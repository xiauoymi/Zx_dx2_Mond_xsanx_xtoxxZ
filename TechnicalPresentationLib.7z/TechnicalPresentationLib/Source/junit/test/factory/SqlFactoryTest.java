package test.factory;

import com.monsanto.wst.technicalpresentationlib.factory.SqlFactory;
import junit.framework.TestCase;
import test.TestUtils;

/**
 * Created by IntelliJ IDEA.
 * Date: May 13, 2005
 * Time: 12:07:23 PM
 * <p/>
 * TODO: Enter description for class.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class SqlFactoryTest extends TestCase {

    public void testGetStatementSuccessful() {
        try {
            TestUtils.prepareLogger();
            String statement = SqlFactory.getStatement("addRequestStat");
            System.out.println("Statement: " + statement);
        } catch (Throwable t) {
            t.printStackTrace();
            fail("Unable to retrieve statement.");
        }
    }

    public void testGetStatement_NonExistent() {
        try {
            TestUtils.prepareLogger();
            String statement = SqlFactory.getStatement("blah");
        } catch (IllegalStateException e) {
            // This should happen.
        } catch (Throwable t) {
            t.printStackTrace();
            fail("The wrong exception was thrown.");
        }
    }

}
