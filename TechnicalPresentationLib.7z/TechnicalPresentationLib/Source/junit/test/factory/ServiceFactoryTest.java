package test.factory;

import junit.framework.TestCase;
import com.monsanto.wst.technicalpresentationlib.dao.RequestDao;
import com.monsanto.wst.technicalpresentationlib.factory.DaoFactory;
import com.monsanto.wst.technicalpresentationlib.factory.ServiceFactory;
import com.monsanto.wst.technicalpresentationlib.service.RequestService;
import com.monsanto.wst.technicalpresentationlib.service.DocumentService;

/**
 * Created by IntelliJ IDEA.
 * Date: May 16, 2005
 * Time: 5:19:58 PM
 * <p>
 * This class is a test case for the service factory class.
 * </p>
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class ServiceFactoryTest extends TestCase {

    /*
     * This method tests the getRequestService() method to make sure it returns a
     * request service.
     */
    public void testGetRequestService() {
        try {
            RequestService service = ServiceFactory.getRequestService();
        } catch (Throwable t) {
            t.printStackTrace();
            fail("Unable to retrieve instance of Request Service.");
        }
    }

    /*
     * This method tests the getRequestService() method to make sure that each result
     * returned is a new instance.
     */
    public void testGetRequestServiceUnique() {
        try {
            RequestService service1 = ServiceFactory.getRequestService();
            RequestService service2 = ServiceFactory.getRequestService();

            assertFalse("Each service returned must be a new instance.", service1 == service2);
        } catch (Throwable t) {
            t.printStackTrace();
            fail("Unable to retrieve instance of Request Service, therefore unable " +
                    "to complete test.");
        }
    }

    /*
     * This method tests the getDocumentService() method to make sure a document service
     * is returned.
     */
    public void testGetDocumentService() {
        try {
            DocumentService service = ServiceFactory.getDocumentService();
        } catch (Throwable t) {
            t.printStackTrace();
            fail("Unable to retrieve instance of Document Service.");
        }
    }

    /*
     * This method tests the getDocumentService() method to make sure that each document
     * service returned is a new instance.
     */
    public void testGetDocumentServiceUnique() {
        try {
            DocumentService service1 = ServiceFactory.getDocumentService();
            DocumentService service2 = ServiceFactory.getDocumentService();

            assertFalse("Each service returned must be a new instance.", service1 == service2);
        } catch (Throwable t) {
            t.printStackTrace();
            fail("Unable to retrieve instance of Document Service, therefore unable " +
                    "to complete test.");
        }
    }

}
