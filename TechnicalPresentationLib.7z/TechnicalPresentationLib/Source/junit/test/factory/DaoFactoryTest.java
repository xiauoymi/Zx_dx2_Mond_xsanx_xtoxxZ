package test.factory;

import com.monsanto.wst.technicalpresentationlib.dao.RequestDao;
import com.monsanto.wst.technicalpresentationlib.factory.DaoFactory;
import junit.framework.TestCase;

/**
 * Created by IntelliJ IDEA.
 * Date: May 13, 2005
 * Time: 8:37:17 AM
 * <p/>
 * TODO: Enter description for class.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class DaoFactoryTest extends TestCase {

    public void testGetRequestDao() {
        try {
            RequestDao dao = DaoFactory.getRequestDao();
        } catch (Throwable t) {
            t.printStackTrace();
            fail("Unable to retrieve instance of Request Dao.");
        }
    }

    public void testGetRequestDaoUnique() {
        try {
            RequestDao dao1 = DaoFactory.getRequestDao();
            RequestDao dao2 = DaoFactory.getRequestDao();

            assertFalse("Each dao returned must be a new instance.", dao1 == dao2);
        } catch (Throwable t) {
            t.printStackTrace();
            fail("Unable to retrieve instance of Request Dao, therefore unable " +
                    "to complete test.");
        }
    }

}
