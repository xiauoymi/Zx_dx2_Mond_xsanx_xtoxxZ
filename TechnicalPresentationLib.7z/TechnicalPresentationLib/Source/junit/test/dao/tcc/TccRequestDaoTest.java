package test.dao.tcc;

import com.monsanto.wst.technicalpresentationlib.dao.tcc.TccRequestDao;
import com.monsanto.wst.technicalpresentationlib.dao.exception.ObjectNotFoundException;
import com.monsanto.wst.technicalpresentationlib.vo.AuditRequest;
import com.monsanto.Util.Exceptions.WrappingException;
import junit.framework.TestCase;
import test.TestUtils;
import test.vo.RequestTest;

/**
 * Created by IntelliJ IDEA.
 * Date: May 13, 2005
 * Time: 8:51:57 AM
 * <p/>
 * TODO: Enter description for class.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 *
 * @author rgeorge (Rijo George)
 * updated the oracle-sql.xml file to reflect the new database & schema names
 * and hence integrate this junit testcase with the respective DAO & methods. 
 * Date : June 20th, 2005
 */
public class TccRequestDaoTest extends TestCase {

    /*
     * Tests the addRequest() method for a successful execution.
     */
    public void testAddRequestSuccessful() {
        TccRequestDao dao = new TccRequestDao();
        AuditRequest customer = RequestTest.createCustomer1(null);
        Long id = null;
        try {
            TestUtils.prepareLogger();
            id = dao.addRequest(customer);
            System.out.println("Generated id: " + id);
        } catch (Throwable t) {
            t.printStackTrace();
            fail("Unable to add customer.");
        }

        verifyRequestAdded(id, "Request should have been added.", TestUtils.SHOULD_PASS);
        rollbackAddedRequest(id);
    }

    /*
     * Verifies the request was added.
     */
    public static void verifyRequestAdded(Long requestId, String message, int expectedResult) {
        TccRequestDao dao = new TccRequestDao();
        AuditRequest request = null;

        try {
            TestUtils.prepareLogger();
            request = dao.loadRequest(requestId);
            if (expectedResult == TestUtils.SHOULD_FAIL) {
                fail(message);
            }
        } catch (ObjectNotFoundException e) {
            if (expectedResult == TestUtils.SHOULD_PASS) {
                e.printStackTrace();
                fail(message);
            }
        } catch (WrappingException e) {
            if (expectedResult == TestUtils.SHOULD_PASS) {
                e.printStackTrace();
                fail(message);
            }
        } catch (Throwable t) {
            t.printStackTrace();
            fail("Wrong exception thrown. " + message);
        }
    }

    /*
     * Deletes the added request.
     */
    public static void rollbackAddedRequest(Long requestId) {
        TccRequestDao dao = new TccRequestDao();

        try {
            dao.deleteRequest(requestId);
        } catch (Throwable t) {
            t.printStackTrace();
        }
    }

}
