package test;

import junit.framework.Test;
import junit.framework.TestSuite;
import junit.textui.TestRunner;
import test.dao.tcc.TccRequestDaoTest;
import test.factory.DaoFactoryTest;
import test.factory.ServiceFactoryTest;
import test.factory.SqlFactoryTest;
import test.vo.RequestTest;
import test.web.controller.*;
import test.service.FilelisterDocumentServiceTest;

/**
 * Created by IntelliJ IDEA.
 * Date: May 13, 2005
 * Time: 3:43:01 PM
 * <p>
 * This class is a test case for testing all test cases.
 * </p>
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 *
 * @author rgeorge(Rijo George)
 * Date : June 17, 2005
 * Added extra TestSuites created
 */
public class TestAll {

    /*
     * Test all test cases.
     */
    public static Test suite() {
        TestSuite suite = new TestSuite();
        suite.addTestSuite(TestControllerTest.class);
        suite.addTestSuite(FilenameDispatchControllerTest.class);
        suite.addTestSuite(ServiceFactoryTest.class);
        suite.addTestSuite(FilelisterDocumentServiceTest.class);
        suite.addTestSuite(ListDocumentControllerTest.class);
        suite.addTestSuite(SelectDocumentControllerTest.class);
        suite.addTestSuite(ViewDocumentControllerTest.class);
        suite.addTestSuite(SqlFactoryTest.class);
        suite.addTestSuite(DaoFactoryTest.class);
        suite.addTestSuite(RequestTest.class);
        suite.addTestSuite(TccRequestDaoTest.class);

        return suite;
    }

    public static void main(String[] args) {
        TestRunner.run(suite());
    }

}
