package test.vo;

import com.monsanto.wst.technicalpresentationlib.vo.AuditRequest;
import junit.framework.TestCase;

import java.util.Date;

/**
 * Created by IntelliJ IDEA.
 * Date: May 12, 2005
 * Time: 4:57:30 PM
 * <p/>
 * TODO: Enter description for class.
 *
 * @author njminsh (Nate Minshew) updated by
 * @version 1.0
 * @since 1.0
 *
 * @author rgeorge (Rijo George)
 * Changed the AuditRequest object to reflect new changes in the bean
 * Date : June 20, 2005 
 */
public class RequestTest extends TestCase {

    public static AuditRequest createCustomer1(Long id) {
        AuditRequest customer = new AuditRequest();
        customer.setId(id);
        customer.setAccessDate(new Date());
        customer.setCreator("testCreator1");
        customer.setDocumentId("XXXXXX");
        customer.setAccessDate(new Date());
        customer.setUser("testUser1");
        customer.setPresentationDate(new Date());
        customer.setPresentationDesc("Type 1");
        customer.setPresentationCont("Content 1");
        customer.setFname("This is test1");
        customer.setFilename("test1.ppt");
        return customer;
    }

    public static AuditRequest createCustomer2(Long id) {
        AuditRequest customer = new AuditRequest();
        customer.setId(id);
        customer.setAccessDate(new Date());
        customer.setCreator("testCreator2");
        customer.setDocumentId("YYYYYYYY");
        customer.setAccessDate(new Date());
        customer.setUser("testUser2");
        customer.setPresentationDate(new Date());
        customer.setPresentationDesc("Type 2");
        customer.setPresentationCont("Content 2");
        customer.setFname("This is test2");
        customer.setFilename("test2.ppt");
        return customer;
    }

    public void testEqual() {
        AuditRequest customer1 = createCustomer1(new Long(123));
        AuditRequest customer2 = createCustomer1(new Long(123));

        assertTrue("The equals method should return true if 2 customers are equal.",
                customer1.equals(customer2));
    }

    public void testNotEqual() {
        AuditRequest customer1 = createCustomer1(new Long(123));
        AuditRequest customer2 = createCustomer2(new Long(345));

        assertFalse("The equals method should return false if 2 customers are not equal",
                customer1.equals(customer2));
    }

    public void testEqualNull() {
        AuditRequest customer1 = createCustomer1(new Long(123));

        try {
            assertFalse("If the customer you are comparing to is null, " +
                    "the equals method should return false.",
                    customer1.equals(null));
        } catch (Throwable t) {
            t.printStackTrace();
            fail("Unable to compare to a null customer.");
        }
    }

    public void testEqualNullFields() {
        AuditRequest customer1 = createCustomer1(null);
        AuditRequest customer2 = new AuditRequest();

        try {
            assertFalse("If the user you are comparing to has null fields, " +
                    "equals should return false.", customer1.equals(customer2));
        } catch (Throwable t) {
            t.printStackTrace();
            fail("Unable to compare to customer with null fields.");
        }
    }

}
