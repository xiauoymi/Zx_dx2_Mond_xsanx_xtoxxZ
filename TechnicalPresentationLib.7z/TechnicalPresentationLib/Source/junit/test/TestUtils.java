package test;

import com.monsanto.AbstractLogging.Logger;
import com.monsanto.dataservices.PersistentStore;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.wst.technicalpresentationlib.Servlet.TechnicalPresentationLibLoggerFactory;
import com.monsanto.wst.technicalpresentationlib.Servlet.TechnicalPresentationLibPersistentStoreFactory;
import com.monsanto.wst.technicalpresentationlib.Servlet.TechnicalPresentationLibServlet;
import com.monsanto.wst.technicalpresentationlib.constant.Constants;

/**
 * Created by IntelliJ IDEA.
 * Date: May 13, 2005
 * Time: 12:49:59 PM
 * <p>
 * This class is a junit utility class for preparing data before doing a test.
 * </p>
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class TestUtils {

    public static final int SHOULD_PASS = 1;
    public static final int SHOULD_FAIL = 0;

    /*
     * This method prepares the Logger for logging errors in the application.
     */
    public static void prepareLogger() {
        setEnvironment();
        try {
            Logger.register(TechnicalPresentationLibLoggerFactory.buildErrorLogger(TechnicalPresentationLibServlet.s_cstrResourceBundle));
        } catch (Exception e) {
            System.out.println("Unable to initialize loggers.");
            e.printStackTrace();
        }
    }

    /*
     * This method prepares resources needed by the persistent store.
     */
    public static void setEnvironment() {
        System.setProperty("lsi.function", "win");
    }

    /*
     * This method prepares resources needed by any servlets.
     */
    public static void prepareServletTest() {
        System.setProperty("system.security.proxy", "com.monsanto.ServletFramework.Test.MockSystemSecurityProxy");
        prepareLogger();
    }

}
