package test.web.controller;

import test.TestUtils;
import test.dao.tcc.TccRequestDaoTest;
import com.monsanto.ServletFramework.Test.MockSystemSecurityProxy;
import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.wst.technicalpresentationlib.web.controller.ViewDocumentController;
import com.monsanto.wst.technicalpresentationlib.sdo.Document;
import junit.framework.TestCase;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * Date: June 17, 2005
 * Time: 9:41:43 AM
 * <p>
 * This test case tests the view document controller.
 * </p>
 * @author rgeorge (Rijo George)
 * @version 1.0
 * @since 1.0
 */
public class ViewDocumentControllerTest extends TestCase {

    /*
     * Tests a successful document retrieval.
     */
    public void testRun_Success() {
        TestUtils.prepareServletTest();
        MockSystemSecurityProxy proxy = new MockSystemSecurityProxy();
        MockUCCHelper helper = new MockUCCHelper("", true, proxy);
        helper.setRequestParameterValue("date","06/31/2006");
        helper.setRequestParameterValue("hour","1");
        helper.setRequestParameterValue("minute","30");
        helper.setRequestParameterValue("ampm","pm");
        helper.setRequestParameterValue("timezone","+2");
        helper.setRequestParameterValue("presentationDesc","Tailored Content");
        helper.setRequestParameterValue("pplName","rgeorge");
        helper.setRequestParameterValue("audience","All");
        helper.setRequestParameterValue("languages","English");
        helper.setRequestParameterValue("presentationCont","Monsanto Overview");
        ViewDocumentController controller = new ViewDocumentController();

        try {
            controller.run(helper);
        } catch (Throwable t) {
            t.printStackTrace();
            fail("Unable to execute the view document controller.");
        }
    }

    /*
     * Tests the flow and that errors get created when not all the required
     * parameters are specified.
     */
    public void testRun_InvalidRequired() {
        TestUtils.prepareServletTest();
        MockUCCHelper helper = new MockUCCHelper("");
        helper.setRequestParameterValue("audience", "All");
        ViewDocumentController controller = new ViewDocumentController();

        try {
            controller.run(helper);
        } catch (Throwable t) {
            t.printStackTrace();
            fail("Unable to execute the view document controller.");
        }

        List errorList = (List) helper.getRequestAttributeValue("errorList");

        if (errorList != null) {
            System.out.println("Errors: " + errorList);
        }

        assertTrue("Incorrect number of errors were returned.", errorList != null && errorList.size() == 8);
        assertTrue("Directed user to incorrect page.", helper.wasSentTo("/WEB-INF/jsp/selectDocument.jsp"));
    }

    /*
     * Tests the flow and that errors get created when the user specifies an invalid
     * date.
     */
    public void testRun_InvalidDate() {
        TestUtils.prepareServletTest();
        MockUCCHelper helper = new MockUCCHelper("");
        helper.setRequestParameterValue("date", "blah");
        helper.setRequestParameterValue("hour","1");
        helper.setRequestParameterValue("minute","30");
        helper.setRequestParameterValue("ampm","pm");
        helper.setRequestParameterValue("timezone","+2");
        helper.setRequestParameterValue("presentationDesc","Tailored Content");
        helper.setRequestParameterValue("pplName","rgeorge");
        helper.setRequestParameterValue("audience","All");
        helper.setRequestParameterValue("languages","English");
        helper.setRequestParameterValue("presentationCont","Monsanto Overview");
        ViewDocumentController controller = new ViewDocumentController();

        try {
            controller.run(helper);
        } catch (Throwable t) {
            t.printStackTrace();
            fail("Unable to execute the view document controller.");
        }

        List errorList = (List) helper.getRequestAttributeValue("errorList");

        if (errorList != null) {
            System.out.println("Errors: " + errorList);
        }

        assertTrue("Date error was not returned.", errorList != null && errorList.size() == 1);
        assertTrue("Directed user to incorrect page.", helper.wasSentTo("/WEB-INF/jsp/selectDocument.jsp"));
    }

}
