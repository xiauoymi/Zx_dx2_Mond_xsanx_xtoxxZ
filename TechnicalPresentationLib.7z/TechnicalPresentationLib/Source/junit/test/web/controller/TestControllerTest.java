package test.web.controller;

import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.wst.technicalpresentationlib.web.controller.TestController;
import junit.framework.TestCase;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Jun 17, 2005
 * Time: 10:58:53 AM
 * This test case tests the TestController
 * @author rgeorge (Rijo George)
 * @version 1.0
 * @since 1.0
 */
public class TestControllerTest extends TestCase{

    public void testRun() {
        MockUCCHelper helper = new MockUCCHelper("http://test.com/tpl/default.htm");
        TestController controller = new TestController();

        try {
            controller.run(helper);
        } catch (Throwable t) {
            t.printStackTrace();
            fail("Unable to forward to correct page.");
        }

        assertTrue("Did not forward correctly.", helper.wasSentTo("/WEB-INF/jsp/test/test.jsp"));
    }
}
