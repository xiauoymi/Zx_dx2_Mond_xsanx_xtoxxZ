package test.web.controller;

import junit.framework.TestCase;
import test.TestUtils;
import com.monsanto.ServletFramework.Test.MockSystemSecurityProxy;
import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.wst.technicalpresentationlib.service.exception.DocumentQueryException;
import com.monsanto.wst.technicalpresentationlib.web.controller.SelectDocumentController;
import com.monsanto.wst.technicalpresentationlib.web.controller.ListDocumentController;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * Date: Jun 17, 2005
 * Time: 11:42:12 AM
 * This test case tests the ListDocumentController.
 * @author rgeorge (Rijo George)
 * @version 1.0
 */
public class ListDocumentControllerTest extends TestCase{

    public void testRun_Success() {
        TestUtils.prepareServletTest();
        MockSystemSecurityProxy proxy = new MockSystemSecurityProxy();
        MockUCCHelper helper = new MockUCCHelper("", true, proxy);

        ListDocumentController controller = new ListDocumentController();
        try {
            controller.run(helper);
        } catch (Throwable t) {
            t.printStackTrace();
            fail("Unable to execute controller.");
        }

        assertTrue("Directed user to incorrect page.", helper.wasSentTo("/WEB-INF/jsp/selectDocument.jsp"));
        }
}
