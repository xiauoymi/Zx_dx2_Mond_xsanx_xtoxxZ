package test.web.controller;

import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.wst.technicalpresentationlib.web.controller.FilenameDispatchController;
import junit.framework.TestCase;

/**
 * Created by IntelliJ IDEA.
 * Date: May 17, 2005
 * Time: 10:06:03 AM
 * <p>
 * This test case tests the filename dispatch controller.
 * </p>
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class FilenameDispatchControllerTest extends TestCase {

    /*
     * Tests whether the controller forwards to the correct html page and path.
     */
    public void testRun() {
        MockUCCHelper helper = new MockUCCHelper("http://test.com/tpl/default.htm");
        FilenameDispatchController controller = new FilenameDispatchController();

        try {
            controller.run(helper);
        } catch (Throwable t) {
            t.printStackTrace();
            fail("Unable to forward to correct page.");
        }

        assertTrue("Did not forward correctly.", helper.wasSentTo("/html/default.htm"));
    }

}
