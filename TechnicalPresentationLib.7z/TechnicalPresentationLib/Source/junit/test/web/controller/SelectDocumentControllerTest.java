package test.web.controller;

import junit.framework.TestCase;
import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.ServletFramework.Test.MockSystemSecurityProxy;
import com.monsanto.wst.technicalpresentationlib.web.controller.SelectDocumentController;
import test.TestUtils;

/**
 * Created by IntelliJ IDEA.
 * Date: May 17, 2005
 * Time: 8:12:37 AM
 * <p>
 * This test case tests the select document controller.
 * </p>
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 *
 * @author rgeorge (Rijo George)
 * Modified the testcase to reflect the appropriate changes in method definitions
 * Date : June 16, 2005
 */
public class SelectDocumentControllerTest extends TestCase {

    /*
     * Tests that the controller successfully retrieves a list of documents.
     */
    public void testRun() {

        MockUCCHelper helper = new MockUCCHelper("");
        SelectDocumentController controller = new SelectDocumentController();

        try {
            controller.run(helper);
        } catch (Throwable t) {
            t.printStackTrace();
            fail("Unable to execute controller.");
        }

        assertTrue("Directed user to incorrect page.", helper.wasSentTo("/WEB-INF/jsp/selectDocument.jsp"));
    }

}
