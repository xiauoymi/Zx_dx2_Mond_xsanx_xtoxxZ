package test.timezone;

import junit.framework.TestCase;

import java.util.Calendar;
import java.util.TimeZone;


/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Jun 22, 2005
 * Time: 12:14:22 PM
 * To change this template use File | Settings | File Templates.
 */
public class TestTimezone{

    public static void main(String[] args) {
            for (int i = 0; i < TimeZone.getAvailableIDs().length; i++) {
                System.out.println("TimeZone " + i + " = '" + TimeZone.getAvailableIDs()[i] + "'");
            }

            Calendar cal = Calendar.getInstance();
            TimeZone ourTimeZone = cal.getTimeZone();
            TimeZone brusselsTimeZone = TimeZone.getTimeZone("Europe/Brussels");
            System.out.println("Our timezone = '" + ourTimeZone + "'");
            System.out.println("Brussels timezone = '" + brusselsTimeZone + "'");
            System.out.println("Our Time: " + cal.getTime());

            cal.setTimeZone(brusselsTimeZone);
            cal.set(Calendar.ZONE_OFFSET, brusselsTimeZone.getRawOffset());
            System.out.println("Brussels Time: " + cal.getTime());

            cal.setTimeZone(ourTimeZone);
            cal.set(Calendar.ZONE_OFFSET, ourTimeZone.getRawOffset());
            System.out.println("Our Time Again: " + cal.getTime());
        }

}
