package test.service;

import junit.framework.TestCase;
import com.monsanto.wst.technicalpresentationlib.sdo.Document;
import com.monsanto.wst.technicalpresentationlib.service.filelister.FilelisterDocumentService;
import com.monsanto.wst.technicalpresentationlib.service.exception.DocumentQueryException;
import com.monsanto.wst.technicalpresentationlib.service.exception.DocumentAccessException;
import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.ServletFramework.Test.MockSystemSecurityProxy;

import java.util.List;

import test.TestUtils;

/**
 * Created by IntelliJ IDEA.
 * Date: May 16, 2005
 * Time: 9:03:51 AM
 * <p/>
 * TODO: Enter description for class.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 *
 * @author rgeorge (Rijo George)
 * Changed the method definition of getDocumentList and retrieveDocument to
 * reflect the updated system.
 * Date: June 17, 2005
 */

public class FilelisterDocumentServiceTest extends TestCase {

    public void testGetDocumentList_Successful() {
        TestUtils.prepareLogger();
        MockSystemSecurityProxy proxy = new MockSystemSecurityProxy();
        MockUCCHelper helper = new MockUCCHelper("", true, proxy);
        FilelisterDocumentService service = new FilelisterDocumentService();

        try {
             List docList = service.getDocumentList("Tailored Content","Launched Products",
                     "Spanish","rgeorge","10/10/2005","All","10","30","am","+1");

            System.out.println(docList);
        } catch (DocumentQueryException e) {
            e.printStackTrace();
            fail("There was a query exception thrown and there shouldn't have been.");
        }
    }

    public void testRetrieveDocument_Successful() {
        TestUtils.prepareLogger();
        FilelisterDocumentService service = new FilelisterDocumentService();

        try {
            Document doc = service.retrieveDocument("09001e1d80011055");

            assertTrue("The incorrect document was returned.",
                    doc != null && doc.getId().equals("09001e1d80011055"));
        } catch (Throwable t) {
            t.printStackTrace();
            fail("Unable to retrieve the document.");
        }
    }

    public void testRetrieveDocument_NonExistant() {
        FilelisterDocumentService service = new FilelisterDocumentService();

        try {
            Document doc = service.retrieveDocument("09001e1d800110d6");
            fail("This document shouldn't exist.");
        } catch (DocumentAccessException e) {
            // This should happen.
        } catch (Throwable t) {
            t.printStackTrace();
            fail("The wrong exception was thrown.");
        }
    }

}
