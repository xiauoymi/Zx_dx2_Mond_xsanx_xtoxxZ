    function navigatetoURL()
    {
        if (top == self)
        {
            document.write("Loading frameset...<br><table><tr><td><br>");
            var where = location.href;
            var myUrl = where;
            var newUrl = "http://w3d.monsanto.com/asp/NGIFrame.aspx?nextUrl=" + myUrl;
            var appVer = navigator.appVersion;--%>
            var NS = (navigator.appName == 'Netscape') && ((appVer.indexOf('3') != -1) || (appVer.indexOf('4') != -1));
            var MSIE = ((appVer.indexOf('MSIE 3') != -1) || (appVer.indexOf('MSIE 4') != -1));
            if (NS || MSIE)
            location.replace(newUrl)
            else
                location.href=newUrl
        }
     }
