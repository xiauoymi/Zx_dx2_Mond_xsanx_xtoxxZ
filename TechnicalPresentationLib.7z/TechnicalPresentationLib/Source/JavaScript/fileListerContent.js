/***********************************************************************************************************************
 * author: Rijo George
 * date: 06/06/2005
 * description: This file is a javascript for for defining functions that will be used on Presentation page.
 **********************************************************************************************************************/

/**
* This function prepares the AJAX url and makes a call to requestFeed(url, processCountyFeed) in the ajax.js file.
*
* created by: NJMINSH (Nate Minshew)
* date created: 05/26/2005
*/
function ContentDesc() {
    var docElement = document.getElementById("documentId");
    var docId = docElement.options[docElement.selectedIndex].value;
    if (docId == null || docId == '') {
        return;
    }

    // This is the url to the next run feed action.
    var url = "documentFeed.htm?documentId=" + escape(docId);
    requestFeed(url, processFilelisterDocument);
}

/**
* This function processes the response of the county feed request and
* modifies the crops and regions page, adding a new drop down for counties.
*
* created by: NJMINSH (Nate Minshew)
* date created: 05/26/2005
*/
function processFilelisterDocument(request) {
    if (getResponse(request)) {
        // If we have made it this far it means that XMLHttpRequest
        // was setup properly connected and we have a successful
        // response.

     // alert(request.responseText);
        var response = getResponse(request);
        var documentNodeList = response.getElementsByTagName('document');
        // check if there were county elements returned.
        if (documentNodeList) {
             // loop through the document

            for (var i = 0; i < documentNodeList.length; i++) {
                var documentNode = documentNodeList[i];
       //     alert("got document node.");
                var attributesNodeList = documentNode.childNodes;

                for (var k = 0; k < attributesNodeList.length; k++) {
                    var attributesNode = attributesNodeList[k];
                    var attributeNodeList = attributesNode.childNodes;

                    for (var j = 0; j < attributeNodeList.length; j++) {
                            var attributeElement = attributeNodeList[j];
                        var colId = attributeElement.getAttribute("colID");

            //    alert("col id = '" + colId + "'");

                        if (colId == 6) {
              //      alert("found correct column.");
                            var valueElementList = attributeElement.childNodes;
                            for (var l = 0; l < valueElementList.length; l++) {
                                    var valueElement = valueElementList[l];
                                    var author = valueElement.childNodes[0].nodeValue;
                                    document.getElementById('auth').innerHTML = author;
                           }
                        }
                        else
                        if (colId == 0) {
                        //alert("found correct column.");
                            var valueElementList = attributeElement.childNodes;
                            for (var l = 0; l < valueElementList.length; l++) {
                                    var valueElement = valueElementList[0];
							            var fname = new Array(valueElement.childNodes[0].nodeValue);
							            document.getElementById('fname').innerHTML = fname[0];
                                    var valueElement = valueElementList[1];
							            var pptname = new Array(valueElement.childNodes[0].nodeValue);
							            document.getElementById('ppt').innerHTML = pptname[0];
					        }
                        }
                       else
                       if (colId == 7) {
                        //alert("found correct column.");
                           var valueElementList = attributeElement.childNodes;
                           for (var l = 0; l < valueElementList.length; l++) {
                                    var valueElement = valueElementList[l];
                                    var description = valueElement.childNodes[0].nodeValue;
                                    document.getElementById('desc').innerHTML = description;
                            }
                        }
                    }
                }
            }
        } else {
            // This means that no document could be found.  Display the error message.
            if (response.getElementsByTagName('error')[0]) {
                document.getElementById('error').innerHTML = response.getElementsByTagName('error')[0].childNodes[0].nodeValue;
            }
        }
    }
}
