/***********************************************************************************************************************
 * author: NJMINSH (Nate Minshew)
 * date: 05/26/2005
 * description: This file is a javascript file for componentizing the AJAX functionality.  In order to use this js
 *      file you will need to define it before any implementing javascript in your html/jsp/asp/xsl/ect.  Then
 *      you will need to write an entry point function that will be called when the AJAX event occurs.  This entry
 *      point function will define the url that will be called to make the xml request and the function that will be
 *      called to process the response.  You will then have to define that function that will process the response and
 *      make sure that it accepts a variable which will be the request object.  The first line of the process method
 *      should call getResponse(request) which will return the xml response object or null if there was a problem.
 *      Then just process the xml as you need.  There is also a method that you can call to check if ajax is available
 *      for the current browser.
 **********************************************************************************************************************/

/**
* This function makes an AJAX request to the specified url and defines the function that will process the response.
*
* created by: NJMINSH (Nate Minshew)
* date created: 05/26/2005
*/

function requestFeed(url, functionObject) {
    var request;
    if (window.XMLHttpRequest) {
        // This is how we setup XMLHttpRequest for none IE browsers.
        request = new XMLHttpRequest();
        request.open("GET", url, true);
        // This sets the function that should be called to process the
        // xml response.
        request.onreadystatechange = function() { functionObject(request); }
        request.send(null);
    } else if (window.ActiveXObject) {
        // This is how we setup XMLHttpRequest for IE.
        request = new ActiveXObject("Microsoft.XMLHTTP");
        request.open("GET", url, true);
        // This sets the function that should be called to process the
        // xml response.
        request.onreadystatechange = function() { functionObject(request); }
        request.send();
    }
}

/**
 * This function returns the xml response from the AJAX request and null if there wasn't a response or there was an
 * error returned.
 *
 * created by: NJMINSH (Nate Minshew)
 * date created: 05/26/2005
 */
function getResponse(request) {
    if (request) {
        if (request.readyState == 4) {
            if (request.status == 200) {
                if (request.responseXML) {
                    return request.responseXML;
                }
            }
        }
    }

    return null;
}

/**
 * This function returns whether AJAX is supported in the current browser.  It returns false if getElementById is not
 * defined, meaning that DHTML is not supported.
 *
 * created by: NJMINSH (Nate Minshew)
 * date created: 05/26/2005
 */
function isAjaxSupported() {
    // If we can't access elements in the page using document.getElementById
    // then the Ajax stuff isn't very useful to us.
    if (!document.getElementById) {
        return false;
    }

    if (window.XMLHttpRequest || (window.ActiveXObject
            && new ActiveXObject("Microsoft.XMLHTTP"))) {
        return true;
    }

    return false;
}