package com.monsanto.wst.technicalpresentationlib.Security;


import com.monsanto.AbstractLogging.LoggableError;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.OracleSecurity.OracleSecurityServer;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dbdataservices.PersistentStoreOracleType2;
import com.monsanto.security.SecurityServer;
import com.monsanto.security.SecurityServiceException;

import java.util.ResourceBundle;

/**
 *
 * <p>Title: SecurityFactory</p>
 * <p>Description: Creates a SecureUser object and passes it to the caller.</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Monsanto</p>
 * @author Java Framework Code	Generator 2.1
 * @version $Id: SecurityFactory.java,v 1.2 2006-03-11 21:44:57 mecoru Exp $
 */
public class SecurityFactory
{
   protected SecurityFactory()
   {
      Logger.traceEntry();

      Logger.traceExit();
   }

   /**
    * @return com.monsanto.security.SecurityServer
    */
   public static SecurityServer buildSecurityServer(String cstrProperFileName) throws SecurityServiceException
   {
      Logger.traceEntry();

      SecurityServer RetVal = null;

      ResourceBundle bundle = ResourceBundle.getBundle(cstrProperFileName);
      try {
         RetVal = new OracleSecurityServer(new PersistentStoreOracleType2(bundle));
      }
      catch (WrappingException we) {
         Logger.log(new LoggableError(we));
         throw new SecurityServiceException(we.toString());
      }

      return (SecurityServer) Logger.traceExit(RetVal);
   }

   public static String getAppName ()
   {
      Logger.traceEntry();

      return Logger.traceExit("TechnicalPresentationLib");
   }
}
