package com.monsanto.wst.technicalpresentationlib.constant;



/**
 * Created by IntelliJ IDEA.
 * Date: May 13, 2005
 * Time: 1:44:30 PM
 * <p/>
 * TODO: Enter description for class.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class Constants {

    public static final String APPLICATION_RESOURCE_BUNDLE_FILE = "com.monsanto.wst.technicalpresentationlib.Servlet.TechnicalPresentationLib";

    public static final String POWER_POINT_MIME_TYPE = "application/vnd.ms-powerpoint";

}
