package com.monsanto.wst.technicalpresentationlib.web.controller;

import com.monsanto.AbstractLogging.LoggableError;
import com.monsanto.AbstractLogging.LoggableInfo;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.ServletFramework.UseCaseController;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.wst.technicalpresentationlib.factory.ServiceFactory;
import com.monsanto.wst.technicalpresentationlib.sdo.Document;
import com.monsanto.wst.technicalpresentationlib.service.DocumentService;
import com.monsanto.wst.technicalpresentationlib.service.RequestService;
import com.monsanto.wst.technicalpresentationlib.service.exception.DocumentAccessException;
import com.monsanto.wst.technicalpresentationlib.service.exception.DocumentQueryException;
import com.monsanto.wst.technicalpresentationlib.vo.AuditRequest;
import org.apache.commons.lang.StringUtils;

import java.io.IOException;
import java.io.OutputStream;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.StringTokenizer;
import java.util.TimeZone;
import java.util.Locale;


/**
 * Created by IntelliJ IDEA.
 * Date: Jun 10, 2005
 * Time: 10:15:39 AM
 * @author rgeorge (Rijo george)
 * @version 1.0
 */
public class RetrieveDocumentController implements UseCaseController{

    private static final String DATE_FORMAT = "MM/dd/yyyy";
//    private static final int MILLIS_IN_MINUTE = 60000;
//    private static final int MINUTES_IN_HOUR = 60;

    public void run(UCCHelper helper) throws IOException {
    try {

        /**
         * paramters sent in the request are retrieved
         */
            DocumentService documentService = ServiceFactory.getDocumentService();
            String docId = helper.getRequestParameterValue("id1");
            String uname = helper.getRequestParameterValue("id2");
            String audience = helper.getRequestParameterValue("id4");
            String date = helper.getRequestParameterValue("id3");
            String hours = helper.getRequestParameterValue("id5");
            String mins = helper.getRequestParameterValue("id6");
            String ampm = helper.getRequestParameterValue("id7");
            String tz = helper.getRequestParameterValue("id8");

            Calendar cal = Calendar.getInstance();
//            Locale loc = new Locale("en","US");
            SimpleDateFormat sdf = new SimpleDateFormat(DATE_FORMAT);
            if (StringUtils.isNotEmpty(date) && StringUtils.isNotEmpty(ampm)) {
               if (hours.equals("12")&&(ampm.equals("pm"))){
                        ampm = "am";
                    }
                    else
                    if (hours.equals("12")&&(ampm.equals("am"))){
                        ampm = "pm";
                    }
                try {
                        cal.setTime(sdf.parse(date));
                        cal.set(Calendar.HOUR, Integer.parseInt(hours));
                        cal.set(Calendar.MINUTE, Integer.parseInt(mins));

                        if ("AM".equalsIgnoreCase(ampm)) {
                            cal.set(Calendar.AM_PM, Calendar.AM);
                        } else if ("PM".equalsIgnoreCase(ampm)) {
                            cal.set(Calendar.AM_PM, Calendar.PM);
                        }
                        TimeZone timezone = TimeZone.getTimeZone(tz);
                    //cal.setTimeZone(timezone);
                        cal.set(Calendar.ZONE_OFFSET, timezone.getRawOffset());

                //parseAndSetTimeZone(cal,timezone);
                } catch (ParseException e) {
                Logger.log(new LoggableInfo(e));
                } catch (NumberFormatException e) {
                Logger.log(new LoggableInfo(e));
                }
            }



        /**
         * Retrieves the document selected - based on the document Id.
         *
         */
            Document document = documentService.retrieveDocument(docId);
            System.out.println("Document returned:\n" + document);
            helper.setContentType(document.getMimeType());
            helper.setHeader("Content-Disposition", "attachment; filename=\"" + document.getFileName() + "\"");

            OutputStream out = helper.getBinaryStream();
            int len = document.getFileStream().length;
            System.out.println(len);

            byte[] stream2 = document.getFileStream();

            for(int i = 0; i < stream2.length; i++){
                System.out.print(stream2[i]);
            }
            out.write(document.getFileStream());
            out.flush();
            out.close();


        /**
         * add the audit information to the database
         */

            RequestService requestService = ServiceFactory.getRequestService();
            AuditRequest requestdb = new AuditRequest();

            requestdb.setCreator(helper.getAuthenticatedUserID());
            requestdb.setDocumentId(docId);
            Timestamp timestamp = new Timestamp(System.currentTimeMillis());
            requestdb.setAccessDate(timestamp);
            requestdb.setUser(uname);
            requestdb.setPresentationDate(cal.getTime());
            requestdb.setPresentationDesc(document.getPresentationDesc());
            if (document.getPresentationDesc().equals("Tailored Content")){
                requestdb.setPresentationCont(document.getPresentationCont());
            }
            else{
                document.setPresentationCont(null);
            }
            requestdb.setFname(document.getName());
            requestdb.setFilename(document.getFileName());
            requestdb.setAudience(audience);

        try {
            System.out.println("We have reached here");
            requestService.addRequest(requestdb);
            System.out.println("Request added to database");
            //helper.expire();
        } catch (WrappingException e) {
            Logger.log(new LoggableError(e));
            // Throw illegalstateexception to redirect to error page.
            // Check the web.xml file to find out what the error page is.
            throw new IllegalStateException("Unable to add request to database.");
        }

        } catch (DocumentQueryException e) {
            Logger.log(new LoggableError(e));
            // Throw illegalstateexception to redirect to error page.
            // Check the web.xml file to find out what the error page is.
            throw new IllegalStateException("Unable to query for documents.");
        } catch (DocumentAccessException e) {
            Logger.log(new LoggableError(e));
            // Throw illegalstateexception to redirect to error page.
            // Check the web.xml file to find out what the error page is.
            throw new IllegalStateException("Unable to retrieve document.");
        }
        System.out.println("Request Service completed!!!");

    }

    /**
     * This method parses the timezone selected and updates the specified
     * calendar object.
     *
     * @param cal Calendar object representing the presentation date.
     * @param timezone String representing the timezone adjustment.
     */
//    private void parseAndSetTimeZone(Calendar cal, String timezone) {
//        StringTokenizer token = new StringTokenizer(timezone, " ");
//
//        // parse the sign and the offset.
//        String sign = token.hasMoreTokens() ? token.nextToken() : "";
//        String offset = token.hasMoreTokens() ? token.nextToken() : "";
//
//        // get the hour and minute values of the offset.
//        StringTokenizer offsetToken = new StringTokenizer(offset, ":");
//        String hour = token.hasMoreTokens() ? offsetToken.nextToken() : null;
//        String minute = token.hasMoreTokens() ? offsetToken.nextToken() : null;
//
//        // if there are both hour and minute values calculate the total offset
//        // in milliseconds and update the calendar object.
//        // otherwise just convert the hour to milliseconds and update.
//        if (StringUtils.isNotEmpty(hour) && StringUtils.isNotEmpty(minute)) {
//            int iOffset = Integer.parseInt(hour) * MINUTES_IN_HOUR * MILLIS_IN_MINUTE;
//            int iMinute = Integer.parseInt(minute)/60 * MILLIS_IN_MINUTE;
//            iOffset = iOffset + iMinute;
//
//            if ("-".equals(sign)) {
//                cal.set(Calendar.ZONE_OFFSET, -iOffset);
//            } else {
//                cal.set(Calendar.ZONE_OFFSET, iOffset);
//            }
//        } else {
//            int iOffset = Integer.parseInt(offset) * MINUTES_IN_HOUR * MILLIS_IN_MINUTE;
//
//            if ("-".equals(sign)) {
//                cal.set(Calendar.ZONE_OFFSET, -iOffset);
//            } else {
//                cal.set(Calendar.ZONE_OFFSET, iOffset);
//            }
//        }
//    }
}
