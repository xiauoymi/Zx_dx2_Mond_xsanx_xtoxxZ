package com.monsanto.wst.technicalpresentationlib.service.exception;

/**
 * Created by IntelliJ IDEA.
 * Date: May 16, 2005
 * Time: 8:46:02 AM
 * <p/>
 * TODO: Enter description for class.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class DocumentAccessException extends Exception {

    public DocumentAccessException(String message) {
        super(message);
    }

    public DocumentAccessException(Throwable t) {
        super(t);
    }

    public DocumentAccessException(String message, Throwable t) {
        super(message, t);
    }

}
