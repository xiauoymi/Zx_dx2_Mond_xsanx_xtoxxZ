package com.monsanto.wst.technicalpresentationlib.service;

import com.monsanto.wst.technicalpresentationlib.service.exception.DocumentQueryException;
import com.monsanto.wst.technicalpresentationlib.service.exception.DocumentAccessException;
import com.monsanto.wst.technicalpresentationlib.sdo.Document;

import javax.xml.parsers.ParserConfigurationException;
import java.util.List;
import java.util.Date;


/**
 * Created by IntelliJ IDEA.
 * Date: May 16, 2005
 * Time: 8:42:10 AM
 * <p>
 * This interface defines service methods for performing tasks on a document or group of documents.
 * </p>
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 *
 * @author rgeorge (Rijo George)
 * modified the getDocumentList method
 * Date : June 20, 2005
 */
public interface DocumentService {

    /**
     * This method returns a list of all available documents.
     *
     * @return List - Representing a list of Document objects.
     * @throws DocumentQueryException - If unable to query for documents.
     */
    public List getDocumentList(String presentationDesc, String presentationCont,
                                String language, String uname, String presdate, String audience,
                                String hours, String mins, String ampm, String timezone)
                                throws DocumentQueryException;

    /**
     * This method retrieves the document with the specified id.
     *
     * @param documentId String representing the document id.
     * @return Document - Object representing the document.
     * @throws DocumentQueryException - If unable to query for document.
     * @throws DocumentAccessException - If unable to retrieve document.
     */
    public Document retrieveDocument(String documentId) throws DocumentQueryException, DocumentAccessException;

//    public org.w3c.dom.Document queryFilelister() throws DocumentQueryException;
//
//    public org.w3c.dom.Document getcontentDocument(org.w3c.dom.Document doc, String documentId) throws ParserConfigurationException;


}
