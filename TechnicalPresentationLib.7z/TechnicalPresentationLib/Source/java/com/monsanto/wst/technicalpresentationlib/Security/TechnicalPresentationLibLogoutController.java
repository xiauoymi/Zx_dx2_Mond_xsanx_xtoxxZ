package com.monsanto.wst.technicalpresentationlib.Security;

import com.monsanto.AbstractLogging.Logger;
import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.ServletFramework.UseCaseController;

import java.io.IOException;

/**
 *
 * <p>Title: TechnicalPresentationLibLogoutController.java</p>
 * <p>Description: Closes the session and calls the logon controller.</p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Monsanto</p>
 * @author Java Framework Code	Generator 2.1
 * @version $Id: TechnicalPresentationLibLogoutController.java,v 1.2 2005-05-16 21:54:35 njminsh Exp $
 */
public class TechnicalPresentationLibLogoutController implements UseCaseController
{
   /**
    * Closes the session and calls the logon controller to re-logon the user.
    * @param helper A Use Case Controller helper class.
    * @throws java.io.IOException
    */
   public void run(UCCHelper helper) throws IOException
   {
      Logger.traceEntry();

      helper.closeSession();
      helper.displayHTML_File("html/TechnicalPresentationLibLogon.html");

      Logger.traceExit();
   }
}
