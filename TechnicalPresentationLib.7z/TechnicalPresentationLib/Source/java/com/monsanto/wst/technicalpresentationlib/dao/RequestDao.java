package com.monsanto.wst.technicalpresentationlib.dao;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.wst.technicalpresentationlib.vo.AuditRequest;
import com.monsanto.wst.technicalpresentationlib.dao.exception.ObjectNotFoundException;

/**
 * Created by IntelliJ IDEA.
 * Date: May 12, 2005
 * Time: 4:36:41 PM
 * <p>
 * This class is a data access object for the request_t database table.
 * </p>
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public interface RequestDao {

    /**
     * This method adds a request object to the database.
     *
     * @param request Object representing the request.
     * @return Long - representing the sequence number.
     * @throws WrappingException - If there was a problem adding the request.
     */
    public Long addRequest(AuditRequest request) throws WrappingException;

    /**
     * This method returns the request with the specified id.
     *
     * @param requestId Long representing the request id.
     * @return Request - Object representing the audit information.
     * @throws WrappingException - If a database exception is thrown.
     * @throws ObjectNotFoundException - If unable to retrieve request.
     */
    public AuditRequest loadRequest(Long requestId) throws WrappingException, ObjectNotFoundException;

    /**
     * This method deletes the request with the specified id.
     *
     * @param requestId Long representing the request id.
     * @throws WrappingException - If there is a problem deleting the request.
     */
    public void deleteRequest(Long requestId) throws WrappingException;

}
