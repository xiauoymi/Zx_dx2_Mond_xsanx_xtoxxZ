package com.monsanto.wst.technicalpresentationlib.Security;

import com.monsanto.AbstractLogging.Logger;

import java.io.PrintWriter;

/**
 *
 * <p>Title: DisplaySessionTimeout.java</p>
 * <p>Description: Displays a timeout message and directs the user to the logon
 *  screen to re-logon.</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Monsanto</p>
 * @author Java Framework Code	Generator 2.1
 * @version $Id: DisplaySessionTimeout.java,v 1.1 2005-05-10 15:32:08 ardharn Exp $
 */
public class DisplaySessionTimeout
{

   /**
    * Displays an error message when session times out.
    * @param writer writes the error message as html text.
    */
   public static void displayTimeoutMessage(PrintWriter writer)
   {
      Logger.traceEntry();

      writer.println("<html>");
      writer.println("<head>");
      writer.println("<meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\">");
      writer.println("<title>Logon Timeout</title>");
      writer.println("</head>");
      writer.println("<body bgcolor=\"#cccccc\">");
      writer.println("</p>");
      writer.println("<h2 align=\"center\">");
      writer.println("Your session has timed out.  Please logon again");
      writer.println("<p align=\"center\"><a href=\"../html/TechnicalPresentationLibLogon.html\">Logon</a>");
      writer.println("</h2>");
      writer.println("</body>");
      writer.println("</html>");

      Logger.traceExit();
   }
}
