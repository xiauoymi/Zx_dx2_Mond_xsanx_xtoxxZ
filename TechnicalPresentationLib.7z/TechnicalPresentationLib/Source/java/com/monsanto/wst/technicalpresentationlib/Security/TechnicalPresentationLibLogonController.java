package com.monsanto.wst.technicalpresentationlib.Security;

import com.monsanto.AbstractLogging.*;
import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.ServletFramework.UseCaseController;
import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.security.*;
import com.monsanto.user.NoSuchUserException;
import com.monsanto.wst.technicalpresentationlib.Servlet.I_SessionParams;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import java.io.IOException;


/**
 *
 * <p>Title: TechnicalPresentationLibLogonController</p>
 * <p>Description: Validates and logs on the current user.</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Monsanto</p>
 * @author Java Framework Code	Generator 2.1
 * @version $Id: TechnicalPresentationLibLogonController.java,v 1.3 2006-03-11 21:45:07 mecoru Exp $
 */
public class TechnicalPresentationLibLogonController implements UseCaseController
{
   /**
    * Runs the code that implements the logon use case.
    * @param helper a UCCHelper used to perform common UCC tasks
    * @throws IOException
    */
   public void run (UCCHelper helper) throws IOException
   {
      Logger.traceEntry();

      try {
         helper.clearSession();

         SecureUser secureUser = buildSecureUser(helper);

         LoginBrief lb = authorizeUser(helper, secureUser);

         Document doc = DOMUtil.newDocument();
         Element itemElement = DOMUtil.addChildElement(doc, "USER_INFO");
         secureUser.insertXML(itemElement);
         lb.insertXML(itemElement);

         /*  If we get here without an exception being thrown then the user must be valid.  */
         helper.applyStylesheet(doc, "/Stylesheet/MainMenu.xsl");
         
         Logger.traceExit();
      }
      catch (SecurityServiceException sse) {      // Some sort of database problem
         Logger.log(new LoggableError("A error occured while logging on the user. " + "The error was: " + sse.toString()));

         DisplayLogonError.displayLogonFailedWrappingException(helper.getPrintWriter());
      }
       catch (NoLogonInformationException nlie) {  // The user needs to identify himself
         helper.displayHTML_File("html/ExampleServletLogon.html");

      }
      catch (LogonFailedException lfe) {          // User identified, but logon was not successful (Bad Password?)
         Logger.log(new LoggableInfo("Logon failed: " + lfe.toString()));

         DisplayLogonError.displayLogonFailed(helper.getPrintWriter(), lfe.getMessage());
      }
   }


   /**
    * Logs the user on to the application.
    * @param helper A Use Case Controller helper class.
    * @throws LogonFailedException if the Password was not provided.
    */
   private LoginBrief authorizeUser (UCCHelper helper, SecureUser secureUser) throws LogonFailedException,
                                                                                     SecurityServiceException
   {
      Logger.traceEntry();

      LoginBrief RetVal = null;

      /*  Be sure the supplied password matches the one in the database.  */
      SecurityGateKeeper gateKeeper = new SecurityGateKeeper();
      RetVal = gateKeeper.login(secureUser, SecurityFactory.getAppName(), SecurityFactory.buildSecurityServer("com.monsanto.wst.technicalpresentationlib.Servlet.TechnicalPresentationLib"));

      /*  If we get this far we are logged in.  Save the security gatekeeper as a session variable.  */
      helper.setSessionParameter(I_SessionParams.sf_cstrSECURITY_GATEKEEPER, gateKeeper);
      helper.setSessionParameter(I_SessionParams.sf_cstrCURRENT_USER, secureUser);

      Logger.log(new LoggableInfo("Logged on user: " + secureUser.userId()));

      return (LoginBrief) Logger.traceExit(RetVal);
   }


   /**
    * Builds a SecureUser object from the input data.
    * @param helper A Use Case Controller helper class.
    * @return SecureUser - The secure user
    * @throws LogonFailedException if the Password was not provided.
    * @throws NoLogonInformationException if the Username was not provided
    * @throws IOException - Error accessing the session of the input data.
    */
   private SecureUser buildSecureUser (UCCHelper helper) throws LogonFailedException,
                                                                NoLogonInformationException,
                                                                java.io.IOException
   {
      Logger.traceEntry();

      String cstrUsername = null;
      SecureUser RetVal   = null;

      cstrUsername = helper.serverAuthorizedUser();
      if ((cstrUsername != null) && !cstrUsername.equals("")) {
//         try {
//            RetVal = new AuthenticatedUser(cstrUsername);
//         }
//         catch (NoSuchUserException e) {
//            throw new LogonFailedException("Login Failed: Userid not found.");
//         }
//         catch (WrappingException e) {
//            throw new LogonFailedException("Login Failed: Data store error: " + e.toString());
//         }

      } else {
         /*  If the UID is not available anywhere else, see if it comes from an HTML request.  */
         cstrUsername = helper.getRequestParameterValue("UserName");

         if ((cstrUsername == null) || cstrUsername.equals("")) {
            Logger.log(new DebugLogEvent("Login Failed: No Username provided."));
            throw new NoLogonInformationException("Login Failed: No Username provided.");
         }

         String cstrPassword = helper.getRequestParameterValue("Password");
         if (cstrPassword == null || cstrPassword.equals("")) {
            Logger.log(new DebugLogEvent("Login Failed: No Password provided for user: " + cstrUsername));
            throw new LogonFailedException("Login Failed: No Password provided.");
         }

         Logger.log(new LoggableInfo("User " + cstrUsername + " entering from the logon screen."));

         try {
            RetVal = new SecureUser(cstrUsername, cstrPassword);
         }
         catch (NoSuchUserException nsue) {
            Logger.log(new LoggableWarning(nsue));
            throw new LogonFailedException("The user " + cstrUsername + " could not be logged on.");

         }
         catch (WrappingException we) {
            Logger.log(new LoggableError(we));
            throw new LogonFailedException("The user " + cstrUsername + " could not be logged on.");
         }
      }

      return (SecureUser) Logger.traceExit(RetVal);
   }
}
