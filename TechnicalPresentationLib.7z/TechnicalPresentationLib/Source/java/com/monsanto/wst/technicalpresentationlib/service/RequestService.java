package com.monsanto.wst.technicalpresentationlib.service;

import com.monsanto.wst.technicalpresentationlib.vo.AuditRequest;
import com.monsanto.Util.Exceptions.WrappingException;

/**
 * Created by IntelliJ IDEA.
 * Date: May 16, 2005
 * Time: 8:42:19 AM
 * <p>
 * This interface defines services for performing tasks on a request.
 * </p>
 *
 * @author njminsh (Nate Minshew) - updated by
 * @version 1.0
 * @since 1.0
 *
 * @author rgeorge (Rijo George)
 * Changed the addRequest method
 * Date : June 20, 2005
 */
public interface RequestService {

    /**
     * This method adds the specified request to the system.
     *
     * @param request Object representing the request.
     * @return Long - Representing the request id.
     * @throws WrappingException - If unable to add request.
     */
    public Long addRequest(AuditRequest request) throws WrappingException;

}
