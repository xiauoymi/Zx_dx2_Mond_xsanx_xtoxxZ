/*
 ExampleServletLoggerFactory was created on Jul 3, 2003 using Monsanto
 resources and is the sole property of Monsanto.  Any duplication of the
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.technicalpresentationlib.Servlet;

import com.monsanto.AbstractLogging.*;
import com.monsanto.Log4JLogging.*;
import com.monsanto.Util.EnvironmentHelper;
import com.monsanto.Util.EnvironmentHelperException;

import java.io.File;
import java.io.IOException;
import java.util.ResourceBundle;

/**
 * <p>Title: ExampleServletLoggerFactory</p>
 * <p>Description:
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Monsanto</p>
 * @author Java Framework Code	Generator 2.1
 * @version $Id: TechnicalPresentationLibLoggerFactory.java,v 1.3 2005-06-06 18:44:31 rgeorge Exp $
 */
public class TechnicalPresentationLibLoggerFactory
{
   private static final String sf_cstrAppName = "TechnicalPresentationLib";
   private static CompositeLogDevice s_RollingLog = null;
   private static String s_cstrPrefix = null;
   private static String s_cstrLocation = null;
   private static ITraceLog s_TraceLog = null;
   private static IDebugLog s_DebugLog = null;
   private static IInfoLog s_InfoLog = null;
   private static IWarningLog s_WarningLog = null;
   private static IErrorLog s_ErrorLog = null;

   static
   {
      try {
         s_cstrPrefix = EnvironmentHelper.getPropertyPrefix();
      }
      catch (EnvironmentHelperException e) {
         s_cstrPrefix = "";
      }
   }

   private static synchronized LogDevice buildAppLogDevice(String cstrResourceBundleName) throws IOException
   {
      if (s_RollingLog == null) {
         s_RollingLog = new CompositeLogDevice();

         String cstrBaseLogFileName = getLogFolder(cstrResourceBundleName) + File.separatorChar + sf_cstrAppName;

         s_RollingLog.add(new Log4JMidnightRollingFileLogDevice(cstrBaseLogFileName + ".log"));
         s_RollingLog.add(new Log4J_XML_FileLogDevice(cstrBaseLogFileName + ".xml"));
      }

      return s_RollingLog;
   }

   private static synchronized String getLogFolder(String cstrResourceBundleName)
   {
      if (s_cstrLocation == null) {
         try {
            String cstrCatalinaBase = System.getProperty("catalina.base");
            if (cstrCatalinaBase == null) {
               s_cstrLocation = ".";
            } else {
               s_cstrLocation = cstrCatalinaBase;
            }

         ResourceBundle bundle = ResourceBundle.getBundle(cstrResourceBundleName);

            String cstrFolderNameFromBundle = bundle.getString(s_cstrPrefix + "log.location");
            if (cstrFolderNameFromBundle != null) {
               s_cstrLocation = cstrFolderNameFromBundle;
            }
         }
         catch (RuntimeException re) {
            System.out.println("Cannot find log resource definition location: " + s_cstrPrefix + "log.location.  Using default location: " + s_cstrLocation);
         }
      }

      return s_cstrLocation;
   }

   /**
    * Returns the TraceLog implementation for the application.
    *
    * @param cstrResourceBundleName The name of the properties file containing
    *                               the information about how to construct logs.
    * @return The trace log.
    * @throws java.io.IOException if the log could not be generated.
    */
   public static ITraceLog buildTraceLogger(String cstrResourceBundleName) throws IOException
   {
      if (s_TraceLog == null) {
         String cstrLogFolderName = getLogFolder(cstrResourceBundleName);

         s_TraceLog = new Log4JTraceLog(sf_cstrAppName, new Log4JFileLogDevice(cstrLogFolderName + File.separatorChar + sf_cstrAppName + "Trace.log"));
      }

      return s_TraceLog;
   }

   /**
    * Returns DebugLog implementation for the application.
    *
    * @param cstrResourceBundleName The name of the properties file containing
    *                               the information about how to construct logs.
    * @return The debug log.
    * @throws java.io.IOException if the log could not be generated.
    */
   public static IDebugLog buildDebugLogger(String cstrResourceBundleName) throws IOException
   {
      if (s_DebugLog == null) {
         s_DebugLog = new Log4JDebugLog(sf_cstrAppName, buildAppLogDevice(cstrResourceBundleName));
      }

      return s_DebugLog;
   }

   /**
    * Returns InfoLog implementation for the application.
    *
    * @param cstrResourceBundleName The name of the properties file containing
    *                               the information about how to construct logs.
    * @return The Info Log
    * @throws java.io.IOException if the log could not be generated.
    */
   public static IInfoLog buildInfoLogger(String cstrResourceBundleName) throws IOException
   {
      if (s_InfoLog == null) {
         s_InfoLog = new Log4JInfoLog(sf_cstrAppName, buildAppLogDevice(cstrResourceBundleName));
      }

      return s_InfoLog;
   }

   /**
    * Returns WarningLog implementation for the application.
    *
    * @param cstrResourceBundleName The name of the properties file containing
    *                               the information about how to construct logs.
    * @return The warning log
    * @throws java.io.IOException if the log could not be generated.
    */
   public static IWarningLog buildWarningLogger(String cstrResourceBundleName) throws IOException
   {
      if (s_WarningLog == null) {
         s_WarningLog = new Log4JWarningLog(sf_cstrAppName, buildAppLogDevice(cstrResourceBundleName));
      }

      return s_WarningLog;
   }

   /**
    * Returns ErrorLog implementation for the application.
    *
    * @param cstrResourceBundleName The name of the properties file containing
    *                               the information about how to construct logs.
    * @return The error log.
    * @throws java.io.IOException if the log could not be generated.
    */
   public static IErrorLog buildErrorLogger(String cstrResourceBundleName) throws IOException
   {
      if (s_ErrorLog == null) {
         s_ErrorLog = new Log4JErrorLog(sf_cstrAppName, buildAppLogDevice(cstrResourceBundleName));
      }

      return s_ErrorLog;
   }

   /**
    * Returns AuditLog implementation for the application.  This application
    * does not use an Audit Log so this method returns null.
    *
    * @param cstrResourceBundleName The name of the properties file containing
    *                               the information about how to construct logs.
    * @return IAuditLog The Audit log to use.
    * @throws java.io.IOException if the log could not be generated.
    */
   public static IAuditLog buildAuditLogger(String cstrResourceBundleName) throws IOException
   {
      return null;
   }
}
