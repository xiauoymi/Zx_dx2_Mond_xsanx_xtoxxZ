package com.monsanto.wst.technicalpresentationlib.util.persistentstore;

import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreStatement;
import com.monsanto.dataservices.PersistentStoreResultSet;

/**
 * Created by IntelliJ IDEA.
 * Date: May 16, 2005
 * Time: 8:31:56 AM
 * <p>
 * This class contains static utility methods for performing tasks on a persistent
 * store.
 * </p>
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class PersistentStoreUtils {

    /**
     * This method closes the specified persistent store connection if it is not
     * null.  If an exception is thrown, the exception is just swallowed since there
     * isn't much you can do.
     *
     * @param con PersistentStoreConnection representing the connection to the database.
     */
    public static void close(PersistentStoreConnection con) {
        if (con != null) {
            try {
                con.close();
            } catch (WrappingException e) {
                // What are you going to do?
            }
        }
    }

    /**
     * This method closes the specified persistent store statement if it is not
     * null.  If an exception is thrown, the exception is just swallowed since there
     * isn't much you can do.
     *
     * @param stat PersistentStoreStatement representing the sql statement.
     */
    public static void close(PersistentStoreStatement stat) {
        if (stat != null) {
            try {
                stat.close();
            } catch (WrappingException e) {
                // What are you going to do?
            }
        }
    }

    /**
     * This method closes the specified persistent store result set if it is not null.
     *
     * @param rs PersistentStoreResultSet representing the query result.
     */
    public static void close(PersistentStoreResultSet rs) {
        if (rs != null) {
            rs.close();
        }
    }

    /**
     * This method rollbacks the specified connection if it is not null and swallows
     * any exceptions that might occur.
     *
     * @param con PersistentStoreConnection representing the connection to the DB.
     */
    public static void rollback(PersistentStoreConnection con) {
        if (con != null) {
            try {
                con.rollbackTransaction();
            } catch (WrappingException e) {
                // What are you going to do?
            }
        }
    }

}
