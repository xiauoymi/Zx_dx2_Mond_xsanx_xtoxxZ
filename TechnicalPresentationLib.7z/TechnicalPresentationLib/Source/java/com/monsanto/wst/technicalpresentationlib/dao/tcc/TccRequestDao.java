package com.monsanto.wst.technicalpresentationlib.dao.tcc;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.*;
import com.monsanto.dbdataservices.PersistentStoreDBPreparedStatement;
import com.monsanto.wst.technicalpresentationlib.Servlet.TechnicalPresentationLibPersistentStoreFactory;
import com.monsanto.wst.technicalpresentationlib.constant.Constants;
import com.monsanto.wst.technicalpresentationlib.dao.RequestDao;
import com.monsanto.wst.technicalpresentationlib.dao.exception.ObjectNotFoundException;
import com.monsanto.wst.technicalpresentationlib.factory.SqlFactory;
import com.monsanto.wst.technicalpresentationlib.vo.AuditRequest;
import com.monsanto.wst.technicalpresentationlib.util.persistentstore.PersistentStoreUtils;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.AbstractLogging.LoggableError;

/**
 * Created by IntelliJ IDEA.
 * Date: May 13, 2005
 * Time: 8:49:56 AM
 * <p>
 * This is the TCC implementation of the request dao.
 * </p>
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class TccRequestDao implements RequestDao {

    /*
     * @see com.monsanto.wst.technicalpresentationlib.dao.RequestDao#addCustomer(com.monsanto.wst.technicalpresentationlib.vo.Request)
     */
    // @Override
    public Long addRequest(AuditRequest request) throws WrappingException {
        PersistentStore ps = TechnicalPresentationLibPersistentStoreFactory.getStore(Constants.APPLICATION_RESOURCE_BUNDLE_FILE);
        PersistentStore.registerInstance(ps);
        PersistentStoreConnection con = null;
        PersistentStoreResultSet rs = null;
        PersistentStoreDBPreparedStatement insert = null;
        Long generatedId = null;

        try {
            con = ps.connect();
            con.beginTransaction();
            String insertSql = SqlFactory.getStatement("addRequestStat");
            String nextSeqSql = SqlFactory.getStatement("queryNextSequence");

            rs = con.executeQuery(nextSeqSql);
            PersistentStoreResultSetSingleResult singleRs = rs.getSingleResult();
            generatedId = singleRs.getLONG(1);

            insert = (PersistentStoreDBPreparedStatement) con.prepareStatement(insertSql);
            insert.setParam(1, generatedId);
            insert.setParam(2, request.getCreator());
            insert.setParam(3, request.getDocumentId());
            insert.setParam(4, request.getAccessDate());
            insert.setParam(5, request.getUser());
            insert.setParam(6, request.getPresentationDate());
            insert.setParam(7, request.getPresentationDesc());
            insert.setParam(8, request.getPresentationCont());
            insert.setParam(9, request.getFname());
            insert.setParam(10, request.getFilename());
            insert.setParam(11, request.getAudience());

            insert.executeInsert();
            con.endTransaction();
        } catch (EmptyResultSetException e) {
            Logger.log(new LoggableError(e));
            PersistentStoreUtils.rollback(con);
            throw new IllegalStateException("Unable to get next sequence number.");
        } catch (WrappingException e) {
            Logger.log(new LoggableError(e.getNestedException()));
            PersistentStoreUtils.rollback(con);
            throw e;
        } finally {
            PersistentStoreUtils.close(insert);
            PersistentStoreUtils.close(con);
        }

        System.out.println("Generated ID is " + generatedId + " Database access was SUCCESSFUL");
        return generatedId;

    }

    /*
     * @see RequestDao#loadRequest(Long)
     */
    // @Override
    public AuditRequest loadRequest(Long requestId) throws WrappingException, ObjectNotFoundException {
        PersistentStore ps = TechnicalPresentationLibPersistentStoreFactory.getStore(Constants.APPLICATION_RESOURCE_BUNDLE_FILE);
        PersistentStore.registerInstance(ps);
        PersistentStoreConnection con = null;
        PersistentStoreDBPreparedStatement query = null;
        PersistentStoreResultSet rs = null;

        try {
            con = ps.connect();
            String queryStat = SqlFactory.getStatement("loadRequestStat");

            query = (PersistentStoreDBPreparedStatement) con.prepareStatement(queryStat);
            query.setParam(1, requestId);

            rs = query.executeQuery();

            AuditRequest request = new AuditRequest();
            request.setId(requestId);
            PersistentStoreResultSetSingleResult singleResult = rs.getSingleResult();

            request.setCreator(singleResult.getString("CREATOR_ID"));
            request.setDocumentId(singleResult.getString("DOC_ID"));
            request.setAccessDate(singleResult.getDate("ACCESS_DATE"));
            request.setUser(singleResult.getString("USER_ID"));
            request.setPresentationDate(singleResult.getDate("PRESENTATION_DATE"));
            request.setPresentationDesc(singleResult.getString("PRESENTATION_TYPE"));

            return request;
        } catch (EmptyResultSetException e) {
            Logger.log(new LoggableError(e));
            throw new ObjectNotFoundException("Unable to find request with id = '" + requestId + "'");
        } catch (WrappingException e) {
            Logger.log(new LoggableError(e.getNestedException()));
            throw e;
        } finally {
            PersistentStoreUtils.close(rs);
            PersistentStoreUtils.close(query);
            PersistentStoreUtils.close(con);
        }
    }

    /*
     * @see RequestDao#deleteRequest(Long)
     */
    // @Override
    public void deleteRequest(Long requestId) throws WrappingException {
        PersistentStore ps = TechnicalPresentationLibPersistentStoreFactory.getStore(Constants.APPLICATION_RESOURCE_BUNDLE_FILE);
        PersistentStore.registerInstance(ps);
        PersistentStoreConnection con = null;
        PersistentStoreDBPreparedStatement deleteStat = null;

        try {
            con = ps.connect();
            String deleteSql = SqlFactory.getStatement("deleteRequestStat");

            deleteStat = (PersistentStoreDBPreparedStatement) con.prepareStatement(deleteSql);
            deleteStat.setParam(1, requestId);
            deleteStat.executeDelete();
        } catch (WrappingException e) {
            Logger.log(new LoggableError(e));
            throw e;
        } finally {
            PersistentStoreUtils.rollback(con);
            PersistentStoreUtils.close(deleteStat);
            PersistentStoreUtils.close(con);
        }
    }

}
