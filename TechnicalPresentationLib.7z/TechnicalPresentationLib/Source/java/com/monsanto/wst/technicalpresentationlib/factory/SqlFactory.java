package com.monsanto.wst.technicalpresentationlib.factory;

import com.monsanto.AbstractLogging.LoggableError;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.XMLUtil.DOMUtil;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

/**
 * Created by IntelliJ IDEA.
 * Date: May 13, 2005
 * Time: 9:57:58 AM
 * <p>
 * This class is a factory for retrieving sql statements from an xml file.  It
 * parses the current database implementation of the sql xml file and caches the
 * values to be retrieved whenever requested.
 * </p>
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class SqlFactory {

    private static final String SQL_PROPERTIES = "com/monsanto/wst/technicalpresentationlib/resources/sql.properties";
    private static final String SQL_XML_PROPERTY = "sql";
    private static final String STATEMENT_TAG_NAME = "statement";
    private static final String ID_ATTRIBUTE_NAME = "id";
    private static Map statementMap = null;

    /**
     * This is a singleton for loading a map of the sql statements in the current
     * database implementation of the sql xml file.  It is a singleton, but it is
     * synchronized to make sure that the sql statements are only loaded once.  Any
     * attribute getters will check if the map is null and if it is call this method.
     * Since this method is synchronized it will wait for each thread until the thread is
     * completely finished executing it.  This method checks if the statement map is
     * null in case the current thread had to wait while the first thread loaded the
     * xml file, therefore a second load will not occur.
     *
     * @return Map - Representing an id to sql statement map.
     */
    private static synchronized Map getStatementMap() {
        if (statementMap == null) {
            try {
                ClassLoader classLoader = SqlFactory.class.getClassLoader();
                InputStream in = classLoader.getResourceAsStream(SQL_PROPERTIES);
                Properties props = new Properties();
                props.load(in);
                String sqlXmlResource = props.getProperty(SQL_XML_PROPERTY);
                InputStream xmlIn = classLoader.getResourceAsStream(sqlXmlResource);
                Document doc = DOMUtil.newDocument(xmlIn);
                parseStatementDoc(doc);
            } catch (Exception e) {
                Logger.log(new LoggableError(e));
                throw new IllegalStateException("Unable to retrieve sql xml resource.");
            }
        }

        return statementMap;
    }

    /**
     * This method parses the sql xml file and creates a map of the ids and statements.
     *
     * @param doc Object representing the xml file.
     * @return Map - Representing the id to sql statement map.
     */
    private static Map parseStatementDoc(Document doc) {
        try {
            NodeList statNodeList = doc.getElementsByTagName(STATEMENT_TAG_NAME);
            statementMap = new HashMap();

            for (int i = 0; i < statNodeList.getLength(); i++) {
                Element statElement = (Element) statNodeList.item(i);
                String attribute = statElement.getAttribute(ID_ATTRIBUTE_NAME);
                String value = statElement.getFirstChild().getNodeValue();
                statementMap.put(attribute, value);
            }

            return statementMap;
        } catch (Exception e) {
            Logger.log(new LoggableError(e));
            throw new IllegalStateException("Unable to parse sql xml file.");
        }
    }

    /**
     * This method returns a string representing the sql statement associated with
     * the attribute specified.
     *
     * @param id String representing the id of the sql statement defined in the
     *   current database implementation of the sql xml file.
     * @return String - Representing the sql statement.
     */
    public static String getStatement(String id) {
        if (statementMap == null) {
            getStatementMap();
        }

        return (String) statementMap.get(id);
    }

}
