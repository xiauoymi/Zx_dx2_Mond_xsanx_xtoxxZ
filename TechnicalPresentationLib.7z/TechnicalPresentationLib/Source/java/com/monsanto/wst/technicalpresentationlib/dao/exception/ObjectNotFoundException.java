package com.monsanto.wst.technicalpresentationlib.dao.exception;

/**
 * Created by IntelliJ IDEA.
 * Date: May 17, 2005
 * Time: 11:32:25 AM
 * <p>
 * This class is a customer exception that gets thrown if a dao is unable to retrieve an
 * object from the database.
 * </p>
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class ObjectNotFoundException extends Exception {

    /**
     * This constructor accepts a message.
     *
     * @param message String representing the message to the admin.
     */
    public ObjectNotFoundException(String message) {
        super(message);
    }

    /**
     * This constructor takes a throwable cause.
     *
     * @param t Throwable representing the cause of this exception.
     */
    public ObjectNotFoundException(Throwable t) {
        super(t);
    }

    /**
     * This constructor takes a message and a throwable cause.
     *
     * @param message String representing a message to the admin.
     * @param t Throwable representing the cause of this exception.
     */
    public ObjectNotFoundException(String message, Throwable t) {
        super(message, t);
    }

}
