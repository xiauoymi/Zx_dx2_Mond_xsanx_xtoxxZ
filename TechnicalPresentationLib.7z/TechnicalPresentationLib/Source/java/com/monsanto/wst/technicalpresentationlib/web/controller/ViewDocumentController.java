package com.monsanto.wst.technicalpresentationlib.web.controller;

import com.monsanto.AbstractLogging.LoggableError;
import com.monsanto.AbstractLogging.LoggableInfo;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.ServletFramework.UseCaseController;
import com.monsanto.wst.technicalpresentationlib.factory.ServiceFactory;
import com.monsanto.wst.technicalpresentationlib.service.DocumentService;
import com.monsanto.wst.technicalpresentationlib.service.exception.DocumentQueryException;
import com.monsanto.wst.technicalpresentationlib.vo.Request1;
import org.apache.commons.lang.StringUtils;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;


/**
 * Created by IntelliJ IDEA.
 * Date: May 17, 2005
 * Time: 9:40:54 AM
 * <p>
 * This class takes information passed in on the request and uses it to send audit
 * information to the database and write the requested document to the response.
 * </p>
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 *
 * @author rgeorge (Rijo George)
 * Date : June 15, 2005
 * Modified the class as per the chnages in requirements.
 */
public class ViewDocumentController implements UseCaseController {

    private static final String DATE_FORMAT = "MM/dd/yyyy";

    /*
     * @see UseCaseController#run(com.monsanto.ServletFramework.UCCHelper)
     */
    public void run(UCCHelper helper) throws IOException {
        // validate the request parameters passed in.
        System.out.println("Entered here");
        List errorList = validate(helper);
  // populate a request object with information passed in.
        Request1 request1 = formToRequest(helper, errorList);
        System.out.println("Request recvd is" + request1);
       DocumentService documentService = ServiceFactory.getDocumentService();

        // If there are validation errors execute the select document controller
        // and return the user to the calling page with a list of the errors.
        System.out.println(errorList.size());
        if (errorList.size() > 0) {
            helper.setRequestAttributeValue("errorList", errorList);
            SelectDocumentController selectController = new SelectDocumentController();
            selectController.run(helper);
            return;
        }
        else {

//   Load a list of all available documents and pass it to the current page.
        try {
            List docList = documentService.getDocumentList(request1.getPresentationDesc(),request1.getPresentationCont(),
                            request1.getLanguages(),request1.getUser(),request1.getPresentationDate(),request1.getAudience(),
                            request1.getHour(),request1.getMin(),request1.getAmpm(),request1.getTimezone());

            if (docList.size()==0){
                    errorList.add("There are no records that match your criteria");
                    helper.setRequestAttributeValue("errorList", errorList);
                    helper.forward("/WEB-INF/jsp/selectDocument.jsp");
            }else{
                    for(int i=0;i<docList.size();i++)
                    helper.setRequestAttributeValue("docList", docList);
                    helper.forward("/WEB-INF/jsp/selectDocument.jsp");
            }

         } catch (DocumentQueryException e) {
            // Log that there was an error and throw an illegal state exception
            // to send the user to the error page.
            // Check the web.xml file for the location of the error page.
            Logger.log(new LoggableError(e));
            throw new IllegalStateException("Unable to retrieve list of current documents.");
        }
        }
   }


    /**
     * This method takes the request parameters passed in and creates a request
     * object.
     *
     * @param helper UCCHelper object representing access to the http request and 
     *      response objects.
     * @param errorList List representing any validation errors that have occurred.
     * @return Request - Object representing the audit information.
     * @throws IOException - If unable to retrieve access the request object.
     */
    private Request1 formToRequest(UCCHelper helper, List errorList) throws IOException {
        Request1 request1 = new Request1();
        String date = helper.getRequestParameterValue("date");
        String hour = helper.getRequestParameterValue("hour");
        String minute = helper.getRequestParameterValue("minute");
        String ampm = helper.getRequestParameterValue("ampm");
        String timezone = helper.getRequestParameterValue("timezone");
        String presentationDesc = helper.getRequestParameterValue("presentationDesc");
        String userId = helper.getRequestParameterValue("pplName");
        String audience = helper.getRequestParameterValue("audience");
        String language = helper.getRequestParameterValue("languages");
        String presentationCont = helper.getRequestParameterValue("presentationCont");

        //String creator = helper.getAuthenticatedUserID();

        Calendar cal = Calendar.getInstance();
        SimpleDateFormat sdf = new SimpleDateFormat(DATE_FORMAT);


        // parse the date, time and timezone of the presentation and
        // set the presentation date on the request object.
        if (StringUtils.isNotEmpty(date) && StringUtils.isNotEmpty(ampm)) {
            try {
                cal.setTime(sdf.parse(date));
                cal.set(Calendar.HOUR, Integer.parseInt(hour));
                cal.set(Calendar.MINUTE, Integer.parseInt(minute));
                if ("AM".equalsIgnoreCase(ampm)) {
                    cal.set(Calendar.AM_PM, Calendar.AM);
                } else if ("PM".equalsIgnoreCase(ampm)) {
                    cal.set(Calendar.AM_PM, Calendar.PM);
                }
                request1.setDatedup(cal.getTime());
                //parseAndSetTimeZone(cal,timezone);
             } catch (ParseException e) {
                Logger.log(new LoggableInfo(e));
                errorList.add("The presentation date you specified is invalid.  " +
                        "Please provide the date in the form " + DATE_FORMAT.toUpperCase());
            } catch (NumberFormatException e) {
                Logger.log(new LoggableInfo(e));
                errorList.add("The presentation time you specified is not valid.  " +
                        "Please check and try again.");
            }
        }

        request1.setPresentationDesc(presentationDesc);
  //      request1.setCreator(creator);
        request1.setUser(userId);
        request1.setAudience(audience);
        request1.setLanguages(language);
        request1.setPresentationCont(presentationCont);
        request1.setAmpm(ampm);
        request1.setHour(hour);
        request1.setMin(minute);
        request1.setPresentationDate(date);
        request1.setTimezone(timezone);

        return request1;
    }

    /**
     * This method validates that all required fields were entered.
     *
     * @param helper UCCHelper object representing access to the http request and
     *      response objects.
     * @return List - Representing any validation errors.
     * @throws IOException - If there was a problem reading the http request object.
     */
    private List validate(UCCHelper helper) throws IOException {
        List errorList = new ArrayList();

        if (StringUtils.isEmpty(helper.getRequestParameterValue("pplName"))) {
            errorList.add("Please select the person who will be presenting.");
        }
        if (StringUtils.isEmpty(helper.getRequestParameterValue("date"))) {
            errorList.add("Please enter a presentation date.");
        }
        if (StringUtils.isEmpty(helper.getRequestParameterValue("hour"))) {
            errorList.add("Please select the hour.");
        }
        if (StringUtils.isEmpty(helper.getRequestParameterValue("minute"))) {
            errorList.add("{Please select the minutes.");
        }
        if (StringUtils.isEmpty(helper.getRequestParameterValue("ampm"))) {
            errorList.add("Please select either am or pm for the time.");
        }
        if (StringUtils.isEmpty(helper.getRequestParameterValue("timezone"))) {
            errorList.add("Please select a timezone.");
        }
        if (StringUtils.isEmpty(helper.getRequestParameterValue("presentationDesc"))) {
            errorList.add("Please select a presentation type.");
        }
        if (StringUtils.isEmpty(helper.getRequestParameterValue("audience"))) {
            errorList.add("Please select an Audience.");
        }
        if (StringUtils.isEmpty(helper.getRequestParameterValue("languages"))) {
            errorList.add("Please select a Langauge.");
        }
        

        return errorList;
    }

}
