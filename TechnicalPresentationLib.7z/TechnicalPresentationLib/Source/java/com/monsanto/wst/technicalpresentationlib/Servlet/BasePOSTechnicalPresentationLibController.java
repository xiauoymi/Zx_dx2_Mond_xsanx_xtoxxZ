package com.monsanto.wst.technicalpresentationlib.Servlet;

import com.monsanto.AbstractLogging.LoggableInfo;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.POSServlet.BasePOSController;
import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.security.*;
import com.monsanto.wst.technicalpresentationlib.Security.SecurityFactory;
import org.w3c.dom.Document;

/**
 * Filename:    $RCSfile: BasePOSTechnicalPresentationLibController.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: rgeorge $    	 On:	$Date: 2005-06-06 18:44:31 $
 * 
 * @author HZHANG3
 * @version $Revision: 1.3 $
 */

public abstract class BasePOSTechnicalPresentationLibController extends BasePOSController {
    public static final String SCHEMAS_DIR = I_SessionParams.sf_cstrXML_SCHEMAS_DIR;

    protected LoginBrief authorizeUser(UCCHelper helper, Document inputDocument) throws LogonFailedException, NoLogonInformationException {
    SecureUser secureUser = buildSecureUser(helper, inputDocument);
    SecurityGateKeeper gateKeeper = new SecurityGateKeeper();
    SecurityServer securityServer = SecurityFactory.buildSecurityServer(TechnicalPresentationLibServlet.s_cstrResourceBundle);
    LoginBrief retVal = makeLoginBrief(gateKeeper, secureUser, securityServer);
    Logger.log(new LoggableInfo("Logged on user: " + secureUser.userId()));
    return retVal;
  }

  protected LoginBrief makeLoginBrief(SecurityGateKeeper gateKeeper, SecureUser secureUser, SecurityServer securityServer) throws LogonFailedException {
    return gateKeeper.login(secureUser, SecurityFactory.getAppName(), securityServer);
  }
  
}
