package com.monsanto.wst.technicalpresentationlib.factory;

import com.monsanto.wst.technicalpresentationlib.service.RequestService;
import com.monsanto.wst.technicalpresentationlib.service.DocumentService;
import com.monsanto.AbstractLogging.LoggableError;
import com.monsanto.AbstractLogging.Logger;

import java.io.InputStream;
import java.util.Properties;

/**
 * Created by IntelliJ IDEA.
 * Date: May 16, 2005
 * Time: 5:13:03 PM
 * <p>
 * This class is a factory for the service implementations.  It contains getters that return
 * the actually implementation of each of the service interfaces.
 * </p>
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class ServiceFactory {

    private static final String SERVICE_PROPERTIES = "com/monsanto/wst/technicalpresentationlib/resources/service.properties";

    /**
     * This method returns the implementation of the request service.
     *
     * @return RequestService - Object representing the implementation.
     */
    public static RequestService getRequestService() {
        try {
            ClassLoader classLoader = ServiceFactory.class.getClassLoader();
            InputStream in = classLoader.getResourceAsStream(SERVICE_PROPERTIES);
            Properties props = new Properties();
            props.load(in);
            Class clazz = Class.forName(props.getProperty("requestService"));
            return (RequestService) clazz.newInstance();
        } catch (Exception e) {
            Logger.log(new LoggableError(e));
            throw new IllegalStateException("Unable to retrieve request service from properties file.");
        }
    }

    /**
     * This method returns the implementation of the document service.
     *
     * @return DocumentService - Object representing the implementation.
     */
    public static DocumentService getDocumentService() {
        try {
            ClassLoader classLoader = ServiceFactory.class.getClassLoader();
            InputStream in = classLoader.getResourceAsStream(SERVICE_PROPERTIES);
            Properties props = new Properties();
            props.load(in);
            Class clazz = Class.forName(props.getProperty("documentService"));
            return (DocumentService) clazz.newInstance();
        } catch (Exception e) {
            Logger.log(new LoggableError(e));
            throw new IllegalStateException("Unable to retrieve document service from properties file.");
        }
    }

}
