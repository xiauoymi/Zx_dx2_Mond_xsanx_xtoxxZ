package com.monsanto.wst.technicalpresentationlib.vo;

import java.util.Date;


/**
 * Created by IntelliJ IDEA.
 * Date: Jun 20, 2005
 * Time: 9:07:28 AM
 * This class contains the Audit information for the database
 * @author rgeorge (Rijo George)
 * @version 1.0
 */

public class AuditRequest {

    private Long id;
    private String creator;
    private String documentId;
    private Date accessDate;
    private String user;
    private Date presentationDate;
    private String presentationDesc;
    private String languages;
    private String fname;
    private String filename;
    private String presentationCont;
    private String audience;

    public String getFname() {
        return fname;
    }

    public void setFname(String fname) {
        this.fname = fname;
    }

    public String getFilename() {
        return filename;
    }

    public void setFilename(String filename) {
        this.filename = filename;
    }

    public String getPresentationCont() {
        return presentationCont;
    }

    public void setPresentationCont(String presentationCont) {
        this.presentationCont = presentationCont;
    }

    public String getLanguages() {
        return languages;
    }

    public void setLanguages(String languages) {
        this.languages = languages;
    }

    public String getAudience() {
        return audience;
    }

    public void setAudience(String audience) {
        this.audience = audience;
    }

   public Date getAccessDate() {
        return accessDate;
    }

    public void setAccessDate(Date accessDate) {
        this.accessDate = accessDate;
    }

    /**
     * This method returns the id for this request.
     *
     * @return Long - Representing the id.
     */
    public Long getId() {
        return this.id;
    }

    /**
     * This method sets the id for this request.
     *
     * @param id Long representing the id.
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * This method returns the id of the creator for this request.
     *
     * @return String - Representing the creator.
     */
    public String getCreator() {
        return this.creator;
    }

    /**
     * This method sets the id of the creator for this request.
     *
     * @param creator String representing the creator's id.
     */
    public void setCreator(String creator) {
        this.creator = creator;
    }

    /**
     * This method returns the id of the document being requested.
     *
     * @return String - Representing the document id.
     */
    public String getDocumentId() {
        return this.documentId;
    }

    /**
     * This method sets the id of the document being requested.
     *
     * @param documentId String representing the document id.
     */
    public void setDocumentId(String documentId) {
        this.documentId = documentId;
    }


    /**
     * This method returns the id of the user who will making the presentation.
     *
     * @return String - Representing the id of the user.
     */
    public String getUser() {
        return this.user;
    }

    /**
     * This method sets the id of the user who will be making the presentation.
     *
     * @param user String representing the id of the user.
     */
    public void setUser(String user) {
        this.user = user;
    }

    /**
     * This method returns the date in which this presentation will be presented.
     *
     * @return Date - Representing the presentation date.
     */
    public Date getPresentationDate() {
        return this.presentationDate;
    }

    /**
     * This method sets the date in which this presentation will be presented.
     *
     * @param presentationDate Date representing the presentation date.
     */
    public void setPresentationDate(Date presentationDate) {
        this.presentationDate = presentationDate;
    }

    /**
     * This method returns the description of this presentation.
     *
     * @return String - Representing the presentation description.
     */
    public String getPresentationDesc() {
        return this.presentationDesc;
    }

    /**
     * This method sets the description of this presentation.
     *
     * @param presentationDesc String representing the presentation description.
     */
    public void setPresentationDesc(String presentationDesc) {
        this.presentationDesc = presentationDesc;
    }

    /*
     * @see java.lang.Object#equals(java.lang.Object)
     */
    // @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof AuditRequest)) {
            return false;
        }

        final AuditRequest customer = (AuditRequest) o;

        if (customer.getDocumentId() != null && customer.getDocumentId().equals(this.documentId)){
            return true;
        }

        return false;
    }

    /*
     * @see java.lang.Object#hashCode()
     */
    // @Override
    public int hashCode() {
        int result;
        result = (creator != null ? creator.hashCode() : 0);
        result = 29 * result + (documentId != null ? documentId.hashCode() : 0);
        result = 29 * result + (accessDate != null ? accessDate.hashCode() : 0);
        return result;
    }

    /*
     * @see java.lang.Object#toString()
     */
    // @Override
    public String toString() {
        StringBuffer sb = new StringBuffer("Request:\n");

        sb.append("  id = '" + this.id + "'\n");
        sb.append("  creator = '" + this.creator + "'\n");
        sb.append("  documentId = '" + this.documentId + "'\n");
        sb.append("  accessDate = '" + this.accessDate + "'\n");
        sb.append("  user = '" + this.user + "'\n");
        sb.append("  presentationDate = '" + this.presentationDate + "'\n");
        sb.append("  presentationDesc = '" + this.presentationDesc + "'\n");
        sb.append("  languages = '" + this.languages + "'\n");
        sb.append("  audience ='" +this.audience + "'\n");
        sb.append("  presentationContent ='" +this.presentationCont + "'\n");

        return sb.toString();
    }
}


