package com.monsanto.wst.technicalpresentationlib.web.controller;

import com.monsanto.AbstractLogging.LoggableError;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.ServletFramework.UseCaseController;
import com.monsanto.wst.technicalpresentationlib.factory.ServiceFactory;
import com.monsanto.wst.technicalpresentationlib.service.DocumentService;
import com.monsanto.wst.technicalpresentationlib.service.exception.DocumentQueryException;

import javax.xml.parsers.ParserConfigurationException;
import java.io.IOException;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Jun 2, 2005
 * Time: 3:34:38 PM
 * To change this template use File | Settings | File Templates.
 */

//public class ContentRetrieveController implements UseCaseController {
//
//    /*
//     * @see UseCaseController#run(com.monsanto.ServletFramework.UCCHelper)
//     */
//    public void run(UCCHelper helper) throws IOException {
//        DocumentService documentService = ServiceFactory.getDocumentService();
//
//        org.w3c.dom.Document fileLister = null;
//        try {
//            fileLister = documentService.queryFilelister();
//        } catch (DocumentQueryException e) {
//            Logger.log(new LoggableError(e));
//           throw new IllegalStateException("Unable to Create a new Document");  //To change body of catch statement use File | Settings | File Templates.
//        }
//        String documentId = helper.getRequestParameterValue("documentId");
//            org.w3c.dom.Document contentDocument = null;
//        try
//        {
//            contentDocument = documentService.getcontentDocument(fileLister,documentId);
//        }
//        catch (ParserConfigurationException e){
//           Logger.log(new LoggableError(e));
//           throw new IllegalStateException("Unable to Create a new Document");
//        }
//
//        helper.setContentType("text/xml");
//        helper.writeXMLDocument(contentDocument);
//    }
//
//}
