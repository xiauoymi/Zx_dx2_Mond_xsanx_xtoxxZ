package com.monsanto.wst.technicalpresentationlib.factory;

import com.monsanto.AbstractLogging.LoggableError;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.wst.technicalpresentationlib.dao.RequestDao;

import java.io.InputStream;
import java.util.Properties;

/**
 * Created by IntelliJ IDEA.
 * Date: May 13, 2005
 * Time: 8:22:22 AM
 * <p>
 * This factory provides access to the current implementation of each of the dao objects.
 * </p>
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class DaoFactory {
    private static final String DAO_PROPERTIES = "com/monsanto/wst/technicalpresentationlib/resources/dao.properties";
    private static final String REQUEST_DAO_PROP = "requestDao";

    /**
     * This method returns a new instance of the current implementation of the request dao.
     *
     * @return RequestDao - Object representing the request dao.
     */
    public static RequestDao getRequestDao() {
        try {
            ClassLoader classLoader = DaoFactory.class.getClassLoader();
            InputStream in = classLoader.getResourceAsStream(DAO_PROPERTIES);
            Properties props = new Properties();
            props.load(in);
            Class clazz = Class.forName(props.getProperty(REQUEST_DAO_PROP));
            return (RequestDao) clazz.newInstance();
        } catch (Exception e) {
            Logger.log(new LoggableError(e));
            throw new IllegalStateException("Unable to instantiate request dao.");
        }
    }
}
