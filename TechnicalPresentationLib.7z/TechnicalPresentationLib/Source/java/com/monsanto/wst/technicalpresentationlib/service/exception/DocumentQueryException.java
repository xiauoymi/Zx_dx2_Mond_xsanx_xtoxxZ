package com.monsanto.wst.technicalpresentationlib.service.exception;

/**
 * Created by IntelliJ IDEA.
 * Date: May 16, 2005
 * Time: 8:45:46 AM
 * <p/>
 * TODO: Enter description for class.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class DocumentQueryException extends Exception {

    public DocumentQueryException(String message) {
        super(message);
    }

    public DocumentQueryException(Throwable t) {
        super(t);
    }

    public DocumentQueryException(String message, Throwable t) {
        super(message, t);
    }

}
