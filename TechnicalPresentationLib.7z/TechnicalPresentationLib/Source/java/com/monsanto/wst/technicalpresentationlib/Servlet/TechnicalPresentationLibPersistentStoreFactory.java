package com.monsanto.wst.technicalpresentationlib.Servlet;

import com.monsanto.AbstractLogging.Logger;
import com.monsanto.dataservices.PersistentStore;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dbdataservices.PersistentStoreOracleCachedType2;
import com.monsanto.dbdataservices.PersistentStoreOracleCachedType4;
import com.monsanto.dbdataservices.PersistentStoreOracleType4;

import java.util.ResourceBundle;

/**
 *
 * <p>Title: TechnicalPresentationLibPersistentStoreFactory</p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Monsanto</p>
 * @author Java Framework Code	Generator 2.1
 * @version $Id: TechnicalPresentationLibPersistentStoreFactory.java,v 1.7 2006-03-11 21:45:09 mecoru Exp $
 */
public class TechnicalPresentationLibPersistentStoreFactory
{
  /**
       * Returns a Persistent Store.
       *
       * @param cstrResourceBundleName The name of the resource bundle that points
       *                               to the correct database.
       * @return A PersistentStore object.
       * @throws WrappingException
       */
      public static PersistentStore getStore(String cstrResourceBundleName) throws WrappingException {
        Logger.traceEntry();
        ResourceBundle bundle = ResourceBundle.getBundle(cstrResourceBundleName);
        //PersistentStore RetVal = new PersistentStoreOracleCachedType2(bundle);
        PersistentStore RetVal = new PersistentStoreOracleType4("TECH_PLIB_USER","TECH_PLIB_USER_123","comgend",1521,"dev01.monsanto.com");
        //PersistentStore RetVal = new PersistentStoreOracleType4(bundle);
        return (PersistentStore) Logger.traceExit(RetVal);
      }
  }
