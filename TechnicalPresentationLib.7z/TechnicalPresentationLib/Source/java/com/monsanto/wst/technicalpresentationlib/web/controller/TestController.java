package com.monsanto.wst.technicalpresentationlib.web.controller;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.ServletFramework.UseCaseController;

import java.io.IOException;

/**
 * Created by IntelliJ IDEA.
 * Date: May 12, 2005
 * Time: 9:51:08 AM
 * <p/>
 * TODO: Enter description for class.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class TestController implements UseCaseController {

    public void run(UCCHelper helper) throws IOException {
        helper.forward("/WEB-INF/jsp/test/test.jsp");
    }

}
