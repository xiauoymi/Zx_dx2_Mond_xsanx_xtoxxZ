package com.monsanto.wst.technicalpresentationlib.sdo;




/**
 * Created by IntelliJ IDEA.
 * Date: May 16, 2005
 * Time: 8:49:47 AM
 * <p/>
 * TODO: Enter description for class.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 * @author rgeorge (Rijo George) - updated
 */
public class Document {

    private String id;
    private String name;
    private String fileName;
    private byte[] fileStream;
    private String presentationDesc;
    private String presentationCont;
    private String desciption;
    private String author;
    private String size;
    private String version;
    private String modifydate;
    private String keywords;
    private String mimeType;
    private String uname;
    private String presdate;
    private String audience;
    private String languages;

    private String hours;
    private String mins;
    private String ampm;

    private String timezone;

    public String getUname() {
        return uname;
    }

    public void setUname(String uname) {
        this.uname = uname;
    }

    public String getAudience() {
        return audience;
    }

    public void setAudience(String audience) {
        this.audience = audience;
    }


    public String getLanguages() {
        return languages;
    }

    public void setLanguages(String languages) {
        this.languages = languages;
    }

    public String getPresentationCont() {
        return presentationCont;
    }

    public void setPresentationCont(String presentationCont) {
        this.presentationCont = presentationCont;
    }

    public String getPresentationDesc() {
        return presentationDesc;
    }

    public void setPresentationDesc(String presentationDesc) {
        this.presentationDesc = presentationDesc;
    }

    public String getName() {
        return this.name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getFileName() {
        return this.fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public String getId() {
        return this.id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public byte[] getFileStream() {
        return this.fileStream;
    }

    public void setFileStream(byte[] fileStream) {
        this.fileStream = fileStream;
    }

    public String getMimeType() {
        return this.mimeType;
    }

    public void setMimeType(String mimeType) {
        this.mimeType = mimeType;
    }

    public String getPresdate() {
        return presdate;
    }

    public void setPresdate(String presdate) {
        this.presdate = presdate;
    }

    public String getHours() {
        return hours;
    }

    public void setHours(String hours) {
        this.hours = hours;
    }

    public String getMins() {
        return mins;
    }

    public void setMins(String mins) {
        this.mins = mins;
    }

    public String getAmpm() {
        return ampm;
    }

    public void setAmpm(String ampm) {
        this.ampm = ampm;
    }

    public String getDesciption() {
        return desciption;
    }

    public void setDesciption(String desciption) {
        this.desciption = desciption;
    }

    public String getTimezone() {
        return timezone;
    }

    public void setTimezone(String timezone) {
        this.timezone = timezone;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public String getSize() {
        return size;
    }

    public void setSize(String size) {
        this.size = size;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public String getModifydate() {
        return modifydate;
    }

    public void setModifydate(String modifydate) {
        this.modifydate = modifydate;
    }

    public String getKeywords() {
        return keywords;
    }

    public void setKeywords(String keywords) {
        this.keywords = keywords;
    }

    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Document)) return false;

        final Document document = (Document) o;
        if(
                ( (presentationDesc!= null) && (presentationDesc.equals(document.presentationDesc))) &&
                ( (languages != null) && (languages.equalsIgnoreCase(document.languages)) ) &&
                ( (presentationCont !=null) && (presentationCont.equals(document.presentationCont)))
          ){
            return true;
            }
            return false;
        }


    public boolean equals1(Object o) {
        if (this == o) return true;
        if (!(o instanceof Document)) return false;

        final Document document = (Document) o;

        if( ( (presentationDesc!= null) && (presentationDesc.equals(document.presentationDesc))) &&
            ( (languages != null) && (languages.equalsIgnoreCase(document.languages)) ) ){
            return true;
            }
            return false;
        }

    public boolean equals2(Object o) {
        if (this == o) return true;
        if (!(o instanceof Document)) return false;

        final Document document = (Document) o;

        if (
             (id != null ? !id.equals(document.id) : document.id != null)
        )
            return false;

       return true;
    }

    public int hashCode() {
        return (id != null ? id.hashCode() : 0);
    }

    public String toString() {
        StringBuffer sb = new StringBuffer("Document:\n");

        sb.append("  id = '" + this.id + "'\n");
        sb.append("  name = '" + this.name + "'\n");
        sb.append("  fileName = '" + this.fileName + "'\n");
        sb.append("  mimeType = '" + this.mimeType + "'\n");
        sb.append("  language ='" + this.languages + "'\n");
        sb.append("  content ='" + this.presentationCont + "'\n");
        sb.append("  type ='" + this.presentationDesc + "'\n");

        return sb.toString();
    }

}
