package com.monsanto.wst.technicalpresentationlib.vo;

import java.util.Date;


/**
 * Created by IntelliJ IDEA.
 * User: Rijo George
 * Date: Jun 11, 2005
 * Time: 5:32:19 PM
 * This class is a dummy version of the AuditRequest class to check for errors entered
 * on the page.
 * @author rgeorge (Rijo George)
 * @version 1.0
 */
public class Request1 {
    private Long id;
    private String documentId;
    private String user;
    private String presentationDate;
    private Date datedup;
    private String ampm;
    private String hour;
    private String min;
    private String timezone;
    private String presentationDesc;
    private String languages;
    private String audience;
    private String presentationCont;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getDocumentId() {
        return documentId;
    }

    public void setDocumentId(String documentId) {
        this.documentId = documentId;
    }

    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }

    public String getPresentationDate() {
        return presentationDate;
    }

    public void setPresentationDate(String presentationDate) {
        this.presentationDate = presentationDate;
    }

    public String getAmpm() {
        return ampm;
    }

    public void setAmpm(String ampm) {
        this.ampm = ampm;
    }

    public String getHour() {
        return hour;
    }

    public void setHour(String hour) {
        this.hour = hour;
    }

    public String getMin() {
        return min;
    }

    public void setMin(String min) {
        this.min = min;
    }

    public String getTimezone() {
        return timezone;
    }

    public void setTimezone(String timezone) {
        this.timezone = timezone;
    }

    public String getPresentationDesc() {
        return presentationDesc;
    }

    public void setPresentationDesc(String presentationDesc) {
        this.presentationDesc = presentationDesc;
    }

    public String getLanguages() {
        return languages;
    }

    public void setLanguages(String languages) {
        this.languages = languages;
    }

    public Date getDatedup() {
        return datedup;
    }

    public void setDatedup(Date datedup) {
        this.datedup = datedup;
    }

    public String getAudience() {
        return audience;
    }

    public void setAudience(String audience) {
        this.audience = audience;
    }

    public String getPresentationCont() {
        return presentationCont;
    }

    public void setPresentationCont(String presentationCont) {
        this.presentationCont = presentationCont;
    }

}
