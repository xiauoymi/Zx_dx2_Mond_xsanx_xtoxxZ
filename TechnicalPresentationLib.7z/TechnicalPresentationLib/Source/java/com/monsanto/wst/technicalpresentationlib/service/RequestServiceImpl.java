package com.monsanto.wst.technicalpresentationlib.service;

import com.monsanto.wst.technicalpresentationlib.vo.AuditRequest;
import com.monsanto.wst.technicalpresentationlib.factory.DaoFactory;
import com.monsanto.wst.technicalpresentationlib.dao.RequestDao;
import com.monsanto.Util.Exceptions.WrappingException;

/**
 * Created by IntelliJ IDEA.
 * Date: May 16, 2005
 * Time: 5:10:45 PM
 * <p>
 * This class is the implementation of the request service interface.
 * </p>
 * @author njminsh (Nate Minshew) - updated by
 * @version 1.0
 * @since 1.0
 *
 * @author rgeorge (Rijo George)
 * Modified the addRequest method.
 * Date : June 20, 2005
 */
public class RequestServiceImpl implements RequestService {

    /**
     * This method adds a request object to the database.
     *
     * @param request Request object representing the audit information.
     * @return Long - Representing the generated id for this request.
     * @throws WrappingException - If there is a problem adding the request
     *   to the database.
     */
    public Long addRequest(AuditRequest request) throws WrappingException {
        RequestDao requestDao = DaoFactory.getRequestDao();
        return requestDao.addRequest(request);
    }

}
