package com.monsanto.wst.technicalpresentationlib.web.controller;

import com.monsanto.ServletFramework.UseCaseController;
import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.wst.technicalpresentationlib.service.DocumentService;
import com.monsanto.wst.technicalpresentationlib.service.exception.DocumentQueryException;
import com.monsanto.wst.technicalpresentationlib.factory.ServiceFactory;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.AbstractLogging.LoggableError;

import java.io.IOException;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * Date: May 17, 2005
 * Time: 8:06:23 AM
 * <p>
 * This class retrieves a list of all available documents and passes it to the
 * current page.
 * </p>
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class SelectDocumentController implements UseCaseController {

    /*
     * @see UseCaseController#run(com.monsanto.ServletFramework.UCCHelper)
     */
    public void run(UCCHelper helper) throws IOException {
//        DocumentService documentService = ServiceFactory.getDocumentService();
//
//        // Load a list of all available documents and pass it to the current page.
//        try {
//            List docList = documentService.getDocumentList();
//            helper.setRequestAttributeValue("docList", docList);
//        } catch (DocumentQueryException e) {
//            // Log that there was an error and throw an illegal state exception
//            // to send the user to the error page.
//            // Check the web.xml file for the location of the error page.
//            Logger.log(new LoggableError(e));
//            throw new IllegalStateException("Unable to retrieve list of current documents.");
//        }

        // forward on to the select document jsp.
        helper.forward("/WEB-INF/jsp/selectDocument.jsp");
       // helper.getClientFiles();
    }

}
