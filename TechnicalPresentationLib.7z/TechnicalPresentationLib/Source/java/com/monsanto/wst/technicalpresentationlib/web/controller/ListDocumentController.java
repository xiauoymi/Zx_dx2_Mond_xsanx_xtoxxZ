//package com.monsanto.wst.technicalpresentationlib.web.controller;
//
//import com.monsanto.AbstractLogging.LoggableError;
//import com.monsanto.AbstractLogging.Logger;
//import com.monsanto.ServletFramework.UCCHelper;
//import com.monsanto.ServletFramework.UseCaseController;
//import com.monsanto.wst.technicalpresentationlib.factory.ServiceFactory;
//import com.monsanto.wst.technicalpresentationlib.service.DocumentService;
//import com.monsanto.wst.technicalpresentationlib.service.exception.DocumentQueryException;
//import com.monsanto.wst.technicalpresentationlib.vo.Request1;
//
//import java.io.IOException;
//import java.util.List;
//import java.util.ArrayList;
//
///**
// * Created by IntelliJ IDEA.
// * Date: Jun 10, 2005
// * Time: 10:52:10 AM
// * @author rgeorge (Rijo George)
// * @version 1.0
// * This class retrieves the list of documents matching the user requirements and forwards the
// * data to the page to be displayed
// */
//
//public class ListDocumentController implements UseCaseController{
//
//    public void run(UCCHelper helper) throws IOException {
//
//        Request1 request = new Request1();
//        DocumentService documentService = ServiceFactory.getDocumentService();
//
//        try {
//             List docList = documentService.getDocumentList(request.getPresentationDesc(),request.getPresentationCont(),
//                            request.getLanguages(),request.getUser(),request.getPresentationDate(),request.getAudience(),
//                            request.getHour(),request.getMin(),request.getAmpm(),request.getTimezone());
//
//            System.out.println("List Size is " + docList.size());
//
//            if (docList.size()!=0){
//                for(int i=0;i<docList.size();i++)
//                helper.setRequestAttributeValue("docList", docList);
//            }else{
//                    List errorList = new ArrayList();
//                    errorList.add("There are no records that match your criteria");
//                    helper.setRequestAttributeValue("errorList", errorList);
//                    helper.forward("/WEB-INF/jsp/selectDocument.jsp");
//                }
//
//            //helper.forward("/WEB-INF/jsp/selectDocument.jsp");
//        } catch (DocumentQueryException e) {
//            // Log that there was an error and throw an illegal state exception
//            // to send the user to the error page.
//            // Check the web.xml file for the location of the error page.
//            Logger.log(new LoggableError(e));
//            throw new IllegalStateException("Unable to retrieve list of current documents.");
//        }
//    }
//}
//
