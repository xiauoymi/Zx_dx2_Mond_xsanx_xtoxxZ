package com.monsanto.wst.technicalpresentationlib.service.filelister;

import com.monsanto.AbstractLogging.LoggableError;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.wst.technicalpresentationlib.constant.Constants;
import com.monsanto.wst.technicalpresentationlib.sdo.Document;
import com.monsanto.wst.technicalpresentationlib.service.DocumentService;
import com.monsanto.wst.technicalpresentationlib.service.exception.DocumentAccessException;
import com.monsanto.wst.technicalpresentationlib.service.exception.DocumentQueryException;
import org.apache.commons.lang.StringUtils;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;


/**
 * Created by IntelliJ IDEA.
 * Date: May 10, 2005
 * Time: 9:03:01 AM
 * <p>
 * This class is the filelister implmentation of the document service.
 * </p>
 * @author njminsh (Nathan Minschew)
 * @version 1.0
 * @since 1.0
 *
 * @author rgeorge (Rijo George)
 * Modified methods getDocumentList, parseFilelister, parseDocumentNode and findDocumentInfo
 * Add new methods getContentDocument(not used now), requestDocument and parseDocumentNodeTotal
 * Date : June 20, 2005
 */
public class FilelisterDocumentService implements DocumentService {

    private static final String FILELISTER_PROPERTIES = "com/monsanto/wst/technicalpresentationlib/resources/filelister.properties";
    private static final String FILELISTER_URL_PROPERTY = "baseUrl";
    private static final String FILELISTER_NAME_PROPERTY = "filelisterName";


    /*
     * @see com.monsanto.wst.technicalpresentationlib.service.DocumentService#getDocumentList()
     */
        public List getDocumentList(String presentationDesc, String presentationCont,
                                    String language, String uname, String presdate,
                                    String audience, String hours, String mins, String ampm, String timezone) throws DocumentQueryException {
        org.w3c.dom.Document responseXmlDoc = queryFilelister();
        return parseFilelister(responseXmlDoc,presentationDesc,presentationCont,language,
                uname,presdate,audience,hours,mins,ampm,timezone);
    }


    /*
     * @see com.monsanto.wst.technicalpresentationlib.service.DocumentService#retrieveDocument(java.lang.String)
     */
    public Document retrieveDocument(String documentId) throws DocumentQueryException, DocumentAccessException {
        org.w3c.dom.Document responseXmlDoc = queryFilelister();
        Document result = findDocumentInfo(responseXmlDoc, documentId);

        try {
            String documentUrl = getDocumentUrl(result.getFileName());
            URL url = new URL(documentUrl);

            System.out.println("encoded url = '" + documentUrl + "'");

            byte[] fileStream = requestDocument(url);
            result.setFileStream(fileStream);

        } catch (Exception e) {
            Logger.log(new LoggableError(e));
            throw new DocumentAccessException("Incorrect url specified.");
        }

        return result;
    }

    /**
     * This method queryies the filelister web server for the filelister info file.
     *
     * @return org.w3c.dom.Document - Representing the filelister xml info file.
     * @throws DocumentQueryException - If unable to query for filelister.
     */
    public org.w3c.dom.Document queryFilelister() throws DocumentQueryException {
        try {
            URL url = new URL(getFilelisterUrl());
            HttpURLConnection con = (HttpURLConnection) url.openConnection();
            con.setUseCaches(false);
            InputStream response = con.getInputStream();
            return DOMUtil.newDocument(response);
        } catch (Exception e) {
            Logger.log(new LoggableError(e));
            throw new DocumentQueryException("Unable to retrieve document list.");
        }
    }

    /**
     * This method request the document at the specified url and returns the document in
     * byte[] format.
     *
     * @param url Object representing the url.
     * @return byte[] - Representing the document.
     * @throws com.monsanto.wst.technicalpresentationlib.service.exception.DocumentAccessException - If unable to retrieve document.
     */
    private byte[] requestDocument(URL url) throws DocumentAccessException {
        try {

            //** explicitly closing the connection which may have been open
            HttpURLConnection con = (HttpURLConnection) url.openConnection();
            con.disconnect();

            //** opening a new connection to retrieve the document
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            byte[] stream = new byte[conn.getContentLength()];
            InputStream in = null;
            System.out.println("Stream Length : " + stream.length);
            in = con.getInputStream();

            int streamLength = stream.length;
            int start = 0;
            int availableBytes = in.available();
            int marker = in.available();

            
            if(marker >= streamLength){ //**Small size files...
                in.read(stream);
            }
            else{
                    byte[] temp1 = new byte[availableBytes];   //** creating a temporary byte array
                    in.read(temp1);

                    for(int i = 0; i < temp1.length; i++){
                        System.out.print(temp1[i]);
                    }

                    for(int i = 0; i < temp1.length; i++){
                        stream[i] = temp1[i];
                    }
            }

            /**using marker to break the entire stream into smaller parts
             * and writing them to a temporary stream [temp1.]
             */

            while(marker < streamLength) {   //**Large size files...
                con.getInputStream().mark(marker);
                in = con.getInputStream();

                start = marker;

                if((marker + availableBytes) <= streamLength){
                marker += availableBytes;
            }
            else{
                marker = streamLength;
            }
                System.out.println("Marker = " + marker);
                byte[] temp = new byte[availableBytes];
                in.read(temp);
                for(int i = 0; i < temp.length; i++){
                    System.out.print(temp[i]);
                }

                    // writing from the temporary stream into the document stream
                int idx = 0;
                for(int i = start; i < marker; i++){
                    stream[i] = temp[idx];
                    idx++;
                }
            }

            //printing out the stream - this also adds some delay to the process
            for(int i=0;i<stream.length;i++){
                System.out.print(stream[i]);
            }

            return stream;

        } catch (Exception e) {
            Logger.log(new LoggableError(e));
            throw new DocumentAccessException("Unable to retrieve document at location: '" + url.getPath() + "'");
        }
    }


    /**
     * This method returns the url of the filelister info file.
     *
     * @return String - Representing the url of the filelister info file.
     */
    private String getFilelisterUrl() {
        Properties props = loadFilelisterProperties();
        return props.getProperty(FILELISTER_URL_PROPERTY) + props.getProperty(FILELISTER_NAME_PROPERTY);
    }

    /**
     * This method returns the url of the specified document.
     *
     * @param documentName String representing the document name.
     * @return String - Representing the url of the document.
     */
    private String getDocumentUrl(String documentName) {
        Properties props = loadFilelisterProperties();
        return props.getProperty(FILELISTER_URL_PROPERTY) + StringUtils.replace(documentName," ","%20");
    }

    /**
     * This method loads a properties object with the values of the filelister properties file.
     *
     * @return Properties - Object representing the filelister properties file.
     */
    private Properties loadFilelisterProperties() {
        try {
            ClassLoader classLoader = FilelisterDocumentService.class.getClassLoader();
            InputStream in = classLoader.getResourceAsStream(FILELISTER_PROPERTIES);
            Properties props = new Properties();
            props.load(in);
            return props;
        } catch (Exception e) {
            Logger.log(new LoggableError(e));
            throw new IllegalStateException("Unable to open filelister properties.");
        }
    }

    /**
     * This method parses the filelister info file and returns the information in a list of
     * document objects.
     *
     * @param xmlResponse Object representing the filelister info file.
     * @return List - Representing the documents.
     */
    private List parseFilelister(org.w3c.dom.Document xmlResponse,String presentationDesc, 
                                 String presentationCont, String language, String uname, 
                                 String presdate, String audience, String hours, String mins, String ampm, String timezone) {

        NodeList documentNodeList = xmlResponse.getElementsByTagName("document");
        List documentList = new ArrayList();
        Document comparequals = new Document();
        
        comparequals.setPresentationDesc(presentationDesc);
        comparequals.setLanguages(language);
        comparequals.setUname(uname);
        comparequals.setPresdate(presdate);
        comparequals.setAudience(audience);
        comparequals.setHours(hours);
        comparequals.setMins(mins);
        comparequals.setAmpm(ampm);
        comparequals.setTimezone(timezone);

        if (presentationCont!=null) {
            comparequals.setPresentationCont(presentationCont);
            for (int i = 0; documentNodeList != null && i < documentNodeList.getLength(); i++) {
                Node documentNode = documentNodeList.item(i);
                Document doc = parseDocumentNodetotal(documentNode,presentationDesc,
                        presentationCont,language,uname,presdate,audience,hours,mins,ampm,timezone);
                if (doc != null && doc.equals(comparequals)) {
                    documentList.add(doc);
//                    System.out.print("Document Returned Is " +doc);
                }
            }
        }
        else{
            for (int i = 0; documentNodeList != null && i < documentNodeList.getLength(); i++) {
                Node documentNode = documentNodeList.item(i);
                Document doc = parseDocumentNodetotal(documentNode,presentationDesc,
                        presentationCont,language,uname,presdate,audience,hours,mins,ampm,timezone);
                if (doc != null && doc.equals1(comparequals)) {
                    documentList.add(doc);
//                    System.out.print("Document Returned Is " +doc);
                }
            }

        }
    return documentList;
    }

   /**
     * This method retrieves the fileLister.xml values based on the parameters
    * specified. Returns a Document containing the values retrieved.
    *
    * @param documentNode
    * @param presentationDesc
    * @param presentationCont
    * @param language
    * @param uname
    * @param presdate
    * @param audience
    * @param hours
    * @param mins
    * @param ampm
    * @return Document
    */
    private Document parseDocumentNodetotal(Node documentNode, String presentationDesc,
                                            String presentationCont, String language, String uname,
                                            String presdate, String audience, String hours, String mins,
                                            String ampm, String timezone) {
        NodeList attributesNodeList = documentNode.getChildNodes();
        Document doc = new Document();
        doc.setUname(uname);
        doc.setAudience(audience);
        doc.setPresdate(presdate);
        doc.setHours(hours);
        doc.setMins(mins);
        doc.setAmpm(ampm);
        doc.setTimezone(timezone);
        boolean b;

        for (int k = 0; attributesNodeList != null && k < attributesNodeList.getLength(); k++) {
            Node attributesNode = attributesNodeList.item(k);
            NodeList attributeNodeList = attributesNode.getChildNodes();

            for (int j = 0; attributeNodeList != null && j < attributeNodeList.getLength(); j++) {
                Node attributeNode = attributeNodeList.item(j);

                if (attributeNode instanceof Element) {
                    Element attributeElement = (Element) attributeNode;
                    int colId = Integer.parseInt(attributeElement.getAttribute("colID"));

                    if (colId == 9){
                       NodeList valueElementList = attributeElement.getChildNodes();
                        for (int l = 0; valueElementList != null && l < valueElementList.getLength(); l++) {
                            Node valueNode = valueElementList.item(l);
                            if (valueNode instanceof Element) {
                                Element valueElement = (Element) valueNode;
                                if (valueElement.hasChildNodes()){
                                    String desc = valueElement.getFirstChild().getNodeValue();
                                    System.out.println("Returned Type Is "+desc);
                                    if (desc != null && desc.equalsIgnoreCase(presentationDesc)){
                                        b=true;
                                        if (b) doc.setPresentationDesc(desc);
                                    }

                                }
                            }
                        }
                    }else
                    if (colId == 10){
                        NodeList valueElementList = attributeElement.getChildNodes();
                        for (int l = 0; valueElementList != null && l < valueElementList.getLength(); l++) {
                            Node valueNode = valueElementList.item(l);
                            if (valueNode instanceof Element) {
                                Element valueElement = (Element) valueNode;
                                if (valueElement.hasChildNodes()){
                                    String content = valueElement.getFirstChild().getNodeValue();
                                    System.out.println("Returned Content Is "+content);
                                    if (content != null ) { 
//                                        && content.equalsIgnoreCase(presentationCont)){
                                        doc.setPresentationCont(content);
                                    }
                                }
                            }
                        }
                    }else
                    if (colId == 11){
                        NodeList valueElementList = attributeElement.getChildNodes();
                        for (int l = 0; valueElementList != null && l < valueElementList.getLength(); l++) {
                            Node valueNode = valueElementList.item(l);
                            if (valueNode instanceof Element) {
                                Element valueElement = (Element) valueNode;
                                if (valueElement.hasChildNodes()){
                                    String lang = valueElement.getFirstChild().getNodeValue();
                                    System.out.println("Returned language Is "+lang);
                                    if (lang != null && lang.equalsIgnoreCase(language)){
                                        b=true;
                                        if (b) doc.setLanguages(lang);
                                    }
                                }
                            }
                        }
                    }else
                    if (colId == 2) {
                        NodeList valueElementList = attributeElement.getChildNodes();
                        for (int l = 0; valueElementList != null && l < valueElementList.getLength(); l++) {
                            Node valueNode = valueElementList.item(l);
                            if (valueNode instanceof Element) {
                                Element valueElement = (Element) valueNode;
                                if (valueElement.hasChildNodes()){
                                    String id = valueElement.getFirstChild().getNodeValue();
                                    System.out.println("Returned ID Is " +id);
                                    doc.setId(id);
                                }
                            }
                        }
                    } else
                    if (colId == 0) {
                        NodeList valueElementList = attributeElement.getChildNodes();
                        for (int l = 0; valueElementList != null && l < valueElementList.getLength(); l++) {
                            Node valueNode = valueElementList.item(l);
                            if (valueNode instanceof Element) {
                                Element valueElement = (Element) valueNode;
                                if ("value".equals(valueElement.getNodeName())) {
                                    String docName = valueElement.getFirstChild().getNodeValue();
                                    System.out.println("Returned Name Is " +docName);
                                    doc.setName(docName);
                            } else if ("link".equals(valueElement.getNodeName())) {
                                    String fileName = valueElement.getFirstChild().getNodeValue();
                                    System.out.println("Returned FileName Is " +fileName);
                                    doc.setFileName(fileName);
                            }
                            }
                        }
                    }
                    else if (colId == 8) {
                    NodeList valueElementList = attributeElement.getChildNodes();
                        for (int l = 0; valueElementList != null && l < valueElementList.getLength(); l++) {
                            Node valueNode = valueElementList.item(l);
                            if (valueNode instanceof Element) {
                                Element valueElement = (Element) valueNode;
                                if (valueElement.hasChildNodes()){
                                    String desc = valueElement.getFirstChild().getNodeValue();
                                    doc.setDesciption(desc);
                                }
                            }
                        }
                    }
                    else
                    if (colId == 3) {
                        NodeList valueElementList = attributeElement.getChildNodes();
                        for (int l = 0; valueElementList != null && l < valueElementList.getLength(); l++) {
                            Node valueNode = valueElementList.item(l);
                            if (valueNode instanceof Element) {
                                Element valueElement = (Element) valueNode;
                                if (valueElement.hasChildNodes()){
                                    String keyword = valueElement.getFirstChild().getNodeValue();
                                    System.out.println("Returned Keywords are " +keyword);
                                    doc.setKeywords(keyword);
                                }
                            }
                        }
                    }
                    else
                    if (colId == 4) {
                        NodeList valueElementList = attributeElement.getChildNodes();
                        for (int l = 0; valueElementList != null && l < valueElementList.getLength(); l++) {
                            Node valueNode = valueElementList.item(l);
                            if (valueNode instanceof Element) {
                                Element valueElement = (Element) valueNode;
                                if (valueElement.hasChildNodes()){
                                    String author = valueElement.getFirstChild().getNodeValue();
                                    System.out.println("Returned Author Is " +author);
                                    doc.setAuthor(author);
                                }
                            }
                        }
                    }
                    else
                    if (colId == 5) {
                        NodeList valueElementList = attributeElement.getChildNodes();
                        for (int l = 0; valueElementList != null && l < valueElementList.getLength(); l++) {
                            Node valueNode = valueElementList.item(l);
                            if (valueNode instanceof Element) {
                                Element valueElement = (Element) valueNode;
                                if (valueElement.hasChildNodes()){
                                    String size = valueElement.getFirstChild().getNodeValue();
                                    System.out.println("Returned Size Is " +size);
                                    doc.setSize(size);
                                }
                            }
                        }
                    }
                    else
                    if (colId == 6) {
                        NodeList valueElementList = attributeElement.getChildNodes();
                        for (int l = 0; valueElementList != null && l < valueElementList.getLength(); l++) {
                            Node valueNode = valueElementList.item(l);
                            if (valueNode instanceof Element) {
                                Element valueElement = (Element) valueNode;
                                if (valueElement.hasChildNodes()){
                                    String version = valueElement.getFirstChild().getNodeValue();
                                    System.out.println("Returned Version Is " +version);
                                    doc.setVersion(version);
                                }
                            }
                        }
                    }
                    else
                    if (colId == 7) {
                        NodeList valueElementList = attributeElement.getChildNodes();
                        for (int l = 0; valueElementList != null && l < valueElementList.getLength(); l++) {
                            Node valueNode = valueElementList.item(l);
                            if (valueNode instanceof Element) {
                                Element valueElement = (Element) valueNode;
                                if (valueElement.hasChildNodes()){
                                    String modifydate = valueElement.getFirstChild().getNodeValue();
                                    System.out.println("Returned Modify Date Is " +modifydate);
                                    doc.setModifydate(modifydate);
                                }
                            }
                        }
                    }
                }
            }
        }
        doc.setMimeType(Constants.POWER_POINT_MIME_TYPE);
        return doc;
    }


    /**
     * This method retrieves the document info for the specified document.
     *
     * @param xmlResponse Object representing the filelister info file.
     * @param documentId String representing the id of the document info requested.
     * @return Document - Object representing the requested document.
     */
    private Document findDocumentInfo(org.w3c.dom.Document xmlResponse, String documentId) {
        NodeList documentNodeList = xmlResponse.getElementsByTagName("document");
        Document comparator = new Document();
        comparator.setId(documentId);

        for (int i = 0; documentNodeList != null && i < documentNodeList.getLength(); i++) {
            Node documentNode = documentNodeList.item(i);
            Document doc = parseDocumentNode(documentNode);

            if (doc != null && doc.equals2(comparator)) {
                return doc;
            }
        }

        return null;
    }

    /**
     * This method parses the specified document node and creates a document object with information
     * obtained.
     *
     * @param documentNode Object representing the xml document node.
     * @return Document - Object representing the document information.
     */
    private Document parseDocumentNode(Node documentNode) {
        NodeList attributesNodeList = documentNode.getChildNodes();
        Document doc = new Document();

        for (int k = 0; attributesNodeList != null && k < attributesNodeList.getLength(); k++) {
            Node attributesNode = attributesNodeList.item(k);
            NodeList attributeNodeList = attributesNode.getChildNodes();

            for (int j = 0; attributeNodeList != null && j < attributeNodeList.getLength(); j++) {
                Node attributeNode = attributeNodeList.item(j);

                if (attributeNode instanceof Element) {
                    Element attributeElement = (Element) attributeNode;
                    int colId = Integer.parseInt(attributeElement.getAttribute("colID"));

                    if (colId == 2) {
                        NodeList valueElementList = attributeElement.getChildNodes();
                        for (int l = 0; valueElementList != null && l < valueElementList.getLength(); l++) {
                            Node valueNode = valueElementList.item(l);
                            if (valueNode instanceof Element) {
                                Element valueElement = (Element) valueNode;
                                String id = valueElement.getFirstChild().getNodeValue();
                                doc.setId(id);
                            }
                        }
                    }else  if (colId == 0) {
                        NodeList valueElementList = attributeElement.getChildNodes();
                        for (int l = 0; valueElementList != null && l < valueElementList.getLength(); l++) {
                            Node valueNode = valueElementList.item(l);
                            if (valueNode instanceof Element) {
                                Element valueElement = (Element) valueNode;
                                if ("value".equals(valueElement.getNodeName())) {
                                    String docName = valueElement.getFirstChild().getNodeValue();
                                    doc.setName(docName);
                                } else if ("link".equals(valueElement.getNodeName())) {
                                    String fileName = valueElement.getFirstChild().getNodeValue();
                                    doc.setFileName(fileName);
                                }
                            }
                        }
                    }
                    else if (colId == 9) {
                     NodeList valueElementList = attributeElement.getChildNodes();
                        for (int l = 0; valueElementList != null && l < valueElementList.getLength(); l++) {
                            Node valueNode = valueElementList.item(l);
                            if (valueNode instanceof Element) {
                                Element valueElement = (Element) valueNode;
                                if (valueElement.hasChildNodes()){
                                    String desc = valueElement.getFirstChild().getNodeValue();
                                    doc.setPresentationDesc(desc);
                                }
                            }
                        }
                    }
                   else if (colId == 10){
                        NodeList valueElementList = attributeElement.getChildNodes();
                        for (int l = 0; valueElementList != null && l < valueElementList.getLength(); l++) {
                            Node valueNode = valueElementList.item(l);
                            if (valueNode instanceof Element) {
                                Element valueElement = (Element) valueNode;
                                if (valueElement.hasChildNodes()){
                                    String content = valueElement.getFirstChild().getNodeValue();
                                    doc.setPresentationCont(content);
                                }
                            }
                        }
                    }
                }
            }
        }
        doc.setMimeType(Constants.POWER_POINT_MIME_TYPE);
        return doc;
    }

//    public org.w3c.dom.Document getcontentDocument(org.w3c.dom.Document doc, String documentId) throws ParserConfigurationException{
//        NodeList documentElements = doc.getElementsByTagName("document");
//        for (int i=0; documentElements != null && i<documentElements.getLength(); i++) {
//            Node docNode = documentElements.item(i);
//            org.w3c.dom.Document ContentDoc = parseDoc(docNode);
//            DOMUtil.outputXML(ContentDoc);
//            if (isPresent(ContentDoc,documentId)) {
//                System.out.println("found document.");
//                return ContentDoc;
//            }
//        }  return null;
//    }
//
//    private org.w3c.dom.Document parseDoc(Node docNode) throws ParserConfigurationException {
//        if (docNode!=null){
//            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
//            DocumentBuilder docBuilder = factory.newDocumentBuilder();
//            org.w3c.dom.Document newDoc = docBuilder.newDocument();
//            Node newdocumentNode = newDoc.importNode(docNode, true);
//            newDoc.appendChild(newdocumentNode);
//            return newDoc;
//        }return null;
//    }
//
//    private boolean isPresent(org.w3c.dom.Document doc, String documentId) {
//        System.out.println("Checking for document id = '" + documentId + "'");
//        NodeList attributeNodeList = doc.getElementsByTagName("attribute");
//
//        for (int i = 0; attributeNodeList != null && i < attributeNodeList.getLength(); i++) {
//            Node attributeNode = attributeNodeList.item(i);
//
//            if (attributeNode instanceof Element) {
//                Element attributeElement = (Element) attributeNode;
//                int colId = Integer.parseInt(attributeElement.getAttribute("colID"));
//
//                if (colId == 5) {
//                    NodeList valueElementList = attributeElement.getChildNodes();
//                    for (int l = 0; valueElementList != null && l < valueElementList.getLength(); l++) {
//                        Node valueNode = valueElementList.item(l);
//                        if (valueNode instanceof Element) {
//                            Element valueElement = (Element) valueNode;
//                            String id = valueElement.getFirstChild().getNodeValue();
//                            if (id != null && id.equals(documentId)){
//                                return true;
//                            }
//                        }
//                    }
//                }
//            }
//        }
//        return false;
//    }
}

