package com.monsanto.wst.technicalpresentationlib.web.controller;

import com.monsanto.ServletFramework.UseCaseController;
import com.monsanto.ServletFramework.UCCHelper;

import java.io.IOException;

/**
 * Created by IntelliJ IDEA.
 * Date: May 17, 2005
 * Time: 9:58:31 AM
 * <p>
 * This class is a controller class for forwarding html file requests to the actual location
 * on the filesystem.
 * </p>
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class FilenameDispatchController implements UseCaseController {

    /**
     * @see UseCaseController#run(com.monsanto.ServletFramework.UCCHelper) s
     */
    public void run(UCCHelper helper) throws IOException {
        String requestUrl = helper.requestedURL();
        String fileName = requestUrl != null ? requestUrl.substring(requestUrl.lastIndexOf("/") + 1, requestUrl.length()) : null;
        helper.forward("/html/" + fileName);
    }

}
