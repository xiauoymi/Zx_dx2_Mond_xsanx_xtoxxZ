package com.monsanto.sqlservertool.adauth;

import com.monsanto.sqlservertool.to.UserDetailsTO;
import com.monsanto.sqlservertool.utils.SqlServerToolConstants;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Hashtable;
import java.util.Map;
import java.util.Properties;
import javax.annotation.Resource;
import javax.naming.Context;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.Attribute;
import javax.naming.directory.Attributes;
import javax.naming.directory.SearchControls;
import javax.naming.directory.SearchResult;
import javax.naming.ldap.InitialLdapContext;
import javax.naming.ldap.LdapContext;

@Component
public class ADAuthenticator {
    private Logger logger = Logger.getLogger(this.getClass());

    @Resource(name = "adDomainProperties")
    private Properties adProps;

    public ADAuthenticator() {
    }

    public Map authenticate(UserDetailsTO userDetails) throws Exception {
        ADDomainProperties adDomainProperties = getADDomainProperties(userDetails.getUserDomain());

        String returnedAtts[] = {"sn", "givenName", "mail"};
        String searchFilter = "(&(objectClass=user)(sAMAccountName=" + userDetails.getUserName() + "))";

        //Create the search controls
        SearchControls searchCtls = new SearchControls();
        searchCtls.setReturningAttributes(returnedAtts);

        //Specify the search scope
        searchCtls.setSearchScope(SearchControls.SUBTREE_SCOPE);

        Hashtable env = populateEnvironmentDetails(userDetails, adDomainProperties);

        return searchADDomainForUser(adDomainProperties, searchFilter, searchCtls, env);
    }

    private Map searchADDomainForUser(ADDomainProperties adDomainProperties, String searchFilter, SearchControls searchCtls, Hashtable env) {
        LdapContext ctxGC = null;

        try {
            ctxGC = new InitialLdapContext(env, null);
            //Search objects in GC using filters
            NamingEnumeration answer = ctxGC.search(adDomainProperties.getSearchBase(), searchFilter, searchCtls);
            while (answer.hasMoreElements()) {
                SearchResult sr = (SearchResult) answer.next();
                Attributes attrs = sr.getAttributes();
                Map adAttributesForUser = null;
                if (attrs != null) {
                    adAttributesForUser = new HashMap();
                    NamingEnumeration ne = attrs.getAll();
                    while (ne.hasMore()) {
                        Attribute attr = (Attribute) ne.next();
                        adAttributesForUser.put(attr.getID(), attr.get());
                    }
                    ne.close();
                }
                return adAttributesForUser;
            }
        } catch (NamingException ex) {
            logger.error("Error while authenticating AD user." + ex.getMessage());
        }

        return null;
    }

    private Hashtable populateEnvironmentDetails(UserDetailsTO userDetails, ADDomainProperties adDomainProperties) {
        Hashtable env = new Hashtable();
        env.put(Context.INITIAL_CONTEXT_FACTORY, SqlServerToolConstants.LDAP_CTX_FACTORY);
        env.put(Context.PROVIDER_URL, adDomainProperties.getLdapHost());
        env.put(Context.SECURITY_AUTHENTICATION, SqlServerToolConstants.SECURITY_AUTH);
        env.put(Context.SECURITY_PRINCIPAL, userDetails.getUserName() + "@" + adDomainProperties.getDomain());
        env.put(Context.SECURITY_CREDENTIALS, userDetails.getPassword());
        return env;
    }

    private ADDomainProperties getADDomainProperties(String selectedDomain) throws Exception {
        ADDomainProperties selectedDomainInfo = new ADDomainProperties();
        String domainName = getADDomainProperty(selectedDomain+SqlServerToolConstants.AD_DOMAIN_PROP_SUFFIX);
        String domainHost = getADDomainProperty(selectedDomain+SqlServerToolConstants.AD_HOST_PROP_SUFFIX);
        String domainDC = getADDomainProperty(selectedDomain+SqlServerToolConstants.AD_DC_PROP_SUFFIX);
        selectedDomainInfo.setDomain(domainName);
        selectedDomainInfo.setLdapHost(domainHost);
        selectedDomainInfo.setSearchBase("DC=" + domainDC + SqlServerToolConstants.AD_SEARCH_BASE_CONSTANT_PROP);
        return selectedDomainInfo;
    }

    private String getADDomainProperty(String property) throws Exception {
        String propertyvalue = null;
        if (adProps.containsKey(property)) {
            propertyvalue = (String) adProps.get(property);
        } else {
            logger.error("Domain property"+property+" not found.");
            throw new Exception("Domain property"+property+" not found.");
        }
        return propertyvalue;
    }

}