package com.monsanto.sqlservertool.utils;

import com.monsanto.Util.EnvironmentHelper;
import com.monsanto.Util.EnvironmentHelperException;
import com.monsanto.Util.StringUtils;
import com.monsanto.Util.databasepasswordencryption.EncryptionUtils;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;

import java.util.MissingResourceException;
import java.util.Properties;
import java.util.ResourceBundle;

/**
 * Created by IntelliJ IDEA.
 * User: RRPAND5
 * Date: Jan 12, 2012
 * Time: 10:28:00 AM
 * To change this template use File | Settings | File Templates.
 */
@Component
public class EncryptionUtil {

    private static final String STORAGE_VAR = "storageVar";
    private static final String APP_FOLDER_NAME = "appFolderName";
    private static final String PASSWORDFILE = "jtds.msmsql.database.passwordfile.";
    private static final String KEYFILE = "jtds.msmsql.database.keyfile.";
    Logger logger = Logger.getLogger(this.getClass());

    public String getPassword(Properties jtdsConnectionProps) throws Exception {
        try {
            String envPropertyPrefix = EnvironmentHelper.getPropertyPrefix();
            if (!StringUtils.isNullOrEmpty(envPropertyPrefix) &&
                    envPropertyPrefix.contains(".")) {
                envPropertyPrefix = envPropertyPrefix.replace(".", "");

            }
            String storageVar = jtdsConnectionProps.getProperty(STORAGE_VAR);
            String appFolder = jtdsConnectionProps.getProperty(APP_FOLDER_NAME);
            String encryptedPasswordFileName = jtdsConnectionProps.getProperty(PASSWORDFILE + envPropertyPrefix.toLowerCase());
            String keyFileName = jtdsConnectionProps.getProperty(KEYFILE + envPropertyPrefix.toLowerCase());
            return EncryptionUtils.GetDecryptedStringFromExternalStorage(storageVar, appFolder, encryptedPasswordFileName, keyFileName);
        } catch (Exception e) {
            logger.debug("Exception occured while obtaining password. " + e);
            throw new Exception(
                    "Exception occurred while obtaining password. " + e, e);
        }
    }
}
