package com.monsanto.sqlservertool.dbconnection;

import com.monsanto.sqlservertool.to.UserSQLAccountsTO;
import com.monsanto.sqlservertool.to.UserServerDetailsTO;
import com.monsanto.sqlservertool.to.UserServerInstancesTO;
import com.monsanto.sqlservertool.utils.SqlServerToolConstants;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Repository;

import javax.annotation.Resource;
import javax.sql.DataSource;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: JHUER
 * Date: 18/10/12
 * Time: 04:25 PM
 * To change this template use File | Settings | File Templates.
 */
@Repository
public class SQLServerToolDAO {
    public static final String EXEC = "EXEC [";
    public static final String MASTER_DBO = "].master.dbo.sp_password ?,?,?";
    public static final String MASTER_SYS = "].master.sys.sp_password ?,?,?";
    Connection connection = null;

    Logger logger = Logger.getLogger(this.getClass());

    public void setDataSource(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    @Resource(name = "sqlserver_ds")
    DataSource dataSource;

    @Resource
    JtdsJdbcConnection jtdsConnection;

    public List<UserServerInstancesTO> getUserServerInstance(String loggedInUser) throws SQLException {
        logger.debug(this.getClass().toString() + " method getUserServerInstance()");
        try {
            connection = dataSource.getConnection();
            Statement statement = connection.createStatement();
            logger.debug(SqlServerToolConstants.GETTING_SERVER_INSTANCE_QUERY + loggedInUser + "%'");
            ResultSet rs = statement.executeQuery(SqlServerToolConstants.GETTING_SERVER_INSTANCE_QUERY + loggedInUser + "%'");

            List<UserServerInstancesTO> userServerInstancesList = new ArrayList<UserServerInstancesTO>();
            while (rs.next()) {
                UserServerInstancesTO userServerInstancesTO = new UserServerInstancesTO();
                userServerInstancesTO.setServerInstance(rs.getString("Server"));
                userServerInstancesList.add(userServerInstancesTO);
            }
            return userServerInstancesList;
        } catch (SQLException sqlException) {
            throw sqlException;

        } finally {
            if (connection != null) {
                connection.close();
            }
        }
    }

    public List<UserSQLAccountsTO> getSQLAccountsByServerInstance(String serverInstance, String loggedInUser) throws SQLException {
        logger.debug(this.getClass().toString() + " method getSQLAccountsByServerInstance()");
        try {
            connection = dataSource.getConnection();
            Statement statement = connection.createStatement();
            logger.debug(SqlServerToolConstants.GETTING_SQL_ACCOUNTS_QUERY + serverInstance + SqlServerToolConstants.GETTING_SQL_ACCOUNTS_QUERY2 + loggedInUser + "%'");
            ResultSet rs = statement.executeQuery(SqlServerToolConstants.GETTING_SQL_ACCOUNTS_QUERY + serverInstance + SqlServerToolConstants.GETTING_SQL_ACCOUNTS_QUERY2 + loggedInUser + "%'");
            List<UserSQLAccountsTO> userSQLAccountsTOList = new ArrayList<UserSQLAccountsTO>();

            while (rs.next()) {
                UserSQLAccountsTO userSQLAccountsTO = new UserSQLAccountsTO();
                userSQLAccountsTO.setSqlAccountName(rs.getString("name"));
                userSQLAccountsTO.setApplication(rs.getString("application"));
                userSQLAccountsTO.setAppOwnerSupport(rs.getString("appOwnerSupport"));
                userSQLAccountsTO.setEmailId(rs.getString("email"));
                userSQLAccountsTO.setNtId(rs.getString("ntId"));
                userSQLAccountsTO.setVersion(rs.getString("version"));
                userSQLAccountsTOList.add(userSQLAccountsTO);
            }
            return userSQLAccountsTOList;
        } catch (SQLException sqlException) {
            throw sqlException;

        } finally {
            if (connection != null) {
                connection.close();
            }

        }
    }

    public boolean runScriptByVersion(UserServerDetailsTO userServerDetailsTO) throws Exception {

        logger.debug(this.getClass().toString() + " method runScriptByVersion()");

        String script = buildScriptToExecute(userServerDetailsTO);
        try {
            connection = jtdsConnection.getConnectionWithWindowAuth();
            PreparedStatement ps = connection.prepareStatement(script);
            ps.setEscapeProcessing(true);
            ps.setString(1, userServerDetailsTO.getCurrentPassword());
            ps.setString(2, userServerDetailsTO.getNewPassword());
            ps.setString(3, userServerDetailsTO.getSelectedSQLAccount());
            logger.debug(ps.toString());
            ps.execute();
            return true;
        } catch (SQLException sqlException) {
            throw sqlException;
        } finally {
            if (connection != null) {
                connection.close();
            }
        }
    }

    private String buildScriptToExecute(UserServerDetailsTO userServerDetailsTO) {
        String script;
        logger.debug(this.getClass().toString() + " method buildScriptToExecute()");
        if (userServerDetailsTO.getVersion().contains(SqlServerToolConstants.VERSION_SQL_2000)) {
            script = EXEC + userServerDetailsTO.getSelectedServerInstance() + MASTER_DBO;
        } else {
            script = EXEC + userServerDetailsTO.getSelectedServerInstance() + MASTER_SYS;
        }
        return script;
    }

    public void setJtdsConnection(JtdsJdbcConnection jtdsConnection) {
        this.jtdsConnection = jtdsConnection;
    }
}


