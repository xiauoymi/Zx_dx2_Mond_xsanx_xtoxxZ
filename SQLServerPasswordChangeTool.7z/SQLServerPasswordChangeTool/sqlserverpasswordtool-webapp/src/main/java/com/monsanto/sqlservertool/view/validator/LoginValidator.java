package com.monsanto.sqlservertool.view.validator;

import com.monsanto.Util.StringUtils;
import com.monsanto.sqlservertool.to.UserDetailsTO;
import com.monsanto.sqlservertool.utils.SqlServerToolErrors;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

/**
 * Created by IntelliJ IDEA.
 * User: rrpand5
 * Date: 10/12/12
 * Time: 4:20 PM
 * To change this template use File | Settings | File Templates.
 */
@Component
public class LoginValidator implements Validator {

    @Override
    public boolean supports(Class<?> clazz) {
        return false;  //To change body of implemented methods use File | Settings | File Templates.
    }

    @Override
    public void validate(Object target, Errors errors) {
        UserDetailsTO loginDetails = (UserDetailsTO) target;
        if (StringUtils.isNullOrEmpty(loginDetails.getUserName())) {
            errors.rejectValue("userName", SqlServerToolErrors.USERNAME_REQUIRED, SqlServerToolErrors.USERNAME_REQUIRED);
        }
        if (StringUtils.isNullOrEmpty(loginDetails.getPassword())) {
            errors.rejectValue("password", SqlServerToolErrors.PASSWORD_REQUIRED, SqlServerToolErrors.PASSWORD_REQUIRED);
        }

    }
}
