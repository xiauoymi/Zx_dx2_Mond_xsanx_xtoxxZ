package com.monsanto.sqlservertool.utils;

/**
 * Created by IntelliJ IDEA.
 * User: rrpand5
 * Date: 10/11/12
 * Time: 2:36 PM
 * To change this template use File | Settings | File Templates.
 */
public class SqlServerToolConstants {
    public static final String LOGGED_IN_USER = "loggedInUser";
    public static final String DOMAIN_NAMES = "domainNames";
    public static final String LDAP_CTX_FACTORY = "com.sun.jndi.ldap.LdapCtxFactory";
    public static final String SECURITY_AUTH = "simple";
    public static final String AD_DOMAIN_PROP_SUFFIX = ".domain";
    public static final String AD_HOST_PROP_SUFFIX = ".host";
    public static final String AD_DC_PROP_SUFFIX = ".dc";
    public static final String AD_SEARCH_BASE_CONSTANT_PROP = ",DC=ds,DC=monsanto,DC=com";
    public static final String GETTING_SERVER_INSTANCE_QUERY = "SELECT DISTINCT ([Server]) FROM [PWDCHG_DEV].[dbo].[SQL_PWD_AGE_WITH_ACCOUNT_OWNER] WHERE [Email ID] IS NOT NULL AND [NT ID] LIKE '%";
    public static final String GETTING_SQL_ACCOUNTS_QUERY = "SELECT [name] AS name, [Application] AS application, [Application Owner/Support] AS appOwnerSupport,[Email ID] AS email, [NT ID] AS ntId, [VersionSQL] as version FROM [PWDCHG_DEV].[dbo].[SQL_PWD_AGE_WITH_ACCOUNT_OWNER] WHERE [Email ID] IS NOT NULL AND [Server] = '";
    public static final String GETTING_SQL_ACCOUNTS_QUERY2 = "' AND [NT ID] LIKE '%";
    public static final String VERSION_SQL_2000 = "8.";



}
