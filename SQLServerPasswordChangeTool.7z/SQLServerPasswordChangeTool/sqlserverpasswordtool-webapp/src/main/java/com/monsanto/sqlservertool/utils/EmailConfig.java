package com.monsanto.sqlservertool.utils;

import com.monsanto.Util.EnvironmentHelper;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;

import java.util.MissingResourceException;
import java.util.ResourceBundle;

/**
 * Created by IntelliJ IDEA.
 * User: JLVALE1
 * Date: 10/22/12
 * Time: 12:46 PM
 * To change this template use File | Settings | File Templates.
 */
@Component
public class EmailConfig {
    private Logger logger = Logger.getLogger(this.getClass());
    private ResourceBundle resourceBundle;
    private static final String MAIL_CONFIG_FILE = "mail";

    public EmailConfig(){
        try{
            resourceBundle = ResourceBundle.getBundle(MAIL_CONFIG_FILE);
        } catch(Exception e){
            logger.error(e.getMessage());
        }
    }

    public String getProperty(String aName) {

        String lValue = null;

        try {
            String envPropertyPrefix = EnvironmentHelper.getPropertyPrefix();
            try {
                lValue = resourceBundle.getString(envPropertyPrefix + aName).trim();
                lValue = resourceBundle.getString(aName).trim();
            } catch (MissingResourceException e) {
                lValue = resourceBundle.getString("default." + aName).trim();

            }

        } catch (Exception e) {
            logger.error(e.getMessage());
        }

        return lValue;
    }

}
