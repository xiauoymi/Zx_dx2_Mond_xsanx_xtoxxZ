package com.monsanto.sqlservertool.utils;

/**
 * Created by IntelliJ IDEA.
 * User: rrpand5
 * Date: 10/12/12
 * Time: 4:22 PM
 * To change this template use File | Settings | File Templates.
 */
public class SqlServerToolErrors {
    public static final String USERNAME_REQUIRED = "Username is required. Please enter Username.";
    public static final String PASSWORD_REQUIRED = "Password is required. Please enter Password.";
    public static final String NEW_PASSWORD_REQUIRED = "New Password is required. Please enter New Password.";
    public static final String CONFIRM_NEW_PASSWORD_REQUIRED = "Confirm New Password is required";
    public static final String CONFIRM_NEW_PASSWORD_MISMATCH = "Confirmed New Password does not match New Password. ";
    public static final String NON_COMPLIANT_PASSWORD = "Non compliant Password";
    public static final String REPEATED_PASSWORD = "Password is repeated. Password cannot be the same as previous.";
    public static final String SHORT_PASSWORD = "Password is too short. Password must be at least eight characters long.";
    public static final String INVALID_LOGIN = "Invalid login. Please check username/password";
    public static final String CURRENT_PASSWORD_REQUIRED = "Current Password is required. Please enter Current Password.";
    public static final String SERVER_INSTANCE_REQUIRED = "Server Instance is required. Please select a Server Instance";
    public static final String SQL_ACCOUNT_REQUIRED = "SQL Account is required. Please select a SQL Account";
    public static final String SELECT_SERVER_INSTANCE = "Select Server...";
    public static final String SELECT_SQL_ACCOUNT = "Select SQL Account...";
    public static final String EMAIL_ERROR = "Password was changed successfully but confirmation emails could not be sent.";
    public static final String ERROR_MESSAGE = "We�re sorry! Your request can�t be completed at this time. Please try again later. If the problem persists,";
    public static final String CONTACT_SUPPORT = " please contact SQL Server Support team at DL-1000-SQLSERVERADMIN@monsanto.com.";
    public static final String CURRENT_PASSWORD_IS_WRONG = "Current Password is wrong, please enter correct current password";

}
