package com.monsanto.sqlservertool.utils;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import java.util.Properties;

/**
 * Created by IntelliJ IDEA.
 * User: JLVALE1
 * Date: 10/17/12
 * Time: 5:24 PM
 * To change this template use File | Settings | File Templates.
 */
@Component
public class EmailSender {
    Logger logger = Logger.getLogger(this.getClass());
    private static final String MAIL_SMTP_HOST_KEY = "mail.smtp.host";
    private static final String MAIL_SMTP_HOST_VALUE = "sendMailHost";
    @Resource
    private EmailConfig emailConfig;

    public boolean sendEmail(String[] sendTo, String[] copyTo, String subject, String emailBody, String sendFrom){
        boolean result = true;
        Properties props = System.getProperties();
        props.put(MAIL_SMTP_HOST_KEY, emailConfig.getProperty(MAIL_SMTP_HOST_VALUE));
        Session session = Session.getInstance(props, null);
        try {
            Message message = new MimeMessage(session);
            message.setFrom(new InternetAddress(sendFrom));
            InternetAddress[] addressTo = null;
            InternetAddress[] addressCopyTo = null;
            if(sendTo == null){
                sendTo = new String[0];
            } else {
                addressTo = new InternetAddress[sendTo.length];
            }
            if(copyTo == null){
                copyTo = new String[0];
            } else {
                addressCopyTo = new InternetAddress[copyTo.length];
            }
            if(sendTo.length > 0){
                for(int i=0; i<sendTo.length; i++){
                    addressTo[i] = new InternetAddress(sendTo[i]);
                }
                if(copyTo.length > 0){
                    for(int i=0; i<copyTo.length; i++){
                        addressCopyTo[i] = new InternetAddress(copyTo[i]);
                    }
                    message.setRecipients(Message.RecipientType.CC, addressCopyTo);
                }
                message.setRecipients(Message.RecipientType.TO, addressTo);
                message.setSubject(subject);
                message.setText(emailBody);
                sendMessage(message);
            }
        } catch(MessagingException mex){
            logger.error("Error while trying to send confirmation emails.");
            result = false;
        }
        return result;
    }

    protected void sendMessage(Message message) throws MessagingException{
        Transport.send(message);
    }

    public EmailConfig getEmailConfig() {
        return emailConfig;
    }

    public void setEmailConfig(EmailConfig emailConfig) {
        this.emailConfig = emailConfig;
    }
}
