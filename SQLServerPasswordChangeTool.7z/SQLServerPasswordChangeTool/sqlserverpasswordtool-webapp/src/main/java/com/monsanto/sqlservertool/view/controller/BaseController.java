package com.monsanto.sqlservertool.view.controller;

import com.monsanto.sqlservertool.dbconnection.SQLServerToolDAO;
import com.monsanto.sqlservertool.to.UserDetailsTO;
import com.monsanto.sqlservertool.utils.SqlServerToolConstants;
import org.apache.log4j.Logger;
import org.codehaus.plexus.util.ExceptionUtils;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.ModelAndView;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

/**
 * Created by IntelliJ IDEA.
 * User: rrpand5
 * Date: 10/11/12
 * Time: 2:00 PM
 * To change this template use File | Settings | File Templates.
 */
public class BaseController {

    private static final String ERROR_VIEW = "/error";
    Logger logger = Logger.getLogger(this.getClass());
    @Resource
    protected SQLServerToolDAO dao;

    protected UserDetailsTO getLoggedInUser(HttpSession session) {
        return (UserDetailsTO) session.getAttribute(SqlServerToolConstants.LOGGED_IN_USER);
    }

    @ExceptionHandler(Throwable.class)
    public ModelAndView handleException(HttpServletRequest request, Exception exception) {
        logger.error(ExceptionUtils.getStackTrace(exception));
        request.setAttribute("exceptionStackTrace", ExceptionUtils.getStackTrace(exception));
        ModelAndView modelAndView = new ModelAndView();
        return modelAndView;
    }

    public void setDao(SQLServerToolDAO dao) {
        this.dao = dao;
    }
}
