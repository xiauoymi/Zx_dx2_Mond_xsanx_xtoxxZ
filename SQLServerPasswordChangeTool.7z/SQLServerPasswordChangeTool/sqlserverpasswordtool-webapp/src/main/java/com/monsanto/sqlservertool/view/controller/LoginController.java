package com.monsanto.sqlservertool.view.controller;

import com.monsanto.sqlservertool.to.UserDetailsTO;
import com.monsanto.sqlservertool.to.UserServerDetailsTO;
import com.monsanto.sqlservertool.to.UserServerInstancesTO;
import com.monsanto.sqlservertool.utils.SqlServerToolConstants;
import com.monsanto.sqlservertool.utils.SqlServerToolErrors;
import com.monsanto.sqlservertool.view.bo.LoginBO;
import com.monsanto.sqlservertool.view.validator.LoginValidator;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.Set;

/**
 * Created by IntelliJ IDEA.
 * User: rrpand5
 * Date: 10/11/12
 * Time: 2:00 PM
 * To change this template use File | Settings | File Templates.
 */
@Controller
@RequestMapping("/login.do")
public class LoginController extends BaseController {

    private static final String USER_SERVER_INSTANCES = "userServerInstances";
    private static final String SUCCESSFUL_LOGIN_VIEW = "/successfulLogin";
    private static final String VIEW_NAME = "login";
    private static final String USER_DETAILS = "userDetails";
    Logger logger = Logger.getLogger(this.getClass());
    private static final String SERVER_DETAILS = "serverDetails";

    @Resource(name = "adDomainProperties")
    private Properties adProps;

    @Resource
    LoginValidator loginValidator;

    @Resource
    LoginBO loginBO;

    @RequestMapping(method = RequestMethod.GET)
    public ModelAndView displayLoginPage(HttpServletRequest request, HttpServletResponse response, HttpSession session) throws Exception {
        logger.debug("Preparing to load login page.");
        ModelAndView modelAndView = new ModelAndView();
        UserDetailsTO userDetails = new UserDetailsTO();
        modelAndView.getModelMap().addAttribute(USER_DETAILS, userDetails);
        session.setAttribute(SqlServerToolConstants.DOMAIN_NAMES, getDomainNames());
        logger.debug("Got domain names.");
        modelAndView.setViewName(VIEW_NAME);
        return modelAndView;
    }

    @RequestMapping(method = RequestMethod.POST)
    public ModelAndView authenticateUser(HttpServletRequest request, HttpServletResponse response, HttpSession session, ModelAndView modelAndView,
                                         @ModelAttribute(value = USER_DETAILS) UserDetailsTO userDetails, BindingResult bindingResult) throws Exception {
        logger.debug("Beginning to authenticate.");
        //validate user credentials
        loginValidator.validate(userDetails, bindingResult);
        if (!bindingResult.hasErrors()) {
            logger.debug("Validation passed. Now authenticating the user.");
             if (!loginBO.authenticateADUser(userDetails)) {
                bindingResult.reject("loginFailed", SqlServerToolErrors.INVALID_LOGIN);
                modelAndView.setViewName(VIEW_NAME);
            } else {
                request.setAttribute(SqlServerToolConstants.LOGGED_IN_USER, userDetails.getFirstName() + " " +userDetails.getLastName());
                session.setAttribute(SqlServerToolConstants.LOGGED_IN_USER, userDetails);
                UserServerDetailsTO userServerDetailsTO = new UserServerDetailsTO();
                List<UserServerInstancesTO> userServerInstancesTOList = getUserServerInstance(session, request);
                session.setAttribute(USER_SERVER_INSTANCES, userServerInstancesTOList);
                modelAndView.getModelMap().addAttribute(USER_SERVER_INSTANCES, userServerInstancesTOList);
                modelAndView.getModelMap().addAttribute(SERVER_DETAILS, userServerDetailsTO);
                modelAndView.setViewName(SUCCESSFUL_LOGIN_VIEW);
            }
        } else {
            logger.debug("Validation failed.");
            modelAndView.setViewName(VIEW_NAME);
        }
        session.setAttribute(SqlServerToolConstants.DOMAIN_NAMES, getDomainNames());
        return modelAndView;
    }

    private ArrayList getDomainNames() {
        logger.debug("Lodaing all domain names.");
        Set<String> adPropNames = adProps.stringPropertyNames();
        ArrayList domainNames = new ArrayList();
        for (String propName : adPropNames) {
            if (propName.contains(".domain")) {
                domainNames.add(adProps.getProperty(propName));
            }
        }
        logger.debug("Total Domain names = " + domainNames.size());
        return domainNames;
    }

    private List<UserServerInstancesTO> getUserServerInstance(HttpSession session, HttpServletRequest request) {
        try {
            return dao.getUserServerInstance(getLoggedInUser(session).getUserName());
        } catch (SQLException sqlException) {
            handleException(request, sqlException);
            return new ArrayList<UserServerInstancesTO>();
        }
    }

    public void setAdProps(Properties adProps) {
        this.adProps = adProps;
    }

    public void setLoginValidator(LoginValidator loginValidator) {
        this.loginValidator = loginValidator;
    }

    public void setLoginBO(LoginBO loginBO) {
        this.loginBO = loginBO;
    }
}