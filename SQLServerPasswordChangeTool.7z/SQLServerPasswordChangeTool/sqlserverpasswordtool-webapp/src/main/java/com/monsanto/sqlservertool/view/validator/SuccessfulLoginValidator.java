package com.monsanto.sqlservertool.view.validator;

import com.monsanto.Util.StringUtils;
import com.monsanto.sqlservertool.to.UserServerDetailsTO;
import com.monsanto.sqlservertool.utils.SqlServerToolErrors;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

/**
 * Created by IntelliJ IDEA.
 * User: JHUER
 * Date: 16/10/12
 * Time: 11:35 AM
 * To change this template use File | Settings | File Templates.
 */
@Component
public class SuccessfulLoginValidator implements Validator {
    private static final int MIN_PASSWORD_LENGTH = 8;
    private static final int MIN_CATEGORIES = 3;

    @Override
    public boolean supports(Class<?> aClass) {
        return false;  //To change body of implemented methods use File | Settings | File Templates.
    }

    @Override
    public void validate(Object object, Errors errors) {
        int matchedCategories = 0;
        UserServerDetailsTO userServerDetailsTO = (UserServerDetailsTO) object;
        if (StringUtils.isNullOrEmpty(userServerDetailsTO.getSelectedServerInstance()) || userServerDetailsTO.getSelectedServerInstance().equals(SqlServerToolErrors.SELECT_SERVER_INSTANCE)) {
            errors.rejectValue("selectedServerInstance", SqlServerToolErrors.SERVER_INSTANCE_REQUIRED, SqlServerToolErrors.SERVER_INSTANCE_REQUIRED);
        }
        if (StringUtils.isNullOrEmpty(userServerDetailsTO.getSelectedSQLAccount()) || userServerDetailsTO.getSelectedSQLAccount().equals(SqlServerToolErrors.SELECT_SQL_ACCOUNT)) {
            errors.rejectValue("selectedSQLAccount", SqlServerToolErrors.SQL_ACCOUNT_REQUIRED, SqlServerToolErrors.SQL_ACCOUNT_REQUIRED);
        }
        if (StringUtils.isNullOrEmpty(userServerDetailsTO.getCurrentPassword())) {
            errors.rejectValue("currentPassword", SqlServerToolErrors.CURRENT_PASSWORD_REQUIRED, SqlServerToolErrors.CURRENT_PASSWORD_REQUIRED);
        }
        if (StringUtils.isNullOrEmpty(userServerDetailsTO.getNewPassword())) {
            errors.rejectValue("newPassword", SqlServerToolErrors.NEW_PASSWORD_REQUIRED, SqlServerToolErrors.NEW_PASSWORD_REQUIRED);
        }
        if (!StringUtils.areEqual(userServerDetailsTO.getNewPassword(), userServerDetailsTO.getConfirmNewPassword())) {
            errors.rejectValue("confirmNewPassword", SqlServerToolErrors.CONFIRM_NEW_PASSWORD_MISMATCH, SqlServerToolErrors.CONFIRM_NEW_PASSWORD_MISMATCH);
        }
        if (!errors.hasErrors()) {
            if (StringUtils.areEqual(userServerDetailsTO.getNewPassword(), userServerDetailsTO.getCurrentPassword())) {
                errors.rejectValue("newPassword", SqlServerToolErrors.REPEATED_PASSWORD, SqlServerToolErrors.REPEATED_PASSWORD);
                return;
            }
            if (userServerDetailsTO.getNewPassword().length() < MIN_PASSWORD_LENGTH) {
                errors.rejectValue("newPassword", SqlServerToolErrors.SHORT_PASSWORD, SqlServerToolErrors.SHORT_PASSWORD);
            }
            if (StringUtils.isMatchedByRegExp(userServerDetailsTO.getNewPassword(), "(?=.*\\d)", false)) {
                matchedCategories++;
            }
            if (StringUtils.isMatchedByRegExp(userServerDetailsTO.getNewPassword(), "(?=.*[a-z])", false)) {
                matchedCategories++;
            }
            if (StringUtils.isMatchedByRegExp(userServerDetailsTO.getNewPassword(), "(?=.*[A-Z])", false)) {
                matchedCategories++;
            }
            if (StringUtils.isMatchedByRegExp(userServerDetailsTO.getNewPassword(), "(?=.*[@#$%!])", false)) {
                matchedCategories++;
            }
            if (matchedCategories < MIN_CATEGORIES) {
                errors.rejectValue("newPassword", SqlServerToolErrors.NON_COMPLIANT_PASSWORD, "Password is not compliant. Please click Help link.");
            }
        }

    }
}
