package com.monsanto.sqlservertool.to;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: JHUER
 * Date: 16/10/12
 * Time: 05:05 PM
 * To change this template use File | Settings | File Templates.
 */
public class UserSQLAccountsTO {
    String sqlAccountName;
    String application;
    String appOwnerSupport;
    String emailId;
    String ntId;
    String version;

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public String getSqlAccountName() {
        return sqlAccountName;
    }

    public void setSqlAccountName(String sqlAccountName) {
        this.sqlAccountName = sqlAccountName;
    }

    public String getApplication() {
        return application;
    }

    public void setApplication(String application) {
        this.application = application;
    }

    public String getAppOwnerSupport() {
        return appOwnerSupport;
    }

    public void setAppOwnerSupport(String appOwnerSupport) {
        this.appOwnerSupport = appOwnerSupport;
    }

    public String getEmailId() {
        return emailId;
    }

    public void setEmailId(String emailId) {
        this.emailId = emailId;
    }

    public String getNtId() {
        return ntId;
    }

    public void setNtId(String ntId) {
        this.ntId = ntId;
    }
}
