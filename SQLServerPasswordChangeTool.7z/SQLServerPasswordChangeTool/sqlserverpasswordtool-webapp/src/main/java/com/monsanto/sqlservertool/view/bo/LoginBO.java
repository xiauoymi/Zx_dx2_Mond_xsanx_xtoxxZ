package com.monsanto.sqlservertool.view.bo;

import com.monsanto.sqlservertool.adauth.ADAuthenticator;
import com.monsanto.sqlservertool.to.UserDetailsTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Map;

/**
 * Created by IntelliJ IDEA.
 * User: rrpand5
 * Date: 10/15/12
 * Time: 10:14 AM
 * To change this template use File | Settings | File Templates.
 */
@Component
public class LoginBO {

    @Autowired
    ADAuthenticator adAuthenticator;

    public boolean authenticateADUser(UserDetailsTO userDetails) throws Exception {
        boolean validUser = false;
        Map userAttributes = adAuthenticator.authenticate(userDetails);
        if(userAttributes != null) {
            validUser = true;
            userDetails.setFirstName((String)userAttributes.get("givenName"));
            userDetails.setLastName((String)userAttributes.get("sn"));
        }
        return validUser;

    }

    public void setAdAuthenticator(ADAuthenticator adAuthenticator) {
        this.adAuthenticator = adAuthenticator;
    }
}
