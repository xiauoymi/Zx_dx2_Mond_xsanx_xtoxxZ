package com.monsanto.sqlservertool.to;

import java.io.Serializable;

/**
 * Created by IntelliJ IDEA.
 * User: JLVALE1
 * Date: 10/16/12
 * Time: 5:22 PM
 * To change this template use File | Settings | File Templates.
 */
public class ChangePasswordTO implements Serializable {
    private String currentPassword;
    private String selectedServerInstance;
    private String selectedSQLAccount;
    private String newPassword;
    private String confirmNewPassword;
    private String validCurrentDataForm;

    public String getCurrentPassword() {
        return currentPassword;
    }

    public void setCurrentPassword(String currentPassword) {
        this.currentPassword = currentPassword;
    }

    public String getSelectedServerInstance() {
        return selectedServerInstance;
    }

    public void setSelectedServerInstance(String selectedServerInstance) {
        this.selectedServerInstance = selectedServerInstance;
    }

    public String getSelectedSQLAccount() {
        return selectedSQLAccount;
    }

    public void setSelectedSQLAccount(String selectedSQLAccount) {
        this.selectedSQLAccount = selectedSQLAccount;
    }

    public String getNewPassword() {
        return newPassword;
    }

    public void setNewPassword(String newPassword) {
        this.newPassword = newPassword;
    }

    public String getConfirmNewPassword() {
        return confirmNewPassword;
    }

    public void setConfirmNewPassword(String confirmNewPassword) {
        this.confirmNewPassword = confirmNewPassword;
    }

    public String getValidCurrentDataForm() {
        return validCurrentDataForm;
    }

    public void setValidCurrentDataForm(String validCurrentDataForm) {
        this.validCurrentDataForm = validCurrentDataForm;
    }
}
