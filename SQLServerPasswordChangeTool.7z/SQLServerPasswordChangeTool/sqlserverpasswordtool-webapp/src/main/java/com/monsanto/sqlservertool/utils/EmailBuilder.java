package com.monsanto.sqlservertool.utils;

import org.springframework.stereotype.Component;

import javax.annotation.Resource;

/**
 * Created by IntelliJ IDEA.
 * User: JLVALE1
 * Date: 10/18/12
 * Time: 9:10 AM
 * To change this template use File | Settings | File Templates.
 */
@Component
public class EmailBuilder {
    @Resource
    private EmailConfig emailConfig;

    public String buildPasswordChangeConfirmationEmailBody(String account, String server){
        if(account == null){
            account = "";
        }
        if(server == null){
            server = "";
        }
        return emailConfig.getProperty("confirmationEmailBody1") + " " + account + " " +
                emailConfig.getProperty("confirmationEmailBody2") + " " +
                emailConfig.getProperty("confirmationEmailBody3") + " " + server + ".";
    }

    public String buildPasswordChangeConfirmationSubject(){
        return emailConfig.getProperty("confirmationEmailSubject");
    }

    public String buildPasswordChangeConfirmationSendFrom(){
        return emailConfig.getProperty("confirmationEmailSentFrom");
    }

    public String buildPasswordChangeConfirmationCC(){
        return emailConfig.getProperty("confirmationEmailSentFrom");
    }

    public String[] tokenizeRecipients(String recipients){
        String[] result = null;
        if(recipients==null){
            result = new String[0];
        } else {
            result = recipients.split(";");
        }
        return result;
    }

    public EmailConfig getEmailConfig() {
        return emailConfig;
    }

    public void setEmailConfig(EmailConfig emailConfig) {
        this.emailConfig = emailConfig;
    }
}
