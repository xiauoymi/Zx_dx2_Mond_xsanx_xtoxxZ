package com.monsanto.sqlservertool.dbconnection;

import com.monsanto.Util.EnvironmentHelper;
import com.monsanto.Util.StringUtils;
import com.monsanto.sqlservertool.utils.EncryptionUtil;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.sql.Connection;
import java.util.Properties;

/**
 * Created by IntelliJ IDEA.
 * User: rrpand5
 * Date: 10/2/12
 * Time: 2:10 PM
 * To change this template use File | Settings | File Templates.
 */
@Component
public class JtdsJdbcConnection {

    private static final String JTDS_MSMSQL_DATABASE = "jtds.msmsql.database.";
    private static final String JTDS_MSSQL_URL = "jtds.mssql.url";
    private static final String JTDS_MSSQL_SERVER_NAME = "jtds.mssql.serverName";
    private static final String JTDS_MSSQL_PORT = "jtds.mssql.port";
    private static final String JTDS_MSMSQL_AD_USER_ACCOUNT_DOMAIN = "jtds.msmsql.aduseraccountdomain";
    private static final String JTDS_MSMSQL_SELECT_METHOD = "jtds.msmsql.selectMethod";
    private static final String JTDS_MSSQL_ADUSERACCOUNT = "jtds.mssql.aduseraccount";

    Logger logger = Logger.getLogger(this.getClass());

    @Resource(name = "jtdsJdbcConnProperties")
    private Properties jtdsConnectionProps;

    @Autowired
    EncryptionUtil encryptionUtil;

    public Connection getConnectionWithWindowAuth() throws Exception {

        Connection connection = getConnection(getConnectionUrlForWindowsAuth(),
                (jtdsConnectionProps.getProperty(JTDS_MSSQL_ADUSERACCOUNT)), getPassword());
        return connection;
    }

    private String getPassword() throws Exception {
        return encryptionUtil.getPassword(jtdsConnectionProps);
    }

    private String getConnectionUrlForWindowsAuth() throws Exception {
        String envPropertyPrefix = EnvironmentHelper.getPropertyPrefix();
        if (!StringUtils.isNullOrEmpty(envPropertyPrefix) &&
                envPropertyPrefix.contains(".")) {
            envPropertyPrefix = envPropertyPrefix.replace(".", "");
            logger.debug("Env value is - "+envPropertyPrefix);
        }
        String databaseNameProperty = JTDS_MSMSQL_DATABASE + envPropertyPrefix.toLowerCase();
        String connectionUrl = jtdsConnectionProps.getProperty(JTDS_MSSQL_URL)
                + jtdsConnectionProps.getProperty(JTDS_MSSQL_SERVER_NAME)
                + ":" + jtdsConnectionProps.getProperty(JTDS_MSSQL_PORT)
                + ";databaseName=" + jtdsConnectionProps.getProperty(databaseNameProperty)
                + ";domain=" + jtdsConnectionProps.getProperty(JTDS_MSMSQL_AD_USER_ACCOUNT_DOMAIN)
                + ";selectMethod=" + jtdsConnectionProps.getProperty(JTDS_MSMSQL_SELECT_METHOD) + ";";
        return connectionUrl;
    }

    private Connection getConnection(String connectionUrl, String userName, String password) throws Exception {
        Connection con = null;
        try {
            Class.forName(jtdsConnectionProps.getProperty("jtds.driver"));
            con = java.sql.DriverManager.getConnection(connectionUrl, userName, password);
        } catch (Exception ex) {
            logger.debug("Error while getting jtds connection");
            throw new Exception("Error while getting jtds connection");
        }
        return con;
    }
}
