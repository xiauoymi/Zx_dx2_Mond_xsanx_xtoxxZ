package com.monsanto.sqlservertool.view.controller;

import com.monsanto.sqlservertool.to.UserSQLAccountsTO;
import com.monsanto.sqlservertool.to.UserServerDetailsTO;
import com.monsanto.sqlservertool.to.UserServerInstancesTO;
import com.monsanto.sqlservertool.utils.EmailBuilder;
import com.monsanto.sqlservertool.utils.EmailSender;
import com.monsanto.sqlservertool.utils.SqlServerToolErrors;
import com.monsanto.sqlservertool.view.validator.SuccessfulLoginValidator;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: JHUER
 * Date: 16/10/12
 * Time: 11:36 AM
 * To change this template use File | Settings | File Templates.
 */
@Controller("successfulLoginController")
@RequestMapping("/successfulLogin.do")
public class SuccessfulLoginController extends BaseController {
    private final static String VIEW_NAME = "/successfulLogin";
    private final static String PASSWORD_CHANGE_VIEW_NAME = "/passwordChangeConfirmation";
    private static final String SERVER_DETAILS = "serverDetails";
    private static final String SQL_ACCOUNTS_LIST = "SQLAccountsList";
    private static final String USER_SERVER_INSTANCES = "userServerInstances";
    private static final String LOGGED_IN_USER = "loggedInUser";
    private static final String WRONG_PASSWORD = "because it does not exist or you do not have permission";

    @Resource
    private SuccessfulLoginValidator validator;
    @Resource
    private EmailBuilder emailBuilder;
    @Resource
    private EmailSender emailSender;

    @RequestMapping(method = RequestMethod.POST)
    public ModelAndView onSubmit(@ModelAttribute(SERVER_DETAILS) UserServerDetailsTO userServerDetailsTO, BindingResult result, HttpServletRequest request, ModelAndView modelAndView, HttpSession session) {
        validator.validate(userServerDetailsTO, result);
        if (!result.hasErrors()) {
            logger.debug("Validation passed. Changing password.");
            try {
                getUserEmailAndVersion(userServerDetailsTO, session);
                if (dao.runScriptByVersion(userServerDetailsTO)) {
                    logger.debug("Password successfully changed. Sending password confirmation.");
                    if (emailSender.sendEmail(emailBuilder.tokenizeRecipients(userServerDetailsTO.getEmailId()),
                            emailBuilder.tokenizeRecipients(emailBuilder.buildPasswordChangeConfirmationCC()),
                            emailBuilder.buildPasswordChangeConfirmationSubject(),
                            emailBuilder.buildPasswordChangeConfirmationEmailBody(userServerDetailsTO.getSelectedSQLAccount(), userServerDetailsTO.getSelectedServerInstance()),
                            emailBuilder.buildPasswordChangeConfirmationSendFrom())) {
                        logger.debug("Email confirmation sent successfully.");
                        modelAndView.setViewName(PASSWORD_CHANGE_VIEW_NAME);
                        return modelAndView;
                    } else {
                        result.reject("emailError", SqlServerToolErrors.EMAIL_ERROR);
                    }
                } else {
                    logger.debug("Password could not be changed.");
                    result.reject("passwordChangeError", SqlServerToolErrors.ERROR_MESSAGE);
                    result.reject("ContactSupportError", SqlServerToolErrors.CONTACT_SUPPORT);
                }
            } catch (Exception exception) {
                modelAndView = handleException(request, exception);
                if (exception.getMessage().contains(WRONG_PASSWORD)) {
                    result.reject("passwordChangeError", SqlServerToolErrors.CURRENT_PASSWORD_IS_WRONG);
                } else {
                    result.reject("passwordChangeError", SqlServerToolErrors.ERROR_MESSAGE);
                    result.reject("ContactSupportError", SqlServerToolErrors.CONTACT_SUPPORT);
                }
            }
        }
        modelAndView.setViewName(VIEW_NAME);
        return modelAndView;
    }

    @RequestMapping(method = RequestMethod.GET)
    public ModelAndView gettingTheSuccessfulLoginView(@ModelAttribute(SERVER_DETAILS) UserServerDetailsTO userServerDetailsTO, HttpServletRequest request, ModelAndView modelAndView, HttpSession session) throws Exception {
        userServerDetailsTO.setRefreshSQLAccounts(false);
        modelAndView.getModelMap().addAttribute(SERVER_DETAILS, userServerDetailsTO);
        modelAndView.getModelMap().addAttribute(SQL_ACCOUNTS_LIST, session.getAttribute(SQL_ACCOUNTS_LIST));
        modelAndView.setViewName(VIEW_NAME);
        return modelAndView;
    }

    @RequestMapping(method = RequestMethod.POST, params = "refreshSQLAccounts=true")
    public ModelAndView refreshSQLAccounts(@ModelAttribute(SERVER_DETAILS) UserServerDetailsTO userServerDetailsTO, HttpServletRequest request, ModelAndView modelAndView, HttpSession session) throws Exception {
        String serverInstance = userServerDetailsTO.getSelectedServerInstance();
        userServerDetailsTO.setRefreshSQLAccounts(false);
        modelAndView.getModelMap().addAttribute(SERVER_DETAILS, userServerDetailsTO);
        List<UserSQLAccountsTO> userSQLAccountsTOList = getSQLAccountsByServerInstance(request, serverInstance, session);
        session.setAttribute(SQL_ACCOUNTS_LIST, userSQLAccountsTOList);
        modelAndView.getModelMap().addAttribute(SQL_ACCOUNTS_LIST, userSQLAccountsTOList);
        modelAndView.setViewName(VIEW_NAME);
        return modelAndView;
    }

    @ModelAttribute(LOGGED_IN_USER)
    protected String getLoggedInUserAttribute(HttpSession session) throws Exception {
        return getLoggedInUser(session).getFirstName() + " " + getLoggedInUser(session).getLastName();
    }

    @ModelAttribute(USER_SERVER_INSTANCES)
    protected List<UserServerInstancesTO> getUserServerInstances(HttpSession session) throws Exception {
        return (List<UserServerInstancesTO>) session.getAttribute(USER_SERVER_INSTANCES);
    }


    @ModelAttribute(SQL_ACCOUNTS_LIST)
    protected List<UserSQLAccountsTO> getSQLAccounts(HttpSession session) throws Exception {
        return (List<UserSQLAccountsTO>) session.getAttribute(SQL_ACCOUNTS_LIST);
    }

    private List<UserSQLAccountsTO> getSQLAccountsByServerInstance(HttpServletRequest request, String serverInstance, HttpSession session) throws Exception {

        try {
            return dao.getSQLAccountsByServerInstance(serverInstance, getLoggedInUser(session).getUserName());
        } catch (SQLException sqlException) {
            handleException(request, sqlException);
            return new ArrayList<UserSQLAccountsTO>();
        }

    }

    private void getUserEmailAndVersion(UserServerDetailsTO userServerDetailsTO, HttpSession session) {
        List<UserSQLAccountsTO> userSQLAccountsTOList = (List<UserSQLAccountsTO>) session.getAttribute(SQL_ACCOUNTS_LIST);
        for (UserSQLAccountsTO userSQLAccountsTO : userSQLAccountsTOList) {
            if (userSQLAccountsTO.getSqlAccountName().equals(userServerDetailsTO.getSelectedSQLAccount())) {
                userServerDetailsTO.setEmailId(userSQLAccountsTO.getEmailId());
                userServerDetailsTO.setVersion(userSQLAccountsTO.getVersion());
            }
        }
    }

    public void setValidator(SuccessfulLoginValidator validator) {
        this.validator = validator;
    }

    public void setEmailBuilder(EmailBuilder emailBuilder) {
        this.emailBuilder = emailBuilder;
    }

    public void setEmailSender(EmailSender emailSender) {
        this.emailSender = emailSender;
    }
}
