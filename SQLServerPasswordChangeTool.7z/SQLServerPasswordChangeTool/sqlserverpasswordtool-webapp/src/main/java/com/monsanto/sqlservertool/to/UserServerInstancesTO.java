package com.monsanto.sqlservertool.to;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: JHUER
 * Date: 16/10/12
 * Time: 05:05 PM
 * To change this template use File | Settings | File Templates.
 */
public class UserServerInstancesTO {
    private String serverInstance;
    private List<UserSQLAccountsTO> userSqlAccounts;

    public String getServerInstance() {
        return serverInstance;
    }

    public void setServerInstance(String serverInstance) {
        this.serverInstance = serverInstance;
    }

    public List<UserSQLAccountsTO> getUserSqlAccounts() {
        return userSqlAccounts;
    }

    public void setUserSqlAccount(List<UserSQLAccountsTO> userSqlAccounts) {
        this.userSqlAccounts = userSqlAccounts;
    }
}
