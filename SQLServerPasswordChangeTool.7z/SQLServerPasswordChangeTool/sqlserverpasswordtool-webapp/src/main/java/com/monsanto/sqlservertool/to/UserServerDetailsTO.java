package com.monsanto.sqlservertool.to;

import java.io.Serializable;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: rrpand5
 * Date: 10/15/12
 * Time: 7:19 PM
 * To change this template use File | Settings | File Templates.
 */
public class UserServerDetailsTO implements Serializable {
    private static final long serialVersionUID = 217429372743298014L;
    private String currentPassword;
    private String selectedServerInstance;
    private String selectedSQLAccount;
    private boolean refreshSQLAccounts;
    private String emailId;
    private String newPassword;
    private String confirmNewPassword;
    private String version;

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public String getNewPassword() {
        return newPassword;
    }

    public void setNewPassword(String newPassword) {
        this.newPassword = newPassword;
    }

    public String getConfirmNewPassword() {
        return confirmNewPassword;
    }

    public void setConfirmNewPassword(String confirmNewPassword) {
        this.confirmNewPassword = confirmNewPassword;
    }

    public String getEmailId() {
        return emailId;
    }

    public void setEmailId(String emailId) {
        this.emailId = emailId;
    }

    public boolean isRefreshSQLAccounts() {
        return refreshSQLAccounts;
    }

    public void setRefreshSQLAccounts(boolean refreshSQLAccounts) {
        this.refreshSQLAccounts = refreshSQLAccounts;
    }

    public String getCurrentPassword() {
        return currentPassword;
    }

    public void setCurrentPassword(String currentPassword) {
        this.currentPassword = currentPassword;
    }

    public String getSelectedServerInstance() {
        return selectedServerInstance;
    }

    public void setSelectedServerInstance(String selectedServerInstance) {
        this.selectedServerInstance = selectedServerInstance;
    }

    public String getSelectedSQLAccount() {
        return selectedSQLAccount;
    }

    public void setSelectedSQLAccount(String selectedSQLAccount) {
        this.selectedSQLAccount = selectedSQLAccount;
    }
}
