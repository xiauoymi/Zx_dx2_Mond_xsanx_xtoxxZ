package com.monsanto.sqlservertool.view.controller;

import com.monsanto.sqlservertool.dbconnection.SQLServerToolDAO;
import com.monsanto.sqlservertool.to.UserDetailsTO;
import com.monsanto.sqlservertool.to.UserSQLAccountsTO;
import com.monsanto.sqlservertool.to.UserServerDetailsTO;
import com.monsanto.sqlservertool.to.UserServerInstancesTO;
import com.monsanto.sqlservertool.utils.EmailBuilder;
import com.monsanto.sqlservertool.utils.EmailSender;
import com.monsanto.sqlservertool.view.validator.SuccessfulLoginValidator;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpSession;
import org.springframework.validation.BindException;
import org.springframework.validation.BindingResult;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpSession;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import static junit.framework.Assert.assertEquals;
import static junit.framework.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/**
 * Created by IntelliJ IDEA.
 * User: JHUER
 * Date: 16/10/12
 * Time: 10:40 AM
 * To change this template use File | Settings | File Templates.
 */
@RunWith(MockitoJUnitRunner.class)
public class SuccessfulLoginController_UT {

    private SuccessfulLoginValidator validator;

    private MockHttpServletRequest request;
    private BindingResult result;
    private SuccessfulLoginController controller;
    private SQLServerToolDAO dao;
    private EmailBuilder emailBuilder;
    private EmailSender emailSender;
    private HttpSession session;

    private final static String VIEW_NAME = "/successfulLogin";
    private static final String SERVER_DETAILS = "serverDetails";
    private static final String SQL_ACCOUNTS_LIST = "SQLAccountsList";
    private static final String USER_SERVER_INSTANCES = "userServerInstances";
    private static final String LOGGED_IN_USER = "loggedInUser";
    private final static String PASSWORD_CHANGE_VIEW_NAME = "/passwordChangeConfirmation";


    @Before
    public void setUp() {
        session = new MockHttpSession();
        request = new MockHttpServletRequest();
        dao = Mockito.mock(SQLServerToolDAO.class);
        validator = new SuccessfulLoginValidator();
        result = Mockito.mock(BindingResult.class);
        controller = new SuccessfulLoginController();
        emailBuilder = Mockito.mock(EmailBuilder.class);
        emailSender = Mockito.mock(EmailSender.class);
        controller.setDao(dao);
        controller.setValidator(validator);
        controller.setEmailBuilder(emailBuilder);
        controller.setEmailSender(emailSender);
    }

    @Test
    public void getSQLAccounts_ReturnsASQLAccountList_WhenTheListHadBeenSetInSession() throws Exception {

        session.setAttribute(SQL_ACCOUNTS_LIST, createSQLAccountsList());

        List<UserSQLAccountsTO> userSQLAccountsTOList = controller.getSQLAccounts(session);

        assertNotNull(userSQLAccountsTOList);
        assertEquals(userSQLAccountsTOList.size(), 2);
        assertEquals(userSQLAccountsTOList.get(1).getNtId(), "JHUER,JVALE1");
    }

    @Test
    public void getSQLAccounts_ReturnsNull_WhenTheListHadNotBeenSetInSession() throws Exception {

        List<UserSQLAccountsTO> userSQLAccountsTOList = controller.getSQLAccounts(session);

        assertNull(userSQLAccountsTOList);
    }

    @Test
    public void getUserServerInstances_ReturnsAServerInstancesList_WhenTheListHadBeenSetInSession() throws Exception {
        session.setAttribute(USER_SERVER_INSTANCES, createServerInstancesList());

        List<UserServerInstancesTO> userServerInstancesTOList = controller.getUserServerInstances(session);

        assertNotNull(userServerInstancesTOList);
        assertEquals(userServerInstancesTOList.size(), 2);
        assertEquals(userServerInstancesTOList.get(1).getServerInstance(), "ServerInstance1");
        assertEquals(userServerInstancesTOList.get(1).getUserSqlAccounts().size(), 2);

    }

    @Test
    public void getUserServerInstances_ReturnsNull_WhenTheListHadNotBeenSetInSession() throws Exception {

        List<UserServerInstancesTO> userServerInstancesTOList = controller.getUserServerInstances(session);

        assertNull(userServerInstancesTOList);
    }

    @Test
    public void getLoggedInUser_ReturnsUser_WhenUserHadBeenSetInSession() throws Exception {
        UserDetailsTO userDetailsTO = new UserDetailsTO();
        userDetailsTO.setUserName("jhuer");
        userDetailsTO.setUserEmail("aerisirea@hotmail.com");
        userDetailsTO.setFirstName("Jackeline");
        userDetailsTO.setLastName("Huerta");
        session.setAttribute(LOGGED_IN_USER, userDetailsTO);

        String loggedInUser = controller.getLoggedInUserAttribute(session);

        assertNotNull(loggedInUser);
        assertEquals(loggedInUser, "Jackeline Huerta");
    }

    @Test
    public void refreshSQLAccounts_ReturnsModelAndViewWithSQLAccountsList() throws Exception {
        UserDetailsTO userDetailsTO = new UserDetailsTO();
        String user = "jhuer";
        userDetailsTO.setUserName(user);
        userDetailsTO.setUserEmail("aerisirea@hotmail.com");
        userDetailsTO.setFirstName("Jackeline");
        userDetailsTO.setLastName("Huerta");
        session.setAttribute(LOGGED_IN_USER, userDetailsTO);
        UserServerDetailsTO userServerDetailsTO = new UserServerDetailsTO();
        String server = "ServerInstanceSelected";
        userServerDetailsTO.setSelectedServerInstance(server);
        ModelAndView modelAndView = new ModelAndView();
        when(dao.getSQLAccountsByServerInstance(server, user)).thenReturn(createSQLAccountsList());

        ModelAndView modelAndViewResult = controller.refreshSQLAccounts(userServerDetailsTO, request, modelAndView, session);

        assertNotNull(modelAndViewResult);
        assertEquals(modelAndView, modelAndViewResult);
        assertEquals(modelAndViewResult.getViewName(), VIEW_NAME);
        assertNotNull(modelAndView.getModelMap().get(SERVER_DETAILS));
        assertNotNull(modelAndView.getModelMap().get(SQL_ACCOUNTS_LIST));
        List<UserSQLAccountsTO> sqlAccountsTOList = (List<UserSQLAccountsTO>) session.getAttribute(SQL_ACCOUNTS_LIST);
        assertNotNull(sqlAccountsTOList);
        assertEquals(sqlAccountsTOList.size(), 2);

    }

    @Test
    public void gettingTheSuccessfulLoginView() throws Exception {
        session.setAttribute(SQL_ACCOUNTS_LIST, createSQLAccountsList());
        session.setAttribute(USER_SERVER_INSTANCES, createServerInstancesList());
        UserServerDetailsTO userServerDetailsTO = new UserServerDetailsTO();
        String server = "ServerInstanceSelected";
        userServerDetailsTO.setSelectedServerInstance(server);
        ModelAndView modelAndView = new ModelAndView();

        ModelAndView view = controller.gettingTheSuccessfulLoginView(userServerDetailsTO, request, modelAndView, session);

        assertNotNull(view);
        assertNotNull(view.getModelMap().get(SERVER_DETAILS));
        assertNotNull(view.getModelMap().get(SQL_ACCOUNTS_LIST));
        List<UserSQLAccountsTO> sqlAccountsTOList = (List<UserSQLAccountsTO>) session.getAttribute(SQL_ACCOUNTS_LIST);
        assertNotNull(sqlAccountsTOList);
        assertEquals(sqlAccountsTOList.size(), 2);
        assertEquals(modelAndView.getViewName(), VIEW_NAME);
    }


    @Test
    public void onSubmit_ReturnsPasswordChangedViewName() throws Exception {
        session.setAttribute(SQL_ACCOUNTS_LIST, createSQLAccountsList());
        session.setAttribute(USER_SERVER_INSTANCES, createServerInstancesList());
        UserServerDetailsTO userServerDetailsTO = new UserServerDetailsTO();
        String server = "ServerInstance1";
        userServerDetailsTO.setSelectedServerInstance(server);
        String sqlAccount = "SQLAccount2";
        String emailSubject = "EmailSubject";
        String[] copyTo = null;
        String emailBody = "Email Body to send";
        String from = "admin@monsanto.com";
        userServerDetailsTO.setSelectedSQLAccount(sqlAccount);
        ModelAndView modelAndView = new ModelAndView();
        when(dao.runScriptByVersion(userServerDetailsTO)).thenReturn(true);
        String tokenizerEmails[] = {"jose.luis.valencia@monsanto.com", "jacqueline.huerta.gonzalez@monsanto.com"};
        String emailsToSend = "jose.luis.valencia@monsanto.com,jacqueline.huerta.gonzalez@monsanto.com";
        when(emailBuilder.tokenizeRecipients(emailsToSend)).thenReturn(tokenizerEmails);
        when(emailBuilder.buildPasswordChangeConfirmationSubject()).thenReturn(emailSubject);
        when(emailBuilder.buildPasswordChangeConfirmationSendFrom()).thenReturn(from);
        when(emailBuilder.buildPasswordChangeConfirmationEmailBody(sqlAccount,server)).thenReturn(emailBody);
        when(emailSender.sendEmail(tokenizerEmails, copyTo, emailSubject, emailBody, from)).thenReturn(true);

        ModelAndView view = controller.onSubmit(userServerDetailsTO, result, request, modelAndView, session);

        assertNotNull(view);
        assertEquals(view.getViewName(), PASSWORD_CHANGE_VIEW_NAME);
        verify(emailSender).sendEmail(tokenizerEmails, copyTo, emailSubject, emailBody, from);
        verify(emailBuilder).tokenizeRecipients(emailsToSend);
        verify(emailBuilder).buildPasswordChangeConfirmationSubject();
        verify(emailBuilder).buildPasswordChangeConfirmationSendFrom();
        verify(emailBuilder).buildPasswordChangeConfirmationEmailBody(sqlAccount,server);
        verify(dao).runScriptByVersion(userServerDetailsTO);
        assertNotNull(userServerDetailsTO.getEmailId());
        assertNotNull(userServerDetailsTO.getVersion());
    }

    @Test
    public void onSubmit_ReturnsPasswordChangedErrorViewName_WhenPasswordWasNotChanged() throws Exception {
        session.setAttribute(SQL_ACCOUNTS_LIST, createSQLAccountsList());
        session.setAttribute(USER_SERVER_INSTANCES, createServerInstancesList());
        UserServerDetailsTO userServerDetailsTO = new UserServerDetailsTO();
        String server = "ServerInstance1";
        userServerDetailsTO.setSelectedServerInstance(server);
        String sqlAccount = "SQLAccount2";
        userServerDetailsTO.setSelectedSQLAccount(sqlAccount);
        ModelAndView modelAndView = new ModelAndView();
        when(dao.runScriptByVersion(userServerDetailsTO)).thenReturn(false);

        ModelAndView view = controller.onSubmit(userServerDetailsTO, result, request, modelAndView, session);

        assertNotNull(view);
        assertEquals(view.getViewName(), VIEW_NAME);
        assertNotNull(userServerDetailsTO.getEmailId());
        assertNotNull(userServerDetailsTO.getVersion());

    }

    @Test
    public void onSubmit_ReturnsEmailErrorViewName_WhenEmailWasNotSent() throws Exception {
        session.setAttribute(SQL_ACCOUNTS_LIST, createSQLAccountsList());
        session.setAttribute(USER_SERVER_INSTANCES, createServerInstancesList());
        UserServerDetailsTO userServerDetailsTO = new UserServerDetailsTO();
        String server = "ServerInstance1";
        userServerDetailsTO.setSelectedServerInstance(server);
        String sqlAccount = "SQLAccount2";
        String emailSubject = "EmailSubject";
        String[] copyTo = null;
        String emailBody = "Email Body to send";
        String from = "admin@monsanto.com";
        userServerDetailsTO.setSelectedSQLAccount(sqlAccount);
        ModelAndView modelAndView = new ModelAndView();
        when(dao.runScriptByVersion(userServerDetailsTO)).thenReturn(true);
        String tokenizerEmails[] = {"jose.luis.valencia@monsanto.com", "jacqueline.huerta.gonzalez@monsanto.com"};
        String emailsToSend = "jose.luis.valencia@monsanto.com,jacqueline.huerta.gonzalez@monsanto.com";
        when(emailBuilder.tokenizeRecipients(emailsToSend)).thenReturn(tokenizerEmails);
        when(emailBuilder.buildPasswordChangeConfirmationSubject()).thenReturn(emailSubject);
        when(emailBuilder.buildPasswordChangeConfirmationSendFrom()).thenReturn(from);
        when(emailBuilder.buildPasswordChangeConfirmationEmailBody(sqlAccount,server)).thenReturn(emailBody);
        when(emailSender.sendEmail(tokenizerEmails, copyTo, emailSubject, emailBody, from)).thenReturn(false);

        ModelAndView view = controller.onSubmit(userServerDetailsTO, result, request, modelAndView, session);

        assertNotNull(view);
        assertEquals(view.getViewName(), VIEW_NAME);
        verify(emailSender).sendEmail(tokenizerEmails, copyTo, emailSubject, emailBody, from);
        verify(emailBuilder).tokenizeRecipients(emailsToSend);
        verify(emailBuilder).buildPasswordChangeConfirmationSubject();
        verify(emailBuilder).buildPasswordChangeConfirmationSendFrom();
        verify(emailBuilder).buildPasswordChangeConfirmationEmailBody(sqlAccount,server);
        verify(dao).runScriptByVersion(userServerDetailsTO);
        assertNotNull(userServerDetailsTO.getEmailId());
        assertNotNull(userServerDetailsTO.getVersion());

    }

    @Test
    public void onSubmit_ReturnsPasswordChangedErrorViewName_WhenDaoThrowsAnException() throws Exception {
        session.setAttribute(SQL_ACCOUNTS_LIST, createSQLAccountsList());
        session.setAttribute(USER_SERVER_INSTANCES, createServerInstancesList());
        UserServerDetailsTO userServerDetailsTO = new UserServerDetailsTO();
        String server = "ServerInstance1";
        userServerDetailsTO.setSelectedServerInstance(server);
        String sqlAccount = "SQLAccount2";
        userServerDetailsTO.setSelectedSQLAccount(sqlAccount);
        ModelAndView modelAndView = new ModelAndView();
        when(dao.runScriptByVersion(userServerDetailsTO)).thenThrow(new SQLException("because it does not exist or you do not have permission"));

        ModelAndView view = controller.onSubmit(userServerDetailsTO, result, request, modelAndView, session);

        assertNotNull(view);
        assertEquals(view.getViewName(), VIEW_NAME);
        assertNotNull(userServerDetailsTO.getEmailId());
        assertNotNull(userServerDetailsTO.getVersion());
    }

    @Test
    public void onSubmit_ReturnsViewName_WhenValidatorReturnedValidationErrors() throws Exception {
        session.setAttribute(SQL_ACCOUNTS_LIST, createSQLAccountsList());
        session.setAttribute(USER_SERVER_INSTANCES, createServerInstancesList());
        UserServerDetailsTO userServerDetailsTO = new UserServerDetailsTO();
        String server = "ServerInstance1";
        userServerDetailsTO.setSelectedServerInstance(server);
        result = new BindException(new UserServerDetailsTO(), "UserServerDetailsTO");
        ModelAndView modelAndView = new ModelAndView();

        ModelAndView view = controller.onSubmit(userServerDetailsTO, result, request, modelAndView, session);

        assertNotNull(view);
        assertEquals(view.getViewName(), VIEW_NAME);
    }


    private List<UserSQLAccountsTO> createSQLAccountsList() {
        List<UserSQLAccountsTO> userSQLAccountsTOList = new ArrayList<UserSQLAccountsTO>();
        UserSQLAccountsTO userSQLAccountsTO = new UserSQLAccountsTO();
        userSQLAccountsTO.setNtId("JHUER");
        userSQLAccountsTO.setEmailId("jacqueline.huerta.gonzalez@monsanto.com");
        userSQLAccountsTO.setSqlAccountName("SQLAccount1");
        userSQLAccountsTOList.add(userSQLAccountsTO);
        userSQLAccountsTO = new UserSQLAccountsTO();
        userSQLAccountsTO.setNtId("JHUER,JVALE1");
        userSQLAccountsTO.setEmailId("jose.luis.valencia@monsanto.com,jacqueline.huerta.gonzalez@monsanto.com");
        userSQLAccountsTO.setSqlAccountName("SQLAccount2");
        userSQLAccountsTO.setVersion("2008");
        userSQLAccountsTOList.add(userSQLAccountsTO);
        return userSQLAccountsTOList;
    }

    private List<UserServerInstancesTO> createServerInstancesList() {
        List<UserServerInstancesTO> userServerInstancesTOList = new ArrayList<UserServerInstancesTO>();
        UserServerInstancesTO serverInstancesTO = new UserServerInstancesTO();
        serverInstancesTO.setServerInstance("ServerInstance1");
        serverInstancesTO.setUserSqlAccount(createSQLAccountsList());
        userServerInstancesTOList.add(serverInstancesTO);
        serverInstancesTO = new UserServerInstancesTO();
        serverInstancesTO.setServerInstance("ServerInstance1");
        serverInstancesTO.setUserSqlAccount(createSQLAccountsList());
        userServerInstancesTOList.add(serverInstancesTO);
        return userServerInstancesTOList;
    }

}
