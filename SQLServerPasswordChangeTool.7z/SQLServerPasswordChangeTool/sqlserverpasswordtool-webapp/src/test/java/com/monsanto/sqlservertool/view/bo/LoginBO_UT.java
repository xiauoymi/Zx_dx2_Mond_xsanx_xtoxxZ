package com.monsanto.sqlservertool.view.bo;

import com.monsanto.sqlservertool.adauth.ADAuthenticator;
import com.monsanto.sqlservertool.to.UserDetailsTO;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.HashMap;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/**
 * Created by IntelliJ IDEA.
 * User: JHUER
 * Date: 25/10/12
 * Time: 03:52 PM
 * To change this template use File | Settings | File Templates.
 */
@RunWith(MockitoJUnitRunner.class)
public class LoginBO_UT {
    private ADAuthenticator adAuthenticator;
    private LoginBO loginBO;

    @Before
    public void setUp() {
        adAuthenticator = Mockito.mock(ADAuthenticator.class);
        loginBO = new LoginBO();
        loginBO.setAdAuthenticator(adAuthenticator);
    }

    @Test
    public void authenticateADUser_ReturnsTrue_WhenUserIsValid() throws Exception {
        UserDetailsTO userDetails = new UserDetailsTO();
        userDetails.setUserName("jhuer");
        userDetails.setUserDomain("NORTH_AMERCIA");
        userDetails.setPassword("Pa$$w0rd");
        when(adAuthenticator.authenticate(userDetails)).thenReturn(new HashMap());

        boolean validUser = loginBO.authenticateADUser(userDetails);

        assertTrue(validUser);
        verify(adAuthenticator).authenticate(userDetails);

    }
    @Test
    public void authenticateADUser_ReturnsFalse_WhenUserIsInvalid() throws Exception {
        UserDetailsTO userDetails = new UserDetailsTO();
        userDetails.setUserName("jhuer");
        userDetails.setUserDomain("NORTH_AMERCIA");
        userDetails.setPassword("Pa$$w0rd");
        when(adAuthenticator.authenticate(userDetails)).thenReturn(null);

        boolean validUser = loginBO.authenticateADUser(userDetails);

        assertFalse(validUser);
        verify(adAuthenticator).authenticate(userDetails);

    }
}
