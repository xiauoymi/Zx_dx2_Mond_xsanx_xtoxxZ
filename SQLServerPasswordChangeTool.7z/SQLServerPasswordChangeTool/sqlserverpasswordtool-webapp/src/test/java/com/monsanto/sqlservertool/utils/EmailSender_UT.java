package com.monsanto.sqlservertool.utils;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;

import javax.mail.Message;
import javax.mail.MessagingException;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.assertFalse;

/**
 * Created by IntelliJ IDEA.
 * User: JLVALE1
 * Date: 10/24/12
 * Time: 3:50 PM
 * To change this template use File | Settings | File Templates.
 */
@RunWith(MockitoJUnitRunner.class)
public class EmailSender_UT {
    private boolean messageSentConfirmation;
    EmailSender sender;
    EmailConfig config;
    EmailBuilder builder;

    @Before
    public void setUp(){
        messageSentConfirmation = false;
        sender = new MockEmailSender();
        config = new EmailConfig();
        builder = new EmailBuilder();
        sender.setEmailConfig(config);
        builder.setEmailConfig(config);
    }

    @Test
    public void sendEmailToOneRecipient(){
        sender.sendEmail(builder.tokenizeRecipients("JLVALE1@monsanto.com"), null,
                                builder.buildPasswordChangeConfirmationSubject(),
                                    builder.buildPasswordChangeConfirmationEmailBody("TestAccount","TestServer"),
                                        "no-reply@monsanto.com");
        assertTrue(messageSentConfirmation);
    }

    @Test
    public void sendEmailToMultipleRecipientsAndCC(){
        sender.sendEmail(builder.tokenizeRecipients("JLVALE1@monsanto.com;JHUER@monsanto.com"),
                            builder.tokenizeRecipients("DL-1000-SQLSERVERADMIN@monsanto.com"),
                                builder.buildPasswordChangeConfirmationSubject(),
                                    builder.buildPasswordChangeConfirmationEmailBody("TestAccount","TestServer"),
                                        "no-reply@monsanto.com");
        assertTrue(messageSentConfirmation);
    }

    @Test
    public void sendEmail_WhenNullRecipientsAndCC(){
        sender.sendEmail(null, null,
                                builder.buildPasswordChangeConfirmationSubject(),
                                    builder.buildPasswordChangeConfirmationEmailBody("TestAccount","TestServer"),
                                        "no-reply@monsanto.com");
        assertFalse(messageSentConfirmation);
    }

    @Test
    public void getConfig(){
        assertEquals(sender.getEmailConfig(),config);
    }

    public class MockEmailSender extends EmailSender{
        @Override
        protected void sendMessage(Message message) throws MessagingException{
            messageSentConfirmation = true;
        }
    }
}
