package com.monsanto.sqlservertool.utils;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;

import static org.junit.Assert.assertEquals;

/**
 * Created by IntelliJ IDEA.
 * User: JLVALE1
 * Date: 10/24/12
 * Time: 9:52 AM
 * To change this template use File | Settings | File Templates.
 */
@RunWith(MockitoJUnitRunner.class)
public class EmailConfig_UT {
    EmailConfig config;

    @Before
    public void setUp(){
         config = new EmailConfig();
    }

    @Test
    public void getExistingProperty(){
        assertEquals(config.getProperty("sendMailHost"),"mail.monsanto.com");
    }

    @Test
    public void getNonExistingProperty(){
        assertEquals(config.getProperty("whatever"),null);

    }

}
