package com.monsanto.sqlservertool.utils;

import com.monsanto.Util.EnvironmentHelper;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import static junit.framework.Assert.assertNotNull;

import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import static org.mockito.Mockito.*;
import java.util.Properties;

/**
 * Created by IntelliJ IDEA.
 * User: JLVALE1
 * Date: 10/25/12
 * Time: 3:07 PM
 * To change this template use File | Settings | File Templates.
 */
@RunWith(MockitoJUnitRunner.class)
public class EncryptionUtil_UT {
    private EncryptionUtil encryptionUtil;
    private Properties properties;
    private EnvironmentHelper helper;

    @Before
    public void setUp(){
        encryptionUtil = new EncryptionUtil();
        properties = new Properties();
        properties.setProperty("storageVar","MONCRYPTJV");
        properties.setProperty("appFolderName","SqlPwdTool");
        properties.setProperty("jtds.msmsql.database.passwordfile.dev","Dev_SqlPwdToolPassword.txt");
        properties.setProperty("jtds.msmsql.database.keyfile.dev","Dev_SqlPwdToolKey.txt");
    }

    @Test
    public void testGetPassword(){
        try{
            assertNotNull(encryptionUtil.getPassword(properties));
        }catch(Exception e){
            return;
        }
    }
}
