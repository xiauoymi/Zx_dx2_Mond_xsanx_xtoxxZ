package com.monsanto.sqlservertool.view.controller;

import com.monsanto.sqlservertool.dbconnection.SQLServerToolDAO;
import com.monsanto.sqlservertool.to.UserDetailsTO;
import com.monsanto.sqlservertool.utils.SqlServerToolConstants;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpSession;
import org.springframework.web.servlet.ModelAndView;

import java.sql.SQLException;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

/**
 * Created by IntelliJ IDEA.
 * User: JHUER
 * Date: 24/10/12
 * Time: 10:23 AM
 * To change this template use File | Settings | File Templates.
 */
@RunWith(MockitoJUnitRunner.class)
public class BaseController_UT {

    private MockHttpServletRequest request;
    private SQLServerToolDAO dao;
    private MockHttpSession session;
    private BaseController controller;
    private final static String ERROR_VIEW = "/error";

    @Before
    public void setUp() {
        request = new MockHttpServletRequest();
        dao = Mockito.mock(SQLServerToolDAO.class);
        session = new MockHttpSession();
        controller = new BaseController();
        controller.setDao(dao);
    }

    @Test
    public void getLoggedInUser_ReturnsLoggedInUser_WhenUserWasSetInSession() {
        UserDetailsTO user = new UserDetailsTO();
        user.setUserName("jhuer");
        user.setUserEmail("jacqueline.huerta.gonzalez@monsanto.com");
        session.setAttribute(SqlServerToolConstants.LOGGED_IN_USER, user);

        UserDetailsTO loggedInUser = controller.getLoggedInUser(session);

        assertNotNull(loggedInUser);
        assertEquals(loggedInUser.getUserName(), "jhuer");
    }

    @Test
    public void getLoggedInUser_ReturnsNull_WhenUserWasNotSetInSession() {

        UserDetailsTO loggedInUser = controller.getLoggedInUser(session);

        assertNull(loggedInUser);
    }

    @Test
    public void handleException() {
        SQLException exception = new SQLException("An Exception was thrown");

        ModelAndView view = controller.handleException(request, exception);

        assertNotNull(view);
        assertNotNull(request.getAttribute("exceptionStackTrace"));
    }

}
