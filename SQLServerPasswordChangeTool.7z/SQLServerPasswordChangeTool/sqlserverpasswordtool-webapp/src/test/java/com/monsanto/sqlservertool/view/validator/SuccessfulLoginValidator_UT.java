package com.monsanto.sqlservertool.view.validator;

import com.monsanto.sqlservertool.to.UserServerDetailsTO;
import com.monsanto.sqlservertool.utils.SqlServerToolErrors;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.validation.BindException;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;

import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

/**
 * Created by IntelliJ IDEA.
 * User: JHUER
 * Date: 22/10/12
 * Time: 09:06 AM
 * To change this template use File | Settings | File Templates.
 */
@RunWith(MockitoJUnitRunner.class)
public class SuccessfulLoginValidator_UT {
    SuccessfulLoginValidator validator;
    BindingResult errors;

    @Before
    public void setUp() {
        errors = new BindException(new UserServerDetailsTO(), "UserServerDetailsTO");
        validator = new SuccessfulLoginValidator();
    }

    @Test
    public void validate_ReturnsNoErrors_WhenUserServerDetailsIsCorrect() {
        UserServerDetailsTO userServerDetailsTO = new UserServerDetailsTO();
        userServerDetailsTO.setSelectedServerInstance("ServerInstance");
        userServerDetailsTO.setSelectedSQLAccount("SQLAccount");
        userServerDetailsTO.setCurrentPassword("onePassword");
        userServerDetailsTO.setNewPassword("Abcd123@");
        userServerDetailsTO.setConfirmNewPassword("Abcd123@");

        validator.validate(userServerDetailsTO, errors);

        assertTrue(!errors.hasErrors());
    }

    @Test
    public void validate_ReturnsErrors_WhenNoNewPassword() {
        UserServerDetailsTO userServerDetailsTO = new UserServerDetailsTO();
        userServerDetailsTO.setSelectedServerInstance("ServerInstance");
        userServerDetailsTO.setSelectedSQLAccount("SQLAccount");
        userServerDetailsTO.setCurrentPassword("onePassword");
        userServerDetailsTO.setNewPassword(null);
        userServerDetailsTO.setConfirmNewPassword("Abcd123@");

        validator.validate(userServerDetailsTO, errors);

        assertEquals(errors.getAllErrors().get(0).getCode(), SqlServerToolErrors.NEW_PASSWORD_REQUIRED);
    }

    @Test
    public void validate_ReturnsErrors_WhenRepeatedNewPassword() {
        UserServerDetailsTO userServerDetailsTO = new UserServerDetailsTO();
        userServerDetailsTO.setSelectedServerInstance("ServerInstance");
        userServerDetailsTO.setSelectedSQLAccount("SQLAccount");
        userServerDetailsTO.setCurrentPassword("Abcd123@");
        userServerDetailsTO.setNewPassword("Abcd123@");
        userServerDetailsTO.setConfirmNewPassword("Abcd123@");

        validator.validate(userServerDetailsTO, errors);

        assertEquals(errors.getAllErrors().get(0).getCode(), SqlServerToolErrors.REPEATED_PASSWORD);
    }

    @Test
    public void validate_ReturnsErrors_WhenPasswordIsTooShort() {
        UserServerDetailsTO userServerDetailsTO = new UserServerDetailsTO();
        userServerDetailsTO.setSelectedServerInstance("ServerInstance");
        userServerDetailsTO.setSelectedSQLAccount("SQLAccount");
        userServerDetailsTO.setCurrentPassword("Abcd123@");
        userServerDetailsTO.setNewPassword("Abcd12@");
        userServerDetailsTO.setConfirmNewPassword("Abcd12@");

        validator.validate(userServerDetailsTO, errors);

        assertEquals(errors.getAllErrors().get(0).getCode(), SqlServerToolErrors.SHORT_PASSWORD);
    }

    @Test
    public void validate_ReturnErrors_WhenNotEnoughPasswordStrenghtCategories() {
        UserServerDetailsTO userServerDetailsTO = new UserServerDetailsTO();
        userServerDetailsTO.setSelectedServerInstance("ServerInstance");
        userServerDetailsTO.setSelectedSQLAccount("SQLAccount");
        userServerDetailsTO.setCurrentPassword("Abcd1234@");
        userServerDetailsTO.setNewPassword("Abcdefgh");
        userServerDetailsTO.setConfirmNewPassword("Abcdefgh");

        validator.validate(userServerDetailsTO, errors);

        assertEquals(errors.getAllErrors().get(0).getCode(), SqlServerToolErrors.NON_COMPLIANT_PASSWORD);
    }

    @Test
    public void validate_ReturnsErrors_WhenNoSelectedServerInstanceIsSent() {
        UserServerDetailsTO userServerDetailsTO = new UserServerDetailsTO();
        userServerDetailsTO.setSelectedServerInstance(SqlServerToolErrors.SELECT_SERVER_INSTANCE);
        userServerDetailsTO.setSelectedSQLAccount("SQLAccount");
        userServerDetailsTO.setCurrentPassword("onePassword");
        userServerDetailsTO.setNewPassword("Abcd123@");
        userServerDetailsTO.setConfirmNewPassword("Abcd123@");

        validator.validate(userServerDetailsTO, errors);

        assertTrue(errors.hasErrors());
        assertEquals(errors.getErrorCount(), 1);
        List<ObjectError> errorList = errors.getAllErrors();
        assertEquals(errorList.get(0).getDefaultMessage(), SqlServerToolErrors.SERVER_INSTANCE_REQUIRED);

    }

    @Test
    public void validate_ReturnsNoErrors_WhenNoSelectedSQLAccountIsSent() {
        UserServerDetailsTO userServerDetailsTO = new UserServerDetailsTO();
        userServerDetailsTO.setSelectedServerInstance("ServerInstance");
        userServerDetailsTO.setSelectedSQLAccount(SqlServerToolErrors.SELECT_SQL_ACCOUNT);
        userServerDetailsTO.setCurrentPassword("onePassword");
        userServerDetailsTO.setNewPassword("Abcd123@");
        userServerDetailsTO.setConfirmNewPassword("Abcd123@");

        validator.validate(userServerDetailsTO, errors);

        assertTrue(errors.hasErrors());
        assertEquals(errors.getErrorCount(), 1);
        List<ObjectError> errorList = errors.getAllErrors();
        assertEquals(errorList.get(0).getDefaultMessage(), SqlServerToolErrors.SQL_ACCOUNT_REQUIRED);
    }

    @Test
    public void validate_ReturnsNoErrors_WhenNoCurrentPasswordIsSent() {
        UserServerDetailsTO userServerDetailsTO = new UserServerDetailsTO();
        userServerDetailsTO.setSelectedServerInstance("ServerInstance");
        userServerDetailsTO.setSelectedSQLAccount("SQLAccount");
        userServerDetailsTO.setCurrentPassword(null);
        userServerDetailsTO.setNewPassword("Abcd123@");
        userServerDetailsTO.setConfirmNewPassword("Abcd123@");

        validator.validate(userServerDetailsTO, errors);

        assertTrue(errors.hasErrors());
        assertEquals(errors.getErrorCount(), 1);
        List<ObjectError> errorList = errors.getAllErrors();
        assertEquals(errorList.get(0).getDefaultMessage(), SqlServerToolErrors.CURRENT_PASSWORD_REQUIRED);

    }

    @Test
    public void supports() {
        assertFalse(validator.supports(this.getClass()));
    }

}
