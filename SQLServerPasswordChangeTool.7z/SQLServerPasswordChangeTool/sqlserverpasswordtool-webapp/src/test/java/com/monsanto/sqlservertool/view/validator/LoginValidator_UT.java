package com.monsanto.sqlservertool.view.validator;

import com.monsanto.sqlservertool.to.UserDetailsTO;
import com.monsanto.sqlservertool.utils.SqlServerToolErrors;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.validation.BindException;
import org.springframework.validation.BindingResult;
import static org.junit.Assert.*;

/**
 * Created by IntelliJ IDEA.
 * User: JHUER
 * Date: 22/10/12
 * Time: 09:06 AM
 * To change this template use File | Settings | File Templates.
 */
@RunWith(MockitoJUnitRunner.class)
public class LoginValidator_UT {
    LoginValidator validator;
    BindingResult errors;

    @Before
    public void setUp() {
        errors = new BindException(new UserDetailsTO(), "UserDetailsTO");
        validator = new LoginValidator();
    }

    @Test
    public void validate_ReturnsNoErrors_WhenUserDetailsIsCorrect() {
        UserDetailsTO userDetailsTO = new UserDetailsTO();
        userDetailsTO.setUserName("jhuer");
        userDetailsTO.setPassword("passW0rd");

        validator.validate(userDetailsTO, errors);

        assertTrue(!errors.hasErrors());
    }

    @Test
    public void validate_ReturnsErrors_WhenNoPasswordWasTyped(){
        UserDetailsTO userDetailsTO = new UserDetailsTO();
        userDetailsTO.setUserName("jhuer");

        validator.validate(userDetailsTO, errors);

        assertEquals(errors.getAllErrors().get(0).getCode(),SqlServerToolErrors.PASSWORD_REQUIRED);
    }

    @Test
    public void supports(){
        assertFalse(validator.supports(this.getClass()));
    }

}
