package com.monsanto.sqlservertool.utils;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;

import static org.junit.Assert.assertEquals;

/**
 * Created by IntelliJ IDEA.
 * User: JLVALE1
 * Date: 10/24/12
 * Time: 2:28 PM
 * To change this template use File | Settings | File Templates.
 */
@RunWith(MockitoJUnitRunner.class)
public class EmailBuilder_UT {
    EmailBuilder builder;
    EmailConfig config;
    @Before
    public void setUp(){
        builder = new EmailBuilder();
        config = new EmailConfig();
        builder.setEmailConfig(config);
    }

    @Test
    public void buildPasswordBody(){
        assertEquals(builder.buildPasswordChangeConfirmationEmailBody("TestAccount","TestServer"),
                        config.getProperty("confirmationEmailBody1") + " TestAccount " + config.getProperty("confirmationEmailBody2") + " " +
                                config.getProperty("confirmationEmailBody3") + " TestServer.");
    }

    @Test
    public void buildPasswordBody_WhenAccountAndServerAreNull(){
        assertEquals(builder.buildPasswordChangeConfirmationEmailBody(null,null),
                        config.getProperty("confirmationEmailBody1") + "  " + config.getProperty("confirmationEmailBody2") + " " +
                                config.getProperty("confirmationEmailBody3") + " .");
    }

    @Test
    public void buildSubject(){
        assertEquals(builder.buildPasswordChangeConfirmationSubject(), config.getProperty("confirmationEmailSubject"));
    }

    @Test
    public void buildSendFrom(){
        assertEquals(builder.buildPasswordChangeConfirmationSendFrom(), config.getProperty("confirmationEmailSentFrom"));
    }

    @Test
    public void buildCC(){
        assertEquals(builder.buildPasswordChangeConfirmationCC(), config.getProperty("confirmationEmailSentFrom"));
    }

    @Test
    public void tokenizeRecipients(){
        assertEquals(builder.tokenizeRecipients("mail1@abc.com;mail2@abc.com").length, 2);
    }

    @Test
    public void tokenizeRecipients_WhenRecipientsIsNull(){
        assertEquals(builder.tokenizeRecipients(null).length, 0);
    }

    @Test
    public void getConfig(){
        assertEquals(builder.getEmailConfig(),config);
    }
}
