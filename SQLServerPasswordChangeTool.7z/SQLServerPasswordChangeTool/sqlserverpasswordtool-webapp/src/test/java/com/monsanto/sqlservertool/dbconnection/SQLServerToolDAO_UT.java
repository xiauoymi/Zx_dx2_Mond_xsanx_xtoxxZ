package com.monsanto.sqlservertool.dbconnection;

import com.monsanto.sqlservertool.to.UserSQLAccountsTO;
import com.monsanto.sqlservertool.to.UserServerDetailsTO;
import com.monsanto.sqlservertool.to.UserServerInstancesTO;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import static org.junit.Assert.*;
import static org.mockito.Mockito.when;

/**
 * Created by IntelliJ IDEA.
 * User: JHUER
 * Date: 22/10/12
 * Time: 08:45 AM
 * To change this template use File | Settings | File Templates.
 */
@RunWith(MockitoJUnitRunner.class)
public class SQLServerToolDAO_UT {
    private static final String USER = "DBA_PWDCHNG_DEV";
    private static final String PASSWORD = "Abc123@";
    private DataSource dataSource;
    private SQLServerToolDAO dao;
    private Connection conn;
    private static final String DRIVER = "weblogic.jdbc.sqlserver.SQLServerDriver";
    private static final String URL = "jdbc:bea:sqlserver://MSSQLMGMT\\MGMT2008:1433";
    private JtdsJdbcConnection jtdsConnection;

    @Before
    public void setUp() {

        dao = new SQLServerToolDAO();
        dataSource = Mockito.mock(DataSource.class);
        jtdsConnection = Mockito.mock(JtdsJdbcConnection.class);
        conn = Mockito.mock(Connection.class);
        dao.setDataSource(dataSource);
        dao.setJtdsConnection(jtdsConnection);
    }


    @Test
    public void getUserServerInstance_ReturnsServerInstancesList() throws Exception {
        String loggedInUser = "jhuer";
        Connection conn = getConnection(URL, USER, PASSWORD);
        when(dataSource.getConnection()).thenReturn(conn);

        List<UserServerInstancesTO> serverInstancesTOList = dao.getUserServerInstance(loggedInUser);

        assertNotNull(serverInstancesTOList);
        assertEquals(serverInstancesTOList.size(), 2);
    }

    @Test
    public void getUserServerInstance_ReturnsAnEmptyServerInstancesList() throws Exception {
        String loggedInUser = "jjuarez";
        Connection conn = getConnection(URL, USER, PASSWORD);
        when(dataSource.getConnection()).thenReturn(conn);

        List<UserServerInstancesTO> serverInstancesTOList = dao.getUserServerInstance(loggedInUser);

        assertNotNull(serverInstancesTOList);
        assertEquals(serverInstancesTOList.size(), 0);
    }

    @Test(expected = SQLException.class)
    public void getUserServerInstance_ThrowsASQLException() throws SQLException {
        String loggedInUser = "jjuarez";
        when(dataSource.getConnection()).thenThrow(new SQLException());

        dao.getUserServerInstance(loggedInUser);

        fail("Throws a SQLException");
    }

    @Test
    public void getSQLAccountsByServerInstance_ReturnsSQLAccountsList() throws Exception {
        String loggedInUser = "jhuer";
        String serverInstance = "STLWSQLCB01";
        Connection conn = getConnection(URL, USER, PASSWORD);
        when(dataSource.getConnection()).thenReturn(conn);

        List<UserSQLAccountsTO> sqlAccountsTOList = dao.getSQLAccountsByServerInstance(serverInstance, loggedInUser);

        assertNotNull(sqlAccountsTOList);
        assertEquals(sqlAccountsTOList.size(), 2);
    }

    @Test
    public void getSQLAccountsByServerInstance_ReturnsAnEmptySQLAccountsList() throws Exception {
        String loggedInUser = "jjuarez";
        String serverInstance = "STLWSQLCB01";
        Connection conn = getConnection(URL, USER, PASSWORD);
        when(dataSource.getConnection()).thenReturn(conn);

        List<UserSQLAccountsTO> sqlAccountsTOList = dao.getSQLAccountsByServerInstance(serverInstance, loggedInUser);

        assertNotNull(sqlAccountsTOList);
        assertEquals(sqlAccountsTOList.size(), 0);
    }

    @Test(expected = SQLException.class)
    public void runScriptByVersion_throwsAnException() throws Exception {
        UserServerDetailsTO userServerDetailsTO = new UserServerDetailsTO();
        userServerDetailsTO.setSelectedSQLAccount("Test1");
        userServerDetailsTO.setSelectedServerInstance("STLWSQLCB01");
        userServerDetailsTO.setConfirmNewPassword("Best4you.");
        userServerDetailsTO.setNewPassword("Best4you.");
        userServerDetailsTO.setVersion("2008");
        Connection conn = getConnection(URL, USER, PASSWORD);
        when(jtdsConnection.getConnectionWithWindowAuth()).thenReturn(conn);

        boolean result = dao.runScriptByVersion(userServerDetailsTO);

        assertFalse(result);
    }

    @Test(expected = SQLException.class)
    public void runScriptByVersion_throwsAnException_WhenDataBaseIsOlderThan2005() throws Exception {
        UserServerDetailsTO userServerDetailsTO = new UserServerDetailsTO();
        userServerDetailsTO.setSelectedSQLAccount("Test1");
        userServerDetailsTO.setSelectedServerInstance("STLWSQLCB01");
        userServerDetailsTO.setConfirmNewPassword("Best4you.");
        userServerDetailsTO.setNewPassword("Best4you.");
        userServerDetailsTO.setVersion("28.");
        Connection conn = getConnection(URL, USER, PASSWORD);
        when(jtdsConnection.getConnectionWithWindowAuth()).thenReturn(conn);

        boolean result = dao.runScriptByVersion(userServerDetailsTO);

        assertFalse(result);
    }


    @Test(expected = SQLException.class)
    public void getSQLAccountsByServerInstance_ThrowsASQLException() throws SQLException {
        String loggedInUser = "jjuarez";
        String serverInstance = "STLWSQLCB01";
        when(dataSource.getConnection()).thenThrow(new SQLException());

        dao.getSQLAccountsByServerInstance(serverInstance, loggedInUser);

        fail("Throws a SQLException");
    }

    private Connection getConnection(String connectionUrl, String userName, String password) throws Exception {
        Connection con = null;
        try {
            Class.forName(DRIVER);
            con = java.sql.DriverManager.getConnection(connectionUrl, userName, password);
        } catch (Exception ex) {
            throw new Exception("Error while getting jtds connection");
        }
        return con;
    }


}
