package com.monsanto.sqlservertool.view.controller;

import com.monsanto.sqlservertool.dbconnection.SQLServerToolDAO;
import com.monsanto.sqlservertool.to.UserDetailsTO;
import com.monsanto.sqlservertool.to.UserServerInstancesTO;
import com.monsanto.sqlservertool.utils.SqlServerToolConstants;
import com.monsanto.sqlservertool.view.bo.LoginBO;
import com.monsanto.sqlservertool.view.validator.LoginValidator;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.mock.web.MockHttpSession;
import org.springframework.validation.BindException;
import org.springframework.validation.BindingResult;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpSession;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.when;

/**
 * Created by IntelliJ IDEA.
 * User: JHUER
 * Date: 24/10/12
 * Time: 12:25 PM
 * To change this template use File | Settings | File Templates.
 */

@RunWith(MockitoJUnitRunner.class)
public class LoginController_UT {
    private static final String USER_SERVER_INSTANCES = "userServerInstances";
    private static final String SUCCESSFUL_LOGIN_VIEW = "/successfulLogin";
    private static final String VIEW_NAME = "login";
    private static final String USER_DETAILS = "userDetails";
    private static final String SERVER_DETAILS = "serverDetails";

    private Properties adProps;
    private LoginValidator loginValidator;
    private LoginBO loginBO;
    private SQLServerToolDAO dao;
    private LoginController controller;
    private MockHttpServletRequest request;
    private MockHttpServletResponse response;
    private BindingResult result;
    private HttpSession session;

    @Before
    public void setUp() {
        adProps = new Properties();
        createProperties();
        session = new MockHttpSession();
        request = new MockHttpServletRequest();
        response = new MockHttpServletResponse();
        result = Mockito.mock(BindingResult.class);
        loginValidator = Mockito.mock(LoginValidator.class);
        dao = Mockito.mock(SQLServerToolDAO.class);
        loginBO = Mockito.mock(LoginBO.class);
        controller = new LoginController();
        controller.setDao(dao);
        controller.setLoginValidator(loginValidator);
        controller.setAdProps(adProps);
        controller.setLoginBO(loginBO);
    }

    @Test
    public void displayLoginPage() throws Exception {

        ModelAndView view = controller.displayLoginPage(request, response, session);

        assertNotNull(view);
        assertEquals(view.getViewName(), view.getViewName());
        ArrayList<String> domainNames = (ArrayList<String>) session.getAttribute(SqlServerToolConstants.DOMAIN_NAMES);
        assertNotNull(domainNames);
        assertTrue(domainNames.size() == 4);
        assertNotNull(view.getModelMap().get(USER_DETAILS));
    }

    @Test
    public void authenticateUser_ReturnsSuccessfulLoginViewName_WhenUserIsSuccessfullyAuthenticated() throws Exception {
        ModelAndView modelAndView = new ModelAndView();
        UserDetailsTO userDetails = new UserDetailsTO();
        userDetails.setUserName("jhuer");
        userDetails.setUserEmail("jacqueline.huerta.gonzalez@monsanto.com");
        userDetails.setFirstName("Jackeline");
        userDetails.setLastName("Huerta");
        when(loginBO.authenticateADUser(userDetails)).thenReturn(true);
        when(dao.getUserServerInstance("jhuer")).thenReturn(createServerInstancesList());

        ModelAndView resultView = controller.authenticateUser(request, response, session, modelAndView, userDetails, result);

        assertNotNull(resultView);
        assertEquals(resultView.getViewName(), SUCCESSFUL_LOGIN_VIEW);
        assertNotNull(session.getAttribute(USER_SERVER_INSTANCES));
        assertNotNull(modelAndView.getModelMap().get(USER_SERVER_INSTANCES));
        assertNotNull(modelAndView.getModelMap().get(SERVER_DETAILS));
        String user = (String) request.getAttribute(SqlServerToolConstants.LOGGED_IN_USER);
        assertNotNull(user);
        assertEquals(user, "Jackeline Huerta");
        UserDetailsTO loggedInUser = (UserDetailsTO) session.getAttribute(SqlServerToolConstants.LOGGED_IN_USER);
        assertNotNull(loggedInUser);
        assertEquals(loggedInUser.getUserName(), "jhuer");
        assertNotNull(session.getAttribute(SqlServerToolConstants.DOMAIN_NAMES));
    }

    @Test
    public void authenticateUser_ReturnsSuccessfulLoginViewName_WhenDaoThrownAnException() throws Exception {
        ModelAndView modelAndView = new ModelAndView();
        UserDetailsTO userDetails = new UserDetailsTO();
        userDetails.setUserName("jhuer");
        userDetails.setUserEmail("jacqueline.huerta.gonzalez@monsanto.com");
        userDetails.setFirstName("Jackeline");
        userDetails.setLastName("Huerta");
        when(loginBO.authenticateADUser(userDetails)).thenReturn(true);
        when(dao.getUserServerInstance("jhuer")).thenThrow(new SQLException());

        ModelAndView resultView = controller.authenticateUser(request, response, session, modelAndView, userDetails, result);

        assertNotNull(resultView);
        assertEquals(resultView.getViewName(), SUCCESSFUL_LOGIN_VIEW);

        assertNotNull(session.getAttribute(USER_SERVER_INSTANCES));
        List<UserServerInstancesTO> serverInstancesTOs = (List<UserServerInstancesTO>) modelAndView.getModelMap().get(USER_SERVER_INSTANCES);
        assertNotNull(serverInstancesTOs);
        assertTrue(serverInstancesTOs.size() == 0);
        assertNotNull(modelAndView.getModelMap().get(SERVER_DETAILS));
        String user = (String) request.getAttribute(SqlServerToolConstants.LOGGED_IN_USER);
        assertNotNull(user);
        assertEquals(user, "Jackeline Huerta");
        UserDetailsTO loggedInUser = (UserDetailsTO) session.getAttribute(SqlServerToolConstants.LOGGED_IN_USER);
        assertNotNull(loggedInUser);
        assertEquals(loggedInUser.getUserName(), "jhuer");
        assertNotNull(session.getAttribute(SqlServerToolConstants.DOMAIN_NAMES));
    }

    @Test
    public void authenticateUser_ReturnsLoginViewName_WhenUserWasNotAuthenticatedByLDAP() throws Exception {
        ModelAndView modelAndView = new ModelAndView();
        result = new BindException(new UserDetailsTO(), "UserDetailsTO");
        UserDetailsTO userDetails = new UserDetailsTO();
        userDetails.setUserName("jhuer");
        userDetails.setUserEmail("jacqueline.huerta.gonzalez@monsanto.com");
        userDetails.setFirstName("Jackeline");
        userDetails.setLastName("Huerta");
        when(loginBO.authenticateADUser(userDetails)).thenReturn(false);
        when(dao.getUserServerInstance("jhuer")).thenReturn(createServerInstancesList());

        ModelAndView resultView = controller.authenticateUser(request, response, session, modelAndView, userDetails, result);

        assertNotNull(resultView);
        assertEquals(resultView.getViewName(), VIEW_NAME);
        assertNotNull(session.getAttribute(SqlServerToolConstants.DOMAIN_NAMES));
    }

    @Test
    public void authenticateUser_ReturnsLoginViewName_WhenValidatorReturnedValidationErrors() throws Exception {
        ModelAndView modelAndView = new ModelAndView();
        loginValidator = new LoginValidator();
        controller.setLoginValidator(loginValidator);
        result = new BindException(new UserDetailsTO(), "UserDetailsTO");
        UserDetailsTO userDetails = new UserDetailsTO();
        userDetails.setUserName("jhuer");
        userDetails.setUserEmail("jacqueline.huerta.gonzalez@monsanto.com");
        when(loginBO.authenticateADUser(userDetails)).thenReturn(true);
        when(dao.getUserServerInstance("jhuer")).thenReturn(createServerInstancesList());

        ModelAndView resultView = controller.authenticateUser(request, response, session, modelAndView, userDetails, result);

        assertNotNull(resultView);
        assertEquals(resultView.getViewName(), VIEW_NAME);
        assertNotNull(session.getAttribute(SqlServerToolConstants.DOMAIN_NAMES));
    }

    private void createProperties() {
        adProps.put("NORTH_AMERICA.domain", "NORTH_AMERICA");
        adProps.put("NORTH_AMERICA.host", "ldap://monldap1.monsanto.com:389");
        adProps.put("NORTH_AMERICA.dc", "na");

        adProps.put("LAWA-SOUTH.domain", "LAWA-SOUTH");
        adProps.put("LAWA-SOUTH.host", "ldap://la1000dsp01.la.ds.monsanto.com:389");
        adProps.put("LAWA-SOUTH.dc", "la");

        adProps.put("EUROPE-AFRICA.domain", "EUROPE-AFRICA");
        adProps.put("EUROPE-AFRICA.host", "ldap://ea1000dsp01.ea.ds.monsanto.com:389");
        adProps.put("EUROPE-AFRICA", "ea");

        adProps.put("ASIA-PACIFIC.domain", "ASIA-PACIFIC");
        adProps.put("ASIA-PACIFIC.host", "ldap://ap1000dsp01.ap.ds.monsanto.com:389");
        adProps.put("ASIA-PACIFIC.dc", "ap");
    }

    private List<UserServerInstancesTO> createServerInstancesList() {
        List<UserServerInstancesTO> userServerInstancesTOList = new ArrayList<UserServerInstancesTO>();
        UserServerInstancesTO serverInstancesTO = new UserServerInstancesTO();
        serverInstancesTO.setServerInstance("ServerInstance1");
        userServerInstancesTOList.add(serverInstancesTO);
        serverInstancesTO = new UserServerInstancesTO();
        serverInstancesTO.setServerInstance("ServerInstance1");
        userServerInstancesTOList.add(serverInstancesTO);
        return userServerInstancesTOList;
    }

}
