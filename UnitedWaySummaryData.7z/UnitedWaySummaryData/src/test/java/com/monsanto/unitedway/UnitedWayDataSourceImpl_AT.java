package com.monsanto.unitedway;

import junit.framework.TestCase;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public class UnitedWayDataSourceImpl_AT extends TestCase {
  public void testDataIsReturned() throws Exception {
    UnitedWayDataSourceImpl dataSource = new UnitedWayDataSourceImpl();
    UnitedWayDataSet data = dataSource.getData(false);
    assertNotNull(data);
    assertNotNull(data.getData());
    assertFalse(data.getData().isEmpty());
  }

}