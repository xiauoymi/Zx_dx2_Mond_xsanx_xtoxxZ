package com.monsanto.unitedway;

import junit.framework.TestCase;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public class CachedDataSource_UT extends TestCase {
  public void testCachedDataSourceCallsDataSourceOnFirstCall() throws Exception {
    MockDataSource mockBaseSource = new MockDataSource();
    UnitedWayDataSource dataSource = new CachedDataSource(mockBaseSource, 100000);
    assertEquals(0, mockBaseSource.getNumCalls());
    dataSource.getData(true);
    assertEquals(1, mockBaseSource.getNumCalls());
  }

  public void testCachedDataSourceDoesntCallsDataSourceOnAdditionalCalls() throws Exception {
    MockDataSource mockBaseSource = new MockDataSource();
    UnitedWayDataSource dataSource = new CachedDataSource(mockBaseSource, 100000);
    UnitedWayDataSet firstResult = dataSource.getData(true);
    assertEquals(1, mockBaseSource.getNumCalls());
    dataSource.getData(true);
    dataSource.getData(true);
    dataSource.getData(true);
    dataSource.getData(true);
    dataSource.getData(true);
    UnitedWayDataSet lastResult = dataSource.getData(true);
    assertEquals(1, mockBaseSource.getNumCalls());
    assertSame(firstResult, lastResult);
  }

  public void testCachedDataSourceDoesCallDataSourceAfterCacheExpires() throws Exception {
    MockDataSource mockBaseSource = new MockDataSource();
    UnitedWayDataSource dataSource = new CachedDataSource(mockBaseSource, 50);
    dataSource.getData(true);
    dataSource.getData(true);
    assertEquals(1, mockBaseSource.getNumCalls());
    Thread.sleep(100);
    dataSource.getData(true);
    assertEquals(2, mockBaseSource.getNumCalls());
  }

  public void testCachedDataSourceDoesCallDataSourceWithDifferentParameterSent() throws Exception {
    MockDataSource mockBaseSource = new MockDataSource();
    UnitedWayDataSource dataSource = new CachedDataSource(mockBaseSource, 100000);
    dataSource.getData(true);
    dataSource.getData(true);
    assertEquals(1, mockBaseSource.getNumCalls());
    dataSource.getData(false);
    assertEquals(2, mockBaseSource.getNumCalls());
    dataSource.getData(false);
    dataSource.getData(true);
    dataSource.getData(false);
    dataSource.getData(true);
    dataSource.getData(false);
    dataSource.getData(true);
    assertEquals(2, mockBaseSource.getNumCalls());
  }

  private static class MockDataSource implements UnitedWayDataSource {
    private int numCalls = 0;

    public UnitedWayDataSet getData(boolean lastYear) {
      numCalls++;
      return new UnitedWayDataSet();
    }

    public int getNumCalls() {
      return numCalls;
    }
  }
}
