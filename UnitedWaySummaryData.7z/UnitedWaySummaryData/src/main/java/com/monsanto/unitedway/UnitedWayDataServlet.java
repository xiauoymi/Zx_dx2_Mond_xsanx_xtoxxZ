package com.monsanto.unitedway;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public class UnitedWayDataServlet extends HttpServlet {
  private static final long CACHE_TIMEOUT = 5 * 60 * 1000; // 5 minutes
  private static final UnitedWayDataSource dataSource = new CachedDataSource(new UnitedWayDataSourceImpl(), CACHE_TIMEOUT);

  @Override
  public void init() throws ServletException {
    super.init();
    try {
      Class.forName("oracle.jdbc.driver.OracleDriver");
    } catch (ClassNotFoundException e) {
      throw new ServletException(e);
    }
  }

  protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    doGet(request, response);
  }

  protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    UnitedWayDataOutput dataOutput = new UnitedWayDataOutput(response);
    boolean lastYear = isLastYearSelected(request);
    UnitedWayDataSet dataSet = dataSource.getData(lastYear);
    dataOutput.outputData(dataSet);
  }

  private boolean isLastYearSelected(HttpServletRequest request) {
    String lastYearString = request.getParameter("lastyear");
    return "Y".equalsIgnoreCase(lastYearString);
  }
}
