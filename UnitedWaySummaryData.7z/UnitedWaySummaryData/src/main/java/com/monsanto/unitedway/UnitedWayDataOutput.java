package com.monsanto.unitedway;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.DecimalFormat;
import java.text.NumberFormat;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public class UnitedWayDataOutput {
  private final HttpServletResponse response;

  public UnitedWayDataOutput(HttpServletResponse response) {
    this.response = response;
  }

  public void outputData(UnitedWayDataSet dataSet) throws IOException {
    response.setContentType("text/xml");
    PrintWriter out = response.getWriter();
    out.println("<UnitedWayData>\n");
    for (UnitedWayDataPoint datum : dataSet.getData()) {
      outputDatum(out, datum);
    }
    out.println("</UnitedWayData>\n");
  }

  private void outputDatum(PrintWriter out, UnitedWayDataPoint datum) {
    String unit = datum.getUnit();
    String manager = datum.getDisplayName();
    out.println("\t<Org>\n");
    out.println("\t\t<Team>" + unit + " - " + manager + "</Team>\n");
    out.println("\t\t<Unit>" + unit + "</Unit>\n");
    out.println("\t\t<Manager>" + manager + "</Manager>\n");
    out.println("\t\t<TotalContributions>" + formatDouble(datum.getTotalCont()) + "</TotalContributions>\n");
    out.println("\t\t<NumDonated>" + datum.getNumDonated() + "</NumDonated>\n");
    out.println("\t\t<NumTotal>" + datum.getNumTotal() + "</NumTotal>\n");
    out.println("\t\t<PercentDonated>" + formatDouble(datum.getPctDonated()) + "</PercentDonated>\n");
    out.println("\t</Org>\n");
  }

  private static final NumberFormat twoDecemalFmt = new DecimalFormat("#0.00");

  private String formatDouble(double dblvalue) {
    return twoDecemalFmt.format(dblvalue);
  }
}
