package com.monsanto.unitedway;

public class UnitedWayDataPoint {
  private final String unit;
  private final String displayName;
  private final double totalCont;
  private final long numDonated;
  private final long numTotal;
  private final double pctDonated;

  public UnitedWayDataPoint(String unit, String displayName, double totalCont, long numDonated, long numTotal, double pctDonated) {
    this.unit = unit;
    this.displayName = displayName;
    this.totalCont = totalCont;
    this.numDonated = numDonated;
    this.numTotal = numTotal;
    this.pctDonated = pctDonated;
  }

  public String getUnit() {
    return unit;
  }

  public String getDisplayName() {
    return displayName;
  }

  public double getTotalCont() {
    return totalCont;
  }

  public long getNumDonated() {
    return numDonated;
  }

  public long getNumTotal() {
    return numTotal;
  }

  public double getPctDonated() {
    return pctDonated;
  }
}
