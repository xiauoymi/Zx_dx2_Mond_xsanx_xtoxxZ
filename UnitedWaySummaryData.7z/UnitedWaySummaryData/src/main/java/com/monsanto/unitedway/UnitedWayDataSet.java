package com.monsanto.unitedway;

import java.util.ArrayList;
import java.util.Collection;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public class UnitedWayDataSet {
  private final Collection<UnitedWayDataPoint> data = new ArrayList<UnitedWayDataPoint>();

  public void add(UnitedWayDataPoint datum) {
    data.add(datum);
  }

  public Collection<UnitedWayDataPoint> getData() {
    return data;
  }
}

