package com.monsanto.unitedway;

import com.monsanto.Util.databasepasswordencryption.EncryptionUtils;
import com.monsanto.Util.databasepasswordencryption.EncryptorException;
import org.apache.commons.dbcp.BasicDataSource;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.MissingResourceException;
import java.util.ResourceBundle;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public class UnitedWayDataSourceImpl implements UnitedWayDataSource {
  private static final String APP_NAME = "UWaySummary";
  private static final String MONCRYPTJV_PROPERTY = "MONCRYPTJV";
  private static final String LSI_FUNCTION_PROPERTY = "lsi.function";
  private static final String PROPERTIES_FILENAME = "unitedway";
  private static final String CURR_YEAR_SQL = "select unit, display_name, total_cont, num_donated, num_total, pct_donated from uway.current_year_dept_summary";
  private static final String LAST_YEAR_SQL = "select unit, display_name, total_cont, num_donated, num_total, pct_donated from uway.last_year_dept_summary";
  private final ResourceBundle properties;

  public UnitedWayDataSourceImpl() {
    this.properties = ResourceBundle.getBundle(PROPERTIES_FILENAME);
  }

  public UnitedWayDataSet getData(boolean lastYear) {
    Connection conn = null;
    try {
      conn = getDataSource().getConnection();
      Statement stmt = conn.createStatement();
      ResultSet result = stmt.executeQuery(getSQL(lastYear));
      UnitedWayDataSet dataSet = getDataSetFromResultSet(result);
      result.close();
      stmt.close();
      return dataSet;
    } catch (SQLException e) {
      throw new RuntimeException(e);
    } catch (EncryptorException e) {
      throw new RuntimeException(e);
    } finally {
      closeIfNeeded(conn);
    }
  }

  private void closeIfNeeded(Connection conn) {
    try {
      if (conn != null && !conn.isClosed()) {
        conn.close();
      }
    } catch (SQLException e) {
      throw new RuntimeException(e);
    }
  }

  private static DataSource dataSource = null;

  private DataSource getDataSource() throws EncryptorException {
    synchronized (UnitedWayDataSourceImpl.class) {
      if (dataSource == null) {
        dataSource = getNewDataSource();
      }

      return dataSource;
    }
  }

  private DataSource getNewDataSource() throws EncryptorException {
    BasicDataSource ds = new BasicDataSource();
    ds.setDriverClassName("oracle.jdbc.driver.OracleDriver");
    ds.setUsername(getUserName());
    ds.setPassword(getPassword());
    ds.setUrl(getURL());
    ds.setDefaultReadOnly(true);
    ds.setValidationQuery("SELECT DUMMY FROM DUAL");
    ds.setTestOnBorrow(true);
    ds.setMaxActive(20);
    return ds;
  }

  private String getPassword() throws EncryptorException {
    return EncryptionUtils.GetDecryptedStringFromExternalStorage(MONCRYPTJV_PROPERTY, APP_NAME, "CipherValue.hex", "KeyValue.hex");
  }

  private String getUserName() {
    return getProperty("username");
  }

  private String getURL() {
    return getProperty("url");
  }

  private String getProperty(String propertyName) {
    try {
      return getPropertyWithoutPrefix(propertyName);
    } catch (MissingResourceException ex) {
      String lsiFunction = getRequiredSystemProperty(LSI_FUNCTION_PROPERTY);
      return getPropertyWithoutPrefix(lsiFunction + "." + propertyName);
    }
  }

  private String getRequiredSystemProperty(String propertyName) {
    String value = System.getProperty(propertyName);
    if (value == null || value.length() == 0) {
      throw new RuntimeException(propertyName + " is not set");
    }
    return value;
  }

  private String getPropertyWithoutPrefix(String propertyName) {
    return properties.getString(propertyName);
  }

  private String getSQL(boolean lastYear) {
    if (lastYear) {
      return LAST_YEAR_SQL;
    } else {
      return CURR_YEAR_SQL;
    }
  }

  private UnitedWayDataSet getDataSetFromResultSet(ResultSet result) throws SQLException {
    UnitedWayDataSet dataSet = new UnitedWayDataSet();
    while (result.next()) {
      String unit = result.getString("UNIT");
      String mgr = result.getString("DISPLAY_NAME");
      double totalCont = result.getDouble("TOTAL_CONT");
      long numDonated = result.getLong("NUM_DONATED");
      long numTotal = result.getLong("NUM_TOTAL");
      double pctDonated = result.getDouble("PCT_DONATED");
      dataSet.add(new UnitedWayDataPoint(unit, mgr, totalCont, numDonated, numTotal, pctDonated));
    }
    return dataSet;
  }
}
