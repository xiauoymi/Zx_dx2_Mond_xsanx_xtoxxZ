package com.monsanto.unitedway;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public class CachedDataSource implements UnitedWayDataSource {
  private final UnitedWayDataSource baseSource;
  private final long cacheLifeMS;
  private CacheResult[] prevResults = {
          new CacheResult(null, 0L),
          new CacheResult(null, 0L)
  };

  public CachedDataSource(UnitedWayDataSource baseSource, long cacheLifeMS) {
    this.baseSource = baseSource;
    this.cacheLifeMS = cacheLifeMS;
  }

  public synchronized UnitedWayDataSet getData(boolean lastYear) {
    int resultIndex = booleanAsIndex(lastYear);
    CacheResult currCacheResult = prevResults[resultIndex];
    UnitedWayDataSet data = currCacheResult.getData();
    if (data == null) {
      data = baseSource.getData(lastYear);
      prevResults[resultIndex] = new CacheResult(data, cacheLifeMS);
    }
    return data;
  }

  private int booleanAsIndex(boolean bool) {
    return (bool) ? 1 : 0;
  }

  private static class CacheResult {
    private final UnitedWayDataSet data;
    private final long cacheTimeOut;

    public CacheResult(UnitedWayDataSet data, long cacheLifeMS) {
      this.data = data;
      this.cacheTimeOut = System.currentTimeMillis() + cacheLifeMS;
    }

    public UnitedWayDataSet getData() {
      if (cacheTimeOut <= System.currentTimeMillis()) {
        return null;
      } else {
        return data;
      }
    }
  }
}
