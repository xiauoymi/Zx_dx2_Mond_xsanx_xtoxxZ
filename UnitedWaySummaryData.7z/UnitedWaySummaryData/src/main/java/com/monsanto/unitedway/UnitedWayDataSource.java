package com.monsanto.unitedway;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public interface UnitedWayDataSource {
  UnitedWayDataSet getData(boolean lastYear);
}
