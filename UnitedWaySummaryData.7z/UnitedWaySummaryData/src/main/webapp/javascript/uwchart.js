function displayUWChart(chartElementId, serverUrl) {
    YAHOO.widget.Chart.SWFURL = serverUrl + "/html/charts.swf";

    this.connectionCallback = {
        success: function(o) {
            var xmlDoc = o.responseXML;
            this.myDataSource = new YAHOO.util.DataSource(xmlDoc);
            this.myDataSource.responseType = YAHOO.util.DataSource.TYPE_XML;
            this.myDataSource.responseSchema = {
                resultNode: "Org",
                fields: ["Team", "Unit","Manager","TotalContributions","NumDonated","NumTotal","PercentDonated"]
            };

            this.percentDonatedSeriesDef =
            [
                {
                    xField: "PercentDonated",
                    displayName: "Pledged",
                    style:
                    {
                        size: 15
                    }
                }
            ];

            //used to format x axis
            YAHOO.example.numberToPercent = function(value)
            {
                return YAHOO.util.Number.format(Number(value), {suffix: "%", thousandsSeparator: ","});
            };

            //Numeric Axis for our currency
            this.percentAxis = new YAHOO.widget.NumericAxis();
            this.percentAxis.stackingEnabled = true;
            this.percentAxis.labelFunction = YAHOO.example.numberToPercent;
            this.percentAxis.minimum = 0;
            this.percentAxis.maximum = 100;
            this.percentAxis.majorUnit = 20;
            this.percentAxis.minorUnit = 10;
            this.percentAxis.title = "Employees Donating";

            this.myChart = new YAHOO.widget.BarChart(chartElementId, this.myDataSource,
            {
                series: this.percentDonatedSeriesDef,
                yField: "Team",
                xAxis: this.percentAxis
            });
        },
        failure: function(o) {
        }
    };

    var dataURL = serverUrl + "/orgdata?lastyear=y";
    this.getXML = YAHOO.util.Connect.asyncRequest("GET", dataURL, this.connectionCallback);
}
