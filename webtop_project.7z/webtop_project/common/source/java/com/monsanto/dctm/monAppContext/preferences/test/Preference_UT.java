/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.monAppContext.preferences.test;

import com.documentum.web.form.ComponentTestUtils;
import com.documentum.web.formext.config.PreferenceService;
import com.monsanto.dctm.component.test.MockForm;
import com.monsanto.dctm.monAppContext.MonAppContextService;
import com.monsanto.dctm.monAppContext.preferences.Preference;
import junit.framework.TestCase;

/**
 * Filename:    $RCSfile: Preference_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: lakench $    	 On:	$Date:
 * 2007/04/26 21:42:01 $
 *
 * @author lakench
 * @version $Revision: 1.5 $
 */
public class Preference_UT extends TestCase {
  public void testPreferenceKeyAppendsMonAppContextInternalName() throws Exception {
    ComponentTestUtils.setupConfigService();
    ComponentTestUtils.initPreferenceService(null);
    ComponentTestUtils.setCurrentDocbase(ComponentTestUtils.TESTDOCBASE);
    PreferenceService.getPreferenceStore()
        .writeString("application.mon_app_context." + ComponentTestUtils.TESTDOCBASE,
            "Test Context with View for commenting disabled");
    Preference preference = new MockPreference();
    preference.setForm(new MockForm());
    preference.setScopeId("test_scope_id");

    String actualPreferenceKey = preference.getPreferenceKey("test preference");
    String expectedPreferenceKey =
        "test preference." + MonAppContextService.getMonAppContextService().getMonAppContextInternalName();
    assertEquals("preference key not generated properly", expectedPreferenceKey, actualPreferenceKey);

    preference.setPreferenceId("test_preference_id");
    actualPreferenceKey = preference.getPreferenceKey();
    expectedPreferenceKey = preference.getPreferenceId() + "." +
        MonAppContextService.getMonAppContextService().getMonAppContextInternalName();
    ComponentTestUtils.releasePreferenceService();
    ComponentTestUtils.releaseConfigService();
  }
}