/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.support;

import com.documentum.fc.client.*;
import com.documentum.fc.common.DfException;
import com.documentum.web.form.control.databound.ColumnDescriptor;
import com.documentum.web.formext.component.Component;

import java.util.ArrayList;
import java.util.List;

/**
 * Filename:    $RCSfile: AppOwners.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: lakench $    	 On:	$Date:
 * 2007/01/12 18:49:20 $
 *
 * @author lakench
 * @version $Revision: 1.3 $
 */
public class AppOwners extends SupportPageTableData {
  public AppOwners(Component component) {
    super(component);
  }

  public List getColumnList() {
    List appOwnerColumns = new ArrayList(3);
    appOwnerColumns.add(new ColumnDescriptor("app", "Application", true));
    appOwnerColumns.add(new ColumnDescriptor("area", "Site", true));
    appOwnerColumns.add(new ColumnDescriptor("owners", "Authorized User Request Sponsor(s)", true));
    return appOwnerColumns;
  }

  public List getData() throws DfException {
    List appOwnerData = new ArrayList(5);
    IDfSession session = null;
    session = getSupportConfig().getSupportConfigSysObject().getSession();

    IDfQuery query = new DfQuery();
    query.setDQL("select object_name, display_name from mon_app_context_info order by display_name");
    IDfCollection monAppContexts = null;
    try {
      monAppContexts = query.execute(session, IDfQuery.DF_READ_QUERY);
      while (monAppContexts.next()) {
        String monAppContextName = monAppContexts.getString("object_name");
        String displayName = monAppContexts.getString("display_name");
        IDfPersistentObject appOwnerObject = session.getObjectByQualification(
            "mon_app_owner_info where mon_app_context = '" + monAppContextName + "'");

        List monAppContextRows = getAppOwnerRowForMonAppContext(displayName, appOwnerObject);
        appOwnerData.addAll(monAppContextRows);
      }
    }
    finally {
      if (monAppContexts != null) {
        monAppContexts.close();
      }
    }


    return appOwnerData;
  }

  private List getAppOwnerRowForMonAppContext(String monAppContextDisplayName,
                                              IDfPersistentObject appOwnerObject) throws
      DfException {
    int numAppOwners = appOwnerObject.getValueCount("area");
    List monAppContextRows = new ArrayList(numAppOwners);
    List row = new ArrayList(3);
    row.add(monAppContextDisplayName);
    if (numAppOwners > 0) {
      String currentArea = appOwnerObject.getRepeatingString("area", 0);
      StringBuffer appOwnerInfo = new StringBuffer();
      for (int i = 0; i < numAppOwners; i++) {
        String area = appOwnerObject.getRepeatingString("area", i);
        if (!area.equals(currentArea)) {
          row.add(currentArea);
          row.add(appOwnerInfo.toString());
          monAppContextRows.add(row);
          appOwnerInfo = new StringBuffer();
          row = new ArrayList(3);
          row.add(monAppContextDisplayName);
          currentArea = area;
        }
        appOwnerInfo.append(appOwnerObject.getRepeatingString("name", i));
        appOwnerInfo.append("::");
        appOwnerInfo.append(appOwnerObject.getRepeatingString("email", i));
        appOwnerInfo.append("##");
      }
      row.add(currentArea);
      row.add(appOwnerInfo.toString());
      monAppContextRows.add(row);
    }
    return monAppContextRows;
  }
}