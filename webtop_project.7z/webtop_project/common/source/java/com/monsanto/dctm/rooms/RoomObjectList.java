package com.monsanto.dctm.rooms;

import com.monsanto.dctm.monAppContext.MonAppContextService;

public class RoomObjectList extends
                            com.documentum.webtop.webcomponent.rooms.RoomObjectList {

    protected String getColumnsPreferenceId() {
        return super.getColumnsPreferenceId() + "." +
               MonAppContextService.getMonAppContextService().getMonAppContextInternalName();
    }

}
