package com.monsanto.dctm.validation;

import com.documentum.web.form.Form;
import com.documentum.web.formext.control.docbase.DocbaseObject;
import com.documentum.web.formext.session.SessionManagerHttpBinding;
import com.documentum.fc.common.DfLogger;
import com.documentum.fc.common.DfException;
import com.documentum.fc.client.IDfCollection;
import com.documentum.fc.client.IDfQuery;
import com.documentum.fc.client.IDfSession;
import com.documentum.com.IDfClientX;
import com.documentum.com.DfClientX;

import java.util.Map;

/**
 * Created by IntelliJ IDEA.
 * User: ussing
 * Date: Dec 17, 2009
 * Time: 9:59:12 AM
 * To change this template use File | Settings | File Templates.
 */
public class NotifyUserValidation extends CustomValidation {
    public NotifyUserValidation(Form form, DocbaseObject docbaseObj) {
        super(form, docbaseObj);

        i_Form.setDoValidation(true);
        DfLogger.debug(this, "do validation? = " + i_Form.getDoValidation(), null, null);

        doCustomValidation = true;  //if we've created an instance of this object, we need custom validation
    }
    protected void customValidate() {
        getAttributes();
        bIsValid = true;
        strErrorMessage = "";
        //doCustomValidation = true; // need to uncomment it for UT's to pass
        if (doCustomValidation)
        {
            DfLogger.debug(this,"notify_users: IF condition: " + (!hAttributes.get("notify_users").equals("")),null,null);
            if (!hAttributes.get("notify_users").equals("")){
                DfLogger.debug(this,"notify_users" + hAttributes.get("notify_users").toString(),null,null);
                String notifyUsers =  hAttributes.get("notify_users").toString()  ;
                notifyUsers = notifyUsers.replace("[","('");
                notifyUsers = notifyUsers.replace(", ","','");
                notifyUsers = notifyUsers.replace("]","')");
                DfLogger.debug(this,"STRING After replacing [ notify_users: " + notifyUsers, null,null);
                String inactiveNotifyUsers = inActiveNotifyUsers(notifyUsers);
                if ((inactiveNotifyUsers != null) && (inactiveNotifyUsers != "")) {
                    bIsValid = false;
                    strErrorMessage += "Following users are inactive:\n " + inactiveNotifyUsers;
                }
                else
                    bIsValid = true;
            }
            super.customValidate();
        }
    }
    private String inActiveNotifyUsers(String notifyUsers) {
        String inactiveUsersList ;
        String inActiveUserQuery = "select user_name from dm_user where user_name in " +
                notifyUsers+ " and user_state = 1";
        DfLogger.info(this, "Name: " + "inActiveUserQuery: " + inActiveUserQuery, null, null);
//        System.out.println("inActiveUserQuery = " + inActiveUserQuery);
        inactiveUsersList = execQuery(inActiveUserQuery) ;
        System.out.println("NotifyUserValidation.inActiveNotifyUsers");
        System.out.println("inactiveUsersList = " + inactiveUsersList);
        return inactiveUsersList;
    }

    protected String execQuery(String queryString)  {
        IDfCollection coll;// = null;
        IDfClientX clientx = new DfClientX();
        IDfSession session = null;
        IDfQuery q = clientx.getQuery();
        String result = "";
        q.setDQL(queryString);
        try {
            session = getDfSession();
            coll = q.execute(session, IDfQuery.DF_READ_QUERY);
            while (coll.next()) {
                result = coll.getString("user_name")+ "," + result  ;
                System.out.println("result = " + result);
                DfLogger.info(this, "Name: Query executed... Result is " + result, null, null);
            }
              if (coll != null)
                    coll.close();
        }
        catch (DfException e) {
            e.printStackTrace();
        }
        finally {

            SessionManagerHttpBinding.getSessionManager().release(session);
        }
        return result;
    }
    private IDfSession getDfSession() throws DfException {
        return SessionManagerHttpBinding.getSessionManager().getSession(
                SessionManagerHttpBinding.getCurrentDocbase());
    }
}
