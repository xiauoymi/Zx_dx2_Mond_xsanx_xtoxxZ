package com.monsanto.dctm.search;

import com.documentum.debug.Trace;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.IDfSessionManager;
import com.documentum.fc.client.search.IDfQueryDefinition;
import com.documentum.fc.client.search.IDfSearchService;
import com.documentum.fc.client.search.IDfSmartList;
import com.documentum.fc.client.search.IDfSmartListDefinition;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfId;
import com.documentum.web.common.ArgumentList;
import com.documentum.web.common.WrapperRuntimeException;
import com.documentum.web.formext.component.Component;
import com.documentum.web.formext.config.Context;
import com.documentum.web.formext.config.IConfigElement;
import com.documentum.web.formext.docbase.FolderUtil;
import com.documentum.web.formext.session.DocbaseUtils;
import com.documentum.web.formext.session.SessionManagerHttpBinding;
import com.documentum.webcomponent.library.search.SearchInfo;

import java.io.IOException;

public class ViewSearchAction extends
    com.documentum.webcomponent.library.actions.ViewSearchAction {
  private IDfSearchService searchService;

  public boolean queryExecute(String strAction, IConfigElement config, ArgumentList arg, Context context,
                              Component component) {
    System.out.println("ViewSearchAction.queryExecute");
    boolean bExecute = false;
    IDfSession session = null;
    try {
      String strObjectId = arg.get("objectId");
      if (!FolderUtil.isFolderType(strObjectId)) {
        System.out.println("not a folder object");
        com.documentum.fc.common.IDfId idSavedSearchObject = new DfId(strObjectId);
        String strDocbase = getDocbaseName(idSavedSearchObject);
        if (null != strDocbase && strDocbase.length() > 0) {
          System.out.println("strDocbase = " + strDocbase);
          session = getSessionManager().getSession(strDocbase);
          IDfSmartList obj = (IDfSmartList) session.getObject(idSavedSearchObject);
          if (null != obj && !obj.isLegacy()) {
            System.out.println("obj is not null and not legacy");
            long contentSize = obj.getContentSize();
            if ((double) contentSize > 0.40000000000000002D) {
              System.out.println("content size is big enough");
              bExecute = isSmartListQuery(obj);
            }
          }
        }
      }
    }
    catch (DfException e) {
      throw new WrapperRuntimeException("Failed to get smartList and/or format", e);
    }
    finally {
      if (session != null)
        getSessionManager().release(session);
    }
    System.out.println("bExecute = " + bExecute);
    return bExecute;
  }

  protected String getDocbaseName(com.documentum.fc.common.IDfId idSavedSearchObject) throws DfException {
    return DocbaseUtils.getDocbaseNameFromId(idSavedSearchObject);
  }

  protected IDfSessionManager getSessionManager() {
    return SessionManagerHttpBinding.getSessionManager();
  }

  private boolean isSmartListQuery(IDfSmartList obj) {
    boolean bExecute = false;
    try {
      IDfSmartListDefinition smartListDef = obj.getSmartListDefinition(getSearchService());
      IDfQueryDefinition queryDef = smartListDef.getQueryDefinition();
      if (queryDef != null && queryDef.isQueryBuilder())
        bExecute = true;
    }
    catch (IOException ioe) {
      Trace.println("Invalid smartlist format - exception = " + ioe);
    }
    catch (DfException dfe) {
      Trace.println("Invalid query/no rights to read content - exception = " + dfe);
    }
    return bExecute;
  }

  protected void setSearchService(IDfSearchService searchService) {
    this.searchService = searchService;
  }

  protected IDfSearchService getSearchService() {
    if (searchService == null) {
      SearchInfo searchInfo = new MonSearchInfo();
      searchService = searchInfo.getSearchService();
    }
    return searchService;
  }
}
