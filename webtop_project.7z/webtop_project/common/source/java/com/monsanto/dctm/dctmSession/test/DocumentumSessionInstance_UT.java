/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.dctmSession.test;

import com.documentum.fc.client.IDfPersistentObject;
import com.documentum.fc.client.MockSession;
import com.monsanto.dctm.component.test.MockPersistentObject;
import com.monsanto.dctm.component.test.MockSessionManager;
import com.monsanto.dctm.dctmSession.DocumentumSessionInstance;
import junit.framework.TestCase;

/**
 * Filename:    $RCSfile: DocumentumSessionInstance_UT.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: lakench $    	 On:	$Date: 2007-03-30 20:58:38 $
 *
 * @author lakench
 * @version $Revision: 1.3 $
 */
public class DocumentumSessionInstance_UT extends TestCase {
    public void testCreate() throws Exception {
        DocumentumSessionInstance documentumSessionInstance = new DocumentumSessionInstance(new MockSessionManager(),
                                                                                            "test_docbase");
        assertNotNull(documentumSessionInstance);
    }

    public void testRelease() throws Exception {
        DocumentumSessionInstance documentumSessionInstance = new DocumentumSessionInstance(new MockSessionManager(),
                                                                                            "test_docbase");
        documentumSessionInstance.release();
        try {
            documentumSessionInstance.getObject(null);
            fail();
        } catch (Exception e) {
            // expected path
        }
    }

    public void testGetObjectReturnsExpectedDctmObject() throws Exception {
        MockSessionManager dfSessionManager = new MockSessionManager();
        MockSession session = new MockSession();
        IDfPersistentObject mockPersistentObject = new MockPersistentObject();
        session.addObject(mockPersistentObject, "testobjectid");
        dfSessionManager.setSession(session);
        DocumentumSessionInstance documentumSessionInstance = new DocumentumSessionInstance(dfSessionManager,
                                                                                            "test_docbase");
        Object actualObject = documentumSessionInstance.getObject("testobjectid");
        assertEquals(mockPersistentObject, actualObject);
    }
}