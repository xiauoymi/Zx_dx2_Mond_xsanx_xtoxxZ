/*
 * Created on Mar 30, 2004
 * 
 * Documentum Developer Program 2004
 *
 */
package com.monsanto.dctm.autoLogin;

import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfLogger;
import com.documentum.web.common.ArgumentList;
import com.documentum.web.common.WrapperRuntimeException;
import com.documentum.web.formext.session.AuthenticationService;
import com.documentum.web.formext.session.IAuthenticationScheme;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;


public class AutoLoginAuthenticationScheme implements IAuthenticationScheme {

    public String authenticate(HttpServletRequest request, HttpServletResponse response, String docbase) throws
                                                                                                         DfException {
        String callingComponentName = getCallingComponentName(request);
        DfLogger.debug(this, "Using AutoLogin", null, null);
        HttpSession sess = request.getSession();
        ComponentCredentials creds = null;
        try {
            creds = getComponentCredentials(callingComponentName);
        } catch (IOException e) {
            throw new WrapperRuntimeException("couldn't get component credentials", e);
        }
        if (creds.getDocbase() != null) {
            doAuthentication(sess, creds);
            return (String) creds.getDocbase();
        } else {
            DfLogger.debug(this, "Didn't find a match for component: " + callingComponentName, null, null);
            return null;
        }
    }

    protected ComponentCredentials getComponentCredentials(String callingComponentName) throws DfException,
                                                                                               IOException {
        return new ComponentCredentials(callingComponentName);
    }

    public String getLoginComponent(HttpServletRequest request, HttpServletResponse response, String docbase, ArgumentList outArgs) {
        return null;
    }

    private void doAuthentication(HttpSession sess, ComponentCredentials creds) throws DfException {
        String docbase = (String) creds.getDocbase();
        String username = (String) creds.getUser();
        String password = (String) creds.getPassword();
        String domain = (String) creds.getDomain();
        DfLogger.debug(this, "Trying to log in " + username + " into " + docbase, null, null);
        AuthenticationService.getService().login(sess, docbase, username, password, domain);
    }

    protected String getCallingComponentName(HttpServletRequest request) {
        String requestURI = request.getRequestURI();

        return requestURI.substring(requestURI.indexOf("component/") + "component/".length());
    }
}
