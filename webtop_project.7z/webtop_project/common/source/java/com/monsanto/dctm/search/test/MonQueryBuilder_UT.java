/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.search.test;

import com.documentum.fc.client.search.DfQueryFormatException;
import com.documentum.fc.client.search.IDfExpressionSet;
import com.documentum.fc.client.search.impl.DfSearchMetadataManager;
import com.documentum.fc.client.search.impl.DfSearchSourceMap;
import com.documentum.fc.client.search.impl.DfXMLUtil;
import com.monsanto.dctm.component.test.MockSessionManager;
import com.monsanto.dctm.search.MonExpressionSet;
import com.monsanto.dctm.search.MonQueryBuilder;
import junit.framework.TestCase;

/**
 * Filename:    $RCSfile: MonQueryBuilder_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: lakench $    	 On:	$Date: 2007-10-05 17:50:59 $
 *
 * @author lakench
 * @version $Revision: 1.1 $
 */
public class MonQueryBuilder_UT extends TestCase {
  public void testCreateWithJustMetadataManager() throws Exception {
    DfSearchMetadataManager metadataManager = new DfSearchMetadataManager(new MockSessionManager(),
        new DfSearchSourceMap(),
        "defaultmetadatadocbase");
    MonQueryBuilder monQueryBuilder = new MonQueryBuilder(metadataManager);

    IDfExpressionSet rootExpressionSet = monQueryBuilder.getRootExpressionSet();

    assertTrue(rootExpressionSet instanceof MonExpressionSet);
    assertEquals(metadataManager, monQueryBuilder.getMetadataMgr());
    assertEquals("dm_sysobject", monQueryBuilder.getObjectType());
    assertEquals(monQueryBuilder.getDateFormat(), rootExpressionSet.getDateFormat());

  }

  public void testCreateWithMetadataManagerAndObjectType() throws Exception {
    DfSearchMetadataManager metadataManager = new DfSearchMetadataManager(new MockSessionManager(),
        new DfSearchSourceMap(),
        "defaultmetadatadocbase");
    MonQueryBuilder monQueryBuilder = new MonQueryBuilder(metadataManager, "testobjecttype");

    IDfExpressionSet rootExpressionSet = monQueryBuilder.getRootExpressionSet();

    assertTrue(rootExpressionSet instanceof MonExpressionSet);
    assertEquals(metadataManager, monQueryBuilder.getMetadataMgr());
    assertEquals("testobjecttype", monQueryBuilder.getObjectType());
    assertEquals(monQueryBuilder.getDateFormat(), rootExpressionSet.getDateFormat());
  }

  public void testExceptionThrownForInvalidQueryDef() throws Exception {
    DfSearchMetadataManager metadataManager = new DfSearchMetadataManager(new MockSessionManager(),
        new DfSearchSourceMap(),
        "defaultmetadatadocbase");
    try {
      new MonQueryBuilder(metadataManager,
          DfXMLUtil.read(SearchTestUtils.generateInvalidStream()));
    } catch (DfQueryFormatException e) {
      //expected path
      return;
    }
    fail("didn't throw DfQueryFormatException exception");
  }

  public void testExceptionThrownForNoMaxResultsQueryDef() throws Exception {
    DfSearchMetadataManager metadataManager = new DfSearchMetadataManager(new MockSessionManager(),
        new DfSearchSourceMap(),
        "defaultmetadatadocbase");
    try {
      new MonQueryBuilder(metadataManager,
          DfXMLUtil.read(SearchTestUtils.generateQueryBuilderStreamWithoutMaxResults("\"false\"")));
    } catch (DfQueryFormatException e) {
      //expected path
      return;
    }
    fail("didn't throw DfQueryFormatException exception");
  }

  public void testExceptionThrownForPassThroughQueryDef() throws Exception {
    DfSearchMetadataManager metadataManager = new DfSearchMetadataManager(new MockSessionManager(),
        new DfSearchSourceMap(),
        "defaultmetadatadocbase");
    try {
      new MonQueryBuilder(metadataManager,
          DfXMLUtil.read(SearchTestUtils.generatePassThroughStream()));
    } catch (DfQueryFormatException e) {
      //expected path
      return;
    }
    fail("didn't throw DfQueryFormatException exception");
  }

  public void testValidQueryBuilderQueryDef() throws Exception {
    DfSearchMetadataManager metadataManager = new DfSearchMetadataManager(new MockSessionManager(),
        new DfSearchSourceMap(),
        "defaultmetadatadocbase");
    MonQueryBuilder monQueryBuilder = new MonQueryBuilder(metadataManager,
        DfXMLUtil.read(SearchTestUtils.generateQueryBuilderStream()));

    IDfExpressionSet rootExpressionSet = monQueryBuilder.getRootExpressionSet();

    assertTrue(rootExpressionSet instanceof MonExpressionSet);
    assertEquals(metadataManager, monQueryBuilder.getMetadataMgr());
    assertEquals("dm_document", monQueryBuilder.getObjectType());
    assertEquals(monQueryBuilder.getDateFormat(), rootExpressionSet.getDateFormat());
  }
}