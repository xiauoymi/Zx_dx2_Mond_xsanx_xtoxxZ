/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.appconfig.test;

import com.documentum.fc.client.MockSession;
import com.documentum.fc.common.DfException;
import com.documentum.web.form.ComponentTestUtils;
import com.documentum.web.form.control.databound.DataProvider;
import com.documentum.web.form.control.databound.Datagrid;
import com.monsanto.dctm.appconfig.AppConfigItem;
import com.monsanto.dctm.appconfig.AppConfigItemBaseComponent;
import com.monsanto.dctm.component.test.MockPersistentObject;
import com.monsanto.dctm.component.test.MockSessionManager;
import junit.framework.TestCase;

import java.util.*;

/**
 * Filename:    $RCSfile: AppConfigAuthRequestors_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: lakench $
 * On:	$Date: 2007-10-12 05:21:59 $
 *
 * @author lakench
 * @version $Revision: 1.3 $
 */
public class AppConfigAuthRequestors_UT extends TestCase {
  private MockAppConfigAuthRequestors appConfigAuthRequestors;
  private MockPersistentObject testAppOwnerInfoObject;

  protected void setUp() throws Exception {
    super.setUp();
    MockSessionManager mockSessionManager = new MockSessionManager();
    MockSession session = new MockSession(mockSessionManager);
    ((MockSessionManager) mockSessionManager).setSession(session);
    testAppOwnerInfoObject = new MockPersistentObject();
    setupTestAppOwnerInfoObjectAndAddToSession(testAppOwnerInfoObject, session);
    appConfigAuthRequestors = (MockAppConfigAuthRequestors) ComponentTestUtils
        .getComponent(MockAppConfigAuthRequestors.class, "appConfigAuthRequestors", "testdocbase", mockSessionManager);
    assertNotNull(appConfigAuthRequestors);
    appConfigAuthRequestors.setupComponent();
  }

  protected void tearDown() throws Exception {
    ComponentTestUtils.releaseComponent(appConfigAuthRequestors);
    super.tearDown();
  }

  public void testInitialized() throws Exception {
    Datagrid requestorGrid = (Datagrid) appConfigAuthRequestors.getControl(AppConfigItemBaseComponent.CONTROL_GRID);
    List actualDataFromGrid = getDataFromDatagrid(requestorGrid, getColumnsList());
    List expectedDataFromGrid = generateExpectedDataFromGrid();

    assertEquals(3, actualDataFromGrid.size());
    assertEquals(expectedDataFromGrid, actualDataFromGrid);
  }

  public void testAddRequestorThroughOnComplete() throws Exception {
    Map appConfigItemValues = new HashMap(3);
    appConfigItemValues.put("area", "testarea");
    appConfigItemValues.put("name", "testname");
    appConfigItemValues.put("email", "testemail");
    AppConfigItem appConfigItem = new AppConfigItem("mon_app_owner", appConfigItemValues);
    Map completionArgs = new HashMap(4);
    completionArgs.put("reallyadd", "true");
    completionArgs.put("appConfigItem", appConfigItem);

    appConfigAuthRequestors.onComplete("this can be anything for adds", false, completionArgs);

    Datagrid requestorGrid = (Datagrid) appConfigAuthRequestors.getControl(AppConfigItemBaseComponent.CONTROL_GRID);
    List actualDataFromGrid = getDataFromDatagrid(requestorGrid, getColumnsList());

    List expectedDataFromGrid = generateExpectedDataFromGrid();
    Map row4 = new HashMap(3);
    row4.put("area", "testarea");
    row4.put("name", "testname");
    row4.put("email", "testemail");
    expectedDataFromGrid.add(row4);

    assertEquals(4, actualDataFromGrid.size());
    assertEquals(expectedDataFromGrid, actualDataFromGrid);

    appConfigAuthRequestors.onCommitChanges();

    List actualDataFromAppOwnerObject = getDataFromAppOwnerInfoObject();
    assertEquals(4, actualDataFromAppOwnerObject.size());
    assertEquals(expectedDataFromGrid, actualDataFromAppOwnerObject);
  }

  public void testDontReallyAddRequestor() throws Exception {
    Map completionArgs = new HashMap(4);
    completionArgs.put("reallyadd", "false");

    appConfigAuthRequestors.onComplete("this can be anything for adds", false, completionArgs);

    Datagrid requestorGrid = (Datagrid) appConfigAuthRequestors.getControl(AppConfigItemBaseComponent.CONTROL_GRID);
    List actualDataFromGrid = getDataFromDatagrid(requestorGrid, getColumnsList());

    List expectedDataFromGrid = generateExpectedDataFromGrid();

    assertEquals(3, actualDataFromGrid.size());
    assertEquals(expectedDataFromGrid, actualDataFromGrid);

    appConfigAuthRequestors.onCommitChanges();

    List actualDataFromAppOwnerObject = getDataFromAppOwnerInfoObject();
    assertEquals(3, actualDataFromAppOwnerObject.size());
    assertEquals(expectedDataFromGrid, actualDataFromAppOwnerObject);
  }

  public void testRemoveRequestorThroughOnComplete() throws Exception {
    Map appConfigItemValues = new HashMap(4);
    appConfigItemValues.put("rowid", "1");
    appConfigItemValues.put("area", "testarea");
    appConfigItemValues.put("name", "testname");
    appConfigItemValues.put("email", "testemail");
    AppConfigItem appConfigItem = new AppConfigItem("mon_app_owner", appConfigItemValues);
    Map completionArgs = new HashMap(4);
    completionArgs.put("reallydelete", "true");
    completionArgs.put("appConfigItem", appConfigItem);

    appConfigAuthRequestors.onComplete("removeauthrequestor", false, completionArgs);

    Datagrid requestorGrid = (Datagrid) appConfigAuthRequestors.getControl(AppConfigItemBaseComponent.CONTROL_GRID);
    List actualDataFromGrid = getDataFromDatagrid(requestorGrid, getColumnsList());

    List expectedDataFromGrid = generateExpectedDataFromGrid();
    expectedDataFromGrid.remove(1);

    assertEquals(2, actualDataFromGrid.size());
    assertEquals(expectedDataFromGrid, actualDataFromGrid);

    appConfigAuthRequestors.onCommitChanges();

    List actualDataFromAppOwnerObject = getDataFromAppOwnerInfoObject();
    assertEquals(2, actualDataFromAppOwnerObject.size());
    assertEquals(expectedDataFromGrid, actualDataFromAppOwnerObject);
  }

  public void testDontReallyRemoveRequestor() throws Exception {
    Map completionArgs = new HashMap(4);
    completionArgs.put("reallydelete", "false");

    appConfigAuthRequestors.onComplete("removeappconfigrequestoraction", false, completionArgs);

    Datagrid requestorGrid = (Datagrid) appConfigAuthRequestors.getControl(AppConfigItemBaseComponent.CONTROL_GRID);
    List actualDataFromGrid = getDataFromDatagrid(requestorGrid, getColumnsList());

    List expectedDataFromGrid = generateExpectedDataFromGrid();

    assertEquals(3, actualDataFromGrid.size());
    assertEquals(expectedDataFromGrid, actualDataFromGrid);

    appConfigAuthRequestors.onCommitChanges();

    List actualDataFromAppOwnerObject = getDataFromAppOwnerInfoObject();
    assertEquals(3, actualDataFromAppOwnerObject.size());
    assertEquals(expectedDataFromGrid, actualDataFromAppOwnerObject);
  }

  private List getDataFromAppOwnerInfoObject() throws DfException {
    int numOfRequestors = testAppOwnerInfoObject.getValueCount("name");
    List actualDataFromAppOwnerObject = null;
    if (numOfRequestors > 0) {
      actualDataFromAppOwnerObject = new ArrayList(numOfRequestors);
      for (int i = 0; i < numOfRequestors; i++) {
        String area = testAppOwnerInfoObject.getRepeatingString("area", i);
        String name = testAppOwnerInfoObject.getRepeatingString("name", i);
        String email = testAppOwnerInfoObject.getRepeatingString("email", i);
        Map row = new HashMap(3);
        row.put("area", area);
        row.put("name", name);
        row.put("email", email);
        actualDataFromAppOwnerObject.add(row);
      }
    }
    return actualDataFromAppOwnerObject;
  }

  private List generateExpectedDataFromGrid() {
    Map expectedRow1 = new HashMap(3);
    expectedRow1.put("area", "area1");
    expectedRow1.put("name", "name1");
    expectedRow1.put("email", "email1");
    Map expectedRow2 = new HashMap(3);
    expectedRow2.put("area", "area2");
    expectedRow2.put("name", "name2");
    expectedRow2.put("email", "email2");
    Map expectedRow3 = new HashMap(3);
    expectedRow3.put("area", "area3");
    expectedRow3.put("name", "name3");
    expectedRow3.put("email", "email3");
    List expectedDataFromGrid = new ArrayList(3);
    expectedDataFromGrid.add(expectedRow1);
    expectedDataFromGrid.add(expectedRow2);
    expectedDataFromGrid.add(expectedRow3);
    return expectedDataFromGrid;
  }

  private List getColumnsList() {
    List listColumns = new ArrayList(3);
    listColumns.add("area");
    listColumns.add("name");
    listColumns.add("email");
    return listColumns;
  }

  private List getDataFromDatagrid(Datagrid requestorGrid, List listColumns) {
    List actualDataFromGrid = new ArrayList(3);
    DataProvider dataProvider = requestorGrid.getDataProvider();
    dataProvider.initBind();
    do {
      Iterator itColumns = listColumns.iterator();
      Map row = new HashMap(3);
      while (itColumns.hasNext()) {
        String columnName = (String) itColumns.next();
        assertTrue(dataProvider.hasDataField(columnName));
        String attributeValue = dataProvider.getDataField(columnName);
        row.put(columnName, attributeValue);
      }
      actualDataFromGrid.add(row);
    } while (dataProvider.nextRow());
    return actualDataFromGrid;
  }

  private void setupTestAppOwnerInfoObjectAndAddToSession(MockPersistentObject testAppOwnerInfoObject,
                                                          MockSession session) throws
      DfException {
    testAppOwnerInfoObject.setString("object_name", "testappcontext_app_owners");
    testAppOwnerInfoObject.setString("mon_app_context", "testappcontext");
    ArrayList areas = new ArrayList(3);
    areas.add("area1");
    areas.add("area2");
    areas.add("area3");
    testAppOwnerInfoObject.setRepeatingStrings("area", areas);
    ArrayList names = new ArrayList(3);
    names.add("name1");
    names.add("name2");
    names.add("name3");
    testAppOwnerInfoObject.setRepeatingStrings("name", names);
    ArrayList emails = new ArrayList(3);
    emails.add("email1");
    emails.add("email2");
    emails.add("email3");
    testAppOwnerInfoObject.setRepeatingStrings("email", emails);
    session.addObject(testAppOwnerInfoObject, "mon_app_owner_info where mon_app_context = 'testappcontext'");
  }
}