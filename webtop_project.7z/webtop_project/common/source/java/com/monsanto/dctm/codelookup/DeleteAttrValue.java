/*
 * DeleteAttrValue.java
 *
 * Created on January 20, 2006, 2:33 PM
 *
 * To change this template, choose Tools | Options and locate the template under
 * the Source Creation and Management node. Right-click the template and choose
 * Open. You can then make changes to the template in the Source Editor.
 */

package com.monsanto.dctm.codelookup;

import com.documentum.com.DfClientX;
import com.documentum.com.IDfClientX;
import com.documentum.fc.client.IDfCollection;
import com.documentum.fc.client.IDfQuery;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.IDfType;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.IDfAttr;
import com.documentum.nls.NlsResourceBundle;
import com.documentum.web.common.ArgumentList;
import com.documentum.web.common.ErrorMessageService;
import com.documentum.web.formext.component.Component;
import com.documentum.webcomponent.library.messages.MessageService;
import com.monsanto.dctm.monAppContext.MonAppContextService;

import java.util.Iterator;
import java.util.Map;

/**
 * @author tsvedan
 */
public class DeleteAttrValue extends Component {

    /**
     * Creates a new instance of DeleteAttrValue
     */
    public DeleteAttrValue() {
        codeType = null;
        attrValue = null;
        config = new NewCodeLookupConfig(getMonAppContext(), getDfSession());
    }

    public void onInit(ArgumentList args) {
        super.onInit(args);
        codeType = args.get("codeType");
        attrValue = args.get("attrValue");
//        System.out.println("DELETE VALUES..");
//        System.out.println("Code Type = " + codeType);
//        System.out.println("Attr Value = " + attrValue);
    }

    protected void execQuery() throws DfException {
        StringBuffer query = new StringBuffer();
        query.append("delete from dm_dbo.code_lookup where ");
        query.append("code_type='").append(codeType).append("' and ");
        query.append("decoded_value='").append(attrValue).append("'");

        IDfClientX clientx = new DfClientX();
        IDfQuery q = clientx.getQuery();
        q.setDQL(query.toString());
        q.execute(getDfSession(), IDfQuery.DF_QUERY);
    }

    protected IDfCollection execQuery(String query) throws DfException {

        IDfClientX clientx = new DfClientX();
        IDfQuery q = clientx.getQuery();
        q.setDQL(query);
        return q.execute(getDfSession(), IDfQuery.DF_READ_QUERY);

    }

    public boolean onCommitChanges() {
        boolean success = false;
        String nlsbundle = getConfigLookup().lookupString(buildConfigPath("nlsbundle"), getContext());
//        System.out.println("NlsBundle = " + nlsbundle);
        NlsResourceBundle nlsResBndl = new NlsResourceBundle(nlsbundle);
        if (isCodeActive()) {
            ErrorMessageService.getService().setNonFatalError(nlsResBndl, "MSG_CODE_VALUE_IN_USE", this, null, null);
            return false;
        }
        if (!config.isUserModifiable(codeType)) {
            ErrorMessageService.getService()
                    .setNonFatalError(nlsResBndl, "MSG_CODE_VALUE_NOT_MODIFIABLE", this, null, null);
            return false;
        }
        try {
            execQuery();
            success = true;
            MessageService.addMessage(this, "MSG_SUCCESS");
        } catch (DfException e) {
        } finally {
            return success;
        }
    }

    protected boolean isCodeActive() {
        boolean used = false;
        String typename = null;
        String attrname = null;
        Map map = config.getTypeAttrInfo(codeType);
        for (Iterator iter = map.keySet().iterator(); !used && iter.hasNext();) {
            typename = (String) iter.next();
            attrname = (String) map.get(typename);
//            System.out.println("Type = " + typename + "   Attr = " + attrname);
            used = isCodeActive(typename, attrname);
        }
        return used;
    }

    protected boolean isCodeActive(String typename, String attrname) {
        boolean used = false;
        StringBuffer query = new StringBuffer();
        query.append("select r_object_id from ").append(typename).append(" where ");
        if (getRepeating(typename, attrname))
            query.append("any ");
        query.append(attrname).append("='").append(attrValue).append("'");
        try {
            IDfCollection coll = execQuery(query.toString());
            if (coll != null) {
                if (coll.next())
                    used = true;
                coll.close();
            }
        } catch (DfException e) {
        }
        return used;
    }

    protected String getMonAppContext() {
        return (MonAppContextService.getMonAppContextService()).getCurrentMonAppContextName();
    }

    private boolean getRepeating(String typename, String attrname) {
        boolean rep = false;
        IDfSession sess = null;
        try {
            sess = getDfSession();
            IDfType type = sess.getType(typename);
            IDfAttr attr = type.getTypeAttr(type.findTypeAttrIndex(attrname));
            rep = attr.isRepeating();
//            System.out.println("Repeating?? " + rep);
        } catch (Exception e) {
//            System.out.println(e);
        }
        return rep;
    }

    private String codeType;
    private String attrValue;
    private ICodeLookupConfig config;
}
