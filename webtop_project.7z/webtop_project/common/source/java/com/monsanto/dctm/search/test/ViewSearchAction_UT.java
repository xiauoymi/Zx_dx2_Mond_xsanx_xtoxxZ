/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.search.test;

import com.documentum.fc.client.IDfSessionManager;
import com.documentum.fc.client.MockSession;
import com.documentum.fc.client.search.IDfSearchService;
import com.documentum.fc.client.search.IDfSmartList;
import com.documentum.fc.client.search.IDfSmartListDefinition;
import com.documentum.fc.client.search.impl.DfQueryManager;
import com.documentum.fc.client.search.impl.DfSearchService;
import com.documentum.fc.client.search.impl.DfSearchSourceMap;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.IDfId;
import com.documentum.web.common.ArgumentList;
import com.monsanto.dctm.component.test.MockDfSmartList;
import com.monsanto.dctm.component.test.MockSessionManager;
import com.monsanto.dctm.search.MonQueryManager;
import com.monsanto.dctm.search.MonSearchService;
import com.monsanto.dctm.search.ViewSearchAction;
import junit.framework.TestCase;

import java.io.ByteArrayInputStream;

/**
 * Filename:    $RCSfile: ViewSearchAction_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: lakench $    	 On:	$Date: 2007-11-19 22:05:22 $
 *
 * @author lakench
 * @version $Revision: 1.1 $
 */
public class ViewSearchAction_UT extends TestCase {
  public static final String TESTOBJECTID = "0900000000000000";
  private ViewSearchAction viewSearchAction;
  private MonQueryManager monQueryManager;
  private IDfSmartList smartList;
  private ArgumentList argumentList;

  protected void setUp() throws Exception {
    super.setUp();
    MockSessionManager sessionManager = new MockSessionManager();
    MockSession session = new MockSession(sessionManager);
    sessionManager.setSession(session);

    IDfSearchService searchService = new MonSearchService(
        new DfSearchService(sessionManager, "defaultnetadatadocbase"));
    viewSearchAction = new MockViewSearchAction(sessionManager, searchService);

    DfSearchSourceMap searchSourceMap = new DfSearchSourceMap();
    monQueryManager = new MonQueryManager(new DfQueryManager(sessionManager, searchSourceMap,
        "defaultMetadataDocbase"));

    smartList = new MockDfSmartList();
    smartList.setString("r_object_id", TESTOBJECTID);
    session.addObject(smartList, TESTOBJECTID);
    argumentList = new ArgumentList();
    argumentList.add("objectId", TESTOBJECTID);
  }

  public void testCreate() throws Exception {
    ViewSearchAction viewSearchAction = new ViewSearchAction();
    assertNotNull(viewSearchAction);
    assertTrue(viewSearchAction instanceof com.documentum.webcomponent.library.actions.ViewSearchAction);
  }

  public void testQueryExecuteWithBasicQueryDef() throws Exception {
    ByteArrayInputStream streamUTF8 = SearchTestUtils.generateQueryBuilderStream();
    IDfSmartListDefinition smartListDefinition = monQueryManager.loadSmartListDefinition(streamUTF8);
    smartList.setSmartListDefinition(smartListDefinition);

    assertTrue(viewSearchAction.queryExecute(null, null, argumentList, null, null));
  }

  public void testQueryExecuteWithNonQueryBuilderQueryDef() throws Exception {
    ByteArrayInputStream byteArrayInputStream = SearchTestUtils.generatePassThroughStream();
    IDfSmartListDefinition smartListDefinition = monQueryManager.loadSmartListDefinition(byteArrayInputStream);
    smartList.setSmartListDefinition(smartListDefinition);

    assertFalse(viewSearchAction.queryExecute(null, null, argumentList, null, null));
  }

  public void testQueryExecuteWithQueryDefWithCorrelatedQueryExpression() throws Exception {
    ByteArrayInputStream byteArrayInputStream = SearchTestUtils
        .generateQueryBuilderStreamWithCorrelatedQueryExpression();
    IDfSmartListDefinition smartListDefinition = monQueryManager.loadSmartListDefinition(byteArrayInputStream);
    smartList.setSmartListDefinition(smartListDefinition);

    assertTrue(viewSearchAction.queryExecute(null, null, argumentList, null, null));
  }

  public class MockViewSearchAction extends ViewSearchAction {
    private IDfSessionManager sessionManager;

    public MockViewSearchAction(IDfSessionManager sessionManager, IDfSearchService searchService) {
      this.sessionManager = sessionManager;
      setSearchService(searchService);
    }

    protected String getDocbaseName(IDfId idSavedSearchObject) throws DfException {
      return "testdocbase";
    }

    protected IDfSessionManager getSessionManager() {
      return sessionManager;
    }

    protected void setSearchService(IDfSearchService searchService) {
      super.setSearchService(searchService);
    }
  }
}