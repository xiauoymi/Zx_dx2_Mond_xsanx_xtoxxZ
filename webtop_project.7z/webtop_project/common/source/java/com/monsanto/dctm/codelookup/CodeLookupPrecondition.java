/*
 * CodeLookupPrecondition.java
 *
 * Created on January 31, 2006, 10:18 AM
 *
 * To change this template, choose Tools | Options and locate the template under
 * the Source Creation and Management node. Right-click the template and choose
 * Open. You can then make changes to the template in the Source Editor.
 */

package com.monsanto.dctm.codelookup;

import com.documentum.fc.client.IDfGroup;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.IDfSessionManager;
import com.documentum.fc.common.DfException;
import com.documentum.web.common.ArgumentList;
import com.documentum.web.formext.action.IActionPrecondition;
import com.documentum.web.formext.component.Component;
import com.documentum.web.formext.config.ConfigService;
import com.documentum.web.formext.config.Context;
import com.documentum.web.formext.config.IConfigElement;
import com.documentum.web.formext.session.SessionManagerHttpBinding;

import java.util.Iterator;

/**
 * @author tsvedan
 */
public class CodeLookupPrecondition implements IActionPrecondition {

    /**
     * Creates a new instance of CodeLookupPrecondition
     */
    public CodeLookupPrecondition() {
    }

    public String[] getRequiredParams() {
        return (new String[]{
                "codeType"
        });
    }

    public boolean queryExecute(String strAction, IConfigElement element, ArgumentList arg, Context context,
                                Component component) {
//        ICodeLookupConfig config = new CodeLookupConfig(getCurrentMonAppContextName(context), context);
//        String [] admins = config.getAdminGroup();
        boolean auth = isUserInGroup("docu");
//        for (int i=0; !auth && i<admins.length; i++){
//            auth = isUserInGroup(admins[i]);
//        }
        return auth;
    }

    private boolean isUserInGroup(String admingroup) {
        IDfGroup admins = null;
        String userName = SessionManagerHttpBinding.getUsername();
        System.out.println("YOUR NAME = " + userName);
        try {
            IDfSession sess = this.getDfSession();
            admins = sess.getGroup(admingroup);
            System.out.println("Present in " + admingroup + " = " + admins.isUserInGroup(userName));
            return admins.isUserInGroup(userName);
        } catch (Exception e) {
            System.out.println(e);
        }
        return false;
    }

    private String getMonAppContext(Context context) {
        String mon_app_context = null;
        String [] pairs = null;
        String strContext = "mon_app_context";
        String temp = context.toString();
        String contexts = temp.substring(temp.indexOf("SESSION("), temp.indexOf(")", temp.indexOf("SESSION(")));
        if (contexts.indexOf(",") > 0) {
            pairs = contexts.split(",");
            for (int i = 0; i < pairs.length; i++) {
                if (pairs[i].indexOf(strContext) != -1) {
                    pairs = pairs[i].split("=");
                    if (pairs.length == 2)
                        mon_app_context = pairs[1];
                    break;
                }
            }
        } else if (contexts.indexOf(strContext) >= 0) {
            pairs = contexts.split("=");
            if (pairs.length == 2)
                mon_app_context = pairs[1];
        }
//        System.out.println("Mon App Context = " + mon_app_context);
        return mon_app_context;
    }

    private String getAdminGroup(String monappcxt, Context context) {

        if (monappcxt == null || monappcxt.length() == 0)
            return "docu";

        String admins = "";
        String path = "component[id=codelookup].mon_app_contexts";
        IConfigElement element = ConfigService.getConfigLookup().lookupElement(path, context);
        Iterator iter = element.getChildElements("mon_app_context");
        while (iter.hasNext()) {
            element = (IConfigElement) iter.next();
            if (monappcxt.equals(element.getChildValue("name"))) {
                admins = element.getChildValue("admingroup");
                break;
            }
        }
        System.out.println("Admin group = " + admins);
        return admins;
    }

    private IDfSession getDfSession() {
        IDfSession sess = null;
        try {
            IDfSessionManager sMgr = SessionManagerHttpBinding.getSessionManager();
            sess = sMgr.getSession(SessionManagerHttpBinding.getCurrentDocbase());
        } catch (DfException e) {
        }
        return sess;
    }

}
