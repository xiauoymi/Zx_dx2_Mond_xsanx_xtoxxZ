package com.monsanto.dctm.preferences.general;

import com.documentum.web.common.ArgumentList;
import com.documentum.web.form.control.Panel;

public class AppGeneralPreferences
		extends
		com.documentum.webtop.webcomponent.environment.preferences.general.AppGeneralPreferences {

	public void onInit(ArgumentList args) {
		super.onInit(args);
		Panel hiddenObjectPanel = (Panel) getControl("displayHiddenObjectPanel", Panel.class);
		hiddenObjectPanel.setVisible(false);
	}

}
