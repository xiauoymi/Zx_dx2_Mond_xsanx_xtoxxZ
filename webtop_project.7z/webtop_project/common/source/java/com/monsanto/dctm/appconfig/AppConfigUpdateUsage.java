/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.appconfig;

import com.documentum.web.common.ArgumentList;
import com.documentum.web.form.control.DropDownList;
import com.documentum.web.form.control.Label;
import com.documentum.web.form.control.Option;
import com.documentum.web.form.control.Text;
import com.documentum.web.formext.component.Component;

import java.util.HashMap;
import java.util.Map;

/**
 * Filename:    $RCSfile: AppConfigUpdateUsage.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: lakench $    	 On:	$Date: 2007-08-21 05:23:14 $
 *
 * @author lakench
 * @version $Revision: 1.1 $
 */
public class AppConfigUpdateUsage extends Component {
  public static final String INSTRUCTIONS = "instructionscontrol";
  public static final String ADD_INSTRUCTIONS = "Please enter a new feature and indicate whether or not that feature is enabled for this application.  This feature will show up for all applications.";
  public static final String TYPE_DROPDOWN_NAME = "typedropdowncontrol";
  public static final String TYPE_TEXT_NAME = "typetextcontrol";
  public static final String ENABLED_DROPDOWN_NAME = "enableddropdowncontrol";
  public static final String REMOVE_INSTRUCTIONS = "Are you sure you want to delete this feature?";
  public static final String APP_CONFIG_ACTION_ARG = "appconfigaction";
  public static final String ADD_ACTION = "add";
  public static final String REMOVE_ACTION = "remove";
  public static final String UPDATE_INSTRUCTIONS = "Please update the use status of this feature for this application";
  public static final String UPDATE_ACTION = "update";
  private String appConfigAction;
  private AppConfigItem appConfigItemToRemove;

  public void onInit(ArgumentList argumentList) {
    super.onInit(argumentList);
    setupComponent(argumentList);
  }

  protected void setupComponent(ArgumentList args) {
    appConfigAction = args.get(APP_CONFIG_ACTION_ARG);
    Map values = new HashMap(3);
    values.put("rowid", args.get("rowid"));
    values.put("usage_type", args.get("usage_type"));
    values.put("usage_enabled", args.get("usage_enabled"));
    appConfigItemToRemove = new AppConfigItem("mon_app_usage", values);
    if (appConfigAction.equals(ADD_ACTION)) {
      setInstructionsLabel(ADD_INSTRUCTIONS);

      setupEnabledDropDownList((DropDownList) getControl(AppConfigUpdateUsage.ENABLED_DROPDOWN_NAME,
          DropDownList.class));
    } else if (appConfigAction.equals(REMOVE_ACTION)) {
      setInstructionsLabel(REMOVE_INSTRUCTIONS);

      setupTypeText(args.get("usage_type"));

      DropDownList enabledControl = (DropDownList) getControl(ENABLED_DROPDOWN_NAME, DropDownList.class);
      Option onlyOption = new Option();
      onlyOption.setValue(args.get("usage_enabled"));
      onlyOption.setLabel(args.get("usage_enabled"));
      enabledControl.addOption(onlyOption);
      enabledControl.setValue(args.get("usage_enabled"));
      enabledControl.setEnabled(false);
    } else if (appConfigAction.equals(UPDATE_ACTION)) {
      setInstructionsLabel(UPDATE_INSTRUCTIONS);

      setupTypeText(args.get("usage_type"));

      DropDownList enabledControl = (DropDownList) getControl(ENABLED_DROPDOWN_NAME, DropDownList.class);
      setupEnabledDropDownList(enabledControl);
      enabledControl.setValue(args.get("usage_enabled"));
    }
  }

  public boolean onCommitChanges() {
    setReturnValue(APP_CONFIG_ACTION_ARG, appConfigAction);
    if (appConfigAction.equals(REMOVE_ACTION)) {
      setReturnValue("reallydelete", "true");
    } else {
      setReturnValue("reallyadd", "true");
      appConfigItemToRemove.set("rowid", "0");
      Text typeControl = (Text) getControl(TYPE_TEXT_NAME);
      String usageType = typeControl.getValue();
      appConfigItemToRemove.set("usage_type", usageType);
      DropDownList enabledControl = (DropDownList) getControl(ENABLED_DROPDOWN_NAME);
      String usageEnabled = enabledControl.getValue();
      appConfigItemToRemove.set("usage_enabled", usageEnabled);
    }
    setReturnValue(AppConfigItemBaseComponent.APP_CONFIG_ITEM, appConfigItemToRemove);
    return super.onCommitChanges();
  }

  private void setupTypeText(String usageType) {
    Text typeControl = (Text) getControl(TYPE_TEXT_NAME, Text.class);
    typeControl.setValue(usageType);
    typeControl.setEnabled(false);
  }

  private void setInstructionsLabel(String instructions) {
    Label instructionsControl = (Label) getControl(AppConfigUpdateUsage.INSTRUCTIONS, Label.class);
    instructionsControl.setLabel(instructions);
  }

  private void setupEnabledDropDownList(DropDownList enabledControl) {
    Option yesOption = new Option();
    yesOption.setValue("Yes");
    yesOption.setLabel("Yes");
    enabledControl.addOption(yesOption);
    Option noOption = new Option();
    noOption.setValue("No");
    noOption.setLabel("No");
    enabledControl.addOption(noOption);
    Option unknownOption = new Option();
    unknownOption.setValue("Unknown");
    unknownOption.setLabel("Unknown");
    enabledControl.addOption(unknownOption);
  }
}