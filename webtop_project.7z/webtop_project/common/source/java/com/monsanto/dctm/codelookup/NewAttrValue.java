/*
 * NewAttrValue.java
 *
 * Created on January 19, 2006, 2:26 PM
 *
 * To change this template, choose Tools | Options and locate the template under
 * the Source Creation and Management node. Right-click the template and choose
 * Open. You can then make changes to the template in the Source Editor.
 */

package com.monsanto.dctm.codelookup;

import com.documentum.com.DfClientX;
import com.documentum.com.IDfClientX;
import com.documentum.fc.client.IDfCollection;
import com.documentum.fc.client.IDfQuery;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.IDfUser;
import com.documentum.fc.common.DfException;
import com.documentum.nls.NlsResourceBundle;
import com.documentum.web.common.ArgumentList;
import com.documentum.web.common.ErrorMessageService;
import com.documentum.web.form.control.Text;
import com.documentum.web.formext.component.Component;
import com.documentum.webcomponent.library.messages.MessageService;
import com.monsanto.dctm.monAppContext.MonAppContextService;

/**
 * @author tsvedan
 */
public class NewAttrValue extends Component {

    /**
     * Creates a new instance of NewAttrValue
     */
    public NewAttrValue() {
        codeType = null;
        codedValue = null;
        decodedValue = null;
        xrefValue = null;
        sortValue = null;

        config = new NewCodeLookupConfig(getMonAppContext(), getDfSession());
    }

    public void onInit(ArgumentList args) {
        super.onInit(args);
        codeType = args.get("codeType");

        Text text = (Text) getControl("code_type", com.documentum.web.form.control.Text.class);
        text.setValue(codeType);
        if (!isSuperUser())
            text.setEnabled(false);
    }

    public boolean canCommitChanges() {
        Text text = (Text) getControl("code_type");
        codeType = text.getValue();
        if (codeType != null)
            codeType = codeType.trim();
//        System.out.println("Code Type: " + codeType);
        text = (Text) getControl("coded_value");
        codedValue = text.getValue();
//        System.out.println("Coded Value: " + codedValue);
        text = (Text) getControl("decoded_value");
        decodedValue = text.getValue();
        if (decodedValue != null)
            decodedValue = decodedValue.trim();
//        System.out.println("Actual Value: " + decodedValue);
        text = (Text) getControl("xref_value");
        xrefValue = text.getValue();
//        System.out.println("Reference Value: " + xrefValue);
        text = (Text) getControl("sort_value");
        sortValue = text.getValue();
//        System.out.println("Sort Value: " + sortValue);
        return true;
    }

    public boolean onCommitChanges() {
        boolean success = false;
        if (!isValid())
            return false;
        if (!config.isUserModifiable(codeType)) {
            NlsResourceBundle nlsResBndl = getNlsResBndl();
            ErrorMessageService.getService()
                    .setNonFatalError(nlsResBndl, "MSG_CODE_VALUE_NOT_MODIFIABLE", this, null, null);
            return false;
        }
        try {
            execQuery();
            success = true;
            MessageService.addMessage(this, "MSG_SUCCESS");
        } catch (DfException e) {
        } finally {
            return success;
        }
    }

    protected boolean isValid() {
        if (codeType == null || decodedValue == null)
            return false;
        NlsResourceBundle nlsResBndl = getNlsResBndl();
        if (codeType.length() == 0) {
            ErrorMessageService.getService().setNonFatalError(nlsResBndl, "MSG_ERROR_NO_CODE_TYPE", this, null, null);
            return false;
        }
        if (decodedValue.length() == 0) {
            ErrorMessageService.getService()
                    .setNonFatalError(nlsResBndl, "MSG_ERROR_NO_DECODED_VALUE", this, null, null);
            return false;
        }
        try {
            if (duplicate()) {
                ErrorMessageService.getService()
                        .setNonFatalError(nlsResBndl, "MSG_ERROR_DUPLICATE_VALUE", this, null, null);
                return false;
            }
        } catch (DfException e) {
        }
        return true;
    }

    protected boolean duplicate() throws DfException {
        boolean dupe = false;
        StringBuffer query = new StringBuffer();
        query.append("select decoded_value from dm_dbo.code_lookup where code_type='");
        query.append(codeType).append("' and decoded_value='").append(decodedValue).append("'");

        IDfCollection coll = null;
        IDfClientX clientx = new DfClientX();
        IDfQuery q = clientx.getQuery();
        q.setDQL(query.toString());
        try {
            coll = q.execute(getDfSession(), IDfQuery.DF_READ_QUERY);
            String value = null;
            if (coll != null && coll.next())
                value = coll.getString("decoded_value");
//            System.out.println("Collection decoded value = " + value);
            if (value != null && decodedValue.equalsIgnoreCase(value.trim()))
                dupe = true;
        } catch (DfException e) {
        } finally {
            if (coll != null)
                coll.close();
        }
        return dupe;
    }

    protected void execQuery() throws DfException {
        StringBuffer query = new StringBuffer();
        query.append("insert into dm_dbo.code_lookup values('");
        query.append(codeType).append("','").append(codedValue);
        query.append("','").append(decodedValue).append("','");
        query.append(xrefValue).append("','").append(sortValue);
        query.append("')");

        IDfClientX clientx = new DfClientX();
        IDfQuery q = clientx.getQuery();
        q.setDQL(query.toString());
        q.execute(getDfSession(), IDfQuery.DF_QUERY);
    }

    protected String getMonAppContext() {
        return (MonAppContextService.getMonAppContextService()).getCurrentMonAppContextName();
    }

    protected NlsResourceBundle getNlsResBndl() {
        String nlsbundle = getConfigLookup().lookupString(buildConfigPath("nlsbundle"), getContext());
//        System.out.println("NlsBundle = " + nlsbundle);
        return new NlsResourceBundle(nlsbundle);
    }

    private boolean isSuperUser() {
        boolean bRetValue = false;
        IDfSession session = null;
        try {
            session = getDfSession();
            IDfUser userObject = session.getUser(session.getLoginUserName());
            if (userObject != null && userObject.getUserPrivileges() == 16)
                return true;
        } catch (DfException e) {
            e.printStackTrace();
        }
        return bRetValue;
    }

    private String codeType;
    private String codedValue;
    private String decodedValue;
    private String xrefValue;
    private String sortValue;

    private ICodeLookupConfig config;
}
