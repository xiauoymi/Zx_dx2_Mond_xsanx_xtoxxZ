package com.monsanto.dctm.report;

import com.documentum.web.common.ArgumentList;
import com.documentum.web.formext.action.IActionPrecondition;
import com.documentum.web.formext.component.Component;
import com.documentum.web.formext.config.ConfigService;
import com.documentum.web.formext.config.Context;
import com.documentum.web.formext.config.IConfigElement;

public class ReportActionPrecondition implements IActionPrecondition {

	public boolean queryExecute(String strAction, IConfigElement config, ArgumentList arg, Context context, Component component) {
		return (ConfigService.getConfigLookup().lookupElement("component[id=reportselector].reports", context) != null);
	}

	public String[] getRequiredParams() {
		return null;
	}

}
