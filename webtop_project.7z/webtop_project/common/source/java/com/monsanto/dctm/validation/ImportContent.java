package com.monsanto.dctm.validation;

import com.documentum.fc.client.IDfValidator;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfList;
import com.documentum.fc.common.DfProperties;
import com.documentum.fc.common.IDfList;
import com.documentum.fc.common.IDfProperties;
import com.documentum.web.form.Control;
import com.documentum.web.form.control.Text;
import com.documentum.web.formext.control.docbase.DocbaseObject;
import com.documentum.web.formext.session.DocbaseUtils;
import com.documentum.webcomponent.common.WebComponentErrorService;

public class ImportContent extends com.monsanto.dctm.importcontent.ImportContent {

	public boolean canCommitChanges() {
		return isObjectNameValid();
	}

    private boolean isObjectNameValid()
    {
        boolean isValid = true;
        String strObjectName = "";
        try
        {
            Text objectNameField = getObjectNameTextControl(false);
            if(objectNameField != null)
            {
                strObjectName = getObjectNameTextControl(false).getValue();
                if(strObjectName != null && strObjectName.length() > 0)
                {
                    DocbaseObject docbaseObj = (DocbaseObject)getControl("docbaseObj", com.documentum.web.formext.control.docbase.DocbaseObject.class);
                    IDfProperties props = new DfProperties();
                    IDfList values = new DfList(2);
                    values.appendString(strObjectName);
                    props.putList("object_name", values);
                    IDfValidator validator = docbaseObj.getDfValidator();
                    validator.validateAll(props, false);
                }
            }
        }
        catch(DfException e)
        {
        	if (!DocbaseUtils.getValidationExceptionMsg(e).equals(" :  Default error message"))
        	{
        		isValid = false;
        		String params[] = new String[1];
        		params[0] = DocbaseUtils.getValidationExceptionMsg(e);
        		WebComponentErrorService.getService().setNonFatalError(this, "MSG_VALIDATION_ERROR", params, null);
        	}
        }
        return isValid;
    }
	
    private Text getObjectNameTextControl(boolean create)
    {
        return (Text)getControl0("attribute_object_name", create, com.documentum.web.form.control.Text.class);
    }

    private Control getControl0(String name, boolean create, Class cl)
    {
        return create ? getControl(name, cl) : getControl(name);
    }
}
