package com.monsanto.dctm.inbox;

import com.monsanto.dctm.monAppContext.MonAppContextService;

public class InboxStreamline extends
                             com.documentum.webtop.webcomponent.inbox.InboxStreamline {

    protected String getColumnsPreferenceId() {
        return super.getColumnsPreferenceId() + "." +
               MonAppContextService.getMonAppContextService().getMonAppContextInternalName();
    }
}
