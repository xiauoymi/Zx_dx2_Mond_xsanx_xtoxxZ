/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.component.test;

import com.documentum.fc.client.*;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.IDfId;
import com.documentum.fc.common.IDfList;

/**
 * Filename:    $RCSfile: MockPersistentObject.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: lakench $
 * On:	$Date: 2007-10-12 05:21:59 $
 *
 * @author lakench
 * @version $Revision: 1.4 $
 */
public class MockPersistentObject extends MockTypedObject implements IDfPersistentObject {
  public boolean wasDestroyCalled = false;

  public boolean isReplica() throws DfException {
    return false;
  }

  public int getVStamp() throws DfException {
    return 0;
  }

  public void destroy() throws DfException {
    wasDestroyCalled = true;
  }

  public IDfType getType() throws DfException {
    return new MockDfType();
  }

  public boolean isDirty() throws DfException {
    return false;
  }

  public boolean isNew() throws DfException {
    return false;
  }

  public void revert() throws DfException {
  }

  public void save() throws DfException {
  }

  public String apiGet(String string, String string1) throws DfException {
    return null;
  }

  public boolean apiSet(String string, String string1, String string2) throws DfException {
    return false;
  }

  public boolean apiExec(String string, String string1) throws DfException {
    return false;
  }

  public boolean fetch(String string) throws DfException {
    return false;
  }

  public boolean fetchWithCaching(String string, boolean b, boolean b1) throws DfException {
    return false;
  }

  public IDfRelation addChildRelative(String string, IDfId iDfId, String string1, boolean b, String string2) throws
      DfException {
    return null;
  }

  public IDfRelation addParentRelative(String string, IDfId iDfId, String string1, boolean b, String string2) throws
      DfException {
    return null;
  }

  public void removeChildRelative(String string, IDfId iDfId, String string1) throws DfException {
  }

  public void removeParentRelative(String string, IDfId iDfId, String string1) throws DfException {
  }

  public IDfCollection getChildRelatives(String string) throws DfException {
    return null;
  }

  public IDfCollection getParentRelatives(String string) throws DfException {
    return null;
  }

  public boolean isDeleted() throws DfException {
    return false;
  }

  public void signoff(String string, String string1, String string2) throws DfException {
  }

  public void validateAllRules(int i) throws DfException {
  }

  public void validateObjRules(int i) throws DfException {
  }

  public void validateAttrRules(String string, int i) throws DfException {
  }

  public void validateAttrRulesWithValue(String string, String string1, int i) throws DfException {
  }

  public void validateAttrRulesWithValues(String string, IDfList iDfList, int i) throws DfException {
  }

  public void validateObjRulesWithValues(IDfList iDfList, IDfList iDfList1, int i) throws DfException {
  }

  public IDfList getAttrAsstDependencies(String string) throws DfException {
    return null;
  }

  public IDfList getAttrAssistance(String string) throws DfException {
    return null;
  }

  public IDfList getAttrAssistanceWithValues(String string, IDfList iDfList, IDfList iDfList1) throws DfException {
    return null;
  }

  public String getWidgetType(int i, String string) throws DfException {
    return null;
  }

  public IDfValidator getValidator() throws DfException {
    return null;
  }
}