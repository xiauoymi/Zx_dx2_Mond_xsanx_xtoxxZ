package com.monsanto.dctm.viewprocessor;

public class BookmarkLinkTag extends com.documentum.web.form.control.BookmarkLinkTag 
{

	protected Class getControlClass()
    {
        return com.monsanto.dctm.viewprocessor.BookmarkLink.class;
    }
}
