package com.monsanto.dctm.monAppContext.preferences;

import com.monsanto.dctm.monAppContext.MonAppContextService;

public class Preference extends
                        com.documentum.web.formext.control.preference.Preference {

    public String getPreferenceKey(String strPreference) {
        return super.getPreferenceKey(strPreference) + "." +
               MonAppContextService.getMonAppContextService().getMonAppContextInternalName();
    }

    public String getPreferenceKey() {
        return super.getPreferenceKey() + "." +
               MonAppContextService.getMonAppContextService().getMonAppContextInternalName();
    }

}
