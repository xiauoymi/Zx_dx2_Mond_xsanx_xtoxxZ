/*
 Copyright:  Copyright � 2006 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.action;

import com.documentum.fc.common.DfException;
import com.documentum.web.common.ArgumentList;
import com.documentum.web.formext.action.IActionExecution;
import com.documentum.web.formext.component.Component;
import com.documentum.web.formext.config.Context;
import com.documentum.web.formext.config.IConfigElement;

import java.util.Map;

/**
 * Filename:    $RCSfile: Flush.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: tsvedan $    	 On:	$Date: 2006-11-14 22:44:18 $
 *
 * @author tsvedan
 * @version $Revision: 1.1 $
 */
public class Flush implements IActionExecution {
  public boolean execute(String string, IConfigElement iConfigElement, ArgumentList argumentList, Context context,
                         Component component, Map map) {
    try {
      component.getDfSession().flush("querycache", null);
    } catch (DfException e) {
      e.printStackTrace();
    }
    return true;
  }

  public String[] getRequiredParams() {
    return new String[0];
  }
}