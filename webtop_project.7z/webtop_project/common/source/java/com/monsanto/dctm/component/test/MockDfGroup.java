/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.component.test;

import com.documentum.fc.client.IDfCollection;
import com.documentum.fc.client.IDfGroup;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.IDfId;
import com.documentum.fc.common.IDfTime;

import java.util.ArrayList;
import java.util.List;

/**
 * Filename:    $RCSfile: MockDfGroup.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: lakench $    	 On:	$Date: 2007-05-18 15:34:21 $
 *
 * @author lakench
 * @version $Revision: 1.1 $
 */
public class MockDfGroup extends MockPersistentObject implements IDfGroup {
    private List users = new ArrayList();
    private String groupName;
    private List groups = new ArrayList();
    private List allUsersNames = new ArrayList();

    public void setAllUsersNames(List allUsersNames) {
        this.allUsersNames = allUsersNames;
    }

    public String getOwnerName() throws DfException {
        return null;
    }

    public String getGroupName() throws DfException {
        return groupName;
    }

    public String getGroupAddress() throws DfException {
        return null;
    }

    public String getUsersNames(int i) throws DfException {
        return (String) users.get(i);
    }

    public int getUsersNamesCount() throws DfException {
        return users.size();
    }

    public String getGroupsNames(int i) throws DfException {
        return (String) groups.get(i);
    }

    public int getGroupsNamesCount() throws DfException {
        return groups.size();
    }

    public boolean isPrivate() throws DfException {
        return false;
    }

    public String getDescription() throws DfException {
        return null;
    }

    public String getAllUsersNames(int i) throws DfException {
        return (String) allUsersNames.get(i);
    }

    public int getAllUsersNamesCount() throws DfException {
        return allUsersNames.size();
    }

    public boolean isGloballyManaged() throws DfException {
        return false;
    }

    public IDfTime getModifyDate() throws DfException {
        return null;
    }

    public IDfId getAliasSetId() throws DfException {
        return null;
    }

    public void setAliasSetId(IDfId iDfId) throws DfException {
    }

    public boolean isUserInGroup(String user) throws DfException {
        return users.contains(user);
    }

    public boolean isGroupInGroup(String group) throws DfException {
        return groups.contains(group);
    }

    public void renameGroup(String groupName, boolean b, boolean b1, boolean b2) throws DfException {
    }

    public void setGroupName(String groupName) throws DfException {
        this.groupName = groupName;
    }

    public void setGroupAddress(String attrName) throws DfException {
    }

    public void setDescription(String attrName) throws DfException {
    }

    public void setPrivate(boolean b) throws DfException {
    }

    public void setOwnerName(String attrName) throws DfException {
    }

    public void setGloballyManaged(boolean b) throws DfException {
    }

    public boolean addUser(String user) throws DfException {
        if (users.contains(user)) {
            return false;
        } else {
            users.add(user);
            return true;
        }
    }

    public boolean addGroup(String group) throws DfException {
        if (groups.contains(group)) {
            return false;
        } else {
            groups.add(group);
            return true;
        }
    }

    public boolean removeUser(String user) throws DfException {
        if (users.contains(user)) {
            users.remove(user);
            return true;
        } else {
            return false;
        }
    }

    public boolean removeGroup(String attrName) throws DfException {
        return false;
    }

    public void removeAllUsers() throws DfException {
        users.clear();
    }

    public void removeAllGroups() throws DfException {
        groups.clear();
    }

    public IDfCollection getUsersNames() throws DfException {
        return null;
    }

    public IDfCollection getGroupsNames() throws DfException {
        return null;
    }

    public void setGroupClass(String attrName) throws DfException {
    }

    public String getGroupClass() throws DfException {
        return null;
    }

    public void setGroupAdmin(String attrName) throws DfException {
    }

    public String getGroupAdmin() throws DfException {
        return null;
    }

    public void setDynamic(boolean b) throws DfException {
    }

    public boolean getDynamic() throws DfException {
        return false;
    }

    public void setDynamicDefault(boolean b) throws DfException {
    }

    public boolean getDynamicDefault() throws DfException {
        return false;
    }

    public String getGroupDisplayName() throws DfException {
        return null;
    }

    public void setGroupDisplayName(String attrName) throws DfException {
    }

    public IDfId getGroupNativeRoomId() throws DfException {
        return null;
    }

    public void setGroupNativeRoomId(IDfId iDfId) throws DfException {
    }
}