/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.component.test;

import com.documentum.fc.client.IDfCollection;
import com.documentum.fc.client.IDfTypedObject;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.IDfAttr;

import java.io.ByteArrayInputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Filename:    $RCSfile: MockDfCollection.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: lakench $    	 On:	$Date: 2007-04-25 16:51:05 $
 *
 * @author lakench
 * @version $Revision: 1.1 $
 */
public class MockDfCollection extends MockTypedObject implements IDfCollection {
    private boolean collectionContainsResults;
    private List results = new ArrayList();
    private int index = 0;
    private Map currentRow = new HashMap();
    public boolean isClosed;

    public MockDfCollection(boolean collectionContainsResults, List results) {

        this.collectionContainsResults = collectionContainsResults;
        this.results = results;
        isClosed = false;

    }

    public boolean next() throws DfException {
        boolean nextOk = collectionContainsResults && (index < results.size());
        if (nextOk) {
            currentRow = (Map) results.get(index);
            index++;
        }
        return nextOk;
    }

    public IDfTypedObject getTypedObject() throws DfException {
        return null;
    }

    public void close() throws DfException {
        isClosed = true;
    }

    public int getState() {
        return 0;
    }

    public ByteArrayInputStream getBytesBuffer(String attrName, String attrName1, String attrName2, int i) throws
                                                                                                           DfException {
        return null;
    }

    public String getRepeatingString(String string, int i) throws DfException {
        if (currentRow.containsKey(string)) {
            Object value = ((List) currentRow.get(string)).get(i);
            return (String) value;
        } else {
            throw new DfException("attribute, \"" + string + "\" not found");
        }
    }

    public int getAttrCount() throws DfException {
        return currentRow.size();
    }

    public IDfAttr getAttr(int i) throws DfException {
        return new MockDfAttr((String) currentRow.keySet().toArray()[i]);
    }
}