package com.monsanto.dctm.subscription;

import com.monsanto.dctm.monAppContext.MonAppContextService;

public class SubscriptionsStreamlineView
        extends
        com.documentum.webtop.webcomponent.subscription.SubscriptionsStreamlineView {

    protected String getColumnsPreferenceId() {
        return super.getColumnsPreferenceId() + "." +
               MonAppContextService.getMonAppContextService().getMonAppContextInternalName();
    }

}
