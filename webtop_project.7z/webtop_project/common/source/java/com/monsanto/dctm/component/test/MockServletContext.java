/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.component.test;

import javax.servlet.RequestDispatcher;
import javax.servlet.Servlet;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

/**
 * Filename:    $RCSfile: MockServletContext.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: lakench $    	 On:	$Date: 2007-03-02 22:44:20 $
 *
 * @author lakench
 * @version $Revision: 1.3 $
 */
public class MockServletContext implements ServletContext {
    private Map attributes = new HashMap();

    public ServletContext getContext(String string) {
        return null;
    }

    public int getMajorVersion() {
        return 0;
    }

    public int getMinorVersion() {
        return 0;
    }

    public String getMimeType(String string) {
        return null;
    }

    public Set getResourcePaths(String string) {
        return null;
    }

    public URL getResource(String strResourcePath) throws MalformedURLException {
        return null;
    }

    public InputStream getResourceAsStream(String string) {
        return null;
    }

    public RequestDispatcher getRequestDispatcher(String string) {
        return null;
    }

    public RequestDispatcher getNamedDispatcher(String string) {
        return null;
    }

    public Servlet getServlet(String string) throws ServletException {
        return null;
    }

    public Enumeration getServlets() {
        return null;
    }

    public Enumeration getServletNames() {
        return null;
    }

    public void log(String string) {
    }

    public void log(Exception exception, String string) {
    }

    public void log(String string, Throwable throwable) {
    }

    public String getRealPath(String path) {
        if (path.equals("/")) return "./common/source/conifg/test";
        else return null;
    }

    public String getServerInfo() {
        return null;
    }

    public String getInitParameter(String string) {
        return null;
    }

    public Enumeration getInitParameterNames() {
        return null;
    }

    public Object getAttribute(String string) {
        return attributes.get(string);
    }

    public Enumeration getAttributeNames() {
        return (Enumeration) attributes.keySet().iterator();
    }

    public void setAttribute(String attrName, Object object) {
        attributes.put(attrName, object);
    }

    public void removeAttribute(String string) {
        attributes.remove(string);
    }

    public String getServletContextName() {
        return null;
    }
}