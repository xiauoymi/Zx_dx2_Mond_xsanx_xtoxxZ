/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.monAppContext;

import com.documentum.web.formext.config.ConfigService;
import com.documentum.web.formext.config.Context;
import com.documentum.web.formext.config.IConfigElement;
import com.documentum.web.formext.config.IConfigLookup;

import java.util.*;

/**
 * Filename:    $RCSfile: AppXmlMonAppContexts.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: lakench $    	 On:	$Date: 2007-03-02 22:44:20 $
 *
 * @author lakench
 * @version $Revision: 1.4 $
 */
public class AppXmlMonAppContexts implements IMonAppContexts {
    private Context context;
    private Map monAppContexts = new HashMap();

    public AppXmlMonAppContexts() {
        this(Context.getSessionContext());
    }

    public AppXmlMonAppContexts(Context context) {
        this.context = context;
        initMonAppContexts();

    }

    private void initMonAppContexts() {
        IConfigLookup lookup = ConfigService.getConfigLookup();
        if (context != null) {
            IConfigElement configMonAppContexts = lookup.lookupElement("application.mon_app_contexts", context);

            if (configMonAppContexts != null) {
                Iterator iterMonAppContexts = configMonAppContexts.getChildElements("context");
                while (iterMonAppContexts.hasNext()) {
                    IConfigElement configMonAppContext = (IConfigElement) iterMonAppContexts.next();
                    String monAppContext = configMonAppContext.getChildValue("name");
                    monAppContexts.put(monAppContext, new AppXmlMonAppContext(configMonAppContext));
                }
            }
        }
    }

    public IMonAppContext getMonAppContext(String currentMonAppContextName) {
        if (currentMonAppContextName == null || (currentMonAppContextName.length() == 0) ||
            !monAppContexts.containsKey(currentMonAppContextName)) {
            return (IMonAppContext) new NullMonAppContext();
        } else {
            return (IMonAppContext) monAppContexts.get(currentMonAppContextName);
        }
    }

    public List getMonAppContextNameList(String docbase) {

        List monAppContextNames = new ArrayList();
        Iterator monAppContextEntries = monAppContexts.entrySet().iterator();
        while (monAppContextEntries.hasNext()) {
            Map.Entry monAppContextEntry = (Map.Entry) monAppContextEntries.next();
            String monAppContextName = (String) monAppContextEntry.getKey();
            IMonAppContext monAppContext = (IMonAppContext) monAppContextEntry.getValue();
            if (monAppContext.isDocbaseSupported(docbase)) monAppContextNames.add(monAppContextName);
        }
        Collections.sort(monAppContextNames);
        return monAppContextNames;
    }
}