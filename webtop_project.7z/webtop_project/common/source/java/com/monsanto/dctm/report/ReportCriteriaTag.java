package com.monsanto.dctm.report;

import java.io.IOException;
import java.util.Iterator;
import java.util.List;

import javax.servlet.jsp.JspTagException;
import javax.servlet.jsp.JspWriter;

import com.documentum.web.common.WrapperRuntimeException;
import com.documentum.web.form.Control;
import com.documentum.web.form.ControlTag;

public class ReportCriteriaTag extends ControlTag {

	private String pre;
	private String col1;
	private String col2;
	private String post;
	private String configId;
	
	public void release() {
		super.release();
		pre = null;
		col1 = null;
		col2 = null;
		post = null;
		configId = null;
	}

	public String getCol1() {
		return col1;
	}

	public void setCol1(String col1) {
		this.col1 = col1;
	}

	public String getCol2() {
		return col2;
	}

	public void setCol2(String col2) {
		this.col2 = col2;
	}

	public String getPost() {
		return post;
	}

	public void setPost(String post) {
		this.post = post;
	}

	public String getPre() {
		return pre;
	}

	public void setPre(String pre) {
		this.pre = pre;
	}

    public String getConfigId() {
		return configId;
	}

	public void setConfigId(String configId) {
		this.configId = configId;
	}

	protected void setControlProperties(Control control) {
        super.setControlProperties(control);
        
        ReportCriteria reportCriteria = (ReportCriteria) control;
        if (getPre() != null) {
            reportCriteria.setPre(getPre());
        }
        if (getCol1() != null) {
            reportCriteria.setCol1(getCol1());
        }
        if (getCol2() != null) {
            reportCriteria.setCol2(getCol2());
        }
        if (getPost() != null) {
            reportCriteria.setPost(getPost());
        }
    }

	protected Class getControlClass() {
		return com.monsanto.dctm.report.ReportCriteria.class;
	}

    protected void renderEnd(JspWriter out) throws IOException, JspTagException {
        ReportCriteria reportCriteria = (ReportCriteria) getControl();

        if (reportCriteria.isVisible()) {
            renderCriteria(reportCriteria);
        }
    }

	protected void renderCriteria(ReportCriteria reportCriteria) throws JspTagException {
		List criteriaList = reportCriteria.getCriteriaConfig();
		
		Iterator criteria = criteriaList.iterator();
		while (criteria.hasNext())
		{
			renderCriterionControl((Criterion) criteria.next());
		}
	}

	private void renderCriterionControl(Criterion criterion) throws JspTagException {
		
		String pre = getPre();
		if (pre == null)
			pre = "<tr><td align=\"right\" scope=\"row\" nowrap class=\"fieldlabel\">";
		String post = getPost();
		if (post == null)
			post = "</td></tr>";
		String col1 = getCol1();
		if (col1 == null)
			col1 = "</td><td nowrap align='left' class='defaultcolumnspacer'>:</td><td>";
		String col2 = getCol2();
		if (col2 == null)
			col2 = "</td><td>";;
		
		ReportCriterionTag criterionTag = getReportCriterionTagInstance(criterion);
		criterionTag.setCriterion(criterion);
		criterionTag.setPre(pre);
		criterionTag.setPost(post);
		criterionTag.setCol1(col1);
		criterionTag.setCol2(col2);
		criterionTag.setCriteria(getName());
		criterionTag.setName(getControl().getElementName("criterion"));
		criterionTag.setPageContext(pageContext);
		criterionTag.setParent(this);
		
		criterionTag.doStartTag();
		criterionTag.doEndTag();
	}

	private ReportCriterionTag getReportCriterionTagInstance(Criterion criterion) {
		String tagclass = com.monsanto.dctm.report.ReportCriterionTag.class.getName();
		if (criterion != null)
		{
			String tagclassFromCriterion = criterion.getTagclass();
			if (tagclassFromCriterion != null && tagclassFromCriterion.length() > 0)
			{
				tagclass = tagclassFromCriterion;
			}
		}
		try {
			return (ReportCriterionTag) Class.forName(tagclass).newInstance();
		} catch (InstantiationException e) {
			throw new WrapperRuntimeException("Could not create ReportCriterionLabelTag instance", e);
		} catch (IllegalAccessException e) {
			throw new WrapperRuntimeException("Could not create ReportCriterionLabelTag instance", e);
		} catch (ClassNotFoundException e) {
			throw new WrapperRuntimeException("Could not create ReportCriterionLabelTag instance", e);
		}
	}
}
