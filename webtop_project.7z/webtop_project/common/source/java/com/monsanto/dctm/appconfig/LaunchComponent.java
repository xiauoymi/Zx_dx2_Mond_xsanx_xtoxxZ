/*
 Copyright:  Copyright � 2006 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.appconfig;

import com.documentum.web.common.ArgumentList;
import com.documentum.web.formext.action.ActionService;
import com.documentum.web.formext.action.IActionCompleteListener;
import com.documentum.web.formext.component.Component;
import com.documentum.web.formext.config.Context;
import com.documentum.web.formext.config.IConfigElement;

import java.util.Map;

/**
 * Filename:    $RCSfile: LaunchComponent.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: lakench $ On:	$Date:
 * 2006/10/30 20:02:11 $
 *
 * @author lakench
 * @version $Revision: 1.6 $
 */
public class LaunchComponent extends com.documentum.web.formext.action.LaunchComponent {

  public boolean execute(String strAction, IConfigElement config, ArgumentList args, Context context,
                         Component component, Map completionArgs) {
    addCallingComponentAsActionCompleteListenerIfItIsOne(component, completionArgs);
    return super.execute(strAction, config, args, context, component, completionArgs);
  }

  protected void addCallingComponentAsActionCompleteListenerIfItIsOne(Component component, Map completionArgs) {
    if (component instanceof IActionCompleteListener) {
      completionArgs.put(ActionService.COMPLETE_LISTENER, component);
    }
  }
}