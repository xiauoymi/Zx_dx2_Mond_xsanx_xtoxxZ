package com.monsanto.dctm.search;

import com.documentum.fc.client.search.IDfSearchMetadataManager;
import com.documentum.fc.client.search.impl.DfEncrypter;
import com.documentum.fc.client.search.impl.DfQueryBuilder;
import com.documentum.fc.client.search.impl.DfXMLUtil;
import com.documentum.fc.common.DfException;
import org.w3c.dom.Document;
import org.w3c.dom.Node;

public class MonQueryBuilder extends DfQueryBuilder {

  public MonQueryBuilder(IDfSearchMetadataManager manager) throws DfException {
    super(manager);
    setRootExpressionSet(new MonExpressionSet(getDateFormat()));
  }

  public MonQueryBuilder(IDfSearchMetadataManager manager, String objectType) throws DfException {
    super(manager, objectType);
    setRootExpressionSet(new MonExpressionSet(getDateFormat()));
  }

  public MonQueryBuilder(IDfSearchMetadataManager metadataManager, Document doc) throws DfException {
    this(metadataManager);
    Node node = DfXMLUtil.getNode(doc, "QueryBuilder", true);
    String maxResultsString = DfXMLUtil.getAttribute(node, "maxResults", true);
    try {
      int maxResults = Integer.parseInt(maxResultsString);
      setMaxResultCount(maxResults);
    }
    catch (NumberFormatException nfe) {
      DfXMLUtil.throwXMLFormatError("<QueryBuilder maxResults=... >");
    }
    String isDbSearchRequestedString = DfXMLUtil.getAttribute(node, "isDatabaseSearchRequested", true);
    setDatabaseSearchRequested(Boolean.valueOf(isDbSearchRequestedString).booleanValue());
    String objectType = DfXMLUtil.getAttribute(node, "objectType", false);
    if (objectType != null)
      setObjectType(objectType);
    String allVersions = DfXMLUtil.getAttribute(node, "allVersions", true);
    setIncludeAllVersions(Boolean.valueOf(allVersions).booleanValue());
    String hiddenObjects = DfXMLUtil.getAttribute(node, "hiddenObjects", true);
    setIncludeHiddenObjects(Boolean.valueOf(hiddenObjects).booleanValue());
    readXMLSourceList(doc);
    readXMLScopeList(doc);
    readXMLExpressionSet(doc);
    readXMLResultList(doc);
  }

  private void readXMLExpressionSet(Document doc)
      throws DfException {
    Node node = DfXMLUtil.getNode(doc, "ExpressionSet", true);
    setRootExpressionSet(new MonExpressionSet(node));
  }

  private void readXMLScopeList(Document doc)
      throws DfException {
    Node node = DfXMLUtil.getNode(doc, "QueryScopeList", true);
    Node[] childNodes = DfXMLUtil.getChildNodes(node, "LocationQueryScope", false);
    for (int i = 0; i < childNodes.length; i++) {

      String m_source = DfXMLUtil.getAttribute(childNodes[i], "source", true);
      String m_locationPath = DfXMLUtil.getValue(childNodes[i], true);
      m_locationPath = getEncrypter().decrypt(m_locationPath);
      String xmlIsDescend = DfXMLUtil.getAttribute(childNodes[i], "isDescend", true);
      boolean m_isDescend = Boolean.valueOf(xmlIsDescend).booleanValue();

      addLocationScope(m_source, m_locationPath, m_isDescend);
    }
  }

  private static DfEncrypter getEncrypter() {
    return new DfEncrypter(SECRET_KEY);
  }

  private void readXMLResultList(Document doc)
      throws DfException {
    Node node = DfXMLUtil.getNode(doc, "ResultAttributeList", true);
    Node[] childNodes = DfXMLUtil.getChildNodes(node, "ResultAttribute", false);
    for (int i = 0; i < childNodes.length; i++) {
      String result = DfXMLUtil.getAttribute(childNodes[i], "name", true);
      addResultAttribute(result);
    }

  }

  private static final String SECRET_KEY = "VA+re7wWcVoKZ0kWL1AqDb7wJ6C12z37URXF+7f7";
}
