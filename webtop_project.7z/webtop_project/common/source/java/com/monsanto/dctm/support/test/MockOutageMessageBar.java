/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.support.test;

import com.documentum.fc.client.DfServiceException;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.IDfSessionManager;
import com.documentum.fc.common.DfException;
import com.documentum.web.common.ArgumentList;
import com.monsanto.dctm.component.test.IMonTestableComponent;
import com.monsanto.dctm.support.OutageMessageBar;

/**
 * Filename:    $RCSfile: MockOutageMessageBar.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: lakench $    	 On:	$Date: 2007-08-23 15:03:38 $
 *
 * @author lakench
 * @version $Revision: 1.1 $
 */
public class MockOutageMessageBar extends OutageMessageBar implements IMonTestableComponent {
  private IDfSessionManager sessionManager;
  public boolean wasHideOutageMessageBarClientEventCalled = false;
  public boolean wasShowOutageMessageBarClientEventCalled = false;

  /**
   * @noinspection RefusedBequest
   */
  public IDfSession getDfSession(int i) {
    try {
      return sessionManager.getSession(getCurrentDocbase());
    } catch (DfServiceException e) {
      e.printStackTrace();
    }
    return null;
  }

  /**
   * @noinspection RefusedBequest
   */
  public void setClientEvent(String eventName, ArgumentList argumentList) {
    if (eventName.equals("hideOutageMessageBar")) wasHideOutageMessageBarClientEventCalled = true;
    if (eventName.equals("showOutageMessageBar")) wasShowOutageMessageBarClientEventCalled = true;
  }

  /**
   * @noinspection RefusedBequest
   */
  public String getCurrentDocbase() {
    return null;
  }

  public void setSessionManager(IDfSessionManager sessionManager) {
    this.sessionManager = sessionManager;
  }

  public IDfSessionManager getSessionManager() {
    return sessionManager;
  }

  protected void initSupportMessages() throws DfException {
    super.initSupportMessages();
  }
}