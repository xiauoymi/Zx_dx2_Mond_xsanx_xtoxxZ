/*
 * Created on Sep 3, 2005
 *
 */
package com.monsanto.dctm.monAppContext;

import com.documentum.web.formext.config.IQualifier;
import com.documentum.web.formext.config.QualifierContext;

/**
 * @author LAKENCH
 */
public class MonAppContextQualifier implements IQualifier {

    public String[] getContextNames() {
        return (new String[]{"mon_app_context"});
    }

    public String getScopeName() {
        return "mon_app_context";
    }

    public String getScopeValue(QualifierContext context) {
        return context.get("mon_app_context");
    }

    public String getParentScopeValue(String arg0) {
        return null;
    }

    public String[] getAliasScopeValues(String arg0) {
        return null;
    }
}
