/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.monAppContext.preferences.test;

import com.monsanto.dctm.monAppContext.preferences.Preference;
import com.monsanto.dctm.monAppContext.preferences.PreferenceTag;
import junit.framework.TestCase;

/**
 * Filename:    $RCSfile: PreferenceTag_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: lakench $
 * On:	$Date: 2007-07-31 18:51:49 $
 *
 * @author lakench
 * @version $Revision: 1.1 $
 */
public class PreferenceTag_UT extends TestCase {
  public void testGetCorrectControlClass() throws Exception {
    MockPreferenceTag preferenceTag = new MockPreferenceTag();
    Class controlClass = preferenceTag.getControlClass();
    assertEquals("control class should be an instance of Preference", controlClass.getName(),
        Preference.class.getName());
  }

  public class MockPreferenceTag extends PreferenceTag {
    protected Class getControlClass() {
      return super.getControlClass();
    }
  }
}