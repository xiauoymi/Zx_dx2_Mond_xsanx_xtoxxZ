package com.monsanto.dctm.inbox;

import com.monsanto.dctm.monAppContext.MonAppContextService;

public class InboxClassic extends
                          com.documentum.webtop.webcomponent.inbox.InboxClassic {

    protected String getColumnsPreferenceId() {
        return super.getColumnsPreferenceId() + "." +
               MonAppContextService.getMonAppContextService().getMonAppContextInternalName();
    }

}
