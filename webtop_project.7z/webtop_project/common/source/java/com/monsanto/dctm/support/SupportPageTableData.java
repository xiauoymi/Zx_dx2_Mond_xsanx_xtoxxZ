/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.support;

import com.documentum.fc.common.DfException;
import com.documentum.web.form.control.databound.ColumnDescriptor;
import com.documentum.web.form.control.databound.TableResultSet;
import com.documentum.web.formext.component.Component;

import java.util.Iterator;
import java.util.List;

/**
 * Filename:    $RCSfile: SupportPageTableData.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: lakench $
 * On:	$Date: 2007-08-02 18:23:24 $
 *
 * @author lakench
 * @version $Revision: 1.2 $
 */
public abstract class SupportPageTableData {

  private SupportConfig supportConfig;

  public SupportPageTableData(Component component) {
    supportConfig = new SupportConfig(component);
  }

  public SupportConfig getSupportConfig() {
    return supportConfig;
  }

  public TableResultSet getResultSet() throws DfException {
    return new TableResultSet(getData(), (String[]) getColumnAttrArray());
  }

  private String[] getColumnAttrArray() {
    Iterator colDescriptors = getColumnList().iterator();
    String[] columnAttr = new String[4];
    int index = 0;
    while (colDescriptors.hasNext()) {
      ColumnDescriptor colDescriptor = (ColumnDescriptor) colDescriptors.next();
      columnAttr[index] = colDescriptor.getAttribute();
      index++;
    }
    return columnAttr;
  }

  public abstract List getData() throws DfException;

  public abstract List getColumnList();
}