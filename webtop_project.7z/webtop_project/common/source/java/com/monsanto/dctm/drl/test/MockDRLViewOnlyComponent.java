/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.drl.test;

import com.documentum.fc.client.DfServiceException;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.IDfSessionManager;
import com.documentum.web.common.ArgumentList;
import com.documentum.web.form.Form;
import com.documentum.web.formext.action.IActionCompleteListener;
import com.documentum.web.formext.component.Component;
import com.documentum.web.formext.config.Context;
import com.monsanto.dctm.component.test.IMonTestableComponent;
import com.monsanto.dctm.drl.DRLViewOnlyComponent;

import java.util.Map;

/**
 * Filename:    $RCSfile: MockDRLViewOnlyComponent.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: lakench $
 * On:	$Date: 2007-10-12 05:21:59 $
 *
 * @author LAKENCH
 * @version $Revision: 1.2 $
 */
public class MockDRLViewOnlyComponent extends DRLViewOnlyComponent implements IMonTestableComponent {
  private IDfSessionManager sessionManager;
  public String logoffUrl;
  public String actionCalledId;
  public ArgumentList actionCalledArgs;
  public Context actionCalledContext;
  public Component actionCalledCallingComponent;
  public IActionCompleteListener actionCalledCompleteListener;

  /**
   * @noinspection RefusedBequest
   */
  public IDfSession getDfSession(int i) {
    try {
      return sessionManager.getSession(getCurrentDocbase());
    } catch (DfServiceException e) {
      e.printStackTrace();
    }
    return null;
  }

  public String getCurrentDocbase() {
    return super.getCurrentDocbase();
  }

  public void setSessionManager(IDfSessionManager sessionManager) {
    this.sessionManager = sessionManager;
  }

  public IDfSessionManager getSessionManager() {
    return sessionManager;
  }

  public void viewObjectAndLogout(String objectId, String versionLabel, String contentType) {
    super.viewObjectAndLogout(objectId, versionLabel, contentType);
  }

  protected void doLogout(String logoffUrl) {
    this.logoffUrl = logoffUrl;
  }

  public Form getTopForm() {
    return super.getTopForm();
  }

  protected void executeAction(String actionId, ArgumentList actionArgs, Context actionContext,
                               Component callingComponent, IActionCompleteListener actionCompleteListener) {
    actionCalledId = actionId;
    actionCalledArgs = actionArgs;
    actionCalledContext = actionContext;
    actionCalledCallingComponent = callingComponent;
    actionCalledCompleteListener = actionCompleteListener;
    super.executeAction(actionId, actionArgs, actionContext, callingComponent, actionCompleteListener);
  }

  public void onComplete(String strAction, boolean bSuccess, Map map) {
    super.onComplete(strAction, bSuccess, map);
  }

}