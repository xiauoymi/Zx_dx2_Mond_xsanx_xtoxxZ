package com.monsanto.dctm.report;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.documentum.web.common.ArgumentList;
import com.documentum.web.form.Control;
import com.documentum.web.form.control.Label;
import com.documentum.web.form.control.databound.ConfigResultSet;
import com.documentum.web.form.control.databound.DataProvider;
import com.documentum.web.form.control.databound.Datagrid;
import com.documentum.web.form.control.databound.ScrollableResultSet;
import com.documentum.web.form.control.databound.TableResultSet;
import com.documentum.web.formext.component.Component;
import com.documentum.web.formext.config.ConfigService;
import com.documentum.web.formext.config.IConfigElement;

public class SelectReport extends Component {

	private Datagrid reportListGrid;

	public void onInit(ArgumentList args) {
		initReportList();
	}

	public boolean canCancelChanges() {
		return false;
	}

	public boolean canCommitChanges() {
		return false;
	}

	public void onClickReportLink(Control control, ArgumentList args)
	{
		setComponentJump("reportcontainer", args, getContext());
	}
		
	protected void initReportList() {
		reportListGrid = getReportListDatagrid();
		DataProvider reportListDataProvider = getReportListDataProvider();
		reportListGrid.setDataProvider(reportListDataProvider);
		ScrollableResultSet reportListScrollableResultSet = getReportListScrollableResultSet();
		reportListDataProvider.setScrollableResultSet(reportListScrollableResultSet);		
	}

	private ScrollableResultSet getReportListScrollableResultSet() {
		return new TableResultSet(getReportsList(), getReportsColumnDef());
	}

	private List getReportsList() {
		ArrayList reportsList = new ArrayList();
		
		IConfigElement reportsConfig = lookupElement("reports");
		if (reportsConfig != null)
		{
			Iterator reports = reportsConfig.getChildElements();
			while (reports.hasNext())
			{
				String[] reportListRow = new String[3];
				String reportComponent = ((IConfigElement)reports.next()).getValue();
				reportListRow[0] = getReportName(reportComponent);
				reportListRow[1] = getReportDescription(reportComponent);
				reportListRow[2] = reportComponent;
				
				reportsList.add(reportListRow);
			}
		}
		
		return reportsList;
	}

	private String getReportDescription(String reportComponent) {
		return ConfigService.getConfigLookup().lookupElement("component[id=" + reportComponent + "].reportdescription", getContext()).getValue();
	}

	private String getReportName(String reportComponent) {
		return ConfigService.getConfigLookup().lookupElement("component[id=" + reportComponent + "].reportname", getContext()).getValue();
	}

	private String[] getReportsColumnDef() {
		String[] columns = {"ReportName", "ReportDescription", "ReportComponent"};
		return columns;
	}

	private DataProvider getReportListDataProvider() {
		return new DataProvider(reportListGrid);
	}

	private Datagrid getReportListDatagrid() {
		return (Datagrid) getControl("reportListDatagrid", Datagrid.class);
	}

}
