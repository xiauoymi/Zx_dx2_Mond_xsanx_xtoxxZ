/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.support.test;

import com.documentum.fc.client.DfServiceException;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.IDfSessionManager;
import com.documentum.fc.common.DfException;
import com.documentum.web.form.IControlListener;
import com.monsanto.dctm.component.test.IMonTestableComponent;
import com.monsanto.dctm.support.Support;

import java.util.HashSet;
import java.util.Set;

/**
 * Filename:    $RCSfile: MockSupportComponent.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: lakench $
 * On:	$Date: 2007-07-31 18:51:49 $
 *
 * @author lakench
 * @version $Revision: 1.3 $
 */
public class MockSupportComponent extends Support implements IMonTestableComponent {
  private Set controlListeners;
  private IDfSessionManager sessionManager;


  public void addControlListener(IControlListener iControlListener) {
    super.addControlListener(iControlListener);
    if (controlListeners == null)
      controlListeners = new HashSet(1);
    controlListeners.add(iControlListener);
  }

  public boolean isControlListener(IControlListener controlListener) {
    return controlListeners.contains(controlListener);
  }

  /**
   * @noinspection RefusedBequest
   */
  public IDfSession getDfSession(int i) {
    try {
      return sessionManager.getSession(getCurrentDocbase());
    } catch (DfServiceException e) {
      e.printStackTrace();
    }
    return null;
  }

  /**
   * @noinspection RefusedBequest
   */
  public String getCurrentDocbase() {
    return null;
  }

  public void setSessionManager(IDfSessionManager sessionManager) {
    this.sessionManager = sessionManager;
  }

  public IDfSessionManager getSessionManager() {
    return sessionManager;
  }

  protected void initSupportConfig() {
    super.initSupportConfig();
  }

  protected void setOutageNoticeLabel() throws DfException {
    super.setOutageNoticeLabel();
  }

  protected void setTeamMailtolink() {
    super.setTeamMailtolink();
  }

  protected void initDataGrids() throws DfException {
    super.initDataGrids();
  }

}