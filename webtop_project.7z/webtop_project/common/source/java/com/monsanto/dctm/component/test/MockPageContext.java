/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.component.test;

import javax.servlet.*;
import javax.servlet.http.HttpSession;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.PageContext;
import javax.servlet.jsp.el.ExpressionEvaluator;
import javax.servlet.jsp.el.VariableResolver;
import java.io.IOException;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;

/**
 * Filename:    $RCSfile: MockPageContext.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: lakench $    	 On:	$Date: 2007-01-04 22:41:10 $
 *
 * @author lakench
 * @version $Revision: 1.1 $
 */
public class MockPageContext extends PageContext {
    private Map attributeMap = new HashMap();
    private ServletRequest servletRequest;

    public void initialize(Servlet servlet, ServletRequest servletRequest, ServletResponse servletResponse, String string, boolean b, int i, boolean b1) throws
                                                                                                                                                         IOException,
                                                                                                                                                         IllegalStateException,
                                                                                                                                                         IllegalArgumentException {
    }

    public void release() {
    }

    public HttpSession getSession() {
        return null;
    }

    public Object getPage() {
        return null;
    }

    public void setRequest(ServletRequest servletRequest) {
        this.servletRequest = servletRequest;
    }

    public ServletRequest getRequest() {
        return servletRequest;
    }

    public ServletResponse getResponse() {
        return null;
    }

    public Exception getException() {
        return null;
    }

    public ServletConfig getServletConfig() {
        return null;
    }

    public ServletContext getServletContext() {
        return null;
    }

    public void forward(String string) throws ServletException, IOException {
    }

    public void include(String string) throws ServletException, IOException {
    }

    public void include(String string, boolean b) throws ServletException, IOException {
    }

    public void handlePageException(Exception exception) throws ServletException, IOException {
    }

    public void handlePageException(Throwable throwable) throws ServletException, IOException {
    }

    public void setAttribute(String string, Object object) {
        attributeMap.put(string, object);
    }

    public void setAttribute(String string, Object object, int i) {
        setAttribute(string, object);
    }

    public Object getAttribute(String string) {
        return attributeMap.get(string);
    }

    public Object getAttribute(String string, int i) {
        return getAttribute(string);
    }

    public Object findAttribute(String string) {
        return null;
    }

    public void removeAttribute(String string) {
    }

    public void removeAttribute(String string, int i) {
    }

    public int getAttributesScope(String string) {
        return 0;
    }

    public Enumeration getAttributeNamesInScope(int i) {
        return null;
    }

    public JspWriter getOut() {
        return null;
    }

    public ExpressionEvaluator getExpressionEvaluator() {
        return null;
    }

    public VariableResolver getVariableResolver() {
        return null;
    }
}