/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.drl.test;

import com.documentum.fc.client.MockSession;
import com.documentum.web.form.ComponentTestUtils;
import com.documentum.web.formext.action.IActionCompleteListener;
import com.documentum.web.formext.component.Component;
import com.monsanto.dctm.component.test.MockSessionManager;
import com.monsanto.dctm.component.test.MockSysObject;
import com.monsanto.dctm.drl.DRLViewOnlyComponent;
import junit.framework.TestCase;

/**
 * Filename:    $RCSfile: DRLViewOnlyComponent_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: lakench $
 * On:	$Date: 2007-10-26 18:47:58 $
 *
 * @author LAKENCH
 * @version $Revision: 1.3 $
 */
public class DRLViewOnlyComponent_UT extends TestCase {
  public void testCreate() throws Exception {
    DRLViewOnlyComponent component = new DRLViewOnlyComponent();
    assertNotNull(component);
    assertTrue(component instanceof Component);
    assertTrue(component instanceof IActionCompleteListener);
  }

  public void testViewObjectAndLogout() throws Exception {
    MockSessionManager mockSessionManager = new MockSessionManager();
    MockSession session = new MockSession(mockSessionManager);
    ((MockSessionManager) mockSessionManager).setSession(session);
    MockSysObject currentObject = new MockSysObject();
    currentObject.setString("r_object_id", "testobjectid");
    currentObject.setString("i_chronicle_id", "chronicle_id");
    session.addObject(currentObject,
        "dm_sysobject (all) where i_chronicle_id = 'chronicle_id' and any r_version_label = 'CURRENT'");
    session.addObject(currentObject, "testobjectid");
    MockDRLViewOnlyComponent component = (MockDRLViewOnlyComponent) ComponentTestUtils
        .getComponent(MockDRLViewOnlyComponent.class, "drlviewonly", "testdocbase", mockSessionManager);

    component.viewObjectAndLogout("testobjectid", "CURRENT", "testformat");

    assertEquals("drlview", component.actionCalledId);
    assertEquals("testobjectid", component.actionCalledArgs.get("objectId"));
    assertEquals("testformat", component.actionCalledArgs.get("contentType"));
    assertEquals(Boolean.FALSE.toString(), component.actionCalledArgs.get("navigateOnComplete"));
    assertEquals("REQUEST(objectId=testobjectid)SESSION()APP()", component.actionCalledContext.toString());
    assertEquals(component, component.actionCalledCallingComponent);
    assertEquals(component, component.actionCalledCompleteListener);

    ComponentTestUtils.releaseComponent(component);
  }

  public void testViewWhenNoMatchingChronicleIdAndVersionLabel() throws Exception {
    MockSessionManager mockSessionManager = new MockSessionManager();
    MockSession session = new MockSession(mockSessionManager);
    ((MockSessionManager) mockSessionManager).setSession(session);
    MockSysObject currentObject = new MockSysObject();
    currentObject.setString("r_object_id", "testobjectid");
    currentObject.setString("i_chronicle_id", "chronicle_id");
    session.addObject(currentObject, "testobjectid");
    MockDRLViewOnlyComponent component = (MockDRLViewOnlyComponent) ComponentTestUtils
        .getComponent(MockDRLViewOnlyComponent.class, "drlviewonly", "testdocbase", mockSessionManager);

    component.viewObjectAndLogout("testobjectid", "CURRENT", "testformat");

    assertEquals("drlview", component.actionCalledId);
    assertEquals("testobjectid", component.actionCalledArgs.get("objectId"));
    assertEquals("testformat", component.actionCalledArgs.get("contentType"));
    assertEquals(Boolean.FALSE.toString(), component.actionCalledArgs.get("navigateOnComplete"));
    assertEquals("REQUEST(objectId=testobjectid)SESSION()APP()", component.actionCalledContext.toString());
    assertEquals(component, component.actionCalledCallingComponent);
    assertEquals(component, component.actionCalledCompleteListener);

    ComponentTestUtils.releaseComponent(component);
  }

  public void testViewCurrentObjectWhenPassingNonCurrentObjectId() throws Exception {
    MockSessionManager mockSessionManager = new MockSessionManager();
    MockSession session = new MockSession(mockSessionManager);
    ((MockSessionManager) mockSessionManager).setSession(session);
    MockSysObject nonCurrentObject = new MockSysObject();
    nonCurrentObject.setString("r_object_id", "testnoncurrentobjectid");
    nonCurrentObject.setString("i_chronicle_id", "chronicle_id");
    session.addObject(nonCurrentObject, "testnoncurrentobjectid");
    MockSysObject currentObject = new MockSysObject();
    currentObject.setString("r_object_id", "testobjectid");
    currentObject.setString("i_chronicle_id", "chronicle_id");
    session.addObject(currentObject,
        "dm_sysobject (all) where i_chronicle_id = 'chronicle_id' and any r_version_label = 'CURRENT'");
    MockDRLViewOnlyComponent component = (MockDRLViewOnlyComponent) ComponentTestUtils
        .getComponent(MockDRLViewOnlyComponent.class, "drlviewonly", "testdocbase", mockSessionManager);

    component.viewObjectAndLogout("testnoncurrentobjectid", "CURRENT", "testformat");

    assertEquals("drlview", component.actionCalledId);
    assertEquals("testobjectid", component.actionCalledArgs.get("objectId"));
    assertEquals("testformat", component.actionCalledArgs.get("contentType"));
    assertEquals(Boolean.FALSE.toString(), component.actionCalledArgs.get("navigateOnComplete"));
    assertEquals("REQUEST(objectId=testobjectid)SESSION()APP()", component.actionCalledContext.toString());
    assertEquals(component, component.actionCalledCallingComponent);
    assertEquals(component, component.actionCalledCompleteListener);

    ComponentTestUtils.releaseComponent(component);
  }

  public void testOnComplete() throws Exception {
    MockSessionManager mockSessionManager = new MockSessionManager();
    MockSession session = new MockSession(mockSessionManager);
    ((MockSessionManager) mockSessionManager).setSession(session);
    MockDRLViewOnlyComponent component = (MockDRLViewOnlyComponent) ComponentTestUtils
        .getComponent(MockDRLViewOnlyComponent.class, "drlviewonly", "testdocbase", mockSessionManager);

    component.onComplete(null, false, null);

    assertEquals("/component/logoff?afterLogoff=closeWindow", component.logoffUrl);

    ComponentTestUtils.releaseComponent(component);
  }
}