/*
 Copyright:  Copyright � 2006 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.support;

import com.documentum.fc.common.DfException;
import com.documentum.web.common.ArgumentList;
import com.documentum.web.common.WrapperRuntimeException;
import com.documentum.web.form.control.Label;
import com.documentum.web.form.control.databound.Datagrid;
import com.documentum.web.formext.component.Component;
import com.monsanto.dctm.component.ListBasedColumnDescriptorList;

import java.util.List;

/**
 * Filename:    $RCSfile: Support.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: lakench $    	 On:	$Date:
 * 2007/05/12 05:29:56 $
 *
 * @author lakench
 * @version $Revision: 1.26 $
 */
public class Support extends Component {
  public static final String SUPPORT_PAGE_LABEL = "supportcontentlabel";
  public static final String SUPPORT_PAGE_OUTAGE_LABEL = "outagenotice";
  public static final String TEAM_MEMBER_TABLE = "teammembers";
  public static final String TEAM_EMAIL_LINK = "teammailto";
  public static final String APP_OWNER_TABLE = "appowners";
  public static final String TEAM_CELLLIST = "teamcelllist";
  public static final String APP_OWNER_CELLLIST = "appownercelllist";

  private SupportConfig supportConfig;
  private static final int TIMEOUT = 15;

  public void onInit(ArgumentList args) {
    super.onInit(args);
    try {
      initSupportConfig();
      setOutageNoticeLabel();
      initDataGrids();
      setTeamMailtolink();
      getPageContext().getSession().setMaxInactiveInterval(TIMEOUT);
    } catch (DfException e) {
      throw new WrapperRuntimeException(e);
    }
  }

  protected void initSupportConfig() {
    supportConfig = new SupportConfig(this);
  }

  protected void setOutageNoticeLabel() throws DfException {
    Label outageNoticeLabel = (Label) getControl(SUPPORT_PAGE_OUTAGE_LABEL, Label.class);
    outageNoticeLabel.setLabel(supportConfig.getOutageNotice());
  }

  protected void setTeamMailtolink() {
    Mailtolink link = (Mailtolink) getControl(TEAM_EMAIL_LINK, Mailtolink.class);
    link.setEmailAddress("eedocu@monsanto.com");
  }

  protected void initDataGrids() throws DfException {
    Datagrid teamMemberDataGrid = getDataGrid(TEAM_MEMBER_TABLE);
    TeamMembers teamMembers = new TeamMembers(this);
    initDataGrid(teamMemberDataGrid, teamMembers, getSupportPageComponentColumnDescriptorList(
        teamMemberDataGrid.getName(), teamMembers.getColumnList()));
    Datagrid appOwnersDataGrid = getDataGrid(APP_OWNER_TABLE);
    AppOwners appOwners = new AppOwners(this);
    initDataGrid(appOwnersDataGrid, appOwners, getSupportPageComponentColumnDescriptorList(
        appOwnersDataGrid.getName(), appOwners.getColumnList()));
  }

  private Datagrid getDataGrid(String controlName) {
    return (Datagrid) getControl(controlName, Datagrid.class);
  }

  protected void initDataGrid(Datagrid datagrid, SupportPageTableData data,
                              ListBasedColumnDescriptorList columnDescriptorList) throws
      DfException {
    addControlListener(columnDescriptorList);
    datagrid.getDataProvider().setScrollableResultSet(data.getResultSet());
  }

  protected ListBasedColumnDescriptorList getSupportPageComponentColumnDescriptorList(String datagridName,
                                                                                      List columnList) {
    return new ListBasedColumnDescriptorList(datagridName, columnList);
  }
}