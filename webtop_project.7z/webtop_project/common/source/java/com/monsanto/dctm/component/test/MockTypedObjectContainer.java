/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.component.test;

import com.documentum.fc.client.IDfTypedObject;
import com.documentum.web.form.Control;
import com.documentum.webcomponent.admin.container.ITypedObjectContainer;

/**
 * Filename:    $RCSfile: MockTypedObjectContainer.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: lakench $    	 On:	$Date: 2007-08-21 05:23:14 $
 *
 * @author lakench
 * @version $Revision: 1.1 $
 */
public class MockTypedObjectContainer extends Control implements ITypedObjectContainer {
  private MockTypedObject mockTypedObject;

  public MockTypedObjectContainer(MockTypedObject mockTypedObject) {
    this.mockTypedObject = mockTypedObject;
  }

  public IDfTypedObject getDfTypedObject() {
    return mockTypedObject;
  }
}