/**
 ******************************************************************************
 *
 * Confidential Property of Documentum, Inc.
 * (c) Copyright Documentum, Inc. 2001.
 * All Rights reserved.
 * May not be used without prior written agreement
 * signed by a Documentum corporate officer.
 *
 ******************************************************************************
 *
 * Project
 * File           ViewPDFRendition.java
 * Description    Action execution class that only allows pdf renditions to be viewed.
 *                No other rendition types are allowed.
 *
 * Created by     Aashish Patil (aashish.patil@documentum.com)
 * Created on     31 January, 2003
 * Tab width      4
 */

package com.monsanto.dctm.action;

import com.documentum.fc.client.DfServiceException;
import com.documentum.fc.client.IDfCollection;
import com.documentum.fc.client.IDfPersistentObject;
import com.documentum.fc.client.IDfSysObject;
import com.documentum.fc.common.DfException;
import com.documentum.web.common.ArgumentList;
import com.documentum.web.common.WrapperRuntimeException;
import com.documentum.web.formext.component.Component;
import com.documentum.web.formext.config.Context;
import com.documentum.web.formext.config.IConfigElement;
import com.monsanto.dctm.dctmSession.DctmSession;
import com.monsanto.dctm.dctmSession.Session;
import com.monsanto.dctm.dctmSession.SessionInstance;

import java.util.Map;

public class ViewPDFRendition extends com.documentum.webtop.webcomponent.actions.ViewAction {
    /**
     * The renditions requested for viewing are contained as the argument
     * 'contentType' in the ArgumentList object. The value of this argument is
     * replaced with the value for the content type of Acrobat PDF.
     */
    public boolean execute(String strAction, IConfigElement config, ArgumentList args, Context context, Component component, Map completionArgs) {
        replaceContentTypeArgIfPDFExists(args);

        return super.execute(strAction, config, args, context, component, completionArgs);

    }

    protected void replaceContentTypeArgIfPDFExists(ArgumentList args) {
        if (args != null) {
            String objectId = args.get("objectId");
            try {
                if (hasPDFRendition(objectId)) {
                    args.replace(m_strContentTypeArg, m_strArrayContentTypePDF);
                }
            } catch (DfServiceException e) {
                throw new WrapperRuntimeException(e);
            }
        }
    }

    /**
     * Checks whether a document has a pdf rendition
     *
     * @param objectId The object id of the sysobject whose renditions have to be checked
     *                 for existence of a pdf rendition.
     * @return boolean     true=>pdf rendition exists
     *         false=>pdf rendition does not exist
     */
    protected boolean hasPDFRendition(String objectId) throws DfServiceException {
        IDfCollection contentTypes = null;
        Session session = createSession();
        SessionInstance docbaseSession = session.getNewSession();

        try {
            IDfSysObject sysObject = (IDfSysObject) docbaseSession.getObject(objectId);
            contentTypes = sysObject.getRenditions("r_object_id");

            while (contentTypes.next()) {
                String attrValue = contentTypes.getString("r_object_id");
                IDfPersistentObject persObj = (IDfPersistentObject) docbaseSession.getObject(attrValue);

                String format = persObj.getString("full_format");
                if (format.equals(m_strArrayContentTypePDF)) {
                    return true;
                }
            }
            return false;

        } catch (DfException dfe) {
            System.out.println("Error while searching for rendition: " + dfe.getMessage());
            dfe.printStackTrace();
            return false;
        }
        finally {
            if (docbaseSession != null) {
                docbaseSession.release();
            }

            if (contentTypes != null) {
                try {
                    contentTypes.close();
                } catch (DfException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    protected Session createSession() {
        return new DctmSession();
    }


    /**
     * String specifying the pdf content type
     */
    private String m_strArrayContentTypePDF = "pdf";

    /**
     * String specifying the key referencing the content type value in the
     * ArgumentList passed
     */
    private String m_strContentTypeArg = "contentType";
}
