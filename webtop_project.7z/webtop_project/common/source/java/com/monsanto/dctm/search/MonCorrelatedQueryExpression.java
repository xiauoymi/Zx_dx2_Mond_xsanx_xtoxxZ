package com.monsanto.dctm.search;

import com.documentum.fc.client.search.DfSearchException;
import com.documentum.fc.client.search.impl.DfValueListAttrExpression;
import com.documentum.fc.client.search.impl.DfXMLUtil;
import com.documentum.fc.client.search.impl.DfDocExprStatus;
import com.documentum.fc.client.search.impl.FullTextSettings;
import com.documentum.fc.common.IDfValue;
import org.w3c.dom.Document;
import org.w3c.dom.Node;

public class MonCorrelatedQueryExpression extends DfValueListAttrExpression
    implements com.monsanto.dctm.search.IMonCorrelatedQueryExpression {

  private static final int[] VALID_SEARCH_OPERATIONS = {IMonCorrelatedQueryExpression.SEARCH_OP_IN,
      IMonCorrelatedQueryExpression.SEARCH_OP_NOT_IN};
  private static final int[] VALID_VALUE_DATA_TYPES = {IDfValue.DF_STRING, SUBQUERY_VALUE_TYPE};
  private String subQuery;

  public MonCorrelatedQueryExpression(DfValueListAttrExpression valueListAttrExpression, String subQuery) {
    super(valueListAttrExpression.getDateFormat(), valueListAttrExpression.getAttrName(), SUBQUERY_VALUE_TYPE,
        valueListAttrExpression.getSearchOperationCode(), valueListAttrExpression.isCaseSensitive(),
        valueListAttrExpression.isRepeated());
    valueListAttrExpression.setValueDataType(IDfValue.DF_STRING);
    this.subQuery = subQuery;
  }

  public MonCorrelatedQueryExpression(Node node) throws DfSearchException {
    super(node);
    setValueDataType(SUBQUERY_VALUE_TYPE);
    setSubQuery(DfXMLUtil.getValue(node, false));
  }

  /**
   * @noinspection RefusedBequest
   */
  public int getExpressionType() {
    return EXPR_TYPE_CORRELATED_QUERY;
  }

  /**
   * @noinspection RefusedBequest
   */
  public DfDocExprStatus getDocbaseExpression(boolean root, FullTextSettings fullTextSettings) throws
      DfSearchException {
    validateExpression();
    StringBuffer attrExprBuffer = new StringBuffer();
    boolean ftDQLEnabled = fullTextSettings.isFTDQLEnabled();
    appendAttrName(attrExprBuffer, ftDQLEnabled);
    appendSearchOperator(attrExprBuffer, ftDQLEnabled);
    appendSubQuery(attrExprBuffer);
    return new DfDocExprStatus(attrExprBuffer.toString(), null);
  }

  protected void appendSearchOperator(StringBuffer attrExprBuffer, boolean ftDQLEnabled) throws DfSearchException {
    attrExprBuffer.append(' ').append(generateDqlPredicate(ftDQLEnabled)).append(' ');
  }

  private void appendSubQuery(StringBuffer attrExprBuffer) {
    attrExprBuffer.append('(').append(getSubQuery()).append(')');
  }

  private void validateExpression() throws DfSearchException {
    validateOperation(VALID_SEARCH_OPERATIONS);
    validateValueDataType(VALID_VALUE_DATA_TYPES);
  }

  private String generateDqlPredicate(boolean ftDQLEnabled) throws DfSearchException {
    String predicate = null;
    switch (getSearchOperationCode()) {
      case com.monsanto.dctm.search.IMonCorrelatedQueryExpression.SEARCH_OP_IN:
        if (ftDQLEnabled)
          throwInvalidSearchOpFTDQL();
        predicate = "IN";
        break;

      case IMonCorrelatedQueryExpression.SEARCH_OP_NOT_IN:
        if (ftDQLEnabled)
          throwInvalidSearchOpFTDQL();
        predicate = "NOT IN";
        break;
    }

    return predicate;
  }

  public String getSubQuery() {
    return subQuery;
  }

  public void setSubQuery(String subQuery) {
    this.subQuery = subQuery;
  }

  public Node generateXML(Document doc, Node parent) {
    Node expr = super.generateXML(doc, parent);
    if (subQuery != null) {
      Node valueNode = doc.createTextNode(subQuery);
      expr.appendChild(valueNode);
    }
    return expr;
  }

  /**
   * @noinspection RefusedBequest
   */
  protected String getXmlNodeName() {
    return "CorrelatedQueryExpression";
  }
}
