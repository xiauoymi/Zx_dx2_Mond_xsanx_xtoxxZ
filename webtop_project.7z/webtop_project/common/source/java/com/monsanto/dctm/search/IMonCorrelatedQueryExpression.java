package com.monsanto.dctm.search;

import com.documentum.fc.client.search.IDfExpression;
import com.documentum.fc.client.search.IDfSearchOperation;

public interface IMonCorrelatedQueryExpression extends IDfExpression {
  public static final int EXPR_TYPE_CORRELATED_QUERY = 6;
  public static final int SUBQUERY_VALUE_TYPE = 7;
  public static final int SEARCH_OP_IN = IDfSearchOperation.SEARCH_OP_IN;
  public static final int SEARCH_OP_NOT_IN = IDfSearchOperation.SEARCH_OP_NOT_IN;

  public abstract String getSubQuery();

  public abstract void setSubQuery(String subQuery);
}
