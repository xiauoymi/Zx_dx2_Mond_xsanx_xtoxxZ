/*
 * Created on May 13, 2005
 */
package com.monsanto.dctm.validation;

import com.documentum.web.common.ArgumentList;
import com.documentum.web.contentxfer.control.ImportApplet;
import com.documentum.web.contentxfer.control.LinkDetectorApplet;
import com.documentum.web.form.Control;
import com.documentum.web.form.IControlListener;
import com.documentum.web.formext.component.Component;
import com.documentum.web.formext.control.docbase.DocbaseObject;
import com.documentum.webcomponent.common.WebComponentErrorService;

import java.util.Collection;

public class ImportContainer extends
                             com.documentum.webcomponent.library.contenttransfer.importcontent.UcfImportContainer implements
                                                                                                                  IControlListener {
    protected String strObjectType = "no_custom_validation";
    protected Component m_component;
    protected DocbaseObject m_docbaseObj;
    protected boolean doCustomValidation = false;
    protected CustomValidation customValidationObject = null;
    protected boolean bObjectTypeChanged = true;
    protected boolean isValid;

    protected LinkDetectorApplet m_customValidationAppletLinkDetector;
    protected ImportApplet m_customValidationAppletImport;

    public void validate() {
        if (doCustomValidation) {
            validate(false);
        } else {
            super.validate();
        }
    }

    protected void validate(boolean bIgnoreDoValidateFlag) {
        if (doCustomValidation) {
            //Do custom validation
            isValid = customValidationObject.isValid();
            if (!isValid)  // Did the custom validation fail?
            {
                setInvalid();  // Set the form to invalid
            } else  // Do the trick of turning off validation on the form, then
            // run validation to set the form back to valid
            {
                boolean bTempDoValidationFlag = getDoValidation(); //remember state of validation
                setDoValidation(false); // turn validation off
                super.validate(false);  //"setValid()" since validation is off
                setDoValidation(bTempDoValidationFlag); //reset validation
            }
        } else  //do regular validation
        {
            super.validate(bIgnoreDoValidateFlag);
        }
    }

    public void onRender() {
        if (doCustomValidation) //makes sure the error message is displayed correctly since something between validate and render resets it
        {
            isValid = customValidationObject.isValid();
        }
        super.onRender();
    }

    public void onRenderEnd() //does some initializing that has to occur after the docbase object tag exists
    {
        super.onRenderEnd();

        //The jsp must have a docbaseobject tag for this to run
        m_component = getContainedComponent();
        m_docbaseObj = (DocbaseObject) m_component.getControl("docbaseObj");

        // Get the right kind of custom validation object
        if (m_docbaseObj != null && bObjectTypeChanged) {
            CustomValidationFactory customValidationFactory = new CustomValidationFactory(this, m_docbaseObj);
            customValidationObject = customValidationFactory.getCustomValidationObject();
            bObjectTypeChanged = false;
        }

        // Set the flag that determines whether or not we have to do custom validation
        if (customValidationObject != null) {
            doCustomValidation = customValidationObject.getDoCustomValidation();
        }
    }

    public void onChangeObjectType(Control control, ArgumentList args) {
        super.onChangeObjectType(control, args);
        bObjectTypeChanged = true;
    }

    protected boolean processOnNextPageFromImport() {
        Collection files = getFilesToImport();
        Integer maxCount = lookupInteger("max-import-file-count");
        if (maxCount != null
            && (files.size() > maxCount.intValue())) {
            Object[] params = new Object[]{new Integer(files.size()), maxCount};
            setReturnError("MSG_MAX_IMPORT_FILE_COUNT_EXCEEDED", params, null);
            WebComponentErrorService.getService().setNonFatalError(this, "MSG_MAX_IMPORT_FILE_COUNT_EXCEEDED",
                                                                   params, null);
            return false;
        } else {
            return super.processOnNextPageFromImport();
        }
    }
}