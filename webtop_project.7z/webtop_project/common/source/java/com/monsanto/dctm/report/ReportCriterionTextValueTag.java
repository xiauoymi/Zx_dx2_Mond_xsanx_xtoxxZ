package com.monsanto.dctm.report;

import com.documentum.fc.common.DfLogger;
import com.documentum.web.common.LocaleService;
import com.documentum.web.form.control.LabelTag;
import com.documentum.web.form.control.Link;
import com.documentum.web.form.control.LinkTag;
import com.documentum.web.form.control.TextTag;
import com.documentum.web.form.control.validator.RequiredFieldValidatorTag;

import javax.servlet.jsp.JspTagException;
import javax.servlet.jsp.JspWriter;
import java.io.IOException;

public class ReportCriterionTextValueTag extends ReportCriterionValueTag {
  private String valuecontrolname;

  protected void renderValueControl(String name, String value, JspWriter out) throws JspTagException, IOException {
    ReportCriterionValue valueControl = (ReportCriterionValue) getControl();
    Criterion valueControlCriterion = valueControl.getCriterion();
    if (valueControlCriterion != null) {
      if (valueControlCriterion.getEditcomponent() != null) {
        renderLabelAndLink(value, out);
      } else {
        renderTextBox(value);
      }
    } else {
      renderTextBox(value);
    }
  }

  private void renderLabelAndLink(String value, JspWriter out) throws JspTagException, IOException {
    ReportCriterionValue valueControl = (ReportCriterionValue) getControl();
    if (value == null || value.length() == 0) {
      value = getInitialLocatorDisplay(valueControl.getCriterion());
    }
    renderLabel(value);
    out.print("<span class='defaultcolumnspacer'>&nbsp;</span>");
    LinkTag link = new LinkTag();
    link.setPageContext(pageContext);
    link.setParent(this);
    String strEdit = nlsResourceClass.getString("MSG_EDIT", LocaleService.getLocale());
    link.setLabel(strEdit);
    Link linkObj = (Link) link.getControl();
    linkObj.setEventHandler("onclick", "onClickEdit", valueControl);
    link.doStartTag();
    link.doEndTag();
  }

  private String getInitialLocatorDisplay(Criterion criterion) {
    return criterion.getAllconfigelements().getChildValue("initiallocatordisplay");
  }

  private void renderLabel(String strValue) throws JspTagException {
    ReportCriterionValue reportCriterionValue = (ReportCriterionValue) getControl();
    String strClass = reportCriterionValue.getCssClass();
    String strStyle = reportCriterionValue.getCssStyle();
    LabelTag label = new LabelTag();
    label.setParent(this);
    label.setPageContext(pageContext);
    if (strClass != null)
      label.setCssclass(strClass);
    if (strStyle != null)
      label.setStyle(strStyle);
    label.setLabel(strValue);
    label.setId(getId());
    label.setEncodelabel("true");
    label.setName(reportCriterionValue.getElementName("value"));
    label.doStartTag();
    label.doEndTag();
  }

  private void renderTextBox(String strValue) throws JspTagException {
    DfLogger.info(this, "strValue = " + strValue, null, null);
    ReportCriterionValue reportCriterionValue = (ReportCriterionValue) getControl();

    String strClass = reportCriterionValue.getCssClass();
    String strStyle = reportCriterionValue.getCssStyle();
    String strSize = "20";
    TextTag text = new TextTag();
    text.setPageContext(pageContext);
    text.setParent(this);
    valuecontrolname = reportCriterionValue.getElementName("value");
    text.setName(valuecontrolname);
    text.setId(getId());
    text.setTooltip(reportCriterionValue.getToolTip());
    if (strClass != null)
      text.setCssclass(strClass);
    if (strStyle != null)
      text.setStyle(strStyle);
    if (strSize != null)
      text.setSize(strSize);
    text.setValue(strValue);

    text.doStartTag();
    text.doEndTag();
    if(reportCriterionValue.getCriterion().isRequired()) {
      RequiredFieldValidatorTag fieldValidatorTag = new RequiredFieldValidatorTag();
      fieldValidatorTag.setPageContext(pageContext);
      fieldValidatorTag.setParent(this);
      fieldValidatorTag.setName(reportCriterionValue.getElementName("reqfieldvalidator"));

      fieldValidatorTag.setErrormessage("you must specify a value for the \""+reportCriterionValue.getCriterion().getLabel()+"\" field");
      fieldValidatorTag.setControltovalidate(valuecontrolname);
      fieldValidatorTag.doStartTag();
      fieldValidatorTag.doEndTag();

    }
  }
}
