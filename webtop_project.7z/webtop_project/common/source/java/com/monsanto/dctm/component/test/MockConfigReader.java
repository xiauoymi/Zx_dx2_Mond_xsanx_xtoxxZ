/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.component.test;

import com.documentum.web.formext.config.ConfigFile;
import com.documentum.web.formext.config.IConfigReader;

import java.io.File;
import java.util.ArrayList;
import java.util.Iterator;

/**
 * Filename:    $RCSfile: MockConfigReader.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: lakench $ On:	$Date:
 * 2007/01/10 22:34:08 $
 *
 * @author lakench
 * @version $Revision: 1.3 $
 */
public class MockConfigReader implements IConfigReader {

  public String getAppName() {
    return "webcomponent";
  }

  public String getRootFolderPath() {
    return "./common/source/config";
  }

  public ConfigFile loadAppConfigFile(String strAppName) {
    String strPath = concatPath(concatPath(getRootFolderPath(), strAppName), "dummyapp.xml");
    return new ConfigFile(strPath, null);
  }

  public Iterator loadConfigFiles(String strAppName) {
    ArrayList configFiles = new ArrayList();
    String strFolderPath = concatPath(concatPath(getRootFolderPath(), strAppName), "config");
    loadConfigFiles(configFiles, strFolderPath, null);
    return configFiles.iterator();
  }

  private void loadConfigFiles(ArrayList configFiles, String strFolderPath, String strAppName) {
    File folder = new File(strFolderPath);
    if (!folder.exists())
      folder = new File(File.separator + strFolderPath);
    if (folder.exists()) {
      String strFiles[] = folder.list();
      for (int iFile = 0; iFile < strFiles.length; iFile++) {
        String strFileName = strFiles[iFile];
        String strFilePathName = concatPath(strFolderPath, strFileName);
        File file = new File(strFilePathName);
        if (file.isFile() && strFileName.endsWith(".xml")) {
          ConfigFile configFile = new ConfigFile(strFilePathName, strAppName);
          configFiles.add(configFile);
        } else if (file.isDirectory())
          loadConfigFiles(configFiles, strFilePathName, strAppName);
      }

    }
  }

  private String concatPath(String strPath1, String strPath2) {
    String strResult = strPath2;
    if (strPath1.length() > 0) {
      if (strPath1.endsWith("/") || strPath1.endsWith("\\"))
        strPath1 = strPath1.substring(0, strPath1.length() - 1);
      if (strPath2.startsWith("/") || strPath2.startsWith("\\"))
        strPath2 = strPath2.substring(1);
      strResult = strPath1 + "/" + strPath2;
    }
    return strResult;
  }
}