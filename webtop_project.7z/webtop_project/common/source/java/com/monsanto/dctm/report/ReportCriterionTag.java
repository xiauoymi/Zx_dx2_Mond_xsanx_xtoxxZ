package com.monsanto.dctm.report;

import com.documentum.web.common.WrapperRuntimeException;
import com.documentum.web.form.Control;
import com.documentum.web.form.ControlTag;

import javax.servlet.jsp.JspTagException;
import javax.servlet.jsp.JspWriter;
import java.io.IOException;

public class ReportCriterionTag extends ControlTag {

  private String criteria;
  private String pre;
  private String col1;
  private String col2;
  private String post;
  private Criterion criterion;

  public void release() {
    super.release();
    pre = null;
    col1 = null;
    col2 = null;
    post = null;
    criterion = null;
    criteria = null;
  }

  public String getCriteria() {
    return criteria;
  }

  public void setCriteria(String criteria) {
    this.criteria = criteria;
  }

  public String getCol1() {
    return col1;
  }

  public void setCol1(String col1) {
    this.col1 = col1;
  }

  public String getCol2() {
    return col2;
  }

  public void setCol2(String col2) {
    this.col2 = col2;
  }

  public String getPost() {
    return post;
  }

  public void setPost(String post) {
    this.post = post;
  }

  public String getPre() {
    return pre;
  }

  public void setPre(String pre) {
    this.pre = pre;
  }

  public void setCriterion(Criterion criterion) {
    this.criterion = criterion;
  }

  protected void setControlProperties(Control control) {
    super.setControlProperties(control);

    ReportCriterion reportCriterion = (ReportCriterion) control;
    if (getCriteria() != null) {
      reportCriterion.setCriteria(getCriteria());
    }
    if (getPre() != null) {
      reportCriterion.setPre(getPre());
    }
    if (getCol1() != null) {
      reportCriterion.setCol1(getCol1());
    }
    if (getCol2() != null) {
      reportCriterion.setCol2(getCol2());
    }
    if (getPost() != null) {
      reportCriterion.setPost(getPost());
    }
    if (criterion != null)
      reportCriterion.setCriterion(criterion);
  }

  protected Class getControlClass() {
    return ReportCriterion.class;
  }

  protected void renderEnd(JspWriter out) throws IOException, JspTagException {
    renderCriterion(out);
  }

  protected void renderCriterion(JspWriter out) throws JspTagException, IOException {

    ReportCriterion reportCriterion = (ReportCriterion) getControl();

    if (reportCriterion.isVisible()) {
      out.print(getPre());
      renderCriterionLabel(reportCriterion.getCriterion());
      out.print(getCol1());
      renderCriterionValue(reportCriterion.getCriterion());
      out.print(getCol2());
      out.print(getPost());
    }
  }

  private void renderCriterionLabel(Criterion criterion) throws JspTagException {
    ReportCriterionLabelTag criterionLabel = getReportCriterionLabelTagInstance(criterion);
    criterionLabel.setCriterion(criterion);
    criterionLabel.setPageContext(pageContext);
    criterionLabel.setParent(this);
    criterionLabel.doStartTag();
    criterionLabel.doEndTag();
  }

  private void renderCriterionValue(Criterion criterion) throws JspTagException {
    ReportCriterionValueTag criterionValue = getReportCriterionValueTagInstance(criterion);
    criterionValue.setCriteria(getCriteria());
    criterionValue.setCriterion(criterion);
    criterionValue.setName(getControl().getElementName("criterion"));
    criterionValue.setPageContext(pageContext);
    criterionValue.setParent(this);
    criterionValue.doStartTag();
    criterionValue.doEndTag();
  }

  private ReportCriterionValueTag getReportCriterionValueTagInstance(Criterion criterion) {
    String valuetagclass = com.monsanto.dctm.report.ReportCriterionTextValueTag.class.getName();
    if (criterion != null) {
      String valuetagclassFromCriterion = criterion.getValuetagclass();
      if (valuetagclassFromCriterion != null && valuetagclassFromCriterion.length() > 0) {
        valuetagclass = valuetagclassFromCriterion;
      }
    }
    try {
      return (ReportCriterionValueTag) Class.forName(valuetagclass).newInstance();
    } catch (InstantiationException e) {
      throw new WrapperRuntimeException("Could not create ReportCriterionLabelTag instance", e);
    } catch (IllegalAccessException e) {
      throw new WrapperRuntimeException("Could not create ReportCriterionLabelTag instance", e);
    } catch (ClassNotFoundException e) {
      throw new WrapperRuntimeException("Could not create ReportCriterionLabelTag instance", e);
    }
  }

  private ReportCriterionLabelTag getReportCriterionLabelTagInstance(Criterion criterion) {
    String labeltagclass = com.monsanto.dctm.report.ReportCriterionLabelTag.class.getName();
    if (criterion != null) {
      String labeltagclassFromCriterion = criterion.getLabeltagclass();
      if (labeltagclassFromCriterion != null && labeltagclassFromCriterion.length() > 0) {
        labeltagclass = labeltagclassFromCriterion;
      }
    }
    try {
      return (ReportCriterionLabelTag) Class.forName(labeltagclass).newInstance();
    } catch (InstantiationException e) {
      throw new WrapperRuntimeException("Could not create ReportCriterionLabelTag instance", e);
    } catch (IllegalAccessException e) {
      throw new WrapperRuntimeException("Could not create ReportCriterionLabelTag instance", e);
    } catch (ClassNotFoundException e) {
      throw new WrapperRuntimeException("Could not create ReportCriterionLabelTag instance", e);
    }
  }
}
