/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.drl;

import com.documentum.fc.client.IDfPersistentObject;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfId;
import com.documentum.web.common.ArgumentList;
import com.documentum.web.formext.action.ActionService;
import com.documentum.web.formext.action.IActionCompleteListener;
import com.documentum.web.formext.component.Component;
import com.documentum.web.formext.config.Context;

import java.util.Map;

/**
 * Filename:    $RCSfile: DRLViewOnlyComponent.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: lakench $
 * On:	$Date: 2007-10-12 05:21:59 $
 *
 * @author LAKENCH
 * @version $Revision: 1.2 $
 */
public class DRLViewOnlyComponent extends Component implements IActionCompleteListener {
  public void onInit(ArgumentList argumentList) {
    super.onInit(argumentList);
    String objectId = argumentList.get("objectId");
    String versionLabel = argumentList.get("versionLabel");
    String contentType = argumentList.get("format");
    viewObjectAndLogout(objectId, versionLabel, contentType);
  }

  public void onComplete(String strAction, boolean bSuccess, Map map) {
    doLogout("/component/logoff?afterLogoff=closeWindow");
  }

  protected void doLogout(String logoffUrl) {
    setComponentPage("logout");
    ArgumentList args = null;
    if (logoffUrl != null && logoffUrl.length() > 0) {
      args = new ArgumentList();
      args.add("homeurl", logoffUrl.toString());
    }
    ActionService.execute("logout", args, getContext(), this, null);
  }

  protected void viewObjectAndLogout(String objectId, String versionLabel, String contentType) {
    ArgumentList actionArgs = new ArgumentList();
    String specificObjectId = getSpecificObjectId(objectId, versionLabel);
    if (specificObjectId == null || specificObjectId.trim().length() == 0) specificObjectId = objectId;
    actionArgs.add("objectId", specificObjectId);
    actionArgs.add("contentType", contentType);
    actionArgs.add("navigateOnComplete", Boolean.FALSE.toString());
    Context actionContext = new Context(getContext());
    actionContext.set("objectId", specificObjectId);
    executeAction("drlview", actionArgs, actionContext, this, this);
  }

  private String getSpecificObjectId(String objectId, String versionLabel) {
    IDfSession session = getDfSession();
    try {
      IDfPersistentObject passedObject = session.getObject(new DfId(objectId));
      String chronicleId = passedObject.getId("i_chronicle_id").getId();
      IDfPersistentObject specificVersionObject = session.getObjectByQualification(
          "dm_sysobject (all) where i_chronicle_id = '" + chronicleId + "' and any r_version_label = '" + versionLabel +
              "'");
      if (specificVersionObject != null) {
        return specificVersionObject.getObjectId().getId();
      } else {
        return null;
      }
    } catch (DfException e) {
      return null;
    }
  }

  protected void executeAction(String actionId, ArgumentList actionArgs, Context actionContext,
                               Component callingComponent, IActionCompleteListener actionCompleteListener) {
    ActionService.execute(actionId, actionArgs, actionContext, callingComponent, actionCompleteListener);
  }
}