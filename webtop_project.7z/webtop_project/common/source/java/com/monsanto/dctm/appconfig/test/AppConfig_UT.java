/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.appconfig.test;

import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.MockSession;
import com.documentum.nls.NlsResourceBundle;
import com.documentum.web.form.ComponentTestUtils;
import com.documentum.web.form.control.Breadcrumb;
import com.documentum.web.form.control.databound.Datagrid;
import com.monsanto.dctm.appconfig.AppConfig;
import com.monsanto.dctm.component.test.MockDataProvider;
import com.monsanto.dctm.component.test.MockDatagrid;
import com.monsanto.dctm.component.test.MockSessionManager;
import junit.framework.TestCase;

/**
 * Filename:    $RCSfile: AppConfig_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: lakench $    	 On:	$Date:
 * 2007/08/21 05:23:14 $
 *
 * @author lakench
 * @version $Revision: 1.3 $
 */
public class AppConfig_UT extends TestCase {
  public void testInitialized() throws Exception {
    MockSessionManager mockSessionManager = new MockSessionManager();
    MockSession session = new MockSession(mockSessionManager);
    ((MockSessionManager) mockSessionManager).setSession(session);
    MockAppConfig appConfig = (MockAppConfig) ComponentTestUtils
        .getComponent(MockAppConfig.class, "appConfig", "testdocbase", mockSessionManager);
    try {
      assertNotNull(appConfig);

      NlsResourceBundle nlsResourceBundle = new NlsResourceBundle(
          "com.monsanto.dctm.appconfig.test.MockAppConfigNlsBundle");
      appConfig.setNlsClass(nlsResourceBundle);

      appConfig.initControls();

      IDfSession actualSession = ((Datagrid) appConfig.getControl(AppConfig.CONTROL_GRID)).getDataProvider()
          .getDfSession();
      assertEquals(session, actualSession);

      String actualQuery = ((Datagrid) appConfig.getControl(AppConfig.CONTROL_GRID)).getDataProvider().getQuery();
      assertEquals(MockAppConfig.BASE_QUERY + MockAppConfig.QUERY_ORDERBY, actualQuery);

      Breadcrumb breadcrumb = (Breadcrumb) appConfig.getControl(AppConfig.CONTROL_BREADCRUMB);
      String expectedBreadCrumbPath =
          appConfig.getString("MSG_ADMINISTRATION_LINK") + "/" + appConfig.getString("MSG_COMPONENT_ID");
      assertEquals(expectedBreadCrumbPath, breadcrumb.getValue());
    } finally {
      ComponentTestUtils.releaseComponent(appConfig);
    }
  }

  public void testOnRefreshData() throws Exception {
    MockSessionManager mockSessionManager = new MockSessionManager();
    MockSession session = new MockSession(mockSessionManager);
    ((MockSessionManager) mockSessionManager).setSession(session);
    MockAppConfig appConfig = (MockAppConfig) ComponentTestUtils
        .getComponent(MockAppConfig.class, "appConfig", "testdocbase", mockSessionManager);

    try {
      MockDatagrid mockDataGrid = (MockDatagrid) appConfig.getControl(AppConfig.CONTROL_GRID, MockDatagrid.class);

      appConfig.onRefreshData();

      assertTrue(((MockDataProvider) mockDataGrid.getDataProvider()).wasRefreshed);
    } finally {
      ComponentTestUtils.releaseComponent(appConfig);
    }
  }

  public void testOnClickBreadcrumb() throws Exception {
    MockSessionManager mockSessionManager = new MockSessionManager();
    MockSession session = new MockSession(mockSessionManager);
    ((MockSessionManager) mockSessionManager).setSession(session);
    MockAppConfig appConfig = (MockAppConfig) ComponentTestUtils
        .getComponent(MockAppConfig.class, "appConfig", "testdocbase", mockSessionManager);
    try {
      NlsResourceBundle nlsResourceBundle = new NlsResourceBundle(
          "com.monsanto.dctm.appconfig.test.MockAppConfigNlsBundle");
      appConfig.setNlsClass(nlsResourceBundle);
      appConfig.initControls();

      Breadcrumb breadcrumb = (Breadcrumb) appConfig.getControl(AppConfig.CONTROL_BREADCRUMB);
      breadcrumb.setValue(appConfig.getString("MSG_ADMINISTRATION_LINK"));
      appConfig.onClickBreadcrumb(breadcrumb, null);
      assertTrue(appConfig.jumpedToAdministrationComponent);
    } finally {
      ComponentTestUtils.releaseComponent(appConfig);
    }
  }
}