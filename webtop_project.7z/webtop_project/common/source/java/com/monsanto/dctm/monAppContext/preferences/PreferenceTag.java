package com.monsanto.dctm.monAppContext.preferences;

public class PreferenceTag extends
		com.documentum.web.formext.control.preference.PreferenceTag {

	protected Class getControlClass() {
		return Preference.class;
	}
}
