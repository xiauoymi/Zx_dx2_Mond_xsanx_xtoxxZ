/*
 * Created on May 19, 2005
 */
package com.monsanto.dctm.validation;

public interface ICustomValidation {
	
	boolean isValid();
	boolean getDoCustomValidation();
}
