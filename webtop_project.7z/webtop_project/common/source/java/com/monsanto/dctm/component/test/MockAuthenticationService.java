/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.component.test;

import com.documentum.fc.common.DfException;
import com.documentum.web.common.ArgumentList;
import com.documentum.web.formext.session.IAuthenticationService;
import com.documentum.web.formext.session.PasswordExpiredException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Filename:    $RCSfile: MockAuthenticationService.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: lakench $    	 On:	$Date: 2007-01-16 22:56:33 $
 *
 * @author LAKENCH
 * @version $Revision: 1.1 $
 */
public class MockAuthenticationService implements IAuthenticationService {
    public String authenticate(HttpServletRequest request, HttpServletResponse response, String docbase) throws
                                                                                                         DfException {
        return docbase;
    }

    public String getLoginComponent(HttpServletRequest request, HttpServletResponse response, String docbase, ArgumentList outArgs) {
        return null;
    }

    public void login(HttpSession httpSession, String strDocbase, String strUsername, String strPassword, String strDomain) throws
                                                                                                                            PasswordExpiredException,
                                                                                                                            DfException {
    }

    public void changePassword(HttpSession httpSession, String strUsername, String strDocbase, String strDomain, String strOldPassword, String strNewPassword) throws
                                                                                                                                                               DfException {
    }
}