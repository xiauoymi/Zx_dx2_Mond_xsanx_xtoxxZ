/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.appconfig.test;

import com.documentum.fc.client.MockSession;
import com.documentum.web.common.ArgumentList;
import com.documentum.web.form.ComponentTestUtils;
import com.documentum.web.form.IReturnListener;
import com.documentum.web.form.control.Label;
import com.documentum.web.form.control.Link;
import com.documentum.web.form.control.Text;
import com.monsanto.dctm.appconfig.AppConfigItem;
import com.monsanto.dctm.appconfig.AppConfigItemBaseComponent;
import com.monsanto.dctm.appconfig.AppConfigUpdateRequestor;
import com.monsanto.dctm.component.test.MockDfUser;
import com.monsanto.dctm.component.test.MockSessionManager;
import junit.framework.TestCase;

import java.util.HashMap;
import java.util.Map;

/**
 * Filename:    $RCSfile: AppConfigUpdateRequestor_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: lakench $
 * On:	$Date: 2007-10-26 18:47:58 $
 *
 * @author lakench
 * @version $Revision: 1.4 $
 */
public class AppConfigUpdateRequestor_UT extends TestCase {
  public static final String TESTNAME = "testname";
  public static final String TESTAREA = "testarea";
  public static final String TESTEMAIL = "testemail";
  public static final String TESTUSER = "testuser";
  public static final String TESTDOCBASE = "testdocbase";
  public static final String TEST_COMPONENT_NAME = "testappconfigupdaterequestor";

  public void testCreateAndInitialized() throws Exception {
    MockAppConfigUpdateRequestor component = (MockAppConfigUpdateRequestor) ComponentTestUtils
        .getComponent(MockAppConfigUpdateRequestor.class, TEST_COMPONENT_NAME, TESTDOCBASE,
            new MockSessionManager());
    assertNotNull(component);
    assertTrue(component instanceof IReturnListener);
    ComponentTestUtils.releaseComponent(component);
  }

  public void testInitializedForAddAction() throws Exception {
    MockAppConfigUpdateRequestor component = (MockAppConfigUpdateRequestor) ComponentTestUtils
        .getComponent(MockAppConfigUpdateRequestor.class, TEST_COMPONENT_NAME, TESTDOCBASE,
            new MockSessionManager());

    ArgumentList argumentList = new ArgumentList();
    argumentList.add(AppConfigUpdateRequestor.APP_CONFIG_ACTION_ARG, "this can be anything for adds");
    component.setupComponent(argumentList);

    Label instructionsControl = (Label) component.getControl(AppConfigUpdateRequestor.INSTRUCTIONS);
    assertEquals(AppConfigUpdateRequestor.ADD_INSTRUCTIONS, instructionsControl.getLabel());
    ComponentTestUtils.releaseComponent(component);
  }

  public void testOnCommitForAddAction() throws Exception {
    MockSessionManager mockSessionManager = new MockSessionManager();
    MockSession session = new MockSession(mockSessionManager);
    MockDfUser mockUser = new MockDfUser();
    mockUser.setUserName(TESTUSER);
    mockUser.setUserAddress(TESTEMAIL);
    session.addObject(mockUser, "dm_user where user_name = 'testuser'");

    ((MockSessionManager) mockSessionManager).setSession(session);
    MockAppConfigUpdateRequestor component = (MockAppConfigUpdateRequestor) ComponentTestUtils
        .getComponent(MockAppConfigUpdateRequestor.class, TEST_COMPONENT_NAME, TESTDOCBASE,
            mockSessionManager);

    ArgumentList argumentList = new ArgumentList();
    argumentList.add(AppConfigUpdateRequestor.APP_CONFIG_ACTION_ARG, "this can be anything for adds");
    component.setupComponent(argumentList);
    Text areaControl = (Text) component.getControl(AppConfigUpdateRequestor.AREA_COL_NAME, Text.class);
    areaControl.setValue(TESTAREA);
    Label nameControl = (Label) component.getControl(AppConfigUpdateRequestor.NAME_COL_NAME, Label.class);
    nameControl.setLabel(TESTUSER);

    component.onCommitChanges();

    Map expectedValues = new HashMap(4);
    expectedValues.put(AppConfigUpdateRequestor.ROWID_COL_NAME, "0");
    expectedValues.put(AppConfigUpdateRequestor.AREA_COL_NAME, TESTAREA);
    expectedValues.put(AppConfigUpdateRequestor.NAME_COL_NAME, TESTUSER);
    expectedValues.put(AppConfigUpdateRequestor.EMAIL_COL_NAME, TESTEMAIL);
    AppConfigItem expectedReturnItem = new AppConfigItem(AppConfigUpdateRequestor.APP_CONFIG_ITEM_TYPE, expectedValues);

    assertEquals("this can be anything for adds",
        component.getReturnValue(AppConfigUpdateRequestor.APP_CONFIG_ACTION_ARG));
    assertTrue(
        Boolean.valueOf((String) component.getReturnValue(AppConfigItemBaseComponent.REALLY_ADD)).booleanValue());
    assertEquals(expectedReturnItem, component.getReturnValue(AppConfigItemBaseComponent.APP_CONFIG_ITEM));
    ComponentTestUtils.releaseComponent(component);
  }

  public void testInitializedForRemoveAction() throws Exception {
    MockAppConfigUpdateRequestor component = (MockAppConfigUpdateRequestor) ComponentTestUtils
        .getComponent(MockAppConfigUpdateRequestor.class, TEST_COMPONENT_NAME, TESTDOCBASE,
            new MockSessionManager());

    ArgumentList argumentList = new ArgumentList();
    argumentList.add(AppConfigUpdateRequestor.APP_CONFIG_ACTION_ARG, AppConfigUpdateRequestor.REMOVE);
    argumentList.add(AppConfigUpdateRequestor.ROWID_COL_NAME, "0");
    argumentList.add(AppConfigUpdateRequestor.AREA_COL_NAME, TESTAREA);
    argumentList.add(AppConfigUpdateRequestor.NAME_COL_NAME, TESTNAME);
    argumentList.add(AppConfigUpdateRequestor.EMAIL_COL_NAME, TESTEMAIL);
    component.setupComponent(argumentList);

    Label instructionsControl = (Label) component.getControl(AppConfigUpdateRequestor.INSTRUCTIONS);
    assertEquals(AppConfigUpdateRequestor.REMOVE_INSTRUCTIONS, instructionsControl.getLabel());
    Link selectRequestorControl = (Link) component.getControl(AppConfigUpdateRequestor.SELECT_REQUESTOR_LINK);
    assertFalse(selectRequestorControl.isVisible());
    Text areaControl = (Text) component.getControl(AppConfigUpdateRequestor.AREA_COL_NAME);
    assertEquals(TESTAREA, areaControl.getValue());
    assertFalse(areaControl.isEnabled());
    Label nameControl = (Label) component.getControl(AppConfigUpdateRequestor.NAME_COL_NAME);
    assertEquals(TESTNAME, nameControl.getLabel());
    ComponentTestUtils.releaseComponent(component);
  }

  public void testOnCommitChangesForRemove() throws Exception {
    MockAppConfigUpdateRequestor component = (MockAppConfigUpdateRequestor) ComponentTestUtils
        .getComponent(MockAppConfigUpdateRequestor.class, TEST_COMPONENT_NAME, TESTDOCBASE,
            new MockSessionManager());

    ArgumentList argumentList = new ArgumentList();
    argumentList.add(AppConfigUpdateRequestor.APP_CONFIG_ACTION_ARG, AppConfigUpdateRequestor.REMOVE);
    argumentList.add(AppConfigUpdateRequestor.ROWID_COL_NAME, "0");
    argumentList.add(AppConfigUpdateRequestor.AREA_COL_NAME, TESTAREA);
    argumentList.add(AppConfigUpdateRequestor.NAME_COL_NAME, TESTNAME);
    argumentList.add(AppConfigUpdateRequestor.EMAIL_COL_NAME, TESTEMAIL);
    component.setupComponent(argumentList);

    component.onCommitChanges();

    Map expectedValues = new HashMap(4);
    expectedValues.put(AppConfigUpdateRequestor.ROWID_COL_NAME, "0");
    expectedValues.put(AppConfigUpdateRequestor.AREA_COL_NAME, TESTAREA);
    expectedValues.put(AppConfigUpdateRequestor.NAME_COL_NAME, TESTNAME);
    expectedValues.put(AppConfigUpdateRequestor.EMAIL_COL_NAME, TESTEMAIL);
    AppConfigItem expectedReturnItem = new AppConfigItem(AppConfigUpdateRequestor.APP_CONFIG_ITEM_TYPE, expectedValues);

    assertEquals(AppConfigUpdateRequestor.REMOVE,
        component.getReturnValue(AppConfigUpdateRequestor.APP_CONFIG_ACTION_ARG));
    assertTrue(
        Boolean.valueOf((String) component.getReturnValue(AppConfigItemBaseComponent.REALLY_DELETE)).booleanValue());
    assertEquals(expectedReturnItem, component.getReturnValue(AppConfigItemBaseComponent.APP_CONFIG_ITEM));
    ComponentTestUtils.releaseComponent(component);
  }

  public void testOnClickEditRequestorLink() throws Exception {
    MockAppConfigUpdateRequestor component = (MockAppConfigUpdateRequestor) ComponentTestUtils
        .getComponent(MockAppConfigUpdateRequestor.class, TEST_COMPONENT_NAME, TESTDOCBASE,
            new MockSessionManager());

    component.onClickEditRequestor(null, null);
    assertTrue(component.nestedToEditRequestorComponent);
    ComponentTestUtils.releaseComponent(component);
  }

  public void testReturnFromEditRequestorComponent() throws Exception {
    MockSessionManager mockSessionManager = new MockSessionManager();
    MockSession session = new MockSession(mockSessionManager);
    MockDfUser mockUser = new MockDfUser();
    mockUser.setUserName(TESTUSER);
    session.addObject(mockUser, "dm_user where user_name = 'testuser'");

    ((MockSessionManager) mockSessionManager).setSession(session);
    MockAppConfigUpdateRequestor component = (MockAppConfigUpdateRequestor) ComponentTestUtils
        .getComponent(MockAppConfigUpdateRequestor.class, TEST_COMPONENT_NAME, TESTDOCBASE,
            mockSessionManager);
    component.setUserToReturnFromCompletionArgs(mockUser);

    component.onReturn(null, new HashMap());

    Label nameControl = (Label) component.getControl(AppConfigUpdateRequestor.NAME_COL_NAME);
    assertEquals(TESTUSER, nameControl.getLabel());
    ComponentTestUtils.releaseComponent(component);
  }

  public void testReturnFromEditRequestorComponentWithNullCompletionArgs() throws Exception {
    MockSessionManager mockSessionManager = new MockSessionManager();
    MockSession session = new MockSession(mockSessionManager);
    MockDfUser mockUser = new MockDfUser();
    mockUser.setUserName(TESTUSER);
    session.addObject(mockUser, "dm_user where user_name = 'testuser'");

    ((MockSessionManager) mockSessionManager).setSession(session);
    MockAppConfigUpdateRequestor component = (MockAppConfigUpdateRequestor) ComponentTestUtils
        .getComponent(MockAppConfigUpdateRequestor.class, TEST_COMPONENT_NAME, TESTDOCBASE,
            mockSessionManager);
    component.setUserToReturnFromCompletionArgs(mockUser);

    component.onReturn(null, null);

    Label nameControl = (Label) component.getControl(AppConfigUpdateRequestor.NAME_COL_NAME, Label.class);
    assertNull(nameControl.getLabel());
    ComponentTestUtils.releaseComponent(component);
  }
}