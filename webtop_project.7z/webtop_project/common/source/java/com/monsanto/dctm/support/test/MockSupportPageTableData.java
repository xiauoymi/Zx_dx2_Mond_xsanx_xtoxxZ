/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.support.test;

import com.documentum.fc.common.DfException;
import com.documentum.web.formext.component.Component;
import com.monsanto.dctm.support.SupportPageTableData;

import java.util.List;

/**
 * Filename:    $RCSfile: MockSupportPageTableData.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: lakench $
 * On:	$Date: 2007-08-02 18:23:24 $
 *
 * @author lakench
 * @version $Revision: 1.2 $
 */
public class MockSupportPageTableData extends SupportPageTableData {
  private List data;
  private List columnList;

  public MockSupportPageTableData(Component component) {
    super(component);
  }

  public void setData(List data) {
    this.data = data;
  }

  public void setColumnList(List columnList) {
    this.columnList = columnList;
  }

  public List getData() throws DfException {
    return data;
  }

  public List getColumnList() {
    return columnList;
  }
}