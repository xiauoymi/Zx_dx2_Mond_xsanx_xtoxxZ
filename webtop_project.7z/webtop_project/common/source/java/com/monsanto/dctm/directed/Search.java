/*
 Copyright:  Copyright � 2006 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.directed;

import com.documentum.fc.client.IDfSysObject;
import com.documentum.fc.common.DfException;
import com.documentum.web.common.ArgumentList;
import com.documentum.web.common.CollaborationService;
import com.documentum.web.common.WrapperRuntimeException;
import com.documentum.web.env.EnvironmentService;
import com.documentum.web.form.control.Link;
import com.documentum.web.formext.action.ActionService;
import com.documentum.web.formext.docbase.FolderUtil;
import com.documentum.web.formext.docbase.ObjectCacheUtil;
import com.documentum.webcomponent.common.WebComponentErrorService;
import com.documentum.webcomponent.navigation.drilldown.DrillDown;

/**
 * Filename:    $RCSfile: Search.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: lakench $    	 On:	$Date: 2007-01-26 23:35:31 $
 *
 * @author lakench
 * @version $Revision: 1.2 $
 */
public class Search extends com.monsanto.dctm.search.Search {
    public void onClickDocbaseObject(Link linkbtn, ArgumentList args) {
        String strObjectId = args.get("objectId");
        if (!FolderUtil.isFolderType(strObjectId)) {
            if (CollaborationService.isNotePageType(strObjectId)) {
                super.onClickDocbaseObject(linkbtn, args);
            } else {
                setDocbaseContext(strObjectId, false);
            }
        }
        try {
            IDfSysObject sysobj;
            try {
                sysobj = (IDfSysObject) ObjectCacheUtil.getObject(getDfSession(), strObjectId);
            }
            catch (DfException e) {
                setReturnError("MSG_CANNOT_FETCH_OBJECT", null, e);
                WebComponentErrorService.getService().setNonFatalError(this, "MSG_CANNOT_FETCH_OBJECT", e);
                return;
            }

            if (sysobj.isVirtualDocument()) {
                // launch the VDM List streamline component
                args.add("structureComponent", getVDMComponent());

//                // add the home arguments for portal so we have a return path
//                if (EnvironmentService.getEnvironment().isPortalEnvironment()) {
//                    args.replace(DrillDown.HOME_COMPONENT, this.getComponentId());
//                    args.replace(DrillDown.HOME_COMPONENT_ARGS, ArgumentList.encode(this.getInitArgs()));
//                }

                ActionService.execute("directed_vdmlist", args, getContext(), this, null);
            } else {
                super.onClickDocbaseObject(linkbtn, args);
            }
        }
        catch (DfException e) {
            throw new WrapperRuntimeException("onClickDocument()", e);
        }
        finally {
            restoreCurrentDocbase();
        }
    }
}