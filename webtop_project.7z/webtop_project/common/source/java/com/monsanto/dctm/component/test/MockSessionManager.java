/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.component.test;

import com.documentum.fc.client.*;
import com.documentum.fc.common.IDfLoginInfo;

import java.util.HashMap;
import java.util.Map;

/**
 * Filename:    $RCSfile: MockSessionManager.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: lakench $    	 On:	$Date: 2007-05-12 05:29:56 $
 *
 * @author lakench
 * @version $Revision: 1.3 $
 */
public class MockSessionManager implements IDfSessionManager {

    public boolean wasReleaseCalled = false;
    private IDfSession mockSession;
    private Map identities = new HashMap();
    private Map sessions = new HashMap();

    public void setPrincipalName(String string) {
    }

    public String getPrincipalName() {
        return null;
    }

    public void setLocale(String string) {
    }

    public String getLocale() {
        return null;
    }

    public void setIdentity(String docbase, IDfLoginInfo iDfLoginInfo) throws DfServiceException {
        identities.put(docbase, iDfLoginInfo);
    }

    public IDfLoginInfo getIdentity(String docbase) {
        return (IDfLoginInfo) identities.get(docbase);
    }

    public boolean hasIdentity(String docbase) {
        if (docbase != null)
            return identities.containsKey(docbase);
        else
            return false;
    }

    public void clearIdentity(String string) {
        identities.remove(string);
    }

    public void clearIdentities() {
        identities.clear();
    }

    public void authenticate(String string) throws DfIdentityException, DfAuthenticationException, DfPrincipalException,
                                                   DfServiceException {
    }

    public IDfSession getSession(String docbase) throws DfIdentityException, DfAuthenticationException,
                                                        DfPrincipalException, DfServiceException {
        if (identities.containsKey(docbase)) {
            IDfLoginInfo identity = (IDfLoginInfo) identities.get(docbase);
            String user = identity.getUser();
            IDfSession session = null;
            Map sessionsByUserid = null;
            if (sessions.containsKey(docbase)) {
                sessionsByUserid = (Map) sessions.get(docbase);
                if (sessionsByUserid.containsKey(user)) {
                    session = (IDfSession) sessionsByUserid.get(user);
                } else {
                    session = newSession(docbase);
                }
            } else {
                session = newSession(docbase);
                sessionsByUserid = new HashMap();
            }
            sessionsByUserid.put(user, session);
            sessions.put(docbase, sessionsByUserid);
            return session;
        }
        return mockSession;
    }

    public IDfSession getSession(String docbase, String user) {
        IDfSession session = null;
        if (sessions.containsKey(docbase)) {
            Map sessionsByUserid = (Map) sessions.get(docbase);
            if (sessionsByUserid.containsKey(user)) {
                session = (IDfSession) sessionsByUserid.get(user);
            }
        }
        return session;
    }

    public void setSession(IDfSession session) {
        mockSession = session;
    }

    public IDfSession newSession(String docbase) throws DfIdentityException, DfAuthenticationException,
                                                        DfPrincipalException, DfServiceException {
        if (identities.containsKey(docbase)) {
            MockSession session = new MockSession(this);
            IDfLoginInfo identity = (IDfLoginInfo) identities.get(docbase);
            String user = identity.getUser();
            session.setLoginUserName(user);
            session.setLoginInfo(identity);
            return session;
        } else {
            throw new DfIdentityException("identity not found for docbase: " + docbase);
        }
    }

    public void release(IDfSession session) {
        this.wasReleaseCalled = true;
    }

    public void beginTransaction() throws DfServiceException {
    }

    public void commitTransaction() throws DfServiceException {
    }

    public void abortTransaction() throws DfServiceException {
    }

    public boolean isTransactionActive() {
        return false;
    }

    public void setTransactionRollbackOnly() {
    }

    public boolean getTransactionRollbackOnly() {
        return false;
    }

    public void beginClientControl() {
    }

    public void endClientControl() throws DfServiceException {
    }

    public IDfSessionManagerStatistics getStatistics() {
        return null;
    }

    public IDfSessionManagerEventListener setListener(IDfSessionManagerEventListener iDfSessionManagerEventListener) {
        return null;
    }
}