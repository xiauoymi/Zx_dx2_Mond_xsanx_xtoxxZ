package com.monsanto.dctm.action;

import com.documentum.fc.client.DfServiceException;
import com.documentum.fc.client.IDfCollection;
import com.documentum.fc.client.IDfPersistentObject;
import com.documentum.fc.client.IDfSysObject;
import com.documentum.fc.common.DfException;
import com.documentum.web.common.ArgumentList;
import com.documentum.web.common.WrapperRuntimeException;
import com.documentum.web.formext.component.Component;
import com.documentum.web.formext.config.Context;
import com.documentum.web.formext.config.IConfigElement;
import com.documentum.webtop.webcomponent.drl.DRLSysObjectViewAction;
import com.monsanto.dctm.dctmSession.DctmSession;
import com.monsanto.dctm.dctmSession.Session;
import com.monsanto.dctm.dctmSession.SessionInstance;

import java.util.Map;

public class DRLViewPDFRendition extends DRLSysObjectViewAction {
//    private static final double VALID_CONTENT_SIZE = 0.4;
//
//    public boolean queryExecute(String strAction, IConfigElement config, ArgumentList args, Context context, Component component) {
//        //This code was added to prevent system from looking up the preferred view action/application.
//        //Since we have commenting turned on it was always running the comment action queryExecute and this was causing
//        // problems with the view button being grayed out sometimes.
//
//        boolean bExecute = false;
//        long contentSize = 0;
//        IDfSysObject sysobj = getSysObject(component, args);
//        contentSize = getContentSize(args, contentSize, sysobj);
//
//        if (contentSize > VALID_CONTENT_SIZE) {
//            String strContentType = getContentType(args, sysobj);
//            if (strContentType != null && strContentType.length() > 0) {
//                args.add("contentType", strContentType);
//            }
//            bExecute = true;
//        } else {
//            bExecute = super.queryExecute(strAction, config, args, context, component);
//        }
//
//
//        return bExecute;
//    }
//
//    private String getContentType(ArgumentList args, IDfSysObject sysobj) {
//        String strContentType = null;
//        strContentType = args.get("contentType");
//        if (strContentType == null || strContentType.length() == 0) {
//            if (sysobj != null) {
//                try {
//                    strContentType = sysobj.getContentType();
//                } catch (DfException e) {
//                    throw new WrapperRuntimeException("Failed to get content type", e);
//                }
//            }
//        }
//        return strContentType;
//    }
//
//    private IDfSysObject getSysObject(Component component, ArgumentList args) {
//        IDfSession dfSession = component.getDfSession();
//        String strObjectId = args.get("objectId");
//        IDfSysObject sysobj = null;
//        try {
//            sysobj = (IDfSysObject) getSysObjectFromCache(dfSession, strObjectId);
//        } catch (DfException e) {
//            throw new WrapperRuntimeException("Failed to get sysobject", e);
//        }
//        return sysobj;
//    }
//
//    private long getContentSize(ArgumentList args, long contentSize, IDfSysObject sysobj) {
//        try {
//
//
//            String strContentSize = args.get("contentSize");
//            if (strContentSize != null && strContentSize.length() != 0) {
//                contentSize = (long) Double.parseDouble(strContentSize);
//            } else {
//                if (sysobj != null) {
//                    contentSize = sysobj.getContentSize();
//                }
//            }
//        }
//        catch (DfException e) {
//            throw new WrapperRuntimeException("Failed to get content size", e);
//        }
//        return contentSize;
//    }

//    protected IDfPersistentObject getSysObjectFromCache(IDfSession dfSession, String strObjectId) throws DfException {
//        return ObjectCacheUtil.getObject(dfSession, strObjectId);
//    }

    public boolean execute(String strAction, IConfigElement config, ArgumentList args, Context context, Component component, Map completionArgs) {
        replaceContentTypeArgIfPDFExists(args);
        return super.execute(strAction, config, args, context, component, completionArgs);
    }

    protected void replaceContentTypeArgIfPDFExists(ArgumentList args) {
        if (args != null) {
            String objectId = args.get("objectId");
            try {
                if (hasPDFRendition(objectId)) {
                    args.replace(m_strContentTypeArg, m_strArrayContentTypePDF);
                }
            } catch (DfServiceException e) {
                throw new WrapperRuntimeException(e);
            }
        }
    }

    protected boolean hasPDFRendition(String objectId) throws DfServiceException {
        IDfCollection contentTypes = null;
        Session session = createSession();
        SessionInstance docbaseSession = session.getNewSession();

        try {
            IDfSysObject sysObject = (IDfSysObject) docbaseSession.getObject(objectId);
            contentTypes = sysObject.getRenditions("r_object_id");

            while (contentTypes.next()) {
                String attrValue = contentTypes.getString("r_object_id");
                IDfPersistentObject persObj = (IDfPersistentObject) docbaseSession.getObject(attrValue);
                String format = persObj.getString("full_format");
                if (format.equals(m_strArrayContentTypePDF)) {
                    return true;
                }
            }
            return false;

        } catch (DfException dfe) {
            System.out.println("Error while searching for rendition: " + dfe.getMessage());
            dfe.printStackTrace();
            return false;
        }
        finally {
            if (docbaseSession != null) {
                docbaseSession.release();
            }
            if (contentTypes != null) {
                try {
                    contentTypes.close();
                } catch (DfException e) {
                    e.printStackTrace();
                }
            }
        }
    }//hasPdfRendition

    protected Session createSession() {
        return new DctmSession();
    }

    /**
     * String specifying the pdf content type
     */
    private String m_strArrayContentTypePDF = "pdf";

    /**
     * String specifying the key referencing the content type value in the
     * ArgumentList passed
     */
    private String m_strContentTypeArg = "contentType";
}
