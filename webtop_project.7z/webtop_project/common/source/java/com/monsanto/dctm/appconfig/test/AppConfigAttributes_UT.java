/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.appconfig.test;

import com.documentum.web.common.ArgumentList;
import com.documentum.web.form.ComponentTestUtils;
import com.documentum.webcomponent.admin.container.ITypedObjectContainer;
import com.monsanto.dctm.component.test.MockSessionManager;
import junit.framework.TestCase;

/**
 * Filename:    $RCSfile: AppConfigAttributes_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: lakench $
 * On:	$Date: 2007-10-12 05:21:59 $
 *
 * @author lakench
 * @version $Revision: 1.3 $
 */
public class AppConfigAttributes_UT extends TestCase {
  public void testCreate() throws Exception {
    MockAppConfigAttributes appConfigAttributes = (MockAppConfigAttributes) ComponentTestUtils
        .getComponent(MockAppConfigAttributes.class, "appConfigAttributes", "testdocbase", new MockSessionManager());
    assertNotNull(appConfigAttributes);
    ComponentTestUtils.releaseComponent(appConfigAttributes);
  }

  public void testPatchArgsWithNonNewObjectId() throws Exception {
    MockAppConfigAttributes appConfigAttributes = (MockAppConfigAttributes) ComponentTestUtils
        .getComponent(MockAppConfigAttributes.class, "appConfigAttributes", "testdocbase", new MockSessionManager());
    try {
      assertNotNull(appConfigAttributes);

      ArgumentList argumentList = new ArgumentList();
      argumentList.add("objectId", "testnonnewobjectid");

      appConfigAttributes.patchObjectIdFromTypedObjectContainer(argumentList);

      assertEquals("testnonnewobjectid", argumentList.get("objectId"));
    } finally {
      ComponentTestUtils.releaseComponent(appConfigAttributes);
    }
  }

  public void testPatchArgsWithNewObjectId() throws Exception {
    MockAppConfigAttributes appConfigAttributes = (MockAppConfigAttributes) ComponentTestUtils
        .getComponent(MockAppConfigAttributes.class, "appConfigAttributes", "testdocbase", new MockSessionManager());
    try {
      assertNotNull(appConfigAttributes);

      ArgumentList argumentList = new ArgumentList();
      argumentList.add("objectId", "newobject");

      appConfigAttributes.patchObjectIdFromTypedObjectContainer(argumentList);

      assertEquals(
          ((ITypedObjectContainer) appConfigAttributes.getContainer()).getDfTypedObject().getObjectId().getId(),
          argumentList.get("objectId"));
    } finally {
      ComponentTestUtils.releaseComponent(appConfigAttributes);
    }
  }
}