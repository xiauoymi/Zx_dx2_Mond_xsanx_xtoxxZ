/*
 Copyright:  Copyright � 2006 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.control;

import com.documentum.web.formext.config.IConfigElement;
import com.documentum.web.formext.control.docbase.DocbaseAttributeValue;
import com.documentum.web.formext.control.docbase.DocbaseAttributeValueTag;
import com.documentum.web.formext.control.docbase.DocbaseObject;

import javax.servlet.jsp.JspTagException;
import javax.servlet.jsp.JspWriter;
import java.io.IOException;

/**
 * Filename:    $RCSfile: SingleAttributeValueTag.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: tsvedan $    	 On:	$Date: 2006-10-25 17:20:52 $
 *
 * @author tsvedan
 * @version $Revision: 1.1 $
 */
public class SingleAttributeValueTag extends DocbaseAttributeValueTag {

  protected void renderSingleAttribute(String strFormattedValue,
                                       String strValue,
                                       boolean bReadonly,
                                       boolean bHasCompleteList,
                                       JspWriter out)
      throws IOException, JspTagException {

    String strLines = setDynamicLines();
    String size = getConfigValue("size");
    DocbaseAttributeValue value = (DocbaseAttributeValue) getControl();
    value.setLines(strLines);
    if (size != null && size.length() > 0)
      value.setSize(size);
    super.renderSingleAttribute(strFormattedValue, strValue,
        bReadonly, bHasCompleteList, out);
  }

  private String setDynamicLines() {
    DocbaseAttributeValue value = (DocbaseAttributeValue) getControl();
    DocbaseObject obj = (DocbaseObject) getForm().getControl(value.getObject());
    IConfigElement iConfigElement = obj.getConfigForAttribute(
        value.getAttribute(), "lines");
    if (iConfigElement != null) {
      return (iConfigElement.getValue());
    }
    return "5";
  }

  private String getConfigValue(String element) {
    DocbaseAttributeValue value = (DocbaseAttributeValue) getControl();
    DocbaseObject obj = (DocbaseObject) getForm().getControl(value.getObject());
    IConfigElement iConfigElement = obj.getConfigForAttribute(
        value.getAttribute(), element);
    if (iConfigElement != null) {
      return (iConfigElement.getValue());
    }
    return null;
  }

}