/*
 * search.java
 *
 * Created on July 26, 2004, 11:58 AM
 */
package com.monsanto.dctm.search;

import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.IDfSysObject;
import com.documentum.fc.client.search.IDfSmartListDefinition;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfId;
import com.documentum.fc.common.IDfId;
import com.documentum.web.common.ArgumentList;
import com.documentum.web.common.WrapperRuntimeException;
import com.documentum.web.form.Control;
import com.documentum.web.form.control.databound.Datagrid;
import com.documentum.web.formext.session.DocbaseUtils;
import com.documentum.web.formext.session.SessionManagerHttpBinding;
import com.documentum.web.util.SearchUtil;
import com.monsanto.dctm.monAppContext.MonAppContextService;
import com.monsanto.dctm.spreadsheet.SpreadsheetFromDatagrid;


public class Search extends com.documentum.webtop.webcomponent.search.SearchEx {
    protected String getColumnsPreferenceId() {
        return super.getColumnsPreferenceId() + "." +
               MonAppContextService.getMonAppContextService().getMonAppContextInternalName();
    }

    public void onClickExportToExcel(Control ctrl, ArgumentList args) {
        new SpreadsheetFromDatagrid((Datagrid) getControl("doclistgrid"), getColumns(),
                                    getPageContext().getServletContext()).displaySpreadsheet(this);
    }

    protected void buildQuery(ArgumentList args) {
        IDfSession session = null;
        try {
            String strQueryType = args.get("queryType");
            String strQuery = args.get("query");
            if (strQueryType != null && strQueryType.equals("objectId")) {
                setSearchInfo(new MonSearchInfo());
                IDfSmartListDefinition smartlist = SearchUtil
                        .loadSmartListDefinition(strQuery, getSearchInfo().getSearchService());
                getSearchInfo().setSmartListDefinition(smartlist);
                getSearchInfo().setObjectId(strQuery);
                IDfId idSavedSearchObject = new DfId(strQuery);
                String strDocbase = DocbaseUtils.getDocbaseNameFromId(idSavedSearchObject);
                session = SessionManagerHttpBinding.getSessionManager().getSession(strDocbase);
                IDfSysObject obj = (IDfSysObject) session.getObject(idSavedSearchObject);
                getSearchInfo().setQueryDescription(obj.getString("title"));
            } else if (strQueryType != null && strQueryType.equals("querydef")) {
                IDfSmartListDefinition smartlist = SearchUtil.getSmartListDefinition(strQuery);
                getSearchInfo().setSmartListDefinition(smartlist);
                if (getSearchInfo().getQueryDescription() == null || getSearchInfo().getObjectId() == null)
                    getSearchInfo().setQueryDescription(getQueryDescription());
            } else if (strQueryType == null || !strQueryType.equals("queryId"))
                buildQueryFromKeywords(strQuery);
            else if (getSearchInfo().getQueryDescription() == null || getSearchInfo().getObjectId() == null)
                getSearchInfo().setQueryDescription(getQueryDescription());
        }
        catch (DfException e) {
            throw new WrapperRuntimeException(e);
        }
        catch (Exception e) {
            throw new WrapperRuntimeException(e);
        }
        finally {
            if (session != null)
                SessionManagerHttpBinding.getSessionManager().release(session);
        }
    }
}
