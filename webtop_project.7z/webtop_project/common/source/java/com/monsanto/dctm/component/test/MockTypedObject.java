/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.component.test;

import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.IDfSessionManager;
import com.documentum.fc.client.IDfTypedObject;
import com.documentum.fc.common.*;

import java.util.*;

/**
 * Filename:    $RCSfile: MockTypedObject.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: lakench $ On:	$Date:
 * 2007/03/30 20:58:38 $
 *
 * @author LAKENCH
 * @version $Revision: 1.4 $
 */
public class MockTypedObject implements IDfTypedObject {
  private Map attributes = new HashMap();
  private IDfSessionManager sessionManager;
  private IDfSession session;

  public IDfSession getSession() {
    return session;
  }

  public void setSession(IDfSession session) {
    this.session = session;
  }

  public IDfId getObjectId() throws DfException {
    return new DfId(getString("r_object_id"));
  }

  public void appendBoolean(String string, boolean b) throws DfException {
  }

  public void appendDouble(String string, double v) throws DfException {
  }

  public void appendId(String string, IDfId iDfId) throws DfException {
  }

  public void appendInt(String string, int i) throws DfException {
  }

  public void appendString(String attrName, String value) throws DfException {
    if (!attributes.containsKey(attrName))
      attributes.put(attrName, new ArrayList());
    ((List) attributes.get(attrName)).add(value);
  }

  public void appendTime(String string, IDfTime iDfTime) throws DfException {
  }

  public void appendValue(String string, IDfValue iDfValue) throws DfException {
  }

  public boolean getBoolean(String string) throws DfException {
    return false;
  }

  public double getDouble(String string) throws DfException {
    return 0;
  }

  public IDfId getId(String attrName) throws DfException {
    return getRepeatingId(attrName, 0);
  }

  public int getInt(String string) throws DfException {
    return 0;
  }

  public String getString(String string) throws DfException {
    return getRepeatingString(string, 0);
  }

  public IDfTime getTime(String string) throws DfException {
    return null;
  }

  public IDfValue getValue(String string) throws DfException {
    return null;
  }

  public boolean getRepeatingBoolean(String string, int i) throws DfException {
    return false;
  }

  public double getRepeatingDouble(String string, int i) throws DfException {
    return 0;
  }

  public IDfId getRepeatingId(String string, int i) throws DfException {
    if (attributes.containsKey(string)) {
      Object value = ((List) attributes.get(string)).get(i);
      return new DfId((String) value);
    } else {
      throw new DfException("attribute, \"" + string + "\" not found");
    }
  }

  public int getRepeatingInt(String string, int i) throws DfException {
    return 0;
  }

  public String getRepeatingString(String string, int i) throws DfException {
    if (attributes.containsKey(string)) {
      Object value = ((List) attributes.get(string)).get(i);
      return (String) value;
    } else {
      throw new DfException("attribute, \"" + string + "\" not found");
    }
  }

  public IDfTime getRepeatingTime(String string, int i) throws DfException {
    return null;
  }

  public IDfValue getRepeatingValue(String string, int i) throws DfException {
    return null;
  }

  public String getAllRepeatingStrings(String attrName, String separator) throws DfException {
    String values = "";
    if (attributes.containsKey(attrName)) {
      separator = separator != null ? separator : ",";
      Iterator valuesIterator = ((List) attributes.get(attrName)).iterator();
      if (valuesIterator.hasNext()) {
        values = (String) valuesIterator.next();
      }
      while (valuesIterator.hasNext()) {
        values += separator + (String) valuesIterator.next();
      }

    }
    return values;
  }

  public void insertBoolean(String string, int i, boolean b) throws DfException {
  }

  public void insertDouble(String string, int i, double v) throws DfException {
  }

  public void insertId(String string, int i, IDfId iDfId) throws DfException {
  }

  public void insertInt(String string, int i, int i1) throws DfException {
  }

  public void insertString(String string, int i, String string1) throws DfException {
  }

  public void insertTime(String string, int i, IDfTime iDfTime) throws DfException {
  }

  public void insertValue(String string, int i, IDfValue iDfValue) throws DfException {
  }

  public int findBoolean(String string, boolean b) throws DfException {
    return 0;
  }

  public int findDouble(String string, double v) throws DfException {
    return 0;
  }

  public int findId(String string, IDfId iDfId) throws DfException {
    return 0;
  }

  public int findInt(String string, int i) throws DfException {
    return 0;
  }

  public int findString(String string, String string1) throws DfException {
    return 0;
  }

  public int findTime(String string, IDfTime iDfTime) throws DfException {
    return 0;
  }

  public int findValue(String string, IDfValue iDfValue) throws DfException {
    return 0;
  }

  public void setBoolean(String string, boolean b) throws DfException {
  }

  public void setDouble(String string, double v) throws DfException {
  }

  public void setId(String string, IDfId iDfId) throws DfException {
  }

  public void setInt(String string, int i) throws DfException {
  }

  public void setString(String attrName, String value) throws DfException {
    setRepeatingString(attrName, 0, value);
  }

  public void setTime(String string, IDfTime iDfTime) throws DfException {
  }

  public void setValue(String string, IDfValue iDfValue) throws DfException {
  }

  public void setRepeatingBoolean(String string, int i, boolean b) throws DfException {
  }

  public void setRepeatingDouble(String string, int i, double v) throws DfException {
  }

  public void setRepeatingId(String string, int i, IDfId iDfId) throws DfException {
  }

  public void setRepeatingInt(String string, int i, int i1) throws DfException {
  }

  public void setRepeatingStrings(String attrName, List values) {
    if (!attributes.containsKey(attrName))
      attributes.put(attrName, new ArrayList(values.size()));
    ((List) attributes.get(attrName)).addAll(values);
  }

  public void setRepeatingString(String attrName, int i, String value) throws DfException {
    if (!attributes.containsKey(attrName))
      attributes.put(attrName, new ArrayList());
    ((List) attributes.get(attrName)).add(i, value);
  }

  public void setRepeatingTime(String string, int i, IDfTime iDfTime) throws DfException {
  }

  public void setRepeatingValue(String string, int i, IDfValue iDfValue) throws DfException {
  }

  public int getValueCount(String string) throws DfException {
    if (attributes.containsKey(string)) return ((List) attributes.get(string)).size();
    else return 0;
  }

  public String dump() throws DfException {
    return null;
  }

  public Enumeration enumAttrs() throws DfException {
    return null;
  }

  public int findAttrIndex(String string) throws DfException {
    return 0;
  }

  public IDfAttr getAttr(int i) throws DfException {
    return null;
  }

  public int getAttrCount() throws DfException {
    return 0;
  }

  public int getAttrDataType(String string) throws DfException {
    return 0;
  }

  public boolean hasAttr(String string) throws DfException {
    return false;
  }

  public boolean isAttrRepeating(String string) throws DfException {
    return getValueCount(string) > 1;
  }

  public void remove(String string, int i) throws DfException {
  }

  public void removeAll(String string) throws DfException {
    if (attributes.containsKey(string)) {
      ((List) attributes.get(string)).clear();
    }
  }

  public void truncate(String string, int i) throws DfException {
  }

  public boolean isNull(String string) throws DfException {
    return false;
  }

  public void setNull(String string) throws DfException {
  }

  public IDfValue getValueAt(int i) throws DfException {
    return null;
  }

  public void setSessionManager(IDfSessionManager sessionManager) throws DfException {
    this.sessionManager = sessionManager;
  }

  public IDfSessionManager getSessionManager() {
    return sessionManager;
  }

  public long getLong(String string) throws DfException {
    return 0;
  }

  public long getRepeatingLong(String string, int i) throws DfException {
    return 0;
  }
}