package com.monsanto.dctm.sendlocator;

import javax.servlet.http.HttpServletRequest;

public class SendLocator extends
		com.documentum.webcomponent.library.sendlocator.SendLocator {

	protected String getCompleteUrl(String strPartialUrl)
    {
        return "http://viewdocumentum.monsanto.com:8080" + strPartialUrl;
    }

}
