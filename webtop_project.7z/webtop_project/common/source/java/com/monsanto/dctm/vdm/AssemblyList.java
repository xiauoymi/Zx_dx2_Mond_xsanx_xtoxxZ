package com.monsanto.dctm.vdm;

import com.monsanto.dctm.monAppContext.MonAppContextService;

public class AssemblyList extends
                          com.documentum.webtop.webcomponent.vdm.AssemblyList {

    protected String getColumnsPreferenceId() {
        return super.getColumnsPreferenceId() + "." +
               MonAppContextService.getMonAppContextService().getMonAppContextInternalName();
    }

}
