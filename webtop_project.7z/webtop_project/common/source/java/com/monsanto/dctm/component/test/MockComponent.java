/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.component.test;

import com.documentum.fc.client.DfServiceException;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.IDfSessionManager;
import com.documentum.web.formext.component.Component;

/**
 * Filename:    $RCSfile: MockComponent.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: lakench $    	 On:	$Date: 2007-05-12 05:29:56 $
 *
 * @author lakench
 * @version $Revision: 1.4 $
 */
public class MockComponent extends Component implements IMonTestableComponent {
    private IDfSessionManager sessionManager;
    private String componentPage;
    public boolean wentToNextPage;
    public boolean wentToPrevPage;
    public boolean committedChanges;
    public boolean cancelledChanges;
    public boolean triedToGoToNextPage;
    public boolean triedToGoToPrevPage;
    public boolean triedToCommitChanges;
    public boolean triedToCancelChanges;
    private boolean hasNextPage = super.hasNextPage();
    private boolean hasPrevPage = super.hasPrevPage();
    private boolean canCommitChanges = super.canCommitChanges();
    private boolean canCancelChanges = super.canCancelChanges();
    public boolean isValid;
    public boolean triedToValidate;
    private boolean shouldValidate;

    public void setSessionManager(IDfSessionManager sessionManager) {
        this.sessionManager = sessionManager;
    }

    public IDfSessionManager getSessionManager() {
        return sessionManager;
    }

    public IDfSession getDfSession() {
        try {
            return sessionManager.getSession(getCurrentDocbase());
        } catch (DfServiceException e) {
            e.printStackTrace();
        }
        return null;
    }

    public void setComponentPage(String componentPage) {
        this.componentPage = componentPage;
    }

    public String getComponentPage() {
        return componentPage;
    }

    public void setHasNextPage(boolean hasNextPage) {
        this.hasNextPage = hasNextPage;
    }

    public boolean hasNextPage() {
        return hasNextPage;
    }

    public boolean onNextPage() {
        triedToGoToNextPage = true;
        wentToNextPage = hasNextPage;
        return wentToNextPage;
    }

    public void setHasPrevPage(boolean hasPrevPage) {
        this.hasPrevPage = hasPrevPage;
    }

    public boolean hasPrevPage() {
        return hasPrevPage;
    }

    public boolean onPrevPage() {
        triedToGoToPrevPage = true;
        wentToPrevPage = hasPrevPage;
        return wentToPrevPage;
    }

    public void setCanCommitChanges(boolean canCommitChanges) {
        this.canCommitChanges = canCommitChanges;
    }

    public boolean canCommitChanges() {
        return canCommitChanges;
    }

    public boolean onCommitChanges() {
        triedToCommitChanges = true;
        committedChanges = canCommitChanges;
        return committedChanges;
    }

    public void setCanCancelChanges(boolean canCancelChanges) {
        this.canCancelChanges = canCancelChanges;
    }

    public boolean canCancelChanges() {
        return canCancelChanges;
    }

    public boolean onCancelChanges() {
        triedToCancelChanges = true;
        cancelledChanges = canCancelChanges;
        return cancelledChanges;
    }

    public void setShouldValidate(boolean shouldValidate) {
        this.shouldValidate = shouldValidate;
    }

    public void validate() {
        triedToValidate = true;
        isValid = shouldValidate;
        super.validate();
    }

    public boolean getIsValid() {
        return isValid;
    }

}