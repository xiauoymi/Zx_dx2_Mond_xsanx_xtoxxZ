/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.usermtn.test;

import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.MockSession;
import com.documentum.fc.common.DfException;
import com.documentum.web.common.WrapperRuntimeException;
import com.documentum.web.form.ComponentTestUtils;
import com.documentum.web.formext.action.IActionPrecondition;
import com.documentum.web.formext.component.Component;
import com.monsanto.dctm.component.test.MockComponent;
import com.monsanto.dctm.component.test.MockDfGroup;
import com.monsanto.dctm.component.test.MockSessionManager;
import com.monsanto.dctm.usermtn.CreateUsersTextFileActionPrecondition;
import junit.framework.TestCase;

import java.util.Arrays;

/**
 * Filename:    $RCSfile: CreateUsersTextFileActionPrecondition_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author:
 * lakench $    	 On:	$Date: 2007-10-26 18:47:58 $
 *
 * @author lakench
 * @version $Revision: 1.3 $
 */
public class CreateUsersTextFileActionPrecondition_UT extends TestCase {
  public void testCreate() throws Exception {
    CreateUsersTextFileActionPrecondition precondition = new CreateUsersTextFileActionPrecondition();
    assertTrue(precondition instanceof IActionPrecondition);
  }

  public void testUserInGroupMembershipCache() throws Exception {

    ComponentTestUtils.setupConfigService();
    MockSessionManager dfSessionManager = new MockSessionManager();
    MockSession session = new MockSession();
    dfSessionManager.setSession(session);
    MockUserInGroupMembershipCache mock = new MockUserInGroupMembershipCache();
    Component component = ComponentTestUtils
        .getComponent(MockComponent.class, "testcomponent", "testdocbase", dfSessionManager);
    assertTrue(mock.queryExecute("action", null, null, null, component));
    assertEquals("authorized_requestors", mock.group);
    ComponentTestUtils.releaseComponent(component);
  }

  public void testUserGroupDoesntExist() throws Exception {

    ComponentTestUtils.setupConfigService();
    MockSessionManager dfSessionManager = new MockSessionManager();
    MockSession session = new MockSession();
    dfSessionManager.setSession(session);
    MockUserNotInGroupMembershipCache mock = new MockUserNotInGroupMembershipCache();
    Component component = ComponentTestUtils
        .getComponent(MockComponent.class, "testcomponent", "testdocbase", dfSessionManager);
    assertFalse(mock.queryExecute("action", null, null, null, component));
    assertEquals("authorized_requestors", mock.group);
    ComponentTestUtils.releaseComponent(component);
  }

  public void testUserNotInCacheButInGroup() throws Exception {
    ComponentTestUtils.setupConfigService();
    MockSessionManager dfSessionManager = new MockSessionManager();
    MockSession session = new MockSession();
    session.setLoginUserName("testuser");
    MockDfGroup group = new MockDfGroup();
    group.setGroupName("authorized_requestors");
    group.setAllUsersNames(Arrays.asList(new String[]{"testuser"}));
    session.addGroup(group);
    dfSessionManager.setSession(session);
    MockUserNotInGroupMembershipCache mock = new MockUserNotInGroupMembershipCache();
    Component component = ComponentTestUtils
        .getComponent(MockComponent.class, "testcomponent", "testdocbase", dfSessionManager);
    assertTrue(mock.queryExecute("action", null, null, null, component));
    assertEquals("authorized_requestors", mock.group);
    ComponentTestUtils.releaseComponent(component);
  }

  public void testUserNotInCacheOrInGroup() throws Exception {
    ComponentTestUtils.setupConfigService();
    MockSessionManager dfSessionManager = new MockSessionManager();
    MockSession session = new MockSession();
    session.setLoginUserName("testuser");
    MockDfGroup group = new MockDfGroup();
    group.setGroupName("authorized_requestors");
    session.addGroup(group);
    dfSessionManager.setSession(session);
    MockUserNotInGroupMembershipCache mock = new MockUserNotInGroupMembershipCache();
    Component component = ComponentTestUtils
        .getComponent(MockComponent.class, "testcomponent", "testdocbase", dfSessionManager);
    assertFalse(mock.queryExecute("action", null, null, null, component));
    assertEquals("authorized_requestors", mock.group);
    ComponentTestUtils.releaseComponent(component);
  }

  public void testMoreThanOnePersonInGroupObject() throws Exception {
    ComponentTestUtils.setupConfigService();
    MockSessionManager dfSessionManager = new MockSessionManager();
    MockSession session = new MockSession();
    session.setLoginUserName("testuser");
    MockDfGroup group = new MockDfGroup();
    group.setGroupName("authorized_requestors");
    group.setAllUsersNames(Arrays.asList(new String[]{"testuser", "Joe Miner"}));
    session.addGroup(group);
    dfSessionManager.setSession(session);
    MockUserNotInGroupMembershipCache mock = new MockUserNotInGroupMembershipCache();
    Component component = ComponentTestUtils
        .getComponent(MockComponent.class, "testcomponent", "testdocbase", dfSessionManager);
    assertTrue(mock.queryExecute("action", null, null, null, component));
    assertEquals("authorized_requestors", mock.group);
    ComponentTestUtils.releaseComponent(component);
  }

  public void testIsUserInGroupThrowsException() throws Exception {
    MockUserInGroupThrowsException mock = new MockUserInGroupThrowsException();
    MockSessionManager dfSessionManager = new MockSessionManager();
    Component component = ComponentTestUtils
        .getComponent(MockComponent.class, "testcomponent", "testdocbase", dfSessionManager);
    try {
      mock.queryExecute("action", null, null, null, component);
    } catch (WrapperRuntimeException e) {
      //expected path
      return;
    } finally {
      ComponentTestUtils.releaseComponent(component);
    }
  }

  public void testRequiredParamsIsEmpty() throws Exception {
    assertEquals(0, new CreateUsersTextFileActionPrecondition().getRequiredParams().length);
  }

  public class MockUserInGroupThrowsException extends MockCreateUsersTextFileActionPrecondition {
    /**
     * @noinspection RefusedBequest
     */
    protected boolean isUserInGroup(String groupName, IDfSession session) throws DfException {
      throw new DfException("test exception");
    }
  }

  public class MockUserInGroupMembershipCache extends MockCreateUsersTextFileActionPrecondition {
    /**
     * @noinspection RefusedBequest
     */
    protected boolean isUserInGroupFromCache(String groupName, String loginUserName, String docbaseName) {
      return true;
    }
  }

  public class MockUserNotInGroupMembershipCache extends MockCreateUsersTextFileActionPrecondition {
    /**
     * @noinspection RefusedBequest
     */
    protected boolean isUserInGroupFromCache(String groupName, String loginUserName, String docbaseName) {
      return false;
    }
  }
}