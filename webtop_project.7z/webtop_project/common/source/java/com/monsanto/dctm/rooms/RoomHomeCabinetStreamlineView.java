package com.monsanto.dctm.rooms;

import com.monsanto.dctm.monAppContext.MonAppContextService;

public class RoomHomeCabinetStreamlineView extends
                                           com.documentum.webtop.webcomponent.rooms.RoomHomeCabinetStreamlineView {

    protected String getColumnsPreferenceId() {
        return super.getColumnsPreferenceId() + "." +
               MonAppContextService.getMonAppContextService().getMonAppContextInternalName();
    }

}
