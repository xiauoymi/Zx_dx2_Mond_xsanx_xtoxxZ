/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.action.test;

import com.documentum.fc.client.IDfSessionManager;
import com.documentum.fc.client.MockSession;
import com.documentum.web.common.ArgumentList;
import com.documentum.web.form.ComponentTestUtils;
import com.documentum.web.form.Form;
import com.documentum.web.form.IReturnListener;
import com.documentum.web.formext.action.ActionService;
import com.documentum.web.formext.action.IActionCompleteListener;
import com.documentum.web.formext.component.Component;
import com.documentum.web.formext.config.ConfigElement;
import com.documentum.web.formext.config.Context;
import com.documentum.web.formext.config.IConfigElement;
import com.documentum.web.formext.config.PreferenceService;
import com.documentum.webtop.webcomponent.drl.DRLSysObjectViewAction;
import com.monsanto.dctm.action.DRLViewOnlySysObjectViewAction;
import com.monsanto.dctm.component.test.MockReturnListener;
import com.monsanto.dctm.component.test.MockSessionManager;
import com.monsanto.dctm.component.test.MockSysObject;
import com.monsanto.dctm.dctmSession.Session;
import com.monsanto.dctm.dctmSession.test.MockDctmSession;
import com.monsanto.dctm.drl.test.MockDRLViewOnlyComponent;
import junit.framework.TestCase;

import java.util.HashMap;
import java.util.Map;

/**
 * Filename:    $RCSfile: DRLViewOnlySysObjectViewAction_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author:
 * lakench $    	 On:	$Date: 2007-10-26 18:47:58 $
 *
 * @author lakench
 * @version $Revision: 1.2 $
 */
public class DRLViewOnlySysObjectViewAction_UT extends TestCase {
  public static final String TESTOBJECTID = "0900000000000000";

  private class ReturnListener implements IReturnListener {

    private String m_strAction;
    private IActionCompleteListener m_completeListener;

    public void onReturn(Form form, Map map) {
      boolean fSuccess = true;
      if (map != null) {
        String strSuccess = (String) map.get("success");
        if (strSuccess != null && strSuccess.equalsIgnoreCase("false"))
          fSuccess = false;
      }
      m_completeListener.onComplete(m_strAction, fSuccess, map);
    }

    public boolean isEquivalentListener(String strAction, IActionCompleteListener completeListener) {
      boolean isEquivalent = false;
      if (strAction.equals(m_strAction) && completeListener != null && completeListener.equals(m_completeListener))
        isEquivalent = true;
      return isEquivalent;
    }

    public ReturnListener(String strAction, IActionCompleteListener completeListener) {
      m_completeListener = null;
      m_strAction = strAction;
      m_completeListener = completeListener;
    }
  }

  public void testCreate() throws Exception {
    DRLViewOnlySysObjectViewAction action = new DRLViewOnlySysObjectViewAction();
    assertNotNull(action);
    assertTrue(action instanceof DRLSysObjectViewAction);
  }

  public void testExecute() throws Exception {

    MockSessionManager dfSessionManager = new MockSessionManager();
    MockSession session = new MockSession(dfSessionManager);
    MockSysObject object = new MockSysObject();
    session.addObject(object, TESTOBJECTID);
    object.setString("r_object_id", TESTOBJECTID);
    object.setString("object_name", "testobjectname");
    object.addRendition("testpdfrendition", "pdf");
    object.setPermit(3);
    dfSessionManager.setSession(session);
    MockDRLViewOnlySysObjectViewAction mockDRLViewOnlySysObjectViewAction = new MockDRLViewOnlySysObjectViewAction(
        dfSessionManager);
    ArgumentList args = new ArgumentList();
    args.add("objectId", TESTOBJECTID);
    args.add("contentType", "msw8");
    args.add("contentSize", "100");
    args.add("type", "dm_document");

    Component component = ComponentTestUtils
        .getComponent(MockDRLViewOnlyComponent.class, "mockcomponent", "testdocbase", dfSessionManager);
    PreferenceService.getPreferenceStore().writeString("contentXferMechanism", "ucf");
    component.getTopForm().getFormResponse().setRedirectPageUrl("testurl");
    System.out.println("component.getTopForm().getFormResponse().getRedirectUrl() = " +
        component.getTopForm().getFormResponse().getRedirectUrl());
    ComponentTestUtils.setReturnListener(component, new MockReturnListener());

    HashMap completionArgs = new HashMap();
    completionArgs.put(ActionService.COMPLETE_LISTENER, component);
    Context context = new Context();
    boolean result = mockDRLViewOnlySysObjectViewAction
        .execute("drlview", new ConfigElement("actionid", "drlview"), args, context, component, completionArgs);

    assertTrue(result);
    assertEquals("view", mockDRLViewOnlySysObjectViewAction.actionId);
    assertEquals(args, mockDRLViewOnlySysObjectViewAction.args);
    assertNotSame(context, mockDRLViewOnlySysObjectViewAction.context);
    assertEquals("REQUEST(application=webcomponent)SESSION()APP()",
        mockDRLViewOnlySysObjectViewAction.context.toString());
    assertEquals(component, mockDRLViewOnlySysObjectViewAction.component);
//    assertEquals(component, mockDRLViewOnlySysObjectViewAction.completionArgs);
    System.out.println(
        "mockDRLViewOnlySysObjectViewAction.completionArgs = " + mockDRLViewOnlySysObjectViewAction.completionArgs);
    IReturnListener returnListener = component.getTopForm().getFormResponse().getReturnListener();
    System.out.println("returnListener = " + returnListener);
    ComponentTestUtils.releaseComponent(component);
    ComponentTestUtils.releasePreferenceService();
    ComponentTestUtils.releaseConfigService();
  }

  class MockDRLViewOnlySysObjectViewAction extends DRLViewOnlySysObjectViewAction {
    private String actionId;
    public ArgumentList args;
    private Context context;
    private Component component;
    private Map completionArgs;
    private IDfSessionManager dfSessionManager;

    public MockDRLViewOnlySysObjectViewAction(IDfSessionManager dfSessionManager) {
      this.dfSessionManager = dfSessionManager;
    }

    /**
     * @noinspection RefusedBequest
     */
    protected Session createSession() {
      return new MockDctmSession(dfSessionManager, "testdocbase");
    }

    protected boolean runAction(String actionId, IConfigElement config, ArgumentList args, Context context,
                                Component component,
                                Map completionArgs) {
      this.actionId = actionId;
      this.args = args;
      this.context = context;
      this.component = component;
      this.completionArgs = completionArgs;

      context = new Context(context);
      context.set("application", "test");

      return super.runAction("view", config, args, context, component, completionArgs);
    }
  }
}