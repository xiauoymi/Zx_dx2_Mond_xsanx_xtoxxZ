/*
 * Created on Sep 3, 2005
 *
 */
package com.monsanto.dctm.monAppContext;

import com.documentum.fc.common.DfLogger;
import com.documentum.web.common.ArgumentList;
import com.documentum.web.common.WrapperRuntimeException;
import com.documentum.web.form.control.Label;
import com.documentum.web.form.control.databound.ArrayResultSet;
import com.documentum.web.form.control.databound.DataDropDownList;

import java.net.InetAddress;
import java.net.UnknownHostException;

/**
 * @author LAKENCH
 */
public class TitleBar extends com.documentum.webtop.webcomponent.titlebar.TitleBar {
  public static final String CONTROL_MON_APP_CONTEXT = "mon_app_context";
  public static final String SUPPORT_OUTAGE_LABEL = "outage";
  public static final String SUPPORT_MESSAGE_LABEL = "user_message";
  public static final String APP_SERVER_LABEL = "appserverlabel";
  public static final String APP_SERVER_NAME = "appservername";

  public void onInit(ArgumentList args) {
    super.onInit(args);
    initMonAppContextControl();
    try {
      initappServername();
    } catch (UnknownHostException e) {
      throw new WrapperRuntimeException("error setting appservername label", e);
    }
  }

  private void initappServername() throws UnknownHostException {
    Label appservernamecontrol = (Label) getControl(APP_SERVER_NAME, Label.class);
    InetAddress localHost = InetAddress.getLocalHost();
    String hostname = localHost.getHostName();
    DfLogger.info(this, "hostname = " + hostname, null, null);
    appservernamecontrol.setLabel(hostname);
  }

  protected void initMonAppContextControl() {
    DataDropDownList dropDownList = ((DataDropDownList) getControl(CONTROL_MON_APP_CONTEXT, DataDropDownList.class));
    IMonAppContextService monAppContextService = getMonAppContextService();
    ArrayResultSet arrMonAppContexts = new ArrayResultSet(monAppContextService.getSupportedMonAppContexts(),
        "mon_app_context");
    dropDownList.getDataProvider().setScrollableResultSet(arrMonAppContexts);
    ((DataDropDownList) getControl(CONTROL_MON_APP_CONTEXT, DataDropDownList.class))
        .setValue(monAppContextService.getCurrentMonAppContextName());
  }

  protected IMonAppContextService getMonAppContextService() {
    return MonAppContextService.getMonAppContextService();
  }

  public void onSelectMonAppContext(DataDropDownList monAppContext, ArgumentList arg) {
    IMonAppContextService monAppContextService = getMonAppContextService();
    monAppContextService.setMonAppContext(monAppContext.getValue());
    setClientEvent("refreshViewWindow", null);
  }
}
