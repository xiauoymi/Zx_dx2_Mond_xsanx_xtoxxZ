package com.monsanto.dctm.search;

import com.documentum.fc.client.search.DfSearchException;
import com.documentum.fc.client.search.impl.DfDocExprStatus;
import com.documentum.fc.client.search.impl.DfSimpleAttrExpression;
import com.documentum.fc.client.search.impl.FullTextSettings;
import org.w3c.dom.Node;

public class MonSimpleAttrExpression extends DfSimpleAttrExpression {

  public MonSimpleAttrExpression(Node node) throws DfSearchException {
    super(node);
  }

  public MonSimpleAttrExpression(String dateFormat, String attrName, int valueDataType, int searchOpCode,
                                 boolean isCaseSensitive, boolean isRepeated, String value) {
    super(dateFormat, attrName, valueDataType, searchOpCode, isCaseSensitive, isRepeated, value);
  }

  protected void appendAttrName(StringBuffer attrExprBuffer, boolean ftDQLEnabled) {
    if (isRepeated())
      attrExprBuffer.append("ANY ");
    if (!ftDQLEnabled) attrExprBuffer.append('(');
    switch (getValueDataType()) {
      case 0: // '\0'
      case 1: // '\001'
      case 4: // '\004'
      case 5: // '\005'
        attrExprBuffer.append(getAttrName());
        break;

      case 2: // '\002'
      case 3: // '\003'
      default:
        if (ftDQLEnabled)
          attrExprBuffer.append(getAttrName());
        else if (isCaseSensitive()) {
          attrExprBuffer.append(getAttrName());
        } else {
          attrExprBuffer.append("UPPER(");
          attrExprBuffer.append(getAttrName());
          attrExprBuffer.append(")");
        }
        break;
    }
  }

  public DfDocExprStatus getDocbaseExpression(boolean root, FullTextSettings fullTextSettings)
      throws DfSearchException {
    if (fullTextSettings.isFTDQLEnabled()) {
      return super.getDocbaseExpression(root, fullTextSettings);
    } else {
      return new DfDocExprStatus(super.getDocbaseExpression(root, fullTextSettings).getAttrExpression() + ")", null);
    }
  }
}
