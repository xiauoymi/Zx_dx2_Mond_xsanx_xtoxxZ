/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.appconfig;

import java.util.*;

/**
 * Filename:    $RCSfile: AppConfigItem.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: lakench $    	 On:	$Date: 2007-08-21 05:23:14 $
 *
 * @author lakench
 * @version $Revision: 1.1 $
 */
public class AppConfigItem {
  private String itemType;
  private Map values = new HashMap();

  public boolean equals(Object obj) {
    if (!(obj instanceof AppConfigItem)) return false;
    boolean equals = true;
    equals &= itemType.equals(((AppConfigItem) obj).getItemType());
    equals &= values.keySet().equals(((AppConfigItem) obj).getColumnNames());
    Iterator valueNames = values.keySet().iterator();
    while (valueNames.hasNext()) {
      Object valueName = valueNames.next();
      equals &= get((String) valueName).equals(((AppConfigItem) obj).get((String) valueName));
    }
    return equals;
  }

  public int hashCode() {
    int hashCode = 0;
    hashCode += itemType.hashCode();
    hashCode += values.hashCode();
    return hashCode;
  }

  public String toString() {
    return "type: " + itemType + " / values: " + values.toString();
  }

  public AppConfigItem(String itemType) {
    this.itemType = itemType;
  }

  public AppConfigItem(String itemType, Map values) {
    this.itemType = itemType;
    this.values = values;
  }

  public String getItemType() {
    return itemType;
  }

  public String get(String columnName) {
    return (String) values.get(columnName);
  }

  public void set(String columnName, String value) {
    values.put(columnName, value);
  }

  public List getValues(List columnNames) {
    List returnValues = new ArrayList(columnNames.size());
    Iterator columns = columnNames.iterator();
    while (columns.hasNext()) {
      String columnName = (String) columns.next();
      returnValues.add(values.get(columnName));
    }
    return returnValues;
  }

  public Set getColumnNames() {
    return values.keySet();
  }
}