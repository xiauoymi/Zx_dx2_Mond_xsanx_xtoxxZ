package com.monsanto.dctm.search;

import com.documentum.fc.client.IDfSessionManager;
import com.documentum.fc.client.search.IDfSearchService;
import com.documentum.fc.client.search.impl.DfSearchService;
import com.documentum.web.formext.session.SessionManagerHttpBinding;

public class RepositorySearch extends com.documentum.web.formext.control.docbase.search.RepositorySearch {

  private IDfSearchService m_idfSearchService;

  public IDfSearchService getSearchService() {
    if (m_idfSearchService == null)
      m_idfSearchService = new MonSearchService(new DfSearchService(getSessionManager(),
          SessionManagerHttpBinding.getCurrentDocbase()));
    return m_idfSearchService;
  }

  protected IDfSessionManager getSessionManager() {
    return SessionManagerHttpBinding.getSessionManager();
  }
}
