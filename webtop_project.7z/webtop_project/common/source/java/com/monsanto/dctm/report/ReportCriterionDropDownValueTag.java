/*
 Copyright:  Copyright � 2006 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.report;

import com.documentum.com.DfClientX;
import com.documentum.fc.client.IDfCollection;
import com.documentum.fc.client.IDfQuery;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.common.DfException;
import com.documentum.web.form.control.DropDownList;
import com.documentum.web.form.control.DropDownListTag;
import com.documentum.web.form.control.Option;
import com.documentum.web.formext.session.SessionManagerHttpBinding;

import javax.servlet.jsp.JspTagException;
import javax.servlet.jsp.JspWriter;
import java.io.IOException;
import java.util.ArrayList;

/**
 * Filename:    $RCSfile: ReportCriterionDropDownValueTag.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: tsvedan $    	 On:	$Date: 2006-09-25 16:15:22 $
 *
 * @author tsvedan
 * @version $Revision: 1.1 $
 */
public class ReportCriterionDropDownValueTag extends ReportCriterionValueTag {

  protected void renderValueControl(String name, String value, JspWriter out)
      throws JspTagException, IOException {
    ReportCriterionValue valueControl = (ReportCriterionValue) getControl();
    Criterion valueControlCriterion = valueControl.getCriterion();
    if (valueControlCriterion != null) {
      String queryString = valueControlCriterion.getDropdownquery();
      String ddvalues = valueControlCriterion.getDropdownvalues();
      if (queryString != null && queryString.length() > 0) {
        System.out.println("dropdownquery = " + queryString);
        ArrayList list = execQuery(queryString);
        renderDropDown(value, list);
      } else if (ddvalues != null && ddvalues.length() > 0) {
        System.out.println("dropdownvalues = " + ddvalues);
        ArrayList list = parseDropdownValues(ddvalues);
        renderDropDown(value, list);
      } else renderDropDown(value);
    } else renderDropDown(value);
  }


  private ArrayList parseDropdownValues(String ddvalues) {
    ArrayList list = new ArrayList();
    String [] values = ddvalues.split(",");
    for (int i = 0; i < values.length; i++) {
      String[] pair = new String[]{values[i], values[i]};
      list.add(pair);
    }
    return list;
  }

  private void renderDropDown(String strValue) throws JspTagException {
    ReportCriterionValue reportCriterionValue = (ReportCriterionValue) getControl();
    String strClass = reportCriterionValue.getCssClass();
    String strStyle = reportCriterionValue.getCssStyle();
    DropDownListTag dropdown = new DropDownListTag();
    dropdown.setPageContext(pageContext);
    dropdown.setParent(this);
    dropdown.setName(reportCriterionValue.getElementName("value"));
    dropdown.setId(getId());
    dropdown.setTooltip(reportCriterionValue.getToolTip());
    if (strClass != null)
      dropdown.setCssclass(strClass);
    if (strStyle != null)
      dropdown.setStyle(strStyle);
    dropdown.setValue(strValue);

    dropdown.doStartTag();
    dropdown.doEndTag();
  }

  private void renderDropDown(String strValue, ArrayList list) throws JspTagException {
    ReportCriterionValue reportCriterionValue = (ReportCriterionValue) getControl();
    String strClass = reportCriterionValue.getCssClass();
    String strStyle = reportCriterionValue.getCssStyle();
    DropDownListTag dropdown = new DropDownListTag();
    dropdown.setPageContext(pageContext);
    dropdown.setParent(this);
    dropdown.setName(reportCriterionValue.getElementName("value"));
    dropdown.setId(getId());
    dropdown.setTooltip(reportCriterionValue.getToolTip());
    if (strClass != null)
      dropdown.setCssclass(strClass);
    if (strStyle != null)
      dropdown.setStyle(strStyle);
    renderOptions((DropDownList) dropdown.getControl(), list);
    if (strValue != null && strValue.length() > 0)
      dropdown.setValue(strValue);
    else
      dropdown.setValue("");
    dropdown.doStartTag();
    dropdown.doEndTag();
  }

  private void renderOptions(DropDownList dropdown, ArrayList list) {
    if (dropdown.isMutable()) {
      Option option = new Option();
      option.setValue("");
      option.setLabel("");
      dropdown.addOption(option);
      for (int i = 0; i < list.size(); i++) {
        String[] values = (String[]) list.get(i);
        option = new Option();
        option.setValue(values[0]);
        option.setLabel(values[1]);
        dropdown.addOption(option);
      }
    }
  }

  private ArrayList execQuery(String strQuery) {
    IDfQuery query = new DfClientX().getQuery();
    ArrayList list = new ArrayList();
    String[] values = null;
    IDfSession session = null;
    query.setDQL(strQuery);
    try {
      session = getDfSession();
      IDfCollection coll = query.execute(session, IDfQuery.DF_QUERY);
      while (coll.next()) {
        if (coll.getAttrCount() > 1)
          values = new String[]{coll.getString("ddvalue"), coll.getString("ddlabel")};
        else
          values = new String[]{coll.getString("ddvalue"), coll.getString("ddvalue")};
        list.add(values);
      }
      coll.close();
    } catch (DfException e) {
      e.printStackTrace();
    } finally {
      SessionManagerHttpBinding.getSessionManager().release(session);
    }
    return list;
  }

  private IDfSession getDfSession() throws DfException {
    return SessionManagerHttpBinding.getSessionManager().getSession(
        SessionManagerHttpBinding.getCurrentDocbase());
  }

}