package com.monsanto.dctm.menubar;

import com.documentum.web.common.ArgumentList;

public class MenuBar extends com.documentum.webtop.webcomponent.menubar.MenuBar 
{

	public void onInit(ArgumentList args) {
		getControl("bookmark", com.monsanto.dctm.viewprocessor.BookmarkLink.class);
		super.onInit(args);
	}

}
