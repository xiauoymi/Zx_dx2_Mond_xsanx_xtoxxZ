package com.monsanto.dctm.report;

import java.util.Date;
import java.util.Map;

import com.documentum.web.common.ArgumentList;
import com.documentum.web.form.Control;
import com.documentum.web.form.Form;
import com.documentum.web.form.IReturnListener;
import com.documentum.web.form.control.BooleanInputControl;
import com.documentum.web.form.control.DateInput;
import com.documentum.web.form.control.DateTime;
import com.documentum.web.form.control.Label;
import com.documentum.web.form.control.Link;
import com.documentum.web.form.control.StringInputControl;
import com.documentum.web.formext.component.Component;
import com.documentum.webcomponent.library.locator.LocatorItemResultSet;

public class ReportCriterionValue extends StringInputControl implements IReturnListener {
	
	private String criteria;
	private Criterion criterion;
	private String displayvalue;
	private String value;
	
	public ReportCriterionValue() {
		criterion = null;
		displayvalue = null;
		criteria = null;
		value = null;
	}
	
	public Criterion getCriterion() {
		return criterion;
	}
	
	public void setCriterion(Criterion criterion) {
		this.criterion = criterion;
	}
	
	public String getValue() {
		if (value != null)
		{
			return value;
		}
		else
		{
			Control control = null;
			control = getForm().getControl(getElementName("value"));
			if (control != null)
				if (control instanceof BooleanInputControl)
					displayvalue = !((BooleanInputControl)control).getValue() ? "false" : "true";
				else if (control instanceof Label)
				{
					displayvalue = ((Label)control).getLabel();
				} else if (control instanceof DateInput)
				{
					DateInput dateInput = (DateInput)control;
					Date date = dateInput.toDate();
					displayvalue = DateTime.toValue(date);
					if(displayvalue == null)
						displayvalue = "";
				} else if (control instanceof StringInputControl)
				{
					displayvalue = ((StringInputControl)control).getValue();
				}
			if (displayvalue == null)
				displayvalue = super.getValue();
		}
		return displayvalue;
	}
	
	public void setValue(String value) {
		this.displayvalue = value;
	}
	
	public String getCriteria() {
		return criteria;
	}
	
	public void setCriteria(String criteria) {
		this.criteria = criteria;
	}
	
	public void onClickEdit(Link link, ArgumentList arg)
	{
		Form form = getForm();
		if (form instanceof Component)
		{
			Component component = (Component) form;
			ArgumentList myargs = new ArgumentList();
			myargs.add("control", getElementName("value"));
			String componentName = getCriterion().getEditcomponent();
			component.setComponentNested(componentName, myargs, component.getContext(), this);
		}
	}
	
	public void onReturn(Form form, Map map)
	{
		if (map == null)
			return;
		LocatorItemResultSet setLocatorSelections = (LocatorItemResultSet) map.get("_locator_sel");
		if (setLocatorSelections != null && setLocatorSelections.first())
		{
			value = setLocatorSelections.getObject(getLocatorValueProperty()).toString();
			displayvalue = setLocatorSelections.getObject(getLocatorDisplayProperty()).toString();
		}
		Control control = getForm().getControl(getElementName("value"));
		if (control != null)
		{
			if (control instanceof Label)
			{
				((Label) control).setLabel(displayvalue);
			}
		}
	}
	
	protected String getLocatorValueProperty()
	{
		return criterion.getAllconfigelements().getChildValue("propertyfromlocatortostore");
	}
	protected String getLocatorDisplayProperty()
	{
		return criterion.getAllconfigelements().getChildValue("propertyfromlocatortoshow");
	}

	public String getDisplayvalue() {
		return displayvalue;
	}
}
