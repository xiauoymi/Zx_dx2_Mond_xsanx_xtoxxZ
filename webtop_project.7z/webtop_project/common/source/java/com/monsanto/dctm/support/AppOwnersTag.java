/*
 Copyright:  Copyright � 2006 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.support;

import com.documentum.web.form.control.Label;
import com.documentum.web.form.control.LabelTag;

import javax.servlet.jsp.JspWriter;
import java.io.IOException;
import java.util.*;

/**
 * Filename:    $RCSfile: AppOwnersTag.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: lakench $    	 On:	$Date: 2007-01-13 08:44:09 $
 *
 * @author lakench
 * @version $Revision: 1.11 $
 */
public class AppOwnersTag extends LabelTag {

    protected void renderEnd(JspWriter jspWriter) throws IOException {
        Label label = (Label) getControl();
        if (label.isVisible()) renderAppOwners(label, jspWriter);
    }

    protected void renderAppOwners(Label label, JspWriter out) throws IOException {
        StringBuffer buf = generateAppOwnersTableHtml(label);
        out.print(buf.toString());
    }

    protected StringBuffer generateAppOwnersTableHtml(Label label) {
        String cssClass = label.getCssClass();
        String labelText = label.getLabel();
        List rows = getRows(labelText);

        StringBuffer buf = new StringBuffer(labelText.length() + 255);
        buf.append("<table class='");
        buf.append(cssClass);
        buf.append("'>");
        Iterator rowsIterator = rows.iterator();
        buf.append("<tr>");
        while (rowsIterator.hasNext()) {
            String row = (String) rowsIterator.next();
            Map appOwnerData = getAppOwnerData(row);
            if (rowsIterator.hasNext())
                buf.append(
                        "<td class='normal' style='padding: 5px; border-collapse: collapse; border-top: none; border-bottom: none; border-left: none; border-right: 1px solid #000099;'>");
            else
                buf.append("<td class='normal' style='padding: 5px; border-collapse: collapse; border: none'>");
            buf.append("<a href='mailto:");
            buf.append(appOwnerData.get("email"));
            buf.append("'>");
            buf.append(appOwnerData.get("name"));
            buf.append("</a>");
            buf.append("</td>");
        }
        buf.append("</tr>");
        buf.append("</table>");
        return buf;
    }

    private Map getAppOwnerData(String row) {
        String[] cols = row.split("::");
        HashMap appOwnerData = new HashMap(2);
        appOwnerData.put("name", cols[0]);
        appOwnerData.put("email", cols[1]);
        return appOwnerData;
    }

    private List getRows(String textData) {
        String[] rows = textData.split("##");
        return Arrays.asList(rows);
    }

}