/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.search.test;

import com.documentum.fc.client.search.*;
import com.documentum.fc.client.search.impl.*;
import com.monsanto.dctm.component.test.MockSessionManager;
import com.monsanto.dctm.search.MonQueryBuilder;
import com.monsanto.dctm.search.MonQueryManager;
import com.monsanto.dctm.search.MonSmartListDefinition;
import junit.framework.TestCase;

import java.io.ByteArrayInputStream;

/**
 * Filename:    $RCSfile: MonQueryManager_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: lakench $    	 On:	$Date: 2007-10-05 17:50:59 $
 *
 * @author lakench
 * @version $Revision: 1.1 $
 */
public class MonQueryManager_UT extends TestCase {
  public void testCreate() throws Exception {
    MonQueryManager monQueryManager = new MonQueryManager(
        new DfQueryManager(new MockSessionManager(), new DfSearchSourceMap(),
            "defaultMetadataDocbase"));
    assertNotNull(monQueryManager);
    assertTrue(monQueryManager instanceof IDfQueryManager);
  }

  public void testNewQueryBuilder() throws Exception {
    MockSessionManager sessionManager = new MockSessionManager();
    DfSearchSourceMap searchSourceMap = new DfSearchSourceMap();
    MonQueryManager monQueryManager = new MonQueryManager(new DfQueryManager(sessionManager, searchSourceMap,
        "defaultMetadataDocbase"));

    IDfQueryBuilder noArgQueryBuilder = monQueryManager.newQueryBuilder();
    assertNotNull(noArgQueryBuilder);
    assertTrue(noArgQueryBuilder instanceof MonQueryBuilder);
    assertEquals("dm_sysobject", noArgQueryBuilder.getObjectType());
    IDfSearchMetadataManager noArgMetadataMgr = noArgQueryBuilder.getMetadataMgr();
    assertTrue(noArgMetadataMgr instanceof DfSearchMetadataManager);
    assertEquals("defaultMetadataDocbase", noArgMetadataMgr.getMetadataDocbase());
    assertEquals(sessionManager, noArgMetadataMgr.getSessionMgr());
    assertEquals(searchSourceMap, noArgMetadataMgr.getSourceMap());

    IDfQueryBuilder queryBuilder = monQueryManager.newQueryBuilder("testobjecttype");
    assertNotNull(queryBuilder);
    assertTrue(queryBuilder instanceof MonQueryBuilder);
    assertEquals("testobjecttype", queryBuilder.getObjectType());
    IDfSearchMetadataManager metadataMgr = queryBuilder.getMetadataMgr();
    assertTrue(metadataMgr instanceof DfSearchMetadataManager);
    assertEquals("defaultMetadataDocbase", metadataMgr.getMetadataDocbase());
    assertEquals(sessionManager, metadataMgr.getSessionMgr());
    assertEquals(searchSourceMap, metadataMgr.getSourceMap());

  }

  public void testLoadSmartlistDefinition() throws Exception {
    ByteArrayInputStream streamUTF8 = SearchTestUtils.generateQueryBuilderStream();

    MockSessionManager sessionManager = new MockSessionManager();
    DfSearchSourceMap searchSourceMap = new DfSearchSourceMap();
    MonQueryManager monQueryManager = new MonQueryManager(new DfQueryManager(sessionManager, searchSourceMap,
        "defaultMetadataDocbase"));
    IDfSmartListDefinition smartListDefinition = monQueryManager.loadSmartListDefinition(streamUTF8);
    assertTrue(smartListDefinition instanceof MonSmartListDefinition);
    IDfQueryDefinition queryDefinition = smartListDefinition.getQueryDefinition();
    assertTrue(queryDefinition.isQueryBuilder());
    IDfQueryBuilder queryBuilder = (IDfQueryBuilder) queryDefinition;
    assertTrue(queryBuilder instanceof MonQueryBuilder);
    assertEquals("dm_document", queryBuilder.getObjectType());
    IDfSearchMetadataManager metadataMgr = queryDefinition.getMetadataMgr();
    assertTrue(metadataMgr instanceof DfSearchMetadataManager);
    assertEquals("defaultMetadataDocbase", metadataMgr.getMetadataDocbase());
    assertEquals(sessionManager, metadataMgr.getSessionMgr());
    assertEquals(searchSourceMap, metadataMgr.getSourceMap());
  }


  public void testReadQueryBuilderQueryDefinition() throws Exception {
    MockSessionManager sessionManager = new MockSessionManager();
    DfSearchSourceMap searchSourceMap = new DfSearchSourceMap();
    IDfQueryDefinition queryDefinition = MockMonQueryManager.readQueryDefinition(
        new DfSearchMetadataManager(sessionManager, searchSourceMap, "defaultMetadataDocbase"),
        DfXMLUtil.read(SearchTestUtils.generateQueryBuilderStream()));

    assertTrue(queryDefinition.isQueryBuilder());
    IDfQueryBuilder queryBuilder = (IDfQueryBuilder) queryDefinition;
    assertTrue(queryBuilder instanceof MonQueryBuilder);
    assertEquals("dm_document", queryBuilder.getObjectType());
    IDfSearchMetadataManager metadataMgr = queryDefinition.getMetadataMgr();
    assertTrue(metadataMgr instanceof DfSearchMetadataManager);
    assertEquals("defaultMetadataDocbase", metadataMgr.getMetadataDocbase());
    assertEquals(sessionManager, metadataMgr.getSessionMgr());
    assertEquals(searchSourceMap, metadataMgr.getSourceMap());
  }

  public void testReadPassThroughQueryDefinition() throws Exception {
    MockSessionManager sessionManager = new MockSessionManager();
    DfSearchSourceMap searchSourceMap = new DfSearchSourceMap();
    IDfQueryDefinition queryDefinition = MockMonQueryManager.readQueryDefinition(
        new DfSearchMetadataManager(sessionManager, searchSourceMap, "defaultMetadataDocbase"),
        DfXMLUtil.read(SearchTestUtils.generatePassThroughStream()));

    assertFalse(queryDefinition.isQueryBuilder());
    IDfPassThroughQuery passThroughQuery = (IDfPassThroughQuery) queryDefinition;
    assertEquals("not sure what this is but the code allows another text node here",
        passThroughQuery.getCustomQueryData());
    assertEquals("select r_object_id from test_object_type", passThroughQuery.getQueryString());
    assertEquals(-1, passThroughQuery.getMaxResultCount());
    assertTrue(passThroughQuery instanceof DfPassThroughQuery);
    IDfSearchMetadataManager metadataMgr = queryDefinition.getMetadataMgr();
    assertTrue(metadataMgr instanceof DfSearchMetadataManager);
    assertEquals("defaultMetadataDocbase", metadataMgr.getMetadataDocbase());
    assertEquals(sessionManager, metadataMgr.getSessionMgr());
    assertEquals(searchSourceMap, metadataMgr.getSourceMap());
  }

  public void testExceptionThrownForNeitherQueryBuildNorPassThroughQueryDef() throws Exception {
    MockSessionManager sessionManager = new MockSessionManager();
    DfSearchSourceMap searchSourceMap = new DfSearchSourceMap();
    try {
      MockMonQueryManager.readQueryDefinition(
          new DfSearchMetadataManager(sessionManager, searchSourceMap, "defaultMetadataDocbase"),
          DfXMLUtil.read(SearchTestUtils.generateInvalidStream()));
    } catch (DfQueryFormatException e) {
      //expected path
      return;
    }
    fail("didn't throw DfQueryFormatException exception");
  }
}