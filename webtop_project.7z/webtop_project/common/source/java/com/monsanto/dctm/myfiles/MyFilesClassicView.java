package com.monsanto.dctm.myfiles;

import com.monsanto.dctm.monAppContext.MonAppContextService;

public class MyFilesClassicView extends
                                com.documentum.webtop.webcomponent.myfiles.MyFilesClassicView {

    protected String getColumnsPreferenceId() {
        return super.getColumnsPreferenceId() + "." +
               MonAppContextService.getMonAppContextService().getMonAppContextInternalName();
    }

}
