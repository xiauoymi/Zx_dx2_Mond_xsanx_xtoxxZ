/*
 * Created on May 19, 2005
 */
package com.monsanto.dctm.validation;

import com.documentum.fc.common.DfLogger;
import com.documentum.web.form.Form;
import com.documentum.web.form.control.validator.BaseValidator;
import com.documentum.web.formext.control.docbase.DocbaseAttributeValue;
import com.documentum.web.formext.control.docbase.DocbaseObject;

import java.util.Iterator;
import java.util.Vector;

public class RegulatoryAffairsLibraryValidation extends CustomValidation {

  public RegulatoryAffairsLibraryValidation(Form form, DocbaseObject docbaseObj) {
    super(form, docbaseObj);

    i_Form.setDoValidation(true);

    System.out.println("do validation? " + i_Form.getDoValidation());


    doCustomValidation = true;  //if we've created an instance of this object, we need custom validation
  }

  protected void customValidate() {
    getAttributes();  //always make sure we have the most recent attribute values
    bIsValid = true;  //assume everything is ok, set this to false if not
    strErrorMessage = "";  //always make sure we start with a blank error message
    //Check to see if we still need to do custom validation still since we might not have to after getAttributes()
    if (doCustomValidation) {
      // Reset any attributes we're making conditionally required
      ((DocbaseAttributeValue) hAttributesControls.get("crop")).setRequired(false);
      ((DocbaseAttributeValue) hAttributesControls.get("biotech_trait")).setRequired(false);
      ((DocbaseAttributeValue) hAttributesControls.get("biotech_gene")).setRequired(false);
      ((DocbaseAttributeValue) hAttributesControls.get("active_ingredient")).setRequired(false);
      ((DocbaseAttributeValue) hAttributesControls.get("submission_region")).setRequired(false);
      ((DocbaseAttributeValue) hAttributesControls.get("regulatory_agency_name")).setRequired(false);
      ((DocbaseAttributeValue) hAttributesControls.get("biotech_prod_line")).setRequired(false);

      // Do the custom validation logic.

      // Only need to check if regulatory_doc_content_type islocated and it is  != "Draft"
      String status = null;
      if (hAttributes.containsKey("regulatory_doc_content_type")) {
        status = (String) hAttributes.get("regulatory_doc_content_type");
      }
      DfLogger.info(this, "status = " + status, null, null);
      if (status != null && status.length() > 0 && !(status.equals("Draft"))) {
        // Must specify either regulatory_doc_discipline or other_reg_doc_discipline
        //   If other_reg_doc_discipline, make sure Other is one of the regulatory_doc_discipline 
        //   values.  If Other is specified in regulatory_doc_disipline, make sure
        //   other_reg_doc_discipline is specified
        bIsValid =
            oneOrTheOtherValidation("regulatory_doc_discipline", "Doc Discipline Type", "other_reg_doc_discipline",
                "Other Doc Discipline") && bIsValid;

        //Rules that apply when regulatory classification = "Biotech"
        if (hAttributes.get("regulatory_classification").toString().equals("Biotech")) {
          // Must specify either crop or other_crop_desc.  If other_crop, make sure Other is one of the
          //   crop values.  If Other is specified in crop, make sure other_crop_desc is specified.
          bIsValid = oneOrTheOtherValidation("crop", "Crop", "other_crop_desc", "Other Crop") && bIsValid;
          ((DocbaseAttributeValue) hAttributesControls.get("crop")).setRequired(true);
          // Must specify either biotech_trait or other_biotech_trait.  If other_biotech_trait, make
          //   sure Other is one of the biotech_trait values.  If Other is specified in
          //   biotech_trait, make sure other_biotech_trait is specified.
          bIsValid =
              oneOrTheOtherValidation("biotech_trait", "Trait", "other_biotech_trait", "Other Trait") && bIsValid;
          ((DocbaseAttributeValue) hAttributesControls.get("biotech_trait")).setRequired(true);
          // Must specify either biotech_gene or other_biotech_gene.  If other_biotech_gene, make sure Other
          //   is one of the biotech_gene values.  If Other is specified in biotech_gene, make sure
          //   other_biotech_gene is specified.
          bIsValid = oneOrTheOtherValidation("biotech_gene", "Gene", "other_biotech_gene", "Other Gene") && bIsValid;
          ((DocbaseAttributeValue) hAttributesControls.get("biotech_gene")).setRequired(true);

          //Must specify "Biotech Product Line" value whenever Biotech is selected for classification
          Vector repeatingAttributeVector = (Vector) hAttributes.get("biotech_prod_line");
          Iterator repeatingAttributeValues = repeatingAttributeVector.iterator();
          boolean bEmpty = true;
          String repeatingAttributeValue = null;
          while (repeatingAttributeValues.hasNext()) {
            repeatingAttributeValue = repeatingAttributeValues.next().toString();
            if ((repeatingAttributeValue != null) && (repeatingAttributeValue).length() > 0) {
              bEmpty = false;
            }
          }
          if (repeatingAttributeVector.isEmpty() || bEmpty) {
            bIsValid = false;
            strErrorMessage += "You must specify Biotech Product Line.</li><li>";
            ((DocbaseAttributeValue) hAttributesControls.get("biotech_prod_line")).setRequired(true);
          }
        }
        //Rules that apply when regulatory classification = "Chemical"
        else if (hAttributes.get("regulatory_classification").toString().equals("Chemical")) {
          // Must specify either active_ingredient or other_act_ing_desc.  If other_act_ing_desc,
          //   make sure Other is one of the active_ingredient values.  If Other is specified in
          //   active_ingredient, make sure other_act_ing_desc is specified.
          bIsValid = oneOrTheOtherValidation("active_ingredient", "Active Ingredient", "other_act_ing_desc",
              "Other Active Ingredient") && bIsValid;
          ((DocbaseAttributeValue) hAttributesControls.get("active_ingredient")).setRequired(true);
          // Must specify either brand_name or other_brand_name.  If other_brand_name,
          //   make sure Other is one of the brand_name values.  If Other is specified in
          //   brand_name, make sure other_brand_name is specified.
          if ((!(((Vector) hAttributes.get("brand_name")).isEmpty()) &&
              !(hAttributes.get("brand_name").toString().equals("[]"))) ||
              (hAttributes.get("other_brand_name") != null &&
                  ((String) hAttributes.get("other_brand_name")).length() > 0)) {
            bIsValid =
                oneOrTheOtherValidation("brand_name", "Brand Name", "other_brand_name", "Other Brand Name") && bIsValid;
          }
        } else {
          bIsValid = false;
          strErrorMessage += "You entered an unknown value for Regulatory Classification.</li><li>";
        }
        if (hAttributes.get("regulatory_doc_content_type").toString().equals("Submitted")) {
          if (!((hAttributes.get("submission_region").toString() != null) &&
              (hAttributes.get("submission_region").toString().length() > 0))) {
            bIsValid = false;
            strErrorMessage += "You must specify Submission Region.</li><li>";
            ((DocbaseAttributeValue) hAttributesControls.get("submission_region")).setRequired(true);
          }
          if (!((hAttributes.get("regulatory_agency_name").toString() != null) &&
              (hAttributes.get("regulatory_agency_name").toString().length() > 0))) {
            bIsValid = false;
            strErrorMessage += "You must specify Agency Name.</li><li>";
            ((DocbaseAttributeValue) hAttributesControls.get("regulatory_agency_name")).setRequired(true);
          }
        }
      }
      super.customValidate(); //do what has to always happen during validation

      // Do some error message patching.
      if (objDocbaseObjectValidator != null) {
        String strOrigErrorMessage = objDocbaseObjectValidator.getErrorMessage();
        if (!bIsValid) {
          if (strOrigErrorMessage.lastIndexOf("&nbsp;:&nbsp;Default error message") >= 0) {
            strOrigErrorMessage = strOrigErrorMessage
                .substring(0, strOrigErrorMessage.lastIndexOf("&nbsp;:&nbsp;Default error message"));
          }
          if (strOrigErrorMessage.lastIndexOf("Doc Language&nbsp;:&nbsp;User must input a value.<br>") >= 0) {
            strOrigErrorMessage = strOrigErrorMessage
                .substring(0, strOrigErrorMessage.lastIndexOf("Doc Language&nbsp;:&nbsp;User must input a value.<br>"));
          }
          if (strOrigErrorMessage.lastIndexOf("Content Type&nbsp;:&nbsp;User must input a value.<br>") >= 0) {
            strOrigErrorMessage = strOrigErrorMessage
                .substring(0, strOrigErrorMessage.lastIndexOf("Content Type&nbsp;:&nbsp;User must input a value.<br>"));
          }
          if (strOrigErrorMessage.lastIndexOf("Reg Classification&nbsp;:&nbsp;User must input a value.<br>") >= 0) {
            strOrigErrorMessage = strOrigErrorMessage.substring(0,
                strOrigErrorMessage.lastIndexOf("Reg Classification&nbsp;:&nbsp;User must input a value.<br>"));
          }
          if (strOrigErrorMessage.lastIndexOf("[DM_DFC_E_BAD_VALUE]error: \"Bad value passed as argument: null.\"") >=
              0) {
            strOrigErrorMessage = strOrigErrorMessage.substring(0,
                strOrigErrorMessage.lastIndexOf("[DM_DFC_E_BAD_VALUE]error: \"Bad value passed as argument: null.\""));
          }
        } else {
          strOrigErrorMessage = "";
        }
        objDocbaseObjectValidator.setErrorMessage(strOrigErrorMessage);
      }
      // Go through the validators again and if we have one for one of the
      //   attributes we're making conditionally required, remove it.  This prevents
      //   the error message from being duplicated in the summary and works around
      //   what is believed to be a bug when you change the attribute to not required
      //   and the error stays in the summary.  The asterisk will always be there
      //   when a field is required since the validator control is recreated when
      //   an attribute is marked as required.  Removing it at this point prevents
      //   the error summary from picking up this validator's error message.
      Iterator validators = vValidators.iterator();
      while (validators.hasNext()) {
        BaseValidator validator = (BaseValidator) validators.next();
        if (!validator.getIsValid()) {
          if (validator.getControlToValidate().getName() != null) {
            String attribute = (String) hAttrbiutesValueElementControls.get(validator.getControlToValidate().getName());
            if (attribute != null) {
              if (attribute.equals("regulatory_doc_discipline") || attribute.equals("crop") ||
                  attribute.equals("biotech_gene") || attribute.equals("biotech_trait") ||
                  attribute.equals("active_ingredient") || attribute.equals("submission_region") ||
                  attribute.equals("regulatory_agency_name") || attribute.equals("biotech_prod_line")) {
                validator.getForm().remove(validator);
              }
            }
          }
        }
      }
    }
  }
}
