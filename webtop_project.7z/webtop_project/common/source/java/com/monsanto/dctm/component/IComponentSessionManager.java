/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.component;

import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.IDfSessionManager;
import com.documentum.fc.common.DfException;
import com.monsanto.dctm.autoLogin.ComponentCredentials;

import java.io.IOException;

/**
 * Filename:    $RCSfile: IComponentSessionManager.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: lakench $    	 On:	$Date: 2007-01-16 22:56:33 $
 *
 * @author lakench
 * @version $Revision: 1.2 $
 */
public interface IComponentSessionManager extends IDfSessionManager {
    public IDfSession getSessionForComponent() throws DfException;

    public ComponentCredentials getComponentCredentials(String componentId) throws DfException, IOException;
}