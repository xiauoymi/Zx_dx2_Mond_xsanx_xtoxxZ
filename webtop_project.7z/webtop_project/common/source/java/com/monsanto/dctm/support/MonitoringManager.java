/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.support;

import com.documentum.fc.common.DfLogger;

import javax.servlet.*;
import javax.servlet.http.HttpSessionAttributeListener;
import javax.servlet.http.HttpSessionBindingEvent;
import javax.servlet.http.HttpSessionEvent;
import javax.servlet.http.HttpSessionListener;

/**
 * Filename:    $RCSfile: MonitoringManager.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: lakench $    	 On:	$Date: 2007-02-16 16:46:36 $
 *
 * @author lakench
 * @version $Revision: 1.1 $
 */
public class MonitoringManager implements HttpSessionListener, HttpSessionAttributeListener {

    public void sessionCreated(HttpSessionEvent httpSessionEvent) {
        long creationTime = httpSessionEvent.getSession().getCreationTime();
        System.out.println("creationTime = " + creationTime);
        String httpSessionId = httpSessionEvent.getSession().getId();
        System.out.println("httpSessionId = " + httpSessionId);
        long lastAccessedTime = httpSessionEvent.getSession().getLastAccessedTime();
        System.out.println("lastAccessedTime = " + lastAccessedTime);
        int maxInactiveInterval = httpSessionEvent.getSession().getMaxInactiveInterval();
        System.out.println("maxInactiveInterval = " + maxInactiveInterval);
    }

    public void sessionDestroyed(HttpSessionEvent httpSessionEvent) {
        long creationTime = httpSessionEvent.getSession().getCreationTime();
        System.out.println("creationTime = " + creationTime);
        String httpSessionId = httpSessionEvent.getSession().getId();
        System.out.println("httpSessionId = " + httpSessionId);
        long lastAccessedTime = httpSessionEvent.getSession().getLastAccessedTime();
        System.out.println("lastAccessedTime = " + lastAccessedTime);
        int maxInactiveInterval = httpSessionEvent.getSession().getMaxInactiveInterval();
        System.out.println("maxInactiveInterval = " + maxInactiveInterval);
    }

    public void attributeAdded(HttpSessionBindingEvent httpSessionBindingEvent) {
        long creationTime = httpSessionBindingEvent.getSession().getCreationTime();
        System.out.println("creationTime = " + creationTime);
        String httpSessionId = httpSessionBindingEvent.getSession().getId();
        System.out.println("httpSessionId = " + httpSessionId);
        long lastAccessedTime = httpSessionBindingEvent.getSession().getLastAccessedTime();
        System.out.println("lastAccessedTime = " + lastAccessedTime);
        int maxInactiveInterval = httpSessionBindingEvent.getSession().getMaxInactiveInterval();
        System.out.println("maxInactiveInterval = " + maxInactiveInterval);
        String servletContextAttributeName = httpSessionBindingEvent.getName();
        String servletContextAttributeClassName = httpSessionBindingEvent.getValue().getClass().getName();
        Object servletContextAttributeValue = httpSessionBindingEvent.getValue();
        String message = "servletContextAttribute added:\n\t" + servletContextAttributeName + "\n\t" +
                         servletContextAttributeClassName + "\n\t" + servletContextAttributeValue;
        System.out.println(message);
    }

    public void attributeRemoved(HttpSessionBindingEvent httpSessionBindingEvent) {
        long creationTime = httpSessionBindingEvent.getSession().getCreationTime();
        System.out.println("creationTime = " + creationTime);
        String httpSessionId = httpSessionBindingEvent.getSession().getId();
        System.out.println("httpSessionId = " + httpSessionId);
        long lastAccessedTime = httpSessionBindingEvent.getSession().getLastAccessedTime();
        System.out.println("lastAccessedTime = " + lastAccessedTime);
        int maxInactiveInterval = httpSessionBindingEvent.getSession().getMaxInactiveInterval();
        System.out.println("maxInactiveInterval = " + maxInactiveInterval);
        String servletContextAttributeName = httpSessionBindingEvent.getName();
        String servletContextAttributeClassName = httpSessionBindingEvent.getValue().getClass().getName();
        Object servletContextAttributeValue = httpSessionBindingEvent.getValue();
        String message = "servletContextAttribute removed:\n\t" + servletContextAttributeName + "\n\t" +
                         servletContextAttributeClassName + "\n\t" + servletContextAttributeValue;
        System.out.println(message);
    }

    public void attributeReplaced(HttpSessionBindingEvent httpSessionBindingEvent) {
        long creationTime = httpSessionBindingEvent.getSession().getCreationTime();
        System.out.println("creationTime = " + creationTime);
        String httpSessionId = httpSessionBindingEvent.getSession().getId();
        System.out.println("httpSessionId = " + httpSessionId);
        long lastAccessedTime = httpSessionBindingEvent.getSession().getLastAccessedTime();
        System.out.println("lastAccessedTime = " + lastAccessedTime);
        int maxInactiveInterval = httpSessionBindingEvent.getSession().getMaxInactiveInterval();
        System.out.println("maxInactiveInterval = " + maxInactiveInterval);
        String servletContextAttributeName = httpSessionBindingEvent.getName();
        String servletContextAttributeClassName = httpSessionBindingEvent.getValue().getClass().getName();
        Object servletContextAttributeValue = httpSessionBindingEvent.getValue();
        String message = "servletContextAttribute removed:\n\t" + servletContextAttributeName + "\n\t" +
                         servletContextAttributeClassName + "\n\t" + servletContextAttributeValue;
        System.out.println(message);
    }
}