package com.monsanto.dctm.directed;

import com.documentum.web.common.ArgumentList;
import com.documentum.web.formext.component.Component;
import com.documentum.web.formext.config.ConfigService;
import com.documentum.web.formext.config.IConfigLookup;

public class DirectedView extends Component {
		
	private String m_strStartComponent;
	
	public void onInit(ArgumentList args) {
		super.onInit(args);
		
		m_strStartComponent = getStartComponentFromDirectedMain();
	}
	
	public void onRender() {
		super.onRender();
		setComponentJump(m_strStartComponent, getContext());
	}
	
	private String getStartComponentFromDirectedMain()
	{
		IConfigLookup lookup = ConfigService.getConfigLookup();
		String strStartComponent = lookup.lookupString("component[id=directed_main].startingComponent", getContext());
		if (strStartComponent == null || strStartComponent.length() == 0)
		{
			strStartComponent = "advsearchcontainer";
		}
		
		return strStartComponent;
	}
	
}
