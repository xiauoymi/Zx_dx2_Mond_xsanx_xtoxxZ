/*
 * LaunchComponentWithLatestCheck.java
 *
 * Created on October 10, 2005, 9:29 AM
 *
 * To change this template, choose Tools | Options and locate the template under
 * the Source Creation and Management node. Right-click the template and choose
 * Open. You can then make changes to the template in the Source Editor.
 */

package com.monsanto.dctm.action;

import com.documentum.web.formext.action.*;

import com.documentum.fc.client.*;
import com.documentum.fc.common.*;
import com.documentum.nls.NlsResourceBundle;
import com.documentum.web.common.ArgumentList;
import com.documentum.web.common.ErrorMessageService;
import com.documentum.web.formext.Trace;
import com.documentum.web.formext.component.Component;
import com.documentum.web.formext.config.Context;
import com.documentum.web.formext.config.IConfigElement;
import com.documentum.web.formext.session.SessionManagerHttpBinding;
import java.util.*;

/**
 *
 * @author tsvedan
 */
public class LaunchComponentWithWorkflowCheck extends LaunchComponent {
    
    public boolean execute(
            String strAction,
            IConfigElement config,
            ArgumentList args,
            Context context,
            Component component,
            Map completionArgs) {
        if (strAction.equals("delete")){
            try{
                IDfQuery query = new DfQuery();
                query.setDQL("select r_object_id from dm_workflow where r_runtime_state not in (2,4) "
                        + "and r_object_id in (select r_workflow_id from dmi_package "
                        + "where any r_component_id='" + args.get("objectId") + "')");
                IDfCollection coll = query.execute(component.getDfSession(), IDfQuery.DF_READ_QUERY);
                if(coll!=null && coll.next()){
                    coll.close();
                    String nlsprop = config.getChildValue("nlsbundle");
                    NlsResourceBundle nlsResBndl = new NlsResourceBundle(nlsprop);
                    ErrorMessageService.getService().setNonFatalError(nlsResBndl, "MSG_ERROR_DELETE_DOC_IN_WORKFLOW", component, null, null);
                } else return super.execute(strAction, config, args, context, component, completionArgs);
            } catch (Exception e){
                if(Trace.COMPONENT)
                    com.documentum.web.common.Trace.println("An Exception occured in LaunchComponentWithWorkflowCheck.execute('" +
                            strAction + "'...'" + context.toString() + "': " + e);
            }
        } else return super.execute(strAction, config, args, context, component, completionArgs);
        return false;
    } //execute
    
}
