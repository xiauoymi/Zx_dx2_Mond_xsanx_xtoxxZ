/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.action;

import com.documentum.web.common.ArgumentList;
import com.documentum.web.formext.component.Component;
import com.documentum.web.formext.config.Context;
import com.documentum.web.formext.config.IConfigElement;

import java.util.Map;

/**
 * Filename:    $RCSfile: DRLViewOnlySysObjectViewAction.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: lakench $    	 On:	$Date: 2007-10-12 05:21:59 $
 *
 * @author lakench
 * @version $Revision: 1.1 $
 */
public class DRLViewOnlySysObjectViewAction extends DRLViewPDFRendition {
  public boolean execute(String strAction, IConfigElement config, ArgumentList args, Context context,
                         Component component, Map completionArgs) {
//    IActionCompleteListener completeListener = (IActionCompleteListener) completionArgs
//        .get(ActionService.COMPLETE_LISTENER);
    Context webcomponentContext = new Context(context);
    webcomponentContext.set("application", "webcomponent");
    return runAction("view", config, args, webcomponentContext, component, completionArgs);

  }

  protected boolean runAction(String actionId, IConfigElement config, ArgumentList args, Context context,
                              Component component, Map completionArgs) {
//    return ActionService.execute(actionId, args, context, component, completeListener);
    return super.execute(actionId, config, args, context, component, completionArgs);
  }
}