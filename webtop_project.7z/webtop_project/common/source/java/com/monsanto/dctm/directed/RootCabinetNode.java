/*
 Copyright:  Copyright � 2006 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.directed;

import com.documentum.fc.client.IDfCollection;
import com.documentum.fc.client.IDfQuery;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.IDfSessionManager;
import com.documentum.fc.common.DfException;
import com.documentum.web.common.WrapperRuntimeException;
import com.documentum.web.form.control.TreeNode;
import com.documentum.web.formext.control.docbase.DocbaseFolderTree;
import com.documentum.web.formext.control.docbase.DocbaseFolderTreeNode;
import com.documentum.web.formext.control.docbase.IDocbaseFolderTreeNodeDataHelper;
import com.documentum.web.formext.docbase.DocbaseLockIconUtil;
import com.documentum.web.formext.docbase.FolderUtil;
import com.documentum.web.formext.docbase.HiddenObjectUtil;
import com.documentum.web.formext.session.SessionManagerHttpBinding;
import com.documentum.web.util.DfcUtils;
import com.documentum.webcomponent.navigation.homecabinet.HomeCabinetService;
import com.documentum.webtop.control.BrowserNavigationNode;
import com.documentum.webtop.control.WebTopBrowserTree;

import java.util.HashSet;
import java.util.Iterator;

/**
 * Filename:    $RCSfile: RootCabinetNode.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: lakench $    	 On:	$Date: 2006-12-14 21:32:30 $
 *
 * @author lakench
 * @version $Revision: 1.5 $
 */
public class RootCabinetNode extends BrowserNavigationNode {

    private HashSet m_existingChildIds = new HashSet(7);

    public RootCabinetNode(WebTopBrowserTree tree, String strId, String strIcon, String strLabel, String strDocbase, TreeNode parent) {
        super(tree, strId, strIcon, strLabel, strDocbase, parent);
    }

    public void getData() {
        String strDocbaseName = getDocbaseName();

        // initialize hashset used for detecting duplicate nodes
        reinitExistingChildIds();

        // make sure the current login credentials are for the docbase we are concerned with
        IDfSessionManager sessionManager = SessionManagerHttpBinding.getSessionManager();
        IDfSession dfSession = null;
        try {
            dfSession = sessionManager.getSession(strDocbaseName);
        }
        catch (DfException e) {
            throw new IllegalStateException("Unable to find docbase credentials for docbase: " + strDocbaseName);
        }
        finally {
            if (dfSession != null) {
                sessionManager.release(dfSession);
            }
        }

        // get current credentials to reset later
        String strOriginalDocbaseName = SessionManagerHttpBinding.getCurrentDocbase();

        // setup the credentials for our docbase
        SessionManagerHttpBinding.setCurrentDocbase(strDocbaseName);

        // removed unneeded try/catch block
        if (m_dataHelper == null) {
            // get the sub-folders
            addFolders();
            insertOptionalNodes();
            sortData();
        } else {
            m_dataHelper.addChildNodes();

            if (m_dataHelper.isChildDataSortable()) {
                // sort the nodes by name
                sortData();
            }
        }

        // restore credentials in case they changed
        SessionManagerHttpBinding.setCurrentDocbase(strOriginalDocbaseName);
    }

    public boolean mayHaveChildren() {
        return m_bMayHaveChildren;
    }

    protected DocbaseFolderTreeNode addChildNode(String strId, String strIcon,
                                                 String strLabel, String strType,
                                                 int childCount,
                                                 IDocbaseFolderTreeNodeDataHelper dataHelper) {
        RootCabinetNode node = null;

        // only add the node if it doesn't already exist
        if (!m_existingChildIds.contains(strId)) {
            node = new RootCabinetNode((WebTopBrowserTree) m_tree, strId, strIcon,
                                       strLabel, getDocbaseName(), this);
            node.setDataHelper(dataHelper);

            if (childCount == 0) {
                node.setMayHaveChildren(false);
            }

            m_existingChildIds.add(strId);
        }

        return node;
    }

    protected void selectNodeFromObjectId(String strObjectId, String strData) {
        if (FolderUtil.isFolderType(strObjectId)) {
            super.selectNodeFromObjectId(strObjectId, strData);
        } else {
            String selectedId = m_tree.getSelectedId();
            StringBuffer id = new StringBuffer(selectedId.length() + 1 + strData.length());
            id.append(selectedId).append('.').append(strData);
            m_tree.setSelectedId(id.toString());
        }
    }

    protected String getObjectId() {
        String objectId = null;

        String nodeId = getId();
        if (nodeId.equals("directed_root_cabinet")) {
            String rootCabinetPath = RootCabinetService.getRootCabinetPath();
            objectId = FolderUtil.getFolderId(rootCabinetPath);
        }

        if (objectId == null) {
            objectId = super.getObjectId();
        }

        return objectId;
    }

    private void addFolders() {
        StringBuffer bufDql = new StringBuffer(256);

        if (getParent() instanceof RootCabinetNode) {
            bufDql.append("select upper(object_name),r_object_id,object_name,r_object_type,r_link_cnt,r_lock_owner ");
            if (HiddenObjectUtil.getShowHiddenObjectPreference()) {
                bufDql.append(
                        "from dm_folder where (i_is_reference is null or i_is_reference = 0) and any i_folder_id='");
            } else {
                bufDql.append(
                        "from dm_folder where a_is_hidden=false and (i_is_reference is null or i_is_reference = 0) and any i_folder_id='");
            }
            bufDql.append(getId());
            bufDql.append("' order by 1");
        } else {
            bufDql.append("select upper(object_name),r_object_id,object_name,r_object_type,r_link_cnt,r_lock_owner ");
            if (HiddenObjectUtil.getShowHiddenObjectPreference()) {
                bufDql.append(
                        "from dm_folder where (i_is_reference is null or i_is_reference = 0) and any i_folder_id='");
            } else {
                bufDql.append(
                        "from dm_folder where a_is_hidden=false and (i_is_reference is null or i_is_reference = 0) and any i_folder_id='");
            }
            bufDql.append(FolderUtil.getFolderId(RootCabinetService.getRootCabinetPath()));
            bufDql.append("' order by 1");
        }

        queryFolders(bufDql.toString());
    }

    private void queryFolders(String strDql) {
        IDfSessionManager sessionManager = SessionManagerHttpBinding.getSessionManager();
        IDfSession dfSession = null;
        IDfCollection coll = null;
        try {
            String strDocbase = getDocbaseName();
            dfSession = sessionManager.getSession(strDocbase);
            IDfQuery query = DfcUtils.getClientX().getQuery();
            query.setDQL(strDql);
            coll = query.execute(dfSession, IDfQuery.READ_QUERY);
            while (coll.next()) {
                //Retrieve data
                String strId = coll.getString("r_object_id");
                // only add the node if it doesn't already exist
                if (!m_existingChildIds.contains(strId)) {
                    m_existingChildIds.add(strId);
                    String strName = coll.getString("object_name");
                    String strType = coll.getString("r_object_type");
                    int iLinkCnt = coll.getInt("r_link_cnt");
                    String strLockOwner = coll.getString("r_lock_owner");

                    int nDepthToUse = ((DocbaseFolderTree) m_tree).getOriginalRootDepth() + getDepth() + 1;
                    String strIcon = ((DocbaseFolderTree) m_tree).getIconForDepth(nDepthToUse, strType);

                    RootCabinetNode node = new RootCabinetNode((WebTopBrowserTree) m_tree,
                                                               strId, strIcon, strName, strDocbase, (TreeNode) this);
                    node.setType(strType);

                    // Set mayhavechildren value as appropriate on r_link_cnt
                    if (iLinkCnt == 0) {
                        node.setMayHaveChildren(false);
                    }

                    // Use lock owner to determine Status Icon to set
                    String strStatusIconImage = DocbaseLockIconUtil
                            .getLockIconImage(strLockOwner, dfSession.getLoginUserName());
                    node.setStatusIcon(strStatusIconImage);
                }
            }
        }
        catch (DfException dfe) {
            throw new WrapperRuntimeException("Failed to read query", dfe);
        }
        finally {
            try {
                if (coll != null) {
                    coll.close();
                }
            }
            catch (DfException dfe2) {
                throw new WrapperRuntimeException("Failed to close collection", dfe2);
            }
            finally {
                if (dfSession != null) {
                    sessionManager.release(dfSession);
                }
            }
        }
    }

    private void insertOptionalNodes() {
        String strFolderId = null;
        if (getParent() instanceof RootCabinetNode)
            strFolderId = getId();
        else
            strFolderId = FolderUtil.getFolderId(HomeCabinetService.getHomeCabinetPath());

        if (((DocbaseFolderTree) m_tree).getIncludeVirtualDocuments()) {
            IDocbaseFolderTreeNodeDataHelper vdmHelper = DocbaseFolderTree.getDataHelperForVirtualDocuments();
            insertNodesFromDataHelper(vdmHelper, strFolderId);
        }

        if (((DocbaseFolderTree) m_tree).getIncludeAssemblyDocuments()) {
            IDocbaseFolderTreeNodeDataHelper assemblyHelper = DocbaseFolderTree.getDataHelperForAssemblies();
            insertNodesFromDataHelper(assemblyHelper, strFolderId);
        }

        // Add support for additional data helpers here!
    }

    private void insertNodesFromDataHelper(IDocbaseFolderTreeNodeDataHelper dataHelper, String strCurrentFolderId) {
        dataHelper.addObjectsFromFolder(this, strCurrentFolderId);
    }

    private void reinitExistingChildIds() {
        m_existingChildIds.clear();
        Iterator iterChildren = getChildren();
        while (iterChildren.hasNext()) {
            TreeNode treeNode = (TreeNode) iterChildren.next();
            m_existingChildIds.add(treeNode.getId());
        }
    }
}