package com.monsanto.dctm.advsearch;

import com.documentum.fc.client.search.IDfQueryBuilder;
import com.documentum.fc.client.search.IDfQueryManager;
import com.documentum.fc.client.search.IDfSearchService;
import com.documentum.fc.client.search.IDfSmartListDefinition;
import com.documentum.fc.client.search.impl.DfSearchService;
import com.documentum.fc.common.DfException;
import com.documentum.web.common.ArgumentList;
import com.documentum.web.common.WrapperRuntimeException;
import com.documentum.web.form.control.Button;
import com.documentum.web.formext.session.SessionManagerHttpBinding;
import com.documentum.web.util.SearchUtil;
import com.documentum.webcomponent.library.search.SearchInfo;
import com.documentum.webtop.webcomponent.advsearch.AdvSearchEx;
import com.monsanto.dctm.search.MonSearchInfo;
import com.monsanto.dctm.search.MonSearchService;

import java.io.ByteArrayInputStream;

public class AdvSearch extends AdvSearchEx {

  protected boolean processRevisedSavedSearch(ArgumentList args)
      throws Exception {
    String strSmartlistObjectId = args.get(PARAM_SAVEDSEARCH_OBJECT_ID);
    boolean fHasRevisedSearch = false;
    if (strSmartlistObjectId != null && strSmartlistObjectId.length() > 0) {
      if (getSearchInfo() == null)
        setSearchInfo(new MonSearchInfo());
      fHasRevisedSearch = super.processRevisedSavedSearch(args);
    } else if (args.get(PARAM_QUERY_ID) != null) {
      fHasRevisedSearch = super.processRevisedSavedSearch(args);
    } else {
      setSearchInfo(new MonSearchInfo());
    }
    return fHasRevisedSearch;
  }

  public void onClickSearch(Button button, ArgumentList args) {
    if (getIsValid()) {
      try {
        IDfQueryBuilder qbNew = buildQuery();
        SearchInfo searchInfoNew = (SearchInfo) getSearchInfo().clone();
        IDfSmartListDefinition smartListNew;
        if (getSearchInfo().getObjectId() != null) {
          String strQueryDef = SearchUtil.getSmartListDefinitionAsString(getSearchInfo().getSmartListDefinition());
          smartListNew = getSmartListDefinition(strQueryDef);
          smartListNew.setQueryDefinition(qbNew);
          searchInfoNew.setSmartListDefinition(smartListNew);
          setSearchInfo(searchInfoNew);
          doSearch();
        } else {
          super.onClickSearch(button, args);
        }
      }
      catch (DfException e) {
        throw new WrapperRuntimeException(e);
      }
      catch (CloneNotSupportedException e) {
        throw new WrapperRuntimeException(e);
      }
      catch (Exception e) {
        throw new WrapperRuntimeException(e);
      }
    }
  }

  public static IDfSmartListDefinition getSmartListDefinition(String strContent)
      throws Exception {
    ByteArrayInputStream streamUTF8 = new ByteArrayInputStream(strContent.getBytes("UTF-8"));
    IDfSmartListDefinition smartListContent = getSmartListDefinition(streamUTF8);
    streamUTF8.close();
    return smartListContent;
  }

  private static IDfSmartListDefinition getSmartListDefinition(ByteArrayInputStream inputstream)
      throws Exception {
    IDfSearchService searchService = new MonSearchService(new DfSearchService(
        SessionManagerHttpBinding.getSessionManager(), SessionManagerHttpBinding.getCurrentDocbase()));
    IDfQueryManager queryMgr = searchService.newQueryMgr();
    return queryMgr.loadSmartListDefinition(inputstream);
  }

}
