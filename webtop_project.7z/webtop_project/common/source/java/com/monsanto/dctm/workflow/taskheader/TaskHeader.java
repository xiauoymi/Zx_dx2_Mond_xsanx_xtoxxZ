package com.monsanto.dctm.workflow.taskheader;

import com.documentum.web.common.ArgumentList;

public class TaskHeader extends com.documentum.webcomponent.library.workflow.taskheader.TaskHeader 
{

	public void onInit(ArgumentList args) {
		getControl("bookmark", com.monsanto.dctm.viewprocessor.BookmarkLink.class);
		super.onInit(args);
	}
	
}
