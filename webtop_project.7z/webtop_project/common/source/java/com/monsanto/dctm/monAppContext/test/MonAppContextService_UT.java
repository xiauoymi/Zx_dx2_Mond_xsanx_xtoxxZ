/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.monAppContext.test;

import com.documentum.web.common.ResourceFileUtil;
import com.documentum.web.form.ComponentTestUtils;
import com.documentum.web.formext.config.ConfigService;
import com.documentum.web.formext.config.Context;
import com.documentum.web.formext.config.PreferenceService;
import com.monsanto.dctm.component.test.MockConfigReader;
import com.monsanto.dctm.component.test.MockHttpServletRequest;
import com.monsanto.dctm.component.test.MockPreferenceStore;
import com.monsanto.dctm.component.test.MockServletContext;
import com.monsanto.dctm.monAppContext.IMonAppContextService;
import com.monsanto.dctm.monAppContext.MonAppContextService;
import junit.framework.TestCase;

import java.util.Arrays;
import java.util.List;

/**
 * Filename:    $RCSfile: MonAppContextService_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: lakench $
 * On:	$Date: 2007-11-06 14:09:56 $
 *
 * @author LAKENCH
 * @version $Revision: 1.10 $
 */
public class MonAppContextService_UT extends TestCase {
  protected IMonAppContextService monAppContextService;
  protected MockServletContext servletContext;
  protected MockConfigReader configReader;
  protected MockHttpServletRequest httpServletRequest;

  protected void setUp() throws Exception {
    super.setUp();
    servletContext = new MockServletContext();
    ResourceFileUtil.setLookupContext(servletContext, null);
    configReader = new MockConfigReader();
    ConfigService.setConfigReader(configReader);
    httpServletRequest = new MockHttpServletRequest();
    PreferenceService.bindHttpRequest(httpServletRequest);
    monAppContextService = MonAppContextService.getMonAppContextService("testdocbase");
  }

  protected void tearDown() throws Exception {
    ((MockPreferenceStore) PreferenceService.getPreferenceStore()).clearPreferences();
    PreferenceService.releaseHttpRequest(httpServletRequest);
    ComponentTestUtils.setCurrentDocbase(null);
    httpServletRequest = null;
    monAppContextService = null;
    configReader = null;
    Context.getSessionContext().remove("mon_app_context");
    servletContext = null;
    super.tearDown();
  }

  public void testGetMonAppContext() throws Exception {
    monAppContextService.setMonAppContext("test mon app context");
    String monAppContext = monAppContextService.getCurrentMonAppContextName();
    assertEquals("mon app context wrong", "test mon app context", monAppContext);
  }

  public void testGetNullMonAppContext() throws Exception {
    monAppContextService.setMonAppContext(null);
    monAppContextService = null;
    String monAppContext = MonAppContextService.getMonAppContextService("testdocbase")
        .getCurrentMonAppContextName();
    assertNull("mon app context wrong", monAppContext);
  }

  public void testGetBlankMonAppContext() throws Exception {
    monAppContextService.setMonAppContext("");
    monAppContextService = null;
    String monAppContext = MonAppContextService.getMonAppContextService("testdocbase")
        .getCurrentMonAppContextName();
    assertEquals("mon app context wrong", "", monAppContext);
  }

  public void testNullMonAppContext() throws Exception {
    monAppContextService.setMonAppContext(null);
    monAppContextService = null;
    String monAppContextInternalName = MonAppContextService.getMonAppContextService("testdocbase")
        .getMonAppContextInternalName();
    assertNull("internal name not null", monAppContextInternalName);
    boolean useViewForCommentingEnabled = MonAppContextService.getMonAppContextService("testdocbase")
        .isUseViewForCommentingEnabled();
    assertFalse("view for commenting enabled", useViewForCommentingEnabled);
  }

  public void testBlankMonAppContext() throws Exception {
    monAppContextService.setMonAppContext("");
    monAppContextService = null;
    String monAppContextInternalName = MonAppContextService.getMonAppContextService("testdocbase")
        .getMonAppContextInternalName();
    assertNull("internal name not null", monAppContextInternalName);
    boolean useViewForCommentingEnabled = MonAppContextService.getMonAppContextService("testdocbase")
        .isUseViewForCommentingEnabled();
    assertFalse("view for commenting enabled", useViewForCommentingEnabled);
  }

  public void testIsUseViewForCommentingEnabled() throws Exception {
    monAppContextService.setMonAppContext("Test Context with View for commenting enabled");
    assertTrue("view for commenting should be enabled", monAppContextService.isUseViewForCommentingEnabled());
    monAppContextService.setMonAppContext("Test Context with View for commenting disabled");
    assertFalse("view for commenting should not be enabled", monAppContextService.isUseViewForCommentingEnabled());
  }

  public void testGetMonAppContextInternalName() throws Exception {
    monAppContextService.setMonAppContext("Test Context with View for commenting enabled");
    assertEquals("internal name wrong", "test1", monAppContextService.getMonAppContextInternalName());
    monAppContextService.setMonAppContext("Test Context with View for commenting disabled");
    assertEquals("internal name wrong", "test2", monAppContextService.getMonAppContextInternalName());
  }

  public void testGetSupportedMonAppContexts() throws Exception {
    List expectedMonAppContexts = Arrays
        .asList(new String[]{null, "Test Context with View for commenting disabled",
            "Test Context with View for commenting enabled", "Test defaults work"});
    List actualMonAppContexts = Arrays.asList(monAppContextService.getSupportedMonAppContexts());
    assertEquals("supported mon app contexts not set correctly", expectedMonAppContexts, actualMonAppContexts);
    monAppContextService.setDocbase("testproddocbase");
    actualMonAppContexts = Arrays.asList(monAppContextService.getSupportedMonAppContexts());
    assertEquals("supported mon app contexts not set correctly", expectedMonAppContexts, actualMonAppContexts);
    monAppContextService.setDocbase("differenttestdocbase");
    expectedMonAppContexts = Arrays
        .asList(new String[]{null, "Test Context with different docbases", "Test defaults work"});
    actualMonAppContexts = Arrays.asList(monAppContextService.getSupportedMonAppContexts());
    assertEquals("supported mon app contexts not set correctly", expectedMonAppContexts, actualMonAppContexts);
    monAppContextService.setDocbase("differenttestproddocbase");
    actualMonAppContexts = Arrays.asList(monAppContextService.getSupportedMonAppContexts());
    assertEquals("supported mon app contexts not set correctly", expectedMonAppContexts, actualMonAppContexts);
    monAppContextService.setDocbase("nonexistantdocbase");
    expectedMonAppContexts = Arrays.asList(new String[]{null, "Test defaults work"});
    actualMonAppContexts = Arrays.asList(monAppContextService.getSupportedMonAppContexts());
    assertEquals("supported mon app contexts not set correctly", expectedMonAppContexts, actualMonAppContexts);
  }

  public void testSetMonAppContextFromPreference() throws Exception {
    PreferenceService.getPreferenceStore()
        .writeString("application.mon_app_context.testdocbase",
            "Test Context with View for commenting disabled");
    monAppContextService.setMonAppContext();
    assertEquals("should have set mon app context from preference stored above",
        "Test Context with View for commenting disabled",
        monAppContextService.getCurrentMonAppContextName());
    assertEquals("wrong internal name", "test2", monAppContextService.getMonAppContextInternalName());
    assertFalse("view for commenting should be disabled", monAppContextService.isUseViewForCommentingEnabled());
    assertEquals("wrong docbase", "testdocbase", monAppContextService.getDocbase());
    assertNotNull("should be able to get the IMonAppContext back", monAppContextService.getCurrentMonAppContext());
  }

  public void testSetMonAppContextButDontStorePreference() throws Exception {
    monAppContextService.setMonAppContext("Test Context with View for commenting disabled", false);
    assertEquals("should have set mon app context above",
        "Test Context with View for commenting disabled",
        monAppContextService.getCurrentMonAppContextName());
    assertEquals("wrong internal name", "test2", monAppContextService.getMonAppContextInternalName());
    assertFalse("view for commenting should be disabled", monAppContextService.isUseViewForCommentingEnabled());
    assertEquals("wrong docbase", "testdocbase", monAppContextService.getDocbase());

  }

  public void testSetMonAppContextButDontStorePreferenceWithAnExtraSessionContextAttribute() throws Exception {
    monAppContextService.setMonAppContext("Test Context with View for commenting disabled", false);
    Context.getSessionContext()
        .set("test_attribute", "so that mon_app_context isn't the only attribute in the context");
    Context.getSessionContext().set("anotherone", "so mon_app_context isn't the last attribute");
    assertEquals("should have set mon app context above",
        "Test Context with View for commenting disabled",
        monAppContextService.getCurrentMonAppContextName());
    assertEquals("wrong internal name", "test2", monAppContextService.getMonAppContextInternalName());
    assertFalse("view for commenting should be disabled", monAppContextService.isUseViewForCommentingEnabled());
    assertEquals("wrong docbase", "testdocbase", monAppContextService.getDocbase());

    Context.getSessionContext().remove("test_attribute");
    Context.getSessionContext().remove("anotherone");

  }

  public void testDefaultsWork() throws Exception {
    monAppContextService.setMonAppContext("Test defaults work");
    assertEquals("wrong internal name", "test4", monAppContextService.getMonAppContextInternalName());
    assertTrue("view for commenting should be enabled", monAppContextService.isUseViewForCommentingEnabled());

  }

  public void testNoArgGetService() throws Exception {
    IMonAppContextService noArgMonAppContextService = MonAppContextService.getMonAppContextService();
    assertNull("docbase should not be set", noArgMonAppContextService.getDocbase());
  }
}