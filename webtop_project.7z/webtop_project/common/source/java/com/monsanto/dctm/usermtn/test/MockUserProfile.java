/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.usermtn.test;

import com.documentum.fc.client.DfServiceException;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.IDfSessionManager;
import com.documentum.web.form.Control;
import com.documentum.web.form.control.DropDownList;
import com.documentum.web.form.control.Text;
import com.documentum.web.form.control.validator.RequiredFieldValidator;
import com.documentum.web.formext.config.ConfigElement;
import com.documentum.web.formext.config.IConfigElement;
import com.monsanto.dctm.component.test.IMonTestableComponent;
import com.monsanto.dctm.usermtn.DuplicateUserValidator;
import com.monsanto.dctm.usermtn.UserProfile;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * Filename:    $RCSfile: MockUserProfile.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: lakench $    	 On:	$Date: 2007-05-12 05:29:56 $
 *
 * @author lakench
 * @version $Revision: 1.1 $
 */
public class MockUserProfile extends UserProfile implements IMonTestableComponent {
    private IDfSessionManager sessionManager;

    public static final String TEST_AUTHOR_GROUP = "test_author_group";
    public static final String TEST_AUTHOR_ACL = "test_author_acl";
    public static final String TEST_AUTHOR_ACL_DOMAIN = "testacldomain";
    public static final String TEST_AUTHOR_FOLDER = "test_author_folder";
    public static final String TEST_AUTHOR_ADDITIONALGROUPS = "another_author_group, one_more_author_group";
    public static final String TEST_USER_GROUP = "test_user_group";
    public static final String TEST_USER_ACL = "test_user_acl";
    public static final String TEST_USER_ACL_DOMAIN = "testacldomain";
    public static final String TEST_USER_FOLDER = "test_user_folder";
    public static final String TEST_USER_ADDITIONALGROUPS = "another_user_group, one_more_user_group";
    public static final String AUTHOR_ROLE_VALUE = "author";
    public static final String AUTHOR_ROLE_LABEL = "Author";
    public static final String USER_ROLE_VALUE = "user";
    public static final String USER_ROLE_LABEL = "User";
    public boolean triedToValidate;
    private List containedControls = new ArrayList();

    public void setSessionManager(IDfSessionManager sessionManager) {
        this.sessionManager = sessionManager;
    }

    public IDfSessionManager getSessionManager() {
        return sessionManager;
    }

    /**
     * @noinspection RefusedBequest
     */
    public IDfSession getDfSession() {
        try {
            return sessionManager.getSession(getCurrentDocbase());
        } catch (DfServiceException e) {
            e.printStackTrace();
        }
        return null;
    }


    public void validate() {
        triedToValidate = true;
        super.validate();
    }

    protected void initializeComponent() {
        addControls();
        super.initializeComponent();
    }

    private void addControls() {
        addUserControls();
    }

    private void addUserControls() {
        addControl(UserProfile.USER_NAME, Text.class, "Enter User's Name (Ex. Lastname Firstname M)");
        addControl(UserProfile.USER_OS_NAME, Text.class, "Enter User's OS Name (Network Id)");
        addControl(UserProfile.GROUP_NAME, Text.class, "Enter Default Group");
        addControl(UserProfile.ACL_NAME, Text.class, "Enter Default ACL");
        addControl(UserProfile.ACL_DOMAIN, Text.class, "Enter ACL Domain");
        addControl(UserProfile.DEFAULT_FOLDER, Text.class, "Enter Default Folder");
        addControl(UserProfile.CLIENT_CAPABILITY, DropDownList.class, "Select Client Capability");
        DuplicateUserValidator control = (DuplicateUserValidator) getControl("duplicateuservalidator",
                                                                             DuplicateUserValidator.class);
        control.setErrorMessage("Duplicate User!");
        control.setVisible(false);
    }

    private void addControl(String controlName, Class controlClass, String errorMessage) {
        addValidator(getControl(controlName, controlClass), errorMessage);
    }

    private void addValidator(Control controlToValidate, String errorMessage) {
        RequiredFieldValidator validator = (RequiredFieldValidator) getControl(
                controlToValidate.getName() + "_validator", RequiredFieldValidator.class);
        validator.setControlToValidate(controlToValidate);
        validator.setErrorMessage(errorMessage);
    }


    public Control getControl(String attrName, int i, Class aClass) {
        Control control = super.getControl(attrName, i, aClass);
        if (!containedControls.contains(control))
            containedControls.add(control);
        return control;
    }

    /**
     * @noinspection RefusedBequest
     */
    public Iterator getContainedControls() {
        return containedControls.iterator();
    }

    /**
     * @noinspection RefusedBequest
     */
    protected IConfigElement getRoleConfig() {
        return new MockUserProfileRoleConfig("roles", "");
    }

    public class MockUserProfileRoleConfig extends ConfigElement {

        public MockUserProfileRoleConfig(String strName, String strValue) {
            super(strName, strValue);
            addUserRole();
            addAuthorRole();
        }

        private void addAuthorRole() {
            ConfigElement authorRoleElement = createAuthorRole();
            this.addChildElement(authorRoleElement);
        }

        private void addUserRole() {
            ConfigElement userRoleElement = createUserRole();
            this.addChildElement(userRoleElement);
        }

        private ConfigElement createAuthorRole() {
            ConfigElement authorRoleElement = new ConfigElement("role", "");
            authorRoleElement.setAttributeValue("value", AUTHOR_ROLE_VALUE);
            authorRoleElement.setAttributeValue("label", AUTHOR_ROLE_LABEL);
            ConfigElement authorGroupName = new ConfigElement(UserProfile.GROUP_NAME, TEST_AUTHOR_GROUP);
            ConfigElement authorAclName = new ConfigElement(UserProfile.ACL_NAME, TEST_AUTHOR_ACL);
            ConfigElement authorAclDomain = new ConfigElement(UserProfile.ACL_DOMAIN, TEST_AUTHOR_ACL_DOMAIN);
            ConfigElement authorDefaultFolder = new ConfigElement(UserProfile.DEFAULT_FOLDER, TEST_AUTHOR_FOLDER);
            ConfigElement authorClientCapability = new ConfigElement(UserProfile.CLIENT_CAPABILITY,
                                                                     UserProfile.CONTRIBUTOR);
            ConfigElement authorAdditionalGroups = new ConfigElement(UserProfile.ADDITIONAL_GROUPS,
                                                                     TEST_AUTHOR_ADDITIONALGROUPS);
            authorRoleElement.addChildElement(authorGroupName);
            authorRoleElement.addChildElement(authorAclName);
            authorRoleElement.addChildElement(authorAclDomain);
            authorRoleElement.addChildElement(authorDefaultFolder);
            authorRoleElement.addChildElement(authorClientCapability);
            authorRoleElement.addChildElement(authorAdditionalGroups);
            return authorRoleElement;
        }

        private ConfigElement createUserRole() {
            ConfigElement userRoleElement = new ConfigElement("role", "");
            userRoleElement.setAttributeValue("value", USER_ROLE_VALUE);
            userRoleElement.setAttributeValue("label", USER_ROLE_LABEL);
            ConfigElement userGroupName = new ConfigElement(UserProfile.GROUP_NAME, TEST_USER_GROUP);
            ConfigElement userAclName = new ConfigElement(UserProfile.ACL_NAME, TEST_USER_ACL);
            ConfigElement userAclDomain = new ConfigElement(UserProfile.ACL_DOMAIN, TEST_USER_ACL_DOMAIN);
            ConfigElement userDefaultFolder = new ConfigElement(UserProfile.DEFAULT_FOLDER, TEST_USER_FOLDER);
            ConfigElement userClientCapability = new ConfigElement(UserProfile.CLIENT_CAPABILITY, UserProfile.CONSUMER);
            ConfigElement userAdditionalGroups = new ConfigElement(UserProfile.ADDITIONAL_GROUPS,
                                                                   TEST_USER_ADDITIONALGROUPS);
            userRoleElement.addChildElement(userGroupName);
            userRoleElement.addChildElement(userAclName);
            userRoleElement.addChildElement(userAclDomain);
            userRoleElement.addChildElement(userDefaultFolder);
            userRoleElement.addChildElement(userClientCapability);
            userRoleElement.addChildElement(userAdditionalGroups);
            return userRoleElement;
        }
    }
}