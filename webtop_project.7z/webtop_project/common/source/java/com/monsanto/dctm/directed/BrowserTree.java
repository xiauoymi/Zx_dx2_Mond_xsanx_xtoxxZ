/*
 Copyright:  Copyright � 2006 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.directed;

import com.documentum.web.common.AccessibilityService;
import com.documentum.web.common.ArgumentList;
import com.documentum.web.form.Control;
import com.documentum.web.form.control.TreeNode;
import com.documentum.web.formext.control.docbase.DocbaseFolderTreeNode;
import com.documentum.web.formext.control.docbase.IDocbaseFolderTreeNodeDataHelper;
import com.documentum.webtop.control.WebTopBrowserTree;

/**
 * Filename:    $RCSfile: BrowserTree.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: lakench $    	 On:	$Date: 2007-04-30 17:48:04 $
 *
 * @author LAKENCH
 * @version $Revision: 1.15 $
 */
public class BrowserTree extends com.documentum.webtop.webcomponent.browsertree.BrowserTree {

    public void refreshTreeFromAbsolutePath(Control control, ArgumentList args) {
        String strObjectIds = args.get("objectIds");
        String strCompId = args.get("componentId");

        strObjectIds = RootCabinetService.stripRootCabinetFromObjectIds(strObjectIds);

        WebTopBrowserTree tree = (WebTopBrowserTree) getControl(TREE_CONTROL);

        tree.selectNodeFromAbsolutePath(getCurrentDocbase(), strCompId, strObjectIds);
        if (!tree.isTreeFocusedOnNode()) {
            DocbaseFolderTreeNode node = (DocbaseFolderTreeNode) tree.getSelectedNode();
            String strNodeId = node.getUniqueId();
            strNodeId = focusTreeIfNeeded(tree, strNodeId, node);
        }
        super.setRefreshDataRequired(false, false);
        TreeNode selectedRefreshNode = tree.getSelectedNode();
        if (selectedRefreshNode != null) {
            selectedRefreshNode.clearChildren();
            selectedRefreshNode.getData();
            selectedRefreshNode.expandNode();
        }
    }

    /**
     * Helper function to refocus the tree
     *
     * @param tree      the tree instance
     * @param strNodeId the current node id to check for refocusing
     * @param node      the node that might be refocused
     * @return the updated node id for the node
     */
    private String focusTreeIfNeeded(WebTopBrowserTree tree, String strNodeId, DocbaseFolderTreeNode node) {
        String strUpdatedNodeId = strNodeId;

        Control showAll = null;
        if (!AccessibilityService.isAllAccessibilitiesEnabled()) {
            showAll = getControl(SHOW_ALL_MENU_ITEM_CONTROL, 0);
        } else {
            showAll = getControl(SHOW_ALL_LINK_CONTROL, 0);
        }

        boolean showFocusedNodeOnly = true;
        if (showAll != null) {
            showFocusedNodeOnly = showAll.isEnabled();
        }

        if (showFocusedNodeOnly) {
            if (tree.getIncludeVirtualDocuments()) {
                IDocbaseFolderTreeNodeDataHelper vdmDataHelper = WebTopBrowserTree.getDataHelperForVirtualDocuments();
                strUpdatedNodeId = focusTree(tree, strNodeId, node, vdmDataHelper);
            }

            if (tree.getIncludeAssemblyDocuments()) {
                IDocbaseFolderTreeNodeDataHelper assemblyDataHelper = WebTopBrowserTree.getDataHelperForAssemblies();
                strUpdatedNodeId = focusTree(tree, strNodeId, node, assemblyDataHelper);
            }
        }

        return strUpdatedNodeId;
    }

    /**
     * Helper function to refocus the tree
     *
     * @param tree       the tree instance
     * @param strNodeId  the current node id to check for refocusing
     * @param node       the node that might be refocused
     * @param dataHelper the data helper instance associated with a type requiring refocusing
     * @return the updated node id for the node
     */
    private String focusTree(WebTopBrowserTree tree, String strNodeId,
                             DocbaseFolderTreeNode node,
                             IDocbaseFolderTreeNodeDataHelper dataHelper) {
        String strUpdatedNodeId = strNodeId;

        String strPrefix = dataHelper.getNodeIdPrefix();
        int prefixIndex = strUpdatedNodeId.indexOf(strPrefix + IDocbaseFolderTreeNodeDataHelper.NODE_PREFIX_TERMINATOR);
        if (prefixIndex != -1) {
            // focus on the first instance of the object in the hierarchy
            int prefixLength = strPrefix.length();

            int nodeSeparatorIndex = strUpdatedNodeId.indexOf(".", prefixIndex + prefixLength + 1);
            String strFirstInstanceNodeId = null;

            if (nodeSeparatorIndex != -1) {
                strFirstInstanceNodeId = strUpdatedNodeId.substring(0, nodeSeparatorIndex);
            } else {
                strFirstInstanceNodeId = strUpdatedNodeId;
            }

            // focus the tree on the root
            tree.focusTreeOnNode(strFirstInstanceNodeId, false);

            // reget the selected id as the node now has a new id, also make sure it is now selected
            strUpdatedNodeId = node.getUniqueId();
            tree.setSelectedId(strUpdatedNodeId);

            // manipulate the "real" id rather than the trucated focused id
            strUpdatedNodeId = tree.getOriginalNodeIdForFocusedNode(strUpdatedNodeId);
        }
        return strUpdatedNodeId;
    }
}