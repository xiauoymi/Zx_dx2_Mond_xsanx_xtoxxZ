/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.monAppContext.test;

import com.documentum.web.form.ComponentTestUtils;
import com.documentum.web.form.control.databound.DataDropDownList;
import com.documentum.web.formext.config.PreferenceService;
import com.monsanto.dctm.monAppContext.MonAppContextService;
import junit.framework.Assert;
import junit.framework.TestCase;

/**
 * Filename:    $RCSfile: Login_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: lakench $    	 On:	$Date:
 * 2007/03/06 22:10:49 $
 *
 * @author lakench
 * @version $Revision: 1.2 $
 */
public class Login_UT extends TestCase {
  private MockLogin loginComponent;

  protected void setUp() throws Exception {
    super.setUp();
    loginComponent = (MockLogin) ComponentTestUtils.getComponent(MockLogin.class, "login");
    loginComponent.setCurrentlySelectedDocbase("testdocbase");
  }

  protected void tearDown() throws Exception {
    ComponentTestUtils.releaseComponent(loginComponent);
    super.tearDown();
  }

  public void testInitMonAppContextDropdown() throws Exception {
    loginComponent.initMonAppContextDropdown();
    String currentlySelectedMonAppContext = loginComponent.getCurrentlySelectedMonAppContext();
    assertNull("with no preference set, currently selected mon app context should be null",
        currentlySelectedMonAppContext);
    DataDropDownList monAppContextControl = loginComponent.getMonAppContextControl();
    MonAppContextTestUtils.verifyMonAppContextDropdown(monAppContextControl);
  }

  public void testInitMonAppContextDropdownWithPreferenceSet() throws Exception {
    PreferenceService.getPreferenceStore().writeString("application.mon_app_context.testdocbase",
        "Test Context with View for commenting disabled");
    loginComponent.initMonAppContextDropdown();
    String currentlySelectedMonAppContext = loginComponent.getCurrentlySelectedMonAppContext();
    assertEquals("mon app context should match the preference", "Test Context with View for commenting disabled",
        currentlySelectedMonAppContext);

  }

  public void testUpdateMonAppContextControl() throws Exception {
    loginComponent.setCurrentlySelectedDocbase("testdocbase");
    loginComponent.updateMonAppContextControl();
    DataDropDownList monAppContextControl = loginComponent.getMonAppContextControl();
    MonAppContextTestUtils.verifyMonAppContextDropdown(monAppContextControl);

    loginComponent.setCurrentlySelectedDocbase("differenttestproddocbase");
    loginComponent.updateMonAppContextControl();
    MonAppContextTestUtils.verifyMonAppContextDropdown(monAppContextControl);
  }

  public void testUpdateMonAppContext() throws Exception {
    loginComponent.initMonAppContextDropdown();
    DataDropDownList monAppContextControl = loginComponent.getMonAppContextControl();
    monAppContextControl.setValue("Test Context with View for commenting disabled");
    loginComponent.updateMonAppContext();

    Assert.assertEquals("mon app context not set correctly", "Test Context with View for commenting disabled",
        MonAppContextService.getMonAppContextService().getCurrentMonAppContextName());

    monAppContextControl.setValue("Test Context with View for commenting enabled");
    loginComponent.updateMonAppContext();

    assertEquals("mon app context not set correctly", "Test Context with View for commenting enabled",
        MonAppContextService.getMonAppContextService().getCurrentMonAppContextName());

  }

}