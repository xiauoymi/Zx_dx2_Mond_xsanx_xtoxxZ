/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.report.test;

import com.documentum.fc.client.DfServiceException;
import com.documentum.fc.client.IDfQuery;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.IDfSessionManager;
import com.monsanto.dctm.component.test.IMonTestableComponent;
import com.monsanto.dctm.component.test.MockDfQuery;
import com.monsanto.dctm.report.DQLReport;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * Filename:    $RCSfile: MockDQLReport.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: lakench $    	 On:	$Date: 2007-04-25 16:51:05 $
 *
 * @author lakench
 * @version $Revision: 1.1 $
 */
public class MockDQLReport extends DQLReport implements IMonTestableComponent {
    public String buildQuery(HashMap criteria) {
        return "select title from dm_document";
    }

    private IDfSessionManager sessionManager;
    public IDfQuery dfQuery;

    public List getMockResults() {
        return mockResults;
    }

    public void setMockResults(List mockResults) {
        this.mockResults = mockResults;
    }

    private List mockResults;

    protected ArrayList getResults(HashMap criteria) {
        return super.getResults(criteria);
    }

    /**
     * @noinspection RefusedBequest
     */
    public IDfSession getDfSession(int i) {
        try {
            return getSessionManager().getSession(getCurrentDocbase());
        } catch (DfServiceException e) {
            e.printStackTrace();
        }
        return null;
    }

    protected IDfQuery createIDfQuery(String query) {
        dfQuery = new MockDfQuery(true, mockResults);
        dfQuery.setDQL(query);
        return dfQuery;

    }

    public void setSessionManager(IDfSessionManager sessionManager) {
        this.sessionManager = sessionManager;
    }

    public IDfSessionManager getSessionManager() {
        return sessionManager;
    }
}