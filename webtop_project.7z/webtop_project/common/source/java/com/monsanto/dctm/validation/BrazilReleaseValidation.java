package com.monsanto.dctm.validation;

import com.documentum.web.form.Form;
import com.documentum.web.form.control.validator.BaseValidator;
import com.documentum.web.formext.control.docbase.DocbaseObject;
import com.documentum.web.formext.control.docbase.DocbaseAttributeValue;
import com.documentum.web.formext.control.validator.DocbaseAttributeValidator;
import com.documentum.fc.common.DfLogger;

import java.util.Vector;
import java.util.Iterator;

/**
 * Created by IntelliJ IDEA.
 * User: ussing
 * Date: Nov 30, 2009
 * Time: 1:40:22 PM
 * To change this template use File | Settings | File Templates.
 */
public class BrazilReleaseValidation extends CustomValidation {
    public BrazilReleaseValidation(Form form, DocbaseObject docbaseObj) {
        super(form, docbaseObj);

        i_Form.setDoValidation(true);
        DfLogger.debug(this, "do validation? = " + i_Form.getDoValidation(), null, null);

        doCustomValidation = true;  //if we've created an instance of this object, we need custom validation
    }
    protected void customValidate() {
      getAttributes();
      bIsValid = true;
      strErrorMessage = "";
      //doCustomValidation = true; // need to uncomment it for UT's to pass
      if (doCustomValidation)
      {
        resetAllAttributesThatWillBeMadeRequiredConditionally();
        String releaseType = null;
        if (hAttributes.containsKey("release_type")) {
            releaseType = hAttributes.get("release_type").toString();
        }
        DfLogger.debug(this,"releaseType = " + releaseType,null,null);

        if(releaseType.equals("comercial")){
          getDescValidation();
        }
        if(releaseType.toString().equals("conten��o")){
          getYearValidation();
        }
        super.customValidate();
        resetAttributeFromValidator();
      }
    }
  private void resetAllAttributesThatWillBeMadeRequiredConditionally() {
    ((DocbaseAttributeValue) hAttributesControls.get("description")).setRequired(false);
    ((DocbaseAttributeValue) hAttributesControls.get("year")).setRequired(false);
  }

    public void getYearValidation() {
        if (!((hAttributes.get("year").toString() != null) && (hAttributes.get("year").toString().length() > 0))){
          bIsValid = false;
          strErrorMessage += "You must specify year.</li><li>";
          ((DocbaseAttributeValue) hAttributesControls.get("year")).setRequired(true);
        }
    }
  private void getDescValidation() {
    if (!((hAttributes.get("description").toString() != null) && (hAttributes.get("description").toString().length() > 0))){
      bIsValid = false;
      strErrorMessage += "You must specify description.</li><li>";
      ((DocbaseAttributeValue) hAttributesControls.get("description")).setRequired(true);
    }
  }
     private void resetAttributeFromValidator() {
    		// Go through the validators again and if we have one for one of the
		//   attributes we're making conditionally required, remove it.  This prevents
		//   the error message from being duplicated in the summary and works around
		//   what is believed to be a bug when you change the attribute to not required
		//   and the error stays in the summary.  The asterisk will always be there
		//   when a field is required since the validator control is recreated when
		//   an attribute is marked as required.  Removing it at this point prevents
		//   the error summary from picking up this validator's error message.
		Iterator validators = vValidators.iterator();
		while(validators.hasNext())
		{
			BaseValidator validator = (BaseValidator) validators.next();
			if (!(validator instanceof DocbaseAttributeValidator))
			{
				DfLogger.debug(this, "validator: " + validator,null,null);
				DfLogger.debug(this, "controltovalidate: " + validator.getControlToValidate(),null,null);
			}
			if (!validator.getIsValid())
			{
				if (validator.getControlToValidate().getName() != null)
				{
					String attribute = (String) hAttrbiutesValueElementControls.get(validator.getControlToValidate().getName());
                    DfLogger.debug(this,"attribute: " + attribute,null,null);
					if (attribute != null)
					{
					    if (attribute.equals("description") || attribute.equals("year"))
                        {
							DfLogger.debug(this,"I'm removing this validator: " + validator,null,null);
							validator.getForm().remove(validator);
						}
					}
				}
			}
		}
    }
}
