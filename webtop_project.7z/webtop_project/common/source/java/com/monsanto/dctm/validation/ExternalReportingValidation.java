/*
 Copyright:  Copyright � 2008 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.validation;

import com.documentum.fc.common.DfLogger;
import com.documentum.web.form.Form;
import com.documentum.web.form.control.validator.BaseValidator;
import com.documentum.web.formext.control.docbase.DocbaseAttributeValue;
import com.documentum.web.formext.control.docbase.DocbaseObject;
import com.documentum.web.formext.control.validator.DocbaseAttributeValidator;

import java.util.Iterator;
import java.util.Vector;

/**
 * Filename:    $RCSfile: ExternalReportingValidation.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ussing $    	 On:	$Date: 2008-06-26 19:48:19 $
 *
 * @author rrkaur
 * @version $Revision: 1.1.2.2 $
 */
public class ExternalReportingValidation extends CustomValidation {
  public ExternalReportingValidation(Form form, DocbaseObject docbaseObj) {

    super(form, docbaseObj);

    i_Form.setDoValidation(true);
    DfLogger.debug(this, "do validation? = " + i_Form.getDoValidation(), null, null);

    doCustomValidation = true;  //if we've created an instance of this object, we need custom validation
  }

  protected void customValidate() {
    getAttributes();
    bIsValid = true;
    strErrorMessage = "";
    //doCustomValidation = true; // need to uncomment it for UT's to pass
    if (doCustomValidation)
    {
      resetAllAttributesThatWillBeMadeRequiredConditionally();

      DfLogger.debug(this,"Major Category" + hAttributes.get("major_category").toString(),null,null);

      if(hAttributes.get("major_category").equals("Agreements")){
        getAgreementsValidation();
      }
      if(hAttributes.get("major_category").toString().equals("Acquisitions")){
        getAcquisitionsValidation();
      }
      if(hAttributes.get("major_category").toString().equals("White Papers")){
        getWhitePapersValidation();
      }
      super.customValidate();
      removeRepeatingValidation();
    }
  }

  private void removeRepeatingValidation() {
    Iterator validators = vValidators.iterator();
    while(validators.hasNext())
    {
      BaseValidator validator = (BaseValidator) validators.next();
      if (!(validator instanceof DocbaseAttributeValidator))
      {
        DfLogger.debug(this,"ExternalReportingValidation.validator: " + validator,null,null);
        DfLogger.debug(this,"ExternalReportingValidation.controltovalidate: " + validator.getControlToValidate(),null,null);
      }
      if (!validator.getIsValid())
      {
        if (validator.getControlToValidate().getName() != null)
        {
          String attribute = (String) hAttrbiutesValueElementControls.get(validator.getControlToValidate().getName());
          if (attribute != null)
          {
            if (attribute.equals("originating_department")
                || attribute.equals("party_target") || attribute.equals("dollar_amount")
                || attribute.equals("white_papers"))
            {
              validator.getForm().remove(validator);
            }
          }
        }
      }
    }
  }

  private void getWhitePapersValidation() {
    if (!((hAttributes.get("originating_department").toString() != null) && (hAttributes.get("originating_department").toString().length() > 0))){
      bIsValid = false;
      strErrorMessage += "You must specify Originating Department.</li><li>";
      ((DocbaseAttributeValue) hAttributesControls.get("originating_department")).setRequired(true);
    }
  }

  private void getAcquisitionsValidation() {
    if (!((hAttributes.get("originating_department").toString() != null) && (hAttributes.get("originating_department").toString().length() > 0))){
      bIsValid = false;
      strErrorMessage += "You must specify Originating Department.</li><li>";
      ((DocbaseAttributeValue) hAttributesControls.get("originating_department")).setRequired(true);
    }
    if (!((hAttributes.get("party_target").toString() != null) && (hAttributes.get("party_target").toString().length() > 0))){
      bIsValid = false;
      strErrorMessage += "You must specify Counter Parties or Acquisition Target.</li><li>";
      ((DocbaseAttributeValue) hAttributesControls.get("party_target")).setRequired(true);
    }
    if (!((hAttributes.get("dollar_amount").toString() != null) && (hAttributes.get("dollar_amount").toString().length() > 0))){
      bIsValid = false;
      strErrorMessage += "You must specify Dollar Amount.</li><li>";
      ((DocbaseAttributeValue) hAttributesControls.get("dollar_amount")).setRequired(true);
    }
   validateWhitePapers();

  }

  private void getAgreementsValidation() {
    if (!((hAttributes.get("originating_department").toString() != null) && (hAttributes.get("originating_department").toString().length() > 0))){
      bIsValid = false;
      System.out.println("ExternalReportingValidation.getAgreementsValidation for Originating Department");
      strErrorMessage += "You must specify Originating Department.</li><li>";
      ((DocbaseAttributeValue) hAttributesControls.get("originating_department")).setRequired(true);
    }
    if (!((hAttributes.get("party_target").toString() != null) && (hAttributes.get("party_target").toString().length() > 0))){
      bIsValid = false;
      strErrorMessage += "You must specify Counter Parties or Acquisition Target.</li><li>";
      ((DocbaseAttributeValue) hAttributesControls.get("party_target")).setRequired(true);
    }
    if (!((hAttributes.get("dollar_amount").toString() != null) && (hAttributes.get("dollar_amount").toString().length() > 0))){
      bIsValid = false;
      strErrorMessage += "You must specify Dollar Amount.</li><li>";
      ((DocbaseAttributeValue) hAttributesControls.get("dollar_amount")).setRequired(true);
    }
    validateWhitePapers();
  }

  private void validateWhitePapers() {
    Vector repeatingAttributeVector = (Vector) hAttributes.get("white_papers");
    Iterator repeatingAttributeValues = repeatingAttributeVector.iterator();
    boolean bEmpty = true;
    String repeatingAttributeValue = null;
    while(repeatingAttributeValues.hasNext())
    {
      repeatingAttributeValue = repeatingAttributeValues.next().toString();
      if ((repeatingAttributeValue != null) && (repeatingAttributeValue).length() > 0)
      {
        bEmpty = false;
      }
    }
    if (repeatingAttributeVector.isEmpty() || bEmpty)
    {
      bIsValid = false;
      strErrorMessage += "You must specify White Papers.</li><li>";
      ((DocbaseAttributeValue) hAttributesControls.get("white_papers")).setRequired(true);
    }
  }
  //white_papers

  private void resetAllAttributesThatWillBeMadeRequiredConditionally() {
    ((DocbaseAttributeValue) hAttributesControls.get("dollar_amount")).setRequired(false);
    ((DocbaseAttributeValue) hAttributesControls.get("originating_department")).setRequired(false);
    ((DocbaseAttributeValue) hAttributesControls.get("party_target")).setRequired(false);
    ((DocbaseAttributeValue) hAttributesControls.get("white_papers")).setRequired(false);
  }
}