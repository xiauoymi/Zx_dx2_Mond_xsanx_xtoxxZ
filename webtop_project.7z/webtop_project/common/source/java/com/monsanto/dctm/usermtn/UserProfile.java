/*
 * UserProfile.java
 *
 * Created on July 8, 2006, 5:04 PM
 *
 * To change this template, choose Tools | Options and locate the template under
 * the Source Creation and Management node. Right-click the template and choose
 * Open. You can then make changes to the template in the Source Editor.
 */

package com.monsanto.dctm.usermtn;

import com.documentum.fc.client.DfUser;
import com.documentum.fc.common.DfException;
import com.documentum.web.common.ArgumentList;
import com.documentum.web.form.control.DropDownList;
import com.documentum.web.form.control.Label;
import com.documentum.web.form.control.Option;
import com.documentum.web.form.control.Text;
import com.documentum.web.formext.component.Component;
import com.documentum.web.formext.config.IConfigElement;

import java.util.ArrayList;
import java.util.Iterator;

/**
 * @author tsvedan
 */
public class UserProfile extends Component {

    public static final String USER_ROLE = "role";
    public static final String USER_NAME = "user_name";
    public static final String USER_OS_NAME = "user_os_name";
    public static final String USER_DOMAIN = "user_domain";
    public static final String GROUP_NAME = "group_name";
    public static final String ACL_NAME = "acl_name";
    public static final String ACL_DOMAIN = "acl_domain";
    public static final String DEFAULT_FOLDER = "default_folder";
    public static final String CLIENT_CAPABILITY = "client_capability";
    public static final String ADDITIONAL_GROUPS = "additional_groups";

    public static final String CONSUMER = Integer.toString(DfUser.DF_CAPABILITY_CONSUMER);
    public static final String CONTRIBUTOR = Integer.toString(DfUser.DF_CAPABILITY_CONTRIBUTOR);
    public static final String COORDINATOR = Integer.toString(DfUser.DF_CAPABILITY_COORDINATOR);

    private User currentUser;
    private ArrayList userProfiles;
    private int index;

    public void onInit(ArgumentList args) {
        super.onInit(args);
        initializeComponent();
    }

    protected void initializeComponent() {
        ((Label) getControl("errmsg", Label.class)).setCssStyle("color: red");
        updateControlsFromConfig();
        userProfiles = new ArrayList();
        index = 0;
    }

    /**
     * @noinspection RefusedBequest
     */
    public boolean onCommitChanges() {
        try {
            return addUser();
        } catch (DfException e) {
            e.printStackTrace();
        }
        return false;
    }

    /**
     * @noinspection RefusedBequest
     */
    public boolean hasNextPage() {
        return true;
    }

    /**
     * @noinspection RefusedBequest
     */
    public boolean hasPrevPage() {
        return index > 0;
    }

    /**
     * @noinspection RefusedBequest
     */
    public boolean onNextPage() {
        try {
            return addUser();
        } catch (DfException e) {
            e.printStackTrace();
        }
        return false;
    }

    /**
     * @noinspection RefusedBequest
     */
    public boolean onPrevPage() {
        if (hasPrevPage()) {
            if (!onLastPage()) {
                setCurrentUser();
                validate();
                if (getIsValid()) {
                    try {
                        updateUserProfiles();
                    } catch (DfException e) {
                        e.printStackTrace();
                    }
                } else {
                    return false;
                }
            }
            decrement();
            updateControlsFromUserObj(index);
            return true;
        } else {
            return false;
        }
    }

    public void onSelectRole(DropDownList list, ArgumentList args) {
        updateControlsFromRole(list.getValue());
    }

    protected IConfigElement getRoleConfig() {
        return lookupElement("roles");
    }

    private boolean addUser() throws DfException {
        setCurrentUser();
        validate();
        if (getIsValid()) {
            increment();
            if (index == userProfiles.size()) {
                clearUserControls();
            } else updateControlsFromUserObj(index);
            return true;
        } else {
            return false;
        }
    }

    private void setCurrentUser() {
        currentUser = new User();
        currentUser.setUserName(getText(UserProfile.USER_NAME).trim());
        currentUser.setUserOSName(getText(UserProfile.USER_OS_NAME).trim());
        currentUser.setDomain(getSelection(UserProfile.USER_DOMAIN));
        currentUser.setUserGroupName(getText(UserProfile.GROUP_NAME));
        currentUser.setAclName(getText(UserProfile.ACL_NAME));
        currentUser.setAclDomain(getText(UserProfile.ACL_DOMAIN));
        currentUser.setDefaultFolder(getText(UserProfile.DEFAULT_FOLDER));
        currentUser.setClientCapability(getSelection(UserProfile.CLIENT_CAPABILITY));
        currentUser.setAdditionalGroups(getText(UserProfile.ADDITIONAL_GROUPS));
        currentUser.setRole(getSelection(UserProfile.USER_ROLE));
    }

    public boolean currentUserAlreadyExists() {
        setCurrentUser();
        return currentUser.validate() && userProfiles.contains(currentUser);
    }

    public boolean onLastPage() {
        return userProfiles.size() == index;
    }

    private void updateUserProfiles() throws DfException {
        if (index == userProfiles.size())
            userProfiles.add(currentUser);
        else
            userProfiles.set(index, currentUser);
        currentUser.runImportUserMethod(getDfSession());
    }

    private void updateControlsFromConfig() {
        DropDownList list = ((DropDownList) getControl(UserProfile.USER_ROLE, DropDownList.class));
        IConfigElement config = getRoleConfig();
        IConfigElement role = null;
        Option option = null;
        for (Iterator iter = config.getChildElements("role"); iter.hasNext(); list.addOption(option)) {
            role = (IConfigElement) iter.next();
            option = new Option();
            option.setValue(role.getAttributeValue("value"));
            option.setLabel(role.getAttributeValue("label"));
        }
        updateControlsFromRole(list.getValue());
    }

    private void updateControlsFromRole(String strRole) {
        IConfigElement config = getRoleConfig();
        config = config.getChildElement("role[value=" + strRole + "]");
        setText(UserProfile.GROUP_NAME, config.getChildValue(UserProfile.GROUP_NAME));
        setText(UserProfile.ACL_NAME, config.getChildValue(UserProfile.ACL_NAME));
        setText(UserProfile.ACL_DOMAIN, config.getChildValue(UserProfile.ACL_DOMAIN));
        setText(UserProfile.DEFAULT_FOLDER, config.getChildValue(UserProfile.DEFAULT_FOLDER));
        setSelection(UserProfile.CLIENT_CAPABILITY, config.getChildValue(UserProfile.CLIENT_CAPABILITY));
        setText(UserProfile.ADDITIONAL_GROUPS, config.getChildValue(UserProfile.ADDITIONAL_GROUPS));
    }

    private void clearUserControls() {
        setText(UserProfile.USER_NAME, "");
        ((Text) getControl(UserProfile.USER_NAME, Text.class)).setEnabled(true);
        setText(UserProfile.USER_OS_NAME, "");
        ((Text) getControl(UserProfile.USER_OS_NAME, Text.class)).setEnabled(true);
    }

    private void updateControlsFromUserObj(int i) {
        User user = (User) userProfiles.get(i);
        setText(UserProfile.USER_NAME, user.getUserName());
        ((Text) getControl(UserProfile.USER_NAME, Text.class)).setEnabled(false);
        setText(UserProfile.USER_OS_NAME, user.getUserOSName());
        ((Text) getControl(UserProfile.USER_OS_NAME, Text.class)).setEnabled(false);
        setSelection(UserProfile.USER_DOMAIN, user.getDomain());
        setText(UserProfile.GROUP_NAME, user.getUserGroupName());
        setText(UserProfile.ACL_NAME, user.getAclName());
        setText(UserProfile.ACL_DOMAIN, user.getAclDomain());
        setText(UserProfile.DEFAULT_FOLDER, user.getDefaultFolder());
        setSelection(UserProfile.CLIENT_CAPABILITY, user.getClientCapability());
        setText(UserProfile.ADDITIONAL_GROUPS, user.getAdditionalGroups());
        setSelection(UserProfile.USER_ROLE, user.getRole());
    }

    private void setText(String name, String value) {
        ((Text) getControl(name, Text.class)).setValue(value);
    }

    private String getText(String name) {
        String value = ((Text) getControl(name, Text.class)).getValue();
        if (value == null) value = "";
        return value;
    }

    private void setSelection(String name, String value) {
        ((DropDownList) getControl(name, DropDownList.class)).setValue(value);
    }

    private String getSelection(String name) {
        return ((DropDownList) getControl(name, DropDownList.class)).getValue();
    }

    private void increment() throws DfException {
        updateUserProfiles();
        index++;
    }

    private void decrement() {
        index--;
    }

    public boolean isEmpty() {
        return userProfiles.isEmpty();
    }

    public User getUser(int i) {
        return (User) userProfiles.get(i);
    }

    public int getTotalUsers() {
        return userProfiles.size();
    }
}
