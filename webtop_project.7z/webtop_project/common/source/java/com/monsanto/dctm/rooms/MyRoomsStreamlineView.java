package com.monsanto.dctm.rooms;

import com.monsanto.dctm.monAppContext.MonAppContextService;

public class MyRoomsStreamlineView extends
                                   com.documentum.webtop.webcomponent.rooms.MyRoomsStreamlineView {

    protected String getColumnsPreferenceId() {
        return super.getColumnsPreferenceId() + "." +
               MonAppContextService.getMonAppContextService().getMonAppContextInternalName();
    }

}
