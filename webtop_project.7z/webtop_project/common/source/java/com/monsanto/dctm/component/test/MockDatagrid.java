/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.component.test;

import com.documentum.web.form.control.databound.DataProvider;
import com.documentum.web.form.control.databound.Datagrid;

/**
 * Filename:    $RCSfile: MockDatagrid.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: lakench $    	 On:	$Date: 2007-08-21 05:23:14 $
 *
 * @author lakench
 * @version $Revision: 1.1 $
 */
public class MockDatagrid extends Datagrid {
  private MockDataProvider mockDataProvider = null;

  public DataProvider getDataProvider() {
    if (mockDataProvider == null) {
      mockDataProvider = new MockDataProvider(this);
    }
    return mockDataProvider;
  }
}