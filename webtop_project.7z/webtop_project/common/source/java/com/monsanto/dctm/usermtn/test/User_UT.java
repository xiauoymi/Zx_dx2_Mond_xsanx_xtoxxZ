/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.usermtn.test;

import com.documentum.fc.client.DfUser;
import com.documentum.fc.client.IDfSysObject;
import com.documentum.fc.client.MockSession;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfId;
import com.documentum.fc.common.DfLoginInfo;
import com.documentum.fc.common.impl.DfLdifFileReader;
import com.monsanto.dctm.component.test.MockDfUser;
import com.monsanto.dctm.component.test.MockSessionManager;
import com.monsanto.dctm.component.test.MockSysObject;
import com.monsanto.dctm.usermtn.User;
import junit.framework.TestCase;

import java.io.File;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;

/**
 * Filename:    $RCSfile: User_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ussing $    	 On:	$Date:
 * 2007/05/12 05:29:56 $
 *
 * @author LAKENCH
 * @version $Revision: 1.3 $
 */
public class User_UT extends TestCase {
  public User user;
  private static final String TESTUSERNAME = "testusername";
  private static final String TESTUSEROSNAME = "testuserosname";
  private static final String TESTDOMAIN = "testdomain";
  private static final String TESTUSERADDRESS = TESTUSEROSNAME + "@monsanto.com";
  private static final String TESTUSERSOURCE = "testusersource";
  private static final String TESTFOLDERNOLEADINGSLASH = "testfolder";
  private static final String TESTFOLDER = "/" + TESTFOLDERNOLEADINGSLASH;
  private static final String TESTGROUPNAME = "testgroup";
  private static final String TESTACLNAME = "testaclname";
  private static final String TESTACLDOMAIN = "testacldomain";
  private static final String TESTCLIENTCAPABILITY = "0";
  private static final String TESTROLE = "testrole";
  private static final String TESTDOCBASE = "testdocbase";
  private static final String TESTADDITIONALGROUPS = "anothergroup,yetanothergroup";
  public static final int LINES_IN_USER_FILE = 13;

  protected void setUp() throws Exception {
    super.setUp();
    user = new MockUser();
    user.setUserName(TESTUSERNAME);
    user.setUserGroupName(TESTGROUPNAME);
    user.setAclName(TESTACLNAME);
    user.setAclDomain(TESTACLDOMAIN);
    user.setClientCapability(TESTCLIENTCAPABILITY);
    user.setAdditionalGroups(TESTADDITIONALGROUPS);
    user.setRole(TESTROLE);
  }

  public void testCreate() throws Exception {
    assertNotNull(user);
  }

  public void testUserName() throws Exception {
    assertEquals(TESTUSERNAME, user.getUserName());
  }

  public void testUserOSName() throws Exception {
    user.setUserOSName(TESTUSEROSNAME);
    assertEquals(TESTUSEROSNAME, user.getUserOSName());
  }

  public void testUserAddressWithoutSettingUserOSNameFirst() throws Exception {
    user.setUserAddress();
    assertEquals("", user.getUserAddress());
  }

  public void testSetUserAddressWithoutAtMonsantoDotCom() throws Exception {
    user.setUserAddress(TESTUSEROSNAME);
    assertEquals("", user.getUserAddress());
  }

  public void testSetUserAddressWithAtMonsantoDotCom() throws Exception {
    user.setUserAddress(TESTUSERADDRESS);
    assertEquals(TESTUSERADDRESS, user.getUserAddress());
  }

  public void testUserAddress() throws Exception {
    user.setUserOSName(TESTUSEROSNAME);
    assertEquals(TESTUSERADDRESS, user.getUserAddress());
  }

  public void testDomainDefault() throws Exception {
    assertEquals(User.DEFAULT_DOMAIN, user.getDomain());
  }

  public void testDomain() throws Exception {
    user.setDomain(TESTDOMAIN);
    assertEquals(TESTDOMAIN, user.getDomain());
  }

  public void testUserSourceDefault() throws Exception {
    assertEquals(User.DEFUALT_USER_SOURCE, user.getUserSource());
  }

  public void testUserSource() throws Exception {
    user.setUserSource(TESTUSERSOURCE);
    assertEquals(TESTUSERSOURCE, user.getUserSource());
  }

  public void testNullDefaultFolder() throws Exception {
    user.setDefaultFolder(null);
    assertEquals("", user.getDefaultFolder());
  }

  public void testDefaultFolderWithNoLeadingSlash() throws Exception {
    user.setDefaultFolder(TESTFOLDERNOLEADINGSLASH);
    assertEquals(TESTFOLDER, user.getDefaultFolder());
  }

  public void testDefaultFolder() throws Exception {
    user.setDefaultFolder(TESTFOLDER);
    assertEquals(TESTFOLDER, user.getDefaultFolder());
  }

  public void testUserGroupName() throws Exception {
    assertEquals(TESTGROUPNAME, user.getUserGroupName());
  }

  public void testAclName() throws Exception {
    assertEquals(TESTACLNAME, user.getAclName());
  }

  public void testAclDomain() throws Exception {
    assertEquals(TESTACLDOMAIN, user.getAclDomain());
  }

  public void testClientCapability() throws Exception {
    assertEquals(TESTCLIENTCAPABILITY, user.getClientCapability());
  }

  public void testAdditionalGroups() throws Exception {
    assertEquals(TESTADDITIONALGROUPS, user.getAdditionalGroups());
  }

  public void testRole() throws Exception {
    assertEquals(TESTROLE, user.getRole());
  }

  public void testToStringWithoutSettingUserOSNameFirst() throws Exception {
    assertNull(user.toString());
  }

  public void testToString() throws Exception {
    user.setUserOSName(TESTUSEROSNAME);
    assertEquals(TESTUSEROSNAME, user.toString());
  }

  public void testEqualsNonUserObject() throws Exception {
    assertFalse(user.equals(new Object()));
  }

  public void testEqualsSameUserObject() throws Exception {
    assertTrue(user.equals(user));
  }

  public void testEqualsUserObjectWithSameUserName() throws Exception {
    User newUser = new User();
    newUser.setUserName(TESTUSERNAME);
    assertTrue(user.equals(newUser));
  }

  public void testEqualsUserObjectWithSameUserOSName() throws Exception {
    User newUser = new User();
    newUser.setUserOSName(TESTUSEROSNAME);
    user.setUserOSName(TESTUSEROSNAME);
    assertTrue(user.equals(newUser));
  }

  public void testCreateDctmUserObject() throws Exception {
    MockSessionManager mockSessionManager = new MockSessionManager();
    MockSession session = setupSession(mockSessionManager, TESTUSEROSNAME, "testticket", TESTUSERNAME);
    ((MockSessionManager) mockSessionManager).setSession(session);
    user.setUserOSName(TESTUSEROSNAME);
    user.setDefaultFolder(TESTFOLDER);
    user.setUserSource(TESTUSERSOURCE);
    user.setDomain(TESTDOMAIN);
//    user.setUserLoginName(TESTUSEROSNAME);
//    user.setUserLoginDomain(TESTDOMAIN);

    user.runImportUserMethod(session);

    assertApplyCallArguments(session);
    assertNewUserObject(session);
    assertUserFileContents();
  }

  private MockSession setupSession(MockSessionManager sessionManager, String userid, String ticket,
                                   String userName) throws DfException {
    DfLoginInfo loginInfo = new DfLoginInfo();
    loginInfo.setUser(userid);
    loginInfo.setPassword(ticket);
    sessionManager.setIdentity(TESTDOCBASE, loginInfo);
    MockSession session = (MockSession) sessionManager.getSession(TESTDOCBASE);
    session.setDocbaseName(TESTDOCBASE);
    MockDfUser dfUser = new MockDfUser();
    dfUser.setUserName(userName);
    dfUser.setClientCapability(DfUser.DF_CAPABILITY_COORDINATOR);
    session.addUser(dfUser);
    session.setLoginUserName(userName);
    session.setDocbaseName(TESTDOCBASE);
    return session;
  }

  private void assertNewUserObject(MockSession session) throws DfException {
    IDfSysObject object = (IDfSysObject) session.getObject(new DfId("newdmdocument"));
    assertTrue(((MockSysObject) object).wasDestroyCalled);
    assertEquals("crtext", object.getContentType());
    assertEquals("New Users", object.getObjectName());
    assertEquals(((MockUser) user).tempFile.getAbsolutePath(), object.getFile(null));
  }

  private void assertApplyCallArguments(MockSession session) throws DfException {
    assertNull(session.applyObjId);
    assertEquals("DO_METHOD", session.applyFunctionName);
    assertEquals(3, session.applyArgs.getCount());
    assertEquals(3, session.applyDataType.getCount());
    assertEquals(3, session.applyValues.getCount());

    assertEquals("METHOD", session.applyArgs.get(0));
    assertEquals("SAVE_RESULTS", session.applyArgs.get(1));
    assertEquals("ARGUMENTS", session.applyArgs.get(2));

    assertEquals("S", session.applyDataType.get(0));
    assertEquals("B", session.applyDataType.get(1));
    assertEquals("S", session.applyDataType.get(2));

    assertEquals("import_user", session.applyValues.get(0));
    assertEquals("TRUE", session.applyValues.get(1));
    String expectedValues = "'-docbase " + TESTDOCBASE + " -userid " + TESTUSEROSNAME +
        " -ticket loginticket -userinfoid newdmdocument" +
        " -additional_groups " + TESTADDITIONALGROUPS + "'";
    assertEquals(expectedValues, session.applyValues.get(2));
  }

  private void assertUserFileContents() throws IOException {
    DfLdifFileReader reader = new DfLdifFileReader(((MockUser) user).tempFile);
    reader.open();
    List section = reader.readSection();
    assertEquals(LINES_IN_USER_FILE, section.size());
    assertNameValuePair(new String[]{User.OBJECT_TYPE, User.DM_USER}, (String[]) section.get(0));
    assertNameValuePair(new String[]{User.USER_NAME, TESTUSERNAME}, (String[]) section.get(1));
    assertNameValuePair(new String[]{User.USER_OS_NAME, TESTUSEROSNAME}, (String[]) section.get(2));
    assertNameValuePair(new String[]{User.USER_OS_DOMAIN, TESTDOMAIN}, (String[]) section.get(3));
    assertNameValuePair(new String[]{User.USER_ADDRESS, TESTUSERADDRESS}, (String[]) section.get(4));
    assertNameValuePair(new String[]{User.USER_SOURCE, TESTUSERSOURCE}, (String[]) section.get(5));
    assertNameValuePair(new String[]{User.USER_GROUP_NAME, TESTGROUPNAME}, (String[]) section.get(6));
    assertNameValuePair(new String[]{User.ACL_NAME, TESTACLNAME}, (String[]) section.get(7));
    assertNameValuePair(new String[]{User.ACL_DOMAIN, TESTACLDOMAIN}, (String[]) section.get(8));
    assertNameValuePair(new String[]{User.DEFAULT_FOLDER, TESTFOLDER}, (String[]) section.get(9));
    assertNameValuePair(new String[]{User.CLIENT_CAPABILITY, TESTCLIENTCAPABILITY}, (String[]) section.get(10));
    assertNameValuePair(new String[]{User.USER_LOGIN_NAME, TESTUSEROSNAME}, (String[]) section.get(11));
    assertNameValuePair(new String[]{User.USER_LOGIN_DOMAIN, TESTDOMAIN}, (String[]) section.get(12));
  }

  private void assertNameValuePair(String[] expectedNameValuePair, String[] actualNameValuePair) {
    assertEquals(Arrays.asList(expectedNameValuePair), Arrays.asList(actualNameValuePair));
  }

  public class MockUser extends User {
    public File tempFile;

    protected File getTempFile() throws IOException {
      tempFile = super.getTempFile();
      return tempFile;
    }

    /**
     * @noinspection RefusedBequest
     */
    protected void deleteTempFile(File userFile) {
      userFile.deleteOnExit();
    }
  }
}