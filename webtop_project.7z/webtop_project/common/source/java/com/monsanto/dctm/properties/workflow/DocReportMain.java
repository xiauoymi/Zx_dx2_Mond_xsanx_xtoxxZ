/*
 * DocReportMain.java
 *
 * Created on November 16, 2005, 11:08 AM
 *
 * To change this template, choose Tools | Options and locate the template under
 * the Source Creation and Management node. Right-click the template and choose
 * Open. You can then make changes to the template in the Source Editor.
 */

package com.monsanto.dctm.properties.workflow;

import com.documentum.web.common.ArgumentList;
import com.documentum.web.form.Control;
import com.documentum.web.form.Form;
import com.documentum.web.form.control.Panel;
import com.documentum.web.form.control.databound.DataDropDownList;
import com.documentum.web.formext.docbase.FolderUtil;
import com.documentum.webcomponent.library.workflow.reportmain.ReportMain;

/**
 * @author tsvedan
 */
public class DocReportMain extends ReportMain {

  /**
   * Creates a new instance of DocReportMain
   */
  public DocReportMain() {
  }

  public void onInit(ArgumentList arg) {
    super.onInit(arg);
    String saveDetails = lookupString("savedetailsreport");
    if (saveDetails != null && saveDetails.length() > 0)
      m_saveDetailsReport = Boolean.valueOf(saveDetails).booleanValue();
    m_workflowType = 4;
    String typeStr = arg.get("workflowType");
    if (typeStr != null && typeStr.length() > 0)
      m_workflowType = Integer.parseInt(typeStr);
    m_showFilter = 2;
    String filterStr = arg.get("workflowFilter");
    if (filterStr != null && filterStr.length() > 0)
      m_showFilter = Integer.parseInt(filterStr);
    String tempStr = arg.get("overdueDays");
    if (tempStr != null && tempStr.length() != 0)
      m_overdueDays = Integer.parseInt(tempStr);
    else
      m_overdueDays = 0;
    m_settingParam = arg.get("workflowTypeParam");
    if (m_workflowType == 4 && (m_settingParam == null || m_settingParam.length() == 0))
      m_settingParam = arg.get("objectId");
    m_visibleColumns = getColumnVisibility();
    if (FolderUtil.isFolderType(m_settingParam)) {
      ((Panel) getControl("versions_panel", com.documentum.web.form.control.Panel.class)).setVisible(false);
    } else {
      String strVersionsComboQuery = getVersionsComboQuery(m_settingParam);
      DataDropDownList versionsCombo = (DataDropDownList) getControl("version_filter",
          com.documentum.web.form.control.databound.DataDropDownList.class);
      versionsCombo.getDataProvider().setQuery(strVersionsComboQuery);
      versionsCombo.getDataProvider().setDfSession(getDfSession());
      versionsCombo.setValue(m_settingParam);
    }
    updateControls();
    Control container = getContainer();
    if (container instanceof Form)
      ((Form) container).setModal(false);
    setModal(false);
  }

  public void onSelectVersionFilter(DataDropDownList control, ArgumentList args) {
    m_settingParam = control.getValue();
    updateControls();
  }

  private String getVersionsComboQuery(String strObjectId) {
    StringBuffer buf = new StringBuffer(256);
    buf.append("SELECT r_object_id,r_version_label FROM dm_sysobject (all) WHERE i_chronicle_id IN ")
        .append("(SELECT i_chronicle_id_i FROM dm_sysobject (all) WHERE r_object_id_i = '").append(strObjectId)
        .append("') ORDER BY r_modify_date DESC, r_object_id");
    return buf.toString();
  }

  public static final String STR_VERSIONS_FILTER = "version_filter";
  public static final String STR_VERSIONS_PANEL = "versions_panel";
}
