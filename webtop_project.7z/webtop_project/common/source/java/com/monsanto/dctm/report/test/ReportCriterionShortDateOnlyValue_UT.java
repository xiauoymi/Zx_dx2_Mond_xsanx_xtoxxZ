/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.report.test;

import com.monsanto.dctm.component.test.MockForm;
import com.monsanto.dctm.report.ReportCriterionShortDateOnlyValue;
import junit.framework.TestCase;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Filename:    $RCSfile: ReportCriterionShortDateOnlyValue_UT.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: lakench $    	 On:	$Date: 2007-04-25 16:51:05 $
 *
 * @author LAKENCH
 * @version $Revision: 1.1 $
 */
public class ReportCriterionShortDateOnlyValue_UT extends TestCase {
    public void testCreate() throws Exception {
        MockForm mockForm = new MockForm();
        ReportCriterionShortDateOnlyValue control = (ReportCriterionShortDateOnlyValue) mockForm
                .createControl("testcontrol", ReportCriterionShortDateOnlyValue.class);
        assertNotNull(control);
    }

    public void testNonSetValue() throws Exception {
        MockForm mockForm = new MockForm();
        ReportCriterionShortDateOnlyValue control = (ReportCriterionShortDateOnlyValue) mockForm
                .createControl("testcontrol", ReportCriterionShortDateOnlyValue.class);
        String value = control.getValue();
        String expectedDate = new SimpleDateFormat("MM/dd/yyyy").format(new Date());
        assertEquals(expectedDate, value);
    }

    public void testBadDateValue() throws Exception {
        MockForm mockForm = new MockForm();
        ReportCriterionShortDateOnlyValue control = (ReportCriterionShortDateOnlyValue) mockForm
                .createControl("testcontrol", ReportCriterionShortDateOnlyValue.class);
        control.setValue("test value");
        String value = control.getValue();
        String expectedDate = new SimpleDateFormat("MM/dd/yyyy").format(new Date());
        assertEquals(expectedDate, value);
    }

    public void testGetShortDate() throws Exception {
        MockForm mockForm = new MockForm();
        ReportCriterionShortDateOnlyValue control = (ReportCriterionShortDateOnlyValue) mockForm
                .createControl("testcontrol", ReportCriterionShortDateOnlyValue.class);
        control.setValue("Apr 20, 2007 12:32:56 PM");
        String value = control.getValue();
        assertEquals("04/20/2007", value);
    }
}