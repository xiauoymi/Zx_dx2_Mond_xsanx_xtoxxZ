/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.appconfig.test;

import com.documentum.web.formext.component.Component;
import com.monsanto.dctm.appconfig.AppConfigAuthRequestors;
import com.monsanto.dctm.appconfig.LaunchComponent;
import com.monsanto.dctm.component.test.MockComponent;
import junit.framework.TestCase;

import java.util.HashMap;
import java.util.Map;

/**
 * Filename:    $RCSfile: LaunchComponent_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: lakench $    	 On:	$Date: 2007-08-24 21:29:43 $
 *
 * @author lakench
 * @version $Revision: 1.2 $
 */
public class LaunchComponent_UT extends TestCase {
  public void testCreate() throws Exception {
    LaunchComponent launchComponent = new LaunchComponent();
    assertNotNull(launchComponent);
  }

  public void testDontAddActionCompleteListener() throws Exception {
    MockLaunchComponent launchComponent = new MockLaunchComponent();
    HashMap completionArgs = new HashMap();
    MockComponent component = new MockComponent();
    launchComponent.addCallingComponentAsActionCompleteListenerIfItIsOne(component, completionArgs);
    assertFalse(completionArgs.containsValue(component));
  }

  public void testAddActionCompleteListener() throws Exception {
    MockLaunchComponent launchComponent = new MockLaunchComponent();
    HashMap completionArgs = new HashMap();
    AppConfigAuthRequestors component = new AppConfigAuthRequestors();
    launchComponent.addCallingComponentAsActionCompleteListenerIfItIsOne(component, completionArgs);
    assertTrue(completionArgs.containsValue(component));
  }

  public class MockLaunchComponent extends LaunchComponent {
    protected void addCallingComponentAsActionCompleteListenerIfItIsOne(Component component, Map completionArgs) {
      super.addCallingComponentAsActionCompleteListenerIfItIsOne(component, completionArgs);
    }
  }
}