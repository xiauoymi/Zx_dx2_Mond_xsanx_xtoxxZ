package com.monsanto.dctm.report;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;

import com.documentum.web.form.Control;
import com.documentum.web.form.IVisitor;

public class FindCriterionValue implements IVisitor {
	
	private String criteriaObjName;
	private ArrayList criterionValues;
	
	public FindCriterionValue(String criteriaObjName)
	{
		this.criteriaObjName = null;
		criterionValues = null;
		setCriteriaObjName(criteriaObjName);
	}
	
	public boolean visit(Control control) {
		if(control instanceof ReportCriterionValue)
		{
			ReportCriterionValue value = (ReportCriterionValue)control;
			String criteria = value.getCriteria();
			if(criteria != null && value.isEnabled() && criteria.equals(criteriaObjName))
			{
				if(criterionValues == null)
					criterionValues = new ArrayList(3);
				criterionValues.add(value);
			}
		}
		return true;
	}
	
	public void setCriteriaObjName(String criteriaObjName) {
		this.criteriaObjName = criteriaObjName;
	}
	
	public Iterator getCriterionValues() {
		Iterator it = Collections.EMPTY_LIST.iterator();
		if(criterionValues != null)
			it = criterionValues.iterator();
		return it;
	}
	
}
