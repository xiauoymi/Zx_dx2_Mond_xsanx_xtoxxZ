package com.monsanto.dctm.monAppContext;

import com.documentum.fc.common.DfException;
import com.documentum.web.formext.session.SavedCredentialsAuthenticationScheme;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class SavedCredentialsAndSetMonAppContextAuthenticationScheme extends
                                                                     SavedCredentialsAuthenticationScheme {

    public String authenticate(HttpServletRequest request, HttpServletResponse response, String docbase) throws
                                                                                                         DfException {

        String strDocbase = super.authenticate(request, response, docbase);

        setMonAppContext(strDocbase);

        return strDocbase;
    }

    protected void setMonAppContext(String strDocbase) {
        if (strDocbase != null) {
            IMonAppContextService monAppContextService = MonAppContextService.getMonAppContextService(strDocbase);
            monAppContextService.setMonAppContext();
        }
    }

}
