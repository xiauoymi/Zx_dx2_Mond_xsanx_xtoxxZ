/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.usermtn.test;

import com.documentum.fc.client.IDfSessionManager;
import com.documentum.fc.client.MockSession;
import com.documentum.fc.common.DfLoginInfo;
import com.documentum.fc.common.IDfLoginInfo;
import com.documentum.web.form.ComponentTestUtils;
import com.documentum.web.form.control.DropDownList;
import com.documentum.web.form.control.Label;
import com.documentum.web.form.control.Option;
import com.documentum.web.form.control.Text;
import com.documentum.web.form.control.validator.RequiredFieldValidator;
import com.monsanto.dctm.component.test.MockSessionManager;
import com.monsanto.dctm.usermtn.DuplicateUserValidator;
import com.monsanto.dctm.usermtn.User;
import com.monsanto.dctm.usermtn.UserProfile;
import junit.framework.TestCase;

import java.util.List;

/**
 * Filename:    $RCSfile: UserProfile_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: lakench $    	 On:	$Date:
 * 2007/05/12 05:29:56 $
 *
 * @author lakench
 * @version $Revision: 1.3 $
 */
public class UserProfile_UT extends TestCase {

  private MockUserProfile component;
  private static final String TEST_USER_NAME_JOEMINER = "Joe Miner";
  private static final String TEST_USER_OS_NAME_JOEMINER = "joeminer";
  private static final String TEST_USER_NAME_TESTUSER = "Test User";
  private static final String TEST_USER_OS_NAME_TESTUSER = "testuser";
  public IDfSessionManager mockSessionManager;

  protected void setUp() throws Exception {
    super.setUp();
    mockSessionManager = new MockSessionManager();
    MockSession session = new MockSession(mockSessionManager);
    session.setLoginUserName(TEST_USER_NAME_TESTUSER);
    session.setDocbaseName("testdocbase");
    IDfLoginInfo loginInfo = new DfLoginInfo();
    loginInfo.setUser(TEST_USER_OS_NAME_TESTUSER);
    session.setLoginInfo(loginInfo);
    ((MockSessionManager) mockSessionManager).setSession(session);
    component = (MockUserProfile) ComponentTestUtils
        .getComponent(MockUserProfile.class, "userprofile", "testdocbase", mockSessionManager);
    component.initializeComponent();
  }

  protected void tearDown() throws Exception {
    ComponentTestUtils.releaseComponent(component);
    super.tearDown();
  }

  public void testInitialize() throws Exception {
    assertEquals(mockSessionManager, component.getSessionManager());
    assertInitialState();

  }

  public void testSelectNewRole() throws Exception {
    DropDownList list = ((DropDownList) component.getControl(UserProfile.USER_ROLE));
    list.setValue(MockUserProfile.AUTHOR_ROLE_VALUE);
    component.onSelectRole(list, null);
    assertEquals(MockUserProfile.AUTHOR_ROLE_VALUE, list.getValue());
    assertAuthorControls();
    assertEquals(UserProfile.CONTRIBUTOR, getSelection(UserProfile.CLIENT_CAPABILITY));
    assertTrue(component.isEmpty());
    assertErrorMessageControlStyle();

    assertNavStatesOnFirstPage();

    assertErrorMessage(null);
  }

  public void testOnNextWithNoUserName() throws Exception {
    assertFalse(component.onNextPage());
    assertTrue(component.triedToValidate);
    RequiredFieldValidator validator = (RequiredFieldValidator) component
        .getControl(UserProfile.USER_NAME + "_validator");
    assertEquals("Enter User's Name (Ex. Lastname Firstname M)", validator.getErrorMessage());
    assertFalse(validator.getIsValid());
  }

  public void testOnNextWithUserNameButNoUserOSNmae() throws Exception {
    Text userNameControl = (Text) component.getControl(UserProfile.USER_NAME, Text.class);
    userNameControl.setValue(TEST_USER_NAME_JOEMINER);
    assertFalse(component.onNextPage());
    assertTrue(component.triedToValidate);
    RequiredFieldValidator validator = (RequiredFieldValidator) component
        .getControl(UserProfile.USER_OS_NAME + "_validator");
    assertEquals("Enter User's OS Name (Network Id)", validator.getErrorMessage());
    assertFalse(validator.getIsValid());
  }

  public void testValidOnNext() throws Exception {
    addUser(MockUserProfile.USER_ROLE_VALUE, TEST_USER_NAME_JOEMINER, TEST_USER_OS_NAME_JOEMINER);
    DuplicateUserValidator control = (DuplicateUserValidator) component.getControl("duplicateuservalidator");
    assertTrue(control.getIsValid());
    assertEquals(1, component.getTotalUsers());
    assertUserRole(component.getUser(0), TEST_USER_NAME_JOEMINER, TEST_USER_OS_NAME_JOEMINER);

    assertStateAfterAddingUserWithUserRole();
  }

  public void testAddTwoUsers() throws Exception {
    addUser(MockUserProfile.USER_ROLE_VALUE, TEST_USER_NAME_JOEMINER, TEST_USER_OS_NAME_JOEMINER);
    assertStateAfterAddingUserWithUserRole();

    addUser(MockUserProfile.AUTHOR_ROLE_VALUE, TEST_USER_NAME_TESTUSER, TEST_USER_OS_NAME_TESTUSER);
    assertStateAfterAddingUserWithAuthorRole();
    DuplicateUserValidator control = (DuplicateUserValidator) component.getControl("duplicateuservalidator");
    assertTrue(control.getIsValid());

    assertEquals(2, component.getTotalUsers());
    assertUserRole(component.getUser(0), TEST_USER_NAME_JOEMINER, TEST_USER_OS_NAME_JOEMINER);
    assertAuthorRole(component.getUser(1), TEST_USER_NAME_TESTUSER, TEST_USER_OS_NAME_TESTUSER);

  }

  public void testCancelChanges() throws Exception {
    assertTrue(component.onCancelChanges());
    assertInitialState();
  }

  public void testCancelAfterAddingOneUser() throws Exception {
    addUser(MockUserProfile.USER_ROLE_VALUE, TEST_USER_NAME_JOEMINER, TEST_USER_OS_NAME_JOEMINER);
    assertStateAfterAddingUserWithUserRole();
    assertTrue(component.onCancelChanges());
    assertStateAfterAddingUserWithUserRole();
  }

  public void testCancelAfterAddingTwoUsers() throws Exception {
    addUser(MockUserProfile.USER_ROLE_VALUE, TEST_USER_NAME_JOEMINER, TEST_USER_OS_NAME_JOEMINER);
    addUser(MockUserProfile.AUTHOR_ROLE_VALUE, TEST_USER_NAME_TESTUSER, TEST_USER_OS_NAME_TESTUSER);
    assertStateAfterAddingUserWithAuthorRole();
    assertTrue(component.onCancelChanges());
    assertStateAfterAddingUserWithAuthorRole();
  }

  public void testCommitChangesWithNoUserName() throws Exception {
    assertFalse(component.onCommitChanges());
    assertTrue(component.triedToValidate);
    RequiredFieldValidator validator = (RequiredFieldValidator) component
        .getControl(UserProfile.USER_NAME + "_validator");
    assertEquals("Enter User's Name (Ex. Lastname Firstname M)", validator.getErrorMessage());
    assertFalse(validator.getIsValid());
  }

  public void testCommitChangesWithUserNameButNoUserOSNmae() throws Exception {
    Text userNameControl = (Text) component.getControl(UserProfile.USER_NAME, Text.class);
    userNameControl.setValue(TEST_USER_NAME_JOEMINER);
    assertFalse(component.onCommitChanges());
    assertTrue(component.triedToValidate);
    RequiredFieldValidator validator = (RequiredFieldValidator) component
        .getControl(UserProfile.USER_OS_NAME + "_validator");
    assertEquals("Enter User's OS Name (Network Id)", validator.getErrorMessage());
    assertFalse(validator.getIsValid());
  }

  public void testValidOnCommitChanges() throws Exception {
    setUserNameAndUserOSName(TEST_USER_NAME_JOEMINER, TEST_USER_OS_NAME_JOEMINER);
    assertTrue(component.onCommitChanges());
    assertTrue(component.triedToValidate);
    DuplicateUserValidator control = (DuplicateUserValidator) component.getControl("duplicateuservalidator");
    assertTrue(control.getIsValid());
    assertEquals(1, component.getTotalUsers());
    assertUserRole(component.getUser(0), TEST_USER_NAME_JOEMINER, TEST_USER_OS_NAME_JOEMINER);

    assertStateAfterAddingUserWithUserRole();
  }

  public void testOnCommitAfterAddingOneUserAndSettingUpForSecond() throws Exception {
    addUser(MockUserProfile.USER_ROLE_VALUE, TEST_USER_NAME_JOEMINER, TEST_USER_OS_NAME_JOEMINER);
    setupUser(MockUserProfile.AUTHOR_ROLE_VALUE, TEST_USER_NAME_TESTUSER, TEST_USER_OS_NAME_TESTUSER);
    assertTrue(component.onCommitChanges());
    assertStateAfterAddingUserWithAuthorRole();
    DuplicateUserValidator control = (DuplicateUserValidator) component.getControl("duplicateuservalidator");
    assertTrue(control.getIsValid());

    assertEquals(2, component.getTotalUsers());
    assertUserRole(component.getUser(0), TEST_USER_NAME_JOEMINER, TEST_USER_OS_NAME_JOEMINER);
    assertAuthorRole(component.getUser(1), TEST_USER_NAME_TESTUSER, TEST_USER_OS_NAME_TESTUSER);
  }

  public void testOnPrevAfterInitialize() throws Exception {
    assertFalse(component.onPrevPage());
    assertFalse(component.triedToValidate);
    component.triedToValidate = false;
    assertInitialState();
  }

  public void testOnPrevAfterAddOneUser() throws Exception {
    addUser(MockUserProfile.USER_ROLE_VALUE, TEST_USER_NAME_JOEMINER, TEST_USER_OS_NAME_JOEMINER);
    assertTrue(component.onPrevPage());
    assertUserControlsSetFromUserObject(TEST_USER_NAME_JOEMINER, TEST_USER_OS_NAME_JOEMINER, false);

  }

  public void testOnPrevAfterAddTwoUsers() throws Exception {
    addUser(MockUserProfile.USER_ROLE_VALUE, TEST_USER_NAME_JOEMINER, TEST_USER_OS_NAME_JOEMINER);
    addUser(MockUserProfile.AUTHOR_ROLE_VALUE, TEST_USER_NAME_TESTUSER, TEST_USER_OS_NAME_TESTUSER);
    assertTrue(component.onPrevPage());
    assertAuthorControlsSetFromUserObject(TEST_USER_NAME_TESTUSER, TEST_USER_OS_NAME_TESTUSER, false);
  }

  public void testOnPrevTwiceAfterAddTwoUsers() throws Exception {
    addUser(MockUserProfile.USER_ROLE_VALUE, TEST_USER_NAME_JOEMINER, TEST_USER_OS_NAME_JOEMINER);
    addUser(MockUserProfile.AUTHOR_ROLE_VALUE, TEST_USER_NAME_TESTUSER, TEST_USER_OS_NAME_TESTUSER);
    assertTrue(component.onPrevPage());
    assertAuthorControlsSetFromUserObject(TEST_USER_NAME_TESTUSER, TEST_USER_OS_NAME_TESTUSER, false);
    assertTrue(component.onPrevPage());
    assertUserControlsSetFromUserObject(TEST_USER_NAME_JOEMINER, TEST_USER_OS_NAME_JOEMINER, false);
  }

  public void testUpdateUserAfterPrev() throws Exception {
    addUser(MockUserProfile.USER_ROLE_VALUE, TEST_USER_NAME_JOEMINER, TEST_USER_OS_NAME_JOEMINER);
    addUser(MockUserProfile.AUTHOR_ROLE_VALUE, TEST_USER_NAME_TESTUSER, TEST_USER_OS_NAME_TESTUSER);
    component.onPrevPage();
    component.onPrevPage();
    selectRole(MockUserProfile.AUTHOR_ROLE_VALUE);
    component.onNextPage();
    assertAuthorRole(component.getUser(0), TEST_USER_NAME_JOEMINER,
        TEST_USER_OS_NAME_JOEMINER);
    assertAuthorControlsSetFromUserObject(TEST_USER_NAME_TESTUSER, TEST_USER_OS_NAME_TESTUSER, false);
    component.onNextPage();
    assertAuthorControlsSetFromUserObject("", "", true);
  }

  public void testUpdateOnPrev() throws Exception {
    addUser(MockUserProfile.USER_ROLE_VALUE, TEST_USER_NAME_JOEMINER, TEST_USER_OS_NAME_JOEMINER);
    addUser(MockUserProfile.AUTHOR_ROLE_VALUE, TEST_USER_NAME_TESTUSER, TEST_USER_OS_NAME_TESTUSER);
    component.onPrevPage();
    component.onPrevPage();
    selectRole(MockUserProfile.AUTHOR_ROLE_VALUE);
    assertTrue(component.onNextPage());
    assertAuthorRole(component.getUser(0), TEST_USER_NAME_JOEMINER,
        TEST_USER_OS_NAME_JOEMINER);
    assertAuthorControlsSetFromUserObject(TEST_USER_NAME_TESTUSER, TEST_USER_OS_NAME_TESTUSER, false);
    selectRole(MockUserProfile.USER_ROLE_VALUE);
    component.onPrevPage();
    assertUserRole(component.getUser(1), TEST_USER_NAME_TESTUSER, TEST_USER_OS_NAME_TESTUSER);
    assertAuthorControlsSetFromUserObject(TEST_USER_NAME_JOEMINER, TEST_USER_OS_NAME_JOEMINER, false);
    component.onNextPage();
    assertUserControlsSetFromUserObject(TEST_USER_NAME_TESTUSER, TEST_USER_OS_NAME_TESTUSER, false);
  }

  public void testInvalidUpdateOnPrev() throws Exception {
    addUser(MockUserProfile.USER_ROLE_VALUE, TEST_USER_NAME_JOEMINER, TEST_USER_OS_NAME_JOEMINER);
    addUser(MockUserProfile.AUTHOR_ROLE_VALUE, TEST_USER_NAME_TESTUSER, TEST_USER_OS_NAME_TESTUSER);
    component.onPrevPage();
    component.onPrevPage();
    selectRole(MockUserProfile.AUTHOR_ROLE_VALUE);
    component.onNextPage();
    assertAuthorRole(component.getUser(0), TEST_USER_NAME_JOEMINER,
        TEST_USER_OS_NAME_JOEMINER);
    assertAuthorControlsSetFromUserObject(TEST_USER_NAME_TESTUSER, TEST_USER_OS_NAME_TESTUSER, false);
    selectRole(MockUserProfile.USER_ROLE_VALUE);
    setText(UserProfile.ACL_NAME, "");
    assertFalse(component.onPrevPage());
    assertUserNameAndUserOSName(TEST_USER_NAME_TESTUSER, TEST_USER_OS_NAME_TESTUSER, false);
  }

  public void testValidate() throws Exception {
    addUser(MockUserProfile.USER_ROLE_VALUE, TEST_USER_NAME_JOEMINER, TEST_USER_OS_NAME_JOEMINER);
    component.onPrevPage();
    component.validate();
    assertTrue(component.getIsValid());
    setSelection(UserProfile.USER_DOMAIN, "");
    component.validate();
    assertTrue(component.getIsValid());
    blankTextControlAndVerifyErrorMessage(UserProfile.GROUP_NAME, "Enter Default Group");
    assertFalse(component.getIsValid());
    blankTextControlAndVerifyErrorMessage(UserProfile.ACL_NAME, "Enter Default ACL");
    assertFalse(component.getIsValid());
    blankTextControlAndVerifyErrorMessage(UserProfile.ACL_DOMAIN, "Enter ACL Domain");
    assertFalse(component.getIsValid());
    blankTextControlAndVerifyErrorMessage(UserProfile.DEFAULT_FOLDER, "Enter Default Folder");
    assertFalse(component.getIsValid());
    blankDropDownControlAndVerifyErrorMessage(UserProfile.CLIENT_CAPABILITY, "Select Client Capability");
    assertFalse(component.getIsValid());
  }

  private void blankTextControlAndVerifyErrorMessage(String controlName, String errorMessage) {
    RequiredFieldValidator validator = (RequiredFieldValidator) component
        .getControl(controlName + "_validator");
    assertTrue(validator.getIsValid());
    String origValue = getText(controlName);
    setText(controlName, "");
    component.validate();
    assertEquals(errorMessage, validator.getErrorMessage());
    assertFalse(validator.getIsValid());
    setText(controlName, origValue);
  }

  private void blankDropDownControlAndVerifyErrorMessage(String controlName, String errorMessage) {
    RequiredFieldValidator validator = (RequiredFieldValidator) component
        .getControl(controlName + "_validator");
    assertTrue(validator.getIsValid());
    String origValue = getSelection(controlName);
    setSelection(controlName, "");
    component.validate();
    assertEquals(errorMessage, validator.getErrorMessage());
    assertFalse(validator.getIsValid());
    setSelection(controlName, origValue);
  }

  public void testAddDuplicateUser() throws Exception {
    addUser(MockUserProfile.USER_ROLE_VALUE, TEST_USER_NAME_JOEMINER, TEST_USER_OS_NAME_JOEMINER);
    addDuplicateUser(MockUserProfile.AUTHOR_ROLE_VALUE, TEST_USER_NAME_JOEMINER, TEST_USER_OS_NAME_JOEMINER);
  }

  public void testAddDuplicateUserDifferentOSName() throws Exception {
    addUser(MockUserProfile.USER_ROLE_VALUE, TEST_USER_NAME_JOEMINER, TEST_USER_OS_NAME_JOEMINER);
    addDuplicateUser(MockUserProfile.AUTHOR_ROLE_VALUE, TEST_USER_NAME_JOEMINER, TEST_USER_OS_NAME_TESTUSER);
  }

  public void testAddDuplcateUserDifferentUserName() throws Exception {
    addUser(MockUserProfile.USER_ROLE_VALUE, TEST_USER_NAME_JOEMINER, TEST_USER_OS_NAME_JOEMINER);
    addDuplicateUser(MockUserProfile.AUTHOR_ROLE_VALUE, TEST_USER_NAME_TESTUSER, TEST_USER_OS_NAME_JOEMINER);
  }

  private void assertInitialState() {
    assertRoleDropDownOptions();
    assertEquals(MockUserProfile.USER_ROLE_VALUE, getSelection(UserProfile.USER_ROLE));
    assertUserControls();

    assertTrue(component.isEmpty());
    assertErrorMessageControlStyle();

    assertNavStatesOnFirstPage();
    assertErrorMessage(null);
  }

  private void assertRoleDropDownOptions() {
    DropDownList list = ((DropDownList) component.getControl(UserProfile.USER_ROLE));
    List options = list.getOptions();
    Option option1 = (Option) options.get(0);
    Option option2 = (Option) options.get(1);
    assertEquals(MockUserProfile.USER_ROLE_VALUE, option1.getValue());
    assertEquals(MockUserProfile.USER_ROLE_LABEL, option1.getLabel());
    assertEquals(MockUserProfile.AUTHOR_ROLE_VALUE, option2.getValue());
    assertEquals(MockUserProfile.AUTHOR_ROLE_LABEL, option2.getLabel());
  }

  private void assertErrorMessageControlStyle() {
    Label errorMessageControl = (Label) component.getControl("errmsg");
    assertEquals("color: red", errorMessageControl.getCssStyle());
  }

  private void assertNavStatesOnFirstPage() {
    assertTrue(component.canCancelChanges());
    assertFalse(component.triedToValidate);
    assertTrue(component.hasNextPage());
    assertFalse(component.triedToValidate);
    assertFalse(component.hasPrevPage());
    assertFalse(component.triedToValidate);
    assertTrue(component.canCommitChanges());
    assertFalse(component.triedToValidate);
  }

  private void assertUserControls() {
    assertFirstUserControls();
    assertEquals(MockUserProfile.TEST_USER_FOLDER, getText(UserProfile.DEFAULT_FOLDER));
  }

  private void assertUserControlsSetFromUserObject(String userName, String userOSName, boolean shouldBeEnabled) {
    assertEquals(MockUserProfile.USER_ROLE_VALUE, getSelection(UserProfile.USER_ROLE));
    assertFirstUserControls();
    assertEquals("/" + MockUserProfile.TEST_USER_FOLDER, getText(UserProfile.DEFAULT_FOLDER));
    assertUserNameAndUserOSName(userName, userOSName, shouldBeEnabled);
  }

  private void assertFirstUserControls() {
    assertEquals(MockUserProfile.TEST_USER_GROUP, getText(UserProfile.GROUP_NAME));
    assertEquals(MockUserProfile.TEST_USER_ACL, getText(UserProfile.ACL_NAME));
    assertEquals(MockUserProfile.TEST_USER_ACL_DOMAIN, getText(UserProfile.ACL_DOMAIN));
    assertEquals(UserProfile.CONSUMER, getSelection(UserProfile.CLIENT_CAPABILITY));
    assertEquals(MockUserProfile.TEST_USER_ADDITIONALGROUPS, getText(UserProfile.ADDITIONAL_GROUPS));
  }

  private void assertStateAfterAddingUserWithUserRole() {
    assertStateAfterAddUser();
    assertUserControls();
  }

  private void assertStateAfterAddUser() {
    assertTrue(component.hasPrevPage());
    assertUserNameAndUserOSName("", "", true);
  }

  private void assertStateAfterAddingUserWithAuthorRole() {
    assertStateAfterAddUser();
    assertAuthorControls();
  }

  private void assertUserNameAndUserOSName(String userName, String userOSName, boolean shouldBeEnabled) {
    assertEquals(userName, getText(UserProfile.USER_NAME));
    assertEquals(shouldBeEnabled, ((Text) component.getControl(UserProfile.USER_NAME)).isEnabled());
    assertEquals(userOSName, getText(UserProfile.USER_OS_NAME));
    assertEquals(shouldBeEnabled, ((Text) component.getControl(UserProfile.USER_OS_NAME)).isEnabled());
  }

  private void assertAuthorControls() {
    assertFirstAuthorControls();
    assertEquals(MockUserProfile.TEST_AUTHOR_FOLDER, getText(UserProfile.DEFAULT_FOLDER));
  }

  private void assertAuthorControlsSetFromUserObject(String userName, String userOSName, boolean shouldBeEnabled) {
    assertFirstAuthorControls();
    assertEquals("/" + MockUserProfile.TEST_AUTHOR_FOLDER, getText(UserProfile.DEFAULT_FOLDER));
    assertUserNameAndUserOSName(userName, userOSName, shouldBeEnabled);
  }

  private void assertFirstAuthorControls() {
    assertEquals(MockUserProfile.AUTHOR_ROLE_VALUE, getSelection(UserProfile.USER_ROLE));
    assertEquals(MockUserProfile.TEST_AUTHOR_GROUP, getText(UserProfile.GROUP_NAME));
    assertEquals(MockUserProfile.TEST_AUTHOR_ACL, getText(UserProfile.ACL_NAME));
    assertEquals(MockUserProfile.TEST_AUTHOR_ACL_DOMAIN, getText(UserProfile.ACL_DOMAIN));
    assertEquals(UserProfile.CONTRIBUTOR, getSelection(UserProfile.CLIENT_CAPABILITY));
    assertEquals(MockUserProfile.TEST_AUTHOR_ADDITIONALGROUPS, getText(UserProfile.ADDITIONAL_GROUPS));
  }

  private void assertErrorMessage(String errorMessage) {
    Label errorMessageControl = (Label) component.getControl("errmsg");
    assertEquals(errorMessage, errorMessageControl.getLabel());
  }

  private void addUser(String role, String userName, String userOSName) {
    setupUser(role, userName, userOSName);
    assertTrue(component.onNextPage());
    assertTrue(component.triedToValidate);
    component.triedToValidate = false;
  }

  private void addDuplicateUser(String role, String userName, String userOSName) {
    setupUser(role, userName, userOSName);
    assertFalse(component.onNextPage());
    assertTrue(component.triedToValidate);
    component.triedToValidate = false;
    DuplicateUserValidator control = (DuplicateUserValidator) component.getControl("duplicateuservalidator");
    assertFalse(control.getIsValid());
  }

  private void setupUser(String role, String userName, String userOSName) {
    selectRole(role);
    setUserNameAndUserOSName(userName, userOSName);
  }

  private void selectRole(String role) {
    ((DropDownList) component.getControl(UserProfile.USER_ROLE)).setValue(role);
    component.onSelectRole(((DropDownList) component.getControl(UserProfile.USER_ROLE)), null);
  }

  private void setUserNameAndUserOSName(String userName, String userOSName) {
    ((Text) component.getControl(UserProfile.USER_NAME, Text.class)).setValue(userName);
    ((Text) component.getControl(UserProfile.USER_OS_NAME, Text.class)).setValue(userOSName);
  }

  private void assertUserRole(User user, String userName, String userOSName) {
    assertBaseRoleInfo(userName, user, userOSName);
    assertEquals(MockUserProfile.TEST_USER_GROUP, user.getUserGroupName());
    assertEquals(MockUserProfile.TEST_USER_ACL, user.getAclName());
    assertEquals(MockUserProfile.TEST_USER_ACL_DOMAIN, user.getAclDomain());
    assertEquals("/" + MockUserProfile.TEST_USER_FOLDER, user.getDefaultFolder());
    assertEquals(MockUserProfile.TEST_USER_ADDITIONALGROUPS, user.getAdditionalGroups());
    assertEquals(UserProfile.CONSUMER, user.getClientCapability());
  }

  private void assertAuthorRole(User user, String userName, String userOSName) {
    assertBaseRoleInfo(userName, user, userOSName);
    assertEquals(MockUserProfile.TEST_AUTHOR_GROUP, user.getUserGroupName());
    assertEquals(MockUserProfile.TEST_AUTHOR_ACL, user.getAclName());
    assertEquals(MockUserProfile.TEST_AUTHOR_ACL_DOMAIN, user.getAclDomain());
    assertEquals("/" + MockUserProfile.TEST_AUTHOR_FOLDER, user.getDefaultFolder());
    assertEquals(MockUserProfile.TEST_AUTHOR_ADDITIONALGROUPS, user.getAdditionalGroups());
    assertEquals(UserProfile.CONTRIBUTOR, user.getClientCapability());
  }

  private void assertBaseRoleInfo(String userName, User user, String userOSName) {
    assertEquals(userName, user.getUserName());
    assertEquals(userOSName, user.getUserOSName());
    assertEquals(User.DEFAULT_DOMAIN, user.getDomain());
    assertEquals(userOSName + User.EMAIL_SUFFIX, user.getUserAddress());
  }

  private String getText(String name) {
    return ((Text) component.getControl(name)).getValue();
  }

  private void setText(String name, String value) {
    ((Text) component.getControl(name, Text.class)).setValue(value);
  }

  private String getSelection(String name) {
    return ((DropDownList) component.getControl(name)).getValue();
  }

  private void setSelection(String name, String value) {
    ((DropDownList) component.getControl(name, DropDownList.class)).setValue(value);
  }
}