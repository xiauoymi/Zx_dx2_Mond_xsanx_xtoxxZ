package com.monsanto.dctm.search;

import com.documentum.fc.client.search.IDfQueryDefinition;
import com.documentum.fc.client.search.IDfSearchMetadataManager;
import com.documentum.fc.client.search.impl.DfSmartListDefinition;
import com.documentum.fc.client.search.impl.DfXMLUtil;
import com.documentum.fc.common.DfException;
import org.w3c.dom.Document;
import org.w3c.dom.Node;

public class MonSmartListDefinition extends DfSmartListDefinition {

  public MonSmartListDefinition(IDfSearchMetadataManager metadataManager, Document doc) throws DfException {
    this(metadataManager);
    DfXMLUtil.getNode(doc, "SmartListDefinition", true);
    IDfQueryDefinition queryDef = MonQueryManager.readQueryDefinition(metadataManager, doc);
    setQueryDefinition(queryDef);
    readXMLDisplayPref(doc);
    readXMLProperties(doc);
  }

  /**
   * @param metadataManager
   *
   * @exception DfException
   */
  public MonSmartListDefinition(IDfSearchMetadataManager metadataManager) throws DfException {
    super(metadataManager);
    setQueryDefinition(new MonQueryBuilder(metadataManager));
  }

  private void readXMLDisplayPref(Document doc)
      throws DfException {
    Node node = DfXMLUtil.getNode(doc, "DisplayPreferences", true);
    Node[] childNodes = DfXMLUtil.getChildNodes(node, "DisplayAttributeList", false);
    if (childNodes.length > 0) {
      childNodes = DfXMLUtil.getChildNodes(childNodes[0], "DisplayAttribute", false);
      for (int i = 0; i < childNodes.length; i++) {
        String displayAttr = DfXMLUtil.getAttribute(childNodes[i], "name", true);
        addDisplayAttribute(displayAttr);
      }

    }
  }

  private void readXMLProperties(Document doc)
      throws DfException {
    Node node = DfXMLUtil.getNode(doc, "PropertyList", true);
    Node[] childNodes = DfXMLUtil.getChildNodes(node, "Property", false);
    for (int i = 0; i < childNodes.length; i++) {
      String propName = DfXMLUtil.getAttribute(childNodes[i], "name", true);
      String propValue = DfXMLUtil.getAttribute(childNodes[i], "value", true);
      addProperty(propName, propValue);
    }
  }

}
