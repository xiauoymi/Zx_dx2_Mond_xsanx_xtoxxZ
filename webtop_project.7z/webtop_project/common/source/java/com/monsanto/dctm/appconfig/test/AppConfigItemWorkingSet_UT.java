/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.appconfig.test;

import com.documentum.fc.client.IDfPersistentObject;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.MockSession;
import com.documentum.fc.common.DfException;
import com.documentum.web.form.control.databound.ColumnDescriptor;
import com.documentum.web.form.control.databound.ScrollableResultSet;
import com.monsanto.dctm.appconfig.AppConfigColumnDescriptor;
import com.monsanto.dctm.appconfig.AppConfigItem;
import com.monsanto.dctm.appconfig.AppConfigItemWorkingSet;
import com.monsanto.dctm.appconfig.AppConfigOwnerWorkingSet;
import com.monsanto.dctm.component.test.MockPersistentObject;
import junit.framework.TestCase;

import java.util.*;

/**
 * Filename:    $RCSfile: AppConfigItemWorkingSet_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: lakench $
 * On:	$Date: 2007-08-24 21:30:26 $
 *
 * @author lakench
 * @version $Revision: 1.2 $
 */
public class AppConfigItemWorkingSet_UT extends TestCase {
  public void testCreateAndValidInitialization() throws Exception {

    MockAppConfigItemWorkingSet requestorWorkingSet = new MockAppConfigItemWorkingSet("testappcontext",
        new MockSession(), "mon_app_owner_info");
    assertNotNull(requestorWorkingSet);

    List requestorsList = generateActualResultsFromResultSet(requestorWorkingSet.getResultSet());

    assertEquals(1, requestorsList.size());
    List expectedRequestorsRow = generateDefaultExpectedRow("0");
    assertEquals(expectedRequestorsRow, requestorsList.get(0));

    IDfPersistentObject appOwnerObject = requestorWorkingSet.getAppOwnerObject();
    assertNotNull(appOwnerObject);
    assertEquals("testappcontext", appOwnerObject.getString("mon_app_context"));
    assertEquals("testappcontext_app_owners", appOwnerObject.getString("object_name"));
  }

  private List generateDefaultExpectedRow(String rowid) {
    List expectedRequestorsRow = new ArrayList(4);
    expectedRequestorsRow.add(rowid);
    expectedRequestorsRow.add("All");
    expectedRequestorsRow.add("Authorized User Not on Record");
    expectedRequestorsRow.add("eedocu@monsanto.com");
    return expectedRequestorsRow;
  }

  public void testInitializeFromExistingAppOwnerObject() throws Exception {
    MockSession session = new MockSession();
    MockPersistentObject testAppOwnerInfoObject = new MockPersistentObject();
    setupTestAppOwnerInfoObjectAndAddToSession(testAppOwnerInfoObject, session);

    MockAppConfigItemWorkingSet requestorWorkingSet = new MockAppConfigItemWorkingSet("testappcontext", session,
        "mon_app_owner_info");
    assertNotNull(requestorWorkingSet);

    List requestorsList = generateActualResultsFromResultSet(requestorWorkingSet.getResultSet());

    assertEquals(3, requestorsList.size());
    List expectedRequestorsRow = new ArrayList(3);
    expectedRequestorsRow.add("0");
    expectedRequestorsRow.add("area1");
    expectedRequestorsRow.add("name1");
    expectedRequestorsRow.add("email1");
    assertEquals(expectedRequestorsRow, requestorsList.get(0));
    expectedRequestorsRow = new ArrayList(3);
    expectedRequestorsRow.add("1");
    expectedRequestorsRow.add("area2");
    expectedRequestorsRow.add("name2");
    expectedRequestorsRow.add("email2");
    assertEquals(expectedRequestorsRow, requestorsList.get(1));
    expectedRequestorsRow = new ArrayList(3);
    expectedRequestorsRow.add("2");
    expectedRequestorsRow.add("area3");
    expectedRequestorsRow.add("name3");
    expectedRequestorsRow.add("email3");
    assertEquals(expectedRequestorsRow, requestorsList.get(2));

    IDfPersistentObject appOwnerObject = requestorWorkingSet.getAppOwnerObject();
    assertSame(testAppOwnerInfoObject, appOwnerObject);
  }

  public void testGetColumnNames() throws Exception {

    AppConfigItemWorkingSet appConfigItemWorkingSet = AppConfigItemWorkingSet
        .createAppConfigItemWorkingSet("testappcontext", new MockSession(), "mon_app_owner_info");
    List columnNames = appConfigItemWorkingSet.getColumnNames();
    ColumnDescriptor columnDescriptor1 = (ColumnDescriptor) columnNames.get(0);
    ColumnDescriptor columnDescriptor2 = (ColumnDescriptor) columnNames.get(1);
    ColumnDescriptor columnDescriptor3 = (ColumnDescriptor) columnNames.get(2);
    ColumnDescriptor columnDescriptor4 = (ColumnDescriptor) columnNames.get(3);
    assertEquals("rowid", columnDescriptor1.getAttribute());
    assertEquals("Row ID", columnDescriptor1.getLabel());
    assertFalse(columnDescriptor1.isVisible());
    assertEquals("area", columnDescriptor2.getAttribute());
    assertEquals("Site", columnDescriptor2.getLabel());
    assertTrue(columnDescriptor2.isVisible());
    assertEquals("name", columnDescriptor3.getAttribute());
    assertEquals("Name", columnDescriptor3.getLabel());
    assertTrue(columnDescriptor3.isVisible());
    assertEquals("email", columnDescriptor4.getAttribute());
    assertEquals("Email", columnDescriptor4.getLabel());
    assertTrue(columnDescriptor4.isVisible());
  }

  public void testAddRequestors() throws Exception {

    AppConfigItemWorkingSet appConfigItemWorkingSet = AppConfigItemWorkingSet
        .createAppConfigItemWorkingSet("testappcontext", new MockSession(), "mon_app_owner_info");
    assertNotNull(appConfigItemWorkingSet);


    List expectedDefaultRequestorsRow = generateDefaultExpectedRow("0");
    List expectedTestRow = new ArrayList(4);
    expectedTestRow.add("testarea1");
    expectedTestRow.add("testname1");
    expectedTestRow.add("testemail1");
    AppConfigItem appConfigItem1 = generateAppConfigItem(expectedTestRow, false);

    appConfigItemWorkingSet.addAppConfigItem(appConfigItem1);
    expectedTestRow.add(0, "1");

    List requestorsList = generateActualResultsFromResultSet(appConfigItemWorkingSet.getResultSet());
    assertEquals(1, requestorsList.size());
    assertFalse(requestorsList.contains(expectedDefaultRequestorsRow));
    assertTrue(requestorsList.contains(expectedTestRow));

    List expectedTestRow2 = new ArrayList(4);
    expectedTestRow2.add("testarea2");
    expectedTestRow2.add("testname2");
    expectedTestRow2.add("testemail2");
    AppConfigItem appConfigItem2 = generateAppConfigItem(expectedTestRow2, false);

    appConfigItemWorkingSet.addAppConfigItem(appConfigItem2);
    expectedTestRow2.add(0, "2");

    requestorsList = generateActualResultsFromResultSet(appConfigItemWorkingSet.getResultSet());
    assertEquals(2, requestorsList.size());
    assertFalse(requestorsList.contains(expectedDefaultRequestorsRow));
    assertTrue(requestorsList.contains(expectedTestRow));
    assertTrue(requestorsList.contains(expectedTestRow2));
  }

  private AppConfigItem generateAppConfigItem(List expectedTestRow, boolean addRowIdColumn) {
    Map itemValues = new HashMap(3);
    List columnNames = createColumnDescriptors();
    if (addRowIdColumn) {
      columnNames.add(0, new AppConfigColumnDescriptor("rowid", "Row ID", false, false, "0"));
    }
    Iterator columns = columnNames.iterator();
    int colIndex = 0;
    while (columns.hasNext()) {
      String columnName = ((AppConfigColumnDescriptor) columns.next()).getColumnName();
      itemValues.put(columnName, expectedTestRow.get(colIndex));
      colIndex++;
    }
    return new AppConfigItem("mon_app_owner", itemValues);
  }

  public void testRemoveOnlyRequestor() throws Exception {

    AppConfigItemWorkingSet appConfigItemWorkingSet = AppConfigItemWorkingSet
        .createAppConfigItemWorkingSet("testappcontext", new MockSession(), "mon_app_owner_info");
    assertNotNull(appConfigItemWorkingSet);


    List expectedDefaultRequestorsRow = generateDefaultExpectedRow("2");
    List expectedTestRow = new ArrayList(4);
    expectedTestRow.add("testarea1");
    expectedTestRow.add("testname1");
    expectedTestRow.add("testemail1");
    AppConfigItem appConfigItem1 = generateAppConfigItem(expectedTestRow, false);

    appConfigItemWorkingSet.addAppConfigItem(appConfigItem1);
    expectedTestRow.add(0, "1");
    AppConfigItem appConfigToRemove = generateAppConfigItem(expectedTestRow, true);

    List requestorsList = generateActualResultsFromResultSet(appConfigItemWorkingSet.getResultSet());
    assertEquals(1, requestorsList.size());

    appConfigItemWorkingSet.removeAppConfigItem(appConfigToRemove);
    requestorsList = generateActualResultsFromResultSet(appConfigItemWorkingSet.getResultSet());
    assertEquals(1, requestorsList.size());
    assertTrue(requestorsList.contains(expectedDefaultRequestorsRow));
    assertFalse(requestorsList.contains(expectedTestRow));
  }

  public void testRemoveRequestor() throws Exception {

    AppConfigItemWorkingSet appConfigItemWorkingSet = AppConfigItemWorkingSet
        .createAppConfigItemWorkingSet("testappcontext", new MockSession(), "mon_app_owner_info");
    assertNotNull(appConfigItemWorkingSet);

    List expectedDefaultRequestorsRow = generateDefaultExpectedRow("0");
    List expectedTestRow = generateExpectedTestRow("1");
    AppConfigItem appConfigItem1 = generateAppConfigItem(expectedTestRow, false);

    appConfigItemWorkingSet.addAppConfigItem(appConfigItem1);
    expectedTestRow.add(0, "1");
    AppConfigItem appConfigItemToRemove = generateAppConfigItem(expectedTestRow, true);

    List requestorsList = generateActualResultsFromResultSet(appConfigItemWorkingSet.getResultSet());
    assertEquals(1, requestorsList.size());
    assertFalse(requestorsList.contains(expectedDefaultRequestorsRow));
    assertTrue(requestorsList.contains(expectedTestRow));

    List expectedTestRow2 = generateExpectedTestRow("2");
    AppConfigItem appConfigItem2 = generateAppConfigItem(expectedTestRow2, false);

    appConfigItemWorkingSet.addAppConfigItem(appConfigItem2);
    expectedTestRow2.add(0, "2");

    requestorsList = generateActualResultsFromResultSet(appConfigItemWorkingSet.getResultSet());
    assertEquals(2, requestorsList.size());
    assertFalse(requestorsList.contains(expectedDefaultRequestorsRow));
    assertTrue(requestorsList.contains(expectedTestRow));
    assertTrue(requestorsList.contains(expectedTestRow2));

    appConfigItemWorkingSet.removeAppConfigItem(appConfigItemToRemove);
    requestorsList = generateActualResultsFromResultSet(appConfigItemWorkingSet.getResultSet());
    assertEquals(1, requestorsList.size());
    assertFalse(requestorsList.contains(expectedDefaultRequestorsRow));
    assertFalse(requestorsList.contains(expectedTestRow));
    assertTrue(requestorsList.contains(expectedTestRow2));
  }

  private List generateExpectedTestRow(String valueSuffix) {
    List expectedTestRow = new ArrayList(4);
    expectedTestRow.add("testarea" + valueSuffix);
    expectedTestRow.add("testname" + valueSuffix);
    expectedTestRow.add("testemail" + valueSuffix);
    return expectedTestRow;
  }

  public void testRemoveNonExistentRequestor() throws Exception {

    AppConfigItemWorkingSet appConfigItemWorkingSet = AppConfigItemWorkingSet
        .createAppConfigItemWorkingSet("testappcontext", new MockSession(), "mon_app_owner_info");
    assertNotNull(appConfigItemWorkingSet);

    List expectedDefaultRequestorsRow = generateDefaultExpectedRow("0");
    List expectedTestRow = generateExpectedTestRow("1");
    AppConfigItem appConfigItem1 = generateAppConfigItem(expectedTestRow, false);

    appConfigItemWorkingSet.addAppConfigItem(appConfigItem1);
    expectedTestRow.add(0, "1");

    List requestorsList = generateActualResultsFromResultSet(appConfigItemWorkingSet.getResultSet());
    assertEquals(1, requestorsList.size());
    assertFalse(requestorsList.contains(expectedDefaultRequestorsRow));
    assertTrue(requestorsList.contains(expectedTestRow));

    List expectedTestRow2 = generateExpectedTestRow("2");
    AppConfigItem appConfigItem2 = generateAppConfigItem(expectedTestRow2, false);

    appConfigItemWorkingSet.addAppConfigItem(appConfigItem2);
    expectedTestRow2.add(0, "2");

    requestorsList = generateActualResultsFromResultSet(appConfigItemWorkingSet.getResultSet());
    assertEquals(2, requestorsList.size());
    assertFalse(requestorsList.contains(expectedDefaultRequestorsRow));
    assertTrue(requestorsList.contains(expectedTestRow));
    assertTrue(requestorsList.contains(expectedTestRow2));

    appConfigItemWorkingSet.removeAppConfigItem(new AppConfigItem("testtype"));
    requestorsList = generateActualResultsFromResultSet(appConfigItemWorkingSet.getResultSet());
    assertEquals(2, requestorsList.size());
    assertFalse(requestorsList.contains(expectedDefaultRequestorsRow));
    assertTrue(requestorsList.contains(expectedTestRow));
    assertTrue(requestorsList.contains(expectedTestRow2));
  }

  public void testSave() throws Exception {
    MockSession session = new MockSession();
    MockPersistentObject testAppOwnerInfoObject = new MockPersistentObject();
    setupTestAppOwnerInfoObjectAndAddToSession(testAppOwnerInfoObject, session);

    MockAppConfigItemWorkingSet requestorWorkingSet = new MockAppConfigItemWorkingSet("testappcontext", session,
        "mon_app_owner_info");
    List testRequestorToRemove = new ArrayList(3);
    testRequestorToRemove.add("area2");
    testRequestorToRemove.add("name2");
    testRequestorToRemove.add("email2");
    AppConfigItem appConfigItemToRemove = generateAppConfigItem(testRequestorToRemove, false);
    appConfigItemToRemove.set("rowid", "1");

    requestorWorkingSet.removeAppConfigItem(appConfigItemToRemove);
    List testRequestor = generateExpectedTestRow("1");
    AppConfigItem appConfigItem1 = generateAppConfigItem(testRequestor, false);
    requestorWorkingSet.addAppConfigItem(appConfigItem1);
    List testRequestor2 = generateExpectedTestRow("2");
    AppConfigItem appConfigItem2 = generateAppConfigItem(testRequestor2, false);
    requestorWorkingSet.addAppConfigItem(appConfigItem2);

    requestorWorkingSet.save();

    IDfPersistentObject appOwnerObject = requestorWorkingSet.getAppOwnerObject();
    assertSame(testAppOwnerInfoObject, appOwnerObject);
    String actualAreas = appOwnerObject.getAllRepeatingStrings("area", ",");
    String actualNames = appOwnerObject.getAllRepeatingStrings("name", ",");
    String actualEmails = appOwnerObject.getAllRepeatingStrings("email", ",");

    assertEquals("area1,area3,testarea1,testarea2", actualAreas);
    assertEquals("name1,name3,testname1,testname2", actualNames);
    assertEquals("email1,email3,testemail1,testemail2", actualEmails);
  }

  public void testGetResultSet() throws Exception {
    MockSession session = new MockSession();
    MockPersistentObject testAppOwnerInfoObject = new MockPersistentObject();
    setupTestAppOwnerInfoObjectAndAddToSession(testAppOwnerInfoObject, session);

    AppConfigItemWorkingSet appConfigItemWorkingSet = AppConfigItemWorkingSet
        .createAppConfigItemWorkingSet("testappcontext", session, "mon_app_owner_info");
    ScrollableResultSet resultSet = appConfigItemWorkingSet.getResultSet();

    List expectedResults = generateExpectedResultsFromResultSet();

    List actualResults = generateActualResultsFromResultSet(resultSet);

    assertEquals(0, resultSet.findColumn("rowid"));
    assertEquals(1, resultSet.findColumn("area"));
    assertEquals(2, resultSet.findColumn("name"));
    assertEquals(3, resultSet.findColumn("email"));
    assertEquals(3, resultSet.getResultsCount());
    assertEquals(expectedResults, actualResults);
  }

  private List createColumnDescriptors() {
    List columnDescriptors = new ArrayList(4);
    columnDescriptors.add(new AppConfigColumnDescriptor("area", "Site", true, true, "All"));
    columnDescriptors.add(new AppConfigColumnDescriptor("name", "Name", true, true, "Authorized User Not on Record"));
    columnDescriptors.add(new AppConfigColumnDescriptor("email", "Email", true, true, "eedocu@monsanto.com"));
    return columnDescriptors;
  }

  private List generateActualResultsFromResultSet(ScrollableResultSet resultSet) {
    int resultsCount = resultSet.getResultsCount();
    List actualResults = new ArrayList(3);
    for (int i = 0; i < resultsCount; i++) {
      List row = new ArrayList(3);
      resultSet.next();
      row.add(resultSet.getObject(1));
      row.add(resultSet.getObject(2));
      row.add(resultSet.getObject(3));
      row.add(resultSet.getObject(4));
      actualResults.add(row);
    }
    return actualResults;
  }

  private List generateExpectedResultsFromResultSet() {
    List expectedResults = new ArrayList(3);
    List row1 = new ArrayList(3);
    row1.add("0");
    row1.add("area1");
    row1.add("name1");
    row1.add("email1");
    expectedResults.add(row1);
    List row2 = new ArrayList(3);
    row2.add("1");
    row2.add("area2");
    row2.add("name2");
    row2.add("email2");
    expectedResults.add(row2);
    List row3 = new ArrayList(3);
    row3.add("2");
    row3.add("area3");
    row3.add("name3");
    row3.add("email3");
    expectedResults.add(row3);
    return expectedResults;
  }

  private void setupTestAppOwnerInfoObjectAndAddToSession(MockPersistentObject testAppOwnerInfoObject,
                                                          MockSession session) throws DfException {
    testAppOwnerInfoObject.setString("object_name", "testappcontext_app_owners");
    testAppOwnerInfoObject.setString("mon_app_context", "testappcontext");
    ArrayList areas = new ArrayList(3);
    areas.add("area1");
    areas.add("area2");
    areas.add("area3");
    testAppOwnerInfoObject.setRepeatingStrings("area", areas);
    ArrayList names = new ArrayList(3);
    names.add("name1");
    names.add("name2");
    names.add("name3");
    testAppOwnerInfoObject.setRepeatingStrings("name", names);
    ArrayList emails = new ArrayList(3);
    emails.add("email1");
    emails.add("email2");
    emails.add("email3");
    testAppOwnerInfoObject.setRepeatingStrings("email", emails);
    session.addObject(testAppOwnerInfoObject);
    session.addObject(testAppOwnerInfoObject, "mon_app_owner_info where mon_app_context = 'testappcontext'");
  }

  public class MockAppConfigItemWorkingSet extends AppConfigOwnerWorkingSet {
    private IDfSession session;

    public MockAppConfigItemWorkingSet(String monAppContext, IDfSession session, String objectType) throws DfException {
      super(monAppContext, session, objectType);

      this.session = session;
    }

    public IDfPersistentObject getAppOwnerObject() throws DfException {
      return session.getObjectByQualification("all");
    }
  }
}