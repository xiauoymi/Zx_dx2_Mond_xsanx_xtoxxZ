/*
 Copyright:  Copyright � 2006 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.appconfig;

import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.IDfUser;
import com.documentum.fc.common.DfException;
import com.documentum.web.common.ArgumentList;
import com.documentum.web.common.WrapperRuntimeException;
import com.documentum.web.form.Form;
import com.documentum.web.form.IReturnListener;
import com.documentum.web.form.control.Label;
import com.documentum.web.form.control.Link;
import com.documentum.web.form.control.Text;
import com.documentum.web.formext.component.Component;
import com.documentum.webcomponent.library.locator.LocatorItemResultSet;

import java.util.HashMap;
import java.util.Map;

/**
 * Filename:    $RCSfile: AppConfigUpdateRequestor.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: lakench $
 * On:	$Date: 2007-08-21 05:23:14 $
 *
 * @author lakench
 * @version $Revision: 1.17 $
 */
public class AppConfigUpdateRequestor extends Component implements IReturnListener {
  public static final String INSTRUCTIONS = "instructions";
  public static final String AREA_COL_NAME = "area";
  public static final String NAME_COL_NAME = "name";
  public static final String SELECT_REQUESTOR_LINK = "selectrequestor";
  public static final String APP_CONFIG_ACTION_ARG = "appconfigaction";
  public static final String REMOVE = "remove";
  public static final String REMOVE_INSTRUCTIONS = "Are you sure you want to delete this Authorized Requestor?";
  public static final String ADD_INSTRUCTIONS = "Please enter the area this requestor is responsible for and choose the requestor.";
  public static final String EDIT_REQUESTOR_COMPONENT = "useronlylocatorcontainer";

  private String appConfigAction;
  private AppConfigItem appConfigItemToRemove;
  public static final String ROWID_COL_NAME = "rowid";
  public static final String EMAIL_COL_NAME = "email";
  public static final String APP_CONFIG_ITEM_TYPE = "mon_app_owner_info";
  public static final String LOCATOR_RESULT_ARG = "_locator_sel";

  public void onInit(ArgumentList argumentList) {
    super.onInit(argumentList);
    setupComponent(argumentList);
  }

  protected void setupComponent(ArgumentList argumentList) {
    appConfigAction = argumentList.get(APP_CONFIG_ACTION_ARG);
    Label instructionsControl = (Label) getControl(INSTRUCTIONS, Label.class);
    if (appConfigAction.equals(REMOVE)) {
      instructionsControl.setLabel(REMOVE_INSTRUCTIONS);
      Link selectRequestorControl = (Link) getControl(SELECT_REQUESTOR_LINK, Link.class);
      selectRequestorControl.setVisible(false);
      String requestorArea = argumentList.get(AREA_COL_NAME);
      String requestorName = argumentList.get(NAME_COL_NAME);
      Text areaControl = (Text) getControl(AREA_COL_NAME, Text.class);
      areaControl.setValue(requestorArea);
      areaControl.setEnabled(false);
      Label nameControl = (Label) getControl(NAME_COL_NAME, Label.class);
      nameControl.setLabel(requestorName);
      String rowid = argumentList.get(ROWID_COL_NAME);
      String requestorEmail = argumentList.get(EMAIL_COL_NAME);
      Map values = new HashMap(4);
      values.put(ROWID_COL_NAME, rowid);
      values.put(AREA_COL_NAME, requestorArea);
      values.put(NAME_COL_NAME, requestorName);
      values.put(EMAIL_COL_NAME, requestorEmail);
      appConfigItemToRemove = new AppConfigItem(APP_CONFIG_ITEM_TYPE, values);
    } else {
      instructionsControl.setLabel(ADD_INSTRUCTIONS);
    }
  }

  public void onClickEditRequestor(Link selectRequestorControl, ArgumentList args) {
    nestToEditRequestorComponent(args);
  }

  protected void nestToEditRequestorComponent(ArgumentList args) {
    // This is here because setComponentNested is final
    setComponentNested(EDIT_REQUESTOR_COMPONENT, args, getContext(), this);
  }

  public void onReturn(Form form, Map completionArgs) {
    if (completionArgs == null)
      return;
    IDfUser user = getUserFromCompletionArgs(completionArgs);
    String userName = null;
    try {
      userName = user.getUserName();
    } catch (DfException e) {
      throw new WrapperRuntimeException("couldn't get user name", e);
    }
    Label nameControl = (Label) getControl(NAME_COL_NAME, Label.class);
    nameControl.setLabel(userName);
  }

  protected IDfUser getUserFromCompletionArgs(Map completionArgs) {
    // This is only here because LocateItemResultSet calls SessionManagerHttpBinding.getSessionManager()
    //  in its constructor, therefore it is impossible to create or mock that class
    LocatorItemResultSet locatorSelections = (LocatorItemResultSet) completionArgs.get(LOCATOR_RESULT_ARG);
    if (locatorSelections != null && locatorSelections.first()) {
      return (IDfUser) locatorSelections.getPersistentObject();
    }
    return null;
  }

  public boolean onCommitChanges() {
    Text areaControl = (Text) getControl(AREA_COL_NAME, Text.class);
    String requestorArea = areaControl.getValue();
    Label nameControl = (Label) getControl(NAME_COL_NAME, Label.class);
    String requestorName = nameControl.getLabel();
    setReturnValue(APP_CONFIG_ACTION_ARG, appConfigAction);
    if (appConfigAction.equals(REMOVE)) {
      setReturnValue(AppConfigItemBaseComponent.REALLY_DELETE, "true");
      setReturnValue(AppConfigItemBaseComponent.APP_CONFIG_ITEM, appConfigItemToRemove);
    } else {
      setReturnValue(AppConfigItemBaseComponent.REALLY_ADD, "true");
      IDfSession session = getDfSession();
      try {
        IDfUser userObject = (IDfUser) session
            .getObjectByQualification("dm_user where user_name = '" + requestorName + "'");
        String requestorEmail = userObject.getUserAddress();
        Map returnValues = new HashMap(4);
        returnValues.put(ROWID_COL_NAME, "0");
        returnValues.put(AREA_COL_NAME, requestorArea);
        returnValues.put(NAME_COL_NAME, requestorName);
        returnValues.put(EMAIL_COL_NAME, requestorEmail);
        setReturnValue(AppConfigItemBaseComponent.APP_CONFIG_ITEM,
            new AppConfigItem(APP_CONFIG_ITEM_TYPE, returnValues));
      } catch (DfException e) {
        throw new WrapperRuntimeException(e);
      }
    }

    return super.onCommitChanges();
  }
}