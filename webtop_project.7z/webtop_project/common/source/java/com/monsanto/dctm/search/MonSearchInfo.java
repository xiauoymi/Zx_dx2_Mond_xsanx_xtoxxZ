package com.monsanto.dctm.search;

import com.documentum.fc.client.IDfSessionManager;
import com.documentum.fc.client.search.IDfSearchService;
import com.documentum.fc.client.search.impl.DfSearchService;
import com.documentum.web.formext.session.SessionManagerHttpBinding;
import com.documentum.webcomponent.library.search.SearchInfo;

public class MonSearchInfo extends SearchInfo {

  private transient IDfSearchService m_idfSearchService;

  public MonSearchInfo() {
    m_idfSearchService = null;
  }

  public void release(boolean fExecInfoOnly) {
    super.release(fExecInfoOnly);
    if (!fExecInfoOnly) {
      m_idfSearchService = null;
    }
  }

  public IDfSearchService getSearchService() {
    if (m_idfSearchService == null)
      m_idfSearchService = new MonSearchService(
          new DfSearchService(getSessionManager(), SessionManagerHttpBinding.getCurrentDocbase()));
    return m_idfSearchService;
  }

  protected IDfSessionManager getSessionManager() {
    return SessionManagerHttpBinding.getSessionManager();
  }
}
