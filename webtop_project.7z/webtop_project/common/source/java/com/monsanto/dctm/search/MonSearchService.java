package com.monsanto.dctm.search;

import com.documentum.fc.client.search.*;

public class MonSearchService implements IDfSearchService {

  private IDfSearchService searchService;

  public MonSearchService(IDfSearchService searchService) {
    this.searchService = searchService;
  }

  public IDfSearchSourceMap getSourceMap() {
    return searchService.getSourceMap();
  }

  public IDfQueryManager newQueryMgr() {
    return new MonQueryManager(searchService.newQueryMgr());
  }

  public IDfResultsManipulator newResultsManipulator(IDfQueryDefinition iDfQueryDefinition) {
    return searchService.newResultsManipulator(iDfQueryDefinition);
  }

  public IDfQueryProcessor newQueryProcessor(IDfQueryDefinition iDfQueryDefinition, boolean b) {
    return searchService.newQueryProcessor(iDfQueryDefinition, b);
  }

  public IDfResultObjectManager newResultObjectManager(IDfQueryDefinition iDfQueryDefinition) {
    return searchService.newResultObjectManager(iDfQueryDefinition);
  }
}
