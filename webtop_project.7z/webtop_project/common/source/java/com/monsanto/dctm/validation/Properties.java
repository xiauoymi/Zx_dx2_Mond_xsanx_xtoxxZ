/*
 * Created on May 17, 2005
 */
package com.monsanto.dctm.validation;


import com.documentum.web.common.ArgumentList;
import com.documentum.web.form.Control;
import com.documentum.web.form.control.Tab;
import com.documentum.web.form.control.Tabbar;
import com.documentum.web.formext.component.Component;
import com.documentum.web.formext.control.docbase.DocbaseObject;

import java.util.ArrayList;
import java.util.Iterator;

public class Properties extends com.documentum.webcomponent.library.properties.Properties {
    protected String strObjectType = "no_custom_validation";
    protected Component m_component;
    protected DocbaseObject m_docbaseObj;
    protected boolean doCustomValidation = false;
    protected CustomValidation customValidationObject = null;


    public void onOk(Control button, ArgumentList args) {
        if (doCustomValidation) {
            validate();
            if (getIsValid()) {
                if (canCommitChanges() && onCommitChanges()) {
                    if (getTopForm().getCallerForm() != null) {
                        setComponentReturn();
                    }
                }
            } else {
                ArrayList components = getContainedComponents();
                if (components.size() >= 1) {
                    Tabbar tabbar = (Tabbar) getControl("tabs", Tabbar.class);
                    Iterator tabs = tabbar.getTabs();
                    Tab tab = (Tab) tabs.next();
                    this.onTabSelected(tab, args);
                    tabbar.setValue(tab.getName());
                }
            }
        } else {
            super.onOk(button, args);
        }
    }

    public void onInit(ArgumentList args) {
        getControl("bookmark", com.monsanto.dctm.viewprocessor.BookmarkLink.class);
        super.onInit(args);
    }

    protected void validate(boolean bIgnoreDoValidateFlag) {
        if (doCustomValidation) {
            //Do custom validation
            boolean bIsValid = customValidationObject.isValid();
            if (!bIsValid)  // Did the custom validation fail?
            {
                setInvalid();  // Set the form to invalid
            } else  // Do the trick of turning off validation on the form, then
            // run validation to set the form back to valid
            {
                boolean bTempDoValidationFlag = getDoValidation(); //remember state of validation
                setDoValidation(false); // turn validation off
                super.validate(false);  //"setValid()" since validation is off
                setDoValidation(bTempDoValidationFlag); //reset validation
            }
        } else  //do regular validation
        {
            super.validate(bIgnoreDoValidateFlag);
        }
    }

    public void onRender() {
        if (doCustomValidation) //makes sure the error message is displayed correctly since something between validate and render resets it
        {
            customValidationObject.isValid();
        }
        super.onRender();
    }

    public void onRenderEnd() //does some initializing that has to occur after the docbase object tag exists
    {
        super.onRenderEnd();

        //The jsp must have a docbaseobject tag for this to run
        m_component = getContainedComponent();
        m_docbaseObj = (DocbaseObject) m_component.getControl("obj");

        // Get the right kind of custom validation object
        if (m_docbaseObj != null && customValidationObject == null) {
            CustomValidationFactory customValidationFactory = new CustomValidationFactory(this, m_docbaseObj);
            customValidationObject = customValidationFactory.getCustomValidationObject();
        }

        // Set the flag that determines whether or not we have to do custom validation
        if (customValidationObject != null) {
            doCustomValidation = customValidationObject.getDoCustomValidation();
        }
    }
}
