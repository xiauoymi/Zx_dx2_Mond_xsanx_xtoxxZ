/*
 * ModifyAttrValue.java
 *
 * Created on January 20, 2006, 2:33 PM
 *
 * To change this template, choose Tools | Options and locate the template under
 * the Source Creation and Management node. Right-click the template and choose
 * Open. You can then make changes to the template in the Source Editor.
 */

package com.monsanto.dctm.codelookup;

import com.documentum.com.DfClientX;
import com.documentum.com.IDfClientX;
import com.documentum.fc.client.*;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.IDfAttr;
import com.documentum.nls.NlsResourceBundle;
import com.documentum.web.common.ArgumentList;
import com.documentum.web.common.ErrorMessageService;
import com.documentum.web.form.control.Text;
import com.documentum.web.formext.component.Component;
import com.documentum.webcomponent.library.messages.MessageService;
import com.monsanto.dctm.monAppContext.MonAppContextService;

import java.util.Iterator;
import java.util.Map;

/**
 * @author tsvedan
 */
public class ModifyAttrValue extends Component {

    private class AttrEntry {

        private void set(String name, String value) {
            StringBuffer set = new StringBuffer();
            if (setClause == null) {
                set.append("set ").append(name).append("='");
                set.append(value).append("'");
            } else {
                set.append(setClause).append(", ").append(name).append("='");
                set.append(value).append("'");
            }
            setClause = set.toString();
        }

        protected void setCodeType(String value) {
            if (!codeType.equals(value)) {
                isModified = true;
                set("code_type", value);
            }
        }

        protected void setCodedValue(String value) {
            if (!codedValue.equals(value)) {
                isModified = true;
                set("coded_value", value);
            }
        }

        protected void setDecodedValue(String value) {
            if (!attrValue.equals(value)) {
                isModified = true;
                set("decoded_value", value);
            }
        }

        protected void setXrefValue(String value) {
            if (!xrefValue.equals(value)) {
                isModified = true;
                set("xref_value", value);
            }
        }

        protected void setSortValue(String value) {
            if (!sortValue.equals(value)) {
                isModified = true;
                set("sort_value", value);
            }
        }
    }

    /**
     * Creates a new instance of ModifyAttrValue
     */
    public ModifyAttrValue() {
        codeType = null;
        codedValue = null;
        decodedValue = null;
        attrValue = null;
        xrefValue = null;
        sortValue = null;
        whereClause = null;
        setClause = null;
        isModified = false;
        config = new NewCodeLookupConfig(getMonAppContext(), getDfSession());
    }

    public void onInit(ArgumentList args) {
        super.onInit(args);
        codeType = args.get("codeType");
        attrValue = args.get("attrValue");
        decodedValue = attrValue;
        whereClause =
                " where code_type='" + args.get("codeType") + "' and decoded_value='" + args.get("attrValue") + "'";
//        System.out.println("MODIFY VALUES..");
//        System.out.println("Code Type = " + codeType);
//        System.out.println("Attr Value = " + attrValue);
        entry = new AttrEntry();
        try {
            execReadQuery();
            Text text = (Text) getControl("code_type", com.documentum.web.form.control.Text.class);
            text.setValue(codeType);
            if (!isSuperUser())
                text.setEnabled(false);
            text = (Text) getControl("coded_value", com.documentum.web.form.control.Text.class);
            text.setValue(codedValue);
            text = (Text) getControl("decoded_value", com.documentum.web.form.control.Text.class);
            text.setValue(attrValue);
            text = (Text) getControl("xref_value", com.documentum.web.form.control.Text.class);
            text.setValue(xrefValue);
            text = (Text) getControl("sort_value", com.documentum.web.form.control.Text.class);
            text.setValue(sortValue);
        } catch (DfException e) {
        }
    }

    protected void execReadQuery() throws DfException {
        StringBuffer query = new StringBuffer();
        query.append("select coded_value,xref_value,sort_value from dm_dbo.code_lookup where ");
        query.append("code_type='").append(codeType).append("' and ");
        query.append("decoded_value='").append(attrValue).append("'");

        IDfCollection coll = null;
        IDfClientX clientx = new DfClientX();
        IDfQuery q = clientx.getQuery();
        q.setDQL(query.toString());
        coll = q.execute(getDfSession(), IDfQuery.DF_READ_QUERY);

        if (coll != null && coll.next()) {
            codedValue = coll.getString("coded_value");
            xrefValue = coll.getString("xref_value");
            sortValue = coll.getString("sort_value");
        }

        if (coll != null)
            coll.close();
    }

    protected void execUpdateQuery() throws DfException {

        String query = update + setClause + whereClause;

        IDfCollection coll = null;
        IDfClientX clientx = new DfClientX();
        IDfQuery q = clientx.getQuery();
        q.setDQL(query);
        q.execute(getDfSession(), IDfQuery.DF_QUERY);

    }

    protected IDfCollection execQuery(String query) throws DfException {

        IDfClientX clientx = new DfClientX();
        IDfQuery q = clientx.getQuery();
        q.setDQL(query);
        return q.execute(getDfSession(), IDfQuery.DF_READ_QUERY);

    }

    public boolean canCommitChanges() {
        Text text = (Text) getControl("code_type");
        entry.setCodeType(text.getValue().trim());
        codeType = text.getValue().trim();
//        System.out.println("New Code Type: " + codeType);
        text = (Text) getControl("coded_value");
        entry.setCodedValue(text.getValue());
        codedValue = text.getValue();
//        System.out.println("New Coded Value: " + codedValue);
        text = (Text) getControl("decoded_value");
        entry.setDecodedValue(text.getValue().trim());
        attrValue = text.getValue().trim();
//        System.out.println("New Attr Value: " + attrValue);
        text = (Text) getControl("xref_value");
        entry.setXrefValue(text.getValue());
        xrefValue = text.getValue();
//        System.out.println("New Reference Value: " + xrefValue);
        text = (Text) getControl("sort_value");
        entry.setSortValue(text.getValue());
        sortValue = text.getValue();
//        System.out.println("New Sort Value: " + sortValue);
        return true;
    }

    public boolean onCommitChanges() {
        boolean success = false;
        if (!(isModified && isValid()))
            return false;
        NlsResourceBundle nlsResBndl = getNlsResBndl();
        if (isCodeActive()) {
            ErrorMessageService.getService().setNonFatalError(nlsResBndl, "MSG_CODE_VALUE_IN_USE", this, null, null);
            return false;
        }
        if (!config.isUserModifiable(codeType)) {
            ErrorMessageService.getService()
                    .setNonFatalError(nlsResBndl, "MSG_CODE_VALUE_NOT_MODIFIABLE", this, null, null);
            return false;
        }
        try {
            execUpdateQuery();
            success = true;
            MessageService.addMessage(this, "MSG_SUCCESS");
        } catch (DfException e) {
        } finally {
            return success;
        }
    }

    protected boolean isCodeActive() {
        boolean used = false;
        String typename = null;
        String attrname = null;
        Map map = config.getTypeAttrInfo(codeType);
        for (Iterator iter = map.keySet().iterator(); !used && iter.hasNext();) {
            typename = (String) iter.next();
            attrname = (String) map.get(typename);
//            System.out.println("Type = " + typename + "   Attr = " + attrname);
            used = isCodeActive(typename, attrname);
        }
        return used;
    }

    protected boolean isCodeActive(String typename, String attrname) {
        boolean used = false;
        StringBuffer query = new StringBuffer();
        query.append("select r_object_id from ").append(typename).append(" where ");
        if (getRepeating(typename, attrname))
            query.append("any ");
        query.append(attrname).append("='").append(decodedValue).append("'");
        try {
            IDfCollection coll = execQuery(query.toString());
            if (coll != null) {
                if (coll.next())
                    used = true;
                coll.close();
            }
        } catch (DfException e) {
            e.printStackTrace();
        }
        return used;
    }

    protected boolean isValid() {
        if (codeType == null || attrValue == null)
            return false;
        NlsResourceBundle nlsResBndl = getNlsResBndl();
        if (codeType.length() == 0) {
            ErrorMessageService.getService().setNonFatalError(nlsResBndl, "MSG_ERROR_NO_CODE_TYPE", this, null, null);
            return false;
        }
        if (attrValue.length() == 0) {
            ErrorMessageService.getService()
                    .setNonFatalError(nlsResBndl, "MSG_ERROR_NO_DECODED_VALUE", this, null, null);
            return false;
        }
        try {
            if (duplicate()) {
                ErrorMessageService.getService()
                        .setNonFatalError(nlsResBndl, "MSG_ERROR_DUPLICATE_VALUE", this, null, null);
                return false;
            }
        } catch (DfException e) {
        }
        return true;
    }

    protected boolean duplicate() throws DfException {
        boolean dupe = false;
        StringBuffer query = new StringBuffer();
        query.append("select decoded_value from dm_dbo.code_lookup where code_type='");
        query.append(codeType).append("' and decoded_value='").append(attrValue).append("'");

        IDfCollection coll = null;
        IDfClientX clientx = new DfClientX();
        IDfQuery q = clientx.getQuery();
        q.setDQL(query.toString());
        try {
            coll = q.execute(getDfSession(), IDfQuery.DF_READ_QUERY);
            String value = null;
            if (coll != null && coll.next())
                value = coll.getString("decoded_value");
//            System.out.println("Collection decoded value = " + value);
            if (value != null && attrValue.equalsIgnoreCase(value.trim()))
                if (!attrValue.equals(decodedValue.trim()))
                    dupe = true;
        } catch (DfException e) {
        } finally {
            if (coll != null)
                coll.close();
        }
        return dupe;
    }

    protected String getMonAppContext() {
        return (MonAppContextService.getMonAppContextService()).getCurrentMonAppContextName();
    }

    protected NlsResourceBundle getNlsResBndl() {
        String nlsbundle = getConfigLookup().lookupString(buildConfigPath("nlsbundle"), getContext());
//        System.out.println("NlsBundle = " + nlsbundle);
        return new NlsResourceBundle(nlsbundle);
    }

    private boolean getRepeating(String typename, String attrname) {
        boolean rep = false;
        IDfSession sess = null;
        try {
            sess = getDfSession();
            IDfType type = sess.getType(typename);
            IDfAttr attr = type.getTypeAttr(type.findTypeAttrIndex(attrname));
            rep = attr.isRepeating();
//            System.out.println("Repeating?? " + rep);
        } catch (Exception e) {
            System.out.println(e);
        }
        return rep;
    }

    private boolean isSuperUser() {
        boolean bRetValue = false;
        IDfSession session = null;
        try {
            session = getDfSession();
            IDfUser userObject = session.getUser(session.getLoginUserName());
            if (userObject != null && userObject.getUserPrivileges() == 16)
                return true;
        } catch (DfException e) {
            e.printStackTrace();
        }
        return bRetValue;
    }

    private String codeType;
    private String codedValue;
    private String decodedValue;
    private String attrValue;
    private String xrefValue;
    private String sortValue;
    private String update = "addRequestor dm_dbo.code_lookup ";
    private String whereClause;
    private String setClause;
    private boolean isModified;
    private AttrEntry entry;

    private ICodeLookupConfig config;
}
