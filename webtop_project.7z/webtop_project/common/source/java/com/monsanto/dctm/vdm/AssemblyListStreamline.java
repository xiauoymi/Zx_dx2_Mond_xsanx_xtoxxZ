package com.monsanto.dctm.vdm;

import com.monsanto.dctm.monAppContext.MonAppContextService;

public class AssemblyListStreamline extends
                                    com.documentum.webtop.webcomponent.vdm.AssemblyListStreamline {

    protected String getColumnsPreferenceId() {
        return super.getColumnsPreferenceId() + "." +
               MonAppContextService.getMonAppContextService().getMonAppContextInternalName();
    }

}
