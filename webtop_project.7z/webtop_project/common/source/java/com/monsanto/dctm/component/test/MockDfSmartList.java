/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.component.test;

import com.documentum.fc.client.search.IDfSearchService;
import com.documentum.fc.client.search.IDfSmartList;
import com.documentum.fc.client.search.IDfSmartListDefinition;
import com.documentum.fc.common.DfException;

import java.io.IOException;

/**
 * Filename:    $RCSfile: MockDfSmartList.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: lakench $    	 On:	$Date: 2007-11-19 22:05:22 $
 *
 * @author lakench
 * @version $Revision: 1.1 $
 */
public class MockDfSmartList extends MockSysObject implements IDfSmartList {
  private IDfSmartListDefinition smartListDefinition;

  public IDfSmartListDefinition getSmartListDefinition(IDfSearchService iDfSearchService) throws DfException,
      IOException {
    return smartListDefinition;
  }

  public void setSmartListDefinition(IDfSmartListDefinition iDfSmartListDefinition) {
    smartListDefinition = iDfSmartListDefinition;
  }

  public boolean isLegacy() throws DfException {
    return false;
  }

  public long getContentSize() throws DfException {
    return 1;
  }
}