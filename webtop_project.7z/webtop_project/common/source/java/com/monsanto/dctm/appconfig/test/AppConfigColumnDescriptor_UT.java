/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.appconfig.test;

import com.documentum.web.form.control.databound.ColumnDescriptor;
import com.monsanto.dctm.appconfig.AppConfigColumnDescriptor;
import junit.framework.TestCase;

/**
 * Filename:    $RCSfile: AppConfigColumnDescriptor_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: lakench $    	 On:	$Date: 2007-08-24 21:29:43 $
 *
 * @author lakench
 * @version $Revision: 1.2 $
 */
public class AppConfigColumnDescriptor_UT extends TestCase {
  public void testCreate() throws Exception {
    AppConfigColumnDescriptor appConfigColumnDescriptor = new AppConfigColumnDescriptor("testcolname", "testcoldisplay",
        true, true, "testdefaultvalue");
    assertEquals("testcolname", appConfigColumnDescriptor.getColumnName());
    assertEquals("testcoldisplay", appConfigColumnDescriptor.getColumnDisplay());
    assertTrue(appConfigColumnDescriptor.isMappedToSysObject());
    assertTrue("testcolname", appConfigColumnDescriptor.isVisible());
    assertEquals("testdefaultvalue", appConfigColumnDescriptor.getDefaultValue());

  }

  public void testGetColumnDescriptor() throws Exception {
    AppConfigColumnDescriptor appConfigColumnDescriptor = new AppConfigColumnDescriptor("testcolname", "testcoldisplay",
        true, true, "testdefaultvalue");
    ColumnDescriptor columnDescriptor = appConfigColumnDescriptor.getColumnDescriptor();
    ColumnDescriptor expectedColumnDescriptor = new ColumnDescriptor("testcolname", "testcoldisplay", true);
    assertEquals(expectedColumnDescriptor.getAttribute(), columnDescriptor.getAttribute());
    assertEquals(expectedColumnDescriptor.getLabel(), columnDescriptor.getLabel());
    assertEquals(expectedColumnDescriptor.isVisible(), columnDescriptor.isVisible());
  }

  public void testEquality() throws Exception {
    AppConfigColumnDescriptor appConfigColumnDescriptor = new AppConfigColumnDescriptor("testcolname", "testcoldisplay",
        true, true, "testdefaultvalue");
    AppConfigColumnDescriptor appConfigColumnDescriptor2 = new AppConfigColumnDescriptor("testcolname",
        "testcoldisplay",
        true, true, "testdefaultvalue");

    assertEquals(appConfigColumnDescriptor, appConfigColumnDescriptor2);
    assertEquals(appConfigColumnDescriptor.hashCode(), appConfigColumnDescriptor2.hashCode());

    AppConfigColumnDescriptor appConfigColumnDescriptor3 = new AppConfigColumnDescriptor("testcolname",
        "testcoldisplay",
        true, false, "testdefaultvalue");
    assertFalse(appConfigColumnDescriptor3.equals(appConfigColumnDescriptor));

    assertFalse(appConfigColumnDescriptor3.equals(new Object()));
  }
}