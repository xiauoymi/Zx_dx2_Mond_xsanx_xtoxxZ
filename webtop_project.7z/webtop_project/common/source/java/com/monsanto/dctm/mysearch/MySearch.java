/*
 * MySearch.java
 *
 * Created on March 22, 2006, 4:04 PM
 *
 * To change this template, choose Tools | Options and locate the template under
 * the Source Creation and Management node. Right-click the template and choose
 * Open. You can then make changes to the template in the Source Editor.
 */

package com.monsanto.dctm.mysearch;

import com.documentum.fc.client.*;
import com.documentum.fc.common.*;
import com.documentum.web.common.ArgumentList;
import com.documentum.web.formext.component.Component;
import com.documentum.web.formext.action.ActionService;

/**
 *
 * @author tsvedan
 */
public class MySearch extends Component {
    
    /** Creates a new instance of MySearch */
    public MySearch() {
    }
    
    public void onRender() {
        String queryId = getQueryId();
        if (queryId != null){
            ArgumentList list = new ArgumentList();
            list.add("query", queryId);
            list.add("queryType", "queryId");
            list.add("drilldown", "false");
            setComponentJump("search", list, getContext());       
        } else {
            ArgumentList list = new ArgumentList();
            list.add("component", "advsearch");
            list.add("type", "dm_sysobject");
//            list.add("usepreviousinput", "true");
            setComponentNested("advsearchcontainer", list, getContext(), null);
        }
    }
    
    private String getQueryId(){
        String queryId = null;
        String context = getContext().toString();
        if(context.indexOf("queryId") > 0){
            queryId = context.substring(context.indexOf("queryId") + 8, context.indexOf(")", context.indexOf("queryId")));
            if (queryId.indexOf(",") > 0)
                queryId = queryId.substring(0, queryId.indexOf(","));
            System.out.println("queryId = " + queryId);
            return queryId;
        }
        return null;
    }
        
}
