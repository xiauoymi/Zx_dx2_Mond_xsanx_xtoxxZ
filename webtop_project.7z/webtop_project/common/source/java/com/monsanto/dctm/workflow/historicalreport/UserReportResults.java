package com.monsanto.dctm.workflow.historicalreport;

import com.monsanto.dctm.monAppContext.MonAppContextService;

public class UserReportResults
        extends
        com.documentum.webcomponent.library.workflow.historicalreport.UserReportResults {

    protected String getColumnsPreferenceId() {
        return super.getColumnsPreferenceId() + "." +
               MonAppContextService.getMonAppContextService().getMonAppContextInternalName();
    }

}
