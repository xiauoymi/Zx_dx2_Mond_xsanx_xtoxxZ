package com.monsanto.dctm.directed;

import com.documentum.web.common.ArgumentList;
import com.documentum.webtop.webcomponent.main.Main;
import com.monsanto.dctm.monAppContext.MonAppContextService;

import javax.servlet.http.HttpServletRequest;

public class DirectedMain extends Main {
    public void onInit(ArgumentList args) {

        String monAppContext = lookupString("set_mon_app_context");
        if (monAppContext != null && monAppContext.length() > 0) {
            MonAppContextService.getMonAppContextService().setMonAppContext(monAppContext, false);
        }

        String strStartComponent = lookupString("startingComponent");
        if (strStartComponent == null || strStartComponent.length() == 0) {
            strStartComponent = "advsearchcontainer";
        }

        HttpServletRequest request = (HttpServletRequest) getPageContext().getRequest();
        String contextPath = request.getContextPath();


        getPageContext().getSession().setAttribute("START_COMPONENT", strStartComponent);
        getPageContext().getSession()
                .setAttribute("RETURN_FROM_LOGOFF_COMPONENT", contextPath + "/component/" + getComponentId());

        super.onInit(args);
    }
}
