/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.component.test;

import com.documentum.web.formext.config.IPreferenceStore;

import java.util.ArrayList;
import java.util.Map;
import java.util.HashMap;

/**
 * Filename:    $RCSfile: MockPreferenceStore.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: lakench $    	 On:	$Date: 2007-03-02 22:44:20 $
 *
 * @author lakench
 * @version $Revision: 1.1 $
 */
public class MockPreferenceStore implements IPreferenceStore {
    private Map stringMap = new HashMap();
    private Map booleanMap = new HashMap();
    private Map integerMap = new HashMap();

    public String readString(String string) {
        return (String) stringMap.get(string);
    }

    public Boolean readBoolean(String string) {
        return (Boolean) booleanMap.get(string);
    }

    public Integer readInteger(String string) {
        return (Integer) integerMap.get(string);
    }

    public void writeString(String string, String string1) {
        stringMap.put(string, string1);
    }

    public void writeBoolean(String string, Boolean aBoolean) {
        booleanMap.put(string, aBoolean);
    }

    public void writeInteger(String string, Integer integer) {
        integerMap.put(string, integer);
    }

    public void clearPreferences() {
        stringMap = new HashMap();
        booleanMap = new HashMap();
        integerMap = new HashMap();
    }
}