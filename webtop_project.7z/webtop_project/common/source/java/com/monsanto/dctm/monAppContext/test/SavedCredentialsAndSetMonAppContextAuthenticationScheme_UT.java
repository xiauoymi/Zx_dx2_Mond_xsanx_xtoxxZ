/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.monAppContext.test;

import com.documentum.web.env.CredentialService;
import com.documentum.web.form.ComponentTestUtils;
import com.documentum.web.formext.config.PreferenceService;
import com.monsanto.dctm.component.test.MockHttpServletRequest;
import com.monsanto.dctm.monAppContext.MonAppContextService;
import com.monsanto.dctm.monAppContext.SavedCredentialsAndSetMonAppContextAuthenticationScheme;
import junit.framework.TestCase;

/**
 * Filename:    $RCSfile: SavedCredentialsAndSetMonAppContextAuthenticationScheme_UT.java,v $ Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: lakench $    	 On:	$Date: 2007-10-12 05:21:59 $
 *
 * @author lakench
 * @version $Revision: 1.4 $
 */
public class SavedCredentialsAndSetMonAppContextAuthenticationScheme_UT extends TestCase {
  private MockHttpServletRequest httpServletRequest;
  private SavedCredentialsAndSetMonAppContextAuthenticationScheme savedCredentialsAndSetMonAppContextAuthenticationScheme;

  protected void setUp() throws Exception {
    super.setUp();
    ComponentTestUtils.setupConfigService();
    httpServletRequest = new MockHttpServletRequest();
    ComponentTestUtils.initPreferenceService(httpServletRequest);
    CredentialService.getInstance().saveCredential("testdocbase", "testuser", "testpassword", "testdomain");
    savedCredentialsAndSetMonAppContextAuthenticationScheme = new SavedCredentialsAndSetMonAppContextAuthenticationScheme();
  }

  protected void tearDown() throws Exception {
    ComponentTestUtils.releasePreferenceService();
    ComponentTestUtils.setCurrentDocbase(null);
    ComponentTestUtils.releaseConfigService();
    httpServletRequest = null;
    super.tearDown();
  }

  public void testNullDocbase() throws Exception {
    String authenticatedDocbase = savedCredentialsAndSetMonAppContextAuthenticationScheme
        .authenticate(httpServletRequest, null, null);
    assertNull("shouldn't authenticate", authenticatedDocbase);
    String currentMonAppContextName = MonAppContextService.getMonAppContextService("testdocbase")
        .getCurrentMonAppContextName();
    assertEquals("mon app context shouldn't be set", null, currentMonAppContextName);
  }

  public void testAuthenticateAndSetMonAppContext() throws Exception {
    PreferenceService.getPreferenceStore()
        .writeString("application.mon_app_context.testdocbase", "Test Context with different docbases");
    String authenticatedDocbase = savedCredentialsAndSetMonAppContextAuthenticationScheme
        .authenticate(httpServletRequest, null, "testdocbase");
    assertEquals("didn't authenticate", "testdocbase", authenticatedDocbase);
    String currentMonAppContextName = MonAppContextService.getMonAppContextService("testdocbase")
        .getCurrentMonAppContextName();
    assertEquals("didn't set mon app context right", "Test Context with different docbases",
        currentMonAppContextName);
  }

}