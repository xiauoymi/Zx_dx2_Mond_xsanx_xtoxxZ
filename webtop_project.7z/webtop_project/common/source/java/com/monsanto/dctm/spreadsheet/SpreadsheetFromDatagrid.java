package com.monsanto.dctm.spreadsheet;

import com.documentum.fc.common.DfLogger;
import com.documentum.web.common.ArgumentList;
import com.documentum.web.common.LocaleService;
import com.documentum.web.form.Form;
import com.documentum.web.form.control.databound.ColumnDescriptor;
import com.documentum.web.form.control.databound.DataProvider;
import com.documentum.web.form.control.databound.Datagrid;
import com.documentum.web.form.control.format.DateValueFormatter;
import com.documentum.web.formext.component.ComponentColumnDescriptorList;
import com.documentum.web.util.DateUtil;
import org.apache.poi.hssf.usermodel.*;
import org.apache.poi.hssf.util.HSSFColor;

import javax.servlet.ServletContext;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.List;


public class SpreadsheetFromDatagrid {
  private String fileName;
  private static HSSFCellStyle cellDateTimeFormat;
  private static String dateTimeFormat;
  private static DateValueFormatter dvf;
  private static SimpleDateFormat df;
  private static HSSFWorkbook workBook;
  private static DataProvider dataprovider;
  private static List listColumns;
  private static HSSFSheet sheet;
  private ServletContext servletContext;


  public SpreadsheetFromDatagrid(Datagrid datagrid, ComponentColumnDescriptorList columnDescriptors,
                                 ServletContext servletContext) {
    initDataProvider(datagrid);
    initWorkbook();
    initDateFormats();
    listColumns = columnDescriptors.getColumnDescriptors();
    this.servletContext = servletContext;
    createSpreadsheet();
  }

  public void displaySpreadsheet(Form form) {
    ArgumentList args = new ArgumentList();
    args.add("fileName", fileName);
    form.setClientEvent("getFileLocation", args);
  }

  private void createSpreadsheet() {
    int pagecount = dataprovider.getPageCount();
    int row = 1;
    for (int i = 0; i < pagecount; i++) {
      dataprovider.initBind();
      do {
        HSSFRow HssRow = sheet.createRow(row);
        short cell = 0;
        Iterator itColumns = listColumns.iterator();
        while (itColumns.hasNext()) {
          ColumnDescriptor column = (ColumnDescriptor) itColumns.next();
          if (column.isVisible()) {
            writeCell(HssRow, cell, column);
            cell++;
          }
        }
        row++;
      } while (dataprovider.nextRow());
      dataprovider.nextPage();
    }
    dataprovider.firstPage();
    addHeaderRow(sheet, listColumns, dataprovider);
    writeToFile("Search");
  }

  private void writeCell(HSSFRow HssRow, short cell, ColumnDescriptor column) {
    HSSFCell HssCol = HssRow.createCell(cell);
    String attributeName = column.getAttribute();
    String attributeValue = dataprovider.getDataField(attributeName);
    int attributeType = dataprovider.getColumnType(attributeName);
    switch (attributeType) {
      case 0:
        attributeValue = (attributeValue.equals("0") ? "True" : "False");
        Boolean booleanAttributeValue = new Boolean(attributeValue);
        HssCol.setCellValue(booleanAttributeValue.booleanValue());
        break;
      case 4:
        attributeValue = dvf.format(attributeValue);
        HssCol.setCellStyle(cellDateTimeFormat);
        try {
          Date dateAttributeValue = df.parse(attributeValue);
          HssCol.setCellValue(dateAttributeValue);
        }
        catch (ParseException parseException) {
          parseException.printStackTrace();
        }
        break;
      default:
        HssCol.setCellValue(attributeValue);
    }
    adjustColumnWidth(cell, attributeValue);
  }

  private void initDataProvider(Datagrid datagrid) {
    dataprovider = datagrid.getDataProvider();
  }

  private void initDateFormats() {
    dateTimeFormat = DateUtil.getDateTimeFormatPattern(DateFormat.SHORT, DateFormat.SHORT, LocaleService.getLocale());
    dvf = new DateValueFormatter();
    df = new SimpleDateFormat(dateTimeFormat, LocaleService.getLocale());
    if (dateTimeFormat.endsWith(" a"))
      dateTimeFormat = dateTimeFormat.substring(0, dateTimeFormat.lastIndexOf(" a")) + " AM/PM";
    cellDateTimeFormat = workBook.createCellStyle();
    cellDateTimeFormat.setDataFormat(workBook.createDataFormat().getFormat(dateTimeFormat));
  }

  private void initWorkbook() {
    workBook = null;
    workBook = new HSSFWorkbook();
    initSheet();
  }

  private void initSheet() {
    sheet = workBook.createSheet();
  }

  private void addHeaderRow(HSSFSheet sheet, List listColumns, DataProvider dataprovider) {
    HSSFFont font = workBook.createFont();
    font.setColor(HSSFColor.WHITE.index);
    HSSFCellStyle columnHeaderStyle = workBook.createCellStyle();
    columnHeaderStyle.setAlignment(HSSFCellStyle.ALIGN_CENTER);
    columnHeaderStyle.setFillBackgroundColor(HSSFColor.BLUE_GREY.index);
    columnHeaderStyle.setFillForegroundColor(HSSFColor.BLUE_GREY.index);
    columnHeaderStyle.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
    columnHeaderStyle.setFont(font);
    HSSFCell headerCell = null;
    HSSFRow headerRow = sheet.createRow(0);
    short col = 0;
    Iterator itColumns = listColumns.iterator();
    while (itColumns.hasNext()) {
      ColumnDescriptor column = (ColumnDescriptor) itColumns.next();
      if (column.isVisible()) {
        headerCell = headerRow.createCell(col);
        String attributeName = column.getLabel();
        headerCell.setCellValue(attributeName);
        adjustColumnWidth(col, attributeName);
        headerCell.setCellStyle(columnHeaderStyle);
        col++;
      }
    }
  }

  private void adjustColumnWidth(short col, String colValue) {
    int colWidth = colValue.length();
    short sheetColWidth = (short) ((colWidth + 1) * 256);
    if (sheetColWidth > sheet.getColumnWidth(col)) {
      sheet.setColumnWidth(col, sheetColWidth);
    }
  }

  private void writeToFile(String fileNamePrefix) {
    FileOutputStream stream = null;
    File spreadsheetFile = null;
    try {
      spreadsheetFile = File.createTempFile(fileNamePrefix, ".xls");
      stream = new FileOutputStream(spreadsheetFile);
      workBook.write(stream);
    }
    catch (IOException ex) {
      DfLogger.error(this, "Error creating temp CSV File", null, ex);
    }
    finally {
      if (stream != null) {
        try {
          stream.close();
        }
        catch (IOException ioe) {
          ioe.printStackTrace();
        }
      }
    }
    fileName = spreadsheetFile.getName();
  }

}
