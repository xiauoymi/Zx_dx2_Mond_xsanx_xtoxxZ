/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.search.test;

import com.documentum.fc.client.search.IDfQueryDefinition;
import com.documentum.fc.client.search.IDfQueryManager;
import com.documentum.fc.client.search.IDfSearchMetadataManager;
import com.documentum.fc.common.DfException;
import com.monsanto.dctm.search.MonQueryManager;
import org.w3c.dom.Document;

/**
 * Filename:    $RCSfile: MockMonQueryManager.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: lakench $    	 On:	$Date: 2007-10-05 17:50:59 $
 *
 * @author lakench
 * @version $Revision: 1.1 $
 */
public class MockMonQueryManager extends MonQueryManager {
  public MockMonQueryManager(IDfQueryManager queryManager) {
    super(queryManager);
  }

  protected static IDfQueryDefinition readQueryDefinition(IDfSearchMetadataManager metadataManager, Document doc)
      throws DfException {
    return MonQueryManager.readQueryDefinition(metadataManager, doc);
  }
}