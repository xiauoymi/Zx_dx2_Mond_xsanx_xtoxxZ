/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.action.test;

import com.documentum.fc.client.IDfSessionManager;
import com.documentum.fc.client.MockSession;
import com.documentum.web.common.ArgumentList;
import com.monsanto.dctm.action.ViewPDFRendition;
import com.monsanto.dctm.component.test.MockSessionManager;
import com.monsanto.dctm.component.test.MockSysObject;
import com.monsanto.dctm.dctmSession.Session;
import com.monsanto.dctm.dctmSession.test.MockDctmSession;
import junit.framework.TestCase;

/**
 * Filename:    $RCSfile: ViewPDFRendition_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: lakench $
 * On:	$Date: 2007-10-12 05:21:59 $
 *
 * @author lakench
 * @version $Revision: 1.3 $
 */
public class ViewPDFRendition_UT extends TestCase {
  protected void setUp() throws Exception {
    super.setUp();
  }

  public void testArgsDontChangeWhenNoPDFRenditionExists() throws Exception {
    MockSessionManager dfSessionManager = new MockSessionManager();
    MockSession session = new MockSession();
    MockSysObject object = new MockSysObject();
    session.addObject(object, "testobjectid");
    object.setString("r_object_id", "testobjectid");
    object.addRendition("testpdfrendition", "not a pdf");
    dfSessionManager.setSession(session);
    MockViewPDFRendition mockViewPDFRendition = new MockViewPDFRendition(dfSessionManager);
    ArgumentList args = new ArgumentList();
    args.add("objectId", "testobjectid");
    args.add("contentType", "msw8");

    mockViewPDFRendition.replaceContentTypeArgIfPDFExists(args);
    assertEquals("msw8", args.get("contentType"));

  }

  public void testArgsDoChangeWhenPDFRenditionExists() throws Exception {
    MockSessionManager dfSessionManager = new MockSessionManager();
    MockSession session = new MockSession();
    MockSysObject object = new MockSysObject();
    session.addObject(object, "testobjectid");
    object.setString("r_object_id", "testobjectid");
    object.addRendition("testpdfrendition", "pdf");
    dfSessionManager.setSession(session);
    MockViewPDFRendition mockViewPDFRendition = new MockViewPDFRendition(dfSessionManager);
    ArgumentList args = new ArgumentList();
    args.add("objectId", "testobjectid");
    args.add("contentType", "msw8");

    mockViewPDFRendition.replaceContentTypeArgIfPDFExists(args);
    assertEquals("pdf", args.get("contentType"));

  }

  class MockViewPDFRendition extends ViewPDFRendition {
    public ArgumentList args;
    private IDfSessionManager dfSessionManager;

    public MockViewPDFRendition(IDfSessionManager dfSessionManager) {
      this.dfSessionManager = dfSessionManager;
    }

    /**
     * @noinspection RefusedBequest
     */
    protected Session createSession() {
      return new MockDctmSession(dfSessionManager, "testdocbase");
    }

    protected void replaceContentTypeArgIfPDFExists(ArgumentList args) {
      super.replaceContentTypeArgIfPDFExists(args);
      this.args = args;
    }
  }
}