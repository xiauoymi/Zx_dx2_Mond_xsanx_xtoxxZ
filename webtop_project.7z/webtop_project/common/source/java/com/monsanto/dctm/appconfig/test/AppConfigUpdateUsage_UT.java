/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.appconfig.test;

import com.documentum.web.common.ArgumentList;
import com.documentum.web.form.ComponentTestUtils;
import com.documentum.web.form.control.DropDownList;
import com.documentum.web.form.control.Label;
import com.documentum.web.form.control.Option;
import com.documentum.web.form.control.Text;
import com.documentum.web.formext.component.Component;
import com.monsanto.dctm.appconfig.AppConfigItem;
import com.monsanto.dctm.appconfig.AppConfigItemBaseComponent;
import com.monsanto.dctm.appconfig.AppConfigUpdateRequestor;
import com.monsanto.dctm.appconfig.AppConfigUpdateUsage;
import com.monsanto.dctm.component.test.MockSessionManager;
import junit.framework.TestCase;

import java.util.*;

/**
 * Filename:    $RCSfile: AppConfigUpdateUsage_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: lakench $
 * On:	$Date: 2007-10-26 18:47:58 $
 *
 * @author lakench
 * @version $Revision: 1.4 $
 */
public class AppConfigUpdateUsage_UT extends TestCase {
  public void testCreate() throws Exception {
    AppConfigUpdateUsage appConfigUpdateUsage = new AppConfigUpdateUsage();
    assertNotNull(appConfigUpdateUsage);
    assertTrue(appConfigUpdateUsage instanceof Component);
  }

  public void testIntializedForAddAction() throws Exception {
    MockAppConfigUpdateUsage component = (MockAppConfigUpdateUsage) ComponentTestUtils
        .getComponent(MockAppConfigUpdateUsage.class, "testupdateusage", "testdocbase",
            new MockSessionManager());

    ArgumentList argumentList = new ArgumentList();
    argumentList.add(AppConfigUpdateUsage.APP_CONFIG_ACTION_ARG, AppConfigUpdateUsage.ADD_ACTION);
    component.setupComponent(argumentList);

    String instructions = AppConfigUpdateUsage.ADD_INSTRUCTIONS;
    validateInstructions(component, instructions);

    validateEnabledDropDownList((DropDownList) component.getControl(AppConfigUpdateUsage.ENABLED_DROPDOWN_NAME));
    ComponentTestUtils.releaseComponent(component);
  }

  public void testInitializedForRemoveAction() throws Exception {
    MockAppConfigUpdateUsage component = (MockAppConfigUpdateUsage) ComponentTestUtils
        .getComponent(MockAppConfigUpdateUsage.class, "testupdateusage", "testdocbase",
            new MockSessionManager());

    ArgumentList argumentList = new ArgumentList();
    argumentList.add(AppConfigUpdateRequestor.APP_CONFIG_ACTION_ARG, AppConfigUpdateUsage.REMOVE_ACTION);
    argumentList.add("rowid", "0");
    argumentList.add("usage_type", "testfeature");
    argumentList.add("usage_enabled", "Yes");
    component.setupComponent(argumentList);

    validateInstructions(component, AppConfigUpdateUsage.REMOVE_INSTRUCTIONS);

    validateTypeControl(component);
    DropDownList enabledControl = (DropDownList) component.getControl(AppConfigUpdateUsage.ENABLED_DROPDOWN_NAME);
    assertEquals("Yes", enabledControl.getValue());
    assertFalse(enabledControl.isEnabled());
    ComponentTestUtils.releaseComponent(component);
  }

  public void testInitializedForUpdateAction() throws Exception {
    MockAppConfigUpdateUsage component = (MockAppConfigUpdateUsage) ComponentTestUtils
        .getComponent(MockAppConfigUpdateUsage.class, "testupdateusage", "testdocbase",
            new MockSessionManager());

    ArgumentList argumentList = new ArgumentList();
    argumentList.add(AppConfigUpdateRequestor.APP_CONFIG_ACTION_ARG, AppConfigUpdateUsage.UPDATE_ACTION);
    argumentList.add("rowid", "0");
    argumentList.add("usage_type", "testfeature");
    argumentList.add("usage_enabled", "Yes");
    component.setupComponent(argumentList);

    validateInstructions(component, AppConfigUpdateUsage.UPDATE_INSTRUCTIONS);
    validateTypeControl(component);
    DropDownList enabledControl = (DropDownList) component.getControl(AppConfigUpdateUsage.ENABLED_DROPDOWN_NAME);
    validateEnabledDropDownList(enabledControl);
    assertEquals("Yes", enabledControl.getValue());
    ComponentTestUtils.releaseComponent(component);
  }

  public void testOnCommitChangesForRemove() throws Exception {
    MockAppConfigUpdateUsage component = (MockAppConfigUpdateUsage) ComponentTestUtils
        .getComponent(MockAppConfigUpdateUsage.class, "testupdateusage", "testdocbase",
            new MockSessionManager());

    ArgumentList argumentList = new ArgumentList();
    argumentList.add(AppConfigUpdateRequestor.APP_CONFIG_ACTION_ARG, AppConfigUpdateUsage.REMOVE_ACTION);
    argumentList.add("rowid", "0");
    argumentList.add("usage_type", "testfeature");
    argumentList.add("usage_enabled", "Yes");
    component.setupComponent(argumentList);

    component.onCommitChanges();

    Map expectedValues = new HashMap(3);
    expectedValues.put("rowid", "0");
    expectedValues.put("usage_type", "testfeature");
    expectedValues.put("usage_enabled", "Yes");
    AppConfigItem expectedReturnItem = new AppConfigItem("mon_app_usage", expectedValues);

    assertEquals(AppConfigUpdateUsage.REMOVE_ACTION,
        component.getReturnValue(AppConfigUpdateUsage.APP_CONFIG_ACTION_ARG));
    assertTrue(
        Boolean.valueOf((String) component.getReturnValue(AppConfigItemBaseComponent.REALLY_DELETE)).booleanValue());
    assertEquals(expectedReturnItem, component.getReturnValue(AppConfigItemBaseComponent.APP_CONFIG_ITEM));
    ComponentTestUtils.releaseComponent(component);
  }

  public void testOnCommitChangesForAdd() throws Exception {
    MockAppConfigUpdateUsage component = (MockAppConfigUpdateUsage) ComponentTestUtils
        .getComponent(MockAppConfigUpdateUsage.class, "testupdateusage", "testdocbase",
            new MockSessionManager());

    ArgumentList argumentList = new ArgumentList();
    argumentList.add(AppConfigUpdateUsage.APP_CONFIG_ACTION_ARG, AppConfigUpdateUsage.ADD_ACTION);
    component.setupComponent(argumentList);
    Text typeControl = (Text) component.getControl(AppConfigUpdateUsage.TYPE_TEXT_NAME, Text.class);
    typeControl.setValue("testfeature");
    DropDownList enabledControl = (DropDownList) component
        .getControl(AppConfigUpdateUsage.ENABLED_DROPDOWN_NAME, DropDownList.class);
    enabledControl.setValue("Yes");

    component.onCommitChanges();

    Map expectedValues = new HashMap(3);
    expectedValues.put("rowid", "0");
    expectedValues.put("usage_type", "testfeature");
    expectedValues.put("usage_enabled", "Yes");
    AppConfigItem expectedReturnItem = new AppConfigItem("mon_app_usage", expectedValues);

    assertEquals(AppConfigUpdateUsage.ADD_ACTION,
        component.getReturnValue(AppConfigUpdateUsage.APP_CONFIG_ACTION_ARG));
    assertTrue(
        Boolean.valueOf((String) component.getReturnValue(AppConfigItemBaseComponent.REALLY_ADD)).booleanValue());
    assertEquals(expectedReturnItem, component.getReturnValue(AppConfigItemBaseComponent.APP_CONFIG_ITEM));
    ComponentTestUtils.releaseComponent(component);
  }

  public void testOnCommitForUpdate() throws Exception {
    MockAppConfigUpdateUsage component = (MockAppConfigUpdateUsage) ComponentTestUtils
        .getComponent(MockAppConfigUpdateUsage.class, "testupdateusage", "testdocbase",
            new MockSessionManager());

    ArgumentList argumentList = new ArgumentList();
    argumentList.add(AppConfigUpdateRequestor.APP_CONFIG_ACTION_ARG, AppConfigUpdateUsage.UPDATE_ACTION);
    argumentList.add("rowid", "0");
    argumentList.add("usage_type", "testfeature");
    argumentList.add("usage_enabled", "Yes");
    component.setupComponent(argumentList);
    DropDownList enabledControl = (DropDownList) component
        .getControl(AppConfigUpdateUsage.ENABLED_DROPDOWN_NAME, DropDownList.class);
    enabledControl.setValue("No");

    component.onCommitChanges();

    Map expectedValues = new HashMap(3);
    expectedValues.put("rowid", "0");
    expectedValues.put("usage_type", "testfeature");
    expectedValues.put("usage_enabled", "No");
    AppConfigItem expectedReturnItem = new AppConfigItem("mon_app_usage", expectedValues);

    assertEquals(AppConfigUpdateUsage.UPDATE_ACTION,
        component.getReturnValue(AppConfigUpdateUsage.APP_CONFIG_ACTION_ARG));
    assertTrue(
        Boolean.valueOf((String) component.getReturnValue(AppConfigItemBaseComponent.REALLY_ADD)).booleanValue());
    assertEquals(expectedReturnItem, component.getReturnValue(AppConfigItemBaseComponent.APP_CONFIG_ITEM));
    ComponentTestUtils.releaseComponent(component);
  }

  private void validateInstructions(MockAppConfigUpdateUsage component, String instructions) {
    Label instructionsControl = (Label) component.getControl(AppConfigUpdateUsage.INSTRUCTIONS);
    assertEquals(instructions, instructionsControl.getLabel());
  }

  private void validateTypeControl(MockAppConfigUpdateUsage component) {
    Text typeControl = (Text) component.getControl(AppConfigUpdateUsage.TYPE_TEXT_NAME);
    assertEquals("testfeature", typeControl.getValue());
    assertFalse(typeControl.isEnabled());
  }

  private void validateEnabledDropDownList(DropDownList enabledControl) {
    List optionsList = enabledControl.getOptions();
    assertEquals(3, optionsList.size());
    Iterator options = optionsList.iterator();
    List optionLabels = new ArrayList(3);
    List optionValues = new ArrayList(3);
    while (options.hasNext()) {
      Option option = (Option) options.next();
      optionLabels.add(option.getLabel());
      optionValues.add(option.getValue());
    }
    assertEquals(3, optionLabels.size());
    assertEquals("Yes", optionLabels.get(0));
    assertEquals("No", optionLabels.get(1));
    assertEquals("Unknown", optionLabels.get(2));
    assertEquals(3, optionValues.size());
    assertEquals("Yes", optionValues.get(0));
    assertEquals("No", optionValues.get(1));
    assertEquals("Unknown", optionValues.get(2));
  }

}