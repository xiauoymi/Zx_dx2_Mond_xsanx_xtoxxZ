/*
 Copyright:  Copyright � 2006 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.support.test;

import com.documentum.fc.client.IDfSessionManager;
import com.documentum.fc.client.MockSession;
import com.documentum.fc.common.DfLoginInfo;
import com.documentum.web.form.ComponentTestUtils;
import com.documentum.web.form.control.Label;
import com.documentum.web.form.control.databound.Datagrid;
import com.monsanto.dctm.component.test.MockSessionManager;
import com.monsanto.dctm.component.test.MockSysObject;
import com.monsanto.dctm.support.Mailtolink;
import com.monsanto.dctm.support.Support;
import junit.framework.TestCase;

/**
 * Filename:    $RCSfile: Support_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: lakench $    	 On:	$Date:
 * 2007/05/12 05:29:56 $
 *
 * @author LAKENCH
 * @version $Revision: 1.8 $
 */

public class Support_UT extends TestCase {

  private MockSupportComponent support;
  private IDfSessionManager mockSessionManager;
  private static final String OUTAGE_NOTICE = "Outage Notice";

  protected void setUp() throws Exception {
    super.setUp();
    mockSessionManager = new MockSessionManager();
    MockSession session = new MockSession(mockSessionManager);
    ((MockSessionManager) mockSessionManager).setSession(session);
    support = (MockSupportComponent) ComponentTestUtils
        .getComponent(MockSupportComponent.class, "support", "testdocbase", mockSessionManager);
    support.initSupportConfig();
  }

  protected void tearDown() throws Exception {
    ComponentTestUtils.releaseComponent(support);
    super.tearDown();
  }

  public void testOutageNoticeSetProperly() throws Exception {
    DfLoginInfo dfLoginInfoForSupportConfig = new DfLoginInfo();
    dfLoginInfoForSupportConfig.setUser("devl01");
    mockSessionManager.setIdentity("stltst03", dfLoginInfoForSupportConfig);
    MockSession sessionForSupportConfig = (MockSession) mockSessionManager.getSession("stltst03");
    MockSysObject testObject = new MockSysObject();
    testObject.setString("outage_notice", OUTAGE_NOTICE);
    sessionForSupportConfig.addObject(testObject, "mon_support_info");
    support.initSupportConfig();
    support.setOutageNoticeLabel();
    Label outageLabelControl = (Label) support.getControl(Support.SUPPORT_PAGE_OUTAGE_LABEL, Label.class);
    String actualOutageLabel = outageLabelControl.getLabel();
    assertEquals("outage label not set properly", OUTAGE_NOTICE, actualOutageLabel);

    mockSessionManager.clearIdentity("stltst03");
  }

  public void testEmailLinkSetProperly() throws Exception {
    support.setTeamMailtolink();
    Mailtolink link = (Mailtolink) support.getControl(Support.TEAM_EMAIL_LINK, Mailtolink.class);
    String linkEmailAddress = link.getEmailAddress();
    assertEquals("mailto link email address not set properly", "eedocu@monsanto.com", linkEmailAddress);
  }

  public void testDataGridsCreated() throws Exception {
    DfLoginInfo dfLoginInfoForSupportConfig = new DfLoginInfo();
    dfLoginInfoForSupportConfig.setUser("devl01");
    mockSessionManager.setIdentity("stltst03", dfLoginInfoForSupportConfig);
    MockSession sessionForSupportConfig = (MockSession) mockSessionManager.getSession("stltst03");
    MockSysObject testObject = new MockSysObject();
    testObject.setString("object_name", "test object name");
    testObject.setString("display_name", "test display name");
    sessionForSupportConfig.addObject(testObject, "mon_support_info");
    sessionForSupportConfig.addObject(testObject,
        "query_cmd,s0,T,F,,,,,select object_name, display_name from mon_app_context_info order by display_name");
    sessionForSupportConfig.addObject(testObject, "mon_app_owner_info where mon_app_context = 'test object name'");
    support.initSupportConfig();
    support.initDataGrids();
    Datagrid teamDataGrid = (Datagrid) support.getControl(Support.TEAM_MEMBER_TABLE);
    Datagrid appOwnerDataGrid = (Datagrid) support.getControl(Support.APP_OWNER_TABLE);
    assertNotNull("team data grid not created", teamDataGrid);
    assertNotNull("app owner data grid not created", appOwnerDataGrid);
  }
}