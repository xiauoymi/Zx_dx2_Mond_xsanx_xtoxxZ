/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.appconfig;

import com.documentum.web.form.control.databound.ColumnDescriptor;

/**
 * Filename:    $RCSfile: AppConfigColumnDescriptor.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: lakench $    	 On:	$Date: 2007-08-21 05:23:14 $
 *
 * @author lakench
 * @version $Revision: 1.1 $
 */
public class AppConfigColumnDescriptor {
  private String columnName;
  private String columnDisplay;
  private boolean mappedToSysObject;
  private boolean visible;
  private String defaultValue;
  private ColumnDescriptor columnDescriptor;

  public AppConfigColumnDescriptor(String columnName, String columnDisplay, boolean mapsToSysObject, boolean visible,
                                   String defaultValue) {
    this.columnName = columnName;
    this.columnDisplay = columnDisplay;
    this.mappedToSysObject = mapsToSysObject;
    this.visible = visible;
    this.defaultValue = defaultValue;
    columnDescriptor = new ColumnDescriptor(columnName, columnDisplay, visible);
  }

  public boolean equals(Object obj) {
    if (!(obj instanceof AppConfigColumnDescriptor)) return false;
    boolean equals = true;
    equals &= ((AppConfigColumnDescriptor) obj).getColumnName().equals(columnName);
    equals &= ((AppConfigColumnDescriptor) obj).getColumnDisplay().equals(columnDisplay);
    equals &= (((AppConfigColumnDescriptor) obj).isMappedToSysObject() == mappedToSysObject);
    equals &= (((AppConfigColumnDescriptor) obj).isVisible() == visible);
    equals &= ((AppConfigColumnDescriptor) obj).getDefaultValue().equals(defaultValue);

    return equals;
  }

  public int hashCode() {
    int hashCode = 0;
    hashCode += columnName.hashCode();
    hashCode += columnDisplay.hashCode();
    hashCode += Boolean.toString(mappedToSysObject).hashCode();
    hashCode += Boolean.toString(visible).hashCode();
    hashCode += defaultValue.hashCode();
    return hashCode;
  }

  public String getColumnName() {
    return columnName;
  }

  public String getColumnDisplay() {
    return columnDisplay;
  }

  public boolean isMappedToSysObject() {
    return mappedToSysObject;
  }

  public boolean isVisible() {
    return visible;
  }

  public String getDefaultValue() {
    return defaultValue;
  }

  public ColumnDescriptor getColumnDescriptor() {
    return columnDescriptor;
  }
}