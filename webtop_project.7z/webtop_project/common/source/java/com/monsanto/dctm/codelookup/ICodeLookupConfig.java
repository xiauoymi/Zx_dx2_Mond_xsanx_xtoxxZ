/*
 * ICodeLookupConfig.java
 *
 * Created on February 3, 2006, 2:55 PM
 *
 * To change this template, choose Tools | Options and locate the template under
 * the Source Creation and Management node. Right-click the template and choose
 * Open. You can then make changes to the template in the Source Editor.
 */

package com.monsanto.dctm.codelookup;

import java.util.Map;

/**
 * @author tsvedan
 */
public interface ICodeLookupConfig {

  public String [] getCodeTypes();

  public String [] getAdminGroup(String codeType);

  public Map getTypeAttrInfo(String codeType);

  public String [] getAttrName(String codeType);

  public String [] getTypeName(String codeType);

  public String getXrefCodeType(String codeType);

  public boolean isUserModifiable(String codeType);

}
