/*
 * CodeLookupConfig.java
 *
 * Created on February 3, 2006, 2:55 PM
 *
 * To change this template, choose Tools | Options and locate the template under
 * the Source Creation and Management node. Right-click the template and choose
 * Open. You can then make changes to the template in the Source Editor.
 */

package com.monsanto.dctm.codelookup;

import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.IDfType;
import com.documentum.fc.common.IDfAttr;
import com.documentum.web.formext.config.ConfigService;
import com.documentum.web.formext.config.Context;
import com.documentum.web.formext.config.IConfigElement;

import java.util.Iterator;
import java.util.Map;
import java.util.Vector;

/**
 * @author tsvedan
 */
public class CodeLookupConfig implements ICodeLookupConfig {

  /**
   * Creates a new instance of CodeLookupConfig
   */
  public CodeLookupConfig(String monappcxt, Context context) {
    this.mon_app_context = monappcxt;
    this.context = context;
  }

  public Map getTypeAttrInfo(String codeType) {
    return null;
  }

  public String [] getTypeName(String codeType) {
    IConfigElement element = getConfigElement(codeType, context);
    String [] types = {element.getChildValue("typename")};
    return types;
  }

  public String [] getAttrName(String codeType) {
    IConfigElement element = getConfigElement(codeType, context);
    String [] attrs = {element.getChildValue("attrname")};
    return attrs;
  }

  public boolean getRepeating(String codeType) {
    IConfigElement element = getConfigElement(codeType, context);
    return (Boolean.valueOf(element.getChildValue("repeating")).booleanValue());
  }

  public boolean getRepeating(String codeType, IDfSession sess, Context context) {
    boolean rep = false;
    IConfigElement element = getConfigElement(codeType, context);
    try {
      IDfType type = sess.getType(element.getChildValue("typename"));
      System.out.println("Type = " + type.getName());
      System.out.println("Attr = " + element.getChildValue("attrname"));
      System.out.println("Index = " + type.findTypeAttrIndex(element.getChildValue("attrname")));
      IDfAttr attr = type.getTypeAttr(type.findTypeAttrIndex(element.getChildValue("attrname")));
      rep = attr.isRepeating();
      System.out.println("Repeating?? " + rep);
    } catch (Exception e) {
      System.out.println(e);
    }
    return rep;
  }

  public String [] getAdminGroup(String codeType) {
    String [] admins = null;
    IConfigElement element = ConfigService.getConfigLookup().lookupElement(
        "component[id=codelookup].mon_app_contexts", context);
    Iterator iter = element.getChildElements("mon_app_context");
    while (iter.hasNext()) {
      element = (IConfigElement) iter.next();
      if (element.getChildValue("name").equals(mon_app_context)) {
        admins = new String[]{element.getChildValue("admingroup")};
        break;
      }
    }
    return admins;
  }

  public String getXrefCodeType(String codeType) {
    IConfigElement element = getConfigElement(codeType, context);
    return element.getChildValue("xrefcode");
  }

  public boolean isUserModifiable(String codeType) {
    IConfigElement element = getConfigElement(codeType, context);
    return (Boolean.valueOf(element.getChildValue("ismodifiable")).booleanValue());
  }

  public String [] getCodeTypes() {

    String [] codetypes = new String[1];
    Iterator codeIter = null;
    IConfigElement element = ConfigService.getConfigLookup().lookupElement(
        "component[id=codelookup].mon_app_contexts", context);
    Iterator iter = element.getChildElements("mon_app_context");
    while (iter.hasNext()) {
      element = (IConfigElement) iter.next();
      if (element.getChildValue("name").equals(mon_app_context)) {
        codeIter = element.getChildElements("codetype");
        break;
      }
    }
    if (codeIter == null) return null;
    Vector v = new Vector();
    while (codeIter.hasNext()) {
      element = (IConfigElement) codeIter.next();
      v.add(element.getAttributeValue("id"));
    }
    codetypes = (String []) v.toArray(codetypes);
    return codetypes;
  }

  private IConfigElement getConfigElement(String codeType, Context context) {

    IConfigElement codetype = null;
    IConfigElement element = ConfigService.getConfigLookup().lookupElement(
        "component[id=codelookup].mon_app_contexts", context);
    Iterator iter = element.getChildElements("mon_app_context");
    while (iter.hasNext()) {
      element = (IConfigElement) iter.next();
      if (element.getChildValue("name").equals(mon_app_context)) {
        codetype = element.getChildElement("codetype[id=" + codeType + "]");
        break;
      }
    }
    return codetype;
  }

  private String mon_app_context;
  private Context context;

}
