/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.appconfig.test;

import com.documentum.fc.client.DfServiceException;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.IDfSessionManager;
import com.documentum.web.form.control.Breadcrumb;
import com.monsanto.dctm.appconfig.AppConfig;
import com.monsanto.dctm.component.test.IMonTestableComponent;
import com.monsanto.dctm.component.test.MockBreadcrumb;

/**
 * Filename:    $RCSfile: MockAppConfig.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: lakench $    	 On:	$Date:
 * 2007/08/21 05:23:14 $
 *
 * @author lakench
 * @version $Revision: 1.3 $
 */
public class MockAppConfig extends AppConfig implements IMonTestableComponent {
  private IDfSessionManager sessionManager;
  /**
   * @noinspection FieldNameHidesFieldInSuperclass
   */
  protected static final String BASE_QUERY = AppConfig.BASE_QUERY;
  /**
   * @noinspection FieldNameHidesFieldInSuperclass
   */
  protected static final String QUERY_ORDERBY = AppConfig.QUERY_ORDERBY;
  public boolean jumpedToAdministrationComponent = false;

  protected void initControls() {
    super.initControls();
  }

  /**
   * @noinspection RefusedBequest
   */
  protected void jumpToAdministrationComponent() {
    jumpedToAdministrationComponent = true;
  }

  /**
   * @noinspection RefusedBequest
   */
  public IDfSession getDfSession(int i) {
    try {
      return sessionManager.getSession(getCurrentDocbase());
    } catch (DfServiceException e) {
      e.printStackTrace();
    }
    return null;
  }

  public void setSessionManager(IDfSessionManager sessionManager) {
    this.sessionManager = sessionManager;
  }

  public IDfSessionManager getSessionManager() {
    return sessionManager;
  }

  /**
   * @noinspection RefusedBequest
   */
  protected Breadcrumb getBreadCrumbControl() {
    return (Breadcrumb) getControl(CONTROL_BREADCRUMB, MockBreadcrumb.class);
  }


}