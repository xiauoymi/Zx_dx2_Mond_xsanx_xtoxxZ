/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.appconfig;

import com.documentum.fc.client.DfQuery;
import com.documentum.fc.client.IDfCollection;
import com.documentum.fc.client.IDfQuery;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.IDfAttr;

import java.util.*;

/**
 * Filename:    $RCSfile: AppConfigAppUsageWorkingSet.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: lakench $    	 On:	$Date: 2007-08-21 05:23:14 $
 *
 * @author LAKENCH
 * @version $Revision: 1.1 $
 */
public class AppConfigAppUsageWorkingSet extends AppConfigItemWorkingSet {
  protected AppConfigAppUsageWorkingSet(String monAppContext, IDfSession session) throws
      DfException {
    super(monAppContext, session, "mon_app_usage");
    addAllExistingUsageTypes(session);
  }

  public List getColumnDescriptors() {
    List columnDescriptors = new ArrayList(2);
    columnDescriptors.add(new AppConfigColumnDescriptor("usage_type", "Feature", true, true, "Select a Usage Type"));
    columnDescriptors.add(new AppConfigColumnDescriptor("usage_enabled", "Enabled", true, true, "Unknown"));
    return columnDescriptors;
  }

  public String getObjectNameSuffix() {
    return "_app_usage";
  }

  public String getDeleteActionName() {
    return "removeappusage";
  }

  public void addAppConfigItem(AppConfigItem item) {
    AppConfigItem match = locateUsageByType(item.get("usage_type"));
    if (match != null) {
      super.removeAppConfigItem(match);
    }
    super.addAppConfigItem(item);
  }

  public boolean removeAppConfigItem(AppConfigItem appConfigItem) {
    boolean deleted = super.removeAppConfigItem(appConfigItem);
    if (deleted) {
      appConfigItem.set("usage_enabled", "Unknown");
      addAppConfigItem(appConfigItem);
    }
    return deleted;
  }

  protected IDfQuery createIDfQuery(String query) {
    IDfQuery dfQuery = new DfQuery();
    dfQuery.setDQL(query);
    return dfQuery;
  }

  private void addAllExistingUsageTypes(IDfSession session) throws DfException {
    Iterator existingUsages = executeDQL("select distinct usage_type from mon_app_usage", session).iterator();
    while (existingUsages.hasNext()) {
      Map usage = (Map) existingUsages.next();
      String usageType = (String) usage.get("usage_type");
      if (usageType != null && usageType.length() > 0) {
        if (locateUsageByType(usageType) == null) {
          usage.put("usage_enabled", "Unknown");
          addAppConfigItem(new AppConfigItem("mon_app_usage", usage));
        }
      }
    }
  }

  private AppConfigItem locateUsageByType(String usageType) {
    Iterator iterator = getAppConfigItems();
    while (iterator.hasNext()) {
      List appConfigItemValues = (List) iterator.next();
      if (appConfigItemValues.get(1).equals(usageType)) {
        Map values = new HashMap(3);
        values.put("rowid", appConfigItemValues.get(0));
        values.put("usage_type", appConfigItemValues.get(1));
        values.put("usage_enabled", appConfigItemValues.get(2));
        return new AppConfigItem("mon_app_usage", values);
      }
    }
    return null;
  }

  private List executeDQL(String query, IDfSession sess) throws DfException {
    IDfCollection col = null;
    IDfQuery qry = createIDfQuery(query);
    List results = new ArrayList();
    try {
      col = qry.execute((IDfSession) sess, IDfQuery.DF_READ_QUERY);
      results = createListFromCollection(col);
    } finally {
      if (col != null) {
        col.close();
      }
    }
    return results;
  }

  private List createListFromCollection(IDfCollection col) throws DfException {
    String value;
    List list = new ArrayList();
    while (col.next()) {
      int attrCount = col.getAttrCount();
      Map row = new HashMap(attrCount);
      for (int i = 0; i < attrCount; i++) {
        IDfAttr attr = col.getAttr(i);
        String attrName = attr.getName();
        value = col.getString(attrName);
        row.put(attrName, value);
      }
      list.add(row);
    }
    return list;
  }

}