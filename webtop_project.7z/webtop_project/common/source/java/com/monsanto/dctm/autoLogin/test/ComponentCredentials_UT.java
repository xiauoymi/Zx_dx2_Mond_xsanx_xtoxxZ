/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.autoLogin.test;

import com.monsanto.dctm.autoLogin.ComponentCredentials;
import junit.framework.TestCase;

/**
 * Filename:    $RCSfile: ComponentCredentials_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: lakench $
 * On:	$Date: 2007-07-31 18:51:49 $
 *
 * @author lakench
 * @version $Revision: 1.1 $
 */
public class ComponentCredentials_UT extends TestCase {
  private MockDocbaseMap testDocbaseMap;
  private MockAutoLoginResourceBundle credentialsList;

  protected void setUp() throws Exception {
    super.setUp();
    credentialsList = new MockAutoLoginResourceBundle();
    Object[][] credentialsListContents = new Object[][]{
        {"test$primary", "testdocbase,testuserid,testpassword,testdomain"},
        {"test$secondary", "test2docbase,test2userid,test2password,test2domain"}
    };
    credentialsList.setContents(credentialsListContents);
    testDocbaseMap = new MockDocbaseMap();

  }

  protected void tearDown() throws Exception {
    super.tearDown();
  }

  public void testNullCredentialsList() throws Exception {
    ComponentCredentials componentCredentials = new ComponentCredentials("test", null, testDocbaseMap);
    assertNull("docbase should be null", componentCredentials.getDocbase());
    assertNull("userid should be null", componentCredentials.getUser());
    assertNull("password should be null", componentCredentials.getPassword());
    assertNull("domain should be null", componentCredentials.getDomain());
    assertNull("login info should be null", componentCredentials.getLoginInfo());
  }

  public void testGetPrimaryCredentialsForComponent() throws Exception {
    testDocbaseMap.addDocbase("12345", "testdocbase", "Test Docbase Description");
    ComponentCredentials credentialsForComponent = new ComponentCredentials("test", credentialsList,
        testDocbaseMap);
    assertEquals("wrong docbase", "testdocbase", credentialsForComponent.getDocbase());
    assertEquals("wrong userid", "testuserid", credentialsForComponent.getUser());
    assertEquals("wrong password", "testpassword", credentialsForComponent.getPassword());
    assertEquals("wrong domain", "testdomain", credentialsForComponent.getDomain());
    assertNotNull("login info should not be null", credentialsForComponent.getLoginInfo());
    assertEquals("wrong login info userid", "testuserid", credentialsForComponent.getLoginInfo().getUser());
    assertEquals("wrong login info password", "testpassword", credentialsForComponent.getLoginInfo().getPassword());
    assertEquals("wrong login info domain", "testdomain", credentialsForComponent.getLoginInfo().getDomain());
  }

  public void testGetSecondaryCredentialsForComponent() throws Exception {
    testDocbaseMap.addDocbase("12345", "test2docbase", "Test Docbase Description");
    ComponentCredentials credentialsForComponent = new ComponentCredentials("test", credentialsList,
        testDocbaseMap);
    assertEquals("wrong docbase", "test2docbase", credentialsForComponent.getDocbase());
    assertEquals("wrong userid", "test2userid", credentialsForComponent.getUser());
    assertEquals("wrong password", "test2password", credentialsForComponent.getPassword());
    assertEquals("wrong domain", "test2domain", credentialsForComponent.getDomain());
    assertNotNull("login info should not be null", credentialsForComponent.getLoginInfo());
    assertEquals("wrong login info userid", "test2userid", credentialsForComponent.getLoginInfo().getUser());
    assertEquals("wrong login info password", "test2password", credentialsForComponent.getLoginInfo().getPassword());
    assertEquals("wrong login info domain", "test2domain", credentialsForComponent.getLoginInfo().getDomain());
  }

  public void testGetCredsForNonAutoLoginComponent() throws Exception {
    assertNull("creds should be null",
        new ComponentCredentials("test", credentialsList, testDocbaseMap).getLoginInfo());
  }
}