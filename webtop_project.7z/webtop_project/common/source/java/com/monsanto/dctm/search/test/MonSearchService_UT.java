/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.search.test;

import com.documentum.fc.client.search.IDfQueryManager;
import com.documentum.fc.client.search.IDfSearchService;
import com.documentum.fc.client.search.impl.DfSearchService;
import com.monsanto.dctm.component.test.MockSessionManager;
import com.monsanto.dctm.search.MonQueryManager;
import com.monsanto.dctm.search.MonSearchService;
import junit.framework.TestCase;

/**
 * Filename:    $RCSfile: MonSearchService_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: lakench $    	 On:	$Date: 2007-10-05 17:50:59 $
 *
 * @author lakench
 * @version $Revision: 1.1 $
 */
public class MonSearchService_UT extends TestCase {
  public void testCreate() throws Exception {
    MonSearchService monSearchService = new MonSearchService(
        new DfSearchService(new MockSessionManager(), "defaultMetadataDocbase"));
    assertNotNull(monSearchService);
    assertTrue(monSearchService instanceof IDfSearchService);
  }

  public void testNewQueryManager() throws Exception {
    MonSearchService monSearchService = new MonSearchService(
        new DfSearchService(new MockSessionManager(), "defaultMetadataDocbase"));
    IDfQueryManager queryManager = monSearchService.newQueryMgr();
    assertNotNull(queryManager);
    assertTrue(queryManager instanceof MonQueryManager);
  }
}