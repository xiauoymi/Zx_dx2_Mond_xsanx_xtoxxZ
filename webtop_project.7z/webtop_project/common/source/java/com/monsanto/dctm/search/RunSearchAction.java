package com.monsanto.dctm.search;

import com.documentum.debug.Trace;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.IDfSessionManager;
import com.documentum.fc.client.search.IDfQueryDefinition;
import com.documentum.fc.client.search.IDfSmartList;
import com.documentum.fc.client.search.IDfSmartListDefinition;
import com.documentum.fc.client.search.IDfSearchService;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfId;
import com.documentum.web.common.ArgumentList;
import com.documentum.web.common.WrapperRuntimeException;
import com.documentum.web.formext.component.Component;
import com.documentum.web.formext.config.Context;
import com.documentum.web.formext.config.IConfigElement;
import com.documentum.web.formext.docbase.FolderUtil;
import com.documentum.web.formext.session.DocbaseUtils;
import com.documentum.web.formext.session.SessionManagerHttpBinding;
import com.documentum.webcomponent.library.search.SearchInfo;

import java.io.IOException;

public class RunSearchAction extends
    com.documentum.webcomponent.library.actions.RunSearchAction {
  private IDfSearchService searchService;

  public boolean queryExecute(String strAction, IConfigElement config, ArgumentList arg, Context context,
                              Component component) {
    boolean bExecute = false;
    IDfSession session = null;
    String strObjectId = arg.get("objectId");
    try {
      if (!FolderUtil.isFolderType(strObjectId)) {
        com.documentum.fc.common.IDfId idSavedSearchObject = new DfId(strObjectId);
        String strDocbase = getDocbaseName(idSavedSearchObject);
        if (null != strDocbase && strDocbase.length() > 0) {
          session = getSessionManager().getSession(strDocbase);
          IDfSmartList obj = (IDfSmartList) session.getObject(idSavedSearchObject);
          if (null != obj) {
            long contentSize = obj.getContentSize();
            if ((double) contentSize > 0.40000000000000002D)
              bExecute = isSmartListQuery(obj);
          }
        }
      }
    }
    catch (DfException e) {
      throw new WrapperRuntimeException("Failed to get dm_smart_list (saved search object)", e);
    }
    finally {
      if (session != null)
        getSessionManager().release(session);
    }
    if (bExecute)
      addSearchParameters(arg, strObjectId);
    return bExecute;
  }

  protected IDfSessionManager getSessionManager() {
    return SessionManagerHttpBinding.getSessionManager();
  }

  protected String getDocbaseName(com.documentum.fc.common.IDfId idSavedSearchObject) throws DfException {
    return DocbaseUtils.getDocbaseNameFromId(idSavedSearchObject);
  }

  private boolean isSmartListQuery(IDfSmartList obj) {
    boolean bExecute = false;
    try {
      IDfSearchService searchService = getSearchService();
      IDfSmartListDefinition smartListDef = obj.getSmartListDefinition(searchService);
      IDfQueryDefinition queryDef = smartListDef.getQueryDefinition();
      if (queryDef != null && queryDef.isQueryBuilder())
        bExecute = true;
    }
    catch (IOException ioe) {
      Trace.println("Invalid smartlist format - exception = " + ioe);
    }
    catch (DfException dfe) {
      Trace.println("Invalid query/no rights to read content - exception = " + dfe);
    }
    return bExecute;
  }

  protected void setSearchService(IDfSearchService searchService) {
    this.searchService = searchService;
  }

  protected IDfSearchService getSearchService() {
    if (searchService == null) {
      SearchInfo searchInfo = new MonSearchInfo();
      searchService = searchInfo.getSearchService();
    }
    return searchService;
  }

  private void addSearchParameters(ArgumentList arg, String strObjectId) {
    String queryType = arg.get("queryType");
    if (null == queryType || queryType.length() == 0) {
      queryType = "objectId";
      arg.add("queryType", queryType);
      arg.add("query", strObjectId);
    }
    String navigation = arg.get("navigation");
    if (null == navigation || navigation.length() == 0)
      arg.add("navigation", "returnjump");
  }
}
