/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.component.test;

import com.documentum.fc.common.IDfAttr;

/**
 * Filename:    $RCSfile: MockDfAttr.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: lakench $    	 On:	$Date: 2007-04-25 16:51:05 $
 *
 * @author lakench
 * @version $Revision: 1.1 $
 */
public class MockDfAttr implements IDfAttr {
    private String name;

    public MockDfAttr(String name) {
        this.name = name;
    }

    public int getLength() {
        return 0;
    }

    public String getName() {
        return name;
    }

    public int getDataType() {
        return 0;
    }

    public boolean isRepeating() {
        return false;
    }

    public int getAllowedLength(String attrName) {
        return 0;
    }
}