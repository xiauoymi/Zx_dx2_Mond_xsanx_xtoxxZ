/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.search.test;

import com.documentum.fc.client.IDfSessionManager;
import com.documentum.fc.client.search.IDfSearchService;
import com.documentum.web.form.ComponentTestUtils;
import com.monsanto.dctm.component.test.MockSessionManager;
import com.monsanto.dctm.search.MonSearchService;
import com.monsanto.dctm.search.RepositorySearch;
import junit.framework.TestCase;

/**
 * Filename:    $RCSfile: RepositorySearch_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: lakench $
 * On:	$Date: 2007-10-12 05:21:59 $
 *
 * @author lakench
 * @version $Revision: 1.2 $
 */
public class RepositorySearch_UT extends TestCase {
  public void testCreate() throws Exception {
    RepositorySearch repositorySearch = new RepositorySearch();
    assertTrue(repositorySearch instanceof com.documentum.web.formext.control.docbase.search.RepositorySearch);
  }

  public void testGetSearchService() throws Exception {
    ComponentTestUtils.setCurrentDocbase("testdocbase");
    RepositorySearch repositorySearch = new MockRepositorySearch(new MockSessionManager());
    IDfSearchService searchService = repositorySearch.getSearchService();
    assertTrue(searchService instanceof MonSearchService);

    IDfSearchService searchServiceAgain = repositorySearch.getSearchService();

    assertEquals(searchService, searchServiceAgain);
  }

  public class MockRepositorySearch extends RepositorySearch {
    private IDfSessionManager sessionManager;

    public MockRepositorySearch(IDfSessionManager sessionManager) {
      this.sessionManager = sessionManager;
    }

    protected IDfSessionManager getSessionManager() {
      return sessionManager;
    }
  }
}