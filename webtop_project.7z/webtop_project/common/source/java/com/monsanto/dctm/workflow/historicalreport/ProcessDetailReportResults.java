package com.monsanto.dctm.workflow.historicalreport;

import com.monsanto.dctm.monAppContext.MonAppContextService;

public class ProcessDetailReportResults
        extends
        com.documentum.webcomponent.library.workflow.historicalreport.ProcessDetailReportResults {

    protected String getColumnsPreferenceId() {
        return super.getColumnsPreferenceId() + "." +
               MonAppContextService.getMonAppContextService().getMonAppContextInternalName();
    }

}
