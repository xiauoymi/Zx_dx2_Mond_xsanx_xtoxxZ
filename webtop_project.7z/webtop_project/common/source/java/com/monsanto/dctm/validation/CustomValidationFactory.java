/*
 * Created on Jun 21, 2005
 *
 */
package com.monsanto.dctm.validation;

import com.documentum.web.form.Form;
import com.documentum.web.formext.control.docbase.DocbaseObject;

public class CustomValidationFactory {
    Form i_Form;
    DocbaseObject i_docbaseObj;
    String strObjectType = null;

    public CustomValidationFactory(Form form, DocbaseObject docbaseObj) {
        i_Form = form;
        i_docbaseObj = docbaseObj;
    }

    public void setStrObjectType(String strObjectType) {
        this.strObjectType = strObjectType;
    }

    public CustomValidation getCustomValidationObject() {
        // Custom Validation Factory Method
        //   Add more else if clauses to this method to create an instance of your custom validation
        //   object when the object type is equal to your custom type

        if (strObjectType == null && i_docbaseObj != null) {
            strObjectType = i_docbaseObj.getType();
        }

        if (strObjectType != null) {
            if (strObjectType.equals("regulatory_affairs_document")) {
                return new RegulatoryAffairsLibraryValidation(i_Form, i_docbaseObj);
            } else if (strObjectType.equals("ag_pesticide_labels")) {
                return new AgPesticideLabelsValidation(i_Form, i_docbaseObj);
            } else if (strObjectType.equals("regulatory_biotech_mta")) {
                return new RegulatoryBiotechMTAValidation(i_Form, i_docbaseObj);
            }else if (strObjectType.equals("ext_rpt_doc")) {
                return new ExternalReportingValidation(i_Form, i_docbaseObj);
            }else if (strObjectType.equals("bzl_release_doc")) {
                return new BrazilReleaseValidation(i_Form, i_docbaseObj);
            }else if (strObjectType.equals("bzl_licenses_approvals_doc")) {
                return new BrazilLicensAppovalValidation(i_Form, i_docbaseObj);
            }else if (strObjectType.equals("bzl_import_export_doc")) {
                return new BrazilImportExportValidation(i_Form, i_docbaseObj);
            }else if (strObjectType.equals("bzl_reports_doc")) {
                return new BrazilReportsValidation(i_Form, i_docbaseObj);
            }else if (strObjectType.equals("seminis_doc")) {
                return new NotifyUserValidation(i_Form, i_docbaseObj);
            }

        }
        return new CustomValidation(i_Form, i_docbaseObj);

    }
}
