/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.action.test;

import com.documentum.fc.client.IDfSessionManager;
import com.documentum.fc.client.MockSession;
import com.documentum.web.common.ArgumentList;
import com.documentum.web.form.ComponentTestUtils;
import com.documentum.web.formext.Trace;
import com.documentum.web.formext.action.ActionService;
import com.documentum.web.formext.component.Component;
import com.documentum.web.formext.config.ConfigElement;
import com.documentum.web.formext.config.Context;
import com.documentum.web.formext.config.IConfigElement;
import com.monsanto.dctm.action.DRLViewPDFRendition;
import com.monsanto.dctm.component.test.MockSessionManager;
import com.monsanto.dctm.component.test.MockSysObject;
import com.monsanto.dctm.dctmSession.Session;
import com.monsanto.dctm.dctmSession.test.MockDctmSession;
import com.monsanto.dctm.drl.test.MockDRLViewOnlyComponent;
import junit.framework.TestCase;

import java.util.HashMap;

/**
 * Filename:    $RCSfile: DRLViewPDFRendition_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: lakench $
 * On:	$Date: 2007-10-26 18:47:58 $
 *
 * @author lakench
 * @version $Revision: 1.5 $
 */
public class DRLViewPDFRendition_UT extends TestCase {
  public static final String TESTOBJECTID = "0900000000000000";
  private Class componentClass;
  private String componentId;
  private String docbase;
  private MockSessionManager dfSessionManager;
  private MockSession session;
  private Component component;
  private MockSysObject object;

  protected void setUp() throws Exception {
    super.setUp();
    dfSessionManager = new MockSessionManager();
    session = new MockSession(dfSessionManager);
    object = new MockSysObject();
    componentClass = MockDRLViewOnlyComponent.class;
    componentId = "mockcomponent";
    docbase = "testdocbase";
    component = ComponentTestUtils.getComponent(componentClass, componentId, docbase, dfSessionManager);
  }

  protected void tearDown() throws Exception {
    ComponentTestUtils.releaseComponent(component);
    super.tearDown();
  }

  public void testExecute() throws Exception {
    Trace.PERSISTENTOBJECTCACHE = true;
    session.addObject(object, TESTOBJECTID);
    object.setString("r_object_id", TESTOBJECTID);
    object.addRendition("testpdfrendition", "pdf");
    dfSessionManager.setSession(session);
    MockDRLViewPDFRendition mockDRLViewPDFRendition = new MockDRLViewPDFRendition(
        dfSessionManager);
    ArgumentList args = new ArgumentList();
    args.add("objectId", TESTOBJECTID);
    args.add("contentType", "msw8");

    HashMap completionArgs = new HashMap();
    completionArgs.put(ActionService.COMPLETE_LISTENER, component);
    mockDRLViewPDFRendition
        .execute("drlview", new ConfigElement("actionid", "drlview"), args, new Context(), component, completionArgs);

    assertTrue(completionArgs.isEmpty());
  }

  public void testArgsDontChangeWhenNoPDFRenditionExists() throws Exception {
    session.addObject(object, TESTOBJECTID);
    object.setString("r_object_id", TESTOBJECTID);
    object.addRendition("testpdfrendition", "not a pdf");
    dfSessionManager.setSession(session);
    MockDRLViewPDFRendition mockDRLViewPDFRendition = new MockDRLViewPDFRendition(
        dfSessionManager);
    ArgumentList args = new ArgumentList();
    args.add("objectId", TESTOBJECTID);
    args.add("contentType", "msw8");

    mockDRLViewPDFRendition.replaceContentTypeArgIfPDFExists(args);
    assertEquals("msw8", mockDRLViewPDFRendition.args.get("contentType"));
  }

  public void testArgsDoChangeWhenPDFRenditionExists() throws Exception {
    session.addObject(object, TESTOBJECTID);
    object.setString("r_object_id", TESTOBJECTID);
    object.addRendition("testpdfrendition", "pdf");
    dfSessionManager.setSession(session);
    MockDRLViewPDFRendition mockDRLViewPDFRendition = new MockDRLViewPDFRendition(
        dfSessionManager);
    ArgumentList args = new ArgumentList();
    args.add("objectId", TESTOBJECTID);
    args.add("contentType", "msw8");

    mockDRLViewPDFRendition.replaceContentTypeArgIfPDFExists(args);
    assertEquals("pdf", mockDRLViewPDFRendition.args.get("contentType"));
  }

  class MockDRLViewPDFRendition extends DRLViewPDFRendition {
    public ArgumentList args;
    private IDfSessionManager dfSessionManager;

    public MockDRLViewPDFRendition(IDfSessionManager dfSessionManager) {
      this.dfSessionManager = dfSessionManager;
    }

    /**
     * @noinspection RefusedBequest
     */
    protected Session createSession() {
      return new MockDctmSession(dfSessionManager, "testdocbase");
    }

    protected void replaceContentTypeArgIfPDFExists(ArgumentList args) {
      super.replaceContentTypeArgIfPDFExists(args);
      this.args = args;
    }

    public boolean queryExecute(String strAction, IConfigElement config, ArgumentList args, Context context,
                                Component component) {
      boolean result = super.queryExecute(strAction, config, args, context, component);
      this.args = args;
      return result;
    }
  }
}