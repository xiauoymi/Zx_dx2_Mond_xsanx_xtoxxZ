/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.report;

import com.documentum.fc.client.DfQuery;
import com.documentum.fc.client.IDfCollection;
import com.documentum.fc.client.IDfQuery;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfLogger;
import com.documentum.fc.common.IDfAttr;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * Filename:    $RCSfile: DQLReport.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: lakench $    	 On:	$Date: 2007-04-25 16:51:05 $
 *
 * @author lakench
 * @version $Revision: 1.1 $
 */
public abstract class DQLReport extends DisplayReport {
    protected ArrayList getResults(HashMap criteria) {
        ArrayList results = new ArrayList();
        try {
            results = executeDQL(buildQuery(criteria), getDfSession());
        } catch (DfException e) {
            DfLogger.error(this, "Error getting report results", null, e);
        }
        return results;
    }

    protected IDfQuery createIDfQuery(String query) {
        IDfQuery dfQuery = new DfQuery();
        dfQuery.setDQL(query);
        return dfQuery;
    }

    private ArrayList executeDQL(String query, IDfSession sess) throws DfException {
        IDfCollection col = null;
        IDfQuery qry = createIDfQuery(query);
        ArrayList results = new ArrayList();
        try {
            col = qry.execute((IDfSession) sess, IDfQuery.DF_READ_QUERY);
            results = createArrayListFromCollection(col);
        } finally {
            if (col != null) {
                col.close();
            }
        }
        return results;
    }

    private ArrayList createArrayListFromCollection(IDfCollection col) throws DfException {
        String value;
        ArrayList list = new ArrayList();
        while (col.next()) {
            int attrCount = col.getAttrCount();
            String[] row = new String[attrCount];
            for (int i = 0; i < attrCount; i++) {
                IDfAttr attr = col.getAttr(i);
                String attrName = attr.getName();
                value = col.getString(attrName);
                row[i] = value;
            }
            list.add(row);
        }
        return list;
    }

    public abstract String buildQuery(HashMap criteria);
}