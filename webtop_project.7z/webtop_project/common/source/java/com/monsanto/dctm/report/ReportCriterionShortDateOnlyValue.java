/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.report;

import com.documentum.fc.common.DfLogger;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Filename:    $RCSfile: ReportCriterionShortDateOnlyValue.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: lakench $    	 On:	$Date: 2007-04-25 16:51:05 $
 *
 * @author LAKENCH
 * @version $Revision: 1.1 $
 */
public class ReportCriterionShortDateOnlyValue extends ReportCriterionValue {

    public String getValue() {

        String displayvalue = super.getValue();
        String formattedDate = null;
        Date date = new Date();
        if (displayvalue != null) {
            try {
                date = DateFormat.getDateInstance(DateFormat.MEDIUM).parse(displayvalue);
            } catch (ParseException e) {
                DfLogger.error(this, "can't parse date criteria, returning today's date", null, e);
            }
        }
        formattedDate = new SimpleDateFormat("MM/dd/yyyy").format(date);
        return formattedDate;
    }
}