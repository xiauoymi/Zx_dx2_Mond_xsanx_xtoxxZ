package com.monsanto.dctm.report;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import com.documentum.web.common.ArgumentList;
import com.documentum.web.form.Control;
import com.documentum.web.form.Form;
import com.documentum.web.form.IControlListener;
import com.documentum.web.form.control.Label;
import com.documentum.web.form.control.databound.ColumnDescriptor;
import com.documentum.web.form.control.databound.DataPaging;
import com.documentum.web.form.control.databound.DataProvider;
import com.documentum.web.form.control.databound.Datagrid;
import com.documentum.web.form.control.databound.TableResultSet;
import com.documentum.web.formext.component.Component;
import com.documentum.web.formext.component.ComponentColumnDescriptorList;
import com.documentum.web.formext.config.Context;
import com.documentum.web.formext.config.IConfigElement;
import com.documentum.web.formext.config.IConfigLookup;
import com.monsanto.dctm.spreadsheet.SpreadsheetFromDatagrid;

public abstract class DisplayReport extends Component {
	
	private TableResultSet m_searchResultSet;
	private Datagrid m_datagrid;
	private transient DataProvider m_dataProvider;
	public static final String CONTROL_GRID = "doclistgrid";
	public static final String CONTROL_PAGER = "docpager";
	public static final String CONTROL_QUERY_DESCRIPTION = "querydescription";
	private ComponentColumnDescriptorList m_columns;
	private ArrayList reportResultList = new ArrayList();
	private HashMap criteria;
	private HashMap criteriaDisplay;
	
	public boolean canCommitChanges() {
		return false; 
	}
	
	public boolean canCancelChanges() {
		return getComponentPage().equals("start");
	}
	
	public boolean hasNextPage() {
		return getComponentPage().equals("start");
	}
	
	public boolean hasPrevPage() {
		return !(getComponentPage().equals("start"));
	}
	
	public boolean onNextPage() {
		if (getComponentPage().equals("start"))
		{
			setComponentPage("results");
			Label title = (Label) ((Component) getContainer()).getControl("title", Label.class);
			title.setLabel(getString("MSG_RESULTSTITLE"));
			ArgumentList args = new ArgumentList();
			initSearch(args);
			return true;
		}
		else
		{
			return super.onNextPage();
		}
	}
	
	public boolean onPrevPage() {
		if (getComponentPage().equals("results"))
		{
			setComponentPage("start");
			Label title = (Label) ((Component) getContainer()).getControl("title", Label.class);
			title.setLabel(getString("MSG_CRITERIATITLE"));
			return true;
		}
		else
		{
			return super.onNextPage();
		}
	}
	
	public void onRender()
	{
		if (!getComponentPage().equals("start"))
		{
			int nItems = getPageSizePreferences();
			((Datagrid)getControl("doclistgrid", com.documentum.web.form.control.databound.Datagrid.class)).getDataProvider().setPaged(true);
			((Datagrid)getControl("doclistgrid", com.documentum.web.form.control.databound.Datagrid.class)).getDataProvider().setPageSize(nItems);
			((Label)getControl("querydescription", com.documentum.web.form.control.Label.class)).setLabel(getResultsDescription());
			refreshResultsDisplay();
		}

		super.onRender();
	}
	
	public void onClickExportToExcel(Control ctrl, ArgumentList args)
	{
		new SpreadsheetFromDatagrid((Datagrid) getControl("doclistgrid"), getColumns(), getPageContext().getServletContext()).displaySpreadsheet(this);
	}
	
	protected int getPageSizePreferences()
	{
		IConfigLookup lookup = getConfigLookup();
		Integer nItems;
		nItems = lookup.lookupInteger("application.display.classic", new Context());
		int nPageSize = 10;
		if(nItems != null)
			nPageSize = nItems.intValue();
		return nPageSize;
	}
	
	protected String getResultsDescription()
	{
		StringBuffer resultsDescription = new StringBuffer();
		resultsDescription.append(getReportName());
		resultsDescription.append(" : ");
		resultsDescription.append(getCriteriaDescription());
		return resultsDescription.toString();
	}
	
	private String getCriteriaDescription() {
		Iterator criteria = lookupElement("criteria").getChildElements("criterion");
		StringBuffer criteriaDescription = new StringBuffer();
		boolean firstCriterion = true;
		while (criteria.hasNext())
		{
			if (!firstCriterion)
			{
				criteriaDescription.append(", ");
			}
			
			Criterion criterion = new Criterion((IConfigElement) criteria.next());
			
			criteriaDescription.append(criterion.getLabel());
			criteriaDescription.append(" = ");
			criteriaDescription.append(criteriaDisplay.get(criterion.getName()));
			
			if (firstCriterion)
			{
				firstCriterion = false;
			}
		}
		
		return criteriaDescription.toString();
	}
	
	private String getReportName() {
		return lookupString("reportname");
	}
	
	protected void initSearch(ArgumentList args)
	{
		m_datagrid = (Datagrid)getControl("doclistgrid", com.documentum.web.form.control.databound.Datagrid.class);
		DataPaging dataPaging = (DataPaging)getControl("docpager", com.documentum.web.form.control.databound.DataPaging.class);
		dataPaging.setEventHandler("onnextpage", "onNextPageClicked", this);
		dataPaging.setEventHandler("onlastpage", "onLastPageClicked", this);
		ReportCriteria criteriaControl = (ReportCriteria) getControl("criteria", ReportCriteria.class);
		criteria = getCriteriaValues(criteriaControl.getCriteria());
		criteriaDisplay = getCriteriaDisplay(criteriaControl.getCriteria());
		reportResultList = getResults(criteria);
		executeQuery();
	}
	
	private HashMap getCriteriaDisplay(HashMap criteriaFromControl) {
		Iterator criteria = criteriaFromControl.keySet().iterator();
		HashMap criteriaValues = new HashMap(criteriaFromControl.size());
		while (criteria.hasNext())
		{
			String criterion = (String) criteria.next();
			String[] criterionValue = (String[]) criteriaFromControl.get(criterion);
			criteriaValues.put(criterion, criterionValue[1]);
		}
		return criteriaValues;
	}
	
	private HashMap getCriteriaValues(HashMap criteriaFromControl) {
		Iterator criteria = criteriaFromControl.keySet().iterator();
		HashMap criteriaValues = new HashMap(criteriaFromControl.size());
		while (criteria.hasNext())
		{
			String criterion = (String) criteria.next();
			String[] criterionValue = (String[]) criteriaFromControl.get(criterion);
			criteriaValues.put(criterion, criterionValue[0]);
		}
		return criteriaValues;
	}
	
	protected abstract ArrayList getResults(HashMap criteria);
	
	private void initDisplayAttributes()
	{
		setDisplayAttributesFromPreferences();
	}
	
	protected String getColumnConfigElementName()
	{
		return "columns";
	}
	
	protected void setDisplayAttributesFromPreferences()
	{
		setColumns(new ComponentColumnDescriptorList(this, getColumnConfigElementName(), null));
	}
	
	protected ComponentColumnDescriptorList getColumns()
	{
		return m_columns;
	}
	
	protected void setColumns(ComponentColumnDescriptorList columns)
	{
		m_columns = columns;
	}
	
	protected void executeQuery()
	{
		initDisplayAttributes();    
		Iterator colDescriptors = m_columns.getColumnDescriptors().iterator();
		String[] columns = new String[m_columns.getColumnDescriptors().size()];
		int i = 0;
		while (colDescriptors.hasNext())
		{
			ColumnDescriptor colDescriptor = (ColumnDescriptor) colDescriptors.next();
			String colLabel = colDescriptor.getAttribute();
			columns[i] = colLabel;
			i++;
		}            
		m_searchResultSet = new TableResultSet(reportResultList, columns);
		m_dataProvider = m_datagrid.getDataProvider();
		m_dataProvider.setScrollableResultSet(m_searchResultSet);
		onNextPageClicked(null, null);
	}
	
	public synchronized void onLastPageClicked(Control control, ArgumentList args)
	{
		m_dataProvider.lastPage();
	}
	
	public synchronized void onNextPageClicked(Control control, ArgumentList args)
	{
		m_dataProvider.nextPage();
	}
	
	private void refreshResultsDisplay()
	{
		m_dataProvider.clearSort();
		setRefreshDataRequired(true, true);
		boolean fFirstRefresh = false;
		m_dataProvider.refresh(m_searchResultSet);
		if(m_dataProvider.getDataHandler() == null)
		{
			fFirstRefresh = true;
			m_dataProvider.initBind();
		}
		int pageSize = getPageSizePreferences();
		m_dataProvider.setPageSize(pageSize);
		m_dataProvider.getDataHandler().setPageSize(pageSize);
		m_datagrid.getDataProvider().setPageSize(pageSize);
		m_dataProvider.initBind();
		if(fFirstRefresh)
			m_dataProvider.setCurrentPage(0);
	}
}
