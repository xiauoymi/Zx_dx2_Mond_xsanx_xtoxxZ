/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.monAppContext;

import com.documentum.web.formext.config.IConfigElement;

import java.util.Iterator;

/**
 * Filename:    $RCSfile: AppXmlMonAppContext.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: lakench $    	 On:	$Date: 2007-01-19 14:43:43 $
 *
 * @author lakench
 * @version $Revision: 1.1 $
 */
public class AppXmlMonAppContext implements IMonAppContext {
    private IConfigElement configElement;

    public AppXmlMonAppContext(IConfigElement configElement) {
        this.configElement = configElement;
    }

    public String getInternalName() {
        return configElement.getChildValue("internal_name");
    }

    public boolean isUseViewForCommentingEnabled() {
        Boolean useViewForCommentingEnabled = configElement.getChildValueAsBoolean("use_view_for_commenting_enabled");
        if (useViewForCommentingEnabled != null)
            return useViewForCommentingEnabled.booleanValue();
        else
            return true;
    }

    public boolean isDocbaseSupported(String docbase) {
        boolean noDocbaseDefined = true;

        IConfigElement configElementDocbases = configElement.getChildElement("docbases");
        if (configElementDocbases != null) {
            Iterator iteratorDocbases = configElementDocbases.getChildElements("docbase");
            while (iteratorDocbases.hasNext()) {
                noDocbaseDefined = false;
                IConfigElement configDocbase = (IConfigElement) iteratorDocbases.next();
                if (configDocbase.getValue().equals(docbase)) {
                    return true;
                }
            }
        }
        return noDocbaseDefined;
    }
}