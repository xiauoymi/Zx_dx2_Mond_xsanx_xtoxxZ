package com.monsanto.dctm.validation;

import com.documentum.web.form.Form;
import com.documentum.web.form.control.validator.BaseValidator;
import com.documentum.web.formext.control.docbase.DocbaseObject;
import com.documentum.web.formext.control.docbase.DocbaseAttributeValue;
import com.documentum.web.formext.control.validator.DocbaseAttributeValidator;
import com.documentum.fc.common.DfLogger;

import java.util.Iterator;

/**
 * Created by IntelliJ IDEA.
 * User: ussing
 * Date: Dec 1, 2009
 * Time: 10:27:29 AM
 * To change this template use File | Settings | File Templates.
 */
public class BrazilImportExportValidation extends CustomValidation {
    public BrazilImportExportValidation(Form form, DocbaseObject docbaseObj) {
        super(form, docbaseObj);

        i_Form.setDoValidation(true);
        DfLogger.debug(this, "do validation? = " + i_Form.getDoValidation(), null, null);

        doCustomValidation = true;  //if we've created an instance of this object, we need custom validation
    }
    protected void customValidate() {
       getAttributes();
       bIsValid = true;
       strErrorMessage = "";
       if (doCustomValidation)
       {
         resetAllAttributesThatWillBeMadeRequiredConditionally();
         String importExportType = null;
         if (hAttributes.containsKey("imp_exp_type")) {
            importExportType = hAttributes.get("imp_exp_type").toString();
         }
         DfLogger.debug(this,"importExportType = " + importExportType,null,null);

         if(importExportType.equals("importa��o prote�na")){
           getProteinValidation();
         }
         if(importExportType.toString().equals("importa��o LPMA")){
           getLpmaCtnbioProcessNoValidation();
         }
         if(importExportType.toString().equals("import")){
           getMapaImportProcessNoValidation();

         }
         if(importExportType.toString().equals("exporta��o")){
           getExportPetitionNumberValidation();
           getPhytosanitaryCertificateNumberValidation();
         }
         super.customValidate();
         resetAttributeFromValidator();
       }
     }

    private void getPhytosanitaryCertificateNumberValidation() {
         if (!((hAttributes.get("phytosanitary_certificate").toString() != null) && (hAttributes.get("phytosanitary_certificate").toString().length() > 0))){
           bIsValid = false;
           strErrorMessage += "You must specify num_certificado_fitossanitario.</li><li>";
           ((DocbaseAttributeValue) hAttributesControls.get("phytosanitary_certificate")).setRequired(true);
         }         
    }

    private void getExportPetitionNumberValidation() {
         if (!((hAttributes.get("export_petition_number").toString() != null) && (hAttributes.get("export_petition_number").toString().length() > 0))){
           bIsValid = false;
           strErrorMessage += "You must specify num_requerimento_exportacao.</li><li>";
           ((DocbaseAttributeValue) hAttributesControls.get("export_petition_number")).setRequired(true);
         } 
    }

    private void getMapaImportProcessNoValidation() {
         if (!((hAttributes.get("mapa_import_process_no").toString() != null) && (hAttributes.get("mapa_import_process_no").toString().length() > 0))){
           bIsValid = false;
           strErrorMessage += "You must specify num_processo_importacao_MAPA.</li><li>";
           ((DocbaseAttributeValue) hAttributesControls.get("mapa_import_process_no")).setRequired(true);
         }
    }

    private void getLpmaCtnbioProcessNoValidation() {
         if (!((hAttributes.get("lpma_ctnbio_process_no").toString() != null) && (hAttributes.get("lpma_ctnbio_process_no").toString().length() > 0))){
           bIsValid = false;
           strErrorMessage += "You must specify num_processo_LPMA_CTNBio.</li><li>";
           ((DocbaseAttributeValue) hAttributesControls.get("lpma_ctnbio_process_no")).setRequired(true);
         }
    }

    private void getProteinValidation() {
         if (!((hAttributes.get("protein").toString() != null) && (hAttributes.get("protein").toString().length() > 0))){
           bIsValid = false;
           strErrorMessage += "You must specify proteina.</li><li>";
           ((DocbaseAttributeValue) hAttributesControls.get("protein")).setRequired(true);
         }
    }

    private void resetAllAttributesThatWillBeMadeRequiredConditionally() {
     ((DocbaseAttributeValue) hAttributesControls.get("protein")).setRequired(false);
     ((DocbaseAttributeValue) hAttributesControls.get("lpma_ctnbio_process_no")).setRequired(false);
     ((DocbaseAttributeValue) hAttributesControls.get("mapa_import_process_no")).setRequired(false);
     ((DocbaseAttributeValue) hAttributesControls.get("export_petition_number")).setRequired(false);
     ((DocbaseAttributeValue) hAttributesControls.get("phytosanitary_certificate")).setRequired(false);
   }
    private void resetAttributeFromValidator() {
    		// Go through the validators again and if we have one for one of the
		//   attributes we're making conditionally required, remove it.  This prevents
		//   the error message from being duplicated in the summary and works around
		//   what is believed to be a bug when you change the attribute to not required
		//   and the error stays in the summary.  The asterisk will always be there
		//   when a field is required since the validator control is recreated when
		//   an attribute is marked as required.  Removing it at this point prevents
		//   the error summary from picking up this validator's error message.
		Iterator validators = vValidators.iterator();
		while(validators.hasNext())
		{
			BaseValidator validator = (BaseValidator) validators.next();
			if (!(validator instanceof DocbaseAttributeValidator))
			{
				DfLogger.debug(this, "validator: " + validator,null,null);
				DfLogger.debug(this, "controltovalidate: " + validator.getControlToValidate(),null,null);
			}
			if (!validator.getIsValid())
			{
				if (validator.getControlToValidate().getName() != null)
				{
					String attribute = (String) hAttrbiutesValueElementControls.get(validator.getControlToValidate().getName());
                    DfLogger.debug(this,"attribute: " + attribute,null,null);
					if (attribute != null)
					{
					    if (attribute.equals("protein") || attribute.equals("lpma_ctnbio_process_no")
                                || attribute.equals("mapa_import_process_no") || attribute.equals("export_petition_number")
                                || attribute.equals("phytosanitary_certificate"))
                        {
							DfLogger.debug(this,"I'm removing this validator: " + validator,null,null);
							validator.getForm().remove(validator);
						}
					}
				}
			}
		}
    }
}
