/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.component.test;

import com.documentum.fc.client.IDfSession;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfLoginInfo;
import com.documentum.web.form.ComponentTestUtils;
import com.monsanto.dctm.component.ComponentSessionManager;
import junit.framework.TestCase;

/**
 * Filename:    $RCSfile: ComponentSessionManager_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: lakench $
 * On:	$Date: 2007-10-26 18:47:58 $
 *
 * @author lakench
 * @version $Revision: 1.4 $
 */
public class ComponentSessionManager_UT extends TestCase {
  private MockSessionManager mockSessionManager;

  protected void setUp() throws Exception {
    super.setUp();
    mockSessionManager = new MockSessionManager();
    DfLoginInfo dfLoginInfo = new DfLoginInfo();
    dfLoginInfo.setUser("testuserid");
    mockSessionManager.setIdentity("testdocbase", dfLoginInfo);
  }

  public void testCreateWithJustComponent() throws Exception {
    MockComponent component = (MockComponent) ComponentTestUtils
        .getComponent(MockComponent.class, "testcomponent", "testdocbase", mockSessionManager);

    ComponentSessionManager componentSessionManager = new ComponentSessionManager(component);

    assertNotNull(componentSessionManager);

    ComponentTestUtils.releaseComponent(component);
  }

  public void testReturnsSessionAssociatedWithComponentWhenNoAutoLoginEntry() throws Exception {
    IDfSession expectedSession = mockSessionManager.getSession("testdocbase");
    MockComponent component = (MockComponent) ComponentTestUtils
        .getComponent(MockComponent.class, "testcomponent", "testdocbase", mockSessionManager);

    ComponentSessionManager componentSessionManager = new ComponentSessionManager(component);
    assertNotNull(componentSessionManager);
    IDfSession sessionForComponent = componentSessionManager.getSessionForComponent();

    assertEquals(expectedSession, sessionForComponent);
    ComponentTestUtils.releaseComponent(component);
  }

  public void testReturnsSessionAssociatedWithComponentWithAutoLoginEntry() throws Exception {
    IDfSession expectedSession = mockSessionManager.getSession("testdocbase");
    MockComponent component = (MockComponent) ComponentTestUtils
        .getComponent(MockComponent.class, "support", "testdocbase", mockSessionManager);

    ComponentSessionManager componentSessionManager = new ComponentSessionManager(component);
    assertNotNull(componentSessionManager);
    IDfSession sessionForComponent = componentSessionManager.getSessionForComponent();

    assertNotSame(expectedSession, sessionForComponent);

    ComponentTestUtils.releaseComponent(component);
  }

  public void testCreateWithComponentIDDocbaseAndSessionManager() throws Exception {
    ComponentSessionManager componentSessionManager = new ComponentSessionManager("testcomponentid", "testdocbase",
        mockSessionManager);

    assertNotNull(componentSessionManager);
  }

  public void testCreateWithNullDocbase() throws Exception {
    ComponentSessionManager componentSessionManager = new ComponentSessionManager("testcomponentid", null,
        mockSessionManager);

    assertNotNull(componentSessionManager);
  }

  public void testGetSessionForComponentWithNoComponentConstructorAndNoAutoLoginEntry() throws Exception {
    IDfSession expectedSession = mockSessionManager.getSession("testdocbase");

    ComponentSessionManager componentSessionManager = new ComponentSessionManager("testcomponentid", "testdocbase",
        mockSessionManager);

    IDfSession sessionForComponent = componentSessionManager.getSessionForComponent();

    assertEquals(expectedSession, sessionForComponent);
  }

  public void testGetSessionForComponentWithNoComponentConstructorNullDocbaseAndNoAutoLoginEntry() throws Exception {
    ComponentSessionManager componentSessionManager = new ComponentSessionManager("testcomponentid", null,
        mockSessionManager);

    try {
      componentSessionManager.getSessionForComponent();
    } catch (DfException e) {
      assertEquals("exception message not set properly",
          "failed to get component credentials for component id: testcomponentid", e.getMessage());
      return;
    }
    fail("Expected DfException");
  }

  public void testGetSessionForComponentWithNoComponentConstructorNullDocbaseAndAutoLoginEntry() throws Exception {
    IDfSession expectedSession = mockSessionManager.getSession("testdocbase");
    ComponentSessionManager componentSessionManager = new ComponentSessionManager("support", null, mockSessionManager);
    assertNotNull(componentSessionManager);
    IDfSession sessionForComponent = componentSessionManager.getSessionForComponent();

    assertNotSame(expectedSession, sessionForComponent);
  }

  public void testCreateWithJustComponentIdAndSessionManager() throws Exception {
    ComponentSessionManager componentSessionManager = new ComponentSessionManager("testcomponentid",
        mockSessionManager);

    assertNotNull(componentSessionManager);
  }

  public void testGetSessionForComponentWithComponentIdAndSessionManagerConstructorAndNoAutoLoginEntry() throws
      Exception {
    ComponentSessionManager componentSessionManager = new ComponentSessionManager("testcomponentid",
        mockSessionManager);

    try {
      componentSessionManager.getSessionForComponent();
    } catch (DfException e) {
      assertEquals("exception message not set properly",
          "failed to get component credentials for component id: testcomponentid", e.getMessage());
      return;
    }
    fail("Expected DfException");
  }

  public void testGetSessionForComponentWithComponentIdAndSessionManagerConstructorAndAutoLoginEntry() throws
      Exception {
    IDfSession expectedSession = mockSessionManager.getSession("testdocbase");
    ComponentSessionManager componentSessionManager = new ComponentSessionManager("support", mockSessionManager);
    assertNotNull(componentSessionManager);
    IDfSession sessionForComponent = componentSessionManager.getSessionForComponent();

    assertNotSame(expectedSession, sessionForComponent);
  }
}