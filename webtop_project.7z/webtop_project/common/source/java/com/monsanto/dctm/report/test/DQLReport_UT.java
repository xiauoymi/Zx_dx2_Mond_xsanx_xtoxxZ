/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.report.test;

import com.documentum.fc.client.MockSession;
import com.documentum.web.form.ComponentTestUtils;
import com.monsanto.dctm.component.test.MockDfQuery;
import com.monsanto.dctm.component.test.MockSessionManager;
import com.monsanto.dctm.report.DisplayReport;
import junit.framework.TestCase;

import java.util.*;

/**
 * Filename:    $RCSfile: DQLReport_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: lakench $    	 On:	$Date:
 * 2007/04/25 16:51:05 $
 *
 * @author lakench
 * @version $Revision: 1.2 $
 */
public class DQLReport_UT extends TestCase {
  public MockSessionManager mockSessionManager;
  public MockSession session;
  public MockDQLReport component;

  protected void setUp() throws Exception {
    super.setUp();
    mockSessionManager = new MockSessionManager();
    session = new MockSession(mockSessionManager);
    ((MockSessionManager) mockSessionManager).setSession(session);
    component = (MockDQLReport) ComponentTestUtils
        .getComponent(MockDQLReport.class, "dqlreport", "testdocbase", mockSessionManager);

  }

  protected void tearDown() throws Exception {
    ComponentTestUtils.releaseComponent(component);
    super.tearDown();
  }

  public void testCreate() throws Exception {
    MockDQLReport mock = new MockDQLReport();
    assertTrue(mock instanceof DisplayReport);
  }

  public void testGetResults() throws Exception {
    setupResults();
    ArrayList results = component.getResults(null);
    ArrayList expectedResults = createExpectedResults();
    assertNotNull(results);
    assertTrue(((MockDfQuery) component.dfQuery).collection.isClosed);
    assertEquals("select title from dm_document", component.dfQuery.getDQL());
    assertEquals(expectedResults.size(), results.size());
    assertResults(expectedResults, results);
  }

  private ArrayList createExpectedResults() {
    ArrayList expectedResults = new ArrayList();
    String[] row = new String[2];
    row[0] = "Test title";
    row[1] = "18";
    expectedResults.add(row);
    return expectedResults;
  }

  private void setupResults() {
    List mockResults = new ArrayList();
    Map mockRow = new HashMap();
    List titles = new ArrayList();
    titles.add("Test title");
    mockRow.put("title", titles);
    List counts = new ArrayList();
    counts.add("18");
    mockRow.put("count", counts);
    mockResults.add(mockRow);
    component.setMockResults(mockResults);
  }

  public void testGetDifferentResults() throws Exception {
    setupDifferentResults();
    ArrayList results = component.getResults(null);
    ArrayList expectedResults = createExpectedDifferentResults();
    assertNotNull(results);
    assertTrue(((MockDfQuery) component.dfQuery).collection.isClosed);
    assertEquals("select title from dm_document", component.dfQuery.getDQL());
    assertEquals(expectedResults.size(), results.size());
    assertResults(expectedResults, results);
  }

  private ArrayList createExpectedDifferentResults() {
    ArrayList expectedResults = new ArrayList();
    String[] row = new String[2];
    row[0] = "A different test title";
    row[1] = "23";
    expectedResults.add(row);
    return expectedResults;
  }

  private void setupDifferentResults() {
    List mockResults = new ArrayList();
    Map mockRow = new HashMap();
    List titles = new ArrayList();
    titles.add("A different test title");
    mockRow.put("title", titles);
    List counts = new ArrayList();
    counts.add("23");
    mockRow.put("count", counts);
    mockResults.add(mockRow);
    component.setMockResults(mockResults);
  }

  public void testGetMultipleRows() throws Exception {
    setupMultipleRowResults();
    ArrayList results = component.getResults(null);
    ArrayList expectedResults = createExpectedMultipleRowResults();
    assertNotNull(results);
    assertTrue(((MockDfQuery) component.dfQuery).collection.isClosed);
    assertEquals("select title from dm_document", component.dfQuery.getDQL());
    assertEquals(expectedResults.size(), results.size());
    assertResults(expectedResults, results);
  }

  private ArrayList createExpectedMultipleRowResults() {
    ArrayList expectedResults = new ArrayList();
    String[] row1 = new String[2];
    row1[0] = "Test title";
    row1[1] = "18";
    String[] row2 = new String[2];
    row2[0] = "A different test title";
    row2[1] = "23";
    expectedResults.add(row1);
    expectedResults.add(row2);
    return expectedResults;
  }

  private void setupMultipleRowResults() {
    Map mockRow1 = new HashMap();
    List titles1 = new ArrayList();
    titles1.add(0, "Test title");
    mockRow1.put("title", titles1);
    List counts1 = new ArrayList();
    counts1.add(0, "18");
    mockRow1.put("count", counts1);
    Map mockRow2 = new HashMap();
    List titles2 = new ArrayList();
    titles2.add(0, "A different test title");
    mockRow2.put("title", titles2);
    List counts2 = new ArrayList();
    counts2.add(0, "23");
    mockRow2.put("count", counts2);
    List mockResults = new ArrayList();
    mockResults.add(mockRow1);
    mockResults.add(mockRow2);
    component.setMockResults(mockResults);
  }

  private void assertResults(ArrayList expectedResults, ArrayList actualResults) {
    Iterator actualRows = actualResults.iterator();
    for (int rowNumber = 0; actualRows.hasNext(); rowNumber++) {
      List actualRow = Arrays.asList((String[]) actualRows.next());
      List expectedRow = Arrays.asList((String[]) expectedResults.get(rowNumber));
      assertTrue(actualRow.containsAll(expectedRow));
    }
  }

}