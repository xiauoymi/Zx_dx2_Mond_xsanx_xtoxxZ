/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.component.test;

import com.documentum.web.form.Form;
import com.documentum.web.form.IControlListener;

import java.util.HashSet;
import java.util.Set;

/**
 * Filename:    $RCSfile: MockForm.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: lakench $    	 On:	$Date: 2007-01-04 22:41:10 $
 *
 * @author lakench
 * @version $Revision: 1.1 $
 */
public class MockForm extends Form {
    private Set controlListeners;

    public void addControlListener(IControlListener iControlListener) {
        super.addControlListener(iControlListener);
        if (controlListeners == null)
            controlListeners = new HashSet(1);
        controlListeners.add(iControlListener);
    }

    public boolean isControlListener(IControlListener controlListener) {
        return controlListeners.contains(controlListener);
    }
}