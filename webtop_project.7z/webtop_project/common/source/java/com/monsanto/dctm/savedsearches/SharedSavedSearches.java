package com.monsanto.dctm.savedsearches;

import com.documentum.web.form.control.databound.Datagrid;
import com.documentum.webcomponent.library.savedsearches.MySavedSearches;
import com.monsanto.dctm.monAppContext.MonAppContextService;

public class SharedSavedSearches extends MySavedSearches {
    protected void initDataGrid() {
        Datagrid searchgrid = (Datagrid) getControl("mysavedsearches_grid",
                                                    com.documentum.web.form.control.databound.Datagrid.class);
        String monAppContext = MonAppContextService.getMonAppContextService(getCurrentDocbase())
                .getCurrentMonAppContextName();
        searchgrid.getDataProvider().setQuery(
                "select upper(object_name) as upperobjname, r_object_id, object_name, title, r_modify_date, owner_name, r_object_type, r_lock_owner, i_is_reference, i_is_replica, r_link_cnt, r_is_virtual_doc, r_content_size, a_content_type, r_assembled_from_id, r_has_frzn_assembly, a_compound_architecture from dm_sysobject where (r_object_type = 'dm_smart_list' and a_content_type = 'dm_internal' and subject='" +
                monAppContext + "') or (r_object_type = 'dm_query' and subject='" + monAppContext + "') order by 1");
    }
}
