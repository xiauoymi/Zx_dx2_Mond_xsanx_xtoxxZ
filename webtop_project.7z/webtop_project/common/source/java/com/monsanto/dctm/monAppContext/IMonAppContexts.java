/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.monAppContext;

import java.util.List;

/**
 * Filename:    $RCSfile: IMonAppContexts.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: lakench $    	 On:	$Date: 2007-01-19 14:43:43 $
 *
 * @author lakench
 * @version $Revision: 1.1 $
 */
public interface IMonAppContexts {
    public abstract IMonAppContext getMonAppContext(String currentMonAppContextName);

    public abstract List getMonAppContextNameList(String docbase);
}