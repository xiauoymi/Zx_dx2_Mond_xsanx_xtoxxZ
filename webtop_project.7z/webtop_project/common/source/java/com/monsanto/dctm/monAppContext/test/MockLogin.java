/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.monAppContext.test;

import com.documentum.fc.client.IDfSessionManager;
import com.documentum.web.form.control.databound.DataDropDownList;
import com.documentum.web.formext.session.SessionManagerHttpBinding;
import com.monsanto.dctm.component.test.IMonTestableComponent;
import com.monsanto.dctm.monAppContext.Login;

/**
 * Filename:    $RCSfile: MockLogin.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: lakench $ On:	$Date:
 * 2007/03/06 22:10:49 $
 *
 * @author lakench
 * @version $Revision: 1.1 $
 */
public class MockLogin extends Login implements IMonTestableComponent {
  private IDfSessionManager sessionManager;

  public void setSessionManager(IDfSessionManager sessionManager) {
    this.sessionManager = sessionManager;
  }

  public IDfSessionManager getSessionManager() {
    return sessionManager;
  }

  public void setCurrentlySelectedDocbase(String docbase) {
    DataDropDownList docbaseDropdown = getDocbaseControl();
    docbaseDropdown.setValue(docbase);
    SessionManagerHttpBinding.setCurrentDocbase(docbase);
  }

  public DataDropDownList getDocbaseControl() {
    return ((DataDropDownList) getControl("docbase",
        DataDropDownList.class));
  }

  public String getCurrentlySelectedMonAppContext() {
    return getMonAppContextControl().getValue();
  }

  public DataDropDownList getMonAppContextControl() {
    return (DataDropDownList) getControl(CONTROL_MON_APP_CONTEXT);
  }

  protected void initMonAppContextDropdown() {
    super.initMonAppContextDropdown();
  }

  protected void updateMonAppContextControl() {
    super.updateMonAppContextControl();
  }

  protected void updateMonAppContext() {
    super.updateMonAppContext();
  }
}