package com.monsanto.dctm.validation;

import com.documentum.web.form.Form;
import com.documentum.web.form.control.validator.BaseValidator;
import com.documentum.web.formext.control.docbase.DocbaseObject;
import com.documentum.web.formext.control.docbase.DocbaseAttributeValue;
import com.documentum.web.formext.control.validator.DocbaseAttributeValidator;
import com.documentum.fc.common.DfLogger;

import java.util.Iterator;
import java.util.Vector;

/**
 * Created by IntelliJ IDEA.
 * User: ussing
 * Date: Feb 17, 2010
 * Time: 4:13:30 PM
 * To change this template use File | Settings | File Templates.
 */
public class BrazilReportsValidation extends CustomValidation {
    public BrazilReportsValidation(Form form, DocbaseObject docbaseObj) {
        super(form, docbaseObj);

        i_Form.setDoValidation(true);
        DfLogger.debug(this, "do validation? = " + i_Form.getDoValidation(), null, null);

        doCustomValidation = true;  //if we've created an instance of this object, we need custom validation
    }
    protected void customValidate() {
      getAttributes();
      bIsValid = true;
      strErrorMessage = "";
      //doCustomValidation = true; // need to uncomment it for UT's to pass
      if (doCustomValidation)
      {
        resetAllAttributesThatWillBeMadeRequiredConditionally();
         if(hAttributes.get("report_type").toString().equals("MONITORAMENTO") ||
                 (hAttributes.get("report_type").toString().equals("AUDITORIA")) )
          {
           getCropValidation();
           getEventValidation();
         }
            super.customValidate();
          resetAttributeFromValidator();
       }
     }
    private void getCropValidation() {
         if (!((hAttributes.get("crop").toString() != null) && (hAttributes.get("crop").toString().length() > 0))){
           bIsValid = false;
           strErrorMessage += "You must specify cultura.</li><li>";
           ((DocbaseAttributeValue) hAttributesControls.get("crop")).setRequired(true);
         }
    }

    private void getEventValidation() {
//         if (!((hAttributes.get("event1").toString() != null) && (hAttributes.get("event1").toString().length() > 0))){
//           bIsValid = false;
//           strErrorMessage += "You must specify evento.</li><li>";
//           ((DocbaseAttributeValue) hAttributesControls.get("event1")).setRequired(true);
//         }
        validateEvent();
    }
    private void resetAllAttributesThatWillBeMadeRequiredConditionally() {
     ((DocbaseAttributeValue) hAttributesControls.get("crop")).setRequired(false);
     ((DocbaseAttributeValue) hAttributesControls.get("event1")).setRequired(false);
   }
   private void validateEvent() {
    Vector repeatingAttributeVector = (Vector) hAttributes.get("event1");
    Iterator repeatingAttributeValues = repeatingAttributeVector.iterator();
    boolean bEmpty = true;
    String repeatingAttributeValue = null;
    while(repeatingAttributeValues.hasNext())
    {
      repeatingAttributeValue = repeatingAttributeValues.next().toString();
      if ((repeatingAttributeValue != null) && (repeatingAttributeValue).length() > 0)
      {
        bEmpty = false;
      }
    }
    if (repeatingAttributeVector.isEmpty() || bEmpty)
    {
      bIsValid = false;
      strErrorMessage += "You must specify evento.</li><li>";
      ((DocbaseAttributeValue) hAttributesControls.get("event1")).setRequired(true);
    }
  }
    private void resetAttributeFromValidator() {
    		// Go through the validators again and if we have one for one of the
		//   attributes we're making conditionally required, remove it.  This prevents
		//   the error message from being duplicated in the summary and works around
		//   what is believed to be a bug when you change the attribute to not required
		//   and the error stays in the summary.  The asterisk will always be there
		//   when a field is required since the validator control is recreated when
		//   an attribute is marked as required.  Removing it at this point prevents
		//   the error summary from picking up this validator's error message.
		Iterator validators = vValidators.iterator();
		while(validators.hasNext())
		{
			BaseValidator validator = (BaseValidator) validators.next();
			if (!(validator instanceof DocbaseAttributeValidator))
			{
				DfLogger.debug(this, "validator: " + validator,null,null);
				DfLogger.debug(this, "controltovalidate: " + validator.getControlToValidate(),null,null);
			}
			if (!validator.getIsValid())
			{
				if (validator.getControlToValidate().getName() != null)
				{
					String attribute = (String) hAttrbiutesValueElementControls.get(validator.getControlToValidate().getName());
                    DfLogger.debug(this,"attribute: " + attribute,null,null);
					if (attribute != null)
					{
					    if (attribute.equals("crop") || attribute.equals("event1"))
                        {
							DfLogger.debug(this,"I'm removing this validator: " + validator,null,null);
							validator.getForm().remove(validator);
						}
					}
				}
			}
		}
    }
 }