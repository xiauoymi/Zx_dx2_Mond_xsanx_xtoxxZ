/*
 * Created on May 25, 2005
 */
package com.monsanto.dctm.validation;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Vector;

import com.documentum.web.form.Form;
import com.documentum.web.form.control.validator.BaseValidator;
import com.documentum.web.formext.control.docbase.DocbaseAttributeValue;
import com.documentum.web.formext.control.docbase.DocbaseObject;
import com.documentum.web.formext.control.docbase.FindValidAttributeValue;
import com.documentum.web.formext.control.validator.DocbaseObjectValidator;

public class CustomValidation implements ICustomValidation {

	// Set initial values for whether or not the attributes are correct and the error message
	// The logic used here requires the following:
	//   A type/object constraint defined in DAB that always evaluates to false.  This allows 
	//       me to use a jsp that displays the attributes using just a dmfx:docbaseattributelist 
	//       tag.  This results in a DocbaseObjectValidator being created.  This code will run 
	//       the DocbaseObjectValdator's validate method if and only if the attributes do not pass
	//       the integrity check.  The error message is overridden, so you can set it to anything 
	//       in DAB.
	
	protected Form i_Form = null;
	protected DocbaseObject i_docbaseObj = null;
	protected HashMap hAttributes = new HashMap();
	protected boolean bIsValid = true;
	protected String strErrorMessage = "";
	protected boolean doCustomValidation = false;
	protected DocbaseObjectValidator objDocbaseObjectValidator = null;
	protected HashMap hAttributesControls = new HashMap();
	protected Vector vValidators = new Vector();
	protected HashMap hAttrbiutesValueElementControls = new HashMap();
	
	public CustomValidation(Form form, DocbaseObject docbaseObj)
	{
		i_Form = form;
		i_docbaseObj = docbaseObj;
	}
	


	public boolean getDoCustomValidation()
	{
		return doCustomValidation;
	}
	
	public boolean isValid() {
		getAttributes();
		bIsValid = true;
		strErrorMessage = "";
		customValidate();
		return bIsValid;
	}
	
	protected void getAttributes()
	{
		// Get values of all the attributes and store them in a HashMap for easy retrieval.  This 
		//   only gets attributes that are currently displayed, so showpagesastabs must be false.  
		//   It also seems to have problems with attributes being in the Show More area, so there 
		//   should not be any attributes defined as Secondary in DAB when using this code.		
		FindValidAttributeValue v = new FindValidAttributeValue(i_docbaseObj.getName());
		i_Form.visitDepthFirst(v);
		Iterator it = v.getAttributeValues();
		int intReadOnlyAttrs = 0;
		int intTotalNumOfAttrs = 0;
		while (it.hasNext() == true)
		{
			intTotalNumOfAttrs++;
			DocbaseAttributeValue value = (DocbaseAttributeValue) it.next();
			hAttributesControls.put(value.getAttribute(), value);
			hAttrbiutesValueElementControls.put(value.getElementName("value"), value.getAttribute());
			if (value.isRepeating())
			{
				hAttributes.put(value.getAttribute(), value.getValues());
			}
			else
			{
				hAttributes.put(value.getAttribute(), value.getValue());
			}
			
			if (value.isReadonly())
			{
				intReadOnlyAttrs++;
			}
		}
		
		//If we didn't find any attributes or all attributes are read only, no need to do any validation since the attribs can't change
		System.out.println("total = " + intTotalNumOfAttrs + " read only = " + intReadOnlyAttrs);
		if (intTotalNumOfAttrs == 0 || intReadOnlyAttrs == intTotalNumOfAttrs || hAttributes.isEmpty())
		{
			doCustomValidation = false;
		}
	}
	
	protected void customValidate()
	{
		// Your custom validation object will override this method and call 
		//   super.customValidate at the end.
		
		// Do the things normal validate does:
		//   We need to go ahead and validate any validators that exist on the 
		//   page, with the exception of the DocbaseObjectValidator.  It gets 
		//   handled separately since we're using it to display our custom 
		//   error message.
		//   We do this by looping through all the validators, checking to see 
		//   if it's the DocbaseObjectValidator.  If it is, do the special 
		//   handling, if not, just run the validator's validate method.
		Iterator validators = i_Form.getValidators();
		vValidators.clear();
		
		while(validators.hasNext())
		{
			BaseValidator validator =  (BaseValidator) validators.next();
			vValidators.add(validator);
			
			if (validator instanceof DocbaseObjectValidator && doCustomValidation)
			{
				objDocbaseObjectValidator = (DocbaseObjectValidator) validator;
			}
			else
			{
				validator.validate();
				bIsValid = bIsValid && validator.getIsValid();
			}
		}
		if (!bIsValid && objDocbaseObjectValidator != null)
		{			
			objDocbaseObjectValidator.setVisible(true);
			objDocbaseObjectValidator.setEnabled(true);
			objDocbaseObjectValidator.validate();  //validate() sets the error message to what's in the DataDictionary
			objDocbaseObjectValidator.setEncodeLabel(false);  //So the html tags don't show through.
			
			System.out.println("after we ran setencodelabel, strErrorMessage = '" + strErrorMessage + "'");
			
			//if (strErrorMessage.lastIndexOf("</li>") > 0)
			//{
			//	strErrorMessage = strErrorMessage.substring(0, strErrorMessage.lastIndexOf("</li>"));
			//}
			String strOrigErrorMessage = objDocbaseObjectValidator.getErrorMessage();
			
			System.out.println("strOrigErrorMessage = '" + strOrigErrorMessage + "'");
			
			if (strOrigErrorMessage != null && strOrigErrorMessage.lastIndexOf("&nbsp;:&nbsp;An object level expression constraint is violated") != -1)
				strOrigErrorMessage = strOrigErrorMessage.substring(0, strOrigErrorMessage.lastIndexOf("&nbsp;:&nbsp;An object level expression constraint is violated"));
			
			System.out.println("strOrigErrorMessage after filter = '" + strOrigErrorMessage + "'");
			
			objDocbaseObjectValidator.setErrorMessage(strErrorMessage); // + strOrigErrorMessage);  //Reset the error message
			
			System.out.println("docbase object's error message now = '" + objDocbaseObjectValidator.getErrorMessage() + "'");
			//When the form is redrawn, the error message will be displayed.
		}
		else if (objDocbaseObjectValidator != null)
		{
			objDocbaseObjectValidator.setEnabled(false);
			objDocbaseObjectValidator.setVisible(false);
		}
	}
	
	protected boolean oneOrTheOtherValidation(String repeatingAttribute, String repeatingLabel, String singleAttribute, String singleLabel)
	{
		// This seemed like it might be useful for other object types.  It helps
		//   the case where you have a repeating attribute with value assistance
		//   in which one of the values is Other.  A second single valued attribute
		//   is to contain a description for the "other" value.  This code makes
		//   sure a value is specified for the repeating value and that if you 
		//   choose Other, a value is specified for the single valued attribute.
		//   One improvement that could be made is to have this method look up
		//   the labels in the DataDictionary instead of taking them as parameters.
		//   They're used to construct the error message.
		boolean bPassed = true;
		Vector repeatingAttributeVector = (Vector) hAttributes.get(repeatingAttribute);
		String singleAttributeValue = hAttributes.get(singleAttribute).toString();
		Iterator repeatingAttributeValues = repeatingAttributeVector.iterator();
		boolean bFoundOther = false;
		boolean bEmpty = true;
		String repeatingAttributeValue = null;
		while(repeatingAttributeValues.hasNext())
		{
			repeatingAttributeValue = repeatingAttributeValues.next().toString();
			if ((repeatingAttributeValue != null) && (repeatingAttributeValue).length() > 0)
			{
				bEmpty = false;
				if (repeatingAttributeValue.equals("Other"))
				{
					bFoundOther = true;
				}
			}
		}
		if (repeatingAttributeVector.isEmpty() || bEmpty)
		{
			if (!((singleAttributeValue != null) && (singleAttributeValue.length() > 0)))
			{
				bPassed = false;
				strErrorMessage += "You must specify " + repeatingLabel + ".<br />";
			}
			else
			{
				bPassed = false;
				strErrorMessage += "If you specify " + singleLabel + ", you must select Other for " + repeatingLabel + ".<br />";
			}
		}
		else
		{
			if (bFoundOther)
			{
				if (!((singleAttributeValue != null) && (singleAttributeValue.length() > 0)))
				{
					bPassed = false;
					strErrorMessage += "If you specify Other for " + repeatingLabel + ", you must specify "+ singleLabel + ".";
				}
			}
			else
			{
				if ((singleAttributeValue != null) && (singleAttributeValue.length() > 0))
				{
					bPassed = false;
					strErrorMessage += "If you specify " + singleLabel + ", you must select Other for " + repeatingLabel + ".<br />";
				}
			}
		}
		return bPassed;
	}
}
