/*
 Copyright:  Copyright � 2006 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.support;

import com.documentum.web.form.Control;
import com.documentum.web.form.control.LinkTag;

import javax.servlet.jsp.JspWriter;
import java.io.IOException;

/**
 * Filename:    $RCSfile: MailtolinkTag.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: lakench $    	 On:	$Date: 2007-01-13 08:44:09 $
 *
 * @author LAKENCH
 * @version $Revision: 1.2 $
 */
public class MailtolinkTag extends LinkTag {
    private String emailAddress;

    public MailtolinkTag() {
        emailAddress = null;
    }

    public void setEmailAddress(String emailAddress) {
        this.emailAddress = emailAddress;
    }

    protected Class getControlClass() {
        return Mailtolink.class;
    }

    protected void setControlProperties(Control control) {
        super.setControlProperties(control);

        Mailtolink mailtolink = (Mailtolink) control;
        if (emailAddress != null)
            mailtolink.setEmailAddress(emailAddress);
    }

    public void release() {
        emailAddress = null;
        super.release();
    }

    protected void renderLinkStart(JspWriter out) throws IOException {
        Mailtolink mailtolink = (Mailtolink) getControl();
        if (mailtolink.isVisible()) {
            super.renderStartToolTip(out);
            StringBuffer buf = generateLinkHtml(mailtolink);
            out.print(buf.toString());
        }
    }

    protected StringBuffer generateLinkHtml(Mailtolink mailtolink) {
        StringBuffer buf = new StringBuffer(255);
        String strClass = mailtolink.getCssClass();
        String strStyle = mailtolink.getCssStyle();
        String strEmailAddress = mailtolink.getEmailAddress();
        if (mailtolink.isEnabled()) {

            buf.append("<a");
            if (strClass != null)
                buf.append(" class=\"").append(strClass).append("\"");
            if (strStyle != null)
                buf.append(" style=\"").append(strStyle).append("\"");
            if (strEmailAddress != null)
                buf.append(" href=\"mailto:").append(strEmailAddress).append("\"");
            else
                buf.append(" href=\"mailto:").append(mailtolink.getLabel()).append("\"");
            buf.append(">");
        }
        if (mailtolink.getLabel() != null && mailtolink.getLabel().length() != 0) {
            buf.append(formatText(mailtolink.getLabel()));
            if (mailtolink.isEnabled())
                buf.append("</a>");
        }
        return buf;
    }

}