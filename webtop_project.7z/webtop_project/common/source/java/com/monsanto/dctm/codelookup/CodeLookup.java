/*
 * CodeLookup.java
 *
 * Created on January 11, 2006, 1:44 PM
 *
 * To change this template, choose Tools | Options and locate the template under
 * the Source Creation and Management node. Right-click the template and choose
 * Open. You can then make changes to the template in the Source Editor.
 */

package com.monsanto.dctm.codelookup;

import com.documentum.web.common.ArgumentList;
import com.documentum.web.form.Control;
import com.documentum.web.form.control.DropDownList;
import com.documentum.web.form.control.Option;
import com.documentum.web.form.control.Text;
import com.documentum.web.form.control.databound.Datagrid;
import com.documentum.web.formext.component.Component;
import com.monsanto.dctm.monAppContext.MonAppContextService;

/**
 * @author tsvedan
 */
public class CodeLookup extends Component {

    /**
     * Creates a new instance of CodeLookup
     */
    public CodeLookup() {
        config = new NewCodeLookupConfig(getMonAppContext(), getDfSession());
    }

    public void onInit(ArgumentList args) {
        super.onInit(args);
        codetypes = config.getCodeTypes();
        setCodeTypeOptions();
        Datagrid datagrid = (Datagrid) getControl("codelookupgrid",
                                                  com.documentum.web.form.control.databound.Datagrid.class);
        datagrid.getDataProvider().setDfSession(getDfSession());
        datagrid.getDataProvider().setQuery(buildQuery());
//        updateBreadCrumb();
    }

    protected void updateControls(String strQuery) {
        Datagrid datagrid = (Datagrid) getControl("codelookupgrid");
        datagrid.getDataProvider().setQuery(strQuery);
        datagrid.getDataProvider().refresh();
    }

    public void onRefreshData() {
        super.onRefreshData();
        ((Datagrid) getControl("codelookupgrid")).getDataProvider().refresh();
    }

    public void onRender() {
        super.onRender();
        Datagrid datagrid = (Datagrid) getControl("codelookupgrid");
        datagrid.getDataProvider().setDfSession(getDfSession());
    }

    public void onSelectCodeType(Control control, ArgumentList args) {
        DropDownList filterCnt = (DropDownList) getControl("filter");
        String codeType = filterCnt.getValue();
        StringBuffer query = new StringBuffer(
                "select code_type,coded_value,decoded_value,xref_value,sort_value from dm_dbo.code_lookup");
        if (codeType.length() > 0) {
            query.append(" where LOWER(code_type) = '");
            query.append(codeType.toLowerCase()).append("'");
        }
        query.append(" order by 1,3");
        updateControls(query.toString());
    }

    public void onClickJumpTo(Control control, ArgumentList args) {
        Text nameCtl = (Text) getControl("jumptotextbox");
        String codeType = nameCtl.getValue();
        codeType = codeType.trim();
        StringBuffer query = new StringBuffer(
                "select code_type,coded_value,decoded_value,xref_value,sort_value from dm_dbo.code_lookup");
        if (codeType.length() > 0) {
            query.append(" where LOWER(code_type) like '");
            query.append(codeType.toLowerCase()).append("%'");
        }
        query.append(" order by 1,3");
        updateControls(query.toString());
    }

    protected String buildQuery() {
        StringBuffer query = new StringBuffer(
                "select code_type,coded_value,decoded_value,xref_value,sort_value from dm_dbo.code_lookup ");

        if (codetypes != null && codetypes.length > 0) {
            query.append("where code_type in (");
            query.append("'").append(codetypes[0]).append("'");
            for (int i = 0; i < codetypes.length; i++) {
//                System.out.println("Code Type = " + codetypes[i]);
                if (i > 0)
                    query.append(",'").append(codetypes[i]).append("'");
            }
            query.append(") ");
        } else
            query.append("where code_type is null ");
        query.append("order by 1,3");
//        System.out.println("Code Lookup Query:: " + query);
        return query.toString();
    }

    protected String getMonAppContext() {
        return (MonAppContextService.getMonAppContextService()).getCurrentMonAppContextName();
    }

    protected void setCodeTypeOptions() {
        DropDownList filterCnt = (DropDownList) getControl("filter", DropDownList.class);
        filterCnt.clearOptions();
        if (codetypes != null && codetypes.length > 0) {
            for (int i = 0; i < codetypes.length; i++) {
                Option opt = new Option();
                opt.setValue(codetypes[i]);
                opt.setLabel(codetypes[i]);
                filterCnt.addOption(opt);
            }
        } else {
            Option opt = new Option();
            opt.setValue("");
            opt.setLabel("");
            filterCnt.addOption(opt);
        }
    }

    private ICodeLookupConfig config;
    private String [] codetypes;
}
