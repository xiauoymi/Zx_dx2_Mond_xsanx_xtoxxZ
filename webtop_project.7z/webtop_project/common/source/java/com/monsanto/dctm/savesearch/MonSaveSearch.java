/*
 * MonSaveSearch.java
 *
 * Created on November 14, 2005, 4:13 PM
 *
 * To change this template, choose Tools | Options and locate the template under
 * the Source Creation and Management node. Right-click the template and choose
 * Open. You can then make changes to the template in the Source Editor.
 */

package com.monsanto.dctm.savesearch;

import com.documentum.fc.client.search.IDfSmartList;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfId;
import com.documentum.web.common.ArgumentList;
import com.documentum.webcomponent.library.savesearch.SaveSearchEx;
import com.documentum.webcomponent.library.search.SearchInfo;
import com.monsanto.dctm.monAppContext.MonAppContextService;

public class MonSaveSearch extends SaveSearchEx {

    private String m_queryId;

    public void onInit(ArgumentList arg) {
        super.onInit(arg);

        m_queryId = arg.get("queryId");
    }

    public boolean onCommitChanges() {
        boolean savedSearch = super.onCommitChanges();

        if (savedSearch) {
            SearchInfo searchInfo = SearchInfo.getInstance(m_queryId);
            try {
                IDfSmartList smartlist = (IDfSmartList) getDfSession().getObject(new DfId(searchInfo.getObjectId()));
                smartlist.setSubject(MonAppContextService
                        .getMonAppContextService(getCurrentDocbase()).getCurrentMonAppContextName());
                smartlist.save();
            }
            catch (DfException e) {
                e.printStackTrace();
            }
        }
        return savedSearch;
    }
}
