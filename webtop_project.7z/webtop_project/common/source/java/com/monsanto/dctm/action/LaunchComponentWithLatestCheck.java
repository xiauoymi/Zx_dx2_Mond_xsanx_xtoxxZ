/*
 * LaunchComponentWithLatestCheck.java
 *
 * Created on October 10, 2005, 9:29 AM
 *
 * To change this template, choose Tools | Options and locate the template under
 * the Source Creation and Management node. Right-click the template and choose
 * Open. You can then make changes to the template in the Source Editor.
 */

package com.monsanto.dctm.action;

import java.util.Map;

import com.documentum.fc.client.IDfSysObject;
import com.documentum.fc.common.DfId;
import com.documentum.nls.NlsResourceBundle;
import com.documentum.web.common.ArgumentList;
import com.documentum.web.common.ErrorMessageService;
import com.documentum.web.formext.Trace;
import com.documentum.web.formext.action.LaunchComponentWithPermitCheck;
import com.documentum.web.formext.component.Component;
import com.documentum.web.formext.config.Context;
import com.documentum.web.formext.config.IConfigElement;



/**
 *
 * @author tsvedan
 */
public class LaunchComponentWithLatestCheck extends LaunchComponentWithPermitCheck {
	
	/** Creates a new instance of LaunchComponentWithLatestCheck */
	public LaunchComponentWithLatestCheck() {
	}
	
	public boolean execute(
			String strAction,
			IConfigElement config,
			ArgumentList args,
			Context context,
			Component component,
			Map completionArgs) {
		if (strAction.equals("editfile") || strAction.equals("checkout")){
			try{
				String strObjectId = args.get("objectId");
				IDfSysObject sysobj = (IDfSysObject) component.getDfSession().getObject(new DfId(strObjectId));
				if(!sysobj.getLatestFlag()){
					String nlsprop = config.getChildValue("nlsbundle");
					NlsResourceBundle nlsResBndl = new NlsResourceBundle(nlsprop);
					ErrorMessageService.getService().setNonFatalError(nlsResBndl, "MSG_ERROR_CHECKING_OUT", component, null, null);
				} else return super.execute(strAction, config, args, context, component, completionArgs);
			} catch (Exception e){
				if(Trace.COMPONENT)
					com.documentum.web.common.Trace.println("An Exception occured in LaunchComponentWithLatestCheck.execute('" +
							strAction + "'...'" + context.toString() + "': " + e);
			}
		} else return super.execute(strAction, config, args, context, component, completionArgs);
		return false;
	} //execute   
}
