package com.monsanto.dctm.notepage;

import com.documentum.fc.common.DfException;

public class NotePage extends com.documentum.webtop.webcomponent.notepage.NotePage 
{

	protected void updateBookmark() throws DfException {
		getControl("notepage_bookmark", com.monsanto.dctm.viewprocessor.BookmarkLink.class);
		super.updateBookmark();
	}

}
