/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.dctmSession;

import com.documentum.fc.client.*;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfId;

/**
 * Filename:    $RCSfile: DocumentumSessionInstance.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: lakench $    	 On:	$Date: 2007-03-16 21:41:19 $
 *
 * @author lakench
 * @version $Revision: 1.2 $
 */
public class DocumentumSessionInstance implements SessionInstance {
    private IDfSession dfSession = null;
    private IDfSessionManager dfSessionManager = null;

    public DocumentumSessionInstance(IDfSessionManager dfSessionManager, String docbase) throws DfServiceException,
                                                                                                DfIdentityException,
                                                                                                DfAuthenticationException {
        this.dfSessionManager = dfSessionManager;
        this.dfSession = dfSessionManager.getSession(docbase);
    }

    public void release() {
        dfSessionManager.release(dfSession);
    }

    public Object getObject(String objectId) {
        try {
            return dfSession.getObject(new DfId(objectId));
        } catch (DfException e) {
            throw new SessionClosedException(e);
        }
    }
}