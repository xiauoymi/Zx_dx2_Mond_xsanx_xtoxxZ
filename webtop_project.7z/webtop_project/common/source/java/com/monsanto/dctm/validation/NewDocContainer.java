/*
 * Created on May 24, 2005
 */
package com.monsanto.dctm.validation;

import com.documentum.fc.client.IDfSysObject;
import com.documentum.fc.common.DfId;
import com.documentum.web.common.ArgumentList;
import com.documentum.web.form.Control;
import com.documentum.web.form.control.Tab;
import com.documentum.web.form.control.Tabbar;
import com.documentum.web.formext.action.ActionService;
import com.documentum.web.formext.component.Component;
import com.documentum.web.formext.config.Context;
import com.documentum.web.formext.control.docbase.DocbaseObject;
import com.documentum.web.formext.session.SessionManagerHttpBinding;
import com.documentum.webcomponent.library.create.NewDocument;

import java.util.ArrayList;
import java.util.Iterator;

/**
 * @author lakench
 */
public class NewDocContainer extends
                             com.documentum.webcomponent.library.create.NewDocContainer {
    protected String strObjectType = "no_custom_validation";
    protected Component m_component;
    protected DocbaseObject m_docbaseObj;
    protected boolean doCustomValidation = false;
    protected CustomValidation customValidationObject = null;
    protected boolean isValid;

    public boolean onNextComponent(Control control, ArgumentList args) {
        if (doCustomValidation) {
            if (onNewComponentTab()) {
                // create new object before switch to other tabs
                if (m_bNeedCreate) {
                    boolean bCreateSuccess = createObject();
                    if (bCreateSuccess) {
                        // disable new component tab to prevent switching back
                        Tab tabNew = getNewTab();
                        if (tabNew != null) {
                            tabNew.setEnabled(false);
                        }
                        m_bNeedCreate = false;
                    } else {
                        // don't switch since creation didn't succeed
                        return false;
                    }
                } else {
                    // don't switch if create page info not ok yet
                    return false;
                }
            }
            Tabbar tabs = (Tabbar) getControl(TABBAR_CONTROL_NAME);
            if (tabs != null) {
                Tab selectedTab = tabs.getSelectedTab();
                Iterator iterator = tabs.getTabs();
                while (iterator.hasNext()) {
                    Tab tab = (Tab) iterator.next();
                    if (tab.equals(selectedTab)) {
                        tab = null;
                        // move down to the next enabled and visible tab
                        while (iterator.hasNext()
                               && !((tab = (Tab) iterator.next()).isEnabled()
                                    && tab.isVisible())) {
                        }

                        // if we encountered a new tab and it was enabled
                        if (tab != null && tab.isVisible() && tab.isEnabled()) {
                            String strComponentId = tab.getName();
                            setCurrentComponent(strComponentId);
                            tabs.setValue(strComponentId);

                            return true;
                        } else {
                            tab = null;
                            // move down to the next enabled and visible tab
                            while (iterator.hasNext()
                                   && !((tab = (Tab) iterator.next()).isEnabled()
                                        && tab.isVisible())) {
                            }

                            // if we encountered a new tab and it was enabled
                            if (tab != null && tab.isVisible() && tab.isEnabled()) {
                                String strComponentId = tab.getName();
                                setCurrentComponent(strComponentId);
                                tabs.setValue(strComponentId);
                                return true;
                            } else {
                                return false;
                            }
                        }
                    }
                }
            }
            return false;

        } else {
            return super.onNextComponent(control, args);
        }
    }

    protected void validate(boolean bIgnoreDoValidateFlag) {
        if (doCustomValidation) {
            isValid = customValidationObject.isValid();
            if (!isValid)  // Did the custom validation fail?
            {
                setInvalid();  // Set the form to invalid
            } else  // Do the trick of turning off validation on the form, then
            // run validation to set the form back to valid
            {
                boolean bTempDoValidationFlag = getTopForm().getDoValidation(); //remember state of validation
                getTopForm().setDoValidation(false); // turn validation off
                super.validate(false);  //"setValid()" since validation is off
                getTopForm().setDoValidation(bTempDoValidationFlag); //reset validation
            }
        } else  //do regular validation
        {
            super.validate(bIgnoreDoValidateFlag);
        }
    }

    public void onRender() {
        if (doCustomValidation) //makes sure the error message is displayed correctly since something between validate and render resets it
        {
            isValid = customValidationObject.isValid();
        }
        super.onRender();
    }

    public void onRenderEnd() //does some initializing that has to occur after the docbase object tag exists
    {
        super.onRenderEnd();
        if (onNewComponentTab()) {
            m_component = (Component) getContainedComponents().get(0);
            m_docbaseObj = (DocbaseObject) m_component.getControl("docbaseObj");
        } else {
            m_component = (Component) getContainedComponents().get(1);
            m_docbaseObj = (DocbaseObject) m_component.getControl("obj");
        }
        // Get the right kind of custom validation object
        CustomValidationFactory customValidationFactory = new CustomValidationFactory(this, m_docbaseObj);
        customValidationObject = customValidationFactory.getCustomValidationObject();

        // Set the flag that determines whether or not we have to do custom validation
        if (customValidationObject != null) {
            doCustomValidation = customValidationObject.getDoCustomValidation();
        }
    }

    public void onOk(Control button, ArgumentList args) {
        //In the super class, onOk runs the data dictionary validation from DFC.
        // To make the custom validation work, one of the requirements is to add
        // an object constraint that always evaluates to false.  When the
        // docbaseattributelist tag is rendered, it adds the
        // DocbaseObjectValidator that I selectively validate (in the
        // ICustomValidation implementations) depending on the results of the
        // custom validation logic.  This gives me a validator that I can set
        // the error message on and only turn it on when I want.  The DFC
        // validation always validates all validators, so I had to get the
        // new object type, check to see if it's one of the types we're doing
        // custom validation on.  If not, just run the super onOk.  If it is,
        // run code copied from the super onOk, with the call to the DFC
        // validation left out.

        if (!doCustomValidation) {
            super.onOk(button, args);
        } else {
            validate();
            if (isValid && canCommitChanges() && onCommitChanges() && validateNameChange()) {
                SessionManagerHttpBinding.removeHttpSessionUnboundListener(this);
                ArrayList components = getContainedComponents();
                NewDocument component = (NewDocument) components.get(0);
                String strNewObjectId = component.getNewObjectId();
                boolean bNewObjectHasContent = component.isFormatAndTemplateSupplied();
                setReturnValue("newObjectId", strNewObjectId);
                if (strNewObjectId != null) {
                    if (bNewObjectHasContent) {
                        String strType = component.getNewType();
                        Context context = getContext();
                        ArgumentList componentArgs = new ArgumentList();
                        componentArgs.add("objectId", strNewObjectId);
                        context.set("type", strType);
                        context.set("objectId", strNewObjectId);
                        ActionService.execute("editafternew", componentArgs, context, this, null);
                    } else  //Call to DFC validation removed below
                    {
                        setComponentReturn();
                    }
                } else {
                    if (strNewObjectId != null && bNewObjectHasContent && strNewObjectId.startsWith("09"))
                        try {
                            IDfSysObject newObj = (IDfSysObject) getDfSession().getObject(new DfId(strNewObjectId));
                            newObj.unmark("_NEW_");
                            newObj.save();
                        }
                        catch (Exception unmarkexpt) {
                        }
                    setComponentReturn();
                }
            }
        }
    }
}
