package com.monsanto.dctm.viewprocessor;

public class BookmarkLink extends com.documentum.web.form.control.BookmarkLink 
{
	public String getHREF() {
		String strHREF = super.getHREF();
		strHREF = "http://viewdocumentum.monsanto.com:8080" + strHREF;
		return strHREF;
	}
}
