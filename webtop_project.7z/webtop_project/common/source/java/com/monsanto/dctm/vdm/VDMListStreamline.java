package com.monsanto.dctm.vdm;

import com.documentum.web.common.ArgumentList;
import com.documentum.web.form.Control;
import com.monsanto.dctm.monAppContext.MonAppContextService;

public class VDMListStreamline extends
                               com.documentum.webtop.webcomponent.vdm.VDMListStreamline {

    protected String getColumnsPreferenceId() {
        return super.getColumnsPreferenceId() + "." +
               MonAppContextService.getMonAppContextService().getMonAppContextInternalName();
    }

    public void onClickRootVdm(Control control, ArgumentList args) {
        ArgumentList list = new ArgumentList();
        list.add("objectId", args.get("objectId"));
        super.onClickRootVdm(control, list);
    }

}
