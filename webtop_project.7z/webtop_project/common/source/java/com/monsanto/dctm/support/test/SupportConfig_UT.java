/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.support.test;

import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.IDfSysObject;
import com.documentum.fc.client.MockSession;
import com.documentum.fc.common.DfLoginInfo;
import com.documentum.web.form.ComponentTestUtils;
import com.monsanto.dctm.component.test.MockComponent;
import com.monsanto.dctm.component.test.MockSessionManager;
import com.monsanto.dctm.component.test.MockSysObject;
import com.monsanto.dctm.support.SupportConfig;
import junit.framework.TestCase;

/**
 * Filename:    $RCSfile: SupportConfig_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: lakench $ On:	$Date:
 * 2007/08/24 21:23:23 $
 *
 * @author LAKENCH
 * @version $Revision: 1.6 $
 */
public class SupportConfig_UT extends TestCase {
  protected void setUp() throws Exception {
    super.setUp();
  }

  protected void tearDown() throws Exception {
    super.tearDown();
  }

  public void testSupportConfigSysObjectSetCorrectlyWithComponentConstructor() throws Exception {
    MockSessionManager mockSessionManager = new MockSessionManager();
    DfLoginInfo dfLoginInfo = new DfLoginInfo();
    dfLoginInfo.setUser("testuserid");
    mockSessionManager.setIdentity("testdocbase", dfLoginInfo);
    MockSession session = (MockSession) mockSessionManager.getSession("testdocbase");
    DfLoginInfo dfLoginInfoForSupportConfig = new DfLoginInfo();
    dfLoginInfo.setUser("devl01");
    mockSessionManager.setIdentity("stltst03", dfLoginInfoForSupportConfig);
    MockSession sessionForSupportConfig = (MockSession) mockSessionManager.getSession("stltst03");
    MockSysObject expectedSupportConfigSysObject = new MockSysObject();
    sessionForSupportConfig.addObject(expectedSupportConfigSysObject, "mon_support_info");

    MockComponent component = (MockComponent) ComponentTestUtils
        .getComponent(MockComponent.class, "testcomponent", "testdocbase", mockSessionManager);
    SupportConfig supportConfig = new SupportConfig(component);

    IDfSysObject actualSupportConfigSysObject = supportConfig.getSupportConfigSysObject();

    IDfSession supportConfigSession = actualSupportConfigSysObject.getSession();
    assertNotSame(session, supportConfigSession);
    assertEquals(sessionForSupportConfig, supportConfigSession);

    assertEquals("support config sysobject not set properly", expectedSupportConfigSysObject,
        actualSupportConfigSysObject);

    ComponentTestUtils.releaseComponent(component);
  }

  public void testGetOutageNoticeWithComponentConstructor() throws Exception {
    MockSessionManager mockSessionManager = new MockSessionManager();
    DfLoginInfo dfLoginInfo = new DfLoginInfo();
    dfLoginInfo.setUser("testuserid");
    mockSessionManager.setIdentity("testdocbase", dfLoginInfo);
    MockSession session = (MockSession) mockSessionManager.getSession("testdocbase");
    DfLoginInfo dfLoginInfoForSupportConfig = new DfLoginInfo();
    dfLoginInfo.setUser("devl01");
    mockSessionManager.setIdentity("stltst03", dfLoginInfoForSupportConfig);
    MockSession sessionForSupportConfig = (MockSession) mockSessionManager.getSession("stltst03");
    MockSysObject expectedSupportConfigSysObject = new MockSysObject();
    expectedSupportConfigSysObject.setString("outage_notice", "test outage notice");
    sessionForSupportConfig.addObject(expectedSupportConfigSysObject, "mon_support_info");

    MockComponent component = (MockComponent) ComponentTestUtils
        .getComponent(MockComponent.class, "testcomponent", "testdocbase", mockSessionManager);
    SupportConfig supportConfig = new SupportConfig(component);

    IDfSysObject actualSupportConfigSysObject = supportConfig.getSupportConfigSysObject();

    IDfSession supportConfigSession = actualSupportConfigSysObject.getSession();
    assertNotSame(session, supportConfigSession);
    assertEquals(sessionForSupportConfig, supportConfigSession);

    assertEquals("support config sysobject not set properly", expectedSupportConfigSysObject,
        actualSupportConfigSysObject);

    String outageNotice = supportConfig.getOutageNotice();

    assertEquals("support config sysobject not set properly", "test outage notice", outageNotice);

    ComponentTestUtils.releaseComponent(component);
  }

  public void testGetUserMessageWithComponentConstructor() throws Exception {
    MockSessionManager mockSessionManager = new MockSessionManager();
    DfLoginInfo dfLoginInfo = new DfLoginInfo();
    dfLoginInfo.setUser("testuserid");
    mockSessionManager.setIdentity("testdocbase", dfLoginInfo);
    MockSession session = (MockSession) mockSessionManager.getSession("testdocbase");
    DfLoginInfo dfLoginInfoForSupportConfig = new DfLoginInfo();
    dfLoginInfo.setUser("devl01");
    mockSessionManager.setIdentity("stltst03", dfLoginInfoForSupportConfig);
    MockSession sessionForSupportConfig = (MockSession) mockSessionManager.getSession("stltst03");
    MockSysObject expectedSupportConfigSysObject = new MockSysObject();
    expectedSupportConfigSysObject.setString("user_message", "test user message");
    sessionForSupportConfig.addObject(expectedSupportConfigSysObject, "mon_support_info");

    MockComponent component = (MockComponent) ComponentTestUtils
        .getComponent(MockComponent.class, "testcomponent", "testdocbase", mockSessionManager);
    SupportConfig supportConfig = new SupportConfig(component);

    IDfSysObject actualSupportConfigSysObject = supportConfig.getSupportConfigSysObject();

    IDfSession supportConfigSession = actualSupportConfigSysObject.getSession();
    assertNotSame(session, supportConfigSession);
    assertEquals(sessionForSupportConfig, supportConfigSession);

    assertEquals("support config sysobject not set properly", expectedSupportConfigSysObject,
        actualSupportConfigSysObject);

    String userMessage = supportConfig.getUserMessage();

    assertEquals("support config sysobject not set properly", "test user message", userMessage);

    ComponentTestUtils.releaseComponent(component);
  }

  public void testGetOutageNoticeReadMoreUrlWithComponentConstructor() throws Exception {
    MockSessionManager mockSessionManager = new MockSessionManager();
    DfLoginInfo dfLoginInfo = new DfLoginInfo();
    dfLoginInfo.setUser("testuserid");
    mockSessionManager.setIdentity("testdocbase", dfLoginInfo);
    MockSession session = (MockSession) mockSessionManager.getSession("testdocbase");
    DfLoginInfo dfLoginInfoForSupportConfig = new DfLoginInfo();
    dfLoginInfo.setUser("devl01");
    mockSessionManager.setIdentity("stltst03", dfLoginInfoForSupportConfig);
    MockSession sessionForSupportConfig = (MockSession) mockSessionManager.getSession("stltst03");
    MockSysObject expectedSupportConfigSysObject = new MockSysObject();
    expectedSupportConfigSysObject.setString("outage_notice_url", "test outage notice url");
    sessionForSupportConfig.addObject(expectedSupportConfigSysObject, "mon_support_info");

    MockComponent component = (MockComponent) ComponentTestUtils
        .getComponent(MockComponent.class, "testcomponent", "testdocbase", mockSessionManager);
    SupportConfig supportConfig = new SupportConfig(component);

    IDfSysObject actualSupportConfigSysObject = supportConfig.getSupportConfigSysObject();

    IDfSession supportConfigSession = actualSupportConfigSysObject.getSession();
    assertNotSame(session, supportConfigSession);
    assertEquals(sessionForSupportConfig, supportConfigSession);

    assertEquals("support config sysobject not set properly", expectedSupportConfigSysObject,
        actualSupportConfigSysObject);

    String userMessage = supportConfig.getOutageNoticeUrl();

    assertEquals("support config sysobject not set properly", "test outage notice url", userMessage);

    ComponentTestUtils.releaseComponent(component);
  }

  public void testGetUserMessageReadMoreUrlWithComponentConstructor() throws Exception {
    MockSessionManager mockSessionManager = new MockSessionManager();
    DfLoginInfo dfLoginInfo = new DfLoginInfo();
    dfLoginInfo.setUser("testuserid");
    mockSessionManager.setIdentity("testdocbase", dfLoginInfo);
    MockSession session = (MockSession) mockSessionManager.getSession("testdocbase");
    DfLoginInfo dfLoginInfoForSupportConfig = new DfLoginInfo();
    dfLoginInfo.setUser("devl01");
    mockSessionManager.setIdentity("stltst03", dfLoginInfoForSupportConfig);
    MockSession sessionForSupportConfig = (MockSession) mockSessionManager.getSession("stltst03");
    MockSysObject expectedSupportConfigSysObject = new MockSysObject();
    expectedSupportConfigSysObject.setString("user_message_url", "test user message url");
    sessionForSupportConfig.addObject(expectedSupportConfigSysObject, "mon_support_info");

    MockComponent component = (MockComponent) ComponentTestUtils
        .getComponent(MockComponent.class, "testcomponent", "testdocbase", mockSessionManager);
    SupportConfig supportConfig = new SupportConfig(component);

    IDfSysObject actualSupportConfigSysObject = supportConfig.getSupportConfigSysObject();

    IDfSession supportConfigSession = actualSupportConfigSysObject.getSession();
    assertNotSame(session, supportConfigSession);
    assertEquals(sessionForSupportConfig, supportConfigSession);

    assertEquals("support config sysobject not set properly", expectedSupportConfigSysObject,
        actualSupportConfigSysObject);

    String userMessage = supportConfig.getUserMessageUrl();

    assertEquals("support config sysobject not set properly", "test user message url", userMessage);

    ComponentTestUtils.releaseComponent(component);
  }

}