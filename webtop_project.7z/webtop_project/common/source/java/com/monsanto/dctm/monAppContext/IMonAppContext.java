/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.monAppContext;

/**
 * Filename:    $RCSfile: IMonAppContext.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: lakench $    	 On:	$Date: 2007-01-19 14:43:43 $
 *
 * @author lakench
 * @version $Revision: 1.1 $
 */
public interface IMonAppContext {
    public abstract String getInternalName();

    public abstract boolean isUseViewForCommentingEnabled();

    public abstract boolean isDocbaseSupported(String docbase);
}