package com.monsanto.dctm.report;

import com.documentum.fc.common.DfLogger;
import com.documentum.web.formext.config.IConfigElement;

public class Criterion {

  private String name;
  private String label;
  private String tagclass;
  private String labeltagclass;
  private String valuetagclass;
  private String dropdownquery;
  private String dropdownvalues;
  private String editcomponent;
  private boolean isRequired;
  private IConfigElement allconfigelements;

  public Criterion(IConfigElement criterion) {
    if (criterion != null) {
      setName(criterion.getAttributeValue("name"));
      setLabel(criterion.getAttributeValue("label"));
      setTagclass(criterion.getChildValue("tagclass"));
      setLabeltagclass(criterion.getChildValue("labeltagclass"));
      setValuetagclass(criterion.getChildValue("valuetagclass"));
      setDropdownquery(criterion.getChildValue("dropdownquery"));
      setDropdownvalues(criterion.getChildValue("dropdownvalues"));
      setEditcomponent(criterion.getChildValue("editcomponent"));
      Boolean isRequiredFromConfigFile = criterion.getChildValueAsBoolean("required");
      DfLogger.info(this, "isRequiredFromConfigFile = " + isRequiredFromConfigFile, null, null);
      if (isRequiredFromConfigFile == null)
        setRequired(false);
      else
        setRequired(isRequiredFromConfigFile.booleanValue());
      setAllconfigelements(criterion);
    }
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public String getLabel() {
    return label;
  }

  public void setLabel(String description) {
    this.label = description;
  }

  public String getEditcomponent() {
    return editcomponent;
  }

  public void setEditcomponent(String editcomponent) {
    this.editcomponent = editcomponent;
  }

  public String getLabeltagclass() {
    return labeltagclass;
  }

  public void setLabeltagclass(String labeltagclass) {
    this.labeltagclass = labeltagclass;
  }

  public String getTagclass() {
    return tagclass;
  }

  public void setTagclass(String tagclass) {
    this.tagclass = tagclass;
  }

  public String getValuetagclass() {
    return valuetagclass;
  }

  public void setValuetagclass(String valuetagclass) {
    this.valuetagclass = valuetagclass;
  }

  public IConfigElement getAllconfigelements() {
    return allconfigelements;
  }

  public void setAllconfigelements(IConfigElement allconfigelements) {
    this.allconfigelements = allconfigelements;
  }

  public boolean isRequired() {
    return isRequired;
  }

  public void setRequired(boolean isRequired) {
    this.isRequired = isRequired;
  }

  public String getDropdownquery() {
    return dropdownquery;
  }

  public void setDropdownquery(String dropdownquery) {
    this.dropdownquery = dropdownquery;
  }

  public String getDropdownvalues() {
    return dropdownvalues;
  }

  public void setDropdownvalues(String dropdownvalues) {
    this.dropdownvalues = dropdownvalues;
  }
}
