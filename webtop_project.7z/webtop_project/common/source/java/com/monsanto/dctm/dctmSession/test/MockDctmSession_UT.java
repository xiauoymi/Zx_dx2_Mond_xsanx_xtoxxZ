/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.dctmSession.test;

import com.monsanto.dctm.dctmSession.Session;
import com.monsanto.dctm.dctmSession.SessionInstance;
import junit.framework.TestCase;

/**
 * Filename:    $RCSfile: MockDctmSession_UT.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: lakench $    	 On:	$Date: 2007-03-30 20:58:38 $
 *
 * @author lakench
 * @version $Revision: 1.1 $
 */
public class MockDctmSession_UT extends TestCase {
    public void testCreate() throws Exception {
        Session session = new MockDctmSession();
        assertNotNull(session);
    }

    public void testGetNewSessionReturnsNotNull() throws Exception {
        Session session = new MockDctmSession();
        SessionInstance si = session.getNewSession();
        assertNotNull(si);
    }

    public void testGetNewSessionReturnsSessionInstance() throws Exception {
        Session session = new MockDctmSession();
        SessionInstance si = session.getNewSession();
        assertTrue(si instanceof SessionInstance);
    }


}