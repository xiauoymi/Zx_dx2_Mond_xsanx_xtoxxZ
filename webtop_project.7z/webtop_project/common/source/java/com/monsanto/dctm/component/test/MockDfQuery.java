/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.component.test;

import com.documentum.fc.client.IDfCollection;
import com.documentum.fc.client.IDfQuery;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.common.DfException;

import java.util.ArrayList;
import java.util.List;

/**
 * Filename:    $RCSfile: MockDfQuery.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: lakench $    	 On:	$Date: 2007-04-25 16:51:05 $
 *
 * @author lakench
 * @version $Revision: 1.1 $
 */
public class MockDfQuery implements IDfQuery {
    private String dql;
    public boolean executeCalled;
    private List results = new ArrayList();

    private boolean shouldCollectionContainResults = false;
    public MockDfCollection collection;

    public List getResults() {
        return results;
    }

    public void setResults(List results) {
        this.results = results;
    }

    public MockDfQuery(boolean shouldCollectionContainResults, List results) {
        this.shouldCollectionContainResults = shouldCollectionContainResults;
        this.results = results;
    }

    public IDfCollection execute(IDfSession session, int i) throws DfException {
        this.executeCalled = true;
        collection = new MockDfCollection(shouldCollectionContainResults, results);
        return collection;
    }

    public void setDQL(String dql) {
        this.dql = dql;
    }

    public String getDQL() {
        return dql;
    }

    public void setBatchSize(int i) {
    }

    public int getBatchSize() {
        return 0;
    }

    public String getCurrencyCheckValue() {
        return null;
    }

    public void setCurrencyCheckValue(String string) {
    }
}