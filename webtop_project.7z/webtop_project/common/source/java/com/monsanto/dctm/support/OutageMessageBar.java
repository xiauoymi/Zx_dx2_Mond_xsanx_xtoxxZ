/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.support;

import com.documentum.fc.common.DfException;
import com.documentum.web.common.ArgumentList;
import com.documentum.web.common.WrapperRuntimeException;
import com.documentum.web.form.control.Label;
import com.documentum.web.formext.component.Component;

/**
 * Filename:    $RCSfile: OutageMessageBar.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: lakench $
 * On:	$Date: 2007-08-24 21:23:23 $
 *
 * @author lakench
 * @version $Revision: 1.2 $
 */
public class OutageMessageBar extends Component {
  public static final String SUPPORT_OUTAGE_LABEL = "outage";
  public static final String SUPPORT_MESSAGE_LABEL = "message";

  public void onInit(ArgumentList argumentList) {
    super.onInit(argumentList);
    try {
      initSupportMessages();
    } catch (DfException e) {
      throw new WrapperRuntimeException(e);
    }
  }

  protected void initSupportMessages() throws DfException {
    SupportConfig supportConfig = new SupportConfig(this);
    String outageNotice = supportConfig.getOutageNotice();
    String userMessage = supportConfig.getUserMessage();

    if ((outageNotice == null || outageNotice.trim().equals("")) &&
        (userMessage == null || userMessage.trim().equals(""))) {
      setClientEvent("hideOutageMessageBar", null);
    } else {
      String outageNoticeUrl = supportConfig.getOutageNoticeUrl();
      String userMessageUrl = supportConfig.getUserMessageUrl();
      if (outageNoticeUrl != null && outageNoticeUrl.trim().length() > 0) {
        outageNotice += " <a href='" + outageNoticeUrl + "' target='_blank'>&lt;Read more&gt;</a>";
      }
      if (userMessageUrl != null && userMessageUrl.trim().length() > 0) {
        userMessage += " <a href='" + userMessageUrl + "' target='_blank'>&lt;Read more&gt;</a>";
      }
      setClientEvent("showOutageMessageBar", null);
      Label outageNoticeLabel = (Label) getControl(SUPPORT_OUTAGE_LABEL, Label.class);
      outageNoticeLabel.setLabel(outageNotice);
      outageNoticeLabel.setCssStyle("color:red;font-weight:bold");
      Label userMessageLabel = (Label) getControl(SUPPORT_MESSAGE_LABEL, Label.class);
      userMessageLabel.setLabel(userMessage);
      userMessageLabel.setCssStyle("color:red;font-weight:bold");
    }
  }
}