/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.component.test;

import com.documentum.nls.NlsResourceBundle;
import com.documentum.web.common.LocaleService;
import com.documentum.web.form.control.Breadcrumb;

/**
 * Filename:    $RCSfile: MockBreadcrumb.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: lakench $    	 On:	$Date: 2007-10-26 18:47:58 $
 *
 * @author lakench
 * @version $Revision: 1.1 $
 */
public class MockBreadcrumb extends Breadcrumb {
  private String value;

  public void setValue(String strValue) {
    value = strValue;
    super.setValue(strValue);
  }

  public String getValue() {
    NlsResourceBundle resourceBundle = new NlsResourceBundle("com.monsanto.dctm.component.test.MockBreadcrumbNlsProp");
    String strHomeStr = resourceBundle.getString("MSG_HOME", LocaleService.getLocale());

    String strValue = value;
    if (this.hasComponentHome() && strValue.startsWith(this.getSeparator() + strHomeStr) == false) {
      strValue = this.getSeparator() + strHomeStr +
          this.getSeparator() + strValue;
    }

    return strValue;
  }
}