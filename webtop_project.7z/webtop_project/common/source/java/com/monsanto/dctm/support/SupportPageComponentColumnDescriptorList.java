/*
 Copyright:  Copyright � 2006 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.support;

import com.documentum.web.form.Control;
import com.documentum.web.form.Form;
import com.documentum.web.form.IControlListener;
import com.documentum.web.form.control.databound.CellList;
import com.documentum.web.form.control.databound.ColumnDescriptor;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * Filename:    $RCSfile: SupportPageComponentColumnDescriptorList.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: lakench $    	 On:	$Date: 2007-03-16 21:22:25 $
 *
 * @author LAKENCH
 * @version $Revision: 1.7 $
 */
public class SupportPageComponentColumnDescriptorList implements IControlListener {

    private List m_columns;
    private String[] m_fields;
    private String[] m_labels;
    private String[] m_aliases;
    private String m_datagridName;

    public SupportPageComponentColumnDescriptorList(String datagridName, List columns) {
        m_columns = new ArrayList(10);
        m_fields = null;
        m_labels = null;
        m_aliases = null;
//        m_datagridName = datagridName;
        setDatagridName(datagridName);
        setColumnDescriptors(columns);
//        datagrid.getForm().addControlListener(this);
    }

    private void setDatagridName(String datagridName) {
        if (datagridName == null) {
            throw new IllegalArgumentException("Datagrid control name cannot be null!");
        } else {
            m_datagridName = datagridName;
        }
    }

    public Iterator iterator() {
        return m_columns.iterator();
    }

    public ColumnDescriptor get(String strAttribute) {
        ColumnDescriptor colResult = null;
        Iterator iterCols = iterator();
        do {
            if (!iterCols.hasNext())
                break;
            ColumnDescriptor col = (ColumnDescriptor) iterCols.next();
            if (!col.getAttribute().equals(strAttribute))
                continue;
            colResult = col;
            break;
        } while (true);
        return colResult;
    }

    public void setColumnDescriptors(List columns) {
        if (columns == null) {
            throw new IllegalArgumentException("ColumnDescriptor list cannot be null!");
        } else {
            m_columns = columns;
            updateFieldLabelLists();
        }
    }

    public void onControlInitialized(Form form, Control control) {
        if (control instanceof CellList) {
            CellList celllist = (CellList) control;
            if ((control.getContainer().getName() != null && control.getContainer().getName().equals(m_datagridName)) ||
                (control.getContainer().getContainer().getName() != null &&
                 control.getContainer().getContainer().getName().equals(m_datagridName))) {
                celllist.setAliases(m_aliases);
                celllist.setFields(m_fields);
                celllist.setLabels(m_labels);
            }
        }
    }

    private void updateFieldLabelLists() {
        int iSize = m_columns.size();
        List fieldsList = new ArrayList(iSize);
        List labelsList = new ArrayList(iSize);
        List aliasList = new ArrayList(iSize);
        for (int iColumnCount = 0; iColumnCount < iSize; iColumnCount++) {
            ColumnDescriptor descriptor = (ColumnDescriptor) m_columns.get(iColumnCount);
            if (descriptor.isVisible()) {
                fieldsList.add(descriptor.getAttribute());
                labelsList.add(descriptor.getLabel());
                String strAlias = descriptor.getAlias();
                aliasList.add(strAlias);
            }
        }

        m_fields = new String[fieldsList.size()];
        fieldsList.toArray(m_fields);
        m_labels = new String[labelsList.size()];
        labelsList.toArray(m_labels);
        m_aliases = new String[aliasList.size()];
        aliasList.toArray(m_aliases);
    }
}