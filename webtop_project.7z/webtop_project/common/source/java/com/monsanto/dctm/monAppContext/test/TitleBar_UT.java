/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.monAppContext.test;

import com.documentum.fc.client.MockSession;
import com.documentum.fc.common.DfLoginInfo;
import com.documentum.web.form.ComponentTestUtils;
import com.documentum.web.form.control.databound.DataDropDownList;
import com.documentum.web.formext.config.PreferenceService;
import com.monsanto.dctm.component.test.MockSessionManager;
import com.monsanto.dctm.monAppContext.MonAppContextService;
import junit.framework.Assert;
import junit.framework.TestCase;

/**
 * Filename:    $RCSfile: TitleBar_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: lakench $ On:	$Date:
 * 2007/08/23 15:03:38 $
 *
 * @author lakench
 * @version $Revision: 1.4 $
 */
public class TitleBar_UT extends TestCase {
  private MockTitleBar titleBarComponent;
  private MockSessionManager mockSessionManager;

  protected void setUp() throws Exception {
    super.setUp();
    mockSessionManager = new MockSessionManager();
    MockSession session = new MockSession(mockSessionManager);
    ((MockSessionManager) mockSessionManager).setSession(session);
    DfLoginInfo dfLoginInfoForSupportConfig = new DfLoginInfo();
    dfLoginInfoForSupportConfig.setUser("devl01");
    mockSessionManager.setIdentity("stltst03", dfLoginInfoForSupportConfig);
    titleBarComponent = (MockTitleBar) ComponentTestUtils
        .getComponent(MockTitleBar.class, "titlebar", "testdocbase", mockSessionManager);
  }

  protected void tearDown() throws Exception {
    ComponentTestUtils.releaseComponent(titleBarComponent);
    super.tearDown();
  }

  public void testInitMonAppContextControl() throws Exception {
    titleBarComponent.initMonAppContextControl();
    String currentlySelectedMonAppContext = titleBarComponent.getCurrentlySelectedMonAppContext();
    assertEquals("with no preference set, currently selected mon app context should be null", null,
        currentlySelectedMonAppContext);
    DataDropDownList monAppContextControl = titleBarComponent.getMonAppContextControl();
    MonAppContextTestUtils.verifyMonAppContextDropdown(monAppContextControl);

  }

  public void testInitMonAppContextDropdownWithPreferenceSet() throws Exception {
    PreferenceService.getPreferenceStore().writeString("application.mon_app_context.testdocbase",
        "Test Context with View for commenting disabled");
    titleBarComponent.initMonAppContextControl();
    String currentlySelectedMonAppContext = titleBarComponent.getCurrentlySelectedMonAppContext();
    assertEquals("mon app context should match the preference", "Test Context with View for commenting disabled",
        currentlySelectedMonAppContext);

  }

  public void testOnSelectMonAppContext() throws Exception {
    titleBarComponent.initMonAppContextControl();
    DataDropDownList monAppContextControl = titleBarComponent.getMonAppContextControl();
    monAppContextControl.setValue("test mon app context");
    titleBarComponent.onSelectMonAppContext(monAppContextControl, null);
    Assert.assertEquals("mon app context not set",
        MonAppContextService.getMonAppContextService().getCurrentMonAppContextName(), "test mon app context");
    assertEquals("refresh view event not called", "refreshViewWindow", titleBarComponent.getLastClientEvent());
  }
}