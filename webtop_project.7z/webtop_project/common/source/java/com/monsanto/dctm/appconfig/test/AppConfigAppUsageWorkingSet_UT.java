/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.appconfig.test;

import com.documentum.fc.client.IDfPersistentObject;
import com.documentum.fc.client.IDfQuery;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.MockSession;
import com.documentum.fc.common.DfException;
import com.documentum.web.form.control.databound.ColumnDescriptor;
import com.documentum.web.form.control.databound.ScrollableResultSet;
import com.monsanto.dctm.appconfig.AppConfigAppUsageWorkingSet;
import com.monsanto.dctm.appconfig.AppConfigItem;
import com.monsanto.dctm.appconfig.AppConfigItemWorkingSet;
import com.monsanto.dctm.component.test.MockDfQuery;
import com.monsanto.dctm.component.test.MockPersistentObject;
import com.monsanto.dctm.component.test.MockSysObject;
import junit.framework.TestCase;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Filename:    $RCSfile: AppConfigAppUsageWorkingSet_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: lakench $    	 On:	$Date: 2007-08-24 21:29:43 $
 *
 * @author LAKENCH
 * @version $Revision: 1.2 $
 */
public class AppConfigAppUsageWorkingSet_UT extends TestCase {
  public void testCreate() throws Exception {
    MockSession session = new MockSession();
    MockSysObject mockSysObject = new MockSysObject();
    mockSysObject.setRepeatingString("_count", 0, "0");
    session.addObject(mockSysObject, "query_cmd,s0,T,F,,,,,select distinct usage_type from mon_app_usage");
    AppConfigItemWorkingSet appConfigAppUsageWorkingSet = AppConfigItemWorkingSet
        .createAppConfigItemWorkingSet("testcontext", session, "mon_app_usage");
    assertNotNull(appConfigAppUsageWorkingSet);
    assertTrue(appConfigAppUsageWorkingSet instanceof AppConfigAppUsageWorkingSet);
  }

  public void testGetColumnNames() throws Exception {

    MockAppConfigAppUsageWorkingSet appUsageWorkingSet = new MockAppConfigAppUsageWorkingSet("testappcontext",
        new MockSession());
    List columnNames = appUsageWorkingSet.getColumnNames();
    ColumnDescriptor columnDescriptor1 = (ColumnDescriptor) columnNames.get(0);
    ColumnDescriptor columnDescriptor2 = (ColumnDescriptor) columnNames.get(1);
    ColumnDescriptor columnDescriptor3 = (ColumnDescriptor) columnNames.get(2);
    assertEquals("rowid", columnDescriptor1.getAttribute());
    assertEquals("Row ID", columnDescriptor1.getLabel());
    assertFalse(columnDescriptor1.isVisible());
    assertEquals("usage_type", columnDescriptor2.getAttribute());
    assertEquals("Feature", columnDescriptor2.getLabel());
    assertTrue(columnDescriptor2.isVisible());
    assertEquals("usage_enabled", columnDescriptor3.getAttribute());
    assertEquals("Enabled", columnDescriptor3.getLabel());
  }

  public void testGetObjectNameSuffix() throws Exception {
    MockAppConfigAppUsageWorkingSet appUsageWorkingSet = new MockAppConfigAppUsageWorkingSet("testappcontext",
        new MockSession());
    assertEquals("_app_usage", appUsageWorkingSet.getObjectNameSuffix());
  }

  public void testGetDeleteActionName() throws Exception {
    MockAppConfigAppUsageWorkingSet appUsageWorkingSet = new MockAppConfigAppUsageWorkingSet("testappcontext",
        new MockSession());
    assertEquals("removeappusage", appUsageWorkingSet.getDeleteActionName());
  }

  public void testInitialized() throws Exception {
    MockAppConfigAppUsageWorkingSet appUsageWorkingSet = new MockAppConfigAppUsageWorkingSet("testappcontext",
        new MockSession());

    List usagesList = generateActualResultsFromResultSet(appUsageWorkingSet.getResultSet());

    List initialExpectedRows = generateInitialExpectedRows();
    assertEquals(initialExpectedRows, usagesList);
    assertEquals(3, usagesList.size());

    IDfPersistentObject appUsageObject = appUsageWorkingSet.getAppOwnerObject();
    assertNotNull(appUsageObject);
    assertEquals("testappcontext", appUsageObject.getString("mon_app_context"));
    assertEquals("testappcontext" + appUsageWorkingSet.getObjectNameSuffix(), appUsageObject.getString("object_name"));
    MockDfQuery mockQuery = (MockDfQuery) appUsageWorkingSet.dfQuery;
    assertTrue(mockQuery.executeCalled);
    assertEquals("select distinct usage_type from mon_app_usage", mockQuery.getDQL());
  }

  public void testInitializedFromExistingAppUsageObject() throws Exception {
    MockSession session = new MockSession();
    MockPersistentObject testAppOwnerInfoObject = new MockPersistentObject();
    setupTestAppUsageObjectAndAddToSession(testAppOwnerInfoObject, session);
    MockAppConfigAppUsageWorkingSet appUsageWorkingSet = new MockAppConfigAppUsageWorkingSet("testappcontext", session);

    List usagesList = generateActualResultsFromResultSet(appUsageWorkingSet.getResultSet());

    assertEquals(4, usagesList.size());
    List expectedRequestorsRow = generateExpectedUsageRow("0", "testtype0", "Yes");
    assertTrue(usagesList.contains(expectedRequestorsRow));
    expectedRequestorsRow = generateExpectedUsageRow("1", "testtype1", "No");
    assertTrue(usagesList.contains(expectedRequestorsRow));
    expectedRequestorsRow = generateExpectedUsageRow("2", "testtype3", "Yes");
    assertTrue(usagesList.contains(expectedRequestorsRow));
    expectedRequestorsRow = generateExpectedUsageRow("3", "testtype2", "Unknown");
    assertTrue(usagesList.contains(expectedRequestorsRow));

    IDfPersistentObject appOwnerObject = appUsageWorkingSet.getAppOwnerObject();
    assertSame(testAppOwnerInfoObject, appOwnerObject);
  }

  public void testRemoveUsage() throws Exception {
    MockSession session = new MockSession();
    MockPersistentObject testAppOwnerInfoObject = new MockPersistentObject();
    setupTestAppUsageObjectAndAddToSession(testAppOwnerInfoObject, session);
    MockAppConfigAppUsageWorkingSet appUsageWorkingSet = new MockAppConfigAppUsageWorkingSet("testappcontext", session);

    AppConfigItem usageToRemove = generateUsageAppConfigItem("1", "testtype1", "doesntmatter");
    appUsageWorkingSet.removeAppConfigItem(usageToRemove);

    List usagesList = generateActualResultsFromResultSet(appUsageWorkingSet.getResultSet());

    assertEquals(4, usagesList.size());
    List expectedRequestorsRow = generateExpectedUsageRow("0", "testtype0", "Yes");
    assertTrue(usagesList.contains(expectedRequestorsRow));
    expectedRequestorsRow = generateExpectedUsageRow("4", "testtype1", "Unknown");
    assertTrue(usagesList.contains(expectedRequestorsRow));
    expectedRequestorsRow = generateExpectedUsageRow("2", "testtype3", "Yes");
    assertTrue(usagesList.contains(expectedRequestorsRow));
    expectedRequestorsRow = generateExpectedUsageRow("3", "testtype2", "Unknown");
    assertTrue(usagesList.contains(expectedRequestorsRow));

    IDfPersistentObject appOwnerObject = appUsageWorkingSet.getAppOwnerObject();
    assertSame(testAppOwnerInfoObject, appOwnerObject);
  }

  public void testRemoveAllUsages() throws Exception {
    MockSession session = new MockSession();
    MockPersistentObject testAppOwnerInfoObject = new MockPersistentObject();
    setupTestAppUsageObjectAndAddToSession(testAppOwnerInfoObject, session);
    MockAppConfigAppUsageWorkingSet appUsageWorkingSet = new MockAppConfigAppUsageWorkingSet("testappcontext", session);

    AppConfigItem usageToRemove = generateUsageAppConfigItem("0", "testtype0", "doesntmatter");
    appUsageWorkingSet.removeAppConfigItem(usageToRemove);
    usageToRemove = generateUsageAppConfigItem("1", "testtype1", "doesntmatter");
    appUsageWorkingSet.removeAppConfigItem(usageToRemove);
    usageToRemove = generateUsageAppConfigItem("2", "testtype3", "doesntmatter");
    appUsageWorkingSet.removeAppConfigItem(usageToRemove);
    usageToRemove = generateUsageAppConfigItem("3", "testtype2", "doesntmatter");
    appUsageWorkingSet.removeAppConfigItem(usageToRemove);

    List usagesList = generateActualResultsFromResultSet(appUsageWorkingSet.getResultSet());

    assertEquals(4, usagesList.size());
    List expectedRequestorsRow = generateExpectedUsageRow("4", "testtype0", "Unknown");
    assertTrue(usagesList.contains(expectedRequestorsRow));
    expectedRequestorsRow = generateExpectedUsageRow("5", "testtype1", "Unknown");
    assertTrue(usagesList.contains(expectedRequestorsRow));
    expectedRequestorsRow = generateExpectedUsageRow("6", "testtype3", "Unknown");
    assertTrue(usagesList.contains(expectedRequestorsRow));
    expectedRequestorsRow = generateExpectedUsageRow("7", "testtype2", "Unknown");
    assertTrue(usagesList.contains(expectedRequestorsRow));

    IDfPersistentObject appOwnerObject = appUsageWorkingSet.getAppOwnerObject();
    assertSame(testAppOwnerInfoObject, appOwnerObject);
  }

  public void testRemoveNonExistentUsage() throws Exception {
    MockSession session = new MockSession();
    MockPersistentObject testAppOwnerInfoObject = new MockPersistentObject();
    setupTestAppUsageObjectAndAddToSession(testAppOwnerInfoObject, session);
    MockAppConfigAppUsageWorkingSet appUsageWorkingSet = new MockAppConfigAppUsageWorkingSet("testappcontext", session);

    AppConfigItem usageToRemove = generateUsageAppConfigItem("4", "testtype1", "doesntmatter");
    appUsageWorkingSet.removeAppConfigItem(usageToRemove);

    List usagesList = generateActualResultsFromResultSet(appUsageWorkingSet.getResultSet());

    assertEquals(4, usagesList.size());
    List expectedRequestorsRow = generateExpectedUsageRow("0", "testtype0", "Yes");
    assertTrue(usagesList.contains(expectedRequestorsRow));
    expectedRequestorsRow = generateExpectedUsageRow("1", "testtype1", "No");
    assertTrue(usagesList.contains(expectedRequestorsRow));
    expectedRequestorsRow = generateExpectedUsageRow("2", "testtype3", "Yes");
    assertTrue(usagesList.contains(expectedRequestorsRow));
    expectedRequestorsRow = generateExpectedUsageRow("3", "testtype2", "Unknown");
    assertTrue(usagesList.contains(expectedRequestorsRow));

    IDfPersistentObject appOwnerObject = appUsageWorkingSet.getAppOwnerObject();
    assertSame(testAppOwnerInfoObject, appOwnerObject);
  }

  public void testAddUsage() throws Exception {
    MockSession session = new MockSession();
    MockPersistentObject testAppOwnerInfoObject = new MockPersistentObject();
    setupTestAppUsageObjectAndAddToSession(testAppOwnerInfoObject, session);
    MockAppConfigAppUsageWorkingSet appUsageWorkingSet = new MockAppConfigAppUsageWorkingSet("testappcontext", session);

    AppConfigItem usageToAdd = generateUsageAppConfigItem("doesntmatter", "testtype4", "No");
    appUsageWorkingSet.addAppConfigItem(usageToAdd);

    List usagesList = generateActualResultsFromResultSet(appUsageWorkingSet.getResultSet());

    assertEquals(5, usagesList.size());
    List expectedRequestorsRow = generateExpectedUsageRow("0", "testtype0", "Yes");
    assertTrue(usagesList.contains(expectedRequestorsRow));
    expectedRequestorsRow = generateExpectedUsageRow("1", "testtype1", "No");
    assertTrue(usagesList.contains(expectedRequestorsRow));
    expectedRequestorsRow = generateExpectedUsageRow("2", "testtype3", "Yes");
    assertTrue(usagesList.contains(expectedRequestorsRow));
    expectedRequestorsRow = generateExpectedUsageRow("3", "testtype2", "Unknown");
    assertTrue(usagesList.contains(expectedRequestorsRow));
    expectedRequestorsRow = generateExpectedUsageRow("4", "testtype4", "No");
    assertTrue(usagesList.contains(expectedRequestorsRow));
  }

  public void testAddExistingUsageActuallyUpdatesExistingUsage() throws Exception {
    MockSession session = new MockSession();
    MockPersistentObject testAppOwnerInfoObject = new MockPersistentObject();
    setupTestAppUsageObjectAndAddToSession(testAppOwnerInfoObject, session);
    MockAppConfigAppUsageWorkingSet appUsageWorkingSet = new MockAppConfigAppUsageWorkingSet("testappcontext", session);

    AppConfigItem usageToAdd = generateUsageAppConfigItem("doesntmatter", "testtype3", "No");
    appUsageWorkingSet.addAppConfigItem(usageToAdd);

    List usagesList = generateActualResultsFromResultSet(appUsageWorkingSet.getResultSet());

    assertEquals(4, usagesList.size());
    List expectedRequestorsRow = generateExpectedUsageRow("0", "testtype0", "Yes");
    assertTrue(usagesList.contains(expectedRequestorsRow));
    expectedRequestorsRow = generateExpectedUsageRow("1", "testtype1", "No");
    assertTrue(usagesList.contains(expectedRequestorsRow));
    expectedRequestorsRow = generateExpectedUsageRow("4", "testtype3", "No");
    assertTrue(usagesList.contains(expectedRequestorsRow));
    expectedRequestorsRow = generateExpectedUsageRow("3", "testtype2", "Unknown");
    assertTrue(usagesList.contains(expectedRequestorsRow));
  }

  private List generateExpectedUsageRow(String rowid, String usageType, String usageEnabled) {
    List expectedRequestorsRow = new ArrayList(3);
    expectedRequestorsRow.add(rowid);
    expectedRequestorsRow.add(usageType);
    expectedRequestorsRow.add(usageEnabled);
    return expectedRequestorsRow;
  }

  private AppConfigItem generateUsageAppConfigItem(String rowid, String usageType, String usageEnabled) {
    Map valuesForUsageToRemove = new HashMap(3);
    valuesForUsageToRemove.put("rowid", rowid);
    valuesForUsageToRemove.put("usage_type", usageType);
    valuesForUsageToRemove.put("usage_enabled", usageEnabled);
    return new AppConfigItem("mon_app_usage", valuesForUsageToRemove);
  }

  private void setupTestAppUsageObjectAndAddToSession(MockPersistentObject testAppOwnerInfoObject,
                                                      MockSession session) throws DfException {
    testAppOwnerInfoObject.setString("object_name", "testappcontext_app_usage");
    testAppOwnerInfoObject.setString("mon_app_context", "testappcontext");
    ArrayList usageTypes = new ArrayList(3);
    usageTypes.add("testtype0");
    usageTypes.add("testtype1");
    usageTypes.add("testtype3");
    testAppOwnerInfoObject.setRepeatingStrings("usage_type", usageTypes);
    ArrayList enabledUsages = new ArrayList(3);
    enabledUsages.add("Yes");
    enabledUsages.add("No");
    enabledUsages.add("Yes");
    testAppOwnerInfoObject.setRepeatingStrings("usage_enabled", enabledUsages);
    session.addObject(testAppOwnerInfoObject);
    session.addObject(testAppOwnerInfoObject, "mon_app_usage where mon_app_context = 'testappcontext'");
  }

  private List generateActualResultsFromResultSet(ScrollableResultSet resultSet) {
    resultSet.setCursor(-1);
    int resultsCount = resultSet.getResultsCount();
    List actualResults = new ArrayList(3);
    for (int i = 0; i < resultsCount; i++) {
      List row = new ArrayList(3);
      resultSet.next();
      row.add(resultSet.getObject(1));
      row.add(resultSet.getObject(2));
      row.add(resultSet.getObject(3));
      actualResults.add(row);
    }
    return actualResults;
  }

  private List generateInitialExpectedRows() {
    List expectedRows = new ArrayList(3);

    List row1 = generateExpectedUsageRow("1", "testtype1", "Unknown");
    expectedRows.add(row1);

    List row2 = generateExpectedUsageRow("2", "testtype2", "Unknown");
    expectedRows.add(row2);

    List row3 = generateExpectedUsageRow("3", "testtype3", "Unknown");
    expectedRows.add(row3);

    return expectedRows;
  }

  public class MockAppConfigAppUsageWorkingSet extends AppConfigAppUsageWorkingSet {
    private IDfSession session;
    public IDfQuery dfQuery;

    public MockAppConfigAppUsageWorkingSet(String monAppContext, IDfSession session) throws
        DfException {
      super(monAppContext, session);
      this.session = session;
    }

    /**
     * @noinspection RefusedBequest
     */
    protected IDfQuery createIDfQuery(String query) {
      dfQuery = new MockDfQuery(true, generateMockUsages());
      dfQuery.setDQL(query);
      return dfQuery;

    }

    private List generateMockUsages() {
      List mockUsages = new ArrayList();
      Map mockRow = new HashMap();
      List usage = new ArrayList();
      usage.add("testtype1");
      mockRow.put("usage_type", usage);
      mockUsages.add(mockRow);
      mockRow = new HashMap();
      usage = new ArrayList();
      usage.add("testtype2");
      mockRow.put("usage_type", usage);
      mockUsages.add(mockRow);
      mockRow = new HashMap();
      usage = new ArrayList();
      usage.add("testtype3");
      mockRow.put("usage_type", usage);
      mockUsages.add(mockRow);
      mockRow = new HashMap();
      usage = new ArrayList();
      usage.add("");
      mockRow.put("usage_type", usage);
      mockUsages.add(mockRow);
      mockRow = new HashMap();
      usage = new ArrayList();
      usage.add(null);
      mockRow.put("usage_type", usage);
      mockUsages.add(mockRow);
      return mockUsages;
    }

    public IDfPersistentObject getAppOwnerObject() throws DfException {
      return session.getObjectByQualification("all");
    }
  }
}