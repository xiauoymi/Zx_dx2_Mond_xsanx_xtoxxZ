/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.support.test;

import com.documentum.web.form.control.Label;
import com.monsanto.dctm.support.AppOwnersTag;
import junit.framework.TestCase;

/**
 * Filename:    $RCSfile: AppOwnersTag_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: lakench $ On:	$Date:
 * 2007/07/31 18:51:49 $
 *
 * @author LAKENCH
 * @version $Revision: 1.2 $
 */
public class AppOwnersTag_UT extends TestCase {
  protected void setUp() throws Exception {
    super.setUp();
  }

  protected void tearDown() throws Exception {
    super.tearDown();
  }

  public void testMailtolinkTagHtmlIsCorrect() throws Exception {
    MockAppOwnersTag appOwnersTag = new MockAppOwnersTag();
    Label label = new Label();
    label.setCssClass("test css class");
    label.setLabel("name 1::email 1##name 2::email 2");
    String expectedOutput = "<table class='test css class'><tr><td class='normal' style='padding: 5px; border-collapse: collapse; border-top: none; border-bottom: none; border-left: none; border-right: 1px solid #000099;'><a href='mailto:email 1'>name 1</a></td><td class='normal' style='padding: 5px; border-collapse: collapse; border: none'><a href='mailto:email 2'>name 2</a></td></tr></table>";

    String actualOutput = appOwnersTag.generateAppOwnersTableHtml(label).toString();

    assertEquals("html not generated properly", expectedOutput, actualOutput);
  }


  public class MockAppOwnersTag extends AppOwnersTag {
    protected StringBuffer generateAppOwnersTableHtml(Label label) {
      return super.generateAppOwnersTableHtml(label);
    }
  }
}
