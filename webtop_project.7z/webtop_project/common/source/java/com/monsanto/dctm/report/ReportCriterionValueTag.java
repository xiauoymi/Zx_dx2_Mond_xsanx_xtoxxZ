package com.monsanto.dctm.report;

import com.documentum.nls.NlsResourceBundle;
import com.documentum.web.form.Control;
import com.documentum.web.form.ControlTag;

import javax.servlet.jsp.JspTagException;
import javax.servlet.jsp.JspWriter;
import java.io.IOException;

public abstract class ReportCriterionValueTag extends ControlTag {

  protected String criteria;
  protected Criterion criterion;
  protected String value;
  protected NlsResourceBundle nlsResourceClass;

  public ReportCriterionValueTag() {
    criteria = null;
    criterion = null;
    value = null;
    nlsResourceClass = new NlsResourceBundle("com.documentum.web.formext.control.docbase.DocbaseAttributeValueNlsProp");
  }

  public void release() {
    criteria = null;
    criterion = null;
    value = null;
    super.release();
  }

  public String getCriteria() {
    return criteria;
  }

  public void setCriteria(String criteria) {
    this.criteria = criteria;
  }

  public void setCriterion(Criterion criterion) {
    this.criterion = criterion;
  }

  public String getValue() {
    return value;
  }

  public void setValue(String value) {
    this.value = value;
  }

  protected Class getControlClass() {
    return ReportCriterionValue.class;
  }

  protected void setControlProperties(Control control) {
    super.setControlProperties(control);

    ReportCriterionValue value = (ReportCriterionValue) control;
    if (criteria != null)
      value.setCriteria(criteria);
    if (criterion != null)
      value.setCriterion(criterion);
    if (value != null)
      value.setValue(getValue());
  }

  protected void renderEnd(JspWriter out) throws IOException, JspTagException {
    ReportCriterionValue value = (ReportCriterionValue) getControl();
    if (value.isVisible()) {
      out.println("<!-- " + getName() + "-->");
      renderValueControl(getName(), value.getValue(), out);
    }
  }

  protected abstract void renderValueControl(String name, String value, JspWriter out)
      throws JspTagException, IOException;

}
