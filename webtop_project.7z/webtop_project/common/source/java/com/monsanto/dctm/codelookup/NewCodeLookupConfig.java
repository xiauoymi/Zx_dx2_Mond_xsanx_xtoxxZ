/*
 * NewCodeLookupConfig.java
 *
 * Created on February 14, 2006, 2:49 PM
 *
 * To change this template, choose Tools | Options and locate the template under
 * the Source Creation and Management node. Right-click the template and choose
 * Open. You can then make changes to the template in the Source Editor.
 */

package com.monsanto.dctm.codelookup;

import com.documentum.com.DfClientX;
import com.documentum.com.IDfClientX;
import com.documentum.fc.client.*;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfUtil;

import java.util.Hashtable;
import java.util.Map;
import java.util.Vector;

/**
 * @author tsvedan
 */
public class NewCodeLookupConfig implements ICodeLookupConfig {

  /**
   * Creates a new instance of NewCodeLookupConfig
   */
  public NewCodeLookupConfig(String context, IDfSession session) {
    this.mon_app_context = context;
    this.session = session;
    this.m_groupsInWhichLoginUserIsAMember = null;
  }

  public Map getTypeAttrInfo(String codeType) {
    IDfCollection coll = null;
    StringBuffer query = new StringBuffer("SELECT object_type, attr_name FROM code_lookup_config ");
    query.append("WHERE object_name='").append(codeType).append("'");
    Hashtable map = new Hashtable();
    try {
      coll = execQuery(query.toString());
      if (coll != null) {
        while (coll.next()) {
          String type = coll.getString("object_type");
          String attr = coll.getString("attr_name");
          if (type != null && type.length() > 0 &&
              attr != null && attr.length() > 0)
            map.put(type, attr);
//                    System.out.println("Object Type = " + type + "   Attr Name = " + attr);
        }
        coll.close();
      }
    } catch (Exception e) {
      e.printStackTrace();
    }
    return map;
  }

  public String [] getTypeName(String codeType) {
    IDfSysObject config = null;
    String [] types = null;
    try {
      config = getConfigObject(codeType);
      types = new String []{config.getString("object_type")};
    } catch (DfException e) {
    }
    return types;
  }

  public String [] getAttrName(String codeType) {
    IDfSysObject config = null;
    String [] attrs = null;
    try {
      config = getConfigObject(codeType);
      attrs = new String []{config.getString("attr_name")};
    } catch (DfException e) {
    }
    return attrs;
  }

  public String getXrefCodeType(String codeType) {
    IDfSysObject config = null;
    String ref = null;
    try {
      config = getConfigObject(codeType);
      ref = config.getString("xref_code");
    } catch (DfException e) {
    }
    return ref;
  }

  public String [] getAdminGroup(String codeType) {
    IDfCollection coll = null;
    StringBuffer query = new StringBuffer("SELECT admingroup FROM code_lookup_config ");
    query.append("WHERE object_name='").append(codeType).append("' AND ");
    query.append("mon_app_context='").append(mon_app_context).append("'");
    String [] admins = new String [1];
    Vector set = new Vector();
    try {
      coll = execQuery(query.toString());
      if (coll != null) {
        while (coll.next()) {
          String admingroup = coll.getString("admingroup");
          if (admingroup != null && admingroup.length() > 0)
            set.add(admingroup);
//                    System.out.println(admingroup);
        }
        coll.close();
      }
    } catch (Exception e) {
      e.printStackTrace();
    }
    admins = (String []) set.toArray(admins);
    return admins;
  }

  public boolean isUserModifiable(String codeType) {
//        boolean bRetValue = false;
//        Vector groups = null;
//        String [] admins = null;
//        IDfSysObject config = null;
//        try {
//            String loginUserName = session.getLoginUserName();
//            IDfUser userObject = session.getUser(loginUserName);
//            if(userObject != null){
//                int userPrivileges = userObject.getUserPrivileges();
//                if(userPrivileges == 16)
//                    return true;
//                config = getConfigObject(codeType);
//                bRetValue = getConfigObject(codeType).getBoolean("is_user_modifiable");
//                System.out.println(codeType + " is_user_modifiable? " + bRetValue);
//                if (bRetValue){
//                    groups = getLoginUsersGroups(loginUserName, session);
//                    admins = getAdminGroup(codeType);
//                    for (int i=0; i<admins.length; i++)
//                        if (groups.contains(admins[i]))
//                            return true;
//                }
//            }
//        } catch(DfException exp) {
//            exp.printStackTrace();
//        }
    return true;
  }

  public String [] getCodeTypes() {
    IDfCollection coll = null;
    StringBuffer query = new StringBuffer("SELECT DISTINCT object_name FROM code_lookup_config ");
    query.append("WHERE mon_app_context='").append(mon_app_context).append("'");
//        System.out.println("Query = " + query);
    String [] codetypes = null;
    String codetype = null;
    Vector v = new Vector();
    try {
      coll = execQuery(query.toString());
      while (coll.next()) {
        codetype = coll.getString("object_name");
        if (canCodeBeModified(codetype))
          v.add(codetype);
//                System.out.println(coll.getString("object_name"));
      }
      coll.close();
    } catch (DfException e) {
    }
    codetypes = (String []) v.toArray(new String[v.size()]);
    return codetypes;
  }

  private IDfSysObject getConfigObject(String codeType) throws DfException {
    IDfSysObject sysObj = null;
    String qual = "code_lookup_config where object_name='" + codeType;
    qual += "' and mon_app_context='" + mon_app_context + "'";
    sysObj = (IDfSysObject) getSession().getObjectByQualification(qual);
    return sysObj;
  }

  private IDfCollection execQuery(String queryString
  ) throws DfException {
    IDfCollection coll = null;
    IDfClientX clientx = new DfClientX();
    IDfQuery q = clientx.getQuery();
    String result = null;
    q.setDQL(queryString);
    coll = q.execute(getSession(), IDfQuery.DF_READ_QUERY);
    return coll;
  } //execQuery

  private Vector getLoginUsersGroups(String loginUserName, IDfSession dfcSession) {
    if (m_groupsInWhichLoginUserIsAMember == null) {
      m_groupsInWhichLoginUserIsAMember = new Vector();
      try {
        IDfQuery query = new DfQuery();
        query.setDQL("select group_name from dm_group where any i_all_users_names = '" +
            DfUtil.escapeQuotedString(loginUserName) + "'");
        IDfCollection collection = query.execute(dfcSession, 0);
        if (collection != null) {
          String groupName;
//                    System.out.println("Member of :");
          for (; collection.next(); m_groupsInWhichLoginUserIsAMember.add(groupName)) {
            groupName = collection.getString("group_name");
//                        System.out.println(groupName);
          }
        }
        collection.close();
      } catch (DfException e) {

      }
    }
    return m_groupsInWhichLoginUserIsAMember;
  }

  public boolean canCodeBeModified(String codeType) {
    Vector groups = null;
    String [] admins = null;
    try {
      String loginUserName = session.getLoginUserName();
      IDfUser userObject = session.getUser(loginUserName);
      if (userObject != null) {
        int userPrivileges = userObject.getUserPrivileges();
        if (userPrivileges == 16)
          return true;
        else if (getConfigObject(codeType).getBoolean("is_user_modifiable")) {
          groups = getLoginUsersGroups(loginUserName, session);
          admins = getAdminGroup(codeType);
          for (int i = 0; i < admins.length; i++) {
//                        System.out.println("Admin group for " + codeType + " = " + admins[i]);
            if (groups.contains(admins[i]))
              return true;
          }
        }
      }
    } catch (DfException exp) {
      exp.printStackTrace();
    }
    return false;
  }

  private IDfSession getSession() {
    return session;
  }


  private String mon_app_context;
  private IDfSession session;
  private Vector m_groupsInWhichLoginUserIsAMember;

}
