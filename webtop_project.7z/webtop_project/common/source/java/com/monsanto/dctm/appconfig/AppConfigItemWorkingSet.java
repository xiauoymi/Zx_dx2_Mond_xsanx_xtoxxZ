/*
 Copyright:  Copyright � 2006 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.appconfig;

import com.documentum.fc.client.IDfPersistentObject;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.common.DfException;
import com.documentum.web.form.control.databound.ScrollableResultSet;
import com.documentum.web.form.control.databound.TableResultSet;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

/**
 * Filename:    $RCSfile: AppConfigItemWorkingSet.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: lakench $
 * On:	$Date: 2007-08-21 05:23:14 $
 *
 * @author lakench
 * @version $Revision: 1.1 $
 */
public abstract class AppConfigItemWorkingSet {

  private List columnDescriptors;
  private IDfPersistentObject appConfigItemObject;
  private TableResultSet appConfigItems;
  private int rowid = 0;
  private String objectType;

  protected AppConfigItemWorkingSet(String monAppContext, IDfSession session, String objectType) throws DfException {
    this.columnDescriptors = getColumnDescriptors();
    this.columnDescriptors.add(0, new AppConfigColumnDescriptor("rowid", "Row ID", false, false, "0"));
    appConfigItems = new TableResultSet(getOnlyColumnNamesAsArray());
    this.objectType = objectType;
    appConfigItemObject = session
        .getObjectByQualification(this.objectType + " where mon_app_context = '" + monAppContext + "'");
    if (appConfigItemObject == null) {
      appConfigItemObject = createNewAppConfigItemObject(monAppContext, session, getObjectNameSuffix());
    }
    List appConfigItemsList = getAppConfigItemsFromAppConfigItemObject();
    if (appConfigItemsList != null) {
      appConfigItems = new TableResultSet(appConfigItemsList, getOnlyColumnNamesAsArray());
    }
  }

  public abstract List getColumnDescriptors();

  public abstract String getObjectNameSuffix();

  public abstract String getDeleteActionName();

  public static AppConfigItemWorkingSet createAppConfigItemWorkingSet(String monAppContext, IDfSession session,
                                                                      String objectType) throws DfException {
    if (objectType.equals("mon_app_owner_info")) {
      return new AppConfigOwnerWorkingSet(monAppContext, session, objectType);
    } else if (objectType.equals("mon_app_usage")) {
      return new AppConfigAppUsageWorkingSet(monAppContext, session);
    }

    return new AppConfigNullWorkingSet(monAppContext, session, objectType);
  }

  public ScrollableResultSet getResultSet() {
    return appConfigItems;
  }

  public List getColumnNames() {
    List appOwnerColumns = new ArrayList(columnDescriptors.size());
    Iterator iterator = columnDescriptors.iterator();
    while (iterator.hasNext()) {
      AppConfigColumnDescriptor columnDescriptor = (AppConfigColumnDescriptor) iterator.next();
      appOwnerColumns.add(columnDescriptor.getColumnDescriptor());
    }
    return appOwnerColumns;
  }

  public void addAppConfigItem(AppConfigItem item) {
    List columnNamesList = Arrays.asList(getOnlyColumnNamesAsArray());
    addAppConfigItem(item.getValues(columnNamesList.subList(1, columnNamesList.size())));

  }

  public boolean removeAppConfigItem(AppConfigItem appConfigItem) {
    return removeAppConfigItem(appConfigItem.get("rowid"));
  }

  public void save() throws DfException {
    Iterator iterator = getAppConfigItems();
    clearAppConfigItemObject();
    while (iterator.hasNext()) {
      List appConfigItem = (List) iterator.next();
      addAppConfigItemToAppConfigItemObject(appConfigItem);
    }
    appConfigItemObject.save();
  }

  private String[] getOnlyColumnNamesAsArray() {
    Iterator iterator = columnDescriptors.iterator();
    String[] colArray = new String[columnDescriptors.size()];
    int colIndex = 0;
    while (iterator.hasNext()) {
      AppConfigColumnDescriptor columnDescriptor = (AppConfigColumnDescriptor) iterator.next();
      colArray[colIndex] = (String) columnDescriptor.getColumnName();
      colIndex++;
    }
    return colArray;
  }

  protected Iterator getAppConfigItems() {
    return getAppConfigItemsFromResultSet().iterator();
  }

  private void addAppConfigItem(List appConfigItem) {
    appConfigItems.add(generateAppConfigItem(appConfigItem));
    if (appConfigItems.getResultsCount() == 2) removeDefaultAppConfigItem();
  }

  private boolean removeAppConfigItem(String rowId) {
    List appConfigItemsList = getAppConfigItemsFromResultSet();
    int index = locateAppConfigItem(rowId);
    if (index > -1) appConfigItemsList.remove(index);
    appConfigItems = new TableResultSet(appConfigItemsList, getOnlyColumnNamesAsArray());
    if (appConfigItems.getResultsCount() < 1) {
      addDefaultAppConfigItem();
    }
    return (index > -1);
  }

  private List getAppConfigItemsFromAppConfigItemObject() throws DfException {
    int numOfAppConfigItems = getNumberOfAppConfigItemsInAppConfigItemObject();
    List listOfAppConfigItems = null;
    if (numOfAppConfigItems > 0) {
      listOfAppConfigItems = new ArrayList(numOfAppConfigItems);
      for (int i = 0; i < numOfAppConfigItems; i++) {
        Iterator iterator = columnDescriptors.iterator();
        List appConfigItem = new ArrayList(columnDescriptors.size());
        while (iterator.hasNext()) {
          AppConfigColumnDescriptor columnDescriptor = (AppConfigColumnDescriptor) iterator.next();
          if (columnDescriptor.isMappedToSysObject()) {
            String value = appConfigItemObject.getRepeatingString(columnDescriptor.getColumnName(), i);
            appConfigItem.add(value);
          }
        }
        listOfAppConfigItems.add(generateAppConfigItem(appConfigItem));
      }
    }
    return listOfAppConfigItems;
  }

  private int getNumberOfAppConfigItemsInAppConfigItemObject() throws DfException {
    int numOfAppConfigItems = 0;
    Iterator iterator = columnDescriptors.iterator();
    while (iterator.hasNext()) {
      AppConfigColumnDescriptor columnDescriptor = (AppConfigColumnDescriptor) iterator.next();
      if (columnDescriptor.isMappedToSysObject()) {
        numOfAppConfigItems = appConfigItemObject.getValueCount(columnDescriptor.getColumnName());
      }
    }
    return numOfAppConfigItems;
  }

  private List getAppConfigItemsFromResultSet() {
    appConfigItems.setCursor(-1);
    int resultsCount = appConfigItems.getResultsCount();
    List actualResults = new ArrayList(3);
    for (int i = 0; i < resultsCount; i++) {
      List row = new ArrayList(columnDescriptors.size());
      appConfigItems.next();
      for (int j = 0; j < columnDescriptors.size(); j++) {
        row.add(appConfigItems.getObject(j + 1));
      }
      actualResults.add(row);
    }
    return actualResults;
  }

  private List generateAppConfigItem(List appConfigItem) {
    List newAppConfigItem = new ArrayList(appConfigItem);
    newAppConfigItem.add(0, Integer.toString(rowid));
    rowid++;
    return newAppConfigItem;
  }

  private IDfPersistentObject createNewAppConfigItemObject(String monAppContext, IDfSession session,
                                                           String objectNameSuffix) throws DfException {
    IDfPersistentObject newAppConfigItemObject = session.newObject(objectType);
    newAppConfigItemObject.setString("object_name", monAppContext + objectNameSuffix);
    newAppConfigItemObject.setString("mon_app_context", monAppContext);
    newAppConfigItemObject.save();
    addDefaultAppConfigItem();
    return newAppConfigItemObject;
  }

  private void addDefaultAppConfigItem() {
    Iterator iterator = columnDescriptors.iterator();
    iterator.next();
    List defaultValues = new ArrayList(columnDescriptors.size() - 1);
    while (iterator.hasNext()) {
      String defaultValue = ((AppConfigColumnDescriptor) iterator.next()).getDefaultValue();
      defaultValues.add(defaultValue);
    }
    addAppConfigItem(defaultValues);
    String defaultRowId = Integer.toString(rowid - 1);
    columnDescriptors.set(0, new AppConfigColumnDescriptor("rowid", "Row ID", false, false, defaultRowId));
  }

  private int locateAppConfigItem(String rowId) {
    Iterator iterator = getAppConfigItems();
    int index = 0;
    boolean found = false;
    while (iterator.hasNext()) {
      List appConfigItem = (List) iterator.next();
      if (appConfigItem.get(0).equals(rowId)) {
        found = true;
        break;
      }
      index++;
    }
    if (!found) index = -1;
    return index;
  }

  private void addAppConfigItemToAppConfigItemObject(List appConfigItem) throws DfException {
    Iterator iterator = columnDescriptors.iterator();
    int columnIndex = 0;
    while (iterator.hasNext()) {
      AppConfigColumnDescriptor columnDescriptor = (AppConfigColumnDescriptor) iterator.next();
      if (columnDescriptor.isMappedToSysObject()) {
        appConfigItemObject.appendString(columnDescriptor.getColumnName(), (String) appConfigItem.get(columnIndex));
      }
      columnIndex++;
    }
  }

  private void clearAppConfigItemObject() throws DfException {
    Iterator iterator = columnDescriptors.iterator();
    while (iterator.hasNext()) {
      AppConfigColumnDescriptor columnDescriptor = (AppConfigColumnDescriptor) iterator.next();
      if (columnDescriptor.isMappedToSysObject()) {
        appConfigItemObject.removeAll(columnDescriptor.getColumnName());
      }
    }
  }

  private void removeDefaultAppConfigItem() {
    removeAppConfigItem(((AppConfigColumnDescriptor) columnDescriptors.get(0)).getDefaultValue());
  }

}