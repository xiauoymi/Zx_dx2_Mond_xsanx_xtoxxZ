/*
 * User.java
 *
 * Created on July 8, 2006, 12:11 PM
 *
 * To change this template, choose Tools | Options and locate the template under
 * the Source Creation and Management node. Right-click the template and choose
 * Open. You can then make changes to the template in the Source Editor.
 */

package com.monsanto.dctm.usermtn;

import com.documentum.com.DfClientX;
import com.documentum.fc.client.IDfACL;
import com.documentum.fc.client.IDfPersistentObject;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.IDfSysObject;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfId;
import com.documentum.fc.common.IDfList;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

/**
 * @author tsvedan
 */
public class User {

  private String userName;
  private String userOSName;
  private String domain;
  private String userAddress;
  private String userSource;
  private String userGroupName;
  private String AclName;
  private String AclDomain;
  private String defaultFolder;
  private String clientCapability;
  private String additionalGroups;
  private String role;
  public static final String USER_NAME = "user_name";
  public static final String USER_OS_NAME = "user_os_name";
  public static final String USER_OS_DOMAIN = "user_os_domain";
  public static final String USER_ADDRESS = "user_address";
  public static final String USER_SOURCE = "user_source";
  public static final String USER_GROUP_NAME = "user_group_name";
  public static final String ACL_NAME = "acl_name";
  public static final String ACL_DOMAIN = "acl_domain";
  public static final String DEFAULT_FOLDER = "default_folder";
  public static final String CLIENT_CAPABILITY = "client_capability";
  public static final String OBJECT_TYPE = "object_type";
  public static final String DM_USER = "dm_user";
  public static final String ELEMENT_SEPARATOR = ";#";
  public static final String NAME_VALUE_SEPARATOR = ":";
  public static final String ADDITIONAL_GROUPS = "additional_groups";
  public static final String DEFAULT_DOMAIN = "north_america";
  public static final String EMAIL_SUFFIX = "@monsanto.com";
  public static final String DEFUALT_USER_SOURCE = "domain only";
  public static final String USER_LOGIN_DOMAIN = "user_login_domain" ;
  public static final String USER_LOGIN_NAME = "user_login_name";

  /**
   * Creates a new instance of User
   */
  public User() {
  }

  public String getUserName() {
    return userName;
  }

  public void setUserName(String userName) {
    this.userName = userName;
  }

  public String getUserOSName() {
    return userOSName;
  }

  public void setUserOSName(String userOSName) {
    this.userOSName = userOSName.toLowerCase();
    setUserAddress();
  }

  public String getDomain() {
    if (domain != null && domain.length() > 0) {
      return domain;
    } else {
      return DEFAULT_DOMAIN;
    }
  }

  public void setDomain(String domain) {
    this.domain = domain;
  }

  public String getUserAddress() {
    if (userAddress != null)
      return userAddress;
    else
      return "";
  }

  public void setUserAddress(String userAddress) {
    if (userAddress.indexOf(EMAIL_SUFFIX) > 0)
      this.userAddress = userAddress;
  }

  public void setUserAddress() {
    if (userOSName != null && userOSName.length() > 0)
      this.userAddress = userOSName + EMAIL_SUFFIX;
  }

  public String getUserSource() {
    if (userSource != null && userSource.length() > 0) {
      return userSource;
    } else {
      return DEFUALT_USER_SOURCE;
    }
  }

  public void setUserSource(String userSource) {
    this.userSource = userSource;
  }

  public String getUserGroupName() {
    return userGroupName;
  }

  public void setUserGroupName(String userGroupName) {
    this.userGroupName = userGroupName;
  }

  public String getAclName() {
    return AclName;
  }

  public void setAclName(String AclName) {
    this.AclName = AclName;
  }

  public String getAclDomain() {
    return AclDomain;
  }

  public void setAclDomain(String AclDomain) {
    this.AclDomain = AclDomain;
  }

  public String getDefaultFolder() {
    if (defaultFolder != null)
      return defaultFolder;
    else
      return "";
  }

  public void setDefaultFolder(String defaultFolder) {
    if (defaultFolder != null && defaultFolder.length() > 0)
      if (defaultFolder.startsWith("/"))
        this.defaultFolder = defaultFolder;
      else
        this.defaultFolder = "/" + defaultFolder;
  }

  public String getClientCapability() {
    return clientCapability;
  }

  public void setClientCapability(String clientCapability) {
    this.clientCapability = clientCapability;
  }

  public String getAdditionalGroups() {
    return additionalGroups;
  }

  public void setAdditionalGroups(String additionalGroups) {
    this.additionalGroups = additionalGroups;
  }

  public boolean equals(Object obj) {
    if (obj instanceof User) {
      User user = (User) obj;
      if (userOSName != null && userOSName.equals(user.userOSName))
        return true;
      if (userName != null && userName.equals(user.userName))
        return true;
    }
    return false;
  }

  public String toString() {
    return userOSName;
  }

  public String getRole() {
    return role;
  }

  public void setRole(String role) {
    this.role = role;
  }

  public boolean validate() {
    boolean valid = true;
    if (getUserOSName().length() == 0) {
      valid = false;
    }
    if (getUserName().length() == 0) {
      valid = false;
    }
    if (getUserGroupName() == null || getUserGroupName().length() == 0) {
      valid = false;
    }
    if (getAclName() == null || getAclName().length() == 0) {
      valid = false;
    }
    if (getAclDomain() == null || getAclDomain().length() == 0) {
      valid = false;
    }
    if (getDefaultFolder() == null || getDefaultFolder().length() == 0) {
      valid = false;
    }
    if (getClientCapability() == null || getClientCapability().length() == 0) {
      valid = false;
    }
    return valid;
  }

  private String getUserInfo() {
    StringBuffer strbuff = new StringBuffer(OBJECT_TYPE).append(NAME_VALUE_SEPARATOR).append(DM_USER);
    addNameValuePair(strbuff, USER_NAME, getUserName());
    addNameValuePair(strbuff, USER_OS_NAME, getUserOSName());
    addNameValuePair(strbuff, USER_OS_DOMAIN, getDomain());
    addNameValuePair(strbuff, USER_ADDRESS, getUserAddress());
    addNameValuePair(strbuff, USER_SOURCE, getUserSource());
    addNameValuePair(strbuff, USER_GROUP_NAME, getUserGroupName());
    addNameValuePair(strbuff, ACL_NAME, getAclName());
    addNameValuePair(strbuff, ACL_DOMAIN, getAclDomain());
    addNameValuePair(strbuff, DEFAULT_FOLDER, getDefaultFolder());
    addNameValuePair(strbuff, CLIENT_CAPABILITY, getClientCapability());
    addNameValuePair(strbuff, USER_LOGIN_NAME, getUserOSName());
    addNameValuePair(strbuff, USER_LOGIN_DOMAIN, getDomain());
    return strbuff.toString();
  }

  private void addNameValuePair(StringBuffer strbuff, String name, String value) {
    strbuff.append(ELEMENT_SEPARATOR).append(name).append(NAME_VALUE_SEPARATOR).append(value);
  }

  private File getUserFile() throws DfException {

    PrintWriter pw = null;
    File file = null;
    try {
      file = getTempFile();
      pw = new PrintWriter(new FileWriter(file, true));
      String [] lines = getUserInfo().split(ELEMENT_SEPARATOR);
      for (int j = 0; j < lines.length; j++) {
        pw.println(lines[j]);
      }
      pw.println();
      pw.close();
    } catch (IOException ioe) {
      throw new DfException("Couldn't generate user import file", ioe);
    }

    return file;
  }

  protected File getTempFile() throws IOException {
    return File.createTempFile("users", ".txt");
  }

  public void runImportUserMethod(IDfSession session) throws DfException {
    String userInfoObjectId = createUserInfoObject(session);
    List argumentNames = Arrays.asList(new String[]{"METHOD", "SAVE_RESULTS", "ARGUMENTS"});
    List argumentTypes = Arrays.asList(new String[]{"S", "B", "S"});
    List argumentValues = Arrays
        .asList(new String[]{"import_user", "TRUE", "'-docbase " + session.getDocbaseName() +
            " -userid " +
            session.getLoginInfo().getUser() +
            " -ticket " + session.getLoginTicket() +
            " -userinfoid " + userInfoObjectId +
            " -additional_groups " + getAdditionalGroups() + "'"});
    session.apply(null, "DO_METHOD", createDfListFromList(argumentNames), createDfListFromList(argumentTypes),
        createDfListFromList(argumentValues));
    IDfPersistentObject object = session.getObject(new DfId(userInfoObjectId));
    if (object != null) {
      object.destroy();
    }
  }

  private IDfList createDfListFromList(List list) throws DfException {
    DfClientX client = new DfClientX();
    IDfList dfList = client.getList();
    Iterator iterator = list.iterator();
    while (iterator.hasNext()) {
      dfList.appendString((String) iterator.next());
    }
    return dfList;
  }

  private String createUserInfoObject(IDfSession session) throws DfException {
    IDfSysObject document = (IDfSysObject) session.newObject("dm_document");
    document.setObjectName("New Users");
    document.setContentType("crtext");
    document.setOwnerPermit(IDfACL.DF_PERMIT_DELETE);
    File userFile = getUserFile();
    document.setFileEx(userFile.getAbsolutePath(), "crtext", 0, null);
    document.link("/Temp");
    document.save();
    deleteTempFile(userFile);
    return document.getObjectId().getId();
  }

  protected void deleteTempFile(File userFile) {
    userFile.delete();
  }
}
