/*
 Copyright:  Copyright � 2006 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.directed;

import com.documentum.web.common.ArgumentList;
import com.documentum.web.env.EnvironmentService;
import com.documentum.web.form.Form;
import com.documentum.web.formext.component.Component;
import com.documentum.web.formext.config.Context;

/**
 * Filename:    $RCSfile: AdvSearch.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: lakench $    	 On:	$Date: 2006-12-14 16:18:46 $
 *
 * @author lakench
 * @version $Revision: 1.4 $
 */
public class AdvSearch extends com.monsanto.dctm.advsearch.AdvSearch {
    protected void doSearch() {
        Context context = new Context(getContext());
        ArgumentList args = new ArgumentList();

        // remove the object id from the context
        context.remove("objectId");
        context.remove("queryId");

        String strObjectType = getSearchInfo().getQueryBuilder().getObjectType();
        context.set("type", strObjectType);
        args.replace("type", strObjectType);

        args.replace(PARAM_QUERY_ID, getSearchInfo().getQueryId());
        if (isDrillDownView()) {
            args.replace("drilldown", "true");
        } else {
            args.replace("drilldown", "false");
        }

        if (isShowWaitPage()) {
            args.replace("showwait", "true");
        } else {
            args.replace("showwait", "false");
        }

        args.replace("query", getSearchInfo().getQueryId());
        args.replace("queryType", "queryId");

        String strJumpComponent = "directed_search";
        boolean fIsPortal = false;
        if (EnvironmentService.getEnvironment() != null && EnvironmentService.getEnvironment().isPortalEnvironment()) {
            fIsPortal = true;
            args.replace("component", strJumpComponent);
            strJumpComponent = "searchcontainer";
        }
        Form topform = getTopForm();
        if (topform instanceof Component) {
            Form callerform = getCallerForm();
            if (callerform != null && callerform != this) {
                if (!fIsPortal || callerform.getCallerForm() != null || !(callerform instanceof Component)) {
                    ((Component) topform).setComponentReturnJump(strJumpComponent, args, context);
                } else {
                    // really need a returnnest operation here if the caller is a toplevel component.
                    ((Component) topform).setComponentNested(strJumpComponent, args, context, null);
                }
            } else if (fIsPortal) {
                ((Component) topform).setComponentNested(strJumpComponent, args, context, null);
            } else {
                ((Component) topform).setComponentJump(strJumpComponent, args, context);
            }
        }
    }
}