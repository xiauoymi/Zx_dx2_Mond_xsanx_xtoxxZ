package com.monsanto.dctm.search;

public class RepositorySearchTag extends com.documentum.web.formext.control.docbase.search.RepositorySearchTag {

  /**
   * @noinspection RefusedBequest
   */
  protected Class getControlClass() {
    return com.monsanto.dctm.search.RepositorySearch.class;
  }

}
