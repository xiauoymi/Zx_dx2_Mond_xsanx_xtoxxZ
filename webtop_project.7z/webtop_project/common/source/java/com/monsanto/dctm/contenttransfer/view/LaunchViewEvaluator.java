package com.monsanto.dctm.contenttransfer.view;

import com.documentum.web.common.ArgumentList;
import com.documentum.web.formext.component.Component;
import com.documentum.web.formext.config.Context;
import com.documentum.web.formext.config.IConfigElement;
import com.monsanto.dctm.monAppContext.IMonAppContextService;
import com.monsanto.dctm.monAppContext.MonAppContextService;

public class LaunchViewEvaluator extends com.documentum.webcomponent.library.contenttransfer.view.LaunchViewEvaluator {

    public String evaluate(String strName, String strAction, IConfigElement config, ArgumentList arg, Context context, Component component) {
        String strReturn = super.evaluate(strName, strAction, config, arg, context, component);

        IMonAppContextService monAppContextService = MonAppContextService.getMonAppContextService();

        if (strReturn.equals("action") && !monAppContextService.isUseViewForCommentingEnabled()) {
            strReturn = "ucf";
        }

        return strReturn;
    }

}
