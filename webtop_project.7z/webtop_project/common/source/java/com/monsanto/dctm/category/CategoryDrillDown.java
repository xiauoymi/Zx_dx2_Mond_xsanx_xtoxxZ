package com.monsanto.dctm.category;

import com.monsanto.dctm.monAppContext.MonAppContextService;

public class CategoryDrillDown extends
                               com.documentum.webcomponent.navigation.category.CategoryDrillDown {

    protected String getColumnsPreferenceId() {
        return super.getColumnsPreferenceId() + "." +
               MonAppContextService.getMonAppContextService().getMonAppContextInternalName();
    }

}
