/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.autoLogin.test;

import com.documentum.fc.client.IDfDocbaseMap;
import com.documentum.fc.client.IDfTypedObject;
import com.documentum.fc.common.DfException;
import com.monsanto.dctm.component.test.MockTypedObject;

/**
 * Filename:    $RCSfile: MockDocbaseMap.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: lakench $    	 On:	$Date: 2007-01-16 22:56:32 $
 *
 * @author LAKENCH
 * @version $Revision: 1.1 $
 */
public class MockDocbaseMap extends MockTypedObject implements IDfDocbaseMap {
    public String getHostName() throws DfException {
        return "localhost";
    }

    public void addDocbase(String docbaseId, String docbaseName, String docbaseDescription) throws DfException {
        appendString("docbaseids", docbaseId);
        appendString("docbasenames", docbaseName);
        appendString("docbasedescriptions", docbaseDescription);
    }

    public int getDocbaseCount() throws DfException {
        return getValueCount("docbaseids");
    }

    public String getDocbaseId(int i) throws DfException {
        return getRepeatingString("docbaseids", i);
    }

    public String getDocbaseName(int i) throws DfException {
        return getRepeatingString("docbasenames", i);
    }

    public String getDocbaseDescription(int i) throws DfException {
        return getRepeatingString("docbasedescriptions", i);
    }

    public String getServerVersion(int i) throws DfException {
        return null;
    }

    public IDfTypedObject getServerMap(int i) throws DfException {
        return null;
    }

    public IDfTypedObject getServerMapByName(String string) throws DfException {
        return null;
    }
}