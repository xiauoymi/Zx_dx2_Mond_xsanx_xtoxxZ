/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.appconfig.test;

import com.monsanto.dctm.appconfig.AppConfigItem;
import junit.framework.TestCase;

import java.util.*;

/**
 * Filename:    $RCSfile: AppConfigItem_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: lakench $
 * On:	$Date: 2007-08-24 21:30:26 $
 *
 * @author lakench
 * @version $Revision: 1.2 $
 */
public class AppConfigItem_UT extends TestCase {
  private AppConfigItem appConfigItem;
  public static final String TEST_VALUE_ONE = "test value - col1";
  public static final String TEST_VALUE_TWO = "test value - col2";
  public static final String TEST_VALUE_THREE = "test value - col3";
  public static final String TEST_VALUE_FOUR = "test value - col4";
  public static final String NEW_VALUE = "new value";
  public static final String COL_NAME_ONE = "col1";
  public static final String COL_NAME_TWO = "col2";
  public static final String COL_NAME_THREE = "col3";
  public static final String COL_NAME_FOUR = "col4";
  public static final String TESTTYPE = "testtype";

  protected void setUp() throws Exception {
    super.setUp();
    Map values = new HashMap(3);
    values.put(COL_NAME_ONE, TEST_VALUE_ONE);
    values.put(COL_NAME_TWO, TEST_VALUE_TWO);
    values.put(COL_NAME_THREE, TEST_VALUE_THREE);
    appConfigItem = new AppConfigItem(TESTTYPE, values);
    assertNotNull(appConfigItem);
  }

  public void testCreate() throws Exception {
    assertEquals(TESTTYPE, appConfigItem.getItemType());
    assertEquals(TEST_VALUE_ONE, appConfigItem.get(COL_NAME_ONE));
    assertEquals(TEST_VALUE_TWO, appConfigItem.get(COL_NAME_TWO));
    assertEquals(TEST_VALUE_THREE, appConfigItem.get(COL_NAME_THREE));
  }

  public void testCreateWithNoInitialValues() throws Exception {
    AppConfigItem testAppConfigItem = new AppConfigItem(TESTTYPE);
    assertNotNull(testAppConfigItem);
    assertEquals(TESTTYPE, testAppConfigItem.getItemType());
    assertNull(testAppConfigItem.get("some column name that isnt there"));
    testAppConfigItem.set(COL_NAME_ONE, TEST_VALUE_ONE);
    assertEquals(TEST_VALUE_ONE, testAppConfigItem.get(COL_NAME_ONE));
  }

  public void testAddNewValue() throws Exception {
    appConfigItem.set(COL_NAME_FOUR, TEST_VALUE_FOUR);
    assertEquals(TESTTYPE, appConfigItem.getItemType());
    assertEquals(TEST_VALUE_ONE, appConfigItem.get(COL_NAME_ONE));
    assertEquals(TEST_VALUE_TWO, appConfigItem.get(COL_NAME_TWO));
    assertEquals(TEST_VALUE_THREE, appConfigItem.get(COL_NAME_THREE));
    assertEquals(TEST_VALUE_FOUR, appConfigItem.get(COL_NAME_FOUR));
  }

  public void testUpdateValue() throws Exception {
    appConfigItem.set(COL_NAME_TWO, NEW_VALUE);
    assertEquals(TEST_VALUE_ONE, appConfigItem.get(COL_NAME_ONE));
    assertEquals(NEW_VALUE, appConfigItem.get(COL_NAME_TWO));
    assertEquals(TEST_VALUE_THREE, appConfigItem.get(COL_NAME_THREE));
  }

  public void testGetNonExistentColumn() throws Exception {
    assertNull(appConfigItem.get("some column that isnt there"));
  }

  public void testGetListOfValuesInOrderGivenByListOfColumnNames() throws Exception {
    List columnNames = new ArrayList(3);
    columnNames.add(COL_NAME_THREE);
    columnNames.add(COL_NAME_ONE);
    columnNames.add(COL_NAME_TWO);
    List values = appConfigItem.getValues(columnNames);

    assertEquals(appConfigItem.get(COL_NAME_THREE), values.get(0));
    assertEquals(appConfigItem.get(COL_NAME_ONE), values.get(1));
    assertEquals(appConfigItem.get(COL_NAME_TWO), values.get(2));
  }

  public void testGetColumnNames() throws Exception {
    Set columnNames = appConfigItem.getColumnNames();
    Set expectedColumnNames = new HashSet(3);
    expectedColumnNames.add(COL_NAME_ONE);
    expectedColumnNames.add(COL_NAME_TWO);
    expectedColumnNames.add(COL_NAME_THREE);
    assertEquals(expectedColumnNames, columnNames);
  }
}