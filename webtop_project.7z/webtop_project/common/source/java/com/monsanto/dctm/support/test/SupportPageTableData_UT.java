/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.support.test;

import com.documentum.fc.client.MockSession;
import com.documentum.fc.common.DfLoginInfo;
import com.documentum.web.form.ComponentTestUtils;
import com.documentum.web.form.control.databound.ColumnDescriptor;
import com.documentum.web.form.control.databound.TableResultSet;
import com.monsanto.dctm.component.test.MockComponent;
import com.monsanto.dctm.component.test.MockSessionManager;
import com.monsanto.dctm.component.test.MockSysObject;
import junit.framework.TestCase;

import java.util.ArrayList;
import java.util.Iterator;

/**
 * Filename:    $RCSfile: SupportPageTableData_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: lakench $
 * On:	$Date: 2007-10-26 18:47:58 $
 *
 * @author lakench
 * @version $Revision: 1.4 $
 */
public class SupportPageTableData_UT extends TestCase {
  private MockSupportPageTableData mockSupportPageTableData;
  private ArrayList data;
  private ArrayList columnList;
  private MockComponent component;

  protected void setUp() throws Exception {
    super.setUp();
    MockSessionManager mockSessionManager = new MockSessionManager();
    DfLoginInfo dfLoginInfo = new DfLoginInfo();
    dfLoginInfo.setUser("testuserid");
    mockSessionManager.setIdentity("testdocbase", dfLoginInfo);
    DfLoginInfo dfLoginInfoForSupportConfig = new DfLoginInfo();
    dfLoginInfo.setUser("devl01");
    mockSessionManager.setIdentity("stltst03", dfLoginInfoForSupportConfig);
    MockSession sessionForSupportConfig = (MockSession) mockSessionManager.getSession("stltst03");
    MockSysObject expectedSupportConfigSysObject = new MockSysObject();
    sessionForSupportConfig.addObject(expectedSupportConfigSysObject, "mon_support_info");

    component = (MockComponent) ComponentTestUtils
        .getComponent(MockComponent.class, "testcomponent", "testdocbase", mockSessionManager);

    mockSupportPageTableData = new MockSupportPageTableData(component);
    data = new ArrayList();
    data.add(new String[]{"Row 1 Column 1 Value", "Row 1 Column 2 Value"});
    data.add(new String[]{"Row 2 Column 1 Value", "Row 2 Column 2 Value"});
    mockSupportPageTableData.setData(data);
    columnList = new ArrayList();
    columnList.add(new ColumnDescriptor("column1", "Column 1 Display", true));
    columnList.add(new ColumnDescriptor("column2", "Column 2 Display", true));
    mockSupportPageTableData.setColumnList(columnList);
  }

  protected void tearDown() throws Exception {
    ComponentTestUtils.releaseComponent(component);
    super.tearDown();
  }

  public void testResultSetContainsRightData() throws Exception {
    TableResultSet resultSet = mockSupportPageTableData.getResultSet();
    Iterator rows = data.iterator();
    Iterator columns = columnList.iterator();
    while (rows.hasNext()) {
      resultSet.next();
      Object row = rows.next();
      while (columns.hasNext()) {
        ColumnDescriptor column = (ColumnDescriptor) columns.next();
        String columnAttribute = column.getAttribute();
        int resultSetIndex = 1;
        try {
          resultSetIndex = resultSet.findColumn(columnAttribute) + 1;
        }
        catch (IllegalArgumentException e) {
          fail("column not found");
        }
        Object expectedValue = ((String[]) row)[resultSetIndex - 1];
        assertEquals("column value not set properly", expectedValue, resultSet.getObject(resultSetIndex));
      }
    }
  }
}