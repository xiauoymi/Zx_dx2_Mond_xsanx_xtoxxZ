package com.monsanto.dctm.validation;

import com.documentum.web.form.Form;
import com.documentum.web.form.control.validator.BaseValidator;
import com.documentum.web.formext.control.docbase.DocbaseObject;
import com.documentum.web.formext.control.docbase.DocbaseAttributeValue;
import com.documentum.web.formext.control.validator.DocbaseAttributeValidator;
import com.documentum.fc.common.DfLogger;

import java.util.Iterator;

/**
 * Created by IntelliJ IDEA.
 * User: ussing
 * Date: Nov 30, 2009
 * Time: 3:35:10 PM
 * To change this template use File | Settings | File Templates.
 */
public class BrazilLicensAppovalValidation extends CustomValidation {
    public BrazilLicensAppovalValidation(Form form, DocbaseObject docbaseObj) {
        super(form, docbaseObj);

        i_Form.setDoValidation(true);
        DfLogger.debug(this, "do validation? = " + i_Form.getDoValidation(), null, null);

        doCustomValidation = true;  //if we've created an instance of this object, we need custom validation
    }
    protected void customValidate() {
       getAttributes();
       bIsValid = true;
       strErrorMessage = "";
       //doCustomValidation = true; // need to uncomment it for UT's to pass
       if (doCustomValidation)
       {
         resetAllAttributesThatWillBeMadeRequiredConditionally();

         DfLogger.debug(this,"license_type" + hAttributes.get("license_type").toString(),null,null);

         if(hAttributes.get("license_type").toString().equals("AGRICULTURAL ZONE") ||
                 hAttributes.get("license_type").toString().equals("ESTADUAL AUTHORIZATION")
                         || hAttributes.get("license_type").toString().equals("LICENCIADOS")
                            || hAttributes.get("license_type").toString().equals("ATEC")){
           getEventValidation();
         }
         if(hAttributes.get("license_type").toString().equals("AGRICULTURAL ZONE") ||
                 hAttributes.get("license_type").toString().equals("ATEC")){
           getSeasonValidation();
         }
         if(hAttributes.get("license_type").toString().equals("INSCRI��O DE CAMPO") ||
                 hAttributes.get("license_type").toString().equals("ESTADUAL AUTHORIZATION")){
           getStateValidation();
         }
         if(hAttributes.get("license_type").toString().equals("ATEC")){
           getProcessNumValidation();
         }
         if(hAttributes.get("license_type").toString().equals("SEMENTES")){
           getCultivarNameValidation();
         }
         super.customValidate();
        resetAttributeFromValidator();
       }
     }
    private void resetAllAttributesThatWillBeMadeRequiredConditionally() {
     ((DocbaseAttributeValue) hAttributesControls.get("event")).setRequired(false);
     ((DocbaseAttributeValue) hAttributesControls.get("season")).setRequired(false);
     ((DocbaseAttributeValue) hAttributesControls.get("state")).setRequired(false);
     ((DocbaseAttributeValue) hAttributesControls.get("process_number")).setRequired(false);
     ((DocbaseAttributeValue) hAttributesControls.get("cultivar_name")).setRequired(false);
   }
     private void resetAttributeFromValidator() {
    		// Go through the validators again and if we have one for one of the
		//   attributes we're making conditionally required, remove it.  This prevents
		//   the error message from being duplicated in the summary and works around
		//   what is believed to be a bug when you change the attribute to not required
		//   and the error stays in the summary.  The asterisk will always be there
		//   when a field is required since the validator control is recreated when
		//   an attribute is marked as required.  Removing it at this point prevents
		//   the error summary from picking up this validator's error message.
		Iterator validators = vValidators.iterator();
		while(validators.hasNext())
		{
			BaseValidator validator = (BaseValidator) validators.next();
			if (!(validator instanceof DocbaseAttributeValidator))
			{
				DfLogger.debug(this, "validator: " + validator,null,null);
				DfLogger.debug(this, "controltovalidate: " + validator.getControlToValidate(),null,null);
			}
			if (!validator.getIsValid())
			{
				if (validator.getControlToValidate().getName() != null)
				{
					String attribute = (String) hAttrbiutesValueElementControls.get(validator.getControlToValidate().getName());
                    DfLogger.debug(this,"attribute: " + attribute,null,null);
					if (attribute != null)
					{
					    if (attribute.equals("event") || attribute.equals("season") ||
                                attribute.equals("state") || attribute.equals("process_number")
                                  || attribute.equals("cultivar_name"))
                        {
							DfLogger.debug(this,"I'm removing this validator: " + validator,null,null);
							validator.getForm().remove(validator);
						}
					}
				}
			}
		}
    }
    private void getCultivarNameValidation() {
         if (!((hAttributes.get("cultivar_name").toString() != null) && (hAttributes.get("cultivar_name").toString().length() > 0))){
           bIsValid = false;
           strErrorMessage += "You must specify nome_cultivar.</li><li>";
           ((DocbaseAttributeValue) hAttributesControls.get("cultivar_name")).setRequired(true);
         }
    }
    private void getProcessNumValidation() {
         if (!((hAttributes.get("process_number").toString() != null) && (hAttributes.get("process_number").toString().length() > 0))){
           bIsValid = false;
           strErrorMessage += "You must specify num_processo.</li><li>";
           ((DocbaseAttributeValue) hAttributesControls.get("process_number")).setRequired(true);
         }        
    }
    
    private void getStateValidation() {
         if (!((hAttributes.get("state").toString() != null) && (hAttributes.get("state").toString().length() > 0))){
           bIsValid = false;
           strErrorMessage += "You must specify estado.</li><li>";
           ((DocbaseAttributeValue) hAttributesControls.get("state")).setRequired(true);
         }
    }

     public void getSeasonValidation() {
         if (!((hAttributes.get("season").toString() != null) && (hAttributes.get("season").toString().length() > 0))){
           bIsValid = false;
           strErrorMessage += "You must specify safra.</li><li>";
           ((DocbaseAttributeValue) hAttributesControls.get("season")).setRequired(true);
         }
     }
   private void getEventValidation() {
     if (!((hAttributes.get("event").toString() != null) && (hAttributes.get("event").toString().length() > 0))){
       bIsValid = false;
       strErrorMessage += "You must specify evento.</li><li>";
       ((DocbaseAttributeValue) hAttributesControls.get("event")).setRequired(true);
     }
   }
    
}
