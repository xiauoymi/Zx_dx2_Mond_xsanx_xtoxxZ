/*
 Copyright:  Copyright � 2006 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.directed;

import com.documentum.web.formext.config.ConfigService;
import com.documentum.web.formext.config.Context;
import com.documentum.web.formext.config.IConfigLookup;
import com.documentum.web.formext.docbase.FolderUtil;
import com.documentum.webcomponent.navigation.homecabinet.HomeCabinetService;

/**
 * Filename:    $RCSfile: RootCabinetService.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: lakench $    	 On:	$Date: 2006-12-14 21:45:06 $
 *
 * @author lakench
 * @version $Revision: 1.12 $
 */
public class RootCabinetService {
    private static final String ROOT_PATH_CONFIG = "component[id=directed_root_cabinet].rootPath";

    public static String getRootCabinetPath() {
        Context context = new Context();
        IConfigLookup configLookup = ConfigService.getConfigLookup();


        String rootPath = configLookup.lookupString(ROOT_PATH_CONFIG, context);
        if (rootPath == null || rootPath.length() < 1) {
            return HomeCabinetService.getHomeCabinetPath();
        } else {
            return rootPath;
        }
    }

    public static String stripRootCabinetFromObjectIds(String objectIds) {
        if (objectIds.equals(FolderUtil.getFolderIdsFromPath(getRootCabinetPath()))) return "";
        String stringToStrip = FolderUtil.getFolderIdsFromPath(getRootCabinetPath()) + ".";
        if (objectIds.startsWith(stringToStrip))
            return objectIds.substring(stringToStrip.length());
        else
            return objectIds;
    }
}