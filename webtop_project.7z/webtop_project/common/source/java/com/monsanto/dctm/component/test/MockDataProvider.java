/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.component.test;

import com.documentum.web.form.Control;
import com.documentum.web.form.control.databound.DataProvider;
import com.documentum.web.form.control.databound.ScrollableResultSet;

/**
 * Filename:    $RCSfile: MockDataProvider.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: lakench $    	 On:	$Date: 2007-08-21 05:23:14 $
 *
 * @author lakench
 * @version $Revision: 1.1 $
 */
public class MockDataProvider extends DataProvider {
  public boolean wasRefreshed = false;

  public MockDataProvider(Control control) {
    super(control);
  }

  public void refresh() {
    wasRefreshed = true;
  }

  public void refresh(ScrollableResultSet scrollableResultSet) {
    wasRefreshed = true;
  }
}