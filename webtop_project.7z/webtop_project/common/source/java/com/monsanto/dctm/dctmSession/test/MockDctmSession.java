/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.dctmSession.test;

import com.documentum.fc.client.DfAuthenticationException;
import com.documentum.fc.client.DfServiceException;
import com.documentum.fc.client.IDfSessionManager;
import com.monsanto.dctm.component.test.MockSessionManager;
import com.monsanto.dctm.dctmSession.DocumentumSessionInstance;
import com.monsanto.dctm.dctmSession.Session;
import com.monsanto.dctm.dctmSession.SessionInstance;

/**
 * Filename:    $RCSfile: MockDctmSession.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: lakench $    	 On:	$Date: 2007-03-30 20:58:38 $
 *
 * @author lakench
 * @version $Revision: 1.1 $
 */
public class MockDctmSession implements Session {
    private String docbase;
    private IDfSessionManager dfSessionManager;

    public MockDctmSession() {
        this("testdocbase");
    }

    public MockDctmSession(String docbase) {
        this(new MockSessionManager(), docbase);
    }

    public MockDctmSession(IDfSessionManager dfSessionManager, String docbase) {
        this.docbase = docbase;
        this.dfSessionManager = dfSessionManager;
    }

    public SessionInstance getNewSession() throws DfServiceException, DfAuthenticationException {
        return new DocumentumSessionInstance(dfSessionManager,
                                             docbase);
    }
}