/*
 * Created on Jul 19, 2005
 *
 */
package com.monsanto.dctm.validation;

import java.util.Iterator;
import java.util.Vector;

import com.documentum.web.form.Form;
import com.documentum.web.form.control.validator.BaseValidator;
import com.documentum.web.formext.control.docbase.DocbaseAttributeValue;
import com.documentum.web.formext.control.docbase.DocbaseObject;
import com.documentum.web.formext.control.validator.DocbaseAttributeValidator;

/**
 * @author lakench
 *
 */
public class AgPesticideLabelsValidation extends CustomValidation
{
	public AgPesticideLabelsValidation(Form form, DocbaseObject docbaseObj) {
		super(form, docbaseObj);
		doCustomValidation = true;
	}
	
	protected void customValidate()
	{
		System.out.println("I'm in customValidate, AgPesticideLabelsValidation.");
		
		// Reset any attributes we're making conditionally required
		((DocbaseAttributeValue) hAttributesControls.get("active_ingredient")).setRequired(false);
		((DocbaseAttributeValue) hAttributesControls.get("registration_type")).setRequired(false);
		((DocbaseAttributeValue) hAttributesControls.get("epa_reg_no")).setRequired(false);
		((DocbaseAttributeValue) hAttributesControls.get("submitted_date")).setRequired(false);
		((DocbaseAttributeValue) hAttributesControls.get("approved_date")).setRequired(false);
		((DocbaseAttributeValue) hAttributesControls.get("brand_name")).setRequired(false);
		((DocbaseAttributeValue) hAttributesControls.get("print_plate_date")).setRequired(false);
		((DocbaseAttributeValue) hAttributesControls.get("print_plate_number")).setRequired(false);
		
		if (hAttributes.get("pesticide_label_status") != null && hAttributes.get("pesticide_label_status").toString().length() > 0)
		{
			String status = hAttributes.get("pesticide_label_status").toString();
			System.out.println("status = '" + status + "'");
			if (status.equals("Approved"))
			{
				bIsValid = oneOrTheOtherValidation("active_ingredient", "Active Ingredient(s)", "other_act_ing_desc", "Other Active Ingredient") && bIsValid;
				((DocbaseAttributeValue) hAttributesControls.get("active_ingredient")).setRequired(true);
				if (!((hAttributes.get("registration_type").toString() != null) && (hAttributes.get("registration_type").toString().length() > 0)))
				{
					bIsValid = false;
					strErrorMessage += "You must specify Registration Type.</li><li>";
					((DocbaseAttributeValue) hAttributesControls.get("registration_type")).setRequired(true);
				}
				if (!((hAttributes.get("epa_reg_no").toString() != null) && (hAttributes.get("epa_reg_no").toString().length() > 0)))
				{
					bIsValid = false;
					strErrorMessage += "You must specify EPA Reg. Number.</li><li>";
					((DocbaseAttributeValue) hAttributesControls.get("epa_reg_no")).setRequired(true);
				}
				if (!((hAttributes.get("submitted_date").toString() != null) && (hAttributes.get("submitted_date").toString().length() > 0)))
				{
					bIsValid = false;
					strErrorMessage += "You must specify Submitted Date.</li><li>";
//					((DocbaseAttributeValue) hAttributesControls.get("submitted_date")).setRequired(true);
				}
				if (!((hAttributes.get("approved_date").toString() != null) && (hAttributes.get("approved_date").toString().length() > 0)))
				{
					bIsValid = false;
					strErrorMessage += "You must specify Approved Date.</li><li>";
//					((DocbaseAttributeValue) hAttributesControls.get("approved_date")).setRequired(true);
				}
				if ((!(((Vector) hAttributes.get("brand_name")).isEmpty()) && !(hAttributes.get("brand_name").toString().equals("[]"))) || (hAttributes.get("other_brand_name_desc") != null && ((String) hAttributes.get("other_brand_name_desc")).length() > 0))
				{
					bIsValid = oneOrTheOtherValidation("brand_name", "Brand Name(s)", "other_brand_name_desc", "Other Brand Name") && bIsValid;
				}
			}
			else if (status.equals("Approved Correct"))
			{
				bIsValid = oneOrTheOtherValidation("active_ingredient", "Active Ingredient(s)", "other_act_ing_desc", "Other Active Ingredient") && bIsValid;
				((DocbaseAttributeValue) hAttributesControls.get("active_ingredient")).setRequired(true);
				if (!((hAttributes.get("registration_type").toString() != null) && (hAttributes.get("registration_type").toString().length() > 0)))
				{
					bIsValid = false;
					strErrorMessage += "You must specify Registration Type.</li><li>";
					((DocbaseAttributeValue) hAttributesControls.get("registration_type")).setRequired(true);
				}
				if (!((hAttributes.get("epa_reg_no").toString() != null) && (hAttributes.get("epa_reg_no").toString().length() > 0)))
				{
					bIsValid = false;
					strErrorMessage += "You must specify EPA Reg. Number.</li><li>";
					((DocbaseAttributeValue) hAttributesControls.get("epa_reg_no")).setRequired(true);
				}
				if (!((hAttributes.get("submitted_date").toString() != null) && (hAttributes.get("submitted_date").toString().length() > 0)))
				{
					bIsValid = false;
					strErrorMessage += "You must specify Submitted Date.</li><li>";
//					((DocbaseAttributeValue) hAttributesControls.get("submitted_date")).setRequired(true);
				}
				if (!((hAttributes.get("approved_date").toString() != null) && (hAttributes.get("approved_date").toString().length() > 0)))
				{
					bIsValid = false;
					strErrorMessage += "You must specify Approved Date.</li><li>";
//					((DocbaseAttributeValue) hAttributesControls.get("approved_date")).setRequired(true);
				}
				if ((!(((Vector) hAttributes.get("brand_name")).isEmpty()) && !(hAttributes.get("brand_name").toString().equals("[]"))) || (hAttributes.get("other_brand_name_desc") != null && ((String) hAttributes.get("other_brand_name_desc")).length() > 0))
				{
					bIsValid = oneOrTheOtherValidation("brand_name", "Brand Name(s)", "other_brand_name_desc", "Other Brand Name") && bIsValid;
				}				
			}
			else if (status.equals("Edited for Print"))
			{
				bIsValid = oneOrTheOtherValidation("active_ingredient", "Active Ingredient(s)", "other_act_ing_desc", "Other Active Ingredient") && bIsValid;
				((DocbaseAttributeValue) hAttributesControls.get("active_ingredient")).setRequired(true);
				bIsValid = oneOrTheOtherValidation("brand_name", "Brand Name(s)", "other_brand_name_desc", "Other Brand Name") && bIsValid;
				((DocbaseAttributeValue) hAttributesControls.get("brand_name")).setRequired(true);
				if (!((hAttributes.get("registration_type").toString() != null) && (hAttributes.get("registration_type").toString().length() > 0)))
				{
					bIsValid = false;
					strErrorMessage += "You must specify Registration Type.</li><li>";
					((DocbaseAttributeValue) hAttributesControls.get("registration_type")).setRequired(true);
				}
				if (!((hAttributes.get("epa_reg_no").toString() != null) && (hAttributes.get("epa_reg_no").toString().length() > 0)))
				{
					bIsValid = false;
					strErrorMessage += "You must specify EPA Reg. Number.</li><li>";
					((DocbaseAttributeValue) hAttributesControls.get("epa_reg_no")).setRequired(true);
				}
			}
			else if (status.equals("In-Progress"))
			{
				bIsValid = oneOrTheOtherValidation("active_ingredient", "Active Ingredient(s)", "other_act_ing_desc", "Other Active Ingredient") && bIsValid;
				((DocbaseAttributeValue) hAttributesControls.get("active_ingredient")).setRequired(true);
				if (!((hAttributes.get("registration_type").toString() != null) && (hAttributes.get("registration_type").toString().length() > 0)))
				{
					bIsValid = false;
					strErrorMessage += "You must specify Registration Type.</li><li>";
					((DocbaseAttributeValue) hAttributesControls.get("registration_type")).setRequired(true);
				}
				if ((!(((Vector) hAttributes.get("brand_name")).isEmpty()) && !(hAttributes.get("brand_name").toString().equals("[]"))) || (hAttributes.get("other_brand_name_desc") != null && ((String) hAttributes.get("other_brand_name_desc")).length() > 0))
				{
					bIsValid = oneOrTheOtherValidation("brand_name", "Brand Name(s)", "other_brand_name_desc", "Other Brand Name") && bIsValid;
				}
			}
			else if (status.equals("Printed"))
			{
				bIsValid = oneOrTheOtherValidation("active_ingredient", "Active Ingredient(s)", "other_act_ing_desc", "Other Active Ingredient") && bIsValid;
				((DocbaseAttributeValue) hAttributesControls.get("active_ingredient")).setRequired(true);
				bIsValid = oneOrTheOtherValidation("brand_name", "Brand Name(s)", "other_brand_name_desc", "Other Brand Name") && bIsValid;
				((DocbaseAttributeValue) hAttributesControls.get("brand_name")).setRequired(true);
				if (!((hAttributes.get("registration_type").toString() != null) && (hAttributes.get("registration_type").toString().length() > 0)))
				{
					bIsValid = false;
					strErrorMessage += "You must specify Registration Type.</li><li>";
					((DocbaseAttributeValue) hAttributesControls.get("registration_type")).setRequired(true);
				}
				if (!((hAttributes.get("epa_reg_no").toString() != null) && (hAttributes.get("epa_reg_no").toString().length() > 0)))
				{
					bIsValid = false;
					strErrorMessage += "You must specify EPA Reg. Number.</li><li>";
					((DocbaseAttributeValue) hAttributesControls.get("epa_reg_no")).setRequired(true);
				}
				if (!((hAttributes.get("print_plate_date").toString() != null) && (hAttributes.get("print_plate_date").toString().length() > 0)))
				{
					bIsValid = false;
					strErrorMessage += "You must specify Print Plate Date.</li><li>";
					((DocbaseAttributeValue) hAttributesControls.get("print_plate_date")).setRequired(true);
				}
				if (!((hAttributes.get("print_plate_number").toString() != null) && (hAttributes.get("print_plate_number").toString().length() > 0)))
				{
					bIsValid = false;
					strErrorMessage += "You must specify Print Plate Number.</li><li>";
					((DocbaseAttributeValue) hAttributesControls.get("print_plate_number")).setRequired(true);
				}
			}
			else if (status.equals("Submitted"))
			{
				bIsValid = oneOrTheOtherValidation("active_ingredient", "Active Ingredient(s)", "other_act_ing_desc", "Other Active Ingredient") && bIsValid;
				((DocbaseAttributeValue) hAttributesControls.get("active_ingredient")).setRequired(true);
				if (!((hAttributes.get("registration_type").toString() != null) && (hAttributes.get("registration_type").toString().length() > 0)))
				{
					bIsValid = false;
					strErrorMessage += "You must specify Registration Type.</li><li>";
					((DocbaseAttributeValue) hAttributesControls.get("registration_type")).setRequired(true);
				}
				if (!((hAttributes.get("submitted_date").toString() != null) && (hAttributes.get("submitted_date").toString().length() > 0)))
				{
					bIsValid = false;
					strErrorMessage += "You must specify Submitted Date.</li><li>";
//					((DocbaseAttributeValue) hAttributesControls.get("submitted_date")).setRequired(true);
				}
				if ((!(((Vector) hAttributes.get("brand_name")).isEmpty()) && !(hAttributes.get("brand_name").toString().equals("[]"))) || (hAttributes.get("other_brand_name_desc") != null && ((String) hAttributes.get("other_brand_name_desc")).length() > 0))
				{
					bIsValid = oneOrTheOtherValidation("brand_name", "Brand Name(s)", "other_brand_name_desc", "Other Brand Name") && bIsValid;
				}
			}
			else if (status.equals("Draft EFP"))
			{
				bIsValid = oneOrTheOtherValidation("active_ingredient", "Active Ingredient(s)", "other_act_ing_desc", "Other Active Ingredient") && bIsValid;
				((DocbaseAttributeValue) hAttributesControls.get("active_ingredient")).setRequired(true);
				if (!((hAttributes.get("registration_type").toString() != null) && (hAttributes.get("registration_type").toString().length() > 0)))
				{
					bIsValid = false;
					strErrorMessage += "You must specify Registration Type.</li><li>";
					((DocbaseAttributeValue) hAttributesControls.get("registration_type")).setRequired(true);
				}
				if (!((hAttributes.get("epa_reg_no").toString() != null) && (hAttributes.get("epa_reg_no").toString().length() > 0)))
				{
					bIsValid = false;
					strErrorMessage += "You must specify EPA Reg. Number.</li><li>";
					((DocbaseAttributeValue) hAttributesControls.get("epa_reg_no")).setRequired(true);
				}
				if (!((hAttributes.get("submitted_date").toString() != null) && (hAttributes.get("submitted_date").toString().length() > 0)))
				{
					bIsValid = false;
					strErrorMessage += "You must specify Submitted Date.</li><li>";
//					((DocbaseAttributeValue) hAttributesControls.get("submitted_date")).setRequired(true);
				}
				if (!((hAttributes.get("approved_date").toString() != null) && (hAttributes.get("approved_date").toString().length() > 0)))
				{
					bIsValid = false;
					strErrorMessage += "You must specify Approved Date.</li><li>";
//					((DocbaseAttributeValue) hAttributesControls.get("approved_date")).setRequired(true);
				}
				if ((!(((Vector) hAttributes.get("brand_name")).isEmpty()) && !(hAttributes.get("brand_name").toString().equals("[]"))) || (hAttributes.get("other_brand_name_desc") != null && ((String) hAttributes.get("other_brand_name_desc")).length() > 0))
				{
					bIsValid = oneOrTheOtherValidation("brand_name", "Brand Name(s)", "other_brand_name_desc", "Other Brand Name") && bIsValid;
				}
			}
			else if (status.equals("Draft Printed"))
			{
				bIsValid = oneOrTheOtherValidation("active_ingredient", "Active Ingredient(s)", "other_act_ing_desc", "Other Active Ingredient") && bIsValid;
				((DocbaseAttributeValue) hAttributesControls.get("active_ingredient")).setRequired(true);
				bIsValid = oneOrTheOtherValidation("brand_name", "Brand Name(s)", "other_brand_name_desc", "Other Brand Name") && bIsValid;
				((DocbaseAttributeValue) hAttributesControls.get("brand_name")).setRequired(true);
				if (!((hAttributes.get("registration_type").toString() != null) && (hAttributes.get("registration_type").toString().length() > 0)))
				{
					bIsValid = false;
					strErrorMessage += "You must specify Registration Type.</li><li>";
					((DocbaseAttributeValue) hAttributesControls.get("registration_type")).setRequired(true);
				}
				if (!((hAttributes.get("epa_reg_no").toString() != null) && (hAttributes.get("epa_reg_no").toString().length() > 0)))
				{
					bIsValid = false;
					strErrorMessage += "You must specify EPA Reg. Number.</li><li>";
					((DocbaseAttributeValue) hAttributesControls.get("epa_reg_no")).setRequired(true);
				}
			}
		}
		
		System.out.println("in AgPesticideLabelsValidation, strErrorMessage = '" + strErrorMessage + "'");
		super.customValidate(); //do what has to always happen during validation

		// Do some error message patching.
		if (objDocbaseObjectValidator != null)
		{
			String strOrigErrorMessage = objDocbaseObjectValidator.getErrorMessage();
			System.out.println("After super.customValidate(), err msg from docbaseobj = '" + strOrigErrorMessage + "'");
			if (!bIsValid)
			{
				if (strOrigErrorMessage.lastIndexOf("&nbsp;:&nbsp;Default error message") >= 0)
				{
					strOrigErrorMessage = strOrigErrorMessage.substring(0, strOrigErrorMessage.lastIndexOf("&nbsp;:&nbsp;Default error message"));
				}
				if (strOrigErrorMessage.lastIndexOf("Doc Language&nbsp;:&nbsp;User must input a value.<br>") >= 0)
				{
					strOrigErrorMessage = strOrigErrorMessage.substring(0, strOrigErrorMessage.lastIndexOf("Doc Language&nbsp;:&nbsp;User must input a value.<br>"));
				}
				if (strOrigErrorMessage.lastIndexOf("[DM_DFC_E_BAD_VALUE]error: \"Bad value passed as argument: null.\"") >= 0)
				{
					strOrigErrorMessage = strOrigErrorMessage.substring(0, strOrigErrorMessage.lastIndexOf("[DM_DFC_E_BAD_VALUE]error: \"Bad value passed as argument: null.\""));
				}
			}
			else
			{
				strOrigErrorMessage = "";
			}
			objDocbaseObjectValidator.setErrorMessage(strOrigErrorMessage);
		}
		// Go through the validators again and if we have one for one of the
		//   attributes we're making conditionally required, remove it.  This prevents
		//   the error message from being duplicated in the summary and works around
		//   what is believed to be a bug when you change the attribute to not required
		//   and the error stays in the summary.  The asterisk will always be there 
		//   when a field is required since the validator control is recreated when
		//   an attribute is marked as required.  Removing it at this point prevents
		//   the error summary from picking up this validator's error message.
		Iterator validators = vValidators.iterator();
		while(validators.hasNext())
		{
			BaseValidator validator = (BaseValidator) validators.next();
			if (!(validator instanceof DocbaseAttributeValidator))
			{
				System.out.println("validator: " + validator);
				System.out.println("\tcontroltovalidate: " + validator.getControlToValidate());
			}
			if (!validator.getIsValid())
			{
				if (validator.getControlToValidate().getName() != null)
				{
					String attribute = (String) hAttrbiutesValueElementControls.get(validator.getControlToValidate().getName());
					if (attribute != null)
					{
						if (attribute.equals("active_ingredient") || attribute.equals("registration_type") || attribute.equals("epa_reg_no") || attribute.equals("submitted_date") || attribute.equals("approved_date") || attribute.equals("brand_name") || attribute.equals("print_plate_date") || attribute.equals("print_plate_number"))
						{
							System.out.println("I'm removing this validator: " + validator);
							validator.getForm().remove(validator);
						}
					}
				}
			}
		}
	}
}
