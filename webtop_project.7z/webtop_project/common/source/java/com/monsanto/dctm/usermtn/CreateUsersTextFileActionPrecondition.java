/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.usermtn;

import com.documentum.fc.client.IDfGroup;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.common.DfException;
import com.documentum.web.common.ArgumentList;
import com.documentum.web.common.WrapperRuntimeException;
import com.documentum.web.formext.action.IActionPrecondition;
import com.documentum.web.formext.component.Component;
import com.documentum.web.formext.config.Context;
import com.documentum.web.formext.config.IConfigElement;
import com.documentum.web.formext.docbase.GroupMembershipCache;

/**
 * Filename:    $RCSfile: CreateUsersTextFileActionPrecondition.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: lakench $    	 On:	$Date: 2007-05-18 15:34:21 $
 *
 * @author lakench
 * @version $Revision: 1.1 $
 */
public class CreateUsersTextFileActionPrecondition implements IActionPrecondition {
    public boolean queryExecute(String attrName, IConfigElement iConfigElement, ArgumentList args, Context context, Component component) {
        try {
            return isUserInGroup("authorized_requestors", component.getDfSession());
        } catch (DfException e) {
            throw new WrapperRuntimeException("Failed to check group membership", e);
        }
    }

    protected boolean isUserInGroup(String groupName, IDfSession session) throws DfException {
        String loginUserName = session.getLoginUserName();
        // check group membership from GroupMemeberShipCache first for performance reasons
        boolean userInGroup = isUserInGroupFromCache(groupName, loginUserName, session.getDocbaseName());
        // GroupMemeberShipCache doesn't check groups in groups though so if not found, check the expensive way
        if (!userInGroup) {
            IDfGroup group = session.getGroup(groupName);
            if (group != null) {
                userInGroup = isUserInGroupFromGroupObject(group, loginUserName);
            }
        }
        return userInGroup;
    }

    private boolean isUserInGroupFromGroupObject(IDfGroup group, String loginUserName) throws DfException {
        int allUsersNamesCount = group.getAllUsersNamesCount();
        boolean userInGroupFromGroupObject = false;
        int i = 0;
        while (i < allUsersNamesCount && !userInGroupFromGroupObject) {
            userInGroupFromGroupObject = group.getAllUsersNames(i).equals(loginUserName);
            i++;
        }
        return userInGroupFromGroupObject;
    }

    protected boolean isUserInGroupFromCache(String groupName, String loginUserName, String docbaseName) {
        return GroupMembershipCache.getCache(groupName, docbaseName).isUserInGroup(loginUserName);
    }

    public String[] getRequiredParams() {
        return new String[0];
    }
}