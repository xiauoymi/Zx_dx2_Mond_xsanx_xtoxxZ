/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.support.test;

import com.documentum.fc.client.MockSession;
import com.documentum.fc.common.DfLoginInfo;
import com.documentum.web.form.ComponentTestUtils;
import com.documentum.web.form.control.databound.ColumnDescriptor;
import com.monsanto.dctm.component.test.MockComponent;
import com.monsanto.dctm.component.test.MockSessionManager;
import com.monsanto.dctm.component.test.MockSysObject;
import com.monsanto.dctm.support.TeamMembers;
import junit.framework.TestCase;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * Filename:    $RCSfile: TeamMembers_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: lakench $    	 On:	$Date:
 * 2007/01/13 08:44:09 $
 *
 * @author lakench
 * @version $Revision: 1.5 $
 */
public class TeamMembers_UT extends TestCase {
  private MockSysObject mockSysObject;
  private TeamMembers teamMembers;
  private MockComponent component;

  protected void setUp() throws Exception {
    super.setUp();
    MockSessionManager mockSessionManager = new MockSessionManager();
    DfLoginInfo dfLoginInfo = new DfLoginInfo();
    dfLoginInfo.setUser("testuserid");
    mockSessionManager.setIdentity("testdocbase", dfLoginInfo);
    DfLoginInfo dfLoginInfoForSupportConfig = new DfLoginInfo();
    dfLoginInfo.setUser("devl01");
    mockSessionManager.setIdentity("stltst03", dfLoginInfoForSupportConfig);
    MockSession sessionForSupportConfig = (MockSession) mockSessionManager.getSession("stltst03");

    component = (MockComponent) ComponentTestUtils
        .getComponent(MockComponent.class, "testcomponent", "testdocbase", mockSessionManager);
    mockSysObject = new MockSysObject();
    sessionForSupportConfig.addObject(mockSysObject, "mon_support_info");
    teamMembers = new TeamMembers(component);
  }

  protected void tearDown() throws Exception {
    ComponentTestUtils.releaseComponent(component);
    super.tearDown();
  }

  public void testAllColumnsInColumnListAreColumnDescriptors() throws Exception {
    List columnList = teamMembers.getColumnList();
    Iterator columns = columnList.iterator();
    while (columns.hasNext()) {
      Object column = columns.next();
      assertTrue("column is not a ColumnDescriptor", column instanceof ColumnDescriptor);
    }
  }

  public void testColumnListContainsCorrectData() throws Exception {
    List expectedColumnList = new ArrayList(4);
    expectedColumnList.add(new ColumnDescriptor("name", "Name", true));
    expectedColumnList.add(new ColumnDescriptor("role", "Document Systems Role", true));
    expectedColumnList.add(new ColumnDescriptor("phone", "Phone", true));
    expectedColumnList.add(new ColumnDescriptor("email", "Email", true));

    List actualColumnList = teamMembers.getColumnList();
    Iterator expectedColumns = expectedColumnList.iterator();
    int index = 0;
    while (expectedColumns.hasNext()) {
      ColumnDescriptor expectedColumn = (ColumnDescriptor) expectedColumns.next();
      ColumnDescriptor actualColumn = (ColumnDescriptor) actualColumnList.get(index);
      assertEquals("column " + index + " attribute not set properly", expectedColumn.getAttribute(),
          actualColumn.getAttribute());
      assertEquals("column " + index + " alias not set properly", expectedColumn.getAlias(),
          actualColumn.getAlias());
      assertEquals("column " + index + " label not set properly", expectedColumn.getLabel(),
          actualColumn.getLabel());
      assertEquals("column " + index + " visible not set properly", expectedColumn.isVisible(),
          actualColumn.isVisible());
      index++;
    }
  }

  public void testDataIsReturnedProperly() throws Exception {
    List expectedNames = new ArrayList(2);
    expectedNames.add("name 1");
    expectedNames.add("name 2");
    List expectedRoles = new ArrayList(2);
    expectedRoles.add("role 1");
    expectedRoles.add("role 2");
    List expectedPhones = new ArrayList(2);
    expectedPhones.add("phone 1");
    expectedPhones.add("phone 2");
    List expectedEmails = new ArrayList(2);
    expectedEmails.add("email 1");
    expectedEmails.add("email 2");
    mockSysObject.setRepeatingStrings("team_member_name", expectedNames);
    mockSysObject.setRepeatingStrings("team_member_role", expectedRoles);
    mockSysObject.setRepeatingStrings("team_member_phone", expectedPhones);
    mockSysObject.setRepeatingStrings("team_member_email", expectedEmails);

    List data = teamMembers.getData();
    Iterator rows = data.iterator();
    int rowNum = 0;
    while (rows.hasNext()) {
      List actualRow = (List) rows.next();
      List expectedRow = new ArrayList(4);
      expectedRow.add(expectedNames.get(rowNum));
      expectedRow.add(expectedRoles.get(rowNum));
      expectedRow.add(expectedPhones.get(rowNum));
      expectedRow.add(expectedEmails.get(rowNum));
      assertEquals("row " + rowNum + " not set correctly", expectedRow, actualRow);
      rowNum++;
    }
  }
}