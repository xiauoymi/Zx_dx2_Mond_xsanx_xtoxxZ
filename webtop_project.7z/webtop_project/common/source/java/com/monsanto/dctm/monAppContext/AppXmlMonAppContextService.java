package com.monsanto.dctm.monAppContext;

import com.documentum.web.formext.config.ConfigService;
import com.documentum.web.formext.config.Context;
import com.documentum.web.formext.config.PreferenceService;
import com.documentum.web.formext.session.SessionManagerHttpBinding;

import java.util.List;

public class AppXmlMonAppContextService implements IMonAppContextService {
    private Context context;
    private String docbase;
    private IMonAppContexts monAppContexts;
    private static final String MON_APP_CONTEXT_ATTR_NAME = "mon_app_context";

    public AppXmlMonAppContextService() {
        this(SessionManagerHttpBinding.getCurrentDocbase());
    }

    public AppXmlMonAppContextService(String docbase) {
        setContext(Context.getSessionContext());
        setDocbase(docbase);
        initMonAppContexts();
    }

    private void initMonAppContexts() {
        monAppContexts = new AppXmlMonAppContexts(context);
    }

    public String getCurrentMonAppContextName() {
        String currentMonAppContextName = getCurrentMonAppContextNameFromPreference();
        if (currentMonAppContextName == null) {
            currentMonAppContextName = getCurrentMonAppContextNameFromContext();
        }
        return currentMonAppContextName;
    }

    private String getCurrentMonAppContextNameFromContext() {
        return getAttrValueFromSessionContext(MON_APP_CONTEXT_ATTR_NAME);
    }

    private String getAttrValueFromSessionContext(String attrName) {
        String monAppContextValue = null;
        int indexOfMonAppContext = Context.getSessionContext().toString().indexOf(attrName + "=");
        if (indexOfMonAppContext > 0) {
            String monAppContextAndBeyond = Context.getSessionContext().toString().substring(indexOfMonAppContext);
            int indexOfMonAppContextValue = monAppContextAndBeyond.indexOf('=') + 1;
            String monAppContextValueAndBeyond = monAppContextAndBeyond.substring(indexOfMonAppContextValue);
            int indexOfEndOfSessionContext = monAppContextValueAndBeyond.indexOf(")APP(");
            String monAppContextValueAndBeyondNoAppContext = monAppContextValueAndBeyond
                    .substring(0, indexOfEndOfSessionContext);
            int indexOfEndOfMonAppContextValue = monAppContextValueAndBeyondNoAppContext.indexOf(',');
            monAppContextValue = monAppContextValueAndBeyondNoAppContext;
            if (indexOfEndOfMonAppContextValue > 0)
                monAppContextValue = monAppContextValueAndBeyond.substring(0, indexOfEndOfMonAppContextValue);
        }
        return monAppContextValue;
    }

    private String getCurrentMonAppContextNameFromPreference() {
        return ConfigService.getConfigLookup()
                .lookupString("application." + MON_APP_CONTEXT_ATTR_NAME + "." + docbase, context);
    }

    public IMonAppContext getCurrentMonAppContext() {
        return monAppContexts.getMonAppContext(getCurrentMonAppContextName());
    }

    public String getMonAppContextInternalName() {
        return monAppContexts.getMonAppContext(getCurrentMonAppContextName()).getInternalName();
    }

    public boolean isUseViewForCommentingEnabled() {
        IMonAppContext currentContext = monAppContexts.getMonAppContext(getCurrentMonAppContextName());
        return currentContext.isUseViewForCommentingEnabled();
    }

    public void setMonAppContext() {
        setMonAppContext(getCurrentMonAppContextName());
    }

    public void setMonAppContext(String monAppContext) {
        setMonAppContext(monAppContext, true);
    }

    public void setMonAppContext(String monAppContext, boolean storePreference) {

        context.set(MON_APP_CONTEXT_ATTR_NAME, monAppContext);
        if (monAppContext == null)
            context.remove(MON_APP_CONTEXT_ATTR_NAME);

        if (storePreference)
            PreferenceService.getPreferenceStore()
                    .writeString("application." + MON_APP_CONTEXT_ATTR_NAME + "." + docbase, monAppContext);
    }

    public void setDocbase(String docbase) {
        this.docbase = docbase;
    }

    public String[] getSupportedMonAppContexts() {
        return getSupportedMonAppContexts(docbase);
    }

    public String[] getSupportedMonAppContexts(String docbase) {
        List monAppContextNames = monAppContexts.getMonAppContextNameList(docbase);
        monAppContextNames.add(0, null);
        String[] supportedMonAppContexts = new String[monAppContextNames.size()];
        monAppContextNames.toArray(supportedMonAppContexts);
        return supportedMonAppContexts;
    }

    private void setContext(Context context) {
        this.context = context;
    }

    public String getDocbase() {
        return docbase;
    }
}
