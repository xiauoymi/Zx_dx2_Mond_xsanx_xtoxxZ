/*
 Copyright:  Copyright � 2006 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.workflow.startworkflow;

import com.documentum.fc.client.IDfSession;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.IDfId;
import com.documentum.web.common.ArgumentList;
import com.documentum.web.formext.component.Component;
import com.documentum.web.formext.config.Context;
import com.documentum.web.formext.config.IConfigElement;

import java.util.Map;

/**
 * Filename:    $RCSfile: LaunchStartWorkflow.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: lakench $    	 On:	$Date: 2007-01-19 14:43:43 $
 *
 * @author tsvedan
 * @version $Revision: 1.2 $
 */
public class LaunchStartWorkflow
        extends com.documentum.webcomponent.library.workflow.startworkflow.LaunchStartWorkflow {

    public String[] getRequiredParams() {
        return (new String[]{
                "startworkflowId", "objectId"
        });
    }

    public boolean execute(String strAction, IConfigElement config, ArgumentList args, Context context,
                           Component component, Map completionArgs) {
        System.out.println("In Custom LaunchStartWorkflow.. ");
        if (component != null) {
            StringBuffer qual = new StringBuffer("dm_process where object_name='");
//            qual.append((MonAppContextService.getMonAppContextService()).getCurrentMonAppContextName()).append("'");
            qual.append(config.getChildValue("workflow-name")).append("'");
            IDfSession sess = component.getDfSession();
            IDfId strTemplateId = null;
            System.out.println("Query to execute.. " + qual);
            try {
                strTemplateId = sess.getIdByQualification(qual.toString());
            } catch (DfException dfe) {
            }
            if (strTemplateId == null || strTemplateId.isNull()) {
                System.out.println("Template Id is NULL!!");
                return false;
            } else
                System.out.println("Template Id = " + strTemplateId.getId());
            ArgumentList myargs = new ArgumentList();
            myargs.add("type", "dm_process");
            myargs.add("objectId", strTemplateId.getId());
            myargs.add("attachmentIds", args.get("objectId"));
            myargs.add("startworkflowId", "startworkflow");
            return super.execute(strAction, config, myargs, context, component, completionArgs);
        } else
            return false;
    }

}