/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.search.test;

import com.documentum.fc.client.IDfSessionManager;
import com.documentum.fc.client.search.IDfSearchService;
import com.documentum.web.form.ComponentTestUtils;
import com.documentum.webcomponent.library.search.SearchInfo;
import com.monsanto.dctm.component.test.MockSessionManager;
import com.monsanto.dctm.search.MonSearchInfo;
import com.monsanto.dctm.search.MonSearchService;
import junit.framework.TestCase;

/**
 * Filename:    $RCSfile: MonSearchInfo_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: lakench $
 * On:	$Date: 2007-10-12 05:21:59 $
 *
 * @author lakench
 * @version $Revision: 1.2 $
 */
public class MonSearchInfo_UT extends TestCase {
  public void testCreate() throws Exception {
    MonSearchInfo monSearchInfo = new MonSearchInfo();
    assertTrue(monSearchInfo instanceof SearchInfo);
  }

  public void testGetSearchService() throws Exception {
    ComponentTestUtils.setCurrentDocbase("testdocbase");
    MockMonSearchInfo repositorySearch = new MockMonSearchInfo(new MockSessionManager());
    IDfSearchService searchService = repositorySearch.getSearchService();
    assertTrue(searchService instanceof MonSearchService);

    IDfSearchService searchServiceAgain = repositorySearch.getSearchService();

    assertEquals(searchService, searchServiceAgain);
  }

  public class MockMonSearchInfo extends MonSearchInfo {
    private IDfSessionManager sessionManager;

    public MockMonSearchInfo(IDfSessionManager sessionManager) {
      this.sessionManager = sessionManager;
    }

    protected IDfSessionManager getSessionManager() {
      return sessionManager;
    }
  }
}