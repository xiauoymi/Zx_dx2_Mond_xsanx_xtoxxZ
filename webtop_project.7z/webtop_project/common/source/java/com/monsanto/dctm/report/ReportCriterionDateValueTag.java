/*
 Copyright:  Copyright � 2006 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.report;

import com.documentum.fc.common.DfLogger;
import com.documentum.web.form.control.DateInputTag;
import com.documentum.web.form.control.validator.RequiredFieldValidatorTag;

import javax.servlet.jsp.JspTagException;
import javax.servlet.jsp.JspWriter;
import java.io.IOException;

/**
 * Filename:    $RCSfile: ReportCriterionDateValueTag.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: tsvedan $    	 On:	$Date: 2006-09-25 16:15:22 $
 *
 * @author tsvedan
 * @version $Revision: 1.1 $
 */
public class ReportCriterionDateValueTag extends ReportCriterionValueTag {

  protected void renderValueControl(String name, String value, JspWriter out)
      throws JspTagException, IOException {
    DfLogger.info(this, "name = " + name, null, null);
    ReportCriterionValue reportCriterionValue = (ReportCriterionValue) getControl();
    String strClass = reportCriterionValue.getCssClass();
    String strStyle = reportCriterionValue.getCssStyle();
    DateInputTag dateInput = new DateInputTag();
    dateInput.setPageContext(pageContext);
    dateInput.setParent(this);
    String dateinputName = reportCriterionValue.getElementName("value");
    dateInput.setName(dateinputName);
    dateInput.setId(getId());
    dateInput.setTooltip(reportCriterionValue.getToolTip());
    if (strClass != null) {
      dateInput.setCssclass(strClass);
    }
    if (strStyle != null) {
      dateInput.setStyle(strStyle);
    }
    dateInput.setValue(value);

    dateInput.doStartTag();
    dateInput.doEndTag();
    if(reportCriterionValue.getCriterion().isRequired()) {
      RequiredFieldValidatorTag fieldValidatorTag = new RequiredFieldValidatorTag();
      fieldValidatorTag.setPageContext(pageContext);
      fieldValidatorTag.setParent(this);
      fieldValidatorTag.setName(reportCriterionValue.getElementName("reqfieldvalidator"));
      fieldValidatorTag.setErrormessage("you must specify a value for the \""+
          reportCriterionValue.getCriterion().getLabel() +"\" field");
      fieldValidatorTag.setControltovalidate(dateinputName);
      fieldValidatorTag.doStartTag();
      fieldValidatorTag.doEndTag();
      
    }
  }
}