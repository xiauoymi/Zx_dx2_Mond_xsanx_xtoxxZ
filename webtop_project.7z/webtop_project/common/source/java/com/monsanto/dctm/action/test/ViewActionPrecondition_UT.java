/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.action.test;

import com.documentum.fc.client.IDfPersistentObject;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.IDfSessionManager;
import com.documentum.fc.client.MockSession;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfId;
import com.documentum.web.common.ArgumentList;
import com.documentum.web.form.ComponentTestUtils;
import com.documentum.web.formext.component.Component;
import com.documentum.web.formext.config.Context;
import com.documentum.web.formext.config.IConfigElement;
import com.monsanto.dctm.action.ViewActionPrecondition;
import com.monsanto.dctm.component.test.MockComponent;
import com.monsanto.dctm.component.test.MockSessionManager;
import com.monsanto.dctm.component.test.MockSysObject;
import com.monsanto.dctm.dctmSession.Session;
import com.monsanto.dctm.dctmSession.test.MockDctmSession;
import junit.framework.TestCase;

import java.util.Iterator;

/**
 * Filename:    $RCSfile: ViewActionPrecondition_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: lakench $
 * On:	$Date: 2007-10-12 05:21:59 $
 *
 * @author lakench
 * @version $Revision: 1.2 $
 */
public class ViewActionPrecondition_UT extends TestCase {
  public void testQueryExecuteReturnsTrueWhenSpecifyingContentSizeInArgs() throws Exception {
    ComponentTestUtils.setupConfigService();
    MockSessionManager dfSessionManager = new MockSessionManager();
    MockSession session = new MockSession();
    MockSysObject object = new MockSysObject();
    session.addObject(object, "testobjectid");
    object.setString("r_object_id", "testobjectid");
    object.addRendition("testpdfrendition", "pdf");
    dfSessionManager.setSession(session);
    MockViewActionPrecondition mock = new MockViewActionPrecondition(dfSessionManager, false);
    ArgumentList args = new ArgumentList();
    args.add("objectId", "testobjectid");
    args.add("contentType", "pdf");
    args.add("contentSize", "1");
    Context.getSessionContext().set("clientenv", "webbrowser");
    Context context = new Context();
    context.set("objectId", "testobjectid");
    Component component = ComponentTestUtils
        .getComponent(MockComponent.class, "testcomponent", "testdocbase", dfSessionManager);
    assertTrue(mock.queryExecute("drlview", new MockViewConfig(), args, context, component));
    ComponentTestUtils.releaseComponent(component);
  }

  public void testQueryExecuteReturnsTrueWhenNotSpecifyingContentSizeInArgs() throws Exception {
    ComponentTestUtils.setupConfigService();
    MockSessionManager dfSessionManager = new MockSessionManager();
    MockSession session = new MockSession();
    MockSysObject object = new MockSysObject();
    session.addObject(object, "testobjectid");
    object.setString("r_object_id", "testobjectid");
    object.setContentSize(1);
    object.addRendition("testpdfrendition", "pdf");
    dfSessionManager.setSession(session);
    MockViewActionPrecondition mock = new MockViewActionPrecondition(dfSessionManager, false);
    ArgumentList args = new ArgumentList();
    args.add("objectId", "testobjectid");
    args.add("contentType", "pdf");
    Context.getSessionContext().set("clientenv", "webbrowser");
    Context context = new Context();
    context.set("objectId", "testobjectid");
    Component component = ComponentTestUtils
        .getComponent(MockComponent.class, "testcomponent", "testdocbase", dfSessionManager);
    assertTrue(mock.queryExecute("drlview", new MockViewConfig(), args, context, component));
    ComponentTestUtils.releaseComponent(component);
  }

  public void testQueryExecuteReturnsFalseWhenContentSizeIsNotValid() throws Exception {
    ComponentTestUtils.setupConfigService();
    MockSessionManager dfSessionManager = new MockSessionManager();
    MockSession session = new MockSession();
    MockSysObject object = new MockSysObject();
    session.addObject(object, "testobjectid");
    object.setString("r_object_id", "testobjectid");
    object.setContentSize(0);
    object.addRendition("testpdfrendition", "pdf");
    dfSessionManager.setSession(session);
    MockViewActionPrecondition mock = new MockViewActionPrecondition(dfSessionManager, false);
    ArgumentList args = new ArgumentList();
    args.add("objectId", "testobjectid");
    args.add("contentType", "pdf");
    Context.getSessionContext().set("clientenv", "webbrowser");
    Context context = new Context();
    context.set("objectId", "testobjectid");
    Component component = ComponentTestUtils
        .getComponent(MockComponent.class, "testcomponent", "testdocbase", dfSessionManager);
    assertFalse(mock.queryExecute("drlview", new MockViewConfig(), args, context, component));
    ComponentTestUtils.releaseComponent(component);
  }

  public void testQueryExecuteReturnsFalseWhenContentSizeIsNotValidFromArgs() throws Exception {
    ComponentTestUtils.setupConfigService();
    MockSessionManager dfSessionManager = new MockSessionManager();
    MockSession session = new MockSession();
    MockSysObject object = new MockSysObject();
    session.addObject(object, "testobjectid");
    object.setString("r_object_id", "testobjectid");
    object.addRendition("testpdfrendition", "pdf");
    dfSessionManager.setSession(session);
    MockViewActionPrecondition mock = new MockViewActionPrecondition(dfSessionManager, false);
    ArgumentList args = new ArgumentList();
    args.add("objectId", "testobjectid");
    args.add("contentType", "pdf");
    args.add("contentSize", "0");
    Context.getSessionContext().set("clientenv", "webbrowser");
    Context context = new Context();
    context.set("objectId", "testobjectid");
    Component component = ComponentTestUtils
        .getComponent(MockComponent.class, "testcomponent", "testdocbase", dfSessionManager);
    assertFalse(mock.queryExecute("drlview", new MockViewConfig(), args, context, component));
    ComponentTestUtils.releaseComponent(component);
  }

  public void testContentTypeIsAddedToArgsOnQueryExecute() throws Exception {
    ComponentTestUtils.setupConfigService();
    MockSessionManager dfSessionManager = new MockSessionManager();
    MockSession session = new MockSession();
    MockSysObject object = new MockSysObject();
    session.addObject(object, "testobjectid");
    object.setString("r_object_id", "testobjectid");
    object.setContentType("pdf");
    object.addRendition("testpdfrendition", "pdf");
    dfSessionManager.setSession(session);
    MockViewActionPrecondition mock = new MockViewActionPrecondition(dfSessionManager, false);
    ArgumentList args = new ArgumentList();
    args.add("objectId", "testobjectid");
    args.add("contentSize", "1");
    Context.getSessionContext().set("clientenv", "webbrowser");
    Context context = new Context();
    context.set("objectId", "testobjectid");
    Component component = ComponentTestUtils
        .getComponent(MockComponent.class, "testcomponent", "testdocbase", dfSessionManager);
    assertTrue(mock.queryExecute("drlview", new MockViewConfig(), args, context, component));
    assertEquals("pdf", mock.args.get("contentType"));
    ComponentTestUtils.releaseComponent(component);
  }


  class MockViewActionPrecondition extends ViewActionPrecondition {
    public ArgumentList args;
    private IDfSessionManager dfSessionManager;
    private boolean superQueryExecuteReturns;

    public MockViewActionPrecondition(IDfSessionManager dfSessionManager, boolean superQueryExecuteReturns) {
      this.dfSessionManager = dfSessionManager;
      this.superQueryExecuteReturns = superQueryExecuteReturns;
    }

    /**
     * @noinspection RefusedBequest
     */
    protected Session createSession() {
      return new MockDctmSession(dfSessionManager, "testdocbase");
    }

    public boolean queryExecute(String strAction, IConfigElement config, ArgumentList args, Context context,
                                Component component) {
      boolean result = super.queryExecute(strAction, config, args, context, component);
      this.args = args;
      return result;
    }

    /**
     * @noinspection RefusedBequest
     */
    protected boolean callSuperQueryExecute(String strAction, IConfigElement config, ArgumentList args, Context context,
                                            Component component) {
      return superQueryExecuteReturns;
    }

    /**
     * @noinspection RefusedBequest
     */
    protected IDfPersistentObject getSysObjectFromCache(IDfSession dfSession, String strObjectId) throws
        DfException {
      return dfSession.getObject(new DfId(strObjectId));
    }
  }

  public class MockViewConfig implements IConfigElement {
    public String getName() {
      return null;
    }

    public IConfigElement getParent() {
      return null;
    }

    public void setParent(IConfigElement iConfigElement) {
    }

    public String getValue() {
      return null;
    }

    public Boolean getValueAsBoolean() {
      return null;
    }

    public Integer getValueAsInteger() {
      return null;
    }

    public String getAttributeValue(String attrName) {
      return null;
    }

    public Boolean getAttributeValueAsBoolean(String attrName) {
      return null;
    }

    public Integer getAttributeValueAsInteger(String attrName) {
      return null;
    }

    public void setAttributeValue(String attrName, String attrName1) {
    }

    public void setAttributeValue(String attrName, boolean b) {
    }

    public void setAttributeValue(String attrName, int i) {
    }

    public Iterator getAttributeNames() {
      return null;
    }

    public Iterator getChildElements() {
      return null;
    }

    public Iterator getChildElements(String attrName) {
      return null;
    }

    public IConfigElement getChildElement(String attrName) {
      return null;
    }

    public String getChildValue(String attrName) {
      return null;
    }

    public Boolean getChildValueAsBoolean(String attrName) {
      return null;
    }

    public Integer getChildValueAsInteger(String attrName) {
      return null;
    }

    public IConfigElement getDescendantElement(String attrName) {
      return null;
    }

    public String getDescendantValue(String attrName) {
      return null;
    }

    public Boolean getDescendantValueAsBoolean(String attrName) {
      return null;
    }

    public Integer getDescendantValueAsInteger(String attrName) {
      return null;
    }

    public void addChildElement(IConfigElement iConfigElement) {
    }
  }
}