/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.search.test;

import java.io.ByteArrayInputStream;
import java.io.UnsupportedEncodingException;

/**
 * Filename:    $RCSfile: SearchTestUtils.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: lakench $
 * On:	$Date: 2007-11-19 22:05:22 $
 *
 * @author lakench
 * @version $Revision: 1.2 $
 */
public class SearchTestUtils {

  public static ByteArrayInputStream generateQueryBuilderStream() throws UnsupportedEncodingException {
    String content = "<SmartListDefinition>" +
        "<QueryBuilder allVersions=\"false\" hiddenObjects=\"false\" isDatabaseSearchRequested=\"false\" maxResults=\"-1\" objectType=\"dm_document\">" +
        "<SourceList>" +
        "<Source description=\"\" name=\"testdocbase\" serverVersion=\"5.2.5.514 SP5 HPUX.Oracle\" type=\"docbase\" />" +
        "</SourceList>" +
        "<QueryScopeList />" +
        "<ExpressionSet logicalOperator=\"AND\" />" +
        "<ResultAttributeList>" +
        "<ResultAttribute name=\"object_name\" />" +
        "<ResultAttribute name=\"r_object_type\" />" +
        "<ResultAttribute name=\"r_lock_owner\" />" +
        "<ResultAttribute name=\"owner_name\" />" +
        "<ResultAttribute name=\"r_link_cnt\" />" +
        "<ResultAttribute name=\"r_is_virtual_doc\" />" +
        "<ResultAttribute name=\"r_content_size\" />" +
        "<ResultAttribute name=\"a_content_type\" />" +
        "<ResultAttribute name=\"i_is_reference\" />" +
        "<ResultAttribute name=\"r_assembled_from_id\" />" +
        "<ResultAttribute name=\"r_has_frzn_assembly\" />" +
        "<ResultAttribute name=\"a_compound_architecture\" />" +
        "<ResultAttribute name=\"i_is_replica\" />" +
        "<ResultAttribute name=\"r_policy_id\" />" +
        "<ResultAttribute name=\"r_modify_date\" />" +
        "</ResultAttributeList>" +
        "</QueryBuilder>" +
        "<DisplayPreferences>" +
        "<DisplayAttributeList>" +
        "<DisplayAttribute name=\"object_name\" />" +
        "<DisplayAttribute name=\"score\" />" +
        "<DisplayAttribute name=\"a_content_type\" />" +
        "<DisplayAttribute name=\"r_content_size\" />" +
        "<DisplayAttribute name=\"r_modify_date\" />" +
        "<DisplayAttribute name=\"r_lock_owner\" />" +
        "<DisplayAttribute name=\"summary\" />" +
        "</DisplayAttributeList>" +
        "</DisplayPreferences>" +
        "<PropertyList>" +
        "<Property name=\"testproperty\" value=\"testvalue\" />" +
        "</PropertyList>" +
        "</SmartListDefinition>";
    return new ByteArrayInputStream(content.getBytes("UTF-8"));
  }

  public static ByteArrayInputStream generateQueryBuilderStreamWithoutMaxResults(
      String isDatabaseSearchRequested) throws UnsupportedEncodingException {
    String content = "<SmartListDefinition>" +
        "<QueryBuilder allVersions=\"false\" hiddenObjects=\"false\" isDatabaseSearchRequested=" +
        isDatabaseSearchRequested + " objectType=\"dm_document\">" +
        "<SourceList>" +
        "<Source description=\"\" name=\"testdocbase\" serverVersion=\"5.2.5.514 SP5 HPUX.Oracle\" type=\"docbase\" />" +
        "</SourceList>" +
        "<QueryScopeList />" +
        "<ExpressionSet logicalOperator=\"AND\" />" +
        "<ResultAttributeList>" +
        "<ResultAttribute name=\"object_name\" />" +
        "<ResultAttribute name=\"r_object_type\" />" +
        "<ResultAttribute name=\"r_lock_owner\" />" +
        "<ResultAttribute name=\"owner_name\" />" +
        "<ResultAttribute name=\"r_link_cnt\" />" +
        "<ResultAttribute name=\"r_is_virtual_doc\" />" +
        "<ResultAttribute name=\"r_content_size\" />" +
        "<ResultAttribute name=\"a_content_type\" />" +
        "<ResultAttribute name=\"i_is_reference\" />" +
        "<ResultAttribute name=\"r_assembled_from_id\" />" +
        "<ResultAttribute name=\"r_has_frzn_assembly\" />" +
        "<ResultAttribute name=\"a_compound_architecture\" />" +
        "<ResultAttribute name=\"i_is_replica\" />" +
        "<ResultAttribute name=\"r_policy_id\" />" +
        "<ResultAttribute name=\"r_modify_date\" />" +
        "</ResultAttributeList>" +
        "</QueryBuilder>" +
        "<DisplayPreferences>" +
        "<DisplayAttributeList>" +
        "<DisplayAttribute name=\"object_name\" />" +
        "<DisplayAttribute name=\"score\" />" +
        "<DisplayAttribute name=\"a_content_type\" />" +
        "<DisplayAttribute name=\"r_content_size\" />" +
        "<DisplayAttribute name=\"r_modify_date\" />" +
        "<DisplayAttribute name=\"r_lock_owner\" />" +
        "<DisplayAttribute name=\"summary\" />" +
        "</DisplayAttributeList>" +
        "</DisplayPreferences>" +
        "<PropertyList />" +
        "</SmartListDefinition>";
    return new ByteArrayInputStream(content.getBytes("UTF-8"));
  }

  public static ByteArrayInputStream generatePassThroughStream() throws UnsupportedEncodingException {
    String content = "<SmartListDefinition>" +
        "<PassThroughQuery maxResults=\"-1\">" +
        "<SourceList>" +
        "<Source description=\"\" name=\"testdocbase\" serverVersion=\"5.2.5.514 SP5 HPUX.Oracle\" type=\"docbase\" />" +
        "</SourceList>" +
        "<QueryString>select r_object_id from test_object_type</QueryString>" +
        "<QueryData>not sure what this is but the code allows another text node here</QueryData>" +
        "</PassThroughQuery>" +
        "<DisplayPreferences>" +
        "<DisplayAttributeList>" +
        "<DisplayAttribute name=\"object_name\" />" +
        "<DisplayAttribute name=\"score\" />" +
        "<DisplayAttribute name=\"a_content_type\" />" +
        "<DisplayAttribute name=\"r_content_size\" />" +
        "<DisplayAttribute name=\"r_modify_date\" />" +
        "<DisplayAttribute name=\"r_lock_owner\" />" +
        "<DisplayAttribute name=\"summary\" />" +
        "</DisplayAttributeList>" +
        "</DisplayPreferences>" +
        "<PropertyList />" +
        "</SmartListDefinition>";
    return new ByteArrayInputStream(content.getBytes("UTF-8"));
  }

  public static ByteArrayInputStream generateInvalidStream() throws UnsupportedEncodingException {
    String content = "<SmartListDefinition>" +
        "<BadSmartListDef>" +
        "</BadSmartListDef>" +
        "</SmartListDefinition>";
    return new ByteArrayInputStream(content.getBytes("UTF-8"));
  }

  public static ByteArrayInputStream generateQueryBuilderStreamWithCorrelatedQueryExpression() throws
      UnsupportedEncodingException {
    String content = "<SmartListDefinition>" +
        "<QueryBuilder allVersions=\"false\" hiddenObjects=\"false\" isDatabaseSearchRequested=\"false\" maxResults=\"-1\" objectType=\"dm_document\">" +
        "<SourceList>" +
        "<Source description=\"\" name=\"testdocbase\" serverVersion=\"5.2.5.514 SP5 HPUX.Oracle\" type=\"docbase\"/>" +
        "</SourceList>" +
        "<QueryScopeList/>" +
        "<ExpressionSet logicalOperator=\"AND\">" +
        "<ExpressionSet logicalOperator=\"AND\"/>" +
        "<ExpressionSet logicalOperator=\"AND\"/>" +
        "<CorrelatedQueryExpression attribute=\"i_chronicle_id\" caseSensitive=\"true\" dataType=\"string\" repeated=\"false\" searchOperation=\"in\">select distinct component_id from dmr_containment cont, dm_document doc where cont.parent_id = doc.r_object_id and cont.component_id != doc.i_chronicle_id</CorrelatedQueryExpression>" +
        "</ExpressionSet>" +
        "<ResultAttributeList>" +
        "<ResultAttribute name=\"object_name\"/>" +
        "<ResultAttribute name=\"r_object_type\"/>" +
        "<ResultAttribute name=\"r_lock_owner\"/>" +
        "<ResultAttribute name=\"owner_name\"/>" +
        "<ResultAttribute name=\"r_link_cnt\"/>" +
        "<ResultAttribute name=\"r_is_virtual_doc\"/>" +
        "<ResultAttribute name=\"r_content_size\"/>" +
        "<ResultAttribute name=\"a_content_type\"/>" +
        "<ResultAttribute name=\"i_is_reference\"/>" +
        "<ResultAttribute name=\"r_assembled_from_id\"/>" +
        "<ResultAttribute name=\"r_has_frzn_assembly\"/>" +
        "<ResultAttribute name=\"a_compound_architecture\"/>" +
        "<ResultAttribute name=\"i_is_replica\"/>" +
        "<ResultAttribute name=\"r_policy_id\"/>" +
        "<ResultAttribute name=\"date_of_document\"/>" +
        "<ResultAttribute name=\"authors\"/>" +
        "<ResultAttribute name=\"recipient\"/>" +
        "<ResultAttribute name=\"r_modify_date\"/>" +
        "</ResultAttributeList>" +
        "</QueryBuilder>" +
        "<DisplayPreferences>" +
        "<DisplayAttributeList>" +
        "<DisplayAttribute name=\"date_of_document\"/>" +
        "<DisplayAttribute name=\"object_name\"/>" +
        "<DisplayAttribute name=\"authors\"/>" +
        "<DisplayAttribute name=\"recipient\"/>" +
        "<DisplayAttribute name=\"a_content_type\"/>" +
        "<DisplayAttribute name=\"r_content_size\"/>" +
        "<DisplayAttribute name=\"r_modify_date\"/>" +
        "<DisplayAttribute name=\"r_lock_owner\"/>" +
        "<DisplayAttribute name=\"summary\"/>" +
        "</DisplayAttributeList>" +
        "</DisplayPreferences>" +
        "<PropertyList/>" +
        "</SmartListDefinition>";
    return new ByteArrayInputStream(content.getBytes("UTF-8"));
  }
}