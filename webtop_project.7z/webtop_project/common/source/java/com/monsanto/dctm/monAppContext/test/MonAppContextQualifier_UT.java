/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.monAppContext.test;

import com.monsanto.dctm.monAppContext.MonAppContextQualifier;
import com.documentum.web.formext.config.Context;
import com.documentum.web.formext.config.QualifierContext;
import com.documentum.web.formext.config.QualifierTestUtils;
import junit.framework.TestCase;

/**
 * Filename:    $RCSfile: MonAppContextQualifier_UT.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: lakench $    	 On:	$Date: 2007-03-06 16:04:34 $
 *
 * @author LAKENCH
 * @version $Revision: 1.2 $
 */
public class MonAppContextQualifier_UT extends TestCase {
    private MonAppContextQualifier monAppContextQualifier;
    private Context context;
    private QualifierContext qualifierContext;

    protected void setUp() throws Exception {
        super.setUp();
        context = new Context();
        qualifierContext = QualifierTestUtils.getQualifierContext(context);
        monAppContextQualifier = new MonAppContextQualifier();
    }

    protected void tearDown() throws Exception {
        super.tearDown();
    }

    public void testGetScopeName() throws Exception {
        assertEquals("scope name wrong", "mon_app_context", monAppContextQualifier.getScopeName());
    }

    public void testGetScopeValue() throws Exception {
        context.set("mon_app_context", "test mon app context");
        String actualScopeValue = monAppContextQualifier.getScopeValue(qualifierContext);
        assertEquals("bad scope value", "test mon app context", actualScopeValue);
    }

    public void testGetParentScopeValue() throws Exception {
        assertNull("parent scope value wrong", monAppContextQualifier.getParentScopeValue("test"));
    }

    public void testAliasScopeValues() throws Exception {
        assertNull("alias scope values wrong", monAppContextQualifier.getAliasScopeValues("test"));
    }

    public void testGetContextNames() throws Exception {
        String[] expectedContextNames = new String[]{"mon_app_context"};
        String[] actualContextNames = monAppContextQualifier.getContextNames();
        assertEquals("context names wrong size", expectedContextNames.length, actualContextNames.length);
        assertEquals("context names wrong", expectedContextNames[0], actualContextNames[0]);
    }
}