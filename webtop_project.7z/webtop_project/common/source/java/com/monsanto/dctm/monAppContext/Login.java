/*
 * Created on Sep 2, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.dctm.monAppContext;

import com.documentum.web.common.ArgumentList;
import com.documentum.web.form.control.DropDownList;
import com.documentum.web.form.control.databound.ArrayResultSet;
import com.documentum.web.form.control.databound.DataDropDownList;

/**
 * @author LAKENCH
 */
public class Login extends com.documentum.web.formext.session.Login {

    public static final String CONTROL_MON_APP_CONTEXT = "mon_app_context";

    public void onInit(ArgumentList args) {
        super.onInit(args);
        initMonAppContextDropdown();
    }

    protected void initMonAppContextDropdown() {
        updateMonAppContextControl();
    }

    protected void updateMonAppContextControl() {
        IMonAppContextService monAppContextService = MonAppContextService
                .getMonAppContextService(getCurrentlySelectedDocbase());
        DataDropDownList monAppContextControl = ((DataDropDownList) getControl(CONTROL_MON_APP_CONTEXT,
                                                                               DataDropDownList.class));
        monAppContextControl.getDataProvider().setScrollableResultSet(
                new ArrayResultSet(monAppContextService.getSupportedMonAppContexts(), "mon_app_context"));
        ((DataDropDownList) getControl(CONTROL_MON_APP_CONTEXT, DataDropDownList.class))
                .setValue(monAppContextService.getCurrentMonAppContextName());
    }

    protected String getCurrentlySelectedDocbase() {
        return ((DataDropDownList) getControl("docbase", DataDropDownList.class)).getValue();
    }

    public void onSelectDocbaseFromDropDown(DropDownList docbase, ArgumentList arg) {
        super.onSelectDocbaseFromDropDown(docbase, arg);
        updateMonAppContextControl();
    }

    protected void handleSuccess() {
        updateMonAppContext();
        super.handleSuccess();
    }

    protected void updateMonAppContext() {
        IMonAppContextService monAppContextService = MonAppContextService
                .getMonAppContextService(getCurrentlySelectedDocbase());
        String strMonAppContext = ((DataDropDownList) getControl(CONTROL_MON_APP_CONTEXT, DataDropDownList.class))
                .getValue();
        monAppContextService.setMonAppContext(strMonAppContext);
    }
}
