package com.monsanto.dctm.report;

import com.documentum.web.form.control.StringInputControl;

public class ReportCriterionLabel extends StringInputControl {
	
	private Criterion criterion;

	public ReportCriterionLabel() {
		criterion = null;
	}

	public Criterion getCriterion() {
		return criterion;
	}

	public void setCriterion(Criterion criterion) {
		this.criterion = criterion;
	}
	
	protected String getCriterionLabel() {
		return criterion.getLabel();
	}
}
