/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.dctmSession;

import com.documentum.fc.client.DfAuthenticationException;
import com.documentum.fc.client.DfServiceException;
import com.documentum.web.formext.session.SessionManagerHttpBinding;

/**
 * Filename:    $RCSfile: DctmSession.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: lakench $    	 On:	$Date: 2007-03-30 20:58:38 $
 *
 * @author lakench
 * @version $Revision: 1.3 $
 */
public class DctmSession implements Session {
    public SessionInstance getNewSession() throws DfServiceException, DfAuthenticationException {
        return new DocumentumSessionInstance(SessionManagerHttpBinding.getSessionManager(),
                                             SessionManagerHttpBinding.getCurrentDocbase());
    }
}