/*
 Copyright:  Copyright � 2006 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.directed;

import com.documentum.web.common.ArgumentList;
import com.documentum.web.formext.component.Component;

/**
 * Filename:    $RCSfile: MySearch.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: lakench $    	 On:	$Date: 2006-12-14 21:32:30 $
 *
 * @author lakench
 * @version $Revision: 1.6 $
 */
public class MySearch extends Component {
    public void onRender() {
        String queryId = getQueryId();
        if (queryId != null) {
            ArgumentList list = new ArgumentList();
            list.add("query", queryId);
            list.add("queryType", "queryId");
            list.add("drilldown", "false");
            setComponentJump("directed_search", list, getContext());
        } else {
            ArgumentList list = new ArgumentList();
            list.add("component", "directed_advsearch");
            list.add("type", "dm_sysobject");
            setComponentNested("directed_advsearchcontainer", list, getContext(), null);
        }
    }

    private String getQueryId() {
        String queryId = null;
        String context = getContext().toString();
        if (context.indexOf("queryId") > 0) {
            queryId = context
                    .substring(context.indexOf("queryId") + 8, context.indexOf(")", context.indexOf("queryId")));
            if (queryId.indexOf(",") > 0)
                queryId = queryId.substring(0, queryId.indexOf(","));
            return queryId;
        }
        return null;
    }

}