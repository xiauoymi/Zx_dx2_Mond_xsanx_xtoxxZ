package com.monsanto.dctm.streamline;

import com.monsanto.dctm.monAppContext.MonAppContextService;
import com.monsanto.dctm.viewprocessor.BookmarkLink;

public class StreamlineView extends
                            com.documentum.webtop.webcomponent.streamline.StreamlineView {

    protected void updateControlsFromPath(String strFolderPath) {
        getControl(CONTROL_BOOKMARK, BookmarkLink.class);
        super.updateControlsFromPath(strFolderPath);
    }

    protected String getColumnsPreferenceId() {
        return super.getColumnsPreferenceId() + "." +
               MonAppContextService.getMonAppContextService().getMonAppContextInternalName();
    }

}
