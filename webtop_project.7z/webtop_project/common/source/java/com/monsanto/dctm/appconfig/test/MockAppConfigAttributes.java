/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.appconfig.test;

import com.documentum.fc.client.DfServiceException;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.IDfSessionManager;
import com.documentum.fc.common.DfException;
import com.documentum.web.common.ArgumentList;
import com.documentum.web.form.Control;
import com.monsanto.dctm.appconfig.AppConfigAttributes;
import com.monsanto.dctm.component.test.IMonTestableComponent;
import com.monsanto.dctm.component.test.MockTypedObject;
import com.monsanto.dctm.component.test.MockTypedObjectContainer;

/**
 * Filename:    $RCSfile: MockAppConfigAttributes.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: lakench $    	 On:	$Date: 2007-08-24 21:29:43 $
 *
 * @author lakench
 * @version $Revision: 1.2 $
 */
public class MockAppConfigAttributes extends AppConfigAttributes implements IMonTestableComponent {
  private IDfSessionManager sessionManager;

  protected void patchObjectIdFromTypedObjectContainer(ArgumentList argumentList) {
    super.patchObjectIdFromTypedObjectContainer(argumentList);
  }

  public Control getContainer() {
    MockTypedObject mockTypedObject = new MockTypedObject();
    try {
      mockTypedObject.setString("r_object_id", "test object id");
      mockTypedObject.setString("object_name", "testappcontext");

    } catch (DfException e) {
      e.printStackTrace();
    }
    return new MockTypedObjectContainer(mockTypedObject);
  }

  /**
   * @noinspection RefusedBequest
   */
  public IDfSession getDfSession(int i) {
    try {
      return sessionManager.getSession(getCurrentDocbase());
    } catch (DfServiceException e) {
      e.printStackTrace();
    }
    return null;
  }

  public void setSessionManager(IDfSessionManager sessionManager) {
    this.sessionManager = sessionManager;
  }

  public IDfSessionManager getSessionManager() {
    return sessionManager;
  }
}