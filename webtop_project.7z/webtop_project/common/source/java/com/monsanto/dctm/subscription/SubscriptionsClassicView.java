package com.monsanto.dctm.subscription;

import com.monsanto.dctm.monAppContext.MonAppContextService;

public class SubscriptionsClassicView
        extends
        com.documentum.webtop.webcomponent.subscription.SubscriptionsClassicView {

    protected String getColumnsPreferenceId() {
        return super.getColumnsPreferenceId() + "." +
               MonAppContextService.getMonAppContextService().getMonAppContextInternalName();
    }

}
