package com.monsanto.dctm.discussion;

public class TopicPageView extends com.documentum.webtop.webcomponent.discussion.TopicPageView 
{

	protected void updateBookmark() {
		getControl("comments_bookmark", com.monsanto.dctm.viewprocessor.BookmarkLink.class);
		super.updateBookmark();
	}

}
