/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.autoLogin.test;

import com.documentum.web.common.ArgumentList;
import com.documentum.web.common.ResourceFileUtil;
import com.documentum.web.formext.config.ConfigService;
import com.monsanto.dctm.component.test.MockConfigReader;
import com.monsanto.dctm.component.test.MockHttpServletRequest;
import com.monsanto.dctm.component.test.MockServletContext;
import junit.framework.TestCase;

/**
 * Filename:    $RCSfile: AutoLoginAuthenticationScheme_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author:
 * lakench $    	 On:	$Date: 2007-07-31 18:51:49 $
 *
 * @author LAKENCH
 * @version $Revision: 1.1 $
 */
public class AutoLoginAuthenticationScheme_UT extends TestCase {
  private MockAutoLoginAuthenticationScheme autoLoginAuthenticationScheme;
  private MockDocbaseMap testDocbaseMap;

  protected void setUp() throws Exception {
    super.setUp();
    ResourceFileUtil.setLookupContext(new MockServletContext(), null);
    ConfigService.setConfigReader(new MockConfigReader());
    autoLoginAuthenticationScheme = new MockAutoLoginAuthenticationScheme();
    MockAutoLoginResourceBundle credentialsList = new MockAutoLoginResourceBundle();
    Object[][] credentialsListContents = new Object[][]{
        {"test$primary", "testdocbase,testuserid,testpassword,testdomain"},
        {"test$secondary", "test2docbase,test2userid,test2password,test2domain"}
    };
    credentialsList.setContents(credentialsListContents);
    autoLoginAuthenticationScheme.setMockResourceBundle(credentialsList);
    testDocbaseMap = new MockDocbaseMap();
    autoLoginAuthenticationScheme.setMockDocbaseMap(testDocbaseMap);

  }

  protected void tearDown() throws Exception {
    super.tearDown();
  }

  public void testAuthenticate() throws Exception {
    testDocbaseMap.addDocbase("12345", "testdocbase", "Test Docbase Description");
    MockHttpServletRequest request = new MockHttpServletRequest();
    request.setRequestURI("http://localhost:8080/webtop/component/test");
    String actualDocbase = autoLoginAuthenticationScheme.authenticate(request, null, null);
    assertEquals("authenticated to wrong docbase", "testdocbase", actualDocbase);
  }

  public void testGetLoginComponent() throws Exception {
    assertNull("login component not null", autoLoginAuthenticationScheme.getLoginComponent(
        new MockHttpServletRequest(), null, "testdocbase", new ArgumentList()));
  }

  public void testGetCallingComponentName() throws Exception {
    MockHttpServletRequest request = new MockHttpServletRequest();
    request.setRequestURI("http://localhost:8080/webtop/component/test");
    assertEquals("wrong calling component name", "test",
        autoLoginAuthenticationScheme.getCallingComponentName(request));
  }
}