package com.monsanto.dctm.category;

import com.monsanto.dctm.monAppContext.MonAppContextService;

public class CategoryClassicView extends
                                 com.documentum.webtop.webcomponent.category.CategoryClassicView {

    protected String getColumnsPreferenceId() {

        return super.getColumnsPreferenceId() + "." +
               MonAppContextService.getMonAppContextService().getMonAppContextInternalName();
    }


}
