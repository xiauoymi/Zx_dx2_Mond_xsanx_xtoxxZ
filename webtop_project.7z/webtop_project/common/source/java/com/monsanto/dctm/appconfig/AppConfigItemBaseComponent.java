/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.appconfig;

import com.documentum.fc.client.IDfTypedObject;
import com.documentum.fc.common.DfException;
import com.documentum.web.common.ArgumentList;
import com.documentum.web.common.WrapperRuntimeException;
import com.documentum.web.form.control.databound.Datagrid;
import com.documentum.web.formext.action.IActionCompleteListener;
import com.documentum.web.formext.component.Component;
import com.documentum.webcomponent.admin.container.ITypedObjectContainer;
import com.monsanto.dctm.component.ListBasedColumnDescriptorList;

import java.util.Map;

/**
 * Filename:    $RCSfile: AppConfigItemBaseComponent.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: lakench $    	 On:	$Date: 2007-08-21 05:23:14 $
 *
 * @author lakench
 * @version $Revision: 1.1 $
 */
public class AppConfigItemBaseComponent extends Component implements IActionCompleteListener {
  public static final String MULTISELECT_CONTROL = "multiselectcontrol";
  public static final String REALLY_DELETE = "reallydelete";
  public static final String APP_CONFIG_ITEM = "appConfigItem";
  public static final String REALLY_ADD = "reallyadd";
  public static final String CONTROL_GRID = "requestorgrid";
  public static final String APP_CONFIG_ITEM_TYPE = "appConfigItemType";

  private AppConfigItemWorkingSet appConfigItemWorkingSet;

  protected String getAppConfigItemType() {
    // This is only here because lookupString is final
    return lookupString(APP_CONFIG_ITEM_TYPE);
  }

  public void onInit(ArgumentList argumentList) {
    super.onInit(argumentList);
    setupComponent();
  }

  protected void setupComponent() {
    IDfTypedObject appConfigObject = ((ITypedObjectContainer) getContainer()).getDfTypedObject();
    try {
      appConfigItemWorkingSet = AppConfigItemWorkingSet.createAppConfigItemWorkingSet(
          appConfigObject.getString("object_name"), getDfSession(), getAppConfigItemType());
    } catch (DfException e) {
      throw new WrapperRuntimeException("couldn't initialize requestors", e);
    }
    initDatagrid();
  }

  public boolean onCommitChanges() {
    try {
      appConfigItemWorkingSet.save();
    } catch (DfException e) {
      throw new WrapperRuntimeException("couldn't save requestors", e);
    }
    return super.onCommitChanges();
  }

  public void onComplete(String strAction, boolean bSuccess, Map completionArgs) {
    if (strAction.equals(appConfigItemWorkingSet.getDeleteActionName())) {
      if (Boolean.valueOf((String) completionArgs.get(REALLY_DELETE)).booleanValue()) {
        appConfigItemWorkingSet.removeAppConfigItem((AppConfigItem) completionArgs.get(APP_CONFIG_ITEM));
      }
    } else {
      if (Boolean.valueOf((String) completionArgs.get(REALLY_ADD)).booleanValue()) {
        AppConfigItem requestor = (AppConfigItem) completionArgs.get(APP_CONFIG_ITEM);
        appConfigItemWorkingSet.addAppConfigItem(requestor);
      }
    }
    refreshDatagridData();
  }

  private void initDatagrid() {
    getControl(CONTROL_GRID, Datagrid.class);
    addControlListener(new ListBasedColumnDescriptorList(CONTROL_GRID, appConfigItemWorkingSet.getColumnNames()));
    refreshDatagridData();
  }

  private void refreshDatagridData() {
    Datagrid requestorGrid = (Datagrid) getControl(CONTROL_GRID);
    requestorGrid.getDataProvider().setScrollableResultSet(appConfigItemWorkingSet.getResultSet());
  }
}