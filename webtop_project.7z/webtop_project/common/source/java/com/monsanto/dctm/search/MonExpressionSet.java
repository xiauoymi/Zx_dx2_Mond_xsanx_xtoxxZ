package com.monsanto.dctm.search;

import com.documentum.fc.client.DfIteratorWrapper;
import com.documentum.fc.client.IDfEnumeration;
import com.documentum.fc.client.search.DfSearchException;
import com.documentum.fc.client.search.IDfExpressionSet;
import com.documentum.fc.client.search.IDfSimpleAttrExpression;
import com.documentum.fc.client.search.impl.DfXMLUtil;
import com.documentum.fc.client.search.impl.DfExpressionSet;
import com.documentum.fc.client.search.impl.DfValueListAttrExpression;
import com.documentum.fc.client.search.impl.DfExpression;
import com.documentum.fc.client.search.impl.DfFullTextExpression;
import com.documentum.fc.client.search.impl.DfValueRangeAttrExpression;

import com.documentum.tracing.core.Parameter;
import com.documentum.tracing.tracer.DfTracer;
import org.w3c.dom.Node;

import java.util.ArrayList;
import java.util.List;

public class MonExpressionSet extends DfExpressionSet {

  private List m_expressions;

  public MonExpressionSet(String dateFormat) {
    super(dateFormat);
    m_expressions = new ArrayList(10);
  }

  public MonExpressionSet(String dateFormat, int logicalOperator) {
    super(dateFormat, logicalOperator);
    m_expressions = new ArrayList(10);
  }

  public MonExpressionSet(Node node) throws DfSearchException {
    this("MM/dd/yyyy HH:mm:ss");
    Throwable __TRACER_EXCEPTION__ = null;
    try {
      if (DfTracer.s_globalTraceEnabled && DfTracer.isEnabled()) {
        Parameter __TRACER_PARAMETERS__[] = new Parameter[1];
        __TRACER_PARAMETERS__[0] = new Parameter(node, "node", "Node");
        DfTracer.traceMethodEntrance("<init>", 65, __TRACER_PARAMETERS__,
            com.documentum.fc.client.search.impl.DfExpressionSet.class, this, null);
      }
      String xmlLogicalOp = DfXMLUtil.getAttribute(node, "logicalOperator", true);
      int logicalOp = DfXMLUtil.convertXMLToLogicalOp(xmlLogicalOp);
      setLogicalOperator(logicalOp);
      Node exprs[] = DfXMLUtil.getChildNodes(node, null, false);
      for (int i = 0; i < exprs.length; i++) {
        Node exprNode = exprs[i];
        String exprName = exprNode.getNodeName();
        DfExpression expr = null;
        if (exprName.equals("ExpressionSet"))
          expr = new MonExpressionSet(exprNode);
        else if (exprName.equals("FulltextExpression"))
          expr = new DfFullTextExpression(exprNode);
        else if (exprName.equals("SimpleAttributeExpression"))
          expr = new MonSimpleAttrExpression(exprNode);
        else if (exprName.equals("ValueListAttributeExpression"))
          expr = new DfValueListAttrExpression(exprNode);
        else if (exprName.equals("ValueRangeAttributeExpression"))
          expr = new DfValueRangeAttrExpression(exprNode);
        else if (exprName.equals("CorrelatedQueryExpression"))
          expr = new MonCorrelatedQueryExpression(exprNode);
        else
          DfXMLUtil.throwXMLFormatError("<" + exprName + ">");
        m_expressions.add(expr);
      }

    }
    catch (Throwable __exception__) {
      __TRACER_EXCEPTION__ = __exception__;
      if (__exception__ instanceof DfSearchException)
        throw (DfSearchException) __exception__;
      if (__exception__ instanceof Error)
        throw (Error) __exception__;
      else
        throw (RuntimeException) __exception__;
    }
    finally {
      if (DfTracer.s_globalTraceEnabled && DfTracer.isEnabled())
        DfTracer.traceMethodExit(getClass().getName(), 65, getClass(), this, __TRACER_EXCEPTION__);
    }
  }

  public int getExpressionCount() {
    return m_expressions.size() + super.getExpressionCount();
  }

  public IDfEnumeration getExpressions() {
    IDfEnumeration theseExpressions = new DfIteratorWrapper(m_expressions.iterator());
    IDfEnumeration thoseExpressions = super.getExpressions();
    List allExpressions = new ArrayList(20);
    while (thoseExpressions.hasMoreElements()) {
      allExpressions.add(thoseExpressions.nextElement());
    }
    while (theseExpressions.hasMoreElements()) {
      allExpressions.add(theseExpressions.nextElement());
    }

    return new DfIteratorWrapper(allExpressions.iterator());
  }

  public IMonCorrelatedQueryExpression addCorrelatedQueryExpression(String attrName, int valueDataType, int searchOp,
                                                                    boolean isCaseSensitive, boolean isRepeated,
                                                                    String subQuery) {
    IMonCorrelatedQueryExpression attrExpression = new MonCorrelatedQueryExpression(
        new DfValueListAttrExpression(getDateFormat(), attrName, 0, searchOp, isCaseSensitive, isRepeated), subQuery);
    m_expressions.add(attrExpression);

    return attrExpression;
  }

  public IDfSimpleAttrExpression addSimpleAttrExpression(String attrName, int valueDataType, int searchOp,
                                                         boolean isCaseSensitive, boolean isRepeated, String value) {
    IDfSimpleAttrExpression __TRACER_RETURN_VALUE__ = null;
    Throwable __TRACER_EXCEPTION__ = null;
    com.documentum.tracing.core.FieldAccessors __TRACE_FIELD_ACCESS__[] = null;
    try {
      IDfSimpleAttrExpression idfsimpleattrexpression;
      try {
        if (DfTracer.s_globalTraceEnabled && DfTracer.isEnabled()) {
          Parameter __TRACER_PARAMETERS__[] = new Parameter[6];
          __TRACER_PARAMETERS__[0] = new Parameter(attrName, "attrName", "String");
          __TRACER_PARAMETERS__[1] = new Parameter(valueDataType, "valueDataType", "int");
          __TRACER_PARAMETERS__[2] = new Parameter(searchOp, "searchOp", "int");
          __TRACER_PARAMETERS__[3] = new Parameter(isCaseSensitive, "isCaseSensitive", "boolean");
          __TRACER_PARAMETERS__[4] = new Parameter(isRepeated, "isRepeated", "boolean");
          __TRACER_PARAMETERS__[5] = new Parameter(value, "value", "String");
          DfTracer.traceMethodEntrance("addSimpleAttrExpression", 1, __TRACER_PARAMETERS__, getClass(), this,
              "IDfSimpleAttrExpression");
        }
        IDfSimpleAttrExpression attrExpression = new MonSimpleAttrExpression(getDateFormat(), attrName, valueDataType,
            searchOp, isCaseSensitive, isRepeated, value);
        m_expressions.add(attrExpression);
        __TRACER_RETURN_VALUE__ = attrExpression;
        idfsimpleattrexpression = __TRACER_RETURN_VALUE__;
      }
      catch (Throwable __exception__) {
        __TRACER_EXCEPTION__ = __exception__;
        if (__exception__ instanceof Error)
          throw (Error) __exception__;
        else
          throw (RuntimeException) __exception__;
      }
      return idfsimpleattrexpression;
    }
    finally {
      if (DfTracer.s_globalTraceEnabled && DfTracer.isEnabled())
        DfTracer.traceMethodExit("addSimpleAttrExpression", 1, getClass(), this, __TRACER_EXCEPTION__,
            __TRACER_RETURN_VALUE__);
    }
  }

  public IDfExpressionSet addExpressionSet() {
    IDfExpressionSet __TRACER_RETURN_VALUE__ = null;
    Throwable __TRACER_EXCEPTION__ = null;
    com.documentum.tracing.core.FieldAccessors __TRACE_FIELD_ACCESS__[] = null;
    try {
      IDfExpressionSet idfexpressionset;
      try {
        if (DfTracer.s_globalTraceEnabled && DfTracer.isEnabled()) {
          Parameter __TRACER_PARAMETERS__[] = new Parameter[0];
          DfTracer
              .traceMethodEntrance("addExpressionSet", 1, __TRACER_PARAMETERS__, getClass(), this, "IDfExpressionSet");
        }
        IDfExpressionSet expressionSet = new MonExpressionSet(getDateFormat());
        m_expressions.add(expressionSet);
        __TRACER_RETURN_VALUE__ = expressionSet;
        idfexpressionset = __TRACER_RETURN_VALUE__;
      }
      catch (Throwable __exception__) {
        __TRACER_EXCEPTION__ = __exception__;
        if (__exception__ instanceof Error)
          throw (Error) __exception__;
        else
          throw (RuntimeException) __exception__;
      }
      return idfexpressionset;
    }
    finally {
      if (DfTracer.s_globalTraceEnabled && DfTracer.isEnabled())
        DfTracer
            .traceMethodExit("addExpressionSet", 1, getClass(), this, __TRACER_EXCEPTION__, __TRACER_RETURN_VALUE__);
    }
  }

  public IDfExpressionSet addExpressionSet(int logicalOperator) {
    IDfExpressionSet __TRACER_RETURN_VALUE__ = null;
    Throwable __TRACER_EXCEPTION__ = null;
    com.documentum.tracing.core.FieldAccessors __TRACE_FIELD_ACCESS__[] = null;
    try {
      IDfExpressionSet idfexpressionset;
      try {
        if (DfTracer.s_globalTraceEnabled && DfTracer.isEnabled()) {
          Parameter __TRACER_PARAMETERS__[] = new Parameter[1];
          __TRACER_PARAMETERS__[0] = new Parameter(logicalOperator, "logicalOperator", "int");
          DfTracer
              .traceMethodEntrance("addExpressionSet", 1, __TRACER_PARAMETERS__, getClass(), this, "IDfExpressionSet");
        }
        IDfExpressionSet expressionSet = new MonExpressionSet(getDateFormat(), logicalOperator);
        m_expressions.add(expressionSet);
        __TRACER_RETURN_VALUE__ = expressionSet;
        idfexpressionset = __TRACER_RETURN_VALUE__;
      }
      catch (Throwable __exception__) {
        __TRACER_EXCEPTION__ = __exception__;
        if (__exception__ instanceof Error)
          throw (Error) __exception__;
        else
          throw (RuntimeException) __exception__;
      }
      return idfexpressionset;
    }
    finally {
      if (DfTracer.s_globalTraceEnabled && DfTracer.isEnabled())
        DfTracer
            .traceMethodExit("addExpressionSet", 1, getClass(), this, __TRACER_EXCEPTION__, __TRACER_RETURN_VALUE__);
    }
  }

}
