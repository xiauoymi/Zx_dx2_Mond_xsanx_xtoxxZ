package com.monsanto.dctm.create;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.StringTokenizer;

import com.documentum.fc.client.IDfType;
import com.documentum.fc.common.DfException;
import com.documentum.web.common.ArgumentList;
import com.documentum.web.common.WrapperRuntimeException;
import com.documentum.web.form.control.databound.DataDropDownList;
import com.documentum.web.form.control.databound.ScrollableResultSet;
import com.documentum.web.form.control.databound.TableResultSet;
import com.documentum.webcomponent.util.Types;

public class NewDocument extends com.documentum.webcomponent.library.create.NewDocument {
	
	private DataDropDownList m_typeList;
	private String m_strBaseDocbaseType;
	private String m_docbaseType;
	
	public void onInit(ArgumentList args) {
		super.onInit(args);
		m_typeList = (DataDropDownList)getControl("objectTypeList", com.documentum.web.form.control.databound.DataDropDownList.class);
		initTypeCombo();
		onSelectType(m_typeList, null);
	}
    	
	protected void initTypeCombo()
	{
		ScrollableResultSet resultSet = createTypesResultSet();
		m_typeList.getDataProvider().setResultSet(resultSet, null);
		m_typeList.getDataProvider().setDfSession(getDfSession());
		m_typeList.setValue(getDocbaseType());
	}
	
	protected ScrollableResultSet createTypesResultSet() {
		
		List includeTypesList = parseIncludeTypes();
		ScrollableResultSet resultSet = null;
		Iterator includeTypes = includeTypesList.iterator();
		while (includeTypes.hasNext())
		{
			String includeType = (String) includeTypes.next();
			setBaseDocbaseType(includeType);
			resultSet = combineTwoTypeListResultSets(resultSet, getTypeComboResultSet());
		}
		
		resultSet.sort("description", 0, 1);
		return resultSet;
	}
	
	protected void setBaseDocbaseType(String strBaseDocbaseType) {
		m_strBaseDocbaseType = strBaseDocbaseType;
		
	}
	
	private ScrollableResultSet combineTwoTypeListResultSets(ScrollableResultSet resultSet1, ScrollableResultSet resultSet2) {
		
		TableResultSet resultSet = new TableResultSet(new String[] {
				"type_name", "description", "label_text"
		});
		
		int numOfColumns = 3;
		copyScrollableResultSetToTableResultSet(resultSet1, resultSet, numOfColumns);
		copyScrollableResultSetToTableResultSet(resultSet2, resultSet, numOfColumns);
		
		return resultSet;
	}

	private void copyScrollableResultSetToTableResultSet(ScrollableResultSet source, TableResultSet target, int numOfColumns) {
		if (source != null)
		{
			int numOfRows = source.getResultsCount();
			for (int i=0; i < numOfRows; i++)
			{
				source.next();
				String[] row = new String[3];
				for (int j=0; j < numOfColumns; j++)
				{
					row[j] = (String) source.getObject(j+1);
				}
				target.add(row);
			}
		}
	}
	
	private List parseIncludeTypes()
	{
		ArrayList baseTypes = new ArrayList();
		String defaultType = lookupString("combo_defaults.base_type");
		String typeName;
		for(StringTokenizer stringTokenizer = new StringTokenizer(defaultType, ", \t\n\r", false); stringTokenizer.hasMoreTokens(); baseTypes.add(typeName))
			typeName = stringTokenizer.nextToken();
		
		return baseTypes;
	}
	
	
	protected ScrollableResultSet getTypeComboResultSet()
	{
		ScrollableResultSet resultSet;
		String baseObjectType = getBaseDocbaseType();
		if (baseObjectType != null && baseObjectType.length() > 0)
		{
			try {
				resultSet = Types.getTypes(baseObjectType, "dm_folder");
			} catch (DfException e) {
				throw new WrapperRuntimeException("Unable to query types from docbase!", e);
			}
		}
		else
		{
			try {
				resultSet = Types.getTypes(getDocumentBaseType(), "dm_folder");
			} catch (DfException e) {
				throw new WrapperRuntimeException("Unable to query types from docbase!", e);
			}
		}
		resultSet.sort("description", 0, 1);
		return resultSet;
	}
	
	protected String getDocumentBaseType()
	{
		return "dm_document";
	}
	
	protected String getDocbaseType()
	{
		if(m_docbaseType != null && m_docbaseType.length() > 0)
			return m_docbaseType;
		else
			return getDefaultDocumentType();
	}
	
	protected String getDefaultDocumentType()
	{
		String defaultType = lookupString("combo_defaults.type");
		if(typeExists(defaultType))
			return defaultType;
		else
			return "dm_document";
	}
	
	protected void setDocbaseType(String docbaseType)
	{
		m_docbaseType = docbaseType;
	}
	
	protected String getBaseDocbaseType() {
		return m_strBaseDocbaseType;
	}
	
	private boolean typeExists(String type)
	{
		if(type == null || type.length() == 0)
			return false;
		IDfType dftype;
		try {
			dftype = getDfSession().getType(type);
		} catch (DfException e) {
			return false;
		}
		return dftype != null;
	}
}
