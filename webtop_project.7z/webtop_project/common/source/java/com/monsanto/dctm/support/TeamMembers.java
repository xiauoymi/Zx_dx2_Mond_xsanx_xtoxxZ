/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.support;

import com.documentum.fc.client.IDfSysObject;
import com.documentum.fc.common.DfException;
import com.documentum.web.form.control.databound.ColumnDescriptor;
import com.documentum.web.formext.component.Component;

import java.util.ArrayList;
import java.util.List;

/**
 * Filename:    $RCSfile: TeamMembers.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: lakench $    	 On:	$Date:
 * 2007/01/13 08:44:09 $
 *
 * @author lakench
 * @version $Revision: 1.4 $
 */
public class TeamMembers extends SupportPageTableData {

  public TeamMembers(Component component) {
    super(component);
  }

  public List getData() throws DfException {
    List teamData = new ArrayList(5);
    IDfSysObject supportObject = getSupportConfig().getSupportConfigSysObject();
    int numTeamMembers = supportObject.getValueCount("team_member_name");
    for (int i = 0; i < numTeamMembers; i++) {
      ArrayList row = new ArrayList(4);
      row.add(supportObject.getRepeatingString("team_member_name", i));
      row.add(supportObject.getRepeatingString("team_member_role", i));
      row.add(supportObject.getRepeatingString("team_member_phone", i));
      row.add(supportObject.getRepeatingString("team_member_email", i));
      teamData.add(row);
    }
    return teamData;
  }

  public List getColumnList() {
    List teamMemberColumns = new ArrayList(4);
    teamMemberColumns.add(new ColumnDescriptor("name", "Name", true));
    teamMemberColumns.add(new ColumnDescriptor("role", "Document Systems Role", true));
    teamMemberColumns.add(new ColumnDescriptor("phone", "Phone", true));
    teamMemberColumns.add(new ColumnDescriptor("email", "Email", true));
    return teamMemberColumns;
  }
}