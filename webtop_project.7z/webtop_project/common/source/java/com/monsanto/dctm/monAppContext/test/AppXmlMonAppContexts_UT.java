/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.monAppContext.test;

import com.documentum.web.formext.config.ConfigService;
import com.documentum.web.common.ResourceFileUtil;
import com.monsanto.dctm.component.test.MockConfigReader;
import com.monsanto.dctm.component.test.MockServletContext;
import com.monsanto.dctm.monAppContext.AppXmlMonAppContexts;
import com.monsanto.dctm.monAppContext.IMonAppContext;
import junit.framework.TestCase;

/**
 * Filename:    $RCSfile: AppXmlMonAppContexts_UT.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: lakench $    	 On:	$Date: 2007-03-02 22:44:20 $
 *
 * @author lakench
 * @version $Revision: 1.1 $
 */
public class AppXmlMonAppContexts_UT extends TestCase {
    private MockConfigReader configReader;
    private MockServletContext servletContext;

    protected void setUp() throws Exception {
        super.setUp();
        servletContext = new MockServletContext();
        ResourceFileUtil.setLookupContext(servletContext, null);
        configReader = new MockConfigReader();
        ConfigService.setConfigReader(configReader);
    }

    protected void tearDown() throws Exception {
        super.tearDown();
    }

    public void testNoArgContstructor() throws Exception {
        AppXmlMonAppContexts appXmlMonAppContexts = new AppXmlMonAppContexts();
        IMonAppContext monAppContext = appXmlMonAppContexts.getMonAppContext("Test defaults work");
        assertEquals("wrong internal name", "test4", monAppContext.getInternalName());
    }

    public void testNullContext() throws Exception {
        new AppXmlMonAppContexts(null);
    }
}