/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.usermtn.test;

import com.documentum.fc.client.IDfSessionManager;
import com.documentum.web.common.ArgumentList;
import com.documentum.web.form.ComponentTestUtils;
import com.documentum.web.form.Form;
import com.documentum.web.formext.component.Component;
import com.monsanto.dctm.component.test.IMonTestableComponent;
import com.monsanto.dctm.usermtn.CreateUsersTextFile;

/**
 * Filename:    $RCSfile: MockCreateUsersTextFile.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: lakench $
 * On:	$Date: 2007-10-12 05:21:59 $
 *
 * @author lakench
 * @version $Revision: 1.2 $
 */
public class MockCreateUsersTextFile extends CreateUsersTextFile implements IMonTestableComponent {
  private IDfSessionManager sessionManager;
  private Class containedComponentClass;
  public ArgumentList containedComponentArgs;
  public boolean componentReturned;
  public Component containedComponent;
  public boolean prevPageSucceeded;
  public boolean nextPageSucceeded;
  private Form callerForm;

  public void setSessionManager(IDfSessionManager sessionManager) {
    this.sessionManager = sessionManager;
  }

  public IDfSessionManager getSessionManager() {
    return sessionManager;
  }

  protected void initializeContainer() {
    super.initializeContainer();
  }

  protected void setContainedComponentPage(String attrName) {
    super.setContainedComponentPage(attrName);
  }

  protected void setContainedComponentName(String attrName) {
    super.setContainedComponentName(attrName);
  }

  protected void setContainedComponentId(String attrName) {
    super.setContainedComponentId(attrName);
  }

  protected void setContainedComponentArgs(ArgumentList args) {
    super.setContainedComponentArgs(args);
  }

  protected void setContainedComponentClass(Class containedComponentClass) {
    this.containedComponentClass = containedComponentClass;
  }

  /**
   * @noinspection RefusedBequest
   */
  public Component createComponent(String strComponentName, String strComponentId, String strComponentPage,
                                   ArgumentList componentArgs) {
    this.containedComponentArgs = componentArgs;

    Component component = null;
    component = ComponentTestUtils
        .getComponent(containedComponentClass, strComponentId, "testdocbase", sessionManager);
    component.setName(strComponentName);
    component.setComponentPage(strComponentPage);
    return component;
  }

  /**
   * @noinspection RefusedBequest
   */
  public void setComponentReturn() {
    componentReturned = true;
  }

  protected Component getContainedComponent() {
    if (containedComponent == null)
      containedComponent = super.getContainedComponent();
    return containedComponent;
  }

  public boolean onPrevPage() {
    prevPageSucceeded = super.onPrevPage();
    return prevPageSucceeded;
  }

  public boolean onNextPage() {
    nextPageSucceeded = super.onNextPage();
    return nextPageSucceeded;
  }

  public void setCallerForm(Form callerForm) {
    this.callerForm = callerForm;
  }

  /**
   * @noinspection RefusedBequest
   */
  public Form getCallerForm() {
    return callerForm;
  }
}