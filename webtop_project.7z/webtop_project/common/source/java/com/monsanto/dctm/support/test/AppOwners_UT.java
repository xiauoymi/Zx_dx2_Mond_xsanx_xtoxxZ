/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.support.test;

import com.documentum.fc.client.MockSession;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfLoginInfo;
import com.documentum.web.form.ComponentTestUtils;
import com.documentum.web.form.control.databound.ColumnDescriptor;
import com.documentum.web.formext.component.Component;
import com.monsanto.dctm.component.test.MockComponent;
import com.monsanto.dctm.component.test.MockSessionManager;
import com.monsanto.dctm.component.test.MockSysObject;
import com.monsanto.dctm.support.AppOwners;
import junit.framework.TestCase;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * Filename:    $RCSfile: AppOwners_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: lakench $    	 On:	$Date:
 * 2007/01/12 18:49:20 $
 *
 * @author lakench
 * @version $Revision: 1.4 $
 */
public class AppOwners_UT extends TestCase {
  private AppOwners appOwners;
  private MockSession session;
  private List expectedAreas;
  private List expectedNames;
  private List expectedEmails;
  private Component component;

  protected void setUp() throws Exception {
    super.setUp();
    MockSessionManager mockSessionManager = new MockSessionManager();
    DfLoginInfo dfLoginInfo = new DfLoginInfo();
    dfLoginInfo.setUser("testuserid");
    mockSessionManager.setIdentity("testdocbase", dfLoginInfo);
    session = (MockSession) mockSessionManager.getSession("testdocbase");
    DfLoginInfo dfLoginInfoForSupportConfig = new DfLoginInfo();
    dfLoginInfo.setUser("devl01");
    mockSessionManager.setIdentity("stltst03", dfLoginInfoForSupportConfig);
    session = (MockSession) mockSessionManager.getSession("stltst03");
    MockSysObject expectedSupportConfigSysObject = new MockSysObject();
    session.addObject(expectedSupportConfigSysObject, "mon_support_info");

    component = (MockComponent) ComponentTestUtils
        .getComponent(MockComponent.class, "testcomponent", "testdocbase", mockSessionManager);
    appOwners = new AppOwners(component);
  }

  protected void tearDown() throws Exception {
    ComponentTestUtils.releaseComponent(component);
    super.tearDown();
  }

  public void testAllColumnsInColumnListAreColumnDescriptors() throws Exception {
    List columnList = appOwners.getColumnList();
    Iterator columns = columnList.iterator();
    while (columns.hasNext()) {
      Object column = columns.next();
      assertTrue("column is not a ColumnDescriptor", column instanceof ColumnDescriptor);
    }
  }

  public void testColumnListContainsCorrectData() throws Exception {
    List expectedColumnList = new ArrayList(3);
    expectedColumnList.add(new ColumnDescriptor("app", "Application", true));
    expectedColumnList.add(new ColumnDescriptor("area", "Site", true));
    expectedColumnList.add(new ColumnDescriptor("owners", "Authorized User Request Sponsor(s)", true));

    List actualColumnList = appOwners.getColumnList();
    Iterator expectedColumns = expectedColumnList.iterator();
    int index = 0;
    while (expectedColumns.hasNext()) {
      ColumnDescriptor expectedColumn = (ColumnDescriptor) expectedColumns.next();
      ColumnDescriptor actualColumn = (ColumnDescriptor) actualColumnList.get(index);
      assertEquals("column " + index + " attribute not set properly", expectedColumn.getAttribute(),
          actualColumn.getAttribute());
      assertEquals("column " + index + " alias not set properly", expectedColumn.getAlias(),
          actualColumn.getAlias());
      assertEquals("column " + index + " label not set properly", expectedColumn.getLabel(),
          actualColumn.getLabel());
      assertEquals("column " + index + " visible not set properly", expectedColumn.isVisible(),
          actualColumn.isVisible());
      index++;
    }
  }

  public void testDataIsReturnedProperly() throws Exception {
    addMonAppContextsObjects();
    addAppOwnerInfoObjects();
    List expectedDataList = getExpectedDataList();

    List actualDataList = appOwners.getData();

    Iterator rows = actualDataList.iterator();
    int rowNum = 0;
    while (rows.hasNext()) {
      List actualRow = (List) rows.next();
      List expectedRow = (List) expectedDataList.get(rowNum);
      assertEquals("row " + rowNum + " not set correctly", expectedRow, actualRow);
      rowNum++;
    }
  }

  private List getExpectedDataList() {
    List expectedDataList = new ArrayList(2);
    int numAppOwners = 4;
    List row = new ArrayList(3);
    row.add("test display name");
    if (numAppOwners > 0) {
      String currentArea = (String) expectedAreas.get(0);
      StringBuffer appOwnerInfo = new StringBuffer();
      for (int i = 0; i < numAppOwners; i++) {
        String area = (String) expectedAreas.get(i);
        if (!area.equals(currentArea)) {
          row.add(currentArea);
          row.add(appOwnerInfo.toString());
          expectedDataList.add(row);
          appOwnerInfo = new StringBuffer();
          row = new ArrayList(3);
          row.add("test display name");
          currentArea = area;
        }
        appOwnerInfo.append(expectedNames.get(i));
        appOwnerInfo.append("::");
        appOwnerInfo.append(expectedEmails.get(i));
        appOwnerInfo.append("##");
      }
      row.add(currentArea);
      row.add(appOwnerInfo.toString());
      expectedDataList.add(row);
    }
    return expectedDataList;
  }

  private void addAppOwnerInfoObjects() {
    expectedAreas = new ArrayList(4);
    expectedAreas.add("area 1");
    expectedAreas.add("area 1");
    expectedAreas.add("area 2");
    expectedAreas.add("area 2");
    expectedNames = new ArrayList(4);
    expectedNames.add("name 1.1");
    expectedNames.add("name 1.2");
    expectedNames.add("name 2.1");
    expectedNames.add("name 2.2");
    expectedEmails = new ArrayList(4);
    expectedEmails.add("email 1.1");
    expectedEmails.add("email 1.2");
    expectedEmails.add("email 2.1");
    expectedEmails.add("email 2.2");
    MockSysObject appOwnerInfoObject = new MockSysObject();
    appOwnerInfoObject.setRepeatingStrings("name", expectedNames);
    appOwnerInfoObject.setRepeatingStrings("area", expectedAreas);
    appOwnerInfoObject.setRepeatingStrings("email", expectedEmails);
    session.addObject(appOwnerInfoObject, "mon_app_owner_info where mon_app_context = 'test object name'");
  }

  private void addMonAppContextsObjects() throws DfException {
    MockSysObject queryObject = new MockSysObject();
    queryObject.setString("object_name", "test object name");
    queryObject.setString("display_name", "test display name");
    session.addObject(queryObject,
        "query_cmd,s0,T,F,,,,,select object_name, display_name from mon_app_context_info order by display_name");
  }
}