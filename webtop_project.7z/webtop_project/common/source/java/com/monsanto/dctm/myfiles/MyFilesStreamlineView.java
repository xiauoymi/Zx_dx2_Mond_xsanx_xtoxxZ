package com.monsanto.dctm.myfiles;

import com.monsanto.dctm.monAppContext.MonAppContextService;

public class MyFilesStreamlineView extends
                                   com.documentum.webtop.webcomponent.myfiles.MyFilesStreamlineView {

    protected String getColumnsPreferenceId() {
        return super.getColumnsPreferenceId() + "." +
               MonAppContextService.getMonAppContextService().getMonAppContextInternalName();
    }

}
