/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.usermtn.test;

import com.documentum.fc.client.IDfSessionManager;
import com.documentum.fc.client.MockSession;
import com.documentum.web.common.ArgumentList;
import com.documentum.web.form.ComponentTestUtils;
import com.documentum.web.form.control.Label;
import com.monsanto.dctm.component.test.MockComponent;
import com.monsanto.dctm.component.test.MockSessionManager;
import junit.framework.TestCase;

/**
 * Filename:    $RCSfile: CreateUsersTextFile_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: lakench $
 * On:	$Date: 2007-10-12 05:21:59 $
 *
 * @author lakench
 * @version $Revision: 1.2 $
 */
public class CreateUsersTextFile_UT extends TestCase {

  private MockCreateUsersTextFile component;
  public IDfSessionManager mockSessionManager;

  protected void setUp() throws Exception {
    super.setUp();
    mockSessionManager = new MockSessionManager();
    MockSession session = new MockSession(mockSessionManager);
    ((MockSessionManager) mockSessionManager).setSession(session);
    component = (MockCreateUsersTextFile) ComponentTestUtils
        .getComponent(MockCreateUsersTextFile.class, "createuserstextfile", "testdocbase", mockSessionManager);
    component.setCallerForm(component);

  }

  /**
   * @noinspection MethodWithTooManyParameters
   */
  private void setContainedComponent(String componentId, String componentName, String componentPage,
                                     ArgumentList componentArgs, Class componentClass,
                                     MockCreateUsersTextFile componentForm) {
    component.setContainedComponentId(componentId);
    component.setContainedComponentName(componentName);
    component.setContainedComponentPage(componentPage);
    component.setContainedComponentArgs(componentArgs);
    component.setContainedComponentClass(componentClass);
    component.getContainedComponent().setForm(componentForm);
  }

  protected void tearDown() throws Exception {
    ComponentTestUtils.releaseComponent(component.containedComponent);
    ComponentTestUtils.releaseComponent(component);
    super.tearDown();
  }

  public void testCreate() throws Exception {
    assertNotNull(component);
    assertEquals(mockSessionManager, component.getSessionManager());
  }

  public void testInit() throws Exception {
    setContainedComponent("testcomponent", "TestComponent", "start", new ArgumentList(), MockComponent.class,
        component);
    ((MockComponent) component.getContainedComponent()).setHasNextPage(true);
    component.initializeContainer();
    Label userCount = (Label) component.getControl("usrcnt");
    assertEquals("1 of 1 User", userCount.getLabel());
    assertEquals(1, component.getCurrentComponent());
    assertTrue(component.hasNextPage());
    assertFalse(component.hasPrevPage());
    assertTrue(component.canCancelChanges());
  }

  public void testPrevPage() throws Exception {
    setContainedComponent("testcomponent", "TestComponent", "start", new ArgumentList(), MockComponent.class,
        component);
    ((MockComponent) component.getContainedComponent()).setHasPrevPage(true);
    component.initializeContainer();
    component.onPrev(null, null);
    assertFalse(((MockComponent) component.containedComponent).triedToGoToPrevPage);
    assertFalse(component.prevPageSucceeded);
    assertEquals(1, component.getCurrentComponent());
    Label userCount = (Label) component.getControl("usrcnt");
    assertEquals("1 of 1 User", userCount.getLabel());
  }

  public void testNextPage() throws Exception {
    setContainedComponent("testcomponent", "TestComponent", "start", new ArgumentList(), MockComponent.class,
        component);
    ((MockComponent) component.getContainedComponent()).setHasNextPage(true);
    ((MockComponent) component.getContainedComponent()).setCanCancelChanges(true);
    ((MockComponent) component.getContainedComponent()).setShouldValidate(true);
    component.initializeContainer();
    component.onNext(null, null);
    assertTrue(((MockComponent) component.containedComponent).triedToGoToNextPage);
    assertTrue(component.nextPageSucceeded);
    assertTrue(component.canCancelChanges());
    assertEquals(2, component.getCurrentComponent());
    Label userCount = (Label) component.getControl("usrcnt");
    assertEquals("2 of 2 Users", userCount.getLabel());
  }

  public void testNextWithInvalidContainedComponent() throws Exception {
    setContainedComponent("testcomponent", "TestComponent", "start", new ArgumentList(), MockComponent.class,
        component);
    ((MockComponent) component.getContainedComponent()).setHasNextPage(true);
    ((MockComponent) component.getContainedComponent()).setShouldValidate(false);
    component.initializeContainer();
    component.onNext(null, null);
    assertFalse(((MockComponent) component.containedComponent).triedToGoToNextPage);
    assertTrue(((MockComponent) component.containedComponent).triedToValidate);
    assertFalse(component.nextPageSucceeded);
    assertTrue(component.canCancelChanges());
    assertEquals(1, component.getCurrentComponent());
    Label userCount = (Label) component.getControl("usrcnt");
    assertEquals("1 of 1 User", userCount.getLabel());
  }

  public void testNextWithContainedComponentThatHasNoNext() throws Exception {
    setContainedComponent("testcomponent", "TestComponent", "start", new ArgumentList(), MockComponent.class,
        component);
    ((MockComponent) component.getContainedComponent()).setHasNextPage(false);
    ((MockComponent) component.getContainedComponent()).setShouldValidate(true);
    component.initializeContainer();
    component.onNext(null, null);
    assertFalse(((MockComponent) component.containedComponent).triedToGoToNextPage);
    assertTrue(((MockComponent) component.containedComponent).triedToValidate);
    assertFalse(component.nextPageSucceeded);
    assertTrue(component.canCancelChanges());
    assertEquals(1, component.getCurrentComponent());
    Label userCount = (Label) component.getControl("usrcnt");
    assertEquals("1 of 1 User", userCount.getLabel());
  }

  public void testNextPageThenPrevPage() throws Exception {
    setContainedComponent("testcomponent", "TestComponent", "start", new ArgumentList(), MockComponent.class,
        component);
    ((MockComponent) component.getContainedComponent()).setHasNextPage(true);
    ((MockComponent) component.getContainedComponent()).setHasPrevPage(true);
    ((MockComponent) component.getContainedComponent()).setShouldValidate(true);
    component.initializeContainer();
    component.onNext(null, null);
    assertTrue(((MockComponent) component.containedComponent).triedToGoToNextPage);
    assertTrue(component.nextPageSucceeded);
    assertEquals(2, component.getCurrentComponent());
    Label userCount = (Label) component.getControl("usrcnt");
    assertEquals("2 of 2 Users", userCount.getLabel());
    component.onPrev(null, null);
    assertTrue(((MockComponent) component.containedComponent).triedToGoToPrevPage);
    assertTrue(component.prevPageSucceeded);
    assertEquals(1, component.getCurrentComponent());
    assertEquals("1 of 2 Users", userCount.getLabel());
  }

  public void testNextPageThenPrevPageThenNextPage() throws Exception {
    setContainedComponent("testcomponent", "TestComponent", "start", new ArgumentList(), MockComponent.class,
        component);
    ((MockComponent) component.getContainedComponent()).setHasNextPage(true);
    ((MockComponent) component.getContainedComponent()).setHasPrevPage(true);
    ((MockComponent) component.getContainedComponent()).setShouldValidate(true);
    component.initializeContainer();
    component.onNext(null, null);
    assertTrue(((MockComponent) component.containedComponent).triedToGoToNextPage);
    assertTrue(component.nextPageSucceeded);
    assertEquals(2, component.getCurrentComponent());
    Label userCount = (Label) component.getControl("usrcnt");
    assertEquals("2 of 2 Users", userCount.getLabel());
    component.onPrev(null, null);
    assertTrue(((MockComponent) component.containedComponent).triedToGoToPrevPage);
    assertTrue(component.prevPageSucceeded);
    assertEquals(1, component.getCurrentComponent());
    assertEquals("1 of 2 Users", userCount.getLabel());
    component.onNext(null, null);
    assertTrue(((MockComponent) component.containedComponent).triedToGoToNextPage);
    assertTrue(component.nextPageSucceeded);
    assertEquals(2, component.getCurrentComponent());
    assertEquals("2 of 2 Users", userCount.getLabel());
  }

  public void testCancel() throws Exception {
    setContainedComponent("testcomponent", "TestComponent", "start", new ArgumentList(), MockComponent.class,
        component);
    component.initializeContainer();
    component.onCancel(null, null);
    assertTrue(((MockComponent) component.containedComponent).triedToCancelChanges);
    assertTrue(((MockComponent) component.containedComponent).cancelledChanges);
  }

  public void testCancelWhenContainedComponentCantCancel() throws Exception {
    setContainedComponent("testcomponent", "TestComponent", "start", new ArgumentList(), MockComponent.class,
        component);
    ((MockComponent) component.getContainedComponent()).setCanCancelChanges(false);
    component.initializeContainer();
    component.onCancel(null, null);
    assertFalse(((MockComponent) component.containedComponent).triedToCancelChanges);
    assertFalse(((MockComponent) component.containedComponent).cancelledChanges);
  }

  public void testCancelAfterNext() throws Exception {
    setContainedComponent("testcomponent", "TestComponent", "start", new ArgumentList(), MockComponent.class,
        component);
    ((MockComponent) component.getContainedComponent()).setHasNextPage(true);
    ((MockComponent) component.getContainedComponent()).setShouldValidate(true);
    component.initializeContainer();
    component.onNext(null, null);
    assertTrue(component.nextPageSucceeded);
    assertEquals(2, component.getCurrentComponent());
    Label userCount = (Label) component.getControl("usrcnt");
    assertEquals("2 of 2 Users", userCount.getLabel());
    component.onCancel(null, null);
    assertTrue(((MockComponent) component.containedComponent).triedToCancelChanges);
    assertTrue(((MockComponent) component.containedComponent).cancelledChanges);
  }

  public void testClose() throws Exception {
    setContainedComponent("testcomponent", "TestComponent", "start", new ArgumentList(), MockComponent.class,
        component);
    component.initializeContainer();
    component.onClose(null, null);
    assertTrue(component.componentReturned);
  }

  public void testOk() throws Exception {
    setContainedComponent("testcomponent", "TestComponent", "start", new ArgumentList(), MockComponent.class,
        component);
    component.initializeContainer();
    component.onOk(null, null);
    assertTrue(((MockComponent) component.containedComponent).triedToCommitChanges);
    assertTrue(component.componentReturned);
  }

  public void testOkWhenContainedComponentCantCommit() throws Exception {
    setContainedComponent("testcomponent", "TestComponent", "start", new ArgumentList(), MockComponent.class,
        component);
    ((MockComponent) component.getContainedComponent()).setCanCommitChanges(false);
    component.initializeContainer();
    component.onOk(null, null);
    assertFalse(((MockComponent) component.containedComponent).triedToCommitChanges);
    assertFalse(component.componentReturned);
  }
}