package com.monsanto.dctm.queuemanagement;

import com.monsanto.dctm.monAppContext.MonAppContextService;

public class ManageQueueInbox extends
                              com.documentum.webcomponent.library.queuemanagement.ManageQueueInbox {

    protected String getColumnsPreferenceId() {
        return super.getColumnsPreferenceId() + "." +
               MonAppContextService.getMonAppContextService().getMonAppContextInternalName();
    }

}
