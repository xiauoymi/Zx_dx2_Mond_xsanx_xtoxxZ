/*
 * DeepExport.java
 *
 * Created on March 23, 2006, 2:19 PM
 * 
 */

package com.monsanto.dctm.action;

import java.util.*;
import java.io.*;

import com.documentum.web.common.*;
import com.documentum.web.formext.action.*;
import com.documentum.web.formext.component.Component;
import com.documentum.web.formext.config.Context;
import com.documentum.web.formext.config.IConfigElement;
import com.documentum.web.formext.session.*;

import com.documentum.fc.client.*;
import com.documentum.fc.common.*;

import com.documentum.devprog.common.zip.*;

/**
 *
 * @author tsvedan
 * @modified by pveerav - Added listeners to delete Zip File
 */
public class DeepExport extends LaunchComponentWithPermitCheck {

    /** Creates a new instance of DeepExport */
    public DeepExport() {
    }

    public boolean execute(
            String strAction,
            IConfigElement config,
            ArgumentList args,
            Context context,
            Component component,
            Map completionArgs) {

        String strObjectId = args.get("objectId");
        try {

            IDfId folderId = new DfId(strObjectId);
            IDfSession session = component.getDfSession();
            IDfFolder folder = (IDfFolder)session.getObject(folderId);
            IDfId parentId = new DfId(folder.getAncestorId(1));// 1 implies immediate parent

            IDfClient localClient = DfClient.getLocalClient();
            IDfSessionManager sessMgr = SessionManagerHttpBinding.getSessionManager();              
            //System.out.println("Folder id = " + strObjectId);
            //System.out.println("Folder name = " + folder.getObjectName());
            String zipFilename = folder.getObjectName();
            String strZipService = IDpZipService.class.getName();
            IDpZipService zipService = (IDpZipService) localClient.newService(strZipService,sessMgr);
            IDfId m_importedZipId = zipService.createZipInDocbase(folderId,parentId,zipFilename);
            //System.out.println(" Finished exporting. " + m_importedZipId);
            
            IActionCompleteListener originalCompleteListener = 
                (IActionCompleteListener)completionArgs.get(ActionService.COMPLETE_LISTENER);
                
            IActionCompleteListener completeListener = new 
              ZipExportCompleteListener(originalCompleteListener,config,args,context,component);
            
            completionArgs.put(ActionService.COMPLETE_LISTENER, completeListener);            
            
            if (m_importedZipId != null && !m_importedZipId.isNull()){
                args.replace("objectId", m_importedZipId.getId());
                args.replace("type", "dm_document");
                 return super.execute(strAction, config, args, context, component, completionArgs);
               }
        } catch(IOException ioe) {
            throw new WrapperRuntimeException(ioe);
        } catch(DfException dfe) {
            throw new WrapperRuntimeException(dfe);
        }
        return false;
    }
    

class ZipExportCompleteListener implements IActionCompleteListener
{
   
   private IActionCompleteListener completeListener;
   private IConfigElement config;
   private ArgumentList args;
   private Context context;
   private Component component;  
   
   
   protected ZipExportCompleteListener (IActionCompleteListener completeListener,IConfigElement config,ArgumentList args,Context context,Component component)
   {      
      this.completeListener = completeListener;
      this.config = config;
      this.args = args;
      this.context = context;
      this.component = component;      
   }
   
   public void onComplete (String actionId, boolean result,java.util.Map map)
   {
      if(completeListener != null)
      {
         completeListener.onComplete (actionId,result,map);
      }      
  
      if(result == true)
      {          
          IDfSession sess = null;
          IDfSessionManager sessionManager= null;
          try{
                  sess = component.getDfSession();  
                  sessionManager = sess.getSessionManager();
                  String zipObjIdString = args.get("objectId"); 
                  //System.out.println(" Destroying exported zip file " + zipObjIdString);
                  String qualification = "dm_sysobject where r_object_id ='" + zipObjIdString + "'";
                  IDfSysObject zipObj = (IDfSysObject)sess.getObjectByQualification(qualification);
                  zipObj.destroy();
          }
          catch(DfException dfe) {             
            dfe.printStackTrace();
        }          
      }
   }
}

}
