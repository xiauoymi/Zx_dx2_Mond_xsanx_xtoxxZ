/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.action;

import com.documentum.fc.client.IDfPersistentObject;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.IDfSysObject;
import com.documentum.fc.common.DfException;
import com.documentum.web.common.ArgumentList;
import com.documentum.web.common.WrapperRuntimeException;
import com.documentum.web.formext.component.Component;
import com.documentum.web.formext.config.Context;
import com.documentum.web.formext.config.IConfigElement;
import com.documentum.web.formext.docbase.ObjectCacheUtil;
import com.documentum.webcomponent.library.actions.ViewAction;
import com.monsanto.dctm.monAppContext.IMonAppContextService;
import com.monsanto.dctm.monAppContext.MonAppContextService;

/**
 * Filename:    $RCSfile: ViewActionPrecondition.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: lakench $
 * On:	$Date: 2007-10-12 05:21:59 $
 *
 * @author lakench
 * @version $Revision: 1.2 $
 */
public class ViewActionPrecondition extends ViewAction {
  private static final double VALID_CONTENT_SIZE = 0.4;

  public boolean queryExecute(String strAction, IConfigElement config, ArgumentList args, Context context,
                              Component component) {
    IMonAppContextService monAppContextService = MonAppContextService.getMonAppContextService();
    if (monAppContextService.isUseViewForCommentingEnabled()) {
      return callSuperQueryExecute(strAction, config, args, context, component);
    } else {

      //This code was added to prevent system from looking up the preferred view action/application.
      //Since we have commenting turned on it was always running the comment action queryExecute and this was causing
      // problems with the view button being grayed out sometimes.

      boolean bExecute = false;
      long contentSize = 0;
      IDfSysObject sysobj = getSysObject(component, args);
      contentSize = getContentSize(args, contentSize, sysobj);

      if (contentSize > VALID_CONTENT_SIZE) {
        String strContentType = getContentType(args, sysobj);
        if (strContentType != null && strContentType.length() > 0) {
          args.add("contentType", strContentType);
        }
        bExecute = true;
      } else {
        bExecute = callSuperQueryExecute(strAction, config, args, context, component);
      }


      return bExecute;
    }

  }

  protected boolean callSuperQueryExecute(String strAction, IConfigElement config, ArgumentList args, Context context,
                                          Component component) {
    return super.queryExecute(strAction, config, args, context, component);
  }

  private String getContentType(ArgumentList args, IDfSysObject sysobj) {
    String strContentType = null;
    strContentType = args.get("contentType");
    if (strContentType == null || strContentType.length() == 0) {
      if (sysobj != null) {
        try {
          strContentType = sysobj.getContentType();
        } catch (DfException e) {
          throw new WrapperRuntimeException("Failed to get content type", e);
        }
      }
    }
    return strContentType;
  }

  private IDfSysObject getSysObject(Component component, ArgumentList args) {
    IDfSession dfSession = component.getDfSession();
    String strObjectId = args.get("objectId");
    IDfSysObject sysobj = null;
    try {
      sysobj = (IDfSysObject) getSysObjectFromCache(dfSession, strObjectId);
    } catch (DfException e) {
      throw new WrapperRuntimeException("Failed to get sysobject", e);
    }
    return sysobj;
  }

  private long getContentSize(ArgumentList args, long contentSize, IDfSysObject sysobj) {
    try {


      String strContentSize = args.get("contentSize");
      if (strContentSize != null && strContentSize.length() != 0) {
        contentSize = (long) Double.parseDouble(strContentSize);
      } else {
        if (sysobj != null) {
          contentSize = sysobj.getContentSize();
        }
      }
    }
    catch (DfException e) {
      throw new WrapperRuntimeException("Failed to get content size", e);
    }
    return contentSize;
  }

  protected IDfPersistentObject getSysObjectFromCache(IDfSession dfSession, String strObjectId) throws DfException {
    return ObjectCacheUtil.getObject(dfSession, strObjectId);
  }
}
