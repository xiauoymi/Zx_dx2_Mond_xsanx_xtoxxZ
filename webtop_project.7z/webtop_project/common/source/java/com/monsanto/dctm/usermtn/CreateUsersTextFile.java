/*
 * CreateUsersTextFile.java
 *
 * Created on July 8, 2006, 11:03 AM
 *
 * To change this template, choose Tools | Options and locate the template under
 * the Source Creation and Management node. Right-click the template and choose
 * Open. You can then make changes to the template in the Source Editor.
 */

package com.monsanto.dctm.usermtn;

import com.documentum.web.common.ArgumentList;
import com.documentum.web.form.control.Label;
import com.documentum.web.formext.component.WizardContainer;

/**
 * @author tsvedan
 */
public class CreateUsersTextFile extends WizardContainer {

    private int index;
    private int total;

    public void onInit(ArgumentList args) {
        super.onInit(args);
        initializeContainer();
    }

    protected void initializeContainer() {
        index = total = 1;
        setCountLabel();
    }

    public boolean onNextPage() {
        boolean wentToNextPage = super.onNextPage();
        if (wentToNextPage) {
            increment();
            setCountLabel();
        }
        return wentToNextPage;
    }

    public boolean onPrevPage() {
        boolean wentToPrevPage = super.onPrevPage();
        if (wentToPrevPage) {
            decrement();
            setCountLabel();
        }
        return wentToPrevPage;
    }

    public int getCurrentComponent() {
        return this.index;
    }

    private void increment() {
        if (getLatestPage())
            total++;
        index++;
    }

    private void decrement() {
        index--;
    }

    private boolean getLatestPage() {
        return index == total;
    }

    private void setCountLabel() {
        StringBuffer strbuff = new StringBuffer();
        strbuff.append(index);
        strbuff.append(" of ");
        strbuff.append(total);
        strbuff.append(" User");
        if (total > 1) strbuff.append("s");
        ((Label) getControl("usrcnt", Label.class)).setLabel(strbuff.toString());
    }
}
