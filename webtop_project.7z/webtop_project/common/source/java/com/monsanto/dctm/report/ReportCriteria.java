package com.monsanto.dctm.report;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import com.documentum.web.form.Control;
import com.documentum.web.form.Form;
import com.documentum.web.formext.component.Component;
import com.documentum.web.formext.config.ConfigService;
import com.documentum.web.formext.config.Context;
import com.documentum.web.formext.config.IConfigElement;

public class ReportCriteria extends Control {
	
	private String pre;
	private String col1;
	private String col2;
	private String post;
	//private String configId;
	private HashMap criteria = new HashMap();

	public ReportCriteria() {
		super();
	}
	public String getCol1() {
		return col1;
	}
	public void setCol1(String col1) {
		this.col1 = col1;
	}
	public String getCol2() {
		return col2;
	}
	public void setCol2(String col2) {
		this.col2 = col2;
	}
	public String getPost() {
		return post;
	}
	public void setPost(String post) {
		this.post = post;
	}
	public String getPre() {
		return pre;
	}
	public void setPre(String pre) {
		this.pre = pre;
	}
	
	public void setCriteria(HashMap criteria) {
		this.criteria = criteria;
	}
	public HashMap getCriteria() {
		return criteria;
	}
	public List getCriteriaConfig()
	{
		List criteriaList = new ArrayList();
		IConfigElement criteriaElement = ConfigService.getConfigLookup().lookupElement(getCriteriaConfigPath(), getContext());
		Iterator criteriaConfigList = criteriaElement.getChildElements();
		while (criteriaConfigList.hasNext())
		{
			criteriaList.add(new Criterion((IConfigElement) criteriaConfigList.next()));
		}
		return criteriaList;
	}
	
    private String getCriteriaConfigPath() {
		return "component[id=" + ((Component)getContainer()).getComponentId() + "].criteria";
	}
    
	private Context getContext()
    {
        Context context = null;
        Form form = getForm();
        if(form instanceof Component)
        {
            Component comp = (Component)form;
            context = new Context(comp.getContext());
        }
        if(context == null)
            context = new Context();
        return context;
    }
	
	protected void updateStateFromRequest() {
		criteria.clear();
		FindCriterionValue criteriaVisitor = new FindCriterionValue(getName());
		getForm().visitDepthFirst(criteriaVisitor);
		Iterator criteriaValues = criteriaVisitor.getCriterionValues();
		while (criteriaValues.hasNext())
		{
			ReportCriterionValue value = (ReportCriterionValue) criteriaValues.next();
			String criterionName = value.getCriterion().getName();
			String criterionValue = value.getValue();
			String criterionDisplay = value.getDisplayvalue();
			String[] criterionReturn = {criterionValue, criterionDisplay};
			criteria.put(criterionName, criterionReturn);
		}
	}
}
