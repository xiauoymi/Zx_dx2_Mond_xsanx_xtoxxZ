/*
 Copyright:  Copyright � 2006 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.appconfig;

import com.documentum.web.common.ArgumentList;
import com.documentum.web.form.control.Breadcrumb;
import com.documentum.web.form.control.databound.Datagrid;
import com.documentum.web.formext.component.Component;

public class AppConfig extends Component {
  public static final String CONTROL_GRID = "appconfiggrid";
  protected static final String BASE_QUERY = "select r_object_id, object_name, display_name from mon_app_context_info ";
  protected static final String QUERY_ORDERBY = " order by object_name";
  public static final String CONTROL_BREADCRUMB = "breadcrumb";

  public void onInit(ArgumentList args) {
    super.onInit(args);
    initControls();
  }

  protected void initControls() {
    initAppConfigDatagrid();
    initBreadcrumb();
  }

  public void onRefreshData() {
    super.onRefreshData();
    ((Datagrid) getControl(CONTROL_GRID)).getDataProvider().refresh();
  }

  private void initAppConfigDatagrid() {
    Datagrid datagrid = (Datagrid) getControl(CONTROL_GRID, Datagrid.class);
    datagrid.getDataProvider().setDfSession(getDfSession());
    datagrid.getDataProvider().setQuery(BASE_QUERY + QUERY_ORDERBY);
  }

  private void initBreadcrumb() {
    Breadcrumb breadcrumb = getBreadCrumbControl();
    String administration = getString("MSG_ADMINISTRATION_LINK");
    String currentComponent = getString("MSG_COMPONENT_ID");
    String breadCrumbPath = administration + "/" + currentComponent;
    breadcrumb.setValue(breadCrumbPath);
  }

  protected Breadcrumb getBreadCrumbControl() {
    return (Breadcrumb) getControl(CONTROL_BREADCRUMB, Breadcrumb.class);
  }

  public void onClickBreadcrumb(Breadcrumb breadcrumb, ArgumentList args) {
    Breadcrumb breadCrumbControl = getBreadCrumbControl();
    String strPath = breadCrumbControl.getValue();

    int index = strPath.lastIndexOf('/');
    String componentNLSName = strPath.substring(index + 1);
    if (componentNLSName.equals(getString("MSG_ADMINISTRATION_LINK"))) {
      jumpToAdministrationComponent();
    }
  }

  protected void jumpToAdministrationComponent() {
    setComponentJump("administration", getContext());
  }
}