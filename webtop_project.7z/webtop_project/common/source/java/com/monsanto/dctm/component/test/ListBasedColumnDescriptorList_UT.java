/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.component.test;

import com.documentum.web.form.control.databound.ColumnDescriptor;
import com.monsanto.dctm.component.ListBasedColumnDescriptorList;
import junit.framework.TestCase;

import java.util.ArrayList;
import java.util.List;

/**
 * Filename:    $RCSfile: ListBasedColumnDescriptorList_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change:
 * $Author: lakench $    	 On:	$Date: 2007-08-21 05:23:14 $
 *
 * @author lakench
 * @version $Revision: 1.1 $
 */
public class ListBasedColumnDescriptorList_UT extends TestCase {

  public void testCreateSupportPageComponentColumnDescriptorListWithNullArgs() throws Exception {
    try {
      new ListBasedColumnDescriptorList(null, null);
    } catch (IllegalArgumentException e) {
      assertEquals("exception message set incorrectly", "Datagrid control name cannot be null!", e.getMessage());
      return;
    }
    fail("Expected IllegalArgumentException");
  }

  public void testCreateSupportPageComponentColumnDescriptorListWithNullColumnList() throws Exception {
    try {
      new ListBasedColumnDescriptorList("test_datagrid", null);
    } catch (IllegalArgumentException e) {
      assertEquals("exception message set incorrectly", "ColumnDescriptor list cannot be null!", e.getMessage());
      return;
    }
    fail("Expected IllegalArgumentException");

  }

  public void testColumnsSet() throws Exception {
    List teamMemberColumns = new ArrayList(2);
    teamMemberColumns.add(new ColumnDescriptor("name", "Name", true));
    teamMemberColumns.add(new ColumnDescriptor("role", "Document Systems Role", false));
    ListBasedColumnDescriptorList columnDescriptorList =
        new ListBasedColumnDescriptorList("test_datagrid", teamMemberColumns);
    ColumnDescriptor columnDescriptor;
    columnDescriptor = columnDescriptorList.get("name");
    assertNotNull("Column named \"name\" doesn't exist", columnDescriptor);
    assertEquals("column label not set properly", "Name", columnDescriptor.getLabel());
    assertNull("column alias not set properly", columnDescriptor.getAlias());
    assertTrue("column visibility not set properly", columnDescriptor.isVisible());

    columnDescriptor = columnDescriptorList.get("role");
    assertNotNull("Column named \"role\" doesn't exist", columnDescriptor);
    assertEquals("column label not set properly", "Document Systems Role", columnDescriptor.getLabel());
    assertNull("column alias not set properly", columnDescriptor.getAlias());
    assertFalse("column visibility not set properly", columnDescriptor.isVisible());
  }

}