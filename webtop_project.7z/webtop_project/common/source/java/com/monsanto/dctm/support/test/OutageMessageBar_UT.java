/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.support.test;

import com.documentum.fc.client.MockSession;
import com.documentum.fc.common.DfLoginInfo;
import com.documentum.web.form.ComponentTestUtils;
import com.documentum.web.form.control.Label;
import com.monsanto.dctm.component.test.MockSessionManager;
import com.monsanto.dctm.component.test.MockSysObject;
import com.monsanto.dctm.support.OutageMessageBar;
import junit.framework.TestCase;

/**
 * Filename:    $RCSfile: OutageMessageBar_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: lakench $ On:	$Date:
 * 2007/08/23 15:03:38 $
 *
 * @author lakench
 * @version $Revision: 1.3 $
 */
public class OutageMessageBar_UT extends TestCase {
  private MockSessionManager mockSessionManager;
  private MockOutageMessageBar outageMessageBarComponent;

  protected void setUp() throws Exception {
    super.setUp();
    mockSessionManager = new MockSessionManager();
    MockSession session = new MockSession(mockSessionManager);
    ((MockSessionManager) mockSessionManager).setSession(session);
    DfLoginInfo dfLoginInfoForSupportConfig = new DfLoginInfo();
    dfLoginInfoForSupportConfig.setUser("devl01");
    mockSessionManager.setIdentity("stltst03", dfLoginInfoForSupportConfig);
    outageMessageBarComponent = (MockOutageMessageBar) ComponentTestUtils
        .getComponent(MockOutageMessageBar.class, "titlebar", "testdocbase", mockSessionManager);
  }

  protected void tearDown() throws Exception {
    ComponentTestUtils.releaseComponent(outageMessageBarComponent);
    super.tearDown();
  }

  public void testSupportMessagesWithBlankUrlsSetCorrectly() throws Exception {
    MockSession sessionForSupportConfig = (MockSession) mockSessionManager.getSession("stltst03");
    MockSysObject expectedSupportConfigSysObject = new MockSysObject();
    expectedSupportConfigSysObject.setString("outage_notice", "test outage notice");
    expectedSupportConfigSysObject.setString("outage_notice_url", "");
    expectedSupportConfigSysObject.setString("user_message", "test user message");
    expectedSupportConfigSysObject.setString("user_message_url", "");
    sessionForSupportConfig.addObject(expectedSupportConfigSysObject, "mon_support_info");

    outageMessageBarComponent.initSupportMessages();
    Label outageLabelControl = (Label) outageMessageBarComponent
        .getControl(OutageMessageBar.SUPPORT_OUTAGE_LABEL, Label.class);
    String actualOutageLabel = outageLabelControl.getLabel();
    assertEquals("test outage notice", actualOutageLabel);
    assertEquals("color:red;font-weight:bold", outageLabelControl.getCssStyle());

    Label userMessageControl = (Label) outageMessageBarComponent
        .getControl(OutageMessageBar.SUPPORT_MESSAGE_LABEL, Label.class);
    String actualUserMessage = userMessageControl.getLabel();
    assertEquals("test user message", actualUserMessage);
    assertEquals("color:red;font-weight:bold", userMessageControl.getCssStyle());

    assertFalse(outageMessageBarComponent.wasHideOutageMessageBarClientEventCalled);
    assertTrue(outageMessageBarComponent.wasShowOutageMessageBarClientEventCalled);
  }

  public void testSupportMessagesWithNullUrlsSetCorrectly() throws Exception {
    MockSession sessionForSupportConfig = (MockSession) mockSessionManager.getSession("stltst03");
    MockSysObject expectedSupportConfigSysObject = new MockSysObject();
    expectedSupportConfigSysObject.setString("outage_notice", "test outage notice");
    expectedSupportConfigSysObject.setString("outage_notice_url", null);
    expectedSupportConfigSysObject.setString("user_message", "test user message");
    expectedSupportConfigSysObject.setString("user_message_url", null);
    sessionForSupportConfig.addObject(expectedSupportConfigSysObject, "mon_support_info");

    outageMessageBarComponent.initSupportMessages();
    Label outageLabelControl = (Label) outageMessageBarComponent
        .getControl(OutageMessageBar.SUPPORT_OUTAGE_LABEL, Label.class);
    String actualOutageLabel = outageLabelControl.getLabel();
    assertEquals("test outage notice", actualOutageLabel);
    assertEquals("color:red;font-weight:bold", outageLabelControl.getCssStyle());

    Label userMessageControl = (Label) outageMessageBarComponent
        .getControl(OutageMessageBar.SUPPORT_MESSAGE_LABEL, Label.class);
    String actualUserMessage = userMessageControl.getLabel();
    assertEquals("test user message", actualUserMessage);
    assertEquals("color:red;font-weight:bold", userMessageControl.getCssStyle());

    assertFalse(outageMessageBarComponent.wasHideOutageMessageBarClientEventCalled);
    assertTrue(outageMessageBarComponent.wasShowOutageMessageBarClientEventCalled);
  }

  public void testSupportMessagesWithUrlsSetCorrectly() throws Exception {
    MockSession sessionForSupportConfig = (MockSession) mockSessionManager.getSession("stltst03");
    MockSysObject expectedSupportConfigSysObject = new MockSysObject();
    expectedSupportConfigSysObject.setString("outage_notice", "test outage notice");
    expectedSupportConfigSysObject.setString("outage_notice_url", "http://www.google.com");
    expectedSupportConfigSysObject.setString("user_message", "test user message");
    expectedSupportConfigSysObject.setString("user_message_url", "http://www.umr.edu");
    sessionForSupportConfig.addObject(expectedSupportConfigSysObject, "mon_support_info");

    outageMessageBarComponent.initSupportMessages();
    Label outageLabelControl = (Label) outageMessageBarComponent
        .getControl(OutageMessageBar.SUPPORT_OUTAGE_LABEL, Label.class);
    String actualOutageLabel = outageLabelControl.getLabel();
    assertEquals("test outage notice <a href='http://www.google.com' target='_blank'>&lt;Read more&gt;</a>",
        actualOutageLabel);
    assertEquals("color:red;font-weight:bold", outageLabelControl.getCssStyle());

    Label userMessageControl = (Label) outageMessageBarComponent
        .getControl(OutageMessageBar.SUPPORT_MESSAGE_LABEL, Label.class);
    String actualUserMessage = userMessageControl.getLabel();
    assertEquals("test user message <a href='http://www.umr.edu' target='_blank'>&lt;Read more&gt;</a>",
        actualUserMessage);
    assertEquals("color:red;font-weight:bold", userMessageControl.getCssStyle());

    assertFalse(outageMessageBarComponent.wasHideOutageMessageBarClientEventCalled);
    assertTrue(outageMessageBarComponent.wasShowOutageMessageBarClientEventCalled);
  }

  public void testOutageMessageBarHiddenIfNoMessages() throws Exception {
    MockSession sessionForSupportConfig = (MockSession) mockSessionManager.getSession("stltst03");
    MockSysObject expectedSupportConfigSysObject = new MockSysObject();
    expectedSupportConfigSysObject.setString("outage_notice", "");
    expectedSupportConfigSysObject.setString("user_message", "");
    sessionForSupportConfig.addObject(expectedSupportConfigSysObject, "mon_support_info");

    outageMessageBarComponent.initSupportMessages();
    Label outageLabelControl = (Label) outageMessageBarComponent
        .getControl(OutageMessageBar.SUPPORT_OUTAGE_LABEL, Label.class);
    String actualOutageLabel = outageLabelControl.getLabel();
    assertEquals(null, actualOutageLabel);

    Label userMessageControl = (Label) outageMessageBarComponent
        .getControl(OutageMessageBar.SUPPORT_MESSAGE_LABEL, Label.class);
    String actualUserMessage = userMessageControl.getLabel();
    assertEquals(null, actualUserMessage);

    assertTrue(outageMessageBarComponent.wasHideOutageMessageBarClientEventCalled);
    assertFalse(outageMessageBarComponent.wasShowOutageMessageBarClientEventCalled);
  }
}