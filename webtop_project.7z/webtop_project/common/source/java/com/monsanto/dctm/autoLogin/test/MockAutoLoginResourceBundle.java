/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.autoLogin.test;

import java.util.ListResourceBundle;

/**
 * Filename:    $RCSfile: MockAutoLoginResourceBundle.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: lakench $    	 On:	$Date: 2007-01-16 22:56:32 $
 *
 * @author LAKENCH
 * @version $Revision: 1.1 $
 */
public class MockAutoLoginResourceBundle extends ListResourceBundle {
    private Object[][] contents;

    /**
     * @noinspection ReturnOfCollectionOrArrayField
     */
    public Object[][] getContents() {
        return contents;
    }

    public void setContents(Object[][] contents) {
        this.contents = contents;
    }
}
