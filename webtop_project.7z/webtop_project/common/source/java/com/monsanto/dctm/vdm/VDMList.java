package com.monsanto.dctm.vdm;

import com.monsanto.dctm.monAppContext.MonAppContextService;

public class VDMList extends com.documentum.webtop.webcomponent.vdm.VDMList {

    protected String getColumnsPreferenceId() {
        return super.getColumnsPreferenceId() + "." +
               MonAppContextService.getMonAppContextService().getMonAppContextInternalName();
    }

}
