/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.appconfig;

import com.documentum.fc.client.IDfSession;
import com.documentum.fc.common.DfException;

import java.util.ArrayList;
import java.util.List;

/**
 * Filename:    $RCSfile: AppConfigOwnerWorkingSet.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: lakench $    	 On:	$Date: 2007-08-21 05:23:14 $
 *
 * @author lakench
 * @version $Revision: 1.1 $
 */
public class AppConfigOwnerWorkingSet extends AppConfigItemWorkingSet {
  public AppConfigOwnerWorkingSet(String monAppContext, IDfSession session, String objectType) throws DfException {
    super(monAppContext, session, objectType);
  }

  public List getColumnDescriptors() {
    List columnDescriptors = new ArrayList(4);
    columnDescriptors.add(new AppConfigColumnDescriptor("area", "Site", true, true, "All"));
    columnDescriptors.add(new AppConfigColumnDescriptor("name", "Name", true, true, "Authorized User Not on Record"));
    columnDescriptors.add(new AppConfigColumnDescriptor("email", "Email", true, true, "eedocu@monsanto.com"));
    return columnDescriptors;
  }

  public String getDeleteActionName() {
    return "removeauthrequestor";
  }

  public String getObjectNameSuffix() {
    return "_app_owners";
  }
}