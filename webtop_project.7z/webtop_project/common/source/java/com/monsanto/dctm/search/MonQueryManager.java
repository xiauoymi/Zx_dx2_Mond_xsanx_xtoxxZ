package com.monsanto.dctm.search;

import com.documentum.fc.client.IDfSysObject;
import com.documentum.fc.client.search.*;
import com.documentum.fc.client.search.impl.DfPassThroughQuery;
import com.documentum.fc.client.search.impl.DfXMLUtil;
import com.documentum.fc.common.DfException;
import org.w3c.dom.Document;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

public class MonQueryManager implements IDfQueryManager {

  private IDfQueryManager queryManager;

  public MonQueryManager(IDfQueryManager queryManager) {
    this.queryManager = queryManager;
  }

  public IDfQueryBuilder newQueryBuilder() throws DfException {
    IDfQueryBuilder queryBuilder = queryManager.newQueryBuilder();
    return new MonQueryBuilder(queryBuilder.getMetadataMgr());
  }

  public IDfQueryBuilder newQueryBuilder(String objectType) throws DfException {
    IDfQueryBuilder queryBuilder = queryManager.newQueryBuilder(objectType);
    return new MonQueryBuilder(queryBuilder.getMetadataMgr(), objectType);
  }

  public IDfQueryBuilder newQueryBuilder(String string, int i, boolean b) throws DfException {
    return queryManager.newQueryBuilder(string, i, b);
  }

  public IDfPassThroughQuery newPassThroughQuery(String string) throws DfException {
    return queryManager.newPassThroughQuery(string);
  }

  public IDfPassThroughQuery newPassThroughQuery(String string, String string1, int i) throws DfException {
    return queryManager.newPassThroughQuery(string, string1, i);
  }

  public IDfSmartListDefinition newSmartListDefinition() throws DfException {
    return queryManager.newSmartListDefinition();
  }

  public IDfQueryDefinition loadQueryDefinition(InputStream inputStream) throws DfException, IOException {
    return queryManager.loadQueryDefinition(inputStream);
  }

  public void saveQueryDefinition(IDfQueryDefinition iDfQueryDefinition, OutputStream outputStream) throws DfException,
      IOException {
    queryManager.saveQueryDefinition(iDfQueryDefinition, outputStream);
  }

  public IDfSmartListDefinition loadSmartListDefinition(InputStream in) throws DfException, IOException {
    Document doc = DfXMLUtil.read(in);
    return new MonSmartListDefinition(newSmartListDefinition().getQueryDefinition().getMetadataMgr(), doc);
  }

  public void saveSmartListDefinition(IDfSmartListDefinition iDfSmartListDefinition, OutputStream outputStream) throws
      DfException, IOException {
    queryManager.saveSmartListDefinition(iDfSmartListDefinition, outputStream);
  }

  public IDfSmartListDefinition convertSmartListDefinition(IDfSysObject object) throws DfException, IOException {
    return queryManager.convertSmartListDefinition(object);
  }

  protected static IDfQueryDefinition readQueryDefinition(IDfSearchMetadataManager metadataManager, Document doc) throws
      DfException {
    IDfQueryDefinition queryDef = null;
    org.w3c.dom.Node node = DfXMLUtil.getNode(doc, "PassThroughQuery", false);
    if (node != null) {
      queryDef = new DfPassThroughQuery(metadataManager, doc);
    } else {
      node = DfXMLUtil.getNode(doc, "QueryBuilder", false);
      if (node != null)
        queryDef = new MonQueryBuilder(metadataManager, doc);
    }
    if (queryDef == null)
      DfXMLUtil.throwXMLFormatError("<QueryBuilder>");
    return queryDef;
  }
}
