/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.autoLogin.test;

import com.documentum.fc.client.IDfDocbaseMap;
import com.documentum.fc.common.DfException;
import com.monsanto.dctm.autoLogin.AutoLoginAuthenticationScheme;
import com.monsanto.dctm.autoLogin.ComponentCredentials;

import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.util.ResourceBundle;

/**
 * Filename:    $RCSfile: MockAutoLoginAuthenticationScheme.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author:
 * lakench $    	 On:	$Date: 2007-07-31 18:51:49 $
 *
 * @author lakench
 * @version $Revision: 1.1 $
 */
public class MockAutoLoginAuthenticationScheme extends AutoLoginAuthenticationScheme {
  private ResourceBundle mockResourceBundle;
  private IDfDocbaseMap mockDocbaseMap;

  public void setMockResourceBundle(ResourceBundle mockResourceBundle) {
    this.mockResourceBundle = mockResourceBundle;
  }

  public void setMockDocbaseMap(IDfDocbaseMap mockDocbaseMap) {
    this.mockDocbaseMap = mockDocbaseMap;
  }

  /**
   * @noinspection RefusedBequest
   */
  protected ComponentCredentials getComponentCredentials(String callingComponentName) throws DfException,
      IOException {
    return new ComponentCredentials(callingComponentName, mockResourceBundle, mockDocbaseMap);
  }

  protected String getCallingComponentName(HttpServletRequest request) {
    return super.getCallingComponentName(request);
  }
}