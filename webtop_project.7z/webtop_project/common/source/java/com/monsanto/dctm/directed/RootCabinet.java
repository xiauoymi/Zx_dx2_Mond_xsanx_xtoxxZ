/*
 Copyright:  Copyright � 2006 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.directed;

import com.documentum.fc.client.IDfSysObject;
import com.documentum.fc.common.DfException;
import com.documentum.web.common.ArgumentList;
import com.documentum.web.common.WrapperRuntimeException;
import com.documentum.web.env.AbstractEnvironment;
import com.documentum.web.env.EnvironmentService;
import com.documentum.web.env.IContentTransfer;
import com.documentum.web.form.Control;
import com.documentum.web.formext.action.ActionService;
import com.documentum.web.formext.docbase.FolderUtil;
import com.documentum.web.formext.docbase.ObjectCacheUtil;
import com.documentum.webcomponent.common.WebComponentErrorService;
import com.monsanto.dctm.homecabinet.HomeCabinetClassicView;

/**
 * Filename:    $RCSfile: RootCabinet.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: lakench $    	 On:	$Date: 2006-12-14 21:32:30 $
 *
 * @author LAKENCH
 * @version $Revision: 1.25 $
 */
public class RootCabinet extends HomeCabinetClassicView {

    public void onInit(ArgumentList args) {
        m_strHomeCabinetPath = RootCabinetService.getRootCabinetPath();
        super.onInit(args);
    }

    /**
     * Handle the onClickObject event.
     * <p/>
     * NOTE: fired from the client to update the doclist after an object onclick
     */
    public void onClickObject(Control control, ArgumentList args) {
        String strId = args.get("objectId");         // can be null if docbase root!
        String strType = args.get("type");
        String strIsFolder = args.get("isFolder");

        boolean bIsFolder = false;
        if (strIsFolder != null && strIsFolder.charAt(0) == '1') {
            bIsFolder = true;
        }

        if (strType == null || strType.length() == 0) {
            return;
        }

        try {
            // only change the folderpath if we have clicked a folder object
            if (bIsFolder || FolderUtil.isFolderType(strId)) {
                onClickFolder(control, args);
            } else {
                // are we are working with a Virtual Document?
                // or with a contentless object?
                IDfSysObject sysobj = null;
                try {
                    sysobj = (IDfSysObject) ObjectCacheUtil.getObject(getDfSession(), strId);
                }
                catch (DfException e) {
                    setReturnError("MSG_CANNOT_FETCH_OBJECT", null, e);
                    WebComponentErrorService.getService().setNonFatalError(this, "MSG_CANNOT_FETCH_OBJECT", e);
                    return;
                }

                if (strType.equals("dm_process")) {
                    args.add("setError", "true");
                }

                boolean isAssembly = !(sysobj.getAssembledFromId().isNull());
                if (sysobj.isVirtualDocument()) {
                    // launch the VDM List component
                    args.add("structureComponent", "directed_vdmlist");
                    ActionService.execute("openvirtualdocument", args, getContext(), this, null);
                } else if (isAssembly) {
                    args.add("structureComponent", "assemblylist");
                    ActionService.execute("openassembly", args, getContext(), this, null);
                } else if (sysobj.getContentSize() == 0) {
                    onClickEmptyContent(control, args);
                } else {
                    // if the object is already checked out by the current user
                    // launch edit
                    AbstractEnvironment env = EnvironmentService.getEnvironment();
                    IContentTransfer ctContract = env.getContentTransferContract();
                    boolean bApplet = true;
                    if (ctContract != null) {
                        if (ctContract.getContentTransferMechanism().equals(IContentTransfer.HTTP_CONTENT_TRANSFER)) {
                            bApplet = false;
                        }
                    }
                    if (sysobj.isCheckedOutBy(null) && bApplet) {
                        ActionService.execute("editfile", args, getContext(), this, null);
                    } else {
                        // execute the "view" action to view the content
                        ActionService.execute("view", args, getContext(), this, null);
                    }
                }
            }
        }
        catch (DfException e) {
            throw new WrapperRuntimeException("onClickObject()", e);
        }
    }
}