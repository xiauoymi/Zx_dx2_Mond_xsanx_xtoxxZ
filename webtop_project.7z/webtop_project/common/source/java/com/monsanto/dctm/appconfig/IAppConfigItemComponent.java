/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.appconfig;

import java.util.List;

/**
 * Filename:    $RCSfile: IAppConfigItemComponent.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: lakench $    	 On:	$Date: 2007-08-21 05:23:14 $
 *
 * @author lakench
 * @version $Revision: 1.1 $
 */
public interface IAppConfigItemComponent {
  public List getColumnDescriptors();

  public String getDeleteActionName();

  public String getAppConfigItemType();

  public String getAppConfigItemNameSuffix();
}