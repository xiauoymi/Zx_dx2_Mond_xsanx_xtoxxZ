/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.usermtn.test;

import com.documentum.fc.client.MockSession;
import com.documentum.fc.common.DfLoginInfo;
import com.documentum.fc.common.IDfLoginInfo;
import com.documentum.web.form.ComponentTestUtils;
import com.documentum.web.form.control.DropDownList;
import com.documentum.web.form.control.Text;
import com.monsanto.dctm.component.test.MockSessionManager;
import com.monsanto.dctm.usermtn.DuplicateUserValidator;
import com.monsanto.dctm.usermtn.UserProfile;
import junit.framework.TestCase;

/**
 * Filename:    $RCSfile: DuplicateUserValidator_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: lakench $
 * On:	$Date: 2007-10-12 05:21:59 $
 *
 * @author LAKENCH
 * @version $Revision: 1.3 $
 */
public class DuplicateUserValidator_UT extends TestCase {
  private MockUserProfile component;
  private static final String TEST_USER_NAME_JOEMINER = "Joe Miner";
  private static final String TEST_USER_OS_NAME_JOEMINER = "joeminer";
  private static final String TEST_USER_NAME_TESTUSER = "Test User";
  private static final String TEST_USER_OS_NAME_TESTUSER = "testuser";

  protected void setUp() throws Exception {
    super.setUp();
    MockSessionManager mockSessionManager = new MockSessionManager();
    MockSession session = new MockSession(mockSessionManager);
    session.setLoginUserName(TEST_USER_NAME_TESTUSER);
    session.setDocbaseName("testdocbase");
    IDfLoginInfo loginInfo = new DfLoginInfo();
    loginInfo.setUser(TEST_USER_OS_NAME_TESTUSER);
    session.setLoginInfo(loginInfo);
    ((MockSessionManager) mockSessionManager).setSession(session);
    component = (MockUserProfile) ComponentTestUtils
        .getComponent(MockUserProfile.class, "userprofile", "testdocbase", mockSessionManager);
    component.initializeComponent();
  }

  protected void tearDown() throws Exception {
    ComponentTestUtils.releaseComponent(component);
    super.tearDown();
  }

  public void testCreate() throws Exception {
    DuplicateUserValidator control = new DuplicateUserValidator();
    assertNotNull(control);
  }

  public void testValidate() throws Exception {
    DuplicateUserValidator control = (DuplicateUserValidator) component
        .getControl("testusernamevalidator", DuplicateUserValidator.class);
    control.setErrorMessage("testerrormessage");
    control.validate();
    assertTrue(control.getIsValid());
  }

  public void testAddDuplicateUser() throws Exception {
    DuplicateUserValidator control = (DuplicateUserValidator) component
        .getControl("testusernamevalidator", DuplicateUserValidator.class);
    control.setVisible(false);
    control.setErrorMessage("testerrormessage");
    addUser(MockUserProfile.USER_ROLE_VALUE, TEST_USER_NAME_JOEMINER, TEST_USER_OS_NAME_JOEMINER);
    addDuplicateUser(MockUserProfile.AUTHOR_ROLE_VALUE, TEST_USER_NAME_JOEMINER, TEST_USER_OS_NAME_JOEMINER);
    control.validate();
    assertFalse(control.getIsValid());
  }

  private void addUser(String role, String userName, String userOSName) {
    setupUser(role, userName, userOSName);
    assertTrue(component.onNextPage());
    assertTrue(component.triedToValidate);
    component.triedToValidate = false;
  }

  private void addDuplicateUser(String role, String userName, String userOSName) {
    setupUser(role, userName, userOSName);
    assertFalse(component.onNextPage());
    assertTrue(component.triedToValidate);
    component.triedToValidate = false;
  }

  private void setupUser(String role, String userName, String userOSName) {
    selectRole(role);
    setUserNameAndUserOSName(userName, userOSName);
  }

  private void selectRole(String role) {
    ((DropDownList) component.getControl(UserProfile.USER_ROLE)).setValue(role);
    component.onSelectRole(((DropDownList) component.getControl(UserProfile.USER_ROLE)), null);
  }

  private void setUserNameAndUserOSName(String userName, String userOSName) {
    ((Text) component.getControl(UserProfile.USER_NAME, Text.class)).setValue(userName);
    ((Text) component.getControl(UserProfile.USER_OS_NAME, Text.class)).setValue(userOSName);
  }
}