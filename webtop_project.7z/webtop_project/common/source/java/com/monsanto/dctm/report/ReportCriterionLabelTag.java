package com.monsanto.dctm.report;

import java.io.IOException;

import javax.servlet.jsp.JspTagException;
import javax.servlet.jsp.JspWriter;

import com.documentum.web.form.Control;
import com.documentum.web.form.ControlTag;

public class ReportCriterionLabelTag extends ControlTag {
	
	private Criterion criterion;
	
	public ReportCriterionLabelTag() {
		criterion = null;
	}

	public void setCriterion(Criterion criterion) {
		this.criterion = criterion;
	}

	protected Class getControlClass() {
		return ReportCriterionLabel.class;
	}

	protected void setControlProperties(Control control) {
		super.setControlProperties(control);
		
		ReportCriterionLabel label = (ReportCriterionLabel) control;
		if (criterion != null)
			label.setCriterion(criterion);
	}

	public void release() {
		criterion = null;
		super.release();
	}

	protected void renderEnd(JspWriter out) throws IOException, JspTagException {
        ReportCriterionLabel label = (ReportCriterionLabel) getControl();
        if(label.isVisible())
        {
            StringBuffer buf = new StringBuffer(255);
            String strClass = label.getCssClass();
            String strStyle = label.getCssStyle();
            buf.append("<!-- " + getName() + "-->");
            buf.append("<span");
			if(strClass != null)
			    buf.append(" class=\"").append(strClass).append("\"");
			else
			    buf.append(" class=\"").append("defaultDocbaseAttributeLabelStyle").append("\"");
			if(strStyle != null)
			    buf.append(" style=\"").append(strStyle).append("\"");
			buf.append(">");
			String strAttribLabel = formatText(label.getCriterionLabel());
			buf.append(strAttribLabel);
			buf.append("</span>");
			out.print(buf.toString());
        }
	}	
}
