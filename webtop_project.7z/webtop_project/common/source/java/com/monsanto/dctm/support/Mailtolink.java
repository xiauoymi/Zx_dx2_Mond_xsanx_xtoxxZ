/*
 Copyright:  Copyright � 2006 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.support;

import com.documentum.web.form.control.Link;

/**
 * Filename:    $RCSfile: Mailtolink.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: lakench $    	 On:	$Date: 2006-09-15 13:51:33 $
 *
 * @author LAKENCH
 * @version $Revision: 1.1 $
 */
public class Mailtolink extends Link {
    private String emailAddress;

    public Mailtolink() {
        emailAddress = null;
    }

    public String getEmailAddress() {
        return emailAddress;
    }

    public void setEmailAddress(String emailAddress) {
        this.emailAddress = emailAddress;
    }

}