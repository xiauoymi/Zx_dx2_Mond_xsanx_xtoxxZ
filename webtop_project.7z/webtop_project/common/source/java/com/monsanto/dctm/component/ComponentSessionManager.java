/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.component;

import com.documentum.fc.client.*;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.IDfLoginInfo;
import com.documentum.web.common.WrapperRuntimeException;
import com.documentum.web.formext.component.Component;
import com.monsanto.dctm.autoLogin.ComponentCredentials;

import java.io.IOException;
import java.text.MessageFormat;

/**
 * Filename:    $RCSfile: ComponentSessionManager.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: lakench $
 * On:	$Date: 2007-08-21 05:23:14 $
 *
 * @author lakench
 * @version $Revision: 1.6 $
 */
public class ComponentSessionManager implements IComponentSessionManager {
  private IDfSessionManager sessionManager;
  private String docbase;
  private String componentID;

  public ComponentSessionManager(Component component) {
    this(component, component.getDfSession().getSessionManager());
  }

  public ComponentSessionManager(Component component, IDfSessionManager sessionManager) {
    this(component.getComponentId(), component.getCurrentDocbase(), sessionManager);
  }

  public ComponentSessionManager(String componentID, String docbase, IDfSessionManager sessionManager) {
    this.componentID = componentID;
    this.docbase = docbase;
    this.sessionManager = sessionManager;
  }

  public ComponentSessionManager(String componentID, IDfSessionManager sessionManager) {
    this(componentID, null, sessionManager);
  }

  public void setPrincipalName(String string) {
    sessionManager.setPrincipalName(string);
  }

  public String getPrincipalName() {
    return sessionManager.getPrincipalName();
  }

  public void setLocale(String string) {
    sessionManager.setLocale(string);
  }

  public String getLocale() {
    return sessionManager.getLocale();
  }

  public void setIdentity(String string, IDfLoginInfo iDfLoginInfo) throws DfServiceException {
    sessionManager.setIdentity(string, iDfLoginInfo);
  }

  public IDfLoginInfo getIdentity(String string) {
    return sessionManager.getIdentity(string);
  }

  public boolean hasIdentity(String string) {
    return sessionManager.hasIdentity(string);
  }

  public void clearIdentity(String string) {
    sessionManager.clearIdentity(string);
  }

  public void clearIdentities() {
    sessionManager.clearIdentities();
  }

  public void authenticate(String string) throws DfIdentityException, DfAuthenticationException, DfPrincipalException,
      DfServiceException {
    sessionManager.authenticate(string);
  }

  public IDfSession getSessionForComponent() throws DfException {
    IDfSession dfSession = null;
    boolean addedIdentity = false;
    String credsDocbase = null;

    ComponentCredentials creds = null;
    try {
      creds = getComponentCredentials(componentID);
    } catch (IOException e) {
      throw new WrapperRuntimeException("couldn't get component credentials", e);
    }
    credsDocbase = (String) creds.getDocbase();
    if (credsDocbase == null) {
      credsDocbase = docbase;
    }
    if (credsDocbase == null) {
      throw new DfException(
          MessageFormat.format("failed to get component credentials for component id: {0}", new Object[]{componentID}));
    }
    try {
      if (!sessionManager.hasIdentity(credsDocbase)) {
        IDfLoginInfo newIdentity = creds.getLoginInfo();
        sessionManager.setIdentity(credsDocbase, newIdentity);
        addedIdentity = true;
      }
      dfSession = sessionManager.getSession(credsDocbase);
    } finally {
      if (addedIdentity) {
        sessionManager.clearIdentity(credsDocbase);
      }
    }
    return dfSession;
  }

  public ComponentCredentials getComponentCredentials(String componentId) throws DfException, IOException {
    return new ComponentCredentials(componentId);
  }

  public IDfSession getSession(String string) throws DfIdentityException, DfAuthenticationException,
      DfPrincipalException, DfServiceException {
    return sessionManager.getSession(string);
  }

  public IDfSession newSession(String string) throws DfIdentityException, DfAuthenticationException,
      DfPrincipalException, DfServiceException {
    return sessionManager.newSession(string);
  }

  public void release(IDfSession session) {
    sessionManager.release(session);
  }

  public void beginTransaction() throws DfServiceException {
    sessionManager.beginTransaction();
  }

  public void commitTransaction() throws DfServiceException {
    sessionManager.commitTransaction();
  }

  public void abortTransaction() throws DfServiceException {
    sessionManager.abortTransaction();
  }

  public boolean isTransactionActive() {
    return sessionManager.isTransactionActive();
  }

  public void setTransactionRollbackOnly() {
    sessionManager.setTransactionRollbackOnly();
  }

  public boolean getTransactionRollbackOnly() {
    return sessionManager.getTransactionRollbackOnly();
  }

  public void beginClientControl() {
    sessionManager.beginClientControl();
  }

  public void endClientControl() throws DfServiceException {
    sessionManager.endClientControl();
  }

  public IDfSessionManagerStatistics getStatistics() {
    return sessionManager.getStatistics();
  }

  public IDfSessionManagerEventListener setListener(IDfSessionManagerEventListener iDfSessionManagerEventListener) {
    return sessionManager.setListener(iDfSessionManagerEventListener);
  }
}