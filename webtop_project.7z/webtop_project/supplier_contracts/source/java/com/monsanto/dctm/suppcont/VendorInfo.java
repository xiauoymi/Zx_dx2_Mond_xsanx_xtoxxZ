/*
 * VendorInfo.java
 *
 * Created on March 29, 2006, 2:49 PM
 *
 * To change this template, choose Tools | Options and locate the template under
 * the Source Creation and Management node. Right-click the template and choose
 * Open. You can then make changes to the template in the Source Editor.
 */

package com.monsanto.dctm.suppcont;

import com.documentum.web.common.*;
import com.documentum.web.form.*;
import com.documentum.web.form.control.*;
import com.documentum.web.formext.component.*;

import com.documentum.fc.client.*;
import com.documentum.fc.common.*;

/**
 *
 * @author tsvedan
 */
public class VendorInfo extends Component {
    
    /** Creates a new instance of VendorInfo */
    public VendorInfo() {
    }
    
    public void onInit(ArgumentList args) {
        super.onInit(args);
        String strObjectId = args.get("objectId");
        String vendorId = null;
        try {
            IDfSysObject sysobj = (IDfSysObject) getDfSession().getObject(new DfId(strObjectId));
            vendorId = sysobj.getString("vendor_id");
        } catch (DfException e) {}
        setLabel("vendorid", vendorId);
        setLabel("streetaddr", "800 N Lindbergh");
        setLabel("city", "St Louis");
        setLabel("state", "Missouri");
        setLabel("zip", "63146");
    }
    
    private void setLabel(String name, String label) {
        Label control = (Label) getControl(name, com.documentum.web.form.control.Label.class);
        control.setLabel(label);
    }
    
}
