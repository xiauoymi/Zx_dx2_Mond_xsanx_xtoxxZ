package com.monsanto.eas.sappasswordtool.to;

import java.io.Serializable;

/**
 * Created by IntelliJ IDEA.
 * User: rrpand5
 * Date: 10/11/12
 * Time: 2:34 PM
 * To change this template use File | Settings | File Templates.
 */
public class UserDetailsTO implements Serializable {

    private static final long serialVersionUID = -7774998249916676596L;
    private String userName;
    private String password;
    private String userDomain;
    private String userEmail;
    private String firstName;
    private String lastName;
    private String sapServerInstance;
    private String sapServerInstanceDesc;

    public String getSapServerInstanceDesc() {
        return sapServerInstanceDesc;
    }

    public void setSapServerInstanceDesc(String sapServerInstanceDesc) {
        this.sapServerInstanceDesc = sapServerInstanceDesc;
    }

    public String getSapServerInstance() {
        return sapServerInstance;
    }

    public void setSapServerInstance(String sapServerInstance) {
        this.sapServerInstance = sapServerInstance;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getUserDomain() {
        return userDomain;
    }

    public void setUserDomain(String userDomain) {
        this.userDomain = userDomain;
    }

    public String getUserEmail() {
        return userEmail;
    }

    public void setUserEmail(String userEmail) {
        this.userEmail = userEmail;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }
}
