
package com.monsanto.eas.sappasswordtool.wsclient.resetpassword;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.monsanto.eas.sappasswordtool.wsclient.resetpassword package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _YPWDRESETWRAPPERException_QNAME = new QName("urn:sap-com:document:sap:rfc:functions", "Y_PWD_RESET_WRAPPER.Exception");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.monsanto.eas.sappasswordtool.wsclient.resetpassword
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link YPWDRESETWRAPPERRfcException }
     * 
     */
    public YPWDRESETWRAPPERRfcException createYPWDRESETWRAPPERRfcException() {
        return new YPWDRESETWRAPPERRfcException();
    }

    /**
     * Create an instance of {@link RfcExceptionMessage }
     * 
     */
    public RfcExceptionMessage createRfcExceptionMessage() {
        return new RfcExceptionMessage();
    }

    /**
     * Create an instance of {@link YPWDRESETWRAPPER }
     * 
     */
    public YPWDRESETWRAPPER createYPWDRESETWRAPPER() {
        return new YPWDRESETWRAPPER();
    }

    /**
     * Create an instance of {@link YPWDRESETWRAPPERResponse }
     * 
     */
    public YPWDRESETWRAPPERResponse createYPWDRESETWRAPPERResponse() {
        return new YPWDRESETWRAPPERResponse();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link YPWDRESETWRAPPERRfcException }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:sap-com:document:sap:rfc:functions", name = "Y_PWD_RESET_WRAPPER.Exception")
    public JAXBElement<YPWDRESETWRAPPERRfcException> createYPWDRESETWRAPPERException(YPWDRESETWRAPPERRfcException value) {
        return new JAXBElement<YPWDRESETWRAPPERRfcException>(_YPWDRESETWRAPPERException_QNAME, YPWDRESETWRAPPERRfcException.class, null, value);
    }

}
