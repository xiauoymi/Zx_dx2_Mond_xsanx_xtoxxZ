package com.monsanto.eas.sappasswordtool.utils;

/**
 * Created by IntelliJ IDEA.
 * User: rrpand5
 * Date: 10/11/12
 * Time: 2:36 PM
 * To change this template use File | Settings | File Templates.
 */
public class SAPPasswordToolConstants {
    public static final String LOGGED_IN_USER = "loggedInUser";
    public static final String USER_INFO = "userInfo";
    public static final String DOMAIN_NAMES = "domainNames";
    public static final String LDAP_CTX_FACTORY = "com.sun.jndi.ldap.LdapCtxFactory";
    public static final String SECURITY_AUTH = "simple";
    public static final String AD_DOMAIN_PROP_SUFFIX = ".domain";
    public static final String AD_HOST_PROP_SUFFIX = ".host";
    public static final String AD_DC_PROP_SUFFIX = ".dc";
    public static final String AD_SEARCH_BASE_CONSTANT_PROP = ",DC=ds,DC=monsanto,DC=com";
    public static final int MAX_PASSWORD_RESET_EXCEED_NUMBER = 5;
    public static final String MAX_PASSWORD_RESET_COUNT = "MaxPasswordResetCount";
    public static final String MAX_PASSWORD_RESET_COUNT_REACHED = "MaxPasswordResetCountReached";
}
