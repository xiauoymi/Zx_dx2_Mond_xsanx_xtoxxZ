package com.monsanto.eas.sappasswordtool.comparator;

import com.monsanto.eas.sappasswordtool.to.SAPSystemDetailsTO;
import org.springframework.stereotype.Component;

import java.io.Serializable;
import java.util.Comparator;

/**
 * Created by IntelliJ IDEA.
 * User: CCCC1
 * Date: 5/23/13
 * Time: 10:50 AM
 * To change this template use File | Settings | File Templates.
 */
@Component
public class SapSystemComparator implements Comparator<SAPSystemDetailsTO>, Serializable {

    @Override
    public int compare(SAPSystemDetailsTO systemDetails1, SAPSystemDetailsTO systemDetails2) {
        return systemDetails1.getSapSystemDesc().compareTo(systemDetails2.getSapSystemDesc());
    }
}
