package com.monsanto.eas.sappasswordtool.view.controller;

import com.monsanto.Util.StringUtils;
import com.monsanto.eas.sappasswordtool.comparator.SapSystemComparator;
import com.monsanto.eas.sappasswordtool.to.SAPSystemDetailsTO;
import com.monsanto.eas.sappasswordtool.to.UserDetailsTO;
import com.monsanto.eas.sappasswordtool.utils.SAPPasswordToolConstants;
import com.monsanto.eas.sappasswordtool.utils.SAPPasswordToolErrors;
import com.monsanto.eas.sappasswordtool.view.bo.SapSystemBO;
import com.monsanto.eas.sappasswordtool.view.validator.SapSystemValidator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.RedirectView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.PrintWriter;
import java.util.Collections;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: CCCC1
 * Date: 5/6/13
 * Time: 12:06 PM
 * To change this template use File | Settings | File Templates.
 */
@Controller
public class SapSystemController extends BaseController {
    private static final String RESET_PASSWORD_VIEW = "resetPassword";
     private static final String SAP_SYSTEM_LIST_VIEW = "sapSystemList";

    private SapSystemBO sapSystemBO;
    private SapSystemValidator sapSystemValidator;
    private SapSystemComparator SapSystemComparator;

    @Autowired
    public SapSystemController(SapSystemBO sapSystemBO, SapSystemValidator sapSystemValidator, SapSystemComparator SapSystemComparator) {
        this.sapSystemBO = sapSystemBO;
        this.sapSystemValidator = sapSystemValidator;
        this.SapSystemComparator = SapSystemComparator;
    }

    @RequestMapping(value = "/sapSystem.do")
    public ModelAndView displayDefaultPage(HttpServletRequest request, HttpServletResponse response, HttpSession session) throws Exception {
        logger.debug("Preparing to load sapSystemList page.");

        ModelAndView modelAndView = new ModelAndView();
        UserDetailsTO userDetails = (UserDetailsTO) session.getAttribute(SAPPasswordToolConstants.USER_INFO);
        modelAndView.getModelMap().addAttribute("userDetails", userDetails);
        List<SAPSystemDetailsTO> sapSystemDetailsList = sapSystemBO.getSapServerInstanceList();
        Collections.sort(sapSystemDetailsList, SapSystemComparator);
        modelAndView.getModelMap().addAttribute("sapSystems", sapSystemDetailsList);
        session.setAttribute("sapSystems", sapSystemDetailsList);

        modelAndView.setViewName(SAP_SYSTEM_LIST_VIEW);

        return modelAndView;
    }

    @RequestMapping(value = "/resetSapSystem.do")
    public ModelAndView displayPasswordResetPage(HttpServletRequest request, HttpServletResponse response,@RequestParam("sapServerInstance") String sapServerInstance, HttpSession session, @ModelAttribute("userDetails") UserDetailsTO userDetails, BindingResult bindingResult) throws Exception {
        logger.debug("Preparing to load Reset Password page.");

        boolean resetFlag = false;
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.setViewName(SAP_SYSTEM_LIST_VIEW);
        UserDetailsTO userDetail = (UserDetailsTO) session.getAttribute(SAPPasswordToolConstants.USER_INFO);
        List<SAPSystemDetailsTO> sapSystemDetailsList = (List<SAPSystemDetailsTO>) session.getAttribute("sapSystems");
        userDetails.setUserName(null != userDetail ? userDetail.getUserName() : null);
        userDetails.setSapServerInstance(sapServerInstance);
        userDetails.setSapServerInstanceDesc(getServerInstanceDesc(sapSystemDetailsList,sapServerInstance));
        modelAndView.getModelMap().addAttribute("userDetails", userDetails);
        modelAndView.getModelMap().addAttribute("sapSystems", sapSystemDetailsList);
        sapSystemValidator.validate(userDetails, bindingResult);
        PrintWriter writer = response.getWriter();
        if (bindingResult.hasErrors()) {
            logger.debug("SAP Server Instance is required. Please select SAP Server Instance");
            response.sendError(501, SAPPasswordToolErrors.SAP_SERVER_INSTANCE_REQUIRED);
            writer.write(SAPPasswordToolErrors.SAP_SERVER_INSTANCE_REQUIRED);
            return modelAndView;
        } else {
            Integer resetCount = (Integer) session.getAttribute(SAPPasswordToolConstants.MAX_PASSWORD_RESET_COUNT);
            if (null == resetCount) {
                resetCount = new Integer(1);
                session.setAttribute(SAPPasswordToolConstants.MAX_PASSWORD_RESET_COUNT, resetCount);
                resetFlag= true;
                modelAndView.setViewName(RESET_PASSWORD_VIEW);
            } else {
                if (resetCount.intValue() == SAPPasswordToolConstants.MAX_PASSWORD_RESET_EXCEED_NUMBER) {
                    bindingResult.reject(SAPPasswordToolConstants.MAX_PASSWORD_RESET_COUNT_REACHED, SAPPasswordToolErrors.MAX_PASSWORD_RESET_COUNT_REACHED);
                    response.sendError(502, SAPPasswordToolErrors.MAX_PASSWORD_RESET_COUNT_REACHED);
                    writer.write(SAPPasswordToolErrors.MAX_PASSWORD_RESET_COUNT_REACHED);
                    logger.debug("Exceeds the maximum password reset tries for the user: " + (null != userDetail ? userDetail.getUserName() : null) + ",Please try on later...");
                } else {
                    resetCount = resetCount + 1;
                    session.setAttribute(SAPPasswordToolConstants.MAX_PASSWORD_RESET_COUNT, resetCount);
                    resetFlag = true;
                    modelAndView.setViewName(RESET_PASSWORD_VIEW);
                }
            }
            if(resetFlag){
                 SAPSystemDetailsTO detailsTO = sapSystemBO.getSapServerInstanceResetPassword(userDetails.getUserName(),userDetails.getSapServerInstance());
                if(null != detailsTO && StringUtils.isNullOrEmpty(detailsTO.getSapPasswordOut())){
                    modelAndView.setViewName(SAP_SYSTEM_LIST_VIEW);
                    bindingResult.reject(detailsTO.getSapSystemDesc(),detailsTO.getSapSystemDesc());
                    response.sendError(503,detailsTO.getSapSystemDesc());
                    writer.write(detailsTO.getSapSystemDesc());
                    logger.debug("Error Occured from the SAPSystem: "+detailsTO.getSapSystemDesc());
                }else
                   if(null != userDetails && null != detailsTO)
                         userDetails.setPassword(detailsTO.getSapPasswordOut());
            }
        }
        return modelAndView;
    }

    @RequestMapping(value = "/sapSystem.do", params = "home")
    public ModelAndView displayPreviousPage(HttpServletRequest request, HttpServletResponse response, HttpSession session) throws Exception {
        logger.debug("Loading the home page for the Back Navigation");

        ModelAndView modelAndView = new ModelAndView(new RedirectView("home.do"));
        return modelAndView;
    }

    private String getServerInstanceDesc(List<SAPSystemDetailsTO> sapSystemDetailsList,String selectedSapServerInstance){
             if(!StringUtils.isNullOrEmpty(selectedSapServerInstance)){
                 for(SAPSystemDetailsTO sapSystemDetails:sapSystemDetailsList){
                     if(selectedSapServerInstance.equals(sapSystemDetails.getSapSystemName()))
                         return sapSystemDetails.getSapSystemDesc();
                 }
             }
        return null;
    }
}
