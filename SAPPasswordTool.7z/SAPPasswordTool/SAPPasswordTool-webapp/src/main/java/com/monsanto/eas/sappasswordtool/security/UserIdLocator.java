package com.monsanto.eas.sappasswordtool.security;

/**
 * Created by IntelliJ IDEA.
 * User: CCCC1
 * Date: 5/29/13
 * Time: 1:29 PM
 * To change this template use File | Settings | File Templates.
 */
public interface UserIdLocator {

    String locateUserId();
}
