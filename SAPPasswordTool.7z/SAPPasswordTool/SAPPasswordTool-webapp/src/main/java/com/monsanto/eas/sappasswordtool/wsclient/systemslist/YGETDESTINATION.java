
package com.monsanto.eas.sappasswordtool.wsclient.systemslist;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="PREFIX_IN" type="{urn:sap-com:document:sap:rfc:functions}char32"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "prefixin"
})
@XmlRootElement(name = "Y_GET_DESTINATION")
public class YGETDESTINATION {

    @XmlElement(name = "PREFIX_IN", required = true)
    protected String prefixin;

    /**
     * Gets the value of the prefixin property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPREFIXIN() {
        return prefixin;
    }

    /**
     * Sets the value of the prefixin property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPREFIXIN(String value) {
        this.prefixin = value;
    }

}
