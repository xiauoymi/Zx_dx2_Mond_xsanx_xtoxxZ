package com.monsanto.eas.sappasswordtool.security;

/**
 * Created by IntelliJ IDEA.
 * User: CCCC1
 * Date: 5/29/13
 * Time: 2:28 PM
 * To change this template use File | Settings | File Templates.
 */
public class LocalUserIdLocator implements UserIdLocator{
    protected static final String SYS_PROP_USER_NAME = "user.name";

  @Override
  public String locateUserId() {
    String userId = System.getProperty(SYS_PROP_USER_NAME);
    if (userId != null) {
      userId = userId.toUpperCase();
    }
    return userId;
  }
}
