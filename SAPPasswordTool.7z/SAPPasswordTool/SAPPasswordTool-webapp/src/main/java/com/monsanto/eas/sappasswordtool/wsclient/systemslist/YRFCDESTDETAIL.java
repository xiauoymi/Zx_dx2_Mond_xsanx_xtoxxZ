
package com.monsanto.eas.sappasswordtool.wsclient.systemslist;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for YRFCDEST_DETAIL complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="YRFCDEST_DETAIL">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="RFCDEST" type="{urn:sap-com:document:sap:rfc:functions}char32"/>
 *         &lt;element name="RFCDOC1" type="{urn:sap-com:document:sap:rfc:functions}char72"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "YRFCDEST_DETAIL", propOrder = {
    "rfcdest",
    "rfcdoc1"
})
public class YRFCDESTDETAIL {

    @XmlElement(name = "RFCDEST", required = true)
    protected String rfcdest;
    @XmlElement(name = "RFCDOC1", required = true)
    protected String rfcdoc1;

    /**
     * Gets the value of the rfcdest property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRFCDEST() {
        return rfcdest;
    }

    /**
     * Sets the value of the rfcdest property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRFCDEST(String value) {
        this.rfcdest = value;
    }

    /**
     * Gets the value of the rfcdoc1 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRFCDOC1() {
        return rfcdoc1;
    }

    /**
     * Sets the value of the rfcdoc1 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRFCDOC1(String value) {
        this.rfcdoc1 = value;
    }

}
