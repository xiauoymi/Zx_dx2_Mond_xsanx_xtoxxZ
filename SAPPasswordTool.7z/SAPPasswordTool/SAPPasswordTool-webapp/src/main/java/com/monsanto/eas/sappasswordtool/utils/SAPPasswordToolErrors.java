package com.monsanto.eas.sappasswordtool.utils;

/**
 * Created by IntelliJ IDEA.
 * User: rrpand5
 * Date: 10/12/12
 * Time: 4:22 PM
 * To change this template use File | Settings | File Templates.
 */
public class SAPPasswordToolErrors {
    public static final String USER_DOMAIN_REQUIRED = "User Domain is required. Please select UserDomain";
    public static final String USERNAME_REQUIRED = "UserId is required. Please enter UserId";
    public static final String PASSWORD_REQUIRED = "Password is required. Please enter Password";
    public static final String INVALID_LOGIN = "Invalid login. Please check username/password";
    public static final String SAP_SERVER_INSTANCE_REQUIRED = "SAP Server Instance is required. Please select SAP Server Instance ";
    public static final String MAX_PASSWORD_RESET_COUNT_REACHED = "Exceeds the maximum password reset tries,Please try on later... ";
}
