package com.monsanto.eas.sappasswordtool.filter;

import com.monsanto.eas.sappasswordtool.security.LsiBasedUserIdLocatorFactory;
import com.monsanto.eas.sappasswordtool.security.UserIdLocatorFactory;
import com.monsanto.eas.sappasswordtool.utils.SAPPasswordToolConstants;
import org.springframework.web.filter.GenericFilterBean;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import java.io.IOException;

/**
 * Created by IntelliJ IDEA.
 * User: CCCC1
 * Date: 5/29/13
 * Time: 2:51 PM
 * To change this template use File | Settings | File Templates.
 */
public class LoggerContextFilter extends GenericFilterBean {

    private UserIdLocatorFactory userIdLocatorFactory;

    public LoggerContextFilter() {
        super();
        userIdLocatorFactory = new LsiBasedUserIdLocatorFactory();
    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
        String userId = "";
        try {
            userId = userIdLocatorFactory.getUserIdLocator().locateUserId();
            ((HttpServletRequest)request).getSession(true).setAttribute(SAPPasswordToolConstants.LOGGED_IN_USER,userId);
        } catch (Exception e) {
            // Ignore exception, logging problems shouldn't prevent application from running
        }
        chain.doFilter(request, response);

    }
}
