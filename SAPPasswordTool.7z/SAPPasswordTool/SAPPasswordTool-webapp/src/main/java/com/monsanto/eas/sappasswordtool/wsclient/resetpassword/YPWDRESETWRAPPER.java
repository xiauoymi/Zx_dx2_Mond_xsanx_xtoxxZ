
package com.monsanto.eas.sappasswordtool.wsclient.resetpassword;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="SAP_SYSTEM_IN" type="{urn:sap-com:document:sap:rfc:functions}char32"/>
 *         &lt;element name="SNC_IN" type="{urn:sap-com:document:sap:rfc:functions}char255" minOccurs="0"/>
 *         &lt;element name="USER_ACCOUNT_IN" type="{urn:sap-com:document:sap:rfc:functions}char12"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "sapsystemin",
    "sncin",
    "useraccountin"
})
@XmlRootElement(name = "Y_PWD_RESET_WRAPPER")
public class YPWDRESETWRAPPER {

    @XmlElement(name = "SAP_SYSTEM_IN", required = true)
    protected String sapsystemin;
    @XmlElement(name = "SNC_IN")
    protected String sncin;
    @XmlElement(name = "USER_ACCOUNT_IN", required = true)
    protected String useraccountin;

    /**
     * Gets the value of the sapsystemin property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSAPSYSTEMIN() {
        return sapsystemin;
    }

    /**
     * Sets the value of the sapsystemin property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSAPSYSTEMIN(String value) {
        this.sapsystemin = value;
    }

    /**
     * Gets the value of the sncin property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSNCIN() {
        return sncin;
    }

    /**
     * Sets the value of the sncin property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSNCIN(String value) {
        this.sncin = value;
    }

    /**
     * Gets the value of the useraccountin property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUSERACCOUNTIN() {
        return useraccountin;
    }

    /**
     * Sets the value of the useraccountin property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUSERACCOUNTIN(String value) {
        this.useraccountin = value;
    }

}
