package com.monsanto.eas.sappasswordtool.view.validator;

import com.monsanto.Util.StringUtils;
import com.monsanto.eas.sappasswordtool.to.UserDetailsTO;
import com.monsanto.eas.sappasswordtool.utils.SAPPasswordToolErrors;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

/**
 * Created by IntelliJ IDEA.
 * User: CCCC1
 * Date: 10/05/13
 * Time: 10:00 PM
 * To change this template use File | Settings | File Templates.
 */
@Component
public class LoginValidator implements Validator {

    @Override
    public boolean supports(Class<?> clazz) {
        return false;  //To change body of implemented methods use File | Settings | File Templates.
    }

    @Override
    public void validate(Object target, Errors errors) {
        UserDetailsTO loginDetails = (UserDetailsTO) target;
         if (StringUtils.isNullOrEmpty(loginDetails.getUserDomain())) {
            errors.reject("userDomain",SAPPasswordToolErrors.USER_DOMAIN_REQUIRED);
        }
        if (StringUtils.isNullOrEmpty(loginDetails.getUserName())) {
            errors.reject("userName",SAPPasswordToolErrors.USERNAME_REQUIRED);
        }
        if (StringUtils.isNullOrEmpty(loginDetails.getPassword())) {
            errors.reject("password", SAPPasswordToolErrors.PASSWORD_REQUIRED);
        }

    }
}
