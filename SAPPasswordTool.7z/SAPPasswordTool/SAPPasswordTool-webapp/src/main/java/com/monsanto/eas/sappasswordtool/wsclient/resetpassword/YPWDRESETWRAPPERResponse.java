
package com.monsanto.eas.sappasswordtool.wsclient.resetpassword;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="DESCR_OUT" type="{urn:sap-com:document:sap:rfc:functions}char80"/>
 *         &lt;element name="PASSWORD_OUT" type="{urn:sap-com:document:sap:rfc:functions}char8"/>
 *         &lt;element name="RESULT_OUT" type="{urn:sap-com:document:sap:rfc:functions}char2"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "descrout",
    "passwordout",
    "resultout"
})
@XmlRootElement(name = "Y_PWD_RESET_WRAPPERResponse")
public class YPWDRESETWRAPPERResponse {

    @XmlElement(name = "DESCR_OUT", required = true)
    protected String descrout;
    @XmlElement(name = "PASSWORD_OUT", required = true)
    protected String passwordout;
    @XmlElement(name = "RESULT_OUT", required = true)
    protected String resultout;

    /**
     * Gets the value of the descrout property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDESCROUT() {
        return descrout;
    }

    /**
     * Sets the value of the descrout property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDESCROUT(String value) {
        this.descrout = value;
    }

    /**
     * Gets the value of the passwordout property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPASSWORDOUT() {
        return passwordout;
    }

    /**
     * Sets the value of the passwordout property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPASSWORDOUT(String value) {
        this.passwordout = value;
    }

    /**
     * Gets the value of the resultout property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRESULTOUT() {
        return resultout;
    }

    /**
     * Sets the value of the resultout property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRESULTOUT(String value) {
        this.resultout = value;
    }

}
