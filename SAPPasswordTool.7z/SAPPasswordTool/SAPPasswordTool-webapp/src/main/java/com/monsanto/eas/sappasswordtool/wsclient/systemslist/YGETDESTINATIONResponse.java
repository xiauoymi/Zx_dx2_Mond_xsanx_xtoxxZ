
package com.monsanto.eas.sappasswordtool.wsclient.systemslist;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="DESCR_OUT" type="{urn:sap-com:document:sap:rfc:functions}char200"/>
 *         &lt;element name="RC" type="{urn:sap-com:document:sap:rfc:functions}char2"/>
 *         &lt;element name="RFCDEST_OUT" type="{urn:sap-com:document:sap:rfc:functions}YRFCDEST_DETAIL_TAB"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "descrout",
    "rc",
    "rfcdestout"
})
@XmlRootElement(name = "Y_GET_DESTINATIONResponse")
public class YGETDESTINATIONResponse {

    @XmlElement(name = "DESCR_OUT", required = true)
    protected String descrout;
    @XmlElement(name = "RC", required = true)
    protected String rc;
    @XmlElement(name = "RFCDEST_OUT", required = true)
    protected YRFCDESTDETAILTAB rfcdestout;

    /**
     * Gets the value of the descrout property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDESCROUT() {
        return descrout;
    }

    /**
     * Sets the value of the descrout property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDESCROUT(String value) {
        this.descrout = value;
    }

    /**
     * Gets the value of the rc property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRC() {
        return rc;
    }

    /**
     * Sets the value of the rc property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRC(String value) {
        this.rc = value;
    }

    /**
     * Gets the value of the rfcdestout property.
     * 
     * @return
     *     possible object is
     *     {@link YRFCDESTDETAILTAB }
     *     
     */
    public YRFCDESTDETAILTAB getRFCDESTOUT() {
        return rfcdestout;
    }

    /**
     * Sets the value of the rfcdestout property.
     * 
     * @param value
     *     allowed object is
     *     {@link YRFCDESTDETAILTAB }
     *     
     */
    public void setRFCDESTOUT(YRFCDESTDETAILTAB value) {
        this.rfcdestout = value;
    }

}
