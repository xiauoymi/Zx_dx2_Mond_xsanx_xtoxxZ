
package com.monsanto.eas.sappasswordtool.wsclient.systemslist;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.monsanto.eas.sappasswordtool.wsclient.systemslist package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _YGETDESTINATIONException_QNAME = new QName("urn:sap-com:document:sap:rfc:functions", "Y_GET_DESTINATION.Exception");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.monsanto.eas.sappasswordtool.wsclient.systemslist
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link YGETDESTINATIONRfcException }
     * 
     */
    public YGETDESTINATIONRfcException createYGETDESTINATIONRfcException() {
        return new YGETDESTINATIONRfcException();
    }

    /**
     * Create an instance of {@link YGETDESTINATION }
     * 
     */
    public YGETDESTINATION createYGETDESTINATION() {
        return new YGETDESTINATION();
    }

    /**
     * Create an instance of {@link RfcExceptionMessage }
     * 
     */
    public RfcExceptionMessage createRfcExceptionMessage() {
        return new RfcExceptionMessage();
    }

    /**
     * Create an instance of {@link YRFCDESTDETAIL }
     * 
     */
    public YRFCDESTDETAIL createYRFCDESTDETAIL() {
        return new YRFCDESTDETAIL();
    }

    /**
     * Create an instance of {@link YRFCDESTDETAILTAB }
     * 
     */
    public YRFCDESTDETAILTAB createYRFCDESTDETAILTAB() {
        return new YRFCDESTDETAILTAB();
    }

    /**
     * Create an instance of {@link YGETDESTINATIONResponse }
     * 
     */
    public YGETDESTINATIONResponse createYGETDESTINATIONResponse() {
        return new YGETDESTINATIONResponse();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link YGETDESTINATIONRfcException }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:sap-com:document:sap:rfc:functions", name = "Y_GET_DESTINATION.Exception")
    public JAXBElement<YGETDESTINATIONRfcException> createYGETDESTINATIONException(YGETDESTINATIONRfcException value) {
        return new JAXBElement<YGETDESTINATIONRfcException>(_YGETDESTINATIONException_QNAME, YGETDESTINATIONRfcException.class, null, value);
    }

}
