package com.monsanto.eas.sappasswordtool.security;

import com.monsanto.Util.EnvironmentHelper;
import org.springframework.stereotype.Component;

/**
 * Created by IntelliJ IDEA.
 * User: CCCC1
 * Date: 5/29/13
 * Time: 2:41 PM
 * To change this template use File | Settings | File Templates.
 */
@Component
public class LsiBasedUserIdLocatorFactory implements UserIdLocatorFactory {

    @Override
    public UserIdLocator getUserIdLocator() {
        UserIdLocator userIdLocator = (EnvironmentHelper.sf_cstrWin.equalsIgnoreCase(EnvironmentHelper.getFunction())) ?
                new LocalUserIdLocator() :
                new WAMUserIdLocator();
        return userIdLocator;
    }
}
