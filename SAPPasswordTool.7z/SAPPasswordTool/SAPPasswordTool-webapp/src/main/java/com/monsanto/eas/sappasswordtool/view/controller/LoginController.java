package com.monsanto.eas.sappasswordtool.view.controller;

import com.monsanto.eas.sappasswordtool.adauth.ADDomainProperties;
import com.monsanto.eas.sappasswordtool.security.UserIdLocator;
import com.monsanto.eas.sappasswordtool.security.WAMUserIdLocator;
import com.monsanto.eas.sappasswordtool.to.UserDetailsTO;
import com.monsanto.eas.sappasswordtool.utils.SAPPasswordToolConstants;
import com.monsanto.eas.sappasswordtool.utils.SAPPasswordToolErrors;
import com.monsanto.eas.sappasswordtool.view.bo.LoginBO;
import com.monsanto.eas.sappasswordtool.view.validator.LoginValidator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.RedirectView;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.Set;

/**
 * Created by IntelliJ IDEA.
 * User: CCCC1
 * Date: 5/6/13
 * Time: 10:00 AM
 * To change this template use File | Settings | File Templates.
 */
@Controller
public class LoginController extends BaseController {

    private static final String LOGIN_VIEW = "login";
    private static final String SAP_SYSTEM_VIEW = "sapSystem.do";
    private static final String USER_INFO = "userInfo";

    private LoginBO loginBO;
    private LoginValidator loginValidator;

    @Resource(name = "adDomainProperties")
    private Properties adProps;

    @Autowired
    public LoginController(LoginBO loginBO, LoginValidator loginValidator) {
        this.loginBO = loginBO;
        this.loginValidator = loginValidator;
    }

    @RequestMapping(value = "/login.do")
    public ModelAndView displayLoginPage(HttpServletRequest request, HttpServletResponse response, HttpSession session) throws Exception {
        logger.debug("Preparing to load login page.");


        ModelAndView modelAndView = new ModelAndView();
        UserDetailsTO userDetailsTO = new UserDetailsTO();
        userDetailsTO.setUserName((String)session.getAttribute(SAPPasswordToolConstants.LOGGED_IN_USER));
        modelAndView.getModelMap().addAttribute("loginForm", userDetailsTO);
        List<ADDomainProperties> adDomainProperties = getDomainNames();
        modelAndView.getModelMap().addAttribute("domains", adDomainProperties);
        session.setAttribute("domains", adDomainProperties);

        modelAndView.setViewName(LOGIN_VIEW);

        return modelAndView;
    }

    @RequestMapping(value = "/authenticate.do", params = "login", method = RequestMethod.POST)
    public ModelAndView authenticateUser(HttpServletRequest request, HttpServletResponse response, HttpSession session, @ModelAttribute("loginForm") UserDetailsTO userDetails, BindingResult bindingResult) throws Exception {
        logger.debug("Started doing the AD domain authentication.");
        ModelAndView modelAndView = new ModelAndView();
        List<ADDomainProperties> adDomainProperties = (List<ADDomainProperties>) session.getAttribute("domains");
        modelAndView.getModelMap().addAttribute("domains", adDomainProperties);
        loginValidator.validate(userDetails, bindingResult);
        if (!bindingResult.hasErrors()) {
            if (!loginBO.authenticateADUser(userDetails)) {

                logger.debug("Invalid Login for the user: "+userDetails.getUserName());

                bindingResult.reject("loginFailed", SAPPasswordToolErrors.INVALID_LOGIN);
                modelAndView.setViewName(LOGIN_VIEW);
            } else {
                logger.debug("Successfully Logged in for the user: "+userDetails.getUserName());
                session.setAttribute(USER_INFO, userDetails);
                modelAndView = new ModelAndView(new RedirectView(SAP_SYSTEM_VIEW));
            }
        } else {
            logger.debug("Login Failed due to empty input.");
            modelAndView.setViewName(LOGIN_VIEW);
        }
        return modelAndView;
    }

    @RequestMapping(value = "/authenticate.do", params = "home")
    public ModelAndView displayHomePage(HttpServletRequest request, HttpServletResponse response, HttpSession session) throws Exception {
        logger.debug("Loading the Home Page for the Back Navigation");

        ModelAndView modelAndView = new ModelAndView(new RedirectView("home.do"));

        return modelAndView;
    }

    public void setAdProps(Properties adProps) {
        this.adProps = adProps;
    }

    private List<ADDomainProperties> getDomainNames() {
        logger.debug("Loading all domain names.");

        Set<String> adPropNames = adProps.stringPropertyNames();
        List<ADDomainProperties> domainNames = new ArrayList<ADDomainProperties>();
        for (String propName : adPropNames) {
            if (propName.contains(".domain")) {
                ADDomainProperties domainProperties = new ADDomainProperties();
                domainProperties.setDomain(adProps.getProperty(propName));
                domainNames.add(domainProperties);
            }
        }
        logger.debug("Total Domain names = " + domainNames.size());

        return domainNames;
    }

}