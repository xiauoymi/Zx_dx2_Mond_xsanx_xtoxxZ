package com.monsanto.eas.sappasswordtool.view.controller;

import org.apache.log4j.Logger;
import org.codehaus.plexus.util.ExceptionUtils;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

/**
 * Created by IntelliJ IDEA.
 * User: CCCC1
 * Date: 5/6/13
 * Time: 10:00 AM
 * To change this template use File | Settings | File Templates.
 */
public class BaseController {

    private static final String ERROR_VIEW = "/error";
    Logger logger = Logger.getLogger(this.getClass());

    @ExceptionHandler(Throwable.class)
    public ModelAndView handleException(HttpServletRequest request, Exception exception) {
        logger.error(ExceptionUtils.getStackTrace(exception));
        request.setAttribute("exceptionStackTrace", ExceptionUtils.getStackTrace(exception));
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.setViewName(ERROR_VIEW);
        return modelAndView;
    }
}
