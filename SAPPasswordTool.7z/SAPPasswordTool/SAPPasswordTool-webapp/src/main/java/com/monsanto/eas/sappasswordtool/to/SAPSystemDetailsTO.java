package com.monsanto.eas.sappasswordtool.to;

import java.io.Serializable;

/**
 * Created by IntelliJ IDEA.
 * User: CCCC1
 * Date: 5/6/13
 * Time: 12:45 PM
 * To change this template use File | Settings | File Templates.
 */
public class SAPSystemDetailsTO implements Serializable {

    private String sapSystemName;
    private String sapSystemDesc;
    private String sapPasswordOut;
    private String sapResultOut;


    public void setSapPasswordOut(String sapPasswordOut) {
        this.sapPasswordOut = sapPasswordOut;
    }

    public String getSapPasswordOut() {
        return sapPasswordOut;
    }

    public void setSapResultOut(String sapResultOut) {
        this.sapResultOut = sapResultOut;
    }

    public String getSapResultOut() {
        return sapResultOut;
    }


    public String getSapSystemDesc() {
        return sapSystemDesc;
    }

    public void setSapSystemDesc(String sapSystemDesc) {
        this.sapSystemDesc = sapSystemDesc;
    }

    public String getSapSystemName() {
        return sapSystemName;
    }

    public void setSapSystemName(String sapSystemName) {
        this.sapSystemName = sapSystemName;
    }


}
