package com.monsanto.eas.sappasswordtool.view.bo;

import com.monsanto.eas.sappasswordtool.adauth.ADAuthenticator;
import com.monsanto.eas.sappasswordtool.to.UserDetailsTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Map;

/**
 * Created by IntelliJ IDEA.
 * User: CCCC1
 * Date: 5/6/13
 * Time: 10:00 AM
 * To change this template use File | Settings | File Templates.
 */
@Component
public class LoginBO {

    @Autowired
    ADAuthenticator adAuthenticator;

    public boolean authenticateADUser(UserDetailsTO userDetails) throws Exception {
        boolean validUser = false;
        Map userAttributes = adAuthenticator.authenticate(userDetails);
        if(userAttributes != null) {
            validUser = true;
            userDetails.setFirstName((String)userAttributes.get("givenName"));
            userDetails.setLastName((String)userAttributes.get("sn"));
            userDetails.setUserEmail((String)userAttributes.get("mail"));
        }
        return validUser;

    }

    public void setAdAuthenticator(ADAuthenticator adAuthenticator) {
        this.adAuthenticator = adAuthenticator;
    }

}
