package com.monsanto.eas.sappasswordtool.adauth;

/**
 * Created by IntelliJ IDEA.
 * User: rrpand5
 * Date: 10/12/12
 * Time: 10:50 AM
 * To change this template use File | Settings | File Templates.
 */
public class ADDomainProperties {
    private String ldapHost;
    private String domain;
    private String searchBase;

    public String getLdapHost() {
        return ldapHost;
    }

    public void setLdapHost(String ldapHost) {
        this.ldapHost = ldapHost;
    }

    public String getDomain() {
        return domain;
    }

    public void setDomain(String domain) {
        this.domain = domain;
    }

    public String getSearchBase() {
        return searchBase;
    }

    public void setSearchBase(String searchBase) {
        this.searchBase = searchBase;
    }
}
