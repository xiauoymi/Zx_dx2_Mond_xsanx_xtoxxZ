package com.monsanto.eas.sappasswordtool.handler;


import com.monsanto.isdclient.soaphandler.WsSecuritySoapHandler;

import javax.xml.ws.handler.Handler;
import javax.xml.ws.handler.HandlerResolver;
import javax.xml.ws.handler.PortInfo;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: CCCC1
 * Date: Feb 19, 2010
 * Time: 2:18:16 PM
 * To change this template use File | Settings | File Templates.
 */
public class SecurityHandlerResolver implements HandlerResolver {
    private WsSecuritySoapHandler soapHandler = null;
    private List<Handler> handlerList = new ArrayList<Handler>();

    public SecurityHandlerResolver(String userName, String password) {
        this.soapHandler = new WsSecuritySoapHandler(userName, password);
        handlerList.add(soapHandler);
    }

    public List<Handler> getHandlerChain(PortInfo portInfo) {
        return handlerList;
    }
}
