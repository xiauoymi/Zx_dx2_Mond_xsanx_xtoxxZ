
package com.monsanto.eas.sappasswordtool.wsclient.resetpassword;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for Y_PWD_RESET_WRAPPER.RfcExceptions.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="Y_PWD_RESET_WRAPPER.RfcExceptions">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="UNEXPECTED_ERROR_IN_UNLOCK"/>
 *     &lt;enumeration value="SYSTEM_LOCKED"/>
 *     &lt;enumeration value="ACCOUNT_NOT_FOUND"/>
 *     &lt;enumeration value="SAP_SYSTEM_UNAVAILABLE"/>
 *     &lt;enumeration value="UNKNOWN_SAP_SYSTEM"/>
 *     &lt;enumeration value="USER_ACCOUNT_LOCKED"/>
 *     &lt;enumeration value="NO_ERROR"/>
 *     &lt;enumeration value="UNEXPECTED_ERROR_IN_RESET"/>
 *     &lt;enumeration value="ACCOUNT_INACTIVE"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "Y_PWD_RESET_WRAPPER.RfcExceptions")
@XmlEnum
public enum YPWDRESETWRAPPERRfcExceptions {

    UNEXPECTED_ERROR_IN_UNLOCK,
    SYSTEM_LOCKED,
    ACCOUNT_NOT_FOUND,
    SAP_SYSTEM_UNAVAILABLE,
    UNKNOWN_SAP_SYSTEM,
    USER_ACCOUNT_LOCKED,
    NO_ERROR,
    UNEXPECTED_ERROR_IN_RESET,
    ACCOUNT_INACTIVE;

    public String value() {
        return name();
    }

    public static YPWDRESETWRAPPERRfcExceptions fromValue(String v) {
        return valueOf(v);
    }

}
