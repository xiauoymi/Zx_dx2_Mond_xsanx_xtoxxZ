package com.monsanto.eas.sappasswordtool.view.bo;

import com.monsanto.eas.sappasswordtool.config.PasswordResetServicesConfiguration;
import com.monsanto.eas.sappasswordtool.to.SAPSystemDetailsTO;
import com.monsanto.eas.sappasswordtool.wsclient.resetpassword.YESYPWDRESETWRAPPER;
import com.monsanto.eas.sappasswordtool.wsclient.systemslist.YESYGETDESTINATION;
import com.monsanto.eas.sappasswordtool.wsclient.systemslist.YRFCDESTDETAIL;
import com.monsanto.eas.sappasswordtool.wsclient.systemslist.YRFCDESTDETAILTAB;
import org.springframework.stereotype.Component;

import javax.xml.ws.Holder;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: CCCC1
 * Date: 5/13/13
 * Time: 2:34 PM
 * To change this template use File | Settings | File Templates.
 */
@Component
public class SapSystemBO {

    private YESYGETDESTINATION getDestinationPort;
    private YESYPWDRESETWRAPPER pwdResetPort;

    public List<SAPSystemDetailsTO> getSapServerInstanceList() {

        String prefixIn = "PSS";
        Holder<String> desc = new Holder<String>();
        Holder<String> rc = new Holder<String>();
        Holder<YRFCDESTDETAILTAB> yrfcdestdetailtab = new Holder<YRFCDESTDETAILTAB>();
        try {

            getDestinationPort = PasswordResetServicesConfiguration.getDestinationService();
            getDestinationPort.yGETDESTINATION(prefixIn, desc, rc, yrfcdestdetailtab);

        } catch (Exception e) {
            e.printStackTrace();
        }
        return populateSapSystemList(yrfcdestdetailtab);
    }


    public SAPSystemDetailsTO getSapServerInstanceResetPassword(String userAccount, String sapSystem) throws Exception {
        String sncIn = null;
        Holder<String> descrOUT = new Holder<String>();
        Holder<String> passwordOUT = new Holder<String>();
        Holder<String> resultOUT = new Holder<String>();

        pwdResetPort = PasswordResetServicesConfiguration.getResetPasswordService();
        pwdResetPort.yPWDRESETWRAPPER(sapSystem, sncIn, userAccount, descrOUT, passwordOUT, resultOUT);

        return getSapSystemDetail(descrOUT,passwordOUT,resultOUT);
    }


    private List<SAPSystemDetailsTO> populateSapSystemList(Holder<YRFCDESTDETAILTAB> yrfcdestdetailtab) {

        List<SAPSystemDetailsTO> sapSystemList = new ArrayList<SAPSystemDetailsTO>();
        if (null != yrfcdestdetailtab) {
            SAPSystemDetailsTO detailsTO = null;
            for (YRFCDESTDETAIL detail : yrfcdestdetailtab.value.getItem()) {
                detailsTO = new SAPSystemDetailsTO();
                detailsTO.setSapSystemName(detail.getRFCDEST());
                detailsTO.setSapSystemDesc(detail.getRFCDOC1());
                sapSystemList.add(detailsTO);
            }
        }
        return sapSystemList;
    }

    private SAPSystemDetailsTO getSapSystemDetail(Holder<String> descrOUT, Holder<String> passwordOUT, Holder<String> resultOUT) {
        SAPSystemDetailsTO detailsTO = new SAPSystemDetailsTO();
        detailsTO.setSapSystemDesc(descrOUT.value);
        detailsTO.setSapPasswordOut(passwordOUT.value);
        detailsTO.setSapResultOut(resultOUT.value);

        return detailsTO;

    }

}
