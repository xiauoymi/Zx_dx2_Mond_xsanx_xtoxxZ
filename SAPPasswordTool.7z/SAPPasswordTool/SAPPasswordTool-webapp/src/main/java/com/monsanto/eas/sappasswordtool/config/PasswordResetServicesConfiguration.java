package com.monsanto.eas.sappasswordtool.config;

import com.monsanto.Util.EnvironmentAwareResourceBundle;
import com.monsanto.Util.EnvironmentHelperException;
import com.monsanto.Util.databasepasswordencryption.EncryptionUtils;
import com.monsanto.eas.sappasswordtool.wsclient.systemslist.YESYGETDESTINATION;
import com.monsanto.eas.sappasswordtool.handler.SecurityHandlerResolver;
import com.monsanto.eas.sappasswordtool.wsclient.resetpassword.YESYPWDRESETWRAPPER;
import org.springframework.context.annotation.Configuration;
import org.springframework.remoting.jaxws.JaxWsPortProxyFactoryBean;

import java.net.URI;

/**
 * Created by IntelliJ IDEA.
 * User: CCCC1
 * Date: 09/05/2013
 * Time: 10:49 AM
 * To change this template use File | Settings | File Templates.
 */
@Configuration
public class PasswordResetServicesConfiguration {

    static final String GET_DESTINATION_WSDL_KEY = "getinstancelist.wsdl";
    static final String GET_DESTINATION_NAMESPACE_URI = "getinstancelist.namespace.uri";
    static final String GET_DESTINATION_SERVICE_NAME = "getinstancelist.service.name";
    static final String GET_DESTINATION_SERVICE_PORT = "getinstancelist.service.port";

    static final String PASSWORD_RESET_WSDL_KEY = "resetpassword.wsdl";
    static final String PASSWORD_RESET_NAMESPACE_URI = "resetpassword.namespace.uri";
    static final String PASSWORD_RESET_SERVICE_NAME = "resetpassword.service.name";
    static final String PASSWORD_RESET_SERVICE_PORT = "resetpassword.service.port";

    static final String SAP_SERVICE_USER_NAME = "sapservices.username";
    static final String SAP_SERVICE_KEY_FILE = "sapservices.keyfile";
    static final String SAP_SERVICE_ENCRYPTEDPASSWORD_FILE = "sapservices.encryptedPasswordFile";
    static final String STORAGE_VAR = "storageVar";
    static final String APP_FOLDER = "appFolderName";


    static final int GET_DESTINATION_SERVICE_ID = 1;
    static final int PASSWORD_RESET_SERVICE_ID = 2;




    public static JaxWsPortProxyFactoryBean getServiceProxy(int serviceId) throws Exception {
        String[] serviceConnectionInfo = getServiceConnectionInfo(serviceId);
        JaxWsPortProxyFactoryBean factoryBean = new JaxWsPortProxyFactoryBean();
        if("YES_Y_GET_DESTINATION".equals(serviceConnectionInfo[2]))
            factoryBean.setServiceInterface(YESYGETDESTINATION.class);
        else if("YES_Y_PWD_RESET_WRAPPER".equals(serviceConnectionInfo[2]))
            factoryBean.setServiceInterface(YESYPWDRESETWRAPPER.class);
        factoryBean.setWsdlDocumentUrl(new URI(serviceConnectionInfo[0]).toURL());
        factoryBean.setNamespaceUri(serviceConnectionInfo[1]);
        factoryBean.setServiceName(serviceConnectionInfo[2]);
        factoryBean.setPortName(serviceConnectionInfo[3]);
        String userName =  serviceConnectionInfo[4];
        String password = EncryptionUtils.GetDecryptedStringFromExternalStorage(serviceConnectionInfo[5],serviceConnectionInfo[6],serviceConnectionInfo[7],serviceConnectionInfo[8]);
        factoryBean.setHandlerResolver(new SecurityHandlerResolver(userName,password));
        factoryBean.setLookupServiceOnStartup(false);
        factoryBean.afterPropertiesSet();
        return factoryBean;
    }


    public static YESYGETDESTINATION getDestinationService() throws Exception {
        return (YESYGETDESTINATION) getServiceProxy(GET_DESTINATION_SERVICE_ID).getObject();
    }

    public static YESYPWDRESETWRAPPER getResetPasswordService() throws Exception {
        return (YESYPWDRESETWRAPPER) getServiceProxy(PASSWORD_RESET_SERVICE_ID).getObject();
    }

    private static String[] getServiceConnectionInfo(int reportServiceId) throws EnvironmentHelperException {
        String[] uriAndWsdl = new String[9];
        EnvironmentAwareResourceBundle resourceBundle = new EnvironmentAwareResourceBundle("sap-ws");

        switch (reportServiceId) {
            case GET_DESTINATION_SERVICE_ID:
                uriAndWsdl[0] = resourceBundle.getString(GET_DESTINATION_WSDL_KEY);
                uriAndWsdl[1] = resourceBundle.getString(GET_DESTINATION_NAMESPACE_URI);
                uriAndWsdl[2] = resourceBundle.getString(GET_DESTINATION_SERVICE_NAME);
                uriAndWsdl[3] = resourceBundle.getString(GET_DESTINATION_SERVICE_PORT);
                uriAndWsdl[4] = resourceBundle.getString(SAP_SERVICE_USER_NAME);
                uriAndWsdl[5] = resourceBundle.getString(STORAGE_VAR);
                uriAndWsdl[6] = resourceBundle.getString(APP_FOLDER);
                uriAndWsdl[7] = resourceBundle.getString(SAP_SERVICE_ENCRYPTEDPASSWORD_FILE);
                uriAndWsdl[8] = resourceBundle.getString(SAP_SERVICE_KEY_FILE);
                break;

            case PASSWORD_RESET_SERVICE_ID:
                uriAndWsdl[0] = resourceBundle.getString(PASSWORD_RESET_WSDL_KEY);
                uriAndWsdl[1] = resourceBundle.getString(PASSWORD_RESET_NAMESPACE_URI);
                uriAndWsdl[2] = resourceBundle.getString(PASSWORD_RESET_SERVICE_NAME);
                uriAndWsdl[3] = resourceBundle.getString(PASSWORD_RESET_SERVICE_PORT);
                uriAndWsdl[4] = resourceBundle.getString(SAP_SERVICE_USER_NAME);
                uriAndWsdl[5] = resourceBundle.getString(STORAGE_VAR);
                uriAndWsdl[6] = resourceBundle.getString(APP_FOLDER);
                uriAndWsdl[7] = resourceBundle.getString(SAP_SERVICE_ENCRYPTEDPASSWORD_FILE);
                uriAndWsdl[8] = resourceBundle.getString(SAP_SERVICE_KEY_FILE);
                break;

            default:
                uriAndWsdl = null;
                break;
        }
        return uriAndWsdl;
    }
}
