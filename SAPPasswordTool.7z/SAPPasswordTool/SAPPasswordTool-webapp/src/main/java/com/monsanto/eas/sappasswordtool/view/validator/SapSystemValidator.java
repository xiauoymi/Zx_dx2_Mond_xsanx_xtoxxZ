package com.monsanto.eas.sappasswordtool.view.validator;

import com.monsanto.Util.StringUtils;
import com.monsanto.eas.sappasswordtool.to.UserDetailsTO;
import com.monsanto.eas.sappasswordtool.utils.SAPPasswordToolErrors;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

/**
 * Created by IntelliJ IDEA.
 * User: CCCC1
 * Date: 5/15/13
 * Time: 11:20 AM
 * To change this template use File | Settings | File Templates.
 */
@Component
public class SapSystemValidator implements Validator {

    @Override
    public boolean supports(Class<?> clazz) {
        return false;  //To change body of implemented methods use File | Settings | File Templates.
    }

    @Override
    public void validate(Object target, Errors errors) {
        UserDetailsTO userDetails = (UserDetailsTO) target;
         if (StringUtils.isNullOrEmpty(userDetails.getSapServerInstance())) {
            errors.reject("sapServerInstance", SAPPasswordToolErrors.SAP_SERVER_INSTANCE_REQUIRED);
        }

    }
}
