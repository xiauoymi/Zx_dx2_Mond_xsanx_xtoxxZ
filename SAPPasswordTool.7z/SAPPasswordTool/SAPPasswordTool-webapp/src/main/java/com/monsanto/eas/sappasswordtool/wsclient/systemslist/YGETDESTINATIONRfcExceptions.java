
package com.monsanto.eas.sappasswordtool.wsclient.systemslist;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for Y_GET_DESTINATION.RfcExceptions.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="Y_GET_DESTINATION.RfcExceptions">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="UNDEFINED_ERROR"/>
 *     &lt;enumeration value="NO_ERROR"/>
 *     &lt;enumeration value="NO_MATCHES_FOUND"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "Y_GET_DESTINATION.RfcExceptions")
@XmlEnum
public enum YGETDESTINATIONRfcExceptions {

    UNDEFINED_ERROR,
    NO_ERROR,
    NO_MATCHES_FOUND;

    public String value() {
        return name();
    }

    public static YGETDESTINATIONRfcExceptions fromValue(String v) {
        return valueOf(v);
    }

}
