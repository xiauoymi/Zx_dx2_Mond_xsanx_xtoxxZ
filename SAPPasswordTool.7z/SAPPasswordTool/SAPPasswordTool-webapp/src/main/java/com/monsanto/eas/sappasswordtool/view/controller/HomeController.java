package com.monsanto.eas.sappasswordtool.view.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Created by IntelliJ IDEA.
 * User: CCCC1
 * Date: 5/1/13
 * Time: 7:09 PM
 * To change this template use File | Settings | File Templates.
 */
@Controller
public class HomeController extends BaseController {

    private static final String VIEW_NAME = "home";

    @RequestMapping(value = "/home.do",method = RequestMethod.GET)
    public ModelAndView displayLoginPage(HttpServletRequest request, HttpServletResponse response, HttpSession session) throws Exception {
        logger.debug("Preparing to load login page.");
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.setViewName(VIEW_NAME);
        return modelAndView;
    }

    @RequestMapping(value = "/sessionDestroy.do",method = RequestMethod.GET)
    public ModelAndView invalidateSession(HttpServletRequest request, HttpServletResponse response, HttpSession session) throws Exception {
        logger.debug("Preparing to load login page.");
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.setViewName(VIEW_NAME);
        request.getSession(false).invalidate();

        return modelAndView;
    }

}
