package com.monsanto.eas.sappasswordtool.security;

import weblogic.security.Security;

import javax.security.auth.Subject;
import java.security.Principal;

import java.util.Set;

/**
 * Created by IntelliJ IDEA.
 * User: CCCC1
 * Date: 5/29/13
 * Time: 1:31 PM
 * To change this template use File | Settings | File Templates.
 */
public class WAMUserIdLocator implements UserIdLocator{

    private Subject requestedSubject;

    public WAMUserIdLocator() {
    }

    // This constructor is mainly used for UTs so that we can inject the Subject.
    public WAMUserIdLocator(Subject requestedSubject) {
        this.requestedSubject = requestedSubject;
    }

    public String locateUserId() {
        Subject subject = getSubject();
        Set<Principal> principals = subject.getPrincipals();

        // There may be more than one principal.  If so, the one we want
        // will be the first one.
        String userId = null;
        if (!principals.isEmpty()) {
            userId = principals.iterator().next().getName();
        }
        if (userId != null) {
            userId = userId.toUpperCase();
        }
        return userId;
    }

    private Subject getSubject() {
        Subject subject = this.requestedSubject;
        if (subject == null) {
            subject = Security.getCurrentSubject();
        }
        return subject;
    }
}
