package com.monsanto.eas.sappasswordtool.filter;

import com.monsanto.eas.sappasswordtool.security.UserIdLocator;
import com.monsanto.eas.sappasswordtool.security.UserIdLocatorFactory;
import junit.framework.Assert;
import org.apache.log4j.MDC;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Matchers;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.runners.MockitoJUnitRunner;
import org.mockito.stubbing.Answer;
import org.springframework.test.util.ReflectionTestUtils;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

import static org.mockito.Mockito.*;

/**
 * Created by IntelliJ IDEA.
 * User: CCCC1
 * Date: 5/30/13
 * Time: 11:41 AM
 * To change this template use File | Settings | File Templates.
 */
@RunWith(MockitoJUnitRunner.class)
public class LoggerContextFilter_UT {

  private LoggerContextFilter filter;
  private String userInsideChain;
  private String requestIdInsideChain;

  @Before
  public void before() {
    filter = new LoggerContextFilter();
    userInsideChain = null;
  }

  @Test
  public void doFilterAddsUserIdAndRequestIdToLog4jMdc() throws IOException, ServletException {
    // Arrange
    HttpServletRequest mockRequest = mock(HttpServletRequest.class);
    HttpServletResponse mockResponse = mock(HttpServletResponse.class);
    FilterChain mockFilterChain = mock(FilterChain.class);
    doAnswer(new Answer<Void>() {
      public Void answer(InvocationOnMock invocationOnMock) throws Throwable {
        userInsideChain = (String) MDC.get("userId");
        requestIdInsideChain = (String) MDC.get("requestId");
        return null;
      }
    }).when(mockFilterChain).doFilter(Matchers.any(ServletRequest.class), Matchers.any(ServletResponse.class));
    String userId = "";
    UserIdLocator mockUserIdLocator = mock(UserIdLocator.class);
    when(mockUserIdLocator.locateUserId()).thenReturn(userId);
    UserIdLocatorFactory mockUserIdLocatorFactory = mock(UserIdLocatorFactory.class);
    when(mockUserIdLocatorFactory.getUserIdLocator()).thenReturn(mockUserIdLocator);
    ReflectionTestUtils.setField(filter, "userIdLocatorFactory", mockUserIdLocatorFactory);
    MDC.remove("userId");
    MDC.remove("requestId");
    // Act
    filter.doFilter(mockRequest, mockResponse, mockFilterChain);
    // Assert
    verify(mockFilterChain, times(1)).doFilter(mockRequest, mockResponse);
//     Assert.assertEquals(userInsideChain, userId);
    Assert.assertTrue(requestIdInsideChain == null);
    Assert.assertEquals(null, MDC.get("userId"));
    Assert.assertEquals(null, MDC.get("requestId"));
  }
}
