package com.monsanto.eas.sappasswordtool.wsclient.systemlist;

import com.monsanto.eas.sappasswordtool.handler.SecurityHandlerResolver;
import com.monsanto.eas.sappasswordtool.to.SAPSystemDetailsTO;
import com.monsanto.eas.sappasswordtool.view.bo.SapSystemBO;
import com.monsanto.eas.sappasswordtool.wsclient.systemslist.YESYGETDESTINATION;
import com.monsanto.eas.sappasswordtool.wsclient.systemslist.YRFCDESTDETAILTAB;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.context.annotation.Configuration;
import org.springframework.remoting.jaxws.JaxWsPortProxyFactoryBean;

import javax.xml.ws.Holder;
import java.net.URI;
import java.util.List;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertTrue;

/**
 * Created by IntelliJ IDEA.
 * User: CCCC1
 * Date: 6/19/13
 * Time: 11:18 AM
 * To change this template use File | Settings | File Templates.
 */
@RunWith(MockitoJUnitRunner.class)
@Configuration
public class YESYGETDESTINATIONService_AT {

    static final String GET_DESTINATION_WSDL_KEY = "http://services-dint.monsanto.com/Global_PasswordResetServices/GetInstanceList?wsdl";
    static final String GET_DESTINATION_NAMESPACE_URI = "urn:sap-com:document:sap:rfc:functions";
    static final String GET_DESTINATION_SERVICE_NAME = "YES_Y_GET_DESTINATION";
    static final String GET_DESTINATION_SERVICE_PORT = "YES_Y_GET_DESTINATIONSOAP";
    static final String SAP_SERVICE_USER_NAME = "NA1000SVC_PSWDTOOL";
    static final String SAP_SERVICE_USER_PASSWORD = "Mhng$397";


    private YESYGETDESTINATION yesygetdestinationPort;
    String prefixIn = "PSS";
    Holder<String> desc = null;
    Holder<String> rc = null;
    Holder<YRFCDESTDETAILTAB> yrfcdestdetailtab = null;

    @Before
    public void setup() throws Exception {
        desc = new Holder<String>();
        rc = new Holder<String>();
        yrfcdestdetailtab = new Holder<YRFCDESTDETAILTAB>();
        yesygetdestinationPort = getDestinationService();
    }

    @Test
    public void yGETDESTINATION() {
        yesygetdestinationPort.yGETDESTINATION(prefixIn, desc, rc, yrfcdestdetailtab);
        assertNotNull(yrfcdestdetailtab);
        assertTrue(yrfcdestdetailtab.value.getItem().size() > 0);
    }


    private YESYGETDESTINATION getDestinationService() throws Exception {

        JaxWsPortProxyFactoryBean factoryBean = new JaxWsPortProxyFactoryBean();
        factoryBean.setServiceInterface(YESYGETDESTINATION.class);
        factoryBean.setWsdlDocumentUrl(new URI(GET_DESTINATION_WSDL_KEY).toURL());
        factoryBean.setNamespaceUri(GET_DESTINATION_NAMESPACE_URI);
        factoryBean.setServiceName(GET_DESTINATION_SERVICE_NAME);
        factoryBean.setPortName(GET_DESTINATION_SERVICE_PORT);
        String userName = SAP_SERVICE_USER_NAME;
        String password = SAP_SERVICE_USER_PASSWORD;
        factoryBean.setHandlerResolver(new SecurityHandlerResolver(userName, password));
        factoryBean.setLookupServiceOnStartup(false);
        factoryBean.afterPropertiesSet();

        return (YESYGETDESTINATION) factoryBean.getObject();
    }
}
