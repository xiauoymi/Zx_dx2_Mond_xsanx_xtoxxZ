package com.monsanto.eas.sappasswordtool.view.validator;

import com.monsanto.eas.sappasswordtool.to.UserDetailsTO;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.validation.BindException;
import org.springframework.validation.BindingResult;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

/**
 * Created by IntelliJ IDEA.
 * User: CCCC1
 * Date: 5/16/13
 * Time: 1:00 PM
 * To change this template use File | Settings | File Templates.
 */
@RunWith(MockitoJUnitRunner.class)
public class SapSystemValidator_UT {

    private static final String SAP_SERVER_INSTANCE = "sapServerInstance";

    SapSystemValidator validator;
    BindingResult errors;

    @Before
    public void setUp() {
        errors = new BindException(new UserDetailsTO(), "UserDetailsTO");
        validator = new SapSystemValidator();
    }

    @Test
    public void validate_ReturnsNoErrors_WhenUserDetailsIsCorrect() {
        UserDetailsTO userDetailsTO = new UserDetailsTO();
        userDetailsTO.setSapServerInstance("SAPServerInstance");

        validator.validate(userDetailsTO, errors);

        assertTrue(!errors.hasErrors());
    }

     @Test
    public void validate_ReturnsErrors_WhenUserDetailsIsCorrect() {
        UserDetailsTO userDetailsTO = new UserDetailsTO();
        validator.validate(userDetailsTO, errors);

        assertTrue(errors.hasErrors());
        assertEquals(errors.getAllErrors().get(0).getCode(), SAP_SERVER_INSTANCE);
    }

     @Test
    public void supports(){
        assertFalse(validator.supports(this.getClass()));
    }

}
