package com.monsanto.eas.sappasswordtool.view.controller;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpSession;
import org.springframework.web.servlet.ModelAndView;

import java.sql.SQLException;

import static org.junit.Assert.assertNotNull;

/**
 * Created by IntelliJ IDEA.
 * User: CCCC1
 * Date: 5/13/13
 * Time: 10:46 AM
 * To change this template use File | Settings | File Templates.
 */
@RunWith(MockitoJUnitRunner.class)
public class BaseController_UT {

    private MockHttpServletRequest request;
    private MockHttpSession session;
    private BaseController controller;
    private final static String ERROR_VIEW = "/error";

    @Before
    public void setUp() {
        request = new MockHttpServletRequest();
        session = new MockHttpSession();
        controller = new BaseController();
    }

    @Test
    public void handleException() {
        SQLException exception = new SQLException("An Exception was thrown");

        ModelAndView view = controller.handleException(request, exception);

        assertNotNull(view);
        assertNotNull(request.getAttribute("exceptionStackTrace"));
    }

}
