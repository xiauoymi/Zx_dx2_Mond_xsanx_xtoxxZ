package com.monsanto.eas.sappasswordtool.comparator;

import com.monsanto.eas.sappasswordtool.to.SAPSystemDetailsTO;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;

import static junit.framework.Assert.assertTrue;

/**
 * Created by IntelliJ IDEA.
 * User: CCCC1
 * Date: 5/23/13
 * Time: 11:03 AM
 * To change this template use File | Settings | File Templates.
 */
@RunWith(MockitoJUnitRunner.class)
public class SapSystemComparator_UT {

    private SapSystemComparator testObject;

    @Before
    public void setup() {
        testObject = new SapSystemComparator();
    }

    @Test
    public void compare_sapSystems() {
        assertTrue(testObject.compare(createSapSystem("# MON - P05 Process Integration (XI) Production"), createSapSystem("# MON - P06 Solution Manager Production")) < 0);
        assertTrue(testObject.compare(createSapSystem("# MON - P05 Process Integration (XI) Production"),
                createSapSystem("# MON - P05 Process Integration (XI) Production")) == 0);
        assertTrue(testObject.compare(createSapSystem("# MON - P06 Solution Manager Production"),
                createSapSystem("# MON - P05 Process Integration (XI) Production")) > 0);
    }

    private SAPSystemDetailsTO createSapSystem(String sapSystemDec) {
        SAPSystemDetailsTO systemDetail = new SAPSystemDetailsTO();
        systemDetail.setSapSystemDesc(sapSystemDec);

        return systemDetail;
    }

}
