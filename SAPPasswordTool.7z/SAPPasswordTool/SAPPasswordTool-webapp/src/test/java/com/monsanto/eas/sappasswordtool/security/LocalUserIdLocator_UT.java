package com.monsanto.eas.sappasswordtool.security;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

/**
 * Created by IntelliJ IDEA.
 * User: CCCC1
 * Date: 5/30/13
 * Time: 11:19 AM
 * To change this template use File | Settings | File Templates.
 */
@RunWith(MockitoJUnitRunner.class)
public class LocalUserIdLocator_UT {

    private static final String SYS_PROP_USER_NAME = "user.name";
    private String originalUserName;
    private UserIdLocator userIdLocator;

  @Before
  public void setUp() {
    originalUserName = System.getProperty(SYS_PROP_USER_NAME);
    System.clearProperty(SYS_PROP_USER_NAME);
    userIdLocator = new LocalUserIdLocator();
  }

  @After
  public void tearDown() {
    System.setProperty(SYS_PROP_USER_NAME, originalUserName);
  }

  @Test
  public void locateUserId_ReturnsSetValue() throws Exception {
    final String expectedUserName = "UT";
    System.setProperty(SYS_PROP_USER_NAME, expectedUserName);

    final String actualUserName = userIdLocator.locateUserId();

    assertEquals(expectedUserName, actualUserName);
  }

  @Test
  public void locateUserId_ReturnsNullWhenNothingSet() throws Exception {
    final String actualUserName = userIdLocator.locateUserId();

    assertNull(actualUserName);
  }
}
