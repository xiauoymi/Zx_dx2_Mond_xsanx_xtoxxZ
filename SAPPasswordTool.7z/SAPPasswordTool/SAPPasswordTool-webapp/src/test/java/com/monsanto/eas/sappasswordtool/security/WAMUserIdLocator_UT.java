package com.monsanto.eas.sappasswordtool.security;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.test.util.ReflectionTestUtils;

import javax.security.auth.Subject;
import java.security.Principal;
import java.util.HashSet;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

/**
 * Created by IntelliJ IDEA.
 * User: CCCC1
 * Date: 5/30/13
 * Time: 11:27 AM
 * To change this template use File | Settings | File Templates.
 */
@RunWith(MockitoJUnitRunner.class)
public class WAMUserIdLocator_UT {

    private UserIdLocator userIdLocator;

    @Before
    public void setUp() {
        userIdLocator = new WAMUserIdLocator();
    }

    @Test
    public void locateUserId_NormalCase() throws Exception {
        String expectedUserId = "MYUSER";
        createSubject(expectedUserId);
        String actualUserId = userIdLocator.locateUserId();
        assertEquals(expectedUserId, actualUserId);
    }

    @Test
    public void locateUserId_NotUpperCase() throws Exception {
        String submittedUserId = "MyUser";
        String expectedUserId = "MYUSER";
        createSubject(submittedUserId);
        String actualUserId = userIdLocator.locateUserId();
        assertEquals(expectedUserId, actualUserId);
    }

    @Test
    public void locateUserId_NotFound() throws Exception {
        String expectedUserId = null;
        createSubject(expectedUserId);
        String actualUserId = userIdLocator.locateUserId();
        assertEquals(expectedUserId, actualUserId);
    }

    @Test(expected = SecurityException.class)
    public void locateUserId_SubjectNotFound() throws Exception {
        // In our test environment, this will raise an exception because the security
        // will not be enabled as it will if running under WebLogic.  So we simply
        // make sure the proper exception is thrown, but this test shows that we would
        // be hitting the 'real' security model.
        userIdLocator.locateUserId();
    }

    private void createSubject(String userId) throws Exception {
        HashSet unusedArgument = new HashSet();
        HashSet<Principal> principals = new HashSet<Principal>();
        if (userId != null) {
            Principal principal = mock(Principal.class);
            when(principal.getName()).thenReturn(userId);
            principals.add(principal);
        }
        ReflectionTestUtils
                .setField(userIdLocator, "requestedSubject", new Subject(true, principals, unusedArgument, unusedArgument));
    }

}
