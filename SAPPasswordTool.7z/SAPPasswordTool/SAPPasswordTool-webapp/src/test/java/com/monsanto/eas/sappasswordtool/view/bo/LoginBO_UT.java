package com.monsanto.eas.sappasswordtool.view.bo;

import com.monsanto.eas.sappasswordtool.adauth.ADAuthenticator;
import com.monsanto.eas.sappasswordtool.to.UserDetailsTO;
import com.monsanto.eas.sappasswordtool.view.bo.LoginBO;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.HashMap;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/**
 * Created by IntelliJ IDEA.
 * User: CCCC1
 * Date: 13/05/13
 * Time: 1:30 PM
 * To change this template use File | Settings | File Templates.
 */
@RunWith(MockitoJUnitRunner.class)
public class LoginBO_UT {
    private ADAuthenticator adAuthenticator;
    private LoginBO loginBO;

    @Before
    public void setUp() {
        adAuthenticator = Mockito.mock(ADAuthenticator.class);
        loginBO = new LoginBO();
        loginBO.setAdAuthenticator(adAuthenticator);
    }

    @Test
    public void authenticateADUser_ReturnsTrue_WhenUserIsValid() throws Exception {
        UserDetailsTO userDetails = new UserDetailsTO();
        userDetails.setUserName("jhuer");
        userDetails.setUserDomain("NORTH_AMERCIA");
        userDetails.setPassword("Pa$$w0rd");
        when(adAuthenticator.authenticate(userDetails)).thenReturn(new HashMap());

        boolean validUser = loginBO.authenticateADUser(userDetails);

        assertTrue(validUser);
        verify(adAuthenticator).authenticate(userDetails);

    }
    @Test
    public void authenticateADUser_ReturnsFalse_WhenUserIsInvalid() throws Exception {
        UserDetailsTO userDetails = new UserDetailsTO();
        userDetails.setUserName("jhuer");
        userDetails.setUserDomain("NORTH_AMERCIA");
        userDetails.setPassword("Pa$$w0rd");
        when(adAuthenticator.authenticate(userDetails)).thenReturn(null);

        boolean validUser = loginBO.authenticateADUser(userDetails);

        assertFalse(validUser);
        verify(adAuthenticator).authenticate(userDetails);

    }
}
