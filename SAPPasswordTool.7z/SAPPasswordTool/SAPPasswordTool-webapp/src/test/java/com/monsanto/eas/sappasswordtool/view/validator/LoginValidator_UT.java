package com.monsanto.eas.sappasswordtool.view.validator;

import com.monsanto.eas.sappasswordtool.to.UserDetailsTO;
import com.monsanto.eas.sappasswordtool.view.validator.LoginValidator;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.validation.BindException;
import org.springframework.validation.BindingResult;

import static org.junit.Assert.*;

/**
 * Created by IntelliJ IDEA.
 * User: CCCC1
 * Date: 13/05/13
 * Time: 09:06 AM
 * To change this template use File | Settings | File Templates.
 */
@RunWith(MockitoJUnitRunner.class)
public class LoginValidator_UT {

    private static final String USER_NAME = "userName";
    private static final String PASSWORD = "password";
    private static final String USER_DOMAIN = "userDomain";

    LoginValidator validator;
    BindingResult errors;

    @Before
    public void setUp() {
        errors = new BindException(new UserDetailsTO(), "UserDetailsTO");
        validator = new LoginValidator();
    }

    @Test
    public void validate_ReturnsNoErrors_WhenUserDetailsIsCorrect() {
        UserDetailsTO userDetailsTO = new UserDetailsTO();
        userDetailsTO.setUserName("jhuer");
        userDetailsTO.setPassword("passW0rd");
        userDetailsTO.setUserDomain("domain");

        validator.validate(userDetailsTO, errors);

        assertTrue(!errors.hasErrors());
    }

    @Test
    public void validate_ReturnsErrors_WhenUserDetailsIsEmpty() {
        UserDetailsTO userDetailsTO = new UserDetailsTO();

        validator.validate(userDetailsTO, errors);

        assertTrue(errors.hasErrors());
        assertTrue(errors.getErrorCount() == new Integer(3));
    }

    @Test
    public void validate_ReturnsErrors_WhenNoUserNameWasTyped(){
        UserDetailsTO userDetailsTO = new UserDetailsTO();
        userDetailsTO.setUserDomain("domain");
        userDetailsTO.setPassword("password");

        validator.validate(userDetailsTO, errors);

        assertEquals(errors.getAllErrors().get(0).getCode(),USER_NAME);
    }

    @Test
    public void validate_ReturnsErrors_WhenNoPasswordWasTyped(){
        UserDetailsTO userDetailsTO = new UserDetailsTO();
        userDetailsTO.setUserName("userName");
        userDetailsTO.setUserDomain("domain");


        validator.validate(userDetailsTO, errors);

        assertEquals(errors.getAllErrors().get(0).getCode(),PASSWORD);
    }

    @Test
    public void validate_ReturnsErrors_WhenNoUserDomainWasTyped(){
        UserDetailsTO userDetailsTO = new UserDetailsTO();
        userDetailsTO.setUserName("userName");
        userDetailsTO.setPassword("password");


        validator.validate(userDetailsTO, errors);

        assertEquals(errors.getAllErrors().get(0).getCode(),USER_DOMAIN);
    }

    @Test
    public void supports(){
        assertFalse(validator.supports(this.getClass()));
    }

}
