package com.monsanto.eas.sappasswordtool.security;

import com.monsanto.Util.EnvironmentHelper;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;

import static com.monsanto.Util.EnvironmentHelper.sf_cstrSystem;
import static org.junit.Assert.assertTrue;

/**
 * Created by IntelliJ IDEA.
 * User: CCCC1
 * Date: 5/30/13
 * Time: 11:23 AM
 * To change this template use File | Settings | File Templates.
 */
@RunWith(MockitoJUnitRunner.class)
public class LsiBasedUserIdLocatorFactory_UT {

    private UserIdLocatorFactory userIdLocatorFactory;
  private String originalLsi;

  @Before
  public void setUp() {
    originalLsi = System.getProperty(sf_cstrSystem);
  }

  @Test
  public void getUserIdLocator_LocalEnvironment() throws Exception {
    System.setProperty(sf_cstrSystem, EnvironmentHelper.sf_cstrWin);
    userIdLocatorFactory = new LsiBasedUserIdLocatorFactory();
    UserIdLocator userIdLocator = userIdLocatorFactory.getUserIdLocator();
    assertTrue(userIdLocator instanceof LocalUserIdLocator);
  }

  @Test
  public void getUserIdLocator_DevelopmentEnvironment() throws Exception {
    System.setProperty(sf_cstrSystem, EnvironmentHelper.sf_cstrDev);
    userIdLocatorFactory = new LsiBasedUserIdLocatorFactory();
    UserIdLocator userIdLocator = userIdLocatorFactory.getUserIdLocator();
    assertTrue(userIdLocator instanceof WAMUserIdLocator);
  }

  @Test
  public void getUserIdLocator_ITEnvironment() throws Exception {
    System.setProperty(sf_cstrSystem, EnvironmentHelper.sf_cstrIt);
    userIdLocatorFactory = new LsiBasedUserIdLocatorFactory();
    UserIdLocator userIdLocator = userIdLocatorFactory.getUserIdLocator();
    assertTrue(userIdLocator instanceof WAMUserIdLocator);
  }

  @Test
  public void getUserIdLocator_ProductionEnvironment() throws Exception {
    System.setProperty(sf_cstrSystem, EnvironmentHelper.sf_cstrPrd);
    userIdLocatorFactory = new LsiBasedUserIdLocatorFactory();
    UserIdLocator userIdLocator = userIdLocatorFactory.getUserIdLocator();
    assertTrue(userIdLocator instanceof WAMUserIdLocator);
  }
}
