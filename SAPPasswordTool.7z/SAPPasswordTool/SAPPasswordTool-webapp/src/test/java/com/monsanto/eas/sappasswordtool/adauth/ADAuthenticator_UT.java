package com.monsanto.eas.sappasswordtool.adauth;

import com.monsanto.eas.sappasswordtool.to.UserDetailsTO;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import static org.junit.Assert.*;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/**
 * Created by IntelliJ IDEA.
 * User: CCCC1
 * Date: 5/17/13
 * Time: 12:33 PM
 * To change this template use File | Settings | File Templates.
 */
@RunWith(MockitoJUnitRunner.class)
public class ADAuthenticator_UT {

    private Properties adProps;
    private ADAuthenticator adAuthenticator;

    @Before
    public void setUp() {
        adProps = new Properties();
        createProperties();
        adAuthenticator = new ADAuthenticator();
        adAuthenticator.setProperties(adProps);
    }

     @Test
    public void authenticateADUser_ReturnsNull_WhenUserIsNotValid() throws Exception {
        UserDetailsTO userDetails = new UserDetailsTO();
        userDetails.setUserName("USER1");
        userDetails.setUserDomain("NORTH_AMERICA");
        userDetails.setPassword("Pa$$w0rd");

        Map userAttributes = adAuthenticator.authenticate(userDetails);
        assertNull(userAttributes);
    }

    @Test
    public void authenticateADUser_ReturnsException_WhenDomainNotValid() throws Exception {
        UserDetailsTO userDetails = new UserDetailsTO();
        userDetails.setUserName("USER1");
        userDetails.setUserDomain("AMERICA");
        userDetails.setPassword("Pa$$w0rd");

        try{
                Map userAttributes = adAuthenticator.authenticate(userDetails);
         }catch (Exception e){
             assertNotNull(e.getMessage());
         }    }

     @Test
    public void authenticateADUser_ReturnsUserInfo_WhenUserValid() throws Exception {
        UserDetailsTO userDetails = new UserDetailsTO();
        userDetails.setUserName("IDMTEST2");
        userDetails.setUserDomain("NORTH_AMERICA");
        userDetails.setPassword("pswd*r3st");

        Map userAttributes = adAuthenticator.authenticate(userDetails);
        assertNotNull(userAttributes);
    }

    private void createProperties() {
        adProps.put("NORTH_AMERICA.domain", "NORTH_AMERICA");
        adProps.put("NORTH_AMERICA.host", "ldap://monldap1.monsanto.com:389");
        adProps.put("NORTH_AMERICA.dc", "na");

        adProps.put("LAWA-SOUTH.domain", "LAWA-SOUTH");
        adProps.put("LAWA-SOUTH.host", "ldap://la1000dsp01.la.ds.monsanto.com:389");
        adProps.put("LAWA-SOUTH.dc", "la");

        adProps.put("EUROPE-AFRICA.domain", "EUROPE-AFRICA");
        adProps.put("EUROPE-AFRICA.host", "ldap://ea1000dsp01.ea.ds.monsanto.com:389");
        adProps.put("EUROPE-AFRICA", "ea");

        adProps.put("ASIA-PACIFIC.domain", "ASIA-PACIFIC");
        adProps.put("ASIA-PACIFIC.host", "ldap://ap1000dsp01.ap.ds.monsanto.com:389");
        adProps.put("ASIA-PACIFIC.dc", "ap");
    }
}
