package com.monsanto.eas.sappasswordtool.view.controller;

import com.monsanto.eas.sappasswordtool.comparator.SapSystemComparator;
import com.monsanto.eas.sappasswordtool.to.SAPSystemDetailsTO;
import com.monsanto.eas.sappasswordtool.to.UserDetailsTO;
import com.monsanto.eas.sappasswordtool.view.bo.SapSystemBO;
import com.monsanto.eas.sappasswordtool.view.validator.SapSystemValidator;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.mock.web.MockHttpSession;
import org.springframework.validation.BindingResult;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpSession;
import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.*;
import static org.mockito.Mockito.when;

/**
 * Created by IntelliJ IDEA.
 * User: CCCC1
 * Date: 5/16/13
 * Time: 11:33 AM
 * To change this template use File | Settings | File Templates.
 */
@RunWith(MockitoJUnitRunner.class)
public class SapSystemController_UT {

    private static final String USER_DETAILS = "userDetails";
    private static final String SAP_SYSTEM_VIEW = "sapSystemList";
    private static final String MAX_PASSWORD_RESET_COUNT = "MaxPasswordResetCount";
    private static final String MAX_PASSWORD_RESET_COUNT_REACHED = "MaxPasswordResetCountReached";
    private static final String MAX_PASSWORD_RESET_COUNT_REACHED_MESSAGE = "Exceeds the maximum password reset tries,Please try on later... ";
    private static final String RESET_PASSWORD_VIEW = "resetPassword";
    private static final String SAP_SYSTEMS = "sapSystems";

    private SapSystemValidator sapSystemValidator;
    private SapSystemBO sapSystemBO;
    private SapSystemController controller;
    private MockHttpServletRequest request;
    private MockHttpServletResponse response;
    private BindingResult result;
    private HttpSession session;
    private SapSystemComparator sapSystemComparator;
    private List<SAPSystemDetailsTO> sapSystemDetailsList = new ArrayList<SAPSystemDetailsTO>();

    @Before
    public void setUp() {
        session = new MockHttpSession();
        request = new MockHttpServletRequest();
        response = new MockHttpServletResponse();
        result = Mockito.mock(BindingResult.class);
        sapSystemValidator = Mockito.mock(SapSystemValidator.class);
        sapSystemBO = Mockito.mock(SapSystemBO.class);
        sapSystemComparator = Mockito.mock(SapSystemComparator.class);
        controller = new SapSystemController(sapSystemBO, sapSystemValidator, sapSystemComparator);
    }

    @Test
    public void displayDefaultPage() throws Exception {

        ModelAndView view = controller.displayDefaultPage(request, response, session);

        assertNotNull(view);
        assertEquals(view.getViewName(), SAP_SYSTEM_VIEW);
        assertTrue(view.getModelMap().containsAttribute(USER_DETAILS));
    }

    @Test
    public void displayPreviousPage() throws Exception {

        ModelAndView view = controller.displayPreviousPage(request, response, session);
        assertNotNull(view);
    }

    @Test
    public void displayPasswordResetPageWithValidationFail() throws Exception {
        UserDetailsTO userDetails = new UserDetailsTO();
        when(result.hasErrors()).thenReturn(true);
        session.setAttribute(SAP_SYSTEMS,populateSapSystems(sapSystemDetailsList));
        ModelAndView view = controller.displayPasswordResetPage(request, response, "D08 - Development", session, userDetails, result);

        assertNotNull(view);
        assertEquals(view.getViewName(), SAP_SYSTEM_VIEW);
        assertTrue(view.getModelMap().containsAttribute(USER_DETAILS));
        assertTrue(result.hasErrors());
    }

    @Test
    public void resetPasswordOfSAPSystemForFirstTime() throws Exception {
        UserDetailsTO userDetails = new UserDetailsTO();
        userDetails.setSapServerInstance("SAPServerInstance");
        when(result.hasErrors()).thenReturn(false);
         session.setAttribute(SAP_SYSTEMS,populateSapSystems(sapSystemDetailsList));
        ModelAndView view = controller.displayPasswordResetPage(request, response, "D08 - Development", session, userDetails, result);

        assertNotNull(view);
        assertEquals(view.getViewName(), RESET_PASSWORD_VIEW);
        assertTrue(view.getModelMap().containsAttribute(USER_DETAILS));
        assertTrue(((Integer) session.getAttribute(MAX_PASSWORD_RESET_COUNT)).intValue() == 1L);
    }

    @Test
    public void resetPasswordOfSAPSystemMoreThanFirstTime() throws Exception {
        UserDetailsTO userDetails = new UserDetailsTO();
        userDetails.setSapServerInstance("SAPServerInstance");
        Integer secondTime = new Integer(1);
        session.setAttribute(MAX_PASSWORD_RESET_COUNT, secondTime);
        when(result.hasErrors()).thenReturn(false);
        session.setAttribute(SAP_SYSTEMS,populateSapSystems(sapSystemDetailsList));
        ModelAndView view = controller.displayPasswordResetPage(request, response, "D08 - Development", session, userDetails, result);

        assertNotNull(view);
        assertEquals(view.getViewName(), RESET_PASSWORD_VIEW);
        assertTrue(view.getModelMap().containsAttribute(USER_DETAILS));
        assertTrue(((Integer) session.getAttribute(MAX_PASSWORD_RESET_COUNT)).intValue() > 1L);
    }

    @Test
    public void resetPasswordOfSAPSystemExceedsPasswordResetCount() throws Exception {
        UserDetailsTO userDetails = new UserDetailsTO();
        userDetails.setSapServerInstance("SAPServerInstance");
        Integer secondTime = new Integer(5);
        session.setAttribute(MAX_PASSWORD_RESET_COUNT, secondTime);
        when(result.hasErrors()).thenReturn(false);
        session.setAttribute(SAP_SYSTEMS,populateSapSystems(sapSystemDetailsList));
        ModelAndView view = controller.displayPasswordResetPage(request, response, "D08 - Development", session, userDetails, result);

        assertNotNull(view);
        assertEquals(view.getViewName(), SAP_SYSTEM_VIEW);
        assertTrue(view.getModelMap().containsAttribute(USER_DETAILS));
        assertTrue(((Integer) session.getAttribute(MAX_PASSWORD_RESET_COUNT)).intValue() > 1L);
    }

    private List<SAPSystemDetailsTO> populateSapSystems(List<SAPSystemDetailsTO> sapSystemDetailsList) {
        SAPSystemDetailsTO sapSystemDetailsTO = null;
        sapSystemDetailsTO = new SAPSystemDetailsTO();
        sapSystemDetailsTO.setSapSystemName("PSSD08");
        sapSystemDetailsTO.setSapSystemDesc("D08 - Development");
        sapSystemDetailsList.add(sapSystemDetailsTO);

        sapSystemDetailsTO = new SAPSystemDetailsTO();
        sapSystemDetailsTO.setSapSystemName("PSSS08");
        sapSystemDetailsTO.setSapSystemDesc("S08-Sandbox");
        sapSystemDetailsList.add(sapSystemDetailsTO);

        return sapSystemDetailsList;
    }

}
