package com.monsanto.eas.sappasswordtool.view.controller;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.mock.web.MockHttpSession;
import org.springframework.validation.BindingResult;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpSession;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

/**
 * Created by IntelliJ IDEA.
 * User: CCCC1
 * Date: 5/13/13
 * Time: 10:46 AM
 * To change this template use File | Settings | File Templates.
 */
@RunWith(MockitoJUnitRunner.class)
public class HomeController_UT {

       private static final String VIEW_NAME = "home";

       private MockHttpServletRequest request;
       private MockHttpServletResponse response;
       private BindingResult result;
       private HttpSession session;
       private HomeController controller;


    @Before
    public void setUp() {
        session = new MockHttpSession();
        request = new MockHttpServletRequest();
        response = new MockHttpServletResponse();
        result = Mockito.mock(BindingResult.class);
        controller = new HomeController();
    }

     @Test
    public void displayLoginPage() throws Exception {

        ModelAndView view = controller.displayLoginPage(request, response, session);

        assertNotNull(view);
        assertEquals(view.getViewName(), VIEW_NAME);
    }

     @Test
    public void invalidateSession() throws Exception {
        request.setSession(session);
        ModelAndView view = controller.invalidateSession(request, response, session);

        assertNotNull(view);
        assertEquals(view.getViewName(), VIEW_NAME);
    }
}
