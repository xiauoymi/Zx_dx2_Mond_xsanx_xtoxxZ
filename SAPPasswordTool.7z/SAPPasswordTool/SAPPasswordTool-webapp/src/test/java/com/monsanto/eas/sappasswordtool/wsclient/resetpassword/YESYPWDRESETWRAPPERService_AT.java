package com.monsanto.eas.sappasswordtool.wsclient.resetpassword;

import com.monsanto.eas.sappasswordtool.handler.SecurityHandlerResolver;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.context.annotation.Configuration;
import org.springframework.remoting.jaxws.JaxWsPortProxyFactoryBean;

import javax.xml.ws.Holder;
import java.net.URI;

import static org.junit.Assert.*;

/**
 * Created by IntelliJ IDEA.
 * User: CCCC1
 * Date: 7/16/13
 * Time: 12:15 PM
 * To change this template use File | Settings | File Templates.
 */
@RunWith(MockitoJUnitRunner.class)
@Configuration
public class YESYPWDRESETWRAPPERService_AT {

    static final String RESET_PASSWORD_WSDL_KEY = "http://services-dint.monsanto.com/Global_PasswordResetServices/ResetPassword?wsdl";
    static final String RESET_PASSWORD_NAMESPACE_URI = "urn:sap-com:document:sap:rfc:functions";
    static final String RESET_PASSWORD_SERVICE_NAME = "YES_Y_PWD_RESET_WRAPPER";
    static final String RESET_PASSWORD_SERVICE_PORT = "YES_Y_PWD_RESET_WRAPPER";
    static final String SAP_SERVICE_USER_NAME = "NA1000SVC_PSWDTOOL";
    static final String SAP_SERVICE_USER_PASSWORD = "Mhng$397";


    private YESYPWDRESETWRAPPER resetPasswordPort;
    Holder<String> descrOUT = null;
    Holder<String> passwordOUT = null;
    Holder<String> resultOUT = null;

    @Before
    public void setup() throws Exception {
        descrOUT = new Holder<String>();
        passwordOUT = new Holder<String>();
        resultOUT = new Holder<String>();
        resetPasswordPort = getResetPasswordService();
    }

    @Test
    public void testResetPasswordSuccess() throws Exception {
        resetPasswordPort.yPWDRESETWRAPPER("PSSD08", null, "IDMTEST2", descrOUT, passwordOUT, resultOUT);
        assertNotNull(descrOUT);
        assertNotNull(passwordOUT);
        assertNotNull(resultOUT);
        assertTrue(descrOUT.value.equals("Success"));
    }

    @Test
    public void testResetPasswordUserAccountNotFound() throws Exception {
        resetPasswordPort.yPWDRESETWRAPPER("PSSD08", null, "IDMTEST3", descrOUT, passwordOUT, resultOUT);
        assertNotNull(descrOUT);
        assertEquals(passwordOUT.value, "");
        assertNotNull(resultOUT);
        //assertTrue(descrOUT.value.equals("Account Not Found."));
    }


    private YESYPWDRESETWRAPPER getResetPasswordService() throws Exception {

        JaxWsPortProxyFactoryBean factoryBean = new JaxWsPortProxyFactoryBean();
        factoryBean.setServiceInterface(YESYPWDRESETWRAPPER.class);
        factoryBean.setWsdlDocumentUrl(new URI(RESET_PASSWORD_WSDL_KEY).toURL());
        factoryBean.setNamespaceUri(RESET_PASSWORD_NAMESPACE_URI);
        factoryBean.setServiceName(RESET_PASSWORD_SERVICE_NAME);
        factoryBean.setPortName(RESET_PASSWORD_SERVICE_PORT);
        String userName = SAP_SERVICE_USER_NAME;
        String password = SAP_SERVICE_USER_PASSWORD;
        factoryBean.setHandlerResolver(new SecurityHandlerResolver(userName, password));
        factoryBean.setLookupServiceOnStartup(false);
        factoryBean.afterPropertiesSet();

        return (YESYPWDRESETWRAPPER) factoryBean.getObject();
    }
}
