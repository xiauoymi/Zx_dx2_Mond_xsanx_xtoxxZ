package com.monsanto.eas.sappasswordtool.adauth;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;

import static org.junit.Assert.assertEquals;

/**
 * Created by IntelliJ IDEA.
 * User: snara
 * Date: 5/22/13
 * Time: 1:10 PM
 */
@RunWith(MockitoJUnitRunner.class)
public class ADDomainProperties_UT {
    private ADDomainProperties aDDomainProperties;

    @Before
    public void setUp() {
        aDDomainProperties = new ADDomainProperties();
        aDDomainProperties.setDomain("NORTH_AMERICA");
        aDDomainProperties.setLdapHost("LDAPHOST");
        aDDomainProperties.setSearchBase("SEARCHBASE");
    }

    @Test
    public void testADDomainProperties() {
        assertEquals("NORTH_AMERICA", aDDomainProperties.getDomain());
        assertEquals("LDAPHOST", aDDomainProperties.getLdapHost());
        assertEquals("SEARCHBASE", aDDomainProperties.getSearchBase());
    }
}
