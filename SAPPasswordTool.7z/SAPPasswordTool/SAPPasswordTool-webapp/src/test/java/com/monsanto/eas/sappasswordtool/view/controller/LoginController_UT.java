package com.monsanto.eas.sappasswordtool.view.controller;

import com.monsanto.eas.sappasswordtool.adauth.ADDomainProperties;
import com.monsanto.eas.sappasswordtool.to.UserDetailsTO;
import com.monsanto.eas.sappasswordtool.utils.SAPPasswordToolConstants;
import com.monsanto.eas.sappasswordtool.view.bo.LoginBO;
import com.monsanto.eas.sappasswordtool.view.validator.LoginValidator;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.mock.web.MockHttpSession;
import org.springframework.validation.BindingResult;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpSession;
import java.util.List;
import java.util.Properties;

import static org.junit.Assert.*;
import static org.mockito.Mockito.when;

/**
 * Created by IntelliJ IDEA.
 * User: CCCC1
 * Date: 5/13/13
 * Time: 10:46 AM
 * To change this template use File | Settings | File Templates.
 */

@RunWith(MockitoJUnitRunner.class)
public class LoginController_UT {

    private static final String USER_DETAILS = "loginForm";
    private static final String SAP_SYSTEM_VIEW = "sapSystem.do";
    private static final String LOGIN_VIEW = "login";

    private Properties adProps;
    private LoginValidator loginValidator;
    private LoginBO loginBO;
    private LoginController controller;
    private LoginController loginController;
    private MockHttpServletRequest request;
    private MockHttpServletResponse response;
    private BindingResult result;
    private HttpSession session;

    @Before
    public void setUp() {
        adProps = new Properties();
        createProperties();
        session = new MockHttpSession();
        request = new MockHttpServletRequest();
        response = new MockHttpServletResponse();
        result = Mockito.mock(BindingResult.class);
        loginValidator = Mockito.mock(LoginValidator.class);
        loginBO = Mockito.mock(LoginBO.class);
        loginController = Mockito.mock(LoginController.class);

        controller = new LoginController(loginBO, loginValidator);
        controller.setAdProps(adProps);
    }

    @Test
    public void displayLoginPage() throws Exception {

        ModelAndView view = controller.displayLoginPage(request, response, session);

        assertNotNull(view);
        assertEquals(view.getViewName(), view.getViewName());
        assertNotNull(view.getModelMap().get(USER_DETAILS));
    }

  /*  @Test
    public void getDomainNames() {

        List<ADDomainProperties> domainProperties = controller.getDomainNames();
        assertNotNull(domainProperties);
        assertTrue(domainProperties.size() == 4);
    }*/

    @Test
    public void authenticateUser_ReturnsSAPSystemListView_WhenUserIsSuccessfullyAuthenticated() throws Exception {


        UserDetailsTO userDetails = new UserDetailsTO();
        userDetails.setUserName("jhuer");
        userDetails.setUserEmail("jacqueline.huerta.gonzalez@monsanto.com");
        userDetails.setFirstName("Jackeline");
        userDetails.setLastName("Huerta");
        when(loginBO.authenticateADUser(userDetails)).thenReturn(true);

        ModelAndView resultView = controller.authenticateUser(request, response, session, userDetails, result);

        assertNotNull(resultView);

        UserDetailsTO loggedInUser = (UserDetailsTO) session.getAttribute(SAPPasswordToolConstants.USER_INFO);
        assertNotNull(loggedInUser);
        assertEquals(loggedInUser.getUserName(), "jhuer");
        assertEquals(loggedInUser.getFirstName(), "Jackeline");
        assertEquals(loggedInUser.getLastName(), "Huerta");

    }

    @Test
    public void authenticateUser_ReturnsLoginPageView_WhenUserIsNotSuccessfullyAuthenticated() throws Exception {

        UserDetailsTO userDetails = new UserDetailsTO();
        userDetails.setUserName("jhuer");
        userDetails.setUserEmail("jacqueline.huerta.gonzalez@monsanto.com");
        userDetails.setFirstName("Jackeline");
        userDetails.setLastName("Huerta");
        when(loginBO.authenticateADUser(userDetails)).thenReturn(false);

        ModelAndView resultView = controller.authenticateUser(request, response, session, userDetails, result);

        assertNotNull(resultView);
        assertEquals(resultView.getViewName(), LOGIN_VIEW);

        UserDetailsTO loggedInUser = (UserDetailsTO) session.getAttribute(SAPPasswordToolConstants.USER_INFO);
        assertNull(loggedInUser);
    }

      @Test
    public void authenticateUser_ReturnsLoginPageView_WhenUserHasValidationErrors() throws Exception {

        UserDetailsTO userDetails = new UserDetailsTO();
        userDetails.setUserName("jhuer");
        userDetails.setUserEmail("jacqueline.huerta.gonzalez@monsanto.com");
        userDetails.setFirstName("Jackeline");
        userDetails.setLastName("Huerta");
        when(loginBO.authenticateADUser(userDetails)).thenReturn(false);
        when(result.hasErrors()).thenReturn(true);

        ModelAndView resultView = controller.authenticateUser(request, response, session, userDetails, result);

        assertNotNull(resultView);
        assertEquals(resultView.getViewName(), LOGIN_VIEW);
    }


    private void createProperties() {
        adProps.put("NORTH_AMERICA.domain", "NORTH_AMERICA");
        adProps.put("NORTH_AMERICA.host", "ldap://monldap1.monsanto.com:389");
        adProps.put("NORTH_AMERICA.dc", "na");

        adProps.put("LAWA-SOUTH.domain", "LAWA-SOUTH");
        adProps.put("LAWA-SOUTH.host", "ldap://la1000dsp01.la.ds.monsanto.com:389");
        adProps.put("LAWA-SOUTH.dc", "la");

        adProps.put("EUROPE-AFRICA.domain", "EUROPE-AFRICA");
        adProps.put("EUROPE-AFRICA.host", "ldap://ea1000dsp01.ea.ds.monsanto.com:389");
        adProps.put("EUROPE-AFRICA", "ea");

        adProps.put("ASIA-PACIFIC.domain", "ASIA-PACIFIC");
        adProps.put("ASIA-PACIFIC.host", "ldap://ap1000dsp01.ap.ds.monsanto.com:389");
        adProps.put("ASIA-PACIFIC.dc", "ap");
    }

     @Test
    public void displayHomePage() throws Exception {

        ModelAndView view = controller.displayHomePage(request, response, session);

        assertNotNull(view);
        assertEquals(view.getViewName(), view.getViewName());

    }

}
