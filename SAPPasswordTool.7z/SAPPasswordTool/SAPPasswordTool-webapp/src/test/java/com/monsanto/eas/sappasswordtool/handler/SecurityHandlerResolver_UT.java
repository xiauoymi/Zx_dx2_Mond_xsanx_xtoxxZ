package com.monsanto.eas.sappasswordtool.handler;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;

import javax.xml.ws.handler.PortInfo;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.mock;

/**
 * Created by IntelliJ IDEA.
 * User: snara
 * Date: 5/22/13
 * Time: 11:23 AM
 */
@RunWith(MockitoJUnitRunner.class)
public class SecurityHandlerResolver_UT {

    SecurityHandlerResolver securityHandlerResolver;

    @Before
    public void setUp() {
        securityHandlerResolver = new SecurityHandlerResolver("userName", "password");
    }

    @Test
    public void testGetHandlerChain() {
        PortInfo portInfo = mock(PortInfo.class);
        assertEquals(1, securityHandlerResolver.getHandlerChain(portInfo).size());
    }
}
