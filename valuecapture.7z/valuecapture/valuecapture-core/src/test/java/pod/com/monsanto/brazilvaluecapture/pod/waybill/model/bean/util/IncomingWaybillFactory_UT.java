package com.monsanto.brazilvaluecapture.pod.waybill.model.bean.util;

import com.monsanto.brazilvaluecapture.pod.waybill.model.bean.IncomingWaybillAR;
import com.monsanto.brazilvaluecapture.pod.waybill.model.bean.IncomingWaybillPY;
import com.monsanto.brazilvaluecapture.pod.waybill.model.bean.TransportType;
import org.junit.Test;

import javax.xml.datatype.XMLGregorianCalendar;
import java.math.BigInteger;
import java.util.Collections;
import java.util.Date;
import java.util.GregorianCalendar;

import static com.monsanto.brazilvaluecapture.pod.waybill.model.bean.IncomingWaybill.DOCUMENT_TYPE_LENGTH;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

public class IncomingWaybillFactory_UT {

    private static final String ADDRESSEE_CITY_CODE = "ADDRESSEE_CITY_CODE";
    private static final long ADDRESSEE_DOCUMENT_NUMBER = 423863910L;
    private static final String ADDRESSEE_DOCUMENT_TYPE = "ADDRESSEE_DOCUMENT_TYPEEEEEEEEE";
    private static final String ADDRESSEE_NAME = "ADDRESSEE_NAME";
    private static final long AGENT_DOCUMENT_NUMBER = 183275389L;
    private static final String AGENT_NAME = "AGENT_NAME";
    private static final long BROKER_DOCUMENT_NUMBER = 38442157L;
    private static final String BROKER_NAME = "BROKER_NAME";
    private static final String CAMPAIGN_CODE = "CAMPAIGN_CODE";
    private static final long COMMERCIAL_SENDER_DOCUMENT_NUMBER = 5328679L;
    private static final String COMMERCIAL_SENDER_DOCUMENT_TYPE = "COMMERCIAL_SENDER_DOCUMENT_TYPE";
    private static final String COMMERCIAL_SENDER_NAME = "COMMERCIAL_SENDER_NAME";
    private static final String CROP_CODE = "CROP_CODE";
    private static final long CTG_DATE_SINCE_MILLIS = 1383600000003L;
    private static final long CTG_DATE_UNTIL_MILLIS = 1383600000004L;
    private static final long CTG_ISSUE_DATE_MILLIS = 1383600000002L;
    private static final int CTG_KILOMETERS_TRAVELED = 1428;
    private static final BigInteger CTG_NUMBER = BigInteger.valueOf(77729412024L);
    private static final String CTG_STATUS = "CTG_STATUS";
    private static final String DESTINATION_ADDRESS = "DESTINATION_ADDRESS";
    private static final long DESTINATION_CITY_CODE = 85L;
    private static final long DESTINATION_DOCUMENT_NUMBER = 86413823L;
    private static final String DESTINATION_DOCUMENT_TYPE = "DESTINATION_DOCUMENT_TYPEEEEEEE";
    private static final String DESTINATION_NAME = "DESTINATION_NAME";
    private static final String DESTINATION_PLANT_CODE = "DESTINATION_PLANT_CODE";
    private static final long DESTINATION_STATE_CODE = 9L;
    private static final long DEVIATION_ADDRESSEE_DOCUMENT_NUMBER = 1935285L;
    private static final long DEVIATION_DATE_MILLIS = 1383600000001L;
    private static final String DEVIATION_DESTINATION_ADDRESS = "DESTINATION_ADDRESS";
    private static final long DEVIATION_DESTINATION_DOCUMENT_NUMBER = 5278L;
    private static final String ESTABLISHMENT = "ESTABLISHMENT";
    private static final long HOLDER_DOCUMENT_NUMBER = 88461L;
    private static final String HOLDER_DOCUMENT_TYPE = "HOLDER_DOCUMENT_TYPEEEEEEEEEEEE";
    private static final String HOLDER_NAME = "HOLDER_NAME";
    private static final long INTERMEDIARY_DOCUMENT_NUMBER = 16293535L;
    private static final String INTERMEDIARY_NAME = "INTERMEDIARY_NAME";
    private static final String LAB_CODE = "LAB_CODE";
    private static final BigInteger NET_WEIGHT = BigInteger.valueOf(429L);
    private static final String SOURCE_ADDRESS = "SOURCE_ADDRESS";
    private static final long SOURCE_CITY_CODE = 85L;
    private static final long SOURCE_STATE_CODE = 4L;
    private static final String TECHNOLOGY_CODE = "TECHNOLOGY_CODE";
    private static final String TRANSFER_REQUESTED_BY = "TRANSFER_REQUESTED_BY";
    private static final BigInteger WAYBILL_NUMBER = BigInteger.valueOf(44278930L);
    private static final BigInteger WEIGHT_DETECTED = BigInteger.valueOf(77L);

    @Test
    public void getInstanceForARShouldSucceed() {
        com.monsanto.brazilvaluecapture.osb.its.waybillexportar.bean.Deviation deviation = mock(
                com.monsanto.brazilvaluecapture.osb.its.waybillexportar.bean.Deviation.class);
        when(deviation.getDestinationDocumentNumber()).thenReturn(DEVIATION_DESTINATION_DOCUMENT_NUMBER);
        when(deviation.getDestinationAddress()).thenReturn(DEVIATION_DESTINATION_ADDRESS);
        when(deviation.getDestinationPlantCode()).thenReturn(DESTINATION_PLANT_CODE);
        XMLGregorianCalendar deviationDate = createXMLGregorianCalendar(DEVIATION_DATE_MILLIS);
        when(deviation.getDeviationDate()).thenReturn(deviationDate);
        when(deviation.getTransferRequestedBy()).thenReturn(TRANSFER_REQUESTED_BY);
        when(deviation.getAddresseeDocumentNumber()).thenReturn(DEVIATION_ADDRESSEE_DOCUMENT_NUMBER);
        when(deviation.getAddresseeCityCode()).thenReturn(ADDRESSEE_CITY_CODE);
        com.monsanto.brazilvaluecapture.osb.its.waybillexportar.bean.LabResult labResult = mock(
                com.monsanto.brazilvaluecapture.osb.its.waybillexportar.bean.LabResult.class);
        when(labResult.getTechnologyCode()).thenReturn(TECHNOLOGY_CODE);
        when(labResult.getWeightDetected()).thenReturn(WEIGHT_DETECTED);
        when(labResult.getLabCode()).thenReturn(LAB_CODE);
        com.monsanto.brazilvaluecapture.osb.its.waybillexportar.bean.Waybill waybill = mock(
                com.monsanto.brazilvaluecapture.osb.its.waybillexportar.bean.Waybill.class);
        when(waybill.getCtgStatus()).thenReturn(CTG_STATUS);
        XMLGregorianCalendar ctgIssueDate = createXMLGregorianCalendar(CTG_ISSUE_DATE_MILLIS);
        when(waybill.getCtgIssueDate()).thenReturn(ctgIssueDate);
        XMLGregorianCalendar ctgDateSince = createXMLGregorianCalendar(CTG_DATE_SINCE_MILLIS);
        when(waybill.getCtgDateSince()).thenReturn(ctgDateSince);
        XMLGregorianCalendar ctgDateUntil = createXMLGregorianCalendar(CTG_DATE_UNTIL_MILLIS);
        when(waybill.getCtgDateUntil()).thenReturn(ctgDateUntil);
        when(waybill.getCtgKilometersTraveled()).thenReturn(CTG_KILOMETERS_TRAVELED);
        when(waybill.getTransportType()).thenReturn(
                com.monsanto.brazilvaluecapture.osb.its.waybillexportar.bean.TransportType.TRUCK);
        when(waybill.getHolderName()).thenReturn(HOLDER_NAME);
        when(waybill.getHolderDocumentType()).thenReturn(HOLDER_DOCUMENT_TYPE);
        when(waybill.getHolderDocumentNumber()).thenReturn(HOLDER_DOCUMENT_NUMBER);
        when(waybill.getIntermediaryName()).thenReturn(INTERMEDIARY_NAME);
        when(waybill.getIntermediaryDocumentNumber()).thenReturn(INTERMEDIARY_DOCUMENT_NUMBER);
        when(waybill.getCommercialSenderName()).thenReturn(COMMERCIAL_SENDER_NAME);
        when(waybill.getCommercialSenderDocumentType()).thenReturn(COMMERCIAL_SENDER_DOCUMENT_TYPE);
        when(waybill.getCommercialSenderDocumentNumber()).thenReturn(COMMERCIAL_SENDER_DOCUMENT_NUMBER);
        when(waybill.getBrokerName()).thenReturn(BROKER_NAME);
        when(waybill.getBrokerDocumentNumber()).thenReturn(BROKER_DOCUMENT_NUMBER);
        when(waybill.getAgentName()).thenReturn(AGENT_NAME);
        when(waybill.getAgentDocumentNumber()).thenReturn(AGENT_DOCUMENT_NUMBER);
        when(waybill.getAddresseeName()).thenReturn(ADDRESSEE_NAME);
        when(waybill.getAddresseeDocumentType()).thenReturn(ADDRESSEE_DOCUMENT_TYPE);
        when(waybill.getAddresseeDocumentNumber()).thenReturn(ADDRESSEE_DOCUMENT_NUMBER);
        when(waybill.getDestinationName()).thenReturn(DESTINATION_NAME);
        when(waybill.getDestinationDocumentType()).thenReturn(DESTINATION_DOCUMENT_TYPE);
        when(waybill.getDestinationDocumentNumber()).thenReturn(DESTINATION_DOCUMENT_NUMBER);
        when(waybill.getCampaignCode()).thenReturn(CAMPAIGN_CODE);
        when(waybill.getCropCode()).thenReturn(CROP_CODE);
        when(waybill.getSourceAddress()).thenReturn(SOURCE_ADDRESS);
        when(waybill.getEstablishment()).thenReturn(ESTABLISHMENT);
        when(waybill.getNetWeight()).thenReturn(NET_WEIGHT);
        when(waybill.getSourceCityCode()).thenReturn(SOURCE_CITY_CODE);
        when(waybill.getSourceStateCode()).thenReturn(SOURCE_STATE_CODE);
        when(waybill.getDestinationAddress()).thenReturn(DESTINATION_ADDRESS);
        when(waybill.getDestinationCityCode()).thenReturn(DESTINATION_CITY_CODE);
        when(waybill.getDestinationStateCode()).thenReturn(DESTINATION_STATE_CODE);
        when(waybill.getDeviation()).thenReturn(deviation);
        when(waybill.getLabResult()).thenReturn(Collections.singletonList(labResult));
        when(waybill.getCtgNumber()).thenReturn(CTG_NUMBER);
        when(waybill.getWaybillNumber()).thenReturn(WAYBILL_NUMBER);

        IncomingWaybillAR incomingWaybill = (IncomingWaybillAR)IncomingWaybillFactory.getInstance(3L, waybill);

        assertEquals("AR", incomingWaybill.getCountryCode());
        assertEquals(3L, incomingWaybill.getBulkId().longValue());
        assertNotNull(incomingWaybill.getReceivedOn());
        assertEquals(CTG_STATUS, incomingWaybill.getCtgStatus());
        assertEquals(CTG_ISSUE_DATE_MILLIS, incomingWaybill.getCtgIssueDate().getTime());
        assertEquals(CTG_DATE_SINCE_MILLIS, incomingWaybill.getCtgDateSince().getTime());
        assertEquals(CTG_DATE_UNTIL_MILLIS, incomingWaybill.getCtgDateUntil().getTime());
        assertEquals(CTG_KILOMETERS_TRAVELED, incomingWaybill.getCtgKilometersTraveled().intValue());
        assertEquals(TransportType.TRUCK, incomingWaybill.getTransportType());
        assertEquals(HOLDER_NAME, incomingWaybill.getHolderName());
        assertEquals(HOLDER_DOCUMENT_TYPE.substring(0, DOCUMENT_TYPE_LENGTH), incomingWaybill.getHolderDocumentType());
        assertEquals(HOLDER_DOCUMENT_NUMBER, incomingWaybill.getHolderDocumentNumber().longValue());
        assertEquals(INTERMEDIARY_NAME, incomingWaybill.getIntermediaryName());
        assertEquals(INTERMEDIARY_DOCUMENT_NUMBER, incomingWaybill.getIntermediaryDocumentNumber().longValue());
        assertEquals(COMMERCIAL_SENDER_NAME, incomingWaybill.getCommercialSenderName());
        assertEquals(COMMERCIAL_SENDER_DOCUMENT_TYPE.substring(0, DOCUMENT_TYPE_LENGTH), incomingWaybill.getCommercialSenderDocumentType());
        assertEquals(COMMERCIAL_SENDER_DOCUMENT_NUMBER, incomingWaybill.getCommercialSenderDocumentNumber().longValue());
        assertEquals(BROKER_NAME, incomingWaybill.getBrokerName());
        assertEquals(BROKER_DOCUMENT_NUMBER, incomingWaybill.getBrokerDocumentNumber().longValue());
        assertEquals(AGENT_NAME, incomingWaybill.getAgentName());
        assertEquals(AGENT_DOCUMENT_NUMBER, incomingWaybill.getAgentDocumentNumber().longValue());
        assertEquals(ADDRESSEE_NAME, incomingWaybill.getAddresseeName());
        assertEquals(ADDRESSEE_DOCUMENT_TYPE.substring(0, DOCUMENT_TYPE_LENGTH), incomingWaybill.getAddresseeDocumentType());
        assertEquals(ADDRESSEE_DOCUMENT_NUMBER, incomingWaybill.getAddresseeDocumentNumber().longValue());
        assertEquals(DESTINATION_NAME, incomingWaybill.getDestinationName());
        assertEquals(DESTINATION_DOCUMENT_TYPE.substring(0, DOCUMENT_TYPE_LENGTH), incomingWaybill.getDestinationDocumentType());
        assertEquals(DESTINATION_DOCUMENT_NUMBER, incomingWaybill.getDestinationDocumentNumber().longValue());
        assertEquals(CAMPAIGN_CODE, incomingWaybill.getCampaignCode());
        assertEquals(CROP_CODE, incomingWaybill.getCropCode());
        assertEquals(SOURCE_ADDRESS, incomingWaybill.getSourceAddress());
        assertEquals(ESTABLISHMENT, incomingWaybill.getEstablishment());
        assertEquals(NET_WEIGHT, incomingWaybill.getNetWeight());
        assertEquals(SOURCE_CITY_CODE, incomingWaybill.getSourceCityCode().longValue());
        assertEquals(SOURCE_STATE_CODE, incomingWaybill.getSourceStateCode().longValue());
        assertEquals(DESTINATION_ADDRESS, incomingWaybill.getDestinationAddress());
        assertEquals(DESTINATION_CITY_CODE, incomingWaybill.getDestinationCityCode().longValue());
        assertEquals(DESTINATION_STATE_CODE, incomingWaybill.getDestinationStateCode().longValue());
        assertEquals(DEVIATION_DESTINATION_DOCUMENT_NUMBER, incomingWaybill.getDeviationDestinationDocumentNumber().longValue());
        assertEquals(DEVIATION_DESTINATION_ADDRESS, incomingWaybill.getDeviationDestinationAddress());
        assertEquals(DESTINATION_PLANT_CODE, incomingWaybill.getDeviationDestinationPlantCode());
        assertEquals(DEVIATION_DATE_MILLIS, incomingWaybill.getDeviationDate().getTime());
        assertEquals(TRANSFER_REQUESTED_BY, incomingWaybill.getDeviationTransferRequestedBy());
        assertEquals(DEVIATION_ADDRESSEE_DOCUMENT_NUMBER, incomingWaybill.getDeviationAddresseeDocumentNumber().longValue());
        assertEquals(ADDRESSEE_CITY_CODE, incomingWaybill.getDeviationAddresseeCityCode());
        assertEquals(1, incomingWaybill.getLabResults().size());
        assertEquals(incomingWaybill, incomingWaybill.getLabResults().iterator().next().getIncomingWaybill());
        assertEquals(TECHNOLOGY_CODE, incomingWaybill.getLabResults().iterator().next().getTechnologyCode());
        assertEquals(WEIGHT_DETECTED, incomingWaybill.getLabResults().iterator().next().getWeightDetected());
        assertEquals(LAB_CODE, incomingWaybill.getLabResults().iterator().next().getLabCode());
        assertEquals(CTG_NUMBER.toString(), incomingWaybill.getCtgNumber());
        assertEquals(WAYBILL_NUMBER.toString(), incomingWaybill.getWaybillNumber());
    }

    @Test
    public void getInstanceForARWithNullOrEmptyPropertiesShouldSucceed() {
        com.monsanto.brazilvaluecapture.osb.its.waybillexportar.bean.Waybill waybill = mock(
                com.monsanto.brazilvaluecapture.osb.its.waybillexportar.bean.Waybill.class);
        when(waybill.getCtgKilometersTraveled()).thenReturn(null);
        when(waybill.getIntermediaryDocumentNumber()).thenReturn(null);
        when(waybill.getCommercialSenderDocumentNumber()).thenReturn(null);
        when(waybill.getBrokerDocumentNumber()).thenReturn(null);
        when(waybill.getAgentDocumentNumber()).thenReturn(null);
        when(waybill.getLabResult()).thenReturn(
                Collections.<com.monsanto.brazilvaluecapture.osb.its.waybillexportar.bean.LabResult>emptyList());

        IncomingWaybillAR incomingWaybill = (IncomingWaybillAR)IncomingWaybillFactory.getInstance(3L, waybill);

        assertEquals("AR", incomingWaybill.getCountryCode());
        assertEquals(3L, incomingWaybill.getBulkId().longValue());
        assertNotNull(incomingWaybill.getReceivedOn());
        assertNull(incomingWaybill.getCtgStatus());
        assertNull(incomingWaybill.getCtgIssueDate());
        assertNull(incomingWaybill.getCtgDateSince());
        assertNull(incomingWaybill.getCtgDateUntil());
        assertNull(incomingWaybill.getCtgKilometersTraveled());
        assertNull(incomingWaybill.getTransportType());
        assertNull(incomingWaybill.getHolderName());
        assertNull(incomingWaybill.getHolderDocumentType());
        assertEquals(0L, incomingWaybill.getHolderDocumentNumber().longValue());
        assertNull(incomingWaybill.getIntermediaryName());
        assertNull(incomingWaybill.getIntermediaryDocumentNumber());
        assertNull(incomingWaybill.getCommercialSenderName());
        assertNull(incomingWaybill.getCommercialSenderDocumentType());
        assertNull(incomingWaybill.getCommercialSenderDocumentNumber());
        assertNull(incomingWaybill.getBrokerName());
        assertNull(incomingWaybill.getBrokerDocumentNumber());
        assertNull(incomingWaybill.getAgentName());
        assertNull(incomingWaybill.getAgentDocumentNumber());
        assertNull(incomingWaybill.getAddresseeName());
        assertNull(incomingWaybill.getAddresseeDocumentType());
        assertEquals(0L, incomingWaybill.getAddresseeDocumentNumber().longValue());
        assertNull(incomingWaybill.getDestinationName());
        assertNull(incomingWaybill.getDestinationDocumentType());
        assertEquals(0L, incomingWaybill.getDestinationDocumentNumber().longValue());
        assertNull(incomingWaybill.getCampaignCode());
        assertNull(incomingWaybill.getCropCode());
        assertNull(incomingWaybill.getSourceAddress());
        assertNull(incomingWaybill.getEstablishment());
        assertNull(incomingWaybill.getNetWeight());
        assertEquals(0L, incomingWaybill.getSourceCityCode().longValue());
        assertEquals(0L, incomingWaybill.getSourceStateCode().longValue());
        assertNull(incomingWaybill.getDestinationAddress());
        assertEquals(0L, incomingWaybill.getDestinationCityCode().longValue());
        assertEquals(0L, incomingWaybill.getDestinationStateCode().longValue());
        assertNull(incomingWaybill.getDeviationDestinationDocumentNumber());
        assertNull(incomingWaybill.getDeviationDestinationAddress());
        assertNull(incomingWaybill.getDeviationDestinationPlantCode());
        assertNull(incomingWaybill.getDeviationDate());
        assertNull(incomingWaybill.getDeviationTransferRequestedBy());
        assertNull(incomingWaybill.getDeviationAddresseeDocumentNumber());
        assertNull(incomingWaybill.getDeviationAddresseeCityCode());
        assertTrue(incomingWaybill.getLabResults().isEmpty());
        assertNull(incomingWaybill.getCtgNumber());
        assertNull(incomingWaybill.getWaybillNumber());
    }

    @Test
    public void getInstanceForPYShouldSucceed() {
        com.monsanto.brazilvaluecapture.osb.its.waybillexportpy.bean.Deviation deviation = mock(
                com.monsanto.brazilvaluecapture.osb.its.waybillexportpy.bean.Deviation.class);
        when(deviation.getDestinationDocumentNumber()).thenReturn(DEVIATION_DESTINATION_DOCUMENT_NUMBER);
        when(deviation.getDestinationAddress()).thenReturn(DEVIATION_DESTINATION_ADDRESS);
        when(deviation.getDestinationPlantCode()).thenReturn(DESTINATION_PLANT_CODE);
        XMLGregorianCalendar deviationDate = createXMLGregorianCalendar(DEVIATION_DATE_MILLIS);
        when(deviation.getDeviationDate()).thenReturn(deviationDate);
        when(deviation.getTransferRequestedBy()).thenReturn(TRANSFER_REQUESTED_BY);
        when(deviation.getAddresseeDocumentNumber()).thenReturn(DEVIATION_ADDRESSEE_DOCUMENT_NUMBER);
        when(deviation.getAddresseeCityCode()).thenReturn(ADDRESSEE_CITY_CODE);
        com.monsanto.brazilvaluecapture.osb.its.waybillexportpy.bean.LabResult labResult = mock(
                com.monsanto.brazilvaluecapture.osb.its.waybillexportpy.bean.LabResult.class);
        when(labResult.getTechnologyCode()).thenReturn(TECHNOLOGY_CODE);
        when(labResult.getWeightDetected()).thenReturn(WEIGHT_DETECTED);
        when(labResult.getLabCode()).thenReturn(LAB_CODE);
        com.monsanto.brazilvaluecapture.osb.its.waybillexportpy.bean.Waybill waybill = mock(
                com.monsanto.brazilvaluecapture.osb.its.waybillexportpy.bean.Waybill.class);
        when(waybill.getCtgStatus()).thenReturn(CTG_STATUS);
        XMLGregorianCalendar ctgIssueDate = createXMLGregorianCalendar(CTG_ISSUE_DATE_MILLIS);
        when(waybill.getCtgIssueDate()).thenReturn(ctgIssueDate);
        XMLGregorianCalendar ctgDateSince = createXMLGregorianCalendar(CTG_DATE_SINCE_MILLIS);
        when(waybill.getCtgDateSince()).thenReturn(ctgDateSince);
        XMLGregorianCalendar ctgDateUntil = createXMLGregorianCalendar(CTG_DATE_UNTIL_MILLIS);
        when(waybill.getCtgDateUntil()).thenReturn(ctgDateUntil);
        when(waybill.getCtgKilometersTraveled()).thenReturn(CTG_KILOMETERS_TRAVELED);
        when(waybill.getTransportType()).thenReturn(
                com.monsanto.brazilvaluecapture.osb.its.waybillexportpy.bean.TransportType.TRUCK);
        when(waybill.getHolderName()).thenReturn(HOLDER_NAME);
        when(waybill.getHolderDocumentType()).thenReturn(HOLDER_DOCUMENT_TYPE);
        when(waybill.getHolderDocumentNumber()).thenReturn(HOLDER_DOCUMENT_NUMBER);
        when(waybill.getIntermediaryName()).thenReturn(INTERMEDIARY_NAME);
        when(waybill.getIntermediaryDocumentNumber()).thenReturn(INTERMEDIARY_DOCUMENT_NUMBER);
        when(waybill.getCommercialSenderName()).thenReturn(COMMERCIAL_SENDER_NAME);
        when(waybill.getCommercialSenderDocumentType()).thenReturn(COMMERCIAL_SENDER_DOCUMENT_TYPE);
        when(waybill.getCommercialSenderDocumentNumber()).thenReturn(COMMERCIAL_SENDER_DOCUMENT_NUMBER);
        when(waybill.getBrokerName()).thenReturn(BROKER_NAME);
        when(waybill.getBrokerDocumentNumber()).thenReturn(BROKER_DOCUMENT_NUMBER);
        when(waybill.getAgentName()).thenReturn(AGENT_NAME);
        when(waybill.getAgentDocumentNumber()).thenReturn(AGENT_DOCUMENT_NUMBER);
        when(waybill.getAddresseeName()).thenReturn(ADDRESSEE_NAME);
        when(waybill.getAddresseeDocumentType()).thenReturn(ADDRESSEE_DOCUMENT_TYPE);
        when(waybill.getAddresseeDocumentNumber()).thenReturn(ADDRESSEE_DOCUMENT_NUMBER);
        when(waybill.getDestinationName()).thenReturn(DESTINATION_NAME);
        when(waybill.getDestinationDocumentType()).thenReturn(DESTINATION_DOCUMENT_TYPE);
        when(waybill.getDestinationDocumentNumber()).thenReturn(DESTINATION_DOCUMENT_NUMBER);
        when(waybill.getCampaignCode()).thenReturn(CAMPAIGN_CODE);
        when(waybill.getCropCode()).thenReturn(CROP_CODE);
        when(waybill.getSourceAddress()).thenReturn(SOURCE_ADDRESS);
        when(waybill.getEstablishment()).thenReturn(ESTABLISHMENT);
        when(waybill.getNetWeight()).thenReturn(NET_WEIGHT);
        when(waybill.getSourceCityCode()).thenReturn(SOURCE_CITY_CODE);
        when(waybill.getSourceStateCode()).thenReturn(SOURCE_STATE_CODE);
        when(waybill.getDestinationAddress()).thenReturn(DESTINATION_ADDRESS);
        when(waybill.getDestinationCityCode()).thenReturn(DESTINATION_CITY_CODE);
        when(waybill.getDestinationStateCode()).thenReturn(DESTINATION_STATE_CODE);
        when(waybill.getDeviation()).thenReturn(deviation);
        when(waybill.getLabResult()).thenReturn(Collections.singletonList(labResult));
        when(waybill.getCtgNumber()).thenReturn(CTG_NUMBER);
        when(waybill.getWaybillNumber()).thenReturn(WAYBILL_NUMBER);

        IncomingWaybillPY incomingWaybill = (IncomingWaybillPY)IncomingWaybillFactory.getInstance(3L, waybill);

        assertEquals("PY", incomingWaybill.getCountryCode());
        assertEquals(3L, incomingWaybill.getBulkId().longValue());
        assertNotNull(incomingWaybill.getReceivedOn());
        assertEquals(CTG_STATUS, incomingWaybill.getCtgStatus());
        assertEquals(CTG_ISSUE_DATE_MILLIS, incomingWaybill.getCtgIssueDate().getTime());
        assertEquals(CTG_DATE_SINCE_MILLIS, incomingWaybill.getCtgDateSince().getTime());
        assertEquals(CTG_DATE_UNTIL_MILLIS, incomingWaybill.getCtgDateUntil().getTime());
        assertEquals(CTG_KILOMETERS_TRAVELED, incomingWaybill.getCtgKilometersTraveled().intValue());
        assertEquals(TransportType.TRUCK, incomingWaybill.getTransportType());
        assertEquals(HOLDER_NAME, incomingWaybill.getHolderName());
        assertEquals(HOLDER_DOCUMENT_TYPE.substring(0, DOCUMENT_TYPE_LENGTH), incomingWaybill.getHolderDocumentType());
        assertEquals(HOLDER_DOCUMENT_NUMBER, incomingWaybill.getHolderDocumentNumber().longValue());
        assertEquals(INTERMEDIARY_NAME, incomingWaybill.getIntermediaryName());
        assertEquals(INTERMEDIARY_DOCUMENT_NUMBER, incomingWaybill.getIntermediaryDocumentNumber().longValue());
        assertEquals(COMMERCIAL_SENDER_NAME, incomingWaybill.getCommercialSenderName());
        assertEquals(COMMERCIAL_SENDER_DOCUMENT_TYPE.substring(0, DOCUMENT_TYPE_LENGTH), incomingWaybill.getCommercialSenderDocumentType());
        assertEquals(COMMERCIAL_SENDER_DOCUMENT_NUMBER, incomingWaybill.getCommercialSenderDocumentNumber().longValue());
        assertEquals(BROKER_NAME, incomingWaybill.getBrokerName());
        assertEquals(BROKER_DOCUMENT_NUMBER, incomingWaybill.getBrokerDocumentNumber().longValue());
        assertEquals(AGENT_NAME, incomingWaybill.getAgentName());
        assertEquals(AGENT_DOCUMENT_NUMBER, incomingWaybill.getAgentDocumentNumber().longValue());
        assertEquals(ADDRESSEE_NAME, incomingWaybill.getAddresseeName());
        assertEquals(ADDRESSEE_DOCUMENT_TYPE.substring(0, DOCUMENT_TYPE_LENGTH), incomingWaybill.getAddresseeDocumentType());
        assertEquals(ADDRESSEE_DOCUMENT_NUMBER, incomingWaybill.getAddresseeDocumentNumber().longValue());
        assertEquals(DESTINATION_NAME, incomingWaybill.getDestinationName());
        assertEquals(DESTINATION_DOCUMENT_TYPE.substring(0, DOCUMENT_TYPE_LENGTH), incomingWaybill.getDestinationDocumentType());
        assertEquals(DESTINATION_DOCUMENT_NUMBER, incomingWaybill.getDestinationDocumentNumber().longValue());
        assertEquals(CAMPAIGN_CODE, incomingWaybill.getCampaignCode());
        assertEquals(CROP_CODE, incomingWaybill.getCropCode());
        assertEquals(SOURCE_ADDRESS, incomingWaybill.getSourceAddress());
        assertEquals(ESTABLISHMENT, incomingWaybill.getEstablishment());
        assertEquals(NET_WEIGHT, incomingWaybill.getNetWeight());
        assertEquals(SOURCE_CITY_CODE, incomingWaybill.getSourceCityCode().longValue());
        assertEquals(SOURCE_STATE_CODE, incomingWaybill.getSourceStateCode().longValue());
        assertEquals(DESTINATION_ADDRESS, incomingWaybill.getDestinationAddress());
        assertEquals(DESTINATION_CITY_CODE, incomingWaybill.getDestinationCityCode().longValue());
        assertEquals(DESTINATION_STATE_CODE, incomingWaybill.getDestinationStateCode().longValue());
        assertEquals(DEVIATION_DESTINATION_DOCUMENT_NUMBER, incomingWaybill.getDeviationDestinationDocumentNumber().longValue());
        assertEquals(DEVIATION_DESTINATION_ADDRESS, incomingWaybill.getDeviationDestinationAddress());
        assertEquals(DESTINATION_PLANT_CODE, incomingWaybill.getDeviationDestinationPlantCode());
        assertEquals(DEVIATION_DATE_MILLIS, incomingWaybill.getDeviationDate().getTime());
        assertEquals(TRANSFER_REQUESTED_BY, incomingWaybill.getDeviationTransferRequestedBy());
        assertEquals(DEVIATION_ADDRESSEE_DOCUMENT_NUMBER, incomingWaybill.getDeviationAddresseeDocumentNumber().longValue());
        assertEquals(ADDRESSEE_CITY_CODE, incomingWaybill.getDeviationAddresseeCityCode());
        assertEquals(1, incomingWaybill.getLabResults().size());
        assertEquals(incomingWaybill, incomingWaybill.getLabResults().iterator().next().getIncomingWaybill());
        assertEquals(TECHNOLOGY_CODE, incomingWaybill.getLabResults().iterator().next().getTechnologyCode());
        assertEquals(WEIGHT_DETECTED, incomingWaybill.getLabResults().iterator().next().getWeightDetected());
        assertEquals(LAB_CODE, incomingWaybill.getLabResults().iterator().next().getLabCode());
        assertEquals(WAYBILL_NUMBER.toString(), incomingWaybill.getWaybillNumber());
    }

    @Test
    public void getInstanceForPYWithNullOrEmptyPropertiesShouldSucceed() {
        com.monsanto.brazilvaluecapture.osb.its.waybillexportpy.bean.Waybill waybill = mock(
                com.monsanto.brazilvaluecapture.osb.its.waybillexportpy.bean.Waybill.class);
        when(waybill.getCtgKilometersTraveled()).thenReturn(null);
        when(waybill.getIntermediaryDocumentNumber()).thenReturn(null);
        when(waybill.getCommercialSenderDocumentNumber()).thenReturn(null);
        when(waybill.getBrokerDocumentNumber()).thenReturn(null);
        when(waybill.getAgentDocumentNumber()).thenReturn(null);
        when(waybill.getLabResult()).thenReturn(
                Collections.<com.monsanto.brazilvaluecapture.osb.its.waybillexportpy.bean.LabResult>emptyList());

        IncomingWaybillPY incomingWaybill = (IncomingWaybillPY)IncomingWaybillFactory.getInstance(3L, waybill);

        assertEquals("PY", incomingWaybill.getCountryCode());
        assertEquals(3L, incomingWaybill.getBulkId().longValue());
        assertNotNull(incomingWaybill.getReceivedOn());
        assertNull(incomingWaybill.getCtgStatus());
        assertNull(incomingWaybill.getCtgIssueDate());
        assertNull(incomingWaybill.getCtgDateSince());
        assertNull(incomingWaybill.getCtgDateUntil());
        assertNull(incomingWaybill.getCtgKilometersTraveled());
        assertNull(incomingWaybill.getTransportType());
        assertNull(incomingWaybill.getHolderName());
        assertNull(incomingWaybill.getHolderDocumentType());
        assertEquals(0L, incomingWaybill.getHolderDocumentNumber().longValue());
        assertNull(incomingWaybill.getIntermediaryName());
        assertNull(incomingWaybill.getIntermediaryDocumentNumber());
        assertNull(incomingWaybill.getCommercialSenderName());
        assertNull(incomingWaybill.getCommercialSenderDocumentType());
        assertNull(incomingWaybill.getCommercialSenderDocumentNumber());
        assertNull(incomingWaybill.getBrokerName());
        assertNull(incomingWaybill.getBrokerDocumentNumber());
        assertNull(incomingWaybill.getAgentName());
        assertNull(incomingWaybill.getAgentDocumentNumber());
        assertNull(incomingWaybill.getAddresseeName());
        assertNull(incomingWaybill.getAddresseeDocumentType());
        assertEquals(0L, incomingWaybill.getAddresseeDocumentNumber().longValue());
        assertNull(incomingWaybill.getDestinationName());
        assertNull(incomingWaybill.getDestinationDocumentType());
        assertEquals(0L, incomingWaybill.getDestinationDocumentNumber().longValue());
        assertNull(incomingWaybill.getCampaignCode());
        assertNull(incomingWaybill.getCropCode());
        assertNull(incomingWaybill.getSourceAddress());
        assertNull(incomingWaybill.getEstablishment());
        assertNull(incomingWaybill.getNetWeight());
        assertEquals(0L, incomingWaybill.getSourceCityCode().longValue());
        assertEquals(0L, incomingWaybill.getSourceStateCode().longValue());
        assertNull(incomingWaybill.getDestinationAddress());
        assertEquals(0L, incomingWaybill.getDestinationCityCode().longValue());
        assertEquals(0L, incomingWaybill.getDestinationStateCode().longValue());
        assertNull(incomingWaybill.getDeviationDestinationDocumentNumber());
        assertNull(incomingWaybill.getDeviationDestinationAddress());
        assertNull(incomingWaybill.getDeviationDestinationPlantCode());
        assertNull(incomingWaybill.getDeviationDate());
        assertNull(incomingWaybill.getDeviationTransferRequestedBy());
        assertNull(incomingWaybill.getDeviationAddresseeDocumentNumber());
        assertNull(incomingWaybill.getDeviationAddresseeCityCode());
        assertTrue(incomingWaybill.getLabResults().isEmpty());
        assertNull(incomingWaybill.getWaybillNumber());
    }

    private XMLGregorianCalendar createXMLGregorianCalendar(long millisecs) {
        GregorianCalendar gregorianCalendar = new GregorianCalendar();
        gregorianCalendar.setTime(new Date(millisecs));
        XMLGregorianCalendar xmlGregorianCalendar = mock(XMLGregorianCalendar.class);
        when(xmlGregorianCalendar.toGregorianCalendar()).thenReturn(gregorianCalendar);
        return xmlGregorianCalendar;
    }

}