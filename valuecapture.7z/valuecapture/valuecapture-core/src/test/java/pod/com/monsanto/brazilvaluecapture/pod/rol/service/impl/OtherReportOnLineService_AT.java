package com.monsanto.brazilvaluecapture.pod.rol.service.impl;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.monsanto.brazilvaluecapture.core.base.model.bean.Company;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Crop;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Contract;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Customer;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.HeadOffice;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.ParticipantTypeEnum;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Technology;
import com.monsanto.brazilvaluecapture.core.customer.service.AffiliateNotEnableForReportException;
import com.monsanto.brazilvaluecapture.core.customer.service.AffiliateNotInVigorException;
import com.monsanto.brazilvaluecapture.core.customer.service.CustomerNotFoundException;
import com.monsanto.brazilvaluecapture.core.foundation.test.AbstractServiceIntegrationTests;
import com.monsanto.brazilvaluecapture.core.foundation.test.dbunit.DbUnitHelper;
import com.monsanto.brazilvaluecapture.core.foundation.util.CalendarUtil;
import com.monsanto.brazilvaluecapture.core.user.model.bean.UserDecorator;
import com.monsanto.brazilvaluecapture.core.user.service.UserNotFoundException;
import com.monsanto.brazilvaluecapture.core.user.service.UserService;
import com.monsanto.brazilvaluecapture.pod.credit.service.OtherRolValueFilter;
import com.monsanto.brazilvaluecapture.pod.rol.model.bean.HeadOfficeDetail;
import com.monsanto.brazilvaluecapture.pod.rol.model.bean.HeadOfficeEffectiveDate;
import com.monsanto.brazilvaluecapture.pod.rol.model.bean.OtherRolValue;
import com.monsanto.brazilvaluecapture.pod.rol.model.bean.ReportOnLine;
import com.monsanto.brazilvaluecapture.pod.rol.model.bean.RolStatus;
import com.monsanto.brazilvaluecapture.pod.rol.model.dao.OtherRolValueDAO;
import com.monsanto.brazilvaluecapture.pod.rol.model.dao.ReportOnlineDAO;
import com.monsanto.brazilvaluecapture.pod.rol.model.service.OtherReportOnLineService;
import com.monsanto.brazilvaluecapture.pod.rol.model.service.impl.OtherReportOnlineConstraintException;
import com.monsanto.brazilvaluecapture.pod.rol.model.service.impl.OtherReportOnlineNotFoundException;

public class OtherReportOnLineService_AT extends AbstractServiceIntegrationTests {

    @Autowired
    private OtherReportOnLineService otherReportOnLineService;

    @Autowired
    private OtherRolValueDAO otherReportOnLineDAO;

    @Autowired
    private ReportOnlineDAO reportOnLineDAO;

    @Autowired
    UserService userService;

    @Before
    public void setup() {

    }

    /**
     * Set up db unit
     */
    public void setupDBUnit() {

        // Load dbunit
        DbUnitHelper.setup("classpath:data/core/fixture-system-dataset.xml",
                "classpath:data/core/participant-dataset.xml",
                "classpath:data/pod/rol/other-report-online-value-dataset.xml",
                "classpath:data/core/headoffice-detail-dataset.xml");

    }

    /**
     * 
     */
    private HeadOfficeDetail setMatrixVigor(HeadOffice headOffice, Date period) {

        Assert.assertNotNull(headOffice);

        // Build contract range
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(period);
        calendar.set(Calendar.DAY_OF_MONTH, 1);
        calendar.add(Calendar.MONTH, -10);

        // Create head office detail
        HeadOfficeDetail headOfficeDetail = headOffice.getHeadOfficeDetail();
        if (headOfficeDetail == null) {
            headOfficeDetail = new HeadOfficeDetail();
            headOfficeDetail.setHeadoffice(headOffice);
            headOfficeDetail.setReportRol(Boolean.TRUE);
            headOfficeDetail.setShowParticipantInList(Boolean.FALSE);
            headOffice.setHeadOfficeDetail(headOfficeDetail);

        }

        try {

            headOffice.getMatrix().selectContractsInVigorBy(headOffice.getCompany(), headOffice.getCrop(),
                    ParticipantTypeEnum.POD);

        } catch (Exception e) {

            Customer matrix = (Customer) getSession().get(Customer.class, headOffice.getMatrix().getId());

            // Create contract
            Contract contract = new Contract();
            contract.setCompany(headOffice.getCompany());
            contract.setCrop(headOffice.getCrop());
            contract.setCustomer(matrix);
            contract.setParticipantType(ParticipantTypeEnum.POD);
            contract.setStartDate(calendar.getTime());
            calendar.add(Calendar.MONTH, 20);
            contract.setEndDate(calendar.getTime());
            // saveAndFlush(contract);

            matrix.addContract(contract);
            // saveAndFlush(headOffice.getMatrix());
        }

        if (!headOffice.checkVigor(period)) {

            calendar.setTime(period);
            calendar.set(Calendar.DAY_OF_MONTH, 1);
            calendar.add(Calendar.MONTH, -10);

            // Set effective date
            HeadOfficeEffectiveDate effectiveDate = new HeadOfficeEffectiveDate();
            effectiveDate.setHeadOfficeDetail(headOfficeDetail);
            effectiveDate.setInitDate(calendar.getTime());

            // Set end of effective date like end of matrix contract
            calendar.add(Calendar.MONTH, 20);
            effectiveDate.setEndDate(calendar.getTime());
            headOfficeDetail.getHeadOfficeEffectiveDates().add(effectiveDate);
            // saveAndFlush(headOfficeDetail);
        }

        return headOfficeDetail;
    }

    @Test
    public void find_other_report_online_value_by_id() throws OtherReportOnlineNotFoundException {
        setupDBUnit();
        // search for the entity
        OtherRolValue otherRolValue = otherReportOnLineService.findOtherRolValueById(900000001L);
        Assert.assertNotNull(otherRolValue);
    }

    @Test(expected = OtherReportOnlineNotFoundException.class)
    public void find_other_report_online_value_by_id_not_found_entity() throws OtherReportOnlineNotFoundException {
        setupDBUnit();
        // search for the entity
        otherReportOnLineService.findOtherRolValueById(900000009L);
        Assert.fail();
    }

    @Test(expected = IllegalArgumentException.class)
    public void find_other_report_online_value_by_id_with_illegal_argument() throws OtherReportOnlineNotFoundException {
        setupDBUnit();
        // search for the entity
        otherReportOnLineService.findOtherRolValueById(null);
        Assert.fail();
    }

    @Ignore("Until we can figure out why status test is failing")
    @Test
    public void delete_other_report_online_value() throws OtherReportOnlineConstraintException,
            OtherReportOnlineNotFoundException {
        setupDBUnit();
        // search for the entity
        OtherRolValue otherRolValue = (OtherRolValue) getSession().get(OtherRolValue.class, 900000001L);

        // change receivedDate for a valid operational year
        Date today = new Date();
        int actualMonth = CalendarUtil.getDateMonth(today);
        Date period = CalendarUtil.getDate(2112, actualMonth, 30);
        otherRolValue.setReceivedDate(period);
        saveAndFlush(otherRolValue);

        // delete entity
        otherReportOnLineService.deleteOtherRolValue(900000001L);

        // search for the entity
        otherRolValue = (OtherRolValue) getSession().get(OtherRolValue.class, 900000001L);
        Assert.assertTrue(otherRolValue == null);
    }

    @Test(expected = OtherReportOnlineConstraintException.class)
    public void delete_other_report_online_value_with_invalid_rol_status() throws OtherReportOnlineConstraintException,
            OtherReportOnlineNotFoundException {
        setupDBUnit();
        // search for the entity
        OtherRolValue otherRolValue = otherReportOnLineService.findOtherRolValueById(900000006L);
        Assert.assertNotNull(otherRolValue);
        // try to delete the entity. But it will fail because the rol
        // (ROL_ID="900000002")
        // is in invalid status for deletion.
        otherReportOnLineService.deleteOtherRolValue(otherRolValue.getId());
        Assert.fail();
    }

    @Test(expected = OtherReportOnlineNotFoundException.class)
    public void delete_other_report_online_value_with_valid_rol_status() throws OtherReportOnlineConstraintException,
            OtherReportOnlineNotFoundException {
        setupDBUnit();
        // search for the entity
        OtherRolValue otherRolValue = otherReportOnLineService.findOtherRolValueById(900000006L);
        Assert.assertNotNull(otherRolValue);

        // get the rol and change its status for a valid status
        ReportOnLine rol = (ReportOnLine) getSession().get(ReportOnLine.class, 900000002L);
        rol.setRolStatus(getCorrectedRolStatus());
        saveAndFlush(rol);

        // try to delete the entity. SUCCESS!!
        otherReportOnLineService.deleteOtherRolValue(900000006L);

        // search for the deleted entity. It throws
        // OtherReportOnlineNotFoundException
        otherReportOnLineService.findOtherRolValueById(900000006L);
    }

    @Test(expected = IllegalArgumentException.class)
    public void delete_other_report_online_value_with_illegal_argument() throws OtherReportOnlineConstraintException,
            OtherReportOnlineNotFoundException {
        // delete entity
        otherReportOnLineService.deleteOtherRolValue(null);
        Assert.fail();
    }

    @Test
    public void save_other_report_online_value_new_instance() throws OtherReportOnlineConstraintException,
            AffiliateNotInVigorException, AffiliateNotEnableForReportException, CustomerNotFoundException {
        setupDBUnit();
        // search for the entity
        OtherRolValue otherRolValue = otherReportOnLineDAO.findById(999900001L);
        Assert.assertNull(otherRolValue);

        Customer customer = (Customer) getSession().get(Customer.class, 900000001L);
        Technology technology = (Technology) getSession().get(Technology.class, 900000001L);
        HeadOffice headoffice = (HeadOffice) getSession().get(HeadOffice.class, 900000001L);

        Date today = new Date();
        int actualMonth = CalendarUtil.getDateMonth(today);
        Date period = CalendarUtil.getDate(2112, actualMonth, 30);

        // matrix vigor
        setMatrixVigor(headoffice, period);

        // max vol allowed: 999.999.999,999
        BigDecimal volume = new BigDecimal(new BigInteger("999999999999"), 3);
        otherRolValue = new OtherRolValue(999900001L, customer, technology, headoffice, today, period, volume);
        // save entity
        otherReportOnLineService.saveOtherRolValue(otherRolValue);
        otherRolValue = null;

        // search for the entity
        otherRolValue = (OtherRolValue) getSession().get(OtherRolValue.class, 999900001L);
        Assert.assertNotNull(otherRolValue);
    }

    @Test
    public void edit_existing_other_report_online_value() throws OtherReportOnlineConstraintException,
            AffiliateNotInVigorException, AffiliateNotEnableForReportException, CustomerNotFoundException {
        setupDBUnit();
        HeadOffice headoffice = (HeadOffice) getSession().get(HeadOffice.class, 900000003L);
        // search for the entity
        OtherRolValue otherRolValue = otherReportOnLineDAO.findById(900000001L);
        Assert.assertNotNull(otherRolValue);

        // change technology , received date
        Technology technology = (Technology) getSession().get(Technology.class, 900000004L);
        otherRolValue.setTechnology(technology);
        Date period = CalendarUtil.getDate(2112, 11, 30);
        otherRolValue.setReceivedDate(period);
        setMatrixVigor(headoffice, period);
        // save entity
        otherReportOnLineService.saveOtherRolValue(otherRolValue);
        otherRolValue = null;

        // search for the entity
        otherRolValue = otherReportOnLineDAO.findById(900000001L);
        Assert.assertNotNull(otherRolValue);
        Assert.assertEquals(technology, otherRolValue.getTechnology());
        Assert.assertEquals(2112, CalendarUtil.getDateYear(otherRolValue.getReceivedDate()));
    }

    @Test(expected = OtherReportOnlineConstraintException.class)
    public void save_other_report_online_value_with_rol_not_in_valid_status()
            throws OtherReportOnlineConstraintException, AffiliateNotInVigorException,
            AffiliateNotEnableForReportException, CustomerNotFoundException {
        setupDBUnit();

        Customer customer = (Customer) getSession().get(Customer.class, 900000001L);
        Technology technology = (Technology) getSession().get(Technology.class, 900000001L);
        HeadOffice headoffice = (HeadOffice) getSession().get(HeadOffice.class, 900000003L);
        // same period in REPORT_ON_LINE with id = 900000001
        Date receivedDate = CalendarUtil.getDate(2112, 4, 30);// 2112-05-30

        // max vol allowed: 999.999.999,999
        BigDecimal volume = new BigDecimal(new BigInteger("999999999999"), 3);
        OtherRolValue otherRolValue = new OtherRolValue(customer, technology, headoffice, new Date(), receivedDate,
                volume);
        // set vigor
        setMatrixVigor(headoffice, receivedDate);
        // save entity
        // throw exception because rol is not in status: "REPORTED" OR
        // "CORRECTED"
        otherReportOnLineService.saveOtherRolValue(otherRolValue);
        Assert.fail();

    }

    @Test
    public void save_other_report_online_value_with_rol_in_valid_status() throws OtherReportOnlineConstraintException,
            AffiliateNotInVigorException, AffiliateNotEnableForReportException, CustomerNotFoundException {
        setupDBUnit();

        // VALID ROL_STATUS "REPORTED" OR "CORRECTED"

        Customer customer = (Customer) getSession().get(Customer.class, 900000001L);
        Technology technology = (Technology) getSession().get(Technology.class, 900000001L);
        HeadOffice headoffice = (HeadOffice) getSession().get(HeadOffice.class, 900000003L);
        // same period in REPORT_ON_LINE with id = 900000002
        Date receivedDate = CalendarUtil.getDate(2112, 5, 30);// 2112-06-30

        // max vol allowed: 999.999.999,999
        BigDecimal volume = new BigDecimal(new BigInteger("999999999999"), 3);
        OtherRolValue otherRolValue = new OtherRolValue(customer, technology, headoffice, new Date(), receivedDate,
                volume);
        setMatrixVigor(headoffice, receivedDate);
        // get the rol and change its status to corrected
        ReportOnLine rol = (ReportOnLine) getSession().get(ReportOnLine.class, 900000002L);
        rol.setRolStatus(getCorrectedRolStatus());
        saveAndFlush(rol); // update rol with new status

        // save entity
        otherReportOnLineService.saveOtherRolValue(otherRolValue);
        Assert.assertTrue(true);

    }

    private RolStatus getCorrectedRolStatus() {
        RolStatus rolStatus = reportOnLineDAO.findRolStatusByCode(RolStatus.ROL_STATUS_CORRECTED);
        if (rolStatus == null) {
            rolStatus = new RolStatus(990000001L, RolStatus.ROL_STATUS_CORRECTED, "label.agreement.status");
            saveAndFlush(rolStatus);
        }
        return rolStatus;
    }

    @Test(expected = OtherReportOnlineConstraintException.class)
    public void save_other_report_online_value_missing_required_attributes()
            throws OtherReportOnlineConstraintException, AffiliateNotInVigorException,
            AffiliateNotEnableForReportException, CustomerNotFoundException {
        setupDBUnit();
        Customer customer = (Customer) getSession().get(Customer.class, 900000001L);
        HeadOffice headoffice = (HeadOffice) getSession().get(HeadOffice.class, 900000003L);
        // MISSING TECHNOLOGY
        OtherRolValue otherRolValue = new OtherRolValue(customer, null, headoffice, new Date(), null, null);
        setMatrixVigor(headoffice, new Date());
        // save entity
        otherReportOnLineService.saveOtherRolValue(otherRolValue);
        Assert.fail();

    }

    @Test(expected = OtherReportOnlineConstraintException.class)
    public void save_other_report_online_value_invalid_volume() throws OtherReportOnlineConstraintException,
            AffiliateNotInVigorException, AffiliateNotEnableForReportException, CustomerNotFoundException {
        setupDBUnit();

        Customer customer = (Customer) getSession().get(Customer.class, 900000001L);
        Technology technology = (Technology) getSession().get(Technology.class, 900000001L);
        HeadOffice headoffice = (HeadOffice) getSession().get(HeadOffice.class, 900000003L);
        // same period in REPORT_ON_LINE with id = 900000002
        Date receivedDate = CalendarUtil.getDate(2112, 5, 30);// 2112-06-30
        // VOLUME EQUALS TO ZERO
        OtherRolValue otherRolValue = new OtherRolValue(customer, technology, headoffice, new Date(), receivedDate,
                BigDecimal.ZERO);
        setMatrixVigor(headoffice, receivedDate);
        // save entity
        otherReportOnLineService.saveOtherRolValue(otherRolValue);
        Assert.fail();

    }

    @Test(expected = IllegalArgumentException.class)
    public void save_other_report_online_value_invalid_argument() throws OtherReportOnlineConstraintException,
            AffiliateNotInVigorException, AffiliateNotEnableForReportException, CustomerNotFoundException {
        setupDBUnit();

        // save entity
        otherReportOnLineService.saveOtherRolValue(null);
        Assert.fail();

    }

    /**
     * @throws OtherReportOnlineConstraintException
     * 
     */
    @Test(expected = IllegalArgumentException.class)
    public void test_search_other_report_online_value_with_null_filter_expected_illegal_argument_exception()
            throws OtherReportOnlineConstraintException {
        otherReportOnLineService.searchOtherReportOnlineByFilter(null);
    }

    /**
     * @throws OtherReportOnlineConstraintException
     * 
     */
    @Test(expected = IllegalArgumentException.class)
    public void test_search_other_report_online_value_with_null_crop_expected_illegal_argument_exception()
            throws OtherReportOnlineConstraintException {
        setupDBUnit();
        OtherRolValueFilter filter = new OtherRolValueFilter();
        // set period 2010-01-01 00:00:0.0 to 2010-02-01 00:00:0.0
        filter.setInitDate(CalendarUtil.getDate(2010, 0, 1));
        filter.setEndDate(CalendarUtil.getDate(2010, 0, 10));
        // set company
        Company company = (Company) getSession().get(Company.class, 990000002L);
        filter.setCompany(company);
        // NO CROP IN FILTER
        otherReportOnLineService.searchOtherReportOnlineByFilter(filter);
    }

    /**
     * @throws OtherReportOnlineConstraintException
     * 
     */
    @Test(expected = OtherReportOnlineConstraintException.class)
    public void test_search_other_report_online_value_missing_required_field_period()
            throws OtherReportOnlineConstraintException {
        OtherRolValueFilter filter = new OtherRolValueFilter();
        Company company = (Company) getSession().get(Company.class, 990000002L);
        filter.setCompany(company);
        otherReportOnLineService.searchOtherReportOnlineByFilter(filter);
    }

    @Test(expected = OtherReportOnlineConstraintException.class)
    public void test_search_other_report_online_value_missing_required_field_company()
            throws OtherReportOnlineConstraintException {
        OtherRolValueFilter filter = new OtherRolValueFilter();

        // set period 2010-01-01 00:00:0.0 to 2010-02-01 00:00:0.0

        filter.setInitDate(CalendarUtil.getDate(2010, 0, 1));
        filter.setEndDate(CalendarUtil.getDate(2010, 1, 1));
        otherReportOnLineService.searchOtherReportOnlineByFilter(filter);
    }

    @Test(expected = OtherReportOnlineConstraintException.class)
    public void test_search_other_report_online_value_missing_required_field_enddate()
            throws OtherReportOnlineConstraintException {
        OtherRolValueFilter filter = new OtherRolValueFilter();

        // set period 2010-01-01 00:00:0.0 to 2010-02-01 00:00:0.0
        filter.setInitDate(CalendarUtil.getDate(2010, 1, 1));
        filter.setEndDate(null);
        otherReportOnLineService.searchOtherReportOnlineByFilter(filter);
    }

    @Test
    public void test_search_other_report_online_value_return_list() throws OtherReportOnlineConstraintException {
        setupDBUnit();
        OtherRolValueFilter filter = new OtherRolValueFilter();

        // set period 2010-01-01 00:00:0.0 to 2010-02-01 00:00:0.0
        filter.setInitDate(CalendarUtil.getDate(2010, 0, 1));
        filter.setEndDate(CalendarUtil.getDate(2010, 0, 10));
        // set crop and company
        Crop crop = (Crop) getSession().get(Crop.class, 900000001L);
        Company company = (Company) getSession().get(Company.class, 990000002L);
        filter.setCrop(crop);
        filter.setCompany(company);
        // set partner
        HeadOffice headOffice = (HeadOffice) getSession().get(HeadOffice.class, 900000003L);
        filter.setCustomer(headOffice.getCustomer());

        List<OtherRolValue> listResult = otherReportOnLineService.searchOtherReportOnlineByFilter(filter);
        Assert.assertEquals(2, listResult.size());

        for (OtherRolValue otherRolValue : listResult) {
            if (!(otherRolValue.getId().longValue() == 900000001 || otherRolValue.getId().longValue() == 900000002)) {
                Assert.fail("The id " + otherRolValue.getId() + " is not an expected one.");
            }
        }
    }

    @Test
    public void test_search_other_report_online_value_by_participant() throws OtherReportOnlineConstraintException {
        setupDBUnit();
        OtherRolValueFilter filter = new OtherRolValueFilter();

        // set period 2112-06-30 00:00:0.0
        filter.setPeriod(CalendarUtil.getDate(2112, 5, 30));
        // set crop and company
        Crop crop = (Crop) getSession().get(Crop.class, 900000001L);
        Company company = (Company) getSession().get(Company.class, 990000002L);
        filter.setCrop(crop);
        filter.setCompany(company);
        // set partner
        HeadOffice headOffice = (HeadOffice) getSession().get(HeadOffice.class, 900000003L);
        filter.setCustomer(headOffice.getCustomer());
        // *************considering PARTICIPANT**************
        Customer customer = (Customer) getSession().get(Customer.class, 900000003L);
        filter.setParticipant(customer);

        List<OtherRolValue> listResult = otherReportOnLineService.searchOtherReportOnlineByFilter(filter);
        Assert.assertEquals(1, listResult.size());

        for (OtherRolValue otherRolValue : listResult) {
            if (!(otherRolValue.getId().longValue() == 900000007)) {
                Assert.fail("The id " + otherRolValue.getId() + " is not an expected one.");
            }
        }
    }

    @Test
    public void test_search_other_report_online_value_by_logged_user_contracts() throws UserNotFoundException,
            OtherReportOnlineConstraintException {
        setupDBUnit();
        OtherRolValueFilter filter = new OtherRolValueFilter();

        // set period 2010-01-01 00:00:0.0 - 2010-02-30 00:00:0.0
        filter.setInitDate(CalendarUtil.getDate(2010, 0, 1));
        filter.setEndDate(CalendarUtil.getDate(2010, 1, 30));

        // set crop and company
        Crop crop = (Crop) getSession().get(Crop.class, 900000001L);
        Company company = (Company) getSession().get(Company.class, 990000002L);
        filter.setCrop(crop);
        filter.setCompany(company);

        // *************considering CONTRACTS**************
        UserDecorator loggedUser = userService.getUserBy("loginParticipant2");
        filter.setContracts(loggedUser.getContracts());

        List<OtherRolValue> listResult = otherReportOnLineService.searchOtherReportOnlineByFilter(filter);

        Assert.assertTrue("Expected at least 3 itens. But found: " + listResult.size(), listResult.size() >= 3);

        for (OtherRolValue otherRolValue : listResult) {
            Assert.assertEquals(crop, otherRolValue.getHeadoffice().getCrop());
            Assert.assertEquals(company, otherRolValue.getHeadoffice().getCompany());
            Assert.assertTrue(
                    "Invalid range of search. Verify it!",
                    CalendarUtil.getFirstDateOfMonth(filter.getInitDate()).compareTo(otherRolValue.getReceivedDate()) <= 0
                            && CalendarUtil.getLastDateOfMonth(filter.getEndDate()).compareTo(
                                    otherRolValue.getReceivedDate()) >= 0);

        }
    }

    @Test
    public void test_search_other_report_online_value_for_pod_participant_type() throws UserNotFoundException,
            OtherReportOnlineConstraintException {
        setupDBUnit();
        OtherRolValueFilter filter = new OtherRolValueFilter();

        // set period june 30th
        filter.setPeriod(CalendarUtil.getDate(2112, 5, 30));

        // set crop and company
        Crop crop = (Crop) getSession().get(Crop.class, 900000001L);
        Company company = (Company) getSession().get(Company.class, 990000002L);
        filter.setCrop(crop);
        filter.setCompany(company);

        // *************considering CONTRACTS**************
        UserDecorator loggedUser = userService.getUserBy("loginParticipant2");
        filter.setContracts(loggedUser.getContracts());

        // *************PARTICIPANT TYPE **********************************
        filter.setParticipantType(ParticipantTypeEnum.POD);
        List<OtherRolValue> listResult = otherReportOnLineService.searchOtherReportOnlineByFilter(filter);
        Assert.assertEquals(2, listResult.size());

        for (OtherRolValue otherRolValue : listResult) {
            if (!(otherRolValue.getId().longValue() == 900000006 || otherRolValue.getId().longValue() == 900000007)) {
                Assert.fail("The id " + otherRolValue.getId() + " is not an expected one.");
            }
        }
    }

    @Test
    public void test_search_other_report_online_value_for_distributor_participant_type() throws UserNotFoundException,
            OtherReportOnlineConstraintException {
        setupDBUnit();
        OtherRolValueFilter filter = new OtherRolValueFilter();

        // set period june 30th
        filter.setPeriod(CalendarUtil.getDate(2112, 5, 30));

        // set crop and company
        Crop crop = (Crop) getSession().get(Crop.class, 900000001L);
        Company company = (Company) getSession().get(Company.class, 990000002L);
        filter.setCrop(crop);
        filter.setCompany(company);

        // *************considering CONTRACTS**************
        UserDecorator loggedUser = userService.getUserBy("loginParticipant2");
        filter.setContracts(loggedUser.getContracts());

        // *************PARTICIPANT TYPE **********************************
        filter.setParticipantType(ParticipantTypeEnum.DISTRIBUTOR);
        List<OtherRolValue> listResult = otherReportOnLineService.searchOtherReportOnlineByFilter(filter);
        Assert.assertEquals(2, listResult.size());

        Assert.assertNotNull("The object doesn't exist.", listResult);
        Assert.assertTrue("There is no OtherRolValue.", listResult.size() > 0);

    }

    /**
     * 
     */
    @Test(expected = IllegalArgumentException.class)
    public void test_sum_other_report_online_value_with_null_filter_expected_illegal_argument_exception() {
        otherReportOnLineService.summarizeOtherReportOnlineByFilter(null);
    }

    /**
     * 
     */
    @Test(expected = IllegalArgumentException.class)
    public void test_sum_other_report_online_value_with_null_crop_and_company_expected_illegal_argument_exception() {
        otherReportOnLineService.summarizeOtherReportOnlineByFilter(new OtherRolValueFilter());
    }

    @Test
    public void test_sum_other_report_online_value_by_valid_filter_expected_sucess() {

        // load db unit
        setupDBUnit();

        // build filter
        OtherRolValueFilter filter = new OtherRolValueFilter();
        filter.setCrop((Crop) getSession().get(Crop.class, 900000001L));
        filter.setCompany((Company) getSession().get(Company.class, 990000002L));
        filter.setMatrix((Customer) getSession().get(Customer.class, 900000002L));
        filter.setTechnology((Technology) getSession().get(Technology.class, 900000001L));

        // summarize values
        BigDecimal value = otherReportOnLineService.summarizeOtherReportOnlineByFilter(filter);
        Assert.assertNotNull("Expected a non-null value.", value);
        Assert.assertEquals("Expected a valie ", new BigDecimal("3.3"), value);

    }

    @Test(expected = AffiliateNotInVigorException.class)
    public void other_report_online_value_with_contract_not_in_vigor() throws OtherReportOnlineConstraintException,
            AffiliateNotInVigorException, AffiliateNotEnableForReportException, CustomerNotFoundException {
        setupDBUnit();
        Customer customer = (Customer) getSession().get(Customer.class, 900000001L);
        Technology technology = (Technology) getSession().get(Technology.class, 900000001L);
        HeadOffice headoffice = (HeadOffice) getSession().get(HeadOffice.class, 900000003L);
        Date receivedDate = CalendarUtil.getDate(2199, 2, 10);
        BigDecimal volume = new BigDecimal(new BigInteger("999999999999"), 3);
        OtherRolValue otherRolValue = new OtherRolValue(customer, technology, headoffice, new Date(), receivedDate,
                volume);
        otherReportOnLineService.saveOtherRolValue(otherRolValue);
    }

    @Test(expected = AffiliateNotEnableForReportException.class)
    public void other_report_online_not_enable_report_rol() throws OtherReportOnlineConstraintException,
            AffiliateNotInVigorException, AffiliateNotEnableForReportException, CustomerNotFoundException {
        setupDBUnit();
        Customer customer = (Customer) getSession().get(Customer.class, 900000001L);
        Technology technology = (Technology) getSession().get(Technology.class, 900000001L);
        HeadOffice headoffice = (HeadOffice) getSession().get(HeadOffice.class, 900000003L);
        Date receivedDate = CalendarUtil.getDate(2112, 4, 30);
        BigDecimal volume = new BigDecimal(new BigInteger("999999999999"), 3);
        OtherRolValue otherRolValue = new OtherRolValue(customer, technology, headoffice, new Date(), receivedDate,
                volume);
        HeadOfficeDetail headOfficeDetail = setMatrixVigor(headoffice, receivedDate);
        headOfficeDetail.setReportRol(Boolean.FALSE);
        otherReportOnLineService.saveOtherRolValue(otherRolValue);
    }

    @Test
    public void test_search_other_report_online_value_matrix_in_vigor() throws OtherReportOnlineConstraintException,
            UserNotFoundException {
        setupDBUnit();
        OtherRolValueFilter filter = new OtherRolValueFilter();

        // set crop and company
        filter.setCrop((Crop) getSession().get(Crop.class, 900000001L));
        filter.setCompany((Company) getSession().get(Company.class, 990000002L));
        filter.setParticipantType(ParticipantTypeEnum.POD);
        filter.setInitDate(CalendarUtil.getDate(2010, 0, 1));
        filter.setEndDate(CalendarUtil.getDate(2012, 0, 10));
        filter.setOnlyInVigorMatrix(Boolean.TRUE);

        // *************considering CONTRACTS**************
        UserDecorator loggedUser = userService.getUserBy("loginParticipant2");
        filter.setContracts(loggedUser.getContracts());

        List<OtherRolValue> listResult = otherReportOnLineService.searchOtherReportOnlineByFilter(filter);

        Assert.assertNotNull("The object doesn't exist.", listResult);
        Assert.assertTrue("There is no OtherRolValue.", listResult.size() > 0);

    }

    @Test
    public void test_search_other_report_online_value_matrix_not_in_vigor()
            throws OtherReportOnlineConstraintException, UserNotFoundException {
        setupDBUnit();
        OtherRolValueFilter filter = new OtherRolValueFilter();

        // set crop and company
        filter.setCrop((Crop) getSession().get(Crop.class, 900000001L));
        filter.setCompany((Company) getSession().get(Company.class, 990000002L));
        filter.setParticipantType(ParticipantTypeEnum.POD);
        filter.setInitDate(CalendarUtil.getDate(2010, 0, 1));
        filter.setEndDate(CalendarUtil.getDate(2012, 0, 10));
        filter.setOnlyInVigorMatrix(Boolean.FALSE);

        // *************considering CONTRACTS**************
        UserDecorator loggedUser = userService.getUserBy("loginParticipant2");
        filter.setContracts(loggedUser.getContracts());

        List<OtherRolValue> listResult = otherReportOnLineService.searchOtherReportOnlineByFilter(filter);

        Assert.assertNotNull("The object doesn't exist.", listResult);
        Assert.assertTrue("There is no OtherRolValue.", listResult.size() > 0);

    }
}
