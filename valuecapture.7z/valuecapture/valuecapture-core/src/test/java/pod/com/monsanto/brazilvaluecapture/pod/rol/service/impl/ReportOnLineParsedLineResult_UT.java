package com.monsanto.brazilvaluecapture.pod.rol.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

import junit.framework.Assert;

import org.junit.Test;

import com.monsanto.brazilvaluecapture.core.foundation.util.ConstraintViolation;
import com.monsanto.brazilvaluecapture.core.foundation.util.ErrorCode;
import com.monsanto.brazilvaluecapture.pod.rol.model.bean.RolParameter;
import com.monsanto.brazilvaluecapture.pod.rol.model.service.ReportOnLineConstraintException;
import com.monsanto.brazilvaluecapture.pod.rol.model.service.ReportOnlineConstraintViolation;
import com.monsanto.brazilvaluecapture.pod.rol.model.service.ReportOnlineConstraintViolation.RolParameterColumnTypeEnum;
import com.monsanto.brazilvaluecapture.pod.rol.model.service.impl.CsvReportOnlineItem;
import com.monsanto.brazilvaluecapture.pod.rol.model.service.impl.ReportOnlineParsedLineResult;
import com.monsanto.brazilvaluecapture.pod.rol.model.service.impl.ReportOnlineParserResult;

/**
 * @author cmiranda
 * 
 */
public class ReportOnLineParsedLineResult_UT {

    /**
     * Bundle
     */
    private ResourceBundle resourceBundle = ResourceBundle.getBundle("bundle/bundle");

    /**
     * 
     */
    @Test
    public void test_formatted_message_for_constraint_violation_required_parameter() {

        // Create rol parameter
        RolParameter rolParameter = new RolParameter();
        rolParameter.setRolParamShownDescription("P1");

        // Create constraint violation
        ConstraintViolation constraintViolation = new ReportOnlineConstraintViolation(
                "pod.report.online.required.params", ReportOnLineConstraintException.REQUIRED_PARAM_CODE,
                rolParameter.getRolParamShownDescription(), rolParameter, RolParameterColumnTypeEnum.QUANTITY);

        // Create csv item
        CsvReportOnlineItem csvReportOnlineItem = new CsvReportOnlineItem(null, null);
        csvReportOnlineItem.setLine(1);

        // Build result
        ReportOnlineParsedLineResult result = new ReportOnlineParsedLineResult(constraintViolation, csvReportOnlineItem);
        String message = result.getFormattedMessage(resourceBundle);
        // System.out.println(message);

        // Verify message
        Assert.assertEquals(
                "Linha 1 Para envio do Relat�rio � necess�rio o preenchimento de todos os par�metros (para os par�metros que n�o houve movimenta��o informar zero).",
                message);

    }

    /**
     * 
     */
    @Test
    public void test_formatted_message_for_constraint_violation_just_one_value_informed_parameter() {

        // Create rol parameter
        RolParameter rolParameter = new RolParameter();
        rolParameter.setRolParamShownDescription("P1");

        // Create constraint violation
        ConstraintViolation constraintViolation = new ReportOnlineConstraintViolation(
                "erro.pod.report.online.value.greater.zero",
                ReportOnLineConstraintException.JUST_ONE_VALUE_INFORMED_PARAM_CODE,
                rolParameter.getRolParamShownDescription(), rolParameter, RolParameterColumnTypeEnum.QUANTITY);

        // Create csv item
        CsvReportOnlineItem csvReportOnlineItem = new CsvReportOnlineItem(null, null);
        csvReportOnlineItem.setLine(20);

        // Build result
        ReportOnlineParsedLineResult result = new ReportOnlineParsedLineResult(constraintViolation, csvReportOnlineItem);
        result.setColumn(1);
        String message = result.getFormattedMessage(resourceBundle);
        // System.out.println(message);

        // Verify message
        Assert.assertEquals(
                "Linha 20 coluna 2 O Par�metro P1 deve possuir valor monet�rio maior que zero, pois h� volume informado.",
                message);

    }

    /**
     * 
     */
    @Test
    public void test_formatted_message_for_constraint_violation_monetary_greater_than_max() {

        // Create rol parameter
        RolParameter rolParameter = new RolParameter();
        rolParameter.setRolParamShownDescription("P1");

        // Create constraint violation
        ConstraintViolation constraintViolation = new ReportOnlineConstraintViolation(
                "erro.value.positive.not.greater.maximum", ReportOnLineConstraintException.MONETARY_GREATER_THAN_MAX,
                rolParameter.getRolParamShownDescription(), rolParameter, RolParameterColumnTypeEnum.QUANTITY);

        // Create csv item
        CsvReportOnlineItem csvReportOnlineItem = new CsvReportOnlineItem(null, null);
        csvReportOnlineItem.setLine(20);

        // Build result
        ReportOnlineParsedLineResult result = new ReportOnlineParsedLineResult(constraintViolation, csvReportOnlineItem);
        result.setColumn(1);
        String message = result.getFormattedMessage(resourceBundle);
        // System.out.println(message);

        // Verify message
        Assert.assertEquals("Linha 20 coluna 2 � esperado um valor entre 0 e 999.999.999,999", message);

    }

    /**
     * 
     */
    @Test
    public void test_formatted_message_for_constraint_violation_paid_volume_by_grower() {

        // Create rol parameter
        RolParameter rolParameter = new RolParameter();
        rolParameter.setRolParamShownDescription("P1");

        // Create constraint violation
        ConstraintViolation constraintViolation = new ConstraintViolation("pod.paid.volume.grower.volume.greater",
                ReportOnLineConstraintException.PAID_VOLUME_BY_GROWER_CODE, "xxx", "1,99", "INTACTA", "5,00");

        // Create csv item
        CsvReportOnlineItem csvReportOnlineItem = new CsvReportOnlineItem(null, null);
        csvReportOnlineItem.setLine(2);

        // Build result
        ReportOnlineParsedLineResult result = new ReportOnlineParsedLineResult(constraintViolation, csvReportOnlineItem);
        result.setColumn(0);
        String message = result.getFormattedMessage(resourceBundle);
        // System.out.println(message);

        // Verify message
        Assert.assertEquals(
                "Linha 2 O Total de volume fixado no ROL: 1,99 para a Tecnologia INTACTA � menor que o volume reportado de todos os agricultores: 5,00.",
                message);

    }

    /**
     * 
     */
    @Test
    public void test_formatted_message_for_constraint_violation_test_stripe_greater_than_max() {

        // Create rol parameter
        RolParameter rolParameter = new RolParameter();
        rolParameter.setRolParamShownDescription("P1");

        // Create constraint violation
        ConstraintViolation constraintViolation = new ReportOnlineConstraintViolation(
                "erro.value.positive.not.greater.maximum.teststripe",
                ReportOnLineConstraintException.TEST_STRIPE_GREATER_THAN_MAX,
                rolParameter.getRolParamShownDescription(), rolParameter, RolParameterColumnTypeEnum.QUANTITY);

        // Create csv item
        CsvReportOnlineItem csvReportOnlineItem = new CsvReportOnlineItem(null, null);
        csvReportOnlineItem.setLine(20);

        // Build result
        ReportOnlineParsedLineResult result = new ReportOnlineParsedLineResult(constraintViolation, csvReportOnlineItem);
        result.setColumn(1);
        String message = result.getFormattedMessage(resourceBundle);
        // System.out.println(message);

        // Verify message
        Assert.assertEquals("Linha 20 coluna 2 � esperado um valor entre 0 e 999.999", message);

    }

    /**
     * 
     */
    @Test
    public void test_formatted_message_for_constraint_violation_test_stripe_required() {

        // Create rol parameter
        RolParameter rolParameter = new RolParameter();
        rolParameter.setRolParamShownDescription("P1");

        // Create constraint violation
        ConstraintViolation constraintViolation = new ReportOnlineConstraintViolation(
                "erro.value.positive.not.greater.maximum.teststripe",
                ReportOnLineConstraintException.TEST_STRIPE_REQUIRED, rolParameter.getRolParamShownDescription(),
                rolParameter, RolParameterColumnTypeEnum.QUANTITY);

        // Create csv item
        CsvReportOnlineItem csvReportOnlineItem = new CsvReportOnlineItem(null, null);
        csvReportOnlineItem.setLine(20);

        // Build result
        ReportOnlineParsedLineResult result = new ReportOnlineParsedLineResult(constraintViolation, csvReportOnlineItem);
        result.setColumn(10);
        String message = result.getFormattedMessage(resourceBundle);
        // System.out.println(message);

        // Verify message
        Assert.assertEquals("Linha 20 coluna 11 � esperado um valor entre 0 e 999.999", message);

    }

    /**
     * 
     */
    @Test
    public void test_formatted_message_for_constraint_violation_test_tonnels_greater_than_max() {

        // Create rol parameter
        RolParameter rolParameter = new RolParameter();
        rolParameter.setRolParamShownDescription("P1");

        // Create constraint violation
        ConstraintViolation constraintViolation = new ReportOnlineConstraintViolation(
                "erro.value.positive.not.greater.maximum", ReportOnLineConstraintException.TONNELS_GREATER_THAN_MAX,
                rolParameter.getRolParamShownDescription(), rolParameter, RolParameterColumnTypeEnum.QUANTITY);

        // Create csv item
        CsvReportOnlineItem csvReportOnlineItem = new CsvReportOnlineItem(null, null);
        csvReportOnlineItem.setLine(7);

        // Build result
        ReportOnlineParsedLineResult result = new ReportOnlineParsedLineResult(constraintViolation, csvReportOnlineItem);
        result.setColumn(8);
        String message = result.getFormattedMessage(resourceBundle);
        // System.out.println(message);

        // Verify message
        Assert.assertEquals("Linha 7 coluna 9 � esperado um valor entre 0 e 999.999.999,999", message);

    }

    /**
     * 
     */
    @Test
    public void test_formatted_message_for_() {

        // Create rol parameter
        RolParameter rolParameter = new RolParameter();
        rolParameter.setRolParamShownDescription("P1");

        // Build place holders
        List<Object> places = new ArrayList<Object>();
        places.add("1001");

        List<Integer> lines = new ArrayList<Integer>();
        lines.add(1);

        // Create constraint violation
        ReportOnlineParsedLineResult constraintViolation = new ReportOnlineParsedLineResult(
                ErrorCode.AFFILIATE_NOT_ENABLE_FOR_REPORT, lines, places);

        // Build result
        ReportOnlineParserResult reportOnlineParserResult = new ReportOnlineParserResult();
        reportOnlineParserResult.addWarning(constraintViolation);

        String warnings = reportOnlineParserResult.getWarningsAsString(resourceBundle);
        // System.out.println(warnings);

        // Verify message
        Assert.assertEquals("Linha 1 A filial 1001 n�o esta ativa para reportar o rol.\n", warnings);

    }

    @Test
    public void report_on_line_contraint_violation_sanity_test() {

        // Create constraint violation
        ReportOnlineConstraintViolation constraintViolation = new ReportOnlineConstraintViolation(
                "erro.value.positive.not.greater.maximum", ReportOnLineConstraintException.TONNELS_GREATER_THAN_MAX,
                "", RolParameterColumnTypeEnum.QUANTITY);

        Assert.assertNull(constraintViolation.getParameter());
        Assert.assertEquals(RolParameterColumnTypeEnum.QUANTITY, constraintViolation.getRolParameterColumnType());

        // Create rol parameter
        RolParameter rolParameter = new RolParameter();
        rolParameter.setRolParamShownDescription("P1");

        // Create constraint violation
        constraintViolation = new ReportOnlineConstraintViolation("erro.value.positive.not.greater.maximum",
                ReportOnLineConstraintException.TONNELS_GREATER_THAN_MAX, rolParameter.getRolParamShownDescription(),
                rolParameter, null);

        Assert.assertEquals(RolParameterColumnTypeEnum.NONE, constraintViolation.getRolParameterColumnType());

        // Create constraint violation
        constraintViolation = new ReportOnlineConstraintViolation("erro.value.positive.not.greater.maximum",
                ReportOnLineConstraintException.TONNELS_GREATER_THAN_MAX, rolParameter.getRolParamShownDescription(),
                null);

        Assert.assertEquals(RolParameterColumnTypeEnum.NONE, constraintViolation.getRolParameterColumnType());

    }
}
