package com.monsanto.brazilvaluecapture.pod.rol.service.impl;

import java.math.BigDecimal;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.hibernate.criterion.Restrictions;
import org.junit.Assert;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.monsanto.brazilvaluecapture.core.base.model.bean.Company;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Crop;
import com.monsanto.brazilvaluecapture.core.base.model.bean.VolumeAndValueDTO;
import com.monsanto.brazilvaluecapture.core.base.service.RegionService;
import com.monsanto.brazilvaluecapture.core.base.service.TechnologyService;
import com.monsanto.brazilvaluecapture.core.commercialhierarchy.model.bean.ItsDistrict;
import com.monsanto.brazilvaluecapture.core.commercialhierarchy.model.bean.ItsRegion;
import com.monsanto.brazilvaluecapture.core.commercialhierarchy.model.bean.ItsUnity;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Contract;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Customer;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.HeadOffice;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.ParticipantTypeEnum;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Technology;
import com.monsanto.brazilvaluecapture.core.foundation.test.AbstractServiceIntegrationTests;
import com.monsanto.brazilvaluecapture.core.foundation.test.dbunit.DbUnitHelper;
import com.monsanto.brazilvaluecapture.core.foundation.util.CalendarUtil;
import com.monsanto.brazilvaluecapture.core.grower.model.bean.Grower;
import com.monsanto.brazilvaluecapture.core.user.model.bean.UserDecorator;
import com.monsanto.brazilvaluecapture.core.user.service.UserNotFoundException;
import com.monsanto.brazilvaluecapture.core.user.service.UserService;
import com.monsanto.brazilvaluecapture.pod.rol.model.bean.CsvPaidVolImportLine;
import com.monsanto.brazilvaluecapture.pod.rol.model.bean.PaidVolByGrowerItem;
import com.monsanto.brazilvaluecapture.pod.rol.model.bean.PaidVolumeByGrower;
import com.monsanto.brazilvaluecapture.pod.rol.model.bean.PaidVolumeByGrowerDTO;
import com.monsanto.brazilvaluecapture.pod.rol.model.bean.PaidVolumeByGrowerSearchDTO;
import com.monsanto.brazilvaluecapture.pod.rol.model.bean.PodReportTypeEnum;
import com.monsanto.brazilvaluecapture.pod.rol.model.bean.ReportOnLine;
import com.monsanto.brazilvaluecapture.pod.rol.model.service.PaidVolumeFilter;
import com.monsanto.brazilvaluecapture.pod.rol.model.service.ReportOnLineByGrowerService;
import com.monsanto.brazilvaluecapture.pod.rol.model.service.ReportOnLineInfo;
import com.monsanto.brazilvaluecapture.pod.rol.model.service.ReportOnlineByGrowerConstraintException;
import com.monsanto.brazilvaluecapture.pod.rol.model.service.ReportOnlineByGrowerException;
import com.monsanto.brazilvaluecapture.pod.rol.model.service.ReportOnlineByGrowerWarningException;
import com.monsanto.brazilvaluecapture.pod.rol.model.service.ReportWarningImportedException;

/**
 * @author pmathias
 * 
 */
public class ReportOnLineByGrowerService_AT extends AbstractServiceIntegrationTests {

    /**
     * 
     */
    @Autowired
    private ReportOnLineByGrowerService reportOnLineByGrowerService;

    @Autowired
    private UserService userService;

    @Autowired
    private TechnologyService technologyService;

    @Autowired
    private RegionService regionService;

    /**
     * Configure database data.
     */
    public void setupDBUnit() {

        // Load dbunit
        DbUnitHelper.setup("classpath:data/pod/credit/credit-consumption-dataset.xml",
                "classpath:data/pod/rol/report-online-by-grower-dataset.xml");

    }

    @Test
    public void search_paid_fixed_volume_grower_by_company_crop_period() throws ReportOnlineByGrowerException,
            ParseException {
        setupDBUnit();

        Company company = (Company) getSession().get(Company.class, new Long(900001111)); // MONSANTO
        Crop crop = (Crop) getSession().get(Crop.class, new Long(900001111));// _SOJA_

        PaidVolumeFilter pvFilter = new PaidVolumeFilter();

        pvFilter.setCompany(company);
        pvFilter.setCrop(crop);

        // Must be in September, 2012 (any day, any time)
        Date utilDate = createDate("05/09/2012");

        pvFilter.setInitDate(CalendarUtil.getFirstDateOfMonth(utilDate));
        pvFilter.setEndDate(CalendarUtil.getLastDateOfMonth(utilDate));

        // search for PaidVolumeByGrower list
        List<PaidVolumeByGrower> pvByGrower = reportOnLineByGrowerService
                .selectPaidVolumeByGrowerListByFilter(pvFilter);

        Assert.assertTrue("Expected at least 2 itens. But found: " + pvByGrower.size(), pvByGrower.size() >= 2);

        for (PaidVolumeByGrower item : pvByGrower) {
            if (item.getHeadoffice().getCompany().getId().equals(new Long(900001111))) {
                Assert.assertEquals("Company 900001111 must be returned.", 900001111L, item.getHeadoffice()
                        .getCompany().getId().longValue());
            }
            if (item.getHeadoffice().getCrop().getId().equals(new Long(900001111))) {
                Assert.assertEquals("Crop 900001111 must be returned.", 900001111L, item.getHeadoffice().getCrop()
                        .getId().longValue());
            }
            if (item.getPaidVolumeByGrowerId() == new Long(999900011)) {
                Assert.assertEquals("Paid Volume By Grower id = 999900011 must be returned.", new Long(999900011),
                        item.getPaidVolumeByGrowerId());
                Assert.assertEquals("Expected 30.0 for this paid volume.", new BigDecimal("30"),
                        item.getSumVolumeByGrower());
            }
            if (item.getPaidVolumeByGrowerId() == new Long(999900021)) {
                Assert.assertEquals("Paid Volume By Grower id = 999900021 must be returned.", new Long(999900021),
                        item.getPaidVolumeByGrowerId());
                Assert.assertEquals("Expected 140.0 for this paid volume.", new BigDecimal("140"),
                        item.getSumVolumeByGrower());
            }
        }
    }

    @Test
    public void search_paid_fixed_volume_grower_by_company_crop_period_customer() throws ReportOnlineByGrowerException,
            ParseException {
        setupDBUnit();

        Company company = (Company) getSession().get(Company.class, new Long(900001111)); // MONSANTO
        Crop crop = (Crop) getSession().get(Crop.class, new Long(900001111));// _SOJA_
        Customer customer = (Customer) getSession().get(Customer.class, new Long(900050001)); // Customer

        PaidVolumeFilter pvFilter = new PaidVolumeFilter();

        pvFilter.setCompany(company);
        pvFilter.setCrop(crop);
        pvFilter.setCustomer(customer);

        // Must be in September, 2012 (any day, any time)
        Date utilDate = createDate("05/09/2012");

        pvFilter.setInitDate(CalendarUtil.getFirstDateOfMonth(utilDate));
        pvFilter.setEndDate(CalendarUtil.getLastDateOfMonth(utilDate));

        // search for PaidVolumeByGrower list
        List<PaidVolumeByGrower> pvByGrower = reportOnLineByGrowerService
                .selectPaidVolumeByGrowerListByFilter(pvFilter);

        Assert.assertTrue("Expected at least 2 itens. But found: " + pvByGrower.size(), pvByGrower.size() >= 2);

        for (PaidVolumeByGrower item : pvByGrower) {
            if (item.getHeadoffice().getCompany().getId().equals(new Long(900001111))) {
                Assert.assertEquals("Company 900001111 must be returned.", 900001111L, item.getHeadoffice()
                        .getCompany().getId().longValue());
            }
            if (item.getHeadoffice().getCrop().getId().equals(new Long(900001111))) {
                Assert.assertEquals("Crop 900001111 must be returned.", 900001111L, item.getHeadoffice().getCrop()
                        .getId().longValue());
            }
            if (item.getHeadoffice().getCustomer().getId().equals(new Long(900050001))) {
                Assert.assertEquals("Customer 900050001 must be returned.", 900050001L, item.getHeadoffice()
                        .getCustomer().getId().longValue());
            }
            if (item.getPaidVolumeByGrowerId() == new Long(999900011)) {
                Assert.assertEquals("Paid Volume By Grower id = 999900011 must be returned.", new Long(999900011),
                        item.getPaidVolumeByGrowerId());
                Assert.assertEquals("Expected 30.0 for this paid volume.", new BigDecimal("30"),
                        item.getSumVolumeByGrower());
            }
            if (item.getPaidVolumeByGrowerId() == new Long(999900021)) {
                Assert.assertEquals("Paid Volume By Grower id = 999900021 must be returned.", new Long(999900021),
                        item.getPaidVolumeByGrowerId());
                Assert.assertEquals("Expected 140.0 for this paid volume.", new BigDecimal("140"),
                        item.getSumVolumeByGrower());
            }
        }
    }

    /**
     * @throws ReportOnlineByGrowerException
     * @throws UserNotFoundException
     */
    @Test
    public void search_paid_fixed_volume_grower_by_company_crop_period_customer_and_invalid_contracts_expected_empty_list()
            throws ReportOnlineByGrowerException, UserNotFoundException {

        setupDBUnit();

        Company company = (Company) getSession().get(Company.class, new Long(900001111)); // MONSANTO
        Crop crop = (Crop) getSession().load(Crop.class, new Long("900000001"));
        Customer customer = (Customer) getSession().get(Customer.class, new Long(900050001)); // Customer

        // Set logged user
        UserDecorator loggedUser = userService.getUserBy("login1");
        loggedUser.getContractsForContext();
        loggedUser.setContextCrop(crop);

        PaidVolumeFilter pvFilter = new PaidVolumeFilter();

        pvFilter.setCompany(company);
        pvFilter.setCrop(crop);
        pvFilter.setCustomer(customer);
        pvFilter.setInitDate(CalendarUtil.getFirstDateOfMonth(new Date()));
        pvFilter.setEndDate(CalendarUtil.getLastDateOfMonth(new Date()));
        pvFilter.setContracts(loggedUser.getContracts());

        // search for PaidVolumeByGrower list
        List<PaidVolumeByGrower> pvByGrower = reportOnLineByGrowerService
                .selectPaidVolumeByGrowerListByFilter(pvFilter);

        Assert.assertTrue("Expected empty list, because dont have report for contracts in filter." + pvByGrower.size(),
                pvByGrower.isEmpty());

    }

    @Test
    public void search_paid_fixed_volume_grower_by_company_crop_period_customer_matrix()
            throws ReportOnlineByGrowerException, ParseException {
        setupDBUnit();

        Company company = (Company) getSession().get(Company.class, new Long(900001111)); // MONSANTO
        Crop crop = (Crop) getSession().get(Crop.class, new Long(900001111));// _SOJA_
        Customer customer = (Customer) getSession().get(Customer.class, new Long(900050001)); // Customer
        Customer matrix = (Customer) getSession().get(Customer.class, new Long(900070001)); // HeadOffice

        PaidVolumeFilter pvFilter = new PaidVolumeFilter();

        pvFilter.setCompany(company);
        pvFilter.setCrop(crop);
        pvFilter.setCustomer(customer);
        pvFilter.setMatrix(matrix);

        // Must be in September, 2012 (any day, any time)
        Date utilDate = createDate("05/09/2012");

        pvFilter.setInitDate(CalendarUtil.getFirstDateOfMonth(utilDate));
        pvFilter.setEndDate(CalendarUtil.getLastDateOfMonth(utilDate));

        // search for PaidVolumeByGrower list
        List<PaidVolumeByGrower> pvByGrower = reportOnLineByGrowerService
                .selectPaidVolumeByGrowerListByFilter(pvFilter);

        Assert.assertTrue("Expected at least 2 itens. But found: " + pvByGrower.size(), pvByGrower.size() >= 2);

        for (PaidVolumeByGrower item : pvByGrower) {
            if (item.getHeadoffice().getCompany().getId().equals(new Long(900001111))) {
                Assert.assertEquals("Company 900001111 must be returned.", 900001111L, item.getHeadoffice()
                        .getCompany().getId().longValue());
            }
            if (item.getHeadoffice().getCrop().getId().equals(new Long(900001111))) {
                Assert.assertEquals("Crop 900001111 must be returned.", 900001111L, item.getHeadoffice().getCrop()
                        .getId().longValue());
            }
            if (item.getHeadoffice().getCustomer().getId().equals(new Long(900050001))) {
                Assert.assertEquals("Customer 900050001 must be returned.", 900050001L, item.getHeadoffice()
                        .getCustomer().getId().longValue());
            }
            if (item.getHeadoffice().getId().equals(new Long(900070001))) {
                Assert.assertEquals("Matrix 900070001 must be returned.", 900070001L, item.getHeadoffice().getId()
                        .longValue());
            }
            if (item.getPaidVolumeByGrowerId() == new Long(999900011)) {
                Assert.assertEquals("Paid Volume By Grower id = 999900011 must be returned.", new Long(999900011),
                        item.getPaidVolumeByGrowerId());
                Assert.assertEquals("Expected 30.0 for this paid volume.", new BigDecimal("30"),
                        item.getSumVolumeByGrower());
            }
            if (item.getPaidVolumeByGrowerId() == new Long(999900021)) {
                Assert.assertEquals("Paid Volume By Grower id = 999900021 must be returned.", new Long(999900021),
                        item.getPaidVolumeByGrowerId());
                Assert.assertEquals("Expected 140.0 for this paid volume.", new BigDecimal("140"),
                        item.getSumVolumeByGrower());
            }
        }
    }

    @Test
    public void search_paid_fixed_volume_by_grower_all() throws ReportOnlineByGrowerException, ParseException {
        setupDBUnit();

        Company company = (Company) getSession().get(Company.class, new Long(900001111)); // MONSANTO
        Crop crop = (Crop) getSession().get(Crop.class, new Long(900001111));// _SOJA_
        Customer customer = (Customer) getSession().get(Customer.class, new Long(900050001)); // Customer
        Customer matrix = (Customer) getSession().get(Customer.class, new Long(900070001)); // HeadOffice
        Grower grower = (Grower) getSession().get(Grower.class, new Long(999900011)); // Grower

        PaidVolumeFilter pvFilter = new PaidVolumeFilter();

        pvFilter.setCompany(company);
        pvFilter.setCrop(crop);
        pvFilter.setCustomer(customer);
        pvFilter.setMatrix(matrix);
        pvFilter.setGrower(grower);

        // Must be in September, 2012 (any day, any time)
        Date utilDate = createDate("05/09/2012");

        pvFilter.setInitDate(CalendarUtil.getFirstDateOfMonth(utilDate));
        pvFilter.setEndDate(CalendarUtil.getLastDateOfMonth(utilDate));

        // search for PaidVolumeByGrower list
        List<PaidVolumeByGrower> pvByGrower = reportOnLineByGrowerService
                .selectPaidVolumeByGrowerListByFilter(pvFilter);

        Assert.assertTrue("Expected at least 1 itens. But found: " + pvByGrower.size(), pvByGrower.size() >= 1);

        for (PaidVolumeByGrower item : pvByGrower) {
            if (item.getHeadoffice().getCompany().getId().equals(new Long(900001111))) {
                Assert.assertEquals("Company 900001111 must be returned.", 900001111L, item.getHeadoffice()
                        .getCompany().getId().longValue());
            }
            if (item.getHeadoffice().getCrop().getId().equals(new Long(900001111))) {
                Assert.assertEquals("Crop 900001111 must be returned.", 900001111L, item.getHeadoffice().getCrop()
                        .getId().longValue());
            }
            if (item.getHeadoffice().getCustomer().getId().equals(new Long(900050001))) {
                Assert.assertEquals("Customer 900050001 must be returned.", 900050001L, item.getHeadoffice()
                        .getCustomer().getId().longValue());
            }
            if (item.getHeadoffice().getId().equals(new Long(900070001))) {
                Assert.assertEquals("Matrix 900070001 must be returned.", 900070001L, item.getHeadoffice().getId()
                        .longValue());
            }
            if (item.getGrower().getId().equals(new Long(999900011))) {
                Assert.assertEquals("Grower 999900011 must be returned.", 999900011L, item.getGrower().getId()
                        .longValue());
            }
            if (item.getPaidVolumeByGrowerId() == new Long(999900011)) {
                Assert.assertEquals("Paid Volume By Grower id = 999900011 must be returned.", new Long(999900011),
                        item.getPaidVolumeByGrowerId());
                Assert.assertEquals("Expected 30.0 for this paid volume.", new BigDecimal("30"),
                        item.getSumVolumeByGrower());
            }
            if (item.getPaidVolumeByGrowerId() == new Long(999900021)) {
                Assert.assertEquals("Paid Volume By Grower id = 999900021 must be returned.", new Long(999900021),
                        item.getPaidVolumeByGrowerId());
                Assert.assertEquals("Expected 140.0 for this paid volume.", new BigDecimal("140"),
                        item.getSumVolumeByGrower());
            }
        }
    }

    @Test
    public void save_paid_volume_default() throws ReportOnlineByGrowerException,
            ReportOnlineByGrowerConstraintException {
        // Set db JUnit
        this.setupDBUnit();

        // Get the informations that will arrive from the screen
        Grower grower = (Grower) getSession().get(Grower.class, new Long(999900011));
        HeadOffice headOffice = (HeadOffice) getSession().get(HeadOffice.class, new Long(900070001));
        Technology technology1 = (Technology) getSession().get(Technology.class, new Long(900003001));
        Technology technology2 = (Technology) getSession().get(Technology.class, new Long(900002001));

        // Create the paid volume
        PaidVolumeByGrower paidVolumeByGrower = new PaidVolumeByGrower();
        paidVolumeByGrower.setGrower(grower);
        paidVolumeByGrower.setHeadoffice(headOffice);

        // The year to be used in this test is 2016, to avoid conflict between
        // local memory database and test database
        Date dth = CalendarUtil.getDate(2016, 8, 22);
        paidVolumeByGrower.setPeriod(dth);
        paidVolumeByGrower.setCreateDate(dth);

        // Create the paid volume items
        Set<PaidVolByGrowerItem> setPaidVolumeItem = new HashSet<PaidVolByGrowerItem>();
        PaidVolByGrowerItem paidVolumeItem1 = new PaidVolByGrowerItem();
        paidVolumeItem1.setPaidVolumeByGrower(paidVolumeByGrower);
        paidVolumeItem1.setTechnology(technology1);
        paidVolumeItem1.setRoyaltyValue(new BigDecimal("10.000"));
        paidVolumeItem1.setVolume(new BigDecimal("10.000"));
        setPaidVolumeItem.add(paidVolumeItem1);

        PaidVolByGrowerItem paidVolumeItem2 = new PaidVolByGrowerItem();
        paidVolumeItem2.setPaidVolumeByGrower(paidVolumeByGrower);
        paidVolumeItem2.setTechnology(technology2);
        paidVolumeItem2.setRoyaltyValue(new BigDecimal("20.000"));
        paidVolumeItem2.setVolume(new BigDecimal("20.000"));
        setPaidVolumeItem.add(paidVolumeItem2);

        // Put the paid volume items in the paid volume
        paidVolumeByGrower.setPaidVolByGrowerItems(setPaidVolumeItem);

        // Persist the information
        this.reportOnLineByGrowerService.savePaidVolumeByGrower(paidVolumeByGrower);

        // Prepare the filter
        Company company = (Company) getSession().get(Company.class, new Long(900001111)); // MONSANTO
        Crop crop = (Crop) getSession().get(Crop.class, new Long(900001111));// _SOJA_

        // Try to find the paid volume just saved (the database has another one)
        PaidVolumeFilter pvFilter = new PaidVolumeFilter();
        pvFilter.setCompany(company);
        pvFilter.setCrop(crop);
        pvFilter.setGrower(grower);
        pvFilter.setInitDate(CalendarUtil.getFirstDateOfMonth(dth));
        pvFilter.setEndDate(CalendarUtil.getLastDateOfMonth(dth));
        List<PaidVolumeByGrower> pvByGrower = this.reportOnLineByGrowerService
                .selectPaidVolumeByGrowerListByFilter(pvFilter);
        Assert.assertEquals("Expect 1 item. But found: " + pvByGrower.size(), 1, pvByGrower.size());
        Assert.assertEquals("Expect 2 items. But found: " + pvByGrower.get(0).getPaidVolByGrowerItems().size(), 2,
                pvByGrower.get(0).getPaidVolByGrowerItems().size());
    }

    @Test
    public void save_paid_volume_empty() throws ReportOnlineByGrowerConstraintException {
        // Set db JUnit
        this.setupDBUnit();

        // Create the paid volume empty
        PaidVolumeByGrower paidVolumeByGrower = null;

        try {
            // Persist the information
            this.reportOnLineByGrowerService.savePaidVolumeByGrower(paidVolumeByGrower);
        } catch (ReportOnlineByGrowerConstraintException e) {
            Assert.assertNotNull("Object shoudn't be null.", e);
        }
    }

    @Test
    public void save_paid_volume_properties_null() throws ReportOnlineByGrowerConstraintException {
        // Set db JUnit
        this.setupDBUnit();

        // Create the paid volume
        PaidVolumeByGrower paidVolumeByGrower = new PaidVolumeByGrower();

        try {
            // Persist the information
            this.reportOnLineByGrowerService.savePaidVolumeByGrower(paidVolumeByGrower);
        } catch (ReportOnlineByGrowerConstraintException e) {
            Assert.assertNotNull("Object shoudn't be null.", e);
        }
    }

    @Test
    public void save_paid_volume_items_null() throws ReportOnlineByGrowerConstraintException {
        // Set db JUnit
        this.setupDBUnit();

        // Get the informations that will arrive from the screen
        Grower grower = (Grower) getSession().get(Grower.class, new Long(999900011));
        HeadOffice headOffice = (HeadOffice) getSession().get(HeadOffice.class, new Long(900070001));

        // Create the paid volume
        PaidVolumeByGrower paidVolumeByGrower = new PaidVolumeByGrower();
        paidVolumeByGrower.setGrower(grower);
        paidVolumeByGrower.setHeadoffice(headOffice);

        // The year to be used in this test is 2016, to avoid conflict between
        // local memory database and test database
        Date dth = CalendarUtil.getDate(2016, 8, 22);
        paidVolumeByGrower.setPeriod(dth);
        paidVolumeByGrower.setCreateDate(dth);

        paidVolumeByGrower.setPaidVolByGrowerItems(null);

        try {
            // Persist the information
            this.reportOnLineByGrowerService.savePaidVolumeByGrower(paidVolumeByGrower);
        } catch (ReportOnlineByGrowerConstraintException e) {
            Assert.assertNotNull("Object shoudn't be null.", e);
        }
    }

    @Test
    public void save_paid_volume_items_empty() throws ReportOnlineByGrowerConstraintException {
        // Set db JUnit
        this.setupDBUnit();

        // Get the informations that will arrive from the screen
        Grower grower = (Grower) getSession().get(Grower.class, new Long(999900011));
        HeadOffice headOffice = (HeadOffice) getSession().get(HeadOffice.class, new Long(900070001));

        // Create the paid volume
        PaidVolumeByGrower paidVolumeByGrower = new PaidVolumeByGrower();
        paidVolumeByGrower.setGrower(grower);
        paidVolumeByGrower.setHeadoffice(headOffice);

        // The year to be used in this test is 2016, to avoid conflict between
        // local memory database and test database
        Date dth = CalendarUtil.getDate(2016, 8, 22);
        paidVolumeByGrower.setPeriod(dth);
        paidVolumeByGrower.setCreateDate(dth);

        // Create the paid volume items
        Set<PaidVolByGrowerItem> setPaidVolumeItem = new HashSet<PaidVolByGrowerItem>();

        // Put the paid volume items in the paid volume
        paidVolumeByGrower.setPaidVolByGrowerItems(setPaidVolumeItem);

        try {
            // Persist the information
            this.reportOnLineByGrowerService.savePaidVolumeByGrower(paidVolumeByGrower);
        } catch (ReportOnlineByGrowerConstraintException e) {
            Assert.assertNotNull("Object shoudn't be null.", e);
        }
    }

    @Test
    public void save_paid_volume_validate_items() throws ReportOnlineByGrowerConstraintException {
        // Set db JUnit
        this.setupDBUnit();

        // Get the informations that will arrive from the screen
        Grower grower = (Grower) getSession().get(Grower.class, new Long(999900011));
        HeadOffice headOffice = (HeadOffice) getSession().get(HeadOffice.class, new Long(900070001));
        Technology technology1 = (Technology) getSession().get(Technology.class, new Long(900003001));

        // Create the paid volume
        PaidVolumeByGrower paidVolumeByGrower = new PaidVolumeByGrower();
        paidVolumeByGrower.setGrower(grower);
        paidVolumeByGrower.setHeadoffice(headOffice);

        // The year to be used in this test is 2016, to avoid conflict between
        // local memory database and test database
        Date dth = CalendarUtil.getDate(2016, 8, 22);
        paidVolumeByGrower.setPeriod(dth);
        paidVolumeByGrower.setCreateDate(dth);

        // Create the paid volume items
        Set<PaidVolByGrowerItem> setPaidVolumeItem = new HashSet<PaidVolByGrowerItem>();
        PaidVolByGrowerItem paidVolumeItem1 = new PaidVolByGrowerItem();
        paidVolumeItem1.setPaidVolumeByGrower(paidVolumeByGrower);
        paidVolumeItem1.setTechnology(technology1);
        paidVolumeItem1.setRoyaltyValue(new BigDecimal("0.000"));
        paidVolumeItem1.setVolume(new BigDecimal("0.000"));
        setPaidVolumeItem.add(paidVolumeItem1);

        // Put the paid volume items in the paid volume
        paidVolumeByGrower.setPaidVolByGrowerItems(setPaidVolumeItem);

        try {
            // Persist the information
            this.reportOnLineByGrowerService.savePaidVolumeByGrower(paidVolumeByGrower);
        } catch (ReportOnlineByGrowerConstraintException e) {
            Assert.assertNotNull("Object shoudn't be null.", e);
        }
    }

    @Test
    public void save_paid_volume_validate_items_volume() throws ReportOnlineByGrowerConstraintException {
        // Set db JUnit
        this.setupDBUnit();

        // Get the informations that will arrive from the screen
        Grower grower = (Grower) getSession().get(Grower.class, new Long(999900011));
        HeadOffice headOffice = (HeadOffice) getSession().get(HeadOffice.class, new Long(900070001));
        Technology technology1 = (Technology) getSession().get(Technology.class, new Long(900003001));

        // Create the paid volume
        PaidVolumeByGrower paidVolumeByGrower = new PaidVolumeByGrower();
        paidVolumeByGrower.setGrower(grower);
        paidVolumeByGrower.setHeadoffice(headOffice);

        // The year to be used in this test is 2016, to avoid conflict between
        // local memory database and test database
        Date dth = CalendarUtil.getDate(2016, 8, 22);
        paidVolumeByGrower.setPeriod(dth);
        paidVolumeByGrower.setCreateDate(dth);

        // Create the paid volume items
        Set<PaidVolByGrowerItem> setPaidVolumeItem = new HashSet<PaidVolByGrowerItem>();
        PaidVolByGrowerItem paidVolumeItem1 = new PaidVolByGrowerItem();
        paidVolumeItem1.setPaidVolumeByGrower(paidVolumeByGrower);
        paidVolumeItem1.setTechnology(technology1);
        paidVolumeItem1.setRoyaltyValue(new BigDecimal("0.000"));
        paidVolumeItem1.setVolume(new BigDecimal("10.000"));
        setPaidVolumeItem.add(paidVolumeItem1);

        // Put the paid volume items in the paid volume
        paidVolumeByGrower.setPaidVolByGrowerItems(setPaidVolumeItem);

        try {
            // Persist the information
            this.reportOnLineByGrowerService.savePaidVolumeByGrower(paidVolumeByGrower);
        } catch (ReportOnlineByGrowerConstraintException e) {
            Assert.assertNotNull("Object shoudn't be null.", e);
        }
    }

    @Test
    public void save_paid_volume_validate_items_value() throws ReportOnlineByGrowerConstraintException {
        // Set db JUnit
        this.setupDBUnit();

        // Get the informations that will arrive from the screen
        Grower grower = (Grower) getSession().get(Grower.class, new Long(999900011));
        HeadOffice headOffice = (HeadOffice) getSession().get(HeadOffice.class, new Long(900070001));
        Technology technology1 = (Technology) getSession().get(Technology.class, new Long(900003001));

        // Create the paid volume
        PaidVolumeByGrower paidVolumeByGrower = new PaidVolumeByGrower();
        paidVolumeByGrower.setGrower(grower);
        paidVolumeByGrower.setHeadoffice(headOffice);

        // The year to be used in this test is 2016, to avoid conflict between
        // local memory database and test database
        Date dth = CalendarUtil.getDate(2016, 8, 22);
        paidVolumeByGrower.setPeriod(dth);
        paidVolumeByGrower.setCreateDate(dth);

        // Create the paid volume items
        Set<PaidVolByGrowerItem> setPaidVolumeItem = new HashSet<PaidVolByGrowerItem>();
        PaidVolByGrowerItem paidVolumeItem1 = new PaidVolByGrowerItem();
        paidVolumeItem1.setPaidVolumeByGrower(paidVolumeByGrower);
        paidVolumeItem1.setTechnology(technology1);
        paidVolumeItem1.setRoyaltyValue(new BigDecimal("10.000"));
        paidVolumeItem1.setVolume(new BigDecimal("0.000"));
        setPaidVolumeItem.add(paidVolumeItem1);

        // Put the paid volume items in the paid volume
        paidVolumeByGrower.setPaidVolByGrowerItems(setPaidVolumeItem);

        try {
            // Persist the information
            this.reportOnLineByGrowerService.savePaidVolumeByGrower(paidVolumeByGrower);
        } catch (ReportOnlineByGrowerConstraintException e) {
            Assert.assertNotNull("Object shoudn't be null.", e);
        }
    }

    @Test
    public void save_paid_volume_items_with_zero() throws ReportOnlineByGrowerException,
            ReportOnlineByGrowerConstraintException {
        // Set db JUnit
        this.setupDBUnit();

        // Get the informations that will arrive from the screen
        Grower grower = (Grower) getSession().get(Grower.class, new Long(999900011));
        HeadOffice headOffice = (HeadOffice) getSession().get(HeadOffice.class, new Long(900070001));
        Technology technology1 = (Technology) getSession().get(Technology.class, new Long(900003001));
        Technology technology2 = (Technology) getSession().get(Technology.class, new Long(900002001));

        // Create the paid volume
        PaidVolumeByGrower paidVolumeByGrower = new PaidVolumeByGrower();
        paidVolumeByGrower.setGrower(grower);
        paidVolumeByGrower.setHeadoffice(headOffice);

        // The year to be used in this test is 2016, to avoid conflict between
        // local memory database and test database
        Date dth = CalendarUtil.getDate(2016, 8, 22);
        paidVolumeByGrower.setPeriod(dth);
        paidVolumeByGrower.setCreateDate(dth);

        // Create the paid volume items
        Set<PaidVolByGrowerItem> setPaidVolumeItem = new HashSet<PaidVolByGrowerItem>();
        PaidVolByGrowerItem paidVolumeItem1 = new PaidVolByGrowerItem();
        paidVolumeItem1.setPaidVolumeByGrower(paidVolumeByGrower);
        paidVolumeItem1.setTechnology(technology1);
        paidVolumeItem1.setRoyaltyValue(new BigDecimal("10.000"));
        paidVolumeItem1.setVolume(new BigDecimal("10.000"));
        setPaidVolumeItem.add(paidVolumeItem1);

        PaidVolByGrowerItem paidVolumeItem2 = new PaidVolByGrowerItem();
        paidVolumeItem2.setPaidVolumeByGrower(paidVolumeByGrower);
        paidVolumeItem2.setTechnology(technology2);
        paidVolumeItem2.setRoyaltyValue(new BigDecimal("0.000"));
        paidVolumeItem2.setVolume(new BigDecimal("0.000"));
        setPaidVolumeItem.add(paidVolumeItem2);

        // Put the paid volume items in the paid volume
        paidVolumeByGrower.setPaidVolByGrowerItems(setPaidVolumeItem);

        // Persist the information
        this.reportOnLineByGrowerService.savePaidVolumeByGrower(paidVolumeByGrower);

        // Prepare the filter
        Company company = (Company) getSession().get(Company.class, new Long(900001111)); // MONSANTO
        Crop crop = (Crop) getSession().get(Crop.class, new Long(900001111));// _SOJA_

        // Try to find the paid volume just saved (the database has another one)
        PaidVolumeFilter pvFilter = new PaidVolumeFilter();
        pvFilter.setCompany(company);
        pvFilter.setCrop(crop);
        pvFilter.setGrower(grower);
        pvFilter.setInitDate(CalendarUtil.getFirstDateOfMonth(dth));
        pvFilter.setEndDate(CalendarUtil.getLastDateOfMonth(dth));
        List<PaidVolumeByGrower> pvByGrower = this.reportOnLineByGrowerService
                .selectPaidVolumeByGrowerListByFilter(pvFilter);
        Assert.assertEquals("Expect 1 item. But found: " + pvByGrower.size(), 1, pvByGrower.size());
    }

    @Test
    public void save_paid_volume_operational_year() throws ReportOnlineByGrowerException {
        // Set db JUnit
        this.setupDBUnit();

        // Get the informations that will arrive from the screen
        Grower grower = (Grower) getSession().get(Grower.class, new Long(999900011));
        HeadOffice headOffice = (HeadOffice) getSession().get(HeadOffice.class, new Long(900070001));
        Technology technology1 = (Technology) getSession().get(Technology.class, new Long(900003001));
        Technology technology2 = (Technology) getSession().get(Technology.class, new Long(900002001));

        // Create the paid volume in a year that doesn't have operational year
        // stored in database
        Date dthDate = CalendarUtil.getDate(1980, 8, 22);
        PaidVolumeByGrower paidVolumeByGrower = new PaidVolumeByGrower();
        paidVolumeByGrower.setGrower(grower);
        paidVolumeByGrower.setHeadoffice(headOffice);
        paidVolumeByGrower.setPeriod(dthDate);
        paidVolumeByGrower.setCreateDate(dthDate);

        // Create the paid volume items
        Set<PaidVolByGrowerItem> setPaidVolumeItem = new HashSet<PaidVolByGrowerItem>();
        PaidVolByGrowerItem paidVolumeItem1 = new PaidVolByGrowerItem();
        paidVolumeItem1.setPaidVolumeByGrower(paidVolumeByGrower);
        paidVolumeItem1.setTechnology(technology1);
        paidVolumeItem1.setRoyaltyValue(new BigDecimal("10.000"));
        paidVolumeItem1.setVolume(new BigDecimal("10.000"));
        setPaidVolumeItem.add(paidVolumeItem1);

        PaidVolByGrowerItem paidVolumeItem2 = new PaidVolByGrowerItem();
        paidVolumeItem2.setPaidVolumeByGrower(paidVolumeByGrower);
        paidVolumeItem2.setTechnology(technology2);
        paidVolumeItem2.setRoyaltyValue(new BigDecimal("20.000"));
        paidVolumeItem2.setVolume(new BigDecimal("20.000"));
        setPaidVolumeItem.add(paidVolumeItem2);

        // Put the paid volume items in the paid volume
        paidVolumeByGrower.setPaidVolByGrowerItems(setPaidVolumeItem);

        try {
            // Persist the information
            this.reportOnLineByGrowerService.savePaidVolumeByGrower(paidVolumeByGrower);
        } catch (ReportOnlineByGrowerConstraintException e) {
            Assert.assertNotNull("Object shoudn't be null.", e);
        }
    }

    @Test
    public void save_paid_volume_rol_no_exists() throws ReportOnlineByGrowerConstraintException {
        // Set db JUnit
        this.setupDBUnit();

        // Get the informations that will arrive from the screen
        Grower grower = (Grower) getSession().get(Grower.class, new Long(999900011));
        HeadOffice headOffice = (HeadOffice) getSession().get(HeadOffice.class, new Long(900070001));
        Technology technology1 = (Technology) getSession().get(Technology.class, new Long(900003001));
        Technology technology2 = (Technology) getSession().get(Technology.class, new Long(900002001));

        // Create the paid volume
        PaidVolumeByGrower paidVolumeByGrower = new PaidVolumeByGrower();
        paidVolumeByGrower.setGrower(grower);
        paidVolumeByGrower.setHeadoffice(headOffice);

        // The year to be used is 2017, which doesn't have a ROL
        Date dth = CalendarUtil.getDate(2017, 8, 22);
        paidVolumeByGrower.setPeriod(dth);
        paidVolumeByGrower.setCreateDate(dth);

        // Create the paid volume items
        Set<PaidVolByGrowerItem> setPaidVolumeItem = new HashSet<PaidVolByGrowerItem>();
        PaidVolByGrowerItem paidVolumeItem1 = new PaidVolByGrowerItem();
        paidVolumeItem1.setPaidVolumeByGrower(paidVolumeByGrower);
        paidVolumeItem1.setTechnology(technology1);
        paidVolumeItem1.setRoyaltyValue(new BigDecimal("10.000"));
        paidVolumeItem1.setVolume(new BigDecimal("10.000"));
        setPaidVolumeItem.add(paidVolumeItem1);

        PaidVolByGrowerItem paidVolumeItem2 = new PaidVolByGrowerItem();
        paidVolumeItem2.setPaidVolumeByGrower(paidVolumeByGrower);
        paidVolumeItem2.setTechnology(technology2);
        paidVolumeItem2.setRoyaltyValue(new BigDecimal("20.000"));
        paidVolumeItem2.setVolume(new BigDecimal("20.000"));
        setPaidVolumeItem.add(paidVolumeItem2);

        // Put the paid volume items in the paid volume
        paidVolumeByGrower.setPaidVolByGrowerItems(setPaidVolumeItem);

        try {
            // Persist the information
            this.reportOnLineByGrowerService.savePaidVolumeByGrower(paidVolumeByGrower);
        } catch (ReportOnlineByGrowerConstraintException e) {
            Assert.assertNotNull("Object shoudn't be null.", e);
        }
    }

    @Test
    public void save_paid_volume_rol_with_no_params() throws ReportOnlineByGrowerConstraintException {
        // Set db JUnit
        this.setupDBUnit();

        // Get the informations that will arrive from the screen
        Grower grower = (Grower) getSession().get(Grower.class, new Long(999900011));
        HeadOffice headOffice = (HeadOffice) getSession().get(HeadOffice.class, new Long(900070001));
        Technology technology1 = (Technology) getSession().get(Technology.class, new Long(900003001));
        Technology technology2 = (Technology) getSession().get(Technology.class, new Long(900002001));

        // Create the paid volume
        PaidVolumeByGrower paidVolumeByGrower = new PaidVolumeByGrower();
        paidVolumeByGrower.setGrower(grower);
        paidVolumeByGrower.setHeadoffice(headOffice);

        // The year to be used is 2018, which has a ROL with no parameters
        Date dth = CalendarUtil.getDate(2018, 8, 22);
        paidVolumeByGrower.setPeriod(dth);
        paidVolumeByGrower.setCreateDate(dth);

        // Create the paid volume items
        Set<PaidVolByGrowerItem> setPaidVolumeItem = new HashSet<PaidVolByGrowerItem>();
        PaidVolByGrowerItem paidVolumeItem1 = new PaidVolByGrowerItem();
        paidVolumeItem1.setPaidVolumeByGrower(paidVolumeByGrower);
        paidVolumeItem1.setTechnology(technology1);
        paidVolumeItem1.setRoyaltyValue(new BigDecimal("10.000"));
        paidVolumeItem1.setVolume(new BigDecimal("10.000"));
        setPaidVolumeItem.add(paidVolumeItem1);

        PaidVolByGrowerItem paidVolumeItem2 = new PaidVolByGrowerItem();
        paidVolumeItem2.setPaidVolumeByGrower(paidVolumeByGrower);
        paidVolumeItem2.setTechnology(technology2);
        paidVolumeItem2.setRoyaltyValue(new BigDecimal("20.000"));
        paidVolumeItem2.setVolume(new BigDecimal("20.000"));
        setPaidVolumeItem.add(paidVolumeItem2);

        // Put the paid volume items in the paid volume
        paidVolumeByGrower.setPaidVolByGrowerItems(setPaidVolumeItem);

        try {
            // Persist the information
            this.reportOnLineByGrowerService.savePaidVolumeByGrower(paidVolumeByGrower);
        } catch (ReportOnlineByGrowerConstraintException e) {
            Assert.assertNotNull("Object shoudn't be null.", e);
        }
    }

    @Test
    public void save_paid_volume_pod_calendar_limit_date() {
        // Set db JUnit
        this.setupDBUnit();

        // Get the informations that will arrive from the screen
        Grower grower = (Grower) getSession().get(Grower.class, new Long(999900011));
        HeadOffice headOffice = (HeadOffice) getSession().get(HeadOffice.class, new Long(900070001));
        Technology technology1 = (Technology) getSession().get(Technology.class, new Long(900003001));
        Technology technology2 = (Technology) getSession().get(Technology.class, new Long(900002001));

        // Create the paid volume
        PaidVolumeByGrower paidVolumeByGrower = new PaidVolumeByGrower();
        paidVolumeByGrower.setGrower(grower);
        paidVolumeByGrower.setHeadoffice(headOffice);

        // The year to be used in this test is 2019, to avoid conflict between
        // local memory database and test database
        Date dth = CalendarUtil.getDate(2019, 7, 22);
        paidVolumeByGrower.setPeriod(dth);
        paidVolumeByGrower.setCreateDate(dth);

        // Create the paid volume items
        Set<PaidVolByGrowerItem> setPaidVolumeItem = new HashSet<PaidVolByGrowerItem>();
        PaidVolByGrowerItem paidVolumeItem1 = new PaidVolByGrowerItem();
        paidVolumeItem1.setPaidVolumeByGrower(paidVolumeByGrower);
        paidVolumeItem1.setTechnology(technology1);
        paidVolumeItem1.setRoyaltyValue(new BigDecimal("10.000"));
        paidVolumeItem1.setVolume(new BigDecimal("10.000"));
        setPaidVolumeItem.add(paidVolumeItem1);

        PaidVolByGrowerItem paidVolumeItem2 = new PaidVolByGrowerItem();
        paidVolumeItem2.setPaidVolumeByGrower(paidVolumeByGrower);
        paidVolumeItem2.setTechnology(technology2);
        paidVolumeItem2.setRoyaltyValue(new BigDecimal("20.000"));
        paidVolumeItem2.setVolume(new BigDecimal("20.000"));
        setPaidVolumeItem.add(paidVolumeItem2);

        // Put the paid volume items in the paid volume
        paidVolumeByGrower.setPaidVolByGrowerItems(setPaidVolumeItem);

        try {
            // Persist the information
            this.reportOnLineByGrowerService.savePaidVolumeByGrower(paidVolumeByGrower);
        } catch (ReportOnlineByGrowerConstraintException e) {
            Assert.assertNotNull("Object shoudn't be null.", e);
        }
    }

    @Test
    public void save_paid_volume_greater_than_used_parameters() {
        // Set db JUnit
        this.setupDBUnit();

        // Get the informations that will arrive from the screen
        Grower grower = (Grower) getSession().get(Grower.class, new Long(999900011));
        HeadOffice headOffice = (HeadOffice) getSession().get(HeadOffice.class, new Long(900070001));
        Technology technology1 = (Technology) getSession().get(Technology.class, new Long(900003001));
        Technology technology2 = (Technology) getSession().get(Technology.class, new Long(900002001));

        // Create the paid volume
        PaidVolumeByGrower paidVolumeByGrower = new PaidVolumeByGrower();
        paidVolumeByGrower.setGrower(grower);
        paidVolumeByGrower.setHeadoffice(headOffice);

        // The year to be used in this test is 2020, to avoid conflict between
        // local memory database and test database
        Date dth = CalendarUtil.getDate(2020, 8, 22);
        paidVolumeByGrower.setPeriod(dth);
        paidVolumeByGrower.setCreateDate(dth);

        // Create the paid volume items
        Set<PaidVolByGrowerItem> setPaidVolumeItem = new HashSet<PaidVolByGrowerItem>();
        PaidVolByGrowerItem paidVolumeItem1 = new PaidVolByGrowerItem();
        paidVolumeItem1.setPaidVolumeByGrower(paidVolumeByGrower);
        paidVolumeItem1.setTechnology(technology1);
        paidVolumeItem1.setRoyaltyValue(new BigDecimal("10.000"));
        paidVolumeItem1.setVolume(new BigDecimal("10.000"));
        setPaidVolumeItem.add(paidVolumeItem1);

        PaidVolByGrowerItem paidVolumeItem2 = new PaidVolByGrowerItem();
        paidVolumeItem2.setPaidVolumeByGrower(paidVolumeByGrower);
        paidVolumeItem2.setTechnology(technology2);
        paidVolumeItem2.setRoyaltyValue(new BigDecimal("20.000"));
        paidVolumeItem2.setVolume(new BigDecimal("20.000"));
        setPaidVolumeItem.add(paidVolumeItem2);

        // Put the paid volume items in the paid volume
        paidVolumeByGrower.setPaidVolByGrowerItems(setPaidVolumeItem);

        try {
            // Persist the information
            this.reportOnLineByGrowerService.savePaidVolumeByGrower(paidVolumeByGrower);
        } catch (ReportOnlineByGrowerConstraintException e) {
            Assert.assertNotNull("Object shoudn't be null.", e);
        }
    }

    @Test
    public void save_paid_volume_insert_twice() throws ReportOnlineByGrowerException,
            ReportOnlineByGrowerConstraintException {
        // Set db JUnit
        this.setupDBUnit();

        // Get the informations that will arrive from the screen
        Grower grower = (Grower) getSession().get(Grower.class, new Long(999900011));
        HeadOffice headOffice = (HeadOffice) getSession().get(HeadOffice.class, new Long(900070001));
        Technology technology1 = (Technology) getSession().get(Technology.class, new Long(900003001));
        Technology technology2 = (Technology) getSession().get(Technology.class, new Long(900002001));

        // Create the paid volume
        PaidVolumeByGrower paidVolumeByGrower = new PaidVolumeByGrower();
        paidVolumeByGrower.setGrower(grower);
        paidVolumeByGrower.setHeadoffice(headOffice);

        // The year to be used in this test is 2016, to avoid conflict between
        // local memory database and test database
        Date dth = CalendarUtil.getDate(2016, 8, 22);
        paidVolumeByGrower.setPeriod(dth);
        paidVolumeByGrower.setCreateDate(dth);

        // Create the paid volume items
        Set<PaidVolByGrowerItem> setPaidVolumeItem = new HashSet<PaidVolByGrowerItem>();
        PaidVolByGrowerItem paidVolumeItem1 = new PaidVolByGrowerItem();
        paidVolumeItem1.setPaidVolumeByGrower(paidVolumeByGrower);
        paidVolumeItem1.setTechnology(technology1);
        paidVolumeItem1.setRoyaltyValue(new BigDecimal("1.000"));
        paidVolumeItem1.setVolume(new BigDecimal("1.000"));
        setPaidVolumeItem.add(paidVolumeItem1);

        PaidVolByGrowerItem paidVolumeItem2 = new PaidVolByGrowerItem();
        paidVolumeItem2.setPaidVolumeByGrower(paidVolumeByGrower);
        paidVolumeItem2.setTechnology(technology2);
        paidVolumeItem2.setRoyaltyValue(new BigDecimal("2.000"));
        paidVolumeItem2.setVolume(new BigDecimal("2.000"));
        setPaidVolumeItem.add(paidVolumeItem2);

        // Put the paid volume items in the paid volume
        paidVolumeByGrower.setPaidVolByGrowerItems(setPaidVolumeItem);

        // Persist the information
        this.reportOnLineByGrowerService.savePaidVolumeByGrower(paidVolumeByGrower);

        // Prepare the filter
        Company company = (Company) getSession().get(Company.class, new Long(900001111)); // MONSANTO
        Crop crop = (Crop) getSession().get(Crop.class, new Long(900001111));// _SOJA_

        // Try to find the paid volume just saved (the database has another one)
        PaidVolumeFilter pvFilter = new PaidVolumeFilter();
        pvFilter.setCompany(company);
        pvFilter.setCrop(crop);
        pvFilter.setGrower(grower);
        pvFilter.setInitDate(CalendarUtil.getFirstDateOfMonth(dth));
        pvFilter.setEndDate(CalendarUtil.getLastDateOfMonth(dth));
        List<PaidVolumeByGrower> pvByGrower = this.reportOnLineByGrowerService
                .selectPaidVolumeByGrowerListByFilter(pvFilter);
        Assert.assertEquals("Expect 1 item. But found: " + pvByGrower.size(), 1, pvByGrower.size());
        Assert.assertEquals("Expect 2 items. But found: " + pvByGrower.get(0).getPaidVolByGrowerItems().size(), 2,
                pvByGrower.get(0).getPaidVolByGrowerItems().size());

        // Create the new paid volume
        paidVolumeByGrower = new PaidVolumeByGrower();
        paidVolumeByGrower.setGrower(grower);
        paidVolumeByGrower.setHeadoffice(headOffice);

        // The year to be used in this test is 2016, to avoid conflict between
        // local memory database and test database
        dth = CalendarUtil.getDate(2016, 8, 23);
        paidVolumeByGrower.setPeriod(dth);
        paidVolumeByGrower.setCreateDate(dth);

        // Create the paid volume items
        setPaidVolumeItem = new HashSet<PaidVolByGrowerItem>();
        paidVolumeItem1 = new PaidVolByGrowerItem();
        paidVolumeItem1.setPaidVolumeByGrower(paidVolumeByGrower);
        paidVolumeItem1.setTechnology(technology1);
        paidVolumeItem1.setRoyaltyValue(new BigDecimal("1.000"));
        paidVolumeItem1.setVolume(new BigDecimal("1.000"));
        setPaidVolumeItem.add(paidVolumeItem1);

        paidVolumeItem2 = new PaidVolByGrowerItem();
        paidVolumeItem2.setPaidVolumeByGrower(paidVolumeByGrower);
        paidVolumeItem2.setTechnology(technology2);
        paidVolumeItem2.setRoyaltyValue(new BigDecimal("2.000"));
        paidVolumeItem2.setVolume(new BigDecimal("2.000"));
        setPaidVolumeItem.add(paidVolumeItem2);

        // Put the paid volume items in the paid volume
        paidVolumeByGrower.setPaidVolByGrowerItems(setPaidVolumeItem);

        // Persist the information
        this.reportOnLineByGrowerService.savePaidVolumeByGrower(paidVolumeByGrower);
    }

    @Test
    public void save_paid_volume_value_and_volume_null() {
        // Set db JUnit
        this.setupDBUnit();

        // Get the informations that will arrive from the screen
        Grower grower = (Grower) getSession().get(Grower.class, new Long(999900011));
        HeadOffice headOffice = (HeadOffice) getSession().get(HeadOffice.class, new Long(900070001));
        Technology technology1 = (Technology) getSession().get(Technology.class, new Long(900003001));

        // Create the paid volume
        PaidVolumeByGrower paidVolumeByGrower = new PaidVolumeByGrower();
        paidVolumeByGrower.setGrower(grower);
        paidVolumeByGrower.setHeadoffice(headOffice);

        // The year to be used in this test is 2020, to avoid conflict between
        // local memory database and test database
        Date dth = CalendarUtil.getDate(2020, 8, 22);
        paidVolumeByGrower.setPeriod(dth);
        paidVolumeByGrower.setCreateDate(dth);

        // Create the paid volume items
        Set<PaidVolByGrowerItem> setPaidVolumeItem = new HashSet<PaidVolByGrowerItem>();
        PaidVolByGrowerItem paidVolumeItem1 = new PaidVolByGrowerItem();
        paidVolumeItem1.setPaidVolumeByGrower(paidVolumeByGrower);
        paidVolumeItem1.setTechnology(technology1);
        paidVolumeItem1.setRoyaltyValue(null);
        paidVolumeItem1.setVolume(null);
        setPaidVolumeItem.add(paidVolumeItem1);

        // Put the paid volume items in the paid volume
        paidVolumeByGrower.setPaidVolByGrowerItems(setPaidVolumeItem);

        try {
            // Persist the information
            this.reportOnLineByGrowerService.savePaidVolumeByGrower(paidVolumeByGrower);
        } catch (ReportOnlineByGrowerConstraintException e) {
            Assert.assertNotNull("Object shoudn't be null.", e);
        }
    }

    @Test
    public void save_paid_volume_rol_with_no_used_params() throws ReportOnlineByGrowerException,
            ReportOnlineByGrowerConstraintException {
        // Set db JUnit
        this.setupDBUnit();

        // Get the informations that will arrive from the screen
        Grower grower = (Grower) getSession().get(Grower.class, new Long(999900011));
        HeadOffice headOffice = (HeadOffice) getSession().get(HeadOffice.class, new Long(900070001));
        Technology technology1 = (Technology) getSession().get(Technology.class, new Long(900003001));
        Technology technology2 = (Technology) getSession().get(Technology.class, new Long(900002001));

        // Create the paid volume
        PaidVolumeByGrower paidVolumeByGrower = new PaidVolumeByGrower();
        paidVolumeByGrower.setGrower(grower);
        paidVolumeByGrower.setHeadoffice(headOffice);

        // The year to be used in this test is 2016, to avoid conflict between
        // local memory database and test database
        Date dth = CalendarUtil.getDate(2016, 8, 22);
        paidVolumeByGrower.setPeriod(dth);
        paidVolumeByGrower.setCreateDate(dth);

        // Create the paid volume items
        Set<PaidVolByGrowerItem> setPaidVolumeItem = new HashSet<PaidVolByGrowerItem>();
        PaidVolByGrowerItem paidVolumeItem1 = new PaidVolByGrowerItem();
        paidVolumeItem1.setPaidVolumeByGrower(paidVolumeByGrower);
        paidVolumeItem1.setTechnology(technology1);
        paidVolumeItem1.setRoyaltyValue(new BigDecimal("1.000"));
        paidVolumeItem1.setVolume(new BigDecimal("1.000"));
        setPaidVolumeItem.add(paidVolumeItem1);

        PaidVolByGrowerItem paidVolumeItem2 = new PaidVolByGrowerItem();
        paidVolumeItem2.setPaidVolumeByGrower(paidVolumeByGrower);
        paidVolumeItem2.setTechnology(technology2);
        paidVolumeItem2.setRoyaltyValue(new BigDecimal("2.000"));
        paidVolumeItem2.setVolume(new BigDecimal("2.000"));
        setPaidVolumeItem.add(paidVolumeItem2);

        // Put the paid volume items in the paid volume
        paidVolumeByGrower.setPaidVolByGrowerItems(setPaidVolumeItem);

        try {
            // Persist the information
            this.reportOnLineByGrowerService.savePaidVolumeByGrower(paidVolumeByGrower);
        } catch (ReportOnlineByGrowerConstraintException e) {
            Assert.assertNotNull("Object shoudn't be null.", e);
        }
    }

    @Test
    public void save_paid_volume_rol_lower() throws ReportOnlineByGrowerException,
            ReportOnlineByGrowerConstraintException {
        // Set db JUnit
        this.setupDBUnit();

        // Get the informations that will arrive from the screen
        Grower grower = (Grower) getSession().get(Grower.class, new Long(999900011));
        HeadOffice headOffice = (HeadOffice) getSession().get(HeadOffice.class, new Long(900070001));
        Technology technology1 = (Technology) getSession().get(Technology.class, new Long(900003001));
        Technology technology2 = (Technology) getSession().get(Technology.class, new Long(900002001));

        // Create the paid volume
        PaidVolumeByGrower paidVolumeByGrower = new PaidVolumeByGrower();
        paidVolumeByGrower.setGrower(grower);
        paidVolumeByGrower.setHeadoffice(headOffice);

        // The year to be used in this test is 2016, to avoid conflict between
        // local memory database and test database
        Date dth = CalendarUtil.getDate(2016, 8, 22);
        paidVolumeByGrower.setPeriod(dth);
        paidVolumeByGrower.setCreateDate(dth);

        // Create the paid volume items
        Set<PaidVolByGrowerItem> setPaidVolumeItem = new HashSet<PaidVolByGrowerItem>();
        PaidVolByGrowerItem paidVolumeItem1 = new PaidVolByGrowerItem();
        paidVolumeItem1.setPaidVolumeByGrower(paidVolumeByGrower);
        paidVolumeItem1.setTechnology(technology1);
        paidVolumeItem1.setRoyaltyValue(new BigDecimal("10000.000"));
        paidVolumeItem1.setVolume(new BigDecimal("10000.000"));
        setPaidVolumeItem.add(paidVolumeItem1);

        PaidVolByGrowerItem paidVolumeItem2 = new PaidVolByGrowerItem();
        paidVolumeItem2.setPaidVolumeByGrower(paidVolumeByGrower);
        paidVolumeItem2.setTechnology(technology2);
        paidVolumeItem2.setRoyaltyValue(new BigDecimal("20000.000"));
        paidVolumeItem2.setVolume(new BigDecimal("20000.000"));
        setPaidVolumeItem.add(paidVolumeItem2);

        // Put the paid volume items in the paid volume
        paidVolumeByGrower.setPaidVolByGrowerItems(setPaidVolumeItem);

        try {
            // Persist the information
            this.reportOnLineByGrowerService.savePaidVolumeByGrower(paidVolumeByGrower);
        } catch (ReportOnlineByGrowerConstraintException e) {
            Assert.assertNotNull("Object shoudn't be null.", e);
        }
    }

    @Test
    public void save_paid_volume_update() throws ReportOnlineByGrowerException, ReportOnlineByGrowerConstraintException {
        // Set db JUnit
        this.setupDBUnit();

        // Get the informations that will arrive from the screen
        Grower grower = (Grower) getSession().get(Grower.class, new Long(999900011));
        HeadOffice headOffice = (HeadOffice) getSession().get(HeadOffice.class, new Long(900070001));
        Technology technology1 = (Technology) getSession().get(Technology.class, new Long(900003001));
        Technology technology2 = (Technology) getSession().get(Technology.class, new Long(900002001));

        // Create the paid volume
        PaidVolumeByGrower paidVolumeByGrower = new PaidVolumeByGrower();
        paidVolumeByGrower.setGrower(grower);
        paidVolumeByGrower.setHeadoffice(headOffice);

        // The year to be used in this test is 2016, to avoid conflict between
        // local memory database and test database
        Date dth = CalendarUtil.getDate(2016, 8, 22);
        paidVolumeByGrower.setPeriod(dth);
        paidVolumeByGrower.setCreateDate(dth);

        // Create the paid volume items
        Set<PaidVolByGrowerItem> setPaidVolumeItem = new HashSet<PaidVolByGrowerItem>();
        PaidVolByGrowerItem paidVolumeItem1 = new PaidVolByGrowerItem();
        paidVolumeItem1.setPaidVolumeByGrower(paidVolumeByGrower);
        paidVolumeItem1.setTechnology(technology1);
        paidVolumeItem1.setRoyaltyValue(new BigDecimal("1.000"));
        paidVolumeItem1.setVolume(new BigDecimal("1.000"));
        setPaidVolumeItem.add(paidVolumeItem1);

        PaidVolByGrowerItem paidVolumeItem2 = new PaidVolByGrowerItem();
        paidVolumeItem2.setPaidVolumeByGrower(paidVolumeByGrower);
        paidVolumeItem2.setTechnology(technology2);
        paidVolumeItem2.setRoyaltyValue(new BigDecimal("2.000"));
        paidVolumeItem2.setVolume(new BigDecimal("2.000"));
        setPaidVolumeItem.add(paidVolumeItem2);

        // Put the paid volume items in the paid volume
        paidVolumeByGrower.setPaidVolByGrowerItems(setPaidVolumeItem);

        // Persist the information
        this.reportOnLineByGrowerService.savePaidVolumeByGrower(paidVolumeByGrower);

        // Prepare the filter
        Company company = (Company) getSession().get(Company.class, new Long(900001111)); // MONSANTO
        Crop crop = (Crop) getSession().get(Crop.class, new Long(900001111));// _SOJA_

        // Try to find the paid volume just saved (the database has another one)
        PaidVolumeFilter pvFilter = new PaidVolumeFilter();
        pvFilter.setCompany(company);
        pvFilter.setCrop(crop);
        pvFilter.setGrower(grower);
        pvFilter.setInitDate(CalendarUtil.getFirstDateOfMonth(dth));
        pvFilter.setEndDate(CalendarUtil.getLastDateOfMonth(dth));
        List<PaidVolumeByGrower> pvByGrower = this.reportOnLineByGrowerService
                .selectPaidVolumeByGrowerListByFilter(pvFilter);
        Assert.assertEquals("Expect 1 item. But found: " + pvByGrower.size(), 1, pvByGrower.size());
        Assert.assertEquals("Expect 2 items. But found: " + pvByGrower.get(0).getPaidVolByGrowerItems().size(), 2,
                pvByGrower.get(0).getPaidVolByGrowerItems().size());

        for (PaidVolumeByGrower paidVolumeByGrower2 : pvByGrower) {
            // Persist the information
            this.reportOnLineByGrowerService.savePaidVolumeByGrower(paidVolumeByGrower2);
        }
    }

    @Test
    public void save_paid_volume_one_item_null() throws ReportOnlineByGrowerException,
            ReportOnlineByGrowerConstraintException {
        // Set db JUnit
        this.setupDBUnit();

        // Get the informations that will arrive from the screen
        Grower grower = (Grower) getSession().get(Grower.class, new Long(999900011));
        HeadOffice headOffice = (HeadOffice) getSession().get(HeadOffice.class, new Long(900070001));
        Technology technology1 = (Technology) getSession().get(Technology.class, new Long(900003001));
        Technology technology2 = (Technology) getSession().get(Technology.class, new Long(900002001));

        // Create the paid volume
        PaidVolumeByGrower paidVolumeByGrower = new PaidVolumeByGrower();
        paidVolumeByGrower.setGrower(grower);
        paidVolumeByGrower.setHeadoffice(headOffice);

        // The year to be used in this test is 2016, to avoid conflict between
        // local memory database and test database
        Date dth = CalendarUtil.getDate(2016, 8, 22);
        paidVolumeByGrower.setPeriod(dth);
        paidVolumeByGrower.setCreateDate(dth);

        // Create the paid volume items
        Set<PaidVolByGrowerItem> setPaidVolumeItem = new HashSet<PaidVolByGrowerItem>();
        PaidVolByGrowerItem paidVolumeItem1 = new PaidVolByGrowerItem();
        paidVolumeItem1.setPaidVolumeByGrower(paidVolumeByGrower);
        paidVolumeItem1.setTechnology(technology1);
        paidVolumeItem1.setRoyaltyValue(new BigDecimal("10.000"));
        paidVolumeItem1.setVolume(new BigDecimal("10.000"));
        setPaidVolumeItem.add(paidVolumeItem1);

        PaidVolByGrowerItem paidVolumeItem2 = new PaidVolByGrowerItem();
        paidVolumeItem2.setPaidVolumeByGrower(paidVolumeByGrower);
        paidVolumeItem2.setTechnology(technology2);
        paidVolumeItem2.setRoyaltyValue(null);
        paidVolumeItem2.setVolume(null);
        setPaidVolumeItem.add(paidVolumeItem2);

        // Put the paid volume items in the paid volume
        paidVolumeByGrower.setPaidVolByGrowerItems(setPaidVolumeItem);

        // Persist the information
        this.reportOnLineByGrowerService.savePaidVolumeByGrower(paidVolumeByGrower);

        // Prepare the filter
        Company company = (Company) getSession().get(Company.class, new Long(900001111)); // MONSANTO
        Crop crop = (Crop) getSession().get(Crop.class, new Long(900001111));// _SOJA_

        // Try to find the paid volume just saved (the database has another one)
        PaidVolumeFilter pvFilter = new PaidVolumeFilter();
        pvFilter.setCompany(company);
        pvFilter.setCrop(crop);
        pvFilter.setGrower(grower);
        pvFilter.setInitDate(CalendarUtil.getFirstDateOfMonth(dth));
        pvFilter.setEndDate(CalendarUtil.getLastDateOfMonth(dth));
        List<PaidVolumeByGrower> pvByGrower = this.reportOnLineByGrowerService
                .selectPaidVolumeByGrowerListByFilter(pvFilter);
        Assert.assertEquals("Expect 1 item. But found: " + pvByGrower.size(), 1, pvByGrower.size());
        Assert.assertEquals("Expect 2 items. But found: " + pvByGrower.get(0).getPaidVolByGrowerItems().size(), 2,
                pvByGrower.get(0).getPaidVolByGrowerItems().size());
    }

    @Test
    public void delete_paid_volume_default() throws ReportOnlineByGrowerConstraintException,
            ReportOnlineByGrowerException {
        // Set db JUnit
        this.setupDBUnit();

        // Get the informations that will arrive from the screen
        Grower grower = (Grower) getSession().get(Grower.class, new Long(999900011));
        HeadOffice headOffice = (HeadOffice) getSession().get(HeadOffice.class, new Long(900070001));
        Technology technology1 = (Technology) getSession().get(Technology.class, new Long(900003001));
        Technology technology2 = (Technology) getSession().get(Technology.class, new Long(900002001));

        // Create the paid volume
        PaidVolumeByGrower paidVolumeByGrower = new PaidVolumeByGrower();
        paidVolumeByGrower.setGrower(grower);
        paidVolumeByGrower.setHeadoffice(headOffice);

        // The year to be used in this test is 2016, to avoid conflict between
        // local memory database and test database
        Date dth = CalendarUtil.getDate(2016, 8, 22);
        paidVolumeByGrower.setPeriod(dth);
        paidVolumeByGrower.setCreateDate(dth);

        // Create the paid volume items
        Set<PaidVolByGrowerItem> setPaidVolumeItem = new HashSet<PaidVolByGrowerItem>();
        PaidVolByGrowerItem paidVolumeItem1 = new PaidVolByGrowerItem();
        paidVolumeItem1.setPaidVolumeByGrower(paidVolumeByGrower);
        paidVolumeItem1.setTechnology(technology1);
        paidVolumeItem1.setRoyaltyValue(new BigDecimal("10.000"));
        paidVolumeItem1.setVolume(new BigDecimal("10.000"));
        setPaidVolumeItem.add(paidVolumeItem1);

        PaidVolByGrowerItem paidVolumeItem2 = new PaidVolByGrowerItem();
        paidVolumeItem2.setPaidVolumeByGrower(paidVolumeByGrower);
        paidVolumeItem2.setTechnology(technology2);
        paidVolumeItem2.setRoyaltyValue(new BigDecimal("20.000"));
        paidVolumeItem2.setVolume(new BigDecimal("20.000"));
        setPaidVolumeItem.add(paidVolumeItem2);

        // Put the paid volume items in the paid volume
        paidVolumeByGrower.setPaidVolByGrowerItems(setPaidVolumeItem);

        // Persist the information
        this.reportOnLineByGrowerService.savePaidVolumeByGrower(paidVolumeByGrower);

        // Prepare the filter
        Company company = (Company) getSession().get(Company.class, new Long(900001111)); // MONSANTO
        Crop crop = (Crop) getSession().get(Crop.class, new Long(900001111));// _SOJA_

        // Try to find the paid volume just saved (the database has another one)
        PaidVolumeFilter pvFilter = new PaidVolumeFilter();
        pvFilter.setCompany(company);
        pvFilter.setCrop(crop);
        pvFilter.setGrower(grower);
        pvFilter.setInitDate(CalendarUtil.getFirstDateOfMonth(dth));
        pvFilter.setEndDate(CalendarUtil.getLastDateOfMonth(dth));
        List<PaidVolumeByGrower> pvByGrower = this.reportOnLineByGrowerService
                .selectPaidVolumeByGrowerListByFilter(pvFilter);

        for (PaidVolumeByGrower paidVolumeByGrowerDB : pvByGrower) {
            // Delete the paid volumes just found
            this.reportOnLineByGrowerService.deletePaidVolumeByGrower(paidVolumeByGrowerDB.getPrimaryKey());
        }
    }

    @Test
    public void delete_paid_volume_not_exists() {
        // Delete a paid volume that doesn't exist
        this.reportOnLineByGrowerService.deletePaidVolumeByGrower(new Long(1L));
    }

    @Test
    public void search_paid_fixed_volume_by_grower_filter_all() throws ReportOnlineByGrowerException, ParseException {
        setupDBUnit();

        Company company = (Company) getSession().get(Company.class, new Long(900001111)); // MONSANTO
        Crop crop = (Crop) getSession().get(Crop.class, new Long(900001111));// _SOJA_
        Customer customer = (Customer) getSession().get(Customer.class, new Long(900050001)); // Customer
        Customer matrix = (Customer) getSession().get(Customer.class, new Long(900070001)); // HeadOffice
        Grower grower = (Grower) getSession().get(Grower.class, new Long(999900011)); // Grower

        PaidVolumeFilter pvFilter = new PaidVolumeFilter();

        pvFilter.setCompany(company);
        pvFilter.setCrop(crop);
        pvFilter.setCustomer(customer);
        pvFilter.setMatrix(matrix);
        pvFilter.setGrower(grower);

        // Must be in September, 2012 (any day, any time)
        Date utilDate = createDateTime("05/09/2012 05:41:23");

        pvFilter.setInitDate(CalendarUtil.getFirstDateOfMonth(utilDate));
        pvFilter.setEndDate(CalendarUtil.getLastDateOfMonth(utilDate));

        pvFilter.setParticipantType(ParticipantTypeEnum.POD);
        pvFilter.setIsUniqueResult(false);
        pvFilter.setIsLikeByDocument(false);
        pvFilter.setDocument("123456789");

        // search for PaidVolumeByGrower list
        List<PaidVolumeByGrower> pvByGrower = reportOnLineByGrowerService
                .selectPaidVolumeByGrowerListByFilter(pvFilter);

        Assert.assertTrue("Expected at least 1 itens. But found: " + pvByGrower.size(), pvByGrower.size() >= 1);

        for (PaidVolumeByGrower item : pvByGrower) {
            if (item.getHeadoffice().getCompany().getId().equals(new Long(900001111))) {
                Assert.assertEquals("Company 900001111 must be returned.", 900001111L, item.getHeadoffice()
                        .getCompany().getId().longValue());
            }
            if (item.getHeadoffice().getCrop().getId().equals(new Long(900001111))) {
                Assert.assertEquals("Crop 900001111 must be returned.", 900001111L, item.getHeadoffice().getCrop()
                        .getId().longValue());
            }
            if (item.getHeadoffice().getCustomer().getId().equals(new Long(900050001))) {
                Assert.assertEquals("Customer 900050001 must be returned.", 900050001L, item.getHeadoffice()
                        .getCustomer().getId().longValue());
            }
            if (item.getHeadoffice().getId().equals(new Long(900070001))) {
                Assert.assertEquals("Matrix 900070001 must be returned.", 900070001L, item.getHeadoffice().getId()
                        .longValue());
            }
            if (item.getGrower().getId().equals(new Long(999900011))) {
                Assert.assertEquals("Grower 999900011 must be returned.", 999900011L, item.getGrower().getId()
                        .longValue());
            }
        }
    }

    /**
     * 
     */
    @Test
    public void test_select_Paid_volume_by_grower_by_id_expected_a_valid_item() {

        // Load db unit
        setupDBUnit();

        PaidVolumeByGrower entity = this.reportOnLineByGrowerService.selectPaidVolumeByGrowerById(999900021L);
        Assert.assertNotNull("Expected a non-null result.", entity);
        Assert.assertEquals("Entity with id 999900021 not found.", new Long("999900021"), entity.getPrimaryKey());

    }

    @Test
    public void search_paid_fixed_volume_grower_by_company_crop_period_vigent_matrix()
            throws ReportOnlineByGrowerException, ParseException {
        setupDBUnit();

        Company company = (Company) getSession().get(Company.class, new Long(900001111)); // MONSANTO
        Crop crop = (Crop) getSession().get(Crop.class, new Long(900001111));// _SOJA_

        PaidVolumeFilter pvFilter = new PaidVolumeFilter();

        pvFilter.setCompany(company);
        pvFilter.setCrop(crop);
        pvFilter.setOnlyInVigorMatrix(Boolean.TRUE);

        // Must be in September, 2012 (any day, any time)
        Date utilDate = createDate("05/09/2012");

        pvFilter.setInitDate(CalendarUtil.getFirstDateOfMonth(utilDate));
        pvFilter.setEndDate(CalendarUtil.getLastDateOfMonth(utilDate));

        // search for PaidVolumeByGrower list
        List<PaidVolumeByGrower> pvByGrower = reportOnLineByGrowerService
                .selectPaidVolumeByGrowerListByFilter(pvFilter);

        Assert.assertTrue("Expected at least 2 itens. But found: " + pvByGrower.size(), pvByGrower.size() >= 2);

        for (PaidVolumeByGrower item : pvByGrower) {
            if (item.getHeadoffice().getCompany().getId().equals(new Long(900001111))) {
                Assert.assertEquals("Company 900001111 must be returned.", 900001111L, item.getHeadoffice()
                        .getCompany().getId().longValue());
            }
            if (item.getHeadoffice().getCrop().getId().equals(new Long(900001111))) {
                Assert.assertEquals("Crop 900001111 must be returned.", 900001111L, item.getHeadoffice().getCrop()
                        .getId().longValue());
            }
            if (item.getPaidVolumeByGrowerId() == new Long(999900031)) {
                Assert.assertEquals("Paid Volume By Grower id = 999900031 must be returned.", new Long(999900031),
                        item.getPaidVolumeByGrowerId());
                Assert.assertEquals("Expected 30.0 for this paid volume.", new BigDecimal("30"),
                        item.getSumVolumeByGrower());
            }
            if (item.getPaidVolumeByGrowerId() == new Long(999900041)) {
                Assert.assertEquals("Paid Volume By Grower id = 999900041 must be returned.", new Long(999900041),
                        item.getPaidVolumeByGrowerId());
                Assert.assertEquals("Expected 140.0 for this paid volume.", new BigDecimal("140"),
                        item.getSumVolumeByGrower());
            }
        }
    }

    @Test
    public void search_paid_fixed_volume_grower_by_company_crop_period_vigent_matrix_expirated()
            throws ReportOnlineByGrowerException, ParseException {
        setupDBUnit();

        Company company = (Company) getSession().get(Company.class, new Long(900001111)); // MONSANTO
        Assert.assertNotNull(company);
        Crop crop = (Crop) getSession().get(Crop.class, new Long(900001111));// _SOJA_
        Assert.assertNotNull(crop);
        Contract contract = (Contract) getSession().get(Contract.class, new Long(900050002)); // Contract
        Assert.assertNotNull(contract);
        Date vigentDate = CalendarUtil.add(Calendar.YEAR, 1, contract.getEndDate());

        PaidVolumeFilter pvFilter = new PaidVolumeFilter();

        pvFilter.setCompany(company);
        pvFilter.setCrop(crop);
        pvFilter.setOnlyInVigorMatrix(Boolean.TRUE);
        pvFilter.setVigentDate(vigentDate);

        // Must be in September, 2012 (any day, any time)
        Date utilDate = createDate("05/09/2012");

        pvFilter.setInitDate(CalendarUtil.getFirstDateOfMonth(utilDate));
        pvFilter.setEndDate(CalendarUtil.getLastDateOfMonth(utilDate));

        // search for PaidVolumeByGrower list
        List<PaidVolumeByGrower> pvByGrower = reportOnLineByGrowerService
                .selectPaidVolumeByGrowerListByFilter(pvFilter);

        Assert.assertTrue("Expected at least 0 itens. But found: " + pvByGrower.size(), pvByGrower.size() == 0);
    }

    @Test
    public void search_paid_fixed_volume_grower_by_company_crop_period_vigent_matrix_not_valid()
            throws ReportOnlineByGrowerException, ParseException {
        setupDBUnit();

        Company company = (Company) getSession().get(Company.class, new Long(900001111)); // MONSANTO
        Assert.assertNotNull(company);
        Crop crop = (Crop) getSession().get(Crop.class, new Long(900001111));// _SOJA_
        Assert.assertNotNull(crop);
        Contract contract = (Contract) getSession().get(Contract.class, new Long(900050002)); // Contract
        Assert.assertNotNull(contract);
        Date vigentDate = CalendarUtil.add(Calendar.YEAR, -5, contract.getStartDate());

        PaidVolumeFilter pvFilter = new PaidVolumeFilter();

        pvFilter.setCompany(company);
        pvFilter.setCrop(crop);
        pvFilter.setOnlyInVigorMatrix(Boolean.TRUE);
        pvFilter.setVigentDate(vigentDate);
        pvFilter.setParticipantType(ParticipantTypeEnum.POD);

        // Must be in September, 2012 (any day, any time)
        Date utilDate = createDate("05/09/2012");

        pvFilter.setInitDate(CalendarUtil.getFirstDateOfMonth(utilDate));
        pvFilter.setEndDate(CalendarUtil.getLastDateOfMonth(utilDate));

        // search for PaidVolumeByGrower list
        List<PaidVolumeByGrower> pvByGrower = reportOnLineByGrowerService
                .selectPaidVolumeByGrowerListByFilter(pvFilter);

        Assert.assertTrue("Expected at least 0 itens. But found: " + pvByGrower.size(), pvByGrower.size() == 0);
    }

    @Test(expected = IllegalArgumentException.class)
    public void test_select_paid_volume_by_grower_with_null_filter_expected_illegal_argument_exception() {
        reportOnLineByGrowerService.selectPaidVolumeByGrower(null);
    }

    @Test(expected = IllegalArgumentException.class)
    public void test_select_paid_volume_by_grower_without_crop_expected_illegal_argument_exception() {

        // Set filter
        PaidVolumeFilter filter = new PaidVolumeFilter();
        filter.setCompany(new Company());

        reportOnLineByGrowerService.selectPaidVolumeByGrower(filter);
    }

    @Test(expected = IllegalArgumentException.class)
    public void test_select_paid_volume_by_grower_without_company_expected_illegal_argument_exception() {

        // Set filter
        PaidVolumeFilter filter = new PaidVolumeFilter();
        filter.setCrop(new Crop());

        reportOnLineByGrowerService.selectPaidVolumeByGrower(filter);
    }

    @Test(expected = IllegalArgumentException.class)
    public void test_select_paid_volume_by_grower_and_crop_company_without_technologies_expected_illega_argument_exception() {

        // Load database
        setupDBUnit();

        // Set filter
        PaidVolumeFilter filter = new PaidVolumeFilter();
        filter.setCrop((Crop) getSession().get(Crop.class, 900001111L));
        filter.setCompany((Company) getSession().get(Company.class, 900001111L));
        filter.setInitDate(CalendarUtil.getDate(1500, 1, 1));
        filter.setEndDate(CalendarUtil.getDate(2500, 1, 1));

        // Execute search
        List<PaidVolumeByGrowerDTO> result = reportOnLineByGrowerService.selectPaidVolumeByGrower(filter);
        Assert.assertNotNull(result);
        Assert.assertFalse(result.isEmpty());

    }

    @Test
    public void test_select_paid_volume_by_grower_and_crop_company() {

        // Load database
        setupDBUnit();

        // Set filter
        PaidVolumeFilter filter = new PaidVolumeFilter();
        filter.setCrop((Crop) getSession().get(Crop.class, 900001111L));
        filter.setCompany((Company) getSession().get(Company.class, 900001111L));
        filter.setInitDate(CalendarUtil.getDate(1500, 1, 1));
        filter.setEndDate(CalendarUtil.getDate(2500, 1, 1));

        // Load technologies
        filter.getTechnologies().add((Technology) getSession().get(Technology.class, 900002001L));
        filter.getTechnologies().add((Technology) getSession().get(Technology.class, 900003001L));

        // Execute search
        List<PaidVolumeByGrowerDTO> result = reportOnLineByGrowerService.selectPaidVolumeByGrower(filter);
        Assert.assertNotNull(result);
        Assert.assertFalse(result.isEmpty());

    }

    @Test
    public void test_select_paid_volume_by_grower_and_crop_company_matrix_unity() {

        // Load database
        setupDBUnit();

        // Set filter
        PaidVolumeFilter filter = new PaidVolumeFilter();
        filter.setCrop((Crop) getSession().get(Crop.class, 900001111L));
        filter.setCompany((Company) getSession().get(Company.class, 900001111L));
        filter.setInitDate(CalendarUtil.getDate(1500, 1, 1));
        filter.setEndDate(CalendarUtil.getDate(2500, 1, 1));
        filter.setMatrixUnity((ItsUnity) getSession().get(ItsUnity.class, 990000000L));

        // Load technologies
        filter.getTechnologies().add((Technology) getSession().get(Technology.class, 900002001L));
        filter.getTechnologies().add((Technology) getSession().get(Technology.class, 900003001L));

        // Execute search
        List<PaidVolumeByGrowerDTO> result = reportOnLineByGrowerService.selectPaidVolumeByGrower(filter);
        Assert.assertNotNull(result);
        Assert.assertFalse(result.isEmpty());

        for (PaidVolumeByGrowerDTO dto : result) {
            Assert.assertEquals(filter.getMatrixUnity().getUnitySapDesc(), dto.getMatrixUnity());
        }

    }

    @Test
    public void test_select_paid_volume_by_grower_and_crop_company_matrix_unity_region() {

        // Load database
        setupDBUnit();

        // Set filter
        PaidVolumeFilter filter = new PaidVolumeFilter();
        filter.setCrop((Crop) getSession().get(Crop.class, 900001111L));
        filter.setCompany((Company) getSession().get(Company.class, 900001111L));
        filter.setInitDate(CalendarUtil.getDate(1500, 1, 1));
        filter.setEndDate(CalendarUtil.getDate(2500, 1, 1));
        filter.setMatrixUnity((ItsUnity) getSession().get(ItsUnity.class, 990000000L));
        filter.setMatrixRegion((ItsRegion) getSession().get(ItsRegion.class, 990000000L));

        // Load technologies
        filter.getTechnologies().add((Technology) getSession().get(Technology.class, 900002001L));
        filter.getTechnologies().add((Technology) getSession().get(Technology.class, 900003001L));

        // Execute search
        List<PaidVolumeByGrowerDTO> result = reportOnLineByGrowerService.selectPaidVolumeByGrower(filter);
        Assert.assertNotNull(result);
        Assert.assertFalse(result.isEmpty());

        for (PaidVolumeByGrowerDTO dto : result) {
            Assert.assertEquals(filter.getMatrixUnity().getUnitySapDesc(), dto.getMatrixUnity());
            Assert.assertEquals(filter.getMatrixRegion().getRegionSapDesc(), dto.getMatrixRegion());
        }

    }

    @Test
    public void test_select_paid_volume_by_grower_and_crop_company_matrix_unity_region_district() {

        // Load database
        setupDBUnit();

        // Set filter
        PaidVolumeFilter filter = new PaidVolumeFilter();
        filter.setCrop((Crop) getSession().get(Crop.class, 900001111L));
        filter.setCompany((Company) getSession().get(Company.class, 900001111L));
        filter.setInitDate(CalendarUtil.getDate(1500, 1, 1));
        filter.setEndDate(CalendarUtil.getDate(2500, 1, 1));
        filter.setMatrixUnity((ItsUnity) getSession().get(ItsUnity.class, 990000000L));
        filter.setMatrixRegion((ItsRegion) getSession().get(ItsRegion.class, 990000000L));
        filter.setMatrixDistrict((ItsDistrict) getSession().get(ItsDistrict.class, 990000000L));

        // Load technologies
        filter.getTechnologies().add((Technology) getSession().get(Technology.class, 900002001L));
        filter.getTechnologies().add((Technology) getSession().get(Technology.class, 900003001L));

        // Execute search
        List<PaidVolumeByGrowerDTO> result = reportOnLineByGrowerService.selectPaidVolumeByGrower(filter);
        Assert.assertNotNull(result);
        Assert.assertFalse(result.isEmpty());

        for (PaidVolumeByGrowerDTO dto : result) {
            Assert.assertEquals(filter.getMatrixUnity().getUnitySapDesc(), dto.getMatrixUnity());
            Assert.assertEquals(filter.getMatrixRegion().getRegionSapDesc(), dto.getMatrixRegion());
            Assert.assertEquals(filter.getMatrixDistrict().getDistrictSapDesc(), dto.getMatrixDistrict());
        }

    }

    @Test
    public void test_select_paid_volume_by_grower_and_crop_company_grower_unity_region_district() {

        // Load database
        setupDBUnit();

        // Set filter
        PaidVolumeFilter filter = new PaidVolumeFilter();
        filter.setCrop((Crop) getSession().get(Crop.class, 900001111L));
        filter.setCompany((Company) getSession().get(Company.class, 900001111L));
        filter.setInitDate(CalendarUtil.getDate(1500, 1, 1));
        filter.setEndDate(CalendarUtil.getDate(2500, 1, 1));
        filter.setGrowerUnity((ItsUnity) getSession().get(ItsUnity.class, 990000000L));
        filter.setGrowerRegion((ItsRegion) getSession().get(ItsRegion.class, 990000000L));
        filter.setGrowerDistrict((ItsDistrict) getSession().get(ItsDistrict.class, 990000000L));

        // Load technologies
        filter.getTechnologies().add((Technology) getSession().get(Technology.class, 900002001L));
        filter.getTechnologies().add((Technology) getSession().get(Technology.class, 900003001L));

        // Execute search
        List<PaidVolumeByGrowerDTO> result = reportOnLineByGrowerService.selectPaidVolumeByGrower(filter);
        Assert.assertNotNull(result);
        Assert.assertFalse(result.isEmpty());

        for (PaidVolumeByGrowerDTO dto : result) {
            Assert.assertEquals(filter.getGrowerUnity().getUnitySapDesc(), dto.getGrowerUnity());
            Assert.assertEquals(filter.getGrowerRegion().getRegionSapDesc(), dto.getGrowerRegion());
            Assert.assertEquals(filter.getGrowerDistrict().getDistrictSapDesc(), dto.getGrowerDistrict());
        }

    }

    @Test
    public void test_select_paid_volume_consolidate_by_grower_and_crop_company_grower_unity_region_district() {

        // Load database
        setupDBUnit();

        // Set filter
        PaidVolumeFilter filter = new PaidVolumeFilter();
        filter.setCrop((Crop) getSession().get(Crop.class, 900001111L));
        filter.setCompany((Company) getSession().get(Company.class, 900001111L));
        filter.setInitDate(CalendarUtil.getDate(1500, 1, 1));
        filter.setEndDate(CalendarUtil.getDate(2500, 1, 1));
        filter.setGrowerUnity((ItsUnity) getSession().get(ItsUnity.class, 990000000L));
        filter.setGrowerRegion((ItsRegion) getSession().get(ItsRegion.class, 990000000L));
        filter.setGrowerDistrict((ItsDistrict) getSession().get(ItsDistrict.class, 990000000L));
        filter.setReportType(PodReportTypeEnum.CONSOLIDATED);

        // Load technologies
        filter.getTechnologies().add((Technology) getSession().get(Technology.class, 900002001L));
        filter.getTechnologies().add((Technology) getSession().get(Technology.class, 900003001L));

        // Execute search
        List<PaidVolumeByGrowerDTO> result = reportOnLineByGrowerService.selectPaidVolumeByGrower(filter);
        Assert.assertNotNull(result);
        Assert.assertFalse(result.isEmpty());

        for (PaidVolumeByGrowerDTO dto : result) {
            Assert.assertEquals(filter.getGrowerUnity().getUnitySapDesc(), dto.getGrowerUnity());
            Assert.assertEquals(filter.getGrowerRegion().getRegionSapDesc(), dto.getGrowerRegion());
            Assert.assertEquals(filter.getGrowerDistrict().getDistrictSapDesc(), dto.getGrowerDistrict());
        }

    }

    @Test
    public void test_select_paid_volume_consolidate_by_grower_and_crop_company_matrix_and_technology() {

        // Load database
        setupDBUnit();

        // Set filter
        PaidVolumeFilter filter = new PaidVolumeFilter();
        filter.setCrop((Crop) getSession().get(Crop.class, 900001111L));
        filter.setCompany((Company) getSession().get(Company.class, 900001111L));
        filter.setInitDate(CalendarUtil.getDate(1500, 1, 1));
        filter.setEndDate(CalendarUtil.getDate(2500, 1, 1));
        filter.setReportType(PodReportTypeEnum.CONSOLIDATED);

        // Load matrix
        filter.setMatrix((Customer) getSession().get(Customer.class, 900050002L));
        Assert.assertNotNull(filter.getMatrix());

        // Load technologies
        Technology tech = (Technology) getSession().get(Technology.class, 900003001L);
        filter.getTechnologies().add(tech);

        // Execute search
        List<PaidVolumeByGrowerDTO> result = reportOnLineByGrowerService.selectPaidVolumeByGrower(filter);
        Assert.assertNotNull(result);
        Assert.assertFalse(result.isEmpty());
        Assert.assertTrue("Expected only one record.", result.size() == 1);

        for (PaidVolumeByGrowerDTO dto : result) {
            Assert.assertEquals(filter.getMatrix().getDocumentValue(), dto.getMatrixDocument());
            Assert.assertEquals(tech.getDescription(), dto.getTechnology());
            Assert.assertEquals(new BigDecimal("1001"), dto.getQuantityTon());
            Assert.assertEquals(new BigDecimal("81"), dto.getRoyaltMoneyValue());
            Assert.assertTrue(dto.getTotalBilled().compareTo(new BigDecimal("4.4")) == 0);
            Assert.assertTrue(dto.getTotalRoyaltMoneyValue().compareTo(new BigDecimal("6.6")) == 0);
        }

    }

    @Test
    public void test_validate_csv_paidVolByGrower_invalid_numeric_values() {
        // Set db JUnit exceeding
        this.setupDBUnit();
        Technology technology1 = (Technology) getSession().get(Technology.class, new Long(900003001));
        // period
        Date dth = CalendarUtil.getDate(2016, 8, 22);
        CsvPaidVolImportLine entity = getCsvPaidVolImportLine("CNPJ", "99999999999999366", "CPF", "123999789", dth,
                CalendarUtil.getDateNow(), technology1.getDescription(), new BigDecimal("-10000.000"), new BigDecimal(
                        "10000.000"), 1);

        ReportOnlineByGrowerWarningException exception = null;

        try {
            reportOnLineByGrowerService.validatePaidVolumeByGrowerCSV(entity, new ReportOnLineInfo());
        } catch (ReportOnlineByGrowerWarningException e) {
            exception = e;
        }

        Assert.assertNotNull(exception);
        Assert.assertTrue(exception.getWarnings().size() > 0);

        // check that there are violations about GROWER NOT FOUND
        List<ReportWarningImportedException> warnings = exception.getWarnings();

        for (ReportWarningImportedException warning : warnings) {
            Assert.assertTrue(warning.countErrors() > 0);
            // Assert.assertTrue(warning.getMessage().equals(PaidVolImportParser.VOLUME_MUST_BE_GREATER_THAN_ZERO));
        }
    }

    @Test
    public void test_validate_csv_paidVolByGrower_affiliate_not_belonging_to_headoffice() {

        // Set db JUnit exceeding
        this.setupDBUnit();

        // Get the informations that will arrive from the screen
        HeadOffice headOffice = (HeadOffice) getSession().get(HeadOffice.class, new Long(900070001));
        Technology technology1 = (Technology) getSession().get(Technology.class, new Long(900003001));
        // Technology technology2 = (Technology)
        // getSession().get(Technology.class, new Long(900002001));

        // period
        Date dth = CalendarUtil.getDate(2016, 8, 22);
        // customer document: 123999789 DOES NOT belong to the headoffice.
        CsvPaidVolImportLine entity = getCsvPaidVolImportLine("CNPJ", "99999999999999366", "CPF", "123999789", dth,
                CalendarUtil.getDateNow(), technology1.getDescription(), new BigDecimal("10000.000"), new BigDecimal(
                        "10000.000"), 1);

        ReportOnlineByGrowerWarningException exception = null;
        ReportOnLineInfo rolInfo = createReportOnlineInfo(headOffice);
        try {
            reportOnLineByGrowerService.validatePaidVolumeByGrowerCSV(entity, rolInfo);
        } catch (ReportOnlineByGrowerWarningException e) {
            exception = e;
        }

        Assert.assertNotNull(exception);
        Assert.assertTrue(exception.getWarnings().size() > 0);

        // check that there are violations about GROWER NOT FOUND
        List<ReportWarningImportedException> violations = exception.getWarnings();
        for (ReportWarningImportedException warning : violations) {
            Assert.assertTrue(warning.getMessage().equals(
                    ReportOnLineByGrowerService.AFFILIATE_NOT_BELONGING_TO_HEADOFFICE));
        }
    }

    /**
     * @param headOffice
     * @return
     */
    private ReportOnLineInfo createReportOnlineInfo(HeadOffice headOffice) {
        ReportOnLineInfo rolInfo = new ReportOnLineInfo();
        rolInfo.setCompany(headOffice.getCompany());
        rolInfo.setCrop(headOffice.getCrop());
        // select all technologies
        rolInfo.setTechnologyList(technologyService.selectAllTechnology(headOffice.getCompany()));
        // select doc types by country
        rolInfo.setDocTypes(regionService.selectAllByCountry(headOffice.getCompany().getCountry()));
        rolInfo.setPoolOfRols(new HashMap<String, ReportOnLine>());
        return rolInfo;
    }

    /**
     * @return
     */
    private CsvPaidVolImportLine getCsvPaidVolImportLine(String growerDocType, String growerDoc,
            String customerDocType, String customerDoc, Date period, Date dateReceive, String technology,
            BigDecimal royaltValue, BigDecimal vol, Integer line) {
        CsvPaidVolImportLine entity = new CsvPaidVolImportLine();
        entity.setGrowerDocumentType(growerDocType);
        entity.setGrowerDocument(growerDoc);
        entity.setCustomerDocumentType(customerDocType);
        entity.setCustomerDocument(customerDoc);
        // period
        entity.setPeriod(period);
        entity.setDateReceive(dateReceive);
        // values
        entity.setRoyaltyValue(royaltValue);
        entity.setVolume(vol);
        entity.setTechnology(technology);
        entity.setLine(line);
        return entity;
    }

    @Test
    public void test_select_volume_and_value_from_grower_sucess_consolidate() {
        // Load database
        setupDBUnit();

        // Set filter
        PaidVolumeFilter filter = new PaidVolumeFilter();
        filter.setCrop((Crop) getSession().get(Crop.class, 900001111L));
        filter.setCompany((Company) getSession().get(Company.class, 900001111L));
        filter.setInitDate(CalendarUtil.getDate(1500, 1, 1));
        filter.setEndDate(CalendarUtil.getDate(2500, 1, 1));

        // Load matrix
        filter.setMatrix((Customer) getSession().get(Customer.class, 900050002L));
        Assert.assertNotNull(filter.getMatrix());

        // Load technologies
        Technology tech = (Technology) getSession().get(Technology.class, 900003001L);
        filter.getTechnologies().add(tech);

        VolumeAndValueDTO dto = reportOnLineByGrowerService.sumVolumeAndValueFromPaidVolumeByGrowerByFilter(filter);

        Assert.assertNotNull(dto.getVolume());
        Assert.assertNotNull(dto.getValue());

        // Check consistency...
        @SuppressWarnings("unchecked")
        List<PaidVolByGrowerItem> list = getSession().createCriteria(PaidVolByGrowerItem.class, "pi")
                .createAlias("pi.paidVolumeByGrower", "pvg").createAlias("pvg.headoffice", "h")
                .add(Restrictions.eq("h.crop", filter.getCrop()))
                .add(Restrictions.eq("h.company", filter.getCompany()))
                .add(Restrictions.eq("h.matrix", filter.getMatrix())).add(Restrictions.eq("pi.technology", tech))
                .add(Restrictions.ge("pvg.period", CalendarUtil.getFirstDateOfMonth(filter.getInitDate())))
                .add(Restrictions.le("pvg.period", CalendarUtil.getLastDateOfMonth(filter.getEndDate()))).list();

        BigDecimal totalVolume = new BigDecimal(0);
        BigDecimal totalValue = new BigDecimal(0);
        for (PaidVolByGrowerItem item : list) {
            totalVolume = totalVolume.add(item.getVolume());
            totalValue = totalValue.add(item.getRoyaltyValue());
        }

        Assert.assertTrue(dto.getVolume().equals(totalVolume));
        Assert.assertTrue(dto.getValue().equals(totalValue));

    }

    @Test
    public void test_select_volume_and_value_from_grower_sucess_affiliate_detail() {
        // Load database
        setupDBUnit();

        // Set filter
        PaidVolumeFilter filter = new PaidVolumeFilter();
        filter.setCrop((Crop) getSession().get(Crop.class, 900001111L));
        filter.setCompany((Company) getSession().get(Company.class, 900001111L));
        filter.setInitDate(CalendarUtil.getDate(1500, 1, 1));
        filter.setEndDate(CalendarUtil.getDate(2500, 1, 1));

        // Load matrix
        filter.setMatrix((Customer) getSession().get(Customer.class, 900050002L));
        Assert.assertNotNull(filter.getMatrix());

        // Load Affiliate
        filter.setCustomer((Customer) getSession().get(Customer.class, 900050002L));

        // Load technologies
        Technology tech = (Technology) getSession().get(Technology.class, 900003001L);
        filter.getTechnologies().add(tech);

        VolumeAndValueDTO dto = reportOnLineByGrowerService.sumVolumeAndValueFromPaidVolumeByGrowerByFilter(filter);

        Assert.assertNotNull(dto.getVolume());
        Assert.assertNotNull(dto.getValue());

        // Check consistency...
        @SuppressWarnings("unchecked")
        List<PaidVolByGrowerItem> list = getSession().createCriteria(PaidVolByGrowerItem.class, "pi")
                .createAlias("pi.paidVolumeByGrower", "pvg").createAlias("pvg.headoffice", "h")
                .add(Restrictions.eq("h.crop", filter.getCrop()))
                .add(Restrictions.eq("h.company", filter.getCompany()))
                .add(Restrictions.eq("h.matrix", filter.getMatrix()))
                .add(Restrictions.eq("h.customer", filter.getMatrix())).add(Restrictions.eq("pi.technology", tech))
                .add(Restrictions.ge("pvg.period", CalendarUtil.getFirstDateOfMonth(filter.getInitDate())))
                .add(Restrictions.le("pvg.period", CalendarUtil.getLastDateOfMonth(filter.getEndDate()))).list();

        BigDecimal totalVolume = new BigDecimal(0);
        BigDecimal totalValue = new BigDecimal(0);
        for (PaidVolByGrowerItem item : list) {
            totalVolume = totalVolume.add(item.getVolume());
            totalValue = totalValue.add(item.getRoyaltyValue());
        }

        Assert.assertTrue(dto.getVolume().equals(totalVolume));
        Assert.assertTrue(dto.getValue().equals(totalValue));

    }

    @Test
    public void search_paid_fixed_volume_grower_dto_by_filter() throws ReportOnlineByGrowerException, ParseException {
        setupDBUnit();

        Company company = (Company) getSession().get(Company.class, new Long(900001111)); // MONSANTO
        Crop crop = (Crop) getSession().get(Crop.class, new Long(900001111));// _SOJA_

        PaidVolumeFilter pvFilter = new PaidVolumeFilter();

        pvFilter.setCompany(company);
        pvFilter.setCrop(crop);

        // Must be in September, 2012 (any day, any time)
        Date utilDate = createDate("05/09/2012");

        pvFilter.setInitDate(CalendarUtil.getFirstDateOfMonth(utilDate));
        pvFilter.setEndDate(CalendarUtil.getLastDateOfMonth(utilDate));

        Technology technology1 = (Technology) getSession().get(Technology.class, new Long(900003001));
        Technology technology2 = (Technology) getSession().get(Technology.class, new Long(900002001));
        List<Technology> technologies = new ArrayList<Technology>();
        technologies.add(technology1);
        technologies.add(technology2);
        pvFilter.setTechnologies(technologies);

        // search for PaidVolumeByGrower list
        List<PaidVolumeByGrowerSearchDTO> pvByGrower = reportOnLineByGrowerService
                .selectPaidVolumeByGrowerListDTOByFilter(pvFilter);
        Assert.assertNotNull(!pvByGrower.isEmpty());
        Assert.assertTrue("Expected at least 2 itens. But found: " + pvByGrower.size(), pvByGrower.size() >= 2);

        for (PaidVolumeByGrowerSearchDTO item : pvByGrower) {

            if (item.getPaidVolByGrowerId() == new Long(999900011)) {
                Assert.assertEquals("Paid Volume By Grower id = 999900011 must be returned.", new Long(999900011),
                        item.getPaidVolByGrowerId());
            }
        }
    }

    @Test
    public void search_paid_fixed_volume_grower_dto_by_filter_with_technology_rr()
            throws ReportOnlineByGrowerException, ParseException {
        setupDBUnit();

        Company company = (Company) getSession().get(Company.class, new Long(900001111)); // MONSANTO
        Crop crop = (Crop) getSession().get(Crop.class, new Long(900001111));// _SOJA_

        PaidVolumeFilter pvFilter = new PaidVolumeFilter();

        pvFilter.setCompany(company);
        pvFilter.setCrop(crop);

        // Must be in September, 2012 (any day, any time)
        Date utilDate = createDate("05/09/2012");

        pvFilter.setInitDate(CalendarUtil.getFirstDateOfMonth(utilDate));
        pvFilter.setEndDate(CalendarUtil.getLastDateOfMonth(utilDate));

        Technology technology = (Technology) getSession().get(Technology.class, new Long(900002001));
        List<Technology> technologies = new ArrayList<Technology>();
        technologies.add(technology);
        pvFilter.setTechnologies(technologies);

        // search for PaidVolumeByGrower list
        List<PaidVolumeByGrowerSearchDTO> pvByGrower = reportOnLineByGrowerService
                .selectPaidVolumeByGrowerListDTOByFilter(pvFilter);
        Assert.assertNotNull(!pvByGrower.isEmpty());
        Assert.assertTrue("Expected at least 2 itens. But found: " + pvByGrower.size(), pvByGrower.size() >= 2);

        for (PaidVolumeByGrowerSearchDTO item : pvByGrower) {

            if (item.getPaidVolByGrowerId() == new Long(999900011)) {
                Assert.assertEquals("Paid Volume By Grower id = 999900011 must be returned.", new Long(999900011),
                        item.getPaidVolByGrowerId());
            }
        }
    }

    @Test
    public void search_paid_fixed_volume_grower_dto_by_filter_with_technology_intacta()
            throws ReportOnlineByGrowerException, ParseException {
        setupDBUnit();

        Company company = (Company) getSession().get(Company.class, new Long(900001111)); // MONSANTO
        Crop crop = (Crop) getSession().get(Crop.class, new Long(900001111));// _SOJA_

        PaidVolumeFilter pvFilter = new PaidVolumeFilter();

        pvFilter.setCompany(company);
        pvFilter.setCrop(crop);

        // Must be in September, 2012 (any day, any time)
        Date utilDate = createDate("05/09/2012");

        pvFilter.setInitDate(CalendarUtil.getFirstDateOfMonth(utilDate));
        pvFilter.setEndDate(CalendarUtil.getLastDateOfMonth(utilDate));

        Technology technology = (Technology) getSession().get(Technology.class, new Long(900003001));
        List<Technology> technologies = new ArrayList<Technology>();
        technologies.add(technology);
        pvFilter.setTechnologies(technologies);

        // search for PaidVolumeByGrower list
        List<PaidVolumeByGrowerSearchDTO> pvByGrower = reportOnLineByGrowerService
                .selectPaidVolumeByGrowerListDTOByFilter(pvFilter);
        Assert.assertNotNull(!pvByGrower.isEmpty());
        Assert.assertTrue("Expected at least 2 itens. But found: " + pvByGrower.size(), pvByGrower.size() >= 2);

        for (PaidVolumeByGrowerSearchDTO item : pvByGrower) {

            if (item.getPaidVolByGrowerId() == new Long(999900011)) {
                Assert.assertEquals("Paid Volume By Grower id = 999900011 must be returned.", new Long(999900011),
                        item.getPaidVolByGrowerId());
            }
        }
    }

}
