package com.monsanto.brazilvaluecapture.pod.credit.service.impl;

import java.math.BigDecimal;
import java.util.Date;

import junit.framework.Assert;

import org.junit.Before;
import org.junit.Test;

import com.monsanto.brazilvaluecapture.core.base.model.bean.CreditConsumptionStatus;
import com.monsanto.brazilvaluecapture.core.grower.CreateTestData;
import com.monsanto.brazilvaluecapture.pod.credit.report.CreditConsumptionReportDTO;

public class CreditConsumptionReportDTO_UT extends CreateTestData {

    @Before
    public void setup() {

    }

    @Test
    public void createObjectConstructorTest() {

        // Create system data
        CreditConsumptionReportDTO dto = new CreditConsumptionReportDTO();
        dto.setCompany("monsanto");
        dto.setCrop("soya");
        dto.setCostumerDocument("11111111111");
        dto.setCostumerName("Juca");
        dto.setCostumerSAPCode("111");
        dto.setCreateCreditConsumptionDate(new Date());
        dto.setCreditConsumptionItemId(1L);
        dto.setCreditConsumptionStatus(CreditConsumptionStatus.CORRECTED.toString());
        dto.setCreditConsumptionUser("teste");
        dto.setCustomerCity("Campinas");
        dto.setCustomerDistrict("district 1");
        dto.setCustomerState("State 1");
        dto.setCustomerRegion("region 1");
        dto.setCustomerUnit("Unity 1");
        dto.setGrowerCity("Campinas");
        dto.setGrowerDocument("2222222");
        dto.setGrowerName("Luis");
        dto.setGrowerState("State 1");
        dto.setMatrixContract("3333333");
        dto.setMatrixDistrict("district 2");
        dto.setMatrixDocument("22222222266");
        dto.setMatrixName("matrix 1");
        dto.setMatrixRegion("Region 2");
        dto.setMatrixSAPCode("1");
        dto.setMatrixUnit("Unity 3");
        dto.setOperationalYear("2012");
        dto.setOriginalCreditConsumptionItemId(1L);
        dto.setReturnDate(new Date());
        dto.setReturnUser("teste2");
        dto.setTechnology("Intact");
        dto.setVolume(new BigDecimal(2.0));

        testAssert(dto);

    }

    /**
     * Validating of grower
     * 
     * @param grower
     */
    void testAssert(CreditConsumptionReportDTO dto) {

        Assert.assertNotNull(dto);
        Assert.assertNotNull(dto.getCompany());
        Assert.assertNotNull(dto.getCostumerDocument());
        Assert.assertNotNull(dto.getCostumerName());
        Assert.assertNotNull(dto.getCostumerSAPCode());
        Assert.assertNotNull(dto.getCreditConsumptionStatus());
        Assert.assertNotNull(dto.getCreditConsumptionUser());
        Assert.assertNotNull(dto.getCrop());
        Assert.assertNotNull(dto.getCustomerCity());
        Assert.assertNotNull(dto.getCustomerDistrict());
        Assert.assertNotNull(dto.getCustomerRegion());
        Assert.assertNotNull(dto.getCustomerState());
        Assert.assertNotNull(dto.getCustomerUnit());
        Assert.assertNotNull(dto.getGrowerCity());
        Assert.assertNotNull(dto.getGrowerName());
        Assert.assertNotNull(dto.getGrowerDocument());
        Assert.assertNotNull(dto.getGrowerState());
        Assert.assertNotNull(dto.getMatrixContract());
        Assert.assertNotNull(dto.getMatrixDistrict());
        Assert.assertNotNull(dto.getMatrixDocument());
        Assert.assertNotNull(dto.getMatrixName());
        Assert.assertNotNull(dto.getMatrixRegion());
        Assert.assertNotNull(dto.getMatrixSAPCode());
        Assert.assertNotNull(dto.getMatrixUnit());
        Assert.assertNotNull(dto.getOperationalYear());
        Assert.assertNotNull(dto.getOriginalCreditConsumptionItemId());
        Assert.assertNotNull(dto.getReturnUser());
        Assert.assertNotNull(dto.getTechnology());
        Assert.assertNotNull(dto.getVolume());
    }

}
