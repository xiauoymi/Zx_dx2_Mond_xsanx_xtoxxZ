package com.monsanto.brazilvaluecapture.pod.rol.service.impl;

import java.util.HashSet;
import java.util.Set;

import org.junit.Assert;
import org.junit.Test;

import com.monsanto.brazilvaluecapture.core.customer.model.bean.HeadOffice;
import com.monsanto.brazilvaluecapture.pod.rol.model.bean.HeadOfficeDetail;
import com.monsanto.brazilvaluecapture.pod.rol.model.bean.HeadOfficeEffectiveDate;

/**
 * @author cmiranda
 * 
 */
public class HeadOfficeDetail_UT {

    /**
     * 
     */
    @Test
    public void test_change_report_rol_flag_from_true_to_true_without_effective_dates_expected_unchecked_billed_rol() {

        // create a head office detail
        HeadOfficeDetail headOfficeDetail = new HeadOfficeDetail(-1L, new HeadOffice(), Boolean.TRUE, Boolean.TRUE,
                new HashSet<HeadOfficeEffectiveDate>());

        // Test for if branch in get below (duplicate its ok! Cyclic branch)
        Assert.assertEquals(headOfficeDetail.getReportRol(), Boolean.TRUE);
        Assert.assertEquals(headOfficeDetail.getReportRol(), Boolean.TRUE);

        // Change flag to report to same value
        headOfficeDetail.setReportRol(Boolean.TRUE);

        Assert.assertFalse(headOfficeDetail.mustCheckForBilledRol());

    }

    /**
     * 
     */
    @Test
    public void test_change_report_rol_flag_from_true_to_true_with_effective_dates_expected_unchecked_billed_rol() {

        // build set of dates for affiliate
        Set<HeadOfficeEffectiveDate> effectives = new HashSet<HeadOfficeEffectiveDate>();
        effectives.add(new HeadOfficeEffectiveDate());

        // create a head office detail
        HeadOfficeDetail headOfficeDetail = new HeadOfficeDetail(-1L, new HeadOffice(), Boolean.TRUE, Boolean.TRUE,
                effectives);

        // Change flag to report to same value
        headOfficeDetail.setReportRol(Boolean.TRUE);

        Assert.assertFalse(headOfficeDetail.mustCheckForBilledRol());

    }

    /**
     * 
     */
    @Test
    public void test_change_report_rol_flag_from_false_to_false_with_effective_dates_expected_unchecked_billed_rol() {

        // build set of dates for affiliate
        Set<HeadOfficeEffectiveDate> effectives = new HashSet<HeadOfficeEffectiveDate>();
        effectives.add(new HeadOfficeEffectiveDate());

        // create a head office detail
        HeadOfficeDetail headOfficeDetail = new HeadOfficeDetail(-1L, new HeadOffice(), Boolean.FALSE, Boolean.FALSE,
                effectives);

        // Change flag to report to same value
        headOfficeDetail.setReportRol(Boolean.FALSE);

        Assert.assertFalse(headOfficeDetail.mustCheckForBilledRol());

    }

    /**
     * 
     */
    @Test
    public void test_change_report_rol_flag_from_true_to_false_with_effective_dates_expected_unchecked_billed_rol() {

        // build set of dates for affiliate
        Set<HeadOfficeEffectiveDate> effectives = new HashSet<HeadOfficeEffectiveDate>();
        effectives.add(new HeadOfficeEffectiveDate());

        // create a head office detail
        HeadOfficeDetail headOfficeDetail = new HeadOfficeDetail(-1L, new HeadOffice(), Boolean.TRUE, Boolean.TRUE,
                effectives);

        // Change flag to report to same value
        headOfficeDetail.setReportRol(Boolean.FALSE);

        Assert.assertFalse(headOfficeDetail.mustCheckForBilledRol());

    }

    /**
     * 
     */
    @Test
    public void test_change_report_rol_flag_from_false_to_true_with_effective_dates_expected_unchecked_billed_rol() {

        // build set of dates for affiliate
        Set<HeadOfficeEffectiveDate> effectives = new HashSet<HeadOfficeEffectiveDate>();
        effectives.add(new HeadOfficeEffectiveDate());

        // create a head office detail
        HeadOfficeDetail headOfficeDetail = new HeadOfficeDetail(-1L, new HeadOffice(), Boolean.FALSE, Boolean.FALSE,
                effectives);

        // Change flag to report to same value
        headOfficeDetail.setReportRol(Boolean.TRUE);

        Assert.assertTrue(headOfficeDetail.mustCheckForBilledRol());

    }

    /**
     * 
     */
    @Test
    public void test_change_report_rol_flag_from_false_to_true_from_true_to_false_with_effective_dates_expected_unchecked_billed_rol() {

        // build set of dates for affiliate
        Set<HeadOfficeEffectiveDate> effectives = new HashSet<HeadOfficeEffectiveDate>();
        effectives.add(new HeadOfficeEffectiveDate());

        // create a head office detail
        HeadOfficeDetail headOfficeDetail = new HeadOfficeDetail(-1L, new HeadOffice(), Boolean.FALSE, Boolean.FALSE,
                effectives);

        // Change flag to report to same value
        headOfficeDetail.setReportRol(Boolean.TRUE);

        // Change it again to false
        headOfficeDetail.setReportRol(Boolean.FALSE);

        Assert.assertFalse(headOfficeDetail.mustCheckForBilledRol());

    }

    /**
     * 
     */
    @Test
    public void test_change_report_rol_flag_from_false_to_true_from_true_to_false_and_to_true_with_effective_dates_expected_unchecked_billed_rol() {

        // build set of dates for affiliate
        Set<HeadOfficeEffectiveDate> effectives = new HashSet<HeadOfficeEffectiveDate>();
        effectives.add(new HeadOfficeEffectiveDate());

        // create a head office detail
        HeadOfficeDetail headOfficeDetail = new HeadOfficeDetail(-1L, new HeadOffice(), Boolean.FALSE, Boolean.FALSE,
                effectives);

        // Change flag to report to same value
        headOfficeDetail.setReportRol(Boolean.TRUE);

        // Change it again to false
        headOfficeDetail.setReportRol(Boolean.FALSE);

        // Change it again to true
        headOfficeDetail.setReportRol(Boolean.TRUE);

        Assert.assertTrue(headOfficeDetail.mustCheckForBilledRol());

    }

    /**
     * 
     */
    @Test
    public void test_change_report_rol_flag_from_true_to_false_from_false_to_true_with_effective_dates_expected_unchecked_billed_rol() {

        // build set of dates for affiliate
        Set<HeadOfficeEffectiveDate> effectives = new HashSet<HeadOfficeEffectiveDate>();
        effectives.add(new HeadOfficeEffectiveDate());

        // create a head office detail
        HeadOfficeDetail headOfficeDetail = new HeadOfficeDetail(-1L, new HeadOffice(), Boolean.TRUE, Boolean.TRUE,
                effectives);

        // Change flag to report to same value
        headOfficeDetail.setReportRol(Boolean.FALSE);

        // Change it again to true
        headOfficeDetail.setReportRol(Boolean.TRUE);

        Assert.assertFalse(headOfficeDetail.mustCheckForBilledRol());

    }

    /**
     * 
     */
    @Test
    public void test_change_report_rol_flag_from_false_to_true_without_effective_dates_expected_unchecked_billed_rol() {

        // build set of dates for affiliate
        Set<HeadOfficeEffectiveDate> effectives = new HashSet<HeadOfficeEffectiveDate>();

        // create a head office detail
        HeadOfficeDetail headOfficeDetail = new HeadOfficeDetail(-1L, new HeadOffice(), Boolean.FALSE, Boolean.FALSE,
                effectives);

        // Change flag to report to same value
        headOfficeDetail.setReportRol(Boolean.TRUE);

        Assert.assertFalse(headOfficeDetail.mustCheckForBilledRol());

    }
}
