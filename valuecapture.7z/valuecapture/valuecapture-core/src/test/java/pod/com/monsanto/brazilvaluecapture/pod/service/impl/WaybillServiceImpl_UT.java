package com.monsanto.brazilvaluecapture.pod.service.impl;

import com.monsanto.brazilvaluecapture.core.base.model.bean.Country;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Crop;
import com.monsanto.brazilvaluecapture.core.base.model.bean.OperationalYear;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Customer;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Technology;
import com.monsanto.brazilvaluecapture.core.grower.model.bean.Grower;
import com.monsanto.brazilvaluecapture.pod.model.bean.Waybill;
import com.monsanto.brazilvaluecapture.pod.model.dao.WaybillDAO;
import com.monsanto.brazilvaluecapture.pod.model.dao.WaybillFilter;
import com.monsanto.brazilvaluecapture.pod.service.WaybillService;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;

import java.util.*;

import static org.fest.assertions.Assertions.assertThat;
import static org.fest.reflect.core.Reflection.field;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.*;

/**
 * Created with IntelliJ IDEA.
 * User: AVIER
 * Date: 10/22/13
 * Time: 4:42 PM
 */
public class WaybillServiceImpl_UT {

    private WaybillService waybillService;
    private WaybillDAO waybillDAO;

    @Before
    public void setup() {
        waybillService = new WaybillServiceImpl();
        waybillDAO= mock(WaybillDAO.class);
        field("waybillDAO").ofType(WaybillDAO.class).in(this.waybillService).set(this.waybillDAO);
    }

    @Test
    public void givenWaybillService_WhenFindWaybillsThenGetAList() {
        // @Given a waybill service
        Long waybill = 351531L;
        Long ctg = 558456L;
        OperationalYear operationalYear = new OperationalYear();
        Crop crop = new Crop();
        Grower grower = new Grower();
        Customer headOffice = new Customer();
        Technology technology = new Technology();
        Date start = new Date();
        Date end = new Date();
        List<Waybill> waybills;
        Country country = new Country();

        // @When find by used with all the parameters
        when(waybillDAO.findBy(any(WaybillFilter.class))).thenReturn(Collections.<Waybill>emptyList());
        waybills = waybillService.findBy(waybill, ctg, operationalYear, crop, grower, headOffice, technology, country, start, end);

        // @Then return a result
        assertThat(waybills).isNotNull();
    }

    @Test
    public void givenWaybillService_WhenFindWithMoreThanOneParameterThenLoadTheFilterWithAllTheValues() {
        // @Given a service
        Long waybill = 351531L;
        Long ctg = 558456L;
        OperationalYear operationalYear = new OperationalYear();
        Crop crop = new Crop();
        Grower grower = new Grower();
        Customer headOffice = new Customer();
        Technology technology = new Technology();
        Date start = new Date();
        Date end = new Date();
        List<Waybill> waybills;
        Country country = new Country();

        // @When use more than argument
        ArgumentCaptor<WaybillFilter> filterArgumentCaptor = ArgumentCaptor.forClass(WaybillFilter.class);
        when(waybillDAO.findBy(any(WaybillFilter.class))).thenReturn(Collections.<Waybill>emptyList());

        // @Then the service set all the parameter set
        waybillService.findBy(waybill, ctg, operationalYear, crop, grower, headOffice, technology, country, start, end);
        verify(waybillDAO).findBy(filterArgumentCaptor.capture());

        WaybillFilter waybillFilter = filterArgumentCaptor.getValue();
        assertThat(waybillFilter.getWaybill()).isEqualTo(waybill);
        assertThat(waybillFilter.getCtg()).isEqualTo(ctg);
        assertThat(waybillFilter.getOperationalYear()).isEqualTo(operationalYear);
        assertThat(waybillFilter.getCrop()).isEqualTo(crop);
        assertThat(waybillFilter.getCountry()).isEqualTo(country);
        assertThat(waybillFilter.getGrower()).isEqualTo(grower);
        assertThat(waybillFilter.getHeadOffice()).isEqualTo(headOffice);
        assertThat(waybillFilter.getTechnology()).isEqualTo(technology);
        assertThat(waybillFilter.getEnd()).isEqualTo(end);
        assertThat(waybillFilter.getStart()).isEqualTo(start);
    }

    @Test
    public void givenWaybillService_WhenFindByWaybillIdCallDaoWithTheWaybillId() {
        // @Given a waybill service
        Long waybillId = 234234L;

        // @When find by id
        ArgumentCaptor<Long> longArgumentCaptor = ArgumentCaptor.forClass(Long.class);
        when(waybillDAO.findBy(waybillId)).thenReturn(new Waybill());
        Waybill waybill = waybillService.findBy(waybillId);

        // @Then return a waybill id is set in the dao
        verify(waybillDAO).findBy(longArgumentCaptor.capture());
        assertThat(longArgumentCaptor.getValue()).isEqualTo(waybillId);
    }

}