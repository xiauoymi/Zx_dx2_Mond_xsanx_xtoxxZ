package com.monsanto.brazilvaluecapture.pod.credit.report;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.ResourceBundle;

import org.junit.Assert;
import org.junit.Test;

import com.monsanto.brazilvaluecapture.core.customer.service.ContractNotFoundException;
import com.monsanto.brazilvaluecapture.core.foundation.service.EntityAlreadyExistException;
import com.monsanto.brazilvaluecapture.core.foundation.test.AbstractServiceIntegrationTests;
import com.monsanto.brazilvaluecapture.core.foundation.util.report.ReportUtilAssert;
import com.monsanto.brazilvaluecapture.pod.rol.model.bean.MissingReportOnlineView;

public class MissingReportAssembler_AT extends AbstractServiceIntegrationTests {
    
    private ResourceBundle resourceBundle = ResourceBundle.getBundle("bundle/bundle");

    @Test
    public void header_test() throws IOException, NoSuchMethodException, ContractNotFoundException, EntityAlreadyExistException {
        MissingReportAssembler reportAssembler = new MissingReportAssembler(new ArrayList<MissingReportOnlineView>());
        ByteArrayOutputStream baos = reportAssembler.build(resourceBundle);
        Assert.assertNotNull(baos);

        validateHeader(baos);
    }
    
    private void validateHeader(ByteArrayOutputStream outputStream) throws IOException {
        ReportUtilAssert.assertEqualsCell(outputStream, 0, 0, 0, resourceBundle.getString("pod.report.missing.company.label"));
        ReportUtilAssert.assertEqualsCell(outputStream, 0, 0, 1, resourceBundle.getString( "pod.report.missing.crop.label"));
        ReportUtilAssert.assertEqualsCell(outputStream, 0, 0, 2, resourceBundle.getString( "pod.report.missing.missingperiod.label"));
        ReportUtilAssert.assertEqualsCell(outputStream, 0, 0, 3, resourceBundle.getString( "pod.report.missing.costumersapcode.label"));
        ReportUtilAssert.assertEqualsCell(outputStream, 0, 0, 4, resourceBundle.getString( "pod.report.missing.costumername.label"));
        ReportUtilAssert.assertEqualsCell(outputStream, 0, 0, 5, resourceBundle.getString( "pod.report.missing.customerdocument.label"));
        ReportUtilAssert.assertEqualsCell(outputStream, 0, 0, 6, resourceBundle.getString( "pod.report.missing.customercity.label"));
        ReportUtilAssert.assertEqualsCell(outputStream, 0, 0, 7, resourceBundle.getString( "pod.report.missing.customerstate.label"));
        ReportUtilAssert.assertEqualsCell(outputStream, 0, 0, 8, resourceBundle.getString( "pod.report.missing.customerunit.label"));
        ReportUtilAssert.assertEqualsCell(outputStream, 0, 0, 9, resourceBundle.getString( "pod.report.missing.customerregion.label"));
        ReportUtilAssert.assertEqualsCell(outputStream, 0, 0, 10, resourceBundle.getString( "pod.report.missing.customerdistrict.label"));
        ReportUtilAssert.assertEqualsCell(outputStream, 0, 0, 11, resourceBundle.getString( "pod.report.missing.matrixsapcode.label"));
        ReportUtilAssert.assertEqualsCell(outputStream, 0, 0, 12, resourceBundle.getString( "pod.report.missing.matrixdocument.label"));
        ReportUtilAssert.assertEqualsCell(outputStream, 0, 0, 13, resourceBundle.getString( "pod.report.missing.matrixname.label"));
        ReportUtilAssert.assertEqualsCell(outputStream, 0, 0, 14, resourceBundle.getString( "pod.report.missing.matrixunit.label"));
        ReportUtilAssert.assertEqualsCell(outputStream, 0, 0, 15, resourceBundle.getString( "pod.report.missing.matrixregion.label"));
        ReportUtilAssert.assertEqualsCell(outputStream, 0, 0, 16, resourceBundle.getString( "pod.report.missing.matrixdistrict.label"));
        ReportUtilAssert.assertEqualsCell(outputStream, 0, 0, 17, resourceBundle.getString( "pod.report.missing.matrixcontract.label"));
        
    }
}
