package com.monsanto.brazilvaluecapture.pod.rol.model.service.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;

import junit.framework.Assert;

import org.hibernate.criterion.Restrictions;
import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.monsanto.brazilvaluecapture.core.foundation.test.AbstractServiceIntegrationTests;
import com.monsanto.brazilvaluecapture.core.foundation.test.dbunit.DbUnitHelper;
import com.monsanto.brazilvaluecapture.core.importfile.model.bean.CsvImportFile;
import com.monsanto.brazilvaluecapture.pod.rol.model.bean.CsvPaidVolImportLine;
import com.monsanto.brazilvaluecapture.pod.rol.model.bean.CsvPaidVolImportResult;
import com.monsanto.brazilvaluecapture.pod.rol.model.service.PaidVolImportService;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.ImportFileStatus;

/**
 * Unity test for PodCalendarService
 * 
 */
public class PaidVolImportService_AT extends AbstractServiceIntegrationTests {

    @Autowired
    private PaidVolImportService paidVolImportService;

    @Before
    public void setupDBUnit() {

        // Load dbunit
        DbUnitHelper.setup("classpath:data/core/fixture-system-dataset.xml",
                "classpath:data/core/participant-dataset.xml");
    }

    @SuppressWarnings("unchecked")
    @Test
    public void test_save_file_and_lines() {

        // Create file entity
        CsvImportFile file = saveFile();

        // Find for file
        CsvImportFile sFile = (CsvImportFile) getSession().get(CsvImportFile.class, file.getId());
        Assert.assertNotNull(sFile);

        // Find for lines from file
        List<CsvPaidVolImportLine> sLines = getSession().createCriteria(CsvPaidVolImportLine.class)
                .add(Restrictions.eq("csvImportFile", sFile)).list();
        Assert.assertNotNull(sLines);
        Assert.assertEquals(1, sLines.size());

    }

    @SuppressWarnings("unchecked")
    @Test
    public void test_cancel_import_file() {

        // Create file entity
        CsvImportFile file = saveFile();

        // Find for lines from file
        List<CsvPaidVolImportLine> sLines = getSession().createCriteria(CsvPaidVolImportLine.class)
                .add(Restrictions.eq("csvImportFile", file)).list();
        Assert.assertNotNull(sLines);
        Assert.assertEquals(1, sLines.size());

        // Delete all lines
        paidVolImportService.cancelImportFile(file);

        sLines = getSession().createCriteria(CsvPaidVolImportLine.class).add(Restrictions.eq("csvImportFile", file))
                .list();
        Assert.assertTrue(sLines.isEmpty());

    }

    @SuppressWarnings("unchecked")
    @Test
    public void test_select_csv_import_lines_by_file() {

        // Create file entity
        CsvImportFile file = saveFile();

        // Find for lines from file
        List<CsvPaidVolImportLine> sLines = getSession().createCriteria(CsvPaidVolImportLine.class)
                .add(Restrictions.eq("csvImportFile", file)).list();
        Assert.assertNotNull(sLines);
        Assert.assertEquals(1, sLines.size());

        // Verify if found same line number
        List<CsvPaidVolImportLine> lines = paidVolImportService.selectCsvImportLinesByFile(file);
        Assert.assertNotNull(lines);
        Assert.assertEquals(1, lines.size());

    }

    @SuppressWarnings("unchecked")
    @Test
    public void test_select_csv_import_result_by_file() {

        // Create file entity
        CsvImportFile file = saveFile();

        // Find for lines from file
        List<CsvPaidVolImportLine> sLines = getSession().createCriteria(CsvPaidVolImportLine.class)
                .add(Restrictions.eq("csvImportFile", file)).list();
        Assert.assertNotNull(sLines);
        Assert.assertEquals(1, sLines.size());

        // Verify if found same line number
        List<CsvPaidVolImportResult> results = paidVolImportService.selectCsvImportResultByFile(file);
        Assert.assertNotNull(results);
        Assert.assertEquals(0, results.size());

    }

    private CsvImportFile saveFile() {

        // Create line list
        Collection<CsvPaidVolImportLine> lines = new ArrayList<CsvPaidVolImportLine>();

        // Create file
        CsvImportFile file = new CsvImportFile();
        file.setCreationDate(new Date());
        file.setFileName("x.txt");
        file.setFileStatus(ImportFileStatus.AWAITING_CANCELLING);
        file.setLastUpdate(new Date());
        file.setTotalDuplicated(0L);
        file.setTotalEntities(1L);
        file.setTotalError(0L);
        file.setTotalSuccess(1L);
        file.setTotalWarning(0L);
        file.setUserLogin("jose");
        file.setValidFile(Boolean.TRUE);

        // Create line 1
        CsvPaidVolImportLine line1 = new CsvPaidVolImportLine();
        line1.setActualPositionColumnSize(1);
        line1.setCompanyId(900000001L);
        line1.setCropId(900000001L);
        line1.setCsvImportFile(file);
        line1.setCustomerDocument("111111111");
        line1.setCustomerDocumentType("CPF");
        line1.setDateReceive(new Date());
        line1.setDuplicated(false);
        line1.setGrowerDocument("xxxx");
        line1.setHeadofficeId(900000001L);
        line1.setLine(1);
        line1.setMaxPositionColumnSize(2);
        line1.setPeriod(new Date());
        line1.setPositionColumn(1);
        line1.setPositionColumnDisplayName("column1");
        line1.setRoyaltyValue(BigDecimal.ONE);
        line1.setTechnology("RR");
        line1.setVolume(BigDecimal.ONE);
        line1.setWarn("warn!");
        lines.add(line1);

        // Save data
        paidVolImportService.saveFileAndLines(file, lines);
        return file;
    }
}
