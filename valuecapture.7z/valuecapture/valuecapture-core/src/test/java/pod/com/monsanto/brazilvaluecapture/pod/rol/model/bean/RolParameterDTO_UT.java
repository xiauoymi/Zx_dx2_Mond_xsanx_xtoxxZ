package com.monsanto.brazilvaluecapture.pod.rol.model.bean;

import java.math.BigDecimal;

import junit.framework.Assert;

import org.junit.Test;

import com.monsanto.brazilvaluecapture.core.base.model.bean.OperationalYear;

/**
 * @author cmiranda
 * 
 */
public class RolParameterDTO_UT {

    @Test
    public void test_used_rol_param_average_val() {

        UsedRolParameter usedRolParameter = new UsedRolParameter();

        RolParameterDTO dto = new RolParameterDTO(usedRolParameter);

        dto.setUsedRolParamAverageVal(BigDecimal.ONE);
        Assert.assertEquals(BigDecimal.ONE, dto.getUsedRolParamAverageVal());

    }

    @Test
    public void test_get_rol_param_charge_hopper_pct() {

        UsedRolParameter usedRolParameter = new UsedRolParameter();
        usedRolParameter.setRolParameter(new RolParameter());
        usedRolParameter.getRolParameter().setRolParChrgRoyHopperPct(BigDecimal.ONE);

        RolParameterDTO dto = new RolParameterDTO(usedRolParameter);

        Assert.assertEquals(BigDecimal.ONE, dto.getRolParChrgRoyHopperPct());

    }

    @Test
    public void test_get_style_class_non_test_parameter() {

        UsedRolParameter usedRolParameter = new UsedRolParameter();
        usedRolParameter.setRolParameter(new RolParameter());
        usedRolParameter.getRolParameter().setRolFrameGroup(new RolFrameGroup());
        usedRolParameter.getRolParameter().getRolFrameGroup().setRolFrameGroupCode(RolFrameGroup.FRAME_GROUP_RECEIVED);

        usedRolParameter.setReportOnLine(new ReportOnLine());
        usedRolParameter.getReportOnLine().setRolStatus(new RolStatus());
        usedRolParameter.getReportOnLine().getRolStatus().setRolStatusCode(RolStatus.ROL_STATUS_CORRECTED);

        RolParameterDTO dto = new RolParameterDTO(usedRolParameter);

        Assert.assertEquals("", dto.getStyleClass());

    }

    @Test
    public void test_get_style_class_test_parameter_subtract() {

        UsedRolParameter usedRolParameter = new UsedRolParameter();
        usedRolParameter.setRolParameter(new RolParameter());

        usedRolParameter.getRolParameter().setRolFrameGroup(new RolFrameGroup());
        usedRolParameter.getRolParameter().getRolFrameGroup()
                .setRolFrameGroupCode(RolFrameGroup.FRAME_GROUP_TESTSTRYPE);

        usedRolParameter.getRolParameter().setGroupAction(new GroupAction());
        usedRolParameter.getRolParameter().getGroupAction().setGroupActionCode(GroupAction.GROUP_ACTION_SUBTRACT);

        usedRolParameter.setReportOnLine(new ReportOnLine());
        usedRolParameter.getReportOnLine().setRolStatus(new RolStatus());
        usedRolParameter.getReportOnLine().getRolStatus().setRolStatusCode(RolStatus.ROL_STATUS_CORRECTED);

        RolParameterDTO dto = new RolParameterDTO(usedRolParameter);

        Assert.assertEquals("rol_subtract_class", dto.getStyleClass());

    }

    @Test
    public void test_get_style_class_test_parameter_sum() {

        UsedRolParameter usedRolParameter = new UsedRolParameter();
        usedRolParameter.setRolParameter(new RolParameter());

        usedRolParameter.getRolParameter().setRolFrameGroup(new RolFrameGroup());
        usedRolParameter.getRolParameter().getRolFrameGroup()
                .setRolFrameGroupCode(RolFrameGroup.FRAME_GROUP_TESTSTRYPE);

        usedRolParameter.getRolParameter().setGroupAction(new GroupAction());
        usedRolParameter.getRolParameter().getGroupAction().setGroupActionCode(GroupAction.GROUP_ACTION_SUM);

        usedRolParameter.setReportOnLine(new ReportOnLine());
        usedRolParameter.getReportOnLine().setRolStatus(new RolStatus());
        usedRolParameter.getReportOnLine().getRolStatus().setRolStatusCode(RolStatus.ROL_STATUS_CORRECTED);

        RolParameterDTO dto = new RolParameterDTO(usedRolParameter);

        Assert.assertEquals("rol_sum_class", dto.getStyleClass());

    }

    @Test
    public void test_get_style_class_test_parameter_calculate() {

        UsedRolParameter usedRolParameter = new UsedRolParameter();
        usedRolParameter.setRolParameter(new RolParameter());

        usedRolParameter.getRolParameter().setRolFrameGroup(new RolFrameGroup());
        usedRolParameter.getRolParameter().getRolFrameGroup()
                .setRolFrameGroupCode(RolFrameGroup.FRAME_GROUP_TESTSTRYPE);

        usedRolParameter.getRolParameter().setGroupAction(new GroupAction());
        usedRolParameter.getRolParameter().getGroupAction().setGroupActionCode(GroupAction.GROUP_ACTION_CALCULATE);

        usedRolParameter.setReportOnLine(new ReportOnLine());
        usedRolParameter.getReportOnLine().setRolStatus(new RolStatus());
        usedRolParameter.getReportOnLine().getRolStatus().setRolStatusCode(RolStatus.ROL_STATUS_CORRECTED);

        RolParameterDTO dto = new RolParameterDTO(usedRolParameter);

        Assert.assertEquals("rol_calculate_class", dto.getStyleClass());

    }

    @Test
    public void test_get_style_class_test_parameter_no_action() {

        UsedRolParameter usedRolParameter = new UsedRolParameter();
        usedRolParameter.setRolParameter(new RolParameter());

        usedRolParameter.getRolParameter().setRolFrameGroup(new RolFrameGroup());
        usedRolParameter.getRolParameter().getRolFrameGroup()
                .setRolFrameGroupCode(RolFrameGroup.FRAME_GROUP_TESTSTRYPE);

        usedRolParameter.getRolParameter().setGroupAction(new GroupAction());
        usedRolParameter.getRolParameter().getGroupAction().setGroupActionCode(GroupAction.GROUP_ACTION_NOACTION);

        usedRolParameter.setReportOnLine(new ReportOnLine());
        usedRolParameter.getReportOnLine().setRolStatus(new RolStatus());
        usedRolParameter.getReportOnLine().getRolStatus().setRolStatusCode(RolStatus.ROL_STATUS_CORRECTED);

        RolParameterDTO dto = new RolParameterDTO(usedRolParameter);

        Assert.assertEquals("", dto.getStyleClass());

    }

    @Test
    public void test_get_style_class_billed_rol() {

        UsedRolParameter usedRolParameter = new UsedRolParameter();
        usedRolParameter.setRolParameter(new RolParameter());

        usedRolParameter.getRolParameter().setRolFrameGroup(new RolFrameGroup());
        usedRolParameter.getRolParameter().getRolFrameGroup()
                .setRolFrameGroupCode(RolFrameGroup.FRAME_GROUP_TESTSTRYPE);

        usedRolParameter.getRolParameter().setGroupAction(new GroupAction());
        usedRolParameter.getRolParameter().getGroupAction().setGroupActionCode(GroupAction.GROUP_ACTION_NOACTION);

        usedRolParameter.setReportOnLine(new ReportOnLine());
        usedRolParameter.getReportOnLine().setRolStatus(new RolStatus());
        usedRolParameter.getReportOnLine().getRolStatus().setRolStatusCode(RolStatus.ROL_STATUS_PROCESSED);

        RolParameterDTO dto = new RolParameterDTO(usedRolParameter);

        Assert.assertEquals("rol_billed_without_sap_id", dto.getStyleClass());

    }

    @Test
    public void test_get_style_class_billed_rol_sum_action_for_test_strip_parameter() {

        UsedRolParameter usedRolParameter = new UsedRolParameter();
        usedRolParameter.setRolParameter(new RolParameter());

        usedRolParameter.getRolParameter().setRolFrameGroup(new RolFrameGroup());
        usedRolParameter.getRolParameter().getRolFrameGroup()
                .setRolFrameGroupCode(RolFrameGroup.FRAME_GROUP_TESTSTRYPE);

        usedRolParameter.getRolParameter().setGroupAction(new GroupAction());
        usedRolParameter.getRolParameter().getGroupAction().setGroupActionCode(GroupAction.GROUP_ACTION_SUM);

        usedRolParameter.setReportOnLine(new ReportOnLine());
        usedRolParameter.getReportOnLine().setRolStatus(new RolStatus());
        usedRolParameter.getReportOnLine().getRolStatus().setRolStatusCode(RolStatus.ROL_STATUS_PROCESSED);

        RolParameterDTO dto = new RolParameterDTO(usedRolParameter);

        Assert.assertEquals("rol_sum_class rol_billed_without_sap_id", dto.getStyleClass());

    }

    @Test
    public void test_get_ton_monetary_required_field_style_class_param_without_flag() {

        UsedRolParameter usedRolParameter = new UsedRolParameter();
        usedRolParameter.setRolParameter(new RolParameter());

        usedRolParameter.getRolParameter().setRolFrameGroup(new RolFrameGroup());
        usedRolParameter.getRolParameter().getRolFrameGroup()
                .setRolFrameGroupCode(RolFrameGroup.FRAME_GROUP_TESTSTRYPE);

        usedRolParameter.getRolParameter().setGroupAction(new GroupAction());
        usedRolParameter.getRolParameter().getGroupAction().setGroupActionCode(GroupAction.GROUP_ACTION_SUM);

        RolParameterDTO dto = new RolParameterDTO(usedRolParameter);

        Assert.assertEquals("", dto.getTonMonetaryRequiredFieldStyleClass());

    }

    @Test
    public void test_get_ton_monetary_required_field_style_class_param_with_flag() {

        UsedRolParameter usedRolParameter = new UsedRolParameter();
        usedRolParameter.setRolParameter(new RolParameter());

        usedRolParameter.getRolParameter().setRolParTransChrgRoyHopper(Boolean.TRUE);
        usedRolParameter.getRolParameter().setRolFrameGroup(new RolFrameGroup());
        usedRolParameter.getRolParameter().getRolFrameGroup()
                .setRolFrameGroupCode(RolFrameGroup.FRAME_GROUP_TESTSTRYPE);

        usedRolParameter.getRolParameter().setGroupAction(new GroupAction());
        usedRolParameter.getRolParameter().getGroupAction().setGroupActionCode(GroupAction.GROUP_ACTION_SUM);

        RolParameterDTO dto = new RolParameterDTO(usedRolParameter);

        Assert.assertEquals("requiredField", dto.getTonMonetaryRequiredFieldStyleClass());

    }

    @Test
    public void test_values_variations() {

        UsedRolParameter usedRolParameter = new UsedRolParameter();
        usedRolParameter.setRolParameter(new RolParameter());

        usedRolParameter.getRolParameter().setRolParTransChrgRoyHopper(Boolean.TRUE);
        usedRolParameter.getRolParameter().setRolFrameGroup(new RolFrameGroup());
        usedRolParameter.getRolParameter().getRolFrameGroup()
                .setRolFrameGroupCode(RolFrameGroup.FRAME_GROUP_TESTSTRYPE);

        usedRolParameter.getRolParameter().setGroupAction(new GroupAction());
        usedRolParameter.getRolParameter().getGroupAction().setGroupActionCode(GroupAction.GROUP_ACTION_SUM);
        usedRolParameter.setCounterPrice(BigDecimal.ONE);

        RolParameterDTO dto = new RolParameterDTO(usedRolParameter);
        Assert.assertNotNull(dto.getMaximumVariation());
        Assert.assertNotNull(dto.getMaximumVariationMoneyVal());
        Assert.assertNotNull(dto.getExceededVariation());
        Assert.assertNotNull(dto.getRolFrameGroupCode());
        Assert.assertNotNull(dto.getCounterPrice());
        Assert.assertNotNull(dto.getCounterPriceMoneyVal());
        Assert.assertNotNull(dto.getMaximumVariationMoneyValue());

    }

    @Test
    public void test_calculate_operational_year() {

        UsedRolParameter usedRolParameter = new UsedRolParameter();
        usedRolParameter.setRolParameter(new RolParameter());

        usedRolParameter.getRolParameter().setRolParTransChrgRoyHopper(Boolean.TRUE);
        usedRolParameter.getRolParameter().setRolFrameGroup(new RolFrameGroup());
        usedRolParameter.getRolParameter().getRolFrameGroup()
                .setRolFrameGroupCode(RolFrameGroup.FRAME_GROUP_TESTSTRYPE);

        usedRolParameter.getRolParameter().setGroupAction(new GroupAction());
        usedRolParameter.getRolParameter().getGroupAction().setGroupActionCode(GroupAction.GROUP_ACTION_SUM);
        usedRolParameter.setCounterPrice(BigDecimal.ONE);

        usedRolParameter.getRolParameter().setOperationalYearType(new OperationalYearType());
        usedRolParameter.getRolParameter().getOperationalYearType().setOperationalYearTypeDiff(-1);

        usedRolParameter.setReportOnLine(new ReportOnLine());
        usedRolParameter.getReportOnLine().setOperationalYear(new OperationalYear("2010"));

        RolParameterDTO dto = new RolParameterDTO(usedRolParameter);
        dto.calculateOperationalYear();
        Assert.assertEquals("2009", dto.getOperationalYear());

    }

}
