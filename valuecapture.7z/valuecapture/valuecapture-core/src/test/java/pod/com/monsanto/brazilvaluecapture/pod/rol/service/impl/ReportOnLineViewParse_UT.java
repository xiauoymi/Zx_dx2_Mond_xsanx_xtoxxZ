package com.monsanto.brazilvaluecapture.pod.rol.service.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;

import junit.framework.Assert;

import org.junit.Test;

import com.monsanto.brazilvaluecapture.core.base.model.bean.Company;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Crop;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Document;
import com.monsanto.brazilvaluecapture.core.base.model.bean.DocumentType;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Contract;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Customer;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.ParticipantTypeEnum;
import com.monsanto.brazilvaluecapture.core.foundation.util.CalendarUtil;
import com.monsanto.brazilvaluecapture.core.revenue.model.bean.RevenueAccount;
import com.monsanto.brazilvaluecapture.core.user.model.bean.HierarchyLevel;
import com.monsanto.brazilvaluecapture.core.user.model.bean.UserContract;
import com.monsanto.brazilvaluecapture.pod.rol.model.bean.ReportOnLine;
import com.monsanto.brazilvaluecapture.pod.rol.model.bean.ReportOnLineView;
import com.monsanto.brazilvaluecapture.pod.rol.model.bean.ReportOnLineViewParser;
import com.monsanto.brazilvaluecapture.pod.rol.model.bean.RolJustification;
import com.monsanto.brazilvaluecapture.pod.rol.model.bean.RolJustificationType;
import com.monsanto.brazilvaluecapture.pod.rol.model.bean.UsedRolParameter;

/**
 * @author cmiranda
 * 
 */
public class ReportOnLineViewParse_UT {

    /**
     * @return
     */
    private ReportOnLineView createReportedRolView() {

        ReportOnLineView view = new ReportOnLineView();
        view.setAffiliateCity("cidade1");
        view.setAffiliateCityId(1L);
        view.setAffiliateCreditConsumption(BigDecimal.ONE);
        view.setAffiliateCustomerSapCode("1");
        view.setAffiliateDistrictSapDesc("d1");
        view.setAffiliateDistrictSapId("d1");
        view.setAffiliateDocument("1111");
        view.setAffiliateDocumentMask("9.999");
        view.setAffiliateDocumentType("CPF");
        view.setAffiliateId(1L);
        view.setAffiliateName("filial 1");
        view.setAffiliateOtherValues(BigDecimal.ONE);
        view.setAffiliateRegionSapDesc("r1");
        view.setAffiliateRegionSapId("r1");
        view.setAffiliateState("sp");
        view.setAffiliateStateId(1L);
        view.setAffiliateUnitySapDesc("u1");
        view.setAffiliateUnitySapId("u1");
        view.setBilledMonetaryValue(BigDecimal.ONE);
        view.setBilledTonValue(BigDecimal.ONE);
        view.setCompanyDescription("monsanto");
        view.setCompanyId(1L);
        view.setContractNumber("123888");
        view.setCounterPrice(BigDecimal.ONE);
        view.setCropDescription("soja");
        view.setCropId(1L);
        view.setMatrixDistrictSapDesc("x123");
        view.setMatrixDistrictSapDesc("d1");
        view.setMatrixDistrictSapId("d1");
        view.setMatrixDocument("456");
        view.setMatrixDocumentMask("999");
        view.setMatrixName("matrix 1");
        view.setMatrixRegionSapDesc("r1");
        view.setMatrixRegionSapId("r1");
        view.setMatrixUnitySapDesc("u1");
        view.setMatrixUnitySapId("u1");
        view.setMatrixSapCode("x1111");
        view.setMatrixId(1L);
        view.setMissingState(Boolean.FALSE);
        view.setRolItsUserLogin("mariazinha");
        view.setPeriod(CalendarUtil.getDate(2012, Calendar.JANUARY));
        
        return view;
    }

    /**
     * @param view
     * @param parameterName
     * @param rolParamAverageValue
     * @param rolParamMonetaryValue
     * @param rolParamStripeValue
     * @param rolParamTonValue
     * @return
     */
    private ReportOnLineView setUsedRolParameter(ReportOnLineView view, String parameterName,
            BigDecimal rolParamAverageValue, BigDecimal rolParamMonetaryValue, Long rolParamStripeValue,
            BigDecimal rolParamTonValue, Integer operationalYearTypeDiff) {

        view.setRolParamShowDescription(parameterName);
        view.setRolParamAverageValue(rolParamAverageValue);
        view.setRolParamMonetaryValue(rolParamMonetaryValue);
        view.setRolParamStripeValue(rolParamStripeValue);
        view.setRolParamTonValue(rolParamTonValue);
        view.setOperationalYearTypeDiff(operationalYearTypeDiff);

        return view;
    }

    /**
     * @param view
     * @param message
     * @param rolJustificationType
     * @param rolJustificationUserLogin
     * @return
     */
    private ReportOnLineView setRolJustificativa(ReportOnLineView view, String message, String rolJustificationType,
            String rolJustificationUserLogin, Date rolJustificationDate) {

        view.setRolJustificationDate(rolJustificationDate);
        view.setRolJustificationMessage(message);
        view.setRolJustificationType(rolJustificationType);
        view.setRolJustificationUserLogin(rolJustificationUserLogin);

        return view;
    }

    @Test
    public void test_group_report_onlines_by_rol_id_with_only_one_rol_and_two_parameters() {

        // Build list to be converted
        List<ReportOnLineView> reportView = new ArrayList<ReportOnLineView>();

        // Parameter 1 for rol 10
        ReportOnLineView l1 = setUsedRolParameter(createReportedRolView(), "P1", BigDecimal.ONE, BigDecimal.ONE, 1L,
                BigDecimal.ONE, -1);
        l1.setReportOnlineId(10L);
        reportView.add(l1);

        // Parameter 2 for rol 10
        ReportOnLineView l2 = setUsedRolParameter(createReportedRolView(), "P2", BigDecimal.TEN, BigDecimal.TEN, 10L,
                BigDecimal.TEN, 0);
        l2.setReportOnlineId(10L);
        reportView.add(l2);

        // Convert list
        Map<Long, List<ReportOnLineView>> groupMap = ReportOnLineViewParser.groupReportOnlinesByRolId(reportView);

        Assert.assertNotNull(groupMap);
        Assert.assertFalse("Expected a non-empty map.", groupMap.isEmpty());
        Assert.assertEquals("Expected only one item in converted map.", 1, groupMap.size());
        Assert.assertEquals("Expected exactly two itens in group 10.", 2, groupMap.get(10L).size());

    }

    @Test
    public void test_group_report_onlines_by_rol_id_list_with_only_one_rol_and_two_parameters_and_three_justifications() {

        // Build list to be converted
        List<ReportOnLineView> reportView = new ArrayList<ReportOnLineView>();

        // Parameter 1 for rol 10
        ReportOnLineView l1 = setUsedRolParameter(createReportedRolView(), "P1", BigDecimal.ONE, BigDecimal.ONE, 1L,
                BigDecimal.ONE, -1);
        l1.setReportOnlineId(10L);
        reportView.add(l1);

        // Parameter 2 for rol 10
        ReportOnLineView l2 = setUsedRolParameter(createReportedRolView(), "P2", BigDecimal.TEN, BigDecimal.TEN, 10L,
                BigDecimal.TEN, 0);
        l2.setReportOnlineId(10L);
        reportView.add(l2);

        // Parameter 2 for rol 10 justification 1
        ReportOnLineView l3 = setRolJustificativa(
                setUsedRolParameter(createReportedRolView(), "P2", BigDecimal.TEN, BigDecimal.TEN, 10L, BigDecimal.TEN,
                        0), "mimimimimimiimimm", RolJustificationType.APPROVAL.name(), "cmiranda", new Date());
        l3.setReportOnlineId(10L);
        reportView.add(l3);

        // Parameter 2 for rol 10 justification 2
        ReportOnLineView l4 = setRolJustificativa(
                setUsedRolParameter(createReportedRolView(), "P2", BigDecimal.TEN, BigDecimal.TEN, 10L, BigDecimal.TEN,
                        0), "NaO!", RolJustificationType.APPROVAL.name(), "cmiranda", new Date());
        l4.setReportOnlineId(10L);
        reportView.add(l4);

        // Parameter 2 for rol 10 justification 3
        ReportOnLineView l5 = setRolJustificativa(
                setUsedRolParameter(createReportedRolView(), "P2", BigDecimal.TEN, BigDecimal.TEN, 10L, BigDecimal.TEN,
                        0), "NaO!", RolJustificationType.APPROVAL.name(), "cmiranda", new Date());
        l5.setReportOnlineId(10L);
        reportView.add(l5);

        // Convert list
        Map<Long, List<ReportOnLineView>> groupList = ReportOnLineViewParser.groupReportOnlinesByRolId(reportView);

        Assert.assertNotNull(groupList);
        Assert.assertFalse("Expected a non-empty map.", groupList.isEmpty());
        Assert.assertEquals("Expected only one item in converted map.", 1, groupList.size());
        Assert.assertEquals("Expected exactly two itens in group 10.", 5, groupList.get(10L).size());

    }

    @Test
    public void test_group_report_onlines_by_rol_id_list_with_only_two_rol_and_two_parameters() {

        // Build list to be converted
        List<ReportOnLineView> reportView = new ArrayList<ReportOnLineView>();

        // Parameter 1 for rol 10
        ReportOnLineView l1 = setUsedRolParameter(createReportedRolView(), "P1", BigDecimal.ONE, BigDecimal.ONE, 1L,
                BigDecimal.ONE, -1);
        l1.setReportOnlineId(10L);
        reportView.add(l1);

        // Parameter 2 for rol 10
        ReportOnLineView l2 = setUsedRolParameter(createReportedRolView(), "P2", BigDecimal.TEN, BigDecimal.TEN, 10L,
                BigDecimal.TEN, 0);
        l2.setReportOnlineId(10L);
        reportView.add(l2);

        // Create line 3 (missing rol)
        reportView.add(createReportedRolView());

        // Convert list
        Map<Long, List<ReportOnLineView>> groupList = ReportOnLineViewParser.groupReportOnlinesByRolId(reportView);

        Assert.assertNotNull(groupList);
        Assert.assertFalse("Expected a non-empty map.", groupList.isEmpty());
        Assert.assertEquals("Expected only one item in group list.", 2, groupList.size());

        boolean sizeOneFound = false;
        boolean sizeTwoFound = false;
        for (List<ReportOnLineView> group : groupList.values()) {
            Assert.assertTrue("Expected group with size 1 or 2.", group.size() == 1 || group.size() == 2);
            if (group.size() == 1) {
                sizeOneFound = true;
            }
            if (group.size() == 2) {
                sizeTwoFound = true;
            }
        }

        Assert.assertTrue("Not found Group missing.", sizeOneFound);
        Assert.assertTrue("Not found Group rol id 10.", sizeTwoFound);
    }

    @Test
    public void test_group_report_onlines_by_rol_id_list_with_only_four_rol_and_two_parameters() {

        // Build list to be converted
        List<ReportOnLineView> reportView = new ArrayList<ReportOnLineView>();

        // Parameter 1 for rol 10
        ReportOnLineView l1 = setUsedRolParameter(createReportedRolView(), "P1", BigDecimal.ONE, BigDecimal.ONE, 1L,
                BigDecimal.ONE, -1);
        l1.setReportOnlineId(10L);
        reportView.add(l1);

        // Parameter 2 for rol 10
        ReportOnLineView l2 = setUsedRolParameter(createReportedRolView(), "P2", BigDecimal.TEN, BigDecimal.TEN, 10L,
                BigDecimal.TEN, 0);
        l2.setReportOnlineId(10L);
        reportView.add(l2);

        // Create line 3 (missing rol)
        reportView.add(createReportedRolView());

        // Create line 4 (missing rol)
        reportView.add(createReportedRolView());

        // Create line 5 (missing rol)
        reportView.add(createReportedRolView());

        // Convert list
        Map<Long, List<ReportOnLineView>> groupList = ReportOnLineViewParser.groupReportOnlinesByRolId(reportView);

        Assert.assertNotNull(groupList);
        Assert.assertFalse("Expected a non-empty map.", groupList.isEmpty());
        Assert.assertEquals("Expected two items in group list.", 2, groupList.size());

        for (List<ReportOnLineView> group : groupList.values()) {
            Assert.assertTrue("Expected group with size 2 or 3.", group.size() == 2 || group.size() == 3);
        }
    }

    @Test
    public void test_parser_report_online_view_to_reportOnline_5_lines_4_rols() {

        // Build list to be converted
        List<ReportOnLineView> reportView = new ArrayList<ReportOnLineView>();

        // Parameter 1 for rol 10
        ReportOnLineView l1 = setUsedRolParameter(createReportedRolView(), "P1", BigDecimal.ONE, BigDecimal.ONE, 1L,
                BigDecimal.ONE, -1);
        l1.setReportOnlineId(10L);
        reportView.add(l1);

        // Parameter 2 for rol 10
        ReportOnLineView l2 = setUsedRolParameter(createReportedRolView(), "P2", BigDecimal.TEN, BigDecimal.TEN, 10L,
                BigDecimal.TEN, 0);
        l2.setReportOnlineId(10L);
        reportView.add(l2);

        // Create line 3 (missing rol)
        reportView.add(createReportedRolView());

        // Create line 4 (missing rol)
        reportView.add(createReportedRolView());

        // Create line 5 (missing rol)
        reportView.add(createReportedRolView());

        // Group list
        Map<Long, List<ReportOnLineView>> groupList = ReportOnLineViewParser.groupReportOnlinesByRolId(reportView);

        Assert.assertNotNull(groupList);
        Assert.assertFalse("Expected a non-empty map.", groupList.isEmpty());

        // Convert list report online view to report online
        List<ReportOnLine> reportOnlineList = ReportOnLineViewParser.parserReportOnlineViewToReportOnline(groupList);

        Assert.assertNotNull(reportOnlineList);
        Assert.assertFalse("Expected a non-empty converted list.", reportOnlineList.isEmpty());
        Assert.assertEquals("Expected exactly 2 reports in list.", 2, reportOnlineList.size());

        // Verify results
        for (ReportOnLine rol : reportOnlineList) {

            Assert.assertNotNull(rol.getCrop());
            Assert.assertNotNull(rol.getHeadoffice());
            Assert.assertNotNull(rol.getItsUserLogin());
            Assert.assertNotNull(rol.getRolPeriod());
            Assert.assertNotNull(rol.getRolStatus());

            if (rol.getId().intValue() >= 0) {
                Assert.assertEquals("Expected exactly 2 parameters for rol with id 10.", 2, rol.getUsedRolParameters()
                        .size());

                // Validate rol parameters
                for (UsedRolParameter usedParam : rol.getUsedRolParameters()) {
                    Assert.assertNotNull(usedParam.getRolParameter());
                    Assert.assertNotNull(usedParam.getUsedRolParamAverageVal());
                    Assert.assertNotNull(usedParam.getUsedRolParameterTonValue());
                    Assert.assertNotNull(usedParam.getUsedRolParamMonetaryVal());
                    Assert.assertNotNull(usedParam.getUsedRolParamStripeValue());
                    Assert.assertTrue("Expected parameter P1 or P2. But found: "
                            + usedParam.getRolParameter().getRolParamShownDescription(), usedParam.getRolParameter()
                            .getRolParamShownDescription().equals("P1")
                            || usedParam.getRolParameter().getRolParamShownDescription().equals("P2"));
                }

            }

        }

    }

    @Test
    public void test_parser_report_online_view_to_reportOnline_5_lines_1_rol_3_parameters_and_2_justifications() {

        // Build list to be converted
        List<ReportOnLineView> reportView = new ArrayList<ReportOnLineView>();

        // -------------- parameters
        // Parameter 1 for rol 10
        ReportOnLineView l1 = setUsedRolParameter(createReportedRolView(), "P1", BigDecimal.ONE, BigDecimal.ONE, 1L,
                BigDecimal.ONE, -1);
        l1.setReportOnlineId(10L);
        reportView.add(l1);

        // Parameter 2 for rol 10
        ReportOnLineView l2 = setUsedRolParameter(createReportedRolView(), "P2", BigDecimal.TEN, BigDecimal.TEN, 10L,
                BigDecimal.TEN, -2);
        l2.setReportOnlineId(10L);
        reportView.add(l2);

        // Parameter 3 for rol 10
        ReportOnLineView l3 = setUsedRolParameter(createReportedRolView(), "P3", new BigDecimal(100), new BigDecimal(
                100), 100L, new BigDecimal(100), -3);
        l3.setReportOnlineId(10L);
        reportView.add(l3);

        // ------------- justifications

        // Parameter 1 for rol 10 justification 1
        String message1 = "justificacao 00000000000000000001 - um !";
        ReportOnLineView l4 = setRolJustificativa(
                setUsedRolParameter(createReportedRolView(), "P1", BigDecimal.ONE, BigDecimal.ONE, 1L, BigDecimal.ONE,
                        -1), message1, RolJustificationType.APPROVAL.name(), "cmiranda", CalendarUtil.getDate(2000, 1));
        l4.setReportOnlineId(10L);
        reportView.add(l4);

        // Parameter 1 for rol 10 justification 2
        String message2 = "             00000000000000000002 - dois!";
        ReportOnLineView l5 = setRolJustificativa(
                setUsedRolParameter(createReportedRolView(), "P1", BigDecimal.ONE, BigDecimal.ONE, 1L, BigDecimal.ONE,
                        -1), message2, RolJustificationType.APPROVAL.name(), "cmiranda", CalendarUtil.getDate(2000, 2));
        l5.setReportOnlineId(10L);
        reportView.add(l5);

        // Parameter 2 for rol 10 justification 1
        ReportOnLineView l6 = setRolJustificativa(
                setUsedRolParameter(createReportedRolView(), "P2", BigDecimal.TEN, BigDecimal.TEN, 10L, BigDecimal.TEN,
                        -2), message1, RolJustificationType.APPROVAL.name(), "cmiranda", CalendarUtil.getDate(2000, 1));
        l6.setReportOnlineId(10L);
        reportView.add(l6);

        // Parameter 2 for rol 10 justification 2
        ReportOnLineView l7 = setRolJustificativa(
                setUsedRolParameter(createReportedRolView(), "P2", BigDecimal.TEN, BigDecimal.TEN, 10L, BigDecimal.TEN,
                        -2), message2, RolJustificationType.APPROVAL.name(), "cmiranda", CalendarUtil.getDate(2000, 2));
        l7.setReportOnlineId(10L);
        reportView.add(l7);

        // Parameter 3 for rol 10 justification 1
        ReportOnLineView l8 = setRolJustificativa(
                setUsedRolParameter(createReportedRolView(), "P3", new BigDecimal(100), new BigDecimal(100), 100L,
                        new BigDecimal(100), -3), message1, RolJustificationType.APPROVAL.name(), "cmiranda",
                CalendarUtil.getDate(2000, 1));
        l8.setReportOnlineId(10L);
        reportView.add(l8);

        // Parameter 3 for rol 10 justification 1
        ReportOnLineView l9 = setRolJustificativa(
                setUsedRolParameter(createReportedRolView(), "P3", new BigDecimal(100), new BigDecimal(100), 100L,
                        new BigDecimal(100), -3), message2, RolJustificationType.APPROVAL.name(), "cmiranda",
                CalendarUtil.getDate(2000, 2));
        l9.setReportOnlineId(10L);
        reportView.add(l9);

        // Group list
        Map<Long, List<ReportOnLineView>> groupList = ReportOnLineViewParser.groupReportOnlinesByRolId(reportView);

        Assert.assertNotNull(groupList);
        Assert.assertFalse("Expected a non-empty map.", groupList.isEmpty());
        Assert.assertEquals("Expected 9 items in list.", 9, groupList.get(10L).size());

        // Convert list report online view to report online
        List<ReportOnLine> reportOnlineList = ReportOnLineViewParser.parserReportOnlineViewToReportOnline(groupList);

        Assert.assertNotNull(reportOnlineList);
        Assert.assertFalse("Expected a non-empty converted list.", reportOnlineList.isEmpty());
        Assert.assertEquals("Expected exactly 1 reports in list.", 1, reportOnlineList.size());

        // Verify results
        for (ReportOnLine rol : reportOnlineList) {

            Assert.assertNotNull(rol.getCrop());
            Assert.assertNotNull(rol.getHeadoffice());
            Assert.assertNotNull(rol.getItsUserLogin());
            Assert.assertNotNull(rol.getRolPeriod());
            Assert.assertNotNull(rol.getRolStatus());

            Assert.assertEquals("Expected exactly 3 parameters for rol with id 10.", 3, rol.getUsedRolParameters()
                    .size());

            // Validate rol parameters
            for (UsedRolParameter usedParam : rol.getUsedRolParameters()) {
                Assert.assertNotNull(usedParam.getRolParameter());
                Assert.assertNotNull(usedParam.getUsedRolParamAverageVal());
                Assert.assertNotNull(usedParam.getUsedRolParameterTonValue());
                Assert.assertNotNull(usedParam.getUsedRolParamMonetaryVal());
                Assert.assertNotNull(usedParam.getUsedRolParamStripeValue());
                Assert.assertTrue("Expected parameter P1, P2 or P3. But found: "
                        + usedParam.getRolParameter().getRolParamShownDescription(), usedParam.getRolParameter()
                        .getRolParamShownDescription().equals("P1")
                        || usedParam.getRolParameter().getRolParamShownDescription().equals("P2")
                        || usedParam.getRolParameter().getRolParamShownDescription().equals("P3"));
            }

            Assert.assertEquals("Expected exactly 2 rol justifications.", 2, rol.getJustifications().size());
            for (RolJustification justification : rol.getJustifications()) {
                Assert.assertNotNull(justification.getRolJustificationMessage());
                Assert.assertNotNull(justification.getRolJustificationType());
                Assert.assertNotNull(justification.getItsUserLogin());
                Assert.assertNotNull(justification.getRolJustificationDate());
            }

        }

    }

    @Test
    public void test_get_counter_price_by_rol_id_and_technology_in_rol_vw_group() {

        // Build list to be converted
        List<ReportOnLineView> reportView = new ArrayList<ReportOnLineView>();

        // Parameter 1 for rol 10 technology RRx
        ReportOnLineView l1 = setUsedRolParameter(createReportedRolView(), "P1", BigDecimal.ONE, BigDecimal.ONE, 1L,
                BigDecimal.ONE, -1);
        l1.setTechnologyDescription("RRx");
        l1.setReportOnlineId(10L);
        l1.setCounterPrice(new BigDecimal("159"));
        reportView.add(l1);

        // Parameter 1 for rol 10 techonology RRy
        ReportOnLineView l2 = setUsedRolParameter(createReportedRolView(), "P1", BigDecimal.ONE, BigDecimal.ONE, 1L,
                BigDecimal.ONE, -1);
        l2.setTechnologyDescription("RRy");
        l2.setReportOnlineId(10L);
        l2.setCounterPrice(new BigDecimal("963"));
        reportView.add(l2);

        BigDecimal counterPrice = ReportOnLineViewParser.getCounterPrice(10L, "RRx",
                ReportOnLineViewParser.groupReportOnlinesByRolId(reportView));
        Assert.assertNotNull(counterPrice);
        Assert.assertEquals(l1.getCounterPrice(), counterPrice);

        counterPrice = ReportOnLineViewParser.getCounterPrice(10L, "RRy",
                ReportOnLineViewParser.groupReportOnlinesByRolId(reportView));
        Assert.assertNotNull(counterPrice);
        Assert.assertEquals(l2.getCounterPrice(), counterPrice);

    }

    @Test
    public void test_get_credit_consumption_by_rol_id_and_technology_in_rol_vw_group() {

        // Build list to be converted
        List<ReportOnLineView> reportView = new ArrayList<ReportOnLineView>();

        // Parameter 1 for rol 10 technology RRx
        ReportOnLineView l1 = setUsedRolParameter(createReportedRolView(), "P1", BigDecimal.ONE, BigDecimal.ONE, 1L,
                BigDecimal.ONE, -1);
        l1.setTechnologyDescription("RRx");
        l1.setReportOnlineId(10L);
        l1.setAffiliateCreditConsumption(new BigDecimal("741"));
        reportView.add(l1);

        // Parameter 1 for rol 10 techonology RRy
        ReportOnLineView l2 = setUsedRolParameter(createReportedRolView(), "P1", BigDecimal.ONE, BigDecimal.ONE, 1L,
                BigDecimal.ONE, -1);
        l2.setTechnologyDescription("RRy");
        l2.setReportOnlineId(10L);
        l2.setAffiliateCreditConsumption(new BigDecimal("963"));
        reportView.add(l2);

        BigDecimal counterPrice = ReportOnLineViewParser.getCreditConsumption(10L, "RRx",
                ReportOnLineViewParser.groupReportOnlinesByRolId(reportView));
        Assert.assertNotNull(counterPrice);
        Assert.assertEquals(l1.getAffiliateCreditConsumption(), counterPrice);

        counterPrice = ReportOnLineViewParser.getCreditConsumption(10L, "RRy",
                ReportOnLineViewParser.groupReportOnlinesByRolId(reportView));
        Assert.assertNotNull(counterPrice);
        Assert.assertEquals(l2.getAffiliateCreditConsumption(), counterPrice);

    }

    @Test
    public void test_get_value_paid_by_grower_by_rol_id_and_technology_in_rol_vw_group() {

        // Build list to be converted
        List<ReportOnLineView> reportView = new ArrayList<ReportOnLineView>();

        // Parameter 1 for rol 10 technology RRx
        ReportOnLineView l1 = setUsedRolParameter(createReportedRolView(), "P1", BigDecimal.ONE, BigDecimal.ONE, 1L,
                BigDecimal.ONE, -1);
        l1.setTechnologyDescription("RRx");
        l1.setReportOnlineId(10L);
        l1.setValuePaidByGrower(new BigDecimal("741"));
        reportView.add(l1);

        // Parameter 1 for rol 10 techonology RRy
        ReportOnLineView l2 = setUsedRolParameter(createReportedRolView(), "P1", BigDecimal.ONE, BigDecimal.ONE, 1L,
                BigDecimal.ONE, -1);
        l2.setTechnologyDescription("RRy");
        l2.setReportOnlineId(10L);
        l2.setValuePaidByGrower(new BigDecimal("963"));
        reportView.add(l2);

        BigDecimal counterPrice = ReportOnLineViewParser.getValuePaidByGrower(10L, "RRx",
                ReportOnLineViewParser.groupReportOnlinesByRolId(reportView));
        Assert.assertNotNull(counterPrice);
        Assert.assertEquals(l1.getValuePaidByGrower(), counterPrice);

        counterPrice = ReportOnLineViewParser.getValuePaidByGrower(10L, "RRy",
                ReportOnLineViewParser.groupReportOnlinesByRolId(reportView));
        Assert.assertNotNull(counterPrice);
        Assert.assertEquals(l2.getValuePaidByGrower(), counterPrice);

        counterPrice = ReportOnLineViewParser.getValuePaidByGrower(10L, "RRz",
                ReportOnLineViewParser.groupReportOnlinesByRolId(reportView));
        Assert.assertNotNull(counterPrice);
        Assert.assertEquals(BigDecimal.ZERO, counterPrice);

    }

    @Test
    public void test_get_volume_paid_by_grower_by_rol_id_and_technology_in_rol_vw_group() {

        // Build list to be converted
        List<ReportOnLineView> reportView = new ArrayList<ReportOnLineView>();

        // Parameter 1 for rol 10 technology RRx
        ReportOnLineView l1 = setUsedRolParameter(createReportedRolView(), "P1", BigDecimal.ONE, BigDecimal.ONE, 1L,
                BigDecimal.ONE, -1);
        l1.setTechnologyDescription("RRx");
        l1.setReportOnlineId(10L);
        l1.setVolumePaidByGrower(new BigDecimal("741"));
        reportView.add(l1);

        // Parameter 1 for rol 10 techonology RRy
        ReportOnLineView l2 = setUsedRolParameter(createReportedRolView(), "P1", BigDecimal.ONE, BigDecimal.ONE, 1L,
                BigDecimal.ONE, -1);
        l2.setTechnologyDescription("RRy");
        l2.setReportOnlineId(10L);
        l2.setVolumePaidByGrower(new BigDecimal("753"));
        reportView.add(l2);

        BigDecimal counterPrice = ReportOnLineViewParser.getVolumePaidByGrower(10L, "RRx",
                ReportOnLineViewParser.groupReportOnlinesByRolId(reportView));
        Assert.assertNotNull(counterPrice);
        Assert.assertEquals(l1.getVolumePaidByGrower(), counterPrice);

        counterPrice = ReportOnLineViewParser.getVolumePaidByGrower(10L, "RRy",
                ReportOnLineViewParser.groupReportOnlinesByRolId(reportView));
        Assert.assertNotNull(counterPrice);
        Assert.assertEquals(l2.getVolumePaidByGrower(), counterPrice);

    }

    @Test
    public void test_get_volume_received_from_others_by_rol_id_and_technology_in_rol_vw_group() {

        // Build list to be converted
        List<ReportOnLineView> reportView = new ArrayList<ReportOnLineView>();

        // Parameter 1 for rol 10 technology RRx
        ReportOnLineView l1 = setUsedRolParameter(createReportedRolView(), "P1", BigDecimal.ONE, BigDecimal.ONE, 1L,
                BigDecimal.ONE, -1);
        l1.setTechnologyDescription("RRx");
        l1.setReportOnlineId(10L);
        l1.setAffiliateOtherValues(new BigDecimal("852"));
        reportView.add(l1);

        // Parameter 1 for rol 10 techonology RRy
        ReportOnLineView l2 = setUsedRolParameter(createReportedRolView(), "P1", BigDecimal.ONE, BigDecimal.ONE, 1L,
                BigDecimal.ONE, -1);
        l2.setTechnologyDescription("RRy");
        l2.setReportOnlineId(10L);
        l2.setAffiliateOtherValues(new BigDecimal("789"));
        reportView.add(l2);

        BigDecimal counterPrice = ReportOnLineViewParser.getVolumeReceivedFromOthers(10L, "RRx",
                ReportOnLineViewParser.groupReportOnlinesByRolId(reportView));
        Assert.assertNotNull(counterPrice);
        Assert.assertEquals(l1.getAffiliateOtherValues(), counterPrice);

        counterPrice = ReportOnLineViewParser.getVolumeReceivedFromOthers(10L, "RRy",
                ReportOnLineViewParser.groupReportOnlinesByRolId(reportView));
        Assert.assertNotNull(counterPrice);
        Assert.assertEquals(l2.getAffiliateOtherValues(), counterPrice);

    }

    @Test
    public void test_get_rol_limite_date_by_rol_id_in_rol_vw_group() {

        // Build list to be converted
        List<ReportOnLineView> reportView = new ArrayList<ReportOnLineView>();

        // Parameter 1 for rol 10 technology RRx
        ReportOnLineView l1 = setUsedRolParameter(createReportedRolView(), "P1", BigDecimal.ONE, BigDecimal.ONE, 1L,
                BigDecimal.ONE, -1);
        l1.setTechnologyDescription("RRx");
        l1.setReportOnlineId(10L);
        l1.setRolLimiteDate(CalendarUtil.getDate(2001, Calendar.SEPTEMBER));
        reportView.add(l1);

        // Parameter 1 for rol 10 techonology RRy
        ReportOnLineView l2 = setUsedRolParameter(createReportedRolView(), "P1", BigDecimal.ONE, BigDecimal.ONE, 1L,
                BigDecimal.ONE, -1);
        l2.setTechnologyDescription("RRy");
        l2.setReportOnlineId(10L);
        l2.setRolLimiteDate(CalendarUtil.getDate(2001, Calendar.SEPTEMBER));
        reportView.add(l2);

        Date rolLimiteDate = ReportOnLineViewParser.getReportLimitDate(10L,
                ReportOnLineViewParser.groupReportOnlinesByRolId(reportView));
        Assert.assertNotNull(rolLimiteDate);
        Assert.assertEquals(l1.getRolLimiteDate(), rolLimiteDate);
    }

    @Test
    public void test_is_missing_by_rol_id_in_rol_vw_group() {

        // Build list to be converted
        List<ReportOnLineView> reportView = new ArrayList<ReportOnLineView>();

        // Parameter 1 for rol 10 technology RRx
        ReportOnLineView l1 = setUsedRolParameter(createReportedRolView(), "P1", BigDecimal.ONE, BigDecimal.ONE, 1L,
                BigDecimal.ONE, -1);
        l1.setTechnologyDescription("RRx");
        l1.setReportOnlineId(10L);
        l1.setMissingState(Boolean.TRUE);
        reportView.add(l1);

        // Parameter 1 for rol 10 techonology RRy
        ReportOnLineView l2 = setUsedRolParameter(createReportedRolView(), "P1", BigDecimal.ONE, BigDecimal.ONE, 1L,
                BigDecimal.ONE, -1);
        l2.setTechnologyDescription("RRy");
        l2.setReportOnlineId(10L);
        l2.setMissingState(Boolean.TRUE);
        reportView.add(l2);

        Boolean itsMissing = ReportOnLineViewParser.isHeadOfficeInMissingState(10L,
                ReportOnLineViewParser.groupReportOnlinesByRolId(reportView));

        Assert.assertNotNull(itsMissing);
        Assert.assertEquals(l1.getMissingState(), itsMissing);
    }

    @Test
    public void test_get_revenue_account_by_rol_id_in_rol_vw_group() {

        // Build list to be converted
        List<ReportOnLineView> reportView = new ArrayList<ReportOnLineView>();

        // Parameter 1 for rol 10 technology RRx
        ReportOnLineView l1 = setUsedRolParameter(createReportedRolView(), "P1", BigDecimal.ONE, BigDecimal.ONE, 1L,
                BigDecimal.ONE, -1);
        l1.setTechnologyDescription("RRx");
        l1.setReportOnlineId(10L);
        l1.setRevenuePostDate(new Date());
        l1.setRevenueReversalCode("x");
        l1.setRevenueReversalDate(new Date());
        l1.setRevenueSapDocumentNumber("xx");
        l1.setRevenueSapOrderNumber("xxx");
        reportView.add(l1);

        // Obtain revenue account
        RevenueAccount revenueAccount = ReportOnLineViewParser.getRevenueAccount(10L,
                ReportOnLineViewParser.groupReportOnlinesByRolId(reportView));

        Assert.assertNotNull(revenueAccount);
        Assert.assertEquals(l1.getRevenuePostDate(), revenueAccount.getPostDate());
        Assert.assertEquals(l1.getRevenueReversalCode(), revenueAccount.getErpReversalCode());
        Assert.assertEquals(l1.getRevenueReversalDate(), revenueAccount.getReversalDate());
        Assert.assertEquals(l1.getRevenueSapDocumentNumber(), revenueAccount.getDocumentNumber());
        Assert.assertEquals(l1.getRevenueSapOrderNumber(), revenueAccount.getOrderNumber());

    }

    @Test
    public void test_filter_by_contracts_result_out_contracts_range() {

        // Build list to be converted
        List<ReportOnLineView> reportView = new ArrayList<ReportOnLineView>();

        // -------------- parameters
        // Parameter 1 for rol 10
        ReportOnLineView l1 = setUsedRolParameter(createReportedRolView(), "P1", BigDecimal.ONE, BigDecimal.ONE, 1L,
                BigDecimal.ONE, -1);
        l1.setReportOnlineId(10L);
        reportView.add(l1);

        // Parameter 2 for rol 10
        ReportOnLineView l2 = setUsedRolParameter(createReportedRolView(), "P2", BigDecimal.TEN, BigDecimal.TEN, 10L,
                BigDecimal.TEN, -2);
        l2.setReportOnlineId(10L);
        reportView.add(l2);

        // Parameter 3 for rol 10
        ReportOnLineView l3 = setUsedRolParameter(createReportedRolView(), "P3", new BigDecimal(100), new BigDecimal(
                100), 100L, new BigDecimal(100), -3);
        l3.setReportOnlineId(10L);
        reportView.add(l3);

        // ------------- justifications

        // Parameter 1 for rol 10 justification 1
        String message1 = "justificacao 00000000000000000001 - um !";
        ReportOnLineView l4 = setRolJustificativa(
                setUsedRolParameter(createReportedRolView(), "P1", BigDecimal.ONE, BigDecimal.ONE, 1L, BigDecimal.ONE,
                        -1), message1, RolJustificationType.APPROVAL.name(), "cmiranda", CalendarUtil.getDate(2000, 1));
        l4.setReportOnlineId(10L);
        reportView.add(l4);

        // Parameter 1 for rol 10 justification 2
        String message2 = "             00000000000000000002 - dois!";
        ReportOnLineView l5 = setRolJustificativa(
                setUsedRolParameter(createReportedRolView(), "P1", BigDecimal.ONE, BigDecimal.ONE, 1L, BigDecimal.ONE,
                        -1), message2, RolJustificationType.APPROVAL.name(), "cmiranda", CalendarUtil.getDate(2000, 2));
        l5.setReportOnlineId(10L);
        reportView.add(l5);

        // Parameter 2 for rol 10 justification 1
        ReportOnLineView l6 = setRolJustificativa(
                setUsedRolParameter(createReportedRolView(), "P2", BigDecimal.TEN, BigDecimal.TEN, 10L, BigDecimal.TEN,
                        -2), message1, RolJustificationType.APPROVAL.name(), "cmiranda", CalendarUtil.getDate(2000, 1));
        l6.setReportOnlineId(10L);
        reportView.add(l6);

        // Parameter 2 for rol 10 justification 2
        ReportOnLineView l7 = setRolJustificativa(
                setUsedRolParameter(createReportedRolView(), "P2", BigDecimal.TEN, BigDecimal.TEN, 10L, BigDecimal.TEN,
                        -2), message2, RolJustificationType.APPROVAL.name(), "cmiranda", CalendarUtil.getDate(2000, 2));
        l7.setReportOnlineId(10L);
        reportView.add(l7);

        // Parameter 3 for rol 10 justification 1
        ReportOnLineView l8 = setRolJustificativa(
                setUsedRolParameter(createReportedRolView(), "P3", new BigDecimal(100), new BigDecimal(100), 100L,
                        new BigDecimal(100), -3), message1, RolJustificationType.APPROVAL.name(), "cmiranda",
                CalendarUtil.getDate(2000, 1));
        l8.setReportOnlineId(10L);
        reportView.add(l8);

        // Parameter 3 for rol 10 justification 1
        ReportOnLineView l9 = setRolJustificativa(
                setUsedRolParameter(createReportedRolView(), "P3", new BigDecimal(100), new BigDecimal(100), 100L,
                        new BigDecimal(100), -3), message2, RolJustificationType.APPROVAL.name(), "cmiranda",
                CalendarUtil.getDate(2000, 2));
        l9.setReportOnlineId(10L);
        reportView.add(l9);

        // Build contract list
        List<UserContract> contracts = new ArrayList<UserContract>();

        Crop crop = new Crop();
        crop.setId(-1L);
        crop.setDescription("soya");

        Company company = new Company("msto");

        Document document = new Document(new DocumentType(null, null, "999"), "454545");
        Customer matrix = new Customer("python", document, null, "xxxx6");
        matrix.setId(-2000L);
        Contract contract = new Contract("x1", matrix, ParticipantTypeEnum.POD, crop, company);

        Customer affiliate = new Customer("python", document, null, "xxxx6");
        affiliate.setId(-2000L);

        UserContract userContract = new UserContract(contract, affiliate, HierarchyLevel.AFFILIATE);
        contracts.add(userContract);

        // Filter report view by contracts
        reportView = ReportOnLineViewParser.filterByContracts(reportView, contracts);
        Assert.assertNotNull(reportView);
        Assert.assertTrue("Expected empty list because user dont have access for anything in result.",
                reportView.isEmpty());

    }

    @Test
    public void test_filter_by_contracts_result_in_matrix_contracts_range() {

        // Build list to be converted
        List<ReportOnLineView> reportView = new ArrayList<ReportOnLineView>();

        // -------------- parameters
        // Parameter 1 for rol 10
        ReportOnLineView l1 = setUsedRolParameter(createReportedRolView(), "P1", BigDecimal.ONE, BigDecimal.ONE, 1L,
                BigDecimal.ONE, -1);
        l1.setReportOnlineId(10L);
        reportView.add(l1);

        // Parameter 2 for rol 10
        ReportOnLineView l2 = setUsedRolParameter(createReportedRolView(), "P2", BigDecimal.TEN, BigDecimal.TEN, 10L,
                BigDecimal.TEN, -2);
        l2.setReportOnlineId(10L);
        reportView.add(l2);

        // Parameter 3 for rol 10
        ReportOnLineView l3 = setUsedRolParameter(createReportedRolView(), "P3", new BigDecimal(100), new BigDecimal(
                100), 100L, new BigDecimal(100), -3);
        l3.setReportOnlineId(10L);
        reportView.add(l3);

        // ------------- justifications

        // Parameter 1 for rol 10 justification 1
        String message1 = "justificacao 00000000000000000001 - um !";
        ReportOnLineView l4 = setRolJustificativa(
                setUsedRolParameter(createReportedRolView(), "P1", BigDecimal.ONE, BigDecimal.ONE, 1L, BigDecimal.ONE,
                        -1), message1, RolJustificationType.APPROVAL.name(), "cmiranda", CalendarUtil.getDate(2000, 1));
        l4.setReportOnlineId(10L);
        reportView.add(l4);

        // Parameter 1 for rol 10 justification 2
        String message2 = "             00000000000000000002 - dois!";
        ReportOnLineView l5 = setRolJustificativa(
                setUsedRolParameter(createReportedRolView(), "P1", BigDecimal.ONE, BigDecimal.ONE, 1L, BigDecimal.ONE,
                        -1), message2, RolJustificationType.APPROVAL.name(), "cmiranda", CalendarUtil.getDate(2000, 2));
        l5.setReportOnlineId(10L);
        reportView.add(l5);

        // Parameter 2 for rol 10 justification 1
        ReportOnLineView l6 = setRolJustificativa(
                setUsedRolParameter(createReportedRolView(), "P2", BigDecimal.TEN, BigDecimal.TEN, 10L, BigDecimal.TEN,
                        -2), message1, RolJustificationType.APPROVAL.name(), "cmiranda", CalendarUtil.getDate(2000, 1));
        l6.setReportOnlineId(10L);
        reportView.add(l6);

        // Parameter 2 for rol 10 justification 2
        ReportOnLineView l7 = setRolJustificativa(
                setUsedRolParameter(createReportedRolView(), "P2", BigDecimal.TEN, BigDecimal.TEN, 10L, BigDecimal.TEN,
                        -2), message2, RolJustificationType.APPROVAL.name(), "cmiranda", CalendarUtil.getDate(2000, 2));
        l7.setReportOnlineId(10L);
        reportView.add(l7);

        // Parameter 3 for rol 10 justification 1
        ReportOnLineView l8 = setRolJustificativa(
                setUsedRolParameter(createReportedRolView(), "P3", new BigDecimal(100), new BigDecimal(100), 100L,
                        new BigDecimal(100), -3), message1, RolJustificationType.APPROVAL.name(), "cmiranda",
                CalendarUtil.getDate(2000, 1));
        l8.setReportOnlineId(10L);
        reportView.add(l8);

        // Parameter 3 for rol 10 justification 1
        ReportOnLineView l9 = setRolJustificativa(
                setUsedRolParameter(createReportedRolView(), "P3", new BigDecimal(100), new BigDecimal(100), 100L,
                        new BigDecimal(100), -3), message2, RolJustificationType.APPROVAL.name(), "cmiranda",
                CalendarUtil.getDate(2000, 2));
        l9.setReportOnlineId(10L);
        reportView.add(l9);

        // Build contract list
        List<UserContract> contracts = new ArrayList<UserContract>();

        Crop crop = new Crop();
        crop.setId(-1L);
        crop.setDescription("soya");

        Company company = new Company("msto");

        Document document = new Document(new DocumentType(null, null, "999"), "454545");
        Customer matrix = new Customer("python", document, null, "xxxx6");
        matrix.setId(1L);
        Contract contract = new Contract("x1", matrix, ParticipantTypeEnum.POD, crop, company);

        UserContract userContract = new UserContract(contract, matrix, HierarchyLevel.HEAD_OFFICE);
        contracts.add(userContract);

        // Filter report view by contracts
        List<ReportOnLineView> filterList = ReportOnLineViewParser.filterByContracts(reportView, contracts);
        Assert.assertNotNull(filterList);
        Assert.assertFalse("Expected non-empty list because user have access for all matrixes in result.",
                filterList.isEmpty());
        Assert.assertEquals("Expected the same size result list.", reportView.size(), filterList.size());

    }
}
