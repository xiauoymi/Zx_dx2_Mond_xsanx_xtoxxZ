package com.monsanto.brazilvaluecapture.pod.waybill.service.impl;

import com.monsanto.brazilvaluecapture.core.foundation.model.bean.SystemParameter;
import com.monsanto.brazilvaluecapture.core.foundation.model.bean.SystemParameterValue;
import com.monsanto.brazilvaluecapture.core.foundation.service.BusinessException;
import com.monsanto.brazilvaluecapture.core.foundation.service.SystemParameterService;
import com.monsanto.brazilvaluecapture.core.regionalization.VCCountry;
import com.monsanto.brazilvaluecapture.osb.util.SecurityContextBadCredentialException;
import com.monsanto.brazilvaluecapture.pod.waybill.model.bean.IncomingWaybill;
import com.monsanto.brazilvaluecapture.pod.waybill.service.IncomingWaybillService;
import org.apache.logging.log4j.Logger;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.net.MalformedURLException;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

//To run from IDE set VM parameters: -Dlsi.function=win -DMONCRYPTJV=c:/moncryptjv
public class AbstractWaybillImportServiceRunner_UT {

    @Mock private SystemParameterService systemParameterService;
    @Mock private IncomingWaybillService incomingWaybillService;
    @Mock private Logger logger;
    @InjectMocks private AbstractWaybillImportServiceRunner service;
    private int runCount;
    private int runLimit;
    private Exception runExceptionToThrow;

    public class DummyWaybillImportServiceRunner extends AbstractWaybillImportServiceRunner {

        public DummyWaybillImportServiceRunner() throws SecurityContextBadCredentialException, MalformedURLException {
            super("a_url");
        }

        protected Logger getLogger() {
            return logger;
        }

        protected VCCountry getCountry() {
            return VCCountry.ARGENTINA;
        }

        protected void doRun() throws Exception {
            setRunAgainRequired(++runCount != runLimit);
            if (runExceptionToThrow != null) {
                throw runExceptionToThrow;
            }
        }

    }

    @Before
    public void setUp() throws Exception {
        service = new DummyWaybillImportServiceRunner();
        MockitoAnnotations.initMocks(this);
        runLimit = 1;
    }

    @Test
    public void getRequestIdParameterShouldSucceed() {
        SystemParameter systemParameter = mock(SystemParameter.class);
        when(systemParameterService.selectParameterByGroupAndNameAndCountryCode(anyString(), anyString(), eq("AR")))
                .thenReturn(systemParameter);

        SystemParameter result = service.getRequestIdParameter();

        assertEquals(systemParameter, result);
    }

    @Test
    public void setRequestIdParameterShouldSucceed() throws Exception {
        SystemParameter systemParameter = mock(SystemParameter.class);

        service.setRequestIdParameter(systemParameter);

        verify(systemParameterService).save(systemParameter);
    }

    @Test
    public void addIncomingWaybillShouldSucceed() throws Exception {
        IncomingWaybill incomingWaybill = mock(IncomingWaybill.class);

        service.addIncomingWaybill(incomingWaybill);

        verify(incomingWaybillService).save(incomingWaybill);
    }

    @Test
    public void setServiceNameShouldSucceed() {
        service.setServiceName("SERVICE_NAME");

        assertEquals("SERVICE_NAME", service.getServiceName());
    }

    @Test
    public void setOperationNameShouldSucceed() {
        service.setOperationName("OPERATION_NAME");

        assertEquals("OPERATION_NAME", service.getOperationName());
    }

    @Test
    public void isEnabledShouldSucceed() {
        SystemParameter systemParameter = mock(SystemParameter.class);
        when(systemParameterService.selectParameterByGroupAndNameAndCountryCode(anyString(), anyString(), eq("AR")))
                .thenReturn(systemParameter);
        SystemParameterValue systemParameterValue = mock(SystemParameterValue.class);
        when(systemParameter.getSystemParameterValue()).thenReturn(systemParameterValue);
        when(systemParameterValue.getValue()).thenReturn("TruE");

        boolean result = service.isEnabled();

        assertTrue(result);
        verify(systemParameterService).selectParameterByGroupAndNameAndCountryCode(anyString(), anyString(), eq("AR"));
        verifyZeroInteractions(logger);
    }

    @Test
    public void isEnabledShouldReturnFalseWhenExceptionIsRaised() {
        Exception exception = new RuntimeException();
        when(systemParameterService.selectParameterByGroupAndNameAndCountryCode(anyString(), anyString(), eq("AR")))
                .thenThrow(exception);

        boolean result = service.isEnabled();

        assertFalse(result);
    }

    @Test
    public void doImportWaybillsShouldSucceed() throws Exception {
        SystemParameter systemParameter = mock(SystemParameter.class);
        when(systemParameterService.selectParameterByGroupAndNameAndCountryCode(anyString(), anyString(), eq("AR")))
                .thenReturn(systemParameter);
        SystemParameterValue systemParameterValue = mock(SystemParameterValue.class);
        when(systemParameter.getSystemParameterValue()).thenReturn(systemParameterValue);
        when(systemParameterValue.getValue()).thenReturn("TruE");

        service.doImportWaybills();

        assertEquals(1, runCount);
    }

    @Test
    public void doImportWaybillsShouldDoNothingWhenNotEnabled() throws Exception {
        SystemParameter systemParameter = mock(SystemParameter.class);
        when(systemParameterService.selectParameterByGroupAndNameAndCountryCode(anyString(), anyString(), eq("AR")))
                .thenReturn(systemParameter);
        SystemParameterValue systemParameterValue = mock(SystemParameterValue.class);
        when(systemParameter.getSystemParameterValue()).thenReturn(systemParameterValue);
        when(systemParameterValue.getValue()).thenReturn("FALSE");

        service.doImportWaybills();

        assertEquals(0, runCount);
    }

    @Test
    public void doImportWaybillsShouldRunManyTimesWhenRequired() throws Exception {
        SystemParameter systemParameter = mock(SystemParameter.class);
        when(systemParameterService.selectParameterByGroupAndNameAndCountryCode(anyString(), anyString(), eq("AR")))
                .thenReturn(systemParameter);
        SystemParameterValue systemParameterValue = mock(SystemParameterValue.class);
        when(systemParameter.getSystemParameterValue()).thenReturn(systemParameterValue);
        when(systemParameterValue.getValue()).thenReturn("TruE");
        runLimit = 3;

        service.doImportWaybills();

        assertEquals(3, runCount);
    }

    @Test
    public void doImportWaybillsShouldThrowBusinessExceptionWhenAnyExceptionIsRaised() {
        SystemParameter systemParameter = mock(SystemParameter.class);
        when(systemParameterService.selectParameterByGroupAndNameAndCountryCode(anyString(), anyString(), eq("AR")))
                .thenReturn(systemParameter);
        SystemParameterValue systemParameterValue = mock(SystemParameterValue.class);
        when(systemParameter.getSystemParameterValue()).thenReturn(systemParameterValue);
        when(systemParameterValue.getValue()).thenReturn("TruE");
        runExceptionToThrow = new RuntimeException();

        try {
            service.doImportWaybills();
            fail();

        } catch (BusinessException ex) {
            assertEquals(1, runCount);
            assertEquals(runExceptionToThrow, ex.getCause());
        }
    }

}