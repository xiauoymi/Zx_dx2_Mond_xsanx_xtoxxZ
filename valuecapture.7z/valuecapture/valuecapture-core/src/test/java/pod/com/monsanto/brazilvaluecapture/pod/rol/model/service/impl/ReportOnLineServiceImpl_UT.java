package com.monsanto.brazilvaluecapture.pod.rol.model.service.impl;


import com.monsanto.brazilvaluecapture.core.base.model.bean.*;
import com.monsanto.brazilvaluecapture.core.commercialhierarchy.model.bean.ItsDistrict;
import com.monsanto.brazilvaluecapture.core.commercialhierarchy.model.bean.ItsRegion;
import com.monsanto.brazilvaluecapture.core.commercialhierarchy.model.bean.ItsUnity;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Customer;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.HeadOffice;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.ParticipantTypeEnum;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Technology;
import com.monsanto.brazilvaluecapture.core.customer.service.ParticipantFilter;
import com.monsanto.brazilvaluecapture.core.customer.service.ParticipantService;
import com.monsanto.brazilvaluecapture.core.revenue.model.bean.RevenueAccount;
import com.monsanto.brazilvaluecapture.pod.rol.model.bean.*;
import com.monsanto.brazilvaluecapture.pod.rol.model.dao.ReportOnlineDAO;
import com.monsanto.brazilvaluecapture.pod.rol.model.service.*;
import junit.framework.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import static junit.framework.Assert.*;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class ReportOnLineServiceImpl_UT {

    @Mock
    ReportOnlineDAO mockReportOnlineDAO;
    @Mock
    ParticipantService mockParticipantService;
    @Mock
    RolConfigurationService mockRolConfigurationService;
    @Mock
    RolInformationService mockRolInformationService;
    @InjectMocks
    ReportOnLineServiceImpl reportOnLineService;

    Address address;
    Document document;
    private Date today = new Date();

    @Before
    public void setUp() {
        address = mock(Address.class);
        document = mock(Document.class);
    }

    @Test
    public void when_rollBackRelatedZeroCreditedROL_ifROLHasNo_rolBillValueZero_NULLIsReturned() throws ReportOnLineNotFoundException {
        //@Given
        RevenueAccount revenueAccount = createRevenueAccount();
        ReportOnLine expectedReportOnline = createReportOnLine(RolStatus.ROL_STATUS_PROCESSED, false);
        when(mockReportOnlineDAO.findRolStatusByCode(RolStatus.ROL_STATUS_RELEASED)).thenReturn(expectedReportOnline.getRolStatus());
        expectedReportOnline.setRolBillValueZero(false);

        //@When
        ReportOnLine reportOnLine = reportOnLineService.rollBackRelatedZeroCreditedROL(expectedReportOnline, revenueAccount);

        //@Should
        assertNull(reportOnLine);
    }

    @Test
    public void when_rollBackRelatedZeroCreditedROL_theGivenROL_hasStatusRELEASED() throws ReportOnLineNotFoundException {
        //@Given
        RevenueAccount revenueAccount = createRevenueAccount();
        ReportOnLine expectedReportOnline = createReportOnLine(RolStatus.ROL_STATUS_RELEASED, true);
        when(mockReportOnlineDAO.findRolStatusByCode(RolStatus.ROL_STATUS_RELEASED)).thenReturn(expectedReportOnline.getRolStatus());

        //@When
        ReportOnLine reportOnLine = reportOnLineService.rollBackRelatedZeroCreditedROL(expectedReportOnline, revenueAccount);

        //@Should
        assertNotNull(reportOnLine);
        assertEquals(RolStatus.ROL_STATUS_RELEASED, reportOnLine.getRolStatus().getRolStatusCode());
    }

    @Test
    public void when_rollBackRelatedZeroCreditedROL_theGivenROL_BillDateIsNULL() throws ReportOnLineNotFoundException {
        //@Given
        RevenueAccount revenueAccount = createRevenueAccount();
        ReportOnLine expectedReportOnline = createReportOnLine(RolStatus.ROL_STATUS_RELEASED, true);
        when(mockReportOnlineDAO.findRolStatusByCode(RolStatus.ROL_STATUS_RELEASED)).thenReturn(expectedReportOnline.getRolStatus());

        //@When
        ReportOnLine reportOnLine = reportOnLineService.rollBackRelatedZeroCreditedROL(expectedReportOnline, revenueAccount);

        //@Should
        assertNotNull(reportOnLine);
        assertNull(reportOnLine.getRolBillDate());
    }

    @Test
    public void when_rollBackRelatedZeroCreditedROL_theGivenROL_RolBillValueZeroIsNULL() throws ReportOnLineNotFoundException {
        //@Given
        RevenueAccount revenueAccount = createRevenueAccount();
        ReportOnLine expectedReportOnline = createReportOnLine(RolStatus.ROL_STATUS_RELEASED, true);
        when(mockReportOnlineDAO.findRolStatusByCode(RolStatus.ROL_STATUS_RELEASED)).thenReturn(expectedReportOnline.getRolStatus());

        //@When
        ReportOnLine reportOnLine = reportOnLineService.rollBackRelatedZeroCreditedROL(expectedReportOnline, revenueAccount);

        //@Should
        assertNotNull(reportOnLine);
        assertFalse(reportOnLine.getRolBillValueZero());
    }

    @Test
    public void when_rollBackRelatedZeroCreditedROL_theROLIsSaved() throws ReportOnLineNotFoundException {
        //@Given
        RevenueAccount revenueAccount = createRevenueAccount();
        ReportOnLine expectedReportOnline = createReportOnLine(RolStatus.ROL_STATUS_RELEASED, true);
        when(mockReportOnlineDAO.findRolStatusByCode(RolStatus.ROL_STATUS_RELEASED)).thenReturn(expectedReportOnline.getRolStatus());

        //@When
        ReportOnLine reportOnLine = reportOnLineService.rollBackRelatedZeroCreditedROL(expectedReportOnline, revenueAccount);

        //@Should
        assertNotNull(reportOnLine);
        verify(mockReportOnlineDAO).saveReportOnline(expectedReportOnline);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testSelectReportOnLineByFilter_ThrowsIllegalArgumentException_WhenReportOnlineFilterIsNull() throws Exception {
        ReportOnLineFilter reportOnLineFilter = null;

        reportOnLineService.selectReportOnLineByFilter(reportOnLineFilter);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testSelectReportOnLineByFilter_ThrowsIllegalArgumentException_WhenCompanyIsNull() throws Exception {
        ReportOnLineFilter reportOnLineFilter = new ReportOnLineFilter();
        reportOnLineFilter.setCompany(null);
        reportOnLineFilter.setCrop(new Crop());
        reportOnLineFilter.setMatrix(createCustomer("CUSTOMER_NAME"));
        reportOnLineFilter.setDistrict(createItsDistrict(1L, 2L, 3L));
        reportOnLineFilter.setParticipantType(ParticipantTypeEnum.POD);

        reportOnLineService.selectReportOnLineByFilter(reportOnLineFilter);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testSelectReportOnLineByFilter_ThrowsIllegalArgumentException_WhenCropIsNull() throws Exception {
        ReportOnLineFilter reportOnLineFilter = new ReportOnLineFilter();
        reportOnLineFilter.setCompany(new Company());
        reportOnLineFilter.setCrop(null);
        reportOnLineFilter.setMatrix(createCustomer("CUSTOMER_NAME"));
        reportOnLineFilter.setDistrict(createItsDistrict(1L, 2L, 3L));
        reportOnLineFilter.setParticipantType(ParticipantTypeEnum.POD);

        reportOnLineService.selectReportOnLineByFilter(reportOnLineFilter);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testSelectReportOnLineByFilter_ThrowsIllegalArgumentException_WhenMatrixAndDistrictIsNull() throws Exception {
        ReportOnLineFilter reportOnLineFilter = new ReportOnLineFilter();
        reportOnLineFilter.setCompany(new Company());
        reportOnLineFilter.setCrop(new Crop());
        reportOnLineFilter.setMatrix(null);
        reportOnLineFilter.setDistrict(null);
        reportOnLineFilter.setParticipantType(ParticipantTypeEnum.POD);

        reportOnLineService.selectReportOnLineByFilter(reportOnLineFilter);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testSelectReportOnLineByFilter_ThrowsIllegalArgumentException_WhenParticipantTypeIsNull() throws Exception {
        ReportOnLineFilter reportOnLineFilter = new ReportOnLineFilter();
        reportOnLineFilter.setCompany(new Company());
        reportOnLineFilter.setCrop(new Crop());
        reportOnLineFilter.setMatrix(createCustomer("CUSTOMER_NAME"));
        reportOnLineFilter.setDistrict(createItsDistrict(1L, 2L, 3L));
        reportOnLineFilter.setParticipantType(null);

        reportOnLineService.selectReportOnLineByFilter(reportOnLineFilter);
    }

    @Test
    public void testSelectReportOnLineByFilter_WhenValidFilterReturnsNoAffiliates() throws Exception {
        RolStatus rolStatus = new RolStatus(4L, RolStatus.ROL_STATUS_REPORTED, "STATUS_BUNDLE");
        ReportOnLineFilter reportOnLineFilter = createReportOnlineFilter();
        reportOnLineFilter.setRolStatus(rolStatus);
        reportOnLineFilter.setListRolStatus(Collections.singletonList(rolStatus));

        List<HeadOffice> affiliateList = new ArrayList<HeadOffice>();
        ParticipantFilter participantFilter = doFilterCopy(new ParticipantFilter(), reportOnLineFilter);
        when(mockParticipantService.selectAllCustomersByMatrixUnity(participantFilter)).thenReturn(affiliateList);

        List<ReportOnLineSearchDTO> reportOnLineSearchDTOs = reportOnLineService.selectReportOnLineByFilter(reportOnLineFilter);
        assertTrue(reportOnLineSearchDTOs.size() == 0);
        verify(mockParticipantService, times(1)).selectAllCustomersByMatrixUnity(participantFilter);
    }

    @Test
    public void testSelectReportOnLineByFilter_WhenValidFilterReturnsAffiliates() throws Exception {
        RolStatus rolStatus = new RolStatus(4L, RolStatus.ROL_STATUS_REPORTED, "STATUS_BUNDLE");
        ReportOnLineFilter reportOnLineFilter = createReportOnlineFilter();
        reportOnLineFilter.setRolStatus(rolStatus);
        reportOnLineFilter.setListRolStatus(Collections.singletonList(rolStatus));

        HeadOffice headOffice = new HeadOffice(createCustomer("CUSTOMER_NAME"), reportOnLineFilter.getMatrix(), reportOnLineFilter.getParticipantType(), reportOnLineFilter.getCrop(), reportOnLineFilter.getCompany());
        List<HeadOffice> affiliateList = Collections.singletonList(headOffice);
        ParticipantFilter participantFilter = doFilterCopy(new ParticipantFilter(), reportOnLineFilter);
        when(mockParticipantService.selectAllCustomersByMatrixUnity(participantFilter)).thenReturn(affiliateList);

        ReportOnLineFilter modifiedReportOnLineFilter = (ReportOnLineFilter) doFilterCopy(new ReportOnLineFilter(), reportOnLineFilter);
        modifiedReportOnLineFilter.setMatrix(null);
        modifiedReportOnLineFilter.setHeadOfficeList(affiliateList);
        ReportOnLine reportOnLine = createReportOnLine(reportOnLineFilter, headOffice);
        List<ReportOnLine> reportOnLineList = Collections.singletonList(reportOnLine);
        when(mockReportOnlineDAO.selectReportOnLineListByFilter(modifiedReportOnLineFilter)).thenReturn(reportOnLineList);

        RolConfiguration rolConfig = new RolConfiguration(1L, reportOnLineFilter.getCrop(), reportOnLineFilter.getCompany(), new Date(), new BigDecimal(10));
        when(mockRolConfigurationService.selectRolConfiguration(reportOnLineFilter.getCrop(), reportOnLineFilter.getCompany())).thenReturn(rolConfig);

        Technology technology = new Technology("TECHNOLOGY", reportOnLineFilter.getCompany());
        CounterPrice counterPrice = new CounterPrice(4L, reportOnLineFilter.getDistrict(), technology, reportOnLineFilter.getCrop(), new Date());
        when(mockRolInformationService.selectCounterPriceByRol(reportOnLine, technology)).thenReturn(counterPrice);

        when(mockRolInformationService.selectRolStatusByCode(RolStatus.ROL_STATUS_REPORTED)).thenReturn(rolStatus);

        List<ReportOnLineSearchDTO> reportOnLineSearchDTOs = reportOnLineService.selectReportOnLineByFilter(reportOnLineFilter);

        Assert.assertNotNull(reportOnLineSearchDTOs);
        assertTrue(reportOnLineSearchDTOs.size() == 1);
        verify(mockParticipantService, times(1)).selectAllCustomersByMatrixUnity(participantFilter);
        verify(mockReportOnlineDAO, times(1)).selectReportOnLineListByFilter(modifiedReportOnLineFilter);
        verify(mockRolConfigurationService, times(1)).selectRolConfiguration(reportOnLineFilter.getCrop(), reportOnLineFilter.getCompany());
        verify(mockRolInformationService, times(1)).selectCounterPriceByRol(reportOnLine, technology);
        verify(mockRolInformationService, times(1)).selectRolStatusByCode(RolStatus.ROL_STATUS_REPORTED);

    }

//    helper methods

    private ItsDistrict createItsDistrict(long itsDistrictId, long itsRegionId, long itsUnityId) {
        ItsDistrict itsDistrict = new ItsDistrict(itsDistrictId);
        itsDistrict.setItsRegion(new ItsRegion(itsRegionId));
        itsDistrict.setItsUnity(new ItsUnity(itsUnityId));
        return itsDistrict;
    }

    private ReportOnLineFilter createReportOnlineFilter() {
        ReportOnLineFilter reportOnLineFilter = new ReportOnLineFilter();
        Company company = new Company("COMPANY_NAME");
        reportOnLineFilter.setCompany(company);
        reportOnLineFilter.setCrop(new Crop("CROP_NAME", company, new Country("COUNTRY_NAME", "COUNTRY_CODE")));
        reportOnLineFilter.setMatrix(createCustomer("MATRIX_NAME"));
        reportOnLineFilter.setDistrict(createItsDistrict(1L, 2L, 3L));
        reportOnLineFilter.setParticipantType(ParticipantTypeEnum.POD);
        return reportOnLineFilter;
    }

    private ParticipantFilter doFilterCopy(ParticipantFilter copyFilter, ReportOnLineFilter reportOnLineFilter) {
        copyFilter.setCompany(reportOnLineFilter.getCompany());
        copyFilter.setCrop(reportOnLineFilter.getCrop());
        copyFilter.setMatrix(reportOnLineFilter.getMatrix());
        copyFilter.setDistrict(reportOnLineFilter.getDistrict());
        copyFilter.setParticipantType(reportOnLineFilter.getParticipantType());
        copyFilter.setListRolStatus(reportOnLineFilter.getListRolStatus());
        if (copyFilter instanceof ReportOnLineFilter) {
            ((ReportOnLineFilter) copyFilter).setRolStatus(reportOnLineFilter.getRolStatus());
        }
        return copyFilter;
    }

    private ReportOnLine createReportOnLine(ReportOnLineFilter reportOnLineFilter, HeadOffice headOffice) {
        ReportOnLine reportOnLine = new ReportOnLine(2L, reportOnLineFilter.getCrop(), null, headOffice, reportOnLineFilter.getRolStatus(), new Date(), new Date());
        reportOnLine.setUsedRolParameters(Collections.singleton(createUsedRolParameter(reportOnLineFilter)));
        return reportOnLine;
    }

    private com.monsanto.brazilvaluecapture.pod.rol.model.bean.UsedRolParameter createUsedRolParameter(ReportOnLineFilter reportOnLineFilter) {
        com.monsanto.brazilvaluecapture.pod.rol.model.bean.UsedRolParameter usedRolParameter = new com.monsanto.brazilvaluecapture.pod.rol.model.bean.UsedRolParameter();
        RolParameter rolParameter = new RolParameter();
        rolParameter.setTechnology(new Technology("TECHNOLOGY", reportOnLineFilter.getCompany()));
        usedRolParameter.setRolParameter(rolParameter);
        return usedRolParameter;
    }


    private RevenueAccount createRevenueAccount() {
        final RevenueAccount revenueAccount = mock(RevenueAccount.class);
        when(revenueAccount.getCustomer()).thenReturn(createCustomer("matrix"));
        return revenueAccount;
    }

    private ReportOnLine createReportOnLine(String status, Boolean billValueZero) {
        final ReportOnLine reportOnLine = new ReportOnLine();
        RolStatus rolStatus = new RolStatus(4l, status, null);
        reportOnLine.setRolStatus(rolStatus);
        reportOnLine.setRolBillValueZero(billValueZero);
        reportOnLine.setRolBillDate(today);
        HeadOffice headOffice = getHeadOffice();
        reportOnLine.setHeadoffice(headOffice);
        return reportOnLine;
    }

    private HeadOffice getHeadOffice() {
        Customer customer = createCustomer("customer");
        Customer matrix = createCustomer("matrix");
        Company company = new Company("MONSANTO");
        Country country = new Country("Cuba", "CU");
        Crop crop = new Crop("SOJA", company, country);
        return new HeadOffice(customer, matrix, ParticipantTypeEnum.POD, crop, company);
    }

    private Customer createCustomer(String customerName) {
        String sapCode = "someSAPCode";
        return new Customer(customerName, document, address, sapCode);
    }

}
