package com.monsanto.brazilvaluecapture.pod.revenue;

import org.junit.extensions.cpsuite.ClasspathSuite;
import org.junit.extensions.cpsuite.ClasspathSuite.ClassnameFilters;
import org.junit.runner.RunWith;


@RunWith(value = ClasspathSuite.class)
@ClassnameFilters({"com.monsanto.brazilvaluecapture.pod.revenue.*AT", 
				   "com.monsanto.brazilvaluecapture.pod.revenue.*UT"})
public class SuitePodRevenue {

}
