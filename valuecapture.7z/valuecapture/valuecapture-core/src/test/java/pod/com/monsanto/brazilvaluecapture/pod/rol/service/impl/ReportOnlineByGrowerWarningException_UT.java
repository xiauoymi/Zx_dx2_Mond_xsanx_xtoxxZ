package com.monsanto.brazilvaluecapture.pod.rol.service.impl;

import java.util.ArrayList;

import junit.framework.Assert;

import org.junit.Test;

import com.monsanto.brazilvaluecapture.pod.rol.model.service.ReportOnlineByGrowerWarningException;
import com.monsanto.brazilvaluecapture.pod.rol.model.service.ReportWarningImportedException;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.CsvSaleCancellationImportLine;
import com.monsanto.brazilvaluecapture.seedsale.sale.service.parser.cancellation.SaleCancelationCsvImportedLine;

/**
 * @author cmiranda
 * 
 */
public class ReportOnlineByGrowerWarningException_UT {

    @Test
    public void sanity_test() {

        ReportOnlineByGrowerWarningException exception = new ReportOnlineByGrowerWarningException("error!");
        exception = new ReportOnlineByGrowerWarningException("error!", new ArrayList<ReportWarningImportedException>());

        SaleCancelationCsvImportedLine saleCancelationCsvImportedLine = new SaleCancelationCsvImportedLine(
                new CsvSaleCancellationImportLine());
        saleCancelationCsvImportedLine.setLine(1);

        Assert.assertTrue(exception.getWarnings().isEmpty());
        exception.add(new ReportWarningImportedException("", saleCancelationCsvImportedLine));
        Assert.assertFalse(exception.getWarnings().isEmpty());

        exception.addAll(new ArrayList<ReportWarningImportedException>());
        exception.setWarnings(new ArrayList<ReportWarningImportedException>());
        Assert.assertTrue(exception.getWarnings().isEmpty());
    }
}
