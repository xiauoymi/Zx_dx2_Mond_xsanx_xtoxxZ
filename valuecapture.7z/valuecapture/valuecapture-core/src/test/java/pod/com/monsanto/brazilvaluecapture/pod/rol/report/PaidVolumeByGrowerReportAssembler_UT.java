package com.monsanto.brazilvaluecapture.pod.rol.report;

import java.io.ByteArrayOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.ResourceBundle;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.monsanto.brazilvaluecapture.core.foundation.util.report.ReportUtilAssert;
import com.monsanto.brazilvaluecapture.pod.rol.model.bean.PaidVolumeByGrowerDTO;

/**
 * @author andrius
 * 
 */
public class PaidVolumeByGrowerReportAssembler_UT {

    /**
     * Bundle
     */
    private ResourceBundle resourceBundle = ResourceBundle.getBundle("bundle/bundle");

    /**
     * Source
     */
    private List<PaidVolumeByGrowerDTO> reportSource = new ArrayList<PaidVolumeByGrowerDTO>();

    @Before
    public void setup() {
        // Build report
        buildReportOnline();
    }

    /**
     * Build report online
     */
    private void buildReportOnline() {

        // Create a dto
        PaidVolumeByGrowerDTO dto = new PaidVolumeByGrowerDTO();
        dto.setBundle(resourceBundle);
        
        dto.setMatrixDocumentType("CNPJ");
        dto.setMatrixDocument("12345678912");
        dto.setMatrixDocumentMask("999.999.999-99");
        dto.setMatrixName("Gr�os S�o Paulo da Mi�pi");
        dto.setMatrixCity("Cidade Matriz");
        dto.setMatrixState("Estado Matriz");
        dto.setMatrixUnity("Matrix Unity");
        dto.setMatrixRegion("Matrix Region");
        dto.setMatrixDistrict("Matrix District");

        dto.setAffiliateDocumentType("CPF");
        dto.setAffiliateDocument("35401425869");
        dto.setAffiliateDocumentMask("999.999.999-99");
        dto.setAffiliateName("Gr�os S�o Jo�o da Boa Vista");
        dto.setAffiliateUnity("Unidade Filial");
        dto.setAffiliateRegion("Regional Filial");
        dto.setAffiliateDistrict("Distrito Filial");
        dto.setGrowerAddress("Rua das Amoreiras, n�mero 1");
        dto.setAffiliateCity("Campinas");
        dto.setAffiliateState("S�o Paulo");

        dto.setGrowerDocumentType("CPF");
        dto.setGrowerDocument("35401425869");
        dto.setGrowerDocumentMask("999.999.999-99");
        dto.setGrowerName("Jos� da Silva Silvestre");
        dto.setGrowerCity("Americana");
        dto.setGrowerState("SP");
        dto.setGrowerUnity("Grower Unity");
        dto.setGrowerRegion("Grower Region");
        dto.setGrowerDistrict("Grower District");

        dto.setPeriod(new Date());
        dto.setDate(new Date());
        dto.setQuantityTon(new BigDecimal(50.50));
        dto.setRoyaltMoneyValue(new BigDecimal(50.56));
        dto.setTotalBilled(new BigDecimal(25.10));
        dto.setTotalRoyaltMoneyValue(new BigDecimal(0.11));
        dto.setTechnology("RR");

        reportSource.add(dto);
    }

    /**
     * @throws NoSuchMethodException
     * @throws IOException
     * 
     */
    @Test
    public void test_generate_report_consolidated() throws NoSuchMethodException, IOException {

        // Warning: keep this parameter like false
        Boolean enableOutputReport = Boolean.FALSE;
        Boolean detailedReport = Boolean.FALSE;
        
        // assembler report
        PaidVolumeByGrowerReportAssembler reportAssembler = new PaidVolumeByGrowerReportAssembler(reportSource,
                resourceBundle, detailedReport);

        ByteArrayOutputStream baos = reportAssembler.build();
        Assert.assertNotNull(baos);

        // Check for report header
        validateHeader(baos, detailedReport);

        // Enable output for debug
        if (enableOutputReport) {
            FileOutputStream fos = new FileOutputStream("c:\\junit_report.xls");
            fos.write(baos.toByteArray());
            fos.close();
        }
    }

    /**
     * @throws NoSuchMethodException
     * @throws IOException
     * 
     */
    @Test
    public void test_generate_report_detailed() throws NoSuchMethodException, IOException {

        // Warning: keep this parameter like false
        Boolean enableOutputReport = Boolean.FALSE;
        Boolean detailedReport = Boolean.TRUE;
        
        // assembler report
        PaidVolumeByGrowerReportAssembler reportAssembler = new PaidVolumeByGrowerReportAssembler(reportSource,
                resourceBundle, detailedReport);

        ByteArrayOutputStream baos = reportAssembler.build();
        Assert.assertNotNull(baos);

        // Check for report header
        validateHeader(baos, detailedReport);

        // Enable output for debug
        if (enableOutputReport) {
            FileOutputStream fos = new FileOutputStream("c:\\junit_report.xls");
            fos.write(baos.toByteArray());
            fos.close();
        }
    }

    /**
     * Validate the Report's Header
     * 
     * @param outputStream
     * @throws IOException
     */
    private void validateHeader(final ByteArrayOutputStream outputStream, boolean detailedReport) throws IOException {

        // Headers labels to check
        String[] columnsLabels = new String[] { 
                "pod.report.paidvolumegrower.matrixdocumenttype.label",
                "pod.report.paidvolumegrower.matrixdocument.label", 
                "pod.report.paidvolumegrower.matrixname.label",
                "pod.report.paidvolumegrower.matrixcity.label", 
                "pod.report.paidvolumegrower.matrixstate.label",
                "pod.report.paidvolumegrower.matrixunity.label",
                "pod.report.paidvolumegrower.matrixregion.label",
                "pod.report.paidvolumegrower.matrixdistrict.label",
                "pod.report.paidvolumegrower.affiliatedocumenttype.label",
                "pod.report.paidvolumegrower.affiliatedocument.label",
                "pod.report.paidvolumegrower.affiliatename.label",
                "pod.report.paidvolumegrower.affiliatecity.label",
                "pod.report.paidvolumegrower.affiliatestate.label",
                "pod.report.paidvolumegrower.affiliateunity.label",
                "pod.report.paidvolumegrower.affiliateregion.label",
                "pod.report.paidvolumegrower.affiliatedistrict.label",
                "pod.report.paidvolumegrower.growerdocumenttype.label",
                "pod.report.paidvolumegrower.growerdocument.label",
                "pod.report.paidvolumegrower.growername.label",
                "pod.report.paidvolumegrower.growercity.label",
                "pod.report.paidvolumegrower.growerstate.label",
                "pod.report.paidvolumegrower.growerunity.label",
                "pod.report.paidvolumegrower.growerregion.label",
                "pod.report.paidvolumegrower.growerdistrict.label", 
                "pod.report.paidvolumegrower.groweraddress.label",
                "pod.report.paidvolumegrower.period.label"};
         
        String columnDate = null;
        if(detailedReport) {
            columnDate = "pod.report.paidvolumegrower.date.label";
        }
        
        String[] columnsLabels2 = new String[] {       
                "pod.report.paidvolumegrower.technology.label",
                "pod.report.paidvolumegrower.quantityton.label",
                "pod.report.paidvolumegrower.royaltmoneyvalue.label",
                "pod.report.paidvolumegrower.totalbilled.label",
                "pod.report.paidvolumegrower.totalroyaltmoneyvalue.label" };

        int column = 0;
        for (String columnLabel : columnsLabels) {
            ReportUtilAssert.assertEqualsCell(outputStream, 0, 0, column++, resourceBundle.getString(columnLabel));
        }
        
        if(detailedReport) {
            ReportUtilAssert.assertEqualsCell(outputStream, 0, 0, column++, resourceBundle.getString(columnDate));
        }
        
        for (String columnLabel : columnsLabels2) {
            ReportUtilAssert.assertEqualsCell(outputStream, 0, 0, column++, resourceBundle.getString(columnLabel));
        }
    }
}
