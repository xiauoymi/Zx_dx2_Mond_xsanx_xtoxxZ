package com.monsanto.brazilvaluecapture.pod.service;

import com.monsanto.brazilvaluecapture.core.base.model.bean.City;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Country;
import com.monsanto.brazilvaluecapture.core.base.model.bean.DocumentType;
import com.monsanto.brazilvaluecapture.core.base.model.bean.State;
import com.monsanto.brazilvaluecapture.core.base.model.dao.StateDAO;
import com.monsanto.brazilvaluecapture.core.base.service.BaseService;
import com.monsanto.brazilvaluecapture.core.base.service.CompanyService;
import com.monsanto.brazilvaluecapture.core.base.service.RegionService;
import com.monsanto.brazilvaluecapture.core.foundation.model.bean.SystemParameter;
import com.monsanto.brazilvaluecapture.core.foundation.model.bean.SystemParameterValue;
import com.monsanto.brazilvaluecapture.core.foundation.model.bean.TypeParameter;
import com.monsanto.brazilvaluecapture.core.foundation.service.BusinessException;
import com.monsanto.brazilvaluecapture.core.foundation.service.SystemParameterService;
import com.monsanto.brazilvaluecapture.core.grower.model.bean.Grower;
import com.monsanto.brazilvaluecapture.core.grower.model.dao.GrowerDAO;
import com.monsanto.brazilvaluecapture.core.grower.service.EmailParametersService;
import com.monsanto.brazilvaluecapture.core.grower.service.impl.CustomerCreationServiceRunner;
import com.monsanto.brazilvaluecapture.core.regionalization.CountriesHolder;
import com.monsanto.brazilvaluecapture.osb.its.api.LASVCCustomerCreationService;
import com.monsanto.brazilvaluecapture.pod.service.impl.GrowerNonParticipantLicencingServiceImpl;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

import static junit.framework.Assert.fail;
import static org.fest.assertions.Assertions.assertThat;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.*;

/**
 * Created with IntelliJ IDEA.
 * User: JPNORV
 * Date: 22/10/13
 */
@RunWith(MockitoJUnitRunner.class)
public class GrowerNonParticipantLicencingServiceImpl_UT {

    String countryCode = null;
    String countryCodePy = null;
    String documentNumber = null;
    Country country = new Country();
    Country countryPY = new Country();
    State state = new State();
    Set<City> cities = new HashSet<City>();
    City city = new City();
    SystemParameter systemParameter = new SystemParameter();
    DocumentType documentType = new DocumentType();
    String customerSAPCode;
    String destinationDocumentType = "RUC";
    @Mock
    private BaseService baseService;
    @Mock
    private LASVCCustomerCreationService osbService;
    @Mock
    private SystemParameterService systemParameterService;
    @Mock
    private CountriesHolder countriesHolder;
    @Mock
    private GrowerDAO growerDAO;
    @Mock
    private RegionService regionService;
    @Mock
    private CompanyService companyService;
    @Mock
    private CustomerCreationServiceRunner customerCreationServiceRunner;
    @Mock
    private EmailParametersService emailParametersService;
    @Mock
    private Iterator<City> iterator;
    @Mock
    private StateDAO stateDAO;
    @InjectMocks
    private GrowerNonParticipantLicencingServiceImpl growerNonParticipantLicencingService;

    @Before
    public void givenThis() {
        countryCode = "AR";
        countryCodePy = "PY";
        documentNumber = "20295426811";
        country.setCode(countryCode);
        country.setDescription("ARGENTINA");
        country.setId(1l);
        countryPY.setCode(countryCodePy);
        countryPY.setDescription("PARAGUAY");
        countryPY.setId(1L);
        cities.add(city);
        state.setCities(cities);
        customerSAPCode = "20";
        SystemParameterValue systemParameterValue = new SystemParameterValue(TypeParameter.STRING, "0000");
        systemParameter.setSystemParameterValue(systemParameterValue);
    }

    @Test
    public void testCreateGrowerWithOnlyDocumentNumberAndDescription() throws BusinessException {
        //@Given
        when(regionService.selectByDescription(countryCode)).thenReturn(country);
        when(regionService.selectCoutryByCountryCode(countryCode)).thenReturn(country);
        when(regionService.selectByCode("POD GENERIC_AR")).thenReturn(state);
        when(regionService.selectByState(state)).thenReturn(new ArrayList<City>(cities));
        when(baseService.getDocumentTypeByDescription(anyString())).thenReturn(documentType);
        when(systemParameterService.selectParameterByNameAndCountry(anyString(), anyLong())).thenReturn(systemParameter);

        //@When
        Grower grower = growerNonParticipantLicencingService.inNewTxCreateGrower(documentNumber, "SOJA SA", countryCode, state, destinationDocumentType);

        //@Should
        verify(this.baseService).saveGrower(grower);
    }

    @Test
    public void testCreateGrowerWithOnlyDocumentNumberAndDescriptionFailCreateCustomerInSAP() throws Exception {
        //@Given
        when(regionService.selectByDescription(countryCode)).thenReturn(country);
        when(regionService.selectByDescription(countryCode)).thenReturn(country);
        when(regionService.selectCoutryByCountryCode(countryCode)).thenReturn(country);
        when(regionService.selectByCode("POD GENERIC_AR")).thenReturn(state);
        when(regionService.selectByState(state)).thenReturn(new ArrayList<City>(cities));
        when(baseService.getDocumentTypeByDescription(anyString())).thenReturn(documentType);
        when(systemParameterService.selectParameterByNameAndCountry(anyString(), anyLong())).thenReturn(systemParameter);
        doThrow(Exception.class).when(customerCreationServiceRunner).run();

        try {
            growerNonParticipantLicencingService.inNewTxCreateGrower(documentNumber, "SOJA SA", countryCode, state, destinationDocumentType);
            fail();
        } catch (Exception e) {
            assertThat(e).isInstanceOf(BusinessException.class);
        } catch (Throwable t) {
            fail();
        }
    }

    @Test
    public void testCreatePYGrowerWithOnlyDocumentNumberAndDescription() throws BusinessException {
        //@Given
        when(regionService.selectByDescription(countryCodePy)).thenReturn(countryPY);
        when(regionService.selectCoutryByCountryCode(countryCodePy)).thenReturn(countryPY);
        when(regionService.selectByCode("POD GENERIC_PY")).thenReturn(state);
        when(regionService.selectByState(state)).thenReturn(new ArrayList<City>(cities));
        when(baseService.getDocumentTypeByDescription(anyString())).thenReturn(documentType);
        when(systemParameterService.selectParameterByNameAndCountry(anyString(), anyLong())).thenReturn(systemParameter);

        //@When
        Grower grower = growerNonParticipantLicencingService.inNewTxCreateGrower(documentNumber, "SOJA SA", countryCodePy, state, destinationDocumentType);

        //@Should
        verify(this.baseService).saveGrower(grower);
    }


}