package com.monsanto.brazilvaluecapture.pod.rol.report;

import com.monsanto.brazilvaluecapture.core.base.model.bean.*;
import com.monsanto.brazilvaluecapture.core.commercialhierarchy.model.bean.*;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.*;
import com.monsanto.brazilvaluecapture.core.foundation.RandomTestData;
import com.monsanto.brazilvaluecapture.core.foundation.util.CalendarUtil;
import com.monsanto.brazilvaluecapture.core.foundation.util.report.ReportUtilAssert;
import com.monsanto.brazilvaluecapture.core.revenue.model.bean.RevenueAccount;
import com.monsanto.brazilvaluecapture.pod.rol.model.bean.*;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.io.ByteArrayOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.math.BigDecimal;
import java.util.*;

/**
 * @author cmiranda
 *
 */
public class DetailedReportAssembler_UT {

    /**
     * Bundle
     */
    private ResourceBundle resourceBundle = ResourceBundle.getBundle("bundle/bundle");

    /**
     * Source
     */
    private List<ReportOnlineDTO> reportSource = new ArrayList<ReportOnlineDTO>();

    @Before
    public void setup() {
        // Build report
        buildReportOnline();
    }

    /**
     * Build report online
     */
    private void buildReportOnline() {

        // Create system data
        Country country = new Country("USA", "usa");
        State state = new State(country, "state 1", "st");
        City city = new City("cidade 1", state);
        Company company = new Company("monsanto");
        Crop crop = new Crop("soya", company, country);
        Technology technologyRR = new Technology("rr", company);
        technologyRR.setId(1L);
        Technology technologyIntacta = new Technology("intact", company);
        technologyIntacta.setId(2L);
        Technology technologyXpto = new Technology("xpto", company);
        technologyXpto.setId(3L);
        OperationalYear operationalYear = new OperationalYear("2012");

        // Build commercial hierarchy
        CustomerDistrict customerDistrict = new CustomerDistrict();
        customerDistrict.setCommercialHierarchy(new CommercialHierarchy());
        customerDistrict.getCommercialHierarchy().setCommercialHierType(new CommercialHierType());
        customerDistrict.getCommercialHierarchy().getCommercialHierType()
                .setCommercialHierTypeDesc(CommercialHierarchyType.POD.getValue());
        customerDistrict.getCommercialHierarchy().setCrop(crop);
        customerDistrict.getCommercialHierarchy().setCompany(company);
        customerDistrict.setItsDistrict(new ItsDistrict());
        customerDistrict.getItsDistrict().setItsRegion(new ItsRegion());
        customerDistrict.getItsDistrict().getItsRegion().setRegionSapId("region1");
        customerDistrict.getItsDistrict().setDistrictSapId("district1");
        customerDistrict.getItsDistrict().setItsUnity(new ItsUnity());
        customerDistrict.getItsDistrict().getItsUnity().setUnitySapId("unity 1");

        // Create head office
        Customer participant = new Customer("zeca", new Document(new DocumentType("CPF", country, "999.999.999-99"),
                "11122233355"), new Address("st", city, state, country, "1222"), RandomTestData.createRandomLong()
                .toString());
        participant.getDistricts().add(customerDistrict);
        participant.setCustomerSAPCode("sap code");

        // Setup matrix
        Customer matrix = new Customer("maria", new Document(new DocumentType("CPF", country, "999.999.999-99"),
                "44455566677"), new Address("st", city, state, country, "1222"), RandomTestData.createRandomLong()
                .toString());
        matrix.getDistricts().add(customerDistrict);
        matrix.setCustomerSAPCode("sap 111");

        // Setup matrix contract
        Contract contract = new Contract();
        contract.setCompany(company);
        contract.setCrop(crop);
        contract.setContractCode("contract #1");
        contract.setParticipantType(ParticipantTypeEnum.POD);
        contract.setStartDate(CalendarUtil.getDate(2000, 01, 01));
        contract.setEndDate(CalendarUtil.getDate(2100, 01, 01));
        contract.setCustomer(matrix);
        matrix.getContracts().add(contract);

        HeadOffice headoffice = new HeadOffice(participant, matrix, ParticipantTypeEnum.POD, crop, company);

        // Actions
        GroupAction groupActionCalculate = new GroupAction(-1L, GroupAction.GROUP_ACTION_CALCULATE,
                GroupAction.GROUP_ACTION_CALCULATE);
        GroupAction groupActionSum = new GroupAction(-2L, GroupAction.GROUP_ACTION_SUM, GroupAction.GROUP_ACTION_SUM);

        // Frame group
        RolFrameGroup rolFrameGroupFixedOccurr = new RolFrameGroup();
        rolFrameGroupFixedOccurr.setRolFrameGroupCode(RolFrameGroup.FRAME_GROUP_FIXEDCURR);

        RolFrameGroup rolFrameGroupTestStrype = new RolFrameGroup();
        rolFrameGroupTestStrype.setRolFrameGroupCode(RolFrameGroup.FRAME_GROUP_TESTSTRYPE);

        RolFrameGroup rolFrameGroupOldTestStrype = new RolFrameGroup();
        rolFrameGroupOldTestStrype.setRolFrameGroupCode(RolFrameGroup.FRAME_GROUP_FIXEDOLD);

        // Operational year type
        OperationalYearType operationalYearType = new OperationalYearType();
        operationalYearType.setOperationalYearTypeCode("actual");
        operationalYearType.setOperationalYearTypeDiff(-1);

        // Rol parameter rr fixed paid
        RolParameter paramrolFixedOccurrRR = new RolParameter();
        paramrolFixedOccurrRR.setCrop(crop);
        paramrolFixedOccurrRR.setGroupAction(groupActionCalculate);
        paramrolFixedOccurrRR.setOperationalYearType(operationalYearType);
        paramrolFixedOccurrRR.setRolFrameGroup(rolFrameGroupFixedOccurr);
        paramrolFixedOccurrRR.setRolParameterDescription("paramrolFixedOccurr");
        paramrolFixedOccurrRR.setRolParamShownDescription("paramrolFixedOccurr");
        paramrolFixedOccurrRR.setRolParameterMaterialSapId("xxx");
        paramrolFixedOccurrRR.setTechnology(technologyRR);

        // Rol parameter intacta fixed paid
        RolParameter paramrolFixedOccurrIntacta = new RolParameter();
        paramrolFixedOccurrIntacta.setCrop(crop);
        paramrolFixedOccurrIntacta.setGroupAction(groupActionCalculate);
        paramrolFixedOccurrIntacta.setOperationalYearType(operationalYearType);
        paramrolFixedOccurrIntacta.setRolFrameGroup(rolFrameGroupFixedOccurr);
        paramrolFixedOccurrIntacta.setRolParameterDescription("paramrolFixedOccurr");
        paramrolFixedOccurrIntacta.setRolParamShownDescription("paramrolFixedOccurr");
        paramrolFixedOccurrIntacta.setRolParameterMaterialSapId("xxx");
        paramrolFixedOccurrIntacta.setTechnology(technologyIntacta);

        // Rol parameter xpto fixed paid
        RolParameter paramrolFixedOccurrXpto = new RolParameter();
        paramrolFixedOccurrXpto.setCrop(crop);
        paramrolFixedOccurrXpto.setGroupAction(groupActionCalculate);
        paramrolFixedOccurrXpto.setOperationalYearType(operationalYearType);
        paramrolFixedOccurrXpto.setRolFrameGroup(rolFrameGroupFixedOccurr);
        paramrolFixedOccurrXpto.setRolParameterDescription("paramrolFixedOccurr");
        paramrolFixedOccurrXpto.setRolParamShownDescription("paramrolFixedOccurr");
        paramrolFixedOccurrXpto.setRolParameterMaterialSapId("xxx");
        paramrolFixedOccurrXpto.setTechnology(technologyXpto);

        RolParameter paramrolFixedOccurrXpto1 = new RolParameter();
        paramrolFixedOccurrXpto1.setCrop(crop);
        paramrolFixedOccurrXpto1.setGroupAction(groupActionCalculate);
        paramrolFixedOccurrXpto1.setOperationalYearType(operationalYearType);
        paramrolFixedOccurrXpto1.setRolFrameGroup(rolFrameGroupFixedOccurr);
        paramrolFixedOccurrXpto1.setRolParameterDescription("paramrolFixedOccurr1");
        paramrolFixedOccurrXpto1.setRolParamShownDescription("paramrolFixedOccurr1");
        paramrolFixedOccurrXpto1.setRolParameterMaterialSapId("xxx1");
        paramrolFixedOccurrXpto1.setTechnology(technologyXpto);

        // Rol parameter xpto fixed paid
        RolParameter paramrolTestStrypeXpto = new RolParameter();
        paramrolTestStrypeXpto.setCrop(crop);
        paramrolTestStrypeXpto.setGroupAction(groupActionSum);
        paramrolTestStrypeXpto.setOperationalYearType(operationalYearType);
        paramrolTestStrypeXpto.setRolFrameGroup(rolFrameGroupTestStrype);
        paramrolTestStrypeXpto.setRolParameterDescription("paramrolFixedOccurr");
        paramrolTestStrypeXpto.setRolParamShownDescription("paramrolFixedOccurr");
        paramrolTestStrypeXpto.setRolParameterMaterialSapId("xxx");
        paramrolTestStrypeXpto.setTechnology(technologyXpto);
        paramrolTestStrypeXpto.setRolParReqValidStripe(Boolean.TRUE);

        // Rol parameter xpto fixed paid
        RolParameter paramrolTestStrypeXptoOld = new RolParameter();
        paramrolTestStrypeXptoOld.setCrop(crop);
        paramrolTestStrypeXptoOld.setGroupAction(groupActionCalculate);
        paramrolTestStrypeXptoOld.setOperationalYearType(operationalYearType);
        paramrolTestStrypeXptoOld.setRolFrameGroup(rolFrameGroupOldTestStrype);
        paramrolTestStrypeXptoOld.setRolParameterDescription("paramrolFixedOccurr");
        paramrolTestStrypeXptoOld.setRolParamShownDescription("paramrolFixedOccurr");
        paramrolTestStrypeXptoOld.setRolParameterMaterialSapId("xxx");
        paramrolTestStrypeXptoOld.setTechnology(technologyXpto);
        paramrolTestStrypeXptoOld.setRolParReqValidStripe(Boolean.TRUE);

        // Build report
        ReportOnLine reportOnLine = new ReportOnLine();
        reportOnLine.setCrop(crop);
        reportOnLine.setHeadoffice(headoffice);
        reportOnLine.setOperationalYear(operationalYear);
        reportOnLine.setRolCreateDate(new Date());
        reportOnLine.setRolPeriod(new Date());
        reportOnLine.setRolStatus(new RolStatus(0L, RolStatus.ROL_STATUS_REPORTED, "pod.rol.parameter.status.rtv"));
        reportOnLine.setUsedRolParameters(new HashSet<UsedRolParameter>());
        reportOnLine.setItsUserLogin("juquinha");

        // Used param 1 - xpto test strype
        UsedRolParameter u1 = new UsedRolParameter();
        u1.setReportOnLine(reportOnLine);
        u1.setRolParameter(paramrolTestStrypeXpto);
        u1.setUsedRolParameterTonValue(new BigDecimal("1"));
        u1.setUsedRolParamMonetaryVal(new BigDecimal("11"));
        u1.setUsedRolParamStripeValue(111L);
        u1.setCounterPrice(BigDecimal.ONE);
        reportOnLine.getUsedRolParameters().add(u1);

        // Used param 2 -- intacta fixed paid
        UsedRolParameter u2 = new UsedRolParameter();
        u2.setReportOnLine(reportOnLine);
        u2.setRolParameter(paramrolFixedOccurrIntacta);
        u2.setUsedRolParameterTonValue(new BigDecimal("2"));
        u2.setUsedRolParamMonetaryVal(new BigDecimal("22"));
        u2.setUsedRolParamStripeValue(222L);
        u2.setUsedRolParamAverageVal(BigDecimal.ZERO);
        u2.setCounterPrice(new BigDecimal(20.00));
        reportOnLine.getUsedRolParameters().add(u2);

        // Used param 3 - rr fixed paid
        UsedRolParameter u3 = new UsedRolParameter();
        u3.setReportOnLine(reportOnLine);
        u3.setRolParameter(paramrolFixedOccurrRR);
        u3.setUsedRolParameterTonValue(new BigDecimal("3"));
        u3.setUsedRolParamMonetaryVal(new BigDecimal("33"));
        u3.setUsedRolParamStripeValue(333L);
        u3.setUsedRolParamAverageVal(BigDecimal.ONE);
        u3.setCounterPrice(BigDecimal.TEN);
        reportOnLine.getUsedRolParameters().add(u3);

        // Used param 4 - xpto fixed paid
        UsedRolParameter u4 = new UsedRolParameter();
        u4.setReportOnLine(reportOnLine);
        u4.setRolParameter(paramrolFixedOccurrXpto);
        u4.setUsedRolParameterTonValue(new BigDecimal("4"));
        u4.setUsedRolParamMonetaryVal(new BigDecimal("44"));
        u4.setUsedRolParamStripeValue(444L);
        u4.setUsedRolParamAverageVal(new BigDecimal(50.00));
        u4.setCounterPrice(BigDecimal.TEN);
        reportOnLine.getUsedRolParameters().add(u4);

        // Used param 5 - xpto fixed paid
        UsedRolParameter u5 = new UsedRolParameter();
        u5.setReportOnLine(reportOnLine);
        u5.setRolParameter(paramrolFixedOccurrXpto1);
        u5.setUsedRolParameterTonValue(new BigDecimal("5"));
        u5.setUsedRolParamMonetaryVal(new BigDecimal("55"));
        u5.setUsedRolParamStripeValue(555L);
        reportOnLine.getUsedRolParameters().add(u5);

        // Used param 6 - xpto test strype old
        UsedRolParameter u6 = new UsedRolParameter();
        u6.setReportOnLine(reportOnLine);
        u6.setRolParameter(paramrolTestStrypeXptoOld);
        u6.setUsedRolParameterTonValue(new BigDecimal("6"));
        u6.setUsedRolParamMonetaryVal(new BigDecimal("66"));
        u6.setUsedRolParamStripeValue(666L);
        reportOnLine.getUsedRolParameters().add(u6);

        // Create a dto
        ReportOnlineDTO dto = new ReportOnlineDTO(reportOnLine);

        // Create parameters list sorted by technology
        for (UsedRolParameter usedRolParameter : reportOnLine.getUsedRolParameters()) {
            dto.addRolParameterDTO(new RolParameterDTO(usedRolParameter));
        }

        // Build revenue account
        RevenueAccount revenueAccount = new RevenueAccount();
        revenueAccount.setOrderNumber("xxxx");
        revenueAccount.setDocumentNumber("333333");

        dto.setReportLimitDate(new Date());
        dto.setRevenueAccount(revenueAccount);

        reportSource.add(dto);
    	}


    /**
     * @throws NoSuchMethodException
     * @throws IOException
     *
     */
    @Test
    public void test_generate_report() throws NoSuchMethodException, IOException {

        // Warning: keep this parameter like false
        Boolean enableOutputReport = Boolean.FALSE;

        // assembler report
        DetailedReportAssembler reportAssembler = new DetailedReportAssembler(reportSource, resourceBundle, true);
        ByteArrayOutputStream baos = reportAssembler.build();
        Assert.assertNotNull(baos);

        // Check for report header
        validateHeader(baos);

        // Enable output for debug
        if (enableOutputReport) {
            FileOutputStream fos = new FileOutputStream("c:\\junit_report.xls");
            fos.write(baos.toByteArray());
            fos.close();
        }
    }

    /**
     * @throws NoSuchMethodException
     * @throws IOException
     *
     */
    @Test
    public void test_generate_report_billing() throws NoSuchMethodException, IOException {

        // Warning: keep this parameter like false
        Boolean enableOutputReport = Boolean.FALSE;

        // assembler report
        DetailedReportAssembler reportAssembler = new DetailedReportAssembler(reportSource, resourceBundle, true, true);
        ByteArrayOutputStream baos = reportAssembler.build();
        Assert.assertNotNull(baos);

        // Check for report header
        validateHeaderBilling(baos);

        // Enable output for debug
        if (enableOutputReport) {
            FileOutputStream fos = new FileOutputStream("c:\\junit_report_billing.xls");
            fos.write(baos.toByteArray());
            fos.close();
        }
    }

    /**
     * @param outputStream
     * @throws IOException
     */
    private void validateHeader(final ByteArrayOutputStream outputStream) throws IOException {

        // Headers labels to check
        String[] columnsLabels = new String[] { "pod.report.detailed.company.label", "pod.report.detailed.crop.label",
                "pod.report.detailed.technology.label", "pod.report.detailed.period.label",
                "pod.report.detailed.affiliatesapcode.label", "pod.report.detailed.affiliatename.label",
                "pod.report.detailed.affiliatedocument.label", "pod.report.detailed.affiliatecity.label",
                "pod.report.detailed.affiliatestate.label", "pod.report.detailed.affiliateunit.label",
                "pod.report.detailed.affiliateregion.label", "pod.report.detailed.affiliatedistrict.label",
                "pod.report.detailed.matrixsapcode.label", "pod.report.detailed.matrixdocument.label",
                "pod.report.detailed.matrixname.label", "pod.report.detailed.matrixunit.label",
                "pod.report.detailed.matrixregion.label", "pod.report.detailed.matrixdistrict.label",
                "pod.report.detailed.matrixcontract.label", "pod.report.detailed.senddate.label",
                "pod.report.detailed.username.label", "pod.report.detailed.limitdate.label" };

        int column = 0;
        for (String columnLabel : columnsLabels) {
            ReportUtilAssert.assertEqualsCell(outputStream, 0, 0, column++, resourceBundle.getString(columnLabel));
        }

    }

    /**
     * @param outputStream
     * @throws IOException
     */
    private void validateHeaderBilling(final ByteArrayOutputStream outputStream) throws IOException {

        // Headers labels to check
        String[] columnsLabels = new String[] { "pod.report.detailed.company.label", "pod.report.detailed.crop.label",
                "pod.report.detailed.technology.label", "pod.report.detailed.period.label",
                "pod.report.detailed.affiliatesapcode.label", "pod.report.detailed.affiliatename.label",
                "pod.report.detailed.affiliatedocument.label", "pod.report.detailed.affiliatecity.label",
                "pod.report.detailed.affiliatestate.label", "pod.report.detailed.affiliateunit.label",
                "pod.report.detailed.affiliateregion.label", "pod.report.detailed.affiliatedistrict.label",
                "pod.report.detailed.matrixsapcode.label", "pod.report.detailed.matrixdocument.label",
                "pod.report.detailed.matrixname.label", "pod.report.detailed.matrixunit.label",
                "pod.report.detailed.matrixregion.label", "pod.report.detailed.matrixdistrict.label",
                "pod.report.detailed.matrixcontract.label", "pod.report.detailed.senddate.label",
                "pod.report.detailed.username.label", "pod.report.detailed.limitdate.label" };

        int column = 0;
        for (String columnLabel : columnsLabels) {
            ReportUtilAssert.assertEqualsCell(outputStream, 0, 0, column++, resourceBundle.getString(columnLabel));
        }

        // Dynamic labels to check
        columnsLabels = new String[] { "Valor - paramrolFixedOccurr - Safra Atual",
                "Qtde. - paramrolFixedOccurr - Safra Atual", "Pre�o M�dio Calculado (R$)",
                "Pre�o Balc�o - paramrolFixedOccurr", "Varia��o - paramrolFixedOccurr",
                "Valor - paramrolFixedOccurr - Safra Atual", "Qtde. - paramrolFixedOccurr - Safra Atual",
                "Pre�o M�dio Calculado (R$)", "Pre�o Balc�o - paramrolFixedOccurr", "Varia��o - paramrolFixedOccurr",
                "Valor - paramrolFixedOccurr - Safra Atual", "Qtde. - paramrolFixedOccurr - Safra Atual",
                "Pre�o M�dio Calculado (R$)", "Pre�o Balc�o - paramrolFixedOccurr", "Varia��o - paramrolFixedOccurr",
                "Valor - paramrolFixedOccurr1 - Safra Atual", "Qtde. - paramrolFixedOccurr1 - Safra Atual",
                "Pre�o M�dio Calculado (R$)", "Pre�o Balc�o - paramrolFixedOccurr1", "Varia��o - paramrolFixedOccurr1",
                "Valor - paramrolFixedOccurr - Safra Atual -1", "Qtde. - paramrolFixedOccurr - Safra Atual -1",
                "Pre�o M�dio Calculado (R$)", "Pre�o Balc�o - paramrolFixedOccurr - Safra Atual -1",
                "Varia��o - paramrolFixedOccurr - Safra Atual -1", "paramrolFixedOccurr" };

        for (String columnLabel : columnsLabels) {
            ReportUtilAssert.assertEqualsCell(outputStream, 0, 0, column++, columnLabel);
            System.out.println(column + " - " + columnLabel);
        }

        columnsLabels = new String[] { "pod.report.detailed.volumereceivedothers.label",
                "pod.report.detailed.creditconsumptionvalue.label", "pod.report.detailed.billedvolume.label",
                "pod.report.detailed.billedvalue.label", "pod.report.detailed.rolstatus.label",
                "pod.report.detailed.ordernumber.label", "pod.report.detailed.documentnumber.label",
                "pod.report.detailed.billeddate.label", "pod.report.detailed.reversalbilleddocument.label",
                "pod.report.detailed.reversalbilleddate.label",
                "pod.report.detailed.amountvolumefixandpaidbygrower.label",
                "pod.report.detailed.amountvaluefixandpaidBgGrower.label",
                "pod.report.detailed.differencevolumefixandpaidgrower.label",
                "pod.report.detailed.differencevaluefixandpaidgrower.label",
                "pod.report.detailed.disapprovalreasons.label", "pod.report.detailed.approvalexplanations.label",
                "pod.report.billing.allaffiliatesreported.label" };

        for (String columnLabel : columnsLabels) {
            ReportUtilAssert.assertEqualsCell(outputStream, 0, 0, column++, resourceBundle.getString(columnLabel));
        }

    }
}
