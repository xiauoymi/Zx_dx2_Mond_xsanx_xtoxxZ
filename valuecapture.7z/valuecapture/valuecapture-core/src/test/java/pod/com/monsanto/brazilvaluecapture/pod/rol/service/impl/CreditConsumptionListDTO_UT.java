package com.monsanto.brazilvaluecapture.pod.rol.service.impl;

import java.math.BigDecimal;
import java.util.Date;

import junit.framework.Assert;

import org.junit.Before;
import org.junit.Test;

import com.monsanto.brazilvaluecapture.core.base.model.bean.Address;
import com.monsanto.brazilvaluecapture.core.base.model.bean.City;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Company;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Country;
import com.monsanto.brazilvaluecapture.core.base.model.bean.CreditConsumption;
import com.monsanto.brazilvaluecapture.core.base.model.bean.CreditConsumptionStatus;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Crop;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Document;
import com.monsanto.brazilvaluecapture.core.base.model.bean.DocumentType;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Customer;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.HeadOffice;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.ParticipantTypeEnum;
import com.monsanto.brazilvaluecapture.core.grower.CreateTestData;
import com.monsanto.brazilvaluecapture.core.grower.model.bean.Grower;
import com.monsanto.brazilvaluecapture.pod.credit.model.bean.CreditConsumptionListDTO;

public class CreditConsumptionListDTO_UT extends CreateTestData {

    @Before
    public void setup() {
    }

    @Test
    public void createObjectConstructorTest() {

        // Create system data
        CreditConsumptionListDTO dto = new CreditConsumptionListDTO();
        dto.setCreditConsumptionId(1L);
        dto.setCreditConsumptionDate(new Date());
        dto.setCreditConsumptionStatus(CreditConsumptionStatus.OPENED);
        dto.setGrowerDocumentNumberFormatted("123.456.789-00");
        dto.setGrowerName("Andrius");
        dto.setMatrixCity("Nova Odessa");
        dto.setMatrixDocumentNumberFormatted("123.456.789-00");
        dto.setMatrixName("KAAM");
        dto.setPartnerCity("Americiana");
        dto.setPartnerDocumentNumberFormatted("123.456.789-00");
        dto.setPartnerName("Bunge");
        dto.setVolume(new BigDecimal(10));

        testAssert(dto);
    }

    @Test
    public void createObjectConstructorTest_based_on_credit_consumption() {

        Document document = new Document();
        document.setDocumentType(new DocumentType("CPF", new Country(), "999.999.999-99"));
        document.setValue("12345678900");

        City city = new City();
        city.setDescription("Cidade");
        Address address = new Address();
        address.setCity(city);
        
        CreditConsumption cc = new CreditConsumption();
        cc.setId(1L);
        cc.setCreditConsumptionStatus(CreditConsumptionStatus.PROCESSED);
        cc.setCreditConsumptionDate(new Date());

        Grower grower = new Grower();
        grower.setName("Henrique");
        grower.setDocument(document);
        cc.setGrower(grower);
        
        Customer customerMatrix = new Customer("Matrix", document, address, "123345");
        Customer customerPartner = new Customer("Partner", document, address, "123345");
        HeadOffice ho = new HeadOffice(customerMatrix, customerPartner, ParticipantTypeEnum.COLLABORATOR, new Crop(),
                new Company());
        
        cc.setHeadoffice(ho);

        CreditConsumptionListDTO dto = new CreditConsumptionListDTO(cc);
        testAssert(dto);
    }
        
    /**
     * Validating of grower
     * 
     * @param grower
     */
    void testAssert(CreditConsumptionListDTO dto) {

        Assert.assertNotNull(dto);
        Assert.assertNotNull(dto.getGrowerDocumentNumberFormatted());
        Assert.assertNotNull(dto.getGrowerName());
        Assert.assertNotNull(dto.getMatrixCity());
        Assert.assertNotNull(dto.getMatrixDocumentNumberFormatted());
        Assert.assertNotNull(dto.getMatrixName());
        Assert.assertNotNull(dto.getPartnerCity());
        Assert.assertNotNull(dto.getPartnerDocumentNumberFormatted());
        Assert.assertNotNull(dto.getPartnerName());
        Assert.assertNotNull(dto.getCreditConsumptionDate());
        Assert.assertNotNull(dto.getCreditConsumptionId());
        Assert.assertNotNull(dto.getCreditConsumptionStatus());
        Assert.assertNotNull(dto.getVolume());
    }
}
