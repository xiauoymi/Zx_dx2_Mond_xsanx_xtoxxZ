package com.monsanto.brazilvaluecapture.pod.rol.service.impl;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Matchers;
import org.mockito.Mockito;

import com.monsanto.brazilvaluecapture.core.base.model.bean.Company;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Country;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Crop;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Document;
import com.monsanto.brazilvaluecapture.core.base.model.bean.DocumentType;
import com.monsanto.brazilvaluecapture.core.base.model.bean.OperationalYear;
import com.monsanto.brazilvaluecapture.core.base.model.bean.VolumeAndValueDTO;
import com.monsanto.brazilvaluecapture.core.commercialhierarchy.model.bean.ItsDistrict;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Contract;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Customer;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.HeadOffice;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.ParticipantTypeEnum;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Technology;
import com.monsanto.brazilvaluecapture.core.customer.service.AffiliateNotEnableForReportException;
import com.monsanto.brazilvaluecapture.core.customer.service.AffiliateNotInVigorException;
import com.monsanto.brazilvaluecapture.core.customer.service.ContractNotFoundException;
import com.monsanto.brazilvaluecapture.core.customer.service.CustomerNotFoundException;
import com.monsanto.brazilvaluecapture.core.customer.service.ParticipantService;
import com.monsanto.brazilvaluecapture.core.foundation.model.bean.StatusEnum;
import com.monsanto.brazilvaluecapture.core.foundation.service.BusinessException;
import com.monsanto.brazilvaluecapture.core.foundation.service.EntityNotFoundException;
import com.monsanto.brazilvaluecapture.core.foundation.util.CalendarUtil;
import com.monsanto.brazilvaluecapture.core.foundation.util.ConstraintViolation;
import com.monsanto.brazilvaluecapture.core.revenue.model.bean.RevenueAccount;
import com.monsanto.brazilvaluecapture.core.revenue.model.bean.RevenueType;
import com.monsanto.brazilvaluecapture.core.revenue.service.RevenueService;
import com.monsanto.brazilvaluecapture.core.user.model.bean.ItsUser;
import com.monsanto.brazilvaluecapture.core.user.model.bean.ItsUser.UserTypeEnum;
import com.monsanto.brazilvaluecapture.core.user.model.bean.UserContract;
import com.monsanto.brazilvaluecapture.pod.credit.service.CreditService;
import com.monsanto.brazilvaluecapture.pod.credit.service.OtherRolValueFilter;
import com.monsanto.brazilvaluecapture.pod.rol.model.bean.GroupAction;
import com.monsanto.brazilvaluecapture.pod.rol.model.bean.HeadOfficeDetail;
import com.monsanto.brazilvaluecapture.pod.rol.model.bean.HeadOfficeEffectiveDate;
import com.monsanto.brazilvaluecapture.pod.rol.model.bean.OperationalYearType;
import com.monsanto.brazilvaluecapture.pod.rol.model.bean.PaidVolByGrowerItem;
import com.monsanto.brazilvaluecapture.pod.rol.model.bean.PaidVolumeByGrower;
import com.monsanto.brazilvaluecapture.pod.rol.model.bean.PodCalendar;
import com.monsanto.brazilvaluecapture.pod.rol.model.bean.ReportOnLine;
import com.monsanto.brazilvaluecapture.pod.rol.model.bean.ReportOnlineDTO;
import com.monsanto.brazilvaluecapture.pod.rol.model.bean.RolConfiguration;
import com.monsanto.brazilvaluecapture.pod.rol.model.bean.RolFrameGroup;
import com.monsanto.brazilvaluecapture.pod.rol.model.bean.RolParameter;
import com.monsanto.brazilvaluecapture.pod.rol.model.bean.RolStatus;
import com.monsanto.brazilvaluecapture.pod.rol.model.bean.TechnologyROL;
import com.monsanto.brazilvaluecapture.pod.rol.model.bean.UsedRolParameter;
import com.monsanto.brazilvaluecapture.pod.rol.model.dao.CounterPriceDAO;
import com.monsanto.brazilvaluecapture.pod.rol.model.dao.ReportOnlineDAO;
import com.monsanto.brazilvaluecapture.pod.rol.model.dao.ValueOfChrgByTonDAO;
import com.monsanto.brazilvaluecapture.pod.rol.model.service.BilledRolFoundForMatrixException;
import com.monsanto.brazilvaluecapture.pod.rol.model.service.OtherReportOnLineService;
import com.monsanto.brazilvaluecapture.pod.rol.model.service.PaidVolumeFilter;
import com.monsanto.brazilvaluecapture.pod.rol.model.service.PodCalendarService;
import com.monsanto.brazilvaluecapture.pod.rol.model.service.ReportOnLineByGrowerService;
import com.monsanto.brazilvaluecapture.pod.rol.model.service.ReportOnLineConstraintException;
import com.monsanto.brazilvaluecapture.pod.rol.model.service.ReportOnLineFilter;
import com.monsanto.brazilvaluecapture.pod.rol.model.service.ReportOnlineException;
import com.monsanto.brazilvaluecapture.pod.rol.model.service.RolConfigurationService;
import com.monsanto.brazilvaluecapture.pod.rol.model.service.UsedRolParametersSpecification;
import com.monsanto.brazilvaluecapture.pod.rol.model.service.impl.ReportOnLineServiceImpl;
import com.monsanto.brazilvaluecapture.pod.rol.model.service.impl.RolInformationServiceImpl;

/**
 * @author cmiranda
 * 
 */
public class ReportOnLineService_UT {

    /**
     * Services to be tested
     */
    private ReportOnLineServiceImpl reportOnLineService = new ReportOnLineServiceImpl();
    private RolInformationServiceImpl rolInformationServiceImpl = new RolInformationServiceImpl();

    // Services
    private CreditService creditService;
    private OtherReportOnLineService otherReportOnLineService;
    private ReportOnLineByGrowerService reportOnLineByGrowerService;
    private ReportOnlineDAO reportOnlineDAO;
    private ParticipantService participantService;
    private PodCalendarService podCalendarService;
    private RevenueService revenueService;
    
    private Crop crop;
    private Company company;
    private Technology technologyRR;
    private Technology technologyIntacta;
    private Technology technologyXpto;
    private HeadOffice headoffice;
    private ReportOnLine reportOnLine;
    private OperationalYear operationalYear;

    private BigDecimal expectedGreaterVariation;

    private ReportOnLineFilter filter;

    @Before
    public void setup() throws EntityNotFoundException {

        // Mock credit service
        creditService = Mockito.mock(CreditService.class);
        reportOnLineService.setCreditService(creditService);

        participantService = Mockito.mock(ParticipantService.class);
        reportOnLineService.setParticipantService(participantService);
        rolInformationServiceImpl.setParticipantService(participantService);

        otherReportOnLineService = Mockito.mock(OtherReportOnLineService.class);
        reportOnLineService.setOtherReportOnLineService(otherReportOnLineService);

        CounterPriceDAO counterPriceDAO = Mockito.mock(CounterPriceDAO.class);
        reportOnLineService.setRolInformationService(rolInformationServiceImpl);
        rolInformationServiceImpl.setcounterPriceDAO(counterPriceDAO);

        reportOnLineByGrowerService = Mockito.mock(ReportOnLineByGrowerService.class);
        reportOnLineService.setReportOnLineByGrowerService(reportOnLineByGrowerService);
        rolInformationServiceImpl.setReportOnLineService(reportOnLineService);

        reportOnlineDAO = Mockito.mock(ReportOnlineDAO.class);
        reportOnLineService.setReportOnlineDAO(reportOnlineDAO);
        reportOnLineService.setRolDao(reportOnlineDAO);

        rolInformationServiceImpl.setReportOnlineDAO(reportOnlineDAO);

        ValueOfChrgByTonDAO valueOfChrgByTonDAO = Mockito.mock(ValueOfChrgByTonDAO.class);
        rolInformationServiceImpl.setValueOfChrgByTonDAO(valueOfChrgByTonDAO);

        podCalendarService = Mockito.mock(PodCalendarService.class);
        reportOnLineService.setPodCalendarService(podCalendarService);

        revenueService = Mockito.mock(RevenueService.class);
        reportOnLineService.setRevenueService(revenueService);

        // Build report
        buildReportOnline();

        // Mock credit consumption sum
        Mockito.when(creditService.selectSumCreditConsumptionByRol(reportOnLine, Boolean.TRUE, technologyIntacta))
                .thenReturn(new BigDecimal("1"));
        Mockito.when(creditService.selectSumCreditConsumptionByRol(reportOnLine, Boolean.TRUE, technologyRR))
                .thenReturn(new BigDecimal("1"));
        Mockito.when(creditService.selectSumCreditConsumptionByRol(reportOnLine, Boolean.TRUE, technologyXpto))
                .thenReturn(new BigDecimal("1"));

        // Mock sum of others
        Mockito.when(otherReportOnLineService.summarizeOtherReportOnlineByFilter((OtherRolValueFilter) Matchers.any()))
                .thenReturn(new BigDecimal("1"));

        // Mock for pod calendar
        Mockito.when(
                podCalendarService.selectPodCalendar((OperationalYear) Matchers.anyObject(),
                        (Company) Matchers.anyObject(), (Crop) Matchers.anyObject(), Matchers.anyInt())).thenReturn(
                new PodCalendar(crop, operationalYear, company, new Long(1).byteValue()));

        HeadOffice headOffice = Mockito.mock(HeadOffice.class);
        Mockito.when(participantService.findHeadOfficeById(Matchers.anyLong())).thenReturn(headOffice);

        Mockito.when(headOffice.checkVigor((Date) Matchers.anyObject())).thenReturn(Boolean.TRUE);
        Mockito.when(headOffice.enableRolReport()).thenReturn(Boolean.TRUE);

        expectedGreaterVariation = new BigDecimal(0);
        filter = new ReportOnLineFilter();
        RolConfigurationService rolConfigurationServiceMock = Mockito.mock(RolConfigurationService.class);
        RolConfiguration rolConfig = new RolConfiguration();
        rolConfig.setMaximumVariationPrice(BigDecimal.TEN);
        Mockito.when(rolConfigurationServiceMock.selectRolConfiguration(crop, company)).thenReturn(rolConfig);
        reportOnLineService.setRolConfigurationService(rolConfigurationServiceMock);
        filter.setCrop(crop);
        filter.setCompany(company);

        // Mock search volume to be fixed
        Mockito.when(
                reportOnlineDAO.sumVolumeByFilter((Customer) Matchers.anyObject(), (Customer) Matchers.anyObject(),
                        (Crop) Matchers.anyObject(), (Company) Matchers.anyObject(),
                        (OperationalYear) Matchers.anyObject(), (Date) Matchers.anyObject(),
                        (Technology) Matchers.anyObject(), Matchers.anyString())).thenReturn(BigDecimal.ONE);

        Mockito.when(
                creditService.selectSumCreditConsumptionByRolInYear((ReportOnLine) Matchers.anyObject(),
                        Matchers.anyBoolean(), (Technology) Matchers.anyObject())).thenReturn(BigDecimal.ONE);

        VolumeAndValueDTO vavDTO = new VolumeAndValueDTO();
        vavDTO.setValue(BigDecimal.ONE);
        vavDTO.setVolume(BigDecimal.ONE);
        Mockito.when(
                reportOnLineByGrowerService.sumVolumeAndValueFromPaidVolumeByGrowerByFilter(Matchers
                        .any(PaidVolumeFilter.class))).thenReturn(vavDTO);
    }

    /**
     * Build report online
     */
    private void buildReportOnline() {

        // Create system data
        Country country = new Country("USA", "usa");
        company = new Company("monsanto");
        crop = new Crop("soya", company, country);
        technologyRR = new Technology("rr", company);
        technologyIntacta = new Technology("intact", company);
        technologyXpto = new Technology("xpto", company);
        operationalYear = new OperationalYear("2012");

        // Create head office
        Customer participant = new Customer("zeca", new Document(new DocumentType("", country, "99999"), "123"), null,
                "sap code");
        Customer matrix = new Customer("maria", null, null, "sap code");

        Contract contract = new Contract();
        contract.setCompany(company);
        contract.setContractCode("xpto");
        contract.setCrop(crop);
        contract.setCustomer(matrix);
        contract.setStartDate(new Date());
        contract.setEndDate(new Date());
        contract.setParticipantType(ParticipantTypeEnum.POD);
        matrix.getContracts().add(contract);
        headoffice = new HeadOffice(participant, matrix, ParticipantTypeEnum.POD, crop, company);

        HeadOfficeDetail headOfficeDetail = new HeadOfficeDetail();
        headOfficeDetail.setHeadoffice(headoffice);
        headOfficeDetail.setReportRol(Boolean.TRUE);
        headOfficeDetail.setShowParticipantInList(Boolean.FALSE);
        headoffice.setHeadOfficeDetail(headOfficeDetail);

        HeadOfficeEffectiveDate headOfficeEffectiveDate = new HeadOfficeEffectiveDate();
        headOfficeEffectiveDate.setInitDate(CalendarUtil.getDate(1500, Calendar.JANUARY, 1));
        headOfficeEffectiveDate.setEndDate(new Date());
        headOfficeEffectiveDate.setHeadOfficeDetail(headOfficeDetail);
        headOfficeDetail.getHeadOfficeEffectiveDates().add(headOfficeEffectiveDate);

        // Actions
        GroupAction groupActionCalculate = new GroupAction(-1L, GroupAction.GROUP_ACTION_CALCULATE,
                GroupAction.GROUP_ACTION_CALCULATE);
        GroupAction groupActionSum = new GroupAction(-2L, GroupAction.GROUP_ACTION_SUM, GroupAction.GROUP_ACTION_SUM);

        // Frame group
        RolFrameGroup rolFrameGroupFixedOccurr = new RolFrameGroup();
        rolFrameGroupFixedOccurr.setRolFrameGroupCode(RolFrameGroup.FRAME_GROUP_FIXEDCURR);

        RolFrameGroup rolFrameGroupTestStrype = new RolFrameGroup();
        rolFrameGroupTestStrype.setRolFrameGroupCode(RolFrameGroup.FRAME_GROUP_TESTSTRYPE);

        RolFrameGroup rolFrameGroupOldTestStrype = new RolFrameGroup();
        rolFrameGroupOldTestStrype.setRolFrameGroupCode(RolFrameGroup.FRAME_GROUP_FIXEDOLD);

        // Operational year type
        OperationalYearType operationalYearType = new OperationalYearType();
        operationalYearType.setOperationalYearTypeCode("actual");
        operationalYearType.setOperationalYearTypeDiff(0);

        // Rol parameter rr fixed paid
        RolParameter paramrolFixedOccurrRR = new RolParameter();
        paramrolFixedOccurrRR.setCrop(crop);
        paramrolFixedOccurrRR.setGroupAction(groupActionCalculate);
        paramrolFixedOccurrRR.setOperationalYearType(operationalYearType);
        paramrolFixedOccurrRR.setRolFrameGroup(rolFrameGroupFixedOccurr);
        paramrolFixedOccurrRR.setRolParameterDescription("paramrolFixedOccurr");
        paramrolFixedOccurrRR.setRolParameterMaterialSapId("xxx");
        paramrolFixedOccurrRR.setTechnology(technologyRR);

        // Rol parameter intacta fixed paid
        RolParameter paramrolFixedOccurrIntacta = new RolParameter();
        paramrolFixedOccurrIntacta.setCrop(crop);
        paramrolFixedOccurrIntacta.setGroupAction(groupActionCalculate);
        paramrolFixedOccurrIntacta.setOperationalYearType(operationalYearType);
        paramrolFixedOccurrIntacta.setRolFrameGroup(rolFrameGroupFixedOccurr);
        paramrolFixedOccurrIntacta.setRolParameterDescription("paramrolFixedOccurr");
        paramrolFixedOccurrIntacta.setRolParameterMaterialSapId("xxx");
        paramrolFixedOccurrIntacta.setTechnology(technologyIntacta);

        // Rol parameter xpto fixed paid
        RolParameter paramrolFixedOccurrXpto = new RolParameter();
        paramrolFixedOccurrXpto.setCrop(crop);
        paramrolFixedOccurrXpto.setGroupAction(groupActionCalculate);
        paramrolFixedOccurrXpto.setOperationalYearType(operationalYearType);
        paramrolFixedOccurrXpto.setRolFrameGroup(rolFrameGroupFixedOccurr);
        paramrolFixedOccurrXpto.setRolParameterDescription("paramrolFixedOccurr");
        paramrolFixedOccurrXpto.setRolParameterMaterialSapId("xxx");
        paramrolFixedOccurrXpto.setTechnology(technologyXpto);

        RolParameter paramrolFixedOccurrXpto1 = new RolParameter();
        paramrolFixedOccurrXpto1.setCrop(crop);
        paramrolFixedOccurrXpto1.setGroupAction(groupActionCalculate);
        paramrolFixedOccurrXpto1.setOperationalYearType(operationalYearType);
        paramrolFixedOccurrXpto1.setRolFrameGroup(rolFrameGroupFixedOccurr);
        paramrolFixedOccurrXpto1.setRolParameterDescription("paramrolFixedOccurr1");
        paramrolFixedOccurrXpto1.setRolParameterMaterialSapId("xxx1");
        paramrolFixedOccurrXpto1.setTechnology(technologyXpto);

        // Rol parameter xpto fixed paid
        RolParameter paramrolTestStrypeXpto = new RolParameter();
        paramrolTestStrypeXpto.setCrop(crop);
        paramrolTestStrypeXpto.setGroupAction(groupActionSum);
        paramrolTestStrypeXpto.setOperationalYearType(operationalYearType);
        paramrolTestStrypeXpto.setRolFrameGroup(rolFrameGroupTestStrype);
        paramrolTestStrypeXpto.setRolParameterDescription("paramrolFixedOccurr");
        paramrolTestStrypeXpto.setRolParameterMaterialSapId("xxx");
        paramrolTestStrypeXpto.setTechnology(technologyXpto);
        paramrolTestStrypeXpto.setRolParReqValidStripe(Boolean.TRUE);

        // Rol parameter xpto fixed paid
        RolParameter paramrolTestStrypeXptoOld = new RolParameter();
        paramrolTestStrypeXptoOld.setCrop(crop);
        paramrolTestStrypeXptoOld.setGroupAction(groupActionCalculate);
        paramrolTestStrypeXptoOld.setOperationalYearType(operationalYearType);
        paramrolTestStrypeXptoOld.setRolFrameGroup(rolFrameGroupOldTestStrype);
        paramrolTestStrypeXptoOld.setRolParameterDescription("paramrolFixedOccurr");
        paramrolTestStrypeXptoOld.setRolParameterMaterialSapId("xxx");
        paramrolTestStrypeXptoOld.setTechnology(technologyXpto);
        paramrolTestStrypeXptoOld.setRolParReqValidStripe(Boolean.TRUE);

        // Build report
        reportOnLine = new ReportOnLine();
        reportOnLine.setCrop(crop);
        reportOnLine.setHeadoffice(headoffice);
        reportOnLine.setOperationalYear(operationalYear);
        reportOnLine.setRolCreateDate(new Date());
        reportOnLine.setRolPeriod(new Date());
        reportOnLine.setRolStatus(new RolStatus(0L, RolStatus.ROL_STATUS_REPORTED, null));
        reportOnLine.setUsedRolParameters(new HashSet<UsedRolParameter>());

        // Used param 1 - xpto test strype
        UsedRolParameter u1 = new UsedRolParameter();
        u1.setReportOnLine(reportOnLine);
        u1.setRolParameter(paramrolTestStrypeXpto);
        u1.setUsedRolParameterTonValue(new BigDecimal("1"));
        u1.setUsedRolParamMonetaryVal(new BigDecimal("11"));
        u1.setUsedRolParamStripeValue(111L);
        u1.setCounterPrice(BigDecimal.ONE);
        reportOnLine.getUsedRolParameters().add(u1);

        // Used param 2 -- intacta fixed paid
        UsedRolParameter u2 = new UsedRolParameter();
        u2.setReportOnLine(reportOnLine);
        u2.setRolParameter(paramrolFixedOccurrIntacta);
        u2.setUsedRolParameterTonValue(new BigDecimal("2"));
        u2.setUsedRolParamMonetaryVal(new BigDecimal("22"));
        u2.setUsedRolParamStripeValue(222L);
        u2.setUsedRolParamAverageVal(BigDecimal.ZERO);
        u2.setCounterPrice(new BigDecimal(20.00));
        reportOnLine.getUsedRolParameters().add(u2);

        // Used param 3 - rr fixed paid
        UsedRolParameter u3 = new UsedRolParameter();
        u3.setReportOnLine(reportOnLine);
        u3.setRolParameter(paramrolFixedOccurrRR);
        u3.setUsedRolParameterTonValue(new BigDecimal("3"));
        u3.setUsedRolParamMonetaryVal(new BigDecimal("33"));
        u3.setUsedRolParamStripeValue(333L);
        u3.setUsedRolParamAverageVal(BigDecimal.ONE);
        u3.setCounterPrice(BigDecimal.TEN);
        reportOnLine.getUsedRolParameters().add(u3);

        // Used param 4 - xpto fixed paid
        UsedRolParameter u4 = new UsedRolParameter();
        u4.setReportOnLine(reportOnLine);
        u4.setRolParameter(paramrolFixedOccurrXpto);
        u4.setUsedRolParameterTonValue(new BigDecimal("4"));
        u4.setUsedRolParamMonetaryVal(new BigDecimal("44"));
        u4.setUsedRolParamStripeValue(444L);
        u4.setUsedRolParamAverageVal(new BigDecimal(50.00));
        u4.setCounterPrice(BigDecimal.TEN);
        reportOnLine.getUsedRolParameters().add(u4);

        // Used param 5 - xpto fixed paid
        UsedRolParameter u5 = new UsedRolParameter();
        u5.setReportOnLine(reportOnLine);
        u5.setRolParameter(paramrolFixedOccurrXpto1);
        u5.setUsedRolParameterTonValue(new BigDecimal("5"));
        u5.setUsedRolParamMonetaryVal(new BigDecimal("55"));
        u5.setUsedRolParamStripeValue(555L);
        reportOnLine.getUsedRolParameters().add(u5);

        // Used param 6 - xpto test strype old
        UsedRolParameter u6 = new UsedRolParameter();
        u6.setReportOnLine(reportOnLine);
        u6.setRolParameter(paramrolTestStrypeXptoOld);
        u6.setUsedRolParameterTonValue(new BigDecimal("6"));
        u6.setUsedRolParamMonetaryVal(new BigDecimal("66"));
        u6.setUsedRolParamStripeValue(666L);
        reportOnLine.getUsedRolParameters().add(u6);

        // itsUser
        ItsUser itsUser = new ItsUser("_root_", UserTypeEnum.SUPER);
        itsUser.setId(new Long(999));
        itsUser.setDocument("123456");
        itsUser.setEmail("j@j.com");
        itsUser.setFullName("first last");
        itsUser.setStatus(StatusEnum.ACTIVE);
        reportOnLine.setItsUserLogin(itsUser.getLogin());
    }

    /**
     * Test converting process to build dto by report online.
     * 
     * @throws ContractNotFoundException
     */
    @Test
    public void test_convert_rol_to_dto() throws BusinessException {

        // Build dto
        ReportOnlineDTO dto = reportOnLineService.convertReportOnlineToReportOnlineDTO(reportOnLine);

        Assert.assertNotNull("Expected a non-null converted dto.", dto);
        Assert.assertEquals("Expected 3 techonologies in list.", 3, dto.getListTechRol().size());

        // Check tech's
        for (TechnologyROL tec : dto.getListTechRol()) {

            Technology technology = tec.getTechnology();

            if (!technology.equals(technologyXpto) && !technology.equals(technologyIntacta)
                    && !technology.equals(technologyRR)) {
                Assert.fail("Invalid technology in list");
            } else {

                if (technology.equals(technologyXpto)) {
                    Assert.assertTrue("Expected 2 itens on fixed paid list.",
                            tec.getListVolumeFixedPaidActual().size() == 2);
                }

                if (technology.equals(technologyIntacta)) {
                    Assert.assertTrue("Expected 1 itens on fixed paid list.",
                            tec.getListVolumeFixedPaidActual().size() == 1);
                }

                if (technology.equals(technologyRR)) {
                    Assert.assertTrue("Expected 1 itens on fixed paid list.",
                            tec.getListVolumeFixedPaidActual().size() == 1);
                }

            }
        }

    }

    /**
     * @throws BusinessException
     * @throws ReportOnLineConstraintException
     */
    @Test
    public void test_send_rol_check_without_parameters() throws BusinessException {

        // Set mock
        Mockito.when(reportOnlineDAO.findRolStatusByCode(Matchers.anyString())).thenReturn(null);
        RolConfigurationService rolConfigurationService = Mockito.mock(RolConfigurationService.class);
        
        Mockito.when(rolConfigurationService.getRolLowerLimiteDate((Crop) Mockito.anyObject(), 
                (Company) Mockito.anyObject())).thenReturn(CalendarUtil.getDate(2008, 07));
        
        reportOnLine.setRolPeriod(CalendarUtil.getDate(2013, 01));
        
        // Clear all used report online parameter values
        reportOnLine.clear();

        try {

            reportOnLineService.setRolConfigurationService(rolConfigurationService);
           
            reportOnLineService.sendReportOnline(reportOnLine, null);
            Assert.assertTrue("Not expected exception.", true);

        } catch (ReportOnLineConstraintException e) {
            Assert.assertFalse(!e.getViolations().isEmpty());
        }
    }

    @Test
    public void test_send_rol_missing_all_param() throws ReportOnLineConstraintException, ReportOnlineException,
            AffiliateNotInVigorException, AffiliateNotEnableForReportException {

        // Set mock
        Mockito.when(reportOnlineDAO.findRolStatusByCode(Matchers.anyString())).thenReturn(null);

        // Clear all used rol parameter values
        reportOnLine.clear();

        UsedRolParametersSpecification specif = new UsedRolParametersSpecification(reportOnLineByGrowerService);
        Assert.assertTrue(specif.isSatisfiedBy(reportOnLine));
    }

    /**
     * @throws BusinessException
     * @throws ReportOnLineConstraintException
     */
    @Test
    public void test_send_rol_check_royalt_constraints() throws BusinessException {

        // Set mock
        Mockito.when(reportOnlineDAO.findRolStatusByCode(Matchers.anyString())).thenReturn(null);
        RolConfigurationService rolConfigurationService = Mockito.mock(RolConfigurationService.class);
        
        Mockito.when(rolConfigurationService.getRolLowerLimiteDate((Crop) Mockito.anyObject(), 
                (Company) Mockito.anyObject())).thenReturn(CalendarUtil.getDate(2008, 07));
        
        reportOnLine.setRolPeriod(CalendarUtil.getDate(2013, 01));
        
        for (UsedRolParameter param : reportOnLine.getUsedRolParameters()) {

            if (RolFrameGroup.FRAME_GROUP_FIXEDCURR.equals(param.getRolParameter().getRolFrameGroup()
                    .getRolFrameGroupCode())) {
                param.setUsedRolParamMonetaryVal(new BigDecimal("1.00"));
                param.getRolParameter().setRolParTransChrgRoyHopper(Boolean.TRUE);
                param.getRolParameter().setRolParChrgRoyHopperPct(new BigDecimal("1.99"));
                param.setUsedRolParameterTonValue(null);
            }
        }

        try {
            
            reportOnLineService.setRolConfigurationService(rolConfigurationService);
            
            reportOnLineService.sendReportOnline(reportOnLine, null);
            Assert.fail("Expected exception.");

        } catch (ReportOnLineConstraintException e) {
            Assert.assertFalse(e.getViolations().isEmpty());

            boolean constraintFound = false;
            for (ConstraintViolation constraint : e.getViolations()) {
                if (ReportOnLineConstraintException.JUST_ONE_VALUE_INFORMED_PARAM_CODE.equals(constraint.getCode())) {
                    constraintFound = true;
                }
            }

            Assert.assertTrue("Just one value informed constraint found.", constraintFound);

        }
    }

    /**
     * @throws BusinessException
     * @throws ReportOnLineConstraintException
     */
    @Test
    public void test_send_rol_check_royalt_zero_constraints() throws BusinessException {

        // Set mock
        Mockito.when(reportOnlineDAO.findRolStatusByCode(Matchers.anyString())).thenReturn(null);

        for (UsedRolParameter param : reportOnLine.getUsedRolParameters()) {

            if (RolFrameGroup.FRAME_GROUP_FIXEDCURR.equals(param.getRolParameter().getRolFrameGroup()
                    .getRolFrameGroupCode())) {
                param.setUsedRolParamMonetaryVal(new BigDecimal("1.00"));
                param.getRolParameter().setRolParChrgRoyHopperPct(new BigDecimal("1.99"));
                param.getRolParameter().setRolParTransChrgRoyHopper(Boolean.TRUE);
                param.setUsedRolParameterTonValue(BigDecimal.ZERO);

            }

        }

        try {

            RolConfigurationService rolConfigurationService = Mockito.mock(RolConfigurationService.class);
            Mockito.when(rolConfigurationService.getRolLowerLimiteDate((Crop) Mockito.anyObject(), 
                    (Company) Mockito.anyObject())).thenReturn(CalendarUtil.getDate(2008, 07));
            
            reportOnLine.setRolPeriod(CalendarUtil.getDate(2013, 01));
            reportOnLineService.setRolConfigurationService(rolConfigurationService);
            
            reportOnLineService.sendReportOnline(reportOnLine, null);
            Assert.fail("Expected exception.");

        } catch (ReportOnLineConstraintException e) {
            Assert.assertFalse(e.getViolations().isEmpty());

            boolean constraintFound = false;
            for (ConstraintViolation constraint : e.getViolations()) {
                if (ReportOnLineConstraintException.JUST_ONE_VALUE_INFORMED_PARAM_CODE.equals(constraint.getCode())) {
                    constraintFound = true;
                }
            }

            Assert.assertTrue("Required constraint not found.", constraintFound);

        }

    }

    /**
     * @throws BusinessException
     * @throws ReportOnLineConstraintException
     */
    @Test
    public void test_send_rol_check_royalt_old_zero_constraints() throws BusinessException {

        // Set mock
        Mockito.when(reportOnlineDAO.findRolStatusByCode(Matchers.anyString())).thenReturn(null);
        RolConfigurationService rolConfigurationService = Mockito.mock(RolConfigurationService.class);
        
        Mockito.when(rolConfigurationService.getRolLowerLimiteDate((Crop) Mockito.anyObject(), 
                (Company) Mockito.anyObject())).thenReturn(CalendarUtil.getDate(2008, 07));
        
        for (UsedRolParameter param : reportOnLine.getUsedRolParameters()) {

            if (RolFrameGroup.FRAME_GROUP_FIXEDOLD.equals(param.getRolParameter().getRolFrameGroup()
                    .getRolFrameGroupCode())) {
                param.setUsedRolParamMonetaryVal(new BigDecimal("0.01"));
                param.getRolParameter().setRolParChrgRoyHopperPct(new BigDecimal("1.99"));
                param.getRolParameter().setRolParTransChrgRoyHopper(Boolean.TRUE);
                param.setUsedRolParameterTonValue(BigDecimal.ZERO);

            }

        }

        try {
            
            reportOnLine.setRolPeriod(CalendarUtil.getDate(2013, 01));
            reportOnLineService.sendReportOnline(reportOnLine, null);
            Assert.fail("Expected exception.");

        } catch (ReportOnLineConstraintException e) {
            Assert.assertFalse(e.getViolations().isEmpty());

            boolean constraintFound = false;
            for (ConstraintViolation constraint : e.getViolations()) {
                if (ReportOnLineConstraintException.JUST_ONE_VALUE_INFORMED_PARAM_CODE.equals(constraint.getCode())) {
                    constraintFound = true;
                }
            }

            Assert.assertTrue("Required constraint not found.", constraintFound);

        }

    }

    /**
     * @throws ReportOnLineConstraintException
     * @throws BusinessException
     */
    @Test
    public void test_send_rol_with_sucess() throws ReportOnLineConstraintException, BusinessException {

        // Set mock
        Mockito.when(reportOnlineDAO.findRolStatusByCode(Matchers.anyString())).thenReturn(null);

        RolConfigurationService rolConfigurationService = Mockito.mock(RolConfigurationService.class);
        
        Mockito.when(rolConfigurationService.getRolLowerLimiteDate((Crop) Mockito.anyObject(), 
                (Company) Mockito.anyObject())).thenReturn(CalendarUtil.getDate(2008, 07));
        
        reportOnLine.setRolPeriod(CalendarUtil.getDate(2013, 01));
        reportOnLineService.setRolConfigurationService(rolConfigurationService);
        reportOnLineService.sendReportOnline(reportOnLine, null);

    }

    /**
     * @throws ContractNotFoundException
     */
    @Test
    public void test_replace_used_rol_parameter_replace_for_zero() throws BusinessException {

        // Build dto
        ReportOnlineDTO dto = reportOnLineService.convertReportOnlineToReportOnlineDTO(reportOnLine);
        Assert.assertNotNull("Expected a non-null converted dto.", dto);

        // Check if dont have any zero parameter
        for (UsedRolParameter usedParam : dto.getReportOnline().getUsedRolParameters()) {
            Assert.assertFalse("Expected non zero for ton param.",
                    BigDecimal.ZERO.equals(usedParam.getUsedRolParameterTonValue()));
            Assert.assertFalse("Expected non zero for monetary param.",
                    BigDecimal.ZERO.equals(usedParam.getUsedRolParamMonetaryVal()));
            Assert.assertFalse("Expected non zero for stripe values.",
                    new Long("0").equals(usedParam.getUsedRolParamStripeValue()));
        }

        // Set zero to all parameters
        for (UsedRolParameter usedParam : dto.getReportOnline().getUsedRolParameters()) {
            usedParam.setUsedRolParameterTonValue(BigDecimal.ZERO);
            usedParam.setUsedRolParamMonetaryVal(BigDecimal.ZERO);
            usedParam.setUsedRolParamStripeValue(0L);
        }

        // Add this rol, expected that all parameter must have zero values.
        dto.replaceUsedRolParameter(dto);

        // Verify if all parameters are zero
        for (UsedRolParameter usedParam : dto.getReportOnline().getUsedRolParameters()) {
            Assert.assertEquals("Expected zero for ton param.", BigDecimal.ZERO,
                    usedParam.getUsedRolParameterTonValue());
            Assert.assertEquals("Expected zero for monetary param.", BigDecimal.ZERO,
                    usedParam.getUsedRolParamMonetaryVal());
            Assert.assertEquals("Expected zero for stripe values.", new Long("0"),
                    usedParam.getUsedRolParamStripeValue());
        }

    }

    /**
     * @throws ContractNotFoundException
     */
    @Test
    public void test_replace_used_rol_parameter_replace_for_one() throws BusinessException {

        // Build dto
        ReportOnlineDTO dto = reportOnLineService.convertReportOnlineToReportOnlineDTO(reportOnLine);
        Assert.assertNotNull("Expected a non-null converted dto.", dto);

        // Check if dont have any zero parameter
        for (UsedRolParameter usedParam : dto.getReportOnline().getUsedRolParameters()) {
            Assert.assertFalse("Expected non zero for ton param.",
                    BigDecimal.ZERO.equals(usedParam.getUsedRolParameterTonValue()));
            Assert.assertFalse("Expected non zero for monetary param.",
                    BigDecimal.ZERO.equals(usedParam.getUsedRolParamMonetaryVal()));
            Assert.assertFalse("Expected non zero for stripe values.",
                    new Long("0").equals(usedParam.getUsedRolParamStripeValue()));
        }

        // Set zero to all parameters
        for (UsedRolParameter usedParam : dto.getReportOnline().getUsedRolParameters()) {
            usedParam.setUsedRolParameterTonValue(BigDecimal.ONE);
            usedParam.setUsedRolParamMonetaryVal(BigDecimal.ONE);
            usedParam.setUsedRolParamStripeValue(1L);
        }

        // Add this rol, expected that all parameter must have zero values.
        dto.replaceUsedRolParameter(dto);

        // Verify if all parameters are zero
        for (UsedRolParameter usedParam : dto.getReportOnline().getUsedRolParameters()) {
            Assert.assertEquals("Expected zero for ton param.", BigDecimal.ONE, usedParam.getUsedRolParameterTonValue());
            Assert.assertEquals("Expected zero for monetary param.", BigDecimal.ONE,
                    usedParam.getUsedRolParamMonetaryVal());
            Assert.assertEquals("Expected zero for stripe values.", new Long("1"),
                    usedParam.getUsedRolParamStripeValue());
        }

    }

    @Test
    public void select_greater_variation() throws BusinessException {
        ReportOnLineFilter filter = new ReportOnLineFilter();
        RolConfigurationService rolConfigurationDAOMock = Mockito.mock(RolConfigurationService.class);
        reportOnLineService.setRolConfigurationService(rolConfigurationDAOMock);

        filter.setCrop(crop);
        filter.setCompany(company);
        List<ReportOnLine> listReportOnline = new ArrayList<ReportOnLine>();
        listReportOnline.add(reportOnLine);
        Mockito.when(reportOnlineDAO.selectReportOnLineListByFilter(filter)).thenReturn(listReportOnline);
        reportOnLineService.setRolDao(reportOnlineDAO);
        RolConfiguration rolConfig = new RolConfiguration();
        rolConfig.setMaximumVariationPrice(BigDecimal.TEN);
        Mockito.when(rolConfigurationDAOMock.selectRolConfiguration(crop, company)).thenReturn(rolConfig);
        assertNotNull(reportOnLineService.selectReportOnLineListCounterPrice(filter));
        assertEquals(expectedGreaterVariation, reportOnLineService.selectReportOnLineListCounterPrice(filter).get(0)
                .getGreaterVariation());
    }

    @Test
    public void select_greater_variation_for_two_used_paramter() throws BusinessException {
        List<ReportOnLine> listReportOnline = new ArrayList<ReportOnLine>();
        listReportOnline.add(reportOnLine);
        Mockito.when(reportOnlineDAO.selectReportOnLineListByFilter(filter)).thenReturn(listReportOnline);
        reportOnLineService.setRolDao(reportOnlineDAO);
        RolConfiguration rolConfig = new RolConfiguration();
        rolConfig.setMaximumVariationPrice(BigDecimal.TEN);

        assertEquals(expectedGreaterVariation, reportOnLineService.selectReportOnLineListCounterPrice(filter).get(0)
                .getGreaterVariation());
    }

    @Test
    public void validate_if_greater_price_has_exceeded() throws BusinessException {
        List<ReportOnLine> listReportOnline = new ArrayList<ReportOnLine>();
        listReportOnline.add(reportOnLine);
        Mockito.when(reportOnlineDAO.selectReportOnLineListByFilter(filter)).thenReturn(listReportOnline);
        reportOnLineService.setRolDao(reportOnlineDAO);
        RolConfiguration rolConfig = new RolConfiguration();
        rolConfig.setMaximumVariationPrice(BigDecimal.TEN);
        assertFalse(reportOnLineService.selectReportOnLineListCounterPrice(filter).get(0).getIsExceeded());
    }

    @Test
    public void validate_if_counter_is_zero_when_it_is_not_informed() throws BusinessException {
        List<ReportOnLine> listReportOnline = new ArrayList<ReportOnLine>();
        listReportOnline.add(reportOnLine);
        Mockito.when(reportOnlineDAO.selectReportOnLineListByFilter(filter)).thenReturn(listReportOnline);
        reportOnLineService.setRolDao(reportOnlineDAO);
        Set<UsedRolParameter> usedRolParameters = reportOnLineService.selectReportOnLineListCounterPrice(filter).get(0)
                .getUsedRolParameters();
        for (UsedRolParameter usedRolParameter : usedRolParameters) {
            if (usedRolParameter.getCounterPrice() == null) {
                assertEquals(BigDecimal.ZERO, usedRolParameter.getCounterPrice());
            }
        }
    }

    /**
     * Check for edtion in rol analisys rtv.
     */
    @Test
    public void test_enable_edition_used_rol_parameter_in_rtv_analisys() {

        RolStatus status = new RolStatus(-1L, RolStatus.ROL_STATUS_RTV, null);

        ReportOnLine report = new ReportOnLine();
        report.setRolStatus(status);

        RolFrameGroup frameGroup = new RolFrameGroup();
        frameGroup.setRolFrameGroupCode(RolFrameGroup.FRAME_GROUP_FIXEDCURR);

        GroupAction groupAction = new GroupAction();
        groupAction.setGroupActionCode(GroupAction.GROUP_ACTION_SUM);

        RolParameter paramter = new RolParameter();
        paramter.setRolParameterMaterialSapId(null);
        paramter.setRolFrameGroup(frameGroup);
        paramter.setGroupAction(groupAction);

        UsedRolParameter usedRolParameter = new UsedRolParameter();
        usedRolParameter.setReportOnLine(report);
        usedRolParameter.setRolParameter(paramter);

        Assert.assertFalse("Cannot edit rvt rol status.", usedRolParameter.getEnabledEdit());

    }

    /**
     * Check for edtion in rol analisys rtv.
     */
    @Test
    public void test_enable_edition_used_rol_parameter_in_gr_state() {

        RolStatus status = new RolStatus(-1L, RolStatus.ROL_STATUS_GR, null);

        ReportOnLine report = new ReportOnLine();
        report.setRolStatus(status);

        RolFrameGroup frameGroup = new RolFrameGroup();
        frameGroup.setRolFrameGroupCode(RolFrameGroup.FRAME_GROUP_FIXEDCURR);

        GroupAction groupAction = new GroupAction();
        groupAction.setGroupActionCode(GroupAction.GROUP_ACTION_SUM);

        RolParameter paramter = new RolParameter();
        paramter.setRolParameterMaterialSapId(null);
        paramter.setRolFrameGroup(frameGroup);
        paramter.setGroupAction(groupAction);

        UsedRolParameter usedRolParameter = new UsedRolParameter();
        usedRolParameter.setReportOnLine(report);
        usedRolParameter.setRolParameter(paramter);

        Assert.assertFalse("Cannot edit rvt rol status.", usedRolParameter.getEnabledEdit());

    }

    /**
     * Check for edtion in rol analisys rtv.
     */
    @Test
    public void test_enable_edition_used_rol_parameter_in_released_state() {

        RolStatus status = new RolStatus(-1L, RolStatus.ROL_STATUS_RELEASED, null);

        ReportOnLine report = new ReportOnLine();
        report.setRolStatus(status);

        RolFrameGroup frameGroup = new RolFrameGroup();
        frameGroup.setRolFrameGroupCode(RolFrameGroup.FRAME_GROUP_FIXEDCURR);

        GroupAction groupAction = new GroupAction();
        groupAction.setGroupActionCode(GroupAction.GROUP_ACTION_SUM);

        RolParameter paramter = new RolParameter();
        paramter.setRolParameterMaterialSapId(null);
        paramter.setRolFrameGroup(frameGroup);
        paramter.setGroupAction(groupAction);

        UsedRolParameter usedRolParameter = new UsedRolParameter();
        usedRolParameter.setReportOnLine(report);
        usedRolParameter.setRolParameter(paramter);

        Assert.assertFalse("Cannot edit rvt rol status.", usedRolParameter.getEnabledEdit());

    }

    /**
     * Check for edtion in rol analisys rtv.
     */
    @Test
    public void test_enable_edition_used_rol_parameter_in_reserved_state() {

        RolStatus status = new RolStatus(-1L, RolStatus.ROL_STATUS_RESERVED, null);

        ReportOnLine report = new ReportOnLine();
        report.setRolStatus(status);

        RolFrameGroup frameGroup = new RolFrameGroup();
        frameGroup.setRolFrameGroupCode(RolFrameGroup.FRAME_GROUP_FIXEDCURR);

        GroupAction groupAction = new GroupAction();
        groupAction.setGroupActionCode(GroupAction.GROUP_ACTION_SUM);

        RolParameter paramter = new RolParameter();
        paramter.setRolParameterMaterialSapId(null);
        paramter.setRolFrameGroup(frameGroup);
        paramter.setGroupAction(groupAction);

        UsedRolParameter usedRolParameter = new UsedRolParameter();
        usedRolParameter.setReportOnLine(report);
        usedRolParameter.setRolParameter(paramter);

        Assert.assertFalse("Cannot edit rvt rol status.", usedRolParameter.getEnabledEdit());

    }

    /**
     * Check for edtion in rol analisys rtv.
     */
    @Test
    public void test_enable_edition_used_rol_parameter_test_stripe_processed_state_and_sum_action() {

        RolStatus status = new RolStatus(-1L, RolStatus.ROL_STATUS_PROCESSED, null);

        ReportOnLine report = new ReportOnLine();
        report.setRolStatus(status);

        RolFrameGroup frameGroup = new RolFrameGroup();
        frameGroup.setRolFrameGroupCode(RolFrameGroup.FRAME_GROUP_TESTSTRYPE);

        GroupAction groupAction = new GroupAction();
        groupAction.setGroupActionCode(GroupAction.GROUP_ACTION_SUM);

        RolParameter paramter = new RolParameter();
        paramter.setRolParameterMaterialSapId(null);
        paramter.setRolFrameGroup(frameGroup);
        paramter.setGroupAction(groupAction);

        UsedRolParameter usedRolParameter = new UsedRolParameter();
        usedRolParameter.setReportOnLine(report);
        usedRolParameter.setRolParameter(paramter);

        Assert.assertTrue("Expect edtion enabled.", usedRolParameter.getEnabledEdit());

    }

    /**
     * Check for edtion in rol analisys rtv.
     */
    @Test
    public void test_enable_edition_used_rol_parameter_test_stripe_processed_state_and_sum_action_with_sap_code() {

        RolStatus status = new RolStatus(-1L, RolStatus.ROL_STATUS_PROCESSED, null);

        ReportOnLine report = new ReportOnLine();
        report.setRolStatus(status);

        RolFrameGroup frameGroup = new RolFrameGroup();
        frameGroup.setRolFrameGroupCode(RolFrameGroup.FRAME_GROUP_TESTSTRYPE);

        GroupAction groupAction = new GroupAction();
        groupAction.setGroupActionCode(GroupAction.GROUP_ACTION_SUM);

        RolParameter paramter = new RolParameter();
        paramter.setRolParameterMaterialSapId("no no no no!");
        paramter.setRolFrameGroup(frameGroup);
        paramter.setGroupAction(groupAction);

        UsedRolParameter usedRolParameter = new UsedRolParameter();
        usedRolParameter.setReportOnLine(report);
        usedRolParameter.setRolParameter(paramter);

        Assert.assertFalse("Cannot available edition because its have sap code.", usedRolParameter.getEnabledEdit());

    }

    /**
     * Check for edtion in rol analisys rtv.
     */
    @Test
    public void test_enable_edition_used_rol_parameter_test_stripe_processed_state_and_result_action() {

        RolStatus status = new RolStatus(-1L, RolStatus.ROL_STATUS_PROCESSED, null);

        ReportOnLine report = new ReportOnLine();
        report.setRolStatus(status);

        RolFrameGroup frameGroup = new RolFrameGroup();
        frameGroup.setRolFrameGroupCode(RolFrameGroup.FRAME_GROUP_TESTSTRYPE);

        GroupAction groupAction = new GroupAction();
        groupAction.setGroupActionCode(GroupAction.GROUP_ACTION_CALCULATE);

        RolParameter paramter = new RolParameter();
        paramter.setRolParameterMaterialSapId(null);
        paramter.setRolFrameGroup(frameGroup);
        paramter.setGroupAction(groupAction);

        UsedRolParameter usedRolParameter = new UsedRolParameter();
        usedRolParameter.setReportOnLine(report);
        usedRolParameter.setRolParameter(paramter);

        Assert.assertFalse("Expect cannot edition enabled.", usedRolParameter.getEnabledEdit());

    }

    /**
     * Check for edtion in rol analisys rtv.
     */
    @Test
    public void test_enable_edition_used_rol_parameter_test_stripe_report_state() {

        RolStatus status = new RolStatus(-1L, RolStatus.ROL_STATUS_REPORTED, null);

        ReportOnLine report = new ReportOnLine();
        report.setRolStatus(status);

        RolFrameGroup frameGroup = new RolFrameGroup();
        frameGroup.setRolFrameGroupCode(RolFrameGroup.FRAME_GROUP_TESTSTRYPE);

        GroupAction groupAction = new GroupAction();
        groupAction.setGroupActionCode(GroupAction.GROUP_ACTION_CALCULATE);

        RolParameter paramter = new RolParameter();
        paramter.setRolParameterMaterialSapId("xx");
        paramter.setRolFrameGroup(frameGroup);
        paramter.setGroupAction(groupAction);

        UsedRolParameter usedRolParameter = new UsedRolParameter();
        usedRolParameter.setReportOnLine(report);
        usedRolParameter.setRolParameter(paramter);

        Assert.assertTrue("Report state must be available for edition.", usedRolParameter.getEnabledEdit());

    }

    /**
     * Check for edtion in rol analisys rtv.
     */
    @Test
    public void test_enable_edition_used_rol_parameter_test_stripe_correction_state() {

        RolStatus status = new RolStatus(-1L, RolStatus.ROL_STATUS_CORRECTED, null);

        ReportOnLine report = new ReportOnLine();
        report.setRolStatus(status);

        RolFrameGroup frameGroup = new RolFrameGroup();
        frameGroup.setRolFrameGroupCode(RolFrameGroup.FRAME_GROUP_TESTSTRYPE);

        GroupAction groupAction = new GroupAction();
        groupAction.setGroupActionCode(GroupAction.GROUP_ACTION_CALCULATE);

        RolParameter paramter = new RolParameter();
        paramter.setRolParameterMaterialSapId("xx");
        paramter.setRolFrameGroup(frameGroup);
        paramter.setGroupAction(groupAction);

        UsedRolParameter usedRolParameter = new UsedRolParameter();
        usedRolParameter.setReportOnLine(report);
        usedRolParameter.setRolParameter(paramter);

        Assert.assertTrue("Correction state must be available for edition.", usedRolParameter.getEnabledEdit());

    }

    @Test(expected = IllegalArgumentException.class)
    public void test_select_report_online_period_is_invalid_crop_and_company_is_required()
            throws CustomerNotFoundException {
        ReportOnLineFilter reportOnlineFilter = new ReportOnLineFilter();
        rolInformationServiceImpl.selectReportOnLineDTOListPeriod(null, reportOnlineFilter);
    }

    @Test
    public void test_select_report_online_period_is_empty() throws CustomerNotFoundException {
        List<UserContract> userContracts = new ArrayList<UserContract>();
        List<UserContract> contracts = new ArrayList<UserContract>();
        Customer matrix = new Customer();
        List<HeadOffice> listHeadOffice = new ArrayList<HeadOffice>();
        Mockito.when(
                participantService.findAllPODParticipantsByCropCompanyMatrixAndContracts(crop, company, matrix,
                        contracts)).thenReturn(listHeadOffice);
        assertTrue(rolInformationServiceImpl.selectReportOnLineDTOListPeriod(userContracts, filter).isEmpty());
    }

    @Test
    public void test_select_report_online_period_is_not_empty() throws CustomerNotFoundException {
        List<UserContract> userContracts = new ArrayList<UserContract>();
        List<UserContract> contracts = new ArrayList<UserContract>();
        Customer matrix = new Customer();
        List<HeadOffice> listHeadOffice = new ArrayList<HeadOffice>();
        listHeadOffice.add(headoffice);
        filter.setMatrix(matrix);
        filter.setContracts(contracts);
        Mockito.when(
                participantService.findAllPODParticipantsByCropCompanyMatrixAndContracts(filter.getCrop(),
                        filter.getCompany(), filter.getMatrix(), filter.getContracts())).thenReturn(listHeadOffice);

        assertFalse(rolInformationServiceImpl.selectReportOnLineDTOListPeriod(userContracts, filter).isEmpty());
    }

    @Test(expected = IllegalArgumentException.class)
    public void test_select_report_online_filter_is_invalid() throws BusinessException {
        reportOnLineService.selectReportOnLineByFilter(filter);
    }

    @Test
    public void test_select_report_online_filter_is_valid_but_there_is_not_record() throws BusinessException {
        Customer matrix = new Customer();
        filter.setMatrix(matrix);
        ItsDistrict district = new ItsDistrict();
        filter.setDistrict(district);
        filter.setParticipantType(ParticipantTypeEnum.POD);
        assertTrue(reportOnLineService.selectReportOnLineByFilter(filter).isEmpty());
    }

    /**
     * @throws BusinessException
     */
    @SuppressWarnings("unchecked")
    @Test(expected = EntityNotFoundException.class)
    public void test_convert_report_online_to_dto_with_invalid_billed_account_record_expected_entity_not_found_exception()
            throws BusinessException {

        // Mock exception for revenue account
        Mockito.when(revenueService.selectRevenueAccountByTypeAndHandleId(RevenueType.POD, reportOnLine.getId()))
                .thenThrow(EntityNotFoundException.class);

        // Billed report
        reportOnLine.setRolBillDate(new Date());
        reportOnLine.setRolBillNumber(3339904L);

        reportOnLineService.convertReportOnlineToReportOnlineDTO(reportOnLine);

    }

    /**
     * @throws BusinessException
     */
    @Test
    public void test_convert_report_online_to_dto() throws BusinessException {

        // Build billed account for rol
        RevenueAccount revenueAccount = new RevenueAccount(null, "4545454", operationalYear, RevenueType.POD, company,
                new Date(), null);

        // Mock exception for revenue account
        Mockito.when(revenueService.selectRevenueAccountByTypeAndHandleId(RevenueType.POD, reportOnLine.getId()))
                .thenReturn(revenueAccount);

        // Billed report
        reportOnLine.setRolBillDate(new Date());
        reportOnLine.setRolBillNumber(3339904L);

        // Convert to dto
        ReportOnlineDTO dto = reportOnLineService.convertReportOnlineToReportOnlineDTO(reportOnLine);
        Assert.assertNotNull(dto);
        Assert.assertNotNull(dto.getListTechRol());
        Assert.assertFalse(dto.getListTechRol().isEmpty());
        Assert.assertEquals(revenueAccount, dto.getRevenueAccount());

    }

    /**
     * @throws BusinessException
     */
    @Test
    public void test_convert_report_online_to_dto_check_report_by_grower() throws BusinessException {

        // Build paid volume by grower (rol by grower)
        List<PaidVolumeByGrower> rolByGrowerList = new ArrayList<PaidVolumeByGrower>();

        PaidVolumeByGrower p1 = new PaidVolumeByGrower();
        p1.getPaidVolByGrowerItems().add(
                new PaidVolByGrowerItem(0L, p1, technologyIntacta, BigDecimal.ONE, BigDecimal.ONE));
        p1.getPaidVolByGrowerItems().add(new PaidVolByGrowerItem(0L, p1, technologyRR, BigDecimal.ONE, BigDecimal.ONE));
        p1.getPaidVolByGrowerItems().add(
                new PaidVolByGrowerItem(0L, p1, technologyXpto, BigDecimal.ONE, BigDecimal.ONE));

        // Mock result of reported rol by grower
        Mockito.when(
                reportOnLineByGrowerService.selectPaidVolumeByGrowerListByFilter((PaidVolumeFilter) Matchers
                        .anyObject())).thenReturn(rolByGrowerList);

        // Convert to dto
        ReportOnlineDTO dto = reportOnLineService.convertReportOnlineToReportOnlineDTO(reportOnLine);
        Assert.assertNotNull(dto);
        Assert.assertNotNull(dto.getListTechRol());
        Assert.assertFalse(dto.getListTechRol().isEmpty());

        for (TechnologyROL tech : dto.getListTechRol()) {
            Assert.assertNotNull(tech.getAmountValuePaidByGrower());
            Assert.assertNotNull(tech.getVolumePaidByGrower());
        }

    }

    /**
     * 
     */
    @Test(expected = IllegalArgumentException.class)
    public void test_select_report_online_in_processed_state_with_null_filter_expected_illegarl_argument_exception() {

        reportOnLineService.selectReportOnLineInProcessedStateByFilter(null);
    }

    /**
     * 
     */
    @Test(expected = IllegalArgumentException.class)
    public void test_select_report_online_in_processed_state_with_empty_filter_expected_illegarl_argument_exception() {

        ReportOnLineFilter filter = new ReportOnLineFilter();
        reportOnLineService.selectReportOnLineInProcessedStateByFilter(filter);
    }

    /**
     * 
     */
    @Test(expected = IllegalArgumentException.class)
    public void test_select_report_online_in_processed_state_with_only_crop_in_filter_expected_illegarl_argument_exception() {

        ReportOnLineFilter filter = new ReportOnLineFilter();
        filter.setCrop(new Crop());

        reportOnLineService.selectReportOnLineInProcessedStateByFilter(filter);
    }

    /**
     * 
     */
    @Test(expected = IllegalArgumentException.class)
    public void test_select_report_online_in_processed_state_with_only_period_in_filter_expected_illegarl_argument_exception() {

        ReportOnLineFilter filter = new ReportOnLineFilter();
        filter.setInitDate(new Date());
        filter.setEndDate(new Date());

        reportOnLineService.selectReportOnLineInProcessedStateByFilter(filter);
    }

    /**
     * 
     */
    @Test(expected = IllegalArgumentException.class)
    public void test_select_report_online_in_processed_state_with_without_period_in_filter_expected_illegarl_argument_exception() {

        ReportOnLineFilter filter = new ReportOnLineFilter();
        filter.setCrop(new Crop());
        filter.setCompany(new Company());

        reportOnLineService.selectReportOnLineInProcessedStateByFilter(filter);
    }

    /**
     * @throws BusinessException
     */
    @Test(expected = BilledRolFoundForMatrixException.class)
    public void test_search_or_instanciate_report_online_to_dto_with_processed_rol_for_matrix_in_period_expected_billed_rol_found_for_matrix_exception()
            throws BusinessException {

        // rol period
        Date period = CalendarUtil.getDate(2000, Calendar.JANUARY, 1);

        // Mock rol search
        Mockito.when(
                reportOnlineDAO.searchReportOnlineByCropHeadOfficeAndPeriod(crop, headoffice, period, operationalYear))
                .thenReturn(null);

        // Head office search
        Mockito.when(participantService.findHeadOfficeById(headoffice.getId())).thenReturn(headoffice);

        //
        Mockito.when(
                reportOnlineDAO.selectCountReportOnlineForMatrixIgnoreAffiliateOnPeriod(
                        (HeadOffice) Matchers.anyObject(), (Date) Matchers.anyObject(), (Date) Matchers.anyObject(),
                        Matchers.anyString())).thenReturn(1000);

        // try search a report whose matrix have rol in processed state for any
        // other affiliate
        reportOnLineService.searchOrInstanciateReportOnlineToDTO(crop, headoffice, period, operationalYear);
    }
}
