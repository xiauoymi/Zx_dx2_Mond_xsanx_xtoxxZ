package com.monsanto.brazilvaluecapture.pod.rol.service.impl;

import junit.framework.Assert;

import org.junit.Before;
import org.junit.Test;

import com.monsanto.brazilvaluecapture.core.base.model.bean.Company;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Crop;
import com.monsanto.brazilvaluecapture.core.commercialhierarchy.model.bean.ItsDistrict;
import com.monsanto.brazilvaluecapture.core.commercialhierarchy.model.bean.ItsRegion;
import com.monsanto.brazilvaluecapture.core.commercialhierarchy.model.bean.ItsUnity;
import com.monsanto.brazilvaluecapture.pod.rol.model.bean.ApprovalEmail;

/**
 * @author cmiranda
 * 
 */
public class ApprovalEmail_UT {

    private ItsUnity unity;
    private ItsRegion region;
    private ItsDistrict district;
    private String login = "john";
    private Crop crop;
    private Company company;

    @Before
    public void setup() {
        unity = new ItsUnity();
        region = new ItsRegion();
        district = new ItsDistrict();
        crop = new Crop();
        company = new Company();
    }

    /**
     * 
     */
    @Test
    public void test_check_valid_email_without_email() {

        // Create email approval
        ApprovalEmail approvalEmail = new ApprovalEmail(crop, company, unity, region, district, login);

        Assert.assertTrue("Expected 0 item on list.", approvalEmail.getFirstLevelEmails().length == 0);
        Assert.assertTrue("Expected 0 item on list.", approvalEmail.getSecondLevelEmails().length == 0);

    }

    @Test
    public void test_check_valid_email() {

        // Create email approval
        ApprovalEmail approvalEmail = new ApprovalEmail(crop, company, unity, region, district, login);
        approvalEmail.setFirstApprovalEmails("cmiranda@ciandt.com");
        approvalEmail.setSecondaryApprovalEmails("cmiranda@ciandt.com");

        Assert.assertTrue("Expected 1 item on list.", approvalEmail.getFirstLevelEmails().length == 1);
        Assert.assertTrue("Expected 1 item on list.", approvalEmail.getSecondLevelEmails().length == 1);
        Assert.assertEquals("cmiranda@ciandt.com", approvalEmail.getFirstLevelEmails()[0]);
        Assert.assertEquals("cmiranda@ciandt.com", approvalEmail.getSecondLevelEmails()[0]);

    }

    @Test
    public void test_check_valid_email_with_separante() {

        // Create email approval
        ApprovalEmail approvalEmail = new ApprovalEmail(crop, company, unity, region, district, login);
        approvalEmail.setFirstApprovalEmails("cmiranda@ciandt.com; ");
        approvalEmail.setSecondaryApprovalEmails("cmiranda@ciandt.com; ");

        Assert.assertTrue("Expected 1 item on list.", approvalEmail.getFirstLevelEmails().length == 1);
        Assert.assertTrue("Expected 1 item on list.", approvalEmail.getSecondLevelEmails().length == 1);

    }

    @Test
    public void test_check_invalid_email() {

        // Create email approval
        ApprovalEmail approvalEmail = new ApprovalEmail(crop, company, unity, region, district, login);
        approvalEmail.setFirstApprovalEmails("xxxxx");
        approvalEmail.setSecondaryApprovalEmails("yyyy;zzzz;");

        Assert.assertTrue("Expected 1 item on list.", approvalEmail.getFirstLevelEmails().length == 1);
        Assert.assertTrue("Expected 2 item on list.", approvalEmail.getSecondLevelEmails().length == 2);

    }

    @Test
    public void test_check_valid_email_with_two_emails() {

        // Create email approval
        ApprovalEmail approvalEmail = new ApprovalEmail(crop, company, unity, region, district, login);
        approvalEmail.setFirstApprovalEmails("cmiranda@ciandt.com;jose@yahoo.com");
        approvalEmail.setSecondaryApprovalEmails("cmiranda@ciandt.com;maria@gmail.com;");

        Assert.assertTrue("Expected 2 item on list.", approvalEmail.getFirstLevelEmails().length == 2);
        Assert.assertTrue("Expected 2 item on list.", approvalEmail.getSecondLevelEmails().length == 2);
        Assert.assertEquals("cmiranda@ciandt.com", approvalEmail.getFirstLevelEmails()[0]);
        Assert.assertEquals("jose@yahoo.com", approvalEmail.getFirstLevelEmails()[1]);
        Assert.assertEquals("cmiranda@ciandt.com", approvalEmail.getSecondLevelEmails()[0]);
        Assert.assertEquals("maria@gmail.com", approvalEmail.getSecondLevelEmails()[1]);

    }
}
