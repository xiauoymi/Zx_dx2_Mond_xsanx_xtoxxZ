package com.monsanto.brazilvaluecapture.pod.waybill.model.dao.impl;

import com.monsanto.brazilvaluecapture.core.foundation.service.BusinessException;
import com.monsanto.brazilvaluecapture.core.foundation.service.EntityAlreadyExistException;
import com.monsanto.brazilvaluecapture.pod.waybill.model.bean.IncomingWaybill;
import com.monsanto.brazilvaluecapture.pod.waybill.model.bean.IncomingWaybillAR;
import org.hibernate.Criteria;
import org.hibernate.SessionFactory;
import org.hibernate.classic.Session;
import org.hibernate.criterion.Criterion;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class IncomingWaybillDAOImpl_UT {

    @Mock
    private SessionFactory sessionFactory;
    @Mock
    private Session session;
    @Mock
    private Criteria criteria;
    @Mock
    private IncomingWaybill incomingWaybill;
    private IncomingWaybillDAOImpl dao;

    @Before
    public void setUp() {
        dao = new IncomingWaybillDAOImpl(sessionFactory);
        when(sessionFactory.getCurrentSession()).thenReturn(session);
    }

    @Test
    public void findByNullProcessedOnShouldSucceed() {
        List<IncomingWaybill> incomingWaybills = mock(List.class);
        when(session.createCriteria(eq(IncomingWaybill.class), anyString())).thenReturn(criteria);
        when(criteria.add(any(Criterion.class))).thenReturn(criteria);
        when(criteria.list()).thenReturn(incomingWaybills);

        List<IncomingWaybill> result = dao.findByNullProcessedOn();

        assertEquals(incomingWaybills, result);
        verify(criteria).add(any(Criterion.class));
    }

    @Test
    public void saveShouldSucceed() throws Exception {
        dao.save(incomingWaybill);

        verify(session).saveOrUpdate(incomingWaybill);
        verify(session).flush();
    }

    @Test
    public void saveShouldThrowBusinessExceptionWhenFails() {
        doThrow(new RuntimeException()).when(session).saveOrUpdate(incomingWaybill);

        try {
            dao.save(incomingWaybill);
            fail();
        } catch (BusinessException ex) {
            assertFalse(ex instanceof EntityAlreadyExistException);
        }
    }

    @Test
    public void saveShouldThrowBusinessExceptionWhenFailsAndCauseIsItself() {
        RuntimeException exception = mock(RuntimeException.class);
        doThrow(exception).when(session).saveOrUpdate(incomingWaybill);
        when(exception.getCause()).thenReturn(exception);

        try {
            dao.save(incomingWaybill);
            fail();
        } catch (BusinessException ex) {
            assertFalse(ex instanceof EntityAlreadyExistException);
        }
    }

    @Test
    public void saveShouldThrowBusinessExceptionWhenFailsAndCauseHasAnyMessage() {
        RuntimeException exception1 = mock(RuntimeException.class);
        RuntimeException exception2 = mock(RuntimeException.class);
        doThrow(exception1).when(session).saveOrUpdate(incomingWaybill);
        when(exception1.getCause()).thenReturn(exception2);
        when(exception2.getMessage()).thenReturn("An exception");

        try {
            dao.save(incomingWaybill);
            fail();
        } catch (BusinessException ex) {
            assertFalse(ex instanceof EntityAlreadyExistException);
        }
    }

    @Test
    public void saveShouldThrowEntityAlreadyExistExceptionWhenARCtgNumberConstraintViolated() {
        RuntimeException exception = mock(RuntimeException.class);
        doThrow(exception).when(session).saveOrUpdate(incomingWaybill);
        when(exception.getMessage()).thenReturn("Blah " + IncomingWaybillDAOImpl.UNIQUE_CONSTRAINT_AR_CTG_NUMBER + " violation");

        try {
            dao.save(incomingWaybill);
            fail();
        } catch (BusinessException ex) {
            assertTrue(ex instanceof EntityAlreadyExistException);
        }
    }

    @Test
    public void saveShouldThrowEntityAlreadyExistExceptionWhenARWaybillNumberConstraintViolated() {
        RuntimeException exception = mock(RuntimeException.class);
        doThrow(exception).when(session).saveOrUpdate(incomingWaybill);
        when(exception.getMessage()).thenReturn("Blah " + IncomingWaybillDAOImpl.UNIQUE_CONSTRAINT_AR_WAYBILL_NUMBER + " violation");

        try {
            dao.save(incomingWaybill);
            fail();
        } catch (BusinessException ex) {
            assertTrue(ex instanceof EntityAlreadyExistException);
        }
    }

    @Test
    public void saveShouldThrowEntityAlreadyExistExceptionWhenPYWaybillNumberConstraintViolated() {
        RuntimeException exception = mock(RuntimeException.class);
        doThrow(exception).when(session).saveOrUpdate(incomingWaybill);
        when(exception.getMessage()).thenReturn("Blah " + IncomingWaybillDAOImpl.UNIQUE_CONSTRAINT_PY_WAYBILL_NUMBER + " violation");

        try {
            dao.save(incomingWaybill);
            fail();
        } catch (BusinessException ex) {
            assertTrue(ex instanceof EntityAlreadyExistException);
        }
    }

    @Test
    public void testGiven_A_WaybillList_When_I_CallReprocessWaybill_Then_ItShouldNotRaiseException() {
        ArrayList<IncomingWaybill> incomingWaybills=new ArrayList<IncomingWaybill>();
        IncomingWaybill iw=new IncomingWaybillAR();
        iw.setBulkId(1L);
        iw.setErrorMessage("Error");
        iw.setId(1L);
        iw.setProcessedOn(new Date());
        incomingWaybills.add(iw);
        try {

             dao.reprocessWaybill(incomingWaybills);
        } catch (RuntimeException re) {
            fail();
        }
       assertTrue("Success: ",true);
    }


}