package com.monsanto.brazilvaluecapture.pod.rol.service.impl;

import java.io.FileNotFoundException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.ResourceBundle;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

import com.monsanto.brazilvaluecapture.core.base.model.bean.Company;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Country;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Crop;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Document;
import com.monsanto.brazilvaluecapture.core.base.model.bean.OperationalYear;
import com.monsanto.brazilvaluecapture.core.base.service.CompanyService;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Customer;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.HeadOffice;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.ParticipantTypeEnum;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Technology;
import com.monsanto.brazilvaluecapture.core.customer.service.CustomerNotFoundException;
import com.monsanto.brazilvaluecapture.core.customer.service.ParticipantFilter;
import com.monsanto.brazilvaluecapture.core.customer.service.ParticipantService;
import com.monsanto.brazilvaluecapture.core.foundation.service.BusinessException;
import com.monsanto.brazilvaluecapture.core.foundation.service.EntityNotFoundException;
import com.monsanto.brazilvaluecapture.core.foundation.util.CalendarUtil;
import com.monsanto.brazilvaluecapture.core.foundation.util.csv.CSVReadableInvalidException;
import com.monsanto.brazilvaluecapture.core.user.model.bean.ItsUser;
import com.monsanto.brazilvaluecapture.core.user.model.bean.ItsUser.UserTypeEnum;
import com.monsanto.brazilvaluecapture.pod.rol.model.bean.GroupAction;
import com.monsanto.brazilvaluecapture.pod.rol.model.bean.OperationalYearType;
import com.monsanto.brazilvaluecapture.pod.rol.model.bean.ReportOnLine;
import com.monsanto.brazilvaluecapture.pod.rol.model.bean.RolFrameGroup;
import com.monsanto.brazilvaluecapture.pod.rol.model.bean.RolParameter;
import com.monsanto.brazilvaluecapture.pod.rol.model.bean.RolStatus;
import com.monsanto.brazilvaluecapture.pod.rol.model.bean.UsedRolParameter;
import com.monsanto.brazilvaluecapture.pod.rol.model.service.ReportOnLineConstraintException;
import com.monsanto.brazilvaluecapture.pod.rol.model.service.ReportOnLineService;
import com.monsanto.brazilvaluecapture.pod.rol.model.service.RolInformationService;
import com.monsanto.brazilvaluecapture.pod.rol.model.service.impl.CsvReportOnlineTemplate;
import com.monsanto.brazilvaluecapture.pod.rol.model.service.impl.ReportOnlineFileParser;
import com.monsanto.brazilvaluecapture.pod.rol.model.service.impl.ReportOnlineParserResult;

/**
 * @author cmiranda
 * 
 */
public class ReportOnlineFileParser_UT {

    /**
     * Parser to be tested
     */
    private ReportOnlineFileParser parser;

    // Services
    private CompanyService companyService;
    private ParticipantService participantService;
    private ReportOnLineService reportOnLineService;
    private RolInformationService rolInformationService;

    private Crop crop;
    private ItsUser user;
    private Company company;
    private Customer matrix;
    private OperationalYear operationalYear;
    private CsvReportOnlineTemplate template;

    private Locale locale = new Locale("pt", "BR");

    private Technology techRR;
    private Technology techINTACTA;

    private InputStream inputStream;

    /**
     * Bundle
     */
    private ResourceBundle resourceBundle = ResourceBundle.getBundle("bundle/bundle");

    @Before
    public void setup() throws FileNotFoundException, CustomerNotFoundException, EntityNotFoundException {

        // Create crop and company
        Country country = new Country("USA", "usa");
        company = new Company("monsanto");
        crop = new Crop("soya", company, country);

        techRR = new Technology("RR", company);
        techRR.setId(1L);
        techINTACTA = new Technology("INTACTA", company);
        techINTACTA.setId(2L);

        // Create matrix
        matrix = new Customer("elise", new Document(null, "999000666"), null, "x008");

        // Create its user
        user = new ItsUser("juquinha", UserTypeEnum.SUPER);

        // Create operational year
        operationalYear = new OperationalYear("2012");

        // Mock participant service
        companyService = Mockito.mock(CompanyService.class);
        participantService = Mockito.mock(ParticipantService.class);
        reportOnLineService = Mockito.mock(ReportOnLineService.class);
        rolInformationService = Mockito.mock(RolInformationService.class);

        // Mock customer search
        HeadOffice headOffice = new HeadOffice(matrix, matrix, ParticipantTypeEnum.POD, crop, company);
        Mockito.when(participantService.selectAffiliateByFilter((ParticipantFilter) Mockito.anyObject())).thenReturn(
                headOffice);

        // Mock operational year search
        Mockito.when(companyService.getOperationalYearByCandidateKey(Mockito.anyString())).thenReturn(operationalYear);

        // Mock rol status search
        Mockito.when(rolInformationService.selectRolStatusByCode(Mockito.anyString())).thenReturn(
                new RolStatus(-1L, RolStatus.ROL_STATUS_RTV, null));

        // Load csv template
        loadTemplate();

    }

    /**
     * @return
     */
    private CsvReportOnlineTemplate loadTemplate() {

        // Actions
        GroupAction groupActionSum = new GroupAction(-2L, GroupAction.GROUP_ACTION_SUM, GroupAction.GROUP_ACTION_SUM);

        GroupAction groupActionNoAction = new GroupAction(-2L, GroupAction.GROUP_ACTION_SUM,
                GroupAction.GROUP_ACTION_NOACTION);

        // Frame group
        RolFrameGroup rolFrameGroupReceived = new RolFrameGroup();
        rolFrameGroupReceived.setRolFrameGroupCode(RolFrameGroup.FRAME_GROUP_RECEIVED);

        RolFrameGroup rolFrameGroupFixedOccurr = new RolFrameGroup();
        rolFrameGroupFixedOccurr.setRolFrameGroupCode(RolFrameGroup.FRAME_GROUP_FIXEDCURR);

        RolFrameGroup rolFrameGroupFixedOld = new RolFrameGroup();
        rolFrameGroupFixedOld.setRolFrameGroupCode(RolFrameGroup.FRAME_GROUP_FIXEDOLD);

        RolFrameGroup rolFrameGroupTestStripe = new RolFrameGroup();
        rolFrameGroupTestStripe.setRolFrameGroupCode(RolFrameGroup.FRAME_GROUP_TESTSTRYPE);

        // Operational year type
        OperationalYearType operationalYearTypeActualYear = new OperationalYearType();
        operationalYearTypeActualYear.setOperationalYearTypeCode("actual");
        operationalYearTypeActualYear.setOperationalYearTypeDiff(0);
        operationalYearTypeActualYear.setOperationalYearTypeBundle("pod.rol.parameter.actual.label");
        
        OperationalYearType operationalYearTypeLessOne = new OperationalYearType();
        operationalYearTypeLessOne.setOperationalYearTypeCode("-1");
        operationalYearTypeLessOne.setOperationalYearTypeDiff(-1);
        operationalYearTypeLessOne.setOperationalYearTypeBundle("pod.rol.parameter.actual.label.one");
        
        
        List<RolParameter> parameters = new ArrayList<RolParameter>();

        // Rol parameter received
        RolParameter rolParameter = new RolParameter();
        rolParameter.setGroupAction(groupActionNoAction);
        rolParameter.setOperationalYearType(operationalYearTypeActualYear);
        rolParameter.setRolFrameGroup(rolFrameGroupReceived);
        rolParameter.setRolParamShownDescription("received");
        rolParameter.setTechnology(techRR);
        parameters.add(rolParameter);

        rolParameter = new RolParameter();
        rolParameter.setGroupAction(groupActionNoAction);
        rolParameter.setOperationalYearType(operationalYearTypeActualYear);
        rolParameter.setRolFrameGroup(rolFrameGroupReceived);
        rolParameter.setRolParamShownDescription("received");
        rolParameter.setTechnology(techINTACTA);
        parameters.add(rolParameter);

        // Rol parameter fix paid current year
        rolParameter = new RolParameter();
        rolParameter.setGroupAction(groupActionNoAction);
        rolParameter.setOperationalYearType(operationalYearTypeActualYear);
        rolParameter.setRolFrameGroup(rolFrameGroupFixedOccurr);
        rolParameter.setRolParamShownDescription("fixed paid current year");
        rolParameter.setTechnology(techRR);
        parameters.add(rolParameter);

        rolParameter = new RolParameter();
        rolParameter.setGroupAction(groupActionNoAction);
        rolParameter.setOperationalYearType(operationalYearTypeActualYear);
        rolParameter.setRolFrameGroup(rolFrameGroupFixedOccurr);
        rolParameter.setRolParamShownDescription("fixed paid current year");
        rolParameter.setTechnology(techINTACTA);
        parameters.add(rolParameter);

        // Rol parameter fix paid old year -1
        rolParameter = new RolParameter();
        rolParameter.setGroupAction(groupActionNoAction);
        rolParameter.setOperationalYearType(operationalYearTypeLessOne);
        rolParameter.setRolFrameGroup(rolFrameGroupFixedOld);
        rolParameter.setRolParamShownDescription("fixed paid old year");
        rolParameter.setTechnology(techRR);
        parameters.add(rolParameter);

        rolParameter = new RolParameter();
        rolParameter.setGroupAction(groupActionNoAction);
        rolParameter.setOperationalYearType(operationalYearTypeLessOne);
        rolParameter.setRolFrameGroup(rolFrameGroupFixedOld);
        rolParameter.setRolParamShownDescription("fixed paid old year");
        rolParameter.setTechnology(techINTACTA);
        parameters.add(rolParameter);

        // Rol parameter fix test stripes sum
        rolParameter = new RolParameter();
        rolParameter.setGroupAction(groupActionSum);
        rolParameter.setOperationalYearType(operationalYearTypeActualYear);
        rolParameter.setRolFrameGroup(rolFrameGroupTestStripe);
        rolParameter.setRolParamShownDescription("sum test stripe");
        rolParameter.setTechnology(techRR);
        parameters.add(rolParameter);

        rolParameter = new RolParameter();
        rolParameter.setGroupAction(groupActionSum);
        rolParameter.setOperationalYearType(operationalYearTypeActualYear);
        rolParameter.setRolFrameGroup(rolFrameGroupTestStripe);
        rolParameter.setRolParamShownDescription("sum test stripe");
        rolParameter.setTechnology(techINTACTA);
        parameters.add(rolParameter);

        // Rol parameter fix test stripes no action
        rolParameter = new RolParameter();
        rolParameter.setGroupAction(groupActionNoAction);
        rolParameter.setOperationalYearType(operationalYearTypeActualYear);
        rolParameter.setRolFrameGroup(rolFrameGroupTestStripe);
        rolParameter.setRolParamShownDescription("no action test stripe");
        rolParameter.setTechnology(techRR);
        parameters.add(rolParameter);

        rolParameter = new RolParameter();
        rolParameter.setGroupAction(groupActionNoAction);
        rolParameter.setOperationalYearType(operationalYearTypeActualYear);
        rolParameter.setRolFrameGroup(rolFrameGroupTestStripe);
        rolParameter.setRolParamShownDescription("no action test stripe");
        rolParameter.setTechnology(techINTACTA);
        parameters.add(rolParameter);

        // Create template
        template = new CsvReportOnlineTemplate(parameters, resourceBundle);

        // Look for valid template
        Assert.assertNotNull(template.getHeaders());
        Assert.assertFalse(template.getHeaders().isEmpty());
        Assert.assertEquals(16, template.getHeaders().size());

        System.out.println(template.getHeaders());

        return template;

    }

    /**
     * @throws CSVReadableInvalidException
     * 
     */
    @Test
    public void test_parse_read_file() throws CSVReadableInvalidException {

        // Load file
        inputStream = getClass().getClassLoader().getResourceAsStream("csv/rol_import_template_valid.csv");

        // Create parser
        parser = new ReportOnlineFileParser(inputStream, locale, reportOnLineService, participantService,
                companyService, user, crop, company, matrix, template, rolInformationService);

        // Read file csv
        parser.readFile();

        // Check if all lines are valid
        Assert.assertEquals(0, parser.getErrorLines());

        // All lines must be in success (only one report online is expected)
        Assert.assertEquals(1, parser.getSuccessLines());

        // Get result
        ReportOnlineParserResult result = parser.getReportOnlineParserResult();
        Assert.assertNotNull(result);

        // Verify if was converted
        Assert.assertFalse(result.getCorrectReportOnline().isEmpty());
        Assert.assertEquals(1, result.getCorrectReportOnline().size());

        // Check rol rol
        ReportOnLine rol = result.getCorrectReportOnline().get(0);
        Assert.assertEquals(crop, rol.getCrop());
        Assert.assertNotNull(rol.getHeadoffice());
        Assert.assertEquals(matrix, rol.getHeadoffice().getMatrix());
        Assert.assertEquals(CalendarUtil.getFirstDateOfMonth(CalendarUtil.getDate(2012, 0, 1)), rol.getRolPeriod());
        Assert.assertNotNull(rol.getItsUserLogin());
        Assert.assertEquals(operationalYear, rol.getOperationalYear());
        Assert.assertNotNull(rol.getUsedRolParameters());
        Assert.assertFalse(rol.getUsedRolParameters().isEmpty());
        Assert.assertEquals(10, rol.getUsedRolParameters().size());
        Assert.assertNotNull(rol.getRolCreateDate());
        Assert.assertNotNull(rol.getRolStatus());
        Assert.assertTrue(rol.getIsAnalysisRTV());

        // Validate user parameters
        for (UsedRolParameter p : rol.getUsedRolParameters()) {

            // Rol parameter cannot be null
            Assert.assertNotNull(p.getRolParameter());

            // Used rol parameter must reference rol
            Assert.assertNotNull(p.getReportOnLine());

            if (RolFrameGroup.FRAME_GROUP_RECEIVED.equals(p.getRolParameter().getRolFrameGroupCode())) {
                Assert.assertNotNull(p.getUsedRolParameterTonValue());
                Assert.assertNull(p.getUsedRolParamMonetaryVal());
                Assert.assertNull(p.getUsedRolParamStripeValue());
            }

            if (RolFrameGroup.FRAME_GROUP_FIXEDCURR.equals(p.getRolParameter().getRolFrameGroupCode())) {
                Assert.assertNotNull(p.getUsedRolParameterTonValue());
                Assert.assertNotNull(p.getUsedRolParamMonetaryVal());
                Assert.assertNull(p.getUsedRolParamStripeValue());
            }

            if (RolFrameGroup.FRAME_GROUP_FIXEDOLD.equals(p.getRolParameter().getRolFrameGroupCode())) {
                Assert.assertNotNull(p.getUsedRolParameterTonValue());
                Assert.assertNotNull(p.getUsedRolParamMonetaryVal());
                Assert.assertNull(p.getUsedRolParamStripeValue());
            }

            if (RolFrameGroup.FRAME_GROUP_TESTSTRYPE.equals(p.getRolParameter().getRolFrameGroupCode())) {
                Assert.assertNull(p.getUsedRolParameterTonValue());
                Assert.assertNull(p.getUsedRolParamMonetaryVal());
                Assert.assertNotNull(p.getUsedRolParamStripeValue());
            }

        }

    }

    /**
     * @throws CSVReadableInvalidException
     * 
     */
    @Test
    public void test_parse_read_file_invalid_layout() throws CSVReadableInvalidException {

        // Load file
        inputStream = getClass().getClassLoader().getResourceAsStream("csv/file_BR.csv");

        // Create parser
        parser = new ReportOnlineFileParser(inputStream, locale, reportOnLineService, participantService,
                companyService, user, crop, company, matrix, template, rolInformationService);

        // Read file csv
        parser.readFile();

        // Check if all lines are valid
        Assert.assertEquals(5, parser.getErrorLines());

        // All lines must be in success
        Assert.assertEquals(0, parser.getSuccessLines());

        ReportOnlineParserResult result = parser.getReportOnlineParserResult();
        Assert.assertNotNull(result);

        Assert.assertFalse(result.hasCorrectCreditConsumption());
    }

    /**
     * @throws CSVReadableInvalidException
     * 
     */
    @Test
    public void test_parse_read_file_invalid_data_type() throws CSVReadableInvalidException {

        // Load file
        inputStream = getClass().getClassLoader().getResourceAsStream("csv/rol_import_template_invalid_data_types.csv");

        // Create parser
        parser = new ReportOnlineFileParser(inputStream, locale, reportOnLineService, participantService,
                companyService, user, crop, company, matrix, template, rolInformationService);

        // Read file csv
        parser.readFile();

        // Check if all lines are valid
        Assert.assertEquals(15, parser.getErrorLines());

        // All lines must be in success
        Assert.assertEquals(0, parser.getSuccessLines());

        ReportOnlineParserResult result = parser.getReportOnlineParserResult();
        Assert.assertNotNull(result);

        Assert.assertFalse(result.hasCorrectCreditConsumption());
    }

    /**
     * @throws CSVReadableInvalidException
     * @throws ReportOnLineConstraintException
     * 
     */
    @Test
    public void test_parse_read_file_invalid_empty_rol_parameter_values() throws CSVReadableInvalidException,
            BusinessException {

        // Load file
        inputStream = getClass().getClassLoader().getResourceAsStream(
                "csv/rol_import_template_invalid_empty_values.csv");

        // Create parser
        parser = new ReportOnlineFileParser(inputStream, locale, reportOnLineService, participantService,
                companyService, user, crop, company, matrix, template, rolInformationService);

        // Mock validation exception
        Mockito.doThrow(ReportOnLineConstraintException.class).when(reportOnLineService)
                .validateSendReportOnLine((ReportOnLine) Mockito.anyObject());

        // Read file csv
        parser.readFile();

        // Check if all lines are valid
        // TODO: rever!
        Assert.assertEquals(1, parser.getErrorLines());

        // All lines must be in success
        Assert.assertEquals(0, parser.getSuccessLines());

        ReportOnlineParserResult result = parser.getReportOnlineParserResult();
        Assert.assertNotNull(result);

        Assert.assertFalse(result.hasCorrectCreditConsumption());
    }

    /**
     * @throws CSVReadableInvalidException
     * @throws ReportOnLineConstraintException
     * 
     */
    @Test
    public void test_parse_read_file_invalid_duplicated_affiliate_by_period() throws CSVReadableInvalidException,
            BusinessException {

        // Load file
        inputStream = getClass().getClassLoader().getResourceAsStream(
                "csv/rol_import_template_invalid_duplicate_affiliate_by_period.csv");

        // Create parser
        parser = new ReportOnlineFileParser(inputStream, locale, reportOnLineService, participantService,
                companyService, user, crop, company, matrix, template, rolInformationService);

        // Mock validation exception
        Mockito.doThrow(ReportOnLineConstraintException.class).when(reportOnLineService)
                .validateSendReportOnLine((ReportOnLine) Mockito.anyObject());

        // Read file csv
        parser.readFile();

        // Check if all lines are valid
        // TODO: rever!
        Assert.assertEquals(2, parser.getErrorLines());

        // All lines must be in success
        Assert.assertEquals(0, parser.getSuccessLines());

        ReportOnlineParserResult result = parser.getReportOnlineParserResult();
        Assert.assertNotNull(result);

        Assert.assertFalse(result.hasCorrectCreditConsumption());
    }
}
