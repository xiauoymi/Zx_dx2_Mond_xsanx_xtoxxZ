package com.monsanto.brazilvaluecapture.pod.revenue.service.impl;

import com.monsanto.Util.StringUtils;
import com.monsanto.brazilvaluecapture.core.base.model.bean.*;
import com.monsanto.brazilvaluecapture.core.base.model.dao.OperationalYearDAO;
import com.monsanto.brazilvaluecapture.core.base.model.dao.TechnologyDAO;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Contract;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Customer;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.HeadOffice;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Technology;
import com.monsanto.brazilvaluecapture.core.foundation.RandomTestData;
import com.monsanto.brazilvaluecapture.core.foundation.service.BusinessException;
import com.monsanto.brazilvaluecapture.core.foundation.service.EntityNotFoundException;
import com.monsanto.brazilvaluecapture.core.foundation.test.AbstractServiceIntegrationTests;
import com.monsanto.brazilvaluecapture.core.foundation.test.dbunit.DbUnitHelper;
import com.monsanto.brazilvaluecapture.core.foundation.util.CalendarUtil;
import com.monsanto.brazilvaluecapture.core.grower.model.bean.Grower;
import com.monsanto.brazilvaluecapture.core.posting.model.bean.Posting;
import com.monsanto.brazilvaluecapture.core.posting.model.bean.PostingReference;
import com.monsanto.brazilvaluecapture.core.posting.model.bean.ReferenceNameEnum;
import com.monsanto.brazilvaluecapture.core.posting.service.PostingService;
import com.monsanto.brazilvaluecapture.core.revenue.model.bean.*;
import com.monsanto.brazilvaluecapture.core.revenue.model.dao.RevenueAccountDAO;
import com.monsanto.brazilvaluecapture.core.revenue.model.dao.RevenueExtractFilter;
import com.monsanto.brazilvaluecapture.core.revenue.osb.OsbRevenueService;
import com.monsanto.brazilvaluecapture.core.revenue.service.Billable;
import com.monsanto.brazilvaluecapture.core.revenue.service.ChargeConsolidateService;
import com.monsanto.brazilvaluecapture.core.revenue.service.RevenueManager;
import com.monsanto.brazilvaluecapture.core.revenue.service.RevenueService;
import com.monsanto.brazilvaluecapture.core.user.model.bean.ItsUser;
import com.monsanto.brazilvaluecapture.osb.its.api.InfraException;
import com.monsanto.brazilvaluecapture.osb.its.api.OSBReturn;
import com.monsanto.brazilvaluecapture.pod.revenue.service.ReportOnlineBillableProvider;
import com.monsanto.brazilvaluecapture.pod.rol.model.bean.*;
import com.monsanto.brazilvaluecapture.pod.rol.model.dao.ReportOnlineDAO;
import com.monsanto.brazilvaluecapture.pod.rol.model.service.CounterPriceFilter;
import com.monsanto.brazilvaluecapture.pod.rol.model.service.ReportOnLineService;
import com.monsanto.brazilvaluecapture.pod.rol.model.service.RolInformationService;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Matchers;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import java.math.BigDecimal;
import java.util.*;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.stub;

public class RevenueService_AT extends AbstractServiceIntegrationTests {

    @Autowired
    private ReportOnlineDAO reportOnlineDAO;

    @Autowired
    private TechnologyDAO technologyDAO;

    @Autowired
    private OperationalYearDAO operationalYearDAO;

    @Autowired
    private ReportOnlineBillableProvider billableProvider;

    @Autowired
    private RolInformationService rolInformationService;

    @Autowired
    @Qualifier("revenueManager")
    private RevenueManager revenueManager;

    @Autowired
    private RevenueService revenueService;

    @Autowired
    private RevenueAccountDAO revenueAccountDAO;

    @Autowired
    private ChargeConsolidateService chargeConsolidateService;

    @Autowired
    private PostingService postingService;

    @SuppressWarnings("unchecked")
    @Before
    public void setup() throws InfraException {
        OsbRevenueService osbService = mock(OsbRevenueService.class);
        OSBReturn result = new OSBReturn();
        result.setDocumentNumber(RandomTestData.createRandomLong().toString());
        result.setSaleOrderNmber(RandomTestData.createRandomLong().toString());
        stub(
                osbService.bill(Matchers.any(com.monsanto.brazilvaluecapture.osb.its.api.param.DocumentType.class),
                        Matchers.any(String.class), Matchers.any(Boolean.class), Matchers.any(Date.class),
                        Matchers.any(List.class), Matchers.any(List.class), Matchers.any(String.class))).toReturn(result);
        revenueManager.setOsbService(osbService);
    }

    /**
     * Configure database data.
     */
    public void setupDBUnitWithAffiliates(boolean considerAffiliates) {

        // Load rol status
        int rolStatusCount = getSession().createCriteria(RolStatus.class).list().size();
        if (rolStatusCount == 0) {
            DbUnitHelper.setup("classpath:data/pod/rol/rol-status-dataset.xml");
        }

        // Load dbunit
        if (considerAffiliates) {
            DbUnitHelper.setup("classpath:data/core/fixture-system-dataset.xml",
                    "classpath:data/core/participant-dataset.xml",
                    "classpath:data/commercialhierarchy/commercialhierarchy-dataset.xml",
                    "classpath:data/pod/rol/rol-parameters-dataset.xml",
                    "classpath:data/pod/rol/report-online-affiliates-dataset.xml",
                    "classpath:data/pod/rol/counter-price-dataset.xml", "classpath:data/core/charge-group-dataset.xml",
                    "classpath:data/core/charge-group-nf-dataset.xml");
        } else {
            DbUnitHelper.setup("classpath:data/core/fixture-system-dataset.xml",
                    "classpath:data/core/participant-dataset.xml",
                    "classpath:data/commercialhierarchy/commercialhierarchy-dataset.xml",
                    "classpath:data/pod/rol/rol-parameters-dataset.xml",
                    "classpath:data/pod/rol/counter-price-dataset.xml", "classpath:data/core/charge-group-dataset.xml",
                    "classpath:data/core/charge-group-nf-dataset.xml", "classpath:data/pod/credit/credit-dataset.xml"
            );
        }

        // Load rol status
        loadRolStatus();
        loadChargeConsolidateTypes();

        // Load Posting Reference and Account
        loadPostingReferenceAndAccount();

        // Load the ITS logger user
        ItsUser itsUser = (ItsUser) this.getSession().get(ItsUser.class, 900000004L);
        this.billableProvider.setItsUser(itsUser);
    }

    private void loadPostingReferenceAndAccount() {
        PostingReference postingReference = postingService
                .getPostingReferenceByType(ReferenceNameEnum.BAIXA_NC_POD);
        if (postingReference == null) {
            DbUnitHelper
                    .setup("classpath:data/core/posting_account_posting_reference_dataset.xml");
        }
    }

    private void loadRolStatus() {
        // Load rol status
        if (reportOnlineDAO.findRolStatusByCode(RolStatus.ROL_STATUS_REPORTED) == null) {
            saveAndFlush(new RolStatus(800000001L, RolStatus.ROL_STATUS_REPORTED, "pod.rol.parameter.status.report.pod"));
        }

        if (reportOnlineDAO.findRolStatusByCode(RolStatus.ROL_STATUS_PROCESSED) == null) {
            saveAndFlush(new RolStatus(800000002L, RolStatus.ROL_STATUS_PROCESSED,
                    "pod.rol.parameter.status.processed.pod"));
        }

        if (reportOnlineDAO.findRolStatusByCode(RolStatus.ROL_STATUS_RELEASED) == null) {
            saveAndFlush(new RolStatus(800000003L, RolStatus.ROL_STATUS_RELEASED,
                    "pod.rol.parameter.status.released.pod"));
        }

        if (reportOnlineDAO.findRolStatusByCode(RolStatus.ROL_STATUS_RESERVED) == null) {
            saveAndFlush(new RolStatus(800000004L, RolStatus.ROL_STATUS_RESERVED,
                    "pod.rol.parameter.status.reserved.pod"));
        }

        if (reportOnlineDAO.findRolStatusByCode(RolStatus.ROL_STATUS_RTV) == null) {
            saveAndFlush(new RolStatus(800000005L, RolStatus.ROL_STATUS_RTV, "pod.rol.parameter.status.rtv.pod"));
        }

        if (reportOnlineDAO.findRolStatusByCode(RolStatus.ROL_STATUS_CORRECTED) == null) {
            saveAndFlush(new RolStatus(800000006L, RolStatus.ROL_STATUS_CORRECTED,
                    "pod.rol.parameter.status.corrected.pod"));
        }

    }

    private void loadChargeConsolidateTypes() {

        CompanyCropAccountNumber cc = (CompanyCropAccountNumber) this.getSession().get(CompanyCropAccountNumber.class,
                new Long(999000001L));

        Map<ChargeConsolidateTypeEnum, ChargeConsolidateType> map = chargeConsolidateService
                .findMapOfAllChargeConsolidateTypes();
        ChargeConsolidateTypeEnum[] values = ChargeConsolidateTypeEnum.values();

        int i = 0;
        for (ChargeConsolidateTypeEnum item : values) {
            if (!map.containsKey(item)) {
                ChargeConsolidateType type = new ChargeConsolidateType();
                type.setId(9999999900L + i);
                type.setChargeConsTypeCode(item);
                type.setChargeConsTypeBundle("bundle.teste");
                type.setCompanyCropAccountNumber(cc);
                type.setImported(item.isImported());
                type.setChargeConsolidateOrigin(item.getChargeConsOriginCode());
                saveAndFlush(type);

                i++;
            }
        }

    }

    private void createValueOfChrg(Date period) {

        Crop crop = (Crop) this.getSession().get(Crop.class, new Long(900000001L));

        // Get all the company technologies
        Company company = (Company) this.getSession().get(Company.class, new Long(990000002L));
        List<Technology> listTechnologies = this.technologyDAO.selectAllTechnology(company);
        for (Technology technology : listTechnologies) {

            // Prepare the value of charge of all technologies
            CounterPriceFilter filter = new CounterPriceFilter();
            filter.setTechnology(technology);
            filter.setPeriod(period);
            filter.setCompany(company);
            filter.setCrop(crop);
            ValueOfChrgByTon charge = this.rolInformationService.selectValueOfChrgByTonByFilter(filter);
            if (charge.getId() == null) {

                // Persist the charge of value
                charge = new ValueOfChrgByTon();
                charge.setCrop(crop);
                charge.setPeriod(period);
                charge.setTechnology(technology);
                charge.setValue(new BigDecimal("0.30"));
                this.saveAndFlush(charge);
            }
        }
    }

    private Long createCreditConsumption(HeadOffice headOffice, Date period, OperationalYear operationalYear) {

        // Get a user
        ItsUser user = (ItsUser) this.getSession().get(ItsUser.class, new Long(900000001L));
        Crop crop = (Crop) this.getSession().get(Crop.class, new Long(900000001L));
        Grower grower = this.createGrower();

        // Create the credit consumption
        CreditConsumption creditConsumption = new CreditConsumption();
        creditConsumption.setHeadoffice(headOffice);
        creditConsumption.setCreditConsumptionDate(period);
        creditConsumption.setItsUserLogin(user.getLogin());
        creditConsumption.setCreditConsumptionStatus(CreditConsumptionStatus.PROCESSED);
        creditConsumption.setGrower(grower);
        this.saveAndFlush(creditConsumption);

        // Get all the company technologies
        Company company = (Company) this.getSession().get(Company.class, new Long(990000002L));
        List<Technology> listTechnologies = this.technologyDAO.selectAllTechnology(company);
        for (Technology technology : listTechnologies) {

            // Create the credit consumption item
            CreditConsumptionItem item = new CreditConsumptionItem();
            item.setCreditConsumption(creditConsumption);
            item.setRequestValue(new BigDecimal("1000.0"));
            item.setGrower(grower);
            item.setOperationalYear(operationalYear);
            item.setCrop(crop);
            item.setTechnology(technology);
            this.saveAndFlush(item);

            item = new CreditConsumptionItem();
            item.setCreditConsumption(creditConsumption);
            item.setRequestValue(new BigDecimal("2000.0"));
            item.setGrower(grower);
            item.setOperationalYear(operationalYear);
            item.setCrop(crop);
            item.setTechnology(technology);
            this.saveAndFlush(item);
        }

        return creditConsumption.getId();
    }

    private Grower createGrower() {
        DocumentType documentType = (DocumentType) this.getSession().get(DocumentType.class, new Long(900000001L));
        Document document = new Document();
        document.setDocumentType(documentType);
        document.setValue("1");

        Country country = (Country) this.getSession().get(Country.class, new Long(990000001L));
        BusinessAddress businessAddress = new BusinessAddress();
        businessAddress.setCountry(country);
        businessAddress.setZipCode("12345123");
        businessAddress.setNumber("123");
        businessAddress.setTelephone("12345678");
        businessAddress.setComplement("1");
        businessAddress.setStreet("Rua");
        businessAddress.setNeighborhood("Bairro");

        BillingAddress billingAddress = new BillingAddress();
        billingAddress.setCountry(country);
        billingAddress.setZipCode("12345123");
        billingAddress.setNumber("123");
        billingAddress.setTelephone("12345678");
        billingAddress.setComplement("1");
        billingAddress.setStreet("Rua");
        billingAddress.setNeighborhood("Bairro");

        Grower grower = new Grower();
        grower.setName("Teste");
        grower.setDocument(document);
        grower.setBusinessAddress(businessAddress);
        grower.setBillingAddress(billingAddress);
        grower.setEmail("teste@teste.com");
        grower.setStatus(true);
        this.saveAndFlush(grower);

        return grower;
    }

    private Long createROL(OperationalYear operationalYear, Date period, HeadOffice headoffice, RolStatus rolStatus,
                           String sapCode, boolean sendToErp, BigDecimal tonValue, BigDecimal monetaryValue) {

        return doCreateROL(operationalYear, period, headoffice, rolStatus, sapCode, sendToErp, tonValue, monetaryValue)
                .getId();
    }

    private ReportOnLine doCreateROL(OperationalYear operationalYear, Date period, HeadOffice headoffice,
                                     RolStatus rolStatus, String sapCode, boolean sendToErp, BigDecimal tonValue, BigDecimal monetaryValue) {

        // Prepare the information to persist the first ROL
        Crop crop = (Crop) this.getSession().get(Crop.class, new Long(900000001L));
        ItsUser user = (ItsUser) this.getSession().get(ItsUser.class, new Long(900000001L));

        ReportOnLine rol = new ReportOnLine();
        rol.setRolStatus(rolStatus);
        rol.setOperationalYear(operationalYear);
        rol.setCrop(crop);
        rol.setRolPeriod(period);
        rol.setHeadoffice(headoffice);
        rol.setRolCreateDate(period);
        rol.setItsUserLogin(user.getLogin());
        rol.setRolSendDate(period);
        this.saveAndFlush(rol);

        CommissionType commissionType = (CommissionType) this.getSession().get(CommissionType.class,
                new Long(900000001L));
        RolFrameGroup rolFrameGroup = (RolFrameGroup) this.getSession().get(RolFrameGroup.class, new Long(1L));
        OperationalYearType operationalYearType = (OperationalYearType) this.getSession().get(
                OperationalYearType.class, new Long(900000001L));
        Technology technology = (Technology) this.getSession().get(Technology.class, new Long(900000001L));

        RolParameter rolParameter = new RolParameter();
        rolParameter.setCommissionType(commissionType);
        rolParameter.setRolFrameGroup(rolFrameGroup);
        rolParameter.setOperationalYearType(operationalYearType);
        rolParameter.setTechnology(technology);
        rolParameter.setCrop(crop);
        rolParameter.setRolParameterDescription("Description");
        rolParameter.setRolParamShownDescription("Shown description");
        rolParameter.setRolParameterSequence(new Integer(1));
        if (!StringUtils.isNullOrEmpty(sapCode)) {
            rolParameter.setRolParameterMaterialSapId(sapCode);
        }
        rolParameter.setRolParameterSendToErp(sendToErp);
        this.saveAndFlush(rolParameter);

        UsedRolParameter usedRolParameter = new UsedRolParameter();
        usedRolParameter.setReportOnLine(rol);
        usedRolParameter.setRolParameter(rolParameter);
        usedRolParameter.setUsedRolParameterTonValue(tonValue);
        usedRolParameter.setUsedRolParamMonetaryVal(monetaryValue);
        this.saveAndFlush(usedRolParameter);

        return rol;

    }

    private Long createCreditConsumption(ReportOnLine rol, Technology technology) {
        return this.doCreateCreditConsumption(rol, technology).getId();
    }

    private CreditConsumption doCreateCreditConsumption(ReportOnLine rol, Technology technology) {

        // Prepare the information to persist the first ROL
        Grower grower = (Grower) getSession().get(Grower.class, 900000033L);
        Assert.assertNotNull(grower);

        ItsUser itsUser = (ItsUser) this.getSession().get(ItsUser.class, 900000004L);
        Assert.assertNotNull(itsUser);

        OperationalYear operationalYear = (OperationalYear) this.getSession().get(OperationalYear.class, 900000001L);
        Assert.assertNotNull(operationalYear);

        CreditConsumption creditConsumption = new CreditConsumption();
        creditConsumption.setHeadoffice(rol.getHeadoffice());
        creditConsumption.setCreditConsumptionDate(rol.getRolPeriod());
        creditConsumption.setCreditConsumptionStatus(CreditConsumptionStatus.OPENED);
        creditConsumption.setGrower(grower);
        creditConsumption.setItsUserLogin(itsUser.getLogin());
        this.saveAndFlush(creditConsumption);

        CreditConsumptionItem creditConsumptionItem = new CreditConsumptionItem();
        creditConsumptionItem.setCreditConsumption(creditConsumption);
        creditConsumptionItem.setTechnology(technology);
        creditConsumptionItem.setRequestValue(new BigDecimal(10));
        creditConsumptionItem.setCrop(rol.getCrop());
        creditConsumptionItem.setGrower(grower);
        creditConsumptionItem.setOperationalYear(operationalYear);
        this.saveAndFlush(creditConsumptionItem);

        return creditConsumption;
    }

    private void doCreateValueOfChrByTon(ReportOnLine rol, Technology technology) {
        ValueOfChrgByTon charge = new ValueOfChrgByTon();
        charge.setCrop(rol.getCrop());
        charge.setPeriod(rol.getRolPeriod());
        charge.setTechnology(technology);
        charge.setValue(new BigDecimal(10));
        this.saveAndFlush(charge);
    }

    private Long createROLWith2Param(OperationalYear operationalYear, Date period, HeadOffice headoffice,
                                     RolStatus rolStatus, String sapCode1, String sapCode2, boolean sendToErp, BigDecimal tonValue,
                                     BigDecimal monetaryValue) {

        // Prepare the information to persist the first ROL
        Crop crop = (Crop) this.getSession().get(Crop.class, new Long(900000001L));

        ReportOnLine rol = new ReportOnLine();
        rol.setRolStatus(rolStatus);
        rol.setOperationalYear(operationalYear);
        rol.setCrop(crop);
        rol.setRolPeriod(period);
        rol.setHeadoffice(headoffice);
        rol.setRolCreateDate(period);
        this.saveAndFlush(rol);

        CommissionType commissionType = (CommissionType) this.getSession().get(CommissionType.class,
                new Long(900000001L));
        RolFrameGroup rolFrameGroup = (RolFrameGroup) this.getSession().get(RolFrameGroup.class, new Long(1L));
        OperationalYearType operationalYearType = (OperationalYearType) this.getSession().get(
                OperationalYearType.class, new Long(900000001L));
        Technology technology = (Technology) this.getSession().get(Technology.class, new Long(900000001L));

        RolParameter rolParameter = new RolParameter();
        rolParameter.setCommissionType(commissionType);
        rolParameter.setRolFrameGroup(rolFrameGroup);
        rolParameter.setOperationalYearType(operationalYearType);
        rolParameter.setTechnology(technology);
        rolParameter.setCrop(crop);
        rolParameter.setRolParameterDescription("Description");
        rolParameter.setRolParamShownDescription("Shown description");
        rolParameter.setRolParameterSequence(new Integer(1));
        if (!StringUtils.isNullOrEmpty(sapCode1)) {
            rolParameter.setRolParameterMaterialSapId(sapCode1);
        }
        rolParameter.setRolParameterSendToErp(sendToErp);
        this.saveAndFlush(rolParameter);

        UsedRolParameter usedRolParameter = new UsedRolParameter();
        usedRolParameter.setReportOnLine(rol);
        usedRolParameter.setRolParameter(rolParameter);
        usedRolParameter.setUsedRolParameterTonValue(tonValue);
        usedRolParameter.setUsedRolParamMonetaryVal(monetaryValue);
        this.saveAndFlush(usedRolParameter);

        rolParameter = new RolParameter();
        rolParameter.setCommissionType(commissionType);
        rolParameter.setRolFrameGroup(rolFrameGroup);
        rolParameter.setOperationalYearType(operationalYearType);
        rolParameter.setTechnology(technology);
        rolParameter.setCrop(crop);
        rolParameter.setRolParameterDescription("Description");
        rolParameter.setRolParamShownDescription("Shown description");
        rolParameter.setRolParameterSequence(new Integer(1));
        if (!StringUtils.isNullOrEmpty(sapCode2)) {
            rolParameter.setRolParameterMaterialSapId(sapCode2);
        }
        rolParameter.setRolParameterSendToErp(sendToErp);
        this.saveAndFlush(rolParameter);

        usedRolParameter = new UsedRolParameter();
        usedRolParameter.setReportOnLine(rol);
        usedRolParameter.setRolParameter(rolParameter);
        usedRolParameter.setUsedRolParameterTonValue(tonValue);
        usedRolParameter.setUsedRolParamMonetaryVal(monetaryValue);
        this.saveAndFlush(usedRolParameter);

        return rol.getId();
    }

    private void createChargeConsolidate(Date period, ChargeConsolidateTypeEnum type, ChargeConsolidateStatus status,
                                         ChargeConsolidateStatus oldStatus) {

        // Get the contract
        Contract contract = (Contract) this.getSession().get(Contract.class, new Long(900000003L));
        ChargeConsolidateType typeDB = chargeConsolidateService.findConsolidateType(type);

        ChargeConsolidate chargeConsolidate = new ChargeConsolidate();
        chargeConsolidate.setChargeConsolidateBillDate(period);
        chargeConsolidate.setChargeConsolidateBillNum(new Long(1L));
        chargeConsolidate.setChargeConsolidateHarvest("Harvest");
        chargeConsolidate.setChargeConsolidateOrigin(ChargeConsolidateOrigin.GRAINRECEIVE);
        chargeConsolidate.setChargeConsolidatePeriod(period);
        chargeConsolidate.setChargeConsolidateStatus(status);
        chargeConsolidate.setChargeConsolidateStatusOld(oldStatus);
        chargeConsolidate.setChargeConsolidateType(typeDB);
        chargeConsolidate.setChargeConsolidateValue(new BigDecimal("10.0"));
        chargeConsolidate.setContract(contract);
        this.saveAndFlush(chargeConsolidate);
    }

    private RolStatus getROLStatus(String statusCode) {

        // Get the ROL status and persist the ROL
        RolStatus rolStatus = (RolStatus) this.getSession().get(RolStatus.class, new Long(900000004L));
        List<RolStatus> lstRolStatus = this.rolInformationService.selectAllRolStatus();
        if ((lstRolStatus != null) && (lstRolStatus.size() > 0)) {
            for (RolStatus rolStatus2 : lstRolStatus) {
                if (statusCode.equals(rolStatus2.getRolStatusCode())) {
                    rolStatus = rolStatus2;
                    break;
                }
            }
        }

        return rolStatus;
    }

    private OperationalYear getOperationalYear(Integer year) {

        OperationalYear operationalYear = null;
        try {

            // Try to find the operational year
            operationalYear = this.operationalYearDAO.getByCandidateKey(year.toString());
        } catch (EntityNotFoundException e) {

            // Create a new operational year
            operationalYear = new OperationalYear(year.toString());
            this.saveAndFlush(operationalYear);
        }
        if (operationalYear == null) {

            // Create a new operational year
            operationalYear = new OperationalYear(year.toString());
            this.saveAndFlush(operationalYear);
        }

        return operationalYear;
    }

    @Test
    public void consolidate_rol_by_revenue_code_null() throws BusinessException {

        this.setupDBUnitWithAffiliates(true);

        // Transform a null list of ROLs
        Company company = (Company) this.getSession().get(Company.class, new Long(990000002L));
        List<Billable> listDTO = this.billableProvider.getBillables(company);

        // Assert no ROLs were consolidated
        Assert.assertNotNull("The ROLs consolidated should exist.", listDTO);
        Assert.assertEquals("The ROLs consolidated numbers were different.", 0, listDTO.size());
    }

    @Test
    public void consolidate_rol_by_revenue_code_empty() throws BusinessException {

        this.setupDBUnitWithAffiliates(true);

        // Transform an empty list of ROLs
        Company company = (Company) this.getSession().get(Company.class, new Long(990000002L));
        List<Billable> listDTO = this.billableProvider.getBillables(company);

        // Assert no ROLs were consolidated
        Assert.assertNotNull("The ROLs consolidated should exist.", listDTO);
        Assert.assertEquals("The ROLs consolidated numbers were different.", 0, listDTO.size());
    }

    /**
     * This scenario is:
     * <p/>
     * There are 4 ROLs in status "RELEASED" and in the current period. Each ROL
     * has an used ROL parameter with one SAP code (the 4 used ROL parameter
     * have the same SAP code). So, there will be created 4 billable objects,
     * each one with the handle code being a ROL id.
     */
    @Test
    public void consolidate_rol_by_revenue_code_status_released_and_current_period() throws BusinessException {

        this.setupDBUnitWithAffiliates(false);

        // Create the basic information (operational year and period)
        Date now = CalendarUtil.getDateNow();
        Integer year = new Integer(CalendarUtil.getDateYear(now) + 10);
        OperationalYear operationalYear = new OperationalYear(year.toString());
        this.saveAndFlush(operationalYear);
        Date period = CalendarUtil.getDate(year, CalendarUtil.getDateMonth(now), 15);

        // Get the ROL status
        RolStatus rolStatus = this.getROLStatus(RolStatus.ROL_STATUS_RELEASED);
        List<Long> listROLId = new ArrayList<Long>();

        // Create the "released" ROL to the matrix in the current period
        HeadOffice headoffice = (HeadOffice) this.getSession().get(HeadOffice.class, new Long(900000001L));
        Long id = this.createROL(operationalYear, period, headoffice, rolStatus, "TesteSAP", false, new BigDecimal(
                "10.0"), new BigDecimal("20.0"));
        listROLId.add(id);

        // Create the "released" ROL to one headoffice in the current period
        headoffice = (HeadOffice) this.getSession().get(HeadOffice.class, new Long(900000004L));
        id = this.createROL(operationalYear, period, headoffice, rolStatus, "TesteSAP", false, new BigDecimal("10.0"),
                new BigDecimal("20.0"));
        listROLId.add(id);

        // Create the "released" ROL to one headoffice in the current period
        headoffice = (HeadOffice) this.getSession().get(HeadOffice.class, new Long(900000006L));
        id = this.createROL(operationalYear, period, headoffice, rolStatus, "TesteSAP", false, new BigDecimal("10.0"),
                new BigDecimal("20.0"));
        listROLId.add(id);

        // Create the "released" ROL to one headoffice in the current period
        headoffice = (HeadOffice) this.getSession().get(HeadOffice.class, new Long(900000007L));
        id = this.createROL(operationalYear, period, headoffice, rolStatus, "TesteSAP", false, new BigDecimal("10.0"),
                new BigDecimal("20.0"));
        listROLId.add(id);

        // Transform a list of ROLs in billable objects
        Company company = (Company) this.getSession().get(Company.class, new Long(990000002L));
        List<Billable> listDTO = this.billableProvider.getBillables(company);

        // Assert the billable objects were created
        Assert.assertNotNull("The ROLs consolidated should exist.", listDTO);
        for (Billable billable : listDTO) {

            // Assert the billable objects were created correctly
            Assert.assertTrue("The billable objects were created incorrectly.",
                    listROLId.contains(billable.getCodeHandle()));

            // Assert there is no additional condition to this billable object
            Assert.assertNull("The billable object mustn't have additional condition.",
                    billable.getAdditionalConditions());

            // Assert the volume was created correctly (10 ton)
            Assert.assertEquals("Volume was created incorrectly.", new BigDecimal("10.0"), billable.getAmount());
        }

        // Assert no ROLs were billed
        for (Long rolId : listROLId) {

            ReportOnLine rol = this.reportOnlineDAO.findById(rolId);
            Assert.assertTrue("ROL is billed.",
                    !RolStatus.ROL_STATUS_PROCESSED.equals(rol.getRolStatus().getRolStatusCode()));
        }
    }

    /**
     * This scenario is:
     * <p/>
     * There are 4 ROLs in status "RELEASED" and in a past period (one year
     * ago). Each ROL has an used ROL parameter with one SAP code (the 4 used
     * ROL parameter have the same SAP code). So, there will be created 4
     * billable objects, each one with the handle code being a ROL id.
     */
    @Test
    public void consolidate_rol_by_revenue_code_status_released_and_past_period() throws BusinessException {

        this.setupDBUnitWithAffiliates(false);

        // Create the basic information (operational year and period)
        Date now = CalendarUtil.getDateNow();
        Integer year = new Integer(CalendarUtil.getDateYear(now) - 1);
        OperationalYear operationalYear = this.getOperationalYear(year);
        Date period = CalendarUtil.getDate(year, CalendarUtil.getDateMonth(now), 15);

        // Get the ROL status
        RolStatus rolStatus = this.getROLStatus(RolStatus.ROL_STATUS_RELEASED);
        List<Long> listROLId = new ArrayList<Long>();

        // Create the "released" ROL to the matrix in the past period
        HeadOffice headoffice = (HeadOffice) this.getSession().get(HeadOffice.class, new Long(900000001L));
        Long id = this.createROL(operationalYear, period, headoffice, rolStatus, "TesteSAP", false, new BigDecimal(
                "10.0"), new BigDecimal("20.0"));
        listROLId.add(id);

        // Create the "released" ROL to one headoffice in the past period
        headoffice = (HeadOffice) this.getSession().get(HeadOffice.class, new Long(900000004L));
        id = this.createROL(operationalYear, period, headoffice, rolStatus, "TesteSAP", false, new BigDecimal("10.0"),
                new BigDecimal("20.0"));
        listROLId.add(id);

        // Create the "released" ROL to one headoffice in the past period
        headoffice = (HeadOffice) this.getSession().get(HeadOffice.class, new Long(900000006L));
        id = this.createROL(operationalYear, period, headoffice, rolStatus, "TesteSAP", false, new BigDecimal("10.0"),
                new BigDecimal("20.0"));
        listROLId.add(id);

        // Create the "released" ROL to one headoffice in the past period
        headoffice = (HeadOffice) this.getSession().get(HeadOffice.class, new Long(900000007L));
        id = this.createROL(operationalYear, period, headoffice, rolStatus, "TesteSAP", false, new BigDecimal("10.0"),
                new BigDecimal("20.0"));
        listROLId.add(id);

        // Transform a list of ROLs in billable objects
        Company company = (Company) this.getSession().get(Company.class, new Long(990000002L));
        List<Billable> listDTO = this.billableProvider.getBillables(company);

        // Assert the billable objects were created
        Assert.assertNotNull("The ROLs consolidated should exist.", listDTO);
        for (Billable billable : listDTO) {

            // Assert the billable objects were created correctly
            Assert.assertTrue("The billable objects were created incorrectly.",
                    listROLId.contains(billable.getCodeHandle()));

            // Assert there is no additional condition to this billable object
            Assert.assertNull("The billable object mustn't have additional condition.",
                    billable.getAdditionalConditions());

            // Assert the volume was created correctly (10 ton)
            Assert.assertEquals("Volume was created incorrectly.", new BigDecimal("10.0"), billable.getAmount());
        }
    }

    /**
     * This scenario is:
     * <p/>
     * There are 3 ROLs in status "RELEASED" and in past period (one year ago),
     * and one ROL in status "REPORTED". Each ROL has an used ROL parameter with
     * one SAP code (the 4 used ROL parameter have the same SAP code). So, there
     * will be created no objects, because the "REPORTED" ROL is in the past.
     */
    @Test
    public void consolidate_rol_by_revenue_code_status_released_and_reported_and_past_period() throws BusinessException {

        this.setupDBUnitWithAffiliates(false);

        // Create the basic information (operational year and period)
        Date now = CalendarUtil.getDateNow();
        Integer year = new Integer(CalendarUtil.getDateYear(now) - 1);
        OperationalYear operationalYear = this.getOperationalYear(year);
        Date period = CalendarUtil.getDate(year, CalendarUtil.getDateMonth(now), 15);

        // Get the ROL status
        RolStatus rolStatus = this.getROLStatus(RolStatus.ROL_STATUS_RELEASED);
        List<Long> listROLId = new ArrayList<Long>();

        // Create the "released" ROL to the matrix in the past period
        HeadOffice headoffice = (HeadOffice) this.getSession().get(HeadOffice.class, new Long(900000001L));
        Long id = this.createROL(operationalYear, period, headoffice, rolStatus, "TesteSAP", false, new BigDecimal(
                "10.0"), new BigDecimal("20.0"));
        listROLId.add(id);

        // Create the "released" ROL to one headoffice in the past period
        headoffice = (HeadOffice) this.getSession().get(HeadOffice.class, new Long(900000004L));
        id = this.createROL(operationalYear, period, headoffice, rolStatus, "TesteSAP", false, new BigDecimal("10.0"),
                new BigDecimal("20.0"));
        listROLId.add(id);

        // Create the "released" ROL to one headoffice in the past period
        headoffice = (HeadOffice) this.getSession().get(HeadOffice.class, new Long(900000006L));
        id = this.createROL(operationalYear, period, headoffice, rolStatus, "TesteSAP", false, new BigDecimal("10.0"),
                new BigDecimal("20.0"));
        listROLId.add(id);

        // Create the "reported" ROL to one headoffice in the past period
        rolStatus = this.getROLStatus(RolStatus.ROL_STATUS_REPORTED);
        headoffice = (HeadOffice) this.getSession().get(HeadOffice.class, new Long(900000007L));
        id = this.createROL(operationalYear, period, headoffice, rolStatus, "TesteSAP", false, new BigDecimal("10.0"),
                new BigDecimal("20.0"));
        listROLId.add(id);

        // Transform a list of ROLs in billable objects
        Company company = (Company) this.getSession().get(Company.class, new Long(990000002L));
        List<Billable> listDTO = this.billableProvider.getBillables(company);

        // Assert the billable objects were not created
        Assert.assertNotNull("The ROLs consolidated should not exist.", listDTO);
        Assert.assertEquals("The ROLs consolidated should not exist.", 4, listDTO.size());
    }

    /**
     * This scenario is:
     * <p/>
     * There are 3 ROLs in status "RELEASED" and in the current period (one year
     * ago), and there are one affiliate without ROL. Each ROL has an used ROL
     * parameter with one SAP code (the 3 used ROL parameter have the same SAP
     * code). So, there will be created 3 billable objects, because the method
     * will consider an in-memory ROL to the affiliate that has no ROL and,
     * thus, this ROL will be in "REPORTED" status and in the current period.
     */
    @Test
    public void consolidate_rol_by_revenue_code_status_released_and_reported_and_current_period()
            throws BusinessException {

        this.setupDBUnitWithAffiliates(false);

        // Create the basic information (operational year and period)
        Date now = CalendarUtil.getDateNow();
        Integer year = new Integer(CalendarUtil.getDateYear(now));
        OperationalYear operationalYear = this.getOperationalYear(year);
        Date period = CalendarUtil.getDate(year, CalendarUtil.getDateMonth(now), 15);

        // Get the ROL status
        RolStatus rolStatus = this.getROLStatus(RolStatus.ROL_STATUS_RELEASED);
        List<Long> listROLId = new ArrayList<Long>();

        // Create the "released" ROL to the matrix in the current period
        HeadOffice headoffice = (HeadOffice) this.getSession().get(HeadOffice.class, new Long(900000001L));
        Long id = this.createROL(operationalYear, period, headoffice, rolStatus, "TesteSAP", true, new BigDecimal(
                "10.0"), new BigDecimal("20.0"));
        listROLId.add(id);

        // Create the "released" ROL to one headoffice in the current period
        headoffice = (HeadOffice) this.getSession().get(HeadOffice.class, new Long(900000004L));
        id = this.createROL(operationalYear, period, headoffice, rolStatus, "TesteSAP", true, new BigDecimal("10.0"),
                new BigDecimal("20.0"));
        listROLId.add(id);

        // Create the "released" ROL to one headoffice in the current period
        headoffice = (HeadOffice) this.getSession().get(HeadOffice.class, new Long(900000006L));
        id = this.createROL(operationalYear, period, headoffice, rolStatus, "TesteSAP", true, new BigDecimal("10.0"),
                new BigDecimal("20.0"));
        listROLId.add(id);

        // Transform a list of ROLs in billable objects (there is one ROL that
        // will be considered only in memory)
        Company company = (Company) this.getSession().get(Company.class, new Long(990000002L));
        List<Billable> listDTO = this.billableProvider.getBillables(company);

        // Assert the billable objects were created
        Assert.assertNotNull("The ROLs consolidated should exist.", listDTO);
        for (Billable billable : listDTO) {

            // Assert the billable objects were created correctly
            Assert.assertTrue("The billable objects were created incorrectly.",
                    listROLId.contains(billable.getCodeHandle()));

            // Assert there is no additional condition to this billable object
            Assert.assertNull("The billable object mustn't have additional condition.",
                    billable.getAdditionalConditions());

            // Assert the volume was created correctly (10 ton)
            Assert.assertEquals("Volume was created incorrectly.", new BigDecimal("10.0"), billable.getAmount());
            Assert.assertTrue("Value was created incorrectly.", billable.getValue().compareTo(BigDecimal.ZERO) > 0);
        }
    }

    /**
     * This scenario is:
     * <p/>
     * There are 4 ROLs in status "RELEASED" and in the current period. Each ROL
     * has an used ROL parameter with no SAP code. So, there will be created no
     * billable objects.
     */
    @Test
    public void consolidate_rol_by_revenue_code_sap_empty() throws BusinessException {
        this.setupDBUnitWithAffiliates(false);

        // Create the basic information (operational year and period)
        Date now = CalendarUtil.getDateNow();
        Integer year = new Integer(CalendarUtil.getDateYear(now) + 10);
        OperationalYear operationalYear = new OperationalYear(year.toString());
        this.saveAndFlush(operationalYear);
        Date period = CalendarUtil.getDate(year, CalendarUtil.getDateMonth(now), 15);

        // Get the ROL status
        RolStatus rolStatus = this.getROLStatus(RolStatus.ROL_STATUS_RELEASED);

        // Create the ROL to the matrix
        HeadOffice headoffice = (HeadOffice) this.getSession().get(HeadOffice.class, new Long(900000001L));
        this.createROL(operationalYear, period, headoffice, rolStatus, null, false, new BigDecimal("10.0"),
                new BigDecimal("20.0"));

        // Create the ROL to one headoffice
        headoffice = (HeadOffice) this.getSession().get(HeadOffice.class, new Long(900000004L));
        this.createROL(operationalYear, period, headoffice, rolStatus, null, false, new BigDecimal("10.0"),
                new BigDecimal("20.0"));

        // Create the ROL to one headoffice
        headoffice = (HeadOffice) this.getSession().get(HeadOffice.class, new Long(900000006L));
        this.createROL(operationalYear, period, headoffice, rolStatus, null, false, new BigDecimal("10.0"),
                new BigDecimal("20.0"));

        // Create the ROL to one headoffice
        headoffice = (HeadOffice) this.getSession().get(HeadOffice.class, new Long(900000007L));
        this.createROL(operationalYear, period, headoffice, rolStatus, null, false, new BigDecimal("10.0"),
                new BigDecimal("20.0"));

        // Get the ROLs DTO grouped by period and headoffice
        List<ReportOnLine> listReportOnLine = this.rolInformationService.selectROLConsolidate(
                RolStatus.ROL_STATUS_RELEASED, RolStatus.ROL_STATUS_REPORTED, null);

        // Transform a list of ROLs in billable objects
        this.billableProvider.setSources(listReportOnLine);
        Company company = (Company) this.getSession().get(Company.class, new Long(990000002L));
        List<Billable> listDTO = this.billableProvider.getBillables(company);

        // Assert no ROLs were consolidated
        Assert.assertNotNull("The ROLs consolidated should exist.", listDTO);
        Assert.assertEquals("The ROLs consolidated numbers were different.", 0, listDTO.size());
    }

    /**
     * This scenario is:
     * <p/>
     * There are 4 ROLs in status "RELEASED" and in the current period. Each ROL
     * has an used ROL parameter with one SAP code (2 used ROL parameter have
     * the same SAP code and other 2 used ROL parameter have another SAP code).
     * So, there will be created 4 billable objects, each one with the handle
     * code being a ROL id.
     */
    @Test
    public void consolidate_rol_by_revenue_two_codes() throws BusinessException {
        this.setupDBUnitWithAffiliates(false);

        // Create the basic information (operational year and period)
        Date now = CalendarUtil.getDateNow();
        Integer year = new Integer(CalendarUtil.getDateYear(now) + 10);
        OperationalYear operationalYear = new OperationalYear(year.toString());
        this.saveAndFlush(operationalYear);
        Date period = CalendarUtil.getDate(year, CalendarUtil.getDateMonth(now), 15);

        // Get the ROL status
        RolStatus rolStatus = this.getROLStatus(RolStatus.ROL_STATUS_RELEASED);
        List<Long> listROLId = new ArrayList<Long>();

        // Create the ROL to the matrix
        HeadOffice headoffice = (HeadOffice) this.getSession().get(HeadOffice.class, new Long(900000001L));
        Long id = this.createROL(operationalYear, period, headoffice, rolStatus, "TesteSAP1", false, new BigDecimal(
                "10.0"), new BigDecimal("20.0"));
        listROLId.add(id);

        // Create the ROL to one headoffice
        headoffice = (HeadOffice) this.getSession().get(HeadOffice.class, new Long(900000004L));
        id = this.createROL(operationalYear, period, headoffice, rolStatus, "TesteSAP1", false, new BigDecimal("10.0"),
                new BigDecimal("20.0"));
        listROLId.add(id);

        // Create the ROL to one headoffice
        headoffice = (HeadOffice) this.getSession().get(HeadOffice.class, new Long(900000006L));
        id = this.createROL(operationalYear, period, headoffice, rolStatus, "TesteSAP2", false, new BigDecimal("10.0"),
                new BigDecimal("20.0"));
        listROLId.add(id);

        // Create the ROL to one headoffice
        headoffice = (HeadOffice) this.getSession().get(HeadOffice.class, new Long(900000007L));
        id = this.createROL(operationalYear, period, headoffice, rolStatus, "TesteSAP2", false, new BigDecimal("10.0"),
                new BigDecimal("20.0"));
        listROLId.add(id);

        // Get the ROLs DTO grouped by period and headoffice
        List<ReportOnLine> listReportOnLine = this.rolInformationService.selectROLConsolidate(
                RolStatus.ROL_STATUS_RELEASED, RolStatus.ROL_STATUS_REPORTED, null);

        // Transform a list of ROLs in billable objects
        this.billableProvider.setSources(listReportOnLine);
        Company company = (Company) this.getSession().get(Company.class, new Long(990000002L));
        List<Billable> listDTO = this.billableProvider.getBillables(company);

        // Assert no ROLs were consolidated
        Assert.assertNotNull("The ROLs consolidated should exist.", listDTO);
        for (Billable billable : listDTO) {

            // Assert the billable objects were created correctly
            Assert.assertTrue("The billable objects were created incorrectly.",
                    listROLId.contains(billable.getCodeHandle()));

            // Assert there is no additional condition to this billable object
            Assert.assertNull("The billable object mustn't have additional condition.",
                    billable.getAdditionalConditions());

            // Assert the volume was created correctly (10 ton)
            Assert.assertEquals("Volume was created incorrectly.", new BigDecimal("10.0"), billable.getAmount());
        }
    }

    /**
     * This scenario is:
     * <p/>
     * There are 4 ROLs in status "RELEASED" and in the current period. Each ROL
     * has an used ROL parameter with one SAP code (the 4 used ROL parameter
     * have the same SAP code). There is also credit consumption to the first
     * ROL. So, there will be created 4 billable objects, each one with the
     * handle code being a ROL id and there will be additional condition to the
     * first one.
     */
    @Test
    public void consolidate_rol_by_revenue_code_status_released_and_current_period_credit_consumption()
            throws BusinessException {

        this.setupDBUnitWithAffiliates(false);

        // Create the basic information (operational year and period)
        Date now = CalendarUtil.getDateNow();
        Integer year = new Integer(CalendarUtil.getDateYear(now) + 10);
        OperationalYear operationalYear = new OperationalYear(year.toString());
        this.saveAndFlush(operationalYear);
        Date period = CalendarUtil.getDate(year, CalendarUtil.getDateMonth(now), 15);

        // Create the value of charge
        this.createValueOfChrg(period);

        // Get the ROL status
        RolStatus rolStatus = this.getROLStatus(RolStatus.ROL_STATUS_RELEASED);
        List<Long> listROLId = new ArrayList<Long>();

        // Create the "released" ROL to the matrix in the current period
        HeadOffice headoffice = (HeadOffice) this.getSession().get(HeadOffice.class, new Long(900000001L));
        Long id = this.createROL(operationalYear, period, headoffice, rolStatus, "TesteSAP", false, new BigDecimal(
                "10.0"), new BigDecimal("20.0"));
        listROLId.add(id);

        // Create the credit consumption to this headoffice
        this.createCreditConsumption(headoffice, period, operationalYear);

        // Create the "released" ROL to one headoffice in the current period
        headoffice = (HeadOffice) this.getSession().get(HeadOffice.class, new Long(900000004L));
        id = this.createROL(operationalYear, period, headoffice, rolStatus, "TesteSAP", false, new BigDecimal("10.0"),
                new BigDecimal("20.0"));
        listROLId.add(id);

        // Create the "released" ROL to one headoffice in the current period
        headoffice = (HeadOffice) this.getSession().get(HeadOffice.class, new Long(900000006L));
        id = this.createROL(operationalYear, period, headoffice, rolStatus, "TesteSAP", false, new BigDecimal("10.0"),
                new BigDecimal("20.0"));
        listROLId.add(id);

        // Create the "released" ROL to one headoffice in the current period
        headoffice = (HeadOffice) this.getSession().get(HeadOffice.class, new Long(900000007L));
        id = this.createROL(operationalYear, period, headoffice, rolStatus, "TesteSAP", false, new BigDecimal("10.0"),
                new BigDecimal("20.0"));
        listROLId.add(id);

        // Transform a list of ROLs in billable objects
        Company company = (Company) this.getSession().get(Company.class, new Long(990000002L));
        List<Billable> listDTO = this.billableProvider.getBillables(company);

        // Assert the billable objects were created
        Assert.assertNotNull("The ROLs consolidated should exist.", listDTO);
        for (Billable billable : listDTO) {

            // Assert the billable objects were created correctly
            Assert.assertTrue("The billable objects were created incorrectly.",
                    listROLId.contains(billable.getCodeHandle()));

            // Assert the volume was created correctly (10 ton)
            Assert.assertEquals("Volume was created incorrectly.", new BigDecimal("10.0"), billable.getAmount());

            // Assert there are additional conditions
            Assert.assertNotNull("The billable object must have additional condition.",
                    billable.getAdditionalConditions());
            for (AdditionalCondition additionalCondition : billable.getAdditionalConditions()) {

                // Assert there is a value
                Assert.assertTrue("The additional condition value is lower than zero.", additionalCondition.getValue()
                        .compareTo(BigDecimal.ZERO) > 0);
            }
        }
    }

    /**
     * This scenario is:
     * <p/>
     * There are 4 ROLs in status "RELEASED" and in the current period. Each ROL
     * has an used ROL parameter with one SAP code (the 4 used ROL parameter
     * have the same SAP code, but their values are zero). So, there will be
     * created 4 billable objects, each one with the handle code being a ROL id
     * and the ROL will be billed.
     */
    @Test
    public void consolidate_rol_by_revenue_code_status_released_and_current_period_with_zero() throws BusinessException {

        this.setupDBUnitWithAffiliates(false);

        // Create the basic information (operational year and period)
        Date now = CalendarUtil.getDateNow();
        Integer year = new Integer(CalendarUtil.getDateYear(now) + 10);
        OperationalYear operationalYear = new OperationalYear(year.toString());
        this.saveAndFlush(operationalYear);
        Date period = CalendarUtil.getDate(year, CalendarUtil.getDateMonth(now), 15);

        // Get the ROL status
        RolStatus rolStatus = this.getROLStatus(RolStatus.ROL_STATUS_RELEASED);
        List<Long> listROLId = new ArrayList<Long>();

        // Create the "released" ROL to the matrix in the current period
        HeadOffice headoffice = (HeadOffice) this.getSession().get(HeadOffice.class, new Long(900000001L));
        Long id = this.createROL(operationalYear, period, headoffice, rolStatus, "TesteSAP", false, new BigDecimal(
                "0.0"), new BigDecimal("0.0"));
        listROLId.add(id);

        // Create the "released" ROL to one headoffice in the current period
        headoffice = (HeadOffice) this.getSession().get(HeadOffice.class, new Long(900000004L));
        id = this.createROL(operationalYear, period, headoffice, rolStatus, "TesteSAP", false, new BigDecimal("0.0"),
                new BigDecimal("0.0"));
        listROLId.add(id);

        // Create the "released" ROL to one headoffice in the current period
        headoffice = (HeadOffice) this.getSession().get(HeadOffice.class, new Long(900000006L));
        id = this.createROL(operationalYear, period, headoffice, rolStatus, "TesteSAP", false, new BigDecimal("0.0"),
                new BigDecimal("0.0"));
        listROLId.add(id);

        // Create the "released" ROL to one headoffice in the current period
        headoffice = (HeadOffice) this.getSession().get(HeadOffice.class, new Long(900000007L));
        id = this.createROL(operationalYear, period, headoffice, rolStatus, "TesteSAP", false, new BigDecimal("0.0"),
                new BigDecimal("0.0"));
        listROLId.add(id);

        // Transform a list of ROLs in billable objects
        Company company = (Company) this.getSession().get(Company.class, new Long(990000002L));
        List<Billable> listDTO = this.billableProvider.getBillables(company);

        // Assert the billable objects were created
        Assert.assertNotNull("The ROLs consolidated should exist.", listDTO);
        for (Billable billable : listDTO) {

            // Assert the billable objects were created correctly
            Assert.assertTrue("The billable objects were created incorrectly.",
                    listROLId.contains(billable.getCodeHandle()));

            // Assert there is no additional condition to this billable object
            Assert.assertNull("The billable object mustn't have additional condition.",
                    billable.getAdditionalConditions());

            // Assert the volume was created correctly (0 ton)
            Assert.assertEquals("Volume was created incorrectly.", new Long("0"), billable.getAmount());
        }

        // Assert all ROLs are billed
        for (Long rolId : listROLId) {

            ReportOnLine rol = this.reportOnlineDAO.findById(rolId);
            Assert.assertTrue("ROL is not billed.",
                    RolStatus.ROL_STATUS_PROCESSED.equals(rol.getRolStatus().getRolStatusCode()));
        }
    }

    /**
     * This scenario is:
     * <p/>
     * There are 4 ROLs in status "RELEASED" and in the current period. Each ROL
     * has an used ROL parameter with no SAP code. So, there will be created no
     * billable objects, but will be created postings.
     */
    @Test
    public void consolidate_rol_by_revenue_code_sap_empty_with_postings() throws BusinessException {
        this.setupDBUnitWithAffiliates(false);

        // Create the basic information (operational year and period)
        Date now = CalendarUtil.getDateNow();
        Integer year = new Integer(CalendarUtil.getDateYear(now) + 10);
        OperationalYear operationalYear = new OperationalYear(year.toString());
        this.saveAndFlush(operationalYear);
        Date period = CalendarUtil.getDate(year, CalendarUtil.getDateMonth(now), 15);

        Technology technology = (Technology) this.getSession().get(Technology.class, 900000005L);
        Assert.assertNotNull(technology);

        // Get the ROL status
        RolStatus rolStatus = this.getROLStatus(RolStatus.ROL_STATUS_RELEASED);

        // Create the ROL to the matrix
        HeadOffice headoffice = (HeadOffice) this.getSession().get(HeadOffice.class, new Long(900000001L));
        ReportOnLine rol = this.doCreateROL(operationalYear, period, headoffice, rolStatus, null, false,
                new BigDecimal("10.0"), new BigDecimal("20.0"));
        Assert.assertNotNull(rol);
        Long createCreditConsumptionId1 = this.createCreditConsumption(rol, technology);
        Assert.assertNotNull(createCreditConsumptionId1);

        // create credit consumption
        Long createCreditConsumptionId2 = this.createCreditConsumption(this.doCreateROL(operationalYear, period,
                headoffice, rolStatus, null, false, new BigDecimal("10.0"), new BigDecimal("20.0")), technology);
        Assert.assertNotNull(createCreditConsumptionId2);

        // Create the ROL to one headoffice
        headoffice = (HeadOffice) this.getSession().get(HeadOffice.class, new Long(900000004L));
        Long createCreditConsumptionId3 = this.createCreditConsumption(this.doCreateROL(operationalYear, period,
                headoffice, rolStatus, null, false, new BigDecimal("10.0"), new BigDecimal("20.0")), technology);
        Assert.assertNotNull(createCreditConsumptionId3);

        // Create the ROL to one headoffice
        headoffice = (HeadOffice) this.getSession().get(HeadOffice.class, new Long(900000006L));
        Long createCreditConsumptionId4 = this.createCreditConsumption(this.doCreateROL(operationalYear, period,
                headoffice, rolStatus, null, false, new BigDecimal("10.0"), new BigDecimal("20.0")), technology);
        Assert.assertNotNull(createCreditConsumptionId4);

        // Create the ROL to one headoffice
        headoffice = (HeadOffice) this.getSession().get(HeadOffice.class, new Long(900000007L));
        Long createCreditConsumptionId5 = this.createCreditConsumption(this.doCreateROL(operationalYear, period,
                headoffice, rolStatus, null, false, new BigDecimal("10.0"), new BigDecimal("20.0")), technology);
        Assert.assertNotNull(createCreditConsumptionId5);

        // Create ValueOfChrByTon
        this.doCreateValueOfChrByTon(rol, technology);

        // Get the ROLs DTO grouped by period and headoffice
        List<ReportOnLine> listReportOnLine = this.rolInformationService.selectROLConsolidate(
                RolStatus.ROL_STATUS_RELEASED, RolStatus.ROL_STATUS_REPORTED, null);

        // Transform a list of ROLs in billable objects
        this.billableProvider.setSources(listReportOnLine);
        Company company = (Company) this.getSession().get(Company.class, new Long(990000002L));
        List<Billable> listDTO = this.billableProvider.getBillables(company);
        List<Posting> listPosting = this.postingService.getAllPendentPostingToSend();

        // Assert no ROLs were consolidated
        Assert.assertNotNull("The ROLs consolidated should exist.", listDTO);
        Assert.assertEquals("The ROLs consolidated numbers were different.", 0, listDTO.size());

        Assert.assertNotNull("The posting should exist.", listPosting);
        Assert.assertEquals("The posting numbers were different.", 4, listPosting.size());

        for (Posting posting : listPosting) {
            Assert.assertFalse(posting.getHasAccounting());
        }
    }

    /**
     * This scenario is:
     * <p/>
     * There are 4 ROLs in status "RELEASED" and in the current period. Each ROL
     * has an used ROL parameter with one SAP code (the 4 used ROL parameter
     * have the same SAP code). So, there will be created 4 billable objects,
     * each one with the handle code being a ROL id and there will be created
     * revenue accounts to each object.
     *
     * @throws InfraException
     */
    @Test
    public void bill_rol_by_revenue_code_status_released_and_current_period() throws BusinessException, InfraException {

        this.setupDBUnitWithAffiliates(false);

        // Create the basic information (operational year and period)
        Date now = CalendarUtil.getDateNow();
        Integer year = new Integer(CalendarUtil.getDateYear(now) + 10);
        OperationalYear operationalYear = new OperationalYear(year.toString());
        this.saveAndFlush(operationalYear);
        Date period = CalendarUtil.getDate(year, CalendarUtil.getDateMonth(now), 1);

        // Get the ROL status
        RolStatus rolStatus = this.getROLStatus(RolStatus.ROL_STATUS_RELEASED);
        List<Long> listROLId = new ArrayList<Long>();

        // Create the "released" ROL to the matrix in the current period
        HeadOffice headoffice = (HeadOffice) this.getSession().get(HeadOffice.class, new Long(900000001L));
        Long id = this.createROL(operationalYear, period, headoffice, rolStatus, "000000000099999999", false,
                new BigDecimal("10.0"), new BigDecimal("20.0"));
        listROLId.add(id);

        // Create the "released" ROL to one headoffice in the current period
        headoffice = (HeadOffice) this.getSession().get(HeadOffice.class, new Long(900000004L));
        id = this.createROL(operationalYear, period, headoffice, rolStatus, "000000000099999999", false,
                new BigDecimal("10.0"), new BigDecimal("20.0"));
        listROLId.add(id);

        // Create the "released" ROL to one headoffice in the current period
        headoffice = (HeadOffice) this.getSession().get(HeadOffice.class, new Long(900000006L));
        id = this.createROL(operationalYear, period, headoffice, rolStatus, "000000000099999999", false,
                new BigDecimal("10.0"), new BigDecimal("20.0"));
        listROLId.add(id);

        // Create the "released" ROL to one headoffice in the current period
        headoffice = (HeadOffice) this.getSession().get(HeadOffice.class, new Long(900000007L));
        id = this.createROL(operationalYear, period, headoffice, rolStatus, "000000000099999999", false,
                new BigDecimal("10.0"), new BigDecimal("20.0"));
        listROLId.add(id);

        // Bill the ROLs
        Company company = (Company) this.getSession().get(Company.class, new Long(990000002L));
        this.revenueManager.bill(this.billableProvider, company);

        // Validate the ROLs, to see if they are billed
        for (Long rolId : listROLId) {

            ReportOnLine rol = this.reportOnlineDAO.findById(rolId);
            Assert.assertTrue("ROL is not billed.",
                    RolStatus.ROL_STATUS_PROCESSED.equals(rol.getRolStatus().getRolStatusCode()));
            // Assert.assertNotNull("ROL has no bill date.",
            // rol.getRolBillDate());
            Assert.assertNotNull("ROL has no bill number.", rol.getRolBillNumber());

            // Analyze ROL log
            List<RolLogDTO> lstRolLog = this.rolInformationService.selectRolLogById(rolId);
            Assert.assertNotNull("There are no logs for the ROL.", lstRolLog);

            // Assert there is a new log with new status "PROCESSED"
            for (RolLogDTO rolLog : lstRolLog) {

                if (rolLog.getRolLogType().getFormatted() == RolLogTypeEnum.STATUS.getFormatted()) {

                    // Assert there the old status is "RELEASED" and the new
                    // status is "PROCESSED"
                    Assert.assertEquals("The old status is not released.", RolStatus.ROL_STATUS_RELEASED,
                            rolLog.getRolLogOldValue());
                    Assert.assertEquals("The new status is not processed.", RolStatus.ROL_STATUS_PROCESSED,
                            rolLog.getRolLogNewValue());
                }
            }
        }
    }

    /**
     * This scenario is:
     * <p/>
     * There are 4 ROLs in status "RELEASED" and in the current period. Each ROL
     * has an used ROL parameter with one SAP code (the 4 used ROL parameter
     * have the same SAP code), but with no volume, no value and no credit
     * consumption. So, there will be created no billable object, but the ROLs
     * will be billed.
     *
     * @throws InfraException
     */
    @Test
    public void bill_rol_by_revenue_code_status_released_and_current_period_without_value() throws BusinessException,
            InfraException {

        this.setupDBUnitWithAffiliates(false);

        // Create the basic information (operational year and period)
        Date now = CalendarUtil.getDateNow();
        Integer year = new Integer(CalendarUtil.getDateYear(now) + 10);
        OperationalYear operationalYear = new OperationalYear(year.toString());
        this.saveAndFlush(operationalYear);
        Date period = CalendarUtil.getDate(year, CalendarUtil.getDateMonth(now), 15);

        // Get the ROL status
        RolStatus rolStatus = this.getROLStatus(RolStatus.ROL_STATUS_RELEASED);
        List<Long> listROLId = new ArrayList<Long>();

        // Create the "released" ROL to the matrix in the current period
        HeadOffice headoffice = (HeadOffice) this.getSession().get(HeadOffice.class, new Long(900000001L));
        Long id = this.createROL(operationalYear, period, headoffice, rolStatus, "000000000099999999", false,
                new BigDecimal("0.0"), new BigDecimal("0.0"));
        listROLId.add(id);

        // Create the "released" ROL to one headoffice in the current period
        headoffice = (HeadOffice) this.getSession().get(HeadOffice.class, new Long(900000004L));
        id = this.createROL(operationalYear, period, headoffice, rolStatus, "000000000099999999", false,
                new BigDecimal("0.0"), new BigDecimal("0.0"));
        listROLId.add(id);

        // Create the "released" ROL to one headoffice in the current period
        headoffice = (HeadOffice) this.getSession().get(HeadOffice.class, new Long(900000006L));
        id = this.createROL(operationalYear, period, headoffice, rolStatus, "000000000099999999", false,
                new BigDecimal("0.0"), new BigDecimal("0.0"));
        listROLId.add(id);

        // Create the "released" ROL to one headoffice in the current period
        headoffice = (HeadOffice) this.getSession().get(HeadOffice.class, new Long(900000007L));
        id = this.createROL(operationalYear, period, headoffice, rolStatus, "000000000099999999", false,
                new BigDecimal("0.0"), new BigDecimal("0.0"));
        listROLId.add(id);

        // Bill the ROLs
        Company company = (Company) this.getSession().get(Company.class, new Long(990000002L));
        this.revenueManager.bill(this.billableProvider, company);

        // Validate the ROLs, to see if they are billed
        for (Long rolId : listROLId) {

            ReportOnLine rol = this.reportOnlineDAO.findById(rolId);
            Assert.assertTrue("ROL is not billed.",
                    RolStatus.ROL_STATUS_PROCESSED.equals(rol.getRolStatus().getRolStatusCode()));
            // Assert.assertNotNull("ROL has no bill date.",
            // rol.getRolBillDate());
            Assert.assertNull("ROL has bill number.", rol.getRolBillNumber());

            // Analyze ROL log
            List<RolLogDTO> lstRolLog = this.rolInformationService.selectRolLogById(rolId);
            Assert.assertNotNull("There are no logs for the ROL.", lstRolLog);

            // Assert there is a new log with new status "PROCESSED"
            for (RolLogDTO rolLog : lstRolLog) {

                if (rolLog.getRolLogType().getFormatted() == RolLogTypeEnum.STATUS.getFormatted()) {

                    // Assert there the old status is "RELEASED" and the new
                    // status is "PROCESSED"
                    Assert.assertEquals("The old status is not released.", RolStatus.ROL_STATUS_RELEASED,
                            rolLog.getRolLogOldValue());
                    Assert.assertEquals("The new status is not processed.", RolStatus.ROL_STATUS_PROCESSED,
                            rolLog.getRolLogNewValue());
                }
            }
        }
    }

    /**
     * This scenario is:
     * <p/>
     * There are 4 ROLs in status "RELEASED" and in the current period. The
     * first ROL has 2 parameters with 2 different SAP codes, the second ROL has
     * 2 parameters with the same SAP code and the next 2 ROLs have one ROL
     * parameter with one SAP code. So, there will be created 6 billable
     * objects, each one with the handle code being a ROL id and there will be
     * created revenue accounts to each object.
     *
     * @throws InfraException
     */
    @Test
    public void bill_rol_by_revenue_code_status_released_and_current_period_2_params() throws BusinessException,
            InfraException {

        this.setupDBUnitWithAffiliates(false);

        // Create the basic information (operational year and period)
        Date now = CalendarUtil.getDateNow();
        Integer year = new Integer(CalendarUtil.getDateYear(now) + 10);
        OperationalYear operationalYear = new OperationalYear(year.toString());
        this.saveAndFlush(operationalYear);
        Date period = CalendarUtil.getDate(year, CalendarUtil.getDateMonth(now), 15);

        // Get the ROL status
        RolStatus rolStatus = this.getROLStatus(RolStatus.ROL_STATUS_RELEASED);
        List<Long> listROLId = new ArrayList<Long>();

        // Create the "released" ROL to the matrix in the current period (with 2
        // parameters)
        HeadOffice headoffice = (HeadOffice) this.getSession().get(HeadOffice.class, new Long(900000001L));
        Long id = this.createROLWith2Param(operationalYear, period, headoffice, rolStatus, "000000000099999999",
                "000000000099999998", false, new BigDecimal("10.0"), new BigDecimal("20.0"));
        listROLId.add(id);

        // Create the "released" ROL to one headoffice in the current period
        // (with 2 parameters)
        headoffice = (HeadOffice) this.getSession().get(HeadOffice.class, new Long(900000004L));
        id = this.createROLWith2Param(operationalYear, period, headoffice, rolStatus, "000000000099999999",
                "000000000099999999", false, new BigDecimal("10.0"), new BigDecimal("20.0"));
        listROLId.add(id);

        // Create the "released" ROL to one headoffice in the current period
        headoffice = (HeadOffice) this.getSession().get(HeadOffice.class, new Long(900000006L));
        id = this.createROL(operationalYear, period, headoffice, rolStatus, "000000000099999999", false,
                new BigDecimal("10.0"), new BigDecimal("20.0"));
        listROLId.add(id);

        // Create the "released" ROL to one headoffice in the current period
        headoffice = (HeadOffice) this.getSession().get(HeadOffice.class, new Long(900000007L));
        id = this.createROL(operationalYear, period, headoffice, rolStatus, "000000000099999999", false,
                new BigDecimal("10.0"), new BigDecimal("20.0"));
        listROLId.add(id);

        // Bill the ROLs
        Company company = (Company) this.getSession().get(Company.class, new Long(990000002L));
        this.revenueManager.bill(this.billableProvider, company);

        // Validate the ROLs, to see if they are billed
        for (Long rolId : listROLId) {

            ReportOnLine rol = this.reportOnlineDAO.findById(rolId);
            Assert.assertTrue("ROL is not billed.",
                    RolStatus.ROL_STATUS_PROCESSED.equals(rol.getRolStatus().getRolStatusCode()));
            // Assert.assertNotNull("ROL has no bill date.",
            // rol.getRolBillDate());
            Assert.assertNotNull("ROL has no bill number.", rol.getRolBillNumber());

            // Analyze ROL log
            List<RolLogDTO> lstRolLog = this.rolInformationService.selectRolLogById(rolId);
            Assert.assertNotNull("There are no logs for the ROL.", lstRolLog);

            // Assert there is a new log with new status "PROCESSED"
            for (RolLogDTO rolLog : lstRolLog) {

                if (rolLog.getRolLogType().getFormatted() == RolLogTypeEnum.STATUS.getFormatted()) {

                    // Assert there the old status is "RELEASED" and the new
                    // status is "PROCESSED"
                    Assert.assertEquals("The old status is not released.", RolStatus.ROL_STATUS_RELEASED,
                            rolLog.getRolLogOldValue());
                    Assert.assertEquals("The new status is not processed.", RolStatus.ROL_STATUS_PROCESSED,
                            rolLog.getRolLogNewValue());
                }
            }
        }
    }

    /**
     * This scenario is:
     * <p/>
     * There are 4 ROLs in status "RELEASED" in an ancient period and 4 ROLs in
     * status "RELEASED" in the current period. The 4 ROLs in the ancient period
     * will fail because they have a wrong SAP code. But the 4 ROLs in the
     * current period will succeeded because their SAP code is right.
     *
     * @throws BusinessException
     * @throws InfraException
     */
    @Test
    public void bill_rol_by_revenue_code_status_released_in_two_periods() throws BusinessException, InfraException {

        this.setupDBUnitWithAffiliates(false);

        // Create the basic information (operational year and period)
        Date now = CalendarUtil.getDateNow();
        Integer year = new Integer(CalendarUtil.getDateYear(now) + 10);
        OperationalYear operationalYear = new OperationalYear(year.toString());
        this.saveAndFlush(operationalYear);
        Date period = CalendarUtil.getDate(year, 6, 1);

        // Get the ROL status
        RolStatus rolStatus = this.getROLStatus(RolStatus.ROL_STATUS_RELEASED);

        /*
         * Create ROLs in the ancient period
         */

        List<Long> listROLId = new ArrayList<Long>();

        // Create the "released" ROL to the matrix in the current period
        HeadOffice headoffice = (HeadOffice) this.getSession().get(HeadOffice.class, new Long(900000001L));
        Long id = this.createROL(operationalYear, period, headoffice, rolStatus, "000000000099999999", false,
                new BigDecimal("10.0"), new BigDecimal("20.0"));
        listROLId.add(id);

        // Create the "released" ROL to one headoffice in the current period
        headoffice = (HeadOffice) this.getSession().get(HeadOffice.class, new Long(900000004L));
        id = this.createROL(operationalYear, period, headoffice, rolStatus, "000000000099999999", false,
                new BigDecimal("10.0"), new BigDecimal("20.0"));
        listROLId.add(id);

        // Create the "released" ROL to one headoffice in the current period
        headoffice = (HeadOffice) this.getSession().get(HeadOffice.class, new Long(900000006L));
        id = this.createROL(operationalYear, period, headoffice, rolStatus, "000000000099999999", false,
                new BigDecimal("10.0"), new BigDecimal("20.0"));
        listROLId.add(id);

        // Create the "released" ROL to one headoffice in the current period
        headoffice = (HeadOffice) this.getSession().get(HeadOffice.class, new Long(900000007L));
        id = this.createROL(operationalYear, period, headoffice, rolStatus, "000000000099999999", false,
                new BigDecimal("10.0"), new BigDecimal("20.0"));
        listROLId.add(id);

        /*
         * Create ROLs in the current period
         */

        // Change period
        Date periodNew = CalendarUtil.add(Calendar.MONTH, 1, period);

        // Create the "released" ROL to the matrix in the current period
        headoffice = (HeadOffice) this.getSession().get(HeadOffice.class, new Long(900000001L));
        id = this.createROL(operationalYear, periodNew, headoffice, rolStatus, "000000000099999999", false,
                new BigDecimal("10.0"), new BigDecimal("20.0"));
        listROLId.add(id);

        // Create the "released" ROL to one headoffice in the current period
        headoffice = (HeadOffice) this.getSession().get(HeadOffice.class, new Long(900000004L));
        id = this.createROL(operationalYear, periodNew, headoffice, rolStatus, "000000000099999999", false,
                new BigDecimal("10.0"), new BigDecimal("20.0"));
        listROLId.add(id);

        // Create the "released" ROL to one headoffice in the current period
        headoffice = (HeadOffice) this.getSession().get(HeadOffice.class, new Long(900000006L));
        id = this.createROL(operationalYear, periodNew, headoffice, rolStatus, "000000000099999999", false,
                new BigDecimal("10.0"), new BigDecimal("20.0"));
        listROLId.add(id);

        // Create the "released" ROL to one headoffice in the current period
        headoffice = (HeadOffice) this.getSession().get(HeadOffice.class, new Long(900000007L));
        id = this.createROL(operationalYear, periodNew, headoffice, rolStatus, "000000000099999999", false,
                new BigDecimal("10.0"), new BigDecimal("20.0"));
        listROLId.add(id);

        /*
         * Bill the ROLs in the two periods
         */

        // Bill the ROLs
        Company company = (Company) this.getSession().get(Company.class, new Long(990000002L));
        this.revenueManager.bill(this.billableProvider, company);

        // Validate the ROLs, to see if they are billed
        for (Long rolId : listROLId) {

            ReportOnLine rol = this.reportOnlineDAO.findById(rolId);
            Assert.assertTrue("ROL is not billed.",
                    RolStatus.ROL_STATUS_PROCESSED.equals(rol.getRolStatus().getRolStatusCode()));
            Assert.assertNotNull("ROL has no bill date.", rol.getRolBillDate());
            Assert.assertNotNull("ROL has no bill number.", rol.getRolBillNumber());

            // Get the revenue from the current ROL
            RevenueAccount revenueAccount = this.revenueService.selectRevenueAccountByTypeAndHandleId(RevenueType.POD,
                    rolId);
            Assert.assertNotNull("There is no revenue account.", revenueAccount);
            Assert.assertEquals("The SAP document number is not equal.", rol.getRolBillNumber().toString(),
                    revenueAccount.getDocumentNumber());
            Assert.assertEquals("The periods are different.", rol.getRolPeriod(), revenueAccount.getPeriod());

            // Analyze ROL log
            List<RolLogDTO> lstRolLog = this.rolInformationService.selectRolLogById(rolId);
            Assert.assertNotNull("There are no logs for the ROL.", lstRolLog);

            // Assert there is a new log with new status "PROCESSED"
            for (RolLogDTO rolLog : lstRolLog) {

                if (rolLog.getRolLogType().getFormatted() == RolLogTypeEnum.STATUS.getFormatted()) {

                    // Assert there the old status is "RELEASED" and the new
                    // status is "PROCESSED"
                    Assert.assertEquals("The old status is not released.", RolStatus.ROL_STATUS_RELEASED,
                            rolLog.getRolLogOldValue());
                    Assert.assertEquals("The new status is not processed.", RolStatus.ROL_STATUS_PROCESSED,
                            rolLog.getRolLogNewValue());
                }
            }
        }
    }

    /**
     * This scenario is:
     * <p/>
     * There are 4 ROLs in status "RELEASED" in an ancient period (wrong) and 4
     * ROLs in status "RELEASED" in the current period. The 4 ROLs in the
     * ancient period will fail because they have a wrong SAP code. But the 4
     * ROLs in the current period will succeeded because their SAP code is
     * right.
     *
     * @throws BusinessException
     * @throws InfraException
     */
    @Test
    public void bill_rol_by_revenue_code_status_released_in_two_periods_with_errors() throws BusinessException,
            InfraException {

        this.setupDBUnitWithAffiliates(false);

        // Create the basic information (operational year and period)
        Date now = CalendarUtil.getDateNow();
        Integer year = new Integer(CalendarUtil.getDateYear(now) + 10);
        OperationalYear operationalYear = new OperationalYear(year.toString());
        this.saveAndFlush(operationalYear);
        Date period = CalendarUtil.getDate(year, 6, 1);

        // Get the ROL status
        RolStatus rolStatus = this.getROLStatus(RolStatus.ROL_STATUS_RELEASED);

        /*
         * Create ROLs in the ancient period
         */

        List<Long> listROLIdWrong = new ArrayList<Long>();

        // Create the "released" ROL to the matrix in the current period
        HeadOffice headoffice = (HeadOffice) this.getSession().get(HeadOffice.class, new Long(900000001L));
        Long id = this.createROL(operationalYear, period, headoffice, rolStatus, "000000000099999991", false,
                new BigDecimal("10.0"), new BigDecimal("20.0"));
        listROLIdWrong.add(id);

        // Create the "released" ROL to one headoffice in the current period
        headoffice = (HeadOffice) this.getSession().get(HeadOffice.class, new Long(900000004L));
        id = this.createROL(operationalYear, period, headoffice, rolStatus, "000000000099999991", false,
                new BigDecimal("10.0"), new BigDecimal("20.0"));
        listROLIdWrong.add(id);

        // Create the "released" ROL to one headoffice in the current period
        headoffice = (HeadOffice) this.getSession().get(HeadOffice.class, new Long(900000006L));
        id = this.createROL(operationalYear, period, headoffice, rolStatus, "000000000099999991", false,
                new BigDecimal("10.0"), new BigDecimal("20.0"));
        listROLIdWrong.add(id);

        // Create the "released" ROL to one headoffice in the current period
        headoffice = (HeadOffice) this.getSession().get(HeadOffice.class, new Long(900000007L));
        id = this.createROL(operationalYear, period, headoffice, rolStatus, "000000000099999991", false,
                new BigDecimal("10.0"), new BigDecimal("20.0"));
        listROLIdWrong.add(id);

        /*
         * Create ROLs in the current period
         */

        // Change period
        Date periodNew = CalendarUtil.add(Calendar.MONTH, 1, period);

        List<Long> listROLId = new ArrayList<Long>();

        // Create the "released" ROL to the matrix in the current period
        headoffice = (HeadOffice) this.getSession().get(HeadOffice.class, new Long(900000001L));
        id = this.createROL(operationalYear, periodNew, headoffice, rolStatus, "000000000099999999", false,
                new BigDecimal("10.0"), new BigDecimal("20.0"));
        listROLId.add(id);

        // Create the "released" ROL to one headoffice in the current period
        headoffice = (HeadOffice) this.getSession().get(HeadOffice.class, new Long(900000004L));
        id = this.createROL(operationalYear, periodNew, headoffice, rolStatus, "000000000099999999", false,
                new BigDecimal("10.0"), new BigDecimal("20.0"));
        listROLId.add(id);

        // Create the "released" ROL to one headoffice in the current period
        headoffice = (HeadOffice) this.getSession().get(HeadOffice.class, new Long(900000006L));
        id = this.createROL(operationalYear, periodNew, headoffice, rolStatus, "000000000099999999", false,
                new BigDecimal("10.0"), new BigDecimal("20.0"));
        listROLId.add(id);

        // Create the "released" ROL to one headoffice in the current period
        headoffice = (HeadOffice) this.getSession().get(HeadOffice.class, new Long(900000007L));
        id = this.createROL(operationalYear, periodNew, headoffice, rolStatus, "000000000099999999", false,
                new BigDecimal("10.0"), new BigDecimal("20.0"));
        listROLId.add(id);

        /*
         * Bill the ROLs in the two periods
         */

        try {
            // Bill the ROLs
            Company company = (Company) this.getSession().get(Company.class, new Long(990000002L));
            this.revenueManager.bill(this.billableProvider, company);
        } catch (BusinessException be) {
            Assert.assertNotNull("No exception found.", be);
        }

        // Validate the wrong ROLs, to see if they are not billed
        for (Long rolId : listROLIdWrong) {

            ReportOnLine rol = this.reportOnlineDAO.findById(rolId);
            Assert.assertTrue("ROL is billed.",
                    RolStatus.ROL_STATUS_RELEASED.equals(rol.getRolStatus().getRolStatusCode()));
            Assert.assertNull("ROL has bill date.", rol.getRolBillDate());
            Assert.assertNull("ROL has bill number.", rol.getRolBillNumber());

            try {
                // Assert there is no revenue from the current ROL
                RevenueAccount revenueAccount = this.revenueService.selectRevenueAccountByTypeAndHandleId(
                        RevenueType.POD, rolId);
                Assert.assertNull("Revenue exists.", revenueAccount);
            } catch (EntityNotFoundException enf) {
                Assert.assertNotNull("No exception found.", enf);
            }

            // Analyze ROL log
            List<RolLogDTO> lstRolLog = this.rolInformationService.selectRolLogById(rolId);
            Assert.assertNotNull("There are no logs for the ROL.", lstRolLog);
            Assert.assertEquals("There is at least one ROL log.", 0, lstRolLog.size());
        }

        // Validate the ROLs, to see if they are billed
        for (Long rolId : listROLId) {

            ReportOnLine rol = this.reportOnlineDAO.findById(rolId);
            Assert.assertTrue("ROL is not billed.",
                    RolStatus.ROL_STATUS_PROCESSED.equals(rol.getRolStatus().getRolStatusCode()));
            Assert.assertNotNull("ROL has no bill date.", rol.getRolBillDate());
            Assert.assertNotNull("ROL has no bill number.", rol.getRolBillNumber());

            // Get the revenue from the current ROL
            RevenueAccount revenueAccount = this.revenueService.selectRevenueAccountByTypeAndHandleId(RevenueType.POD,
                    rolId);
            Assert.assertNotNull("There is no revenue account.", revenueAccount);
            Assert.assertEquals("The SAP document number is not equal.", rol.getRolBillNumber().toString(),
                    revenueAccount.getDocumentNumber());
            Assert.assertEquals("The periods are different.", rol.getRolPeriod(), revenueAccount.getPeriod());

            // Analyze ROL log
            List<RolLogDTO> lstRolLog = this.rolInformationService.selectRolLogById(rolId);
            Assert.assertNotNull("There are no logs for the ROL.", lstRolLog);

            // Assert there is a new log with new status "PROCESSED"
            for (RolLogDTO rolLog : lstRolLog) {

                if (rolLog.getRolLogType().getFormatted() == RolLogTypeEnum.STATUS.getFormatted()) {

                    // Assert there the old status is "RELEASED" and the new
                    // status is "PROCESSED"
                    Assert.assertEquals("The old status is not released.", RolStatus.ROL_STATUS_RELEASED,
                            rolLog.getRolLogOldValue());
                    Assert.assertEquals("The new status is not processed.", RolStatus.ROL_STATUS_PROCESSED,
                            rolLog.getRolLogNewValue());
                }
            }
        }
    }

    /**
     * This scenario is:
     * <p/>
     * There are 4 ROLs in status "RELEASED" and in the current period. Each ROL
     * has an used ROL parameter with one SAP code (the 4 used ROL parameter
     * have the same SAP code). So, there will be created 4 billable objects,
     * each one with the handle code being a ROL id and there will be created
     * revenue accounts to each object.
     *
     * @throws InfraException
     */
    @Test
    public void select_rol_bill_rol_by_revenue_code_status_released_and_current_period() throws BusinessException,
            InfraException {

        this.setupDBUnitWithAffiliates(false);

        // Create the basic information (operational year and period)
        Date now = CalendarUtil.getDateNow();
        Integer year = new Integer(CalendarUtil.getDateYear(now) + 10);
        OperationalYear operationalYear = new OperationalYear(year.toString());
        this.saveAndFlush(operationalYear);
        Date period = CalendarUtil.getDate(year, CalendarUtil.getDateMonth(now), 15);

        // Get the ROL status
        RolStatus rolStatus = this.getROLStatus(RolStatus.ROL_STATUS_RELEASED);
        List<Long> listROLId = new ArrayList<Long>();

        // Create the "released" ROL to the matrix in the current period
        HeadOffice headoffice = (HeadOffice) this.getSession().get(HeadOffice.class, new Long(900000001L));
        Long id = this.createROL(operationalYear, period, headoffice, rolStatus, "000000000099999999", false,
                new BigDecimal("10.0"), new BigDecimal("20.0"));
        listROLId.add(id);

        // Create the "released" ROL to one headoffice in the current period
        headoffice = (HeadOffice) this.getSession().get(HeadOffice.class, new Long(900000004L));
        id = this.createROL(operationalYear, period, headoffice, rolStatus, "000000000099999999", false,
                new BigDecimal("10.0"), new BigDecimal("20.0"));
        listROLId.add(id);

        // Create the "released" ROL to one headoffice in the current period
        headoffice = (HeadOffice) this.getSession().get(HeadOffice.class, new Long(900000006L));
        id = this.createROL(operationalYear, period, headoffice, rolStatus, "000000000099999999", false,
                new BigDecimal("10.0"), new BigDecimal("20.0"));
        listROLId.add(id);

        // Create the "released" ROL to one headoffice in the current period
        headoffice = (HeadOffice) this.getSession().get(HeadOffice.class, new Long(900000007L));
        id = this.createROL(operationalYear, period, headoffice, rolStatus, "000000000099999999", false,
                new BigDecimal("10.0"), new BigDecimal("20.0"));
        listROLId.add(id);

        // Bill the ROLs
        Company company = (Company) this.getSession().get(Company.class, new Long(990000002L));
        revenueManager.bill(this.billableProvider, company);

        // Find the ROLs released
        List<ReportOnLine> lstROLFound = this.rolInformationService.selectROLConsolidate(RolStatus.ROL_STATUS_RELEASED,
                null, company);
        Assert.assertNotNull("ROLs were not found.", lstROLFound);

        // Find the ROLs released with extra attributes
        lstROLFound = this.rolInformationService.selectROLConsolidate(RolStatus.ROL_STATUS_RELEASED,
                RolStatus.ROL_STATUS_REPORTED, company);
        Assert.assertNotNull("ROLs were not found.", lstROLFound);
    }

    /**
     * This scenario is:
     * <p/>
     * There are 4 ROLs in status "RELEASED" and in the current period. Each ROL
     * has an used ROL parameter with one SAP code (the 4 used ROL parameter
     * have the same SAP code). So, there will be created 4 billable objects,
     * each one with the handle code being a ROL id and there will be created
     * revenue accounts to each object. After that, the method will try to find
     * the ROLs billed without charge (all of them).
     *
     * @throws InfraException
     */
    @Test
    public void select_rol_billed_without_charge() throws BusinessException, InfraException {

        this.setupDBUnitWithAffiliates(false);

        // Create the basic information (operational year and period)
        Date now = CalendarUtil.getDateNow();
        Integer year = new Integer(CalendarUtil.getDateYear(now) + 10);
        OperationalYear operationalYear = new OperationalYear(year.toString());
        this.saveAndFlush(operationalYear);
        Date period = CalendarUtil.getDate(year, CalendarUtil.getDateMonth(now), 15);

        // Get the ROL status
        RolStatus rolStatus = this.getROLStatus(RolStatus.ROL_STATUS_RELEASED);
        List<Long> listROLId = new ArrayList<Long>();

        // Create the "released" ROL to the matrix in the current period
        HeadOffice headoffice = (HeadOffice) this.getSession().get(HeadOffice.class, new Long(900000001L));
        Long id = this.createROL(operationalYear, period, headoffice, rolStatus, "000000000099999999", false,
                new BigDecimal("10.0"), new BigDecimal("20.0"));
        listROLId.add(id);

        // Create the "released" ROL to one headoffice in the current period
        headoffice = (HeadOffice) this.getSession().get(HeadOffice.class, new Long(900000004L));
        id = this.createROL(operationalYear, period, headoffice, rolStatus, "000000000099999999", false,
                new BigDecimal("10.0"), new BigDecimal("20.0"));
        listROLId.add(id);

        // Create the "released" ROL to one headoffice in the current period
        headoffice = (HeadOffice) this.getSession().get(HeadOffice.class, new Long(900000006L));
        id = this.createROL(operationalYear, period, headoffice, rolStatus, "000000000099999999", false,
                new BigDecimal("10.0"), new BigDecimal("20.0"));
        listROLId.add(id);

        // Create the "released" ROL to one headoffice in the current period
        headoffice = (HeadOffice) this.getSession().get(HeadOffice.class, new Long(900000007L));
        id = this.createROL(operationalYear, period, headoffice, rolStatus, "000000000099999999", false,
                new BigDecimal("10.0"), new BigDecimal("20.0"));
        listROLId.add(id);

        // Bill the ROLs
        Company company = (Company) this.getSession().get(Company.class, new Long(990000002L));
        this.revenueManager.bill(this.billableProvider, company);

        // Try to find the ROLs billed without charge 
        List<ReportOnLine> listROLBilled = this.rolInformationService.selectROLConsolidateWithoutCharge(
                RolStatus.ROL_STATUS_PROCESSED, null, company);

        // Assert all the ROLs were returned, because there is no charge
        Assert.assertTrue("There is no ROL billed.", listROLBilled.size() > 0);

        // Validate the ROLs, to see if they are billed
        for (Long rolId : listROLId) {

            ReportOnLine rol = this.reportOnlineDAO.findById(rolId);
            Assert.assertTrue("ROL is not billed.",
                    RolStatus.ROL_STATUS_PROCESSED.equals(rol.getRolStatus().getRolStatusCode()));
        }
    }

    /**
     * This scenario is:
     * <p/>
     * There are 4 ROLs in status "RELEASED" and in the current period. Each ROL
     * has an used ROL parameter with one SAP code (the 4 used ROL parameter
     * have the same SAP code). So, there will be created 4 billable objects,
     * each one with the handle code being a ROL id and there will be created
     * revenue accounts to each object. After that, the method will try to find
     * the ROLs billed with manual charge.
     *
     * @throws InfraException
     */
    @Test
    public void select_rol_billed_with_charge_manual() throws BusinessException, InfraException {

        this.setupDBUnitWithAffiliates(false);

        // Create the basic information (operational year and period)
        Date now = CalendarUtil.getDateNow();
        Integer year = new Integer(CalendarUtil.getDateYear(now) + 10);
        OperationalYear operationalYear = new OperationalYear(year.toString());
        this.saveAndFlush(operationalYear);
        Date period = CalendarUtil.getDate(year, CalendarUtil.getDateMonth(now), 15);

        // Get the ROL status
        RolStatus rolStatus = this.getROLStatus(RolStatus.ROL_STATUS_RELEASED);
        List<Long> listROLId = new ArrayList<Long>();

        // Create the "released" ROL to the matrix in the current period
        HeadOffice headoffice = (HeadOffice) this.getSession().get(HeadOffice.class, new Long(900000001L));
        Long id = this.createROL(operationalYear, period, headoffice, rolStatus, "000000000099999999", false,
                new BigDecimal("10.0"), new BigDecimal("20.0"));
        listROLId.add(id);

        // Create the "released" ROL to one headoffice in the current period
        headoffice = (HeadOffice) this.getSession().get(HeadOffice.class, new Long(900000004L));
        id = this.createROL(operationalYear, period, headoffice, rolStatus, "000000000099999999", false,
                new BigDecimal("10.0"), new BigDecimal("20.0"));
        listROLId.add(id);

        // Create the "released" ROL to one headoffice in the current period
        headoffice = (HeadOffice) this.getSession().get(HeadOffice.class, new Long(900000006L));
        id = this.createROL(operationalYear, period, headoffice, rolStatus, "000000000099999999", false,
                new BigDecimal("10.0"), new BigDecimal("20.0"));
        listROLId.add(id);

        // Create the "released" ROL to one headoffice in the current period
        headoffice = (HeadOffice) this.getSession().get(HeadOffice.class, new Long(900000007L));
        id = this.createROL(operationalYear, period, headoffice, rolStatus, "000000000099999999", false,
                new BigDecimal("10.0"), new BigDecimal("20.0"));
        listROLId.add(id);

        // Create the charge consolidate to this period
        this.createChargeConsolidate(period, ChargeConsolidateTypeEnum.CREDITCONSUMPTIONCHARGE,
                ChargeConsolidateStatus.RELEASED, null);

        // Bill the ROLs
        Company company = (Company) this.getSession().get(Company.class, new Long(990000002L));
        this.revenueManager.bill(this.billableProvider, company);

        // Try to find the ROLs billed without charge
        List<ReportOnLine> listROLBilled = this.rolInformationService.selectROLConsolidateWithoutCharge(
                RolStatus.ROL_STATUS_PROCESSED, null, company);

        // Assert no ROLs were returned, because there are charges
        Assert.assertTrue("There is ROL billed.", listROLBilled.size() == 0);
    }

    /**
     * This scenario is:
     * <p/>
     * There are 4 ROLs in status "RELEASED" and in the current period. Each ROL
     * has an used ROL parameter with one SAP code (the 4 used ROL parameter
     * have the same SAP code). So, there will be created 4 billable objects,
     * each one with the handle code being a ROL id and there will be created
     * revenue accounts to each object. After that, the method will try to find
     * the ROLs billed with imported charge.
     *
     * @throws InfraException
     */
    @Test
    public void select_rol_billed_with_charge_imported() throws BusinessException, InfraException {

        this.setupDBUnitWithAffiliates(false);

        // Create the basic information (operational year and period)
        Date now = CalendarUtil.getDateNow();
        Integer year = new Integer(CalendarUtil.getDateYear(now) + 10);
        OperationalYear operationalYear = new OperationalYear(year.toString());
        this.saveAndFlush(operationalYear);
        Date period = CalendarUtil.getDate(year, CalendarUtil.getDateMonth(now), 15);

        // Get the ROL status
        RolStatus rolStatus = this.getROLStatus(RolStatus.ROL_STATUS_RELEASED);
        List<Long> listROLId = new ArrayList<Long>();

        // Create the "released" ROL to the matrix in the current period
        HeadOffice headoffice = (HeadOffice) this.getSession().get(HeadOffice.class, new Long(900000001L));
        Long id = this.createROL(operationalYear, period, headoffice, rolStatus, "000000000099999999", false,
                new BigDecimal("10.0"), new BigDecimal("20.0"));
        listROLId.add(id);

        // Create the "released" ROL to one headoffice in the current period
        headoffice = (HeadOffice) this.getSession().get(HeadOffice.class, new Long(900000004L));
        id = this.createROL(operationalYear, period, headoffice, rolStatus, "000000000099999999", false,
                new BigDecimal("10.0"), new BigDecimal("20.0"));
        listROLId.add(id);

        // Create the "released" ROL to one headoffice in the current period
        headoffice = (HeadOffice) this.getSession().get(HeadOffice.class, new Long(900000006L));
        id = this.createROL(operationalYear, period, headoffice, rolStatus, "000000000099999999", false,
                new BigDecimal("10.0"), new BigDecimal("20.0"));
        listROLId.add(id);

        // Create the "released" ROL to one headoffice in the current period
        headoffice = (HeadOffice) this.getSession().get(HeadOffice.class, new Long(900000007L));
        id = this.createROL(operationalYear, period, headoffice, rolStatus, "000000000099999999", false,
                new BigDecimal("10.0"), new BigDecimal("20.0"));
        listROLId.add(id);

        // Create the charge consolidate to this period
        this.createChargeConsolidate(period, ChargeConsolidateTypeEnum.CREDITCONSUMPTIONCHARGEIMP,
                ChargeConsolidateStatus.RELEASED, null);

        // Bill the ROLs
        Company company = (Company) this.getSession().get(Company.class, new Long(990000002L));
        this.revenueManager.bill(this.billableProvider, company);

        // Try to find the ROLs billed without charge
        List<ReportOnLine> listROLBilled = this.rolInformationService.selectROLConsolidateWithoutCharge(
                RolStatus.ROL_STATUS_PROCESSED, null, company);

        // Assert all the ROLs were returned, because there is no charge
        Assert.assertTrue("There is no ROL billed.", listROLBilled.size() > 0);

        // Validate the ROLs, to see if they are billed
        for (Long rolId : listROLId) {

            ReportOnLine rol = this.reportOnlineDAO.findById(rolId);
            Assert.assertTrue("ROL is not billed.",
                    RolStatus.ROL_STATUS_PROCESSED.equals(rol.getRolStatus().getRolStatusCode()));
        }
    }

    /**
     * This scenario is:
     * <p/>
     * There are 4 ROLs in status "RELEASED" and in the current period. Each ROL
     * has an used ROL parameter with one SAP code (the 4 used ROL parameter
     * have the same SAP code). So, there will be created 4 billable objects,
     * each one with the handle code being a ROL id and there will be created
     * revenue accounts to each object. After that, the test will create charge
     * consolidate objects.
     *
     * @throws InfraException
     */
    @Test
    public void bill_and_generate_charge() throws BusinessException, InfraException {

        this.setupDBUnitWithAffiliates(false);

        // Create the basic information (operational year and period)
        Date now = CalendarUtil.getDateNow();
        Integer year = new Integer(CalendarUtil.getDateYear(now) + 10);
        OperationalYear operationalYear = new OperationalYear(year.toString());
        this.saveAndFlush(operationalYear);
        Date period = CalendarUtil.getDate(year, CalendarUtil.getDateMonth(now), 15);

        // Get the ROL status
        RolStatus rolStatus = this.getROLStatus(RolStatus.ROL_STATUS_RELEASED);
        List<Long> listROLId = new ArrayList<Long>();

        // Create the "released" ROL to the matrix in the current period
        HeadOffice headoffice = (HeadOffice) this.getSession().get(HeadOffice.class, new Long(900000001L));
        Long id = this.createROL(operationalYear, period, headoffice, rolStatus, "000000000099999999", false,
                new BigDecimal("10.0"), new BigDecimal("20.0"));
        listROLId.add(id);

        // Create the "released" ROL to one headoffice in the current period
        headoffice = (HeadOffice) this.getSession().get(HeadOffice.class, new Long(900000004L));
        id = this.createROL(operationalYear, period, headoffice, rolStatus, "000000000099999999", false,
                new BigDecimal("10.0"), new BigDecimal("20.0"));
        listROLId.add(id);

        // Create the "released" ROL to one headoffice in the current period
        headoffice = (HeadOffice) this.getSession().get(HeadOffice.class, new Long(900000006L));
        id = this.createROL(operationalYear, period, headoffice, rolStatus, "000000000099999999", false,
                new BigDecimal("10.0"), new BigDecimal("20.0"));
        listROLId.add(id);

        // Create the "released" ROL to one headoffice in the current period
        headoffice = (HeadOffice) this.getSession().get(HeadOffice.class, new Long(900000007L));
        id = this.createROL(operationalYear, period, headoffice, rolStatus, "000000000099999999", false,
                new BigDecimal("10.0"), new BigDecimal("20.0"));
        listROLId.add(id);

        // Create credit consumption
        Long creditConsumpId = createCreditConsumption(headoffice, period, operationalYear);

        // Create value of charge
        ValueOfChrgByTon valueOfChrgByTon = new ValueOfChrgByTon();
        valueOfChrgByTon.setCrop(headoffice.getCrop());
        valueOfChrgByTon.setPeriod(period);
        valueOfChrgByTon.setTechnology((Technology) getSession().get(Technology.class, 900000005L));
        valueOfChrgByTon.setValue(BigDecimal.ONE);
        saveAndFlush(valueOfChrgByTon);

        // Bill the ROLs
        Company company = (Company) this.getSession().get(Company.class, new Long(990000002L));
        this.revenueManager.bill(this.billableProvider, company);

        // Generate the charge consolidate
        this.rolInformationService.generateChargeConsolidate(company);

        //Check that the CreditConsumption entity is now with status PROCESSED
        CreditConsumption creditConsump = (CreditConsumption) getSession().get(CreditConsumption.class, creditConsumpId);
        Assert.assertTrue(creditConsump.getCreditConsumptionStatus().equals(CreditConsumptionStatus.PROCESSED));

        // Get the contract
        Contract contract = (Contract) this.getSession().get(Contract.class, new Long(900000003L));

        List<ChargeConsolidate> listChargeConsolidate = selectChargeConsolidateByPeriodAndContract(period, contract);

        // Assert there is at least one charge consolidate
        Assert.assertNotNull("There is no charge consolidate.", listChargeConsolidate);
        Assert.assertTrue("There is no charge consolidate.", listChargeConsolidate.size() > 0);

        for (@SuppressWarnings("rawtypes")
             Iterator iterator = listChargeConsolidate.iterator(); iterator.hasNext(); ) {
            ChargeConsolidate chargeConsolidate = (ChargeConsolidate) iterator.next();
            Assert.assertNotNull("chargeConsolidate doesn't have charge handles code.",
                    chargeConsolidate.getChargeHandleCode());
            for (Long rolId : listROLId) {
                Assert.assertTrue(chargeConsolidate.getChargeHandleCode().contains(
                        new ChargeHandleCode(chargeConsolidate, rolId, ChargeHandleCode.POD_TYPE)));
            }
        }

    }

    /**
     * This scenario is:
     * <p/>
     * There are 4 ROLs in status "RELEASED" and in the current period. Each ROL
     * has an used ROL parameter with one SAP code (the 4 used ROL parameter
     * have the same SAP code). So, there will be created 4 billable objects,
     * each one with the handle code being a ROL id and there will be created
     * revenue accounts to each object. After that, the test will not create
     * charge consolidate objects. There is no credit consumption on period must
     * not create charge consolidate
     *
     * @throws InfraException
     */
    @Test
    public void bill_and_generate_not_charge_because_dont_have_credit_consumption_on_period() throws BusinessException,
            InfraException {

        this.setupDBUnitWithAffiliates(false);

        // Create the basic information (operational year and period)
        Date now = CalendarUtil.getDateNow();
        Integer year = new Integer(CalendarUtil.getDateYear(now) + 10);
        OperationalYear operationalYear = new OperationalYear(year.toString());
        this.saveAndFlush(operationalYear);
        Date period = CalendarUtil.getDate(year, CalendarUtil.getDateMonth(now), 15);

        // Get the ROL status
        RolStatus rolStatus = this.getROLStatus(RolStatus.ROL_STATUS_RELEASED);
        List<Long> listROLId = new ArrayList<Long>();

        // Create the "released" ROL to the matrix in the current period
        HeadOffice headoffice = (HeadOffice) this.getSession().get(HeadOffice.class, new Long(900000001L));
        Long id = this.createROL(operationalYear, period, headoffice, rolStatus, "000000000099999999", false,
                new BigDecimal("10.0"), new BigDecimal("20.0"));
        listROLId.add(id);

        // Create the "released" ROL to one headoffice in the current period
        headoffice = (HeadOffice) this.getSession().get(HeadOffice.class, new Long(900000004L));
        id = this.createROL(operationalYear, period, headoffice, rolStatus, "000000000099999999", false,
                new BigDecimal("10.0"), new BigDecimal("20.0"));
        listROLId.add(id);

        // Create the "released" ROL to one headoffice in the current period
        headoffice = (HeadOffice) this.getSession().get(HeadOffice.class, new Long(900000006L));
        id = this.createROL(operationalYear, period, headoffice, rolStatus, "000000000099999999", false,
                new BigDecimal("10.0"), new BigDecimal("20.0"));
        listROLId.add(id);

        // Create the "released" ROL to one headoffice in the current period
        headoffice = (HeadOffice) this.getSession().get(HeadOffice.class, new Long(900000007L));
        id = this.createROL(operationalYear, period, headoffice, rolStatus, "000000000099999999", false,
                new BigDecimal("10.0"), new BigDecimal("20.0"));
        listROLId.add(id);

        // Bill the ROLs
        Company company = (Company) this.getSession().get(Company.class, new Long(990000002L));
        this.revenueManager.bill(this.billableProvider, company);

        // Generate the charge consolidate
        this.rolInformationService.generateChargeConsolidate(company);

        // Get the contract
        Contract contract = (Contract) this.getSession().get(Contract.class, new Long(900000003L));

        List<ChargeConsolidate> listChargeConsolidate = selectChargeConsolidateByPeriodAndContract(period, contract);

        // Assert there is at least one charge consolidate
        Assert.assertTrue("There is charge consolidate.", listChargeConsolidate.isEmpty());

    }

    @Test
    public void test_reversal_pod() throws BusinessException, InfraException {

        this.setupDBUnitWithAffiliates(false);

        // Create the basic information (operational year and period)
        Date now = CalendarUtil.getDateNow();
        Integer year = new Integer(CalendarUtil.getDateYear(now) + 10);
        OperationalYear operationalYear = new OperationalYear(year.toString());
        this.saveAndFlush(operationalYear);
        Date period = CalendarUtil.getDate(year, CalendarUtil.getDateMonth(now), 15);

        // Get the ROL status
        RolStatus rolStatus = this.getROLStatus(RolStatus.ROL_STATUS_RELEASED);
        List<ReportOnLine> listROL = new ArrayList<ReportOnLine>();

        // Create the "released" ROL to the matrix in the current period
        HeadOffice headoffice = (HeadOffice) this.getSession().get(HeadOffice.class, new Long(900000001L));
        ReportOnLine rol = this.doCreateROL(operationalYear, period, headoffice, rolStatus, "000000000099999999",
                false, new BigDecimal("10.0"), new BigDecimal("20.0"));
        listROL.add(rol);

        // Create the "released" ROL to one headoffice in the current period
        headoffice = (HeadOffice) this.getSession().get(HeadOffice.class, new Long(900000004L));
        rol = this.doCreateROL(operationalYear, period, headoffice, rolStatus, "000000000099999999", false,
                new BigDecimal("10.0"), new BigDecimal("20.0"));
        listROL.add(rol);

        // Create the "released" ROL to one headoffice in the current period
        headoffice = (HeadOffice) this.getSession().get(HeadOffice.class, new Long(900000006L));
        rol = this.doCreateROL(operationalYear, period, headoffice, rolStatus, "000000000099999999", false,
                new BigDecimal("10.0"), new BigDecimal("20.0"));
        listROL.add(rol);

        // Create the "released" ROL to one headoffice in the current period
        headoffice = (HeadOffice) this.getSession().get(HeadOffice.class, new Long(900000007L));
        rol = this.doCreateROL(operationalYear, period, headoffice, rolStatus, "000000000099999999", false,
                new BigDecimal("10.0"), new BigDecimal("20.0"));
        listROL.add(rol);

        // Create credit consumption
        createCreditConsumption(headoffice, period, operationalYear);

        // Create value of charge
        ValueOfChrgByTon valueOfChrgByTon = new ValueOfChrgByTon();
        valueOfChrgByTon.setCrop(headoffice.getCrop());
        valueOfChrgByTon.setPeriod(period);
        valueOfChrgByTon.setTechnology((Technology) getSession().get(Technology.class, 900000005L));
        valueOfChrgByTon.setValue(BigDecimal.ONE);
        saveAndFlush(valueOfChrgByTon);

        // Bill the ROLs
        Company company = (Company) this.getSession().get(Company.class, new Long(990000002L));
        this.revenueManager.bill(this.billableProvider, company);

        // Generate the charge consolidate
        this.rolInformationService.generateChargeConsolidate(company);

        // Get the contract
        Contract contract = (Contract) this.getSession().get(Contract.class, new Long(900000003L));

        // Try to find the charge consolidate created in database
        List<ChargeConsolidate> listChargeConsolidate = selectChargeConsolidateByPeriodAndContract(period, contract);

        // Assert there is at least one charge consolidate
        Assert.assertNotNull("There is no charge consolidate.", listChargeConsolidate);
        Assert.assertTrue("There is no charge consolidate.", listChargeConsolidate.size() > 0);

        // ************************************** DO REVERSAL
        // ********************************************
        // clean all rols from session cache.
        for (ReportOnLine item : listROL) {
            flushObject(item);
        }

        // load _root_ itsUser
        ItsUser itsUser = (ItsUser) getSession().get(ItsUser.class, new Long(900000004));

        // get parameters for reversal
        Map<String, Object> reversalOtherInfoMap = new HashMap<String, Object>();
        Crop crop = (Crop) this.getSession().get(Crop.class, new Long(900000001L));
        reversalOtherInfoMap.put(ReportOnLineService.CROP_KEY, crop);
        reversalOtherInfoMap.put(ReportOnLineService.USER_KEY, itsUser);
        // revenue account
        RevenueExtractFilter filter = RevenueExtractFilter.getInstance();
        filter.add(operationalYear);
        filter.add(headoffice.getMatrix());
        List<RevenueAccount> accounts = revenueAccountDAO.getByFilter(filter);

        // DO the REVERSAL
        billableProvider.reversal(accounts.get(0), itsUser.getLogin(), reversalOtherInfoMap);

        listChargeConsolidate = null;
        // Try to find the charge consolidate created in database
        listChargeConsolidate = selectChargeConsolidateByPeriodAndContract(period, contract);

        // Verify that there is no ChargeConsolidate anymore.
        Assert.assertTrue("The ChargeConsolidate list must be empty after reversal.", listChargeConsolidate.size() == 0);

        // Take the rol list and verify that each rol had the status updated to
        // CORRECTED
        for (ReportOnLine item : listROL) {
            ReportOnLine reportOnLine = (ReportOnLine) getSession().get(ReportOnLine.class, item.getId());

            Assert.assertTrue(reportOnLine.getRolStatus().getRolStatusCode().equals(RolStatus.ROL_STATUS_CORRECTED));
        }

    }

    /**
     * @param period
     * @param contract
     * @return
     */
    private List<ChargeConsolidate> selectChargeConsolidateByPeriodAndContract(Date period, Contract contract) {
        ChargeConsolidateFilter filter = new ChargeConsolidateFilter();
        filter.setContract(contract);
        filter.setPeriod(period);
        List<ChargeConsolidate> listChargeConsolidate = this.chargeConsolidateService
                .findCreditConsumptionChargeConsolidate(filter);
        return listChargeConsolidate;
    }

    /**
     * This scenario is:
     * <p/>
     * There is no ROL billed and the method will try to generate charge
     * consolidate.
     */
    @Test
    public void generate_charge_without_billed_rol() throws BusinessException {

        this.setupDBUnitWithAffiliates(false);

        // Create the basic information (operational year and period)
        Date now = CalendarUtil.getDateNow();
        Integer year = new Integer(CalendarUtil.getDateYear(now) + 10);
        OperationalYear operationalYear = new OperationalYear(year.toString());
        this.saveAndFlush(operationalYear);
        Date period = CalendarUtil.getDate(year, CalendarUtil.getDateMonth(now), 15);

        // Get the ROL status
        RolStatus rolStatus = this.getROLStatus(RolStatus.ROL_STATUS_RELEASED);
        List<Long> listROLId = new ArrayList<Long>();

        // Create the "released" ROL to the matrix in the current period
        HeadOffice headoffice = (HeadOffice) this.getSession().get(HeadOffice.class, new Long(900000001L));
        Long id = this.createROL(operationalYear, period, headoffice, rolStatus, "000000000099999999", false,
                new BigDecimal("10.0"), new BigDecimal("20.0"));
        listROLId.add(id);

        // Create the "released" ROL to one headoffice in the current period
        headoffice = (HeadOffice) this.getSession().get(HeadOffice.class, new Long(900000004L));
        id = this.createROL(operationalYear, period, headoffice, rolStatus, "000000000099999999", false,
                new BigDecimal("10.0"), new BigDecimal("20.0"));
        listROLId.add(id);

        // Create the "released" ROL to one headoffice in the current period
        headoffice = (HeadOffice) this.getSession().get(HeadOffice.class, new Long(900000006L));
        id = this.createROL(operationalYear, period, headoffice, rolStatus, "000000000099999999", false,
                new BigDecimal("10.0"), new BigDecimal("20.0"));
        listROLId.add(id);

        // Create the "released" ROL to one headoffice in the current period
        headoffice = (HeadOffice) this.getSession().get(HeadOffice.class, new Long(900000007L));
        id = this.createROL(operationalYear, period, headoffice, rolStatus, "000000000099999999", false,
                new BigDecimal("10.0"), new BigDecimal("20.0"));
        listROLId.add(id);

        // Generate the charge consolidate
        Company company = (Company) this.getSession().get(Company.class, new Long(990000002L));
        this.rolInformationService.generateChargeConsolidate(company);

        // Get the contract
        Contract contract = (Contract) this.getSession().get(Contract.class, new Long(900000003L));

        List<ChargeConsolidate> listChargeConsolidate = selectChargeConsolidateByPeriodAndContract(period, contract);

        // Assert there is no charge consolidate
        Assert.assertTrue("There is charge consolidate.", listChargeConsolidate.size() == 0);
    }

    @Test
    public void pay_charge_consolidate_not_pod() throws BusinessException {

        this.setupDBUnitWithAffiliates(false);

        // Create the basic information (period)
        Date now = CalendarUtil.getDateNow();
        Integer year = new Integer(CalendarUtil.getDateYear(now) + 10);
        OperationalYear operationalYear = new OperationalYear(year.toString());
        Date period = CalendarUtil.getDate(year, CalendarUtil.getDateMonth(now), 15);

        // Create the charge consolidate
        this.createChargeConsolidate(period, ChargeConsolidateTypeEnum.CREDITCONSUMPTIONCHARGE,
                ChargeConsolidateStatus.RELEASED, null);

        // Get the customer and company
        Customer customer = (Customer) this.getSession().get(Customer.class, new Long("900000001"));
        Company company = (Company) this.getSession().get(Company.class, new Long(990000002L));

        // Pay the charge consolidate
        RevenueAccount account = new RevenueAccount(customer, "1", operationalYear, RevenueType.DISTRIBUTION, company,
                "1");
        try {
            this.billableProvider.pay(account);
            Assert.fail("Expected Bussiness exception!");
        } catch (Exception e) {
            e.printStackTrace();
        }

        // Get the charge consolidate
        ChargeConsolidateFilter filter = new ChargeConsolidateFilter();
        filter.setBillNumber(Long.valueOf("1"));
        List<ChargeConsolidate> listChargeConsolidate = this.chargeConsolidateService.findChargeConsolidate(filter);
        Assert.assertNotNull("Charge consolidate list not found.", listChargeConsolidate);
        Assert.assertTrue("There is no charge consolidate with the document number specified.",
                listChargeConsolidate.size() > 0);
    }

    @Test
    public void pay_charge_consolidate_status_release() throws BusinessException {

        this.setupDBUnitWithAffiliates(false);

        // Create the basic information (period)
        Date now = CalendarUtil.getDateNow();
        Integer year = new Integer(CalendarUtil.getDateYear(now) + 10);
        OperationalYear operationalYear = new OperationalYear(year.toString());
        Date period = CalendarUtil.getDate(year, CalendarUtil.getDateMonth(now), 15);

        // Create the charge consolidate
        this.createChargeConsolidate(period, ChargeConsolidateTypeEnum.CREDITCONSUMPTIONCHARGE,
                ChargeConsolidateStatus.RELEASED, null);

        // Get the customer and company
        Customer customer = (Customer) this.getSession().get(Customer.class, new Long("900000001"));
        Company company = (Company) this.getSession().get(Company.class, new Long(990000002L));

        // Pay the charge consolidate
        RevenueAccount account = new RevenueAccount(customer, "1", operationalYear, RevenueType.POD, company, "1");
        try {
            this.billableProvider.pay(account);
            Assert.fail("Expected Bussiness exception!");
        } catch (Exception e) {
            e.printStackTrace();
        }

        // Get the charge consolidate
        ChargeConsolidateFilter filter = new ChargeConsolidateFilter();
        filter.setBillNumber(Long.valueOf("1"));
        List<ChargeConsolidate> listChargeConsolidate = this.chargeConsolidateService.findChargeConsolidate(filter);
        Assert.assertNotNull("Charge consolidate list not found.", listChargeConsolidate);
        Assert.assertTrue("There is no charge consolidate with the document number specified.",
                listChargeConsolidate.size() > 0);
    }

    @Test
    public void pay_charge_consolidate_status_blocked() throws BusinessException {

        this.setupDBUnitWithAffiliates(false);

        // Create the basic information (period)
        Date now = CalendarUtil.getDateNow();
        Integer year = new Integer(CalendarUtil.getDateYear(now) + 10);
        OperationalYear operationalYear = new OperationalYear(year.toString());
        Date period = CalendarUtil.getDate(year, CalendarUtil.getDateMonth(now), 15);
        Date expirationDate = period;
        // Create the charge consolidate
        this.createChargeConsolidate(period, ChargeConsolidateTypeEnum.CREDITCONSUMPTIONCHARGE,
                ChargeConsolidateStatus.BLOCKED, null);

        // Get the customer and company
        Customer customer = (Customer) this.getSession().get(Customer.class, new Long("900000001"));
        Company company = (Company) this.getSession().get(Company.class, new Long(990000002L));

        // Pay the charge consolidate
        RevenueAccount account = new RevenueAccount(customer, "1", operationalYear, RevenueType.POD, company, period, expirationDate);
        account.setDocumentNumber("1");
        this.billableProvider.pay(account);

        // Get the charge consolidate
        ChargeConsolidateFilter filter = new ChargeConsolidateFilter();
        filter.setBillNumber(Long.valueOf("1"));
        List<ChargeConsolidate> listChargeConsolidate = this.chargeConsolidateService.findChargeConsolidate(filter);
        Assert.assertNotNull("Charge consolidate list not found.", listChargeConsolidate);
        Assert.assertTrue("There is no charge consolidate with the document number specified.",
                listChargeConsolidate.size() > 0);
        for (ChargeConsolidate chargeConsolidate : listChargeConsolidate) {

            // Asset the status is right
            Assert.assertEquals("The status is not released.", ChargeConsolidateStatus.RELEASED,
                    chargeConsolidate.getChargeConsolidateStatus());
        }
    }

    @Test
    public void pay_charge_consolidate_status_distract() throws BusinessException {

        this.setupDBUnitWithAffiliates(false);

        // Create the basic information (period)
        Date now = CalendarUtil.getDateNow();
        Integer year = new Integer(CalendarUtil.getDateYear(now) + 10);
        OperationalYear operationalYear = new OperationalYear(year.toString());
        Date period = CalendarUtil.getDate(year, CalendarUtil.getDateMonth(now), 15);
        Date expirationDate = CalendarUtil.getDate(year, CalendarUtil.getDateMonth(now), 15);

        // Create the charge consolidate
        this.createChargeConsolidate(period, ChargeConsolidateTypeEnum.CREDITCONSUMPTIONCHARGE,
                ChargeConsolidateStatus.DISTRACTED, ChargeConsolidateStatus.BLOCKED);

        // Get the customer and company
        Customer customer = (Customer) this.getSession().get(Customer.class, new Long("900000001"));
        Company company = (Company) this.getSession().get(Company.class, new Long(990000002L));

        // Pay the charge consolidate
        RevenueAccount account = new RevenueAccount(customer, "1", operationalYear, RevenueType.POD, company, period, expirationDate);
        account.setDocumentNumber("1");
        this.billableProvider.pay(account);

        // Get the charge consolidate
        ChargeConsolidateFilter filter = new ChargeConsolidateFilter();
        filter.setBillNumber(Long.valueOf("1"));
        List<ChargeConsolidate> listChargeConsolidate = this.chargeConsolidateService.findChargeConsolidate(filter);
        Assert.assertNotNull("Charge consolidate list not found.", listChargeConsolidate);
        Assert.assertTrue("There is no charge consolidate with the document number specified.",
                listChargeConsolidate.size() > 0);
        for (ChargeConsolidate chargeConsolidate : listChargeConsolidate) {

            // Asset the status is right
            Assert.assertEquals("The status is not released.", ChargeConsolidateStatus.RELEASED,
                    chargeConsolidate.getChargeConsolidateStatusOld());
        }
    }

    @Test
    public void pay_charge_consolidate_status_blocked_type_monthly() throws BusinessException {

        this.setupDBUnitWithAffiliates(false);

        // Create the basic information (period)
        Date now = CalendarUtil.getDateNow();
        Integer year = new Integer(CalendarUtil.getDateYear(now) + 10);
        OperationalYear operationalYear = new OperationalYear(year.toString());
        Date period = CalendarUtil.getDate(year, CalendarUtil.getDateMonth(now), 15);
        Date expirationDate = period;

        // Create the charge consolidate
        this.createChargeConsolidate(period, ChargeConsolidateTypeEnum.MONTHLYCHARGEROYALTY,
                ChargeConsolidateStatus.BLOCKED, null);

        // Get the customer and company
        Customer customer = (Customer) this.getSession().get(Customer.class, new Long("900000001"));
        Company company = (Company) this.getSession().get(Company.class, new Long(990000002L));

        // Pay the charge consolidate
        RevenueAccount account = new RevenueAccount(customer, "1", operationalYear, RevenueType.POD, company, period, expirationDate);
        account.setDocumentNumber("1");
        this.billableProvider.pay(account);

        // Get the charge consolidate
        ChargeConsolidateFilter filter = new ChargeConsolidateFilter();
        filter.setBillNumber(Long.valueOf("1"));
        List<ChargeConsolidate> listChargeConsolidate = this.chargeConsolidateService.findChargeConsolidate(filter);
        Assert.assertNotNull("Charge consolidate list not found.", listChargeConsolidate);
        Assert.assertTrue("There is no charge consolidate with the document number specified.",
                listChargeConsolidate.size() > 0);
        for (ChargeConsolidate chargeConsolidate : listChargeConsolidate) {

            // Asset the status is right
            Assert.assertEquals("The status is not released.", ChargeConsolidateStatus.RELEASED,
                    chargeConsolidate.getChargeConsolidateStatus());
        }
    }

    @Test
    public void pay_charge_consolidate_status_blocked_type_season() throws BusinessException {

        this.setupDBUnitWithAffiliates(false);

        // Create the basic information (period)
        Date now = CalendarUtil.getDateNow();
        Integer year = new Integer(CalendarUtil.getDateYear(now) + 10);
        OperationalYear operationalYear = new OperationalYear(year.toString());
        Date period = CalendarUtil.getDate(year, CalendarUtil.getDateMonth(now), 15);

        // Create the charge consolidate
        this.createChargeConsolidate(period, ChargeConsolidateTypeEnum.SEASONBONUS, ChargeConsolidateStatus.BLOCKED,
                null);

        // Get the customer and company
        Customer customer = (Customer) this.getSession().get(Customer.class, new Long("900000001"));
        Company company = (Company) this.getSession().get(Company.class, new Long(990000002L));

        // Pay the charge consolidate
        RevenueAccount account = new RevenueAccount(customer, "1", operationalYear, RevenueType.POD, company, "1");
        try {
            this.billableProvider.pay(account);
            Assert.fail("Expected Bussiness exception!");
        } catch (Exception e) {
            e.printStackTrace();
        }

        // Get the charge consolidate
        ChargeConsolidateFilter filter = new ChargeConsolidateFilter();
        filter.setBillNumber(Long.valueOf("1"));
        List<ChargeConsolidate> listChargeConsolidate = this.chargeConsolidateService.findChargeConsolidate(filter);
        Assert.assertNotNull("Charge consolidate list not found.", listChargeConsolidate);
        Assert.assertTrue("There is no charge consolidate with the document number specified.",
                listChargeConsolidate.size() > 0);
        for (ChargeConsolidate chargeConsolidate : listChargeConsolidate) {

            // Asset the status is right
            Assert.assertEquals("The status is not released.", ChargeConsolidateStatus.BLOCKED,
                    chargeConsolidate.getChargeConsolidateStatus());
        }
    }

    @Test
    public void test_list_all_charge_consolidate_types() {
        setupDBUnitWithAffiliates(false);
        List<ChargeConsolidateType> consolidateTypes = chargeConsolidateService.findAllChargeConsolidateTypes();

        ChargeConsolidateTypeEnum[] values = ChargeConsolidateTypeEnum.values();

        for (ChargeConsolidateTypeEnum item : values) {
            boolean find = false;
            for (@SuppressWarnings("rawtypes")
                 Iterator iterator = consolidateTypes.iterator(); iterator.hasNext(); ) {
                ChargeConsolidateType chargeConsolidateType = (ChargeConsolidateType) iterator.next();
                if (chargeConsolidateType.getChargeConsTypeCode().equals(item)) {
                    find = true;
                }
            }
            Assert.assertTrue("The type " + item + " must be listed.", find);
        }

    }

    /**
     * @throws BusinessException
     */
    @Test(expected = IllegalArgumentException.class)
    public void test_select_revenue_account_by_type_and_handle_id_with_both_null_expected_illegal_argument_exception()
            throws BusinessException {
        revenueService.selectRevenueAccountByTypeAndHandleId(null, null);
    }

    /**
     * @throws BusinessException
     */
    @Test(expected = IllegalArgumentException.class)
    public void test_select_revenue_account_by_type_and_handle_id_with_type_null_expected_illegal_argument_exception()
            throws BusinessException {
        revenueService.selectRevenueAccountByTypeAndHandleId(null, -1L);
    }

    /**
     * @throws BusinessException
     */
    @Test(expected = IllegalArgumentException.class)
    public void test_select_revenue_account_by_type_and_handle_id_with_id_null_expected_illegal_argument_exception()
            throws BusinessException {
        revenueService.selectRevenueAccountByTypeAndHandleId(RevenueType.POD, null);
    }

    /**
     * @throws BusinessException
     */
    @Test(expected = EntityNotFoundException.class)
    public void test_select_revenue_account_by_type_and_handle_id_with_invalid_id_expected_entity_not_found_exception()
            throws BusinessException {
        revenueService.selectRevenueAccountByTypeAndHandleId(RevenueType.POD, -999933L);
    }

}