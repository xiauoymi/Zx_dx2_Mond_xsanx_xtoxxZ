package com.monsanto.brazilvaluecapture.pod.rol.model.dao.impl;

import com.monsanto.brazilvaluecapture.core.base.model.bean.*;
import com.monsanto.brazilvaluecapture.core.commercialhierarchy.model.bean.ItsDistrict;
import com.monsanto.brazilvaluecapture.core.commercialhierarchy.model.bean.ItsRegion;
import com.monsanto.brazilvaluecapture.core.commercialhierarchy.model.bean.ItsUnity;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Customer;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Technology;
import com.monsanto.brazilvaluecapture.core.wsiconsole.dao.impl.BaseHibernateUnitTest;
import com.monsanto.brazilvaluecapture.pod.rol.model.bean.ReportOnLineView;
import com.monsanto.brazilvaluecapture.pod.rol.model.bean.RolStatus;
import com.monsanto.brazilvaluecapture.pod.rol.model.dao.ReportOnlineDAO;
import com.monsanto.brazilvaluecapture.pod.rol.model.service.ReportOnLineFilter;
import org.hibernate.Criteria;
import org.hibernate.transform.ResultTransformer;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Matchers;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;

import static org.mockito.Mockito.*;

/**
 * Created by IntelliJ IDEA.
 * User: rpredd1
 * Date: 10/2/14
 * Time: 9:49 AM
 * To change this template use File | Settings | File Templates.
 */
public class ReportOnlineDAOImpl_UT extends BaseHibernateUnitTest {
    private ReportOnlineDAO reportOnlineDAO;

    @Before
    public void setUp() {
        reportOnlineDAO = new ReportOnlineDAOImpl(sessionFactory);
    }

    @Test
    public void testDetachAllReportOnlineView() {
        List<ReportOnLineView> reportOnLineViewList = new ArrayList<ReportOnLineView>();
        reportOnLineViewList.add(new ReportOnLineView());
        reportOnLineViewList.add(new ReportOnLineView());
        doNothing().when(session).evict(Matchers.<Object>anyObject());
        reportOnlineDAO.detachAllReportOnlineView(reportOnLineViewList);
        verify(session, times(2)).evict(Matchers.<Object>anyObject());
    }

    @Test
    public void testSearchReportOnlineViewByFilterOptimized_RequiredFieldsOnly() {
        ReportOnLineFilter filter = getDefaultFilter();
        when(session.createQuery(anyString())).thenReturn(query);
        when(query.setParameter(anyString(), Matchers.<Object>anyObject())).thenReturn(query);
        when(query.setParameterList(anyString(), Matchers.<Collection>anyObject())).thenReturn(query);
        when(query.setResultTransformer(Matchers.<ResultTransformer>anyObject())).thenReturn(query);
        when(query.list()).thenReturn(new ArrayList<ReportOnLineView>());
        reportOnlineDAO.searchReportOnlineViewByFilterOptimized(filter);
        verify(session).createQuery(eq("select reportOnLineView from ReportOnLineView reportOnLineView where cropId = :cropId and companyId = :companyId and period between :dateFrom and :dateTo  and technologyId in (:technologyIds) "));
        verify(query, times(4)).setParameter(anyString(), Matchers.<Object>anyObject());
        verify(query, times(1)).setParameterList(anyString(), Matchers.<Collection>anyObject());
        verify(query).setResultTransformer(eq(Criteria.DISTINCT_ROOT_ENTITY));
        verify(query).list();
    }

    @Test
    public void testSearchReportOnlineViewByFilterOptimized() {
        ReportOnLineFilter filter = getCompleteFilter();
        when(session.createQuery(anyString())).thenReturn(query);
        when(query.setParameter(anyString(), Matchers.<Object>anyObject())).thenReturn(query);
        when(query.setParameterList(anyString(), Matchers.<Collection>anyObject())).thenReturn(query);
        when(query.setResultTransformer(Matchers.<ResultTransformer>anyObject())).thenReturn(query);
        when(query.list()).thenReturn(new ArrayList<ReportOnLineView>());
        reportOnlineDAO.searchReportOnlineViewByFilterOptimized(filter);
        verify(session).createQuery(eq("select reportOnLineView from ReportOnLineView reportOnLineView where cropId = :cropId and companyId = :companyId and period between :dateFrom and :dateTo and affiliateDocument = :affiliateDocument and affiliateUnitySapId = :affiliateUnitySapId and affiliateRegionSapId = :affiliateRegionSapId and affiliateDistrictSapId = :affiliateDistrictSapId and affiliateStateId = :affiliateStateId and affiliateCityId = :affiliateCityId  and technologyId in (:technologyIds) and matrixId = :matrixId and matrixUnitySapId = :matrixUnitySapId and matrixRegionSapId = :matrixRegionSapId and matrixDistrictSapId = :matrixDistrictSapId and rolStatusCode = :rolStatusCode and revenueSapOrderNumber = :revenueSapOrderNumber and revenueSapDocumentNumber = :revenueSapDocumentNumber and revenuePostDate >= :initRevenueDate and revenuePostDate <= :endRevenueDate "));
        verify(query, times(19)).setParameter(anyString(), Matchers.<Object>anyObject());
        verify(query, times(1)).setParameterList(anyString(), Matchers.<Collection>anyObject());
        verify(query).setResultTransformer(eq(Criteria.DISTINCT_ROOT_ENTITY));
        verify(query).list();
    }

    private ReportOnLineFilter getDefaultFilter() {
        ReportOnLineFilter filter = new ReportOnLineFilter();
        Company company = new Company();
        company.setId(1L);
        filter.setCompany(company);
        Crop crop = new Crop();
        crop.setId(1L);
        filter.setCrop(crop);
        Technology technology1 = new Technology();
        technology1.setId(1L);
        filter.getTechnologies().add(technology1);
        Technology technology2 = new Technology();
        technology1.setId(2L);
        filter.getTechnologies().add(technology2);
        Technology technology3 = new Technology();
        technology1.setId(3L);
        filter.getTechnologies().add(technology3);
        Technology technology4 = new Technology();
        technology1.setId(4L);
        filter.getTechnologies().add(technology4);
        filter.setInitDate(new Date());
        filter.setEndDate(new Date());
        return filter;
    }

    private ReportOnLineFilter getCompleteFilter() {
        ReportOnLineFilter filter = getDefaultFilter();
        Customer customer = new Customer();
        Document document = new Document();
        document.setValue("1234");
        customer.setDocument(document);
        filter.setCustomer(customer);
        ItsUnity itsUnity = new ItsUnity();
        itsUnity.setUnitySapId("00010000");
        filter.setCustomerUnity(itsUnity);
        ItsRegion itsRegion = new ItsRegion();
        itsRegion.setRegionSapId("00010001");
        filter.setCustomerRegion(itsRegion);
        ItsDistrict itsDistrict = new ItsDistrict();
        itsDistrict.setDistrictSapId("00010002");
        filter.setCustomerDistrict(itsDistrict);
        State state = new State();
        state.setId(1L);
        filter.setState(state);
        City city = new City();
        city.setId(1L);
        filter.setCity(city);
        filter.setOrderNumber("ABC-123");
        filter.setDocumentNumber("123-383");
        filter.setInitRevenueDate(new Date());
        filter.setEndRevenueDate(new Date());
        customer.setId(1L);
        filter.setMatrix(customer);
        itsUnity.setUnitySapId("01");
        filter.setUnity(itsUnity);
        itsRegion.setRegionSapId("02");
        filter.setRegion(itsRegion);
        itsDistrict.setDistrictSapId("03");
        filter.setDistrict(itsDistrict);
        RolStatus rolStatus = new RolStatus();
        rolStatus.setRolStatusCode("123");
        filter.setRolStatus(rolStatus);
        return filter;
    }
}
