/**
 * 
 */
package com.monsanto.brazilvaluecapture.pod.rol.report;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.MessageFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.ResourceBundle;

import org.apache.commons.lang3.StringUtils;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.monsanto.brazilvaluecapture.core.foundation.util.CalendarUtil;
import com.monsanto.brazilvaluecapture.core.foundation.util.report.ReportUtilAssert;
import com.monsanto.brazilvaluecapture.pod.rol.model.bean.VolumeToFixDTO;

/**
 * Unit Test for Volume to Fix from ROL.
 * 
 * @author andersonb
 */
public class VolumeToFixReportAssembler_UT {

    /**
     * Used Bundle.
     */
    private ResourceBundle resourceBundle = ResourceBundle.getBundle("bundle/bundle");

    private List<VolumeToFixDTO> reportSource = new ArrayList<VolumeToFixDTO>();

    @Before
    public void setup() {
        // Build Report
        buildReport();
    }

    private void buildReport() {
        VolumeToFixDTO dto = null;

        for (int i = 0; i < 3; i++) {
            dto = new VolumeToFixDTO();

            dto.setCompanyName("Company " + i);
            dto.setCropName("Crop " + i);
            dto.setAffiliateDocumentType("Doc. Type " + i);
            dto.setAffiliateDocumentMask("9999.999.99-99");
            dto.setAffiliateDocument("12345678901");
            dto.setAffiliateCustomerSapCode("Affiliate Doc. N� " + i);
            dto.setAffiliateName("Affiliate Name " + i);
            dto.setAffiliateUnitySapDesc("Affiliate Unity " + i);
            dto.setAffiliateRegionSapDesc("Affiliate Region " + i);
            dto.setAffiliateDistrictSapDesc("Affiliate District " + i);
            dto.setContractNumber("Contract " + i);
            dto.setMatrixSapCode("Code ERP (Matrix) " + i);
            dto.setMatrixDocumentType("Matrix Document Type " + i);
            dto.setMatrixDocumentMask("99.999.9999-99");
            dto.setMatrixDocument("12345678901" + i);
            dto.setMatrixName("Matrix Name " + i);
            dto.setMatrixUnitySapDesc("Matrix Unity " + i);
            dto.setMatrixRegionSapDesc("Matrix Region " + i);
            dto.setMatrixDistrictSapDesc("Matrix District " + i);
            dto.setTechnologyName("Technology " + i);
            dto.setVolumeReceived(BigDecimal.valueOf(i));
            dto.setVolumeFixPaidActualYear(BigDecimal.valueOf(i));
            dto.setVolumeFixPaidOldYear(BigDecimal.valueOf(i));
            dto.setVolumeCreditConsumption(BigDecimal.valueOf(i));

            reportSource.add(dto);
        }
    }

    @Test
    public void test_generate_report_basic() throws NoSuchMethodException, IOException {
        // Warning: keep this parameter like false
        Boolean enableOutputReport = Boolean.FALSE;

        Date periodReport = CalendarUtil.getDate(2010, Calendar.JANUARY, 1);
        VolumeToFixReportAssembler assembler = new VolumeToFixReportAssembler(reportSource, resourceBundle,
                periodReport, periodReport, periodReport, periodReport);

        ByteArrayOutputStream baos = assembler.build();
        Assert.assertNotNull(baos);

        // Check each report headers
        validateHeader(baos, periodReport);

        // Enable output for debug
        if (!enableOutputReport) {
            File file = File.createTempFile("volume_to_fix", ".xls");
            FileOutputStream fos = new FileOutputStream(file);
            fos.write(baos.toByteArray());
            fos.close();
        }
    }

    private void validateHeader(ByteArrayOutputStream baos, Date periodReport) throws IOException {

        DateFormat dateFormat = new SimpleDateFormat(resourceBundle.getString("pattern.period"));
        String startDateFmt = StringUtils.leftPad(String.valueOf(CalendarUtil.getDateMonth(periodReport) + 1), 2, '0');
        String periodDateFmt = dateFormat.format(periodReport);

        List<String> headers = new ArrayList<String>();
        headers.add(resourceBundle.getString("report.fixedvol.company.label"));
        headers.add(resourceBundle.getString("report.fixedvol.crop.label"));
        headers.add(resourceBundle.getString("report.fixedvol.affiliate.document.type.label"));
        headers.add(resourceBundle.getString("report.fixedvol.affiliate.document.label"));
        headers.add(resourceBundle.getString("report.fixedvol.affiliate.customer.sapcode"));
        headers.add(resourceBundle.getString("report.fixedvol.affiliate.name"));
        headers.add(resourceBundle.getString("report.fixedvol.affiliate.unity.sapdesc"));
        headers.add(resourceBundle.getString("report.fixedvol.affiliate.region.sapdesc"));
        headers.add(resourceBundle.getString("report.fixedvol.affiliate.district.sapdesc"));
        headers.add(resourceBundle.getString("report.fixedvol.matrix.contract.number"));
        headers.add(resourceBundle.getString("report.fixedvol.matrix.customer.sapcode"));
        headers.add(resourceBundle.getString("report.fixedvol.matrix.document.type.label"));
        headers.add(resourceBundle.getString("report.fixedvol.matrix.document.label"));
        headers.add(resourceBundle.getString("report.fixedvol.matrix.name"));
        headers.add(resourceBundle.getString("report.fixedvol.matrix.unity.sapdesc"));
        headers.add(resourceBundle.getString("report.fixedvol.matrix.region.sapdesc"));
        headers.add(resourceBundle.getString("report.fixedvol.matrix.district.sapdesc"));
        headers.add(resourceBundle.getString("report.fixedvol.technology.name"));
        headers.add(MessageFormat.format(resourceBundle.getString("report.fixedvol.volume.received.label"),
                new Object[] { startDateFmt, periodDateFmt }));
        headers.add(MessageFormat.format(resourceBundle.getString("report.fixedvol.volume.fixpaid.actualyear.label"),
                new Object[] { startDateFmt, periodDateFmt }));
        headers.add(MessageFormat.format(resourceBundle.getString("report.fixedvol.volume.fixpaid.oldyear.label"),
                new Object[] { startDateFmt, periodDateFmt }));
        headers.add(MessageFormat.format(resourceBundle.getString("report.fixedvol.volume.creditconsumption.label"),
                new Object[] { periodDateFmt, periodDateFmt }));
        headers.add(resourceBundle.getString("report.fixedvol.volume.amounttofix.label"));

        int columnIndex = 0;
        for (String header : headers) {
            ReportUtilAssert.assertEqualsCell(baos, 0, 0, columnIndex++, header);
        }

    }
}
