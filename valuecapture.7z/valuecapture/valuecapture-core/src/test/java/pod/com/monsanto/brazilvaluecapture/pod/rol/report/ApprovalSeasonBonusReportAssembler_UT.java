/**
 * 
 */
package com.monsanto.brazilvaluecapture.pod.rol.report;

import static junit.framework.Assert.assertNotNull;

import java.io.ByteArrayOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.ResourceBundle;

import org.junit.Before;
import org.junit.Test;

import com.monsanto.brazilvaluecapture.core.foundation.util.report.ReportUtilAssert;
import com.monsanto.brazilvaluecapture.core.revenue.model.bean.CharConsolidAppSeasonBonusDTO;
import com.monsanto.brazilvaluecapture.core.revenue.model.bean.ChargeConsolidateStatus;

/**
 * Unit Test for the Approval Season Bonus Report Assembler.
 * 
 * @author andersonb
 */
public class ApprovalSeasonBonusReportAssembler_UT {

    /**
     * Bundle
     */
    private ResourceBundle resourceBundle = ResourceBundle.getBundle("bundle/bundle");

    /**
     * Source
     */
    private List<CharConsolidAppSeasonBonusDTO> reportSource = new ArrayList<CharConsolidAppSeasonBonusDTO>();

    @Before
    public void setup() {
        // Build report
        buildReport();
    }

	private void buildReport() {
		CharConsolidAppSeasonBonusDTO dto = new CharConsolidAppSeasonBonusDTO();
		dto.setBundle(resourceBundle);
		
		dto.setCompanyName("Company 1");
		dto.setCropName("Crop 1");
		dto.setDocumentType("POD");
		
		// Set the Mask for current document number.
		dto.setDocumentMask("999.999.999-99");
		dto.setDocument("12345678912");
		
		dto.setHeadofficeName("HeadOffice 1");
		dto.setCity("City 1");
		dto.setState("State 1");
		dto.setUnity("Unity 1");
		dto.setRegion("Region 1");
		dto.setDistrict("District 1");
		dto.setPeriod(Calendar.getInstance().getTime());
		dto.setPercent(BigDecimal.valueOf(50,50));
		dto.setValue(BigDecimal.valueOf(10,30));
		dto.setStatus(ChargeConsolidateStatus.RELEASED.getId().toString());
		dto.setLastUpdateDate(Calendar.getInstance().getTime());
		
		reportSource.add(dto);
		reportSource.add(dto);
	}
	
	@Test
	public void test_generate_report_basic() throws NoSuchMethodException, IOException {
        // Warning: keep this parameter like false
        Boolean enableOutputReport = Boolean.FALSE;

        // Assembly the report
		ApprovalSeasonBonusReportAssembler assembler = new ApprovalSeasonBonusReportAssembler(
				reportSource, resourceBundle);
		
		ByteArrayOutputStream baos = assembler.build();
		assertNotNull(baos);
		
		// Check each report headers
		validateHeader(baos);
		
		// Enable output for debug
		if (enableOutputReport) {
            FileOutputStream fos = new FileOutputStream("c:\\junit_report.xls");
            fos.write(baos.toByteArray());
            fos.close();
		}
	}

	private void validateHeader(final ByteArrayOutputStream baos) throws IOException {
		String[] headers = new String[] {
				"label.user.company", 
				"label.user.crop",
				"pod.approval.seasonbonus.report.headoffice.documentType",
				"pod.approval.seasonbonus.report.headoffice.documentFormatted",
				"pod.approval.seasonbonus.report.headoffice.name",
				"label.city",
				"label.state",
				"label.unit",
				"label.region",
				"label.district",
				"label.period",
				"label.percent",
				"label.value",
				"label.status",
				"pod.approval.seasonbonus.report.headoffice.lastUpdateDate"
			};
		
		int columnIndex = 0;
		for (String header : headers) {
			ReportUtilAssert.assertEqualsCell(baos, 0, 0, columnIndex++, resourceBundle.getString(header));
		}
		
	}
}
