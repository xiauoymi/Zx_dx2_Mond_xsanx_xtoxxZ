package com.monsanto.brazilvaluecapture.pod.service.impl;

import com.monsanto.brazilvaluecapture.core.account.model.bean.Account;
import com.monsanto.brazilvaluecapture.core.base.model.bean.CreditConsumption;
import com.monsanto.brazilvaluecapture.core.base.model.bean.CreditConsumptionItem;
import com.monsanto.brazilvaluecapture.core.base.model.bean.CreditConsumptionStatus;
import com.monsanto.brazilvaluecapture.core.base.model.bean.OperationalYear;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.HeadOffice;
import com.monsanto.brazilvaluecapture.core.grower.model.bean.Grower;
import com.monsanto.brazilvaluecapture.pod.model.bean.Waybill;
import org.junit.Test;

import java.math.BigDecimal;
import java.util.*;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

/**
 * Created with IntelliJ IDEA.
 * User: JFVERO
 * Date: 14/01/14
 * Time: 14:57
 */
public class PrepaidTonsConsumptionRule_UT {

    private static final long DETECTED_VALUE = 15L;

    @Test
    public void testWhenDetectedValueIsZeroThenNoConsumptionsOccur() {
        Waybill waybill = createWaybill(0L);
        List<Account> accounts = Collections.emptyList();

        PrepaidTonsConsumptionRule rule = new PrepaidTonsConsumptionRule().apply(waybill, accounts);

        assertFalse(rule.hasConsumed());
        assertNull(rule.getCreditConsumption());
        assertEquals(0L, rule.getRemainingKgs().longValue());
    }

    @Test
    public void testWhenNoAccountsThenNoConsumptionsOccur() {
        Waybill waybill = createWaybill(DETECTED_VALUE);
        List<Account> accounts = Collections.emptyList();

        PrepaidTonsConsumptionRule rule = new PrepaidTonsConsumptionRule().apply(waybill, accounts);

        assertFalse(rule.hasConsumed());
        assertNull(rule.getCreditConsumption());
        assertEquals(DETECTED_VALUE, rule.getRemainingKgs().longValue());
    }

    @Test
    public void testConsumptionsAreMadeOnPositiveBalances() {
        Waybill waybill = createWaybill(DETECTED_VALUE);
        List<Account> accounts = new ArrayList<Account>();
        accounts.add(createAccount(0L, 2013));
        accounts.add(createAccount(12L, 2014));

        PrepaidTonsConsumptionRule rule = new PrepaidTonsConsumptionRule().apply(waybill, accounts);

        assertTrue(rule.hasConsumed());
        assertCreditConsumption(waybill, rule.getCreditConsumption());
        assertEquals(1, rule.getCreditConsumption().getCreditConsumptionItens().size());
        assertHasCreditConsumptionItem(12L, 2014, rule.getCreditConsumption().getCreditConsumptionItens());
        assertEquals(3L, rule.getRemainingKgs().longValue());
    }

    @Test
    public void testConsumptionsAreMadeOnOlderBalancesFirst() {
        Waybill waybill = createWaybill(DETECTED_VALUE);
        List<Account> accounts = new ArrayList<Account>();
        accounts.add(createAccount(20L, 2014));
        accounts.add(createAccount(12L, 2013));

        PrepaidTonsConsumptionRule rule = new PrepaidTonsConsumptionRule().apply(waybill, accounts);

        assertTrue(rule.hasConsumed());
        assertCreditConsumption(waybill, rule.getCreditConsumption());
        assertEquals(2, rule.getCreditConsumption().getCreditConsumptionItens().size());
        assertHasCreditConsumptionItem(12L, 2013, rule.getCreditConsumption().getCreditConsumptionItens());
        assertHasCreditConsumptionItem(3L, 2014, rule.getCreditConsumption().getCreditConsumptionItens());
        assertEquals(0L, rule.getRemainingKgs().longValue());
    }

    private static void assertCreditConsumption(Waybill waybill, CreditConsumption creditConsumption) {
        assertEquals(CreditConsumptionStatus.OPENED, creditConsumption.getCreditConsumptionStatus());
        assertEquals(waybill.getGrower(), creditConsumption.getGrower());
        assertEquals(waybill.getAddresseeHeadOffice(), creditConsumption.getHeadoffice());
    }

    private static void assertHasCreditConsumptionItem(long requestValue, int year, Set<CreditConsumptionItem> items) {
        for (CreditConsumptionItem item: items) {
            if (requestValue == item.getRequestValue().longValue() &&
                    year == item.getOperationalYear().getNumericalYear().intValue()) {
                return;
            }
        }
        fail("Expected CreditConsumptionItem not found!");
    }

    private static Waybill createWaybill(long detectedValue) {
        Waybill waybill = mock(Waybill.class);
        when(waybill.getDetectedValue()).thenReturn(detectedValue);
        when(waybill.getGrower()).thenReturn(mock(Grower.class));
        when(waybill.getAddresseeHeadOffice()).thenReturn(mock(HeadOffice.class));
        return waybill;
    }

    private static Account createAccount(long balance, int year) {
        OperationalYear operationalYear = mock(OperationalYear.class);
        when(operationalYear.getNumericalYear()).thenReturn(year);

        Account account = mock(Account.class);
        when(account.getBalance()).thenReturn(BigDecimal.valueOf(balance));
        when(account.getOperationalYear()).thenReturn(operationalYear);
        return account;
    }

}