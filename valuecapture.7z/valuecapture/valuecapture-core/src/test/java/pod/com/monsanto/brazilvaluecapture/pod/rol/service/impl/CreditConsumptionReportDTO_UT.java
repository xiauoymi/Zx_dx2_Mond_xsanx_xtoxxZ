package com.monsanto.brazilvaluecapture.pod.rol.service.impl;

import java.math.BigDecimal;
import java.util.Date;
import java.util.ListResourceBundle;
import java.util.ResourceBundle;

import junit.framework.Assert;

import org.junit.Before;
import org.junit.Test;

import com.monsanto.brazilvaluecapture.core.base.model.bean.Address;
import com.monsanto.brazilvaluecapture.core.base.model.bean.BillingAddress;
import com.monsanto.brazilvaluecapture.core.base.model.bean.BusinessAddress;
import com.monsanto.brazilvaluecapture.core.base.model.bean.City;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Company;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Country;
import com.monsanto.brazilvaluecapture.core.base.model.bean.CreditConsumption;
import com.monsanto.brazilvaluecapture.core.base.model.bean.CreditConsumptionItem;
import com.monsanto.brazilvaluecapture.core.base.model.bean.CreditConsumptionStatus;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Crop;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Document;
import com.monsanto.brazilvaluecapture.core.base.model.bean.DocumentType;
import com.monsanto.brazilvaluecapture.core.base.model.bean.OperationalYear;
import com.monsanto.brazilvaluecapture.core.base.model.bean.State;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Customer;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.HeadOffice;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.ParticipantTypeEnum;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Technology;
import com.monsanto.brazilvaluecapture.core.foundation.RandomTestData;
import com.monsanto.brazilvaluecapture.core.grower.CreateTestData;
import com.monsanto.brazilvaluecapture.core.grower.model.bean.Grower;
import com.monsanto.brazilvaluecapture.pod.credit.report.CreditConsumptionReportDTO;

public class CreditConsumptionReportDTO_UT extends CreateTestData {

    private ResourceBundle bundle;

    @Before
    public void setup() {
        bundle = new TestResourceBundle();
    }

    @Test
    public void createObjectConstructorTest() {

        // Create system data
        Country country = new Country("Brasil", "br");
        Company company = new Company("monsanto");
        Crop crop = new Crop("soya", company, country);
        OperationalYear operationalYear = new OperationalYear("2012");
        Technology technologyXpto = new Technology("xpto", company);

        State state = new State();
        state.setCode("SP");
        state.setCountry(country);
        state.setDescription("Sao Paulo");

        City city = new City();
        city.setDescription("A. Nogueira");
        city.setId(1L);
        city.setState(state);

        Address address = new Address();
        address.setCity(city);
        address.setCountry(country);
        address.setState(state);
        address.setStreet("street of tomorrow");
        address.setZipCode("123456");

        // Create head office
        Customer participant = new Customer("zeca", new Document(new DocumentType("t1", country, "##"), "123"), address, RandomTestData.createRandomLong().toString());
        participant.setCustomerSAPCode("juca");
        Customer matrix = new Customer("maria", new Document(new DocumentType("t1", country, "##"), "123"), address, RandomTestData.createRandomLong().toString());
        matrix.setCustomerSAPCode("max");
        HeadOffice headoffice = new HeadOffice(participant, matrix, ParticipantTypeEnum.POD, crop, company);

        CreditConsumption creditConsumption = new CreditConsumption();
        creditConsumption.setId(-1L);
        creditConsumption.setCorrectionDate(new Date());
        creditConsumption.setCorrectionItsUserLogin("juquinha");
        creditConsumption.setCreditConsumptionDate(new Date());
        creditConsumption.setCreditConsumptionStatus(CreditConsumptionStatus.PROCESSED);
        creditConsumption.setHeadoffice(headoffice);
        creditConsumption.setOriginalCreditConsumption(new CreditConsumption());
        creditConsumption.getOriginalCreditConsumption().setId(2L);
        creditConsumption.setReversalDate(new Date());
        creditConsumption.setItsUserLogin("mariazinha");
        creditConsumption.setReversalItsUserLogin("saci");

        Grower grower = new Grower();
        grower.setAlias("");
        grower.setBillingAddress(new BillingAddress("", "", "", "", "", "", "", city, state, country));
        grower.setBusinessAddress(new BusinessAddress("", "", "", "", "", "", "", city, state, country));
        grower.setDocument(new Document(new DocumentType("t1", country, "##"), "123"));
        grower.setEmail("");
        grower.setName("");

        CreditConsumptionItem item = new CreditConsumptionItem();
        item.setBalance(new BigDecimal("9"));
        item.setCorrectionValue(new BigDecimal("6"));
        item.setCreditConsumption(creditConsumption);
        item.setCrop(crop);
        item.setGrower(grower);
        item.setId(2L);
        item.setOperationalYear(operationalYear);
        item.setRequestValue(new BigDecimal("45"));
        item.setTechnology(technologyXpto);

        CreditConsumptionReportDTO dto = new CreditConsumptionReportDTO(item, bundle);

        testAssert(dto);

    }

    /**
     * Validating of grower
     * 
     * @param grower
     */
    private void testAssert(CreditConsumptionReportDTO dto) {

        Assert.assertNotNull(dto);
        Assert.assertNotNull(dto.getCompany());
        Assert.assertNotNull(dto.getCostumerDocument());
        Assert.assertNotNull(dto.getCostumerName());
        Assert.assertNotNull(dto.getCostumerSAPCode());
        Assert.assertNotNull(dto.getCostumerSAPCode());
        Assert.assertNotNull(dto.getCreditConsumptionStatus());
        Assert.assertNotNull(dto.getCreditConsumptionUser());
        Assert.assertNotNull(dto.getCrop());
        Assert.assertNotNull(dto.getCustomerCity());
        Assert.assertNotNull(dto.getCustomerDistrict());
        Assert.assertNotNull(dto.getCustomerRegion());
        Assert.assertNotNull(dto.getCustomerState());
        Assert.assertNotNull(dto.getCustomerUnit());
        Assert.assertNotNull(dto.getGrowerCity());
        Assert.assertNotNull(dto.getGrowerDocument());
        Assert.assertNotNull(dto.getGrowerName());
        Assert.assertNotNull(dto.getGrowerState());
        Assert.assertNotNull(dto.getMatrixContract());
        Assert.assertNotNull(dto.getMatrixDistrict());
        Assert.assertNotNull(dto.getMatrixDocument());
        Assert.assertNotNull(dto.getMatrixName());
        Assert.assertNotNull(dto.getMatrixRegion());
        Assert.assertNotNull(dto.getMatrixSAPCode());
        Assert.assertNotNull(dto.getMatrixUnit());
        Assert.assertNotNull(dto.getOperationalYear());
        Assert.assertNotNull(dto.getReturnUser());
        Assert.assertNotNull(dto.getTechnology());
        Assert.assertNotNull(dto.getCreateCreditConsumptionDate());
        Assert.assertNotNull(dto.getOriginalCreditConsumptionItemId());
        Assert.assertNotNull(dto.getCreditConsumptionItemId());
        Assert.assertNotNull(dto.getReturnDate());
        Assert.assertNotNull(dto.getVolume());

    }

    private class TestResourceBundle extends ListResourceBundle {

        private Object[][] contents = new Object[][] { { "pod.credit.list.grid.consumption.status.p", "a" },
                { "msgError", "error message" } };

        protected Object[][] getContents() {
            return contents;
        }
    }

}
