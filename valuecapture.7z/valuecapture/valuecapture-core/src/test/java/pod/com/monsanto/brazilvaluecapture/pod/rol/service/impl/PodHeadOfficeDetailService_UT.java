package com.monsanto.brazilvaluecapture.pod.rol.service.impl;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashSet;
import java.util.List;

import junit.framework.Assert;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

import com.monsanto.brazilvaluecapture.core.base.model.bean.Company;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Country;
import com.monsanto.brazilvaluecapture.core.base.model.bean.CreditConsumption;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Crop;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Document;
import com.monsanto.brazilvaluecapture.core.base.model.bean.DocumentType;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Contract;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Customer;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.HeadOffice;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.ParticipantTypeEnum;
import com.monsanto.brazilvaluecapture.core.customer.model.dao.ParticipantDAO;
import com.monsanto.brazilvaluecapture.core.customer.service.ContractNotFoundException;
import com.monsanto.brazilvaluecapture.core.customer.service.ContractService;
import com.monsanto.brazilvaluecapture.core.customer.service.HeadOfficeDetailException;
import com.monsanto.brazilvaluecapture.core.customer.service.ParticipantService;
import com.monsanto.brazilvaluecapture.core.foundation.RandomTestData;
import com.monsanto.brazilvaluecapture.core.foundation.service.BusinessException;
import com.monsanto.brazilvaluecapture.core.foundation.util.ConstraintViolation;
import com.monsanto.brazilvaluecapture.pod.credit.service.CreditConsumptionException;
import com.monsanto.brazilvaluecapture.pod.credit.service.CreditConsumptionFilter;
import com.monsanto.brazilvaluecapture.pod.credit.service.CreditService;
import com.monsanto.brazilvaluecapture.pod.credit.service.OtherRolValueFilter;
import com.monsanto.brazilvaluecapture.pod.rol.model.bean.HeadOfficeDetail;
import com.monsanto.brazilvaluecapture.pod.rol.model.bean.HeadOfficeEffectiveDate;
import com.monsanto.brazilvaluecapture.pod.rol.model.bean.OtherRolValue;
import com.monsanto.brazilvaluecapture.pod.rol.model.bean.PaidVolumeByGrower;
import com.monsanto.brazilvaluecapture.pod.rol.model.bean.ReportOnLine;
import com.monsanto.brazilvaluecapture.pod.rol.model.service.BilledRolFoundForMatrixException;
import com.monsanto.brazilvaluecapture.pod.rol.model.service.OtherReportOnLineService;
import com.monsanto.brazilvaluecapture.pod.rol.model.service.PaidVolumeFilter;
import com.monsanto.brazilvaluecapture.pod.rol.model.service.PodHeadOfficeDetailConstraintException;
import com.monsanto.brazilvaluecapture.pod.rol.model.service.ReportOnLineByGrowerService;
import com.monsanto.brazilvaluecapture.pod.rol.model.service.ReportOnLineFilter;
import com.monsanto.brazilvaluecapture.pod.rol.model.service.ReportOnLineService;
import com.monsanto.brazilvaluecapture.pod.rol.model.service.ReportOnlineByGrowerException;
import com.monsanto.brazilvaluecapture.pod.rol.model.service.RolInformationService;
import com.monsanto.brazilvaluecapture.pod.rol.model.service.impl.OtherReportOnlineConstraintException;
import com.monsanto.brazilvaluecapture.pod.rol.model.service.impl.PodHeadOfficeDetailServiceImpl;

/**
 * @author cmiranda
 * 
 */
public class PodHeadOfficeDetailService_UT {

    /**
     * Service for test.
     */
    private PodHeadOfficeDetailServiceImpl podHeadOfficeDetailService;

    /**
     * Service for mock
     */
    private CreditService creditService;
    private ParticipantDAO participantDAO;
    private ContractService contractService;
    private ParticipantService participantService;
    private ReportOnLineService reportOnLineService;
    private OtherReportOnLineService otherReportOnLineService;
    private ReportOnLineByGrowerService reportOnLineByGrowerService;
    private RolInformationService rolInformationService;

    // Headoffice for test
    private HeadOfficeDetail headOfficeDetail;

    // Contract of matrix
    private Contract matrixContract;

    /**
     * @throws ContractNotFoundException
     */
    @Before
    public void setup() throws ContractNotFoundException {

        Calendar calendar = Calendar.getInstance();

        // Service that must be tested
        podHeadOfficeDetailService = new PodHeadOfficeDetailServiceImpl();

        // Create system data
        Country country = new Country("USA", "usa");
        Company company = new Company("monsanto");
        Crop crop = new Crop("soya", company, country);

        // Create head office
        Customer participant = new Customer("john", null, null, RandomTestData.createRandomLong().toString());
        Customer matrix = new Customer("mary", new Document(null, "344"), null, RandomTestData.createRandomLong().toString());
        HeadOffice headoffice = new HeadOffice(participant, matrix, ParticipantTypeEnum.POD, crop, company);

        // Create matrix contract
        matrixContract = new Contract();
        matrixContract.setCompany(company);
        matrixContract.setContractCode("c0000001");
        matrixContract.setCrop(crop);
        matrixContract.setCustomer(matrix);
        matrixContract.setParticipantType(ParticipantTypeEnum.POD);
        matrixContract.setStartDate(calendar.getTime());
        calendar.add(Calendar.YEAR, 10);
        matrixContract.setEndDate(calendar.getTime());
        matrix.addContract(matrixContract);

        // Create head office detail
        headOfficeDetail = new HeadOfficeDetail();
        headOfficeDetail.setHeadoffice(headoffice);
        headOfficeDetail.setReportRol(Boolean.TRUE);
        headOfficeDetail.setShowParticipantInList(Boolean.TRUE);

        // Configure mocks
        creditService = Mockito.mock(CreditService.class);
        podHeadOfficeDetailService.setCreditService(creditService);

        participantDAO = Mockito.mock(ParticipantDAO.class);
        podHeadOfficeDetailService.setParticipantDAO(participantDAO);

        contractService = Mockito.mock(ContractService.class);

        participantService = Mockito.mock(ParticipantService.class);
        podHeadOfficeDetailService.setParticipantService(participantService);

        rolInformationService = Mockito.mock(RolInformationService.class);
        
        reportOnLineService = Mockito.mock(ReportOnLineService.class);
        podHeadOfficeDetailService.setReportOnLineService(reportOnLineService);
        podHeadOfficeDetailService.setRolInformationService(rolInformationService);

        otherReportOnLineService = Mockito.mock(OtherReportOnLineService.class);
        podHeadOfficeDetailService.setOtherRolService(otherReportOnLineService);

        reportOnLineByGrowerService = Mockito.mock(ReportOnLineByGrowerService.class);
        podHeadOfficeDetailService.setReportOnLineByGrowerService(reportOnLineByGrowerService);

        // Create defaults scenery

        // search headoffice detail
        Mockito.when(participantService.selectHeadOfficeDetailById(headOfficeDetail.getId())).thenReturn(
                headOfficeDetail);

        // search matrix contracts
        List<Contract> contracts = new ArrayList<Contract>();
        contracts.add(matrixContract);
        Mockito.when(
                contractService.getContractsByFilter(crop, company, matrix.getDocumentValue(), null, matrix.getId(),
                        ParticipantTypeEnum.POD)).thenReturn(contracts);

    }

    /**
     * Check change periods with report online in uncovered period.
     * 
     * @throws ContractNotFoundException
     */
    @Test
    public void test_save_pod_headoffice_effective_date_with_rol_reported_in_period() throws ContractNotFoundException {

        // Create period range
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(matrixContract.getStartDate());
        calendar.add(Calendar.MONTH, 2);
        Date dtStartReference = calendar.getTime();
        calendar.add(Calendar.MONTH, 1);
        Date dtStart = calendar.getTime();
        calendar.add(Calendar.MONTH, 5);
        Date dtEnd = calendar.getTime();

        // Create affiliate contract periods for update
        HeadOfficeEffectiveDate headOfficeEffectiveDate = new HeadOfficeEffectiveDate();
        headOfficeEffectiveDate.setId(60606L);
        headOfficeEffectiveDate.setHeadOfficeDetail(headOfficeDetail);
        headOfficeEffectiveDate.setInitDate(dtStart);
        headOfficeEffectiveDate.setEndDate(dtEnd);

        // Set reference
        HeadOfficeEffectiveDate reference = new HeadOfficeEffectiveDate(headOfficeEffectiveDate);
        reference.setInitDate(dtStartReference);

        // Associate
        headOfficeDetail.getHeadOfficeEffectiveDates().add(reference);

        // Build mock's scenery

        // Mock for search report on periods
        List<ReportOnLine> resultReportOnline = new ArrayList<ReportOnLine>();
        resultReportOnline.add(new ReportOnLine());
        Mockito.when(reportOnLineService.selectReportOnLineListByFilter((ReportOnLineFilter) Mockito.anyObject()))
                .thenReturn(resultReportOnline);

        try {

            // Try update this
            podHeadOfficeDetailService.savePodHeadOfficeEffectiveDate(headOfficeEffectiveDate);

            Assert.fail("Expected PodHeadOfficeDetailConstraintException.");

        } catch (PodHeadOfficeDetailConstraintException e) {

            for (ConstraintViolation c : e.getViolations()) {
                Assert.assertEquals("Expected uncored period constraint.",
                        PodHeadOfficeDetailConstraintException.RECORDS_IN_UNCOVERED_PERIODS_ERROR_CODE, c.getCode());
            }

        }

    }

    /**
     * Check change periods with report online in uncovered period.
     * 
     * @throws ContractNotFoundException
     * @throws OtherReportOnlineConstraintException
     */
    @Test
    public void test_save_pod_headoffice_effective_date_with_rol_for_other_reported_in_period()
            throws ContractNotFoundException, OtherReportOnlineConstraintException {

        // Create period range
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(matrixContract.getStartDate());
        calendar.add(Calendar.MONTH, 2);
        Date dtStartReference = calendar.getTime();
        calendar.add(Calendar.MONTH, 1);
        Date dtStart = calendar.getTime();
        calendar.add(Calendar.MONTH, 5);
        Date dtEnd = calendar.getTime();

        // Create affiliate contract periods for update
        HeadOfficeEffectiveDate headOfficeEffectiveDate = new HeadOfficeEffectiveDate();
        headOfficeEffectiveDate.setId(60606L);
        headOfficeEffectiveDate.setHeadOfficeDetail(headOfficeDetail);
        headOfficeEffectiveDate.setInitDate(dtStart);
        headOfficeEffectiveDate.setEndDate(dtEnd);

        // Set reference
        HeadOfficeEffectiveDate reference = new HeadOfficeEffectiveDate(headOfficeEffectiveDate);
        reference.setInitDate(dtStartReference);

        // Associate
        headOfficeDetail.getHeadOfficeEffectiveDates().add(reference);

        // Build mock's scenery

        // Mock for search report on periods
        List<OtherRolValue> resultReportOnline = new ArrayList<OtherRolValue>();
        resultReportOnline.add(new OtherRolValue());
        Mockito.when(
                otherReportOnLineService.searchOtherReportOnlineByFilter((OtherRolValueFilter) Mockito.anyObject()))
                .thenReturn(resultReportOnline);

        try {

            // Try update this
            podHeadOfficeDetailService.savePodHeadOfficeEffectiveDate(headOfficeEffectiveDate);

            Assert.fail("Expected PodHeadOfficeDetailConstraintException.");

        } catch (PodHeadOfficeDetailConstraintException e) {

            for (ConstraintViolation c : e.getViolations()) {
                Assert.assertEquals("Expected uncored period constraint.",
                        PodHeadOfficeDetailConstraintException.RECORDS_IN_UNCOVERED_PERIODS_ERROR_CODE, c.getCode());
            }

        }

    }

    /**
     * Check change periods with report online in uncovered period.
     * 
     * @throws ContractNotFoundException
     * @throws OtherReportOnlineConstraintException
     * @throws CreditConsumptionException
     */
    @Test
    public void test_save_pod_headoffice_effective_date_with_credit_consumption_in_period()
            throws ContractNotFoundException, OtherReportOnlineConstraintException, CreditConsumptionException {

        // Create period range
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(matrixContract.getStartDate());
        calendar.add(Calendar.MONTH, 2);
        Date dtStartReference = calendar.getTime();
        calendar.add(Calendar.MONTH, 1);
        Date dtStart = calendar.getTime();
        calendar.add(Calendar.MONTH, 5);
        Date dtEnd = calendar.getTime();

        // Create affiliate contract periods for update
        HeadOfficeEffectiveDate headOfficeEffectiveDate = new HeadOfficeEffectiveDate();
        headOfficeEffectiveDate.setId(60606L);
        headOfficeEffectiveDate.setHeadOfficeDetail(headOfficeDetail);
        headOfficeEffectiveDate.setInitDate(dtStart);
        headOfficeEffectiveDate.setEndDate(dtEnd);

        // Set reference
        HeadOfficeEffectiveDate reference = new HeadOfficeEffectiveDate(headOfficeEffectiveDate);
        reference.setInitDate(dtStartReference);

        // Associate
        headOfficeDetail.getHeadOfficeEffectiveDates().add(reference);

        // Build mock's scenery

        // Mock for search report on periods
        List<CreditConsumption> resultReportOnline = new ArrayList<CreditConsumption>();
        resultReportOnline.add(new CreditConsumption());

        Mockito.when(creditService.selectCreditConsumptionListByFilter((CreditConsumptionFilter) Mockito.anyObject()))
                .thenReturn(resultReportOnline);

        try {

            // Try update this
            podHeadOfficeDetailService.savePodHeadOfficeEffectiveDate(headOfficeEffectiveDate);

            Assert.fail("Expected PodHeadOfficeDetailConstraintException.");

        } catch (PodHeadOfficeDetailConstraintException e) {

            for (ConstraintViolation c : e.getViolations()) {
                Assert.assertEquals("Expected uncored period constraint.",
                        PodHeadOfficeDetailConstraintException.RECORDS_IN_UNCOVERED_PERIODS_ERROR_CODE, c.getCode());
            }

        }

    }

    /**
     * Check change periods with report online in uncovered period.
     * 
     * @throws ContractNotFoundException
     * @throws OtherReportOnlineConstraintException
     * @throws CreditConsumptionException
     * @throws ReportOnlineByGrowerException
     */
    @Test
    public void test_save_pod_headoffice_effective_date_with_rol_for_grower_in_period()
            throws ContractNotFoundException, OtherReportOnlineConstraintException, CreditConsumptionException,
            ReportOnlineByGrowerException {

        // Create period range
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(matrixContract.getStartDate());
        calendar.add(Calendar.MONTH, 2);
        Date dtStartReference = calendar.getTime();
        calendar.add(Calendar.MONTH, 1);
        Date dtStart = calendar.getTime();
        calendar.add(Calendar.MONTH, 5);
        Date dtEnd = calendar.getTime();

        // Create affiliate contract periods for update
        HeadOfficeEffectiveDate headOfficeEffectiveDate = new HeadOfficeEffectiveDate();
        headOfficeEffectiveDate.setId(60606L);
        headOfficeEffectiveDate.setHeadOfficeDetail(headOfficeDetail);
        headOfficeEffectiveDate.setInitDate(dtStart);
        headOfficeEffectiveDate.setEndDate(dtEnd);

        // Set reference
        HeadOfficeEffectiveDate reference = new HeadOfficeEffectiveDate(headOfficeEffectiveDate);
        reference.setInitDate(dtStartReference);

        // Associate
        headOfficeDetail.getHeadOfficeEffectiveDates().add(reference);

        // Build mock's scenery

        // Mock for search report on periods
        List<PaidVolumeByGrower> resultReportOnline = new ArrayList<PaidVolumeByGrower>();
        resultReportOnline.add(new PaidVolumeByGrower());

        Mockito.when(
                reportOnLineByGrowerService.selectPaidVolumeByGrowerListByFilter((PaidVolumeFilter) Mockito.anyObject()))
                .thenReturn(resultReportOnline);

        try {

            // Try update this
            podHeadOfficeDetailService.savePodHeadOfficeEffectiveDate(headOfficeEffectiveDate);

            Assert.fail("Expected PodHeadOfficeDetailConstraintException.");

        } catch (PodHeadOfficeDetailConstraintException e) {

            for (ConstraintViolation c : e.getViolations()) {
                Assert.assertEquals("Expected uncored period constraint.",
                        PodHeadOfficeDetailConstraintException.RECORDS_IN_UNCOVERED_PERIODS_ERROR_CODE, c.getCode());
            }

        }

    }

    /**
     * Check change periods with report online in uncovered period.
     * 
     * @throws ContractNotFoundException
     * @throws OtherReportOnlineConstraintException
     * @throws CreditConsumptionException
     * @throws ReportOnlineByGrowerException
     */
    @Test
    public void test_save_pod_head_office_effective_date_in_period_with_processed_rol_for_matrix_expected_violated_constraint_exception()
            throws ContractNotFoundException, OtherReportOnlineConstraintException, CreditConsumptionException,
            ReportOnlineByGrowerException {

        // Create period range
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(matrixContract.getStartDate());
        calendar.add(Calendar.MONTH, 2);
        Date dtStartReference = calendar.getTime();

        calendar.add(Calendar.MONTH, 1);
        Date dtStart = calendar.getTime();
        calendar.add(Calendar.MONTH, 5);
        Date dtEnd = calendar.getTime();

        // Create affiliate contract periods for update
        HeadOfficeEffectiveDate headOfficeEffectiveDate = new HeadOfficeEffectiveDate();
        headOfficeEffectiveDate.setId(60606L);
        headOfficeEffectiveDate.setHeadOfficeDetail(headOfficeDetail);
        headOfficeEffectiveDate.setInitDate(dtStartReference);
        headOfficeEffectiveDate.setEndDate(dtEnd);

        // Set reference
        HeadOfficeEffectiveDate reference = new HeadOfficeEffectiveDate(headOfficeEffectiveDate);
        reference.setInitDate(dtStart);

        // Associate
        headOfficeDetail.getHeadOfficeEffectiveDates().add(reference);

        // Build mock's scenery

        // Mock for search report on periods
        List<Long> resultReportOnline = new ArrayList<Long>();
        resultReportOnline.add(999L);

        // Mock result.
        Mockito.when(
                reportOnLineService.selectReportOnLineIdInProcessedStateByFilter((ReportOnLineFilter) Mockito
                        .anyObject())).thenReturn(resultReportOnline);

        try {

            // Try update this
            podHeadOfficeDetailService.savePodHeadOfficeEffectiveDate(headOfficeEffectiveDate);

            Assert.fail("Expected PodHeadOfficeDetailConstraintException.");

        } catch (PodHeadOfficeDetailConstraintException e) {

            for (ConstraintViolation c : e.getViolations()) {
                Assert.assertEquals("Expected uncored period constraint.",
                        PodHeadOfficeDetailConstraintException.THERE_ARE_PROCESSED_ROL_IN_PERIOD_ERROR_CODE,
                        c.getCode());
            }

        }

    }

    /**
     * @throws ReportOnlineByGrowerException
     * @throws HeadOfficeDetailException
     */
    @Test(expected = HeadOfficeDetailException.class)
    public void test_delete_with_rol_for_grower_in_period_expected_head_office_detail_excption()
            throws ReportOnlineByGrowerException, HeadOfficeDetailException {

        // Create period range
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(matrixContract.getStartDate());
        calendar.add(Calendar.MONTH, 2);
        Date dtStart = calendar.getTime();
        calendar.add(Calendar.MONTH, 5);
        Date dtEnd = calendar.getTime();

        // Create affiliate contract periods for update
        HeadOfficeEffectiveDate headOfficeEffectiveDate = new HeadOfficeEffectiveDate();
        headOfficeEffectiveDate.setId(60606L);
        headOfficeEffectiveDate.setHeadOfficeDetail(headOfficeDetail);
        headOfficeEffectiveDate.setInitDate(dtStart);
        headOfficeEffectiveDate.setEndDate(dtEnd);

        // Associate
        headOfficeDetail.getHeadOfficeEffectiveDates().add(headOfficeEffectiveDate);

        // Build mock's scenery

        // Mock for search report on periods
        List<PaidVolumeByGrower> resultReportOnline = new ArrayList<PaidVolumeByGrower>();
        resultReportOnline.add(new PaidVolumeByGrower());

        Mockito.when(
                reportOnLineByGrowerService.selectPaidVolumeByGrowerListByFilter((PaidVolumeFilter) Mockito.anyObject()))
                .thenReturn(resultReportOnline);

        Mockito.when(participantDAO.selectHeadOfficeEffectiveDateById(Mockito.anyLong())).thenReturn(
                headOfficeEffectiveDate);

        // Try update this
        podHeadOfficeDetailService.deletePodHeadOfficeEffectiveDate(headOfficeEffectiveDate.getId());

        Assert.fail("Expected PodHeadOfficeDetailConstraintException.");

    }

    /**
     * @throws CreditConsumptionException
     * @throws ReportOnlineByGrowerException
     * @throws HeadOfficeDetailException
     */
    @Test(expected = HeadOfficeDetailException.class)
    public void test_delete_with_credit_consumption_period_expected_head_office_detail_excption()
            throws CreditConsumptionException, HeadOfficeDetailException {

        // Create period range
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(matrixContract.getStartDate());
        calendar.add(Calendar.MONTH, 2);
        Date dtStart = calendar.getTime();
        calendar.add(Calendar.MONTH, 5);
        Date dtEnd = calendar.getTime();

        // Create affiliate contract periods for update
        HeadOfficeEffectiveDate headOfficeEffectiveDate = new HeadOfficeEffectiveDate();
        headOfficeEffectiveDate.setId(60606L);
        headOfficeEffectiveDate.setHeadOfficeDetail(headOfficeDetail);
        headOfficeEffectiveDate.setInitDate(dtStart);
        headOfficeEffectiveDate.setEndDate(dtEnd);

        // Associate
        headOfficeDetail.getHeadOfficeEffectiveDates().add(headOfficeEffectiveDate);

        // Build mock's scenery

        // Mock for search report on periods
        List<CreditConsumption> resultReportOnline = new ArrayList<CreditConsumption>();
        resultReportOnline.add(new CreditConsumption());

        Mockito.when(creditService.selectCreditConsumptionListByFilter((CreditConsumptionFilter) Mockito.anyObject()))
                .thenReturn(resultReportOnline);

        Mockito.when(participantDAO.selectHeadOfficeEffectiveDateById(Mockito.anyLong())).thenReturn(
                headOfficeEffectiveDate);

        // Try update this
        podHeadOfficeDetailService.deletePodHeadOfficeEffectiveDate(headOfficeEffectiveDate.getId());

        Assert.fail("Expected PodHeadOfficeDetailConstraintException.");

    }

    /**
     * @throws BusinessException
     * @throws
     * 
     */
    @Test(expected = IllegalArgumentException.class)
    public void test_save_head_office_detail_with_null_list_expected_illegal_argument_exception()
            throws BusinessException {
        podHeadOfficeDetailService.saveHeadOfficeDetail(null);
    }

    /**
     * @throws BusinessException
     * @throws
     * 
     */
    @Test(expected = HeadOfficeDetailException.class)
    public void test_save_head_office_detail_without_pod_head_office_in_list_expected_head_office_detail_exception()
            throws BusinessException {

        List<HeadOfficeDetail> list = new ArrayList<HeadOfficeDetail>();

        // Distributor head office
        HeadOffice headOffice = new HeadOffice(new Customer(), new Customer(), ParticipantTypeEnum.DISTRIBUTOR, null,
                null);
        HeadOfficeDetail headOfficeDetail = new HeadOfficeDetail();
        headOfficeDetail.setHeadoffice(headOffice);
        list.add(headOfficeDetail);

        podHeadOfficeDetailService.saveHeadOfficeDetail(list);
    }

    /**
     * @throws BusinessException
     * @throws
     * 
     */
    @Test(expected = BilledRolFoundForMatrixException.class)
    public void test_save_head_office_detail_try_activated_a_affiliate_in_period_with_billed_rol_for_matrix()
            throws BusinessException {

        List<HeadOfficeDetail> list = new ArrayList<HeadOfficeDetail>();

        // Build pod head office
        HeadOffice headOffice = new HeadOffice(new Customer("", new Document(new DocumentType(), "6060606000"), null, RandomTestData.createRandomLong().toString()),
                new Customer(), ParticipantTypeEnum.POD, null, null);

        // Detail
        HeadOfficeDetail headOfficeDetail = new HeadOfficeDetail(-1L, headOffice, true, false,
                new HashSet<HeadOfficeEffectiveDate>());

        // Configure effective date
        HeadOfficeEffectiveDate headOfficeEffectiveDate = new HeadOfficeEffectiveDate();
        headOfficeEffectiveDate.setInitDate(new Date());
        headOfficeEffectiveDate.setEndDate(new Date());
        headOfficeEffectiveDate.setHeadOfficeDetail(headOfficeDetail);
        headOfficeDetail.getHeadOfficeEffectiveDates().add(headOfficeEffectiveDate);

        // change to report
        headOfficeDetail.setReportRol(Boolean.TRUE);

        // Include to list
        list.add(headOfficeDetail);

        // Mock for search report on periods
        List<Long> resultReportOnline = new ArrayList<Long>();
        resultReportOnline.add(999L);

        // Mock result.
        Mockito.when(
                reportOnLineService.selectCountReportOnlineForMatrixIgnoreAffiliateOnPeriod(
                        (HeadOffice) Mockito.anyObject(), (Date) Mockito.anyObject(), (Date) Mockito.anyObject(),
                        Mockito.anyString())).thenReturn(1000);

        // try update it
        podHeadOfficeDetailService.saveHeadOfficeDetail(list);
    }
}
