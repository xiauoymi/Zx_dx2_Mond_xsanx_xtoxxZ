package com.monsanto.brazilvaluecapture.pod.rol.model.service.parser.importation;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import junit.framework.Assert;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

import com.monsanto.brazilvaluecapture.core.foundation.service.BusinessException;
import com.monsanto.brazilvaluecapture.core.io.ProcessorConfig;
import com.monsanto.brazilvaluecapture.core.io.ProcessorConfig.ProcessorConfigProperties;
import com.monsanto.brazilvaluecapture.core.user.model.bean.ItsUser;
import com.monsanto.brazilvaluecapture.core.user.model.bean.UserContext;
import com.monsanto.brazilvaluecapture.pod.rol.model.bean.CsvPaidVolImportLine;
import com.monsanto.brazilvaluecapture.pod.rol.model.bean.PaidVolByGrowerItem;
import com.monsanto.brazilvaluecapture.pod.rol.model.bean.PaidVolumeByGrower;
import com.monsanto.brazilvaluecapture.pod.rol.model.service.PaidVolImportService;
import com.monsanto.brazilvaluecapture.pod.rol.model.service.ReportOnLineByGrowerService;
import com.monsanto.brazilvaluecapture.pod.rol.model.service.ReportOnLineInfo;

/**
 * @author cmiranda
 * 
 */
public class PaidVolImportProcessor_UT {

    // Processor to test
    private PaidVolImportProcessor processor;

    private ProcessorConfig processorConfig;

    private PaidVolImportService paidVolImportService;

    private PaidVolImportParser paidVolImportParser;

    private ReportOnLineByGrowerService reportOnLineByGrowerService;

    @Before
    public void setup() {

        // Create processor
        processor = new PaidVolImportProcessor();

        // Create processor config
        processorConfig = new ProcessorConfig();

        // Mock service
        paidVolImportService = Mockito.mock(PaidVolImportService.class);
        processor.setPaidVolImportService(paidVolImportService);

        // Mock parser
        paidVolImportParser = Mockito.mock(PaidVolImportParser.class);
        processor.setPaidVolImportParser(paidVolImportParser);

        // Mock grower service
        reportOnLineByGrowerService = Mockito.mock(ReportOnLineByGrowerService.class);
        processor.setReportOnLineByGrowerService(reportOnLineByGrowerService);

    }

    @Test(expected = UnsupportedOperationException.class)
    public void test_read_expected_exception() throws IOException, BusinessException {
        processor.read((InputStream) null);
    }

    @Test(expected = IllegalArgumentException.class)
    public void test_read_with_invalid_processor_locale_null() throws IOException, BusinessException {
        processor.read(processorConfig);
    }

    @Test(expected = IllegalArgumentException.class)
    public void test_read_with_invalid_processor_user_null() throws IOException, BusinessException {

        // Add locale
        processorConfig.put(ProcessorConfigProperties.SELECTED_LOCALE, Locale.US);
        processor.read(processorConfig);
    }

    @Test
    public void test_read() throws IOException, BusinessException {

        // Add locale
        processorConfig.put(ProcessorConfigProperties.SELECTED_LOCALE, Locale.US);

        // Add user
        processorConfig.put(ProcessorConfigProperties.LOGGED_USER, new ItsUser());

        // read!
        Assert.assertNull(processor.read(processorConfig));
    }

    @Test
    public void test_read_imported_lines() {

        // read!
        Assert.assertNull(processor.readImportedLines(processorConfig));
    }

    @Test(expected = UnsupportedOperationException.class)
    public void test_write_expected_exception() {
        processor.write(null);
    }

    @Test
    public void test_set_service() {
        processor.setPaidVolImportService(paidVolImportService);
        Assert.assertEquals(paidVolImportService, processor.getPaidVolImportService());
    }

    @Test
    public void test_process_lines() {

        // Add locale
        processorConfig.put(ProcessorConfigProperties.SELECTED_LOCALE, Locale.US);

        // Add user
        processorConfig.put(ProcessorConfigProperties.LOGGED_USER, new ItsUser());

        // Create file
        PaidVolImportedFile file = new PaidVolImportedFile();

        // Process lines
        PaidVolImportedFile fileOut = processor.processLines(file, processorConfig);
        Assert.assertEquals(file, fileOut);

    }

    @Test(expected = IllegalArgumentException.class)
    public void test_read_with_null_stream_expected_exception() throws IOException, BusinessException {

        // Add locale
        processorConfig.put(ProcessorConfigProperties.SELECTED_LOCALE, Locale.US);

        // Add user
        processorConfig.put(ProcessorConfigProperties.LOGGED_USER, new ItsUser());

        processor.read(null, processorConfig);

    }

    @Test(expected = BusinessException.class)
    public void test_read_with_invalid_stream_expected_business_exception() throws IOException, BusinessException {

        // Add locale
        processorConfig.put(ProcessorConfigProperties.SELECTED_LOCALE, Locale.US);

        // Mock user context
        UserContext user = Mockito.mock(UserContext.class);

        // Add user
        processorConfig.put(ProcessorConfigProperties.LOGGED_USER, user);

        InputStream inputStream = Mockito.mock(InputStream.class);
        processor.read(inputStream, processorConfig);

    }

    @Test
    public void test_write_with_valid_empty_file() throws IOException, BusinessException {

        // Add locale
        processorConfig.put(ProcessorConfigProperties.SELECTED_LOCALE, Locale.US);

        // Mock user context
        UserContext user = Mockito.mock(UserContext.class);

        // Add user
        processorConfig.put(ProcessorConfigProperties.LOGGED_USER, user);

        PaidVolImportedFile validImportedFile = new PaidVolImportedFile();

        Assert.assertEquals(validImportedFile, processor.write(validImportedFile, processorConfig));

    }

    @SuppressWarnings("unchecked")
    @Test
    public void test_write_with_valid_one_line_file() throws IOException, BusinessException {

        // Add locale
        processorConfig.put(ProcessorConfigProperties.SELECTED_LOCALE, Locale.US);

        // Mock user context
        UserContext user = Mockito.mock(UserContext.class);

        // Add user
        processorConfig.put(ProcessorConfigProperties.LOGGED_USER, user);

        PaidVolImportedFile validImportedFile = new PaidVolImportedFile();
        validImportedFile.add(new CsvPaidVolImportLine());

        Mockito.when(paidVolImportParser.getRolInformationForFile(validImportedFile))
                .thenReturn(new ReportOnLineInfo());

        List<PaidVolumeByGrower> paidList = new ArrayList<PaidVolumeByGrower>();
        paidList.add(new PaidVolumeByGrower());

        Mockito.when(
                reportOnLineByGrowerService.generatePaidVolumeByGrowerList(
                        (List<CsvPaidVolImportLine>) Mockito.anyObject(),
                        (Map<PaidVolByGrowerItem, CsvPaidVolImportLine>) Mockito.anyMap())).thenReturn(paidList);

        Assert.assertEquals(validImportedFile, processor.write(validImportedFile, processorConfig));

    }
}
