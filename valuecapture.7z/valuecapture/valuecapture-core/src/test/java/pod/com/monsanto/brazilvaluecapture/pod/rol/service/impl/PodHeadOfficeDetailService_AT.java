package com.monsanto.brazilvaluecapture.pod.rol.service.impl;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.junit.Assert;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.monsanto.brazilvaluecapture.core.customer.model.bean.Contract;
import com.monsanto.brazilvaluecapture.core.customer.service.ContractNotFoundException;
import com.monsanto.brazilvaluecapture.core.customer.service.HeadOfficeDetailException;
import com.monsanto.brazilvaluecapture.core.foundation.test.AbstractServiceIntegrationTests;
import com.monsanto.brazilvaluecapture.core.foundation.test.dbunit.DbUnitHelper;
import com.monsanto.brazilvaluecapture.core.foundation.util.ConstraintViolation;
import com.monsanto.brazilvaluecapture.pod.credit.service.CreditConsumptionException;
import com.monsanto.brazilvaluecapture.pod.rol.model.bean.HeadOfficeDetail;
import com.monsanto.brazilvaluecapture.pod.rol.model.bean.HeadOfficeEffectiveDate;
import com.monsanto.brazilvaluecapture.pod.rol.model.service.PodHeadOfficeDetailConstraintException;
import com.monsanto.brazilvaluecapture.pod.rol.model.service.PodHeadOfficeDetailService;
import com.monsanto.brazilvaluecapture.pod.rol.model.service.impl.OtherReportOnlineConstraintException;

/**
 * @author cmiranda
 * 
 */
public class PodHeadOfficeDetailService_AT extends AbstractServiceIntegrationTests {

    /**
     * 
     */
    @Autowired
    private PodHeadOfficeDetailService podHeadOfficeDetailService;

    /**
     * Load db unit.
     */
    public void setupDBUnit() {

        // Load dbunit
        DbUnitHelper.setup("classpath:data/core/fixture-system-dataset.xml",
                "classpath:data/core/participant-dataset.xml", "classpath:data/core/headoffice-detail-dataset.xml");

    }

    /**
     * Check for illegal argument exception.
     * 
     * @throws ContractNotFoundException
     * @throws PodHeadOfficeDetailConstraintException
     * @throws OtherReportOnlineConstraintException
     * @throws CreditConsumptionException
     */
    @Test(expected = IllegalArgumentException.class)
    public void test_save_pod_participant_control_period_with_null_parameter_expected_illegal_argument_excepion()
            throws PodHeadOfficeDetailConstraintException, ContractNotFoundException, CreditConsumptionException,
            OtherReportOnlineConstraintException {
        podHeadOfficeDetailService.savePodHeadOfficeEffectiveDate(null);
    }

    /**
     * Check for illegal argument exception.
     * 
     * @throws ContractNotFoundException
     * @throws OtherReportOnlineConstraintException
     * @throws CreditConsumptionException
     * @throws PodHeadOfficeDetailConstraintException
     */
    @Test
    public void test_save_pod_participant_control_period_without_periods_expected_constraint_exception()
            throws ContractNotFoundException, CreditConsumptionException, OtherReportOnlineConstraintException {

        // Build fake record
        HeadOfficeEffectiveDate headOfficeEffectiveDate = new HeadOfficeEffectiveDate();

        try {

            // Try save it
            podHeadOfficeDetailService.savePodHeadOfficeEffectiveDate(headOfficeEffectiveDate);

            Assert.fail("Expected PodHeadOfficeDetailConstraintException.");

        } catch (PodHeadOfficeDetailConstraintException e) {

            for (ConstraintViolation c : e.getViolations()) {
                Assert.assertEquals(PodHeadOfficeDetailConstraintException.REQUIRED_PARAM_ERROR_CODE, c.getCode());
            }

        }
    }

    /**
     * Check for illegal argument exception.
     * 
     * @throws ContractNotFoundException
     * @throws OtherReportOnlineConstraintException
     * @throws CreditConsumptionException
     * @throws PodHeadOfficeDetailConstraintException
     */
    @Test
    public void test_save_pod_participant_control_period_with_end_period_null_expected_constraint_exception()
            throws ContractNotFoundException, CreditConsumptionException, OtherReportOnlineConstraintException {

        // Build fake record
        HeadOfficeEffectiveDate headOfficeEffectiveDate = new HeadOfficeEffectiveDate();
        headOfficeEffectiveDate.setInitDate(new Date());

        try {

            // Try save it
            podHeadOfficeDetailService.savePodHeadOfficeEffectiveDate(headOfficeEffectiveDate);

            Assert.fail("Expected PodHeadOfficeDetailConstraintException.");

        } catch (PodHeadOfficeDetailConstraintException e) {

            for (ConstraintViolation c : e.getViolations()) {
                Assert.assertEquals(PodHeadOfficeDetailConstraintException.REQUIRED_PARAM_ERROR_CODE, c.getCode());
            }

        }
    }

    /**
     * @throws ContractNotFoundException
     * @throws OtherReportOnlineConstraintException
     * @throws CreditConsumptionException
     */
    @Test
    public void test_save_pod_participant_control_period_with_end_date_less_than_init_date()
            throws ContractNotFoundException, CreditConsumptionException, OtherReportOnlineConstraintException {

        // Build new and fake effective date
        Calendar calendar = Calendar.getInstance();
        HeadOfficeEffectiveDate headOfficeEffectiveDate = new HeadOfficeEffectiveDate();
        headOfficeEffectiveDate.setEndDate(calendar.getTime());

        // init date is 2 days later than end date.
        calendar.add(Calendar.DAY_OF_MONTH, 2);
        headOfficeEffectiveDate.setInitDate(calendar.getTime());

        try {

            // Try save it
            podHeadOfficeDetailService.savePodHeadOfficeEffectiveDate(headOfficeEffectiveDate);

            Assert.fail("Expected PodHeadOfficeDetailConstraintException.");

        } catch (PodHeadOfficeDetailConstraintException e) {

            for (ConstraintViolation c : e.getViolations()) {
                Assert.assertEquals(PodHeadOfficeDetailConstraintException.INVALID_DATE_RANGE_ERROR_CODE, c.getCode());
            }

        }
    }

    /**
     * Check constraint violation for contract not found (matrix don't have
     * contract).
     * 
     * @throws ContractNotFoundException
     * @throws PodHeadOfficeDetailConstraintException
     * @throws OtherReportOnlineConstraintException
     * @throws CreditConsumptionException
     */
    @Test(expected = ContractNotFoundException.class)
    public void test_save_pod_participant_control_period_without_contract_matrix_expected_contract_not_found_exception()
            throws PodHeadOfficeDetailConstraintException, ContractNotFoundException, CreditConsumptionException,
            OtherReportOnlineConstraintException {

        // Load db unit
        setupDBUnit();

        // Find head office detail
        HeadOfficeDetail headOfficeDetail = (HeadOfficeDetail) getSession().get(HeadOfficeDetail.class, 900000001L);
        Assert.assertNotNull(headOfficeDetail);

        // Build new effective date for some affiliate
        Calendar calendar = Calendar.getInstance();
        HeadOfficeEffectiveDate headOfficeEffectiveDate = new HeadOfficeEffectiveDate();
        headOfficeEffectiveDate.setHeadOfficeDetail(headOfficeDetail);

        // start now
        headOfficeEffectiveDate.setInitDate(calendar.getTime());

        // and finish 3 years later
        calendar.add(Calendar.YEAR, 3);
        headOfficeEffectiveDate.setEndDate(calendar.getTime());

        // Try save it
        podHeadOfficeDetailService.savePodHeadOfficeEffectiveDate(headOfficeEffectiveDate);

    }

    /**
     * @throws ContractNotFoundException
     * @throws PodHeadOfficeDetailConstraintException
     * @throws OtherReportOnlineConstraintException
     * @throws CreditConsumptionException
     */
    @Test
    public void test_save_pod_participant_control_period_with_valid_parameters_expected_success()
            throws ContractNotFoundException, PodHeadOfficeDetailConstraintException, CreditConsumptionException,
            OtherReportOnlineConstraintException {

        // Load db unit
        setupDBUnit();

        // Find head office detail
        HeadOfficeDetail headOfficeDetail = (HeadOfficeDetail) getSession().get(HeadOfficeDetail.class, 900000002L);
        Assert.assertNotNull(headOfficeDetail);

        // Build new effective date for some affiliate
        Calendar calendar = Calendar.getInstance();
        HeadOfficeEffectiveDate headOfficeEffectiveDate = new HeadOfficeEffectiveDate();
        headOfficeEffectiveDate.setHeadOfficeDetail(headOfficeDetail);

        // start now
        headOfficeEffectiveDate.setInitDate(calendar.getTime());

        // and finish 3 years later
        calendar.add(Calendar.YEAR, 3);
        headOfficeEffectiveDate.setEndDate(calendar.getTime());

        // Try save it
        headOfficeEffectiveDate = podHeadOfficeDetailService.savePodHeadOfficeEffectiveDate(headOfficeEffectiveDate);
        Assert.assertNotNull("Record must be persisted.", headOfficeDetail.getId());

    }

    /**
     * @throws ContractNotFoundException
     * @throws OtherReportOnlineConstraintException
     * @throws CreditConsumptionException
     * @throws PodHeadOfficeDetailConstraintException
     */
    @Test
    public void test_save_pod_participant_control_period_with_periods_start_and_ends_before_contract_matrix_period_expected_exception()
            throws ContractNotFoundException, CreditConsumptionException, OtherReportOnlineConstraintException {

        // Load db unit
        setupDBUnit();

        // Find head office detail
        HeadOfficeDetail headOfficeDetail = (HeadOfficeDetail) getSession().get(HeadOfficeDetail.class, 900000002L);
        Assert.assertNotNull(headOfficeDetail);

        // Find matrix contact
        Contract contract = (Contract) getSession().get(Contract.class, 900000003L);
        Assert.assertNotNull(contract);

        // Build new effective date for some affiliate
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(contract.getStartDate());
        calendar.set(Calendar.YEAR, -10);

        HeadOfficeEffectiveDate headOfficeEffectiveDate = new HeadOfficeEffectiveDate();
        headOfficeEffectiveDate.setHeadOfficeDetail(headOfficeDetail);

        // start 20 year early than start contract date
        headOfficeEffectiveDate.setInitDate(calendar.getTime());

        // and finish 1 month ahead
        calendar.add(Calendar.MONTH, 1);
        headOfficeEffectiveDate.setEndDate(calendar.getTime());

        // Try save it
        try {

            podHeadOfficeDetailService.savePodHeadOfficeEffectiveDate(headOfficeEffectiveDate);

        } catch (PodHeadOfficeDetailConstraintException e) {

            for (ConstraintViolation c : e.getViolations()) {
                Assert.assertTrue(
                        "Expected out of matrix periods exception. But found: " + c.getCode(),
                        c.getCode().equals(
                                PodHeadOfficeDetailConstraintException.INIT_PERIOD_OUT_OF_MATRIX_CONTRACT_ERROR_CODE)
                                || c.getCode()
                                        .equals(PodHeadOfficeDetailConstraintException.END_PERIOD_OUT_OF_MATRIX_CONTRACT_ERROR_CODE));
            }

        }

    }

    /**
     * @throws ContractNotFoundException
     * @throws OtherReportOnlineConstraintException
     * @throws CreditConsumptionException
     * @throws PodHeadOfficeDetailConstraintException
     */
    @Test
    public void test_save_pod_participant_control_period_with_periods_start_and_ends_after_contract_matrix_period_expected_exception()
            throws ContractNotFoundException, CreditConsumptionException, OtherReportOnlineConstraintException {

        // Load db unit
        setupDBUnit();

        // Find head office detail
        HeadOfficeDetail headOfficeDetail = (HeadOfficeDetail) getSession().get(HeadOfficeDetail.class, 900000002L);
        Assert.assertNotNull(headOfficeDetail);

        // Find matrix contact
        Contract contract = (Contract) getSession().get(Contract.class, 900000003L);
        Assert.assertNotNull(contract);

        // Build new effective date for some affiliate
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(contract.getEndDate());
        calendar.set(Calendar.YEAR, 2);

        HeadOfficeEffectiveDate headOfficeEffectiveDate = new HeadOfficeEffectiveDate();
        headOfficeEffectiveDate.setHeadOfficeDetail(headOfficeDetail);

        // start 2 year later than end contract date
        headOfficeEffectiveDate.setInitDate(calendar.getTime());

        // and finish 10 month ahead
        calendar.add(Calendar.MONTH, 10);
        headOfficeEffectiveDate.setEndDate(calendar.getTime());

        // Try save it
        try {

            podHeadOfficeDetailService.savePodHeadOfficeEffectiveDate(headOfficeEffectiveDate);

        } catch (PodHeadOfficeDetailConstraintException e) {

            for (ConstraintViolation c : e.getViolations()) {
                Assert.assertTrue(
                        "Expected out of matrix periods exception. But found: " + c.getCode(),
                        c.getCode().equals(
                                PodHeadOfficeDetailConstraintException.INIT_PERIOD_OUT_OF_MATRIX_CONTRACT_ERROR_CODE)
                                || c.getCode()
                                        .equals(PodHeadOfficeDetailConstraintException.END_PERIOD_OUT_OF_MATRIX_CONTRACT_ERROR_CODE));
            }

        }

    }

    /**
     * @throws ContractNotFoundException
     * @throws OtherReportOnlineConstraintException
     * @throws CreditConsumptionException
     * @throws PodHeadOfficeDetailConstraintException
     */
    @Test
    public void test_save_pod_participant_control_period_with_periods_start_after_contract_and_finished_out_matrix_contract_period_expected_exception()
            throws ContractNotFoundException, CreditConsumptionException, OtherReportOnlineConstraintException {

        // Load db unit
        setupDBUnit();

        // Find head office detail
        HeadOfficeDetail headOfficeDetail = (HeadOfficeDetail) getSession().get(HeadOfficeDetail.class, 900000002L);
        Assert.assertNotNull(headOfficeDetail);

        // Find matrix contact
        Contract contract = (Contract) getSession().get(Contract.class, 900000003L);
        Assert.assertNotNull(contract);

        // Build new effective date for some affiliate
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(contract.getStartDate());
        calendar.add(Calendar.YEAR, 3);

        HeadOfficeEffectiveDate headOfficeEffectiveDate = new HeadOfficeEffectiveDate();
        headOfficeEffectiveDate.setHeadOfficeDetail(headOfficeDetail);

        // start 3 years later than start contract date
        headOfficeEffectiveDate.setInitDate(calendar.getTime());

        // and finish 10 month ahead than ends contracts
        calendar.setTime(contract.getEndDate());
        calendar.add(Calendar.MONTH, 10);
        headOfficeEffectiveDate.setEndDate(calendar.getTime());

        try {

            // Try save it
            podHeadOfficeDetailService.savePodHeadOfficeEffectiveDate(headOfficeEffectiveDate);

        } catch (PodHeadOfficeDetailConstraintException e) {

            for (ConstraintViolation c : e.getViolations()) {
                Assert.assertTrue(
                        "Expected out of matrix periods exception. But found: " + c.getCode(),
                        c.getCode().equals(
                                PodHeadOfficeDetailConstraintException.INIT_PERIOD_OUT_OF_MATRIX_CONTRACT_ERROR_CODE)
                                || c.getCode()
                                        .equals(PodHeadOfficeDetailConstraintException.END_PERIOD_OUT_OF_MATRIX_CONTRACT_ERROR_CODE));
            }

        }

    }

    /**
     * @throws ContractNotFoundException
     * @throws OtherReportOnlineConstraintException
     * @throws CreditConsumptionException
     * @throws PodHeadOfficeDetailConstraintException
     */
    @Test
    public void test_save_pod_participant_control_period_with_periods_start_and_end_after_contract_finished_out_matrix_contract_period_expected_exception()
            throws ContractNotFoundException, CreditConsumptionException, OtherReportOnlineConstraintException {

        // Load db unit
        setupDBUnit();

        // Find head office detail
        HeadOfficeDetail headOfficeDetail = (HeadOfficeDetail) getSession().get(HeadOfficeDetail.class, 900000002L);
        Assert.assertNotNull(headOfficeDetail);

        // Find matrix contact
        Contract contract = (Contract) getSession().get(Contract.class, 900000003L);
        Assert.assertNotNull(contract);

        // Build new effective date for some affiliate
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(contract.getEndDate());
        calendar.add(Calendar.YEAR, 3);

        HeadOfficeEffectiveDate headOfficeEffectiveDate = new HeadOfficeEffectiveDate();
        headOfficeEffectiveDate.setHeadOfficeDetail(headOfficeDetail);

        // start 3 years later than start contract date
        headOfficeEffectiveDate.setInitDate(calendar.getTime());

        // and finish 10 month ahead than ends contracts
        calendar.add(Calendar.MONTH, 10);
        headOfficeEffectiveDate.setEndDate(calendar.getTime());

        try {

            // Try save it
            podHeadOfficeDetailService.savePodHeadOfficeEffectiveDate(headOfficeEffectiveDate);

        } catch (PodHeadOfficeDetailConstraintException e) {

            for (ConstraintViolation c : e.getViolations()) {
                Assert.assertEquals("Expected out of matrix periods exception. But found: " + c.getCode(),
                        PodHeadOfficeDetailConstraintException.END_PERIOD_OUT_OF_MATRIX_CONTRACT_ERROR_CODE,
                        c.getCode());
            }

        }

    }

    /**
     * @throws ContractNotFoundException
     * @throws OtherReportOnlineConstraintException
     * @throws CreditConsumptionException
     * @throws PodHeadOfficeDetailConstraintException
     */
    @Test
    public void test_save_pod_participant_control_period_with_period_overlap_expected_exception()
            throws ContractNotFoundException, CreditConsumptionException, OtherReportOnlineConstraintException {

        // Load db unit
        setupDBUnit();

        // Find head office detail
        HeadOfficeDetail headOfficeDetail = (HeadOfficeDetail) getSession().get(HeadOfficeDetail.class, 900000002L);
        Assert.assertNotNull(headOfficeDetail);

        List<HeadOfficeEffectiveDate> effectivesDates = new ArrayList<HeadOfficeEffectiveDate>(
                headOfficeDetail.getHeadOfficeEffectiveDates());

        HeadOfficeEffectiveDate effective = effectivesDates.get(0);

        // Build new effective date for some affiliate
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(effective.getInitDate());
        calendar.add(Calendar.MONTH, 1);

        HeadOfficeEffectiveDate headOfficeEffectiveDate = new HeadOfficeEffectiveDate();
        headOfficeEffectiveDate.setHeadOfficeDetail(headOfficeDetail);

        // start 3 years later than start contract date
        headOfficeEffectiveDate.setInitDate(calendar.getTime());

        // and finish 10 month ahead than ends contracts
        calendar.add(Calendar.MONTH, 1);
        headOfficeEffectiveDate.setEndDate(calendar.getTime());

        try {

            // Try save it
            podHeadOfficeDetailService.savePodHeadOfficeEffectiveDate(headOfficeEffectiveDate);

        } catch (PodHeadOfficeDetailConstraintException e) {

            for (ConstraintViolation c : e.getViolations()) {
                Assert.assertEquals("Expected out of matrix periods exception.",
                        PodHeadOfficeDetailConstraintException.OVERLAP_PERIODS_ERROR_CODE, c.getCode());
            }

        }

    }

    /**
     * @throws ContractNotFoundException
     * @throws PodHeadOfficeDetailConstraintException
     * @throws OtherReportOnlineConstraintException
     * @throws CreditConsumptionException
     */
    @Test
    public void test_edit_pod_participant_control_period_with_valid_period() throws ContractNotFoundException,
            PodHeadOfficeDetailConstraintException, CreditConsumptionException, OtherReportOnlineConstraintException {

        // Load db unit
        setupDBUnit();

        // Find head office detail
        HeadOfficeDetail headOfficeDetail = (HeadOfficeDetail) getSession().get(HeadOfficeDetail.class, 900000002L);
        Assert.assertNotNull(headOfficeDetail);

        // Get already persisted effective date for affiliate
        List<HeadOfficeEffectiveDate> effectivesDates = new ArrayList<HeadOfficeEffectiveDate>(
                headOfficeDetail.getHeadOfficeEffectiveDates());
        Assert.assertFalse("Expected a lista non-list.", effectivesDates.isEmpty());

        HeadOfficeEffectiveDate effective = effectivesDates.get(0);

        // Build new effective date for some affiliate
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(effective.getInitDate());
        calendar.add(Calendar.MONTH, 1);
        effective.setInitDate(calendar.getTime());

        calendar.setTime(effective.getEndDate());
        calendar.add(Calendar.MONTH, -1);
        effective.setEndDate(calendar.getTime());

        Date dtStart = new Date(effective.getInitDate().getTime());
        Date dtEnd = new Date(effective.getEndDate().getTime());

        // Try save it
        podHeadOfficeDetailService.savePodHeadOfficeEffectiveDate(effective);

        // Check if periods have been updated
        HeadOfficeEffectiveDate dbRecord = (HeadOfficeEffectiveDate) getSession().get(HeadOfficeEffectiveDate.class,
                effective.getId());
        Assert.assertEquals(dtStart, dbRecord.getInitDate());
        Assert.assertEquals(dtEnd, dbRecord.getEndDate());

    }

    /**
     * @throws HeadOfficeDetailException
     */
    @Test
    public void test_delete_pod_headoffice_effective_date_without_constraint_expected_success()
            throws HeadOfficeDetailException {

        // Load db unit
        setupDBUnit();

        // Find head office detail
        HeadOfficeDetail headOfficeDetail = (HeadOfficeDetail) getSession().get(HeadOfficeDetail.class, 900000002L);
        Assert.assertNotNull(headOfficeDetail);

        // Get already persisted effective date for affiliate
        List<HeadOfficeEffectiveDate> effectivesDates = new ArrayList<HeadOfficeEffectiveDate>(
                headOfficeDetail.getHeadOfficeEffectiveDates());
        Assert.assertFalse("Expected a lista non-empty list.", effectivesDates.isEmpty());
        int sizeListBefore = effectivesDates.size();

        HeadOfficeEffectiveDate effective = effectivesDates.get(0);

        // Try delete it
        headOfficeDetail = podHeadOfficeDetailService.deletePodHeadOfficeEffectiveDate(effective.getId());

        // Verify if it was really deleted.
        Assert.assertTrue("Record not deleted.", headOfficeDetail.getHeadOfficeEffectiveDates().size() < sizeListBefore);

        // Find head office detail again
        headOfficeDetail = (HeadOfficeDetail) getSession().get(HeadOfficeDetail.class, 900000002L);
        Assert.assertNotNull(headOfficeDetail);
        Assert.assertTrue("Expected a empty list.", headOfficeDetail.getHeadOfficeEffectiveDates().isEmpty());

    }

}
