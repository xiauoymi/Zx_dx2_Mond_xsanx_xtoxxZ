package com.monsanto.brazilvaluecapture.pod.rol.service.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import junit.framework.Assert;

import org.junit.Before;
import org.junit.Test;

import com.monsanto.brazilvaluecapture.core.base.model.bean.Company;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Country;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Crop;
import com.monsanto.brazilvaluecapture.core.commercialhierarchy.model.bean.ItsDistrict;
import com.monsanto.brazilvaluecapture.core.commercialhierarchy.model.bean.ItsRegion;
import com.monsanto.brazilvaluecapture.core.commercialhierarchy.model.bean.ItsUnity;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Technology;
import com.monsanto.brazilvaluecapture.core.grower.CreateTestData;
import com.monsanto.brazilvaluecapture.pod.rol.model.bean.CounterPrice;
import com.monsanto.brazilvaluecapture.pod.rol.model.bean.VolumeOfBag;
import com.monsanto.brazilvaluecapture.pod.rol.model.service.CounterPriceDTO;

public class CounterPriceDTO_UT extends CreateTestData {

    @Before
    public void setup() {

    }

    @Test
    public void createObjectConstructorTest() {

        // Create system data
        Country country = new Country("USA", "usa");
        Company company = new Company("monsanto");
        Crop crop = new Crop("soya", company, country);
        Technology technologyIntacta = new Technology("intact", company);

        ItsUnity itsUnity = new ItsUnity();
        itsUnity.setActivitySector("POD");
        itsUnity.setId(0L);
        itsUnity.setUnitySapDesc("A1");
        itsUnity.setUnitySapId("x1");

        ItsRegion itsRegion = new ItsRegion();
        itsRegion.setActivitySector("POD");
        itsRegion.setItsUnity(itsUnity);
        itsRegion.setRegionSapDesc("r1");
        itsRegion.setRegionSapId("x1");

        ItsDistrict itsDistrict = new ItsDistrict();
        itsDistrict.setActivitySector("POD");
        itsDistrict.setDistrictSapDesc("71");
        itsDistrict.setDistrictSapId("x123");
        itsDistrict.setId(0L);
        itsDistrict.setItsRegion(itsRegion);
        itsDistrict.setItsUnity(itsUnity);

        List<CounterPrice> counterPriceList = new ArrayList<CounterPrice>();
        CounterPrice counterPrice = new CounterPrice();
        counterPrice.setCrop(crop);
        counterPrice.setActivitySector("x");
        counterPrice.setDistrictSapDesc("x");
        counterPrice.setDistrictSapId("x");
        counterPrice.setRegionSapId("x");
        counterPrice.setUnitySapId("x");
        counterPrice.setPeriod(new Date());
        counterPrice.setPrice(new BigDecimal("1.99"));
        counterPriceList.add(counterPrice);

        VolumeOfBag volumeOfBag = new VolumeOfBag();
        volumeOfBag.setCrop(crop);
        volumeOfBag.setId(2L);
        volumeOfBag.setPeriod(new Date());
        volumeOfBag.setTechnology(technologyIntacta);
        volumeOfBag.setVolume(BigDecimal.TEN);

        CounterPriceDTO dto = new CounterPriceDTO(volumeOfBag);
        dto.setCounterPriceList(counterPriceList);

        testAssert(dto);

    }

    /**
     * Validating of grower
     * 
     * @param grower
     */
    private void testAssert(CounterPriceDTO dto) {

        Assert.assertNotNull(dto);
        Assert.assertNotNull(dto.getCounterPriceList());
        Assert.assertNotNull(dto.getVolumeOfBag());

    }

    @Test
    public void testConstructors() throws Exception {

        ItsDistrict district = new ItsDistrict();
        district.setItsRegion(new ItsRegion());
        district.setItsUnity(new ItsUnity());

        new CounterPrice();
        new CounterPrice(1L, district, new Technology(), new Crop(), null);
        new CounterPrice(1L, district, new Technology(), new Crop(), null, BigDecimal.ZERO);
    }

}
