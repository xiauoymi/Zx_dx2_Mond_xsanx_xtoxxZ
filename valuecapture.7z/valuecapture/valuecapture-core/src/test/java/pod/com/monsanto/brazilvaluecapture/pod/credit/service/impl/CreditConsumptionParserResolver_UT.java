package com.monsanto.brazilvaluecapture.pod.credit.service.impl;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

import com.monsanto.brazilvaluecapture.core.user.model.bean.UserContract;
import com.monsanto.brazilvaluecapture.pod.credit.service.CreditService;

public class CreditConsumptionParserResolver_UT {

    private CreditConsumptionParserResolver creditConsumptionParserResolver;
    private CreditConsumptionParserBuilder builderMock;

    @Before
    public void setUp() throws Exception {
        CreditService creditService = null;
        String companyDescription = null;
        String matrixSelected = null;
        String cropDescription = null;
        List<UserContract> listUserContract = null;
        String userLogin = null;
        creditConsumptionParserResolver = new CreditConsumptionParserResolver(creditService, companyDescription, matrixSelected, cropDescription, listUserContract, userLogin);
        builderMock = Mockito.mock(CreditConsumptionParserBuilder.class);
        creditConsumptionParserResolver.setBuilder(builderMock);
    }

    @Test
    public void test_return_creditConsumptionParseResult_proceed_not_null() {
        List<CsvCreditConsumptionItem> csvCreditConsumptionItems = new ArrayList<CsvCreditConsumptionItem>();
        CsvCreditConsumptionItem csvCreditConsumtionItem = Mockito.mock(CsvCreditConsumptionItem.class);
        csvCreditConsumptionItems.add(csvCreditConsumtionItem );
        CreditConsumptionParserResult crediConsumptionParseResult = Mockito.mock(CreditConsumptionParserResult.class);
        Mockito.when(builderMock.buildProceed()).thenReturn(crediConsumptionParseResult );
        assertNotNull(creditConsumptionParserResolver.resolveCreditConsumptionItemProceed(csvCreditConsumptionItems ));
    }
    
    @Test
    public void test_return_creditConsumptionParseResult_import_not_null() {
        List<CsvCreditConsumptionItem> csvCreditConsumptionItems = new ArrayList<CsvCreditConsumptionItem>();
        CsvCreditConsumptionItem csvCreditConsumtionItem = Mockito.mock(CsvCreditConsumptionItem.class);
        csvCreditConsumptionItems.add(csvCreditConsumtionItem );
        CreditConsumptionParserResult crediConsumptionParseResult = Mockito.mock(CreditConsumptionParserResult.class);
        Mockito.when(builderMock.buildImport()).thenReturn(crediConsumptionParseResult );
        assertNotNull(creditConsumptionParserResolver.resolveCreditConsumptionItemImport(csvCreditConsumptionItems ));
    }

    @Test
    public void test_countLines_is_not_zero() {
        Mockito.when(builderMock.countLinesToProccess()).thenReturn(1);
        assertTrue(creditConsumptionParserResolver.countLines()>0);
    }
    @Test
    public void test_count_line_is_zero(){
        assertTrue(creditConsumptionParserResolver.countLines() == 0);
    }

    @Test
    public void testCountCandidateCreditConsumption() {
        Mockito.when(builderMock.countCandidateCreditConsumption()).thenReturn(1);
        assertTrue(creditConsumptionParserResolver.countCandidateCreditConsumption()>0);
    }

}
