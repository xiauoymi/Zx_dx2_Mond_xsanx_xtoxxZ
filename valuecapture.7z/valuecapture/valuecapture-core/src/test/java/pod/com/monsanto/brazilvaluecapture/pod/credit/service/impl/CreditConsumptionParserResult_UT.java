package com.monsanto.brazilvaluecapture.pod.credit.service.impl;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

import com.monsanto.brazilvaluecapture.core.foundation.util.parser.ParsedLineResult;
import com.monsanto.brazilvaluecapture.pod.credit.model.bean.CreditConsumptionItemDTO;

public class CreditConsumptionParserResult_UT {

    private CreditConsumptionParserResult creditConsumptionParserResult;
    private CreditConsumptionItemDTO creditConsumptionItemDTOMock;

    @Before
    public void setUp() throws Exception {
        creditConsumptionParserResult = new CreditConsumptionParserResult();
        creditConsumptionItemDTOMock = Mockito.mock(CreditConsumptionItemDTO.class);
    }

    @Test
    public void test_Add_Warning_CSVReadable() {
        CsvCreditConsumptionItem csvReadableMock = Mockito.mock(CsvCreditConsumptionItem.class);
        Mockito.when(csvReadableMock.hasWarning()).thenReturn(true);
        creditConsumptionParserResult.addWarning(csvReadableMock);
    }
    @Test
    public void test_not_add_warning_csvreadable() {
        CsvCreditConsumptionItem csvReadableMock = Mockito.mock(CsvCreditConsumptionItem.class);
        Mockito.when(csvReadableMock.hasWarning()).thenReturn(false);
        creditConsumptionParserResult.addWarning(csvReadableMock);
    }
    

    @Test
    public void testAddWarningParsedLineResult() {
        ParsedLineResult parseResult = Mockito.mock(ParsedLineResult.class);
        creditConsumptionParserResult.addWarning(parseResult );
        assertFalse(creditConsumptionParserResult.getWarnings().isEmpty());
    }

 
    @Test
    public void test_Clear_Warnigs() {
        creditConsumptionParserResult.clearWarnigs();
        assertTrue(creditConsumptionParserResult.getWarnings().isEmpty());
    }

     @Test
    public void test_Count_Succeeded_CreditConsumption() {
        creditConsumptionParserResult.addCorrectCreditConsumptionItem(creditConsumptionItemDTOMock);
        assertTrue(creditConsumptionParserResult.countSucceededCreditConsumption()>0);
        assertFalse(creditConsumptionParserResult.getCorrectCreditConsumptionItemDTO().isEmpty());
    }
    @Test
    public void test_count_succeded_credit_consumption_is_zero(){
        creditConsumptionParserResult.addCorrectCreditConsumptionItem(creditConsumptionItemDTOMock);
        assertFalse(creditConsumptionParserResult.countSucceededCreditConsumption()==0);
    }

    @Test
    public void testHasnotCorrectCreditConsumption() {
        assertFalse(creditConsumptionParserResult.hasCorrectCreditConsumption());
    }

    @Test
    public void test_not_has_error() {
        ParsedLineResult parsedLineResultMock = Mockito.mock(ParsedLineResult.class);
        Mockito.when(parsedLineResultMock.getCodeWarn()).thenReturn("erro");
       assertFalse(creditConsumptionParserResult.hasError("noError"));
    }
    @Test
    public void test_has_error(){
        ParsedLineResult parsedLineResultMock = Mockito.mock(ParsedLineResult.class);
        Mockito.when(parsedLineResultMock.getCodeWarn()).thenReturn("erro");
        creditConsumptionParserResult.getWarnings().add(parsedLineResultMock);
        assertTrue(creditConsumptionParserResult.hasError("erro"));
    }

}
