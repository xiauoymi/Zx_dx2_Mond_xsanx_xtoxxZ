package com.monsanto.brazilvaluecapture.pod.waybill.service.impl;

import org.junit.Test;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

public class ResponseFormatter_UT {

    @Test
    public void getBulkIdsForARShouldSucceed() {
        com.monsanto.brazilvaluecapture.osb.its.waybillexportar.bean.Bulk bulk1 = mock(
                com.monsanto.brazilvaluecapture.osb.its.waybillexportar.bean.Bulk.class);
        when(bulk1.getId()).thenReturn(8L);
        com.monsanto.brazilvaluecapture.osb.its.waybillexportar.bean.Bulk bulk2 = mock(
                com.monsanto.brazilvaluecapture.osb.its.waybillexportar.bean.Bulk.class);
        when(bulk2.getId()).thenReturn(10L);
        List<com.monsanto.brazilvaluecapture.osb.its.waybillexportar.bean.Bulk> bulkList =
                new ArrayList<com.monsanto.brazilvaluecapture.osb.its.waybillexportar.bean.Bulk>();
        bulkList.add(bulk1);
        bulkList.add(bulk2);
        com.monsanto.brazilvaluecapture.osb.its.waybillexportar.bean.Response response = mock(
                com.monsanto.brazilvaluecapture.osb.its.waybillexportar.bean.Response.class);
        when(response.getBulk()).thenReturn(bulkList);

        String result = ResponseFormatter.getBulkIds(response);

        assertEquals("[8,10]", result);
    }

    @Test
    public void getBulkIdsForARWithoutBulksShouldSucceed() {
        com.monsanto.brazilvaluecapture.osb.its.waybillexportar.bean.Response response = mock(
                com.monsanto.brazilvaluecapture.osb.its.waybillexportar.bean.Response.class);
        when(response.getBulk()).thenReturn(Collections.<com.monsanto.brazilvaluecapture.osb.its.waybillexportar.bean.Bulk>emptyList());

        String result = ResponseFormatter.getBulkIds(response);

        assertEquals("[]", result);
    }

    @Test
    public void getBulkIdsForPYShouldSucceed() {
        com.monsanto.brazilvaluecapture.osb.its.waybillexportpy.bean.Bulk bulk1 = mock(
                com.monsanto.brazilvaluecapture.osb.its.waybillexportpy.bean.Bulk.class);
        when(bulk1.getId()).thenReturn(8L);
        com.monsanto.brazilvaluecapture.osb.its.waybillexportpy.bean.Bulk bulk2 = mock(
                com.monsanto.brazilvaluecapture.osb.its.waybillexportpy.bean.Bulk.class);
        when(bulk2.getId()).thenReturn(10L);
        List<com.monsanto.brazilvaluecapture.osb.its.waybillexportpy.bean.Bulk> bulkList =
                new ArrayList<com.monsanto.brazilvaluecapture.osb.its.waybillexportpy.bean.Bulk>();
        bulkList.add(bulk1);
        bulkList.add(bulk2);
        com.monsanto.brazilvaluecapture.osb.its.waybillexportpy.bean.Response response = mock(
                com.monsanto.brazilvaluecapture.osb.its.waybillexportpy.bean.Response.class);
        when(response.getBulk()).thenReturn(bulkList);

        String result = ResponseFormatter.getBulkIds(response);

        assertEquals("[8,10]", result);
    }

    @Test
    public void getBulkIdsForPYWithoutBulksShouldSucceed() {
        com.monsanto.brazilvaluecapture.osb.its.waybillexportpy.bean.Response response = mock(
                com.monsanto.brazilvaluecapture.osb.its.waybillexportpy.bean.Response.class);
        when(response.getBulk()).thenReturn(Collections.<com.monsanto.brazilvaluecapture.osb.its.waybillexportpy.bean.Bulk>emptyList());

        String result = ResponseFormatter.getBulkIds(response);

        assertEquals("[]", result);
    }

}