package com.monsanto.brazilvaluecapture.pod.rol.model.bean;

import java.math.BigDecimal;

import junit.framework.Assert;

import org.junit.Test;

/**
 * @author cmiranda
 * 
 */
public class RolLogDTO_UT {

    @Test
    public void test_get_rol_log_old_value_as_number_null() {

        ReportOnLine rol = new ReportOnLine();

        RolLog log = new RolLog();
        log.setId(1L);

        RolLogDTO dto = new RolLogDTO(rol, log);
        Assert.assertNull(dto.getRolLogOldValueAsNumber());

    }

    @Test
    public void test_get_rol_log_old_value_as_number() {

        ReportOnLine rol = new ReportOnLine();

        RolLog log = new RolLog();
        log.setId(1L);
        log.setRolLogOldValue("12");

        RolLogDTO dto = new RolLogDTO(rol, log);
        Assert.assertNotNull(dto.getRolLogOldValueAsNumber());
        Assert.assertEquals(new BigDecimal("12"), dto.getRolLogOldValueAsNumber());

    }

    @Test
    public void test_get_rol_log_old_value_as_number_invalid_number() {

        ReportOnLine rol = new ReportOnLine();

        RolLog log = new RolLog();
        log.setId(1L);
        log.setRolLogOldValue("juquinha");

        RolLogDTO dto = new RolLogDTO(rol, log);
        Assert.assertNull(dto.getRolLogOldValueAsNumber());

    }

    @Test
    public void test_get_rol_log_new_value_as_number_null() {

        ReportOnLine rol = new ReportOnLine();

        RolLog log = new RolLog();
        log.setId(1L);

        RolLogDTO dto = new RolLogDTO(rol, log);
        Assert.assertNull(dto.getRolLogNewValueAsNumber());

    }

    @Test
    public void test_get_rol_log_new_value_as_number() {

        ReportOnLine rol = new ReportOnLine();

        RolLog log = new RolLog();
        log.setId(1L);
        log.setRolLogNewValue("12");

        RolLogDTO dto = new RolLogDTO(rol, log);
        Assert.assertNotNull(dto.getRolLogNewValueAsNumber());
        Assert.assertEquals(new BigDecimal("12"), dto.getRolLogNewValueAsNumber());

    }

    @Test
    public void test_get_rol_log_new_value_as_number_invalid_number() {

        ReportOnLine rol = new ReportOnLine();

        RolLog log = new RolLog();
        log.setId(1L);
        log.setRolLogNewValue("rrrrrrrrrrrrrrr");

        RolLogDTO dto = new RolLogDTO(rol, log);
        Assert.assertNull(dto.getRolLogNewValueAsNumber());

    }

    @Test
    public void sanity_test() {

        ReportOnLine rol = new ReportOnLine();

        RolLog log = new RolLog();
        log.setId(1L);

        RolLogDTO dto = new RolLogDTO(rol, log);

        dto.setUpdatedData("01012000");
        dto.setRolLogType(RolLogTypeEnum.OPERATIONAL_YEAR);
        dto.setOldStatusDescription("x");
        dto.setNewStatusDescription("xx");

        Assert.assertNull(dto.getParameterDescription());
        Assert.assertEquals("01012000", dto.getUpdatedData());
        Assert.assertEquals("", dto.getRolLogValueStyleClass());
        Assert.assertEquals("x", dto.getOldStatusDescription());
        Assert.assertEquals("xx", dto.getNewStatusDescription());

    }
}
