package com.monsanto.brazilvaluecapture.pod.credit.service.impl;

import junit.framework.Assert;

import org.junit.Before;
import org.junit.Test;

import com.monsanto.brazilvaluecapture.core.base.model.bean.Address;
import com.monsanto.brazilvaluecapture.core.base.model.bean.City;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Company;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Country;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Crop;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Document;
import com.monsanto.brazilvaluecapture.core.base.model.bean.State;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Contract;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Customer;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.HeadOffice;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.ParticipantTypeEnum;
import com.monsanto.brazilvaluecapture.core.customer.service.ContractNotFoundException;
import com.monsanto.brazilvaluecapture.core.foundation.RandomTestData;
import com.monsanto.brazilvaluecapture.core.foundation.service.EntityAlreadyExistException;
import com.monsanto.brazilvaluecapture.core.foundation.util.CalendarUtil;
import com.monsanto.brazilvaluecapture.core.grower.CreateTestData;
import com.monsanto.brazilvaluecapture.pod.credit.report.MissingReportDTO;
import com.monsanto.brazilvaluecapture.pod.rol.model.bean.ReportOnLine;
import com.monsanto.brazilvaluecapture.pod.rol.model.service.ReportOnLineSearchDTO;

public class MissingReportDTO_UT extends CreateTestData {

    @Before
    public void setup() {

    }

    @Test
    public void createObjectConstructorTest() {

        // Create system data
        MissingReportDTO dto = new MissingReportDTO();
        dto.setCompany("monsanto");
        dto.setCrop("soya");
        dto.setMissingPeriod(CalendarUtil.getDateNow());
        dto.setPartnerSAPCode("111");
        dto.setPartnerName("Paulo");
        dto.setPartnerDocument("11111111111");
        dto.setPartnerCity("Campinas");
        dto.setPartnerState("São Paulo");
        dto.setPartnerUnit("Unity 1");
        dto.setPartnerRegion("region 1");
        dto.setPartnerDistrict("district 1");
        dto.setHeadOfficeSAPCode("1");
        dto.setHeadOfficeDocument("22222222266");
        dto.setHeadOfficeName("matrix 1");
        dto.setHeadOfficeUnit("Unity 3");
        dto.setHeadOfficeRegion("Region 2");
        dto.setHeadOfficeDistrict("district 2");
        dto.setHeadOfficeContract("3333333");

        testAssert(dto);

    }

    @Test
    public void createObjectConstructorReportOnLineSearchDTOTest() throws ContractNotFoundException,
            EntityAlreadyExistException {
        ReportOnLineSearchDTO dto = createDTO();

        MissingReportDTO reportDto = new MissingReportDTO(dto);
        Assert.assertNotNull(reportDto);
    }

    /**
     * Create object DTO
     * @return
     */
    private ReportOnLineSearchDTO createDTO() {
        // Create system data
        Company company = createBasicCompany();
        Country country = createBasicCountry();
        Crop crop = createBasicCrop();
     
        Address address = createAddress(country);

        Document doc = new Document();
        doc.setValue("11111111111");

        // Create head office
        Customer participant = createCustomer("zeca", address, doc);
        Customer matrix = createCustomer("maria", address, doc);
        
        Contract contract = createContract(company, crop, matrix);
        matrix.addContract(contract);

        HeadOffice headoffice = new HeadOffice(participant, matrix, ParticipantTypeEnum.POD, crop, company);
        ReportOnLine rol = new ReportOnLine();
        rol.setCrop(crop);
        rol.setHeadoffice(headoffice);

        ReportOnLineSearchDTO dto = new ReportOnLineSearchDTO(headoffice);
        dto.setAddress(address);
        dto.setAffiliate(headoffice);
        dto.setDescription("blh!");
        dto.setDocument(new Document());
        dto.setRol(rol);
        dto.setSentRol(false);
        return dto;
    }

    private Contract createContract(Company company, Crop crop, Customer matrix) {
        Contract contract = new Contract();
        contract.setCompany(company);
        contract.setContractCode("2222222222222");
        contract.setCrop(crop);
        contract.setParticipantType(ParticipantTypeEnum.POD);
        contract.setCustomer(matrix);
        return contract;
    }

    private Customer createCustomer(String name, Address address, Document doc) {
        return new Customer(name, doc, address, RandomTestData.createRandomLong().toString());
    }

    /**
     * Create Address
     * @param country
     * @return
     */
    private Address createAddress(Country country) {
        State state = new State();
        state.setCode("SP");
        state.setCountry(country);
        state.setDescription("Sao Paulo");

        City city = new City();
        city.setDescription("A. Nogueira");
        city.setId(1L);
        city.setState(state);

        Address address = new Address();
        address.setCity(city);
        address.setCountry(country);
        address.setState(state);
        address.setStreet("street of tomorrow");
        address.setZipCode("123456");
        return address;
    }

    /**
     * Validating of missingReportDTO
     * 
     * @param dto
     */
    void testAssert(MissingReportDTO dto) {

        Assert.assertNotNull(dto);
        Assert.assertNotNull(dto.getCompany());
        Assert.assertNotNull(dto.getCrop());
        Assert.assertNotNull(dto.getMissingPeriod());
        Assert.assertNotNull(dto.getMissingPeriodValueFormatted());
        Assert.assertNotNull(dto.getPartnerSAPCode());
        Assert.assertNotNull(dto.getPartnerDocument());
        Assert.assertNotNull(dto.getPartnerName());
        Assert.assertNotNull(dto.getPartnerCity());
        Assert.assertNotNull(dto.getPartnerState());
        Assert.assertNotNull(dto.getPartnerUnit());
        Assert.assertNotNull(dto.getPartnerRegion());
        Assert.assertNotNull(dto.getPartnerDistrict());
        Assert.assertNotNull(dto.getHeadOfficeSAPCode());
        Assert.assertNotNull(dto.getHeadOfficeName());
        Assert.assertNotNull(dto.getHeadOfficeDocument());
        Assert.assertNotNull(dto.getHeadOfficeUnit());
        Assert.assertNotNull(dto.getHeadOfficeRegion());
        Assert.assertNotNull(dto.getHeadOfficeDistrict());
        Assert.assertNotNull(dto.getHeadOfficeContract());
    }

}
