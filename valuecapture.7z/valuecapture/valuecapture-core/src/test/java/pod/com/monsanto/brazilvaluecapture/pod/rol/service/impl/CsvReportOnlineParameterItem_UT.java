package com.monsanto.brazilvaluecapture.pod.rol.service.impl;

import java.math.BigDecimal;

import org.junit.Test;

import junit.framework.Assert;

import com.monsanto.brazilvaluecapture.core.base.model.bean.Crop;
import com.monsanto.brazilvaluecapture.core.user.model.bean.ItsUser;
import com.monsanto.brazilvaluecapture.pod.rol.model.bean.RolParameter;
import com.monsanto.brazilvaluecapture.pod.rol.model.service.impl.CsvReportOnlineItem;
import com.monsanto.brazilvaluecapture.pod.rol.model.service.impl.CsvReportOnlineParameterItem;

/**
 * @author cmiranda
 * 
 */
public class CsvReportOnlineParameterItem_UT {

    /**
     * 
     */
    @Test
    public void test_csv_report_online_item_getters() {

        RolParameter rolParameter = new RolParameter();
        rolParameter.setRolParamShownDescription("P1.0");

        CsvReportOnlineItem parent = new CsvReportOnlineItem(new Crop(), new ItsUser());
        CsvReportOnlineParameterItem item = new CsvReportOnlineParameterItem(parent,
                rolParameter.getRolParamShownDescription(), BigDecimal.ONE, rolParameter);

        item.setLine(3);
        item.setWarn("xx");
        item.setPositionColumn(2);// set column index position

        Assert.assertEquals(new Integer(3), item.getLine());
        Assert.assertEquals("xx", item.getCodeWarn());
        Assert.assertEquals(rolParameter.getRolParamShownDescription(), item.getParameterName());
        Assert.assertEquals(new Integer(3), item.getPositionColumn());
        Assert.assertEquals(rolParameter, item.getRolParameter());
        Assert.assertEquals(BigDecimal.ONE, item.getValue());
        Assert.assertEquals("xx", item.getWarn());
        Assert.assertTrue(item.getLines().contains(3));

    }
}
