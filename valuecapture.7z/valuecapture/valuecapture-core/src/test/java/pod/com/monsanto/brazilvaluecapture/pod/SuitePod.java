package com.monsanto.brazilvaluecapture.pod;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

import com.monsanto.brazilvaluecapture.pod.credit.SuiteCreditConsumption;
import com.monsanto.brazilvaluecapture.pod.revenue.SuitePodRevenue;
import com.monsanto.brazilvaluecapture.pod.rol.SuiteRol;

@RunWith(value = Suite.class)
@SuiteClasses(value = { 
		SuiteCreditConsumption.class,
		SuiteRol.class,
		SuitePodRevenue.class})
public class SuitePod {

}
