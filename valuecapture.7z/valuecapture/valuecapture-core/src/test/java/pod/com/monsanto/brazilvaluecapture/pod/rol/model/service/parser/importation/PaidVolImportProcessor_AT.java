package com.monsanto.brazilvaluecapture.pod.rol.model.service.parser.importation;

import java.io.IOException;
import java.io.InputStream;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.ResourceBundle;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.monsanto.brazilvaluecapture.core.foundation.service.BusinessException;
import com.monsanto.brazilvaluecapture.core.foundation.test.AbstractServiceIntegrationTests;
import com.monsanto.brazilvaluecapture.core.foundation.test.dbunit.DbUnitHelper;
import com.monsanto.brazilvaluecapture.core.foundation.util.CalendarUtil;
import com.monsanto.brazilvaluecapture.core.foundation.util.StringUtils;
import com.monsanto.brazilvaluecapture.core.importfile.model.bean.CsvImportFile;
import com.monsanto.brazilvaluecapture.core.io.ProcessorConfig;
import com.monsanto.brazilvaluecapture.core.io.ProcessorConfig.ProcessorConfigProperties;
import com.monsanto.brazilvaluecapture.core.io.WarningImportedException;
import com.monsanto.brazilvaluecapture.core.user.model.bean.ItsUser;
import com.monsanto.brazilvaluecapture.core.user.model.bean.UserDecorator;
import com.monsanto.brazilvaluecapture.pod.rol.model.bean.CsvPaidVolImportLine;

public class PaidVolImportProcessor_AT extends AbstractServiceIntegrationTests {

    private static int LINE_NUMBER_ONE = 1;
    private static int ZERO_VIOLATION = 0;
    private static int ONE_VIOLATION = 1;
    private static int ZERO_LINE = 0;
    private static int ONE_LINE = 1;
    private static int TWO_LINE = 2;

    private static final String valideGrowerDocumentType = "CPF_fake";
    private static final String valideGrowerDocument = "556565665";

    private static final String valideAffiliateDocumentType = "CPF_fake";
    private static final String valideAffiliateDocument = "9090909090";

    private static final String valideTechnology = "XLG RR";

    // Enum used to identify the CSV part that will be invalid, only to
    // facilitate the tests
    private enum InvalidPart {
        Customer, Grower, DateReceive, Period, Technology, Volume, RoyaltyValue
    };

    private PaidVolImportedFile paidVolImportedFile;
    private ProcessorConfig processorConfig;

    @Autowired
    private PaidVolImportProcessor paidVolImportProcessor;

    @Autowired
    private PaidVolImportParser importParser;

    @Before
    public void init() {
        paidVolImportedFile = new PaidVolImportedFile();
        DbUnitHelper.setup("classpath:data/pod/rol/report-online-by-grower-complete-scenary-dataset.xml");

        // Get its user
        ItsUser user = (ItsUser) getSession().get(ItsUser.class, 999900001L);
        processorConfig = createProcessorConfig(new UserDecorator(user, user));
    }

    private ProcessorConfig createProcessorConfig(UserDecorator user) {
        ProcessorConfig aProcessorConfig = new ProcessorConfig();
        aProcessorConfig.put(ProcessorConfigProperties.SELECTED_LOCALE, new Locale("pt", "BR"));
        aProcessorConfig.put(ProcessorConfigProperties.LOGGED_USER, user);
        aProcessorConfig.put(ProcessorConfigProperties.BUNDLE, ResourceBundle.getBundle("bundle/bundle"));
        paidVolImportedFile.setLocale(new Locale("pt", "BR"));
        return aProcessorConfig;
    }

    @Test
    public void given_a_imported_line_with_inexistent_customer_should_throw_exception() throws WarningImportedException {

        // Create an invalid line to be imported
        CsvPaidVolImportLine line = createInvalidCsvPaidVolImportedLine(InvalidPart.Customer);

        // Add the invalid line in the file and process it
        preparePaidVolImportLine(line);
        importParser.proccessFile(paidVolImportedFile);

        Assert.assertEquals("Should have one violation", ONE_VIOLATION, paidVolImportedFile.countWarnings());
    }

    @Test
    public void given_a_imported_line_with_inexistent_grower_should_throw_exception() throws WarningImportedException {

        // Create an invalid line to be imported
        CsvPaidVolImportLine line = createInvalidCsvPaidVolImportedLine(InvalidPart.Grower);

        // Add the invalid line in the file and process it
        preparePaidVolImportLine(line);
        importParser.proccessFile(paidVolImportedFile);

        Assert.assertEquals("Should have one violation", ONE_VIOLATION, paidVolImportedFile.countWarnings());
    }

    @Test
    public void given_a_imported_line_with_inexistent_date_receive_should_throw_exception()
            throws WarningImportedException {

        // Create an invalid line to be imported
        CsvPaidVolImportLine line = createInvalidCsvPaidVolImportedLine(InvalidPart.DateReceive);

        // Add the invalid line in the file and process it
        preparePaidVolImportLine(line);
        importParser.proccessFile(paidVolImportedFile);

        Assert.assertEquals("Should have one violation", ONE_VIOLATION, paidVolImportedFile.countWarnings());
    }

    @Test
    public void given_a_imported_line_with_inexistent_period_should_throw_exception() throws WarningImportedException {

        // Create an invalid line to be imported
        CsvPaidVolImportLine line = createInvalidCsvPaidVolImportedLine(InvalidPart.Period);

        // Add the invalid line in the file and process it
        preparePaidVolImportLine(line);
        importParser.proccessFile(paidVolImportedFile);

        Assert.assertEquals("Should have one violation", ONE_VIOLATION, paidVolImportedFile.countWarnings());
    }

    @Test
    public void given_a_imported_line_with_inexistent_technology_should_throw_exception()
            throws WarningImportedException {

        // Create an invalid line to be imported
        CsvPaidVolImportLine line = createInvalidCsvPaidVolImportedLine(InvalidPart.Technology);

        // Add the invalid line in the file and process it
        preparePaidVolImportLine(line);
        importParser.proccessFile(paidVolImportedFile);

        Assert.assertEquals("Should have one violation", ONE_VIOLATION, paidVolImportedFile.countWarnings());
    }

    @Test
    public void given_a_imported_line_with_inexistent_volume_should_throw_exception() throws WarningImportedException {

        // Create an invalid line to be imported
        CsvPaidVolImportLine line = createInvalidCsvPaidVolImportedLine(InvalidPart.Volume);

        // Add the invalid line in the file and process it
        preparePaidVolImportLine(line);
        importParser.proccessFile(paidVolImportedFile);

        Assert.assertEquals("Should have one violation", ONE_VIOLATION, paidVolImportedFile.countWarnings());
    }

    @Test
    public void given_a_imported_line_with_inexistent_royalty_value_should_throw_exception()
            throws WarningImportedException {

        // Create an invalid line to be imported
        CsvPaidVolImportLine line = createInvalidCsvPaidVolImportedLine(InvalidPart.RoyaltyValue);

        // Add the invalid line in the file and process it
        preparePaidVolImportLine(line);
        importParser.proccessFile(paidVolImportedFile);

        Assert.assertEquals("Should have one violation", ONE_VIOLATION, paidVolImportedFile.countWarnings());
    }

    @Test
    public void given_a_valid_imported_line_should_import() throws WarningImportedException {

        // Create a valid line to be imported
        CsvPaidVolImportLine line = createValidCsvPaidVolImportedLine();

        // Add the valid line in the file and process it
        preparePaidVolImportLine(line);
        importParser.proccessFile(paidVolImportedFile);

        Assert.assertEquals("Should have no violation", ZERO_VIOLATION, paidVolImportedFile.countWarnings());
        Assert.assertEquals("Should have one line imported", ONE_LINE, paidVolImportedFile.countDetailLines());
    }

    @Test
    public void given_two_valid_imported_lines_should_import() throws WarningImportedException {

        List<CsvPaidVolImportLine> lines = new ArrayList<CsvPaidVolImportLine>();

        // Create a valid line to be imported
        CsvPaidVolImportLine line = createValidCsvPaidVolImportedLine();
        lines.add(line);

        // Create another valid line to be imported
        line = createValidCsvPaidVolImportedLine();
        lines.add(line);

        // Add the valid lines in the file and process them
        prepareQuotaImportedFile(lines);
        importParser.proccessFile(paidVolImportedFile);

        Assert.assertEquals("Should have no violation", ZERO_VIOLATION, paidVolImportedFile.countWarnings());
        Assert.assertEquals("Should have two lines imported", TWO_LINE, paidVolImportedFile.countDetailLines());
    }

    @Test
    public void given_an_invalid_csv_should_return_one_warning() throws IOException, BusinessException {

        // Get the CSV file
        InputStream resourceAsStream = getClass().getClassLoader().getResourceAsStream("csvPaidVol/emptyFile.csv");
        this.processorConfig.put(ProcessorConfigProperties.FILENAME, "emptyFile.csv");

        // Process the CSV file
        PaidVolImportedFile paidVolImportedFile = paidVolImportProcessor.read(resourceAsStream, processorConfig);
        this.assertImportResultStatus(ZERO_LINE, ZERO_LINE, ONE_VIOLATION, ZERO_VIOLATION, ONE_LINE,
                paidVolImportedFile);
    }

    @Test
    public void given_a_valid_csv_should_succeed() throws IOException, BusinessException {

        // Get the CSV file
        InputStream resourceAsStream = getClass().getClassLoader().getResourceAsStream("csvPaidVol/emptyFile.csv");
        this.processorConfig.put(ProcessorConfigProperties.FILENAME, "emptyFile.csv");

        // Process the CSV file
        CsvImportFile csvImportFile = paidVolImportProcessor.readLines(resourceAsStream, processorConfig);
        Assert.assertNotNull("The CSV file doesn't exist.", csvImportFile);
    }

    private CsvPaidVolImportLine createValidCsvPaidVolImportedLine() {

        return createCsvPaidVolImportedLine(LINE_NUMBER_ONE, valideAffiliateDocumentType, valideAffiliateDocument,
                valideGrowerDocumentType, valideGrowerDocument, CalendarUtil.getDate(3010, Calendar.JANUARY),
                CalendarUtil.getDate(3010, Calendar.JANUARY), valideTechnology, BigDecimal.ONE, BigDecimal.ONE);
    }

    private CsvPaidVolImportLine createInvalidCsvPaidVolImportedLine(InvalidPart invalidPart) {

        if (invalidPart == InvalidPart.Customer) {

            return createCsvPaidVolImportedLine(LINE_NUMBER_ONE, StringUtils.EMPTY, StringUtils.EMPTY,
                    valideGrowerDocumentType, valideGrowerDocument, new Date(),
                    CalendarUtil.getDate(2006, Calendar.JANUARY), valideTechnology, BigDecimal.ONE, BigDecimal.ONE);
        } else if (invalidPart == InvalidPart.Grower) {
            return createCsvPaidVolImportedLine(LINE_NUMBER_ONE, valideAffiliateDocumentType, valideAffiliateDocument,
                    StringUtils.EMPTY, StringUtils.EMPTY, new Date(), new Date(), valideTechnology, BigDecimal.ONE,
                    BigDecimal.ONE);
        } else if (invalidPart == InvalidPart.DateReceive) {
            return createCsvPaidVolImportedLine(LINE_NUMBER_ONE, valideAffiliateDocumentType, valideAffiliateDocument,
                    valideGrowerDocumentType, valideGrowerDocument, null, new Date(), valideTechnology, BigDecimal.ONE,
                    BigDecimal.ONE);
        } else if (invalidPart == InvalidPart.Period) {

            return createCsvPaidVolImportedLine(LINE_NUMBER_ONE, valideAffiliateDocumentType, valideAffiliateDocument,
                    valideGrowerDocumentType, valideGrowerDocument, new Date(), null, valideTechnology, BigDecimal.ONE,
                    BigDecimal.ONE);
        } else if (invalidPart == InvalidPart.Technology) {

            return createCsvPaidVolImportedLine(LINE_NUMBER_ONE, valideAffiliateDocumentType, valideAffiliateDocument,
                    valideGrowerDocumentType, valideGrowerDocument, new Date(), new Date(), StringUtils.EMPTY,
                    BigDecimal.ONE, BigDecimal.ONE);
        } else if (invalidPart == InvalidPart.Volume) {

            return createCsvPaidVolImportedLine(LINE_NUMBER_ONE, valideAffiliateDocumentType, valideAffiliateDocument,
                    valideGrowerDocumentType, valideGrowerDocument, new Date(), new Date(), valideTechnology, null,
                    BigDecimal.ONE);
        } else {

            return createCsvPaidVolImportedLine(LINE_NUMBER_ONE, valideAffiliateDocumentType, valideAffiliateDocument,
                    valideGrowerDocumentType, valideGrowerDocument, new Date(), new Date(), valideTechnology,
                    BigDecimal.ONE, null);
        }
    }

    /**
     * Method used to create one CSV line in memory.
     * 
     * @param lineNumber
     *            CSV line number.
     * @param customerDocumentType
     * @param customerDocument
     * @param growerDocumentType
     * @param growerDocument
     * @param dateReceive
     * @param period
     * @param technology
     * @param volume
     * @param royaltyValue
     * @return CSV line.
     */
    private CsvPaidVolImportLine createCsvPaidVolImportedLine(Integer lineNumber, String customerDocumentType,
            String customerDocument, String growerDocumentType, String growerDocument, Date dateReceive, Date period,
            String technology, BigDecimal volume, BigDecimal royaltyValue) {

        CsvPaidVolImportLine line = new CsvPaidVolImportLine();
        line.setLine(lineNumber);
        line.setCustomerDocumentType(customerDocumentType);
        line.setCustomerDocument(customerDocument);
        line.setGrowerDocumentType(growerDocumentType);
        line.setGrowerDocument(growerDocument);
        line.setDateReceive(dateReceive);
        line.setPeriod(period);
        line.setTechnology(technology);
        line.setVolume(volume);
        line.setRoyaltyValue(royaltyValue);
        line.setEntityUser(null);
        line.setCompanyId(999900001L);
        line.setCropId(999900001L);
        line.setHeadofficeId(999900002L);

        return line;
    }

    private void preparePaidVolImportLine(CsvPaidVolImportLine line) {
        ArrayList<CsvPaidVolImportLine> lines = new ArrayList<CsvPaidVolImportLine>();
        lines.add(line);
        paidVolImportedFile.setAllEntities(lines);
    }

    private void prepareQuotaImportedFile(List<CsvPaidVolImportLine> lines) {
        paidVolImportedFile.setAllEntities(lines);
    }

    private void assertImportResultStatus(int expectedSuccessLinesCount, int expectedDetailLinesCount,
            int expectedWarningCount, int expectedErrorsCount, int totalLineNumber, PaidVolImportedFile actualResult) {

        Assert.assertNotNull("Result of read file should not be null.", actualResult);
        Assert.assertEquals("Number of success lines is wrong.", expectedSuccessLinesCount, actualResult.countSuccess());
        Assert.assertEquals("Number of detail lines is wrong.", expectedDetailLinesCount,
                actualResult.countDetailLines());
        Assert.assertEquals("Number of warnings is wrong.", expectedWarningCount, actualResult.countWarnings());
        Assert.assertEquals("Number of erros is wrong.", expectedErrorsCount, actualResult.countErrors());
        Assert.assertEquals("Total # of lines is wrong.", totalLineNumber, actualResult.countTotalLines());
    }
}
