package com.monsanto.brazilvaluecapture.pod.rol.model.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.ResourceBundle;

import junit.framework.Assert;

import org.junit.Test;
import org.mockito.Mockito;

import com.monsanto.brazilvaluecapture.core.customer.model.bean.Customer;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.HeadOffice;
import com.monsanto.brazilvaluecapture.core.foundation.util.ConstraintViolation;
import com.monsanto.brazilvaluecapture.core.foundation.util.ErrorCode;
import com.monsanto.brazilvaluecapture.pod.rol.model.bean.CsvPaidVolImportLine;

/**
 * @author cmiranda
 * 
 */
public class ReportOnlineByGrowerConstraintException_UT {

    /**
     * Bundle
     */
    private ResourceBundle resourceBundle = ResourceBundle.getBundle("bundle/bundle");

    @Test
    public void test_get_warnings_for_grower_exceeding_royalty_value() {

        // Instantiate exception to test
        ReportOnlineByGrowerConstraintException exception = new ReportOnlineByGrowerConstraintException("meleca");

        // Mock customer
        Customer customer = Mockito.mock(Customer.class);
        Mockito.when(customer.getName()).thenReturn("johnny");

        // Mock headoffice
        HeadOffice headOffice = Mockito.mock(HeadOffice.class);
        Mockito.when(headOffice.getCustomer()).thenReturn(customer);

        CsvPaidVolImportLine importedLine = new CsvPaidVolImportLine();
        importedLine.setLine(1);
        importedLine.setHeadOffice(headOffice);

        // Create constraint violation
        ConstraintViolation constraintViolation = new ConstraintViolation("xxx xx x 0",
                ErrorCode.GROWER_EXCEEDING_ROYALTY, "value");
        constraintViolation.addPlace("x");
        constraintViolation.addPlace("x");
        constraintViolation.addPlace("x");

        // Create violations
        List<ConstraintViolation> violations = new ArrayList<ConstraintViolation>();
        violations.add(constraintViolation);
        exception.setViolations(violations);

        // Get warnings
        List<ReportWarningImportedException> exceptions = exception.getWarnings(importedLine, true, true,
                resourceBundle);

        Assert.assertNotNull(exceptions);
        Assert.assertFalse(exceptions.isEmpty());

    }

    @Test
    public void test_get_warnings_for_grower_exceeding_volume() {

        // Instantiate exception to test
        ReportOnlineByGrowerConstraintException exception = new ReportOnlineByGrowerConstraintException("meleca");

        // Mock customer
        Customer customer = Mockito.mock(Customer.class);
        Mockito.when(customer.getName()).thenReturn("johnny");

        // Mock headoffice
        HeadOffice headOffice = Mockito.mock(HeadOffice.class);
        Mockito.when(headOffice.getCustomer()).thenReturn(customer);

        CsvPaidVolImportLine importedLine = new CsvPaidVolImportLine();
        importedLine.setLine(1);
        importedLine.setHeadOffice(headOffice);

        // Create constraint violation
        ConstraintViolation constraintViolation = new ConstraintViolation("xxx xx x 0",
                ErrorCode.GROWER_EXCEEDING_VOLUME, "value");
        constraintViolation.addPlace("x");
        constraintViolation.addPlace("x");
        constraintViolation.addPlace("x");

        // Create violations
        List<ConstraintViolation> violations = new ArrayList<ConstraintViolation>();
        violations.add(constraintViolation);
        exception.setViolations(violations);

        // Get warnings
        List<ReportWarningImportedException> exceptions = exception.getWarnings(importedLine, true, true,
                resourceBundle);

        Assert.assertNotNull(exceptions);
        Assert.assertFalse(exceptions.isEmpty());

    }

    @Test
    public void test_get_warnings_list_for_grower_exceeding_volume() {

        // Instantiate exception to test
        ReportOnlineByGrowerConstraintException exception = new ReportOnlineByGrowerConstraintException("meleca");

        // Mock customer
        Customer customer = Mockito.mock(Customer.class);
        Mockito.when(customer.getName()).thenReturn("johnny");

        // Mock headoffice
        HeadOffice headOffice = Mockito.mock(HeadOffice.class);
        Mockito.when(headOffice.getCustomer()).thenReturn(customer);

        List<CsvPaidVolImportLine> lines = new ArrayList<CsvPaidVolImportLine>();
        CsvPaidVolImportLine importedLine = new CsvPaidVolImportLine();
        importedLine.setLine(1);
        importedLine.setHeadOffice(headOffice);
        lines.add(importedLine);
        lines.add(importedLine);

        // Create constraint violation
        ConstraintViolation constraintViolation = new ConstraintViolation("xxx xx x 0",
                ErrorCode.GROWER_EXCEEDING_VOLUME, "value");
        constraintViolation.addPlace("x");
        constraintViolation.addPlace("x");
        constraintViolation.addPlace("x");

        // Create violations
        List<ConstraintViolation> violations = new ArrayList<ConstraintViolation>();
        violations.add(constraintViolation);
        exception.setViolations(violations);

        // Get warnings
        List<ReportWarningImportedException> exceptions = exception.getWarnings(lines, true, false, resourceBundle);

        Assert.assertNotNull(exceptions);
        Assert.assertFalse(exceptions.isEmpty());

    }

    @Test
    public void test_get_warnings_for_grower_exceeding_volume_not_importing() {

        // Instantiate exception to test
        ReportOnlineByGrowerConstraintException exception = new ReportOnlineByGrowerConstraintException("meleca");

        // Mock customer
        Customer customer = Mockito.mock(Customer.class);
        Mockito.when(customer.getName()).thenReturn("johnny");

        // Mock headoffice
        HeadOffice headOffice = Mockito.mock(HeadOffice.class);
        Mockito.when(headOffice.getCustomer()).thenReturn(customer);

        CsvPaidVolImportLine importedLine = new CsvPaidVolImportLine();
        importedLine.setLine(1);
        importedLine.setHeadOffice(headOffice);
        importedLine.setPeriod(new Date());

        // Create constraint violation
        ConstraintViolation constraintViolation = new ConstraintViolation("xxx xx x 0",
                ErrorCode.GROWER_EXCEEDING_VOLUME, "value");
        constraintViolation.addPlace("x");
        constraintViolation.addPlace("x");
        constraintViolation.addPlace("x");

        // Create violations
        List<ConstraintViolation> violations = new ArrayList<ConstraintViolation>();
        violations.add(constraintViolation);
        exception.setViolations(violations);

        // Get warnings
        List<ReportWarningImportedException> exceptions = exception.getWarnings(importedLine, false, false,
                resourceBundle);

        Assert.assertNotNull(exceptions);
        Assert.assertFalse(exceptions.isEmpty());

    }
}
