package com.monsanto.brazilvaluecapture.pod.rol.service.impl;

import junit.framework.Assert;

import org.junit.Before;
import org.junit.Test;

import com.monsanto.brazilvaluecapture.core.base.model.bean.Address;
import com.monsanto.brazilvaluecapture.core.base.model.bean.City;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Company;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Country;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Crop;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Document;
import com.monsanto.brazilvaluecapture.core.base.model.bean.State;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Customer;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.HeadOffice;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.ParticipantTypeEnum;
import com.monsanto.brazilvaluecapture.core.foundation.RandomTestData;
import com.monsanto.brazilvaluecapture.core.grower.CreateTestData;
import com.monsanto.brazilvaluecapture.pod.rol.model.bean.ReportOnLine;
import com.monsanto.brazilvaluecapture.pod.rol.model.service.ReportOnLineSearchDTO;

public class ReportOnlineSearchDTO_UT extends CreateTestData {

    @Before
    public void setup() {

    }

    @Test
    public void createObjectConstructorTest() {

        // Create system data
        Country country = new Country("Brasil", "br");
        Company company = new Company("monsanto");
        Crop crop = new Crop("soya", company, country);

        State state = new State();
        state.setCode("SP");
        state.setCountry(country);
        state.setDescription("Sao Paulo");

        City city = new City();
        city.setDescription("A. Nogueira");
        city.setId(1L);
        city.setState(state);

        // Create head office
        Customer participant = new Customer("zeca", null, null, RandomTestData.createRandomLong().toString());
        Customer matrix = new Customer("maria", null, null, RandomTestData.createRandomLong().toString());
        HeadOffice headoffice = new HeadOffice(participant, matrix, ParticipantTypeEnum.POD, crop, company);

        Address address = new Address();
        address.setCity(city);
        address.setCountry(country);
        address.setState(state);
        address.setStreet("street of tomorrow");
        address.setZipCode("123456");

        ReportOnLineSearchDTO dto = new ReportOnLineSearchDTO(headoffice);
        dto.setAddress(address);
        dto.setAffiliate(headoffice);
        dto.setDescription("blh!");
        dto.setDocument(new Document());
        dto.setRol(new ReportOnLine());
        dto.setSentRol(false);

        testAssert(dto);

    }

    /**
     * Validating of grower
     * 
     * @param grower
     */
    private void testAssert(ReportOnLineSearchDTO dto) {

        Assert.assertNotNull(dto);
        Assert.assertNotNull(dto.getDescription());
        Assert.assertNotNull(dto.getSendRolDescription());
        Assert.assertNotNull(dto.getAddress());
        Assert.assertNotNull(dto.getAffiliate());
        Assert.assertNotNull(dto.getDocument());
        Assert.assertNotNull(dto.getRol());

    }

}
