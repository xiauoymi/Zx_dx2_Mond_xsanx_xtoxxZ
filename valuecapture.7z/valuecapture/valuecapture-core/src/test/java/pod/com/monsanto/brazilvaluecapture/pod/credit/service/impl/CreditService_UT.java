package com.monsanto.brazilvaluecapture.pod.credit.service.impl;

import static org.junit.Assert.assertFalse;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

import com.monsanto.brazilvaluecapture.core.account.model.bean.Account;
import com.monsanto.brazilvaluecapture.core.account.model.dao.AccountFilter;
import com.monsanto.brazilvaluecapture.core.account.service.impl.AccountService;
import com.monsanto.brazilvaluecapture.core.base.model.bean.CreditConsumption;
import com.monsanto.brazilvaluecapture.core.base.model.bean.CreditConsumptionItem;
import com.monsanto.brazilvaluecapture.core.base.model.bean.CreditConsumptionStatus;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Crop;
import com.monsanto.brazilvaluecapture.core.base.model.bean.OperationalYear;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.HeadOffice;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Technology;
import com.monsanto.brazilvaluecapture.core.foundation.service.BusinessException;
import com.monsanto.brazilvaluecapture.core.foundation.service.EntityNotFoundException;
import com.monsanto.brazilvaluecapture.core.grower.model.bean.Grower;
import com.monsanto.brazilvaluecapture.pod.credit.model.dao.CreditDAO;
import com.monsanto.brazilvaluecapture.pod.credit.service.CreditConsumptionConstraintException;
import com.monsanto.brazilvaluecapture.pod.credit.service.CreditConsumptionException;
import com.monsanto.brazilvaluecapture.seedsale.extract.credit.model.bean.amount.ContentHandled;
import com.monsanto.brazilvaluecapture.seedsale.extract.credit.model.bean.amount.ICreditAmount;

/**
 * @author cmiranda
 * 
 */
public class CreditService_UT {

    private CreditDAO creditDAO;
    private AccountService accountService;

    // Service implementation to be tested
    private CreditServiceImpl creditServiceImpl = new CreditServiceImpl();

    /**
     * @throws EntityNotFoundException
     * 
     */
    @Before
    public void setup() throws BusinessException {

        creditDAO = Mockito.mock(CreditDAO.class);
        creditServiceImpl.setCreditDAO(creditDAO);

        accountService = Mockito.mock(AccountService.class);
        creditServiceImpl.setAccountService(accountService);
        
        Account account = Mockito.mock(Account.class);

        Mockito.when(account.getBalance()).thenReturn(new BigDecimal("200000"));

        Mockito.when(accountService.getUniqueAccountBy((AccountFilter) Mockito.anyObject())).thenReturn(account);

    }

    /**
     * @throws BusinessException
     * @throws CreditConsumptionConstraintException
     */
    @Test(expected = CreditConsumptionException.class)
    public void test_save_credit_consumption_with_account_inconsistent_expected_credit_consumption_exception()
            throws BusinessException, CreditConsumptionConstraintException {

        // Create a credit consumption
        CreditConsumption creditConsumption = new CreditConsumption();
        creditConsumption.setCorrectionDate(new Date());
        creditConsumption.setCorrectionItsUserLogin(null);
        creditConsumption.setCreditConsumptionItens(new HashSet<CreditConsumptionItem>());
        creditConsumption.setCreditConsumptionStatus(CreditConsumptionStatus.OPENED);
        creditConsumption.setHeadoffice(null);
        creditConsumption.setOriginalCreditConsumption(null);
        creditConsumption.setReversalDate(null);
        creditConsumption.setReversalItsUserLogin(null);
        creditConsumption.setReversalReasonDesc(null);
        creditConsumption.setHeadoffice(new HeadOffice());
        creditConsumption.setGrower(new Grower());
        creditConsumption.setItsUserLogin("juquinha");

        Technology tech = new Technology();
        tech.setId(0L);

        Crop crop = new Crop();
        crop.setId(0L);

        OperationalYear operationalYear = new OperationalYear();
        operationalYear.setId(0L);

        CreditConsumptionItem item = new CreditConsumptionItem();
        item.setCreditConsumption(creditConsumption);
        item.setRequestValue(BigDecimal.TEN);
        item.setTechnology(tech);
        item.setCrop(crop);
        item.setOperationalYear(operationalYear);

        creditConsumption.getCreditConsumptionItens().add(item);

        Mockito.doThrow(BusinessException.class)
                .when(accountService)
                .saveCreditConsumption((Crop) Mockito.anyObject(), (Technology) Mockito.anyObject(),
                        (OperationalYear) Mockito.anyObject(), (Grower) Mockito.anyObject(),
                        (BigDecimal) Mockito.anyObject(), Mockito.anyLong());

        creditServiceImpl.saveCreditConsumption(creditConsumption);

    }
    @SuppressWarnings("unchecked")
    @Test
    public void test_select_credit_consumption_item_by_id_is_not_empty(){
        ICreditAmount creditAmountMock = Mockito.mock(ICreditAmount.class);
        List<ContentHandled> listHandleCode = new ArrayList<ContentHandled>();
        ContentHandled contentHandleMock = Mockito.mock(ContentHandled.class);
        Mockito.when(contentHandleMock.getCodeHandled()).thenReturn(1L);
        listHandleCode.add(contentHandleMock);
        Mockito.when(creditAmountMock.getContentHandles()).thenReturn(listHandleCode);
        List<CreditConsumptionItem> listCreditConsumptionItem = new ArrayList<CreditConsumptionItem>();
        CreditConsumptionItem creditConsumptionItem = new CreditConsumptionItem();
        CreditConsumption creditConsumption = new CreditConsumption();
        creditConsumption.setCreditConsumptionStatus(CreditConsumptionStatus.OPENED);
        creditConsumptionItem.setCreditConsumption(creditConsumption );
        listCreditConsumptionItem.add(creditConsumptionItem );
        Mockito.when(creditDAO.findCreditConsumptionById(Mockito.anyList())).thenReturn(listCreditConsumptionItem);
        assertFalse(creditServiceImpl.selectCreditConsumptionById(creditAmountMock).isEmpty());
    }
}
