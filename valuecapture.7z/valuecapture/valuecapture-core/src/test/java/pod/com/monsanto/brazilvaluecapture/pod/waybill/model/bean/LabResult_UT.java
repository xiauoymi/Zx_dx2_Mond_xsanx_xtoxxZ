package com.monsanto.brazilvaluecapture.pod.waybill.model.bean;

import org.junit.Test;

import java.math.BigInteger;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

public class LabResult_UT {

    @Test
    public void testSettersAndGetters() {
        Long id = 82L;
        IncomingWaybill incomingWaybill = mock(IncomingWaybill.class);
        String technologyCode = "INTACTA";
        BigInteger weightDetected = BigInteger.TEN;
        String labCode = "LAB 01";
        LabResult labResult = new LabResult();

        labResult.setId(id);
        labResult.setIncomingWaybill(incomingWaybill);
        labResult.setTechnologyCode(technologyCode);
        labResult.setWeightDetected(weightDetected);
        labResult.setLabCode(labCode);

        assertEquals(id, labResult.getId());
        assertEquals(id, labResult.getPrimaryKey());
        assertEquals(incomingWaybill, labResult.getIncomingWaybill());
        assertEquals(technologyCode, labResult.getTechnologyCode());
        assertEquals(weightDetected, labResult.getWeightDetected());
        assertEquals(labCode, labResult.getLabCode());
    }

}