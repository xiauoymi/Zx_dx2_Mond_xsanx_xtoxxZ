package com.monsanto.brazilvaluecapture.pod.rol.model.bean;

import junit.framework.Assert;

import org.junit.Test;

import com.monsanto.brazilvaluecapture.core.base.model.bean.DocumentType;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.ParticipantTypeEnum;

/**
 * @author cmiranda
 * 
 */
public class HeadOfficeBlockDTO_UT {

    @Test
    public void sanity_test_dto() {

        HeadOfficeBlockDTO dto = new HeadOfficeBlockDTO(null, null, null, null, null, null);
        dto.setHeadofficeId(-1L);
        dto.setBlocked(Boolean.TRUE);
        dto.setDocument("123");
        dto.setDocumentType(new DocumentType("", null, "999"));
        dto.setName("jose");
        dto.setType(ParticipantTypeEnum.POD);

        Assert.assertEquals(Boolean.TRUE, dto.getBlocked());
        Assert.assertEquals(new Long(-1), dto.getHeadofficeId());
        Assert.assertEquals("123", dto.getDocument());
        Assert.assertEquals("123", dto.getValueFormatted());
        Assert.assertEquals(new DocumentType("", null, "999"), dto.getDocumentType());
        Assert.assertEquals(ParticipantTypeEnum.POD, dto.getType());
        Assert.assertEquals("jose", dto.getName());

        dto.setDocumentType(null);
        dto.getValueFormatted();

    }
}
