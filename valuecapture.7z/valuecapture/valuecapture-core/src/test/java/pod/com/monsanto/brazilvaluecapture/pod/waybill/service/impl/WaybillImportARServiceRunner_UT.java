package com.monsanto.brazilvaluecapture.pod.waybill.service.impl;

import com.monsanto.brazilvaluecapture.core.foundation.model.bean.SystemParameter;
import com.monsanto.brazilvaluecapture.core.foundation.model.bean.SystemParameterValue;
import com.monsanto.brazilvaluecapture.core.foundation.model.bean.TypeParameter;
import com.monsanto.brazilvaluecapture.core.foundation.service.EntityAlreadyExistException;
import com.monsanto.brazilvaluecapture.core.foundation.service.SystemParameterService;
import com.monsanto.brazilvaluecapture.core.regionalization.VCCountry;
import com.monsanto.brazilvaluecapture.osb.its.api.LASVCWaybillExportARService;
import com.monsanto.brazilvaluecapture.osb.its.waybillexportar.bean.Bulk;
import com.monsanto.brazilvaluecapture.osb.its.waybillexportar.bean.Response;
import com.monsanto.brazilvaluecapture.osb.its.waybillexportar.bean.Waybill;
import com.monsanto.brazilvaluecapture.pod.waybill.model.bean.IncomingWaybill;
import com.monsanto.brazilvaluecapture.pod.waybill.service.IncomingWaybillService;
import org.apache.commons.lang3.StringUtils;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

//To run from IDE set VM parameters: -Dlsi.function=win -DMONCRYPTJV=c:/moncryptjv
public class WaybillImportARServiceRunner_UT {

    private static final String COUNTRY_CODE = "AR";
    private static final String FROM_ID = "15";

    @Mock
    private SystemParameterService systemParameterService;
    @Mock
    private IncomingWaybillService incomingWaybillService;
    @Mock
    private LASVCWaybillExportARService lasvcWaybillExportARService;
    @InjectMocks
    private WaybillImportARServiceRunner service;

    @Before
    public void setUp() throws Exception {
        service = new WaybillImportARServiceRunner();
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void getLoggerSucceeds() {
        assertNotNull(service.getLogger());
    }

    @Test
    public void getCountrySucceeds() {
        assertEquals(VCCountry.ARGENTINA, service.getCountry());
    }

    @Test
    public void doRunSucceeds() throws Exception {
        SystemParameterValue systemParameterValue = new SystemParameterValue(TypeParameter.INTEGER, FROM_ID);
        SystemParameter systemParameter = new SystemParameter("NAME", systemParameterValue);
        when(systemParameterService.selectParameterByGroupAndNameAndCountryCode(anyString(), anyString(), eq(COUNTRY_CODE)))
                .thenReturn(systemParameter);
        Bulk bulk = new Bulk();
        bulk.setId(16);
        bulk.getWaybill().add(new Waybill());
        bulk.getWaybill().add(new Waybill());
        bulk.getWaybill().add(new Waybill());
        Response response = new Response();
        response.setHasMore(true);
        response.getBulk().add(bulk);
        when(lasvcWaybillExportARService.exportWaybills(Long.parseLong(FROM_ID))).thenReturn(response);
        doNothing().doThrow(new EntityAlreadyExistException("A")).doThrow(new RuntimeException())
                .when(incomingWaybillService).save(any(IncomingWaybill.class));

        service.doRun();

        assertTrue(service.getStatus());
        assertEquals(FROM_ID, service.getRequest().get("fromId"));
        assertEquals("[16]", service.getResponse().get("bulkIds"));
        assertEquals("true", service.getResponse().get("hasMore"));
        assertEquals("16", systemParameter.getSystemParameterValue().getValue());
        verify(lasvcWaybillExportARService).exportWaybills(Long.parseLong(FROM_ID));
        verify(incomingWaybillService, times(3)).save((IncomingWaybill) any());
        verify(systemParameterService).save(systemParameter);
    }

    @Test
    public void doRunWithNoWaybillsSucceeds() throws Exception {
        SystemParameterValue systemParameterValue = new SystemParameterValue(TypeParameter.INTEGER, FROM_ID);
        SystemParameter systemParameter = new SystemParameter("NAME", systemParameterValue);
        when(systemParameterService.selectParameterByGroupAndNameAndCountryCode(anyString(), anyString(), eq(COUNTRY_CODE)))
                .thenReturn(systemParameter);
        Bulk bulk = new Bulk();
        bulk.setId(16);
        Response response = new Response();
        response.setHasMore(false);
        response.getBulk().add(bulk);
        when(lasvcWaybillExportARService.exportWaybills(Long.parseLong(FROM_ID))).thenReturn(response);

        service.doRun();

        assertTrue(service.getStatus());
        assertEquals(FROM_ID, service.getRequest().get("fromId"));
        assertEquals("[16]", service.getResponse().get("bulkIds"));
        assertEquals("false", service.getResponse().get("hasMore"));
        assertEquals("16", systemParameter.getSystemParameterValue().getValue());
        verify(lasvcWaybillExportARService).exportWaybills(Long.parseLong(FROM_ID));
        verifyZeroInteractions(incomingWaybillService);
        verify(systemParameterService).save(systemParameter);
    }

    @Test
    public void doRunWithNoBulksSucceeds() throws Exception {
        SystemParameterValue systemParameterValue = new SystemParameterValue(TypeParameter.INTEGER, FROM_ID);
        SystemParameter systemParameter = new SystemParameter("NAME", systemParameterValue);
        when(systemParameterService.selectParameterByGroupAndNameAndCountryCode(anyString(), anyString(), eq(COUNTRY_CODE)))
                .thenReturn(systemParameter);
        Response response = new Response();
        response.setHasMore(false);
        when(lasvcWaybillExportARService.exportWaybills(Long.parseLong(FROM_ID))).thenReturn(response);

        service.doRun();

        assertTrue(service.getStatus());
        assertEquals(FROM_ID, service.getRequest().get("fromId"));
        assertEquals("[]", service.getResponse().get("bulkIds"));
        assertEquals("false", service.getResponse().get("hasMore"));
        verify(lasvcWaybillExportARService).exportWaybills(Long.parseLong(FROM_ID));
        verifyZeroInteractions(incomingWaybillService);
        verify(systemParameterService, times(0)).save(any(SystemParameter.class));
    }

    @Test
    public void doRunSetsStatusToFalseOnException() {
        Exception exception = new RuntimeException("Opss");
        when(systemParameterService.selectParameterByGroupAndNameAndCountryCode(anyString(), anyString(), eq(COUNTRY_CODE)))
                .thenThrow(exception);

        try {
            service.doRun();
            fail();

        } catch (Exception ex) {
            assertEquals(exception, ex);
            assertFalse(service.getStatus());
            assertEquals("java.lang.RuntimeException", service.getResponse().get("ERROR_EXCEPTION"));
            assertNotNull("Opss", service.getResponse().get("ERROR_EXCEPTION_MESSAGE"));
        }
    }


    public static void main(String args[]) {
       String a="11111111111111111111111111111111111111111";
        System.out.println("Abc "+a.length()+"-"+a);
       a=StringUtils.substring(a, 0, 40) ;

       System.out.println("Abc "+a.length()+"-"+a);



    }


}