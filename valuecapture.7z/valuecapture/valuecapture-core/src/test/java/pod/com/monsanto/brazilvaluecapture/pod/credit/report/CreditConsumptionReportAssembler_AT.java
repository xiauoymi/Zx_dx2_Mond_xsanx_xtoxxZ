package com.monsanto.brazilvaluecapture.pod.credit.report;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.math.BigDecimal;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

import org.junit.Assert;
import org.junit.Test;

import com.csvreader.CsvReader;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Address;
import com.monsanto.brazilvaluecapture.core.base.model.bean.City;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Company;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Country;
import com.monsanto.brazilvaluecapture.core.base.model.bean.CreditConsumption;
import com.monsanto.brazilvaluecapture.core.base.model.bean.CreditConsumptionItem;
import com.monsanto.brazilvaluecapture.core.base.model.bean.CreditConsumptionStatus;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Crop;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Document;
import com.monsanto.brazilvaluecapture.core.base.model.bean.DocumentType;
import com.monsanto.brazilvaluecapture.core.base.model.bean.OperationalYear;
import com.monsanto.brazilvaluecapture.core.base.model.bean.State;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Customer;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.HeadOffice;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.ParticipantTypeEnum;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Technology;
import com.monsanto.brazilvaluecapture.core.foundation.test.AbstractServiceIntegrationTests;
import com.monsanto.brazilvaluecapture.core.foundation.util.report.ReportUtilAssert;
import com.monsanto.brazilvaluecapture.core.grower.model.bean.Grower;

public class CreditConsumptionReportAssembler_AT extends AbstractServiceIntegrationTests {

    private ResourceBundle resourceBundle = ResourceBundle.getBundle("bundle/bundle");

    @Test
    public void sanity_test() throws IOException, NoSuchMethodException {
        CreditConsumptionReportAssembler reportAssembler = new CreditConsumptionReportAssembler(
                new ArrayList<CreditConsumptionItem>(), resourceBundle);
        ByteArrayOutputStream baos = reportAssembler.build(resourceBundle);
        Assert.assertNotNull(baos);

        validateHeader(baos);
    }

    private void validateHeader(ByteArrayOutputStream outputStream) throws IOException {

        ReportUtilAssert.assertEqualsCell(outputStream, 0, 0, 0,
                resourceBundle.getString("label.credit.consumption.report.id"));
        ReportUtilAssert.assertEqualsCell(outputStream, 0, 0, 1,
                resourceBundle.getString("label.credit.consumption.report.status"));
        ReportUtilAssert.assertEqualsCell(outputStream, 0, 0, 2,
                resourceBundle.getString("label.credit.consumption.report.company"));
        ReportUtilAssert.assertEqualsCell(outputStream, 0, 0, 3,
                resourceBundle.getString("label.credit.consumption.report.crop"));
        ReportUtilAssert.assertEqualsCell(outputStream, 0, 0, 4,
                resourceBundle.getString("label.credit.consumption.report.costumersapcode"));
        ReportUtilAssert.assertEqualsCell(outputStream, 0, 0, 5,
                resourceBundle.getString("label.credit.consumption.report.customerdocument"));
        ReportUtilAssert.assertEqualsCell(outputStream, 0, 0, 6,
                resourceBundle.getString("label.credit.consumption.report.costumername"));
        ReportUtilAssert.assertEqualsCell(outputStream, 0, 0, 7,
                resourceBundle.getString("label.credit.consumption.report.customercity"));
        ReportUtilAssert.assertEqualsCell(outputStream, 0, 0, 8,
                resourceBundle.getString("label.credit.consumption.report.customerstate"));
        ReportUtilAssert.assertEqualsCell(outputStream, 0, 0, 9,
                resourceBundle.getString("label.credit.consumption.report.customerunit"));
        ReportUtilAssert.assertEqualsCell(outputStream, 0, 0, 10,
                resourceBundle.getString("label.credit.consumption.report.customerregion"));
        ReportUtilAssert.assertEqualsCell(outputStream, 0, 0, 11,
                resourceBundle.getString("label.credit.consumption.report.customerdistrict"));
        ReportUtilAssert.assertEqualsCell(outputStream, 0, 0, 12,
                resourceBundle.getString("label.credit.consumption.report.matrixsapcode"));
        ReportUtilAssert.assertEqualsCell(outputStream, 0, 0, 13,
                resourceBundle.getString("label.credit.consumption.report.matrixcontract"));
        ReportUtilAssert.assertEqualsCell(outputStream, 0, 0, 14,
                resourceBundle.getString("label.credit.consumption.report.matrixdocument"));
        ReportUtilAssert.assertEqualsCell(outputStream, 0, 0, 15,
                resourceBundle.getString("label.credit.consumption.report.matrixname"));
        ReportUtilAssert.assertEqualsCell(outputStream, 0, 0, 16,
                resourceBundle.getString("label.credit.consumption.report.matrixunit"));
        ReportUtilAssert.assertEqualsCell(outputStream, 0, 0, 17,
                resourceBundle.getString("label.credit.consumption.report.matrixregion"));
        ReportUtilAssert.assertEqualsCell(outputStream, 0, 0, 18,
                resourceBundle.getString("label.credit.consumption.report.matrixdistrict"));
        ReportUtilAssert.assertEqualsCell(outputStream, 0, 0, 19,
                resourceBundle.getString("label.credit.consumption.report.growerdocument"));
        ReportUtilAssert.assertEqualsCell(outputStream, 0, 0, 20,
                resourceBundle.getString("label.credit.consumption.report.growername"));
        ReportUtilAssert.assertEqualsCell(outputStream, 0, 0, 21,
                resourceBundle.getString("label.credit.consumption.report.growercity"));
        ReportUtilAssert.assertEqualsCell(outputStream, 0, 0, 22,
                resourceBundle.getString("label.credit.consumption.report.growerstate"));
        ReportUtilAssert.assertEqualsCell(outputStream, 0, 0, 23,
                resourceBundle.getString("label.credit.consumption.report.createdate"));
        ReportUtilAssert.assertEqualsCell(outputStream, 0, 0, 24,
                resourceBundle.getString("label.credit.consumption.report.technology"));
        ReportUtilAssert.assertEqualsCell(outputStream, 0, 0, 25,
                resourceBundle.getString("label.credit.consumption.report.operationalyear"));
        ReportUtilAssert.assertEqualsCell(outputStream, 0, 0, 26,
                resourceBundle.getString("label.credit.consumption.report.volume"));
        ReportUtilAssert.assertEqualsCell(outputStream, 0, 0, 27,
                resourceBundle.getString("label.credit.consumption.report.creditconsumptionuser"));
        ReportUtilAssert.assertEqualsCell(outputStream, 0, 0, 28,
                resourceBundle.getString("label.credit.consumption.report.originalid"));
        ReportUtilAssert.assertEqualsCell(outputStream, 0, 0, 29,
                resourceBundle.getString("label.credit.consumption.report.returnuser"));
        ReportUtilAssert.assertEqualsCell(outputStream, 0, 0, 30,
                resourceBundle.getString("label.credit.consumption.report.returndate"));

    }

    /**
     * Test csv generate report.
     * 
     * @throws NoSuchMethodException
     * @throws IOException
     */
    @Test
    public void generate_csv_type_report() throws NoSuchMethodException, IOException {

        Country country = new Country("usa", "usa");

        State state = new State(country, "florida", "fl");
        City city = new City("x", state);

        Address address = new Address("", city, state, country, "1000");

        Customer customer = new Customer("jose", new Document(new DocumentType("cnpj", country, "999"), "123"),
                address, "x1");

        Company company = new Company("msto");
        Crop crop = new Crop("soya", company, country);

        CreditConsumption creditConsumption = new CreditConsumption();
        creditConsumption.setHeadoffice(new HeadOffice(customer, customer, ParticipantTypeEnum.POD, crop, company));
        creditConsumption.setCreditConsumptionStatus(CreditConsumptionStatus.OPENED);

        Technology tech = new Technology("rr", company);

        OperationalYear operationalYear = new OperationalYear("2000");

        Grower grower = new Grower(new Document(new DocumentType("cnpj", country, "999"), "444"), "maria", "ma",
                "mr@gmail.com", null, null);

        CreditConsumptionItem item = new CreditConsumptionItem();
        item.setBalance(BigDecimal.ONE);
        item.setCorrectionValue(BigDecimal.ONE);
        item.setCreditConsumption(creditConsumption);
        item.setCrop(crop);
        item.setGrower(grower);
        item.setTechnology(tech);
        item.setOperationalYear(operationalYear);

        // Build a big overflow credit item list.
        List<CreditConsumptionItem> creditItens = new ArrayList<CreditConsumptionItem>();
        for (int i = 0; i < 30000; i++) {
            creditItens.add(item);
        }

        // Create assembler
        CreditConsumptionReportAssembler reportAssembler = new CreditConsumptionReportAssembler(creditItens,
                resourceBundle);

        Assert.assertFalse("Expected report type like .csv", reportAssembler.isXlsReportType());

        // Build report
        ByteArrayOutputStream baos = reportAssembler.build(resourceBundle);
        Assert.assertNotNull(baos);

        InputStream inputStream = new ByteArrayInputStream(baos.toByteArray());
        CsvReader csv = new CsvReader(inputStream, Charset.forName("Windows-1252"));
        csv.readHeaders();
        String[] cols = null;
        while (csv.readRecord()) {
            cols = csv.get(0).split(";");
        }
        
        Assert.assertTrue("Invalid coluns", cols.length > 1);

    }
}
