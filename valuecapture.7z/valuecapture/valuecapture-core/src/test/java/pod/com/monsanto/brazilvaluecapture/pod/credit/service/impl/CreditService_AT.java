package com.monsanto.brazilvaluecapture.pod.credit.service.impl;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.hibernate.criterion.Restrictions;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;
import org.springframework.beans.factory.annotation.Autowired;

import com.monsanto.brazilvaluecapture.core.account.model.bean.Account;
import com.monsanto.brazilvaluecapture.core.account.model.bean.Account.AccountType;
import com.monsanto.brazilvaluecapture.core.account.model.bean.Account.OwnerType;
import com.monsanto.brazilvaluecapture.core.account.model.bean.ManualCreditTransactionType;
import com.monsanto.brazilvaluecapture.core.account.service.impl.AccountNotFoundException;
import com.monsanto.brazilvaluecapture.core.account.service.impl.AccountService;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Company;
import com.monsanto.brazilvaluecapture.core.base.model.bean.CreditConsumption;
import com.monsanto.brazilvaluecapture.core.base.model.bean.CreditConsumptionItem;
import com.monsanto.brazilvaluecapture.core.base.model.bean.CreditConsumptionStatus;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Crop;
import com.monsanto.brazilvaluecapture.core.base.model.bean.DocumentType.DocumentTypeEnum;
import com.monsanto.brazilvaluecapture.core.base.model.bean.OperationalYear;
import com.monsanto.brazilvaluecapture.core.base.model.dao.TechnologyDAO;
import com.monsanto.brazilvaluecapture.core.base.service.BaseService;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Contract;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Customer;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.HeadOffice;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.ParticipantTypeEnum;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Technology;
import com.monsanto.brazilvaluecapture.core.customer.model.dao.CustomerDAO;
import com.monsanto.brazilvaluecapture.core.customer.service.AffiliateNotInVigorException;
import com.monsanto.brazilvaluecapture.core.customer.service.ContractNotFoundException;
import com.monsanto.brazilvaluecapture.core.customer.service.ContractService;
import com.monsanto.brazilvaluecapture.core.customer.service.CustomerNotAllowedException;
import com.monsanto.brazilvaluecapture.core.customer.service.CustomerNotFoundException;
import com.monsanto.brazilvaluecapture.core.customer.service.ParticipantService;
import com.monsanto.brazilvaluecapture.core.foundation.service.BusinessException;
import com.monsanto.brazilvaluecapture.core.foundation.service.EntityNotFoundException;
import com.monsanto.brazilvaluecapture.core.foundation.test.AbstractServiceIntegrationTests;
import com.monsanto.brazilvaluecapture.core.foundation.test.dbunit.DbUnitHelper;
import com.monsanto.brazilvaluecapture.core.foundation.util.CalendarUtil;
import com.monsanto.brazilvaluecapture.core.foundation.util.ConstraintViolation;
import com.monsanto.brazilvaluecapture.core.grower.model.bean.Grower;
import com.monsanto.brazilvaluecapture.core.grower.model.dao.GrowerDAO;
import com.monsanto.brazilvaluecapture.core.grower.service.GrowerNotFoundException;
import com.monsanto.brazilvaluecapture.core.importfile.model.ImportFileType;
import com.monsanto.brazilvaluecapture.core.importfile.model.bean.CsvImportFile;
import com.monsanto.brazilvaluecapture.core.user.model.bean.ItsUserDTO;
import com.monsanto.brazilvaluecapture.core.user.model.bean.UserContract;
import com.monsanto.brazilvaluecapture.core.user.model.bean.UserDecorator;
import com.monsanto.brazilvaluecapture.core.user.service.DocumentMismatchException;
import com.monsanto.brazilvaluecapture.core.user.service.ManualCreditConstraintException;
import com.monsanto.brazilvaluecapture.core.user.service.UserNotFoundException;
import com.monsanto.brazilvaluecapture.core.user.service.UserService;
import com.monsanto.brazilvaluecapture.pod.credit.model.bean.CreditConsumptionImportDTO;
import com.monsanto.brazilvaluecapture.pod.credit.model.bean.CreditConsumptionItemDTO;
import com.monsanto.brazilvaluecapture.pod.credit.model.bean.CreditConsumptionListDTO;
import com.monsanto.brazilvaluecapture.pod.credit.model.bean.CsvCreditConsumptionImportLine;
import com.monsanto.brazilvaluecapture.pod.credit.model.bean.CsvCreditConsumptionImportResult;
import com.monsanto.brazilvaluecapture.pod.credit.model.dao.CreditDAO;
import com.monsanto.brazilvaluecapture.pod.credit.service.CreditConsumptionConstraintException;
import com.monsanto.brazilvaluecapture.pod.credit.service.CreditConsumptionException;
import com.monsanto.brazilvaluecapture.pod.credit.service.CreditConsumptionFilter;
import com.monsanto.brazilvaluecapture.pod.credit.service.CreditConsumptionNotFoundException;
import com.monsanto.brazilvaluecapture.pod.credit.service.CreditService;
import com.monsanto.brazilvaluecapture.pod.rol.model.bean.HeadOfficeDetail;
import com.monsanto.brazilvaluecapture.pod.rol.model.bean.HeadOfficeEffectiveDate;
import com.monsanto.brazilvaluecapture.pod.rol.model.bean.ReportOnLine;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.ImportFileStatus;

/**
 * @author cmiranda
 * 
 */
public class CreditService_AT extends AbstractServiceIntegrationTests {

    @Autowired
    private GrowerDAO growerDAO;

    @Autowired
    private CreditDAO creditDAO;

    @Autowired
    private CustomerDAO customerDAO;

    @Autowired
    private CreditService creditService;

    @Autowired
    private ContractService contractService;

    @Autowired
    private AccountService accountService;

    @Autowired
    private UserService userService;

    @Autowired
    private ParticipantService participantService;

    @Autowired
    private BaseService baseService;

    @Autowired
    private TechnologyDAO technologyDAO;

    // Credit consumption for test
    private CreditConsumption creditConsumption;

    // Create soja crop
    private Crop cropSoja;

    // Grower
    private Grower growerZe;

    // Grower
    private Grower growerMaria;

    // Grower
    private Grower growerAntonia;

    // Grower
    private Grower growerPedro;

    // Grower
    private Grower growerJoao;

    // Accounts for ze and soja
    private List<Account> accountsZeSoja;

    // Customer for consumption
    private Customer customer;

    private UserDecorator loggedUser;

    private List<UserContract> listUserContract;

    private int accountsZeSojaSizeBeforeConsumption;

    private Account accountBeforeOperation;

    @Before
    public void setup() {

        // Create a credit consumption
        creditConsumption = new CreditConsumption();
        creditConsumption.setCorrectionDate(new Date());
        creditConsumption.setCorrectionItsUserLogin("cmiranda");
        creditConsumption.setCreditConsumptionItens(new HashSet<CreditConsumptionItem>());
        creditConsumption.setCreditConsumptionStatus(CreditConsumptionStatus.OPENED);
        creditConsumption.setHeadoffice(null);
        creditConsumption.setOriginalCreditConsumption(null);
        creditConsumption.setReversalDate(null);
        creditConsumption.setReversalItsUserLogin(null);
        creditConsumption.setReversalReasonDesc(null);

    }

    public void setupDBUnit(boolean considerCsv) throws GrowerNotFoundException, UserNotFoundException,
            CustomerNotFoundException, CustomerNotAllowedException {

        if (considerCsv) {
            // Load dbunit
            DbUnitHelper.setup("classpath:data/pod/credit/credit-consumption-csv-dataset.xml",
                    "classpath:data/pod/credit/credit-consumption-2-dataset.xml");
        } else {
            // Load dbunit
            DbUnitHelper.setup("classpath:data/pod/credit/credit-consumption-dataset.xml",
                    "classpath:data/pod/credit/credit-consumption-2-dataset.xml");
        }

        // Create soja crop
        cropSoja = (Crop) getSession().get(Crop.class, new Long("900000001"));

        // Get Ze grower
        growerZe = growerDAO.selectBy("1", false);

        // Get Maria grower
        growerMaria = growerDAO.selectBy("2", false);

        // Get Antonia grower
        growerAntonia = growerDAO.selectBy("4", false);

        // Get Pedro grower
        growerPedro = growerDAO.selectBy("8", false);

        // Get Joao grower
        growerJoao = growerDAO.selectBy("9", false);

        // Set logged user
        loggedUser = userService.getUserBy("login1");
        loggedUser.getContractsForContext();
        loggedUser.setContextCrop(cropSoja);

        // Set user contracts
        UserContract userContract = (UserContract) this.getSession().get(UserContract.class, new Long("900000003"));
        if (userContract != null) {
            this.listUserContract = new ArrayList<UserContract>();
            this.listUserContract.add(userContract);
        }

        customer = participantService.findAllowedParticipantPODByDocumentCropAndContracts("111111111", cropSoja, null,
                loggedUser.getContracts(), false, false);

        // Search accounts for grower ze and crop soja
        accountsZeSoja = accountService.getAccountsForCreditConsumption(growerZe, cropSoja, cropSoja.getCompany());

    }

    /**
     * @throws GrowerNotFoundException
     */
    @Test
    public void credit_consumption_save_without_accounts() throws GrowerNotFoundException {

        try {

            creditService.saveCreditConsumption(creditConsumption);

        } catch (CreditConsumptionConstraintException cce) {

            checkConstraintException(cce, "Credit Consumptions itens is required");

        } catch (Exception e) {
            e.printStackTrace();
            Assert.fail("Expected CreditConsumptionConstraintException, but received " + e);
        }

    }

    /**
     * @throws GrowerNotFoundException
     * @throws CustomerNotAllowedException
     * @throws CustomerNotFoundException
     * @throws UserNotFoundException
     */
    @Test
    public void credit_consumption_save_with_negative_balance_accounts() throws GrowerNotFoundException,
            UserNotFoundException, CustomerNotFoundException, CustomerNotAllowedException {

        // Initialize db unit
        setupDBUnit(false);

        try {

            Assert.assertNotNull(accountsZeSoja);
            Assert.assertFalse("Expected accounts for grower ze and crop soja.", accountsZeSoja.isEmpty());

            // Get first account
            Account account = accountsZeSoja.get(0);

            // Create item
            CreditConsumptionItem item = new CreditConsumptionItem(null, null, new BigDecimal("-1"),
                    account.getTechnology(), account.getOperationalYear(), account.getCrop(),
                    baseService.selectGrowerByID(account.getOwnerCode()), account.getBalance());

            // insert item in credit consumption
            creditConsumption.getCreditConsumptionItens().add(item);
            creditService.saveCreditConsumption(creditConsumption);

        } catch (CreditConsumptionConstraintException cce) {

            checkConstraintException(cce,
                    "Requested value for credit consumption must be a positive and non zero value.");

        } catch (Exception e) {
            e.printStackTrace();
            Assert.fail("Expected CreditConsumptionConstraintException, but received " + e);
        }

    }

    /**
     * @throws GrowerNotFoundException
     * @throws CustomerNotAllowedException
     * @throws CustomerNotFoundException
     * @throws UserNotFoundException
     */
    @Test
    public void credit_consumption_save_with_zero_balance_accounts() throws GrowerNotFoundException,
            UserNotFoundException, CustomerNotFoundException, CustomerNotAllowedException {

        // Initialize db unit
        setupDBUnit(false);

        try {

            Assert.assertNotNull(accountsZeSoja);
            Assert.assertFalse("Expected accounts for grower ze and crop soja.", accountsZeSoja.isEmpty());

            // Get first account
            Account account = accountsZeSoja.get(0);

            CreditConsumptionItem item = new CreditConsumptionItem(null, null, BigDecimal.ZERO,
                    account.getTechnology(), account.getOperationalYear(), account.getCrop(),
                    baseService.selectGrowerByID(account.getOwnerCode()), account.getBalance());

            // insert item in credit consumption
            creditConsumption.getCreditConsumptionItens().add(item);

            creditService.saveCreditConsumption(creditConsumption);

        } catch (CreditConsumptionConstraintException cce) {

            checkConstraintException(cce,
                    "Requested value for credit consumption must be a positive and non zero value.");

        } catch (Exception e) {
            e.printStackTrace();
            Assert.fail("Expected CreditConsumptionConstraintException, but received " + e);
        }

    }

    /**
     * @throws GrowerNotFoundException
     * @throws CustomerNotAllowedException
     * @throws CustomerNotFoundException
     * @throws UserNotFoundException
     */
    @Test
    public void credit_consumption_save_with_blocked_accounts() throws GrowerNotFoundException, UserNotFoundException,
            CustomerNotFoundException, CustomerNotAllowedException {

        // Initialize db unit
        setupDBUnit(false);

        try {

            growerZe = growerDAO.selectBy("6", false);

            // Create soja crop
            Crop cropBlockedMilho = (Crop) getSession().get(Crop.class, new Long("900000004"));

            // Search blocked accounts
            List<Account> blockedAccounts = accountService.getAccountsByGrowerAndCropAndTypeAndOwer(growerZe,
                    cropBlockedMilho, cropSoja.getCompany(), new AccountType[] { AccountType.BLOCKED },
                    OwnerType.GROWER);

            Assert.assertNotNull(blockedAccounts);
            Assert.assertFalse("Expected accounts for grower ze and crop soja.", blockedAccounts.isEmpty());

            // Get first account
            Account account = blockedAccounts.get(0);

            CreditConsumptionItem item = new CreditConsumptionItem(null, null, BigDecimal.ZERO,
                    account.getTechnology(), account.getOperationalYear(), account.getCrop(),
                    baseService.selectGrowerByID(account.getOwnerCode()), account.getBalance());

            // insert item in credit consumption
            creditConsumption.getCreditConsumptionItens().add(item);

            creditService.saveCreditConsumption(creditConsumption);

        } catch (CreditConsumptionConstraintException cce) {

            checkConstraintException(cce, "Account is required for a credit consumption item.");

        } catch (Exception e) {
            e.printStackTrace();
            Assert.fail("Expected CreditConsumptionConstraintException, but received " + e);
        }

    }

    /**
     * @throws GrowerNotFoundException
     * @throws CustomerNotAllowedException
     * @throws CustomerNotFoundException
     * @throws UserNotFoundException
     */
    @Test
    public void credit_consumption_save_with_unusable_accounts() throws GrowerNotFoundException, UserNotFoundException,
            CustomerNotFoundException, CustomerNotAllowedException {

        // Initialize db unit
        setupDBUnit(false);

        try {

            // Search blocked accounts
            List<Account> blockedAccounts = accountService.getAccountsByGrowerAndCropAndTypeAndOwer(growerZe, cropSoja,
                    cropSoja.getCompany(), new AccountType[] { AccountType.UNUSABLE }, OwnerType.GROWER);

            Assert.assertNotNull(blockedAccounts);
            Assert.assertFalse("Expected accounts for grower ze and crop soja.", blockedAccounts.isEmpty());

            // Get first account
            Account account = blockedAccounts.get(0);

            CreditConsumptionItem item = new CreditConsumptionItem(null, null, BigDecimal.ZERO,
                    account.getTechnology(), account.getOperationalYear(), account.getCrop(),
                    baseService.selectGrowerByID(account.getOwnerCode()), account.getBalance());

            // insert item in credit consumption
            creditConsumption.getCreditConsumptionItens().add(item);

            creditService.saveCreditConsumption(creditConsumption);

        } catch (CreditConsumptionConstraintException cce) {

            checkConstraintException(cce, "Account is required for a credit consumption item.");

        } catch (Exception e) {
            e.printStackTrace();
            Assert.fail("Expected CreditConsumptionConstraintException, but received " + e);
        }

    }

    /**
     * @throws GrowerNotFoundException
     * @throws CustomerNotAllowedException
     * @throws CustomerNotFoundException
     * @throws UserNotFoundException
     */
    @Test
    public void credit_consumption_save_with_greate_consumption_than_credit_balance() throws GrowerNotFoundException,
            UserNotFoundException, CustomerNotFoundException, CustomerNotAllowedException {

        // Initialize db unit
        setupDBUnit(false);

        try {

            Assert.assertNotNull(accountsZeSoja);
            Assert.assertFalse("Expected accounts for grower ze and crop soja.", accountsZeSoja.isEmpty());

            // Get first account
            Account account = accountsZeSoja.get(0);

            CreditConsumptionItem item = new CreditConsumptionItem(null, creditConsumption, BigDecimal.ZERO,
                    account.getTechnology(), account.getOperationalYear(), account.getCrop(),
                    baseService.selectGrowerByID(account.getOwnerCode()), account.getBalance());
            item.setRequestValue(account.getBalance().add(BigDecimal.valueOf(1)));

            // insert item in credit consumption
            creditConsumption.getCreditConsumptionItens().add(item);

            creditService.saveCreditConsumption(creditConsumption);

        } catch (CreditConsumptionConstraintException cce) {

            checkConstraintException(cce,
                    "Requested value for credit consumption must be less or equals available credit in account.");

        } catch (Exception e) {
            e.printStackTrace();
            Assert.fail("Expected CreditConsumptionConstraintException, but received " + e);
        }

    }

    /**
     * @throws GrowerNotFoundException
     */
    @Test
    public void credit_consumption_save_with_null_account() throws GrowerNotFoundException {

        try {

            CreditConsumptionItem item = new CreditConsumptionItem();
            item.setCreditConsumption(creditConsumption);

            // insert item in credit consumption
            creditConsumption.getCreditConsumptionItens().add(item);

            creditService.saveCreditConsumption(creditConsumption);

        } catch (CreditConsumptionConstraintException cce) {

            checkConstraintException(cce, "Account is required for a credit consumption item.");

        } catch (Exception e) {
            e.printStackTrace();
            Assert.fail("Expected CreditConsumptionConstraintException, but received " + e);
        }

    }

    /**
     * @throws GrowerNotFoundException
     */
    @Test
    public void credit_consumption_save_with_fake_account() throws Exception {

        try {
            // Create a fake account
            Account account = new Account(AccountType.AVAILABLE, OwnerType.GROWER, 99999999999999L, null, null, null);

            CreditConsumptionItem item = new CreditConsumptionItem(null, creditConsumption, BigDecimal.ZERO,
                    account.getTechnology(), account.getOperationalYear(), account.getCrop(),
                    baseService.selectGrowerByID(account.getOwnerCode()), account.getBalance());

            // insert item in credit consumption
            creditConsumption.getCreditConsumptionItens().add(item);

            creditService.saveCreditConsumption(creditConsumption);

        } catch (CreditConsumptionConstraintException cce) {

            checkConstraintException(cce, "Account is required for a credit consumption item.");

        } catch (Exception e) {
            e.printStackTrace();
            Assert.fail("Expected CreditConsumptionConstraintException, but received " + e);
        }

    }

    /**
     * @throws GrowerNotFoundException
     */
    @Test
    public void credit_consumption_save_with_null_requested_value() throws GrowerNotFoundException {

        try {

            CreditConsumptionItem item = new CreditConsumptionItem();
            item.setRequestValue(null);
            item.setCreditConsumption(creditConsumption);

            // insert item in credit consumption
            creditConsumption.getCreditConsumptionItens().add(item);

            creditService.saveCreditConsumption(creditConsumption);

        } catch (CreditConsumptionConstraintException cce) {

            checkConstraintException(cce, "Requested value is required.");

        } catch (Exception e) {
            e.printStackTrace();
            Assert.fail("Expected CreditConsumptionConstraintException, but received " + e);
        }

    }

    /**
     * @throws GrowerNotFoundException
     */
    @Test
    public void credit_consumption_save_with_null_itens() throws GrowerNotFoundException {

        try {

            creditConsumption.setCreditConsumptionItens(null);
            creditService.saveCreditConsumption(creditConsumption);

        } catch (CreditConsumptionConstraintException cce) {

            checkConstraintException(cce, "Credit Consumptions itens is required");

        } catch (Exception e) {
            e.printStackTrace();
            Assert.fail("Expected CreditConsumptionConstraintException, but received " + e);
        }

    }

    /**
     * @throws GrowerNotFoundException
     */
    @Test
    public void credit_consumption_save_without_headoffice() throws GrowerNotFoundException {

        try {

            creditConsumption.setHeadoffice(null);
            creditService.saveCreditConsumption(creditConsumption);

        } catch (CreditConsumptionConstraintException cce) {

            checkConstraintException(cce, "Head Office is required");

        } catch (Exception e) {
            e.printStackTrace();
            Assert.fail("Expected CreditConsumptionConstraintException, but received " + e);
        }

    }

    /**
     * @throws GrowerNotFoundException
     */
    @Test
    public void credit_consumption_save_without_its_user() throws GrowerNotFoundException {

        try {

            creditConsumption.setItsUserLogin(null);
            creditService.saveCreditConsumption(creditConsumption);

        } catch (CreditConsumptionConstraintException cce) {

            checkConstraintException(cce, "Its user is required");

        } catch (Exception e) {
            e.printStackTrace();
            Assert.fail("Expected CreditConsumptionConstraintException, but received " + e);
        }

    }

    /**
     * Testing a searching with just one headoffice and date range: July, 1st,
     * 2012 to August, 1st, 2012
     * 
     * @throws GrowerNotFoundException
     * @throws CustomerNotFoundException
     * @throws UserNotFoundException
     * @throws CustomerNotAllowedException
     * @throws CreditConsumptionException
     * @throws DocumentMismatchException
     */
    @Test
    public void search_creditCconsumptionList_by_headoffice() throws GrowerNotFoundException,
            CustomerNotFoundException, UserNotFoundException, CustomerNotAllowedException, CreditConsumptionException,
            DocumentMismatchException {
        // Initialize db unit
        setupDBUnit(false);

        Customer cust = customerDAO.selectBy("111111111", null, ParticipantTypeEnum.POD);
        // getting the headoffice(900000001) from this customer
        Iterator<HeadOffice> iter = cust.getHeadOffices().iterator();
        HeadOffice ho = null;
        while (iter.hasNext()) {
            ho = (HeadOffice) iter.next();
            if (ho.getMatrix().getId().equals(new Long(900000002))) {
                break;
            }
        }

        CreditConsumptionFilter ccFilter = new CreditConsumptionFilter();
        ccFilter.setMatrix(ho.getMatrix());
        // get init date
        setInitOrEndDate_CreditConsumptionFilter(true, ccFilter, 2012, 6, 1); // July,
                                                                              // 1st,
                                                                              // 2012
        // get end date
        setInitOrEndDate_CreditConsumptionFilter(false, ccFilter, 2012, 7, 1); // August,
                                                                               // 1st,
                                                                               // 2012

        List<CreditConsumption> creditConList = creditService.selectCreditConsumptionListByFilter(ccFilter);
        Assert.assertEquals(2, creditConList.size());

        // CreditConsumption creditCon = creditConList.get(0);
        // Make sure the unique item in the list is the 900000001
        // Assert.assertTrue(creditCon.getId().longValue() == 900000002);

    }

    /**
     * Testing a searching with just one headoffice and date range: June, 1st,
     * 2012 to July, 1st, 2012 and status "opened"
     * 
     * @throws GrowerNotFoundException
     * @throws CustomerNotFoundException
     * @throws UserNotFoundException
     * @throws CustomerNotAllowedException
     * @throws CreditConsumptionException
     * @throws DocumentMismatchException
     * @throws ContractNotFoundException
     */
    @Test
    public void search_creditCconsumptionItemList_by_headoffice_status_opened() throws GrowerNotFoundException,
            CustomerNotFoundException, UserNotFoundException, CustomerNotAllowedException, CreditConsumptionException,
            DocumentMismatchException, ContractNotFoundException {
        // Initialize db unit
        DbUnitHelper.setup("classpath:data/core/fixture-system-dataset.xml",
                "classpath:data/core/production_fix-CAV-2299-dataset.xml");

        // Get the customer
        Customer cust = (Customer) getSession().get(Customer.class, 900000001L);

        Crop crop = (Crop) getSession().get(Crop.class, 900000001L);

        Company company = (Company) getSession().get(Company.class, 900000001L);

        // getting the headoffice(900000001) from this customer
        Iterator<HeadOffice> iter = cust.getHeadOffices().iterator();
        HeadOffice ho = null;
        while (iter.hasNext()) {
            ho = (HeadOffice) iter.next();
            if (ho.getMatrix().getId().equals(new Long(900000003))) {
                break;
            }
        }

        // Get the technologies
        List<Technology> lstTechnologies = technologyDAO.selectAllTechnology(ho.getCompany());

        CreditConsumptionFilter ccFilter = new CreditConsumptionFilter();
        // technologies
        ccFilter.setTechnologies(lstTechnologies);
        // company
        ccFilter.setCompany(company);
        // crop
        ccFilter.setCrop(crop);
        // get init date
        setInitOrEndDate_CreditConsumptionFilter(true, ccFilter, 2012, 6, 1); // June,
                                                                              // 1st,
                                                                              // 2012
        // get end date
        setInitOrEndDate_CreditConsumptionFilter(false, ccFilter, 2012, 6, 1); // July,
                                                                               // 1st,
                                                                               // 2012
        // status "opened"
        List<CreditConsumptionStatus> status = new ArrayList<CreditConsumptionStatus>();
        status.add(CreditConsumptionStatus.OPENED);
        ccFilter.setStatus(status);

        List<CreditConsumptionItem> creditConList = creditService.selectCreditConsumptionItemListByFilter(ccFilter);
        Assert.assertEquals(0, creditConList.size());
    }

    /**
     * Testing a searching with just one headoffice and date range: June, 1st,
     * 2012 to July, 1st, 2012 and status "corrected" and "reversed"
     * 
     * @throws GrowerNotFoundException
     * @throws CustomerNotFoundException
     * @throws UserNotFoundException
     * @throws CustomerNotAllowedException
     * @throws CreditConsumptionException
     * @throws DocumentMismatchException
     * @throws ContractNotFoundException
     */
    @Test
    public void search_creditCconsumptionItemList_by_headoffice_status_corrected_reversed()
            throws GrowerNotFoundException, CustomerNotFoundException, UserNotFoundException,
            CustomerNotAllowedException, CreditConsumptionException, DocumentMismatchException,
            ContractNotFoundException {
        // Initialize db unit
        DbUnitHelper.setup("classpath:data/core/fixture-system-dataset.xml",
                "classpath:data/core/production_fix-CAV-2299-dataset.xml");

        // Get the grower
        Grower grower = new Grower();
        grower.setId(new Long("900000001"));

        Assert.assertNotNull("Grower 900000001 MUST exists!", grower);

        // Get the customer
        Customer cust = (Customer) getSession().get(Customer.class, 900000001L);

        Crop crop = (Crop) getSession().get(Crop.class, 900000001L);

        Company company = (Company) getSession().get(Company.class, 900000001L);

        // getting the headoffice(900000001) from this customer
        Iterator<HeadOffice> iter = cust.getHeadOffices().iterator();
        HeadOffice ho = null;
        while (iter.hasNext()) {
            ho = (HeadOffice) iter.next();
            if (ho.getMatrix().getId().equals(new Long(900000003))) {
                break;
            }
        }

        CreditConsumptionFilter ccFilter = new CreditConsumptionFilter();
        // grower
        ccFilter.setGrower(grower);
        // matrix
        ccFilter.setMatrix(ho.getMatrix());
        // company
        ccFilter.setCompany(company);
        // crop
        ccFilter.setCrop(crop);
        // customer
        ccFilter.setCustomer(cust);
        // user contracts
        ccFilter.setContracts(contractService.getContractsWithAffiliatesByFilter(crop, company, cust,
                ParticipantTypeEnum.POD));
        // status "corrected" and "reversed"
        List<CreditConsumptionStatus> status = new ArrayList<CreditConsumptionStatus>();
        status.add(CreditConsumptionStatus.CORRECTED);
        status.add(CreditConsumptionStatus.REVERSED);
        ccFilter.setStatus(status);

        List<CreditConsumptionItem> creditConList = creditService.selectCreditConsumptionItemListByFilter(ccFilter);
        Assert.assertEquals(0, creditConList.size());
    }

    /**
     * Testing a searching with just one headoffice and date range: June, 1st,
     * 2012 to July, 1st, 2012 and without status
     * 
     * @throws GrowerNotFoundException
     * @throws CustomerNotFoundException
     * @throws UserNotFoundException
     * @throws CustomerNotAllowedException
     * @throws CreditConsumptionException
     * @throws DocumentMismatchException
     * @throws ContractNotFoundException
     */
    @Test
    public void search_creditCconsumptionItemList_by_headoffice_without_status() throws GrowerNotFoundException,
            CustomerNotFoundException, UserNotFoundException, CustomerNotAllowedException, CreditConsumptionException,
            DocumentMismatchException, ContractNotFoundException {
        // Initialize db unit
        DbUnitHelper.setup("classpath:data/core/fixture-system-dataset.xml",
                "classpath:data/core/production_fix-CAV-2299-dataset.xml");

        // Get the grower
        Grower grower = new Grower();
        grower.setId(new Long("900000001"));

        Assert.assertNotNull("Grower 900000001 MUST exists!", grower);
        Crop crop = (Crop) getSession().get(Crop.class, 900000001L);

        Company company = (Company) getSession().get(Company.class, 900000001L);

        // Get the customer
        Customer cust = (Customer) getSession().get(Customer.class, 900000001L);

        // getting the headoffice(900000001) from this customer
        Iterator<HeadOffice> iter = cust.getHeadOffices().iterator();
        HeadOffice ho = null;
        while (iter.hasNext()) {
            ho = (HeadOffice) iter.next();
            if (ho.getMatrix().getId().equals(new Long(900000003))) {
                break;
            }
        }

        CreditConsumptionFilter ccFilter = new CreditConsumptionFilter();
        // grower
        ccFilter.setGrower(grower);
        // user contracts
        List<UserContract> lstUserContract = contractService.getContractsWithAffiliatesByFilter(crop, company, cust,
                ParticipantTypeEnum.POD);
        lstUserContract.clear();
        ccFilter.setContracts(lstUserContract);
        // status "corrected" and "reversed"
        List<CreditConsumptionStatus> status = new ArrayList<CreditConsumptionStatus>();
        ccFilter.setStatus(status);

        List<CreditConsumptionItem> creditConList = creditService.selectCreditConsumptionItemListByFilter(ccFilter);
        Assert.assertEquals(0, creditConList.size());
    }

    private void setInitOrEndDate_CreditConsumptionFilter(boolean init, CreditConsumptionFilter ccFilter, int year,
            int month, int day) {
        Calendar cal = Calendar.getInstance();
        cal.clear();
        cal.set(year, month - 1, day);
        Date dt = cal.getTime();
        if (init)
            ccFilter.setInitDate(dt);
        else
            ccFilter.setEndDate(dt);
    }

    @Test
    public void search_creditCconsumptionList_by_headoffice_technology_period_grower() throws GrowerNotFoundException,
            UserNotFoundException, CustomerNotFoundException, CustomerNotAllowedException, CreditConsumptionException,
            DocumentMismatchException {
        // Initialize db unit
        setupDBUnit(false);

        Customer cust = customerDAO.selectBy("111111111", null, ParticipantTypeEnum.POD);
        // getting the headoffice(900000001) from this customer
        Iterator<HeadOffice> iter = cust.getHeadOffices().iterator();
        HeadOffice ho = null;
        while (iter.hasNext()) {
            ho = (HeadOffice) iter.next();
            if (ho.getMatrix().getId().longValue() == 900000002) {
                break;
            }
        }

        CreditConsumptionFilter ccFilter = new CreditConsumptionFilter();
        ccFilter.setMatrix(ho.getMatrix());
        // technology 900000001 __INTACTA_
        Account account = accountService.getAccountById(new Long(900000009)); // account
                                                                              // that
                                                                              // has
                                                                              // __INTACTA_
                                                                              // technology
        List<Technology> techList = new ArrayList<Technology>();
        techList.add(account.getTechnology());
        ccFilter.setTechnologies(techList);
        // get init date
        setInitOrEndDate_CreditConsumptionFilter(true, ccFilter, 2012, 5, 1); // June,
                                                                              // 1st,
                                                                              // 2012
        // get end date
        setInitOrEndDate_CreditConsumptionFilter(false, ccFilter, 2012, 7, 1); // August,
                                                                               // 1st,
                                                                               // 2012

        List<CreditConsumption> creditConList = creditService.selectCreditConsumptionListByFilter(ccFilter);
        Assert.assertEquals(1, creditConList.size());

        CreditConsumption creditCon = creditConList.get(0);
        // Make sure the unique item in the list is the 900000002
        Assert.assertTrue(creditCon.getId().longValue() == 900000002);
    }

    @Test
    public void search_creditCconsumptionListDTO_by_headoffice_technology_period_grower()
            throws GrowerNotFoundException, UserNotFoundException, CustomerNotFoundException,
            CustomerNotAllowedException, CreditConsumptionException, DocumentMismatchException {
        // Initialize db unit
        setupDBUnit(false);

        Customer cust = customerDAO.selectBy("111111111", null, ParticipantTypeEnum.POD);
        // getting the headoffice(900000001) from this customer
        Iterator<HeadOffice> iter = cust.getHeadOffices().iterator();
        HeadOffice ho = null;
        while (iter.hasNext()) {
            ho = (HeadOffice) iter.next();
            if (ho.getMatrix().getId().longValue() == 900000002) {
                break;
            }
        }

        CreditConsumptionFilter ccFilter = new CreditConsumptionFilter();
        ccFilter.setMatrix(ho.getMatrix());
        // technology 900000001 __INTACTA_
        Account account = accountService.getAccountById(new Long(900000009)); // account
                                                                              // that
                                                                              // has
                                                                              // __INTACTA_
                                                                              // technology
        List<Technology> techList = new ArrayList<Technology>();
        techList.add(account.getTechnology());
        ccFilter.setTechnologies(techList);
        // get init date
        setInitOrEndDate_CreditConsumptionFilter(true, ccFilter, 2000, 5, 1); // June,
                                                                              // 1st,
                                                                              // 2012
        // get end date
        setInitOrEndDate_CreditConsumptionFilter(false, ccFilter, 2000, 7, 1); // August,
                                                                               // 1st,
                                                                               // 2012

        List<CreditConsumptionListDTO> creditDTOConList = creditService
                .selectCreditConsumptionListDtoByFilter(ccFilter);
        Assert.assertEquals(0, creditDTOConList.size());
    }

    @Test
    public void test_search_creditCconsumptionList_for_contract_date_outside_range() throws GrowerNotFoundException,
            UserNotFoundException, CustomerNotFoundException, CustomerNotAllowedException, CreditConsumptionException,
            DocumentMismatchException {
        // Initialize db unit
        setupDBUnit(false);

        Customer cust = (Customer) customerDAO.selectBy("111111111", null, ParticipantTypeEnum.POD);
        // getting the headoffice(900000001) from this customer
        Iterator<HeadOffice> iter = cust.getHeadOffices().iterator();
        HeadOffice ho = null;
        while (iter.hasNext()) {
            ho = (HeadOffice) iter.next();
            if (ho.getMatrix().getId().longValue() == 900000002) {
                break;
            }
        }
        Company company = ho.getCompany();
        Crop crop = ho.getCrop();

        CreditConsumptionFilter ccFilter = new CreditConsumptionFilter();
        ccFilter.setCompany(company);
        ccFilter.setCrop(crop);
        ccFilter.setMatrix(ho.getMatrix());
        // technology 900000001 __INTACTA_
        Account account = accountService.getAccountById(new Long(900000009)); // account
                                                                              // that
                                                                              // has
                                                                              // __INTACTA_
                                                                              // technology
        List<Technology> techList = new ArrayList<Technology>();
        techList.add(account.getTechnology());
        ccFilter.setTechnologies(techList);
        // get init date
        setInitOrEndDate_CreditConsumptionFilter(true, ccFilter, 2012, 5, 1); // June,
                                                                              // 1st,
                                                                              // 2012
        // get end date
        setInitOrEndDate_CreditConsumptionFilter(false, ccFilter, 2012, 7, 1); // August,
                                                                               // 1st,
                                                                               // 2012

        // CONSIDERING NOW THAT THE CONTRACT MUST BE IN VIGOR BASED ON THE
        // contractDate
        ccFilter.setOnlyInVigorMatrix(Boolean.TRUE);
        Date contractDate = CalendarUtil.getDate(2151, 1, 1); // date outside
                                                              // range
        ccFilter.setContractDate(contractDate);

        List<CreditConsumption> creditConList = creditService.selectCreditConsumptionListByFilter(ccFilter);
        Assert.assertEquals(0, creditConList.size());

    }

    @Test
    public void test_search_creditCconsumptionList_for_contract_date_in_range() throws GrowerNotFoundException,
            UserNotFoundException, CustomerNotFoundException, CustomerNotAllowedException, CreditConsumptionException,
            DocumentMismatchException {
        // Initialize db unit
        setupDBUnit(false);

        Customer cust = customerDAO.selectBy("111111111", null, ParticipantTypeEnum.POD);
        // getting the headoffice(900000001) from this customer
        Iterator<HeadOffice> iter = cust.getHeadOffices().iterator();
        HeadOffice ho = null;
        while (iter.hasNext()) {
            ho = (HeadOffice) iter.next();
            if (ho.getMatrix().getId().longValue() == 900000002) {
                break;
            }
        }
        Company company = ho.getCompany();
        Crop crop = ho.getCrop();

        CreditConsumptionFilter ccFilter = new CreditConsumptionFilter();
        ccFilter.setCompany(company);
        ccFilter.setCrop(crop);
        ccFilter.setMatrix(ho.getMatrix());
        ccFilter.setParticipantType(ParticipantTypeEnum.POD);
        // technology 900000001 __INTACTA_
        Account account = accountService.getAccountById(new Long(900000009)); // account
                                                                              // that
                                                                              // has
                                                                              // __INTACTA_
                                                                              // technology
        List<Technology> techList = new ArrayList<Technology>();
        techList.add(account.getTechnology());
        ccFilter.setTechnologies(techList);
        // get init date
        setInitOrEndDate_CreditConsumptionFilter(true, ccFilter, 2012, 5, 1); // June,
                                                                              // 1st,
                                                                              // 2012
        // get end date
        setInitOrEndDate_CreditConsumptionFilter(false, ccFilter, 2012, 7, 1); // August,
                                                                               // 1st,
                                                                               // 2012

        // CONSIDERING NOW THAT THE CONTRACT MUST BE IN VIGOR BASED ON THE
        // contractDate
        ccFilter.setOnlyInVigorMatrix(Boolean.TRUE);
        Date contractDate = CalendarUtil.getDate(2150, 0, 1); // date in range
        ccFilter.setContractDate(contractDate);

        List<CreditConsumption> creditConList = creditService.selectCreditConsumptionListByFilter(ccFilter);
        Assert.assertEquals(1, creditConList.size());

    }

    /**
     * @throws GrowerNotFoundException
     */
    @Test
    public void credit_consumption_save_null() throws GrowerNotFoundException {

        try {

            creditService.saveCreditConsumption(null);

        } catch (CreditConsumptionConstraintException cce) {

            checkConstraintException(cce, "Credit consumption is required");

        } catch (Exception e) {
            e.printStackTrace();
            Assert.fail("Expected CreditConsumptionConstraintException, but received " + e);
        }

    }

    /**
     * @throws GrowerNotFoundException
     * @throws CreditConsumptionConstraintException
     * @throws CreditConsumptionException
     * @throws CustomerNotAllowedException
     * @throws CustomerNotFoundException
     * @throws UserNotFoundException
     * @throws CreditConsumptionNotFoundException
     */
    @Test
    public void credit_consumption_save() throws CreditConsumptionConstraintException, CreditConsumptionException,
            GrowerNotFoundException, UserNotFoundException, CustomerNotFoundException, CustomerNotAllowedException,
            CreditConsumptionNotFoundException {

        // Initialize db unit
        setupDBUnit(false);

        // Verify customer
        Assert.assertNotNull("Expected headoffices non-null.", customer);

        // Verify accounts
        Assert.assertNotNull(accountsZeSoja);
        Assert.assertFalse("Expected accounts for grower ze and crop soja.", accountsZeSoja.isEmpty());

        // Get accounts size before consumption
        int accountsZeSojaSizeBeforeConsumption = accountsZeSoja.size();

        // Get first account
        Account account = accountsZeSoja.get(0);

        // Create a item
        CreditConsumptionItem item = new CreditConsumptionItem(null, creditConsumption, account.getBalance(),
                account.getTechnology(), account.getOperationalYear(), account.getCrop(),
                baseService.selectGrowerByID(account.getOwnerCode()), account.getBalance());

        // insert item in credit consumption
        creditConsumption.getCreditConsumptionItens().add(item);

        creditConsumption.setItsUserLogin(loggedUser.getLogin());
        creditConsumption.setHeadoffice(customer.getHeadOffices().iterator().next());
        creditConsumption.setGrower(growerZe);

        // Realize credit consumption
        creditService.saveCreditConsumption(creditConsumption);

        // Flush session
        getSession().flush();

        Assert.assertNotNull("Credit Consumption must be persisted.", creditConsumption.getPrimaryKey());

        // Search credit consumption
        CreditConsumption consumption = creditDAO.selectCreditConsumptionById(creditConsumption.getPrimaryKey());

        Assert.assertNotNull("Credit Consumption must be persisted.", consumption);
        Assert.assertFalse("Expected itens for consumption.", consumption.getCreditConsumptionItens().isEmpty());

        // Verify itens
        for (CreditConsumptionItem it : consumption.getCreditConsumptionItens()) {
            Assert.assertNotNull("Credit Consumption item must be persisted.", it.getPrimaryKey());
        }

        // Search accounts again
        accountsZeSoja = accountService.getAccountsForCreditConsumption(growerZe, cropSoja, cropSoja.getCompany());

        Assert.assertNotNull(accountsZeSoja);
        Assert.assertFalse("Expected accounts for grower ze and crop soja.", accountsZeSoja.isEmpty());
        Assert.assertEquals("Expected less credit accounts than before.", (accountsZeSojaSizeBeforeConsumption - 1),
                accountsZeSoja.size());

    }

    /**
     * @throws GrowerNotFoundException
     * @throws UserNotFoundException
     * @throws CustomerNotFoundException
     * @throws CustomerNotAllowedException
     * @throws CreditConsumptionConstraintException
     * @throws CreditConsumptionException
     * @throws CreditConsumptionNotFoundException
     */
    private Long executeAValidCreditConsumption() throws GrowerNotFoundException, UserNotFoundException,
            CustomerNotFoundException, CustomerNotAllowedException, CreditConsumptionException,
            CreditConsumptionConstraintException, CreditConsumptionNotFoundException {

        // Initialize db unit
        setupDBUnit(false);

        // Verify customer
        Assert.assertNotNull("Expected headoffices non-null.", customer);

        // Verify accounts
        Assert.assertNotNull(accountsZeSoja);
        Assert.assertFalse("Expected accounts for grower ze and crop soja.", accountsZeSoja.isEmpty());

        // Get accounts size before consumption
        accountsZeSojaSizeBeforeConsumption = accountsZeSoja.size();

        // Get first account
        accountBeforeOperation = accountsZeSoja.get(0);

        // Create a item
        CreditConsumptionItem item = new CreditConsumptionItem(null, creditConsumption,
                accountBeforeOperation.getBalance(), accountBeforeOperation.getTechnology(),
                accountBeforeOperation.getOperationalYear(), accountBeforeOperation.getCrop(),
                baseService.selectGrowerByID(accountBeforeOperation.getOwnerCode()),
                accountBeforeOperation.getBalance());

        // insert item in credit consumption
        creditConsumption.getCreditConsumptionItens().add(item);

        creditConsumption.setItsUserLogin(loggedUser.getLogin());
        creditConsumption.setHeadoffice(customer.getHeadOffices().iterator().next());
        creditConsumption.setGrower(growerZe);

        // Realize credit consumption
        creditService.saveCreditConsumption(creditConsumption);

        // Flush session
        // getSession().flush();

        Assert.assertNotNull("Credit Consumption must be persisted.", creditConsumption.getPrimaryKey());

        // Search credit consumption
        CreditConsumption consumption = creditDAO.selectCreditConsumptionById(creditConsumption.getPrimaryKey());

        Assert.assertNotNull("Credit Consumption must be persisted.", consumption);
        Assert.assertFalse("Expected itens for consumption.", consumption.getCreditConsumptionItens().isEmpty());

        // Verify itens
        for (CreditConsumptionItem it : consumption.getCreditConsumptionItens()) {
            Assert.assertNotNull("Credit Consumption item must be persisted.", it.getPrimaryKey());
        }

        // Search accounts again
        accountsZeSoja = accountService.getAccountsForCreditConsumption(growerZe, cropSoja, cropSoja.getCompany());

        Assert.assertNotNull(accountsZeSoja);
        Assert.assertFalse("Expected accounts for grower ze and crop soja.", accountsZeSoja.isEmpty());
        Assert.assertEquals("Expected less credit accounts than before.", (accountsZeSojaSizeBeforeConsumption - 1),
                accountsZeSoja.size());

        return creditConsumption.getPrimaryKey();
    }

    /**
     * @throws GrowerNotFoundException
     * @throws CreditConsumptionConstraintException
     * @throws CreditConsumptionException
     * @throws CustomerNotAllowedException
     * @throws CustomerNotFoundException
     * @throws UserNotFoundException
     * @throws CreditConsumptionNotFoundException
     */
    @Test
    public void credit_consumption_revert() throws CreditConsumptionConstraintException, CreditConsumptionException,
            GrowerNotFoundException, UserNotFoundException, CustomerNotFoundException, CustomerNotAllowedException,
            CreditConsumptionNotFoundException {

        // Execute credit consumption
        Long creditConsumptionId = executeAValidCreditConsumption();

        // Search credit consumption
        CreditConsumption consumption = creditDAO.selectCreditConsumptionById(creditConsumptionId);

        Assert.assertNotNull("Credit Consumption must be persisted.", consumption);
        Assert.assertFalse("Expected itens for consumption.", consumption.getCreditConsumptionItens().isEmpty());

        // Execute reverse
        creditService.revertCreditConsumption(consumption.getPrimaryKey(), "wrong operation, revert it!",
                loggedUser.getLogin());

        // Search accounts again, verify that credit came back
        accountsZeSoja = accountService.getAccountsForCreditConsumption(growerZe, cropSoja, cropSoja.getCompany());

        Assert.assertNotNull(accountsZeSoja);
        Assert.assertFalse("Expected accounts for grower ze and crop soja.", accountsZeSoja.isEmpty());
        Assert.assertEquals("Expected less credit accounts than before.", accountsZeSojaSizeBeforeConsumption,
                accountsZeSoja.size());

        // Check if account have original amount
        Assert.assertEquals("Credit for account must be reverted.", accountBeforeOperation.getBalance(), accountsZeSoja
                .get(0).getBalance());

        // Check credit consumption status
        consumption = creditDAO.selectCreditConsumptionById(creditConsumption.getPrimaryKey());

        Assert.assertNotNull(creditConsumption);
        Assert.assertEquals("Credit consumption must be in reversed status.", CreditConsumptionStatus.REVERSED,
                consumption.getCreditConsumptionStatus());
        Assert.assertNotNull("Expected reversal reason for reversal credit consumption operation.",
                consumption.getReversalReasonDesc());
        Assert.assertNotNull("Expected reversal its user for reversal credit consumption operation.",
                consumption.getReversalItsUserLogin());
        Assert.assertNotNull("Expected reversal date for reversal credit consumption operation.",
                consumption.getReversalDate());

    }

    /**
     * @throws GrowerNotFoundException
     * @throws CreditConsumptionConstraintException
     * @throws CreditConsumptionException
     * @throws CustomerNotAllowedException
     * @throws CustomerNotFoundException
     * @throws UserNotFoundException
     * @throws CreditConsumptionNotFoundException
     */
    @Test(expected = IllegalArgumentException.class)
    public void credit_consumption_revert_expected_illegal_state_exception() throws GrowerNotFoundException,
            UserNotFoundException, CustomerNotFoundException, CustomerNotAllowedException, CreditConsumptionException,
            CreditConsumptionConstraintException, CreditConsumptionNotFoundException {
        // Execute credit consumption
        Long creditConsumptionId = executeAValidCreditConsumption();

        // Search credit consumption
        CreditConsumption consumption = creditDAO.selectCreditConsumptionById(creditConsumptionId);

        Assert.assertNotNull("Credit Consumption must be persisted.", consumption);
        Assert.assertFalse("Expected itens for consumption.", consumption.getCreditConsumptionItens().isEmpty());

        accountService.reverteCreditConsumption(consumption);
        accountService.reverteCreditConsumption(consumption);
    }

    /**
     * @throws GrowerNotFoundException
     * @throws CreditConsumptionConstraintException
     * @throws CreditConsumptionException
     * @throws CustomerNotAllowedException
     * @throws CustomerNotFoundException
     * @throws UserNotFoundException
     * @throws CreditConsumptionNotFoundException
     */
    @Test(expected = IllegalStateException.class)
    public void credit_consumption_revert_with_credit_consumption_in_billed_status_expected_illegal_state_exception()
            throws CreditConsumptionConstraintException, CreditConsumptionException, GrowerNotFoundException,
            UserNotFoundException, CustomerNotFoundException, CustomerNotAllowedException,
            CreditConsumptionNotFoundException {

        // Execute credit consumption
        Long creditConsumptionId = executeAValidCreditConsumption();

        // Search credit consumption
        CreditConsumption consumption = creditDAO.selectCreditConsumptionById(creditConsumptionId);

        Assert.assertNotNull("Credit Consumption must be persisted.", consumption);
        Assert.assertFalse("Expected itens for consumption.", consumption.getCreditConsumptionItens().isEmpty());

        // Update status of credit consumption for
        creditConsumption.setCreditConsumptionStatus(CreditConsumptionStatus.PROCESSED);
        creditDAO.save(creditConsumption);

        // Execute reverse
        creditService
                .revertCreditConsumption(creditConsumptionId, "wrong operation, revert it!", loggedUser.getLogin());
    }

    /**
     * @throws GrowerNotFoundException
     * @throws CreditConsumptionConstraintException
     * @throws CreditConsumptionException
     * @throws CustomerNotAllowedException
     * @throws CustomerNotFoundException
     * @throws UserNotFoundException
     * @throws CreditConsumptionNotFoundException
     */
    @Test(expected = IllegalStateException.class)
    public void credit_consumption_revert_with_credit_consumption_in_corrected_status_expected_illegal_state_exception()
            throws CreditConsumptionConstraintException, CreditConsumptionException, GrowerNotFoundException,
            UserNotFoundException, CustomerNotFoundException, CustomerNotAllowedException,
            CreditConsumptionNotFoundException {

        // Execute credit consumption
        Long creditConsumptionId = executeAValidCreditConsumption();

        // Search credit consumption
        CreditConsumption consumption = creditDAO.selectCreditConsumptionById(creditConsumptionId);

        Assert.assertNotNull("Credit Consumption must be persisted.", consumption);
        Assert.assertFalse("Expected itens for consumption.", consumption.getCreditConsumptionItens().isEmpty());

        // Update status of credit consumption for
        creditConsumption.setCreditConsumptionStatus(CreditConsumptionStatus.CORRECTED);
        creditDAO.save(creditConsumption);

        // Execute reverse
        creditService
                .revertCreditConsumption(creditConsumptionId, "wrong operation, revert it!", loggedUser.getLogin());
    }

    /**
     * @throws GrowerNotFoundException
     * @throws CreditConsumptionConstraintException
     * @throws CreditConsumptionException
     * @throws CustomerNotAllowedException
     * @throws CustomerNotFoundException
     * @throws UserNotFoundException
     * @throws CreditConsumptionNotFoundException
     */
    @Test(expected = IllegalStateException.class)
    public void credit_consumption_revert_with_credit_consumption_in_reversed_status_expected_illegal_state_exception()
            throws CreditConsumptionConstraintException, CreditConsumptionException, GrowerNotFoundException,
            UserNotFoundException, CustomerNotFoundException, CustomerNotAllowedException,
            CreditConsumptionNotFoundException {

        // Execute credit consumption
        Long creditConsumptionId = executeAValidCreditConsumption();

        // Search credit consumption
        CreditConsumption consumption = creditDAO.selectCreditConsumptionById(creditConsumptionId);

        Assert.assertNotNull("Credit Consumption must be persisted.", consumption);
        Assert.assertFalse("Expected itens for consumption.", consumption.getCreditConsumptionItens().isEmpty());

        // Update status of credit consumption for
        creditConsumption.setCreditConsumptionStatus(CreditConsumptionStatus.REVERSED);
        creditDAO.save(creditConsumption);

        // Execute reverse
        creditService
                .revertCreditConsumption(creditConsumptionId, "wrong operation, revert it!", loggedUser.getLogin());
    }

    /**
     * @throws GrowerNotFoundException
     * @throws CreditConsumptionConstraintException
     * @throws CreditConsumptionException
     * @throws CustomerNotAllowedException
     * @throws CustomerNotFoundException
     * @throws UserNotFoundException
     * @throws CreditConsumptionNotFoundException
     */
    @Test(expected = IllegalArgumentException.class)
    public void credit_consumption_revert_with_null_credit_consumption_id_expected_illegal_argument_exception()
            throws CreditConsumptionConstraintException, CreditConsumptionException, GrowerNotFoundException,
            UserNotFoundException, CustomerNotFoundException, CustomerNotAllowedException,
            CreditConsumptionNotFoundException {

        // Execute reverse
        creditService.revertCreditConsumption(null, "blah!", "cmiranda");

    }

    /**
     * @throws GrowerNotFoundException
     * @throws CreditConsumptionConstraintException
     * @throws CreditConsumptionException
     * @throws CustomerNotAllowedException
     * @throws CustomerNotFoundException
     * @throws UserNotFoundException
     * @throws CreditConsumptionNotFoundException
     */
    @Test(expected = IllegalArgumentException.class)
    public void credit_consumption_revert_with_null_reason_expected_illegal_argument_exception()
            throws CreditConsumptionConstraintException, CreditConsumptionException, GrowerNotFoundException,
            UserNotFoundException, CustomerNotFoundException, CustomerNotAllowedException,
            CreditConsumptionNotFoundException {

        // Execute reverse
        creditService.revertCreditConsumption(90001L, null, "cmiranda");

    }

    /**
     * @throws GrowerNotFoundException
     * @throws CreditConsumptionConstraintException
     * @throws CreditConsumptionException
     * @throws CustomerNotAllowedException
     * @throws CustomerNotFoundException
     * @throws UserNotFoundException
     * @throws CreditConsumptionNotFoundException
     */
    @Test(expected = IllegalArgumentException.class)
    public void credit_consumption_revert_with_null_its_user_expected_illegal_argument_exception()
            throws CreditConsumptionConstraintException, CreditConsumptionException, GrowerNotFoundException,
            UserNotFoundException, CustomerNotFoundException, CustomerNotAllowedException,
            CreditConsumptionNotFoundException {

        // Execute reverse
        creditService.revertCreditConsumption(90001L, "blah!", null);

    }

    /**
     * @throws GrowerNotFoundException
     * @throws CreditConsumptionConstraintException
     * @throws CreditConsumptionException
     * @throws CustomerNotAllowedException
     * @throws CustomerNotFoundException
     * @throws UserNotFoundException
     * @throws CreditConsumptionNotFoundException
     */
    @Test(expected = CreditConsumptionNotFoundException.class)
    public void credit_consumption_revert_with_wrong_credit_consumption_id_expected__exception()
            throws CreditConsumptionConstraintException, CreditConsumptionException, GrowerNotFoundException,
            UserNotFoundException, CustomerNotFoundException, CustomerNotAllowedException,
            CreditConsumptionNotFoundException {

        // Execute reverse
        creditService.revertCreditConsumption(-1L, "blah!", "cmiranda");

    }

    /**
     * @throws GrowerNotFoundException
     * @throws CreditConsumptionConstraintException
     * @throws CreditConsumptionException
     * @throws CustomerNotAllowedException
     * @throws CustomerNotFoundException
     * @throws UserNotFoundException
     * @throws CreditConsumptionNotFoundException
     */
    @Test(expected = IllegalStateException.class)
    public void credit_consumption_correct_with_credit_consumption_in_open_status_expected_illegal_state_exception()
            throws CreditConsumptionConstraintException, CreditConsumptionException, GrowerNotFoundException,
            UserNotFoundException, CustomerNotFoundException, CustomerNotAllowedException,
            CreditConsumptionNotFoundException {

        // Execute credit consumption
        Long creditConsumptionId = executeAValidCreditConsumption();

        // Search credit consumption
        CreditConsumption consumption = creditDAO.selectCreditConsumptionById(creditConsumptionId);

        Assert.assertNotNull("Credit Consumption must be persisted.", consumption);
        Assert.assertFalse("Expected itens for consumption.", consumption.getCreditConsumptionItens().isEmpty());

        consumption.setReversalReasonDesc("fixing...");
        consumption.setCorrectionDate(new Date());
        consumption.setCorrectionItsUserLogin(loggedUser.getLogin());

        for (CreditConsumptionItem item : consumption.getCreditConsumptionItens()) {
            item.setCorrectionValue(BigDecimal.ONE);
        }

        // Execute reverse
        creditService.correctCreditConsumption(consumption);
    }

    /**
     * @throws GrowerNotFoundException
     * @throws CreditConsumptionConstraintException
     * @throws CreditConsumptionException
     * @throws CustomerNotAllowedException
     * @throws CustomerNotFoundException
     * @throws UserNotFoundException
     * @throws CreditConsumptionNotFoundException
     */
    @Test(expected = IllegalStateException.class)
    public void credit_consumption_correct_with_credit_consumption_in_corrected_status_expected_illegal_state_exception()
            throws CreditConsumptionConstraintException, CreditConsumptionException, GrowerNotFoundException,
            UserNotFoundException, CustomerNotFoundException, CustomerNotAllowedException,
            CreditConsumptionNotFoundException {

        // Execute credit consumption
        Long creditConsumptionId = executeAValidCreditConsumption();

        // Search credit consumption
        CreditConsumption consumption = creditDAO.selectCreditConsumptionById(creditConsumptionId);

        Assert.assertNotNull("Credit Consumption must be persisted.", consumption);
        Assert.assertFalse("Expected itens for consumption.", consumption.getCreditConsumptionItens().isEmpty());

        // Update credit consumption state for corrected
        creditConsumption.setCreditConsumptionStatus(CreditConsumptionStatus.CORRECTED);
        creditDAO.save(consumption);

        consumption.setReversalReasonDesc("fixing...");
        consumption.setCorrectionDate(new Date());
        consumption.setCorrectionItsUserLogin(loggedUser.getLogin());

        for (CreditConsumptionItem item : consumption.getCreditConsumptionItens()) {
            item.setCorrectionValue(BigDecimal.ONE);
        }

        // Execute reverse
        creditService.correctCreditConsumption(consumption);
    }

    /**
     * @throws GrowerNotFoundException
     * @throws CreditConsumptionConstraintException
     * @throws CreditConsumptionException
     * @throws CustomerNotAllowedException
     * @throws CustomerNotFoundException
     * @throws UserNotFoundException
     * @throws CreditConsumptionNotFoundException
     */
    @Test(expected = IllegalStateException.class)
    public void credit_consumption_correct_with_credit_consumption_in_reversed_status_expected_illegal_state_exception()
            throws CreditConsumptionConstraintException, CreditConsumptionException, GrowerNotFoundException,
            UserNotFoundException, CustomerNotFoundException, CustomerNotAllowedException,
            CreditConsumptionNotFoundException {

        // Execute credit consumption
        Long creditConsumptionId = executeAValidCreditConsumption();

        // Search credit consumption
        CreditConsumption consumption = creditDAO.selectCreditConsumptionById(creditConsumptionId);

        Assert.assertNotNull("Credit Consumption must be persisted.", consumption);
        Assert.assertFalse("Expected itens for consumption.", consumption.getCreditConsumptionItens().isEmpty());

        // Update credit consumption state for corrected
        creditConsumption.setCreditConsumptionStatus(CreditConsumptionStatus.REVERSED);
        creditDAO.save(consumption);

        consumption.setReversalReasonDesc("fixing...");
        consumption.setCorrectionDate(new Date());
        consumption.setCorrectionItsUserLogin(loggedUser.getLogin());

        for (CreditConsumptionItem item : consumption.getCreditConsumptionItens()) {
            item.setCorrectionValue(BigDecimal.ONE);
        }

        // Execute reverse
        creditService.correctCreditConsumption(consumption);
    }

    /**
     * @throws GrowerNotFoundException
     * @throws CreditConsumptionConstraintException
     * @throws CreditConsumptionException
     * @throws CustomerNotAllowedException
     * @throws CustomerNotFoundException
     * @throws UserNotFoundException
     * @throws CreditConsumptionNotFoundException
     */
    @Test(expected = IllegalArgumentException.class)
    public void credit_consumption_correct_with_credit_consumption_null_expected_illegal_argument_exception()
            throws CreditConsumptionConstraintException, CreditConsumptionException, GrowerNotFoundException,
            UserNotFoundException, CustomerNotFoundException, CustomerNotAllowedException,
            CreditConsumptionNotFoundException {

        // Execute reverse
        creditService.correctCreditConsumption(null);
    }

    /**
     * @throws GrowerNotFoundException
     * @throws CreditConsumptionConstraintException
     * @throws CreditConsumptionException
     * @throws CustomerNotAllowedException
     * @throws CustomerNotFoundException
     * @throws UserNotFoundException
     * @throws CreditConsumptionNotFoundException
     */
    @Test
    public void credit_consumption_correct_with_credit_consumption_without_revertion_reason_expected_constraint_exception()
            throws CreditConsumptionConstraintException, CreditConsumptionException, GrowerNotFoundException,
            UserNotFoundException, CustomerNotFoundException, CustomerNotAllowedException,
            CreditConsumptionNotFoundException {

        // Execute credit consumption
        Long creditConsumptionId = executeAValidCreditConsumption();

        // Search credit consumption
        CreditConsumption consumption = creditDAO.selectCreditConsumptionById(creditConsumptionId);

        Assert.assertNotNull("Credit Consumption must be persisted.", consumption);
        Assert.assertFalse("Expected itens for consumption.", consumption.getCreditConsumptionItens().isEmpty());

        // Update credit consumption state for billed
        creditConsumption.setCreditConsumptionStatus(CreditConsumptionStatus.PROCESSED);
        creditDAO.save(consumption);

        consumption.setReversalReasonDesc(null);
        consumption.setCorrectionDate(new Date());
        consumption.setCorrectionItsUserLogin(loggedUser.getLogin());

        for (CreditConsumptionItem item : consumption.getCreditConsumptionItens()) {
            item.setCorrectionValue(BigDecimal.ONE);
        }

        try {
            // Execute reverse
            creditService.correctCreditConsumption(consumption);
            Assert.fail("Expected CreditConsumptionConstraintException, because reversal reason is null");
        } catch (CreditConsumptionConstraintException e) {
            Assert.assertEquals("Expect just one constraint violation.", 1, e.getViolations().size());
            for (ConstraintViolation contraint : e.getViolations()) {
                Assert.assertEquals("Reverse reason is required for this operation.", contraint.getMessage());
            }

        }
    }

    /**
     * @throws GrowerNotFoundException
     * @throws CreditConsumptionConstraintException
     * @throws CreditConsumptionException
     * @throws CustomerNotAllowedException
     * @throws CustomerNotFoundException
     * @throws UserNotFoundException
     * @throws CreditConsumptionNotFoundException
     */
    @Test
    public void credit_consumption_correct_with_credit_consumption_without_correction_user_expected_constraint_exception()
            throws CreditConsumptionConstraintException, CreditConsumptionException, GrowerNotFoundException,
            UserNotFoundException, CustomerNotFoundException, CustomerNotAllowedException,
            CreditConsumptionNotFoundException {

        // Execute credit consumption
        Long creditConsumptionId = executeAValidCreditConsumption();

        // Search credit consumption
        CreditConsumption consumption = creditDAO.selectCreditConsumptionById(creditConsumptionId);

        Assert.assertNotNull("Credit Consumption must be persisted.", consumption);
        Assert.assertFalse("Expected itens for consumption.", consumption.getCreditConsumptionItens().isEmpty());

        // Update credit consumption state for billed
        creditConsumption.setCreditConsumptionStatus(CreditConsumptionStatus.PROCESSED);
        creditDAO.save(consumption);

        consumption.setReversalReasonDesc("blah!");
        consumption.setCorrectionDate(new Date());
        consumption.setCorrectionItsUserLogin(null);

        for (CreditConsumptionItem item : consumption.getCreditConsumptionItens()) {
            item.setCorrectionValue(BigDecimal.ONE);
        }

        try {
            // Execute reverse
            creditService.correctCreditConsumption(consumption);
            Assert.fail("Expected CreditConsumptionConstraintException, because correction user is null");
        } catch (CreditConsumptionConstraintException e) {
            Assert.assertEquals("Expect just one constraint violation.", 1, e.getViolations().size());
            for (ConstraintViolation contraint : e.getViolations()) {
                Assert.assertEquals("Correction user is required for this operation.", contraint.getMessage());
            }

        }
    }

    /**
     * @throws GrowerNotFoundException
     * @throws CreditConsumptionConstraintException
     * @throws CreditConsumptionException
     * @throws CustomerNotAllowedException
     * @throws CustomerNotFoundException
     * @throws UserNotFoundException
     * @throws CreditConsumptionNotFoundException
     */
    @Test
    public void credit_consumption_correct_with_credit_consumption_without_consumption_items_expected_constraint_exception()
            throws CreditConsumptionConstraintException, CreditConsumptionException, GrowerNotFoundException,
            UserNotFoundException, CustomerNotFoundException, CustomerNotAllowedException,
            CreditConsumptionNotFoundException {

        // Execute credit consumption
        Long creditConsumptionId = executeAValidCreditConsumption();

        // Search credit consumption
        CreditConsumption consumption = creditDAO.selectCreditConsumptionById(creditConsumptionId);

        Assert.assertNotNull("Credit Consumption must be persisted.", consumption);
        Assert.assertFalse("Expected itens for consumption.", consumption.getCreditConsumptionItens().isEmpty());

        // Update credit consumption state for billed
        creditConsumption.setCreditConsumptionStatus(CreditConsumptionStatus.PROCESSED);
        creditDAO.save(consumption);

        consumption.setReversalReasonDesc("blah!");
        consumption.setCorrectionDate(new Date());
        consumption.setCorrectionItsUserLogin(loggedUser.getLogin());
        consumption.setCreditConsumptionItens(new HashSet<CreditConsumptionItem>());

        try {
            // Execute reverse
            creditService.correctCreditConsumption(consumption);
            Assert.fail("Expected CreditConsumptionConstraintException, because hasnt consumption itens.");
        } catch (CreditConsumptionConstraintException e) {
            Assert.assertEquals("Expect just one constraint violation.", 1, e.getViolations().size());
            for (ConstraintViolation contraint : e.getViolations()) {
                Assert.assertEquals("Credit Consumptions itens is required.", contraint.getMessage());
            }
        }
    }

    /**
     * @throws GrowerNotFoundException
     * @throws CreditConsumptionConstraintException
     * @throws CreditConsumptionException
     * @throws CustomerNotAllowedException
     * @throws CustomerNotFoundException
     * @throws UserNotFoundException
     * @throws CreditConsumptionNotFoundException
     */
    @Test
    public void credit_consumption_correct_with_credit_consumption_with_null_correction_values_expected_constraint_exception()
            throws CreditConsumptionConstraintException, CreditConsumptionException, GrowerNotFoundException,
            UserNotFoundException, CustomerNotFoundException, CustomerNotAllowedException,
            CreditConsumptionNotFoundException {

        // Execute credit consumption
        Long creditConsumptionId = executeAValidCreditConsumption();

        // Search credit consumption
        CreditConsumption consumption = creditDAO.selectCreditConsumptionById(creditConsumptionId);

        Assert.assertNotNull("Credit Consumption must be persisted.", consumption);
        Assert.assertFalse("Expected itens for consumption.", consumption.getCreditConsumptionItens().isEmpty());

        // Update credit consumption state for billed
        creditConsumption.setCreditConsumptionStatus(CreditConsumptionStatus.PROCESSED);
        creditDAO.save(consumption);

        consumption.setReversalReasonDesc("blah!");
        consumption.setCorrectionDate(new Date());
        consumption.setCorrectionItsUserLogin(loggedUser.getLogin());

        for (CreditConsumptionItem item : consumption.getCreditConsumptionItens()) {
            item.setCorrectionValue(null);
        }

        try {
            // Execute reverse
            creditService.correctCreditConsumption(consumption);
            Assert.fail("Expected CreditConsumptionConstraintException, because correction user is null");
        } catch (CreditConsumptionConstraintException e) {
            Assert.assertEquals("Expect just " + creditConsumption.getCreditConsumptionItens().size()
                    + " constraint violation.", creditConsumption.getCreditConsumptionItens().size(), e.getViolations()
                    .size());
            for (ConstraintViolation contraint : e.getViolations()) {
                Assert.assertEquals("Correction value is required.", contraint.getMessage());
            }

        }
    }

    /**
     * @throws GrowerNotFoundException
     * @throws CreditConsumptionConstraintException
     * @throws CreditConsumptionException
     * @throws CustomerNotAllowedException
     * @throws CustomerNotFoundException
     * @throws UserNotFoundException
     * @throws CreditConsumptionNotFoundException
     */
    @Test
    public void credit_consumption_correct_with_credit_consumption_with_grate_correction_values_expected_constraint_exception()
            throws CreditConsumptionConstraintException, CreditConsumptionException, GrowerNotFoundException,
            UserNotFoundException, CustomerNotFoundException, CustomerNotAllowedException,
            CreditConsumptionNotFoundException {

        // Execute credit consumption
        Long creditConsumptionId = executeAValidCreditConsumption();

        // Search credit consumption
        CreditConsumption consumption = creditDAO.selectCreditConsumptionById(creditConsumptionId);

        Assert.assertNotNull("Credit Consumption must be persisted.", consumption);
        Assert.assertFalse("Expected itens for consumption.", consumption.getCreditConsumptionItens().isEmpty());

        // Update credit consumption state for billed
        creditConsumption.setCreditConsumptionStatus(CreditConsumptionStatus.PROCESSED);
        creditDAO.save(consumption);

        consumption.setReversalReasonDesc("blah!");
        consumption.setCorrectionDate(new Date());
        consumption.setCorrectionItsUserLogin(loggedUser.getLogin());

        // Set correction over consumption value
        for (CreditConsumptionItem item : consumption.getCreditConsumptionItens()) {
            item.setCorrectionValue(item.getRequestValue().add(BigDecimal.ONE));
        }

        try {
            // Execute reverse
            creditService.correctCreditConsumption(consumption);
            Assert.fail("Expected CreditConsumptionConstraintException, because correction user is null");
        } catch (CreditConsumptionConstraintException e) {
            Assert.assertEquals("Expect just " + creditConsumption.getCreditConsumptionItens().size()
                    + " constraint violation.", creditConsumption.getCreditConsumptionItens().size(), e.getViolations()
                    .size());
            for (ConstraintViolation contraint : e.getViolations()) {
                Assert.assertEquals("Correction value must be less or equals then credit consumption value.",
                        contraint.getMessage());
            }

        }
    }

    /**
     * @throws GrowerNotFoundException
     * @throws CreditConsumptionConstraintException
     * @throws CreditConsumptionException
     * @throws CustomerNotAllowedException
     * @throws CustomerNotFoundException
     * @throws UserNotFoundException
     * @throws CreditConsumptionNotFoundException
     */
    @Test
    public void credit_consumption_correct_with_credit_consumption_with_negative_correction_values_expected_constraint_exception()
            throws CreditConsumptionConstraintException, CreditConsumptionException, GrowerNotFoundException,
            UserNotFoundException, CustomerNotFoundException, CustomerNotAllowedException,
            CreditConsumptionNotFoundException {

        // Execute credit consumption
        Long creditConsumptionId = executeAValidCreditConsumption();

        // Search credit consumption
        CreditConsumption consumption = creditDAO.selectCreditConsumptionById(creditConsumptionId);

        Assert.assertNotNull("Credit Consumption must be persisted.", consumption);
        Assert.assertFalse("Expected itens for consumption.", consumption.getCreditConsumptionItens().isEmpty());

        // Update credit consumption state for billed
        creditConsumption.setCreditConsumptionStatus(CreditConsumptionStatus.PROCESSED);
        creditDAO.save(consumption);

        consumption.setReversalReasonDesc("blah!");
        consumption.setCorrectionDate(new Date());
        consumption.setCorrectionItsUserLogin(loggedUser.getLogin());

        // Set correction over consumption value
        for (CreditConsumptionItem item : consumption.getCreditConsumptionItens()) {
            item.setCorrectionValue(BigDecimal.ONE.negate());
        }

        try {
            // Execute reverse
            creditService.correctCreditConsumption(consumption);
            Assert.fail("Expected CreditConsumptionConstraintException, because correction user is null");
        } catch (CreditConsumptionConstraintException e) {
            Assert.assertEquals("Expect just " + creditConsumption.getCreditConsumptionItens().size()
                    + " constraint violation.", creditConsumption.getCreditConsumptionItens().size(), e.getViolations()
                    .size());
            for (ConstraintViolation contraint : e.getViolations()) {
                Assert.assertEquals("Correction value must be non negative.", contraint.getMessage());
            }

        }
    }

    /**
     * @throws GrowerNotFoundException
     * @throws CreditConsumptionConstraintException
     * @throws CreditConsumptionException
     * @throws CustomerNotAllowedException
     * @throws CustomerNotFoundException
     * @throws UserNotFoundException
     * @throws CreditConsumptionNotFoundException
     */
    @Test
    public void credit_consumption_correct() throws CreditConsumptionConstraintException, CreditConsumptionException,
            GrowerNotFoundException, UserNotFoundException, CustomerNotFoundException, CustomerNotAllowedException,
            CreditConsumptionNotFoundException {

        // Execute credit consumption
        Long creditConsumptionId = executeAValidCreditConsumption();

        // Search credit consumption
        CreditConsumption consumption = creditDAO.selectCreditConsumptionById(creditConsumptionId);

        Assert.assertNotNull("Credit Consumption must be persisted.", consumption);
        Assert.assertFalse("Expected itens for consumption.", consumption.getCreditConsumptionItens().isEmpty());

        // Update credit consumption state for billed
        creditConsumption.setCreditConsumptionStatus(CreditConsumptionStatus.PROCESSED);
        creditDAO.save(consumption);

        consumption.setReversalReasonDesc("blah!");
        consumption.setCorrectionDate(new Date());
        consumption.setCorrectionItsUserLogin(loggedUser.getLogin());

        // Set correction value with difference by one
        Crop crop = null;
        Technology tech = null;
        OperationalYear op = null;
        for (CreditConsumptionItem item : consumption.getCreditConsumptionItens()) {
            item.setCorrectionValue(BigDecimal.ONE);
            crop = item.getCrop();
            tech = item.getTechnology();
            op = item.getOperationalYear();
        }

        // Execute reverse
        creditService.correctCreditConsumption(consumption);

        // Verify credit consumption original
        CreditConsumption consumptionOriginal = creditDAO.selectCreditConsumptionById(creditConsumptionId);
        Assert.assertNotNull("Expected credit consumption.", consumptionOriginal);
        Assert.assertNotNull("Correction date must be not null.", consumptionOriginal.getCorrectionDate());
        Assert.assertNotNull("Correction user must be not null.", consumptionOriginal.getCorrectionItsUserLogin());
        Assert.assertNotNull("Correction reason must be not null.", consumptionOriginal.getReversalReasonDesc());
        Assert.assertEquals("Original credit consumption must be in CORRECTED state.",
                CreditConsumptionStatus.CORRECTED, consumptionOriginal.getCreditConsumptionStatus());
        // Assert.assertNotNull("Credit consumption must have correction child.",consumptionOriginal.getCorrectionCreditConsumption());

        // Verify new credit consumption with difference
        CreditConsumption newConsumption = creditDAO.selectCreditConsumptionByOriginalCreditConsId(creditConsumptionId);

        Assert.assertNotNull("Credit Consumption must be persisted.", newConsumption);
        Assert.assertFalse("Expected itens for consumption.", newConsumption.getCreditConsumptionItens().isEmpty());
        Assert.assertNotNull("Original credit consumption must be not null.",
                newConsumption.getOriginalCreditConsumption());

        // Verify itens
        for (CreditConsumptionItem it : newConsumption.getCreditConsumptionItens()) {
            Assert.assertNotNull("Credit Consumption item must be persisted.", it.getPrimaryKey());
            Assert.assertEquals("Credit consumption item must have requested value 1.", BigDecimal.ONE,
                    it.getRequestValue());
        }

        // Search accounts again
        Account account = accountService.getAccountAndValidateExistence(consumption.getGrower(), crop, tech, op,
                new AccountType[] { AccountType.AVAILABLE, AccountType.EXTENDED });

        Assert.assertNotNull(account);
        Assert.assertEquals("Expected correction account value", BigDecimal.ONE, account.getBalance());

    }

    /**
     * @throws GrowerNotFoundException
     * @throws CreditConsumptionConstraintException
     * @throws CreditConsumptionException
     * @throws CustomerNotAllowedException
     * @throws CustomerNotFoundException
     * @throws UserNotFoundException
     * @throws CreditConsumptionNotFoundException
     */
    @Test
    public void credit_consumption_parcial_credit_save() throws CreditConsumptionConstraintException,
            CreditConsumptionException, GrowerNotFoundException, UserNotFoundException, CustomerNotFoundException,
            CustomerNotAllowedException, CreditConsumptionNotFoundException {

        // Initialize db unit
        setupDBUnit(false);

        // Verify customer
        Assert.assertNotNull("Expected headoffices non-null.", customer);

        // Verify accounts
        Assert.assertNotNull(accountsZeSoja);
        Assert.assertFalse("Expected accounts for grower ze and crop soja.", accountsZeSoja.isEmpty());

        // Get accounts size before consumption
        int accountsZeSojaSizeBeforeConsumption = accountsZeSoja.size();

        // Get first account
        Account account = accountsZeSoja.get(0);

        // Create a item
        CreditConsumptionItem item = new CreditConsumptionItem(null, creditConsumption, account.getBalance(),
                account.getTechnology(), account.getOperationalYear(), account.getCrop(),
                baseService.selectGrowerByID(account.getOwnerCode()), account.getBalance());
        item.setRequestValue(account.getBalance().subtract(BigDecimal.ONE));

        // Calculate remaining credit
        BigDecimal differenceBalance = account.getBalance().subtract(item.getRequestValue());

        // insert item in credit consumption
        creditConsumption.getCreditConsumptionItens().add(item);

        creditConsumption.setItsUserLogin(loggedUser.getLogin());
        creditConsumption.setHeadoffice(customer.getHeadOffices().iterator().next());
        creditConsumption.setGrower(growerZe);

        // Realize credit consumption
        creditService.saveCreditConsumption(creditConsumption);

        // Flush session
        getSession().flush();

        Assert.assertNotNull("Credit Consumption must be persisted.", creditConsumption.getPrimaryKey());

        // Search credit consumption
        CreditConsumption consumption = creditDAO.selectCreditConsumptionById(creditConsumption.getPrimaryKey());

        Assert.assertNotNull("Credit Consumption must be persisted.", consumption);
        Assert.assertFalse("Expected itens for consumption.", consumption.getCreditConsumptionItens().isEmpty());

        // Verify itens
        for (CreditConsumptionItem it : consumption.getCreditConsumptionItens()) {
            Assert.assertNotNull("Credit Consumption item must be persisted.", it.getPrimaryKey());
        }

        // Search accounts again
        accountsZeSoja = accountService.getAccountsForCreditConsumption(growerZe, cropSoja, cropSoja.getCompany());

        Assert.assertNotNull(accountsZeSoja);
        Assert.assertFalse("Expected accounts for grower ze and crop soja.", accountsZeSoja.isEmpty());
        Assert.assertEquals("Expected same credit accounts than before.", accountsZeSojaSizeBeforeConsumption,
                accountsZeSoja.size());

        // Get account again
        account = accountsZeSoja.get(0);

        Assert.assertEquals("Expected remaining credit in account.", differenceBalance, account.getBalance());

    }

    /**
     * Verify a specific violation constraint.
     * 
     * @param CreditConsumptionConstraintException
     */
    private void checkConstraintException(CreditConsumptionConstraintException cce, String message) {

        // Verify null and empty list
        Assert.assertNotNull(cce.getViolations());
        Assert.assertFalse("Expected not empty violation list.", cce.getViolations().isEmpty());

        // Check especifique constraint
        for (ConstraintViolation contraint : cce.getViolations()) {

            if (message.equalsIgnoreCase(contraint.getMessage())) {
                return;
            }

        }

        Assert.fail("Expected contraint violation for '" + message + "'.");
        cce.printStackTrace();
    }

    @Test
    public void calculate_credit_volume() throws CustomerNotFoundException, GrowerNotFoundException,
            UserNotFoundException, CustomerNotAllowedException {
        setupDBUnit(false);
        HeadOffice headoffice = (HeadOffice) getSession().get(HeadOffice.class, new Long("900000001"));

        CreditConsumptionFilter ccFilter = new CreditConsumptionFilter();

        ccFilter.setCustomer(headoffice.getCustomer());

        ccFilter.setMatrix(headoffice.getMatrix());

        ccFilter.setCompany(headoffice.getCompany());

        ccFilter.setCrop(headoffice.getCrop());

        Date period = new Date();
        Calendar cal = new GregorianCalendar();
        cal.setTime(period);
        cal.set(Calendar.MONTH, 6);
        cal.set(Calendar.YEAR, 2012);
        period = cal.getTime();
        // period
        ccFilter.setPeriod(period);
        Technology technology = new Technology();
        technology.setId(900000004L);
        ccFilter.setTechnology(technology);
        Boolean filterByAffiliate = true;
        BigDecimal expectedRequestValue = new BigDecimal(3000);
        assertEquals(expectedRequestValue, creditDAO.selectSumVolumeCreditConsumption(ccFilter, filterByAffiliate));
    }

    @Test
    public void summarized_credit_consumption_by_affiliate() throws GrowerNotFoundException, UserNotFoundException,
            CustomerNotFoundException, CustomerNotAllowedException {
        setupDBUnit(false);
        HeadOffice headoffice = (HeadOffice) getSession().get(HeadOffice.class, new Long("900000001"));
        ReportOnLine reportOnLine = new ReportOnLine();
        reportOnLine.setCrop(headoffice.getCrop());
        reportOnLine.setHeadoffice(headoffice);
        Date rolPeriod = CalendarUtil.getDate(2012, 5, 1);
        reportOnLine.setRolPeriod(rolPeriod);
        boolean filterByAffiliate = true;
        BigDecimal expectedSumVolCreditConsumption = new BigDecimal(1);

        Technology technology = new Technology();
        technology.setId(900000001L);
        assertEquals(expectedSumVolCreditConsumption,
                creditService.selectSumCreditConsumptionByRol(reportOnLine, filterByAffiliate, technology));

    }

    /**
     * @throws GrowerNotFoundException
     * @throws UserNotFoundException
     * @throws CustomerNotFoundException
     * @throws CustomerNotAllowedException
     */
    @Test
    public void get_credit_consumption_item_by_filter_affiliates() throws GrowerNotFoundException,
            UserNotFoundException, CustomerNotFoundException, CustomerNotAllowedException {
        setupDBUnit(false);
        HeadOffice headoffice = (HeadOffice) getSession().get(HeadOffice.class, new Long("900000001"));
        ReportOnLine reportOnLine = new ReportOnLine();
        reportOnLine.setCrop(headoffice.getCrop());
        reportOnLine.setHeadoffice(headoffice);
        Date rolPeriod = CalendarUtil.getDate(2012, 5, 1);
        reportOnLine.setRolPeriod(rolPeriod);
        int expectedTotalCreditConsumption = 1;
        Technology technology = new Technology();
        technology.setId(900000001L);
        boolean filterByAffiliate = true;
        assertEquals(expectedTotalCreditConsumption,
                creditService.selectCreditConsumptionItem(reportOnLine, filterByAffiliate, technology).size());
    }

    /**
     * Test credit consumption with user login null.
     * 
     * @throws BusinessException
     */
    @Test(expected = EntityNotFoundException.class)
    public void test_execute_textual_credit_consumption_with_company_null_parameters_expected_entity_not_found_exception()
            throws BusinessException {

        creditService.executeTextualCreditConsumption("cmiranda", "666666", "6666666", "6666", BigDecimal.ONE, "RR",
                null, "SOYA");

    }

    /**
     * Test credit consumption with user login null.
     * 
     * @throws BusinessException
     */
    @Test(expected = EntityNotFoundException.class)
    public void test_execute_textual_credit_consumption_with_crop_null_parameters_expected_entity_not_found_exception()
            throws BusinessException {

        creditService.executeTextualCreditConsumption("cmiranda", "666666", "6666666", "6666", BigDecimal.ONE, "RR",
                "MONSANTO", null);

    }

    /**
     * Test credit consumption with user login null.
     * 
     * @throws BusinessException
     */
    @Test(expected = EntityNotFoundException.class)
    public void test_execute_textual_credit_consumption_with_tech_null_parameters_expected_entity_not_found_exception()
            throws BusinessException {

        creditService.executeTextualCreditConsumption("cmiranda", "666666", "6666666", "6666", BigDecimal.ONE, null,
                "MONSANTO", null);

    }

    /**
     * Test credit consumption with user login null.
     * 
     * @throws EntityNotFoundException
     * @throws UserNotFoundException
     * @throws GrowerNotFoundException
     * @throws CustomerNotFoundException
     * @throws AccountNotFoundException
     * @throws CreditConsumptionException
     * @throws CreditConsumptionNotAvailableVolumeException
     * @throws CreditConsumptionConstraintException
     * @throws CustomerNotAllowedException
     */
    @Test(expected = GrowerNotFoundException.class)
    public void test_execute_textual_credit_consumption_with_grower_null_parameters_expected_grower_not_found_exception()
            throws BusinessException {

        // Setup db unit
        setupDBUnit(false);

        // Get first technology
        String tech = cropSoja.getCompany().getTechnologies().iterator().next().getDescription();

        creditService.executeTextualCreditConsumption("cmiranda", "666666", "6666666", null, BigDecimal.ONE, tech,
                cropSoja.getCompanyDescription(), cropSoja.getDescription());

    }

    /**
     * Test credit consumption with user login null.
     * 
     * @throws EntityNotFoundException
     * @throws UserNotFoundException
     * @throws GrowerNotFoundException
     * @throws CustomerNotFoundException
     * @throws AccountNotFoundException
     * @throws CreditConsumptionException
     * @throws CreditConsumptionNotAvailableVolumeException
     * @throws CreditConsumptionConstraintException
     * @throws CustomerNotAllowedException
     */
    @Test(expected = CustomerNotFoundException.class)
    public void test_execute_textual_credit_consumption_with_matrix_document_null_parameters_expected_customer_not_found_exception()
            throws BusinessException {

        // Setup db unit
        setupDBUnit(false);

        // Get first technology
        String tech = cropSoja.getCompany().getTechnologies().iterator().next().getDescription();

        creditService.executeTextualCreditConsumption("cmiranda", "666666", "", "1", BigDecimal.ONE, tech,
                cropSoja.getCompanyDescription(), cropSoja.getDescription());

    }

    /**
     * Test credit consumption with user login null.
     * 
     * @throws EntityNotFoundException
     * @throws UserNotFoundException
     * @throws GrowerNotFoundException
     * @throws CustomerNotFoundException
     * @throws AccountNotFoundException
     * @throws CreditConsumptionException
     * @throws CreditConsumptionNotAvailableVolumeException
     * @throws CreditConsumptionConstraintException
     * @throws CustomerNotAllowedException
     */
    @Test(expected = CustomerNotFoundException.class)
    public void test_execute_textual_credit_consumption_with_invalid_affiliate_document_null_parameters_expected_customer_not_found_exception()
            throws BusinessException {

        // Setup db unit
        setupDBUnit(false);

        setMatrixVigor(900000001L, 900000001L, 900000001L);

        // Execute credit consumption
        creditService.executeTextualCreditConsumption("cmiranda", "*****", "111111111", "1", BigDecimal.ONE,
                "__INTACTA_", "__MONSANTO DO BRASIL LTDA._", "__SOJA");

    }

    /**
     * Test credit consumption with user login null.
     * 
     * @throws EntityNotFoundException
     * @throws UserNotFoundException
     * @throws GrowerNotFoundException
     * @throws CustomerNotFoundException
     * @throws AccountNotFoundException
     * @throws CreditConsumptionException
     * @throws CreditConsumptionNotAvailableVolumeException
     * @throws CreditConsumptionConstraintException
     * @throws CustomerNotAllowedException
     */
    @Test(expected = AccountNotFoundException.class)
    public void test_execute_textual_credit_consumption_without_accounts_expected_customer_not_found_exception()
            throws BusinessException {

        // Setup db unit
        setupDBUnit(false);

        // Load matrix vigor
        setMatrixVigor(900000001L, 900000001L, 900000001L);

        // Execute credit consumption
        creditService.executeTextualCreditConsumption("cmiranda", "111111111", "111111111", "2", BigDecimal.ONE,
                "__RR_", "__MONSANTO DO BRASIL LTDA._", "__SOJA");

    }

    /**
     * 
     */
    private HeadOfficeDetail setMatrixVigor(Long cropLong, Long companyLong, Long headofficeLong) {
        // Find crop
        Crop crop = (Crop) getSession().get(Crop.class, cropLong);
        Assert.assertNotNull(crop);
        Company company = (Company) getSession().get(Company.class, companyLong);
        Assert.assertNotNull(company);

        // Find head office
        HeadOffice headOffice = (HeadOffice) getSession().get(HeadOffice.class, headofficeLong);
        Assert.assertNotNull(headOffice);

        // Build contract range
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.MONTH, -10);

        // Create head office detail
        HeadOfficeDetail headOfficeDetail = new HeadOfficeDetail();
        headOfficeDetail.setHeadoffice(headOffice);
        headOfficeDetail.setReportRol(Boolean.TRUE);
        headOfficeDetail.setShowParticipantInList(Boolean.FALSE);

        // Set effective date
        HeadOfficeEffectiveDate effectiveDate = new HeadOfficeEffectiveDate();
        effectiveDate.setHeadOfficeDetail(headOfficeDetail);
        effectiveDate.setInitDate(calendar.getTime());

        // Create contract
        Contract contract = new Contract();
        contract.setCompany(company);
        contract.setCrop(crop);
        contract.setCustomer(headOffice.getMatrix());
        contract.setParticipantType(ParticipantTypeEnum.POD);
        contract.setStartDate(calendar.getTime());
        calendar.add(Calendar.MONTH, 20);
        contract.setEndDate(calendar.getTime());
        saveAndFlush(contract);

        // Set end of effective date like end of matrix contract
        effectiveDate.setEndDate(calendar.getTime());
        headOfficeDetail.getHeadOfficeEffectiveDates().add(effectiveDate);
        saveAndFlush(headOfficeDetail);

        return headOfficeDetail;
    }

    /**
     * Test credit consumption with user login null.
     * 
     * @throws BusinessException
     * @throws ManualCreditConstraintException
     */
    @Test
    public void test_execute_textual_credit_consumption() throws BusinessException, ManualCreditConstraintException {

        // Setup db unit
        setupDBUnit(false);

        HeadOfficeDetail detail = setMatrixVigor(900000005L, 900000002L, 999000003L);

        OperationalYear operationalYear = (OperationalYear) getSession().get(OperationalYear.class, 900000001L);
        Assert.assertNotNull(operationalYear);

        Technology technology = (Technology) getSession().get(Technology.class, 900000002L);
        Assert.assertNotNull(technology);

        Grower grower = (Grower) getSession().get(Grower.class, 900000010L);
        Assert.assertNotNull(grower);

        accountService.generateCreditManually(detail.getHeadoffice().getCrop(), operationalYear, technology, grower,
                ManualCreditTransactionType.CREDIT, BigDecimal.TEN, "x", loggedUser.getLogin());

        // Execute credit consumption
        CreditConsumption creditConsumption = creditService.executeTextualCreditConsumption("login1", "666", "666",
                "10", BigDecimal.ONE, "__INTACTA EUA_", "__MONSANTO US_", "__MILHO_");

        Assert.assertNotNull("Expected a valid credit consumption.", creditConsumption);
        Assert.assertNotNull("Expected a valid credit consumption.", creditConsumption.getId());

    }

    /**
     * Test credit consumption with user login null.
     * 
     * @throws BusinessException
     */
    @Test(expected = AffiliateNotInVigorException.class)
    public void test_execute_textual_credit_consumption_but_affiliate_is_not_enabled_for_report_rol_expected_affiliate_not_in_vigor_exception()
            throws BusinessException {

        // Setup db unit
        setupDBUnit(false);

        // Remove affilite to report rol
        HeadOfficeDetail detail = setMatrixVigor(900000001L, 900000001L, 900000001L);
        detail.setReportRol(Boolean.FALSE);
        saveAndFlush(detail);

        // Execute credit consumption
        creditService.executeTextualCreditConsumption("login1", "111111111", "111111111", "1", BigDecimal.ONE,
                "__INTACTA_", "__MONSANTO DO BRASIL LTDA._", "__SOJA");

    }

    /**
     * Test credit consumption with user login null.
     * 
     * @throws BusinessException
     */
    @Test(expected = AffiliateNotInVigorException.class)
    public void test_execute_textual_credit_consumption_but_affiliate_is_enabled_for_report_rol_but_out_of_period_expected_affiliate_not_in_vigor_exception()
            throws BusinessException {

        // Setup db unit
        setupDBUnit(false);

        // Remove affilite to report rol
        HeadOfficeDetail detail = setMatrixVigor(900000001L, 900000001L, 900000001L);

        // Change affiliate vigor
        for (HeadOfficeEffectiveDate hoed : detail.getHeadOfficeEffectiveDates()) {
            hoed.setInitDate(CalendarUtil.getDate(1986, 11, 13));
            hoed.setEndDate(CalendarUtil.getDate(1987, 11, 13));
        }

        saveAndFlush(detail);

        // Execute credit consumption
        creditService.executeTextualCreditConsumption("login1", "111111111", "111111111", "1", BigDecimal.ONE,
                "__INTACTA_", "__MONSANTO DO BRASIL LTDA._", "__SOJA");

    }

    /**
     * Test credit consumption with user login null.
     * 
     * @throws BusinessException
     */
    @Test(expected = ContractNotFoundException.class)
    public void test_execute_textual_credit_consumption_matrix_without_contract() throws BusinessException {

        // Setup db unit
        setupDBUnit(false);

        // Execute credit consumption
        creditService.executeTextualCreditConsumption("login1", "666", "666", "8", BigDecimal.ONE, "__BOLLGARD BAYER_",
                "__BAYER S.A_", "__CANA_");

    }

    /**
     * Test credit consumption with user login null.
     * 
     * @throws BusinessException
     */
    @Test(expected = ContractNotFoundException.class)
    public void test_execute_textual_credit_consumption_matrix_contract_but_out_of_vigor() throws BusinessException {

        // Setup db unit
        setupDBUnit(false);

        // Find crop
        Crop crop = (Crop) getSession().get(Crop.class, 900000001L);
        Assert.assertNotNull(crop);
        Company company = (Company) getSession().get(Company.class, 900000001L);
        Assert.assertNotNull(company);

        // Find head office
        HeadOffice headOffice = (HeadOffice) getSession().get(HeadOffice.class, 900000001L);
        Assert.assertNotNull(headOffice);

        // Build contract set vigor in past
        Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.YEAR, 1986);

        // Change vigor to out of date.
        for (Contract contract : headOffice.getMatrix().getContracts()) {
            contract.setStartDate(calendar.getTime());
            calendar.add(Calendar.YEAR, 1);
            contract.setEndDate(calendar.getTime());
            saveAndFlush(contract);
        }

        // Execute credit consumption
        creditService.executeTextualCreditConsumption("login1", "111111111", "111111111", "1", BigDecimal.ONE,
                "__INTACTA_", "__MONSANTO DO BRASIL LTDA._", "__SOJA");

    }

    /**
     * @throws CreditConsumptionNotFoundException
     */
    @Test(expected = IllegalArgumentException.class)
    public void test_execute_textual_revert_credit_consumption_with_all_null_parameters() throws UserNotFoundException,
            CreditConsumptionNotFoundException {

        creditService.executeTextualRevertCreditConsumption(null, null, null, null);

    }

    /**
     * @throws UserNotFoundException
     * @throws CreditConsumptionNotFoundException
     * @throws GrowerNotFoundException
     * @throws CustomerNotFoundException
     * @throws CustomerNotAllowedException
     * @throws CreditConsumptionException
     * @throws CreditConsumptionConstraintException
     */
    @Test
    public void test_execute_textual_revert_credit_consumption() throws UserNotFoundException,
            CreditConsumptionNotFoundException, GrowerNotFoundException, CustomerNotFoundException,
            CustomerNotAllowedException, CreditConsumptionException, CreditConsumptionConstraintException {

        // Execute credit consumption
        Long creditConsumptionId = executeAValidCreditConsumption();

        // Search credit consumption
        CreditConsumption consumption = creditDAO.selectCreditConsumptionById(creditConsumptionId);

        Assert.assertNotNull("Credit Consumption must be persisted.", consumption);
        Assert.assertFalse("Expected itens for consumption.", consumption.getCreditConsumptionItens().isEmpty());

        // Execute reverse
        creditService.executeTextualRevertCreditConsumption(loggedUser.getLogin(), creditConsumptionId, new Date(),
                "ah!");

        // Search accounts again, verify that credit came back
        accountsZeSoja = accountService.getAccountsForCreditConsumption(growerZe, cropSoja, cropSoja.getCompany());

        Assert.assertNotNull(accountsZeSoja);
        Assert.assertFalse("Expected accounts for grower ze and crop soja.", accountsZeSoja.isEmpty());
        Assert.assertEquals("Expected less credit accounts than before.", accountsZeSojaSizeBeforeConsumption,
                accountsZeSoja.size());

        // Check if account have original amount
        Assert.assertEquals("Credit for account must be reverted.", accountBeforeOperation.getBalance(), accountsZeSoja
                .get(0).getBalance());

        // Check credit consumption status
        consumption = creditDAO.selectCreditConsumptionById(creditConsumption.getPrimaryKey());

        Assert.assertNotNull(creditConsumption);
        Assert.assertEquals("Credit consumption must be in reversed status.", CreditConsumptionStatus.REVERSED,
                consumption.getCreditConsumptionStatus());
        Assert.assertNotNull("Expected reversal reason for reversal credit consumption operation.",
                consumption.getReversalReasonDesc());
        Assert.assertNotNull("Expected reversal its user for reversal credit consumption operation.",
                consumption.getReversalItsUserLogin());
        Assert.assertNotNull("Expected reversal date for reversal credit consumption operation.",
                consumption.getReversalDate());
    }

    @Test
    public void get_credit_account_consumption_by_credit_consumption_id() throws CreditConsumptionNotFoundException,
            GrowerNotFoundException, UserNotFoundException, CustomerNotFoundException, CustomerNotAllowedException {

        // Initialize db unit
        setupDBUnit(false);

        // Assert the item is not null and the object was found.
        CreditConsumption creditConsumption = creditService.selectCreditAccountConsumption(900000001L);
        Assert.assertNotNull(creditConsumption);
    }

    @Test
    public void save_file_and_lines_sucess() throws GrowerNotFoundException, UserNotFoundException,
            CustomerNotFoundException, CustomerNotAllowedException {

        CsvImportFile csvFile = new CsvImportFile("fileName", "userLogin", ImportFileType.CSV_PAID_VOLUME);
        List<CsvCreditConsumptionImportLine> lines = createCsvCreditConsumptionImportLines(3, csvFile);

        CsvImportFile result = creditService.saveFileAndLines(csvFile, lines);

        Assert.assertTrue(result != null);
    }

    @Test
    public void save_file_and_lines_sucess_with_20() throws GrowerNotFoundException, UserNotFoundException,
            CustomerNotFoundException, CustomerNotAllowedException {

        CsvImportFile csvFile = createCsvImportFile();
        csvFile.setFileStatus(ImportFileStatus.UPLOADED);
        saveAndFlush(csvFile);
        List<CsvCreditConsumptionImportLine> lines = createCsvCreditConsumptionImportLines(20, csvFile);

        CsvImportFile result = creditService.saveFileAndLines(csvFile, lines);

        Assert.assertTrue(result != null);
    }

    private CsvImportFile createCsvImportFile() {
        CsvImportFile csvFile = new CsvImportFile();
        Calendar creationDate = Calendar.getInstance();
        creationDate.add(Calendar.MONTH, -1);
        csvFile.setCreationDate(creationDate.getTime());
        csvFile.setFileName("FileName");
        csvFile.setFileStatus(null);
        csvFile.setLastUpdate(Calendar.getInstance().getTime());
        csvFile.setUserLogin("userLogin");
        return csvFile;
    }

    private List<CsvCreditConsumptionImportLine> createCsvCreditConsumptionImportLines(final int numberOfLines,
            final CsvImportFile csvFile) {

        List<CsvCreditConsumptionImportLine> lines = new ArrayList<CsvCreditConsumptionImportLine>(numberOfLines);
        for (int i = 0; i < numberOfLines; i++) {
            CsvCreditConsumptionItem ccci = new CsvCreditConsumptionItem();
            ccci.setActualPositionColumnSize(10 * i);
            ccci.setLine(i);
            ccci.setMaxPositionColumnSize(i);
            ccci.setPositionColumn(i);
            ccci.setPositionColumnDisplayName("ColumnDisplayName " + i);
            ccci.setWarn("Warn " + i);

            CsvCreditConsumptionImportLine cccil = new CsvCreditConsumptionImportLine(ccci, csvFile);
            cccil.setCompanyDescription("CompanyDescription " + i);
            Calendar creationDate = Calendar.getInstance();
            creationDate.add(Calendar.MONTH, -1);
            cccil.setCreationDate(creationDate.getTime());
            cccil.setCropDescription("__SOJA___");
            cccil.setGrowerDocumentNumber("12345678900");
            cccil.setGrowerDocumentType(DocumentTypeEnum.CPF.name());
            cccil.setLineNumber(i);
            cccil.setMatrixDocumentNumber("09.281.091/0001-55");
            cccil.setPartnerDocumentNumber("09.281.091/0002-36");
            cccil.setPositionColumn(i);
            cccil.setRequestValue(BigDecimal.valueOf(i));
            cccil.setTechnologyDescription("RR");

            lines.add(cccil);
        }

        return lines;
    }

    @Test
    public void select_csv_import_lines_by_file_sucess() throws GrowerNotFoundException, UserNotFoundException,
            CustomerNotFoundException, CustomerNotAllowedException {

        CsvImportFile csvFile = new CsvImportFile("select_csv_import_lines_by_file_sucess_fileName",
                "select_csv_import_lines_by_file_sucess_userLogin", ImportFileType.CSV_PAID_VOLUME);
        List<CsvCreditConsumptionImportLine> lines = createCsvCreditConsumptionImportLines(20, csvFile);

        CsvImportFile cif = creditService.saveFileAndLines(csvFile, lines);

        Assert.assertTrue(cif != null);

        List<CsvCreditConsumptionImportLine> result = creditService.selectCsvImportLinesByFile(cif);

        Assert.assertFalse(result.isEmpty());
    }

    @Test
    public void save_credit_consumption_import_result_sucess() throws GrowerNotFoundException, UserNotFoundException,
            CustomerNotFoundException, CustomerNotAllowedException {

        int warningNumber = 3;
        Set<String> warningList = new HashSet<String>();
        for (int i = 0; i < warningNumber; i++) {
            warningList.add("Warning " + i);
        }

        CsvImportFile csvFile = new CsvImportFile("CsvfileName", "CsvUserLogin", ImportFileType.CSV_PAID_VOLUME);
        saveAndFlush(csvFile);

        creditService.saveCreditConsumptionImportResult(warningList, csvFile);

        @SuppressWarnings("unchecked")
        List<CsvCreditConsumptionImportResult> result = getSession()
                .createCriteria(CsvCreditConsumptionImportResult.class).add(Restrictions.eq("file", csvFile)).list();

        Assert.assertTrue(result.size() == warningNumber);
    }

    @Test
    public void save_credit_consumption_import_result_sucess_with_20() throws GrowerNotFoundException,
            UserNotFoundException, CustomerNotFoundException, CustomerNotAllowedException {

        int warningNumber = 20;
        Set<String> warningList = new HashSet<String>();
        for (int i = 0; i < warningNumber; i++) {
            warningList.add("Warning " + i);
        }

        CsvImportFile csvFile = new CsvImportFile("CsvfileName", "CsvUserLogin", ImportFileType.CSV_PAID_VOLUME);
        saveAndFlush(csvFile);

        creditService.saveCreditConsumptionImportResult(warningList, csvFile);

        @SuppressWarnings("unchecked")
        List<CsvCreditConsumptionImportResult> result = getSession()
                .createCriteria(CsvCreditConsumptionImportResult.class).add(Restrictions.eq("file", csvFile)).list();

        Assert.assertTrue(result.size() == warningNumber);
    }

    @Test
    public void cancel_import_file() {

        CsvImportFile csvFile = new CsvImportFile("CsvfileName", "CsvUserLogin", ImportFileType.CSV_PAID_VOLUME);
        saveAndFlush(csvFile);

        CsvImportFile file = creditService.cancelImportFile(csvFile);

        Assert.assertNotNull(file);
    }

    @Test
    public void select_csv_credit_consumption_import_result_by_file() {

        CsvImportFile csvFile = new CsvImportFile("fileName", "userLogin", ImportFileType.CSV_PAID_VOLUME);
        saveAndFlush(csvFile);
        List<CsvCreditConsumptionImportResult> results = createCsvCreditConsumptionImportResults(3, csvFile);
        for (CsvCreditConsumptionImportResult result : results) {
            saveAndFlush(result);
        }

        List<CsvCreditConsumptionImportResult> result = creditService
                .selectCsvCreditConsumptionImportResultByFile(csvFile);

        Assert.assertFalse(result.isEmpty());
    }

    private List<CsvCreditConsumptionImportResult> createCsvCreditConsumptionImportResults(final int numberOfResults,
            final CsvImportFile csvFile) {
        List<CsvCreditConsumptionImportResult> results = new ArrayList<CsvCreditConsumptionImportResult>(
                numberOfResults);
        for (int i = 0; i < numberOfResults; i++) {
            results.add(new CsvCreditConsumptionImportResult(csvFile, "Warning " + i));
        }

        return results;
    }

    @Test(expected = CreditConsumptionException.class)
    public void merge_credit_consumption_import_account_not_found() throws GrowerNotFoundException,
            UserNotFoundException, CustomerNotFoundException, CustomerNotAllowedException, CreditConsumptionException,
            NumberFormatException, CreditConsumptionNotFoundException, CreditConsumptionConstraintException {

        this.setupDBUnit(false);

        Map<CreditConsumptionItem, CreditConsumptionImportDTO> creditConsumptionItemLineImportMap = new HashMap<CreditConsumptionItem, CreditConsumptionImportDTO>();
        List<CreditConsumptionImportDTO> listImportDTO = createOneImportDTOItem();

        // test when grower don't have account
        creditService.mergeCreditConsumptionImport(listImportDTO, creditConsumptionItemLineImportMap);

    }

    @Test
    public void merge_credit_consumption_import_diferents_grower() throws GrowerNotFoundException,
            UserNotFoundException, CustomerNotFoundException, CustomerNotAllowedException, CreditConsumptionException,
            NumberFormatException, CreditConsumptionNotFoundException, CreditConsumptionConstraintException {

        this.setupDBUnit(false);

        List<CreditConsumption> creditConsumptions = null;
        Map<CreditConsumptionItem, CreditConsumptionImportDTO> creditConsumptionItemLineImportMap = new HashMap<CreditConsumptionItem, CreditConsumptionImportDTO>();
        List<CreditConsumptionImportDTO> listImportDTO = createTwoImportDTOItemsDifferentGrower();

        // test when exists different growers
        creditConsumptions = creditService.mergeCreditConsumptionImport(listImportDTO,
                creditConsumptionItemLineImportMap);
        Assert.assertNotNull(creditConsumptions);
        Assert.assertEquals("Invalid list size", 2, creditConsumptions.size());

        // should be created two credit consumption with one item
        for (CreditConsumption cc : creditConsumptions) {
            Assert.assertEquals(1, cc.getCreditConsumptionItens().size());
        }

    }

    @Test
    public void merge_credit_consumption_import_same_grower_different_technology() throws NumberFormatException,
            ManualCreditConstraintException, BusinessException {

        this.setupDBUnit(false);

        List<CreditConsumption> creditConsumptions = null;
        Map<CreditConsumptionItem, CreditConsumptionImportDTO> creditConsumptionItemLineImportMap = new HashMap<CreditConsumptionItem, CreditConsumptionImportDTO>();
        List<CreditConsumptionImportDTO> listImportDTO = createThreeImportDTOItemsSameGrowerDiffTechnology();

        OperationalYear operationalYear = (OperationalYear) getSession().get(OperationalYear.class, 900000001L);
        Assert.assertNotNull(operationalYear);

        // generate manual credit to line one and two
        for (CreditConsumptionImportDTO creditConsumptionImportDTO : listImportDTO) {
            accountService.generateCreditManually(creditConsumptionImportDTO.getCrop(), operationalYear,
                    creditConsumptionImportDTO.getTechnology(), creditConsumptionImportDTO.getGrower(),
                    ManualCreditTransactionType.CREDIT, BigDecimal.ONE, "x", loggedUser.getLogin());
        }

        // test when exists same growers and different technology in sequence,
        // credit
        // consumption item should be grouped
        creditConsumptions = creditService.mergeCreditConsumptionImport(listImportDTO,
                creditConsumptionItemLineImportMap);
        Assert.assertNotNull(creditConsumptions);
        Assert.assertEquals("Invalid list size", 2, creditConsumptions.size());

        // Should be create two credit consumptions, one with one item e one
        // with two items
        for (CreditConsumption cc : creditConsumptions) {
            Assert.assertTrue(cc.getCreditConsumptionItens().size() <= 2);
        }

    }

    @Test(expected = CreditConsumptionConstraintException.class)
    public void validate_account_and_save_credit_consumption_account_not_found()
            throws ManualCreditConstraintException, BusinessException {
        this.setupDBUnit(false);
        CreditConsumption creditCons = (CreditConsumption) getSession().get(CreditConsumption.class, 900000006L);
        Assert.assertNotNull(creditCons);

        Map<CreditConsumptionItem, CreditConsumptionImportDTO> creditConsumptionItemLineImportMap = new HashMap<CreditConsumptionItem, CreditConsumptionImportDTO>();
        Integer line = 1;
        for (CreditConsumptionItem item : creditCons.getCreditConsumptionItens()) {
            CreditConsumptionImportDTO dto = new CreditConsumptionImportDTO();
            dto.setLineNumber(line++);
            creditConsumptionItemLineImportMap.put(item, dto);
        }

        this.creditService.validateAccountAndSaveCreditConsumption(creditCons, creditConsumptionItemLineImportMap);
    }

    @Test
    public void validate_account_and_save_credit_consumption() throws ManualCreditConstraintException,
            BusinessException {

        this.setupDBUnit(false);
        List<CreditConsumption> creditConsumptions = null;
        Map<CreditConsumptionItem, CreditConsumptionImportDTO> creditConsumptionItemLineImportMap = new HashMap<CreditConsumptionItem, CreditConsumptionImportDTO>();

        List<CreditConsumptionImportDTO> listImportDTO = new ArrayList<CreditConsumptionImportDTO>();
        Crop crop = (Crop) getSession().get(Crop.class, 900000001L);
        Assert.assertNotNull(crop);
        Company company = (Company) getSession().get(Company.class, 900000001L);
        Assert.assertNotNull(company);
        HeadOffice headOffice = (HeadOffice) getSession().get(HeadOffice.class, 900000001L);
        Assert.assertNotNull(headOffice);
        Technology technologyRR = (Technology) getSession().get(Technology.class, 900000003L);
        Assert.assertNotNull(technologyRR);
        ItsUserDTO itsUserDTO = this.userService.getByLogin(loggedUser.getLogin());
        Assert.assertNotNull(itsUserDTO);

        OperationalYear operationalYear = (OperationalYear) getSession().get(OperationalYear.class, 900000001L);
        Assert.assertNotNull(operationalYear);

        Integer lineNumber = 2; // line 1 is csv header
        CreditConsumptionImportDTO importDTO = new CreditConsumptionImportDTO();
        importDTO.setCompany(company);
        importDTO.setCrop(crop);
        importDTO.setGrower(growerJoao);
        importDTO.setHeadOffice(headOffice);
        importDTO.setLineNumber(lineNumber);
        importDTO.setTechnology(technologyRR);
        importDTO.setMatrix(headOffice.getMatrix());
        importDTO.setUser(itsUserDTO);
        importDTO.setVolume(BigDecimal.ONE);
        listImportDTO.add(importDTO);

        accountService.generateCreditManually(crop, operationalYear, technologyRR, growerJoao,
                ManualCreditTransactionType.CREDIT, BigDecimal.TEN, "x", loggedUser.getLogin());

        // test when exists same growers and different technology in sequence,
        // credit
        // consumption item should be grouped
        creditConsumptions = creditService.mergeCreditConsumptionImport(listImportDTO,
                creditConsumptionItemLineImportMap);

        Assert.assertNotNull(creditConsumptions);
        for (CreditConsumption creditConsumption : creditConsumptions) {
            creditService
                    .validateAccountAndSaveCreditConsumption(creditConsumption, creditConsumptionItemLineImportMap);
        }

    }

    @Test
    public void validate_account_and_save_credit_consumption_balance_overflow() throws ManualCreditConstraintException,
            BusinessException {

        this.setupDBUnit(false);
        List<CreditConsumption> creditConsumptions = null;
        Map<CreditConsumptionItem, CreditConsumptionImportDTO> creditConsumptionItemLineImportMap = new HashMap<CreditConsumptionItem, CreditConsumptionImportDTO>();
        OperationalYear operationalYear = (OperationalYear) getSession().get(OperationalYear.class, 900000001L);
        Assert.assertNotNull(operationalYear);

        List<CreditConsumptionImportDTO> listImportDTO = createThreeImportDTOItemsSameGrowerDiffTechnologyOverFlow();

        // generate manual credit
        for (CreditConsumptionImportDTO creditConsumptionImportDTO : listImportDTO) {
            accountService.generateCreditManually(creditConsumptionImportDTO.getCrop(), operationalYear,
                    creditConsumptionImportDTO.getTechnology(), creditConsumptionImportDTO.getGrower(),
                    ManualCreditTransactionType.CREDIT, BigDecimal.ONE, "x", loggedUser.getLogin());
        }

        // test when exists same growers and different technology in sequence,
        // credit
        // consumption item should be grouped
        try {
            creditConsumptions = creditService.mergeCreditConsumptionImport(listImportDTO,
                    creditConsumptionItemLineImportMap);
        } catch (CreditConsumptionConstraintException e1) {
            Assert.fail(e1.getMessage());
        }

        Assert.assertNotNull(creditConsumptions);
        for (CreditConsumption creditConsumption : creditConsumptions) {
            try {
                creditService.validateAccountAndSaveCreditConsumption(creditConsumption,
                        creditConsumptionItemLineImportMap);
            } catch (CreditConsumptionConstraintException e) {
                Assert.assertTrue(e.getMessage().startsWith("There are errors."));
            }
        }

    }

    @Test
    public void validate_grower_account_success() throws ManualCreditConstraintException, BusinessException {

        this.setupDBUnit(false);

        List<CreditConsumptionImportDTO> listImportDTO = createOneImportDTOItem();
        CreditConsumptionImportDTO creditConsumptionImportDTO = listImportDTO.get(0);

        Crop crop = (Crop) getSession().get(Crop.class, 900000001L);
        Assert.assertNotNull(crop);
        Company company = (Company) getSession().get(Company.class, 900000001L);
        Assert.assertNotNull(company);
        HeadOffice headOffice = (HeadOffice) getSession().get(HeadOffice.class, 900000001L);
        Assert.assertNotNull(headOffice);
        Technology technology = (Technology) getSession().get(Technology.class, 900000001L);
        Assert.assertNotNull(technology);
        ItsUserDTO itsUserDTO = this.userService.getByLogin(loggedUser.getLogin());
        Assert.assertNotNull(itsUserDTO);

        CreditConsumptionItemDTO item = new CreditConsumptionItemDTO();
        item.setTechnology(technology.getDescription());
        item.setVolume(BigDecimal.TEN);

        OperationalYear operationalYear = (OperationalYear) getSession().get(OperationalYear.class, 900000001L);
        Assert.assertNotNull(operationalYear);

        // generate manual credit the same credit consumption
        accountService.generateCreditManually(creditConsumptionImportDTO.getCrop(), operationalYear,
                creditConsumptionImportDTO.getTechnology(), creditConsumptionImportDTO.getGrower(),
                ManualCreditTransactionType.CREDIT, BigDecimal.TEN, "x", loggedUser.getLogin());

        // test when grower don't have account
        creditService.validateGrowerAccount(item, creditConsumptionImportDTO, Boolean.TRUE);
    }

    @Test(expected = CreditConsumptionConstraintException.class)
    public void validate_grower_account_fail_balance_overflow() throws ManualCreditConstraintException,
            BusinessException {

        this.setupDBUnit(false);

        List<CreditConsumptionImportDTO> listImportDTO = createOneImportDTOItem();
        CreditConsumptionImportDTO creditConsumptionImportDTO = listImportDTO.get(0);

        Crop crop = (Crop) getSession().get(Crop.class, 900000001L);
        Assert.assertNotNull(crop);
        Company company = (Company) getSession().get(Company.class, 900000001L);
        Assert.assertNotNull(company);
        HeadOffice headOffice = (HeadOffice) getSession().get(HeadOffice.class, 900000001L);
        Assert.assertNotNull(headOffice);
        Technology technology = (Technology) getSession().get(Technology.class, 900000001L);
        Assert.assertNotNull(technology);
        ItsUserDTO itsUserDTO = this.userService.getByLogin(loggedUser.getLogin());
        Assert.assertNotNull(itsUserDTO);

        CreditConsumptionItemDTO item = new CreditConsumptionItemDTO();
        item.setTechnology(technology.getDescription());
        item.setVolume(BigDecimal.TEN);

        OperationalYear operationalYear = (OperationalYear) getSession().get(OperationalYear.class, 900000001L);
        Assert.assertNotNull(operationalYear);

        // generate manual credit less than credit consumption
        accountService.generateCreditManually(creditConsumptionImportDTO.getCrop(), operationalYear,
                creditConsumptionImportDTO.getTechnology(), creditConsumptionImportDTO.getGrower(),
                ManualCreditTransactionType.CREDIT, BigDecimal.ONE, "x", loggedUser.getLogin());

        // test when grower don't have account
        creditService.validateGrowerAccount(item, creditConsumptionImportDTO, Boolean.TRUE);
    }

    @Test(expected = CreditConsumptionConstraintException.class)
    public void validate_grower_account_not_found() throws ManualCreditConstraintException, BusinessException {

        this.setupDBUnit(false);

        List<CreditConsumptionImportDTO> listImportDTO = createOneImportDTOItem();
        CreditConsumptionImportDTO creditConsumptionImportDTO = listImportDTO.get(0);

        Technology technology = (Technology) getSession().get(Technology.class, 900000001L);
        Assert.assertNotNull(technology);

        CreditConsumptionItemDTO item = new CreditConsumptionItemDTO();
        item.setTechnology(technology.getDescription());
        item.setVolume(BigDecimal.TEN);

        // test when grower don't have account
        creditService.validateGrowerAccount(item, creditConsumptionImportDTO, Boolean.TRUE);
    }

    @Test
    public void validate_grower_account_not_validate_account() throws ManualCreditConstraintException,
            BusinessException {

        this.setupDBUnit(false);

        List<CreditConsumptionImportDTO> listImportDTO = createOneImportDTOItem();
        CreditConsumptionImportDTO creditConsumptionImportDTO = listImportDTO.get(0);

        Technology technology = (Technology) getSession().get(Technology.class, 900000001L);
        Assert.assertNotNull(technology);

        CreditConsumptionItemDTO item = new CreditConsumptionItemDTO();
        item.setTechnology(technology.getDescription());
        item.setVolume(BigDecimal.TEN);

        OperationalYear operationalYear = (OperationalYear) getSession().get(OperationalYear.class, 900000001L);
        Assert.assertNotNull(operationalYear);

        // generate manual credit less than credit consumption
        accountService.generateCreditManually(creditConsumptionImportDTO.getCrop(), operationalYear,
                creditConsumptionImportDTO.getTechnology(), creditConsumptionImportDTO.getGrower(),
                ManualCreditTransactionType.CREDIT, BigDecimal.ONE, "x", loggedUser.getLogin());

        // test when grower don't have account
        creditService.validateGrowerAccount(item, creditConsumptionImportDTO, Boolean.FALSE);
    }

    @Test
    public void validate_credit_consumption() throws CreditConsumptionConstraintException, GrowerNotFoundException,
            UserNotFoundException, CustomerNotFoundException, CustomerNotAllowedException, DocumentMismatchException {
        this.setupDBUnit(false);
        CreditConsumptionItemDTO item = createCreditConsumptionItemDTO(Boolean.TRUE);
        CreditConsumptionImportDTO creditConsumptionImportDTO = creditService.validateCreditConsumption(item,
                Boolean.TRUE);
        Assert.assertNotNull(creditConsumptionImportDTO);

    }

    @Test(expected = CreditConsumptionConstraintException.class)
    public void validate_credit_consumption_balance_overflow() throws CreditConsumptionConstraintException,
            GrowerNotFoundException, UserNotFoundException, CustomerNotFoundException, CustomerNotAllowedException,
            DocumentMismatchException {
        this.setupDBUnit(false);
        CreditConsumptionItemDTO item = createCreditConsumptionItemDTO(Boolean.TRUE);
        item.setVolume(BigDecimal.TEN);
        creditService.validateCreditConsumption(item, Boolean.TRUE);
    }

    @Test
    public void validate_credit_consumption_not_validate_account() throws CreditConsumptionConstraintException,
            GrowerNotFoundException, UserNotFoundException, CustomerNotFoundException, CustomerNotAllowedException,
            DocumentMismatchException {
        this.setupDBUnit(false);
        CreditConsumptionItemDTO item = createCreditConsumptionItemDTO(Boolean.TRUE);
        CreditConsumptionImportDTO creditConsumptionImportDTO = creditService.validateCreditConsumption(item,
                Boolean.FALSE);
        Assert.assertNotNull(creditConsumptionImportDTO);
    }

    @Test(expected = CreditConsumptionConstraintException.class)
    public void validate_credit_consumption_affiliate_not_vigor() throws CreditConsumptionConstraintException,
            GrowerNotFoundException, UserNotFoundException, CustomerNotFoundException, CustomerNotAllowedException,
            DocumentMismatchException {
        this.setupDBUnit(false);
        CreditConsumptionItemDTO item = createCreditConsumptionItemDTO(Boolean.FALSE);
        CreditConsumptionImportDTO creditConsumptionImportDTO = creditService.validateCreditConsumption(item,
                Boolean.TRUE);
        Assert.assertNotNull(creditConsumptionImportDTO);
    }

    @Test
    public void validate_select_credit_consumption_by_id_use_dao_with_parameter() throws CreditConsumptionNotFoundException {
        // @Given a credit service
        CreditServiceImpl service = new CreditServiceImpl();
        CreditDAO dao = mock(CreditDAO.class);
        service.setCreditDAO(dao);
        long id = 516513L;
        ArgumentCaptor<Long> idArgumentCaptor = ArgumentCaptor.forClass(Long.class);

        // @When
        service.selectCreditConsumption(id);
        verify(dao).selectCreditConsumptionById(idArgumentCaptor.capture());

        // @Then
        org.fest.assertions.Assertions.assertThat(idArgumentCaptor.getValue()).isEqualTo(id);
    }

    private List<CreditConsumptionImportDTO> createOneImportDTOItem() {
        List<CreditConsumptionImportDTO> listImportDTO = new ArrayList<CreditConsumptionImportDTO>();
        Crop crop = (Crop) getSession().get(Crop.class, 900000001L);
        Assert.assertNotNull(crop);
        Company company = (Company) getSession().get(Company.class, 900000001L);
        Assert.assertNotNull(company);
        HeadOffice headOffice = (HeadOffice) getSession().get(HeadOffice.class, 900000001L);
        Assert.assertNotNull(headOffice);
        Technology technology = (Technology) getSession().get(Technology.class, 900000001L);
        Assert.assertNotNull(technology);
        ItsUserDTO itsUserDTO = this.userService.getByLogin(loggedUser.getLogin());
        Assert.assertNotNull(itsUserDTO);

        Integer lineNumber = 2; // line 1 is csv header
        CreditConsumptionImportDTO importDTO = new CreditConsumptionImportDTO();
        importDTO.setCompany(company);
        importDTO.setCrop(crop);
        importDTO.setGrower(growerMaria);
        importDTO.setHeadOffice(headOffice);
        importDTO.setLineNumber(lineNumber);
        importDTO.setTechnology(technology);
        importDTO.setMatrix(headOffice.getMatrix());
        importDTO.setUser(itsUserDTO);
        importDTO.setVolume(BigDecimal.TEN);
        listImportDTO.add(importDTO);
        return listImportDTO;
    }

    private CreditConsumptionItemDTO createCreditConsumptionItemDTO(Boolean createVigor) {
        Crop crop = (Crop) getSession().get(Crop.class, 900000001L);
        Assert.assertNotNull(crop);
        Company company = (Company) getSession().get(Company.class, 900000001L);
        Assert.assertNotNull(company);
        HeadOffice headOffice = (HeadOffice) getSession().get(HeadOffice.class, 900000001L);
        Assert.assertNotNull(headOffice);
        Technology technology = (Technology) getSession().get(Technology.class, 900000001L);
        Assert.assertNotNull(technology);

        if (createVigor) {
            createVigor(headOffice);
        }

        CreditConsumptionItemDTO item = new CreditConsumptionItemDTO();
        item.setTechnology(technology.getDescription());
        item.setVolume(BigDecimal.ONE);
        item.setAffiliateDocumentNumber(headOffice.getCustomerDocumentValue());
        item.setAffiliateDocumentType("_CNPJ_");
        item.setCompanyDescription(company.getDescription());
        item.setCropDescription(crop.getDescription());
        item.setGrowerDocumentNumber(growerZe.getDocumentValue());
        item.setGrowerDocumentType(growerZe.getDocument().getDocumentTypeDescription());

        item.setLineNumber(1);
        item.setMatrixDocumentNumber(customer.getDocumentValue());
        item.setUserLogin(loggedUser.getLogin());
        return item;
    }

    private void createVigor(HeadOffice headOffice) {
        HeadOfficeDetail detail = new HeadOfficeDetail();
        detail.setHeadoffice(headOffice);
        detail.setReportRol(Boolean.FALSE);
        detail.setShowParticipantInList(Boolean.FALSE);
        saveAndFlush(detail);

        HeadOfficeEffectiveDate dates = new HeadOfficeEffectiveDate();
        dates.setEndDate(CalendarUtil.getDate(2500, 12, 1));
        dates.setInitDate(CalendarUtil.getDate(1900, 1, 1));
        dates.setHeadOfficeDetail(detail);
        saveAndFlush(dates);
    }

    private List<CreditConsumptionImportDTO> createTwoImportDTOItemsDifferentGrower() {
        List<CreditConsumptionImportDTO> listImportDTO = new ArrayList<CreditConsumptionImportDTO>();
        Crop crop = (Crop) getSession().get(Crop.class, 900000001L);
        Assert.assertNotNull(crop);
        Company company = (Company) getSession().get(Company.class, 900000001L);
        Assert.assertNotNull(company);
        HeadOffice headOffice = (HeadOffice) getSession().get(HeadOffice.class, 900000001L);
        Assert.assertNotNull(headOffice);
        Technology technology = (Technology) getSession().get(Technology.class, 900000001L);
        Assert.assertNotNull(technology);
        ItsUserDTO itsUserDTO = this.userService.getByLogin(loggedUser.getLogin());
        Assert.assertNotNull(itsUserDTO);

        Integer lineNumber = 2; // line 1 is csv header
        CreditConsumptionImportDTO importDTO = new CreditConsumptionImportDTO();
        importDTO.setCompany(company);
        importDTO.setCrop(crop);
        importDTO.setGrower(growerZe);
        importDTO.setHeadOffice(headOffice);
        importDTO.setLineNumber(lineNumber);
        importDTO.setTechnology(technology);
        importDTO.setMatrix(headOffice.getMatrix());
        importDTO.setUser(itsUserDTO);
        importDTO.setVolume(BigDecimal.ONE);
        listImportDTO.add(importDTO);

        CreditConsumptionImportDTO importDTO2 = new CreditConsumptionImportDTO();
        importDTO2.setCompany(company);
        importDTO2.setCrop(crop);
        importDTO2.setGrower(growerAntonia);
        importDTO2.setHeadOffice(headOffice);
        importDTO2.setLineNumber(lineNumber++);
        importDTO2.setTechnology(technology);
        importDTO2.setMatrix(headOffice.getMatrix());
        importDTO2.setUser(itsUserDTO);
        importDTO2.setVolume(BigDecimal.ONE);
        listImportDTO.add(importDTO2);
        return listImportDTO;
    }

    private List<CreditConsumptionImportDTO> createThreeImportDTOItemsSameGrowerDiffTechnology() {
        List<CreditConsumptionImportDTO> listImportDTO = new ArrayList<CreditConsumptionImportDTO>();
        Crop crop = (Crop) getSession().get(Crop.class, 900000001L);
        Assert.assertNotNull(crop);
        Company company = (Company) getSession().get(Company.class, 900000001L);
        Assert.assertNotNull(company);
        HeadOffice headOffice = (HeadOffice) getSession().get(HeadOffice.class, 900000001L);
        Assert.assertNotNull(headOffice);
        Technology intacta = (Technology) getSession().get(Technology.class, 900000001L);
        Assert.assertNotNull(intacta);
        Technology rr = (Technology) getSession().get(Technology.class, 900000003L);
        Assert.assertNotNull(rr);
        ItsUserDTO itsUserDTO = this.userService.getByLogin(loggedUser.getLogin());
        Assert.assertNotNull(itsUserDTO);

        Integer lineNumber = 2; // line 1 is csv header
        CreditConsumptionImportDTO importDTO = new CreditConsumptionImportDTO();
        importDTO.setCompany(company);
        importDTO.setCrop(crop);
        importDTO.setGrower(growerPedro);
        importDTO.setHeadOffice(headOffice);
        importDTO.setLineNumber(lineNumber);
        importDTO.setTechnology(intacta);
        importDTO.setMatrix(headOffice.getMatrix());
        importDTO.setUser(itsUserDTO);
        importDTO.setVolume(BigDecimal.ONE);
        listImportDTO.add(importDTO);

        CreditConsumptionImportDTO importDTO2 = new CreditConsumptionImportDTO();
        importDTO2.setCompany(company);
        importDTO2.setCrop(crop);
        importDTO2.setGrower(growerPedro);
        importDTO2.setHeadOffice(headOffice);
        importDTO2.setLineNumber(lineNumber++);
        importDTO2.setTechnology(rr);
        importDTO2.setMatrix(headOffice.getMatrix());
        importDTO2.setUser(itsUserDTO);
        importDTO2.setVolume(BigDecimal.ONE);
        listImportDTO.add(importDTO2);

        CreditConsumptionImportDTO importDTO3 = new CreditConsumptionImportDTO();
        importDTO3.setCompany(company);
        importDTO3.setCrop(crop);
        importDTO3.setGrower(growerPedro);
        importDTO3.setHeadOffice(headOffice);
        importDTO3.setLineNumber(lineNumber++);
        importDTO3.setTechnology(intacta);
        importDTO3.setMatrix(headOffice.getMatrix());
        importDTO3.setUser(itsUserDTO);
        importDTO3.setVolume(BigDecimal.ONE);
        listImportDTO.add(importDTO3);

        return listImportDTO;
    }

    private List<CreditConsumptionImportDTO> createThreeImportDTOItemsSameGrowerDiffTechnologyOverFlow() {
        List<CreditConsumptionImportDTO> listImportDTO = new ArrayList<CreditConsumptionImportDTO>();
        Crop crop = (Crop) getSession().get(Crop.class, 900000001L);
        Assert.assertNotNull(crop);
        Company company = (Company) getSession().get(Company.class, 900000001L);
        Assert.assertNotNull(company);
        HeadOffice headOffice = (HeadOffice) getSession().get(HeadOffice.class, 900000001L);
        Assert.assertNotNull(headOffice);
        Technology intacta = (Technology) getSession().get(Technology.class, 900000001L);
        Assert.assertNotNull(intacta);
        Technology rr = (Technology) getSession().get(Technology.class, 900000003L);
        Assert.assertNotNull(rr);
        ItsUserDTO itsUserDTO = this.userService.getByLogin(loggedUser.getLogin());
        Assert.assertNotNull(itsUserDTO);

        Integer lineNumber = 2; // line 1 is csv header
        CreditConsumptionImportDTO importDTO = new CreditConsumptionImportDTO();
        importDTO.setCompany(company);
        importDTO.setCrop(crop);
        importDTO.setGrower(growerPedro);
        importDTO.setHeadOffice(headOffice);
        importDTO.setLineNumber(lineNumber);
        importDTO.setTechnology(intacta);
        importDTO.setMatrix(headOffice.getMatrix());
        importDTO.setUser(itsUserDTO);
        importDTO.setVolume(BigDecimal.ONE);
        listImportDTO.add(importDTO);

        CreditConsumptionImportDTO importDTO2 = new CreditConsumptionImportDTO();
        importDTO2.setCompany(company);
        importDTO2.setCrop(crop);
        importDTO2.setGrower(growerPedro);
        importDTO2.setHeadOffice(headOffice);
        importDTO2.setLineNumber(lineNumber++);
        importDTO2.setTechnology(rr);
        importDTO2.setMatrix(headOffice.getMatrix());
        importDTO2.setUser(itsUserDTO);
        importDTO2.setVolume(BigDecimal.ONE);
        listImportDTO.add(importDTO2);

        CreditConsumptionImportDTO importDTO3 = new CreditConsumptionImportDTO();
        importDTO3.setCompany(company);
        importDTO3.setCrop(crop);
        importDTO3.setGrower(growerPedro);
        importDTO3.setHeadOffice(headOffice);
        importDTO3.setLineNumber(lineNumber++);
        importDTO3.setTechnology(intacta);
        importDTO3.setMatrix(headOffice.getMatrix());
        importDTO3.setUser(itsUserDTO);
        importDTO3.setVolume(BigDecimal.TEN);
        listImportDTO.add(importDTO3);

        return listImportDTO;
    }

}
