package com.monsanto.brazilvaluecapture.pod.rol.model.bean;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import junit.framework.Assert;

import org.junit.Test;

import com.monsanto.brazilvaluecapture.core.base.model.bean.OperationalYear;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Contract;
import com.monsanto.brazilvaluecapture.core.foundation.util.CalendarUtil;

/**
 * @author cmiranda
 * 
 */
public class ReportOnlinePeriodDTO_UT {

    @Test
    public void sanity_test_constructor_limit_date_null() {

        // Build original operational year list
        List<OperationalYear> operationalYears = new ArrayList<OperationalYear>();
        operationalYears.add(new OperationalYear("2009"));
        operationalYears.add(new OperationalYear("2010"));
        operationalYears.add(new OperationalYear("2011"));
        operationalYears.add(new OperationalYear("2012"));

        // create contract
        Contract contract = new Contract();
        contract.setStartDate(CalendarUtil.getDate(2010, Calendar.JANUARY));
        contract.setEndDate(CalendarUtil.getDate(2011, Calendar.JANUARY));

        // Create dto
        ReportOnlinePeriodDTO dto = new ReportOnlinePeriodDTO(contract, null);

        // set operational years
        dto.setOperationalYears(operationalYears);

        // Start date must be same the contract date
        Assert.assertEquals(2, dto.getOperationalYears().size());
        Assert.assertFalse(dto.getOperationalYears().contains(operationalYears.get(0)));
        Assert.assertTrue(dto.getOperationalYears().contains(operationalYears.get(1)));
        Assert.assertTrue(dto.getOperationalYears().contains(operationalYears.get(2)));
        Assert.assertFalse(dto.getOperationalYears().contains(operationalYears.get(3)));

    }

    @Test
    public void sanity_test_constructor_limit_date_greate_then_contract_start_date() {

        // Build original operational year list
        List<OperationalYear> operationalYears = new ArrayList<OperationalYear>();
        operationalYears.add(new OperationalYear("2009"));
        operationalYears.add(new OperationalYear("2010"));
        operationalYears.add(new OperationalYear("2011"));
        operationalYears.add(new OperationalYear("2012"));
        operationalYears.add(new OperationalYear("2013"));

        // create contract
        Contract contract = new Contract();
        contract.setStartDate(CalendarUtil.getDate(2010, Calendar.JANUARY));
        contract.setEndDate(CalendarUtil.getDate(2012, Calendar.JANUARY));

        // Create dto
        ReportOnlinePeriodDTO dto = new ReportOnlinePeriodDTO(contract, CalendarUtil.getDate(2011, Calendar.JANUARY));

        // set operational years
        dto.setOperationalYears(operationalYears);

        // Start date must be same the contract date
        Assert.assertEquals(2, dto.getOperationalYears().size());
        Assert.assertFalse(dto.getOperationalYears().contains(operationalYears.get(0)));
        Assert.assertFalse(dto.getOperationalYears().contains(operationalYears.get(1)));
        Assert.assertTrue(dto.getOperationalYears().contains(operationalYears.get(2)));
        Assert.assertTrue(dto.getOperationalYears().contains(operationalYears.get(3)));
        Assert.assertFalse(dto.getOperationalYears().contains(operationalYears.get(4)));

    }

    @Test
    public void test_get_list_of_months() {

        // Build original operational year list
        List<OperationalYear> operationalYears = new ArrayList<OperationalYear>();
        operationalYears.add(new OperationalYear("2009"));
        operationalYears.add(new OperationalYear("2010"));

        // create contract
        Contract contract = new Contract();
        contract.setStartDate(CalendarUtil.getDate(2009, Calendar.NOVEMBER));
        contract.setEndDate(CalendarUtil.getDate(2010, Calendar.JANUARY));

        // Create dto
        ReportOnlinePeriodDTO dto = new ReportOnlinePeriodDTO(contract, CalendarUtil.getDate(2009, Calendar.JANUARY));

        // set operational years
        dto.setOperationalYears(operationalYears);

        // Start date must be same the contract date
        Assert.assertEquals(2, dto.getOperationalYears().size());

        // Load months for 2009
        dto.loadMonthsByOperationalYear(operationalYears.get(0));
        Assert.assertEquals(2, dto.getListMonths().size());

        // Look for November and December
        Assert.assertEquals(new Integer(Calendar.NOVEMBER), dto.getListMonths().get(0));
        Assert.assertEquals(new Integer(Calendar.DECEMBER), dto.getListMonths().get(1));

    }

    @Test
    public void test_get_list_of_months_superior_limit() {

        // Build original operational year list
        List<OperationalYear> operationalYears = new ArrayList<OperationalYear>();
        operationalYears.add(new OperationalYear("2009"));
        operationalYears.add(new OperationalYear("2010"));

        // create contract
        Contract contract = new Contract();
        contract.setStartDate(CalendarUtil.getDate(2009, Calendar.NOVEMBER));
        contract.setEndDate(CalendarUtil.getDate(2010, Calendar.MARCH));

        // Create dto
        ReportOnlinePeriodDTO dto = new ReportOnlinePeriodDTO(contract, CalendarUtil.getDate(2009, Calendar.JANUARY));

        // set operational years
        dto.setOperationalYears(operationalYears);

        // Start date must be same the contract date
        Assert.assertEquals(2, dto.getOperationalYears().size());

        // Load months for 2010
        dto.loadMonthsByOperationalYear(operationalYears.get(1));
        Assert.assertEquals(12, dto.getListMonths().size());

        // Look for November and December
        Assert.assertEquals(new Integer(Calendar.JANUARY), dto.getListMonths().get(0));
        Assert.assertEquals(new Integer(Calendar.FEBRUARY), dto.getListMonths().get(1));
        Assert.assertEquals(new Integer(Calendar.MARCH), dto.getListMonths().get(2));
        // ...
        Assert.assertEquals(new Integer(Calendar.DECEMBER), dto.getListMonths().get(11));

        Assert.assertEquals(new Integer(Calendar.DECEMBER), dto.getLastMonth());

    }

    @Test
    public void test_load_months_with_null_operational_year() {

        // create contract
        Contract contract = new Contract();
        contract.setStartDate(CalendarUtil.getDate(2009, Calendar.NOVEMBER));
        contract.setEndDate(CalendarUtil.getDate(2010, Calendar.MARCH));

        // Create dto
        ReportOnlinePeriodDTO dto = new ReportOnlinePeriodDTO(contract, CalendarUtil.getDate(2009, Calendar.JANUARY));

        // Verify contract
        Assert.assertEquals(contract, dto.getContract());

        // Load months for 2010
        Assert.assertNull(dto.loadMonthsByOperationalYear(null));

        Assert.assertEquals(new Integer(Calendar.JANUARY), dto.getLastMonth());

    }
}
