package com.monsanto.brazilvaluecapture.pod.credit.service.impl;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import java.io.InputStream;
import java.util.Locale;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

import com.monsanto.brazilvaluecapture.core.foundation.util.csv.CSVReadableInvalidException;
import com.monsanto.brazilvaluecapture.core.user.model.bean.UserDecorator;
import com.monsanto.brazilvaluecapture.pod.credit.service.CreditService;

public class CreditConsumptionFileParser_UT {

    private CreditConsumptionFileParser creditConsumptionFileParser;
    private CreditConsumptionParserResult creditConsumptionParserResultMock;
    private CreditService creditServiceMock;
    private static String companySelected = "MONSANTO";
    private static String matrixSelected = "44555666000177";
    private static String cropDescription = "SOJA";
    private static String filename = "creditconsumption.csv";
    private InputStream inputStream;
    private Locale locale = Locale.getDefault();

    @Before
    public void setUp() throws Exception {
        inputStream = Mockito.mock(InputStream.class);
         creditServiceMock = Mockito.mock(CreditService.class);

        UserDecorator userDecorator = Mockito.mock(UserDecorator.class);
        Mockito.when(userDecorator.getLogin()).thenReturn("Jose");
        Mockito.when(inputStream.read()).thenReturn(1);
        creditConsumptionFileParser = new CreditConsumptionFileParser(inputStream, locale, creditServiceMock,
                userDecorator, companySelected, matrixSelected, cropDescription, filename);
        creditConsumptionParserResultMock = Mockito.mock(CreditConsumptionParserResult.class);
        creditConsumptionFileParser.setCreditConsumptionParserResult(creditConsumptionParserResultMock);
        creditConsumptionFileParser.setCreditService(creditServiceMock);
    }

    @Test(expected = CSVReadableInvalidException.class)
    public void testReadFile() throws CSVReadableInvalidException {
            creditConsumptionFileParser.readFile();
    }

    @Test
    public void test_process_with_success() {
        creditConsumptionFileParser.process();
        Mockito.when(creditConsumptionParserResultMock.countSucceededCreditConsumption()).thenReturn(1);
        assertTrue(creditConsumptionFileParser.getCreditConsumptionParserResult().countSucceededCreditConsumption() > 0);
    }

    @Test
    public void test_Get_Error_Lines_with_warnings() {
        Mockito.when(creditConsumptionParserResultMock.countCreditConsumptionWithWarning()).thenReturn(1);
        assertTrue(creditConsumptionFileParser.getErrorLines() > 0);
    }

    @Test
    public void test_get_error_lines_non_warnings() {
        final int noWarnings = 0;
        assertEquals(noWarnings, creditConsumptionFileParser.getErrorLines());
    }

    @Test
    public void test_Get_Success_Lines() {
        Mockito.when(creditConsumptionParserResultMock.countSucceededCreditConsumption()).thenReturn(1);
        assertTrue(creditConsumptionFileParser.getSuccessLines() > 0);
    }

    @Test
    public void test_Has_Success_is_false() {
        assertFalse(creditConsumptionFileParser.hasSuccess());
    }

    @Test
    public void test_Has_Sucess_is_true() {
        Mockito.when(creditConsumptionParserResultMock.countSucceededCreditConsumption()).thenReturn(1);
        assertTrue(creditConsumptionFileParser.hasSuccess());
    }

    @Test
    public void test_Lines_To_Process_is_valid() {
        Mockito.when(creditConsumptionParserResultMock.hasCorrectCreditConsumption()).thenReturn(true);
        assertTrue(creditConsumptionFileParser.isLinesToProcess());
    }
    
    @Test
    public void test_there_is_not_lines_to_process() {
        assertFalse(creditConsumptionFileParser.isLinesToProcess());
    }

    @Test
    public void test_has_error() {
        assertNull(creditConsumptionFileParser.hasError(null));
    }

    @Test
    public void test_get_credit_service_not_null() {
        assertNotNull(creditConsumptionFileParser.getCreditService());
    }

    @Test
    public void test_constructor() {
        InputStream inputStream = Mockito.mock(InputStream.class);
        UserDecorator userDecorator = Mockito.mock(UserDecorator.class);
        CreditConsumptionFileParser parser = new CreditConsumptionFileParser(inputStream, creditServiceMock,
                companySelected, matrixSelected, cropDescription, userDecorator);
        assertNotNull(parser);
    }

}
