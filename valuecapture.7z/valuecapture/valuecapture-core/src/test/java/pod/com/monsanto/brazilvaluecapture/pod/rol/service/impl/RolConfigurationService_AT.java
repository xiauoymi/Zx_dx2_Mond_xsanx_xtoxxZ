package com.monsanto.brazilvaluecapture.pod.rol.service.impl;

import org.junit.Assert;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.monsanto.brazilvaluecapture.core.base.model.bean.Company;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Crop;
import com.monsanto.brazilvaluecapture.core.foundation.service.BusinessException;
import com.monsanto.brazilvaluecapture.core.foundation.service.EntityNotFoundException;
import com.monsanto.brazilvaluecapture.core.foundation.test.AbstractServiceIntegrationTests;
import com.monsanto.brazilvaluecapture.core.foundation.test.dbunit.DbUnitHelper;
import com.monsanto.brazilvaluecapture.pod.rol.model.bean.RolConfiguration;
import com.monsanto.brazilvaluecapture.pod.rol.model.service.RolConfigurationService;

/**
 * Unity test for Rol Configuration
 * 
 */
public class RolConfigurationService_AT extends AbstractServiceIntegrationTests {

    /**
     * 
     */
    @Autowired
    private RolConfigurationService rolConfigurationService;

    /**
     * 
     */
    public void setupDBUnit() {

        // Load dbunit
        // Load dbunit
        DbUnitHelper.setup("classpath:data/core/fixture-system-dataset.xml",
                "classpath:data/core/participant-dataset.xml", "classpath:data/pod/rol/rol-configuration-dataset.xml");

    }

    /**
     * 
     */
    @Test(expected = IllegalArgumentException.class)
    public void test_select_rol_configuration_with_null_id() throws BusinessException {
        rolConfigurationService.selectRolConfiguration(null, null);
    }

    /**
     * 
     */
    @Test(expected = IllegalArgumentException.class)
    public void test_select_rol_configuration_with_null_company() throws BusinessException {
        rolConfigurationService.selectRolConfiguration(new Crop(), null);
    }

    /**
     * 
     */
    @Test(expected = IllegalArgumentException.class)
    public void test_select_rol_configuration_with_null_crop() throws BusinessException {
        rolConfigurationService.selectRolConfiguration(null, new Company());
    }

    /**
     * 
     */
    @Test(expected = EntityNotFoundException.class)
    public void test_select_rol_configuration_with_invalid_filter_expected_entity_not_found() throws BusinessException {

        // Load data base
        setupDBUnit();

        // Load filter that dont have any configuration on data base
        Crop crop = (Crop) getSession().get(Crop.class, 900000001L);
        Company company = (Company) getSession().get(Company.class, 900000001L);

        // Search
        rolConfigurationService.selectRolConfiguration(crop, company);
    }

    /**
     * 
     */
    @Test
    public void test_select_rol_configuration() throws BusinessException {

        // Load data base
        setupDBUnit();

        // Load filter that dont have any configuration on data base
        Crop crop = (Crop) getSession().get(Crop.class, 900000001L);
        Company company = (Company) getSession().get(Company.class, 990000002L);

        // Search
        RolConfiguration rol = rolConfigurationService.selectRolConfiguration(crop, company);
        Assert.assertNotNull(rol);
    }

}
