package com.monsanto.brazilvaluecapture.pod.rol.service.impl;

import java.math.BigDecimal;
import java.util.Date;
import java.util.HashSet;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.monsanto.brazilvaluecapture.core.base.model.bean.Company;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Country;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Crop;
import com.monsanto.brazilvaluecapture.core.base.model.bean.OperationalYear;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Customer;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.HeadOffice;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.ParticipantTypeEnum;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Technology;
import com.monsanto.brazilvaluecapture.core.foundation.RandomTestData;
import com.monsanto.brazilvaluecapture.pod.rol.model.bean.GroupAction;
import com.monsanto.brazilvaluecapture.pod.rol.model.bean.OperationalYearType;
import com.monsanto.brazilvaluecapture.pod.rol.model.bean.ReportOnLine;
import com.monsanto.brazilvaluecapture.pod.rol.model.bean.RolFrameGroup;
import com.monsanto.brazilvaluecapture.pod.rol.model.bean.RolParameter;
import com.monsanto.brazilvaluecapture.pod.rol.model.bean.RolStatus;
import com.monsanto.brazilvaluecapture.pod.rol.model.bean.UsedRolParameter;
import com.monsanto.brazilvaluecapture.pod.rol.model.service.impl.ReportOnLineStateMachine;

public class ReportOnlineStateMachine_UT {

    private ReportOnLine reportOnLine;
    private Crop crop;
    private Company company;
    private HeadOffice headoffice;
    private OperationalYear operationalYear;
    private RolParameter paramrolFixedOccurrIntacta;
    private RolParameter paramrolFixedOccurrRR;
    private UsedRolParameter u1;
    private UsedRolParameter u2;

    @Before
    public void ReportOnlineStateMachine() {
        reportOnLine = buildReportOnline();
    }

    /**
     * run the test for approval RolStatus Released equal billing because the
     * price is lower than the variation
     */
    @Test
    public void test_approval_rol_analisys_rtv_lower_variation() {
        RolStatus rolStatus = new RolStatus();
        rolStatus.setId(new Long(1L));
        rolStatus.setRolStatusCode(RolStatus.ROL_STATUS_RTV);
        rolStatus.setRolStatusOrder((short) 1);
        rolStatus.setRolStatusBundle("pod.rol.parameter.status.rtv");
        reportOnLine.setRolStatus(rolStatus);
        String validateStatusRol = ReportOnLineStateMachine.approvalRol(reportOnLine);
        Assert.assertTrue("The new status rol will be released for billing",
                validateStatusRol.equals(RolStatus.ROL_STATUS_RELEASED));
    }

    /**
     * run the test for approval RolStatus Analysis equal to GR because the
     * price is greater than the variation
     */
    @Test
    public void test_approval_rol_analisys_rtv_greater_variation() {
        // Used param 1 -- intacta fixed paid
        u1 = new UsedRolParameter();
        u1.setReportOnLine(reportOnLine);
        u1.setRolParameter(paramrolFixedOccurrIntacta);
        u1.setUsedRolParameterTonValue(new BigDecimal("2"));
        u1.setUsedRolParamMonetaryVal(new BigDecimal("22"));
        u1.setUsedRolParamStripeValue(222L);
        u1.setUsedRolParamAverageVal(BigDecimal.TEN);
        u1.setCounterPrice(new BigDecimal(20.00));
        u1.setMaximumVariation(new BigDecimal("10"));
        reportOnLine.getUsedRolParameters().add(u1);

        RolStatus rolStatus = new RolStatus();
        rolStatus.setId(new Long(1L));
        rolStatus.setRolStatusCode(RolStatus.ROL_STATUS_RTV);
        rolStatus.setRolStatusOrder((short) 1);
        rolStatus.setRolStatusBundle("pod.rol.parameter.status.rtv");
        reportOnLine.setRolStatus(rolStatus);

        String validateStatusRol = ReportOnLineStateMachine.approvalRol(reportOnLine);
        Assert.assertTrue("The new status rol will be GR analisys", validateStatusRol.equals(RolStatus.ROL_STATUS_GR));
    }

    /**
     * performs the test to fail RolStatus equal to Correct report
     */
    @Test
    public void test_reprove_rol_analisys_rtv() {
        RolStatus rolStatus = new RolStatus();
        rolStatus.setId(new Long(1L));
        rolStatus.setRolStatusCode(RolStatus.ROL_STATUS_RTV);
        rolStatus.setRolStatusOrder((short) 1);
        rolStatus.setRolStatusBundle("pod.rol.parameter.status.rtv");
        reportOnLine.setRolStatus(rolStatus);
        String validateStatusRol = ReportOnLineStateMachine.disapprovalRol(reportOnLine);
        Assert.assertTrue("The new status ROl will be the correct reporting",
                validateStatusRol.equals(RolStatus.ROL_STATUS_CORRECTED));
    }

    /**
     * run the test for approval RolStatus equal to Released for billing
     */
    @Test
    public void test_approval_rol_analisys_gr() {
        RolStatus rolStatus = new RolStatus();
        rolStatus.setId(new Long(2L));
        rolStatus.setRolStatusCode(RolStatus.ROL_STATUS_GR);
        rolStatus.setRolStatusOrder((short) 2);
        rolStatus.setRolStatusBundle("pod.rol.parameter.status.gr");
        reportOnLine.setRolStatus(rolStatus);
        String validateStatusRol = ReportOnLineStateMachine.approvalRol(reportOnLine);
        Assert.assertTrue("The new status rol will be released for billing",
                validateStatusRol.equals(RolStatus.ROL_STATUS_RELEASED));
    }

    /**
     * performs the test to fail RolStatus equal to Correct report
     */
    @Test
    public void test_reprove_rol_analisys_gr() {
        RolStatus rolStatus = new RolStatus();
        rolStatus.setId(new Long(2L));
        rolStatus.setRolStatusCode(RolStatus.ROL_STATUS_GR);
        rolStatus.setRolStatusOrder((short) 2);
        rolStatus.setRolStatusBundle("pod.rol.parameter.status.gr");
        reportOnLine.setRolStatus(rolStatus);
        String validateStatusRol = ReportOnLineStateMachine.disapprovalRol(reportOnLine);
        Assert.assertTrue("The new status ROl will be the correct reporting",
                validateStatusRol.equals(RolStatus.ROL_STATUS_CORRECTED));
    }

    /**
     * run the test for approval RolStatus equal to Processed
     */
    @Test
    public void test_approval_rol_released_billing() {
        RolStatus rolStatus = new RolStatus();
        rolStatus.setId(new Long(3L));
        rolStatus.setRolStatusCode(RolStatus.ROL_STATUS_RELEASED);
        rolStatus.setRolStatusOrder((short) 3);
        rolStatus.setRolStatusBundle("pod.rol.parameter.status.released");
        reportOnLine.setRolStatus(rolStatus);
        String validateStatusRol = ReportOnLineStateMachine.approvalRol(reportOnLine);
        Assert.assertTrue("The new status rol will be released for billing",
                validateStatusRol.equals(RolStatus.ROL_STATUS_PROCESSED));
    }

    /**
     * performs the test to fail RolStatus equal to Correct report
     */
    @Test
    public void test_reprove_rol_released_billing() {
        RolStatus rolStatus = new RolStatus();
        rolStatus.setId(new Long(3L));
        rolStatus.setRolStatusCode(RolStatus.ROL_STATUS_RELEASED);
        rolStatus.setRolStatusOrder((short) 3);
        rolStatus.setRolStatusBundle("pod.rol.parameter.status.released");
        reportOnLine.setRolStatus(rolStatus);
        String validateStatusRol = ReportOnLineStateMachine.disapprovalRol(reportOnLine);
        Assert.assertTrue("The new status ROl will be the correct reporting",
                validateStatusRol.equals(RolStatus.ROL_STATUS_CORRECTED));
    }

    /**
     * performs the test to fail RolStatus equal to Correct report
     */
    @Test
    public void test_reprove_rol_processed() {
        RolStatus rolStatus = new RolStatus();
        rolStatus.setId(new Long(4L));
        rolStatus.setRolStatusCode(RolStatus.ROL_STATUS_PROCESSED);
        rolStatus.setRolStatusOrder((short) 4);
        rolStatus.setRolStatusBundle("pod.rol.parameter.status.process");
        reportOnLine.setRolStatus(rolStatus);
        String validateStatusRol = ReportOnLineStateMachine.disapprovalRol(reportOnLine);
        Assert.assertTrue("The new status ROl will be the correct reporting",
                validateStatusRol.equals(RolStatus.ROL_STATUS_CORRECTED));
    }

    private ReportOnLine buildReportOnline() {
        // Create system data
        Country country = new Country("USA", "usa");
        company = new Company("monsanto");
        crop = new Crop("soya", company, country);
        Technology technologyRR = new Technology("rr", company);
        Technology technologyIntacta = new Technology("intact", company);
        operationalYear = new OperationalYear("2012");

        // Create head office
        Customer participant = new Customer("Cebolinha", null, null, RandomTestData.createRandomLong().toString());
        Customer matrix = new Customer("Monica", null, null, RandomTestData.createRandomLong().toString());
        headoffice = new HeadOffice(participant, matrix, ParticipantTypeEnum.POD, crop, company);

        // Actions
        GroupAction groupActionCalculate = new GroupAction(-1L, GroupAction.GROUP_ACTION_CALCULATE,
                GroupAction.GROUP_ACTION_CALCULATE);

        // Frame group
        RolFrameGroup rolFrameGroupFixedOccurr = new RolFrameGroup();
        rolFrameGroupFixedOccurr.setRolFrameGroupCode(RolFrameGroup.FRAME_GROUP_FIXEDCURR);

        RolFrameGroup rolFrameGroupTestStrype = new RolFrameGroup();
        rolFrameGroupTestStrype.setRolFrameGroupCode(RolFrameGroup.FRAME_GROUP_TESTSTRYPE);

        RolFrameGroup rolFrameGroupOldTestStrype = new RolFrameGroup();
        rolFrameGroupOldTestStrype.setRolFrameGroupCode(RolFrameGroup.FRAME_GROUP_FIXEDOLD);

        // Operational year type
        OperationalYearType operationalYearType = new OperationalYearType();
        operationalYearType.setOperationalYearTypeCode("actual");
        operationalYearType.setOperationalYearTypeDiff(0);

        // Rol parameter rr fixed paid
        paramrolFixedOccurrRR = new RolParameter();
        paramrolFixedOccurrRR.setCrop(crop);
        paramrolFixedOccurrRR.setGroupAction(groupActionCalculate);
        paramrolFixedOccurrRR.setOperationalYearType(operationalYearType);
        paramrolFixedOccurrRR.setRolFrameGroup(rolFrameGroupFixedOccurr);
        paramrolFixedOccurrRR.setRolParameterDescription("paramrolFixedOccurr");
        paramrolFixedOccurrRR.setRolParameterMaterialSapId("xxx");
        paramrolFixedOccurrRR.setTechnology(technologyRR);

        // Rol parameter intacta fixed paid
        paramrolFixedOccurrIntacta = new RolParameter();
        paramrolFixedOccurrIntacta.setCrop(crop);
        paramrolFixedOccurrIntacta.setGroupAction(groupActionCalculate);
        paramrolFixedOccurrIntacta.setOperationalYearType(operationalYearType);
        paramrolFixedOccurrIntacta.setRolFrameGroup(rolFrameGroupFixedOccurr);
        paramrolFixedOccurrIntacta.setRolParameterDescription("paramrolFixedOccurr");
        paramrolFixedOccurrIntacta.setRolParameterMaterialSapId("xxx");
        paramrolFixedOccurrIntacta.setTechnology(technologyIntacta);

        // Build report
        reportOnLine = new ReportOnLine();
        reportOnLine.setCrop(crop);
        reportOnLine.setHeadoffice(headoffice);
        reportOnLine.setOperationalYear(operationalYear);
        reportOnLine.setRolCreateDate(new Date());
        reportOnLine.setRolPeriod(new Date());
        reportOnLine.setRolStatus(new RolStatus());
        reportOnLine.setUsedRolParameters(new HashSet<UsedRolParameter>());

        // Used param 2 - rr fixed paid
        u2 = new UsedRolParameter();
        u2.setReportOnLine(reportOnLine);
        u2.setRolParameter(paramrolFixedOccurrRR);
        u2.setUsedRolParameterTonValue(new BigDecimal("3"));
        u2.setUsedRolParamMonetaryVal(new BigDecimal("33"));
        u2.setUsedRolParamStripeValue(333L);
        u2.setUsedRolParamAverageVal(BigDecimal.ONE);
        u2.setCounterPrice(BigDecimal.TEN);
        reportOnLine.getUsedRolParameters().add(u2);

        return reportOnLine;
    }
}
