package com.monsanto.brazilvaluecapture.pod.rol;

import org.junit.extensions.cpsuite.ClasspathSuite;
import org.junit.extensions.cpsuite.ClasspathSuite.ClassnameFilters;
import org.junit.runner.RunWith;


@RunWith(value = ClasspathSuite.class)
@ClassnameFilters({"com.monsanto.brazilvaluecapture.pod.rol.*AT", 
				   "com.monsanto.brazilvaluecapture.pod.rol.*UT"})
public class SuiteRol {

}
