package com.monsanto.brazilvaluecapture.pod.rol.service.impl;

import java.util.ArrayList;

import junit.framework.Assert;

import org.junit.Test;

import com.monsanto.brazilvaluecapture.core.foundation.util.ConstraintViolation;
import com.monsanto.brazilvaluecapture.pod.rol.model.service.ReportOnLineConstraintException;

/**
 * @author cmiranda
 * 
 */
public class ReportOnLineConstraintException_UT {

    @Test
    public void sanity_test() {

        // Create exception
        ReportOnLineConstraintException exception = new ReportOnLineConstraintException("omg! error!",
                new ArrayList<ConstraintViolation>());

        // Add constraints
        exception.add(new ConstraintViolation("", "", ""));
        exception.add(new ConstraintViolation("xxxxxxxx", "requiredParams", "x"));
        exception.add(new ConstraintViolation("xxxxxxxx", "requiredParams", "x"));

        Assert.assertEquals(2, exception.getViolations().size());

    }

}
