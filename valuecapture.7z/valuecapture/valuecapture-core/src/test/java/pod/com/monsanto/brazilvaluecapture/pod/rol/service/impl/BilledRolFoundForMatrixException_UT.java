package com.monsanto.brazilvaluecapture.pod.rol.service.impl;

import java.util.Calendar;

import junit.framework.Assert;

import org.junit.Test;

import com.monsanto.brazilvaluecapture.core.foundation.util.CalendarUtil;
import com.monsanto.brazilvaluecapture.pod.rol.model.service.BilledRolFoundForMatrixException;

public class BilledRolFoundForMatrixException_UT {

    @Test
    public void sanity_test() {

        BilledRolFoundForMatrixException exception = new BilledRolFoundForMatrixException("x", null,
                CalendarUtil.getDate(2001, Calendar.FEBRUARY), CalendarUtil.getDate(2001, Calendar.NOVEMBER));

        exception.setAffiliate(null);
        Assert.assertNull(exception.getAffiliate());

        exception.setPeriodEnd(null);
        Assert.assertNull(exception.getPeriodEnd());

        exception.setPeriodStart(null);
        Assert.assertNull(exception.getPeriodStart());

    }

}
