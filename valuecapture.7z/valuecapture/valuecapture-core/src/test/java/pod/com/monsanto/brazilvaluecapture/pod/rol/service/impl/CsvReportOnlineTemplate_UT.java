package com.monsanto.brazilvaluecapture.pod.rol.service.impl;

import com.monsanto.brazilvaluecapture.core.base.model.bean.Company;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Technology;
import com.monsanto.brazilvaluecapture.core.foundation.service.EntityNotFoundException;
import com.monsanto.brazilvaluecapture.core.foundation.util.csv.CSVConverterEnum;
import com.monsanto.brazilvaluecapture.pod.rol.model.bean.GroupAction;
import com.monsanto.brazilvaluecapture.pod.rol.model.bean.OperationalYearType;
import com.monsanto.brazilvaluecapture.pod.rol.model.bean.RolFrameGroup;
import com.monsanto.brazilvaluecapture.pod.rol.model.bean.RolParameter;
import com.monsanto.brazilvaluecapture.pod.rol.model.service.impl.CsvReportOnlineTemplate;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * Unit test for report online template.
 * 
 * @author cmiranda
 * 
 */
public class CsvReportOnlineTemplate_UT {

    /**
     * Template generator to test
     */
    private CsvReportOnlineTemplate template;

    /**
     * Parameter list.
     */
    private List<RolParameter> parameters = new ArrayList<RolParameter>();

    private Company company = new Company("msto");
    private Technology techRR = new Technology("RR", company);
    private Technology techINTACT = new Technology("INTACTA", company);
    
    private String actualLabel;
    private String actualLabelMinus;
    private String actualLabelMinusTwo;

    /**
     * Bundle
     */
    private ResourceBundle resourceBundle = ResourceBundle.getBundle("bundle/bundle", new Locale("pt", "BR"));

    @Before
    public void setup() throws EntityNotFoundException {
    	
    	actualLabel = resourceBundle.getString("pod.rol.parameter.actual.label");
    	actualLabelMinus = resourceBundle.getString("pod.rol.parameter.actual.label.one");
    	actualLabelMinusTwo = resourceBundle.getString("pod.rol.parameter.actual.label.two");

        // Set tech id to sort.
        techRR.setId(1L);
        techINTACT.setId(2L);

        // Actions
        GroupAction groupActionCalculate = new GroupAction(-1L, GroupAction.GROUP_ACTION_CALCULATE,
                GroupAction.GROUP_ACTION_CALCULATE);

        GroupAction groupActionSum = new GroupAction(-2L, GroupAction.GROUP_ACTION_SUM, GroupAction.GROUP_ACTION_SUM);

        GroupAction groupActionNoAction = new GroupAction(-2L, GroupAction.GROUP_ACTION_SUM,
                GroupAction.GROUP_ACTION_NOACTION);

        // Frame group
        RolFrameGroup rolFrameGroupReceived = new RolFrameGroup();
        rolFrameGroupReceived.setRolFrameGroupCode(RolFrameGroup.FRAME_GROUP_RECEIVED);

        RolFrameGroup rolFrameGroupFixedOccurr = new RolFrameGroup();
        rolFrameGroupFixedOccurr.setRolFrameGroupCode(RolFrameGroup.FRAME_GROUP_FIXEDCURR);

        RolFrameGroup rolFrameGroupFixedOld = new RolFrameGroup();
        rolFrameGroupFixedOld.setRolFrameGroupCode(RolFrameGroup.FRAME_GROUP_FIXEDOLD);

        RolFrameGroup rolFrameGroupTestStripe = new RolFrameGroup();
        rolFrameGroupTestStripe.setRolFrameGroupCode(RolFrameGroup.FRAME_GROUP_TESTSTRYPE);

        // Operational year type
        OperationalYearType operationalYearTypeActualYear = new OperationalYearType();
        operationalYearTypeActualYear.setOperationalYearTypeCode("actual");
        operationalYearTypeActualYear.setOperationalYearTypeDiff(0);
        operationalYearTypeActualYear.setOperationalYearTypeBundle("pod.rol.parameter.actual.label");

        OperationalYearType operationalYearTypeLessOne = new OperationalYearType();
        operationalYearTypeLessOne.setOperationalYearTypeCode("-1");
        operationalYearTypeLessOne.setOperationalYearTypeDiff(-1);
        operationalYearTypeLessOne.setOperationalYearTypeBundle("pod.rol.parameter.actual.label.one");
        
        OperationalYearType operationalYearTypeLessTwo = new OperationalYearType();
        operationalYearTypeLessTwo.setOperationalYearTypeCode("-2");
        operationalYearTypeLessTwo.setOperationalYearTypeDiff(-2);
        operationalYearTypeLessTwo.setOperationalYearTypeBundle("pod.rol.parameter.actual.label.two");
        
        // Rol parameter received
        RolParameter rolParameter = new RolParameter();
        rolParameter.setGroupAction(groupActionNoAction);
        rolParameter.setOperationalYearType(operationalYearTypeActualYear);
        rolParameter.setRolFrameGroup(rolFrameGroupReceived);
        rolParameter.setRolParamShownDescription("received");
        rolParameter.setTechnology(techRR);
        parameters.add(rolParameter);

        rolParameter = new RolParameter();
        rolParameter.setGroupAction(groupActionNoAction);
        rolParameter.setOperationalYearType(operationalYearTypeActualYear);
        rolParameter.setRolFrameGroup(rolFrameGroupReceived);
        rolParameter.setRolParamShownDescription("received");
        rolParameter.setTechnology(techINTACT);
        parameters.add(rolParameter);

        // Rol parameter fix paid current year
        rolParameter = new RolParameter();
        rolParameter.setGroupAction(groupActionNoAction);
        rolParameter.setOperationalYearType(operationalYearTypeActualYear);
        rolParameter.setRolFrameGroup(rolFrameGroupFixedOccurr);
        rolParameter.setRolParamShownDescription("fixed paid current year");
        rolParameter.setTechnology(techRR);
        parameters.add(rolParameter);

        // Rol parameter fix paid old year -1
        rolParameter = new RolParameter();
        rolParameter.setGroupAction(groupActionNoAction);
        rolParameter.setOperationalYearType(operationalYearTypeLessOne);
        rolParameter.setRolFrameGroup(rolFrameGroupFixedOld);
        rolParameter.setRolParamShownDescription("fixed paid old year");
        rolParameter.setTechnology(techRR);
        parameters.add(rolParameter);

        // Rol parameter fix paid old year -2
        rolParameter = new RolParameter();
        rolParameter.setGroupAction(groupActionCalculate);
        rolParameter.setOperationalYearType(operationalYearTypeLessTwo);
        rolParameter.setRolFrameGroup(rolFrameGroupFixedOld);
        rolParameter.setRolParamShownDescription("fixed paid old year");
        rolParameter.setTechnology(techRR);
        parameters.add(rolParameter);

        // Rol parameter fix test stripes calculateServiceFeeValue
        rolParameter = new RolParameter();
        rolParameter.setGroupAction(groupActionCalculate);
        rolParameter.setOperationalYearType(operationalYearTypeActualYear);
        rolParameter.setRolFrameGroup(rolFrameGroupTestStripe);
        rolParameter.setRolParamShownDescription("calculateServiceFeeValue test stripe");
        rolParameter.setTechnology(techRR);
        parameters.add(rolParameter);

        // Rol parameter fix test stripes sum
        rolParameter = new RolParameter();
        rolParameter.setGroupAction(groupActionSum);
        rolParameter.setOperationalYearType(operationalYearTypeActualYear);
        rolParameter.setRolFrameGroup(rolFrameGroupTestStripe);
        rolParameter.setRolParamShownDescription("sum test stripe");
        rolParameter.setTechnology(techRR);
        parameters.add(rolParameter);

        // Rol parameter fix test stripes no action
        rolParameter = new RolParameter();
        rolParameter.setGroupAction(groupActionNoAction);
        rolParameter.setOperationalYearType(operationalYearTypeActualYear);
        rolParameter.setRolFrameGroup(rolFrameGroupTestStripe);
        rolParameter.setRolParamShownDescription("no action test stripe");
        rolParameter.setTechnology(techRR);
        parameters.add(rolParameter);

        // Create template
        template = new CsvReportOnlineTemplate(parameters, resourceBundle);

    }

    /**
     * Generate headers
     */
    @Test
    public void test_get_headers_from_template() {

        // Build headers
        List<String> headers = template.getHeaders();
        // System.out.println(headers);

        Assert.assertNotNull(headers);
        Assert.assertFalse(headers.isEmpty());

        // Validate header size expected
        Assert.assertEquals(12, headers.size());

        // Validate fix header
        int headIndex = 0;
        Assert.assertEquals("Periodo", headers.get(headIndex++));
        Assert.assertEquals("Nro. Documento Filial", headers.get(headIndex++));

        // Validate dynamic header for received volume
        Assert.assertEquals("RR - Total Qtde received - Recebido", headers.get(headIndex++));

        // Validate dynamic header for fixed paid actual year
        Assert.assertEquals("RR - Qtde. - fixed paid current year - "+actualLabel, headers.get(headIndex++));
        Assert.assertEquals("RR - Valor - fixed paid current year - "+actualLabel, headers.get(headIndex++));

        // Validate dynamic header for fixed paid old year -1
        Assert.assertEquals("RR - Qtde. - fixed paid old year - "+actualLabelMinus, headers.get(headIndex++));
        Assert.assertEquals("RR - Valor - fixed paid old year - "+actualLabelMinus, headers.get(headIndex++));

        // Validate dynamic header for fixed paid old year -2
        Assert.assertEquals("RR - Qtde. - fixed paid old year - "+actualLabelMinusTwo, headers.get(headIndex++));
        Assert.assertEquals("RR - Valor - fixed paid old year - "+actualLabelMinusTwo, headers.get(headIndex++));

        Assert.assertEquals("RR - sum test stripe", headers.get(headIndex++));
        Assert.assertEquals("RR - no action test stripe", headers.get(headIndex++));

        Assert.assertEquals("INTACTA - Total Qtde received - Recebido", headers.get(headIndex++));

    }

    /**
     * Validate
     */
    @Test
    public void test_get_type_by_column_name() {

        // Build headers
        List<String> headers = template.getHeaders();

        Assert.assertNotNull(headers);
        Assert.assertFalse(headers.isEmpty());

        Assert.assertEquals(CSVConverterEnum.NULL, template.getTypeByColumnName("Tecnologia"));
        Assert.assertEquals(CSVConverterEnum.DATE, template.getTypeByColumnName("Periodo"));
        Assert.assertEquals(CSVConverterEnum.NULL, template.getTypeByColumnName("Nro. Documento Filial"));
        Assert.assertEquals(CSVConverterEnum.DECIMAL,
                template.getTypeByColumnName("RR - Total Qtde received - Recebido"));
        Assert.assertEquals(CSVConverterEnum.DECIMAL,
                template.getTypeByColumnName("RR - Qtde. - fixed paid current year - "+actualLabel));
        Assert.assertEquals(CSVConverterEnum.DECIMAL,
                template.getTypeByColumnName("RR - Valor - fixed paid current year - "+actualLabel));
        Assert.assertEquals(CSVConverterEnum.DECIMAL,
                template.getTypeByColumnName("RR - Qtde. - fixed paid old year - "+actualLabelMinus));
        Assert.assertEquals(CSVConverterEnum.DECIMAL,
                template.getTypeByColumnName("RR - Valor - fixed paid old year - "+actualLabelMinus));
        Assert.assertEquals(CSVConverterEnum.DECIMAL,
                template.getTypeByColumnName("RR - Qtde. - fixed paid old year - "+actualLabelMinusTwo));
        Assert.assertEquals(CSVConverterEnum.DECIMAL,
                template.getTypeByColumnName("RR - Valor - fixed paid old year - "+actualLabelMinusTwo));
        Assert.assertEquals(CSVConverterEnum.INTEGER, template.getTypeByColumnName("RR - sum test stripe"));
        Assert.assertEquals(CSVConverterEnum.INTEGER, template.getTypeByColumnName("RR - no action test stripe"));

    }

    /**
     * 
     */
    @Test
    public void test_get_rol_parameter_by_column_name() {

        // Build headers
        List<String> headers = template.getHeaders();

        Assert.assertNotNull(headers);
        Assert.assertFalse(headers.isEmpty());

        Assert.assertEquals(null, template.getRolParameterByColumnName("Periodo"));
        Assert.assertEquals(null, template.getRolParameterByColumnName("Nro. Documento Filial"));
        Assert.assertEquals(parameters.get(0),
                template.getRolParameterByColumnName("RR - Total Qtde received - Recebido"));

        Assert.assertEquals(parameters.get(1),
                template.getRolParameterByColumnName("RR - Qtde. - fixed paid current year - "+actualLabel));
        Assert.assertEquals(parameters.get(1),
                template.getRolParameterByColumnName("RR - Valor - fixed paid current year - "+actualLabel));
        Assert.assertEquals(parameters.get(2),
                template.getRolParameterByColumnName("RR - Qtde. - fixed paid old year - "+actualLabelMinus));
        Assert.assertEquals(parameters.get(2),
                template.getRolParameterByColumnName("RR - Valor - fixed paid old year - "+actualLabelMinus));
        Assert.assertEquals(parameters.get(3),
                template.getRolParameterByColumnName("RR - Qtde. - fixed paid old year - "+actualLabelMinusTwo));
        Assert.assertEquals(parameters.get(3),
                template.getRolParameterByColumnName("RR - Valor - fixed paid old year - "+actualLabelMinusTwo));
        Assert.assertEquals(parameters.get(5), template.getRolParameterByColumnName("RR - sum test stripe"));
        Assert.assertEquals(parameters.get(6), template.getRolParameterByColumnName("RR - no action test stripe"));

        Assert.assertEquals(parameters.get(7),
                template.getRolParameterByColumnName("INTACTA - Total Qtde received - Recebido"));

    }

    /**
     * Test example.
     */
    @Test
    public void test_get_rol_tamplate_example() {

        // Build headers
        List<String> headers = template.getHeaders();

        Assert.assertNotNull(headers);
        Assert.assertFalse(headers.isEmpty());

        DateFormat df = new SimpleDateFormat("dd/MM/yyyy");
        
        System.out.println(template.getExample());
        Assert.assertEquals(template.getHeaders().size(), template.getExample().split(";").length);
        Assert.assertEquals(df.format(new Date()) + ";123.456.789/0000-21;0;0;0;0;0;0;0;0;0;0", template.getExample());

    }

    /**
     * 
     */
    @Test
    public void test_get_type_by_invalid_column_name() {

        // Build headers
        List<String> headers = template.getHeaders();

        Assert.assertNotNull(headers);
        Assert.assertFalse(headers.isEmpty());

        Assert.assertEquals(CSVConverterEnum.NULL, template.getTypeByColumnName("xxxxxxxxxxxy"));
    }

    /**
     * 
     */
    @Test
    public void test_get_rol_parameter_by__invalid_column_name() {

        // Build headers
        List<String> headers = template.getHeaders();

        Assert.assertNotNull(headers);
        Assert.assertFalse(headers.isEmpty());

        Assert.assertNull(template.getRolParameterByColumnName("xxxxxxxxxxxy"));
    }
}
