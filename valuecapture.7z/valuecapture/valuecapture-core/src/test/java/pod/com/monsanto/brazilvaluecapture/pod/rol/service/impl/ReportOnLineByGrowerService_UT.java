package com.monsanto.brazilvaluecapture.pod.rol.service.impl;

import java.math.BigDecimal;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

import com.monsanto.brazilvaluecapture.core.base.model.bean.Company;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Country;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Crop;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Document;
import com.monsanto.brazilvaluecapture.core.base.model.bean.DocumentType;
import com.monsanto.brazilvaluecapture.core.base.model.bean.OperationalYear;
import com.monsanto.brazilvaluecapture.core.base.service.BaseService;
import com.monsanto.brazilvaluecapture.core.base.service.OperationalYearService;
import com.monsanto.brazilvaluecapture.core.base.service.TechnologyService;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Contract;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Customer;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.HeadOffice;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.ParticipantTypeEnum;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Technology;
import com.monsanto.brazilvaluecapture.core.customer.service.ParticipantHeadOfficeFilter;
import com.monsanto.brazilvaluecapture.core.customer.service.ParticipantService;
import com.monsanto.brazilvaluecapture.core.foundation.service.BusinessException;
import com.monsanto.brazilvaluecapture.core.foundation.service.EntityNotFoundException;
import com.monsanto.brazilvaluecapture.core.foundation.util.CalendarUtil;
import com.monsanto.brazilvaluecapture.core.grower.model.bean.Grower;
import com.monsanto.brazilvaluecapture.core.grower.service.GrowerNotFoundException;
import com.monsanto.brazilvaluecapture.core.io.WarningImportedException;
import com.monsanto.brazilvaluecapture.pod.rol.model.bean.CsvPaidVolImportLine;
import com.monsanto.brazilvaluecapture.pod.rol.model.bean.PaidVolByGrowerItem;
import com.monsanto.brazilvaluecapture.pod.rol.model.bean.PaidVolumeByGrower;
import com.monsanto.brazilvaluecapture.pod.rol.model.bean.PaidVolumeByGrowerSearchDTO;
import com.monsanto.brazilvaluecapture.pod.rol.model.bean.ReportOnLine;
import com.monsanto.brazilvaluecapture.pod.rol.model.bean.RolParameter;
import com.monsanto.brazilvaluecapture.pod.rol.model.bean.UsedRolParameter;
import com.monsanto.brazilvaluecapture.pod.rol.model.dao.ReportOnlineByGrowerDAO;
import com.monsanto.brazilvaluecapture.pod.rol.model.service.PaidVolumeFilter;
import com.monsanto.brazilvaluecapture.pod.rol.model.service.ReportOnLineInfo;
import com.monsanto.brazilvaluecapture.pod.rol.model.service.ReportOnLineService;
import com.monsanto.brazilvaluecapture.pod.rol.model.service.ReportOnlineByGrowerConstraintException;
import com.monsanto.brazilvaluecapture.pod.rol.model.service.ReportOnlineByGrowerException;
import com.monsanto.brazilvaluecapture.pod.rol.model.service.ReportOnlineByGrowerWarningException;
import com.monsanto.brazilvaluecapture.pod.rol.model.service.impl.ReportOnLineByGrowerServiceImpl;
import com.monsanto.brazilvaluecapture.pod.rol.model.service.parser.importation.PaidVolImportParser;

/**
 * @author cmiranda
 * 
 */
public class ReportOnLineByGrowerService_UT {

    /**
     * Service whose must be tested;
     */
    private ReportOnLineByGrowerServiceImpl reportOnLineByGrowerService = new ReportOnLineByGrowerServiceImpl();

    // Services to mock
    private BaseService baseService;
    private ParticipantService participantService;
    private TechnologyService technologyService;
    private OperationalYearService operationalYearService;
    private ReportOnLineService reportOnLineService;
    private ReportOnlineByGrowerDAO reportOnlineByGrowerDAO;

    private Company company;
    private Crop crop;
    private Grower grower;
    private HeadOffice headOffice;
    private OperationalYear operationalYear;
    private Technology technologyRR;
    private Technology technologyINTACTA;
    private Technology technologyXPTO;

    @Before
    public void setup() throws GrowerNotFoundException, EntityNotFoundException {

        // Mock base data
        Country country = new Country("USA", "usa");
        company = new Company("monsanto");
        company.setCountry(country);
        crop = new Crop("soya", company, country);
        operationalYear = new OperationalYear("2011");
        technologyRR = new Technology("RR", company);
        technologyINTACTA = new Technology("INTACTA", company);
        technologyXPTO = new Technology("XPTO", company);

        // Mock grower
        grower = new Grower();

        // Create head office
        Customer participant = new Customer("zeca", new Document(new DocumentType("", country, "99999"), "123"), null,
                "sap code");
        Customer matrix = new Customer("maria", null, null, "sap code");

        Contract contract = new Contract();
        contract.setCompany(company);
        contract.setContractCode("xpto");
        contract.setCrop(crop);
        contract.setCustomer(matrix);
        contract.setStartDate(new Date());
        contract.setEndDate(new Date());
        contract.setParticipantType(ParticipantTypeEnum.POD);
        matrix.getContracts().add(contract);
        headOffice = new HeadOffice(participant, matrix, ParticipantTypeEnum.POD, crop, company);

        List<HeadOffice> headOffices = new ArrayList<HeadOffice>();
        headOffices.add(headOffice);

        // Mock base service
        baseService = Mockito.mock(BaseService.class);
        reportOnLineByGrowerService.setBaseService(baseService);

        // Mock participant service
        participantService = Mockito.mock(ParticipantService.class);
        reportOnLineByGrowerService.setParticipantService(participantService);

        // Mock operational year service
        operationalYearService = Mockito.mock(OperationalYearService.class);
        reportOnLineByGrowerService.setOperationalYearService(operationalYearService);

        // Mock technology service
        technologyService = Mockito.mock(TechnologyService.class);
        reportOnLineByGrowerService.setTechnologyService(technologyService);

        // Mock report online service
        reportOnLineService = Mockito.mock(ReportOnLineService.class);
        reportOnLineByGrowerService.setReportOnlineService(reportOnLineService);

        // Mock dao
        reportOnlineByGrowerDAO = Mockito.mock(ReportOnlineByGrowerDAO.class);
        reportOnLineByGrowerService.setReportOnlineByGrowerDAO(reportOnlineByGrowerDAO);

        // Mock base services
        Mockito.when(baseService.selectGrowerDocumentByCountry((Document) Mockito.anyObject(), Mockito.anyLong()))
                .thenReturn(grower);

        Mockito.when(participantService.selectHeadOfficeBy((ParticipantHeadOfficeFilter) Mockito.anyObject()))
                .thenReturn(headOffices);

        Mockito.when(operationalYearService.selectExactOperationalYear(Mockito.anyInt())).thenReturn(operationalYear);

        Mockito.when(technologyService.findTechnologyByCandidateKey(Mockito.anyString(), (Company) Mockito.anyObject()))
                .thenReturn(technologyRR);

    }

    /**
     * @throws BusinessException
     */
    @Test(expected = IllegalArgumentException.class)
    public void search_paid_fixed_volume_by_grower_without_crop_and_company_expected_illegal_argument_exception()
            throws BusinessException {

        PaidVolumeFilter pvFilter = new PaidVolumeFilter();
        // Search report with crop and company null
        List<PaidVolumeByGrower> pvByGrower = reportOnLineByGrowerService
                .selectPaidVolumeByGrowerListByFilter(pvFilter);

        Assert.assertEquals(0, pvByGrower.size());
    }

    @Test
    public void test_validate_csv_paidVolByGrower_values_required_field_grower_document_type_empty() {

        // period
        Date dth = CalendarUtil.getDate(2016, 8, 22);
        CsvPaidVolImportLine entity = getCsvPaidVolImportLine(null, "99999999999999366", "CPF", "123456789", dth,
                CalendarUtil.getDateNow(), "RR", new BigDecimal("10000.000"), new BigDecimal("10000.000"), 1);

        try {
            reportOnLineByGrowerService.validatePaidVolumeByGrowerCSV(entity, null);
            Assert.fail("Expected ReportOnlineByGrowerWarningException.");
        } catch (ReportOnlineByGrowerWarningException e) {
            Assert.assertTrue("", e.getWarnings().size() == 1);
            for (WarningImportedException warning : e.getWarnings()) {
                Assert.assertTrue("Not found GROWER_DOCUMENT_TYPE_REQUIRED warning. ", warning.getErrorMessageKeys()
                        .contains(PaidVolImportParser.GROWER_DOCUMENT_TYPE_REQUIRED));
            }
        }

    }

    @Test
    public void test_validate_csv_paidVolByGrower_values_required_field_grower_document_empty() {

        CsvPaidVolImportLine entity = getCsvPaidVolImportLine("CPF", "", "CPF", "123456789",
                CalendarUtil.getDate(2016, 8, 22), CalendarUtil.getDateNow(), "RR", new BigDecimal("10000.000"),
                new BigDecimal("10000.000"), 1);

        try {
            reportOnLineByGrowerService.validatePaidVolumeByGrowerCSV(entity, null);
            Assert.fail("Expected ReportOnlineByGrowerWarningException.");
        } catch (ReportOnlineByGrowerWarningException e) {
            Assert.assertTrue("", e.getWarnings().size() == 1);
            for (WarningImportedException warning : e.getWarnings()) {
                Assert.assertTrue("Not found GROWER_DOCUMENT_REQUIRED warning. ", warning.getErrorMessageKeys()
                        .contains(PaidVolImportParser.GROWER_DOCUMENT_REQUIRED));
            }
        }

    }

    @Test
    public void test_validate_csv_paidVolByGrower_values_required_field_customer_document_type_empty() {

        // period
        Date dth = CalendarUtil.getDate(2016, 8, 22);
        CsvPaidVolImportLine entity = getCsvPaidVolImportLine("CPF", "112233", null, "123456789", dth,
                CalendarUtil.getDateNow(), "RR", new BigDecimal("10000.000"), new BigDecimal("10000.000"), 1);

        try {
            reportOnLineByGrowerService.validatePaidVolumeByGrowerCSV(entity, null);
            Assert.fail("Expected ReportOnlineByGrowerWarningException.");
        } catch (ReportOnlineByGrowerWarningException e) {
            Assert.assertTrue("", e.getWarnings().size() == 1);
            for (WarningImportedException warning : e.getWarnings()) {
                Assert.assertTrue("Not found CUSTOMER_DOCUMENT_TYPE_REQUIRED warning. ", warning.getErrorMessageKeys()
                        .contains(PaidVolImportParser.CUSTOMER_DOCUMENT_TYPE_REQUIRED));
            }
        }
    }

    @Test
    public void test_validate_csv_paidVolByGrower_values_required_field_customer_document_empty() {

        // period
        Date dth = CalendarUtil.getDate(2016, 8, 22);
        CsvPaidVolImportLine entity = getCsvPaidVolImportLine("CPF", "112233", "CNPJ", "", dth,
                CalendarUtil.getDateNow(), "RR", new BigDecimal("10000.000"), new BigDecimal("10000.000"), 1);

        try {
            reportOnLineByGrowerService.validatePaidVolumeByGrowerCSV(entity, null);
            Assert.fail("Expected ReportOnlineByGrowerWarningException.");
        } catch (ReportOnlineByGrowerWarningException e) {
            Assert.assertTrue("", e.getWarnings().size() == 1);
            for (WarningImportedException warning : e.getWarnings()) {
                Assert.assertTrue("Not found CUSTOMER_DOCUMENT_REQUIRED warning. ", warning.getErrorMessageKeys()
                        .contains(PaidVolImportParser.CUSTOMER_DOCUMENT_REQUIRED));
            }
        }
    }

    @Test
    public void test_validate_csv_paidVolByGrower_values_required_field_null_period() {

        CsvPaidVolImportLine entity = getCsvPaidVolImportLine("CPF", "112233", "CNPJ", "333", null,
                CalendarUtil.getDateNow(), "RR", new BigDecimal("10000.000"), new BigDecimal("10000.000"), 1);

        try {
            reportOnLineByGrowerService.validatePaidVolumeByGrowerCSV(entity, null);
            Assert.fail("Expected ReportOnlineByGrowerWarningException.");
        } catch (ReportOnlineByGrowerWarningException e) {
            Assert.assertTrue("", e.getWarnings().size() == 1);
            for (WarningImportedException warning : e.getWarnings()) {
                Assert.assertTrue("Not found PERIOD_REQUIRED warning. ",
                        warning.getErrorMessageKeys().contains(PaidVolImportParser.PERIOD_REQUIRED));
            }
        }
    }

    @Test
    public void test_validate_csv_paidVolByGrower_values_required_field_null_received_date() {

        CsvPaidVolImportLine entity = getCsvPaidVolImportLine("CPF", "112233", "CNPJ", "333",
                CalendarUtil.getDate(2016, 8, 22), null, "RR", new BigDecimal("10000.000"),
                new BigDecimal("10000.000"), 1);

        try {
            reportOnLineByGrowerService.validatePaidVolumeByGrowerCSV(entity, null);
            Assert.fail("Expected ReportOnlineByGrowerWarningException.");
        } catch (ReportOnlineByGrowerWarningException e) {
            Assert.assertTrue("", e.getWarnings().size() == 1);
            for (WarningImportedException warning : e.getWarnings()) {
                Assert.assertTrue("Not found DATE_RECEIVE_REQUIRED warning. ",
                        warning.getErrorMessageKeys().contains(PaidVolImportParser.DATE_RECEIVE_REQUIRED));
            }
        }
    }

    @Test
    public void test_validate_csv_paidVolByGrower_values_required_field_empty_technology() {

        CsvPaidVolImportLine entity = getCsvPaidVolImportLine("CPF", "112233", "CNPJ", "333",
                CalendarUtil.getDate(2016, 8, 22), CalendarUtil.getDateNow(), "", new BigDecimal("10000.000"),
                new BigDecimal("10000.000"), 1);

        try {
            reportOnLineByGrowerService.validatePaidVolumeByGrowerCSV(entity, null);
            Assert.fail("Expected ReportOnlineByGrowerWarningException.");
        } catch (ReportOnlineByGrowerWarningException e) {
            Assert.assertTrue("", e.getWarnings().size() == 1);
            for (WarningImportedException warning : e.getWarnings()) {
                Assert.assertTrue("Not found TECHNOLOGY_REQUIRED warning. ",
                        warning.getErrorMessageKeys().contains(PaidVolImportParser.TECHNOLOGY_REQUIRED));
            }
        }
    }

    @Test
    public void test_validate_csv_paidVolByGrower_values_required_field_null_royalt_value() {

        CsvPaidVolImportLine entity = getCsvPaidVolImportLine("CPF", "112233", "CNPJ", "333",
                CalendarUtil.getDate(2016, 8, 22), CalendarUtil.getDateNow(), "RR", null, new BigDecimal("10000.000"),
                1);

        try {
            reportOnLineByGrowerService.validatePaidVolumeByGrowerCSV(entity, null);
            Assert.fail("Expected ReportOnlineByGrowerWarningException.");
        } catch (ReportOnlineByGrowerWarningException e) {
            Assert.assertTrue("", e.getWarnings().size() == 1);
            for (WarningImportedException warning : e.getWarnings()) {
                Assert.assertTrue("Not found TECHNOLOGY_REQUIRED warning. ",
                        warning.getErrorMessageKeys().contains(PaidVolImportParser.ROYALTY_VALUE_REQUIRED));
            }
        }
    }

    @Test
    public void test_validate_csv_paidVolByGrower_values_required_field_null_volume() {

        CsvPaidVolImportLine entity = getCsvPaidVolImportLine("CPF", "112233", "CNPJ", "333",
                CalendarUtil.getDate(2016, 8, 22), CalendarUtil.getDateNow(), "RR", new BigDecimal("10000.000"), null,
                1);

        try {
            reportOnLineByGrowerService.validatePaidVolumeByGrowerCSV(entity, null);
            Assert.fail("Expected ReportOnlineByGrowerWarningException.");
        } catch (ReportOnlineByGrowerWarningException e) {
            Assert.assertTrue("", e.getWarnings().size() == 1);
            for (WarningImportedException warning : e.getWarnings()) {
                Assert.assertTrue("Not found VOLUME_REQUIRED warning. ",
                        warning.getErrorMessageKeys().contains(PaidVolImportParser.VOLUME_REQUIRED));
            }
        }
    }

    @Test
    public void test_validate_csv_paidVolByGrower_values_negative_volume() {

        CsvPaidVolImportLine entity = getCsvPaidVolImportLine("CPF", "112233", "CNPJ", "333",
                CalendarUtil.getDate(2016, 8, 22), CalendarUtil.getDateNow(), "RR", new BigDecimal("10000.000"),
                new BigDecimal("-10000.000"), 1);

        try {
            reportOnLineByGrowerService.validatePaidVolumeByGrowerCSV(entity, null);
            Assert.fail("Expected ReportOnlineByGrowerWarningException.");
        } catch (ReportOnlineByGrowerWarningException e) {
            Assert.assertTrue("", e.getWarnings().size() == 1);
            for (WarningImportedException warning : e.getWarnings()) {
                Assert.assertTrue("Not found VOLUME_MUST_BE_GREATER_THAN_ZERO warning. ", warning.getErrorMessageKeys()
                        .contains(PaidVolImportParser.VOLUME_MUST_BE_GREATER_THAN_ZERO));
            }
        }
    }

    @Test
    public void test_validate_csv_paidVolByGrower_values_zero_volume() {

        CsvPaidVolImportLine entity = getCsvPaidVolImportLine("CPF", "112233", "CNPJ", "333",
                CalendarUtil.getDate(2016, 8, 22), CalendarUtil.getDateNow(), "RR", new BigDecimal("10000.000"),
                BigDecimal.ZERO, 1);

        try {
            reportOnLineByGrowerService.validatePaidVolumeByGrowerCSV(entity, null);
            Assert.fail("Expected ReportOnlineByGrowerWarningException.");
        } catch (ReportOnlineByGrowerWarningException e) {
            Assert.assertTrue("", e.getWarnings().size() == 1);
            for (WarningImportedException warning : e.getWarnings()) {
                Assert.assertTrue("Not found VOLUME_MUST_BE_GREATER_THAN_ZERO warning. ", warning.getErrorMessageKeys()
                        .contains(PaidVolImportParser.VOLUME_MUST_BE_GREATER_THAN_ZERO));
            }
        }
    }

    @Test
    public void test_validate_csv_paidVolByGrower_zero_royalt_value() {

        CsvPaidVolImportLine entity = getCsvPaidVolImportLine("CPF", "112233", "CNPJ", "333", CalendarUtil.getDate(
                2016, 8, 22), CalendarUtil.getDateNow(), "RR", BigDecimal.ZERO, new BigDecimal("10000.000"), 1);

        try {
            reportOnLineByGrowerService.validatePaidVolumeByGrowerCSV(entity, null);
            Assert.fail("Expected ReportOnlineByGrowerWarningException.");
        } catch (ReportOnlineByGrowerWarningException e) {
            Assert.assertTrue("", e.getWarnings().size() == 1);
            for (WarningImportedException warning : e.getWarnings()) {
                Assert.assertTrue("Not found ROYALTY_MUST_BE_GREATER_THAN_ZERO warning. ", warning
                        .getErrorMessageKeys().contains(PaidVolImportParser.ROYALTY_MUST_BE_GREATER_THAN_ZERO));
            }
        }
    }

    @Test
    public void test_validate_csv_paidVolByGrower_negative_royalt_value() {

        CsvPaidVolImportLine entity = getCsvPaidVolImportLine("CPF", "112233", "CNPJ", "333",
                CalendarUtil.getDate(2016, 8, 22), CalendarUtil.getDateNow(), "RR", new BigDecimal("-10.000"),
                new BigDecimal("10000.000"), 1);

        try {
            reportOnLineByGrowerService.validatePaidVolumeByGrowerCSV(entity, null);
            Assert.fail("Expected ReportOnlineByGrowerWarningException.");
        } catch (ReportOnlineByGrowerWarningException e) {
            Assert.assertTrue("", e.getWarnings().size() == 1);
            for (WarningImportedException warning : e.getWarnings()) {
                Assert.assertTrue("Not found ROYALTY_MUST_BE_GREATER_THAN_ZERO warning. ", warning
                        .getErrorMessageKeys().contains(PaidVolImportParser.ROYALTY_MUST_BE_GREATER_THAN_ZERO));
            }
        }
    }

    @Test
    public void test_validate_csv_paidVolByGrower() throws BusinessException {

        CsvPaidVolImportLine entity = getCsvPaidVolImportLine("CPF", "112233", "CNPJ", "333",
                CalendarUtil.getDate(2016, 8, 22), CalendarUtil.getDateNow(), "RR", new BigDecimal("1.00"),
                new BigDecimal("10000.00"), 1);

        // Mock rol info
        ReportOnLineInfo rolInfo = new ReportOnLineInfo();
        rolInfo.setCrop(crop);
        rolInfo.setCompany(company);
        rolInfo.setDocTypes(new ArrayList<DocumentType>());
        rolInfo.getDocTypes().add(new DocumentType("CNPJ", null, null));
        rolInfo.getDocTypes().add(new DocumentType("CPF", null, null));

        reportOnLineByGrowerService.validatePaidVolumeByGrowerCSV(entity, rolInfo);
        Assert.assertEquals(headOffice, entity.getHeadOffice());
        Assert.assertEquals(operationalYear, entity.getOperationalYear());
        Assert.assertEquals(technologyRR, entity.getTech());
        Assert.assertEquals(grower, entity.getGrower());

    }

    @Test
    public void test_validate_csv_paidVolByGrower_grower_not_found() throws BusinessException {

        CsvPaidVolImportLine entity = getCsvPaidVolImportLine("CPF", "112233", "CNPJ", "333",
                CalendarUtil.getDate(2016, 8, 22), CalendarUtil.getDateNow(), "RR", new BigDecimal("1.00"),
                new BigDecimal("10000.00"), 1);

        // Mock rol info
        ReportOnLineInfo rolInfo = new ReportOnLineInfo();
        rolInfo.setCrop(crop);
        rolInfo.setCompany(company);
        rolInfo.setDocTypes(new ArrayList<DocumentType>());
        rolInfo.getDocTypes().add(new DocumentType("CNPJ", null, null));
        rolInfo.getDocTypes().add(new DocumentType("CPF", null, null));

        // Mock base services
        Mockito.when(baseService.selectGrowerDocumentByCountry((Document) Mockito.anyObject(), Mockito.anyLong()))
                .thenThrow(new GrowerNotFoundException(""));

        try {
            reportOnLineByGrowerService.validatePaidVolumeByGrowerCSV(entity, rolInfo);
            Assert.fail("Expected ReportOnlineByGrowerWarningException.");
        } catch (ReportOnlineByGrowerWarningException e) {
            Assert.assertTrue("Expected only one exception, but found: " + e.getWarnings().size(), e.getWarnings()
                    .size() == 1);
            for (WarningImportedException warning : e.getWarnings()) {
                Assert.assertTrue("Not found GROWER_NOT_FOUND warning. ",
                        warning.getErrorMessageKeys().contains(PaidVolImportParser.GROWER_NOT_FOUND));
            }
        }
    }

    @Test
    public void test_validate_csv_paidVolByGrower_affiliate_not_found() throws BusinessException {

        CsvPaidVolImportLine entity = getCsvPaidVolImportLine("CPF", "112233", "CNPJ", "333",
                CalendarUtil.getDate(2016, 8, 22), CalendarUtil.getDateNow(), "RR", new BigDecimal("1.00"),
                new BigDecimal("10000.00"), 1);

        // Mock rol info
        ReportOnLineInfo rolInfo = new ReportOnLineInfo();
        rolInfo.setCrop(crop);
        rolInfo.setCompany(company);
        rolInfo.setDocTypes(new ArrayList<DocumentType>());
        rolInfo.getDocTypes().add(new DocumentType("CNPJ", null, null));
        rolInfo.getDocTypes().add(new DocumentType("CPF", null, null));

        Mockito.when(participantService.selectHeadOfficeBy((ParticipantHeadOfficeFilter) Mockito.anyObject()))
                .thenReturn(new ArrayList<HeadOffice>());

        try {
            reportOnLineByGrowerService.validatePaidVolumeByGrowerCSV(entity, rolInfo);
            Assert.fail("Expected ReportOnlineByGrowerWarningException.");
        } catch (ReportOnlineByGrowerWarningException e) {
            Assert.assertTrue("Expected only one exception, but found: " + e.getWarnings().size(), e.getWarnings()
                    .size() == 1);
            for (WarningImportedException warning : e.getWarnings()) {
                Assert.assertTrue("Not found AFFILIATE_NOT_BELONGING_TO_HEADOFFICE warning. ", warning
                        .getErrorMessageKeys().contains(PaidVolImportParser.AFFILIATE_NOT_BELONGING_TO_HEADOFFICE));
            }
        }
    }

    @Test
    public void test_validate_csv_paidVolByGrower_affiliate_without_vigor() throws BusinessException {

        CsvPaidVolImportLine entity = getCsvPaidVolImportLine("CPF", "112233", "CNPJ", "333",
                CalendarUtil.getDate(2016, 8, 22), CalendarUtil.getDateNow(), "RR", new BigDecimal("1.00"),
                new BigDecimal("10000.00"), 1);

        // Mock rol info
        ReportOnLineInfo rolInfo = new ReportOnLineInfo();
        rolInfo.setCrop(crop);
        rolInfo.setCompany(company);
        rolInfo.setDocTypes(new ArrayList<DocumentType>());
        rolInfo.getDocTypes().add(new DocumentType("CNPJ", null, null));
        rolInfo.getDocTypes().add(new DocumentType("CPF", null, null));

        // Clear matrix contracts
        headOffice.getMatrix().getContracts().clear();

        try {
            reportOnLineByGrowerService.validatePaidVolumeByGrowerCSV(entity, rolInfo);
            Assert.fail("Expected ReportOnlineByGrowerWarningException.");
        } catch (ReportOnlineByGrowerWarningException e) {
            Assert.assertTrue("Expected only one exception, but found: " + e.getWarnings().size(), e.getWarnings()
                    .size() == 1);
            for (WarningImportedException warning : e.getWarnings()) {
                Assert.assertTrue("Not found AFFILIATE_NOT_BELONGING_TO_HEADOFFICE warning. ", warning
                        .getErrorMessageKeys().contains(PaidVolImportParser.AFFILIATE_NOT_BELONGING_TO_HEADOFFICE));
            }
        }
    }

    @Test
    public void test_validate_csv_paidVolByGrower_operational_year_not_found() throws BusinessException {

        CsvPaidVolImportLine entity = getCsvPaidVolImportLine("CPF", "112233", "CNPJ", "333",
                CalendarUtil.getDate(2016, 8, 22), CalendarUtil.getDateNow(), "RR", new BigDecimal("1.00"),
                new BigDecimal("10000.00"), 1);

        // Mock rol info
        ReportOnLineInfo rolInfo = new ReportOnLineInfo();
        rolInfo.setCrop(crop);
        rolInfo.setCompany(company);
        rolInfo.setDocTypes(new ArrayList<DocumentType>());
        rolInfo.getDocTypes().add(new DocumentType("CNPJ", null, null));
        rolInfo.getDocTypes().add(new DocumentType("CPF", null, null));

        Mockito.when(operationalYearService.selectExactOperationalYear(Mockito.anyInt())).thenThrow(
                new EntityNotFoundException(""));

        try {
            reportOnLineByGrowerService.validatePaidVolumeByGrowerCSV(entity, rolInfo);
            Assert.fail("Expected ReportOnlineByGrowerWarningException.");
        } catch (ReportOnlineByGrowerWarningException e) {
            Assert.assertTrue("Expected only one exception, but found: " + e.getWarnings().size(), e.getWarnings()
                    .size() == 1);
            for (WarningImportedException warning : e.getWarnings()) {
                Assert.assertTrue("Not found OPERATIONAL_YEAR_NOT_FOUND warning. ", warning.getErrorMessageKeys()
                        .contains(PaidVolImportParser.OPERATIONAL_YEAR_NOT_FOUND));
            }
        }
    }

    @Test
    public void test_validate_csv_paidVolByGrower_technology_not_found() throws BusinessException {

        CsvPaidVolImportLine entity = getCsvPaidVolImportLine("CPF", "112233", "CNPJ", "333",
                CalendarUtil.getDate(2016, 8, 22), CalendarUtil.getDateNow(), "RR", new BigDecimal("1.00"),
                new BigDecimal("10000.00"), 1);

        // Mock rol info
        ReportOnLineInfo rolInfo = new ReportOnLineInfo();
        rolInfo.setCrop(crop);
        rolInfo.setCompany(company);
        rolInfo.setDocTypes(new ArrayList<DocumentType>());
        rolInfo.getDocTypes().add(new DocumentType("CNPJ", null, null));
        rolInfo.getDocTypes().add(new DocumentType("CPF", null, null));

        Mockito.when(technologyService.findTechnologyByCandidateKey(Mockito.anyString(), (Company) Mockito.anyObject()))
                .thenThrow(new EntityNotFoundException(""));

        try {
            reportOnLineByGrowerService.validatePaidVolumeByGrowerCSV(entity, rolInfo);
            Assert.fail("Expected ReportOnlineByGrowerWarningException.");
        } catch (ReportOnlineByGrowerWarningException e) {
            Assert.assertTrue("Expected only one exception, but found: " + e.getWarnings().size(), e.getWarnings()
                    .size() == 1);
            for (WarningImportedException warning : e.getWarnings()) {
                Assert.assertTrue("Not found TECHNOLOGY_NOT_FOUND warning. ",
                        warning.getErrorMessageKeys().contains(PaidVolImportParser.TECHNOLOGY_NOT_FOUND));
            }
        }
    }

    @Test
    public void test_group_paid_volume_by_grower_csv_by_rol_key_one_group_one_line() {

        List<CsvPaidVolImportLine> lines = new ArrayList<CsvPaidVolImportLine>();
        CsvPaidVolImportLine entity = getCsvPaidVolImportLine("CPF", "112233", "CNPJ", "333",
                CalendarUtil.getDate(2016, 8, 22), CalendarUtil.getDateNow(), "RR", new BigDecimal("1.00"),
                new BigDecimal("10000.00"), 1);
        lines.add(entity);

        // Group lines by ROL key
        Map<String, List<CsvPaidVolImportLine>> groupMap = reportOnLineByGrowerService
                .groupPaidVolumeByGrowerCSVByRolKey(lines);
        Assert.assertTrue("Expected only one item in group, but found: " + groupMap.size(), groupMap.size() == 1);
        for (List<CsvPaidVolImportLine> groupLines : groupMap.values()) {
            for (CsvPaidVolImportLine line : groupLines) {
                Assert.assertEquals(entity, line);
            }
        }
    }

    @Test
    public void test_group_paid_volume_by_grower_csv_by_rol_key_one_group_two_lines() {

        List<CsvPaidVolImportLine> lines = new ArrayList<CsvPaidVolImportLine>();
        CsvPaidVolImportLine entity = getCsvPaidVolImportLine("CPF", "112233", "CNPJ", "333",
                CalendarUtil.getDate(2016, 8, 22), CalendarUtil.getDateNow(), "RR", new BigDecimal("1.00"),
                new BigDecimal("1.00"), 1);
        CsvPaidVolImportLine entity1 = getCsvPaidVolImportLine("CPF", "556688", "CNPJ", "333",
                CalendarUtil.getDate(2016, 8, 22), CalendarUtil.getDateNow(), "RR", new BigDecimal("2.00"),
                new BigDecimal("2.00"), 1);
        lines.add(entity);
        lines.add(entity1);

        // Group lines by ROL key
        Map<String, List<CsvPaidVolImportLine>> groupMap = reportOnLineByGrowerService
                .groupPaidVolumeByGrowerCSVByRolKey(lines);
        Assert.assertTrue("Expected only one item in group, but found: " + groupMap.size(), groupMap.size() == 1);
        for (List<CsvPaidVolImportLine> groupLines : groupMap.values()) {
            Assert.assertTrue("Expected two lines in this group", groupLines.size() == 2);
            Assert.assertTrue(groupLines.contains(entity));
            Assert.assertTrue(groupLines.contains(entity1));
        }
    }

    @Test
    public void test_group_paid_volume_by_grower_csv_by_rol_key_two_group_two_lines() {

        List<CsvPaidVolImportLine> lines = new ArrayList<CsvPaidVolImportLine>();
        CsvPaidVolImportLine entity = getCsvPaidVolImportLine("CPF", "112233", "CNPJ", "333",
                CalendarUtil.getDate(2016, 8, 22), CalendarUtil.getDateNow(), "RR", new BigDecimal("1.00"),
                new BigDecimal("1.00"), 1);
        CsvPaidVolImportLine entity1 = getCsvPaidVolImportLine("CPF", "556688", "CNPJ", "333",
                CalendarUtil.getDate(2016, 8, 22), CalendarUtil.getDateNow(), "intacta", new BigDecimal("2.00"),
                new BigDecimal("2.00"), 1);
        lines.add(entity);
        lines.add(entity1);

        // Group lines by ROL key
        Map<String, List<CsvPaidVolImportLine>> groupMap = reportOnLineByGrowerService
                .groupPaidVolumeByGrowerCSVByRolKey(lines);
        Assert.assertTrue("Expected exactly two groups, but found: " + groupMap.size(), groupMap.size() == 2);
        for (List<CsvPaidVolImportLine> groupLines : groupMap.values()) {
            Assert.assertTrue("Expected only one lines in this group", groupLines.size() == 1);
            Assert.assertTrue((groupLines.contains(entity) && !groupLines.contains(entity1))
                    || (!groupLines.contains(entity) && groupLines.contains(entity1)));
        }
    }

    @Test
    public void test_group_paid_volume_by_grower_csv_by_rol_key_two_group_two_lines_change_customer() {

        List<CsvPaidVolImportLine> lines = new ArrayList<CsvPaidVolImportLine>();
        CsvPaidVolImportLine entity = getCsvPaidVolImportLine("CPF", "112233", "CNPJ", "333",
                CalendarUtil.getDate(2016, 8, 22), CalendarUtil.getDateNow(), "RR", new BigDecimal("1.00"),
                new BigDecimal("1.00"), 1);
        CsvPaidVolImportLine entity1 = getCsvPaidVolImportLine("CPF", "556688", "CNPJ", "333666",
                CalendarUtil.getDate(2016, 8, 22), CalendarUtil.getDateNow(), "RR", new BigDecimal("2.00"),
                new BigDecimal("2.00"), 1);
        lines.add(entity);
        lines.add(entity1);

        // Group lines by ROL key
        Map<String, List<CsvPaidVolImportLine>> groupMap = reportOnLineByGrowerService
                .groupPaidVolumeByGrowerCSVByRolKey(lines);
        Assert.assertTrue("Expected exactly two groups, but found: " + groupMap.size(), groupMap.size() == 2);
        for (List<CsvPaidVolImportLine> groupLines : groupMap.values()) {
            Assert.assertTrue("Expected only one lines in this group", groupLines.size() == 1);
            Assert.assertTrue((groupLines.contains(entity) && !groupLines.contains(entity1))
                    || (!groupLines.contains(entity) && groupLines.contains(entity1)));
        }
    }

    @Test
    public void test_validate_paid_volume_by_grower_csv_volume_value_with_rol_without_overflow_rol_not_reported_yet()
            throws BusinessException {

        Map<String, ReportOnLine> rolCache = new HashMap<String, ReportOnLine>();

        List<CsvPaidVolImportLine> lines = new ArrayList<CsvPaidVolImportLine>();

        CsvPaidVolImportLine entity = getCsvPaidVolImportLine("CPF", "112233", "CNPJ", "333",
                CalendarUtil.getDate(2013, 1, 1), CalendarUtil.getDateNow(), "RR", new BigDecimal("1.00"),
                new BigDecimal("1.00"), 1);
        entity.setHeadOffice(headOffice);
        entity.setOperationalYear(operationalYear);
        lines.add(entity);

        // Validate volume and value by group
        reportOnLineByGrowerService.validatePaidVolumeByGrowerCSVVolumeValueWithRol(lines, rolCache);
    }

    @Test
    public void test_validate_paid_volume_by_grower_csv_volume_value_with_rol_without_overflow()
            throws BusinessException {

        Map<String, ReportOnLine> rolCache = new HashMap<String, ReportOnLine>();

        List<CsvPaidVolImportLine> lines = new ArrayList<CsvPaidVolImportLine>();

        CsvPaidVolImportLine entity = getCsvPaidVolImportLine("CPF", "112233", "CNPJ", "333",
                CalendarUtil.getDate(2013, 1, 1), CalendarUtil.getDateNow(), "RR", new BigDecimal("1.00"),
                new BigDecimal("1.00"), 1);
        entity.setHeadOffice(headOffice);
        entity.setOperationalYear(operationalYear);
        lines.add(entity);

        // Mock rol search
        ReportOnLine rol = new ReportOnLine();

        Mockito.when(
                reportOnLineService.searchReportOnline((Crop) Mockito.anyObject(), (HeadOffice) Mockito.anyObject(),
                        (Date) Mockito.anyObject(), (OperationalYear) Mockito.anyObject())).thenReturn(rol);

        // Validate volume and value by group
        reportOnLineByGrowerService.validatePaidVolumeByGrowerCSVVolumeValueWithRol(lines, rolCache);

        // Mock for not found rol in service, expected use cache
        Mockito.when(
                reportOnLineService.searchReportOnline((Crop) Mockito.anyObject(), (HeadOffice) Mockito.anyObject(),
                        (Date) Mockito.anyObject(), (OperationalYear) Mockito.anyObject())).thenReturn(null);

        // Validate volume and value by group
        reportOnLineByGrowerService.validatePaidVolumeByGrowerCSVVolumeValueWithRol(lines, rolCache);
    }

    @Test(expected = ReportOnlineByGrowerConstraintException.class)
    public void test_validate_paid_volume_by_grower_csv_volume_value_with_rol_with_overflow_volume()
            throws BusinessException {

        Map<String, ReportOnLine> rolCache = new HashMap<String, ReportOnLine>();

        List<CsvPaidVolImportLine> lines = new ArrayList<CsvPaidVolImportLine>();

        CsvPaidVolImportLine entity = getCsvPaidVolImportLine("CPF", "112233", "CNPJ", "333",
                CalendarUtil.getDate(2013, 1, 1), CalendarUtil.getDateNow(), "RR", new BigDecimal("1.00"),
                new BigDecimal("10.00"), 1);
        entity.setHeadOffice(headOffice);
        entity.setOperationalYear(operationalYear);
        entity.setTech(technologyRR);
        lines.add(entity);

        // Mock rol search
        ReportOnLine rol = new ReportOnLine();

        RolParameter rolParameter = new RolParameter();
        rolParameter.setRolParValidateByGrower(Boolean.TRUE);
        rolParameter.setTechnology(technologyRR);

        UsedRolParameter usedRolParameter = new UsedRolParameter();
        usedRolParameter.setRolParameter(rolParameter);
        usedRolParameter.setUsedRolParameterTonValue(BigDecimal.ONE);
        rol.getUsedRolParameters().add(usedRolParameter);

        Mockito.when(
                reportOnLineService.searchReportOnline((Crop) Mockito.anyObject(), (HeadOffice) Mockito.anyObject(),
                        (Date) Mockito.anyObject(), (OperationalYear) Mockito.anyObject())).thenReturn(rol);

        // Validate volume and value by group
        reportOnLineByGrowerService.validatePaidVolumeByGrowerCSVVolumeValueWithRol(lines, rolCache);
    }

    @Test(expected = ReportOnlineByGrowerConstraintException.class)
    public void test_validate_paid_volume_by_grower_csv_volume_value_with_rol_with_overflow_value()
            throws BusinessException {

        Map<String, ReportOnLine> rolCache = new HashMap<String, ReportOnLine>();

        List<CsvPaidVolImportLine> lines = new ArrayList<CsvPaidVolImportLine>();

        CsvPaidVolImportLine entity = getCsvPaidVolImportLine("CPF", "112233", "CNPJ", "333",
                CalendarUtil.getDate(2013, 1, 1), CalendarUtil.getDateNow(), "RR", new BigDecimal("100.00"),
                new BigDecimal("1.00"), 1);
        entity.setHeadOffice(headOffice);
        entity.setOperationalYear(operationalYear);
        entity.setTech(technologyRR);
        lines.add(entity);

        // Mock rol search
        ReportOnLine rol = new ReportOnLine();

        RolParameter rolParameter = new RolParameter();
        rolParameter.setRolParValidateByGrower(Boolean.TRUE);
        rolParameter.setTechnology(technologyRR);

        UsedRolParameter usedRolParameter = new UsedRolParameter();
        usedRolParameter.setRolParameter(rolParameter);
        usedRolParameter.setUsedRolParameterTonValue(BigDecimal.ONE);
        usedRolParameter.setUsedRolParamMonetaryVal(new BigDecimal("99.00"));
        rol.getUsedRolParameters().add(usedRolParameter);

        Mockito.when(
                reportOnLineService.searchReportOnline((Crop) Mockito.anyObject(), (HeadOffice) Mockito.anyObject(),
                        (Date) Mockito.anyObject(), (OperationalYear) Mockito.anyObject())).thenReturn(rol);

        // Validate volume and value by group
        reportOnLineByGrowerService.validatePaidVolumeByGrowerCSVVolumeValueWithRol(lines, rolCache);
    }

    @Test
    public void test_group_paid_volume_by_grower_csv_by_rol_key_two_group_three_lines() {

        List<CsvPaidVolImportLine> lines = new ArrayList<CsvPaidVolImportLine>();
        CsvPaidVolImportLine entity = getCsvPaidVolImportLine("CPF", "00000", "CNPJ", "333666",
                CalendarUtil.getDate(2016, 8, 22), CalendarUtil.getDateNow(), "RR", new BigDecimal("1.00"),
                new BigDecimal("1.00"), 1);
        CsvPaidVolImportLine entity1 = getCsvPaidVolImportLine("CPF", "00000", "CNPJ", "333666",
                CalendarUtil.getDate(2016, 8, 22), CalendarUtil.getDateNow(), "RR", new BigDecimal("2.00"),
                new BigDecimal("2.00"), 2);
        CsvPaidVolImportLine entity2 = getCsvPaidVolImportLine("CPF", "00000", "CNPJ", "333666",
                CalendarUtil.getDate(2016, 9, 22), CalendarUtil.getDateNow(), "RR", new BigDecimal("3.00"),
                new BigDecimal("3.00"), 3);
        lines.add(entity);
        lines.add(entity1);
        lines.add(entity2);

        // Group lines by ROL key
        Map<String, List<CsvPaidVolImportLine>> groupMap = reportOnLineByGrowerService
                .groupPaidVolumeByGrowerCSVByRolKey(lines);
        Assert.assertTrue("Expected exactly two groups, but found: " + groupMap.size(), groupMap.size() == 2);
        boolean foundAll = false;
        boolean found = false;
        for (List<CsvPaidVolImportLine> groupLines : groupMap.values()) {
            Assert.assertTrue(groupLines.size() == 1 || groupLines.size() == 2);
            if (groupLines.size() == 1) {
                Assert.assertEquals(entity2, groupLines.get(0));
                found = true;
            } else {
                Assert.assertTrue(groupLines.contains(entity) && groupLines.contains(entity1));
                foundAll = true;
            }
        }

        Assert.assertTrue(found && foundAll);
    }

    @Test
    public void test_group_paid_volume_by_grower_csv_by_rol_key_two_group_two_lines_change_period() {

        List<CsvPaidVolImportLine> lines = new ArrayList<CsvPaidVolImportLine>();
        CsvPaidVolImportLine entity = getCsvPaidVolImportLine("CPF", "112233", "CNPJ", "666",
                CalendarUtil.getDate(2016, 8, 22), CalendarUtil.getDateNow(), "RR", new BigDecimal("1.00"),
                new BigDecimal("1.00"), 1);
        CsvPaidVolImportLine entity1 = getCsvPaidVolImportLine("CPF", "556688", "CNPJ", "666",
                CalendarUtil.getDate(2016, 9, 22), CalendarUtil.getDateNow(), "RR", new BigDecimal("2.00"),
                new BigDecimal("2.00"), 1);
        lines.add(entity);
        lines.add(entity1);

        // Group lines by ROL key
        Map<String, List<CsvPaidVolImportLine>> groupMap = reportOnLineByGrowerService
                .groupPaidVolumeByGrowerCSVByRolKey(lines);
        Assert.assertTrue("Expected exactly two groups, but found: " + groupMap.size(), groupMap.size() == 2);
        for (List<CsvPaidVolImportLine> groupLines : groupMap.values()) {
            Assert.assertTrue("Expected only one lines in this group", groupLines.size() == 1);
            Assert.assertTrue((groupLines.contains(entity) && !groupLines.contains(entity1))
                    || (!groupLines.contains(entity) && groupLines.contains(entity1)));
        }
    }

    @Test
    public void test_generate_paid_volume_by_grower_list_one_line() {

        // Build line list
        List<CsvPaidVolImportLine> lines = new ArrayList<CsvPaidVolImportLine>();
        CsvPaidVolImportLine entity = getCsvPaidVolImportLine("CPF", "112233", "CNPJ", "666",
                CalendarUtil.getDate(2016, 8, 22), CalendarUtil.getDateNow(), "RR", new BigDecimal("1.00"),
                new BigDecimal("1.00"), 1);
        entity.setHeadOffice(headOffice);
        entity.setGrower(grower);
        entity.setTech(technologyRR);
        entity.setOperationalYear(operationalYear);
        lines.add(entity);

        // Convert line to report list
        Map<PaidVolByGrowerItem, CsvPaidVolImportLine> itemToCsvLineMap = new HashMap<PaidVolByGrowerItem, CsvPaidVolImportLine>();
        List<PaidVolumeByGrower> convertedList = reportOnLineByGrowerService.generatePaidVolumeByGrowerList(lines,
                itemToCsvLineMap);
        Assert.assertNotNull(convertedList);
        Assert.assertFalse(convertedList.isEmpty());
        Assert.assertFalse(itemToCsvLineMap.isEmpty());
        Assert.assertEquals(lines.size(), itemToCsvLineMap.size());
        Assert.assertTrue("Expected only one report in converted list.", convertedList.size() == 1);

        PaidVolumeByGrower paidVolumeByGrower = convertedList.get(0);
        Assert.assertNotNull(paidVolumeByGrower.getHeadoffice());
        Assert.assertEquals(headOffice, paidVolumeByGrower.getHeadoffice());
        Assert.assertNotNull(paidVolumeByGrower.getCreateDate());
        Assert.assertNotNull(paidVolumeByGrower.getGrower());
        Assert.assertEquals(grower, paidVolumeByGrower.getGrower());
        Assert.assertNotNull(paidVolumeByGrower.getPaidVolByGrowerItems());
        Assert.assertFalse(paidVolumeByGrower.getPaidVolByGrowerItems().isEmpty());
        Assert.assertTrue("Expected one item.", paidVolumeByGrower.getPaidVolByGrowerItems().size() == 1);
        Assert.assertNotNull(paidVolumeByGrower.getPeriod());
        Assert.assertEquals(CalendarUtil.getFirstDateOfMonth(entity.getPeriod()), paidVolumeByGrower.getPeriod());
        Assert.assertTrue(paidVolumeByGrower.getTechnologies().contains(technologyRR));

        // Get item
        PaidVolByGrowerItem item = paidVolumeByGrower.getPaidVolByGrowerItems().iterator().next();
        Assert.assertNotNull(item.getPaidVolumeByGrower());
        Assert.assertEquals(paidVolumeByGrower, item.getPaidVolumeByGrower());
        Assert.assertNotNull(item.getRoyaltyValue());
        Assert.assertEquals(entity.getRoyaltyValue(), item.getRoyaltyValue());
        Assert.assertNotNull(item.getVolume());
        Assert.assertEquals(entity.getVolume(), item.getVolume());
        Assert.assertEquals(technologyRR, item.getTechnology());

        Assert.assertTrue(itemToCsvLineMap.containsKey(item));
        Assert.assertEquals(entity, itemToCsvLineMap.get(item));

    }

    @Test
    public void test_generate_paid_volume_by_grower_list_two_lines_and_two_rols() {

        // Build line list
        List<CsvPaidVolImportLine> lines = new ArrayList<CsvPaidVolImportLine>();
        CsvPaidVolImportLine entity0 = getCsvPaidVolImportLine("CPF", "112233", "CNPJ", "666",
                CalendarUtil.getDate(2016, 8, 22), CalendarUtil.getDateNow(), "RR", new BigDecimal("1.00"),
                new BigDecimal("1.00"), 1);
        entity0.setHeadOffice(headOffice);
        entity0.setGrower(grower);
        entity0.setTech(technologyRR);
        entity0.setOperationalYear(operationalYear);
        lines.add(entity0);

        CsvPaidVolImportLine entity1 = getCsvPaidVolImportLine("CPF", "112233", "CNPJ", "666",
                CalendarUtil.getDate(2016, 8, 22), CalendarUtil.getDateNow(), "RR", new BigDecimal("1.99"),
                new BigDecimal("2.99"), 1);
        entity1.setHeadOffice(headOffice);
        entity1.setGrower(grower);
        entity1.setTech(technologyRR);
        entity1.setOperationalYear(operationalYear);
        lines.add(entity1);

        // Convert line to report list
        Map<PaidVolByGrowerItem, CsvPaidVolImportLine> itemToCsvLineMap = new HashMap<PaidVolByGrowerItem, CsvPaidVolImportLine>();
        List<PaidVolumeByGrower> convertedList = reportOnLineByGrowerService.generatePaidVolumeByGrowerList(lines,
                itemToCsvLineMap);
        Assert.assertNotNull(convertedList);
        Assert.assertFalse(convertedList.isEmpty());
        Assert.assertFalse(itemToCsvLineMap.isEmpty());
        Assert.assertEquals(lines.size(), itemToCsvLineMap.size());
        Assert.assertTrue("Expected two reports in converted list.", convertedList.size() == 2);

        int index = 0;
        for (PaidVolumeByGrower paidVolumeByGrower : convertedList) {

            ++index;

            Assert.assertNotNull(paidVolumeByGrower.getHeadoffice());
            Assert.assertEquals(headOffice, paidVolumeByGrower.getHeadoffice());
            Assert.assertNotNull(paidVolumeByGrower.getCreateDate());
            Assert.assertNotNull(paidVolumeByGrower.getGrower());
            Assert.assertEquals(grower, paidVolumeByGrower.getGrower());
            Assert.assertNotNull(paidVolumeByGrower.getPaidVolByGrowerItems());
            Assert.assertFalse(paidVolumeByGrower.getPaidVolByGrowerItems().isEmpty());
            Assert.assertTrue("Expected one item.", paidVolumeByGrower.getPaidVolByGrowerItems().size() == 1);
            Assert.assertNotNull(paidVolumeByGrower.getPeriod());
            Assert.assertTrue(paidVolumeByGrower.getTechnologies().contains(technologyRR));

            // Get item
            PaidVolByGrowerItem item = paidVolumeByGrower.getPaidVolByGrowerItems().iterator().next();
            Assert.assertNotNull(item.getPaidVolumeByGrower());
            Assert.assertEquals(paidVolumeByGrower, item.getPaidVolumeByGrower());
            Assert.assertNotNull(item.getRoyaltyValue());
            Assert.assertNotNull(item.getVolume());
            Assert.assertEquals(technologyRR, item.getTechnology());
            Assert.assertTrue(itemToCsvLineMap.containsKey(item));

            if (index == 1) {
                Assert.assertEquals(CalendarUtil.getFirstDateOfMonth(entity0.getPeriod()),
                        paidVolumeByGrower.getPeriod());
                Assert.assertEquals(entity0.getRoyaltyValue(), item.getRoyaltyValue());
                Assert.assertEquals(entity0.getVolume(), item.getVolume());
                Assert.assertEquals(entity0, itemToCsvLineMap.get(item));
            } else {
                Assert.assertEquals(CalendarUtil.getFirstDateOfMonth(entity1.getPeriod()),
                        paidVolumeByGrower.getPeriod());
                Assert.assertEquals(entity1.getRoyaltyValue(), item.getRoyaltyValue());
                Assert.assertEquals(entity1.getVolume(), item.getVolume());
                Assert.assertEquals(entity1, itemToCsvLineMap.get(item));
            }

        }

    }

    @Test
    public void test_generate_paid_volume_by_grower_list_three_lines_and_two_rols() {

        // Build line list
        List<CsvPaidVolImportLine> lines = new ArrayList<CsvPaidVolImportLine>();
        CsvPaidVolImportLine entity0 = getCsvPaidVolImportLine("CPF", "112233", "CNPJ", "666",
                CalendarUtil.getDate(2016, 8, 22), CalendarUtil.getDateNow(), "RR", new BigDecimal("1.00"),
                new BigDecimal("1.00"), 1);
        entity0.setHeadOffice(headOffice);
        entity0.setGrower(grower);
        entity0.setTech(technologyRR);
        entity0.setOperationalYear(operationalYear);
        lines.add(entity0);

        CsvPaidVolImportLine entity1 = getCsvPaidVolImportLine("CPF", "112233", "CNPJ", "666",
                CalendarUtil.getDate(2016, 8, 22), CalendarUtil.getDateNow(), "RR", new BigDecimal("1.99"),
                new BigDecimal("2.99"), 2);
        entity1.setHeadOffice(headOffice);
        entity1.setGrower(grower);
        entity1.setTech(technologyRR);
        entity1.setOperationalYear(operationalYear);
        lines.add(entity1);

        CsvPaidVolImportLine entity2 = getCsvPaidVolImportLine("CPF", "112233", "CNPJ", "666",
                CalendarUtil.getDate(2016, 8, 22), CalendarUtil.getDateNow(), "INTACTA", new BigDecimal("888.99"),
                new BigDecimal("777.99"), 3);
        entity2.setHeadOffice(headOffice);
        entity2.setGrower(grower);
        entity2.setTech(technologyINTACTA);
        entity2.setOperationalYear(operationalYear);
        lines.add(entity2);

        // Convert line to report list
        Map<PaidVolByGrowerItem, CsvPaidVolImportLine> itemToCsvLineMap = new HashMap<PaidVolByGrowerItem, CsvPaidVolImportLine>();
        List<PaidVolumeByGrower> convertedList = reportOnLineByGrowerService.generatePaidVolumeByGrowerList(lines,
                itemToCsvLineMap);
        Assert.assertNotNull(convertedList);
        Assert.assertFalse(convertedList.isEmpty());
        Assert.assertFalse(itemToCsvLineMap.isEmpty());
        Assert.assertEquals(lines.size(), itemToCsvLineMap.size());
        Assert.assertTrue("Expected two reports in converted list.", convertedList.size() == 2);

        int index = 0;
        for (PaidVolumeByGrower paidVolumeByGrower : convertedList) {

            ++index;

            Assert.assertNotNull(paidVolumeByGrower.getHeadoffice());
            Assert.assertEquals(headOffice, paidVolumeByGrower.getHeadoffice());
            Assert.assertNotNull(paidVolumeByGrower.getCreateDate());
            Assert.assertNotNull(paidVolumeByGrower.getGrower());
            Assert.assertEquals(grower, paidVolumeByGrower.getGrower());
            Assert.assertNotNull(paidVolumeByGrower.getPaidVolByGrowerItems());
            Assert.assertFalse(paidVolumeByGrower.getPaidVolByGrowerItems().isEmpty());

            Assert.assertNotNull(paidVolumeByGrower.getPeriod());

            if (index == 1) {

                for (PaidVolByGrowerItem item : paidVolumeByGrower.getPaidVolByGrowerItems()) {
                    Assert.assertNotNull(item.getPaidVolumeByGrower());
                    Assert.assertEquals(paidVolumeByGrower, item.getPaidVolumeByGrower());
                    Assert.assertNotNull(item.getRoyaltyValue());
                    Assert.assertNotNull(item.getVolume());
                    Assert.assertEquals(technologyRR, item.getTechnology());
                    Assert.assertTrue(itemToCsvLineMap.containsKey(item));

                    Assert.assertTrue("Expected one item.", paidVolumeByGrower.getPaidVolByGrowerItems().size() == 1);
                    Assert.assertTrue(paidVolumeByGrower.getTechnologies().contains(technologyRR));
                    Assert.assertEquals(CalendarUtil.getFirstDateOfMonth(entity0.getPeriod()),
                            paidVolumeByGrower.getPeriod());
                    Assert.assertEquals(entity0.getRoyaltyValue(), item.getRoyaltyValue());
                    Assert.assertEquals(entity0.getVolume(), item.getVolume());
                    Assert.assertEquals(entity0, itemToCsvLineMap.get(item));
                }

            } else {

                Assert.assertTrue("Expected one item.", paidVolumeByGrower.getPaidVolByGrowerItems().size() == 2);
                Assert.assertTrue(paidVolumeByGrower.getTechnologies().contains(technologyRR));
                Assert.assertTrue(paidVolumeByGrower.getTechnologies().contains(technologyINTACTA));

                for (PaidVolByGrowerItem item : paidVolumeByGrower.getPaidVolByGrowerItems()) {

                    if (technologyINTACTA.equals(item.getTechnology())) {
                        Assert.assertEquals(CalendarUtil.getFirstDateOfMonth(entity2.getPeriod()),
                                paidVolumeByGrower.getPeriod());
                        Assert.assertEquals(entity2.getRoyaltyValue(), item.getRoyaltyValue());
                        Assert.assertEquals(entity2.getVolume(), item.getVolume());
                        Assert.assertEquals(entity2, itemToCsvLineMap.get(item));
                    } else {
                        Assert.assertEquals(CalendarUtil.getFirstDateOfMonth(entity1.getPeriod()),
                                paidVolumeByGrower.getPeriod());
                        Assert.assertEquals(entity1.getRoyaltyValue(), item.getRoyaltyValue());
                        Assert.assertEquals(entity1.getVolume(), item.getVolume());
                        Assert.assertEquals(entity1, itemToCsvLineMap.get(item));
                    }
                }
            }
        }
    }

    @Test
    public void test_generate_paid_volume_by_grower_list_four_lines_and_three_rols() {

        // Build line list
        List<CsvPaidVolImportLine> lines = new ArrayList<CsvPaidVolImportLine>();
        CsvPaidVolImportLine entity0 = getCsvPaidVolImportLine("CPF", "112233", "CNPJ", "666",
                CalendarUtil.getDate(2016, 8, 22), CalendarUtil.getDateNow(), "RR", new BigDecimal("1.00"),
                new BigDecimal("1.00"), 1);
        entity0.setHeadOffice(headOffice);
        entity0.setGrower(grower);
        entity0.setTech(technologyRR);
        entity0.setOperationalYear(operationalYear);
        lines.add(entity0);

        CsvPaidVolImportLine entity1 = getCsvPaidVolImportLine("CPF", "112233", "CNPJ", "666",
                CalendarUtil.getDate(2016, 8, 22), CalendarUtil.getDateNow(), "RR", new BigDecimal("1.99"),
                new BigDecimal("2.99"), 2);
        entity1.setHeadOffice(headOffice);
        entity1.setGrower(grower);
        entity1.setTech(technologyRR);
        entity1.setOperationalYear(operationalYear);
        lines.add(entity1);

        CsvPaidVolImportLine entity2 = getCsvPaidVolImportLine("CPF", "112233", "CNPJ", "666",
                CalendarUtil.getDate(2016, 8, 22), CalendarUtil.getDateNow(), "INTACTA", new BigDecimal("888.99"),
                new BigDecimal("777.99"), 3);
        entity2.setHeadOffice(headOffice);
        entity2.setGrower(grower);
        entity2.setTech(technologyINTACTA);
        entity2.setOperationalYear(operationalYear);
        lines.add(entity2);

        CsvPaidVolImportLine entity3 = getCsvPaidVolImportLine("CPF", "112233", "CNPJ", "666",
                CalendarUtil.getDate(2016, 8, 22), CalendarUtil.getDateNow(), "RR", new BigDecimal("500.88"),
                new BigDecimal("20000.99"), 4);
        entity3.setHeadOffice(headOffice);
        entity3.setGrower(grower);
        entity3.setTech(technologyRR);
        entity3.setOperationalYear(operationalYear);
        lines.add(entity3);

        // Convert line to report list
        Map<PaidVolByGrowerItem, CsvPaidVolImportLine> itemToCsvLineMap = new HashMap<PaidVolByGrowerItem, CsvPaidVolImportLine>();
        List<PaidVolumeByGrower> convertedList = reportOnLineByGrowerService.generatePaidVolumeByGrowerList(lines,
                itemToCsvLineMap);
        Assert.assertNotNull(convertedList);
        Assert.assertFalse(convertedList.isEmpty());
        Assert.assertFalse(itemToCsvLineMap.isEmpty());
        Assert.assertEquals(lines.size(), itemToCsvLineMap.size());
        Assert.assertTrue("Expected two reports in converted list.", convertedList.size() == 3);

        int index = 0;
        for (PaidVolumeByGrower paidVolumeByGrower : convertedList) {

            ++index;

            Assert.assertNotNull(paidVolumeByGrower.getHeadoffice());
            Assert.assertEquals(headOffice, paidVolumeByGrower.getHeadoffice());
            Assert.assertNotNull(paidVolumeByGrower.getCreateDate());
            Assert.assertNotNull(paidVolumeByGrower.getGrower());
            Assert.assertEquals(grower, paidVolumeByGrower.getGrower());
            Assert.assertNotNull(paidVolumeByGrower.getPaidVolByGrowerItems());
            Assert.assertFalse(paidVolumeByGrower.getPaidVolByGrowerItems().isEmpty());

            Assert.assertNotNull(paidVolumeByGrower.getPeriod());

            if (index == 1) {

                for (PaidVolByGrowerItem item : paidVolumeByGrower.getPaidVolByGrowerItems()) {
                    Assert.assertNotNull(item.getPaidVolumeByGrower());
                    Assert.assertEquals(paidVolumeByGrower, item.getPaidVolumeByGrower());
                    Assert.assertNotNull(item.getRoyaltyValue());
                    Assert.assertNotNull(item.getVolume());
                    Assert.assertEquals(technologyRR, item.getTechnology());
                    Assert.assertTrue(itemToCsvLineMap.containsKey(item));

                    Assert.assertTrue("Expected one item.", paidVolumeByGrower.getPaidVolByGrowerItems().size() == 1);
                    Assert.assertTrue(paidVolumeByGrower.getTechnologies().contains(technologyRR));
                    Assert.assertEquals(CalendarUtil.getFirstDateOfMonth(entity0.getPeriod()),
                            paidVolumeByGrower.getPeriod());
                    Assert.assertEquals(entity0.getRoyaltyValue(), item.getRoyaltyValue());
                    Assert.assertEquals(entity0.getVolume(), item.getVolume());
                    Assert.assertEquals(entity0, itemToCsvLineMap.get(item));
                }

            } else if (index == 2) {

                Assert.assertTrue("Expected one item.", paidVolumeByGrower.getPaidVolByGrowerItems().size() == 2);
                Assert.assertTrue(paidVolumeByGrower.getTechnologies().contains(technologyRR));
                Assert.assertTrue(paidVolumeByGrower.getTechnologies().contains(technologyINTACTA));

                for (PaidVolByGrowerItem item : paidVolumeByGrower.getPaidVolByGrowerItems()) {

                    if (technologyINTACTA.equals(item.getTechnology())) {
                        Assert.assertEquals(CalendarUtil.getFirstDateOfMonth(entity2.getPeriod()),
                                paidVolumeByGrower.getPeriod());
                        Assert.assertEquals(entity2.getRoyaltyValue(), item.getRoyaltyValue());
                        Assert.assertEquals(entity2.getVolume(), item.getVolume());
                        Assert.assertEquals(entity2, itemToCsvLineMap.get(item));
                    } else {
                        Assert.assertEquals(CalendarUtil.getFirstDateOfMonth(entity1.getPeriod()),
                                paidVolumeByGrower.getPeriod());
                        Assert.assertEquals(entity1.getRoyaltyValue(), item.getRoyaltyValue());
                        Assert.assertEquals(entity1.getVolume(), item.getVolume());
                        Assert.assertEquals(entity1, itemToCsvLineMap.get(item));
                    }
                }

            } else {

                Assert.assertTrue("Expected one item.", paidVolumeByGrower.getPaidVolByGrowerItems().size() == 1);
                Assert.assertTrue(paidVolumeByGrower.getTechnologies().contains(technologyRR));

                for (PaidVolByGrowerItem item : paidVolumeByGrower.getPaidVolByGrowerItems()) {
                    Assert.assertEquals(CalendarUtil.getFirstDateOfMonth(entity1.getPeriod()),
                            paidVolumeByGrower.getPeriod());
                    Assert.assertEquals(entity3.getRoyaltyValue(), item.getRoyaltyValue());
                    Assert.assertEquals(entity3.getVolume(), item.getVolume());
                    Assert.assertEquals(entity3, itemToCsvLineMap.get(item));
                }
            }
        }
    }

    @Test
    public void test_generate_paid_volume_by_grower_list_two_lines_one_rol_two_itens() {

        // Build line list
        List<CsvPaidVolImportLine> lines = new ArrayList<CsvPaidVolImportLine>();
        CsvPaidVolImportLine entity0 = getCsvPaidVolImportLine("CPF", "112233", "CNPJ", "666",
                CalendarUtil.getDate(2016, 8, 22), CalendarUtil.getDateNow(), "RR", new BigDecimal("1.00"),
                new BigDecimal("1.00"), 1);
        entity0.setHeadOffice(headOffice);
        entity0.setGrower(grower);
        entity0.setTech(technologyRR);
        entity0.setOperationalYear(operationalYear);
        lines.add(entity0);

        CsvPaidVolImportLine entity1 = getCsvPaidVolImportLine("CPF", "112233", "CNPJ", "666",
                CalendarUtil.getDate(2016, 8, 22), CalendarUtil.getDateNow(), "INTACTA", new BigDecimal("100.00"),
                new BigDecimal("10.00"), 1);
        entity1.setHeadOffice(headOffice);
        entity1.setGrower(grower);
        entity1.setTech(technologyINTACTA);
        entity1.setOperationalYear(operationalYear);
        lines.add(entity1);

        // Convert line to report list
        Map<PaidVolByGrowerItem, CsvPaidVolImportLine> itemToCsvLineMap = new HashMap<PaidVolByGrowerItem, CsvPaidVolImportLine>();
        List<PaidVolumeByGrower> convertedList = reportOnLineByGrowerService.generatePaidVolumeByGrowerList(lines,
                itemToCsvLineMap);
        Assert.assertNotNull(convertedList);
        Assert.assertFalse(convertedList.isEmpty());
        Assert.assertFalse(itemToCsvLineMap.isEmpty());
        Assert.assertEquals(lines.size(), itemToCsvLineMap.size());
        Assert.assertTrue("Expected only one report in converted list.", convertedList.size() == 1);

        PaidVolumeByGrower paidVolumeByGrower = convertedList.get(0);
        Assert.assertNotNull(paidVolumeByGrower.getHeadoffice());
        Assert.assertEquals(headOffice, paidVolumeByGrower.getHeadoffice());
        Assert.assertNotNull(paidVolumeByGrower.getCreateDate());
        Assert.assertNotNull(paidVolumeByGrower.getGrower());
        Assert.assertEquals(grower, paidVolumeByGrower.getGrower());
        Assert.assertNotNull(paidVolumeByGrower.getPaidVolByGrowerItems());
        Assert.assertFalse(paidVolumeByGrower.getPaidVolByGrowerItems().isEmpty());
        Assert.assertTrue("Expected two items.", paidVolumeByGrower.getPaidVolByGrowerItems().size() == 2);
        Assert.assertNotNull(paidVolumeByGrower.getPeriod());
        Assert.assertEquals(CalendarUtil.getFirstDateOfMonth(entity0.getPeriod()), paidVolumeByGrower.getPeriod());
        Assert.assertTrue(paidVolumeByGrower.getTechnologies().contains(technologyRR));
        Assert.assertTrue(paidVolumeByGrower.getTechnologies().contains(technologyINTACTA));

        // Check itens
        for (PaidVolByGrowerItem item : paidVolumeByGrower.getPaidVolByGrowerItems()) {

            Assert.assertNotNull(item.getPaidVolumeByGrower());
            Assert.assertEquals(paidVolumeByGrower, item.getPaidVolumeByGrower());
            Assert.assertNotNull(item.getRoyaltyValue());
            Assert.assertNotNull(item.getVolume());

            if (item.getTechnology().equals(technologyINTACTA)) {
                Assert.assertEquals(entity1.getRoyaltyValue(), item.getRoyaltyValue());
                Assert.assertEquals(entity1.getVolume(), item.getVolume());
                Assert.assertTrue(itemToCsvLineMap.containsKey(item));
                Assert.assertEquals(entity1, itemToCsvLineMap.get(item));
            } else {
                Assert.assertEquals(entity0.getRoyaltyValue(), item.getRoyaltyValue());
                Assert.assertEquals(entity0.getVolume(), item.getVolume());
                Assert.assertEquals(technologyRR, item.getTechnology());
                Assert.assertTrue(itemToCsvLineMap.containsKey(item));
                Assert.assertEquals(entity0, itemToCsvLineMap.get(item));
            }
        }

    }

    @Test
    public void test_generate_paid_volume_by_grower_list_three_lines_one_rol_three_itens() {

        // Build line list
        List<CsvPaidVolImportLine> lines = new ArrayList<CsvPaidVolImportLine>();
        CsvPaidVolImportLine entity0 = getCsvPaidVolImportLine("CPF", "112233", "CNPJ", "666",
                CalendarUtil.getDate(2016, 8, 22), CalendarUtil.getDateNow(), "RR", new BigDecimal("1.00"),
                new BigDecimal("1.00"), 1);
        entity0.setHeadOffice(headOffice);
        entity0.setGrower(grower);
        entity0.setTech(technologyRR);
        entity0.setOperationalYear(operationalYear);
        lines.add(entity0);

        CsvPaidVolImportLine entity1 = getCsvPaidVolImportLine("CPF", "112233", "CNPJ", "666",
                CalendarUtil.getDate(2016, 8, 22), CalendarUtil.getDateNow(), "INTACTA", new BigDecimal("100.00"),
                new BigDecimal("10.00"), 2);
        entity1.setHeadOffice(headOffice);
        entity1.setGrower(grower);
        entity1.setTech(technologyINTACTA);
        entity1.setOperationalYear(operationalYear);
        lines.add(entity1);

        CsvPaidVolImportLine entity2 = getCsvPaidVolImportLine("CPF", "112233", "CNPJ", "666",
                CalendarUtil.getDate(2016, 8, 22), CalendarUtil.getDateNow(), "XPTO", new BigDecimal("1000.00"),
                new BigDecimal("100.00"), 3);
        entity2.setHeadOffice(headOffice);
        entity2.setGrower(grower);
        entity2.setTech(technologyXPTO);
        entity2.setOperationalYear(operationalYear);
        lines.add(entity2);

        // Convert line to report list
        Map<PaidVolByGrowerItem, CsvPaidVolImportLine> itemToCsvLineMap = new HashMap<PaidVolByGrowerItem, CsvPaidVolImportLine>();
        List<PaidVolumeByGrower> convertedList = reportOnLineByGrowerService.generatePaidVolumeByGrowerList(lines,
                itemToCsvLineMap);
        Assert.assertNotNull(convertedList);
        Assert.assertFalse(convertedList.isEmpty());
        Assert.assertFalse(itemToCsvLineMap.isEmpty());
        Assert.assertEquals(lines.size(), itemToCsvLineMap.size());
        Assert.assertTrue("Expected only one report in converted list.", convertedList.size() == 1);

        PaidVolumeByGrower paidVolumeByGrower = convertedList.get(0);
        Assert.assertNotNull(paidVolumeByGrower.getHeadoffice());
        Assert.assertEquals(headOffice, paidVolumeByGrower.getHeadoffice());
        Assert.assertNotNull(paidVolumeByGrower.getCreateDate());
        Assert.assertNotNull(paidVolumeByGrower.getGrower());
        Assert.assertEquals(grower, paidVolumeByGrower.getGrower());
        Assert.assertNotNull(paidVolumeByGrower.getPaidVolByGrowerItems());
        Assert.assertFalse(paidVolumeByGrower.getPaidVolByGrowerItems().isEmpty());
        Assert.assertTrue("Expected two items.", paidVolumeByGrower.getPaidVolByGrowerItems().size() == 3);
        Assert.assertNotNull(paidVolumeByGrower.getPeriod());
        Assert.assertEquals(CalendarUtil.getFirstDateOfMonth(entity0.getPeriod()), paidVolumeByGrower.getPeriod());
        Assert.assertTrue(paidVolumeByGrower.getTechnologies().contains(technologyRR));
        Assert.assertTrue(paidVolumeByGrower.getTechnologies().contains(technologyINTACTA));

        // Check itens
        for (PaidVolByGrowerItem item : paidVolumeByGrower.getPaidVolByGrowerItems()) {

            Assert.assertNotNull(item.getPaidVolumeByGrower());
            Assert.assertEquals(paidVolumeByGrower, item.getPaidVolumeByGrower());
            Assert.assertNotNull(item.getRoyaltyValue());
            Assert.assertNotNull(item.getVolume());

            if (item.getTechnology().equals(technologyXPTO)) {
                Assert.assertEquals(entity2.getRoyaltyValue(), item.getRoyaltyValue());
                Assert.assertEquals(entity2.getVolume(), item.getVolume());
                Assert.assertTrue(itemToCsvLineMap.containsKey(item));
                Assert.assertEquals(entity2, itemToCsvLineMap.get(item));
            } else if (item.getTechnology().equals(technologyINTACTA)) {
                Assert.assertEquals(entity1.getRoyaltyValue(), item.getRoyaltyValue());
                Assert.assertEquals(entity1.getVolume(), item.getVolume());
                Assert.assertTrue(itemToCsvLineMap.containsKey(item));
                Assert.assertEquals(entity1, itemToCsvLineMap.get(item));
            } else {
                Assert.assertEquals(entity0.getRoyaltyValue(), item.getRoyaltyValue());
                Assert.assertEquals(entity0.getVolume(), item.getVolume());
                Assert.assertEquals(technologyRR, item.getTechnology());
                Assert.assertTrue(itemToCsvLineMap.containsKey(item));
                Assert.assertEquals(entity0, itemToCsvLineMap.get(item));
            }
        }

    }

    @Test
    public void test_save_paid_volume_by_grower_csv() {

        List<CsvPaidVolImportLine> lines = new ArrayList<CsvPaidVolImportLine>();

        CsvPaidVolImportLine entity1 = getCsvPaidVolImportLine("CPF", "112233", "CNPJ", "666",
                CalendarUtil.getDate(2016, 8, 22), CalendarUtil.getDateNow(), "INTACTA", new BigDecimal("100.00"),
                new BigDecimal("10.00"), 1);
        entity1.setHeadOffice(headOffice);
        entity1.setGrower(grower);
        entity1.setTech(technologyINTACTA);
        entity1.setOperationalYear(operationalYear);
        lines.add(entity1);

        // Convert line to report list
        Map<PaidVolByGrowerItem, CsvPaidVolImportLine> itemToCsvLineMap = new HashMap<PaidVolByGrowerItem, CsvPaidVolImportLine>();
        List<PaidVolumeByGrower> convertedList = reportOnLineByGrowerService.generatePaidVolumeByGrowerList(lines,
                itemToCsvLineMap);
        Assert.assertNotNull(convertedList);
        Assert.assertFalse(convertedList.isEmpty());
        Assert.assertFalse(itemToCsvLineMap.isEmpty());
        Assert.assertEquals(lines.size(), itemToCsvLineMap.size());

        // Mock rol info
        ReportOnLineInfo rolInfo = new ReportOnLineInfo();
        rolInfo.setCrop(crop);
        rolInfo.setCompany(company);

        // Save paid volume group
        Map<CsvPaidVolImportLine, ReportOnlineByGrowerConstraintException> overflowLines = reportOnLineByGrowerService
                .savePaidVolumeByGrowerCSV(convertedList.get(0), itemToCsvLineMap, rolInfo);
        Assert.assertTrue(overflowLines.isEmpty());

    }

    @Test
    public void test_save_paid_volume_by_grower_csv_one_rol_two_itens_one_overflow_item_INTACTA_value() {

        List<CsvPaidVolImportLine> lines = new ArrayList<CsvPaidVolImportLine>();

        CsvPaidVolImportLine entity1 = getCsvPaidVolImportLine("CPF", "112233", "CNPJ", "666",
                CalendarUtil.getDate(2016, 8, 22), CalendarUtil.getDateNow(), "INTACTA", new BigDecimal("1000000.00"),
                new BigDecimal("10.00"), 1);
        entity1.setHeadOffice(headOffice);
        entity1.setGrower(grower);
        entity1.setTech(technologyINTACTA);
        entity1.setOperationalYear(operationalYear);
        lines.add(entity1);

        CsvPaidVolImportLine entity2 = getCsvPaidVolImportLine("CPF", "112233", "CNPJ", "666",
                CalendarUtil.getDate(2016, 8, 22), CalendarUtil.getDateNow(), "INTACTA", new BigDecimal("1.00"),
                new BigDecimal("1.00"), 1);
        entity2.setHeadOffice(headOffice);
        entity2.setGrower(grower);
        entity2.setTech(technologyRR);
        entity2.setOperationalYear(operationalYear);
        lines.add(entity2);

        // Convert line to report list
        Map<PaidVolByGrowerItem, CsvPaidVolImportLine> itemToCsvLineMap = new HashMap<PaidVolByGrowerItem, CsvPaidVolImportLine>();
        List<PaidVolumeByGrower> convertedList = reportOnLineByGrowerService.generatePaidVolumeByGrowerList(lines,
                itemToCsvLineMap);
        Assert.assertNotNull(convertedList);
        Assert.assertFalse(convertedList.isEmpty());
        Assert.assertFalse(itemToCsvLineMap.isEmpty());
        Assert.assertEquals(lines.size(), itemToCsvLineMap.size());

        // Mock rol info
        ReportOnLineInfo rolInfo = new ReportOnLineInfo();
        rolInfo.setCrop(crop);
        rolInfo.setCompany(company);

        // Mock rol search
        ReportOnLine rol = new ReportOnLine();

        RolParameter rolParameterRR = new RolParameter();
        rolParameterRR.setRolParValidateByGrower(Boolean.TRUE);
        rolParameterRR.setTechnology(technologyRR);

        UsedRolParameter usedRolParameter0 = new UsedRolParameter();
        usedRolParameter0.setRolParameter(rolParameterRR);
        usedRolParameter0.setUsedRolParameterTonValue(BigDecimal.ONE);
        usedRolParameter0.setUsedRolParamMonetaryVal(new BigDecimal("99.00"));
        rol.getUsedRolParameters().add(usedRolParameter0);

        RolParameter rolParameterINTACTA = new RolParameter();
        rolParameterINTACTA.setRolParValidateByGrower(Boolean.TRUE);
        rolParameterINTACTA.setTechnology(technologyINTACTA);

        UsedRolParameter usedRolParameter1 = new UsedRolParameter();
        usedRolParameter1.setRolParameter(rolParameterINTACTA);
        usedRolParameter1.setUsedRolParameterTonValue(BigDecimal.ONE);
        usedRolParameter1.setUsedRolParamMonetaryVal(new BigDecimal("999.00"));
        rol.getUsedRolParameters().add(usedRolParameter1);

        Mockito.when(
                reportOnLineService.searchReportOnline((Crop) Mockito.anyObject(), (HeadOffice) Mockito.anyObject(),
                        (Date) Mockito.anyObject(), (OperationalYear) Mockito.anyObject())).thenReturn(rol);

        // Save paid volume group
        Map<CsvPaidVolImportLine, ReportOnlineByGrowerConstraintException> overflowLines = reportOnLineByGrowerService
                .savePaidVolumeByGrowerCSV(convertedList.get(0), itemToCsvLineMap, rolInfo);
        Assert.assertFalse(overflowLines.isEmpty());
        Assert.assertEquals(1, overflowLines.size());
        Assert.assertEquals(entity1, overflowLines.keySet().iterator().next());
    }

    /**
     * @return
     */
    private CsvPaidVolImportLine getCsvPaidVolImportLine(String growerDocType, String growerDoc,
            String customerDocType, String customerDoc, Date period, Date dateReceive, String technology,
            BigDecimal royaltValue, BigDecimal vol, Integer line) {
        CsvPaidVolImportLine entity = new CsvPaidVolImportLine();
        entity.setGrowerDocumentType(growerDocType);
        entity.setGrowerDocument(growerDoc);
        entity.setCustomerDocumentType(customerDocType);
        entity.setCustomerDocument(customerDoc);
        // period
        entity.setPeriod(period);
        entity.setDateReceive(dateReceive);
        // values
        entity.setRoyaltyValue(royaltValue);
        entity.setVolume(vol);
        entity.setTechnology(technology);
        entity.setLine(line);
        return entity;
    }

    @Test(expected = IllegalArgumentException.class)
    public void test_select_volume_and_value_from_grower_throws_exception_no_crop() {
        PaidVolumeFilter filter = new PaidVolumeFilter();
        filter.setCrop(null);
        reportOnLineByGrowerService.sumVolumeAndValueFromPaidVolumeByGrowerByFilter(filter);
    }

    @Test(expected = IllegalArgumentException.class)
    public void test_select_volume_and_value_from_grower_throws_exception_no_company() {
        PaidVolumeFilter filter = new PaidVolumeFilter();
        filter.setCompany(null);
        reportOnLineByGrowerService.sumVolumeAndValueFromPaidVolumeByGrowerByFilter(filter);
    }

    @Test(expected = IllegalArgumentException.class)
    public void search_paid_fixed_volume_grower_dto_by_filter_is_null() throws ReportOnlineByGrowerException,
            ParseException {

        PaidVolumeFilter pvFilter = new PaidVolumeFilter();
        // Search report with crop and company null
        List<PaidVolumeByGrowerSearchDTO> pvByGrower = reportOnLineByGrowerService
                .selectPaidVolumeByGrowerListDTOByFilter(pvFilter);
        Assert.assertEquals(0, pvByGrower.size());
    }

    @Test(expected = NullPointerException.class)
    public void search_paid_fixed_volume_grower_dto_by_filter_is_empty() throws ReportOnlineByGrowerException,
            ParseException {
        List<PaidVolumeByGrowerSearchDTO> pvByGrower = reportOnLineByGrowerService
                .selectPaidVolumeByGrowerListDTOByFilter(null);
        Assert.assertNull(pvByGrower);
    }
}
