package com.monsanto.brazilvaluecapture.pod.waybill.model.bean;

import org.junit.Test;

import java.math.BigInteger;
import java.util.Collections;
import java.util.Date;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.mock;

public class IncomingWaybillPY_UT {

    @Test
    public void testNewInstanceHasEmptyLabResults() {
        IncomingWaybillPY incomingWaybill = new IncomingWaybillPY();

        assertTrue(incomingWaybill.getLabResults().isEmpty());
    }

    @Test
    public void testToString() {
        IncomingWaybillPY incomingWaybill = new IncomingWaybillPY();
        incomingWaybill.setId(41L);
        incomingWaybill.setWaybillNumber("98725");

        String str = incomingWaybill.toString();

        assertEquals("IncomingWaybillPY={id=41,waybillNumber=98725}", str);
    }

    @Test
    public void testSettersAndGetters() {
        Long id = 78L;
        String countryCode = "countryCode";
        Long bulkId = 93L;
        Date receivedOn = mock(Date.class);
        Date processedOn = mock(Date.class);
        String ctgStatus = "ctgStatus";
        Date ctgIssueDate = mock(Date.class);
        Date ctgDateSince = mock(Date.class);
        Date ctgDateUntil = mock(Date.class);
        Integer ctgKilometersTraveled = 675;
        TransportType transportType = TransportType.BARGE;
        String holderName = "holderName";
        String holderDocumentType = "holderDocumentType";
        Long holderDocumentNumber = 8432L;
        String intermediaryName = "intermediaryName";
        Long intermediaryDocumentNumber = 28429L;
        String commercialSenderName = "commercialSenderName";
        String commercialSenderDocumentType = "commercialSenderDocumentType";
        Long commercialSenderDocumentNumber = 812935L;
        String brokerName = "brokerName";
        Long brokerDocumentNumber = 1298482L;
        String agentName = "agentName";
        Long agentDocumentNumber = 456123L;
        String addresseeName = "addresseeName";
        String addresseeDocumentType = "addresseeDocumentType";
        Long addresseeDocumentNumber = 853285L;
        String destinationName = "destinationName";
        String destinationDocumentType = "destinationDocumentType";
        Long destinationDocumentNumber = 5439871L;
        String campaignCode = "campaignCode";
        String cropCode = "cropCode";
        String sourceAddress = "sourceAddress";
        String establishment = "establishment";
        BigInteger netWeight = BigInteger.ONE;
        Long sourceCityCode = 23L;
        Long sourceStateCode = 5L;
        String destinationAddress = "destinationAddress";
        Long destinationCityCode = 16L;
        Long destinationStateCode = 6L;
        Long deviationDestinationDocumentNumber = 283746L;
        String deviationDestinationAddress = "deviationDestinationAddress";
        String deviationDestinationPlantCode = "deviationDestinationPlantCode";
        Date deviationDate = mock(Date.class);
        String deviationTransferRequestedBy = "deviationTransferRequestedBy";
        Long deviationAddresseeDocumentNumber = 5463728L;
        String deviationAddresseeCityCode = "deviationAddresseeCityCode";
        LabResult labResult = mock(LabResult.class);
        String waybillNumber = "waybillNumber";
        IncomingWaybillPY incomingWaybill = new IncomingWaybillPY();

        incomingWaybill.setId(id);
        incomingWaybill.setCountryCode(countryCode);
        incomingWaybill.setBulkId(bulkId);
        incomingWaybill.setReceivedOn(receivedOn);
        incomingWaybill.setProcessedOn(processedOn);
        incomingWaybill.setCtgStatus(ctgStatus);
        incomingWaybill.setCtgIssueDate(ctgIssueDate);
        incomingWaybill.setCtgDateSince(ctgDateSince);
        incomingWaybill.setCtgDateUntil(ctgDateUntil);
        incomingWaybill.setCtgKilometersTraveled(ctgKilometersTraveled);
        incomingWaybill.setTransportType(transportType);
        incomingWaybill.setHolderName(holderName);
        incomingWaybill.setHolderDocumentType(holderDocumentType);
        incomingWaybill.setHolderDocumentNumber(holderDocumentNumber);
        incomingWaybill.setIntermediaryName(intermediaryName);
        incomingWaybill.setIntermediaryDocumentNumber(intermediaryDocumentNumber);
        incomingWaybill.setCommercialSenderName(commercialSenderName);
        incomingWaybill.setCommercialSenderDocumentType(commercialSenderDocumentType);
        incomingWaybill.setCommercialSenderDocumentNumber(commercialSenderDocumentNumber);
        incomingWaybill.setBrokerName(brokerName);
        incomingWaybill.setBrokerDocumentNumber(brokerDocumentNumber);
        incomingWaybill.setAgentName(agentName);
        incomingWaybill.setAgentDocumentNumber(agentDocumentNumber);
        incomingWaybill.setAddresseeName(addresseeName);
        incomingWaybill.setAddresseeDocumentType(addresseeDocumentType);
        incomingWaybill.setAddresseeDocumentNumber(addresseeDocumentNumber);
        incomingWaybill.setDestinationName(destinationName);
        incomingWaybill.setDestinationDocumentType(destinationDocumentType);
        incomingWaybill.setDestinationDocumentNumber(destinationDocumentNumber);
        incomingWaybill.setCampaignCode(campaignCode);
        incomingWaybill.setCropCode(cropCode);
        incomingWaybill.setSourceAddress(sourceAddress);
        incomingWaybill.setEstablishment(establishment);
        incomingWaybill.setNetWeight(netWeight);
        incomingWaybill.setSourceCityCode(sourceCityCode);
        incomingWaybill.setSourceStateCode(sourceStateCode);
        incomingWaybill.setDestinationAddress(destinationAddress);
        incomingWaybill.setDestinationCityCode(destinationCityCode);
        incomingWaybill.setDestinationStateCode(destinationStateCode);
        incomingWaybill.setDeviationDestinationDocumentNumber(deviationDestinationDocumentNumber);
        incomingWaybill.setDeviationDestinationAddress(deviationDestinationAddress);
        incomingWaybill.setDeviationDestinationPlantCode(deviationDestinationPlantCode);
        incomingWaybill.setDeviationDate(deviationDate);
        incomingWaybill.setDeviationTransferRequestedBy(deviationTransferRequestedBy);
        incomingWaybill.setDeviationAddresseeDocumentNumber(deviationAddresseeDocumentNumber);
        incomingWaybill.setDeviationAddresseeCityCode(deviationAddresseeCityCode);
        incomingWaybill.setLabResults(Collections.singleton(labResult));
        incomingWaybill.setWaybillNumber(waybillNumber);

        assertEquals(id, incomingWaybill.getId());
        assertEquals(id, incomingWaybill.getPrimaryKey());
        assertEquals(countryCode, incomingWaybill.getCountryCode());
        assertEquals(bulkId, incomingWaybill.getBulkId());
        assertEquals(receivedOn, incomingWaybill.getReceivedOn());
        assertEquals(processedOn, incomingWaybill.getProcessedOn());
        assertEquals(ctgStatus, incomingWaybill.getCtgStatus());
        assertEquals(ctgIssueDate, incomingWaybill.getCtgIssueDate());
        assertEquals(ctgDateSince, incomingWaybill.getCtgDateSince());
        assertEquals(ctgDateUntil, incomingWaybill.getCtgDateUntil());
        assertEquals(ctgKilometersTraveled, incomingWaybill.getCtgKilometersTraveled());
        assertEquals(transportType, incomingWaybill.getTransportType());
        assertEquals(holderName, incomingWaybill.getHolderName());
        assertEquals(holderDocumentType, incomingWaybill.getHolderDocumentType());
        assertEquals(holderDocumentNumber, incomingWaybill.getHolderDocumentNumber());
        assertEquals(intermediaryName, incomingWaybill.getIntermediaryName());
        assertEquals(intermediaryDocumentNumber, incomingWaybill.getIntermediaryDocumentNumber());
        assertEquals(commercialSenderName, incomingWaybill.getCommercialSenderName());
        assertEquals(commercialSenderDocumentType, incomingWaybill.getCommercialSenderDocumentType());
        assertEquals(commercialSenderDocumentNumber, incomingWaybill.getCommercialSenderDocumentNumber());
        assertEquals(brokerName, incomingWaybill.getBrokerName());
        assertEquals(brokerDocumentNumber, incomingWaybill.getBrokerDocumentNumber());
        assertEquals(agentName, incomingWaybill.getAgentName());
        assertEquals(agentDocumentNumber, incomingWaybill.getAgentDocumentNumber());
        assertEquals(addresseeName, incomingWaybill.getAddresseeName());
        assertEquals(addresseeDocumentType, incomingWaybill.getAddresseeDocumentType());
        assertEquals(addresseeDocumentNumber, incomingWaybill.getAddresseeDocumentNumber());
        assertEquals(destinationName, incomingWaybill.getDestinationName());
        assertEquals(destinationDocumentType, incomingWaybill.getDestinationDocumentType());
        assertEquals(destinationDocumentNumber, incomingWaybill.getDestinationDocumentNumber());
        assertEquals(campaignCode, incomingWaybill.getCampaignCode());
        assertEquals(cropCode, incomingWaybill.getCropCode());
        assertEquals(sourceAddress, incomingWaybill.getSourceAddress());
        assertEquals(establishment, incomingWaybill.getEstablishment());
        assertEquals(netWeight, incomingWaybill.getNetWeight());
        assertEquals(sourceCityCode, incomingWaybill.getSourceCityCode());
        assertEquals(sourceStateCode, incomingWaybill.getSourceStateCode());
        assertEquals(destinationAddress, incomingWaybill.getDestinationAddress());
        assertEquals(destinationCityCode, incomingWaybill.getDestinationCityCode());
        assertEquals(destinationStateCode, incomingWaybill.getDestinationStateCode());
        assertEquals(deviationDestinationDocumentNumber, incomingWaybill.getDeviationDestinationDocumentNumber());
        assertEquals(deviationDestinationAddress, incomingWaybill.getDeviationDestinationAddress());
        assertEquals(deviationDestinationPlantCode, incomingWaybill.getDeviationDestinationPlantCode());
        assertEquals(deviationDate, incomingWaybill.getDeviationDate());
        assertEquals(deviationTransferRequestedBy, incomingWaybill.getDeviationTransferRequestedBy());
        assertEquals(deviationAddresseeDocumentNumber, incomingWaybill.getDeviationAddresseeDocumentNumber());
        assertEquals(deviationAddresseeCityCode, incomingWaybill.getDeviationAddresseeCityCode());
        assertEquals(1, incomingWaybill.getLabResults().size());
        assertEquals(labResult, incomingWaybill.getLabResults().iterator().next());
        assertEquals(waybillNumber, incomingWaybill.getWaybillNumber());
    }

}