package com.monsanto.brazilvaluecapture.pod.rol.report;

import com.monsanto.brazilvaluecapture.core.base.model.bean.Company;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Technology;
import com.monsanto.brazilvaluecapture.pod.rol.model.bean.GroupAction;
import com.monsanto.brazilvaluecapture.pod.rol.model.bean.OperationalYearType;
import com.monsanto.brazilvaluecapture.pod.rol.model.bean.RolFrameGroup;
import com.monsanto.brazilvaluecapture.pod.rol.model.bean.RolParameter;
import com.monsanto.brazilvaluecapture.pod.rol.model.service.impl.CsvReportOnlineTemplate;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.ResourceBundle;

/**
 * Unit test for template report to import rol assembler.
 * 
 * @author cmiranda
 * 
 */
public class TemplateReportOnlineAssembler_UT {

    /**
     * Assembler to test
     */
    private TemplateReportOnlineAssembler assembler;

    /**
     * Template generator
     */
    private CsvReportOnlineTemplate template;

    /**
     * Parameter list.
     */
    private List<RolParameter> parameters = new ArrayList<RolParameter>();

    /**
     * Bundle
     */
    private ResourceBundle resourceBundle = ResourceBundle.getBundle("bundle/bundle", new Locale("pt", "BR"));

    private String actualLabel;
    private String actualLabelMinus;
    private String actualLabelMinusTwo;

    @Before
    public void setup() {

        actualLabel = resourceBundle.getString("pod.rol.parameter.actual.label");
        actualLabelMinus = resourceBundle.getString("pod.rol.parameter.actual.label.one");
        actualLabelMinusTwo = resourceBundle.getString("pod.rol.parameter.actual.label.two");

        Company company = new Company("mxto");
        Technology technology = new Technology("RR", company);
        technology.setId(1L);

        // Actions
        GroupAction groupActionCalculate = new GroupAction(-1L, GroupAction.GROUP_ACTION_CALCULATE,
                GroupAction.GROUP_ACTION_CALCULATE);

        GroupAction groupActionSum = new GroupAction(-2L, GroupAction.GROUP_ACTION_SUM, GroupAction.GROUP_ACTION_SUM);

        GroupAction groupActionNoAction = new GroupAction(-2L, GroupAction.GROUP_ACTION_SUM,
                GroupAction.GROUP_ACTION_NOACTION);

        // Frame group
        RolFrameGroup rolFrameGroupReceived = new RolFrameGroup();
        rolFrameGroupReceived.setRolFrameGroupCode(RolFrameGroup.FRAME_GROUP_RECEIVED);

        RolFrameGroup rolFrameGroupFixedOccurr = new RolFrameGroup();
        rolFrameGroupFixedOccurr.setRolFrameGroupCode(RolFrameGroup.FRAME_GROUP_FIXEDCURR);

        RolFrameGroup rolFrameGroupFixedOld = new RolFrameGroup();
        rolFrameGroupFixedOld.setRolFrameGroupCode(RolFrameGroup.FRAME_GROUP_FIXEDOLD);

        RolFrameGroup rolFrameGroupTestStripe = new RolFrameGroup();
        rolFrameGroupTestStripe.setRolFrameGroupCode(RolFrameGroup.FRAME_GROUP_TESTSTRYPE);

        // Operational year type
        OperationalYearType operationalYearTypeActualYear = new OperationalYearType();
        operationalYearTypeActualYear.setOperationalYearTypeCode("actual");
        operationalYearTypeActualYear.setOperationalYearTypeDiff(0);
        operationalYearTypeActualYear.setOperationalYearTypeBundle("pod.rol.parameter.actual.label");

        OperationalYearType operationalYearTypeLessOne = new OperationalYearType();
        operationalYearTypeLessOne.setOperationalYearTypeCode("-1");
        operationalYearTypeLessOne.setOperationalYearTypeDiff(-1);
        operationalYearTypeLessOne.setOperationalYearTypeBundle("pod.rol.parameter.actual.label.one");

        OperationalYearType operationalYearTypeLessTwo = new OperationalYearType();
        operationalYearTypeLessTwo.setOperationalYearTypeCode("-2");
        operationalYearTypeLessTwo.setOperationalYearTypeDiff(-2);
        operationalYearTypeLessTwo.setOperationalYearTypeBundle("pod.rol.parameter.actual.label.two");

        // Rol parameter received
        RolParameter rolParameter = new RolParameter();
        rolParameter.setGroupAction(groupActionNoAction);
        rolParameter.setOperationalYearType(operationalYearTypeActualYear);
        rolParameter.setRolFrameGroup(rolFrameGroupReceived);
        rolParameter.setRolParamShownDescription("received");
        rolParameter.setTechnology(technology);
        parameters.add(rolParameter);

        // Rol parameter fix paid current year
        rolParameter = new RolParameter();
        rolParameter.setGroupAction(groupActionNoAction);
        rolParameter.setOperationalYearType(operationalYearTypeActualYear);
        rolParameter.setRolFrameGroup(rolFrameGroupFixedOccurr);
        rolParameter.setRolParamShownDescription("fixed paid current year");
        rolParameter.setTechnology(technology);
        parameters.add(rolParameter);

        // Rol parameter fix paid old year -1
        rolParameter = new RolParameter();
        rolParameter.setGroupAction(groupActionNoAction);
        rolParameter.setOperationalYearType(operationalYearTypeLessOne);
        rolParameter.setRolFrameGroup(rolFrameGroupFixedOld);
        rolParameter.setRolParamShownDescription("fixed paid old year");
        rolParameter.setTechnology(technology);
        parameters.add(rolParameter);

        // Rol parameter fix paid old year -2
        rolParameter = new RolParameter();
        rolParameter.setGroupAction(groupActionCalculate);
        rolParameter.setOperationalYearType(operationalYearTypeLessTwo);
        rolParameter.setRolFrameGroup(rolFrameGroupFixedOld);
        rolParameter.setRolParamShownDescription("fixed paid old year");
        rolParameter.setTechnology(technology);
        parameters.add(rolParameter);

        // Rol parameter fix test stripes calculateServiceFeeValue
        rolParameter = new RolParameter();
        rolParameter.setGroupAction(groupActionCalculate);
        rolParameter.setOperationalYearType(operationalYearTypeActualYear);
        rolParameter.setRolFrameGroup(rolFrameGroupTestStripe);
        rolParameter.setRolParamShownDescription("calculateServiceFeeValue test stripe");
        rolParameter.setTechnology(technology);
        parameters.add(rolParameter);

        // Rol parameter fix test stripes sum
        rolParameter = new RolParameter();
        rolParameter.setGroupAction(groupActionSum);
        rolParameter.setOperationalYearType(operationalYearTypeActualYear);
        rolParameter.setRolFrameGroup(rolFrameGroupTestStripe);
        rolParameter.setRolParamShownDescription("sum test stripe");
        rolParameter.setTechnology(technology);
        parameters.add(rolParameter);

        // Rol parameter fix test stripes no action
        rolParameter = new RolParameter();
        rolParameter.setGroupAction(groupActionNoAction);
        rolParameter.setOperationalYearType(operationalYearTypeActualYear);
        rolParameter.setRolFrameGroup(rolFrameGroupTestStripe);
        rolParameter.setRolParamShownDescription("no action test stripe");
        rolParameter.setTechnology(technology);
        parameters.add(rolParameter);

        // Create template
        template = new CsvReportOnlineTemplate(parameters, resourceBundle);

        // Create assembler
        assembler = new TemplateReportOnlineAssembler(template);
    }

    /**
     * @throws IOException
     */
    @Test
    public void test_build_template_import_rol() throws IOException {

        // Build headers
        List<String> headers = template.getHeaders();
        System.out.println(headers);

        Assert.assertNotNull(headers);
        Assert.assertFalse(headers.isEmpty());

        // Validate header size expected
        Assert.assertEquals(11, headers.size());

        ByteArrayOutputStream baos = assembler.build();
        Assert.assertNotNull(baos);

        System.out.println(baos.toString());

        // Headers labels to check
        Assert.assertEquals(
                "Periodo;Nro. Documento Filial;RR - Total Qtde received - Recebido;RR - Qtde. - fixed paid current year - "
                        + actualLabel + ";RR - Valor - fixed paid current year - " + actualLabel
                        + ";RR - Qtde. - fixed paid old year - " + actualLabelMinus
                        + ";RR - Valor - fixed paid old year - " + actualLabelMinus
                        + ";RR - Qtde. - fixed paid old year - " + actualLabelMinusTwo
                        + ";RR - Valor - fixed paid old year - " + actualLabelMinusTwo
                        + ";RR - sum test stripe;RR - no action test stripe", baos.toString());

    }

}
