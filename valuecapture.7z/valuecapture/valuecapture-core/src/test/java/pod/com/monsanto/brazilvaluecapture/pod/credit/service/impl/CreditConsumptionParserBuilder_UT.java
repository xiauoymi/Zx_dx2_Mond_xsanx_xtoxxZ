package com.monsanto.brazilvaluecapture.pod.credit.service.impl;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

import com.monsanto.brazilvaluecapture.core.user.model.bean.UserContract;
import com.monsanto.brazilvaluecapture.pod.credit.service.CreditConsumptionConstraintException;
import com.monsanto.brazilvaluecapture.pod.credit.service.CreditService;

public class CreditConsumptionParserBuilder_UT {

    private CreditConsumptionParserBuilder creditConsumptionParserBuilder;
    private CreditService creditService;
    private ArrayList<UserContract> listUserContract;

    @Before
    public void setUp() throws Exception {
         creditService = Mockito.mock(CreditService.class);
        listUserContract = new ArrayList<UserContract>();
        String cropDescription = "SOJA";
        String companyDescription = "Bunge";
        String matrixSelected = "223334440001505";
        String userLogin = "JOHN";
        creditConsumptionParserBuilder = new CreditConsumptionParserBuilder(creditService, companyDescription,
                matrixSelected, cropDescription, listUserContract, userLogin);
        CsvCreditConsumptionItem csvCreditConsumptionItemMock = Mockito.mock(CsvCreditConsumptionItem.class);
        creditConsumptionParserBuilder.getCsvListCreditConsumptionItem().add(csvCreditConsumptionItemMock);
    }

    @Test
    public void test_countLines_to_proccess_is_not_zero() {
        assertTrue(creditConsumptionParserBuilder.countLinesToProccess() > 0);
    }

    @Test
    public void test_Count_Candidate_CreditConsumption_is_not_zero() {
        assertTrue(creditConsumptionParserBuilder.countCandidateCreditConsumption() > 0);
    }

    @Test
    public void testSearchErrors() {
        creditConsumptionParserBuilder.searchErrors();
        assertTrue(creditConsumptionParserBuilder.getCreditConsumptionParserResult().getWarnings().isEmpty());
    }

    @Test
    public void test_build_import_with_success() throws CreditConsumptionConstraintException {
        List<CsvCreditConsumptionItem> csvCreditConsumptions = new ArrayList<CsvCreditConsumptionItem>();
        CsvCreditConsumptionItem csvCreditConsumptionItem = Mockito.mock(CsvCreditConsumptionItem.class);
        csvCreditConsumptions.add(csvCreditConsumptionItem);
        creditConsumptionParserBuilder.setCsvCreditConsumptionToProcess(csvCreditConsumptions);
        assertNotNull(creditConsumptionParserBuilder.buildImport());
    }
    
    @Test
    public void testGetMatrixSelected() {
        assertNotNull(creditConsumptionParserBuilder.getMatrixSelected());
    }

    @Test
    public void test_ListUserContract_is_empty() {
       assertTrue(creditConsumptionParserBuilder.getListUserContract().isEmpty());
    }

    @Test
    public void tesT_list_user_contract_is_not_empty() {
        UserContract userContract = Mockito.mock(UserContract.class);
        listUserContract.add(userContract);
        creditConsumptionParserBuilder.setListUserContract(listUserContract);
        assertFalse(creditConsumptionParserBuilder.getListUserContract().isEmpty());
    }

    @Test
    public void test_Get_Csv_List_CreditConsumptionItem_is_not_null() {
        List<CsvCreditConsumptionItem> csvCreditConsumptions = new ArrayList<CsvCreditConsumptionItem>();
        CsvCreditConsumptionItem csvCreditConsumptionItem = Mockito.mock(CsvCreditConsumptionItem.class);
        csvCreditConsumptions.add(csvCreditConsumptionItem);
        creditConsumptionParserBuilder.setCsvCreditConsumptionToProcess(csvCreditConsumptions);
        assertFalse(creditConsumptionParserBuilder.getCsvListCreditConsumptionItem().isEmpty());
    }

    @Test
    public void test_Get_Company_Description_not_null() {
       assertNotNull(creditConsumptionParserBuilder.getCompanyDescription());
    }

    @Test
    public void test_Get_Crop_Description_not_null() {
        assertNotNull(creditConsumptionParserBuilder.getCropDescription());
    }

    @Test
    public void test_Get_UserLogin_not_null() {
        assertNotNull(creditConsumptionParserBuilder.getUserLogin());
    }

}
