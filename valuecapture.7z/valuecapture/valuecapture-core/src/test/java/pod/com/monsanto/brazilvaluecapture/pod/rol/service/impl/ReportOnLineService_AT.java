package com.monsanto.brazilvaluecapture.pod.rol.service.impl;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;

import org.apache.commons.lang.time.DateUtils;
import org.hibernate.Criteria;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.junit.Assert;
import org.junit.Ignore;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.monsanto.brazilvaluecapture.core.base.model.bean.City;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Company;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Crop;
import com.monsanto.brazilvaluecapture.core.base.model.bean.OperationalYear;
import com.monsanto.brazilvaluecapture.core.base.model.bean.State;
import com.monsanto.brazilvaluecapture.core.base.service.CompanyService;
import com.monsanto.brazilvaluecapture.core.commercialhierarchy.model.bean.CommercialHierarchyType;
import com.monsanto.brazilvaluecapture.core.commercialhierarchy.model.bean.CustomerDistrict;
import com.monsanto.brazilvaluecapture.core.commercialhierarchy.model.bean.ItsDistrict;
import com.monsanto.brazilvaluecapture.core.commercialhierarchy.model.bean.ItsRegion;
import com.monsanto.brazilvaluecapture.core.commercialhierarchy.model.bean.ItsUnity;
import com.monsanto.brazilvaluecapture.core.commercialhierarchy.service.CommercialHierarchyService;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Contract;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Customer;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.HeadOffice;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.ParticipantTypeEnum;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Technology;
import com.monsanto.brazilvaluecapture.core.customer.service.AffiliateNotInVigorException;
import com.monsanto.brazilvaluecapture.core.customer.service.ContractNotFoundException;
import com.monsanto.brazilvaluecapture.core.customer.service.CustomerNotAllowedException;
import com.monsanto.brazilvaluecapture.core.customer.service.CustomerNotFoundException;
import com.monsanto.brazilvaluecapture.core.foundation.service.BusinessException;
import com.monsanto.brazilvaluecapture.core.foundation.service.EntityAlreadyExistException;
import com.monsanto.brazilvaluecapture.core.foundation.service.EntityNotFoundException;
import com.monsanto.brazilvaluecapture.core.foundation.test.AbstractServiceIntegrationTests;
import com.monsanto.brazilvaluecapture.core.foundation.test.dbunit.DbUnitHelper;
import com.monsanto.brazilvaluecapture.core.foundation.util.CalendarUtil;
import com.monsanto.brazilvaluecapture.core.grower.service.GrowerNotFoundException;
import com.monsanto.brazilvaluecapture.core.revenue.model.bean.RevenueAccount;
import com.monsanto.brazilvaluecapture.core.revenue.model.bean.RevenueHandle;
import com.monsanto.brazilvaluecapture.core.revenue.model.bean.RevenueType;
import com.monsanto.brazilvaluecapture.core.user.model.bean.ItsUser;
import com.monsanto.brazilvaluecapture.core.user.model.bean.UserContract;
import com.monsanto.brazilvaluecapture.core.user.service.UserNotFoundException;
import com.monsanto.brazilvaluecapture.core.user.service.UserService;
import com.monsanto.brazilvaluecapture.pod.rol.model.bean.CounterPrice;
import com.monsanto.brazilvaluecapture.pod.rol.model.bean.HeadOfficeDetail;
import com.monsanto.brazilvaluecapture.pod.rol.model.bean.HeadOfficeEffectiveDate;
import com.monsanto.brazilvaluecapture.pod.rol.model.bean.MissingReportOnlineView;
import com.monsanto.brazilvaluecapture.pod.rol.model.bean.PodCalendar;
import com.monsanto.brazilvaluecapture.pod.rol.model.bean.ReportOnLine;
import com.monsanto.brazilvaluecapture.pod.rol.model.bean.ReportOnlineDTO;
import com.monsanto.brazilvaluecapture.pod.rol.model.bean.ReportOnlinePeriodDTO;
import com.monsanto.brazilvaluecapture.pod.rol.model.bean.RolConfiguration;
import com.monsanto.brazilvaluecapture.pod.rol.model.bean.RolJustification;
import com.monsanto.brazilvaluecapture.pod.rol.model.bean.RolJustificationType;
import com.monsanto.brazilvaluecapture.pod.rol.model.bean.RolLogActionEnum;
import com.monsanto.brazilvaluecapture.pod.rol.model.bean.RolLogDTO;
import com.monsanto.brazilvaluecapture.pod.rol.model.bean.RolLogTypeEnum;
import com.monsanto.brazilvaluecapture.pod.rol.model.bean.RolParameterDTO;
import com.monsanto.brazilvaluecapture.pod.rol.model.bean.RolStatus;
import com.monsanto.brazilvaluecapture.pod.rol.model.bean.TechnologyROL;
import com.monsanto.brazilvaluecapture.pod.rol.model.bean.UsedRolParameter;
import com.monsanto.brazilvaluecapture.pod.rol.model.bean.ValueOfChrgByTon;
import com.monsanto.brazilvaluecapture.pod.rol.model.bean.VolumeOfBag;
import com.monsanto.brazilvaluecapture.pod.rol.model.dao.ReportOnlineDAO;
import com.monsanto.brazilvaluecapture.pod.rol.model.service.CounterPriceFilter;
import com.monsanto.brazilvaluecapture.pod.rol.model.service.PodCalendarException;
import com.monsanto.brazilvaluecapture.pod.rol.model.service.PodCalendarService;
import com.monsanto.brazilvaluecapture.pod.rol.model.service.ReportOnLineByGrowerService;
import com.monsanto.brazilvaluecapture.pod.rol.model.service.ReportOnLineConstraintException;
import com.monsanto.brazilvaluecapture.pod.rol.model.service.ReportOnLineFilter;
import com.monsanto.brazilvaluecapture.pod.rol.model.service.ReportOnLineInfo;
import com.monsanto.brazilvaluecapture.pod.rol.model.service.ReportOnLineNotFoundException;
import com.monsanto.brazilvaluecapture.pod.rol.model.service.ReportOnLineSearchDTO;
import com.monsanto.brazilvaluecapture.pod.rol.model.service.ReportOnLineService;
import com.monsanto.brazilvaluecapture.pod.rol.model.service.ReportOnlineException;
import com.monsanto.brazilvaluecapture.pod.rol.model.service.RolConfigurationService;
import com.monsanto.brazilvaluecapture.pod.rol.model.service.RolInformationService;
import com.monsanto.brazilvaluecapture.pod.rol.model.service.RolParameterException;
import com.monsanto.brazilvaluecapture.pod.rol.model.service.UsedRolParametersSpecification;

/**
 * @author cmiranda
 * 
 */
public class ReportOnLineService_AT extends AbstractServiceIntegrationTests {

    /**
     *
     */
    @Autowired
    private ReportOnLineService reportOnlineService;

    @Autowired
    private ReportOnLineByGrowerService reportOnLineByGrowerService;

    @Autowired
    private RolInformationService rolInformationService;

    @Autowired
    private PodCalendarService podCalendarService;

    @Autowired
    private CompanyService companyService;

    @Autowired
    private UserService userService;

    @Autowired
    private CommercialHierarchyService commercialHierarchyService;

    @Autowired
    private ReportOnlineDAO reportOnlineDAO;

    @Autowired
    private RolConfigurationService rolConfigurationService;

    private ItsUser itsUser;

    private ReportOnLineInfo rolInfo = new ReportOnLineInfo(Locale.US);

    /**
     * Configure database data.
     */
    public void setupDBUnit() {

        // Load rol status
        int rolStatusCount = (Integer) getSession().createCriteria(RolStatus.class)
                .setProjection(Projections.count("id")).uniqueResult();
        if (rolStatusCount == 0) {
            DbUnitHelper.setup("classpath:data/pod/rol/rol-status-dataset.xml");
        }

        // Load dbunit
        DbUnitHelper.setup("classpath:data/core/fixture-system-dataset.xml",
                "classpath:data/core/participant-dataset.xml",
                "classpath:data/commercialhierarchy/commercialhierarchy-dataset.xml",
                "classpath:data/pod/rol/rol-parameters-dataset.xml",
                "classpath:data/pod/rol/report-online-dataset.xml", "classpath:data/pod/rol/counter-price-dataset.xml",
                "classpath:data/pod/rol/rol-configuration-dataset.xml",
                "classpath:data/core/headoffice-detail-dataset.xml");

        // TODO: the code below fix commercial hierarchy on junit database,
        // first uncomment this, dataset's must be fixed.
        /*
         * // Load dbunit
         * DbUnitHelper.setup("classpath:data/core/fixture-system-dataset.xml",
         * "classpath:data/core/participant-dataset.xml");
         * 
         * // Change the hierType to create scenarios with dataset.
         * 
         * @SuppressWarnings("unchecked") List<CommercialHierType> list =
         * getSession().createCriteria(CommercialHierType.class).list();
         * 
         * for (CommercialHierType commercialHierType : list) {
         * commercialHierType.setCommercialHierTypeDesc("MV_" +
         * commercialHierType.getCommercialHierTypeDesc());
         * commercialHierType.setCommercialHierTypeObs("MV_" +
         * commercialHierType.getCommercialHierTypeObs());
         * getSession().save(commercialHierType); }
         * 
         * getSession().flush();
         * 
         * DbUnitHelper.setup(
         * "classpath:data/commercialhierarchy/commercialhierarchytype-dataset.xml"
         * ); DbUnitHelper.setup(
         * "classpath:data/commercialhierarchy/commercialhierarchy-dataset.xml"
         * );
         * DbUnitHelper.setup("classpath:data/pod/rol/rol-parameters-dataset.xml"
         * );
         * DbUnitHelper.setup("classpath:data/pod/rol/report-online-dataset.xml"
         * );
         * DbUnitHelper.setup("classpath:data/pod/rol/counter-price-dataset.xml"
         * );
         * DbUnitHelper.setup("classpath:data/pod/rol/rol-configuration-dataset.xml"
         * );
         * DbUnitHelper.setup("classpath:data/core/headoffice-detail-dataset.xml"
         * );
         */

        // load _root_ itsUser
        itsUser = (ItsUser) getSession().get(ItsUser.class, new Long(900000004));

        // WARNING - This dataset emulate the view, keep this sincronized with
        // data base and others datasets
        if (!getAssumptionTest().isEnvironmentWithSQLANSI()) {
            DbUnitHelper.setup("classpath:data/core/vw-missing-report-online-dataset.xml",
                    "classpath:data/core/vw-report-online-dataset.xml");
        }

    }

    /**
     * Configure database data.
     */
    public void setupDBUnitWithAffiliates() {

        // load rol-status
        int rolStatusCount = getSession().createCriteria(RolStatus.class).list().size();
        if (rolStatusCount == 0) {
            DbUnitHelper.setup("classpath:data/pod/rol/rol-status-dataset.xml");
        }

        // Load dbunit
        DbUnitHelper.setup("classpath:data/core/fixture-system-dataset.xml",
                "classpath:data/core/participant-dataset.xml",
                "classpath:data/commercialhierarchy/commercialhierarchy-dataset.xml",
                "classpath:data/pod/rol/rol-parameters-dataset.xml",
                "classpath:data/pod/rol/report-online-affiliates-dataset.xml",
                "classpath:data/pod/rol/counter-price-dataset.xml");
    }

    /**
     * Configure database data.
     */
    public void setupDBUnitUpdateRol() {
        // Load dbunit
        int rolStatusCount = getSession().createCriteria(RolStatus.class).list().size();
        if (rolStatusCount == 0) {
            DbUnitHelper.setup("classpath:data/pod/rol/rol-status-dataset.xml");
        }
        DbUnitHelper.setup("classpath:data/core/fixture-system-dataset.xml",
                "classpath:data/core/participant-dataset.xml",
                "classpath:data/commercialhierarchy/commercialhierarchy-dataset.xml",
                "classpath:data/pod/rol/rol-parameters-dataset.xml",
                "classpath:data/pod/rol/rol-state-machine-dataset.xml");

        // load _root_ itsUser
        itsUser = (ItsUser) getSession().get(ItsUser.class, new Long(900000004));
    }

    @Test
    public void search_rol_by_id() throws ReportOnLineNotFoundException {
        setupDBUnit();
        ReportOnLine rol = reportOnlineDAO.findById(new Long(900000003));
        Assert.assertTrue("Status must ZZZ.",
                rol.getRolStatus().getRolStatusCode().equals(RolStatus.ROL_STATUS_RELEASED));
    }

    /**
     * @throws BusinessException
     */
    @Test(expected = ReportOnLineNotFoundException.class)
    public void delete_rol_by_id_only_for_consolidate_status() throws BusinessException {

        setupDBUnit();

        ReportOnLine rol = (ReportOnLine) getSession().get(ReportOnLine.class, 900000004L);
        Assert.assertNotNull(rol);
        rol.setRolStatus(findStatusByCode(RolStatus.ROL_STATUS_CORRECTED));
        saveAndFlush(rol);

        reportOnlineService.deleteReportOnline(rol.getId(), false);
        // try to find the rol again
        rol = reportOnlineDAO.findById(new Long(900000004));
        Assert.fail("Deletion was not executed.");
    }

    @Test(expected = ReportOnLineNotFoundException.class)
    public void delete_rol_by_id_only_for_consolidate_status_and_with_justification_associate()
            throws BusinessException {

        setupDBUnit();

        // Find user
        ItsUser user = (ItsUser) getSession().get(ItsUser.class, 900000001L);
        Assert.assertNotNull(user);

        // Find rol
        ReportOnLine rol = (ReportOnLine) getSession().get(ReportOnLine.class, 900000004L);
        Assert.assertNotNull(rol);
        rol.setRolStatus(findStatusByCode(RolStatus.ROL_STATUS_CORRECTED));

        // Build justifications
        RolJustification j1 = new RolJustification();
        j1.setItsUserLogin(user.getLogin());
        j1.setReportOnLine(rol);
        j1.setRolJustificationDate(new Date());
        j1.setRolJustificationMessage("ah!");
        j1.setRolJustificationType(RolJustificationType.APPROVAL.name());
        rol.getJustifications().add(j1);

        j1 = new RolJustification();
        j1.setItsUserLogin(user.getLogin());
        j1.setReportOnLine(rol);
        j1.setRolJustificationDate(new Date());
        j1.setRolJustificationMessage("bleh!");
        j1.setRolJustificationType(RolJustificationType.DISAPPROVED.name());
        rol.getJustifications().add(j1);

        saveAndFlush(rol);

        reportOnlineService.deleteReportOnline(rol.getId(), false);
        // try to find the rol again
        rol = reportOnlineDAO.findById(new Long(900000004));
        Assert.fail("Deletion was not executed.");
    }

    @Test(expected = ReportOnlineException.class)
    public void delete_rol_by_id_only_for_not_consolidate_status() throws ReportOnLineNotFoundException,
            ReportOnlineException {
        setupDBUnit();
        // rolstatus ZZZ
        ReportOnLine rol = reportOnlineDAO.findById(new Long(900000003));
        reportOnlineService.deleteReportOnline(rol.getId(), false);

        Assert.fail("Deletion was executed which could not occur.");
    }

    @Test(expected = ReportOnlineException.class)
    public void delete_rol_for_participant_with_today_after_limit_date() throws ReportOnLineNotFoundException,
            ReportOnlineException, PodCalendarException {
        setupDBUnit();
        // Oper. year 2012
        OperationalYear operYear = (OperationalYear) getSession().get(OperationalYear.class, new Long(900000003));
        // _SOJA_ && company _MONSANTO DO BRASIL LTDA._
        Crop crop = (Crop) getSession().get(Crop.class, new Long(900000001));
        ReportOnLine rol = reportOnlineDAO.findById(new Long(900000004));
        rol.setOperationalYear(operYear);
        rol.setCrop(crop);
        rol.setRolStatus(findStatusByCode(RolStatus.ROL_STATUS_CORRECTED));

        saveAndFlush(rol);

        // set a limit date in the past
        List<PodCalendar> calendarList = podCalendarService.selectPodCalendarList(operYear, crop.getCompany(), crop);
        setLimitDateInThePast(rolMonth(rol), calendarList);
        podCalendarService.savePodCalendar(calendarList);

        reportOnlineService.deleteReportOnline(rol.getId(), true); // participant

        Assert.fail("Deletion was executed which could not occur.");
    }

    @Test
    public void check_limit_date_rule_for_participant() throws PodCalendarException, ReportOnLineNotFoundException {
        setupDBUnit();
        // Oper. year 2012
        OperationalYear operYear = (OperationalYear) getSession().get(OperationalYear.class, new Long(900000003));
        // _SOJA_ && company _MONSANTO DO BRASIL LTDA._
        Crop crop = (Crop) getSession().get(Crop.class, new Long(900000001));
        ReportOnLine rol = reportOnlineDAO.findById(new Long(900000004));
        rol.setOperationalYear(operYear);
        rol.setCrop(crop);
        rol.setRolStatus(findStatusByCode(RolStatus.ROL_STATUS_CORRECTED));

        saveAndFlush(rol);

        // set a limit date in the past
        List<PodCalendar> calendarList = podCalendarService.selectPodCalendarList(operYear, crop.getCompany(), crop);
        setLimitDateInThePast(rolMonth(rol), calendarList);
        podCalendarService.savePodCalendar(calendarList);

        boolean flag = rolInformationService.checkLimitDateForReportOnlineWithPodCalendar(rol);
        Assert.assertFalse(flag);

        // set a limit date in the future
        calendarList = podCalendarService.selectPodCalendarList(operYear, crop.getCompany(), crop);
        setLimitDateInTheFuture(rolMonth(rol), calendarList);
        podCalendarService.savePodCalendar(calendarList);

        flag = rolInformationService.checkLimitDateForReportOnlineWithPodCalendar(rol);
        Assert.assertTrue(flag);

    }

    @Test
    public void select_all_allowed_row_status_superadmin_in_rtv_status() throws ReportOnLineNotFoundException {
        setupDBUnit();
        // Take a ROL with RTV status
        ReportOnLine rol = reportOnlineDAO.findById(new Long(900000004));
        rol.setRolStatus(findStatusByCode(RolStatus.ROL_STATUS_RTV));
        saveAndFlush(rol);
        // select all allowed status
        List<RolStatus> statusList = rolInformationService.selectAllAllowedRolStatusList(rol.getId(), false); // super
                                                                                                              // or
                                                                                                              // admin
        // only RTV and CORRECTED status should be returned.
        Assert.assertEquals(2, statusList.size());

        for (RolStatus item : statusList) {
            boolean rtvOrCorrected = item.getRolStatusCode().equals(RolStatus.ROL_STATUS_CORRECTED)
                    || item.getRolStatusCode().equals(RolStatus.ROL_STATUS_RTV);
            Assert.assertTrue("only RTV and CORRECTED status must be returned.", rtvOrCorrected);
        }

    }

    @Test
    public void select_all_allowed_row_status_superadmin_in_corrected_status() throws ReportOnLineNotFoundException {

        // load db unit
        setupDBUnit();

        // Take a ROL with RTV status
        ReportOnLine rol = reportOnlineDAO.findById(new Long(900000004));
        rol.setRolStatus(findStatusByCode(RolStatus.ROL_STATUS_CORRECTED));
        saveAndFlush(rol);

        // select all allowed status
        List<RolStatus> statusList = rolInformationService.selectAllAllowedRolStatusList(rol.getId(), false);

        // only RTV and CORRECTED status should be returned.
        Assert.assertEquals(1, statusList.size());

        for (RolStatus item : statusList) {
            Assert.assertEquals("Only CORRECTED status must be returned.", RolStatus.ROL_STATUS_CORRECTED,
                    item.getRolStatusCode());
        }

    }

    @Test
    public void select_all_allowed_row_status_with_rol_id_null() throws ReportOnLineNotFoundException {

        setupDBUnit();

        // select all allowed status
        List<RolStatus> statusList = rolInformationService.selectAllAllowedRolStatusList(null, false); // super
                                                                                                       // or
                                                                                                       // admin
        // only Report ROL status should be returned.
        Assert.assertEquals(1, statusList.size());

        for (RolStatus item : statusList) {
            Assert.assertEquals("Only reported status must be returned.", RolStatus.ROL_STATUS_REPORTED,
                    item.getRolStatusCode());
        }

    }

    @Test
    public void select_all_allowed_row_status_participant_in_rtvstatus_today_before_limitdate()
            throws ReportOnLineNotFoundException, PodCalendarException {
        setupDBUnit();
        // Oper. year 2012
        OperationalYear operYear = (OperationalYear) getSession().get(OperationalYear.class, new Long(900000003));
        // _SOJA_ && company _MONSANTO DO BRASIL LTDA._
        Crop crop = (Crop) getSession().get(Crop.class, new Long(900000001));

        // Take a ROL with RTV status
        ReportOnLine rol = reportOnlineDAO.findById(new Long(900000004));
        rol.setOperationalYear(operYear);
        rol.setCrop(crop);
        rol.setRolStatus(findStatusByCode(RolStatus.ROL_STATUS_RTV));
        saveAndFlush(rol);
        // set for PodCalendar in month a limit date after today
        List<PodCalendar> calendarList = podCalendarService.selectPodCalendarList(operYear, crop.getCompany(), crop);
        setLimitDateInTheFuture(rolMonth(rol), calendarList);
        podCalendarService.savePodCalendar(calendarList);

        // select all allowed status
        List<RolStatus> statusList = rolInformationService.selectAllAllowedRolStatusList(rol.getId(), true); // participant
        // only RTV and CORRECTED status should be returned.
        Assert.assertEquals(2, statusList.size());

        for (RolStatus item : statusList) {
            boolean rtvOrCorrected = item.getRolStatusCode().equals(RolStatus.ROL_STATUS_CORRECTED)
                    || item.getRolStatusCode().equals(RolStatus.ROL_STATUS_RTV);
            Assert.assertTrue("only RTV and CORRECTED status must be returned.", rtvOrCorrected);
        }

    }

    /**
     * @throws ReportOnLineNotFoundException
     * @throws PodCalendarException
     */
    @Test
    public void select_all_allowed_row_status_for_super_with_rol_in_processed_state()
            throws ReportOnLineNotFoundException, PodCalendarException {
        setupDBUnit();
        // Oper. year 2012
        OperationalYear operYear = (OperationalYear) getSession().get(OperationalYear.class, new Long(900000003));
        // _SOJA_ && company _MONSANTO DO BRASIL LTDA._
        Crop crop = (Crop) getSession().get(Crop.class, new Long(900000001));

        // Take a ROL with RTV status
        ReportOnLine rol = reportOnlineDAO.findById(new Long(900000004));
        rol.setOperationalYear(operYear);
        rol.setCrop(crop);
        rol.setRolStatus(findStatusByCode(RolStatus.ROL_STATUS_PROCESSED));
        saveAndFlush(rol);

        // set for PodCalendar in month a limit date after today
        List<PodCalendar> calendarList = podCalendarService.selectPodCalendarList(operYear, crop.getCompany(), crop);
        setLimitDateInTheFuture(rolMonth(rol), calendarList);
        podCalendarService.savePodCalendar(calendarList);

        // select all allowed status
        List<RolStatus> statusList = rolInformationService.selectAllAllowedRolStatusList(rol.getId(), false); // participant

        // Check for all states
        Assert.assertTrue(!statusList.isEmpty());

    }

    @Test
    public void select_all_allowed_row_status_participant_in_rtvstatus_today_after_limitdate()
            throws ReportOnLineNotFoundException, PodCalendarException {
        setupDBUnit();
        // Oper. year 2012
        OperationalYear operYear = (OperationalYear) getSession().get(OperationalYear.class, new Long(900000003));
        // _SOJA_ && company _MONSANTO DO BRASIL LTDA._
        Crop crop = (Crop) getSession().get(Crop.class, new Long(900000001));

        // Take a ROL with RTV status
        ReportOnLine rol = reportOnlineDAO.findById(new Long(900000004));
        rol.setCrop(crop);
        rol.setRolStatus(findStatusByCode(RolStatus.ROL_STATUS_RTV));
        rol.setOperationalYear(operYear);
        saveAndFlush(rol);

        // set for PodCalendar in month a limit date BEFORE today
        List<PodCalendar> calendarList = podCalendarService.selectPodCalendarList(operYear, crop.getCompany(), crop);
        setLimitDateInThePast(rolMonth(rol), calendarList);
        podCalendarService.savePodCalendar(calendarList);

        // select all allowed status
        List<RolStatus> statusList = rolInformationService.selectAllAllowedRolStatusList(rol.getId(), true); // participant
        // only RTV should be returned.
        Assert.assertEquals(1, statusList.size());

        for (RolStatus item : statusList) {
            boolean rtv = item.getRolStatusCode().equals(RolStatus.ROL_STATUS_RTV);
            Assert.assertTrue("only RTV status must be returned.", rtv);
        }

    }

    private int rolMonth(final ReportOnLine rol) {
        return CalendarUtil.getDateMonth(rol.getRolPeriod()) + 1;
    }

    private void setLimitDateInThePast(final int month, final List<PodCalendar> calendarList) {
        for (PodCalendar podCalendar : calendarList) {
            if (podCalendar.getMonth() == month) {
                podCalendar.setLimitDate(DateUtils.addDays(new Date(), -1));
            }
        }
    }

    private void setLimitDateInTheFuture(final int month, final List<PodCalendar> calendarList) {
        for (PodCalendar podCalendar : calendarList) {
            if (podCalendar.getMonth() == month) {
                podCalendar.setLimitDate(DateUtils.addDays(new Date(), 1));
            }
        }
    }

    @Test
    public void search_rol_list_by_headofficelist_crop_operational_year() throws RolParameterException,
            GrowerNotFoundException, UserNotFoundException, CustomerNotFoundException, CustomerNotAllowedException {

        setupDBUnit();

        Crop crop = (Crop) getSession().get(Crop.class, new Long(900000001));// _SOJA_
        OperationalYear operYear = (OperationalYear) getSession().get(OperationalYear.class, new Long(900000007));// 2012
        // build list of headoffices
        HeadOffice ho1 = (HeadOffice) getSession().get(HeadOffice.class, new Long(900000001));
        HeadOffice ho2 = (HeadOffice) getSession().get(HeadOffice.class, new Long(900000002));
        HeadOffice ho3 = (HeadOffice) getSession().get(HeadOffice.class, new Long(900000003));
        List<HeadOffice> hoList = new ArrayList<HeadOffice>();
        hoList.add(ho1);
        hoList.add(ho2);
        hoList.add(ho3);

        ReportOnLineFilter filter = new ReportOnLineFilter();
        filter.setCrop(crop);
        filter.setOperationalYear(operYear);
        filter.setHeadOfficeList(hoList);
        filter.setRolPeriod(getRolPeriod(2012, 7, 1));// consider only ROL
                                                      // on July
        // search for Rol list
        List<ReportOnLine> rolList = reportOnlineService.selectReportOnLineListByFilter(filter);

        Assert.assertEquals("Only two items must be returned.", 2, rolList.size());

        for (ReportOnLine item : rolList) {
            Assert.assertTrue("ROL must have one of the following ids: 900000001,900000002",
                    item.getId().longValue() == 900000001 || item.getId().longValue() == 900000002);
        }

    }

    /**
     * @throws BusinessException
     */
    @Test
    public void search_rol_list_by_customer_matrix_crop_operational_year() throws BusinessException {

        // Load database
        setupDBUnit();

        // Load operational year
        OperationalYear operYear = (OperationalYear) getSession().get(OperationalYear.class, new Long(900000007));

        // Load head office
        HeadOffice headOffice = (HeadOffice) getSession().get(HeadOffice.class, new Long(900000001));

        // Build filter
        ReportOnLineFilter filter = new ReportOnLineFilter();
        filter.setCompany(headOffice.getCompany());
        filter.setCrop(headOffice.getCrop());
        filter.setOperationalYear(operYear);
        filter.setMatrix(headOffice.getMatrix());
        filter.setCustomer(headOffice.getCustomer());

        // Set period
        filter.setInitDate(getRolPeriod(2012, 7, 1));
        filter.setEndDate(getRolPeriod(2012, 12, 31));

        // search for Rol list
        List<ReportOnLine> rolList = reportOnlineService.selectReportOnLineListByFilter(filter);

        // Check result size
        Assert.assertTrue("Expected at least 1 reports. But found " + rolList.size(), rolList.size() >= 1);

        // Check result
        for (ReportOnLine item : rolList) {
            Assert.assertEquals(headOffice.getCompany(), item.getHeadoffice().getCompany());
            Assert.assertEquals(headOffice.getCrop(), item.getCrop());
            Assert.assertEquals(operYear, item.getOperationalYear());
            Assert.assertEquals(headOffice.getMatrix(), item.getHeadoffice().getMatrix());
            Assert.assertEquals(headOffice.getCustomer(), item.getHeadoffice().getCustomer());
            Assert.assertTrue(
                    "Expected reports between filter period.",
                    CalendarUtil.compareToPeriod(item.getRolPeriod(), filter.getInitDate()) >= 0
                            && CalendarUtil.compareToPeriod(item.getRolPeriod(), filter.getEndDate()) <= 0);

        }

    }

    /**
     * @throws BusinessException
     */
    @Test
    public void search_rol_list_by_customer_matrix_crop_operational_year_rol_status() throws BusinessException {

        // Load database
        setupDBUnit();

        // Load operational year
        OperationalYear operYear = (OperationalYear) getSession().get(OperationalYear.class, new Long(900000007));

        // Load head office
        HeadOffice headOffice = (HeadOffice) getSession().get(HeadOffice.class, new Long(900000001));

        // Build filter
        ReportOnLineFilter filter = new ReportOnLineFilter();
        filter.setCompany(headOffice.getCompany());
        filter.setCrop(headOffice.getCrop());
        filter.setOperationalYear(operYear);
        filter.setMatrix(headOffice.getMatrix());
        filter.setCustomer(headOffice.getCustomer());

        // Set status
        filter.setRolStatus(rolInformationService.selectRolStatusByCode(RolStatus.ROL_STATUS_RTV));

        // Set period
        filter.setInitDate(getRolPeriod(2012, 7, 1));
        filter.setEndDate(getRolPeriod(2012, 12, 31));

        // search for Rol list
        List<ReportOnLine> rolList = reportOnlineService.selectReportOnLineListByFilter(filter);

        // Check result size
        Assert.assertTrue("Expected at least 1 reports. But found " + rolList.size(), rolList.size() >= 1);

        // Check result
        for (ReportOnLine item : rolList) {
            Assert.assertEquals(headOffice.getCompany(), item.getHeadoffice().getCompany());
            Assert.assertEquals(headOffice.getCrop(), item.getCrop());
            Assert.assertEquals(operYear, item.getOperationalYear());
            Assert.assertEquals(headOffice.getMatrix(), item.getHeadoffice().getMatrix());
            Assert.assertEquals(headOffice.getCustomer(), item.getHeadoffice().getCustomer());
            Assert.assertEquals(filter.getRolStatus(), item.getRolStatus());
            Assert.assertTrue(
                    "Expected reports between filter period.",
                    CalendarUtil.compareToPeriod(item.getRolPeriod(), filter.getInitDate()) >= 0
                            && CalendarUtil.compareToPeriod(item.getRolPeriod(), filter.getEndDate()) <= 0);

        }

    }

    /**
     * @throws BusinessException
     */
    @Test
    public void search_rol_list_by_customer_matrix_unity_matrix_crop_operational_year_rol_status()
            throws BusinessException {

        // Load database
        setupDBUnit();

        // Load operational year
        OperationalYear operYear = (OperationalYear) getSession().get(OperationalYear.class, new Long(900000007));
        Assert.assertNotNull(operYear);

        // Load head office
        HeadOffice headOffice = (HeadOffice) getSession().get(HeadOffice.class, new Long(900000001));
        Assert.assertNotNull(headOffice);

        // Build filter
        ReportOnLineFilter filter = new ReportOnLineFilter();
        filter.setCompany(headOffice.getCompany());
        filter.setCrop(headOffice.getCrop());
        filter.setOperationalYear(operYear);
        filter.setMatrix(headOffice.getMatrix());
        filter.setCustomer(headOffice.getCustomer());

        // Set status
        filter.setRolStatus(rolInformationService.selectRolStatusByCode(RolStatus.ROL_STATUS_RTV));
        Assert.assertNotNull(filter.getRolStatus());

        // Set unity
        ItsUnity unity = (ItsUnity) getSession().get(ItsUnity.class, 900000000L);
        Assert.assertNotNull(unity);
        filter.setUnity(unity);

        // Set period
        filter.setInitDate(getRolPeriod(2012, 7, 1));
        filter.setEndDate(getRolPeriod(2012, 12, 31));

        // search for Rol list
        List<ReportOnLine> rolList = reportOnlineService.selectReportOnLineListByFilter(filter);

        // Check result size
        Assert.assertTrue("Expected at least 1 reports. But found " + rolList.size(), rolList.size() >= 1);

        // Check result
        for (ReportOnLine item : rolList) {
            Assert.assertEquals(headOffice.getCompany(), item.getHeadoffice().getCompany());
            Assert.assertEquals(headOffice.getCrop(), item.getCrop());
            Assert.assertEquals(operYear, item.getOperationalYear());
            Assert.assertEquals(headOffice.getMatrix(), item.getHeadoffice().getMatrix());
            Assert.assertEquals(headOffice.getCustomer(), item.getHeadoffice().getCustomer());
            Assert.assertEquals(filter.getRolStatus(), item.getRolStatus());
            Assert.assertTrue(
                    "Expected reports between filter period.",
                    CalendarUtil.compareToPeriod(item.getRolPeriod(), filter.getInitDate()) >= 0
                            && CalendarUtil.compareToPeriod(item.getRolPeriod(), filter.getEndDate()) <= 0);
            Assert.assertTrue("Matrix must have commercial hierarchy of POD.",
                    checkCommercialHierarchyType(item.getHeadoffice().getMatrix(), CommercialHierarchyType.POD));
            Assert.assertTrue("Matrix must have unity " + filter.getUnity() + " for POD commercial hierarchy.",
                    checkUnity(item.getHeadoffice().getMatrix(), filter.getUnity()));
        }

    }

    /**
     * @throws BusinessException
     */
    @Test
    public void search_rol_list_by_customer_matrix_unity_affiliate_crop_operational_year_rol_status()
            throws BusinessException {

        // Load database
        setupDBUnit();

        // Load operational year
        OperationalYear operYear = (OperationalYear) getSession().get(OperationalYear.class, new Long(900000007));
        Assert.assertNotNull(operYear);

        // Load head office
        HeadOffice headOffice = (HeadOffice) getSession().get(HeadOffice.class, new Long(900000001));
        Assert.assertNotNull(headOffice);

        // Build filter
        ReportOnLineFilter filter = new ReportOnLineFilter();
        filter.setCompany(headOffice.getCompany());
        filter.setCrop(headOffice.getCrop());
        filter.setOperationalYear(operYear);
        filter.setMatrix(headOffice.getMatrix());
        filter.setCustomer(headOffice.getCustomer());

        // Set status
        filter.setRolStatus(rolInformationService.selectRolStatusByCode(RolStatus.ROL_STATUS_RTV));
        Assert.assertNotNull(filter.getRolStatus());

        // Set unity
        ItsUnity unity = (ItsUnity) getSession().get(ItsUnity.class, 900000000L);
        Assert.assertNotNull(unity);
        filter.setCustomerUnity(unity);

        // Set period
        filter.setInitDate(getRolPeriod(2012, 7, 1));
        filter.setEndDate(getRolPeriod(2012, 12, 31));

        // search for Rol list
        List<ReportOnLine> rolList = reportOnlineService.selectReportOnLineListByFilter(filter);

        // Check result size
        Assert.assertTrue("Expected at least 1 reports. But found " + rolList.size(), rolList.size() >= 1);

        // Check result
        for (ReportOnLine item : rolList) {
            Assert.assertEquals(headOffice.getCompany(), item.getHeadoffice().getCompany());
            Assert.assertEquals(headOffice.getCrop(), item.getCrop());
            Assert.assertEquals(operYear, item.getOperationalYear());
            Assert.assertEquals(headOffice.getMatrix(), item.getHeadoffice().getMatrix());
            Assert.assertEquals(headOffice.getCustomer(), item.getHeadoffice().getCustomer());
            Assert.assertEquals(filter.getRolStatus(), item.getRolStatus());
            Assert.assertTrue(
                    "Expected reports between filter period.",
                    CalendarUtil.compareToPeriod(item.getRolPeriod(), filter.getInitDate()) >= 0
                            && CalendarUtil.compareToPeriod(item.getRolPeriod(), filter.getEndDate()) <= 0);
            Assert.assertTrue("Matrix must have commercial hierarchy of POD.",
                    checkCommercialHierarchyType(item.getHeadoffice().getMatrix(), CommercialHierarchyType.POD));
            Assert.assertTrue("Affiliate must have unity " + filter.getCustomerUnity()
                    + " for POD commercial hierarchy.",
                    checkUnity(item.getHeadoffice().getCustomer(), filter.getCustomerUnity()));
        }

    }

    /**
     * @throws BusinessException
     */
    @Test
    public void search_rol_list_by_customer_matrix_invalid_unity_matrix_crop_operational_year_rol_status_expected_empty_list()
            throws BusinessException {

        // Load database
        setupDBUnit();

        // Load operational year
        OperationalYear operYear = (OperationalYear) getSession().get(OperationalYear.class, new Long(900000007));
        Assert.assertNotNull(operYear);

        // Load head office
        HeadOffice headOffice = (HeadOffice) getSession().get(HeadOffice.class, new Long(900000001));
        Assert.assertNotNull(headOffice);

        // Build filter
        ReportOnLineFilter filter = new ReportOnLineFilter();
        filter.setCompany(headOffice.getCompany());
        filter.setCrop(headOffice.getCrop());
        filter.setOperationalYear(operYear);
        filter.setMatrix(headOffice.getMatrix());
        filter.setCustomer(headOffice.getCustomer());

        // Set status
        filter.setRolStatus(rolInformationService.selectRolStatusByCode(RolStatus.ROL_STATUS_RTV));
        Assert.assertNotNull(filter.getRolStatus());

        // Set unity invalid unity
        ItsUnity unity = (ItsUnity) getSession().get(ItsUnity.class, 900000005L);
        Assert.assertNotNull(unity);
        filter.setUnity(unity);

        // Set period
        filter.setInitDate(getRolPeriod(2012, 7, 1));
        filter.setEndDate(getRolPeriod(2012, 12, 31));

        // search for Rol list
        List<ReportOnLine> rolList = reportOnlineService.selectReportOnLineListByFilter(filter);

        // Check result size
        Assert.assertTrue("Expected a empty list. But found " + rolList.size(), rolList.isEmpty());
    }

    /**
     * @throws BusinessException
     */
    @Test
    public void search_rol_list_by_customer_matrix_district_matrix_crop_operational_year_rol_status()
            throws BusinessException {

        // Load database
        setupDBUnit();

        // Load operational year
        OperationalYear operYear = (OperationalYear) getSession().get(OperationalYear.class, new Long(900000007));
        Assert.assertNotNull(operYear);

        // Load head office
        HeadOffice headOffice = (HeadOffice) getSession().get(HeadOffice.class, new Long(900000001));
        Assert.assertNotNull(headOffice);

        // Build filter
        ReportOnLineFilter filter = new ReportOnLineFilter();
        filter.setCompany(headOffice.getCompany());
        filter.setCrop(headOffice.getCrop());
        filter.setOperationalYear(operYear);
        filter.setMatrix(headOffice.getMatrix());
        filter.setCustomer(headOffice.getCustomer());

        // Set status
        filter.setRolStatus(rolInformationService.selectRolStatusByCode(RolStatus.ROL_STATUS_RTV));
        Assert.assertNotNull(filter.getRolStatus());

        // Set district
        ItsDistrict district = (ItsDistrict) getSession().get(ItsDistrict.class, 900000000L);
        Assert.assertNotNull(district);
        filter.setDistrict(district);

        // Set period
        filter.setInitDate(getRolPeriod(2012, 7, 1));
        filter.setEndDate(getRolPeriod(2012, 12, 31));

        // search for Rol list
        List<ReportOnLine> rolList = reportOnlineService.selectReportOnLineListByFilter(filter);

        // Check result size
        Assert.assertTrue("Expected at least 1 reports. But found " + rolList.size(), rolList.size() >= 1);

        // Check result
        for (ReportOnLine item : rolList) {
            Assert.assertEquals(headOffice.getCompany(), item.getHeadoffice().getCompany());
            Assert.assertEquals(headOffice.getCrop(), item.getCrop());
            Assert.assertEquals(operYear, item.getOperationalYear());
            Assert.assertEquals(headOffice.getMatrix(), item.getHeadoffice().getMatrix());
            Assert.assertEquals(headOffice.getCustomer(), item.getHeadoffice().getCustomer());
            Assert.assertEquals(filter.getRolStatus(), item.getRolStatus());
            Assert.assertTrue(
                    "Expected reports between filter period.",
                    CalendarUtil.compareToPeriod(item.getRolPeriod(), filter.getInitDate()) >= 0
                            && CalendarUtil.compareToPeriod(item.getRolPeriod(), filter.getEndDate()) <= 0);
            Assert.assertTrue("Matrix must have commercial hierarchy of POD.",
                    checkCommercialHierarchyType(item.getHeadoffice().getMatrix(), CommercialHierarchyType.POD));
            Assert.assertTrue("Matrix must have district " + filter.getDistrict() + " for POD commercial hierarchy.",
                    checkDistrict(item.getHeadoffice().getMatrix(), filter.getDistrict()));
        }

    }

    /**
     * @throws BusinessException
     */
    @Test
    public void search_rol_list_by_customer_matrix_unity_district_region_matrix_crop_operational_year_rol_status()
            throws BusinessException {

        // Load database
        setupDBUnit();

        // Load operational year
        OperationalYear operYear = (OperationalYear) getSession().get(OperationalYear.class, new Long(900000007));
        Assert.assertNotNull(operYear);

        // Load head office
        HeadOffice headOffice = (HeadOffice) getSession().get(HeadOffice.class, new Long(900000001));
        Assert.assertNotNull(headOffice);

        // Build filter
        ReportOnLineFilter filter = new ReportOnLineFilter();
        filter.setCompany(headOffice.getCompany());
        filter.setCrop(headOffice.getCrop());
        filter.setOperationalYear(operYear);
        filter.setMatrix(headOffice.getMatrix());
        filter.setCustomer(headOffice.getCustomer());

        // Set status
        filter.setRolStatus(rolInformationService.selectRolStatusByCode(RolStatus.ROL_STATUS_RTV));
        Assert.assertNotNull(filter.getRolStatus());

        // Set district
        ItsDistrict district = (ItsDistrict) getSession().get(ItsDistrict.class, 900000000L);
        Assert.assertNotNull(district);
        filter.setDistrict(district);

        // Set unity
        ItsUnity unity = (ItsUnity) getSession().get(ItsUnity.class, 900000000L);
        Assert.assertNotNull(unity);
        filter.setUnity(unity);

        // Set region
        ItsRegion region = (ItsRegion) getSession().get(ItsRegion.class, 900000000L);
        Assert.assertNotNull(region);
        filter.setRegion(region);

        // Set period
        filter.setInitDate(getRolPeriod(2012, 7, 1));
        filter.setEndDate(getRolPeriod(2012, 12, 31));

        // search for Rol list
        List<ReportOnLine> rolList = reportOnlineService.selectReportOnLineListByFilter(filter);

        // Check result size
        Assert.assertTrue("Expected at least 1 reports. But found " + rolList.size(), rolList.size() >= 1);

        // Check result
        for (ReportOnLine item : rolList) {
            Assert.assertEquals(headOffice.getCompany(), item.getHeadoffice().getCompany());
            Assert.assertEquals(headOffice.getCrop(), item.getCrop());
            Assert.assertEquals(operYear, item.getOperationalYear());
            Assert.assertEquals(headOffice.getMatrix(), item.getHeadoffice().getMatrix());
            Assert.assertEquals(headOffice.getCustomer(), item.getHeadoffice().getCustomer());
            Assert.assertEquals(filter.getRolStatus(), item.getRolStatus());
            Assert.assertTrue(
                    "Expected reports between filter period.",
                    CalendarUtil.compareToPeriod(item.getRolPeriod(), filter.getInitDate()) >= 0
                            && CalendarUtil.compareToPeriod(item.getRolPeriod(), filter.getEndDate()) <= 0);
            Assert.assertTrue("Matrix must have commercial hierarchy of POD.",
                    checkCommercialHierarchyType(item.getHeadoffice().getMatrix(), CommercialHierarchyType.POD));
            Assert.assertTrue("Matrix must have unity " + filter.getUnity() + " for POD commercial hierarchy.",
                    checkUnity(item.getHeadoffice().getMatrix(), filter.getUnity()));

            Assert.assertTrue("Matrix must have district " + filter.getDistrict() + " for POD commercial hierarchy.",
                    checkDistrict(item.getHeadoffice().getMatrix(), filter.getDistrict()));

            Assert.assertTrue("Matrix must have region " + filter.getRegion() + " for POD commercial hierarchy.",
                    checkRegion(item.getHeadoffice().getMatrix(), filter.getRegion()));
        }

    }

    /**
     * @throws BusinessException
     */
    @Test
    public void search_rol_list_by_customer_matrix_unity_district_region_affiliate_crop_operational_year_rol_status()
            throws BusinessException {

        // Load database
        setupDBUnit();

        // Load operational year
        OperationalYear operYear = (OperationalYear) getSession().get(OperationalYear.class, new Long(900000007));
        Assert.assertNotNull(operYear);

        // Load head office
        HeadOffice headOffice = (HeadOffice) getSession().get(HeadOffice.class, new Long(900000001));
        Assert.assertNotNull(headOffice);

        // Build filter
        ReportOnLineFilter filter = new ReportOnLineFilter();
        filter.setCompany(headOffice.getCompany());
        filter.setCrop(headOffice.getCrop());
        filter.setOperationalYear(operYear);
        filter.setMatrix(headOffice.getMatrix());
        filter.setCustomer(headOffice.getCustomer());

        // Set status
        filter.setRolStatus(rolInformationService.selectRolStatusByCode(RolStatus.ROL_STATUS_RTV));
        Assert.assertNotNull(filter.getRolStatus());

        // Set district
        ItsDistrict district = (ItsDistrict) getSession().get(ItsDistrict.class, 900000000L);
        Assert.assertNotNull(district);
        filter.setCustomerDistrict(district);

        // Set unity
        ItsUnity unity = (ItsUnity) getSession().get(ItsUnity.class, 900000000L);
        Assert.assertNotNull(unity);
        filter.setCustomerUnity(unity);

        // Set region
        ItsRegion region = (ItsRegion) getSession().get(ItsRegion.class, 900000000L);
        Assert.assertNotNull(region);
        filter.setCustomerRegion(region);

        // Set period
        filter.setInitDate(getRolPeriod(2012, 7, 1));
        filter.setEndDate(getRolPeriod(2012, 12, 31));

        // search for Rol list
        List<ReportOnLine> rolList = reportOnlineService.selectReportOnLineListByFilter(filter);

        // Check result size
        Assert.assertTrue("Expected at least 1 reports. But found " + rolList.size(), rolList.size() >= 1);

        // Check result
        for (ReportOnLine item : rolList) {
            Assert.assertEquals(headOffice.getCompany(), item.getHeadoffice().getCompany());
            Assert.assertEquals(headOffice.getCrop(), item.getCrop());
            Assert.assertEquals(operYear, item.getOperationalYear());
            Assert.assertEquals(headOffice.getMatrix(), item.getHeadoffice().getMatrix());
            Assert.assertEquals(headOffice.getCustomer(), item.getHeadoffice().getCustomer());
            Assert.assertEquals(filter.getRolStatus(), item.getRolStatus());
            Assert.assertTrue(
                    "Expected reports between filter period.",
                    CalendarUtil.compareToPeriod(item.getRolPeriod(), filter.getInitDate()) >= 0
                            && CalendarUtil.compareToPeriod(item.getRolPeriod(), filter.getEndDate()) <= 0);
            Assert.assertTrue("Matrix must have commercial hierarchy of POD.",
                    checkCommercialHierarchyType(item.getHeadoffice().getMatrix(), CommercialHierarchyType.POD));
            Assert.assertTrue("Affiliate must have unity " + filter.getCustomerUnity()
                    + " for POD commercial hierarchy.",
                    checkUnity(item.getHeadoffice().getCustomer(), filter.getCustomerUnity()));

            Assert.assertTrue("Affiliate must have district " + filter.getCustomerDistrict()
                    + " for POD commercial hierarchy.",
                    checkDistrict(item.getHeadoffice().getCustomer(), filter.getCustomerDistrict()));

            Assert.assertTrue("Affiliate must have region " + filter.getCustomerRegion()
                    + " for POD commercial hierarchy.",
                    checkRegion(item.getHeadoffice().getCustomer(), filter.getCustomerRegion()));
        }

    }

    /**
     * @throws BusinessException
     */
    @Test
    public void search_rol_list_by_crop_company_period_matrix_state_rol_status() throws BusinessException {

        // Load database
        setupDBUnit();

        // Load head office
        HeadOffice headOffice = (HeadOffice) getSession().get(HeadOffice.class, new Long(900000001));
        Assert.assertNotNull(headOffice);

        // Build filter
        ReportOnLineFilter filter = new ReportOnLineFilter();
        filter.setCompany(headOffice.getCompany());
        filter.setCrop(headOffice.getCrop());

        // Set status
        filter.setRolStatus(rolInformationService.selectRolStatusByCode(RolStatus.ROL_STATUS_RTV));
        Assert.assertNotNull(filter.getRolStatus());

        // Set state
        filter.setState(headOffice.getMatrix().getAddress().getState());

        // Set period
        filter.setInitDate(getRolPeriod(2012, 7, 1));
        filter.setEndDate(getRolPeriod(2012, 12, 31));

        // search for Rol list
        List<ReportOnLine> rolList = reportOnlineService.selectReportOnLineListByFilter(filter);

        // Check result size
        Assert.assertTrue("Expected at least 1 reports. But found " + rolList.size(), rolList.size() >= 1);

        // Check result
        for (ReportOnLine item : rolList) {
            Assert.assertEquals(headOffice.getCompany(), item.getHeadoffice().getCompany());
            Assert.assertEquals(headOffice.getCrop(), item.getCrop());
            Assert.assertEquals(filter.getRolStatus(), item.getRolStatus());
            Assert.assertEquals(filter.getState(), item.getHeadoffice().getMatrix().getAddress().getState());
            Assert.assertTrue(
                    "Expected reports between filter period.",
                    CalendarUtil.compareToPeriod(item.getRolPeriod(), filter.getInitDate()) >= 0
                            && CalendarUtil.compareToPeriod(item.getRolPeriod(), filter.getEndDate()) <= 0);

        }

    }

    /**
     * @throws BusinessException
     */
    @Test
    public void search_rol_list_by_crop_company_period_customer_state_rol_status() throws BusinessException {

        // Load database
        setupDBUnit();

        // Load head office
        HeadOffice headOffice = (HeadOffice) getSession().get(HeadOffice.class, new Long(900000001));
        Assert.assertNotNull(headOffice);

        // Build filter
        ReportOnLineFilter filter = new ReportOnLineFilter();
        filter.setCompany(headOffice.getCompany());
        filter.setCrop(headOffice.getCrop());

        // Set status
        filter.setRolStatus(rolInformationService.selectRolStatusByCode(RolStatus.ROL_STATUS_RTV));
        Assert.assertNotNull(filter.getRolStatus());

        // Set state
        filter.setAffiliateState(headOffice.getCustomer().getAddress().getState());

        // Set period
        filter.setInitDate(getRolPeriod(2012, 7, 1));
        filter.setEndDate(getRolPeriod(2012, 12, 31));

        // search for Rol list
        List<ReportOnLine> rolList = reportOnlineService.selectReportOnLineListByFilter(filter);

        // Check result size
        Assert.assertTrue("Expected at least 1 reports. But found " + rolList.size(), rolList.size() >= 1);

        // Check result
        for (ReportOnLine item : rolList) {
            Assert.assertEquals(headOffice.getCompany(), item.getHeadoffice().getCompany());
            Assert.assertEquals(headOffice.getCrop(), item.getCrop());
            Assert.assertEquals(filter.getRolStatus(), item.getRolStatus());
            Assert.assertEquals(filter.getAffiliateState(), item.getHeadoffice().getCustomer().getAddress().getState());
            Assert.assertTrue(
                    "Expected reports between filter period.",
                    CalendarUtil.compareToPeriod(item.getRolPeriod(), filter.getInitDate()) >= 0
                            && CalendarUtil.compareToPeriod(item.getRolPeriod(), filter.getEndDate()) <= 0);

        }

    }

    /**
     * @throws BusinessException
     */
    @Test
    public void search_rol_list_by_crop_company_period_customer_city_rol_status() throws BusinessException {

        // Load database
        setupDBUnit();

        // Load head office
        HeadOffice headOffice = (HeadOffice) getSession().get(HeadOffice.class, new Long(900000001));
        Assert.assertNotNull(headOffice);

        // Build filter
        ReportOnLineFilter filter = new ReportOnLineFilter();
        filter.setCompany(headOffice.getCompany());
        filter.setCrop(headOffice.getCrop());

        // Set status
        filter.setRolStatus(rolInformationService.selectRolStatusByCode(RolStatus.ROL_STATUS_RTV));
        Assert.assertNotNull(filter.getRolStatus());

        // Set state
        filter.setAffiliateCity(headOffice.getCustomer().getAddress().getCity());

        // Set period
        filter.setInitDate(getRolPeriod(2012, 7, 1));
        filter.setEndDate(getRolPeriod(2012, 12, 31));

        // search for Rol list
        List<ReportOnLine> rolList = reportOnlineService.selectReportOnLineListByFilter(filter);

        // Check result size
        Assert.assertTrue("Expected at least 1 reports. But found " + rolList.size(), rolList.size() >= 1);

        // Check result
        for (ReportOnLine item : rolList) {
            Assert.assertEquals(headOffice.getCompany(), item.getHeadoffice().getCompany());
            Assert.assertEquals(headOffice.getCrop(), item.getCrop());
            Assert.assertEquals(filter.getRolStatus(), item.getRolStatus());
            Assert.assertEquals(filter.getAffiliateCity(), item.getHeadoffice().getCustomer().getAddress().getCity());
            Assert.assertTrue(
                    "Expected reports between filter period.",
                    CalendarUtil.compareToPeriod(item.getRolPeriod(), filter.getInitDate()) >= 0
                            && CalendarUtil.compareToPeriod(item.getRolPeriod(), filter.getEndDate()) <= 0);

        }

    }

    /**
     * @throws BusinessException
     */
    @Test
    public void search_rol_list_by_crop_company_customer_city() throws BusinessException {

        // Load database
        setupDBUnit();

        // Load head office
        HeadOffice headOffice = (HeadOffice) getSession().get(HeadOffice.class, new Long(900000001));
        Assert.assertNotNull(headOffice);

        // Build filter
        ReportOnLineFilter filter = new ReportOnLineFilter();
        filter.setCompany(headOffice.getCompany());
        filter.setCrop(headOffice.getCrop());

        // Set city
        filter.setAffiliateCity(headOffice.getCustomer().getAddress().getCity());

        // search for Rol list
        List<ReportOnLine> rolList = reportOnlineService.selectReportOnLineListByFilter(filter);

        // Check result size
        Assert.assertTrue("Expected at least 1 reports. But found " + rolList.size(), rolList.size() >= 1);

        // Check result
        for (ReportOnLine item : rolList) {
            Assert.assertEquals(headOffice.getCompany(), item.getHeadoffice().getCompany());
            Assert.assertEquals(headOffice.getCrop(), item.getCrop());
            Assert.assertEquals(filter.getAffiliateCity(), item.getHeadoffice().getCustomer().getAddress().getCity());
        }

    }

    /**
     * @throws BusinessException
     */
    @Test
    public void search_rol_list_by_crop_company_and_invalid_revenue_order_number_expected_empty_list()
            throws BusinessException {

        // Load database
        setupDBUnit();

        // Load head office
        HeadOffice headOffice = (HeadOffice) getSession().get(HeadOffice.class, new Long(900000001));
        Assert.assertNotNull(headOffice);

        // Build filter
        ReportOnLineFilter filter = new ReportOnLineFilter();
        filter.setCompany(headOffice.getCompany());
        filter.setCrop(headOffice.getCrop());

        // Set invalid order number
        filter.setOrderNumber("xxxjjjiii888");

        // search for Rol list
        List<ReportOnLine> rolList = reportOnlineService.selectReportOnLineListByFilter(filter);

        // Check result size
        Assert.assertTrue("Expected empty list. But found " + rolList.size(), rolList.isEmpty());

    }

    /**
     * @throws BusinessException
     */
    @Test
    public void search_rol_list_by_crop_company_customer_revenue_document_number() throws BusinessException {

        // Load database
        setupDBUnit();

        // Load head office
        HeadOffice headOffice = (HeadOffice) getSession().get(HeadOffice.class, new Long(900000001));
        Assert.assertNotNull(headOffice);

        OperationalYear operationalYear = (OperationalYear) getSession().createCriteria(OperationalYear.class).list()
                .get(0);

        // Create a fake revenue account scene
        RevenueAccount revenueAccount = new RevenueAccount(headOffice.getCustomer(), "123", operationalYear,
                RevenueType.POD, headOffice.getCompany(), new Date(), null);
        revenueAccount.setDocumentNumber("10000000005");
        revenueAccount.setOrderNumber("o11100112");

        // Create revenue handle
        RevenueHandle revenueHandle = new RevenueHandle(900000001L);
        revenueHandle.setRevenueAccount(revenueAccount);
        revenueAccount.getHandles().add(revenueHandle);
        saveAndFlush(revenueAccount);

        // Update rol with revenue account document number
        ReportOnLine rol = (ReportOnLine) getSession().get(ReportOnLine.class, 900000001L);
        rol.setRolBillNumber(new Long(revenueAccount.getDocumentNumber()));
        saveAndFlush(rol);

        // Build filter
        ReportOnLineFilter filter = new ReportOnLineFilter();
        filter.setCompany(headOffice.getCompany());
        filter.setCrop(headOffice.getCrop());
        filter.setCustomer(headOffice.getCustomer());

        // Set document number
        filter.setDocumentNumber(revenueAccount.getDocumentNumber());

        // search for Rol list
        List<ReportOnLine> rolList = reportOnlineService.selectReportOnLineListByFilter(filter);

        // Check result size
        Assert.assertTrue("Expected at least 1 reports. But found " + rolList.size(), rolList.size() >= 1);

        // Check result
        for (ReportOnLine item : rolList) {
            Assert.assertEquals(headOffice.getCompany(), item.getHeadoffice().getCompany());
            Assert.assertEquals(headOffice.getCrop(), item.getCrop());
            Assert.assertEquals(filter.getCustomer(), item.getHeadoffice().getCustomer());
            Assert.assertEquals(filter.getDocumentNumber(), item.getRolBillNumber().toString());
        }

    }

    /**
     * @throws BusinessException
     */
    @Test
    public void search_rol_list_by_crop_company_customer_revenue_order_number() throws BusinessException {

        // Load database
        setupDBUnit();

        // Load head office
        HeadOffice headOffice = (HeadOffice) getSession().get(HeadOffice.class, new Long(900000001));
        Assert.assertNotNull(headOffice);

        OperationalYear operationalYear = (OperationalYear) getSession().createCriteria(OperationalYear.class).list()
                .get(0);

        // Create a fake revenue account scene
        RevenueAccount revenueAccount = new RevenueAccount(headOffice.getCustomer(), "123", operationalYear,
                RevenueType.POD, headOffice.getCompany(), new Date(), null);
        revenueAccount.setDocumentNumber("10000000005");
        revenueAccount.setOrderNumber("o11100112x");

        // Create revenue handle
        RevenueHandle revenueHandle = new RevenueHandle(900000001L);
        revenueHandle.setRevenueAccount(revenueAccount);
        revenueAccount.getHandles().add(revenueHandle);
        saveAndFlush(revenueAccount);

        // Update rol with revenue account document number
        ReportOnLine rol = (ReportOnLine) getSession().get(ReportOnLine.class, 900000001L);
        rol.setRolBillNumber(new Long(revenueAccount.getDocumentNumber()));
        saveAndFlush(rol);

        // Build filter
        ReportOnLineFilter filter = new ReportOnLineFilter();
        filter.setCompany(headOffice.getCompany());
        filter.setCrop(headOffice.getCrop());
        filter.setCustomer(headOffice.getCustomer());

        // Set document number
        filter.setOrderNumber(revenueAccount.getOrderNumber());

        // search for Rol list
        List<ReportOnLine> rolList = reportOnlineService.selectReportOnLineListByFilter(filter);

        // Check result size
        Assert.assertTrue("Expected at least 1 reports. But found " + rolList.size(), rolList.size() >= 1);

        // Check result
        for (ReportOnLine item : rolList) {
            Assert.assertEquals(headOffice.getCompany(), item.getHeadoffice().getCompany());
            Assert.assertEquals(headOffice.getCrop(), item.getCrop());
            Assert.assertEquals(filter.getCustomer(), item.getHeadoffice().getCustomer());

            // Find revenue account
            RevenueHandle rHandle = (RevenueHandle) getSession().createCriteria(RevenueHandle.class)
                    .add(Restrictions.eq("handle", item.getId())).uniqueResult();
            Assert.assertNotNull(rHandle);
            Assert.assertEquals(filter.getOrderNumber(), rHandle.getRevenueAccount().getOrderNumber());
        }

    }

    /**
     * @throws BusinessException
     */
    @Test
    public void search_rol_list_by_crop_company_customer_revenue_unique_order_number() throws BusinessException {

        // Load database
        setupDBUnit();

        // Load head office
        HeadOffice headOffice = (HeadOffice) getSession().get(HeadOffice.class, new Long(900000001));
        Assert.assertNotNull(headOffice);

        OperationalYear operationalYear = (OperationalYear) getSession().createCriteria(OperationalYear.class).list()
                .get(0);

        // Create a fake revenue account scene
        RevenueAccount revenueAccount = new RevenueAccount(headOffice.getCustomer(), "123", operationalYear,
                RevenueType.POD, headOffice.getCompany(), new Date(), null);
        revenueAccount.setDocumentNumber("10000000005");
        revenueAccount.setOrderNumber("o11100112x");

        // Create revenue handle
        RevenueHandle revenueHandle = new RevenueHandle(900000001L);
        revenueHandle.setRevenueAccount(revenueAccount);
        revenueAccount.getHandles().add(revenueHandle);
        saveAndFlush(revenueAccount);

        // Update rol with revenue account document number
        ReportOnLine rol = (ReportOnLine) getSession().get(ReportOnLine.class, 900000001L);
        rol.setRolBillNumber(new Long(revenueAccount.getDocumentNumber()));
        saveAndFlush(rol);

        // Build filter
        ReportOnLineFilter filter = new ReportOnLineFilter();
        filter.setCompany(headOffice.getCompany());
        filter.setCrop(headOffice.getCrop());
        filter.setCustomer(headOffice.getCustomer());

        // Set unique document number
        filter.setUniqueOrderNumber(revenueAccount.getOrderNumber());

        // search for Rol list
        List<ReportOnLine> rolList = reportOnlineService.selectReportOnLineListByFilter(filter);

        // Check result size
        Assert.assertTrue("Expected at least 1 reports. But found " + rolList.size(), rolList.size() >= 1);

        // Check result
        for (ReportOnLine item : rolList) {
            Assert.assertEquals(headOffice.getCompany(), item.getHeadoffice().getCompany());
            Assert.assertEquals(headOffice.getCrop(), item.getCrop());
            Assert.assertEquals(filter.getCustomer(), item.getHeadoffice().getCustomer());

            // Find revenue account
            RevenueHandle rHandle = (RevenueHandle) getSession().createCriteria(RevenueHandle.class)
                    .add(Restrictions.eq("handle", item.getId())).uniqueResult();
            Assert.assertNotNull(rHandle);
            Assert.assertEquals(filter.getUniqueOrderNumber(), rHandle.getRevenueAccount().getOrderNumber());
        }

    }

    /**
     * @throws BusinessException
     */
    @Test
    public void search_rol_list_by_crop_company_customer_revenue_valid_period() throws BusinessException {

        // Load database
        setupDBUnit();

        // Load head office
        HeadOffice headOffice = (HeadOffice) getSession().get(HeadOffice.class, new Long(900000001));
        Assert.assertNotNull(headOffice);

        OperationalYear operationalYear = (OperationalYear) getSession().createCriteria(OperationalYear.class).list()
                .get(0);

        // Create a fake revenue account scene
        RevenueAccount revenueAccount = new RevenueAccount(headOffice.getCustomer(), "123", operationalYear,
                RevenueType.POD, headOffice.getCompany(), new Date(), null);
        revenueAccount.setDocumentNumber("10000000005");
        revenueAccount.setOrderNumber("o11100112x");

        // Create revenue handle
        RevenueHandle revenueHandle = new RevenueHandle(900000001L);
        revenueHandle.setRevenueAccount(revenueAccount);
        revenueAccount.getHandles().add(revenueHandle);
        saveAndFlush(revenueAccount);

        // Update rol with revenue account document number
        ReportOnLine rol = (ReportOnLine) getSession().get(ReportOnLine.class, 900000001L);
        rol.setRolBillNumber(new Long(revenueAccount.getDocumentNumber()));
        saveAndFlush(rol);

        // Build filter
        ReportOnLineFilter filter = new ReportOnLineFilter();
        filter.setCompany(headOffice.getCompany());
        filter.setCrop(headOffice.getCrop());
        filter.setCustomer(headOffice.getCustomer());

        // Set document number
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.MONTH, -1);
        filter.setInitRevenueDate(calendar.getTime());
        calendar.add(Calendar.MONTH, 2);
        filter.setEndRevenueDate(calendar.getTime());

        // search for Rol list
        List<ReportOnLine> rolList = reportOnlineService.selectReportOnLineListByFilter(filter);

        // Check result size
        Assert.assertTrue("Expected at least 1 reports. But found " + rolList.size(), rolList.size() >= 1);

        // Check result
        for (ReportOnLine item : rolList) {
            Assert.assertEquals(headOffice.getCompany(), item.getHeadoffice().getCompany());
            Assert.assertEquals(headOffice.getCrop(), item.getCrop());
            Assert.assertEquals(filter.getCustomer(), item.getHeadoffice().getCustomer());
            // Find revenue account
            RevenueHandle rHandle = (RevenueHandle) getSession().createCriteria(RevenueHandle.class)
                    .add(Restrictions.eq("handle", item.getId())).uniqueResult();
            Assert.assertNotNull(rHandle);
            Date revenueAccountPeriod = rHandle.getRevenueAccount().getPostDate();
            Assert.assertTrue(
                    "Expected revenue account in period range. But found " + revenueAccountPeriod,
                    revenueAccountPeriod.compareTo(filter.getInitRevenueDate()) >= 0
                            && revenueAccountPeriod.compareTo(filter.getEndRevenueDate()) <= 0);
        }

    }

    /**
     * @throws BusinessException
     */
    @Test
    public void search_rol_list_by_crop_company_customer_revenue_invalid_period() throws BusinessException {

        // Load database
        setupDBUnit();

        // Load head office
        HeadOffice headOffice = (HeadOffice) getSession().get(HeadOffice.class, new Long(900000001));
        Assert.assertNotNull(headOffice);

        OperationalYear operationalYear = (OperationalYear) getSession().createCriteria(OperationalYear.class).list()
                .get(0);

        // Create a fake revenue account scene
        RevenueAccount revenueAccount = new RevenueAccount(headOffice.getCustomer(), "123", operationalYear,
                RevenueType.POD, headOffice.getCompany(), new Date(), null);
        revenueAccount.setDocumentNumber("10000000005");
        revenueAccount.setOrderNumber("o11100112x");

        // Create revenue handle
        RevenueHandle revenueHandle = new RevenueHandle(900000001L);
        revenueHandle.setRevenueAccount(revenueAccount);
        revenueAccount.getHandles().add(revenueHandle);
        saveAndFlush(revenueAccount);

        // Update rol with revenue account document number
        ReportOnLine rol = (ReportOnLine) getSession().get(ReportOnLine.class, 900000001L);
        rol.setRolBillNumber(new Long(revenueAccount.getDocumentNumber()));
        saveAndFlush(rol);

        // Build filter
        ReportOnLineFilter filter = new ReportOnLineFilter();
        filter.setCompany(headOffice.getCompany());
        filter.setCrop(headOffice.getCrop());
        filter.setCustomer(headOffice.getCustomer());

        // Set future revenue period (invalid because its not possible generate
        // tax on future)
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.MONTH, 10);
        filter.setInitRevenueDate(calendar.getTime());
        calendar.add(Calendar.MONTH, 20);
        filter.setEndRevenueDate(calendar.getTime());

        // search for Rol list
        List<ReportOnLine> rolList = reportOnlineService.selectReportOnLineListByFilter(filter);

        // Check result size
        Assert.assertTrue("Expected empty list. But found " + rolList.size(), rolList.isEmpty());

    }

    /**
     * @throws BusinessException
     */
    @Test
    public void search_rol_list_by_crop_company_and_invalid_revenue_document_number_expected_empty_list()
            throws BusinessException {

        // Load database
        setupDBUnit();

        // Load head office
        HeadOffice headOffice = (HeadOffice) getSession().get(HeadOffice.class, new Long(900000001));
        Assert.assertNotNull(headOffice);

        // Build filter
        ReportOnLineFilter filter = new ReportOnLineFilter();
        filter.setCompany(headOffice.getCompany());
        filter.setCrop(headOffice.getCrop());

        // Set invalid document number
        filter.setDocumentNumber("luluzinha");

        // search for Rol list
        List<ReportOnLine> rolList = reportOnlineService.selectReportOnLineListByFilter(filter);

        // Check result size
        Assert.assertTrue("Expected empty list. But found " + rolList.size(), rolList.isEmpty());

    }

    /**
     * @throws BusinessException
     */
    @Test
    public void search_rol_list_by_crop_company_and_invalid_revenue_period_expected_empty_list()
            throws BusinessException {

        // Load database
        setupDBUnit();

        // Load head office
        HeadOffice headOffice = (HeadOffice) getSession().get(HeadOffice.class, new Long(900000001));
        Assert.assertNotNull(headOffice);

        // Build filter
        ReportOnLineFilter filter = new ReportOnLineFilter();
        filter.setCompany(headOffice.getCompany());
        filter.setCrop(headOffice.getCrop());

        // Set invalid revenue period
        filter.setInitRevenueDate(CalendarUtil.getDate(1500, 01, 01));
        filter.setEndRevenueDate(CalendarUtil.getDate(1600, 01, 01));

        // search for Rol list
        List<ReportOnLine> rolList = reportOnlineService.selectReportOnLineListByFilter(filter);

        // Check result size
        Assert.assertTrue("Expected empty list. But found " + rolList.size(), rolList.isEmpty());

    }

    /**
     * @throws BusinessException
     */
    @Test
    public void search_rol_list_by_crop_company_customer_invalid_city() throws BusinessException {

        // Load database
        setupDBUnit();

        // Load head office
        HeadOffice headOffice = (HeadOffice) getSession().get(HeadOffice.class, new Long(900000001));
        Assert.assertNotNull(headOffice);

        // Build filter
        ReportOnLineFilter filter = new ReportOnLineFilter();
        filter.setCompany(headOffice.getCompany());
        filter.setCrop(headOffice.getCrop());

        // Set city
        City city = (City) getSession().get(City.class, 990000006L);
        filter.setAffiliateCity(city);

        // search for Rol list
        List<ReportOnLine> rolList = reportOnlineService.selectReportOnLineListByFilter(filter);

        // Check result size
        Assert.assertTrue("Expected empty list. But found " + rolList.size(), rolList.isEmpty());

    }

    /**
     * @throws BusinessException
     */
    @Test
    public void search_rol_list_by_crop_company_period_customer_city_state_rol_status() throws BusinessException {

        // Load database
        setupDBUnit();

        // Load head office
        HeadOffice headOffice = (HeadOffice) getSession().get(HeadOffice.class, new Long(900000001));
        Assert.assertNotNull(headOffice);

        // Build filter
        ReportOnLineFilter filter = new ReportOnLineFilter();
        filter.setCompany(headOffice.getCompany());
        filter.setCrop(headOffice.getCrop());

        // Set status
        filter.setRolStatus(rolInformationService.selectRolStatusByCode(RolStatus.ROL_STATUS_RTV));
        Assert.assertNotNull(filter.getRolStatus());

        // Set city
        filter.setAffiliateCity(headOffice.getCustomer().getAddress().getCity());

        // Set state
        filter.setAffiliateState(headOffice.getCustomer().getAddress().getState());

        // Set period
        filter.setInitDate(getRolPeriod(2012, 7, 1));
        filter.setEndDate(getRolPeriod(2012, 12, 31));

        // search for Rol list
        List<ReportOnLine> rolList = reportOnlineService.selectReportOnLineListByFilter(filter);

        // Check result size
        Assert.assertTrue("Expected at least 1 reports. But found " + rolList.size(), rolList.size() >= 1);

        // Check result
        for (ReportOnLine item : rolList) {
            Assert.assertEquals(headOffice.getCompany(), item.getHeadoffice().getCompany());
            Assert.assertEquals(headOffice.getCrop(), item.getCrop());
            Assert.assertEquals(filter.getRolStatus(), item.getRolStatus());
            Assert.assertEquals(filter.getAffiliateCity(), item.getHeadoffice().getCustomer().getAddress().getCity());
            Assert.assertEquals(filter.getAffiliateState(), item.getHeadoffice().getCustomer().getAddress().getState());
            Assert.assertTrue(
                    "Expected reports between filter period.",
                    CalendarUtil.compareToPeriod(item.getRolPeriod(), filter.getInitDate()) >= 0
                            && CalendarUtil.compareToPeriod(item.getRolPeriod(), filter.getEndDate()) <= 0);

        }

    }

    /**
     * @throws BusinessException
     */
    @Test
    public void search_rol_list_by_crop_company_period_matrix_invalid_state_rol_status() throws BusinessException {

        // Load database
        setupDBUnit();

        // Load head office
        HeadOffice headOffice = (HeadOffice) getSession().get(HeadOffice.class, new Long(900000001));
        Assert.assertNotNull(headOffice);

        // Build filter
        ReportOnLineFilter filter = new ReportOnLineFilter();
        filter.setCompany(headOffice.getCompany());
        filter.setCrop(headOffice.getCrop());

        // Set status
        filter.setRolStatus(rolInformationService.selectRolStatusByCode(RolStatus.ROL_STATUS_RTV));
        Assert.assertNotNull(filter.getRolStatus());

        // Set state
        State state = (State) getSession().get(State.class, 900000004L);
        Assert.assertNotNull(state);
        filter.setState(state);

        // Set period
        filter.setInitDate(getRolPeriod(2012, 7, 1));
        filter.setEndDate(getRolPeriod(2012, 12, 31));

        // search for Rol list
        List<ReportOnLine> rolList = reportOnlineService.selectReportOnLineListByFilter(filter);

        // Check result size
        Assert.assertTrue("Expected empty list. But found " + rolList.size(), rolList.isEmpty());

    }

    /**
     * @throws BusinessException
     */
    @Test
    public void search_rol_list_by_crop_company_period_matrix_city_rol_status() throws BusinessException {

        // Load database
        setupDBUnit();

        // Load head office
        HeadOffice headOffice = (HeadOffice) getSession().get(HeadOffice.class, new Long(900000001));
        Assert.assertNotNull(headOffice);

        // Build filter
        ReportOnLineFilter filter = new ReportOnLineFilter();
        filter.setCompany(headOffice.getCompany());
        filter.setCrop(headOffice.getCrop());

        // Set status
        filter.setRolStatus(rolInformationService.selectRolStatusByCode(RolStatus.ROL_STATUS_RTV));
        Assert.assertNotNull(filter.getRolStatus());

        // Set state
        filter.setCity(headOffice.getMatrix().getAddress().getCity());

        // Set period
        filter.setInitDate(getRolPeriod(2012, 7, 1));
        filter.setEndDate(getRolPeriod(2012, 12, 31));

        // search for Rol list
        List<ReportOnLine> rolList = reportOnlineService.selectReportOnLineListByFilter(filter);

        // Check result size
        Assert.assertTrue("Expected at least 1 reports. But found " + rolList.size(), rolList.size() >= 1);

        // Check result
        for (ReportOnLine item : rolList) {
            Assert.assertEquals(headOffice.getCompany(), item.getHeadoffice().getCompany());
            Assert.assertEquals(headOffice.getCrop(), item.getCrop());
            Assert.assertEquals(filter.getRolStatus(), item.getRolStatus());
            Assert.assertEquals(filter.getCity(), item.getHeadoffice().getMatrix().getAddress().getCity());
            Assert.assertTrue(
                    "Expected reports between filter period.",
                    CalendarUtil.compareToPeriod(item.getRolPeriod(), filter.getInitDate()) >= 0
                            && CalendarUtil.compareToPeriod(item.getRolPeriod(), filter.getEndDate()) <= 0);

        }

    }

    /**
     * @throws BusinessException
     */
    @Test
    public void search_rol_list_by_crop_company_period_matrix_state_city_rol_status() throws BusinessException {

        // Load database
        setupDBUnit();

        // Load head office
        HeadOffice headOffice = (HeadOffice) getSession().get(HeadOffice.class, new Long(900000001));
        Assert.assertNotNull(headOffice);

        // Build filter
        ReportOnLineFilter filter = new ReportOnLineFilter();
        filter.setCompany(headOffice.getCompany());
        filter.setCrop(headOffice.getCrop());

        // Set status
        filter.setRolStatus(rolInformationService.selectRolStatusByCode(RolStatus.ROL_STATUS_RTV));
        Assert.assertNotNull(filter.getRolStatus());

        // Set city
        filter.setCity(headOffice.getMatrix().getAddress().getCity());

        // Set state
        filter.setState(headOffice.getMatrix().getAddress().getState());

        // Set period
        filter.setInitDate(getRolPeriod(2012, 7, 1));
        filter.setEndDate(getRolPeriod(2012, 12, 31));

        // search for Rol list
        List<ReportOnLine> rolList = reportOnlineService.selectReportOnLineListByFilter(filter);

        // Check result size
        Assert.assertTrue("Expected at least 1 reports. But found " + rolList.size(), rolList.size() >= 1);

        // Check result
        for (ReportOnLine item : rolList) {
            Assert.assertEquals(headOffice.getCompany(), item.getHeadoffice().getCompany());
            Assert.assertEquals(headOffice.getCrop(), item.getCrop());
            Assert.assertEquals(filter.getRolStatus(), item.getRolStatus());
            Assert.assertEquals(filter.getCity(), item.getHeadoffice().getMatrix().getAddress().getCity());
            Assert.assertEquals(filter.getState(), item.getHeadoffice().getMatrix().getAddress().getState());
            Assert.assertTrue(
                    "Expected reports between filter period.",
                    CalendarUtil.compareToPeriod(item.getRolPeriod(), filter.getInitDate()) >= 0
                            && CalendarUtil.compareToPeriod(item.getRolPeriod(), filter.getEndDate()) <= 0);
        }

    }

    /**
     * @throws BusinessException
     */
    @Test
    public void search_rol_list_by_crop_company_period_matrix_invalid_city_rol_status() throws BusinessException {

        // Load database
        setupDBUnit();

        // Load head office
        HeadOffice headOffice = (HeadOffice) getSession().get(HeadOffice.class, new Long(900000001));
        Assert.assertNotNull(headOffice);

        // Build filter
        ReportOnLineFilter filter = new ReportOnLineFilter();
        filter.setCompany(headOffice.getCompany());
        filter.setCrop(headOffice.getCrop());

        // Set status
        filter.setRolStatus(rolInformationService.selectRolStatusByCode(RolStatus.ROL_STATUS_RTV));
        Assert.assertNotNull(filter.getRolStatus());

        // Set state
        City city = (City) getSession().get(City.class, 900000005L);
        Assert.assertNotNull(city);
        filter.setCity(city);

        // Set period
        filter.setInitDate(getRolPeriod(2012, 7, 1));
        filter.setEndDate(getRolPeriod(2012, 12, 31));

        // search for Rol list
        List<ReportOnLine> rolList = reportOnlineService.selectReportOnLineListByFilter(filter);

        // Check result size
        Assert.assertTrue("Expected empty list. But found " + rolList.size(), rolList.isEmpty());

    }

    /**
     * @throws BusinessException
     */
    @Test
    public void search_rol_list_by_customer_matrix_unity__invalid_district_region_affiliate_crop_operational_year_rol_status_expected_empty_list()
            throws BusinessException {

        // Load database
        setupDBUnit();

        // Load operational year
        OperationalYear operYear = (OperationalYear) getSession().get(OperationalYear.class, new Long(900000007));
        Assert.assertNotNull(operYear);

        // Load head office
        HeadOffice headOffice = (HeadOffice) getSession().get(HeadOffice.class, new Long(900000001));
        Assert.assertNotNull(headOffice);

        // Build filter
        ReportOnLineFilter filter = new ReportOnLineFilter();
        filter.setCompany(headOffice.getCompany());
        filter.setCrop(headOffice.getCrop());
        filter.setOperationalYear(operYear);
        filter.setMatrix(headOffice.getMatrix());
        filter.setCustomer(headOffice.getCustomer());

        // Set status
        filter.setRolStatus(rolInformationService.selectRolStatusByCode(RolStatus.ROL_STATUS_RTV));
        Assert.assertNotNull(filter.getRolStatus());

        // Set district
        ItsDistrict district = (ItsDistrict) getSession().get(ItsDistrict.class, 900000000L);
        Assert.assertNotNull(district);
        filter.setCustomerDistrict(district);

        // Set unity
        ItsUnity unity = (ItsUnity) getSession().get(ItsUnity.class, 900000005L);
        Assert.assertNotNull(unity);
        filter.setCustomerUnity(unity);

        // Set region
        ItsRegion region = (ItsRegion) getSession().get(ItsRegion.class, 900000001L);
        Assert.assertNotNull(region);
        filter.setCustomerRegion(region);

        // Set period
        filter.setInitDate(getRolPeriod(2012, 7, 1));
        filter.setEndDate(getRolPeriod(2012, 12, 31));

        // search for Rol list
        List<ReportOnLine> rolList = reportOnlineService.selectReportOnLineListByFilter(filter);

        // Check result size
        Assert.assertTrue("Expected empty list. But found " + rolList.size(), rolList.isEmpty());

    }

    /**
     * @throws BusinessException
     */
    @Test
    public void search_rol_list_by_customer_matrix_invalid_unity_district_region_matrix_crop_operational_year_rol_status()
            throws BusinessException {

        // Load database
        setupDBUnit();

        // Load operational year
        OperationalYear operYear = (OperationalYear) getSession().get(OperationalYear.class, new Long(900000007));
        Assert.assertNotNull(operYear);

        // Load head office
        HeadOffice headOffice = (HeadOffice) getSession().get(HeadOffice.class, new Long(900000001));
        Assert.assertNotNull(headOffice);

        // Build filter
        ReportOnLineFilter filter = new ReportOnLineFilter();
        filter.setCompany(headOffice.getCompany());
        filter.setCrop(headOffice.getCrop());
        filter.setOperationalYear(operYear);
        filter.setMatrix(headOffice.getMatrix());
        filter.setCustomer(headOffice.getCustomer());

        // Set status
        filter.setRolStatus(rolInformationService.selectRolStatusByCode(RolStatus.ROL_STATUS_RTV));
        Assert.assertNotNull(filter.getRolStatus());

        // Set district
        ItsDistrict district = (ItsDistrict) getSession().get(ItsDistrict.class, 900000000L);
        Assert.assertNotNull(district);
        filter.setDistrict(district);

        // Set unity
        ItsUnity unity = (ItsUnity) getSession().get(ItsUnity.class, 900000005L);
        Assert.assertNotNull(unity);
        filter.setUnity(unity);

        // Set region
        ItsRegion region = (ItsRegion) getSession().get(ItsRegion.class, 900000000L);
        Assert.assertNotNull(region);
        filter.setRegion(region);

        // Set period
        filter.setInitDate(getRolPeriod(2012, 7, 1));
        filter.setEndDate(getRolPeriod(2012, 12, 31));

        // search for Rol list
        List<ReportOnLine> rolList = reportOnlineService.selectReportOnLineListByFilter(filter);

        // Check result size
        Assert.assertTrue("Expected empty list. But found " + rolList.size(), rolList.isEmpty());

    }

    /**
     * @throws BusinessException
     */
    @Test
    public void search_rol_list_by_customer_matrix_invalid_district_matrix_crop_operational_year_rol_status()
            throws BusinessException {

        // Load database
        setupDBUnit();

        // Load operational year
        OperationalYear operYear = (OperationalYear) getSession().get(OperationalYear.class, new Long(900000007));
        Assert.assertNotNull(operYear);

        // Load head office
        HeadOffice headOffice = (HeadOffice) getSession().get(HeadOffice.class, new Long(900000001));
        Assert.assertNotNull(headOffice);

        // Build filter
        ReportOnLineFilter filter = new ReportOnLineFilter();
        filter.setCompany(headOffice.getCompany());
        filter.setCrop(headOffice.getCrop());
        filter.setOperationalYear(operYear);
        filter.setMatrix(headOffice.getMatrix());
        filter.setCustomer(headOffice.getCustomer());

        // Set status
        filter.setRolStatus(rolInformationService.selectRolStatusByCode(RolStatus.ROL_STATUS_RTV));
        Assert.assertNotNull(filter.getRolStatus());

        // Set district
        ItsDistrict district = (ItsDistrict) getSession().get(ItsDistrict.class, 900000005L);
        Assert.assertNotNull(district);
        filter.setDistrict(district);

        // Set period
        filter.setInitDate(getRolPeriod(2012, 7, 1));
        filter.setEndDate(getRolPeriod(2012, 12, 31));

        // search for Rol list
        List<ReportOnLine> rolList = reportOnlineService.selectReportOnLineListByFilter(filter);

        // Check result size
        Assert.assertTrue("Expected empty list. But found " + rolList.size(), rolList.isEmpty());

    }

    /**
     * @throws BusinessException
     */
    @Test
    public void search_rol_list_by_customer_matrix_region_matrix_crop_operational_year_rol_status()
            throws BusinessException {

        // Load database
        setupDBUnit();

        // Load operational year
        OperationalYear operYear = (OperationalYear) getSession().get(OperationalYear.class, new Long(900000007));
        Assert.assertNotNull(operYear);

        // Load head office
        HeadOffice headOffice = (HeadOffice) getSession().get(HeadOffice.class, new Long(900000001));
        Assert.assertNotNull(headOffice);

        // Build filter
        ReportOnLineFilter filter = new ReportOnLineFilter();
        filter.setCompany(headOffice.getCompany());
        filter.setCrop(headOffice.getCrop());
        filter.setOperationalYear(operYear);
        filter.setMatrix(headOffice.getMatrix());
        filter.setCustomer(headOffice.getCustomer());

        // Set status
        filter.setRolStatus(rolInformationService.selectRolStatusByCode(RolStatus.ROL_STATUS_RTV));
        Assert.assertNotNull(filter.getRolStatus());

        // Set district
        ItsRegion region = (ItsRegion) getSession().get(ItsRegion.class, 900000000L);
        Assert.assertNotNull(region);
        filter.setRegion(region);

        // Set period
        filter.setInitDate(getRolPeriod(2012, 7, 1));
        filter.setEndDate(getRolPeriod(2012, 12, 31));

        // search for Rol list
        List<ReportOnLine> rolList = reportOnlineService.selectReportOnLineListByFilter(filter);

        // Check result size
        Assert.assertTrue("Expected at least 1 reports. But found " + rolList.size(), rolList.size() >= 1);

        // Check result
        for (ReportOnLine item : rolList) {
            Assert.assertEquals(headOffice.getCompany(), item.getHeadoffice().getCompany());
            Assert.assertEquals(headOffice.getCrop(), item.getCrop());
            Assert.assertEquals(operYear, item.getOperationalYear());
            Assert.assertEquals(headOffice.getMatrix(), item.getHeadoffice().getMatrix());
            Assert.assertEquals(headOffice.getCustomer(), item.getHeadoffice().getCustomer());
            Assert.assertEquals(filter.getRolStatus(), item.getRolStatus());
            Assert.assertTrue(
                    "Expected reports between filter period.",
                    CalendarUtil.compareToPeriod(item.getRolPeriod(), filter.getInitDate()) >= 0
                            && CalendarUtil.compareToPeriod(item.getRolPeriod(), filter.getEndDate()) <= 0);
            Assert.assertTrue("Matrix must have commercial hierarchy of POD.",
                    checkCommercialHierarchyType(item.getHeadoffice().getMatrix(), CommercialHierarchyType.POD));
            Assert.assertTrue("Matrix must have region " + filter.getRegion() + " for POD commercial hierarchy.",
                    checkRegion(item.getHeadoffice().getMatrix(), filter.getRegion()));
        }

    }

    /**
     * @throws BusinessException
     */
    @Test
    public void search_rol_list_by_customer_matrix_invalid_region_matrix_crop_operational_year_rol_status()
            throws BusinessException {

        // Load database
        setupDBUnit();

        // Load operational year
        OperationalYear operYear = (OperationalYear) getSession().get(OperationalYear.class, new Long(900000007));
        Assert.assertNotNull(operYear);

        // Load head office
        HeadOffice headOffice = (HeadOffice) getSession().get(HeadOffice.class, new Long(900000001));
        Assert.assertNotNull(headOffice);

        // Build filter
        ReportOnLineFilter filter = new ReportOnLineFilter();
        filter.setCompany(headOffice.getCompany());
        filter.setCrop(headOffice.getCrop());
        filter.setOperationalYear(operYear);
        filter.setMatrix(headOffice.getMatrix());
        filter.setCustomer(headOffice.getCustomer());

        // Set status
        filter.setRolStatus(rolInformationService.selectRolStatusByCode(RolStatus.ROL_STATUS_RTV));
        Assert.assertNotNull(filter.getRolStatus());

        // Set invalid region
        ItsRegion region = (ItsRegion) getSession().get(ItsRegion.class, 900000003L);
        Assert.assertNotNull(region);
        filter.setRegion(region);

        // Set period
        filter.setInitDate(getRolPeriod(2012, 7, 1));
        filter.setEndDate(getRolPeriod(2012, 12, 31));

        // search for Rol list
        List<ReportOnLine> rolList = reportOnlineService.selectReportOnLineListByFilter(filter);

        // Check result size
        Assert.assertTrue("Expected empty list. But found " + rolList.size(), rolList.isEmpty());

    }

    /**
     * Check if customer have unity.
     * 
     * @param customer
     * @param unity
     * @return
     */
    private Boolean checkUnity(final Customer customer, final ItsUnity unity) {

        Customer attached = (Customer) getSession().get(Customer.class, customer.getId());

        for (CustomerDistrict cd : attached.getDistricts()) {
            if (cd.getItsDistrict().getItsUnity().equals(unity)) {
                return Boolean.TRUE;
            }
        }

        return Boolean.FALSE;
    }

    /**
     * Check if customer have district.
     * 
     * @param customer
     * @param unity
     * @return
     */
    private Boolean checkDistrict(final Customer customer, final ItsDistrict district) {

        Customer attached = (Customer) getSession().get(Customer.class, customer.getId());

        for (CustomerDistrict cd : attached.getDistricts()) {
            if (cd.getItsDistrict().equals(district)) {
                return Boolean.TRUE;
            }
        }

        return Boolean.FALSE;
    }

    /**
     * Check if customer have region.
     * 
     * @param customer
     * @param region
     * @return
     */
    private Boolean checkRegion(final Customer customer, final ItsRegion region) {

        Customer attached = (Customer) getSession().get(Customer.class, customer.getId());

        for (CustomerDistrict cd : attached.getDistricts()) {
            if (cd.getItsDistrict().getItsRegion().equals(region)) {
                return Boolean.TRUE;
            }
        }

        return Boolean.FALSE;
    }

    /**
     * Check if customer have unity.
     * 
     * @param customer
     * @param unity
     * @return
     */
    private Boolean checkCommercialHierarchyType(final Customer customer,
            final CommercialHierarchyType commercialHierarchyType) {

        for (CustomerDistrict cd : customer.getDistricts()) {

            if (cd.getCommercialHierarchy().getCommercialHierType().getCommercialHierTypeDesc()
                    .equals(commercialHierarchyType.getValue())) {
                return Boolean.TRUE;
            }

        }

        return Boolean.FALSE;
    }

    /**
     * @throws BusinessException
     */
    @Test
    public void search_rol_list_by_customer_matrix_crop_operational_year_invalid_rol_status_expected_empty_list()
            throws BusinessException {

        // Load database
        setupDBUnit();

        // Load operational year
        OperationalYear operYear = (OperationalYear) getSession().get(OperationalYear.class, new Long(900000007));

        // Load head office
        HeadOffice headOffice = (HeadOffice) getSession().get(HeadOffice.class, new Long(900000001));

        // Build filter
        ReportOnLineFilter filter = new ReportOnLineFilter();
        filter.setCompany(headOffice.getCompany());
        filter.setCrop(headOffice.getCrop());
        filter.setOperationalYear(operYear);
        filter.setMatrix(headOffice.getMatrix());
        filter.setCustomer(headOffice.getCustomer());

        // Set status reported, this state never will be exists on table
        filter.setRolStatus(rolInformationService.selectRolStatusByCode(RolStatus.ROL_STATUS_REPORTED));

        // Set period
        filter.setInitDate(getRolPeriod(2012, 7, 1));
        filter.setEndDate(getRolPeriod(2012, 12, 31));

        // search for Rol list
        List<ReportOnLine> rolList = reportOnlineService.selectReportOnLineListByFilter(filter);

        // Check result size
        Assert.assertTrue("Expected a empty list. But found " + rolList.size(), rolList.isEmpty());
    }

    @Test
    public void search_rol_dto_list_by_filter_participant_user() throws BusinessException {

        setupDBUnit();

        Company company = (Company) getSession().get(Company.class, new Long(990000002));// Monsanto
        Assert.assertNotNull(company);
        Crop crop = (Crop) getSession().get(Crop.class, new Long(900000001));// _BEANS_
        Assert.assertNotNull(crop);
        OperationalYear operYear = (OperationalYear) getSession().get(OperationalYear.class, new Long(900000007));// _2012_
        Assert.assertNotNull(operYear);
        Customer customer = (Customer) getSession().get(Customer.class, new Long(900000001));
        Assert.assertNotNull(customer);

        // build filter
        ReportOnLineFilter filter = new ReportOnLineFilter();
        filter.setCompany(company);
        filter.setCrop(crop);
        filter.setOperationalYear(operYear);
        filter.setRolPeriod(getRolPeriod(2012, 5, 1));// consider only ROL
                                                      // on May
        filter.setMatrix(customer);

        // User contracts
        List<UserContract> contracts = new ArrayList<UserContract>();
        UserContract userContract = (UserContract) getSession().get(UserContract.class, new Long(900000001));
        Assert.assertNotNull(userContract);
        contracts.add(userContract);

        // Performe search
        List<ReportOnLineSearchDTO> dtoRolList = reportOnlineService.selectReportOnLineDTOList(contracts, filter);

        Assert.assertTrue("Expected at least 2 records.", dtoRolList.size() >= 2);

        // Verify records across the filter
        for (ReportOnLineSearchDTO item : dtoRolList) {
            Assert.assertEquals(filter.getCrop(), item.getRol().getCrop());
            Assert.assertEquals(filter.getCompany(), item.getRol().getHeadoffice().getCompany());
            Assert.assertEquals(filter.getOperationalYear(), item.getRol().getOperationalYear());
            Assert.assertEquals(customer, item.getRol().getHeadoffice().getMatrix());
            Assert.assertTrue("Period invalid.", item.getRol().getRolPeriod().compareTo(filter.getInitDate()) >= 0
                    && item.getRol().getRolPeriod().compareTo(filter.getEndDate()) <= 0);
            Assert.assertTrue("Affiliate must be enabled for report rol.", item.getRol().getHeadoffice()
                    .enableRolReport());
            Assert.assertTrue("Affiliate must have vigor in filter range.",
                    item.getRol().getHeadoffice().checkVigor(filter.getInitDate())
                            && item.getRol().getHeadoffice().checkVigor(filter.getEndDate()));
        }

    }

    /**
     * @throws RolParameterException
     * @throws GrowerNotFoundException
     * @throws UserNotFoundException
     * @throws CustomerNotFoundException
     * @throws CustomerNotAllowedException
     */
    @Test(expected = IllegalArgumentException.class)
    public void search_rol_dto_list_by_filter_participant_user_withou_crop_and_company_expected_illegal_argument_exception()
            throws RolParameterException, GrowerNotFoundException, UserNotFoundException, CustomerNotFoundException,
            CustomerNotAllowedException {

        // User contracts
        List<UserContract> contracts = new ArrayList<UserContract>();

        // Search report with crop and company null
        reportOnlineService.selectReportOnLineDTOList(contracts, new ReportOnLineFilter());

    }

    @Test
    public void search_rol_dto_list_by_filter_superoradmin_user() throws BusinessException {

        setupDBUnit();
        Crop crop = (Crop) getSession().get(Crop.class, new Long("900000001")); // BEANS
        Company company = (Company) getSession().get(Company.class, new Long("990000002"));// Monsanto
        OperationalYear operYear = (OperationalYear) getSession().get(OperationalYear.class, new Long(900000007));// _2012_
        Customer customer = (Customer) getSession().get(Customer.class, new Long(900000001));

        // build filter
        ReportOnLineFilter filter = new ReportOnLineFilter();
        filter.setCompany(company);
        filter.setCrop(crop);
        filter.setOperationalYear(operYear);
        filter.setRolPeriod(getRolPeriod(2012, 7, 1));// consider only ROL
                                                      // on May
        filter.setMatrix(customer);
        List<ReportOnLineSearchDTO> dtoRolList = reportOnlineService.selectReportOnLineDTOList(null, filter);

        Assert.assertTrue("Expected at leat 2 records.", dtoRolList.size() >= 2);

        for (ReportOnLineSearchDTO item : dtoRolList) {
            Assert.assertEquals(filter.getCrop(), item.getRol().getCrop());
            Assert.assertEquals(filter.getCompany(), item.getRol().getHeadoffice().getCompany());
            Assert.assertEquals(filter.getOperationalYear(), item.getRol().getOperationalYear());
            Assert.assertEquals(customer, item.getRol().getHeadoffice().getMatrix());
            Assert.assertTrue("Period invalid.", item.getRol().getRolPeriod().compareTo(filter.getInitDate()) >= 0
                    && item.getRol().getRolPeriod().compareTo(filter.getEndDate()) <= 0);
            Assert.assertTrue("Affiliate must be enabled for report rol.", item.getRol().getHeadoffice()
                    .enableRolReport());
            Assert.assertTrue("Affiliate must have vigor in filter range.",
                    item.getRol().getHeadoffice().checkVigor(filter.getInitDate())
                            && item.getRol().getHeadoffice().checkVigor(filter.getEndDate()));
        }

    }

    /**
     * @param year
     * @param month
     * @param day
     * @return
     */
    private Date getRolPeriod(final int year, final int month, final int day) {
        Calendar cal = Calendar.getInstance();
        cal.clear();
        cal.set(year, month - 1, day);
        return cal.getTime();

    }

    /**
     *
     */
    @Test(expected = IllegalArgumentException.class)
    public void test_search_report_online_without_parameters_expect_illegal_argument_exception() {
        reportOnlineService.searchReportOnline(null, null, null, null);
    }

    /**
     *
     */
    @Test(expected = IllegalArgumentException.class)
    public void test_search_report_online_with_null_crop_expect_illegal_argument_exception() {
        reportOnlineService.searchReportOnline(null, new HeadOffice(), new Date(), new OperationalYear());
    }

    /**
     *
     */
    @Test(expected = IllegalArgumentException.class)
    public void test_search_report_online_with_null_headoffice_expect_illegal_argument_exception() {
        reportOnlineService.searchReportOnline(new Crop(), null, new Date(), new OperationalYear());
    }

    /**
     *
     */
    @Test(expected = IllegalArgumentException.class)
    public void test_search_report_online_with_null_period_expect_illegal_argument_exception() {
        reportOnlineService.searchReportOnline(new Crop(), new HeadOffice(), null, new OperationalYear());
    }

    /**
     *
     */
    @Test(expected = IllegalArgumentException.class)
    public void test_search_report_online_with_null_operational_year_expect_illegal_argument_exception() {
        reportOnlineService.searchReportOnline(new Crop(), new HeadOffice(), new Date(), null);
    }

    /**
     *
     */
    @Test
    public void test_search_report_online_with_valid_filter_expected_rol_valid() {

        // Load database
        setupDBUnit();

        HeadOffice headOffice = (HeadOffice) getSession().get(HeadOffice.class, 900000004L);
        Crop crop = (Crop) getSession().get(Crop.class, 900000001L);
        OperationalYear operationalYear = (OperationalYear) getSession().get(OperationalYear.class, 900000007L);
        ReportOnLine rol = reportOnlineService.searchReportOnline(crop, headOffice, getRolPeriod(2012, 7, 1),
                operationalYear);
        Assert.assertNotNull("Expect a valid rol for this filter.", rol);
    }

    /**
     *
     */
    @Test
    public void test_select_All_rol_status() {

        // load database
        setupDBUnit();

        List<RolStatus> rolStatusList = rolInformationService.selectAllRolStatus();
        Assert.assertNotNull("Expected a non null rol status list.", rolStatusList);
        Assert.assertFalse("Expected at least one status on list.", rolStatusList.isEmpty());

    }

    /**
     * Check for a rol that never have been reported before, expected that start
     * period be start contract.
     * 
     * @throws ContractNotFoundException
     * 
     */
    @Test
    public void test_calculate_report_online_period_for_rol_never_reported_before() throws BusinessException {

        // Load database
        setupDBUnit();

        // Find headoffice and crop
        HeadOffice headOffice = (HeadOffice) getSession().get(HeadOffice.class, 900000003L);
        Assert.assertNotNull(headOffice);

        // Find contract
        Contract contract = (Contract) getSession().get(Contract.class, 900000001L);
        Assert.assertNotNull(contract);

        // Get period
        Date rolPeriod = CalendarUtil.getDate(2010, 1, 1);
        Assert.assertTrue("Head office must have vigor on rol period.", headOffice.checkVigor(rolPeriod));

        // Calculate a next period for rol
        ReportOnlinePeriodDTO period = reportOnlineService.calculateReportOnlinePeriod(headOffice.getId(), rolPeriod);
        Assert.assertNotNull("Expected a non null date.", period);
        Assert.assertNotNull("Operational years list must be not null.", period.getOperationalYears());

    }

    /**
     * @throws ReportOnlineException
     * 
     */
    @Test
    public void test_search_or_instanciate_report_online_with_valid_filter_expected_rol_valid()
            throws BusinessException {

        // Load database
        setupDBUnit();

        HeadOffice headOffice = (HeadOffice) getSession().get(HeadOffice.class, 900000004L);
        Crop crop = (Crop) getSession().get(Crop.class, 900000001L);
        OperationalYear operationalYear = (OperationalYear) getSession().get(OperationalYear.class, 900000007L);
        ReportOnLine rol = reportOnlineService.searchOrInstanciateReportOnline(crop, headOffice,
                getRolPeriod(2012, 7, 1), operationalYear);
        Assert.assertNotNull("Expect a valid rol for this filter.", rol);
        Assert.assertEquals("Expected rol with id 900000003.", new Long(900000003), rol.getId());
    }

    /**
     * @throws ReportOnlineException
     * 
     */
    @Test(expected = AffiliateNotInVigorException.class)
    public void test_search_or_instanciate_report_online_with_valid_filter_but_without_contracts_in_database_expected_contract_not_found_exception()
            throws BusinessException {

        // Load database
        setupDBUnit();

        // Build filter
        HeadOffice headOffice = (HeadOffice) getSession().get(HeadOffice.class, 900000002L);
        Crop crop = (Crop) getSession().get(Crop.class, 900000001L);
        OperationalYear operationalYear = (OperationalYear) getSession().get(OperationalYear.class, 900000007L);

        // Search report
        reportOnlineService
                .searchOrInstanciateReportOnline(crop, headOffice, getRolPeriod(2015, 5, 1), operationalYear);

    }

    /**
     * @throws ReportOnlineException
     * 
     */
    @Test
    public void test_search_or_instanciate_report_online_with_valid_filter_but_never_have_reported_before()
            throws BusinessException {

        // Load database
        setupDBUnit();

        // Load operational year
        loadOperationalYearOnDB("2012");

        // Build filters
        HeadOffice headOffice = (HeadOffice) getSession().get(HeadOffice.class, 900000003L);
        Assert.assertNotNull(headOffice);
        Crop crop = (Crop) getSession().get(Crop.class, 900000001L);
        Assert.assertNotNull(crop);

        // Load
        OperationalYear operationalYear = loadOperationalYearOnDB("2012");
        Assert.assertNotNull(operationalYear);

        // Rol period
        Date rolPeriod = getRolPeriod(operationalYear.getNumericalYear(), 7, 1);
        Assert.assertTrue("Affiliate must be in vigor on period.", headOffice.checkVigor(rolPeriod));

        // Setup rol configuration for rol (lowest rol date start when matrix
        // contract starts)
        Contract contract = headOffice.getMatrix().selectContractsInVigorBy(headOffice.getCompany(), crop,
                ParticipantTypeEnum.POD);
        RolConfiguration rolConfiguration = rolConfigurationService.selectRolConfiguration(crop,
                headOffice.getCompany());
        rolConfiguration.setLowestDate(CalendarUtil.getFirstDateOfMonth(contract.getStartDate()));
        saveAndFlush(rolConfiguration);

        // Search new rol
        ReportOnLine rol = reportOnlineService.searchOrInstanciateReportOnline(crop, headOffice, rolPeriod,
                operationalYear);

        // Check attributes
        Assert.assertNotNull("Expect a valid rol for this filter.", rol);
        Assert.assertNull("Rol must have id null, because never have been reported.", rol.getId());
        Assert.assertTrue("Next period for a rol never reported must be actual last month.",
                CalendarUtil.compareToPeriod(rol.getRolPeriod(), rolPeriod) == 0);
        Assert.assertNotNull("Expected a valida create date.", rol.getRolCreateDate());
        Assert.assertNotNull("Expected non-null operational year.", rol.getOperationalYear());
        Assert.assertEquals("Operational year must be 2010.", operationalYear.getNumericalYear(), rol
                .getOperationalYear().getNumericalYear());
        Assert.assertNotNull("Crop must be not null.", rol.getCrop());
        Assert.assertNotNull("Headoffice must be not null.", rol.getHeadoffice());
        Assert.assertNotNull("Rol status must be not null.", rol.getRolStatus());

        // Check parameters
        Assert.assertNotNull("Expected rol parameters.", rol.getUsedRolParameters());
        Assert.assertFalse("Expected non-empty parameters for rol.", rol.getUsedRolParameters().isEmpty());
        Assert.assertEquals("Expected only one parameter", 1, rol.getUsedRolParameters().size());
        Assert.assertNull("Used rol parameter must be null because its a new empty rol.", rol.getUsedRolParameters()
                .iterator().next().getUsedRolParameterId());

        // Check a valid parameter
        Long expectedRolParameterId = new Long(900000001);
        Assert.assertEquals("Expected rol parameter with id " + expectedRolParameterId, expectedRolParameterId, rol
                .getUsedRolParameters().iterator().next().getRolParameter().getId());

    }

    /**
     * @throws ReportOnlineException
     * @throws ReportOnLineConstraintException
     * 
     */
    @Test
    public void test_search_or_instanciate_report_online_with_valid_filter_for_rol_already_sent_with_gap()
            throws BusinessException {

        // Load database
        setupDBUnit();

        // Load operational year
        loadOperationalYearOnDB("2010");

        // Build filters
        HeadOffice headOffice = (HeadOffice) getSession().get(HeadOffice.class, 900000003L);
        Crop crop = (Crop) getSession().get(Crop.class, 900000001L);
        OperationalYear operationalYear = (OperationalYear) getSession().get(OperationalYear.class, 900000007L);

        // Setup rol configuration for rol (lowest rol date start when matrix
        // contract starts)
        Contract contract = headOffice.getMatrix().selectContractsInVigorBy(headOffice.getCompany(), crop,
                ParticipantTypeEnum.POD);
        RolConfiguration rolConfiguration = rolConfigurationService.selectRolConfiguration(crop,
                headOffice.getCompany());
        rolConfiguration.setLowestDate(CalendarUtil.getFirstDateOfMonth(contract.getStartDate()));
        saveAndFlush(rolConfiguration);

        // Search new rol
        ReportOnLine rol = reportOnlineService.searchOrInstanciateReportOnline(crop, headOffice,
                getRolPeriod(2010, 1, 1), operationalYear);

        // Check for state
        Assert.assertEquals("Expected reported status for rol", RolStatus.ROL_STATUS_REPORTED, rol.getRolStatus()
                .getRolStatusCode());

    }

    /**
     * @throws ReportOnlineException
     * @throws ContractNotFoundException
     * 
     */
    @Test
    public void test_search_or_instanciate_report_dto_online_with_valid_filter_but_never_have_reported_before()
            throws BusinessException {

        // Load database
        setupDBUnit();

        // Build filters
        HeadOffice headOffice = (HeadOffice) getSession().get(HeadOffice.class, 900000003L);
        Assert.assertNotNull(headOffice);
        Crop crop = (Crop) getSession().get(Crop.class, 900000001L);
        Assert.assertNotNull(crop);
        OperationalYear operationalYear = loadOperationalYearOnDB("2012");
        Assert.assertNotNull(operationalYear);

        // Rol Period
        Date rolPeriod = getRolPeriod(2012, 7, 1);

        // Setup rol configuration for rol (lowest rol date start world began)
        RolConfiguration rolConfiguration = rolConfigurationService.selectRolConfiguration(crop,
                headOffice.getCompany());
        rolConfiguration.setLowestDate(CalendarUtil.getDate(1000, 1));
        saveAndFlush(rolConfiguration);

        // Search new rol
        ReportOnlineDTO dto = reportOnlineService.searchOrInstanciateReportOnlineToDTO(crop, headOffice, rolPeriod,
                operationalYear);

        // Check attributes
        Assert.assertNotNull("Expect a valid rol for this filter.", dto);
        Assert.assertNull("Rol must have id null, because never have been reported.", dto.getReportOnline().getId());
        Assert.assertTrue("Next period for a rol never reported must be actual last month.",
                CalendarUtil.compareToPeriod(dto.getReportOnline().getRolPeriod(), rolPeriod) == 0);
        Assert.assertNotNull("Expected a valida create date.", dto.getReportOnline().getRolCreateDate());
        Assert.assertNotNull("Expected non-null operational year.", dto.getOperationalYear());
        Assert.assertEquals("Operational year must be year of start contract of matrix.",
                operationalYear.getNumericalYear(), dto.getOperationalYear().getNumericalYear());
        Assert.assertNotNull("Crop must be not null.", dto.getCrop());
        Assert.assertNotNull("Headoffice must be not null.", dto.getReportOnline().getHeadoffice());
        Assert.assertNotNull("Rol status must be not null.", dto.getReportOnline().getRolStatus());

        // Check parameters
        Assert.assertNotNull("Expected rol parameters.", dto.getReportOnline().getUsedRolParameters());
        Assert.assertFalse("Expected non-empty parameters for rol.", dto.getReportOnline().getUsedRolParameters()
                .isEmpty());
        Assert.assertEquals("Expected only one parameter", 1, dto.getReportOnline().getUsedRolParameters().size());
        Assert.assertNull("Used rol parameter must be null because its a new empty rol.", dto.getReportOnline()
                .getUsedRolParameters().iterator().next().getUsedRolParameterId());

        // Check a valid parameter
        Long expectedRolParameterId = new Long(900000001);
        Assert.assertEquals("Expected rol parameter with id " + expectedRolParameterId, expectedRolParameterId, dto
                .getReportOnline().getUsedRolParameters().iterator().next().getRolParameter().getId());

    }

    /**
     * @throws ReportOnLineNotFoundException
     * 
     */
    @Test(expected = IllegalArgumentException.class)
    public void test_update_report_online_with_all_null_parameters_expected_illegal_argument_exception()
            throws ReportOnLineNotFoundException {
        reportOnlineService.updateReportOnlineStatus(null, null, null, null, null);
    }

    /**
     * @throws ReportOnLineNotFoundException
     * 
     */
    @Test(expected = IllegalArgumentException.class)
    public void test_update_report_online_with_rol_null_parameters_expected_illegal_argument_exception()
            throws ReportOnLineNotFoundException {

        reportOnlineService
                .updateReportOnlineStatus(null, Boolean.TRUE, new RolStatus(), new Long(900000004), "_root_");
    }

    /**
     * @throws ReportOnLineNotFoundException
     * 
     */
    @Test(expected = IllegalArgumentException.class)
    public void test_update_report_online_with_participant_flag_null_parameters_expected_illegal_argument_exception()
            throws ReportOnLineNotFoundException {
        reportOnlineService.updateReportOnlineStatus(2L, null, new RolStatus(), new Long(900000004), "_root_");
    }

    /**
     * @throws ReportOnLineNotFoundException
     * 
     */
    @Test(expected = IllegalArgumentException.class)
    public void test_update_report_online_with_status_null_parameters_expected_illegal_argument_exception()
            throws ReportOnLineNotFoundException {
        reportOnlineService.updateReportOnlineStatus(2L, Boolean.FALSE, null, new Long(900000004), "_root_");
    }

    @Test(expected = IllegalArgumentException.class)
    public void test_update_report_online_with_null_itsuser_id_expected_illegal_argument_exception()
            throws ReportOnLineNotFoundException {

        reportOnlineService.updateReportOnlineStatus(-666L, Boolean.FALSE, new RolStatus(), null, "");
    }

    @Test(expected = IllegalArgumentException.class)
    public void test_update_report_online_with_null_itsuser_login_expected_illegal_argument_exception()
            throws ReportOnLineNotFoundException {

        reportOnlineService.updateReportOnlineStatus(-666L, Boolean.FALSE, new RolStatus(), new Long(1), null);
    }

    /**
     * @throws ReportOnLineNotFoundException
     * 
     */
    @Test(expected = ReportOnLineNotFoundException.class)
    public void test_update_report_online_with_status_invalid_rol_id_expected_report_online_not_found_expect()
            throws ReportOnLineNotFoundException {

        // load data base
        setupDBUnit();

        reportOnlineService.updateReportOnlineStatus(-666L, Boolean.FALSE,
                findStatusByCode(RolStatus.ROL_STATUS_PROCESSED), itsUser.getId(), itsUser.getLogin());
    }

    /**
     * @throws ReportOnLineNotFoundException
     * 
     */
    @Test
    public void test_update_report_online_with_valid_parameters_for_super_user_expected_sucess()
            throws ReportOnLineNotFoundException {

        // load data base
        setupDBUnit();

        // Find corrected status
        RolStatus newStatus = findStatusByCode(RolStatus.ROL_STATUS_CORRECTED);

        // Update rol
        reportOnlineService.updateReportOnlineStatus(900000001L, Boolean.FALSE, newStatus, itsUser.getId(),
                itsUser.getLogin());

        // Find rol
        ReportOnLine report = (ReportOnLine) getSession().get(ReportOnLine.class, 900000001L);

        // Check if this was updated
        Assert.assertEquals("Expected rol be updated for corrected status.", newStatus, report.getRolStatus());
    }

    /**
     * @throws ReportOnLineNotFoundException
     * 
     */
    @Test
    public void test_update_report_online_with_valid_parameters_for_participant_expected_sucess()
            throws ReportOnLineNotFoundException {

        // load data base
        setupDBUnit();

        // Find corrected status
        RolStatus newStatus = findStatusByCode(RolStatus.ROL_STATUS_CORRECTED);

        // Update rol
        reportOnlineService.updateReportOnlineStatus(900000001L, Boolean.TRUE, newStatus, itsUser.getId(),
                itsUser.getLogin());

        // Find rol
        ReportOnLine report = (ReportOnLine) getSession().get(ReportOnLine.class, 900000001L);

        // Check if this was updated
        Assert.assertEquals("Expected rol be updated for corrected status.", newStatus, report.getRolStatus());
    }

    /**
     * Find status by code
     * 
     * @param code
     * @return
     */
    private RolStatus findStatusByCode(final String code) {

        for (RolStatus status : rolInformationService.selectAllRolStatus()) {
            if (status.getRolStatusCode().equals(code)) {
                return status;
            }
        }

        return null;
    }

    /**
     * @throws ReportOnlineException
     * @throws ReportOnLineConstraintException
     * 
     */
    @Test(expected = IllegalArgumentException.class)
    public void test_send_report_online_with_null_report_expected_illegal_argument_exception() throws BusinessException {

        ReportOnLine rol = null;
        reportOnlineService.sendReportOnline(rol, null);

    }

    /**
     * @throws ReportOnlineException
     * @throws ReportOnLineConstraintException
     * 
     */
    @Test
    public void test_send_report_online_never_reported_before_expected_sucess() throws BusinessException {

        // Load database
        setupDBUnit();

        // Find a new report online that have dont been reported before (first
        // in contract)
        ReportOnLine reportOnLine = loadNewReportOnline(getRolPeriod(2012, 7, 1));

        BigDecimal value = new BigDecimal("666");

        // Update rol parameters values
        for (UsedRolParameter usedRolParameter : reportOnLine.getUsedRolParameters()) {
            usedRolParameter.setUsedRolParameterTonValue(value);
            usedRolParameter.setUsedRolParamMonetaryVal(value);
            usedRolParameter.setUsedRolParamStripeValue(value.longValue());
        }
        // set itsUser
        ItsUser user = userService.getUserBy("_root_").getCurrentUser();
        reportOnLine.setItsUserLogin(user.getLogin());
        // Save report
        ReportOnLineInfo rolInfo = new ReportOnLineInfo(Locale.US);
        reportOnLine = reportOnlineService.sendReportOnline(reportOnLine, rolInfo);

        // Find report
        ReportOnLine report = (ReportOnLine) getSession().get(ReportOnLine.class, reportOnLine.getPrimaryKey());
        Assert.assertEquals("Report online must be in RTV Analysis.", findStatusByCode(RolStatus.ROL_STATUS_RTV),
                report.getRolStatus());

        // Check if parameters values was updated
        for (UsedRolParameter usedRolParameter : report.getUsedRolParameters()) {
            Assert.assertEquals("Rol used parameter wasn't updated.", value,
                    usedRolParameter.getUsedRolParameterTonValue());
            Assert.assertEquals("Rol used parameter wasn't updated.", value,
                    usedRolParameter.getUsedRolParamMonetaryVal());
            Assert.assertEquals("Rol used parameter wasn't updated.", new Long(value.longValue()),
                    usedRolParameter.getUsedRolParamStripeValue());
        }
    }

    /**
     * @throws ReportOnlineException
     * @throws ReportOnLineConstraintException
     * 
     */
    @Test
    public void test_send_report_online_with_validated_usedRolParameters() throws BusinessException {

        // Load database
        setupDBUnit();

        // Find a new report online that have dont been reported before (first
        // in contract)
        ReportOnLine reportOnLine = loadNewReportOnline(getRolPeriod(2012, 7, 1));

        BigDecimal value = new BigDecimal("666");

        // Update rol parameters values
        for (UsedRolParameter usedRolParameter : reportOnLine.getUsedRolParameters()) {
            usedRolParameter.setUsedRolParameterTonValue(value);
            usedRolParameter.setUsedRolParamMonetaryVal(value);
            usedRolParameter.setUsedRolParamStripeValue(value.longValue());
        }
        // set itsUser
        ItsUser user = userService.getUserBy("_root_").getCurrentUser();
        reportOnLine.setItsUserLogin(user.getLogin());
        UsedRolParametersSpecification specif = new UsedRolParametersSpecification(reportOnLineByGrowerService);
        Assert.assertTrue(specif.isSatisfiedBy(reportOnLine));

    }

    /**
     * @return
     * @throws ReportOnlineException
     */
    private ReportOnLine loadNewReportOnline(final Date period) throws BusinessException {

        // Check if there a operational year 2010
        loadOperationalYearOnDB("2010");
        loadOperationalYearOnDB("2011");
        loadOperationalYearOnDB("2012");

        // Build filters
        HeadOffice headOffice = (HeadOffice) getSession().get(HeadOffice.class, 900000003L);
        Crop crop = (Crop) getSession().get(Crop.class, 900000001L);
        OperationalYear operationalYear = (OperationalYear) getSession().get(OperationalYear.class, 900000007L);

        // Search new rol
        return reportOnlineService.searchOrInstanciateReportOnline(crop, headOffice, period, operationalYear);
    }

    /**
     *
     */
    private OperationalYear loadOperationalYearOnDB(final String year) {
        try {

            // Check if there are 2011 year
            return companyService.getOperationalYearByCandidateKey(year);

        } catch (EntityNotFoundException e) {
            // Create operational year
            OperationalYear operationalYear = new OperationalYear(year);
            saveAndFlush(operationalYear);
            return operationalYear;
        }
    }

    /**
     * @throws ReportOnlineException
     * 
     */
    @Test(expected = IllegalArgumentException.class)
    public void test_search_report_online_consolidate_with_all_null_parameters_expected_illegal_argument_exception()
            throws ReportOnlineException {
        reportOnlineService.searchReportOnlineConsolidateToDTO(null, null, null, null, null);
    }

    /**
     * @throws ReportOnlineException
     * 
     */
    @Test
    public void test_search_report_online_consolidate_with_valid_filter_expected_success() throws ReportOnlineException {

        // Load db unit
        setupDBUnit();

        // Bild filter
        Crop crop = (Crop) getSession().get(Crop.class, 900000001L);
        Assert.assertNotNull(crop);
        Customer matrix = (Customer) getSession().get(Customer.class, 900000001L);
        Assert.assertNotNull(matrix);
        OperationalYear operationalYear = (OperationalYear) getSession().get(OperationalYear.class, 900000007L);
        Assert.assertNotNull(operationalYear);

        // Find head office
        HeadOffice headOffice = (HeadOffice) getSession().createCriteria(HeadOffice.class)
                .add(Restrictions.eq("matrix", matrix)).add(Restrictions.eq("customer", matrix))
                .add(Restrictions.eq("type", ParticipantTypeEnum.POD)).uniqueResult();

        // Find technologies
        Technology tech1 = (Technology) getSession().get(Technology.class, 900000001L);
        Assert.assertNotNull(tech1);
        Technology tech2 = (Technology) getSession().get(Technology.class, 900000003L);
        Assert.assertNotNull(tech2);

        // Search consolidate
        ReportOnlineDTO dto = reportOnlineService.searchReportOnlineConsolidateToDTO(crop, matrix,
                getRolPeriod(2012, 7, 10), operationalYear, headOffice);
        Assert.assertNotNull("Expected a not null dto.", dto);
        Assert.assertEquals("Expected 2 techonologies in list.", 2, dto.getListTechRol().size());

        // Check tech's
        for (TechnologyROL tec : dto.getListTechRol()) {

            Technology technology = tec.getTechnology();

            if (!technology.equals(tech1) && !technology.equals(tech2)) {

                Assert.fail("Invalid technology in list");

            } else {

                if (technology.equals(tech1)) {

                    Assert.assertEquals("Expected 1 item on test stripes list.", 1, tec.getListTestStrips().size());

                    // Check parameters repeated
                    checkRepeatedParameters(tec.getListTestStrips());

                    for (RolParameterDTO param : tec.getListTestStrips()) {
                        chekRolParamterDtoValues(param, new BigDecimal("4"), new BigDecimal("4"), 4L);
                    }

                    Assert.assertEquals("Expected 0 item on fixed paid list.", 0, tec.getListVolumeFixedPaidActual()
                            .size());

                    // Check parameters repeated
                    checkRepeatedParameters(tec.getListVolumeFixedPaidActual());

                    Assert.assertEquals("Expected 0 itens on volume fixed paid old list.", 0, tec
                            .getListVolumeFixedPaidOld().size());

                    // Check parameters repeated
                    checkRepeatedParameters(tec.getListVolumeFixedPaidOld());

                    Assert.assertEquals("Expected 2 itens on received volume list.", 2, tec.getListVolumeReceived()
                            .size());

                    // Check parameters repeated
                    checkRepeatedParameters(tec.getListVolumeReceived());

                    for (RolParameterDTO param : tec.getListVolumeReceived()) {

                        if (param.getRolParameter().getId().equals(new Long("900000001"))) {
                            chekRolParamterDtoValues(param, new BigDecimal("2"), new BigDecimal("2"), 2L);
                        }

                        else if (param.getRolParameter().getId().equals(new Long("900000002"))) {
                            chekRolParamterDtoValues(param, new BigDecimal("2"), new BigDecimal("2"), 2L);
                        }

                        else {
                            Assert.fail("Ops, parameter not mapped! Rol parameter id="
                                    + param.getRolParameter().getId());
                        }
                    }

                }

                if (technology.equals(tech2)) {

                    Assert.assertEquals("Expected 1 itens on test stripes list.", 1, tec.getListTestStrips().size());

                    // Check parameters repeated
                    checkRepeatedParameters(tec.getListTestStrips());

                    for (RolParameterDTO param : tec.getListTestStrips()) {
                        chekRolParamterDtoValues(param, new BigDecimal("3"), new BigDecimal("3"), 3L);
                    }

                    Assert.assertEquals("Expected 0 itens on fixed paid list.", 0, tec.getListVolumeFixedPaidActual()
                            .size());

                    Assert.assertEquals("Expected 0 itens on volume fixed paid old list.", 0, tec
                            .getListVolumeFixedPaidOld().size());

                    Assert.assertEquals("Expected 0 itens on received volume list.", 0, tec.getListVolumeReceived()
                            .size());

                }

            }
        }

    }

    private void checkRepeatedParameters(final List<RolParameterDTO> parameters) {

        if (parameters != null) {
            List<Long> checkedParameters = new ArrayList<Long>();
            for (RolParameterDTO dto : parameters) {

                if (checkedParameters.contains(dto.getRolParameter().getPrimaryKey())) {
                    Assert.fail("There parameters repeated in list. Rol parameter repeated: "
                            + dto.getRolParameter().getId());
                } else {
                    checkedParameters.add(dto.getRolParameter().getPrimaryKey());
                }

            }
        }

    }

    private void chekRolParamterDtoValues(final RolParameterDTO dto, final BigDecimal ton, final BigDecimal mon,
            final Long stripes) {
        Assert.assertNotNull(dto);
        Assert.assertEquals("Invalid ton value.", ton, dto.getUsedRolParameterTonValue());
        Assert.assertEquals("Invalid monetary value.", mon, dto.getUsedRolParamMonetaryVal());
        Assert.assertEquals("Invalid # stripes value.", stripes, dto.getUsedRolParamStripValue());

    }

    /**
     * @throws ReportOnlineException
     * 
     */
    @Test(expected = IllegalArgumentException.class)
    public void test_search_report_online_consolidate_with_null_crop__expected_illegal_argument_exception()
            throws ReportOnlineException {

        // Load db unit
        setupDBUnit();

        // Bild filter
        Customer matrix = (Customer) getSession().get(Customer.class, 0L);
        OperationalYear operationalYear = (OperationalYear) getSession().get(OperationalYear.class, 0L);

        // Search consolidate
        reportOnlineService.searchReportOnlineConsolidateToDTO(null, matrix, getRolPeriod(2010, 1, 1), operationalYear,
                null);

    }

    /**
     * @throws ReportOnlineException
     * 
     */
    @Test(expected = IllegalArgumentException.class)
    public void test_search_report_online_consolidate_with_null_matrix__expected_illegal_argument_exception()
            throws ReportOnlineException {

        // Load db unit
        setupDBUnit();

        // Bild filter
        Crop crop = (Crop) getSession().get(Crop.class, 0L);
        OperationalYear operationalYear = (OperationalYear) getSession().get(OperationalYear.class, 0L);

        // Search consolidate
        reportOnlineService.searchReportOnlineConsolidateToDTO(crop, null, getRolPeriod(2010, 1, 1), operationalYear,
                null);

    }

    /**
     * @throws ReportOnlineException
     * 
     */
    @Test(expected = IllegalArgumentException.class)
    public void test_search_report_online_consolidate_with_null_period__expected_illegal_argument_exception()
            throws ReportOnlineException {

        // Load db unit
        setupDBUnit();

        // Bild filter
        Crop crop = (Crop) getSession().get(Crop.class, 0L);
        Customer matrix = (Customer) getSession().get(Customer.class, 0L);
        OperationalYear operationalYear = (OperationalYear) getSession().get(OperationalYear.class, 0L);

        // Search consolidate
        reportOnlineService.searchReportOnlineConsolidateToDTO(crop, matrix, null, operationalYear, null);

    }

    /**
     * @throws ReportOnlineException
     * 
     */
    @Test(expected = IllegalArgumentException.class)
    public void test_search_report_online_consolidate_with_null_operational_year_expected_illegal_argument_exception()
            throws ReportOnlineException {

        // Load db unit
        setupDBUnit();

        // Bild filter
        Crop crop = (Crop) getSession().get(Crop.class, 0L);
        Customer matrix = (Customer) getSession().get(Customer.class, 0L);

        // Search consolidate
        reportOnlineService.searchReportOnlineConsolidateToDTO(crop, matrix, getRolPeriod(2010, 1, 1), null, null);

    }

    /**
     * 
     * @throws ReportOnLineNotFoundException
     * @throws ReportOnlineException
     */
    @Test(expected = IllegalArgumentException.class)
    public void delete_rol_by_id_null() throws ReportOnLineNotFoundException, ReportOnlineException {
        setupDBUnit();
        reportOnlineService.deleteReportOnline(null, false);
        Assert.fail("Deletion was executed which could not occur.");
    }

    /**
     * 
     * @throws ContractNotFoundException
     */
    @Test(expected = IllegalArgumentException.class)
    public void test_calculate_next_report_online_period_for_rol_never_reported_before_with_headoffice_null()
            throws BusinessException {

        // Calculate a next period for rol
        reportOnlineService.calculateReportOnlinePeriod(null, CalendarUtil.getDate(2010, 1, 1));

    }

    @Test
    public void search_counter_price_technology_and_period() throws RolParameterException, GrowerNotFoundException,
            UserNotFoundException, CustomerNotFoundException, CustomerNotAllowedException {

        // Load dbunit
        setupDBUnit();

        Crop crop = (Crop) getSession().get(Crop.class, 900000001L);// _SOJA_
        Technology tech = (Technology) getSession().get(Technology.class, 900000001L);// _INTACTA_

        CounterPriceFilter filter = new CounterPriceFilter();
        filter.setCrop(crop);
        filter.setTechnology(tech);
        filter.setCompany(crop.getCompany());

        Calendar cal = Calendar.getInstance();
        cal.clear();
        cal.set(Calendar.YEAR, 2012);
        cal.set(Calendar.MONTH, Calendar.JULY);
        filter.setPeriod(cal.getTime());

        // search for CounterPrice list
        List<CounterPrice> counterPriceList = rolInformationService.selectCounterPriceListByFilter(filter);

        // validate six here
        Assert.assertEquals("Only six items must be returned.", 8, counterPriceList.size());

        for (CounterPrice item : counterPriceList) {
            Assert.assertEquals("Technology must be _INTACTA_", "_INTACTA_", item.getTechnology().getDescription());
            Assert.assertTrue("Counter Price ids must be 999000002 or 999000003", item.getId() == null
                    || item.getId().longValue() == 999000002 || item.getId().longValue() == 999000003);
        }
    }

    @Test
    public void search_counter_price_filter_all() throws RolParameterException, GrowerNotFoundException,
            UserNotFoundException, CustomerNotFoundException, CustomerNotAllowedException {
        setupDBUnit();

        Crop crop = (Crop) getSession().get(Crop.class, new Long(900000001));// _SOJA_
        Technology tech = (Technology) getSession().get(Technology.class, new Long(900000001));// _INTACTA_
        ItsDistrict district = (ItsDistrict) getSession().get(ItsDistrict.class, new Long(900000000)); // DISTRICT
                                                                                                       // 1

        CounterPriceFilter filter = new CounterPriceFilter();
        filter.setCrop(crop);
        filter.setTechnology(tech);
        filter.setCompany(crop.getCompany());
        filter.setDistrict(district);
        filter.setRegion(district.getItsRegion());
        filter.setUnit(district.getItsUnity());

        Calendar cal = Calendar.getInstance();
        cal.clear();
        cal.set(2012, 6, 1); // July
        filter.setPeriod(cal.getTime());

        // search for CounterPrice list
        List<CounterPrice> counterPriceList = rolInformationService.selectCounterPriceListByFilter(filter);

        Assert.assertEquals("Only one item must be returned.", 2, counterPriceList.size());

        for (CounterPrice item : counterPriceList) {
            if (item.getId() != null) {
                Assert.assertTrue("Counter Price id must be 999000002", item.getId().longValue() == 999000002);
            }
        }
    }

    @Test
    public void search_counter_price_by_region_unity() throws RolParameterException, GrowerNotFoundException,
            UserNotFoundException, CustomerNotFoundException, CustomerNotAllowedException {
        setupDBUnit();

        Crop crop = (Crop) getSession().get(Crop.class, new Long(900000001));// _SOJA_
        Technology tech = (Technology) getSession().get(Technology.class, new Long(900000002));// _INTACTA
                                                                                               // EUA_
        ItsRegion region = (ItsRegion) getSession().get(ItsRegion.class, new Long(900000003)); // REGION
                                                                                               // 1
        ItsUnity unity = (ItsUnity) getSession().get(ItsUnity.class, new Long(999000005)); // UNITY
                                                                                           // 1

        CounterPriceFilter filter = new CounterPriceFilter();
        filter.setCrop(crop);
        filter.setTechnology(tech);
        filter.setCompany(crop.getCompany());
        filter.setRegion(region);
        filter.setUnit(unity);

        Calendar cal = Calendar.getInstance();
        cal.clear();
        cal.set(2012, 5, 1); // June
        filter.setPeriod(cal.getTime());

        // search for CounterPrice list
        List<CounterPrice> counterPriceList = rolInformationService.selectCounterPriceListByFilter(filter);

        Assert.assertEquals("Only 1 item must be returned.", 2, counterPriceList.size());

        for (CounterPrice item : counterPriceList) {
            if (item.getId() != null) {
                Assert.assertTrue("Counter Price id must be 999000004", item.getId().longValue() == 999000004);
            }
        }
    }

    @Test
    public void search_counter_price_by_unity() throws RolParameterException, GrowerNotFoundException,
            UserNotFoundException, CustomerNotFoundException, CustomerNotAllowedException {
        setupDBUnit();

        Crop crop = (Crop) getSession().get(Crop.class, new Long(900000001));// _SOJA_
        Technology tech = (Technology) getSession().get(Technology.class, new Long(900000002));// _INTACTA
                                                                                               // EUA_
        ItsUnity unity = (ItsUnity) getSession().get(ItsUnity.class, new Long(900000005)); // UNITY
                                                                                           // 1

        CounterPriceFilter filter = new CounterPriceFilter();
        filter.setCrop(crop);
        filter.setTechnology(tech);
        filter.setCompany(crop.getCompany());
        filter.setUnit(unity);

        Calendar cal = Calendar.getInstance();
        cal.clear();
        cal.set(2012, Calendar.SEPTEMBER, 14); // Setember
        filter.setPeriod(cal.getTime());

        // search for CounterPrice list
        List<CounterPrice> counterPriceList = rolInformationService.selectCounterPriceListByFilter(filter);

        Assert.assertEquals("Only 3 item must be returned.", 3, counterPriceList.size());

        for (CounterPrice item : counterPriceList) {
            if (item.getId() != null) {
                Assert.assertTrue("Counter Price id must be 999000005", item.getId().longValue() == 999000005);
            }
        }
    }

    @Test
    public void search_volume_of_bag_technology_and_period() throws RolParameterException, GrowerNotFoundException,
            UserNotFoundException, CustomerNotFoundException, CustomerNotAllowedException {
        setupDBUnit();

        Crop crop = (Crop) getSession().get(Crop.class, new Long(900000001));// _SOJA_
        Technology tech = (Technology) getSession().get(Technology.class, new Long(900000001));// _INTACTA_

        CounterPriceFilter filter = new CounterPriceFilter();
        filter.setCrop(crop);
        filter.setTechnology(tech);
        filter.setCompany(crop.getCompany());
        Calendar cal = Calendar.getInstance();
        cal.clear();
        cal.set(2012, 7, 1); // Aug
        filter.setPeriod(cal.getTime());

        // search for VolumeOfBag list
        VolumeOfBag volumeOfBagList = rolInformationService.selectVolumeOfBagByFilter(filter);

        Assert.assertEquals("Volume of Bag ids must be 999000001", new Long("999000001"), volumeOfBagList.getId());
    }

    @Test
    public void insert_volume_of_bag_counter_price() throws RolParameterException, GrowerNotFoundException,
            UserNotFoundException, CustomerNotFoundException, CustomerNotAllowedException {
        setupDBUnit();

        Crop crop = (Crop) getSession().get(Crop.class, new Long(900000001));// _SOJA_
        Technology tech = (Technology) getSession().get(Technology.class, new Long(900000002));// _INTACTA_
        ItsDistrict district = (ItsDistrict) getSession().get(ItsDistrict.class, new Long(900000004)); // DISTRICT
                                                                                                       // 1

        CounterPriceFilter cpFilter = new CounterPriceFilter();
        cpFilter.setCrop(crop);
        cpFilter.setTechnology(tech);
        cpFilter.setCompany(crop.getCompany());
        cpFilter.setDistrict(district);
        cpFilter.setRegion(district.getItsRegion());
        cpFilter.setUnit(district.getItsUnity());

        Calendar cal = Calendar.getInstance();
        cal.clear();
        cal.set(2012, Calendar.SEPTEMBER, 14); // Setember
        cpFilter.setPeriod(cal.getTime());

        // search for CounterPrice list
        List<CounterPrice> counterPriceList = rolInformationService.selectCounterPriceListByFilter(cpFilter);
        Assert.assertFalse(counterPriceList.isEmpty());

        CounterPriceFilter vbFilter = new CounterPriceFilter();
        vbFilter.setCrop(crop);
        vbFilter.setTechnology(tech);
        vbFilter.setCompany(crop.getCompany());
        vbFilter.setPeriod(cal.getTime());

        // search for VolumeOfBag list
        VolumeOfBag volumeOfBag = rolInformationService.selectVolumeOfBagByFilter(vbFilter);
        Assert.assertNotNull("Expected a non-null volume of bag by filter.", volumeOfBag);

        // Set volume
        volumeOfBag.setVolume(new BigDecimal("60"));

        ValueOfChrgByTon valueOfCBT = rolInformationService.selectValueOfChrgByTonByFilter(vbFilter);
        Assert.assertNotNull("Expected a non-null value of Charge by Ton by filter.", valueOfCBT);

        valueOfCBT.setValue(new BigDecimal(15));

        rolInformationService.saveCounterPrice(counterPriceList, volumeOfBag, valueOfCBT);
    }

    @Test
    public void select_rol_by_filter_only_heafoffice() throws BusinessException {
        setupDBUnit();
        Crop crop = (Crop) getSession().get(Crop.class, new Long(900000001));
        ReportOnLineFilter filter = new ReportOnLineFilter();
        filter.setCrop(crop);
        Company company = (Company) getSession().get(Company.class, new Long(990000002));
        filter.setCompany(company);
        Customer matrix = (Customer) getSession().get(Customer.class, new Long(900000002));
        filter.setMatrix(matrix);
        filter.setParticipantType(ParticipantTypeEnum.POD);
        Date rolPeriod = new Date();
        filter.setRolPeriod(rolPeriod);
        List<RolStatus> listRolStatus = new ArrayList<RolStatus>();
        RolStatus rolStatus = (RolStatus) getSession().get(RolStatus.class, new Long(2));
        listRolStatus.add(rolStatus);
        filter.setListRolStatus(listRolStatus);
        List<ReportOnLineSearchDTO> result = reportOnlineService.selectReportOnLineByFilter(filter);
        assertNotNull(result);
        assertEquals(0, result.size());
    }

    @Test(expected = IllegalArgumentException.class)
    public void expect_exception_report_filter_invalid_crop_is_null() throws BusinessException {
        ReportOnLineFilter filter = new ReportOnLineFilter();
        setupDBUnit();
        reportOnlineService.selectReportOnLineByFilter(filter);
    }

    @Test(expected = IllegalArgumentException.class)
    public void expect_exception_report_filter_is_null() throws BusinessException {
        setupDBUnit();
        reportOnlineService.selectReportOnLineByFilter(null);
    }

    @Test(expected = IllegalArgumentException.class)
    public void expect_exception_report_filter_invalid_company_is_null() throws BusinessException {
        setupDBUnit();
        ReportOnLineFilter filter = new ReportOnLineFilter();
        Crop crop = (Crop) getSession().get(Crop.class, new Long(900000001));
        filter.setCrop(crop);
        reportOnlineService.selectReportOnLineByFilter(filter);
    }

    @Test(expected = IllegalArgumentException.class)
    public void expect_exception_report_filter_invalid_matrix_and_district_is_null() throws BusinessException {
        setupDBUnit();
        ReportOnLineFilter filter = new ReportOnLineFilter();
        Crop crop = (Crop) getSession().get(Crop.class, new Long(900000001));
        filter.setCrop(crop);
        Company company = (Company) getSession().get(Company.class, new Long(990000002));
        filter.setCompany(company);
        reportOnlineService.selectReportOnLineByFilter(filter);
    }

    @Test(expected = IllegalArgumentException.class)
    public void expect_exception_report_filter_invalid_type_is_null() throws BusinessException {
        setupDBUnit();
        Crop crop = (Crop) getSession().get(Crop.class, new Long(900000001));
        ReportOnLineFilter filter = new ReportOnLineFilter();
        filter.setCrop(crop);
        Company company = (Company) getSession().get(Company.class, new Long(990000002));
        filter.setCompany(company);
        Customer matrix = (Customer) getSession().get(Customer.class, new Long(900000002));
        filter.setMatrix(matrix);
        reportOnlineService.selectReportOnLineByFilter(filter);
    }

    @Test(expected = IllegalArgumentException.class)
    public void expect_exception_report_filter_matrix_and_district_null() throws BusinessException {
        setupDBUnit();
        Crop crop = (Crop) getSession().get(Crop.class, new Long(900000001));
        ReportOnLineFilter filter = new ReportOnLineFilter();
        filter.setCrop(crop);
        Company company = (Company) getSession().get(Company.class, new Long(990000002));
        filter.setCompany(company);
        filter.setParticipantType(ParticipantTypeEnum.POD);
        Date rolPeriod = new Date();
        filter.setRolPeriod(rolPeriod);
        List<RolStatus> listRolStatus = new ArrayList<RolStatus>();
        RolStatus rolStatus = (RolStatus) getSession().get(RolStatus.class, new Long(900000001));
        listRolStatus.add(rolStatus);
        filter.setListRolStatus(listRolStatus);
        assertNotNull(reportOnlineService.selectReportOnLineByFilter(filter));
    }

    @Test
    public void expect_no_affiliates() throws BusinessException {
        setupDBUnit();
        Crop crop = (Crop) getSession().get(Crop.class, new Long(900000003));
        ReportOnLineFilter filter = new ReportOnLineFilter();
        filter.setCrop(crop);
        Company company = (Company) getSession().get(Company.class, new Long(990000002));
        filter.setCompany(company);
        Customer matrix = (Customer) getSession().get(Customer.class, new Long(900000004));
        filter.setMatrix(matrix);
        filter.setParticipantType(ParticipantTypeEnum.POD);
        Date rolPeriod = new Date();
        filter.setRolPeriod(rolPeriod);
        List<RolStatus> listRolStatus = new ArrayList<RolStatus>();
        RolStatus rolStatus = (RolStatus) getSession().get(RolStatus.class, new Long(900000001));
        listRolStatus.add(rolStatus);
        filter.setListRolStatus(listRolStatus);
        final int expectedNothing = 0;
        assertEquals(expectedNothing, reportOnlineService.selectReportOnLineByFilter(filter).size());
    }

    @Test
    public void select_rol_by_filter_only_heafoffice_with_affiliate_in_vigor() throws BusinessException {
        setupDBUnit();
        Crop crop = (Crop) getSession().get(Crop.class, new Long(900000001));
        ReportOnLineFilter filter = new ReportOnLineFilter();
        filter.setCrop(crop);
        Company company = (Company) getSession().get(Company.class, new Long(990000002));
        filter.setCompany(company);
        Customer matrix = (Customer) getSession().get(Customer.class, new Long(900000002));
        filter.setMatrix(matrix);
        filter.setParticipantType(ParticipantTypeEnum.POD);

        List<RolStatus> listRolStatus = new ArrayList<RolStatus>();
        RolStatus rolStatus = (RolStatus) getSession().get(RolStatus.class, new Long(2));
        listRolStatus.add(rolStatus);
        filter.setListRolStatus(listRolStatus);

        filter.setOnlyInVigorAffiliate(Boolean.TRUE);
        Date periodVigor = CalendarUtil.getDate(2012, 4, 10);// 10/05/2012
        filter.setPeriodVigor(periodVigor);

        List<ReportOnLineSearchDTO> result = reportOnlineService.selectReportOnLineByFilter(filter);
        assertNotNull(result);
    }

    @Test
    public void select_report_online_list_filter_null() {
        try {
            rolInformationService.selectReportOnLineList(null, 1, 1);
        } catch (IllegalArgumentException e) {
            Assert.assertNotNull("Exception shoud not be null.", e);
        }
    }

    @Test
    public void select_report_online_list_period_null() {
        try {
            ReportOnLineFilter filter = new ReportOnLineFilter();
            filter.setRolStatus(null);
            rolInformationService.selectReportOnLineList(filter, 1, 1);
        } catch (IllegalArgumentException e) {
            Assert.assertNotNull("Exception shoud not be null.", e);
        }
    }

    @Test
    public void select_report_online_list() {
        setupDBUnit();

        // Get the desired status
        RolStatus rolStatus = (RolStatus) getSession().get(RolStatus.class, new Long(3));

        // Get the ROLs grouped by period and headoffice
        ReportOnLineFilter filter = new ReportOnLineFilter();
        filter.setRolStatus(rolStatus);
        List<Object[]> listROL = rolInformationService.selectReportOnLineList(filter, 1, 10);

        // Assert the ROLs were found
        Assert.assertNotNull("The ROLs should exist.", listROL);
        Assert.assertEquals("The ROL numbers were different.", 2, listROL.size());
    }

    @Test
    public void select_report_online_DTO_list_with_ROL_no_consolidate() throws CustomerNotFoundException,
            EntityAlreadyExistException, EntityNotFoundException {
        setupDBUnitWithAffiliates();

        // Get the ROLs that belong to validated Matrixes
        List<ReportOnLine> listDTO = rolInformationService.selectROLConsolidate(RolStatus.ROL_STATUS_RELEASED,
                RolStatus.ROL_STATUS_REPORTED, null);

        // Assert the ROLs were found
        Assert.assertNotNull("The ROLs should exist.", listDTO);
        Assert.assertEquals("The ROL numbers were different.", 0, listDTO.size());
    }

    @Test
    public void select_report_online_DTO_list_with_ROL_billed_no_consolidate() throws CustomerNotFoundException,
            EntityAlreadyExistException, EntityNotFoundException {
        setupDBUnitWithAffiliates();

        // Get the ROLs that belong to validated Matrixes
        List<ReportOnLine> listDTO = rolInformationService.selectROLConsolidate(RolStatus.ROL_STATUS_PROCESSED, null,
                null);

        // Assert the ROLs were found
        Assert.assertNotNull("The ROLs should exist.", listDTO);
        Assert.assertEquals("The ROL numbers were different.", 0, listDTO.size());
    }

    @Test
    public void select_report_online_DTO_list_with_ROL_consolidate() throws CustomerNotFoundException,
            EntityAlreadyExistException, EntityNotFoundException {
        setupDBUnitWithAffiliates();

        // Get the ROL status and persist the ROL
        RolStatus rolStatus = rolInformationService.selectRolStatusByCode(RolStatus.ROL_STATUS_RELEASED);
        Assert.assertNotNull(rolStatus);

        // Prepare the information to persist the first ROL
        OperationalYear operationalYear = (OperationalYear) getSession().get(OperationalYear.class,
                new Long(900000007L));
        Crop crop = (Crop) getSession().get(Crop.class, new Long(900000001L));
        HeadOffice headoffice = (HeadOffice) getSession().get(HeadOffice.class, new Long(900000004L));
        Date period = CalendarUtil.getDate(2212, 5, 30);
        Company company = (Company) getSession().get(Company.class, 990000002L);

        ReportOnLine rol = new ReportOnLine();
        rol.setRolStatus(rolStatus);
        rol.setOperationalYear(operationalYear);
        rol.setCrop(crop);
        rol.setRolPeriod(period);
        rol.setHeadoffice(headoffice);
        rol.setRolCreateDate(period);
        saveAndFlush(rol);

        // Prepare the information to persist the second ROL with the another
        // different headoffice
        headoffice = (HeadOffice) getSession().get(HeadOffice.class, new Long(900000007L));

        rol = new ReportOnLine();
        rol.setRolStatus(rolStatus);
        rol.setOperationalYear(operationalYear);
        rol.setCrop(crop);
        rol.setRolPeriod(period);
        rol.setHeadoffice(headoffice);
        rol.setRolCreateDate(period);
        saveAndFlush(rol);

        // Get the ROLs DTO grouped by period and headoffice
        List<ReportOnLine> listDTO = rolInformationService.selectROLConsolidate(RolStatus.ROL_STATUS_RELEASED,
                RolStatus.ROL_STATUS_REPORTED, company);

        // Assert the ROLs were found
        Assert.assertNotNull("The ROLs should exist.", listDTO);
        Assert.assertEquals("The ROL numbers were different.", 2, listDTO.size());
    }

    @Test
    public void select_report_online_DTO_list_with_ROL_consolidate_processed() throws CustomerNotFoundException,
            EntityAlreadyExistException, EntityNotFoundException {
        setupDBUnitWithAffiliates();

        // Get the ROL status and persist the ROL
        RolStatus rolStatus = (RolStatus) getSession().get(RolStatus.class, new Long(4));
        List<RolStatus> lstRolStatus = rolInformationService.selectAllRolStatus();
        if (lstRolStatus != null && lstRolStatus.size() > 0) {
            for (RolStatus rolStatus2 : lstRolStatus) {
                if (RolStatus.ROL_STATUS_RELEASED.equals(rolStatus2.getRolStatusCode())) {
                    rolStatus = rolStatus2;
                    break;
                }
            }
        }

        // Prepare the information to persist the first ROL
        OperationalYear operationalYear = (OperationalYear) getSession().get(OperationalYear.class,
                new Long(900000007L));
        Crop crop = (Crop) getSession().get(Crop.class, new Long(900000001L));
        HeadOffice headoffice = (HeadOffice) getSession().get(HeadOffice.class, new Long(900000004L));
        Date period = CalendarUtil.getDate(2212, 5, 30);
        Company company = (Company) getSession().get(Company.class, 990000002L);

        ReportOnLine rol = new ReportOnLine();
        rol.setRolStatus(rolStatus);
        rol.setOperationalYear(operationalYear);
        rol.setCrop(crop);
        rol.setRolPeriod(period);
        rol.setHeadoffice(headoffice);
        rol.setRolCreateDate(period);
        saveAndFlush(rol);

        // Prepare the information to persist the second ROL with the another
        // different headoffice
        headoffice = null;
        headoffice = (HeadOffice) getSession().get(HeadOffice.class, new Long(900000007L));
        rol = new ReportOnLine();
        rol.setRolStatus(rolStatus);
        rol.setOperationalYear(operationalYear);
        rol.setCrop(crop);
        rol.setRolPeriod(period);
        rol.setHeadoffice(headoffice);
        rol.setRolCreateDate(period);
        saveAndFlush(rol);

        // Get the ROLs DTO grouped by period and headoffice
        List<ReportOnLine> listDTO = rolInformationService.selectROLConsolidate(RolStatus.ROL_STATUS_PROCESSED,
                RolStatus.ROL_STATUS_REPORTED, company);

        // Assert the ROLs were found
        Assert.assertNotNull("The ROLs should exist.", listDTO);
        Assert.assertEquals("The ROL numbers were different.", 0, listDTO.size());
    }

    @Test
    public void select_report_online_DTO_list_with_ROL_consolidate_partial() throws CustomerNotFoundException,
            EntityAlreadyExistException, EntityNotFoundException {

        setupDBUnitWithAffiliates();

        // Get the ROL status and persist the ROL
        RolStatus rolStatus = rolInformationService.selectRolStatusByCode(RolStatus.ROL_STATUS_RELEASED);
        Assert.assertNotNull(rolStatus);

        // Prepare the information to persist the first ROL
        OperationalYear operationalYear = (OperationalYear) getSession().get(OperationalYear.class,
                new Long(900000007L));
        Crop crop = (Crop) getSession().get(Crop.class, new Long(900000001L));
        HeadOffice headoffice = (HeadOffice) getSession().get(HeadOffice.class, new Long(900000004L));
        Date period = CalendarUtil.getDate(2212, 5, 30);
        Company company = (Company) getSession().get(Company.class, 990000002L);

        ReportOnLine rol = new ReportOnLine();
        rol.setRolStatus(rolStatus);
        rol.setOperationalYear(operationalYear);
        rol.setCrop(crop);
        rol.setRolPeriod(period);
        rol.setHeadoffice(headoffice);
        rol.setRolCreateDate(period);
        saveAndFlush(rol);

        RolStatus rolStatus3 = rolInformationService.selectRolStatusByCode(RolStatus.ROL_STATUS_RESERVED);
        Assert.assertNotNull(rolStatus3);

        // Prepare the information to persist the second ROL with the another
        // different headoffice
        headoffice = null;
        headoffice = (HeadOffice) getSession().get(HeadOffice.class, new Long(900000005L));
        rol = new ReportOnLine();
        rol.setRolStatus(rolStatus3);
        rol.setOperationalYear(operationalYear);
        rol.setCrop(crop);
        rol.setRolPeriod(period);
        rol.setHeadoffice(headoffice);
        rol.setRolCreateDate(period);
        saveAndFlush(rol);

        // Get the ROLs DTO grouped by period and headoffice
        List<ReportOnLine> listDTO = rolInformationService.selectROLConsolidate(RolStatus.ROL_STATUS_RELEASED,
                RolStatus.ROL_STATUS_REPORTED, company);

        // Assert the ROLs were found
        Assert.assertNotNull("The ROLs should exist.", listDTO);
        Assert.assertEquals("The ROL numbers were different.", 1, listDTO.size());
    }

    @Test
    public void select_report_online_DTO_list_with_ROL_no_consolidate_charge() throws BusinessException {
        setupDBUnitWithAffiliates();

        // Get the ROLs that belong to validated Matrixes
        List<ReportOnLine> listDTO = rolInformationService.selectROLConsolidateWithoutCharge(
                RolStatus.ROL_STATUS_RELEASED, RolStatus.ROL_STATUS_REPORTED, null);

        // Assert the ROLs were found
        Assert.assertNotNull("The ROLs should exist.", listDTO);
        Assert.assertEquals("The ROL numbers were different.", 0, listDTO.size());
    }

    @Test
    public void select_report_online_DTO_list_with_ROL_billed_no_consolidate_charge() throws BusinessException {
        setupDBUnitWithAffiliates();

        // Get the ROLs that belong to validated Matrixes
        List<ReportOnLine> listDTO = rolInformationService.selectROLConsolidateWithoutCharge(
                RolStatus.ROL_STATUS_PROCESSED, null, null);

        // Assert the ROLs were found
        Assert.assertNotNull("The ROLs should exist.", listDTO);
        Assert.assertEquals("The ROL numbers were different.", 0, listDTO.size());
    }

    @Test
    public void select_counter_price_by_rol() throws ReportOnLineNotFoundException {
        setupDBUnit();
        Technology technology = (Technology) getSession().get(Technology.class, new Long(900000001));
        HeadOffice headOffice = (HeadOffice) getSession().get(HeadOffice.class, 900000004L);
        Crop crop = (Crop) getSession().get(Crop.class, 900000001L);
        OperationalYear operationalYear = (OperationalYear) getSession().get(OperationalYear.class, 900000007L);
        ReportOnLine rol = reportOnlineService.searchReportOnline(crop, headOffice, getRolPeriod(2012, 7, 1),
                operationalYear);
        assertNotNull(rolInformationService.selectCounterPriceByRol(rol, technology));
        CounterPrice counterPriceByRol = rolInformationService.selectCounterPriceByRol(rol, technology);
        BigDecimal expectedResult = new BigDecimal(10);

        assertEquals(expectedResult, counterPriceByRol.getPrice().setScale(0));
    }

    @Test
    public void search_value_charge_by_ton_technology_and_period() throws RolParameterException,
            GrowerNotFoundException, UserNotFoundException, CustomerNotFoundException, CustomerNotAllowedException {
        setupDBUnit();

        Crop crop = (Crop) getSession().get(Crop.class, new Long(900000001));// _SOJA_
        Technology tech = (Technology) getSession().get(Technology.class, new Long(900000003));

        CounterPriceFilter filter = new CounterPriceFilter();
        filter.setCrop(crop);
        filter.setTechnology(tech);
        filter.setCompany(crop.getCompany());
        Calendar cal = Calendar.getInstance();
        cal.clear();
        cal.set(2012, 7, 1); // Aug
        filter.setPeriod(cal.getTime());

        ValueOfChrgByTon valueOfCBT = rolInformationService.selectValueOfChrgByTonByFilter(filter);

        Assert.assertEquals("Volume of Bag ids must be 999000002", new Long("999000002"), valueOfCBT.getId());

        // Teste com valores nulos IllegalArgumentException
        // Tech null
        filter.setTechnology(null);

        try {
            // lança exception IllegalArgumentException
            valueOfCBT = rolInformationService.selectValueOfChrgByTonByFilter(filter);
        } catch (Exception e) {
            Assert.assertTrue(e instanceof IllegalArgumentException);
        }

        // Crop null
        filter.setTechnology(tech);
        filter.setCrop(null);

        try {
            // lança exception IllegalArgumentException
            valueOfCBT = rolInformationService.selectValueOfChrgByTonByFilter(filter);
        } catch (Exception e) {
            Assert.assertTrue(e instanceof IllegalArgumentException);
        }

        // Period null
        filter.setCrop(crop);
        filter.setPeriod(null);

        try {
            // lança exception IllegalArgumentException
            valueOfCBT = rolInformationService.selectValueOfChrgByTonByFilter(filter);
        } catch (Exception e) {
            Assert.assertTrue(e instanceof IllegalArgumentException);
        }

        // Period null
        filter.setPeriod(cal.getTime());
        filter.setCompany(null);

        try {
            // lança exception IllegalArgumentException
            valueOfCBT = rolInformationService.selectValueOfChrgByTonByFilter(filter);
        } catch (Exception e) {
            Assert.assertTrue(e instanceof IllegalArgumentException);
        }

    }

    private RolJustification populateRolJustification(final ReportOnLine rol,
            final RolJustificationType rolJustificationType, final String justification) {
        RolJustification rolJustification = new RolJustification();
        if (justification != null) {
            Date rolJustificationDate = new Date();
            rolJustification.setItsUserLogin("CEBOLINHA");
            rolJustification.setReportOnLine(rol);
            rolJustification.setRolJustificationDate(rolJustificationDate);
            rolJustification.setRolJustificationMessage(justification);
            rolJustification.setRolJustificationType(rolJustificationType.toString());
        }
        return rolJustification;
    }

    @Test
    public void test_update_approval_rol_analisys_rtv_lower_variation() throws BusinessException {
        setupDBUnitUpdateRol();
        DbUnitHelper.setup("classpath:data/core/approval-email-dataset.xml");

        String justification = "APROVADO CONFORME CONVERSADO COM O CLIENTE";
        // Find rol Actual
        ReportOnLine reportOnLine = (ReportOnLine) getSession().get(ReportOnLine.class, new Long(910000006));

        // populate object RolJustification
        RolJustification rolJustification = populateRolJustification(reportOnLine, RolJustificationType.APPROVAL,
                justification);

        rolInfo.setRecipients(new ArrayList<String>());
        // updated status rol
        reportOnlineService.updateApprovalStatusRol(new Long(910000006), rolJustification, rolInfo);
        // Find rol
        ReportOnLine reportNew = (ReportOnLine) getSession().get(ReportOnLine.class, new Long(910000006));
        // Check if this was updated
        Assert.assertTrue("The new status rol will be released for billing.",
                RolStatus.ROL_STATUS_RELEASED.equals(reportNew.getRolStatus().getRolStatusCode()));

        // check that emails were NOT sent to GR (Second approving)
        Assert.assertTrue(rolInfo.getRecipients().size() == 0);
    }

    @Test
    public void test_update_approval_rol_analisys_rtv_greater_variation() throws BusinessException {
        // Load dbunit
        setupDBUnitUpdateRol();
        DbUnitHelper.setup("classpath:data/core/approval-email-dataset.xml");

        String justification = "APROVADO CONFORME CONVERSADO COM O CLIENTE";
        // Find rol Actual
        ReportOnLine reportOnLine = (ReportOnLine) getSession().get(ReportOnLine.class, new Long(910000001));

        // populate object RolJustification
        RolJustification rolJustification = populateRolJustification(reportOnLine, RolJustificationType.APPROVAL,
                justification);

        rolInfo.setRecipients(new ArrayList<String>());

        // updated status rol
        reportOnlineService.updateApprovalStatusRol(new Long(910000001), rolJustification, rolInfo);
        // Find rol
        ReportOnLine reportNew = (ReportOnLine) getSession().get(ReportOnLine.class, new Long(910000001));
        // Check if this was updated
        Assert.assertTrue("The new status rol will be Analysis GR.",
                RolStatus.ROL_STATUS_GR.equals(reportNew.getRolStatus().getRolStatusCode()));

        // check that emails were sent to GR (Second approving)
        Assert.assertTrue(rolInfo.getRecipients().size() > 0);
    }

    @Test
    public void test_update_approval_rol_analisys_gr() throws BusinessException {
        setupDBUnitUpdateRol();
        String justification = "";

        // Find rol Actual
        ReportOnLine reportOnLine = (ReportOnLine) getSession().get(ReportOnLine.class, new Long(910000002));

        // populate object RolJustification
        RolJustification rolJustification = populateRolJustification(reportOnLine, RolJustificationType.APPROVAL,
                justification);

        // updated status rol
        reportOnlineService.updateApprovalStatusRol(new Long(910000002L), rolJustification, rolInfo);
        // Find rol
        ReportOnLine report = (ReportOnLine) getSession().get(ReportOnLine.class, 910000002L);
        // Check if this was updated
        Assert.assertTrue("The new status rol will be released for billing.",
                RolStatus.ROL_STATUS_RELEASED.equals(report.getRolStatus().getRolStatusCode()));
    }

    @Test
    public void test_update_approval_rol_released_billing() throws BusinessException {
        setupDBUnitUpdateRol();
        String justification = "APROVADO CONFORME CONVERSADO COM O CLIENTE";

        // Find rol Actual
        ReportOnLine reportOnLine = (ReportOnLine) getSession().get(ReportOnLine.class, new Long(910000003));

        // populate object RolJustification
        RolJustification rolJustification = populateRolJustification(reportOnLine, RolJustificationType.APPROVAL,
                justification);
        // updated status rol
        reportOnlineService.updateApprovalStatusRol(new Long(910000003), rolJustification, rolInfo);
        // Find rol
        ReportOnLine report = (ReportOnLine) getSession().get(ReportOnLine.class, new Long(910000003));
        // Check if this was updated
        Assert.assertTrue("The new status rol will be processed.",
                RolStatus.ROL_STATUS_PROCESSED.equals(report.getRolStatus().getRolStatusCode()));
    }

    @Test
    public void test_update_reprove_rol_analisys_rtv() throws BusinessException {
        setupDBUnitUpdateRol();
        String justification = "REPROVADO CONFORME CONVERSADO COM O CLIENTE";

        // Find rol Actual
        ReportOnLine reportOnLine = (ReportOnLine) getSession().get(ReportOnLine.class, new Long(910000001));

        // populate object RolJustification
        RolJustification rolJustification = populateRolJustification(reportOnLine, RolJustificationType.DISAPPROVED,
                justification);

        // updated status rol
        reportOnlineService.updateDisapprovalRolStatusRol(new Long(910000001), rolJustification, rolInfo);
        // Find rol
        ReportOnLine report = (ReportOnLine) getSession().get(ReportOnLine.class, new Long(910000001));
        // Check if this was updated
        Assert.assertTrue("The new status rol will be corrected report.",
                RolStatus.ROL_STATUS_CORRECTED.equals(report.getRolStatus().getRolStatusCode()));
    }

    @Test
    @Ignore
    public void test_send_report_logs_from_corrected_to_rtv() throws BusinessException {
        setupDBUnitUpdateRol();

        ReportOnLine rol = takeRolInCorrectedStatus();
        // get logs
        List<RolLogDTO> logs = rolInformationService.selectRolLogById(rol.getId());
        Assert.assertTrue(logs.get(0).getRolStatus().getRolStatusCode().equals(RolStatus.ROL_STATUS_CORRECTED));
        rol.setRolPeriod(CalendarUtil.getDate(2013, 05));
        
        // change ton value for one parameter
        for (UsedRolParameter item : rol.getUsedRolParameters()) {
            item.getRolParameter().setRolParReqValidStripe(Boolean.TRUE);
            item.setUsedRolParameterTonValue(new BigDecimal(1000));
        }

        // Set vigor in head office
        setMatrixVigor(rol.getHeadoffice());

        // set itsUser in rol
        ItsUser user = userService.getUserBy("_root_").getCurrentUser();
        rol.setItsUserLogin(user.getLogin());
        reportOnlineService.sendReportOnline(rol, null);

        // get Logs again
        logs = rolInformationService.selectRolLogById(rol.getId());
        // check that exist logs
        Assert.assertTrue(logs.size() > 0);
        boolean statusWasUpdate = false;
        for (RolLogDTO item : logs) {
            if (item.getRolLogType().equals(RolLogTypeEnum.STATUS)
                    && item.getRolLogAction().equals(RolLogActionEnum.UPDATE)
                    && item.getRolStatus().getRolStatusCode().equals(RolStatus.ROL_STATUS_RTV)) {
                statusWasUpdate = true;
            }
        }
        Assert.assertTrue(statusWasUpdate);
    }

    /**
     * 
     */
    private void setMatrixVigor(HeadOffice headOffice) {

        Assert.assertNotNull(headOffice);

        // Build contract range
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.MONTH, -10);

        if (!headOffice.getMatrix().inVigorAndRol(headOffice.getCrop(), headOffice.getCompany(),
                ParticipantTypeEnum.POD)) {

            Contract contract = null;
            for (Contract c : headOffice.getMatrix().getContracts()) {

                if (c.getParticipantType().equals(ParticipantTypeEnum.POD) && c.getCrop().equals(headOffice.getCrop())
                        && c.getCompany().equals(headOffice.getCompany())) {
                    contract = c;
                    break;
                }

            }

            // Create contract
            if (contract == null) {
                contract = new Contract();
                contract.setCompany(headOffice.getCompany());
                contract.setCrop(headOffice.getCrop());
                contract.setCustomer(headOffice.getMatrix());
                contract.setParticipantType(ParticipantTypeEnum.POD);
                contract.setStartDate(calendar.getTime());
            }

            calendar.add(Calendar.MONTH, 20);
            contract.setEndDate(calendar.getTime());
            headOffice.getMatrix().addContract(contract);
            saveAndFlush(contract);
        }

        if (!headOffice.checkVigor(new Date())) {
            // Create head office detail
            HeadOfficeDetail headOfficeDetail;

            if (headOffice.getHeadOfficeDetail() == null) {
                headOfficeDetail = new HeadOfficeDetail();
                headOfficeDetail.setHeadoffice(headOffice);
                headOfficeDetail.setReportRol(Boolean.TRUE);
                headOfficeDetail.setShowParticipantInList(Boolean.FALSE);
                headOffice.setHeadOfficeDetail(headOfficeDetail);
                saveAndFlush(headOffice);
                saveAndFlush(headOfficeDetail);

            } else {
                headOfficeDetail = headOffice.getHeadOfficeDetail();
            }

            calendar = Calendar.getInstance();
            calendar.add(Calendar.MONTH, -10);

            // Set effective date
            HeadOfficeEffectiveDate effectiveDate = new HeadOfficeEffectiveDate();
            effectiveDate.setHeadOfficeDetail(headOfficeDetail);
            effectiveDate.setInitDate(calendar.getTime());

            // Set end of effective date like end of matrix contract
            calendar.add(Calendar.MONTH, 20);
            effectiveDate.setEndDate(calendar.getTime());
            headOfficeDetail.getHeadOfficeEffectiveDates().add(effectiveDate);
            saveAndFlush(effectiveDate);
            saveAndFlush(headOfficeDetail);

        }
    }

    private ReportOnLine takeRolInCorrectedStatus() throws ReportOnLineNotFoundException, EntityNotFoundException {
        String justification = "REPROVADO CONFORME CONVERSADO COM O CLIENTE";

        // Find rol Actual
        ReportOnLine reportOnLine = (ReportOnLine) getSession().get(ReportOnLine.class, new Long(910000001));

        // populate object RolJustification
        RolJustification rolJustification = populateRolJustification(reportOnLine, RolJustificationType.DISAPPROVED,
                justification);

        // updated status rol
        reportOnlineService.updateDisapprovalRolStatusRol(new Long(910000001), rolJustification, rolInfo);
        // Find rol
        ReportOnLine report = (ReportOnLine) getSession().get(ReportOnLine.class, new Long(910000001));
        // Check if this was updated
        Assert.assertTrue("The new status rol will be corrected report.",
                RolStatus.ROL_STATUS_CORRECTED.equals(report.getRolStatus().getRolStatusCode()));
        return report;
    }

    @Test
    public void test_update_reprove_rol_analisys_gr() throws BusinessException {
        setupDBUnitUpdateRol();
        String justification = "REPROVADO CONFORME CONVERSADO COM O CLIENTE";

        // Find rol Actual
        ReportOnLine reportOnLine = (ReportOnLine) getSession().get(ReportOnLine.class, new Long(910000002));

        // populate object RolJustification
        RolJustification rolJustification = populateRolJustification(reportOnLine, RolJustificationType.DISAPPROVED,
                justification);

        // updated status rol
        reportOnlineService.updateDisapprovalRolStatusRol(new Long(910000002), rolJustification, rolInfo);
        // Find rol
        ReportOnLine report = (ReportOnLine) getSession().get(ReportOnLine.class, new Long(910000002));
        // Check if this was updated
        Assert.assertTrue("The new status rol will be corrected report.",
                RolStatus.ROL_STATUS_CORRECTED.equals(report.getRolStatus().getRolStatusCode()));
    }

    @Test
    public void test_update_reprove_rol_released_billing() throws BusinessException {
        setupDBUnitUpdateRol();
        String justification = "REPROVADO CONFORME CONVERSADO COM O CLIENTE";

        // Find rol Actual
        ReportOnLine reportOnLine = (ReportOnLine) getSession().get(ReportOnLine.class, new Long(910000003));

        // populate object RolJustification
        RolJustification rolJustification = populateRolJustification(reportOnLine, RolJustificationType.DISAPPROVED,
                justification);
        // updated status rol
        reportOnlineService.updateDisapprovalRolStatusRol(new Long(910000003), rolJustification, rolInfo);
        // Find rol
        ReportOnLine report = (ReportOnLine) getSession().get(ReportOnLine.class, new Long(910000003));
        // Check if this was updated
        Assert.assertTrue("The new status rol will be corrected report.",
                RolStatus.ROL_STATUS_CORRECTED.equals(report.getRolStatus().getRolStatusCode()));
    }

    @Test
    public void test_update_reprove_rol_processed() throws BusinessException {
        setupDBUnitUpdateRol();
        String justification = "REPROVADO CONFORME CONVERSADO COM O CLIENTE";

        // Find rol Actual
        ReportOnLine reportOnLine = (ReportOnLine) getSession().get(ReportOnLine.class, new Long(910000004));

        // populate object RolJustification
        RolJustification rolJustification = populateRolJustification(reportOnLine, RolJustificationType.DISAPPROVED,
                justification);
        // updated status rol
        reportOnlineService.updateDisapprovalRolStatusRol(new Long(910000004), rolJustification, rolInfo);
        // Find rol
        ReportOnLine report = (ReportOnLine) getSession().get(ReportOnLine.class, new Long(910000004));
        // Check if this was updated
        Assert.assertTrue("The new status rol will be corrected report.",
                RolStatus.ROL_STATUS_CORRECTED.equals(report.getRolStatus().getRolStatusCode()));
    }

    /**
     *
     */
    @Test
    public void test_select_report_on_line_in_processed_state_by_affiliate_state() {

        // load db unit
        setupDBUnit();

        // Find crop
        // Crop crop = (Crop) getSession().get(Crop.class, 900000001L);
        OperationalYear operYear = (OperationalYear) getSession().get(OperationalYear.class, new Long(900000007));

        // Find matrix
        HeadOffice headOffice = (HeadOffice) getSession().get(HeadOffice.class, 900000004L);

        // Build filter
        ReportOnLineFilter filter = new ReportOnLineFilter();
        filter.setCrop(headOffice.getCrop());
        filter.setCompany(headOffice.getCompany());
        filter.setOperationalYear(operYear);
        filter.setMatrix(headOffice.getMatrix());
        filter.setInitDate(getRolPeriod(2012, 9, 1));
        filter.setEndDate(getRolPeriod(2012, 11, 1));
        filter.setAffiliateState(headOffice.getCustomer().getAddress().getState());

        // search for Rol list
        List<Long> rolList = reportOnlineService.selectReportOnLineIdInProcessedStateByFilter(filter);
        Assert.assertNotNull(rolList);
        Assert.assertFalse("Expected a non-empty list.", rolList.isEmpty());

        Assert.assertEquals("Only two items must be returned.", 2, rolList.size());

        // Check result
        for (Long id : rolList) {

            // Find rol
            ReportOnLine rol = (ReportOnLine) getSession().get(ReportOnLine.class, id);

            Assert.assertEquals(filter.getCrop(), rol.getCrop());
            Assert.assertEquals(filter.getCompany(), rol.getHeadoffice().getCompany());
            Assert.assertEquals(filter.getOperationalYear(), rol.getOperationalYear());
            Assert.assertEquals(filter.getMatrix(), rol.getHeadoffice().getMatrix());
            Assert.assertEquals(filter.getAffiliateState(), rol.getHeadoffice().getCustomer().getAddress().getState());
        }

    }

    /**
     *
     */
    @Test
    public void test_select_report_on_line_in_processed_state_by_affiliate_for_state_that_dont_have_any_rol_expected_empty_list() {

        // load db unit
        setupDBUnit();

        // Find crop
        // Crop crop = (Crop) getSession().get(Crop.class, 900000001L);
        OperationalYear operYear = (OperationalYear) getSession().get(OperationalYear.class, new Long(900000007));

        // Find matrix
        HeadOffice headOffice = (HeadOffice) getSession().get(HeadOffice.class, 900000004L);

        // Build filter
        ReportOnLineFilter filter = new ReportOnLineFilter();
        filter.setCrop(headOffice.getCrop());
        filter.setCompany(headOffice.getCompany());
        filter.setOperationalYear(operYear);
        filter.setMatrix(headOffice.getMatrix());
        filter.setInitDate(getRolPeriod(2012, 9, 1));
        filter.setEndDate(getRolPeriod(2012, 11, 1));

        // load a state ouf of filter
        filter.setAffiliateState((State) getSession().get(State.class, 900000001L));

        // search for Rol list
        List<Long> rolList = reportOnlineService.selectReportOnLineIdInProcessedStateByFilter(filter);
        Assert.assertNotNull(rolList);
        Assert.assertTrue("Expected a empty list.", rolList.isEmpty());

    }

    /**
     *
     */
    @Test
    public void test_select_report_on_line_in_processed_state_by_affiliate_state_and_city() {

        // load db unit
        setupDBUnit();

        // Find crop
        // Crop crop = (Crop) getSession().get(Crop.class, 900000001L);
        OperationalYear operYear = (OperationalYear) getSession().get(OperationalYear.class, new Long(900000007));

        // Find matrix
        HeadOffice headOffice = (HeadOffice) getSession().get(HeadOffice.class, 900000004L);

        // Build filter
        ReportOnLineFilter filter = new ReportOnLineFilter();
        filter.setCrop(headOffice.getCrop());
        filter.setCompany(headOffice.getCompany());
        filter.setOperationalYear(operYear);
        filter.setMatrix(headOffice.getMatrix());
        filter.setInitDate(getRolPeriod(2012, 9, 1));
        filter.setEndDate(getRolPeriod(2012, 11, 1));
        filter.setAffiliateState(headOffice.getCustomer().getAddress().getState());
        filter.setAffiliateCity(headOffice.getCustomer().getAddress().getCity());

        // search for Rol list
        List<Long> rolList = reportOnlineService.selectReportOnLineIdInProcessedStateByFilter(filter);
        Assert.assertNotNull(rolList);
        Assert.assertFalse("Expected a non-empty list.", rolList.isEmpty());

        Assert.assertEquals("Only two items must be returned.", 2, rolList.size());

        // Check result
        for (Long id : rolList) {

            // Find rol
            ReportOnLine rol = (ReportOnLine) getSession().get(ReportOnLine.class, id);

            Assert.assertEquals(filter.getCrop(), rol.getCrop());
            Assert.assertEquals(filter.getCompany(), rol.getHeadoffice().getCompany());
            Assert.assertEquals(filter.getOperationalYear(), rol.getOperationalYear());
            Assert.assertEquals(filter.getMatrix(), rol.getHeadoffice().getMatrix());
            Assert.assertEquals(filter.getAffiliateCity(), rol.getHeadoffice().getCustomer().getAddress().getCity());
            Assert.assertEquals(filter.getAffiliateState(), rol.getHeadoffice().getCustomer().getAddress().getState());
        }

    }

    /**
     *
     */
    @Test
    public void test_select_report_on_line_in_processed_state_by_affiliate_city() {

        // load db unit
        setupDBUnit();

        // Find crop
        // Crop crop = (Crop) getSession().get(Crop.class, 900000001L);
        OperationalYear operYear = (OperationalYear) getSession().get(OperationalYear.class, new Long(900000007));

        // Find matrix
        HeadOffice headOffice = (HeadOffice) getSession().get(HeadOffice.class, 900000004L);

        // Build filter
        ReportOnLineFilter filter = new ReportOnLineFilter();
        filter.setCrop(headOffice.getCrop());
        filter.setCompany(headOffice.getCompany());
        filter.setOperationalYear(operYear);
        filter.setMatrix(headOffice.getMatrix());
        filter.setInitDate(getRolPeriod(2012, 9, 1));
        filter.setEndDate(getRolPeriod(2012, 11, 1));
        filter.setAffiliateCity(headOffice.getCustomer().getAddress().getCity());

        // search for Rol list
        List<Long> rolList = reportOnlineService.selectReportOnLineIdInProcessedStateByFilter(filter);
        Assert.assertNotNull(rolList);
        Assert.assertFalse("Expected a non-empty list.", rolList.isEmpty());

        Assert.assertEquals("Only two items must be returned.", 2, rolList.size());

        // Check result
        for (Long id : rolList) {

            // Find rol
            ReportOnLine rol = (ReportOnLine) getSession().get(ReportOnLine.class, id);

            Assert.assertEquals(filter.getCrop(), rol.getCrop());
            Assert.assertEquals(filter.getCompany(), rol.getHeadoffice().getCompany());
            Assert.assertEquals(filter.getOperationalYear(), rol.getOperationalYear());
            Assert.assertEquals(filter.getMatrix(), rol.getHeadoffice().getMatrix());
            Assert.assertEquals(filter.getAffiliateCity(), rol.getHeadoffice().getCustomer().getAddress().getCity());
        }

    }

    /**
     *
     */
    @Test
    public void test_select_report_on_line_in_processed_state_by_invalid_affiliate_city() {

        // load db unit
        setupDBUnit();

        // Find crop
        // Crop crop = (Crop) getSession().get(Crop.class, 900000001L);
        OperationalYear operYear = (OperationalYear) getSession().get(OperationalYear.class, new Long(900000007));

        // Find matrix
        HeadOffice headOffice = (HeadOffice) getSession().get(HeadOffice.class, 900000004L);

        // Build filter
        ReportOnLineFilter filter = new ReportOnLineFilter();
        filter.setCrop(headOffice.getCrop());
        filter.setCompany(headOffice.getCompany());
        filter.setOperationalYear(operYear);
        filter.setMatrix(headOffice.getMatrix());
        filter.setInitDate(getRolPeriod(2012, 9, 1));
        filter.setEndDate(getRolPeriod(2012, 11, 1));

        // load city out of filter
        filter.setAffiliateCity((City) getSession().get(City.class, 900000003L));

        // search for Rol list
        List<Long> rolList = reportOnlineService.selectReportOnLineIdInProcessedStateByFilter(filter);
        Assert.assertNotNull(rolList);
        Assert.assertTrue("Expected non-empty list.", rolList.isEmpty());

    }

    /**
     * @throws ReportOnlineException
     * @throws ReportOnLineConstraintException
     * 
     */
    @Test(expected = IllegalArgumentException.class)
    public void test_send_report_online_after_billed_never_reported_before_expected_illegal_argument_exception()
            throws BusinessException {

        // Load database
        setupDBUnit();

        // Find a new report online that have dont been reported before (first
        // in contract)
        ReportOnLine reportOnLine = loadNewReportOnline(getRolPeriod(2012, 7, 1));

        // Save report after billed
        reportOnlineService.sendReportOnlineAfterBilledProcess(reportOnLine);

    }

    /**
     * @throws ReportOnlineException
     * @throws ReportOnLineConstraintException
     * @throws ReportOnLineNotFoundException
     * 
     */
    @Test(expected = IllegalStateException.class)
    public void test_send_report_online_after_billed_with_state_not_processed_before_expected_illegal_state_exception()
            throws BusinessException {

        // Load database
        setupDBUnit();

        // Find report in state RTV analisys
        ReportOnLine reportOnLine = (ReportOnLine) getSession().get(ReportOnLine.class, 900000001L);

        // Save report after billed
        reportOnlineService.sendReportOnlineAfterBilledProcess(reportOnLine);

    }

    /**
     * @throws ReportOnlineException
     * @throws ReportOnLineConstraintException
     * 
     */
    @Test
    public void test_send_report_online_after_billed_expected_success() throws BusinessException {

        // Load database
        setupDBUnit();

        // Find report in state RTV analisys
        ReportOnLine reportOnLine = (ReportOnLine) getSession().get(ReportOnLine.class, 900000001L);
        reportOnLine.setItsUserLogin(itsUser.getLogin());

        // Update to processed
        reportOnLine.setRolStatus(findStatusByCode(RolStatus.ROL_STATUS_PROCESSED));

        // Update all parameters to 666, no one parameter can be changed!
        for (UsedRolParameter p : reportOnLine.getUsedRolParameters()) {

            // Set material sap code, this mean that paramter cannot be change
            p.getRolParameter().setRolParameterMaterialSapId("xxx");
            saveAndFlush(p.getRolParameter());

            // Illegal update values, to check
            p.setUsedRolParameterTonValue(new BigDecimal(666L));
            p.setUsedRolParamMonetaryVal(new BigDecimal(666L));
            p.setUsedRolParamStripeValue(666L);
        }

        // Save report
        reportOnlineService.sendReportOnlineAfterBilledProcess(reportOnLine);

        // Find report
        ReportOnLine report = (ReportOnLine) getSession().get(ReportOnLine.class, reportOnLine.getPrimaryKey());
        Assert.assertEquals("Report online must be in Processed state.",
                findStatusByCode(RolStatus.ROL_STATUS_PROCESSED), report.getRolStatus());
        Assert.assertTrue("Report must be flagged like updated after billed.", report.getRolUpdatedAfterBilled());

        // Check if some parameter have been updated
        for (UsedRolParameter p : report.getUsedRolParameters()) {
            Assert.assertTrue("Paramter must be not changed.",
                    !p.getUsedRolParameterTonValue().equals(new BigDecimal(666L)));
            Assert.assertTrue("Paramter must be not changed.",
                    !p.getUsedRolParamMonetaryVal().equals(new BigDecimal(666L)));
            Assert.assertTrue("Paramter must be not changed.", !p.getUsedRolParamStripeValue().equals(666L));
        }

    }

    /**
     * @throws ReportOnlineException
     * @throws ReportOnLineConstraintException
     * 
     */
    @Test
    public void test_send_report_online_after_billed_check_for_update_parameters_expected_success()
            throws BusinessException {

        // Load database
        setupDBUnit();

        // Find report in state RTV analisys
        ReportOnLine reportOnLine = (ReportOnLine) getSession().get(ReportOnLine.class, 900000001L);
        reportOnLine.setItsUserLogin(itsUser.getLogin());

        // Update to processed
        reportOnLine.setRolStatus(findStatusByCode(RolStatus.ROL_STATUS_PROCESSED));

        // Update all parameters to 666
        for (UsedRolParameter p : reportOnLine.getUsedRolParameters()) {

            // Set material sap code, this mean that paramter must be changed
            p.getRolParameter().setRolParameterMaterialSapId(null);
            saveAndFlush(p.getRolParameter());

            // Illegal update values, to check
            p.setUsedRolParameterTonValue(new BigDecimal(666L));
            p.setUsedRolParamMonetaryVal(new BigDecimal(666L));
            p.setUsedRolParamStripeValue(666L);
        }

        // Save report
        reportOnlineService.sendReportOnlineAfterBilledProcess(reportOnLine);

        // Find report
        ReportOnLine report = (ReportOnLine) getSession().get(ReportOnLine.class, reportOnLine.getPrimaryKey());
        Assert.assertEquals("Report online must be in Processed state.",
                findStatusByCode(RolStatus.ROL_STATUS_PROCESSED), report.getRolStatus());
        Assert.assertTrue("Report must be flagged like updated after billed.", report.getRolUpdatedAfterBilled());

        // Check if some parameter have been updated
        for (UsedRolParameter p : report.getUsedRolParameters()) {
            Assert.assertTrue("Paramter must be changed.", p.getUsedRolParameterTonValue().equals(new BigDecimal(666L)));
            Assert.assertTrue("Paramter must be changed.", p.getUsedRolParamMonetaryVal().equals(new BigDecimal(666L)));
            Assert.assertTrue("Paramter must be changed.", p.getUsedRolParamStripeValue().equals(666L));
        }

    }

    /**
     * @throws CustomerNotFoundException
     */
    @Test(expected = IllegalArgumentException.class)
    public void test_select_report_on_line_DTO_list_period_with_empty_filter_expected_illegal_argument_exception()
            throws CustomerNotFoundException {

        rolInformationService.selectReportOnLineDTOListPeriod(null, new ReportOnLineFilter());
    }

    /**
     * @throws CustomerNotFoundException
     */
    @Test(expected = IllegalArgumentException.class)
    public void test_select_report_on_line_DTO_list_period_with_crop_empty_filter_expected_illegal_argument_exception()
            throws CustomerNotFoundException {

        ReportOnLineFilter filter = new ReportOnLineFilter();
        filter.setCompany(new Company());

        rolInformationService.selectReportOnLineDTOListPeriod(null, filter);
    }

    /**
     * @throws CustomerNotFoundException
     */
    @Test(expected = IllegalArgumentException.class)
    public void test_select_report_on_line_DTO_list_period_with_company_empty_filter_expected_illegal_argument_exception()
            throws CustomerNotFoundException {

        ReportOnLineFilter filter = new ReportOnLineFilter();
        filter.setCrop(new Crop());

        rolInformationService.selectReportOnLineDTOListPeriod(null, filter);
    }

    /**
     * @throws CustomerNotFoundException
     */
    @Test(expected = IllegalArgumentException.class)
    public void test_select_report_on_line_DTO_list_period_with_null_filter_expected_illegal_argument_exception()
            throws CustomerNotFoundException {

        rolInformationService.selectReportOnLineDTOListPeriod(null, null);
    }

    /**
     * 
     * @throws CustomerNotFoundException
     */
    @Test(expected = IllegalArgumentException.class)
    public void select_missing_report_online_by_filter_filter_is_null() throws BusinessException {
        // filter null
        reportOnlineService.selectMissingReportOnLineByFilter(null);
    }

    /**
     * 
     * @throws CustomerNotFoundException
     */
    @Test(expected = IllegalArgumentException.class)
    public void select_missing_report_online_by_filter_company_is_null() throws BusinessException {
        ReportOnLineFilter filter = new ReportOnLineFilter();
        Crop crop = (Crop) getSession().get(Crop.class, new Long(900000001));
        filter.setCrop(crop);
        Date initDate = CalendarUtil.getDateNow();
        Date endDate = CalendarUtil.getDateNow();
        filter.setInitDate(initDate);
        filter.setEndDate(endDate);
        reportOnlineService.selectMissingReportOnLineByFilter(filter);
    }

    /**
     * 
     * @throws CustomerNotFoundException
     */
    @Test(expected = IllegalArgumentException.class)
    public void select_missing_report_online_by_filter_crop_is_null() throws BusinessException {
        ReportOnLineFilter filter = new ReportOnLineFilter();
        Company company = (Company) getSession().get(Company.class, new Long(990000002));
        filter.setCompany(company);
        Date initDate = CalendarUtil.getDateNow();
        Date endDate = CalendarUtil.getDateNow();
        filter.setInitDate(initDate);
        filter.setEndDate(endDate);
        reportOnlineService.selectMissingReportOnLineByFilter(filter);

    }

    /**
     * 
     * @throws CustomerNotFoundException
     */
    @Test(expected = IllegalArgumentException.class)
    public void select_missing_report_online_by_filter_period_is_null() throws BusinessException {
        ReportOnLineFilter filter = new ReportOnLineFilter();
        Company company = (Company) getSession().get(Company.class, new Long(990000002));
        Crop crop = (Crop) getSession().get(Crop.class, new Long(900000001));
        filter.setCrop(crop);
        filter.setCompany(company);

        reportOnlineService.selectMissingReportOnLineByFilter(filter);

    }

    /**
     * 
     * @throws CustomerNotFoundException
     */
    @Test
    public void select_missing_report_online_by_filter_only_heafoffice() throws BusinessException {
        setupDBUnit();

        Crop crop = (Crop) getSession().get(Crop.class, new Long(900000001));
        ReportOnLineFilter filter = new ReportOnLineFilter();

        filter.setCrop(crop);
        Company company = (Company) getSession().get(Company.class, new Long(990000002));
        filter.setCompany(company);

        Customer matrix = (Customer) getSession().get(Customer.class, new Long(900000002));
        filter.setMatrix(matrix);
        filter.setParticipantType(ParticipantTypeEnum.POD);

        Date initDate = CalendarUtil.getDate(2011, 01, 12);
        Date endDate = CalendarUtil.getDate(2012, 10, 21);
        filter.setInitDate(initDate);
        filter.setEndDate(endDate);

        List<MissingReportOnlineView> result = reportOnlineService.selectMissingReportOnLineByFilter(filter);
        assertNotNull(result);
        Assert.assertTrue("Expected non empty list.", !result.isEmpty());
    }

    /**
     * 
     * @throws CustomerNotFoundException
     */
    @Test
    public void select_missing_report_online_by_filter_only_Affiliate() throws BusinessException {
        setupDBUnit();

        Crop crop = (Crop) getSession().get(Crop.class, new Long(900000001));
        ReportOnLineFilter filter = new ReportOnLineFilter();

        filter.setCrop(crop);
        Company company = (Company) getSession().get(Company.class, new Long(990000002));
        filter.setCompany(company);

        Customer affiliate = (Customer) getSession().get(Customer.class, new Long(900000002));
        filter.setCustomer(affiliate);
        filter.setParticipantType(ParticipantTypeEnum.POD);

        Date initDate = CalendarUtil.getDate(2011, 01, 12);
        Date endDate = CalendarUtil.getDate(2012, 10, 21);
        filter.setInitDate(initDate);
        filter.setEndDate(endDate);

        List<MissingReportOnlineView> result = reportOnlineService.selectMissingReportOnLineByFilter(filter);
        assertNotNull(result);
        Assert.assertTrue("Expected non empty list.", !result.isEmpty());
    }

    /**
     * 
     * @throws CustomerNotFoundException
     */
    @Test
    public void select_missing_report_online_by_filter_headoffice_with_unity() throws BusinessException {
        setupDBUnit();

        Crop crop = (Crop) getSession().get(Crop.class, new Long(900000001));
        ReportOnLineFilter filter = new ReportOnLineFilter();

        filter.setCrop(crop);
        Company company = (Company) getSession().get(Company.class, new Long(990000002));
        filter.setCompany(company);

        Customer matrix = (Customer) getSession().get(Customer.class, new Long(900000002));
        filter.setMatrix(matrix);
        filter.setParticipantType(ParticipantTypeEnum.POD);

        ItsUnity unity = (ItsUnity) getSession().get(ItsUnity.class, new Long(999000005)); // UNITY
        filter.setUnity(unity);

        ItsRegion region = (ItsRegion) getSession().get(ItsRegion.class, new Long(900000003)); // REGION
        filter.setRegion(region);

        ItsDistrict district = (ItsDistrict) getSession().get(ItsDistrict.class, new Long(900000000)); // DISTRICT
        filter.setDistrict(district);

        Date initDate = CalendarUtil.getDate(2011, 01, 12);
        Date endDate = CalendarUtil.getDate(2012, 10, 21);
        filter.setInitDate(initDate);
        filter.setEndDate(endDate);

        List<MissingReportOnlineView> result = reportOnlineService.selectMissingReportOnLineByFilter(filter);
        assertNotNull(result);
    }

    /**
     * 
     * @throws CustomerNotFoundException
     */
    @Test
    public void select_missing_report_online_by_filter_Affiliate_with_unity() throws BusinessException {
        setupDBUnit();

        Crop crop = (Crop) getSession().get(Crop.class, new Long(900000001));
        ReportOnLineFilter filter = new ReportOnLineFilter();

        filter.setCrop(crop);
        Company company = (Company) getSession().get(Company.class, new Long(990000002));
        filter.setCompany(company);

        Customer affiliate = (Customer) getSession().get(Customer.class, new Long(900000002));
        filter.setCustomer(affiliate);
        filter.setParticipantType(ParticipantTypeEnum.POD);

        filter.setCommercialHierType(commercialHierarchyService.findCommercialHierType(CommercialHierarchyType.POD
                .toString()));

        ItsUnity unity = (ItsUnity) getSession().get(ItsUnity.class, new Long(999000005)); // UNITY
        filter.setCustomerUnity(unity);

        ItsRegion region = (ItsRegion) getSession().get(ItsRegion.class, new Long(900000003)); // REGION
        filter.setCustomerRegion(region);

        ItsDistrict district = (ItsDistrict) getSession().get(ItsDistrict.class, new Long(900000000)); // DISTRICT
        filter.setCustomerDistrict(district);

        filter.setDescription("AGRO");

        Date initDate = CalendarUtil.getDate(2011, 01, 12);
        Date endDate = CalendarUtil.getDate(2012, 10, 21);
        filter.setInitDate(initDate);
        filter.setEndDate(endDate);

        List<MissingReportOnlineView> result = reportOnlineService.selectMissingReportOnLineByFilter(filter);
        assertNotNull(result);
    }

    /**
     * @throws BusinessException
     * 
     */
    @Test(expected = IllegalArgumentException.class)
    public void test_disapproval_without_justification_expected_illegal_argument_exception() throws BusinessException {
        setupDBUnitUpdateRol();
        reportOnlineService.updateDisapprovalRolStatusRol(new Long(910000001), null, rolInfo);
    }

    /**
     * @throws BusinessException
     * 
     */
    @Test(expected = IllegalArgumentException.class)
    public void test_approval_without_justification_expected_illegal_argument_exception() throws BusinessException {
        setupDBUnitUpdateRol();
        reportOnlineService.updateApprovalStatusRol(910000006L, null, rolInfo);
    }

    /**
     * @throws CustomerNotFoundException
     */
    @Test
    public void select_missing_report_online_by_filter_affiliate_not_vigor() throws BusinessException {

        // load data base
        setupDBUnit();

        ReportOnLineFilter filter = new ReportOnLineFilter();

        // Get crop
        Crop crop = (Crop) getSession().get(Crop.class, new Long(900000001));
        Assert.assertNotNull(crop);
        filter.setCrop(crop);

        // Get company
        Company company = (Company) getSession().get(Company.class, new Long(990000002));
        Assert.assertNotNull(company);
        filter.setCompany(company);

        // Get affiliate
        Customer affiliate = (Customer) getSession().get(Customer.class, new Long(900000002));
        Assert.assertNotNull(affiliate);
        filter.setCustomer(affiliate);

        // Get matrix
        Customer matrix = (Customer) getSession().get(Customer.class, new Long(900000001));
        Assert.assertNotNull(matrix);
        filter.setMatrix(matrix);

        // Set type
        filter.setParticipantType(ParticipantTypeEnum.POD);

        Date initDate = CalendarUtil.getDate(2011, 01, 12);
        Date endDate = CalendarUtil.getDate(2012, 10, 21);
        filter.setInitDate(initDate);
        filter.setEndDate(endDate);

        // Remove headoffice vigor
        HeadOffice headOffice = (HeadOffice) getSession().get(HeadOffice.class, 900000004L);
        Assert.assertNotNull(headOffice);

        // Check for valid head office
        Assert.assertEquals(matrix, headOffice.getMatrix());
        Assert.assertEquals(affiliate, headOffice.getCustomer());
        Assert.assertNotNull(headOffice.getHeadOfficeDetail());

        // remove vigor periods
        headOffice.getHeadOfficeDetail().setReportRol(Boolean.FALSE);
        saveAndFlush(headOffice.getHeadOfficeDetail());

        // Search
        List<MissingReportOnlineView> result = reportOnlineService.selectMissingReportOnLineByFilter(filter);
        assertNotNull(result);
        Assert.assertTrue("Expected a empty list. But found: " + result.size(), result.isEmpty());
    }

    @Test
    public void select_missing_report_online_by_filter_affiliate_vigor() throws BusinessException {
        setupDBUnit();

        Crop crop = (Crop) getSession().get(Crop.class, new Long(900000001));
        ReportOnLineFilter filter = new ReportOnLineFilter();

        filter.setCrop(crop);
        Company company = (Company) getSession().get(Company.class, new Long(990000002));
        filter.setCompany(company);

        Customer affiliate = (Customer) getSession().get(Customer.class, new Long(900000005));
        filter.setCustomer(affiliate);

        Customer matrix = (Customer) getSession().get(Customer.class, new Long(900000001));
        filter.setMatrix(matrix);

        filter.setParticipantType(ParticipantTypeEnum.POD);

        Date initDate = CalendarUtil.getDate(2011, 01, 12);
        Date endDate = CalendarUtil.getDate(2012, 10, 21);
        filter.setInitDate(initDate);
        filter.setEndDate(endDate);

        // Remove headoffice vigor
        HeadOffice headOffice = (HeadOffice) getSession().get(HeadOffice.class, 900000007L);
        Assert.assertNotNull(headOffice);

        // Check for valid head office
        Assert.assertEquals(matrix, headOffice.getMatrix());
        Assert.assertEquals(affiliate, headOffice.getCustomer());
        Assert.assertNotNull(headOffice.getHeadOfficeDetail());

        // Set vigor periods
        headOffice.getHeadOfficeDetail().setReportRol(Boolean.TRUE);
        saveAndFlush(headOffice.getHeadOfficeDetail());

        List<MissingReportOnlineView> result = reportOnlineService.selectMissingReportOnLineByFilter(filter);
        assertNotNull(result);
        Assert.assertFalse("Expected a non empty list.", result.isEmpty());
    }

    @Test
    public void select_missing_report_online_by_filter_matrix_not_vigor() throws BusinessException {
        setupDBUnit();

        Crop crop = (Crop) getSession().get(Crop.class, new Long(900000001));
        ReportOnLineFilter filter = new ReportOnLineFilter();

        filter.setCrop(crop);
        Company company = (Company) getSession().get(Company.class, new Long(990000002));
        filter.setCompany(company);

        Customer affiliate = (Customer) getSession().get(Customer.class, new Long(900000008));
        filter.setCustomer(affiliate);

        Customer matrix = (Customer) getSession().get(Customer.class, new Long(900000008));
        filter.setMatrix(matrix);

        filter.setParticipantType(ParticipantTypeEnum.POD);

        Date initDate = CalendarUtil.getDate(2011, 01, 12);
        Date endDate = CalendarUtil.getDate(2012, 10, 21);
        filter.setInitDate(initDate);
        filter.setEndDate(endDate);

        List<MissingReportOnlineView> result = reportOnlineService.selectMissingReportOnLineByFilter(filter);
        assertNotNull(result);
        Assert.assertTrue(result.size() == 0);
    }

    @Test
    public void select_missing_report_online_by_filter_matrix_vigor() throws BusinessException {
        setupDBUnit();

        Crop crop = (Crop) getSession().get(Crop.class, new Long(900000001));
        ReportOnLineFilter filter = new ReportOnLineFilter();

        filter.setCrop(crop);
        Company company = (Company) getSession().get(Company.class, new Long(990000002));
        filter.setCompany(company);

        Customer affiliate = (Customer) getSession().get(Customer.class, new Long(900000002));
        filter.setCustomer(affiliate);

        Customer matrix = (Customer) getSession().get(Customer.class, new Long(900000002));
        filter.setMatrix(matrix);

        filter.setParticipantType(ParticipantTypeEnum.POD);

        Date initDate = CalendarUtil.getDate(2011, 01, 12);
        Date endDate = CalendarUtil.getDate(2012, 10, 21);
        filter.setInitDate(initDate);
        filter.setEndDate(endDate);

        List<MissingReportOnlineView> result = reportOnlineService.selectMissingReportOnLineByFilter(filter);
        assertNotNull(result);
        Assert.assertTrue("Expected non empty list.", !result.isEmpty());
    }

    /**
     *
     */
    @Test
    public void test_select_count_report_online_for_matrix_ignore_affiliate_on_period_with_all_affiliates_reported_expected_zero_result() {

        // Load data base
        setupDBUnit();

        /** Create scenary */

        // Find operational year
        OperationalYear operationalYear = (OperationalYear) getSession()
                .get(OperationalYear.class, new Long(900000003));
        Assert.assertNotNull(operationalYear);

        // Get head office 1
        HeadOffice ho1 = (HeadOffice) getSession().get(HeadOffice.class, 900000004L);
        Assert.assertNotNull(ho1);

        // Create rol for head office 1
        ReportOnLine rol1 = new ReportOnLine();
        rol1.setCrop(ho1.getCrop());
        rol1.setHeadoffice(ho1);
        rol1.setOperationalYear(operationalYear);
        rol1.setRolCreateDate(new Date());
        rol1.setRolStatus(reportOnlineDAO.findRolStatusByCode(RolStatus.ROL_STATUS_RTV));
        rol1.setRolPeriod(CalendarUtil.getDate(2012, 01, 20));
        saveAndFlush(rol1);

        // Get head office 2
        HeadOffice ho2 = (HeadOffice) getSession().get(HeadOffice.class, 900000007L);
        Assert.assertNotNull(ho2);

        // Create rol for head office 2
        ReportOnLine rol2 = new ReportOnLine();
        rol2.setCrop(ho2.getCrop());
        rol2.setHeadoffice(ho2);
        rol2.setOperationalYear(operationalYear);
        rol2.setRolCreateDate(new Date());
        rol2.setRolStatus(reportOnlineDAO.findRolStatusByCode(RolStatus.ROL_STATUS_RTV));
        rol2.setRolPeriod(CalendarUtil.getDate(2012, 01, 20));
        saveAndFlush(rol2);

        // Execute search
        Integer rolAmounts = reportOnlineService.selectCountReportOnlineForMatrixIgnoreAffiliateOnPeriod(ho2,
                CalendarUtil.getDate(2012, 01, 01), CalendarUtil.getDate(2012, 01, 30), RolStatus.ROL_STATUS_RTV);

        // Check result
        Assert.assertTrue("Expected zero records because affiliates (1 and 2) have rol reported in same period.",
                rolAmounts == 0);

    }

    /**
     *
     */
    @Test
    public void test_select_count_report_online_for_matrix_ignore_affiliate_on_period_with_only_one_affiliates_reported_expected_one_result() {

        // Load data base
        setupDBUnit();

        /** Create scenary */

        // Find operational year
        OperationalYear operationalYear = (OperationalYear) getSession()
                .get(OperationalYear.class, new Long(900000003));
        Assert.assertNotNull(operationalYear);

        // Get head office 1
        HeadOffice ho1 = (HeadOffice) getSession().get(HeadOffice.class, 900000004L);
        Assert.assertNotNull(ho1);

        // Create rol for head office 1
        ReportOnLine rol1 = new ReportOnLine();
        rol1.setCrop(ho1.getCrop());
        rol1.setHeadoffice(ho1);
        rol1.setOperationalYear(operationalYear);
        rol1.setRolCreateDate(new Date());
        rol1.setRolStatus(reportOnlineDAO.findRolStatusByCode(RolStatus.ROL_STATUS_RTV));
        rol1.setRolPeriod(CalendarUtil.getDate(2012, 01, 20));
        saveAndFlush(rol1);

        // Get head office 2
        HeadOffice ho2 = (HeadOffice) getSession().get(HeadOffice.class, 900000007L);
        Assert.assertNotNull(ho2);

        // Execute search
        Integer rolAmounts = reportOnlineService.selectCountReportOnlineForMatrixIgnoreAffiliateOnPeriod(ho2,
                CalendarUtil.getDate(2012, 01, 01), CalendarUtil.getDate(2012, 01, 30), RolStatus.ROL_STATUS_RTV);

        // Check result
        Assert.assertTrue("Expected one records because affiliates only one affiliate have rol reported in period.",
                rolAmounts == 1);

    }

    @Test(expected = IllegalArgumentException.class)
    public void find_by_rol_bill_number_null() {
        reportOnlineDAO.findByRolBillNumber(null);
    }

    @Test
    public void find_by_rol_bill_number() {

        // Load data base
        setupDBUnit();

        // Create scenary
        ReportOnLine rol = (ReportOnLine) getSession().get(ReportOnLine.class, 900000001L);
        rol.setRolBillNumber(9990999909L);
        saveAndFlush(rol);

        List<ReportOnLine> rolList = reportOnlineDAO.findByRolBillNumber(9990999909L);
        Assert.assertNotNull(rolList);
        Assert.assertTrue("Expected at least 1 itens, but found: " + rolList.size(), rolList.size() >= 1);
    }

    @Test(expected = IllegalArgumentException.class)
    public void test_select_rol_log_by_id_null_argument() throws ReportOnLineNotFoundException {
        rolInformationService.selectRolLogById(null);
    }

    @Test(expected = ReportOnLineNotFoundException.class)
    public void test_select_rol_log_by_id_not_exists() throws ReportOnLineNotFoundException {
        // Load data base
        setupDBUnit();

        List<RolLogDTO> result = rolInformationService.selectRolLogById(-1L);

        Assert.assertTrue(result.isEmpty());
    }

    @Test(expected = IllegalArgumentException.class)
    public void test_select_rol_log_by_id_with_null_argument() {
        reportOnlineDAO.selectRolLogById(null);
    }

    @Test(expected = ReportOnLineNotFoundException.class)
    public void test_select_rol_log_by_id_with_nonexistent_rolid() throws ReportOnLineNotFoundException {
        // Load data base
        setupDBUnit();

        Long rolId = 987999683L; // rolId do not exist
        rolInformationService.selectRolLogById(rolId);

        Assert.fail();
    }

    @Test
    public void test_select_rol_log_by_id() throws ReportOnLineNotFoundException {
        // Load data base
        setupDBUnit();

        Long rolId = 900000003L;
        List<RolLogDTO> result = rolInformationService.selectRolLogById(rolId);

        Assert.assertFalse(result.isEmpty());

        for (RolLogDTO rl : result) {
            Assert.assertEquals(rolId, rl.getRolId());
        }
    }

    @Test
    public void test_select_rol_log_by_id_description_filled() throws ReportOnLineNotFoundException {
        // Load data base
        setupDBUnit();

        Long rolId = 900000003L;
        List<RolLogDTO> result = rolInformationService.selectRolLogById(rolId);

        Assert.assertFalse(result.isEmpty());

        for (RolLogDTO rl : result) {
            assertNotNull(rl.getParameterDescription());
        }
    }

    @Test
    public void select_report_on_line_DTO_optmized_by_filter_with_billing_columns() throws BusinessException {

        // Load database
        setupDBUnit();

        // Load head office
        HeadOffice headOffice = (HeadOffice) getSession().get(HeadOffice.class, 900000001L);
        Assert.assertNotNull(headOffice);

        // Build filter
        ReportOnLineFilter filter = new ReportOnLineFilter();
        filter.setCompany(headOffice.getCompany());
        filter.setCrop(headOffice.getCrop());
        filter.setMatrix(headOffice.getMatrix());
        // Set district
        ItsDistrict district = (ItsDistrict) getSession().get(ItsDistrict.class, 900000000L);
        Assert.assertNotNull(district);
        filter.setDistrict(district);

        // Set unity
        ItsUnity unity = (ItsUnity) getSession().get(ItsUnity.class, 900000000L);
        Assert.assertNotNull(unity);
        filter.setUnity(unity);

        // Set region
        ItsRegion region = (ItsRegion) getSession().get(ItsRegion.class, 900000000L);
        Assert.assertNotNull(region);
        filter.setRegion(region);

        // Set period
        filter.setInitDate(getRolPeriod(2012, 7, 1));
        filter.setEndDate(getRolPeriod(2012, 12, 31));

        // show billing columns
        filter.setShowBillingColumn(Boolean.TRUE);

        // search for Rol list
        List<ReportOnlineDTO> rolList = reportOnlineService.selectReportOnLineDTOByFilterOptmized(filter);

        // Check result size
        Assert.assertTrue("Expected at least 1 reports. But found " + rolList.size(), rolList.size() >= 1);

        // Check result
        for (ReportOnlineDTO item : rolList) {
            Assert.assertEquals(headOffice.getCompany().getDescription().toLowerCase(), item.getReportOnline()
                    .getHeadoffice().getCompany().getDescription().toLowerCase());
            Assert.assertEquals(headOffice.getCrop().getDescription().toLowerCase(), item.getCrop().getDescription()
                    .toLowerCase());
            Assert.assertEquals(headOffice.getMatrix().getDocumentValue(), item.getReportOnline().getHeadoffice()
                    .getMatrix().getDocumentValue());
            Assert.assertTrue(
                    "Expected reports between filter period.",
                    CalendarUtil.compareToPeriod(item.getPeriod(), filter.getInitDate()) >= 0
                            && CalendarUtil.compareToPeriod(item.getPeriod(), filter.getEndDate()) <= 0);

            Assert.assertTrue("Matrix must have unity " + filter.getUnity() + " for POD commercial hierarchy.",
                    checkUnity(item.getReportOnline().getHeadoffice().getMatrix(), filter.getUnity()));

            Assert.assertTrue("Matrix must have district " + filter.getDistrict() + " for POD commercial hierarchy.",
                    checkDistrict(item.getReportOnline().getHeadoffice().getMatrix(), filter.getDistrict()));

            Assert.assertTrue("Matrix must have region " + filter.getRegion() + " for POD commercial hierarchy.",
                    checkRegion(item.getReportOnline().getHeadoffice().getMatrix(), filter.getRegion()));

            if (CalendarUtil.formatDate(item.getPeriod(), CalendarUtil.PATTERN_MM_YYYY).equals("07/2012")) {
                Assert.assertTrue("Missing Status must true", item.getMissingStatus());
            } else {
                Assert.assertFalse("Missing Status must false", item.getMissingStatus());
            }
        }

    }

    @Test
    public void select_missing_report_on_line_by_filter_basic() throws EntityNotFoundException {

        // Load database
        setupDBUnit();

        // Load head office
        HeadOffice headOffice = (HeadOffice) getSession().get(HeadOffice.class, new Long(900000001));
        Assert.assertNotNull(headOffice);

        // Build filter
        ReportOnLineFilter filter = new ReportOnLineFilter();
        filter.setCompany(headOffice.getCompany());
        filter.setCrop(headOffice.getCrop());

        // Set period
        filter.setInitDate(getRolPeriod(2012, 7, 1));
        filter.setEndDate(getRolPeriod(2012, 12, 31));

        List<MissingReportOnlineView> result = reportOnlineService.selectMissingReportOnLineByFilter(filter);

        Assert.assertFalse(result.isEmpty());

        ArrayList<Integer> monthsMissing = new ArrayList<Integer>(2);
        monthsMissing.add(11);
        monthsMissing.add(12);
        for (MissingReportOnlineView mRol : result) {
            Assert.assertEquals("The 'company' does not match...", headOffice.getCompany().getId(), mRol.getCompanyId());
            Assert.assertEquals("The 'crop' does not match...", headOffice.getCrop().getId(), mRol.getCropId());

            Assert.assertTrue("The 'period' does not match the init...",
                    CalendarUtil.compareToPeriod(mRol.getPeriod(), getRolPeriod(2012, 7, 1)) >= 0);
            Assert.assertTrue("The 'period' does not match the end...",
                    CalendarUtil.compareToPeriod(mRol.getPeriod(), getRolPeriod(2012, 12, 31)) <= 0);

            Criteria criteria = getSession().createCriteria(ReportOnLine.class);
            criteria.add(Restrictions.eq("headoffice.id", mRol.getHeadofficeId()));
            criteria.add(Restrictions.between("rolPeriod", CalendarUtil.getFirstDateOfMonth(mRol.getPeriod()),
                    CalendarUtil.getLastDateOfMonth(mRol.getPeriod())));
            @SuppressWarnings("unchecked")
            List<ReportOnLine> rols = criteria.list();

            Assert.assertTrue("There's ROL's using the same Headoffice/Period...", rols.isEmpty());

            // Cannot have these periods...
            Assert.assertFalse(mRol.getPeriod().equals(getRolPeriod(2012, 7, 30)));
            Assert.assertFalse(mRol.getPeriod().equals(getRolPeriod(2012, 7, 15)));
            Assert.assertFalse(mRol.getPeriod().equals(getRolPeriod(2012, 8, 01)));
            Assert.assertFalse(mRol.getPeriod().equals(getRolPeriod(2012, 9, 01)));
            Assert.assertFalse(mRol.getPeriod().equals(getRolPeriod(2012, 10, 01)));

            // Should have missing's...
            for (Iterator<Integer> it = monthsMissing.iterator(); it.hasNext();) {
                Integer missing = it.next();
                if ((CalendarUtil.getDateMonth(mRol.getPeriod()) + 1) == missing) {
                    it.remove();
                }
            }
        }

        // Check if the missing months was validated...
        Assert.assertTrue(monthsMissing.isEmpty());

    }

    @Test
    public void select_missing_report_on_line_by_filter_affiliate() throws EntityNotFoundException {

        // Load database
        setupDBUnit();

        // Load head office
        HeadOffice headOffice = (HeadOffice) getSession().get(HeadOffice.class, new Long(900000001));
        Assert.assertNotNull(headOffice);

        // Build filter
        ReportOnLineFilter filter = new ReportOnLineFilter();
        filter.setCompany(headOffice.getCompany());
        filter.setCrop(headOffice.getCrop());

        Customer affiliate = (Customer) getSession().get(Customer.class, 900000002L);
        Assert.assertNotNull(affiliate);
        filter.setCustomer(affiliate);

        // Set period
        filter.setInitDate(getRolPeriod(2012, 7, 1));
        filter.setEndDate(getRolPeriod(2012, 12, 31));

        List<MissingReportOnlineView> result = reportOnlineService.selectMissingReportOnLineByFilter(filter);

        Assert.assertFalse(result.isEmpty());

        for (MissingReportOnlineView mRol : result) {
            Assert.assertEquals("The 'company' does not match...", headOffice.getCompany().getId(), mRol.getCompanyId());
            Assert.assertEquals("The 'crop' does not match...", headOffice.getCrop().getId(), mRol.getCropId());

            Assert.assertTrue("The 'period' does not match the init...",
                    CalendarUtil.compareToPeriod(mRol.getPeriod(), getRolPeriod(2012, 7, 1)) >= 0);
            Assert.assertTrue("The 'period' does not match the end...",
                    CalendarUtil.compareToPeriod(mRol.getPeriod(), getRolPeriod(2012, 12, 31)) <= 0);

            Assert.assertEquals("The 'affiliateId' does not match..", affiliate.getId(), mRol.getAffiliateId());

            Criteria criteria = getSession().createCriteria(ReportOnLine.class);
            criteria.add(Restrictions.eq("headoffice.id", mRol.getHeadofficeId()));
            criteria.add(Restrictions.between("rolPeriod", CalendarUtil.getFirstDateOfMonth(mRol.getPeriod()),
                    CalendarUtil.getLastDateOfMonth(mRol.getPeriod())));
            @SuppressWarnings("unchecked")
            List<ReportOnLine> rols = criteria.list();

            Assert.assertTrue("There's ROL's using the same Filters...", rols.isEmpty());
        }
    }

    @Test
    public void select_missing_report_on_line_by_filter_matrix() throws EntityNotFoundException {

        // Load database
        setupDBUnit();

        // Load head office
        HeadOffice headOffice = (HeadOffice) getSession().get(HeadOffice.class, new Long(900000001));
        Assert.assertNotNull(headOffice);

        // Build filter
        ReportOnLineFilter filter = new ReportOnLineFilter();
        filter.setCompany(headOffice.getCompany());
        filter.setCrop(headOffice.getCrop());

        Customer matrix = (Customer) getSession().get(Customer.class, 900000002L);
        Assert.assertNotNull(matrix);
        filter.setMatrix(matrix);

        // Set period
        filter.setInitDate(getRolPeriod(2012, 7, 1));
        filter.setEndDate(getRolPeriod(2012, 12, 31));

        List<MissingReportOnlineView> result = reportOnlineService.selectMissingReportOnLineByFilter(filter);

        Assert.assertFalse(result.isEmpty());

        for (MissingReportOnlineView mRol : result) {
            Assert.assertEquals("The 'company' does not match...", headOffice.getCompany().getId(), mRol.getCompanyId());
            Assert.assertEquals("The 'crop' does not match...", headOffice.getCrop().getId(), mRol.getCropId());

            Assert.assertTrue("The 'period' does not match the init...",
                    CalendarUtil.compareToPeriod(mRol.getPeriod(), getRolPeriod(2012, 7, 1)) >= 0);
            Assert.assertTrue("The 'period' does not match the end...",
                    CalendarUtil.compareToPeriod(mRol.getPeriod(), getRolPeriod(2012, 12, 31)) <= 0);

            Assert.assertEquals("The 'matrixId' does not match..", matrix.getId(), mRol.getMatrixId());

            Criteria criteria = getSession().createCriteria(ReportOnLine.class);
            criteria.add(Restrictions.eq("headoffice.id", mRol.getHeadofficeId()));
            criteria.add(Restrictions.between("rolPeriod", CalendarUtil.getFirstDateOfMonth(mRol.getPeriod()),
                    CalendarUtil.getLastDateOfMonth(mRol.getPeriod())));
            @SuppressWarnings("unchecked")
            List<ReportOnLine> rols = criteria.list();

            Assert.assertTrue("There's ROL's using the same Filters...", rols.isEmpty());
        }
    }

}