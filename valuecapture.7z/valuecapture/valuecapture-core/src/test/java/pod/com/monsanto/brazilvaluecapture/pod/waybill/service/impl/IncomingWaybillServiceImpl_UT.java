package com.monsanto.brazilvaluecapture.pod.waybill.service.impl;

import com.monsanto.brazilvaluecapture.core.foundation.service.BusinessException;
import com.monsanto.brazilvaluecapture.core.grower.service.impl.GrowerAccountUpdateARServiceRunner;
import com.monsanto.brazilvaluecapture.core.regionalization.VCCountry;
import com.monsanto.brazilvaluecapture.pod.model.bean.Waybill;
import com.monsanto.brazilvaluecapture.pod.service.WaybillService;
import com.monsanto.brazilvaluecapture.pod.waybill.model.bean.IncomingWaybill;
import com.monsanto.brazilvaluecapture.pod.waybill.model.bean.IncomingWaybillAR;
import com.monsanto.brazilvaluecapture.pod.waybill.model.dao.IncomingWaybillDAO;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.Arrays;
import java.util.List;

import static org.fest.reflect.core.Reflection.field;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class IncomingWaybillServiceImpl_UT {

    @Mock
    private IncomingWaybillDAO incomingWaybillDAO;
    @InjectMocks
    private IncomingWaybillServiceImpl service;
    @Mock
    private WaybillService waybillService;


    @Test
    public void saveShouldSucceed() throws Exception {
        IncomingWaybill incomingWaybill = mock(IncomingWaybill.class);

        service.save(incomingWaybill);

        verify(incomingWaybillDAO).save(incomingWaybill);
    }

    @Test
    public void testProcessIncomingWaybills_When_IncomingWaybillAR() throws Exception {
        // @Given


        IncomingWaybill incomingWaybill = new IncomingWaybillAR();
        incomingWaybill.setCountryCode(VCCountry.ARGENTINA.getLocale().getCountry());

        Long waybillId = 300L;
        Waybill waybill = new Waybill();
        waybill.setId(waybillId);
        waybill.setCreditConsumptionId(200L);

        //  field("waybillService").ofType(WaybillService.class).in(incomingWaybillService).set(waybillService);
        when(waybillService.createAndProcessWaybill(incomingWaybill)).thenReturn(waybill);

        GrowerAccountUpdateARServiceRunner growerAccountUpdateServiceAR = mock(GrowerAccountUpdateARServiceRunner.class);
        field("growerAccountUpdateServiceAR").ofType(GrowerAccountUpdateARServiceRunner.class).in(service).set(growerAccountUpdateServiceAR);

        // @When
        try {
            service.analyzeWaybill(incomingWaybill);
        } catch (Throwable throwable) {
            fail(throwable.getMessage());
        }

        // @Then
        verify(growerAccountUpdateServiceAR).run(waybill);
        assertEquals(waybillId, waybill.getId());
    }


    @Test
    public void testGiven_AnIncoming_Waybill_When_I_Call_CreateAndProcessWaybill_Then_IT_Should_RaiseAnException() throws BusinessException {
        // @Given
        IncomingWaybill incomingWaybill = new IncomingWaybillAR();
        incomingWaybill.setCountryCode(VCCountry.ARGENTINA.getLocale().getCountry());

        when(waybillService.createAndProcessWaybill(incomingWaybill)).thenThrow(BusinessException.class);

        // @When
        try{
            service.analyzeWaybill(incomingWaybill);
        }catch(Throwable t){

            assertTrue("Test Succeed",true);
        }

    }







}