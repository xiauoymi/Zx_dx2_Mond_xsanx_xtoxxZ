package com.monsanto.brazilvaluecapture.pod.rol.service.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import org.hibernate.criterion.Projections;
import org.junit.Assert;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.monsanto.brazilvaluecapture.core.base.model.bean.Company;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Crop;
import com.monsanto.brazilvaluecapture.core.commercialhierarchy.model.bean.ItsDistrict;
import com.monsanto.brazilvaluecapture.core.commercialhierarchy.model.bean.ItsRegion;
import com.monsanto.brazilvaluecapture.core.commercialhierarchy.model.bean.ItsUnity;
import com.monsanto.brazilvaluecapture.core.foundation.test.AbstractServiceIntegrationTests;
import com.monsanto.brazilvaluecapture.core.foundation.test.dbunit.DbUnitHelper;
import com.monsanto.brazilvaluecapture.core.user.model.bean.ItsUser;
import com.monsanto.brazilvaluecapture.pod.rol.model.bean.ApprovalEmail;
import com.monsanto.brazilvaluecapture.pod.rol.model.bean.ReportOnLine;
import com.monsanto.brazilvaluecapture.pod.rol.model.bean.RolStatus;
import com.monsanto.brazilvaluecapture.pod.rol.model.service.ApprovalEmailFilter;
import com.monsanto.brazilvaluecapture.pod.rol.model.service.ApprovalEmailNotFoundException;
import com.monsanto.brazilvaluecapture.pod.rol.model.service.PodApprovalEmailService;
import com.monsanto.brazilvaluecapture.pod.rol.model.service.ReportOnLineInfo;

/**
 * @author andrius
 * 
 */
public class PodApprovalEmailService_AT extends AbstractServiceIntegrationTests {

    @Autowired
    private PodApprovalEmailService approvalEmailService;

    private ItsUser itsUser;

    /**
     * Configure database data.
     */
    public void setupDBUnit() {

        // Load rol status
        int rolStatusCount = (Integer) getSession().createCriteria(RolStatus.class)
                .setProjection(Projections.count("id")).uniqueResult();
        if (rolStatusCount == 0) {
            DbUnitHelper.setup("classpath:data/pod/rol/rol-status-dataset.xml");
        }

        // Load dbunit
        DbUnitHelper.setup("classpath:data/core/fixture-system-dataset.xml",
                "classpath:data/core/participant-dataset.xml",
                "classpath:data/commercialhierarchy/commercialhierarchy-podapproval-email-mecanism-dataset.xml",
                "classpath:data/pod/rol/rol-parameters-dataset.xml",
                "classpath:data/pod/rol/report-online-dataset.xml", "classpath:data/pod/rol/counter-price-dataset.xml",
                "classpath:data/pod/rol/rol-configuration-dataset.xml",
                "classpath:data/core/headoffice-detail-dataset.xml", "classpath:data/core/approval-email-dataset.xml");

        itsUser = (ItsUser) getSession().get(ItsUser.class, new Long(900000004));

    }

    @Test
    public void test_send_email_approval_rol_just_for_first_approving() {
        setupDBUnit();

        // get emails to send
        ApprovalEmailFilter filter = new ApprovalEmailFilter();
        filter.setCrop((Crop) getSession().get(Crop.class, 900000001L));
        filter.setCompany((Company) getSession().get(Company.class, 990000002L));

        ApprovalEmail approvalEmail = approvalEmailService.selectUniqueApprovalEmailByFilter(filter);

        // get rol
        ReportOnLine rol = (ReportOnLine) getSession().get(ReportOnLine.class, 900000001L);

        // get list of e-mails
        String[] firstEmails = approvalEmail.getFirstLevelEmails();
        String[] secondEmails = approvalEmail.getSecondLevelEmails();

        ReportOnLineInfo rolInfo = new ReportOnLineInfo(Locale.US);
        rolInfo.setRecipients(new ArrayList<String>());
        boolean sendToSecondApproving = false;
        approvalEmailService.sendEmailApprovalRol(rol, rolInfo, sendToSecondApproving);

        // check that the emails to send were firstEmails
        List<String> recipients = rolInfo.getRecipients();

        for (String email : recipients) {
            Assert.assertTrue(containsInArray(email, firstEmails));
            Assert.assertFalse(containsInArray(email, secondEmails));
        }

    }

    @Test
    public void test_send_email_approval_rol_just_for_second_approving() {
        setupDBUnit();

        // get emails to send
        ApprovalEmailFilter filter = new ApprovalEmailFilter();
        filter.setCrop((Crop) getSession().get(Crop.class, 900000001L));
        filter.setCompany((Company) getSession().get(Company.class, 990000002L));

        // get the aprrovers's e-mail.
        ApprovalEmail approvalEmail = approvalEmailService.selectUniqueApprovalEmailByFilter(filter);

        // get rol
        ReportOnLine rol = (ReportOnLine) getSession().get(ReportOnLine.class, 900000001L);

        // get list of e-mails
        String[] firstEmails = approvalEmail.getFirstLevelEmails();
        String[] secondEmails = approvalEmail.getSecondLevelEmails();

        ReportOnLineInfo rolInfo = new ReportOnLineInfo(Locale.US);
        rolInfo.setRecipients(new ArrayList<String>());
        boolean sendToSecondApproving = true;
        approvalEmailService.sendEmailApprovalRol(rol, rolInfo, sendToSecondApproving);

        // check that the emails to send were firstEmails
        List<String> recipients = rolInfo.getRecipients();

        for (String email : recipients) {
            Assert.assertFalse(containsInArray(email, firstEmails));
            Assert.assertTrue(containsInArray(email, secondEmails));
        }

    }

    private boolean containsInArray(String str, String[] strArray) {
        for (String item : strArray) {
            if (item.equals(str)) {
                return true;
            }
        }
        return false;
    }

    @Test(expected = IllegalArgumentException.class)
    public void teste_select_approval_email_with_no_filter_expected_exception_no_filter() {

        // Build null filter...
        ApprovalEmailFilter filter = null;
        approvalEmailService.selectApprovalEmailByFilter(filter);

    }

    @Test(expected = IllegalArgumentException.class)
    public void teste_select_approval_email_with_no_filter_expected_exception_no_company() {

        // Build simple filter without restrictions...
        ApprovalEmailFilter filter = new ApprovalEmailFilter();
        approvalEmailService.selectApprovalEmailByFilter(filter);

    }

    @Test(expected = IllegalArgumentException.class)
    public void teste_select_approval_email_with_no_filter_expected_exception_no_crop() {

        setupDBUnit();

        // Build simple filter without crop...
        ApprovalEmailFilter filter = new ApprovalEmailFilter();
        filter.setCompany((Company) getSession().get(Company.class, 990000002L));
        approvalEmailService.selectApprovalEmailByFilter(filter);

    }

    @Test()
    public void teste_select_approval_email_by_crop_and_company() {
        setupDBUnit();
        // Build simple filter without restrictions...
        ApprovalEmailFilter filter = new ApprovalEmailFilter();

        filter.setCrop((Crop) getSession().get(Crop.class, 900000001L));
        filter.setCompany((Company) getSession().get(Company.class, 990000002L));

        List<ApprovalEmail> result = approvalEmailService.selectApprovalEmailByFilter(filter);
        Assert.assertNotNull(result);
        Assert.assertFalse(result.isEmpty());
        Assert.assertTrue("Expected at least one. But found: " + result.size(), result.size() >= 1);

        for (ApprovalEmail ae : result) {
            Assert.assertEquals(filter.getCrop(), ae.getCrop());
            Assert.assertEquals(filter.getCompany(), ae.getCompany());
        }

    }

    @Test
    public void test_save_approval_mail_with_success() {
        this.setupDBUnit();

        Company company = (Company) this.getSession().get(Company.class, 990000002L);
        Assert.assertNotNull(company);

        Crop crop = (Crop) this.getSession().get(Crop.class, 900000001L);
        Assert.assertNotNull(crop);

        ItsUnity unity = (ItsUnity) this.getSession().get(ItsUnity.class, 900000000L);
        Assert.assertNotNull(unity);

        ItsRegion region = (ItsRegion) this.getSession().get(ItsRegion.class, 900000000L);
        Assert.assertNotNull(region);

        ItsDistrict district = (ItsDistrict) this.getSession().get(ItsDistrict.class, 900000005L);
        Assert.assertNotNull(district);

        String login = "_root_";
        String[] firstEmails = { "primeira_aprovacao@testeUnity.com" };

        String[] secondEmails = { "segunda_aprovacao@testeUnity.com" };

        ApprovalEmail approvalEmail = new ApprovalEmail(crop, company, unity, region, district, login);

        approvalEmail.setFirstApprovalEmails(firstEmails.toString());
        approvalEmail.setSecondaryApprovalEmails(secondEmails.toString());
        approvalEmail.setUpdateDate(new Date());

        ApprovalEmailFilter filter = new ApprovalEmailFilter();
        filter.setCompany(company);
        filter.setCrop(crop);
        filter.setDistrict(district);
        Assert.assertNotNull(filter);

        List<ApprovalEmail> listApproval = approvalEmailService.selectApprovalEmailByFilter(filter);
        Assert.assertEquals(0, listApproval.size());

        approvalEmailService.saveAndUpdatePodApprovalEmail(approvalEmail);
        Assert.assertNotNull(approvalEmail.getId());
    }

    @Test
    public void test_save_approval_mail_without_success() {
        this.setupDBUnit();

        Company company = (Company) this.getSession().get(Company.class, 990000002L);
        Assert.assertNotNull(company);

        Crop crop = (Crop) this.getSession().get(Crop.class, 900000001L);
        Assert.assertNotNull(crop);

        ItsUnity unity = (ItsUnity) this.getSession().get(ItsUnity.class, 900000000L);
        Assert.assertNotNull(unity);

        ItsRegion region = (ItsRegion) this.getSession().get(ItsRegion.class, 900000000L);
        Assert.assertNotNull(region);

        ItsDistrict district = (ItsDistrict) this.getSession().get(ItsDistrict.class, 900000000L);
        Assert.assertNotNull(district);

        String login = "_root_";
        ApprovalEmail approvalEmail = new ApprovalEmail(crop, company, unity, region, district, login);
        approvalEmail.setFirstApprovalEmails("primeira_aprovacao@testeUnity.com");
        approvalEmail.setSecondaryApprovalEmails("segunda_aprovacao@testeUnity.com");

        ApprovalEmailFilter filter = new ApprovalEmailFilter();
        filter.setCompany(company);
        filter.setCrop(crop);
        filter.setDistrict(district);
        Assert.assertNotNull(filter);

        List<ApprovalEmail> listApproval = approvalEmailService.selectApprovalEmailByFilter(filter);
        Assert.assertNotNull(listApproval);
        Assert.assertFalse(listApproval.isEmpty());
    }

    @Test(expected = IllegalArgumentException.class)
    public void test_save_approval_mail_null() {
        approvalEmailService.saveAndUpdatePodApprovalEmail(null);
    }

    @Test
    public void test_delete_approval_mail_with_success() throws ApprovalEmailNotFoundException {
        this.setupDBUnit();

        ApprovalEmail approvalEmail = (ApprovalEmail) this.getSession().get(ApprovalEmail.class, 999000002L);
        Assert.assertNotNull(approvalEmail);
        approvalEmailService.deletePodApprovalEmail(approvalEmail);
    }

    @Test(expected = IllegalArgumentException.class)
    public void test_delete_approval_mail_null() throws ApprovalEmailNotFoundException {
        approvalEmailService.deletePodApprovalEmail(null);
    }

    @Test
    public void test_approval_mail_find_by_id() throws ApprovalEmailNotFoundException {
        this.setupDBUnit();
        ApprovalEmail approvalEmail = approvalEmailService.findById(999000001L);
        Assert.assertNotNull(approvalEmail);
    }

    @Test(expected = IllegalArgumentException.class)
    public void test_approval_mail_find_by_id_null() throws ApprovalEmailNotFoundException {
        approvalEmailService.findById(null);
    }

    @Test()
    public void teste_select_approval_email_by_crop_company_unity() {

        setupDBUnit();

        // Build simple filter without restrictions...
        ApprovalEmailFilter filter = new ApprovalEmailFilter();

        filter.setCrop((Crop) getSession().get(Crop.class, 900000001L));
        filter.setCompany((Company) getSession().get(Company.class, 990000002L));

        filter.setUnity((ItsUnity) getSession().get(ItsUnity.class, 900000000L));

        List<ApprovalEmail> result = approvalEmailService.selectApprovalEmailByFilter(filter);
        Assert.assertNotNull(result);
        Assert.assertFalse(result.isEmpty());
        Assert.assertTrue("Expected at least one. But found: " + result.size(), result.size() >= 1);

        for (ApprovalEmail ae : result) {
            Assert.assertEquals(filter.getCrop(), ae.getCrop());
            Assert.assertEquals(filter.getCompany(), ae.getCompany());
        }

    }

    @Test()
    public void teste_select_approval_email_by_crop_company_region() {

        setupDBUnit();

        // Build simple filter without restrictions...
        ApprovalEmailFilter filter = new ApprovalEmailFilter();

        filter.setCrop((Crop) getSession().get(Crop.class, 900000001L));
        filter.setCompany((Company) getSession().get(Company.class, 990000002L));

        filter.setRegion((ItsRegion) getSession().get(ItsRegion.class, 900000000L));

        List<ApprovalEmail> result = approvalEmailService.selectApprovalEmailByFilter(filter);
        Assert.assertNotNull(result);
        Assert.assertFalse(result.isEmpty());
        Assert.assertTrue("Expected at least one. But found: " + result.size(), result.size() >= 1);

        for (ApprovalEmail ae : result) {
            Assert.assertEquals(filter.getCrop(), ae.getCrop());
            Assert.assertEquals(filter.getCompany(), ae.getCompany());
        }

    }

    @Test()
    public void teste_select_approval_email_by_crop_company_district() {

        setupDBUnit();

        // Build simple filter without restrictions...
        ApprovalEmailFilter filter = new ApprovalEmailFilter();

        filter.setCrop((Crop) getSession().get(Crop.class, 900000001L));
        filter.setCompany((Company) getSession().get(Company.class, 990000002L));

        filter.setDistrict((ItsDistrict) getSession().get(ItsDistrict.class, 900000000L));

        List<ApprovalEmail> result = approvalEmailService.selectApprovalEmailByFilter(filter);
        Assert.assertNotNull(result);
        Assert.assertFalse(result.isEmpty());
        Assert.assertTrue("Expected at least one. But found: " + result.size(), result.size() >= 1);

        for (ApprovalEmail ae : result) {
            Assert.assertEquals(filter.getCrop(), ae.getCrop());
            Assert.assertEquals(filter.getCompany(), ae.getCompany());
        }

    }

    @Test()
    public void teste_select_approval_email_empty_result() {

        setupDBUnit();

        // Build simple filter without restrictions...
        ApprovalEmailFilter filter = new ApprovalEmailFilter();

        filter.setCrop((Crop) getSession().get(Crop.class, 900000001L));
        filter.setCompany((Company) getSession().get(Company.class, 990000002L));

        filter.setUnity((ItsUnity) getSession().get(ItsUnity.class, 900000002L));
        filter.setRegion((ItsRegion) getSession().get(ItsRegion.class, 900000003L));
        filter.setDistrict((ItsDistrict) getSession().get(ItsDistrict.class, 900000005L));

        List<ApprovalEmail> result = approvalEmailService.selectApprovalEmailByFilter(filter);

        Assert.assertTrue(result.isEmpty());

    }

    @Test
    public void test_send_email_disapproval_rol_just_for_affiliate_and_first_approving() {

        setupDBUnit();
        // get emails to send
        ApprovalEmailFilter filter = new ApprovalEmailFilter();
        filter.setCrop((Crop) getSession().get(Crop.class, 900000001L));
        filter.setCompany((Company) getSession().get(Company.class, 990000002L));

        ApprovalEmail approvalEmail = approvalEmailService.selectUniqueApprovalEmailByFilter(filter);
        // get rol
        ReportOnLine rol = (ReportOnLine) getSession().get(ReportOnLine.class, 900000001L);

        String[] firstEmails = approvalEmail.getFirstLevelEmails();
        String[] secondEmails = approvalEmail.getSecondLevelEmails();

        // Disapprove ROL
        rol = (ReportOnLine) getSession().get(ReportOnLine.class, 900000004L);
        ReportOnLineInfo rolInfo = new ReportOnLineInfo(Locale.US);
        rolInfo.setRecipients(new ArrayList<String>());
        rol.setItsUserLogin(this.itsUser.getLogin());

        String affiliateEmail = this.itsUser.getEmail();
        boolean sendToFirstApproving = true;
        boolean sendToSecondApproving = false;

        // Send Mail.
        approvalEmailService.sendEmailDisapprovalRol(rol, rolInfo, sendToFirstApproving, sendToSecondApproving);
        // check that the emails to send were firstEmails more affiliate email.
        List<String> recipients = rolInfo.getRecipients();

        Assert.assertTrue(recipients.contains(affiliateEmail));
        recipients.remove(affiliateEmail);

        for (String email : recipients) {
            Assert.assertTrue(containsInArray(email, firstEmails));
            Assert.assertFalse(containsInArray(email, secondEmails));
        }
    }

    @Test
    public void test_send_email_disapproval_rol_for_affiliate_first_and_second_approving() {

        setupDBUnit();

        // get emails to send
        ApprovalEmailFilter filter = new ApprovalEmailFilter();
        filter.setCrop((Crop) getSession().get(Crop.class, 900000001L));
        filter.setCompany((Company) getSession().get(Company.class, 990000002L));

        ApprovalEmail approvalEmail = approvalEmailService.selectUniqueApprovalEmailByFilter(filter);
        // get rol
        ReportOnLine rol = (ReportOnLine) getSession().get(ReportOnLine.class, 900000001L);

        // Disapprove ROL
        rol = (ReportOnLine) getSession().get(ReportOnLine.class, 900000004L);
        ReportOnLineInfo rolInfo = new ReportOnLineInfo(Locale.US);
        rolInfo.setRecipients(new ArrayList<String>());
        rol.setItsUserLogin(this.itsUser.getLogin());

        String affiliateEmail = this.itsUser.getEmail();
        String[] firstEmails = approvalEmail.getFirstLevelEmails();
        String[] secondEmails = approvalEmail.getSecondLevelEmails();
        boolean sendToFirstApproving = true;
        boolean sendToSecondApproving = true;

        // Send Mail.
        approvalEmailService.sendEmailDisapprovalRol(rol, rolInfo, sendToFirstApproving, sendToSecondApproving);

        // check that the emails to send were firstEmails
        List<String> recipients = rolInfo.getRecipients();

        Assert.assertTrue(recipients.contains(affiliateEmail));
        recipients.remove(affiliateEmail);

        for (String email : recipients) {

            boolean emailInRecipients = containsInArray(email, firstEmails);
            emailInRecipients = emailInRecipients || containsInArray(email, secondEmails);
            Assert.assertTrue(emailInRecipients);
        }
    }

    @Test
    public void try_send_disapproved_email_when_there_are_no_approval_email_registered() {
        setupDBUnit();

        ReportOnLine rol = (ReportOnLine) getSession().get(ReportOnLine.class, 900000001L);
        ReportOnLineInfo rolInfo = new ReportOnLineInfo(Locale.US);
        rolInfo.setRecipients(new ArrayList<String>());
        rol.setItsUserLogin(this.itsUser.getLogin());

        boolean sendToFirstApproving = true;
        boolean sendToSecondApproving = true;

        // Send Mail.
        approvalEmailService.sendEmailDisapprovalRol(rol, rolInfo, sendToFirstApproving, sendToSecondApproving);

        rolInfo.getRecipients().remove(itsUser.getEmail());

        // check that the emails to send were firstEmails
        Assert.assertTrue(rolInfo.getRecipients().isEmpty());
    }

    @Test
    public void send_dissapproved_email_for_pod_email() {

        ReportOnLine rol;
        setupDBUnit();

        // Disapprove ROL
        rol = (ReportOnLine) getSession().get(ReportOnLine.class, 900000004L);
        ReportOnLineInfo rolInfo = new ReportOnLineInfo(Locale.US);
        rolInfo.setRecipients(new ArrayList<String>());
        rol.setItsUserLogin(this.itsUser.getLogin());

        String affiliateEmail = this.itsUser.getEmail();
        boolean sendToFirstApproving = false;
        boolean sendToSecondApproving = false;

        // Send Mail.
        approvalEmailService.sendEmailDisapprovalRol(rol, rolInfo, sendToFirstApproving, sendToSecondApproving);

        // check that the emails to send were firstEmails
        List<String> recipients = rolInfo.getRecipients();

        Assert.assertTrue(recipients.get(0).equals(affiliateEmail));
    }
}
