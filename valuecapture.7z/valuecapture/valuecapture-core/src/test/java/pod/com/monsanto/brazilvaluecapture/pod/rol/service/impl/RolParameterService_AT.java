package com.monsanto.brazilvaluecapture.pod.rol.service.impl;

import static org.junit.Assert.assertFalse;

import java.math.BigDecimal;
import java.util.HashSet;
import java.util.List;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.monsanto.brazilvaluecapture.core.base.model.bean.Crop;
import com.monsanto.brazilvaluecapture.core.commercialhierarchy.model.bean.ItsUnity;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Technology;
import com.monsanto.brazilvaluecapture.core.customer.service.CustomerNotAllowedException;
import com.monsanto.brazilvaluecapture.core.customer.service.CustomerNotFoundException;
import com.monsanto.brazilvaluecapture.core.foundation.test.AbstractServiceIntegrationTests;
import com.monsanto.brazilvaluecapture.core.foundation.test.dbunit.DbUnitHelper;
import com.monsanto.brazilvaluecapture.core.foundation.util.ConstraintViolation;
import com.monsanto.brazilvaluecapture.core.grower.service.GrowerNotFoundException;
import com.monsanto.brazilvaluecapture.core.user.service.UserNotFoundException;
import com.monsanto.brazilvaluecapture.pod.rol.model.bean.CommissionType;
import com.monsanto.brazilvaluecapture.pod.rol.model.bean.ItsUnitToRolParameter;
import com.monsanto.brazilvaluecapture.pod.rol.model.bean.OperationalYearType;
import com.monsanto.brazilvaluecapture.pod.rol.model.bean.RolFrameGroup;
import com.monsanto.brazilvaluecapture.pod.rol.model.bean.RolParameter;
import com.monsanto.brazilvaluecapture.pod.rol.model.bean.RolStatus;
import com.monsanto.brazilvaluecapture.pod.rol.model.service.RolParameterAlreadyUsedException;
import com.monsanto.brazilvaluecapture.pod.rol.model.service.RolParameterConstraintException;
import com.monsanto.brazilvaluecapture.pod.rol.model.service.RolParameterException;
import com.monsanto.brazilvaluecapture.pod.rol.model.service.RolParameterNotFoundException;
import com.monsanto.brazilvaluecapture.pod.rol.model.service.RolParameterService;

/**
 * @author cmiranda
 * 
 */
public class RolParameterService_AT extends AbstractServiceIntegrationTests {

    /**
     * 
     */
    @Autowired
    private RolParameterService rolParameterService;

    @Before
    public void setup() {

    }

    public void setupDBUnit() {

        // Load rol status
        int rolStatusCount = getSession().createCriteria(RolStatus.class).list().size();
        if (rolStatusCount == 0) {
            DbUnitHelper.setup("classpath:data/pod/rol/rol-status-dataset.xml");
        }

        // Load dbunit
        DbUnitHelper.setup("classpath:data/core/fixture-system-dataset.xml",
                "classpath:data/core/participant-dataset.xml",
                "classpath:data/commercialhierarchy/commercialhierarchy-dataset.xml",
                "classpath:data/pod/rol/rol-parameters-dataset.xml");
    }

    @Test
    public void search_rol_parameter_list_soja_intacta() throws RolParameterException, GrowerNotFoundException,
            UserNotFoundException, CustomerNotFoundException, CustomerNotAllowedException {
        setupDBUnit();

        Crop crop = (Crop) getSession().load(Crop.class, new Long(900000001));// _SOJA_
        Technology tech = (Technology) getSession().load(Technology.class, new Long(900000001));// _INTACTA_
        // search for RolParameter list
        List<RolParameter> rolParamList = rolParameterService.selectRolParameterList(crop.getCompany(), crop, tech);

        Assert.assertEquals("Only two items must be returned.", 2, rolParamList.size());

        for (RolParameter item : rolParamList) {
            Assert.assertEquals("Technology must be _INTACTA_", "_INTACTA_", item.getTechnology().getDescription());
        }

    }

    @Test
    public void search_rol_parameter_list_algodao_intacta() throws RolParameterException, GrowerNotFoundException,
            UserNotFoundException, CustomerNotFoundException, CustomerNotAllowedException {
        setupDBUnit();

        Technology tech = (Technology) getSession().load(Technology.class, new Long(900000001));// _INTACTA_
        // <!-- TECHNOLOGY INTACTA * CROP _ALGODAO_ -->
        Crop crop = (Crop) getSession().load(Crop.class, new Long(900000002));// _ALGODAO_
        List<RolParameter> rolParamList = rolParameterService.selectRolParameterList(crop.getCompany(), crop, tech);

        Assert.assertEquals("Only ONE item must be returned.", 1, rolParamList.size());
        Assert.assertEquals("Crop must be _ALGODAO_", "_ALGODAO_", rolParamList.get(0).getCrop().getDescription());
    }

    @Test
    public void search_rol_parameter_list_for_all_technologies() throws RolParameterException, GrowerNotFoundException,
            UserNotFoundException, CustomerNotFoundException, CustomerNotAllowedException {
        setupDBUnit();

        Crop crop = (Crop) getSession().load(Crop.class, new Long(900000001));// _SOJA_
        // search for RolParameter list
        List<RolParameter> rolParamList = rolParameterService.selectRolParameterList(crop.getCompany(), crop, null);

        Assert.assertEquals("Only four items must be returned.", 3, rolParamList.size());
        int intacta = 0;
        int rr = 0;
        for (RolParameter item : rolParamList) {
            if (item.getTechnology().getDescription().equals("_INTACTA_")) {
                intacta++;
            }
            if (item.getTechnology().getDescription().equals("_RR_")) {
                rr++;
            }
        }
        Assert.assertEquals("Only 3 intacta technologies must appear.", 2, intacta);
        Assert.assertEquals("Only 1 RR technology must appear.", 1, rr);
    }

    @Test(expected = IllegalArgumentException.class)
    public void search_rol_parameter_list_missing_arguments_expected_rolparameterexception()
            throws RolParameterException, GrowerNotFoundException, UserNotFoundException, CustomerNotFoundException,
            CustomerNotAllowedException {
        setupDBUnit();

        Crop crop = (Crop) getSession().load(Crop.class, new Long(900000001));// _SOJA_
        Technology tech = (Technology) getSession().load(Technology.class, new Long(900000001));// _INTACTA_
        // search for RolParameter list
        rolParameterService.selectRolParameterList(null, crop, tech);
        Assert.fail("Expected exception RolParameterException");
    }

    /**
     * @throws RolParameterNotFoundException
     */
    @Test(expected = IllegalArgumentException.class)
    public void test_find_rol_parameter_with_null_id_expected_illegar_argument_exception()
            throws RolParameterNotFoundException {

        rolParameterService.findRolParameterById(null);

    }

    /**
     * @throws RolParameterNotFoundException
     */
    @Test
    public void test_find_rol_parameter_with_valid_id() throws RolParameterNotFoundException {

        // Load dbunit for this test
        setupDBUnit();

        Long id = new Long(900000001L);
        RolParameter param = rolParameterService.findRolParameterById(id);
        Assert.assertNotNull("Expected a valid param.", param);
        Assert.assertEquals("Expected a valid param.", id, param.getId());

    }

    @Test
    public void select_operational_years() {
        setupDBUnit();
        assertFalse(rolParameterService.selectOperationalYearsType().isEmpty());
    }

    @Test
    public void select_comissions() {
        setupDBUnit();
        assertFalse(rolParameterService.selectComissionsType().isEmpty());
    }

    @Test
    public void select_bundle_rol_groups() {
        setupDBUnit();
        assertFalse(rolParameterService.selectRolFrameGroups().isEmpty());
    }

    @Test
    public void test_find_rol_parameter_with_valid_id_that_have_been_used_for_rol()
            throws RolParameterNotFoundException {

        // Load dbunit for this test
        setupDBUnit();

        Long id = new Long(900000002L);
        RolParameter param = rolParameterService.findRolParameterById(id);
        Assert.assertNotNull("Expected a valid param.", param);
        Assert.assertEquals("Expected a valid param.", id, param.getId());
        Assert.assertTrue("This parameter must be flagged as used.", param.getParameterIsAlreadyUsed());
    }

    /**
     * @throws RolParameterNotFoundException
     */
    @Test(expected = RolParameterNotFoundException.class)
    public void test_find_rol_parameter_with_invalid_id() throws RolParameterNotFoundException {

        rolParameterService.findRolParameterById(-1L);

    }

    @Test(expected = IllegalArgumentException.class)
    public void test_save_rol_parameter_with_parameter_null_expected_illegal_argument_exception()
            throws RolParameterConstraintException, RolParameterNotFoundException {

        rolParameterService.saveRolParameter(null);

    }

    /**
     * @throws RolParameterConstraintException
     * @throws RolParameterNotFoundException
     */
    @Test
    public void test_save_rol_parameter_with_crop_null_expected_valid_contraint_exception()
            throws RolParameterConstraintException, RolParameterNotFoundException {

        RolParameter rolParameter = new RolParameter();
        rolParameter.setCommissionType(new CommissionType());
        rolParameter.setCrop(null);
        rolParameter.setItsUnitToRolParameters(new HashSet<ItsUnitToRolParameter>());
        rolParameter.setOperationalYearType(new OperationalYearType());
        rolParameter.setRolFrameGroup(new RolFrameGroup());
        rolParameter.setRolParameterDescription("");
        rolParameter.setRolParameterMaterialSapId("");
        rolParameter.setRolParameterSeasonBonus(false);
        rolParameter.setRolParameterSendToErp(false);
        rolParameter.setRolParameterSequence(new Integer(0));
        rolParameter.setRolParamShownDescription("");
        rolParameter.setRolParChrgRoyHopperPct(null);
        rolParameter.setRolParTransChrgRoyHopper(false);
        rolParameter.setTechnology(new Technology());

        try {

            rolParameterService.saveRolParameter(rolParameter);

        } catch (RolParameterConstraintException ce) {
            checkConstraintException(ce, "Crop is required");
        }

    }

    /**
     * @throws RolParameterConstraintException
     * @throws RolParameterNotFoundException
     */
    @Test
    public void test_save_rol_parameter_with_technology_null_expected_valid_contraint_exception()
            throws RolParameterConstraintException, RolParameterNotFoundException {

        RolParameter rolParameter = new RolParameter();
        rolParameter.setCommissionType(new CommissionType());
        rolParameter.setCrop(new Crop());
        rolParameter.setItsUnitToRolParameters(new HashSet<ItsUnitToRolParameter>());
        rolParameter.setOperationalYearType(new OperationalYearType());
        rolParameter.setRolFrameGroup(new RolFrameGroup());
        rolParameter.setRolParameterDescription("");
        rolParameter.setRolParameterMaterialSapId("");
        rolParameter.setRolParameterSeasonBonus(false);
        rolParameter.setRolParameterSendToErp(false);
        rolParameter.setRolParameterSequence(new Integer(0));
        rolParameter.setRolParamShownDescription("");
        rolParameter.setRolParChrgRoyHopperPct(null);
        rolParameter.setRolParTransChrgRoyHopper(false);
        rolParameter.setTechnology(null);

        try {

            rolParameterService.saveRolParameter(rolParameter);

        } catch (RolParameterConstraintException ce) {
            checkConstraintException(ce, "Technology is required");
        }

    }

    /**
     * @throws RolParameterConstraintException
     * @throws RolParameterNotFoundException
     */
    @Test
    public void test_save_rol_parameter_with_description_null_expected_valid_contraint_exception()
            throws RolParameterConstraintException, RolParameterNotFoundException {

        RolParameter rolParameter = new RolParameter();
        rolParameter.setCommissionType(new CommissionType());
        rolParameter.setCrop(new Crop());
        rolParameter.setItsUnitToRolParameters(new HashSet<ItsUnitToRolParameter>());
        rolParameter.setOperationalYearType(new OperationalYearType());
        rolParameter.setRolFrameGroup(new RolFrameGroup());
        rolParameter.setRolParameterDescription("");
        rolParameter.setRolParameterMaterialSapId("");
        rolParameter.setRolParameterSeasonBonus(false);
        rolParameter.setRolParameterSendToErp(false);
        rolParameter.setRolParameterSequence(new Integer(0));
        rolParameter.setRolParamShownDescription("");
        rolParameter.setRolParChrgRoyHopperPct(null);
        rolParameter.setRolParTransChrgRoyHopper(false);
        rolParameter.setTechnology(new Technology());

        try {

            rolParameterService.saveRolParameter(rolParameter);

        } catch (RolParameterConstraintException ce) {
            checkConstraintException(ce, "Description is required");
        }

    }

    /**
     * @throws RolParameterConstraintException
     * @throws RolParameterNotFoundException
     */
    @Test
    public void test_save_rol_parameter_with_commision_type_null_expected_valid_contraint_exception()
            throws RolParameterConstraintException, RolParameterNotFoundException {

        RolParameter rolParameter = new RolParameter();
        rolParameter.setCommissionType(null);
        rolParameter.setCrop(new Crop());
        rolParameter.setItsUnitToRolParameters(new HashSet<ItsUnitToRolParameter>());
        rolParameter.setOperationalYearType(new OperationalYearType());
        rolParameter.setRolFrameGroup(new RolFrameGroup());
        rolParameter.setRolParameterDescription("");
        rolParameter.setRolParameterMaterialSapId("");
        rolParameter.setRolParameterSeasonBonus(false);
        rolParameter.setRolParameterSendToErp(false);
        rolParameter.setRolParameterSequence(new Integer(0));
        rolParameter.setRolParamShownDescription("");
        rolParameter.setRolParChrgRoyHopperPct(null);
        rolParameter.setRolParTransChrgRoyHopper(false);
        rolParameter.setTechnology(new Technology());

        try {

            rolParameterService.saveRolParameter(rolParameter);

        } catch (RolParameterConstraintException ce) {
            checkConstraintException(ce, "Commision type is required");
        }

    }

    /**
     * @throws RolParameterConstraintException
     * @throws RolParameterNotFoundException
     */
    @Test
    public void test_save_rol_parameter_with_shown_description_null_expected_valid_contraint_exception()
            throws RolParameterConstraintException, RolParameterNotFoundException {

        RolParameter rolParameter = new RolParameter();
        rolParameter.setCommissionType(new CommissionType());
        rolParameter.setCrop(new Crop());
        rolParameter.setItsUnitToRolParameters(new HashSet<ItsUnitToRolParameter>());
        rolParameter.setOperationalYearType(new OperationalYearType());
        rolParameter.setRolFrameGroup(new RolFrameGroup());
        rolParameter.setRolParameterDescription("");
        rolParameter.setRolParameterMaterialSapId("");
        rolParameter.setRolParameterSeasonBonus(false);
        rolParameter.setRolParameterSendToErp(false);
        rolParameter.setRolParameterSequence(new Integer(0));
        rolParameter.setRolParamShownDescription("");
        rolParameter.setRolParChrgRoyHopperPct(null);
        rolParameter.setRolParTransChrgRoyHopper(false);
        rolParameter.setTechnology(new Technology());

        try {

            rolParameterService.saveRolParameter(rolParameter);

        } catch (RolParameterConstraintException ce) {
            checkConstraintException(ce, "Shown description is required");
        }

    }

    /**
     * @throws RolParameterConstraintException
     * @throws RolParameterNotFoundException
     */
    @Test
    public void test_save_rol_parameter_with_frame_group_null_expected_valid_contraint_exception()
            throws RolParameterConstraintException, RolParameterNotFoundException {

        RolParameter rolParameter = new RolParameter();
        rolParameter.setCommissionType(new CommissionType());
        rolParameter.setCrop(new Crop());
        rolParameter.setItsUnitToRolParameters(new HashSet<ItsUnitToRolParameter>());
        rolParameter.setOperationalYearType(new OperationalYearType());
        rolParameter.setRolFrameGroup(null);
        rolParameter.setRolParameterDescription("");
        rolParameter.setRolParameterMaterialSapId("");
        rolParameter.setRolParameterSeasonBonus(false);
        rolParameter.setRolParameterSendToErp(false);
        rolParameter.setRolParameterSequence(new Integer(0));
        rolParameter.setRolParamShownDescription("");
        rolParameter.setRolParChrgRoyHopperPct(null);
        rolParameter.setRolParTransChrgRoyHopper(false);
        rolParameter.setTechnology(new Technology());

        try {

            rolParameterService.saveRolParameter(rolParameter);

        } catch (RolParameterConstraintException ce) {
            checkConstraintException(ce, "Frame Group is required");
        }

    }

    /**
     * @throws RolParameterConstraintException
     * @throws RolParameterNotFoundException
     */
    @Test
    public void test_save_rol_parameter_with_sequence_null_expected_valid_contraint_exception()
            throws RolParameterConstraintException, RolParameterNotFoundException {

        RolParameter rolParameter = new RolParameter();
        rolParameter.setCommissionType(new CommissionType());
        rolParameter.setCrop(new Crop());
        rolParameter.setItsUnitToRolParameters(new HashSet<ItsUnitToRolParameter>());
        rolParameter.setOperationalYearType(new OperationalYearType());
        rolParameter.setRolFrameGroup(new RolFrameGroup());
        rolParameter.setRolParameterDescription("");
        rolParameter.setRolParameterMaterialSapId("");
        rolParameter.setRolParameterSeasonBonus(false);
        rolParameter.setRolParameterSendToErp(false);
        rolParameter.setRolParameterSequence(null);
        rolParameter.setRolParamShownDescription("");
        rolParameter.setRolParChrgRoyHopperPct(BigDecimal.ONE);
        rolParameter.setRolParTransChrgRoyHopper(false);
        rolParameter.setTechnology(new Technology());

        try {

            rolParameterService.saveRolParameter(rolParameter);

        } catch (RolParameterConstraintException ce) {
            checkConstraintException(ce, "Parameter sequence is required");
        }

    }

    /**
     * @throws RolParameterConstraintException
     * @throws RolParameterNotFoundException
     */
    @Test
    public void test_save_rol_parameter_with_rolparchrgroy_hopper_pct_null_expected_valid_contraint_exception()
            throws RolParameterConstraintException, RolParameterNotFoundException {

        RolParameter rolParameter = new RolParameter();
        rolParameter.setCommissionType(new CommissionType());
        rolParameter.setCrop(new Crop());
        rolParameter.setItsUnitToRolParameters(new HashSet<ItsUnitToRolParameter>());
        rolParameter.setOperationalYearType(new OperationalYearType());
        rolParameter.setRolFrameGroup(new RolFrameGroup());
        rolParameter.setRolParameterDescription("");
        rolParameter.setRolParameterMaterialSapId("");
        rolParameter.setRolParameterSeasonBonus(false);
        rolParameter.setRolParameterSendToErp(false);
        rolParameter.setRolParameterSequence(null);
        rolParameter.setRolParamShownDescription("");
        rolParameter.setRolParChrgRoyHopperPct(null);
        rolParameter.setRolParTransChrgRoyHopper(true);
        rolParameter.setTechnology(new Technology());

        try {

            rolParameterService.saveRolParameter(rolParameter);

        } catch (RolParameterConstraintException ce) {
            checkConstraintException(ce, "Charging Royalt Hope Percent is required");
        }

    }

    /**
     * @throws RolParameterConstraintException
     * @throws RolParameterNotFoundException
     */
    @Test
    public void test_save_rol_parameter_with_empty_unit_list_expected_valid_contraint_exception()
            throws RolParameterConstraintException, RolParameterNotFoundException {

        RolParameter rolParameter = new RolParameter();
        rolParameter.setCommissionType(new CommissionType());
        rolParameter.setCrop(new Crop());
        rolParameter.setItsUnitToRolParameters(new HashSet<ItsUnitToRolParameter>());
        rolParameter.setOperationalYearType(new OperationalYearType());
        rolParameter.setRolFrameGroup(new RolFrameGroup());
        rolParameter.setRolParameterDescription("");
        rolParameter.setRolParameterMaterialSapId("");
        rolParameter.setRolParameterSeasonBonus(false);
        rolParameter.setRolParameterSendToErp(false);
        rolParameter.setRolParameterSequence(null);
        rolParameter.setRolParamShownDescription("");
        rolParameter.setRolParChrgRoyHopperPct(null);
        rolParameter.setRolParTransChrgRoyHopper(true);
        rolParameter.setTechnology(new Technology());

        try {

            rolParameterService.saveRolParameter(rolParameter);

        } catch (RolParameterConstraintException ce) {
            checkConstraintException(ce, "At least one unit is mandatory.");
        }

    }

    /**
     * @throws RolParameterConstraintException
     * @throws RolParameterNotFoundException
     */
    @Test
    public void test_save_rol_parameter_with_valid_parameter_filled_expected_success()
            throws RolParameterConstraintException, RolParameterNotFoundException {

        // Load dbunit
        setupDBUnit();

        // Build a valid rol parameter
        RolParameter rolParameter = new RolParameter();
        rolParameter.setId(null);
        rolParameter.setCommissionType((CommissionType) getSession().get(CommissionType.class, 900000001L));
        rolParameter.setCrop((Crop) getSession().get(Crop.class, 900000002L));

        ItsUnity unity = (ItsUnity) getSession().get(ItsUnity.class, 900000003L);
        Assert.assertNotNull(unity);

        // Create a ItsUnit
        rolParameter.setItsUnitToRolParameters(new HashSet<ItsUnitToRolParameter>());
        ItsUnitToRolParameter itsUnitToRolParameter = new ItsUnitToRolParameter(rolParameter, unity);
        rolParameter.getItsUnitToRolParameters().add(itsUnitToRolParameter);

        rolParameter.setOperationalYearType((OperationalYearType) getSession().get(OperationalYearType.class,
                900000001L));
        rolParameter.setRolFrameGroup((RolFrameGroup) getSession().get(RolFrameGroup.class, 1L));

        rolParameter.setRolParameterDescription("blah!");
        rolParameter.setRolParameterMaterialSapId("blah!");
        rolParameter.setRolParameterSeasonBonus(false);
        rolParameter.setRolParameterSendToErp(false);
        rolParameter.setRolParameterSequence(new Integer(1));
        rolParameter.setRolParamShownDescription("Blah!");
        rolParameter.setRolParChrgRoyHopperPct(null);
        rolParameter.setRolParTransChrgRoyHopper(false);
        rolParameter.setTechnology((Technology) getSession().get(Technology.class, 900000001L));

        // Save parameter
        rolParameterService.saveRolParameter(rolParameter);
        Assert.assertNotNull("Expected a valid id for rol parameter. This wasnt persisted.", rolParameter.getId());

    }

    /**
     * @throws RolParameterConstraintException
     * @throws RolParameterNotFoundException
     */
    @Test
    public void test_update_rol_parameter_expected_success() throws RolParameterConstraintException,
            RolParameterNotFoundException {

        // Load dbunit
        setupDBUnit();

        // Build a valid rol parameter
        RolParameter rolParameter = (RolParameter) getSession().get(RolParameter.class, 900000001L);

        // Verify if parameter just have only one unit
        Assert.assertTrue("Expected 1 units.", rolParameter.getItsUnitToRolParameters().size() == 1);

        // Get unity
        ItsUnity unity = (ItsUnity) getSession().get(ItsUnity.class, 900000001L);
        Assert.assertNotNull(unity);

        // Added a new unit
        ItsUnitToRolParameter itsUnitToRolParameter = new ItsUnitToRolParameter(rolParameter, unity);
        itsUnitToRolParameter.setRolParameter(rolParameter);
        rolParameter.getItsUnitToRolParameters().add(itsUnitToRolParameter);

        // Update parameter
        rolParameterService.saveRolParameter(rolParameter);

        // Find rol parameter again
        rolParameter = (RolParameter) getSession().get(RolParameter.class, 900000001L);
        Assert.assertTrue("Expected 2 units. This wasnt persisted.",
                rolParameter.getItsUnitToRolParameters().size() == 2);

    }

    /**
     * @throws RolParameterAlreadyUsedException
     * 
     */
    @Test(expected = IllegalArgumentException.class)
    public void test_remove_rol_parameter_null_expected_illegal_argument_exception()
            throws RolParameterAlreadyUsedException {

        rolParameterService.removeRolParameter(null);

    }

    /**
     * @throws RolParameterAlreadyUsedException
     * 
     */
    @Test
    public void test_remove_rol_parameter_expected_success() throws RolParameterAlreadyUsedException {

        // load dbunit
        setupDBUnit();

        // Find parameter
        RolParameter parameter = (RolParameter) getSession().get(RolParameter.class, 900000001L);

        // Remove it
        rolParameterService.removeRolParameter(parameter);

        // Verify if was deleted
        parameter = (RolParameter) getSession().get(RolParameter.class, 900000001L);
        Assert.assertNull("Parameter must be deleted.", parameter);

    }

    /**
     * @throws RolParameterAlreadyUsedException
     * 
     */
    @Test(expected = RolParameterAlreadyUsedException.class)
    public void test_remove_rol_parameter_used_parameter_by_rol_expected_alredy_used_parameter_exception()
            throws RolParameterAlreadyUsedException {

        // load dbunit
        setupDBUnit();

        // Find parameter
        RolParameter parameter = (RolParameter) getSession().get(RolParameter.class, 900000002L);

        // Remove it
        rolParameterService.removeRolParameter(parameter);

    }

    /**
     * 
     */
    @Test(expected = IllegalArgumentException.class)
    public void test_search_rol_parameter_with_null_crop_expected_illegal_argument_exception() {
        rolParameterService.searchRolParametersByCrop(null);
    }

    /**
     * 
     */
    @Test
    public void test_search_rol_parameter_with_valid_crop_expected_sucess() {

        // Load dbunit
        setupDBUnit();

        // Find crop
        Crop crop = (Crop) getSession().get(Crop.class, 900000001L);

        // Execute search
        List<RolParameter> parameters = rolParameterService.searchRolParametersByCrop(crop);
        Assert.assertNotNull("Expected some parameters.", parameters);
        Assert.assertEquals("Expected 3 parameters for this crop.", 3, parameters.size());

        // Check all parameter crop
        for (RolParameter param : parameters) {
            Assert.assertEquals("Expected only param with crop " + crop, crop, param.getCrop());
        }
    }

    /**
     * 
     */
    @Test
    public void test_search_rol_parameter_with_valid_crop_have_rol_parameters_without_material_sap_expected_empty_list() {

        // Load dbunit
        setupDBUnit();

        // Find crop
        Crop crop = (Crop) getSession().get(Crop.class, 900000002L);

        // Execute search
        List<RolParameter> parameters = rolParameterService.searchRolParametersByCrop(crop);
        Assert.assertNotNull("Expected not null parameters.", parameters);
        Assert.assertTrue("Expected empty list because parameters have empty material sap code.", parameters.isEmpty());

    }

    /**
     * Verify a specific violation constraint.
     * 
     * @param RolParameterConstraintException
     */
    private void checkConstraintException(RolParameterConstraintException cce, String message) {

        // Verify null and empty list
        Assert.assertNotNull(cce.getViolations());
        Assert.assertFalse("Expected not empty violation list.", cce.getViolations().isEmpty());

        // Check especifique constraint
        for (ConstraintViolation contraint : cce.getViolations()) {

            if (message.equalsIgnoreCase(contraint.getMessage())) {
                return;
            }

        }

        Assert.fail("Expected contraint violation for '" + message + "'.");
        cce.printStackTrace();
    }

}
