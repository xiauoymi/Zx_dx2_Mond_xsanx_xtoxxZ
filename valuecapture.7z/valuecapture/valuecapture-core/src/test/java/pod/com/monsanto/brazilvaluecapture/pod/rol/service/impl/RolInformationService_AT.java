package com.monsanto.brazilvaluecapture.pod.rol.service.impl;

import java.math.BigDecimal;
import java.util.Calendar;
import java.util.List;

import junit.framework.Assert;

import org.hibernate.criterion.Projections;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.monsanto.brazilvaluecapture.core.base.model.bean.Company;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Crop;
import com.monsanto.brazilvaluecapture.core.commercialhierarchy.model.bean.ItsDistrict;
import com.monsanto.brazilvaluecapture.core.commercialhierarchy.model.bean.ItsRegion;
import com.monsanto.brazilvaluecapture.core.commercialhierarchy.model.bean.ItsUnity;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Customer;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Technology;
import com.monsanto.brazilvaluecapture.core.foundation.test.AbstractServiceIntegrationTests;
import com.monsanto.brazilvaluecapture.core.foundation.test.dbunit.DbUnitHelper;
import com.monsanto.brazilvaluecapture.core.foundation.util.CalendarUtil;
import com.monsanto.brazilvaluecapture.pod.rol.model.bean.RolStatus;
import com.monsanto.brazilvaluecapture.pod.rol.model.bean.VolumeToFixDTO;
import com.monsanto.brazilvaluecapture.pod.rol.model.service.ReportOnLineVolumeToFixFilter;
import com.monsanto.brazilvaluecapture.pod.rol.model.service.RolInformationService;

/**
 * Unit class to test Rol Information Service.
 * 
 * @author cmiranda
 * 
 */
public class RolInformationService_AT extends AbstractServiceIntegrationTests {

    @Autowired
    private RolInformationService rolInformationService;

    /**
     * Configure database data.
     */
    public void setupDB() {

        // load rol-status
        int rolStatusCount = getSession().createCriteria(RolStatus.class).list().size();
        if (rolStatusCount == 0) {
            DbUnitHelper.setup("classpath:data/pod/rol/rol-status-dataset.xml");
        }

        // Load dbunit
        DbUnitHelper.setup("classpath:data/core/fixture-system-dataset.xml",
                "classpath:data/core/participant-dataset.xml",
                "classpath:data/commercialhierarchy/commercialhierarchy-dataset.xml",
                "classpath:data/pod/rol/rol-parameters-dataset.xml",
                "classpath:data/pod/rol/report-online-affiliates-dataset.xml",
                "classpath:data/pod/rol/counter-price-dataset.xml");

        // WARNING - This dataset emulate the view, keep this sincronized
        // with data base and others datasets
        if (!getAssumptionTest().isEnvironmentWithSQLANSI()) {
            DbUnitHelper.setup("classpath:data/core/vw-report-online-volume-to-fix-dataset.xml");
        }

    }

    public void setupDBValueScenary() {

        // Load rol status
        int rolStatusCount = (Integer) getSession().createCriteria(RolStatus.class)
                .setProjection(Projections.count("id")).uniqueResult();
        if (rolStatusCount == 0) {
            DbUnitHelper.setup("classpath:data/pod/rol/rol-status-dataset.xml");
        }

        DbUnitHelper.setup("classpath:data/core/report-online-volume-to-fix-dataset.xml");

        // WARNING - This dataset emulate the view, keep this sincronized
        // with data base and others datasets
        if (!getAssumptionTest().isEnvironmentWithSQLANSI()) {
            DbUnitHelper.setup("classpath:data/core/vw-report-online-volume-to-fix-dataset.xml");
        }

    }

    @Test(expected = IllegalArgumentException.class)
    public void test_search_volume_to_fix_with_null_filter_expecte_illegal_argument_exception() {
        rolInformationService.searchVolumeToFixByFilter(null);
    }

    @Test(expected = IllegalArgumentException.class)
    public void test_search_volume_to_fix_with_null_company_expecte_illegal_argument_exception() {
        rolInformationService.searchVolumeToFixByFilter(new ReportOnLineVolumeToFixFilter());
    }

    @Test(expected = IllegalArgumentException.class)
    public void test_search_volume_to_fix_with_empty_technologies_expecte_illegal_argument_exception() {

        // Create filter with fake company, and without technologies
        ReportOnLineVolumeToFixFilter filter = new ReportOnLineVolumeToFixFilter();
        filter.setCompany(new Company());

        rolInformationService.searchVolumeToFixByFilter(new ReportOnLineVolumeToFixFilter());
    }

    @Test
    public void test_search_volume_to_fix_by_valid_filter() {

        // Load database
        setupDB();

        // Load filter
        ReportOnLineVolumeToFixFilter filter = new ReportOnLineVolumeToFixFilter();
        filter.setCompany((Company) getSession().get(Company.class, 990000002L));
        Assert.assertNotNull(filter.getCompany());
        filter.setCrop((Crop) getSession().get(Crop.class, 900000001L));
        Assert.assertNotNull(filter.getCrop());
        Technology technology = (Technology) getSession().get(Technology.class, 900000001L);
        Assert.assertNotNull(technology);
        filter.getTechnologies().add(technology);

        // Set a valid period for rol
        filter.setStartRolPeriod(CalendarUtil.getDate(2200, Calendar.FEBRUARY, 1));
        filter.setEndRolPeriod(CalendarUtil.getDate(2212, Calendar.OCTOBER, 1));

        // Set a valid credit consumption range
        filter.setStartCreditConsumptionPeriod(CalendarUtil.getDate(1500, Calendar.APRIL, 22));
        filter.setEndCreditConsumptionPeriod(CalendarUtil.getDate(3121, Calendar.NOVEMBER, 1));

        // Execute search
        List<VolumeToFixDTO> result = rolInformationService.searchVolumeToFixByFilter(filter);

        Assert.assertNotNull(result);
        Assert.assertFalse("Expected at least one record.", result.isEmpty());

        // Validate result with filter
        for (VolumeToFixDTO dto : result) {

            System.out.println("---------------------------------------------------");
            System.out.println("aff unit sap desc: " + dto.getAffiliateUnitySapDesc());
            System.out.println("aff reg sap des: " + dto.getAffiliateRegionSapDesc());
            System.out.println("aff dist sap des: " + dto.getAffiliateRegionSapDesc());
            System.out.println("mat unit sap desc: " + dto.getMatrixUnitySapDesc());
            System.out.println("mat reg sap des: " + dto.getMatrixRegionSapDesc());
            System.out.println("mat dist sap des: " + dto.getMatrixRegionSapDesc());
            System.out.println("---------------------------------------------------");

            Assert.assertEquals(filter.getCrop().getDescription(), dto.getCropName());
            Assert.assertEquals(filter.getCompany().getDescription(), dto.getCompanyName());
            Assert.assertEquals(technology.getDescription(), dto.getTechnologyName());
            Assert.assertTrue(
                    "Volume fix and paid for others years must be zero, because filter is not a full year range (january until december).",
                    dto.getVolumeFixPaidOldYear().getAmount().compareTo(BigDecimal.ZERO) == 0);
            Assert.assertTrue(dto.getVolumeReceived().getAmount().compareTo(BigDecimal.ZERO) > 0);
        }
    }

    @Test
    public void test_search_volume_to_fix_by_filter_and_affiliate_invalid_expected_empty_result() {

        // Load database
        setupDB();

        // Build filter
        ReportOnLineVolumeToFixFilter filter = new ReportOnLineVolumeToFixFilter();
        filter.setCompany((Company) getSession().get(Company.class, 990000002L));
        Assert.assertNotNull(filter.getCompany());
        filter.setCrop((Crop) getSession().get(Crop.class, 900000001L));
        Assert.assertNotNull(filter.getCrop());
        Technology technology = (Technology) getSession().get(Technology.class, 900000001L);
        Assert.assertNotNull(technology);
        filter.getTechnologies().add(technology);

        // Load matrix
        filter.setAffiliate((Customer) getSession().get(Customer.class, 999000011L));
        Assert.assertNotNull(filter.getAffiliate());

        // Set a valid period for rol
        filter.setStartRolPeriod(CalendarUtil.getDate(2200, Calendar.FEBRUARY, 1));
        filter.setEndRolPeriod(CalendarUtil.getDate(2212, Calendar.OCTOBER, 1));

        // Set a valid credit consumption range
        filter.setStartCreditConsumptionPeriod(CalendarUtil.getDate(1500, Calendar.APRIL, 22));
        filter.setEndCreditConsumptionPeriod(CalendarUtil.getDate(3121, Calendar.NOVEMBER, 1));

        // Execute search
        List<VolumeToFixDTO> result = rolInformationService.searchVolumeToFixByFilter(filter);

        Assert.assertNotNull(result);
        Assert.assertTrue("Expected empty result.", result.isEmpty());

    }

    @Test
    public void test_search_volume_to_fix_by_filter_validate_values() {

        // Load database
        setupDBValueScenary();

        // Build filter
        ReportOnLineVolumeToFixFilter filter = new ReportOnLineVolumeToFixFilter();
        filter.setCompany((Company) getSession().get(Company.class, 999900001L));
        filter.setCrop((Crop) getSession().get(Crop.class, 999900001L));
        Technology technology = (Technology) getSession().get(Technology.class, 999900001L);
        filter.getTechnologies().add(technology);

        Assert.assertNotNull(technology);
        Assert.assertNotNull(filter.getCrop());
        Assert.assertNotNull(filter.getCompany());

        // Set a valid period for rol
        filter.setStartRolPeriod(CalendarUtil.getDate(3010, Calendar.JANUARY, 1));
        filter.setEndRolPeriod(CalendarUtil.getDate(3010, Calendar.DECEMBER, 1));

        // Set a valid credit consumption range
        filter.setStartCreditConsumptionPeriod(CalendarUtil.getDate(3010, Calendar.JANUARY, 1));
        filter.setEndCreditConsumptionPeriod(CalendarUtil.getDate(3010, Calendar.FEBRUARY, 15));

        // Execute search
        List<VolumeToFixDTO> result = rolInformationService.searchVolumeToFixByFilter(filter);

        Assert.assertNotNull(result);
        Assert.assertFalse("Expected at least one record.", result.isEmpty());

        // Validate result with filter
        for (VolumeToFixDTO dto : result) {
            Assert.assertEquals(filter.getCrop().getDescription(), dto.getCropName());
            Assert.assertEquals(filter.getCompany().getDescription(), dto.getCompanyName());
            Assert.assertEquals(technology.getDescription(), dto.getTechnologyName());

            Assert.assertTrue("Expected 10.00 for volume received but found " + dto.getVolumeReceived().getAmount(),
                    dto.getVolumeReceived().getAmount().compareTo(new BigDecimal(10)) == 0);

            Assert.assertTrue("Expected 100.00 for volume fix and paid actual year but found "
                    + dto.getVolumeFixPaidActualYear().getAmount(), dto.getVolumeFixPaidActualYear().getAmount()
                    .compareTo(new BigDecimal(100)) == 0);

            Assert.assertTrue("Expected 11000.00 for volume fix and paid other years but found "
                    + dto.getVolumeFixPaidOldYear().getAmount(),
                    dto.getVolumeFixPaidOldYear().getAmount().compareTo(new BigDecimal(11000)) == 0);

            Assert.assertTrue("Expected 0.01 for credit consumption but found "
                    + dto.getVolumeCreditConsumption().getAmount(), dto.getVolumeCreditConsumption().getAmount()
                    .floatValue() == new BigDecimal(0.01).floatValue());

            Assert.assertTrue("Expected " + new BigDecimal(10 - 100 - 11000 - 0.01) + " for amount to fix but found "
                    + dto.getAmountVolumeToFix().getAmount(),
                    dto.getAmountVolumeToFix().getAmount().floatValue() == new BigDecimal(10 - 100 - 11000 - 0.01)
                            .floatValue());
        }

    }

    @Test
    public void test_search_volume_to_fix_by_filter_and_affiliate_unity() {

        // Load database
        setupDBValueScenary();

        // Load filter
        ReportOnLineVolumeToFixFilter filter = new ReportOnLineVolumeToFixFilter();
        filter.setCompany((Company) getSession().get(Company.class, 999900001L));
        Assert.assertNotNull(filter.getCompany());
        filter.setCrop((Crop) getSession().get(Crop.class, 999900001L));
        Assert.assertNotNull(filter.getCrop());
        Technology technology = (Technology) getSession().get(Technology.class, 999900001L);
        Assert.assertNotNull(technology);
        filter.getTechnologies().add(technology);
        filter.setAffiliateUnity((ItsUnity) getSession().get(ItsUnity.class, 999900001L));
        Assert.assertNotNull(filter.getAffiliateUnity());

        // Set a valid period for rol
        filter.setStartRolPeriod(CalendarUtil.getDate(3009, Calendar.JANUARY, 1));
        filter.setEndRolPeriod(CalendarUtil.getDate(3010, Calendar.JUNE, 1));

        // Set a valid credit consumption range
        filter.setStartCreditConsumptionPeriod(CalendarUtil.getDate(3010, Calendar.JANUARY, 1));
        filter.setEndCreditConsumptionPeriod(CalendarUtil.getDate(3010, Calendar.FEBRUARY, 15));

        // Execute search
        List<VolumeToFixDTO> result = rolInformationService.searchVolumeToFixByFilter(filter);

        Assert.assertNotNull(result);
        Assert.assertFalse("Expected at least one record.", result.isEmpty());

        // Validate result with filter
        for (VolumeToFixDTO dto : result) {
            Assert.assertEquals(filter.getCrop().getDescription(), dto.getCropName());
            Assert.assertEquals(filter.getCompany().getDescription(), dto.getCompanyName());
            Assert.assertEquals(technology.getDescription(), dto.getTechnologyName());
            Assert.assertEquals(filter.getAffiliateUnity().getUnitySapDesc(), dto.getAffiliateUnitySapDesc());
            Assert.assertTrue(
                    "Volume fix and paid for others years must be zero, because filter is not a full year range (january until december).",
                    dto.getVolumeFixPaidOldYear().getAmount().compareTo(BigDecimal.ZERO) == 0);
            Assert.assertTrue(dto.getVolumeCreditConsumption().getAmount().compareTo(BigDecimal.ZERO) > 0);
            Assert.assertTrue(dto.getVolumeFixPaidActualYear().getAmount().compareTo(BigDecimal.ZERO) > 0);
            Assert.assertTrue(dto.getVolumeReceived().getAmount().compareTo(BigDecimal.ZERO) > 0);
        }
    }

    @Test
    public void test_search_volume_to_fix_by_filter_and_affiliate_unity_region_district() {

        // Load database
        setupDBValueScenary();

        // Load filter
        ReportOnLineVolumeToFixFilter filter = new ReportOnLineVolumeToFixFilter();
        filter.setCompany((Company) getSession().get(Company.class, 999900001L));
        Assert.assertNotNull(filter.getCompany());
        filter.setCrop((Crop) getSession().get(Crop.class, 999900001L));
        Assert.assertNotNull(filter.getCrop());
        Technology technology = (Technology) getSession().get(Technology.class, 999900001L);
        Assert.assertNotNull(technology);
        filter.getTechnologies().add(technology);

        filter.setAffiliateUnity((ItsUnity) getSession().get(ItsUnity.class, 999900001L));
        Assert.assertNotNull(filter.getAffiliateUnity());

        filter.setAffiliateRegion((ItsRegion) getSession().get(ItsRegion.class, 999900001L));
        Assert.assertNotNull(filter.getAffiliateRegion());

        filter.setAffiliateDistrict((ItsDistrict) getSession().get(ItsDistrict.class, 999900001L));
        Assert.assertNotNull(filter.getAffiliateDistrict());

        // Set a valid period for rol
        filter.setStartRolPeriod(CalendarUtil.getDate(3009, Calendar.JANUARY, 1));
        filter.setEndRolPeriod(CalendarUtil.getDate(3010, Calendar.JUNE, 1));

        // Set a valid credit consumption range
        filter.setStartCreditConsumptionPeriod(CalendarUtil.getDate(3010, Calendar.JANUARY, 1));
        filter.setEndCreditConsumptionPeriod(CalendarUtil.getDate(3010, Calendar.FEBRUARY, 15));

        // Execute search
        List<VolumeToFixDTO> result = rolInformationService.searchVolumeToFixByFilter(filter);

        Assert.assertNotNull(result);
        Assert.assertFalse("Expected at least one record.", result.isEmpty());

        // Validate result with filter
        for (VolumeToFixDTO dto : result) {
            Assert.assertEquals(filter.getCrop().getDescription(), dto.getCropName());
            Assert.assertEquals(filter.getCompany().getDescription(), dto.getCompanyName());
            Assert.assertEquals(technology.getDescription(), dto.getTechnologyName());
            Assert.assertEquals(filter.getAffiliateUnity().getUnitySapDesc(), dto.getAffiliateUnitySapDesc());
            Assert.assertEquals(filter.getAffiliateRegion().getRegionSapDesc(), dto.getAffiliateRegionSapDesc());
            Assert.assertEquals(filter.getAffiliateDistrict().getDistrictSapDesc(), dto.getAffiliateDistrictSapDesc());
            Assert.assertTrue(
                    "Volume fix and paid for others years must be zero, because filter is not a full year range (january until december).",
                    dto.getVolumeFixPaidOldYear().getAmount().compareTo(BigDecimal.ZERO) == 0);
            Assert.assertTrue(dto.getVolumeCreditConsumption().getAmount().compareTo(BigDecimal.ZERO) > 0);
            Assert.assertTrue(dto.getVolumeFixPaidActualYear().getAmount().compareTo(BigDecimal.ZERO) > 0);
            Assert.assertTrue(dto.getVolumeReceived().getAmount().compareTo(BigDecimal.ZERO) > 0);
        }
    }

    @Test
    public void test_search_volume_to_fix_by_filter_and_matrix_unity_region_district() {

        // Load database
        setupDBValueScenary();

        // Load filter
        ReportOnLineVolumeToFixFilter filter = new ReportOnLineVolumeToFixFilter();
        filter.setCompany((Company) getSession().get(Company.class, 999900001L));
        Assert.assertNotNull(filter.getCompany());
        filter.setCrop((Crop) getSession().get(Crop.class, 999900001L));
        Assert.assertNotNull(filter.getCrop());
        Technology technology = (Technology) getSession().get(Technology.class, 999900001L);
        Assert.assertNotNull(technology);
        filter.getTechnologies().add(technology);

        filter.setMatrixUnity((ItsUnity) getSession().get(ItsUnity.class, 999900001L));
        Assert.assertNotNull(filter.getMatrixUnity());

        filter.setMatrixRegion((ItsRegion) getSession().get(ItsRegion.class, 999900001L));
        Assert.assertNotNull(filter.getMatrixRegion());

        filter.setMatrixDistrict((ItsDistrict) getSession().get(ItsDistrict.class, 999900001L));
        Assert.assertNotNull(filter.getMatrixDistrict());

        // Set a valid period for rol
        filter.setStartRolPeriod(CalendarUtil.getDate(3009, Calendar.JANUARY, 1));
        filter.setEndRolPeriod(CalendarUtil.getDate(3010, Calendar.JUNE, 1));

        // Set a valid credit consumption range
        filter.setStartCreditConsumptionPeriod(CalendarUtil.getDate(3010, Calendar.JANUARY, 1));
        filter.setEndCreditConsumptionPeriod(CalendarUtil.getDate(3010, Calendar.FEBRUARY, 15));

        // Execute search
        List<VolumeToFixDTO> result = rolInformationService.searchVolumeToFixByFilter(filter);

        Assert.assertNotNull(result);
        Assert.assertFalse("Expected at least one record.", result.isEmpty());

        // Validate result with filter
        for (VolumeToFixDTO dto : result) {
            Assert.assertEquals(filter.getCrop().getDescription(), dto.getCropName());
            Assert.assertEquals(filter.getCompany().getDescription(), dto.getCompanyName());
            Assert.assertEquals(technology.getDescription(), dto.getTechnologyName());
            Assert.assertEquals(filter.getMatrixUnity().getUnitySapDesc(), dto.getMatrixUnitySapDesc());
            Assert.assertEquals(filter.getMatrixRegion().getRegionSapDesc(), dto.getMatrixRegionSapDesc());
            Assert.assertEquals(filter.getMatrixDistrict().getDistrictSapDesc(), dto.getMatrixDistrictSapDesc());
            Assert.assertTrue(
                    "Volume fix and paid for others years must be zero, because filter is not a full year range (january until december).",
                    dto.getVolumeFixPaidOldYear().getAmount().compareTo(BigDecimal.ZERO) == 0);
            Assert.assertTrue(dto.getVolumeCreditConsumption().getAmount().compareTo(BigDecimal.ZERO) > 0);
            Assert.assertTrue(dto.getVolumeFixPaidActualYear().getAmount().compareTo(BigDecimal.ZERO) > 0);
            Assert.assertTrue(dto.getVolumeReceived().getAmount().compareTo(BigDecimal.ZERO) > 0);
        }
    }

    @Test
    public void test_search_volume_to_fix_by_filter_and_matrix() {

        // Load database
        setupDBValueScenary();

        // Build filter
        ReportOnLineVolumeToFixFilter filter = new ReportOnLineVolumeToFixFilter();
        filter.setCompany((Company) getSession().get(Company.class, 999900001L));
        Assert.assertNotNull(filter.getCompany());
        filter.setCrop((Crop) getSession().get(Crop.class, 999900001L));
        Assert.assertNotNull(filter.getCrop());
        Technology technology = (Technology) getSession().get(Technology.class, 999900001L);
        Assert.assertNotNull(technology);
        filter.getTechnologies().add(technology);

        // Load matrix
        filter.setMatrix((Customer) getSession().get(Customer.class, 999900002L));
        Assert.assertNotNull(filter.getMatrix());

        // Set a valid period for rol
        filter.setStartRolPeriod(CalendarUtil.getDate(3009, Calendar.JANUARY, 1));
        filter.setEndRolPeriod(CalendarUtil.getDate(3010, Calendar.JUNE, 1));

        // Set a valid credit consumption range
        filter.setStartCreditConsumptionPeriod(CalendarUtil.getDate(3010, Calendar.JANUARY, 1));
        filter.setEndCreditConsumptionPeriod(CalendarUtil.getDate(3010, Calendar.FEBRUARY, 15));

        // Execute search
        List<VolumeToFixDTO> result = rolInformationService.searchVolumeToFixByFilter(filter);

        Assert.assertNotNull(result);
        Assert.assertFalse("Expected at least one record.", result.isEmpty());

        // Validate result with filter
        for (VolumeToFixDTO dto : result) {
            Assert.assertEquals(filter.getCrop().getDescription(), dto.getCropName());
            Assert.assertEquals(filter.getCompany().getDescription(), dto.getCompanyName());
            Assert.assertEquals(technology.getDescription(), dto.getTechnologyName());
            Assert.assertTrue(
                    "Volume fix and paid for others years must be zero, because filter is not a full year range (january until december).",
                    dto.getVolumeFixPaidOldYear().getAmount().compareTo(BigDecimal.ZERO) == 0);
            Assert.assertTrue(dto.getVolumeCreditConsumption().getAmount().compareTo(BigDecimal.ZERO) > 0);
            Assert.assertTrue(dto.getVolumeFixPaidActualYear().getAmount().compareTo(BigDecimal.ZERO) > 0);
            Assert.assertTrue(dto.getVolumeReceived().getAmount().compareTo(BigDecimal.ZERO) > 0);
            Assert.assertEquals(filter.getMatrix().getName(), dto.getMatrixName());
        }
    }

    @Test
    public void test_search_volume_to_fix_by_filter_and_affiliate() {

        // Load database
        setupDBValueScenary();

        // Build filter
        ReportOnLineVolumeToFixFilter filter = new ReportOnLineVolumeToFixFilter();
        filter.setCompany((Company) getSession().get(Company.class, 999900001L));
        Assert.assertNotNull(filter.getCompany());
        filter.setCrop((Crop) getSession().get(Crop.class, 999900001L));
        Assert.assertNotNull(filter.getCrop());
        Technology technology = (Technology) getSession().get(Technology.class, 999900001L);
        Assert.assertNotNull(technology);
        filter.getTechnologies().add(technology);

        // Load matrix
        filter.setAffiliate((Customer) getSession().get(Customer.class, 999900001L));
        Assert.assertNotNull(filter.getAffiliate());

        // Set a valid period for rol
        filter.setStartRolPeriod(CalendarUtil.getDate(3009, Calendar.JANUARY, 1));
        filter.setEndRolPeriod(CalendarUtil.getDate(3010, Calendar.JUNE, 1));

        // Set a valid credit consumption range
        filter.setStartCreditConsumptionPeriod(CalendarUtil.getDate(3010, Calendar.JANUARY, 1));
        filter.setEndCreditConsumptionPeriod(CalendarUtil.getDate(3010, Calendar.FEBRUARY, 15));

        // Execute search
        List<VolumeToFixDTO> result = rolInformationService.searchVolumeToFixByFilter(filter);

        Assert.assertNotNull(result);
        Assert.assertFalse("Expected at least one record.", result.isEmpty());

        // Validate result with filter
        for (VolumeToFixDTO dto : result) {
            Assert.assertEquals(filter.getCrop().getDescription(), dto.getCropName());
            Assert.assertEquals(filter.getCompany().getDescription(), dto.getCompanyName());
            Assert.assertEquals(technology.getDescription(), dto.getTechnologyName());
            Assert.assertTrue(
                    "Volume fix and paid for others years must be zero, because filter is not a full year range (january until december).",
                    dto.getVolumeFixPaidOldYear().getAmount().compareTo(BigDecimal.ZERO) == 0);
            Assert.assertTrue(dto.getVolumeCreditConsumption().getAmount().compareTo(BigDecimal.ZERO) > 0);
            Assert.assertTrue(dto.getVolumeFixPaidActualYear().getAmount().compareTo(BigDecimal.ZERO) > 0);
            Assert.assertTrue(dto.getVolumeReceived().getAmount().compareTo(BigDecimal.ZERO) > 0);
            Assert.assertEquals(filter.getAffiliate().getName(), dto.getAffiliateName());
        }

    }
}