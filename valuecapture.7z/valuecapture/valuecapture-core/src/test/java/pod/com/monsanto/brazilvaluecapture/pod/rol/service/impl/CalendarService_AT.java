package com.monsanto.brazilvaluecapture.pod.rol.service.impl;

import java.util.Calendar;
import java.util.Date;
import java.util.List;

import junit.framework.Assert;

import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.monsanto.brazilvaluecapture.core.base.model.bean.Company;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Crop;
import com.monsanto.brazilvaluecapture.core.base.model.bean.OperationalYear;
import com.monsanto.brazilvaluecapture.core.base.model.dao.OperationalYearDAO;
import com.monsanto.brazilvaluecapture.core.customer.service.CustomerNotAllowedException;
import com.monsanto.brazilvaluecapture.core.customer.service.CustomerNotFoundException;
import com.monsanto.brazilvaluecapture.core.foundation.service.BusinessException;
import com.monsanto.brazilvaluecapture.core.foundation.service.EntityNotFoundException;
import com.monsanto.brazilvaluecapture.core.foundation.test.AbstractServiceIntegrationTests;
import com.monsanto.brazilvaluecapture.core.foundation.test.dbunit.DbUnitHelper;
import com.monsanto.brazilvaluecapture.core.grower.service.GrowerNotFoundException;
import com.monsanto.brazilvaluecapture.core.user.service.UserNotFoundException;
import com.monsanto.brazilvaluecapture.pod.rol.model.bean.PodCalendar;
import com.monsanto.brazilvaluecapture.pod.rol.model.service.PodCalendarException;
import com.monsanto.brazilvaluecapture.pod.rol.model.service.PodCalendarService;

/**
 * Unity test for PodCalendarService
 * 
 */
public class CalendarService_AT extends AbstractServiceIntegrationTests {

    @Autowired
    private OperationalYearDAO operYearDAO;
    
    @Autowired
    private PodCalendarService calendarService;

    @Before
    public void setup() {

    }

    public void setupDBUnit() throws GrowerNotFoundException, UserNotFoundException, CustomerNotFoundException,
            CustomerNotAllowedException {
        // Load dbunit
        String dataSetLocation1 = "classpath:data/core/fixture-system-dataset.xml";
        String dataSetLocation2 = "classpath:data/pod/calendar/grains-receipt-calendar-dataset.xml";
        DbUnitHelper.setup(dataSetLocation1, dataSetLocation2);

    }

    @Test
    public void searching_PODCalendar_by_operational_year() throws EntityNotFoundException, GrowerNotFoundException,
            UserNotFoundException, CustomerNotFoundException, CustomerNotAllowedException, PodCalendarException {
        setupDBUnit();
        OperationalYear operYear = operYearDAO.getByCandidateKey("2112");
        Company comp = (Company) getSession().load(Company.class, new Long(900000001));
        Crop crop = (Crop) getSession().load(Crop.class, new Long(900000001));

        List<PodCalendar> calList = calendarService.selectPodCalendarList(operYear, comp, crop);
        // Make sure 12 size list is returned
        Assert.assertEquals(12, calList.size());
        // Make sure the ones in positions 1 and 8 have null limit date
        Assert.assertTrue("Limit date must be null", calList.get(0).getLimitDate() == null);
        Assert.assertTrue("Limit date must be null", calList.get(7).getLimitDate() == null);
        // Make sure the ones in positions 6 and 7 have limit date not null
        Assert.assertTrue("Limit date must be NOT null", calList.get(5).getLimitDate() != null);
        Assert.assertTrue("Limit date must be NOT null", calList.get(6).getLimitDate() != null);
    }

    @Test
    public void select_Persisted_PODCalendar_by_operational_year() throws EntityNotFoundException,
            GrowerNotFoundException, UserNotFoundException, CustomerNotFoundException, CustomerNotAllowedException,
            PodCalendarException {
        setupDBUnit();
        OperationalYear operYear = operYearDAO.getByCandidateKey("2111");
        Company comp = (Company) getSession().load(Company.class, new Long(900000001));
        Crop crop = (Crop) getSession().load(Crop.class, new Long(900000001));
        // select a list that does not exist
        List<PodCalendar> calList = calendarService.selectPodCalendarList(operYear, comp, crop);
        // verify that the item has no id
        Assert.assertFalse("The list cannot be persisted. That means some of the ids may be null.",
                isListPersisted(calList));
        // select a persisted list
        List<PodCalendar> calPersistedList = calendarService.loadPersistedPodCalendarList(operYear, comp, crop);
        Assert.assertTrue("The list must be persisted. That means ALL of the ids are NOT null.",
                isListPersisted(calPersistedList));

    }

    private boolean isListPersisted(List<PodCalendar> podCalendarList) {
        boolean persisted = true;
        for (PodCalendar item : podCalendarList) {
            if (item.getId() == null) {
                persisted = false;
                break;
            }
        }
        return persisted;
    }

    @Test(expected = PodCalendarException.class)
    public void searching_PODCalendar_with_invalid_arguments() throws EntityNotFoundException, GrowerNotFoundException,
            UserNotFoundException, CustomerNotFoundException, CustomerNotAllowedException, PodCalendarException {
        setupDBUnit();
        OperationalYear operYear = operYearDAO.getByCandidateKey("2112");
        Crop crop = (Crop) getSession().load(Crop.class, new Long(900000001));

        List<PodCalendar> calList = calendarService.selectPodCalendarList(operYear, null, crop);
        Assert.assertEquals(2, calList.size());
    }

    @Test
    public void save_valid_PODCalendarList_with_ALL_limitDateItems_null() throws PodCalendarException,
            GrowerNotFoundException, UserNotFoundException, BusinessException, CustomerNotAllowedException {
        setupDBUnit();
        // search for PodCalendars that does not exist
        List<PodCalendar> calList = getlist_Year2012_Company_MonsantoUS_Crop_CandaDeAcucar();
        Assert.assertEquals(12, calList.size());
        Assert.assertTrue("Ids must be null", calList.get(0).getId() == null);
        Assert.assertTrue("Limit date must be null", calList.get(0).getLimitDate() == null);

        // Save the list
        calendarService.savePodCalendar(calList);

        // verify after save if the list receive ids for each PODCalendar
        calList = getlist_Year2012_Company_MonsantoUS_Crop_CandaDeAcucar();
        for (PodCalendar item : calList) {
            Assert.assertNotNull("The id must be not null", item.getId());
        }

    }

    @Test
    public void edit_valid_PODCalendarList_with_ALL_limitDateItems_null() throws PodCalendarException,
            GrowerNotFoundException, UserNotFoundException, BusinessException, CustomerNotAllowedException {
        setupDBUnit();
        // search for PodCalendars that does not exist
        List<PodCalendar> calList = getlist_Year2012_Company_MonsantoUS_Crop_CandaDeAcucar();

        // Save the list
        calendarService.savePodCalendar(calList);
        // Search again
        calList = getlist_Year2012_Company_MonsantoUS_Crop_CandaDeAcucar();
        // get 5th item and edit limit date
        PodCalendar pc = calList.get(4);
        Calendar cal = Calendar.getInstance();
        cal.clear();
        cal.set(2012, 4, 25);
        Date dt = cal.getTime();
        pc.setLimitDate(dt);
        calendarService.savePodCalendar(calList);

        // search again and verify if the limit date was edited correctly
        calList = getlist_Year2012_Company_MonsantoUS_Crop_CandaDeAcucar();
        pc = calList.get(4);
        Assert.assertEquals("The dates must be equal.", dt, pc.getLimitDate());

    }

    @Test(expected = PodCalendarException.class)
    public void save_invalid_PODCalendarList() throws PodCalendarException, GrowerNotFoundException,
            UserNotFoundException, BusinessException, CustomerNotAllowedException {
        setupDBUnit();
        // search for PodCalendars that does not exist
        List<PodCalendar> calList = getlist_Year2012_Company_MonsantoUS_Crop_CandaDeAcucar();
        // remove one item
        calList.remove(0);
        // try to Save the list with just 11 items
        calendarService.savePodCalendar(calList);
        Assert.fail();
    }

    @Test(expected = PodCalendarException.class)
    public void save_invalid_PODCalendarList_with_a_null_podcalendar() throws PodCalendarException,
            GrowerNotFoundException, UserNotFoundException, BusinessException, CustomerNotAllowedException {
        setupDBUnit();
        List<PodCalendar> calList = getlist_Year2012_Company_MonsantoUS_Crop_CandaDeAcucar();
        // null one item
        calList.set(1, null);

        // try to Save the list with a null element
        calendarService.savePodCalendar(calList);
        Assert.fail();
    }

    @Test
    public void select_pod_calendar_for_a_month() throws EntityNotFoundException, GrowerNotFoundException,
            UserNotFoundException, CustomerNotFoundException, CustomerNotAllowedException {
        setupDBUnit();
        // try to Save the list with just 11 items
        OperationalYear operYear = operYearDAO.getByCandidateKey("2112");
        // _MONSANTO DO BRASIL LTDA._
        Company comp = (Company) getSession().load(Company.class, new Long(900000001));
        // _SOJA_
        Crop crop = (Crop) getSession().load(Crop.class, new Long(900000001));
        PodCalendar podCal = calendarService.selectPodCalendar(operYear, comp, crop, 6);

        Assert.assertTrue(podCal.getId().equals(new Long(900000002)));

    }

    @Test(expected = IllegalArgumentException.class)
    public void select_pod_calendar_for_a_month_with_IllegalArgumentException() throws EntityNotFoundException,
            GrowerNotFoundException, UserNotFoundException, CustomerNotFoundException, CustomerNotAllowedException {

        setupDBUnit();
        OperationalYear operYear = operYearDAO.getByCandidateKey("2112");

        // _SOJA_
        Crop crop = (Crop) getSession().load(Crop.class, new Long(900000001));
        calendarService.selectPodCalendar(operYear, null, crop, 6);

        Assert.fail("the following exception is expected: IllegalArgumentException");

    }

    private List<PodCalendar> getlist_Year2012_Company_MonsantoUS_Crop_CandaDeAcucar() throws EntityNotFoundException,
            PodCalendarException {
        OperationalYear operYear = operYearDAO.getByCandidateKey("2112");
        // _MONSANTO US_
        Company comp = (Company) getSession().load(Company.class, new Long(900000002));
        // _CANA DE ACUCAR_
        Crop crop = (Crop) getSession().load(Crop.class, new Long(900000003));
        // Get a 12 size list with all ids null and all limitDateItems null
        return calendarService.selectPodCalendarList(operYear, comp, crop);
    }
}
