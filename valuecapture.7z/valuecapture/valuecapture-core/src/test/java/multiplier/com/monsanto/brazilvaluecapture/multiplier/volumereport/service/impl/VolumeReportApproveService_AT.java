package com.monsanto.brazilvaluecapture.multiplier.volumereport.service.impl;

import com.monsanto.brazilvaluecapture.core.account.model.bean.Account;
import com.monsanto.brazilvaluecapture.core.account.model.bean.Account.AccountType;
import com.monsanto.brazilvaluecapture.core.account.model.bean.ManualCreditTransactionType;
import com.monsanto.brazilvaluecapture.core.account.model.dao.AccountFilter;
import com.monsanto.brazilvaluecapture.core.account.service.impl.AccountService;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Document;
import com.monsanto.brazilvaluecapture.core.base.service.BaseService;
import com.monsanto.brazilvaluecapture.core.foundation.service.BusinessException;
import com.monsanto.brazilvaluecapture.core.foundation.service.EntityNotFoundException;
import com.monsanto.brazilvaluecapture.core.foundation.test.AbstractServiceIntegrationTests;
import com.monsanto.brazilvaluecapture.core.foundation.test.dbunit.DbUnitHelper;
import com.monsanto.brazilvaluecapture.core.grower.model.bean.Grower;
import com.monsanto.brazilvaluecapture.core.user.model.bean.ItsUser;
import com.monsanto.brazilvaluecapture.core.user.model.bean.UserContext;
import com.monsanto.brazilvaluecapture.core.user.model.bean.UserDecorator;
import com.monsanto.brazilvaluecapture.core.user.service.ManualCreditConstraintException;
import com.monsanto.brazilvaluecapture.core.user.service.UserNotFoundException;
import com.monsanto.brazilvaluecapture.core.user.service.UserService;
import com.monsanto.brazilvaluecapture.multiplier.cultivar.model.bean.Cultivar;
import com.monsanto.brazilvaluecapture.multiplier.volumereport.model.bean.*;
import com.monsanto.brazilvaluecapture.multiplier.volumereport.model.bean.VolumeReportApprovalDTO.ApprovalStateHolder;
import com.monsanto.brazilvaluecapture.multiplier.volumereport.model.dao.VolumeReportApprovalFilter;
import com.monsanto.brazilvaluecapture.multiplier.volumereport.service.VolumeReportApproveService;
import com.monsanto.brazilvaluecapture.multiplier.volumereport.service.VolumeReportReversalService;
import com.monsanto.brazilvaluecapture.multiplier.volumereport.service.VolumeReportService;
import com.monsanto.brazilvaluecapture.seedsale.harvest.model.bean.Harvest;
import com.monsanto.brazilvaluecapture.seedsale.quota.service.InsufficientQuotaForPhase6Approval;
import org.junit.Assert;
import org.junit.Ignore;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.List;

public class VolumeReportApproveService_AT extends AbstractServiceIntegrationTests {

    @Autowired
    private VolumeReportReversalService volumeReportReversalService;

    @Autowired
    private VolumeReportApproveService volumeReportApproveService;

    @Autowired
    private VolumeReportService volumeReportService;

    @Autowired
    private AccountService accountService;

    @Autowired
    private BaseService baseService;

    @Autowired
    private UserService userService;

    private static final BigDecimal TWENTY = BigDecimal.valueOf(20L);
    
    public void setupFixture() {
        DbUnitHelper.setup(
                "classpath:data/multiplier/basic-fixture.xml",
                "classpath:data/multiplier/volume-report-dataset.xml",
                "classpath:data/multiplier/volume-report-with-parent-dataset.xml");
    }

    @Test
    public void test_approve_phase1_when_detail_has_revenue_account_id_and_cultivar_charge_technology() throws InsufficientQuotaForPhase6Approval {
        setupFixture();
        
        ItsUser user = (ItsUser) getSession().get(ItsUser.class, 900000003L);
        
        VolumeReportDetail detail = (VolumeReportDetail) getSession().get(VolumeReportDetail.class, 900000003L);
        
        Long revenueId = 900000001L;
        detail.setVolumeReportDetailPhase1Status(VolumeReportStatus.REPORTED);
		detail.setRevenueAccountId(revenueId);
        saveAndFlush(detail);

        volumeReportApproveService.approve(VolumeReportTestData.generateApprovalDTO(VolumeReportFieldEnum.ENTERED_AREA, 900000003L), detail.getVolumeReportHeader(), VolumeReportTestData.mockUser(user.getLogin()));
        
        getSession().evict(detail);
        
        VolumeReportDetail newDetail = (VolumeReportDetail) getSession().get(VolumeReportDetail.class, 900000003L);
        
        Assert.assertEquals("Revenue Account Id does not match", revenueId, newDetail.getRevenueAccountId());
        Assert.assertEquals("Status does not match", VolumeReportStatus.WAITING_BILLING, newDetail.getVolumeReportDetailPhase1Status());
        Assert.assertEquals("User reprover login does not match", user.getLogin(), newDetail.getFieldByPhase(VolumeReportFieldEnum.ENTERED_AREA).getApproverLogin());
    }
    
    @Test
    public void test_approve_phase1_when_detail_has_revenue_account_id_and_cultivar_do_not_charge_technology() throws InsufficientQuotaForPhase6Approval {
        setupFixture();
        
        ItsUser user = (ItsUser) getSession().get(ItsUser.class, 900000003L);
        
        // Updating cultivar of detail used in the test to don't charge technology
        Cultivar detailCultivar = (Cultivar) getSession().get(Cultivar.class, 900000011L);
        detailCultivar.setChargeTechnology(Boolean.FALSE);
        saveAndFlush(detailCultivar);
        
        VolumeReportDetail detail = (VolumeReportDetail) getSession().get(VolumeReportDetail.class, 900000003L);
        
        Long revenueId = 900000001L;
        detail.setVolumeReportDetailPhase1Status(VolumeReportStatus.REPORTED);
        detail.setRevenueAccountId(revenueId);
        saveAndFlush(detail);

        volumeReportApproveService.approve(VolumeReportTestData.generateApprovalDTO(VolumeReportFieldEnum.ENTERED_AREA, 900000003L), detail.getVolumeReportHeader(), VolumeReportTestData.mockUser(user.getLogin()));
        
        getSession().evict(detail);
        
        VolumeReportDetail newDetail = (VolumeReportDetail) getSession().get(VolumeReportDetail.class, 900000003L);
        
        Assert.assertNull("Revenue Account Id should be null", newDetail.getRevenueAccountId());
        Assert.assertEquals("Status does not match", VolumeReportStatus.APPROVED, newDetail.getVolumeReportDetailPhase1Status());
        Assert.assertEquals("User reprover login does not match", user.getLogin(), newDetail.getFieldByPhase(VolumeReportFieldEnum.ENTERED_AREA).getApproverLogin());
    }
    
    @Test
    public void test_approve_phase2_harvest_vol() throws InsufficientQuotaForPhase6Approval {
        setupFixture();
        
        ItsUser user = (ItsUser) getSession().get(ItsUser.class, 900000003L);
        
        VolumeReportDetail detail = (VolumeReportDetail) getSession().get(VolumeReportDetail.class, 900000003L);
        
        detail.getVolumeHarvested().setStatus(VolumeReportStatus.REPORTED);
        detail.getPortioning().setStatus(VolumeReportStatus.REPORTED);
        detail.getEnteredArea().setValue(new BigDecimal(50));
        detail.setProductivity(new BigInteger("200"));
        detail.getVolumeHarvested().setValue(new BigDecimal(8000));

        saveAndFlush(detail);
        volumeReportApproveService.approve(VolumeReportTestData.generateApprovalDTO(VolumeReportFieldEnum.VOLUME_HARVEST, 900000003L), detail.getVolumeReportHeader(), VolumeReportTestData.mockUser(user.getLogin()));
        getSession().flush();
        detail = (VolumeReportDetail) getSession().get(VolumeReportDetail.class, 900000003L);
        Assert.assertNull("Should not have transactionId", detail.getVolumeHarvested().getTransactionCode());
        
        getSession().evict(detail);
        
        VolumeReportDetail newDetail = (VolumeReportDetail) getSession().get(VolumeReportDetail.class, 900000003L);
        
        Assert.assertEquals("Status does not match", VolumeReportStatus.APPROVED, newDetail.getVolumeHarvested().getStatus());
        Assert.assertEquals("User reprover login does not match", user.getLogin(), newDetail.getVolumeHarvested().getApproverLogin());
        Assert.assertEquals("Status does not match", VolumeReportStatus.APPROVED, newDetail.getPortioning().getStatus());
    }

    @Test
    public void given_no_discardportioning_when_approve_portioning_should_pass() throws InsufficientQuotaForPhase6Approval {
        setupFixture();

        ItsUser user = (ItsUser) getSession().get(ItsUser.class, 900000003L);

        VolumeReportDetail detail = (VolumeReportDetail) getSession().get(VolumeReportDetail.class, 900000003L);

        detail.getPortioning().setStatus(VolumeReportStatus.REPORTED);
        detail.setProductivity(BigInteger.TEN);

        saveAndFlush(detail);
        volumeReportApproveService.approve(VolumeReportTestData.generateApprovalDTO(VolumeReportFieldEnum.PORTIONING, 900000003L), detail.getVolumeReportHeader(), VolumeReportTestData.mockUser(user.getLogin()));

        VolumeReportDetail newDetail = (VolumeReportDetail) getSession().get(VolumeReportDetail.class, 900000003L);

        Assert.assertEquals("Status does not match", VolumeReportStatus.APPROVED, newDetail.getPortioning().getStatus());
        Assert.assertEquals("User approver login does not match", user.getLogin(), newDetail.getPortioning().getApproverLogin());
    }

    @Test
    public void test_approve_phase2_portioning() throws InsufficientQuotaForPhase6Approval {
        setupFixture();
        
        ItsUser user = (ItsUser) getSession().get(ItsUser.class, 900000003L);
        
        VolumeReportDetail detail = (VolumeReportDetail) getSession().get(VolumeReportDetail.class, 900000003L);
        Grower grower1 = (Grower) getSession().get(Grower.class, 900000001L);
        Grower grower2 = (Grower) getSession().get(Grower.class, 900000002L);
        Grower grower3 = (Grower) getSession().get(Grower.class, 900000003L);

        detail.getPortioning().setStatus(VolumeReportStatus.REPORTED);
        detail.setProductivity(BigInteger.TEN);
        detail.addDiscardPortioning(new DiscardPortioning(grower1, detail, BigDecimal.TEN));
        detail.addDiscardPortioning(new DiscardPortioning(grower2, detail, BigDecimal.TEN));
        detail.addDiscardPortioning(new DiscardPortioning(grower3, detail, BigDecimal.TEN));

        saveAndFlush(detail);
        volumeReportApproveService.approve(VolumeReportTestData.generateApprovalDTO(VolumeReportFieldEnum.PORTIONING, 900000003L), detail.getVolumeReportHeader(), VolumeReportTestData.mockUser(user.getLogin()));
        getSession().flush();

        getSession().evict(detail);
        
        VolumeReportDetail newDetail = (VolumeReportDetail) getSession().get(VolumeReportDetail.class, 900000003L);
        
        Assert.assertEquals("Status does not match", VolumeReportStatus.APPROVED, newDetail.getPortioning().getStatus());
        Assert.assertEquals("User reprover login does not match", user.getLogin(), newDetail.getPortioning().getApproverLogin());
        for (DiscardPortioning discardPortioning : newDetail.getDiscardPortionings()) {
            Assert.assertNotNull("Should have generated id", discardPortioning.getApprovalTransactionCode());
        }
        assertAccountBalance(newDetail, BigDecimal.valueOf(100L), grower1);
        assertAccountBalance(newDetail, BigDecimal.valueOf(100L), grower2);
        assertAccountBalance(newDetail, BigDecimal.valueOf(100L), grower3);

    }

    @Test
    public void test_approve_phase2_ubs_dest_vol() throws InsufficientQuotaForPhase6Approval {
        setupFixture();
        
        ItsUser user = (ItsUser) getSession().get(ItsUser.class, 900000003L);
        
        VolumeReportDetail detail = (VolumeReportDetail) getSession().get(VolumeReportDetail.class, 900000003L);
        
        detail.getVolumeForUBS().setStatus(VolumeReportStatus.REPORTED);
        detail.getVolumeHarvested().setValue(new BigDecimal(500));
        detail.getVolumeForUBS().setValue(new BigDecimal(250));
        
        saveAndFlush(detail);
        volumeReportApproveService.approve(VolumeReportTestData.generateApprovalDTO(VolumeReportFieldEnum.VOLUME_UBS, 900000003L), detail.getVolumeReportHeader(), VolumeReportTestData.mockUser(user.getLogin()));
        getSession().flush();
        detail = (VolumeReportDetail) getSession().get(VolumeReportDetail.class, 900000003L);
        Assert.assertNotNull("Should have transactionId", detail.getVolumeForUBS().getTransactionCode());

        getSession().evict(detail);
        
        VolumeReportDetail newDetail = (VolumeReportDetail) getSession().get(VolumeReportDetail.class, 900000003L);
        
        Assert.assertEquals("Status does not match", VolumeReportStatus.APPROVED, newDetail.getVolumeForUBS().getStatus());
        Assert.assertEquals("User reprover login does not match", user.getLogin(), newDetail.getVolumeForUBS().getApproverLogin());

        Account account = selectAccountFromDetail(newDetail);
        Assert.assertEquals("Balance does not match", new BigDecimal(250), account.getBalance());
    }

    @Test
    public void given_approval_when_difference_is_zero_should_not_generate_any_credits() throws BusinessException, ManualCreditConstraintException {
        setupFixture();

        ItsUser user = (ItsUser) getSession().get(ItsUser.class, 900000003L);

        VolumeReportDetail detail = (VolumeReportDetail) getSession().get(VolumeReportDetail.class, 900000003L);

        detail.getVolumeForUBS().setStatus(VolumeReportStatus.REPORTED);
        detail.getVolumeHarvested().setValue(new BigDecimal(500));
        detail.getVolumeForUBS().setValue(new BigDecimal(500));

        Document document = detail.getVolumeReportHeader().getCustomer().getDocument();
        Grower grower = baseService.getGrowerByCandidateKey(document.getValue(), document.getDocumentType().getDescription());
        accountService.generateCreditManually(detail.getVolumeReportHeader().getHarvest().getCrop(),detail.getVolumeReportHeader().getHarvest().getOperationalYear(),
                detail.getCultivar().getTechnology(),grower, ManualCreditTransactionType.CREDIT, BigDecimal.valueOf(10L), "WHATEVER", user.getLogin());
        accountService.generateCreditManually(detail.getVolumeReportHeader().getHarvest().getCrop(),detail.getVolumeReportHeader().getHarvest().getOperationalYear(),
                detail.getCultivar().getTechnology(),grower, ManualCreditTransactionType.DEBIT, BigDecimal.valueOf(10L), "WHATEVER", user.getLogin());

        saveAndFlush(detail);
        volumeReportApproveService.approve(VolumeReportTestData.generateApprovalDTO(VolumeReportFieldEnum.VOLUME_UBS, 900000003L), detail.getVolumeReportHeader(), VolumeReportTestData.mockUser(user.getLogin()));
        getSession().flush();
        detail = (VolumeReportDetail) getSession().get(VolumeReportDetail.class, 900000003L);
        Assert.assertEquals("TransactionId should be 0",0,  detail.getVolumeForUBS().getTransactionCode().longValue());

        getSession().evict(detail);

        VolumeReportDetail newDetail = (VolumeReportDetail) getSession().get(VolumeReportDetail.class, 900000003L);

        Assert.assertEquals("Status does not match", VolumeReportStatus.APPROVED, newDetail.getVolumeForUBS().getStatus());
        Assert.assertEquals("User reprover login does not match", user.getLogin(), newDetail.getVolumeForUBS().getApproverLogin());

        assertAccountBalance(detail, BigDecimal.ZERO, true);
    }

    @Test
    public void given_reproval_for_approval_generated_with_zero_credits_should_not_generate_reversal() throws ManualCreditConstraintException, BusinessException {
        setupFixture();

        ItsUser user = (ItsUser) getSession().get(ItsUser.class, 900000003L);

        VolumeReportDetail detail = (VolumeReportDetail) getSession().get(VolumeReportDetail.class, 900000003L);

        detail.getVolumeForUBS().setStatus(VolumeReportStatus.REPORTED);
        detail.getVolumeHarvested().setValue(new BigDecimal(500));
        detail.getVolumeForUBS().setValue(new BigDecimal(500));
        Document document = detail.getVolumeReportHeader().getCustomer().getDocument();
        Grower grower = baseService.getGrowerByCandidateKey(document.getValue(), document.getDocumentType().getDescription());
        accountService.generateCreditManually(detail.getVolumeReportHeader().getHarvest().getCrop(),detail.getVolumeReportHeader().getHarvest().getOperationalYear(),
                detail.getCultivar().getTechnology(),grower, ManualCreditTransactionType.CREDIT, BigDecimal.valueOf(10L), "WHATEVER", user.getLogin());
        accountService.generateCreditManually(detail.getVolumeReportHeader().getHarvest().getCrop(),detail.getVolumeReportHeader().getHarvest().getOperationalYear(),
                detail.getCultivar().getTechnology(),grower, ManualCreditTransactionType.DEBIT, BigDecimal.valueOf(10L), "WHATEVER", user.getLogin());
        getSession().flush();

        saveAndFlush(detail);
        volumeReportApproveService.approve(VolumeReportTestData.generateApprovalDTO(VolumeReportFieldEnum.VOLUME_UBS, 900000003L), detail.getVolumeReportHeader(), VolumeReportTestData.mockUser(user.getLogin()));
        getSession().flush();
        detail = (VolumeReportDetail) getSession().get(VolumeReportDetail.class, 900000003L);
        Assert.assertEquals("TransactionId should be 0",0,  detail.getVolumeForUBS().getTransactionCode().longValue());

        getSession().evict(detail);

        VolumeReportDetail newDetail = (VolumeReportDetail) getSession().get(VolumeReportDetail.class, 900000003L);

        Assert.assertEquals("Status does not match", VolumeReportStatus.APPROVED, newDetail.getVolumeForUBS().getStatus());
        Assert.assertEquals("User reprover login does not match", user.getLogin(), newDetail.getVolumeForUBS().getApproverLogin());

        assertAccountBalance(newDetail, BigDecimal.ZERO, false);

        volumeReportReversalService.reversalPhase2VolForUBS(newDetail, user.getLogin());
        assertAccountBalance(newDetail, BigDecimal.ZERO, false);
    }

    @Test
    public void test_approve_phase3() throws InsufficientQuotaForPhase6Approval {
        setupFixture();
        
        ItsUser user = (ItsUser) getSession().get(ItsUser.class, 900000003L);
        
        VolumeReportDetail detail = (VolumeReportDetail) getSession().get(VolumeReportDetail.class, 900000003L);
        
        detail.getVolumeBenefitted().setStatus(VolumeReportStatus.REPORTED);
        detail.getVolumeForUBS().setValue(new BigDecimal(500));
        detail.getVolumeBenefitted().setValue(new BigDecimal(200));

        saveAndFlush(detail);
        volumeReportApproveService.approve(VolumeReportTestData.generateApprovalDTO(VolumeReportFieldEnum.VOLUME_BENEFITTED, 900000003L), detail.getVolumeReportHeader(), VolumeReportTestData.mockUser(user.getLogin()));
        getSession().flush();
        detail = (VolumeReportDetail) getSession().get(VolumeReportDetail.class, 900000003L);
        Assert.assertNotNull("Should have transactionId", detail.getVolumeBenefitted().getTransactionCode());

        getSession().evict(detail);
        
        VolumeReportDetail newDetail = (VolumeReportDetail) getSession().get(VolumeReportDetail.class, 900000003L);
        
        Assert.assertEquals("Status does not match", VolumeReportStatus.APPROVED, newDetail.getVolumeBenefitted().getStatus());
        Assert.assertEquals("User reprover login does not match", user.getLogin(), newDetail.getVolumeBenefitted().getApproverLogin());
        
        Account account = selectAccountFromDetail(newDetail);
        Assert.assertEquals("Balance does not match", new BigDecimal(300), account.getBalance());
    }
    
    @Test
    public void test_approve_phase4() throws InsufficientQuotaForPhase6Approval {
        setupFixture();
        
        ItsUser user = (ItsUser) getSession().get(ItsUser.class, 900000003L);
        
        VolumeReportDetail detail = (VolumeReportDetail) getSession().get(VolumeReportDetail.class, 900000003L);
        
        detail.getVolumeApproved().setStatus(VolumeReportStatus.REPORTED);
        detail.getVolumeBenefitted().setValue(new BigDecimal(600));
        detail.getVolumeApproved().setValue(new BigDecimal(300));

        saveAndFlush(detail);
        volumeReportApproveService.approve(VolumeReportTestData.generateApprovalDTO(VolumeReportFieldEnum.VOLUME_APPROVED, 900000003L), detail.getVolumeReportHeader(), VolumeReportTestData.mockUser(user.getLogin()));
        getSession().flush();
        detail = (VolumeReportDetail) getSession().get(VolumeReportDetail.class, 900000003L);
        Assert.assertNotNull("Should have transactionId", detail.getVolumeApproved().getTransactionCode());

        getSession().evict(detail);
        
        VolumeReportDetail newDetail = (VolumeReportDetail) getSession().get(VolumeReportDetail.class, 900000003L);
        
        Assert.assertEquals("Status does not match", VolumeReportStatus.APPROVED, newDetail.getVolumeApproved().getStatus());
        Assert.assertEquals("User reprover login does not match", user.getLogin(), newDetail.getVolumeApproved().getApproverLogin());
        
        Account account = selectAccountFromDetail(newDetail);
        Assert.assertEquals("Balance does not match", new BigDecimal(300), account.getBalance());
    }
    
    @Test
    public void test_approve_phase5_commld_1() throws InsufficientQuotaForPhase6Approval {
        setupFixture();
        
        ItsUser user = (ItsUser) getSession().get(ItsUser.class, 900000003L);
        
        VolumeReportDetail detail = (VolumeReportDetail) getSession().get(VolumeReportDetail.class, 900000003L);
        
        detail.getVolumeCommercialized1().setStatus(VolumeReportStatus.REPORTED);

        saveAndFlush(detail);
        volumeReportApproveService.approve(VolumeReportTestData.generateApprovalDTO(VolumeReportFieldEnum.VOLUME_COMMERCIALIZED1, 900000003L), detail.getVolumeReportHeader(), VolumeReportTestData.mockUser(user.getLogin()));

        getSession().evict(detail);
        
        VolumeReportDetail newDetail = (VolumeReportDetail) getSession().get(VolumeReportDetail.class, 900000003L);
        
        Assert.assertEquals("Status does not match", VolumeReportStatus.APPROVED, newDetail.getVolumeCommercialized1().getStatus());
        Assert.assertEquals("User reprover login does not match", user.getLogin(), newDetail.getVolumeCommercialized1().getApproverLogin());
    }
    
    @Test
    public void test_approve_phase5_commld_2() throws InsufficientQuotaForPhase6Approval {
        setupFixture();
        
        ItsUser user = (ItsUser) getSession().get(ItsUser.class, 900000003L);
        
        VolumeReportDetail detail = (VolumeReportDetail) getSession().get(VolumeReportDetail.class, 900000003L);
        
        detail.getVolumeCommercialized2().setStatus(VolumeReportStatus.REPORTED);

        saveAndFlush(detail);
        volumeReportApproveService.approve(VolumeReportTestData.generateApprovalDTO(VolumeReportFieldEnum.VOLUME_COMMERCIALIZED2, 900000003L), detail.getVolumeReportHeader(), VolumeReportTestData.mockUser(user.getLogin()));

        getSession().evict(detail);
        
        VolumeReportDetail newDetail = (VolumeReportDetail) getSession().get(VolumeReportDetail.class, 900000003L);
        
        Assert.assertEquals("Status does not match", VolumeReportStatus.APPROVED, newDetail.getVolumeCommercialized2().getStatus());
        Assert.assertEquals("User reprover login does not match", user.getLogin(), newDetail.getVolumeCommercialized2().getApproverLogin());
    }
    
    @Test
    public void test_approve_phase5_commld_3() throws InsufficientQuotaForPhase6Approval {
        setupFixture();
        
        ItsUser user = (ItsUser) getSession().get(ItsUser.class, 900000003L);
        
        VolumeReportDetail detail = (VolumeReportDetail) getSession().get(VolumeReportDetail.class, 900000003L);
        
        detail.getVolumeCommercialized3().setStatus(VolumeReportStatus.REPORTED);

        saveAndFlush(detail);
        volumeReportApproveService.approve(VolumeReportTestData.generateApprovalDTO(VolumeReportFieldEnum.VOLUME_COMMERCIALIZED3, 900000003L), detail.getVolumeReportHeader(), VolumeReportTestData.mockUser(user.getLogin()));

        getSession().evict(detail);
        
        VolumeReportDetail newDetail = (VolumeReportDetail) getSession().get(VolumeReportDetail.class, 900000003L);
        
        Assert.assertEquals("Status does not match", VolumeReportStatus.APPROVED, newDetail.getVolumeCommercialized3().getStatus());
        Assert.assertEquals("User reprover login does not match", user.getLogin(), newDetail.getVolumeCommercialized3().getApproverLogin());
    }
    
    @Test
    public void test_approve_phase6() throws InsufficientQuotaForPhase6Approval {
        setupFixture();
        
        ItsUser user = (ItsUser) getSession().get(ItsUser.class, 900000003L);
        
        VolumeReportDetail detail = (VolumeReportDetail) getSession().get(VolumeReportDetail.class, 900000003L);
        detail.getCultivar().setObtainerOnly(false);
        getSession().save(detail.getCultivar());
        
        detail.getVolumeForNextHarvest().setStatus(VolumeReportStatus.REPORTED);
        detail.getVolumeApproved().setValue(new BigDecimal(30000));
        detail.getVolumeCommercialized1().setValue(new BigDecimal(6000));
        detail.getVolumeCommercialized2().setValue(new BigDecimal(20000));
        detail.getVolumeCommercialized3().setValue(new BigDecimal(2000));
        detail.getVolumeCommercialized3().setStatus(VolumeReportStatus.REPORTED);
        detail.getVolumeForNextHarvest().setValue(new BigDecimal(500));

        saveAndFlush(detail);
        volumeReportApproveService.approve(VolumeReportTestData.generateApprovalDTO(VolumeReportFieldEnum.VOLUME_FOR_NEXT_HARVEST, 900000003L), detail.getVolumeReportHeader(), VolumeReportTestData.mockUser(user.getLogin()));
        getSession().flush();
        detail = (VolumeReportDetail) getSession().get(VolumeReportDetail.class, 900000003L);
        Assert.assertNotNull("Should have transactionId", detail.getVolumeForNextHarvest().getTransactionCode());

        getSession().evict(detail);
        
        VolumeReportDetail newDetail = (VolumeReportDetail) getSession().get(VolumeReportDetail.class, 900000003L);

        Assert.assertEquals("Status does not match", VolumeReportStatus.APPROVED, newDetail.getVolumeForNextHarvest().getStatus());
        Assert.assertEquals("User reprover login does not match", user.getLogin(), newDetail.getVolumeForNextHarvest().getApproverLogin());
        Assert.assertEquals("Status does not match", VolumeReportStatus.APPROVED, newDetail.getVolumeCommercialized3().getStatus());

        Account account = selectAccountFromDetail(newDetail);
        Assert.assertEquals("Balance does not match", new BigDecimal(1500), account.getBalance());
    }
    
    @Test
    public void test_reversal_phase1() {
    	setupFixture();
    	
    	ItsUser user = (ItsUser) getSession().get(ItsUser.class, 900000003L);
    	
    	VolumeReportDetail detail = (VolumeReportDetail) getSession().get(VolumeReportDetail.class, 900000003L);
        detail.getPortioning().setStatus(VolumeReportStatus.APPROVED);
    	
    	volumeReportReversalService.reversalPhase1(detail, user.getLogin());
    	
    	getSession().evict(detail);
    	
    	VolumeReportDetail newDetail = (VolumeReportDetail) getSession().get(VolumeReportDetail.class, 900000003L);
    	
    	Assert.assertEquals("Status does not match", VolumeReportStatus.RETURNED, newDetail.getEnteredArea().getStatus());
    	Assert.assertEquals("User reprover login does not match", user.getLogin(), newDetail.getEnteredArea().getReproverLogin());
        Assert.assertEquals("Portioning was APPROVED, should be returned now", VolumeReportStatus.RETURNED, detail.getPortioning().getStatus());
    }
    
    @Test
    public void test_reversal_phase2_volume_harvested() throws InsufficientQuotaForPhase6Approval {
        setupFixture();
        
        ItsUser user = (ItsUser) getSession().get(ItsUser.class, 900000003L);
        
        VolumeReportDetail detail = (VolumeReportDetail) getSession().get(VolumeReportDetail.class, 900000003L);
        
        detail.getVolumeHarvested().setStatus(VolumeReportStatus.REPORTED);
        detail.getEnteredArea().setValue(new BigDecimal(50));
        detail.setProductivity(new BigInteger("200"));
        detail.getVolumeHarvested().setValue(new BigDecimal(8000));

        saveAndFlush(detail);
        volumeReportApproveService.approve(VolumeReportTestData.generateApprovalDTO(VolumeReportFieldEnum.VOLUME_HARVEST, 900000003L), detail.getVolumeReportHeader(), VolumeReportTestData.mockUser(user.getLogin()));
        getSession().flush();
        detail = (VolumeReportDetail) getSession().get(VolumeReportDetail.class, 900000003L);
        Assert.assertNull("Should not have transactionId", detail.getVolumeHarvested().getTransactionCode());

        volumeReportReversalService.reversalPhase2VolHarvested(detail, user.getLogin());
        getSession().evict(detail);

        VolumeReportDetail newDetail = (VolumeReportDetail) getSession().get(VolumeReportDetail.class, 900000003L);
        Assert.assertEquals("Status does not match", VolumeReportStatus.RETURNED, newDetail.getVolumeHarvested().getStatus());
    	Assert.assertEquals("User reprover login does not match", user.getLogin(), newDetail.getVolumeHarvested().getReproverLogin());
    }
    
    @Test
    public void test_reversal_phase2_volume_for_UBS() throws InsufficientQuotaForPhase6Approval {
        setupFixture();
        
        ItsUser user = (ItsUser) getSession().get(ItsUser.class, 900000003L);
        
        VolumeReportDetail detail = (VolumeReportDetail) getSession().get(VolumeReportDetail.class, 900000003L);
        
        detail.getVolumeForUBS().setStatus(VolumeReportStatus.REPORTED);
        detail.getVolumeHarvested().setValue(new BigDecimal(500));
        detail.getVolumeForUBS().setValue(new BigDecimal(250));

        saveAndFlush(detail);
        volumeReportApproveService.approve(VolumeReportTestData.generateApprovalDTO(VolumeReportFieldEnum.VOLUME_UBS, 900000003L), detail.getVolumeReportHeader(), VolumeReportTestData.mockUser(user.getLogin()));
        getSession().flush();
        detail = (VolumeReportDetail) getSession().get(VolumeReportDetail.class, 900000003L);
        Assert.assertNotNull("Should have  transactionId", detail.getVolumeForUBS().getTransactionCode());

        volumeReportReversalService.reversalPhase2VolForUBS(detail, user.getLogin());
        Assert.assertNull("Should have cleared transactionId", detail.getVolumeForUBS().getTransactionCode());
        getSession().evict(detail);
        
        Account account = selectAccountFromDetail(detail);
        Assert.assertEquals("Balance does not match", BigDecimal.ZERO, account.getBalance());
        
        VolumeReportDetail newDetail = (VolumeReportDetail) getSession().get(VolumeReportDetail.class, 900000003L);
        Assert.assertEquals("Status does not match", VolumeReportStatus.RETURNED, newDetail.getVolumeForUBS().getStatus());
    	Assert.assertEquals("User reprover login does not match", user.getLogin(), newDetail.getVolumeForUBS().getReproverLogin());
    }

    @Test
    public void test_reversal_phase2_without_portioning_defined() throws InsufficientQuotaForPhase6Approval {
        setupFixture();

        ItsUser user = (ItsUser) getSession().get(ItsUser.class, 900000003L);

        VolumeReportDetail detail = (VolumeReportDetail) getSession().get(VolumeReportDetail.class, 900000003L);

        detail.getPortioning().setStatus(VolumeReportStatus.REPORTED);
        detail.setProductivity(BigInteger.TEN);

        saveAndFlush(detail);
        volumeReportApproveService.approve(VolumeReportTestData.generateApprovalDTO(VolumeReportFieldEnum.PORTIONING, 900000003L), detail.getVolumeReportHeader(), VolumeReportTestData.mockUser(user.getLogin()));
        getSession().flush();
        getSession().evict(detail);
        VolumeReportDetail newDetail = (VolumeReportDetail) getSession().get(VolumeReportDetail.class, 900000003L);

        volumeReportReversalService.reversalPhase2Portioning(newDetail, user.getLogin());

        getSession().evict(detail);

        newDetail = (VolumeReportDetail) getSession().get(VolumeReportDetail.class, 900000003L);
        Assert.assertEquals("Status does not match", VolumeReportStatus.RETURNED, newDetail.getPortioning().getStatus());
        Assert.assertEquals("User reprover login does not match", user.getLogin(), newDetail.getPortioning().getReproverLogin());
    }
    
    @Test
    public void test_reversal_phase2_portioning() throws InsufficientQuotaForPhase6Approval {
        setupFixture();
        
        ItsUser user = (ItsUser) getSession().get(ItsUser.class, 900000003L);
        
        VolumeReportDetail detail = (VolumeReportDetail) getSession().get(VolumeReportDetail.class, 900000003L);
        Grower grower1 = (Grower) getSession().get(Grower.class, 900000001L);
        Grower grower2 = (Grower) getSession().get(Grower.class, 900000002L);
        Grower grower3 = (Grower) getSession().get(Grower.class, 900000003L);

        detail.getPortioning().setStatus(VolumeReportStatus.REPORTED);
        detail.setProductivity(BigInteger.TEN);
        detail.addDiscardPortioning(new DiscardPortioning(grower1, detail, BigDecimal.TEN));
        detail.addDiscardPortioning(new DiscardPortioning(grower2, detail, BigDecimal.TEN));
        detail.addDiscardPortioning(new DiscardPortioning(grower3, detail, BigDecimal.TEN));

        saveAndFlush(detail);
        volumeReportApproveService.approve(VolumeReportTestData.generateApprovalDTO(VolumeReportFieldEnum.PORTIONING, 900000003L), detail.getVolumeReportHeader(), VolumeReportTestData.mockUser(user.getLogin()));
        getSession().flush();
        getSession().evict(detail);
        VolumeReportDetail newDetail = (VolumeReportDetail) getSession().get(VolumeReportDetail.class, 900000003L);

        volumeReportReversalService.reversalPhase2Portioning(newDetail, user.getLogin());
        
        getSession().evict(detail);
        
        newDetail = (VolumeReportDetail) getSession().get(VolumeReportDetail.class, 900000003L);
        Assert.assertEquals("Status does not match", VolumeReportStatus.RETURNED, newDetail.getPortioning().getStatus());
        Assert.assertEquals("User reprover login does not match", user.getLogin(), newDetail.getPortioning().getReproverLogin());
        for (DiscardPortioning discardPortioning : newDetail.getDiscardPortionings()) {
            Assert.assertNull("Should not have generated id", discardPortioning.getApprovalTransactionCode());
        }
        assertAccountBalance(newDetail, BigDecimal.ZERO, grower1);
        assertAccountBalance(newDetail, BigDecimal.ZERO, grower2);
        assertAccountBalance(newDetail, BigDecimal.ZERO, grower3);
    }
    
    @Test
    public void test_reversal_phase3() throws InsufficientQuotaForPhase6Approval {
        setupFixture();
        
        ItsUser user = (ItsUser) getSession().get(ItsUser.class, 900000003L);
        
        VolumeReportDetail detail = (VolumeReportDetail) getSession().get(VolumeReportDetail.class, 900000003L);
        
        detail.getVolumeBenefitted().setStatus(VolumeReportStatus.REPORTED);
        detail.getVolumeForUBS().setValue(new BigDecimal(500));
        detail.getVolumeBenefitted().setValue(new BigDecimal(200));
        
        saveAndFlush(detail);
        volumeReportApproveService.approve(VolumeReportTestData.generateApprovalDTO(VolumeReportFieldEnum.VOLUME_BENEFITTED, 900000003L), detail.getVolumeReportHeader(), VolumeReportTestData.mockUser(user.getLogin()));
        getSession().flush();
        detail = (VolumeReportDetail) getSession().get(VolumeReportDetail.class, 900000003L);
        Assert.assertNotNull("Should have transactionId", detail.getVolumeBenefitted().getTransactionCode());

        volumeReportReversalService.reversalPhase3(detail, user.getLogin());
        Assert.assertNull("Should have cleared transactionId", detail.getVolumeBenefitted().getTransactionCode());

        getSession().evict(detail);
        
        Account account = selectAccountFromDetail(detail);
        Assert.assertEquals("Balance does not match", BigDecimal.ZERO, account.getBalance());
        
        VolumeReportDetail newDetail = (VolumeReportDetail) getSession().get(VolumeReportDetail.class, 900000003L);
        Assert.assertEquals("Status does not match", VolumeReportStatus.RETURNED, newDetail.getVolumeBenefitted().getStatus());
        Assert.assertEquals("User reprover login does not match", user.getLogin(), newDetail.getVolumeBenefitted().getReproverLogin());
    }
    
    @Test
    public void test_reversal_phase4() throws InsufficientQuotaForPhase6Approval {
        setupFixture();
        
        ItsUser user = (ItsUser) getSession().get(ItsUser.class, 900000003L);
        
        VolumeReportDetail detail = (VolumeReportDetail) getSession().get(VolumeReportDetail.class, 900000003L);
        
        detail.getVolumeApproved().setStatus(VolumeReportStatus.REPORTED);
        detail.getVolumeBenefitted().setValue(new BigDecimal(600));
        detail.getVolumeApproved().setValue(new BigDecimal(300));

        saveAndFlush(detail);
        volumeReportApproveService.approve(VolumeReportTestData.generateApprovalDTO(VolumeReportFieldEnum.VOLUME_APPROVED, 900000003L), detail.getVolumeReportHeader(), VolumeReportTestData.mockUser(user.getLogin()));
        getSession().flush();
        detail = (VolumeReportDetail) getSession().get(VolumeReportDetail.class, 900000003L);
        Assert.assertNotNull("Should have transactionId", detail.getVolumeApproved().getTransactionCode());

        volumeReportReversalService.reversalPhase4(detail, user.getLogin());
        Assert.assertNull("Should have cleared transactionId", detail.getVolumeApproved().getTransactionCode());

        getSession().evict(detail);
        
        Account account = selectAccountFromDetail(detail);
        Assert.assertEquals("Balance does not match", BigDecimal.ZERO, account.getBalance());
        
        VolumeReportDetail newDetail = (VolumeReportDetail) getSession().get(VolumeReportDetail.class, 900000003L);
        Assert.assertEquals("Status does not match", VolumeReportStatus.RETURNED, newDetail.getVolumeApproved().getStatus());
        Assert.assertEquals("User reprover login does not match", user.getLogin(), newDetail.getVolumeApproved().getReproverLogin());
    }
    
    @Test
    public void test_reversal_phase5_commld_1() {
        setupFixture();
        
        ItsUser user = (ItsUser) getSession().get(ItsUser.class, 900000003L);
        
        VolumeReportDetail detail = (VolumeReportDetail) getSession().get(VolumeReportDetail.class, 900000003L);
        
        detail.getVolumeCommercialized1().setStatus(VolumeReportStatus.REPORTED);
        
        volumeReportReversalService.reversalPhase5CommldVol1(detail, user.getLogin());
        
        getSession().evict(detail);
        
        VolumeReportDetail newDetail = (VolumeReportDetail) getSession().get(VolumeReportDetail.class, 900000003L);
        Assert.assertEquals("Status does not match", VolumeReportStatus.RETURNED, newDetail.getVolumeCommercialized1().getStatus());
        Assert.assertEquals("User reprover login does not match", user.getLogin(), newDetail.getVolumeCommercialized1().getReproverLogin());
    }
    
    @Test
    public void test_reversal_phase5_commld_2() {
        setupFixture();
        
        ItsUser user = (ItsUser) getSession().get(ItsUser.class, 900000003L);
        
        VolumeReportDetail detail = (VolumeReportDetail) getSession().get(VolumeReportDetail.class, 900000003L);
        
        detail.getVolumeCommercialized2().setStatus(VolumeReportStatus.APPROVED);
        detail.getVolumeCommercialized3().setStatus(VolumeReportStatus.APPROVED);

        volumeReportReversalService.reversalPhase5CommldVol2(detail, user.getLogin());
        
        getSession().evict(detail);
        
        VolumeReportDetail newDetail = (VolumeReportDetail) getSession().get(VolumeReportDetail.class, 900000003L);
        Assert.assertEquals("Status does not match", VolumeReportStatus.RETURNED, newDetail.getVolumeCommercialized2().getStatus());
        Assert.assertEquals("User reprover login does not match", user.getLogin(), newDetail.getVolumeCommercialized2().getReproverLogin());
        Assert.assertEquals("Status does not match", VolumeReportStatus.RETURNED, newDetail.getVolumeCommercialized3().getStatus());

    }
    
    @Test
    public void test_reversal_phase5_commld_3() {
        setupFixture();
        
        ItsUser user = (ItsUser) getSession().get(ItsUser.class, 900000003L);
        
        VolumeReportDetail detail = (VolumeReportDetail) getSession().get(VolumeReportDetail.class, 900000003L);
        
        detail.getVolumeCommercialized3().setStatus(VolumeReportStatus.REPORTED);
        
        volumeReportReversalService.reversalPhase5CommldVol3(detail, user.getLogin());
        
        getSession().evict(detail);
        
        VolumeReportDetail newDetail = (VolumeReportDetail) getSession().get(VolumeReportDetail.class, 900000003L);
        Assert.assertEquals("Status does not match", VolumeReportStatus.RETURNED, newDetail.getVolumeCommercialized3().getStatus());
        Assert.assertEquals("User reprover login does not match", user.getLogin(), newDetail.getVolumeCommercialized3().getReproverLogin());
    }
    
    @Test
    public void test_reversal_phase6() throws InsufficientQuotaForPhase6Approval {
        setupFixture();
        
        ItsUser user = (ItsUser) getSession().get(ItsUser.class, 900000003L);
        
        VolumeReportDetail detail = (VolumeReportDetail) getSession().get(VolumeReportDetail.class, 900000003L);
        
        detail.getVolumeForNextHarvest().setStatus(VolumeReportStatus.REPORTED);
        detail.getVolumeApproved().setValue(new BigDecimal(30000));
        detail.getVolumeCommercialized1().setValue(new BigDecimal(6000));
        detail.getVolumeCommercialized2().setValue(new BigDecimal(20000));
        detail.getVolumeCommercialized3().setValue(new BigDecimal(2000));
        detail.getVolumeForNextHarvest().setValue(new BigDecimal(500));

        saveAndFlush(detail);
        volumeReportApproveService.approve(VolumeReportTestData.generateApprovalDTO(VolumeReportFieldEnum.VOLUME_FOR_NEXT_HARVEST, 900000003L), detail.getVolumeReportHeader(), VolumeReportTestData.mockUser(user.getLogin()));
        getSession().flush();
        detail = (VolumeReportDetail) getSession().get(VolumeReportDetail.class, 900000003L);
        Assert.assertNotNull("Should have transactionId", detail.getVolumeForNextHarvest().getTransactionCode());

        volumeReportReversalService.reversalPhase6(detail, user.getLogin());
        Assert.assertNull("Should have cleared transactionId", detail.getVolumeForNextHarvest().getTransactionCode());

        getSession().evict(detail);
        
        Account account = selectAccountFromDetail(detail);
        Assert.assertEquals("Balance does not match", BigDecimal.ZERO, account.getBalance());
        
        VolumeReportDetail newDetail = (VolumeReportDetail) getSession().get(VolumeReportDetail.class, 900000003L);
        Assert.assertEquals("Status does not match", VolumeReportStatus.RETURNED, newDetail.getVolumeForNextHarvest().getStatus());
        Assert.assertEquals("User reprover login does not match", user.getLogin(), newDetail.getVolumeForNextHarvest().getReproverLogin());
    }

    public void saveDetailView(VolumeReportDetail detail) {
        if (!getAssumptionTest().isEnvironmentWithSQLANSI()) {
            getSession().save(VolumeReportTestData.createVolumeReportDetailViewFrom(detail, detail.getVolumeReportHeader().getObtainer(),detail.getVolumeReportHeader().getCustomer(),
                    detail.getVolumeReportHeader().getMatrix(),detail.getVolumeReportHeader().getHarvest(),detail.getVolumeReportHeader().getId()));
        }
    }

    @Test
    public void given_phase2_3_set_to_reported_when_fetch_and_save_and_approve_should_be_set_to_approved() throws InsufficientQuotaForPhase6Approval {
        setupFixture();
        UserContext userContext = getSuperUser();

        VolumeReportDetail detail = fetchVolumeReportDetail(900000004L);

        VolumeReportTestData.updateToPhase2_3(detail);
        detail.getVolumeHarvested().setValue(TWENTY);
        detail.getVolumeForUBS().setValue(BigDecimal.TEN);
        detail.getVolumeForUBS().setStatus(VolumeReportStatus.REPORTED);
        saveDetailView(detail);
        saveAndFlush(detail);

        List<VolumeReportByMatrixApprovalDTO> matrixApprovalDTOs = generateDTOListUsingDetailAsFilter(detail);
        VolumeReportApprovalDTO dto = generateApprovalDTOForDetail(matrixApprovalDTOs);
        extractAndApproveApprovalState(dto.getVolumeForUBSApprovalState());
        volumeReportApproveService.approve(matrixApprovalDTOs, detail.getVolumeReportHeader(), userContext);
        detail = refreshDetail(detail);
        Assert.assertEquals("Should be approved", VolumeReportStatus.APPROVED, detail.getVolumeForUBS().getStatus());
    }

    @Test
    public void given_phase3_set_to_reported_when_fetch_and_save_and_approve_should_be_set_to_approved() throws InsufficientQuotaForPhase6Approval {
        setupFixture();
        UserContext userContext = getSuperUser();

        VolumeReportDetail detail = fetchVolumeReportDetail(900000004L);
        VolumeReportTestData.updateToPhase3(detail);
        detail.getVolumeForUBS().setValue(TWENTY);
        detail.getVolumeBenefitted().setValue(BigDecimal.TEN);
        detail.getVolumeBenefitted().setStatus(VolumeReportStatus.REPORTED);
        saveDetailView(detail);
        saveAndFlush(detail);

        List<VolumeReportByMatrixApprovalDTO> matrixApprovalDTOs = generateDTOListUsingDetailAsFilter(detail);
        VolumeReportApprovalDTO dto = generateApprovalDTOForDetail(matrixApprovalDTOs);
        ApprovalStateHolder volumeForUBSApprovalState = dto.getVolumeBenefittedApprovalState();
        extractAndApproveApprovalState(volumeForUBSApprovalState);
        volumeReportApproveService.approve(matrixApprovalDTOs, detail.getVolumeReportHeader(), userContext);
        detail = refreshDetail(detail);
        Assert.assertEquals("Should be approved", VolumeReportStatus.APPROVED, detail.getVolumeBenefitted().getStatus());
    }

    @Ignore("The dbunit dataset used in this AT has to be modified in order for this test to pass")
    @Test
    public void given_phase4_set_to_reported_when_fetch_and_save_and_approve_should_be_set_to_approved() throws InsufficientQuotaForPhase6Approval {
        setupFixture();
        UserContext userContext = getSuperUser();

        VolumeReportDetail detail = fetchVolumeReportDetail(900000004L);
        VolumeReportTestData.updateToPhase4(detail);
        detail.getVolumeBenefitted().setValue(TWENTY);
        detail.getVolumeApproved().setValue(BigDecimal.TEN);
        detail.getVolumeApproved().setStatus(VolumeReportStatus.REPORTED);

        VolumeReportDetail detailChild  = fetchVolumeReportDetail(900000005L);
        detailChild.getVolumeApproved().setValue(BigDecimal.ONE);
        
        saveDetailView(detail);
        saveAndFlush(detail);

        List<VolumeReportByMatrixApprovalDTO> matrixApprovalDTOs = generateDTOListUsingDetailAsFilter(detail);
        VolumeReportApprovalDTO dto = generateApprovalDTOForDetail(matrixApprovalDTOs);
        ApprovalStateHolder volumeForUBSApprovalState = dto.getVolumeApprovedApprovalState();
        extractAndApproveApprovalState(volumeForUBSApprovalState);
        volumeReportApproveService.approve(matrixApprovalDTOs, detail.getVolumeReportHeader(), userContext);
        detail = refreshDetail(detail);
        Assert.assertEquals("Should be approved", VolumeReportStatus.APPROVED, detail.getVolumeApproved().getStatus());
        for (VolumeReportDetail child : detail.getVolumeReportDetailChildren()) {
        	Assert.assertEquals("All child status should be approved", VolumeReportStatus.APPROVED, child.getVolumeApproved().getStatus());
		}
        assertAccountBalance(detail, BigDecimal.valueOf(9L), false);
    }

    @Test
    public void given_phase5_1_set_to_reported_when_fetch_and_save_and_approve_should_be_set_to_approved() throws InsufficientQuotaForPhase6Approval {
        setupFixture();
        UserContext userContext = getSuperUser();

        VolumeReportDetail detail = fetchVolumeReportDetail(900000004L);
        VolumeReportTestData.updateToPhase5_1(detail);
        detail.getVolumeApproved().setValue(TWENTY);
        detail.getVolumeCommercialized1().setValue(BigDecimal.TEN);
        detail.getVolumeCommercialized1().setStatus(VolumeReportStatus.REPORTED);
        saveDetailView(detail);
        saveAndFlush(detail);

        List<VolumeReportByMatrixApprovalDTO> matrixApprovalDTOs = generateDTOListUsingDetailAsFilter(detail);
        VolumeReportApprovalDTO dto = generateApprovalDTOForDetail(matrixApprovalDTOs);
        ApprovalStateHolder volumeForUBSApprovalState = dto.getVolumeCommercialized1ApprovalState();
        extractAndApproveApprovalState(volumeForUBSApprovalState);
        volumeReportApproveService.approve(matrixApprovalDTOs, detail.getVolumeReportHeader(), userContext);
        detail = refreshDetail(detail);
        Assert.assertEquals("Should be approved", VolumeReportStatus.APPROVED, detail.getVolumeCommercialized1().getStatus());
    }

    @Test
    public void given_phase5_2_set_to_reported_when_fetch_and_save_and_approve_should_be_set_to_approved() throws InsufficientQuotaForPhase6Approval {
        setupFixture();
        UserContext userContext = getSuperUser();

        VolumeReportDetail detail = fetchVolumeReportDetail(900000004L);
        VolumeReportTestData.updateToPhase5_2(detail);
        detail.getVolumeCommercialized1().setValue(TWENTY);
        detail.getVolumeCommercialized2().setValue(BigDecimal.TEN);
        detail.getVolumeCommercialized2().setStatus(VolumeReportStatus.REPORTED);
        saveDetailView(detail);
        saveAndFlush(detail);

        List<VolumeReportByMatrixApprovalDTO> matrixApprovalDTOs = generateDTOListUsingDetailAsFilter(detail);
        VolumeReportApprovalDTO dto = generateApprovalDTOForDetail(matrixApprovalDTOs);
        ApprovalStateHolder volumeForUBSApprovalState = dto.getVolumeCommercialized2ApprovalState();
        extractAndApproveApprovalState(volumeForUBSApprovalState);
        volumeReportApproveService.approve(matrixApprovalDTOs, detail.getVolumeReportHeader(), userContext);
        detail = refreshDetail(detail);
        Assert.assertEquals("Should be approved", VolumeReportStatus.APPROVED, detail.getVolumeCommercialized2().getStatus());
    }

    @Test
    public void given_phase5_3_set_to_reported_when_fetch_and_save_and_approve_should_be_set_to_approved() throws InsufficientQuotaForPhase6Approval {
        setupFixture();
        UserContext userContext = getSuperUser();

        VolumeReportDetail detail = fetchVolumeReportDetail(900000004L);
        VolumeReportTestData.updateToPhase5_3(detail);
        detail.getVolumeCommercialized2().setValue(TWENTY);
        detail.getVolumeCommercialized3().setValue(BigDecimal.TEN);
        detail.getVolumeCommercialized3().setStatus(VolumeReportStatus.REPORTED);
        saveDetailView(detail);
        saveAndFlush(detail);

        List<VolumeReportByMatrixApprovalDTO> matrixApprovalDTOs = generateDTOListUsingDetailAsFilter(detail);
        VolumeReportApprovalDTO dto = generateApprovalDTOForDetail(matrixApprovalDTOs);
        ApprovalStateHolder volumeForUBSApprovalState = dto.getVolumeCommercialized3ApprovalState();
        extractAndApproveApprovalState(volumeForUBSApprovalState);
        volumeReportApproveService.approve(matrixApprovalDTOs, detail.getVolumeReportHeader(), userContext);
        detail = refreshDetail(detail);
        Assert.assertEquals("Should be approved", VolumeReportStatus.APPROVED, detail.getVolumeCommercialized3().getStatus());
    }

    @Test(expected = InsufficientQuotaForPhase6Approval.class)
    public void given_phase6_set_to_reported_when_fetch_and_save_and_approve_should_be_set_to_approved() throws InsufficientQuotaForPhase6Approval {
        setupFixture();
        UserContext userContext = getSuperUser();

        VolumeReportDetail detail = fetchVolumeReportDetail(900000004L);
        VolumeReportTestData.updateToPhase6(detail);
        detail.getVolumeApproved().setValue(BigDecimal.valueOf(100L));
        detail.getVolumeCommercialized1().setValue(BigDecimal.TEN);
        detail.getVolumeCommercialized2().setValue(BigDecimal.TEN);
        detail.getVolumeCommercialized3().setValue(BigDecimal.TEN);
        detail.getVolumeForNextHarvest().setValue(BigDecimal.TEN);
        detail.getVolumeForNextHarvest().setStatus(VolumeReportStatus.REPORTED);
        
        VolumeReportDetail detailChild  = fetchVolumeReportDetail(900000005L);
        detailChild.getVolumeApproved().setValue(BigDecimal.TEN);
        detailChild.getVolumeCommercialized1().setValue(BigDecimal.ONE);
        detailChild.getVolumeCommercialized2().setValue(BigDecimal.ONE);
        detailChild.getVolumeCommercialized3().setValue(BigDecimal.ONE);
        detailChild.getVolumeForNextHarvest().setValue(BigDecimal.ONE);
        
        saveDetailView(detail);
        saveAndFlush(detail);

        List<VolumeReportByMatrixApprovalDTO> matrixApprovalDTOs = generateDTOListUsingDetailAsFilter(detail);
        VolumeReportApprovalDTO dto = generateApprovalDTOForDetail(matrixApprovalDTOs);
        ApprovalStateHolder volumeForUBSApprovalState = dto.getVolumeForNextHarvestApprovalState();
        extractAndApproveApprovalState(volumeForUBSApprovalState);
        volumeReportApproveService.approve(matrixApprovalDTOs, detail.getVolumeReportHeader(), userContext);
        detail = refreshDetail(detail);
        Assert.assertEquals("Should be approved", VolumeReportStatus.APPROVED, detail.getVolumeForNextHarvest().getStatus());
        for (VolumeReportDetail child : detail.getVolumeReportDetailChildren()) {
        	Assert.assertEquals("All child status should be approved", VolumeReportStatus.APPROVED, child.getVolumeApproved().getStatus());
		}
        assertAccountBalance(detail, BigDecimal.valueOf(66L), false);
    }

    private void extractAndApproveApprovalState(ApprovalStateHolder volumeForUBSApprovalState) {
        Assert.assertTrue(volumeForUBSApprovalState.isAvailable());
        volumeForUBSApprovalState.setApproved(true);
        Assert.assertTrue(volumeForUBSApprovalState.isNewApproval());
    }

    @Test
    public void given_phase2_2_set_to_reported_when_fetch_and_save_and_approve_should_be_set_to_approved() throws InsufficientQuotaForPhase6Approval {
        setupFixture();
        UserContext userContext = getSuperUser();

        VolumeReportDetail detail = fetchVolumeReportDetail(900000004L);
        VolumeReportTestData.updateToPhase2_2(detail);
        detail.getEnteredArea().setValue(BigDecimal.TEN);
        detail.getVolumeHarvested().setValue(BigDecimal.TEN);
        detail.getVolumeHarvested().setStatus(VolumeReportStatus.REPORTED);
        saveDetailView(detail);
        saveAndFlush(detail);

        List<VolumeReportByMatrixApprovalDTO> matrixApprovalDTOs = generateDTOListUsingDetailAsFilter(detail);
        VolumeReportApprovalDTO dto = generateApprovalDTOForDetail(matrixApprovalDTOs);
        extractAndApproveApprovalState(dto.getVolumeHarvestedApprovalState());
        volumeReportApproveService.approve(matrixApprovalDTOs, detail.getVolumeReportHeader(), userContext);
        detail = refreshDetail(detail);
        Assert.assertEquals("Should be approved", VolumeReportStatus.APPROVED, detail.getVolumeHarvested().getStatus());
    }

    @Test
    public void given_phase2_1_set_to_reported_when_fetch_and_save_and_approve_should_be_set_to_approved() throws InsufficientQuotaForPhase6Approval {
        setupFixture();
        UserContext userContext = getSuperUser();

        VolumeReportDetail detail = fetchVolumeReportDetail(900000004L);
        VolumeReportTestData.updateToPhase2_1(detail);
        detail.getPortioning().setStatus(VolumeReportStatus.REPORTED);
        saveDetailView(detail);
        saveAndFlush(detail);

        List<VolumeReportByMatrixApprovalDTO> matrixApprovalDTOs = generateDTOListUsingDetailAsFilter(detail);
        VolumeReportApprovalDTO dto = generateApprovalDTOForDetail(matrixApprovalDTOs);
        extractAndApproveApprovalState(dto.getPortioningApprovalState());
        volumeReportApproveService.approve(matrixApprovalDTOs, detail.getVolumeReportHeader(), userContext);
        detail = refreshDetail(detail);
        Assert.assertEquals("Should be approved", VolumeReportStatus.APPROVED, detail.getPortioning().getStatus());
    }
    
    @Test
    public void given_phase1_set_to_reported_when_cultivar_do_not_charge_technology_fetch_and_save_and_approve_should_be_set_to_approved() throws InsufficientQuotaForPhase6Approval {
        setupFixture();
        UserContext userContext = getSuperUser();

        // Updating cultivar of detail used in the test to don't charge technology
        Cultivar detailCultivar = (Cultivar) getSession().get(Cultivar.class, 900000013L);
        detailCultivar.setChargeTechnology(Boolean.FALSE);
        saveAndFlush(detailCultivar);
        
        VolumeReportDetail detail = fetchVolumeReportDetail(900000004L);
        detail.getEnteredArea().setValue(BigDecimal.TEN);
        detail.getOwnSeedUsed().setValue(BigDecimal.TEN);
        detail.getMatrixSeedUsed().setValue(BigDecimal.TEN);
        detail.setVolumeReportDetailPhase1Status(VolumeReportStatus.REPORTED);
        saveDetailView(detail);
        saveAndFlush(detail);

        List<VolumeReportByMatrixApprovalDTO> matrixApprovalDTOs = generateDTOListUsingDetailAsFilter(detail);
        VolumeReportApprovalDTO dto = generateApprovalDTOForDetail(matrixApprovalDTOs);
        extractAndApproveApprovalState(dto.getPhase1ApprovalState());
        volumeReportApproveService.approve(matrixApprovalDTOs, detail.getVolumeReportHeader(), userContext);
        detail = refreshDetail(detail);
        Assert.assertEquals("Should be approved", VolumeReportStatus.APPROVED, detail.getVolumeReportDetailPhase1Status());
    }
    
    @Test
    public void given_phase1_set_to_reported_when_cultivar_charge_technology_fetch_and_save_and_approve_should_be_set_to_approved() throws InsufficientQuotaForPhase6Approval {
        setupFixture();
        UserContext userContext = getSuperUser();
        
        VolumeReportDetail detail = fetchVolumeReportDetail(900000004L);
        detail.getEnteredArea().setValue(BigDecimal.TEN);
        detail.getOwnSeedUsed().setValue(BigDecimal.TEN);
        detail.getMatrixSeedUsed().setValue(BigDecimal.TEN);
        detail.setVolumeReportDetailPhase1Status(VolumeReportStatus.REPORTED);
        saveDetailView(detail);
        saveAndFlush(detail);

        List<VolumeReportByMatrixApprovalDTO> matrixApprovalDTOs = generateDTOListUsingDetailAsFilter(detail);
        VolumeReportApprovalDTO dto = generateApprovalDTOForDetail(matrixApprovalDTOs);
        extractAndApproveApprovalState(dto.getPhase1ApprovalState());
        volumeReportApproveService.approve(matrixApprovalDTOs, detail.getVolumeReportHeader(), userContext);
        detail = refreshDetail(detail);
        Assert.assertEquals("Should be approved", VolumeReportStatus.WAITING_BILLING, detail.getVolumeReportDetailPhase1Status());
    }

    private VolumeReportDetail refreshDetail(VolumeReportDetail detail) {
        getSession().flush();
        getSession().evict(detail);
        detail = (VolumeReportDetail) getSession().get(VolumeReportDetail.class, detail.getId());
        return detail;
    }


    private UserDecorator getSuperUser() {
        try {
            return userService.getUserBy("DANDRADE_S");
        } catch (UserNotFoundException e) {
            return null; // if gives error, is problem with test setup
        }
    }

    private VolumeReportApprovalDTO generateApprovalDTOForDetail(List<VolumeReportByMatrixApprovalDTO> matrixApprovalDTOs) {
        Assert.assertEquals("Should have 1", 1, matrixApprovalDTOs.size());
        VolumeReportByMatrixApprovalDTO matrixApprovalDTO = matrixApprovalDTOs.iterator().next();
        Assert.assertEquals("Should have 1", 1, matrixApprovalDTO.getApprovalDTOs().size());
        return matrixApprovalDTO.getApprovalDTOs().iterator().next();
    }

    private VolumeReportDetail fetchVolumeReportDetail(Long detailId) {
        return (VolumeReportDetail) getSession().get(VolumeReportDetail.class, detailId);
    }



    private void assertAccountBalance(VolumeReportDetail detail, BigDecimal value, boolean expectEmpty) {
        try {
            Document document = detail.getVolumeReportHeader().getCustomer().getDocument();
            Grower grower = baseService.getGrowerByCandidateKey(document.getValue(), document.getDocumentType().getDescription());

            assertAccountBalance(detail, value, grower);
        } catch (EntityNotFoundException e) {
            if(!expectEmpty) {
            }
        }
    }

    private void assertAccountBalance(VolumeReportDetail detail, BigDecimal value, Grower grower) {
        Harvest harvest = detail.getVolumeReportHeader().getHarvest();
        AccountFilter filter = AccountFilter.getInstance().add(AccountType.AVAILABLE).
                add(harvest.getCrop()).
                add(harvest.getOperationalYear()).
                add(detail.getCultivar().getTechnology()).add(grower);
        Account account = null;
        try {
            account = accountService.getAccountByFilter(filter);
        } catch (EntityNotFoundException e) {
            Assert.fail("Should not have thrown ene");
        }
        Assert.assertEquals("Balance should be: " + value.toString() + " but was: " + account.getBalance().toString(), 0, value.compareTo(account.getBalance()));
    }

    private List<VolumeReportByMatrixApprovalDTO> generateDTOListUsingDetailAsFilter(VolumeReportDetail volumeReportDetail) {
//        VolumeReportDetail volumeReportDetail = (VolumeReportDetail) getSession().get(VolumeReportDetail.class, detailId);
        VolumeReportApprovalFilter filter = VolumeReportApprovalFilter.getInstance(volumeReportDetail.getVolumeReportHeader().getHarvest()).
                addObtainer(volumeReportDetail.getVolumeReportHeader().getObtainer()).
                addCultivar(volumeReportDetail.getCultivar()).
                addMatrix(volumeReportDetail.getVolumeReportHeader().getMatrix()).
                addCustomer(volumeReportDetail.getVolumeReportHeader().getCustomer());
        return volumeReportService.selectVolumeReportByMatrixByFilter(filter);
    }
    
    private Account selectAccountFromDetail(VolumeReportDetail detail) {
    	Account account = null;
    	Grower grower = baseService.selectGrowerBy(detail.getVolumeReportHeader().getMatrix().getDocument());
    	AccountFilter filter = AccountFilter.getInstance().add(detail.getVolumeReportHeader().getHarvest().getCrop()).
    			add(detail.getVolumeReportHeader().getHarvest().getOperationalYear()).add(detail.getCultivar().getTechnology()).
    			add(grower);
    	try {
    		account = accountService.getAccountByFilter(filter);
    	} catch (EntityNotFoundException e) {
    		e.printStackTrace();
            Assert.fail("Could not check the account");
		}
    	return account;
    }

}
