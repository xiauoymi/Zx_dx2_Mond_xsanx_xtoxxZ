package com.monsanto.brazilvaluecapture.multiplier.volumereport.model.dao;

import com.monsanto.brazilvaluecapture.core.customer.model.bean.HeadOffice;
import com.monsanto.brazilvaluecapture.core.foundation.test.AbstractServiceIntegrationTests;
import com.monsanto.brazilvaluecapture.core.foundation.test.dbunit.DbUnitHelper;
import com.monsanto.brazilvaluecapture.multiplier.cultivar.model.bean.Cultivar;
import com.monsanto.brazilvaluecapture.multiplier.itsclass.model.bean.ItsClass;
import com.monsanto.brazilvaluecapture.multiplier.obtainer.model.bean.Obtainer;
import com.monsanto.brazilvaluecapture.multiplier.volumereport.model.bean.VolumeReportDetail;
import com.monsanto.brazilvaluecapture.seedsale.harvest.model.bean.Harvest;
import junit.framework.Assert;
import org.junit.Test;

import java.util.List;

public class VolumeReportDetailFilter_AT extends AbstractServiceIntegrationTests {

    public void init() {
        DbUnitHelper.setup(
                "classpath:data/multiplier/basic-fixture.xml",
                "classpath:data/multiplier/volume-report-dataset.xml",
                "classpath:data/multiplier/volume-report-with-parent-dataset.xml");
    }

    @SuppressWarnings("unchecked")
	@Test
    public void given_no_parameters_should_return_multile_results_with_parents_and_children_details() {
        init();
        List<VolumeReportDetail> list = VolumeReportDetailFilter.getInstance().buildQuery(getSession()).list();
        int size = list.size();
        Assert.assertTrue("Should have more than 1 result ", size > 1);
        boolean foundChild = false;
        for (VolumeReportDetail detail : list) {
			if(detail.getVolumeReportDistributor() != null) {
				foundChild = true;
			}
		}
        Assert.assertTrue("Should have found some child detail", foundChild);
    }

    @SuppressWarnings("unchecked")
    @Test
    public void given_all_null_filter_should_return_multiple_results() {
        init();
        HeadOffice headOffice = (HeadOffice)getSession().get(HeadOffice.class, 900000008L);
        List<VolumeReportDetail> list = VolumeReportDetailFilter.getInstance().addCultivar(null).addObtainer(null).addMatrixCustomer(null, null).
                addHarvest(null).addItsClass(null).buildQuery(getSession()).list();
        int size = list.size();
        Assert.assertTrue("Should have more than 1 result ", size > 1);
        list = VolumeReportDetailFilter.getInstance().addCultivar(null).addObtainer(null).addMatrixCustomer(null, headOffice.getCustomer()).
                addHarvest(null).addItsClass(null).buildQuery(getSession()).list();
        Assert.assertTrue("Should have more than 1 result ", size > 1);
    }

    @Test
    public void given_all_params_should_return_single_result() {
        init();
        Harvest harvest = (Harvest) getSession().get(Harvest.class, 900000002L);
        Obtainer obtainer = (Obtainer) getSession().get(Obtainer.class, 900000001L);
        HeadOffice headOffice = (HeadOffice)getSession().get(HeadOffice.class, 900000001L);
        Cultivar cultivar = (Cultivar)getSession().get(Cultivar.class, 900000011L);
        ItsClass itsClass = (ItsClass)getSession().get(ItsClass.class, 900000002L);
        VolumeReportDetail detail = (VolumeReportDetail) VolumeReportDetailFilter.getInstance().addItsClass(itsClass).addHarvest(harvest).addCultivar(cultivar).
                addMatrixCustomer(headOffice.getMatrix(), headOffice.getCustomer()).addObtainer(obtainer).buildQuery(getSession()).uniqueResult();
        Assert.assertNotNull("Should have found detail", detail);

    }

    @Test
    public void given_all_params_invalid_cultivar_should_not_find_result() {
        init();
        Harvest harvest = (Harvest) getSession().get(Harvest.class, 900000002L);
        Obtainer obtainer = (Obtainer) getSession().get(Obtainer.class, 900000001L);
        HeadOffice headOffice = (HeadOffice)getSession().get(HeadOffice.class, 900000008L);
        Cultivar cultivar = (Cultivar)getSession().get(Cultivar.class, 900000013L);
        ItsClass itsClass = (ItsClass)getSession().get(ItsClass.class, 900000002L);
        VolumeReportDetail detail = (VolumeReportDetail) VolumeReportDetailFilter.getInstance().addItsClass(itsClass).addHarvest(harvest).addCultivar(cultivar).
                addMatrixCustomer(headOffice.getMatrix(), headOffice.getCustomer()).addObtainer(obtainer).buildQuery(getSession()).uniqueResult();
        Assert.assertNull("Should not have found detail", detail);
    }
}
