package com.monsanto.brazilvaluecapture.multiplier.volumereport.service.impl;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.csvreader.CsvReader;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Company;
import com.monsanto.brazilvaluecapture.core.foundation.service.BusinessException;
import com.monsanto.brazilvaluecapture.core.foundation.test.AbstractServiceIntegrationTests;
import com.monsanto.brazilvaluecapture.core.foundation.test.dbunit.DbUnitHelper;
import com.monsanto.brazilvaluecapture.core.user.service.ManualCreditConstraintException;
import com.monsanto.brazilvaluecapture.multiplier.volumereport.model.dao.BillingGermplasmViewFilter;
import com.monsanto.brazilvaluecapture.seedsale.quota.report.EmptyReportException;

public class BillingGermplasmReportBuilder_AT extends AbstractServiceIntegrationTests {

	private ResourceBundle resourceBundle = ResourceBundle.getBundle("bundle/bundle");

	@Autowired
	private BillingGermplasmReportBuilder billingGermplasmReportBuilder;
	
	@Before
	public void init() throws BusinessException, ManualCreditConstraintException {
		setupDBUnit();
	}

    @Test(expected=EmptyReportException.class)
	public void test_empty_report() throws IOException, NoSuchMethodException, EmptyReportException {
		
		Company company = (Company) getSession().get(Company.class, 900000002L); 
		
		BillingGermplasmViewFilter filter = BillingGermplasmViewFilter.getInstance();
		filter.addCompany(company);
		
		billingGermplasmReportBuilder.clear();
		billingGermplasmReportBuilder.loadRecord(filter);
		
		Assert.fail("Should fail at this point!");
	}
    
	@Test
	public void test_xls() throws EmptyReportException, NoSuchMethodException, IOException {
		
		Company company = (Company) getSession().get(Company.class, 900000001L); 
		
		BillingGermplasmViewFilter filter = BillingGermplasmViewFilter.getInstance();
		filter.addCompany(company);
		
		billingGermplasmReportBuilder.clear();
		billingGermplasmReportBuilder.loadRecord(filter);
		ByteArrayOutputStream baos =  billingGermplasmReportBuilder.buildReportFor(resourceBundle); 
		//columns 0 - 30, lines 1 - 5
		for (int y = 1; y < 5; y++) {
			for (int x = 0; x < 30; x++) {
				assertSheet(baos, y, x);
			}
		}
	}
	
	@Test
	public void test_csv() throws IOException, NoSuchMethodException, EmptyReportException {
		
		Company company = (Company) getSession().get(Company.class, 900000001L); 
		
		BillingGermplasmViewFilter filter = BillingGermplasmViewFilter.getInstance();
		filter.addCompany(company);
		
		billingGermplasmReportBuilder.clear();
		billingGermplasmReportBuilder.loadRecord(filter);
		billingGermplasmReportBuilder.fetchReportTypeEnum("1");
		ByteArrayOutputStream baos =  billingGermplasmReportBuilder.buildReportFor(resourceBundle); 
		
		InputStream inputStream = new ByteArrayInputStream(baos.toByteArray());
        CsvReader csv = new CsvReader(inputStream, Charset.forName("Windows-1252"));
        csv.readHeaders();
        List<String[]> rows = new ArrayList<String[]>();
        while(csv.readRecord()){
        	String[] cols = csv.getValues()[0].split(";");
        	rows.add(cols);
        }       
        
		//columns 0 - 30, lines 1 - 5
        for (int y = 1; y < 5; y++) {
        	for (int x = 0; x < 30; x++) {
				assertCsv(rows.get(y), x);			
			}
		}
	}
    
    private void setupDBUnit() {
        if(getAssumptionTest().isEnvironmentWithSQLANSI()) {
            DbUnitHelper.setup("classpath:data/multiplier/germplasm-view-dataset-part1.xml",
                    "classpath:data/multiplier/germplasm-view-dataset-part2.xml");
        } else {
            DbUnitHelper.setup("classpath:data/multiplier/germplasm-view-dataset-part1.xml",
            		"classpath:data/multiplier/germplasm-view-dataset-part2.xml",
            		"classpath:data/multiplier/vw-local-only-dataset.xml");
        }
    	
    }
    
	private void assertCsv(String[] row, int column){
		Assert.assertNotNull("CSV cell shouldn't be null", row[column]);
	}
	
    private void assertSheet(ByteArrayOutputStream baos, int rowNum, int cellPosition) throws IOException {
		ByteArrayInputStream inputStream = new ByteArrayInputStream(baos.toByteArray());
		HSSFWorkbook hssfWorkbook = new HSSFWorkbook(inputStream);
		Assert.assertNotNull("workbook shouldn't be null", hssfWorkbook);
		HSSFSheet sheet = hssfWorkbook.getSheetAt(0);
		Assert.assertNotNull("Sheet shouldn't be null", sheet);
		HSSFRow row = sheet.getRow(rowNum);
		Assert.assertNotNull("Row shouldn't be null", row);
		HSSFCell cell = row.getCell(cellPosition);
		Assert.assertNotNull("Cell shouldn't be null", cell);
	}

}
