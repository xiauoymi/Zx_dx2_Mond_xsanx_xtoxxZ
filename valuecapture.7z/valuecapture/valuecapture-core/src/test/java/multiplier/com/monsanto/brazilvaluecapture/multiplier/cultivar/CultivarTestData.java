package com.monsanto.brazilvaluecapture.multiplier.cultivar;

import com.monsanto.brazilvaluecapture.core.base.model.bean.Crop;
import com.monsanto.brazilvaluecapture.core.foundation.RandomTestData;
import com.monsanto.brazilvaluecapture.core.foundation.model.bean.StatusEnum;
import com.monsanto.brazilvaluecapture.multiplier.cultivar.model.bean.Cultivar;
import com.monsanto.brazilvaluecapture.multiplier.obtainer.model.bean.Obtainer;

public class CultivarTestData {

	public static Cultivar createActiveCultivar(Crop crop, Obtainer obtainer) {
		return createActiveCultivar(RandomTestData.createRandomString(10), crop, obtainer);
	}

	public static Cultivar createActiveCultivar(String description, Crop crop, Obtainer obtainer) {
		Cultivar cultivar = new Cultivar();
		cultivar.setDescription(description);
		cultivar.setStatus(StatusEnum.ACTIVE);
		cultivar.setCrop(crop);
		return cultivar;
	}	
	
	
}
