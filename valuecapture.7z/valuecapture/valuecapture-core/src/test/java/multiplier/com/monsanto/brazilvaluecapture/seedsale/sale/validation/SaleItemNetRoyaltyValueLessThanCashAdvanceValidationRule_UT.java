package com.monsanto.brazilvaluecapture.seedsale.sale.validation;

import com.google.common.collect.Sets;
import com.monsanto.brazilvaluecapture.core.foundation.validation.ValidationException;
import com.monsanto.brazilvaluecapture.core.presentation.beans.ResourceBundleTestHelper;
import com.monsanto.brazilvaluecapture.seedsale.product.model.bean.Product;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.Sale;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.SaleItem;
import com.monsanto.brazilvaluecapture.seedsale.sale.service.SaleConstraintViolationException;
import org.junit.Test;

import java.math.BigDecimal;
import java.util.Set;

import static org.fest.assertions.Assertions.assertThat;
import static org.fest.assertions.Fail.fail;


public class SaleItemNetRoyaltyValueLessThanCashAdvanceValidationRule_UT {
    @Test
    public void testValidateThrowsValidationException_WhenSaleItemNetRoyaltyValueIsGreatThanConsumedCashAdvance() {
        Sale sale = createSale(createSaleItem(BigDecimal.TEN, BigDecimal.ONE));
        SaleItemNetRoyaltyValueLessThanCashAdvanceValidationRule saleItemNetRoyaltyValueLessThanCashAdvanceValidationRule = new SaleItemNetRoyaltyValueLessThanCashAdvanceValidationRule();

        try {
            saleItemNetRoyaltyValueLessThanCashAdvanceValidationRule.validate(sale);
            fail("Should throw ValidationException");
        } catch (ValidationException e) {
            assertThat(e).isInstanceOf(SaleValidationException.class).hasNoCause();
            SaleValidationException sve = (SaleValidationException) e;
            final SaleConstraintViolationException saleViolation = sve.getSaleViolation();
            assertThat(saleViolation.getViolations()).onProperty("field").contains("royalty.value.item.netroyalty.gt.cashadvance");
        }
    }

    @Test
    public void testValidatedoNotThrowsValidationException_WhenSaleItemNetRoyaltyValueIsLessThanConsumedCashAdvance() {
        Sale sale = createSale(createSaleItem(BigDecimal.ONE, BigDecimal.TEN));
        SaleItemNetRoyaltyValueLessThanCashAdvanceValidationRule saleItemNetRoyaltyValueLessThanCashAdvanceValidationRule = new SaleItemNetRoyaltyValueLessThanCashAdvanceValidationRule();

        try {
            saleItemNetRoyaltyValueLessThanCashAdvanceValidationRule.validate(sale);
        } catch (ValidationException e) {
            fail("Should never throw ValidationException");
        }
    }

    @Test
    public void testValidateDoNotThrowsValidationException_WhenConsumedCashAdvanceIsZero() {
        Sale sale = createSale(createSaleItem(BigDecimal.TEN, BigDecimal.ZERO));
        SaleItemNetRoyaltyValueLessThanCashAdvanceValidationRule saleItemNetRoyaltyValueLessThanCashAdvanceValidationRule = new SaleItemNetRoyaltyValueLessThanCashAdvanceValidationRule();

        try {
            saleItemNetRoyaltyValueLessThanCashAdvanceValidationRule.validate(sale);
        } catch (ValidationException e) {
            fail("Should not throw ValidationException");
        }
    }

    @Test
    public void testValidateDoNotThrowsValidationException_WhenConsumedCashAdvanceIsNULL() throws ValidationException {
        Sale sale = createSale(createSaleItem(BigDecimal.TEN, null));
        SaleItemNetRoyaltyValueLessThanCashAdvanceValidationRule saleItemNetRoyaltyValueLessThanCashAdvanceValidationRule = new SaleItemNetRoyaltyValueLessThanCashAdvanceValidationRule();

        try {
            saleItemNetRoyaltyValueLessThanCashAdvanceValidationRule.validate(sale);
        } catch (NullPointerException e) {
            fail("Should not throw NullPointerException");
        }
    }



    private String[] messages = {"royalty.value.item.netroyalty.gt.cashadvance"};

    @Test
    public void testI18mMessages_Brazil() throws Exception {
        ResourceBundleTestHelper.assertLanguageStrExistsForBrazil(messages);
    }

    @Test
    public void testI18mMessages_English() throws Exception {
        ResourceBundleTestHelper.assertLanguageStrExistsForUS(messages);
    }

    private Sale createSale(SaleItem... item) {
        final Sale sale = new Sale();
        Set<SaleItem> items = Sets.newHashSet(item);
        sale.setItems(items);
        return sale;
    }

    private SaleItem createSaleItem(BigDecimal netRoyaltyValueQuantity, BigDecimal prepaidRoyaltyValueQuantity) {
        SaleItem item = new SaleItem();
        item.setNetRoyaltyValueQuantity(netRoyaltyValueQuantity);
        item.setPrepaidRoyaltyValueQuantity(prepaidRoyaltyValueQuantity);
        Product product = new Product();
        product.setDescription("Prod Desc");
        item.setProduct(product);
        return item;
    }
}
