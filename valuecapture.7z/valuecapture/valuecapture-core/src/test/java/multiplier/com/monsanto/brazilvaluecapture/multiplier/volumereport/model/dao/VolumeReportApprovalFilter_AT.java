package com.monsanto.brazilvaluecapture.multiplier.volumereport.model.dao;

import java.util.Collection;
import java.util.List;

import junit.framework.Assert;

import org.junit.Test;

import com.monsanto.brazilvaluecapture.core.base.model.bean.City;
import com.monsanto.brazilvaluecapture.core.base.model.bean.State;
import com.monsanto.brazilvaluecapture.core.commercialhierarchy.model.bean.ItsDistrict;
import com.monsanto.brazilvaluecapture.core.commercialhierarchy.model.bean.ItsRegion;
import com.monsanto.brazilvaluecapture.core.commercialhierarchy.model.bean.ItsUnity;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Customer;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.HeadOffice;
import com.monsanto.brazilvaluecapture.core.foundation.test.AbstractServiceIntegrationTests;
import com.monsanto.brazilvaluecapture.core.foundation.test.dbunit.DbUnitHelper;
import com.monsanto.brazilvaluecapture.multiplier.cultivar.model.bean.Cultivar;
import com.monsanto.brazilvaluecapture.multiplier.itsclass.model.bean.ItsClass;
import com.monsanto.brazilvaluecapture.multiplier.obtainer.model.bean.Obtainer;
import com.monsanto.brazilvaluecapture.multiplier.volumereport.model.bean.VolumeReportApprovalDTO;
import com.monsanto.brazilvaluecapture.multiplier.volumereport.model.bean.VolumeReportDetail;
import com.monsanto.brazilvaluecapture.multiplier.volumereport.model.bean.VolumeReportDetailView;
import com.monsanto.brazilvaluecapture.multiplier.volumereport.model.bean.VolumeReportHeader;
import com.monsanto.brazilvaluecapture.multiplier.volumereport.service.impl.VolumeReportTestData;
import com.monsanto.brazilvaluecapture.seedsale.harvest.model.bean.Harvest;

public class VolumeReportApprovalFilter_AT extends AbstractServiceIntegrationTests {
    public static final Long CROP1 = 900000001L;
    public static final Long CROP2 = 900000002L;

    public static final Long OBTAINER1 = 900000001L;
    public static final Long OBTAINER2 = 900000002L;
    public static final Long OBTAINER3 = 900000003L;
    public static final Long OBTAINER4 = 900000004L;

    public static final Long CULTIVAR1 = 900000001L;
    public static final Long CULTIVAR2 = 900000002L;
    public static final Long CULTIVAR3 = 900000003L;
    public static final Long CULTIVAR4 = 900000004L;
    public static final Long CULTIVAR5 = 900000005L;
    public static final Long CULTIVAR6 = 900000006L;
    public static final Long CULTIVAR7 = 900000007L;
    public static final Long CULTIVAR8 = 900000008L;
    public static final Long CULTIVAR9 = 900000009L;

    public static final Long HARVEST1 = 900000001L;
    public static final Long HARVEST2 = 900000002L;
    public static final Long HARVEST3 = 900000003L;

    public static final Long STATE1 = 900000001L;
    public static final Long STATE2 = 900000002L;
    public static final Long STATE3 = 900000003L;
    public static final Long STATE4 = 900000004L;
    public static final Long STATE5 = 900000005L;

    public static final Long HEADOFFICE8 = 900000008L;
    public static final Long HEADOFFICE1 = 900000002L;
    public static final Long HEADOFFICE2 = 900000001L;

    public static final Long CLASS1 = 900000001L;
    public static final Long CLASS2 = 900000002L;

    public void init() {
        DbUnitHelper.setup(
                "classpath:data/multiplier/basic-fixture.xml",
                "classpath:data/multiplier/volume-report-dataset.xml",
                "classpath:data/multiplier/volume-report-with-parent-dataset.xml");
    }

    private Harvest getHarvest(Long id) {
        return (Harvest) getSession().get(Harvest.class, id);
    }

    private void saveDetailViews(Collection<VolumeReportDetailView> volumeReportDetailViews) {
        if(!getAssumptionTest().isEnvironmentWithSQLANSI()) {
            for(VolumeReportDetailView view:volumeReportDetailViews) {
                getSession().save(view);
            }
            getSession().flush();
        }
    }

    @SuppressWarnings("unchecked")
    @Test
    public void given_created_report_with_no_fields_set_in_filter_but_harvest_should_return_that_result() {
        init();
        Harvest harvest = getHarvest(HARVEST1);
        VolumeReportHeader header = VolumeReportTestData.generateVolumeReportHeader(harvest, getHeadOffice(HEADOFFICE2), getObtainer(OBTAINER1),
                new ItsClass[]{getItsClass(CLASS1)}, new Cultivar[]{getCultivar(CULTIVAR8)});
        VolumeReportDetail next = header.getVolumeReportDetails().iterator().next();
        VolumeReportTestData.updateToPhase6(next);
        getSession().save(header);
        saveDetailViews(VolumeReportTestData.createVolumeReportDetailViewsFrom(header));
        Long detailId = next.getId();
        Assert.assertFalse(getSession().createCriteria(VolumeReportDetail.class).list().isEmpty());


        VolumeReportApprovalFilter filter = VolumeReportApprovalFilter.getInstance(harvest);
        List<VolumeReportApprovalDTO> list = filter.buildQuery(getSession()).list();
        boolean found=false;
        for(VolumeReportApprovalDTO dto:list) {
            if(dto.getDetailId().equals(detailId)) {
                found=true;
            }
        }
        Assert.assertTrue("Should have found the one element", found);

    }

    @SuppressWarnings("unchecked")
    @Test
    public void given_created_report_with_no_fields_set_when_use_obtainer_filter_should_bring_one_result() {
        init();
        Harvest harvest = getHarvest(HARVEST1);
        VolumeReportHeader header = VolumeReportTestData.generateVolumeReportHeader(harvest, getHeadOffice(HEADOFFICE2), getObtainer(OBTAINER1),
                new ItsClass[]{getItsClass(CLASS1)}, new Cultivar[]{getCultivar(CULTIVAR8)});
        getSession().save(header);
        saveDetailViews(VolumeReportTestData.createVolumeReportDetailViewsFrom(header));

        header = VolumeReportTestData.generateVolumeReportHeader(harvest, getHeadOffice(HEADOFFICE2), getObtainer(OBTAINER2),
                new ItsClass[]{getItsClass(CLASS2)}, new Cultivar[]{getCultivar(CULTIVAR3)});
        getSession().save(header);
        saveDetailViews(VolumeReportTestData.createVolumeReportDetailViewsFrom(header));
        VolumeReportApprovalFilter filter = VolumeReportApprovalFilter.getInstance(harvest);
        filter.addObtainer(getObtainer(OBTAINER2));
        List<VolumeReportApprovalDTO> list = filter.buildQuery(getSession()).list();
        Assert.assertEquals("Should have 1 element", 1, list.size());
    }

    @SuppressWarnings("unchecked")
    @Test
    public void given_created_report_with_no_fields_set_when_use_cultivar_filter_should_bring_that_result() {
        init();
        Harvest harvest = getHarvest(HARVEST1);
        VolumeReportHeader header = VolumeReportTestData.generateVolumeReportHeader(harvest, getHeadOffice(HEADOFFICE2), getObtainer(OBTAINER1),
                new ItsClass[]{getItsClass(CLASS1)}, new Cultivar[]{getCultivar(CULTIVAR8)});
        getSession().save(header);
        saveDetailViews(VolumeReportTestData.createVolumeReportDetailViewsFrom(header));

        header = VolumeReportTestData.generateVolumeReportHeader(harvest, getHeadOffice(HEADOFFICE2), getObtainer(OBTAINER2),
                new ItsClass[]{getItsClass(CLASS2)}, new Cultivar[]{getCultivar(CULTIVAR3)});
        getSession().save(header);
        saveDetailViews(VolumeReportTestData.createVolumeReportDetailViewsFrom(header));
        VolumeReportApprovalFilter filter = VolumeReportApprovalFilter.getInstance(harvest);
        filter.addCultivar(getCultivar(CULTIVAR3));
        List<VolumeReportApprovalDTO> list = filter.buildQuery(getSession()).list();
        Assert.assertEquals("Should have 1 element", 1, list.size());
    }

    @SuppressWarnings("unchecked")
    @Test
    public void given_created_report_with_no_fields_set_when_use_matrix_customer_filter_should_bring_one_result() {
        init();
        Harvest harvest = getHarvest(HARVEST1);
        VolumeReportHeader header = VolumeReportTestData.generateVolumeReportHeader(harvest, getHeadOffice(HEADOFFICE2), getObtainer(OBTAINER1),
                new ItsClass[]{getItsClass(CLASS1)}, new Cultivar[]{getCultivar(CULTIVAR8)});
        getSession().save(header);
        saveDetailViews(VolumeReportTestData.createVolumeReportDetailViewsFrom(header));

        VolumeReportApprovalFilter filter = VolumeReportApprovalFilter.getInstance(harvest);
        filter.addMatrix((Customer) getSession().get(Customer.class, 900000001L));
        filter.addCustomer((Customer) getSession().get(Customer.class, 900000002L));
        List<VolumeReportApprovalDTO> list = filter.buildQuery(getSession()).list();
        Assert.assertEquals("Should have 1 element", 1, list.size());
        filter = VolumeReportApprovalFilter.getInstance(harvest);
        filter.addMatrix((Customer) getSession().get(Customer.class, 900000002L));
        filter.addCustomer((Customer) getSession().get(Customer.class, 900000001L));
        list = filter.buildQuery(getSession()).list();
        Assert.assertEquals("Should have 0 element", 0, list.size());
    }

    @Test
    public void given_created_report_with_no_fields_set_when_use_state_city_should_have_one_result() {
        init();
        Harvest harvest = getHarvest(HARVEST1);
        VolumeReportHeader header = VolumeReportTestData.generateVolumeReportHeader(harvest, getHeadOffice(HEADOFFICE2), getObtainer(OBTAINER1),
                new ItsClass[]{getItsClass(CLASS1)}, new Cultivar[]{getCultivar(CULTIVAR8)});
        getSession().save(header);
        saveDetailViews(VolumeReportTestData.createVolumeReportDetailViewsFrom(header));

        VolumeReportApprovalFilter filter = VolumeReportApprovalFilter.getInstance(harvest);
        filter.addCity((City) getSession().get(City.class, 900000004L));
        filter.addState((State) getSession().get(State.class, 900000001L));
        filter.buildQuery(getSession()).list();
    }

    @SuppressWarnings("unchecked")
    @Test
    public void given_created_report_with_no_fields_set_when_use_hierarchy_should_bring_one_result() {
        init();
        Harvest harvest = getHarvest(HARVEST1);
        VolumeReportHeader header = VolumeReportTestData.generateVolumeReportHeader(harvest, getHeadOffice(HEADOFFICE2), getObtainer(OBTAINER1),
                new ItsClass[]{getItsClass(CLASS1)}, new Cultivar[]{getCultivar(CULTIVAR8)});
        VolumeReportDetail next = header.getVolumeReportDetails().iterator().next();
        getSession().save(header);
        saveDetailViews(VolumeReportTestData.createVolumeReportDetailViewsFrom(header));
        Long detailId=next.getId();
        ItsDistrict district = (ItsDistrict)getSession().get(ItsDistrict.class, 900000001L);
        ItsRegion region = (ItsRegion)getSession().get(ItsRegion.class, 900000001L);
        ItsUnity unit = (ItsUnity)getSession().get(ItsUnity.class, 900000001L);

        VolumeReportApprovalFilter filter = VolumeReportApprovalFilter.getInstance(harvest);
        filter.addHierarchy(unit, region, district);
        List<VolumeReportApprovalDTO> list = filter.buildQuery(getSession()).list();
        boolean found=false;
        for(VolumeReportApprovalDTO dto:list) {
            if(dto.getDetailId().equals(detailId)) {
                found=true;
            }
        }
        Assert.assertTrue("Should have found the one element", found);
    }

    @SuppressWarnings("unchecked")
    @Test
    public void given_created_report_with_no_fields_set_when_all_null_should_not_throw_exception() {
        init();
        Harvest harvest = getHarvest(HARVEST1);
        VolumeReportHeader header = VolumeReportTestData.generateVolumeReportHeader(harvest, getHeadOffice(HEADOFFICE2), getObtainer(OBTAINER1),
                new ItsClass[]{getItsClass(CLASS1)}, new Cultivar[]{getCultivar(CULTIVAR8)});
        getSession().save(header);
        saveDetailViews(VolumeReportTestData.createVolumeReportDetailViewsFrom(header));
        VolumeReportDetail next = header.getVolumeReportDetails().iterator().next();
        Long detailId=next.getId();

        VolumeReportApprovalFilter filter = VolumeReportApprovalFilter.getInstance(null);
        filter.addCity(null);
        filter.addCultivar(null);
        filter.addCustomer(null);
        filter.addMatrix(null);
        filter.addHierarchy(null, null, null);
        filter.addObtainer(null);
        filter.addState(null);
        List<VolumeReportApprovalDTO> list = filter.buildQuery(getSession()).list();
        boolean found=false;
        for(VolumeReportApprovalDTO dto:list) {
            if(dto.getDetailId().equals(detailId)) {
                found=true;
            }
        }
        Assert.assertTrue("Should have found the one element", found);
    }
    
    @SuppressWarnings("unchecked")
	@Test
    public void volumeReportApprovalFilter_should_not_return_children_details_to_VolumeReportApprovalDTO() {
    	init();
    	// Detail with ID = 900000005 is a child detail.
    	VolumeReportDetail detail = (VolumeReportDetail) getSession().get(VolumeReportDetail.class, 900000005L);
    	Assert.assertNotNull("Detail 900000005 should have parent", detail.getVolumeReportDetailParent());
    	
    	saveDetailViews(VolumeReportTestData.createVolumeReportDetailViewsFrom(detail.getVolumeReportHeader()));
    	
    	VolumeReportApprovalFilter filter = VolumeReportApprovalFilter.getInstance(null);
    	List<VolumeReportApprovalDTO> list = filter.buildQuery(getSession()).list();
    	
    	Assert.assertFalse("List of volume report approval should not be empty", list.isEmpty());
    	
    	boolean found=false;
    	for (VolumeReportApprovalDTO dto : list) {
			if(dto.getDetailId().equals(detail.getId())) {
				found = true;
			}
		}
    	Assert.assertFalse("Should not found a child detail", found);
    }

    private HeadOffice getHeadOffice(Long id) {
        return (HeadOffice) getSession().get(HeadOffice.class,id);
    }

    private Obtainer getObtainer(Long id) {
        return (Obtainer) getSession().get(Obtainer.class,id);
    }

    private ItsClass getItsClass(Long id) {
        return (ItsClass) getSession().get(ItsClass.class,id);
    }

    private Cultivar getCultivar(Long id) {
        return (Cultivar) getSession().get(Cultivar.class,id);
    }
}
