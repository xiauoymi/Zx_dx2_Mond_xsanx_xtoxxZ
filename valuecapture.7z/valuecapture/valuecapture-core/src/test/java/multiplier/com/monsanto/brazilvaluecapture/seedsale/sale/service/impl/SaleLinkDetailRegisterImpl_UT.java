package com.monsanto.brazilvaluecapture.seedsale.sale.service.impl;

import com.google.common.collect.Lists;
import com.monsanto.brazilvaluecapture.seedsale.product.model.bean.Product;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.Sale;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.SaleItem;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.SaleLinkDetail;
import com.monsanto.brazilvaluecapture.utils.DateRange;
import com.monsanto.brazilvaluecapture.utils.DateUtils;
import org.junit.Test;
import org.mockito.ArgumentCaptor;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import static org.fest.assertions.Assertions.assertThat;
import static org.mockito.Mockito.*;


public class SaleLinkDetailRegisterImpl_UT extends ControllershipTestConfigurator {


    @Test
    public void testRegisterSaleCreatesSaleLinkDetailWithMultiplierSale_WhenRegisteringSaleToBeLinked() {
        Sale sale = createMultiplierSale();
        addSaleItemToSale(sale, new ItemDescription(BigDecimal.ZERO, createProduct("Product 1", false), "LOT", plantability, BigDecimal.valueOf(20)), null);
        SaleLinkDetailRegister saleLinkDetailRegisterImpl = new SaleLinkDetailRegisterImpl(saleLinkDetailDAO, multiplierSaleDAO);

        List<SaleLinkDetail> saleLinkDetails = saleLinkDetailRegisterImpl.registerSale(sale);

        assertThat(saleLinkDetails).hasSize(1);
        SaleLinkDetail saleLinkDetail = saleLinkDetails.get(0);
        assertThat(saleLinkDetail.getMultiplierSale()).isEqualTo(sale);
    }

    @Test
    public void testRegisterSaleCreatesSaleLinkDetailWithSaleDealer_WhenRegisteringSaleToBeLinked() {
        Sale sale = createMultiplierSale();
        addSaleItemToSale(sale, new ItemDescription(BigDecimal.ZERO, createProduct("Product 1", false), "LOT", plantability, BigDecimal.valueOf(20)), null);
        SaleLinkDetailRegister saleLinkDetailRegisterImpl = new SaleLinkDetailRegisterImpl(saleLinkDetailDAO, multiplierSaleDAO);

        Collection<SaleLinkDetail> saleLinkDetails = saleLinkDetailRegisterImpl.registerSale(sale);

        assertThat(saleLinkDetails.iterator().next().getDealer()).isEqualTo(dealer);
    }

    @Test
    public void testRegisterSaleCreatesSaleLinkDetailWithSaleItemProduct_WhenRegisteringSaleToBeLinked() {
        final Product product = createProduct("Product 1", true);
        Sale sale = createMultiplierSale();
        addSaleItemToSale(sale, new ItemDescription(BigDecimal.ZERO, createProduct("Product 1", false), "LOT", plantability, BigDecimal.valueOf(20)), null);
        SaleLinkDetailRegister saleLinkDetailRegisterImpl = new SaleLinkDetailRegisterImpl(saleLinkDetailDAO, multiplierSaleDAO);

        List<SaleLinkDetail> saleLinkDetails = saleLinkDetailRegisterImpl.registerSale(sale);

        SaleLinkDetail saleLinkDetail = saleLinkDetails.get(0);
        assertThat(saleLinkDetail.getProduct()).isEqualTo(product);
    }

    @Test
    public void testRegisterSaleCreatesSaleLinkDetailWithSaleItemPlantability_WhenRegisteringSaleToBeLinked() {
        Sale sale = createMultiplierSale();
        addSaleItemToSale(sale, new ItemDescription(BigDecimal.ZERO, createProduct("Product 1", false), "LOT", plantability, BigDecimal.valueOf(20)), null);
        SaleLinkDetailRegister saleLinkDetailRegisterImpl = new SaleLinkDetailRegisterImpl(saleLinkDetailDAO, multiplierSaleDAO);

        List<SaleLinkDetail> saleLinkDetails = saleLinkDetailRegisterImpl.registerSale(sale);

        SaleLinkDetail saleLinkDetail = saleLinkDetails.get(0);
        assertThat(saleLinkDetail.getPlantability()).isEqualTo(plantability);
    }

    @Test
    public void testRegisterSaleCreatesSaleLinkDetailWithSaleItemBatchName_WhenRegisteringSaleToBeLinked() {
        String expectedBatchName = "LOT";
        final BigDecimal expectedTotal = BigDecimal.TEN;
        Sale sale = createMultiplierSale();
        addSaleItemToSale(sale, new ItemDescription(expectedTotal, createProduct("Product 1", false), expectedBatchName, plantability, BigDecimal.valueOf(20)), null);
        SaleLinkDetailRegister saleLinkDetailRegisterImpl = new SaleLinkDetailRegisterImpl(saleLinkDetailDAO, multiplierSaleDAO);

        List<SaleLinkDetail> saleLinkDetails = saleLinkDetailRegisterImpl.registerSale(sale);

        final SaleLinkDetail saleLinkDetail = saleLinkDetails.get(0);
        assertThat(saleLinkDetail.getBatchName()).isEqualTo(expectedBatchName);
    }

    @Test
    public void testRegisterSaleCreatesSaleLinkDetailWithCorrespondingSaleItem_WhenRegisteringSaleToBeLinked() {
        final BigDecimal expectedTotal = BigDecimal.TEN;
        Sale sale = createMultiplierSale();
        SaleItem saleItem = addSaleItemToSale(sale, new ItemDescription(expectedTotal, createProduct("Product 1", false), "LOT", plantability, BigDecimal.valueOf(20)), null);
        SaleLinkDetailRegister saleLinkDetailRegisterImpl = new SaleLinkDetailRegisterImpl(saleLinkDetailDAO, multiplierSaleDAO);

        List<SaleLinkDetail> saleLinkDetails = saleLinkDetailRegisterImpl.registerSale(sale);

        final SaleLinkDetail saleLinkDetail = saleLinkDetails.get(0);
        assertThat(saleLinkDetail.getSaleItem()).isEqualTo(saleItem);
    }

    @Test
    public void testRegisterSaleCreatesTwoSaleLinkDetail_WhenRegisteringSaleHaveTwoItems() {
        Sale sale = createMultiplierSale();
        SaleItem saleItem = addSaleItemToSale(sale, new ItemDescription(BigDecimal.TEN, createProduct("Product 1", false), "LOT", plantability, BigDecimal.valueOf(20)), null);
        SaleItem saleItem1 = addSaleItemToSale(sale, new ItemDescription(BigDecimal.TEN, createProduct("Product 1", false), "LOT1", plantability, BigDecimal.valueOf(20)), null);
        SaleLinkDetailRegister saleLinkDetailRegisterImpl = new SaleLinkDetailRegisterImpl(saleLinkDetailDAO, multiplierSaleDAO);

        Collection<SaleLinkDetail> saleLinkDetails = saleLinkDetailRegisterImpl.registerSale(sale);

        final int expectedSize = 2;
        assertThat(saleLinkDetails).hasSize(expectedSize).onProperty("saleItem").contains(saleItem, saleItem1);
    }

    @Test
    public void testRegisterSaleCreatesTwoSaleLinkDetailEachWithTotalEqualsTo10_WhenRegisteringSaleHaveTwoItemsWithSoldQtyOf10() {
        ItemDescription itemDescription1 = new ItemDescription(BigDecimal.TEN, createProduct("Product 1", false), "LOT", plantability, BigDecimal.valueOf(20));
        ItemDescription itemDescription2 = new ItemDescription(BigDecimal.TEN, createProduct("Product 1", false), "LOT1", plantability, BigDecimal.valueOf(20));
        final ArrayList<ItemDescription> itemDescriptions = Lists.newArrayList(itemDescription1, itemDescription2);
        Sale sale = createSale(itemDescriptions);
        SaleLinkDetailRegister saleLinkDetailRegisterImpl = new SaleLinkDetailRegisterImpl(saleLinkDetailDAO, multiplierSaleDAO);

        Collection<SaleLinkDetail> saleLinkDetails = saleLinkDetailRegisterImpl.registerSale(sale);

        assertThat(saleLinkDetails).onProperty("total").isEqualTo(Lists.newArrayList(BigDecimal.TEN, BigDecimal.TEN));
    }

    @Test
    public void testRegisterSaleInvokesSaleLinkDetailDAO_WhenRegisteringSaleLinkDetail() {
        Sale sale = createMultiplierSale();
        addSaleItemToSale(sale, new ItemDescription(BigDecimal.TEN, createProduct("Product 1", false), "LOT", plantability, BigDecimal.valueOf(20)), null);
        SaleLinkDetailRegister saleLinkDetailRegisterImpl = new SaleLinkDetailRegisterImpl(saleLinkDetailDAO, multiplierSaleDAO);

        final List<SaleLinkDetail> saleLinkDetails = saleLinkDetailRegisterImpl.registerSale(sale);

        final SaleLinkDetail saleLinkDetail = saleLinkDetails.get(0);
        verify(saleLinkDetailDAO).save(saleLinkDetail);
    }

    @Test
    public void testRegisterSaleInvokesSaleLinkDetailDAOForEachGeneratedSaleLinkDetail_WhenRegisteringSaleLinkDetail() {
        ItemDescription itemDescription1 = new ItemDescription(BigDecimal.TEN, createProduct("Product 1", false), "LOT", plantability, BigDecimal.valueOf(20));
        ItemDescription itemDescription2 = new ItemDescription(BigDecimal.TEN, createProduct("Product 1", false), "LOT1", plantability, BigDecimal.valueOf(20));
        final ArrayList<ItemDescription> itemDescriptions = Lists.newArrayList(itemDescription1, itemDescription2);
        Sale sale = createSale(itemDescriptions);
        SaleLinkDetailRegister saleLinkDetailRegisterImpl = new SaleLinkDetailRegisterImpl(saleLinkDetailDAO, multiplierSaleDAO);

        List<SaleLinkDetail> saleLinkDetails = saleLinkDetailRegisterImpl.registerSale(sale);

        ArgumentCaptor<SaleLinkDetail> savedSaleLinkDetailCaptor = ArgumentCaptor.forClass(SaleLinkDetail.class);
        verify(saleLinkDetailDAO, times(2)).save(savedSaleLinkDetailCaptor.capture());
        assertThat(savedSaleLinkDetailCaptor.getAllValues()).contains(saleLinkDetails.toArray());
    }

    @Test
    public void testRegisterSaleWontProcessSaleItems_WhenObtainerIsMarkedAsExcludedFromRevenueRecProcess() {
        ItemDescription itemDescription1 = new ItemDescription(BigDecimal.TEN, createProduct("Product 1", true), "LOT", plantability, BigDecimal.valueOf(20));
        Product nonExcludedProduct = createProduct("Product 1", false);
        ItemDescription itemDescription2 = new ItemDescription(BigDecimal.TEN, nonExcludedProduct, "LOT1", plantability, BigDecimal.valueOf(20));
        final ArrayList<ItemDescription> itemDescriptions = Lists.newArrayList(itemDescription1, itemDescription2);
        Sale sale = createSale(itemDescriptions);
        SaleLinkDetailRegister saleLinkDetailRegisterImpl = new SaleLinkDetailRegisterImpl(saleLinkDetailDAO, multiplierSaleDAO);

        List<SaleLinkDetail> saleLinkDetails = saleLinkDetailRegisterImpl.registerSale(sale);

        int expectedSize = 1;
        assertThat(saleLinkDetails).hasSize(expectedSize);
        SaleLinkDetail nonExcludedSaleLinkDetail = saleLinkDetails.get(0);
        verify(saleLinkDetailDAO, times(1)).save(nonExcludedSaleLinkDetail);
        assertThat(nonExcludedSaleLinkDetail.getSaleItem().getProduct()).isEqualTo(nonExcludedProduct);

    }

    @Test
    public void testRegisterSalesInPeriodListsMultiplierSalesInTheGivenPeriod() {
        final DateRange lastMonthDateRange = DateUtils.getLastMonthDateRange();
        SaleLinkDetailRegister saleLinkDetailRegister = new SaleLinkDetailRegisterImpl(saleLinkDetailDAO, multiplierSaleDAO);

        saleLinkDetailRegister.registerSalesInPeriod(lastMonthDateRange);

        verify(multiplierSaleDAO).listMultiplierToDealerSalesInPeriod(lastMonthDateRange, Sale.SaleTypeEnum.MULTIPLIER_SEED_SALE);
    }

    @Test
    public void testRegisterSalesInPeriodRegistersListedSales() {
        final DateRange lastMonthDateRange = DateUtils.getLastMonthDateRange();
        Sale sale = new Sale();
        when(multiplierSaleDAO.listMultiplierToDealerSalesInPeriod(lastMonthDateRange, Sale.SaleTypeEnum.MULTIPLIER_SEED_SALE)).thenReturn(Lists.newArrayList(sale));
        SaleLinkDetailRegister saleLinkDetailRegister = spy(new SaleLinkDetailRegisterImpl(saleLinkDetailDAO, multiplierSaleDAO));

        saleLinkDetailRegister.registerSalesInPeriod(lastMonthDateRange);

        verify(saleLinkDetailRegister).registerSale(sale);
    }

}
