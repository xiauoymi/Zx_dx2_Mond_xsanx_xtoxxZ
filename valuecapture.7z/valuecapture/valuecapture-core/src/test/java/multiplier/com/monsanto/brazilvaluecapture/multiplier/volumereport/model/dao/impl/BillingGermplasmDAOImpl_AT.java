package com.monsanto.brazilvaluecapture.multiplier.volumereport.model.dao.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import junit.framework.Assert;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.monsanto.brazilvaluecapture.core.base.model.bean.Company;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Crop;
import com.monsanto.brazilvaluecapture.core.commercialhierarchy.model.bean.CommercialHierType;
import com.monsanto.brazilvaluecapture.core.commercialhierarchy.model.bean.ItsDistrict;
import com.monsanto.brazilvaluecapture.core.commercialhierarchy.model.bean.ItsRegion;
import com.monsanto.brazilvaluecapture.core.commercialhierarchy.model.bean.ItsUnity;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Customer;
import com.monsanto.brazilvaluecapture.core.foundation.test.AbstractServiceIntegrationTests;
import com.monsanto.brazilvaluecapture.core.foundation.test.dbunit.DbUnitHelper;
import com.monsanto.brazilvaluecapture.core.foundation.util.CalendarUtil;
import com.monsanto.brazilvaluecapture.multiplier.cultivar.model.bean.Cultivar;
import com.monsanto.brazilvaluecapture.multiplier.revenue.model.bean.GermplasmRevenueStatus;
import com.monsanto.brazilvaluecapture.multiplier.volumereport.model.bean.BillingGermplasmView;
import com.monsanto.brazilvaluecapture.multiplier.volumereport.model.dao.BillingGermplasmDAO;
import com.monsanto.brazilvaluecapture.multiplier.volumereport.model.dao.BillingGermplasmViewFilter;
import com.monsanto.brazilvaluecapture.seedsale.harvest.model.bean.Harvest;

public class BillingGermplasmDAOImpl_AT extends AbstractServiceIntegrationTests {

    @Autowired
    private BillingGermplasmDAO billingGermplasmDAO;

    public void init() {
        CommercialHierType hierType = (CommercialHierType) getSession().get(CommercialHierType.class, 5l);
        if(getAssumptionTest().isEnvironmentWithSQLANSI() && hierType!=null) {
            DbUnitHelper.setup(
                    "classpath:data/multiplier/germplasm-view-dataset-part1.xml","classpath:data/multiplier/germplasm-view-dataset-part2.xml");
        } else {
            DbUnitHelper.setup(
                    "classpath:data/multiplier/germplasm-view-dataset-part1.xml","classpath:data/multiplier/commercialhierarchytype-local.xml",
                    "classpath:data/multiplier/germplasm-view-dataset-part2.xml","classpath:data/multiplier/vw-local-only-dataset.xml");
        }
    }

    @Test
    public void given_database_view_when_select_by_empty_filter_should_return_five_results() {
        init();
        List<BillingGermplasmView> billingGermplasmViews = billingGermplasmDAO.selectBillingGermplasmViewBy(BillingGermplasmViewFilter.getInstance());
        Assert.assertEquals("Should have one element", 5, billingGermplasmViews.size());
        for(BillingGermplasmView view:billingGermplasmViews) {
        	if(view.getCustomerId().equals(900000001L)) {
        		Assert.assertEquals("should be S", "S", view.getCustomerHierarchyStatus());
        		Assert.assertEquals("should be S", "S", view.getMatrixHierarchyStatus());
        		Assert.assertEquals("Should be _DS_", "_DS_", view.getMatrixDistrictSapCode());
        		Assert.assertEquals("Should be _RG_", "_RG_", view.getMatrixRegionSapCode());
        		Assert.assertEquals("Should be _UN_", "_UN_", view.getMatrixUnitySapCode());
        		Assert.assertEquals("Should be _UNUN_", "_UNUN_", view.getMatrixUnitySapDesc());
        		Assert.assertEquals("Should be _REGREG_", "_REGREG_", view.getMatrixRegionSapDesc());
        		Assert.assertEquals("Should be _DISDIS_", "_DISDIS_", view.getMatrixDistrictSapDesc());
        		Assert.assertEquals("Should be _DS_", "_DS_", view.getCustomerDistrictSapCode());
        		Assert.assertEquals("Should be _RG_", "_RG_", view.getCustomerRegionSapCode());
        		Assert.assertEquals("Should be _UN_", "_UN_", view.getCustomerUnitySapCode());
        		Assert.assertEquals("Should be _UNUN_", "_UNUN_", view.getCustomerUnitySapDesc());
        		Assert.assertEquals("Should be _REGREG_", "_REGREG_", view.getCustomerRegionSapDesc());
        		Assert.assertEquals("Should be _DISDIS_", "_DISDIS_", view.getCustomerDistrictSapDesc());
        	}
        }
    }

    @Test
    public void given_view_as_entity_when_select_by_filter_should_bring_one_result() {
        init();
        BillingGermplasmViewFilter filter = BillingGermplasmViewFilter.getInstance();
        filter.addCompany((Company) getSession().get(Company.class, 900000001L));
        filter.addCrop((Crop) getSession().get(Crop.class, 900000001L));
        filter.addMatrix((Customer) getSession().get(Customer.class, 900000001L));
        filter.addAffiliate((Customer) getSession().get(Customer.class, 900000001L));
        filter.addHarvest((Harvest) getSession().get(Harvest.class, 900000001L));
        filter.addCultivar((Cultivar) getSession().get(Cultivar.class, 900000001L));

        filter.addHierarchyMatrix((ItsUnity) getSession().get(ItsUnity.class, 900000001L), 
        		(ItsRegion) getSession().get(ItsRegion.class, 900000001L), 
        		(ItsDistrict) getSession().get(ItsDistrict.class, 900000001L));

        Date date = CalendarUtil.getDate(2012, 06, 30);
        filter.addExpirationDate(date, date);

        List<GermplasmRevenueStatus> statusList = new ArrayList<GermplasmRevenueStatus>();
        for (GermplasmRevenueStatus status : GermplasmRevenueStatus.values()) {
        	statusList.add(status);
        }
        filter.addStatus(statusList);
        
        filter.addBillingNumber("900000001");

        List<BillingGermplasmView> billingGermplasmViews = billingGermplasmDAO.selectBillingGermplasmViewBy(filter);
        Assert.assertEquals("Should have one element", 1, billingGermplasmViews.size());
        BillingGermplasmView view = billingGermplasmViews.iterator().next();
        Assert.assertEquals("Should be S","S", view.getCustomerHierarchyStatus());
        Assert.assertEquals("should be S","S", view.getMatrixHierarchyStatus());
        Assert.assertEquals("Should be _DS_", "_DS_", view.getMatrixDistrictSapCode());
        Assert.assertEquals("Should be _RG_", "_RG_", view.getMatrixRegionSapCode());
        Assert.assertEquals("Should be _UN_", "_UN_", view.getMatrixUnitySapCode());
        Assert.assertEquals("Should be _UNUN_", "_UNUN_", view.getMatrixUnitySapDesc());
        Assert.assertEquals("Should be _REGREG_", "_REGREG_", view.getMatrixRegionSapDesc());
        Assert.assertEquals("Should be _DISDIS_", "_DISDIS_", view.getMatrixDistrictSapDesc());
        Assert.assertEquals("Should be _DS_", "_DS_", view.getCustomerDistrictSapCode());
        Assert.assertEquals("Should be _RG_", "_RG_", view.getCustomerRegionSapCode());
        Assert.assertEquals("Should be _UN_", "_UN_", view.getCustomerUnitySapCode());
        Assert.assertEquals("Should be _UNUN_", "_UNUN_", view.getCustomerUnitySapDesc());
        Assert.assertEquals("Should be _REGREG_", "_REGREG_", view.getCustomerRegionSapDesc());
        Assert.assertEquals("Should be _DISDIS_", "_DISDIS_", view.getCustomerDistrictSapDesc());
    }

}
