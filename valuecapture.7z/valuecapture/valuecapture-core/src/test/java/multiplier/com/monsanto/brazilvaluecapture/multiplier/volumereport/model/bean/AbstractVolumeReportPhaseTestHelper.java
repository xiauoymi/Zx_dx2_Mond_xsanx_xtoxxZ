package com.monsanto.brazilvaluecapture.multiplier.volumereport.model.bean;

import com.monsanto.brazilvaluecapture.core.customer.model.bean.HeadOffice;
import com.monsanto.brazilvaluecapture.multiplier.cultivar.model.bean.Cultivar;
import com.monsanto.brazilvaluecapture.multiplier.harvestcalendar.model.bean.HarvestCalendar;
import com.monsanto.brazilvaluecapture.multiplier.itsclass.model.bean.ItsClass;
import com.monsanto.brazilvaluecapture.multiplier.obtainer.model.bean.Obtainer;
import com.monsanto.brazilvaluecapture.seedsale.harvest.model.bean.Harvest;
import org.junit.Before;
import org.mockito.Mockito;

import java.util.Calendar;
import java.util.Date;

public abstract class AbstractVolumeReportPhaseTestHelper {

    protected Date pastDateStart;
    protected Date pastDateEnd;
    protected Date currentDateStart;
    protected Date currentDateEnd;
    protected Date futureDateStart;
    protected Date futureDateEnd;
    protected HarvestCalendar harvestCalendarPast;
    protected HarvestCalendar harvestCalendarCurrent;
    protected HarvestCalendar harvestCalendarFuture;
    protected Harvest harvest;
    protected Obtainer obtainer;
    protected HeadOffice headOffice;
    protected Cultivar cultivar;
    protected ItsClass itsClass;

    public AbstractVolumeReportPhaseTestHelper() {
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.MONTH, -6);
        pastDateStart = calendar.getTime();
        calendar.add(Calendar.MONTH, 1);
        pastDateEnd = calendar.getTime();

        calendar = Calendar.getInstance();
        calendar.add(Calendar.MONTH,-1);
        currentDateStart = calendar.getTime();
        calendar.add(Calendar.MONTH, 2);
        currentDateEnd = calendar.getTime();

        calendar = Calendar.getInstance();
        calendar.add(Calendar.MONTH, 6);
        futureDateStart = calendar.getTime();
        calendar.add(Calendar.MONTH,1);
        futureDateEnd = calendar.getTime();
    }

    @Before
    public void setup() {
        createMockedHarvestCalendarInPast();
        createMockedHarvestCalendarCurrent();
        createMockedHarvestCalendarInFuture();

        harvest = Mockito.mock(Harvest.class);
        obtainer = Mockito.mock(Obtainer.class);
        headOffice = Mockito.mock(HeadOffice.class);
        cultivar = Mockito.mock(Cultivar.class);
        Mockito.when(cultivar.getChargeGermoplasm()).thenReturn(Boolean.TRUE);
        Mockito.when(cultivar.getChargeTechnology()).thenReturn(Boolean.TRUE);
        itsClass = Mockito.mock(ItsClass.class);
    }

    private void createMockedHarvestCalendarInFuture() {
        harvestCalendarFuture = Mockito.mock(HarvestCalendar.class);


        // Phase 1
        Mockito.when(harvestCalendarFuture.getInscribedAreaStart()).thenReturn(futureDateStart);
        Mockito.when(harvestCalendarFuture.getInscribedAreaEnd()).thenReturn(futureDateEnd);
        Mockito.when(harvestCalendarFuture.getOwnSeedVolUsedStart()).thenReturn(futureDateStart);
        Mockito.when(harvestCalendarFuture.getOwnSeedVolUsedEnd()).thenReturn(futureDateEnd);
        Mockito.when(harvestCalendarFuture.getMatrixSeedVolOwnedStart()).thenReturn(futureDateStart);
        Mockito.when(harvestCalendarFuture.getMatrixSeedVolOwnedEnd()).thenReturn(futureDateEnd);
        // Phase 2
        Mockito.when(harvestCalendarFuture.getHarvestVolStart()).thenReturn(futureDateStart);
        Mockito.when(harvestCalendarFuture.getHarvestVolEnd()).thenReturn(futureDateEnd);
        Mockito.when(harvestCalendarFuture.getUbsDestVolStart()).thenReturn(futureDateStart);
        Mockito.when(harvestCalendarFuture.getUbsDestVolEnd()).thenReturn(futureDateEnd);
        Mockito.when(harvestCalendarFuture.getHarvestDiscardedAreaStart()).thenReturn(futureDateStart);
        Mockito.when(harvestCalendarFuture.getHarvestDiscardedAreaEnd()).thenReturn(futureDateEnd);
        // phase 3
        Mockito.when(harvestCalendarFuture.getBenefittedVolStart()).thenReturn(futureDateStart);
        Mockito.when(harvestCalendarFuture.getBenefittedVolEnd()).thenReturn(futureDateEnd);
        // phase 4
        Mockito.when(harvestCalendarFuture.getApprovedVolStart()).thenReturn(futureDateStart);
        Mockito.when(harvestCalendarFuture.getApprovedVolEnd()).thenReturn(futureDateEnd);
        // Phase 5
        Mockito.when(harvestCalendarFuture.getFirstCommldVolStart()).thenReturn(futureDateStart);
        Mockito.when(harvestCalendarFuture.getFirstCommldVolEnd()).thenReturn(futureDateEnd);
        Mockito.when(harvestCalendarFuture.getSecondCommldVolStart()).thenReturn(futureDateStart);
        Mockito.when(harvestCalendarFuture.getSecondCommldVolEnd()).thenReturn(futureDateEnd);
        Mockito.when(harvestCalendarFuture.getThirdCommldVolStart()).thenReturn(futureDateStart);
        Mockito.when(harvestCalendarFuture.getThirdCommldVolEnd()).thenReturn(futureDateEnd);
        // phase 6
        Mockito.when(harvestCalendarFuture.getNextHarvestVolStart()).thenReturn(futureDateStart);
        Mockito.when(harvestCalendarFuture.getNextHarvestVolEnd()).thenReturn(futureDateEnd);

    }

    private void createMockedHarvestCalendarCurrent() {
        harvestCalendarCurrent = Mockito.mock(HarvestCalendar.class);

        // Phase 1
        Mockito.when(harvestCalendarCurrent.getInscribedAreaStart()).thenReturn(currentDateStart);
        Mockito.when(harvestCalendarCurrent.getInscribedAreaEnd()).thenReturn(currentDateEnd);
        Mockito.when(harvestCalendarCurrent.getOwnSeedVolUsedStart()).thenReturn(currentDateStart);
        Mockito.when(harvestCalendarCurrent.getOwnSeedVolUsedEnd()).thenReturn(currentDateEnd);
        Mockito.when(harvestCalendarCurrent.getMatrixSeedVolOwnedStart()).thenReturn(currentDateStart);
        Mockito.when(harvestCalendarCurrent.getMatrixSeedVolOwnedEnd()).thenReturn(currentDateEnd);
        // Phase 2
        Mockito.when(harvestCalendarCurrent.getHarvestVolStart()).thenReturn(currentDateStart);
        Mockito.when(harvestCalendarCurrent.getHarvestVolEnd()).thenReturn(currentDateEnd);
        Mockito.when(harvestCalendarCurrent.getUbsDestVolStart()).thenReturn(currentDateStart);
        Mockito.when(harvestCalendarCurrent.getUbsDestVolEnd()).thenReturn(currentDateEnd);
        Mockito.when(harvestCalendarCurrent.getHarvestDiscardedAreaStart()).thenReturn(currentDateStart);
        Mockito.when(harvestCalendarCurrent.getHarvestDiscardedAreaEnd()).thenReturn(currentDateEnd);
        // phase 3
        Mockito.when(harvestCalendarCurrent.getBenefittedVolStart()).thenReturn(currentDateStart);
        Mockito.when(harvestCalendarCurrent.getBenefittedVolEnd()).thenReturn(currentDateEnd);
        // phase 4
        Mockito.when(harvestCalendarCurrent.getApprovedVolStart()).thenReturn(currentDateStart);
        Mockito.when(harvestCalendarCurrent.getApprovedVolEnd()).thenReturn(currentDateEnd);
        // Phase 5
        Mockito.when(harvestCalendarCurrent.getFirstCommldVolStart()).thenReturn(currentDateStart);
        Mockito.when(harvestCalendarCurrent.getFirstCommldVolEnd()).thenReturn(currentDateEnd);
        Mockito.when(harvestCalendarCurrent.getSecondCommldVolStart()).thenReturn(currentDateStart);
        Mockito.when(harvestCalendarCurrent.getSecondCommldVolEnd()).thenReturn(currentDateEnd);
        Mockito.when(harvestCalendarCurrent.getThirdCommldVolStart()).thenReturn(currentDateStart);
        Mockito.when(harvestCalendarCurrent.getThirdCommldVolEnd()).thenReturn(currentDateEnd);
        // phase 6
        Mockito.when(harvestCalendarCurrent.getNextHarvestVolStart()).thenReturn(currentDateStart);
        Mockito.when(harvestCalendarCurrent.getNextHarvestVolEnd()).thenReturn(currentDateEnd);
    }

    private void createMockedHarvestCalendarInPast() {
        harvestCalendarPast = Mockito.mock(HarvestCalendar.class);
        // Phase 1
        Mockito.when(harvestCalendarPast.getInscribedAreaStart()).thenReturn(pastDateStart);
        Mockito.when(harvestCalendarPast.getInscribedAreaEnd()).thenReturn(pastDateEnd);
        Mockito.when(harvestCalendarPast.getOwnSeedVolUsedStart()).thenReturn(pastDateStart);
        Mockito.when(harvestCalendarPast.getOwnSeedVolUsedEnd()).thenReturn(pastDateEnd);
        Mockito.when(harvestCalendarPast.getMatrixSeedVolOwnedStart()).thenReturn(pastDateStart);
        Mockito.when(harvestCalendarPast.getMatrixSeedVolOwnedEnd()).thenReturn(pastDateEnd);
        // Phase 2
        Mockito.when(harvestCalendarPast.getHarvestVolStart()).thenReturn(pastDateStart);
        Mockito.when(harvestCalendarPast.getHarvestVolEnd()).thenReturn(pastDateEnd);
        Mockito.when(harvestCalendarPast.getUbsDestVolStart()).thenReturn(pastDateStart);
        Mockito.when(harvestCalendarPast.getUbsDestVolEnd()).thenReturn(pastDateEnd);
        Mockito.when(harvestCalendarPast.getHarvestDiscardedAreaStart()).thenReturn(pastDateStart);
        Mockito.when(harvestCalendarPast.getHarvestDiscardedAreaEnd()).thenReturn(pastDateEnd);
        // phase 3
        Mockito.when(harvestCalendarPast.getBenefittedVolStart()).thenReturn(pastDateStart);
        Mockito.when(harvestCalendarPast.getBenefittedVolEnd()).thenReturn(pastDateEnd);
        // phase 4
        Mockito.when(harvestCalendarPast.getApprovedVolStart()).thenReturn(pastDateStart);
        Mockito.when(harvestCalendarPast.getApprovedVolEnd()).thenReturn(pastDateEnd);
        // Phase 5
        Mockito.when(harvestCalendarPast.getFirstCommldVolStart()).thenReturn(pastDateStart);
        Mockito.when(harvestCalendarPast.getFirstCommldVolEnd()).thenReturn(pastDateEnd);
        Mockito.when(harvestCalendarPast.getSecondCommldVolStart()).thenReturn(pastDateStart);
        Mockito.when(harvestCalendarPast.getSecondCommldVolEnd()).thenReturn(pastDateEnd);
        Mockito.when(harvestCalendarPast.getThirdCommldVolStart()).thenReturn(pastDateStart);
        Mockito.when(harvestCalendarPast.getThirdCommldVolEnd()).thenReturn(pastDateEnd);
        // phase 6
        Mockito.when(harvestCalendarPast.getNextHarvestVolStart()).thenReturn(pastDateStart);
        Mockito.when(harvestCalendarPast.getNextHarvestVolEnd()).thenReturn(pastDateEnd);

    }
}
