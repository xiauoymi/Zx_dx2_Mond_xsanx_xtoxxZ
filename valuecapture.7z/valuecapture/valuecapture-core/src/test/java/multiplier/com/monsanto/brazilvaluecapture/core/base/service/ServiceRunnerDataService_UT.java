package com.monsanto.brazilvaluecapture.core.base.service;

import org.junit.Test;

/**
 * Created with IntelliJ IDEA.
 * User: IFERN1
 * Date: 8/7/13
 * Time: 12:56 PM
 * To change this template use File | Settings | File Templates.
 */
public class ServiceRunnerDataService_UT {
    @Test
    public void testLogData() throws Exception {

    }

    @Test
    public void testLogBusinessObject() throws Exception {

    }
}
