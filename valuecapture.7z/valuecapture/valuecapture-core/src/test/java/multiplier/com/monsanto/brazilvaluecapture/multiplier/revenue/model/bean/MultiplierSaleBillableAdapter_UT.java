package com.monsanto.brazilvaluecapture.multiplier.revenue.model.bean;

import com.monsanto.brazilvaluecapture.core.base.model.bean.Company;
import com.monsanto.brazilvaluecapture.core.base.model.bean.OperationalYear;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Contract;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Customer;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Technology;
import com.monsanto.brazilvaluecapture.core.revenue.model.bean.RevenueType;
import com.monsanto.brazilvaluecapture.multiplier.cultivar.model.bean.Cultivar;
import com.monsanto.brazilvaluecapture.multiplier.revenue.model.MultiplierSaleBillableAdapter;
import com.monsanto.brazilvaluecapture.seedsale.billing.model.bean.BillingCalendar;
import com.monsanto.brazilvaluecapture.seedsale.harvest.model.bean.Harvest;
import com.monsanto.brazilvaluecapture.seedsale.product.model.bean.Product;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.SaleItem;
import com.monsanto.brazilvaluecapture.seedsale.template.model.bean.SaleTemplate;
import junit.framework.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import static org.mockito.Matchers.any;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class MultiplierSaleBillableAdapter_UT {

    @Mock
    private SaleItem saleItem;

    @Mock
    private SaleTemplate saleTemplate;

    @Mock
    private Harvest harvest;

    @Mock
    private Company company;

    @Mock
    private Product product;

    @Mock
    private Cultivar cultivar;

    @Mock
    private Technology technology;

    @Mock
    private BillingCalendar billingCalendar;
    
    @Mock
    private Contract contract;
    
    private String multiplierSalesBillingIntactaMaterialNumber;
    private List<BillingCalendar> billingCalendars;
    
    @InjectMocks
    private MultiplierSaleBillableAdapter multiplierSaleBillableAdapter;


    @Before
    public void init() {
        MockitoAnnotations.initMocks(this);

        multiplierSalesBillingIntactaMaterialNumber = "12008002";

        billingCalendars = new ArrayList<BillingCalendar>();
        billingCalendars.add(billingCalendar);
        when(billingCalendar.getSaleTemplate()).thenReturn(saleTemplate);
        when(saleTemplate.getErpPaymentCondition(any(Technology.class))).thenReturn("ERP_PAYMENT_CONDITION");

        multiplierSaleBillableAdapter = new MultiplierSaleBillableAdapter(saleItem, billingCalendars, multiplierSalesBillingIntactaMaterialNumber, contract);

        when(saleTemplate.getHarvest()).thenReturn(harvest);

        when(harvest.getCompany()).thenReturn(company);
        when(harvest.getOperationalYear()).thenReturn(Mockito.mock(OperationalYear.class));

        when(saleItem.getSaleTemplate()).thenReturn(saleTemplate);
        when(saleItem.getSoldQuantity()).thenReturn(8L);
        when(saleItem.getHaAmount()).thenReturn(new BigDecimal(10));
        when(saleItem.getTotalRoyaltyValue()).thenReturn(new BigDecimal(10));
        when(saleItem.getNetRoyaltyValueQuantity()).thenReturn(new BigDecimal(10));
        when(saleItem.getId()).thenReturn(4L);
        when(saleItem.getContractCode()).thenReturn("ContractCode");
        when(saleItem.getCustomerParent()).thenReturn(Mockito.mock(Customer.class));
        when(saleItem.getDueDate()).thenReturn(new Date());

        when(saleItem.getProduct()).thenReturn(product);
        when(product.getCultivar()).thenReturn(cultivar);
        when(cultivar.getTechnology()).thenReturn(technology);
    }

    @Test
    public void adapterTest() {

        when(technology.getDescription()).thenReturn("RR");

        Assert.assertNull(multiplierSaleBillableAdapter.getAdditionalConditions());
        Assert.assertNotNull(multiplierSaleBillableAdapter.getAmount());
        Assert.assertEquals(multiplierSaleBillableAdapter.getAmount(), new BigDecimal(10));
        Assert.assertNull(multiplierSaleBillableAdapter.getBonusValue());
        Assert.assertNotNull(multiplierSaleBillableAdapter.getCodeHandle());
        Assert.assertEquals(multiplierSaleBillableAdapter.getCodeHandle().longValue(), 4l);
        Assert.assertNull(multiplierSaleBillableAdapter.getComissionValue());
        Assert.assertEquals(multiplierSaleBillableAdapter.getCompany(), company);
        Assert.assertEquals(multiplierSaleBillableAdapter.getContractNumber(), contract.getContractCode());
        Assert.assertEquals(multiplierSaleBillableAdapter.getCustomer(), saleItem.getCustomerParent());
        Assert.assertNotNull(multiplierSaleBillableAdapter.getExpirationDate());
        Assert.assertNull(multiplierSaleBillableAdapter.getFixedComissionValue());
        Assert.assertNull(multiplierSaleBillableAdapter.getMarketingValue());
        Assert.assertEquals(multiplierSaleBillableAdapter.getOperationalYear(), harvest.getOperationalYear());
        Assert.assertNull(multiplierSaleBillableAdapter.getPeriod());
        Assert.assertNull(multiplierSaleBillableAdapter.getProductSapCode(), null);
        Assert.assertEquals(multiplierSaleBillableAdapter.getType(), RevenueType.DISTRIBUTION);
        Assert.assertNotNull(multiplierSaleBillableAdapter.getValue());
        Assert.assertEquals(multiplierSaleBillableAdapter.getValue(), new BigDecimal(10));
        Assert.assertEquals(multiplierSaleBillableAdapter.getMaterialDetail(), null);
        Assert.assertEquals(multiplierSaleBillableAdapter.isZNET(), Boolean.FALSE);
        Assert.assertEquals(multiplierSaleBillableAdapter.getPaymentCondition(), billingCalendar.getSaleTemplate().getErpPaymentCondition(any(Technology.class)));
        Assert.assertEquals(multiplierSaleBillableAdapter.hasItemValueRequired(), Boolean.TRUE);
        Assert.assertEquals(multiplierSaleBillableAdapter.hasDiverseMaterials(), Boolean.FALSE);
        Assert.assertEquals(multiplierSaleBillableAdapter.hasCreditConsumption(), Boolean.FALSE);
    }

    @Test
    public void adapterOtherTest() {

        when(technology.getDescription()).thenReturn("RR2");

        Assert.assertNull(multiplierSaleBillableAdapter.getAdditionalConditions());
        Assert.assertNotNull(multiplierSaleBillableAdapter.getAmount());
        Assert.assertEquals(multiplierSaleBillableAdapter.getAmount(), new BigDecimal(10));
        Assert.assertNull(multiplierSaleBillableAdapter.getBonusValue());
        Assert.assertNotNull(multiplierSaleBillableAdapter.getCodeHandle());
        Assert.assertEquals(multiplierSaleBillableAdapter.getCodeHandle().longValue(), 4l);
        Assert.assertNull(multiplierSaleBillableAdapter.getComissionValue());
        Assert.assertEquals(multiplierSaleBillableAdapter.getCompany(), company);
        Assert.assertEquals(multiplierSaleBillableAdapter.getContractNumber(), contract.getContractCode());
        Assert.assertEquals(multiplierSaleBillableAdapter.getCustomer(), saleItem.getCustomerParent());
        Assert.assertNotNull(multiplierSaleBillableAdapter.getExpirationDate());
        Assert.assertNull(multiplierSaleBillableAdapter.getFixedComissionValue());
        Assert.assertNull(multiplierSaleBillableAdapter.getMarketingValue());
        Assert.assertEquals(multiplierSaleBillableAdapter.getOperationalYear(), harvest.getOperationalYear());
        Assert.assertNull(multiplierSaleBillableAdapter.getPeriod());
        Assert.assertNull(multiplierSaleBillableAdapter.getProductSapCode(), null);
        Assert.assertEquals(multiplierSaleBillableAdapter.getType(), RevenueType.DISTRIBUTION);
        Assert.assertNotNull(multiplierSaleBillableAdapter.getValue());
        Assert.assertEquals(multiplierSaleBillableAdapter.getValue(), new BigDecimal(10));
        Assert.assertEquals(multiplierSaleBillableAdapter.getMaterialDetail(), null);
    }
}
