package com.monsanto.brazilvaluecapture.core.grower.model.bean;

import com.monsanto.brazilvaluecapture.core.foundation.test.AssertHelper;
import org.junit.Before;
import org.junit.Test;

import java.util.Date;

import static junit.framework.Assert.assertNull;
import static org.fest.assertions.Assertions.assertThat;

/**
 * Created with IntelliJ IDEA.
 * User: IFERN1
 * Date: 10/23/13
 * Time: 4:05 PM
 * To change this template use File | Settings | File Templates.
 */
public class GrowerEventDTO_UT {

    GrowerEventDTO growerEventDTO;

    private String growerDocumentMask = "growerDocumentMask";
    private String growerDocumentValue = "growerDocumentValue";
    private String growerSapId = "growerSapId";
    private String growerName = "growerName";
    private GrowerStatusEnum growerStatus = GrowerStatusEnum.getByStatus(false);
    private GrowerBillingStatus growerBillingStatus = GrowerBillingStatus.ACTIVE;
    private Date growerCreationDate = new Date();
    private String growerCreationUser = "growerCreationUser";
    private Date growerApprovalDate = new Date();
    private String growerApprovalUser = "growerApprovalUser";
    private String growerAgreementTechnologyDescription = "growerAgreementTechnologyDescription";
    private Agreement.AgreementStatusEnum growerAgreementStatus = Agreement.AgreementStatusEnum.APPROVED;
    private Date growerAgreementCreationDate = new Date();
    private String growerAgreementCreationUser = "growerAgreementCreationUser";
    private Date growerAgreementApprovalDate = new Date();
    private String growerAgreementApprovalUser = "growerAgreementApprovalUser";
    private String growerAgreementApprovalComment = "growerAgreementApprovalComment";
    private GrowerDocsApproval.ApprovalState growerDocsApprovalState = GrowerDocsApproval.ApprovalState.APPROVED;
    private Date growerDocsApprovalDate = new Date();
    private String growerDocsApprovalUser = "growerDocsApprovalUser";
    private String growerDocsApprovalComment = "growerDocsApprovalComment";
    private Long growerId = 1l;
    private String growerAgreementLicenseNumber = "growerAgreementLicenseNumber";
    private String growerAgreementCustomerDocument = "growerAgreementCustomerDocument";
    private String growerAgreementCustomerDescription = "growerAgreementCustomerDescription";

    @Before
    public void setUp(){
        growerEventDTO = new GrowerEventDTO();
    }

    @Test
    public void test_constructor() {
        GrowerEventDTO growerEventDTO = new GrowerEventDTO(growerDocumentMask, growerDocumentValue, growerSapId,
                growerName, growerStatus.getBooleanValue(),growerBillingStatus.getBooleanValue(), growerCreationDate, growerCreationUser, growerApprovalDate, growerApprovalUser,
                growerAgreementTechnologyDescription, growerAgreementStatus, growerAgreementCreationDate,
                growerAgreementCreationUser, growerAgreementApprovalDate, growerAgreementApprovalUser,
                growerAgreementApprovalComment, growerDocsApprovalState, growerDocsApprovalDate, growerDocsApprovalUser,
                growerDocsApprovalComment, growerId, growerAgreementLicenseNumber, growerAgreementCustomerDocument,
                growerAgreementCustomerDescription);
        assertThat(growerEventDTO.getGrowerDocumentMask()).isEqualTo(growerDocumentMask);
        assertThat(growerEventDTO.getGrowerDocumentValue()).isEqualTo(growerDocumentValue);
        assertThat(growerEventDTO.getGrowerSapId()).isEqualTo(growerSapId);
        assertThat(growerEventDTO.getGrowerName()).isEqualTo(growerName);
        assertThat(growerEventDTO.getGrowerStatus()).isEqualTo(growerStatus);
        assertThat(growerEventDTO.getGrowerBillingStatus()).isEqualTo(GrowerBillingStatus.ACTIVE);
        assertThat(growerEventDTO.getGrowerCreationDate()).isEqualTo(growerCreationDate);
        assertThat(growerEventDTO.getGrowerCreationUser()).isEqualTo(growerCreationUser);
        assertThat(growerEventDTO.getGrowerApprovalDate()).isEqualTo(growerApprovalDate);
        assertThat(growerEventDTO.getGrowerApprovalUser()).isEqualTo(growerApprovalUser);
        assertThat(growerEventDTO.getGrowerAgreementTechnologyDescription()).isEqualTo(growerAgreementTechnologyDescription);
        assertThat(growerEventDTO.getGrowerAgreementStatus()).isEqualTo(growerAgreementStatus);
        assertThat(growerEventDTO.getGrowerAgreementCreationDate()).isEqualTo(growerAgreementCreationDate);
        assertThat(growerEventDTO.getGrowerAgreementCreationUser()).isEqualTo(growerAgreementCreationUser);
        assertThat(growerEventDTO.getGrowerAgreementApprovalDate()).isEqualTo(growerAgreementApprovalDate);
        assertThat(growerEventDTO.getGrowerAgreementApprovalUser()).isEqualTo(growerAgreementApprovalUser);
        assertThat(growerEventDTO.getGrowerAgreementApprovalComment()).isEqualTo(growerAgreementApprovalComment);
        assertThat(growerEventDTO.getGrowerDocsApprovalState()).isEqualTo(growerDocsApprovalState);
        assertThat(growerEventDTO.getGrowerDocsApprovalDate()).isEqualTo(growerDocsApprovalDate);
        assertThat(growerEventDTO.getGrowerDocsApprovalUser()).isEqualTo(growerDocsApprovalUser);
        assertThat(growerEventDTO.getGrowerDocsApprovalComment()).isEqualTo(growerDocsApprovalComment);
        assertThat(growerEventDTO.getGrowerId()).isEqualTo(growerId);
        assertThat(growerEventDTO.getGrowerAgreementLicenseNumber()).isEqualTo(growerAgreementLicenseNumber);
        assertThat(growerEventDTO.getGrowerAgreementCustomerDocument()).isEqualTo(growerAgreementCustomerDocument);
        assertThat(growerEventDTO.getGrowerAgreementCustomerDescription()).isEqualTo(growerAgreementCustomerDescription);
    }

    @Test
    public void test_getters_and_setters() {
        AssertHelper.testGettersAndSetters(growerEventDTO, new String[0]);
    }

    @Test
    public void test_getGrowerDocumentValueFormatted() {
        growerEventDTO.setGrowerDocumentValue("12345678");
        assertThat(growerEventDTO.getGrowerDocumentValueFormatted()).isEqualTo(growerEventDTO.getGrowerDocumentValue());
        growerEventDTO.setGrowerDocumentMask("99.999.999/9999-99");
        assertThat(growerEventDTO.getGrowerDocumentValueFormatted()).isEqualTo("00.000.012/3456-78");
    }

    @Test
    public void test_getGrowerApprovalDateStrict(){
        assertNull(growerEventDTO.getGrowerApprovalDateStrict());
        growerEventDTO.setGrowerStatus(GrowerStatusEnum.getByStatus(true));
        growerEventDTO.setGrowerApprovalDate(growerApprovalDate);
        assertThat(growerEventDTO.getGrowerApprovalDateStrict()).isEqualTo(growerApprovalDate);
    }

    @Test
    public void test_getGrowerApprovalUserStrict(){
      assertNull(growerEventDTO.getGrowerApprovalUserStrict());
        growerEventDTO.setGrowerStatus(GrowerStatusEnum.getByStatus(true));
        growerEventDTO.setGrowerApprovalUser(growerApprovalUser);
        assertThat(growerEventDTO.getGrowerApprovalUserStrict()).isEqualTo(growerApprovalUser);
    }

    @Test
    public void test_getGrowerAgreementStatusLabel(){
        assertNull(growerEventDTO.getGrowerAgreementStatusLabel());
        growerEventDTO.setGrowerAgreementStatus(growerAgreementStatus);
        assertThat(growerEventDTO.getGrowerAgreementStatusLabel()).isEqualTo(growerAgreementStatus.getMessage());
    }

    @Test
    public void test_getGrowerAgreementApprovalDateStrict(){
        assertNull(growerEventDTO.getGrowerAgreementApprovalDateStrict());
        growerEventDTO.setGrowerAgreementStatus(growerAgreementStatus);
        growerEventDTO.setGrowerAgreementApprovalDate(growerAgreementApprovalDate);
        assertThat(growerEventDTO.getGrowerAgreementApprovalDateStrict()).isEqualTo(growerAgreementApprovalDate);
    }

    @Test
    public void test_getGrowerAgreementApprovalUserStrict(){
        assertNull(growerEventDTO.getGrowerAgreementApprovalUserStrict());
        growerEventDTO.setGrowerAgreementStatus(growerAgreementStatus);
        growerEventDTO.setGrowerAgreementApprovalUser(growerAgreementApprovalUser);
        assertThat(growerEventDTO.getGrowerAgreementApprovalUserStrict()).isEqualTo(growerAgreementApprovalUser);
    }

    @Test
    public void test_getGrowerAgreementApprovalCommentStrict(){
        assertNull(growerEventDTO.getGrowerAgreementApprovalCommentStrict());
        growerEventDTO.setGrowerAgreementStatus(growerAgreementStatus);
        growerEventDTO.setGrowerAgreementApprovalComment(growerAgreementApprovalComment);
        assertThat(growerEventDTO.getGrowerAgreementApprovalCommentStrict()).isEqualTo(growerAgreementApprovalComment);
    }

    @Test
    public void test_getGrowerDocsApprovalStateLabel(){
        assertThat(growerEventDTO.getGrowerDocsApprovalStateLabel()).isEqualTo(GrowerDocsApproval.ApprovalState.PENDING_APPROVAL.getLabel());
        growerEventDTO.setGrowerDocsApprovalState(growerDocsApprovalState);
        assertThat(growerEventDTO.getGrowerDocsApprovalStateLabel()).isEqualTo(growerDocsApprovalState.getLabel());
    }

    @Test
    public void test_getGrowerDocsApprovalDateStrict(){
        assertNull(growerEventDTO.getGrowerDocsApprovalDateStrict());
        growerEventDTO.setGrowerDocsApprovalState(growerDocsApprovalState);
        growerEventDTO.setGrowerDocsApprovalDate(growerDocsApprovalDate);
        assertThat(growerEventDTO.getGrowerDocsApprovalDateStrict()).isEqualTo(growerDocsApprovalDate);
    }

    @Test
    public void test_getGrowerDocsApprovalUserStrict(){
        assertNull(growerEventDTO.getGrowerDocsApprovalUserStrict());
        growerEventDTO.setGrowerDocsApprovalState(growerDocsApprovalState);
        growerEventDTO.setGrowerDocsApprovalUser(growerDocsApprovalUser);
        assertThat(growerEventDTO.getGrowerDocsApprovalUserStrict()).isEqualTo(growerDocsApprovalUser);
    }

    @Test
    public void test_getGrowerDocsApprovalCommentStrict(){
        assertNull(growerEventDTO.getGrowerDocsApprovalCommentStrict());
        growerEventDTO.setGrowerDocsApprovalState(growerDocsApprovalState);
        growerEventDTO.setGrowerDocsApprovalComment(growerDocsApprovalComment);
        assertThat(growerEventDTO.getGrowerDocsApprovalCommentStrict()).isEqualTo(growerDocsApprovalComment);
    }
}
