package com.monsanto.brazilvaluecapture.multiplier.revenue.service.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import junit.framework.Assert;

import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.monsanto.brazilvaluecapture.core.base.model.bean.Company;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Crop;
import com.monsanto.brazilvaluecapture.core.commercialhierarchy.model.bean.CommercialHierType;
import com.monsanto.brazilvaluecapture.core.foundation.test.AbstractServiceIntegrationTests;
import com.monsanto.brazilvaluecapture.core.foundation.test.dbunit.DbUnitHelper;
import com.monsanto.brazilvaluecapture.core.foundation.util.CalendarUtil;
import com.monsanto.brazilvaluecapture.multiplier.revenue.model.bean.BillingGermplasmDTO;
import com.monsanto.brazilvaluecapture.multiplier.revenue.model.bean.GermplasmRevenue;
import com.monsanto.brazilvaluecapture.multiplier.revenue.model.bean.GermplasmRevenueStatus;
import com.monsanto.brazilvaluecapture.multiplier.revenue.model.dao.GermplasmRevenueDAO;
import com.monsanto.brazilvaluecapture.multiplier.revenue.service.BillingGermplasmService;
import com.monsanto.brazilvaluecapture.multiplier.volumereport.model.bean.BillingGermplasmView;
import com.monsanto.brazilvaluecapture.multiplier.volumereport.model.dao.BillingGermplasmViewFilter;

public class BillingGermplasmServiceImpl_AT extends AbstractServiceIntegrationTests {

	@Autowired
	GermplasmRevenueDAO germplasmRevenueDAO;
	
	@Autowired
	BillingGermplasmService billingGermplasmService; 
	
	@Before
	public void init() {
        CommercialHierType hierType = (CommercialHierType) getSession().get(CommercialHierType.class, 5l);
        if(getAssumptionTest().isEnvironmentWithSQLANSI() && hierType!=null) {
            DbUnitHelper.setup(
                    "classpath:data/multiplier/germplasm-view-dataset-part1.xml","classpath:data/multiplier/germplasm-view-dataset-part2.xml");
        } else {
            DbUnitHelper.setup(
                    "classpath:data/multiplier/germplasm-view-dataset-part1.xml","classpath:data/multiplier/commercialhierarchytype-local.xml",
                    "classpath:data/multiplier/germplasm-view-dataset-part2.xml","classpath:data/multiplier/vw-local-only-dataset.xml");
        }
	}

	@Test
	public void test_save() {
		GermplasmRevenueStatus status = GermplasmRevenueStatus.APPROVED;
		
		BillingGermplasmDTO bgd = new BillingGermplasmDTO();
		bgd.setGermplasmRevenueId(900000005L);
		
		List<BillingGermplasmDTO> revenues = new ArrayList<BillingGermplasmDTO>();
		revenues.add(bgd);
		
		GermplasmRevenue grBefore = (GermplasmRevenue) getSession().get(GermplasmRevenue.class, 900000005L);
		Assert.assertEquals("Status does not match", GermplasmRevenueStatus.OPEN, grBefore.getGermplasmRevenueStatus());
		
		billingGermplasmService.saveApproval(revenues, status);

		GermplasmRevenue grAfter = (GermplasmRevenue) getSession().get(GermplasmRevenue.class, 900000005L);
		
		Assert.assertEquals("Status does not match", status, grAfter.getGermplasmRevenueStatus());
	}
	
	@Test
	public void test_save_status_null() {
		GermplasmRevenueStatus status = null;
		
		BillingGermplasmDTO bgd = new BillingGermplasmDTO();
		bgd.setGermplasmRevenueId(900000005L);
		
		List<BillingGermplasmDTO> revenues = new ArrayList<BillingGermplasmDTO>();
		revenues.add(bgd);
		
		GermplasmRevenue grBefore = (GermplasmRevenue) getSession().get(GermplasmRevenue.class, 900000005L);
		Assert.assertEquals("Status does not match", GermplasmRevenueStatus.OPEN, grBefore.getGermplasmRevenueStatus());
		
		billingGermplasmService.saveApproval(revenues, status);
		
		GermplasmRevenue grAfter = (GermplasmRevenue) getSession().get(GermplasmRevenue.class, 900000005L);
		
		Assert.assertEquals("Status does not match", GermplasmRevenueStatus.OPEN, grAfter.getGermplasmRevenueStatus());
	}
	
	@Test
    public void given_a_filter_selectBillingGermplasmDTOBy_should_return_billingGermplasmDTOs_with_filtered_parameters() {
    	Company company = (Company) getSession().get(Company.class, 900000001L);
    	Crop crop = (Crop) getSession().get(Crop.class, 900000001L);
    	Date date = CalendarUtil.getDate(2012, 06, 30);
    	GermplasmRevenueStatus status = GermplasmRevenueStatus.BILLED; 
    	List<GermplasmRevenueStatus> statusList = new ArrayList<GermplasmRevenueStatus>();
    	statusList.add(status);
    	
    	BillingGermplasmViewFilter filter = BillingGermplasmViewFilter.getInstance();
    	filter.addCompany(company).addCrop(crop).addExpirationDate(date, date).addStatus(statusList);
    	            	
        List<BillingGermplasmDTO> billingGermplasmDTOs = billingGermplasmService.selectBillingGermplasmDTOBy(filter);
        
        Assert.assertFalse("List of DTOs should not be empty", billingGermplasmDTOs.isEmpty());
        
        for (BillingGermplasmDTO dto : billingGermplasmDTOs) {
        	Assert.assertEquals(company.getDescription(), dto.getCompanyDescription());
        	Assert.assertEquals(crop.getDescription(), dto.getCropDescription());
        	Assert.assertEquals(date, CalendarUtil.normalizeDateToStartOfDay(dto.getExpirationDate()));
        	Assert.assertEquals(status, dto.getRevenueStatus());
		}
    }
	
	@Test
	public void test_select_billing_germplasm_view() {
		Company company = (Company) getSession().get(Company.class, 900000001L);
		Crop crop = (Crop) getSession().get(Crop.class, 900000001L);
		Date date = CalendarUtil.getDate(2012, 06, 30);
		GermplasmRevenueStatus status = GermplasmRevenueStatus.BILLED; 
		List<GermplasmRevenueStatus> statusList = new ArrayList<GermplasmRevenueStatus>();
		statusList.add(status);
		
		BillingGermplasmViewFilter filter = BillingGermplasmViewFilter.getInstance();
		filter.addCompany(company).addCrop(crop).addExpirationDate(date, date).addStatus(statusList);
		
		List<BillingGermplasmView> billingGermplasmViews = billingGermplasmService.selectBillingGermplasmViewBy(filter);
		
		Assert.assertFalse("List of DTOs should not be empty", billingGermplasmViews.isEmpty());
		
		for (BillingGermplasmView view : billingGermplasmViews) {
			Assert.assertEquals(company.getDescription(), view.getCompanyDescription());
			Assert.assertEquals(crop.getDescription(), view.getCropDescription());
			Assert.assertEquals(date, CalendarUtil.normalizeDateToStartOfDay(view.getExpirationDate()));
			Assert.assertEquals(status, view.getRevenueStatus());
		}
	}
	
	@Test
	public void test_count_billing_germplasm_view() {
		Company company = (Company) getSession().get(Company.class, 900000001L);
		Crop crop = (Crop) getSession().get(Crop.class, 900000001L);
		Date date = CalendarUtil.getDate(2012, 06, 30);
		GermplasmRevenueStatus status = GermplasmRevenueStatus.BILLED; 
		List<GermplasmRevenueStatus> statusList = new ArrayList<GermplasmRevenueStatus>();
		statusList.add(status);
		
		BillingGermplasmViewFilter filter = BillingGermplasmViewFilter.getInstance();
		filter.addCompany(company).addCrop(crop).addExpirationDate(date, date).addStatus(statusList);
		
		Integer count = billingGermplasmService.countBillingGermplasmViewBy(filter);
		
		Assert.assertEquals("Quantity does not match", 4, count.intValue());
	}
	
}
