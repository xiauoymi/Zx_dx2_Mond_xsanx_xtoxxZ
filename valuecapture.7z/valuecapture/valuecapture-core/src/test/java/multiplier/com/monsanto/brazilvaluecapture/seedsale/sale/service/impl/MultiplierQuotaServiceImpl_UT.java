package com.monsanto.brazilvaluecapture.seedsale.sale.service.impl;

import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Company;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Country;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Crop;
import com.monsanto.brazilvaluecapture.core.base.model.bean.OperationalYear;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Customer;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.ParticipantTypeEnum;
import com.monsanto.brazilvaluecapture.core.customer.service.CustomerService;
import com.monsanto.brazilvaluecapture.core.foundation.model.bean.StatusEnum;
import com.monsanto.brazilvaluecapture.core.foundation.service.BusinessException;
import com.monsanto.brazilvaluecapture.core.foundation.service.EntityNotFoundException;
import com.monsanto.brazilvaluecapture.multiplier.cultivar.model.bean.Cultivar;
import com.monsanto.brazilvaluecapture.multiplier.obtainer.model.bean.Obtainer;
import com.monsanto.brazilvaluecapture.seedsale.harvest.model.bean.Harvest;
import com.monsanto.brazilvaluecapture.seedsale.harvest.model.bean.Plantability;
import com.monsanto.brazilvaluecapture.seedsale.product.model.bean.Product;
import com.monsanto.brazilvaluecapture.seedsale.quota.model.bean.*;
import com.monsanto.brazilvaluecapture.seedsale.quota.model.dao.QuotaDAO;
import com.monsanto.brazilvaluecapture.seedsale.quota.model.dao.QuotaFilter;
import com.monsanto.brazilvaluecapture.seedsale.quota.model.dao.QuotaTransactionDAO;
import com.monsanto.brazilvaluecapture.seedsale.quota.service.impl.QuotaServiceImpl;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.Sale;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.SaleItem;
import com.monsanto.brazilvaluecapture.seedsale.sale.service.SaleConstraintViolationException;
import com.monsanto.brazilvaluecapture.seedsale.template.model.bean.SaleTemplate;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;

import java.math.BigDecimal;
import java.util.List;
import java.util.Set;

import static org.fest.assertions.Assertions.assertThat;
import static org.fest.assertions.Fail.fail;
import static org.mockito.Mockito.*;


public class MultiplierQuotaServiceImpl_UT extends MultiplierQuotaData {
    private final Country country = new Country("Cuba", "CU");
    private final Company company = new Company("C1");
    Crop crop1 = new Crop("Crop 1", company, country);
    Crop crop2 = new Crop("Crop 2", company, country);
    String description = "CULTIVAR 1";
    Obtainer obtainer1 = new Obtainer("Obtainer 1", StatusEnum.ACTIVE, null);
    Obtainer obtainer2 = new Obtainer("Obtainer 2", StatusEnum.ACTIVE, null);
    private MultiplierQuotaServiceImpl multiplierQuotaService;
    private QuotaTransactionDAO quotaTransactionDAO;

    @Before
    public void setUp() {
        quotaDAO = mock(QuotaDAO.class);
        quotaService = mock(QuotaServiceImpl.class);
        quotaTransactionDAO = mock(QuotaTransactionDAO.class);
        customerHeadOffice = mock(Customer.class);
        multiplierHeadOffice = mock(Customer.class);
        customerService = mock(CustomerService.class);
        operationalYear = new OperationalYear("YEAR");
        multiplierQuotaService = spy(new MultiplierQuotaServiceImpl(quotaService, quotaDAO, quotaTransactionDAO, customerService));
        createProducs();
    }

    @Test
    public void testTransferQuotaFromMultiplierToDealerFailsWithSaleConstraintViolationException_WhenMultiplierHasNotEnoughQuota() throws EntityNotFoundException {
        //@Given a sale from multiplier with not enough quota
        setMultiplierQuotaForProductOf(BigDecimal.ZERO, productGeneratingQuota1);
        final Sale sale = createSaleWithOneSaleItem();

        //@When consume quota from multiplier
        try {
            multiplierQuotaService.transferQuotaFromMultiplierToDealer(sale);
            fail("Should fail with an exception");
        } catch (Exception e) {
            //@Should fail
            assertThat(e).isInstanceOf(SaleConstraintViolationException.class).hasMessage("Not enough quota for product PRODUCTGENERATINGQUOTA1");
        }
    }

    @Test
    public void testTransferQuotaFromMultiplierToDealerConsumesTenAmountsOfQuota_WhenMultiplierHaveEnoughQuotaAndConsumptionOfTenIsRequested() throws Exception {
        //@Given a sale from multiplier with enough quota
        setMultiplierQuotaForProductOf(BigDecimal.TEN, productGeneratingQuota1);
        final Sale sale = createSaleWithOneSaleItem();
        setDistributorQuotaOf(BigDecimal.TEN, productGeneratingQuota1);

        //@When consume quota
        multiplierQuotaService.transferQuotaFromMultiplierToDealer(sale);

        //@Should use que quota service
        BigDecimal expectedBalance = BigDecimal.ZERO;
        verify(quotaDAO, times(2)).getQuotaBy(any(QuotaFilter.class));
        ArgumentCaptor<Quota> quotaArgumentCaptor = ArgumentCaptor.forClass(Quota.class);
        verify(quotaDAO).save(quotaArgumentCaptor.capture());
        Quota savedQuota = quotaArgumentCaptor.getValue();
        assertThat(savedQuota.getBalance()).isEqualTo(expectedBalance);
    }

    @Test
    public void testTransferQuotaFromMultiplierToDealerCallCustomerServiceToQueryForMultiplierHeadOffice_WhenTranferringQuotaFromMultipliertoDealer() throws Exception {
        //@Given a sale from multiplier with enough quota
        setMultiplierQuotaForProductOf(BigDecimal.TEN, productGeneratingQuota1);
        Customer matrix = new Customer();
        final Sale sale = createSaleWithOneSaleItem(matrix);
        setDistributorQuotaOf(BigDecimal.TEN, productGeneratingQuota1);

        //@When consume quota
        multiplierQuotaService.transferQuotaFromMultiplierToDealer(sale);

        //@Should use que quota service
        verify(multiplierQuotaService).consumeQuotaFromMultiplier(any(Product.class), eq(matrix), any(OperationalYear.class), any(BigDecimal.class), anyString(), anyString(), any(Sale.class));
    }

    @Test
    public void testTransferQuotaFromMultiplierToDealerWontConsume_WhenProductIsNotMarkedAsPhase4QuotaGenerator() throws Exception {
        //@Given a sale from multiplier with enough quota
        setDistributorQuotaOf(BigDecimal.ZERO, productNotGeneratingQuota);
        setMultiplierQuotaForProductOf(BigDecimal.TEN, productNotGeneratingQuota);
        final Sale sale = createSaleForProducts(Lists.newArrayList(productNotGeneratingQuota));

        //@When consume quota
        multiplierQuotaService.transferQuotaFromMultiplierToDealer(sale);

        //@Should use que quota service
        verify(quotaDAO, never()).save(any(Quota.class));
    }

    @Test
    public void testTransferQuotaFromMultiplierToDealerWillAssignQuotaToDealer_WhenMultiplierConsumptionSucceed() throws Exception {
        //@Given
        setMultiplierQuotaForProductOf(BigDecimal.TEN, productGeneratingQuota1);
        final Sale sale = createSaleForProducts(Lists.newArrayList(productGeneratingQuota1));
        Quota quota = setDistributorQuotaOf(BigDecimal.TEN, productGeneratingQuota1);

        //@When
        multiplierQuotaService.transferQuotaFromMultiplierToDealer(sale);

        //@Should
        verify(quotaService).fetchOrCreateQuota(customerHeadOffice, productGeneratingQuota1, operationalYear,
                QuotaType.AVAILABLE, lot1, multiplier, plantability1);
        BigDecimal expectedAmount = new BigDecimal(10);
        verify(quotaService).registerCreditQuota(QuotaTransaction.QuotaTransactionType.SALE, quota,
                expectedAmount, sale.getId(), sale.getInvoiceNumber(), sale.getUser());
    }

    @Test
    public void testTransferQuotaFromMultiplierToDealerGenerateQuotaTransactionWithSameInvoiceNumberAsSales_WhenMultiplierConsumptionSucceed() throws Exception {
        //@Given
        setMultiplierQuotaForProductOf(BigDecimal.TEN, productGeneratingQuota1);
        final Sale sale = createSaleForProducts(Lists.newArrayList(productGeneratingQuota1));
        Quota quota = setDistributorQuotaOf(BigDecimal.TEN, productGeneratingQuota1);

        //@When
        multiplierQuotaService.transferQuotaFromMultiplierToDealer(sale);

        //@Should
        final QuotaTransaction quotaTransaction = assertThatQuotaTransactionIsGenerated();
        assertThat(quotaTransaction.getInvoiceNumber()).isNotEmpty().isEqualTo(sale.getInvoiceNumber());
    }

    @Test
    public void testTransferQuotaFromMultiplierToDealerGenerateQuotaTransactionWithTypeSALE_WhenTransactionTypeIsSALE() throws Exception {
        //@Given
        setMultiplierQuotaForProductOf(BigDecimal.TEN, productGeneratingQuota1);
        final Sale sale = createSaleForProducts(Lists.newArrayList(productGeneratingQuota1));
        Quota quota = setDistributorQuotaOf(BigDecimal.TEN, productGeneratingQuota1);

        //@When
        multiplierQuotaService.transferQuotaFromMultiplierToDealer(sale);

        //@Should
        final QuotaTransaction quotaTransaction = assertThatQuotaTransactionIsGenerated();
        assertThat(quotaTransaction.getType()).isEqualTo(QuotaTransaction.QuotaTransactionType.SALE);
    }


    @Test
    public void testTransferQuotaFromMultiplierToDealerGenerateQuotaTransactionWithSameUserAsSale_WhenQuotaIsTransferredFromMultipliertoDealer() throws Exception {
        //@Given
        setMultiplierQuotaForProductOf(BigDecimal.TEN, productGeneratingQuota1);
        final Sale sale = createSaleForProducts(Lists.newArrayList(productGeneratingQuota1));
        Quota quota = setDistributorQuotaOf(BigDecimal.TEN, productGeneratingQuota1);

        //@When
        multiplierQuotaService.transferQuotaFromMultiplierToDealer(sale);

        //@Should
        final QuotaTransaction quotaTransaction = assertThatQuotaTransactionIsGenerated();
        assertThat(quotaTransaction.getLoginUser()).isEqualTo(sale.getUser());
    }

    @Test
    public void testReturnQuotaFromDealerToMultiplierConsumesQuotaFromDealer_WhenDealerHasEnoughQuotaToRevert() throws BusinessException {
        //@Given
        BigDecimal amountToRevert = BigDecimal.TEN;
        setMultiplierQuotaForProductOf(BigDecimal.ZERO, productGeneratingQuota1);
        setDistributorQuotaOf1(amountToRevert, productGeneratingQuota1);
        Sale sale = createSaleForProducts(Lists.newArrayList(productGeneratingQuota1));

        //@When
        multiplierQuotaService.returnQuotaFromDealerToMultiplier(sale);

        //@Should
        ArgumentCaptor<Quota> quotaArgumentCaptor = ArgumentCaptor.forClass(Quota.class);
        verify(quotaDAO, times(2)).save(quotaArgumentCaptor.capture());
    }

    @Test
    public void testReturnQuotaFromDealerToMultiplierInvokesCustomerService_WhenProductGeneratesQuota() throws BusinessException {
        //@Given
        BigDecimal amountToRevert = BigDecimal.TEN;
        setMultiplierQuotaForProductOf(BigDecimal.ZERO, productGeneratingQuota1);
        setDistributorQuotaOf1(amountToRevert, productGeneratingQuota1);
        Sale sale = createSaleForProducts(Lists.newArrayList(productGeneratingQuota1));

        //@When
        multiplierQuotaService.returnQuotaFromDealerToMultiplier(sale);

        //@Should
        verify(customerService).getCustomerHeadOffice(any(Customer.class), any(ParticipantTypeEnum.class));
    }

    @Test
    public void testReturnQuotaFromDealerToMultiplierUsesDealerHeadoffice_WhenProductGeneratesQuota() throws BusinessException {
        //@Given
        BigDecimal amountToRevert = BigDecimal.TEN;
        setMultiplierQuotaForProductOf(BigDecimal.ZERO, productGeneratingQuota1);
        setDistributorQuotaOf1(amountToRevert, productGeneratingQuota1);
        Sale sale = createSaleForProducts(Lists.newArrayList(productGeneratingQuota1));
        Customer dealerHeadoffice = new Customer();
        dealerHeadoffice.setName("DUMMY_DEALER_HEADOFFICE");
        when(customerService.getCustomerHeadOffice(any(Customer.class), any(ParticipantTypeEnum.class))).thenReturn(dealerHeadoffice);

        //@When
        multiplierQuotaService.returnQuotaFromDealerToMultiplier(sale);

        //@Should
        verify(multiplierQuotaService, times(2)).getQuota(eq(dealerHeadoffice), any(Product.class), any(OperationalYear.class), any(QuotaOwner.class), any(Customer.class), any(Plantability.class), anyString());

        verify(multiplierQuotaService, times(1)).saveQuota(any(Product.class), eq(dealerHeadoffice), any(OperationalYear.class), any(BigDecimal.class), anyString(),
                any(QuotaTransaction.QuotaTransactionType.class), anyString(), any(QuotaOwner.class), any(Customer.class), any(Plantability.class), anyString());

        verify(multiplierQuotaService, times(1)).saveQuota(any(Product.class), eq(sale.getCustomerParentOfFirstSaleItem()), any(OperationalYear.class), any(BigDecimal.class), anyString(),
                any(QuotaTransaction.QuotaTransactionType.class), anyString(), any(QuotaOwner.class), any(Customer.class), any(Plantability.class), anyString());
    }

    @Test
    public void testReturnQuotaFromDealerToMultiplierDoesNotModifyDealerQuota_WhenProductDoesNotGenerateQuota() throws BusinessException {
        //@Given
        BigDecimal amountToRevert = BigDecimal.TEN;
        Quota quota = setDistributorQuotaOf1(amountToRevert, productNotGeneratingQuota);
        Sale sale = createSaleForProducts(Lists.newArrayList(productNotGeneratingQuota));

        //@When
        multiplierQuotaService.returnQuotaFromDealerToMultiplier(sale);

        //@Should
        verify(quotaDAO, never()).save(any(Quota.class));
    }

    @Test
    public void testReturnQuotaFromDealerToMultiplierFailsWithInsufficientMultiplierQuotaException_WhenDealerHasNoQuotaAvailable() throws Exception {
        //@Given
        setMultiplierQuotaForProductOf(BigDecimal.ZERO, productGeneratingQuota1);
        setDistributorQuotaOf1(BigDecimal.ONE, productGeneratingQuota1);
        Sale sale = createSaleForProducts(Lists.newArrayList(productGeneratingQuota1));

        try {
            //@When
            multiplierQuotaService.returnQuotaFromDealerToMultiplier(sale);
            fail("Should fail with InsufficientMultiplierQuotaException");
        } catch (Exception e) {
            //@Should
            assertThat(e).isInstanceOf(InsufficientMultiplierQuotaException.class).hasMessage("error.cancellation.quota.insufficient.balance");
        }
    }

    @Test
    public void testGetCultivarsUsesQuotaDAO_WhenMultipliersHeadOfficeHasQuotaForOperationalYear() {

        //@When get cultivars
        List<QuotaByCultivar> cultivarList = multiplierQuotaService.getQuotaByCultivars(multiplier, operationalYear, null, null, null, null);

        //@then should retrieve available products from quota
        verify(quotaDAO).getQuotaByCultivars(operationalYear, multiplier);
    }

    @Test
    public void testGetCultivarFiltersByDescriptionCultivar_WhenDescriptionFilterIsProvided() {
        //@given a list of cultivars
        QuotaByCultivar cultivar1 = new QuotaByCultivar(new Cultivar("Cultivar 1", false, false, StatusEnum.ACTIVE, null, null, null, false), BigDecimal.ZERO);
        QuotaByCultivar cultivar2 = new QuotaByCultivar(new Cultivar("Cultivar 2", false, false, StatusEnum.ACTIVE, null, null, null, false), BigDecimal.ZERO);
        QuotaByCultivar cultivar3 = new QuotaByCultivar(new Cultivar("Cultivar 3", false, false, StatusEnum.ACTIVE, null, null, null, false), BigDecimal.ZERO);
        when(quotaDAO.getQuotaByCultivars(operationalYear, multiplier)).thenReturn(Lists.newArrayList(cultivar1, cultivar2, cultivar3));

        //@When getQuotaByCultivars
        final List<QuotaByCultivar> resultCultivars = multiplierQuotaService.getQuotaByCultivars(multiplier, operationalYear, description, null, null, null);

        //@Then only cultivar with Cultivar 1 description is retrieved
        assertThat(resultCultivars).containsOnly(cultivar1);
    }

    @Test
    public void testGetCultivarWontFilter_WhenNoFiltersAreProvided() {
        //@given a list of cultivars
        QuotaByCultivar cultivar1 = new QuotaByCultivar(new Cultivar("Cultivar 1", false, false, StatusEnum.ACTIVE, null, null, null, false), BigDecimal.ZERO);
        QuotaByCultivar cultivar2 = new QuotaByCultivar(new Cultivar("Cultivar 2", false, false, StatusEnum.ACTIVE, null, null, null, false), BigDecimal.ZERO);
        QuotaByCultivar cultivar3 = new QuotaByCultivar(new Cultivar("Cultivar 3", false, false, StatusEnum.ACTIVE, null, null, null, false), BigDecimal.ZERO);
        when(quotaDAO.getQuotaByCultivars(operationalYear, multiplier)).thenReturn(Lists.newArrayList(cultivar1, cultivar2, cultivar3));

        //@When getQuotaByCultivars
        final List<QuotaByCultivar> resultCultivars = multiplierQuotaService.getQuotaByCultivars(multiplier, operationalYear, null, null, null, null);

        //@Then only cultivar with Cultivar 1 description is retrieved
        assertThat(resultCultivars).contains(cultivar1, cultivar2, cultivar3);
    }

    @Test
    public void testGetCultivarWontFilter_WhenNoFiltersAreProvided1() {
        //@given a list of cultivars
        QuotaByCultivar cultivar1 = new QuotaByCultivar(new Cultivar("Cultivar 1", false, false, StatusEnum.ACTIVE, null, null, null, false), BigDecimal.ZERO);
        QuotaByCultivar cultivar2 = new QuotaByCultivar(new Cultivar("Cultivar 2", false, false, StatusEnum.ACTIVE, null, null, null, false), BigDecimal.ZERO);
        QuotaByCultivar cultivar3 = new QuotaByCultivar(new Cultivar("Cultivar 3", false, false, StatusEnum.ACTIVE, null, null, null, false), BigDecimal.ZERO);
        when(quotaDAO.getQuotaByCultivars(operationalYear, multiplier)).thenReturn(Lists.newArrayList(cultivar1, cultivar2, cultivar3));

        //@When getQuotaByCultivars
        final List<QuotaByCultivar> resultCultivars = multiplierQuotaService.getQuotaByCultivars(multiplier, operationalYear, "", null, null, null);

        //@Then only cultivar with Cultivar 1 description is retrieved
        assertThat(resultCultivars).contains(cultivar1, cultivar2, cultivar3);
    }

    @Test
    public void testGetCultivarFiltersByObtainerObtainer1_WhenObtainerFilterIsProvided() {
        //@given a list of cultivars
        QuotaByCultivar cultivar1 = new QuotaByCultivar(new Cultivar("Cultivar 1", false, false, StatusEnum.ACTIVE, null, obtainer1, null, false), BigDecimal.ZERO);
        QuotaByCultivar cultivar2 = new QuotaByCultivar(new Cultivar("Cultivar 2", false, false, StatusEnum.ACTIVE, null, obtainer2, null, false), BigDecimal.ZERO);
        QuotaByCultivar cultivar3 = new QuotaByCultivar(new Cultivar("Cultivar 3", false, false, StatusEnum.ACTIVE, null, obtainer2, null, false), BigDecimal.ZERO);
        when(quotaDAO.getQuotaByCultivars(operationalYear, multiplier)).thenReturn(Lists.newArrayList(cultivar1, cultivar2, cultivar3));

        //@When getQuotaByCultivars
        final List<QuotaByCultivar> resultCultivars = multiplierQuotaService.getQuotaByCultivars(multiplier, operationalYear, null, obtainer1, null, null);

        //@Then only cultivar with Cultivar 1 description is retrieved
        assertThat(resultCultivars).containsOnly(cultivar1);
    }

    @Test
    public void testGetCultivarFiltersByTechnology_WhenTechnologyFilterIsProvided() {
        //@given a list of cultivars
        QuotaByCultivar cultivar1 = new QuotaByCultivar(new Cultivar("Cultivar 1", false, false, StatusEnum.ACTIVE, null, null, null, false), BigDecimal.ZERO);
        cultivar1.getCultivar().setProduct(productGeneratingQuota1);
        QuotaByCultivar cultivar2 = new QuotaByCultivar(new Cultivar("Cultivar 2", false, false, StatusEnum.ACTIVE, null, null, null, false), BigDecimal.ZERO);
        cultivar2.getCultivar().setProduct(productNotGeneratingQuota);
        QuotaByCultivar cultivar3 = new QuotaByCultivar(new Cultivar("Cultivar 3", false, false, StatusEnum.ACTIVE, null, null, null, false), BigDecimal.ZERO);
        cultivar3.getCultivar().setProduct(productNotGeneratingQuota);
        when(quotaDAO.getQuotaByCultivars(operationalYear, multiplier)).thenReturn(Lists.newArrayList(cultivar1, cultivar2, cultivar3));

        //@When getQuotaByCultivars
        final List<QuotaByCultivar> resultCultivars = multiplierQuotaService.getQuotaByCultivars(multiplier, operationalYear, null, null, technology1, null);

        //@Then only cultivar with Cultivar 1 description is retrieved
        assertThat(resultCultivars).containsOnly(cultivar1);
    }

    @Test
    public void testGetCultivarFiltersByCrop_WhenCropFilterIsProvided() {
        //@given a list of cultivars
        QuotaByCultivar cultivar1 = new QuotaByCultivar(new Cultivar("Cultivar 1", false, false, StatusEnum.ACTIVE, crop1, null, null, false), BigDecimal.ZERO);
        QuotaByCultivar cultivar2 = new QuotaByCultivar(new Cultivar("Cultivar 2", false, false, StatusEnum.ACTIVE, crop2, null, null, false), BigDecimal.ZERO);
        QuotaByCultivar cultivar3 = new QuotaByCultivar(new Cultivar("Cultivar 3", false, false, StatusEnum.ACTIVE, crop2, null, null, false), BigDecimal.ZERO);
        when(quotaDAO.getQuotaByCultivars(operationalYear, multiplier)).thenReturn(Lists.newArrayList(cultivar1, cultivar2, cultivar3));

        //@When getQuotaByCultivars
        final List<QuotaByCultivar> resultCultivars = multiplierQuotaService.getQuotaByCultivars(multiplier, operationalYear, null, null, null, crop1);

        //@Then only cultivar with Cultivar 1 description is retrieved
        assertThat(resultCultivars).containsOnly(cultivar1);
    }

    @Test
    public void testGetCultivarFiltersByDescriptionObtainerAndTechnology_WhenDescriptionObtainerAndTechnologyFiltersAreProvided
            () {
        //@given a list of cultivars
        QuotaByCultivar cultivar1 = new QuotaByCultivar(new Cultivar("Cultivar 1", false, false, StatusEnum.ACTIVE, crop1, obtainer1, null, false), BigDecimal.ZERO);
        cultivar1.getCultivar().setProduct(productGeneratingQuota1);
        QuotaByCultivar cultivar2 = new QuotaByCultivar(new Cultivar("Cultivar 2", false, false, StatusEnum.ACTIVE, crop2, obtainer2, null, false), BigDecimal.ZERO);
        cultivar2.getCultivar().setProduct(productNotGeneratingQuota);
        QuotaByCultivar cultivar3 = new QuotaByCultivar(new Cultivar("Cultivar 3", false, false, StatusEnum.ACTIVE, crop2, obtainer2, null, false), BigDecimal.ZERO);
        cultivar3.getCultivar().setProduct(productNotGeneratingQuota);
        when(quotaDAO.getQuotaByCultivars(operationalYear, multiplier)).thenReturn(Lists.newArrayList(cultivar1, cultivar2, cultivar3));

        //@When getQuotaByCultivars
        final List<QuotaByCultivar> resultCultivars = multiplierQuotaService.getQuotaByCultivars(multiplier, operationalYear, description, obtainer1, technology1, crop1);

        //@Then only cultivar with Cultivar 1 description is retrieved
        assertThat(resultCultivars).containsOnly(cultivar1);
    }


    @Test
    public void testSaveQuotaCreatesNewQuotaEntry_WhenSavingQuota() throws EntityNotFoundException {
        //@Given an existing quota
        BigDecimal balance = BigDecimal.TEN;
        final Quota quota = setMultiplierQuotaForProductOf(BigDecimal.TEN, productGeneratingQuota1);
        when(quotaDAO.save(quota)).thenReturn(quota);

        //@When saving modifications
        final Quota savedQuota = multiplierQuotaService.saveQuota(productGeneratingQuota1, multiplier, operationalYear, balance, null, null, "");

        //@Then should add new QuotaEntry to quota
        assertThat(savedQuota.getEntries()).isNotEmpty();
    }

    @Test
    public void testSaveQuotaCreatesQuotaTransactionLine_WhenSavingQuota() throws EntityNotFoundException {
        //@Given
        BigDecimal balace = BigDecimal.TEN;
        final Quota quota = setMultiplierQuotaForProductOf(BigDecimal.TEN, productGeneratingQuota1);
        when(quotaDAO.save(quota)).thenReturn(quota);

        //@When
        multiplierQuotaService.saveQuota(productGeneratingQuota1, multiplier, operationalYear, balace, null, QuotaTransaction.QuotaTransactionType.SALE, "");

        //@Then
        QuotaTransaction quotaTransaction = assertThatQuotaTransactionIsGenerated();
        assertThat(quotaTransaction.getTransactionDate()).isNotNull();
        assertThat(quotaTransaction.getLoginUser()).isNotNull();
        assertThat(quotaTransaction.getType()).isNotNull();
        assertThat(quotaTransaction.getEntries()).isNotEmpty();
        assertThat(quotaTransaction.getEntries().get(0).getQuotaTransaction()).isEqualTo(quotaTransaction);
    }

    @Test
    public void testGetQuotaCreatesANewQuotaWithGivenLot_WhenQuotaDoesNotExists() throws EntityNotFoundException {
        when(quotaDAO.getQuotaBy(any(QuotaFilter.class))).thenThrow(EntityNotFoundException.class);

        multiplierQuotaService.getQuota(customer1, productGeneratingQuota1, operationalYear, QuotaOwner.DEALER, multiplier, plantability1, lot1);

        ArgumentCaptor<Quota> quotaCaptor = ArgumentCaptor.forClass(Quota.class);
        verify(quotaDAO).save(quotaCaptor.capture());
        final Quota savedQuota = quotaCaptor.getValue();
        assertThat(savedQuota.getLot()).isEqualTo(lot1);
    }

    @Test
    public void testGetQuotaCreatesANewQuotaWithGivenPlantability_WhenQuotaDoesNotExists() throws EntityNotFoundException {
        when(quotaDAO.getQuotaBy(any(QuotaFilter.class))).thenThrow(EntityNotFoundException.class);

        multiplierQuotaService.getQuota(customer1, productGeneratingQuota1, operationalYear, QuotaOwner.DEALER, multiplier, plantability1, lot1);

        ArgumentCaptor<Quota> quotaCaptor = ArgumentCaptor.forClass(Quota.class);
        verify(quotaDAO).save(quotaCaptor.capture());
        final Quota savedQuota = quotaCaptor.getValue();
        assertThat(savedQuota.getPlantability()).isEqualTo(plantability1);
    }

    @Test
    public void testGetQuotaCreatesANewQuotaWithGivenMultiplier_WhenQuotaDoesNotExists() throws EntityNotFoundException {
        when(quotaDAO.getQuotaBy(any(QuotaFilter.class))).thenThrow(EntityNotFoundException.class);

        multiplierQuotaService.getQuota(customer1, productGeneratingQuota1, operationalYear, QuotaOwner.DEALER, multiplier, plantability1, lot1);

        ArgumentCaptor<Quota> quotaCaptor = ArgumentCaptor.forClass(Quota.class);
        verify(quotaDAO).save(quotaCaptor.capture());
        final Quota savedQuota = quotaCaptor.getValue();
        assertThat(savedQuota.getMultiplier()).isEqualTo(multiplier);
    }

    @Test
    public void testGetQuotaCreatesANewQuotaWithNullLot_WhenQuotaWithNullLotIsRequestedAndQuotaDoesNotExists() throws EntityNotFoundException {
        when(quotaDAO.getQuotaBy(any(QuotaFilter.class))).thenThrow(EntityNotFoundException.class);

        multiplierQuotaService.getQuota(customer1, productGeneratingQuota1, operationalYear, QuotaOwner.DEALER, multiplier, plantability1, null);

        ArgumentCaptor<Quota> quotaCaptor = ArgumentCaptor.forClass(Quota.class);
        verify(quotaDAO).save(quotaCaptor.capture());
        final Quota savedQuota = quotaCaptor.getValue();
        assertThat(savedQuota.getLot()).isNull();
    }

    @Test
    public void testGetQuotaCreatesANewQuotaWithNullPlantability_WhenQuotaWithNullPlantabilityIsRequestedAndQuotaDoesNotExists() throws EntityNotFoundException {
        when(quotaDAO.getQuotaBy(any(QuotaFilter.class))).thenThrow(EntityNotFoundException.class);

        multiplierQuotaService.getQuota(customer1, productGeneratingQuota1, operationalYear, QuotaOwner.DEALER, multiplier, null, lot1);

        ArgumentCaptor<Quota> quotaCaptor = ArgumentCaptor.forClass(Quota.class);
        verify(quotaDAO).save(quotaCaptor.capture());
        final Quota savedQuota = quotaCaptor.getValue();
        assertThat(savedQuota.getPlantability()).isNull();
    }

    @Test
    public void testGetQuotaCreatesANewQuotaWithNullMultiplier_WhenQuotaWithNullMultiplierIsRequestedAndQuotaDoesNotExists() throws EntityNotFoundException {
        when(quotaDAO.getQuotaBy(any(QuotaFilter.class))).thenThrow(EntityNotFoundException.class);

        multiplierQuotaService.getQuota(customer1, productGeneratingQuota1, operationalYear, QuotaOwner.DEALER, null, plantability1, lot1);

        ArgumentCaptor<Quota> quotaCaptor = ArgumentCaptor.forClass(Quota.class);
        verify(quotaDAO).save(quotaCaptor.capture());
        final Quota savedQuota = quotaCaptor.getValue();
        assertThat(savedQuota.getMultiplier()).isNull();
    }

    private QuotaTransaction assertThatQuotaTransactionIsGenerated() {
        ArgumentCaptor<QuotaTransaction> quotaTransactionArgumentCaptor = ArgumentCaptor.forClass(QuotaTransaction.class);
        verify(quotaTransactionDAO).save(quotaTransactionArgumentCaptor.capture());
        return quotaTransactionArgumentCaptor.getValue();
    }

    @Test
    public void testConsumeQuotaFromMultiplierAssignCreditToGrowerConsumesTenAmountsOfQuota_WhenMultiplierHaveEnoughQuotaAndConsumptionOfTenIsRequested() throws Exception {
        //@Given a sale from multiplier with enough quota
        setMultiplierQuotaForProductOf(BigDecimal.TEN, productGeneratingQuota1);
        final Sale sale = createSaleWithOneSaleItem();
        setDistributorQuotaOf(BigDecimal.TEN, productGeneratingQuota1);

        //@When consume quota
        multiplierQuotaService.consumeQuotaFromMultiplier(sale);

        //@Should use que quota service
        BigDecimal expectedBalance = BigDecimal.ZERO;
        verify(quotaDAO, times(2)).getQuotaBy(any(QuotaFilter.class));
        ArgumentCaptor<Quota> quotaArgumentCaptor = ArgumentCaptor.forClass(Quota.class);
        verify(quotaDAO).save(quotaArgumentCaptor.capture());
        Quota savedQuota = quotaArgumentCaptor.getValue();
        assertThat(savedQuota.getBalance()).isEqualTo(expectedBalance);
    }

    @Test
    public void testConsumeQuotaFromMultiplierFailsWithSaleConstraintViolationException_WhenMultiplierHaveNoEnoughQuota() throws EntityNotFoundException {
        //@Given a sale from multiplier with enough quota
        setMultiplierQuotaForProductOf(BigDecimal.ZERO, productGeneratingQuota1);
        final Sale sale = createSaleWithOneSaleItem();
        setDistributorQuotaOf(BigDecimal.TEN, productGeneratingQuota1);

        //@When consume quota
        try {
            multiplierQuotaService.consumeQuotaFromMultiplier(sale);
            fail("Should throw SaleConstraintViolationException");
        } catch (Exception e) {
            assertThat(e).isInstanceOf(SaleConstraintViolationException.class).hasMessage("Not enough quota for product PRODUCTGENERATINGQUOTA1");
        }
    }

    @Test
    public void testConsumeQuotaFromMultiplierWithMatrix_whenQuotaIsTriggered() throws SaleConstraintViolationException, EntityNotFoundException {
        Customer matrix = new Customer();
        Sale sale = createSaleWithOneSaleItem(matrix);
        Quota quota = new Quota();
        quota.getEntries().add(new QuotaEntry(quota, BigDecimal.TEN));
        quota.setBalance(BigDecimal.TEN);
        when(quotaDAO.getQuotaBy(any(QuotaFilter.class))).thenReturn(quota);

        multiplierQuotaService.consumeQuotaFromMultiplier(sale);

        verify(multiplierQuotaService).consumeQuotaFromMultiplier(any(Product.class), eq(matrix), any(OperationalYear.class), any(BigDecimal.class), anyString(), anyString(), any(Sale.class));
    }

    @Test
    public void testReturnQuotaFromGrowerToMultiplierSavesQuotaWithHeadoffice_whenQuotaSaveIsTriggered() throws BusinessException {
        Harvest harvest = new Harvest();
        OperationalYear operationalYear = new OperationalYear();
        SaleTemplate saleTemplate = new SaleTemplate();
        saleTemplate.setHarvest(harvest);
        Customer matrix = new Customer();
        Sale sale = createSale(harvest, operationalYear, saleTemplate, matrix, productGeneratingQuota1);
        Quota quota = createQuota();
        when(quotaDAO.getQuotaBy(any(QuotaFilter.class))).thenReturn(quota);

        multiplierQuotaService.returnQuotaFromGrowerToMultiplier(sale);

        verify(multiplierQuotaService).saveQuota(productGeneratingQuota1, matrix, operationalYear, BigDecimal.TEN, sale.getInvoiceNumber(),
                QuotaTransaction.QuotaTransactionType.REVERSAL, sale.getUser(), QuotaOwner.MULTIPLIER, sale.getCustomer(), null, null);
    }

    private Quota createQuota() {
        Quota quota = new Quota();
        quota.getEntries().add(new QuotaEntry(quota, BigDecimal.valueOf(1000)));
        quota.setBalance(new BigDecimal(1000L));
        return quota;
    }

    private Sale createSale(Harvest harvest, OperationalYear operationalYear, SaleTemplate saleTemplate, Customer matrix, Product product) {
        Sale sale = new Sale();
        SaleItem saleItem = new SaleItem();
        harvest.setOperationalYear(operationalYear);
        saleItem.setSaleTemplate(saleTemplate);
        saleItem.setCustomerParent(matrix);
        saleItem.setSoldQuantity(10l);
        saleItem.setProduct(product);
        Set<SaleItem> saleItems = Sets.newHashSet(saleItem);
        sale.setItems(saleItems);
        return sale;
    }

}