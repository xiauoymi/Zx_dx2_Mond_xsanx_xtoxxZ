package com.monsanto.brazilvaluecapture.seedsale.sale.service.impl;

import com.monsanto.brazilvaluecapture.core.base.model.bean.Company;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Country;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Crop;
import com.monsanto.brazilvaluecapture.core.base.model.bean.OperationalYear;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Customer;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Technology;
import com.monsanto.brazilvaluecapture.core.foundation.model.bean.StatusEnum;
import com.monsanto.brazilvaluecapture.core.foundation.service.EntityNotFoundException;
import com.monsanto.brazilvaluecapture.core.grower.model.bean.Grower;
import com.monsanto.brazilvaluecapture.multiplier.cultivar.model.bean.Cultivar;
import com.monsanto.brazilvaluecapture.multiplier.obtainer.model.bean.Obtainer;
import com.monsanto.brazilvaluecapture.multiplier.seedsale.model.dao.SaleLinkDetailDAO;
import com.monsanto.brazilvaluecapture.seedsale.harvest.model.bean.Harvest;
import com.monsanto.brazilvaluecapture.seedsale.harvest.model.bean.Plantability;
import com.monsanto.brazilvaluecapture.seedsale.harvest.model.bean.PlantabilitySystemEnum;
import com.monsanto.brazilvaluecapture.seedsale.product.model.bean.Brand;
import com.monsanto.brazilvaluecapture.seedsale.product.model.bean.Product;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.Sale;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.SaleItem;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.SaleLinkDetail;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.dao.MultiplierSaleDAO;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.dao.SaleDAO;
import com.monsanto.brazilvaluecapture.seedsale.template.model.bean.SaleTemplate;
import org.junit.Before;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import static org.mockito.Matchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class ControllershipTestConfigurator {
    protected Customer dealer;
    protected Plantability plantability;
    protected SaleDAO saleDAO;
    protected SaleLinkDetailDAO saleLinkDetailDAO;
    protected MultiplierSaleDAO multiplierSaleDAO;
    private Crop crop;
    private Company company;
    private Harvest harvest;

    Sale createSale(List<ItemDescription> itemDescriptions) {
        Sale sale = createMultiplierSale();
        for (ItemDescription itemDescription : itemDescriptions) {
            addSaleItemToSale(sale, itemDescription, null);
        }
        return sale;
    }

    protected Sale createMultiplierSale() {
        Customer multiplier = new Customer();
        return new Sale(multiplier, dealer);
    }

    protected Sale createDealerSale(Date creationDate) {
        Customer dealer = new Customer();
        final Sale sale = new Sale(dealer, new Grower());
        sale.setCreationDate(creationDate);
        return sale;
    }

    protected Plantability createPlantability(String description) {
        return new Plantability(harvest, description, StatusEnum.ACTIVE, PlantabilitySystemEnum.NO);
    }

    protected SaleItem addSaleItemToSale(Sale sale, ItemDescription itemDescription, BigDecimal netQty) {
        SaleItem saleItem = new SaleItem(sale, new SaleTemplate(), itemDescription.getProduct(), sale.getCustomer());
        saleItem.setLot(itemDescription.getBatchName());
        saleItem.setPlantabilityId(itemDescription.getPlantability());
        saleItem.setSoldQuantity(itemDescription.getSoldQty().longValue());
        saleItem.setHaAmount(itemDescription.getHaAmount());
        saleItem.setNetQuantity(netQty);
        return saleItem;
    }

    protected SaleItem addSaleItemToSale(Sale sale, ItemDescription itemDescription, BigDecimal netQty, BigDecimal revenueRecognition) {
        SaleItem saleItem = new SaleItem(sale, new SaleTemplate(), itemDescription.getProduct(), sale.getCustomer());
        saleItem.setLot(itemDescription.getBatchName());
        saleItem.setPlantabilityId(itemDescription.getPlantability());
        saleItem.setSoldQuantity(itemDescription.getSoldQty().longValue());
        saleItem.setHaAmount(itemDescription.getHaAmount());
        saleItem.setNetQuantity(netQty);
        saleItem.setRevenueRecognition(revenueRecognition);
        return saleItem;
    }

    protected Product createProduct(String description, boolean revenueRecognitionExcluded) {
        Product product = new Product(description, StatusEnum.ACTIVE, crop, new Technology(), new Brand(), company);
        Cultivar cultivar = new Cultivar();
        Obtainer obtainer = new Obtainer();
        obtainer.setRevenueRecognitionExcluded(revenueRecognitionExcluded);
        cultivar.setObtainer(obtainer);
        product.setCultivar(cultivar);
        return product;
    }

    @Before
    public void saleLinkDetailRegisterTestConfiguratorSetUp() {
        dealer = new Customer();
        Country country = new Country("BRAZIL", "BR");
        company = new Company("Company 1");
        company.setCountry(country);
        crop = new Crop("Crop 1", company, country);
        final OperationalYear operationalYear = new OperationalYear("OY 1");
        harvest = new Harvest(company, "Harvest 1", operationalYear, crop, StatusEnum.ACTIVE);
        plantability = createPlantability("Plantability 1");
        saleDAO = mock(SaleDAO.class);
        saleLinkDetailDAO = mock(SaleLinkDetailDAO.class);
        multiplierSaleDAO = mock(MultiplierSaleDAO.class);
    }

    public Sale createSaleWithOneSaleItem(Product product1, String batchName, Plantability plantability, BigDecimal soldQty) {
        final ItemDescription itemDescription = new ItemDescription(soldQty, product1, batchName, plantability, BigDecimal.valueOf(20));
        Sale sale = createMultiplierSale();
        addSaleItemToSale(sale, itemDescription, null);
        return sale;
    }

    public Sale createSaleWithTwoSaleItems(Product product1, String batchName1, Plantability plantability1, Product product2, String batchName2, Plantability plantability2, BigDecimal soldQty) {
        final ItemDescription itemDescription = new ItemDescription(soldQty, product1, batchName1, plantability1, BigDecimal.valueOf(20));
        final ItemDescription itemDescription1 = new ItemDescription(soldQty, product2, batchName2, plantability2, BigDecimal.valueOf(20));
        Sale sale = createMultiplierSale();
        addSaleItemToSale(sale, itemDescription, null);
        addSaleItemToSale(sale, itemDescription1, null);
        return sale;
    }

    protected void willFindOneSalelinkDetailForSale(Product product, String batchName, BigDecimal soldQty) throws EntityNotFoundException {
        Sale multiplierSale = new Sale(new Customer(), new Customer());
        SaleItem saleItem = addSaleItemToSale(multiplierSale, new ItemDescription(soldQty, product, batchName, plantability, BigDecimal.valueOf(20)), null);
        SaleLinkDetail saleLinkDetail = new SaleLinkDetail(multiplierSale, saleItem);
        when(saleLinkDetailDAO.getCorrespondingSaleLinkDetail(any(SaleItem.class))).thenReturn(saleLinkDetail);
    }

    protected class ItemDescription {
        private final BigDecimal soldQty;
        private final Product product;
        private final String batchName;
        private final Plantability plantability;

        private final BigDecimal haAmount;

        public ItemDescription(BigDecimal soldQty, Product product, String batchName, Plantability plantability, BigDecimal haAmount) {
            this.soldQty = soldQty;
            this.product = product;
            this.batchName = batchName;
            this.plantability = plantability;
            this.haAmount = haAmount;
        }

        public BigDecimal getSoldQty() {
            return soldQty;
        }

        public Product getProduct() {
            return product;
        }

        public String getBatchName() {
            return batchName;
        }

        public Plantability getPlantability() {
            return plantability;
        }

        public BigDecimal getHaAmount() {
            return haAmount;
        }
    }
}
