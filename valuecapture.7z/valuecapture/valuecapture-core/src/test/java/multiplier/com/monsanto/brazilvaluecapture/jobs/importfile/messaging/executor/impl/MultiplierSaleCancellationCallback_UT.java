package com.monsanto.brazilvaluecapture.jobs.importfile.messaging.executor.impl;

import com.monsanto.brazilvaluecapture.core.foundation.util.ConstraintViolation;
import com.monsanto.brazilvaluecapture.core.importfile.model.ImportFileType;
import com.monsanto.brazilvaluecapture.core.importfile.model.bean.CsvImportFile;
import com.monsanto.brazilvaluecapture.core.importfile.service.CsvImportFileService;
import com.monsanto.brazilvaluecapture.core.user.model.bean.UserDecorator;
import com.monsanto.brazilvaluecapture.core.user.service.UserService;
import com.monsanto.brazilvaluecapture.jobs.importfile.messaging.bean.FileImportDefinition;
import com.monsanto.brazilvaluecapture.jobs.importfile.messaging.bean.FileImportInfo;
import com.monsanto.brazilvaluecapture.jobs.importfile.messaging.bean.FileImportOperation;
import com.monsanto.brazilvaluecapture.jobs.importfile.messaging.executor.ImportFileCallbackException;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.Cancellation;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.ImportFileStatus;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.Sale;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.SaleCancellationEntry;
import com.monsanto.brazilvaluecapture.seedsale.sale.service.BillingCancellationWarningException;
import com.monsanto.brazilvaluecapture.seedsale.sale.service.MultiplierSaleService;
import com.monsanto.brazilvaluecapture.seedsale.sale.service.SaleCancellationService;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.Locale;
import java.util.ResourceBundle;

import static junit.framework.Assert.fail;
import static org.fest.assertions.Assertions.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyCollection;
import static org.mockito.Matchers.anyList;
import static org.mockito.Mockito.anyString;
import static org.mockito.Mockito.*;

/**
 * Created with IntelliJ IDEA.
 * User: IFERN1
 * Date: 10/22/13
 * Time: 10:13 AM
 * To change this template use File | Settings | File Templates.
 */
@RunWith(MockitoJUnitRunner.class)
public class MultiplierSaleCancellationCallback_UT {
    @Mock
    private UserService userService;

    @Mock
    private MultiplierSaleService multiplierSaleService;

    @Mock
    private SaleCancellationService saleCancellationService;

    @Mock
    private CsvImportFileService csvImportFileService;

    @InjectMocks
    private MultiplierSaleCancellationCallback saleCancellationCallback;

    @Test
    public void when_importFileCallback_with_CANCEL_fileOperation_and_wrongFileType_then_throws_IllegalStateException() throws ImportFileCallbackException {
        //@Given
        FileImportInfo fileImportInfo = initFileImportInfo(ImportFileStatus.CANCELLED, FileImportOperation.CANCEL);

        //@When
        try {
            saleCancellationCallback.importFileCallback(fileImportInfo);
            fail("Should throw IllegalStateException exception");
        } catch (Exception e) {
            //@Should throw an IllegalStateException
            assertThat(e).isInstanceOf(IllegalStateException.class).hasMessage("Invalid status for cancel: " + fileImportInfo);
        }

    }

    @Test
    public void when_importFileCallback_with_CANCEL_fileOperation_then_cancellation_fails_with_ImportFileCallbackException() throws ImportFileCallbackException {
        //@Given
        FileImportInfo fileImportInfo = initFileImportInfo(ImportFileStatus.AWAITING_CANCELLING, FileImportOperation.CANCEL);

        //@When
        try {
            saleCancellationCallback.importFileCallback(fileImportInfo);
            fail("Should throw ImportFileCallbackException exception");
        } catch (Exception e) {
            //@Should
            assertThat(e).isInstanceOf(ImportFileCallbackException.class).hasMessage("Unexpected error during cancellation: " + fileImportInfo);
        }
    }

    @Test
    public void when_importFileCallback_with_IMPORT_fileOperation_and_wrongFileType_then_importation_fails_with_IllegalStateException() throws ImportFileCallbackException {
        //@Given
        FileImportInfo fileImportInfo = initFileImportInfo(ImportFileStatus.AWAITING_CANCELLING, FileImportOperation.IMPORT);

        //@When
        try {
            saleCancellationCallback.importFileCallback(fileImportInfo);
            fail("Should throw IllegalStateException exception");
        } catch (Exception e) {
            //@Should
            assertThat(e).isInstanceOf(IllegalStateException.class).hasMessage("Invalid status for import [Expected: UPLOADED; Value: " + fileImportInfo.getFile().getFileStatus() + "]");
        }
    }

    @Test
    public void when_importFileCallback_with_IMPORT_fileOperation_then_proceed_fails_with_ImportFileCallbackException() throws ImportFileCallbackException {
        //@Given
        FileImportInfo fileImportInfo = initFileImportInfo(ImportFileStatus.UPLOADED, FileImportOperation.IMPORT);

        //@When
        try {
            saleCancellationCallback.importFileCallback(fileImportInfo);
            fail("Should throw ImportFileCallbackException exception");
        } catch (Exception e) {
            //@Should
            assertThat(e).isInstanceOf(ImportFileCallbackException.class).hasMessage("Unexpected error during validation: " + fileImportInfo);
        }
    }

    @Test
    public void when_processing_a_asynchronous_multiplier_seed_sale_cancellation_does_not_fail() throws BillingCancellationWarningException {
        //@Given
        UserDecorator userDecorator = mock(UserDecorator.class);
        CsvImportFile file = new CsvImportFile();
        FileImportInfo fileImportInfo = initFileImportInfo(ImportFileStatus.PROCESSED, FileImportOperation.CANCEL);

        ArrayList<SaleCancellationEntry> saleCancellationEntries = new ArrayList<SaleCancellationEntry>();
        Sale sale=new Sale();
        sale.setId(1L);

        SaleCancellationEntry saleCancellationEntry = new SaleCancellationEntry(sale, new Cancellation(), file);

        saleCancellationEntries.add(saleCancellationEntry);
        when(saleCancellationService.getSaleCancellationEntryByCsvImportFile(any(CsvImportFile.class))).thenReturn(saleCancellationEntries);
        when(userService.getItsUserByLogin(any(String.class))).thenReturn(userDecorator);
        when(multiplierSaleService.getSaleById(any(Long.class))).thenReturn(sale);

        //@When
        saleCancellationCallback.doProceed(fileImportInfo);

        //@Should
        verify(multiplierSaleService).cancelMultipleSales(anyCollection(), anyList(), any(Cancellation.class), anyString());
    }

    @Test
    public void when_processing_a_asynchronous_multiplier_seed_sale_cancellation_does_nothing_with_empty_entries() throws BillingCancellationWarningException {
        //@Given
        UserDecorator userDecorator = mock(UserDecorator.class);
        CsvImportFile file = new CsvImportFile();
        FileImportInfo fileImportInfo = initFileImportInfo(ImportFileStatus.PROCESSED, FileImportOperation.CANCEL);

        ArrayList<SaleCancellationEntry> saleCancellationEntries = new ArrayList<SaleCancellationEntry>();
        when(saleCancellationService.getSaleCancellationEntryByCsvImportFile(any(CsvImportFile.class))).thenReturn(saleCancellationEntries);
        when(userService.getItsUserByLogin(any(String.class))).thenReturn(userDecorator);

        //@When
        saleCancellationCallback.doProceed(fileImportInfo);

        //@Should

    }

    @Test
    public void when_processing_a_asynchronous_multiplier_seed_sale_cancellation_fail_should_through_exception() throws BillingCancellationWarningException {
        //@Given
        UserDecorator userDecorator = mock(UserDecorator.class);
        CsvImportFile file = new CsvImportFile();
        FileImportInfo fileImportInfo = initFileImportInfo(ImportFileStatus.PROCESSED, FileImportOperation.CANCEL);

        ArrayList<SaleCancellationEntry> saleCancellationEntries = new ArrayList<SaleCancellationEntry>();
        Sale sale=new Sale();
        sale.setId(1L);

        SaleCancellationEntry saleCancellationEntry = new SaleCancellationEntry(sale, new Cancellation(), file);

        saleCancellationEntries.add(saleCancellationEntry);
        when(saleCancellationService.getSaleCancellationEntryByCsvImportFile(any(CsvImportFile.class))).thenReturn(saleCancellationEntries);
        when(userService.getItsUserByLogin(any(String.class))).thenReturn(userDecorator);
        when(multiplierSaleService.getSaleById(any(Long.class))).thenReturn(sale);
        doThrow(new BillingCancellationWarningException("Error Message")).when(multiplierSaleService).cancelMultipleSales(anyCollection(), anyList(), any(Cancellation.class), any(String.class));
        Logger logger = LogManager.getLogger(MultiplierSaleCancellationCallback.class);

        //@When
        saleCancellationCallback.doProceed(fileImportInfo);

        //@Should
        verify(saleCancellationService).saveCancellationResults(anyList());
    }

    @Test
    public void when_processing_an_asynchronous_cancellation_and_exception_is_throw_save_results_should_save_the_errors() throws BillingCancellationWarningException {
        //@Given
        UserDecorator userDecorator = mock(UserDecorator.class);
        CsvImportFile file = new CsvImportFile();
        FileImportInfo fileImportInfo = initFileImportInfo(ImportFileStatus.PROCESSED, FileImportOperation.CANCEL);

        ArrayList<SaleCancellationEntry> saleCancellationEntries = new ArrayList<SaleCancellationEntry>();
        Sale sale=new Sale();
        sale.setId(1L);

        SaleCancellationEntry saleCancellationEntry = new SaleCancellationEntry(sale, new Cancellation(), file);

        saleCancellationEntries.add(saleCancellationEntry);
        when(saleCancellationService.getSaleCancellationEntryByCsvImportFile(any(CsvImportFile.class))).thenReturn(saleCancellationEntries);
        when(userService.getItsUserByLogin(any(String.class))).thenReturn(userDecorator);
        when(multiplierSaleService.getSaleById(any(Long.class))).thenReturn(sale);
        BillingCancellationWarningException toBeThrown =mock(BillingCancellationWarningException.class);
        ConstraintViolation constraintViolation = mock(ConstraintViolation.class);
        when(constraintViolation.getInnerViolation()).thenReturn(constraintViolation);
        when(constraintViolation.resolveFieldMessage(any(ResourceBundle.class))).thenReturn("any text");
        when(constraintViolation.getField()).thenReturn("credit.due.date.both.dates.required");
        ArrayList<Integer> lines = new ArrayList<Integer>();
        lines.add(1);
        when(constraintViolation.getLine()).thenReturn(lines);
        ArrayList<ConstraintViolation> constraintViolations = new ArrayList<ConstraintViolation>();
        constraintViolations.add(constraintViolation);
        when(toBeThrown.getViolations()).thenReturn(constraintViolations);
        ArrayList<Object> places = new ArrayList<Object>();
        places.add("Place");
        when(constraintViolation.getPlaces()).thenReturn(places);


        toBeThrown.add(constraintViolation);
        doThrow(toBeThrown).when(multiplierSaleService).cancelMultipleSales(anyCollection(), anyList(), any(Cancellation.class), any(String.class));

        //@When
        saleCancellationCallback.doProceed(fileImportInfo);

        //@Should
        verify(saleCancellationService).saveCancellationResults(anyList());
    }

    private FileImportInfo initFileImportInfo(ImportFileStatus fileStatus, FileImportOperation importOperation) {
        UserDecorator userDecorator = mock(UserDecorator.class);
        FileImportDefinition fileImportDefinition = null;
        Locale locale = Locale.getDefault();
        String bundleName = "language";
        CsvImportFile csvImportFile = new CsvImportFile("fileName", "userLogin", ImportFileType.CSV_MULTIPLIER_SALE);
        csvImportFile.setId(1l);
        csvImportFile.setFileStatus(fileStatus);
        FileImportInfo fileImportInfo = new FileImportInfo(csvImportFile, userDecorator, fileImportDefinition, importOperation, locale, bundleName);
        when(csvImportFileService.selectById(csvImportFile.getId())).thenReturn(csvImportFile);
        return fileImportInfo;
    }
}
