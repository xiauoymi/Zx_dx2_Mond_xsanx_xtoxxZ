/**
 * 
 */
package com.monsanto.brazilvaluecapture.multiplier.volumereport.service.parser;

import com.monsanto.brazilvaluecapture.core.base.model.bean.Company;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Crop;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Document;
import com.monsanto.brazilvaluecapture.core.base.model.bean.OperationalYear;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Customer;
import com.monsanto.brazilvaluecapture.core.foundation.test.AbstractServiceIntegrationTests;
import com.monsanto.brazilvaluecapture.core.foundation.test.dbunit.DbUnitHelper;
import com.monsanto.brazilvaluecapture.core.foundation.util.CalendarUtil;
import com.monsanto.brazilvaluecapture.core.grower.model.bean.Grower;
import com.monsanto.brazilvaluecapture.core.io.ImportedException;
import com.monsanto.brazilvaluecapture.multiplier.cultivar.model.bean.Cultivar;
import com.monsanto.brazilvaluecapture.multiplier.harvestcalendar.model.bean.HarvestCalendar;
import com.monsanto.brazilvaluecapture.multiplier.itsclass.model.bean.ItsClass;
import com.monsanto.brazilvaluecapture.multiplier.obtainer.model.bean.Obtainer;
import com.monsanto.brazilvaluecapture.multiplier.volumereport.model.bean.DiscardPortioningCsvImportedLine;
import com.monsanto.brazilvaluecapture.multiplier.volumereport.model.bean.VolumeReportDetail;
import com.monsanto.brazilvaluecapture.multiplier.volumereport.model.bean.VolumeReportHeader;
import com.monsanto.brazilvaluecapture.multiplier.volumereport.model.bean.VolumeReportStatus;
import com.monsanto.brazilvaluecapture.seedsale.harvest.model.bean.Harvest;
import junit.framework.Assert;
import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * @author andregc
 *
 */
public class DiscardPortioningCsvParser_AT extends AbstractServiceIntegrationTests {
	
	@Autowired
	private DiscardPortioningCsvParser parser;
	
	private OperationalYear operationalYear;

	private Harvest harvest;

	private Company company;

	private Crop crop;

	private Customer customer;

	private Obtainer obtainer;

	private ItsClass itsClass;

	private Cultivar cultivar;
	
	private Grower cooperative;

	private VolumeReportDetail detail;

	private Customer matrix;

	
	@Before
	public void init() {
        DbUnitHelper.setup("classpath:data/multiplier/basic-fixture.xml",
        "classpath:data/multiplier/discard-portioning-dataset.xml");

        detail = (VolumeReportDetail) getSession().get(VolumeReportDetail.class, 900000005L);
        detail.getEnteredArea().setValue(BigDecimal.TEN);
        detail.setVolumeReportDetailPhase1Status(VolumeReportStatus.APPROVED);
        detail.getPortioning().setStatus(VolumeReportStatus.WAITING_REPORT);
        saveAndFlush(detail);
		harvest = detail.getVolumeReportHeader().getHarvest(); // 900000001L
        operationalYear = harvest.getOperationalYear();
        company = harvest.getCompany();
        crop = harvest.getCrop();
        matrix = detail.getVolumeReportHeader().getMatrix(); // 900000004L
		customer = detail.getVolumeReportHeader().getCustomer(); // 900000003L
		obtainer = detail.getVolumeReportHeader().getObtainer(); // 900000001L
		itsClass = detail.getItsClass(); // 900000001L
		cultivar = detail.getCultivar(); // 900000001L
		cultivar.setObtainerOnly(false);
		saveAndFlush(cultivar);
		cooperative = (Grower) getSession().get(Grower.class, 900000005L);
		
//		Date startDate = CalendarUtil.normalizeDateToStartOfDay(new Date());
//		Date endDate = CalendarUtil.normalizeDateToEndOfDay(new Date());
//		createAndPersistHarvestCalendarForDiscardPortioning(harvest, startDate, endDate);
	}
	
	@Test
	public void given_a_valid_file_when_parse_should_not_have_warnings() {
		createHarvestCalendarForCurrentDay();
		
		DiscardPortioningCsvImportedLine line = createValidLine();

		DiscardPortioningCsvImportedFile file = createFileFor(line);
		parser.proccessFile(file);
		
		Assert.assertEquals("Should not warnings", 0, file.countWarnings());
		Assert.assertEquals(operationalYear, line.getOperationalYear());
		Assert.assertEquals(harvest, line.getHarvest());
		Assert.assertEquals(customer, line.getCustomer());
		Assert.assertEquals(obtainer, line.getObtainer());
		Assert.assertEquals(itsClass, line.getItsClass());
		Assert.assertEquals(cultivar, line.getCultivar());
		Assert.assertEquals(cooperative, line.getGrower());
		Assert.assertEquals(detail, line.getVolumeReportDetail());
	}
	
	@Test
	public void given_a_line_without_cooperativeDiscard_when_parse_file_should_have_one_warning() {
		DiscardPortioningCsvImportedLine line = createValidLine();
		line.setCooperativeDiscard(null);

		DiscardPortioningCsvImportedFile file = createFileFor(line);		
		parser.proccessFile(file);

		assertOneWarningForMessage(DiscardPortioningCsvParser.ERROR_DISCARD_PORTIONING_IMPORT_COOPERATIVE_DISCARD_REQUIRED, file);
	}
	
	@Test
	public void given_a_line_without_operationalYearDescription_when_parse_file_should_have_one_warning() {
		DiscardPortioningCsvImportedLine line = createValidLine();
		line.setOperationalYearDescription(null);

		DiscardPortioningCsvImportedFile file = createFileFor(line);		
		parser.proccessFile(file);

		assertOneWarningForMessage(DiscardPortioningCsvParser.ERROR_DISCARD_PORTIONING_IMPORT_OPERATIONAL_YEAR_REQUIRED, file);
	}
	
	@Test
	public void given_a_line_without_harvestDescription_when_parse_file_should_have_one_warning() {
		DiscardPortioningCsvImportedLine line = createValidLine();
		line.setHarvestDescription(null);

		DiscardPortioningCsvImportedFile file = createFileFor(line);		
		parser.proccessFile(file);

		assertOneWarningForMessage(DiscardPortioningCsvParser.ERROR_DISCARD_PORTIONING_IMPORT_HARVEST_REQUIRED, file);
	}
	
	@Test
	public void given_a_line_without_customerDocumentType_when_parse_file_should_have_one_warning() {
		DiscardPortioningCsvImportedLine line = createValidLine();
		line.setCustomerDocumentTypeDescription(null);

		DiscardPortioningCsvImportedFile file = createFileFor(line);
		parser.proccessFile(file);

		assertOneWarningForMessage(DiscardPortioningCsvParser.ERROR_DISCARD_PORTIONING_IMPORT_CUSTOMER_DOCUMENT_TYPE_REQUIRED, file);
	}
	
	@Test
	public void given_a_line_without_customerDocument_when_parse_file_should_have_one_warning() {
		DiscardPortioningCsvImportedLine line = createValidLine();
		line.setCustomerDocument(null);

		DiscardPortioningCsvImportedFile file = createFileFor(line);		
		parser.proccessFile(file);

		assertOneWarningForMessage(DiscardPortioningCsvParser.ERROR_DISCARD_PORTIONING_IMPORT_CUSTOMER_DOCUMENT_REQUIRED, file);
	}
	
	@Test
	public void given_a_line_without_obtainerDescription_when_parse_file_should_have_one_warning() {
		DiscardPortioningCsvImportedLine line = createValidLine();
		line.setObtainerDescription(null);

		DiscardPortioningCsvImportedFile file = createFileFor(line);
		parser.proccessFile(file);

		assertOneWarningForMessage(DiscardPortioningCsvParser.ERROR_DISCARD_PORTIONING_IMPORT_OBTAINER_REQUIRED, file);
	}
	
	@Test
	public void given_a_line_without_classDescription_when_parse_file_should_have_one_warning() {
		DiscardPortioningCsvImportedLine line = createValidLine();
		line.setClassAbbreviation(null);

		DiscardPortioningCsvImportedFile file = createFileFor(line);
		parser.proccessFile(file);

		assertOneWarningForMessage(DiscardPortioningCsvParser.ERROR_DISCARD_PORTIONING_IMPORT_CLASS_REQUIRED, file);
	}
	
	@Test
	public void given_a_line_without_cultivarDescription_when_parse_file_should_have_one_warning() {
		DiscardPortioningCsvImportedLine line = createValidLine();
		line.setCultivarDescription(null);

		DiscardPortioningCsvImportedFile file = createFileFor(line);
		parser.proccessFile(file);

		assertOneWarningForMessage(DiscardPortioningCsvParser.ERROR_DISCARD_PORTIONING_IMPORT_CULTIVAR_REQUIRED, file);
	}
	
	@Test
	public void given_a_line_with_isCooperativeDiscard_N_and_without_cooperativeDocumentType_when_parse_file_should_not_have_warnings() {
		createHarvestCalendarForCurrentDay();
		DiscardPortioningCsvImportedLine line = createValidLine();
		line.setCooperativeDiscard("N");
		line.setCooperativeDocumentTypeDescription(null);

		DiscardPortioningCsvImportedFile file = createFileFor(line);
		parser.proccessFile(file);

		Assert.assertEquals("Should not have warnings", 0, file.countWarnings());
	}
	
	@Test
	public void given_a_line_with_isCooperativeDiscard_N_and_without_cooperativeDocument_when_parse_file_should_not_have_warnings() {
		createHarvestCalendarForCurrentDay();
		DiscardPortioningCsvImportedLine line = createValidLine();
		line.setCooperativeDiscard("N");
		line.setCooperativeDocument(null);

		DiscardPortioningCsvImportedFile file = createFileFor(line);
		parser.proccessFile(file);

		Assert.assertEquals("Should not have warnings", 0, file.countWarnings());
	}
	
	@Test
	public void given_a_line_with_isCooperativeDiscard_S_and_without_cooperativeDocumentType_when_parse_file_should_have_one_warning() {
		DiscardPortioningCsvImportedLine line = createValidLine();
		line.setCooperativeDiscard("S");
		line.setCooperativeDocumentTypeDescription(null);

		DiscardPortioningCsvImportedFile file = createFileFor(line);
		parser.proccessFile(file);

		assertOneWarningForMessage(DiscardPortioningCsvParser.ERROR_DISCARD_PORTIONING_IMPORT_COOPERATIVE_DOCUMENT_TYPE_REQUIRED, file);
	}
	
	@Test
	public void given_a_line_with_isCooperativeDiscard_S_and_without_cooperativeDocument_when_parse_file_should_have_one_warning() {
		DiscardPortioningCsvImportedLine line = createValidLine();
		line.setCooperativeDiscard("S");
		line.setCooperativeDocument(null);

		DiscardPortioningCsvImportedFile file = createFileFor(line);
		parser.proccessFile(file);

		assertOneWarningForMessage(DiscardPortioningCsvParser.ERROR_DISCARD_PORTIONING_IMPORT_COOPERATIVE_DOCUMENT_REQUIRED, file);
	}
	
	@Test
	public void given_one_cooperativeDiscard_diferent_of_S_and_N_should_have_one_warning() {
		DiscardPortioningCsvImportedLine line = createValidLine();
		line.setCooperativeDiscard("INVALID VALUE!!!");
		
		DiscardPortioningCsvImportedFile file = createFileFor(line);
		parser.proccessFile(file);
		
		assertOneWarningForMessage(DiscardPortioningCsvParser.ERROR_DISCARD_PORTIONING_IMPORT_COOPERATIVE_DISCARD_INVALID, file);
	}
	
	@Test
	public void given_a_line_without_area_when_parse_file_should_have_one_warning() {
		DiscardPortioningCsvImportedLine line = createValidLine();
		line.setArea(null);

		DiscardPortioningCsvImportedFile file = createFileFor(line);
		parser.proccessFile(file);

		assertOneWarningForMessage(DiscardPortioningCsvParser.ERROR_DISCARD_PORTIONING_IMPORT_AREA_REQUIRED, file);
	}
	
	@Test
	public void given_an_invalid_operational_year_when_parse_file_should_have_one_warning() {
		DiscardPortioningCsvImportedLine line = createValidLine();
		line.setOperationalYearDescription("INEXISTENT OPERATIONAL YEAR");

		DiscardPortioningCsvImportedFile file = createFileFor(line);
		parser.proccessFile(file);
		
		assertOneWarningForMessage(DiscardPortioningCsvParser.ERROR_DISCARD_PORTIONING_IMPORT_OPERATIONAL_YEAR_NOT_FOUND, file);
	}

	@Test
	public void given_an_invalid_harvest_description_when_parse_file_should_have_one_warning() {
		DiscardPortioningCsvImportedLine line = createValidLine();
		line.setHarvestDescription("INEXISTENT HARVEST");

		DiscardPortioningCsvImportedFile file = createFileFor(line);
		parser.proccessFile(file);

		assertOneWarningForMessage(DiscardPortioningCsvParser.ERROR_DISCARD_PORTIONING_IMPORT_HARVEST_NOT_FOUND, file);
	}

	@Test
	public void given_a_harvest_of_another_operationalYear_when_parse_file_should_have_one_warning() {
		DiscardPortioningCsvImportedLine line = createValidLine();
		
		OperationalYear operationalYear = (OperationalYear) getSession().get(OperationalYear.class, 900000002L);
		line.setOperationalYearDescription(operationalYear.getYear());
		
		DiscardPortioningCsvImportedFile file = createFileFor(line);
		parser.proccessFile(file);

		assertOneWarningForMessage(DiscardPortioningCsvParser.ERROR_DISCARD_PORTIONING_IMPORT_HARVEST_DOESNT_EXIST_FOR_OPERATIONAL_YEAR, file);
	}

	@Test
	public void given_an_invalid_customerDocumentType_when_parse_file_should_have_one_warning() {
		DiscardPortioningCsvImportedLine line = createValidLine();
		line.setCustomerDocumentTypeDescription("INVALID DOCUMENT TYPE");

		DiscardPortioningCsvImportedFile file = createFileFor(line);
		parser.proccessFile(file);

		assertOneWarningForMessage(DiscardPortioningCsvParser.ERROR_DISCARD_PORTIONING_IMPORT_CUSTOMER_DOCUMENT_TYPE_INVALID, file);
	}
	
	@Test
	public void given_an_invalid_document_when_parse_file_should_have_one_warning() {
		DiscardPortioningCsvImportedLine line = createValidLine();
		line.setCustomerDocument("INVALID DOCUMENT");

		DiscardPortioningCsvImportedFile file = createFileFor(line);
		parser.proccessFile(file);

		assertOneWarningForMessage(DiscardPortioningCsvParser.ERROR_DISCARD_PORTIONING_IMPORT_CUSTOMER_DOCUMENT_INVALID, file);
	}
	
	@Test
	public void given_an_duplicated_customer_without_sap_code_when_parse_file_should_have_one_warning() {
		DiscardPortioningCsvImportedLine line = createValidLine();
		line.setCustomerSAPCode(null);

		DiscardPortioningCsvImportedFile file = createFileFor(line);
		parser.proccessFile(file);

		assertOneWarningForMessage(DiscardPortioningCsvParser.ERROR_DISCARD_PORTIONING_IMPORT_CUSTOMER_DUPLICATED, file);
	}
	
	@Test
	public void given_a_valid_but_inexistent_customerDocument_when_parse_file_should_have_one_warning() {
		DiscardPortioningCsvImportedLine line = createValidLine();
		line.setCustomerDocument("11.490.357/0001-11");

		DiscardPortioningCsvImportedFile file = createFileFor(line);
		parser.proccessFile(file);

		assertOneWarningForMessage(DiscardPortioningCsvParser.ERROR_DISCARD_PORTIONING_IMPORT_CUSTOMER_NOT_FOUND, file);
	}
	
	@Test 
	public void given_an_invalid_obtainerDescription_when_parse_file_should_have_one_warning() {
		DiscardPortioningCsvImportedLine line = createValidLine();
		line.setObtainerDescription("INEXISTENT OBTAINER");

		DiscardPortioningCsvImportedFile file = createFileFor(line);
		parser.proccessFile(file);

		assertOneWarningForMessage(DiscardPortioningCsvParser.ERROR_DISCARD_PORTIONING_IMPORT_OBTAINER_NOT_FOUND, file);
	}
	
	@Test 
	public void given_an_invalid_classAbbreviation_when_parse_file_should_have_one_warning() {
		DiscardPortioningCsvImportedLine line = createValidLine();
		line.setClassAbbreviation("INVALID CLASS ABREVIATION");
		
		DiscardPortioningCsvImportedFile file = createFileFor(line);
		parser.proccessFile(file);

		assertOneWarningForMessage(DiscardPortioningCsvParser.ERROR_DISCARD_PORTIONING_IMPORT_CLASS_NOT_FOUND, file);
	}
	
	@Test 
	public void given_any_value_except_S_for_cooperativeDiscard_when_parse_file_should_not_have_warning_and_isCooperativeDiscard_should_be_false() {
		createHarvestCalendarForCurrentDay();
		
		DiscardPortioningCsvImportedLine line = createValidLine();
		line.setCooperativeDiscard("N");
		
		DiscardPortioningCsvImportedFile file = createFileFor(line);
		parser.proccessFile(file);

		Assert.assertFalse("Cooperative Discard should be false", line.isCooperativeDiscard());
		Assert.assertEquals("Should not have warning", 0, file.countWarnings());
	}
	
	@Test 
	public void given_S_for_cooperativeDiscard_when_parse_file_should_not_have_warning_and_isCooperativeDiscard_should_be_true() {
		createHarvestCalendarForCurrentDay();
		
		DiscardPortioningCsvImportedLine line = createValidLine();
		line.setCooperativeDiscard("S");
		
		DiscardPortioningCsvImportedFile file = createFileFor(line);
		parser.proccessFile(file);

		Assert.assertTrue("Cooperative Discard should be true", line.isCooperativeDiscard());
		Assert.assertEquals("Should not have warning", 0, file.countWarnings());
	}
	
	@Test 
	public void given_an_invalid_cultivar_description_when_parse_file_should_have_one_warning() {
		DiscardPortioningCsvImportedLine line = createValidLine();
		line.setCultivarDescription("INEXISTENT CULTIVAR DESCRIPTION");
		
		DiscardPortioningCsvImportedFile file = createFileFor(line);
		parser.proccessFile(file);

		assertOneWarningForMessage(DiscardPortioningCsvParser.ERROR_DISCARD_PORTIONING_IMPORT_CULTIVAR_NOT_FOUND, file);
	}
	
	@Test 
	public void given_a_valid_cultivar_of_another_obtainer_when_parse_file_should_have_one_warning() {
		DiscardPortioningCsvImportedLine line = createValidLine();
		Obtainer anotherObtainer = (Obtainer) getSession().get(Obtainer.class, 900000002L);
		line.setObtainerDescription(anotherObtainer.getDescription());
		
		DiscardPortioningCsvImportedFile file = createFileFor(line);
		parser.proccessFile(file);

		assertOneWarningForMessage(DiscardPortioningCsvParser.ERROR_DISCARD_PORTIONING_IMPORT_CULTIVAR_DOESNT_EXIST_FOR_OBTAINER, file);
	}
	
	@Test
	public void given_an_invalid_cooperativeDocumentType_and_S_for_cooperativeDiscard_when_parse_file_should_have_one_warning() {
		createHarvestCalendarForCurrentDay();
		
		DiscardPortioningCsvImportedLine line = createValidLine();
		line.setCooperativeDocumentTypeDescription("INVALID DOCUMENT TYPE");
		
		DiscardPortioningCsvImportedFile file = createFileFor(line);
		parser.proccessFile(file);
		assertOneWarningForMessage(DiscardPortioningCsvParser.ERROR_DISCARD_PORTIONING_IMPORT_COOPERATIVE_DOCUMENT_TYPE_INVALID, file);
	}
	
	@Test
	public void given_an_invalid_cooperativeDocument_and_S_for_cooperativeDiscard_when_parse_file_should_have_one_warning() {
		createHarvestCalendarForCurrentDay();
		
		DiscardPortioningCsvImportedLine line = createValidLine();
		line.setCooperativeDocument("INVALID DOCUMENT");
		
		DiscardPortioningCsvImportedFile file = createFileFor(line);
		parser.proccessFile(file);
		assertOneWarningForMessage(DiscardPortioningCsvParser.ERROR_DISCARD_PORTIONING_IMPORT_COOPERATIVE_DOCUMENT_INVALID, file);
	}
	
	@Test
	public void given_N_for_cooperativeDiscard_and_a_customer_without_grower_created_when_parse_file_should_have_one_warning() {
		createHarvestCalendarForCurrentDay();
		
		detail = (VolumeReportDetail) getSession().get(VolumeReportDetail.class, 900000006L);
        detail.getEnteredArea().setValue(BigDecimal.TEN);
        detail.setVolumeReportDetailPhase1Status(VolumeReportStatus.APPROVED);
        detail.getPortioning().setStatus(VolumeReportStatus.WAITING_REPORT);
        saveAndFlush(detail);

        Customer customer = detail.getVolumeReportHeader().getCustomer();
        matrix = detail.getVolumeReportHeader().getMatrix();
		
		DiscardPortioningCsvImportedLine line = createValidLine();
		line.setCustomerDocumentTypeDescription(customer.getDocument().getDocumentTypeDescription());
		line.setCustomerDocument(customer.getDocumentValue());
		line.setCooperativeDiscard("N");
		
		
		DiscardPortioningCsvImportedFile file = createFileFor(line);
		parser.proccessFile(file);
		assertOneWarningForMessage(DiscardPortioningCsvParser.ERROR_DISCARD_PORTIONING_IMPORT_CUSTOMER_WITHOUT_GROWER, file);
	}
	
	@Test
	public void given_N_for_cooperativeDiscard_and_a_customer_with_grower_when_parse_file_should_not_have_warnings() {
		createHarvestCalendarForCurrentDay();
		
		DiscardPortioningCsvImportedLine line = createValidLine();
		line.setCooperativeDiscard("N");
		
		DiscardPortioningCsvImportedFile file = createFileFor(line);
		parser.proccessFile(file);
		Assert.assertEquals("Should not warnings", 0, file.countWarnings());
		Assert.assertEquals(line.getCustomer().getDocumentValue(), line.getGrower().getDocumentValue());
	}
	
	@Test
	public void given_a_valid_but_inexistent_cooperativeDocument_when_parse_file_should_have_one_warning() {
		createHarvestCalendarForCurrentDay();
		
		DiscardPortioningCsvImportedLine line = createValidLine();
		line.setCooperativeDocument("11.490.357/0001-11");

		DiscardPortioningCsvImportedFile file = createFileFor(line);
		parser.proccessFile(file);

		assertOneWarningForMessage(DiscardPortioningCsvParser.ERROR_DISCARD_PORTIONING_IMPORT_COOPERATIVE_NOT_FOUND, file);
	}
	
	@Test
	public void given_a_line_without_detail_when_parse_file_should_have_one_warning() {
		DiscardPortioningCsvImportedLine line = createValidLine();
		Cultivar cultivar = (Cultivar) getSession().get(Cultivar.class, 900000002L);
		line.setCultivarDescription(cultivar.getDescription());
		
		DiscardPortioningCsvImportedFile file = createFileFor(line);
		parser.proccessFile(file);

		assertOneWarningForMessage(DiscardPortioningCsvParser.ERROR_DISCARD_PORTIONING_IMPORT_VOLUME_REPORT_NOT_FOUND, file);
	}
	
	@Test
	public void given_a_valid_line_but_phase2_discardPortioning_is_not_available_when_parse_file_should_have_one_warning() {
		Date startDate = CalendarUtil.normalizeDateToEndOfDay(new Date());
		Date endDate = CalendarUtil.normalizeDateToEndOfDay(new Date());
		createAndPersistHarvestCalendarForDiscardPortioning(harvest, startDate, endDate);
		
		DiscardPortioningCsvImportedLine line = createValidLine();
		
		DiscardPortioningCsvImportedFile file = createFileFor(line);
		parser.proccessFile(file);

		assertOneWarningForMessage(DiscardPortioningCsvParser.ERROR_DISCARD_PORTIONING_IMPORT_DISCARD_PORTIONING_NOT_AVAILABLE, file);
	}
	
	@Test
	public void given_an_area_negative_when_parse_file_should_have_one_warning() {
		createHarvestCalendarForCurrentDay();
		
		DiscardPortioningCsvImportedLine line = createValidLine();
		line.setArea(new BigDecimal("-1"));
		
		DiscardPortioningCsvImportedFile file = createFileFor(line);
		parser.proccessFile(file);

		assertOneWarningForMessage(DiscardPortioningCsvParser.ERROR_DISCARD_PORTIONING_IMPORT_AREA_INVALID, file);
	}

    @Test
    public void given_multiple_lines_for_single_detail_should_group_into_one_item_map() {
        VolumeReportDetail detail = (VolumeReportDetail)getSession().get(VolumeReportDetail.class,900000003L);
        Grower grower1 = (Grower)getSession().get(Grower.class, 900000001L);
        Grower grower2 = (Grower)getSession().get(Grower.class, 900000002L);
        Grower grower3 = (Grower)getSession().get(Grower.class, 900000003L);
        List<DiscardPortioningCsvImportedLine> lines = new ArrayList<DiscardPortioningCsvImportedLine>();
        lines.add(createImportedLineFromDetail(detail, grower1, BigDecimal.TEN, "S", 1));
        lines.add(createImportedLineFromDetail(detail, grower1, BigDecimal.TEN, "S", 2));
        lines.add(createImportedLineFromDetail(detail, grower2, BigDecimal.TEN, "S", 3));
        lines.add(createImportedLineFromDetail(detail, grower3, BigDecimal.TEN, "S", 4));
        lines.add(createImportedLineFromDetail(detail, grower3, BigDecimal.TEN, "S", 5));
        Map<DiscardPortioningByDetailIndexer,List<DiscardPortioningCsvImportedLine>> indexerSetMap = parser.groupLinesByDetail(lines);
        Assert.assertEquals("Should have 1 set", 1, indexerSetMap.size());
    }

	@Test
    public void given_multiple_lines_for_two_details_should_have_two_entries() {
        VolumeReportDetail detail = (VolumeReportDetail)getSession().get(VolumeReportDetail.class,900000003L);
        VolumeReportDetail detail2 = (VolumeReportDetail)getSession().get(VolumeReportDetail.class,900000004L);
        Grower grower1 = (Grower)getSession().get(Grower.class, 900000001L);
        Grower grower2 = (Grower)getSession().get(Grower.class, 900000002L);
        Grower grower3 = (Grower)getSession().get(Grower.class, 900000003L);
        List<DiscardPortioningCsvImportedLine> lines = new ArrayList<DiscardPortioningCsvImportedLine>();
        lines.add(createImportedLineFromDetail(detail, grower1, BigDecimal.TEN, "S", 1));
        lines.add(createImportedLineFromDetail(detail, grower1, BigDecimal.TEN, "S", 2));
        lines.add(createImportedLineFromDetail(detail2, grower2, BigDecimal.TEN, "S", 3));
        lines.add(createImportedLineFromDetail(detail, grower3, BigDecimal.TEN, "S", 4));
        lines.add(createImportedLineFromDetail(detail2, grower3, BigDecimal.TEN, "S", 5));
        Map<DiscardPortioningByDetailIndexer, List<DiscardPortioningCsvImportedLine>> indexerSetMap = parser.groupLinesByDetail(lines);
        Assert.assertEquals("Should have 1 set", 2, indexerSetMap.size());
    }

    @Test
    public void given_multiple_lines_for_two_details_should_group_same_grower() {
        VolumeReportDetail detail = (VolumeReportDetail)getSession().get(VolumeReportDetail.class,900000003L);
        detail.getEnteredArea().setValue(BigDecimal.valueOf(25L));
        VolumeReportDetail detail2 = (VolumeReportDetail)getSession().get(VolumeReportDetail.class,900000004L);
        detail2.getEnteredArea().setValue(BigDecimal.valueOf(25L));
        Grower grower1 = (Grower)getSession().get(Grower.class, 900000001L);
        Grower grower2 = (Grower)getSession().get(Grower.class, 900000002L);
        Grower grower3 = (Grower)getSession().get(Grower.class, 900000003L);
        List<DiscardPortioningCsvImportedLine> lines = new ArrayList<DiscardPortioningCsvImportedLine>();
        BigDecimal FIVE = BigDecimal.valueOf(5L);
        lines.add(createImportedLineFromDetail(detail, grower1, FIVE, "S", 1));
        lines.add(createImportedLineFromDetail(detail, grower1, FIVE, "S", 2));
        lines.add(createImportedLineFromDetail(detail2, grower2, FIVE, "S", 3));
        lines.add(createImportedLineFromDetail(detail, grower3, FIVE, "S", 4));
        lines.add(createImportedLineFromDetail(detail, grower3, FIVE, "S", 5));
        lines.add(createImportedLineFromDetail(detail2, grower3, FIVE, "S", 6));
        Map<DiscardPortioningByDetailIndexer, List<DiscardPortioningCsvImportedLine>> indexerSetMap = parser.groupLinesByDetail(lines);
        DiscardPortioningCsvImportedFile file = new DiscardPortioningCsvImportedFile();
        parser.validateMaxDiscardAreaAndJoinRepeatedLines(indexerSetMap, file);
        Assert.assertEquals(4, file.getValidLinesToImport().size());
        for (DiscardPortioningCsvImportedLine line : file.getValidLinesToImport()) {
            if(detail.equals(line.getVolumeReportDetail())) {
                if(line.getGrower().equals(grower1)) {
                    Assert.assertTrue("Should be equal to 10, was " + line.getArea(), line.getArea().compareTo(BigDecimal.valueOf(10L))==0);
                } else if(line.getGrower().equals(grower2)) {
                    Assert.assertTrue("Should be equal to 5 was " + line.getArea(), line.getArea().compareTo(BigDecimal.valueOf(5l))==0);
                } else {
                    Assert.assertTrue("Should be equal to 10 was " + line.getArea(), line.getArea().compareTo(BigDecimal.valueOf(10l))==0);
                }
            } else {
                if(line.getGrower().equals(grower1)) {
                    Assert.assertTrue("Should be equal to 5 was " + line.getArea(), line.getArea().compareTo(BigDecimal.valueOf(5l))==0);
                } else if(line.getGrower().equals(grower2)) {
                    Assert.assertTrue("Should be equal to 5 was " + line.getArea(), line.getArea().compareTo(BigDecimal.valueOf(5l))==0);
                } else {
                    Assert.assertTrue("Should be equal to 5 was " + line.getArea(), line.getArea().compareTo(BigDecimal.valueOf(5l))==0);
                }
            }
        }

    }

    @Test
    public void given_multiple_lines_for_two_details_with_more_area_than_line_should_discard_line_and_create_warning() {
        VolumeReportDetail detail = (VolumeReportDetail)getSession().get(VolumeReportDetail.class,900000003L);
        detail.getEnteredArea().setValue(BigDecimal.valueOf(25L));
        
        VolumeReportDetail detail2 = (VolumeReportDetail)getSession().get(VolumeReportDetail.class,900000004L);
        detail2.getEnteredArea().setValue(BigDecimal.valueOf(25L));
        
        Grower grower1 = (Grower)getSession().get(Grower.class, 900000001L);
        Grower grower2 = (Grower)getSession().get(Grower.class, 900000002L);
        Grower grower3 = (Grower)getSession().get(Grower.class, 900000003L);
        
        List<DiscardPortioningCsvImportedLine> lines = new ArrayList<DiscardPortioningCsvImportedLine>();
        lines.add(createImportedLineFromDetail(detail, grower1, BigDecimal.TEN, "S", 1));
        lines.add(createImportedLineFromDetail(detail, grower1, BigDecimal.TEN, "S", 2));
        lines.add(createImportedLineFromDetail(detail2, grower2, BigDecimal.TEN, "S", 3));
        lines.add(createImportedLineFromDetail(detail, grower3, BigDecimal.TEN, "S", 4));
        lines.add(createImportedLineFromDetail(detail, grower3, BigDecimal.TEN, "S", 5));
        lines.add(createImportedLineFromDetail(detail2, grower3, BigDecimal.TEN, "S", 6));
        
        Map<DiscardPortioningByDetailIndexer, List<DiscardPortioningCsvImportedLine>> indexerSetMap = parser.groupLinesByDetail(lines);
        DiscardPortioningCsvImportedFile file = new DiscardPortioningCsvImportedFile();
        parser.validateMaxDiscardAreaAndJoinRepeatedLines(indexerSetMap,file);
        
        Assert.assertEquals(2, file.getValidLinesToImport().size());
        for (DiscardPortioningCsvImportedLine line : file.getValidLinesToImport()) {
            Assert.assertEquals("Should be for detail2", detail2, line.getVolumeReportDetail());
        }
        Assert.assertEquals("Should have 4 errors", 4, file.getWarningList().size());

    }
	
	
	private void assertOneWarningForMessage(String warningMessage, DiscardPortioningCsvImportedFile file) {
		Assert.assertEquals("Should have one warning", 1, file.countWarnings());
		ImportedException businessException = (ImportedException) file.getWarningList().get(0);
		Assert.assertEquals("Should have only one message", 1, businessException.getErrorMessageKeys().size());
		Assert.assertEquals(warningMessage, businessException.getErrorMessageKeys().get(0));
	}

	private DiscardPortioningCsvImportedFile createFileFor(DiscardPortioningCsvImportedLine line) {
		DiscardPortioningCsvImportedFile file = new DiscardPortioningCsvImportedFile();
		List<DiscardPortioningCsvImportedLine> entities = new ArrayList<DiscardPortioningCsvImportedLine>();
		entities.add(line);
		file.setAllLines(entities);
		return file;
	}

	private DiscardPortioningCsvImportedLine createValidLine() {
		DiscardPortioningCsvImportedLine line = createImportedLine("S",
                " "+operationalYear.getYear(),
                " "+harvest.getDescription(),
                " "+customer.getDocument().getDocumentTypeDescription(),
                " "+customer.getDocumentValue(),
                " "+customer.getCustomerSAPCode(),
                " "+obtainer.getDescription(),
                " "+itsClass.getAbbreviation(),
                " "+cultivar.getDescription(),
                " "+cooperative.getDocument().getDocumentTypeDescription(),
                " "+cooperative.getDocumentValue(), BigDecimal.ONE, 1);
		
		line.setCropCode(crop.getId());
		line.setCompanyCode(company.getId());
		line.setMatrixCode(matrix.getId());
		
		return line;
	}

    private DiscardPortioningCsvImportedLine createImportedLineFromDetail(VolumeReportDetail detail, Grower grower, BigDecimal area, String cooperativeDiscard, int lineNumber) {
        VolumeReportHeader volumeReportHeader = detail.getVolumeReportHeader();
        Harvest harvest = volumeReportHeader.getHarvest();
        Customer customer = volumeReportHeader.getCustomer();
        Document document = customer.getDocument();
        DiscardPortioningCsvImportedLine importedLine = createImportedLine(cooperativeDiscard, harvest.getOperationalYear().getYear(),
                harvest.getDescription(), document.getDocumentType().getDescription(), document.getValue(), customer.getCustomerSAPCode(),
                volumeReportHeader.getObtainer().getDescription(), detail.getItsClass().getAbbreviation(),
                detail.getCultivar().getDescription(), grower.getDocument().getDocumentType().getDescription(),
                grower.getDocument().getValue(), area, lineNumber);
        importedLine.setGrower(grower);
        importedLine.setVolumeReportDetail(detail);
        importedLine.setCooperativeDiscard("S".equalsIgnoreCase(cooperativeDiscard));
        return importedLine;
    }

	private DiscardPortioningCsvImportedLine createImportedLine(String cooperativeDiscard, String operationalYearDescription, String harvestDescription, String customerDocumentType, String customerDocument, String customerSAPCode, String obtainerDescription, String classDescription, String cultivarDescription, String cooperativeDocumentType, String cooperativeDocument, BigDecimal area, int lineNumber) {
		DiscardPortioningCsvImportedLine line = new DiscardPortioningCsvImportedLine();
		line.setCooperativeDiscard(cooperativeDiscard);
		line.setOperationalYearDescription(operationalYearDescription);
		line.setHarvestDescription(harvestDescription);
		line.setCustomerDocumentTypeDescription(customerDocumentType);
		line.setCustomerDocument(customerDocument);
		line.setCustomerSAPCode(customerSAPCode);
		line.setObtainerDescription(obtainerDescription);
		line.setClassAbbreviation(classDescription);
		line.setCultivarDescription(cultivarDescription);
		line.setCooperativeDocumentTypeDescription(cooperativeDocumentType);
		line.setCooperativeDocument(cooperativeDocument);
		line.setArea(area);
		line.setLine(lineNumber);
		return line;
	}

	private void createHarvestCalendarForCurrentDay() {
		Date startDate = CalendarUtil.normalizeDateToStartOfDay(new Date());
		Date endDate = CalendarUtil.normalizeDateToEndOfDay(new Date());
		createAndPersistHarvestCalendarForDiscardPortioning(harvest, startDate, endDate);
	}
	
	private HarvestCalendar createAndPersistHarvestCalendarForDiscardPortioning(Harvest harvest, Date startDate, Date endDate) {
        HarvestCalendar harvestCalendar = new HarvestCalendar(harvest);
        harvestCalendar.setHarvestDiscardedAreaStart(startDate); // 7
        harvestCalendar.setHarvestDiscardedAreaEnd(endDate);

        saveAndFlush(harvestCalendar);
        return harvestCalendar;
    }
	
}
