package com.monsanto.brazilvaluecapture.multiplier.seedsale.model.dao.impl;

import com.google.common.collect.Lists;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Customer;
import com.monsanto.brazilvaluecapture.core.foundation.service.EntityNotFoundException;
import com.monsanto.brazilvaluecapture.core.grower.model.bean.Grower;
import com.monsanto.brazilvaluecapture.core.wsiconsole.dao.impl.BaseHibernateUnitTest;
import com.monsanto.brazilvaluecapture.multiplier.seedsale.model.dao.SaleLinkDetailDAO;
import com.monsanto.brazilvaluecapture.seedsale.billing.model.bean.PaymentStatus;
import com.monsanto.brazilvaluecapture.seedsale.harvest.model.bean.Harvest;
import com.monsanto.brazilvaluecapture.seedsale.harvest.model.bean.Plantability;
import com.monsanto.brazilvaluecapture.seedsale.product.model.bean.Product;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.Sale;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.SaleItem;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.SaleLinkDetail;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.SaleLinkDetailValue;
import com.monsanto.brazilvaluecapture.seedsale.template.model.bean.SaleTemplate;
import com.monsanto.brazilvaluecapture.utils.DateRange;
import com.monsanto.brazilvaluecapture.utils.DateUtils;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;

import java.math.BigDecimal;
import java.util.Collection;

import static org.fest.assertions.Assertions.assertThat;
import static org.fest.assertions.Fail.fail;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

public class SaleLinkDetailDAOImpl_UT extends BaseHibernateUnitTest {
    @Before
    public void setUp() {
        when(query.uniqueResult()).thenReturn(new SaleLinkDetail());
    }

    @Test
    public void testSaveRetrievesCurrentSession_WhenSavingSaleLinkDetail() throws Exception {
        SaleLinkDetailDAOImpl saleLinkDetailDAO = new SaleLinkDetailDAOImpl(sessionFactory);
        SaleLinkDetail saleLinkDetail = new SaleLinkDetail();

        saleLinkDetailDAO.save(saleLinkDetail);

        verify(sessionFactory).getCurrentSession();
    }

    @Test
    public void testSaveInvokesSaveOrUpdateMethodFromSession_WhenSavingSaleLinkDetail() throws Exception {
        SaleLinkDetailDAOImpl saleLinkDetailDAO = new SaleLinkDetailDAOImpl(sessionFactory);
        SaleLinkDetail saleLinkDetail = new SaleLinkDetail();

        saleLinkDetailDAO.save(saleLinkDetail);

        verify(session).saveOrUpdate(saleLinkDetail);
    }

    @Test
    public void testSaveReturnsSavedObject_WhenSavingSaleLinkDetail() throws Exception {
        SaleLinkDetailDAOImpl saleLinkDetailDAO = new SaleLinkDetailDAOImpl(sessionFactory);
        SaleLinkDetail saleLinkDetail = new SaleLinkDetail();

        final SaleLinkDetail savedSaleLinkDetail = saleLinkDetailDAO.save(saleLinkDetail);

        assertThat(savedSaleLinkDetail).isEqualTo(saleLinkDetail);
    }

    @Test
    public void testGetCorrespondingSaleLinkDetailCreatesQuery_WhenGettingSaleLinkDetail() throws EntityNotFoundException {
        SaleLinkDetailDAO saleLinkDetailDAO = new SaleLinkDetailDAOImpl(sessionFactory);
        SaleItem saleItem = createSaleItem();

        saleLinkDetailDAO.getCorrespondingSaleLinkDetail(saleItem);

        verify(session).createQuery(anyString());
    }

    private SaleItem createSaleItem() {
        SaleItem saleItem = new SaleItem();
        final SaleTemplate saleTemplate = new SaleTemplate();
        final Harvest harvest = new Harvest() {
            @Override
            public String getCompleteDescription() {
                return "Sample Harvest";
            }
        };
        saleTemplate.setHarvest(harvest);
        saleItem.setSaleTemplate(saleTemplate);
        saleItem.setProduct(new Product());
        saleItem.setSale(new Sale(new Customer(), new Grower()));
        saleItem.setLot("LOT");
        saleItem.setPlantabilityId(new Plantability());
        return saleItem;
    }

    @Test
    public void testGetCorrespondingSaleLinkDetailCreatesQueryWithSpecificString_WhenGettingSaleLinkDetail() throws EntityNotFoundException {
        SaleLinkDetailDAO saleLinkDetailDAO = new SaleLinkDetailDAOImpl(sessionFactory);
        SaleItem saleItem = createSaleItem();

        saleLinkDetailDAO.getCorrespondingSaleLinkDetail(saleItem);

        ArgumentCaptor<String> queryStringCaptor = ArgumentCaptor.forClass(String.class);
        verify(session).createQuery(queryStringCaptor.capture());
        String queryString = queryStringCaptor.getValue();
        final String expectedQueryString = "select sld from SaleLinkDetail sld " +
                "where sld.saleItem.saleTemplate.harvest = :dealerHarvest " +
                "and sld.product = :product " +
                "and sld.batchName = :batchName " +
                "and sld.plantability = :plantability " +
                "and sld.saleItem.billing.paymentStatus in (:paymentStatuses)" +
                "and sld.total > sld.consumed " +
                "and " +
                "( " +     //HeadOffice of Dealer in SaleLinkDetail
                "    (SELECT h.matrix FROM HeadOffice h WHERE h.id = (SELECT max(h1.id) FROM HeadOffice h1 WHERE h1.customer = sld.dealer and h1.type = :distributorType)) " +
                "    = " +   //HeadOffice of Dealer in Dealer SaleItem
                "    (SELECT h.matrix FROM HeadOffice h WHERE h.id = (SELECT max(h1.id) FROM HeadOffice h1 WHERE h1.customer = :dealer and h1.type = :distributorType)) " +
                ") " +
                "order by sld.saleItem.billing.dueDate asc, " +
                "case sld.saleItem.billing.paymentStatus  " +
                "    when 'FULLY_PAID' then 0 " +
                "    when 'BILLED' then 1 " +
                "    when 'NOT_PAID' then 2 " +
                "end asc, " +
                "sld.saleItem.billing.id asc";
        assertThat(queryString).isEqualTo(expectedQueryString);
    }

    @Test
    public void testGetCorrespondingSaleLinkDetailSetsHarvestParameterToQuery() throws EntityNotFoundException {
        SaleLinkDetailDAO saleLinkDetailDAO = new SaleLinkDetailDAOImpl(sessionFactory);
        SaleItem saleItem = createSaleItem();

        saleLinkDetailDAO.getCorrespondingSaleLinkDetail(saleItem);

        verify(query).setParameter("dealerHarvest", saleItem.getSaleTemplate().getHarvest());
    }

    @Test
    public void testGetCorrespondingSaleLinkDetailAddsDealerParameter_FromSale() throws EntityNotFoundException {
        SaleLinkDetailDAO saleLinkDetailDAO = new SaleLinkDetailDAOImpl(sessionFactory);
        SaleItem saleItem = createSaleItem();

        saleLinkDetailDAO.getCorrespondingSaleLinkDetail(saleItem);

        verify(query).setParameter("dealer", saleItem.getSale().getCustomer());
    }

    @Test
    public void testGetCorrespondingSaleLinkDetailAddsProductParameter_FromSaleItem() throws EntityNotFoundException {
        SaleLinkDetailDAO saleLinkDetailDAO = new SaleLinkDetailDAOImpl(sessionFactory);
        SaleItem saleItem = createSaleItem();

        saleLinkDetailDAO.getCorrespondingSaleLinkDetail(saleItem);

        verify(query).setParameter("product", saleItem.getProduct());
    }

    @Test
    public void testGetCorrespondingSaleLinkDetailAddsBatchNameParameter_FromSaleItem() throws EntityNotFoundException {
        SaleLinkDetailDAO saleLinkDetailDAO = new SaleLinkDetailDAOImpl(sessionFactory);
        SaleItem saleItem = createSaleItem();

        saleLinkDetailDAO.getCorrespondingSaleLinkDetail(saleItem);

        verify(query).setParameter("batchName", saleItem.getLot());
    }

    @Test
    public void testGetCorrespondingSaleLinkDetailAddsPlantabilityParameter_FromSaleItem() throws EntityNotFoundException {
        SaleLinkDetailDAO saleLinkDetailDAO = new SaleLinkDetailDAOImpl(sessionFactory);
        SaleItem saleItem = createSaleItem();

        saleLinkDetailDAO.getCorrespondingSaleLinkDetail(saleItem);

        verify(query).setParameter("plantability", saleItem.getPlantabilityId());
    }

    @Test
    public void testGetCorrespondingSaleLinkDetailAddsListOfPaymentStatusParameter_FromSale() throws EntityNotFoundException {
        SaleLinkDetailDAO saleLinkDetailDAO = new SaleLinkDetailDAOImpl(sessionFactory);
        SaleItem saleItem = createSaleItem();

        saleLinkDetailDAO.getCorrespondingSaleLinkDetail(saleItem);

        Collection expectedPaymentStatusList = Lists.newArrayList(PaymentStatus.FULLY_PAID, PaymentStatus.BILLED, PaymentStatus.NOT_PAID);
        verify(query).setParameterList("paymentStatuses", expectedPaymentStatusList);
    }

    @Test
    public void testGetCorrespondingSaleLinkDetailThrowsEntityNotFoundException_WhenNoSaleLinkDetailIsFound() {
        SaleLinkDetailDAO saleLinkDetailDAO = new SaleLinkDetailDAOImpl(sessionFactory);
        SaleItem saleItem = createSaleItem();
        when(query.uniqueResult()).thenReturn(null);

        try {
            saleLinkDetailDAO.getCorrespondingSaleLinkDetail(saleItem);
            fail("should throw EntityNotFoundException");
        } catch (EntityNotFoundException e) {
            assertThat(e).hasNoCause().hasMessage("No SaleLinkDetail was found for saleItem " + saleItem.getId());
        }
    }

    @Test
    public void testGetNotLinkedSaleItemsForSale() {
        //@Given
        Sale sale = new Sale();
        SaleLinkDetailDAO saleLinkDetailDAO = new SaleLinkDetailDAOImpl(sessionFactory);
        String queryStr = "SELECT sale_item FROM SaleItem as sale_item WHERE sale_item.sale = :sale AND sale_item NOT IN ( " +
                "SELECT sldv.dealerSaleItem FROM SaleLinkDetailValue as sldv )";
        //@When
        saleLinkDetailDAO.getNotLinkedSaleItemsForSale(sale);
        //@Then
        verify(session).createQuery(queryStr);
        verify(query).setParameter("sale", sale);
        verify(query).list();
    }

    @Test
    public void testFindLinkedSalesByPaymentStatusAndPaydPeriodUsesTheCorrectQuery() {
        SaleLinkDetailDAO saleLinkDetailDAO = new SaleLinkDetailDAOImpl(sessionFactory);

        saleLinkDetailDAO.findLinkedSalesByPaymentStatusAndPayedInPeriod(PaymentStatus.BILLED, DateUtils.getLastMonthDateRange());

        String queryString = new StringBuilder()
                .append("SELECT distinct sld FROM SaleLinkDetail sld ")
                .append("WHERE")
                .append("   sld.saleItem.billing.paymentStatus = :paymentStatus and")
                .append("   sld.saleItem.revenueAccount.paymentDate between :startDate and :endDate").toString();
        assertQueryStringIsSameAs(queryString);
    }

    @Test
    public void testFindLinkedSalesByPaymentStatusAndPaydPeriodAddsParameterPaymentStatus() {
        SaleLinkDetailDAO saleLinkDetailDAO = new SaleLinkDetailDAOImpl(sessionFactory);
        final PaymentStatus expectedPaymentStatus = PaymentStatus.BILLED;

        saleLinkDetailDAO.findLinkedSalesByPaymentStatusAndPayedInPeriod(expectedPaymentStatus, DateUtils.getLastMonthDateRange());

        verify(query).setParameter("paymentStatus", expectedPaymentStatus);
    }

    @Test
    public void testFindLinkedSalesByPaymentStatusAndPaydPeriodAddsParameterStartDate() {
        SaleLinkDetailDAO saleLinkDetailDAO = new SaleLinkDetailDAOImpl(sessionFactory);
        final DateRange lastMonthDateRange = DateUtils.getLastMonthDateRange();

        saleLinkDetailDAO.findLinkedSalesByPaymentStatusAndPayedInPeriod(PaymentStatus.BILLED, lastMonthDateRange);

        verify(query).setParameter("startDate", lastMonthDateRange.getDateFrom());
    }

    @Test
    public void testFindLinkedSalesByPaymentStatusAndPaydPeriodAddsParameterEndDate() {
        SaleLinkDetailDAO saleLinkDetailDAO = new SaleLinkDetailDAOImpl(sessionFactory);
        final DateRange lastMonthDateRange = DateUtils.getLastMonthDateRange();

        saleLinkDetailDAO.findLinkedSalesByPaymentStatusAndPayedInPeriod(PaymentStatus.BILLED, lastMonthDateRange);

        verify(query).setParameter("endDate", lastMonthDateRange.getDateTo());
    }

    @Test
    public void testFindLinkedSalesByPaymentStatusAndCreatedPeriodUsesTheCorrectQuery() {
        SaleLinkDetailDAO saleLinkDetailDAO = new SaleLinkDetailDAOImpl(sessionFactory);

        saleLinkDetailDAO.findLinkedSalesByPaymentStatusAndCreatedInPeriod(PaymentStatus.BILLED, DateUtils.getLastMonthDateRange());

        String queryString = new StringBuilder()
                .append("SELECT distinct sld FROM SaleLinkDetail sld ")
                .append("JOIN sld.saleLinkDetailValueSet sldv ")
                .append("WHERE")
                .append("   sld.consumed > 0 and")
                .append("   sld.saleItem.billing.paymentStatus = :paymentStatus and")
                .append("   sldv.dealerSaleItem.postingStatus = :notPosted and")
                .append("   sldv.dealerSale.creationDate between :startDate and :endDate").toString();
        assertQueryStringIsSameAs(queryString);
    }

    @Test
    public void testFindLinkedSalesByPaymentStatusAndCreatedPeriodAddsParameterPaymentStatus() {
        SaleLinkDetailDAO saleLinkDetailDAO = new SaleLinkDetailDAOImpl(sessionFactory);
        final PaymentStatus expectedPaymentStatus = PaymentStatus.BILLED;

        saleLinkDetailDAO.findLinkedSalesByPaymentStatusAndCreatedInPeriod(expectedPaymentStatus, DateUtils.getLastMonthDateRange());

        verify(query).setParameter("paymentStatus", expectedPaymentStatus);
    }

    @Test
    public void testFindLinkedSalesByPaymentStatusAndCreatedPeriodAddsParameterStartDate() {
        SaleLinkDetailDAO saleLinkDetailDAO = new SaleLinkDetailDAOImpl(sessionFactory);
        final DateRange lastMonthDateRange = DateUtils.getLastMonthDateRange();

        saleLinkDetailDAO.findLinkedSalesByPaymentStatusAndCreatedInPeriod(PaymentStatus.BILLED, lastMonthDateRange);

        verify(query).setParameter("startDate", lastMonthDateRange.getDateFrom());
    }

    @Test
    public void testFindLinkedSalesByPaymentStatusAndCreatedPeriodAddsParameterEndDate() {
        SaleLinkDetailDAO saleLinkDetailDAO = new SaleLinkDetailDAOImpl(sessionFactory);
        final DateRange lastMonthDateRange = DateUtils.getLastMonthDateRange();

        saleLinkDetailDAO.findLinkedSalesByPaymentStatusAndCreatedInPeriod(PaymentStatus.BILLED, lastMonthDateRange);

        verify(query).setParameter("endDate", lastMonthDateRange.getDateTo());
    }

    @Test
    public void testDeleteSaleLinkDetailValueDeletesTheObjectFromSession() {
        final SaleLinkDetailValue saleLinkDetailValue = new SaleLinkDetailValue();
        SaleLinkDetailDAO saleLinkDetailDAO = new SaleLinkDetailDAOImpl(sessionFactory);

        saleLinkDetailDAO.deleteSaleLinkDetailValue(saleLinkDetailValue);

        verify(session).delete(saleLinkDetailValue);
    }

    @Test
    public void testDeleteSaleLinkDetailDeletesTheObjectFromSession() {
        final SaleLinkDetail saleLinkDetail = new SaleLinkDetail();
        SaleLinkDetailDAO saleLinkDetailDAO = new SaleLinkDetailDAOImpl(sessionFactory);

        saleLinkDetailDAO.deleteSaleLinkDetail(saleLinkDetail);

        verify(session).delete(saleLinkDetail);
    }

    @Test
    public void testGetTotalRecognizedFromSaleLinkDetailValueOf() {
        //@Given
        final SaleItem saleItem = new SaleItem();
        saleItem.setId(1L);
        SaleLinkDetailDAO saleLinkDetailDAO = new SaleLinkDetailDAOImpl(sessionFactory);
        when(session.createQuery("select sum(sldv.revenueRecognition) from SaleLinkDetailValue sldv where sldv.revenueRecognition is not null and sldv.dealerSaleItem = :saleItem")).thenReturn(query);
        when(query.uniqueResult()).thenReturn(BigDecimal.valueOf(1));
        //@When
        saleLinkDetailDAO.getTotalRecognizedFromSaleLinkDetailValueOf(saleItem);
        //@Then
        verify(session).createQuery("select sum(sldv.revenueRecognition) from SaleLinkDetailValue sldv where sldv.revenueRecognition is not null and sldv.dealerSaleItem = :saleItem");
        verify(query).setParameter("saleItem", saleItem);
    }

    @Test
    public void testGetSaleLinkDetailValuesAssociatedWith() {
        //@Given
        final SaleItem saleItem = new SaleItem();
        saleItem.setId(1L);
        SaleLinkDetailDAO saleLinkDetailDAO = new SaleLinkDetailDAOImpl(sessionFactory);
        //@When
        saleLinkDetailDAO.getSaleLinkDetailValuesAssociatedWith(saleItem);
        //@Then
        String queryString = "" +
                "select sldv " +
                "from SaleLinkDetailValue sldv " +
                "where sldv.dealerSaleItem = :saleItem " +
                "and sldv.revenueRecognition is not null ";
        verify(session).createQuery(queryString);
        verify(query).setParameter("saleItem", saleItem);
    }

}