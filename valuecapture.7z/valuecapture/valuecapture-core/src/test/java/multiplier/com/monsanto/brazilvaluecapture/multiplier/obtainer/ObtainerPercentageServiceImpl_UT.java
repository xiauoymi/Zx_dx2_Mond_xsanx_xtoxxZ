package com.monsanto.brazilvaluecapture.multiplier.obtainer;

import com.monsanto.brazilvaluecapture.core.foundation.model.bean.StatusEnum;
import com.monsanto.brazilvaluecapture.core.foundation.service.BusinessException;
import com.monsanto.brazilvaluecapture.multiplier.obtainer.model.bean.Obtainer;
import com.monsanto.brazilvaluecapture.multiplier.obtainer.model.bean.ObtainerPercentage;
import com.monsanto.brazilvaluecapture.multiplier.obtainer.model.dao.ObtainerPercentageDAO;
import com.monsanto.brazilvaluecapture.multiplier.obtainer.model.dao.ObtainerPercentageFilter;
import com.monsanto.brazilvaluecapture.multiplier.obtainer.service.ObtainerPercentageService;
import com.monsanto.brazilvaluecapture.multiplier.obtainer.service.impl.ObtainerPercentageServiceImpl;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.fail;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/**
 * Created by IntelliJ IDEA.
 * User: sgovi
 * Date: 8/26/2014
 * Time: 2:33 PM
 */
@RunWith(MockitoJUnitRunner.class)
public class ObtainerPercentageServiceImpl_UT {

    @Mock
    private ObtainerPercentageDAO mockObtainerPercentageDAO;

    @InjectMocks
    private ObtainerPercentageService obtainerPercentageService = new ObtainerPercentageServiceImpl();

    @Before
    public void setUp() throws Exception {
        MockitoAnnotations.initMocks(obtainerPercentageService);

    }

    private List<ObtainerPercentage> buildObtainerPercentage() {
        List<ObtainerPercentage> obtainerPercentageList = new ArrayList<ObtainerPercentage>();
        ObtainerPercentage obtainerPercentage = ObtainerPercentageTestData.createActiveObtainerPercentage(new Obtainer());
        obtainerPercentage.setTransactionType("TRANSACTION_TYPE");
        obtainerPercentage.setTransTypeStatus(StatusEnum.ACTIVE);
        obtainerPercentageList.add(obtainerPercentage);
        return obtainerPercentageList;
    }

    @Test(expected = IllegalArgumentException.class)
    public void testSaveMethod_When_ObtainerPercentageList_isNull_ByUser() throws BusinessException {
        obtainerPercentageService.save(null);
    }

    @Test
    public void testSaveMethod_When_ObtainerPercentageList_isNotNull_ByUser() throws BusinessException {

        List<ObtainerPercentage> obtainerPercentageList = buildObtainerPercentage();
        obtainerPercentageService.save(obtainerPercentageList);
        verify(mockObtainerPercentageDAO).saveObtainerPercentage(obtainerPercentageList.get(0));

    }

    @Test(expected = IllegalArgumentException.class)
    public void testUpdateMethod_When_ObtainerPercentageList_isNull_ByUser() throws BusinessException {
        obtainerPercentageService.save(null);
    }

    @Test
    public void testUpdateMethod_When_ObtainerPercentageList_isNotNull_ByUser() throws BusinessException {

        List<ObtainerPercentage> obtainerPercentageList = buildObtainerPercentage();
        obtainerPercentageService.update(obtainerPercentageList);
        verify(mockObtainerPercentageDAO).updateObtainerPercentage(obtainerPercentageList.get(0));

    }

    @Test(expected = IllegalArgumentException.class)
    public void testSelectObtainerPercentageByMethod_when_obtainerFilter_isNull() {
        obtainerPercentageService.selectObtainerPercentageBy(null);
    }

    @Test
    public void testSelectObtainerPercentageByMethod_when_obtainerFilter_isNotNull() {
        ObtainerPercentageFilter obtainerPercentageFilter = ObtainerPercentageFilter.getInstance().addUser("TESTUSER").addPercentageTransactionStatus(StatusEnum.ACTIVE);
        when(mockObtainerPercentageDAO.selectObtainerPercentageBy(obtainerPercentageFilter)).thenReturn(new ArrayList<ObtainerPercentage>());
        obtainerPercentageService.selectObtainerPercentageBy(obtainerPercentageFilter);
        verify(mockObtainerPercentageDAO).selectObtainerPercentageBy(obtainerPercentageFilter);

    }

    @Test
    public void testGetActiveObtainerPercentagesFor_whenObtainerIsNull_thenIllegalArgumentExceptionMustBeThrown() {
        //@When
        try {
            obtainerPercentageService.getActiveObtainerPercentagesFor(null);
            fail("IllegalArgumentExceptionMustBeThrown");
        } catch (IllegalArgumentException e) {
            //@Then
            assertNotNull(e);
        }
    }

    @Test
    public void testGetActiveObtainerPercentagesFor_whenObtainerIsNotNull_thenDAOMustBeInvoked() {
        //@Given
        Obtainer obtainer = new Obtainer();
        when(mockObtainerPercentageDAO.getActiveObtainerPercentagesFor(obtainer)).thenReturn(new ArrayList<ObtainerPercentage>());
        //@When
        obtainerPercentageService.getActiveObtainerPercentagesFor(obtainer);
        //@Then
        verify(mockObtainerPercentageDAO).getActiveObtainerPercentagesFor(obtainer);

    }

}
