package com.monsanto.brazilvaluecapture.core.io;

import com.monsanto.brazilvaluecapture.core.foundation.service.BusinessException;
import com.monsanto.brazilvaluecapture.core.foundation.util.csv.CSVColumnPosition;
import com.monsanto.brazilvaluecapture.core.foundation.util.csv.CSVHeader;
import com.monsanto.brazilvaluecapture.core.regionalization.VCCountry;
import org.junit.Before;
import org.junit.Test;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.util.Collection;
import java.util.Locale;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

/**
 * Created by IntelliJ IDEA.
 * User: CGLLLO
 * Date: 12/12/13
 * Time: 11:34
 */
public class ImportedFileCSVReader_UT {

    public static final Locale LOCALE = VCCountry.BRAZIL.getLocale();

    @Before
    public void setUp() throws Exception {

    }

    private String createFileContent(Long[] someLongs, String[] someStrings, String delimiter) {
        final StringBuilder fileContentBuilder = new StringBuilder("headerString;headerLong\n");
        final int count = someLongs.length > someStrings.length ? someLongs.length : someStrings.length;
        for (int i=0; i<count; i++) {
            try{
                fileContentBuilder.append(someStrings[i]);
            } catch (ArrayIndexOutOfBoundsException e) {}
            fileContentBuilder.append(delimiter);
            try {
                fileContentBuilder.append(someLongs[i]);
            } catch (ArrayIndexOutOfBoundsException e) {}
            fileContentBuilder.append("\n");
        }
        return fileContentBuilder.toString();
    }

    private String createFileContent(Long[] saleIds, String[] documents) {
        return createFileContent(saleIds, documents, ";");
    }

    @Test
    public void testReadFile_Given_good_content_file() throws Exception {
        // @Given
        ImportedFileCSVReader<SomeImportedLineCSVReadable> importedFileCSVReader = new ImportedFileCSVReader<SomeImportedLineCSVReadable>(SomeImportedLineCSVReadable.class);

        final String[] someStrings = new String[] { "someString", "otherString", "anotherString" };
        final Long[] someLongs = new Long[] { 23L, 45L, 4L };

        InputStream inputStream = new ByteArrayInputStream(createFileContent(someLongs, someStrings).getBytes());

        // @When
        Collection<SomeImportedLineCSVReadable> result = importedFileCSVReader.readFile(inputStream, LOCALE).getAllLines();

        // @Then
        assertEquals(someStrings.length, result.size());
        int i=0;
        for (SomeImportedLineCSVReadable importedLine:result) {
            assertEquals(new Integer(2 + i), importedLine.getLine());
            assertEquals(someStrings[i], importedLine.getSomeString());
            assertEquals(someLongs[i], new Long(importedLine.getSomeLong()));
            i++;
        }
    }

    @Test
    public void testReadFile_When_bad_separator() throws Exception {
        ImportedFileCSVReader<SomeImportedLineCSVReadable> importedFileCSVReader = new ImportedFileCSVReader<SomeImportedLineCSVReadable>(SomeImportedLineCSVReadable.class);

        final String[] someStrings = new String[] { "someString1", "someString2", "someString3" };
        final Long[] someLongs = new Long[] { 23L, 45L, 4L };

        String delimiter = ",";
        String fileContent = createFileContent(someLongs, someStrings, delimiter).replace(someStrings[someStrings.length-1] + delimiter, someStrings[someStrings.length-1] + ";");
        InputStream inputStream = new ByteArrayInputStream(fileContent.getBytes());

        // @When
        Collection<BusinessException> result = importedFileCSVReader.readFile(inputStream, LOCALE).getWarningList();

        // @Then
        assertEquals(someStrings.length-1, result.size());
        int i=0;
        for (BusinessException e:result) {
            WarningImportedException warningImportedException = (WarningImportedException) e;
            assertEquals(new Integer(2 + i), warningImportedException.getLineNumber());
            assertEquals("import.result.error.layout.invalid", warningImportedException.getErrorMessageKeys().get(0));
            i++;
        }
    }

    @CSVHeader(columns={
            @CSVColumnPosition(headerName="headerString", position="0"),
            @CSVColumnPosition(headerName="headerLong", position="1")
    })
    class NotInstantiableImportedLineCSVReadable extends ImportedLineCSVReadable {}

    @Test
    public void testReadFile_When_not_instantiable_class() throws Exception {
        ImportedFileCSVReader<NotInstantiableImportedLineCSVReadable> importedFileCSVReader = new ImportedFileCSVReader<NotInstantiableImportedLineCSVReadable>(NotInstantiableImportedLineCSVReadable.class);

        final String[] someStrings = new String[] { "someString", "otherString", "anotherString" };
        final Long[] someLongs = new Long[] { 23L, 45L, 4L };

        InputStream inputStream = new ByteArrayInputStream(createFileContent(someLongs, someStrings).getBytes());

        // @When
        try {
            importedFileCSVReader.readFile(inputStream, LOCALE);
            // @Then
            fail("BusinessException should be throw");
        } catch (BusinessException e) {}
    }

    @Test
    public void  testReadFile_When_too_long_field() throws Exception {
        ImportedFileCSVReader<TooLongFieldImportedLineCSVReadable> importedFileCSVReader = new ImportedFileCSVReader<TooLongFieldImportedLineCSVReadable>(TooLongFieldImportedLineCSVReadable.class);

        final String[] someStrings = new String[] { "someString", "otherString", "anotherString" };
        final Long[] someLongs = new Long[] { 23L, 45L, 4L };

        InputStream inputStream = new ByteArrayInputStream(createFileContent(someLongs, someStrings).getBytes());

        // @When
        Collection<BusinessException> result = importedFileCSVReader.readFile(inputStream, LOCALE).getWarningList();

        // @Then
        assertEquals(someStrings.length, result.size());
        int i=0;
        for (BusinessException e:result) {
            WarningImportedException warningImportedException = (WarningImportedException) e;
            assertEquals(new Integer(2 + i), warningImportedException.getLineNumber());
            assertEquals("import.result.error.field.too.large.name", warningImportedException.getErrorMessageKeys().get(0));
            i++;
        }
    }
}
