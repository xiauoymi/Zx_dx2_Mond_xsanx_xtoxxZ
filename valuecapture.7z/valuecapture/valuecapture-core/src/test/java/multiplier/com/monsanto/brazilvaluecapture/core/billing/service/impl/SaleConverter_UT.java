package com.monsanto.brazilvaluecapture.core.billing.service.impl;

import com.monsanto.brazilvaluecapture.core.base.service.BaseService;
import com.monsanto.brazilvaluecapture.core.base.service.impl.BaseServiceImpl;
import com.monsanto.brazilvaluecapture.core.customer.model.dao.CustomerDAO;
import com.monsanto.brazilvaluecapture.core.customer.model.dao.HeadOfficeDAO;
import com.monsanto.brazilvaluecapture.core.customer.service.CustomerService;
import com.monsanto.brazilvaluecapture.core.customer.service.impl.CustomerServiceImpl;
import com.monsanto.brazilvaluecapture.core.grower.model.bean.Grower;
import com.monsanto.brazilvaluecapture.core.grower.model.dao.GrowerDAO;
import com.monsanto.brazilvaluecapture.core.regionalization.CountriesHolder;
import com.monsanto.brazilvaluecapture.core.regionalization.VCCountry;
import com.monsanto.brazilvaluecapture.seedsale.product.model.bean.Product;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.Sale;
import com.monsanto.brazilvaluecapture.seedsale.sale.service.SaleOrderImportService;
import com.monsanto.brazilvaluecapture.seedsale.sale.service.impl.SaleOrderImportServiceImpl;
import com.monsanto.brazilvaluecapture.seedsale.sale.service.impl.SaleServiceImpl;
import com.monsanto.brazilvaluecapture.seedsale.template.model.bean.DueDateValue;
import com.monsanto.brazilvaluecapture.seedsale.template.model.bean.Price;
import com.monsanto.brazilvaluecapture.seedsale.template.model.bean.SaleTemplate;
import com.monsanto.brazilvaluecapture.seedsale.template.model.dao.SaleTemplateDAO;
import junit.framework.TestCase;
import org.junit.Before;
import org.junit.Test;

import java.util.Date;
import java.util.Iterator;
import java.util.Set;

import static org.fest.reflect.core.Reflection.field;
import static org.mockito.Mockito.*;

/**
 * Created by IntelliJ IDEA.
 * User: AVIER
 * Date: 7/8/13
 * Time: 11:02 AM
 * To change this template use File | Settings | File Templates.
 */
public class SaleConverter_UT extends TestCase {
    private CsvSaleOrderToCash saleMock;
    private SaleConverter converter;
    private SaleServiceImpl saleService;
    private BaseService baseService;
    private CustomerService customerService;
    private CountriesHolder countryHolder;
    private GrowerDAO growerDAO;
    private CustomerDAO customerDAO;
    private SaleTemplateDAO saleTemplateDAO;
    private SaleOrderImportService saleOrderImportService;
    private HeadOfficeDAO headOfficeDAO;

    @Before
    public void setUp() {
        this.saleOrderImportService=mock(SaleOrderImportServiceImpl.class);
        converter = new SaleConverter(saleOrderImportService);
        this.saleService = mock(SaleServiceImpl.class);
        this.baseService=new BaseServiceImpl();
        headOfficeDAO = mock(HeadOfficeDAO.class);
        this.customerService=new CustomerServiceImpl(headOfficeDAO);
        this.countryHolder=mock(CountriesHolder.class);
        this.growerDAO=mock(GrowerDAO.class);
        this.customerDAO=mock(CustomerDAO.class);
        this.saleTemplateDAO=mock(SaleTemplateDAO.class);
        field("growerDAO").ofType(GrowerDAO.class).in(this.baseService).set(this.growerDAO);
        field("customerDAO").ofType(CustomerDAO.class).in(this.customerService).set(this.customerDAO);
        field("saleTemplateDAO").ofType(SaleTemplateDAO.class).in(this.saleService).set(this.saleTemplateDAO);


    }
   /* Fecha del Pedido;Nro de Factura;ID SAP del Comercio;ID SAP del Productor;Cantidad de Toneladas;Total ARS;Total USD;Fecha de Pago;Nro NVLP
     * 18.04.2013;100108806;1008081;0001099737;100.000;184852.50;36750.00;;*/
/*18.04.2013;100108806;1008081;0001099737;100.000;184852.50;36750.00;;*/
     @Test
    public void testWhenconvertSaleShouldNotRaiseViolations() {
        createCsvSaleMock("18.04.2013","100108806","1008080","0001099737","100.000","184852.50","36750.00");
        when(baseService.selectGrowerByCustomerSapId("0001099737")).thenReturn(mock(Grower.class));
        when(saleOrderImportService.validateSaleOrder(mock(Grower.class))).thenReturn(null);
        converter.convert(saleMock);
        assertFalse(converter.hasViolations());
        verifyCsvBillingMock();
    }


    private void verifyCsvBillingMock() {
        verify(saleMock, atLeastOnce()).getSaleDate();
        verify(saleMock, atLeastOnce()).getInvoiceNumber();
        verify(saleMock, atLeastOnce()).getHeadOfficeDocument();
        verify(saleMock, atLeastOnce()).getGrowerDocument();
        verify(saleMock, atLeastOnce()).getTonsQty();
        verify(saleMock, atLeastOnce()).getTotalArs();
        verify(saleMock, atLeastOnce()).getTotalUsd();

    }


    /**
     * Sample Row
     * Fecha del Pedido;Nro de Factura;ID SAP del Comercio;ID SAP del Productor;Cantidad de Toneladas;Total ARS;Total USD;Fecha de Pago;Nro NVLP
     * 18.04.2013;100108806;1008081;0001099737;100.000;184852.50;36750.00;;
     */
    private void createCsvSaleMock(String date,String invoiceNumber,String idCustomerSapCode,String idGrowerSapCode,String amount,String totalArs,String totalUsd) {
        saleMock = mock(CsvSaleOrderToCash.class);
        when(saleMock.getSaleDate()).thenReturn(date);
        when(saleMock.getInvoiceNumber()).thenReturn(invoiceNumber);
        when(saleMock.getHeadOfficeDocument()).thenReturn(idCustomerSapCode);
        when(saleMock.getGrowerDocument()).thenReturn(idGrowerSapCode);
        when(saleMock.getTonsQty()).thenReturn(amount);
        when(saleMock.getTotalArs()).thenReturn(totalArs);
        when(saleMock.getTotalUsd()).thenReturn(totalUsd);
    }


    @Test
    public void testGetSaleWithItems__WhenGetServiceToOrderIsCalled() throws Exception {
        // @Given A sale Order to Cash Object and this services SaleService saleService,BaseService baseService, CustomerService customerService, CountriesHolder countryHolder
        createCsvSaleMock("18.04.2013", "100108806", "1008081", "0001099737", "100.000", "184852.50","36750.00");
        when(saleOrderImportService.validateSaleOrder(mock(Grower.class))).thenReturn(null);
        converter.convert(saleMock);
        when(countryHolder.getCountry()).thenReturn(VCCountry.ARGENTINA);
        when(growerDAO.selectGrowerByCustomerSapId("0001099737")).thenReturn(mock(Grower.class));

        SaleTemplate saleTemplate=mock(SaleTemplate.class);
        Product product=mock(Product.class);
        Set products =mock(Set.class);
        products.add(product);
        saleTemplate.setProducts(products);
        when(saleTemplate.getProducts()).thenReturn(products);
        when(products.iterator()).thenReturn(mock(Iterator.class));
        Set prices =mock(Set.class);
        Price price =mock(Price.class);
        prices.add(price);
        when(saleTemplate.getPrices()).thenReturn(prices);
        Iterator it= mock(Iterator.class);
        when(prices.iterator()).thenReturn(it);
        when(it.next()).thenReturn(price);
        DueDateValue dueDate=mock(DueDateValue.class);
        saleTemplate.addPrices(price);
        price.addDueDate(dueDate);
        Set dueDates=mock(Set.class);
        dueDates.add(dueDate) ;
        when(price.getDueDates()).thenReturn(dueDates);
        Iterator itDue=mock(Iterator.class);
        when(dueDates.iterator()).thenReturn(itDue);
        when(itDue.next()).thenReturn(dueDate);
        when(dueDate.getValue()).thenReturn(mock(Date.class));

       // Date dueDate = ((DueDateValue) price.getDueDates().iterator().next()).getValue();
        when(saleService.getSaleTemplateByType(Sale.SaleTypeEnum.SALE_AND_ORDER_OBTENTOR)).thenReturn(saleTemplate);


        // @When converter is provided
        //converter.getSaleOrderToCash(saleService, baseService, customerService, countryHolder);
        // @Then it return true if Sale fields are calling at least one.



    }




}
