package com.monsanto.brazilvaluecapture.multiplier.extract.credit.service.impl;

import com.monsanto.brazilvaluecapture.core.base.model.bean.Company;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Crop;
import com.monsanto.brazilvaluecapture.core.base.service.BaseService;
import com.monsanto.brazilvaluecapture.core.base.service.ConstraintException;
import com.monsanto.brazilvaluecapture.core.foundation.test.AbstractServiceIntegrationTests;
import com.monsanto.brazilvaluecapture.core.foundation.test.dbunit.DbUnitHelper;
import com.monsanto.brazilvaluecapture.core.grower.model.bean.Grower;
import com.monsanto.brazilvaluecapture.multiplier.extract.credit.model.bean.detail.DetailedMultiplierDiscardCreditAmount;
import com.monsanto.brazilvaluecapture.multiplier.extract.credit.service.MultiplierCreditService;
import com.monsanto.brazilvaluecapture.multiplier.volumereport.model.bean.DiscardPortioning;
import com.monsanto.brazilvaluecapture.multiplier.volumereport.model.bean.VolumeReportDetail;
import com.monsanto.brazilvaluecapture.multiplier.volumereport.model.bean.VolumeReportFieldEnum;
import com.monsanto.brazilvaluecapture.multiplier.volumereport.service.VolumeReportApproveService;
import com.monsanto.brazilvaluecapture.multiplier.volumereport.service.VolumeReportReversalService;
import com.monsanto.brazilvaluecapture.multiplier.volumereport.service.impl.VolumeReportTestData;
import com.monsanto.brazilvaluecapture.seedsale.extract.credit.model.bean.SummaryCreditExtract;
import com.monsanto.brazilvaluecapture.seedsale.extract.credit.model.bean.amount.MultiplierDiscardComposite;
import com.monsanto.brazilvaluecapture.seedsale.quota.service.InsufficientQuotaForPhase6Approval;
import com.monsanto.brazilvaluecapture.seedsale.sale.service.SaleService;
import edu.emory.mathcs.backport.java.util.Arrays;
import junit.framework.Assert;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class MultiplierCreditServiceImpl_AT extends AbstractServiceIntegrationTests {

    @Qualifier("volumeReportApproveServiceImpl")
    @Autowired
    private VolumeReportApproveService volumeReportApproveService;

    @Qualifier("volumeReportReversalServiceImpl")
    @Autowired
    private VolumeReportReversalService volumeReportReversalService;

    @Qualifier("baseServiceImpl")
    @Autowired
    private BaseService baseService;

    @Qualifier("multiplierCreditServiceImpl")
    @Autowired
    private MultiplierCreditService multiplierCreditService;

    @Qualifier("saleServiceImpl")
    @Autowired
    private SaleService saleService;
    //900000003, 900000004
    private void approveToPhase(VolumeReportDetail detail, VolumeReportFieldEnum fieldEnum, BigDecimal areaValue, BigDecimal nextHarvest, BigDecimal deltaValue, String login, List<Grower> growers, boolean doPortioning) throws InsufficientQuotaForPhase6Approval {
        VolumeReportFieldEnum itFieldEnum=VolumeReportFieldEnum.ENTERED_AREA;
        BigDecimal value = nextHarvest.add(deltaValue.multiply(BigDecimal.valueOf(7)));
        growers.add(baseService.selectGrowerBy(detail.getVolumeReportHeader().getMatrix().getDocument()));
        do {
            detail=getVolumeReportDetail(detail.getId());
            if(itFieldEnum==VolumeReportFieldEnum.ENTERED_AREA) {
                detail.getEnteredArea().setValue(areaValue);
                detail.getMatrixSeedUsed().setValue(BigDecimal.TEN);
                detail.getOwnSeedUsed().setValue(BigDecimal.TEN);
                volumeReportApproveService.approve(VolumeReportTestData.generateApprovalDTO(VolumeReportFieldEnum.ENTERED_AREA, detail.getId()), detail.getVolumeReportHeader(), VolumeReportTestData.mockUser(login));
                getSession().flush();
                detail=getVolumeReportDetail(detail.getId());
                saveAndFlush(detail);
            } else if(doPortioning&&itFieldEnum==VolumeReportFieldEnum.PORTIONING) {
                BigDecimal portionArea = areaValue.subtract(BigDecimal.ONE).divide(BigDecimal.valueOf(growers.size()),2,BigDecimal.ROUND_DOWN);
                for(Grower g:growers) {
                    detail.addDiscardPortioning(new DiscardPortioning(g,detail,portionArea));
                }
                saveAndFlush(detail);
                volumeReportApproveService.approve(VolumeReportTestData.generateApprovalDTO(itFieldEnum, detail.getId()), detail.getVolumeReportHeader(), VolumeReportTestData.mockUser(login));
                getSession().flush();
            }  else {
                switch (itFieldEnum) {
                    case VOLUME_COMMERCIALIZED1:
                    case VOLUME_COMMERCIALIZED2:
                    case VOLUME_COMMERCIALIZED3:
                        detail.getFieldByPhase(itFieldEnum).setValue(BigDecimal.TEN);
                        break;
                    default:
                        detail.getFieldByPhase(itFieldEnum).setValue(value);
                }
                value = value.subtract(deltaValue);
                saveAndFlush(detail);
                volumeReportApproveService.approve(VolumeReportTestData.generateApprovalDTO(itFieldEnum, detail.getId()), detail.getVolumeReportHeader(), VolumeReportTestData.mockUser(login));
                getSession().flush();
            }
            if(itFieldEnum==fieldEnum) {
                break;
            }
            itFieldEnum=itFieldEnum.getNextField(true, true);
        } while(itFieldEnum!=null);
    }

    private void setup() {
        DbUnitHelper.setup(
                "classpath:data/multiplier/basic-fixture.xml",
                "classpath:data/multiplier/volume-report-dataset.xml");
    }

    private VolumeReportDetail getVolumeReportDetail(Long id) {
        return (VolumeReportDetail)getSession().get(VolumeReportDetail.class,id);
    }

    private Grower getGrower(Long id) {
        return (Grower)getSession().get(Grower.class,id);
    }

    @Test
    public void given_multiple_volume_report_details_when_approve_extract_should_match() throws ConstraintException, InsufficientQuotaForPhase6Approval {
        setup();
        Company company = (Company)getSession().get(Company.class,900000001L);
        Crop crop = (Crop)getSession().get(Crop.class,900000001L);

        VolumeReportDetail detail = getVolumeReportDetail(900000003l);
        Grower grower1 = getGrower(900000003l);
        Grower custGrower = baseService.selectGrowerBy(detail.getVolumeReportHeader().getMatrix().getDocument());
        List<Grower> growerList = new ArrayList<Grower>(2);
        growerList.add(grower1);
        approveToPhase(detail, VolumeReportFieldEnum.VOLUME_UBS, BigDecimal.valueOf(2500), BigDecimal.valueOf(50), BigDecimal.TEN, "LOOO", growerList, false);
        getSession().flush();

        List<SummaryCreditExtract> creditExtracts = saleService.getCreditExtract(custGrower,
                crop, company);
        Assert.assertFalse("Should not be empty", creditExtracts.isEmpty());
        Assert.assertEquals("Should have 1", 1, creditExtracts.size());
        Assert.assertEquals("Should be 10 but was " + creditExtracts.iterator().next().getTotalMultiplierDiscardAmount().getValue(), 0, creditExtracts.iterator().next().getTotalMultiplierDiscardAmount().getValue().compareTo(BigDecimal.TEN));
        DetailedMultiplierDiscardCreditAmount detailOfMultiplierDiscard = multiplierCreditService.getDetailOfMultiplierDiscard(creditExtracts.iterator().next().getTotalMultiplierDiscardAmount());
        Assert.assertEquals("Should have 1", 1, detailOfMultiplierDiscard.getFields().size());
        MultiplierDiscardComposite discardComposite = detailOfMultiplierDiscard.getFields().iterator().next();
        Assert.assertEquals("Should be volume ubs", VolumeReportFieldEnum.VOLUME_UBS, discardComposite.getVolumeReportFieldType());
        Assert.assertEquals("Should be 10 but was " + discardComposite.getValue(), 0, BigDecimal.TEN.compareTo(discardComposite.getValue()));
        Assert.assertEquals("Should have same grower", custGrower, discardComposite.getGrower());
    }

    @SuppressWarnings("unchecked")
	@Test
    public void given_one_detail_multiple_approvals_should_return_multiple_fields() throws ConstraintException, InsufficientQuotaForPhase6Approval {
        setup();
        Company company = (Company)getSession().get(Company.class,900000001L);
        Crop crop = (Crop)getSession().get(Crop.class,900000001L);

        VolumeReportDetail detail = getVolumeReportDetail(900000003l);
        detail.getCultivar().setObtainerOnly(false);
        getSession().save(detail.getCultivar());
        Grower grower1 = getGrower(900000003l);
        Grower custGrower = baseService.selectGrowerBy(detail.getVolumeReportHeader().getMatrix().getDocument());
        List<Grower> growerList = new ArrayList<Grower>(2);
        growerList.add(grower1);
        approveToPhase(detail, VolumeReportFieldEnum.VOLUME_FOR_NEXT_HARVEST, BigDecimal.valueOf(2500), BigDecimal.valueOf(50), BigDecimal.TEN, "LOOO", growerList, false);
        getSession().flush();

        List<SummaryCreditExtract> creditExtracts = saleService.getCreditExtract(custGrower,
                crop, company);
        Assert.assertFalse("Should not be empty", creditExtracts.isEmpty());
        Assert.assertEquals("Should have 1", 1, creditExtracts.size());
        Assert.assertEquals("Should be 40 but was " + creditExtracts.iterator().next().getTotalMultiplierDiscardAmount().getValue(), 0, creditExtracts.iterator().next().getTotalMultiplierDiscardAmount().getValue().compareTo(BigDecimal.valueOf(40L)));
        DetailedMultiplierDiscardCreditAmount detailOfMultiplierDiscard = multiplierCreditService.getDetailOfMultiplierDiscard(creditExtracts.iterator().next().getTotalMultiplierDiscardAmount());
        Assert.assertEquals("Should have 4", 4, detailOfMultiplierDiscard.getFields().size());
        Set<VolumeReportFieldEnum> fields = new HashSet<VolumeReportFieldEnum>(Arrays.asList(new VolumeReportFieldEnum[] {VolumeReportFieldEnum.VOLUME_UBS, VolumeReportFieldEnum.VOLUME_APPROVED, VolumeReportFieldEnum.VOLUME_BENEFITTED, VolumeReportFieldEnum.VOLUME_FOR_NEXT_HARVEST} ));
        for(MultiplierDiscardComposite field:detailOfMultiplierDiscard.getFields()) {
            fields.remove(field.getVolumeReportFieldType());
        }
        Assert.assertTrue("Should have found all fields", fields.isEmpty());
    }

    @SuppressWarnings("unchecked")
	@Test
    public void given_portioning_should_generate_extract_for_two_growers() throws ConstraintException, InsufficientQuotaForPhase6Approval {
        setup();
        Company company = (Company)getSession().get(Company.class,900000001L);
        Crop crop = (Crop)getSession().get(Crop.class,900000001L);

        VolumeReportDetail detail = getVolumeReportDetail(900000003l);
        Grower grower1 = getGrower(900000003l);
        Grower custGrower = baseService.selectGrowerBy(detail.getVolumeReportHeader().getMatrix().getDocument());
        List<Grower> growerList = new ArrayList<Grower>(2);
        growerList.add(grower1);
        BigDecimal areaValue = BigDecimal.valueOf(2500);
        approveToPhase(detail, VolumeReportFieldEnum.VOLUME_UBS, areaValue, BigDecimal.valueOf(50), BigDecimal.TEN, "LOOO", growerList, true);
        getSession().flush();
        BigDecimal portionArea = areaValue.subtract(BigDecimal.ONE).divide(BigDecimal.valueOf(2), 2, BigDecimal.ROUND_DOWN);

        List<SummaryCreditExtract> creditExtracts = saleService.getCreditExtract(custGrower,
                crop, company);
        Assert.assertFalse("Should not be empty", creditExtracts.isEmpty());
        Assert.assertEquals("Should have 1", 1, creditExtracts.size());
        BigDecimal totalValue  = BigDecimal.TEN.multiply(portionArea).add(BigDecimal.valueOf(10L));
        Assert.assertEquals("should be" + totalValue + " was " + creditExtracts.iterator().next().getTotalMultiplierDiscardAmount().getValue(), 0, creditExtracts.iterator().next().getTotalMultiplierDiscardAmount().getValue().compareTo(totalValue));
        DetailedMultiplierDiscardCreditAmount detailOfMultiplierDiscard = multiplierCreditService.getDetailOfMultiplierDiscard(creditExtracts.iterator().next().getTotalMultiplierDiscardAmount());
        Assert.assertEquals("Should have 2", 2, detailOfMultiplierDiscard.getFields().size());
        Set<VolumeReportFieldEnum> fields = new HashSet<VolumeReportFieldEnum>(Arrays.asList(new VolumeReportFieldEnum[] {VolumeReportFieldEnum.VOLUME_UBS, VolumeReportFieldEnum.PORTIONING} ));
        for(MultiplierDiscardComposite field:detailOfMultiplierDiscard.getFields()) {
            fields.remove(field.getVolumeReportFieldType());
        }
        Assert.assertTrue("Should have found all fields", fields.isEmpty());
        creditExtracts = saleService.getCreditExtract(grower1,
                crop, company);
        Assert.assertEquals("Should have 1", 1, creditExtracts.size());
        totalValue  = BigDecimal.TEN.multiply(portionArea);
        SummaryCreditExtract creditExtract = creditExtracts.iterator().next();
        Assert.assertEquals("Should be " + totalValue + " but was " + creditExtract.getTotalMultiplierDiscardAmount().getValue(), 0, creditExtract.getTotalMultiplierDiscardAmount().getValue().compareTo(totalValue));
        detailOfMultiplierDiscard = multiplierCreditService.getDetailOfMultiplierDiscard(creditExtract.getTotalMultiplierDiscardAmount());
        Assert.assertEquals("Should have 1", 1, detailOfMultiplierDiscard.getFields().size());
        Assert.assertEquals("Should be same grower ", custGrower, detailOfMultiplierDiscard.getFields().iterator().next().getGrower());
    }


    @Test
    public void given_approval_and_reversal_should_have_zero_balance_and_no_entries() throws ConstraintException, InsufficientQuotaForPhase6Approval {
        setup();
        Company company = (Company)getSession().get(Company.class,900000001L);
        Crop crop = (Crop)getSession().get(Crop.class,900000001L);

        VolumeReportDetail detail = getVolumeReportDetail(900000003l);
        Grower grower1 = getGrower(900000003l);
        Grower custGrower = baseService.selectGrowerBy(detail.getVolumeReportHeader().getMatrix().getDocument());
        List<Grower> growerList = new ArrayList<Grower>(2);
        growerList.add(grower1);
        approveToPhase(detail, VolumeReportFieldEnum.VOLUME_UBS, BigDecimal.valueOf(2500), BigDecimal.valueOf(50), BigDecimal.TEN, "LOOO", growerList, false);
        getSession().flush();
        detail = getVolumeReportDetail(900000003l);
        volumeReportReversalService.reversalPhase2VolForUBS(detail, "BOOO");



        List<SummaryCreditExtract> creditExtracts = saleService.getCreditExtract(custGrower,
                crop, company);
        Assert.assertFalse("Should not be empty", creditExtracts.isEmpty());
        Assert.assertEquals("Should have 1", 1, creditExtracts.size());
        Assert.assertEquals("Should be 0 but was " + creditExtracts.iterator().next().getTotalMultiplierDiscardAmount().getValue(), 0, creditExtracts.iterator().next().getTotalMultiplierDiscardAmount().getValue().compareTo(BigDecimal.ZERO));
        DetailedMultiplierDiscardCreditAmount detailOfMultiplierDiscard = multiplierCreditService.getDetailOfMultiplierDiscard(creditExtracts.iterator().next().getTotalMultiplierDiscardAmount());
        Assert.assertEquals("Should have 0", 0, detailOfMultiplierDiscard.getFields().size());

        volumeReportApproveService.approve(VolumeReportTestData.generateApprovalDTO(VolumeReportFieldEnum.VOLUME_UBS, detail.getId()), detail.getVolumeReportHeader(), VolumeReportTestData.mockUser("LOOO"));
        creditExtracts = saleService.getCreditExtract(custGrower,
                crop, company);
        Assert.assertEquals("Should have 1", 1, creditExtracts.size());
        Assert.assertEquals("Should be 10 but was " + creditExtracts.iterator().next().getTotalMultiplierDiscardAmount().getValue(), 0, creditExtracts.iterator().next().getTotalMultiplierDiscardAmount().getValue().compareTo(BigDecimal.TEN));
        detailOfMultiplierDiscard = multiplierCreditService.getDetailOfMultiplierDiscard(creditExtracts.iterator().next().getTotalMultiplierDiscardAmount());
        Assert.assertEquals("Should have 1", 1, detailOfMultiplierDiscard.getFields().size());
        Assert.assertEquals("Should be volume ubs", VolumeReportFieldEnum.VOLUME_UBS, detailOfMultiplierDiscard.getFields().iterator().next().getVolumeReportFieldType());
    }
}
