package com.monsanto.brazilvaluecapture.multiplier.volumereport.model.bean;

import com.monsanto.brazilvaluecapture.core.revenue.model.bean.RevenueStatus;
import com.monsanto.brazilvaluecapture.multiplier.volumereport.model.bean.VolumeReportApprovalDTO.ApprovalStateHolder;
import junit.framework.Assert;
import org.junit.Test;

public class VolumeReportApprovalDTO_UT {



    @Test
    public void given_non_specific_status_report_approval_document_fields_should_be_valid() {
        VolumeReportApprovalDTO volumeReportApprovalDTO = generateVolumeReportApprovalDTO(null, VolumeReportStatus.WAITING_REPORT,
                VolumeReportStatus.WAITING_REPORT, VolumeReportStatus.WAITING_REPORT, VolumeReportStatus.WAITING_REPORT, VolumeReportStatus.WAITING_REPORT,
                VolumeReportStatus.WAITING_REPORT, VolumeReportStatus.WAITING_REPORT, VolumeReportStatus.WAITING_REPORT,
                VolumeReportStatus.WAITING_REPORT, VolumeReportStatus.WAITING_REPORT, true, false, true);
        Assert.assertEquals(1L, volumeReportApprovalDTO.getHeaderId().longValue());
        Assert.assertEquals(1L, volumeReportApprovalDTO.getDetailId().longValue());
        Assert.assertEquals("9876.5432-100", volumeReportApprovalDTO.getCustomerDocument());
        Assert.assertEquals("123.456.789-00", volumeReportApprovalDTO.getMatrixDocument());
        Assert.assertEquals("test", volumeReportApprovalDTO.getMatrixName());
        Assert.assertEquals("1", volumeReportApprovalDTO.getMatrixSapCode());
        Assert.assertEquals("test2", volumeReportApprovalDTO.getCustomerName());
        Assert.assertEquals("2", volumeReportApprovalDTO.getCustomerSapCode());
        Assert.assertEquals("harv", volumeReportApprovalDTO.getHarvestDescription());
        Assert.assertEquals("obt", volumeReportApprovalDTO.getObtainerDescription());
        Assert.assertEquals("cult", volumeReportApprovalDTO.getCultivarDescription());
        Assert.assertEquals("C1", volumeReportApprovalDTO.getClassAbbreviation());
    }

    @Test
    public void given_approval_with_all_waiting_report_no_phase_should_be_available() {
        VolumeReportApprovalDTO volumeReportApprovalDTO = generateVolumeReportApprovalDTO(null, VolumeReportStatus.WAITING_REPORT,
                VolumeReportStatus.WAITING_REPORT, VolumeReportStatus.WAITING_REPORT, VolumeReportStatus.WAITING_REPORT, VolumeReportStatus.WAITING_REPORT,
                VolumeReportStatus.WAITING_REPORT, VolumeReportStatus.WAITING_REPORT, VolumeReportStatus.WAITING_REPORT,
                VolumeReportStatus.WAITING_REPORT, VolumeReportStatus.WAITING_REPORT, true, false, true);

        assertApprovedStatuses(new boolean[] {false, false, false, false, false, false, false, false, false, false}, extractStateHolders(volumeReportApprovalDTO));
        assertAvailableStatuses(new boolean[] {false, false, false, false, false, false, false, false, false, false}, extractStateHolders(volumeReportApprovalDTO));
        assertHiddenStatuses(new boolean[] {false, false, false, false, false, false, false, false, false, false}, extractStateHolders(volumeReportApprovalDTO));
        assertReturnAvailableStatuses(new boolean[] {false, false, false, false, false, false, false, false, false, false}, extractStateHolders(volumeReportApprovalDTO));
    }

    @Test
    public void given_approval_with_phase1_reported_phase_1_should_be_available_for_return() {
        VolumeReportApprovalDTO volumeReportApprovalDTO = generateVolumeReportApprovalDTO(RevenueStatus.REVERSED, VolumeReportStatus.APPROVED,
                VolumeReportStatus.WAITING_REPORT, VolumeReportStatus.WAITING_REPORT, VolumeReportStatus.WAITING_REPORT, VolumeReportStatus.WAITING_REPORT,
                VolumeReportStatus.WAITING_REPORT, VolumeReportStatus.WAITING_REPORT, VolumeReportStatus.WAITING_REPORT,
                VolumeReportStatus.WAITING_REPORT, VolumeReportStatus.WAITING_REPORT, true, false, true);

        assertApprovedStatuses(new boolean[] {true, false, false, false, false, false, false, false, false, false}, extractStateHolders(volumeReportApprovalDTO));
        assertAvailableStatuses(new boolean[] {false, false, false, false, false, false, false, false, false, false}, extractStateHolders(volumeReportApprovalDTO));
        assertHiddenStatuses(new boolean[] {false, false, false, false, false, false, false, false, false, false}, extractStateHolders(volumeReportApprovalDTO));
        assertReturnAvailableStatuses(new boolean[] {true, false, false, false, false, false, false, false, false, false}, extractStateHolders(volumeReportApprovalDTO));

        volumeReportApprovalDTO = generateVolumeReportApprovalDTO(RevenueStatus.BILLED, VolumeReportStatus.BILLED,
            VolumeReportStatus.WAITING_REPORT, VolumeReportStatus.WAITING_REPORT, VolumeReportStatus.WAITING_REPORT, VolumeReportStatus.WAITING_REPORT,
            VolumeReportStatus.WAITING_REPORT, VolumeReportStatus.WAITING_REPORT, VolumeReportStatus.WAITING_REPORT,
            VolumeReportStatus.WAITING_REPORT, VolumeReportStatus.WAITING_REPORT, true, false, true);

        assertApprovedStatuses(new boolean[] {true, false, false, false, false, false, false, false, false, false}, extractStateHolders(volumeReportApprovalDTO));
        assertAvailableStatuses(new boolean[] {false, false, false, false, false, false, false, false, false, false}, extractStateHolders(volumeReportApprovalDTO));
        assertHiddenStatuses(new boolean[] {false, false, false, false, false, false, false, false, false, false}, extractStateHolders(volumeReportApprovalDTO));
        assertReturnAvailableStatuses(new boolean[] {true, false, false, false, false, false, false, false, false, false}, extractStateHolders(volumeReportApprovalDTO));

        volumeReportApprovalDTO = generateVolumeReportApprovalDTO(RevenueStatus.BILLED, VolumeReportStatus.BILLED,
                VolumeReportStatus.RETURNED, VolumeReportStatus.WAITING_REPORT, VolumeReportStatus.WAITING_REPORT, VolumeReportStatus.WAITING_REPORT,
                VolumeReportStatus.WAITING_REPORT, VolumeReportStatus.WAITING_REPORT, VolumeReportStatus.WAITING_REPORT,
                VolumeReportStatus.WAITING_REPORT, VolumeReportStatus.WAITING_REPORT, true, false, true);

        assertApprovedStatuses(new boolean[] {true, false, false, false, false, false, false, false, false, false}, extractStateHolders(volumeReportApprovalDTO));
        assertAvailableStatuses(new boolean[] {false, false, false, false, false, false, false, false, false, false}, extractStateHolders(volumeReportApprovalDTO));
        assertHiddenStatuses(new boolean[] {false, false, false, false, false, false, false, false, false, false}, extractStateHolders(volumeReportApprovalDTO));
        assertReturnAvailableStatuses(new boolean[] {true, false, false, false, false, false, false, false, false, false}, extractStateHolders(volumeReportApprovalDTO));

        volumeReportApprovalDTO = generateVolumeReportApprovalDTO(RevenueStatus.BILLED, VolumeReportStatus.BILLED,
                VolumeReportStatus.RETURNED, VolumeReportStatus.RETURNED, VolumeReportStatus.RETURNED, VolumeReportStatus.RETURNED,
                VolumeReportStatus.RETURNED, VolumeReportStatus.RETURNED, VolumeReportStatus.RETURNED,
                VolumeReportStatus.RETURNED, VolumeReportStatus.WAITING_REPORT, true, false, true);

        assertApprovedStatuses(new boolean[] {true, false, false, false, false, false, false, false, false, false}, extractStateHolders(volumeReportApprovalDTO));
        assertAvailableStatuses(new boolean[] {false, false, false, false, false, false, false, false, false, false}, extractStateHolders(volumeReportApprovalDTO));
        assertHiddenStatuses(new boolean[] {false, false, false, false, false, false, false, false, false, false}, extractStateHolders(volumeReportApprovalDTO));
        assertReturnAvailableStatuses(new boolean[] {true, false, false, false, false, false, false, false, false, false}, extractStateHolders(volumeReportApprovalDTO));

        volumeReportApprovalDTO = generateVolumeReportApprovalDTO(RevenueStatus.BILLED, VolumeReportStatus.BILLED,
                VolumeReportStatus.REPORTED, VolumeReportStatus.WAITING_REPORT, VolumeReportStatus.WAITING_REPORT, VolumeReportStatus.WAITING_REPORT,
                VolumeReportStatus.WAITING_REPORT, VolumeReportStatus.WAITING_REPORT, VolumeReportStatus.WAITING_REPORT,
                VolumeReportStatus.WAITING_REPORT, VolumeReportStatus.WAITING_REPORT, true, false, true);

        assertApprovedStatuses(new boolean[] {true, false, false, false, false, false, false, false, false, false}, extractStateHolders(volumeReportApprovalDTO));
        assertAvailableStatuses(new boolean[] {false, true, false, false, false, false, false, false, false, false}, extractStateHolders(volumeReportApprovalDTO));
        assertHiddenStatuses(new boolean[] {false, false, false, false, false, false, false, false, false, false}, extractStateHolders(volumeReportApprovalDTO));
        assertReturnAvailableStatuses(new boolean[] {true, false, false, false, false, false, false, false, false, false}, extractStateHolders(volumeReportApprovalDTO));
    }

    @Test
    public void given_run_through_statuses_return_and_available_statuses_should_change_correctly() {

        VolumeReportApprovalDTO volumeReportApprovalDTO = generateVolumeReportApprovalDTO(null, VolumeReportStatus.APPROVED,
                VolumeReportStatus.APPROVED, VolumeReportStatus.WAITING_REPORT, VolumeReportStatus.WAITING_REPORT, VolumeReportStatus.WAITING_REPORT,
                VolumeReportStatus.WAITING_REPORT, VolumeReportStatus.WAITING_REPORT, VolumeReportStatus.WAITING_REPORT,
                VolumeReportStatus.WAITING_REPORT, VolumeReportStatus.WAITING_REPORT, true, false, true);

        assertApprovedStatuses(new boolean[] {true, true, false, false, false, false, false, false, false, false}, extractStateHolders(volumeReportApprovalDTO));
        assertAvailableStatuses(new boolean[] {false, false, false, false, false, false, false, false, false, false}, extractStateHolders(volumeReportApprovalDTO));
        assertHiddenStatuses(new boolean[] {false, false, false, false, false, false, false, false, false, false}, extractStateHolders(volumeReportApprovalDTO));
        assertReturnAvailableStatuses(new boolean[] {false, true, false, false, false, false, false, false, false, false}, extractStateHolders(volumeReportApprovalDTO));

        volumeReportApprovalDTO = generateVolumeReportApprovalDTO(null, VolumeReportStatus.APPROVED,
                VolumeReportStatus.APPROVED, VolumeReportStatus.REPORTED, VolumeReportStatus.WAITING_REPORT, VolumeReportStatus.WAITING_REPORT,
                VolumeReportStatus.WAITING_REPORT, VolumeReportStatus.WAITING_REPORT, VolumeReportStatus.WAITING_REPORT,
                VolumeReportStatus.WAITING_REPORT, VolumeReportStatus.WAITING_REPORT, true, false, true);

        assertApprovedStatuses(new boolean[] {true, true, false, false, false, false, false, false, false, false}, extractStateHolders(volumeReportApprovalDTO));
        assertAvailableStatuses(new boolean[] {false, false, true, false, false, false, false, false, false, false}, extractStateHolders(volumeReportApprovalDTO));
        assertHiddenStatuses(new boolean[] {false, false, false, false, false, false, false, false, false, false}, extractStateHolders(volumeReportApprovalDTO));
        assertReturnAvailableStatuses(new boolean[] {false, true, false, false, false, false, false, false, false, false}, extractStateHolders(volumeReportApprovalDTO));



    }

    @Test
    public void given_approved_status_on_volume_harvested_return_should_be_available() {
        VolumeReportApprovalDTO volumeReportApprovalDTO;
        volumeReportApprovalDTO = generateVolumeReportApprovalDTO(null, VolumeReportStatus.APPROVED,
                VolumeReportStatus.APPROVED, VolumeReportStatus.APPROVED, VolumeReportStatus.WAITING_REPORT, VolumeReportStatus.WAITING_REPORT,
                VolumeReportStatus.WAITING_REPORT, VolumeReportStatus.WAITING_REPORT, VolumeReportStatus.WAITING_REPORT,
                VolumeReportStatus.WAITING_REPORT, VolumeReportStatus.WAITING_REPORT, true, false, true);

        assertApprovedStatuses(new boolean[] {true, true, true, false, false, false, false, false, false, false}, extractStateHolders(volumeReportApprovalDTO));
        assertAvailableStatuses(new boolean[] {false, false, false, false, false, false, false, false, false, false}, extractStateHolders(volumeReportApprovalDTO));
        assertHiddenStatuses(new boolean[] {false, false, false, false, false, false, false, false, false, false}, extractStateHolders(volumeReportApprovalDTO));
        assertReturnAvailableStatuses(new boolean[] {false, false, true, false, false, false, false, false, false, false}, extractStateHolders(volumeReportApprovalDTO));

        volumeReportApprovalDTO = generateVolumeReportApprovalDTO(null, VolumeReportStatus.APPROVED,
                VolumeReportStatus.APPROVED, VolumeReportStatus.APPROVED, VolumeReportStatus.REPORTED, VolumeReportStatus.WAITING_REPORT,
                VolumeReportStatus.WAITING_REPORT, VolumeReportStatus.WAITING_REPORT, VolumeReportStatus.WAITING_REPORT,
                VolumeReportStatus.WAITING_REPORT, VolumeReportStatus.WAITING_REPORT, true, false, true);

        assertApprovedStatuses(new boolean[] {true, true, true, false, false, false, false, false, false, false}, extractStateHolders(volumeReportApprovalDTO));
        assertAvailableStatuses(new boolean[] {false, false, false, true, false, false, false, false, false, false}, extractStateHolders(volumeReportApprovalDTO));
        assertHiddenStatuses(new boolean[] {false, false, false, false, false, false, false, false, false, false}, extractStateHolders(volumeReportApprovalDTO));
        assertReturnAvailableStatuses(new boolean[] {false, false, true, false, false, false, false, false, false, false}, extractStateHolders(volumeReportApprovalDTO));

        Assert.assertFalse(volumeReportApprovalDTO.hasNewApproval());
        Assert.assertNull("Should not find", volumeReportApprovalDTO.findNewApproval());
        volumeReportApprovalDTO.getVolumeForUBSApprovalState().setApproved(true);
        Assert.assertTrue(volumeReportApprovalDTO.hasNewApproval());
        Assert.assertEquals("Should be volume for ubs", VolumeReportFieldEnum.VOLUME_UBS,volumeReportApprovalDTO.findNewApproval());
    }

    @Test
    public void given_approved_status_on_volume_for_ubs_should_be_avaliable_for_return() {
        VolumeReportApprovalDTO volumeReportApprovalDTO;
        volumeReportApprovalDTO = generateVolumeReportApprovalDTO(null, VolumeReportStatus.APPROVED,
                VolumeReportStatus.APPROVED, VolumeReportStatus.APPROVED, VolumeReportStatus.APPROVED, VolumeReportStatus.WAITING_REPORT,
                VolumeReportStatus.WAITING_REPORT, VolumeReportStatus.WAITING_REPORT, VolumeReportStatus.WAITING_REPORT,
                VolumeReportStatus.WAITING_REPORT, VolumeReportStatus.WAITING_REPORT, true, false, true);

        assertApprovedStatuses(new boolean[] {true, true, true, true, false, false, false, false, false, false}, extractStateHolders(volumeReportApprovalDTO));
        assertAvailableStatuses(new boolean[] {false, false, false, false, false, false, false, false, false, false}, extractStateHolders(volumeReportApprovalDTO));
        assertHiddenStatuses(new boolean[] {false, false, false, false, false, false, false, false, false, false}, extractStateHolders(volumeReportApprovalDTO));
        assertReturnAvailableStatuses(new boolean[] {false, false, false, true, false, false, false, false, false, false}, extractStateHolders(volumeReportApprovalDTO));

        volumeReportApprovalDTO = generateVolumeReportApprovalDTO(null, VolumeReportStatus.APPROVED,
                VolumeReportStatus.APPROVED, VolumeReportStatus.APPROVED, VolumeReportStatus.APPROVED, VolumeReportStatus.REPORTED,
                VolumeReportStatus.WAITING_REPORT, VolumeReportStatus.WAITING_REPORT, VolumeReportStatus.WAITING_REPORT,
                VolumeReportStatus.WAITING_REPORT, VolumeReportStatus.WAITING_REPORT, true, false, true);

        assertApprovedStatuses(new boolean[] {true, true, true, true, false, false, false, false, false, false}, extractStateHolders(volumeReportApprovalDTO));
        assertAvailableStatuses(new boolean[] {false, false, false, false, true, false, false, false, false, false}, extractStateHolders(volumeReportApprovalDTO));
        assertHiddenStatuses(new boolean[] {false, false, false, false, false, false, false, false, false, false}, extractStateHolders(volumeReportApprovalDTO));
        assertReturnAvailableStatuses(new boolean[] {false, false, false, true, false, false, false, false, false, false}, extractStateHolders(volumeReportApprovalDTO));
    }

    @Test
    public void given_approved_status_on_benefitted_volume_should_be_available_for_return() {
        VolumeReportApprovalDTO volumeReportApprovalDTO;
        volumeReportApprovalDTO = generateVolumeReportApprovalDTO(null, VolumeReportStatus.APPROVED,
                VolumeReportStatus.APPROVED, VolumeReportStatus.APPROVED, VolumeReportStatus.APPROVED, VolumeReportStatus.APPROVED,
                VolumeReportStatus.WAITING_REPORT, VolumeReportStatus.WAITING_REPORT, VolumeReportStatus.WAITING_REPORT,
                VolumeReportStatus.WAITING_REPORT, VolumeReportStatus.WAITING_REPORT, true, false, true);

        assertApprovedStatuses(new boolean[] {true, true, true, true, true, false, false, false, false, false}, extractStateHolders(volumeReportApprovalDTO));
        assertAvailableStatuses(new boolean[] {false, false, false, false, false, false, false, false, false, false}, extractStateHolders(volumeReportApprovalDTO));
        assertHiddenStatuses(new boolean[] {false, false, false, false, false, false, false, false, false, false}, extractStateHolders(volumeReportApprovalDTO));
        assertReturnAvailableStatuses(new boolean[] {false, false, false, false, true, false, false, false, false, false}, extractStateHolders(volumeReportApprovalDTO));

        volumeReportApprovalDTO = generateVolumeReportApprovalDTO(null, VolumeReportStatus.APPROVED,
                VolumeReportStatus.APPROVED, VolumeReportStatus.APPROVED, VolumeReportStatus.APPROVED, VolumeReportStatus.APPROVED,
                VolumeReportStatus.REPORTED, VolumeReportStatus.WAITING_REPORT, VolumeReportStatus.WAITING_REPORT,
                VolumeReportStatus.WAITING_REPORT, VolumeReportStatus.WAITING_REPORT, true, false, true);

        assertApprovedStatuses(new boolean[] {true, true, true, true, true, false, false, false, false, false}, extractStateHolders(volumeReportApprovalDTO));
        assertAvailableStatuses(new boolean[] {false, false, false, false, false, true, false, false, false, false}, extractStateHolders(volumeReportApprovalDTO));
        assertHiddenStatuses(new boolean[] {false, false, false, false, false, false, false, false, false, false}, extractStateHolders(volumeReportApprovalDTO));
        assertReturnAvailableStatuses(new boolean[] {false, false, false, false, true, false, false, false, false, false}, extractStateHolders(volumeReportApprovalDTO));
    }

    @Test
    public void given_approved_status_on_approved_volume_should_be_available_for_return() {
        VolumeReportApprovalDTO volumeReportApprovalDTO;
        volumeReportApprovalDTO = generateVolumeReportApprovalDTO(null, VolumeReportStatus.APPROVED,
                VolumeReportStatus.APPROVED, VolumeReportStatus.APPROVED, VolumeReportStatus.APPROVED, VolumeReportStatus.APPROVED,
                VolumeReportStatus.APPROVED, VolumeReportStatus.WAITING_REPORT, VolumeReportStatus.WAITING_REPORT,
                VolumeReportStatus.WAITING_REPORT, VolumeReportStatus.WAITING_REPORT, true, false, true);

        assertApprovedStatuses(new boolean[] {true, true, true, true, true, true, false, false, false, false}, extractStateHolders(volumeReportApprovalDTO));
        assertAvailableStatuses(new boolean[] {false, false, false, false, false, false, false, false, false, false}, extractStateHolders(volumeReportApprovalDTO));
        assertHiddenStatuses(new boolean[] {false, false, false, false, false, false, false, false, false, false}, extractStateHolders(volumeReportApprovalDTO));
        assertReturnAvailableStatuses(new boolean[] {false, false, false, false, false, true, false, false, false, false}, extractStateHolders(volumeReportApprovalDTO));

        volumeReportApprovalDTO = generateVolumeReportApprovalDTO(null, VolumeReportStatus.APPROVED,
                VolumeReportStatus.APPROVED, VolumeReportStatus.APPROVED, VolumeReportStatus.APPROVED, VolumeReportStatus.APPROVED,
                VolumeReportStatus.APPROVED, VolumeReportStatus.REPORTED, VolumeReportStatus.WAITING_REPORT,
                VolumeReportStatus.WAITING_REPORT, VolumeReportStatus.WAITING_REPORT, true, false, true);

        assertApprovedStatuses(new boolean[] {true, true, true, true, true, true, false, false, false, false}, extractStateHolders(volumeReportApprovalDTO));
        assertAvailableStatuses(new boolean[] {false, false, false, false, false, false, true, false, false, false}, extractStateHolders(volumeReportApprovalDTO));
        assertHiddenStatuses(new boolean[] {false, false, false, false, false, false, false, false, false, false}, extractStateHolders(volumeReportApprovalDTO));
        assertReturnAvailableStatuses(new boolean[] {false, false, false, false, false, true, false, false, false, false}, extractStateHolders(volumeReportApprovalDTO));
    }

    @Test
    public void given_approved_status_on_vol_comm1_should_be_available_for_return() {
        VolumeReportApprovalDTO volumeReportApprovalDTO;
        volumeReportApprovalDTO = generateVolumeReportApprovalDTO(null, VolumeReportStatus.APPROVED,
                VolumeReportStatus.APPROVED, VolumeReportStatus.APPROVED, VolumeReportStatus.APPROVED, VolumeReportStatus.APPROVED,
                VolumeReportStatus.APPROVED, VolumeReportStatus.APPROVED, VolumeReportStatus.WAITING_REPORT,
                VolumeReportStatus.WAITING_REPORT, VolumeReportStatus.WAITING_REPORT, true, false, true);

        assertApprovedStatuses(new boolean[] {true, true, true, true, true, true, true, false, false, false}, extractStateHolders(volumeReportApprovalDTO));
        assertAvailableStatuses(new boolean[] {false, false, false, false, false, false, false, false, false, false}, extractStateHolders(volumeReportApprovalDTO));
        assertHiddenStatuses(new boolean[] {false, false, false, false, false, false, false, false, false, false}, extractStateHolders(volumeReportApprovalDTO));
        assertReturnAvailableStatuses(new boolean[] {false, false, false, false, false, false, true, false, false, false}, extractStateHolders(volumeReportApprovalDTO));

        volumeReportApprovalDTO = generateVolumeReportApprovalDTO(null, VolumeReportStatus.APPROVED,
                VolumeReportStatus.APPROVED, VolumeReportStatus.APPROVED, VolumeReportStatus.APPROVED, VolumeReportStatus.APPROVED,
                VolumeReportStatus.APPROVED, VolumeReportStatus.BILLED, VolumeReportStatus.REPORTED,
                VolumeReportStatus.WAITING_REPORT, VolumeReportStatus.WAITING_REPORT, true, false, true);

        assertApprovedStatuses(new boolean[] {true, true, true, true, true, true, true, false, false, false}, extractStateHolders(volumeReportApprovalDTO));
        assertAvailableStatuses(new boolean[] {false, false, false, false, false, false, false, true, false, false}, extractStateHolders(volumeReportApprovalDTO));
        assertHiddenStatuses(new boolean[] {false, false, false, false, false, false, false, false, false, false}, extractStateHolders(volumeReportApprovalDTO));
        assertReturnAvailableStatuses(new boolean[] {false, false, false, false, false, false, true, false, false, false}, extractStateHolders(volumeReportApprovalDTO));
    }

    @Test
    public void given_approved_status_on_vol_comm2_should_be_available_for_return() {
        VolumeReportApprovalDTO volumeReportApprovalDTO;
        volumeReportApprovalDTO = generateVolumeReportApprovalDTO(null, VolumeReportStatus.APPROVED,
                VolumeReportStatus.APPROVED, VolumeReportStatus.APPROVED, VolumeReportStatus.APPROVED, VolumeReportStatus.APPROVED,
                VolumeReportStatus.APPROVED, VolumeReportStatus.APPROVED, VolumeReportStatus.APPROVED,
                VolumeReportStatus.WAITING_REPORT, VolumeReportStatus.WAITING_REPORT, true, false, true);

        assertApprovedStatuses(new boolean[] {true, true, true, true, true, true, true, true, false, false}, extractStateHolders(volumeReportApprovalDTO));
        assertAvailableStatuses(new boolean[] {false, false, false, false, false, false, false, false, false, false}, extractStateHolders(volumeReportApprovalDTO));
        assertHiddenStatuses(new boolean[] {false, false, false, false, false, false, false, false, false, false}, extractStateHolders(volumeReportApprovalDTO));
        assertReturnAvailableStatuses(new boolean[] {false, false, false, false, false, false, false, true, false, false}, extractStateHolders(volumeReportApprovalDTO));

        volumeReportApprovalDTO = generateVolumeReportApprovalDTO(null, VolumeReportStatus.APPROVED,
                VolumeReportStatus.APPROVED, VolumeReportStatus.APPROVED, VolumeReportStatus.APPROVED, VolumeReportStatus.APPROVED,
                VolumeReportStatus.APPROVED, VolumeReportStatus.APPROVED, VolumeReportStatus.BILLED,
                VolumeReportStatus.REPORTED, VolumeReportStatus.WAITING_REPORT, true, false, true);

        assertApprovedStatuses(new boolean[] {true, true, true, true, true, true, true, true, false, false}, extractStateHolders(volumeReportApprovalDTO));
        assertAvailableStatuses(new boolean[] {false, false, false, false, false, false, false, false, true, false}, extractStateHolders(volumeReportApprovalDTO));
        assertHiddenStatuses(new boolean[] {false, false, false, false, false, false, false, false, false, false}, extractStateHolders(volumeReportApprovalDTO));
        assertReturnAvailableStatuses(new boolean[] {false, false, false, false, false, false, false, true, false, false}, extractStateHolders(volumeReportApprovalDTO));
    }

    @Test
    public void given_approval_status_on_vol_com3_should_be_return_available() {
        VolumeReportApprovalDTO volumeReportApprovalDTO;
        volumeReportApprovalDTO = generateVolumeReportApprovalDTO(null, VolumeReportStatus.APPROVED,
                VolumeReportStatus.APPROVED, VolumeReportStatus.APPROVED, VolumeReportStatus.APPROVED, VolumeReportStatus.APPROVED,
                VolumeReportStatus.APPROVED, VolumeReportStatus.APPROVED, VolumeReportStatus.APPROVED,
                VolumeReportStatus.APPROVED, VolumeReportStatus.WAITING_REPORT, true, false, true);

        assertApprovedStatuses(new boolean[] {true, true, true, true, true, true, true, true, true, false}, extractStateHolders(volumeReportApprovalDTO));
        assertAvailableStatuses(new boolean[] {false, false, false, false, false, false, false, false, false, false}, extractStateHolders(volumeReportApprovalDTO));
        assertHiddenStatuses(new boolean[] {false, false, false, false, false, false, false, false, false, false}, extractStateHolders(volumeReportApprovalDTO));
        assertReturnAvailableStatuses(new boolean[] {false, false, false, false, false, false, false, false, true, false}, extractStateHolders(volumeReportApprovalDTO));

        volumeReportApprovalDTO = generateVolumeReportApprovalDTO(null, VolumeReportStatus.APPROVED,
                VolumeReportStatus.APPROVED, VolumeReportStatus.APPROVED, VolumeReportStatus.APPROVED, VolumeReportStatus.APPROVED,
                VolumeReportStatus.APPROVED, VolumeReportStatus.APPROVED, VolumeReportStatus.APPROVED,
                VolumeReportStatus.BILLED, VolumeReportStatus.REPORTED, true, false, true);

        assertApprovedStatuses(new boolean[] {true, true, true, true, true, true, true, true, true, false}, extractStateHolders(volumeReportApprovalDTO));
        assertAvailableStatuses(new boolean[] {false, false, false, false, false, false, false, false, false, true}, extractStateHolders(volumeReportApprovalDTO));
        assertHiddenStatuses(new boolean[] {false, false, false, false, false, false, false, false, false, false}, extractStateHolders(volumeReportApprovalDTO));
        assertReturnAvailableStatuses(new boolean[] {false, false, false, false, false, false, false, false, true, false}, extractStateHolders(volumeReportApprovalDTO));

        volumeReportApprovalDTO = generateVolumeReportApprovalDTO(null, VolumeReportStatus.APPROVED,
                VolumeReportStatus.APPROVED, VolumeReportStatus.APPROVED, VolumeReportStatus.APPROVED, VolumeReportStatus.APPROVED,
                VolumeReportStatus.APPROVED, VolumeReportStatus.APPROVED, VolumeReportStatus.APPROVED,
                VolumeReportStatus.REPORTED, VolumeReportStatus.REPORTED, true, false, false);

        assertApprovedStatuses(new boolean[] {true, true, true, true, true, true, true, true, false, false}, extractStateHolders(volumeReportApprovalDTO));
        assertAvailableStatuses(new boolean[] {false, false, false, false, false, false, false, false, false, true}, extractStateHolders(volumeReportApprovalDTO));
        assertHiddenStatuses(new boolean[] {false, false, false, false, false, false, false, false, true, false}, extractStateHolders(volumeReportApprovalDTO));
        assertReturnAvailableStatuses(new boolean[] {false, false, false, false, false, false, false, true, false, false}, extractStateHolders(volumeReportApprovalDTO));
    }

    @Test
    public void given_all_approved_report_return_all_should_be_approved_none_available_and_last_available_for_return() {
        final VolumeReportApprovalDTO volumeReportApprovalDTO;
        volumeReportApprovalDTO = generateVolumeReportApprovalDTO(null, VolumeReportStatus.APPROVED,
                VolumeReportStatus.APPROVED, VolumeReportStatus.APPROVED, VolumeReportStatus.APPROVED, VolumeReportStatus.APPROVED,
                VolumeReportStatus.APPROVED, VolumeReportStatus.APPROVED, VolumeReportStatus.APPROVED,
                VolumeReportStatus.APPROVED, VolumeReportStatus.APPROVED, true, false, true);

        assertApprovedStatuses(new boolean[] {true, true, true, true, true, true, true, true, true, true}, extractStateHolders(volumeReportApprovalDTO));
        assertAvailableStatuses(new boolean[] {false, false, false, false, false, false, false, false, false, false}, extractStateHolders(volumeReportApprovalDTO));
        assertHiddenStatuses(new boolean[] {false, false, false, false, false, false, false, false, false, false}, extractStateHolders(volumeReportApprovalDTO));
        assertReturnAvailableStatuses(new boolean[] {false, false, false, false, false, false, false, false, false, true}, extractStateHolders(volumeReportApprovalDTO));
    }

    @Test
    public void given_proper_flags_fields_should_be_hidden_correctly() {
        VolumeReportApprovalDTO volumeReportApprovalDTO = generateVolumeReportApprovalDTO(null, VolumeReportStatus.APPROVED,
                VolumeReportStatus.APPROVED, VolumeReportStatus.WAITING_REPORT, VolumeReportStatus.WAITING_REPORT, VolumeReportStatus.WAITING_REPORT,
                VolumeReportStatus.WAITING_REPORT, VolumeReportStatus.WAITING_REPORT, VolumeReportStatus.WAITING_REPORT,
                VolumeReportStatus.WAITING_REPORT, VolumeReportStatus.WAITING_REPORT, false, true, false);

        assertApprovedStatuses(new boolean[] {true, true, false, false, false, false, false, false, false, false}, extractStateHolders(volumeReportApprovalDTO));
        assertAvailableStatuses(new boolean[] {false, false, false, false, false, false, false, false, false, false}, extractStateHolders(volumeReportApprovalDTO));
        assertHiddenStatuses(new boolean[] {false, true, false, false, false, false, true, true, true, true}, extractStateHolders(volumeReportApprovalDTO));
        assertReturnAvailableStatuses(new boolean[] {true, false, false, false, false, false, false, false, false, false}, extractStateHolders(volumeReportApprovalDTO));
    }

    @Test
    public void test_to_string() {
        VolumeReportApprovalDTO volumeReportApprovalDTO = generateVolumeReportApprovalDTO(null, VolumeReportStatus.APPROVED,
                VolumeReportStatus.APPROVED, VolumeReportStatus.WAITING_REPORT, VolumeReportStatus.WAITING_REPORT, VolumeReportStatus.WAITING_REPORT,
                VolumeReportStatus.WAITING_REPORT, VolumeReportStatus.WAITING_REPORT, VolumeReportStatus.WAITING_REPORT,
                VolumeReportStatus.WAITING_REPORT, VolumeReportStatus.WAITING_REPORT, false, true, false);

        Assert.assertNotNull(volumeReportApprovalDTO.toString());
    }



    /*
    0 phase1
    1 portioning
    2 volumeHarvested
    3 volumeForUBS
    4 volumeBenefitted
    5 volumeApproved
    6 volumeComm1
    7 volumeComm2
    8 volumeComm3
    9 volumeForNext
     */
    private ApprovalStateHolder[] extractStateHolders(VolumeReportApprovalDTO dto) {
        return new ApprovalStateHolder[] { dto.getPhase1ApprovalState(), dto.getPortioningApprovalState(), dto.getVolumeHarvestedApprovalState(),
        dto.getVolumeForUBSApprovalState(), dto.getVolumeBenefittedApprovalState(), dto.getVolumeApprovedApprovalState(),
        dto.getVolumeCommercialized1ApprovalState(), dto.getVolumeCommercialized2ApprovalState(), dto.getVolumeCommercialized3ApprovalState(),
        dto.getVolumeForNextHarvestApprovalState()};
    }

    private void assertAvailableStatuses(boolean[] availables, ApprovalStateHolder[] approvalStates) {
        for(int i=0;i<approvalStates.length;i++) {
            Assert.assertEquals("Should (i) " + i + " be " + availables[i], availables[i], approvalStates[i].isAvailable());
        }
    }

    private void assertApprovedStatuses(boolean[] approved, ApprovalStateHolder[] approvalStates) {
        for(int i=0;i<approvalStates.length;i++) {
            Assert.assertEquals("Should (i) " + i+ " be " + approved[i], approved[i], approvalStates[i].isApproved());
        }
    }

    private void assertReturnAvailableStatuses(boolean[] returnAvailables, ApprovalStateHolder[] approvalStates) {
        for(int i=0;i<approvalStates.length;i++) {
            Assert.assertEquals("Should (i) " + i+ " be " + returnAvailables[i] + " was: " + approvalStates[i].toString() , returnAvailables[i], approvalStates[i].isReturnAvailable());
        }
    }
    
    private void assertHiddenStatuses(boolean[] hiddens, ApprovalStateHolder[] approvalStates) {
        for(int i=0;i<approvalStates.length;i++) {
            Assert.assertEquals("Should (i) " + i + " be " + hiddens[i], hiddens[i], approvalStates[i].isHidden());
        }
    }

    private VolumeReportApprovalDTO generateVolumeReportApprovalDTO(RevenueStatus revenueStatus, VolumeReportStatus phase1Status, VolumeReportStatus portioningStatus,
                                                                    VolumeReportStatus volumeHarvestedStatus, VolumeReportStatus volumeForUBSStatus, VolumeReportStatus volumeBenefittedStatus,
                                                                    VolumeReportStatus volumeApprovedStatus, VolumeReportStatus volumeCommercialized1Status,
                                                                    VolumeReportStatus volumeCommercialized2Status, VolumeReportStatus volumeCommercialized3Status, VolumeReportStatus volumeForNextHarvestStatus, boolean cooperative,
                                                                    boolean exclusivity, boolean chargeGermoplasm) {
        return new VolumeReportApprovalDTO(1L, 1L, revenueStatus, phase1Status, portioningStatus, volumeHarvestedStatus, volumeForUBSStatus, volumeBenefittedStatus, volumeApprovedStatus, volumeCommercialized1Status,
                volumeCommercialized2Status, volumeCommercialized3Status, volumeForNextHarvestStatus, "test", "12345678900", "1", "999.999.999-99", "test2", "98765432100", "2", "9999.9999-999", "harv",
                "obt", "cult", "C1", exclusivity, chargeGermoplasm,cooperative, 1l, true);
    }
}
