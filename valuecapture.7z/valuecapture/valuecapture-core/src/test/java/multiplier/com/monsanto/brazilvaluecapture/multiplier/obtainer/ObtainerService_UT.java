package com.monsanto.brazilvaluecapture.multiplier.obtainer;

import com.monsanto.brazilvaluecapture.core.customer.model.bean.Customer;
import com.monsanto.brazilvaluecapture.multiplier.obtainer.model.bean.Obtainer;
import com.monsanto.brazilvaluecapture.multiplier.obtainer.model.bean.ObtainerByMultiplier;
import com.monsanto.brazilvaluecapture.multiplier.obtainer.model.dao.ObtainerDAO;
import com.monsanto.brazilvaluecapture.multiplier.obtainer.service.ObtainerService;
import com.monsanto.brazilvaluecapture.multiplier.obtainer.service.impl.ObtainerServiceImpl;
import junit.framework.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.List;

import static org.mockito.Matchers.any;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class ObtainerService_UT {

    @Mock
    private Customer customer;

    @Mock
    private ObtainerDAO obtainerDAO;

    @InjectMocks
    private ObtainerService obtainerService = new ObtainerServiceImpl();

    @Before
    public void setUp() {
        List<Obtainer> obtainers = new ArrayList<Obtainer>();
        obtainers.add(Mockito.mock(Obtainer.class));
        when(obtainerDAO.selectDistinctObtainerByMultiplier(any(Long.class))).thenReturn(obtainers);
    }

    @Test
    public void selectDistinctObtainerByMultiplierTest() {
        List<Obtainer> list = obtainerService.selectDistinctObtainerByMultiplier(customer);

        Assert.assertNotNull(list);
        Assert.assertFalse(list.isEmpty());
    }

}
