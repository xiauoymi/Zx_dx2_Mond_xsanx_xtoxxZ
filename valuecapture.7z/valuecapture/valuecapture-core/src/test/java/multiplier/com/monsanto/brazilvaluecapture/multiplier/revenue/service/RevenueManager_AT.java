package com.monsanto.brazilvaluecapture.multiplier.revenue.service;

import com.dumbster.smtp.SimpleSmtpServer;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Company;
import com.monsanto.brazilvaluecapture.core.foundation.RandomTestData;
import com.monsanto.brazilvaluecapture.core.foundation.service.BusinessException;
import com.monsanto.brazilvaluecapture.core.foundation.test.AbstractServiceIntegrationTests;
import com.monsanto.brazilvaluecapture.core.foundation.test.dbunit.DbUnitHelper;
import com.monsanto.brazilvaluecapture.core.revenue.model.bean.Division;
import com.monsanto.brazilvaluecapture.core.revenue.model.bean.RevenueAccount;
import com.monsanto.brazilvaluecapture.core.revenue.model.dao.RevenueExtractFilter;
import com.monsanto.brazilvaluecapture.core.revenue.osb.OsbPaymentService;
import com.monsanto.brazilvaluecapture.core.revenue.osb.OsbRevenueService;
import com.monsanto.brazilvaluecapture.core.revenue.service.PaymentDataService;
import com.monsanto.brazilvaluecapture.core.revenue.service.RevenueManager;
import com.monsanto.brazilvaluecapture.core.revenue.service.RevenueService;
import com.monsanto.brazilvaluecapture.multiplier.revenue.model.bean.GermplasmRevenue;
import com.monsanto.brazilvaluecapture.multiplier.volumereport.model.bean.*;
import com.monsanto.brazilvaluecapture.multiplier.volumereport.service.VolumeReportRevenueService;
import com.monsanto.brazilvaluecapture.multiplier.volumereport.service.VolumeReportService;
import com.monsanto.brazilvaluecapture.multiplier.volumereport.service.impl.VolumeReportPhase1ReversalException;
import com.monsanto.brazilvaluecapture.multiplier.volumereport.service.impl.VolumeReportTestData;
import com.monsanto.brazilvaluecapture.osb.its.api.InfraException;
import com.monsanto.brazilvaluecapture.osb.its.api.OSBReturn;
import com.monsanto.brazilvaluecapture.osb.its.api.SapPayment;
import junit.framework.Assert;
import org.hibernate.criterion.Restrictions;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Matchers;
import org.mockito.Mockito;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.stubbing.Answer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class RevenueManager_AT extends AbstractServiceIntegrationTests {

    @Autowired
    private MultiplierBillableProvider multiplierBillableProvider;

    @Autowired
    private Germplasm1BillableProvider germplasm1BillableProvider;

    @Autowired
    private Germplasm2BillableProvider germplasm2BillableProvider;

    @Autowired
    private Germplasm3BillableProvider germplasm3BillableProvider;

    @Autowired
    @Qualifier("revenueManager")
    private RevenueManager revenueManager;

    @Autowired
    private RevenueService revenueService;

    @Autowired
    private VolumeReportRevenueService volumeReportRevenueService;

    @Autowired
    private VolumeReportService reportService;

    private SimpleSmtpServer serverSMTP;

//    @Before
//    public void start() {
//
//        serverSMTP = SimpleSmtpServer.start(getEnviromentSpecificSmtpPort());
//    }
//
//    @After
//    public void stop() {
//        if (serverSMTP != null) {
//            serverSMTP.stop();
//        }
//
//    }

    private void assertEmails(int emailCount) {
//		Iterator<SmtpMessage> receivedEmail = serverSMTP.getReceivedEmail();
//        int counter=0;
//        while(receivedEmail.hasNext()) {
//            receivedEmail.next();
//            counter++;
//        }
//        Assert.assertEquals("Should have found " + emailCount + " messages", emailCount, counter);
    }

    @SuppressWarnings("unchecked")
    @Before
    public void init() throws BusinessException, InfraException {
        OsbRevenueService osbService = mock(OsbRevenueService.class);
        when(
                osbService.bill(Matchers.any(com.monsanto.brazilvaluecapture.osb.its.api.param.DocumentType.class),
                        Matchers.any(String.class), Matchers.any(Boolean.class), Matchers.any(Date.class), Matchers.any(List.class),
                        Matchers.any(List.class), Matchers.any(String.class))).thenAnswer(new Answer<OSBReturn>() {
            public OSBReturn answer(InvocationOnMock invocation) {
                OSBReturn result = new OSBReturn();
                result.setDocumentNumber(RandomTestData.createRandomLong().toString());
                result.setSaleOrderNmber(RandomTestData.createRandomLong().toString());
                return result;
            }
        });

        revenueManager.setOsbService(osbService);
    }

    @Test
    public void bill_multiplier() throws BusinessException, InfraException {
        DbUnitHelper.setup("classpath:data/multiplier/basic-fixture.xml",
                "classpath:data/multiplier/revenue-multiplier-dataset.xml");

        Company company = getCompanyBy(900000001L);

        List<VolumeReportDetail> reportDetails = volumeReportRevenueService.selectAllPendingReportDetailsToMultiplyRevenues(company);
        Assert.assertTrue("At least one detail needed to bill.", reportDetails.size() > 0);

        revenueManager.bill(multiplierBillableProvider, company);

        RevenueExtractFilter filter = RevenueExtractFilter.getInstance();
        List<RevenueAccount> result = revenueService.getByFilter(filter);
        Assert.assertEquals("One revenue must be created.", 1, result.size());
        Assert.assertNull(result.get(0).getExpirationDate());

        List<VolumeReportDetail> reportDetails2 = volumeReportRevenueService.selectAllPendingReportDetailsToMultiplyRevenues(company);
        Assert.assertTrue("No detail must be ready to bill now.", reportDetails2.size() == 0);
    }


    private Company getCompanyBy(Long companyId) {
        return (Company) getSession().get(Company.class, companyId);
    }

    @Test
    public void bill_germplasm1_and_pay() throws BusinessException, InfraException {
        DbUnitHelper.setup("classpath:data/multiplier/basic-fixture.xml",
                "classpath:data/multiplier/revenue-multiplier-dataset.xml");

        Company company = getCompanyBy(900000001L);

        // Mock of the Division
        List<Division> listDivisions = new ArrayList<Division>();
        Division division = new Division(1L, null, company, 9282L, "BIOTECNOLOGIA", Boolean.TRUE);
        listDivisions.add(division);

        List<GermplasmRevenue> reportDetails = volumeReportRevenueService.selectAllPendingReportToGermplasmRevenues(company, 1);
        Assert.assertTrue("At least one detail needed to bill.", reportDetails.size() > 0);

        revenueManager.bill(germplasm1BillableProvider, company);

        RevenueExtractFilter filter = RevenueExtractFilter.getInstance();
        List<RevenueAccount> result = revenueService.getByFilter(filter);
        Assert.assertEquals("One revenue must be created.", 1, result.size());
        Assert.assertNotNull("Expiration date is mandatory for germplasm", result.get(0).getExpirationDate());

        List<GermplasmRevenue> reportDetails2 = volumeReportRevenueService.selectAllPendingReportToGermplasmRevenues(company, 1);
        Assert.assertTrue("No detail must be ready to bill now.", reportDetails2.size() == 0);


        PaymentDataService paymentDataService = Mockito.mock(PaymentDataService.class);
        revenueManager.setPaymentDataService(paymentDataService);
        Mockito.when(paymentDataService.loadAllDivisionByCompany((Company) Mockito.anyObject(), Mockito.anyBoolean()))
                .thenReturn(listDivisions);

        // Mock of the SapPayments
        OsbPaymentService paymentService = Mockito.mock(OsbPaymentService.class);
        revenueManager.setPaymentService(paymentService);
        List<SapPayment> listPayments = new ArrayList<SapPayment>();
        SapPayment sapPayment = new SapPayment("4168", result.get(0).getDocumentNumber(), "2600000458", "1800000027", "2006", "2008");
        listPayments.add(sapPayment);
        Mockito.when(paymentService.selectPayments(division.getDivisionCode().toString())).thenReturn(listPayments);

        revenueManager.callOsbAndUpdatePayment(germplasm1BillableProvider, company);

        result = revenueService.getByFilter(filter);
        Assert.assertEquals("One revenue must be created.", 1, result.size());
        Assert.assertEquals("Paid revenues must have docFI.", result.get(0).getSapDocumentFiNumber(), "1800000027");
    }

    @Test
    public void bill_germplasm2_and_pay() throws BusinessException, InfraException {
        DbUnitHelper.setup("classpath:data/multiplier/basic-fixture.xml",
                "classpath:data/multiplier/revenue-multiplier-dataset.xml");

        Company company = getCompanyBy(900000001L);

        // Mock of the Division
        List<Division> listDivisions = new ArrayList<Division>();
        Division division = new Division(1L, null, company, 9282L, "BIOTECNOLOGIA", Boolean.TRUE);
        listDivisions.add(division);

        List<GermplasmRevenue> reportDetails = volumeReportRevenueService.selectAllPendingReportToGermplasmRevenues(company, 2);
        Assert.assertTrue("At least one detail needed to bill.", reportDetails.size() > 0);

        revenueManager.bill(germplasm2BillableProvider, company);

        RevenueExtractFilter filter = RevenueExtractFilter.getInstance();
        List<RevenueAccount> result = revenueService.getByFilter(filter);
        Assert.assertEquals("One revenue must be created.", 1, result.size());
        Assert.assertNotNull("Expiration date is mandatory for germplasm", result.get(0).getExpirationDate());

        List<GermplasmRevenue> reportDetails2 = volumeReportRevenueService.selectAllPendingReportToGermplasmRevenues(company, 2);
        Assert.assertTrue("No detail must be ready to bill now.", reportDetails2.size() == 0);


        PaymentDataService paymentDataService = Mockito.mock(PaymentDataService.class);
        revenueManager.setPaymentDataService(paymentDataService);
        Mockito.when(paymentDataService.loadAllDivisionByCompany((Company) Mockito.anyObject(), Mockito.anyBoolean()))
                .thenReturn(listDivisions);

        // Mock of the SapPayments
        OsbPaymentService paymentService = Mockito.mock(OsbPaymentService.class);
        revenueManager.setPaymentService(paymentService);
        List<SapPayment> listPayments = new ArrayList<SapPayment>();
        SapPayment sapPayment = new SapPayment("4168", result.get(0).getDocumentNumber(), "2600000458", "1800000027", "2006", "2008");
        listPayments.add(sapPayment);
        Mockito.when(paymentService.selectPayments(division.getDivisionCode().toString())).thenReturn(listPayments);

        revenueManager.callOsbAndUpdatePayment(germplasm2BillableProvider, company);

        result = revenueService.getByFilter(filter);
        Assert.assertEquals("One revenue must be created.", 1, result.size());
        Assert.assertEquals("Paid revenues must have docFI.", result.get(0).getSapDocumentFiNumber(), "1800000027");
    }

    @Test
    public void bill_germplasm3_and_pay() throws BusinessException, InfraException {
        DbUnitHelper.setup("classpath:data/multiplier/basic-fixture.xml",
                "classpath:data/multiplier/revenue-multiplier-dataset.xml");

        Company company = getCompanyBy(900000001L);

        // Mock of the Division
        List<Division> listDivisions = new ArrayList<Division>();
        Division division = new Division(1L, null, company, 9282L, "BIOTECNOLOGIA", Boolean.TRUE);
        listDivisions.add(division);

        List<GermplasmRevenue> reportDetails = volumeReportRevenueService.selectAllPendingReportToGermplasmRevenues(company, 3);
        Assert.assertTrue("At least one detail needed to bill.", reportDetails.size() > 0);

        revenueManager.bill(germplasm3BillableProvider, company);

        RevenueExtractFilter filter = RevenueExtractFilter.getInstance();
        List<RevenueAccount> result = revenueService.getByFilter(filter);
        Assert.assertEquals("One revenue must be created.", 1, result.size());
        Assert.assertNotNull("Expiration date is mandatory for germplasm", result.get(0).getExpirationDate());

        List<GermplasmRevenue> reportDetails2 = volumeReportRevenueService.selectAllPendingReportToGermplasmRevenues(company, 3);
        Assert.assertTrue("No detail must be ready to bill now.", reportDetails2.size() == 0);


        PaymentDataService paymentDataService = Mockito.mock(PaymentDataService.class);
        revenueManager.setPaymentDataService(paymentDataService);
        Mockito.when(paymentDataService.loadAllDivisionByCompany((Company) Mockito.anyObject(), Mockito.anyBoolean()))
                .thenReturn(listDivisions);

        // Mock of the SapPayments
        OsbPaymentService paymentService = Mockito.mock(OsbPaymentService.class);
        revenueManager.setPaymentService(paymentService);
        List<SapPayment> listPayments = new ArrayList<SapPayment>();
        SapPayment sapPayment = new SapPayment("4168", result.get(0).getDocumentNumber(), "2600000458", "1800000027", "2006", "2008");
        listPayments.add(sapPayment);
        Mockito.when(paymentService.selectPayments(division.getDivisionCode().toString())).thenReturn(listPayments);

        revenueManager.callOsbAndUpdatePayment(germplasm3BillableProvider, company);

        result = revenueService.getByFilter(filter);
        Assert.assertEquals("One revenue must be created.", 1, result.size());
        Assert.assertEquals("Paid revenues must have docFI.", result.get(0).getSapDocumentFiNumber(), "1800000027");
    }

    @Test
    public void bill_multiplier_and_pay() throws BusinessException, InfraException {
        DbUnitHelper.setup("classpath:data/multiplier/basic-fixture.xml",
                "classpath:data/multiplier/revenue-multiplier-dataset.xml");


        Company company = getCompanyBy(900000001L);

        // Mock of the Division
        List<Division> listDivisions = new ArrayList<Division>();
        Division division = new Division(1L, null, company, 9282L, "BIOTECNOLOGIA", Boolean.TRUE);
        listDivisions.add(division);

        List<VolumeReportDetail> reportDetails = volumeReportRevenueService.selectAllPendingReportDetailsToMultiplyRevenues(company);
        Assert.assertTrue("At least one detail needed to bill.", reportDetails.size() > 0);

        revenueManager.bill(multiplierBillableProvider, company);

        RevenueExtractFilter filter = RevenueExtractFilter.getInstance();
        List<RevenueAccount> result = revenueService.getByFilter(filter);
        Assert.assertEquals("One revenue must be created.", 1, result.size());
        Assert.assertNull("Expiration date must be null to multiplier", result.get(0).getExpirationDate());

        List<VolumeReportDetail> reportDetails2 = volumeReportRevenueService.selectAllPendingReportDetailsToMultiplyRevenues(company);
        Assert.assertTrue("No detail must be ready to bill now.", reportDetails2.size() == 0);


        PaymentDataService paymentDataService = Mockito.mock(PaymentDataService.class);
        revenueManager.setPaymentDataService(paymentDataService);
        Mockito.when(paymentDataService.loadAllDivisionByCompany((Company) Mockito.anyObject(), Mockito.anyBoolean()))
                .thenReturn(listDivisions);

        // Mock of the SapPayments
        OsbPaymentService paymentService = Mockito.mock(OsbPaymentService.class);
        revenueManager.setPaymentService(paymentService);
        List<SapPayment> listPayments = new ArrayList<SapPayment>();
        SapPayment sapPayment = new SapPayment("4168", result.get(0).getDocumentNumber(), "2600000458", "1800000027", "2006", "2008");
        listPayments.add(sapPayment);
        Mockito.when(paymentService.selectPayments(division.getDivisionCode().toString())).thenReturn(listPayments);

        revenueManager.callOsbAndUpdatePayment(multiplierBillableProvider, company);

        result = revenueService.getByFilter(filter);
        Assert.assertEquals("One revenue must be created.", 1, result.size());
        Assert.assertEquals("Paid revenues must have docFI.", result.get(0).getSapDocumentFiNumber(), "1800000027");
    }

    @Test
    public void bill_multiplier_and_germplasm_and_pay() throws BusinessException, InfraException {
        DbUnitHelper.setup("classpath:data/multiplier/basic-fixture.xml",
                "classpath:data/multiplier/revenue-multiplier-dataset.xml");

        Company company = getCompanyBy(900000001L);

        // Mock of the Division
        List<Division> listDivisions = new ArrayList<Division>();
        Division division = new Division(1L, null, company, 9282L, "BIOTECNOLOGIA", Boolean.TRUE);
        listDivisions.add(division);

        List<VolumeReportDetail> reportDetails = volumeReportRevenueService.selectAllPendingReportDetailsToMultiplyRevenues(company);
        Assert.assertTrue("At least one detail needed to bill.", reportDetails.size() > 0);
        List<GermplasmRevenue> germplasmRevenues = volumeReportRevenueService.selectAllPendingReportToGermplasmRevenues(company, 1);
        Assert.assertTrue("At least one detail needed to bill.", germplasmRevenues.size() > 0);

        revenueManager.bill(multiplierBillableProvider, company);
        revenueManager.bill(germplasm1BillableProvider, company);

        RevenueExtractFilter filter = RevenueExtractFilter.getInstance();
        List<RevenueAccount> result = revenueService.getByFilter(filter);
        Assert.assertEquals("Two revenue must be created.", 2, result.size());

        reportDetails = volumeReportRevenueService.selectAllPendingReportDetailsToMultiplyRevenues(company);
        Assert.assertTrue("No detail must be ready to bill now.", reportDetails.size() == 0);
        germplasmRevenues = volumeReportRevenueService.selectAllPendingReportToGermplasmRevenues(company, 1);
        Assert.assertTrue("No detail must be ready to bill now.", germplasmRevenues.size() == 0);

        PaymentDataService paymentDataService = Mockito.mock(PaymentDataService.class);
        revenueManager.setPaymentDataService(paymentDataService);
        Mockito.when(paymentDataService.loadAllDivisionByCompany((Company) Mockito.anyObject(), Mockito.anyBoolean()))
                .thenReturn(listDivisions);

        // Mock of the SapPayments
        OsbPaymentService paymentService = Mockito.mock(OsbPaymentService.class);
        revenueManager.setPaymentService(paymentService);
        List<SapPayment> listPayments = new ArrayList<SapPayment>();
        SapPayment sapPayment1 = new SapPayment("4168", "00" + result.get(0).getDocumentNumber(), "2600000458", "1800000027", "2006", "2008");
        SapPayment sapPayment2 = new SapPayment("4168", "0" + result.get(1).getDocumentNumber(), "2600000458", "1800000028", "2006", "2008");
        listPayments.add(sapPayment1);
        listPayments.add(sapPayment2);
        Mockito.when(paymentService.selectPayments(division.getDivisionCode().toString())).thenReturn(listPayments);

        revenueManager.callOsbAndUpdatePayment(multiplierBillableProvider, company);
        revenueManager.callOsbAndUpdatePayment(germplasm1BillableProvider, company);

        result = revenueService.getByFilter(filter);
        Assert.assertEquals("Two revenue must be created.", 2, result.size());
        Assert.assertEquals("Paid revenues must have docFI.", "1800000027", result.get(0).getSapDocumentFiNumber());
        Assert.assertEquals("Paid revenues must have docFI.", "1800000028", result.get(1).getSapDocumentFiNumber());
    }

    @SuppressWarnings("unchecked")
    @Test
    public void given_multiplierBill_when_i_search_details_by_revenueAccount_should_return_volumeReportDetails_that_were_billed() throws BusinessException, InfraException {
        DbUnitHelper.setup("classpath:data/multiplier/basic-fixture.xml",
                "classpath:data/multiplier/revenue-multiplier-dataset.xml");

        Company company = getCompanyBy(900000001L);

        // Mock of the Division
        List<Division> listDivisions = new ArrayList<Division>();
        Division division = new Division(1L, null, company, 9282L, "BIOTECNOLOGIA", Boolean.TRUE);
        listDivisions.add(division);

        List<VolumeReportDetail> reportDetails = volumeReportRevenueService.selectAllPendingReportDetailsToMultiplyRevenues(company);
        Assert.assertTrue("At least one detail needed to bill.", reportDetails.size() > 0);

        revenueManager.bill(multiplierBillableProvider, company);

        if (!getAssumptionTest().isEnvironmentWithSQLANSI()) {
            List<VolumeReportHeader> headers = getSession().createCriteria(VolumeReportHeader.class).list();
            for (VolumeReportHeader header : headers) {
                VolumeReportHeader reportHeader = reportService.selectVolumeReport(header.getId());
                Collection<VolumeReportDetailView> details = VolumeReportTestData.createVolumeReportDetailViewsFrom(reportHeader);
                for (VolumeReportDetailView detailView : details) {
                    saveAndFlush(detailView);
                }
            }
        }

        RevenueExtractFilter filter = RevenueExtractFilter.getInstance();
        List<RevenueAccount> result = revenueService.getByFilter(filter);
        Assert.assertEquals("One revenue must be created.", 1, result.size());
        Assert.assertNull("Expiration date must be null to multiplier", result.get(0).getExpirationDate());

        List<VolumeReportDetailRevenueDTO> detailDTOs = volumeReportRevenueService.selectAllVolumeReportDetailRevenueDTOByRevenueAccount(result.get(0));

        Assert.assertFalse("DTO list should not be empty", detailDTOs.isEmpty());

        for (VolumeReportDetailRevenueDTO dto : detailDTOs) {
            Assert.assertNotNull("DTO should have entered area value", dto.getEnteredArea());
            Assert.assertNotNull("DTO should have a customer", dto.getCustomer());
            Assert.assertNotNull("DTO should have a harvest", dto.getHarvest());
        }
    }

    @SuppressWarnings("unchecked")
    @Test(expected = VolumeReportPhase1ReversalException.class)
    public void given_revenueAccount_multiplierType_when_reversal_and_has_one_enteredArea_unable_to_reversal_should_throw_exception() throws BusinessException, InfraException {
        DbUnitHelper.setup("classpath:data/multiplier/basic-fixture.xml",
                "classpath:data/multiplier/revenue-multiplier-dataset.xml");

        Company company = getCompanyBy(900000001L);

        // Mock of the Division
        List<Division> listDivisions = new ArrayList<Division>();
        Division division = new Division(1L, null, company, 9282L, "BIOTECNOLOGIA", Boolean.TRUE);
        listDivisions.add(division);

        List<VolumeReportDetail> reportDetails = volumeReportRevenueService.selectAllPendingReportDetailsToMultiplyRevenues(company);
        Assert.assertTrue("At least one detail needed to bill.", reportDetails.size() > 0);

        revenueManager.bill(multiplierBillableProvider, company);

        if (!getAssumptionTest().isEnvironmentWithSQLANSI()) {
            List<VolumeReportHeader> headers = getSession().createCriteria(VolumeReportHeader.class).list();
            for (VolumeReportHeader header : headers) {
                VolumeReportHeader reportHeader = reportService.selectVolumeReport(header.getId());
                Collection<VolumeReportDetailView> details = VolumeReportTestData.createVolumeReportDetailViewsFrom(reportHeader);
                for (VolumeReportDetailView detailView : details) {
                    saveAndFlush(detailView);
                }
            }
        }

        RevenueExtractFilter filter = RevenueExtractFilter.getInstance();
        List<RevenueAccount> result = revenueService.getByFilter(filter);
        Assert.assertEquals("One revenue must be created.", 1, result.size());
        Assert.assertNull("Expiration date must be null to multiplier", result.get(0).getExpirationDate());
        revenueService.reversal(multiplierBillableProvider, result.get(0), "reversal code", "reversal reason", "vrodrigues", null);
    }

    @SuppressWarnings("unchecked")
    @Test
    public void given_revenueAccount_multiplierType_when_reversal_with_all_volumeReportDetails_available_for_reversal_should_reverse_successfully() throws BusinessException, InfraException {
        DbUnitHelper.setup("classpath:data/multiplier/basic-fixture.xml",
                "classpath:data/multiplier/multiplier-revenue-reversal-dataset.xml");

        Company company = getCompanyBy(900000001L);

        // Mock of the Division
        List<Division> listDivisions = new ArrayList<Division>();
        Division division = new Division(1L, null, company, 9282L, "BIOTECNOLOGIA", Boolean.TRUE);
        listDivisions.add(division);

        List<VolumeReportDetail> reportDetails = volumeReportRevenueService.selectAllPendingReportDetailsToMultiplyRevenues(company);
        Assert.assertEquals("Should have 3 details", 3, reportDetails.size());

        for (VolumeReportDetail detail : reportDetails) {
            Assert.assertEquals("Field should be in status approved", VolumeReportStatus.WAITING_BILLING, detail.getEnteredArea().getStatus());
        }

        revenueManager.bill(multiplierBillableProvider, company);

        if (!getAssumptionTest().isEnvironmentWithSQLANSI()) {
            List<VolumeReportHeader> headers = getSession().createCriteria(VolumeReportHeader.class).list();
            for (VolumeReportHeader header : headers) {
                VolumeReportHeader reportHeader = reportService.selectVolumeReport(header.getId());
                Collection<VolumeReportDetailView> details = VolumeReportTestData.createVolumeReportDetailViewsFrom(reportHeader);
                for (VolumeReportDetailView detailView : details) {
                    saveAndFlush(detailView);
                }
            }
        }

        RevenueExtractFilter filter = RevenueExtractFilter.getInstance();
        List<RevenueAccount> result = revenueService.getByFilter(filter);
        Assert.assertEquals("One revenue must be created.", 1, result.size());
        Assert.assertNull("Expiration date must be null to multiplier", result.get(0).getExpirationDate());

        RevenueAccount revenueAccount = result.get(0);
        List<VolumeReportDetail> details = getSession()
                .createCriteria(VolumeReportDetail.class)
                .add(Restrictions.eq("revenueAccountId", revenueAccount.getId()))
                .list();

        Assert.assertEquals("Should have 3 details", 3, details.size());

        for (VolumeReportDetail detail : details) {
            Assert.assertEquals("Field should be in status billed", VolumeReportStatus.BILLED, detail.getEnteredArea().getStatus());
        }

        revenueService.reversal(multiplierBillableProvider, revenueAccount, "reversal code", "reversal reason", "vrodrigues", null);

        details = getSession()
                .createCriteria(VolumeReportDetail.class)
                .add(Restrictions.eq("revenueAccountId", revenueAccount.getId()))
                .list();

        Assert.assertEquals("Should have 3 details", 3, details.size());

        for (VolumeReportDetail detail : details) {
            Assert.assertEquals("Field should be in status billed", VolumeReportStatus.RETURNED, detail.getEnteredArea().getStatus());
        }

    }
}
