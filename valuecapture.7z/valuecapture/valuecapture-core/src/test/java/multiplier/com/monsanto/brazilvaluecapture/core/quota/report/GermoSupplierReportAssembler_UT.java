package com.monsanto.brazilvaluecapture.core.quota.report;

import com.monsanto.brazilvaluecapture.core.base.model.bean.Document;
import com.monsanto.brazilvaluecapture.core.base.model.bean.DocumentType;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Customer;
import com.monsanto.brazilvaluecapture.core.foundation.service.ExpectedSingleEntityException;
import com.monsanto.brazilvaluecapture.core.grower.model.bean.Grower;
import com.monsanto.brazilvaluecapture.core.quota.model.bean.QuotaFY;
import com.monsanto.brazilvaluecapture.core.quota.model.bean.QuotaFYDTO;
import com.monsanto.brazilvaluecapture.core.regionalization.VCCountry;
import com.monsanto.brazilvaluecapture.core.regionalization.VCRegion;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.LinkedList;
import java.util.List;
import java.util.ResourceBundle;
import java.io.ByteArrayOutputStream;

import static org.fest.reflect.core.Reflection.field;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.when;

/**
 * Created by IntelliJ IDEA.
 * User: CGLLLO
 * Date: 03/09/13
 * Time: 16:18
 */
public class GermoSupplierReportAssembler_UT {

    private List<QuotaFYDTO> dataList;
    private QuotaFY quotaFY;
    private QuotaFYDTO quotaFYDTO;
    private Grower grower;
    private Document document;
    private Customer customer;

    private ResourceBundle resourceBundle;

    private GermoSupplierReportAssembler germoSupplierReportAssembler;

    @Before
    public void setUp() throws Exception {
        this.quotaFYDTO = createQuotaFYDTO();
        this.dataList = new LinkedList<QuotaFYDTO>();
        this.dataList.add(quotaFYDTO);
        resourceBundle = ResourceBundle.getBundle("language", VCCountry.ARGENTINA.getLocale());
        this.germoSupplierReportAssembler = new GermoSupplierReportAssembler(dataList, resourceBundle);
    }

    private QuotaFYDTO createQuotaFYDTO() {
        this.document = new Document();
        this.document.setValue("");
        this.grower = new Grower();
        this.grower.setDocument(document);
        this.customer = new Customer();
        field("document").ofType(Document.class).in(this.customer).set(this.document);
        this.quotaFY = new QuotaFY();
        this.quotaFY.setGrower(grower);
        this.quotaFY.setCustomer(customer);
        return new QuotaFYDTO(quotaFY);
    }

    @Test
    public void given_quotaFYDTO_when_build_should_create_stream() throws Exception {
        // @Given

        // @When
        ByteArrayOutputStream result = this.germoSupplierReportAssembler.build();
        // @Should
        assertNotNull(result);
    }
}
