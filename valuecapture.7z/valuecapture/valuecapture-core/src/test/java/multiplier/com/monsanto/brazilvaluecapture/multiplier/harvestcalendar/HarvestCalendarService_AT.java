package com.monsanto.brazilvaluecapture.multiplier.harvestcalendar;

import java.util.Date;

import junit.framework.Assert;

import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.monsanto.brazilvaluecapture.core.base.SystemTestFixture;
import com.monsanto.brazilvaluecapture.core.foundation.test.AbstractServiceIntegrationTests;
import com.monsanto.brazilvaluecapture.multiplier.harvestcalendar.model.bean.HarvestCalendar;
import com.monsanto.brazilvaluecapture.multiplier.harvestcalendar.model.dao.HarvestCalendarFilter;
import com.monsanto.brazilvaluecapture.multiplier.harvestcalendar.service.HarvestCalendarService;
import com.monsanto.brazilvaluecapture.seedsale.harvest.HarvestTestData;
import com.monsanto.brazilvaluecapture.seedsale.harvest.model.bean.Harvest;

public class HarvestCalendarService_AT extends AbstractServiceIntegrationTests {

    @Autowired
    private HarvestCalendarService harvestCalendarService;
    
    private Harvest harvest;
    
    private HarvestCalendar harvestCalendar;
    
    @Before
    public void setup() {
        systemTestFixture = new SystemTestFixture(this);
        
        harvest = HarvestTestData.createABrazilianHarvest();
        
        saveAndFlush(harvest.getCompany().getCountry());
        saveAndFlush(harvest.getCompany());
        saveAndFlush(harvest.getCrop());
        saveAndFlush(harvest.getOperationalYear());
        saveAndFlush(harvest);
        
        harvestCalendar = new HarvestCalendar(harvest);
    }

    @Test
    public void test_insert() {
        Date date = new Date();
        
        harvestCalendar.setApprovedVolEnd(date);
        
        harvestCalendarService.save(harvestCalendar);
        
        HarvestCalendarFilter filter = HarvestCalendarFilter.getInstance().addHarvest(harvest);
        
        HarvestCalendar hc = harvestCalendarService.selectByFilter(filter);
        
        Assert.assertEquals("Date does not match", date, hc.getApprovedVolEnd());
    }
    
    @Test
    public void test_null_harvest_criteria() {
        Date date = new Date();
        
        harvestCalendar.setApprovedVolEnd(date);
        
        harvestCalendarService.save(harvestCalendar);
        
        HarvestCalendarFilter filter = HarvestCalendarFilter.getInstance().addHarvest(harvest);
        
        int criterias = filter.countCriterias();
        
        filter = filter.addHarvest(null);
        
        Assert.assertEquals("Criterias does not match", criterias, filter.countCriterias());
    }    
    
    @Test
    public void test_save_without_dates() {
        Date date = new Date();
        
        harvestCalendar.setApprovedVolStart(date);
        harvestCalendar.setApprovedVolEnd(date);
        
        harvestCalendarService.save(harvestCalendar);
        
        HarvestCalendarFilter filter = HarvestCalendarFilter.getInstance().addHarvest(harvest);
        
        HarvestCalendar hc = harvestCalendarService.selectByFilter(filter);
        
        Assert.assertEquals("Date does not match", date, hc.getApprovedVolEnd());
        
        harvestCalendar.setApprovedVolStart(null);
        harvestCalendar.setApprovedVolEnd(null);
        
        harvestCalendarService.save(harvestCalendar);
        
        HarvestCalendar hcNull = harvestCalendarService.selectByFilter(filter);
        
        Assert.assertNull("HarvestCalendar should be null", hcNull);
        
    }
    
    @Test
    public void test_save_with_firs_period_inscribed_area() {
        Date date = new Date();
        
        harvestCalendar.setInscribedAreaEnd(date);
        harvestCalendar.setInscribedAreaStart(date);
        
        harvestCalendarService.save(harvestCalendar);
        
        HarvestCalendarFilter filter = HarvestCalendarFilter.getInstance().addHarvest(harvest);
        
        HarvestCalendar hc = harvestCalendarService.selectByFilter(filter);
        
        Assert.assertEquals("Date does not match", date, hc.getInscribedAreaEnd());
        Assert.assertEquals("Date does not match", date, hc.getInscribedAreaStart());
        
    }
    
    @Test
    public void test_save_with_firs_period_own_seed_vol_used() {
        Date date = new Date();
        
        harvestCalendar.setOwnSeedVolUsedEnd(date);
        harvestCalendar.setOwnSeedVolUsedStart(date);
        
        harvestCalendarService.save(harvestCalendar);
        
        HarvestCalendarFilter filter = HarvestCalendarFilter.getInstance().addHarvest(harvest);
        
        HarvestCalendar hc = harvestCalendarService.selectByFilter(filter);
        
        Assert.assertEquals("Date does not match", date, hc.getOwnSeedVolUsedEnd());
        Assert.assertEquals("Date does not match", date, hc.getOwnSeedVolUsedStart());
        
    }
    
    @Test
    public void test_save_with_firs_period_matrix_seed_vol_owned() {
        Date date = new Date();
        
        harvestCalendar.setMatrixSeedVolOwnedEnd(date);
        harvestCalendar.setMatrixSeedVolOwnedStart(date);
        
        harvestCalendarService.save(harvestCalendar);
        
        HarvestCalendarFilter filter = HarvestCalendarFilter.getInstance().addHarvest(harvest);
        
        HarvestCalendar hc = harvestCalendarService.selectByFilter(filter);
        
        Assert.assertEquals("Date does not match", date, hc.getMatrixSeedVolOwnedEnd());
        Assert.assertEquals("Date does not match", date, hc.getMatrixSeedVolOwnedStart());
        
    }
    
    @Test
    public void test_save_with_second_period_harvest_vol() {
        Date date = new Date();
        
        harvestCalendar.setHarvestVolEnd(date);
        harvestCalendar.setHarvestVolStart(date);
        
        harvestCalendarService.save(harvestCalendar);
        
        HarvestCalendarFilter filter = HarvestCalendarFilter.getInstance().addHarvest(harvest);
        
        HarvestCalendar hc = harvestCalendarService.selectByFilter(filter);
        
        Assert.assertEquals("Date does not match", date, hc.getHarvestVolEnd());
        Assert.assertEquals("Date does not match", date, hc.getHarvestVolStart());
        
    }
    
    @Test
    public void test_save_with_second_period_ubsdest_vol() {
        Date date = new Date();
        
        harvestCalendar.setUbsDestVolEnd(date);
        harvestCalendar.setUbsDestVolStart(date);
        
        harvestCalendarService.save(harvestCalendar);
        
        HarvestCalendarFilter filter = HarvestCalendarFilter.getInstance().addHarvest(harvest);
        
        HarvestCalendar hc = harvestCalendarService.selectByFilter(filter);
        
        Assert.assertEquals("Date does not match", date, hc.getUbsDestVolEnd());
        Assert.assertEquals("Date does not match", date, hc.getUbsDestVolStart());
        
    }
    
    @Test
    public void test_save_with_second_period_harvest_discarded_area() {
        Date date = new Date();
        
        harvestCalendar.setHarvestDiscardedAreaEnd(date);
        harvestCalendar.setHarvestDiscardedAreaStart(date);
        
        harvestCalendarService.save(harvestCalendar);
        
        HarvestCalendarFilter filter = HarvestCalendarFilter.getInstance().addHarvest(harvest);
        
        HarvestCalendar hc = harvestCalendarService.selectByFilter(filter);
        
        Assert.assertEquals("Date does not match", date, hc.getHarvestDiscardedAreaEnd());
        Assert.assertEquals("Date does not match", date, hc.getHarvestDiscardedAreaStart());
        
    }
    
    @Test
    public void test_save_with_third_period() {
        Date date = new Date();
        
        harvestCalendar.setBenefittedVolEnd(date);
        harvestCalendar.setBenefittedVolStart(date);
        
        
        harvestCalendarService.save(harvestCalendar);
        
        HarvestCalendarFilter filter = HarvestCalendarFilter.getInstance().addHarvest(harvest);
        
        HarvestCalendar hc = harvestCalendarService.selectByFilter(filter);
        
        Assert.assertEquals("Date does not match", date, hc.getBenefittedVolEnd());
        Assert.assertEquals("Date does not match", date, hc.getBenefittedVolStart());
        
    }
    
    @Test
    public void test_save_with_sixth_period() {
        Date date = new Date();
        
        harvestCalendar.setNextHarvestVolEnd(date);
        harvestCalendar.setNextHarvestVolStart(date);
        
        
        harvestCalendarService.save(harvestCalendar);
        
        HarvestCalendarFilter filter = HarvestCalendarFilter.getInstance().addHarvest(harvest);
        
        HarvestCalendar hc = harvestCalendarService.selectByFilter(filter);
        
        Assert.assertEquals("Date does not match", date, hc.getNextHarvestVolEnd());
        Assert.assertEquals("Date does not match", date, hc.getNextHarvestVolStart());
        
    }
    
    @Test
    public void test_save_with_fifth_period_first_comm_ld_vol_end() {
        Date date = new Date();
        
        harvestCalendar.setFirstCommldVolEnd(date);
        harvestCalendar.setFirstCommldVolStart(date);
        
        harvestCalendarService.save(harvestCalendar);
        
        HarvestCalendarFilter filter = HarvestCalendarFilter.getInstance().addHarvest(harvest);
        
        HarvestCalendar hc = harvestCalendarService.selectByFilter(filter);
        
        Assert.assertEquals("Date does not match", date, hc.getFirstCommldVolEnd());
        Assert.assertEquals("Date does not match", date, hc.getFirstCommldVolStart());
        
    }
    
    @Test
    public void test_save_with_fifth_period_second_comm_ld_vol_end() {
        Date date = new Date();
        
        harvestCalendar.setSecondCommldVolEnd(date);
        harvestCalendar.setSecondCommldVolStart(date);
        
        harvestCalendarService.save(harvestCalendar);
        
        HarvestCalendarFilter filter = HarvestCalendarFilter.getInstance().addHarvest(harvest);
        
        HarvestCalendar hc = harvestCalendarService.selectByFilter(filter);
        
        Assert.assertEquals("Date does not match", date, hc.getSecondCommldVolEnd());
        Assert.assertEquals("Date does not match", date, hc.getSecondCommldVolStart());
        
    }
    
    @Test
    public void test_save_with_fifth_period_third_comm_ld_vol_end() {
        Date date = new Date();
        
        harvestCalendar.setThirdCommldVolEnd(date);
        harvestCalendar.setThirdCommldVolStart(date);
        
        harvestCalendarService.save(harvestCalendar);
        
        HarvestCalendarFilter filter = HarvestCalendarFilter.getInstance().addHarvest(harvest);
        
        HarvestCalendar hc = harvestCalendarService.selectByFilter(filter);
        
        Assert.assertEquals("Date does not match", date, hc.getThirdCommldVolEnd());
        Assert.assertEquals("Date does not match", date, hc.getThirdCommldVolStart());
        
    }


    
}
