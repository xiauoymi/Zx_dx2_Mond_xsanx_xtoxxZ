package com.monsanto.brazilvaluecapture.multiplier.obtainer;

import com.monsanto.brazilvaluecapture.core.base.model.bean.Crop;
import com.monsanto.brazilvaluecapture.core.foundation.RandomTestData;
import com.monsanto.brazilvaluecapture.core.foundation.model.bean.StatusEnum;
import com.monsanto.brazilvaluecapture.multiplier.obtainer.model.bean.Obtainer;

public class ObtainerTestData {

	public static Obtainer createActiveObtainer(Crop crop) {
		return createActiveObtainer(RandomTestData.createRandomString(10), crop);
	}

	public static Obtainer createActiveObtainer(String description, Crop crop) {
		Obtainer obtainer = new Obtainer();
		obtainer.setDescription(description);
		obtainer.setStatus(StatusEnum.ACTIVE);
		obtainer.setCrop(crop);
		return obtainer;
	}	
	
	
}
