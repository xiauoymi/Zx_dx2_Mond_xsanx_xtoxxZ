package com.monsanto.brazilvaluecapture.multiplier.revenue.model.bean;

import org.junit.Test;

import com.monsanto.brazilvaluecapture.core.foundation.test.AssertHelper;

public class BillingGermplasmDTOs_UT {

	@Test
	public void test_getters_and_setters_billingGermplasmImportDTO() {
	    AssertHelper.testGettersAndSetters(new BillingGermplasmImportDTO());
	}

	@Test
	public void test_getters_and_settes_billingGermplasmDTO() {
		AssertHelper.testGettersAndSetters(new BillingGermplasmDTO());
	}
    
}
