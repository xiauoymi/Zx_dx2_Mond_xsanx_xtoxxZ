package com.monsanto.brazilvaluecapture.multiplier.volumereport.model.bean;

import com.monsanto.brazilvaluecapture.core.customer.model.bean.HeadOffice;
import com.monsanto.brazilvaluecapture.multiplier.cultivar.model.bean.Cultivar;
import com.monsanto.brazilvaluecapture.multiplier.itsclass.model.bean.ItsClass;
import com.monsanto.brazilvaluecapture.multiplier.obtainer.model.bean.Obtainer;
import com.monsanto.brazilvaluecapture.multiplier.volumereport.model.bean.VolumeReportClassesByCultivarDTO.CultivarClassListPair;
import com.monsanto.brazilvaluecapture.multiplier.volumereport.model.bean.VolumeReportClassesByCultivarDTO.ItsClassBooleanWrapper;
import com.monsanto.brazilvaluecapture.seedsale.harvest.model.bean.Harvest;
import junit.framework.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Random;

public class VolumeReportClassesByCultivarDTO_UT {

    private Cultivar cultivar1;
    private Cultivar cultivar2;
    private Cultivar cultivar3;
    private Cultivar cultivar4;
    private Cultivar cultivar5;

    private ItsClass itsClass1;
    private ItsClass itsClass2;
    private ItsClass itsClass3;
    private ItsClass itsClass4;
    private ItsClass itsClass5;
    private ItsClass itsClass6;

    private Harvest harvest;
    private Obtainer obtainer;
    private HeadOffice headOffice;

    @Before
    public void init() {
        cultivar1 = Mockito.mock(Cultivar.class);
        Mockito.when(cultivar1.getDescription()).thenReturn("CULTIVAR1");
        cultivar2 = Mockito.mock(Cultivar.class);
        Mockito.when(cultivar2.getDescription()).thenReturn("CULTIVAR2");
        cultivar3 = Mockito.mock(Cultivar.class);
        Mockito.when(cultivar3.getDescription()).thenReturn("CULTIVAR3");
        cultivar4 = Mockito.mock(Cultivar.class);
        Mockito.when(cultivar4.getDescription()).thenReturn("CULTIVAR4");
        cultivar5 = Mockito.mock(Cultivar.class);
        Mockito.when(cultivar5.getDescription()).thenReturn("CULTIVAR5");

        itsClass1 = Mockito.mock(ItsClass.class);
        Mockito.when(itsClass1.getAbbreviation()).thenReturn("C1");
        itsClass2 = Mockito.mock(ItsClass.class);
        Mockito.when(itsClass2.getAbbreviation()).thenReturn("C2");
        itsClass3 = Mockito.mock(ItsClass.class);
        Mockito.when(itsClass3.getAbbreviation()).thenReturn("C3");
        itsClass4 = Mockito.mock(ItsClass.class);
        Mockito.when(itsClass4.getAbbreviation()).thenReturn("C4");
        itsClass5 = Mockito.mock(ItsClass.class);
        Mockito.when(itsClass5.getAbbreviation()).thenReturn("C5");
        itsClass6 = Mockito.mock(ItsClass.class);
        Mockito.when(itsClass6.getAbbreviation()).thenReturn("C6");

        harvest = Mockito.mock(Harvest.class);
        headOffice = Mockito.mock(HeadOffice.class);
    }

    @Test
    public void given_5_cultivar_and_6_class_should_have_5_line_and_6_row() {
        VolumeReportClassesByCultivarDTO dto = new VolumeReportClassesByCultivarDTO(generateCultivarList(cultivar1, cultivar2, cultivar3, cultivar4, cultivar5),
                generateClassList(itsClass1, itsClass2, itsClass3, itsClass4, itsClass5, itsClass6), harvest, headOffice.getCustomer(), headOffice.getMatrix(), obtainer);

        Assert.assertEquals("Should be 5", 5, dto.getCultivarClassValues().size());
        for(CultivarClassListPair cultivar:dto.getCultivarClassValues()) {
            Assert.assertEquals("Should be 6", 6, cultivar.getBooleanList().size());
        }
    }
    
    @Test
    public void given_detials_with_classes_and_cultivars_inactive_cultivarClassListPair_should_contain_them_with_correct_changeable_value() {
    	Cultivar cultivar6 = Mockito.mock(Cultivar.class);
        Mockito.when(cultivar6.getDescription()).thenReturn("CULTIVAR6");
        Cultivar cultivar7 = Mockito.mock(Cultivar.class);
        Mockito.when(cultivar7.getDescription()).thenReturn("CULTIVAR7");
    	
    	VolumeReportClassesByCultivarDTO dto = new VolumeReportClassesByCultivarDTO(generateCultivarList(cultivar1, cultivar2, cultivar3, cultivar4, cultivar5, cultivar6),
                generateClassList(itsClass1, itsClass4), harvest, headOffice.getCustomer(), headOffice.getMatrix(), obtainer);
    	
    	Assert.assertEquals("Should be 6", 6, dto.getCultivarClassValues().size());
        for(CultivarClassListPair cultivar:dto.getCultivarClassValues()) {
            Assert.assertEquals("Should be 2", 2, cultivar.getBooleanList().size());
        }
    	
    	VolumeReportHeader header = new VolumeReportHeader(harvest, headOffice.getCustomer(), headOffice.getMatrix(), obtainer);
    	
        List<VolumeReportDetail> details = new ArrayList<VolumeReportDetail>();
        details.add(new VolumeReportDetail(cultivar7, itsClass1, header));
        details.add(new VolumeReportDetail(cultivar7, itsClass2, header));
        details.add(new VolumeReportDetail(cultivar1, itsClass3, header));
        
        dto.mergeCultivarClassListPairWithDetails(details);
        
        Assert.assertEquals("Should be 7", 7, dto.getCultivarClassValues().size());
        for(CultivarClassListPair cultivar:dto.getCultivarClassValues()) {
            Assert.assertEquals("Should be 4", 4, cultivar.getBooleanList().size());
        }
        
        final List<CultivarClassListPair> cultivarClassValues = dto.getCultivarClassValues();

        for (int i = 0, cultivarClassValuesSize = cultivarClassValues.size(); i < cultivarClassValuesSize; i++) {
            final CultivarClassListPair cultivarClassListPair = cultivarClassValues.get(i);
            final List<ItsClassBooleanWrapper> booleanList = cultivarClassListPair.getBooleanList();
            for (int j = 0, booleanListSize = booleanList.size(); j < booleanListSize; j++) {
                final ItsClassBooleanWrapper wrapper = booleanList.get(j);
                
                if ((i==6 || j==1 || j==2) && !wrapper.getClassSet()) {
                	Assert.assertFalse("Should not be changeable", wrapper.getClassChangeable());
                } else {
                	Assert.assertTrue("Should be changeable", wrapper.getClassChangeable());
                }
            }
        }
    }

    @Test
    public void given_5_cultivar_and_6_class_should_produce_0_detail_all_false() {
        VolumeReportClassesByCultivarDTO dto = new VolumeReportClassesByCultivarDTO(generateCultivarList(cultivar1, cultivar2, cultivar3, cultivar4, cultivar5),
                generateClassList(itsClass1, itsClass2, itsClass3, itsClass4, itsClass5, itsClass6), harvest, headOffice.getCustomer(), headOffice.getMatrix(), obtainer);

        Assert.assertEquals("Should be empty", 0, dto.generateVolumeReportDetails(null).size());

    }

    @Test
    public void given_5_cultivar_and_6_class_when_set_two_values_should_produce_2_details() {
        VolumeReportClassesByCultivarDTO dto = new VolumeReportClassesByCultivarDTO(generateCultivarList(cultivar1, cultivar2, cultivar3, cultivar4, cultivar5),
                generateClassList(itsClass1, itsClass2, itsClass3, itsClass4, itsClass5, itsClass6), harvest, headOffice.getCustomer(), headOffice.getMatrix(), obtainer);

        dto.getCultivarClassValues().get(0).getBooleanList().get(1).setClassSet(Boolean.TRUE);
        dto.getCultivarClassValues().get(1).getBooleanList().get(2).setClassSet(Boolean.TRUE);
        Assert.assertEquals("Should have 2", 2, dto.generateVolumeReportDetails(null).size());

    }

    @Test
    public void given_5_cultivar_6_class_when_feed_in_3_detail_should_return_3_detail() {
        VolumeReportClassesByCultivarDTO dto = new VolumeReportClassesByCultivarDTO(generateCultivarList(cultivar1, cultivar2, cultivar3, cultivar4, cultivar5),
                generateClassList(itsClass1, itsClass2, itsClass3, itsClass4, itsClass5, itsClass6), harvest, headOffice.getCustomer(), headOffice.getMatrix(), obtainer);

        dto.mergeCultivarClassListPairWithDetails(generateDetailList(mockDetail(itsClass1, cultivar1), mockDetail(itsClass2, cultivar1), mockDetail(itsClass3, cultivar2)));
        Assert.assertEquals("Should have 3", 3, dto.generateVolumeReportDetails(null).size());

    }

    @Test
    public void given_5_cultivar_6_class_with_detail_fed_in_when_set_4_other_checks_should_return_7_detail() {
        VolumeReportClassesByCultivarDTO dto = new VolumeReportClassesByCultivarDTO(generateCultivarList(cultivar1, cultivar2, cultivar3, cultivar4, cultivar5),
                generateClassList(itsClass1, itsClass2, itsClass3, itsClass4, itsClass5, itsClass6), harvest, headOffice.getCustomer(), headOffice.getMatrix(), obtainer);

        dto.mergeCultivarClassListPairWithDetails(generateDetailList(mockDetail(itsClass1, cultivar1), mockDetail(itsClass2, cultivar1), mockDetail(itsClass3, cultivar2)));
        int count = 0;
        Random r = new Random(new Date().getTime());
        while(count<4) {
            int cultivarIndex = r.nextInt(5);
            int classIndex = r.nextInt(6);
            if(!dto.getCultivarClassValues().get(cultivarIndex).getBooleanList().get(classIndex).getClassSet()) {
                dto.getCultivarClassValues().get(cultivarIndex).getBooleanList().get(classIndex).setClassSet(Boolean.TRUE);
                count++;
            }
        }
        Assert.assertEquals("Should have 7", 7, dto.generateVolumeReportDetails(null).size());

    }

    @Test
    public void given_5_cultivar_6_class_with_6_detail_fed_in_when_reset_4_flags_should_return_2_detail() {
        VolumeReportClassesByCultivarDTO dto = new VolumeReportClassesByCultivarDTO(generateCultivarList(cultivar1, cultivar2, cultivar3, cultivar4, cultivar5),
                generateClassList(itsClass1, itsClass2, itsClass3, itsClass4, itsClass5, itsClass6), harvest, headOffice.getCustomer(), headOffice.getMatrix(), obtainer);

        dto.mergeCultivarClassListPairWithDetails(generateDetailList(mockDetail(itsClass1, cultivar1), mockDetail(itsClass2, cultivar1),
                mockDetail(itsClass3, cultivar2), mockDetail(itsClass3, cultivar3), mockDetail(itsClass4, cultivar5), mockDetail(itsClass5, cultivar3)));

        int count = 0;

        outer:
        for (CultivarClassListPair cultivarListPair : dto.getCultivarClassValues()) {
            List<ItsClassBooleanWrapper> right = cultivarListPair.getBooleanList();
            for (int i = 0, rightSize = right.size(); i < rightSize; i++) {
                if(right.get(i).getClassSet()) {
                    right.get(i).setClassSet(Boolean.FALSE);
                    count++;
                    if(count>=4) {
                        break outer;
                    }
                }
            }

        }


    }

    private VolumeReportDetail mockDetail(ItsClass itsClass, Cultivar cultivar) {
        VolumeReportDetail detail = Mockito.mock(VolumeReportDetail.class);
        Mockito.when(detail.getItsClass()).thenReturn(itsClass);
        Mockito.when(detail.getCultivar()).thenReturn(cultivar);
        return detail;
    }

    private List<ItsClass> generateClassList(ItsClass... classes) {
        List<ItsClass> classList = new ArrayList<ItsClass>();
        for(ItsClass cls:classes) {
            classList.add(cls);
        }
        return classList;
    }

    private List<Cultivar> generateCultivarList(Cultivar... cultivars) {
        List<Cultivar> cultivarList = new ArrayList<Cultivar>();
        for(Cultivar cultivar:cultivars) {
            cultivarList.add(cultivar);
        }
        return cultivarList;
    }

    private List<VolumeReportDetail> generateDetailList(VolumeReportDetail... details) {
        List<VolumeReportDetail> detailList = new ArrayList<VolumeReportDetail>();
        for(VolumeReportDetail detail:details) {
            detailList.add(detail);
        }
        return detailList;
    }

}
