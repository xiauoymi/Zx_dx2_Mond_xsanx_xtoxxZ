package com.monsanto.brazilvaluecapture.jobs.executor.messaging.executors.impl;

import com.google.common.collect.Lists;
import com.monsanto.brazilvaluecapture.core.foundation.service.BusinessException;
import com.monsanto.brazilvaluecapture.core.revenue.model.bean.RevenueAccount;
import com.monsanto.brazilvaluecapture.core.revenue.model.bean.RevenueType;
import com.monsanto.brazilvaluecapture.seedsale.billing.model.bean.Billing;
import com.monsanto.brazilvaluecapture.seedsale.billing.model.bean.PaymentStatus;
import com.monsanto.brazilvaluecapture.seedsale.billing.model.dao.BillingDAO;
import org.junit.Test;
import org.mockito.ArgumentCaptor;

import java.util.List;

import static org.fest.assertions.Assertions.assertThat;
import static org.mockito.Mockito.*;

public class MultiplierUpdateSalesBillableProvider_UT {

    private BillingDAO billingDAO = mock(BillingDAO.class);

    @Test
    public void testGetRevenueTypeReturnsRevenueType_DISTRIBUTION() {
        MultiplierUpdateSalesBillableProvider multiplierUpdateSalesBillableProvider = new MultiplierUpdateSalesBillableProvider(null);

        RevenueType revenueType = multiplierUpdateSalesBillableProvider.getRevenueType();

        assertThat(revenueType).isEqualTo(RevenueType.DISTRIBUTION);
    }

    @Test
    public void testPayRetrievesBillings_FromSaleItemsAssociatedWithRevenueAccount() throws BusinessException {
        MultiplierUpdateSalesBillableProvider multiplierUpdateSalesBillableProvider = new MultiplierUpdateSalesBillableProvider(billingDAO);
        RevenueAccount revenueAccount = new RevenueAccount();
        stubBillingDAO(revenueAccount, Lists.newArrayList(new Billing()));

        multiplierUpdateSalesBillableProvider.pay(revenueAccount);

        verify(billingDAO).getBillingsFromRevenueAccount(revenueAccount);
    }

    @Test
    public void testPayUpdatesRetrievedBillings_WhenPayingBillings() throws BusinessException {
        RevenueAccount revenueAccount = new RevenueAccount();
        Billing billing = new Billing();
        List<Billing> billings = Lists.newArrayList(billing);
        stubBillingDAO(revenueAccount, billings);
        MultiplierUpdateSalesBillableProvider multiplierUpdateSalesBillableProvider = new MultiplierUpdateSalesBillableProvider(billingDAO);

        multiplierUpdateSalesBillableProvider.pay(revenueAccount);

        verify(billingDAO).save(billing);
    }

    @Test
    public void testPayUpdatesAllRetrievedBillings_WhenPayingBillings() throws BusinessException {
        RevenueAccount revenueAccount = new RevenueAccount();
        Billing billing = new Billing();
        Billing billing1 = new Billing();
        Billing billing2 = new Billing();
        List<Billing> billings = Lists.newArrayList(billing, billing1, billing2);
        stubBillingDAO(revenueAccount, billings);
        MultiplierUpdateSalesBillableProvider multiplierUpdateSalesBillableProvider = new MultiplierUpdateSalesBillableProvider(billingDAO);

        multiplierUpdateSalesBillableProvider.pay(revenueAccount);

        ArgumentCaptor<Billing> billingCaptor = ArgumentCaptor.forClass(Billing.class);
        verify(billingDAO, times(3)).save(billingCaptor.capture());
        List<Billing> billingsUpdated = billingCaptor.getAllValues();
        assertThat(billingsUpdated).contains(billing, billing1, billing2);
    }

    @Test
    public void testPayUpdatesBillingPaymentStatus_WhenPayingbillings() throws BusinessException {
        RevenueAccount revenueAccount = new RevenueAccount();
        Billing billing = new Billing();
        billing.setPaymentStatus(PaymentStatus.BILLED);
        Billing billing1 = new Billing();
        billing1.setPaymentStatus(PaymentStatus.BILLED);
        Billing billing2 = new Billing();
        billing2.setPaymentStatus(PaymentStatus.BILLED);
        List<Billing> billings = Lists.newArrayList(billing, billing1, billing2);
        stubBillingDAO(revenueAccount, billings);
        MultiplierUpdateSalesBillableProvider multiplierUpdateSalesBillableProvider = new MultiplierUpdateSalesBillableProvider(billingDAO);

        multiplierUpdateSalesBillableProvider.pay(revenueAccount);

        ArgumentCaptor<Billing> billingCaptor = ArgumentCaptor.forClass(Billing.class);
        verify(billingDAO, times(3)).save(billingCaptor.capture());
        List<Billing> billingsUpdated = billingCaptor.getAllValues();
        assertThat(billingsUpdated).onProperty("paymentStatus").contains(PaymentStatus.FULLY_PAID);
    }

    private void stubBillingDAO(RevenueAccount revenueAccount, List<Billing> billings) {
        when(billingDAO.getBillingsFromRevenueAccount(revenueAccount)).thenReturn(billings);
    }
}