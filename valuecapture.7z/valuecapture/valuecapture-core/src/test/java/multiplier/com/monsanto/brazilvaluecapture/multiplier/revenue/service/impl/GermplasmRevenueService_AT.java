package com.monsanto.brazilvaluecapture.multiplier.revenue.service.impl;

import java.math.BigDecimal;
import java.util.Calendar;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.ResourceBundle;
import java.util.Set;

import com.monsanto.brazilvaluecapture.core.foundation.util.security.EnvironmentSpecificPropertyReader;
import com.monsanto.brazilvaluecapture.core.regionalization.CountriesHolder;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.monsanto.brazilvaluecapture.core.base.model.bean.Company;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Crop;
import com.monsanto.brazilvaluecapture.core.base.model.bean.DocumentType;
import com.monsanto.brazilvaluecapture.core.base.model.bean.OperationalYear;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Customer;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Technology;
import com.monsanto.brazilvaluecapture.core.foundation.test.AbstractServiceIntegrationTests;
import com.monsanto.brazilvaluecapture.core.foundation.test.dbunit.DbUnitHelper;
import com.monsanto.brazilvaluecapture.core.importfile.model.ImportFileType;
import com.monsanto.brazilvaluecapture.core.importfile.model.bean.CsvImportFile;
import com.monsanto.brazilvaluecapture.core.io.ProcessorConfig;
import com.monsanto.brazilvaluecapture.core.io.ProcessorConfig.ProcessorConfigProperties;
import com.monsanto.brazilvaluecapture.core.user.model.bean.UserDecorator;
import com.monsanto.brazilvaluecapture.core.user.service.UserNotFoundException;
import com.monsanto.brazilvaluecapture.core.user.service.UserService;
import com.monsanto.brazilvaluecapture.multiplier.cultivar.model.bean.Cultivar;
import com.monsanto.brazilvaluecapture.multiplier.itsclass.model.bean.ItsClass;
import com.monsanto.brazilvaluecapture.multiplier.obtainer.model.bean.Obtainer;
import com.monsanto.brazilvaluecapture.multiplier.revenue.model.bean.BillingGermplasmCsvImportResult;
import com.monsanto.brazilvaluecapture.multiplier.revenue.model.bean.BillingGermplasmCsvImportedLine;
import com.monsanto.brazilvaluecapture.multiplier.revenue.model.bean.GermplasmRevenue;
import com.monsanto.brazilvaluecapture.multiplier.revenue.model.bean.GermplasmRevenueStatus;
import com.monsanto.brazilvaluecapture.multiplier.revenue.model.bean.VolumeCommercializedType;
import com.monsanto.brazilvaluecapture.multiplier.revenue.service.GermplasmRevenueService;
import com.monsanto.brazilvaluecapture.multiplier.volumereport.model.bean.VolumeReportDetail;
import com.monsanto.brazilvaluecapture.multiplier.volumereport.model.dao.BillingGermplasmFilter;
import com.monsanto.brazilvaluecapture.seedsale.harvest.model.bean.Harvest;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class GermplasmRevenueService_AT extends AbstractServiceIntegrationTests {
	
	@Autowired
	private GermplasmRevenueService germplasmRevenueService; 
	
    @Autowired
    private UserService userService;
	
	private Locale localeBR = new Locale("pt", "BR");
	private ResourceBundle resourceBundle = ResourceBundle
			.getBundle("bundle/bundle");

	private ProcessorConfig processorConfig;
	private OperationalYear operationalYear;
	private Customer customer;
	private DocumentType customerDocumentType;
	private Harvest harvest;
	private Company company;
	private Crop crop;
	private UserDecorator user;
	private Customer matrix;
	private Obtainer obtainer;
	private ItsClass itsClass;
	private Cultivar cultivar;
	private Technology technology;
	private VolumeCommercializedType volumeCommercializedType;
	private GermplasmRevenue revenue;
	
	private CsvImportFile csvImportFile;
	private BillingGermplasmCsvImportedLine csvImportLine;

	private VolumeReportDetail detail;

    @Autowired
    private CountriesHolder countriesHolder;

	@Before
	public void setup() throws UserNotFoundException {

		DbUnitHelper.setup("classpath:data/multiplier/basic-fixture.xml",
				"classpath:data/multiplier/revenue-multiplier-dataset.xml");

         //Added for LASVC to return a country brazil
         String configuredHost = "CONFIGURED_AND_REQUESTED_HOST_SAME";
		 EnvironmentSpecificPropertyReader env = mock(EnvironmentSpecificPropertyReader.class);
		 countriesHolder.setEnvironmentSpecificPropertyReader(env);
		 when(env.getEnvironmentSpecificProperty("host_name.argentina", null)).thenReturn("other");
		 when(env.getEnvironmentSpecificProperty("host_name.brazil", null)).thenReturn(configuredHost);
		 when(env.getEnvironmentSpecificProperty("host_name.paraguay", null)).thenReturn("another");

         countriesHolder.initialize();
         try{
            countriesHolder.resolveCountry(configuredHost);
         }catch(IllegalStateException ex)
         {

         }

		detail = (VolumeReportDetail) getSession().get(VolumeReportDetail.class, 991000008L);
		customer = (Customer) getSession().get(Customer.class, 900000003L);
		customerDocumentType = customer.getDocument().getDocumentType();
		harvest = (Harvest) getSession().get(Harvest.class, 900000001L);
		operationalYear = (OperationalYear) getSession().get(OperationalYear.class, 900000002L);
		company = (Company) getSession().get(Company.class, 900000001L);
		crop = (Crop) getSession().get(Crop.class, 900000001L);
		matrix = (Customer) getSession().get(Customer.class, 900000004L);
		obtainer = (Obtainer) getSession().get(Obtainer.class, 991000001L);
		itsClass = (ItsClass) getSession().get(ItsClass.class, 991000001L);
		cultivar = (Cultivar) getSession().get(Cultivar.class, 991000001L);
		technology = (Technology) getSession().get(Technology.class, 900000001L);
		volumeCommercializedType = VolumeCommercializedType.ONE;
		
		revenue = (GermplasmRevenue) getSession().get(GermplasmRevenue.class, 991000001L);
		
		user = userService.getAuthenticatedUserBy("DANDRADE_S");
		user.setContextCompany(company);
		
		processorConfig = new ProcessorConfig();
		processorConfig
				.put(ProcessorConfigProperties.SELECTED_LOCALE, localeBR);
		processorConfig.put(ProcessorConfigProperties.LOGGED_USER, user);
		processorConfig.put(ProcessorConfigProperties.FILENAME, "sample.csv");
		processorConfig.put(ProcessorConfigProperties.BUNDLE, resourceBundle);
		
		createImportFile();

		createValidLine(csvImportFile);


	}

	private void createImportFile() {
		csvImportFile = new CsvImportFile(
				(String) processorConfig
						.get(ProcessorConfigProperties.FILENAME),
				user.getLogin(), ImportFileType.CSV_BILLING_GERMPLASM);
		getSession().saveOrUpdate(csvImportFile);
	}
	
	private void createValidLine(CsvImportFile csvImportFile) {
		csvImportLine = createImportedLine(
				csvImportFile,
				customerDocumentType.getDescription(),
				customer.getDocumentValue(), 
				customer.getCustomerSAPCode(),
				matrix.getDocument().getDocumentTypeDescription(),
				matrix.getDocumentValue(), 
				matrix.getCustomerSAPCode(),
				company.getDescription(),
				crop.getDescription(),
				operationalYear.getYear(), 
				harvest.getDescription(), 
				technology.getDescription(), 
				obtainer.getDescription(), 
				cultivar.getDescription(),
				itsClass.getAbbreviation(),
				getFutureDate(),
				volumeCommercializedType.getValue(), 
				BigDecimal.ONE,
				"Importacao referente safra 2013",
				1);

		saveAndFlush(csvImportLine);
	}
	
	private Date getFutureDate() {
		Calendar calendar = Calendar.getInstance();
		calendar.add(Calendar.MONTH, 1);
		return calendar.getTime();
	}

	private BillingGermplasmCsvImportedLine createImportedLine(CsvImportFile csvImportFile,
			String partnerDocumentType, String customerDocument,
			String customerSAPCode, String matrixDocumentType,
			String matrixDocument, String matrixSAPCode, String companyDescription,
			String cropDescription, String operationalYearDescription, String harvestDescription,
			String technologyDescription, String obtainerDescription, String cultivarDescription,
			String classAbbreaviation, Date dueDate,
			Integer volumeCommercialized, BigDecimal volumeGermplasm,
			String billingGermplasmNote,
			int lineNumber) {
		
		BillingGermplasmCsvImportedLine line = new BillingGermplasmCsvImportedLine();
		line.setCsvImportFile(csvImportFile);
		line.setLine(lineNumber);		
		
		line.setOverwriteImported(false);
		
		line.setCustomerDocumentTypeDescription(partnerDocumentType);
		line.setCustomerDocument(customerDocument);
		line.setCustomerSAPCode(customerSAPCode);
		line.setMatrixDocumentTypeDescription(matrixDocumentType);
		line.setMatrixDocument(matrixDocument);
		line.setMatrixSAPCode(matrixSAPCode);
		line.setCompanyDescription(companyDescription);
		line.setCropDescription(cropDescription);
		line.setOperationalYearDescription(operationalYearDescription);
		line.setHarvestDescription(harvestDescription);
		line.setTechnologyDescription(technologyDescription);
		line.setObtainerDescription(obtainerDescription);
		line.setCultivarDescription(cultivarDescription);
		line.setClassAbbreviation(classAbbreaviation);
		line.setDueDate(dueDate);
		line.setVolumeCommercializedTypeNumber(volumeCommercialized);
		line.setVolumeGermplasm(volumeGermplasm);
		line.setBillingGermplasmNote(billingGermplasmNote);
		
		return line;
	}

	@Test
	public void testSelectCsvBillingGermplasmImportResultByFile() {
		
		BillingGermplasmCsvImportResult result = new BillingGermplasmCsvImportResult(1L, csvImportFile, "Linha 1");
		saveAndFlush(result);
		
		List<BillingGermplasmCsvImportResult> list = germplasmRevenueService.selectCsvBillingGermplasmImportResultByFile(csvImportFile);
		Assert.assertFalse(list.isEmpty());
	}

	@Test
	public void testSaveRevenues() {
		Set<GermplasmRevenue> revenues = new HashSet<GermplasmRevenue>();
		revenues.add(revenue);
		germplasmRevenueService.saveRevenues(revenues);
	}

	@Test
	public void testSelectRevenueById() {
		Long id = 991000001L;
		GermplasmRevenue germplasmRevenue = germplasmRevenueService.selectRevenueById(id);
		Assert.assertNotNull(germplasmRevenue);
	}

	@Test
	public void given_a_BillingGermplasmFilter_when_i_search_by_detail_should_return_result() {
		BillingGermplasmFilter filter = BillingGermplasmFilter.getInstance();
		filter.add(detail);
		
		List<GermplasmRevenue> revenues = germplasmRevenueService.selectRevenueBy(filter);
		Assert.assertEquals("Should have 3 germplasmRevenue with this detail", 3, revenues.size());
	}
	
	@Test
	public void given_a_BillingGermplasmFilter_when_i_search_by_detail_and_volCommType_should_return_result() {
		BillingGermplasmFilter filter = BillingGermplasmFilter.getInstance();
		filter.add(detail);
		filter.add(VolumeCommercializedType.THREE);
		
		List<GermplasmRevenue> revenues = germplasmRevenueService.selectRevenueBy(filter);
		Assert.assertEquals("Should have 2 germplasmRevenue of this detail with this type", 2, revenues.size());
	}
	
	@Test
	public void given_a_BillingGermplasmFilter_when_i_search_by_detail_and_volCommType_and_status_should_return_result() {
		BillingGermplasmFilter filter = BillingGermplasmFilter.getInstance();
		filter.add(detail);
		filter.add(VolumeCommercializedType.THREE);
		filter.add(GermplasmRevenueStatus.OPEN);
		
		List<GermplasmRevenue> revenues = germplasmRevenueService.selectRevenueBy(filter);
		Assert.assertEquals("Should have 1 germplasmRevenue of this detail with this type and status", 1, revenues.size());
	}

}
