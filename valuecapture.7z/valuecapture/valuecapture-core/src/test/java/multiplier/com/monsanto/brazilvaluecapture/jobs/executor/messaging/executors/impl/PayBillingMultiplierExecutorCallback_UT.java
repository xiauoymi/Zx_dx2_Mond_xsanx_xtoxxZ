package com.monsanto.brazilvaluecapture.jobs.executor.messaging.executors.impl;

import com.monsanto.brazilvaluecapture.core.base.model.bean.Company;
import com.monsanto.brazilvaluecapture.core.foundation.service.BusinessException;
import com.monsanto.brazilvaluecapture.core.foundation.util.log.bean.JobLogEntry;
import com.monsanto.brazilvaluecapture.core.revenue.service.RevenueManager;
import com.monsanto.brazilvaluecapture.jobs.executor.messaging.bean.JobExecutionInfo;
import com.monsanto.brazilvaluecapture.multiplier.revenue.service.MultiplierBillableProvider;
import com.monsanto.brazilvaluecapture.osb.its.api.InfraException;
import org.junit.Test;

import static org.mockito.Mockito.*;

public class PayBillingMultiplierExecutorCallback_UT {
    @Test
    public void testDoWorkInvokesRevenueManager_WithMultiplierUpdateSalesBillableProvider() throws InfraException, BusinessException {
        RevenueManager revenueManager = mock(RevenueManager.class);
        Company company = new Company("Some Company");
        JobExecutionInfo jobExecution = mockJobExecutionInfo(company);
        MultiplierUpdateSalesBillableProvider multiplierUpdateSalesBillableProvider = mock(MultiplierUpdateSalesBillableProvider.class);
        MultiplierBillableProvider multiplierBillableProvider = mock(MultiplierBillableProvider.class);
        PayBillingMultiplierExecutorCallback payBillingMultiplierExecutorCallback =
                new PayBillingMultiplierExecutorCallback(revenueManager, multiplierBillableProvider, multiplierUpdateSalesBillableProvider);

        payBillingMultiplierExecutorCallback.doWork(jobExecution);

        verify(revenueManager).callOsbAndUpdatePayment(multiplierUpdateSalesBillableProvider, company);
    }

    private JobExecutionInfo mockJobExecutionInfo(Company company) {
        JobExecutionInfo jobExecutionInfo = mock(JobExecutionInfo.class);
        when(jobExecutionInfo.getEntry()).thenReturn(new JobLogEntry());
        when(jobExecutionInfo.getCompany()).thenReturn(company);
        return jobExecutionInfo;
    }

}