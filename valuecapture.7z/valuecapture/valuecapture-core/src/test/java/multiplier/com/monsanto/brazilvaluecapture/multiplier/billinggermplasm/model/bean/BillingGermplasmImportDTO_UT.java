package com.monsanto.brazilvaluecapture.multiplier.billinggermplasm.model.bean;

import org.junit.Test;

import com.monsanto.brazilvaluecapture.core.foundation.test.AssertHelper;
import com.monsanto.brazilvaluecapture.multiplier.revenue.model.bean.BillingGermplasmImportDTO;

public class BillingGermplasmImportDTO_UT {

@Test
public void test_getters_and_setters() {
    AssertHelper.testGettersAndSetters(new BillingGermplasmImportDTO());
}

    
}
