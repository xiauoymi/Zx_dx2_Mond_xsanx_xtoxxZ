package com.monsanto.brazilvaluecapture.seedsale.sale.validation;

public class SaleTotalCashAdvanceAvailableValidationRule_UT {

}