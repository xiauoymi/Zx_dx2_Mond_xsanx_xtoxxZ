package com.monsanto.brazilvaluecapture.multiplier.volumereport.service.impl;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.ResourceBundle;

import junit.framework.Assert;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.junit.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;

import com.monsanto.brazilvaluecapture.core.base.model.bean.Company;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Crop;
import com.monsanto.brazilvaluecapture.core.customer.CustomerTestData;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Customer;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.CustomerHierarchyDetailView;
import com.monsanto.brazilvaluecapture.core.foundation.test.AbstractServiceIntegrationTests;
import com.monsanto.brazilvaluecapture.core.foundation.test.dbunit.DbUnitHelper;
import com.monsanto.brazilvaluecapture.core.revenue.model.bean.RevenueAccount;
import com.monsanto.brazilvaluecapture.core.user.model.bean.UserDecorator;
import com.monsanto.brazilvaluecapture.multiplier.volumereport.model.bean.CustomerHierarchyFilterView;
import com.monsanto.brazilvaluecapture.multiplier.volumereport.model.bean.EnteredAreaReportView;
import com.monsanto.brazilvaluecapture.multiplier.volumereport.model.bean.VolumeReportDetail;
import com.monsanto.brazilvaluecapture.multiplier.volumereport.model.dao.EnteredAreaReportViewFilter;
import com.monsanto.brazilvaluecapture.seedsale.quota.report.EmptyReportException;

public class EnteredAreaReportBuilder_AT extends AbstractServiceIntegrationTests {
	public static final Long COMPANY1 = 900000001L;
	public static final Long CROP1 = 900000001L;

	private static final int COLUMN_ENTERED_AREA = 21;
	private static final int COLUMN_OWN_SEED_USED = 22;
	private static final int COLUMN_MATRIX_SEED_USED = 23;
	private static final int COLUMN_TOTAL_DISCARD_PORTIONING = 24;
	private static final int COLUMN_VOLUME_DISCARDED_FIELD = 25;
	private static final int COLUMN_AREA_HARVESTED_FOR_SEED = 26;
	private static final int COLUMN_VOLUME_HARVESTED = 27;
	private static final int COLUMN_VOLUME_FOR_UBS = 28;
	private static final int COLUMN_VOLUME_DISCARDED_HARVEST = 29;
	private static final int COLUMN_VOLUME_BENEFITTED = 30;
	private static final int COLUMN_VOLUME_DISCARDED_UBS = 31;
	private static final int COLUMN_VOLUME_APPROVED = 32;
	private static final int COLUMN_VOLUME_REPPROVED_RECLASSIFICATION = 33;
	private static final int COLUMN_VOLUME_COMMERCIALIZED1 = 34;
	private static final int COLUMN_VOLUME_COMMERCIALIZED2 = 35;
	private static final int COLUMN_VOLUME_COMMERCIALIZED3 = 36;
	private static final int COLUMN_VOLUME_FOR_NEXT_HARVEST = 37;
	private static final int COLUMN_VOLUME_SEED_LEFT_OVER = 38;
	
	private ResourceBundle resourceBundle = ResourceBundle.getBundle("bundle/bundle");
	
	@Autowired
	private EnteredAreaReportBuilder builder;

	private Company company1;
	private Crop crop1;
	
	private void setup() {
		DbUnitHelper.setup("classpath:data/multiplier/basic-fixture.xml");
		company1 = (Company) getSession().get(Company.class, COMPANY1);
		crop1 = (Crop) getSession().get(Crop.class, CROP1);
	}

	@SuppressWarnings("unchecked")
	private void setupReportData() {
		setup();
		DbUnitHelper.setup("classpath:data/multiplier/entered-area-report-dataset.xml");
		if (!getAssumptionTest().isEnvironmentWithSQLANSI()) {
			List<VolumeReportDetail> details = getSession().createCriteria(VolumeReportDetail.class).list();
			HashMap<VolumeReportDetail, RevenueAccount> detailAccountMap = new HashMap<VolumeReportDetail, RevenueAccount>();
	    	
	    	for (VolumeReportDetail detail : details) {
				if (detail.getRevenueAccountId() != null) {
					RevenueAccount account = (RevenueAccount) getSession().get(RevenueAccount.class, detail.getRevenueAccountId());
					detailAccountMap.put(detail, account);
				} else {
					detailAccountMap.put(detail, null);
				}
			}
			List<EnteredAreaReportView> viewsList = VolumeReportTestData.createEnteredAreaReportViewFrom(details, detailAccountMap);
			for (EnteredAreaReportView view : viewsList) {
				saveAndFlush(view);
			}
			
	    	List<Customer> customers = getSession().createCriteria(Customer.class).list();
	    	List<CustomerHierarchyFilterView> filterViews = CustomerTestData.createCustomerHierarchyFilterViewBy(customers);
	    	for (CustomerHierarchyFilterView customerHierarchyFilterView : filterViews) {
				saveAndFlush(customerHierarchyFilterView);
			}
	    	
	    	List<CustomerHierarchyDetailView> detailViews = CustomerTestData.createCustomerDetailViewBy(customers);
	    	for (CustomerHierarchyDetailView customerHierarchyDetailView : detailViews) {
				saveAndFlush(customerHierarchyDetailView);
			}
		}
	}

	private EnteredAreaReportViewFilter getInstanceFilter() {
		return EnteredAreaReportViewFilter.getInstance(company1, crop1, Mockito.mock(UserDecorator.class));
	}
	
	@Test(expected=EmptyReportException.class)
	public void given_no_records_saved_when_load_records_should_throw_empty_report_exception() throws EmptyReportException {
		setup();
		EnteredAreaReportViewFilter filter = getInstanceFilter();
		loadRecords(filter);
	}

	@Test
	public void given_many_detail_saved_when_load_records_should_have_many_records() throws EmptyReportException {
		setupReportData();
		EnteredAreaReportViewFilter filter = getInstanceFilter();
		loadRecords(filter);
		
		Assert.assertEquals("Should have five records", 5, builder.getTotalRecord());
	}
	
	@Test
	public void given_details_saved_when_build_report_should_have_correct_calculated_values() throws EmptyReportException, NoSuchMethodException, IOException {
		setupReportData();
		EnteredAreaReportViewFilter filter = getInstanceFilter();
		loadRecords(filter);
		ByteArrayOutputStream baos = builder.buildReportFor(resourceBundle);
		
		assertAllCalulatedColumns(baos, 1, 500L, 100L, 100L, 35L, 350L, 465L, 75L,
				0L, 0L, 900L, 0L, 800L, 100L, 50L, 100L, 150L, 200L, 300L);
		
		assertAllCalulatedColumns(baos, 2, 0L, 0L, 0L, 0L, 0L, 0L, 0L,
				0L, 0L, 40L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L);
		
		assertAllCalulatedColumns(baos, 3, 11L, 12L, 13L, 0L, 0L, 11L, 15L,
				16L, -1L, 17L, -1L, 18L, -1L, 0L, 0L, 0L, 0L, 0L);
		
		assertAllCalulatedColumns(baos, 4, 0L, 0L, 0L, 0L, 0L, 0L, 0L,
				0L, 0L, 40L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L);
		
		assertAllCalulatedColumns(baos, 5, 0L, 0L, 0L, 30L, 300L, 0L, 0L,
				500L, 0L, 0L, 0L, 700L, 0L, 0L, 0L, 0L, 0L, 0L);
	}
	
	private void assertAllCalulatedColumns(ByteArrayOutputStream baos,
			int rowNum, double enteredArea,
			double ownSeedUsed, double matrixSeedUsed,
			double totalDiscardPortioning, double volumeDiscardedField,
			double harvestedForSeed, double volumeHarvested,
			double volumeForUBS, double volumeDiscardedHarvest,
			double volumeBenefitted, double volumeDiscardedUBS,
			double volumeApproved, double volumeRepprovedReclassification,
			double volumeComm1, double volumeComm2,
			double volumeComm3,
			double volumeForNextHarvest, double volumeSeedLeftOver) throws IOException {
		assertCalculatedCell(enteredArea, baos, rowNum, COLUMN_ENTERED_AREA);
		assertCalculatedCell(ownSeedUsed, baos, rowNum, COLUMN_OWN_SEED_USED);
		assertCalculatedCell(matrixSeedUsed, baos, rowNum, COLUMN_MATRIX_SEED_USED);
		assertCalculatedCell(totalDiscardPortioning, baos, rowNum, COLUMN_TOTAL_DISCARD_PORTIONING);
		assertCalculatedCell(volumeDiscardedField, baos, rowNum, COLUMN_VOLUME_DISCARDED_FIELD);
		assertCalculatedCell(harvestedForSeed, baos, rowNum, COLUMN_AREA_HARVESTED_FOR_SEED);
		assertCalculatedCell(volumeHarvested, baos, rowNum, COLUMN_VOLUME_HARVESTED);
		assertCalculatedCell(volumeForUBS, baos, rowNum, COLUMN_VOLUME_FOR_UBS);
		assertCalculatedCell(volumeDiscardedHarvest, baos, rowNum, COLUMN_VOLUME_DISCARDED_HARVEST);
		assertCalculatedCell(volumeBenefitted, baos, rowNum, COLUMN_VOLUME_BENEFITTED);
		assertCalculatedCell(volumeDiscardedUBS, baos, rowNum, COLUMN_VOLUME_DISCARDED_UBS);
		assertCalculatedCell(volumeApproved, baos, rowNum, COLUMN_VOLUME_APPROVED);
		assertCalculatedCell(volumeRepprovedReclassification, baos, rowNum, COLUMN_VOLUME_REPPROVED_RECLASSIFICATION);
		assertCalculatedCell(volumeComm1, baos, rowNum, COLUMN_VOLUME_COMMERCIALIZED1);
		assertCalculatedCell(volumeComm2, baos, rowNum, COLUMN_VOLUME_COMMERCIALIZED2);
		assertCalculatedCell(volumeComm3, baos, rowNum, COLUMN_VOLUME_COMMERCIALIZED3);
		assertCalculatedCell(volumeForNextHarvest, baos, rowNum, COLUMN_VOLUME_FOR_NEXT_HARVEST);
		assertCalculatedCell(volumeSeedLeftOver, baos, rowNum, COLUMN_VOLUME_SEED_LEFT_OVER);
	}

	private void loadRecords(EnteredAreaReportViewFilter filter) throws EmptyReportException {
		builder.clear();
		builder.loadRecords(filter, resourceBundle);
		alterBuilderReportList();
	}

	private void alterBuilderReportList() {
		List<EnteredAreaReportView> list = builder.getResultList();
		boolean isCooperative = true;
		for (EnteredAreaReportView view : list) {
			view.setCooperative(isCooperative);
			if (isCooperative) {
				view.setProductivity(BigDecimal.TEN);
			}
			isCooperative = !isCooperative;
		}
		builder.setResultList(list);
	}
	
	private void assertCalculatedCell(double expected, ByteArrayOutputStream baos, int rowNum, int cellPosition) throws IOException {
		HSSFCell cell = assertOutputStreamAndGetCell(baos, rowNum, cellPosition);
		Assert.assertEquals(
				"Values don't match for column: " + cell.getColumnIndex() + " and row: " + rowNum, expected, cell.getNumericCellValue());
	}
	
	private HSSFCell assertOutputStreamAndGetCell(ByteArrayOutputStream baos, int rowNum, int cellPosition) throws IOException {
		ByteArrayInputStream inputStream = new ByteArrayInputStream(baos.toByteArray());
    	HSSFWorkbook hssfWorkbook = new HSSFWorkbook(inputStream);
    	Assert.assertNotNull("workbook shouldn't be null", hssfWorkbook);
    	HSSFSheet sheet = hssfWorkbook.getSheetAt(0);
    	Assert.assertNotNull("Sheet shouldn't be null", sheet);
    	HSSFRow row = sheet.getRow(rowNum);
    	Assert.assertNotNull("Row shouldn't be null", row);
    	HSSFCell cell = row.getCell(cellPosition);
    	Assert.assertNotNull("Cell shouldn't be null", cell);
		return cell;
	}
}
