package com.monsanto.brazilvaluecapture.multiplier.volumereport.service.impl;

import com.dumbster.smtp.SimpleSmtpServer;
import com.monsanto.CountriesHolderInitializer;
import com.monsanto.brazilvaluecapture.core.base.model.bean.*;
import com.monsanto.brazilvaluecapture.core.base.service.ConstraintException;
import com.monsanto.brazilvaluecapture.core.commercialhierarchy.model.bean.ItsDistrict;
import com.monsanto.brazilvaluecapture.core.commercialhierarchy.model.bean.ItsRegion;
import com.monsanto.brazilvaluecapture.core.commercialhierarchy.model.bean.ItsUnity;
import com.monsanto.brazilvaluecapture.core.customer.CustomerTestData;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.*;
import com.monsanto.brazilvaluecapture.core.foundation.test.AbstractServiceIntegrationTests;
import com.monsanto.brazilvaluecapture.core.foundation.test.dbunit.DbUnitHelper;
import com.monsanto.brazilvaluecapture.core.foundation.util.CalendarUtil;
import com.monsanto.brazilvaluecapture.core.foundation.util.ConstraintViolation;
import com.monsanto.brazilvaluecapture.core.grower.model.bean.Grower;
import com.monsanto.brazilvaluecapture.core.regionalization.CountriesHolder;
import com.monsanto.brazilvaluecapture.core.revenue.model.bean.RevenueAccount;
import com.monsanto.brazilvaluecapture.core.user.model.bean.UserDecorator;
import com.monsanto.brazilvaluecapture.core.user.service.UserNotFoundException;
import com.monsanto.brazilvaluecapture.core.user.service.UserService;
import com.monsanto.brazilvaluecapture.multiplier.cultivar.model.bean.Cultivar;
import com.monsanto.brazilvaluecapture.multiplier.harvestcalendar.model.bean.HarvestCalendar;
import com.monsanto.brazilvaluecapture.multiplier.hectareproductivity.model.bean.HectareProductivity;
import com.monsanto.brazilvaluecapture.multiplier.itsclass.model.bean.ItsClass;
import com.monsanto.brazilvaluecapture.multiplier.obtainer.model.bean.Obtainer;
import com.monsanto.brazilvaluecapture.multiplier.volumereport.model.bean.*;
import com.monsanto.brazilvaluecapture.multiplier.volumereport.model.bean.VolumeReportClassesByCultivarDTO.CultivarClassListPair;
import com.monsanto.brazilvaluecapture.multiplier.volumereport.model.bean.VolumeReportClassesByCultivarDTO.ItsClassBooleanWrapper;
import com.monsanto.brazilvaluecapture.multiplier.volumereport.model.dao.EnteredAreaReportViewFilter;
import com.monsanto.brazilvaluecapture.multiplier.volumereport.model.dao.VolumeReportApprovalFilter;
import com.monsanto.brazilvaluecapture.multiplier.volumereport.model.dao.VolumeReportFilter;
import com.monsanto.brazilvaluecapture.multiplier.volumereport.service.VolumeReportDetailService;
import com.monsanto.brazilvaluecapture.multiplier.volumereport.service.VolumeReportService;
import com.monsanto.brazilvaluecapture.seedsale.harvest.model.bean.Harvest;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.*;

public class VolumeReportServiceImpl_AT extends AbstractServiceIntegrationTests {
    public static final Long CROP1 = 900000001L;
    public static final Long CROP2 = 900000002L;
    public static final Long OBTAINER1 = 900000001L;
    public static final Long OBTAINER2 = 900000002L;
    public static final Long OBTAINER3 = 900000003L;
    public static final Long OBTAINER4 = 900000004L;
    public static final Long CULTIVAR1 = 900000001L;
    public static final Long CULTIVAR2 = 900000002L;
    public static final Long CULTIVAR3 = 900000003L;
    public static final Long CULTIVAR4 = 900000004L;
    public static final Long CULTIVAR5 = 900000005L;
    public static final Long CULTIVAR6 = 900000006L;
    public static final Long CULTIVAR7 = 900000007L;
    public static final Long CULTIVAR8 = 900000008L;
    public static final Long CULTIVAR9 = 900000009L;
    public static final Long CULTIVAR14 = 900000014L;
    public static final Long HARVEST1 = 900000001L;
    public static final Long HARVEST2 = 900000002L;
    public static final Long HARVEST3 = 900000003L;
    public static final Long STATE1 = 900000001L;
    public static final Long STATE2 = 900000002L;
    public static final Long STATE3 = 900000003L;
    public static final Long STATE4 = 900000004L;
    public static final Long STATE5 = 900000005L;
    public static final Long HEADOFFICE8 = 900000008L;
    public static final Long HEADOFFICE9 = 900000009L;
    public static final Long HEADOFFICE10 = 900000010L;
    public static final Long HEADOFFICE1 = 900000002L;
    public static final Long HEADOFFICE2 = 900000001L;
    public static final Long CLASS1 = 900000001L;
    public static final Long CLASS2 = 900000002L;
    public static final Long COMPANY1 = 900000001L;
    public static final Long COMPANY2 = 900000002L;
    public static final Long ITS_DISTRICT1 = 900000001L;
    private static final long GROWER1 = 900000001L;
    private static final long HEADER_ID = 900000001L;
    //    private static final Date pastDateStart;
//    private static final Date pastDateEnd;
    private static final Date currentDateStart;
    private static final Date currentDateEnd;
    private static final Date futureDateStart;
    private static final Date futureDateEnd;
    private SimpleSmtpServer serverSMTP;

    @Autowired
    private UserService userService;

    private Locale localeBR = new Locale("pt", "BR");

    private ResourceBundle resourceBundle = ResourceBundle.getBundle("bundle/bundle");

    //    @Before
//    public void start() {
//
//        serverSMTP = SimpleSmtpServer.start(getEnviromentSpecificSmtpPort());
//    }
//
//    @After
//    public void stop() {
//        if (serverSMTP != null) {
//            serverSMTP.stop();
//        }
//
//    }
    @Autowired
    private VolumeReportService volumeReportService;
    @Autowired
    private VolumeReportDetailService volumeReportDetailService;
    private ItsClass itsClass1;
    private ItsClass itsClass2;
    private Cultivar cultivar1;
    private Obtainer obtainer;
    private Cultivar cultivar2;
    private Harvest harvest;
    private HeadOffice headOffice;
    private Company company1;
    private Company company2;
    private Crop crop1;
    private Crop crop2;
    private ItsDistrict itsDistrict;
    @Autowired
    private CountriesHolder countriesHolder;

    static {
        Calendar calendar = Calendar.getInstance();
//        calendar.add(Calendar.MONTH, -6);
//        pastDateStart = calendar.getDateTodayPreviousMonth();
//        calendar.add(Calendar.MONTH, 1);
//        pastDateEnd = calendar.getDateTodayPreviousMonth();

        calendar = Calendar.getInstance();
        calendar.add(Calendar.MONTH, -1);
        currentDateStart = calendar.getTime();
        calendar.add(Calendar.MONTH, 2);
        currentDateEnd = calendar.getTime();

        calendar = Calendar.getInstance();
        calendar.add(Calendar.MONTH, 6);
        futureDateStart = calendar.getTime();
        calendar.add(Calendar.MONTH, 1);
        futureDateEnd = calendar.getTime();
    }

//    private HarvestCalendar pastHarvestCalendar;
//    private HarvestCalendar futureHarvestCalendar;
//    private HarvestCalendar currentHarvestCalendar;

    @Before
    public void init() {
        CountriesHolderInitializer.initialize(countriesHolder);
    }

    public void setupFixture() {
        if (((Long) getSession().createQuery("select count(*) from VolumeReportPhaseMailTemplate").uniqueResult()).compareTo(0L) > 0) {
            DbUnitHelper.setup(
                    "classpath:data/multiplier/basic-fixture.xml",
                    "classpath:data/multiplier/volume-report-dataset.xml");
        } else {
            DbUnitHelper.setup(
                    "classpath:data/multiplier/basic-fixture.xml",
                    "classpath:data/multiplier/volume-report-dataset.xml",
                    "classpath:data/multiplier/volume-report-phase-mail-template.xml");
        }


//        pastHarvestCalendar = createAndPersistHarvestCalendar((Harvest) getSession().get(Harvest.class, HARVEST1), pastDateStart, pastDateEnd);
//        futureHarvestCalendar = createAndPersistHarvestCalendar((Harvest) getSession().get(Harvest.class, HARVEST1), pastDateStart, pastDateEnd);
        company1 = (Company) getSession().get(Company.class, COMPANY1);
        company2 = (Company) getSession().get(Company.class, COMPANY2);
        crop1 = (Crop) getSession().get(Crop.class, CROP1);
        crop2 = (Crop) getSession().get(Crop.class, CROP2);
        itsDistrict = (ItsDistrict) getSession().get(ItsDistrict.class, ITS_DISTRICT1);
    }

    private HarvestCalendar createAndPersistHarvestCalendar(Harvest harvest, Date startDate, Date endDate) {
        HarvestCalendar harvestCalendar = new HarvestCalendar(harvest);
        harvestCalendar.setApprovedVolStart(startDate); // 1
        harvestCalendar.setApprovedVolEnd(endDate);
        harvestCalendar.setBenefittedVolStart(startDate); //2
        harvestCalendar.setBenefittedVolEnd(endDate);
        harvestCalendar.setFirstCommldVolStart(startDate); // 3
        harvestCalendar.setFirstCommldVolEnd(endDate);
        harvestCalendar.setSecondCommldVolStart(startDate); // 4
        harvestCalendar.setSecondCommldVolEnd(endDate);
        harvestCalendar.setThirdCommldVolStart(startDate); // 5
        harvestCalendar.setThirdCommldVolEnd(endDate);
        harvestCalendar.setInscribedAreaStart(startDate); // 6
        harvestCalendar.setInscribedAreaEnd(endDate);
        harvestCalendar.setHarvestDiscardedAreaStart(startDate); // 7
        harvestCalendar.setHarvestDiscardedAreaEnd(endDate);
        harvestCalendar.setUbsDestVolStart(startDate); // 8
        harvestCalendar.setUbsDestVolEnd(endDate);
        harvestCalendar.setNextHarvestVolStart(startDate); // 9
        harvestCalendar.setNextHarvestVolEnd(endDate);
        harvestCalendar.setOwnSeedVolUsedStart(startDate); // 10
        harvestCalendar.setOwnSeedVolUsedEnd(endDate);
        harvestCalendar.setMatrixSeedVolOwnedStart(startDate); // 11
        harvestCalendar.setMatrixSeedVolOwnedEnd(endDate);
        harvestCalendar.setHarvestVolStart(startDate); // 12
        harvestCalendar.setHarvestVolEnd(endDate);


        saveAndFlush(harvestCalendar);
        return harvestCalendar;
    }

    private void populateDetail(VolumeReportDetail detail) {
        for (VolumeReportFieldEnum fieldEnum : VolumeReportFieldEnum.values()) {
            if (fieldEnum.getGroupedFields() == null) {
                VolumeReportField fieldByPhase = detail.getFieldByPhase(fieldEnum);
                fieldByPhase.setValue(BigDecimal.valueOf(10L));
                fieldByPhase.setApproverLogin("USER_APPROVER");
                fieldByPhase.setReproverLogin("USER_REPROVER");
                if (fieldEnum.isGenerateCreditOnApproval()) {
                    fieldByPhase.setTransactionCode(1L);
                }
            }
        }

    }

    private void createEmailRegistration() {
        EmailByCustomerDistrictVolumeReport report = new EmailByCustomerDistrictVolumeReport(company1, crop1, itsDistrict.getDistrictSapId(), itsDistrict.getItsRegion().getItsUnity().getUnitySapId(),
                itsDistrict.getItsRegion().getRegionSapId(),
                "alanbk@ciandt.com", "alanbk@ciandt.com", "alanbk@ciandt.com", "alanbk@ciandt.com", "alanbk@ciandt.com", "alanbk@ciandt.com", "alanbk@ciandt.com", "alanbk@ciandt.com", "alanbk@ciandt.com", "alanbk@ciandt.com");
        saveAndFlush(report);
    }

    @Test
    public void sanity_test() {
        setupFixture();
        Harvest harvest = (Harvest) getSession().get(Harvest.class, HARVEST1);
        Obtainer obtainer = (Obtainer) getSession().get(Obtainer.class, OBTAINER1);
        HeadOffice headOffice = (HeadOffice) getSession().get(HeadOffice.class, HEADOFFICE1);
        Cultivar cultivar = (Cultivar) getSession().get(Cultivar.class, CULTIVAR1);
        ItsClass itsClass = (ItsClass) getSession().get(ItsClass.class, CLASS1);
        ItsClass itsClass2 = (ItsClass) getSession().get(ItsClass.class, CLASS2);

        VolumeReportHeader header = new VolumeReportHeader(harvest, headOffice.getCustomer(), headOffice.getMatrix(), obtainer);
        final VolumeReportDetail detail = new VolumeReportDetail(cultivar, itsClass, header);
        header.addVolumeReportDetail(detail);
        final VolumeReportDetail detail1 = new VolumeReportDetail(cultivar, itsClass2, header);
        header.addVolumeReportDetail(detail1);
        populateDetail(detail1);

        volumeReportService.save(header);
        getSession().flush();
        Assert.assertNotNull("Id shouldn't be null", header.getId());

        long id = header.getId();
        long detailId = detail.getId();
        long detailId1 = detail1.getId();
        getSession().flush();


        getSession().evict(header);
        getSession().evict(detail);
        getSession().evict(detail1);
        header = null;

        header = volumeReportService.selectById(id);

        Assert.assertEquals("Harvest should be same", harvest, header.getHarvest());
        Assert.assertEquals("Obtainer should be same", obtainer, header.getObtainer());
        Assert.assertEquals("Customer should be same", headOffice.getCustomer(), header.getCustomer());
        Assert.assertEquals("Matrix should be same", headOffice.getMatrix(), header.getMatrix());
        boolean foundDetail = false;
        boolean foundDetail1 = false;

        for (VolumeReportDetail d : header.getVolumeReportDetails()) {
            if (d.getId() == detailId) {
                foundDetail = true;
                Assert.assertEquals("Cultivar should be same", cultivar, d.getCultivar());
                Assert.assertEquals("ItsClass should be same", itsClass, d.getItsClass());
                Assert.assertEquals("VolumeReportHeader should be same", header, d.getVolumeReportHeader());
                sanityTestFields(d);
            } else if (d.getId() == detailId1) {
                foundDetail1 = true;
                Assert.assertEquals("Cultivar should be same", cultivar, d.getCultivar());
                Assert.assertEquals("ItsClass should be same", itsClass2, d.getItsClass());
                Assert.assertEquals("VolumeReportHeader should be same", header, d.getVolumeReportHeader());
                validatePhases(d);
                sanityTestFields(d);
            }
        }
        Assert.assertTrue("Did not find all the details", foundDetail);
        Assert.assertTrue("Did not find all the details", foundDetail1);
    }

    @Test
    public void test_select_by_filter() {
        setupFixture();
        Harvest harvest = (Harvest) getSession().get(Harvest.class, HARVEST1);
        HeadOffice headOffice = (HeadOffice) getSession().get(HeadOffice.class, HEADOFFICE8);
        Obtainer obtainer = (Obtainer) getSession().get(Obtainer.class, OBTAINER1);
        Cultivar cultivar = (Cultivar) getSession().get(Cultivar.class, CULTIVAR1);
        ItsClass itsClass = (ItsClass) getSession().get(ItsClass.class, CLASS1);
        ItsClass itsClass2 = (ItsClass) getSession().get(ItsClass.class, CLASS2);

        VolumeReportHeader header = new VolumeReportHeader(harvest, headOffice.getCustomer(), headOffice.getMatrix(), obtainer);
        final VolumeReportDetail detail = new VolumeReportDetail(cultivar, itsClass, header);
        header.addVolumeReportDetail(detail);
        final VolumeReportDetail detail1 = new VolumeReportDetail(cultivar, itsClass2, header);
        header.addVolumeReportDetail(detail1);

        volumeReportService.save(header);
        Assert.assertNotNull("Id shouldn't be null", header.getId());

//        long id = header.getId();
//        long detailId = detail.getId();
//        long detailId1 = detail1.getId();

        getSession().flush();

        getSession().evict(header);
        getSession().evict(detail);
        getSession().evict(detail1);
        header = null;

        VolumeReportFilter filter = VolumeReportFilter.getInstance().addHarvest(harvest);
        // Somente para cobertura, deve manter o harvest acima selecionado
        filter = VolumeReportFilter.getInstance().addHarvest(null);
        filter = VolumeReportFilter.getInstance().addObtainer(null);
        filter = VolumeReportFilter.getInstance().addHeadOffice(null);
        filter = VolumeReportFilter.getInstance().addHarvestList(null);

        List<VolumeReportHeader> list = volumeReportService.selectByFilter(filter);

        Assert.assertFalse("List should not be empty", list.isEmpty());

    }

    private void validatePhases(VolumeReportDetail d) {
        for (VolumeReportFieldEnum fieldEnum : VolumeReportFieldEnum.values()) {
            if (fieldEnum.getGroupedFields() == null) {
                VolumeReportField fieldByPhase = d.getFieldByPhase(fieldEnum);
                assertBigDecimalValue(fieldByPhase.getValue(), 10l);
                Assert.assertEquals("Should be user approver", "USER_APPROVER", fieldByPhase.getApproverLogin());
                Assert.assertEquals("Should be user approver", "USER_REPROVER", fieldByPhase.getReproverLogin());
                if (fieldEnum.isGenerateCreditOnApproval()) {
                    Assert.assertEquals("Should have id of 1", 1, fieldByPhase.getTransactionCode().longValue());
                }
            }
        }
    }

    private void sanityTestFields(VolumeReportDetail d) {
        Assert.assertEquals("Should be " + VolumeReportFieldEnum.ENTERED_AREA, VolumeReportFieldEnum.ENTERED_AREA, d.getEnteredArea().getVolumeReportField());
        Assert.assertEquals("Should be " + VolumeReportFieldEnum.OWN_SEED_USED, VolumeReportFieldEnum.OWN_SEED_USED, d.getOwnSeedUsed().getVolumeReportField());
        Assert.assertEquals("Should be " + VolumeReportFieldEnum.MATRIX_SEED_USED, VolumeReportFieldEnum.MATRIX_SEED_USED, d.getMatrixSeedUsed().getVolumeReportField());
        Assert.assertEquals("Should be " + VolumeReportFieldEnum.PORTIONING, VolumeReportFieldEnum.PORTIONING, d.getPortioning().getVolumeReportField());
        Assert.assertEquals("Should be " + VolumeReportFieldEnum.VOLUME_HARVEST, VolumeReportFieldEnum.VOLUME_HARVEST, d.getVolumeHarvested().getVolumeReportField());
        Assert.assertEquals("Should be " + VolumeReportFieldEnum.VOLUME_UBS, VolumeReportFieldEnum.VOLUME_UBS, d.getVolumeForUBS().getVolumeReportField());
        Assert.assertEquals("Should be " + VolumeReportFieldEnum.VOLUME_BENEFITTED, VolumeReportFieldEnum.VOLUME_BENEFITTED, d.getVolumeBenefitted().getVolumeReportField());
        Assert.assertEquals("Should be " + VolumeReportFieldEnum.VOLUME_APPROVED, VolumeReportFieldEnum.VOLUME_APPROVED, d.getVolumeApproved().getVolumeReportField());
        Assert.assertEquals("Should be " + VolumeReportFieldEnum.VOLUME_COMMERCIALIZED1, VolumeReportFieldEnum.VOLUME_COMMERCIALIZED1, d.getVolumeCommercialized1().getVolumeReportField());
        Assert.assertEquals("Should be " + VolumeReportFieldEnum.VOLUME_COMMERCIALIZED2, VolumeReportFieldEnum.VOLUME_COMMERCIALIZED2, d.getVolumeCommercialized2().getVolumeReportField());
        Assert.assertEquals("Should be " + VolumeReportFieldEnum.VOLUME_COMMERCIALIZED3, VolumeReportFieldEnum.VOLUME_COMMERCIALIZED3, d.getVolumeCommercialized3().getVolumeReportField());
        Assert.assertEquals("Should be " + VolumeReportFieldEnum.VOLUME_FOR_NEXT_HARVEST, VolumeReportFieldEnum.VOLUME_FOR_NEXT_HARVEST, d.getVolumeForNextHarvest().getVolumeReportField());
    }

    private void assertBigDecimalValue(BigDecimal bd1, double d) {
        Assert.assertTrue("Should be equal to " + d + " but is " + bd1.doubleValue(), bd1.compareTo(BigDecimal.valueOf(d)) == 0);
    }

    private void assertBigDecimalValue(BigDecimal bd1, long l) {
        Assert.assertTrue("Should be equal to " + l + " but is " + bd1.longValue(), bd1.compareTo(BigDecimal.valueOf(l)) == 0);
    }

    private void assertStringValue(String actuals, String expecteds) {
        Assert.assertEquals("Should be equals to " + expecteds + " but is " + actuals, expecteds, actuals);
    }
//    private void assertBigDecimalValue(BigDecimal bd1, int i) {
//        Assert.assertTrue("Should be equal to " + i + " but is " + bd1.longValue(), bd1.compareTo(BigDecimal.valueOf(i))==0);
//    }


    @Test
    public void given_obtainer_with_two_classes_and_three_cultivar_should_create_list_with_2_rows_2_items() {
        setupFixture();
        Obtainer obtainer = (Obtainer) getSession().get(Obtainer.class, OBTAINER1);
        Harvest harvest = (Harvest) getSession().get(Harvest.class, HARVEST1);
        HeadOffice headOffice = (HeadOffice) getSession().get(HeadOffice.class, HEADOFFICE8);
        VolumeReportClassesByCultivarDTO volumeReportClassesByCultivarDTO = volumeReportService.generateVolumeReportClassesConfigurationBy(headOffice, harvest, obtainer);
        Assert.assertEquals("Should have 2 classes", 2, volumeReportClassesByCultivarDTO.getClassList().size());
        Assert.assertEquals("Should have 2 cultivar", 5, volumeReportClassesByCultivarDTO.getCultivarClassValues().size());
    }

    @Test
    public void given_obtainer_without_classes_should_not_create_list() {
        setupFixture();

        Obtainer obtainer = (Obtainer) getSession().get(Obtainer.class, OBTAINER1);
        obtainer.getItsClasses().clear();
        saveAndFlush(obtainer);

        Harvest harvest = (Harvest) getSession().get(Harvest.class, HARVEST1);
        HeadOffice headOffice = (HeadOffice) getSession().get(HeadOffice.class, HEADOFFICE8);

        VolumeReportClassesByCultivarDTO volumeReportClassesByCultivarDTO = volumeReportService.generateVolumeReportClassesConfigurationBy(headOffice, harvest, obtainer);
        Assert.assertEquals("Should have 0 classes", 0, volumeReportClassesByCultivarDTO.getClassList().size());
        Assert.assertEquals("Should have 4 cultivar", 5, volumeReportClassesByCultivarDTO.getCultivarClassValues().size());
    }

    @Test
    public void when_detail_has_classes_and_cultivars_inactives_should_merge_list_from_detail_and_obtainer() {
        setupFixture();
        Obtainer obtainer = (Obtainer) getSession().get(Obtainer.class, 900000006L);
        Harvest harvest = (Harvest) getSession().get(Harvest.class, HARVEST1);
        HeadOffice headOffice = (HeadOffice) getSession().get(HeadOffice.class, HEADOFFICE8);
        VolumeReportClassesByCultivarDTO volumeReportClassesByCultivarDTO = volumeReportService.generateVolumeReportClassesConfigurationBy(headOffice, harvest, obtainer);
        Assert.assertEquals("Should have 3 classes", 3, volumeReportClassesByCultivarDTO.getClassList().size());
        Assert.assertEquals("Should have 2 cultivar", 2, volumeReportClassesByCultivarDTO.getCultivarClassValues().size());
    }

    @Test
    public void given_obtainer_with_2x2_cltxcls_when_update_with_2_detail_should_have_2_trues_set() {
        setupFixture();
        VolumeReportClassesByCultivarDTO volumeReportClassesByCultivarDTO = initializeVolumeReportHeader();
        VolumeReportHeader header;
        header = volumeReportService.selectById(HEADER_ID);
        volumeReportClassesByCultivarDTO.mergeCultivarClassListPairWithDetails(header.getVolumeReportDetails());
        countNumberOfSetClasses(volumeReportClassesByCultivarDTO, 2);

//        volumeReportClassesByCultivarDTO.getCultivarClassValues().get(1).getBooleanList().get(1).setClassSet(Boolean.TRUE);
    }

    @Test
    public void given_obtainer_with_2x2_and_harvest_headoffice_provided_should_find_header_with_2_values_set() {
        setupFixture();
        initializeVolumeReportHeader();
        VolumeReportClassesByCultivarDTO volumeReportClassesByCultivarDTO = volumeReportService.generateVolumeReportClassesConfigurationBy(headOffice, harvest, obtainer);
        countNumberOfSetClasses(volumeReportClassesByCultivarDTO, 2);

    }

    @Test
    public void given_obtainer_with_2x2_cltxcls_when_generate_table_then_save_with_no_changes_should_maintain_entities() {
        setupFixture();
        VolumeReportClassesByCultivarDTO volumeReportClassesByCultivarDTO = initializeVolumeReportHeader();
        VolumeReportHeader header;
        header = volumeReportService.selectById(HEADER_ID);
        volumeReportClassesByCultivarDTO.mergeCultivarClassListPairWithDetails(header.getVolumeReportDetails());

        Set<Long> idSet = new HashSet<Long>();
        Set<VolumeReportDetail> details = new HashSet<VolumeReportDetail>();
        for (VolumeReportDetail detail : header.getVolumeReportDetails()) {
            idSet.add(detail.getId());
            details.add(detail);
        }
        volumeReportService.mergeVolumeReportBy(header, volumeReportClassesByCultivarDTO);
        getSession().flush();


        getSession().evict(HEADER_ID);
        header = volumeReportService.selectById(HEADER_ID);
        for (VolumeReportDetail detail : header.getVolumeReportDetails()) {
            Assert.assertTrue(idSet.contains(detail.getId()));
            Assert.assertTrue(details.contains(detail));
            idSet.remove(detail.getId());
            details.remove(detail);
        }
        Assert.assertTrue("should be empty", idSet.isEmpty());
        Assert.assertTrue("should be empty", details.isEmpty());
    }

    @Test
    public void given_obtainer_with_2x2_cltxcls_when_generate_table_then_add_class_should_have_one_more_detail() {
        setupFixture();
        VolumeReportClassesByCultivarDTO volumeReportClassesByCultivarDTO = initializeVolumeReportHeader();
        VolumeReportHeader header;
        header = volumeReportService.selectById(HEADER_ID);
        volumeReportClassesByCultivarDTO.mergeCultivarClassListPairWithDetails(header.getVolumeReportDetails());
        ItsClass classSet = null;
        Cultivar cultivarSet = null;

        outer1:
        for (CultivarClassListPair cultivarClassListPair : volumeReportClassesByCultivarDTO.getCultivarClassValues()) {
            final List<ItsClassBooleanWrapper> booleanList = cultivarClassListPair.getBooleanList();
            for (int i = 0, booleanListSize = booleanList.size(); i < booleanListSize; i++) {
                final ItsClassBooleanWrapper booleanWrapper = booleanList.get(i);
                if (!booleanWrapper.getClassSet()) {
                    booleanWrapper.setClassSet(Boolean.TRUE);
                    cultivarSet = cultivarClassListPair.getCultivar();
                    classSet = volumeReportClassesByCultivarDTO.getClassList().get(i);
                    break outer1;
                }
            }

        }

        Set<Long> idSet = new HashSet<Long>();
        Set<VolumeReportDetail> details = new HashSet<VolumeReportDetail>();
        for (VolumeReportDetail detail : header.getVolumeReportDetails()) {
            idSet.add(detail.getId());
            details.add(detail);
        }
        volumeReportService.mergeVolumeReportBy(header, volumeReportClassesByCultivarDTO);
        getSession().flush();


        getSession().evict(HEADER_ID);
        header = volumeReportService.selectById(HEADER_ID);
        for (VolumeReportDetail detail : header.getVolumeReportDetails()) {
            if (idSet.contains(detail.getId())) {
                idSet.remove(detail.getId());
                details.remove(detail);
            } else {
                Assert.assertEquals("Should have same cultivar", cultivarSet, detail.getCultivar());
                Assert.assertEquals("Should have same class", classSet, detail.getItsClass());
            }
        }

        Assert.assertTrue("should be empty", idSet.isEmpty());
        Assert.assertTrue("should be empty", details.isEmpty());

    }

    @Test
    public void given_obtainer_with_2x2_when_generate_table_then_fetch_by_header_id_should_produce_correct_structure() {
        setupFixture();
        VolumeReportClassesByCultivarDTO volumeReportClassesByCultivarDTO = initializeVolumeReportHeader();
        VolumeReportHeader header = volumeReportService.selectById(HEADER_ID);
        volumeReportClassesByCultivarDTO.mergeCultivarClassListPairWithDetails(header.getVolumeReportDetails());
        VolumeReportClassesByCultivarDTO cultivarDTO = volumeReportService.fetchVolumeReportClassesConfigurationBy(HEADER_ID);
        final List<CultivarClassListPair> cultivarClassValues = volumeReportClassesByCultivarDTO.getCultivarClassValues();

        int count = 0;
        for (int i = 0, cultivarClassValuesSize = cultivarClassValues.size(); i < cultivarClassValuesSize; i++) {
            final CultivarClassListPair cultivarClassListPair = cultivarClassValues.get(i);
            final List<ItsClassBooleanWrapper> booleanList = cultivarClassListPair.getBooleanList();
            for (int j = 0, booleanListSize = booleanList.size(); j < booleanListSize; j++) {
                final ItsClassBooleanWrapper itsClassBooleanWrapper = booleanList.get(j);
                Assert.assertEquals("Should be equal", cultivarDTO.getCultivarClassValues().get(i).getBooleanList().get(j).getClassSet(), itsClassBooleanWrapper.getClassSet());
                if (cultivarDTO.getCultivarClassValues().get(i).getBooleanList().get(j).getClassSet()) {
                    count++;
                }
            }


        }
        Assert.assertEquals("Should have 2 set", 2, count);

    }

    @Test
    public void given_obtainer_with_2x2_cltxcls_when_generate_table_then_remove_class_should_have_one_fewer_detail() {
        setupFixture();
        VolumeReportClassesByCultivarDTO volumeReportClassesByCultivarDTO = initializeVolumeReportHeader();
        VolumeReportHeader header;
        header = volumeReportService.selectById(HEADER_ID);
        volumeReportClassesByCultivarDTO.mergeCultivarClassListPairWithDetails(header.getVolumeReportDetails());

        StateHelper state = new StateHelper();
        Set<Long> idSet = new HashSet<Long>();
        Set<VolumeReportDetail> details = new HashSet<VolumeReportDetail>();

        mergeReportAndStoreState(volumeReportClassesByCultivarDTO, header, state, idSet, details);
        validateDetailRemoval(state, idSet, details);
    }

    private void validateDetailRemoval(StateHelper state, Set<Long> idSet, Set<VolumeReportDetail> details) {
        final VolumeReportHeader header;
        header = volumeReportService.selectById(HEADER_ID);
        for (VolumeReportDetail detail : header.getVolumeReportDetails()) {
            if (idSet.contains(detail.getId())) {
                if (detail.getItsClass().equals(state.classSet) && detail.getCultivar().equals(state.cultivarSet)) {
                    Assert.fail("This detail line should not exist anymore");
                }
                idSet.remove(detail.getId());
                details.remove(detail);
            }
        }

        Assert.assertEquals("Should have only 1 entry", 1, details.size());
        VolumeReportDetail detail = details.iterator().next();
        Long idRemaining = idSet.iterator().next();
        Assert.assertEquals("Should have set itsclass", state.classSet, detail.getItsClass());
        Assert.assertEquals("Should have set cultivar", state.cultivarSet, detail.getCultivar());

        Object object = getSession().get(VolumeReportDetail.class, idRemaining);
        Assert.assertNull("Should not find value", object);
    }

    @Test
    public void given_obtainer_with_2x2_when_phase1_is_waiting_report_should_allow_removal() {
        setupFixture();
        VolumeReportClassesByCultivarDTO volumeReportClassesByCultivarDTO = initializeVolumeReportHeader();
        VolumeReportHeader header;
        header = volumeReportService.selectById(HEADER_ID);
        volumeReportClassesByCultivarDTO.mergeCultivarClassListPairWithDetails(header.getVolumeReportDetails());

        StateHelper state = new StateHelper();
        Set<Long> idSet = new HashSet<Long>();
        Set<VolumeReportDetail> details = new HashSet<VolumeReportDetail>();

        mergeReportAndStoreState(volumeReportClassesByCultivarDTO, header, state, idSet, details, VolumeReportStatus.WAITING_REPORT);
        validateDetailRemoval(state, idSet, details);
    }

    @Test
    public void given_obtainer_with_2x2_when_phase1_is_reported_should_allow_removal() {
        setupFixture();
        VolumeReportClassesByCultivarDTO volumeReportClassesByCultivarDTO = initializeVolumeReportHeader();
        VolumeReportHeader header;
        header = volumeReportService.selectById(HEADER_ID);
        volumeReportClassesByCultivarDTO.mergeCultivarClassListPairWithDetails(header.getVolumeReportDetails());

        StateHelper state = new StateHelper();
        Set<Long> idSet = new HashSet<Long>();
        Set<VolumeReportDetail> details = new HashSet<VolumeReportDetail>();

        mergeReportAndStoreState(volumeReportClassesByCultivarDTO, header, state, idSet, details, VolumeReportStatus.REPORTED);
        validateDetailRemoval(state, idSet, details);
    }

    @Test
    public void given_obtainer_with_2x2_when_phase1_is_approved_should_not_remove_detail_line() {
        setupFixture();
        VolumeReportClassesByCultivarDTO volumeReportClassesByCultivarDTO = initializeVolumeReportHeader();
        VolumeReportHeader header;
        header = volumeReportService.selectById(HEADER_ID);
        volumeReportClassesByCultivarDTO.mergeCultivarClassListPairWithDetails(header.getVolumeReportDetails());

        StateHelper state = new StateHelper();
        Set<Long> idSet = new HashSet<Long>();
        Set<VolumeReportDetail> details = new HashSet<VolumeReportDetail>();

        mergeReportAndStoreState(volumeReportClassesByCultivarDTO, header, state, idSet, details, VolumeReportStatus.APPROVED);

        header = volumeReportService.selectById(HEADER_ID);
        for (VolumeReportDetail detail : header.getVolumeReportDetails()) {
            if (idSet.contains(detail.getId())) {
                idSet.remove(detail.getId());
                details.remove(detail);
            }
        }
        Assert.assertTrue("Should be empty, all details before and after are the same", idSet.isEmpty());
    }

    private void mergeReportAndStoreState(VolumeReportClassesByCultivarDTO volumeReportClassesByCultivarDTO, VolumeReportHeader header, StateHelper state, Set<Long> idSet, Set<VolumeReportDetail> details) {
        mergeReportAndStoreState(volumeReportClassesByCultivarDTO, header, state, idSet, details, null);

    }

    private void mergeReportAndStoreState(VolumeReportClassesByCultivarDTO volumeReportClassesByCultivarDTO, VolumeReportHeader header, StateHelper state, Set<Long> idSet, Set<VolumeReportDetail> details, VolumeReportStatus status) {
        VolumeReportDetail detailSet = null;
        outer1:
        for (CultivarClassListPair cultivarClassListPair : volumeReportClassesByCultivarDTO.getCultivarClassValues()) {
            final List<ItsClassBooleanWrapper> booleanList = cultivarClassListPair.getBooleanList();
            for (int i = 0, booleanListSize = booleanList.size(); i < booleanListSize; i++) {
                final ItsClassBooleanWrapper booleanWrapper = booleanList.get(i);
                if (booleanWrapper.getClassSet()) {
                    booleanWrapper.setClassSet(Boolean.FALSE);
                    state.cultivarSet = cultivarClassListPair.getCultivar();
                    state.classSet = volumeReportClassesByCultivarDTO.getClassList().get(i);
                    break outer1;
                }
            }
        }

        for (VolumeReportDetail detail : header.getVolumeReportDetails()) {
            idSet.add(detail.getId());
            details.add(detail);
            if (status != null && detail.getItsClass().equals(state.classSet) && detail.getCultivar().equals(state.cultivarSet)) {
                detailSet = detail;
            }
        }
        if (detailSet != null) {
            detailSet.getEnteredArea().setValue(BigDecimal.TEN);
            detailSet.getOwnSeedUsed().setValue(BigDecimal.TEN);
            detailSet.getMatrixSeedUsed().setValue(BigDecimal.TEN);
            detailSet.setVolumeReportDetailPhase1Status(status);
        }
        volumeReportService.mergeVolumeReportBy(header, volumeReportClassesByCultivarDTO);
        getSession().flush();

        getSession().evict(header);
    }


    @Test
    public void given_a_header_and_a_harvestCalendar_when_i_inject_harvestCalendar_then_header_should_have_a_calendar() {
        setupFixture();
        initializeVolumeReportHeader();

        HarvestCalendar calendar = new HarvestCalendar(harvest);
        saveAndFlush(calendar);

        VolumeReportHeader header = volumeReportService.selectById(HEADER_ID);
        volumeReportService.injectHarvestCalendarIn(header);

        Assert.assertNotNull("Should return the calendar", header.getHarvestCalendar());
    }


    @Test
    public void given_a_harvest_that_dont_have_calendar_when_i_inject_harvestCalendar_then_header_should_not_have_a_calendar() {
        setupFixture();
        initializeVolumeReportHeader();

        Harvest anotherHarvest = (Harvest) getSession().get(Harvest.class, HARVEST2);
        HarvestCalendar calendar = new HarvestCalendar(anotherHarvest);
        saveAndFlush(calendar);

        VolumeReportHeader header = volumeReportService.selectById(HEADER_ID);
        volumeReportService.injectHarvestCalendarIn(header);

        Assert.assertNull("Should not return a calendar", header.getHarvestCalendar());
    }

    @Test
    public void given_a_header_with_obtainer_that_is_cooperative_when_i_select_volumeReport_then_should_return_a_header_with_flag_isObtainerCooperative_true() {
        setupFixture();
        initializeVolumeReportHeader();

        VolumeReportHeader header = volumeReportService.selectVolumeReport(HEADER_ID);
        Assert.assertTrue("Should be cooperative", header.isObtainerCooperative());
    }

    @Test
    public void given_a_harvest_calendar_when_i_select_volumeReport_then_should_return_a_header_with_harvestCalendar() {
        setupFixture();
        initializeVolumeReportHeader();

        HarvestCalendar calendar = new HarvestCalendar(harvest);
        saveAndFlush(calendar);

        VolumeReportHeader header = volumeReportService.selectVolumeReport(HEADER_ID);
        Assert.assertNotNull("Should have a harvest calendar injected", header.getHarvestCalendar());
    }

    @Test
    public void given_a_headerId_that_doesnt_exists_when_i_select_volumeReport_then_should_return_null() {
        Assert.assertNull("Should not have volumeReport", volumeReportService.selectVolumeReport(1L));
    }

    @Test(expected = IllegalStateException.class)
    public void given_two_volume_report_headers_for_same_parameters_when_try_and_fetch_should_throw_exception() {
        setupFixture();
        initializeVolumeReportHeader();

        VolumeReportHeader anotherHeader = new VolumeReportHeader(harvest, headOffice.getCustomer(), headOffice.getMatrix(), obtainer);
        saveAndFlush(anotherHeader);

        volumeReportService.generateVolumeReportClassesConfigurationBy(headOffice, harvest, obtainer);
    }

    @Test
    public void given_header_that_exists_when_save_should_not_create_new_one() {

        setupFixture();
        obtainer = (Obtainer) getSession().get(Obtainer.class, OBTAINER1);
        harvest = (Harvest) getSession().get(Harvest.class, HARVEST1);
        headOffice = (HeadOffice) getSession().get(HeadOffice.class, HEADOFFICE8);
        VolumeReportClassesByCultivarDTO volumeReportClassesByCultivarDTO = volumeReportService.generateVolumeReportClassesConfigurationBy(headOffice, harvest, obtainer);


        int count = 0;
        outer1:
        for (CultivarClassListPair cultivarClassListPair : volumeReportClassesByCultivarDTO.getCultivarClassValues()) {
            final List<ItsClassBooleanWrapper> booleanList = cultivarClassListPair.getBooleanList();
            for (int i = 0, booleanListSize = booleanList.size(); i < booleanListSize; i++) {
                final ItsClassBooleanWrapper booleanWrapper = booleanList.get(i);
                if (!booleanWrapper.getClassSet()) {
                    booleanWrapper.setClassSet(Boolean.TRUE);
                    count++;
                    if (count > 1) {
                        break outer1;
                    }
                }
            }

        }
        volumeReportService.saveConfig(volumeReportClassesByCultivarDTO);
        List<VolumeReportHeader> volumeReportHeaders = volumeReportService.selectByFilter(VolumeReportFilter.getInstance().addObtainer(volumeReportClassesByCultivarDTO.getObtainer()).addCustomerMatrix(volumeReportClassesByCultivarDTO.getCustomer(), volumeReportClassesByCultivarDTO.getMatrix()).addHarvest(volumeReportClassesByCultivarDTO.getHarvest()));
        Assert.assertEquals("Should find 1", 1, volumeReportHeaders.size());
        Assert.assertNotNull("should have id", volumeReportHeaders.iterator().next().getId());
        Long id = volumeReportHeaders.iterator().next().getId();

        volumeReportClassesByCultivarDTO = volumeReportService.generateVolumeReportClassesConfigurationBy(headOffice, volumeReportClassesByCultivarDTO.getHarvest(), volumeReportClassesByCultivarDTO.getObtainer());
        volumeReportService.saveConfig(volumeReportClassesByCultivarDTO);
        volumeReportHeaders = volumeReportService.selectByFilter(VolumeReportFilter.getInstance().addObtainer(volumeReportClassesByCultivarDTO.getObtainer()).addCustomerMatrix(volumeReportClassesByCultivarDTO.getCustomer(), volumeReportClassesByCultivarDTO.getMatrix()).addHarvest(volumeReportClassesByCultivarDTO.getHarvest()));
        Assert.assertEquals("Should find 1", 1, volumeReportHeaders.size());
        Assert.assertEquals("Id should match", id, volumeReportHeaders.iterator().next().getId());

    }

    @Test
    public void given_header_doesnt_exist_when_saveConfig_should_generate_new_volume_report_header() {
        setupFixture();
        obtainer = (Obtainer) getSession().get(Obtainer.class, OBTAINER1);
        harvest = (Harvest) getSession().get(Harvest.class, HARVEST1);
        headOffice = (HeadOffice) getSession().get(HeadOffice.class, HEADOFFICE8);
        VolumeReportClassesByCultivarDTO volumeReportClassesByCultivarDTO = volumeReportService.generateVolumeReportClassesConfigurationBy(headOffice, harvest, obtainer);


        int count = 0;
        outer1:
        for (CultivarClassListPair cultivarClassListPair : volumeReportClassesByCultivarDTO.getCultivarClassValues()) {
            final List<ItsClassBooleanWrapper> booleanList = cultivarClassListPair.getBooleanList();
            for (int i = 0, booleanListSize = booleanList.size(); i < booleanListSize; i++) {
                final ItsClassBooleanWrapper booleanWrapper = booleanList.get(i);
                if (!booleanWrapper.getClassSet()) {
                    booleanWrapper.setClassSet(Boolean.TRUE);
                    count++;
                    if (count > 1) {
                        break outer1;
                    }
                }
            }

        }
        volumeReportService.saveConfig(volumeReportClassesByCultivarDTO);
        List<VolumeReportHeader> volumeReportHeaders = volumeReportService.selectByFilter(VolumeReportFilter.getInstance().addObtainer(volumeReportClassesByCultivarDTO.getObtainer()).addCustomerMatrix(volumeReportClassesByCultivarDTO.getCustomer(), volumeReportClassesByCultivarDTO.getMatrix()).addHarvest(volumeReportClassesByCultivarDTO.getHarvest()));
        Assert.assertEquals("Should find 1", 1, volumeReportHeaders.size());
        Assert.assertNotNull("should have id", volumeReportHeaders.iterator().next().getId());

    }

    private Harvest getHarvest(Long id) {
        return (Harvest) getSession().get(Harvest.class, id);
    }

    private HeadOffice getHeadOffice(Long id) {
        return (HeadOffice) getSession().get(HeadOffice.class, id);
    }

    private Obtainer getObtainer(Long id) {
        return (Obtainer) getSession().get(Obtainer.class, id);
    }

    private ItsClass getItsClass(Long id) {
        return (ItsClass) getSession().get(ItsClass.class, id);
    }

    private Cultivar getCultivar(Long id) {
        return (Cultivar) getSession().get(Cultivar.class, id);
    }

    private void updateHeaderDetailsWithProductivity(VolumeReportHeader header) {
        for (VolumeReportDetail detail : header.getVolumeReportDetails()) {
            detail.setProductivity(BigInteger.TEN);
        }
    }

    @Test
    public void given_report_with_no_fields_set_when_save_and_submit_should_do_nothing() throws UserNotFoundException, ConstraintException {
        setupFixture();
        VolumeReportHeader header = VolumeReportTestData.generateVolumeReportHeader(getHarvest(HARVEST1), getHeadOffice(HEADOFFICE2), getObtainer(OBTAINER1),
                new ItsClass[]{getItsClass(CLASS1)}, new Cultivar[]{getCultivar(CULTIVAR8)});

        saveAndFlush(header);
        getSession().evict(header);
        header = volumeReportService.selectVolumeReport(header.getId());
        updateHeaderDetailsWithProductivity(header);
        UserDecorator user = userService.getAuthenticatedUserBy("DANDRADE_S");
        volumeReportDetailService.submitReport(header.getVolumeReportDetails(), localeBR, resourceBundle, user);
        getSession().flush();
        VolumeReportDetail detail = header.getVolumeReportDetails().iterator().next();
        detail.setProductivity(BigInteger.TEN);

        assertPhase1Statuses(detail, new VolumeReportStatus[]{VolumeReportStatus.WAITING_REPORT, VolumeReportStatus.WAITING_REPORT, VolumeReportStatus.WAITING_REPORT});
        assertPhase2Statuses(detail, new VolumeReportStatus[]{VolumeReportStatus.WAITING_REPORT, VolumeReportStatus.WAITING_REPORT, VolumeReportStatus.WAITING_REPORT, VolumeReportStatus.WAITING_REPORT});
        assertPhase3Statuses(detail, new VolumeReportStatus[]{VolumeReportStatus.WAITING_REPORT});
        assertPhase4Statuses(detail, new VolumeReportStatus[]{VolumeReportStatus.WAITING_REPORT});
        assertPhase5Statuses(detail, new VolumeReportStatus[]{VolumeReportStatus.WAITING_REPORT, VolumeReportStatus.WAITING_REPORT, VolumeReportStatus.WAITING_REPORT});
        assertPhase6Statuses(detail, new VolumeReportStatus[]{VolumeReportStatus.WAITING_REPORT});
    }

    @Test
    public void given_report_with_phase1_fields_set_when_save_and_submit_should_set_status_to_reported() throws UserNotFoundException, ConstraintException {
        setupFixture();
        createEmailRegistration();
        createAndPersistHarvestCalendar((Harvest) getSession().get(Harvest.class, HARVEST1), currentDateStart, currentDateEnd);
        VolumeReportHeader header = VolumeReportTestData.generateVolumeReportHeader(getHarvest(HARVEST1), getHeadOffice(HEADOFFICE2), getObtainer(OBTAINER1),
                new ItsClass[]{getItsClass(CLASS1)}, new Cultivar[]{getCultivar(CULTIVAR8)});

        saveAndFlush(header);
        getSession().evict(header);
        header = volumeReportService.selectVolumeReport(header.getId());

        VolumeReportDetail detail = header.getVolumeReportDetails().iterator().next();
        detail.setProductivity(BigInteger.TEN);
        UserDecorator user = userService.getAuthenticatedUserBy("DANDRADE_S");
        VolumeReportTestData.fillWithValues(detail, new VolumeReportFieldEnum[]{VolumeReportFieldEnum.ENTERED_AREA, VolumeReportFieldEnum.OWN_SEED_USED, VolumeReportFieldEnum.MATRIX_SEED_USED}, VolumeReportTestData.VALID_VALUE);
        volumeReportDetailService.submitReport(header.getVolumeReportDetails(), localeBR, resourceBundle, user);
        getSession().flush();

        assertPhase1Statuses(detail, new VolumeReportStatus[]{VolumeReportStatus.REPORTED, VolumeReportStatus.REPORTED, VolumeReportStatus.REPORTED});
        assertPhase2Statuses(detail, new VolumeReportStatus[]{VolumeReportStatus.WAITING_REPORT, VolumeReportStatus.WAITING_REPORT, VolumeReportStatus.WAITING_REPORT});
        assertPhase3Statuses(detail, new VolumeReportStatus[]{VolumeReportStatus.WAITING_REPORT});
        assertPhase4Statuses(detail, new VolumeReportStatus[]{VolumeReportStatus.WAITING_REPORT});
        assertPhase5Statuses(detail, new VolumeReportStatus[]{VolumeReportStatus.WAITING_REPORT, VolumeReportStatus.WAITING_REPORT, VolumeReportStatus.WAITING_REPORT});
        assertPhase6Statuses(detail, new VolumeReportStatus[]{VolumeReportStatus.WAITING_REPORT});
        assertEmails(1);
    }

    @Test
    public void given_a_detail_and_cultivar_charge_technology_when_save_and_submit_phase1_fields_should_not_change_revenue_account_id() throws UserNotFoundException, ConstraintException {
        setupFixture();
        createEmailRegistration();
        createAndPersistHarvestCalendar((Harvest) getSession().get(Harvest.class, HARVEST1), currentDateStart, currentDateEnd);
        VolumeReportHeader header = VolumeReportTestData.generateVolumeReportHeader(getHarvest(HARVEST1), getHeadOffice(HEADOFFICE2), getObtainer(OBTAINER1),
                new ItsClass[]{getItsClass(CLASS1)}, new Cultivar[]{getCultivar(CULTIVAR8)});

        saveAndFlush(header);
        getSession().evict(header);
        header = volumeReportService.selectVolumeReport(header.getId());

        Long revenueId = 900000001L;

        VolumeReportDetail detail = header.getVolumeReportDetails().iterator().next();
        detail.setRevenueAccountId(revenueId);
        detail.setProductivity(BigInteger.TEN);

        UserDecorator user = userService.getAuthenticatedUserBy("DANDRADE_S");
        VolumeReportTestData.fillWithValues(detail, new VolumeReportFieldEnum[]{VolumeReportFieldEnum.ENTERED_AREA, VolumeReportFieldEnum.OWN_SEED_USED, VolumeReportFieldEnum.MATRIX_SEED_USED}, VolumeReportTestData.VALID_VALUE);
        volumeReportDetailService.submitReport(header.getVolumeReportDetails(), localeBR, resourceBundle, user);
        getSession().flush();

        Assert.assertEquals("Revenue account id does not match", revenueId, detail.getRevenueAccountId());
        assertPhase1Statuses(detail, new VolumeReportStatus[]{VolumeReportStatus.REPORTED, VolumeReportStatus.REPORTED, VolumeReportStatus.REPORTED});
        assertPhase2Statuses(detail, new VolumeReportStatus[]{VolumeReportStatus.WAITING_REPORT, VolumeReportStatus.WAITING_REPORT, VolumeReportStatus.WAITING_REPORT});
        assertPhase3Statuses(detail, new VolumeReportStatus[]{VolumeReportStatus.WAITING_REPORT});
        assertPhase4Statuses(detail, new VolumeReportStatus[]{VolumeReportStatus.WAITING_REPORT});
        assertPhase5Statuses(detail, new VolumeReportStatus[]{VolumeReportStatus.WAITING_REPORT, VolumeReportStatus.WAITING_REPORT, VolumeReportStatus.WAITING_REPORT});
        assertPhase6Statuses(detail, new VolumeReportStatus[]{VolumeReportStatus.WAITING_REPORT});
        assertEmails(1);
    }

    @Test
    public void given_a_detail_and_cultivar_do_not_charge_technology_when_save_and_submit_phase1_fields_should_set_revenue_account_id_to_null() throws UserNotFoundException, ConstraintException {
        setupFixture();
        createEmailRegistration();
        createAndPersistHarvestCalendar((Harvest) getSession().get(Harvest.class, HARVEST1), currentDateStart, currentDateEnd);
        VolumeReportHeader header = VolumeReportTestData.generateVolumeReportHeader(getHarvest(HARVEST1), getHeadOffice(HEADOFFICE2), getObtainer(OBTAINER1),
                new ItsClass[]{getItsClass(CLASS1)}, new Cultivar[]{getCultivar(CULTIVAR8)});

        saveAndFlush(header);
        getSession().evict(header);
        header = volumeReportService.selectVolumeReport(header.getId());

        VolumeReportDetail detail = header.getVolumeReportDetails().iterator().next();
        detail.setRevenueAccountId(900000001L);
        detail.getCultivar().setChargeTechnology(Boolean.FALSE);
        detail.setProductivity(BigInteger.TEN);

        UserDecorator user = userService.getAuthenticatedUserBy("DANDRADE_S");
        VolumeReportTestData.fillWithValues(detail, new VolumeReportFieldEnum[]{VolumeReportFieldEnum.ENTERED_AREA, VolumeReportFieldEnum.OWN_SEED_USED, VolumeReportFieldEnum.MATRIX_SEED_USED}, VolumeReportTestData.VALID_VALUE);
        volumeReportDetailService.submitReport(header.getVolumeReportDetails(), localeBR, resourceBundle, user);
        getSession().flush();

        Assert.assertNull("Revenue account id should be null", detail.getRevenueAccountId());
        assertPhase1Statuses(detail, new VolumeReportStatus[]{VolumeReportStatus.REPORTED, VolumeReportStatus.REPORTED, VolumeReportStatus.REPORTED});
        assertPhase2Statuses(detail, new VolumeReportStatus[]{VolumeReportStatus.WAITING_REPORT, VolumeReportStatus.WAITING_REPORT, VolumeReportStatus.WAITING_REPORT});
        assertPhase3Statuses(detail, new VolumeReportStatus[]{VolumeReportStatus.WAITING_REPORT});
        assertPhase4Statuses(detail, new VolumeReportStatus[]{VolumeReportStatus.WAITING_REPORT});
        assertPhase5Statuses(detail, new VolumeReportStatus[]{VolumeReportStatus.WAITING_REPORT, VolumeReportStatus.WAITING_REPORT, VolumeReportStatus.WAITING_REPORT});
        assertPhase6Statuses(detail, new VolumeReportStatus[]{VolumeReportStatus.WAITING_REPORT});
        assertEmails(1);
    }

    @Test
    public void given_a_detail_and_cultivar_do_not_charge_technology_when_save_and_submit_any_phase_other_than_phase1_should_not_change_revenue_account_id() throws UserNotFoundException, ConstraintException {
        setupFixture();
        createEmailRegistration();
        createAndPersistHarvestCalendar((Harvest) getSession().get(Harvest.class, HARVEST1), currentDateStart, currentDateEnd);
        VolumeReportHeader header = VolumeReportTestData.generateVolumeReportHeader(getHarvest(HARVEST1), getHeadOffice(HEADOFFICE2), getObtainer(OBTAINER1),
                new ItsClass[]{getItsClass(CLASS1)}, new Cultivar[]{getCultivar(CULTIVAR8)});

        VolumeReportDetail detail = header.getVolumeReportDetails().iterator().next();
        VolumeReportTestData.fillWithValues(detail, new VolumeReportFieldEnum[]{VolumeReportFieldEnum.ENTERED_AREA, VolumeReportFieldEnum.OWN_SEED_USED, VolumeReportFieldEnum.MATRIX_SEED_USED}, VolumeReportTestData.VALID_VALUE);
        detail.setRevenueAccountId(900000001L);
        VolumeReportTestData.updateToPhase2_2(detail);

        saveAndFlush(header);
        getSession().evict(header);
        header = volumeReportService.selectVolumeReport(header.getId());

        Long revenueId = 900000001L;

        detail = header.getVolumeReportDetails().iterator().next();
        detail.setRevenueAccountId(revenueId);
        detail.getCultivar().setChargeTechnology(Boolean.FALSE);
        detail.setProductivity(BigInteger.TEN);

        UserDecorator user = userService.getAuthenticatedUserBy("DANDRADE_S");
        VolumeReportTestData.fillWithValues(detail, new VolumeReportFieldEnum[]{VolumeReportFieldEnum.ENTERED_AREA, VolumeReportFieldEnum.OWN_SEED_USED, VolumeReportFieldEnum.MATRIX_SEED_USED}, VolumeReportTestData.VALID_VALUE);
        volumeReportDetailService.submitReport(header.getVolumeReportDetails(), localeBR, resourceBundle, user);
        getSession().flush();

        Assert.assertEquals("Revenue account id does not match", revenueId, detail.getRevenueAccountId());
        assertPhase1Statuses(detail, new VolumeReportStatus[]{VolumeReportStatus.APPROVED});
        assertPhase2Statuses(detail, new VolumeReportStatus[]{VolumeReportStatus.APPROVED, VolumeReportStatus.WAITING_REPORT, VolumeReportStatus.WAITING_REPORT});
        assertPhase3Statuses(detail, new VolumeReportStatus[]{VolumeReportStatus.WAITING_REPORT});
        assertPhase4Statuses(detail, new VolumeReportStatus[]{VolumeReportStatus.WAITING_REPORT});
        assertPhase5Statuses(detail, new VolumeReportStatus[]{VolumeReportStatus.WAITING_REPORT, VolumeReportStatus.WAITING_REPORT, VolumeReportStatus.WAITING_REPORT});
        assertPhase6Statuses(detail, new VolumeReportStatus[]{VolumeReportStatus.WAITING_REPORT});
        assertEmails(1);
    }

    @Test
    public void given_report_with_phase1_fields_set_with_no_customer_district_should_send_zero_emails() throws UserNotFoundException, ConstraintException {
        setupFixture();
        createEmailRegistration();
        createAndPersistHarvestCalendar((Harvest) getSession().get(Harvest.class, HARVEST1), currentDateStart, currentDateEnd);
        getSession().createQuery("delete from CustomerDistrict").executeUpdate();
        VolumeReportHeader header = VolumeReportTestData.generateVolumeReportHeader(getHarvest(HARVEST1), getHeadOffice(HEADOFFICE2), getObtainer(OBTAINER1),
                new ItsClass[]{getItsClass(CLASS1)}, new Cultivar[]{getCultivar(CULTIVAR8)});

        saveAndFlush(header);
        getSession().evict(header);
        header = volumeReportService.selectVolumeReport(header.getId());

        VolumeReportDetail detail = header.getVolumeReportDetails().iterator().next();
        detail.setProductivity(BigInteger.TEN);
        UserDecorator user = userService.getAuthenticatedUserBy("DANDRADE_S");
        VolumeReportTestData.fillWithValues(detail, new VolumeReportFieldEnum[]{VolumeReportFieldEnum.ENTERED_AREA, VolumeReportFieldEnum.OWN_SEED_USED, VolumeReportFieldEnum.MATRIX_SEED_USED}, VolumeReportTestData.VALID_VALUE);
        volumeReportDetailService.submitReport(header.getVolumeReportDetails(), localeBR, resourceBundle, user);
        getSession().flush();

        assertPhase1Statuses(detail, new VolumeReportStatus[]{VolumeReportStatus.REPORTED, VolumeReportStatus.REPORTED, VolumeReportStatus.REPORTED});
        assertPhase2Statuses(detail, new VolumeReportStatus[]{VolumeReportStatus.WAITING_REPORT, VolumeReportStatus.WAITING_REPORT, VolumeReportStatus.WAITING_REPORT});
        assertPhase3Statuses(detail, new VolumeReportStatus[]{VolumeReportStatus.WAITING_REPORT});
        assertPhase4Statuses(detail, new VolumeReportStatus[]{VolumeReportStatus.WAITING_REPORT});
        assertPhase5Statuses(detail, new VolumeReportStatus[]{VolumeReportStatus.WAITING_REPORT, VolumeReportStatus.WAITING_REPORT, VolumeReportStatus.WAITING_REPORT});
        assertPhase6Statuses(detail, new VolumeReportStatus[]{VolumeReportStatus.WAITING_REPORT});
        assertEmails(0);
    }

    @Test
    public void given_report_with_phase1_fields_set_but_no_email_reports_registered_should_send_0_emails() throws UserNotFoundException, ConstraintException {
        setupFixture();
        createAndPersistHarvestCalendar((Harvest) getSession().get(Harvest.class, HARVEST1), currentDateStart, currentDateEnd);
        VolumeReportHeader header = VolumeReportTestData.generateVolumeReportHeader(getHarvest(HARVEST1), getHeadOffice(HEADOFFICE2), getObtainer(OBTAINER1),
                new ItsClass[]{getItsClass(CLASS1)}, new Cultivar[]{getCultivar(CULTIVAR8)});

        saveAndFlush(header);
        getSession().evict(header);
        header = volumeReportService.selectVolumeReport(header.getId());

        VolumeReportDetail detail = header.getVolumeReportDetails().iterator().next();
        detail.setProductivity(BigInteger.TEN);
        UserDecorator user = userService.getAuthenticatedUserBy("DANDRADE_S");
        VolumeReportTestData.fillWithValues(detail, new VolumeReportFieldEnum[]{VolumeReportFieldEnum.ENTERED_AREA, VolumeReportFieldEnum.OWN_SEED_USED, VolumeReportFieldEnum.MATRIX_SEED_USED}, VolumeReportTestData.VALID_VALUE);
        volumeReportDetailService.submitReport(header.getVolumeReportDetails(), localeBR, resourceBundle, user);
        getSession().flush();

        assertPhase1Statuses(detail, new VolumeReportStatus[]{VolumeReportStatus.REPORTED, VolumeReportStatus.REPORTED, VolumeReportStatus.REPORTED});
        assertPhase2Statuses(detail, new VolumeReportStatus[]{VolumeReportStatus.WAITING_REPORT, VolumeReportStatus.WAITING_REPORT, VolumeReportStatus.WAITING_REPORT});
        assertPhase3Statuses(detail, new VolumeReportStatus[]{VolumeReportStatus.WAITING_REPORT});
        assertPhase4Statuses(detail, new VolumeReportStatus[]{VolumeReportStatus.WAITING_REPORT});
        assertPhase5Statuses(detail, new VolumeReportStatus[]{VolumeReportStatus.WAITING_REPORT, VolumeReportStatus.WAITING_REPORT, VolumeReportStatus.WAITING_REPORT});
        assertPhase6Statuses(detail, new VolumeReportStatus[]{VolumeReportStatus.WAITING_REPORT});
        assertEmails(0);
    }

    @Test
    public void given_report_with_only_one_phase1_field_enabled_but_all_fields_filled_should_update_status() throws UserNotFoundException, ConstraintException {
        setupFixture();
        HarvestCalendar harvestCalendar = createAndPersistHarvestCalendar((Harvest) getSession().get(Harvest.class, HARVEST1), currentDateStart, currentDateEnd);
        harvestCalendar.setOwnSeedVolUsedStart(futureDateStart);
        harvestCalendar.setOwnSeedVolUsedEnd(futureDateEnd);
        harvestCalendar.setMatrixSeedVolOwnedStart(futureDateStart);
        harvestCalendar.setMatrixSeedVolOwnedEnd(futureDateEnd);
        saveAndFlush(harvestCalendar);
        VolumeReportHeader header = VolumeReportTestData.generateVolumeReportHeader(getHarvest(HARVEST1), getHeadOffice(HEADOFFICE2), getObtainer(OBTAINER1),
                new ItsClass[]{getItsClass(CLASS1)}, new Cultivar[]{getCultivar(CULTIVAR8)});

        saveAndFlush(header);
        getSession().evict(header);
        header = volumeReportService.selectVolumeReport(header.getId());

        VolumeReportDetail detail = header.getVolumeReportDetails().iterator().next();
        detail.setProductivity(BigInteger.TEN);
        UserDecorator user = userService.getAuthenticatedUserBy("DANDRADE_S");
        VolumeReportTestData.fillWithValues(detail, new VolumeReportFieldEnum[]{VolumeReportFieldEnum.ENTERED_AREA, VolumeReportFieldEnum.OWN_SEED_USED, VolumeReportFieldEnum.MATRIX_SEED_USED}, VolumeReportTestData.VALID_VALUE);
        volumeReportDetailService.submitReport(header.getVolumeReportDetails(), localeBR, resourceBundle, user);
        getSession().flush();

        assertPhase1Statuses(detail, new VolumeReportStatus[]{VolumeReportStatus.REPORTED, VolumeReportStatus.REPORTED, VolumeReportStatus.REPORTED});
        assertPhase2Statuses(detail, new VolumeReportStatus[]{VolumeReportStatus.WAITING_REPORT, VolumeReportStatus.WAITING_REPORT, VolumeReportStatus.WAITING_REPORT});

    }

    @Test
    public void given_report_with_only_entered_area_phase1_field_filled_in_should_not_change_status() throws UserNotFoundException, ConstraintException {
        setupFixture();
        HarvestCalendar harvestCalendar = createAndPersistHarvestCalendar((Harvest) getSession().get(Harvest.class, HARVEST1), currentDateStart, currentDateEnd);
        harvestCalendar.setOwnSeedVolUsedStart(futureDateStart);
        harvestCalendar.setOwnSeedVolUsedEnd(futureDateEnd);
        harvestCalendar.setMatrixSeedVolOwnedStart(futureDateStart);
        harvestCalendar.setMatrixSeedVolOwnedEnd(futureDateEnd);
        saveAndFlush(harvestCalendar);
        VolumeReportHeader header = VolumeReportTestData.generateVolumeReportHeader(getHarvest(HARVEST1), getHeadOffice(HEADOFFICE2), getObtainer(OBTAINER1),
                new ItsClass[]{getItsClass(CLASS1)}, new Cultivar[]{getCultivar(CULTIVAR8)});

        saveAndFlush(header);
        getSession().evict(header);
        header = volumeReportService.selectVolumeReport(header.getId());

        VolumeReportDetail detail = header.getVolumeReportDetails().iterator().next();
        detail.setProductivity(BigInteger.TEN);
        UserDecorator user = userService.getAuthenticatedUserBy("DANDRADE_S");
        detail.getEnteredArea().setValue(VolumeReportTestData.VALID_VALUE);
        volumeReportDetailService.submitReport(header.getVolumeReportDetails(), localeBR, resourceBundle, user);
        getSession().flush();

        assertPhase1Statuses(detail, new VolumeReportStatus[]{VolumeReportStatus.WAITING_REPORT, VolumeReportStatus.WAITING_REPORT, VolumeReportStatus.WAITING_REPORT});
        assertPhase2Statuses(detail, new VolumeReportStatus[]{VolumeReportStatus.WAITING_REPORT, VolumeReportStatus.WAITING_REPORT, VolumeReportStatus.WAITING_REPORT, VolumeReportStatus.WAITING_REPORT});

    }

    @Test
    public void given_report_with_only_matrix_area_phase1_field_filled_in_should_not_change_status() throws UserNotFoundException, ConstraintException {
        setupFixture();
        HarvestCalendar harvestCalendar = createAndPersistHarvestCalendar((Harvest) getSession().get(Harvest.class, HARVEST1), currentDateStart, currentDateEnd);
        harvestCalendar.setOwnSeedVolUsedStart(futureDateStart);
        harvestCalendar.setOwnSeedVolUsedEnd(futureDateEnd);
        harvestCalendar.setInscribedAreaStart(futureDateStart);
        harvestCalendar.setInscribedAreaEnd(futureDateEnd);
        saveAndFlush(harvestCalendar);
        VolumeReportHeader header = VolumeReportTestData.generateVolumeReportHeader(getHarvest(HARVEST1), getHeadOffice(HEADOFFICE2), getObtainer(OBTAINER1),
                new ItsClass[]{getItsClass(CLASS1)}, new Cultivar[]{getCultivar(CULTIVAR8)});

        saveAndFlush(header);
        getSession().evict(header);
        header = volumeReportService.selectVolumeReport(header.getId());

        VolumeReportDetail detail = header.getVolumeReportDetails().iterator().next();
        detail.setProductivity(BigInteger.TEN);
        UserDecorator user = userService.getAuthenticatedUserBy("DANDRADE_S");
        detail.getMatrixSeedUsed().setValue(VolumeReportTestData.VALID_VALUE);
        volumeReportDetailService.submitReport(header.getVolumeReportDetails(), localeBR, resourceBundle, user);
        getSession().flush();

        assertPhase1Statuses(detail, new VolumeReportStatus[]{VolumeReportStatus.WAITING_REPORT, VolumeReportStatus.WAITING_REPORT, VolumeReportStatus.WAITING_REPORT});
        assertPhase2Statuses(detail, new VolumeReportStatus[]{VolumeReportStatus.WAITING_REPORT, VolumeReportStatus.WAITING_REPORT, VolumeReportStatus.WAITING_REPORT, VolumeReportStatus.WAITING_REPORT});

    }

    @Test
    public void given_report_with_only_own_area_phase1_field_filled_in_should_not_change_status() throws UserNotFoundException, ConstraintException {
        setupFixture();
        HarvestCalendar harvestCalendar = createAndPersistHarvestCalendar((Harvest) getSession().get(Harvest.class, HARVEST1), currentDateStart, currentDateEnd);
        harvestCalendar.setInscribedAreaStart(futureDateStart);
        harvestCalendar.setInscribedAreaEnd(futureDateEnd);
        harvestCalendar.setMatrixSeedVolOwnedStart(futureDateStart);
        harvestCalendar.setMatrixSeedVolOwnedEnd(futureDateEnd);
        saveAndFlush(harvestCalendar);
        VolumeReportHeader header = VolumeReportTestData.generateVolumeReportHeader(getHarvest(HARVEST1), getHeadOffice(HEADOFFICE2), getObtainer(OBTAINER1),
                new ItsClass[]{getItsClass(CLASS1)}, new Cultivar[]{getCultivar(CULTIVAR8)});

        saveAndFlush(header);
        getSession().evict(header);
        header = volumeReportService.selectVolumeReport(header.getId());

        VolumeReportDetail detail = header.getVolumeReportDetails().iterator().next();
        detail.setProductivity(BigInteger.TEN);
        UserDecorator user = userService.getAuthenticatedUserBy("DANDRADE_S");
        detail.getOwnSeedUsed().setValue(VolumeReportTestData.VALID_VALUE);
        volumeReportDetailService.submitReport(header.getVolumeReportDetails(), localeBR, resourceBundle, user);
        getSession().flush();

        assertPhase1Statuses(detail, new VolumeReportStatus[]{VolumeReportStatus.WAITING_REPORT, VolumeReportStatus.WAITING_REPORT, VolumeReportStatus.WAITING_REPORT});
        assertPhase2Statuses(detail, new VolumeReportStatus[]{VolumeReportStatus.WAITING_REPORT, VolumeReportStatus.WAITING_REPORT, VolumeReportStatus.WAITING_REPORT, VolumeReportStatus.WAITING_REPORT});

    }


    @Test
    public void given_report_with_more_than_one_detail_when_update_one_to_phase1_other_should_not_be_touched() throws UserNotFoundException, ConstraintException {
        setupFixture();
        createEmailRegistration();
        createAndPersistHarvestCalendar((Harvest) getSession().get(Harvest.class, HARVEST1), currentDateStart, currentDateEnd);
        VolumeReportHeader header = VolumeReportTestData.generateVolumeReportHeader(getHarvest(HARVEST1), getHeadOffice(HEADOFFICE2), getObtainer(OBTAINER1),
                new ItsClass[]{getItsClass(CLASS1), getItsClass(CLASS2)}, new Cultivar[]{getCultivar(CULTIVAR8)});

        saveAndFlush(header);
        getSession().evict(header);
        header = volumeReportService.selectVolumeReport(header.getId());

        Iterator<VolumeReportDetail> iterator = header.getVolumeReportDetails().iterator();
        VolumeReportDetail detail1 = iterator.next();
        detail1.setProductivity(BigInteger.TEN);
        VolumeReportDetail detail2 = iterator.next();
        detail2.setProductivity(BigInteger.TEN);
        UserDecorator user = userService.getAuthenticatedUserBy("DANDRADE_S");
        VolumeReportTestData.fillWithValues(detail1, new VolumeReportFieldEnum[]{VolumeReportFieldEnum.ENTERED_AREA, VolumeReportFieldEnum.OWN_SEED_USED, VolumeReportFieldEnum.MATRIX_SEED_USED}, VolumeReportTestData.VALID_VALUE);
        volumeReportDetailService.submitReport(header.getVolumeReportDetails(), localeBR, resourceBundle, user);
        getSession().flush();

        assertPhase1Statuses(detail1, new VolumeReportStatus[]{VolumeReportStatus.REPORTED, VolumeReportStatus.REPORTED, VolumeReportStatus.REPORTED});
        assertPhase2Statuses(detail1, new VolumeReportStatus[]{VolumeReportStatus.WAITING_REPORT, VolumeReportStatus.WAITING_REPORT, VolumeReportStatus.WAITING_REPORT});
        assertPhase3Statuses(detail1, new VolumeReportStatus[]{VolumeReportStatus.WAITING_REPORT});
        assertPhase4Statuses(detail1, new VolumeReportStatus[]{VolumeReportStatus.WAITING_REPORT});
        assertPhase5Statuses(detail1, new VolumeReportStatus[]{VolumeReportStatus.WAITING_REPORT, VolumeReportStatus.WAITING_REPORT, VolumeReportStatus.WAITING_REPORT});
        assertPhase6Statuses(detail1, new VolumeReportStatus[]{VolumeReportStatus.WAITING_REPORT});
        assertEmails(1);
        assertPhase1Statuses(detail2, new VolumeReportStatus[]{VolumeReportStatus.WAITING_REPORT, VolumeReportStatus.WAITING_REPORT, VolumeReportStatus.WAITING_REPORT});
        assertPhase2Statuses(detail2, new VolumeReportStatus[]{VolumeReportStatus.WAITING_REPORT, VolumeReportStatus.WAITING_REPORT, VolumeReportStatus.WAITING_REPORT, VolumeReportStatus.WAITING_REPORT});
        assertPhase3Statuses(detail2, new VolumeReportStatus[]{VolumeReportStatus.WAITING_REPORT});
        assertPhase4Statuses(detail2, new VolumeReportStatus[]{VolumeReportStatus.WAITING_REPORT});
        assertPhase5Statuses(detail2, new VolumeReportStatus[]{VolumeReportStatus.WAITING_REPORT, VolumeReportStatus.WAITING_REPORT, VolumeReportStatus.WAITING_REPORT});
        assertPhase6Statuses(detail2, new VolumeReportStatus[]{VolumeReportStatus.WAITING_REPORT});
    }


    @Test
    public void given_report_with_phase1_fields_set_when_save_and_submit_then_submit_again_should_send_email_again() throws UserNotFoundException, ConstraintException {
        setupFixture();
        createEmailRegistration();
        createAndPersistHarvestCalendar((Harvest) getSession().get(Harvest.class, HARVEST1), currentDateStart, currentDateEnd);
        VolumeReportHeader header = VolumeReportTestData.generateVolumeReportHeader(getHarvest(HARVEST1), getHeadOffice(HEADOFFICE2), getObtainer(OBTAINER1),
                new ItsClass[]{getItsClass(CLASS1)}, new Cultivar[]{getCultivar(CULTIVAR8)});

        saveAndFlush(header);
        getSession().evict(header);
        header = volumeReportService.selectVolumeReport(header.getId());
        updateHeaderDetailsWithProductivity(header);

        VolumeReportDetail detail = header.getVolumeReportDetails().iterator().next();
        detail.setProductivity(BigInteger.TEN);
        UserDecorator user = userService.getAuthenticatedUserBy("DANDRADE_S");
        VolumeReportTestData.fillWithValues(detail, new VolumeReportFieldEnum[]{VolumeReportFieldEnum.ENTERED_AREA, VolumeReportFieldEnum.OWN_SEED_USED, VolumeReportFieldEnum.MATRIX_SEED_USED}, VolumeReportTestData.VALID_VALUE);
        volumeReportDetailService.submitReport(header.getVolumeReportDetails(), localeBR, resourceBundle, user);
        getSession().flush();

        assertPhase1Statuses(detail, new VolumeReportStatus[]{VolumeReportStatus.REPORTED, VolumeReportStatus.REPORTED, VolumeReportStatus.REPORTED});
        assertPhase2Statuses(detail, new VolumeReportStatus[]{VolumeReportStatus.WAITING_REPORT, VolumeReportStatus.WAITING_REPORT, VolumeReportStatus.WAITING_REPORT});
        assertPhase3Statuses(detail, new VolumeReportStatus[]{VolumeReportStatus.WAITING_REPORT});
        assertPhase4Statuses(detail, new VolumeReportStatus[]{VolumeReportStatus.WAITING_REPORT});
        assertPhase5Statuses(detail, new VolumeReportStatus[]{VolumeReportStatus.WAITING_REPORT, VolumeReportStatus.WAITING_REPORT, VolumeReportStatus.WAITING_REPORT});
        assertPhase6Statuses(detail, new VolumeReportStatus[]{VolumeReportStatus.WAITING_REPORT});
        assertEmails(1);
        header = volumeReportService.selectVolumeReport(header.getId());
        volumeReportDetailService.submitReport(header.getVolumeReportDetails(), localeBR, resourceBundle, user);
        getSession().flush();
        assertPhase1Statuses(detail, new VolumeReportStatus[]{VolumeReportStatus.REPORTED, VolumeReportStatus.REPORTED, VolumeReportStatus.REPORTED});
        assertEmails(2);
    }

    @Test
    public void given_phase2_portioning_reported_with_no_discard_should_update_status_to_reported() throws UserNotFoundException, ConstraintException {
        setupFixture();
        createEmailRegistration();
        createAndPersistHarvestCalendar((Harvest) getSession().get(Harvest.class, HARVEST1), currentDateStart, currentDateEnd);
        VolumeReportHeader header = VolumeReportTestData.generateVolumeReportHeader(getHarvest(HARVEST1), getHeadOffice(HEADOFFICE2), getObtainer(OBTAINER1),
                new ItsClass[]{getItsClass(CLASS1)}, new Cultivar[]{getCultivar(CULTIVAR8)});

        VolumeReportDetail detail = header.getVolumeReportDetails().iterator().next();
        VolumeReportTestData.fillWithValues(detail, new VolumeReportFieldEnum[]{VolumeReportFieldEnum.ENTERED_AREA, VolumeReportFieldEnum.OWN_SEED_USED, VolumeReportFieldEnum.MATRIX_SEED_USED}, VolumeReportTestData.VALID_VALUE);
        VolumeReportTestData.updateToPhase2_1(detail);
        detail.setNotUseDiscardPortioning(true);
        saveAndFlush(header);

        getSession().evict(header);
        header = volumeReportService.selectVolumeReport(header.getId());
        updateHeaderDetailsWithProductivity(header);


        detail = header.getVolumeReportDetails().iterator().next();
        UserDecorator user = userService.getAuthenticatedUserBy("DANDRADE_S");
        VolumeReportTestData.fillWithValues(detail, new VolumeReportFieldEnum[]{VolumeReportFieldEnum.PORTIONING, VolumeReportFieldEnum.VOLUME_HARVEST, VolumeReportFieldEnum.VOLUME_UBS}, VolumeReportTestData.VALID_VALUE);
        volumeReportDetailService.submitReport(header.getVolumeReportDetails(), localeBR, resourceBundle, user);
        getSession().flush();

        assertPhase1Statuses(detail, new VolumeReportStatus[]{VolumeReportStatus.APPROVED});
        assertPhase2Statuses(detail, new VolumeReportStatus[]{VolumeReportStatus.REPORTED, VolumeReportStatus.WAITING_REPORT, VolumeReportStatus.WAITING_REPORT});
        assertPhase3Statuses(detail, new VolumeReportStatus[]{VolumeReportStatus.WAITING_REPORT});
        assertPhase4Statuses(detail, new VolumeReportStatus[]{VolumeReportStatus.WAITING_REPORT});
        assertPhase5Statuses(detail, new VolumeReportStatus[]{VolumeReportStatus.WAITING_REPORT, VolumeReportStatus.WAITING_REPORT, VolumeReportStatus.WAITING_REPORT});
        assertPhase6Statuses(detail, new VolumeReportStatus[]{VolumeReportStatus.WAITING_REPORT});
        assertEmails(1);
    }


    @Test
    public void given_phase2_portioning_reported_with_discard_should_update_status_to_reported() throws UserNotFoundException, ConstraintException {
        setupFixture();
        createEmailRegistration();
        createAndPersistHarvestCalendar((Harvest) getSession().get(Harvest.class, HARVEST1), currentDateStart, currentDateEnd);
        VolumeReportHeader header = VolumeReportTestData.generateVolumeReportHeader(getHarvest(HARVEST1), getHeadOffice(HEADOFFICE2), getObtainer(OBTAINER1),
                new ItsClass[]{getItsClass(CLASS1)}, new Cultivar[]{getCultivar(CULTIVAR8)});

        VolumeReportDetail detail = header.getVolumeReportDetails().iterator().next();
        VolumeReportTestData.fillWithValues(detail, new VolumeReportFieldEnum[]{VolumeReportFieldEnum.ENTERED_AREA, VolumeReportFieldEnum.OWN_SEED_USED, VolumeReportFieldEnum.MATRIX_SEED_USED}, VolumeReportTestData.VALID_VALUE);
        VolumeReportTestData.updateToPhase2_1(detail);
        Grower grower = (Grower) getSession().get(Grower.class, GROWER1);
        detail.addDiscardPortioning(new DiscardPortioning(grower, detail, BigDecimal.TEN));
        saveAndFlush(header);

        getSession().evict(header);
        header = volumeReportService.selectVolumeReport(header.getId());
        updateHeaderDetailsWithProductivity(header);

        detail = header.getVolumeReportDetails().iterator().next();
        UserDecorator user = userService.getAuthenticatedUserBy("DANDRADE_S");
        VolumeReportTestData.fillWithValues(detail, new VolumeReportFieldEnum[]{VolumeReportFieldEnum.PORTIONING, VolumeReportFieldEnum.VOLUME_HARVEST, VolumeReportFieldEnum.VOLUME_UBS}, VolumeReportTestData.VALID_VALUE);
        volumeReportDetailService.submitReport(header.getVolumeReportDetails(), localeBR, resourceBundle, user);
        getSession().flush();

        assertPhase1Statuses(detail, new VolumeReportStatus[]{VolumeReportStatus.APPROVED});
        assertPhase2Statuses(detail, new VolumeReportStatus[]{VolumeReportStatus.REPORTED, VolumeReportStatus.WAITING_REPORT, VolumeReportStatus.WAITING_REPORT});
        assertPhase3Statuses(detail, new VolumeReportStatus[]{VolumeReportStatus.WAITING_REPORT});
        assertPhase4Statuses(detail, new VolumeReportStatus[]{VolumeReportStatus.WAITING_REPORT});
        assertPhase5Statuses(detail, new VolumeReportStatus[]{VolumeReportStatus.WAITING_REPORT, VolumeReportStatus.WAITING_REPORT, VolumeReportStatus.WAITING_REPORT});
        assertPhase6Statuses(detail, new VolumeReportStatus[]{VolumeReportStatus.WAITING_REPORT});
        assertEmails(1);
    }

    @Test
    public void given_report_with_phase2_1_fields_set_when_save_and_submit_should_set_status_to_reported() throws UserNotFoundException, ConstraintException {
        setupFixture();
        createEmailRegistration();
        createAndPersistHarvestCalendar((Harvest) getSession().get(Harvest.class, HARVEST1), currentDateStart, currentDateEnd);
        VolumeReportHeader header = VolumeReportTestData.generateVolumeReportHeader(getHarvest(HARVEST1), getHeadOffice(HEADOFFICE2), getObtainer(OBTAINER1),
                new ItsClass[]{getItsClass(CLASS1)}, new Cultivar[]{getCultivar(CULTIVAR8)});

        VolumeReportDetail detail = header.getVolumeReportDetails().iterator().next();
        VolumeReportTestData.fillWithValues(detail, new VolumeReportFieldEnum[]{VolumeReportFieldEnum.ENTERED_AREA, VolumeReportFieldEnum.OWN_SEED_USED, VolumeReportFieldEnum.MATRIX_SEED_USED}, VolumeReportTestData.VALID_VALUE);
        VolumeReportTestData.updateToPhase2_2(detail);
        saveAndFlush(header);

        getSession().evict(header);
        header = volumeReportService.selectVolumeReport(header.getId());
        updateHeaderDetailsWithProductivity(header);

        detail = header.getVolumeReportDetails().iterator().next();
        UserDecorator user = userService.getAuthenticatedUserBy("DANDRADE_S");
        VolumeReportTestData.fillWithValues(detail, new VolumeReportFieldEnum[]{VolumeReportFieldEnum.PORTIONING, VolumeReportFieldEnum.VOLUME_HARVEST, VolumeReportFieldEnum.VOLUME_UBS}, VolumeReportTestData.VALID_VALUE);
        volumeReportDetailService.submitReport(header.getVolumeReportDetails(), localeBR, resourceBundle, user);
        getSession().flush();

        assertPhase1Statuses(detail, new VolumeReportStatus[]{VolumeReportStatus.APPROVED});
        assertPhase2Statuses(detail, new VolumeReportStatus[]{VolumeReportStatus.APPROVED, VolumeReportStatus.REPORTED, VolumeReportStatus.WAITING_REPORT});
        assertPhase3Statuses(detail, new VolumeReportStatus[]{VolumeReportStatus.WAITING_REPORT});
        assertPhase4Statuses(detail, new VolumeReportStatus[]{VolumeReportStatus.WAITING_REPORT});
        assertPhase5Statuses(detail, new VolumeReportStatus[]{VolumeReportStatus.WAITING_REPORT, VolumeReportStatus.WAITING_REPORT, VolumeReportStatus.WAITING_REPORT});
        assertPhase6Statuses(detail, new VolumeReportStatus[]{VolumeReportStatus.WAITING_REPORT});
        assertEmails(1);
    }

    @Test
    public void given_report_with_phase2_2_fields_set_when_save_and_submit_should_set_status_to_reported() throws UserNotFoundException, ConstraintException {
        setupFixture();
        createEmailRegistration();
        createAndPersistHarvestCalendar((Harvest) getSession().get(Harvest.class, HARVEST1), currentDateStart, currentDateEnd);
        VolumeReportHeader header = VolumeReportTestData.generateVolumeReportHeader(getHarvest(HARVEST1), getHeadOffice(HEADOFFICE2), getObtainer(OBTAINER1),
                new ItsClass[]{getItsClass(CLASS1)}, new Cultivar[]{getCultivar(CULTIVAR8)});

        VolumeReportDetail detail = header.getVolumeReportDetails().iterator().next();
        VolumeReportTestData.fillWithValues(detail, new VolumeReportFieldEnum[]{VolumeReportFieldEnum.ENTERED_AREA, VolumeReportFieldEnum.OWN_SEED_USED, VolumeReportFieldEnum.MATRIX_SEED_USED}, VolumeReportTestData.VALID_VALUE);
        VolumeReportTestData.updateToPhase2_2(detail);
        saveAndFlush(header);

        getSession().evict(header);
        header = volumeReportService.selectVolumeReport(header.getId());
        updateHeaderDetailsWithProductivity(header);

        detail = header.getVolumeReportDetails().iterator().next();
        UserDecorator user = userService.getAuthenticatedUserBy("DANDRADE_S");
        VolumeReportTestData.fillWithValues(detail, new VolumeReportFieldEnum[]{VolumeReportFieldEnum.PORTIONING, VolumeReportFieldEnum.VOLUME_HARVEST, VolumeReportFieldEnum.VOLUME_UBS}, VolumeReportTestData.VALID_VALUE);
        volumeReportDetailService.submitReport(header.getVolumeReportDetails(), localeBR, resourceBundle, user);
        getSession().flush();

        assertPhase1Statuses(detail, new VolumeReportStatus[]{VolumeReportStatus.APPROVED});
        assertPhase2Statuses(detail, new VolumeReportStatus[]{VolumeReportStatus.APPROVED, VolumeReportStatus.REPORTED, VolumeReportStatus.WAITING_REPORT});
        assertPhase3Statuses(detail, new VolumeReportStatus[]{VolumeReportStatus.WAITING_REPORT});
        assertPhase4Statuses(detail, new VolumeReportStatus[]{VolumeReportStatus.WAITING_REPORT});
        assertPhase5Statuses(detail, new VolumeReportStatus[]{VolumeReportStatus.WAITING_REPORT, VolumeReportStatus.WAITING_REPORT, VolumeReportStatus.WAITING_REPORT});
        assertPhase6Statuses(detail, new VolumeReportStatus[]{VolumeReportStatus.WAITING_REPORT});
        assertEmails(1);
    }

    @Test
    public void given_report_with_phase2_3_fields_set_when_save_and_submit_should_set_status_to_reported() throws UserNotFoundException, ConstraintException {
        setupFixture();
        createEmailRegistration();
        createAndPersistHarvestCalendar((Harvest) getSession().get(Harvest.class, HARVEST1), currentDateStart, currentDateEnd);
        VolumeReportHeader header = VolumeReportTestData.generateVolumeReportHeader(getHarvest(HARVEST1), getHeadOffice(HEADOFFICE2), getObtainer(OBTAINER1),
                new ItsClass[]{getItsClass(CLASS1)}, new Cultivar[]{getCultivar(CULTIVAR8)});

        VolumeReportDetail detail = header.getVolumeReportDetails().iterator().next();
        VolumeReportTestData.fillWithValues(detail, new VolumeReportFieldEnum[]{VolumeReportFieldEnum.ENTERED_AREA, VolumeReportFieldEnum.OWN_SEED_USED, VolumeReportFieldEnum.MATRIX_SEED_USED}, VolumeReportTestData.VALID_VALUE);
        VolumeReportTestData.updateToPhase2_3(detail);
        saveAndFlush(header);

        getSession().evict(header);
        header = volumeReportService.selectVolumeReport(header.getId());
        updateHeaderDetailsWithProductivity(header);

        detail = header.getVolumeReportDetails().iterator().next();
        UserDecorator user = userService.getAuthenticatedUserBy("DANDRADE_S");
        VolumeReportTestData.fillWithValues(detail, new VolumeReportFieldEnum[]{VolumeReportFieldEnum.PORTIONING, VolumeReportFieldEnum.VOLUME_HARVEST, VolumeReportFieldEnum.VOLUME_UBS}, VolumeReportTestData.VALID_VALUE);
        volumeReportDetailService.submitReport(header.getVolumeReportDetails(), localeBR, resourceBundle, user);
        getSession().flush();

        assertPhase1Statuses(detail, new VolumeReportStatus[]{VolumeReportStatus.APPROVED});
        assertPhase2Statuses(detail, new VolumeReportStatus[]{VolumeReportStatus.APPROVED, VolumeReportStatus.APPROVED, VolumeReportStatus.REPORTED});
        assertPhase3Statuses(detail, new VolumeReportStatus[]{VolumeReportStatus.WAITING_REPORT});
        assertPhase4Statuses(detail, new VolumeReportStatus[]{VolumeReportStatus.WAITING_REPORT});
        assertPhase5Statuses(detail, new VolumeReportStatus[]{VolumeReportStatus.WAITING_REPORT, VolumeReportStatus.WAITING_REPORT, VolumeReportStatus.WAITING_REPORT});
        assertPhase6Statuses(detail, new VolumeReportStatus[]{VolumeReportStatus.WAITING_REPORT});
        assertEmails(1);
    }

    @Test
    public void given_report_with_phase3_fields_set_when_save_and_submit_should_set_status_to_reported() throws UserNotFoundException, ConstraintException {
        setupFixture();
        createEmailRegistration();
        createAndPersistHarvestCalendar((Harvest) getSession().get(Harvest.class, HARVEST1), currentDateStart, currentDateEnd);
        VolumeReportHeader header = VolumeReportTestData.generateVolumeReportHeader(getHarvest(HARVEST1), getHeadOffice(HEADOFFICE2), getObtainer(OBTAINER1),
                new ItsClass[]{getItsClass(CLASS1)}, new Cultivar[]{getCultivar(CULTIVAR8)});


        saveAndFlush(header);

        getSession().evict(header);
        header = volumeReportService.selectVolumeReport(header.getId());

        VolumeReportDetail detail = header.getVolumeReportDetails().iterator().next();
        VolumeReportTestData.fillWithValues(detail, new VolumeReportFieldEnum[]{VolumeReportFieldEnum.ENTERED_AREA, VolumeReportFieldEnum.OWN_SEED_USED, VolumeReportFieldEnum.MATRIX_SEED_USED}, VolumeReportTestData.VALID_VALUE);
        VolumeReportTestData.fillWithValues(detail, new VolumeReportFieldEnum[]{VolumeReportFieldEnum.PORTIONING, VolumeReportFieldEnum.VOLUME_HARVEST, VolumeReportFieldEnum.VOLUME_UBS}, VolumeReportTestData.VALID_VALUE);
        VolumeReportTestData.updateToPhase3(detail);
        saveAndFlush(header);
        getSession().evict(header);
        header = volumeReportService.selectVolumeReport(header.getId());
        updateHeaderDetailsWithProductivity(header);
        detail = header.getVolumeReportDetails().iterator().next();


        UserDecorator user = userService.getAuthenticatedUserBy("DANDRADE_S");
        VolumeReportTestData.fillWithValues(detail, new VolumeReportFieldEnum[]{VolumeReportFieldEnum.VOLUME_BENEFITTED}, VolumeReportTestData.VALID_VALUE);
        volumeReportDetailService.submitReport(header.getVolumeReportDetails(), localeBR, resourceBundle, user);
        getSession().flush();

        assertPhase1Statuses(detail, new VolumeReportStatus[]{VolumeReportStatus.APPROVED});
        assertPhase2Statuses(detail, new VolumeReportStatus[]{VolumeReportStatus.APPROVED, VolumeReportStatus.APPROVED, VolumeReportStatus.APPROVED});
        assertPhase3Statuses(detail, new VolumeReportStatus[]{VolumeReportStatus.REPORTED});
        assertPhase4Statuses(detail, new VolumeReportStatus[]{VolumeReportStatus.WAITING_REPORT});
        assertPhase5Statuses(detail, new VolumeReportStatus[]{VolumeReportStatus.WAITING_REPORT, VolumeReportStatus.WAITING_REPORT, VolumeReportStatus.WAITING_REPORT});
        assertPhase6Statuses(detail, new VolumeReportStatus[]{VolumeReportStatus.WAITING_REPORT});
        assertEmails(1);
    }


    @Test
    public void given_report_with_phase4_fields_set_when_save_and_submit_should_set_status_to_reported() throws UserNotFoundException, ConstraintException {
        setupFixture();
        createEmailRegistration();
        createAndPersistHarvestCalendar((Harvest) getSession().get(Harvest.class, HARVEST1), currentDateStart, currentDateEnd);
        VolumeReportHeader header = VolumeReportTestData.generateVolumeReportHeader(getHarvest(HARVEST1), getHeadOffice(HEADOFFICE2), getObtainer(OBTAINER1),
                new ItsClass[]{getItsClass(CLASS1)}, new Cultivar[]{getCultivar(CULTIVAR8)});


        saveAndFlush(header);

        getSession().evict(header);
        header = volumeReportService.selectVolumeReport(header.getId());

        VolumeReportDetail detail = header.getVolumeReportDetails().iterator().next();
        VolumeReportTestData.fillWithValues(detail, new VolumeReportFieldEnum[]{VolumeReportFieldEnum.ENTERED_AREA, VolumeReportFieldEnum.OWN_SEED_USED, VolumeReportFieldEnum.MATRIX_SEED_USED}, VolumeReportTestData.VALID_VALUE);
        VolumeReportTestData.fillWithValues(detail, new VolumeReportFieldEnum[]{VolumeReportFieldEnum.PORTIONING, VolumeReportFieldEnum.VOLUME_HARVEST, VolumeReportFieldEnum.VOLUME_UBS}, VolumeReportTestData.VALID_VALUE);
        VolumeReportTestData.updateToPhase4(detail);
        saveAndFlush(header);
        getSession().evict(header);
        header = volumeReportService.selectVolumeReport(header.getId());
        updateHeaderDetailsWithProductivity(header);
        detail = header.getVolumeReportDetails().iterator().next();


        UserDecorator user = userService.getAuthenticatedUserBy("DANDRADE_S");
        VolumeReportTestData.fillWithValues(detail, new VolumeReportFieldEnum[]{VolumeReportFieldEnum.VOLUME_APPROVED}, VolumeReportTestData.VALID_VALUE);
        volumeReportDetailService.submitReport(header.getVolumeReportDetails(), localeBR, resourceBundle, user);
        getSession().flush();

        assertPhase1Statuses(detail, new VolumeReportStatus[]{VolumeReportStatus.APPROVED});
        assertPhase2Statuses(detail, new VolumeReportStatus[]{VolumeReportStatus.APPROVED, VolumeReportStatus.APPROVED, VolumeReportStatus.APPROVED});
        assertPhase3Statuses(detail, new VolumeReportStatus[]{VolumeReportStatus.APPROVED});
        assertPhase4Statuses(detail, new VolumeReportStatus[]{VolumeReportStatus.REPORTED});
        assertPhase5Statuses(detail, new VolumeReportStatus[]{VolumeReportStatus.WAITING_REPORT, VolumeReportStatus.WAITING_REPORT, VolumeReportStatus.WAITING_REPORT});
        assertPhase6Statuses(detail, new VolumeReportStatus[]{VolumeReportStatus.WAITING_REPORT});
        assertEmails(1);
    }


    @Test
    public void given_report_with_phase5_1_fields_set_when_save_and_submit_should_set_status_to_reported() throws UserNotFoundException, ConstraintException {
        setupFixture();
        createEmailRegistration();
        createAndPersistHarvestCalendar((Harvest) getSession().get(Harvest.class, HARVEST1), currentDateStart, currentDateEnd);
        VolumeReportHeader header = VolumeReportTestData.generateVolumeReportHeader(getHarvest(HARVEST1), getHeadOffice(HEADOFFICE2), getObtainer(OBTAINER1),
                new ItsClass[]{getItsClass(CLASS1)}, new Cultivar[]{getCultivar(CULTIVAR8)});


        saveAndFlush(header);

        getSession().evict(header);
        header = volumeReportService.selectVolumeReport(header.getId());

        VolumeReportDetail detail = header.getVolumeReportDetails().iterator().next();
        VolumeReportTestData.fillWithValues(detail, new VolumeReportFieldEnum[]{VolumeReportFieldEnum.ENTERED_AREA, VolumeReportFieldEnum.OWN_SEED_USED, VolumeReportFieldEnum.MATRIX_SEED_USED}, VolumeReportTestData.VALID_VALUE);
        VolumeReportTestData.fillWithValues(detail, new VolumeReportFieldEnum[]{VolumeReportFieldEnum.PORTIONING, VolumeReportFieldEnum.VOLUME_HARVEST, VolumeReportFieldEnum.VOLUME_UBS}, VolumeReportTestData.VALID_VALUE);
        VolumeReportTestData.fillWithValues(detail, new VolumeReportFieldEnum[]{VolumeReportFieldEnum.VOLUME_BENEFITTED}, VolumeReportTestData.VALID_VALUE);
        VolumeReportTestData.fillWithValues(detail, new VolumeReportFieldEnum[]{VolumeReportFieldEnum.VOLUME_APPROVED}, VolumeReportTestData.VALID_VALUE);
        VolumeReportTestData.updateToPhase5(detail);
        saveAndFlush(header);
        getSession().evict(header);
        header = volumeReportService.selectVolumeReport(header.getId());
        updateHeaderDetailsWithProductivity(header);
        detail = header.getVolumeReportDetails().iterator().next();


        UserDecorator user = userService.getAuthenticatedUserBy("DANDRADE_S");
//        VolumeReportTestData.fillWithValues(detail.getVolumeReportDetailPhase5(), VolumeReportTestData.VALID_VALUE);
        VolumeReportTestData.fillWithValues(detail, new VolumeReportFieldEnum[]{VolumeReportFieldEnum.VOLUME_COMMERCIALIZED1}, VolumeReportTestData.VALID_VALUE);
        volumeReportDetailService.submitReport(header.getVolumeReportDetails(), localeBR, resourceBundle, user);
        getSession().flush();

        assertPhase1Statuses(detail, new VolumeReportStatus[]{VolumeReportStatus.APPROVED});
        assertPhase2Statuses(detail, new VolumeReportStatus[]{VolumeReportStatus.APPROVED, VolumeReportStatus.APPROVED, VolumeReportStatus.APPROVED});
        assertPhase3Statuses(detail, new VolumeReportStatus[]{VolumeReportStatus.APPROVED});
        assertPhase4Statuses(detail, new VolumeReportStatus[]{VolumeReportStatus.APPROVED});
        assertPhase5Statuses(detail, new VolumeReportStatus[]{VolumeReportStatus.REPORTED, VolumeReportStatus.WAITING_REPORT, VolumeReportStatus.WAITING_REPORT});
        assertPhase6Statuses(detail, new VolumeReportStatus[]{VolumeReportStatus.WAITING_REPORT});
        assertEmails(1);
    }


    @Test
    public void given_report_with_phase5_2_fields_set_when_save_and_submit_should_set_status_to_reported() throws UserNotFoundException, ConstraintException {
        setupFixture();
        createEmailRegistration();
        createAndPersistHarvestCalendar((Harvest) getSession().get(Harvest.class, HARVEST1), currentDateStart, currentDateEnd);
        VolumeReportHeader header = VolumeReportTestData.generateVolumeReportHeader(getHarvest(HARVEST1), getHeadOffice(HEADOFFICE2), getObtainer(OBTAINER1),
                new ItsClass[]{getItsClass(CLASS1)}, new Cultivar[]{getCultivar(CULTIVAR8)});


        saveAndFlush(header);

        getSession().evict(header);
        header = volumeReportService.selectVolumeReport(header.getId());

        VolumeReportDetail detail = header.getVolumeReportDetails().iterator().next();
        VolumeReportTestData.fillWithValues(detail, new VolumeReportFieldEnum[]{VolumeReportFieldEnum.ENTERED_AREA, VolumeReportFieldEnum.OWN_SEED_USED, VolumeReportFieldEnum.MATRIX_SEED_USED}, VolumeReportTestData.VALID_VALUE);
        VolumeReportTestData.fillWithValues(detail, new VolumeReportFieldEnum[]{VolumeReportFieldEnum.PORTIONING, VolumeReportFieldEnum.VOLUME_HARVEST, VolumeReportFieldEnum.VOLUME_UBS}, VolumeReportTestData.VALID_VALUE);
        VolumeReportTestData.fillWithValues(detail, new VolumeReportFieldEnum[]{VolumeReportFieldEnum.VOLUME_BENEFITTED}, VolumeReportTestData.VALID_VALUE);
        VolumeReportTestData.fillWithValues(detail, new VolumeReportFieldEnum[]{VolumeReportFieldEnum.VOLUME_APPROVED}, VolumeReportTestData.VALID_VALUE);
        VolumeReportTestData.updateToPhase5_1(detail);
        saveAndFlush(header);
        getSession().evict(header);
        header = volumeReportService.selectVolumeReport(header.getId());
        updateHeaderDetailsWithProductivity(header);
        detail = header.getVolumeReportDetails().iterator().next();


        UserDecorator user = userService.getAuthenticatedUserBy("DANDRADE_S");
//        VolumeReportTestData.fillWithValues(detail.getVolumeReportDetailPhase5(), VolumeReportTestData.VALID_VALUE);
        VolumeReportTestData.fillWithValues(detail, new VolumeReportFieldEnum[]{VolumeReportFieldEnum.VOLUME_COMMERCIALIZED1, VolumeReportFieldEnum.VOLUME_COMMERCIALIZED2}, VolumeReportTestData.VALID_VALUE);
        volumeReportDetailService.submitReport(header.getVolumeReportDetails(), localeBR, resourceBundle, user);
        getSession().flush();

        assertPhase1Statuses(detail, new VolumeReportStatus[]{VolumeReportStatus.APPROVED});
        assertPhase2Statuses(detail, new VolumeReportStatus[]{VolumeReportStatus.APPROVED, VolumeReportStatus.APPROVED, VolumeReportStatus.APPROVED});
        assertPhase3Statuses(detail, new VolumeReportStatus[]{VolumeReportStatus.APPROVED});
        assertPhase4Statuses(detail, new VolumeReportStatus[]{VolumeReportStatus.APPROVED});
        assertPhase5Statuses(detail, new VolumeReportStatus[]{VolumeReportStatus.APPROVED, VolumeReportStatus.REPORTED, VolumeReportStatus.WAITING_REPORT});
        assertPhase6Statuses(detail, new VolumeReportStatus[]{VolumeReportStatus.WAITING_REPORT});
        assertEmails(1);
    }


    @Test
    public void given_report_with_phase5_3_fields_set_when_save_and_submit_should_set_status_to_reported() throws UserNotFoundException, ConstraintException {
        setupFixture();
        createEmailRegistration();
        createAndPersistHarvestCalendar((Harvest) getSession().get(Harvest.class, HARVEST1), currentDateStart, currentDateEnd);
        VolumeReportHeader header = VolumeReportTestData.generateVolumeReportHeader(getHarvest(HARVEST1), getHeadOffice(HEADOFFICE2), getObtainer(OBTAINER1),
                new ItsClass[]{getItsClass(CLASS1)}, new Cultivar[]{getCultivar(CULTIVAR8)});


        saveAndFlush(header);

        getSession().evict(header);
        header = volumeReportService.selectVolumeReport(header.getId());
        updateHeaderDetailsWithProductivity(header);

        VolumeReportDetail detail = header.getVolumeReportDetails().iterator().next();
        VolumeReportTestData.fillWithValues(detail, new VolumeReportFieldEnum[]{VolumeReportFieldEnum.ENTERED_AREA, VolumeReportFieldEnum.OWN_SEED_USED, VolumeReportFieldEnum.MATRIX_SEED_USED}, VolumeReportTestData.VALID_VALUE);
        VolumeReportTestData.fillWithValues(detail, new VolumeReportFieldEnum[]{VolumeReportFieldEnum.PORTIONING, VolumeReportFieldEnum.VOLUME_HARVEST, VolumeReportFieldEnum.VOLUME_UBS}, VolumeReportTestData.VALID_VALUE);
        VolumeReportTestData.fillWithValues(detail, new VolumeReportFieldEnum[]{VolumeReportFieldEnum.VOLUME_BENEFITTED}, VolumeReportTestData.VALID_VALUE);
        VolumeReportTestData.fillWithValues(detail, new VolumeReportFieldEnum[]{VolumeReportFieldEnum.VOLUME_APPROVED}, VolumeReportTestData.VALID_VALUE);
        VolumeReportTestData.updateToPhase5_2(detail);
        saveAndFlush(header);
        getSession().evict(header);
        header = volumeReportService.selectVolumeReport(header.getId());
        updateHeaderDetailsWithProductivity(header);
        detail = header.getVolumeReportDetails().iterator().next();


        UserDecorator user = userService.getAuthenticatedUserBy("DANDRADE_S");
//        VolumeReportTestData.fillWithValues(detail.getVolumeReportDetailPhase5(), VolumeReportTestData.VALID_VALUE);
        VolumeReportTestData.fillWithValues(detail, new VolumeReportFieldEnum[]{VolumeReportFieldEnum.VOLUME_COMMERCIALIZED1, VolumeReportFieldEnum.VOLUME_COMMERCIALIZED2, VolumeReportFieldEnum.VOLUME_COMMERCIALIZED3}, VolumeReportTestData.VALID_VALUE);
        volumeReportDetailService.submitReport(header.getVolumeReportDetails(), localeBR, resourceBundle, user);
        getSession().flush();

        assertPhase1Statuses(detail, new VolumeReportStatus[]{VolumeReportStatus.APPROVED});
        assertPhase2Statuses(detail, new VolumeReportStatus[]{VolumeReportStatus.APPROVED, VolumeReportStatus.APPROVED, VolumeReportStatus.APPROVED});
        assertPhase3Statuses(detail, new VolumeReportStatus[]{VolumeReportStatus.APPROVED});
        assertPhase4Statuses(detail, new VolumeReportStatus[]{VolumeReportStatus.APPROVED});
        assertPhase5Statuses(detail, new VolumeReportStatus[]{VolumeReportStatus.APPROVED, VolumeReportStatus.APPROVED, VolumeReportStatus.REPORTED});
        assertPhase6Statuses(detail, new VolumeReportStatus[]{VolumeReportStatus.WAITING_REPORT});
        assertEmails(1);
    }


    @Test
    public void given_report_with_phase6_fields_set_when_save_and_submit_should_set_status_to_reported() throws UserNotFoundException, ConstraintException {
        setupFixture();
        createEmailRegistration();
        createAndPersistHarvestCalendar((Harvest) getSession().get(Harvest.class, HARVEST1), currentDateStart, currentDateEnd);
        VolumeReportHeader header = VolumeReportTestData.generateVolumeReportHeader(getHarvest(HARVEST1), getHeadOffice(HEADOFFICE2), getObtainer(OBTAINER1),
                new ItsClass[]{getItsClass(CLASS1)}, new Cultivar[]{getCultivar(CULTIVAR8)});


        saveAndFlush(header);

        getSession().evict(header);
        header = volumeReportService.selectVolumeReport(header.getId());
        updateHeaderDetailsWithProductivity(header);

        VolumeReportDetail detail = header.getVolumeReportDetails().iterator().next();
        VolumeReportTestData.fillWithValues(detail, new VolumeReportFieldEnum[]{VolumeReportFieldEnum.ENTERED_AREA, VolumeReportFieldEnum.OWN_SEED_USED, VolumeReportFieldEnum.MATRIX_SEED_USED}, VolumeReportTestData.VALID_VALUE);
        VolumeReportTestData.fillWithValues(detail, new VolumeReportFieldEnum[]{VolumeReportFieldEnum.PORTIONING, VolumeReportFieldEnum.VOLUME_HARVEST, VolumeReportFieldEnum.VOLUME_UBS}, VolumeReportTestData.VALID_VALUE);
        VolumeReportTestData.fillWithValues(detail, new VolumeReportFieldEnum[]{VolumeReportFieldEnum.VOLUME_BENEFITTED}, VolumeReportTestData.VALID_VALUE);
        VolumeReportTestData.fillWithValues(detail, new VolumeReportFieldEnum[]{VolumeReportFieldEnum.VOLUME_APPROVED}, VolumeReportTestData.VALID_VALUE);
        VolumeReportTestData.updateToPhase6(detail);
        saveAndFlush(header);
        getSession().evict(header);
        header = volumeReportService.selectVolumeReport(header.getId());
        updateHeaderDetailsWithProductivity(header);
        detail = header.getVolumeReportDetails().iterator().next();


        UserDecorator user = userService.getAuthenticatedUserBy("DANDRADE_S");
//        VolumeReportTestData.fillWithValues(detail.getVolumeReportDetailPhase5(), VolumeReportTestData.VALID_VALUE);
        VolumeReportTestData.fillWithValues(detail, new VolumeReportFieldEnum[]{VolumeReportFieldEnum.VOLUME_FOR_NEXT_HARVEST}, VolumeReportTestData.VALID_VALUE);
        volumeReportDetailService.submitReport(header.getVolumeReportDetails(), localeBR, resourceBundle, user);
        getSession().flush();

        assertPhase1Statuses(detail, new VolumeReportStatus[]{VolumeReportStatus.APPROVED});
        assertPhase2Statuses(detail, new VolumeReportStatus[]{VolumeReportStatus.APPROVED, VolumeReportStatus.APPROVED, VolumeReportStatus.APPROVED});
        assertPhase3Statuses(detail, new VolumeReportStatus[]{VolumeReportStatus.APPROVED});
        assertPhase4Statuses(detail, new VolumeReportStatus[]{VolumeReportStatus.APPROVED});
        assertPhase5Statuses(detail, new VolumeReportStatus[]{VolumeReportStatus.APPROVED, VolumeReportStatus.APPROVED, VolumeReportStatus.APPROVED});
        assertPhase6Statuses(detail, new VolumeReportStatus[]{VolumeReportStatus.REPORTED});
        assertEmails(1);
    }

    @Test
    public void given_header_that_exists_with_more_than_one_volume_report_should_throw_exception() {

        setupFixture();
        Harvest harvest = (Harvest) getSession().get(Harvest.class, HARVEST1);
        Obtainer obtainer = (Obtainer) getSession().get(Obtainer.class, OBTAINER1);
        HeadOffice headOffice = (HeadOffice) getSession().get(HeadOffice.class, HEADOFFICE1);
        Cultivar cultivar = (Cultivar) getSession().get(Cultivar.class, CULTIVAR1);
        ItsClass itsClass = (ItsClass) getSession().get(ItsClass.class, CLASS1);

        VolumeReportHeader header1 = new VolumeReportHeader(harvest, headOffice.getCustomer(), headOffice.getMatrix(), obtainer);
        VolumeReportHeader header2 = new VolumeReportHeader(harvest, headOffice.getCustomer(), headOffice.getMatrix(), obtainer);

        volumeReportService.save(header1);
        volumeReportService.save(header2);

        List<Cultivar> cultivarList = new ArrayList<Cultivar>();
        List<ItsClass> classList = new ArrayList<ItsClass>();
        cultivarList.add(cultivar);
        classList.add(itsClass);

        VolumeReportClassesByCultivarDTO volumeReportClassesByCultivarDTO = new VolumeReportClassesByCultivarDTO(
                cultivarList, classList, harvest, headOffice.getCustomer(), headOffice.getMatrix(), obtainer);
        try {
            volumeReportService.saveConfig(volumeReportClassesByCultivarDTO);
        } catch (IllegalStateException e) {
            Assert.assertEquals(e.getMessage(), "There shouldn't be more than 1 volume report per headoffice, harvest, obtainer!");
        }

    }

    @Test
    public void given_header_that_exists_with_no_volume_report() {

        setupFixture();
        Harvest harvest = (Harvest) getSession().get(Harvest.class, HARVEST1);
        Obtainer obtainer = (Obtainer) getSession().get(Obtainer.class, OBTAINER1);
        HeadOffice headOffice = (HeadOffice) getSession().get(HeadOffice.class, HEADOFFICE1);
        Cultivar cultivar = (Cultivar) getSession().get(Cultivar.class, CULTIVAR1);
        ItsClass itsClass = (ItsClass) getSession().get(ItsClass.class, CLASS1);

        List<Cultivar> cultivarList = new ArrayList<Cultivar>();
        List<ItsClass> classList = new ArrayList<ItsClass>();
        cultivarList.add(cultivar);
        classList.add(itsClass);

        VolumeReportClassesByCultivarDTO volumeReportClassesByCultivarDTO = new VolumeReportClassesByCultivarDTO(
                cultivarList, classList, harvest, headOffice.getCustomer(), headOffice.getMatrix(), obtainer);

        volumeReportService.saveConfig(volumeReportClassesByCultivarDTO);
        List<VolumeReportHeader> volumeReportHeaders = volumeReportService.selectByFilter(VolumeReportFilter.getInstance().addObtainer(volumeReportClassesByCultivarDTO.getObtainer()).addCustomerMatrix(volumeReportClassesByCultivarDTO.getCustomer(), volumeReportClassesByCultivarDTO.getMatrix()).addHarvest(volumeReportClassesByCultivarDTO.getHarvest()));
        Assert.assertEquals("Should find 1", 1, volumeReportHeaders.size());
        Assert.assertNotNull("should have id", volumeReportHeaders.iterator().next().getId());

    }

    @Test
    public void test_save_details() {
        setupFixture();
        Harvest harvest = (Harvest) getSession().get(Harvest.class, HARVEST1);
        Obtainer obtainer = (Obtainer) getSession().get(Obtainer.class, OBTAINER1);
        HeadOffice headOffice = (HeadOffice) getSession().get(HeadOffice.class, HEADOFFICE1);
        Cultivar cultivar = (Cultivar) getSession().get(Cultivar.class, CULTIVAR1);
        ItsClass itsClass = (ItsClass) getSession().get(ItsClass.class, CLASS1);

        VolumeReportHeader header = new VolumeReportHeader(harvest, headOffice.getCustomer(), headOffice.getMatrix(), obtainer);
        final VolumeReportDetail detail = new VolumeReportDetail(cultivar, itsClass, header);

        volumeReportService.save(header);

        List<VolumeReportDetail> details = new ArrayList<VolumeReportDetail>();

        details.add(detail);

        volumeReportDetailService.saveDetails(details);

        long detailId = detail.getId();

        getSession().flush();
        Assert.assertNotNull("Id shouldn't be null", detail.getId());

        VolumeReportDetail detail1 = volumeReportDetailService.selectDetailById(detailId);

        Assert.assertEquals("Detail should be same", detail, detail1);
    }

    @Test
    public void test_delete_report_detail() {
        setupFixture();
        Harvest harvest = (Harvest) getSession().get(Harvest.class, HARVEST1);
        Obtainer obtainer = (Obtainer) getSession().get(Obtainer.class, OBTAINER1);
        HeadOffice headOffice = (HeadOffice) getSession().get(HeadOffice.class, HEADOFFICE1);
        Cultivar cultivar = (Cultivar) getSession().get(Cultivar.class, CULTIVAR1);
        ItsClass itsClass = (ItsClass) getSession().get(ItsClass.class, CLASS1);

        VolumeReportHeader header = new VolumeReportHeader(harvest, headOffice.getCustomer(), headOffice.getMatrix(), obtainer);
        final VolumeReportDetail detail = new VolumeReportDetail(cultivar, itsClass, header);

        header.addVolumeReportDetail(detail);

        volumeReportService.save(header);

        long headerId = header.getId();

        volumeReportDetailService.deleteReportDetail(header, detail);

        getSession().flush();
        getSession().evict(header);

        VolumeReportHeader header1 = volumeReportService.selectById(headerId);

        Set<VolumeReportDetail> detailSet = header1.getVolumeReportDetails();

        Assert.assertTrue("Details should be empty", detailSet.isEmpty());
    }

    @Test
    public void test_inject_produtivity() {

        setupFixture();
        Harvest harvest = (Harvest) getSession().get(Harvest.class, HARVEST1);
        Obtainer obtainer = (Obtainer) getSession().get(Obtainer.class, OBTAINER1);
        HeadOffice headOffice = (HeadOffice) getSession().get(HeadOffice.class, HEADOFFICE1);
        Cultivar cultivar = (Cultivar) getSession().get(Cultivar.class, CULTIVAR1);
        ItsClass itsClass = (ItsClass) getSession().get(ItsClass.class, CLASS1);
        State state = getState(STATE1);

        VolumeReportHeader header = new VolumeReportHeader(harvest, headOffice.getCustomer(), headOffice.getMatrix(), obtainer);

        final VolumeReportDetail detail = new VolumeReportDetail(cultivar, itsClass, header);

        List<VolumeReportDetail> details = new ArrayList<VolumeReportDetail>();

        details.add(detail);

        volumeReportService.save(header);

        detail.setVolumeReportHeader(header);

        volumeReportDetailService.saveDetails(details);

        HectareProductivity hectareProductivity = new HectareProductivity(harvest, state, cultivar);
        hectareProductivity.setProductivity(BigInteger.TEN);
        saveAndFlush(hectareProductivity);

        long headerId = header.getId();

        getSession().flush();

        VolumeReportHeader header1 = volumeReportService.selectById(headerId);

        header = volumeReportService.injectProdutivityIn(header1);

        Assert.assertEquals("Should be equal to " + BigInteger.TEN,
                BigInteger.TEN, header1.getVolumeReportDetails().iterator()
                        .next().getProductivity());

    }

    @Test
    public void validate_filter_values_from_config_report_with_all_values_should_be_success() {
        setupFixture();
        Company company = (Company) getSession().get(Company.class, 900000001L);
        Crop crop = (Crop) getSession().get(Crop.class, 900000001L);
        Customer matrix = (Customer) getSession().get(Customer.class, 900000001L);
        HeadOffice affiliate = (HeadOffice) getSession().get(HeadOffice.class, 900000001L);
        Harvest harvest = (Harvest) getSession().get(Harvest.class, 900000001L);
        Obtainer obtainer = (Obtainer) getSession().get(Obtainer.class, 900000001L);

        try {
            volumeReportService.validateHeaderReport(company, crop, matrix, affiliate.getCustomer(), harvest, obtainer);
        } catch (ConstraintException e) {
//			ConstraintViolation violation = e.getViolations().get(0);
            Assert.fail();
        }
    }

    @Test
    public void validate_filter_values_from_config_report_without_company_should_return_exception() {
        setupFixture();
        Company company = null;
        Crop crop = (Crop) getSession().get(Crop.class, 900000001L);
        Customer matrix = (Customer) getSession().get(Customer.class, 900000001L);
        HeadOffice affiliate = (HeadOffice) getSession().get(HeadOffice.class, 900000001L);
        Harvest harvest = (Harvest) getSession().get(Harvest.class, 900000001L);
        Obtainer obtainer = (Obtainer) getSession().get(Obtainer.class, 900000001L);

        try {
            volumeReportService.validateHeaderReport(company, crop, matrix, affiliate.getCustomer(), harvest, obtainer);
            Assert.fail();
        } catch (ConstraintException e) {
            ConstraintViolation violation = e.getViolations().get(0);
            Assert.assertEquals("javax.faces.component.UIInput.REQUIRED", violation.getMessage());
            Assert.assertEquals("label.volumereport.company", violation.getField());
        }
    }

    @Test
    public void validate_filter_values_from_config_report_without_crop_should_return_exception() {
        setupFixture();
        Company company = (Company) getSession().get(Company.class, 900000001L);
        Crop crop = null;
        Customer matrix = (Customer) getSession().get(Customer.class, 900000001L);
        HeadOffice affiliate = (HeadOffice) getSession().get(HeadOffice.class, 900000001L);
        Harvest harvest = (Harvest) getSession().get(Harvest.class, 900000001L);
        Obtainer obtainer = (Obtainer) getSession().get(Obtainer.class, 900000001L);

        try {
            volumeReportService.validateHeaderReport(company, crop, matrix, affiliate.getCustomer(), harvest, obtainer);
            Assert.fail();
        } catch (ConstraintException e) {
            ConstraintViolation violation = e.getViolations().get(0);
            Assert.assertEquals("javax.faces.component.UIInput.REQUIRED", violation.getMessage());
            Assert.assertEquals("label.volumereport.crop", violation.getField());
        }
    }

    @Test
    public void validate_filter_values_from_config_report_without_matrix_should_return_exception() {
        setupFixture();
        Company company = (Company) getSession().get(Company.class, 900000001L);
        Crop crop = (Crop) getSession().get(Crop.class, 900000001L);
        Customer matrix = null;
        HeadOffice affiliate = (HeadOffice) getSession().get(HeadOffice.class, 900000001L);
        Harvest harvest = (Harvest) getSession().get(Harvest.class, 900000001L);
        Obtainer obtainer = (Obtainer) getSession().get(Obtainer.class, 900000001L);

        try {
            volumeReportService.validateHeaderReport(company, crop, matrix, affiliate.getCustomer(), harvest, obtainer);
            Assert.fail();
        } catch (ConstraintException e) {
            ConstraintViolation violation = e.getViolations().get(0);
            Assert.assertEquals("javax.faces.component.UIInput.REQUIRED", violation.getMessage());
            Assert.assertEquals("label.headOfficeCC.headOffice", violation.getField());
        }
    }

    @Test
    public void validate_filter_values_from_config_report_without_affiliate_should_return_exception() {
        setupFixture();
        Company company = (Company) getSession().get(Company.class, 900000001L);
        Crop crop = (Crop) getSession().get(Crop.class, 900000001L);
        Customer matrix = (Customer) getSession().get(Customer.class, 900000001L);
        Customer affiliate = null;
        Harvest harvest = (Harvest) getSession().get(Harvest.class, 900000001L);
        Obtainer obtainer = (Obtainer) getSession().get(Obtainer.class, 900000001L);

        try {
            volumeReportService.validateHeaderReport(company, crop, matrix, affiliate, harvest, obtainer);
            Assert.fail();
        } catch (ConstraintException e) {
            ConstraintViolation violation = e.getViolations().get(0);
            Assert.assertEquals("javax.faces.component.UIInput.REQUIRED", violation.getMessage());
            Assert.assertEquals("label.volumereport.affiliate", violation.getField());
        }
    }

    @Test
    public void validate_filter_values_from_config_report_without_harvest_should_return_exception() {
        setupFixture();
        Company company = (Company) getSession().get(Company.class, 900000001L);
        Crop crop = (Crop) getSession().get(Crop.class, 900000001L);
        Customer matrix = (Customer) getSession().get(Customer.class, 900000001L);
        HeadOffice affiliate = (HeadOffice) getSession().get(HeadOffice.class, 900000001L);
        Harvest harvest = null;
        Obtainer obtainer = (Obtainer) getSession().get(Obtainer.class, 900000001L);

        try {
            volumeReportService.validateHeaderReport(company, crop, matrix, affiliate.getCustomer(), harvest, obtainer);
            Assert.fail();
        } catch (ConstraintException e) {
            ConstraintViolation violation = e.getViolations().get(0);
            Assert.assertEquals("javax.faces.component.UIInput.REQUIRED", violation.getMessage());
            Assert.assertEquals("label.volumereport.harvest", violation.getField());
        }
    }

    @Test
    public void validate_filter_values_from_config_report_without_obtainer_should_return_exception() {
        setupFixture();
        Company company = (Company) getSession().get(Company.class, 900000001L);
        Crop crop = (Crop) getSession().get(Crop.class, 900000001L);
        Customer matrix = (Customer) getSession().get(Customer.class, 900000001L);
        HeadOffice affiliate = (HeadOffice) getSession().get(HeadOffice.class, 900000001L);
        Harvest harvest = (Harvest) getSession().get(Harvest.class, 900000001L);
        Obtainer obtainer = null;

        try {
            volumeReportService.validateHeaderReport(company, crop, matrix, affiliate.getCustomer(), harvest, obtainer);
            Assert.fail();
        } catch (ConstraintException e) {
            ConstraintViolation violation = e.getViolations().get(0);
            Assert.assertEquals("javax.faces.component.UIInput.REQUIRED", violation.getMessage());
            Assert.assertEquals("label.volumereport.obtainer", violation.getField());
        }
    }

    private void saveHeadDetailViewLines(VolumeReportHeader header) {
        if (!getAssumptionTest().isEnvironmentWithSQLANSI()) {
            for (VolumeReportDetailView volumeReportDetailView : VolumeReportTestData.createVolumeReportDetailViewsFrom(header)) {
                getSession().save(volumeReportDetailView);
            }
        }
    }

    @Test
    public void given_multiple_reports_for_different_headoffices_should_generate_matrix_list_with_3_entries_1_each() {
        setupFixture();
        Harvest harvest1 = (Harvest) getSession().get(Harvest.class, HARVEST1);
        createAndPersistHarvestCalendar(harvest1, currentDateStart, currentDateEnd);
        VolumeReportHeader header = VolumeReportTestData.generateVolumeReportHeader(getHarvest(HARVEST1), getHeadOffice(HEADOFFICE9), getObtainer(OBTAINER1),
                new ItsClass[]{getItsClass(CLASS1)}, new Cultivar[]{getCultivar(CULTIVAR14)});
        getSession().save(header);
        saveHeadDetailViewLines(header);
        header = VolumeReportTestData.generateVolumeReportHeader(getHarvest(HARVEST1), getHeadOffice(HEADOFFICE10), getObtainer(OBTAINER1),
                new ItsClass[]{getItsClass(CLASS1)}, new Cultivar[]{getCultivar(CULTIVAR14)});
        getSession().save(header);
        saveHeadDetailViewLines(header);
        header = VolumeReportTestData.generateVolumeReportHeader(getHarvest(HARVEST1), getHeadOffice(HEADOFFICE8), getObtainer(OBTAINER1),
                new ItsClass[]{getItsClass(CLASS1)}, new Cultivar[]{getCultivar(CULTIVAR14)});
        getSession().save(header);
        saveHeadDetailViewLines(header);
        getSession().flush();

        VolumeReportApprovalFilter filter = VolumeReportApprovalFilter.getInstance(harvest1).addCultivar(getCultivar(CULTIVAR14));
        List<VolumeReportByMatrixApprovalDTO> volumeReportByMatrixApprovalDTOs = volumeReportService.selectVolumeReportByMatrixByFilter(filter);
        Assert.assertEquals("Should have 3", 3, volumeReportByMatrixApprovalDTOs.size());
        for (VolumeReportByMatrixApprovalDTO volumeReportByMatrixApprovalDTO : volumeReportByMatrixApprovalDTOs) {
            Assert.assertEquals("Should have 1", 1, volumeReportByMatrixApprovalDTO.getApprovalDTOs().size());
        }

    }

    private State getState(Long id) {
        return (State) getSession().get(State.class, id);
    }

    private void assertEmails(int emailCount) {
//		Iterator<SmtpMessage> receivedEmail = serverSMTP.getReceivedEmail();
//        int counter=0;
//        while(receivedEmail.hasNext()) {
//            receivedEmail.next();
//            counter++;
//        }
//        Assert.assertEquals("Should have found " + emailCount + " messages", emailCount, counter);
    }

    private void assertFieldStatuses(VolumeReportDetail detail, VolumeReportFieldEnum[] fieldEnums, VolumeReportStatus[] statuses) {
        for (int i = 0; i < fieldEnums.length; i++) {
            assertStatus(statuses[i], detail.getFieldByPhase(fieldEnums[i]).getStatus());
        }
    }

    private void assertPhase1Statuses(VolumeReportDetail detail, VolumeReportStatus[] statuses) {
        assertFieldStatuses(detail, new VolumeReportFieldEnum[]{VolumeReportFieldEnum.ENTERED_AREA}, statuses);
    }

    private void assertPhase2Statuses(VolumeReportDetail detail, VolumeReportStatus[] statuses) {
        assertFieldStatuses(detail, new VolumeReportFieldEnum[]{VolumeReportFieldEnum.PORTIONING, VolumeReportFieldEnum.VOLUME_HARVEST, VolumeReportFieldEnum.VOLUME_UBS}, statuses);
    }

    private void assertPhase3Statuses(VolumeReportDetail detail, VolumeReportStatus[] statuses) {
        assertFieldStatuses(detail, new VolumeReportFieldEnum[]{VolumeReportFieldEnum.VOLUME_BENEFITTED}, statuses);
    }

    private void assertPhase4Statuses(VolumeReportDetail detail, VolumeReportStatus[] statuses) {
        assertFieldStatuses(detail, new VolumeReportFieldEnum[]{VolumeReportFieldEnum.VOLUME_APPROVED}, statuses);
    }

    private void assertPhase5Statuses(VolumeReportDetail detail, VolumeReportStatus[] statuses) {
        assertFieldStatuses(detail, new VolumeReportFieldEnum[]{VolumeReportFieldEnum.VOLUME_COMMERCIALIZED1, VolumeReportFieldEnum.VOLUME_COMMERCIALIZED2, VolumeReportFieldEnum.VOLUME_COMMERCIALIZED3}, statuses);
    }

    private void assertPhase6Statuses(VolumeReportDetail detail, VolumeReportStatus[] statuses) {
        assertFieldStatuses(detail, new VolumeReportFieldEnum[]{VolumeReportFieldEnum.VOLUME_FOR_NEXT_HARVEST}, statuses);
    }

    private void assertStatus(VolumeReportStatus statusToAssert, VolumeReportStatus statusToCheck) {
        if (statusToAssert != null) {
            Assert.assertEquals("Should be " + statusToAssert, statusToAssert, statusToCheck);
        }
    }


    private VolumeReportClassesByCultivarDTO initializeVolumeReportHeader() {
        obtainer = (Obtainer) getSession().get(Obtainer.class, OBTAINER1);
        harvest = (Harvest) getSession().get(Harvest.class, HARVEST1);
        headOffice = (HeadOffice) getSession().get(HeadOffice.class, HEADOFFICE8);
        VolumeReportClassesByCultivarDTO volumeReportClassesByCultivarDTO = volumeReportService.generateVolumeReportClassesConfigurationBy(headOffice, harvest, obtainer);
        Assert.assertEquals("Should have 2 classes", 2, volumeReportClassesByCultivarDTO.getClassList().size());
        Assert.assertEquals("Should have 5 cultivar", 5, volumeReportClassesByCultivarDTO.getCultivarClassValues().size());

        itsClass1 = (ItsClass) getSession().get(ItsClass.class, CLASS1);
        itsClass2 = (ItsClass) getSession().get(ItsClass.class, CLASS2);

        cultivar1 = (Cultivar) getSession().get(Cultivar.class, CULTIVAR1);
        cultivar2 = (Cultivar) getSession().get(Cultivar.class, CULTIVAR2);

        VolumeReportHeader header = (VolumeReportHeader) getSession().get(VolumeReportHeader.class, 900000001L);
        header.addVolumeReportDetail(new VolumeReportDetail(cultivar1, itsClass1, header));
        header.addVolumeReportDetail(new VolumeReportDetail(cultivar2, itsClass2, header));
        volumeReportService.save(header);
        getSession().flush();
        getSession().evict(header);
        return volumeReportClassesByCultivarDTO;
    }

    private void countNumberOfSetClasses(VolumeReportClassesByCultivarDTO volumeReportClassesByCultivarDTO, int i) {
        int count = 0;
        for (CultivarClassListPair pair : volumeReportClassesByCultivarDTO.getCultivarClassValues()) {
            for (ItsClassBooleanWrapper itsClassBooleanWrapper : pair.getBooleanList()) {
                if (itsClassBooleanWrapper.getClassSet()) {
                    count++;
                }
            }
        }
        Assert.assertEquals("Should be " + i, i, count);
    }

    @Test
    public void get_values_test() {
        setupFixture();

        VolumeReportStatus volumeReportStatus = VolumeReportStatus.WAITING_REPORT;

        Assert.assertEquals("label.volumeReportStatus.waitingReport", volumeReportStatus.getLabel());
        Assert.assertEquals("label.volumeReportStatus.waitingReport", volumeReportStatus.getBillingLabel());
        Assert.assertEquals(new Integer("0"), volumeReportStatus.getNumber());
        Assert.assertTrue(VolumeReportStatus.isSaveableStatus(volumeReportStatus));
    }

    @Test
    public void is_saveable_status_test() {
        setupFixture();

        VolumeReportStatus volumeReportStatus = VolumeReportStatus.APPROVED;

        Assert.assertFalse(VolumeReportStatus.isSaveableStatus(volumeReportStatus));
    }

    @Test
    public void sanity_check_discardPotioning() {
        setupFixture();
        VolumeReportHeader header = createAndSaveHeaderWithDetail();
        VolumeReportDetail detail = header.getVolumeReportDetails().iterator().next();

        BigDecimal area = BigDecimal.TEN;
        Grower grower = (Grower) getSession().get(Grower.class, GROWER1);

        DiscardPortioning discardPortioning = new DiscardPortioning(grower, detail, area);
        detail.addDiscardPortioning(discardPortioning);

        volumeReportDetailService.saveDetails(header.getVolumeReportDetails());
        getSession().evict(header);

        VolumeReportHeader refreshedHeader = volumeReportService.selectVolumeReport(header.getId());
        VolumeReportDetail refreshedDetail = refreshedHeader.getVolumeReportDetails().iterator().next();

        Assert.assertEquals(1, refreshedDetail.getDiscardPortionings().size());
        DiscardPortioning portioning = refreshedDetail.getDiscardPortionings().iterator().next();

        Assert.assertEquals(grower, portioning.getGrower());
        Assert.assertEquals(refreshedDetail, portioning.getVolumeReportDetail());
        Assert.assertEquals(area, portioning.getArea());

    }

    @Test
    public void given_call_to_select_single_detail_should_return_single_detail() {
        setupFixture();
        createAndSaveHeaderWithDetail();
        HeadOffice headOffice1 = getHeadOffice(HEADOFFICE1);
        VolumeReportDetail detail = volumeReportDetailService.selectVolumeReportDetailBy(getHarvest(HARVEST1), headOffice1.getMatrix(), headOffice1.getCustomer(),
                getObtainer(OBTAINER1), getCultivar(CULTIVAR1), getItsClass(CLASS1));
        Assert.assertNotNull("Should not be null", detail);
    }

    @Test
    public void given_call_to_select_by_cultivar_should_return_a_list() {
        setupFixture();
        createAndSaveHeaderWithDetail();
        List<VolumeReportDetail> details = volumeReportDetailService.selectVolumeReportDetailByCultivar(getCultivar(CULTIVAR1));
        Assert.assertFalse("Should not be empty", details.isEmpty());
    }

    @Test
    public void given_an_invalid_id_when_select_volumeReportDetailWithDiscards_should_return_null() {
        Assert.assertNull(volumeReportService.selectVolumeReport(123L));
    }

    @Test
    public void given_an_id_of_a_detail_when_select_volumeReportDetailWithDiscards_should_detail_with_yours_discardPortionings() {
        DbUnitHelper.setup("classpath:data/multiplier/basic-fixture.xml", "classpath:data/multiplier/discard-portioning-dataset.xml");
        VolumeReportHeader header = volumeReportService.selectVolumeReport(900000006L);

        Assert.assertNotNull("Should have a report header", header);
        VolumeReportDetail detail = header.getVolumeReportDetails().iterator().next();
        Assert.assertNotNull("Should return a detail", detail);
        Assert.assertFalse("Discard portionings list should not be empty", detail.getDiscardPortionings().isEmpty());
        Assert.assertEquals(detail, detail.getDiscardPortionings().iterator().next().getVolumeReportDetail());
    }

    @Test
    public void given_an_id_of_a_detail_without_discards_when_select_volumeReportDetailWithDiscards_should_return_detail_with_discardPortionings_empty() {
        DbUnitHelper.setup("classpath:data/multiplier/basic-fixture.xml", "classpath:data/multiplier/discard-portioning-dataset.xml");
        VolumeReportHeader header = volumeReportService.selectVolumeReport(900000005L);

        VolumeReportDetail detail = header.getVolumeReportDetails().iterator().next();
        Assert.assertNotNull("Should return a detail", detail);
        Assert.assertTrue("Discard portionings list should be empty", detail.getDiscardPortionings().isEmpty());
    }

    @Test
    public void given_a_filter_with_only_company_and_crop_when_select_enteredAreaReport_should_return_all_reports() {
        initEnteredAreaReportFixture();

        Company company = (Company) getSession().get(Company.class, 900000001L);
        Crop crop = (Crop) getSession().get(Crop.class, 900000001L);
        State partnerState = null;
        City partnerCity = null;
        OperationalYear operationalYear = null;
        Harvest harvest = null;
        Obtainer obtainer = null;

        EnteredAreaReportViewFilter filter = EnteredAreaReportViewFilter.getInstance(company, crop, getMockedUser())
                .addMatrix(null).addHierarchyMatrix(null, null, null)
                .addPartner(null).addHierarchyPartner(null, null, null).add(partnerState).add(partnerCity)
                .add(operationalYear).add(harvest).add(obtainer)
                .addRevenueDocumentNumber(null).addRevenueOrderNumber(null).addRevenuePostDate(null, null)
                .addRevenueReversalCode(null).addRevenueReversalDate(null, null);
        Assert.assertEquals("Should have 5 lines", 5, volumeReportDetailService.selectEnteredAreaReportViewBy(filter).size());
    }

    @Test
    public void given_a_filter_with_technology_when_select_enteredAreaReport_should_return_only_lines_with_this_technology() {
        initEnteredAreaReportFixture();

        Company company = (Company) getSession().get(Company.class, 900000001L);
        Crop crop = (Crop) getSession().get(Crop.class, 900000001L);
        Technology technology = (Technology) getSession().get(Technology.class, 900000003L);

        EnteredAreaReportViewFilter filter = EnteredAreaReportViewFilter.getInstance(company, crop, getMockedUser());
        filter.add(technology);

        List<EnteredAreaReportView> enteredAreas = volumeReportDetailService.selectEnteredAreaReportViewBy(filter);
        Assert.assertFalse("Should return results", enteredAreas.isEmpty());
        for (EnteredAreaReportView enteredAreaReportView : enteredAreas) {
            Assert.assertEquals("Technology should be equals", technology.getDescription(), enteredAreaReportView.getTechnologyDescription());
        }
    }

    @Test
    public void given_a_filter_with_conventional_technology_when_select_enteredAreaReport_should_return_only_lines_with_no_technology() {
        initEnteredAreaReportFixture();

        Company company = (Company) getSession().get(Company.class, 900000001L);
        Crop crop = (Crop) getSession().get(Crop.class, 900000001L);

        EnteredAreaReportViewFilter filter = EnteredAreaReportViewFilter.getInstance(company, crop, getMockedUser());
        Technology technology = new Technology();
        technology.setId(-1L); // -1 technology means conventional
        filter.add(technology);

        List<EnteredAreaReportView> enteredAreas = volumeReportDetailService.selectEnteredAreaReportViewBy(filter);
        Assert.assertFalse("Should return results", enteredAreas.isEmpty());
        for (EnteredAreaReportView enteredAreaReportView : enteredAreas) {
            Assert.assertEquals("Technology description shoul be a bundle key", "label.enteredAreaReport.technology.conventional", enteredAreaReportView.getTechnologyDescription());
            Assert.assertNull("Technology should be null", enteredAreaReportView.getTechnologyCode());
        }
    }

    @Test
    public void given_a_filter_with_partner_when_select_enteredAreaReport_should_return_only_lines_with_this_partner() {
        initEnteredAreaReportFixture();

        Company company = (Company) getSession().get(Company.class, 900000001L);
        Crop crop = (Crop) getSession().get(Crop.class, 900000001L);

        Customer partner = (Customer) getSession().get(Customer.class, 900000001L);
        EnteredAreaReportViewFilter filter = EnteredAreaReportViewFilter.getInstance(company, crop, getMockedUser());
        filter.addPartner(partner);

        List<EnteredAreaReportView> enteredAreas = volumeReportDetailService.selectEnteredAreaReportViewBy(filter);
        Assert.assertFalse("Should return results", enteredAreas.isEmpty());
        for (EnteredAreaReportView enteredAreaReportView : enteredAreas) {
            Assert.assertEquals("Partner id should be equals", partner.getId(), enteredAreaReportView.getPartnerId());
            Assert.assertEquals("Partner name should be equals", partner.getName(), enteredAreaReportView.getPartnerDescription());
            Assert.assertEquals("Partner sap code should be equals", partner.getCustomerSAPCode(), enteredAreaReportView.getPartnerSAPCode());
            Assert.assertEquals("Partner document should be equals", partner.getDocumentValue(), enteredAreaReportView.getPartnerDocument());
            Assert.assertEquals("Partner document mask should be equals", partner.getDocument().getDocumentType().getMask(), enteredAreaReportView.getPartnerDocumentMask());
            Assert.assertEquals("Partner city id should be equals", partner.getAddress().getCity().getId(), enteredAreaReportView.getPartnerCityId());
            Assert.assertEquals("Partner city description should be equals", partner.getAddress().getCity().getDescription(), enteredAreaReportView.getPartnerCityDescription());
            Assert.assertEquals("Partner state id should be equals", partner.getAddress().getState().getId(), enteredAreaReportView.getPartnerStateId());
            Assert.assertEquals("Partner state code should be equals", partner.getAddress().getState().getCode(), enteredAreaReportView.getPartnerStateCode());
        }
    }

    @Test
    public void given_a_filter_with_hierarchyPartner_when_select_enteredAreaReport_should_return_only_lines_with_this_hierarchyPartner() {
        initEnteredAreaReportFixture();

        Company company = (Company) getSession().get(Company.class, 900000001L);
        Crop crop = (Crop) getSession().get(Crop.class, 900000001L);

        ItsUnity partnerUnity = (ItsUnity) getSession().get(ItsUnity.class, 900000001L);
        ItsRegion partnerRegion = (ItsRegion) getSession().get(ItsRegion.class, 900000001L);
        ItsDistrict partnerDistrict = (ItsDistrict) getSession().get(ItsDistrict.class, 900000001L);


        EnteredAreaReportViewFilter filter = EnteredAreaReportViewFilter.getInstance(company, crop, getMockedUser());
        filter.addHierarchyPartner(partnerUnity, partnerRegion, partnerDistrict);

        List<EnteredAreaReportView> enteredAreas = volumeReportDetailService.selectEnteredAreaReportViewBy(filter);
        Assert.assertFalse("Should return results", enteredAreas.isEmpty());
        for (EnteredAreaReportView enteredAreaReportView : enteredAreas) {
            Assert.assertEquals("PartnerHierarchyUnityDesc id should be equals", "_UN_", enteredAreaReportView.getPartnerUnitSapId());
            Assert.assertEquals("PartnerHierarchyUnityDesc id should be equals", "_UNUN_", enteredAreaReportView.getPartnerUnitSapDesc());
            Assert.assertEquals("PartnerHierarchyRegionDesc id should be equals", "_RG_", enteredAreaReportView.getPartnerRegionSapId());
            Assert.assertEquals("PartnerHierarchyRegionDesc id should be equals", "_REGREG_", enteredAreaReportView.getPartnerRegionSapDesc());
            Assert.assertEquals("PartnerHierarchyDistrictDesc id should be equals", "_DS_", enteredAreaReportView.getPartnerDistrictSapId());
            Assert.assertEquals("PartnerHierarchyDistrictDesc id should be equals", "_DISDIS_", enteredAreaReportView.getPartnerDistrictSapDesc());
        }
    }

    @Test
    public void given_a_filter_with_partnerState_when_select_enteredAreaReport_should_return_only_lines_with_this_partnerState() {
        initEnteredAreaReportFixture();

        Company company = (Company) getSession().get(Company.class, 900000001L);
        Crop crop = (Crop) getSession().get(Crop.class, 900000001L);

        State partnerState = (State) getSession().get(State.class, 900000001L);
        EnteredAreaReportViewFilter filter = EnteredAreaReportViewFilter.getInstance(company, crop, getMockedUser());
        filter.add(partnerState);

        List<EnteredAreaReportView> enteredAreas = volumeReportDetailService.selectEnteredAreaReportViewBy(filter);
        Assert.assertFalse("Should return results", enteredAreas.isEmpty());
        for (EnteredAreaReportView enteredAreaReportView : enteredAreas) {
            Assert.assertEquals("Partner state id should be equals", partnerState.getId(), enteredAreaReportView.getPartnerStateId());
            Assert.assertEquals("Partner state code should be equals", partnerState.getCode(), enteredAreaReportView.getPartnerStateCode());
        }
    }

    @Test
    public void given_a_filter_with_partnerCity_when_select_enteredAreaReport_should_return_only_lines_with_this_partnerCity() {
        initEnteredAreaReportFixture();

        Company company = (Company) getSession().get(Company.class, 900000001L);
        Crop crop = (Crop) getSession().get(Crop.class, 900000001L);

        City partnerCity = (City) getSession().get(City.class, 900000004L);
        EnteredAreaReportViewFilter filter = EnteredAreaReportViewFilter.getInstance(company, crop, getMockedUser());
        filter.add(partnerCity);

        List<EnteredAreaReportView> enteredAreas = volumeReportDetailService.selectEnteredAreaReportViewBy(filter);
        Assert.assertFalse("Should return results", enteredAreas.isEmpty());
        for (EnteredAreaReportView enteredAreaReportView : enteredAreas) {
            Assert.assertEquals("Partner city id should be equals", partnerCity.getId(), enteredAreaReportView.getPartnerCityId());
            Assert.assertEquals("Partner city description should be equals", partnerCity.getDescription(), enteredAreaReportView.getPartnerCityDescription());
        }
    }

    @Test
    public void given_a_filter_with_operationalYear_when_select_enteredAreaReport_should_return_only_lines_with_this_operationalYear() {
        initEnteredAreaReportFixture();

        Company company = (Company) getSession().get(Company.class, 900000001L);
        Crop crop = (Crop) getSession().get(Crop.class, 900000001L);

        OperationalYear operationalYear = (OperationalYear) getSession().get(OperationalYear.class, 900000002L);
        EnteredAreaReportViewFilter filter = EnteredAreaReportViewFilter.getInstance(company, crop, getMockedUser());
        filter.add(operationalYear);

        List<EnteredAreaReportView> enteredAreas = volumeReportDetailService.selectEnteredAreaReportViewBy(filter);
        Assert.assertFalse("Should return results", enteredAreas.isEmpty());
        for (EnteredAreaReportView enteredAreaReportView : enteredAreas) {
            Assert.assertEquals("OperationalYear should be equals", operationalYear.getId(), enteredAreaReportView.getOperationalYearId());
        }
    }

    @Test
    public void given_a_filter_with_harvest_when_select_enteredAreaReport_should_return_only_lines_with_this_harvest() {
        initEnteredAreaReportFixture();

        Company company = (Company) getSession().get(Company.class, 900000001L);
        Crop crop = (Crop) getSession().get(Crop.class, 900000001L);

        Harvest harvest = (Harvest) getSession().get(Harvest.class, 900000002L);
        EnteredAreaReportViewFilter filter = EnteredAreaReportViewFilter.getInstance(company, crop, getMockedUser());
        filter.add(harvest);

        List<EnteredAreaReportView> enteredAreas = volumeReportDetailService.selectEnteredAreaReportViewBy(filter);
        Assert.assertFalse("Should return results", enteredAreas.isEmpty());
        for (EnteredAreaReportView enteredAreaReportView : enteredAreas) {
            Assert.assertEquals("Harvest id should be equals", harvest.getId(), enteredAreaReportView.getHarvestId());
            Assert.assertEquals("Harvest description should be equals", harvest.getDescription(), enteredAreaReportView.getHarvestDescription());
        }
    }

    @Test
    public void given_a_filter_with_obtainer_when_select_enteredAreaReport_should_return_only_lines_with_this_obtainer() {
        initEnteredAreaReportFixture();

        Company company = (Company) getSession().get(Company.class, 900000001L);
        Crop crop = (Crop) getSession().get(Crop.class, 900000001L);

        Obtainer obtainer = (Obtainer) getSession().get(Obtainer.class, 900000006L);
        EnteredAreaReportViewFilter filter = EnteredAreaReportViewFilter.getInstance(company, crop, getMockedUser());
        filter.add(obtainer);

        List<EnteredAreaReportView> enteredAreas = volumeReportDetailService.selectEnteredAreaReportViewBy(filter);
        Assert.assertFalse("Should return results", enteredAreas.isEmpty());
        for (EnteredAreaReportView enteredAreaReportView : enteredAreas) {
            Assert.assertEquals("Obtainer id should be equals", obtainer.getId(), enteredAreaReportView.getObtainerId());
            Assert.assertEquals("Obtainer description should be equals", obtainer.getDescription(), enteredAreaReportView.getObtainerDescription());
        }
    }

    @Test
    public void given_a_filter_with_revenueDocumentNumber_when_select_enteredAreaReport_should_return_only_lines_with_this_revenueDocumentNumber() {
        initEnteredAreaReportFixture();

        Company company = (Company) getSession().get(Company.class, 900000001L);
        Crop crop = (Crop) getSession().get(Crop.class, 900000001L);

        String revenueDocumentNumber = "900000001";
        EnteredAreaReportViewFilter filter = EnteredAreaReportViewFilter.getInstance(company, crop, getMockedUser());
        filter.addRevenueDocumentNumber(revenueDocumentNumber);

        List<EnteredAreaReportView> enteredAreas = volumeReportDetailService.selectEnteredAreaReportViewBy(filter);
        Assert.assertFalse("Should return results", enteredAreas.isEmpty());
        for (EnteredAreaReportView enteredAreaReportView : enteredAreas) {
            Assert.assertEquals("RevenueDocumentNumber should be equals", revenueDocumentNumber, enteredAreaReportView.getRevenueDocumentNumber());
        }
    }

    @Test
    public void given_a_filter_with_revenueOrderNumber_when_select_enteredAreaReport_should_return_only_lines_with_this_revenueOrderNumber() {
        initEnteredAreaReportFixture();

        Company company = (Company) getSession().get(Company.class, 900000001L);
        Crop crop = (Crop) getSession().get(Crop.class, 900000001L);

        String revenueOrderNumber = "900000001";
        EnteredAreaReportViewFilter filter = EnteredAreaReportViewFilter.getInstance(company, crop, getMockedUser());
        filter.addRevenueOrderNumber(revenueOrderNumber);

        List<EnteredAreaReportView> enteredAreas = volumeReportDetailService.selectEnteredAreaReportViewBy(filter);
        Assert.assertFalse("Should return results", enteredAreas.isEmpty());
        for (EnteredAreaReportView enteredAreaReportView : enteredAreas) {
            Assert.assertEquals("RevenueDocumentNumber should be equals", revenueOrderNumber, enteredAreaReportView.getRevenueOrderNumber());
        }
    }

    @Test
    public void given_a_filter_with_revenuePostDate_when_select_enteredAreaReport_should_return_only_lines_with_this_revenuePostDate() {
        initEnteredAreaReportFixture();

        Company company = (Company) getSession().get(Company.class, 900000001L);
        Crop crop = (Crop) getSession().get(Crop.class, 900000001L);

        Date revenuePostDateStart = CalendarUtil.getDate(2012, 06, 29);
        Date revenuePostDateEnd = CalendarUtil.getDate(2012, 06, 31);

        EnteredAreaReportViewFilter filter = EnteredAreaReportViewFilter.getInstance(company, crop, getMockedUser());
        filter.addRevenuePostDate(revenuePostDateStart, revenuePostDateEnd);

        List<EnteredAreaReportView> enteredAreas = volumeReportDetailService.selectEnteredAreaReportViewBy(filter);
        Assert.assertFalse("Should return results", enteredAreas.isEmpty());
        for (EnteredAreaReportView enteredAreaReportView : enteredAreas) {
            Assert.assertTrue("RevenuePostDate should be after", enteredAreaReportView.getRevenuePostDate().compareTo(revenuePostDateStart) > -1);
            Assert.assertTrue("RevenuePostDate should be before", enteredAreaReportView.getRevenuePostDate().compareTo(revenuePostDateEnd) < 1);
        }
    }

    @Test
    public void given_a_filter_with_revenueReversalCode_when_select_enteredAreaReport_should_return_only_lines_with_this_revenueReversalCode() {
        initEnteredAreaReportFixture();

        Company company = (Company) getSession().get(Company.class, 900000001L);
        Crop crop = (Crop) getSession().get(Crop.class, 900000001L);

        String revenueReversalCode = "900000003";
        EnteredAreaReportViewFilter filter = EnteredAreaReportViewFilter.getInstance(company, crop, getMockedUser());
        filter.addRevenueReversalCode(revenueReversalCode);

        List<EnteredAreaReportView> enteredAreas = volumeReportDetailService.selectEnteredAreaReportViewBy(filter);
        Assert.assertFalse("Should return results", enteredAreas.isEmpty());
        for (EnteredAreaReportView enteredAreaReportView : enteredAreas) {
            Assert.assertEquals("RevenueReversalCode should be equals", revenueReversalCode, enteredAreaReportView.getRevenueReversalCode());
        }
    }

    @Test
    public void given_a_filter_with_revenueReversalDate_when_select_enteredAreaReport_should_return_only_lines_with_this_revenueReversalDate() {
        initEnteredAreaReportFixture();

        Company company = (Company) getSession().get(Company.class, 900000001L);
        Crop crop = (Crop) getSession().get(Crop.class, 900000001L);

        Date revenueReversalDateStart = CalendarUtil.getDate(2012, 06, 29);
        Date revenueReversalDateEnd = CalendarUtil.getDate(2012, 06, 31);

        EnteredAreaReportViewFilter filter = EnteredAreaReportViewFilter.getInstance(company, crop, getMockedUser());
        filter.addRevenueReversalDate(revenueReversalDateStart, revenueReversalDateEnd);

        List<EnteredAreaReportView> enteredAreas = volumeReportDetailService.selectEnteredAreaReportViewBy(filter);
        Assert.assertFalse("Should return results", enteredAreas.isEmpty());
        for (EnteredAreaReportView enteredAreaReportView : enteredAreas) {
            Assert.assertTrue("RevenueReversalDate should be after", enteredAreaReportView.getRevenueReversalDate().compareTo(revenueReversalDateStart) > -1);
            Assert.assertTrue("RevenueReversalDate should be before", enteredAreaReportView.getRevenueReversalDate().compareTo(revenueReversalDateEnd) < 1);
        }
    }

    @Test
    public void given_a_filter_with_matrix_when_select_enteredAreaReport_should_return_only_lines_with_this_matrix() {
        initEnteredAreaReportFixture();

        Company company = (Company) getSession().get(Company.class, 900000001L);
        Crop crop = (Crop) getSession().get(Crop.class, 900000001L);

        Customer matrix = (Customer) getSession().get(Customer.class, 900000001L);
        EnteredAreaReportViewFilter filter = EnteredAreaReportViewFilter.getInstance(company, crop, getMockedUser());
        filter.addMatrix(matrix);

        List<EnteredAreaReportView> enteredAreas = volumeReportDetailService.selectEnteredAreaReportViewBy(filter);
        Assert.assertFalse("Should return results", enteredAreas.isEmpty());
        for (EnteredAreaReportView enteredAreaReportView : enteredAreas) {
            Assert.assertEquals("Matrix id should be equals", matrix.getId(), enteredAreaReportView.getMatrixId());
            Assert.assertEquals("Matrix name should be equals", matrix.getName(), enteredAreaReportView.getMatrixDescription());
            Assert.assertEquals("Matrix sap code should be equals", matrix.getCustomerSAPCode(), enteredAreaReportView.getMatrixSAPCode());
            Assert.assertEquals("Matrix document should be equals", matrix.getDocumentValue(), enteredAreaReportView.getMatrixDocument());
            Assert.assertEquals("Matrix document mask should be equals", matrix.getDocument().getDocumentType().getMask(), enteredAreaReportView.getMatrixDocumentMask());
            Assert.assertEquals("Matrix city description should be equals", matrix.getAddress().getCity().getDescription(), enteredAreaReportView.getMatrixCityDescription());
            Assert.assertEquals("Matrix state code should be equals", matrix.getAddress().getState().getCode(), enteredAreaReportView.getMatrixStateCode());
        }
    }

    @Test
    public void given_a_filter_with_matrix_hierarchy_duplicated_when_select_enteredAreaReport_should_return_hierarchy_duplicated() {
        initEnteredAreaReportFixture();

        Company company = (Company) getSession().get(Company.class, 900000001L);
        Crop crop = (Crop) getSession().get(Crop.class, 900000001L);

        Customer matrix = (Customer) getSession().get(Customer.class, 990000004L);
        EnteredAreaReportViewFilter filter = EnteredAreaReportViewFilter.getInstance(company, crop, getMockedUser());
        filter.addMatrix(matrix);

        List<EnteredAreaReportView> enteredAreas = volumeReportDetailService.selectEnteredAreaReportViewBy(filter);
        Assert.assertFalse("Should return results", enteredAreas.isEmpty());
        for (EnteredAreaReportView enteredAreaReportView : enteredAreas) {
            Assert.assertNull("MatrixHierarchyUnity id should be null", enteredAreaReportView.getMatrixUnitSapId());
            Assert.assertEquals("MatrixHierarchyUnityDesc should be a bundle key", "label.entered.area.report.matrix.hierarchyDuplicated", enteredAreaReportView.getMatrixUnitSapDesc());
            Assert.assertNull("MatrixHierarchyRegion id should be null", enteredAreaReportView.getMatrixRegionSapId());
            Assert.assertEquals("MatrixHierarchyRegionDesc should be equals", "label.entered.area.report.matrix.hierarchyDuplicated", enteredAreaReportView.getMatrixRegionSapDesc());
            Assert.assertNull("MatrixHierarchyDistrict id should be null", enteredAreaReportView.getMatrixDistrictSapId());
            Assert.assertEquals("MatrixHierarchyDistrictDesc should be equals", "label.entered.area.report.matrix.hierarchyDuplicated", enteredAreaReportView.getMatrixDistrictSapDesc());
        }
    }

    @Test
    public void given_a_filter_with_matrix_without_hierarchy_when_select_enteredAreaReport_should_not_return_hierarchy() {
        initEnteredAreaReportFixture();

        Company company = (Company) getSession().get(Company.class, 900000001L);
        Crop crop = (Crop) getSession().get(Crop.class, 900000001L);

        Customer matrix = (Customer) getSession().get(Customer.class, 900000005L);
        EnteredAreaReportViewFilter filter = EnteredAreaReportViewFilter.getInstance(company, crop, getMockedUser());
        filter.addMatrix(matrix);

        List<EnteredAreaReportView> enteredAreas = volumeReportDetailService.selectEnteredAreaReportViewBy(filter);
        Assert.assertFalse("Should return results", enteredAreas.isEmpty());
        for (EnteredAreaReportView enteredAreaReportView : enteredAreas) {
            Assert.assertEquals("Matrix id should be equals", matrix.getId(), enteredAreaReportView.getMatrixId());
            Assert.assertNull("MatrixHierarchyUnity id should be null", enteredAreaReportView.getMatrixUnitSapId());
            Assert.assertNull("MatrixHierarchyUnityDesc should be null", enteredAreaReportView.getMatrixUnitSapDesc());
            Assert.assertNull("MatrixHierarchyRegion id should be null", enteredAreaReportView.getMatrixRegionSapId());
            Assert.assertNull("MatrixHierarchyRegionDesc should be null", enteredAreaReportView.getMatrixRegionSapDesc());
            Assert.assertNull("MatrixHierarchyDistrict id should be null", enteredAreaReportView.getMatrixDistrictSapId());
            Assert.assertNull("MatrixHierarchyDistrictDesc should be null", enteredAreaReportView.getMatrixDistrictSapDesc());
        }
    }

    @Test
    public void given_a_filter_with_partner_without_hierarchy_when_select_enteredAreaReport_should_not_return_hierarchy() {
        initEnteredAreaReportFixture();

        Company company = (Company) getSession().get(Company.class, 900000001L);
        Crop crop = (Crop) getSession().get(Crop.class, 900000001L);

        Customer partner = (Customer) getSession().get(Customer.class, 900000005L);
        EnteredAreaReportViewFilter filter = EnteredAreaReportViewFilter.getInstance(company, crop, getMockedUser());
        filter.addPartner(partner);

        List<EnteredAreaReportView> enteredAreas = volumeReportDetailService.selectEnteredAreaReportViewBy(filter);
        Assert.assertFalse("Should return results", enteredAreas.isEmpty());
        for (EnteredAreaReportView enteredAreaReportView : enteredAreas) {
            Assert.assertEquals("Partner id should be equals", partner.getId(), enteredAreaReportView.getPartnerId());
            Assert.assertNull("PartnerHierarchyUnity id should be null", enteredAreaReportView.getPartnerUnitSapId());
            Assert.assertNull("PartnerHierarchyUnityDesc should be null", enteredAreaReportView.getPartnerUnitSapDesc());
            Assert.assertNull("PartnerHierarchyRegion id should be null", enteredAreaReportView.getPartnerRegionSapId());
            Assert.assertNull("PartnerHierarchyRegionDesc should be null", enteredAreaReportView.getPartnerRegionSapDesc());
            Assert.assertNull("PartnerHierarchyDistrict id should be null", enteredAreaReportView.getPartnerDistrictSapId());
            Assert.assertNull("PartnerHierarchyDistrictDesc should be null", enteredAreaReportView.getPartnerDistrictSapDesc());
        }
    }

    @Test
    public void given_a_filter_with_partner_hierarchy_duplicated_when_select_enteredAreaReport_should_return_hierarchy_duplicated() {
        initEnteredAreaReportFixture();

        Company company = (Company) getSession().get(Company.class, 900000001L);
        Crop crop = (Crop) getSession().get(Crop.class, 900000001L);

        Customer partner = (Customer) getSession().get(Customer.class, 990000004L);
        EnteredAreaReportViewFilter filter = EnteredAreaReportViewFilter.getInstance(company, crop, getMockedUser());
        filter.addPartner(partner);

        List<EnteredAreaReportView> enteredAreas = volumeReportDetailService.selectEnteredAreaReportViewBy(filter);
        Assert.assertFalse("Should return results", enteredAreas.isEmpty());
        for (EnteredAreaReportView enteredAreaReportView : enteredAreas) {
            Assert.assertNull("PartnerHierarchyUnity id should be null", enteredAreaReportView.getPartnerUnitSapId());
            Assert.assertEquals("PartnerHierarchyUnityDesc should be a bundle key", "label.entered.area.report.partner.hierarchyDuplicated", enteredAreaReportView.getPartnerUnitSapDesc());
            Assert.assertNull("PartnerHierarchyRegion id should be null", enteredAreaReportView.getPartnerRegionSapId());
            Assert.assertEquals("PartnerHierarchyRegionDesc should be equals", "label.entered.area.report.partner.hierarchyDuplicated", enteredAreaReportView.getPartnerRegionSapDesc());
            Assert.assertNull("PartnerHierarchyDistrict id should be null", enteredAreaReportView.getPartnerDistrictSapId());
            Assert.assertEquals("PartnerHierarchyDistrictDesc should be equals", "label.entered.area.report.partner.hierarchyDuplicated", enteredAreaReportView.getPartnerDistrictSapDesc());
        }
    }

    @Test
    public void given_a_filter_with_user_participant_when_select_enteredAreaReport_should_return_only_lines_with_customers_that_user_have_access() {
        initEnteredAreaReportFixture();

        Company company = (Company) getSession().get(Company.class, 900000001L);
        Crop crop = (Crop) getSession().get(Crop.class, 900000001L);
        UserDecorator user = getMockedUser();

        List<Customer> partners = new ArrayList<Customer>();
        partners.add((Customer) getSession().get(Customer.class, 990000004L));
        Mockito.when(user.getContextPartnersBy(Mockito.any(Crop.class), Mockito.any(Company.class), Mockito.any(ParticipantTypeEnum.class))).thenReturn(partners);
        Mockito.when(user.getContextHeadOfficesBy(Mockito.any(ParticipantTypeEnum.class), Mockito.any(Company.class))).thenReturn(null);

        EnteredAreaReportViewFilter filter = EnteredAreaReportViewFilter.getInstance(company, crop, user);
        List<EnteredAreaReportView> enteredAreas = volumeReportDetailService.selectEnteredAreaReportViewBy(filter);
        Assert.assertFalse("Should return results", enteredAreas.isEmpty());
        for (EnteredAreaReportView enteredAreaReportView : enteredAreas) {
            Assert.assertTrue("Partner id should be equals", enteredAreaReportView.getPartnerId().equals(990000004L));
        }
    }

    @Test
    public void given_a_filter_with_user_participant_when_select_enteredAreaReport_should_return_only_lines_with_matrix_that_user_have_access() {
        initEnteredAreaReportFixture();

        Company company = (Company) getSession().get(Company.class, 900000001L);
        Crop crop = (Crop) getSession().get(Crop.class, 900000001L);
        UserDecorator user = getMockedUser();

        Mockito.when(user.getContextPartnersBy(Mockito.any(Crop.class), Mockito.any(Company.class), Mockito.any(ParticipantTypeEnum.class))).thenReturn(null);
        List<Customer> matrixes = new ArrayList<Customer>();
        matrixes.add((Customer) getSession().get(Customer.class, 990000004L));
        Mockito.when(user.getContextHeadOfficesBy(Mockito.any(ParticipantTypeEnum.class), Mockito.any(Company.class))).thenReturn(matrixes);

        EnteredAreaReportViewFilter filter = EnteredAreaReportViewFilter.getInstance(company, crop, user);
        List<EnteredAreaReportView> enteredAreas = volumeReportDetailService.selectEnteredAreaReportViewBy(filter);
        Assert.assertFalse("Should return results", enteredAreas.isEmpty());
        for (EnteredAreaReportView enteredAreaReportView : enteredAreas) {
            Assert.assertTrue("Matrix id should be equals", enteredAreaReportView.getMatrixId().equals(990000004L));
        }
    }

    private UserDecorator getMockedUser() {
        return Mockito.mock(UserDecorator.class);
    }

    @Test
    public void given_a_filter_with_hierarchyMatrix_when_select_enteredAreaReport_should_return_only_lines_with_this_hierarchyMatrix() {
        initEnteredAreaReportFixture();

        Company company = (Company) getSession().get(Company.class, 900000001L);
        Crop crop = (Crop) getSession().get(Crop.class, 900000001L);

        ItsUnity matrixUnity = (ItsUnity) getSession().get(ItsUnity.class, 900000001L);
        ItsRegion matrixRegion = (ItsRegion) getSession().get(ItsRegion.class, 900000001L);
        ItsDistrict matrixDistrict = (ItsDistrict) getSession().get(ItsDistrict.class, 900000001L);


        EnteredAreaReportViewFilter filter = EnteredAreaReportViewFilter.getInstance(company, crop, getMockedUser());
        filter.addHierarchyMatrix(matrixUnity, matrixRegion, matrixDistrict);

        List<EnteredAreaReportView> enteredAreas = volumeReportDetailService.selectEnteredAreaReportViewBy(filter);
        Assert.assertFalse("Should return results", enteredAreas.isEmpty());
        for (EnteredAreaReportView enteredAreaReportView : enteredAreas) {
            Assert.assertEquals("MatrixHierarchyUnityDesc id should be equals", "_UN_", enteredAreaReportView.getMatrixUnitSapId());
            Assert.assertEquals("MatrixHierarchyUnityDesc id should be equals", "_UNUN_", enteredAreaReportView.getMatrixUnitSapDesc());
            Assert.assertEquals("MatrixHierarchyRegionDesc id should be equals", "_RG_", enteredAreaReportView.getMatrixRegionSapId());
            Assert.assertEquals("MatrixHierarchyRegionDesc id should be equals", "_REGREG_", enteredAreaReportView.getMatrixRegionSapDesc());
            Assert.assertEquals("MatrixHierarchyDistrictDesc id should be equals", "_DS_", enteredAreaReportView.getMatrixDistrictSapId());
            Assert.assertEquals("MatrixHierarchyDistrictDesc id should be equals", "_DISDIS_", enteredAreaReportView.getMatrixDistrictSapDesc());
        }
    }

    @SuppressWarnings("unchecked")
    private void initEnteredAreaReportFixture() {
        DbUnitHelper.setup("classpath:data/multiplier/basic-fixture.xml",
                "classpath:data/multiplier/entered-area-report-dataset.xml");
        if (!getAssumptionTest().isEnvironmentWithSQLANSI()) {
            List<VolumeReportDetail> details = (List<VolumeReportDetail>) getSession().createCriteria(VolumeReportDetail.class).list();
            HashMap<VolumeReportDetail, RevenueAccount> detailAccountMap = new HashMap<VolumeReportDetail, RevenueAccount>();

            for (VolumeReportDetail detail : details) {
                if (detail.getRevenueAccountId() != null) {
                    RevenueAccount account = (RevenueAccount) getSession().get(RevenueAccount.class, detail.getRevenueAccountId());
                    detailAccountMap.put(detail, account);
                } else {
                    detailAccountMap.put(detail, null);
                }
            }

            List<EnteredAreaReportView> enteredAreas = VolumeReportTestData.createEnteredAreaReportViewFrom(details, detailAccountMap);
            for (EnteredAreaReportView enteredAreaReportView : enteredAreas) {
                saveAndFlush(enteredAreaReportView);
            }

            List<Customer> customers = getSession().createCriteria(Customer.class).list();
            List<CustomerHierarchyFilterView> filterViews = CustomerTestData.createCustomerHierarchyFilterViewBy(customers);
            for (CustomerHierarchyFilterView customerHierarchyFilterView : filterViews) {
                saveAndFlush(customerHierarchyFilterView);
            }

            List<CustomerHierarchyDetailView> detailViews = CustomerTestData.createCustomerDetailViewBy(customers);
            for (CustomerHierarchyDetailView customerHierarchyDetailView : detailViews) {
                saveAndFlush(customerHierarchyDetailView);
            }

        }
    }

    /**
     * @return
     */
    private VolumeReportHeader createAndSaveHeaderWithDetail() {
        Harvest harvest = (Harvest) getSession().get(Harvest.class, HARVEST1);
        Obtainer obtainer = (Obtainer) getSession().get(Obtainer.class, OBTAINER1);
        HeadOffice headOffice = (HeadOffice) getSession().get(HeadOffice.class, HEADOFFICE1);
        Cultivar cultivar = (Cultivar) getSession().get(Cultivar.class, CULTIVAR1);
        ItsClass itsClass = (ItsClass) getSession().get(ItsClass.class, CLASS1);

        VolumeReportHeader header = new VolumeReportHeader(harvest, headOffice.getCustomer(), headOffice.getMatrix(), obtainer);
        final VolumeReportDetail detail = new VolumeReportDetail(cultivar, itsClass, header);
        header.addVolumeReportDetail(detail);

        volumeReportService.save(header);
        getSession().flush();
        return header;
    }

    private class StateHelper {
        public Cultivar cultivarSet;
        public ItsClass classSet;
    }

}
