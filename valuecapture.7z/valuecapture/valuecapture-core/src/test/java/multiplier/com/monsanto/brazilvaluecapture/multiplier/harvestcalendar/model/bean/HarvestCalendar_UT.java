package com.monsanto.brazilvaluecapture.multiplier.harvestcalendar.model.bean;

import com.monsanto.brazilvaluecapture.core.foundation.test.AssertHelper;
import org.junit.Test;

public class HarvestCalendar_UT {


    @Test
    public void testGettersAndSetters() {
        HarvestCalendar harvestCalendar = new HarvestCalendar();
        AssertHelper.testGettersAndSetters(harvestCalendar);
    }
}
