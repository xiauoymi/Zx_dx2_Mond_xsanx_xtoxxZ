package com.monsanto.brazilvaluecapture.multiplier.revenue.service.predicates;

import com.monsanto.brazilvaluecapture.seedsale.billing.model.bean.BillingCalendar;
import com.monsanto.brazilvaluecapture.seedsale.template.model.bean.SaleTemplate;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.ArrayList;

import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class SaleTemplateBillingCalendarPredicate_UT {

    @Mock
    private BillingCalendar billingCalendar;

    @Mock
    private SaleTemplate saleTemplate;

    @Mock
    private SaleTemplate otherSaleTemplate;

    @Mock
    private BillingCalendar otherBillingCalendar;

    private SaleTemplateBillingCalendarPredicate saleTemplateBillingCalendarPredicate;

    @Before
    public void startUp() {
        MockitoAnnotations.initMocks(this);
        saleTemplateBillingCalendarPredicate = new SaleTemplateBillingCalendarPredicate(saleTemplate);
        when(billingCalendar.getSaleTemplate()).thenReturn(saleTemplate);
        when(saleTemplate.getId()).thenReturn(1L);
        when(otherSaleTemplate.getId()).thenReturn(2L);
        when(otherBillingCalendar.getSaleTemplate()).thenReturn(otherSaleTemplate);
    }

    @Test
    public void saleTest() {
        saleTemplateBillingCalendarPredicate.evaluate(billingCalendar);
    }

    @Test
    public void otherSaleTest() {
        saleTemplateBillingCalendarPredicate.evaluate(otherBillingCalendar);
    }

}
