package com.monsanto.brazilvaluecapture.multiplier.revenue.service;

import com.monsanto.brazilvaluecapture.seedsale.product.model.bean.Product;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.Sale;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.SaleItem;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.SaleLinkDetail;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.SaleLinkDetailValue;
import com.monsanto.brazilvaluecapture.seedsale.sale.service.impl.ControllershipTestConfigurator;
import com.monsanto.brazilvaluecapture.utils.DateRange;
import com.monsanto.brazilvaluecapture.utils.DateUtils;
import org.junit.Test;

import java.math.BigDecimal;

import static org.fest.assertions.Assertions.assertThat;

public class RevenueRecognitionCalculatorImpl_UT extends ControllershipTestConfigurator {

    @Test
    public void testCalculateRevenueRecognitionForPeriodReturns320_WhenNetQtyIs200_KgByHaIs5_ConsumedInPeriodIs8() {
        RevenueRecognitionCalculator revenueRecognitionCalculator = new RevenueRecognitionCalculatorImpl();
        DateRange period = DateUtils.getLastMonthDateRange();
        Product product = createProduct("product", false);
        final String batchName = "batchName";
        SaleLinkDetail saleLinkDetail = createSaleLinkDetailWithOneSaleItem(product, batchName, BigDecimal.valueOf(200), BigDecimal.valueOf(40), BigDecimal.valueOf(200));
        BigDecimal toConsume = BigDecimal.valueOf(8);
        consumeFromSaleLinkDetail(period, product, batchName, saleLinkDetail, toConsume);

        final BigDecimal revenueRecognition = revenueRecognitionCalculator.getRevenueRecognition(saleLinkDetail, period);

        assertThat(revenueRecognition).isEqualTo(BigDecimal.valueOf(320).setScale(2, BigDecimal.ROUND_HALF_UP));
    }

    @Test
    public void testCalculateRevenueRecognitionForPeriodReturns160_WhenNetQtyIs100_KgByHaIs5_ConsumedInPeriodIs8() {
        RevenueRecognitionCalculator revenueRecognitionCalculator = new RevenueRecognitionCalculatorImpl();
        DateRange period = DateUtils.getLastMonthDateRange();
        Product product = createProduct("product", false);
        final String batchName = "batchName";
        SaleLinkDetail saleLinkDetail = createSaleLinkDetailWithOneSaleItem(product, batchName, BigDecimal.valueOf(100), BigDecimal.valueOf(20), BigDecimal.valueOf(100));
        BigDecimal toConsume = BigDecimal.valueOf(8);
        consumeFromSaleLinkDetail(period, product, batchName, saleLinkDetail, toConsume);

        final BigDecimal revenueRecognition = revenueRecognitionCalculator.getRevenueRecognition(saleLinkDetail, period);

        assertThat(revenueRecognition).isEqualTo(BigDecimal.valueOf(160).setScale(2, BigDecimal.ROUND_HALF_UP));
    }

    @Test
    public void testCalculateRevenueRecognitionForPeriodReturns30_19_WhenNetQtyIs105_KgByHaIs80_ConsumedInPeriodIs23() {
        RevenueRecognitionCalculator revenueRecognitionCalculator = new RevenueRecognitionCalculatorImpl();
        DateRange period = DateUtils.getLastMonthDateRange();
        Product product = createProduct("product", false);
        final String batchName = "batchName";
        SaleLinkDetail saleLinkDetail = createSaleLinkDetailWithOneSaleItem(product, batchName, BigDecimal.valueOf(160), BigDecimal.valueOf(2), BigDecimal.valueOf(105));
        BigDecimal toConsume = BigDecimal.valueOf(23);
        consumeFromSaleLinkDetail(period, product, batchName, saleLinkDetail, toConsume);

        final BigDecimal revenueRecognition = revenueRecognitionCalculator.getRevenueRecognition(saleLinkDetail, period);

        assertThat(revenueRecognition).isEqualTo(BigDecimal.valueOf(30.13f).setScale(2, BigDecimal.ROUND_HALF_UP));
    }

    @Test
    public void testCalculateRevenueRecognitionForPeriodUpdatesProportionalRevenueRecognitionInSaleLinkDetailValue() {
        RevenueRecognitionCalculator revenueRecognitionCalculator = new RevenueRecognitionCalculatorImpl();
        DateRange period = DateUtils.getLastMonthDateRange();
        Product product = createProduct("product", false);
        final String batchName = "batchName";
        SaleLinkDetail saleLinkDetail = createSaleLinkDetailWithOneSaleItem(product, batchName, BigDecimal.valueOf(160), BigDecimal.valueOf(2), BigDecimal.valueOf(105));
        BigDecimal toConsume = BigDecimal.valueOf(23);
        consumeFromSaleLinkDetail(period, product, batchName, saleLinkDetail, toConsume);

        revenueRecognitionCalculator.getRevenueRecognition(saleLinkDetail, period);

        final SaleLinkDetailValue saleLinkDetailValue = saleLinkDetail.getSaleLinkDetailValueSet().iterator().next();
        assertThat(saleLinkDetailValue.getRevenueRecognition()).isEqualTo(BigDecimal.valueOf(30.13f).setScale(2, BigDecimal.ROUND_HALF_UP));
    }

    @Test
    public void testCalculateRevenueRecognitionUpdatesRevenueRecognitionOfLinkedSaleItems() {
        RevenueRecognitionCalculator revenueRecognitionCalculator = new RevenueRecognitionCalculatorImpl();
        DateRange period = DateUtils.getLastMonthDateRange();
        Product product = createProduct("product", false);
        final String batchName = "batchName";
        SaleLinkDetail saleLinkDetail = createSaleLinkDetailWithOneSaleItem(product, batchName, BigDecimal.valueOf(100), BigDecimal.valueOf(20), BigDecimal.valueOf(100));
        BigDecimal toConsume = BigDecimal.valueOf(8);
        final SaleItem saleItem = consumeFromSaleLinkDetail(period, product, batchName, saleLinkDetail, toConsume);

        revenueRecognitionCalculator.getRevenueRecognition(saleLinkDetail, period);

        BigDecimal expectedRevenueRecognition = BigDecimal.valueOf(160).setScale(2, BigDecimal.ROUND_HALF_UP);
        assertThat(saleItem.getRevenueRecognition()).isEqualTo(expectedRevenueRecognition);
    }

    private SaleItem consumeFromSaleLinkDetail(DateRange period, Product product, String batchName, SaleLinkDetail saleLinkDetail, BigDecimal toConsume) {
        Sale dealerSale = createDealerSale(period.getDateTo());
        SaleItem dealerSaleItem = addSaleItemToSale(dealerSale, new ItemDescription(toConsume, product, batchName, plantability, BigDecimal.valueOf(20)), null);
        saleLinkDetail.consume(dealerSale, toConsume, dealerSaleItem);
        return dealerSaleItem;
    }

    private SaleLinkDetail createSaleLinkDetailWithOneSaleItem(Product product, String batchName, BigDecimal soldQty, BigDecimal haAmount, BigDecimal netQty) {
        Sale multiplierSale = createMultiplierSale();
        SaleItem multiplierSaleItem = addSaleItemToSale(multiplierSale, new ItemDescription(soldQty, product, batchName, plantability, haAmount), netQty);
        return new SaleLinkDetail(multiplierSale, multiplierSaleItem);
    }

    public SaleItem createSaleItem(BigDecimal netQuantity, BigDecimal haAmount, long soldQuantity, BigDecimal consumed) {
        SaleItem saleItem = new SaleItem();
        saleItem.setNetQuantity(netQuantity);
        saleItem.setHaAmount(haAmount);
        saleItem.setSoldQuantity(soldQuantity);
        SaleLinkDetail saleLinkDetail = new SaleLinkDetail();
        saleLinkDetail.setConsumed(consumed);
        saleLinkDetail.setSaleItem(saleItem);
        saleItem.setSaleLinkDetail(saleLinkDetail);
        return saleItem;
    }

}