package com.monsanto.brazilvaluecapture.multiplier.volumereport.service.impl;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import org.mockito.Mockito;

import com.monsanto.brazilvaluecapture.core.customer.model.bean.Customer;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.HeadOffice;
import com.monsanto.brazilvaluecapture.core.revenue.model.bean.RevenueAccount;
import com.monsanto.brazilvaluecapture.core.user.model.bean.UserContext;
import com.monsanto.brazilvaluecapture.multiplier.cultivar.model.bean.Cultivar;
import com.monsanto.brazilvaluecapture.multiplier.itsclass.model.bean.ItsClass;
import com.monsanto.brazilvaluecapture.multiplier.obtainer.model.bean.Obtainer;
import com.monsanto.brazilvaluecapture.multiplier.volumereport.model.bean.EnteredAreaReportView;
import com.monsanto.brazilvaluecapture.multiplier.volumereport.model.bean.VolumeReportApprovalDTO;
import com.monsanto.brazilvaluecapture.multiplier.volumereport.model.bean.VolumeReportByMatrixApprovalDTO;
import com.monsanto.brazilvaluecapture.multiplier.volumereport.model.bean.VolumeReportDetail;
import com.monsanto.brazilvaluecapture.multiplier.volumereport.model.bean.VolumeReportDetailView;
import com.monsanto.brazilvaluecapture.multiplier.volumereport.model.bean.VolumeReportFieldEnum;
import com.monsanto.brazilvaluecapture.multiplier.volumereport.model.bean.VolumeReportHeader;
import com.monsanto.brazilvaluecapture.multiplier.volumereport.model.bean.VolumeReportStatus;
import com.monsanto.brazilvaluecapture.seedsale.harvest.model.bean.Harvest;

public class VolumeReportTestData {
    public static final BigDecimal VALID_VALUE = BigDecimal.valueOf(10d);
    public static final BigDecimal INVALID_VALUE = BigDecimal.valueOf(-10d);

    public static VolumeReportHeader generateVolumeReportHeader(Harvest harvest, HeadOffice headOffice, Obtainer obtainer) {
        return new VolumeReportHeader(harvest,headOffice.getCustomer(),headOffice.getMatrix(), obtainer);
    }

    public static VolumeReportHeader generateVolumeReportHeader(Harvest harvest, HeadOffice headOffice, Obtainer obtainer, ItsClass[] classes, Cultivar[] cultivars) {
        VolumeReportHeader header = generateVolumeReportHeader(harvest,headOffice,obtainer);
        for(ItsClass itsClass:classes) {
            for(Cultivar cultivar:cultivars) {
                VolumeReportDetail detail = new VolumeReportDetail(cultivar,itsClass,header);
                detail.setProductivity(BigInteger.ONE);
                header.addVolumeReportDetail(detail);
            }
        }
        return header;
    }

    public static void updateToPhase2_1(VolumeReportDetail detail) {
    	detail.setVolumeReportDetailPhase1Status(VolumeReportStatus.APPROVED);
    }

    public static void updateToPhase2_2(VolumeReportDetail detail) {
        updateToPhase2_1(detail);
        detail.getPortioning().setStatus(VolumeReportStatus.APPROVED);
    }

    public static void updateToPhase2_3(VolumeReportDetail detail) {
        updateToPhase2_2(detail);
        detail.getVolumeHarvested().setStatus(VolumeReportStatus.APPROVED);
    }

    public static void updateToPhase3(VolumeReportDetail detail) {
        updateToPhase2_3(detail);
        detail.getVolumeForUBS().setStatus(VolumeReportStatus.APPROVED);
    }

    public static void updateToPhase4(VolumeReportDetail detail) {
        updateToPhase3(detail);
        detail.getVolumeBenefitted().setStatus(VolumeReportStatus.APPROVED);
    }

    public static void updateToPhase5(VolumeReportDetail detail) {
        updateToPhase4(detail);
        detail.getVolumeApproved().setStatus(VolumeReportStatus.APPROVED);
    }

    public static void updateToPhase5_1(VolumeReportDetail detail) {
        updateToPhase5(detail);
        detail.getVolumeCommercialized1().setStatus(VolumeReportStatus.APPROVED);
    }

    public static void updateToPhase5_2(VolumeReportDetail detail) {
        updateToPhase5_1(detail);
        detail.getVolumeCommercialized2().setStatus(VolumeReportStatus.APPROVED);
    }

    public static void updateToPhase5_3(VolumeReportDetail detail) {
        updateToPhase5_2(detail);
        detail.getVolumeCommercialized3().setStatus(VolumeReportStatus.APPROVED);
    }

    public static void updateToPhase6(VolumeReportDetail detail) {

        if(detail.getCultivar().getChargeGermoplasm()) {
            updateToPhase5_3(detail);
        } else {
            updateToPhase5_2(detail);
        }
    }

    public static void updateToAllReported(VolumeReportDetail detail) {
        updateToPhase6(detail);
        detail.getVolumeForNextHarvest().setStatus(VolumeReportStatus.APPROVED);
    }

    public static void fillWithValues(VolumeReportDetail detail, VolumeReportFieldEnum volumeReportFieldEnum[], BigDecimal value) {
        for (VolumeReportFieldEnum reportFieldEnum : volumeReportFieldEnum) {
            detail.getFieldByPhase(reportFieldEnum).setValue(value);
        }
    }


    public static List<VolumeReportByMatrixApprovalDTO> generateApprovalDTO(VolumeReportFieldEnum fieldEnum, Long detailId) {
        List<VolumeReportByMatrixApprovalDTO> volumeReportByMatrixApprovalDTOs = new ArrayList<VolumeReportByMatrixApprovalDTO>(1);
        VolumeReportByMatrixApprovalDTO matrixApprovalDTO = new VolumeReportByMatrixApprovalDTO("111", "111", "111");
        VolumeReportApprovalDTO dto = Mockito.mock(VolumeReportApprovalDTO.class);
        Mockito.when(dto.hasNewApproval()).thenReturn(true);
        Mockito.when(dto.findNewApproval()).thenReturn(fieldEnum);
        Mockito.when(dto.getDetailId()).thenReturn(detailId);
        matrixApprovalDTO.addApprovalDTO(dto);
        volumeReportByMatrixApprovalDTOs.add(matrixApprovalDTO);
        return volumeReportByMatrixApprovalDTOs;
    }

    public static UserContext mockUser(String login) {
        UserContext user = Mockito.mock(UserContext.class);
        Mockito.when(user.getLogin()).thenReturn(login);
        return user;
    }

    public static Collection<VolumeReportDetailView> createVolumeReportDetailViewsFrom(VolumeReportHeader header) {
        List<VolumeReportDetailView> detailViews = new ArrayList<VolumeReportDetailView>();
        for(VolumeReportDetail detail:header.getVolumeReportDetails()) {
            detailViews.add(createVolumeReportDetailViewFrom(detail,header.getObtainer(),header.getCustomer(),header.getMatrix(),header.getHarvest(),header.getId()));
        }
        return detailViews;
    }

    public static VolumeReportDetailView createVolumeReportDetailViewFrom(VolumeReportDetail detail, Obtainer obtainer, Customer customer, Customer matrix, Harvest harvest, Long headerId) {
        Long detailParentId = null;
    	if(detail.getVolumeReportDetailParent() != null) {
        	detailParentId = detail.getVolumeReportDetailParent().getId();
        }
    	return new VolumeReportDetailView(detail.getId(), detail.getCultivar().getId(), detail.getItsClass().getId(), headerId, detailParentId, detail.getEnteredArea().getId(), detail.getEnteredArea().getVolumeReportField(),
                detail.getEnteredArea().getStatus(), detail.getEnteredArea().getValue(),detail.getEnteredArea().getReportDate(), detail.getEnteredArea().getApproverLogin(), detail.getEnteredArea().getReproverLogin(),
                detail.getOwnSeedUsed().getId(),detail.getOwnSeedUsed().getVolumeReportField(),detail.getOwnSeedUsed().getStatus(),detail.getOwnSeedUsed().getValue(),detail.getOwnSeedUsed().getReportDate(),
                detail.getOwnSeedUsed().getApproverLogin(),detail.getOwnSeedUsed().getReproverLogin(),detail.getMatrixSeedUsed().getId(),detail.getMatrixSeedUsed().getVolumeReportField(),
                detail.getMatrixSeedUsed().getStatus(),detail.getMatrixSeedUsed().getValue(),detail.getMatrixSeedUsed().getReportDate(),detail.getMatrixSeedUsed().getApproverLogin(),
                detail.getMatrixSeedUsed().getReproverLogin(),detail.getPortioning().getId(),detail.getPortioning().getVolumeReportField(),detail.getPortioning().getStatus(),
                detail.getPortioning().getValue(),detail.getPortioning().getReportDate(),detail.getPortioning().getApproverLogin(),detail.getPortioning().getReproverLogin(),
                detail.getVolumeHarvested().getId(),detail.getVolumeHarvested().getVolumeReportField(),detail.getVolumeHarvested().getStatus(),detail.getVolumeHarvested().getValue(),
                detail.getVolumeHarvested().getReportDate(),detail.getVolumeHarvested().getApproverLogin(),detail.getVolumeHarvested().getReproverLogin(),detail.getVolumeForUBS().getId(),
                detail.getVolumeForUBS().getVolumeReportField(),detail.getVolumeForUBS().getStatus(),detail.getVolumeForUBS().getValue(),detail.getVolumeForUBS().getReportDate(),
                detail.getVolumeForUBS().getApproverLogin(),detail.getVolumeForUBS().getReproverLogin(),detail.getVolumeBenefitted().getId(),detail.getVolumeBenefitted().getVolumeReportField(),
                detail.getVolumeBenefitted().getStatus(),detail.getVolumeBenefitted().getValue(),detail.getVolumeBenefitted().getReportDate(),detail.getVolumeBenefitted().getApproverLogin(),
                detail.getVolumeBenefitted().getReproverLogin(),detail.getVolumeApproved().getId(),detail.getVolumeApproved().getVolumeReportField(),detail.getVolumeApproved().getStatus(),
                detail.getVolumeApproved().getValue(),detail.getVolumeApproved().getReportDate(),detail.getVolumeApproved().getApproverLogin(),detail.getVolumeApproved().getReproverLogin(),
                detail.getVolumeCommercialized1().getId(),detail.getVolumeCommercialized1().getVolumeReportField(),detail.getVolumeCommercialized1().getStatus(),detail.getVolumeCommercialized1().getValue(),
                detail.getVolumeCommercialized1().getReportDate(),detail.getVolumeCommercialized1().getApproverLogin(),detail.getVolumeCommercialized1().getReproverLogin(),
                detail.getVolumeCommercialized2().getId(),detail.getVolumeCommercialized2().getVolumeReportField(),detail.getVolumeCommercialized2().getStatus(),detail.getVolumeCommercialized2().getValue(),
                detail.getVolumeCommercialized2().getReportDate(),detail.getVolumeCommercialized2().getApproverLogin(),detail.getVolumeCommercialized2().getReproverLogin(),
                detail.getVolumeCommercialized3().getId(),detail.getVolumeCommercialized3().getVolumeReportField(),detail.getVolumeCommercialized3().getStatus(),detail.getVolumeCommercialized3().getValue(),
                detail.getVolumeCommercialized3().getReportDate(),detail.getVolumeCommercialized3().getApproverLogin(),detail.getVolumeCommercialized3().getReproverLogin(),
                detail.getVolumeForNextHarvest().getId(),detail.getVolumeForNextHarvest().getVolumeReportField(),detail.getVolumeForNextHarvest().getStatus(),detail.getVolumeForNextHarvest().getValue(),
                detail.getVolumeForNextHarvest().getReportDate(),detail.getVolumeForNextHarvest().getApproverLogin(),detail.getVolumeForNextHarvest().getReproverLogin(), detail.getRevenueAccountId());

    }

    
	public static List<EnteredAreaReportView> createEnteredAreaReportViewFrom(
			List<VolumeReportDetail> details, HashMap<VolumeReportDetail, RevenueAccount> detailAccountMap) {
		List<EnteredAreaReportView> enteredAreas = new ArrayList<EnteredAreaReportView>();

		for (VolumeReportDetail detail : details) {
			String matrixContractCode = null;
			
			RevenueAccount account = detailAccountMap.get(detail);
			
			Date revenuePostDate = null;
			String revenueDocumentNumber = null;
			String revenueOrderNumber = null;
			Date revenueReversalDate = null;
			String revenueReversalCode = null;
			String revenueReversalReason = null;
			if (account != null) {
				revenuePostDate = account.getPostDate();
				revenueDocumentNumber = account.getDocumentNumber();
				revenueOrderNumber = account.getOrderNumber();
				revenueReversalDate = account.getReversalDate();
				revenueReversalCode = account.getErpReversalCode();
				revenueReversalReason = account.getReversalReason();
			}
			
			String technologyDescription = null;
			Long technologyCode = null;
			if(detail.getCultivar().getTechnology() != null) {
				technologyDescription = detail.getCultivar().getTechnology().getDescription();
				technologyCode = detail.getCultivar().getTechnology().getId();
			}

			Long parentClassSequence = detail.getVolumeReportDetailParent() != null ? detail.getVolumeReportDetailParent().getItsClass().getSequence() : null;
			EnteredAreaReportView enteredAreaReportView = new EnteredAreaReportView(
					detail.getId(),
					detail.getVolumeReportHeader().getHarvest().getCompany().getId(),
					detail.getVolumeReportHeader().getHarvest().getCrop().getId(),
					detail.getVolumeReportHeader().getHarvest().getOperationalYear().getId(),
					detail.getVolumeReportHeader().getHarvest().getId(),
					detail.getVolumeReportHeader().getHarvest().getDescription(),
					detail.getVolumeReportHeader().getCustomer().getId(),
					detail.getVolumeReportHeader().getCustomer().getName(),
					detail.getVolumeReportHeader().getCustomer().getDocumentValue(),
					detail.getVolumeReportHeader().getCustomer().getDocument().getDocumentType().getMask(),
					detail.getVolumeReportHeader().getCustomer().getCustomerSAPCode(),
					detail.getVolumeReportHeader().getCustomer().getAddress().getCity().getId(),
					detail.getVolumeReportHeader().getCustomer().getAddress().getCity().getDescription(),
					detail.getVolumeReportHeader().getCustomer().getAddress().getState().getId(),
					detail.getVolumeReportHeader().getCustomer().getAddress().getState().getCode(),
					detail.getVolumeReportHeader().getMatrix().getId(),
					detail.getVolumeReportHeader().getMatrix().getName(),
					detail.getVolumeReportHeader().getMatrix().getDocumentValue(),
					detail.getVolumeReportHeader().getMatrix().getDocument().getDocumentType().getMask(),
					detail.getVolumeReportHeader().getMatrix().getCustomerSAPCode(),
					matrixContractCode,
					detail.getVolumeReportHeader().getMatrix().getAddress().getCity().getDescription(),
					detail.getVolumeReportHeader().getMatrix().getAddress().getState().getCode(),
					detail.getVolumeReportHeader().getObtainer().getId(),
					detail.getVolumeReportHeader().getObtainer().getDescription(),
					detail.getCultivar().getDescription(),
					detail.getItsClass().getSequence(), 
					parentClassSequence, 
					detail.getItsClass().getAbbreviation(), 
					detail.getEnteredArea().getValue(), 
					detail.getOwnSeedUsed().getValue(), 
					detail.getMatrixSeedUsed().getValue(), 
					detail.getTotalDiscardPortioning(), 
					detail.getVolumeHarvested().getValue(), 
					detail.getVolumeForUBS().getValue(),
					detail.getVolumeBenefitted().getValue(), 
					detail.getVolumeApproved().getValue(), 
					detail.getVolumeCommercialized1().getValue(),
					detail.getVolumeCommercialized2().getValue(), 
					detail.getVolumeCommercialized3().getValue(),
					detail.getVolumeForNextHarvest().getValue(),
					revenuePostDate,
					revenueDocumentNumber,
					revenueOrderNumber,
					revenueReversalDate,
					revenueReversalCode, revenueReversalReason, 
					technologyDescription, 
					technologyCode, 
					detail.getEnteredArea().getStatus(), 
					detail.getEnteredArea().getReportDate(), 
					detail.getPortioning().getReportDate(), 
					detail.getVolumeHarvested().getReportDate(), 
					detail.getVolumeForUBS().getReportDate(),
					detail.getVolumeApproved().getReportDate(), 
					detail.getVolumeBenefitted().getReportDate(), 
					detail.getVolumeCommercialized1().getReportDate(), 
					detail.getVolumeCommercialized2().getReportDate(), 
					detail.getVolumeCommercialized3().getReportDate(), 
					detail.getVolumeForNextHarvest().getReportDate(), detail.getCultivar().getChargeGermoplasm(), detail.getCultivar().getObtainerOnly());
			enteredAreas.add(enteredAreaReportView);
		}
    	
    	return enteredAreas;
    }
}
