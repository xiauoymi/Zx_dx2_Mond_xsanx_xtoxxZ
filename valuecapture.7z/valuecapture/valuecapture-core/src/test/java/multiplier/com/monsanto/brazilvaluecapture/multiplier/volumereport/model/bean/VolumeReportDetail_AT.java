package com.monsanto.brazilvaluecapture.multiplier.volumereport.model.bean;

import com.monsanto.brazilvaluecapture.core.customer.model.bean.Customer;
import com.monsanto.brazilvaluecapture.core.foundation.test.AbstractServiceIntegrationTests;
import com.monsanto.brazilvaluecapture.multiplier.cultivar.model.bean.Cultivar;
import com.monsanto.brazilvaluecapture.multiplier.harvestcalendar.model.bean.HarvestCalendar;
import com.monsanto.brazilvaluecapture.multiplier.itsclass.model.bean.ItsClass;
import com.monsanto.brazilvaluecapture.multiplier.obtainer.model.bean.Obtainer;
import com.monsanto.brazilvaluecapture.seedsale.harvest.model.bean.Harvest;
import junit.framework.Assert;
import org.junit.Test;
import org.mockito.Mockito;

import java.math.BigDecimal;
import java.util.Calendar;
import java.util.Date;


public class VolumeReportDetail_AT extends AbstractServiceIntegrationTests {


    protected Date pastDateStart;
    protected Date pastDateEnd;
    protected Date currentDateStart;
    protected Date currentDateEnd;
    protected Date futureDateStart;
    protected Date futureDateEnd;
    protected HarvestCalendar harvestCalendarPast;
    protected HarvestCalendar harvestCalendarCurrent;
    protected HarvestCalendar harvestCalendarFuture;

    private void createMockedHarvestCalendarCurrent() {
        harvestCalendarCurrent = Mockito.mock(HarvestCalendar.class);

        // Phase 1
        Mockito.when(harvestCalendarCurrent.getInscribedAreaStart()).thenReturn(currentDateStart);
        Mockito.when(harvestCalendarCurrent.getInscribedAreaEnd()).thenReturn(currentDateEnd);
        Mockito.when(harvestCalendarCurrent.getOwnSeedVolUsedStart()).thenReturn(currentDateStart);
        Mockito.when(harvestCalendarCurrent.getOwnSeedVolUsedEnd()).thenReturn(currentDateEnd);
        Mockito.when(harvestCalendarCurrent.getMatrixSeedVolOwnedStart()).thenReturn(currentDateStart);
        Mockito.when(harvestCalendarCurrent.getMatrixSeedVolOwnedEnd()).thenReturn(currentDateEnd);
        // Phase 2
        Mockito.when(harvestCalendarCurrent.getHarvestVolStart()).thenReturn(currentDateStart);
        Mockito.when(harvestCalendarCurrent.getHarvestVolEnd()).thenReturn(currentDateEnd);
        Mockito.when(harvestCalendarCurrent.getUbsDestVolStart()).thenReturn(currentDateStart);
        Mockito.when(harvestCalendarCurrent.getUbsDestVolEnd()).thenReturn(currentDateEnd);
        Mockito.when(harvestCalendarCurrent.getHarvestDiscardedAreaStart()).thenReturn(currentDateStart);
        Mockito.when(harvestCalendarCurrent.getHarvestDiscardedAreaEnd()).thenReturn(currentDateEnd);
        // phase 3
        Mockito.when(harvestCalendarCurrent.getBenefittedVolStart()).thenReturn(currentDateStart);
        Mockito.when(harvestCalendarCurrent.getBenefittedVolEnd()).thenReturn(currentDateEnd);
        // phase 4
        Mockito.when(harvestCalendarCurrent.getApprovedVolStart()).thenReturn(currentDateStart);
        Mockito.when(harvestCalendarCurrent.getApprovedVolEnd()).thenReturn(currentDateEnd);
        // Phase 5
        Mockito.when(harvestCalendarCurrent.getFirstCommldVolStart()).thenReturn(currentDateStart);
        Mockito.when(harvestCalendarCurrent.getFirstCommldVolEnd()).thenReturn(currentDateEnd);
        Mockito.when(harvestCalendarCurrent.getSecondCommldVolStart()).thenReturn(currentDateStart);
        Mockito.when(harvestCalendarCurrent.getSecondCommldVolEnd()).thenReturn(currentDateEnd);
        Mockito.when(harvestCalendarCurrent.getThirdCommldVolStart()).thenReturn(currentDateStart);
        Mockito.when(harvestCalendarCurrent.getThirdCommldVolEnd()).thenReturn(currentDateEnd);
        // phase 6
        Mockito.when(harvestCalendarCurrent.getNextHarvestVolStart()).thenReturn(currentDateStart);
        Mockito.when(harvestCalendarCurrent.getNextHarvestVolEnd()).thenReturn(currentDateEnd);
    }

    private void createMockedHarvestCalendarInPast() {
        harvestCalendarPast = Mockito.mock(HarvestCalendar.class);
        // Phase 1
        Mockito.when(harvestCalendarPast.getInscribedAreaStart()).thenReturn(pastDateStart);
        Mockito.when(harvestCalendarPast.getInscribedAreaEnd()).thenReturn(pastDateEnd);
        Mockito.when(harvestCalendarPast.getOwnSeedVolUsedStart()).thenReturn(pastDateStart);
        Mockito.when(harvestCalendarPast.getOwnSeedVolUsedEnd()).thenReturn(pastDateEnd);
        Mockito.when(harvestCalendarPast.getMatrixSeedVolOwnedStart()).thenReturn(pastDateStart);
        Mockito.when(harvestCalendarPast.getMatrixSeedVolOwnedEnd()).thenReturn(pastDateEnd);
        // Phase 2
        Mockito.when(harvestCalendarPast.getHarvestVolStart()).thenReturn(pastDateStart);
        Mockito.when(harvestCalendarPast.getHarvestVolEnd()).thenReturn(pastDateEnd);
        Mockito.when(harvestCalendarPast.getUbsDestVolStart()).thenReturn(pastDateStart);
        Mockito.when(harvestCalendarPast.getUbsDestVolEnd()).thenReturn(pastDateEnd);
        Mockito.when(harvestCalendarPast.getHarvestDiscardedAreaStart()).thenReturn(pastDateStart);
        Mockito.when(harvestCalendarPast.getHarvestDiscardedAreaEnd()).thenReturn(pastDateEnd);
        // phase 3
        Mockito.when(harvestCalendarPast.getBenefittedVolStart()).thenReturn(pastDateStart);
        Mockito.when(harvestCalendarPast.getBenefittedVolEnd()).thenReturn(pastDateEnd);
        // phase 4
        Mockito.when(harvestCalendarPast.getApprovedVolStart()).thenReturn(pastDateStart);
        Mockito.when(harvestCalendarPast.getApprovedVolEnd()).thenReturn(pastDateEnd);
        // Phase 5
        Mockito.when(harvestCalendarPast.getFirstCommldVolStart()).thenReturn(pastDateStart);
        Mockito.when(harvestCalendarPast.getFirstCommldVolEnd()).thenReturn(pastDateEnd);
        Mockito.when(harvestCalendarPast.getSecondCommldVolStart()).thenReturn(pastDateStart);
        Mockito.when(harvestCalendarPast.getSecondCommldVolEnd()).thenReturn(pastDateEnd);
        Mockito.when(harvestCalendarPast.getThirdCommldVolStart()).thenReturn(pastDateStart);
        Mockito.when(harvestCalendarPast.getThirdCommldVolEnd()).thenReturn(pastDateEnd);
        // phase 6
        Mockito.when(harvestCalendarPast.getNextHarvestVolStart()).thenReturn(pastDateStart);
        Mockito.when(harvestCalendarPast.getNextHarvestVolEnd()).thenReturn(pastDateEnd);

    }

    private void initializeDates() {
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.MONTH, -6);
        pastDateStart = calendar.getTime();
        calendar.add(Calendar.MONTH, 1);
        pastDateEnd = calendar.getTime();

        calendar = Calendar.getInstance();
        calendar.add(Calendar.MONTH,-1);
        currentDateStart = calendar.getTime();
        calendar.add(Calendar.MONTH, 2);
        currentDateEnd = calendar.getTime();

        calendar = Calendar.getInstance();
        calendar.add(Calendar.MONTH, 6);
        futureDateStart = calendar.getTime();
        calendar.add(Calendar.MONTH,1);
        futureDateEnd = calendar.getTime();
    }
    private VolumeReportDetail initializeDetail() {
        Harvest harvest = Mockito.mock(Harvest.class);
        Obtainer obtainer = Mockito.mock(Obtainer.class);
        Customer customer = Mockito.mock(Customer.class);
        Cultivar cultivar = Mockito.mock(Cultivar.class);
        Mockito.when(cultivar.getChargeGermoplasm()).thenReturn(true);
        Mockito.when(cultivar.getChargeTechnology()).thenReturn(true);
        ItsClass itsClass = Mockito.mock(ItsClass.class);


        VolumeReportHeader header = new VolumeReportHeader(harvest,customer,customer,obtainer);
        VolumeReportDetail detail = new VolumeReportDetail(cultivar, itsClass, header);
        header.addVolumeReportDetail(detail);
        header.setObtainerCooperative(true);
        return detail;
    }

    @Test
    public void given_detail_in_phase2_when_status_is_saveable_and_is_available_then_reported_should_be_true() {
        initializeDates();
        createMockedHarvestCalendarCurrent();
        VolumeReportDetail detail = initializeDetail();
        detail.getVolumeReportHeader().setHarvestCalendar(harvestCalendarCurrent);
        detail.getEnteredArea().setValue(BigDecimal.TEN);
        detail.getEnteredArea().setStatus(VolumeReportStatus.APPROVED);
        detail.getMatrixSeedUsed().setValue(BigDecimal.TEN);
        detail.getOwnSeedUsed().setValue(BigDecimal.TEN);
        Assert.assertTrue(detail.isReported(new Date(), VolumeReportFieldEnum.PORTIONING));
    }

    @Test
    public void given_detail_in_phase2_when_status_is_saveable_and_is_not_available_then_reported_should_be_false() {
        initializeDates();
        createMockedHarvestCalendarInPast();
        VolumeReportDetail detail = initializeDetail();
        detail.getVolumeReportHeader().setHarvestCalendar(harvestCalendarPast);
        detail.getEnteredArea().setValue(BigDecimal.TEN);
        detail.getEnteredArea().setStatus(VolumeReportStatus.APPROVED);
        detail.getMatrixSeedUsed().setValue(BigDecimal.TEN);
        detail.getOwnSeedUsed().setValue(BigDecimal.TEN);
        Assert.assertFalse(detail.isReported(new Date(), VolumeReportFieldEnum.PORTIONING));
    }

    @Test
    public void given_detail_in_phase2_when_status_is_not_saveable_and_is_available_then_reported_should_be_true() {
        initializeDates();
        createMockedHarvestCalendarCurrent();
        VolumeReportDetail detail = initializeDetail();
        detail.getVolumeReportHeader().setHarvestCalendar(harvestCalendarCurrent);
        detail.getEnteredArea().setValue(BigDecimal.TEN);
        detail.getEnteredArea().setStatus(VolumeReportStatus.APPROVED);
        detail.getMatrixSeedUsed().setValue(BigDecimal.TEN);
        detail.getOwnSeedUsed().setValue(BigDecimal.TEN);
        detail.setNotUseDiscardPortioning(true);
        detail.getPortioning().setStatus(VolumeReportStatus.APPROVED);
        Assert.assertTrue(detail.isReported(new Date(), VolumeReportFieldEnum.PORTIONING));
    }
    
    @Test
    public void given_detail_in_phase2_when_status_is_not_saveable_and_is_not_available_then_reported_should_be_true() {
        initializeDates();
        createMockedHarvestCalendarInPast();
        VolumeReportDetail detail = initializeDetail();
        detail.getVolumeReportHeader().setHarvestCalendar(harvestCalendarPast);
        detail.getEnteredArea().setValue(BigDecimal.TEN);
        detail.getEnteredArea().setStatus(VolumeReportStatus.APPROVED);
        detail.getMatrixSeedUsed().setValue(BigDecimal.TEN);
        detail.getOwnSeedUsed().setValue(BigDecimal.TEN);
        detail.setNotUseDiscardPortioning(true);
        detail.getPortioning().setStatus(VolumeReportStatus.APPROVED);
        Assert.assertTrue(detail.isReported(new Date(), VolumeReportFieldEnum.PORTIONING));
    }
    
    @Test
    public void given_detail_useDiscardPortioning_without_discards_when_getTotalDiscardPortioningEmptyNull_should_return_null() {
        VolumeReportDetail detail = initializeDetail();
    	detail.setNotUseDiscardPortioning(false);
    	
    	Assert.assertNull("total should be null", detail.getTotalDiscardPortioningEmptyNull());
    }
    
    @Test
    public void given_detail_notUseDiscardPortioning_when_getTotalDiscardPortioningEmptyNull_should_return_ZERO() {
        VolumeReportDetail detail = initializeDetail();
    	detail.setNotUseDiscardPortioning(true);
    	
    	Assert.assertEquals("total should be zero", BigDecimal.ZERO, detail.getTotalDiscardPortioningEmptyNull());
    }

}
