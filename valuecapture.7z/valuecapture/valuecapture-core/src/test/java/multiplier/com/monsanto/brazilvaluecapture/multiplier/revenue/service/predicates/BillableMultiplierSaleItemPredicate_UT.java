package com.monsanto.brazilvaluecapture.multiplier.revenue.service.predicates;

import com.monsanto.brazilvaluecapture.multiplier.cultivar.model.bean.Cultivar;
import com.monsanto.brazilvaluecapture.seedsale.billing.model.bean.BillingCalendar;
import com.monsanto.brazilvaluecapture.seedsale.product.model.bean.Product;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.SaleItem;
import com.monsanto.brazilvaluecapture.seedsale.template.model.bean.SaleTemplate;
import junit.framework.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

import java.util.ArrayList;

import static org.mockito.Mockito.when;

public class BillableMultiplierSaleItemPredicate_UT {

    private SaleItem saleItem;
    private BillingCalendar billingCalendar;
    private BillableMultiplierSaleItemPredicate billableMultiplierSaleItemPredicate;

    @Before
    public void setUp() {
        SaleTemplate saleTemplateForBilling = Mockito.mock(SaleTemplate.class);
        when(saleTemplateForBilling.getId()).thenReturn(4L);

        billingCalendar = Mockito.mock(BillingCalendar.class);
        when(billingCalendar.getSaleTemplate()).thenReturn(saleTemplateForBilling);

        ArrayList<BillingCalendar> billingCalendars = new ArrayList<BillingCalendar>();
        billingCalendars.add(billingCalendar);

        billableMultiplierSaleItemPredicate = new BillableMultiplierSaleItemPredicate(billingCalendars);
    }

    @Test
    public void evaluateTrueTest() {

        SaleTemplate saleTemplate = Mockito.mock(SaleTemplate.class);
        when(saleTemplate.getId()).thenReturn(4L);

        saleItem = Mockito.mock(SaleItem.class);
        when(saleItem.getSaleTemplate()).thenReturn(saleTemplate);
        Product product = Mockito.mock(Product.class);
        Cultivar cultivar = Mockito.mock(Cultivar.class);
        when(cultivar.getChargeTechnologyPhaseFive()).thenReturn(Boolean.TRUE);
        when(product.getCultivar()).thenReturn(cultivar);
        when(saleItem.getProduct()).thenReturn(product);

        boolean value = billableMultiplierSaleItemPredicate.evaluate(saleItem);
        Assert.assertTrue(value);
    }

    @Test
    public void evaluateFalseDifferentSaleTemplatesTest() {

        SaleTemplate saleTemplate = Mockito.mock(SaleTemplate.class);
        when(saleTemplate.getId()).thenReturn(5L);

        saleItem = Mockito.mock(SaleItem.class);
        when(saleItem.getSaleTemplate()).thenReturn(saleTemplate);

        boolean value = billableMultiplierSaleItemPredicate.evaluate(saleItem);
        Assert.assertFalse(value);
    }

    @Test
    public void evaluateFalseTest() {

        SaleTemplate saleTemplate = Mockito.mock(SaleTemplate.class);
        when(saleTemplate.getId()).thenReturn(4L);

        saleItem = Mockito.mock(SaleItem.class);
        when(saleItem.getSaleTemplate()).thenReturn(saleTemplate);
        Product product = Mockito.mock(Product.class);
        Cultivar cultivar = Mockito.mock(Cultivar.class);
        when(cultivar.getChargeTechnologyPhaseFive()).thenReturn(Boolean.FALSE);
        when(product.getCultivar()).thenReturn(cultivar);
        when(saleItem.getProduct()).thenReturn(product);

        boolean value = billableMultiplierSaleItemPredicate.evaluate(saleItem);
        Assert.assertFalse(value);
    }
}
