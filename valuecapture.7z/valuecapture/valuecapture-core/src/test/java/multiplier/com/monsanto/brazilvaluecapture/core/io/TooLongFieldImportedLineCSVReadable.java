package com.monsanto.brazilvaluecapture.core.io;

import com.monsanto.brazilvaluecapture.core.foundation.util.csv.CSVColumn;
import com.monsanto.brazilvaluecapture.core.foundation.util.csv.CSVColumnPosition;
import com.monsanto.brazilvaluecapture.core.foundation.util.csv.CSVConverterEnum;
import com.monsanto.brazilvaluecapture.core.foundation.util.csv.CSVHeader;
import com.monsanto.brazilvaluecapture.core.io.ImportedLineCSVReadable;

/**
 * Created by IntelliJ IDEA.
 * User: CGLLLO
 * Date: 12/12/13
 * Time: 16:07
 */
@CSVHeader(columns={
    @CSVColumnPosition(headerName="headerString", position="0"),
    @CSVColumnPosition(headerName="headerLong", position="1")
})
public class TooLongFieldImportedLineCSVReadable extends ImportedLineCSVReadable {

    @CSVColumn(headerName="headerString", maxLength=1)
    private String someString;

    @CSVColumn(headerName="headerLong", converter=CSVConverterEnum.LONG)
    private long someLong;

    public String getSomeString() {
        return someString;
    }

    public void setSomeString(String someString) {
        this.someString = someString;
    }

    public long getSomeLong() {
        return someLong;
    }

    public void setSomeLong(long someLong) {
        this.someLong = someLong;
    }
}