package com.monsanto.brazilvaluecapture.multiplier.cultivar;

import java.math.BigInteger;
import java.util.List;

import junit.framework.Assert;

import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.monsanto.brazilvaluecapture.core.base.SystemTestFixture;
import com.monsanto.brazilvaluecapture.core.base.model.bean.State;
import com.monsanto.brazilvaluecapture.core.base.service.ConstraintException;
import com.monsanto.brazilvaluecapture.core.foundation.model.bean.StatusEnum;
import com.monsanto.brazilvaluecapture.core.foundation.test.AbstractServiceIntegrationTests;
import com.monsanto.brazilvaluecapture.core.foundation.test.dbunit.DbUnitHelper;
import com.monsanto.brazilvaluecapture.core.foundation.util.ConstraintViolation;
import com.monsanto.brazilvaluecapture.multiplier.cultivar.model.bean.Cultivar;
import com.monsanto.brazilvaluecapture.multiplier.cultivar.model.dao.CultivarFilter;
import com.monsanto.brazilvaluecapture.multiplier.cultivar.service.CultivarService;
import com.monsanto.brazilvaluecapture.multiplier.hectareproductivity.model.bean.HectareProductivity;
import com.monsanto.brazilvaluecapture.multiplier.obtainer.ObtainerTestData;
import com.monsanto.brazilvaluecapture.multiplier.obtainer.model.bean.Obtainer;
import com.monsanto.brazilvaluecapture.seedsale.harvest.model.bean.Harvest;

public class CultivarService_AT extends AbstractServiceIntegrationTests {

    public static final Long HARVEST1 = 900000001L;
	public static final Long STATE1 = 900000001L;
	public static final Long CULTIVAR1 = 900000001L;
	
	@Autowired
	private CultivarService cultivarService;
	
	private Obtainer obtainer;

	private Cultivar cultivar;
	
	@Before
	public void setup() {
		systemTestFixture = new SystemTestFixture(this);
		
		obtainer = ObtainerTestData.createActiveObtainer("Obtainer Test", systemTestFixture.soy);
		saveAndFlush(obtainer);
		
		cultivar = new Cultivar("Cultivar Test", Boolean.TRUE, Boolean.TRUE, StatusEnum.ACTIVE, systemTestFixture.soy,
				obtainer, systemTestFixture.intacta, Boolean.FALSE);
		saveAndFlush(cultivar);

    }	
	
	@Test
	public void test_labels_from_boolean_fields() {
		Assert.assertEquals("label.yes", cultivar.getChargeGermoplasmLabel());
		Assert.assertEquals("label.yes", cultivar.getChargeTechnologyLabel());
		Assert.assertEquals("label.no", cultivar.getObtainerOnlyLabel());
		
		cultivar.setChargeGermoplasm(Boolean.FALSE);
		cultivar.setChargeTechnology(Boolean.FALSE);
		cultivar.setObtainerOnly(Boolean.TRUE);
		Assert.assertEquals("label.no", cultivar.getChargeGermoplasmLabel());
		Assert.assertEquals("label.no", cultivar.getChargeTechnologyLabel());
		Assert.assertEquals("label.yes", cultivar.getObtainerOnlyLabel());
	}
	
	@Test
	public void given_a_cultivar_with_empty_description_should_throw_exception() {
		cultivar.setDescription("");
		try {
			cultivarService.save(cultivar);
			Assert.fail();
		} catch (ConstraintException e) {
			ConstraintViolation violation = e.getViolations().get(0);
			Assert.assertEquals("Description is required", violation.getMessage());
		}
	}
	
	@Test
	public void given_a_cultivar_without_description_should_throw_exception() {
		cultivar.setDescription(null);
		try {
			cultivarService.save(cultivar);
			Assert.fail();
		} catch (ConstraintException e) {
			ConstraintViolation violation = e.getViolations().get(0);
			Assert.assertEquals("Description is required", violation.getMessage());
		}
	}
	
	@Test
	public void given_a_cultivar_without_crop_should_throw_exception() {
		cultivar.setCrop(null);
		try {
			cultivarService.save(cultivar);
			Assert.fail();
		} catch (ConstraintException e) {
			ConstraintViolation violation = e.getViolations().get(0);
			Assert.assertEquals("Crop is required", violation.getMessage());
		}
	}
	
	@Test
	public void given_a_cultivar_without_obtainer_should_throw_exception() {
		cultivar.setObtainer(null);
		try {
			cultivarService.save(cultivar);
			Assert.fail();
		} catch (ConstraintException e) {
			ConstraintViolation violation = e.getViolations().get(0);
			Assert.assertEquals("Obtainer is required", violation.getMessage());
		}
	}
	
	@Test
	public void given_a_cultivar_charge_technology_without_technology_code_should_throw_exception() {
		cultivar.setTechnology(null);
		try {
			cultivarService.save(cultivar);
			Assert.fail();
		} catch (ConstraintException e) {
			ConstraintViolation violation = e.getViolations().get(0);
			Assert.assertEquals("Technology is required", violation.getMessage());
		}
	}
	
	@Test
	public void given_a_cultivar_with_existing_crop_obtainer_description_should_throw_exception() {
		Cultivar anotherCultivar = new Cultivar("Cultivar Test", Boolean.FALSE, Boolean.FALSE, StatusEnum.ACTIVE, systemTestFixture.soy,
				obtainer, null, Boolean.FALSE);
		try {
			cultivarService.save(anotherCultivar);
			Assert.fail();
		} catch (ConstraintException e) {
			ConstraintViolation violation = e.getViolations().get(0);
			Assert.assertEquals("Cultivar already exist", violation.getMessage());
		}
	}
	
	@SuppressWarnings("unchecked")
	@Test
	public void given_a_edited_cultivar_with_all_required_values_should_save_successfully() throws ConstraintException {
		Cultivar editedCultivar = cultivarService.selectById(cultivar.getPrimaryKey());
		editedCultivar.setChargeGermoplasm(Boolean.FALSE);
		editedCultivar.setChargeTechnology(Boolean.FALSE);
		editedCultivar.setTechnology(null);
		editedCultivar.setStatus(StatusEnum.INACTIVE);
		editedCultivar.setObtainerOnly(Boolean.TRUE);
		cultivarService.save(editedCultivar);
		
		List<Cultivar> cultivarList = (List<Cultivar>) getSession().createCriteria(Cultivar.class).list();
		Assert.assertTrue("Cultivar List should contains saved Cultivar", cultivarList.contains(editedCultivar));
	}
	
	@SuppressWarnings("unchecked")
	@Test
	public void given_a_cultivar_should_delete_successfully() throws ConstraintException {
		Cultivar deletedCultivar = cultivarService.selectById(cultivar.getPrimaryKey());
		cultivarService.delete(deletedCultivar);
		
		List<Cultivar> cultivarList = (List<Cultivar>) getSession().createCriteria(Cultivar.class).list();
		Assert.assertFalse("Class should not contains deleted Class", cultivarList.contains(deletedCultivar));
	}
	
	@Test
	public void when_search_cultivar_by_filter_should_return_only_cultivar_with_filtered_values() {
		Cultivar anotherCultivar = new Cultivar("Another Cultivar", Boolean.TRUE, Boolean.TRUE, StatusEnum.INACTIVE, systemTestFixture.soy,
				obtainer, systemTestFixture.intacta, Boolean.FALSE);
		saveAndFlush(anotherCultivar);
		
		Cultivar cultivarSearch = new Cultivar();
		cultivarSearch.setDescription("  ther C ");
		cultivarSearch.setCrop(systemTestFixture.soy);
		cultivarSearch.setObtainer(obtainer);
		cultivarSearch.setStatus(StatusEnum.INACTIVE);
		
		CultivarFilter filter = CultivarFilter.getInstance();
		filter.add(cultivarSearch).addObtainerStatus(StatusEnum.ACTIVE);
		
		List<Cultivar> cultivarList = cultivarService.selectByFilter(filter);
		
		Assert.assertEquals(1, cultivarList.size());
		Assert.assertTrue(cultivarList.contains(anotherCultivar));
		Assert.assertFalse(cultivarList.contains(cultivar));
	}
	
	@Test
	public void when_search_cultivar_order_by_description_should_return_all_cultivars_ordened() {
		Cultivar anotherCultivar = new Cultivar("Another Cultivar", Boolean.TRUE, Boolean.TRUE, StatusEnum.INACTIVE, systemTestFixture.soy,
				obtainer, systemTestFixture.intacta, Boolean.FALSE);
		saveAndFlush(anotherCultivar);
		
		CultivarFilter filter = CultivarFilter.getInstance();
		
		List<Cultivar> cultivarList = cultivarService.selectOrderByDescription(filter);
		
		Assert.assertEquals(2, cultivarList.size());
		Assert.assertEquals(cultivarList.get(0), anotherCultivar);
		Assert.assertTrue(cultivarList.contains(anotherCultivar));
		Assert.assertTrue(cultivarList.contains(cultivar));
	}
	
	@Test
	public void when_search_cultivar_without_filter_should_return_all_classes() {
		Cultivar anotherCultivar = new Cultivar("Another Cultivar", Boolean.TRUE, Boolean.TRUE, StatusEnum.INACTIVE, systemTestFixture.soy,
				obtainer, systemTestFixture.intacta, Boolean.FALSE);
		saveAndFlush(anotherCultivar);
		
		CultivarFilter filter = CultivarFilter.getInstance();
		filter.addDescription(null).addCrop(null).addObtainer(null).addStatus(null);
		
		List<Cultivar> itsClasseList = cultivarService.selectByFilter(filter);
		
		Assert.assertEquals(2, itsClasseList.size());
		Assert.assertTrue(itsClasseList.contains(anotherCultivar));
		Assert.assertTrue(itsClasseList.contains(cultivar));
	}

	@Test
	public void given_a_cultivar_with_hectare_productivity_should_throw_exception() {
		
        DbUnitHelper.setup(
        "classpath:data/multiplier/basic-fixture.xml",
        "classpath:data/multiplier/cultivar_dataset.xml");
	
		Harvest harvest1 = getHarvest(HARVEST1);
		State state1 = getState(STATE1);
		Cultivar cultivar1 = getCultivar(CULTIVAR1);
		
		persistHectareProductivity(harvest1, state1, cultivar1, BigInteger.valueOf(15L));
	
		try {
			cultivarService.delete(cultivar1);
			Assert.fail();
		} catch (ConstraintException e) {
			ConstraintViolation violation = e.getViolations().get(0);
			Assert.assertEquals("Cultivar with hectare productivity", violation.getMessage());
		}
	}
	
    private Cultivar getCultivar(Long id) {
        return (Cultivar) getSession().get(Cultivar.class, id);
    }

    private Harvest getHarvest(Long id) {
        return (Harvest) getSession().get(Harvest.class, id);
    }

    private State getState(Long id) {
        return (State) getSession().get(State.class, id);
    }
	
    private HectareProductivity persistHectareProductivity(Harvest harvest, State state, Cultivar cultivar, BigInteger productivity) {
        HectareProductivity hectareProductivity = new HectareProductivity(harvest, state, cultivar);
        hectareProductivity.setProductivity(productivity);
        saveAndFlush(hectareProductivity);
        return hectareProductivity;
    }
	
}
