package com.monsanto.brazilvaluecapture.multiplier.revenue.service.impl;

import com.monsanto.brazilvaluecapture.core.foundation.service.BusinessException;
import com.monsanto.brazilvaluecapture.multiplier.revenue.service.PostRevenueRecognition;
import com.monsanto.brazilvaluecapture.multiplier.revenue.service.PostRevenueRecognitionAdjuster;
import com.monsanto.brazilvaluecapture.multiplier.revenue.service.PostValueShare;
import com.monsanto.brazilvaluecapture.osb.its.api.InfraException;
import com.monsanto.brazilvaluecapture.seedsale.revenue.service.PostMultiplierToGrowerSalesRecognizer;
import com.monsanto.brazilvaluecapture.seedsale.sale.service.SaleLinkDetailLinker;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import static org.mockito.Mockito.verify;

@RunWith(MockitoJUnitRunner.class)
public class ControllershipJobImpl_UT {

    @Mock
    private SaleLinkDetailLinker saleLinkDetailLinker;

    @Mock
    private PostRevenueRecognitionAdjuster postRevenueRecognitionAdjuster;

    @Mock
    private PostMultiplierToGrowerSalesRecognizer postMultiplierToGrowerSalesRecognizer;

    @Mock
    private PostRevenueRecognition postRevenueRecognition;

    @Mock
    private PostValueShare postValueShare;

    private ControllershipJobImpl controllershipJob;

    @Before
    public void setUp() {
        controllershipJob = new ControllershipJobImpl(saleLinkDetailLinker,
                postRevenueRecognitionAdjuster, postMultiplierToGrowerSalesRecognizer,
                postRevenueRecognition, postValueShare);
    }

    @Test
    public void testExecute_whenNoStepFails_thenAllTheStepsMustBeExecuted() throws InfraException, BusinessException {
        //@When
        controllershipJob.execute();
        //@Then
        verify(saleLinkDetailLinker).linkSalesFromLastMonth();
        verify(postRevenueRecognitionAdjuster).payMultiplierBankSlip();
        verify(postMultiplierToGrowerSalesRecognizer).recognizeRevenueFromSales();
        verify(postRevenueRecognition).postRevenueRecognition();
        verify(postValueShare).calculateAndPostValueShare();
    }

}