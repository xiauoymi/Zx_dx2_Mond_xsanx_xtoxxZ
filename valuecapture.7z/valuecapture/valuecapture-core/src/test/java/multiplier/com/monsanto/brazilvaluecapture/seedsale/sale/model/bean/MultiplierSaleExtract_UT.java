package com.monsanto.brazilvaluecapture.seedsale.sale.model.bean;

import com.monsanto.brazilvaluecapture.core.customer.model.bean.Customer;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Technology;
import com.monsanto.brazilvaluecapture.seedsale.billing.model.bean.Billing;
import com.monsanto.brazilvaluecapture.seedsale.billing.model.bean.PaymentStatus;
import com.monsanto.brazilvaluecapture.seedsale.billing.model.bean.PossiblePayment;
import com.monsanto.brazilvaluecapture.seedsale.billing.model.bean.Royalty;
import com.monsanto.brazilvaluecapture.seedsale.product.model.bean.Region;
import org.junit.Test;

import java.math.BigDecimal;
import java.util.*;

import static junit.framework.Assert.*;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertSame;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

/**
 * Created with IntelliJ IDEA.
 * User: IFERN1
 * Date: 10/9/13
 * Time: 3:16 PM
 * To change this template use File | Settings | File Templates.
 */
public class MultiplierSaleExtract_UT {
    @Test
    public void test_SaleExtract_detail_creation() {
        //@Given
        Sale sale = mock(Sale.class);
        //Royalties
        Set<Royalty> royalties = new HashSet<Royalty>();
        Royalty royalty = mock(Royalty.class);
        Technology technology = mock(Technology.class);
        when(royalty.getTechnology()).thenReturn(technology);
        royalties.add(royalty);

        //Payments
        PossiblePayment possiblePayment = mock(PossiblePayment.class);
        when(possiblePayment.getReceiptValue()).thenReturn(BigDecimal.TEN);
        when(possiblePayment.getPaidValue()).thenReturn(BigDecimal.TEN);
        Date paymentDate = new Date();
        when(possiblePayment.getPaymentDate()).thenReturn(paymentDate);
        Set<PossiblePayment> payments = new HashSet<PossiblePayment>();
        payments.add(possiblePayment);

        //Billings
        Billing billing = mock(Billing.class);
        when(billing.getPayments()).thenReturn(payments);
        when(billing.getPossiblePaymentPaid()).thenReturn(possiblePayment);
        when(billing.getRoyalties()).thenReturn(royalties);
        when(royalty.getBilling()).thenReturn(billing);
        when(billing.getTechnology()).thenReturn(technology);
        PaymentStatus paymentStatus = PaymentStatus.FULLY_PAID;
        when(billing.getPaymentStatus()).thenReturn(paymentStatus);
        Date dueDate = new Date();
        when(billing.getDueDate()).thenReturn(dueDate);
        List<Billing> billings = new ArrayList<Billing>();
        billings.add(billing);

        //@When
        MultiplierSaleExtract multiplierSaleExtract = new MultiplierSaleExtract(sale, billings);

        //@Then
        assertFalse(multiplierSaleExtract.getSaleExtractDetails().isEmpty());
        MultiplierSaleExtractDetail multiplierSaleExtractDetail = multiplierSaleExtract.getSaleExtractDetails().get(0);
        assertNotNull(multiplierSaleExtractDetail);
        assertTrue(BigDecimal.TEN.equals(multiplierSaleExtractDetail.getRoyaltyCost()));
        assertTrue(BigDecimal.TEN.equals(multiplierSaleExtractDetail.getRoyaltyPaid()));
        assertTrue(BigDecimal.TEN.equals(multiplierSaleExtractDetail.getPaymentValue()));
        assertTrue(BigDecimal.TEN.equals(multiplierSaleExtractDetail.getPaidValue()));
        assertEquals(paymentDate, multiplierSaleExtractDetail.getPaymentDate());
        assertEquals(dueDate, multiplierSaleExtractDetail.getDueDate());
        assertEquals(paymentStatus.getValue(), multiplierSaleExtractDetail.getPaymentStatus());
        assertEquals(technology, multiplierSaleExtractDetail.getTechnology());
    }

    @Test
    public void test_SaleExtract_detail_creation_NoPaymentData() {
        //@Given
        Sale sale = mock(Sale.class);
        //Royalties
        Set<Royalty> royalties = new HashSet<Royalty>();
        Royalty royalty = mock(Royalty.class);
        Technology technology = mock(Technology.class);
        when(royalty.getTechnology()).thenReturn(technology);
        royalties.add(royalty);

        //Payments
        PossiblePayment possiblePayment = mock(PossiblePayment.class);
        when(possiblePayment.getReceiptValue()).thenReturn(BigDecimal.TEN);
        when(possiblePayment.getPaidValue()).thenReturn(null);
        Date paymentDate = null;
        when(possiblePayment.getPaymentDate()).thenReturn(paymentDate);
        Set<PossiblePayment> payments = new HashSet<PossiblePayment>();
        payments.add(possiblePayment);

        //Billings
        Billing billing = mock(Billing.class);
        when(billing.getPayments()).thenReturn(payments);
        when(billing.getPossiblePaymentPaid()).thenReturn(null);
        when(billing.getRoyalties()).thenReturn(royalties);
        when(royalty.getBilling()).thenReturn(billing);
        when(billing.getTechnology()).thenReturn(technology);
        PaymentStatus paymentStatus = PaymentStatus.FULLY_PAID;
        when(billing.getPaymentStatus()).thenReturn(paymentStatus);
        Date dueDate = new Date();
        when(billing.getDueDate()).thenReturn(dueDate);
        List<Billing> billings = new ArrayList<Billing>();
        billings.add(billing);

        //@When
        MultiplierSaleExtract multiplierSaleExtract = new MultiplierSaleExtract(sale, billings);

        //@Then
        assertFalse(multiplierSaleExtract.getSaleExtractDetails().isEmpty());
        MultiplierSaleExtractDetail multiplierSaleExtractDetail = multiplierSaleExtract.getSaleExtractDetails().get(0);
        assertNotNull(multiplierSaleExtractDetail);
        assertTrue(BigDecimal.ZERO.equals(multiplierSaleExtractDetail.getRoyaltyCost()));
        assertTrue(BigDecimal.ZERO.equals(multiplierSaleExtractDetail.getRoyaltyPaid()));
        assertTrue(BigDecimal.TEN.equals(multiplierSaleExtractDetail.getPaymentValue()));
        assertTrue(BigDecimal.ZERO.equals(multiplierSaleExtractDetail.getPaidValue()));
        assertEquals(paymentDate, multiplierSaleExtractDetail.getPaymentDate());
        assertEquals(dueDate, multiplierSaleExtractDetail.getDueDate());
        assertEquals(paymentStatus.getValue(), multiplierSaleExtractDetail.getPaymentStatus());
        assertEquals(technology, multiplierSaleExtractDetail.getTechnology());
    }

    @Test
    public void test_invoiceDate_property() {
        //@Given
        Sale sale = mock(Sale.class);
        Date invoiceDate = new Date();
        when(sale.getInvoiceDate()).thenReturn(invoiceDate);
        List<Billing> billings = new ArrayList<Billing>();

        //@When
        MultiplierSaleExtract multiplierSaleExtract = new MultiplierSaleExtract(sale, billings);

        //@Then
        assertSame(invoiceDate, multiplierSaleExtract.getInvoiceDate());
    }

    @Test
    public void test_creationDate_property() {
        //@Given
        Sale sale = mock(Sale.class);
        Date creationDate = new Date();
        when(sale.getCreationDate()).thenReturn(creationDate);
        List<Billing> billings = new ArrayList<Billing>();

        //@When
        MultiplierSaleExtract multiplierSaleExtract = new MultiplierSaleExtract(sale, billings);

        //@Then
        assertSame(creationDate, multiplierSaleExtract.getCreationDate());
    }

    @Test
    public void test_invoiceNumber_property() {
        //@Given
        Sale sale = mock(Sale.class);
        String invoiceNumber = "someInvoiceNumber";
        when(sale.getInvoiceNumber()).thenReturn(invoiceNumber);
        List<Billing> billings = new ArrayList<Billing>();

        //@When
        MultiplierSaleExtract multiplierSaleExtract = new MultiplierSaleExtract(sale, billings);

        //@Then
        assertSame(invoiceNumber, multiplierSaleExtract.getInvoiceNumber());
    }

    @Test
    public void test_multiplierName_property() {
        //@Given
        Sale sale = mock(Sale.class);
        String multiplierName = "someMultiplierName";
        Customer multiplier = mock(Customer.class);
        when(multiplier.getName()).thenReturn(multiplierName);
        when(sale.getCustomer()).thenReturn(multiplier);
        List<Billing> billings = new ArrayList<Billing>();

        //@When
        MultiplierSaleExtract multiplierSaleExtract = new MultiplierSaleExtract(sale, billings);

        //@Then
        assertSame(multiplierName, multiplierSaleExtract.getMultiplierName());
    }

    @Test
    public void test_region_property() {
        //@Given
        Sale sale = mock(Sale.class);
        String regionName = "someRegionName";
        Region region = mock(Region.class);
        when(region.getRegionDescription()).thenReturn(regionName);
        when(sale.getRegion()).thenReturn(region);
        List<Billing> billings = new ArrayList<Billing>();

        //@When
        MultiplierSaleExtract multiplierSaleExtract = new MultiplierSaleExtract(sale, billings);

        //@Then
        assertSame(regionName, multiplierSaleExtract.getRegionName());
    }
}
