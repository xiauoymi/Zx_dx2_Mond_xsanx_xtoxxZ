package com.monsanto.brazilvaluecapture.multiplier.revenue.service;

import com.monsanto.brazilvaluecapture.core.base.model.bean.Company;
import com.monsanto.brazilvaluecapture.core.base.model.bean.OperationalYear;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Customer;
import com.monsanto.brazilvaluecapture.core.foundation.service.BusinessException;
import com.monsanto.brazilvaluecapture.core.revenue.model.bean.RevenueAccount;
import com.monsanto.brazilvaluecapture.core.revenue.model.bean.RevenueType;
import com.monsanto.brazilvaluecapture.multiplier.volumereport.service.VolumeReportRevenueService;
import org.junit.Test;

import java.util.Date;

import static org.fest.assertions.Assertions.assertThat;
import static org.fest.assertions.Fail.fail;
import static org.mockito.Matchers.anyCollection;
import static org.mockito.Matchers.anyLong;
import static org.mockito.Mockito.*;

public class MultiplierBillableProvider_UT {

    private VolumeReportRevenueService volumeReportRevenueService = mock(VolumeReportRevenueService.class);

    @Test
    public void testBillCallBackInvokesVolumeReportService_WhenRevenueAccountTypeIsMultiplier() throws BusinessException {
        MultiplierBillableProvider multiplierBillableProvider = new MultiplierBillableProvider(volumeReportRevenueService);
        RevenueAccount revenueAccount = new RevenueAccount(new Customer(), "contractNumber", new OperationalYear("2014"),
                RevenueType.MULTIPLIER, new Company("company"), new Date(), new Date());

        multiplierBillableProvider.billCallBack(revenueAccount);

        verify(volumeReportRevenueService).updateMultiplyReportDetailsToBilled(anyCollection(), anyLong());
    }

    @Test
    public void testBillCallBackWontInvokeVolumeReportService_WhenRevenueAccountTypeIsNotMultiplier() throws BusinessException {
        MultiplierBillableProvider multiplierBillableProvider = new MultiplierBillableProvider(volumeReportRevenueService);
        RevenueAccount revenueAccount = new RevenueAccount(new Customer(), "contractNumber", new OperationalYear("2014"),
                RevenueType.DISTRIBUTION, new Company("company"), new Date(), new Date());

        multiplierBillableProvider.billCallBack(revenueAccount);

        verifyNoMoreInteractions(volumeReportRevenueService);
    }

    @Test
    public void testPayThrowsBusinessException_WhenRevenueAccountHasTypeDifferentFromMultiplier() {
        MultiplierBillableProvider multiplierBillableProvider = new MultiplierBillableProvider(volumeReportRevenueService);
        RevenueAccount revenueAccount = new RevenueAccount(new Customer(), "contractNumber", new OperationalYear("2014"),
                RevenueType.DISTRIBUTION, new Company("company"), new Date(), new Date());

        try {
            multiplierBillableProvider.pay(revenueAccount);
        } catch (BusinessException e) {
            assertThat(e).hasNoCause().hasMessage("Revenue account is different from type MULTIPLIER.");
        }
    }

    @Test
    public void testPayDontThrowsBusinessException_WhenRevenueAccountHasTypeMultiplier() {
        MultiplierBillableProvider multiplierBillableProvider = new MultiplierBillableProvider(volumeReportRevenueService);
        RevenueAccount revenueAccount = new RevenueAccount(new Customer(), "contractNumber", new OperationalYear("2014"),
                RevenueType.MULTIPLIER, new Company("company"), new Date(), new Date());

        try {
            multiplierBillableProvider.pay(revenueAccount);
        } catch (BusinessException e) {
            fail("Should not throw BusinessException");
        }
    }
}