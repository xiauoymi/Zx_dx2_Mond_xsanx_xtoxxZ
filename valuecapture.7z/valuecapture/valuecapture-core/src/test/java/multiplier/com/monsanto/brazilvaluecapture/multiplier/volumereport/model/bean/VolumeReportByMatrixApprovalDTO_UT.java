package com.monsanto.brazilvaluecapture.multiplier.volumereport.model.bean;

import junit.framework.Assert;
import org.junit.Test;

public class VolumeReportByMatrixApprovalDTO_UT {

    @Test
    public void given_basic_functionality_should_work_as_expected_for_sanity_test() {
        VolumeReportByMatrixApprovalDTO dto = new VolumeReportByMatrixApprovalDTO("12345", "123444", "BOB");
        dto.addApprovalDTO(new VolumeReportApprovalDTO(1L, 1L, null, VolumeReportStatus.WAITING_REPORT, VolumeReportStatus.WAITING_REPORT, VolumeReportStatus.WAITING_REPORT, VolumeReportStatus.WAITING_REPORT,
                VolumeReportStatus.WAITING_REPORT, VolumeReportStatus.WAITING_REPORT, VolumeReportStatus.WAITING_REPORT, VolumeReportStatus.WAITING_REPORT, VolumeReportStatus.WAITING_REPORT,
                VolumeReportStatus.WAITING_REPORT, "WOB", "54321", "001", "99999", "NOB", "32342", "002", "99999", "harv", "obt", "cult", "class", false, true, null, 1l, true));
        Assert.assertEquals(dto.getDocument(),"123444");
        Assert.assertEquals(dto.getSapCode(),"12345");
        Assert.assertEquals(dto.getName(),"BOB");
        Assert.assertEquals(1,dto.getApprovalDTOs().size());
    }
}
