package com.monsanto.brazilvaluecapture.multiplier.revenue.service.impl;

import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import com.monsanto.brazilvaluecapture.core.foundation.service.BusinessException;
import com.monsanto.brazilvaluecapture.core.posting.model.bean.ReferenceNameEnum;
import com.monsanto.brazilvaluecapture.core.posting.service.PostingService;
import com.monsanto.brazilvaluecapture.multiplier.revenue.service.RevenueRecognitionCalculator;
import com.monsanto.brazilvaluecapture.multiplier.seedsale.model.dao.SaleLinkDetailDAO;
import com.monsanto.brazilvaluecapture.seedsale.billing.model.bean.PaymentStatus;
import com.monsanto.brazilvaluecapture.seedsale.posting.osb.OsbBonusPostingService;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.Sale;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.SaleItem;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.SaleLinkDetail;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.SaleLinkDetailValue;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.dao.MultiplierSaleDAO;
import com.monsanto.brazilvaluecapture.utils.DateRange;
import com.monsanto.brazilvaluecapture.utils.DateUtils;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.runners.MockitoJUnitRunner;

import java.math.BigDecimal;
import java.util.Collection;
import java.util.Date;
import java.util.List;

import static junit.framework.Assert.assertNotNull;
import static org.junit.Assert.fail;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class PostRevenueRecognitionAdjusterImpl_UT {

    @Mock
    private MultiplierSaleDAO multiplierSaleDAO;
    @Mock
    private PostingService postingService;
    @Mock
    private RevenueRecognitionCalculator revenueRecognitionCalculator;
    @Mock
    private SaleLinkDetailDAO saleLinkDetailDAO;
    @Spy
    @InjectMocks
    private PostRevenueRecognitionAdjusterImpl postRevenueRecognitionAdjustImpl;

    @Test
    public void testProcessBankSlipPaymentInfo_thenOSBServiceMustBeCalled() throws Exception {
        //@Given
        SaleLinkDetail toDealer = getSaleLinkDetail(BigDecimal.valueOf(2300), BigDecimal.valueOf(1380), BigDecimal.valueOf(30));
        toDealer.getSaleLinkDetailValueSet().iterator().next().setRevenueRecognition(BigDecimal.ONE);
        List<SaleLinkDetail> toDealerList = Lists.newArrayList(toDealer);
        SaleItem toGrower = getSaleItem(BigDecimal.valueOf(500), BigDecimal.valueOf(500), BigDecimal.valueOf(30));
        Collection<SaleItem> toGrowerList = Lists.newArrayList(toGrower);
        when(revenueRecognitionCalculator.getRevenueRecognition(toDealer, DateUtils.getLastMonthDateRange())).thenReturn(BigDecimal.valueOf(1380));
        //@When
        postRevenueRecognitionAdjustImpl.processBankSlipPaymentInfo(toDealerList, toGrowerList);
        //@Then
        Date lastDateOfPreviousMonth = DateUtils.getLastMonthDateRange().getDateTo();
        verify(postingService).submitAndSaveBonusPosting(
                any(BigDecimal.class),
                eq(ReferenceNameEnum.ADJUST_CASH_GT_REVENUE_RECOGNITION), any(String.class),
                eq(lastDateOfPreviousMonth), eq(lastDateOfPreviousMonth), eq(OsbBonusPostingService.DEFAULT_TECHNOLOGY));
    }

    @Test
    public void testProcessBankSlipPaymentInfo_whenToDealerInfoIsNull_thenBusinessExceptionMustToBeThrownAndOSBServiceMustNotBeCalled() throws Exception {
        //@Given
        SaleItem toGrower = getSaleItem(BigDecimal.valueOf(500), BigDecimal.valueOf(500), BigDecimal.valueOf(30));
        Collection<SaleItem> toGrowerList = Lists.newArrayList(toGrower);
        //@When
        try {
            postRevenueRecognitionAdjustImpl.processBankSlipPaymentInfo(null, toGrowerList);
            fail();
        } catch (BusinessException e) {
            assertNotNull("Error", e.getMessage());
        }
        //@Then
        verify(postingService, never()).submitAndSaveBonusPosting(
                any(BigDecimal.class),
                any(ReferenceNameEnum.class),
                any(String.class),
                any(Date.class),
                any(Date.class),
                eq(OsbBonusPostingService.DEFAULT_TECHNOLOGY)
        );
    }

    @Test
    public void testProcessBankSlipPaymentInfo_whenToGrowerInfoIsNull_thenBusinessExceptionMustToBeThrownAndOSBServiceMustNotBeCalled() throws Exception {
        //@Given
        SaleItem toGrower = mock(SaleItem.class);
        when(toGrower.getNetRoyaltyValueQuantity()).thenReturn(new BigDecimal(1150));
        when(toGrower.getRevenueRecognition()).thenReturn(new BigDecimal(1150));
        Collection<SaleItem> toGrowerList = Lists.newArrayList(toGrower);
        //@When
        try {
            postRevenueRecognitionAdjustImpl.processBankSlipPaymentInfo(null, toGrowerList);
            fail();
        } catch (BusinessException e) {
            assertNotNull("Error", e.getMessage());
        }
        //@Then
        verify(postingService, never()).submitAndSaveBonusPosting(
                any(BigDecimal.class),
                any(ReferenceNameEnum.class),
                any(String.class),
                any(Date.class),
                any(Date.class),
                eq(OsbBonusPostingService.DEFAULT_TECHNOLOGY)
        );
    }

    @Test
    public void testProcessBankSlipPaymentInfo_whenConsumedIsGreaterThanGenerated_thenBusinessExceptionMustToBeThrownAndOSBServiceMustNotBeCalled() throws Exception {
        //@Given
        SaleLinkDetail toDealer = getSaleLinkDetail(BigDecimal.valueOf(13), BigDecimal.valueOf(2300), BigDecimal.valueOf(30));
        toDealer.getSaleLinkDetailValueSet().iterator().next().setRevenueRecognition(BigDecimal.valueOf(2300));
        List<SaleLinkDetail> toDealerList = Lists.newArrayList(toDealer);
        SaleItem toGrower = getSaleItem(BigDecimal.valueOf(500), BigDecimal.valueOf(500), BigDecimal.valueOf(30));
        Collection<SaleItem> toGrowerList = Lists.newArrayList(toGrower);
        //@When
        try {
            postRevenueRecognitionAdjustImpl.processBankSlipPaymentInfo(toDealerList, toGrowerList);
            fail();
        } catch (BusinessException e) {
            assertNotNull("Revenue recognition is greater than net royalty value", e.getMessage());
        }
    }

    @Test
    public void testProcessBankSlipPaymentInfo_whenConsumedIsEqualThanGenerated_thenOSBServiceMustNotBeCalled() throws Exception {
        //@Given
        SaleLinkDetail toDealer = getSaleLinkDetail(BigDecimal.valueOf(280), BigDecimal.valueOf(1380), BigDecimal.valueOf(30));
        toDealer.getSaleLinkDetailValueSet().iterator().next().setRevenueRecognition(BigDecimal.valueOf(30));
        List<SaleLinkDetail> toDealerList = Lists.newArrayList(toDealer);
        SaleItem toGrower = getSaleItem(BigDecimal.valueOf(250), BigDecimal.valueOf(500), BigDecimal.valueOf(30));
        Collection<SaleItem> toGrowerList = Lists.newArrayList(toGrower);
        when(revenueRecognitionCalculator.getRevenueRecognition(toDealer, DateUtils.getLastMonthDateRange())).thenReturn(BigDecimal.valueOf(1380));
        //@When
        postRevenueRecognitionAdjustImpl.processBankSlipPaymentInfo(toDealerList, toGrowerList);
        //@Then
        verifyNoMoreInteractions(postingService);
    }

    @Test
    public void testPayMultiplierBankSlipInvokesSaleLinkDetailDao() throws BusinessException {
        //@When
        postRevenueRecognitionAdjustImpl.payMultiplierBankSlip();
        //@Then
        DateRange lastMonthDateRange = DateUtils.getLastMonthDateRange();
        verify(saleLinkDetailDAO).findLinkedSalesByPaymentStatusAndPayedInPeriod(PaymentStatus.FULLY_PAID, lastMonthDateRange);
    }

    public SaleLinkDetail getSaleLinkDetail(BigDecimal netRoyaltyValueQuantity, BigDecimal revenueRecognition, BigDecimal consumed) {
        SaleLinkDetail saleLinkDetail = new SaleLinkDetail();
        Sale multiplierSale = new Sale();
        multiplierSale.setSaleType(Sale.SaleTypeEnum.MULTIPLIER_SEED_SALE);
        SaleItem multiplierSaleItem = new SaleItem();
        multiplierSaleItem.setNetRoyaltyValueQuantity(netRoyaltyValueQuantity);
        multiplierSaleItem.setSaleLinkDetail(saleLinkDetail);
        multiplierSaleItem.setHaAmount(BigDecimal.ONE);
        multiplierSaleItem.setNetQuantity(BigDecimal.valueOf(100));
        multiplierSaleItem.setSoldQuantity(100l);
        multiplierSale.addItem(multiplierSaleItem);
        saleLinkDetail.setConsumed(consumed);
        saleLinkDetail.setMultiplierSale(multiplierSale);
        saleLinkDetail.setSaleItem(multiplierSaleItem);
        Sale dealerSale = new Sale();
        dealerSale.setSaleType(Sale.SaleTypeEnum.SALE_SEED);
        SaleItem dealerSaleItem = new SaleItem();
        dealerSaleItem.setRevenueRecognition(revenueRecognition);
        SaleLinkDetailValue saleLinkDetailValue = new SaleLinkDetailValue(dealerSale, dealerSaleItem, consumed, saleLinkDetail);
        saleLinkDetail.setSaleLinkDetailValueSet(Sets.newHashSet(saleLinkDetailValue));
        return saleLinkDetail;
    }

    public SaleItem getSaleItem(BigDecimal netRoyaltyValueQuantity, BigDecimal revenueRecognition, BigDecimal consumed) {
        SaleItem saleItem = new SaleItem();
        saleItem.setNetRoyaltyValueQuantity(netRoyaltyValueQuantity);
        saleItem.setRevenueRecognition(revenueRecognition);
        SaleLinkDetail saleLinkDetail = new SaleLinkDetail();
        saleLinkDetail.setConsumed(consumed);
        saleItem.setSaleLinkDetail(saleLinkDetail);
        return saleItem;
    }

}