package com.monsanto.brazilvaluecapture.multiplier.itsclass;

import java.util.List;

import junit.framework.Assert;

import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.monsanto.brazilvaluecapture.core.base.SystemTestFixture;
import com.monsanto.brazilvaluecapture.core.base.service.ConstraintException;
import com.monsanto.brazilvaluecapture.core.foundation.model.bean.StatusEnum;
import com.monsanto.brazilvaluecapture.core.foundation.test.AbstractServiceIntegrationTests;
import com.monsanto.brazilvaluecapture.core.foundation.util.ConstraintViolation;
import com.monsanto.brazilvaluecapture.multiplier.itsclass.model.bean.ItsClass;
import com.monsanto.brazilvaluecapture.multiplier.itsclass.model.dao.ItsClassFilter;
import com.monsanto.brazilvaluecapture.multiplier.itsclass.service.ItsClassService;
import com.monsanto.brazilvaluecapture.multiplier.obtainer.ObtainerTestData;
import com.monsanto.brazilvaluecapture.multiplier.obtainer.model.bean.Obtainer;

public class ItsClassService_AT extends AbstractServiceIntegrationTests {

	@Autowired
	private ItsClassService itsClassService;
	
	@Before
	public void setup() {
		systemTestFixture = new SystemTestFixture(this);
	}
	
	@Test
	public void given_a_its_class_with_empty_description_should_throw_exception() {
		ItsClass itsClass = createDefaultItsClass();
		itsClass.setDescription("");
		try {
			itsClassService.save(itsClass);
			Assert.fail();
		} catch (ConstraintException e) {
			ConstraintViolation violation = e.getViolations().get(0);
			Assert.assertEquals("Description is required", violation.getMessage());
		}
	}
	
	@Test
	public void given_a_its_class_without_description_should_throw_exception() {
		ItsClass itsClass = createDefaultItsClass();
		itsClass.setDescription(null);
		try {
			itsClassService.save(itsClass);
			Assert.fail();
		} catch (ConstraintException e) {
			ConstraintViolation violation = e.getViolations().get(0);
			Assert.assertEquals("Description is required", violation.getMessage());
		}
	}
	
	@Test
	public void given_a_its_class_with_empty_abbreviation_should_throw_exception() {
		ItsClass itsClass = createDefaultItsClass();
		itsClass.setAbbreviation("");
		try {
			itsClassService.save(itsClass);
			Assert.fail();
		} catch (ConstraintException e) {
			ConstraintViolation violation = e.getViolations().get(0);
			Assert.assertEquals("Abbreviation is required", violation.getMessage());
		}
	}
	
	@Test
	public void given_a_its_class_without_abbreviation_should_throw_exception() {
		ItsClass itsClass = createDefaultItsClass();
		itsClass.setAbbreviation(null);
		try {
			itsClassService.save(itsClass);
			Assert.fail();
		} catch (ConstraintException e) {
			ConstraintViolation violation = e.getViolations().get(0);
			Assert.assertEquals("Abbreviation is required", violation.getMessage());
		}
	}
	
	@Test
	public void given_a_its_class_without_sequence_should_throw_exception() {
		ItsClass itsClass = createDefaultItsClass();
		itsClass.setSequence(null);
		try {
			itsClassService.save(itsClass);
			Assert.fail();
		} catch (ConstraintException e) {
			ConstraintViolation violation = e.getViolations().get(0);
			Assert.assertEquals("Sequence is required", violation.getMessage());
		}
	}
	
	@Test
	public void given_a_its_class_without_crop_should_throw_exception() {
		ItsClass itsClass = createDefaultItsClass();
		itsClass.setCrop(null);
		try {
			itsClassService.save(itsClass);
			Assert.fail();
		} catch (ConstraintException e) {
			ConstraintViolation violation = e.getViolations().get(0);
			Assert.assertEquals("Crop is required", violation.getMessage());
		}
	}
	
	@Test
	public void given_a_its_class_with_existing_abbreviation_should_throw_exception() {
		ItsClass itsClass = createDefaultItsClass();
		saveAndFlush(itsClass);
		ItsClass anotherItsClass = new ItsClass("Another Class", itsClass.getAbbreviation(), 1L, StatusEnum.INACTIVE, systemTestFixture.coffee);
		try {
			itsClassService.save(anotherItsClass);
			Assert.fail();
		} catch (ConstraintException e) {
			ConstraintViolation violation = e.getViolations().get(0);
			Assert.assertEquals("Abbreviation already exist", violation.getMessage());
		}
	}
	
	@SuppressWarnings("unchecked")
	@Test
	public void given_a_its_class_with_all_required_values_should_save_successfully() throws ConstraintException {
		ItsClass itsClass = createDefaultItsClass();
		
		itsClassService.save(itsClass);
		
		List<ItsClass> itsClassList = (List<ItsClass>) getSession().createCriteria(ItsClass.class).list();
		Assert.assertTrue("Class List should contains saved Class", itsClassList.contains(itsClass));
	}
	
	@SuppressWarnings("unchecked")
	@Test
	public void given_a_edited_its_class_with_valid_values_should_save_successfully() throws ConstraintException {
		ItsClass itsClass = createDefaultItsClass();
		saveAndFlush(itsClass);
		
		itsClass.setDescription("Edited Test Class");
		itsClassService.save(itsClass);
		
		List<ItsClass> itsClassList = (List<ItsClass>) getSession().createCriteria(ItsClass.class).list();
		Assert.assertTrue("Class List should contains saved Class", itsClassList.contains(itsClass));
	}
	
	@SuppressWarnings("unchecked")
	@Test
	public void given_a_its_class_should_delete_successfully() throws ConstraintException {
		ItsClass itsClass = createDefaultItsClass();
		saveAndFlush(itsClass);
		
		itsClassService.delete(itsClass);
		
		List<ItsClass> itsClassList = (List<ItsClass>) getSession().createCriteria(ItsClass.class).list();
		Assert.assertFalse("Class should not contains deleted Class", itsClassList.contains(itsClass));
	}
	
	@Test
	public void given_a_class_with_obtainer_associated_should_throw_exception() {
		ItsClass itsClass = createDefaultItsClass();
		saveAndFlush(itsClass);
		
		Obtainer obtainer = ObtainerTestData.createActiveObtainer(systemTestFixture.soy);
		obtainer.addClass(itsClass);
		saveAndFlush(obtainer);
		
		try {
			itsClassService.delete(itsClass);
			Assert.fail("Should not delete.");
		} catch (ConstraintException e) {
			ConstraintViolation violation = e.getViolations().get(0);
			Assert.assertEquals("error.class.associated.obtainer", violation.getMessage());
		}
	}
	
	@Test
	public void when_search_its_class_by_filter_should_return_only_its_classes_with_filtered_values() {
		ItsClass itsClass = createDefaultItsClass();
		saveAndFlush(itsClass);
		
		ItsClass anotherItsClass = new ItsClass("Another Class", "AC", 1L, StatusEnum.ACTIVE, systemTestFixture.soy);
		saveAndFlush(anotherItsClass);
		
		ItsClassFilter filter = ItsClassFilter.getInstance();
		filter.addDescription("  ther C ").addAbbreviation(" AC").addStatus(StatusEnum.ACTIVE).addCrop(systemTestFixture.soy);
		
		List<ItsClass> itsClasseList = itsClassService.selectByFilter(filter);
		
		Assert.assertEquals(1, itsClasseList.size());
		Assert.assertTrue(itsClasseList.contains(anotherItsClass));
		Assert.assertFalse(itsClasseList.contains(itsClass));
	}
	
	@Test
	public void when_search_its_class_without_filter_should_return_all_classes() {
		ItsClass itsClass = createDefaultItsClass();
		saveAndFlush(itsClass);
		
		ItsClass anotherItsClass = new ItsClass("Another Class", "AC", 1L, StatusEnum.INACTIVE, systemTestFixture.coffee);
		saveAndFlush(anotherItsClass);
		
		ItsClassFilter filter = ItsClassFilter.getInstance();
		filter.addDescription(null).addAbbreviation(null).addStatus(null).addCrop(null);
		
		List<ItsClass> itsClasseList = itsClassService.selectByFilter(filter);
		
		Assert.assertEquals(2, itsClasseList.size());
		Assert.assertTrue(itsClasseList.contains(anotherItsClass));
		Assert.assertTrue(itsClasseList.contains(itsClass));
	}
	
	@Test
	public void when_search_by_id_should_return_correct_a_its_class() {
		ItsClass itsClass = createDefaultItsClass();
		saveAndFlush(itsClass);
		
		ItsClass itsClassSearch = itsClassService.selectById(itsClass.getPrimaryKey());
		
		Assert.assertEquals(itsClass, itsClassSearch);
	}

	private ItsClass createDefaultItsClass() {
		return new ItsClass("Test Class", "TC", 0L, StatusEnum.ACTIVE, systemTestFixture.soy);
	}
	
}
