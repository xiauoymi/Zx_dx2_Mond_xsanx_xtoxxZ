package com.monsanto.brazilvaluecapture.multiplier.volumereport.service.impl;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import junit.framework.Assert;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

import com.monsanto.brazilvaluecapture.core.base.model.bean.Address;
import com.monsanto.brazilvaluecapture.core.base.model.bean.City;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Company;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Country;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Crop;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Document;
import com.monsanto.brazilvaluecapture.core.base.model.bean.DocumentType;
import com.monsanto.brazilvaluecapture.core.base.model.bean.OperationalYear;
import com.monsanto.brazilvaluecapture.core.base.model.bean.State;
import com.monsanto.brazilvaluecapture.core.base.service.ConstraintException;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Customer;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.HeadOffice;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Technology;
import com.monsanto.brazilvaluecapture.core.foundation.model.bean.StatusEnum;
import com.monsanto.brazilvaluecapture.core.foundation.util.ConstraintViolation;
import com.monsanto.brazilvaluecapture.multiplier.cultivar.model.bean.Cultivar;
import com.monsanto.brazilvaluecapture.multiplier.harvestcalendar.model.bean.HarvestCalendar;
import com.monsanto.brazilvaluecapture.multiplier.itsclass.model.bean.ItsClass;
import com.monsanto.brazilvaluecapture.multiplier.obtainer.model.bean.Obtainer;
import com.monsanto.brazilvaluecapture.multiplier.volumereport.model.bean.VolumeReportDetail;
import com.monsanto.brazilvaluecapture.multiplier.volumereport.model.bean.VolumeReportHeader;
import com.monsanto.brazilvaluecapture.multiplier.volumereport.model.bean.VolumeReportStatus;
import com.monsanto.brazilvaluecapture.seedsale.harvest.model.bean.Harvest;

public class VolumeReportValidator_UT {
    private BigDecimal negativeValue = BigDecimal.valueOf(-1L);
    private BigDecimal validValue = BigDecimal.TEN;
    protected Date pastDateStart;
    protected Date pastDateEnd;
    protected Date currentDateStart;
    protected Date currentDateEnd;
    protected Date futureDateStart;
    protected Date futureDateEnd;
    protected HarvestCalendar harvestCalendarPast;
    protected HarvestCalendar harvestCalendarCurrent;
    protected HarvestCalendar harvestCalendarFuture;
    protected Harvest harvest;
    protected Obtainer obtainer;
    protected HeadOffice headOffice;
    protected Cultivar cultivar;
    protected ItsClass itsClass;

    public VolumeReportValidator_UT() {
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.MONTH, -6);
        pastDateStart = calendar.getTime();
        calendar.add(Calendar.MONTH, 1);
        pastDateEnd = calendar.getTime();

        calendar = Calendar.getInstance();
        calendar.add(Calendar.MONTH,-1);
        currentDateStart = calendar.getTime();
        calendar.add(Calendar.MONTH, 2);
        currentDateEnd = calendar.getTime();

        calendar = Calendar.getInstance();
        calendar.add(Calendar.MONTH, 6);
        futureDateStart = calendar.getTime();
        calendar.add(Calendar.MONTH,1);
        futureDateEnd = calendar.getTime();
    }

    private VolumeReportValidator volumeReportValidator = new VolumeReportValidator();

    private void initializePhase1(VolumeReportDetail detail, BigDecimal enteredArea, BigDecimal ownSeed, BigDecimal matrixSeed) {
        detail.getEnteredArea().setValue(enteredArea);
        detail.getMatrixSeedUsed().setValue(matrixSeed);
        detail.getOwnSeedUsed().setValue(ownSeed);
    }

    private void initializePhase2(VolumeReportDetail detail, BigDecimal areaHarvested, BigDecimal areaHarvesteForSeed, BigDecimal volumeHarvested, BigDecimal volumeForUbs) {
        initializePhase1(detail, null, null, null);
        detail.getEnteredArea().setStatus(VolumeReportStatus.APPROVED);
        
    	detail.getVolumeHarvested().setValue(volumeHarvested);
        detail.getVolumeForUBS().setValue(volumeForUbs);
    }

    private void initializePhase3(VolumeReportDetail detail, BigDecimal volumeBenefitted) {
        initializePhase2(detail, null, null, null, null);
        detail.setNotUseDiscardPortioning(true);
        detail.getPortioning().setStatus(VolumeReportStatus.APPROVED);
        detail.getVolumeHarvested().setStatus(VolumeReportStatus.APPROVED);
        detail.getVolumeForUBS().setStatus(VolumeReportStatus.APPROVED);
        
    	detail.getVolumeBenefitted().setValue(volumeBenefitted);
    }

    private void initializePhase4(VolumeReportDetail detail, BigDecimal volumeApproved) {
        initializePhase3(detail, null);
        detail.getVolumeBenefitted().setStatus(VolumeReportStatus.APPROVED);
        
    	detail.getVolumeApproved().setValue(volumeApproved);
    }


    private void initializePhase5(VolumeReportDetail detail, BigDecimal volumeComm1, BigDecimal volumeComm2, BigDecimal volumeComm3) {
        initializePhase4(detail, null);
        detail.getVolumeApproved().setStatus(VolumeReportStatus.APPROVED);
    	
    	detail.getVolumeCommercialized1().setValue(volumeComm1);
        detail.getVolumeCommercialized2().setValue(volumeComm2);
        detail.getVolumeCommercialized3().setValue(volumeComm3);
    }

    private void initializePhase6(VolumeReportDetail detail, BigDecimal volumeForNextHarvest) {
        initializePhase5(detail, null, null, null);
        detail.getVolumeCommercialized1().setStatus(VolumeReportStatus.APPROVED);
        detail.getVolumeCommercialized2().setStatus(VolumeReportStatus.APPROVED);
        detail.getVolumeCommercialized3().setStatus(VolumeReportStatus.APPROVED);
        
    	detail.getVolumeForNextHarvest().setValue(volumeForNextHarvest);
    }

    @Before
    public void setup() {
        harvestCalendarCurrent = Mockito.mock(HarvestCalendar.class);

        // Phase 1
        Mockito.when(harvestCalendarCurrent.getInscribedAreaStart()).thenReturn(currentDateStart);
        Mockito.when(harvestCalendarCurrent.getInscribedAreaEnd()).thenReturn(currentDateEnd);
        Mockito.when(harvestCalendarCurrent.getOwnSeedVolUsedStart()).thenReturn(currentDateStart);
        Mockito.when(harvestCalendarCurrent.getOwnSeedVolUsedEnd()).thenReturn(currentDateEnd);
        Mockito.when(harvestCalendarCurrent.getMatrixSeedVolOwnedStart()).thenReturn(currentDateStart);
        Mockito.when(harvestCalendarCurrent.getMatrixSeedVolOwnedEnd()).thenReturn(currentDateEnd);
        // Phase 2
        Mockito.when(harvestCalendarCurrent.getHarvestVolStart()).thenReturn(currentDateStart);
        Mockito.when(harvestCalendarCurrent.getHarvestVolEnd()).thenReturn(currentDateEnd);
        Mockito.when(harvestCalendarCurrent.getUbsDestVolStart()).thenReturn(currentDateStart);
        Mockito.when(harvestCalendarCurrent.getUbsDestVolEnd()).thenReturn(currentDateEnd);
        Mockito.when(harvestCalendarCurrent.getHarvestDiscardedAreaStart()).thenReturn(currentDateStart);
        Mockito.when(harvestCalendarCurrent.getHarvestDiscardedAreaEnd()).thenReturn(currentDateEnd);
        // phase 3
        Mockito.when(harvestCalendarCurrent.getBenefittedVolStart()).thenReturn(currentDateStart);
        Mockito.when(harvestCalendarCurrent.getBenefittedVolEnd()).thenReturn(currentDateEnd);
        // phase 4
        Mockito.when(harvestCalendarCurrent.getApprovedVolStart()).thenReturn(currentDateStart);
        Mockito.when(harvestCalendarCurrent.getApprovedVolEnd()).thenReturn(currentDateEnd);
        // Phase 5
        Mockito.when(harvestCalendarCurrent.getFirstCommldVolStart()).thenReturn(currentDateStart);
        Mockito.when(harvestCalendarCurrent.getFirstCommldVolEnd()).thenReturn(currentDateEnd);
        Mockito.when(harvestCalendarCurrent.getSecondCommldVolStart()).thenReturn(currentDateStart);
        Mockito.when(harvestCalendarCurrent.getSecondCommldVolEnd()).thenReturn(currentDateEnd);
        Mockito.when(harvestCalendarCurrent.getThirdCommldVolStart()).thenReturn(currentDateStart);
        Mockito.when(harvestCalendarCurrent.getThirdCommldVolEnd()).thenReturn(currentDateEnd);
        // phase 6
        Mockito.when(harvestCalendarCurrent.getNextHarvestVolStart()).thenReturn(currentDateStart);
        Mockito.when(harvestCalendarCurrent.getNextHarvestVolEnd()).thenReturn(currentDateEnd);
    }

    @Test
    public void given_empty_phase2_3_when_validate_should_pass() {
    	Date validateDate = new Date();
        ConstraintException exception = new ConstraintException("Test exception");
        VolumeReportDetail detail = getVolumeReportDetail(true, true, false);
        initializePhase2(detail, null, null, null, null);
        volumeReportValidator.validatePhase2(detail, validateDate, exception);
        Assert.assertEquals("Should have no violations", 0, exception.getViolations().size());
    }

    @Test
    public void given_valid_phase2_3_when_validate_should_pass() {
    	Date validateDate = new Date();
        ConstraintException exception = new ConstraintException("Test exception");
        VolumeReportDetail detail = getVolumeReportDetail(true, true, false);
        initializePhase2(detail, null, null, validValue, null);
        volumeReportValidator.validatePhase2(detail, validateDate, exception);
        Assert.assertEquals("Should have no violations", 0, exception.getViolations().size());
    }

    @Test
    public void given_empty_phase2_3_in_reported_status_when_validate_should_have_1_violation() {
    	Date validateDate = new Date();
        ConstraintException exception = new ConstraintException("Test exception");
        VolumeReportDetail detail = getVolumeReportDetail(true, true, false);
        initializePhase2(detail, null, null, null, null);
        detail.setNotUseDiscardPortioning(true);
        detail.getPortioning().setStatus(VolumeReportStatus.APPROVED);
        detail.getVolumeHarvested().setStatus(VolumeReportStatus.REPORTED);
        volumeReportValidator.validatePhase2(detail, validateDate, exception);
        Assert.assertEquals("Should have one violations", 1, exception.getViolations().size());
    }
    
    @Test
    public void given_empty_phase2_3_in_returned_status_but_not_avaliable_should_pass() {
    	Date validateDate = new Date();
        ConstraintException exception = new ConstraintException("Test exception");
        VolumeReportDetail detail = getVolumeReportDetail(true, true, false);
        initializePhase2(detail, null, null, null, null);
        detail.setNotUseDiscardPortioning(true);
        detail.getPortioning().setStatus(VolumeReportStatus.RETURNED);
        detail.getVolumeHarvested().setStatus(VolumeReportStatus.RETURNED);
        volumeReportValidator.validatePhase2(detail, validateDate, exception);
        Assert.assertEquals("Should have one violation", 0, exception.getViolations().size());
    }

    @Test
    public void given_empty_phase2_4_when_validate_should_pass() {
    	Date validateDate = new Date();
        ConstraintException exception = new ConstraintException("Test exception");
        VolumeReportDetail detail = getVolumeReportDetail(true, true, false);
        initializePhase2(detail, null, null, null, null);
        volumeReportValidator.validatePhase2(detail, validateDate, exception);
        Assert.assertEquals("Should have no violations", 0, exception.getViolations().size());
    }

    @Test
    public void given_valid_phase2_4_when_validate_should_pass() {
    	Date validateDate = new Date();
        ConstraintException exception = new ConstraintException("Test exception");
        VolumeReportDetail detail = getVolumeReportDetail(true, true, false);
        initializePhase2(detail, null, null, null, validValue);
        volumeReportValidator.validatePhase2(detail, validateDate, exception);
        Assert.assertEquals("Should have no violations", 0, exception.getViolations().size());
    }

    @Test
    public void given_empty_phase2_4_in_reported_status_when_validate_should_have_1_violation() {
    	Date validateDate = new Date();
        ConstraintException exception = new ConstraintException("Test exception");
        VolumeReportDetail detail = getVolumeReportDetail(true, true, false);
        initializePhase2(detail, null, null, null, null);
        detail.getPortioning().setStatus(VolumeReportStatus.APPROVED);
        detail.getVolumeHarvested().setValue(validValue);
        detail.getVolumeHarvested().setStatus(VolumeReportStatus.APPROVED);
        detail.getVolumeForUBS().setStatus(VolumeReportStatus.REPORTED);
        volumeReportValidator.validatePhase2(detail, validateDate, exception);
        Assert.assertEquals("Should have one violations", 1, exception.getViolations().size());
    }
    
    @Test
    public void given_empty_phase2_4_in_returned_status_but_not_avaliable_should_pass() {
    	Date validateDate = new Date();
        ConstraintException exception = new ConstraintException("Test exception");
        VolumeReportDetail detail = getVolumeReportDetail(true, true, false);
        initializePhase2(detail, null, null, null, null);
        detail.setNotUseDiscardPortioning(true);
        detail.getPortioning().setStatus(VolumeReportStatus.APPROVED);
        detail.getVolumeHarvested().setValue(validValue);
        detail.getVolumeHarvested().setStatus(VolumeReportStatus.RETURNED);
        detail.getVolumeForUBS().setStatus(VolumeReportStatus.RETURNED);
        volumeReportValidator.validatePhase2(detail, validateDate, exception);
        Assert.assertEquals("Should have one violation", 0, exception.getViolations().size());
    }
    
    @Test
    public void given_empty_phase5_1_when_validate_should_pass() {
    	Date validateDate = new Date();
        ConstraintException exception = new ConstraintException("Test exception");
        VolumeReportDetail detail = getVolumeReportDetail(true, true, false);
        initializePhase5(detail, null, null, null);
        volumeReportValidator.validatePhase5(detail, validateDate, exception);
        Assert.assertEquals("Should have no violations", 0, exception.getViolations().size());
    }
    
    @Test
    public void given_valid_phase5_1_when_validate_should_pass() {
    	Date validateDate = new Date();
        ConstraintException exception = new ConstraintException("Test exception");
        VolumeReportDetail detail = getVolumeReportDetail(true, true, false);
        initializePhase5(detail,validValue, null, null);
        volumeReportValidator.validatePhase5(detail, validateDate, exception);
        Assert.assertEquals("Should have no violations", 0, exception.getViolations().size());
    }

    @Test
    public void given_empty_phase5_1_in_reported_status_when_validate_should_have_one_exception() {
    	Date validateDate = new Date();
        ConstraintException exception = new ConstraintException("Test exception");
        VolumeReportDetail detail = getVolumeReportDetail(true, true, false);
        initializePhase5(detail, null, null, null);
        detail.getVolumeCommercialized1().setStatus(VolumeReportStatus.REPORTED);
        volumeReportValidator.validatePhase5(detail, validateDate, exception);
        Assert.assertEquals("Should have one violation", 1, exception.getViolations().size());
    }
    
    @Test
    public void given_empty_phase5_1_in_returned_status_but_not_avaliable_should_pass() {
    	Date validateDate = new Date();
        ConstraintException exception = new ConstraintException("Test exception");
        VolumeReportDetail detail = getVolumeReportDetail(true, true, false);
        initializePhase5(detail, null, null, null);
        detail.getVolumeApproved().setStatus(VolumeReportStatus.RETURNED);
        detail.getVolumeCommercialized1().setStatus(VolumeReportStatus.RETURNED);
        volumeReportValidator.validatePhase5(detail, validateDate, exception);
        Assert.assertEquals("Should have one violation", 0, exception.getViolations().size());
    }
    
    @Test
    public void given_empty_phase5_1_parent_with_one_child_filled_when_validate_should_have_1_error() {
    	Date validateDate = new Date();
        ConstraintException exception = new ConstraintException("Test exception");
        VolumeReportDetail detailParent = getVolumeReportDetail(true, true, false);
        initializePhase5(detailParent, null, null, null);
        
        VolumeReportDetail detailChild1 = new VolumeReportDetail(detailParent.getCultivar(), new ItsClass("CLASS1", "C2", 1L, StatusEnum.ACTIVE, detailParent.getCultivar().getCrop()), detailParent.getVolumeReportHeader());
        detailChild1.setProductivity(BigInteger.TEN);
        initializePhase5(detailChild1, null, null, null);
        detailChild1.getVolumeCommercialized1().setValue(validValue);
        detailChild1.setVolumeReportDetailParent(detailParent);
        detailParent.getVolumeReportDetailChildren().add(detailChild1);
        
        volumeReportValidator.validatePhase5(detailParent, validateDate, exception);
        Assert.assertEquals("Should have one violation", 1, exception.getViolations().size());
    }
    
    @Test
    public void given_empty_phase5_1_child_with_parent_filled_when_validate_should_have_1_error() {
    	Date validateDate = new Date();
        ConstraintException exception = new ConstraintException("Test exception");
        VolumeReportDetail detailParent = getVolumeReportDetail(true, true, false);
        initializePhase5(detailParent, null, null, null);
        detailParent.getVolumeCommercialized1().setValue(validValue);
        
        VolumeReportDetail detailChild1 = new VolumeReportDetail(detailParent.getCultivar(), new ItsClass("CLASS1", "C2", 1L, StatusEnum.ACTIVE, detailParent.getCultivar().getCrop()), detailParent.getVolumeReportHeader());
        detailChild1.setProductivity(BigInteger.TEN);
        initializePhase6(detailChild1, null);
        detailChild1.setVolumeReportDetailParent(detailParent);
        detailParent.getVolumeReportDetailChildren().add(detailChild1);
        
        volumeReportValidator.validatePhase5(detailChild1, validateDate, exception);
        Assert.assertEquals("Should have one violation", 1, exception.getViolations().size());
    }

    @Test
    public void given_empty_phase5_2_when_validate_should_pass() {
    	Date validateDate = new Date();
        ConstraintException exception = new ConstraintException("Test exception");
        VolumeReportDetail detail = getVolumeReportDetail(true, true, false);
        initializePhase5(detail, null, null, null);
        volumeReportValidator.validatePhase5(detail, validateDate, exception);
        Assert.assertEquals("Should have no violations", 0, exception.getViolations().size());
    }

    @Test
    public void given_valid_phase5_2_when_validate_should_pass() {
    	Date validateDate = new Date();
        ConstraintException exception = new ConstraintException("Test exception");
        VolumeReportDetail detail = getVolumeReportDetail(true, true, false);
        initializePhase5(detail,null, validValue, null);
        volumeReportValidator.validatePhase5(detail, validateDate, exception);
        Assert.assertEquals("Should have no violations", 0, exception.getViolations().size());
    }

    @Test
    public void given_empty_phase5_2_in_reported_status_when_validate_should_have_one_exception() {
    	Date validateDate = new Date();
        ConstraintException exception = new ConstraintException("Test exception");
        VolumeReportDetail detail = getVolumeReportDetail(true, true, false);
        initializePhase5(detail, null, null, null);
        detail.getVolumeCommercialized1().setStatus(VolumeReportStatus.APPROVED);
        detail.getVolumeCommercialized2().setStatus(VolumeReportStatus.REPORTED);
        volumeReportValidator.validatePhase5(detail, validateDate, exception);
        Assert.assertEquals("Should have one violation", 1, exception.getViolations().size());
    }
    
    @Test
    public void given_empty_phase5_2_in_returned_status_but_not_avaliable_should_pass() {
    	Date validateDate = new Date();
        ConstraintException exception = new ConstraintException("Test exception");
        VolumeReportDetail detail = getVolumeReportDetail(true, true, false);
        initializePhase5(detail, null, null, null);
        detail.getVolumeCommercialized1().setStatus(VolumeReportStatus.RETURNED);
        detail.getVolumeCommercialized1().setValue(validValue);
        detail.getVolumeCommercialized2().setStatus(VolumeReportStatus.RETURNED);
        volumeReportValidator.validatePhase5(detail, validateDate, exception);
        Assert.assertEquals("Should have one violation", 0, exception.getViolations().size());
    }
    
    @Test
    public void given_empty_phase5_2_parent_with_one_child_filled_when_validate_should_have_1_error() {
    	Date validateDate = new Date();
        ConstraintException exception = new ConstraintException("Test exception");
        VolumeReportDetail detailParent = getVolumeReportDetail(true, true, false);
        initializePhase5(detailParent, null, null, null);
        detailParent.getVolumeCommercialized1().setStatus(VolumeReportStatus.APPROVED);
        
        VolumeReportDetail detailChild1 = new VolumeReportDetail(detailParent.getCultivar(), new ItsClass("CLASS1", "C2", 1L, StatusEnum.ACTIVE, detailParent.getCultivar().getCrop()), detailParent.getVolumeReportHeader());
        detailChild1.setProductivity(BigInteger.TEN);
        initializePhase5(detailChild1, null, null, null);
        detailChild1.getVolumeCommercialized2().setValue(validValue);
        detailChild1.setVolumeReportDetailParent(detailParent);
        detailParent.getVolumeReportDetailChildren().add(detailChild1);
        
        volumeReportValidator.validatePhase5(detailParent, validateDate, exception);
        Assert.assertEquals("Should have one violation", 1, exception.getViolations().size());
    }
    
    @Test
    public void given_empty_phase5_2_child_with_parent_filled_when_validate_should_have_1_error() {
    	Date validateDate = new Date();
        ConstraintException exception = new ConstraintException("Test exception");
        VolumeReportDetail detailParent = getVolumeReportDetail(true, true, false);
        initializePhase5(detailParent, null, null, null);
        detailParent.getVolumeCommercialized1().setStatus(VolumeReportStatus.APPROVED);
        detailParent.getVolumeCommercialized2().setValue(validValue);
        
        VolumeReportDetail detailChild1 = new VolumeReportDetail(detailParent.getCultivar(), new ItsClass("CLASS1", "C2", 1L, StatusEnum.ACTIVE, detailParent.getCultivar().getCrop()), detailParent.getVolumeReportHeader());
        detailChild1.setProductivity(BigInteger.TEN);
        initializePhase5(detailChild1, null, null, null);
        detailChild1.setVolumeReportDetailParent(detailParent);
        detailParent.getVolumeReportDetailChildren().add(detailChild1);
        
        volumeReportValidator.validatePhase5(detailChild1, validateDate, exception);
        Assert.assertEquals("Should have one violation", 1, exception.getViolations().size());
    }

    @Test
    public void given_empty_phase5_3_when_validate_should_pass() {
    	Date validateDate = new Date();
        ConstraintException exception = new ConstraintException("Test exception");
        VolumeReportDetail detail = getVolumeReportDetail(true, true, false);
        initializePhase5(detail, null, null, null);
        volumeReportValidator.validatePhase5(detail, validateDate, exception);
        Assert.assertEquals("Should have no violations", 0, exception.getViolations().size());
    }

    @Test
    public void given_valid_phase5_3_when_validate_should_pass() {
    	Date validateDate = new Date();
        ConstraintException exception = new ConstraintException("Test exception");
        VolumeReportDetail detail = getVolumeReportDetail(true, true, false);
        initializePhase5(detail,null, null, validValue);
        volumeReportValidator.validatePhase5(detail, validateDate, exception);
        Assert.assertEquals("Should have no violations", 0, exception.getViolations().size());
    }

    @Test
    public void given_empty_phase5_3_in_reported_status_when_validate_should_have_one_exception() {
    	Date validateDate = new Date();
        ConstraintException exception = new ConstraintException("Test exception");
        VolumeReportDetail detail = getVolumeReportDetail(true, true, false);
        initializePhase5(detail, null, null, null);
        detail.getVolumeCommercialized1().setStatus(VolumeReportStatus.APPROVED);
        detail.getVolumeCommercialized2().setStatus(VolumeReportStatus.APPROVED);
        detail.getVolumeCommercialized3().setStatus(VolumeReportStatus.REPORTED);
        volumeReportValidator.validatePhase5(detail, validateDate, exception);
        Assert.assertEquals("Should have one violation", 1, exception.getViolations().size());
    }
    
    @Test
    public void given_empty_phase5_3_in_returned_status_but_not_avaliable_should_pass() {
    	Date validateDate = new Date();
        ConstraintException exception = new ConstraintException("Test exception");
        VolumeReportDetail detail = getVolumeReportDetail(true, true, false);
        initializePhase5(detail, null, null, null);
        detail.getVolumeCommercialized1().setStatus(VolumeReportStatus.APPROVED);
        detail.getVolumeCommercialized1().setValue(validValue);
        detail.getVolumeCommercialized2().setStatus(VolumeReportStatus.RETURNED);
        detail.getVolumeCommercialized2().setValue(validValue);
        detail.getVolumeCommercialized3().setStatus(VolumeReportStatus.RETURNED);
        volumeReportValidator.validatePhase5(detail, validateDate, exception);
        Assert.assertEquals("Should have one violation", 0, exception.getViolations().size());
    }
    
    @Test
    public void given_empty_phase5_3_parent_with_one_child_filled_when_validate_should_have_1_error() {
    	Date validateDate = new Date();
        ConstraintException exception = new ConstraintException("Test exception");
        VolumeReportDetail detailParent = getVolumeReportDetail(true, true, false);
        initializePhase5(detailParent, null, null, null);
        detailParent.getVolumeCommercialized1().setStatus(VolumeReportStatus.APPROVED);
        detailParent.getVolumeCommercialized2().setStatus(VolumeReportStatus.APPROVED);
        
        VolumeReportDetail detailChild1 = new VolumeReportDetail(detailParent.getCultivar(), new ItsClass("CLASS1", "C2", 1L, StatusEnum.ACTIVE, detailParent.getCultivar().getCrop()), detailParent.getVolumeReportHeader());
        detailChild1.setProductivity(BigInteger.TEN);
        initializePhase5(detailChild1, null, null, null);
        detailChild1.getVolumeCommercialized3().setValue(validValue);
        detailChild1.setVolumeReportDetailParent(detailParent);
        detailParent.getVolumeReportDetailChildren().add(detailChild1);
        
        volumeReportValidator.validatePhase5(detailParent, validateDate, exception);
        Assert.assertEquals("Should have one violation", 1, exception.getViolations().size());
    }
    
    @Test
    public void given_empty_phase5_3_child_with_parent_filled_when_validate_should_have_1_error() {
    	Date validateDate = new Date();
        ConstraintException exception = new ConstraintException("Test exception");
        VolumeReportDetail detailParent = getVolumeReportDetail(true, true, false);
        initializePhase5(detailParent, null, null, null);
        detailParent.getVolumeCommercialized1().setStatus(VolumeReportStatus.APPROVED);
        detailParent.getVolumeCommercialized2().setStatus(VolumeReportStatus.APPROVED);
        detailParent.getVolumeCommercialized3().setValue(validValue);
        
        VolumeReportDetail detailChild1 = new VolumeReportDetail(detailParent.getCultivar(), new ItsClass("CLASS1", "C2", 1L, StatusEnum.ACTIVE, detailParent.getCultivar().getCrop()), detailParent.getVolumeReportHeader());
        detailChild1.setProductivity(BigInteger.TEN);
        initializePhase5(detailChild1, null, null, null);
        detailChild1.setVolumeReportDetailParent(detailParent);
        detailParent.getVolumeReportDetailChildren().add(detailChild1);
        
        volumeReportValidator.validatePhase5(detailChild1, validateDate, exception);
        Assert.assertEquals("Should have one violation", 1, exception.getViolations().size());
    }

    @Test
    public void given_valid_phase5_3_with_no_germ_in_reported_status_when_validate_should_have_no_exceptions() {
    	Date validateDate = new Date();
        ConstraintException exception = new ConstraintException("Test exception");
        VolumeReportDetail detail = getVolumeReportDetail(true, false, false);
        initializePhase5(detail, null, null, null);
        detail.getVolumeCommercialized3().setStatus(VolumeReportStatus.REPORTED);
        volumeReportValidator.validatePhase5(detail, validateDate, exception);
        Assert.assertEquals("Should have 0 violation", 0, exception.getViolations().size());
    }
    
    @Test
    public void given_valid_phase6_when_validate_should_pass() {
    	Date validateDate = new Date();
        ConstraintException exception = new ConstraintException("Test exception");
        VolumeReportDetail detail = getVolumeReportDetail(true, true, false);
        initializePhase6(detail, validValue);
        volumeReportValidator.validatePhase6(detail, validateDate, exception);
        Assert.assertEquals("Should have no violations", 0, exception.getViolations().size());
    }

    @Test
    public void given_empty_phase6_when_validate_should_pass() {
    	Date validateDate = new Date();
        ConstraintException exception = new ConstraintException("Test exception");
        VolumeReportDetail detail = getVolumeReportDetail(true, true, false);
        initializePhase6(detail, null);
        volumeReportValidator.validatePhase6(detail, validateDate, exception);
        Assert.assertEquals("Should have no violations", 0, exception.getViolations().size());
    }

    @Test
    public void given_empty_phase6_in_reported_status_when_validate_should_have_1_error() {
    	Date validateDate = new Date();
        ConstraintException exception = new ConstraintException("Test exception");
        VolumeReportDetail detail = getVolumeReportDetail(true, true, false);
        initializePhase6(detail, null);
        detail.getVolumeForNextHarvest().setStatus(VolumeReportStatus.REPORTED);
        volumeReportValidator.validatePhase6(detail, validateDate, exception);
        Assert.assertEquals("Should have one violation", 1, exception.getViolations().size());
    }
    
    @Test
    public void given_empty_phase6_in_returned_status_but_not_avaliable_should_pass() {
    	Date validateDate = new Date();
        ConstraintException exception = new ConstraintException("Test exception");
        VolumeReportDetail detail = getVolumeReportDetail(true, true, false);
        initializePhase6(detail, null);
        detail.getVolumeCommercialized3().setStatus(VolumeReportStatus.RETURNED);
        detail.getVolumeForNextHarvest().setStatus(VolumeReportStatus.RETURNED);
        volumeReportValidator.validatePhase6(detail, validateDate, exception);
        Assert.assertEquals("Should have one violation", 0, exception.getViolations().size());
    }
    
    @Test
    public void given_empty_phase6_parent_with_one_child_filled_when_validate_should_have_1_error() {
    	Date validateDate = new Date();
        ConstraintException exception = new ConstraintException("Test exception");
        VolumeReportDetail detailParent = getVolumeReportDetail(true, true, false);
        initializePhase6(detailParent, null);
        
        VolumeReportDetail detailChild1 = new VolumeReportDetail(detailParent.getCultivar(), new ItsClass("CLASS1", "C2", 1L, StatusEnum.ACTIVE, detailParent.getCultivar().getCrop()), detailParent.getVolumeReportHeader());
        detailChild1.setProductivity(BigInteger.TEN);
        initializePhase6(detailChild1, null);
        detailChild1.getVolumeForNextHarvest().setValue(validValue);
        detailChild1.setVolumeReportDetailParent(detailParent);
        detailParent.getVolumeReportDetailChildren().add(detailChild1);
        
        volumeReportValidator.validatePhase6(detailParent, validateDate, exception);
        Assert.assertEquals("Should have one violation", 1, exception.getViolations().size());
    }
    
    @Test
    public void given_empty_phase6_child_with_parent_filled_when_validate_should_have_1_error() {
    	Date validateDate = new Date();
        ConstraintException exception = new ConstraintException("Test exception");
        VolumeReportDetail detailParent = getVolumeReportDetail(true, true, false);
        initializePhase6(detailParent, null);
        detailParent.getVolumeForNextHarvest().setValue(validValue);
        
        VolumeReportDetail detailChild1 = new VolumeReportDetail(detailParent.getCultivar(), new ItsClass("CLASS1", "C2", 1L, StatusEnum.ACTIVE, detailParent.getCultivar().getCrop()), detailParent.getVolumeReportHeader());
        detailChild1.setProductivity(BigInteger.TEN);
        initializePhase6(detailChild1, null);
        detailChild1.setVolumeReportDetailParent(detailParent);
        detailParent.getVolumeReportDetailChildren().add(detailChild1);
        
        volumeReportValidator.validatePhase6(detailChild1, validateDate, exception);
        Assert.assertEquals("Should have one violation", 1, exception.getViolations().size());
    }

    @Test
    public void given_valid_phase4_when_validate_should_pass() {
    	Date validateDate = new Date();
        ConstraintException exception = new ConstraintException("Test exception");
        VolumeReportDetail detail = getVolumeReportDetail(true, true, false);
        initializePhase4(detail, validValue);
        volumeReportValidator.validatePhase4(detail, validateDate, exception);
        Assert.assertEquals("Should have no violations", 0, exception.getViolations().size());
    }

    @Test
    public void given_empty_phase4_when_validate_should_pass() {
    	Date validateDate = new Date();
        ConstraintException exception = new ConstraintException("Test exception");
        VolumeReportDetail detail = getVolumeReportDetail(true, true, false);
        initializePhase4(detail, null);
        volumeReportValidator.validatePhase4(detail, validateDate, exception);
        Assert.assertEquals("Should have no violations", 0, exception.getViolations().size());
    }
    
    @Test
    public void given_empty_phase4_parent_with_one_child_filled_when_validate_should_have_1_error() {
    	Date validateDate = new Date();
        ConstraintException exception = new ConstraintException("Test exception");
        VolumeReportDetail detailParent = getVolumeReportDetail(true, true, false);
        initializePhase4(detailParent, null);
        
        VolumeReportDetail detailChild1 = new VolumeReportDetail(detailParent.getCultivar(), new ItsClass("CLASS1", "C2", 1L, StatusEnum.ACTIVE, detailParent.getCultivar().getCrop()), detailParent.getVolumeReportHeader());
        detailChild1.setProductivity(BigInteger.TEN);
        initializePhase4(detailChild1, null);
        detailChild1.getVolumeApproved().setValue(validValue);
        detailChild1.setVolumeReportDetailParent(detailParent);
        detailParent.getVolumeReportDetailChildren().add(detailChild1);
        
        volumeReportValidator.validatePhase4(detailParent, validateDate, exception);
        Assert.assertEquals("Should have one violation", 1, exception.getViolations().size());
    }
    
    @Test
    public void given_empty_phase4_child_with_parent_filled_when_validate_should_have_1_error() {
    	Date validateDate = new Date();
        ConstraintException exception = new ConstraintException("Test exception");
        VolumeReportDetail detailParent = getVolumeReportDetail(true, true, false);
        initializePhase4(detailParent, null);
        detailParent.getVolumeApproved().setValue(validValue);
        
        VolumeReportDetail detailChild1 = new VolumeReportDetail(detailParent.getCultivar(), new ItsClass("CLASS1", "C2", 1L, StatusEnum.ACTIVE, detailParent.getCultivar().getCrop()), detailParent.getVolumeReportHeader());
        detailChild1.setProductivity(BigInteger.TEN);
        initializePhase4(detailChild1, null);
        detailChild1.setVolumeReportDetailParent(detailParent);
        detailParent.getVolumeReportDetailChildren().add(detailChild1);
        
        volumeReportValidator.validatePhase4(detailChild1, validateDate, exception);
        Assert.assertEquals("Should have one violation", 1, exception.getViolations().size());
    }
    
    @Test
    public void given_empty_phase4_child_with_another_child_from_same_parent_filled_when_validate_should_have_1_error() {
    	Date validateDate = new Date();
        ConstraintException exception = new ConstraintException("Test exception");
        VolumeReportDetail detailParent = getVolumeReportDetail(true, true, false);
        initializePhase4(detailParent, null);
        
        VolumeReportDetail detailChild1 = new VolumeReportDetail(detailParent.getCultivar(), new ItsClass("CLASS1", "C2", 1L, StatusEnum.ACTIVE, detailParent.getCultivar().getCrop()), detailParent.getVolumeReportHeader());
        detailChild1.setProductivity(BigInteger.TEN);
        initializePhase4(detailChild1, null);
        detailChild1.getVolumeApproved().setValue(validValue);
        detailChild1.setVolumeReportDetailParent(detailParent);
        detailParent.getVolumeReportDetailChildren().add(detailChild1);
        
        VolumeReportDetail detailChild2 = new VolumeReportDetail(detailParent.getCultivar(), new ItsClass("CLASS1", "C3", 1L, StatusEnum.ACTIVE, detailParent.getCultivar().getCrop()), detailParent.getVolumeReportHeader());
        detailChild2.setProductivity(BigInteger.TEN);
        initializePhase4(detailChild2, null);
        detailChild2.setVolumeReportDetailParent(detailParent);
        detailParent.getVolumeReportDetailChildren().add(detailChild2);
        
        volumeReportValidator.validatePhase4(detailChild2, validateDate, exception);
        Assert.assertEquals("Should have one violation", 1, exception.getViolations().size());
    }

    @Test
    public void given_empty_phase4_in_reported_status_when_validate_should_have_1_error() {
    	Date validateDate = new Date();
        ConstraintException exception = new ConstraintException("Test exception");
        VolumeReportDetail detail = getVolumeReportDetail(true, true, false);
        initializePhase4(detail, null);
        detail.getVolumeApproved().setStatus(VolumeReportStatus.REPORTED);
        volumeReportValidator.validatePhase4(detail, validateDate, exception);
        Assert.assertEquals("Should have one violation", 1, exception.getViolations().size());
    }
    
    @Test
    public void given_empty_phase4_in_returned_status_but_not_avaliable_should_pass() {
    	Date validateDate = new Date();
        ConstraintException exception = new ConstraintException("Test exception");
        VolumeReportDetail detail = getVolumeReportDetail(true, true, false);
        initializePhase4(detail, null);
        detail.getVolumeBenefitted().setStatus(VolumeReportStatus.RETURNED);
        detail.getVolumeApproved().setStatus(VolumeReportStatus.RETURNED);
        volumeReportValidator.validatePhase4(detail, validateDate, exception);
        Assert.assertEquals("Should have one violation", 0, exception.getViolations().size());
    }

    @Test
    public void given_valid_phase3_when_validate_should_pass() {
    	Date validateDate = new Date();
        ConstraintException exception = new ConstraintException("Test exception");
        VolumeReportDetail detail = getVolumeReportDetail(true, true, false);
        initializePhase3(detail,validValue);
        volumeReportValidator.validatePhase3(detail, validateDate, exception);
        Assert.assertEquals("Should have no violations", 0, exception.getViolations().size());
    }

    @Test
    public void given_empty_phase3_when_validate_should_pass() {
    	Date validateDate = new Date();
        ConstraintException exception = new ConstraintException("Test exception");
        VolumeReportDetail detail = getVolumeReportDetail(true, true, false);
        initializePhase3(detail,null);
        volumeReportValidator.validatePhase3(detail, validateDate, exception);
        Assert.assertEquals("Should have no violations", 0, exception.getViolations().size());
    }
    
    @Test
    public void given_empty_phase3_in_returned_status_but_not_avaliable_should_pass() {
    	Date validateDate = new Date();
        ConstraintException exception = new ConstraintException("Test exception");
        VolumeReportDetail detail = getVolumeReportDetail(true, true, false);
        initializePhase3(detail, null);
        detail.getVolumeForUBS().setStatus(VolumeReportStatus.RETURNED);
        detail.getVolumeBenefitted().setStatus(VolumeReportStatus.RETURNED);
        volumeReportValidator.validatePhase3(detail, validateDate, exception);
        Assert.assertEquals("Should have one violation", 0, exception.getViolations().size());
    }

    @Test
    public void given_empty_productivity_should_have_one_violation() {
        ConstraintException exception = new ConstraintException("Test exception");
        VolumeReportDetail detail = getVolumeReportDetail(true, true, false);
        detail.setProductivity(null);
        volumeReportValidator.validateProductivity(detail, exception);
        Assert.assertEquals("Should have 1 violations", 1, exception.getViolations().size());
    }

    @Test
    public void given_valid_productivity_should_have_no_violation() {
        ConstraintException exception = new ConstraintException("Test exception");
        VolumeReportDetail detail = getVolumeReportDetail(true, true, false);
        detail.setProductivity(BigInteger.TEN);
        volumeReportValidator.validateProductivity(detail, exception);
        Assert.assertEquals("Should have 0 violations", 0, exception.getViolations().size());
    }

    @Test
    public void given_empty_phase3_in_reported_status_when_validate_should_have_1_error() {
    	Date validateDate = new Date();
        ConstraintException exception = new ConstraintException("Test exception");
        VolumeReportDetail detail = getVolumeReportDetail(true, true, false);
        initializePhase3(detail, null);
        detail.getVolumeBenefitted().setStatus(VolumeReportStatus.REPORTED);
        volumeReportValidator.validatePhase3(detail, validateDate, exception);
        Assert.assertEquals("Should have one violation", 1, exception.getViolations().size());
    }

    @Test
    public void given_valid_phase1_when_validate_should_pass_with_no_exception_thrown() {
        Date validateDate = new Date();
        ConstraintException exception = new ConstraintException("Test exception");
        VolumeReportDetail detail = getVolumeReportDetail(true, true, false);
        initializePhase1(detail, validValue, validValue, validValue);
        volumeReportValidator.validatePhase1(detail, validateDate, exception);
        Assert.assertEquals("Should have no violations", 0, exception.getViolations().size());
    }

    private VolumeReportDetail getVolumeReportDetail(Boolean isCooperative, Boolean billGermoplasm, Boolean isObtainerExclusive) {
        Company nyop_ = new Company("_NYOP_");
        Country country = new Country("__CNTR__", "CN");
        Crop crop = new Crop("__NN__", nyop_, country);
        State state = new State(country, "__STATE__", "ST");
        Customer cust = new Customer("__CUST__", new Document(new DocumentType("CPP", country,"1111"),"1234"), new Address("__STREET__", new City("_CITY_", state), state, country, "11111"), "1234567");
        Obtainer obt__ = new Obtainer("__OBT__", StatusEnum.ACTIVE, crop);
        VolumeReportHeader header = new VolumeReportHeader(new Harvest(nyop_,"__HARV__", new OperationalYear("1960"), crop, StatusEnum.ACTIVE),
                cust, cust, obt__);
        header.setObtainerCooperative(isCooperative);
        header.setHarvestCalendar(harvestCalendarCurrent);
        VolumeReportDetail detail = new VolumeReportDetail(new Cultivar("__CULT__", billGermoplasm, true, StatusEnum.ACTIVE, crop, obt__, new Technology("__RRRR__", nyop_), isObtainerExclusive), new ItsClass("CLASS1", "C1", 1L, StatusEnum.ACTIVE, crop), header);
        detail.setProductivity(BigInteger.TEN);
        return detail;
    }

    @Test
    public void given_null_enteredArea_when_validate_enteredArea_message_should_be_present() {
        Date validateDate = new Date();
        ConstraintException exception = new ConstraintException("Test exception");
        VolumeReportDetail detail = getVolumeReportDetail(true, true, false);
        initializePhase1(detail, null, validValue, validValue);
        volumeReportValidator.validatePhase1(detail, validateDate, exception);
        Assert.assertEquals("Should have 1", 1, exception.getViolations().size());
        ConstraintViolation violation = exception.getViolations().iterator().next();
        Assert.assertEquals("Area required error should be present", "error.message.volume.report.entered.area.required", violation.getField());
    }

    @Test
    public void given_negative_enteredArea_when_validate_enteredArea_message_should_be_present() {
        Date validateDate = new Date();
        ConstraintException exception = new ConstraintException("Test exception");
        VolumeReportDetail detail = getVolumeReportDetail(true, true, false);
        initializePhase1(detail, negativeValue, validValue, validValue);
        volumeReportValidator.validatePhase1(detail, validateDate, exception);
        Assert.assertEquals("Should have 1", 1, exception.getViolations().size());
        ConstraintViolation violation = exception.getViolations().iterator().next();
        Assert.assertEquals("Area required error should be present", "error.message.volume.report.values.should.be.non.negative", violation.getField());
    }
    @Test
    public void given_null_matrixUsed_when_validate_matrixUsed_message_should_be_present() {
        Date validateDate = new Date();
        ConstraintException exception = new ConstraintException("Test exception");
        VolumeReportDetail detail = getVolumeReportDetail(true, true, false);
        initializePhase1(detail, validValue, validValue, null);
        volumeReportValidator.validatePhase1(detail, validateDate, exception);
        Assert.assertEquals("Should have 1", 1, exception.getViolations().size());
        ConstraintViolation violation = exception.getViolations().iterator().next();
        Assert.assertEquals("Area required error should be present", "error.message.volume.report.matrix.seed.used.required", violation.getField());
    }

    @Test
    public void given_negative_matrixUsed_when_validate_matrixUsed_message_should_be_present() {
        Date validateDate = new Date();
        ConstraintException exception = new ConstraintException("Test exception");
        VolumeReportDetail detail = getVolumeReportDetail(true, true, false);
        initializePhase1(detail, validValue, validValue, negativeValue);
        volumeReportValidator.validatePhase1(detail, validateDate, exception);
        Assert.assertEquals("Should have 1", 1, exception.getViolations().size());
        ConstraintViolation violation = exception.getViolations().iterator().next();
        Assert.assertEquals("Area required error should be present", "error.message.volume.report.values.should.be.non.negative", violation.getField());
    }

    @Test
    public void given_null_ownUsed_when_validate_ownUsed_message_should_be_present() {
        Date validateDate = new Date();
        ConstraintException exception = new ConstraintException("Test exception");
        VolumeReportDetail detail = getVolumeReportDetail(true, true, false);
        initializePhase1(detail, validValue, null, validValue);
        volumeReportValidator.validatePhase1(detail, validateDate, exception);
        Assert.assertEquals("Should have 1", 1, exception.getViolations().size());
        ConstraintViolation violation = exception.getViolations().iterator().next();
        Assert.assertEquals("Area required error should be present", "error.message.volume.report.own.seed.used.required", violation.getField());
    }

    @Test
    public void given_null_values_when_status_is_reported_should_have_3_violations() {
        Date validateDate = new Date();
        ConstraintException exception = new ConstraintException("Test exception");
        VolumeReportDetail detail = getVolumeReportDetail(true, true, false);
        initializePhase1(detail, null, null, null);
        detail.setVolumeReportDetailPhase1Status(VolumeReportStatus.REPORTED);
        volumeReportValidator.validatePhase1(detail, validateDate, exception);
        Assert.assertEquals("Should have 3", 3, exception.getViolations().size());
    }

    @Test
    public void given_negative_ownUsed_when_validate_ownUsed_message_should_be_present() {
        Date validateDate = new Date();
        ConstraintException exception = new ConstraintException("Test exception");
        VolumeReportDetail detail = getVolumeReportDetail(true, true, false);
        initializePhase1(detail, validValue, negativeValue, validValue);
        volumeReportValidator.validatePhase1(detail, validateDate, exception);
        Assert.assertEquals("Should have 1", 1, exception.getViolations().size());
        ConstraintViolation violation = exception.getViolations().iterator().next();
        Assert.assertEquals("Area required error should be present", "error.message.volume.report.values.should.be.non.negative", violation.getField());
    }

    @Test
    public void given_enteredArea_and_ownUsed_null_value_when_status_is_reported_should_have_2_violations() {
        Date validateDate = new Date();
        ConstraintException exception = new ConstraintException("Test exception");
        VolumeReportDetail detail = getVolumeReportDetail(true, true, false);
        initializePhase1(detail, null, null, validValue);
        detail.setVolumeReportDetailPhase1Status(VolumeReportStatus.REPORTED);
        volumeReportValidator.validatePhase1(detail, validateDate, exception);
        Assert.assertEquals("Should have 2", 2, exception.getViolations().size());
    }
    
    @Test
    public void given_ownUsed_and_matrixUsed_null_value_when_status_is_reported_should_have_2_violations() {
    	Date validateDate = new Date();
    	ConstraintException exception = new ConstraintException("Test exception");
    	VolumeReportDetail detail = getVolumeReportDetail(true, true, false);
    	initializePhase1(detail, validValue, null, null);
    	detail.setVolumeReportDetailPhase1Status(VolumeReportStatus.REPORTED);
    	volumeReportValidator.validatePhase1(detail, validateDate, exception);
    	Assert.assertEquals("Should have 2", 2, exception.getViolations().size());
    }
    
    @Test
    public void given_report_with_null_values_and_status_notReported_should_have_no_warnings() {
    	Date validateDate = new Date();
    	ConstraintException exception = new ConstraintException("Test exception");
    	VolumeReportDetail detail = getVolumeReportDetail(true, true, false);
    	initializePhase1(detail, null, null, null);
    	volumeReportValidator.validatePhase1(detail, validateDate, exception);
    	Assert.assertEquals("Should have 0", 0, exception.getViolations().size());
    }
    
    @Test
    public void given_enteredArea_and_matrixUsed_null_value_when_status_is_reported_should_have_2_violations() {
    	Date validateDate = new Date();
    	ConstraintException exception = new ConstraintException("Test exception");
    	VolumeReportDetail detail = getVolumeReportDetail(true, true, false);
    	initializePhase1(detail, null, validValue, null);
    	detail.setVolumeReportDetailPhase1Status(VolumeReportStatus.REPORTED);
    	volumeReportValidator.validatePhase1(detail, validateDate, exception);
    	Assert.assertEquals("Should have 2", 2, exception.getViolations().size());
    }
    
    @Test
    public void given_header_with_one_detail_and_valid_phase1_validation_should_pass_with_no_errors() throws ConstraintException {
        Date validateDate = new Date();
//        ConstraintException exception = new ConstraintException("Test exception");
        VolumeReportDetail detail = getVolumeReportDetail(true, true, false);
        detail.setProductivity(BigInteger.TEN);
        initializePhase1(detail, validValue, validValue, validValue);
        List<VolumeReportDetail> details = new ArrayList<VolumeReportDetail>();
        details.add(detail);
        volumeReportValidator.validate(details,validateDate);
    }

    @Test(expected = ConstraintException.class)
    public void given_header_with_one_detail_and_invalid_phase1_should_throw_exception() throws ConstraintException {
        Date validateDate = new Date();
//        ConstraintException exception = new ConstraintException("Test exception");
        VolumeReportDetail detail = getVolumeReportDetail(true, true, false);
        initializePhase1(detail, negativeValue, null, validValue);
        List<VolumeReportDetail> details = new ArrayList<VolumeReportDetail>();
        details.add(detail);
        volumeReportValidator.validate(details,validateDate);
    }
}
