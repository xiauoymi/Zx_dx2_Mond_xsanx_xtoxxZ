/**
 * 
 */
package com.monsanto.brazilvaluecapture.multiplier.revenue.service.parser;

import com.monsanto.brazilvaluecapture.core.base.model.bean.Company;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Crop;
import com.monsanto.brazilvaluecapture.core.base.model.bean.DocumentType;
import com.monsanto.brazilvaluecapture.core.base.model.bean.OperationalYear;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Customer;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Technology;
import com.monsanto.brazilvaluecapture.core.foundation.test.AbstractServiceIntegrationTests;
import com.monsanto.brazilvaluecapture.core.foundation.test.dbunit.DbUnitHelper;
import com.monsanto.brazilvaluecapture.core.io.ImportedException;
import com.monsanto.brazilvaluecapture.core.user.model.bean.UserDecorator;
import com.monsanto.brazilvaluecapture.multiplier.cultivar.model.bean.Cultivar;
import com.monsanto.brazilvaluecapture.multiplier.itsclass.model.bean.ItsClass;
import com.monsanto.brazilvaluecapture.multiplier.obtainer.model.bean.Obtainer;
import com.monsanto.brazilvaluecapture.multiplier.revenue.model.bean.BillingGermplasmCsvImportedLine;
import com.monsanto.brazilvaluecapture.multiplier.revenue.model.bean.VolumeCommercializedType;
import com.monsanto.brazilvaluecapture.multiplier.volumereport.model.bean.VolumeReportDetail;
import com.monsanto.brazilvaluecapture.multiplier.volumereport.model.bean.VolumeReportStatus;
import com.monsanto.brazilvaluecapture.seedsale.harvest.model.bean.Harvest;
import junit.framework.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

/**
 * @author andregc
 *
 */
public class BillingGermplasmCsvParser_AT extends AbstractServiceIntegrationTests {

	@Autowired
	BillingGermplasmCsvParser parser;
	
	private Customer customer;
	private Customer matrix;
	private Company company;
	private UserDecorator user;
	private Crop crop;
	private Technology technology;
	private Technology technology2;
	private OperationalYear operationalYear;
	private Harvest harvest;
	private Obtainer obtainer;
	private ItsClass itsClass;
	private Cultivar cultivar;
	private VolumeCommercializedType volumeCommercializedType;

	private DocumentType customerDocumentType;

	private DocumentType matrixDocumentType;

	private VolumeReportDetail detail;
	
	@Before
	public void init() {
        DbUnitHelper.setup("classpath:data/multiplier/basic-fixture.xml", "classpath:data/multiplier/revenue-multiplier-dataset.xml");
        
        detail = (VolumeReportDetail) getSession().get(VolumeReportDetail.class, 991000008L);
		customer = (Customer) getSession().get(Customer.class, 900000003L);
		customerDocumentType = customer.getDocument().getDocumentType();
		matrix = (Customer) getSession().get(Customer.class, 900000004L);
		matrixDocumentType = matrix.getDocument().getDocumentType();
		company = (Company) getSession().get(Company.class, 900000001L);
		crop = (Crop) getSession().get(Crop.class, 900000001L);
		operationalYear = (OperationalYear) getSession().get(OperationalYear.class, 900000002L);
		harvest = (Harvest) getSession().get(Harvest.class, 900000001L);
		technology = (Technology) getSession().get(Technology.class, 900000001L);
		technology2 = (Technology) getSession().get(Technology.class, 900000003L);
		obtainer = (Obtainer) getSession().get(Obtainer.class, 991000001L);
		cultivar = (Cultivar) getSession().get(Cultivar.class, 991000001L);
		itsClass = (ItsClass) getSession().get(ItsClass.class, 991000001L);
		volumeCommercializedType = VolumeCommercializedType.ONE;
		
		initUser();
	}

	private void initUser() {
		List<Company> contextCompanies = new ArrayList<Company>();
		contextCompanies.add(company);
		user = Mockito.mock(UserDecorator.class);
		Mockito.when(user.getAllCompaniesForContext()).thenReturn(contextCompanies);
		List<Crop> contextCrops = new ArrayList<Crop>();
		contextCrops.add(crop);
		Mockito.when(user.getAllCropForContext()).thenReturn(contextCrops);
	}
	
	@Test
	public void given_a_valid_file_when_parse_should_not_have_warnings() {
		BillingGermplasmCsvImportedLine line = createValidLine(technology.getDescription());
        BillingGermplasmCsvImportedFile file = createFileFor(line);
        parser.proccessFile(file);

        Assert.assertEquals("Should not warnings", 0, file.countWarnings());
		Assert.assertEquals(customerDocumentType.getDescription(), line.getCustomerDocumentType().getDescription());
		Assert.assertEquals(customer, line.getCustomer());
		Assert.assertEquals(matrixDocumentType.getDescription(), line.getMatrixDocumentType().getDescription());
		Assert.assertEquals(matrix, line.getMatrix());
		Assert.assertEquals(company, line.getCompany());
		Assert.assertEquals(crop, line.getCrop());
		Assert.assertEquals(operationalYear, line.getOperationalYear());
		Assert.assertEquals(harvest, line.getHarvest());
		Assert.assertEquals(technology, line.getTechnology());
		Assert.assertEquals(obtainer, line.getObtainer());
		Assert.assertEquals(cultivar, line.getCultivar());
		Assert.assertEquals(itsClass, line.getItsClass());
		Assert.assertEquals(volumeCommercializedType, line.getVolumeCommercializedType());
		Assert.assertEquals(detail, line.getVolumeReportDetail());
	}
	
	@Test
	public void given_a_valid_file_that_overwrite_past_imported_lines_when_parse_should_not_have_warnings() {
		BillingGermplasmCsvImportedLine line = createValidLine(technology.getDescription());
		line.setOverwriteImported(true);
		line.setVolumeCommercializedTypeNumber(3);
		BillingGermplasmCsvImportedFile file = createFileFor(line);
		parser.proccessFile(file);
		
		Assert.assertEquals("Should not warnings", 0, file.countWarnings());
	}
	
	@Test
	public void given_a_valid_file_with_VolumeCommercializedTypeNumber_2_when_parse_should_not_have_warnings() {
		BillingGermplasmCsvImportedLine line = createValidLine(technology.getDescription());
		line.setVolumeCommercializedTypeNumber(2);
		BillingGermplasmCsvImportedFile file = createFileFor(line);
		parser.proccessFile(file);
		
		Assert.assertEquals("Should not warnings", 0, file.countWarnings());
	}
	
	@Test
	public void given_a_valid_file_with_VolumeCommercializedTypeNumber_3_when_parse_should_not_have_warnings() {
		BillingGermplasmCsvImportedLine line = createValidLine(technology.getDescription());
		line.setVolumeCommercializedTypeNumber(3);
		BillingGermplasmCsvImportedFile file = createFileFor(line);
		parser.proccessFile(file);
		
		Assert.assertEquals("Should not warnings", 0, file.countWarnings());
	}
	
	@Test
	public void given_a_valid_file_with_two_duplicated_lines_when_parse_should_have_warnings() {
		BillingGermplasmCsvImportedLine line = createValidLine(technology.getDescription());
		BillingGermplasmCsvImportedLine line2 = createValidLine(technology.getDescription());
		line2.setLine(2);
		BillingGermplasmCsvImportedLine line3 = createValidLine(technology.getDescription());
		line3.setLine(3);
		BillingGermplasmCsvImportedFile file = createFileFor(line, line2, line3);
		parser.proccessFile(file);
		
		Assert.assertEquals("Should have one warning", 1, file.countWarnings());
	}
	
	@Test
	public void given_a_line_without_customerDocumentType_when_parse_file_should_have_one_warning() {
		BillingGermplasmCsvImportedLine line = createValidLine(technology.getDescription());
		line.setCustomerDocumentTypeDescription(null);
		
		BillingGermplasmCsvImportedFile file = createFileFor(line);
		parser.proccessFile(file);
		
		assertOneWarningForMessage("error.billingGermplasm.import.customer.documentType.required", file);
	}
	
	@Test
	public void given_a_line_without_customerDocument_when_parse_file_should_have_one_warning() {
		BillingGermplasmCsvImportedLine line = createValidLine(technology.getDescription());
		line.setCustomerDocument(null);

		BillingGermplasmCsvImportedFile file = createFileFor(line);		
		parser.proccessFile(file);

		assertOneWarningForMessage("error.billingGermplasm.import.customer.document.required", file);
	}
	
	@Test
	public void given_a_line_without_matrixDocumentType_when_parse_file_should_have_one_warning() {
		BillingGermplasmCsvImportedLine line = createValidLine(technology.getDescription());
		line.setMatrixDocumentTypeDescription(null);
		
		BillingGermplasmCsvImportedFile file = createFileFor(line);
		parser.proccessFile(file);
		
		assertOneWarningForMessage("error.billingGermplasm.import.matrix.documentType.required", file);
	}
	
	@Test
	public void given_a_line_without_matrixDocument_when_parse_file_should_have_one_warning() {
		BillingGermplasmCsvImportedLine line = createValidLine(technology.getDescription());
		line.setMatrixDocument(null);

		BillingGermplasmCsvImportedFile file = createFileFor(line);		
		parser.proccessFile(file);

		assertOneWarningForMessage("error.billingGermplasm.import.matrix.document.required", file);
	}
	
	@Test
	public void given_a_line_without_companyDescription_when_parse_file_should_have_one_warning() {
		BillingGermplasmCsvImportedLine line = createValidLine(technology.getDescription());
		line.setCompanyDescription(null);

		BillingGermplasmCsvImportedFile file = createFileFor(line);		
		parser.proccessFile(file);

		assertOneWarningForMessage("error.billingGermplasm.import.company.required", file);
	}
	
	@Test
	public void given_a_line_without_cropDescription_when_parse_file_should_have_one_warning() {
		BillingGermplasmCsvImportedLine line = createValidLine(technology.getDescription());
		line.setCropDescription(null);

		BillingGermplasmCsvImportedFile file = createFileFor(line);		
		parser.proccessFile(file);

		assertOneWarningForMessage("error.billingGermplasm.import.crop.required", file);
	}
	
	@Test
	public void given_a_line_without_operationalYearDescription_when_parse_file_should_have_one_warning() {
		BillingGermplasmCsvImportedLine line = createValidLine(technology.getDescription());
		line.setOperationalYearDescription(null);

		BillingGermplasmCsvImportedFile file = createFileFor(line);		
		parser.proccessFile(file);

		assertOneWarningForMessage("error.billingGermplasm.import.operationalYear.required", file);
	}
	
	@Test
	public void given_a_line_without_harvestDescription_when_parse_file_should_have_one_warning() {
		BillingGermplasmCsvImportedLine line = createValidLine(technology.getDescription());
		line.setHarvestDescription(null);

		BillingGermplasmCsvImportedFile file = createFileFor(line);		
		parser.proccessFile(file);

		assertOneWarningForMessage("error.billingGermplasm.import.harvest.required", file);
	}
	
	@Test
	public void given_a_line_without_technologyDescription_when_parse_file_should_have_one_warning() {
		BillingGermplasmCsvImportedLine line = createValidLine(technology.getDescription());
		line.setTechnologyDescription(null);

		BillingGermplasmCsvImportedFile file = createFileFor(line);		
		parser.proccessFile(file);

		assertOneWarningForMessage("error.billingGermplasm.import.technology.required", file);
	}
	
	@Test
	public void given_a_line_without_obtainerDescription_when_parse_file_should_have_one_warning() {
		BillingGermplasmCsvImportedLine line = createValidLine(technology.getDescription());
		line.setObtainerDescription(null);

		BillingGermplasmCsvImportedFile file = createFileFor(line);
		parser.proccessFile(file);

		assertOneWarningForMessage("error.billingGermplasm.import.obtainer.required", file);
	}
	
	@Test
	public void given_a_line_without_cultivarDescription_when_parse_file_should_have_one_warning() {
		BillingGermplasmCsvImportedLine line = createValidLine(technology.getDescription());
		line.setCultivarDescription(null);

		BillingGermplasmCsvImportedFile file = createFileFor(line);
		parser.proccessFile(file);

		assertOneWarningForMessage("error.billingGermplasm.import.cultivar.required", file);
	}
	
	@Test
	public void given_a_line_without_classDescription_when_parse_file_should_have_one_warning() {
		BillingGermplasmCsvImportedLine line = createValidLine(technology.getDescription());
		line.setClassAbbreviation(null);

		BillingGermplasmCsvImportedFile file = createFileFor(line);
		parser.proccessFile(file);

		assertOneWarningForMessage("error.billingGermplasm.import.class.required", file);
	}
	
	@Test
	public void given_a_line_without_dueDate_when_parse_file_should_have_one_warning() {
		BillingGermplasmCsvImportedLine line = createValidLine(technology.getDescription());
		line.setDueDate(null);

		BillingGermplasmCsvImportedFile file = createFileFor(line);
		parser.proccessFile(file);

		assertOneWarningForMessage("error.billingGermplasm.import.dueDate.required", file);
	}
	
	@Test
	public void given_a_line_without_volumeCommercializedType_when_parse_file_should_have_one_warning() {
		BillingGermplasmCsvImportedLine line = createValidLine(technology.getDescription());
		line.setVolumeCommercializedTypeNumber(null);

		BillingGermplasmCsvImportedFile file = createFileFor(line);
		parser.proccessFile(file);

		assertOneWarningForMessage("error.billingGermplasm.import.volumeCommercializedType.required", file);
	}
	
	@Test
	public void given_a_line_without_volumeGermplasm_when_parse_file_should_have_one_warning() {
		BillingGermplasmCsvImportedLine line = createValidLine(technology.getDescription());
		line.setVolumeGermplasm(null);

		BillingGermplasmCsvImportedFile file = createFileFor(line);
		parser.proccessFile(file);

		assertOneWarningForMessage("error.billingGermplasm.import.volumeGermplasm.required", file);
	}

	@Test
	public void given_an_invalid_customerDocumentType_when_parse_file_should_have_one_warning() {
		BillingGermplasmCsvImportedLine line = createValidLine(technology.getDescription());
		line.setCustomerDocumentTypeDescription("INVALID DOCUMENT TYPE");

		BillingGermplasmCsvImportedFile file = createFileFor(line);
		parser.proccessFile(file);

		assertOneWarningForMessage("error.billingGermplasm.import.customer.documentType.invalid", file);
	}
	
	@Test
	public void given_an_duplicated_customer_without_sap_code_when_parse_file_should_have_one_warning() {
		BillingGermplasmCsvImportedLine line = createValidLine(technology.getDescription());
		line.setCustomerSAPCode(null);

		BillingGermplasmCsvImportedFile file = createFileFor(line);
		parser.proccessFile(file);

		assertOneWarningForMessage("error.billingGermplasm.import.customer.duplicated", file);
	}
	
	@Test
	public void given_a_valid_but_inexistent_customerDocument_when_parse_file_should_have_one_warning() {
		BillingGermplasmCsvImportedLine line = createValidLine(technology.getDescription());
		line.setCustomerDocument("11.490.357/0001-11");

		BillingGermplasmCsvImportedFile file = createFileFor(line);
		parser.proccessFile(file);

		assertOneWarningForMessage("error.billingGermplasm.import.customer.invalid", file);
	}
	
	@Test
	public void given_an_invalid_document_when_parse_file_should_have_one_warning() {
		BillingGermplasmCsvImportedLine line = createValidLine(technology.getDescription());
		line.setCustomerDocument("INVALID DOCUMENT");

		BillingGermplasmCsvImportedFile file = createFileFor(line);
		parser.proccessFile(file);

		assertOneWarningForMessage("error.billingGermplasm.import.customer.document.invalid", file);
	}

	@Test
	public void given_an_invalid_matrixDocumentType_when_parse_file_should_have_one_warning() {
		BillingGermplasmCsvImportedLine line = createValidLine(technology.getDescription());
		line.setMatrixDocumentTypeDescription("INVALID DOCUMENT TYPE");

		BillingGermplasmCsvImportedFile file = createFileFor(line);
		parser.proccessFile(file);

		assertOneWarningForMessage("error.billingGermplasm.import.matrix.documentType.invalid", file);
	}
	
	@Test
	public void given_an_duplicated_matrix_without_sap_code_when_parse_file_should_have_one_warning() {
		BillingGermplasmCsvImportedLine line = createValidLine(technology.getDescription());
		Customer customer = (Customer) getSession().get(Customer.class, 900000004L);
		line.setMatrixDocumentTypeDescription(customer.getDocument().getDocumentTypeDescription());
		line.setMatrixDocument(customer.getDocumentValue());
		line.setMatrixSAPCode(null);

		BillingGermplasmCsvImportedFile file = createFileFor(line);
		parser.proccessFile(file);

		assertOneWarningForMessage("error.billingGermplasm.import.matrix.duplicated", file);
	}
	
	@Test
	public void given_a_valid_but_inexistent_matrixDocument_when_parse_file_should_have_one_warning() {
		BillingGermplasmCsvImportedLine line = createValidLine(technology.getDescription());
		line.setMatrixDocument("11.490.357/0001-11");

		BillingGermplasmCsvImportedFile file = createFileFor(line);
		parser.proccessFile(file);

		assertOneWarningForMessage("error.billingGermplasm.import.matrix.invalid", file);
	}
	
	@Test
	public void given_an_invalid_matrixDocument_when_parse_file_should_have_one_warning() {
		BillingGermplasmCsvImportedLine line = createValidLine(technology.getDescription());
		line.setMatrixDocument("INVALID DOCUMENT");

		BillingGermplasmCsvImportedFile file = createFileFor(line);
		parser.proccessFile(file);

		assertOneWarningForMessage("error.billingGermplasm.import.matrix.document.invalid", file);
	}
	
	@Test
	public void given_an_invalid_company_when_parse_file_should_have_one_warning() {
		BillingGermplasmCsvImportedLine line = createValidLine(technology.getDescription());
		line.setCompanyDescription("INVALID COMPANY");

		BillingGermplasmCsvImportedFile file = createFileFor(line);
		parser.proccessFile(file);

		assertOneWarningForMessage("error.billingGermplasm.import.company.invalid", file);
	}
	
	@Test
	public void given_a_company_that_user_dont_have_access_when_parse_file_should_have_one_warning() {
		BillingGermplasmCsvImportedLine line = createValidLine(technology.getDescription());
		Company company = (Company) getSession().get(Company.class, 900000002L);
		line.setCompanyDescription(company.getDescription());

		BillingGermplasmCsvImportedFile file = createFileFor(line);
		parser.proccessFile(file);

		assertOneWarningForMessage("error.billingGermplasm.import.company.notAllowed", file);
		Assert.assertNull("Company should be null", line.getCompany());
	}
	
	@Test
	public void given_an_invalid_crop_when_parse_file_should_have_one_warning() {
		BillingGermplasmCsvImportedLine line = createValidLine(technology.getDescription());
		line.setCropDescription("INVALID CROP");

		BillingGermplasmCsvImportedFile file = createFileFor(line);
		parser.proccessFile(file);

		assertOneWarningForMessage("error.billingGermplasm.import.crop.invalid", file);
	}
	
	@Test
	public void given_a_crop_that_user_dont_have_access_when_parse_file_should_have_one_warning() {
		BillingGermplasmCsvImportedLine line = createValidLine(technology.getDescription());
		Crop crop = (Crop) getSession().get(Crop.class, 900000002L);
		line.setCropDescription(crop.getDescription());

		BillingGermplasmCsvImportedFile file = createFileFor(line);
		parser.proccessFile(file);

		assertOneWarningForMessage("error.billingGermplasm.import.crop.notAllowed", file);
	}
	
	@Test
	public void given_an_invalid_operational_year_when_parse_file_should_have_one_warning() {
		BillingGermplasmCsvImportedLine line = createValidLine(technology.getDescription());
		line.setOperationalYearDescription("INEXISTENT OPERATIONAL YEAR");

		BillingGermplasmCsvImportedFile file = createFileFor(line);
		parser.proccessFile(file);
		
		assertOneWarningForMessage("error.billingGermplasm.import.operationalYear.invalid", file);
	}

	@Test
	public void given_an_invalid_harvest_description_when_parse_file_should_have_one_warning() {
		BillingGermplasmCsvImportedLine line = createValidLine(technology.getDescription());
		line.setHarvestDescription("INEXISTENT HARVEST");

		BillingGermplasmCsvImportedFile file = createFileFor(line);
		parser.proccessFile(file);

		assertOneWarningForMessage("error.billingGermplasm.import.harvest.invalid", file);
	}

	@Test
	public void given_a_harvest_of_another_operationalYear_when_parse_file_should_have_one_warning() {
		BillingGermplasmCsvImportedLine line = createValidLine(technology.getDescription());
		
		OperationalYear operationalYear = (OperationalYear) getSession().get(OperationalYear.class, 900000001L);
		line.setOperationalYearDescription(operationalYear.getYear());
		
		BillingGermplasmCsvImportedFile file = createFileFor(line);
		parser.proccessFile(file);

		assertOneWarningForMessage("error.billingGermplasm.import.harvest.operationalYear.invalid", file);
	}
	
	@Test
	public void given_an_invalid_technology_when_parse_file_should_have_one_warning() {
		BillingGermplasmCsvImportedLine line = createValidLine(technology.getDescription());
		line.setTechnologyDescription("INVALID TECHNOLOGY");

		BillingGermplasmCsvImportedFile file = createFileFor(line);
		parser.proccessFile(file);

		assertOneWarningForMessage("error.billingGermplasm.import.technology.invalid", file);
	}
	
	@Test 
	public void given_an_invalid_obtainerDescription_when_parse_file_should_have_one_warning() {
		BillingGermplasmCsvImportedLine line = createValidLine(technology.getDescription());
		line.setObtainerDescription("INEXISTENT OBTAINER");

		BillingGermplasmCsvImportedFile file = createFileFor(line);
		parser.proccessFile(file);

		assertOneWarningForMessage("error.billingGermplasm.import.obtainer.invalid", file);
	}
	
	@Test
	public void given_an_invalid_cultivar_description_when_parse_file_should_have_one_warning() {
		BillingGermplasmCsvImportedLine line = createValidLine(technology.getDescription());
		line.setCultivarDescription("INEXISTENT CULTIVAR DESCRIPTION");
		
		BillingGermplasmCsvImportedFile file = createFileFor(line);
		parser.proccessFile(file);

		assertOneWarningForMessage("error.billingGermplasm.import.cultivar.invalid", file);
	}
	
	@Test 
	public void given_a_valid_cultivar_of_another_obtainer_when_parse_file_should_have_one_warning() {
		BillingGermplasmCsvImportedLine line = createValidLine(technology.getDescription());
		Obtainer anotherObtainer = (Obtainer) getSession().get(Obtainer.class, 991000002L);
		line.setObtainerDescription(anotherObtainer.getDescription());
		
		BillingGermplasmCsvImportedFile file = createFileFor(line);
		parser.proccessFile(file);

		assertOneWarningForMessage("error.billingGermplasm.import.cultivar.obtainer.invalid", file);
	}
	
	@Test 
	public void given_an_invalid_classAbbreviation_when_parse_file_should_have_one_warning() {
		BillingGermplasmCsvImportedLine line = createValidLine(technology.getDescription());
		line.setClassAbbreviation("INVALID CLASS ABREVIATION");
		
		BillingGermplasmCsvImportedFile file = createFileFor(line);
		parser.proccessFile(file);

		assertOneWarningForMessage("error.billingGermplasm.import.class.invalid", file);
	}
	
	@Test
	public void given_a_dueDate_in_past_when_parse_file_should_have_one_warning() {
		BillingGermplasmCsvImportedLine line = createValidLine(technology.getDescription());
		
		Calendar calendar = Calendar.getInstance();
		calendar.add(Calendar.MONTH, -1);
		line.setDueDate(calendar.getTime());
		
		BillingGermplasmCsvImportedFile file = createFileFor(line);
		parser.proccessFile(file);

		assertOneWarningForMessage("error.billingGermplasm.import.dueDate.invalid", file);
	}
	
	@Test
	public void given_a_dueDate_equals_actual_date_when_parse_file_should_have_one_warning() {
		BillingGermplasmCsvImportedLine line = createValidLine(technology.getDescription());
		line.setDueDate(new Date());
		
		BillingGermplasmCsvImportedFile file = createFileFor(line);
		parser.proccessFile(file);

		assertOneWarningForMessage("error.billingGermplasm.import.dueDate.invalid", file);
	}
	
	@Test
	public void given_an_invalid_volumeCommercializedType_when_parse_file_should_have_one_warning() {
		BillingGermplasmCsvImportedLine line = createValidLine(technology.getDescription());
		line.setVolumeCommercializedTypeNumber(5);
		
		BillingGermplasmCsvImportedFile file = createFileFor(line);
		parser.proccessFile(file);

		assertOneWarningForMessage("error.billingGermplasm.import.volumeCommercializedType.invalid", file);
	}
	
	@Test
	public void given_a_negative_volumeGermplasm_when_parse_file_should_have_one_warning() {
		BillingGermplasmCsvImportedLine line = createValidLine(technology.getDescription());
		line.setVolumeGermplasm(new BigDecimal("-5"));
		
		BillingGermplasmCsvImportedFile file = createFileFor(line);
		parser.proccessFile(file);

		assertOneWarningForMessage("error.billingGermplasm.import.volumeGermplasm.invalid", file);
	}
	
	@Test
	public void given_a_line_without_detail_when_parse_file_should_have_one_warning() {
		BillingGermplasmCsvImportedLine line = createValidLine(technology.getDescription());
		Obtainer obtainer = (Obtainer) getSession().get(Obtainer.class, 991000002L);
		line.setObtainerDescription(obtainer.getDescription());
		Cultivar cultivar = (Cultivar) getSession().get(Cultivar.class, 991000004L);
		line.setCultivarDescription(cultivar.getDescription());
		
		BillingGermplasmCsvImportedFile file = createFileFor(line);
		parser.proccessFile(file);

		assertOneWarningForMessage("error.billingGermplasm.import.volumeReport.notFound", file);
	}
	
	@Test
	public void given_a_detail_with_volumeCommercialized_not_available_when_parse_file_should_have_one_warning() {
		detail.getVolumeCommercialized1().setStatus(VolumeReportStatus.WAITING_REPORT);
		saveAndFlush(detail);
		
		BillingGermplasmCsvImportedLine line = createValidLine(technology.getDescription());
		
		BillingGermplasmCsvImportedFile file = createFileFor(line);
		parser.proccessFile(file);

		assertOneWarningForMessage("error.billingGermplasm.import.volumeCommercialized.notAvailable", file);
	}
	
	@Test
	public void given_a_line_that_overwrite_imported_and_dont_have_past_imported_revenueGermplasm_when_parse_file_should_have_one_warning() {
		BillingGermplasmCsvImportedLine line = createValidLine(technology.getDescription());
		line.setOverwriteImported(true);
		line.setVolumeCommercializedTypeNumber(1);
		
		BillingGermplasmCsvImportedFile file = createFileFor(line);
		parser.proccessFile(file);

		assertOneWarningForMessage("error.billingGermplasm.import.germplasmRevenue.notFound", file);
	}
	
	@Test
	public void given_a_line_that_overwrite_imported_and_have_imported_revenueGermplasm_with_status_not_equals_open_when_parse_file_should_have_one_warning() {
		BillingGermplasmCsvImportedLine line = createValidLine(technology.getDescription());
		line.setOverwriteImported(true);
		line.setVolumeCommercializedTypeNumber(2);
		
		BillingGermplasmCsvImportedFile file = createFileFor(line);
		parser.proccessFile(file);

		assertOneWarningForMessage("error.billingGermplasm.import.germplasmRevenue.status.invalid", file);
	}
	
	@Test
	public void given_one_cultivarIntacta_when_i_try_to_import_csvLine_with_RR_technology_should_have_one_warning() {
		BillingGermplasmCsvImportedLine line = createValidLine(technology2.getDescription());
		BillingGermplasmCsvImportedFile file = createFileFor(line);
		
		parser.proccessFile(file);
		
		assertOneWarningForMessage("error.billingGermplasm.import.cultivar.technology.dont.match", file);
	}
	
	private void assertOneWarningForMessage(String warningMessage, BillingGermplasmCsvImportedFile file) {
		Assert.assertEquals("Should have one warning", 1, file.countWarnings());
		ImportedException businessException = (ImportedException) file.getWarningList().get(0);
		Assert.assertEquals("Should have only one message", 1, businessException.getErrorMessageKeys().size());
		Assert.assertEquals(warningMessage, businessException.getErrorMessageKeys().get(0));
	}

	private BillingGermplasmCsvImportedLine createValidLine(String technologyDescription) {
		Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.MONTH, 1);
		Date futureDate = calendar.getTime();
		
		BillingGermplasmCsvImportedLine line = createImportedLine(
				false,
				customerDocumentType.getDescription(),
				customer.getDocumentValue(),
				customer.getCustomerSAPCode(),
				matrixDocumentType.getDescription(),
				matrix.getDocumentValue(),
				matrix.getCustomerSAPCode(),
				company.getDescription(),
				crop.getDescription(),
				operationalYear.getYear(),
				harvest.getDescription(),
				technologyDescription,
				obtainer.getDescription(), 
				cultivar.getDescription(),
				itsClass.getAbbreviation(),
				futureDate,
				volumeCommercializedType.getValue(), BigDecimal.ONE, "Importacao referente safra 2013", 1);
		return line;
	}

	private BillingGermplasmCsvImportedLine createImportedLine(
			Boolean overwrite, String customerDocumentTypeDescription,
			String customerDocument, String customerSAPCode,
			String matrixDocumentTypeDescription, String matrixDocument,
			String matrixSAPCode, String companyDescription,
			String cropDescription, String operationalYearDescription,
			String harvestDescription, String technologyDescription,
			String obtainerDescription, String cultivarDescription, String classAbbreviation,
			Date dueDate, Integer volumeCommercializedType,
			BigDecimal volumeGermplasm, String billingGermplasmNote, int lineNumber) {
		BillingGermplasmCsvImportedLine line = new BillingGermplasmCsvImportedLine();
		line.setOverwriteImported(overwrite);
		line.setCustomerDocumentTypeDescription(customerDocumentTypeDescription);
		line.setCustomerDocument(customerDocument);
		line.setCustomerSAPCode(customerSAPCode);
		line.setMatrixDocumentTypeDescription(matrixDocumentTypeDescription);
		line.setMatrixDocument(matrixDocument);
		line.setMatrixSAPCode(matrixSAPCode);
		line.setCompanyDescription(companyDescription);
		line.setCropDescription(cropDescription);
		line.setOperationalYearDescription(operationalYearDescription);
		line.setHarvestDescription(harvestDescription);
		line.setTechnologyDescription(technologyDescription);
		line.setObtainerDescription(obtainerDescription);
		line.setCultivarDescription(cultivarDescription);
		line.setClassAbbreviation(classAbbreviation);
		line.setDueDate(dueDate);
		line.setVolumeCommercializedTypeNumber(volumeCommercializedType);
		line.setVolumeGermplasm(volumeGermplasm);
		line.setBillingGermplasmNote(billingGermplasmNote);
		line.setLine(lineNumber);
		return line;
	}

	private BillingGermplasmCsvImportedFile createFileFor(BillingGermplasmCsvImportedLine... lines) {
		BillingGermplasmCsvImportedFile file = new BillingGermplasmCsvImportedFile();
		List<BillingGermplasmCsvImportedLine> entities = new ArrayList<BillingGermplasmCsvImportedLine>();
		for (BillingGermplasmCsvImportedLine line : lines) {
			entities.add(line);
		}
		file.setAllEntities(entities);
		file.setUser(user);
		
		return file;
	}
}
