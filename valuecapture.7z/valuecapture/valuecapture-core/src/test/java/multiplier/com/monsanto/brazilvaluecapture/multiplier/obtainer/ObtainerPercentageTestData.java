package com.monsanto.brazilvaluecapture.multiplier.obtainer;

import com.monsanto.brazilvaluecapture.core.foundation.RandomTestData;
import com.monsanto.brazilvaluecapture.multiplier.obtainer.model.bean.Obtainer;
import com.monsanto.brazilvaluecapture.multiplier.obtainer.model.bean.ObtainerPercentage;

import java.util.Date;

/**
 * Created by IntelliJ IDEA.
 * User: sgovi
 * Date: 8/28/2014
 * Time: 9:21 AM
 */
public class ObtainerPercentageTestData {

    public static ObtainerPercentage createActiveObtainerPercentage(Obtainer obtainer) {
        return createActiveObtainerPercentage(RandomTestData.createRandomString(10), obtainer);
    }

    public static ObtainerPercentage createActiveObtainerPercentage(String description, Obtainer obtainer) {
        ObtainerPercentage obtainerPercentage = new ObtainerPercentage();
        obtainerPercentage.setId(20l);
        obtainerPercentage.setUserName("TESTUSER");
        obtainerPercentage.setPercentage(23.34);
        obtainerPercentage.setTransactionType(obtainer.getDescription());
        obtainerPercentage.setObtainer(obtainer);
        obtainerPercentage.setCreationDate(new Date());
        obtainerPercentage.setTransTypeStatus(obtainer.getStatus());
        return obtainerPercentage;
    }
}
