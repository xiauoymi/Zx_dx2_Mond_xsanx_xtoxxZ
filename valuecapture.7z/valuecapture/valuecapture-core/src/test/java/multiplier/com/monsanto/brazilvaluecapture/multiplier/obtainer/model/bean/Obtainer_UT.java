package com.monsanto.brazilvaluecapture.multiplier.obtainer.model.bean;

import com.monsanto.brazilvaluecapture.core.base.model.bean.Company;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Country;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Crop;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Document;
import com.monsanto.brazilvaluecapture.core.foundation.model.bean.StatusEnum;
import org.junit.Test;

import static org.fest.assertions.Assertions.assertThat;

public class Obtainer_UT {
    @Test
    public void testObtainerCreatesInstanceWithrevenueRecognitionExcludedEqualToFalse() {
        Obtainer obtainer = new Obtainer();

        assertThat(obtainer.getRevenueRecognitionExcluded()).isFalse();
    }

    @Test
    public void testGetRevenueRecognitionExcludedReturnFalse_WhenRevenueRecognitionExcludedIsSetToNull() {
        Obtainer obtainer = new Obtainer();

        obtainer.setRevenueRecognitionExcluded(null);

        assertThat(obtainer.getRevenueRecognitionExcluded()).isFalse();
    }


    @Test
   	public void testEquals_returnsTue_whenAreTheSame() {
        Obtainer obtainer = new Obtainer();
        assertThat(obtainer.equals(obtainer)).isTrue();
    }

    @Test
   	public void testEquals_returnsFalse_whenAreDifferentType() {
        Obtainer obtainer = new Obtainer();
        assertThat(obtainer.equals("string")).isFalse();
        assertThat(obtainer.equals(null)).isFalse();
    }

    @Test
   	public void testEquals_returnsFalse_whenHaveDifferentAttributes() {
        Obtainer obtainer;
        Obtainer anotherObtainer;

        Crop crop1 = new Crop("crop1", new Company(), new Country());
        Crop crop2 = new Crop("crop2", new Company(), new Country());

        String description1 = "description1";
        String description2 = "description2";

        // only description
        obtainer = new Obtainer(description1, null, null);
        anotherObtainer = new Obtainer(description2, null, null);
        assertThat(obtainer.equals(anotherObtainer)).isFalse();

        // only crop
        obtainer = new Obtainer(null, null, crop1);
        anotherObtainer = new Obtainer(null, null, crop2);
        assertThat(obtainer.equals(anotherObtainer)).isFalse();

        // description and crop
        obtainer = new Obtainer(description1, null, crop1);
        anotherObtainer = new Obtainer(description2, null, crop2);
        assertThat(obtainer.equals(anotherObtainer)).isFalse();

        // mixed
        obtainer = new Obtainer(description1, null, null);
        anotherObtainer = new Obtainer(null, null, crop1);
        assertThat(obtainer.equals(anotherObtainer)).isFalse();

        // mixed
        obtainer = new Obtainer(null, null, crop1);
        anotherObtainer = new Obtainer(description1, null, null);
        assertThat(obtainer.equals(anotherObtainer)).isFalse();
    }

    @Test
   	public void testEquals_returnsTue_whenHaveSameAttributes() {
        Obtainer obtainer;
        Obtainer anotherObtainer;

        Crop crop = new Crop();

        String description = "description";

        // null attributes
        obtainer = new Obtainer();
        anotherObtainer = new Obtainer();
        assertThat(obtainer.equals(anotherObtainer)).isTrue();

        // status is not considered
        obtainer = new Obtainer(null, StatusEnum.ACTIVE, null);
        anotherObtainer = new Obtainer(null, StatusEnum.INACTIVE, null);
        assertThat(obtainer.equals(anotherObtainer)).isTrue();

        // only description
        obtainer = new Obtainer(description, null, null);
        anotherObtainer = new Obtainer(description, null, null);
        assertThat(obtainer.equals(anotherObtainer)).isTrue();

        // only crop
        obtainer = new Obtainer(null, null, crop);
        anotherObtainer = new Obtainer(null, null, crop);
        assertThat(obtainer.equals(anotherObtainer)).isTrue();

        // description and crop
        obtainer = new Obtainer(description, null, crop);
        anotherObtainer = new Obtainer(description, null, crop);
        assertThat(obtainer.equals(anotherObtainer)).isTrue();
   }

}