package com.monsanto.brazilvaluecapture.seedsale.sale.service.impl;

import com.monsanto.brazilvaluecapture.core.customer.model.bean.Customer;
import com.monsanto.brazilvaluecapture.core.foundation.service.EntityNotFoundException;
import com.monsanto.brazilvaluecapture.core.foundation.service.MBusinessException;
import com.monsanto.brazilvaluecapture.seedsale.harvest.model.bean.Plantability;
import com.monsanto.brazilvaluecapture.seedsale.product.model.bean.Product;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.Sale;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.SaleItem;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.SaleLinkDetail;
import com.monsanto.brazilvaluecapture.seedsale.sale.service.SaleLinkDetailLinker;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.runners.MockitoJUnitRunner;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import static org.fest.assertions.Assertions.assertThat;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class SaleLinkDetailLinkerImpl_UT extends ControllershipTestConfigurator {

    @Test
    public void testLinkDealerSale_whenSaleHasSomeSaleItemsLinked_thenMethodMustBeExecutedOverNotLinkedSaleitems() throws EntityNotFoundException {
        //@Given
        final Product product = createProduct("Product 1", true);
        Sale sale = createMultiplierSale();
        final SaleItem saleItemLinked1 = addSaleItemToSale(sale, new ItemDescription(BigDecimal.ONE, product, "BATCH NAME 1", plantability, BigDecimal.valueOf(20)), null);
        SaleLinkDetail saleLinkDetailLinked1 = new SaleLinkDetail(sale, saleItemLinked1);
        final SaleItem saleItemLinked2 = addSaleItemToSale(sale, new ItemDescription(BigDecimal.ONE, product, "BATCH NAME 2", plantability, BigDecimal.valueOf(20)), null);
        SaleLinkDetail saleLinkDetailLinked2 = new SaleLinkDetail(sale, saleItemLinked2);
        final SaleItem saleItemNotLinked1 = addSaleItemToSale(sale, new ItemDescription(BigDecimal.ONE, product, "BATCH NAME 3", plantability, BigDecimal.valueOf(20)), null);
        SaleLinkDetail saleLinkDetailNotLinked1 = new SaleLinkDetail(sale, saleItemNotLinked1);
        final SaleItem saleItemNotLinked2 = addSaleItemToSale(sale, new ItemDescription(BigDecimal.ONE, product, "BATCH NAME 4", plantability, BigDecimal.valueOf(20)), null);
        SaleLinkDetail saleLinkDetailNotLinked2 = new SaleLinkDetail(sale, saleItemNotLinked2);
        when(saleLinkDetailDAO.getCorrespondingSaleLinkDetail(saleItemLinked1)).thenReturn(saleLinkDetailLinked1);
        when(saleLinkDetailDAO.getCorrespondingSaleLinkDetail(saleItemLinked2)).thenReturn(saleLinkDetailLinked2);
        when(saleLinkDetailDAO.getCorrespondingSaleLinkDetail(saleItemNotLinked1)).thenReturn(saleLinkDetailNotLinked1);
        when(saleLinkDetailDAO.getCorrespondingSaleLinkDetail(saleItemNotLinked2)).thenReturn(saleLinkDetailNotLinked2);
        SaleLinkDetailLinkerImpl saleLinkDetailLinkerImpl = spy(new SaleLinkDetailLinkerImpl(saleDAO, saleLinkDetailDAO));
        when(saleLinkDetailDAO.getNotLinkedSaleItemsForSale(sale)).thenReturn(Arrays.asList(saleItemNotLinked1, saleItemNotLinked2));
        //@When
        saleLinkDetailLinkerImpl.linkDealerSale(sale);
        //@Then
        verify(saleLinkDetailDAO, never()).getCorrespondingSaleLinkDetail(saleItemLinked1);
        verify(saleLinkDetailDAO, never()).getCorrespondingSaleLinkDetail(saleItemLinked2);
        verify(saleLinkDetailDAO).getCorrespondingSaleLinkDetail(saleItemNotLinked1);
        verify(saleLinkDetailDAO).getCorrespondingSaleLinkDetail(saleItemNotLinked2);
    }

    @Test
    public void testLinkSaleRetrievesRegisteredSales_WhenLinkingDealerSales() throws EntityNotFoundException, MBusinessException {
        final Product product = createProduct("Product 1", true);
        final String batchName = "BATCH NAME";
        Sale sale = createMultiplierSale();
        final SaleItem saleItem = addSaleItemToSale(sale, new ItemDescription(BigDecimal.ONE, product, batchName, plantability, BigDecimal.valueOf(20)), null);
        willFindOneSalelinkDetailForSale(product, batchName, BigDecimal.TEN);
        final SaleLinkDetailLinkerImpl saleLinkDetailLinkerImpl = new SaleLinkDetailLinkerImpl(saleDAO, saleLinkDetailDAO);
        when(saleLinkDetailDAO.getNotLinkedSaleItemsForSale(sale)).thenReturn(sale.getItems());

        saleLinkDetailLinkerImpl.linkDealerSale(sale);

        verify(saleLinkDetailDAO).getCorrespondingSaleLinkDetail(saleItem);
    }

    @Test
    public void testLinkSaleReturnsTheFoundSaleLinkDetail_WhenLinkingDealerSales() throws EntityNotFoundException, MBusinessException {
        final Product product = createProduct("Product 1", true);
        final String batchName = "BATCH NAME";
        Sale sale = createMultiplierSale();
        final SaleItem saleItem = addSaleItemToSale(sale, new ItemDescription(BigDecimal.TEN, product, batchName, plantability, BigDecimal.valueOf(20)), null);
        SaleLinkDetail saleLinkDetail = new SaleLinkDetail(sale, saleItem);
        when(saleLinkDetailDAO.getCorrespondingSaleLinkDetail(saleItem)).thenReturn(saleLinkDetail);
        final SaleLinkDetailLinkerImpl saleLinkDetailLinkerImpl = new SaleLinkDetailLinkerImpl(saleDAO, saleLinkDetailDAO);
        when(saleLinkDetailDAO.getNotLinkedSaleItemsForSale(sale)).thenReturn(sale.getItems());

        final List<SaleLinkDetail> saleLinkDetails = saleLinkDetailLinkerImpl.linkDealerSale(sale);

        assertThat(saleLinkDetails).hasSize(1).contains(saleLinkDetail);
    }

    @Test
    public void testLinkSaleAdds10ToSaleLinkDetailConsumedField_WhenSaleItemSoldQtyIs10() throws EntityNotFoundException, MBusinessException {
        final Product product = createProduct("Product 1", true);
        final String batchName = "BATCH NAME";
        Sale sale = createMultiplierSale();
        BigDecimal saleItemSoldQty = BigDecimal.TEN;
        addSaleItemToSale(sale, new ItemDescription(saleItemSoldQty, product, batchName, plantability, BigDecimal.valueOf(20)), null);
        willFindOneSalelinkDetailForSale(product, batchName, BigDecimal.TEN);
        final SaleLinkDetailLinkerImpl saleLinkDetailLinkerImpl = new SaleLinkDetailLinkerImpl(saleDAO, saleLinkDetailDAO);
        when(saleLinkDetailDAO.getNotLinkedSaleItemsForSale(sale)).thenReturn(sale.getItems());

        final List<SaleLinkDetail> saleLinkDetails = saleLinkDetailLinkerImpl.linkDealerSale(sale);

        assertThat(saleLinkDetails).hasSize(1).onProperty("consumed").contains(saleItemSoldQty);
    }

    @Test
    public void testLinkSaleAdds20ToSaleLinkDetailConsumedField_WhenSaleItemSoldQtyIs20() throws EntityNotFoundException, MBusinessException {
        final Product product = createProduct("Product 1", true);
        final String batchName = "BATCH NAME";
        Sale sale = createMultiplierSale();
        BigDecimal saleItemSoldQty = BigDecimal.valueOf(20);
        addSaleItemToSale(sale, new ItemDescription(saleItemSoldQty, product, batchName, plantability, BigDecimal.valueOf(20)), null);
        willFindOneSalelinkDetailForSale(product, batchName, saleItemSoldQty);
        final SaleLinkDetailLinkerImpl saleLinkDetailLinkerImpl = new SaleLinkDetailLinkerImpl(saleDAO, saleLinkDetailDAO);
        when(saleLinkDetailDAO.getNotLinkedSaleItemsForSale(sale)).thenReturn(sale.getItems());

        final List<SaleLinkDetail> saleLinkDetails = saleLinkDetailLinkerImpl.linkDealerSale(sale);

        assertThat(saleLinkDetails).hasSize(1).onProperty("consumed").contains(saleItemSoldQty);
    }

    @Test
    public void testLinkSaleAdds40ToSaleLinkDetailConsumedField_WhenSaleHasTwoSaleItemWithSoldQtyOf20() throws EntityNotFoundException, MBusinessException {
        final Product product1 = createProduct("Product 1", true);
        final String batchName = "BATCH NAME";
        BigDecimal soldQty = BigDecimal.valueOf(20);
        Sale sale = createSaleWithTwoSaleItems(product1, batchName, plantability, product1, batchName, plantability, soldQty);
        willFindOneSalelinkDetailForSale(product1, batchName, BigDecimal.valueOf(40));
        final SaleLinkDetailLinkerImpl saleLinkDetailLinkerImpl = new SaleLinkDetailLinkerImpl(saleDAO, saleLinkDetailDAO);
        when(saleLinkDetailDAO.getNotLinkedSaleItemsForSale(sale)).thenReturn(sale.getItems());

        final List<SaleLinkDetail> saleLinkDetails = saleLinkDetailLinkerImpl.linkDealerSale(sale);

        BigDecimal expectedConsumedValue = BigDecimal.valueOf(40);
        assertThat(saleLinkDetails).hasSize(1).onProperty("consumed").contains(expectedConsumedValue);
    }

    @Test
    public void testLinkSaleWillReturnTwoSaleLinkDetails_WhenSaleHasTwoSaleItemWithDifferentProductBatchNameAndPlantability() throws EntityNotFoundException, MBusinessException {
        //@Given Sale with two sale items
        Product product = createProduct("Product", true);
        String batchName = "BATCH_NAME";
        Product product1 = createProduct("Product 1", true);
        String batchName1 = "BATCH_NAME 1";
        Plantability plantability1 = createPlantability("Plantability 1");
        Sale dealerSale = createMultiplierSale();
        BigDecimal saleItemSoldQty = BigDecimal.TEN;
        SaleItem dealerSaleItem1 = addSaleItemToSale(dealerSale, new ItemDescription(saleItemSoldQty, product, batchName, plantability, BigDecimal.valueOf(20)), null);
        SaleItem dealerSaleItem2 = addSaleItemToSale(dealerSale, new ItemDescription(saleItemSoldQty, product1, batchName1, plantability1, BigDecimal.valueOf(20)), null);
        //@And corresponding sale link details for each sale saleItem
        Sale multiplierSale = new Sale(new Customer(), new Customer());
        SaleItem multiplierSaleItem = addSaleItemToSale(multiplierSale, new ItemDescription(saleItemSoldQty, product, batchName, plantability, BigDecimal.valueOf(20)), null);
        SaleLinkDetail saleLinkDetail = new SaleLinkDetail(multiplierSale, multiplierSaleItem);
        when(saleLinkDetailDAO.getCorrespondingSaleLinkDetail(dealerSaleItem1)).thenReturn(saleLinkDetail);
        SaleItem multiplierSaleItem1 = addSaleItemToSale(multiplierSale, new ItemDescription(saleItemSoldQty, product1, batchName1, plantability1, BigDecimal.valueOf(20)), null);
        SaleLinkDetail saleLinkDetail1 = new SaleLinkDetail(multiplierSale, multiplierSaleItem1);
        when(saleLinkDetailDAO.getCorrespondingSaleLinkDetail(dealerSaleItem2)).thenReturn(saleLinkDetail1);
        final SaleLinkDetailLinkerImpl saleLinkDetailLinker = new SaleLinkDetailLinkerImpl(saleDAO, saleLinkDetailDAO);
        when(saleLinkDetailDAO.getNotLinkedSaleItemsForSale(dealerSale)).thenReturn(dealerSale.getItems());

        //@When dealer sale is linked
        List<SaleLinkDetail> saleLinkDetails = saleLinkDetailLinker.linkDealerSale(dealerSale);

        //@Then two sale link details are returned each with the same amount consumed as saleItem soldQty
        assertThat(saleLinkDetails).hasSize(2).onProperty("consumed").contains(saleItemSoldQty);
    }

    @Test
    public void testLinkSaleWillSaveUpdatedSaleLinkDetail_WhenLinkingSales() throws EntityNotFoundException, MBusinessException {
        final Product product = createProduct("Product 1", true);
        final String batchName = "BATCH NAME";
        BigDecimal soldQty = BigDecimal.valueOf(20);
        Sale sale = createSaleWithOneSaleItem(product, batchName, plantability, soldQty);
        willFindOneSalelinkDetailForSale(product, batchName, soldQty);
        final SaleLinkDetailLinkerImpl saleLinkDetailLinkerImpl = new SaleLinkDetailLinkerImpl(saleDAO, saleLinkDetailDAO);
        when(saleLinkDetailDAO.getNotLinkedSaleItemsForSale(sale)).thenReturn(sale.getItems());

        final List<SaleLinkDetail> saleLinkDetails = saleLinkDetailLinkerImpl.linkDealerSale(sale);

        SaleLinkDetail saleLinkDetail = saleLinkDetails.get(0);
        verify(saleLinkDetailDAO).save(saleLinkDetail);
    }

    @Test
    public void testLinkSaleWillSaveSaleLinkDetailTwice_WhenSameSaleLinkDetailIsFoundForSaleItems() throws EntityNotFoundException, MBusinessException {
        final Product product = createProduct("Product 1", true);
        final String batchName = "BATCH NAME";
        String batchName1 = "BATCH NAME 1";
        BigDecimal soldQty = BigDecimal.valueOf(20);
        Sale sale = createSaleWithTwoSaleItems(product, batchName, plantability, product, batchName1, plantability, soldQty);
        willFindOneSalelinkDetailForSale(product, batchName, BigDecimal.valueOf(40));
        final SaleLinkDetailLinkerImpl saleLinkDetailLinkerImpl = new SaleLinkDetailLinkerImpl(saleDAO, saleLinkDetailDAO);
        when(saleLinkDetailDAO.getNotLinkedSaleItemsForSale(sale)).thenReturn(sale.getItems());

        final List<SaleLinkDetail> saleLinkDetails = saleLinkDetailLinkerImpl.linkDealerSale(sale);

        SaleLinkDetail saleLinkDetail = saleLinkDetails.get(0);
        verify(saleLinkDetailDAO, times(2)).save(saleLinkDetail);
    }

    @Test
    public void testLinkSaleWillSaveTwoSaleLinkDetails_WhenTwoDifferentSaleLinkDetailsAreFoundForEachSaleItem() throws EntityNotFoundException, MBusinessException {
        //@Given Sale with two sale items
        Product product = createProduct("Product", true);
        String batchName = "BATCH_NAME";
        Product product1 = createProduct("Product 1", true);
        String batchName1 = "BATCH_NAME 1";
        Plantability plantability1 = createPlantability("Plantability 1");
        Sale dealerSale = createMultiplierSale();
        BigDecimal saleItemSoldQty = BigDecimal.TEN;
        SaleItem dealerSaleItem1 = addSaleItemToSale(dealerSale, new ItemDescription(saleItemSoldQty, product, batchName, plantability, BigDecimal.valueOf(20)), null);
        SaleItem dealerSaleItem2 = addSaleItemToSale(dealerSale, new ItemDescription(saleItemSoldQty, product1, batchName1, plantability1, BigDecimal.valueOf(20)), null);
        //@And corresponding sale link details for each sale saleItem
        Sale multiplierSale = new Sale(new Customer(), new Customer());
        SaleItem multiplierSaleItem = addSaleItemToSale(multiplierSale, new ItemDescription(saleItemSoldQty, product, batchName, plantability, BigDecimal.valueOf(20)), null);
        SaleLinkDetail saleLinkDetail = new SaleLinkDetail(multiplierSale, multiplierSaleItem);
        when(saleLinkDetailDAO.getCorrespondingSaleLinkDetail(dealerSaleItem1)).thenReturn(saleLinkDetail);
        SaleItem multiplierSaleItem1 = addSaleItemToSale(multiplierSale, new ItemDescription(saleItemSoldQty, product1, batchName1, plantability1, BigDecimal.valueOf(20)), null);
        SaleLinkDetail saleLinkDetail1 = new SaleLinkDetail(multiplierSale, multiplierSaleItem1);
        when(saleLinkDetailDAO.getCorrespondingSaleLinkDetail(dealerSaleItem2)).thenReturn(saleLinkDetail1);
        final SaleLinkDetailLinkerImpl saleLinkDetailLinker = new SaleLinkDetailLinkerImpl(saleDAO, saleLinkDetailDAO);
        when(saleLinkDetailDAO.getNotLinkedSaleItemsForSale(dealerSale)).thenReturn(dealerSale.getItems());

        //@When dealer sale is linked
        List<SaleLinkDetail> saleLinkDetails = saleLinkDetailLinker.linkDealerSale(dealerSale);

        //@Then two sale link details are returned each with the same amount consumed as saleItem soldQty
        ArgumentCaptor<SaleLinkDetail> savedLinkDetails = ArgumentCaptor.forClass(SaleLinkDetail.class);
        verify(saleLinkDetailDAO, times(2)).save(savedLinkDetails.capture());
        assertThat(savedLinkDetails.getAllValues()).contains(saleLinkDetails.toArray());
    }

    @Test
    public void testLinkSaleAddsNewSaleLinkDetailValueToSaleLinkDetail_WhenLinkingSales() throws EntityNotFoundException, MBusinessException {
        final SaleLinkDetailLinker saleLinkDetailLinker = new SaleLinkDetailLinkerImpl(saleDAO, saleLinkDetailDAO);
        Product product = createProduct("Product", true);
        BigDecimal soldQty = BigDecimal.valueOf(20);
        String batchName = "BATCH NAME";
        Sale dealerSale = createSaleWithOneSaleItem(product, batchName, plantability, soldQty);
        willFindOneSalelinkDetailForSale(product, batchName, soldQty);
        when(saleLinkDetailDAO.getNotLinkedSaleItemsForSale(dealerSale)).thenReturn(dealerSale.getItems());

        List<SaleLinkDetail> saleLinkDetails = saleLinkDetailLinker.linkDealerSale(dealerSale);

        SaleLinkDetail saleLinkDetail = saleLinkDetails.get(0);
        assertThat(saleLinkDetail.getSaleLinkDetailValueSet()).hasSize(1)
                .onProperty("dealerSale").contains(dealerSale);
        assertThat(saleLinkDetail.getSaleLinkDetailValueSet()).onProperty("consumed").contains(soldQty);
    }

    @Test
    public void testLinkSaleSearchsForTwoSaleLinkDetails_WhenSaleItemSoldQtyIsGreatThatFoundSaleLinkDetailTotal() throws MBusinessException, EntityNotFoundException {
        SaleLinkDetailLinker saleLinkDetailLinker = new SaleLinkDetailLinkerImpl(saleDAO, saleLinkDetailDAO);
        Sale dealerSale = createMultiplierSale();
        Product product = createProduct("Product 1", true);
        String batchName = "batch name";
        BigDecimal soldQty = BigDecimal.valueOf(20);
        SaleItem dealerSaleItem = addSaleItemToSale(dealerSale, new ItemDescription(soldQty, product, batchName, plantability, BigDecimal.valueOf(20)), null);
        Sale multiplierSale = createDealerSale(new Date());
        SaleItem multiplierSaleItem = addSaleItemToSale(multiplierSale, new ItemDescription(BigDecimal.TEN, product, batchName, plantability, BigDecimal.valueOf(20)), null);
        SaleLinkDetail saleLinkDetail = new SaleLinkDetail(multiplierSale, multiplierSaleItem);
        SaleLinkDetail saleLinkDetail1 = new SaleLinkDetail(multiplierSale, multiplierSaleItem);
        when(saleLinkDetailDAO.getCorrespondingSaleLinkDetail(dealerSaleItem)).thenReturn(saleLinkDetail, saleLinkDetail1);
        when(saleLinkDetailDAO.getNotLinkedSaleItemsForSale(dealerSale)).thenReturn(dealerSale.getItems());

        saleLinkDetailLinker.linkDealerSale(dealerSale);

        verify(saleLinkDetailDAO, times(2)).getCorrespondingSaleLinkDetail(dealerSaleItem);
    }

    @Test
    public void testLinkSaleConsumesFromTwoSaleLinkDetailsEachWithTotal10_WhenSaleItemSoldQtyIs20() throws MBusinessException, EntityNotFoundException {
        SaleLinkDetailLinker saleLinkDetailLinker = new SaleLinkDetailLinkerImpl(saleDAO, saleLinkDetailDAO);
        Sale dealerSale = createMultiplierSale();
        Product product = createProduct("Product 1", true);
        String batchName = "batch name";
        SaleItem dealerSaleItem = addSaleItemToSale(dealerSale, new ItemDescription(BigDecimal.valueOf(20), product, batchName, plantability, BigDecimal.valueOf(20)), null);
        Sale multiplierSale = createDealerSale(new Date());
        SaleItem multiplierSaleItem = addSaleItemToSale(multiplierSale, new ItemDescription(BigDecimal.TEN, product, batchName, plantability, BigDecimal.valueOf(20)), null);
        SaleLinkDetail saleLinkDetail = new SaleLinkDetail(multiplierSale, multiplierSaleItem);
        SaleLinkDetail saleLinkDetail1 = new SaleLinkDetail(multiplierSale, multiplierSaleItem);
        when(saleLinkDetailDAO.getCorrespondingSaleLinkDetail(dealerSaleItem)).thenReturn(saleLinkDetail, saleLinkDetail1);
        when(saleLinkDetailDAO.getNotLinkedSaleItemsForSale(dealerSale)).thenReturn(dealerSale.getItems());

        List<SaleLinkDetail> saleLinkDetails = saleLinkDetailLinker.linkDealerSale(dealerSale);

        assertThat(saleLinkDetails).hasSize(2);
        assertThat(saleLinkDetails.get(0).getConsumed()).isEqualTo(BigDecimal.TEN);
        assertThat(saleLinkDetails.get(1).getConsumed()).isEqualTo(BigDecimal.TEN);
    }

    @Test
    public void testUnlinkDealerSaleDecreaseTheSaleLinkDetailConsumed() {
        Product product = createProduct("Product", false);
        String batchName = "batchName";
        Sale multiplierSale = createSaleWithOneSaleItem(product, batchName, plantability, BigDecimal.TEN);
        final SaleLinkDetail saleLinkDetail = new SaleLinkDetail(multiplierSale, multiplierSale.getItems().iterator().next());
        final Sale dealerSale = createSaleWithOneSaleItem(product, batchName, plantability, BigDecimal.valueOf(5));
        saleLinkDetail.consume(dealerSale, BigDecimal.valueOf(5), dealerSale.getItems().iterator().next());

        final SaleLinkDetailLinkerImpl saleLinkDetailLinker = new SaleLinkDetailLinkerImpl(saleDAO, saleLinkDetailDAO);

        saleLinkDetailLinker.unlinkDealerSale(dealerSale);

        assertThat(saleLinkDetail.getConsumed()).isEqualTo(BigDecimal.ZERO);
    }

    @Test
    public void testUnlinkDealerSaleRemovesSaleLinkDetailValueFromSaleLinkDetail() {
        Product product = createProduct("Product", false);
        String batchName = "batchName";
        Sale multiplierSale = createSaleWithOneSaleItem(product, batchName, plantability, BigDecimal.TEN);
        final SaleLinkDetail saleLinkDetail = new SaleLinkDetail(multiplierSale, multiplierSale.getItems().iterator().next());
        final Sale dealerSale = createSaleWithOneSaleItem(product, batchName, plantability, BigDecimal.valueOf(5));
        saleLinkDetail.consume(dealerSale, BigDecimal.valueOf(5), dealerSale.getItems().iterator().next());

        final SaleLinkDetailLinkerImpl saleLinkDetailLinker = new SaleLinkDetailLinkerImpl(saleDAO, saleLinkDetailDAO);

        saleLinkDetailLinker.unlinkDealerSale(dealerSale);

        assertThat(saleLinkDetail.getSaleLinkDetailValueSet()).isEmpty();
    }

    @Test
    public void testUnlinkDealerSaleRemovesSaleLinkDetailValueFromDataBase() {
        Product product = createProduct("Product", false);
        String batchName = "batchName";
        Sale multiplierSale = createSaleWithOneSaleItem(product, batchName, plantability, BigDecimal.TEN);
        final SaleLinkDetail saleLinkDetail = new SaleLinkDetail(multiplierSale, multiplierSale.getItems().iterator().next());
        final Sale dealerSale = createSaleWithOneSaleItem(product, batchName, plantability, BigDecimal.valueOf(5));
        saleLinkDetail.consume(dealerSale, BigDecimal.valueOf(5), dealerSale.getItems().iterator().next());

        final SaleLinkDetailLinkerImpl saleLinkDetailLinker = new SaleLinkDetailLinkerImpl(saleDAO, saleLinkDetailDAO);

        saleLinkDetailLinker.unlinkDealerSale(dealerSale);

        verify(saleLinkDetailDAO).deleteSaleLinkDetailValue(dealerSale.getItems().iterator().next().getSaleLinkDetailValue());
    }
}
