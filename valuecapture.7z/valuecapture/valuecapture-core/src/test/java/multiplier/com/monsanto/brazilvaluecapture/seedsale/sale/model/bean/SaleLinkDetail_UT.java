package com.monsanto.brazilvaluecapture.seedsale.sale.model.bean;

import com.monsanto.brazilvaluecapture.seedsale.product.model.bean.Product;
import com.monsanto.brazilvaluecapture.seedsale.revenue.model.PostingStatusEnum;
import com.monsanto.brazilvaluecapture.seedsale.sale.service.impl.ControllershipTestConfigurator;
import com.monsanto.brazilvaluecapture.utils.DateRange;
import com.monsanto.brazilvaluecapture.utils.DateUtils;
import org.joda.time.DateTime;
import org.junit.Test;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import static org.fest.assertions.Assertions.assertThat;

public class SaleLinkDetail_UT extends ControllershipTestConfigurator {

    @Test
    public void testSaleLinkDetailConstructorInitializesTotalWith10_WhenSaleItemSoldQtyIs10() {
        Sale multiplierSale = new Sale();
        SaleItem multiplierSaleItem = new SaleItem(multiplierSale, null, null, null);
        multiplierSaleItem.setSoldQuantity(10l);
        SaleLinkDetail saleLinkDetail = new SaleLinkDetail(multiplierSale, multiplierSaleItem);

        BigDecimal soldQuantity = BigDecimal.valueOf(multiplierSaleItem.getSoldQuantity());
        assertThat(saleLinkDetail.getTotal()).isEqualTo(soldQuantity);
    }

    @Test
    public void testConsumeAddsNewSaleLinkDetailValueWithDealerSale_WhenConsumingFromSaleLinkDetail() {
        Sale multiplierSale = createMultiplierSale();
        BigDecimal soldQty = BigDecimal.TEN;
        Product product = createProduct("Product", true);
        String batchName = "batch Name";
        SaleItem saleItem = addSaleItemToSale(multiplierSale, new ItemDescription(soldQty, product, batchName, plantability, BigDecimal.valueOf(20)), null);
        SaleLinkDetail saleLinkDetail = new SaleLinkDetail(multiplierSale, saleItem);
        Sale dealerSale = createDealerSale(new Date());
        addSaleItemToSale(dealerSale, new ItemDescription(soldQty, product, batchName, plantability, BigDecimal.valueOf(20)), null);

        saleLinkDetail.consume(dealerSale, soldQty, saleItem);

        assertThat(saleLinkDetail.getSaleLinkDetailValueSet()).hasSize(1).onProperty("dealerSale").contains(dealerSale);
    }

    @Test
    public void testConsumeAddsNewSaleLinkDetailValueWithSaleItemSoldQty_WhenConsumingFromSaleLinkDetail() {
        Sale multiplierSale = createMultiplierSale();
        BigDecimal soldQty = BigDecimal.TEN;
        Product product = createProduct("Product", true);
        String batchName = "batch Name";
        SaleItem saleItem = addSaleItemToSale(multiplierSale, new ItemDescription(soldQty, product, batchName, plantability, BigDecimal.valueOf(20)), null);
        SaleLinkDetail saleLinkDetail = new SaleLinkDetail(multiplierSale, saleItem);
        Sale dealerSale = createDealerSale(new Date());
        addSaleItemToSale(dealerSale, new ItemDescription(soldQty, product, batchName, plantability, BigDecimal.valueOf(20)), null);

        saleLinkDetail.consume(dealerSale, soldQty, saleItem);

        assertThat(saleLinkDetail.getSaleLinkDetailValueSet()).hasSize(1).onProperty("consumed").contains(soldQty);
    }

    @Test
    public void testConsumeAddsNewSaleLinkDetailValueWithSaleItem_WhenConsumingFromSaleLinkDetail() {
        Sale multiplierSale = createMultiplierSale();
        BigDecimal soldQty = BigDecimal.TEN;
        Product product = createProduct("Product", true);
        String batchName = "batch Name";
        SaleItem saleItem = addSaleItemToSale(multiplierSale, new ItemDescription(soldQty, product, batchName, plantability, BigDecimal.valueOf(20)), null);
        SaleLinkDetail saleLinkDetail = new SaleLinkDetail(multiplierSale, saleItem);
        Sale dealerSale = createDealerSale(new Date());
        SaleItem dealerSaleItem = addSaleItemToSale(dealerSale, new ItemDescription(soldQty, product, batchName, plantability, BigDecimal.valueOf(20)), null);

        saleLinkDetail.consume(dealerSale, soldQty, dealerSaleItem);

        assertThat(saleLinkDetail.getSaleLinkDetailValueSet()).hasSize(1).onProperty("dealerSaleItem").contains(dealerSaleItem);
    }

    @Test
    public void testConsumeIncreasesConsumedField_WhenConsumingFromSaleLinkDetail() {
        Sale multiplierSale = createMultiplierSale();
        BigDecimal soldQty = BigDecimal.TEN;
        Product product = createProduct("Product", true);
        String batchName = "batch Name";
        SaleItem saleItem = addSaleItemToSale(multiplierSale, new ItemDescription(soldQty, product, batchName, plantability, BigDecimal.valueOf(20)), null);
        SaleLinkDetail saleLinkDetail = new SaleLinkDetail(multiplierSale, saleItem);
        Sale dealerSale = createDealerSale(new Date());
        addSaleItemToSale(dealerSale, new ItemDescription(soldQty, product, batchName, plantability, BigDecimal.valueOf(20)), null);

        saleLinkDetail.consume(dealerSale, soldQty, saleItem);

        assertThat(saleLinkDetail.getConsumed()).isEqualTo(soldQty);
    }

    @Test
    public void testConsumeSetsSaleLinkDetailValueToDealerSaleItem() {
        Sale multiplierSale = createMultiplierSale();
        BigDecimal soldQty = BigDecimal.TEN;
        Product product = createProduct("Product", true);
        String batchName = "batch Name";
        SaleItem saleItem = addSaleItemToSale(multiplierSale, new ItemDescription(soldQty, product, batchName, plantability, BigDecimal.valueOf(20)), null);
        SaleLinkDetail saleLinkDetail = new SaleLinkDetail(multiplierSale, saleItem);
        Sale dealerSale = createDealerSale(new Date());
        final SaleItem dealerSaleItem = addSaleItemToSale(dealerSale, new ItemDescription(soldQty, product, batchName, plantability, BigDecimal.valueOf(20)), null);

        final SaleLinkDetailValue linkDetailValue = saleLinkDetail.consume(dealerSale, soldQty, dealerSaleItem);

        assertThat(dealerSaleItem.getSaleLinkDetailValue()).isSameAs(linkDetailValue);
    }

    @Test
    public void testGetSaleDealerItemsInPeriodReturnsSaleItemsOfSalesCreatedInTheGivenPeriod_WhenThereAreAssociatedSalesInThatPeriod() {
        Product product = createProduct("product 1", false);
        final String batchName = "Batch Name";
        Sale multiplierSale = createMultiplierSale();
        final SaleItem saleItem = addSaleItemToSale(multiplierSale, new ItemDescription(BigDecimal.TEN, product, batchName, plantability, BigDecimal.valueOf(20)), null);
        SaleLinkDetail saleLinkDetail = new SaleLinkDetail(multiplierSale, saleItem);
        final Sale dealerSale = createDealerSale(new Date());
        SaleItem dealerSaleItem = addSaleItemToSale(dealerSale, new ItemDescription(BigDecimal.ONE, product, batchName, plantability, BigDecimal.valueOf(20)), null);
        dealerSaleItem.setPostingStatus(PostingStatusEnum.NOT_POSTED);
        saleLinkDetail.consume(dealerSale, BigDecimal.ONE, dealerSaleItem);
        DateRange period = new DateRange(DateUtils.setTimeToMidnight(new Date()), DateUtils.setTimeToLastSecondOfDay(new Date()));

        List<SaleItem> saleItems = saleLinkDetail.getNotRecognizedSaleItemsInPeriod(period);

        assertThat(saleItems).containsExactly(dealerSaleItem);
    }

    @Test
    public void testGetSaleDealerItemsInPeriodWontReturnsSaleItemsOfSalesCreatedInTheGivenPeriod_WhenThereAreNotAssociatedSalesInThatPeriod() {
        Sale multiplierSale = createMultiplierSale();
        Product product = createProduct("product 1", false);
        final String batchName = "Batch Name";
        final SaleItem saleItem = addSaleItemToSale(multiplierSale, new ItemDescription(BigDecimal.TEN, product, batchName, plantability, BigDecimal.valueOf(20)), null);
        SaleLinkDetail saleLinkDetail = new SaleLinkDetail(multiplierSale, saleItem);
        final Date dealerSaleCreationDate = new DateTime(2013, 1, 1, 0, 0).toDate();
        final Sale dealerSale = createDealerSale(dealerSaleCreationDate);
        final BigDecimal consumedByDealerSaleItems = BigDecimal.ONE;
        SaleItem dealerSaleItem = addSaleItemToSale(dealerSale, new ItemDescription(consumedByDealerSaleItems, product, batchName, plantability, BigDecimal.valueOf(20)), null);
        saleLinkDetail.consume(dealerSale, consumedByDealerSaleItems, dealerSaleItem);
        DateRange period = new DateRange(DateUtils.setTimeToMidnight(new Date()), DateUtils.setTimeToLastSecondOfDay(new Date()));

        List<SaleItem> saleItems = saleLinkDetail.getNotRecognizedSaleItemsInPeriod(period);

        assertThat(saleItems).isEmpty();
    }

    @Test
    public void testGetSaleDealerItemsInPeriodReturnsNotRecognizedSaleItemsOfSalesCreatedInTheGivenPeriod_WhenThereAreAssociatedSalesInThatPeriod() {
        Product product = createProduct("product 1", false);
        final String batchName = "Batch Name";
        Sale multiplierSale = createMultiplierSale();
        final SaleItem saleItem = addSaleItemToSale(multiplierSale, new ItemDescription(BigDecimal.TEN, product, batchName, plantability, BigDecimal.valueOf(20)), null);
        SaleLinkDetail saleLinkDetail = new SaleLinkDetail(multiplierSale, saleItem);
        final Sale dealerSale = createDealerSale(new Date());
        SaleItem dealerSaleItem = addSaleItemToSale(dealerSale, new ItemDescription(BigDecimal.ONE, product, batchName, plantability, BigDecimal.valueOf(20)), null);
        dealerSaleItem.setPostingStatus(PostingStatusEnum.NOT_POSTED);
        saleLinkDetail.consume(dealerSale, BigDecimal.ONE, dealerSaleItem);
        final Sale dealerSaleWithRevenueRecognition = createDealerSale(new Date());
        SaleItem dealerSaleItemPosted = addSaleItemToSale(dealerSaleWithRevenueRecognition, new ItemDescription(BigDecimal.ONE, product, batchName, plantability, BigDecimal.valueOf(20)), null, null);
        saleLinkDetail.consume(dealerSaleWithRevenueRecognition, BigDecimal.ONE, dealerSaleItemPosted);
        dealerSaleItemPosted.setPostingStatus(PostingStatusEnum.REVENUE_RECOGNITION_POSTED);
        DateRange period = new DateRange(DateUtils.setTimeToMidnight(new Date()), DateUtils.setTimeToLastSecondOfDay(new Date()));

        List<SaleItem> saleItems = saleLinkDetail.getNotRecognizedSaleItemsInPeriod(period);

        assertThat(saleItems).containsExactly(dealerSaleItem);
    }

    @Test
    public void testGetConsumedInPeriodReturn9_WhenSaleItemsInTheGivenPeriodConsumed1FromTotalOf10() {
        Sale multiplierSale = createMultiplierSale();
        Product product = createProduct("product 1", false);
        final String batchName = "Batch Name";
        final SaleItem saleItem = addSaleItemToSale(multiplierSale, new ItemDescription(BigDecimal.TEN, product, batchName, plantability, BigDecimal.valueOf(20)), null);
        SaleLinkDetail saleLinkDetail = new SaleLinkDetail(multiplierSale, saleItem);
        final Date dealerSaleCreationDate = new Date();
        final Sale dealerSale = createDealerSale(dealerSaleCreationDate);
        SaleItem dealerSaleItem = addSaleItemToSale(dealerSale, new ItemDescription(BigDecimal.ONE, product, batchName, plantability, BigDecimal.valueOf(20)), null);
        saleLinkDetail.consume(dealerSale, BigDecimal.ONE, dealerSaleItem);
        DateRange period = new DateRange(DateUtils.setTimeToMidnight(new Date()), DateUtils.setTimeToLastSecondOfDay(new Date()));

        BigDecimal consumedInPeriod = saleLinkDetail.getNotRecognizedConsumedInPeriod(period);

        assertThat(consumedInPeriod).isEqualTo(BigDecimal.valueOf(1));
    }

    @Test
    public void testGetConsumedInPeriodReturn5_WhenSaleItemsInTheGivenPeriodConsumed5FromTotalOf10() {
        Sale multiplierSale = createMultiplierSale();
        Product product = createProduct("product 1", false);
        final String batchName = "Batch Name";
        final SaleItem saleItem = addSaleItemToSale(multiplierSale, new ItemDescription(BigDecimal.TEN, product, batchName, plantability, BigDecimal.valueOf(20)), null);
        SaleLinkDetail saleLinkDetail = new SaleLinkDetail(multiplierSale, saleItem);
        final Date dealerSaleCreationDate = new Date();
        final Sale dealerSale = createDealerSale(dealerSaleCreationDate);
        final BigDecimal consumedByDealerSaleItems = BigDecimal.valueOf(5);
        SaleItem dealerSaleItem = addSaleItemToSale(dealerSale, new ItemDescription(consumedByDealerSaleItems, product, batchName, plantability, BigDecimal.valueOf(20)), null);
        saleLinkDetail.consume(dealerSale, consumedByDealerSaleItems, dealerSaleItem);
        DateRange period = new DateRange(DateUtils.setTimeToMidnight(new Date()), DateUtils.setTimeToLastSecondOfDay(new Date()));

        BigDecimal consumedInPeriod = saleLinkDetail.getNotRecognizedConsumedInPeriod(period);

        assertThat(consumedInPeriod).isEqualTo(consumedByDealerSaleItems);
    }

    @Test
    public void testGetConsumedInPeriodReturn5_WhenSaleItemsInTheGivenPeriodConsumed5FromTotalOf10AndDealerSaleItemSold10() {
        Sale multiplierSale = createMultiplierSale();
        Product product = createProduct("product 1", false);
        final String batchName = "Batch Name";
        final SaleItem saleItem = addSaleItemToSale(multiplierSale, new ItemDescription(BigDecimal.TEN, product, batchName, plantability, BigDecimal.valueOf(20)), null);
        SaleLinkDetail saleLinkDetail = new SaleLinkDetail(multiplierSale, saleItem);
        final Date dealerSaleCreationDate = new Date();
        final Sale dealerSale = createDealerSale(dealerSaleCreationDate);
        final BigDecimal consumedByDealerSaleItems = BigDecimal.valueOf(5);
        SaleItem dealerSaleItem = addSaleItemToSale(dealerSale, new ItemDescription(BigDecimal.TEN, product, batchName, plantability, BigDecimal.valueOf(20)), null);
        saleLinkDetail.consume(dealerSale, consumedByDealerSaleItems, dealerSaleItem);
        DateRange period = new DateRange(DateUtils.setTimeToMidnight(new Date()), DateUtils.setTimeToLastSecondOfDay(new Date()));

        BigDecimal consumedInPeriod = saleLinkDetail.getNotRecognizedConsumedInPeriod(period);

        assertThat(consumedInPeriod).isEqualTo(consumedByDealerSaleItems);
    }

    @Test
    public void testGetConsumedInPeriodReturn0_WhenNoSaleConsumedInGivenPeriod() {
        Sale multiplierSale = createMultiplierSale();
        Product product = createProduct("product 1", false);
        final String batchName = "Batch Name";
        final SaleItem saleItem = addSaleItemToSale(multiplierSale, new ItemDescription(BigDecimal.TEN, product, batchName, plantability, BigDecimal.valueOf(20)), null);
        SaleLinkDetail saleLinkDetail = new SaleLinkDetail(multiplierSale, saleItem);
        final Date dealerSaleCreationDate = new DateTime(2013, 1, 1, 0, 0).toDate();
        final Sale dealerSale = createDealerSale(dealerSaleCreationDate);
        final BigDecimal consmedByDealerSaleItems = BigDecimal.valueOf(5);
        SaleItem dealerSaleItem = addSaleItemToSale(dealerSale, new ItemDescription(consmedByDealerSaleItems, product, batchName, plantability, BigDecimal.valueOf(20)), null);
        saleLinkDetail.consume(dealerSale, consmedByDealerSaleItems, dealerSaleItem);
        DateRange period = new DateRange(DateUtils.setTimeToMidnight(new Date()), DateUtils.setTimeToLastSecondOfDay(new Date()));

        BigDecimal consumedInPeriod = saleLinkDetail.getNotRecognizedConsumedInPeriod(period);

        assertThat(consumedInPeriod).isEqualTo(BigDecimal.ZERO);
    }

    @Test
    public void testGetConsumedInPeriodReturn10_WhenSaleLinkDetailValueWasAlreadyRecognized() {
        Sale multiplierSale = createMultiplierSale();
        Product product = createProduct("product 1", false);
        final String batchName = "Batch Name";
        final SaleItem saleItem = addSaleItemToSale(multiplierSale, new ItemDescription(BigDecimal.TEN, product, batchName, plantability, BigDecimal.valueOf(20)), null);
        SaleLinkDetail saleLinkDetail = new SaleLinkDetail(multiplierSale, saleItem);
        final Date dealerSaleCreationDate = new Date();
        final Sale dealerSale = createDealerSale(dealerSaleCreationDate);
        SaleItem dealerSaleItem = addSaleItemToSale(dealerSale, new ItemDescription(BigDecimal.ONE, product, batchName, plantability, BigDecimal.valueOf(20)), null, null);
        saleLinkDetail.consume(dealerSale, BigDecimal.ONE, dealerSaleItem);
        saleLinkDetail.getSaleLinkDetailValueSet().iterator().next().setRevenueRecognition(BigDecimal.TEN);

        DateRange period = new DateRange(DateUtils.setTimeToMidnight(new Date()), DateUtils.setTimeToLastSecondOfDay(new Date()));

        BigDecimal consumedInPeriod = saleLinkDetail.getNotRecognizedConsumedInPeriod(period);

        assertThat(consumedInPeriod).isEqualTo(BigDecimal.valueOf(0));
    }

    @Test
    public void testGetNotRecognizedSaleLinkDetailValuesInPeriodReturnNotRecognizedSaleLinkDetailsValuesInGivenPeriod() {
        Sale multiplierSale = createMultiplierSale();
        final SaleItem multiplierSaleItem = new SaleItem();
        multiplierSaleItem.setSoldQuantity(1l);
        SaleLinkDetail saleLinkDetail = new SaleLinkDetail(multiplierSale, multiplierSaleItem);
        DateRange period = new DateRange(DateUtils.setTimeToMidnight(new Date()), DateUtils.setTimeToLastSecondOfDay(new Date()));
        final Sale dealerSale = createDealerSale(new Date());
        SaleItem dealerSaleItem = addSaleItemToSale(dealerSale, new ItemDescription(BigDecimal.ONE, createProduct("product 1", false), "Batch Name", plantability, BigDecimal.valueOf(20)), null, null);
        saleLinkDetail.consume(dealerSale, BigDecimal.ONE, dealerSaleItem);

        List<SaleLinkDetailValue> saleLinkDetailValues = saleLinkDetail.getNotRecognizedSaleLinkDetailValuesInPeriod(period);

        assertThat(saleLinkDetailValues).contains(saleLinkDetail.getSaleLinkDetailValueSet().iterator().next());
    }

    @Test
    public void testGetNotRecognizedSaleLinkDetailValuesInPeriodReturnEmptyIfNoDealerSaleInPeriod() {
        Sale multiplierSale = createMultiplierSale();
        final SaleItem multiplierSaleItem = new SaleItem();
        multiplierSaleItem.setSoldQuantity(1l);
        SaleLinkDetail saleLinkDetail = new SaleLinkDetail(multiplierSale, multiplierSaleItem);
        DateRange period = new DateRange(DateUtils.setTimeToMidnight(new Date()), DateUtils.setTimeToLastSecondOfDay(new Date()));
        final Sale dealerSale = createDealerSale(new DateTime(2014, 01, 01, 00, 00).toDate());
        SaleItem dealerSaleItem = addSaleItemToSale(dealerSale, new ItemDescription(BigDecimal.ONE, createProduct("product 1", false), "Batch Name", plantability, BigDecimal.valueOf(20)), null, null);
        saleLinkDetail.consume(dealerSale, BigDecimal.ONE, dealerSaleItem);

        List<SaleLinkDetailValue> saleLinkDetailValues = saleLinkDetail.getNotRecognizedSaleLinkDetailValuesInPeriod(period);

        assertThat(saleLinkDetailValues).isEmpty();
    }

    @Test
    public void testGetNotRecognizedSaleLinkDetailValuesInPeriodReturnEmptyIfSaleLinkDetailValueWasAlreadyRecognized() {
        Sale multiplierSale = createMultiplierSale();
        final SaleItem multiplierSaleItem = new SaleItem();
        multiplierSaleItem.setSoldQuantity(1l);
        SaleLinkDetail saleLinkDetail = new SaleLinkDetail(multiplierSale, multiplierSaleItem);
        DateRange period = new DateRange(DateUtils.setTimeToMidnight(new Date()), DateUtils.setTimeToLastSecondOfDay(new Date()));
        final Sale dealerSale = createDealerSale(DateTime.now().plusHours(1).toDate());
        SaleItem dealerSaleItem = addSaleItemToSale(dealerSale, new ItemDescription(BigDecimal.ONE, createProduct("product 1", false), "Batch Name", plantability, BigDecimal.valueOf(20)), null, null);
        saleLinkDetail.consume(dealerSale, BigDecimal.ONE, dealerSaleItem);
        saleLinkDetail.getSaleLinkDetailValueSet().iterator().next().setRevenueRecognition(BigDecimal.TEN);

        List<SaleLinkDetailValue> saleLinkDetailValues = saleLinkDetail.getNotRecognizedSaleLinkDetailValuesInPeriod(period);

        assertThat(saleLinkDetailValues).isEmpty();
    }

    @Test
    public void testGetTotalRevenueRecognitionReturn2_WhenSaleLinkDetailValueRevenueRecognitionIs2() {
        Sale multiplierSale = createMultiplierSale();
        Product product = createProduct("product 1", false);
        final String batchName = "Batch Name";
        final SaleItem saleItem = addSaleItemToSale(multiplierSale, new ItemDescription(BigDecimal.TEN, product, batchName, plantability, BigDecimal.valueOf(20)), BigDecimal.ONE);
        SaleLinkDetail saleLinkDetail = new SaleLinkDetail(multiplierSale, saleItem);
        final Date dealerSaleCreationDate = new Date();
        final Sale dealerSale = createDealerSale(dealerSaleCreationDate);
        SaleItem dealerSaleItem = addSaleItemToSale(dealerSale, new ItemDescription(BigDecimal.ONE, product, batchName, plantability, BigDecimal.valueOf(20)), null, BigDecimal.valueOf(5000));
        saleLinkDetail.consume(dealerSale, BigDecimal.ONE, dealerSaleItem);
        dealerSaleItem.setSaleLinkDetail(saleLinkDetail);
        saleLinkDetail.getSaleLinkDetailValueSet().iterator().next().setRevenueRecognition(BigDecimal.valueOf(2));

        BigDecimal allRevenueRecognition = saleLinkDetail.getTotalRevenueRecognition();

        assertThat(allRevenueRecognition).isEqualTo(BigDecimal.valueOf(2));
    }

    @Test
    public void testGetTotalRevenueRecognitionZero_WhenSaleLinkDetailValueRevenueRecognitionIsNull() {
        Sale multiplierSale = createMultiplierSale();
        Product product = createProduct("product 1", false);
        final String batchName = "Batch Name";
        final SaleItem saleItem = addSaleItemToSale(multiplierSale, new ItemDescription(BigDecimal.TEN, product, batchName, plantability, BigDecimal.valueOf(20)), BigDecimal.ONE);
        SaleLinkDetail saleLinkDetail = new SaleLinkDetail(multiplierSale, saleItem);
        final Date dealerSaleCreationDate = new Date();
        final Sale dealerSale = createDealerSale(dealerSaleCreationDate);
        SaleItem dealerSaleItem = addSaleItemToSale(dealerSale, new ItemDescription(BigDecimal.ONE, product, batchName, plantability, BigDecimal.valueOf(20)), null, BigDecimal.valueOf(5000));
        saleLinkDetail.consume(dealerSale, BigDecimal.ONE, dealerSaleItem);
        dealerSaleItem.setSaleLinkDetail(saleLinkDetail);

        BigDecimal allRevenueRecognition = saleLinkDetail.getTotalRevenueRecognition();

        assertThat(allRevenueRecognition).isEqualTo(BigDecimal.ZERO);
    }

    @Test
    public void testHasPostedLinkedSalesReturnsTrue_WhenHavePostedDealerSalesLinked() {
        Sale multiplierSale = createMultiplierSale();
        Product product = createProduct("product 1", false);
        final String batchName = "Batch Name";
        final SaleItem saleItem = addSaleItemToSale(multiplierSale, new ItemDescription(BigDecimal.TEN, product, batchName, plantability, BigDecimal.valueOf(20)), null);
        SaleLinkDetail saleLinkDetail = new SaleLinkDetail(multiplierSale, saleItem);
        final Date dealerSaleCreationDate = new Date();
        final Sale dealerSale = createDealerSale(dealerSaleCreationDate);
        final BigDecimal expectedRevenueRecognition = BigDecimal.valueOf(5000);
        SaleItem dealerSaleItem = addSaleItemToSale(dealerSale, new ItemDescription(BigDecimal.ONE, product, batchName, plantability, BigDecimal.valueOf(20)), null, expectedRevenueRecognition);
        saleLinkDetail.consume(dealerSale, BigDecimal.ONE, dealerSaleItem);
        dealerSaleItem.setSaleLinkDetail(saleLinkDetail);
        dealerSaleItem.setPostingDate(new Date());
        dealerSaleItem.setPostingStatus(PostingStatusEnum.REVENUE_RECOGNITION_POSTED);

        assertThat(saleLinkDetail.hasPostedLinkedSales()).isTrue();
    }

    @Test
    public void testHasPostedLinkedSalesReturnsFalse_WhenDoNotHavePostedDealerSalesLinked() {
        Sale multiplierSale = createMultiplierSale();
        Product product = createProduct("product 1", false);
        final String batchName = "Batch Name";
        final SaleItem saleItem = addSaleItemToSale(multiplierSale, new ItemDescription(BigDecimal.TEN, product, batchName, plantability, BigDecimal.valueOf(20)), null);
        SaleLinkDetail saleLinkDetail = new SaleLinkDetail(multiplierSale, saleItem);
        final Date dealerSaleCreationDate = new Date();
        final Sale dealerSale = createDealerSale(dealerSaleCreationDate);
        final BigDecimal expectedRevenueRecognition = BigDecimal.valueOf(5000);
        SaleItem dealerSaleItem = addSaleItemToSale(dealerSale, new ItemDescription(BigDecimal.ONE, product, batchName, plantability, BigDecimal.valueOf(20)), null, expectedRevenueRecognition);
        saleLinkDetail.consume(dealerSale, BigDecimal.ONE, dealerSaleItem);
        dealerSaleItem.setSaleLinkDetail(saleLinkDetail);

        assertThat(saleLinkDetail.hasPostedLinkedSales()).isFalse();
    }

    @Test
    public void testGetRevenueRecognitionFromPreviousCalculationsReturns10_WhenPostedSaleItemsHaveRevenueRecognitionOf10() {
        Sale multiplierSale = createMultiplierSale();
        Product product = createProduct("product 1", false);
        final String batchName = "Batch Name";
        final SaleItem saleItem = addSaleItemToSale(multiplierSale, new ItemDescription(BigDecimal.TEN, product, batchName, plantability, BigDecimal.valueOf(20)), null);
        SaleLinkDetail saleLinkDetail = new SaleLinkDetail(multiplierSale, saleItem);
        final Date dealerSaleCreationDate = new Date();
        final Sale dealerSale = createDealerSale(dealerSaleCreationDate);
        final BigDecimal expectedRevenueRecognition = BigDecimal.TEN;
        SaleItem dealerSaleItem = addSaleItemToSale(dealerSale, new ItemDescription(BigDecimal.ONE, product, batchName, plantability, BigDecimal.valueOf(20)), null, null);
        saleLinkDetail.consume(dealerSale, BigDecimal.ONE, dealerSaleItem);
        saleLinkDetail.getSaleLinkDetailValueSet().iterator().next().setRevenueRecognition(expectedRevenueRecognition);
        dealerSaleItem.setSaleLinkDetail(saleLinkDetail);
        dealerSaleItem.setPostingStatus(PostingStatusEnum.REVENUE_RECOGNITION_POSTED);

        BigDecimal actualValue = saleLinkDetail.getRevenueRecognitionFromPreviousCalculations();

        assertThat(actualValue).isEqualTo(expectedRevenueRecognition);
    }

    @Test
    public void testGetRevenueRecognitionFromPreviousCalculationsReturns1_WhenPostedSaleItemsHaveRevenueRecognitionOf1() {
        Sale multiplierSale = createMultiplierSale();
        Product product = createProduct("product 1", false);
        final String batchName = "Batch Name";
        final SaleItem saleItem = addSaleItemToSale(multiplierSale, new ItemDescription(BigDecimal.TEN, product, batchName, plantability, BigDecimal.valueOf(20)), null);
        SaleLinkDetail saleLinkDetail = new SaleLinkDetail(multiplierSale, saleItem);
        final Date dealerSaleCreationDate = new Date();
        final Sale dealerSale = createDealerSale(dealerSaleCreationDate);
        final BigDecimal expectedRevenueRecognition = BigDecimal.ONE;
        SaleItem dealerSaleItem = addSaleItemToSale(dealerSale, new ItemDescription(BigDecimal.ONE, product, batchName, plantability, BigDecimal.valueOf(20)), null, null);
        saleLinkDetail.consume(dealerSale, BigDecimal.ONE, dealerSaleItem);
        saleLinkDetail.getSaleLinkDetailValueSet().iterator().next().setRevenueRecognition(expectedRevenueRecognition);
        dealerSaleItem.setSaleLinkDetail(saleLinkDetail);
        dealerSaleItem.setPostingStatus(PostingStatusEnum.REVENUE_RECOGNITION_POSTED);

        BigDecimal actualValue = saleLinkDetail.getRevenueRecognitionFromPreviousCalculations();

        assertThat(actualValue).isEqualTo(expectedRevenueRecognition);
    }

    @Test
    public void testGetRevenueRecognitionFromPreviousCalculationsReturns0_WhenPostedSaleItemsHaveRevenueRecognitionOf10ButAreNotPosted() {
        Sale multiplierSale = createMultiplierSale();
        Product product = createProduct("product 1", false);
        final String batchName = "Batch Name";
        final SaleItem saleItem = addSaleItemToSale(multiplierSale, new ItemDescription(BigDecimal.TEN, product, batchName, plantability, BigDecimal.valueOf(20)), null);
        SaleLinkDetail saleLinkDetail = new SaleLinkDetail(multiplierSale, saleItem);
        final Date dealerSaleCreationDate = new Date();
        final Sale dealerSale = createDealerSale(dealerSaleCreationDate);
        SaleItem dealerSaleItem = addSaleItemToSale(dealerSale, new ItemDescription(BigDecimal.ONE, product, batchName, plantability, BigDecimal.valueOf(20)), null, BigDecimal.ONE);
        saleLinkDetail.consume(dealerSale, BigDecimal.ONE, dealerSaleItem);
        dealerSaleItem.setSaleLinkDetail(saleLinkDetail);
        dealerSaleItem.setPostingStatus(PostingStatusEnum.NOT_POSTED);

        BigDecimal actualValue = saleLinkDetail.getRevenueRecognitionFromPreviousCalculations();

        assertThat(actualValue).isEqualTo(BigDecimal.ZERO);
    }

}