package com.monsanto.brazilvaluecapture.seedsale.sale.service.impl;

import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import com.monsanto.brazilvaluecapture.core.account.service.DuplicatedCancellationException;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Company;
import com.monsanto.brazilvaluecapture.core.base.model.bean.State;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Customer;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.ParticipantTypeEnum;
import com.monsanto.brazilvaluecapture.core.customer.model.dao.CustomerDAO;
import com.monsanto.brazilvaluecapture.core.customer.model.dao.HeadOfficeDAO;
import com.monsanto.brazilvaluecapture.core.customer.service.CustomerNotAllowedException;
import com.monsanto.brazilvaluecapture.core.customer.service.CustomerNotFoundException;
import com.monsanto.brazilvaluecapture.core.foundation.service.BusinessException;
import com.monsanto.brazilvaluecapture.core.foundation.service.EntityNotFoundException;
import com.monsanto.brazilvaluecapture.core.foundation.service.IndustrySystemOperationException;
import com.monsanto.brazilvaluecapture.core.foundation.service.SystemParameterService;
import com.monsanto.brazilvaluecapture.core.foundation.util.ConstraintViolation;
import com.monsanto.brazilvaluecapture.core.grower.model.bean.Grower;
import com.monsanto.brazilvaluecapture.core.importfile.model.ImportFileType;
import com.monsanto.brazilvaluecapture.core.importfile.model.bean.CsvImportFile;
import com.monsanto.brazilvaluecapture.core.posting.service.PostingService;
import com.monsanto.brazilvaluecapture.core.user.model.bean.ItsUser;
import com.monsanto.brazilvaluecapture.core.user.model.bean.UserDecorator;
import com.monsanto.brazilvaluecapture.core.user.service.DocumentMismatchException;
import com.monsanto.brazilvaluecapture.jobs.importfile.messaging.bean.FileImportDefinition;
import com.monsanto.brazilvaluecapture.jobs.importfile.messaging.bean.FileImportOperation;
import com.monsanto.brazilvaluecapture.jobs.importfile.messaging.service.FileImportDispatcher;
import com.monsanto.brazilvaluecapture.multiplier.obtainer.service.ObtainerPercentageService;
import com.monsanto.brazilvaluecapture.seedsale.billing.model.bean.Billing;
import com.monsanto.brazilvaluecapture.seedsale.billing.model.bean.PaymentStatus;
import com.monsanto.brazilvaluecapture.seedsale.billing.model.dao.BilletTransactionDAO;
import com.monsanto.brazilvaluecapture.seedsale.billing.model.dao.BillingCalendarDao;
import com.monsanto.brazilvaluecapture.seedsale.billing.model.dao.BillingDAO;
import com.monsanto.brazilvaluecapture.seedsale.billing.model.dao.BillingFilter;
import com.monsanto.brazilvaluecapture.seedsale.billing.service.impl.BillingFactory;
import com.monsanto.brazilvaluecapture.seedsale.cashAdvance.service.CashAdvanceService;
import com.monsanto.brazilvaluecapture.seedsale.cashAdvance.service.impl.CashAdvanceConsumptionReversalError;
import com.monsanto.brazilvaluecapture.seedsale.harvest.model.bean.Harvest;
import com.monsanto.brazilvaluecapture.seedsale.harvest.model.bean.Plantability;
import com.monsanto.brazilvaluecapture.seedsale.harvest.model.dao.HarvestDAO;
import com.monsanto.brazilvaluecapture.seedsale.harvest.model.dao.PlantabilityDAO;
import com.monsanto.brazilvaluecapture.seedsale.product.model.bean.Product;
import com.monsanto.brazilvaluecapture.seedsale.product.model.dao.ProductDAO;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.Cancellation;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.Indexable;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.Sale;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.SaleItem;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.dao.MultiplierSaleDAO;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.dao.MultiplierSaleFilter;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.dao.SaleDAO;
import com.monsanto.brazilvaluecapture.seedsale.sale.service.*;
import com.monsanto.brazilvaluecapture.seedsale.sale.validation.MultiplierToDealerSaleValidator;
import com.monsanto.brazilvaluecapture.seedsale.sale.validation.MultiplierToGrowerSaleValidator;
import com.monsanto.brazilvaluecapture.seedsale.template.model.bean.SaleTemplate;
import com.monsanto.brazilvaluecapture.seedsale.template.model.bean.SaleTemplateBillingMethodEnum;
import com.monsanto.brazilvaluecapture.seedsale.template.model.dao.SaleTemplateDAO;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.runners.MockitoJUnitRunner;

import java.math.BigDecimal;
import java.util.*;

import static junit.framework.Assert.*;
import static org.fest.assertions.Assertions.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyString;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.anyLong;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class MultiplierSaleServiceImpl_UT {

    public static final int EXPECTED_VALUE_2 = 2;
    @Mock
    private CustomerDAO customerDAO;
    @Mock
    private HarvestDAO harvestDAO;
    @Mock
    private SaleTemplateDAO saleTemplateDAO;
    @Mock
    private ProductDAO productDAO;
    @Mock
    private PlantabilityDAO plantabilityDAO;
    @Mock
    private MultiplierSaleDAO multiplierSaleDAO;
    @Mock
    private ObtainerPercentageService obtainerPercentageService;
    @Mock
    private SaleService saleService;
    @Mock
    private BillingDAO billingDAO;
    @Mock
    private BilletTransactionDAO billetTransactionDAO;
    @Mock
    private SaleCancellationService cancellationService;
    @Mock
    private FileImportDispatcher fileImportDispatcher;
    @Mock
    private SystemParameterService systemParameterService;
    @Mock
    private SaleDAO saleDAO;
    @Mock
    private MultiplierSaleValidator multiplierSaleValidator;
    @Mock
    private BillingFactory billingFactory;
    @Mock
    private HeadOfficeDAO headOfficeDAO;
    @Mock
    private MultiplierQuotaServiceImpl multiplierQuotaService;
    @Mock
    private AccountManager accountManager;
    @Mock
    private MultiplierToDealerSaleValidator multiplierToDealerSaleValidator;
    @Mock
    private MultiplierToGrowerSaleValidator multiplierToGrowerSaleValidator;
    @Mock
    private CashAdvanceService cashAdvanceService;
    @Mock
    private PostingService postingService;
    @Mock
    private SaleLinkDetailRegister saleLinkDetailRegister;
    @Mock
    private BillingCalendarDao billingCalendarDao;
    @Mock
    private SaleLinkDetailLinker saleLinkDetailLinker;
    @Spy
    @InjectMocks
    private MultiplierSaleServiceImpl multiplierSaleServiceImpl;

    private SaleTemplate saleTemplate;

    @Test
    public void test_getSaleBy() {
        //@When
        MultiplierSaleFilter saleFilter = mock(MultiplierSaleFilter.class);
        multiplierSaleServiceImpl.getSaleBy(saleFilter);

        //@Then
        verify(multiplierSaleDAO).getByFilter(saleFilter);
    }

    @Test
    public void test_getBillingBy() {
        //@When
        BillingFilter billingFilter = mock(BillingFilter.class);
        multiplierSaleServiceImpl.getBillingBy(billingFilter);

        //@Then
        verify(saleService).getBillingBy(billingFilter);
    }

    @Test
    public void given_nullCancellation_when_cancelBillingCompletely_should_throw_BillingCancellationWarningException()
            throws IndustrySystemOperationException {
        //@When
        Long saleCode = 1l;
        List<Company> companies = new ArrayList<Company>();
        Company company = mock(Company.class);
        companies.add(company);
        String userLogin = "someUserLogin";
        try {
            multiplierSaleServiceImpl.cancelBillingCompletely(saleCode, companies, null, userLogin);
            fail("BillingCancellationWarningException is expected on null cancellation");
        } catch (BillingCancellationWarningException e) {
            //@Should
        }
    }

    @Test
    public void given_notNullCancellation_when_cancelBillingCompletely_should_call_cancelBillingReversalPartially()
            throws IndustrySystemOperationException, BillingCancellationWarningException {
        //@When
        Long saleCode = 1l;
        List<Company> companies = new ArrayList<Company>();
        Company company = mock(Company.class);
        companies.add(company);
        Cancellation cancellation = mock(Cancellation.class);
        when(cancellation.isCancelPaidSaleOrder()).thenReturn(true);
        String userLogin = "someUserLogin";

        multiplierSaleServiceImpl.cancelBillingCompletely(saleCode, companies, cancellation, userLogin);
        verify(multiplierSaleServiceImpl).cancelBillingReversalPartially(saleCode, company, cancellation, userLogin);
    }

    @Test
    public void given_billingsToCancel_when_cancelBillingCompletely_should_save_cancelled_Billing()
            throws IndustrySystemOperationException, BillingCancellationWarningException {
        //@Given
        List<Billing> billingsToCancel = new ArrayList<Billing>();
        Billing billing = mock(Billing.class);
        billingsToCancel.add(billing);
        when(saleService.getBillingBy(any(BillingFilter.class))).thenReturn(billingsToCancel);
        Long saleCode = 1l;
        List<Company> companies = new ArrayList<Company>();
        Company company = mock(Company.class);
        companies.add(company);
        Cancellation cancellation = mock(Cancellation.class);
        when(cancellation.isCancelPaidSaleOrder()).thenReturn(true);
        String userLogin = "someUserLogin";
        //@When
        multiplierSaleServiceImpl.cancelBillingCompletely(saleCode, companies, cancellation, userLogin);

        //@Then
        verify(billing).markAsCancel(cancellation);
        verify(billingDAO).save(billing);
    }

    @Test
    public void given_billingsToCancel_when_cancelBillingPartially_should_save_cancelled_Billing()
            throws IndustrySystemOperationException, BillingCancellationWarningException {
        //@Given
        List<Billing> billingsToCancel = new ArrayList<Billing>();
        Billing billing = mock(Billing.class);
        billingsToCancel.add(billing);
        when(saleService.getBillingBy(any(BillingFilter.class))).thenReturn(billingsToCancel);
        Long saleCode = 1l;
        List<Company> companies = new ArrayList<Company>();
        Company company = mock(Company.class);
        companies.add(company);
        Cancellation cancellation = mock(Cancellation.class);
        when(cancellation.isCancelPaidSaleOrder()).thenReturn(true);
        String userLogin = "someUserLogin";
        //@When
        multiplierSaleServiceImpl.cancelBillingPartially(saleCode, company, cancellation, userLogin);

        //@Then
        verify(billing).markAsCancel(cancellation);
        verify(billingDAO).save(billing);
    }

    @Test
    public void given_noBillingsToCancel_when_cancelBillingCompletely_should_throw_BillingCancellationWarningException()
            throws IndustrySystemOperationException, BillingCancellationWarningException {
        //@Given
        List<Billing> billingsToCancel = new ArrayList<Billing>();
        Billing billing = mock(Billing.class);
        when(billing.isPaid()).thenReturn(true);
        when(billing.getBillingMethod()).thenReturn(SaleTemplateBillingMethodEnum.BANKSLIP);
        billingsToCancel.add(billing);
        when(saleService.getBillingBy(any(BillingFilter.class))).thenReturn(billingsToCancel);
        when(saleService.getBillingBy(any(BillingFilter.class))).thenReturn(billingsToCancel);
        Long saleCode = 1l;
        List<Company> companies = new ArrayList<Company>();
        Company company = mock(Company.class);
        companies.add(company);
        Cancellation cancellation = mock(Cancellation.class);
        when(cancellation.isCancelPaidSaleOrder()).thenReturn(true);
        String userLogin = "someUserLogin";
        //@When
        try {
            multiplierSaleServiceImpl.cancelBillingCompletely(saleCode, companies, cancellation, userLogin);
            fail("Should throw BillingCancellationWarningException");
        } catch (BillingCancellationWarningException e) {
            assertThat(e).hasNoCause();
        }
    }

    @Test
    public void given_billingFilter_when_getBillingsOfSale_newDetailedSale_isCreated() {
        //@Given
        List<Billing> expectedBillings = new ArrayList<Billing>();
        BillingFilter billingFilter = mock(BillingFilter.class);
        when(saleService.getBillingBy(billingFilter)).thenReturn(expectedBillings);

        //@When
        DetailedSale detailedSale = multiplierSaleServiceImpl.getBillingsOfSale(billingFilter);

        //@Then
        assertEquals(expectedBillings, detailedSale.getBillings());
    }

    @Test
    public void given_billingFilter_when_getBillingsOfSale1_newDetailedSale_isCreated() {
        //@Given
        List<Billing> expectedBillings = new ArrayList<Billing>();
        BillingFilter billingFilter = mock(BillingFilter.class);
        when(saleService.getBillingBy(billingFilter)).thenReturn(expectedBillings);

        //@When
        PaymentStatus paymentStatus = PaymentStatus.FULLY_PAID;
        DetailedSale detailedSale = multiplierSaleServiceImpl.getBillingsOfSale(billingFilter, paymentStatus);

        //@Then
        assertEquals(expectedBillings, detailedSale.getBillings());
    }

    @Test
    public void given_unexistingSale_when_getSaleForDetailBy_throws_EntityNotFoundException() {
        //@Given
        UserDecorator userDecorator = mock(UserDecorator.class);
        Long saleId = 0l;
        when(multiplierSaleDAO.getById(saleId)).thenReturn(null);

        //@When
        try {
            multiplierSaleServiceImpl.getSaleForDetailBy(saleId, userDecorator);
            fail("Should throw EntityNotFoundException");
        } catch (EntityNotFoundException e) {
            //@Should
        }

    }

    @Test
    public void given_Sale_when_getSaleForDetailBy_then_saleIsUpdated() throws EntityNotFoundException {
        //@Given
        UserDecorator userDecorator = mock(UserDecorator.class);
        when(userDecorator.getType()).thenReturn(ItsUser.UserTypeEnum.PARTICIPANT);
        Long saleId = 0l;
        Sale sale = mock(Sale.class);
        Set<SaleItem> saleItems = new HashSet<SaleItem>();
        SaleItem saleItem = mock(SaleItem.class);
        when(saleItem.getPlantability()).thenReturn("somePlantabilityDescription");
        Plantability plantability = mock(Plantability.class);
        when(plantability.isSystem()).thenReturn(true);
        when(plantabilityDAO.selectBy(anyString(), any(Harvest.class))).thenReturn(plantability);
        saleItems.add(saleItem);
        when(sale.getItems()).thenReturn(saleItems);
        when(multiplierSaleDAO.getById(saleId)).thenReturn(sale);

        //@When
        Sale resultSale = multiplierSaleServiceImpl.getSaleForDetailBy(saleId, userDecorator);

        //@Then
        assertFalse(resultSale.getItems().isEmpty());
    }

    @Test
    public void test_getMultiplierSaleExtract() {
        //@Given
        BillingFilter billingFilter = mock(BillingFilter.class);
        List<Billing> billingList = new ArrayList<Billing>();
        when(billingDAO.getByFilter(billingFilter)).thenReturn(billingList);

        //@Then
        Sale sale = mock(Sale.class);
        assertNotNull(multiplierSaleServiceImpl.createMultiplierSaleExtract(sale));
    }

    @Test
    public void given_Cancellation_and_SaleList_when_handleCancelMultipleSales_should_CancelSales()
            throws IndustrySystemOperationException, BillingCancellationWarningException {
        //@Given
        Long saleCode = 1l;
        final List<Company> companies = new ArrayList<Company>();
        final Company company = mock(Company.class);
        companies.add(company);
        Cancellation cancellation = mock(Cancellation.class);
        when(cancellation.isCancelPaidSaleOrder()).thenReturn(true);
        String userLogin = "someUserLogin";
        List<Sale> sales = new ArrayList<Sale>();
        Sale sale = new Sale();
        sale.setSaleType(Sale.SaleTypeEnum.MULTIPLIER_SEED_SALE);
        sale.setId(saleCode);
        sales.add(sale);

        //@When
        multiplierSaleServiceImpl.cancelMultipleSales(sales, companies, cancellation, userLogin);

        //@Should
        verify(multiplierSaleServiceImpl).cancelBillingCompletely(saleCode, companies, cancellation, userLogin);
    }

    @Test
    public void given_Cancellation_and_SaleList_when_cancelBillingCompletely_throws_BillingCancellationWarningException_handleCancelMultipleSales_throw_BillingCancellationWarningException()
            throws IndustrySystemOperationException, BillingCancellationWarningException {
        //@Given
        Long saleCode = 1l;
        List<Company> companies = new ArrayList<Company>();
        Company company = mock(Company.class);
        companies.add(company);
        Cancellation cancellation = mock(Cancellation.class);
        when(cancellation.isCancelPaidSaleOrder()).thenReturn(true);
        String userLogin = "someUserLogin";
        List<Sale> sales = new ArrayList<Sale>();
        Sale sale = new Sale();
        sale.setSaleType(Sale.SaleTypeEnum.MULTIPLIER_SEED_SALE);
        Customer customer = new Customer("someCustomerName", null, null, "someSAPCode");
        sale.setCustomer(customer);
        sale.setInvoiceNumber("someInvoiceNumber");
        sale.setCreationDate(new Date());
        sale.setId(saleCode);
        sales.add(sale);

        BillingCancellationWarningException exception = new BillingCancellationWarningException("someMessage");
        exception.add(mock(ConstraintViolation.class));
        doThrow(exception).when(multiplierSaleServiceImpl).cancelBillingCompletely(saleCode, companies, cancellation, userLogin);

        try {
            //@When
            multiplierSaleServiceImpl.cancelMultipleSales(sales, companies, cancellation, userLogin);
            fail("Should throw BillingCancellationWarningException");
        } catch (BillingCancellationWarningException e) {
            //@Should
        }
    }

    @Test
    public void given_Cancellation_and_SaleList_when_cancelBillingCompletely_throws_IllegalArgumentException_handleCancelMultipleSales_throw_BillingCancellationWarningException()
            throws IndustrySystemOperationException, BillingCancellationWarningException {
        //@Given
        Long saleCode = 1l;
        List<Company> companies = new ArrayList<Company>();
        Company company = mock(Company.class);
        companies.add(company);
        Cancellation cancellation = mock(Cancellation.class);
        when(cancellation.isCancelPaidSaleOrder()).thenReturn(true);
        String userLogin = "someUserLogin";
        List<Sale> sales = new ArrayList<Sale>();
        Sale sale = new Sale();
        sale.setSaleType(Sale.SaleTypeEnum.MULTIPLIER_SEED_SALE);
        Customer customer = new Customer("someCustomerName", null, null, "someSAPCode");
        sale.setCustomer(customer);
        sale.setInvoiceNumber("someInvoiceNumber");
        sale.setCreationDate(new Date());
        sale.setId(saleCode);
        sales.add(sale);

        IllegalArgumentException exception = new IllegalArgumentException();
        doThrow(exception).when(multiplierSaleServiceImpl).cancelBillingCompletely(saleCode, companies, cancellation, userLogin);

        try {
            //@When
            multiplierSaleServiceImpl.cancelMultipleSales(sales, companies, cancellation, userLogin);
            fail("Should throw BillingCancellationWarningException");
        } catch (BillingCancellationWarningException e) {
            //@Should
        }
    }

    @Test
    public void testHandleCancelMultipleSalesReturnsQuotaFromDealerToMultiplier_WhenSaleTypeIsMULTIPLIER_SEED_SALE() throws InsufficientMultiplierQuotaException, BillingCancellationWarningException {
        Sale sale = new Sale();
        sale.setSaleType(Sale.SaleTypeEnum.MULTIPLIER_SEED_SALE);
        Collection<Sale> sales = Lists.newArrayList(sale);
        List<Company> companies = Lists.newArrayList();
        Cancellation cancellation = new Cancellation();
        String userLogin = "userLogin";

        multiplierSaleServiceImpl.cancelMultipleSales(sales, companies, cancellation, userLogin);

        verify(multiplierQuotaService).returnQuotaFromDealerToMultiplier(sale);
    }

    @Test
    public void testHandleCancelMultipleSalesRevertsMultiplierQuotaConsumption_WhenSaleTypeIsMULTIPLIER_TO_GROWER_SEED_SALE() throws BusinessException {
        final Company company = new Company("Company");
        List<Company> companies = Lists.newArrayList(company);
        Sale sale = new Sale() {
            @Override
            public Set<Company> getCompanies() {
                return Sets.newHashSet(company);
            }
        };
        sale.setSaleType(Sale.SaleTypeEnum.MULTIPLIER_TO_GROWER_SEED_SALE);
        Collection<Sale> sales = Lists.newArrayList(sale);
        Cancellation cancellation = new Cancellation();
        String userLogin = "userLogin";

        multiplierSaleServiceImpl.cancelMultipleSales(sales, companies, cancellation, userLogin);

        verify(multiplierQuotaService).returnQuotaFromGrowerToMultiplier(sale);
    }

    @Test
    public void given_Cancellation_and_SaleList_when_cancelBillingCompletely_throws_DuplicatedCancellationException_handleCancelMultipleSales_throw_BillingCancellationWarningException()
            throws IndustrySystemOperationException, BillingCancellationWarningException {
        //@Given
        Long saleCode = 1l;
        List<Company> companies = new ArrayList<Company>();
        Company company = mock(Company.class);
        companies.add(company);
        Cancellation cancellation = mock(Cancellation.class);
        when(cancellation.isCancelPaidSaleOrder()).thenReturn(true);
        String userLogin = "someUserLogin";
        List<Sale> sales = new ArrayList<Sale>();
        Sale sale = new Sale();
        sale.setSaleType(Sale.SaleTypeEnum.MULTIPLIER_SEED_SALE);
        Customer customer = new Customer("someCustomerName", null, null, "someSAPCode");
        sale.setCustomer(customer);
        sale.setInvoiceNumber("someInvoiceNumber");
        sale.setCreationDate(new Date());
        sale.setId(saleCode);
        sales.add(sale);

        DuplicatedCancellationException exception = new DuplicatedCancellationException("someMessage", 1l);
        doThrow(exception).when(multiplierSaleServiceImpl).cancelBillingCompletely(saleCode, companies, cancellation, userLogin);

        try {
            //@When
            multiplierSaleServiceImpl.cancelMultipleSales(sales, companies, cancellation, userLogin);
            fail("Should throw BillingCancellationWarningException");
        } catch (BillingCancellationWarningException e) {
            //@Should
        }
    }

    @Test
    public void given_Cancellation_and_SaleList_when_cancelBillingCompletely_throws_UnknowsException_handleCancelMultipleSales_throw_BillingCancellationWarningException()
            throws IndustrySystemOperationException, BillingCancellationWarningException {
        //@Given
        Long saleCode = 1l;
        List<Company> companies = new ArrayList<Company>();
        Company company = mock(Company.class);
        companies.add(company);
        Cancellation cancellation = mock(Cancellation.class);
        when(cancellation.isCancelPaidSaleOrder()).thenReturn(true);
        String userLogin = "someUserLogin";
        List<Sale> sales = new ArrayList<Sale>();
        Sale sale = new Sale();
        sale.setSaleType(Sale.SaleTypeEnum.MULTIPLIER_SEED_SALE);
        Customer customer = new Customer("someCustomerName", null, null, "someSAPCode");
        sale.setCustomer(customer);
        sale.setInvoiceNumber("someInvoiceNumber");
        sale.setCreationDate(new Date());
        sale.setId(saleCode);
        sales.add(sale);

        doThrow(Exception.class).when(multiplierSaleServiceImpl).cancelBillingCompletely(saleCode, companies, cancellation, userLogin);

        try {
            //@When
            multiplierSaleServiceImpl.cancelMultipleSales(sales, companies, cancellation, userLogin);
            fail("Should throw BillingCancellationWarningException");
        } catch (BillingCancellationWarningException e) {
            //@Should
            assertThat(e).hasNoCause();
        }
    }

    @Test
    public void test_getCancellations() {
        //@When
        multiplierSaleServiceImpl.getCancellations();

        //@Then
        verify(saleService).getCancellations();
    }

    @Test
    public void on_asynchronousCancellation_then_sale_are_asynchronously_cancelled() {
        //@Given
        String fileName = "someFileName";
        String userLogin = "someUserLogin";
        ImportFileType importFileType = ImportFileType.MULTIPLIER_SALE_CANCELLATION;
        Cancellation cancellation = mock(Cancellation.class);
        List<Sale> sales = new ArrayList<Sale>();
        CsvImportFile csvImportFile = mock(CsvImportFile.class);
        UserDecorator user = mock(UserDecorator.class);
        FileImportDefinition fileImportDefinition = FileImportDefinition.MULTIPLIER_SALE_CANCELLATION;
        FileImportOperation fileImportOperation = FileImportOperation.PROCEED;
        Locale locale = Locale.getDefault();
        String bundleName = "someBundleName";

        //@When
        when(cancellationService.saveRequestCancellation(fileName, userLogin, importFileType, sales, cancellation)).thenReturn(csvImportFile);
        doNothing().when(fileImportDispatcher).sendFileImportRequest(csvImportFile, user, fileImportDefinition, fileImportOperation, locale, bundleName);
        multiplierSaleServiceImpl.asynchronousCancellation(sales, cancellation, userLogin, fileName, locale, bundleName, user);

        //@Should
        verify(cancellationService).saveRequestCancellation(fileName, userLogin, importFileType, sales, cancellation);
        verify(fileImportDispatcher).sendFileImportRequest(csvImportFile, user, fileImportDefinition, fileImportOperation, locale, bundleName);
    }

    @Test
    public void test_getCustomerById() {
        //@When
        Long customerId = 100l;
        multiplierSaleServiceImpl.getCustomerById(customerId);

        //@Should
        verify(saleService).getCustomerById(customerId);
    }

    @Test
    public void test_getPlantabilitiesBy() {
        //@When
        State state = new State();
        Harvest harvest = new Harvest();
        Product product = new Product();
        multiplierSaleServiceImpl.getPlantabilitiesBy(state, harvest, product);

        //@Should
        verify(saleService).getPlantabilitiesBy(state, harvest, product);
    }

    @Test
    public void testSaveMultiplierToDealerSale_ValidatesSale() throws SaleConstraintViolationException {
        //@Given a Sale in an invalid state
        Sale sale = mock(Sale.class);
        SaleConstraintViolationException violationException = new SaleConstraintViolationException("someMessage");
        violationException.add(new ConstraintViolation("someMessage", "someCode", "someField"));
        doThrow(violationException).when(multiplierToDealerSaleValidator).validate(sale);

        //@When the sale is saved
        try {
            multiplierSaleServiceImpl.saveMultiplierToDealerSale(sale);
            fail("Sale is not validated");
        } catch (SaleConstraintViolationException e) {
            //@Then a validation constrains violation exception is thrown
        }
    }

    @Test
    public void testSaveSaleTransferQuotafromMultiplierToDealer_WhenSaleIsSaved() throws Exception {
        //@Given
        Sale sale = new Sale();
        SaleConstraintViolationException violationException = new SaleConstraintViolationException("someMessage");
        when(multiplierSaleValidator.validate(sale)).thenReturn(violationException);
        stubbSaleDaoSaveMethod(sale);

        //@When
        multiplierSaleServiceImpl.saveMultiplierToDealerSale(sale);

        //@Then
        verify(multiplierQuotaService).transferQuotaFromMultiplierToDealer(sale);
    }

    private void stubbSaleDaoSaveMethod(Sale sale) {
        when(saleDAO.save(sale)).thenReturn(sale);
    }

    @Test
    public void testSaveSaleInvokesMultiplierToDealerSaleValidator_WhenSavingTheSale() throws SaleConstraintViolationException {
        Sale sale = new Sale();
        stubbSaleDaoSaveMethod(sale);

        multiplierSaleServiceImpl.saveMultiplierToDealerSale(sale);

        verify(multiplierToDealerSaleValidator).validate(sale);
    }

    @Test
    public void testSaveSaleThrowsSaleConstraintViolationException_WhenMultiplierHasNoEnoughQuota() throws BusinessException {
        //@Given
        Sale sale = new Sale();
        SaleConstraintViolationException violationException = new SaleConstraintViolationException("someMessage");
        when(multiplierSaleValidator.validate(sale)).thenReturn(violationException);
        final SaleConstraintViolationException toBeThrown = new SaleConstraintViolationException("SaleValidator found errors in sale");
        toBeThrown.add(new ConstraintViolation("", "", ""));
        doThrow(toBeThrown).when(multiplierQuotaService).transferQuotaFromMultiplierToDealer(sale);

        try {
            //@When
            multiplierSaleServiceImpl.saveMultiplierToDealerSale(sale);
            fail("Should throe SaleConstraintViolationException");
        } catch (Exception e) {
            //@Then
            assertThat(e).isInstanceOf(SaleConstraintViolationException.class).hasMessage("SaleValidator found errors in sale");
            SaleConstraintViolationException exception = (SaleConstraintViolationException) e;
            assertThat(exception.getViolations()).isNotEmpty();
        }

    }

    @Test
    public void testSaveMultiplierToDealerSale_SavesSale() throws SaleConstraintViolationException {
        //@Given a Sale in a valid state
        Sale sale = new Sale();
        stubbSaleDaoSaveMethod(sale);
        SaleConstraintViolationException saleConstraintViolationException = mock(SaleConstraintViolationException.class);
        when(saleConstraintViolationException.isEmpty()).thenReturn(Boolean.TRUE);
        when(multiplierSaleValidator.validate(sale)).thenReturn(saleConstraintViolationException);
        //@And a user
        mock(UserDecorator.class);
        Billing billing = new Billing();
        when(billingFactory.buildBilling(sale)).thenReturn(Lists.newArrayList(billing));

        //@When the sale is saved
        multiplierSaleServiceImpl.saveMultiplierToDealerSale(sale);

        //@Should create a sale and corresponding billings
        verify(billingDAO).save(billing);
    }

    @Test
    public void test_saveMultiplierToDealerCSVSale() throws SaleConstraintViolationException {
        //@Given
        Sale sale = new Sale();
        stubbSaleDaoSaveMethod(sale);
        UserDecorator userDecorator = new UserDecorator(null, null);

        //@When
        multiplierSaleServiceImpl.saveMultiplierToDealerCSVSale(sale, userDecorator);

        //@Should
        //verify(multiplierSaleServiceImpl).saveMultiplierToDealerSale(sale);
        verify(saleDAO).save(sale);
    }

    @Test
    public void test_saveMultiplierToGrowerCSVSale() throws SaleConstraintViolationException {
        //@Given
        Sale sale = new Sale();
        stubbSaleDaoSaveMethod(sale);
        UserDecorator userDecorator = new UserDecorator(null, null);

        //@When
        multiplierSaleServiceImpl.saveMultiplierToGrowerCSVSale(sale, userDecorator);

        //@Should
        //verify(multiplierSaleServiceImpl).saveMultiplierToGrowerSale(sale);
        verify(saleDAO).save(sale);
    }

    @Test
    public void testHandleCancelMultipleSalesInvokesCashAdvanceServiceRevertCashAdvanceDebitFromSale_WhenRevertingSales()
            throws BillingCancellationWarningException, CashAdvanceConsumptionReversalError {
        Sale sale = new Sale();
        sale.setSaleType(Sale.SaleTypeEnum.MULTIPLIER_SEED_SALE);
        Collection<Sale> sales = Lists.newArrayList(sale);
        List<Company> companies = Lists.newArrayList();
        Cancellation cancellation = new Cancellation();
        String userLogin = "userLogin";

        multiplierSaleServiceImpl.cancelMultipleSales(sales, companies, cancellation, userLogin);

        verify(cashAdvanceService).revertCashAdvanceDebitFromSale(any(Sale.class));
    }

    @Test
    public void testHandleCancelMultipleSalesHandlesCashAdvanceServiceRevertCashAdvanceDebitFromSaleException_WhenRevertingSales()
            throws CashAdvanceConsumptionReversalError {
        Sale sale = new Sale();
        sale.setSaleType(Sale.SaleTypeEnum.MULTIPLIER_SEED_SALE);
        Collection<Sale> sales = Lists.newArrayList(sale);
        List<Company> companies = Lists.newArrayList();
        Cancellation cancellation = new Cancellation();
        String userLogin = "userLogin";
        final String expectedErrorMessage = "Expected error message";
        CashAdvanceConsumptionReversalError expectedException = new CashAdvanceConsumptionReversalError(expectedErrorMessage);
        doThrow(expectedException).when(cashAdvanceService).revertCashAdvanceDebitFromSale(sale);

        try {
            multiplierSaleServiceImpl.cancelMultipleSales(sales, companies, cancellation, userLogin);
            fail("Should throw BillingCancellationWarningException");
        } catch (BillingCancellationWarningException e) {
            assertThat(e.getViolations()).onProperty("field").contains(expectedErrorMessage);
        }
    }

    @Test
    public void test_saveFileAndLines() {
        //@Given
        CsvImportFile file = new CsvImportFile();
        List<Indexable> lines = new ArrayList<Indexable>();

        //@When
        multiplierSaleServiceImpl.saveFileAndLines(file, lines);

        //@Should
        verify(saleService).saveFileAndLines(file, lines);
    }

    @Test
    public void test_getAllowedBy() throws CustomerNotAllowedException, CustomerNotFoundException, DocumentMismatchException {
        //@Given

        //@When
        String documentNumber = "someDocumentNumber";
        ParticipantTypeEnum participantType = ParticipantTypeEnum.MULTIPLICADOR;
        UserDecorator userDecorator = new UserDecorator(null, null);
        multiplierSaleServiceImpl.getAllowedBy(documentNumber, documentNumber, documentNumber, participantType, userDecorator);

        //@Should
        verify(saleService).getAllowedBy(documentNumber, documentNumber, documentNumber, participantType, userDecorator);
    }

    @Test
    public void technology_value_culation_test() throws BusinessException {
        //@Given
        BigDecimal priceByHa = new BigDecimal(115);
        BigDecimal productivityValue = new BigDecimal(54.444);
        long soldQuantity = 3000L;
        BigDecimal expectedTechnologyValue = new BigDecimal("6330.00");

        //@When
        BigDecimal actualTechnologyValue = multiplierSaleServiceImpl.calculateTechnologyValue(priceByHa, productivityValue, soldQuantity, BigDecimal.ZERO);

        //@Should
        assertThat(actualTechnologyValue.toString()).isEqualTo(expectedTechnologyValue.toString());
    }

    @Test
    public void technology_value_culation_round_test() throws BusinessException {
        //@Given
        BigDecimal priceByHa = new BigDecimal(115);
        BigDecimal productivityValue = new BigDecimal(66.66);
        long soldQuantity = 1L;
        BigDecimal expectedTechnologyValue = new BigDecimal("1.73");

        //@When
        BigDecimal actualTechnologyValue = multiplierSaleServiceImpl.calculateTechnologyValue(priceByHa, productivityValue, soldQuantity, BigDecimal.ZERO);

        //@Should
        assertThat(actualTechnologyValue.toString()).isEqualTo(expectedTechnologyValue.toString());
    }

    @Test
    public void technology_value_calculation_round_with_discount_test() throws BusinessException {
        //@Given
        BigDecimal priceValue = new BigDecimal(100);
        BigDecimal discountValue = new BigDecimal(15);
        BigDecimal priceByHa = priceValue.add(discountValue);
        BigDecimal productivityValue = new BigDecimal(66.66);
        long soldQuantity = 1L;

        BigDecimal expectedDiscountRoyaltyValueQuantity = new BigDecimal("0.23");
        BigDecimal expectedTotalRoyaltyValue = new BigDecimal("1.73");
        BigDecimal expectedNetRoyaltyValueQuantity = new BigDecimal("1.50");

        BigDecimal discountRoyaltyValueQuantity = multiplierSaleServiceImpl.calculateDiscountRoyaltyValue(soldQuantity, discountValue, productivityValue);
        BigDecimal totalRoyaltyValue = multiplierSaleServiceImpl.calculateTotalRoyaltyValue(soldQuantity, priceByHa, productivityValue);
        BigDecimal netRoyaltyValueQuantity = multiplierSaleServiceImpl.calculateNetRoyaltyValue(totalRoyaltyValue, discountRoyaltyValueQuantity);

        assertThat(discountRoyaltyValueQuantity.toString()).isEqualTo(expectedDiscountRoyaltyValueQuantity.toString());
        assertThat(totalRoyaltyValue.toString()).isEqualTo(expectedTotalRoyaltyValue.toString());
        assertThat(netRoyaltyValueQuantity.toString()).isEqualTo(expectedNetRoyaltyValueQuantity.toString());

    }

    @Test
    public void technology_value_calculation_round_with_discount_test2() throws BusinessException {
        //@Given
        BigDecimal priceValue = new BigDecimal(99);
        BigDecimal discountValue = new BigDecimal(16);
        BigDecimal priceByHa = priceValue.add(discountValue);
        BigDecimal productivityValue = new BigDecimal(39.2);
        long soldQuantity = 1L;

        BigDecimal expectedDiscountRoyaltyValueQuantity = new BigDecimal("0.41");
        BigDecimal expectedTotalRoyaltyValue = new BigDecimal("2.93");
        BigDecimal expectedNetRoyaltyValueQuantity = new BigDecimal("2.52");

        BigDecimal discountRoyaltyValueQuantity = multiplierSaleServiceImpl.calculateDiscountRoyaltyValue(soldQuantity, discountValue, productivityValue);
        BigDecimal totalRoyaltyValue = multiplierSaleServiceImpl.calculateTotalRoyaltyValue(soldQuantity, priceByHa, productivityValue);
        BigDecimal netRoyaltyValueQuantity = multiplierSaleServiceImpl.calculateNetRoyaltyValue(totalRoyaltyValue, discountRoyaltyValueQuantity);

        assertThat(discountRoyaltyValueQuantity.toString()).isEqualTo(expectedDiscountRoyaltyValueQuantity.toString());
        assertThat(totalRoyaltyValue.toString()).isEqualTo(expectedTotalRoyaltyValue.toString());
        assertThat(netRoyaltyValueQuantity.toString()).isEqualTo(expectedNetRoyaltyValueQuantity.toString());

    }

    @Test
    public void technology_value_calculation_round_with_discount_and_enough_cash_advance_test() throws BusinessException {
        //@Given
        BigDecimal priceValue = new BigDecimal(99);
        BigDecimal discountValue = new BigDecimal(16);
        BigDecimal priceByHa = priceValue.add(discountValue);
        BigDecimal productivityValue = new BigDecimal(39.2);
        BigDecimal cashAdvanceBalance = new BigDecimal(300);
        long soldQuantity = 101L;

        BigDecimal expectedDiscountRoyaltyValueQuantity = new BigDecimal("41.41");
        BigDecimal expectedTotalRoyaltyValue = new BigDecimal("295.93");
        BigDecimal expectedNetRoyaltyValueQuantity = new BigDecimal("254.52");
        BigDecimal expectedPrepaidRoyaltyValue = new BigDecimal("254.52");

        //@When
        BigDecimal discountRoyaltyValueQuantity = multiplierSaleServiceImpl.calculateDiscountRoyaltyValue(soldQuantity, discountValue, productivityValue);
        BigDecimal totalRoyaltyValue = multiplierSaleServiceImpl.calculateTotalRoyaltyValue(soldQuantity, priceByHa, productivityValue);
        BigDecimal netRoyaltyValueQuantity = multiplierSaleServiceImpl.calculateNetRoyaltyValue(totalRoyaltyValue, discountRoyaltyValueQuantity);
        BigDecimal prepaidRoyaltyValueQuantity = multiplierSaleServiceImpl.calculatePrepaidRoyaltyValue(netRoyaltyValueQuantity, cashAdvanceBalance);

        //@Then
        assertThat(discountRoyaltyValueQuantity.toString()).isEqualTo(expectedDiscountRoyaltyValueQuantity.toString());
        assertThat(totalRoyaltyValue.toString()).isEqualTo(expectedTotalRoyaltyValue.toString());
        assertThat(netRoyaltyValueQuantity.toString()).isEqualTo(expectedNetRoyaltyValueQuantity.toString());
        assertThat(prepaidRoyaltyValueQuantity.toString()).isEqualTo(expectedPrepaidRoyaltyValue.toString());

    }

    @Test
    public void technology_value_calculation_round_with_discount_and_not_enough_cash_advance_test() throws BusinessException {
        //@Given
        BigDecimal priceValue = new BigDecimal(99);
        BigDecimal discountValue = new BigDecimal(16);
        BigDecimal priceByHa = priceValue.add(discountValue);
        BigDecimal productivityValue = new BigDecimal(39.2);
        BigDecimal cashAdvanceBalance = new BigDecimal(100);
        long soldQuantity = 101L;

        BigDecimal expectedDiscountRoyaltyValueQuantity = new BigDecimal("41.41");
        BigDecimal expectedTotalRoyaltyValue = new BigDecimal("295.93");
        BigDecimal expectedNetRoyaltyValueQuantity = new BigDecimal("254.52");
        BigDecimal expectedPrepaidRoyaltyValue = new BigDecimal("254.52");

        //@When
        BigDecimal discountRoyaltyValueQuantity = multiplierSaleServiceImpl.calculateDiscountRoyaltyValue(soldQuantity, discountValue, productivityValue);
        BigDecimal totalRoyaltyValue = multiplierSaleServiceImpl.calculateTotalRoyaltyValue(soldQuantity, priceByHa, productivityValue);
        BigDecimal netRoyaltyValueQuantity = multiplierSaleServiceImpl.calculateNetRoyaltyValue(totalRoyaltyValue, discountRoyaltyValueQuantity);
        BigDecimal prepaidRoyaltyValueQuantity = multiplierSaleServiceImpl.calculatePrepaidRoyaltyValue(netRoyaltyValueQuantity, cashAdvanceBalance);

        //@Then
        assertThat(discountRoyaltyValueQuantity.toString()).isEqualTo(expectedDiscountRoyaltyValueQuantity.toString());
        assertThat(totalRoyaltyValue.toString()).isEqualTo(expectedTotalRoyaltyValue.toString());
        assertThat(netRoyaltyValueQuantity.toString()).isEqualTo(expectedNetRoyaltyValueQuantity.toString());
        assertThat(prepaidRoyaltyValueQuantity.toString()).isEqualTo(expectedPrepaidRoyaltyValue.toString());

    }

    @Test
    public void technology_value_calculation_round_with_discount_and_no_cash_advance_test() throws BusinessException {
        //@Given
        BigDecimal priceValue = new BigDecimal(99);
        BigDecimal discountValue = new BigDecimal(16);
        BigDecimal priceByHa = priceValue.add(discountValue);
        BigDecimal productivityValue = new BigDecimal(39.2);
        BigDecimal cashAdvanceBalance = new BigDecimal(0);
        long soldQuantity = 101L;

        BigDecimal expectedDiscountRoyaltyValueQuantity = new BigDecimal("41.41");
        BigDecimal expectedTotalRoyaltyValue = new BigDecimal("295.93");
        BigDecimal expectedNetRoyaltyValueQuantity = new BigDecimal("254.52");
        BigDecimal expectedPrepaidRoyaltyValue = new BigDecimal("0");

        //@When
        BigDecimal discountRoyaltyValueQuantity = multiplierSaleServiceImpl.calculateDiscountRoyaltyValue(soldQuantity, discountValue, productivityValue);
        BigDecimal totalRoyaltyValue = multiplierSaleServiceImpl.calculateTotalRoyaltyValue(soldQuantity, priceByHa, productivityValue);
        BigDecimal netRoyaltyValueQuantity = multiplierSaleServiceImpl.calculateNetRoyaltyValue(totalRoyaltyValue, discountRoyaltyValueQuantity);
        BigDecimal prepaidRoyaltyValueQuantity = multiplierSaleServiceImpl.calculatePrepaidRoyaltyValue(netRoyaltyValueQuantity, cashAdvanceBalance);

        //@Then
        assertThat(discountRoyaltyValueQuantity.toString()).isEqualTo(expectedDiscountRoyaltyValueQuantity.toString());
        assertThat(totalRoyaltyValue.toString()).isEqualTo(expectedTotalRoyaltyValue.toString());
        assertThat(netRoyaltyValueQuantity.toString()).isEqualTo(expectedNetRoyaltyValueQuantity.toString());
        assertThat(prepaidRoyaltyValueQuantity.toString()).isEqualTo(expectedPrepaidRoyaltyValue.toString());

    }

    @Test
    public void technology_value_calculation_round_with_discount_and_null_cash_advance_test() throws BusinessException {
        //@Given
        BigDecimal priceValue = new BigDecimal(99);
        BigDecimal discountValue = new BigDecimal(16);
        BigDecimal priceByHa = priceValue.add(discountValue);
        BigDecimal productivityValue = new BigDecimal(39.2);
        long soldQuantity = 101L;

        BigDecimal expectedDiscountRoyaltyValueQuantity = new BigDecimal("41.41");
        BigDecimal expectedTotalRoyaltyValue = new BigDecimal("295.93");
        BigDecimal expectedNetRoyaltyValueQuantity = new BigDecimal("254.52");
        BigDecimal expectedPrepaidRoyaltyValue = new BigDecimal("0");

        //@When
        BigDecimal discountRoyaltyValueQuantity = multiplierSaleServiceImpl.calculateDiscountRoyaltyValue(soldQuantity, discountValue, productivityValue);
        BigDecimal totalRoyaltyValue = multiplierSaleServiceImpl.calculateTotalRoyaltyValue(soldQuantity, priceByHa, productivityValue);
        BigDecimal netRoyaltyValueQuantity = multiplierSaleServiceImpl.calculateNetRoyaltyValue(totalRoyaltyValue, discountRoyaltyValueQuantity);
        BigDecimal prepaidRoyaltyValueQuantity = multiplierSaleServiceImpl.calculatePrepaidRoyaltyValue(netRoyaltyValueQuantity, null);

        //@Then
        assertThat(discountRoyaltyValueQuantity.toString()).isEqualTo(expectedDiscountRoyaltyValueQuantity.toString());
        assertThat(totalRoyaltyValue.toString()).isEqualTo(expectedTotalRoyaltyValue.toString());
        assertThat(netRoyaltyValueQuantity.toString()).isEqualTo(expectedNetRoyaltyValueQuantity.toString());
        assertThat(prepaidRoyaltyValueQuantity.toString()).isEqualTo(expectedPrepaidRoyaltyValue.toString());

    }

    @Test
    public void technologyValueCalculationDtoWithErrorKgByHaNullTest() throws BusinessException {

        BigDecimal totalRoyaltyValue = multiplierSaleServiceImpl.calculateTechnologyValue(new BigDecimal(10), null, null, null);

        Assert.assertNull(totalRoyaltyValue);
    }

    @Test
    public void technologyValueCalculationDtoWithErrorSoldQuantityNullTest() throws BusinessException {

        BigDecimal totalRoyaltyValue = multiplierSaleServiceImpl.calculateTechnologyValue(new BigDecimal(10), new BigDecimal(100), null, null);

        Assert.assertNull(totalRoyaltyValue);
    }

    @Test
    public void when_calculateSaleAmountHa_receives_null_then_returns_null() {
        assertNull(multiplierSaleServiceImpl.calculateSaleAmountHa(BigDecimal.ONE, null));
        assertNull(multiplierSaleServiceImpl.calculateSaleAmountHa(null, new Long(1)));
    }

    @Test
    public void test_isPermitedMultiplier() {
        //@Given
        Customer customer = mock(Customer.class);
        when(customer.getDocumentValue()).thenReturn("someDocValue");
        when(customer.getId()).thenReturn(1l);

        SaleItem saleItem = mock(SaleItem.class);
        SaleTemplate mockSaleTemplate = mock(SaleTemplate.class);
        when(mockSaleTemplate.getId()).thenReturn(1l);
        when(saleItem.getSaleTemplate()).thenReturn(mockSaleTemplate);
        Sale mockSale = mock(Sale.class);
        when(mockSale.getCustomer()).thenReturn(customer);
        when(saleItem.getSale()).thenReturn(mockSale);

        //@When
        multiplierSaleServiceImpl.isPermitedMultiplier(saleItem, customer);

        //@Should
        verify(headOfficeDAO).isPermited(anyLong(), anyString(), anyLong(), any(ParticipantTypeEnum.class));
    }

    @Test
    public void test_isHarvestHeadOfficeRelated() {
        //@Given
        SaleItem saleItem = mock(SaleItem.class);

        //@When
        multiplierSaleServiceImpl.isHarvestHeadOfficeRelated(saleItem);

        //@Should
        verify(harvestDAO).isHarvestHeadOfficeRelated(saleItem);
    }

    @Test
    public void testSaveMultiplierToGrowerSaleInvokesSaleDAO_WhenSavingSale() throws SaleConstraintViolationException {
        Sale sale = new Sale();
        when(multiplierSaleValidator.validate(sale)).thenReturn(new SaleConstraintViolationException(""));

        multiplierSaleServiceImpl.saveMultiplierToGrowerSale(sale);

        verify(saleDAO).save(sale);
    }

    @Test
    public void testSaveMultiplierToGrowerSaleInvokesMultiplierSaleValidator_WhenSavingSale() throws SaleConstraintViolationException {
        Sale sale = new Sale();
        when(multiplierSaleValidator.validate(sale)).thenReturn(new SaleConstraintViolationException(""));

        multiplierSaleServiceImpl.saveMultiplierToGrowerSale(sale);

        verify(multiplierToGrowerSaleValidator).validate(sale);
    }

    @Test
    public void testSaveMultiplierToGrowerSaleInvokesSaleServiceGenerateBonusforSale_WhenSavingSale() throws SaleConstraintViolationException {

        Sale sale = new Sale();
        Sale savedSale = new Sale();
        savedSale.setId(10l);
        when(multiplierSaleValidator.validate(sale)).thenReturn(new SaleConstraintViolationException(""));
        when(saleDAO.save(sale)).thenReturn(savedSale);

        multiplierSaleServiceImpl.saveMultiplierToGrowerSale(sale);

        verify(saleService).calculateBonusForSale(sale);
        verify(saleService).saveBonusForSale(savedSale);
    }

    @Test
    public void testHandleCancelMultipleSalesCancelsBonus_WhenSaleIsCancelledOfTypeMULTIPLIER_TO_GROWER_SEED_SALE() throws Exception {

        final Company company = new Company("Company");
        Sale sale = new Sale() {
            @Override
            public Set<Company> getCompanies() {
                return Sets.newHashSet(company);
            }
        };
        sale.setId(3l);
        List<Company> companies = Lists.newArrayList(company);
        sale.setSaleType(Sale.SaleTypeEnum.MULTIPLIER_TO_GROWER_SEED_SALE);
        Collection<Sale> sales = Lists.newArrayList(sale);
        Cancellation cancellation = new Cancellation();
        String userLogin = "userLogin";

        multiplierSaleServiceImpl.cancelMultipleSales(sales, companies, cancellation, userLogin);

        verify(saleService).cancellingBonus(sale.getId());
    }

    @Test
    public void testHandleCancelMultipleSalesCancelsBonus_WhenSaleIsCancelledOfTypeMULTIPLIER_SEED_SALE() throws Exception {

        final Company company = new Company("Company");
        Sale sale = new Sale() {
            @Override
            public Set<Company> getCompanies() {
                return Sets.newHashSet(company);
            }
        };
        List<Company> companies = Lists.newArrayList(company);
        sale.setSaleType(Sale.SaleTypeEnum.MULTIPLIER_SEED_SALE);
        Collection<Sale> sales = Lists.newArrayList(sale);
        Cancellation cancellation = new Cancellation();
        String userLogin = "userLogin";

        multiplierSaleServiceImpl.cancelMultipleSales(sales, companies, cancellation, userLogin);

        verify(saleService, never()).cancellingBonus(anyLong());
    }

    @Test
    public void testHandleCancelMultipleSalesDoNotCancelBonus_WhenSaleIsCancelledAndSaleDoesNotHaveBonus() throws Exception {

        final Company company = new Company("Company");
        Sale sale = new Sale() {
            @Override
            public Set<Company> getCompanies() {
                return Sets.newHashSet(company);
            }
        };
        sale.setId(3l);
        List<Company> companies = Lists.newArrayList(company);
        sale.setSaleType(Sale.SaleTypeEnum.MULTIPLIER_TO_GROWER_SEED_SALE);
        Collection<Sale> sales = Lists.newArrayList(sale);
        Cancellation cancellation = new Cancellation();
        String userLogin = "userLogin";

        multiplierSaleServiceImpl.cancelMultipleSales(sales, companies, cancellation, userLogin);

        verify(saleService).cancellingBonus(sale.getId());
    }

    @Test
    public void testSaveMultiplierToGrowerSaleInvokesCreatesBillings_WhenSavingSale() throws SaleConstraintViolationException {
        Sale sale = new Sale();
        when(saleDAO.save(sale)).thenReturn(sale);
        when(multiplierSaleValidator.validate(sale)).thenReturn(new SaleConstraintViolationException(""));

        multiplierSaleServiceImpl.saveMultiplierToGrowerSale(sale);

        verify(billingFactory).buildBilling(sale);
    }

    @Test
    public void testSaveMultiplierToGrowerSaleSavesCreatedBillings_WhenSavingSale() throws SaleConstraintViolationException {
        Sale sale = new Sale();
        when(saleDAO.save(sale)).thenReturn(sale);
        when(multiplierSaleValidator.validate(sale)).thenReturn(new SaleConstraintViolationException(""));
        List<Billing> billings = Lists.newArrayList(mock(Billing.class), mock(Billing.class));
        when(billingFactory.buildBilling(sale)).thenReturn(billings);

        multiplierSaleServiceImpl.saveMultiplierToGrowerSale(sale);

        verify(billingDAO, times(2)).save(any(Billing.class));
    }

    @Test
    public void testSaveMultiplierToGrowerSaleInvokesAccountManagementForEachBilling_WhenSavingSale() throws SaleConstraintViolationException {
        Customer multiplier = new Customer();
        Grower grower = new Grower();
        Sale sale = new Sale(multiplier, grower);
        stubbSaleDaoSaveMethod(sale);
        sale.setSaleType(Sale.SaleTypeEnum.MULTIPLIER_TO_GROWER_SEED_SALE);
        when(multiplierSaleValidator.validate(sale)).thenReturn(new SaleConstraintViolationException(""));
        List<Billing> billings = Lists.newArrayList(mock(Billing.class), mock(Billing.class));
        when(billingFactory.buildBilling(sale)).thenReturn(billings);

        multiplierSaleServiceImpl.saveMultiplierToGrowerSale(sale);

        verify(accountManager, times(2)).manageSaleFor(eq(sale.getGrower()), any(Billing.class));
    }

    @Test
    public void testSaveMultiplierToGrowerSaleConsumesQuotaFromMultiplier_WhenSavingSale() throws SaleConstraintViolationException {
        Customer multiplier = new Customer();
        Grower grower = new Grower();
        Sale sale = new Sale(multiplier, grower);
        stubbSaleDaoSaveMethod(sale);
        sale.setSaleType(Sale.SaleTypeEnum.MULTIPLIER_TO_GROWER_SEED_SALE);
        when(multiplierSaleValidator.validate(sale)).thenReturn(new SaleConstraintViolationException(""));
        List<Billing> billings = Lists.newArrayList(mock(Billing.class), mock(Billing.class));
        when(billingFactory.buildBilling(sale)).thenReturn(billings);

        multiplierSaleServiceImpl.saveMultiplierToGrowerSale(sale);

        verify(multiplierQuotaService).consumeQuotaFromMultiplier(sale);
    }

    @Test
    public void testSaveSaleWontInvokeAccountManagementForEachBilling_WhenSavingSale() throws SaleConstraintViolationException {
        Customer multiplier = new Customer();
        Grower grower = new Grower();
        Sale sale = new Sale(multiplier, grower);
        stubbSaleDaoSaveMethod(sale);
        sale.setSaleType(Sale.SaleTypeEnum.MULTIPLIER_SEED_SALE);
        when(multiplierSaleValidator.validate(sale)).thenReturn(new SaleConstraintViolationException(""));
        List<Billing> billings = Lists.newArrayList(mock(Billing.class), mock(Billing.class));
        when(billingFactory.buildBilling(sale)).thenReturn(billings);

        multiplierSaleServiceImpl.saveMultiplierToDealerSale(sale);

        verify(accountManager, never()).manageSaleFor(eq(sale.getGrower()), any(Billing.class));
    }

    @Test
    public void testCalculateCreditReturn100_WhenSeedSaleIs50AndProductivityIs2() {
        BigDecimal seedsSold = BigDecimal.valueOf(50l);
        BigDecimal productivity = BigDecimal.valueOf(2l);

        BigDecimal creditValue = multiplierSaleServiceImpl.getCreditValueByRegion(seedsSold, productivity);

        assertThat(creditValue.toString()).isEqualTo("100");
    }

    @Test
    public void testCalculateCreditReturn50_WhenSeedSaleIs25AndProductivityIs2() {
        BigDecimal seedsSold = BigDecimal.valueOf(25l);
        BigDecimal productivity = BigDecimal.valueOf(2l);

        BigDecimal creditValue = multiplierSaleServiceImpl.getCreditValueByRegion(seedsSold, productivity);

        assertThat(creditValue.toString()).isEqualTo("50");
    }

    @Test
    public void testCalculateCreditValueByStateUpdatesPlantability_WhenCalculatingCreditValue() {
        BigDecimal seedSoldQuantity = BigDecimal.valueOf(25);
        Product product = new Product();
        State state = new State();
        Plantability plantability = new Plantability() {
            @Override
            public BigDecimal getAverageProductivityValue(Product product, State state) {
                return BigDecimal.ONE;
            }
        };
        plantability.setId(100l);
        when(plantabilityDAO.selectById(plantability.getId())).thenReturn(plantability);

        multiplierSaleServiceImpl.getCreditValueByState(seedSoldQuantity, plantability, product, state);

        verify(plantabilityDAO).selectById(plantability.getId());
    }

    @Test
    public void testCalculateCreditValueByStateReturn50_WhenSeedSoldQuantityIs25AndProductivityByStateIs2() {
        BigDecimal seedSoldQuantity = BigDecimal.valueOf(25);
        final BigDecimal productivityByState = BigDecimal.valueOf(2);
        Plantability plantability = new Plantability() {
            @Override
            public BigDecimal getAverageProductivityValue(Product product, State state) {
                return productivityByState;
            }
        };
        plantability.setId(100l);
        when(plantabilityDAO.selectById(plantability.getId())).thenReturn(plantability);
        Product product = new Product();
        State state = new State();

        assertThat(multiplierSaleServiceImpl.
                getCreditValueByState(seedSoldQuantity, plantability, product, state)).isEqualTo(BigDecimal.valueOf(50));
    }

    @Test
    public void testCalculateCreditValueByStateReturn100_WhenSeedSoldQuantityIs50AndProductivityByStateIs2() {
        BigDecimal seedSoldQuantity = BigDecimal.valueOf(50);
        final BigDecimal productivityByState = BigDecimal.valueOf(2);
        Plantability plantability = new Plantability() {
            @Override
            public BigDecimal getAverageProductivityValue(Product product, State state) {
                return productivityByState;
            }
        };
        plantability.setId(100l);
        when(plantabilityDAO.selectById(plantability.getId())).thenReturn(plantability);
        Product product = new Product();
        State state = new State();
        assertThat(multiplierSaleServiceImpl.
                getCreditValueByState(seedSoldQuantity, plantability, product, state)).isEqualTo(BigDecimal.valueOf(100));
    }

    @Test
    public void testSaveSaleConsumesCashAdvance_WhenSavingSale() throws SaleConstraintViolationException {
        Sale sale = new Sale();
        when(saleDAO.save(sale)).thenReturn(sale);

        multiplierSaleServiceImpl.saveMultiplierToDealerSale(sale);

        verify(cashAdvanceService).createCashAdvanceDebitFromSale(sale);
    }

    @Test
    public void testSaveMultiplierToGrowerSaleConsumesCashAdvance_WhenSavingSale() throws SaleConstraintViolationException {
        Sale sale = new Sale();
        stubbSaleDaoSaveMethod(sale);

        multiplierSaleServiceImpl.saveMultiplierToGrowerSale(sale);

        verify(cashAdvanceService).createCashAdvanceDebitFromSale(sale);
    }

    @Test
    public void saveMultiplierToDealerSaleRegisterSaleLinkDetails_WhenSavingSales() throws SaleConstraintViolationException {
        Sale sale = new Sale();
        when(saleDAO.save(sale)).thenReturn(sale);

        multiplierSaleServiceImpl.saveMultiplierToDealerSale(sale);

        verify(saleLinkDetailRegister).registerSale(sale);
    }
    public static final long ID4 = 13l;
    public static final long ID3 = 12l;
    public static final long ID2 = 11l;
    public static final long ID1 = 10l;

    @Test
    public void excludePostedSalesFromSaleList_WhenExcludingpostingSales() throws SaleConstraintViolationException {

        List<Sale> sales = new ArrayList<Sale>();
        List<Sale> postedSales = new ArrayList<Sale>();
        Sale sale = new Sale();
        sale.setId(ID1);
        sales.add(sale);
        postedSales.add(sale);
        sale = new Sale();
        sale.setId(ID2);
        sales.add(sale);
        postedSales.add(sale);
        sale = new Sale();
        sale.setId(ID3);
        sales.add(sale);
        sale = new Sale();
        sale.setId(ID4);
        sales.add(sale);
        when(multiplierSaleDAO.findPostedSalesInSaleList(sales)).thenReturn(postedSales);

        List<Sale> returnedSales = multiplierSaleServiceImpl.excludePostedSalesFromSaleList(sales);

        verify(multiplierSaleDAO).findPostedSalesInSaleList(sales);
        assertEquals(returnedSales.size(), EXPECTED_VALUE_2);
    }
}