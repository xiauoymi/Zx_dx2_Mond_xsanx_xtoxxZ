package com.monsanto.brazilvaluecapture.core.grower.model.dao.impl;

import com.monsanto.brazilvaluecapture.core.base.model.bean.Company;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Crop;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Technology;
import com.monsanto.brazilvaluecapture.core.foundation.service.EntityAlreadyExistException;
import com.monsanto.brazilvaluecapture.core.foundation.util.ItsFilter;
import com.monsanto.brazilvaluecapture.core.grower.model.bean.Agreement;
import com.monsanto.brazilvaluecapture.core.grower.model.bean.AgreementFile;
import com.monsanto.brazilvaluecapture.core.grower.model.bean.AgreementTemplate;
import com.monsanto.brazilvaluecapture.core.grower.model.bean.Grower;
import com.monsanto.brazilvaluecapture.core.grower.model.dao.AgreementByGrowerFilterParameters;
import com.monsanto.brazilvaluecapture.core.grower.service.AgreementTemplateWithAgreementUndeletableException;
import com.monsanto.brazilvaluecapture.core.user.model.bean.ItsUser;
import com.monsanto.brazilvaluecapture.core.wsiconsole.dao.impl.BaseHibernateUnitTest;
import oracle.jdbc.internal.OracleTypes;
import org.hibernate.exception.ConstraintViolationException;
import org.hibernate.jdbc.Work;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import static junit.framework.Assert.fail;
import static org.fest.assertions.Assertions.assertThat;
import static org.mockito.Mockito.*;

/**
 * Created with IntelliJ IDEA.
 * User: IFERN1
 * Date: 10/21/13
 * Time: 4:29 PM
 * To change this template use File | Settings | File Templates.
 */
@RunWith(MockitoJUnitRunner.class)
public class AgreementDAOImpl_UT extends BaseHibernateUnitTest {
    private AgreementDAOImpl agreementDAO;

    @Before
    public void setUp() {
        agreementDAO = new AgreementDAOImpl(sessionFactory);
        MockitoAnnotations.initMocks(agreementDAO);
    }

    @Test
    public void test_getAgreementTemplatesByFilter() {
        //@Given
        ItsFilter itsFilter = mock(ItsFilter.class);
        when(itsFilter.buildCriteria(session)).thenReturn(criteria);

        //@When
        List<AgreementTemplate> result = agreementDAO.getAgreementTemplatesByFilter(itsFilter);

        //@Should
        verify(criteria).list();
    }

    @Test
    public void test_save() throws EntityAlreadyExistException {
        //@Given
        AgreementTemplate agreementTemplate = mock(AgreementTemplate.class);

        //@When
        agreementDAO.save(agreementTemplate);

        //@Should
        verify(session).saveOrUpdate(agreementTemplate);
    }

    @Test(expected = EntityAlreadyExistException.class)
    public void test_save_error_condition() throws EntityAlreadyExistException {
        //@Given
        AgreementTemplate agreementTemplate = mock(AgreementTemplate.class);
        ConstraintViolationException exception = new ConstraintViolationException("someMessage",
                new SQLException("UQ_AGR_TEMPLATE", "someSQLState"), "UQ_AGR_TEMPLATE");
        doThrow(exception).when(session).saveOrUpdate(agreementTemplate);

        //@When
        agreementDAO.save(agreementTemplate);

        //@Should
        fail("Should fail with a EntityAlreadyExistException exception");
    }

    @Test(expected = ConstraintViolationException.class)
    public void test_save_error_condition_1() throws EntityAlreadyExistException {
        //@Given
        AgreementTemplate agreementTemplate = mock(AgreementTemplate.class);
        ConstraintViolationException exception = new ConstraintViolationException("someMessage",
                new SQLException("someConstraint", "someSQLState"), "someConstraint");
        doThrow(exception).when(session).saveOrUpdate(agreementTemplate);

        //@When
        agreementDAO.save(agreementTemplate);

        //@Should
        fail("Should fail with a ConstraintViolationException exception");
    }

    @Test
    public void test_delete() throws Exception {
        //@Given
        AgreementTemplate agreementTemplate = mock(AgreementTemplate.class);

        //@When
        agreementDAO.delete(agreementTemplate);

        //@Should
        verify(session).delete(agreementTemplate);
    }

    @Test(expected = AgreementTemplateWithAgreementUndeletableException.class)
    public void test_delete_error_condition() throws Exception {
        //@Given
        AgreementTemplate agreementTemplate = mock(AgreementTemplate.class);
        ConstraintViolationException exception = new ConstraintViolationException("someMessage",
                new SQLException("FK_AGR_TEMP_FK_AGR_ID", "someSQLState"), "FK_AGR_TEMP_FK_AGR_ID");
        doThrow(exception).when(session).delete(agreementTemplate);

        //@When
        agreementDAO.delete(agreementTemplate);

        //@Should
        fail("Should fail with a EntityAlreadyExistException exception");
    }

    @Test(expected = ConstraintViolationException.class)
    public void test_delete_error_condition_1() throws Exception {
        //@Given
        AgreementTemplate agreementTemplate = mock(AgreementTemplate.class);
        ConstraintViolationException exception = new ConstraintViolationException("someMessage",
                new SQLException("someConstraint", "someSQLState"), "someConstraint");
        doThrow(exception).when(session).delete(agreementTemplate);

        //@When
        agreementDAO.delete(agreementTemplate);

        //@Should
        fail("Should fail with a ConstraintViolationException exception");
    }

    @Test
    public void test_selectByGrower() {
        //@Given
        Grower grower = new Grower();

        //@When
        Grower savedGrower = agreementDAO.selectByGrower(grower);

        //@Should
        verify(session).createQuery(anyString());
        verify(query).setParameter("p_grower", grower);
        verify(query).uniqueResult();
    }

    @Test
    public void test_getAgreementVersion() {
        //@Given
        Company company = mock(Company.class);
        Technology technology = mock(Technology.class);
        Crop crop = mock(Crop.class);

        //@When
        agreementDAO.getAgreementVersion(company, technology, crop, null);

        //@Should
        verify(session).doWork(any(AgreementDAOImpl.GenerateVersionWork.class));
    }

    @Test
    public void test_saveAgreement() {
        //@Given
        Agreement agreement = new Agreement();

        //@When
        agreementDAO.saveAgreement(agreement);

        //@Should
        verify(session).saveOrUpdate(agreement);
    }

    @Test
    public void test_deleteAgreement() {
        //@Given
        Agreement agreement = new Agreement();

        //@When
        agreementDAO.deleteAgreement(agreement);

        //@Should
        verify(session).delete(agreement);
    }

    @Test
    public void test_selectAgreementById() {
        //@When
        long id = 1l;
        agreementDAO.selectAgreementById(id);

        //@Should
        verify(session).createQuery(anyString());
        verify(query).setParameter("p_id", id);
        verify(query).uniqueResult();
    }

    @Test
    public void test_hasSalesPerformed() {
        //@Given
        Long growerId = 1l;
        Long companyId = 1l;
        Long technologyId = 1l;
        Long cropId = 1l;
        ArrayList<BigDecimal> values = new ArrayList<BigDecimal>();
        values.add(BigDecimal.ONE);
        when(sqlQuery.list()).thenReturn(values);

        //@When
        agreementDAO.hasSalesPerformed(growerId, companyId, technologyId, cropId);

        //@Should
        verify(session).createSQLQuery(anyString());
        verify(sqlQuery).setParameter("growerId", growerId);
        verify(sqlQuery).setParameter("companyId", companyId);
        verify(sqlQuery).setParameter("technologyId", technologyId);
        verify(sqlQuery).setParameter("cropId", cropId);
        verify(sqlQuery).list();
    }

    @Test
    public void test_getAgreementTemplatesByCountryCode() {
        //@Given
        String countryCode = "someCountrycode";

        //@When
        agreementDAO.getAgreementTemplatesByCountryCode(countryCode);

        //@Should
        verify(session).createQuery(anyString());
        verify(query).setParameter("countryCode", countryCode);
        verify(query).list();
    }

    @Test
    public void test_getAgreementByGrowerDTOsNumberOfResults() {
        //@Given
        AgreementByGrowerFilterParameters filterParameters = mock(AgreementByGrowerFilterParameters.class);
        String someValue = "someValue";
        when(filterParameters.getCountryCode()).thenReturn(someValue);
        when(filterParameters.getDocumentNumber()).thenReturn(someValue);
        when(filterParameters.getLicenseNumber()).thenReturn(someValue);
        when(filterParameters.getAgreementStatus()).thenReturn(Agreement.AgreementStatusEnum.APPROVED);
        when(filterParameters.getTechnology()).thenReturn(new Technology());
        when(filterParameters.isAuthorizedToSearchAll()).thenReturn(false);
        when(filterParameters.getUserType()).thenReturn(ItsUser.UserTypeEnum.PARTICIPANT);
        when(filterParameters.getUserLogin()).thenReturn(someValue);
        when(query.uniqueResult()).thenReturn(10l);

        //@When
        int res = agreementDAO.getAgreementByGrowerDTOsNumberOfResults(filterParameters);

        //@Should
        assertThat(res).isEqualTo(10);
        verify(session).createQuery(anyString());
        verify(query).uniqueResult();
    }

    @Test
    public void test_getAgreementByGrowerDTOs() {
        //@Given
        AgreementByGrowerFilterParameters filterParameters = mock(AgreementByGrowerFilterParameters.class);
        String someValue = "someValue";
        when(filterParameters.getCountryCode()).thenReturn(someValue);
        when(filterParameters.getDocumentNumber()).thenReturn(someValue);
        when(filterParameters.getLicenseNumber()).thenReturn(someValue);
        when(filterParameters.getAgreementStatus()).thenReturn(Agreement.AgreementStatusEnum.APPROVED);
        when(filterParameters.getTechnology()).thenReturn(new Technology());
        when(filterParameters.getUserType()).thenReturn(ItsUser.UserTypeEnum.PARTICIPANT);
        when(filterParameters.getUserLogin()).thenReturn(someValue);
        when(filterParameters.getSortField()).thenReturn(someValue);
        when(filterParameters.getPageSize()).thenReturn(Integer.valueOf(1));
        when(filterParameters.getFirstResult()).thenReturn(1);
        when(filterParameters.isLimitedSearch()).thenReturn(true);

        //@When
        agreementDAO.getAgreementByGrowerDTOs(filterParameters);

        //@Should
        verify(session).createQuery(anyString());
        verify(query).setMaxResults(100);
        verify(query).list();
    }

    @Test
    public void test_validateExistAgreementByLicenseNumberAndCountryId() {
        //@Given
        String licenseNumber = "someLicenseNumber";
        Long countryId = 1l;

        //@When
        boolean result = agreementDAO.validateExistAgreementByLicenseNumberAndCountryId(licenseNumber, countryId);

        //@Should
        verify(session).clear();
        verify(session).createQuery(anyString());
        verify(query).setParameter("licenseNumber", licenseNumber);
        verify(query).setParameter("countryId", countryId);
        verify(query).list();
    }

    @Test
    public void test_GenerateVersionWork_execute() throws SQLException {
        //@Given
        Company company = mock(Company.class);
        Long companyId = 1l;
        when(company.getId()).thenReturn(companyId);
        Technology technology = mock(Technology.class);
        Long technologyId = 10l;
        when(technology.getId()).thenReturn(technologyId);
        Crop crop = mock(Crop.class);
        long cropId = 100l;
        when(crop.getId()).thenReturn(cropId);

        //@When
         Work generateVersionWork = agreementDAO.getGenerateVersionWorkInstance(company, technology, crop, null);
        generateVersionWork.execute(connection);

        //@Should
        verify(callableStatement).setLong(1, companyId);
        verify(callableStatement).setLong(2, cropId);
        verify(callableStatement).setLong(3, technologyId);
        verify(callableStatement).registerOutParameter(4, OracleTypes.NUMBER);
        verify(callableStatement).execute();
        verify(callableStatement).getLong(4);
    }
    @Test
    public void test_searchAgreementsByStateAndCuit() {
        //@Given
         Grower grower = new Grower();
        List<Agreement> agreementList= new ArrayList<Agreement>();
        List<Grower> growerList = new ArrayList<Grower>();
        growerList.add(grower);

        //@When
        agreementList = agreementDAO.searchAgreementsByStateAndCuit(growerList, Agreement.AgreementStatusEnum.PENDING_AGREEMENT,"AR");

        //@Should
        verify(session).createQuery(anyString());
        verify(query).setParameter("countryCode", "AR");
        verify(query).setParameter("status", Agreement.AgreementStatusEnum.PENDING_AGREEMENT);
        verify(query).setParameterList("growers", growerList);
        verify(query).list();
    }

    @Test
    public void test_getAgreementFileByAgreement() {
        //@Given
        Agreement agreement = new Agreement();

        //@When
        List<AgreementFile> list = agreementDAO.getAgreementFileByAgreement(agreement);

        //@Should
        verify(session).createQuery(anyString());
        verify(query).setParameter("agreement", agreement);
        verify(query).list();
    }

    @Test
        public void test_searchAgreementsByGrowerCropAndCompanies() {
            //@Given
             Grower grower = new Grower();
            Company company = new Company();
            List<Agreement> agreementList= new ArrayList<Agreement>();
            List<Company> companyList = new ArrayList<Company>();
            companyList.add(company);
            Crop crop = new Crop();

            //@When
            agreementList = agreementDAO.getAgreementsByGrowerCropAndCompanies(grower, crop,companyList);

            //@Should
            verify(session).createQuery(anyString());
            verify(query).setParameter("grower", grower);
            verify(query).setParameter("cropParam", crop);
            verify(query).setParameterList("companies", companyList);
            verify(query).list();
        }
}
