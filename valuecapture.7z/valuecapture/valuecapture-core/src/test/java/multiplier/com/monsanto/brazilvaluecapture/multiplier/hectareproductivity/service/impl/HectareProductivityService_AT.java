package com.monsanto.brazilvaluecapture.multiplier.hectareproductivity.service.impl;

import com.monsanto.brazilvaluecapture.core.base.model.bean.Crop;
import com.monsanto.brazilvaluecapture.core.base.model.bean.State;
import com.monsanto.brazilvaluecapture.core.foundation.model.bean.StatusEnum;
import com.monsanto.brazilvaluecapture.core.foundation.test.AbstractServiceIntegrationTests;
import com.monsanto.brazilvaluecapture.core.foundation.test.dbunit.DbUnitHelper;
import com.monsanto.brazilvaluecapture.multiplier.cultivar.model.bean.Cultivar;
import com.monsanto.brazilvaluecapture.multiplier.hectareproductivity.model.bean.HectareProductivity;
import com.monsanto.brazilvaluecapture.multiplier.hectareproductivity.service.HectareProductivityService;
import com.monsanto.brazilvaluecapture.multiplier.obtainer.model.bean.Obtainer;
import com.monsanto.brazilvaluecapture.seedsale.harvest.model.bean.Harvest;
import junit.framework.Assert;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import java.math.BigInteger;
import java.util.Collection;
import java.util.List;
import java.util.Map;


public class HectareProductivityService_AT extends AbstractServiceIntegrationTests {

    public static final Long CROP1 = 900000001L;
    public static final Long CROP2 = 900000002L;

    public static final Long OBTAINER1 = 900000001L;
    public static final Long OBTAINER2 = 900000002L;
    public static final Long OBTAINER3 = 900000003L;
    public static final Long OBTAINER4 = 900000004L;

    public static final Long CULTIVAR1 = 900000001L;
    public static final Long CULTIVAR2 = 900000002L;
    public static final Long CULTIVAR3 = 900000003L;
    public static final Long CULTIVAR4 = 900000004L;
    public static final Long CULTIVAR5 = 900000005L;

    public static final Long HARVEST1 = 900000001L;
    public static final Long HARVEST2 = 900000002L;
    public static final Long HARVEST3 = 900000003L;

    public static final Long STATE1 = 900000001L;
    public static final Long STATE2 = 900000002L;
    public static final Long STATE3 = 900000003L;
    public static final Long STATE4 = 900000004L;
    public static final Long STATE5 = 900000005L;

    @Qualifier("hectareProductivityServiceImpl")
    @Autowired
    private HectareProductivityService hectareProductivityService;

    public void setupFixture() {
        DbUnitHelper.setup(
        "classpath:data/multiplier/basic-fixture.xml",
        "classpath:data/multiplier/hectare_productivity_dataset.xml");
    }

    private Crop getCrop(Long id) {
        return (Crop) getSession().get(Crop.class, id);
    }

    private Obtainer getObtainer(Long id) {
        return (Obtainer) getSession().get(Obtainer.class, id);
    }

    private Cultivar getCultivar(Long id) {
        return (Cultivar) getSession().get(Cultivar.class, id);
    }

    private Harvest getHarvest(Long id) {
        return (Harvest) getSession().get(Harvest.class, id);
    }

    private State getState(Long id) {
        return (State) getSession().get(State.class, id);
    }

    @Test
    public void sanity_test() {
        setupFixture();
        Harvest harvest = getHarvest(HARVEST1);
        State state = getState(STATE1);
//        Obtainer obtainer = getObtainer(OBTAINER1);
        Cultivar cultivar = getCultivar(CULTIVAR1);
        HectareProductivity hectareProductivity = new HectareProductivity(harvest, state, cultivar);
        hectareProductivity.setProductivity(BigInteger.TEN);
        saveAndFlush(hectareProductivity);
        Long id = hectareProductivity.getId();
        Assert.assertNotNull("Id should not be null", id);
        getSession().evict(hectareProductivity);
        hectareProductivity=null;
        hectareProductivity=hectareProductivityService.selectById(id);
        Assert.assertNotNull("Productivity should not be null", hectareProductivity);
        Assert.assertEquals("Productivity should be equal", BigInteger.TEN, hectareProductivity.getProductivity());
        Assert.assertEquals("Cultivar should be equal", cultivar, hectareProductivity.getCultivar());
        Assert.assertEquals("State should be equal", state, hectareProductivity.getState());
        Assert.assertEquals("Harvest should be equal", harvest, hectareProductivity.getHarvest());
    }

    @Test
    public void given_no_obtainer_generate_should_create_4_hectare_productivities() {
        setupFixture();
        Harvest harvest = getHarvest(HARVEST1);
        State state = getState(STATE1);

        List<HectareProductivity> hectareProductivities = hectareProductivityService.generateHectareProductiviesBy(state, harvest, null);
        Assert.assertEquals("Should have 4", 4, hectareProductivities.size());
    }

    @Test
    public void when_i_add_a_cultivar_should_add_one_more_hect_prod_to_list() throws HectareProductivityConstraintException {
        setupFixture();
        Harvest harvest = getHarvest(HARVEST1);
        State state = getState(STATE1);
        Obtainer obtainer = getObtainer(OBTAINER1);
        Obtainer obtainer2 = getObtainer(OBTAINER2);
        Cultivar cultivar = getCultivar(CULTIVAR1);
        Crop crop = getCrop(CROP1);
        List<HectareProductivity> hectareProductivities = hectareProductivityService.generateHectareProductiviesBy(state, harvest, null);
        Assert.assertEquals(4, hectareProductivities.size());

        hectareProductivities = hectareProductivityService.generateHectareProductiviesBy(state, harvest, obtainer);
        Assert.assertEquals("Should have 2", 2, hectareProductivities.size());
        for(int i=0;i<hectareProductivities.size();i++) {
            hectareProductivities.get(i).setProductivity(BigInteger.valueOf(10+i));
        }
        hectareProductivityService.save(hectareProductivities);
        getSession().flush();
        hectareProductivities = hectareProductivityService.generateHectareProductiviesBy(state, harvest, null);
        Assert.assertEquals("Should have 4", 4, hectareProductivities.size());
        for(HectareProductivity hectareProductivity:hectareProductivities) {
            getSession().evict(hectareProductivity);
        }
        Cultivar cultivar2 = new Cultivar("NEW CULTIVAR", true, true, StatusEnum.ACTIVE, crop, obtainer2, cultivar.getTechnology(), Boolean.TRUE);
        saveAndFlush(cultivar2);
        hectareProductivities = hectareProductivityService.generateHectareProductiviesBy(state, harvest, null);
        Assert.assertEquals("Should have 5", 5, hectareProductivities.size());
    }

    @Test
    public void given_one_obtainer_should_return_2_values() {
        setupFixture();
        Harvest harvest = getHarvest(HARVEST1);
        State state = getState(STATE1);
        Obtainer obtainer = getObtainer(OBTAINER1);

        List<HectareProductivity> hectareProductivities = hectareProductivityService.generateHectareProductiviesBy(state, harvest, obtainer);
        Assert.assertEquals("Should have 2", 2, hectareProductivities.size());
    }

    @Test
    public void given_defined_obtainer_and_save_should_persist_all_results() throws HectareProductivityConstraintException {
        setupFixture();
        Harvest harvest = getHarvest(HARVEST1);
        State state = getState(STATE1);
        Obtainer obtainer = getObtainer(OBTAINER1);

        List<HectareProductivity> hectareProductivities = hectareProductivityService.generateHectareProductiviesBy(state, harvest, obtainer);
        Assert.assertEquals("Should have 2", 2, hectareProductivities.size());
        for(int i=0;i<hectareProductivities.size();i++) {
            hectareProductivities.get(i).setProductivity(BigInteger.valueOf(10+i));
        }
        hectareProductivityService.save(hectareProductivities);
        getSession().flush();
        for(HectareProductivity hectareProductivity:hectareProductivities) {
            getSession().evict(hectareProductivity);
        }
        hectareProductivities = hectareProductivityService.generateHectareProductiviesBy(state, harvest, obtainer);
        for(int i=0;i<hectareProductivities.size();i++) {
            Assert.assertEquals("Should be equal to " + (10+i), BigInteger.valueOf(10+i), hectareProductivities.get(i).getProductivity());
        }
    }

    @Test
    public void given_saved_producitivities_and_search_for_producitivity_by_state_harvest_cultivar_should_return_one_result() throws HectareProductivityConstraintException {
        setupFixture();
        Harvest harvest = getHarvest(HARVEST1);
        State state = getState(STATE1);
        Obtainer obtainer = getObtainer(OBTAINER1);
        Cultivar cultivar = getCultivar(CULTIVAR1);

        List<HectareProductivity> hectareProductivities = hectareProductivityService.generateHectareProductiviesBy(state, harvest, obtainer);
        Assert.assertEquals("Should have 2", 2, hectareProductivities.size());
        BigInteger val = null;
        for(int i=0;i<hectareProductivities.size();i++) {
            if(hectareProductivities.get(i).getCultivar().getId()==900000001L) {
                val = BigInteger.valueOf(10 + i);
            }
            hectareProductivities.get(i).setProductivity(BigInteger.valueOf(10+i));
        }
        Assert.assertNotNull(val);
        hectareProductivityService.save(hectareProductivities);
        getSession().flush();

        BigInteger productivity = hectareProductivityService.selectProductivityBy(harvest, state, cultivar);
        Assert.assertEquals(0, val.compareTo(productivity));

    }

    @Test
    public void given_mix_of_filled_in_and_not_filled_in_productivities_should_return_4_productivities_with_2_filled_in() throws HectareProductivityConstraintException {
        setupFixture();
        Harvest harvest = getHarvest(HARVEST1);
        State state = getState(STATE1);
        Obtainer obtainer = getObtainer(OBTAINER1);

        List<HectareProductivity> hectareProductivities = hectareProductivityService.generateHectareProductiviesBy(state, harvest, obtainer);
        Assert.assertEquals("Should have 2", 2, hectareProductivities.size());
        for(int i=0;i<hectareProductivities.size();i++) {
            hectareProductivities.get(i).setProductivity(BigInteger.valueOf(10+i));
        }
        hectareProductivityService.save(hectareProductivities);
        getSession().flush();

        hectareProductivities = hectareProductivityService.generateHectareProductiviesBy(state, harvest, null);
        Assert.assertEquals("Should have 4", 4, hectareProductivities.size());
        int count = 0;
        for(HectareProductivity hectareProductivity:hectareProductivities) {
            if(hectareProductivity.getProductivity()!=null) {
                count++;
            }
        }
        Assert.assertEquals("Should have 2 filled in", 2, count);
    }

    @Test(expected = HectareProductivityConstraintException.class)
    public void given_invalid_productivity_value_should_throw_exception() throws HectareProductivityConstraintException {
        setupFixture();
        Harvest harvest = getHarvest(HARVEST1);
        State state = getState(STATE1);
        List<HectareProductivity> hectareProductivities = hectareProductivityService.generateHectareProductiviesBy(state, harvest, null);
        hectareProductivities.iterator().next().setProductivity(BigInteger.valueOf(-1L));
        for(int i=1;i<hectareProductivities.size();i++) {
            hectareProductivities.get(i).setProductivity(BigInteger.valueOf(10+i));
        }
        hectareProductivityService.save(hectareProductivities);
        getSession().flush();
    }

    @Test
    public void given_productivity_values_of_zero_should_persist_successfully() throws HectareProductivityConstraintException {
        setupFixture();
        Harvest harvest = getHarvest(HARVEST1);
        State state = getState(STATE1);
        List<HectareProductivity> hectareProductivities = hectareProductivityService.generateHectareProductiviesBy(state, harvest, null);
        for(int i=0;i<hectareProductivities.size();i++) {
            hectareProductivities.get(i).setProductivity(BigInteger.ZERO);
        }
        hectareProductivityService.save(hectareProductivities);
        getSession().flush();
    }

    @Test(expected = HectareProductivityConstraintException.class)
    public void given_some_productivities_filled_in_should_throw_exception() throws HectareProductivityConstraintException {
        setupFixture();
        Harvest harvest = getHarvest(HARVEST1);
        State state = getState(STATE1);

        List<HectareProductivity> hectareProductivities = hectareProductivityService.generateHectareProductiviesBy(state, harvest, null);
        Assert.assertEquals("Should have 4", 4, hectareProductivities.size());
        for(int i=0;i<hectareProductivities.size();i++) {
            if(i%2==0) {
                hectareProductivities.get(i).setProductivity(BigInteger.valueOf(10+i));
            }
        }
        hectareProductivityService.save(hectareProductivities);
        getSession().flush();
        hectareProductivities = hectareProductivityService.generateHectareProductiviesBy(state, harvest, null);
        for(int i=0;i<hectareProductivities.size();i++) {
           Assert.assertEquals("Should be zero", BigInteger.ZERO,  hectareProductivities.get(i).getProductivity());
        }

    }

    @Test
    public void given_several_different_productivities_when_search_by_crop_state_obtainer_should_bring_only_correct_results() {
        setupFixture();
        Harvest harvest1 = getHarvest(HARVEST1);
        Harvest harvest2 = getHarvest(HARVEST2);
        Harvest harvest3 = getHarvest(HARVEST3);

        State state1 = getState(STATE1);
        State state2 = getState(STATE2);

        Obtainer obtainer1 = getObtainer(OBTAINER1);
        Obtainer obtainer4 = getObtainer(OBTAINER4);

        Cultivar cultivar1 = getCultivar(CULTIVAR1);
        Cultivar cultivar2 = getCultivar(CULTIVAR2);
        Cultivar cultivar3 = getCultivar(CULTIVAR3);
        Cultivar cultivar4 = getCultivar(CULTIVAR4);
        Cultivar cultivar5 = getCultivar(CULTIVAR5);


        persistHectareProductivity(harvest1, state1, cultivar1, BigInteger.valueOf(15L));
        persistHectareProductivity(harvest1, state1, cultivar2, BigInteger.valueOf(16L));
        persistHectareProductivity(harvest1, state1, cultivar3, BigInteger.valueOf(17L));
        persistHectareProductivity(harvest1, state1, cultivar5, BigInteger.valueOf(17L));
        persistHectareProductivity(harvest1, state2, cultivar1, BigInteger.valueOf(18L));
        persistHectareProductivity(harvest1, state2, cultivar2, BigInteger.valueOf(19L));
        persistHectareProductivity(harvest2, state1, cultivar1, BigInteger.valueOf(20L));
        persistHectareProductivity(harvest2, state1, cultivar3, BigInteger.valueOf(21L));
        persistHectareProductivity(harvest3, state1, cultivar4, BigInteger.valueOf(22L));
        persistHectareProductivity(harvest3, state2, cultivar4, BigInteger.valueOf(22L));

        Assert.assertEquals("Have 10 records", 10, getSession().createCriteria(HectareProductivity.class).list().size());

        List<HectareProductivity> hectareProductivities = hectareProductivityService.generateHectareProductiviesBy(state1, harvest1, null);
        assertNumberResults(hectareProductivities, 4);
        hectareProductivities = hectareProductivityService.generateHectareProductiviesBy(state1, harvest1, obtainer1);
        assertNumberResults(hectareProductivities, 2);
        hectareProductivities = hectareProductivityService.generateHectareProductiviesBy(state2, harvest1, obtainer1);
        assertNumberResults(hectareProductivities, 2);
        hectareProductivities = hectareProductivityService.generateHectareProductiviesBy(state1, harvest2, obtainer1);
        assertNumberResults(hectareProductivities, 1);
        hectareProductivities = hectareProductivityService.generateHectareProductiviesBy(state2, harvest3, obtainer4);
        assertNumberResults(hectareProductivities, 1);

    }

    private void assertNumberResults(Collection<HectareProductivity> hectareProductivityCollection, int number) {
        int counter = 0;
        for(HectareProductivity hectareProductivity:hectareProductivityCollection) {
            if(hectareProductivity.getProductivity()!=null&&!hectareProductivity.getProductivity().equals(BigInteger.ZERO)) {
                counter++;
            }
        }
        Assert.assertEquals("Should be "+number, number, counter);
    }

    private HectareProductivity persistHectareProductivity(Harvest harvest, State state, Cultivar cultivar, BigInteger productivity) {
        HectareProductivity hectareProductivity = new HectareProductivity(harvest, state, cultivar);
        hectareProductivity.setProductivity(productivity);
        saveAndFlush(hectareProductivity);
        return hectareProductivity;
    }
    
    @Test
    public void given_defined_headoffice_harvest_and_obtainer_should_return_cultivar_productivities() throws HectareProductivityConstraintException {
        setupFixture();
        
        Harvest harvest = getHarvest(HARVEST1);
        State state = getState(STATE1);
        Obtainer obtainer = getObtainer(OBTAINER1);
        Cultivar cultivar = getCultivar(CULTIVAR1);

        HectareProductivity hectareProductivity = new HectareProductivity(harvest, state, cultivar);
        hectareProductivity.setProductivity(BigInteger.TEN);
        saveAndFlush(hectareProductivity);
        
        Map<Long, BigInteger> productivities = hectareProductivityService.findMapOfProductivitesForCultivars(state, harvest, obtainer);
        Assert.assertEquals("Should have 1", 1, productivities.size());


        Assert.assertEquals("Should be equal to " + BigInteger.TEN, BigInteger.TEN, productivities.get(cultivar.getId()));

    }
}
