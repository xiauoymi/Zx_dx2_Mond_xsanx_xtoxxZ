package com.monsanto.brazilvaluecapture.multiplier.obtainer;

import com.monsanto.brazilvaluecapture.core.base.SystemTestFixture;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Company;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Crop;
import com.monsanto.brazilvaluecapture.core.base.service.ConstraintException;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Customer;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.ParticipantTypeEnum;
import com.monsanto.brazilvaluecapture.core.foundation.model.bean.StatusEnum;
import com.monsanto.brazilvaluecapture.core.foundation.service.BusinessException;
import com.monsanto.brazilvaluecapture.core.foundation.test.AbstractServiceIntegrationTests;
import com.monsanto.brazilvaluecapture.core.foundation.test.dbunit.DbUnitHelper;
import com.monsanto.brazilvaluecapture.core.foundation.util.ConstraintViolation;
import com.monsanto.brazilvaluecapture.multiplier.cultivar.model.bean.Cultivar;
import com.monsanto.brazilvaluecapture.multiplier.itsclass.model.bean.ItsClass;
import com.monsanto.brazilvaluecapture.multiplier.obtainer.model.bean.CustomerAssociationDTO;
import com.monsanto.brazilvaluecapture.multiplier.obtainer.model.bean.Obtainer;
import com.monsanto.brazilvaluecapture.multiplier.obtainer.model.bean.ObtainerByMultiplier;
import com.monsanto.brazilvaluecapture.multiplier.obtainer.model.dao.ObtainerByMultiplierFilter;
import com.monsanto.brazilvaluecapture.multiplier.obtainer.model.dao.ObtainerFilter;
import com.monsanto.brazilvaluecapture.multiplier.obtainer.service.ObtainerService;
import com.monsanto.brazilvaluecapture.seedsale.harvest.model.bean.Harvest;
import com.monsanto.brazilvaluecapture.seedsale.sale.SaleTestFixture;
import edu.emory.mathcs.backport.java.util.Arrays;
import org.junit.Assert;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class ObtainerService_AT extends AbstractServiceIntegrationTests {

	private static final long CROP1 = 900000001L;
	private static final long COMPANY1 = 900000001L;
	@Autowired
    private ObtainerService obtainerService;
	
	private void init(boolean useFixture) {
		if(useFixture) {
			systemTestFixture = new SystemTestFixture(this);
			saleTestFixture = new SaleTestFixture(this, systemTestFixture);
		} else {
	        DbUnitHelper.setup("classpath:data/multiplier/obtainer-dataset.xml");
		}
	}
	
	private void initObtainerByHarvest() {
		if(getAssumptionTest().isEnvironmentWithSQLANSI()) {
			DbUnitHelper.setup("classpath:data/multiplier/obtainer-dataset.xml");
		} else {
			DbUnitHelper.setup("classpath:data/multiplier/obtainer-dataset.xml");
			DbUnitHelper.setup("classpath:data/multiplier/obtainer-by-harvest-dataset.xml");
		}
	}
	
	private void init() {
		init(true);
	}

	@Test
	public void when_obtainer_does_not_exist_save_should_be_success() throws BusinessException {
		init();
		Obtainer obtainer = ObtainerTestData.createActiveObtainer(this.systemTestFixture.soy);
		obtainerService.save(obtainer);
		getSession().flush();
    	
        Assert.assertNotNull(obtainer.getId());
	}
	
	@Test
	public void given_a_edited_obtainer_with_valid_values_should_save_successfully() throws ConstraintException {
		init(false);
		Obtainer obtainer = (Obtainer) getSession().get(Obtainer.class, 900000001L);
		obtainer.setDescription("Edited Test Obtainer");
		
		obtainerService.save(obtainer);
		
		Obtainer obtainerEdited = (Obtainer) getSession().get(Obtainer.class, 900000001L);
//		Assert.assertNotNull(obtainer.getId());
		Assert.assertEquals(obtainer.getId(), obtainerEdited.getId());
		Assert.assertEquals(obtainer.getDescription(), obtainerEdited.getDescription());
	}
	
	@Test
	public void given_a_obtainer_without_crop_should_throw_exception() {
		init(false);
		Obtainer obtainer = new Obtainer("Test Invalid Obtainer", StatusEnum.ACTIVE, null);
		try {
			obtainerService.save(obtainer);
			Assert.fail();
		} catch (ConstraintException e) {
			ConstraintViolation violation = e.getViolations().get(0);
			Assert.assertEquals("Should have correct message", "error.posting.field.required", violation.getMessage());
			Assert.assertEquals("Should have correct field", "label.obtainer.crop", violation.getField());
		}
	}
	
	@Test
	public void given_a_obtainer_without_description_should_throw_exception() {
		init(false);
		Obtainer obtainer = new Obtainer(null, StatusEnum.ACTIVE, (Crop) getSession().get(Crop.class, 900000001L));
		try {
			obtainerService.save(obtainer);
			Assert.fail();
		} catch (ConstraintException e) {
			ConstraintViolation violation = e.getViolations().get(0);
			Assert.assertEquals("Should have correct message", "error.posting.field.required", violation.getMessage());
			Assert.assertEquals("Should have correct field", "label.obtainer.description", violation.getField());
		}
	}
	
	@Test
	public void given_a_obtainer_with_existing_description_and_crop_should_throw_exception() {
		init(false);
		Obtainer obtainer = new Obtainer("OBTAINER1", StatusEnum.ACTIVE, (Crop) getSession().get(Crop.class, 900000001L));
		try {
			obtainerService.save(obtainer);
			Assert.fail();
		} catch (ConstraintException e) {
			ConstraintViolation violation = e.getViolations().get(0);
			Assert.assertEquals("Should have correct message", "error.obtainer.save", violation.getMessage());
		}
	}

	@Test
	public void test_delete_new_obtainer_should_be_success() throws BusinessException {
		init();
		Obtainer obtainer = ObtainerTestData.createActiveObtainer(this.systemTestFixture.soy);
		getSession().saveOrUpdate(obtainer);
		getSession().flush();
		
        Long id = obtainer.getId();
        
        obtainerService.delete(obtainer);
        
        Assert.assertNull("Obtainer should have been deleted.", obtainerService.selectById(id));
	}
	
	@Test
	public void when_delete_a_obtainer_associated_to_cultivar_should_throw_exception() throws BusinessException {
		init();
		Obtainer obtainer = ObtainerTestData.createActiveObtainer(systemTestFixture.soy);
		saveAndFlush(obtainer);
		
		Cultivar cultivar = new Cultivar("Test Cultivar", Boolean.TRUE, Boolean.FALSE, StatusEnum.ACTIVE, systemTestFixture.soy, obtainer, null, Boolean.FALSE);
		saveAndFlush(cultivar);
		
		try {
			obtainerService.delete(obtainer);
			Assert.fail();
		} catch (ConstraintException e) {
			ConstraintViolation violation = e.getViolations().get(0);
			Assert.assertEquals("error.obtainer.associated", violation.getMessage());
			Assert.assertEquals("feature.cultivarCRUD", violation.getField());
		}
	}
	
	@Test
	public void when_delete_a_obtainer_associated_to_multiplier_should_throw_exception() throws BusinessException {
		init(false);
		
		Obtainer associatedObtainer = (Obtainer) getSession().get(Obtainer.class, 900000001L);
		
		try {
			obtainerService.delete(associatedObtainer);
			Assert.fail();
		} catch (ConstraintException e) {
			ConstraintViolation violation = e.getViolations().get(0);
			Assert.assertEquals("error.obtainer.associated", violation.getMessage());
			Assert.assertEquals("label.contract.type.multiplicator", violation.getField());
		}
	}

	@Test
    public void when_obtainer_filter_has_crop_and_status_and_exist_obtainer_that_match_should_return_list() {
		init();
		Obtainer obtainerThatMatch = ObtainerTestData.createActiveObtainer("obtainerThatMatch", this.systemTestFixture.soy);
		getSession().saveOrUpdate(obtainerThatMatch);
		
		Obtainer obtainerForFilter = ObtainerTestData.createActiveObtainer(null, this.systemTestFixture.soy);
    	
		ObtainerFilter obtainerFilter = ObtainerFilter.getInstance().add(obtainerForFilter);
    	
    	List<Obtainer> obtainers = obtainerService.selectObtainerBy(obtainerFilter);
    	
    	Assert.assertNotNull(obtainers);
    	Assert.assertEquals("Should have exactaly one obtainer", 1, obtainers.size());
    	Assert.assertEquals("Returned obtainer and obtainerThatMatch should have same id.", obtainerThatMatch.getId(), obtainers.get(0).getId());
    }

	@Test
    public void when_obtainer_filter_has_null_crop_and_status_and_obtainer_description() {
		init();
		Obtainer obtainerThatMatch = ObtainerTestData.createActiveObtainer("obtainerThatMatch", this.systemTestFixture.soy);
		getSession().saveOrUpdate(obtainerThatMatch);
    	
		ObtainerFilter obtainerFilter = ObtainerFilter.getInstance();
    	
		int criterias = obtainerFilter.countCriterias();
		
		Obtainer obtainer = null;
		Crop crop = null;
		
		obtainerFilter = obtainerFilter.add(obtainer);
		obtainerFilter = obtainerFilter.add(crop);
		obtainerFilter = obtainerFilter.addObtainerDescription(null);
		obtainerFilter = obtainerFilter.addObtainerDescription("");
		obtainerFilter = obtainerFilter.addExactlyObtainerDescription(null);
		obtainerFilter = obtainerFilter.addExactlyObtainerDescription("");
		
		Assert.assertEquals("Criterias number should not be modified", criterias, obtainerFilter.countCriterias());
    }
	
	@Test
    public void when_obtainer_filter_has_all_attributes_and_exist_obtainer_that_match_should_return_list() {
		init();
		Obtainer obtainerThatMatch = ObtainerTestData.createActiveObtainer(this.systemTestFixture.soy);
		getSession().saveOrUpdate(obtainerThatMatch);
    	
		ObtainerFilter obtainerFilter = ObtainerFilter.getInstance().add(obtainerThatMatch);
    	
    	List<Obtainer> obtainers = obtainerService.selectObtainerBy(obtainerFilter);
    	
    	Assert.assertNotNull(obtainers);
    	Assert.assertEquals("Should have exactaly one obtainer", 1, obtainers.size());
    	Assert.assertEquals("Returned obtainer and obtainerThatMatch should have same id.", obtainerThatMatch.getId(), obtainers.get(0).getId());
    }
	
	@Test
    public void when_search_actives_obtainers_should_return_only_obtainers_with_status_active() {
		init(false);
		ObtainerFilter obtainerFilter = ObtainerFilter.getInstance().activeOnly(true);
    	
    	List<Obtainer> obtainers = obtainerService.selectObtainerBy(obtainerFilter);
    	
    	for (Obtainer obtainer : obtainers) {
			Assert.assertEquals("Should return only actives obtainers", StatusEnum.ACTIVE, obtainer.getStatus());
		}
    }
	
	@Test
	public void when_i_associate_classes_to_an_obtainer_they_should_be_saved() {
		init();
		ItsClass randomItsClass = new ItsClass("Test Class", "TC", 0L, StatusEnum.ACTIVE, systemTestFixture.soy);
		saveAndFlush(randomItsClass);
		
		Obtainer obtainer = ObtainerTestData.createActiveObtainer(this.systemTestFixture.soy);
		obtainer.addClass(randomItsClass);
		saveAndFlush(obtainer);
		getSession().evict(obtainer);
		
		Obtainer obtainerBd = obtainerService.selectById(obtainer.getId());
		
		Assert.assertEquals("This obtainer should have 1 class associated", 1, obtainerBd.getItsClasses().size());
	}
	
	@Test
	public void given_a_valid_obtainerByMultiplier_when_i_save_should_return_sucess() {
		init();
		Obtainer obtainerSoy = ObtainerTestData.createActiveObtainer(this.systemTestFixture.soy);
		saveAndFlush(obtainerSoy);
		
		ObtainerByMultiplier obtainerByMultiplier = new ObtainerByMultiplier(saleTestFixture.harvestSoyMonsanto2012, obtainerSoy, saleTestFixture.customer.getId());
		obtainerByMultiplier.setIsCooperative(Boolean.TRUE);
		saveAndFlush(obtainerByMultiplier);
		
		ObtainerByMultiplier obtainerByMultiplierBd = (ObtainerByMultiplier) getSession().get(ObtainerByMultiplier.class, obtainerByMultiplier.getId());
		Assert.assertNotNull("Object should not be null", obtainerByMultiplierBd);
		Assert.assertTrue("ObtainerByMultiplier should be cooperative", obtainerByMultiplierBd.isCooperative());
	}
	
	@Test
	public void given_a_harvest_and_obtainer_when_i_save_obtainerByMultiplier_should_delete_another_obtainerByMultiplier_associated() throws ConstraintException {
		init();
		Obtainer obtainerSoy = ObtainerTestData.createActiveObtainer(this.systemTestFixture.soy);
		saveAndFlush(obtainerSoy);
		
		ObtainerByMultiplier obtainerByMultiplier = new ObtainerByMultiplier(saleTestFixture.harvestSoyMonsanto2012, obtainerSoy, saleTestFixture.customer.getId());
		obtainerByMultiplier.setIsCooperative(Boolean.TRUE);
		saveAndFlush(obtainerByMultiplier);
		
		obtainerService.saveObtainerByMultiplier(saleTestFixture.harvestSoyMonsanto2012, obtainerSoy, new ArrayList<CustomerAssociationDTO>());

		ObtainerByMultiplier obtainerByMultiplierBd = (ObtainerByMultiplier) getSession().get(ObtainerByMultiplier.class, obtainerByMultiplier.getId());
		Assert.assertNull("This obtainerByMultiplier should not exist", obtainerByMultiplierBd);
	}

	@Test
    public void when_obtainer_multiplier_filter_has_null_values() {
		init();
		Obtainer obtainerThatMatch = ObtainerTestData.createActiveObtainer("obtainerThatMatch", this.systemTestFixture.soy);
		getSession().saveOrUpdate(obtainerThatMatch);
    	
		ObtainerByMultiplierFilter obtainerFilter = ObtainerByMultiplierFilter.getInstance();
    	
		int criterias = obtainerFilter.countCriterias();
		
		Obtainer obtainer = null;
		Harvest harvest = null;
		Customer multiplier = null;
		List<Long> multiplierIdList = new ArrayList<Long>();
		
		obtainerFilter.add(obtainer);
		obtainerFilter.add(harvest);
		obtainerFilter.add(multiplier);
		obtainerFilter.add(multiplierIdList);
		
		Assert.assertEquals("Criterias number should not be modified", criterias, obtainerFilter.countCriterias());
    }
		
	@Test
	public void given_a_harvest_and_an_obtainer_when_i_save_obtainerByMultiplier_should_save_with_success() throws ConstraintException {
		init();
		Obtainer obtainerSoy = ObtainerTestData.createActiveObtainer(this.systemTestFixture.soy);
		saveAndFlush(obtainerSoy);
		
		ObtainerByMultiplierFilter obtainerByMultiplierFilter = ObtainerByMultiplierFilter.getInstance()
				.add(saleTestFixture.harvestSoyMonsanto2012)
				.add(obtainerSoy);
		List<ObtainerByMultiplier> obtainerByMultiplierListBD = obtainerService.selectObtainerByMultiplierBy(obtainerByMultiplierFilter);
		
		Assert.assertEquals("DataBase should be empty.", 0, obtainerByMultiplierListBD.size());
		
		CustomerAssociationDTO dto = createCustomerAssociationDTOWith(saleTestFixture.customer);
		dto.setIsCooperative(Boolean.TRUE);
		
		List<CustomerAssociationDTO> customers = new ArrayList<CustomerAssociationDTO>();
		customers.add(dto);
		obtainerService.saveObtainerByMultiplier(saleTestFixture.harvestSoyMonsanto2012, obtainerSoy, customers);
		
		obtainerByMultiplierListBD = obtainerService.selectObtainerByMultiplierBy(obtainerByMultiplierFilter);
		Assert.assertEquals("Should have one obtainerByMultiplier", 1, obtainerByMultiplierListBD.size());
	}
	
	@Test
	public void when_i_filter_obtainerByMultiplier_by_a_list_of_multipliers_and_a_harvest_should_return_four_results() throws ConstraintException {
		init(false);
		
		Harvest harvest = (Harvest) getSession().get(Harvest.class, 900000001L);
		Customer multiplier1 = (Customer) getSession().get(Customer.class, 900000001L);
		Customer multiplier2 = (Customer) getSession().get(Customer.class, 900000002L);
		
		List<Long> multiplierIdList = new ArrayList<Long>();
		multiplierIdList.add(multiplier1.getId());
		multiplierIdList.add(multiplier2.getId());
		
		
		ObtainerByMultiplierFilter filter = ObtainerByMultiplierFilter.getInstance().add(harvest).add(multiplierIdList);
		List<ObtainerByMultiplier> obtainerByMultiplierList = obtainerService.selectObtainerByMultiplierBy(filter);
		
		Assert.assertEquals("Should have one obtainerByMultiplier", 4, obtainerByMultiplierList.size());
		for (ObtainerByMultiplier obtainerByMultiplier : obtainerByMultiplierList) {
			Assert.assertTrue("Multiplier does not match.", multiplierIdList.contains(obtainerByMultiplier.getMultiplier()));
			Assert.assertEquals("Harvest does not match.", harvest, obtainerByMultiplier.getHarvest());
		}
	}
	
	@Test
	public void when_i_filter_obtainerByMultiplier_by_a_multiplier_and_a_harvest_should_return_correct_one_results() throws ConstraintException {
		init(false);
		
		Harvest harvest = (Harvest) getSession().get(Harvest.class, 900000001L);
		Customer multiplier = (Customer) getSession().get(Customer.class, 900000002L);
		
		ObtainerByMultiplierFilter filter = ObtainerByMultiplierFilter.getInstance().add(harvest).add(multiplier);
		List<ObtainerByMultiplier> obtainerByMultiplierList = obtainerService.selectObtainerByMultiplierBy(filter);
		
		Assert.assertEquals("Should have one obtainerByMultiplier", 1, obtainerByMultiplierList.size());
		ObtainerByMultiplier obtainerByMultiplier = obtainerByMultiplierList.get(0);
		Assert.assertEquals("Multiplier does not match.", multiplier.getId(), obtainerByMultiplier.getMultiplier());
		Assert.assertEquals("Harvest does not match.", harvest, obtainerByMultiplier.getHarvest());
	}
	
	@Test(expected = ConstraintException.class)
	public void given_only_obtainer_when_i_save_obtainerByMultiplier_then_save_should_throw_exception() throws ConstraintException {init();
		Obtainer obtainerSoy = ObtainerTestData.createActiveObtainer(this.systemTestFixture.soy);
		saveAndFlush(obtainerSoy);

		obtainerService.saveObtainerByMultiplier(null, obtainerSoy, new ArrayList<CustomerAssociationDTO>());
	}
	
	@Test(expected = ConstraintException.class)
	public void given_only_harvest_when_i_save_obtainerByMultiplier_then_save_should_throw_exception() throws ConstraintException {init();
		obtainerService.saveObtainerByMultiplier(saleTestFixture.harvestSoyMonsanto2012, null, new ArrayList<CustomerAssociationDTO>());
	}
	
	@Test
	public void given_an_obtainerByMultiplierFilter_with_all_attributes_and_exist_obtainerByMultiplier_that_match_when_i_search_for_obtainerByMultipliers_should_return_list() {
		init();
		Obtainer obtainerSoy = ObtainerTestData.createActiveObtainer(this.systemTestFixture.soy);
		saveAndFlush(obtainerSoy);
		
		ObtainerByMultiplier obtainerByMultiplier = new ObtainerByMultiplier(saleTestFixture.harvestSoyMonsanto2012, obtainerSoy, saleTestFixture.customer.getId());
		getSession().saveOrUpdate(obtainerByMultiplier);
		
		ObtainerByMultiplierFilter obtainerByMultiplierFilter = ObtainerByMultiplierFilter.getInstance()
																	.add(saleTestFixture.harvestSoyMonsanto2012)
																	.add(obtainerSoy);
    	
    	List<ObtainerByMultiplier> obtainerByMultipliers = obtainerService.selectObtainerByMultiplierBy(obtainerByMultiplierFilter);
		
		Assert.assertNotNull(obtainerByMultipliers);
    	Assert.assertEquals("Should have exactaly one obtainerByMultiplier", 1, obtainerByMultipliers.size());
    	Assert.assertEquals("Returned obtainerByMultiplier and obtainerByMultiplierThatMatch should have same id.", obtainerByMultiplier.getId(), obtainerByMultipliers.get(0).getId());
	}
	
	
	@Test
	public void given_an_obtainerByMultiplierFilter_with_harvest_that_doesnt_match_with_obtainerByMultiplier_registered_then_search_shouldNotReturn_results() {
		init();
		Obtainer obtainerSoy = ObtainerTestData.createActiveObtainer(this.systemTestFixture.soy);
		saveAndFlush(obtainerSoy);
		
		ObtainerByMultiplier obtainerByMultiplier = new ObtainerByMultiplier(saleTestFixture.harvestSoyMonsanto2012, obtainerSoy, saleTestFixture.customer.getId());
		getSession().saveOrUpdate(obtainerByMultiplier);
		
		ObtainerByMultiplierFilter obtainerByMultiplierFilter = ObtainerByMultiplierFilter.getInstance()
																	.add(saleTestFixture.harvest2011SoyMonsanto)
																	.add(obtainerSoy);
    	
    	List<ObtainerByMultiplier> obtainerByMultipliers = obtainerService.selectObtainerByMultiplierBy(obtainerByMultiplierFilter);
		
		
    	Assert.assertEquals("Should have no obtainerByMultiplier", 0, obtainerByMultipliers.size());
	}	
	
	@Test
	public void given_an_obtainerByMultiplierFilter_with_obtainer_that_doesnt_match_with_obtainerByMultiplier_registered_then_search_shouldNotReturn_results() {
		init();
		Obtainer obtainerSoy = ObtainerTestData.createActiveObtainer(this.systemTestFixture.soy);
		saveAndFlush(obtainerSoy);
		
		Obtainer anotherObtainer = ObtainerTestData.createActiveObtainer(this.systemTestFixture.soy);
		saveAndFlush(anotherObtainer);
		
		ObtainerByMultiplier obtainerByMultiplier = new ObtainerByMultiplier(saleTestFixture.harvestSoyMonsanto2012, obtainerSoy, saleTestFixture.customer.getId());
		getSession().saveOrUpdate(obtainerByMultiplier);
		
		ObtainerByMultiplierFilter obtainerByMultiplierFilter = ObtainerByMultiplierFilter.getInstance()
																	.add(saleTestFixture.harvestSoyMonsanto2012)
																	.add(anotherObtainer);
    	
    	List<ObtainerByMultiplier> obtainerByMultipliers = obtainerService.selectObtainerByMultiplierBy(obtainerByMultiplierFilter);
		
		
    	Assert.assertEquals("Should have no obtainerByMultiplier", 0, obtainerByMultipliers.size());
	}
	
	@Test
	public void given_an_obtainer_with_one_multiplier_associated_when_i_select_associations_then_should_return_one_result() {
		init();
		Obtainer obtainerSoy = ObtainerTestData.createActiveObtainer(this.systemTestFixture.soy);
		saveAndFlush(obtainerSoy);
		
		Long customerId = saleTestFixture.customer.getId();
		ObtainerByMultiplier obtainerByMultiplier = new ObtainerByMultiplier(saleTestFixture.harvestSoyMonsanto2012, obtainerSoy, customerId);
		getSession().saveOrUpdate(obtainerByMultiplier);
		
    	List<CustomerAssociationDTO> customerAssociations = obtainerService.selectObtainerCustomerAssociationsBy(obtainerSoy, saleTestFixture.harvestSoyMonsanto2012);
		
		Assert.assertNotNull(customerAssociations);
    	Assert.assertEquals("Should have exactaly one customerAssociation", 1, customerAssociations.size());
    	Assert.assertEquals("Returned obtainerByMultiplier and obtainerByMultiplierThatMatch should have same id.", customerId, customerAssociations.get(0).getCustomerId());
	}
	
	@Test
	public void given_an_obtainer_with_two_multipliers_associated_when_i_select_associations_then_should_return_two_results() {
		init();
		Obtainer obtainerSoy = ObtainerTestData.createActiveObtainer(this.systemTestFixture.soy);
		saveAndFlush(obtainerSoy);
		
		ObtainerByMultiplier obtainerByMultiplier = new ObtainerByMultiplier(saleTestFixture.harvestSoyMonsanto2012, obtainerSoy, saleTestFixture.customer.getId());
		getSession().saveOrUpdate(obtainerByMultiplier);
		
		ObtainerByMultiplier obtainerByMultiplier2 = new ObtainerByMultiplier(saleTestFixture.harvestSoyMonsanto2012, obtainerSoy, saleTestFixture.affiliate.getId());
		getSession().saveOrUpdate(obtainerByMultiplier2);
		
    	List<CustomerAssociationDTO> customerAssociations = obtainerService.selectObtainerCustomerAssociationsBy(obtainerSoy, saleTestFixture.harvestSoyMonsanto2012);
		
		Assert.assertNotNull(customerAssociations);
    	Assert.assertEquals("Should have exactaly one customerAssociation", 2, customerAssociations.size());
	}
	
	@Test
	public void given_an_obtainer_with_one_multiplier_associated_when_i_select_associations_with_wrong_harvest_then_search_shouldNotReturn_results() {
		init();
		Obtainer obtainerSoy = ObtainerTestData.createActiveObtainer(this.systemTestFixture.soy);
		saveAndFlush(obtainerSoy);
		
		ObtainerByMultiplier obtainerByMultiplier = new ObtainerByMultiplier(saleTestFixture.harvestSoyMonsanto2012, obtainerSoy, saleTestFixture.customer.getId());
		getSession().saveOrUpdate(obtainerByMultiplier);
    	
    	List<CustomerAssociationDTO> customerAssociations = obtainerService.selectObtainerCustomerAssociationsBy(obtainerSoy, saleTestFixture.harvest2011SoyMonsanto);
		
    	Assert.assertEquals("Should have no obtainerByMultiplier", 0, customerAssociations.size());
	}
	
	@Test
	public void given_an_obtainer_with_one_multiplier_associated_when_i_select_associations_with_another_obtainer_then_search_shouldNotReturn_results() {
		init();
		Obtainer obtainerSoy = ObtainerTestData.createActiveObtainer(this.systemTestFixture.soy);
		saveAndFlush(obtainerSoy);
		
		Obtainer anotherObtainer = ObtainerTestData.createActiveObtainer(this.systemTestFixture.soy);
		saveAndFlush(anotherObtainer);
		
		ObtainerByMultiplier obtainerByMultiplier = new ObtainerByMultiplier(saleTestFixture.harvestSoyMonsanto2012, obtainerSoy, saleTestFixture.customer.getId());
		getSession().saveOrUpdate(obtainerByMultiplier);
		
    	List<CustomerAssociationDTO> customerAssociations = obtainerService.selectObtainerCustomerAssociationsBy(anotherObtainer, saleTestFixture.harvestSoyMonsanto2012);
		
    	Assert.assertEquals("Should have no obtainerByMultiplier", 0, customerAssociations.size());
	}
	

    @Test
    public void sanity_select_all_customer_by_test() {
    	init(false);
    	Crop crop = (Crop) getSession().get(Crop.class, CROP1);
        Company company = (Company) getSession().get(Company.class, COMPANY1);
        
        Set<CustomerAssociationDTO> customers = obtainerService.selectAllCustomerWithValidContractsBy(crop, company, ParticipantTypeEnum.MULTIPLICADOR);
        Assert.assertEquals("Should be equal to", 3, customers.size());
    }
    
	
    @Test
    public void given_valid_customers_formatter_should_provide_valid_values() {
        init(false);
        Crop crop = (Crop) getSession().get(Crop.class, CROP1);
        Company company = (Company) getSession().get(Company.class, COMPANY1);
        Set<CustomerAssociationDTO> customers = obtainerService.selectAllCustomerWithValidContractsBy(crop, company, ParticipantTypeEnum.MULTIPLICADOR);
        for(CustomerAssociationDTO dto:customers) {
            Customer c = (Customer) getSession().get(Customer.class, dto.getCustomerId());
            Assert.assertEquals("Should be equal", dto.getDocument(), c.getDocument().getValue());
            Assert.assertEquals("Should be equal", dto.getCustomerName(), c.getName());
            Assert.assertEquals("Should be equal", dto.getCustomerSapCode(), c.getCustomerSAPCode());
            Assert.assertEquals("Should be equal", dto.getStateCode(), c.getAddress().getState().getCode());
            Assert.assertEquals("Should be equal", dto.getCityDescription(), c.getAddress().getCity().getDescription());
            Assert.assertEquals("Should be equal", dto.getDocumentMask(), c.getDocument().getDocumentType().getMask());
            Assert.assertEquals("Should be equal", dto.getFormattedDocument(), c.getDocument().getValueFormatted());
        }
    }

    @Test
    public void given_harvest_customer_obtainer_should_return_proper_boolean_values() {
        init(false);
        Customer cust1 = (Customer) getSession().get(Customer.class,900000001L);
        Customer cust2 = (Customer) getSession().get(Customer.class,900000002L);

        Harvest harvest1 = (Harvest) getSession().get(Harvest.class, 900000001L);
        Harvest harvest2 = (Harvest) getSession().get(Harvest.class, 900000002L);

        Obtainer obtainer1 = (Obtainer) getSession().get(Obtainer.class, 900000001L);
        Obtainer obtainer2 = (Obtainer) getSession().get(Obtainer.class, 900000002L);
        Obtainer obtainer3 = (Obtainer) getSession().get(Obtainer.class, 900000003L);

        Assert.assertTrue("Should be true", obtainerService.selectObtainerIsCooperativeBy(harvest1, cust1, obtainer1));
        Assert.assertFalse("Should be false", obtainerService.selectObtainerIsCooperativeBy(harvest1, cust1, obtainer2));
        Assert.assertTrue("Should be true", obtainerService.selectObtainerIsCooperativeBy(harvest1, cust1, obtainer3));
        Assert.assertTrue("Should be true", obtainerService.selectObtainerIsCooperativeBy(harvest1, cust2, obtainer3));
        Assert.assertTrue("Should be true", obtainerService.selectObtainerIsCooperativeBy(harvest2, cust1, obtainer1));
        Assert.assertFalse("Should be false", obtainerService.selectObtainerIsCooperativeBy(harvest2, cust2, obtainer1));
    }

    @Test
    public void given_invalid_harvest_customer_obtainer_should_return_false() {
        init(false);
        Customer cust2 = (Customer) getSession().get(Customer.class,900000002L);

        Harvest harvest2 = (Harvest) getSession().get(Harvest.class, 900000002L);

        Obtainer obtainer2 = (Obtainer) getSession().get(Obtainer.class, 900000002L);

        Assert.assertFalse("Should be false", obtainerService.selectObtainerIsCooperativeBy(harvest2, cust2, obtainer2));
    }


    @SuppressWarnings("unchecked")
    @Test
    public void given_harvest_and_customer_should_return_correct_number_of_obtainers() {
        init(false);
        Customer cust1 = (Customer) getSession().get(Customer.class,900000001L);
        Customer cust2 = (Customer) getSession().get(Customer.class,900000002L);
        Customer cust3 = (Customer) getSession().get(Customer.class,900000003L);

        Harvest harvest1 = (Harvest) getSession().get(Harvest.class, 900000001L);
        Harvest harvest2 = (Harvest) getSession().get(Harvest.class, 900000002L);

        HashSet<Long> longs = new HashSet<Long>(Arrays.asList(new Long[]{900000001L, 900000002L, 900000003L}));

        List<Obtainer> obtainers = obtainerService.selectObtainersBy(harvest1, cust1);
        assertObtainerResults(longs, obtainers, 3);

        longs = new HashSet<Long>(Arrays.asList(new Long[]{900000003L}));
        obtainers = obtainerService.selectObtainersBy(harvest1, cust2);
        assertObtainerResults(longs, obtainers, 1);

        longs = new HashSet<Long>(Arrays.asList(new Long[]{900000001L}));
        obtainers = obtainerService.selectObtainersBy(harvest2, cust1);
        assertObtainerResults(longs, obtainers, 1);

        longs = new HashSet<Long>(Arrays.asList(new Long[]{900000001L}));
        obtainers = obtainerService.selectObtainersBy(harvest2, cust2);
        assertObtainerResults(longs, obtainers, 1);

        longs = new HashSet<Long>(Arrays.asList(new Long[]{}));
        obtainers = obtainerService.selectObtainersBy(harvest2, cust3);
        assertObtainerResults(longs, obtainers, 0);

    }

    private void assertObtainerResults(HashSet<Long> longs, List<Obtainer> obtainers, int num) {
        Assert.assertEquals("Should have 3", num, obtainers.size());
        for(Obtainer obtainer:obtainers) {
            longs.remove(obtainer.getId());
        }
        Assert.assertTrue("Should all be accounted for", longs.isEmpty());
    }

    private CustomerAssociationDTO createCustomerAssociationDTOWith(Customer customer) {
		return new CustomerAssociationDTO(customer.getId(),
				customer.getDocumentValue(),
				customer.getDocument().getDocumentType().getMask(),
				customer.getName(),
				customer.getAddress().getCity().getDescription(),
				customer.getAddress().getState().getCode(),
				customer.getCustomerSAPCode());
    }
    
    @Test
    public void active_only_test() {
        init();
        
        Obtainer obtainerForFilter = ObtainerTestData.createActiveObtainer(null, this.systemTestFixture.soy);
        ObtainerFilter obtainerFilter = ObtainerFilter.getInstance().add(obtainerForFilter);
        
        Assert.assertNotNull(obtainerFilter.activeOnly(true));
        Assert.assertNotNull(obtainerFilter.activeOnly(false));
    }    
    
    @Test
    public void given_harvest_should_return_proper_obtainer_list() {
    	initObtainerByHarvest();

        Harvest harvest1 = (Harvest) getSession().get(Harvest.class, 900000001L);
        
        List<Obtainer> obtainers = obtainerService.selectObtainerByHarvest(harvest1);

        Assert.assertFalse("Should be false", obtainers.isEmpty());

    }
}
