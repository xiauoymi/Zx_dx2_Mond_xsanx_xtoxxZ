/**
 * 
 */
package com.monsanto.brazilvaluecapture.multiplier.volumereport.service.parser;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.math.BigDecimal;
import java.util.List;
import java.util.Locale;
import java.util.ResourceBundle;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;

import com.monsanto.brazilvaluecapture.core.base.model.bean.Company;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Crop;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Document;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Customer;
import com.monsanto.brazilvaluecapture.core.foundation.service.BusinessException;
import com.monsanto.brazilvaluecapture.core.foundation.test.AbstractServiceIntegrationTests;
import com.monsanto.brazilvaluecapture.core.foundation.test.dbunit.DbUnitHelper;
import com.monsanto.brazilvaluecapture.core.grower.model.bean.Grower;
import com.monsanto.brazilvaluecapture.core.importfile.model.bean.CsvImportFile;
import com.monsanto.brazilvaluecapture.core.io.ProcessorConfig;
import com.monsanto.brazilvaluecapture.core.io.ProcessorConfig.ProcessorConfigProperties;
import com.monsanto.brazilvaluecapture.core.user.model.bean.ItsUser;
import com.monsanto.brazilvaluecapture.core.user.model.bean.ItsUser.UserTypeEnum;
import com.monsanto.brazilvaluecapture.core.user.model.bean.UserDecorator;
import com.monsanto.brazilvaluecapture.multiplier.discardportioning.model.bean.DiscardPortioningImportDTO;
import com.monsanto.brazilvaluecapture.multiplier.volumereport.model.bean.DiscardPortioning;
import com.monsanto.brazilvaluecapture.multiplier.volumereport.model.bean.DiscardPortioningCsvImportResult;
import com.monsanto.brazilvaluecapture.multiplier.volumereport.model.bean.DiscardPortioningCsvImportedLine;
import com.monsanto.brazilvaluecapture.multiplier.volumereport.model.bean.VolumeReportDetail;
import com.monsanto.brazilvaluecapture.multiplier.volumereport.model.bean.VolumeReportHeader;
import com.monsanto.brazilvaluecapture.multiplier.volumereport.service.VolumeReportService;
import com.monsanto.brazilvaluecapture.seedsale.harvest.model.bean.Harvest;

/**
 * @author andregc
 *
 */
public class DiscardPortioningProcessor_AT extends AbstractServiceIntegrationTests {

	
	private static final String CSV_HEADER = "Descarte para Cooperante;Ano Operacional;Nome da Safra;Tipo Documento Filial;N�mero Documento Filial;C�digo ERP Filial;Nome Obtentora;Abrevia��o da Classe;C�digo Cultivar;Tipo Documento Cooperante;N�mero Documento Cooperante;�rea Hectare";

	private ProcessorConfig processorConfig;

	private Locale localeBR = new Locale("pt", "BR");
	private ResourceBundle resourceBundle = ResourceBundle.getBundle("bundle/bundle");

	@Autowired
	private DiscardPortioningProcessor processor;
	
	@Autowired
	private VolumeReportService volumeReportService;
	
	@Before
	public void setup() {
		UserDecorator decorator = new UserDecorator(null, new ItsUser("userLogin", UserTypeEnum.SUPER));
		
		processorConfig = new ProcessorConfig();
        processorConfig.put(ProcessorConfigProperties.SELECTED_LOCALE, localeBR);
        processorConfig.put(ProcessorConfigProperties.LOGGED_USER, decorator);
        processorConfig.put(ProcessorConfigProperties.FILENAME, "sample.csv");
        processorConfig.put(ProcessorConfigProperties.BUNDLE, resourceBundle);
	}

    public void setupDatabase() {
        DbUnitHelper.setup(
                "classpath:data/multiplier/basic-fixture.xml",
                "classpath:data/multiplier/discard-portioning-dataset.xml");
    }

    private void initProcessorConfigDTO(Crop crop, Company company, Customer matrix) {
        DiscardPortioningImportDTO dto = new DiscardPortioningImportDTO();
        dto.setCompany(company);
        dto.setCrop(crop);
        dto.setMatrix(matrix);
        processorConfig.put(ProcessorConfigProperties.DTO,dto);
    }

    private Company createMockCompany() {
        Company mock = Mockito.mock(Company.class);
        Mockito.when(mock.getId()).thenReturn(1l);
        return mock;
    }

    private Crop createMockCrop() {
        Crop mock = Mockito.mock(Crop.class);
        Mockito.when(mock.getId()).thenReturn(1L);
        return mock;
    }

    private Customer createMockCustomer() {
        Customer mock = Mockito.mock(Customer.class);
        Mockito.when(mock.getId()).thenReturn(1L);
        return mock;
    }

	@Test
	public void given_3_valid_lines_when_read_should_produce_file_with_3_lines() throws IOException, BusinessException {
        setupDatabase();
		StringBuffer csv = createLineForInputStream(null, "Y", "2012", "SAFRA - 2012", "CNPJ", "22222222", "123123", "OBTAINER", "CLASS", "CULTIVAR", "CPF", "0000001", "500");
		csv = createLineForInputStream(csv, "Y", "2012", "SAFRA - 2012", "CNPJ", "22222222", "123123", "OBTAINER", "CLASS", "CULTIVAR", "CPF", "0000002", "500");
		csv = createLineForInputStream(csv, "Y", "2012", "SAFRA - 2012", "CNPJ", "22222222", "123123", "OBTAINER", "CLASS", "CULTIVAR", "CPF", "0000003", "500");
        initProcessorConfigDTO(createMockCrop(), createMockCompany(), createMockCustomer());


		CsvImportFile csvImportFile = processor.readLines(new ByteArrayInputStream(csv.toString().getBytes()), processorConfig);
		
		List<DiscardPortioningCsvImportedLine> discardPortioningCsvImportedLines = volumeReportService.selectCsvDiscardPortioningImportLinesByFile(csvImportFile);
        Assert.assertEquals("Should be 3", 3, discardPortioningCsvImportedLines.size());

        List<DiscardPortioningCsvImportResult> discardPortioningCsvImportResults = volumeReportService.selectCsvDiscardPortioningImportResultByFile(csvImportFile);
        Assert.assertEquals("Should be 0", 0, discardPortioningCsvImportResults.size());
	}
	
	@Test
	public void given_2_invalid_lines_when_read_should_produce_file_with_2_results() throws IOException, BusinessException {
		StringBuffer csv =  new StringBuffer(CSV_HEADER).append("\n");
        csv.append(";;;;;").append("\n");
        csv = createLineForInputStream(csv, null, null, null, null, null, null, null, null, null, null, null, "INVALID VALUE FOR AREA");
        initProcessorConfigDTO(createMockCrop(), createMockCompany(), createMockCustomer());

		CsvImportFile csvImportFile = processor.readLines(new ByteArrayInputStream(csv.toString().getBytes()), processorConfig);
		
		List<DiscardPortioningCsvImportedLine> discardPortioningCsvImportedLines = volumeReportService.selectCsvDiscardPortioningImportLinesByFile(csvImportFile);
        Assert.assertEquals("Should be 0", 0, discardPortioningCsvImportedLines.size());

        List<DiscardPortioningCsvImportResult> discardPortioningCsvImportResults = volumeReportService.selectCsvDiscardPortioningImportResultByFile(csvImportFile);
        Assert.assertEquals("Should be 2", 2, discardPortioningCsvImportResults.size());
	}
	
	@Test(expected=UnsupportedOperationException.class)
	public void method_read_by_inputStream_should_not_be_implemented() throws IOException, BusinessException {
		StringBuffer csv = createLineForInputStream(null, "Y", "2012", "SAFRA - 2012", "CNPJ", "22222222", "123123", "OBTAINER", "CLASS", "CULTIVAR", "CPF", "0000003", "500");
		processor.read(new ByteArrayInputStream(csv.toString().getBytes()));
	}
	
	@Test(expected=UnsupportedOperationException.class)
	public void method_read_by_processorConfig_should_not_be_implemented() throws IOException, BusinessException {
		processor.read(processorConfig);
	}
	
	@Test(expected=UnsupportedOperationException.class)
	public void method_read_should_not_be_implemented() throws IOException, BusinessException {
		StringBuffer csv = createLineForInputStream(null, "Y", "2012", "SAFRA - 2012", "CNPJ", "22222222", "123123", "OBTAINER", "CLASS", "CULTIVAR", "CPF", "0000003", "500");
		processor.read(new ByteArrayInputStream(csv.toString().getBytes()), processorConfig);
	}
	
	@Test(expected=UnsupportedOperationException.class)
	public void method_readLines_should_not_be_implemented() throws IOException, BusinessException {
		processor.readImportedLines(processorConfig);
	}
	
	@Test(expected=UnsupportedOperationException.class)
	public void method_write_by_file_should_not_be_implemented() throws IOException, BusinessException {
		processor.write(null);
	}

    @Test
    public void given_a_valid_line_with_detail_and_grower_associated_should_save_discard_on_write() {
        setupDatabase();
        VolumeReportDetail detail = getVolumeReportDetailById(900000003l);
        Grower grower = getGrowerById(900000003L);
        BigDecimal area = BigDecimal.valueOf(25.25);
        DiscardPortioningCsvImportedLine line = createImportedLineFromDetail(detail, grower, area, "Y");
        DiscardPortioningCsvImportedFile file = new DiscardPortioningCsvImportedFile();
        file.getValidLinesToImport().add(line);
        processor.write(file, processorConfig);
        getSession().flush();
        getSession().evict(detail);

        detail = getVolumeReportDetailById(900000003L);
        Assert.assertEquals("Should have 1 discard",1, detail.getDiscardPortionings().size());
        DiscardPortioning portioning = detail.getDiscardPortionings().iterator().next();
        Assert.assertEquals("Growers should be equal", grower, portioning.getGrower());
        Assert.assertTrue("Value should be " + area, area.compareTo(portioning.getArea()) == 0);

    }

    @Test
    public void given_a_valid_line_when_i_import_this_line_twice_should_save_two_discards() {
        setupDatabase();
        Grower grower = getGrowerById(900000003L);
        
        VolumeReportDetail detail = getVolumeReportDetailById(900000003l);
        BigDecimal area = BigDecimal.valueOf(25.25);
        DiscardPortioningCsvImportedLine line = createImportedLineFromDetail(detail, grower, area, "Y");
        DiscardPortioningCsvImportedFile file = new DiscardPortioningCsvImportedFile();
        file.getValidLinesToImport().add(line);
        processor.write(file, processorConfig);
        getSession().flush();
        getSession().evict(detail);
        
        detail = getVolumeReportDetailById(900000003l);
        line = createImportedLineFromDetail(detail, grower, area, "Y");
        file = new DiscardPortioningCsvImportedFile();
        file.getValidLinesToImport().add(line);
        processor.write(file, processorConfig);
        getSession().flush();
        getSession().evict(detail);

        detail = getVolumeReportDetailById(900000003L);
        Assert.assertEquals("Should have 2 discard", 2, detail.getDiscardPortionings().size());
    }

    private DiscardPortioningCsvImportedLine createImportedLineFromDetail(VolumeReportDetail detail, Grower grower, BigDecimal area, String cooperativeDiscard) {
        VolumeReportHeader volumeReportHeader = detail.getVolumeReportHeader();
        Harvest harvest = volumeReportHeader.getHarvest();
        Customer customer = volumeReportHeader.getCustomer();
        Document document = customer.getDocument();
        DiscardPortioningCsvImportedLine importedLine = createImportedLine(cooperativeDiscard, harvest.getOperationalYear().getYear(),
                harvest.getDescription(), document.getDocumentType().getDescription(), document.getValue(), customer.getCustomerSAPCode(),
                volumeReportHeader.getObtainer().getDescription(), detail.getItsClass().getAbbreviation(),
                detail.getCultivar().getDescription(), grower.getDocument().getDocumentType().getDescription(),
                grower.getDocument().getValue(), area);
        importedLine.setGrower(grower);
        importedLine.setVolumeReportDetail(detail);
        importedLine.setCooperativeDiscard("Y".equalsIgnoreCase(cooperativeDiscard));
        return importedLine;
    }

    private DiscardPortioningCsvImportedLine createImportedLine(String cooperativeDiscard, String operationalYear,
                                                                String harvest, String customerDocumentType,
                                                                String customerDocument, String customerSAPCode,
                                                                String obtainer, String classAbbreviation,
                                                                String cultivarDescription, String growerDocType,
                                                                String growerDoc, BigDecimal area) {
        DiscardPortioningCsvImportedLine line = new DiscardPortioningCsvImportedLine();
        line.setCooperativeDiscard(cooperativeDiscard);
        line.setOperationalYearDescription(operationalYear);
        line.setHarvestDescription(harvest);
        line.setCustomerDocumentTypeDescription(customerDocumentType);
        line.setCustomerDocument(customerDocument);
        line.setCustomerSAPCode(customerSAPCode);
        line.setObtainerDescription(obtainer);
        line.setClassAbbreviation(classAbbreviation);
        line.setCultivarDescription(cultivarDescription);
        line.setCooperativeDocumentTypeDescription(growerDocType);
        line.setCooperativeDocument(growerDoc);
        line.setArea(area);
        return line;
    }


    private VolumeReportDetail getVolumeReportDetailById(Long id) {
        return (VolumeReportDetail) getSession().get(VolumeReportDetail.class, id);
    }

    private Grower getGrowerById(Long id) {
        return (Grower) getSession().get(Grower.class, id);
    }
	
	private StringBuffer createLineForInputStream(StringBuffer csv,
			String cooperativeDiscard, String operationalYear, String harvest,
			String customerDocumentType, String customerDocument, String customerSAPCode,
			String obtainer, String classAbbreaviation,
			String cultivarDescription, String cooperativeDocumentType,
			String cooperativeDocument, String area) {
		
        if(csv==null) {
            csv = new StringBuffer(CSV_HEADER);
            csv.append("\n");
        }

		csv.append(cooperativeDiscard == null ? "" : cooperativeDiscard).append(";");
		csv.append(operationalYear == null ? "" : operationalYear).append(";");
		csv.append(harvest == null ? "" : harvest).append(";");
		csv.append(customerDocumentType == null ? "" : customerDocumentType).append(";");
		csv.append(customerDocument == null ? "" : customerDocument).append(";");
		csv.append(customerSAPCode == null ? "" : customerSAPCode).append(";");
		csv.append(obtainer == null ? "" : obtainer).append(";");
		csv.append(classAbbreaviation == null ? "" : classAbbreaviation).append(";");
		csv.append(cultivarDescription == null ? "" : cultivarDescription).append(";");
		csv.append(cooperativeDocumentType == null ? "" : cooperativeDocumentType).append(";");
		csv.append(cooperativeDocument == null ? "" : cooperativeDocument).append(";");
		csv.append(area == null ? "" : area);
        
        csv.append("\n");
        
        return csv;
    }
	
}
