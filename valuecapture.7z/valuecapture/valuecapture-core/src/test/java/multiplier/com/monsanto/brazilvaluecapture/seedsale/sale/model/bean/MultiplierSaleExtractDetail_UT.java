package com.monsanto.brazilvaluecapture.seedsale.sale.model.bean;

import com.monsanto.brazilvaluecapture.core.customer.model.bean.Technology;
import com.monsanto.brazilvaluecapture.seedsale.billing.model.bean.PaymentStatus;
import org.junit.Test;

import java.math.BigDecimal;
import java.util.Date;

import static junit.framework.Assert.*;
import static org.mockito.Mockito.mock;

/**
 * Created with IntelliJ IDEA.
 * User: IFERN1
 * Date: 10/9/13
 * Time: 2:38 PM
 */
public class MultiplierSaleExtractDetail_UT {
    @Test
    public void test_RoyaltyCost_Property_isZero_ifNew(){
        MultiplierSaleExtractDetail multiplierSaleExtractDetail = new MultiplierSaleExtractDetail();
        assertTrue(BigDecimal.ZERO.equals(multiplierSaleExtractDetail.getRoyaltyCost()));
    }

    @Test
    public void test_RoyaltyCost_Property(){
        MultiplierSaleExtractDetail multiplierSaleExtractDetail = new MultiplierSaleExtractDetail();
        BigDecimal expectedRoyaltyCost = BigDecimal.TEN;
        multiplierSaleExtractDetail.setRoyaltyCost(expectedRoyaltyCost);
        assertSame(expectedRoyaltyCost, multiplierSaleExtractDetail.getRoyaltyCost());
    }

    @Test
    public void test_RoyaltyPaid_Property_isZero_ifNew(){
        MultiplierSaleExtractDetail multiplierSaleExtractDetail = new MultiplierSaleExtractDetail();
        assertTrue(BigDecimal.ZERO.equals(multiplierSaleExtractDetail.getRoyaltyPaid()));
    }

    @Test
    public void test_RoyaltyPaid_Property(){
        MultiplierSaleExtractDetail multiplierSaleExtractDetail = new MultiplierSaleExtractDetail();
        BigDecimal expectedRoyaltyCost = BigDecimal.TEN;
        multiplierSaleExtractDetail.setRoyaltyPaid(expectedRoyaltyCost);
        assertSame(expectedRoyaltyCost, multiplierSaleExtractDetail.getRoyaltyPaid());
    }

    @Test
    public void test_DueDate_Property(){
        MultiplierSaleExtractDetail multiplierSaleExtractDetail = new MultiplierSaleExtractDetail();
        Date expectedDate = new Date();
        multiplierSaleExtractDetail.setDueDate(expectedDate);
        assertEquals(expectedDate, multiplierSaleExtractDetail.getDueDate());
    }

    @Test
    public void test_PaymentDate_Property(){
        MultiplierSaleExtractDetail multiplierSaleExtractDetail = new MultiplierSaleExtractDetail();
        Date expectedDate = new Date();
        multiplierSaleExtractDetail.setPaymentDate(expectedDate);
        assertEquals(expectedDate, multiplierSaleExtractDetail.getPaymentDate());
    }

    @Test
    public void test_PaymentValue_Property_isZero_ifNew(){
        MultiplierSaleExtractDetail multiplierSaleExtractDetail = new MultiplierSaleExtractDetail();
        assertTrue(BigDecimal.ZERO.equals(multiplierSaleExtractDetail.getPaymentValue()));
    }

    @Test
    public void test_PaymentValue_Property(){
        MultiplierSaleExtractDetail multiplierSaleExtractDetail = new MultiplierSaleExtractDetail();
        BigDecimal expectedPaymentValue = BigDecimal.TEN;
        multiplierSaleExtractDetail.setPaymentValue(expectedPaymentValue);
        assertSame(expectedPaymentValue, multiplierSaleExtractDetail.getPaymentValue());
    }

    @Test
    public void test_PaidValue_Property_isZero_ifNew(){
        MultiplierSaleExtractDetail multiplierSaleExtractDetail = new MultiplierSaleExtractDetail();
        assertTrue(BigDecimal.ZERO.equals(multiplierSaleExtractDetail.getPaidValue()));
    }

    @Test
    public void test_PaidValue_Property(){
        MultiplierSaleExtractDetail multiplierSaleExtractDetail = new MultiplierSaleExtractDetail();
        BigDecimal expectedPaidValue = BigDecimal.TEN;
        multiplierSaleExtractDetail.setPaidValue(expectedPaidValue);
        assertSame(expectedPaidValue, multiplierSaleExtractDetail.getPaidValue());
    }

    @Test
    public void test_setSaleStatus(){
        String paymentStatus = PaymentStatus.FULLY_PAID.getValue();
        MultiplierSaleExtractDetail multiplierSaleExtractDetail = new MultiplierSaleExtractDetail();
        multiplierSaleExtractDetail.setPaymentStatus(PaymentStatus.FULLY_PAID);
        assertSame(paymentStatus, multiplierSaleExtractDetail.getPaymentStatus());
    }

    @Test
    public void test_technologyProperty(){
        MultiplierSaleExtractDetail multiplierSaleExtractDetail = new MultiplierSaleExtractDetail();
        Technology technology = mock(Technology.class);
        multiplierSaleExtractDetail.setTechnology(technology);
        assertEquals(technology, multiplierSaleExtractDetail.getTechnology());
    }
}
