package com.monsanto.brazilvaluecapture.multiplier.obtainer.model.dao.impl;

import com.monsanto.brazilvaluecapture.core.wsiconsole.dao.impl.BaseHibernateUnitTest;
import com.monsanto.brazilvaluecapture.multiplier.obtainer.model.bean.ObtainerPercentage;
import com.monsanto.brazilvaluecapture.multiplier.obtainer.model.dao.ObtainerPercentageFilter;
import org.junit.Before;
import org.junit.Test;

import static org.mockito.Mockito.*;

public class ObtainerPercentageDAOImpl_UT extends BaseHibernateUnitTest {


    @Before
    public void setUp() {

        when(query.uniqueResult()).thenReturn(new ObtainerPercentage());
    }


    @Test
    public void testSave_WhenSaving_ObtainerPercentage() throws Exception {
        ObtainerPercentageDAOImpl obtainerPercentageDAO = new ObtainerPercentageDAOImpl(sessionFactory);
        ObtainerPercentage obtainerPercentage = new ObtainerPercentage();
        obtainerPercentageDAO.saveObtainerPercentage(obtainerPercentage);
        verify(sessionFactory, times(3)).getCurrentSession();
    }

    @Test
    public void testSave_invokeSaveMethodFromSession_WhenObtainerPercentage() throws Exception {
        ObtainerPercentageDAOImpl obtainerPercentageDAO = new ObtainerPercentageDAOImpl(sessionFactory);
        ObtainerPercentage obtainerPercentage = new ObtainerPercentage();
        obtainerPercentageDAO.saveObtainerPercentage(obtainerPercentage);
        verify(session).save(obtainerPercentage);
    }

    @Test
    public void testUpdate_invokeUpdateMethodFromSession_WhenObtainerPercentage() throws Exception {
        ObtainerPercentageDAOImpl obtainerPercentageDAO = new ObtainerPercentageDAOImpl(sessionFactory);
        ObtainerPercentage obtainerPercentage = new ObtainerPercentage();
        obtainerPercentageDAO.updateObtainerPercentage(obtainerPercentage);
        verify(session).update(obtainerPercentage);
    }

    @Test
    public void testSelectObtainerPercentageBy_invokeSaveMethodFromSession_WhenObtainerPercentage() throws Exception {
        ObtainerPercentageDAOImpl obtainerPercentageDAO = new ObtainerPercentageDAOImpl(sessionFactory);
        obtainerPercentageDAO.selectObtainerPercentageBy(ObtainerPercentageFilter.getInstance());
    }


}