package com.monsanto.brazilvaluecapture.multiplier.volumereport.service.impl;

import com.monsanto.brazilvaluecapture.core.base.model.bean.Company;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Crop;
import com.monsanto.brazilvaluecapture.core.commercialhierarchy.model.bean.CommercialHierType;
import com.monsanto.brazilvaluecapture.core.commercialhierarchy.model.bean.ItsDistrict;
import com.monsanto.brazilvaluecapture.core.foundation.test.AbstractServiceIntegrationTests;
import com.monsanto.brazilvaluecapture.core.foundation.test.AssertHelper;
import com.monsanto.brazilvaluecapture.core.foundation.test.dbunit.DbUnitHelper;
import com.monsanto.brazilvaluecapture.multiplier.volumereport.model.bean.EmailByCustomerDistrictVolumeReport;
import com.monsanto.brazilvaluecapture.multiplier.volumereport.model.bean.EmailByCustomerDistrictVolumeReportDTO.EmailByCustomerDistrictVolumeReportDetail;
import com.monsanto.brazilvaluecapture.multiplier.volumereport.model.bean.VolumeReportFieldEnum;
import com.monsanto.brazilvaluecapture.multiplier.volumereport.model.dao.VolumeReportEmailDAO;
import com.monsanto.brazilvaluecapture.multiplier.volumereport.model.dao.VolumeReportEmailFilter;
import com.monsanto.brazilvaluecapture.multiplier.volumereport.service.VolumeReportEmailService;
import junit.framework.Assert;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

public class VolumeReportEmailService_AT extends AbstractServiceIntegrationTests {
	public static final Long COMPANY1 = 900000001L;
	public static final Long COMPANY2 = 900000002L;

	public static final Long CROP1 = 900000001L;
	public static final Long CROP2 = 900000002L;
	
	public static final Long ITS_DISTRICT1 = 900000001L;
	public static final Long COMMERCIAL_HIER_TYPE = 2L;
	
	private Company company1;
	private Company company2;
	
	private Crop crop1;
	private Crop crop2;
	
	private ItsDistrict itsDistrict;
	private CommercialHierType commercialHierType;
	
	@Autowired
	private VolumeReportEmailService volumeReportEmailService;
	
	@Autowired
	private VolumeReportEmailDAO volumeReportEmailDAO;
	
	public void setup() {
		DbUnitHelper.setup("classpath:data/multiplier/basic-fixture.xml");
		commercialHierType = (CommercialHierType) getSession().get(CommercialHierType.class, COMMERCIAL_HIER_TYPE);
		company1 = (Company) getSession().get(Company.class, COMPANY1);
		company2 = (Company) getSession().get(Company.class, COMPANY2);
		crop1 = (Crop) getSession().get(Crop.class, CROP1);
		crop2 = (Crop) getSession().get(Crop.class, CROP2);
		itsDistrict = (ItsDistrict) getSession().get(ItsDistrict.class, ITS_DISTRICT1);
	}


	
	@SuppressWarnings("unchecked")
	@Test
	public void given_one_email_by_customer_district_volume_report_saved_when_i_search_all_should_return_saved_object() throws DuplicatedEmailByCustomerDistrictException, EmailByCustomerDistrictFieldsException {
		setup();
		EmailByCustomerDistrictVolumeReport emailByCustomerDistrictVolumeReport = createEmailByCustomerDistrictVolumeReport(company1,
				crop1, itsDistrict.getItsRegion().getRegionSapId(), itsDistrict
				.getItsUnity()
				.getUnitySapId(), itsDistrict.getDistrictSapId());
		volumeReportEmailService.save(emailByCustomerDistrictVolumeReport);
		
		List<EmailByCustomerDistrictVolumeReport> list = getSession().createCriteria(EmailByCustomerDistrictVolumeReport.class).list();
		
		Assert.assertEquals("Should have one saved email report", 1, list.size());
		Assert.assertEquals("Should be equals", emailByCustomerDistrictVolumeReport, list.get(0));
	}
	
	@SuppressWarnings("unchecked")
	@Test(expected=DuplicatedEmailByCustomerDistrictException.class)
	public void given_one_email_already_save_for_same_crop_company_hierarchy_when_i_save_should_throw_exception() throws DuplicatedEmailByCustomerDistrictException, EmailByCustomerDistrictFieldsException {
		setup();
		EmailByCustomerDistrictVolumeReport emailByCustomerDistrictVolumeReport = createEmailByCustomerDistrictVolumeReport(company1,
				crop1, itsDistrict.getItsRegion().getRegionSapId(), itsDistrict
				.getItsUnity()
				.getUnitySapId(), itsDistrict.getDistrictSapId());
		volumeReportEmailService.save(emailByCustomerDistrictVolumeReport);
		
		List<EmailByCustomerDistrictVolumeReport> list = getSession().createCriteria(EmailByCustomerDistrictVolumeReport.class).list();
		
		Assert.assertEquals("Should have one saved email report", 1, list.size());
		Assert.assertEquals("Should be equals", emailByCustomerDistrictVolumeReport, list.get(0));
		
		EmailByCustomerDistrictVolumeReport emailByCustomerDistrictVolumeReportDuplicated = createEmailByCustomerDistrictVolumeReport(company1,
				crop1, itsDistrict.getItsRegion().getRegionSapId(), itsDistrict
				.getItsUnity()
				.getUnitySapId(), itsDistrict.getDistrictSapId());
		volumeReportEmailService.save(emailByCustomerDistrictVolumeReportDuplicated);
	}
	
	@Test
	public void when_i_try_to_save_new_email_by_customer_district_with_null_fields_should_throw_exception() throws DuplicatedEmailByCustomerDistrictException {
		EmailByCustomerDistrictVolumeReport volumeReport = new EmailByCustomerDistrictVolumeReport(
				null, null, null, null, null, null, null, null, null, null,
				null, null, null, null, null);
		
		try {
			volumeReportEmailService.save(volumeReport);
			Assert.fail();
		} catch (EmailByCustomerDistrictFieldsException e) {
			Assert.assertEquals("Should have exact 11 violations", 11, e.getViolations().size());
		}
	}
	
	@Test(expected=IllegalArgumentException.class)
	public void when_i_try_to_search_by_filter_not_using_crop_should_throw_exception() {
		VolumeReportEmailFilter filter = VolumeReportEmailFilter.getInstance(company1, null);
		volumeReportEmailDAO.getByFilter(filter);
	}
	
	@Test(expected=IllegalArgumentException.class)
	public void when_i_try_to_search_by_filter_not_using_company_should_throw_exception() {
		VolumeReportEmailFilter filter = VolumeReportEmailFilter.getInstance(null, crop1);
		volumeReportEmailDAO.getByFilter(filter);
	}
	
	@Test
	public void when_i_search_using_crop_and_company_filters_should_return_two_results() {
		setup();
		saveAndFlush(createEmailByCustomerDistrictVolumeReport(
				company1,
					crop1,
					itsDistrict.getItsRegion().getRegionSapId(), 
					itsDistrict.getItsUnity().getUnitySapId(), itsDistrict.getDistrictSapId()));
		saveAndFlush(createEmailByCustomerDistrictVolumeReport(
				company1,
					crop1,
					itsDistrict.getItsRegion().getRegionSapId(), 
					itsDistrict.getItsUnity().getUnitySapId(), itsDistrict.getDistrictSapId()));
		
		VolumeReportEmailFilter filter = VolumeReportEmailFilter.getInstance(company1, crop1);
		
		List<EmailByCustomerDistrictVolumeReport> result = volumeReportEmailDAO.getByFilter(filter);
		Assert.assertEquals("Should have two results", 2, result.size());
	}
	
	@Test
	public void when_i_search_using_commercialHierarchy_with_district_should_return_one_result() {
		setup();
		saveAndFlush(createEmailByCustomerDistrictVolumeReport(
				company1,
					crop1, 
					"regionSapId", 
					"unitySapId", "districtSapId"));
		saveAndFlush(createEmailByCustomerDistrictVolumeReport(
				company1,
					crop1,
					itsDistrict.getItsRegion().getRegionSapId(), 
					itsDistrict.getItsUnity().getUnitySapId(), itsDistrict.getDistrictSapId()));
		
		VolumeReportEmailFilter filter = VolumeReportEmailFilter.getInstance(company1, crop1);
		filter.addCommercialHierarchy("unitySapId", "regionSapId", "districtSapId");
		
		List<EmailByCustomerDistrictVolumeReport> result = volumeReportEmailDAO.getByFilter(filter);
		Assert.assertEquals("Should return only one result", 1, result.size());
	}
	
	@Test
	public void when_i_search_using_commercialHierarchy_without_district_should_return_one_result() {
		setup();
		saveAndFlush(createEmailByCustomerDistrictVolumeReport(
				company1,
				crop1, 
				"regionSapId", 
				"unitySapId", "districtSapId"));
		saveAndFlush(createEmailByCustomerDistrictVolumeReport(
				company1,
				crop1,
				itsDistrict.getItsRegion().getRegionSapId(), 
				itsDistrict.getItsUnity().getUnitySapId(), itsDistrict.getDistrictSapId()));
		
		VolumeReportEmailFilter filter = VolumeReportEmailFilter.getInstance(company1, crop1);
		filter.addCommercialHierarchy("unitySapId", "regionSapId", null);
		
		List<EmailByCustomerDistrictVolumeReport> result = volumeReportEmailDAO.getByFilter(filter);
		Assert.assertEquals("Should return only one result", 1, result.size());
	}
	
	@Test
	public void when_i_search_using_commercialHierarchy_with_unityOnly_should_return_one_result() {
		setup();
		saveAndFlush(createEmailByCustomerDistrictVolumeReport(
				company1,
				crop1, 
				"regionSapId", 
				"unitySapId", "districtSapId"));
		saveAndFlush(createEmailByCustomerDistrictVolumeReport(
				company1,
				crop1,
				itsDistrict.getItsRegion().getRegionSapId(), 
				itsDistrict.getItsUnity().getUnitySapId(), itsDistrict.getDistrictSapId()));
		
		VolumeReportEmailFilter filter = VolumeReportEmailFilter.getInstance(company1, crop1);
		filter.addCommercialHierarchy("unitySapId", null, null);
		
		List<EmailByCustomerDistrictVolumeReport> result = volumeReportEmailDAO.getByFilter(filter);
		Assert.assertEquals("Should return only one result", 1, result.size());
	}
	
	@Test
	public void given_two_email_report_saved_when_search_details_should_return_one_result_per_report_phase() {
		setup();
		saveAndFlush(createEmailByCustomerDistrictVolumeReport(
				company1,
				crop1,
				itsDistrict.getItsRegion().getRegionSapId(), 
				itsDistrict.getItsUnity().getUnitySapId(), itsDistrict.getDistrictSapId()));
		saveAndFlush(createEmailByCustomerDistrictVolumeReport(
				company1,
				crop1,
				itsDistrict.getItsRegion().getRegionSapId(), 
				itsDistrict.getItsUnity().getUnitySapId(), itsDistrict.getDistrictSapId()));
		
		VolumeReportEmailFilter filter = VolumeReportEmailFilter.getInstance(company1, crop1);
		filter.addCommercialHierType(commercialHierType.getCommercialHierTypeDesc());
		List<EmailByCustomerDistrictVolumeReportDetail> details = volumeReportEmailService.getEmailVolumeReportDetailsByFilter(filter, null);
	
		Assert.assertEquals("Should have 20 detail result", 20, details.size());
	}
	
	@Test
	public void given_two_email_report_saved_when_search_for_specific_phase_should_return_one_result() {
		setup();
		saveAndFlush(createEmailByCustomerDistrictVolumeReport(
				company1,
				crop1,
				itsDistrict.getItsRegion().getRegionSapId(), 
				itsDistrict.getItsUnity().getUnitySapId(), itsDistrict.getDistrictSapId()));
		
		VolumeReportEmailFilter filter = VolumeReportEmailFilter.getInstance(company1, crop1);
		filter.addCommercialHierType(commercialHierType.getCommercialHierTypeDesc());
		List<EmailByCustomerDistrictVolumeReportDetail> details = volumeReportEmailService
				.getEmailVolumeReportDetailsByFilter(filter, VolumeReportFieldEnum.ENTERED_AREA);
		
		Assert.assertEquals("Should have 1 detail result", 1, details.size());
	}
	
	@Test
	public void given_two_email_report_for_different_companies_when_get_by_filter_should_return_ten_details() {
		setup();
		saveAndFlush(createEmailByCustomerDistrictVolumeReport(
				company1,
				crop1,
				itsDistrict.getItsRegion().getRegionSapId(), 
				itsDistrict.getItsUnity().getUnitySapId(), itsDistrict.getDistrictSapId()));
		saveAndFlush(createEmailByCustomerDistrictVolumeReport(
				company2,
				crop1,
				itsDistrict.getItsRegion().getRegionSapId(), 
				itsDistrict.getItsUnity().getUnitySapId(), itsDistrict.getDistrictSapId()));
		
		VolumeReportEmailFilter filter = VolumeReportEmailFilter.getInstance(company1, crop1);
		filter.addCommercialHierType(commercialHierType.getCommercialHierTypeDesc());
		List<EmailByCustomerDistrictVolumeReportDetail> details = volumeReportEmailService.getEmailVolumeReportDetailsByFilter(filter, null);
		
		Assert.assertEquals("Should have 10 detail result", 10, details.size());
	}
	
	@Test
	public void given_two_email_report_for_different_crops_when_get_by_filter_should_return_ten_details() {
		setup();
		saveAndFlush(createEmailByCustomerDistrictVolumeReport(
				company1,
				crop1,
				itsDistrict.getItsRegion().getRegionSapId(), 
				itsDistrict.getItsUnity().getUnitySapId(), itsDistrict.getDistrictSapId()));
		saveAndFlush(createEmailByCustomerDistrictVolumeReport(
				company1,
				crop2,
				itsDistrict.getItsRegion().getRegionSapId(), 
				itsDistrict.getItsUnity().getUnitySapId(), itsDistrict.getDistrictSapId()));
		
		VolumeReportEmailFilter filter = VolumeReportEmailFilter.getInstance(company1, crop1);
		filter.addCommercialHierType(commercialHierType.getCommercialHierTypeDesc());
		List<EmailByCustomerDistrictVolumeReportDetail> details = volumeReportEmailService.getEmailVolumeReportDetailsByFilter(filter, null);
		
		Assert.assertEquals("Should have 10 detail result", 10, details.size());
	}
	
	@SuppressWarnings("unchecked")
	@Test
	public void given_one_saved_email_volume_report_when_i_delete_should_be_successfull() {
		setup();
		EmailByCustomerDistrictVolumeReport emailVolumeReport = createEmailByCustomerDistrictVolumeReport(
				company1,
				crop1,
				itsDistrict.getItsRegion().getRegionSapId(), 
				itsDistrict.getItsUnity().getUnitySapId(), itsDistrict.getDistrictSapId());
		saveAndFlush(emailVolumeReport);
		
		List<EmailByCustomerDistrictVolumeReport> list = getSession().createCriteria(EmailByCustomerDistrictVolumeReport.class).list();
		Assert.assertEquals("Should have 1 result", 1, list.size());
		
		getSession().clear();
		
		volumeReportEmailService.deleteEmailVolumeReport(emailVolumeReport);
		
		list = getSession().createCriteria(EmailByCustomerDistrictVolumeReport.class).list();
		Assert.assertEquals("Should have 0 result", 0, list.size());
	}
	
	@Test
	public void test_getters_setters() {
		AssertHelper.testGettersAndSetters(new EmailByCustomerDistrictVolumeReport());
	}
	
	private EmailByCustomerDistrictVolumeReport createEmailByCustomerDistrictVolumeReport(Company company, Crop crop, String regionSapId, String unitySapId, String districtSapId) {
		return new EmailByCustomerDistrictVolumeReport(company, crop,
				districtSapId, unitySapId, regionSapId, "vrodrigues.phase1@ciandt.com",
				"vrodrigues.portioning@ciandt.com",
				"vrodrigues.harvest@ciandt.com", "vrodrigues.ubs@ciandt.com",
				"vrodrigues.benefitted@ciandt.com",
				"vrodrigues.approved@ciandt.com",
				"vrodrigues.commercialized1@ciandt.com",
				"vrodrigues.commercialized2@ciandt.com",
				"vrodrigues.commercialized3@ciandt.com",
				"vrodrigues.next.harvest@ciandt.com");
	}
}
