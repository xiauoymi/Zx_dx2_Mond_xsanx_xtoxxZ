package com.monsanto.brazilvaluecapture.seedsale.sale.service.impl;

import com.google.common.collect.Sets;
import com.monsanto.brazilvaluecapture.core.base.model.bean.OperationalYear;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Customer;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.ParticipantTypeEnum;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Technology;
import com.monsanto.brazilvaluecapture.core.customer.service.CustomerService;
import com.monsanto.brazilvaluecapture.core.foundation.model.bean.QuotaUsageEnum;
import com.monsanto.brazilvaluecapture.core.foundation.service.EntityNotFoundException;
import com.monsanto.brazilvaluecapture.multiplier.cultivar.model.bean.Cultivar;
import com.monsanto.brazilvaluecapture.seedsale.harvest.model.bean.Harvest;
import com.monsanto.brazilvaluecapture.seedsale.harvest.model.bean.Plantability;
import com.monsanto.brazilvaluecapture.seedsale.product.model.bean.Product;
import com.monsanto.brazilvaluecapture.seedsale.quota.model.bean.Quota;
import com.monsanto.brazilvaluecapture.seedsale.quota.model.bean.QuotaOwner;
import com.monsanto.brazilvaluecapture.seedsale.quota.model.bean.QuotaType;
import com.monsanto.brazilvaluecapture.seedsale.quota.model.dao.QuotaDAO;
import com.monsanto.brazilvaluecapture.seedsale.quota.model.dao.QuotaFilter;
import com.monsanto.brazilvaluecapture.seedsale.quota.service.QuotaService;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.Sale;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.SaleItem;
import com.monsanto.brazilvaluecapture.seedsale.template.model.bean.SaleTemplate;

import java.math.BigDecimal;
import java.util.List;
import java.util.Set;

import static org.mockito.Matchers.any;
import static org.mockito.Mockito.when;


public class MultiplierQuotaData {
    protected QuotaDAO quotaDAO;
    protected Product productGeneratingQuota1;
    protected OperationalYear operationalYear;
    protected Customer multiplier = new Customer("Multiplier", null, null, "MULTI");
    protected Customer customer1 = new Customer("Dealer", null, null, "DEALER");
    protected String lot1 = "LOT 1";
    protected Plantability plantability1 = new Plantability();
    protected QuotaService quotaService;
    protected Product productNotGeneratingQuota;
    Technology technology1 = new Technology("Technology 1", null);
    Technology technology2 = new Technology("Technology 2", null);
    Customer customerHeadOffice;
    Customer multiplierHeadOffice;
    CustomerService customerService;
    private Cultivar generatingQuotaCultivar;

    protected Quota setMultiplierQuotaForProductOf(BigDecimal amount, Product product) throws EntityNotFoundException {
        when(customerService.getCustomerHeadOffice(multiplier, ParticipantTypeEnum.MULTIPLICADOR)).thenReturn(multiplierHeadOffice);
        Quota quota = new Quota(operationalYear, multiplierHeadOffice, product, QuotaType.AVAILABLE);
        quota.deposit(amount);
        quota.setOwner(QuotaOwner.MULTIPLIER);
        when(quotaDAO.getQuotaBy(any(QuotaFilter.class))).thenReturn(quota);
        return quota;
    }

    protected Sale createSaleForProducts(List<Product> productList) {
        final Sale sale = new Sale();
        sale.setId(1245l);
        sale.setInvoiceNumber("INVOICE-NUMBER");
        sale.setCustomer(multiplier);
        sale.setDistributor(customer1);
        Set<SaleItem> saleItems = Sets.newHashSet();
        for (Product product : productList) {
            SaleItem saleItem = createSaleItem(product);
            saleItems.add(saleItem);
        }
        sale.setItems(saleItems);
        return sale;
    }

    protected Sale createSaleWithOneSaleItem() {
        final Sale sale = new Sale();
        sale.setCustomer(multiplier);
        sale.setDistributor(customer1);
        SaleItem saleItem = createSaleItem(productGeneratingQuota1);
        Set<SaleItem> saleItems = Sets.newHashSet(saleItem);
        sale.setItems(saleItems);
        return sale;
    }

    protected Sale createSaleWithOneSaleItem(Customer customerParent) {
        final Sale sale = new Sale();
        sale.setCustomer(multiplier);
        sale.setDistributor(customer1);
        SaleItem saleItem = createSaleItem(productGeneratingQuota1);
        Set<SaleItem> saleItems = Sets.newHashSet(saleItem);
        saleItem.setCustomerParent(customerParent);
        sale.setItems(saleItems);
        return sale;
    }

    private SaleItem createSaleItem(Product product) {
        SaleItem saleItem = new SaleItem();
        saleItem.setSoldQuantity(10l);
        SaleTemplate saleTemplate = new SaleTemplate();
        Harvest harvest = new Harvest();
        harvest.setOperationalYear(operationalYear);
        saleTemplate.setHarvest(harvest);
        saleItem.setSaleTemplate(saleTemplate);
        saleItem.setProduct(product);
        saleItem.setLot(lot1);
        saleItem.setPlantabilityId(plantability1);
        Customer customerParent = new Customer();
        customerParent.setName("Customer_Parent");
        saleItem.setCustomerParent(customerParent);
        return saleItem;
    }

    protected void createProducs() {
        //Cultivar that generates quota
        generatingQuotaCultivar = new Cultivar();
        generatingQuotaCultivar.setProduct(new Product());
        generatingQuotaCultivar.getProduct().setGenerateQuotaPhaseFour(true);

        productGeneratingQuota1 = new Product();
        productGeneratingQuota1.setDescription("productGeneratingQuota1");
        productGeneratingQuota1.setCultivar(generatingQuotaCultivar);
        productGeneratingQuota1.setTechnology(technology1);
        productGeneratingQuota1.setQuotaUsage(QuotaUsageEnum.USE_QUOTA);

        Cultivar notGeneratingQuotaCultivar = new Cultivar();
        notGeneratingQuotaCultivar.setProduct(new Product());
        notGeneratingQuotaCultivar.getProduct().setGenerateQuotaPhaseFour(true);

        productNotGeneratingQuota = new Product();
        productNotGeneratingQuota.setDescription("productNotGeneratingQuota");
        productNotGeneratingQuota.setCultivar(notGeneratingQuotaCultivar);
        productNotGeneratingQuota.setTechnology(technology2);
        productNotGeneratingQuota.setQuotaUsage(QuotaUsageEnum.DONT_USE_QUOTA);
    }

    protected Quota setDistributorQuotaOf(BigDecimal amount, Product product) throws EntityNotFoundException {
        when(customerService.getCustomerHeadOffice(customer1, ParticipantTypeEnum.DISTRIBUTOR)).thenReturn(customerHeadOffice);
        Quota quota = new Quota(operationalYear, customerHeadOffice, product, QuotaType.AVAILABLE);
        quota.setOwner(QuotaOwner.DEALER);
        quota.deposit(amount);
        when(quotaService.fetchOrCreateQuota(customerHeadOffice, product, operationalYear,
                QuotaType.AVAILABLE, lot1, multiplier, plantability1)).thenReturn(quota);
        return quota;
    }

    protected Quota setDistributorQuotaOf1(BigDecimal amount, Product product) throws EntityNotFoundException {
        when(customerService.getCustomerHeadOffice(customer1, ParticipantTypeEnum.DISTRIBUTOR)).thenReturn(customerHeadOffice);
        Quota quota = new Quota(operationalYear, customerHeadOffice, product, QuotaType.AVAILABLE);
        quota.setOwner(QuotaOwner.DEALER);
        quota.deposit(amount);
        when(quotaDAO.getQuotaBy(any(QuotaFilter.class))).thenReturn(quota);
        return quota;
    }
}

