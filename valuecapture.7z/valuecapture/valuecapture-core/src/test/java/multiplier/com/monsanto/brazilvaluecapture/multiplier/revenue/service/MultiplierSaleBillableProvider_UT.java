package com.monsanto.brazilvaluecapture.multiplier.revenue.service;

import com.google.common.collect.Lists;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Company;
import com.monsanto.brazilvaluecapture.core.base.model.bean.OperationalYear;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Contract;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Customer;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Technology;
import com.monsanto.brazilvaluecapture.core.customer.service.CustomerService;
import com.monsanto.brazilvaluecapture.core.foundation.model.bean.SystemParameter;
import com.monsanto.brazilvaluecapture.core.foundation.model.bean.SystemParameterValue;
import com.monsanto.brazilvaluecapture.core.foundation.model.bean.TypeParameter;
import com.monsanto.brazilvaluecapture.core.foundation.service.*;
import com.monsanto.brazilvaluecapture.core.posting.model.bean.ReferenceNameEnum;
import com.monsanto.brazilvaluecapture.core.posting.service.PostingService;
import com.monsanto.brazilvaluecapture.core.revenue.model.bean.RevenueAccount;
import com.monsanto.brazilvaluecapture.core.revenue.model.bean.RevenueType;
import com.monsanto.brazilvaluecapture.core.revenue.service.Billable;
import com.monsanto.brazilvaluecapture.core.revenue.service.RevenueService;
import com.monsanto.brazilvaluecapture.multiplier.cultivar.model.bean.Cultivar;
import com.monsanto.brazilvaluecapture.multiplier.harvestcalendar.model.bean.HarvestCalendar;
import com.monsanto.brazilvaluecapture.multiplier.obtainer.model.bean.Obtainer;
import com.monsanto.brazilvaluecapture.osb.its.api.InfraException;
import com.monsanto.brazilvaluecapture.osb.its.api.PostingDocument;
import com.monsanto.brazilvaluecapture.seedsale.billing.model.bean.Billing;
import com.monsanto.brazilvaluecapture.seedsale.billing.model.bean.BillingCalendar;
import com.monsanto.brazilvaluecapture.seedsale.billing.service.BillingCalendarService;
import com.monsanto.brazilvaluecapture.seedsale.product.model.bean.Product;
import com.monsanto.brazilvaluecapture.seedsale.revenue.model.PostingStatusEnum;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.Sale;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.SaleItem;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.SaleLinkDetail;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.dao.RevenueSaleItemFilter;
import com.monsanto.brazilvaluecapture.seedsale.sale.service.SaleService;
import com.monsanto.brazilvaluecapture.seedsale.template.model.bean.SaleTemplate;
import com.monsanto.brazilvaluecapture.utils.DateUtils;
import junit.framework.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import static junit.framework.Assert.assertEquals;
import static org.fest.assertions.Assertions.assertThat;
import static org.fest.assertions.Fail.fail;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyList;
import static org.mockito.Matchers.anyString;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class MultiplierSaleBillableProvider_UT {

    private static final String MULTIPLIER_SALES_MAT_NUM = "MULTIPLIER_SALES_MAT_NUM";

    @Mock
    private SaleService saleService;

    @Mock
    private RevenueService revenueService;

    @Mock
    private BillingCalendarService billingCalendarService;

    @Mock
    private CustomerService customerService;

    @Mock
    private Company company;

    @Mock
    private Technology technology;

    @Mock
    private Product product;

    @Mock
    private SystemParameterService systemParameterService;

    @Mock
    private SystemParameter parameter;

    @Mock
    private SystemParameterValue parameterValue;

    @Mock
    private Customer customer;

    @Mock
    private Contract contract;

    @Mock
    private HarvestCalendar harvestCalendar;

    @Mock
    private PostingService postingService;

    @InjectMocks
    private MultiplierSaleBillableProvider multiplierSaleBillableProvider = new MultiplierSaleBillableProvider();

    private BillingCalendar billingCalendar;
    private SaleItem saleItem;

    @Before
    public void setUp() throws SystemParameterNotFoundException, SystemParameterInvalidException, SystemParameterDuplicateException {

        SaleTemplate saleTemplate = Mockito.mock(SaleTemplate.class);

        when(saleTemplate.getId()).thenReturn(3L);

        Cultivar cultivar = Mockito.mock(Cultivar.class);
        when(cultivar.getChargeTechnologyPhaseFive()).thenReturn(Boolean.TRUE);
        when(cultivar.getTechnology()).thenReturn(technology);

        when(product.getCultivar()).thenReturn(cultivar);

        when(technology.getDescription()).thenReturn("RR2");

        List<SaleItem> saleItems = new ArrayList<SaleItem>();
        saleItem = Mockito.mock(SaleItem.class);
        when(saleItem.getSaleTemplate()).thenReturn(saleTemplate);
        when(saleItem.getBilling()).thenReturn(Mockito.mock(Billing.class));
        when(saleItem.getProduct()).thenReturn(product);
        when(saleItem.getCustomerParent()).thenReturn(customer);
        when(saleItem.getSale()).thenReturn(Mockito.mock(Sale.class));
        saleItems.add(saleItem);

        List<BillingCalendar> billingCalendars = new ArrayList<BillingCalendar>();
        billingCalendar = new BillingCalendar();
        billingCalendar.setSaleTemplate(saleTemplate);
        billingCalendars.add(billingCalendar);

        when(saleService.getSaleItemsBy(any(RevenueSaleItemFilter.class))).thenReturn(saleItems);
        when(saleService.getSaleItemsBy(anyList())).thenReturn(saleItems);
        when(billingCalendarService.getBillingCalendarsByDateAndCompany(any(Date.class), any(Company.class))).thenReturn(billingCalendars);
        when(systemParameterService.selectParameterByName(any(String.class))).thenReturn(parameter);

        when(parameter.getSystemParameterValue()).thenReturn(parameterValue);

        List<Contract> contracts = new ArrayList<Contract>();
        contracts.add(contract);
        when(customerService.getContractsByCustomerAndCompany((Company) Mockito.anyObject(), (Customer) Mockito.anyObject())).thenReturn(contracts);
    }

    @Test
    public void revenueTypeTest() {
        RevenueType revenueType = multiplierSaleBillableProvider.getRevenueType();

        Assert.assertNotNull(revenueType);
        Assert.assertTrue(revenueType.equals(RevenueType.MULTIPLIER));
    }

    @Test
    public void testBillCallbackUpdatesSaleItemWithRevenueAccount_WhenBilling() throws BusinessException {
        Sale multiplierSale = createSale(Sale.SaleTypeEnum.MULTIPLIER_SEED_SALE);
        final SaleTemplate saleTemplate = new SaleTemplate();
        final Product product = createProduct(Boolean.FALSE);
        final Customer matrix = new Customer();
        final BigDecimal netRoyaltyValueQuantity = new BigDecimal(200);
        final BigDecimal revenueRecognition = new BigDecimal(100);
        SaleItem multiplierSaleItem = new SaleItem(multiplierSale, saleTemplate, product, matrix);
        multiplierSaleItem.setNetRoyaltyValueQuantity(netRoyaltyValueQuantity);
        multiplierSaleItem.setSoldQuantity(100l);
        multiplierSaleItem.setNetQuantity(BigDecimal.ONE);
        multiplierSaleItem.setHaAmount(BigDecimal.ONE);

        final SaleLinkDetail saleLinkDetail = new SaleLinkDetail(multiplierSale, multiplierSaleItem);

        final Sale dealerSale = new Sale();
        final SaleItem dealerSaleItem = new SaleItem(dealerSale, saleTemplate, product, matrix);
        dealerSaleItem.setRevenueRecognition(revenueRecognition);
        dealerSaleItem.setSoldQuantity(10l);
        dealerSaleItem.setPostingDate(new Date());
        dealerSaleItem.setPostingStatus(PostingStatusEnum.REVENUE_RECOGNITION_POSTED);
        saleLinkDetail.consume(dealerSale, BigDecimal.TEN, dealerSaleItem);
        multiplierSaleItem.setSaleLinkDetail(saleLinkDetail);
        saleLinkDetail.getSaleLinkDetailValueSet().iterator().next().setRevenueRecognition(BigDecimal.TEN);

        Billing billing = new Billing();
        multiplierSaleItem.setBilling(billing);
        List<SaleItem> saleItems = Lists.newArrayList(multiplierSaleItem);
        RevenueAccount revenueAccount = createRevenueAccount();
        when(saleService.getSaleItemsBy(anyList())).thenReturn(saleItems);

        multiplierSaleBillableProvider.billCallBack(revenueAccount);

        assertThat(saleItems).onProperty("revenueAccount").contains(revenueAccount);
        verify(saleService).saveSaleItems(saleItems);
    }

    private Product createProduct(Boolean revenueRecognitionExcluded) {
        final Product product = new Product();
        final Cultivar cultivar = new Cultivar();
        final Obtainer obtainer = new Obtainer();
        obtainer.setRevenueRecognitionExcluded(revenueRecognitionExcluded);
        cultivar.setObtainer(obtainer);
        product.setCultivar(cultivar);
        return product;
    }

    @Test
    public void testBillCallbackPosts100AsRevenueTotal_WhenAccumulatedRevenueFromSalesIs100InMultiplierToGrowerSales()
            throws BusinessException, InfraException {
        Sale sale = createSale(Sale.SaleTypeEnum.MULTIPLIER_TO_GROWER_SEED_SALE);
        BigDecimal expectedPostingValue = new BigDecimal(100);
        SaleItem saleItem = createSaleItemWithBilling(sale, new BigDecimal(50), expectedPostingValue, Boolean.FALSE);
        List<SaleItem> saleItems = Lists.newArrayList(saleItem);
        RevenueAccount revenueAccount = createRevenueAccount();
        when(saleService.getSaleItemsBy(anyList())).thenReturn(saleItems);

        multiplierSaleBillableProvider.billCallBack(revenueAccount);

        verify(postingService).submitAndSaveBonusPosting(eq(expectedPostingValue),
                eq(ReferenceNameEnum.REVERSAL_ROYALTIES_REVENUE_RECOGNITION),
                any(Date.class),
                any(Date.class),
                eq("INTACTA"));
    }

    @Test
    public void testBillCallbackPosts150AsRevenueTotal_WhenAccumulatedRevenueFromSalesIs150InMultiplierToGrowerSales()
            throws BusinessException, InfraException {
        Sale sale = createSale(Sale.SaleTypeEnum.MULTIPLIER_TO_GROWER_SEED_SALE);
        BigDecimal expectedPostingValue = new BigDecimal(150);
        SaleItem saleItem = createSaleItemWithBilling(sale, new BigDecimal(100), expectedPostingValue, Boolean.FALSE);
        List<SaleItem> saleItems = Lists.newArrayList(saleItem);
        RevenueAccount revenueAccount = createRevenueAccount();
        when(saleService.getSaleItemsBy(anyList())).thenReturn(saleItems);

        multiplierSaleBillableProvider.billCallBack(revenueAccount);

        verify(postingService).submitAndSaveBonusPosting(eq(expectedPostingValue),
                eq(ReferenceNameEnum.REVERSAL_ROYALTIES_REVENUE_RECOGNITION),
                any(Date.class),
                any(Date.class),
                eq("INTACTA"));
    }

    @Test
    public void testBillCallbackDoNotPostsReferenceReversalRoyaltiesRevenueRecognition_WhenAccumulatedRevenueFromSalesIsZeroInMultiplierToGrowerSales()
            throws BusinessException, InfraException {
        Sale sale = createSale(Sale.SaleTypeEnum.MULTIPLIER_TO_GROWER_SEED_SALE);
        SaleItem saleItem = createSaleItemWithBilling(sale, new BigDecimal(100), BigDecimal.ZERO, Boolean.FALSE);
        List<SaleItem> saleItems = Lists.newArrayList(saleItem);
        RevenueAccount revenueAccount = createRevenueAccount();
        when(saleService.getSaleItemsBy(anyList())).thenReturn(saleItems);

        multiplierSaleBillableProvider.billCallBack(revenueAccount);

        verify(postingService, never()).submitAndSaveBonusPosting(any(BigDecimal.class),
                eq(ReferenceNameEnum.REVERSAL_ROYALTIES_REVENUE_RECOGNITION),
                any(Date.class),
                any(Date.class),
                anyString());
    }

    @Test
    public void testBillCallbackCallsPostingServiceWithPaymentDateEqualsFileDate_whenPostingServiceIsCalled()
            throws BusinessException, InfraException {
        Sale sale = createSale(Sale.SaleTypeEnum.MULTIPLIER_TO_GROWER_SEED_SALE);
        SaleItem saleItem = createSaleItemWithBilling(sale, new BigDecimal(200), new BigDecimal(100), Boolean.FALSE);
        List<SaleItem> saleItems = Lists.newArrayList(saleItem);
        RevenueAccount revenueAccount = createRevenueAccount();
        when(saleService.getSaleItemsBy(anyList())).thenReturn(saleItems);

        multiplierSaleBillableProvider.billCallBack(revenueAccount);

        ArgumentCaptor<Date> paymentDateArgument = ArgumentCaptor.forClass(Date.class);
        ArgumentCaptor<Date> fileDateArgument = ArgumentCaptor.forClass(Date.class);
        verify(postingService).submitAndSaveBonusPosting(any(BigDecimal.class),
                eq(ReferenceNameEnum.BILLING_LARGER_THAN_REVENUE_RECOGNITION),
                paymentDateArgument.capture(),
                fileDateArgument.capture(),
                anyString());

        assertEquals(paymentDateArgument.getValue(), fileDateArgument.getValue());
    }

    @Test
    public void testBillCallbackIgnoresSaleItemsNotRecognized_WhenBillingMULTIPLIER_SEED_SALEsales()
            throws BusinessException, InfraException {
        Sale multiplierSale = createSale(Sale.SaleTypeEnum.MULTIPLIER_SEED_SALE);
        final SaleTemplate saleTemplate = new SaleTemplate();
        final Product product = createProduct(Boolean.FALSE);
        final Customer matrix = new Customer();
        final BigDecimal netRoyaltyValueQuantity = new BigDecimal(200);
        final BigDecimal revenueRecognition = null;
        SaleItem multiplierSaleItem = new SaleItem(multiplierSale, saleTemplate, product, matrix);
        multiplierSaleItem.setNetRoyaltyValueQuantity(netRoyaltyValueQuantity);
        multiplierSaleItem.setSoldQuantity(100l);

        final SaleLinkDetail saleLinkDetail = new SaleLinkDetail(multiplierSale, multiplierSaleItem);

        final Sale dealerSale = new Sale();
        final SaleItem dealerSaleItem = new SaleItem(dealerSale, saleTemplate, product, matrix);
        dealerSaleItem.setRevenueRecognition(revenueRecognition);
        dealerSaleItem.setSoldQuantity(10l);
        dealerSaleItem.setPostingDate(new Date());
        dealerSaleItem.setPostingStatus(PostingStatusEnum.REVENUE_RECOGNITION_POSTED);
        dealerSaleItem.setRevenueRecognition(null);
        saleLinkDetail.consume(dealerSale, BigDecimal.TEN, dealerSaleItem);
        multiplierSaleItem.setSaleLinkDetail(saleLinkDetail);

        Billing billing = new Billing();
        multiplierSaleItem.setBilling(billing);
        List<SaleItem> saleItems = Lists.newArrayList(multiplierSaleItem);
        RevenueAccount revenueAccount = createRevenueAccount();
        when(saleService.getSaleItemsBy(anyList())).thenReturn(saleItems);

        when(saleService.getSaleItemsBy(anyList())).thenReturn(saleItems);

        try {
            multiplierSaleBillableProvider.billCallBack(revenueAccount);
        } catch (NullPointerException e) {
            fail("Should not throw NPE");
        }
    }

    @Test
    public void testBillCallbackIgnoresSaleItemsNotRecognized_WhenBillingMULTIPLIER_TO_GROWER_SEED_SALEsales()
            throws BusinessException, InfraException {
        Sale sale = createSale(Sale.SaleTypeEnum.MULTIPLIER_TO_GROWER_SEED_SALE);
        SaleItem saleItem = createSaleItemWithBilling(sale, new BigDecimal(200), null, Boolean.FALSE);
        List<SaleItem> saleItems = Lists.newArrayList(saleItem);
        RevenueAccount revenueAccount = createRevenueAccount();
        when(saleService.getSaleItemsBy(anyList())).thenReturn(saleItems);

        try {
            multiplierSaleBillableProvider.billCallBack(revenueAccount);
        } catch (NullPointerException e) {
            fail("Should not throw NPE");
        }
    }

    private RevenueAccount createRevenueAccount() {
        return new RevenueAccount(new Customer(), "contractNumber", new OperationalYear("OY"), RevenueType.DISTRIBUTION, new Company(), new Date(), new Date());
    }

    private SaleItem createSaleItemWithBilling(Sale sale, BigDecimal netRoyaltyValueQuantity, BigDecimal revenueRecognition, Boolean revenueRecognitionExcluded) {
        final Product product = createProduct(revenueRecognitionExcluded);
        SaleItem saleItem = new SaleItem(sale, new SaleTemplate(), product, new Customer());
        saleItem.setNetRoyaltyValueQuantity(netRoyaltyValueQuantity);
        saleItem.setRevenueRecognition(revenueRecognition);
        Billing billing = new Billing();
        saleItem.setBilling(billing);
        return saleItem;
    }

    private Sale createSale(Sale.SaleTypeEnum saleType) {
        Sale sale = new Sale();
        sale.setSaleType(saleType);
        return sale;
    }

    @Test
    public void getBillablesTest() throws BusinessException {
        when(harvestCalendar.getFirstCommldVolStart()).thenReturn(Mockito.mock(Date.class));
        when(harvestCalendar.getFirstCommldVolEnd()).thenReturn(Mockito.mock(Date.class));
        when(saleItem.getSale().getCreationDate()).thenReturn(Mockito.mock(Date.class));

        List<Billable> list = multiplierSaleBillableProvider.getBillables(company);

        Assert.assertNotNull(list);
        assertEquals(list.size(), 1);
    }

    @Test
    public void getBillablesNoIntactaMaterialNumberTest() throws BusinessException {

        SystemParameter value = new SystemParameter();
        SystemParameterValue systemParameterValue = new SystemParameterValue(TypeParameter.STRING, "34");
        value.setSystemParameterValue(systemParameterValue);
        when(systemParameterService.selectParameterByName(MULTIPLIER_SALES_MAT_NUM)).thenReturn(value);

        Date today = new Date();

        Calendar cal = Calendar.getInstance();
        cal.setTime(today);
        cal.add(Calendar.DATE, -2);
        Date startDate = cal.getTime();

        Calendar cal2 = Calendar.getInstance();
        cal2.setTime(today);
        cal2.add(Calendar.DATE, +2);
        Date endDate = cal2.getTime();

        when(harvestCalendar.getFirstCommldVolStart()).thenReturn(startDate);
        when(harvestCalendar.getFirstCommldVolEnd()).thenReturn(endDate);
        when(saleItem.getSale().getCreationDate()).thenReturn(Mockito.mock(Date.class));

        List<Billable> list = multiplierSaleBillableProvider.getBillables(company);

        Assert.assertNotNull(list);
        assertEquals(list.size(), 1);
    }

    @Test
    public void testBillCallbackPostsWithFileDateOSBDate_whenREVERSAL_ROYALTIES_REV_RECOG()
            throws BusinessException, InfraException {
        Sale sale = createSale(Sale.SaleTypeEnum.MULTIPLIER_TO_GROWER_SEED_SALE);
        SaleItem saleItem = createSaleItemWithBilling(sale, BigDecimal.valueOf(50), BigDecimal.valueOf(100), Boolean.FALSE);
        List<SaleItem> saleItems = Lists.newArrayList(saleItem);
        RevenueAccount revenueAccount = createRevenueAccount();
        when(saleService.getSaleItemsBy(anyList())).thenReturn(saleItems);

        ArgumentCaptor<BigDecimal> postingValueCaptor = ArgumentCaptor.forClass(BigDecimal.class);
        ArgumentCaptor<ReferenceNameEnum> referenceCaptor = ArgumentCaptor.forClass(ReferenceNameEnum.class);
        ArgumentCaptor<Date> paymentDateCaptor = ArgumentCaptor.forClass(Date.class);
        ArgumentCaptor<Date> fileDateCaptor = ArgumentCaptor.forClass(Date.class);
        ArgumentCaptor<String> technologyNameCaptor = ArgumentCaptor.forClass(String.class);
        when(postingService.submitAndSaveBonusPosting(
                postingValueCaptor.capture(),
                referenceCaptor.capture(),
                paymentDateCaptor.capture(),
                fileDateCaptor.capture(),
                technologyNameCaptor.capture()
        )).thenReturn(mock(PostingDocument.class));

        multiplierSaleBillableProvider.billCallBack(revenueAccount);

        assertEquals(DateUtils.setTimeToMidnight(new Date()), DateUtils.setTimeToMidnight(fileDateCaptor.getValue()));
    }

    @Test
    public void testBillCallbackPostsWithPaymentDateToday_whenREVERSAL_ROYALTIES_REV_RECOG()
            throws BusinessException, InfraException {
        Sale sale = createSale(Sale.SaleTypeEnum.MULTIPLIER_TO_GROWER_SEED_SALE);
        SaleItem saleItem = createSaleItemWithBilling(sale, BigDecimal.valueOf(50), BigDecimal.valueOf(100), Boolean.FALSE);
        List<SaleItem> saleItems = Lists.newArrayList(saleItem);
        RevenueAccount revenueAccount = createRevenueAccount();
        when(saleService.getSaleItemsBy(anyList())).thenReturn(saleItems);

        ArgumentCaptor<BigDecimal> postingValueCaptor = ArgumentCaptor.forClass(BigDecimal.class);
        ArgumentCaptor<ReferenceNameEnum> referenceCaptor = ArgumentCaptor.forClass(ReferenceNameEnum.class);
        ArgumentCaptor<Date> paymentDateCaptor = ArgumentCaptor.forClass(Date.class);
        ArgumentCaptor<Date> fileDateCaptor = ArgumentCaptor.forClass(Date.class);
        ArgumentCaptor<String> technologyNameCaptor = ArgumentCaptor.forClass(String.class);
        when(postingService.submitAndSaveBonusPosting(
                postingValueCaptor.capture(),
                referenceCaptor.capture(),
                paymentDateCaptor.capture(),
                fileDateCaptor.capture(),
                technologyNameCaptor.capture()
        )).thenReturn(mock(PostingDocument.class));

        multiplierSaleBillableProvider.billCallBack(revenueAccount);

        assertEquals(DateUtils.setTimeToMidnight(new Date()), DateUtils.setTimeToMidnight(paymentDateCaptor.getValue()));
    }

    @Test
    public void testBillCallbackPostsWithFileDateOSBDate_whenBILLING_LARGER_THAN_REVENUE_RECOGNITION()
            throws BusinessException, InfraException {
        Sale sale = createSale(Sale.SaleTypeEnum.MULTIPLIER_TO_GROWER_SEED_SALE);
        SaleItem saleItem = createSaleItemWithBilling(sale, BigDecimal.valueOf(200), BigDecimal.valueOf(100), Boolean.FALSE);
        List<SaleItem> saleItems = Lists.newArrayList(saleItem);
        RevenueAccount revenueAccount = createRevenueAccount();
        when(saleService.getSaleItemsBy(anyList())).thenReturn(saleItems);

        ArgumentCaptor<BigDecimal> postingValueCaptor = ArgumentCaptor.forClass(BigDecimal.class);
        ArgumentCaptor<ReferenceNameEnum> referenceCaptor = ArgumentCaptor.forClass(ReferenceNameEnum.class);
        ArgumentCaptor<Date> paymentDateCaptor = ArgumentCaptor.forClass(Date.class);
        ArgumentCaptor<Date> fileDateCaptor = ArgumentCaptor.forClass(Date.class);
        ArgumentCaptor<String> technologyNameCaptor = ArgumentCaptor.forClass(String.class);
        when(postingService.submitAndSaveBonusPosting(
                postingValueCaptor.capture(),
                referenceCaptor.capture(),
                paymentDateCaptor.capture(),
                fileDateCaptor.capture(),
                technologyNameCaptor.capture()
        )).thenReturn(mock(PostingDocument.class));

        multiplierSaleBillableProvider.billCallBack(revenueAccount);

        assertEquals(DateUtils.setTimeToMidnight(new Date()), DateUtils.setTimeToMidnight(fileDateCaptor.getValue()));
    }

    @Test
    public void testBillCallbackPostsWithPaymentDateOSBDate_whenBILLING_LARGER_THAN_REVENUE_RECOGNITION()
            throws BusinessException, InfraException {
        Sale sale = createSale(Sale.SaleTypeEnum.MULTIPLIER_TO_GROWER_SEED_SALE);
        SaleItem saleItem = createSaleItemWithBilling(sale, BigDecimal.valueOf(200), BigDecimal.valueOf(100), Boolean.FALSE);
        List<SaleItem> saleItems = Lists.newArrayList(saleItem);
        RevenueAccount revenueAccount = createRevenueAccount();
        when(saleService.getSaleItemsBy(anyList())).thenReturn(saleItems);

        ArgumentCaptor<BigDecimal> postingValueCaptor = ArgumentCaptor.forClass(BigDecimal.class);
        ArgumentCaptor<ReferenceNameEnum> referenceCaptor = ArgumentCaptor.forClass(ReferenceNameEnum.class);
        ArgumentCaptor<Date> paymentDateCaptor = ArgumentCaptor.forClass(Date.class);
        ArgumentCaptor<Date> fileDateCaptor = ArgumentCaptor.forClass(Date.class);
        ArgumentCaptor<String> technologyNameCaptor = ArgumentCaptor.forClass(String.class);
        when(postingService.submitAndSaveBonusPosting(
                postingValueCaptor.capture(),
                referenceCaptor.capture(),
                paymentDateCaptor.capture(),
                fileDateCaptor.capture(),
                technologyNameCaptor.capture()
        )).thenReturn(mock(PostingDocument.class));

        multiplierSaleBillableProvider.billCallBack(revenueAccount);

        assertEquals(DateUtils.setTimeToMidnight(new Date()), DateUtils.setTimeToMidnight(paymentDateCaptor.getValue()));
    }

    @Test
    public void testBillCallbackWontPost_WhenSaleItemObtainerIsExcluded()
            throws BusinessException, InfraException {
        Sale sale = createSale(Sale.SaleTypeEnum.MULTIPLIER_TO_GROWER_SEED_SALE);
        final Boolean revenueRecognitionExcluded = Boolean.TRUE;
        SaleItem saleItem = createSaleItemWithBilling(sale, BigDecimal.valueOf(200), BigDecimal.valueOf(100), revenueRecognitionExcluded);
        List<SaleItem> saleItems = Lists.newArrayList(saleItem);
        RevenueAccount revenueAccount = createRevenueAccount();
        when(saleService.getSaleItemsBy(anyList())).thenReturn(saleItems);

        multiplierSaleBillableProvider.billCallBack(revenueAccount);

        verifyNoMoreInteractions(postingService);
    }

}
