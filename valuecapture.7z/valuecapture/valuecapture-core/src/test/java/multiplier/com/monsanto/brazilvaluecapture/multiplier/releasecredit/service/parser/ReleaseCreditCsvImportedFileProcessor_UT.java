package com.monsanto.brazilvaluecapture.multiplier.releasecredit.service.parser;

import com.monsanto.brazilvaluecapture.core.base.model.bean.Document;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Customer;
import com.monsanto.brazilvaluecapture.core.io.ImportedFileAdapter;
import com.monsanto.brazilvaluecapture.seedsale.billing.model.bean.Billing;
import com.monsanto.brazilvaluecapture.seedsale.billing.model.bean.CreditStatus;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.ManualReleaseCredit;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.Sale;
import com.monsanto.brazilvaluecapture.seedsale.sale.service.SaleService;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.ArrayList;
import java.util.List;

import static org.mockito.Matchers.anyVararg;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/**
 * Created by IntelliJ IDEA.
 * User: CGLLLO
 * Date: 11/12/13
 * Time: 17:16
 */
public class ReleaseCreditCsvImportedFileProcessor_UT {

    @Mock
    private SaleService saleService;
    @InjectMocks
    private ReleaseCreditCsvImportedFileProcessor releaseCreditCsvImportedFileProcessor;

    @Before
    public void setUp() throws Exception {
        releaseCreditCsvImportedFileProcessor = new ReleaseCreditCsvImportedFileProcessor();
        MockitoAnnotations.initMocks(this);
    }

    private ManualReleaseCredit createManualReleaseCredit(Long saleId, CreditStatus creditStatus, String documentValue) {
        Billing billing = new Billing();
        billing.setCreditStatus(creditStatus);
        Document document = new Document();
        document.setValue(documentValue.replaceAll("\\D*", ""));
        Customer customer = new Customer(null, document, null, null);
        Sale sale = new Sale();
        sale.setId(saleId);
        sale.setCustomer(customer);
        return new ManualReleaseCredit(billing, sale);
    }

    private ReleaseCreditCsvImportedLine createImportedLine(int lineNumber, Long saleId, String document) {
        ReleaseCreditCsvImportedLine releaseCreditCsvImportedLine = new ReleaseCreditCsvImportedLine();
        releaseCreditCsvImportedLine.setLine(lineNumber);
        releaseCreditCsvImportedLine.setSaleNumber(saleId);
        releaseCreditCsvImportedLine.setCustomerDocument(document);
        return releaseCreditCsvImportedLine;
    }

    private ReleaseCreditCsvImportedLine createImportedLine(int lineNumber, Long saleId, String document, String warning) {
        ReleaseCreditCsvImportedLine releaseCreditCsvImportedLine = createImportedLine(lineNumber, saleId, document);
        releaseCreditCsvImportedLine.setWarn(warning);
        return releaseCreditCsvImportedLine;
    }

    private ReleaseCreditCsvImportedLine createImportedLine(int lineNumber, Sale sale) {
        return createImportedLine(lineNumber, sale.getId(), sale.getCustomerDocument());
    }

    @Test
    public void testValidateAndProcess() throws Exception {
        // @Given
        List<ManualReleaseCredit> expected = new ArrayList<ManualReleaseCredit>();
        expected.add(createManualReleaseCredit(23L, CreditStatus.WAITING_FOR_RELEASE_MANUAL, "doc" + expected.size()));

        List<ManualReleaseCredit> allManualReleaseCredits = new ArrayList<ManualReleaseCredit>();
        allManualReleaseCredits.addAll(expected);
        allManualReleaseCredits.add(createManualReleaseCredit(45L, CreditStatus.RELEASED_MANUALLY, "doc" + allManualReleaseCredits.size()));
        allManualReleaseCredits.add(createManualReleaseCredit(4L, CreditStatus.RELEASED_AUTOMATICALLY, "doc" + allManualReleaseCredits.size()));
        when(saleService.getManualReleaseCreditBySaleIds((Long[]) anyVararg())).thenReturn(allManualReleaseCredits);

        final int FIRST_IMPORTED_LINE_POSITION = 2;
        List<ReleaseCreditCsvImportedLine> importedLines = new ArrayList<ReleaseCreditCsvImportedLine>();
        for (int i=0; i < allManualReleaseCredits.size(); i++) {
            importedLines.add(createImportedLine(FIRST_IMPORTED_LINE_POSITION + i, allManualReleaseCredits.get(i).getSale()));
        }
        importedLines.add(createImportedLine(FIRST_IMPORTED_LINE_POSITION + importedLines.size(), 356L, "doc" + importedLines.size(), "warning"));
        importedLines.add(createImportedLine(FIRST_IMPORTED_LINE_POSITION + importedLines.size(), 25L, "doc" + importedLines.size()));

        long badDocumentSaleId = 573L;
        allManualReleaseCredits.add(createManualReleaseCredit(badDocumentSaleId, CreditStatus.WAITING_FOR_RELEASE_MANUAL, "badDocument2892389"));
        importedLines.add(createImportedLine(FIRST_IMPORTED_LINE_POSITION + importedLines.size(), badDocumentSaleId, "doc" + importedLines.size()));

        ImportedFileAdapter<ReleaseCreditCsvImportedLine> importedFile = new ImportedFileAdapter<ReleaseCreditCsvImportedLine>();
        importedFile.setAllLines(importedLines);

        // @When
        releaseCreditCsvImportedFileProcessor.validate(importedFile);
        releaseCreditCsvImportedFileProcessor.process(importedFile);

        // @Then
        verify(saleService).manageManualReleases(eq(expected));
    }
}
