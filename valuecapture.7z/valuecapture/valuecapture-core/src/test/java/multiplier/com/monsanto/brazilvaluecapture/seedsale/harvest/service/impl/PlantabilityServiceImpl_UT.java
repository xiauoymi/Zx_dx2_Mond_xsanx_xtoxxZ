package com.monsanto.brazilvaluecapture.seedsale.harvest.service.impl;

import com.monsanto.brazilvaluecapture.core.foundation.service.BusinessException;
import com.monsanto.brazilvaluecapture.seedsale.harvest.model.bean.Harvest;
import com.monsanto.brazilvaluecapture.seedsale.harvest.model.bean.Plantability;
import com.monsanto.brazilvaluecapture.seedsale.harvest.model.dao.PlantabilityDAO;
import com.monsanto.brazilvaluecapture.seedsale.product.model.bean.ProductivityByRegion;
import com.monsanto.brazilvaluecapture.seedsale.product.model.bean.Region;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.*;

/**
 * Created with IntelliJ IDEA.
 * User: IFERN1
 * Date: 10/2/13
 * Time: 9:51 AM
 * To change this template use File | Settings | File Templates.
 */
@RunWith(MockitoJUnitRunner.class)
public class PlantabilityServiceImpl_UT {
    @Mock
    private PlantabilityDAO plantabilityDAO;

    @InjectMocks
    private PlantabilityServiceImpl plantabilityService;

    @Before
    public void setUp() throws Exception {

    }

    @Test(expected = BusinessException.class)
    public void when_plantabilityIsSaved_then_serviceVerifies_NoPlantabilityWithSameValueExists() throws BusinessException {
        //@Given an existing plantabilities
        Plantability plantability = mock(Plantability.class);
        List<Plantability> plantabilityList = new ArrayList<Plantability>();
        plantabilityList.add(plantability);
        when(plantabilityDAO.selectAllPlantabilityEquals(plantability)).thenReturn(plantabilityList);

        //@When plantability es saved
        plantabilityService.save(plantability);

        //@Then an exception is thrown
    }

    @Test
    public void when_plantabilityIsSaved_andNoSameValuedPlantabilityExists_PlantabilityIsSaved() throws BusinessException {
        //@Given an existing plantabilities
        Plantability plantability = mock(Plantability.class);
        List<Plantability> plantabilityList = new ArrayList<Plantability>();
        when(plantabilityDAO.selectAllPlantabilityEquals(plantability)).thenReturn(plantabilityList);

        //@When plantability es saved
        plantabilityService.save(plantability);

        //@Then plantability is saved
        verify(plantabilityDAO).save(plantability);
    }

    @Test
    public void when_plantability_is_deleted_thenPlantabilityDao_deletesIt() throws BusinessException {
        //@When plantability is sent for deletion
        Plantability plantability = mock(Plantability.class);
        plantabilityService.delete(plantability);

        //@Then the service uses DAO to delete it
        verify(plantabilityDAO).delete(plantability);
    }

    @Test
    public void test_selectById(){
        //@When
        plantabilityService.selectById(1l);
        //@Then
        verify(plantabilityDAO).selectById(1l);
    }

    @Test
    public void test_selectByFilter(){
        Plantability plantability = mock(Plantability.class);
        //@When
        plantabilityService.selectByFilter(plantability);
        //@Then
        verify(plantabilityDAO).selectByFilter(plantability);
    }

    @Test
    public void test_selectByHarvest(){
        Harvest harvest = mock(Harvest.class);
        //@When
        plantabilityService.selectByHarvest(harvest);
        //@Then
        verify(plantabilityDAO).selectByHarvest(harvest);
    }

    @Test
    public void test_selectBy(){
        Harvest harvest = mock(Harvest.class);
        String plantabilityDescription = "someDecription";
        //@When
        plantabilityService.selectBy(plantabilityDescription, harvest);
        //@Then
        verify(plantabilityDAO).selectBy(plantabilityDescription, harvest);
    }

    @Test
    public void test_plantabilitiesByHarvestAndRegion(){
        //@Given
        Region region = new Region();
        Harvest harvest = new Harvest();

        Plantability p1 = mock(Plantability.class);
        when(p1.getHarvest()).thenReturn(harvest);
        Plantability p2 = mock(Plantability.class);
        when(p2.getHarvest()).thenReturn(harvest);
        List<Plantability> plantabilities = new ArrayList<Plantability>();
        plantabilities.add(p1);
        plantabilities.add(p2);
        when(plantabilityDAO.selectByHarvest(harvest)).thenReturn(plantabilities);
        assertEquals(2, plantabilities.size());

        List<ProductivityByRegion> productivityByRegionList = new ArrayList<ProductivityByRegion>();
        ProductivityByRegion productivityByRegion = mock(ProductivityByRegion.class);
        when(productivityByRegion.getRegion()).thenReturn(region);
        when(productivityByRegion.getPlantability()).thenReturn(p1);
        productivityByRegionList.add(productivityByRegion);

        //@When plantabilities are requestes by harvest and region
        List<Plantability> result = plantabilityService.getPlantabilitiesByHarvestAndRegion(harvest, productivityByRegionList, region);

        //@Then plantabilities are filtered
        assertEquals(1, result.size());
    }
}
