package com.monsanto.brazilvaluecapture.core.grower.model.dao.impl;

import com.monsanto.brazilvaluecapture.core.grower.model.dao.BonusRulesFilter;
import com.monsanto.brazilvaluecapture.core.wsiconsole.dao.impl.BaseHibernateUnitTest;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;

import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class BonusRulesDAOImpl_UT extends BaseHibernateUnitTest {
    private BonusRulesDAOImpl bonusRulesDAO;

    @Before
    public void setUp() {
        bonusRulesDAO = new BonusRulesDAOImpl(sessionFactory);
        MockitoAnnotations.initMocks(bonusRulesDAO);
    }

    @Test
    public void test_findByFilter() {
        //@Given
        BonusRulesFilter filter = BonusRulesFilter.getInstance();
        when(filter.buildCriteria(session)).thenReturn(criteria);

        //@When
        bonusRulesDAO.findByFilter(filter);

        //@Should
        verify(criteria).list();
    }

}
