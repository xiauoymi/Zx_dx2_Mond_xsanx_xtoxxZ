/**
 * 
 */
package com.monsanto.brazilvaluecapture.multiplier.volumereport.model.bean;

import org.junit.Assert;
import org.junit.Test;

/**
 * @author andregc
 *
 */
public class VolumeReportUtil_UT {

	@Test
	public void given_one_null_and_one_not_null_element_when_assertNoNullElements_then_method_should_return_false() {
		Assert.assertFalse("Should return false.", VolumeReportUtil.assertNoNullElements("x", null));
	}

	@Test
	public void given_no_null_elements_when_assertNoNullElements_then_method_should_return_true() {
		Assert.assertTrue("Should return true.", VolumeReportUtil.assertNoNullElements("x", "y"));
	}

    @Test
    public void given_multiple_bools_and_should_return_correct_value() {
        Assert.assertFalse("Should be false", VolumeReportUtil.andAll(true, true, true, true, false));
        Assert.assertFalse("Should be false", VolumeReportUtil.andAll(true, false, true, true, false));
        Assert.assertFalse("Should be false", VolumeReportUtil.andAll(true, false, true, true, false));
        Assert.assertFalse("Should be false", VolumeReportUtil.andAll(false, true, true, true, true));
        Assert.assertTrue("Should be true", VolumeReportUtil.andAll(true, true, true, true, true));
    }


    @Test
    public void given_multiple_bools_or_should_return_correct_value() {
        Assert.assertTrue("Should be true", VolumeReportUtil.orAll(false, false, false, false, true));
        Assert.assertTrue("Should be true", VolumeReportUtil.orAll(true, false, false, false, false));
        Assert.assertTrue("Should be true", VolumeReportUtil.orAll(false, false, true, false, true));
        Assert.assertTrue("Should be true", VolumeReportUtil.orAll(false, false, true, false, false));
        Assert.assertFalse("Should be false", VolumeReportUtil.orAll(false, false, false, false, false));
    }
    
    @Test
    public void given_one_null_element_and_one_not_null_when_assertAnyNotNull_then_method_should_return_true() {
		Assert.assertTrue("Should return true.", VolumeReportUtil.assertAnyNotNull(null, "x"));
    }
    
    @Test
    public void given_only_not_null_elements_when_assertAnyNotNull_then_method_should_return_true() {
		Assert.assertTrue("Should return true.", VolumeReportUtil.assertAnyNotNull("x", "x"));
    }
    
    @Test
    public void given_only_null_elements_when_assertAnyNotNull_then_method_should_return_false() {
		Assert.assertFalse("Should return false.", VolumeReportUtil.assertAnyNotNull(null, null));
    }

}
