package com.monsanto.brazilvaluecapture.seedsale.sale.model.bean;

import org.junit.Test;

import java.math.BigDecimal;

import static org.fest.assertions.Assertions.assertThat;

public class SaleLinkDetailValue_UT {
    @Test
    public void testSaleLinkDetailValueInitializesFields_WhenConstructed() {
        Sale dealerSale = new Sale();
        SaleItem saleItem = new SaleItem();
        BigDecimal consumed = BigDecimal.TEN;
        SaleLinkDetail saleLinkDetail = new SaleLinkDetail();

        SaleLinkDetailValue saleLinkDetailValue = new SaleLinkDetailValue(dealerSale, saleItem, consumed, saleLinkDetail);

        assertThat(saleLinkDetailValue.getDealerSale()).isSameAs(dealerSale);
        assertThat(saleLinkDetailValue.getConsumed()).isSameAs(consumed);
        assertThat(saleLinkDetailValue.getSaleLinkDetail()).isSameAs(saleLinkDetail);
    }

}