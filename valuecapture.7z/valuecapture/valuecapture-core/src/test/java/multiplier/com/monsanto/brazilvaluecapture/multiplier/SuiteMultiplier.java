package com.monsanto.brazilvaluecapture.multiplier;

import org.junit.extensions.cpsuite.ClasspathSuite;
import org.junit.runner.RunWith;

@RunWith(value = ClasspathSuite.class)
@ClasspathSuite.ClassnameFilters({"com.monsanto.brazilvaluecapture.multiplier.*AT",
        "com.monsanto.brazilvaluecapture.multiplier.*UT"})
public class SuiteMultiplier {
}
