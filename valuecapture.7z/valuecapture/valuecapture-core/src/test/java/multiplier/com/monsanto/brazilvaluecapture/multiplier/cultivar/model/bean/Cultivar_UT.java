package com.monsanto.brazilvaluecapture.multiplier.cultivar.model.bean;

import com.monsanto.brazilvaluecapture.core.base.model.bean.Company;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Crop;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Technology;
import com.monsanto.brazilvaluecapture.core.foundation.model.bean.StatusEnum;
import com.monsanto.brazilvaluecapture.multiplier.obtainer.model.bean.Obtainer;
import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;
import static org.fest.assertions.Assertions.*;

/**
 * Created by IFERN1 on 2/20/14.
 */
public class Cultivar_UT {
    @Test
    public void whenCultivarTechnologyIs_Intacta_ProductSAPCodeIs_00012121444() {
        //@Given
        Crop crop = new Crop();
        Obtainer obtainer = new Obtainer();
        Company company = new Company("Monsanto");
        Technology technology = new Technology("INTACTA MULTIPLICAÇÃO", company);
        Cultivar cultivar = new Cultivar("Cultivar description", false, false, StatusEnum.ACTIVE, crop, obtainer, technology, false);

        //@When
        String actualMultiplySapCode = cultivar.getMultiplyProductSapCode();

        //@Should
        String expectedMultiplySapCode = "000000000012121444";
        assertEquals(expectedMultiplySapCode, actualMultiplySapCode);
    }

    @Test
    public void whenCultivarTechnologyIs_RR_ProductSAPCodeIs_00010547554() {
        //@Given
        Crop crop = new Crop();
        Obtainer obtainer = new Obtainer();
        Company company = new Company("Monsanto");
        Technology technology = new Technology("RR", company);
        Cultivar cultivar = new Cultivar("Cultivar description", false, false, StatusEnum.ACTIVE, crop, obtainer, technology, false);

        //@When
        String actualMultiplySapCode = cultivar.getMultiplyProductSapCode();

        //@Should
        String expectedMultiplySapCode = "000000000010547554";
        assertEquals(expectedMultiplySapCode, actualMultiplySapCode);
    }

    @Test
    public void whenCultivarTechnologyHasBothIntactaAndRR_Intacta_wins_and_ProductSAPCodeIs_00010547554() {
        //@Given
        Crop crop = new Crop();
        Obtainer obtainer = new Obtainer();
        Company company = new Company("Monsanto");
        Technology technology = new Technology("Intacta RR2 Pro", company);
        Cultivar cultivar = new Cultivar("Cultivar description", false, false, StatusEnum.ACTIVE, crop, obtainer, technology, false);

        //@When
        String actualMultiplySapCode = cultivar.getMultiplyProductSapCode();

        //@Should
        String expectedMultiplySapCode = "000000000012121444";
        assertEquals(expectedMultiplySapCode, actualMultiplySapCode);
    }

    @Test
    public void whenCultivarTechnologyIsNot_RR_or_Intacta_shoudlThrowException() {
        //@Given
        Crop crop = new Crop();
        Obtainer obtainer = new Obtainer();
        Company company = new Company("Monsanto");
        Technology technology = new Technology("Unknown technology", company);
        Cultivar cultivar = new Cultivar("Cultivar description", false, false, StatusEnum.ACTIVE, crop, obtainer, technology, false);

        //@When
        try {
            cultivar.getMultiplyProductSapCode();
            fail("Should throw IllegalStateException");
        } catch (Exception e) {
            //@Should
            assertThat(e).isInstanceOf(IllegalStateException.class).hasMessage("Cultivar CULTIVAR DESCRIPTION has unknown technology UNKNOWN TECHNOLOGY");
        }

    }
}
