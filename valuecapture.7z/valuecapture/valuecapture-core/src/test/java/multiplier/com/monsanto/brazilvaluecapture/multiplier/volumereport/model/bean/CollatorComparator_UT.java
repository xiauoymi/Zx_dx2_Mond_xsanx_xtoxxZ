package com.monsanto.brazilvaluecapture.multiplier.volumereport.model.bean;


import junit.framework.Assert;
import org.junit.Test;

public class CollatorComparator_UT {

    @Test
    public void given_collator_comparator_ordering_should_ignore_accents_and_spaces() {
        Assert.assertTrue(CollatorComparator.getInstance().compare("T3st", "Test")<0);
        Assert.assertTrue(CollatorComparator.getInstance().compare("T\u00e9st", "Tfst")<0);
        Assert.assertTrue(CollatorComparator.getInstance().compare("T\u00e9st", "Test")>0);
        Assert.assertTrue(CollatorComparator.getInstance().compare("T st", "Tfst")<0);
        Assert.assertTrue(CollatorComparator.getInstance().compare("T st", "T\u00e9st")<0);
        Assert.assertTrue(CollatorComparator.getInstance().compare("T st", "T st")==0);
        Assert.assertTrue(CollatorComparator.getInstance().compare("Test", "Test")==0);
        Assert.assertTrue(CollatorComparator.getInstance().compare("T\u00e9st", "T\u00e9st")==0);
        Assert.assertTrue(CollatorComparator.getInstance().compare("T st st", "T st")>0);
        Assert.assertTrue(CollatorComparator.getInstance().compare("T st", "T st st")<0);
        Assert.assertTrue(CollatorComparator.getInstance().compare("T sa", "T st")<0);
        Assert.assertTrue(CollatorComparator.getInstance().compare("T sa", "T ct")>0);
        Assert.assertTrue(CollatorComparator.getInstance().compare("T sa", "T  sa")==0);
        Assert.assertTrue(CollatorComparator.getInstance().compare("", "T sa")<0);
        Assert.assertTrue(CollatorComparator.getInstance().compare(" ", "T sa")<0);
        Assert.assertTrue(CollatorComparator.getInstance().compare("T sa", " ")>0);
        Assert.assertTrue(CollatorComparator.getInstance().compare("T sa", "")>0);
        Assert.assertTrue(CollatorComparator.getInstance().compare(" ", "")==0);

    }
}
