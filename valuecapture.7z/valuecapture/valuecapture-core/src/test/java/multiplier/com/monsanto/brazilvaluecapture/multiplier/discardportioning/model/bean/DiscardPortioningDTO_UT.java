package com.monsanto.brazilvaluecapture.multiplier.discardportioning.model.bean;

import org.junit.Test;

import com.monsanto.brazilvaluecapture.core.foundation.test.AssertHelper;

public class DiscardPortioningDTO_UT {

@Test
public void test_getters_and_setters() {
    AssertHelper.testGettersAndSetters(new DiscardPortioningImportDTO());
}

    
}
