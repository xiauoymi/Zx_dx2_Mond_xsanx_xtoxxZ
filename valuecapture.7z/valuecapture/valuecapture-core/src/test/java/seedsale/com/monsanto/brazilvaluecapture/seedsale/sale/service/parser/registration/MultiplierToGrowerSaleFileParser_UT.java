package com.monsanto.brazilvaluecapture.seedsale.sale.service.parser.registration;

import com.monsanto.brazilvaluecapture.core.foundation.util.csv.CSVReadableInvalidException;
import com.monsanto.brazilvaluecapture.core.importfile.model.bean.CsvImportFile;
import com.monsanto.brazilvaluecapture.core.user.model.bean.UserDecorator;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.CsvMultiplierToGrowerSale;
import com.monsanto.brazilvaluecapture.seedsale.sale.service.MultiplierSaleService;
import com.monsanto.brazilvaluecapture.seedsale.sale.validation.MultiplierToGrowerSaleValidator;
import org.junit.Before;
import org.junit.Test;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import static org.mockito.Matchers.any;
import static org.mockito.Mockito.*;

/**
 * Test for class {@link com.monsanto.brazilvaluecapture.seedsale.sale.service.parser.registration.MultiplierToGrowerSaleFileParser}
 *
 * @author CSOBR1
 */
public class MultiplierToGrowerSaleFileParser_UT {

    /**
     * Class under test.
     */
    private MultiplierToGrowerSaleFileParser test;

    private MultiplierSaleService multiplierSaleService;
    private MultiplierToGrowerSaleValidator multiplierToGrowerSaleValidator;

    @Before
    public void setUp() throws Exception {

        multiplierSaleService = mock(MultiplierSaleService.class);
        multiplierToGrowerSaleValidator = mock(MultiplierToGrowerSaleValidator.class);
        test = new MultiplierToGrowerSaleFileParser(mock(InputStream.class), new Locale("pt", "BR"), mock(UserDecorator.class),
                multiplierSaleService, multiplierToGrowerSaleValidator, "filename");

        this.test = spy(test);
        List<CsvMultiplierToGrowerSale> list = new ArrayList<CsvMultiplierToGrowerSale>();
        list.add(mock(CsvMultiplierToGrowerSale.class));
        doReturn(list).when(test).getCsvSales();
    }

    @Test
    public void test_readFile() throws CSVReadableInvalidException {

        test.readFile();

        verify(multiplierSaleService).saveFileAndLines(any(CsvImportFile.class), anyList());
    }

}
