package com.monsanto.brazilvaluecapture.seedsale.sale;

import org.junit.extensions.cpsuite.ClasspathSuite;
import org.junit.extensions.cpsuite.ClasspathSuite.ClassnameFilters;
import org.junit.runner.RunWith;

@RunWith(value = ClasspathSuite.class)
/*@SuiteClasses(value = { 
		DirectSaleParser_AT.class, 
		SaleService_UT.class,
		SaleService_AT.class, 
		SaleTemplate_AT.class, 
		SaleTemplate_UT.class,
		SaleValidations_AT.class, 
		SaleTemplateService_AT.class, 
		Price_UT.class,
		SaleFilter_UT.class, 
		SaleDAO_AT.class,
		SaleTemplateToProduct_UT.class
})*/
@ClassnameFilters(value={
		"com.monsanto.brazilvaluecapture.seedsale.template.*AT",
		"com.monsanto.brazilvaluecapture.seedsale.template.*UT",
		"com.monsanto.brazilvaluecapture.seedsale.sale.*UT",
		"com.monsanto.brazilvaluecapture.seedsale.sale.*AT",
		"com.monsanto.brazilvaluecapture.seedsale.product.*AT",
		"com.monsanto.brazilvaluecapture.seedsale.product.*UT",
		"!com.monsanto.brazilvaluecapture.seedsale.sale.CSVSaleReader_UT",
		"!com.monsanto.brazilvaluecapture.seedsale.sale.CSVSaleReader_AT",
		"!com.monsanto.brazilvaluecapture.seedsale.sale.CSVReader_UT"})
public class SuiteSale {

}
