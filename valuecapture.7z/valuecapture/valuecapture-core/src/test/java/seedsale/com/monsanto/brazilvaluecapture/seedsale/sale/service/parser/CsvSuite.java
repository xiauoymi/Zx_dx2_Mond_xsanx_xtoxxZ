package com.monsanto.brazilvaluecapture.seedsale.sale.service.parser;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

import com.monsanto.brazilvaluecapture.core.foundation.util.csv.CSVReader_UT;
import com.monsanto.brazilvaluecapture.core.grower.CSVGrowerReader_AT;
import com.monsanto.brazilvaluecapture.core.grower.CSVGrowerReader_UT;
import com.monsanto.brazilvaluecapture.seedsale.billing.parser.CnabProcessor_AT;
import com.monsanto.brazilvaluecapture.seedsale.billing.parser.CnabProcessor_UT;
import com.monsanto.brazilvaluecapture.seedsale.revenue.service.parser.ChargeConsolidateProcessor_AT;
import com.monsanto.brazilvaluecapture.seedsale.sale.service.parser.registration.CSVSaleReader_AT;
import com.monsanto.brazilvaluecapture.seedsale.sale.service.parser.registration.CSVSaleReader_UT;

@RunWith(value = Suite.class)
@SuiteClasses(value = {
		CSVSaleReader_UT.class, 
		CSVSaleReader_AT.class,
		CSVReader_UT.class, 
		CSVGrowerReader_UT.class, 
		CSVGrowerReader_AT.class,
		CnabProcessor_AT.class,
		CnabProcessor_UT.class,
		ChargeConsolidateProcessor_AT.class
})
public class CsvSuite {

}
