package com.monsanto.brazilvaluecapture.seedsale.sale.service.parser.registration;

import static org.fest.reflect.core.Reflection.field;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Matchers.anyLong;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.SortedSet;
import java.util.TreeSet;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

import com.monsanto.brazilvaluecapture.core.foundation.util.parser.ParsedLineResult;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.CsvSale;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.Sale;

/**
 * Test for class {@link DirectSaleParserBuilder}
 * 
 * @author CSOBR1
 *
 */
public class DirectSaleParserBuilder_UT {

	private DirectSaleParserBuilder test;
	
	@Before
    public void setUp() throws Exception {
        test = new DirectSaleParserBuilder();
    }
	
	@Test
	public void test_createSaleFrom() {
		
		CsvSale csvSale = mock(CsvSale.class);
		List<CsvSale> probablySaleItems = new ArrayList<CsvSale>();
		probablySaleItems.add(csvSale);
		Sale result = test.createSaleFrom(csvSale, probablySaleItems);
		
		assertNotNull(result);
		
	}
	
	@Test
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public void test_updateCsvSaleGroups() {
		
		SaleParserResult parserResult = test.getParserResult();
		Map map = field("warningsMap").ofType(Map.class).in(parserResult).get();
		SortedSet<ParsedLineResult> value = new TreeSet<ParsedLineResult>();
		ParsedLineResult parsedLineResult = mock(ParsedLineResult.class);
		when(parsedLineResult.getReadable()).thenReturn(new CsvSale());
		value.add(parsedLineResult);
		map.put(new CsvSale(), value);
		
		Map<CsvSale, List<CsvSale>> candidateSalesMap = test.getCandidateSalesMap();
		List<CsvSale> list = new ArrayList<CsvSale>();
		CsvSale csvSale = mock(CsvSale.class);
		list.add(csvSale);
		candidateSalesMap.put(new CsvSale(), list );
		
		test.updateCsvSaleGroups();
		
		Mockito.verify(csvSale).setSaleGroup(anyLong());
	}

}
