package com.monsanto.brazilvaluecapture.seedsale.harvest;

import java.util.List;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.monsanto.brazilvaluecapture.core.base.SystemTestFixture;
import com.monsanto.brazilvaluecapture.core.foundation.RandomTestData;
import com.monsanto.brazilvaluecapture.core.foundation.model.bean.StatusEnum;
import com.monsanto.brazilvaluecapture.core.foundation.service.BusinessException;
import com.monsanto.brazilvaluecapture.core.foundation.test.AbstractServiceIntegrationTests;
import com.monsanto.brazilvaluecapture.seedsale.harvest.model.bean.Harvest;
import com.monsanto.brazilvaluecapture.seedsale.harvest.model.bean.Plantability;
import com.monsanto.brazilvaluecapture.seedsale.harvest.model.bean.PlantabilitySystemEnum;
import com.monsanto.brazilvaluecapture.seedsale.harvest.model.dao.HarvestFilter;
import com.monsanto.brazilvaluecapture.seedsale.harvest.service.HarvestService;

public class HarvestService_AT extends AbstractServiceIntegrationTests {

	@Autowired
	private HarvestService harvestService;
	
	private Harvest theSavedHarvest;
	
	@Before
	public void init() {
		systemTestFixture = new SystemTestFixture(this);
		
		theSavedHarvest = HarvestTestData.createHarvest(this.systemTestFixture.soy, this.systemTestFixture.operationalYearOf2011, this.systemTestFixture.monsantoBr);
		getSession().saveOrUpdate(theSavedHarvest);
		getSession().flush();
	}
	
	@Test
	public void when_i_create_aNewHarvest_shouldCreate_aNewSystemPlantability() throws BusinessException {
		Harvest harvest = createNewHarvest();
		
		Assert.assertEquals("A new harvest just should have a system plantability",
				harvest.getPlantabilities().iterator().next().getIsPlantabilitySystem(), PlantabilitySystemEnum.YES);
	}
	
	@Test
	public void when_i_update_aHarvest_shouldNotCreate_aNewSystemPlantability() throws BusinessException {
		Harvest harvest = createNewHarvest();
		
		harvest.setDescription(RandomTestData.createRandomString(10));
		
		harvestService.save(harvest, null);

		int numberOfPlantabilitySystem = 0;

		for (Plantability plantability : harvest.getPlantabilities()) {
			if (plantability.getIsPlantabilitySystem().equals(PlantabilitySystemEnum.YES)){
				numberOfPlantabilitySystem++;
			}
		}

		Assert.assertEquals("A harvest just should have a system plantability", numberOfPlantabilitySystem, 1);
	}

	private Harvest createNewHarvest() throws BusinessException {
		Harvest harvest = HarvestTestData.createHarvest(systemTestFixture.soy, systemTestFixture.operationalYearOf2011, systemTestFixture.monsantoBr);
		Plantability systemPlantability = new Plantability(harvest, RandomTestData.createRandomString(10), StatusEnum.ACTIVE, PlantabilitySystemEnum.YES);
		
		harvestService.save(harvest, systemPlantability);
		
		Assert.assertNotNull("Should have a Plantability", harvest.getPlantabilities());
		return harvest;
	}
	
	@Test
	public void testSelectByFilter() throws BusinessException{
		HarvestFilter filter = HarvestFilter.getInstance().add(theSavedHarvest.getCompany()).add(theSavedHarvest.getCrop()).add(theSavedHarvest.getOperationalYear()).add(theSavedHarvest.getStatus());
		List<Harvest> harvests = harvestService.selectByFilter(filter);
        Assert.assertNotNull(harvests);
        Assert.assertFalse(harvests.isEmpty());
	}
	
	@Test
	public void testSelectByFilterWithoutFilters() throws BusinessException{
		HarvestFilter harvestFilter = HarvestFilter.getInstance().add(theSavedHarvest.getCompany()).add(theSavedHarvest.getCrop());
		List<Harvest> harvestBase = harvestService.selectByFilter(harvestFilter);
		assertTestSelectFilter(theSavedHarvest, harvestBase);
	}
	
	@Test
	public void testSelectByFilterWithoutOperationalYear() throws BusinessException{
		HarvestFilter harvestFilter = HarvestFilter.getInstance().add(theSavedHarvest.getCompany()).add(theSavedHarvest.getCrop()).add(theSavedHarvest.getStatus());
		List<Harvest> harvestBase = harvestService.selectByFilter(harvestFilter);
		assertTestSelectFilter(theSavedHarvest, harvestBase);	
		
	}
	
	@Test
	public void testSelectByFilterWithoutStatus() throws BusinessException{
		HarvestFilter harvestFilter = HarvestFilter.getInstance().add(theSavedHarvest.getCompany()).add(theSavedHarvest.getCrop()).add(theSavedHarvest.getOperationalYear());
		List<Harvest> harvestBase = harvestService.selectByFilter(harvestFilter);
		assertTestSelectFilter(theSavedHarvest, harvestBase);	
	}
	
	/**
	 * Check assertNotNull from harvests
	 * @param harvest
	 * @param harvestBase
	 */
	private void assertTestSelectFilter(Harvest harvest,
			List<Harvest> harvestBase) {
		Assert.assertNotNull(harvestBase);
		Assert.assertFalse(harvestBase.isEmpty());
		Assert.assertTrue(harvestBase.size() == 1);
		Assert.assertEquals(harvestBase.iterator().next().getId(), harvest.getId());
	}
	
}
