package com.monsanto.brazilvaluecapture.seedsale.template;

import java.math.BigDecimal;
import java.util.Calendar;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import junit.framework.Assert;

import org.junit.Test;

import com.monsanto.brazilvaluecapture.core.customer.model.bean.Technology;
import com.monsanto.brazilvaluecapture.core.foundation.RandomTestData;
import com.monsanto.brazilvaluecapture.core.foundation.service.BusinessException;
import com.monsanto.brazilvaluecapture.seedsale.harvest.HarvestTestData;
import com.monsanto.brazilvaluecapture.seedsale.harvest.model.bean.Harvest;
import com.monsanto.brazilvaluecapture.seedsale.harvest.model.bean.Plantability;
import com.monsanto.brazilvaluecapture.seedsale.product.PlantabilityTestData;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.NoValueByPlantability;
import com.monsanto.brazilvaluecapture.seedsale.sale.service.PricePlantabilityMandatoryException;
import com.monsanto.brazilvaluecapture.seedsale.template.model.bean.AbstractPrice;
import com.monsanto.brazilvaluecapture.seedsale.template.model.bean.ByExpirationDate;
import com.monsanto.brazilvaluecapture.seedsale.template.model.bean.ByPlantabilityAndExpirationDate;
import com.monsanto.brazilvaluecapture.seedsale.template.model.bean.DueDateValue;
import com.monsanto.brazilvaluecapture.seedsale.template.model.bean.Fix;
import com.monsanto.brazilvaluecapture.seedsale.template.model.bean.FreeValue;
import com.monsanto.brazilvaluecapture.seedsale.template.model.bean.NoValue;
import com.monsanto.brazilvaluecapture.seedsale.template.model.bean.Price;
import com.monsanto.brazilvaluecapture.seedsale.template.model.bean.Price.PriceTypeEnum;
import com.monsanto.brazilvaluecapture.seedsale.template.model.bean.Range;
import com.monsanto.brazilvaluecapture.seedsale.template.model.bean.RoyaltyValue;
import com.monsanto.brazilvaluecapture.seedsale.template.model.bean.SaleTemplate;
import com.monsanto.brazilvaluecapture.seedsale.template.model.bean.SaleTemplateBillingMethodEnum;
import com.monsanto.brazilvaluecapture.seedsale.template.service.DueDateCanNotBeEqualsAnotherException;
import com.monsanto.brazilvaluecapture.seedsale.template.service.DueDateCanNotBeMoreThanTwoException;
import com.monsanto.brazilvaluecapture.seedsale.template.service.PriceDuplicatedExpirationDateException;
import com.monsanto.brazilvaluecapture.seedsale.template.service.PriceExpirationDateMandatoryException;
import com.monsanto.brazilvaluecapture.seedsale.template.service.PriceFixNotHaveMoreThanOneValueException;
import com.monsanto.brazilvaluecapture.seedsale.template.service.PriceMustNotHaveExpirationDateException;
import com.monsanto.brazilvaluecapture.seedsale.template.service.PriceMustNotHavePlantabilityException;
import com.monsanto.brazilvaluecapture.seedsale.template.service.PriceNotHaveValueException;
import com.monsanto.brazilvaluecapture.seedsale.template.service.PriceRangeNotHaveMoreThanTwoValueException;
import com.monsanto.brazilvaluecapture.seedsale.template.service.PriceTypeCanNotBeNoValueException;
import com.monsanto.brazilvaluecapture.seedsale.template.service.PriceValueMandatoryException;

public class Price_UT {

	private Harvest harvest = HarvestTestData.createABrazilianHarvest();
	private SaleTemplate saleTemplate = SaleTemplateTestData.createSaleTemplateTypeSeedSale(harvest);
	private Plantability plantability = PlantabilityTestData.createPlantability(harvest); 
	private Technology technology = saleTemplate.getTechnologies().iterator().next();

	private Date january = createDate(2012, 0, 31);
	private Date march = createDate(2012, 3, 30);
	private Date june = createDate(2012, 5, 31);

	private RoyaltyValue royaltyValueOne = new RoyaltyValue(BigDecimal.ONE);
	private RoyaltyValue royaltyValueTen = new RoyaltyValue(BigDecimal.TEN);

	private RoyaltyValue royaltyValueTenWithExpirationDateInJune = new RoyaltyValue(BigDecimal.TEN, june );
	
	private RoyaltyValue royaltyValueTenWithExpirationDateInJuneAndPlantability = createRoyaltyValueWithPlantability(royaltyValueTenWithExpirationDateInJune);

	@Test
	public void createPricingFixTest() throws BusinessException {
		Price pricing = new Fix(saleTemplate, technology);

		Assert.assertNull(pricing.getPrimaryKey());
		Assert.assertNull(((Fix)pricing).getRoyaltyValue());
		Assert.assertNull(((Fix)pricing).getRoyaltyValue());		
		Assert.assertNotNull(pricing.getTechnology());
		Assert.assertNotNull(pricing.getSaleTemplate());
	}

	@Test(expected=PriceFixNotHaveMoreThanOneValueException.class)
	public void createPricingFixWithMoreThanOneValueTest() throws BusinessException {
		AbstractPrice pricing = new Fix(saleTemplate,technology);
		pricing.addRoyaltyValue(royaltyValueOne);
		pricing.addRoyaltyValue(royaltyValueOne);
	}

	@Test(expected=PriceMustNotHaveExpirationDateException.class)
	public void createPricingFixWithDateExpirationTest() throws BusinessException {
		AbstractPrice pricing = new Fix(saleTemplate,technology);
		pricing.addRoyaltyValue(royaltyValueTenWithExpirationDateInJune);
	}

	@Test
	public void createPricingFixWithOneValueTest() throws BusinessException {
		AbstractPrice pricing = new Fix(saleTemplate,technology);
		pricing.addRoyaltyValue(royaltyValueOne);

		Assert.assertNotNull(((Fix)pricing).getRoyaltyValue());
	}

	@Test(expected=DueDateCanNotBeMoreThanTwoException.class)
	public void add_more_than_two_duedates_in_a_price_throw_exception() throws BusinessException {
		AbstractPrice pricing = new Fix(saleTemplate,technology);
		pricing.addRoyaltyValue(royaltyValueOne);
		pricing.addDueDate(new DueDateValue(january));
		pricing.addDueDate(new DueDateValue(march));
		pricing.addDueDate(new DueDateValue(june));
	}

	@Test(expected=DueDateCanNotBeEqualsAnotherException.class)
	public void add_the_same_due_date_twice_in_a_price_throw_exception() throws BusinessException {
		AbstractPrice pricing = new Fix(saleTemplate,technology);
		pricing.addRoyaltyValue(royaltyValueOne);
		DueDateValue dateValue = new DueDateValue(january);

		pricing.addDueDate(dateValue);
		pricing.addDueDate(dateValue);
	}

	@Test(expected=PriceNotHaveValueException.class)
	public void createPriceNoValueWithRoyaltyValueTest() throws BusinessException {
		AbstractPrice pricing = new NoValue(saleTemplate,technology);
		pricing.addRoyaltyValue(royaltyValueOne);
	}

	@Test(expected=UnsupportedOperationException.class)
	public void createPriceNoValueWithDueDateTest() throws BusinessException {
		AbstractPrice pricing = new NoValue(saleTemplate,technology);
		pricing.addDueDate(new DueDateValue(january));
	}

	@Test(expected=UnsupportedOperationException.class)
	public void createPricingNoValueWithGetRoyaltyTest() throws BusinessException {
		new NoValue(saleTemplate,technology).getRoyaltyValues();
	}
	
	@Test(expected=UnsupportedOperationException.class)
	public void createPricingFreeValueWithGetRoyaltyTest() throws BusinessException {
		new FreeValue(saleTemplate,technology).getRoyaltyValues();
	}
	
	@Test(expected=PriceNotHaveValueException.class)
	public void createPriceFreeValueWithRoyaltyValueTest() throws BusinessException {
		AbstractPrice pricing = new FreeValue(saleTemplate,technology);
		pricing.addRoyaltyValue(royaltyValueOne);
	}

	@Test(expected=PriceRangeNotHaveMoreThanTwoValueException.class)
	public void createPricingRangeWithThreeRoyaltyTest() throws BusinessException {
		AbstractPrice price = new Range(saleTemplate,technology);
		price.addRoyaltyValue(royaltyValueOne);
		price.addRoyaltyValue(royaltyValueTen);
		price.addRoyaltyValue(new RoyaltyValue(BigDecimal.ZERO));
	}

	@Test
	public void createPricingRangeGetMinAndMaxRoyaltyValueTest() throws BusinessException {
		Range pricing = new Range(saleTemplate,technology);
		pricing.addRoyaltyValue(royaltyValueOne);
		pricing.addRoyaltyValue(royaltyValueTen);

		Assert.assertEquals(BigDecimal.ONE.doubleValue(),pricing.getMinRoyaltyValue().getValue().doubleValue(),001D); 
		Assert.assertEquals(BigDecimal.TEN.doubleValue(), pricing.getMaxRoyaltyValue().getValue().doubleValue(),001); 
	}

	@Test
	public void createPriceByPlantabilitySuccessTest() throws BusinessException {
		ByPlantabilityAndExpirationDate pricing = new ByPlantabilityAndExpirationDate(saleTemplate,technology);
		pricing.addRoyaltyValue(royaltyValueTenWithExpirationDateInJuneAndPlantability);
	}

	@Test(expected=PricePlantabilityMandatoryException.class)
	public void createPriceByPlantabilityWithoutPlantabilityInRoyaltyValueTest() throws BusinessException {
		ByPlantabilityAndExpirationDate pricing = new ByPlantabilityAndExpirationDate(saleTemplate,technology);
		pricing.addRoyaltyValue(royaltyValueTenWithExpirationDateInJune);
	}

	@Test(expected=PriceExpirationDateMandatoryException.class)
	public void createPriceByPlantabilityWithoutExpirationDateInRoyaltyValueTest() throws BusinessException{
		ByPlantabilityAndExpirationDate pricing = new ByPlantabilityAndExpirationDate(saleTemplate,technology);

		RoyaltyValue royaltWithPlantabilityButWithoutExpirationDate = royaltyValueTenWithExpirationDateInJuneAndPlantability;
		royaltWithPlantabilityButWithoutExpirationDate.setExpirationDate(null);
		pricing.addRoyaltyValue(royaltWithPlantabilityButWithoutExpirationDate);
	}

	@Test(expected=PriceValueMandatoryException.class)
	public void createPriceWithoutRoyaltyValueTest() throws BusinessException {
		ByPlantabilityAndExpirationDate pricing = new ByPlantabilityAndExpirationDate(saleTemplate,technology);
		pricing.addRoyaltyValue(new RoyaltyValue());
	}

	@Test
	public void createPriceObject() {
		Price price = new Fix();

		price.setSaleTemplate(saleTemplate);
		price.setTechnology(saleTemplate.getTechnologies().iterator().next());

		RoyaltyValue value = new RoyaltyValue();
		value.setPrice(price);
		value.setValue(RandomTestData.createRandomBigDecimal());

		Set<RoyaltyValue> values = new HashSet<RoyaltyValue>();
		values.add(value);

		price.setRoyaltyValues(values);

		Assert.assertNull(price.getPrimaryKey());
		Assert.assertNotNull(price.getRoyaltyValues());
		Assert.assertNotNull(price.getRoyaltyValues().iterator().next().getValue());
		Assert.assertNull(price.getRoyaltyValues().iterator().next().getPrimaryKey());
		Assert.assertNull(price.getRoyaltyValues().iterator().next().getExpirationDate());
		Assert.assertNotNull(price.getTechnology());
		Assert.assertNotNull(price.getSaleTemplate());
		Assert.assertNotNull(price.getTechnology());
	}

	@Test (expected = BusinessException.class)
	public void add_a_royaltyValue_with_plantability_in_a_fixValue_price_should_throw_exception() throws BusinessException {
		Price price = new Fix();
		price.addRoyaltyValue(royaltyValueTenWithExpirationDateInJuneAndPlantability);
	}

	@Test (expected = BusinessException.class)
	public void add_a_royaltyValue_with_expiration_date_in_a_fixValue_price_should_throw_exception() throws BusinessException {
		Price price = new Fix();
		price.addRoyaltyValue(royaltyValueTenWithExpirationDateInJune);
	}

	@Test (expected = BusinessException.class)
	public void add_two_royaltyValues_in_a_fixValue_price_should_throw_exception() throws BusinessException {
		Price price = new Fix();
		price.addRoyaltyValue(royaltyValueOne);
		price.addRoyaltyValue(royaltyValueTen);
	}

	@Test
	public void testInsertRoyaltyValueByExpirationDateWithExpirationDateAndValue() throws BusinessException { 
		Price price = new ByExpirationDate(saleTemplate, technology);
		price.addRoyaltyValue(royaltyValueTenWithExpirationDateInJune);		
		Assert.assertEquals("Price should have 1 royalty value", 1, price.getRoyaltyValues().size());		
		Assert.assertTrue(price.getRoyaltyValues().contains(royaltyValueTenWithExpirationDateInJune));
	}

	@Test(expected=PriceExpirationDateMandatoryException.class)
	public void testInsertRoyaltyValueByExpirationDateWithoutExpirationDate() throws BusinessException { 
		Price price = new ByExpirationDate(saleTemplate, technology);
		price.addRoyaltyValue(royaltyValueTen);				
	}

	@Test(expected=PriceValueMandatoryException.class)
	public void add_a_royaltyValue_without_value_in_a_price_byExpirationDate_throw_exception() throws BusinessException { 
		Price price = new ByExpirationDate(saleTemplate, technology);
		RoyaltyValue royalty = new RoyaltyValue();
		royalty.setExpirationDate(new Date());
		price.addRoyaltyValue(royalty);				
	}


	@Test(expected=PriceMustNotHavePlantabilityException.class)
	public void add_a_royaltyValue_with_plantability_in_a_price_byExpirationDate_throw_exception() throws BusinessException { 
		Price price = new ByExpirationDate(saleTemplate, technology);
		price.addRoyaltyValue(royaltyValueTenWithExpirationDateInJuneAndPlantability);				
	}

	@Test(expected=PriceDuplicatedExpirationDateException.class)
	public void add_the_same_royaltyValue_twice_throw_exception() throws BusinessException { 
		Price price = new ByExpirationDate(saleTemplate, technology);
		price.addRoyaltyValue(royaltyValueTenWithExpirationDateInJune);	
		price.addRoyaltyValue(royaltyValueTenWithExpirationDateInJune);
	}
	
	@Test
	public void when_i_have_a_price_noValueByPlantability_should_have_plantability_and_no_royalty_value_and_no_expiration_date() throws BusinessException {
		Price noValueByPlantability = new NoValueByPlantability(saleTemplate, technology);
		RoyaltyValue royaltyValueWithPlantability = new RoyaltyValue();
		royaltyValueWithPlantability.setPlantability(plantability);
		
		noValueByPlantability.addRoyaltyValue(royaltyValueWithPlantability);
		
		Assert.assertEquals("Should be a price of type no value by plantability", PriceTypeEnum.NO_VALUE_BY_PLANTABILITY, noValueByPlantability.getType());
		assertRoyalty(noValueByPlantability);
	}

	private void assertRoyalty(Price noValueByPlantability) {
		RoyaltyValue royaltyValue = noValueByPlantability.getRoyaltyValues().iterator().next();
		Assert.assertEquals("Should have the given plantability", plantability, royaltyValue.getPlantability());
		Assert.assertNull("Should have no value of royalty", royaltyValue.getValue());
		Assert.assertNull("Should have no expiration date", royaltyValue.getExpirationDate());
	}
	
	@Test(expected=PricePlantabilityMandatoryException.class)
	public void when_i_have_a_price_noValueByPlantability_with_no_plantability_should_throw_exception() throws BusinessException {
		Price noValueByPlantability = new NoValueByPlantability(saleTemplate, technology);
		RoyaltyValue royaltyValueWithoutPlantability = new RoyaltyValue();
		
		noValueByPlantability.addRoyaltyValue(royaltyValueWithoutPlantability);
	}
	
	@Test(expected=PriceNotHaveValueException.class)
	public void when_i_have_a_price_noValueByPlantability_with_royalty_value_should_throw_exception() throws BusinessException {
		Price noValueByPlantability = new NoValueByPlantability(saleTemplate, technology);
		RoyaltyValue royaltyValuePlantabilityOnly = new RoyaltyValue(BigDecimal.ONE);
		royaltyValuePlantabilityOnly.setPlantability(plantability);
		
		noValueByPlantability.addRoyaltyValue(royaltyValuePlantabilityOnly);
	}

	@Test(expected=PriceMustNotHaveExpirationDateException.class)
	public void when_i_have_a_price_noValueByPlantability_with_expiration_date_should_throw_exception() throws BusinessException {
		Price noValueByPlantability = new NoValueByPlantability(saleTemplate, technology);
		RoyaltyValue royaltyValuePlantabilityOnly = new RoyaltyValue(null, new Date());
		royaltyValuePlantabilityOnly.setPlantability(plantability);
		
		noValueByPlantability.addRoyaltyValue(royaltyValuePlantabilityOnly);
	}
	
	private Date createDate(int year,int month, int date) {
		Calendar cal = Calendar.getInstance();
		cal.clear();
		cal.set(Calendar.YEAR, year);
		cal.set(Calendar.MONTH, month);
		cal.set(Calendar.DATE, date);

		return cal.getTime();
	}

	private RoyaltyValue createRoyaltyValueWithPlantability(RoyaltyValue royaltyValue) {
		RoyaltyValue r = new RoyaltyValue(royaltyValue.getValue(), royaltyValue.getExpirationDate());
		r.setPlantability(plantability);
		return r;
	}
	
	@Test(expected=PriceTypeCanNotBeNoValueException.class)
	public void when_I_save_a_sale_template_with_billing_method_ERP_price_type_can_not_be_no_value() throws BusinessException {
		saleTemplate.setBillingMethod(SaleTemplateBillingMethodEnum.ERP);
		PriceTestData.createPrice(PriceTypeEnum.NO_VALUE, saleTemplate, technology);
	}

}
