package com.monsanto.brazilvaluecapture.seedsale.sale.service.parser.saleOrder;

import com.monsanto.brazilvaluecapture.core.base.model.bean.Company;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Customer;
import com.monsanto.brazilvaluecapture.core.customer.service.CustomerNotFoundException;
import com.monsanto.brazilvaluecapture.core.foundation.service.EntityNotFoundException;
import com.monsanto.brazilvaluecapture.core.foundation.util.csv.CSVReadableInvalidException;
import com.monsanto.brazilvaluecapture.core.foundation.util.parser.FileParser;
import com.monsanto.brazilvaluecapture.core.foundation.util.parser.ParsedLineResult;
import com.monsanto.brazilvaluecapture.core.grower.model.bean.Grower;
import com.monsanto.brazilvaluecapture.core.user.model.bean.UserDecorator;
import com.monsanto.brazilvaluecapture.core.user.service.DocumentMismatchException;
import com.monsanto.brazilvaluecapture.pod.rol.model.bean.GermoSupplier;
import com.monsanto.brazilvaluecapture.seedsale.product.model.bean.Product;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.Sale;
import com.monsanto.brazilvaluecapture.seedsale.sale.service.SaleOrderImportService;
import com.monsanto.brazilvaluecapture.seedsale.template.model.bean.DueDateValue;
import com.monsanto.brazilvaluecapture.seedsale.template.model.bean.Price;
import com.monsanto.brazilvaluecapture.seedsale.template.model.bean.SaleTemplate;
import junit.framework.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.security.Authentication;
import org.springframework.security.context.SecurityContextHolder;

import java.io.InputStream;
import java.util.*;

import static com.monsanto.brazilvaluecapture.core.regionalization.VCCountry.ARGENTINA;
import static org.fest.reflect.core.Reflection.field;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
import static org.junit.Assert.*;

/**
 * Created by IntelliJ IDEA.
 * User: HGFIOR
 * Date: 10/07/13
 * Time: 14:08
 * To change this template use File | Settings | File Templates.
 */
public class PreCampaignFileParser_UT {

    private CsvPreCampaign csvPreCampaign;

    private Locale locale = new Locale("es", "AR");

    private InputStream inputStream;

    @Mock
    private UserDecorator userDecorator;

    /**
     * Bundle
     */
    private ResourceBundle resourceBundle = ResourceBundle.getBundle("bundle/bundle");

    private static final String FILE_NAME = "fileName";

    @Before
    public void setUp() throws Exception {
        CsvPreCampaign csvPreCampaign = new CsvPreCampaign();
        field("saleOrderDate").ofType(String.class).in(csvPreCampaign).set("15.04.2013");
        field("SAPSaleOrderId").ofType(String.class).in(csvPreCampaign).set("107114");
        field("retailerSAPId").ofType(String.class).in(csvPreCampaign).set("1008080");
        field("growerSAPId").ofType(String.class).in(csvPreCampaign).set("0001099746");
        field("tonsAmount").ofType(String.class).in(csvPreCampaign).set("100.000");
        field("totalARS").ofType(String.class).in(csvPreCampaign).set("184852.50");
        field("totalUSD").ofType(String.class).in(csvPreCampaign).set("36750.00");
        field("germoSupplier").ofType(String.class).in(csvPreCampaign).set("1");
        field("paymentDate").ofType(String.class).in(csvPreCampaign).set("15.04.2013");
        field("invoiceSAPNumber").ofType(String.class).in(csvPreCampaign).set("666");
        field("receiptSAPNumber").ofType(String.class).in(csvPreCampaign).set("777");
        field("totalBag40").ofType(String.class).in(csvPreCampaign).set("10");
        field("totalBag25").ofType(String.class).in(csvPreCampaign).set("5");
        this.csvPreCampaign = csvPreCampaign;



    }

    private SaleOrderImportService initializeCSV() throws EntityNotFoundException, CustomerNotFoundException, DocumentMismatchException {
        SaleOrderImportService saleOrderImportService = Mockito.mock(SaleOrderImportService.class);
        Customer customer = Mockito.mock(Customer.class);
        Grower grower = Mockito.mock(Grower.class);
        GermoSupplier germoSupplier = Mockito.mock(GermoSupplier.class);
        SaleTemplate saleTemplate = Mockito.mock(SaleTemplate.class);

        Product product = Mockito.mock(Product.class);
        HashSet<Product> products = new HashSet<Product>();
        products.add(product);
        Company company = Mockito.mock(Company.class);
        Price price = Mockito.mock(Price.class);
        HashSet<Price> prices = new HashSet<Price>();
        prices.add(price);
        DueDateValue dueDate = new DueDateValue();
        Set<DueDateValue> dueDates = new HashSet<DueDateValue>();
        dueDates.add(dueDate);

        Mockito.when(saleOrderImportService.getCountry()).thenReturn(ARGENTINA);
        Mockito.when(saleOrderImportService.getCustomerBySapCode(any(String.class))).thenReturn(customer);
        Mockito.when(saleOrderImportService.getGrowerByCustomerSapId(any(String.class))).thenReturn(grower);
        Mockito.when(saleOrderImportService.getGermoSupplier(any(String.class))).thenReturn(germoSupplier);
        Mockito.when(saleOrderImportService.getSaleTemplate(any(Sale.SaleTypeEnum.class))).thenReturn(saleTemplate);

        Mockito.when(saleTemplate.getProducts()).thenReturn(products);
        Mockito.when(saleTemplate.getProducts()).thenReturn(products);
        Mockito.when(saleTemplate.getPrices()).thenReturn(prices);
        Mockito.when(price.getDueDates()).thenReturn(dueDates);
        return saleOrderImportService;
    }

    @Test
    public void testProcess() throws Exception {
        SaleOrderImportService saleOrderImportService = initializeCSV();
        // Load file
        inputStream = getClass().getClassLoader().getResourceAsStream("csv/rol_import_template_valid.csv");
        FileParser fp = new PreCampaignFileParser(resourceBundle,saleOrderImportService,FILE_NAME,inputStream,locale,"usuario");
        List<CsvPreCampaign> list = new ArrayList<CsvPreCampaign>();
        list.add(csvPreCampaign);
        Authentication authentication = mock(Authentication.class);
        when(authentication.getPrincipal()).thenReturn(userDecorator);
        SecurityContextHolder.getContext().setAuthentication(authentication);
        field("preCampaigns").ofType(List.class).in(fp).set(list);

        fp.process();
        assertTrue(fp.getErrorLines()==0);
        assertTrue(fp.getSuccessLines()==1);

    }

    @Test
    public void getFormattedWarnings() throws Exception {

        SaleOrderImportService saleOrderImportService = initializeCSV();
        // Load file
        inputStream = getClass().getClassLoader().getResourceAsStream("csv/rol_import_template_valid.csv");
        FileParser fp = new PreCampaignFileParser(resourceBundle,saleOrderImportService,FILE_NAME,inputStream,locale,"usuario");
        List<CsvPreCampaign> list = new ArrayList<CsvPreCampaign>();
        list.add(csvPreCampaign);
        Authentication authentication = mock(Authentication.class);
        when(authentication.getPrincipal()).thenReturn(userDecorator);
        SecurityContextHolder.getContext().setAuthentication(authentication);
        field("preCampaigns").ofType(List.class).in(fp).set(list);
        List<ParsedLineResult> warnings = new ArrayList<ParsedLineResult>();
        ParsedLineResult plr = mock(ParsedLineResult.class);
        warnings.add(plr);
        field("warnings").ofType(List.class).in(fp).set(warnings);
        String formattedStr = fp.getFormattedWarnings(resourceBundle);
        assertNotNull(formattedStr);
        assertTrue(!formattedStr.equalsIgnoreCase(""));

    }

    @Test
    public void readFile() throws Exception {
        SaleOrderImportService saleOrderImportService = initializeCSV();
        // Load file
        inputStream = getClass().getClassLoader().getResourceAsStream("csv/rol_import_template_valid.csv");
        FileParser fp = new PreCampaignFileParser(resourceBundle,saleOrderImportService,FILE_NAME,inputStream,locale,"usuario");
        List<CsvPreCampaign> list = new ArrayList<CsvPreCampaign>();
        list.add(csvPreCampaign);
        Authentication authentication = mock(Authentication.class);
        when(authentication.getPrincipal()).thenReturn(userDecorator);
        SecurityContextHolder.getContext().setAuthentication(authentication);
        field("preCampaigns").ofType(List.class).in(fp).set(list);
        try{
            fp.readFile();
        }catch (Exception e){
            Assert.fail();
        }

    }
}
