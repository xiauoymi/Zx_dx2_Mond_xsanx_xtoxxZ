package com.monsanto.brazilvaluecapture.seedsale.sale.service.parser.registration;

import com.monsanto.brazilvaluecapture.core.user.model.bean.UserDecorator;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.CsvMultiplierToGrowerSale;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.Sale;
import com.monsanto.brazilvaluecapture.seedsale.sale.service.SaleConstraintViolationException;
import com.monsanto.brazilvaluecapture.seedsale.sale.validation.MultiplierToGrowerSaleValidator;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;

public class MultiplierToGrowerSaleParserBuilder_UT {

    @Test
    public void test_createSaleFrom() {
        MultiplierToGrowerSaleParserBuilder test = new MultiplierToGrowerSaleParserBuilder();
        List<CsvMultiplierToGrowerSale> list = new ArrayList<CsvMultiplierToGrowerSale>();
        list.add(mock(CsvMultiplierToGrowerSale.class));
        Sale result = test.createSaleFrom(mock(CsvMultiplierToGrowerSale.class), list);

        assertNotNull(result);

    }

    @Test
    public void validateInvokesValidateCollectingAllViolations_FromMultiplierToGrowerSaleValidator() throws SaleConstraintViolationException {
        MultiplierToGrowerSaleValidator multiplierToGrowerSaleValidator = mock(MultiplierToGrowerSaleValidator.class);
        UserDecorator user = mock(UserDecorator.class);
        MultiplierToGrowerSaleParserBuilder test = new MultiplierToGrowerSaleParserBuilder(multiplierToGrowerSaleValidator, user, Sale.SaleTypeEnum.MULTIPLIER_TO_GROWER_SEED_SALE);
        Sale sale = new Sale();

        test.validate(sale, user);

        verify(multiplierToGrowerSaleValidator).validate(sale);
    }

}
