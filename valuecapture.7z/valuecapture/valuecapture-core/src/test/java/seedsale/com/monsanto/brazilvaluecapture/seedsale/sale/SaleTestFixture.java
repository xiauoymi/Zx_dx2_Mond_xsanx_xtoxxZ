package com.monsanto.brazilvaluecapture.seedsale.sale;

import com.monsanto.brazilvaluecapture.core.base.SystemTestFixture;
import com.monsanto.brazilvaluecapture.core.base.model.bean.*;
import com.monsanto.brazilvaluecapture.core.commercialhierarchy.model.bean.CustomerDistrict;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.*;
import com.monsanto.brazilvaluecapture.core.foundation.RandomTestData;
import com.monsanto.brazilvaluecapture.core.foundation.model.bean.QuotaUsageEnum;
import com.monsanto.brazilvaluecapture.core.foundation.model.bean.StatusEnum;
import com.monsanto.brazilvaluecapture.core.foundation.service.BusinessException;
import com.monsanto.brazilvaluecapture.core.foundation.test.AbstractIntegrationTestsParent;
import com.monsanto.brazilvaluecapture.core.foundation.test.AbstractTestFixture;
import com.monsanto.brazilvaluecapture.core.foundation.util.CalendarUtil;
import com.monsanto.brazilvaluecapture.core.grower.PlayerTestData;
import com.monsanto.brazilvaluecapture.core.grower.model.bean.Agreement;
import com.monsanto.brazilvaluecapture.core.grower.model.bean.AgreementTemplate;
import com.monsanto.brazilvaluecapture.core.grower.model.bean.AgreementTemplateType;
import com.monsanto.brazilvaluecapture.core.grower.model.bean.Grower;
import com.monsanto.brazilvaluecapture.multiplier.cultivar.CultivarTestData;
import com.monsanto.brazilvaluecapture.multiplier.cultivar.model.bean.Cultivar;
import com.monsanto.brazilvaluecapture.multiplier.obtainer.ObtainerTestData;
import com.monsanto.brazilvaluecapture.multiplier.obtainer.model.bean.Obtainer;
import com.monsanto.brazilvaluecapture.seedsale.harvest.HarvestTestData;
import com.monsanto.brazilvaluecapture.seedsale.harvest.model.bean.Harvest;
import com.monsanto.brazilvaluecapture.seedsale.harvest.model.bean.Plantability;
import com.monsanto.brazilvaluecapture.seedsale.harvest.model.bean.PlantabilitySystemEnum;
import com.monsanto.brazilvaluecapture.seedsale.product.PlantabilityTestData;
import com.monsanto.brazilvaluecapture.seedsale.product.ProductTestData;
import com.monsanto.brazilvaluecapture.seedsale.product.ProductivityTestData;
import com.monsanto.brazilvaluecapture.seedsale.product.model.bean.Product;
import com.monsanto.brazilvaluecapture.seedsale.product.model.bean.Productivity;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.Cancellation;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.Sale.SaleTypeEnum;
import com.monsanto.brazilvaluecapture.seedsale.sale.service.PlantabilitiesSelector;
import com.monsanto.brazilvaluecapture.seedsale.sale.service.SaleItemFactory;
import com.monsanto.brazilvaluecapture.seedsale.template.PriceTestData;
import com.monsanto.brazilvaluecapture.seedsale.template.SaleTemplateTestData;
import com.monsanto.brazilvaluecapture.seedsale.template.model.bean.*;
import com.monsanto.brazilvaluecapture.seedsale.template.model.bean.Price.PriceTypeEnum;
import com.monsanto.brazilvaluecapture.seedsale.template.model.bean.Price.ReleaseCreditTypeEnum;
import com.monsanto.brazilvaluecapture.seedsale.template.model.bean.RetributionFee.RetributionSourceType;
import com.monsanto.brazilvaluecapture.seedsale.template.service.DueDateCanNotBeEqualsAnotherException;
import com.monsanto.brazilvaluecapture.seedsale.template.service.DueDateCanNotBeMoreThanTwoException;

import java.math.BigDecimal;
import java.util.*;

public class SaleTestFixture extends AbstractTestFixture {
	public static Date JANUARY = createDate(-6, 20);
	public static Date FEBRUARY = createDate(-5, 20);
	public static Date APRIL = createDate(-4, 20);
	public static Date MAY = createDate(-3, 20);
	public static Date AUGUST = createDate(-2, 20);
	public static Date OCTOBER = createDate(-1, 20);
	public static Date NOVEMBER = createDate(1, 20);
	public static Date DECEMBER = createDate(2, 20);
	public static Date DATE_NOW =  createNow();
	public static Date DATE_TOMORROW = createTomorrow();
	public static Date DATE_YESTERDAY = createYesterday();

	public static BigDecimal EIGHT_DOLLARS = new BigDecimal("8");
	public static BigDecimal FIVE_DOLLARS = new BigDecimal("5");
	public static BigDecimal TWO_POINT_FIVE_DOLLARS = new BigDecimal("2.5");
	public static BigDecimal ONE_POINT_THREE_DOLLARS = new BigDecimal("1.3");
	public static BigDecimal SEVENTY_CENTS = new BigDecimal("0.7");
	public static BigDecimal FIFTY_CENTS = new BigDecimal("0.5");

	public Plantability plantabilitySystemOfHarvest2011Soy;
	public Plantability anotherPlantability;
	public Plantability plantabilitySystemSoyMonsanto2012;
	public Plantability plantability45To54SoyMonsanto2012;
	public Plantability plantability76To84SoyMonsanto2009;

	public HeadOffice headOfficeCargil;
	public HeadOffice headOfficeAffiliate;
	public HeadOffice headOfficeAffiliate2;
	public HeadOffice headOfficeAffiliate3;

	public Harvest harvest2011SoyMonsanto;
	public Harvest harvest2009SoyMonsanto;
	public Harvest harvestSoyMonsanto2012;
	public Harvest harvestSoyMonsantoEua2012;
	
	public Grower chicoBento;
    public Grower chicoBentoSimple;
	public Grower joaoDaSilva;
	public Document chicoBentoDocument;
    public Document chicoBentoSimpleDocument;
	public static final String CHICO_CNPJ = "77208382069704"; //no mask
	public static final String JOAO_CNPJ = "99999999999999387"; //no mask

	public Customer customer;
    public Customer customerWithDistrict;

	public CustomerDistrict customerDistrict;
	public HeadOffice officeCustomer;
	public Customer matrixCargil;
	public CustomerDistrict customerDistrictMatrixCargil;
	public Customer affiliate;
	public Customer affiliate2;

	public Customer agroSoja;
	public HeadOffice agroSojaMatrix;
	public Customer agroSojaAffiliate;
	public Customer agroSojaAndCargilAffiliate;
	public HeadOffice agroSojaAffiliateHeadOffice;
	public HeadOffice agroSojaAndCargilAffiliateHeadOffice;
	public Contract agroSojaContract;
	
	public Contract contract;
	public Contract contractCargil;
	public Contract contractMons4nto;
	

	public Product productIntactaSoy;
	public Product productCargilIntactaSoy;
	public Product productIntactaSoy2;
	public Product productBtSoy;
	public Product productRRSoy;
	public Product productIntactaCoffee;
	public Product productIntactaWithQuota;
	public Product productIntactaWithQuotaForReport;

	public Productivity productivityOfIntactaSoy;
	public Productivity productivityOfIntactaCoffee;
	public Productivity productivityOfBtSoy;
	public Productivity productivityOfIntactaSoy2012;
	public Productivity productivityOfBtSoy2012;
	public Productivity productivitySoyMonsanto2009;

	public Productivity productivityOfIntactaSoy2012NoSystem;
	public Productivity productivityOfBtSoy2012NoSystem;

	public SaleTemplate templateReservedSeedNoValue;
	public SaleTemplate templateIntactaNoValueRRNoValue;
	public SaleTemplate templateIntactaFixRRRangeBtNoValue;
	public SaleTemplate templateDirectSaleIntactaFixRRRangeBtNoValue;
	public SaleTemplate templateIntactaByPlantabilityRRByExpirationBtFree;
	public SaleTemplate templateIntactaByPlantabilityRRByExpirationBtFreeErp;
	public SaleTemplate templateIntactaNoValueByPlantability;
	public SaleTemplate templateFreeWithDueDateRange;
	public SaleTemplate templateByPlantabilityWithFixDueDate;
	public SaleTemplate templateFixWithDueDateRange;
	public SaleTemplate templateRangeWithDueDateRange;
	public SaleTemplate templateByExpirationDateWithDueDateRange;
	public SaleTemplate templateFreeWithDueDateRangeAndGenerationCreditDisabled;
	public SaleTemplate templateForLicenseSeedIntactaByPlantabilityRRByExpirationBtFree;

    public SaleTemplate templateSeamlessPricingNew;

    public DueDatePrice dueDatePrice1;

    public DueDatePriceItem dueDatePriceItem1;

	public Cancellation saleCancellation;

	public SaleItemFactory saleItemFactoryForMatoGrossoDoSul;
	
	public static final String THE_CARGIL_CNPJ = "77046101298780";
	public static final String THE_AGROESTE_CNPJ = "99.999.999/9999/99387";
	public static final String THE_CARGIL_CNPJ_WITHOUT_MASK = "77641531811757";
	public static final String MONS4NTO_CNPJ_WITHOUT_MASK = "77727239523705";
	public PlantabilitiesSelector plantabilitiesSelector;
    public HeadOffice officeMons4nto;
    public Harvest harvestSoyMons4nto2012;
    public Plantability plantability45To54SoyMons4nto2012;
    public Product productIntactaSoyMons4nto;
    public Product productRRSoyMons4nto;
    public Product productBTSoyMons4nto;
    public Productivity productivityOfIntactaSoy2012NoSystemMons4nto;
    public SaleTemplate templateIntactaMons4nto;
    public SaleTemplate templateIntactaMons4ntoManualCreditRelease;
    public SaleTemplate templateIntactaMons4ntoOnPayment;
    public Plantability plantabilitySystemMons4nto2012;
    public Productivity productivityOfIntactaSoy2012SystemMons4nto;
    public PlantabilitiesSelector plantabilitiesSelectorMons4nto;
    public SaleItemFactory saleItemFactoryForMatoGrossoDoSulMons4nto;
    public Customer matrixMons4nto;
    public SaleTemplate templateLicenseSeedMons4nto;
	public Productivity productivityOfSystemSoyMonsanto2012AtMatoGrossoDoSul;
	public Grower joseDaSilva;
    public String batchName = "testBatchName";
	

	public SaleTestFixture(AbstractIntegrationTestsParent context, SystemTestFixture systemTestFixture) {
		super(context);
		setupFixture(systemTestFixture);
	}

	public SaleTestFixture(SystemTestFixture systemTestFixture) {
		super();
		setupFixture(systemTestFixture);
	}

	private void setupFixture(SystemTestFixture systemTestFixture) {
        createSimpleGrower(systemTestFixture);
        createGrower(systemTestFixture);
		createGrowerJoao(systemTestFixture);
		createGrowerJose(systemTestFixture);

		Address a = PlayerTestData.createAddress(systemTestFixture.matoGrossoDoSul, systemTestFixture.vilaNova, systemTestFixture.brazil);

		customer = createNewCustomer(RandomTestData.createRandomString(5), PlayerTestData.createDocument(systemTestFixture.documentCnpj, "77784236909725"), a, RandomTestData.createRandomNumberAsString(10));
		persist(customer);

		contract = new Contract(RandomTestData.createRandomLong().toString(), customer, ParticipantTypeEnum.DISTRIBUTOR, systemTestFixture.soy, systemTestFixture.monsantoBr);
		contract.setEndDate(CalendarUtil.getDateNow());
		persist(contract);
		

		officeCustomer = new HeadOffice(customer, customer, ParticipantTypeEnum.DISTRIBUTOR, systemTestFixture.soy, systemTestFixture.monsantoBr);
		persist(officeCustomer);
		
		agroSoja = createNewCustomer("agroSoja"+RandomTestData.createRandomString(5), PlayerTestData.createDocument(systemTestFixture.documentCnpj, "77648547246717"), a, RandomTestData.createRandomNumberAsString(10));
		persist(agroSoja);
		
		agroSojaAffiliate = createNewCustomer("agroSojaAff"+RandomTestData.createRandomString(5), PlayerTestData.createDocument(systemTestFixture.documentCnpj, "34653374"), a, RandomTestData.createRandomNumberAsString(10));
		persist(agroSojaAffiliate);
		
		agroSojaAndCargilAffiliate = createNewCustomer("agroSojaCargil"+RandomTestData.createRandomString(5), PlayerTestData.createDocument(systemTestFixture.documentCnpj, "6533723468"), a, RandomTestData.createRandomNumberAsString(10));
		persist(agroSojaAndCargilAffiliate);
		
		agroSojaMatrix = new HeadOffice(agroSoja, agroSoja, ParticipantTypeEnum.DISTRIBUTOR, systemTestFixture.soy, systemTestFixture.monsantoBr);
		persist(agroSojaMatrix);
		
		agroSojaAffiliateHeadOffice = new HeadOffice(agroSojaAffiliate, agroSoja, ParticipantTypeEnum.DISTRIBUTOR, systemTestFixture.soy, systemTestFixture.monsantoBr);
		agroSojaAndCargilAffiliateHeadOffice = new HeadOffice(agroSojaAndCargilAffiliate, agroSoja, ParticipantTypeEnum.DISTRIBUTOR, systemTestFixture.soy, systemTestFixture.monsantoBr);
		persist(agroSojaAffiliateHeadOffice);
		persist(agroSojaAndCargilAffiliateHeadOffice);
		
		matrixCargil = createNewCustomer(RandomTestData.createRandomString(5), PlayerTestData.createDocument(systemTestFixture.documentCnpj, THE_CARGIL_CNPJ_WITHOUT_MASK), a, "0085007465");
		affiliate = createNewCustomer("affiliateA"+RandomTestData.createRandomString(5), PlayerTestData.createDocument(systemTestFixture.documentCnpj, "77825341351772"), a, RandomTestData.createRandomNumberAsString(10));
		affiliate2 = createNewCustomer("affiliateB"+RandomTestData.createRandomString(5), PlayerTestData.createDocument(systemTestFixture.documentCnpj, "333333"), a, RandomTestData.createRandomNumberAsString(10));
		matrixMons4nto = createNewCustomer("matrixMons"+RandomTestData.createRandomString(5), PlayerTestData.createDocument(systemTestFixture.documentCnpj, MONS4NTO_CNPJ_WITHOUT_MASK), a, "77349148138782");
		agroSojaAndCargilAffiliateHeadOffice = new HeadOffice(agroSojaAndCargilAffiliate, matrixCargil, ParticipantTypeEnum.DISTRIBUTOR, systemTestFixture.soy, systemTestFixture.monsantoBr);

		persist(matrixCargil);
		persist(affiliate);
		persist(affiliate2);
		persist(matrixMons4nto);
		persist(agroSojaAndCargilAffiliateHeadOffice);
		
		customerDistrictMatrixCargil = new CustomerDistrict(systemTestFixture.commercialHierarchyMonsantoSoy);
		customerDistrictMatrixCargil.setCustomerDistrictId(1000L);
		customerDistrictMatrixCargil.setItsDistrict(systemTestFixture.districtCampinas);
		customerDistrictMatrixCargil.setCustomer(matrixCargil);
		customerDistrictMatrixCargil.setCommercialHierarchy(systemTestFixture.commercialHierarchyMonsantoSoy);
		persist(customerDistrictMatrixCargil);

        customerWithDistrict = createNewCustomer(RandomTestData.createRandomString(15), PlayerTestData.createDocument(systemTestFixture.documentCnpj, "77784236904444"), a, RandomTestData.createRandomNumberAsString(10));
        customerWithDistrict.addDistrict(customerDistrictMatrixCargil);
        persist(customerWithDistrict);
		
		customerDistrict = new CustomerDistrict(systemTestFixture.commercialHierarchyMonsantoSoy);
		customerDistrict.setCustomerDistrictId(2000L);
		customerDistrict.setItsDistrict(systemTestFixture.districtVilaNova);
		customerDistrict.setCustomer(customer);
		customerDistrict.setCommercialHierarchy(systemTestFixture.commercialHierarchyMonsantoSoy);
		persist(customerDistrict);
		
		agroSojaContract = new Contract(RandomTestData.createRandomLong().toString(), agroSoja, ParticipantTypeEnum.DISTRIBUTOR, systemTestFixture.soy, systemTestFixture.monsantoBr);
		agroSojaContract.setEndDate(CalendarUtil.getDateNow());
		persist(agroSojaContract);
		
		contractMons4nto = new Contract(RandomTestData.createRandomLong().toString(), matrixMons4nto, ParticipantTypeEnum.DISTRIBUTOR, systemTestFixture.soyMons4nto, systemTestFixture.mons4ntoBr);
		contractMons4nto.setEndDate(CalendarUtil.getDateNow());
		persist(contractMons4nto);
		
		officeMons4nto = new HeadOffice(matrixMons4nto, matrixMons4nto, ParticipantTypeEnum.DISTRIBUTOR, systemTestFixture.soyMons4nto, systemTestFixture.mons4ntoBr);
		persist(officeMons4nto); 

		contractCargil = new Contract("111222", matrixCargil, ParticipantTypeEnum.DISTRIBUTOR, systemTestFixture.soy, systemTestFixture.monsantoBr);
		contractCargil.setEndDate(CalendarUtil.getDateNow());
		persist(contractCargil);

		headOfficeCargil = new HeadOffice(matrixCargil, matrixCargil, ParticipantTypeEnum.DISTRIBUTOR, systemTestFixture.soy, systemTestFixture.monsantoBr);
		headOfficeAffiliate = new HeadOffice(affiliate, matrixCargil, ParticipantTypeEnum.DISTRIBUTOR, systemTestFixture.soy, systemTestFixture.monsantoBr);
		headOfficeAffiliate2 = new HeadOffice(affiliate2, matrixCargil, ParticipantTypeEnum.DISTRIBUTOR, systemTestFixture.soy, systemTestFixture.monsantoBr);
		
		headOfficeAffiliate3 = new HeadOffice(affiliate, affiliate, ParticipantTypeEnum.DISTRIBUTOR, systemTestFixture.soy, systemTestFixture.monsantoBr);

		persist(headOfficeCargil);
		persist(headOfficeAffiliate);
		persist(headOfficeAffiliate2);
		persist(headOfficeAffiliate3);
		
		HeadOffice headOfficeAffiliate = new HeadOffice(affiliate, customer, ParticipantTypeEnum.DISTRIBUTOR, systemTestFixture.soy, systemTestFixture.monsantoBr);
		persist(headOfficeAffiliate);

		harvest2011SoyMonsanto = HarvestTestData.createHarvest(systemTestFixture.soy, systemTestFixture.operationalYearOf2011, systemTestFixture.monsantoBr);
		persist(harvest2011SoyMonsanto);

		harvest2009SoyMonsanto = HarvestTestData.createHarvest(systemTestFixture.soy, systemTestFixture.operationalYearOf2009, systemTestFixture.monsantoBr);
		harvest2009SoyMonsanto.setDescription(harvest2011SoyMonsanto.getDescription());
		persist(harvest2009SoyMonsanto);

		harvestSoyMonsanto2012 = HarvestTestData.createHarvest(systemTestFixture.soy, systemTestFixture.operationalYearOf2012, systemTestFixture.monsantoBr);
		persist(harvestSoyMonsanto2012);
		
		harvestSoyMons4nto2012 = HarvestTestData.createHarvest(systemTestFixture.soyMons4nto, systemTestFixture.operationalYearOf2012, systemTestFixture.mons4ntoBr);
		persist(harvestSoyMons4nto2012);

		harvestSoyMonsantoEua2012 = HarvestTestData.createHarvest(systemTestFixture.soyEua, systemTestFixture.operationalYearOf2012, systemTestFixture.monsantoEua);
		persist(harvestSoyMonsantoEua2012);
		
		
		plantabilitySystemOfHarvest2011Soy = PlantabilityTestData.createPlantability(harvest2011SoyMonsanto);
		plantabilitySystemOfHarvest2011Soy.setIsPlantabilitySystem(PlantabilitySystemEnum.YES);
		persist(plantabilitySystemOfHarvest2011Soy);

		plantabilitySystemSoyMonsanto2012 = PlantabilityTestData.createPlantability(harvestSoyMonsanto2012);
		plantabilitySystemSoyMonsanto2012.setIsPlantabilitySystem(PlantabilitySystemEnum.YES);
		plantabilitySystemSoyMonsanto2012.setDescription("System Plantability of Harvest Soy Monsanto 2012");
		persist(plantabilitySystemSoyMonsanto2012);

		plantability45To54SoyMonsanto2012 = PlantabilityTestData.createPlantability(harvestSoyMonsanto2012);
		plantability45To54SoyMonsanto2012.setDescription("45 to 54 zone of Harvest Soy Monsanto 2012");
		persist(plantability45To54SoyMonsanto2012);
		
		plantabilitySystemMons4nto2012 = PlantabilityTestData.createPlantability(harvestSoyMons4nto2012);
		plantabilitySystemMons4nto2012.setIsPlantabilitySystem(PlantabilitySystemEnum.YES);
		plantabilitySystemMons4nto2012.setDescription("System plantability of harvest soy mons4nto 2012");
		persist(plantabilitySystemMons4nto2012);
		
		plantability45To54SoyMons4nto2012 = PlantabilityTestData.createPlantability(harvestSoyMons4nto2012);
		plantability45To54SoyMons4nto2012.setDescription("45 to 54 zone of Harvest Soy Mons4nto 2012");
		persist(plantability45To54SoyMons4nto2012);
		
		plantability76To84SoyMonsanto2009 = PlantabilityTestData.createPlantability(harvest2009SoyMonsanto);
		plantability76To84SoyMonsanto2009.setDescription("76 to 84 kg for harvest monsanto 2009");
		persist(plantability76To84SoyMonsanto2009);

		anotherPlantability = PlantabilityTestData.createPlantability(harvest2011SoyMonsanto);
		persist(anotherPlantability);

		productIntactaSoy = ProductTestData.createProduct(systemTestFixture.monsoy, systemTestFixture.soy, systemTestFixture.intacta, StatusEnum.ACTIVE, systemTestFixture.monsantoBr);
		productIntactaSoy.setDescription("SOYA");
		
		Obtainer obtainer = ObtainerTestData.createActiveObtainer(systemTestFixture.soy);
		Cultivar cultivar = CultivarTestData.createActiveCultivar(systemTestFixture.soy, obtainer);
		productIntactaSoy.setCultivar(cultivar);
		persist(cultivar);
		persist(productIntactaSoy);
		
		productCargilIntactaSoy = ProductTestData.createProduct(systemTestFixture.monsoy, systemTestFixture.soy, systemTestFixture.intacta, StatusEnum.ACTIVE, systemTestFixture.monsantoBr);
		productCargilIntactaSoy.setDescription("SOYA CARGIL");
		persist(productCargilIntactaSoy);
		
		productIntactaSoy2 = ProductTestData.createProduct(systemTestFixture.monsoyMons4nto, systemTestFixture.soy, systemTestFixture.intacta, StatusEnum.ACTIVE, systemTestFixture.monsantoBr);
		productIntactaSoy2.setDescription("SOYA 2");
		persist(productIntactaSoy2);
		
		productIntactaSoyMons4nto = ProductTestData.createProduct(systemTestFixture.monsoyMons4nto, systemTestFixture.soyMons4nto, systemTestFixture.intactaMons4nto, StatusEnum.ACTIVE, systemTestFixture.mons4ntoBr);
		productIntactaSoyMons4nto.setDescription("MONS4NTO-SOYA INTACTA");
		persist(productIntactaSoyMons4nto);
		
		productRRSoyMons4nto = ProductTestData.createProduct(systemTestFixture.monsoyMons4nto, systemTestFixture.soyMons4nto, systemTestFixture.rrMons4nto, StatusEnum.ACTIVE, systemTestFixture.mons4ntoBr);
		productRRSoyMons4nto.setDescription("MONS4NTO-SOYA RR");
		persist(productRRSoyMons4nto);
		
		productBTSoyMons4nto = ProductTestData.createProduct(systemTestFixture.monsoyMons4nto, systemTestFixture.soyMons4nto, systemTestFixture.btMons4nto, StatusEnum.ACTIVE, systemTestFixture.mons4ntoBr);
		productBTSoyMons4nto.setDescription("MONS4NTO-SOYA BT");
		persist(productBTSoyMons4nto);
		
		productRRSoy = ProductTestData.createProduct(systemTestFixture.monsoyMons4nto, systemTestFixture.soyMons4nto, systemTestFixture.intactaMons4nto, StatusEnum.ACTIVE, systemTestFixture.mons4ntoBr);

		productIntactaCoffee = ProductTestData.createProduct(systemTestFixture.monsoy, systemTestFixture.coffee, systemTestFixture.intacta, StatusEnum.ACTIVE, systemTestFixture.monsantoBr);
		persist(productIntactaCoffee);

		productBtSoy = ProductTestData.createProduct(systemTestFixture.monsoy, systemTestFixture.soy, systemTestFixture.bt, StatusEnum.ACTIVE, systemTestFixture.monsantoBr);
		productBtSoy.setDescription("OLD-SOY");
		persist(productBtSoy);
		
		productRRSoy = ProductTestData.createProduct(systemTestFixture.monsoy, systemTestFixture.soy, systemTestFixture.rr, StatusEnum.ACTIVE, systemTestFixture.monsantoBr);
		productRRSoy.setDescription("RR-SOY");
		persist(productRRSoy);
		
		productIntactaWithQuota = ProductTestData.createProduct(systemTestFixture.monsoyMons4nto, systemTestFixture.soyMons4nto, systemTestFixture.intactaMons4nto, StatusEnum.ACTIVE, systemTestFixture.mons4ntoBr);
		productIntactaWithQuota.setQuotaUsage(QuotaUsageEnum.USE_QUOTA);
		productIntactaWithQuota.setDescription("INTACTA-SOY with quota");
		persist(productIntactaWithQuota);
		
		productIntactaWithQuotaForReport = ProductTestData.createProduct(systemTestFixture.monsoy, systemTestFixture.soy, systemTestFixture.intacta, StatusEnum.ACTIVE, systemTestFixture.monsantoBr);
		productIntactaWithQuotaForReport.setQuotaUsage(QuotaUsageEnum.USE_QUOTA);
		productIntactaWithQuotaForReport.setDescription("INTACTA-SOY with quota 2");
		persist(productIntactaWithQuotaForReport);

		productivityOfIntactaSoy = ProductivityTestData.createProductivity(systemTestFixture.matoGrossoDoSul, plantabilitySystemOfHarvest2011Soy);
		ProductivityTestData.addProductivityValue(productivityOfIntactaSoy, productIntactaSoy);
		ProductivityTestData.addProductivityValue(productivityOfIntactaSoy, productBtSoy);
		ProductivityTestData.addProductivityValue(productivityOfIntactaSoy, productRRSoy);
		persist(productivityOfIntactaSoy);
		
		productivityOfSystemSoyMonsanto2012AtMatoGrossoDoSul = ProductivityTestData.createProductivity(systemTestFixture.matoGrossoDoSul, plantabilitySystemSoyMonsanto2012);
		ProductivityTestData.addProductivityValue(productivityOfSystemSoyMonsanto2012AtMatoGrossoDoSul, productIntactaCoffee);
		ProductivityTestData.addProductivityValue(productivityOfSystemSoyMonsanto2012AtMatoGrossoDoSul, productIntactaSoy);
		ProductivityTestData.addProductivityValue(productivityOfSystemSoyMonsanto2012AtMatoGrossoDoSul, productBtSoy);
		ProductivityTestData.addProductivityValue(productivityOfSystemSoyMonsanto2012AtMatoGrossoDoSul, productRRSoy);
		ProductivityTestData.addProductivityValue(productivityOfSystemSoyMonsanto2012AtMatoGrossoDoSul, productCargilIntactaSoy);
		persist(productivityOfSystemSoyMonsanto2012AtMatoGrossoDoSul);
		
		productivitySoyMonsanto2009 = ProductivityTestData.createProductivity(systemTestFixture.matoGrossoDoSul, plantability76To84SoyMonsanto2009);
		ProductivityTestData.addProductivityValue(productivitySoyMonsanto2009, productIntactaSoy);
		persist(productivitySoyMonsanto2009);

		productivityOfIntactaSoy2012NoSystem = ProductivityTestData.createProductivity(systemTestFixture.matoGrossoDoSul, plantability45To54SoyMonsanto2012); 
		ProductivityTestData.addProductivityValue(productivityOfIntactaSoy2012NoSystem, productIntactaSoy);
		ProductivityTestData.addProductivityValue(productivityOfIntactaSoy2012NoSystem, productRRSoy);
		ProductivityTestData.addProductivityValue(productivityOfIntactaSoy2012NoSystem, productIntactaWithQuotaForReport);
		persist(productivityOfIntactaSoy2012NoSystem);
		
		productivityOfIntactaSoy2012SystemMons4nto = ProductivityTestData.createProductivity(systemTestFixture.matoGrossoDoSul, plantabilitySystemMons4nto2012); 
		ProductivityTestData.addProductivityValue(productivityOfIntactaSoy2012SystemMons4nto, productIntactaSoyMons4nto);
		ProductivityTestData.addProductivityValue(productivityOfIntactaSoy2012SystemMons4nto, productRRSoyMons4nto);
		ProductivityTestData.addProductivityValue(productivityOfIntactaSoy2012SystemMons4nto, productBTSoyMons4nto);
		ProductivityTestData.addProductivityValue(productivityOfIntactaSoy2012SystemMons4nto, productIntactaWithQuota);
		persist(productivityOfIntactaSoy2012SystemMons4nto);
		
		productivityOfIntactaSoy2012NoSystemMons4nto = ProductivityTestData.createProductivity(systemTestFixture.matoGrossoDoSul, plantability45To54SoyMons4nto2012); 
		ProductivityTestData.addProductivityValue(productivityOfIntactaSoy2012NoSystemMons4nto, productIntactaSoyMons4nto);
		ProductivityTestData.addProductivityValue(productivityOfIntactaSoy2012NoSystemMons4nto, productRRSoyMons4nto);
		ProductivityTestData.addProductivityValue(productivityOfIntactaSoy2012NoSystemMons4nto, productBTSoyMons4nto);
		ProductivityTestData.addProductivityValue(productivityOfIntactaSoy2012NoSystemMons4nto, productIntactaWithQuota);
		persist(productivityOfIntactaSoy2012NoSystemMons4nto);
		
		productivityOfBtSoy2012NoSystem = ProductivityTestData.createProductivity(systemTestFixture.matoGrossoDoSul, plantability45To54SoyMonsanto2012);
		ProductivityTestData.addProductivityValue(productivityOfBtSoy2012NoSystem, productBtSoy);
		ProductivityTestData.addProductivityValue(productivityOfBtSoy2012NoSystem, productIntactaWithQuotaForReport);
		persist(productivityOfBtSoy2012NoSystem);

		templateIntactaFixRRRangeBtNoValue = createTemplateWithSimplePriceTypes(systemTestFixture, SaleTypeEnum.SALE_SEED);
		persist(templateIntactaFixRRRangeBtNoValue);
		
		templateDirectSaleIntactaFixRRRangeBtNoValue = createTemplateWithSimplePriceTypes(systemTestFixture, SaleTypeEnum.DIRECT_SALE);
		persist(templateDirectSaleIntactaFixRRRangeBtNoValue);
		
		templateIntactaMons4nto = createTemplateForMons4nto(systemTestFixture);
		persist(templateIntactaMons4nto);
		
		templateIntactaMons4ntoManualCreditRelease = createManualReleaseTemplateForMons4nto(systemTestFixture);
		persist(templateIntactaMons4ntoManualCreditRelease);
		
		templateIntactaMons4ntoOnPayment = createOnPaymentTemplateForMons4nto(systemTestFixture);
		persist(templateIntactaMons4ntoOnPayment);
		
		templateLicenseSeedMons4nto = createLicenseSeedTemplateForMons4nto(systemTestFixture);
		persist(templateLicenseSeedMons4nto);
		
		
		templateIntactaByPlantabilityRRByExpirationBtFree = createTemplatesWithManyRoyaltyValues(systemTestFixture);
		persist(templateIntactaByPlantabilityRRByExpirationBtFree);
		
		templateIntactaByPlantabilityRRByExpirationBtFreeErp = createTemplatesWithManyRoyaltyValuesErp(systemTestFixture);
		persist(templateIntactaByPlantabilityRRByExpirationBtFreeErp);
		
		templateForLicenseSeedIntactaByPlantabilityRRByExpirationBtFree = createLicenseSeedTemplateWithManyRoyaltyValues(systemTestFixture);
		persist(templateForLicenseSeedIntactaByPlantabilityRRByExpirationBtFree);
		
		templateIntactaNoValueRRNoValue = SaleTemplateTestData.createSaleTemplateTypeSeedSale(harvestSoyMonsanto2012);
		persist(templateIntactaNoValueRRNoValue);
		
		templateIntactaNoValueByPlantability = SaleTemplateTestData.createSaleTemplateTypeSeedSale(harvestSoyMonsanto2012);
		persist(templateIntactaNoValueByPlantability);
		
		templateReservedSeedNoValue = SaleTemplateTestData.createSaleTemplateTypeSeedSale(harvestSoyMonsanto2012);
		templateReservedSeedNoValue.setSaleType(SaleTypeEnum.LICENSE_SEED);
		persist(templateReservedSeedNoValue);
		
		templateFreeWithDueDateRange = createTemplateWithFreePricesAndDueDateRange(systemTestFixture);
		persist(templateFreeWithDueDateRange);
		
		templateFreeWithDueDateRangeAndGenerationCreditDisabled = createTemplateWithFreePricesAndDueDateRangeAndGenerationCreditDisabled(systemTestFixture);
				
		templateByPlantabilityWithFixDueDate = createTemplateWithPricesByPlantabilityAndFixDueDate(systemTestFixture);
		persist(templateByPlantabilityWithFixDueDate);

		templateFixWithDueDateRange = createTemplateWithFixPricesAndDueDateRange(systemTestFixture);
		persist(templateFixWithDueDateRange);
				
		templateRangeWithDueDateRange = createTemplateWithRangePricesAndDueDateRange(systemTestFixture);
		persist(templateRangeWithDueDateRange);

		templateByExpirationDateWithDueDateRange = createTemplateWithPricesByExpirationDateAndDueDateRange(systemTestFixture);
		persist(templateByExpirationDateWithDueDateRange);

        /***
         * TEST JMF
         */
//        templateSeamlessPricingNew = createTemplateSeamlessPricing(systemTestFixture);
//        persist(templateSeamlessPricingNew);

		prepareTemplateTwoNoValue(systemTestFixture);
		prepareTemplateReservedSaleTwoNoValue(systemTestFixture);
		prepareTemplateIntactaFixRRRangeBtNoValueForSale();
		prepareTemplateDirectSaleIntactaFixRRRangeBtNoValueForSale();
		prepareTemplateIntactaByPlantabilityRRByExpirationBtFreeForSale();
		prepareTemplateIntactaNoValueByPlantability();
		prepareTemplateIntactaMons4nto();
		prepareTemplateFixWithDueDateRange();
		prepareTemplateRangeWithDueDateRange();
		prepareTemplateFreeWithDueDateRange();

		saleCancellation = new Cancellation();
		saleCancellation.setCode("SALE_CANCELLATION_TEST_FIXTURE");
		saleCancellation.setDescription("label.cancellation.sale.cancellation");
		saleCancellation.setIsVisible(true);
		persist(saleCancellation);
		
		plantabilitiesSelector = new PlantabilitiesSelector(harvestSoyMonsanto2012.getPlantabilities(), systemTestFixture.matoGrossoDoSul);
		plantabilitiesSelectorMons4nto = new PlantabilitiesSelector(harvestSoyMons4nto2012.getPlantabilities(), systemTestFixture.matoGrossoDoSul);
		
		saleItemFactoryForMatoGrossoDoSul = SaleItemFactory.getInstance(systemTestFixture.matoGrossoDoSul, plantabilitiesSelector);
		saleItemFactoryForMatoGrossoDoSulMons4nto = SaleItemFactory.getInstance(systemTestFixture.matoGrossoDoSul, plantabilitiesSelectorMons4nto);


	}

	private Customer createNewCustomer(String name, Document document, Address a, String sapCode) {
		Customer customer = new Customer(name,document, a, sapCode);
		return customer;
	}



	private SaleTemplate createLicenseSeedTemplateWithManyRoyaltyValues(SystemTestFixture systemTestFixture) {
		SaleTemplate template = createTemplatesWithManyRoyaltyValues(systemTestFixture);
		template.setSaleType(SaleTypeEnum.LICENSE_SEED);
		template.setStartDate(FEBRUARY);
		template.setEndDate(DECEMBER);
		return template;
	}

	private SaleTemplate createTemplateWithPricesByExpirationDateAndDueDateRange(SystemTestFixture systemTestFixture) {
		try {
			SaleTemplate template = SaleTemplateTestData.createSaleTemplateTypeSeedSale(harvestSoyMonsanto2012);

			Price priceByExpirationDateForIntacta = new ByExpirationDate(template, systemTestFixture.intacta);
			priceByExpirationDateForIntacta.addRoyaltyValue(new RoyaltyValue(TWO_POINT_FIVE_DOLLARS, AUGUST));
			priceByExpirationDateForIntacta.addRoyaltyValue(new RoyaltyValue(FIFTY_CENTS, FEBRUARY));
			priceByExpirationDateForIntacta.addDueDate(new DueDateValue(NOVEMBER));
			priceByExpirationDateForIntacta.addDueDate(new DueDateValue(APRIL));

			Price priceByExpirationDateForRr = new ByExpirationDate(template, systemTestFixture.rr);
			priceByExpirationDateForRr.addRoyaltyValue(new RoyaltyValue(TWO_POINT_FIVE_DOLLARS, AUGUST));
			priceByExpirationDateForRr.addRoyaltyValue(new RoyaltyValue(FIFTY_CENTS, FEBRUARY));
			priceByExpirationDateForRr.addDueDate(new DueDateValue(NOVEMBER));
			priceByExpirationDateForRr.addDueDate(new DueDateValue(APRIL));

			Price priceByExpirationDateForBt = new ByExpirationDate(template, systemTestFixture.bt);
			priceByExpirationDateForBt.addRoyaltyValue(new RoyaltyValue(TWO_POINT_FIVE_DOLLARS, AUGUST));
			priceByExpirationDateForBt.addRoyaltyValue(new RoyaltyValue(FIFTY_CENTS, FEBRUARY));
			priceByExpirationDateForBt.addDueDate(new DueDateValue(NOVEMBER));
			priceByExpirationDateForBt.addDueDate(new DueDateValue(APRIL));

			template.addPrices(priceByExpirationDateForIntacta);
			template.addPrices(priceByExpirationDateForRr);
			template.addPrices(priceByExpirationDateForBt);

			return template;
		} catch (BusinessException e) {
			throw new IllegalStateException("Error creating SaleTemplate during SaleTestFixture", e);
		}
	}

	private SaleTemplate createTemplateWithRangePricesAndDueDateRange( SystemTestFixture systemTestFixture) {
		try {
			SaleTemplate template = SaleTemplateTestData.createSaleTemplateTypeSeedSale(harvestSoyMonsanto2012);

			Price fixPriceForIntacta = createPriceRangeByTemplate(systemTestFixture.intacta, template);
			fixPriceForIntacta.addDueDate(new DueDateValue(APRIL));

			Price fixPriceForRr = createPriceRangeByTemplate(systemTestFixture.rr, template);
			fixPriceForRr.addDueDate(new DueDateValue(APRIL));

			Price fixPriceForBt = createPriceRangeByTemplate(systemTestFixture.bt, template);
			fixPriceForBt.addDueDate(new DueDateValue(APRIL));

			template.addPrices(fixPriceForIntacta);
			template.addPrices(fixPriceForRr);
			template.addPrices(fixPriceForBt);

			return template;
		} catch (BusinessException e) {
			throw new IllegalStateException("Error creating SaleTemplate during SaleTestFixture", e);
		}
	}

	private SaleTemplate createTemplateWithFixPricesAndDueDateRange(SystemTestFixture systemTestFixture) {
		try {
			SaleTemplate template = SaleTemplateTestData.createSaleTemplateTypeSeedSale(harvestSoyMonsanto2012);

			Price fixPriceForIntacta = createPriceFixByTemplate(systemTestFixture.intacta, template);
			fixPriceForIntacta.addDueDate(new DueDateValue(APRIL));

			Price fixPriceForRr = createPriceFixByTemplate(systemTestFixture.rr, template);
			fixPriceForRr.addDueDate(new DueDateValue(APRIL));

			Price fixPriceForBt = createPriceFixByTemplate(systemTestFixture.bt, template);
			fixPriceForBt.addDueDate(new DueDateValue(APRIL));

			template.addPrices(fixPriceForIntacta);
			template.addPrices(fixPriceForRr);
			template.addPrices(fixPriceForBt);

			return template;
		} catch (BusinessException e) {
			throw new IllegalStateException("Error creating SaleTemplate during SaleTestFixture", e);
		}
	}

	private void prepareTemplateReservedSaleTwoNoValue(SystemTestFixture systemTestFixture) {
		try {
			Price noValuePrice1 = PriceTestData.createPrice(PriceTypeEnum.NO_VALUE, templateReservedSeedNoValue, systemTestFixture.intacta);
			Price noValuePrice2 = PriceTestData.createPrice(PriceTypeEnum.NO_VALUE, templateReservedSeedNoValue, systemTestFixture.intacta);
			templateReservedSeedNoValue.addPrices(noValuePrice1);
			templateReservedSeedNoValue.addPrices(noValuePrice2);
			templateReservedSeedNoValue.addHeadOffice(headOfficeCargil);
			templateReservedSeedNoValue.addProduct(productIntactaSoy);
			templateReservedSeedNoValue.addProduct(productIntactaCoffee);
			persist(templateReservedSeedNoValue);
		} catch (BusinessException e) {
			throw new IllegalStateException("Error creating SaleTemplate during SaleTestFixture", e);
		}
		
	}

	private void prepareTemplateTwoNoValue(SystemTestFixture systemTestFixture) {
		try {
			Price noValuePrice1 = PriceTestData.createPrice(PriceTypeEnum.NO_VALUE, templateIntactaNoValueRRNoValue, systemTestFixture.intacta);
			Price noValuePrice2 = PriceTestData.createPrice(PriceTypeEnum.NO_VALUE, templateIntactaNoValueRRNoValue, systemTestFixture.rr);
			templateIntactaNoValueRRNoValue.addPrices(noValuePrice1);
			templateIntactaNoValueRRNoValue.addPrices(noValuePrice2);
			templateIntactaNoValueRRNoValue.addHeadOffice(headOfficeCargil);
			templateIntactaNoValueRRNoValue.addProduct(productIntactaSoy);
			templateIntactaNoValueRRNoValue.addProduct(productIntactaCoffee);
			persist(templateIntactaNoValueRRNoValue);
		} catch (BusinessException e) {
			throw new IllegalStateException("Error creating SaleTemplate during SaleTestFixture", e);
		}

	}

	private void prepareTemplateIntactaFixRRRangeBtNoValueForSale() {
		templateIntactaFixRRRangeBtNoValue.addHeadOffice(officeCustomer);
		templateIntactaFixRRRangeBtNoValue.addHeadOffice(headOfficeCargil);
		templateIntactaFixRRRangeBtNoValue.addProduct(productIntactaSoy);
		templateIntactaFixRRRangeBtNoValue.addProduct(productBtSoy);
		templateIntactaFixRRRangeBtNoValue.addProduct(productRRSoy);
		templateIntactaFixRRRangeBtNoValue.addProduct(productIntactaWithQuota);
		templateIntactaFixRRRangeBtNoValue.addProduct(productCargilIntactaSoy);
		templateIntactaFixRRRangeBtNoValue.setBillingMethod(SaleTemplateBillingMethodEnum.BANKSLIP);
		persist(templateIntactaFixRRRangeBtNoValue);
	}

	private void prepareTemplateDirectSaleIntactaFixRRRangeBtNoValueForSale() {
		templateDirectSaleIntactaFixRRRangeBtNoValue.addHeadOffice(officeCustomer);
		templateDirectSaleIntactaFixRRRangeBtNoValue.addHeadOffice(headOfficeCargil);
		templateDirectSaleIntactaFixRRRangeBtNoValue.addProduct(productIntactaSoy);
		templateDirectSaleIntactaFixRRRangeBtNoValue.addProduct(productBtSoy);
		templateDirectSaleIntactaFixRRRangeBtNoValue.addProduct(productRRSoy);
		templateDirectSaleIntactaFixRRRangeBtNoValue.addProduct(productIntactaWithQuota);
		templateDirectSaleIntactaFixRRRangeBtNoValue.addProduct(productCargilIntactaSoy);
		templateDirectSaleIntactaFixRRRangeBtNoValue.setBillingMethod(SaleTemplateBillingMethodEnum.BANKSLIP);
		persist(templateDirectSaleIntactaFixRRRangeBtNoValue);
	}

	private void prepareTemplateIntactaByPlantabilityRRByExpirationBtFreeForSale() {
		templateIntactaByPlantabilityRRByExpirationBtFree.addHeadOffice(officeCustomer);
		templateIntactaByPlantabilityRRByExpirationBtFree.addHeadOffice(headOfficeCargil);
		templateIntactaByPlantabilityRRByExpirationBtFree.addHeadOffice(agroSojaMatrix);
		templateIntactaByPlantabilityRRByExpirationBtFree.addProduct(productIntactaSoy);
		templateIntactaByPlantabilityRRByExpirationBtFree.addProduct(productIntactaWithQuota);
		templateIntactaByPlantabilityRRByExpirationBtFree.addProduct(productBtSoy);
		templateIntactaByPlantabilityRRByExpirationBtFree.addProduct(productRRSoy);
		templateIntactaByPlantabilityRRByExpirationBtFree.setBillingMethod(SaleTemplateBillingMethodEnum.BANKSLIP);
		persist(templateIntactaByPlantabilityRRByExpirationBtFree);
		
		templateIntactaByPlantabilityRRByExpirationBtFreeErp.addHeadOffice(headOfficeCargil);
		templateIntactaByPlantabilityRRByExpirationBtFreeErp.addHeadOffice(agroSojaMatrix);
        templateIntactaByPlantabilityRRByExpirationBtFreeErp.addProduct(productIntactaSoy);
        templateIntactaByPlantabilityRRByExpirationBtFreeErp.addProduct(productIntactaWithQuota);
        templateIntactaByPlantabilityRRByExpirationBtFreeErp.addProduct(productIntactaWithQuotaForReport);
        templateIntactaByPlantabilityRRByExpirationBtFreeErp.addProduct(productBtSoy);
        templateIntactaByPlantabilityRRByExpirationBtFreeErp.setBillingMethod(SaleTemplateBillingMethodEnum.ERP);
        persist(templateIntactaByPlantabilityRRByExpirationBtFreeErp);
		
		templateForLicenseSeedIntactaByPlantabilityRRByExpirationBtFree.addHeadOffice(headOfficeCargil);
		templateForLicenseSeedIntactaByPlantabilityRRByExpirationBtFree.addProduct(productIntactaSoy);
		templateForLicenseSeedIntactaByPlantabilityRRByExpirationBtFree.addProduct(productBtSoy);
		templateForLicenseSeedIntactaByPlantabilityRRByExpirationBtFree.setBillingMethod(SaleTemplateBillingMethodEnum.BANKSLIP);
		persist(templateForLicenseSeedIntactaByPlantabilityRRByExpirationBtFree);
	}

	private void prepareTemplateIntactaNoValueByPlantability() {
		try {
			templateIntactaNoValueByPlantability.addHeadOffice(headOfficeCargil);
			templateIntactaNoValueByPlantability.addProduct(productIntactaSoy);
			templateIntactaNoValueByPlantability.setBillingMethod(SaleTemplateBillingMethodEnum.BANKSLIP);
			Price noValuePlantability = PriceTestData.createPrice(PriceTypeEnum.NO_VALUE_BY_PLANTABILITY, templateIntactaNoValueByPlantability, productIntactaSoy.getTechnology());
			templateIntactaNoValueByPlantability.addPrices(noValuePlantability);
			persist(templateIntactaNoValueByPlantability);
		} catch (BusinessException e) {
			throw new IllegalStateException("Error creating SaleTemplate during SaleTestFixture", e);
		}
	}
	
	private void prepareTemplateIntactaMons4nto() {
		templateIntactaMons4nto.addHeadOffice(officeMons4nto);
		templateIntactaMons4nto.addProduct(productIntactaSoyMons4nto);
		templateIntactaMons4nto.addProduct(productRRSoyMons4nto);
		templateIntactaMons4nto.addProduct(productBTSoyMons4nto);
        templateIntactaMons4nto.addProduct(productIntactaWithQuota);
		templateIntactaMons4nto
				.setBillingMethod(SaleTemplateBillingMethodEnum.BANKSLIP);

		templateLicenseSeedMons4nto.addHeadOffice(officeMons4nto);
		templateLicenseSeedMons4nto.addProduct(productIntactaSoyMons4nto);
		templateLicenseSeedMons4nto
				.setBillingMethod(SaleTemplateBillingMethodEnum.BANKSLIP);
		
		templateIntactaMons4ntoManualCreditRelease.addHeadOffice(officeMons4nto);
        templateIntactaMons4ntoManualCreditRelease.addProduct(productIntactaSoyMons4nto);
        templateIntactaMons4ntoManualCreditRelease.addProduct(productIntactaWithQuota);
        templateIntactaMons4ntoManualCreditRelease
                .setBillingMethod(SaleTemplateBillingMethodEnum.BANKSLIP);

		templateIntactaMons4ntoOnPayment.addHeadOffice(officeMons4nto);
        templateIntactaMons4ntoOnPayment.addProduct(productIntactaSoyMons4nto);
        templateIntactaMons4ntoOnPayment.addProduct(productRRSoyMons4nto);
        templateIntactaMons4ntoOnPayment.addProduct(productBTSoyMons4nto);
        templateIntactaMons4ntoOnPayment.addProduct(productIntactaWithQuota);
        templateIntactaMons4ntoOnPayment
                .setBillingMethod(SaleTemplateBillingMethodEnum.BANKSLIP);
        
		persist(templateIntactaMons4nto);
		persist(templateLicenseSeedMons4nto);
		persist(templateIntactaMons4ntoManualCreditRelease);
		persist(templateIntactaMons4ntoOnPayment);
	}
	
	private void prepareTemplateFixWithDueDateRange() {
		templateFixWithDueDateRange.addHeadOffice(officeCustomer);
		templateFixWithDueDateRange.addProduct(productIntactaSoy);
		templateFixWithDueDateRange.setBillingMethod(SaleTemplateBillingMethodEnum.BANKSLIP);

		persist(templateFixWithDueDateRange);
	}
	
	private void prepareTemplateFreeWithDueDateRange() {
		templateFreeWithDueDateRange.addHeadOffice(officeCustomer);
		templateFreeWithDueDateRange.addProduct(productIntactaSoy);
		templateFreeWithDueDateRange.setBillingMethod(SaleTemplateBillingMethodEnum.BANKSLIP);

		persist(templateFreeWithDueDateRange);
	}
	
	private void prepareTemplateRangeWithDueDateRange() {
		templateRangeWithDueDateRange.addHeadOffice(officeCustomer);
		templateRangeWithDueDateRange.addProduct(productIntactaSoy);
		templateRangeWithDueDateRange.setBillingMethod(SaleTemplateBillingMethodEnum.BANKSLIP);
		
		templateRangeWithDueDateRange.addHeadOffice(officeCustomer);
		templateRangeWithDueDateRange.addProduct(productRRSoy);
		templateRangeWithDueDateRange.setBillingMethod(SaleTemplateBillingMethodEnum.BANKSLIP);

		persist(templateRangeWithDueDateRange);
	}
	
	private SaleTemplate createTemplateWithSimplePriceTypes(SystemTestFixture systemTestFixture, SaleTypeEnum saleType) {
		try {
			SaleTemplate template = SaleTemplateTestData.createSaleTemplate(harvestSoyMonsanto2012, saleType);

			Price fixPrice = createPriceFixByTemplate(systemTestFixture.intacta, template);

			Price rangePrice = createPriceRangeByTemplate(systemTestFixture.rr,	template);

			Price noValuePrice = PriceTestData.createPrice(PriceTypeEnum.NO_VALUE, template, systemTestFixture.bt);

			template.addPrices(fixPrice);
			template.addPrices(rangePrice);
			template.addPrices(noValuePrice);

			return template;
		} catch (BusinessException e) {
			throw new IllegalStateException("Error creating SaleTemplate during SaleTestFixture", e);
		}
	}

	   private SaleTemplate createTemplateForMons4nto(SystemTestFixture systemTestFixture) {
	        try {
	            SaleTemplate template = SaleTemplateTestData.createSaleTemplateTypeSeedSale(harvestSoyMons4nto2012);

	            
	            Price plantabilityPrice = new ByPlantabilityAndExpirationDate(template, systemTestFixture.intactaMons4nto);
	            plantabilityPrice.addRoyaltyValue(createRoyaltyWithPlantability(SEVENTY_CENTS, AUGUST, plantability45To54SoyMons4nto2012));
	            plantabilityPrice.addRoyaltyValue(createRoyaltyWithPlantability(ONE_POINT_THREE_DOLLARS, FEBRUARY, plantability45To54SoyMons4nto2012));
				plantabilityPrice.addRoyaltyValue(createRoyaltyWithPlantability(TWO_POINT_FIVE_DOLLARS, AUGUST, plantabilitySystemMons4nto2012));
				plantabilityPrice.addRoyaltyValue(createRoyaltyWithPlantability(FIFTY_CENTS, FEBRUARY, plantabilitySystemMons4nto2012));
	            plantabilityPrice.addDueDate(new DueDateValue(APRIL));
	            plantabilityPrice.addDueDate(new DueDateValue(NOVEMBER));
	            plantabilityPrice.setReleaseCreditType(ReleaseCreditTypeEnum.AUTOMATICALLY);
	            template.addPrices(plantabilityPrice);

	            plantabilityPrice = new ByPlantabilityAndExpirationDate(template, systemTestFixture.rrMons4nto);
                plantabilityPrice.addRoyaltyValue(createRoyaltyWithPlantability(SEVENTY_CENTS, AUGUST, plantability45To54SoyMons4nto2012));
                plantabilityPrice.addRoyaltyValue(createRoyaltyWithPlantability(ONE_POINT_THREE_DOLLARS, FEBRUARY, plantability45To54SoyMons4nto2012));
                plantabilityPrice.addRoyaltyValue(createRoyaltyWithPlantability(TWO_POINT_FIVE_DOLLARS, AUGUST, plantabilitySystemMons4nto2012));
                plantabilityPrice.addRoyaltyValue(createRoyaltyWithPlantability(FIFTY_CENTS, FEBRUARY, plantabilitySystemMons4nto2012));
                plantabilityPrice.addDueDate(new DueDateValue(APRIL));
                plantabilityPrice.addDueDate(new DueDateValue(NOVEMBER));
                plantabilityPrice.setReleaseCreditType(ReleaseCreditTypeEnum.AUTOMATICALLY);
	            template.addPrices(plantabilityPrice);
                
                plantabilityPrice = new ByPlantabilityAndExpirationDate(template, systemTestFixture.btMons4nto);
                plantabilityPrice.addRoyaltyValue(createRoyaltyWithPlantability(SEVENTY_CENTS, AUGUST, plantability45To54SoyMons4nto2012));
                plantabilityPrice.addRoyaltyValue(createRoyaltyWithPlantability(ONE_POINT_THREE_DOLLARS, FEBRUARY, plantability45To54SoyMons4nto2012));
                plantabilityPrice.addRoyaltyValue(createRoyaltyWithPlantability(TWO_POINT_FIVE_DOLLARS, AUGUST, plantabilitySystemMons4nto2012));
                plantabilityPrice.addRoyaltyValue(createRoyaltyWithPlantability(FIFTY_CENTS, FEBRUARY, plantabilitySystemMons4nto2012));
                plantabilityPrice.addDueDate(new DueDateValue(APRIL));
                plantabilityPrice.addDueDate(new DueDateValue(NOVEMBER));
                plantabilityPrice.setReleaseCreditType(ReleaseCreditTypeEnum.AUTOMATICALLY);
	            
	            template.addPrices(plantabilityPrice);
	            

	            return template;
	        } catch (BusinessException e) {
	            throw new IllegalStateException("Error creating SaleTemplate during SaleTestFixture", e);
	        }
	    }
	   
	   private SaleTemplate createManualReleaseTemplateForMons4nto(SystemTestFixture systemTestFixture) {
           try {
               SaleTemplate template = SaleTemplateTestData.createSaleTemplateTypeSeedSale(harvestSoyMons4nto2012);

               
               Price plantabilityPrice = new ByPlantabilityAndExpirationDate(template, systemTestFixture.intactaMons4nto);
               plantabilityPrice.addRoyaltyValue(createRoyaltyWithPlantability(SEVENTY_CENTS, AUGUST, plantability45To54SoyMons4nto2012));
               plantabilityPrice.addRoyaltyValue(createRoyaltyWithPlantability(ONE_POINT_THREE_DOLLARS, FEBRUARY, plantability45To54SoyMons4nto2012));
               plantabilityPrice.addRoyaltyValue(createRoyaltyWithPlantability(TWO_POINT_FIVE_DOLLARS, AUGUST, plantabilitySystemMons4nto2012));
               plantabilityPrice.addRoyaltyValue(createRoyaltyWithPlantability(FIFTY_CENTS, FEBRUARY, plantabilitySystemMons4nto2012));
               plantabilityPrice.addDueDate(new DueDateValue(APRIL));
               plantabilityPrice.addDueDate(new DueDateValue(NOVEMBER));
               plantabilityPrice.setReleaseCreditType(ReleaseCreditTypeEnum.MANUALLY);

               template.addPrices(plantabilityPrice);
               

               return template;
           } catch (BusinessException e) {
               throw new IllegalStateException("Error creating SaleTemplate during SaleTestFixture", e);
           }
       }
      
	   private SaleTemplate createOnPaymentTemplateForMons4nto(SystemTestFixture systemTestFixture) {
           try {
               SaleTemplate template = SaleTemplateTestData.createSaleTemplateTypeSeedSale(harvestSoyMons4nto2012);

               
               Price plantabilityPrice = new ByPlantabilityAndExpirationDate(template, systemTestFixture.intactaMons4nto);
               plantabilityPrice.addRoyaltyValue(createRoyaltyWithPlantability(SEVENTY_CENTS, AUGUST, plantability45To54SoyMons4nto2012));
               plantabilityPrice.addRoyaltyValue(createRoyaltyWithPlantability(ONE_POINT_THREE_DOLLARS, FEBRUARY, plantability45To54SoyMons4nto2012));
               plantabilityPrice.addRoyaltyValue(createRoyaltyWithPlantability(TWO_POINT_FIVE_DOLLARS, AUGUST, plantabilitySystemMons4nto2012));
               plantabilityPrice.addRoyaltyValue(createRoyaltyWithPlantability(FIFTY_CENTS, FEBRUARY, plantabilitySystemMons4nto2012));
               plantabilityPrice.addDueDate(new DueDateValue(APRIL));
               plantabilityPrice.addDueDate(new DueDateValue(NOVEMBER));
               plantabilityPrice.setReleaseCreditType(ReleaseCreditTypeEnum.ON_PAYMENT);

               template.addPrices(plantabilityPrice);
               
			   plantabilityPrice = new ByPlantabilityAndExpirationDate(template, systemTestFixture.rrMons4nto);
               plantabilityPrice.addRoyaltyValue(createRoyaltyWithPlantability(SEVENTY_CENTS, AUGUST, plantability45To54SoyMons4nto2012));
               plantabilityPrice.addRoyaltyValue(createRoyaltyWithPlantability(ONE_POINT_THREE_DOLLARS, FEBRUARY, plantability45To54SoyMons4nto2012));
               plantabilityPrice.addRoyaltyValue(createRoyaltyWithPlantability(TWO_POINT_FIVE_DOLLARS, AUGUST, plantabilitySystemMons4nto2012));
               plantabilityPrice.addRoyaltyValue(createRoyaltyWithPlantability(FIFTY_CENTS, FEBRUARY, plantabilitySystemMons4nto2012));
               plantabilityPrice.addDueDate(new DueDateValue(APRIL));
               plantabilityPrice.addDueDate(new DueDateValue(NOVEMBER));
               plantabilityPrice.setReleaseCreditType(ReleaseCreditTypeEnum.ON_PAYMENT);

               template.addPrices(plantabilityPrice);
               
 			   plantabilityPrice = new ByPlantabilityAndExpirationDate(template, systemTestFixture.btMons4nto);
               plantabilityPrice.addRoyaltyValue(createRoyaltyWithPlantability(SEVENTY_CENTS, AUGUST, plantability45To54SoyMons4nto2012));
               plantabilityPrice.addRoyaltyValue(createRoyaltyWithPlantability(ONE_POINT_THREE_DOLLARS, FEBRUARY, plantability45To54SoyMons4nto2012));
               plantabilityPrice.addRoyaltyValue(createRoyaltyWithPlantability(TWO_POINT_FIVE_DOLLARS, AUGUST, plantabilitySystemMons4nto2012));
               plantabilityPrice.addRoyaltyValue(createRoyaltyWithPlantability(FIFTY_CENTS, FEBRUARY, plantabilitySystemMons4nto2012));
               plantabilityPrice.addDueDate(new DueDateValue(APRIL));
               plantabilityPrice.addDueDate(new DueDateValue(NOVEMBER));
               plantabilityPrice.setReleaseCreditType(ReleaseCreditTypeEnum.ON_PAYMENT);

               template.addPrices(plantabilityPrice);              

               return template;
           } catch (BusinessException e) {
               throw new IllegalStateException("Error creating SaleTemplate during SaleTestFixture", e);
           }
       }
	   
	   private SaleTemplate createLicenseSeedTemplateForMons4nto(SystemTestFixture systemTestFixture) {
	        SaleTemplate template = createTemplateForMons4nto(systemTestFixture);
	       
	        template.setSaleType(SaleTypeEnum.LICENSE_SEED);
	        template.setStartDate(FEBRUARY);
	        template.setEndDate(DECEMBER);
	        return template;

       }
	   
	private Price createPriceRangeByTemplate(Technology technology, SaleTemplate template) throws BusinessException, DueDateCanNotBeMoreThanTwoException, DueDateCanNotBeEqualsAnotherException {
		Price rangePrice = PriceTestData.createPrice(PriceTypeEnum.RANGE, template, technology);
		rangePrice.addRoyaltyValue(new RoyaltyValue(FIFTY_CENTS));
		rangePrice.addRoyaltyValue(new RoyaltyValue(TWO_POINT_FIVE_DOLLARS));
		rangePrice.addDueDate(new DueDateValue(DATE_NOW));
		rangePrice.setReleaseCreditType(ReleaseCreditTypeEnum.ON_PAYMENT);
		return rangePrice;
	}

	private Price createPriceFixByTemplate(Technology technology, SaleTemplate template) throws BusinessException, DueDateCanNotBeMoreThanTwoException, DueDateCanNotBeEqualsAnotherException {
		Price fixPrice = PriceTestData.createPrice(PriceTypeEnum.FIX, template, technology);
		fixPrice.addRoyaltyValue(new RoyaltyValue(FIVE_DOLLARS));
		fixPrice.addDueDate(new DueDateValue(DATE_NOW));
		fixPrice.setReleaseCreditType(ReleaseCreditTypeEnum.ON_PAYMENT);
		
		RetributionFee retributionFee = new RetributionFee();
		retributionFee.setMarketingProgramEnabled(true);
		retributionFee.setMarketingProgramSourceType(RetributionSourceType.ITS);
		retributionFee.setMarketingProgram(new BigDecimal("10"));
		retributionFee.setRetributionFeeEnabled(true);
		retributionFee.setRetributionFeeSourceType(RetributionSourceType.ITS);
		retributionFee.setRetributionFee(new BigDecimal("10"));
		fixPrice.setRetributionFee(retributionFee);
		
		return fixPrice;
	}

	private SaleTemplate createTemplatesWithManyRoyaltyValues(SystemTestFixture systemTestFixture) {
		try {
			SaleTemplate template = SaleTemplateTestData.createSaleTemplateTypeSeedSale(harvestSoyMonsanto2012);

			Price plantabilityPrice = new ByPlantabilityAndExpirationDate(template, systemTestFixture.intacta);
			plantabilityPrice.addRoyaltyValue(createRoyaltyWithPlantability(SEVENTY_CENTS, AUGUST, plantability45To54SoyMonsanto2012));
			plantabilityPrice.addRoyaltyValue(createRoyaltyWithPlantability(ONE_POINT_THREE_DOLLARS, FEBRUARY, plantability45To54SoyMonsanto2012));
			plantabilityPrice.addRoyaltyValue(createRoyaltyWithPlantability(TWO_POINT_FIVE_DOLLARS, AUGUST, plantabilitySystemSoyMonsanto2012));
			plantabilityPrice.addRoyaltyValue(createRoyaltyWithPlantability(FIFTY_CENTS, FEBRUARY, plantabilitySystemSoyMonsanto2012));
			plantabilityPrice.addDueDate(new DueDateValue(APRIL));
			plantabilityPrice.addDueDate(new DueDateValue(NOVEMBER));
			plantabilityPrice.setReleaseCreditType(ReleaseCreditTypeEnum.ON_PAYMENT);
			
			RetributionFee retributionFeeIntacta = new RetributionFee();
			retributionFeeIntacta.setRetributionFeeEnabled(true);
			retributionFeeIntacta.setRetributionFee(new BigDecimal("10"));
			retributionFeeIntacta.setRetributionFeeSourceType(RetributionSourceType.ITS);
			retributionFeeIntacta.setMarketingProgramEnabled(true);
			retributionFeeIntacta.setMarketingProgram(new BigDecimal("10"));
			retributionFeeIntacta.setMarketingProgramSourceType(RetributionSourceType.ITS);
			plantabilityPrice.setRetributionFee(retributionFeeIntacta);

			Price expirationDatePrice = new ByExpirationDate(template, systemTestFixture.rr);
			expirationDatePrice.addRoyaltyValue(new RoyaltyValue(TWO_POINT_FIVE_DOLLARS, AUGUST));
			expirationDatePrice.addRoyaltyValue(new RoyaltyValue(FIFTY_CENTS, FEBRUARY));
			expirationDatePrice.addDueDate(new DueDateValue(NOVEMBER));
			expirationDatePrice.setReleaseCreditType(ReleaseCreditTypeEnum.ON_PAYMENT);

			Price freeValuePrice = new FreeValue(template, systemTestFixture.bt);
			freeValuePrice.addDueDate(new DueDateValue(NOVEMBER));
			freeValuePrice.setReleaseCreditType(ReleaseCreditTypeEnum.ON_PAYMENT);

			template.addPrices(plantabilityPrice);
			template.addPrices(expirationDatePrice);
			template.addPrices(freeValuePrice);

			return template;
		} catch (BusinessException e) {
			throw new IllegalStateException("Error creating SaleTemplate during SaleTestFixture", e);
		}
	}
	
	   private SaleTemplate createTemplatesWithManyRoyaltyValuesErp(SystemTestFixture systemTestFixture) {
	        try {
	            SaleTemplate template = SaleTemplateTestData.createSaleTemplateTypeSeedSale(harvestSoyMonsanto2012);

	            Price plantabilityPrice = new ByPlantabilityAndExpirationDate(template, systemTestFixture.intacta);
	            plantabilityPrice.addRoyaltyValue(createRoyaltyWithPlantability(SEVENTY_CENTS, AUGUST, plantability45To54SoyMonsanto2012));
	            plantabilityPrice.addRoyaltyValue(createRoyaltyWithPlantability(ONE_POINT_THREE_DOLLARS, FEBRUARY, plantability45To54SoyMonsanto2012));
	            plantabilityPrice.addRoyaltyValue(createRoyaltyWithPlantability(TWO_POINT_FIVE_DOLLARS, AUGUST, plantabilitySystemSoyMonsanto2012));
	            plantabilityPrice.addRoyaltyValue(createRoyaltyWithPlantability(FIFTY_CENTS, FEBRUARY, plantabilitySystemSoyMonsanto2012));
	            plantabilityPrice.addDueDate(new DueDateValue(APRIL));
	            plantabilityPrice.addDueDate(new DueDateValue(NOVEMBER));
	            plantabilityPrice.setReleaseCreditType(ReleaseCreditTypeEnum.ON_PAYMENT);
	            
	            RetributionFee retributionFeeIntacta = new RetributionFee();
	            retributionFeeIntacta.setRetributionFeeEnabled(true);
	            retributionFeeIntacta.setRetributionFee(new BigDecimal("10"));
	            retributionFeeIntacta.setRetributionFeeSourceType(RetributionSourceType.ITS);
	            retributionFeeIntacta.setMarketingProgramEnabled(true);
	            retributionFeeIntacta.setMarketingProgram(new BigDecimal("10"));
	            retributionFeeIntacta.setMarketingProgramSourceType(RetributionSourceType.ITS);
	            plantabilityPrice.setRetributionFee(retributionFeeIntacta);

	            Price plantabilityPrice2 = new ByPlantabilityAndExpirationDate(template, systemTestFixture.rr);
                plantabilityPrice2.addRoyaltyValue(createRoyaltyWithPlantability(SEVENTY_CENTS, AUGUST, plantability45To54SoyMonsanto2012));
                plantabilityPrice2.addRoyaltyValue(createRoyaltyWithPlantability(ONE_POINT_THREE_DOLLARS, FEBRUARY, plantability45To54SoyMonsanto2012));
                plantabilityPrice2.addRoyaltyValue(createRoyaltyWithPlantability(TWO_POINT_FIVE_DOLLARS, AUGUST, plantabilitySystemSoyMonsanto2012));
                plantabilityPrice2.addRoyaltyValue(createRoyaltyWithPlantability(FIFTY_CENTS, FEBRUARY, plantabilitySystemSoyMonsanto2012));
                plantabilityPrice2.addDueDate(new DueDateValue(APRIL));
                plantabilityPrice2.addDueDate(new DueDateValue(NOVEMBER));
                plantabilityPrice2.setReleaseCreditType(ReleaseCreditTypeEnum.ON_PAYMENT);

	            Price freeValuePrice = new FreeValue(template, systemTestFixture.bt);
	            freeValuePrice.addDueDate(new DueDateValue(NOVEMBER));
	            freeValuePrice.setReleaseCreditType(ReleaseCreditTypeEnum.ON_PAYMENT);

	            template.addPrices(plantabilityPrice);
	            template.addPrices(plantabilityPrice2);
	            template.addPrices(freeValuePrice);

	            return template;
	        } catch (BusinessException e) {
	            throw new IllegalStateException("Error creating SaleTemplate during SaleTestFixture", e);
	        }
	    }

	private SaleTemplate createTemplateWithFreePricesAndDueDateRange(SystemTestFixture systemTestFixture) {
		try {
			SaleTemplate template = SaleTemplateTestData.createSaleTemplateTypeSeedSale(harvestSoyMonsanto2012);

			Price freePriceForIntacta = new FreeValue(template, systemTestFixture.intacta);
			freePriceForIntacta.addDueDate(new DueDateValue(APRIL));
			freePriceForIntacta.addDueDate(new DueDateValue(NOVEMBER));

			Price freePriceForRr = new FreeValue(template, systemTestFixture.rr);
			freePriceForRr.addDueDate(new DueDateValue(APRIL));
			freePriceForRr.addDueDate(new DueDateValue(NOVEMBER));

			Price freePriceForBr = new FreeValue(template, systemTestFixture.bt);
			freePriceForBr.addDueDate(new DueDateValue(APRIL));
			freePriceForBr.addDueDate(new DueDateValue(NOVEMBER));

			template.addPrices(freePriceForIntacta);
			template.addPrices(freePriceForRr);
			template.addPrices(freePriceForBr);

			return template;
		} catch (BusinessException e) {
			throw new IllegalStateException("Error creating SaleTemplate during SaleTestFixture", e);
		}
	}

	private SaleTemplate createTemplateWithFreePricesAndDueDateRangeAndGenerationCreditDisabled(SystemTestFixture systemTestFixture) {
		SaleTemplate template = createTemplateWithFreePricesAndDueDateRange(systemTestFixture);
		for(Price price : template.getPrices()) {
			price.setCreditGenerationEnabled(Boolean.FALSE);
		}
		return template;
	}

	private SaleTemplate createTemplateWithPricesByPlantabilityAndFixDueDate(SystemTestFixture systemTestFixture) {
		try {
			SaleTemplate template = SaleTemplateTestData.createSaleTemplateTypeSeedSale(harvestSoyMonsanto2012);

			Price plantabilityPriceForIntacta = new ByPlantabilityAndExpirationDate(template, systemTestFixture.intacta);
			plantabilityPriceForIntacta.addRoyaltyValue(createRoyaltyWithPlantability(SEVENTY_CENTS, AUGUST, plantability45To54SoyMonsanto2012));
			plantabilityPriceForIntacta.addRoyaltyValue(createRoyaltyWithPlantability(ONE_POINT_THREE_DOLLARS, FEBRUARY, plantability45To54SoyMonsanto2012));
			plantabilityPriceForIntacta.addRoyaltyValue(createRoyaltyWithPlantability(TWO_POINT_FIVE_DOLLARS, AUGUST, plantabilitySystemSoyMonsanto2012));
			plantabilityPriceForIntacta.addRoyaltyValue(createRoyaltyWithPlantability(FIFTY_CENTS, FEBRUARY, plantabilitySystemSoyMonsanto2012));
			plantabilityPriceForIntacta.addDueDate(new DueDateValue(NOVEMBER));

			Price plantabilityPriceForRr = new ByPlantabilityAndExpirationDate(template, systemTestFixture.rr);
			plantabilityPriceForRr.addRoyaltyValue(createRoyaltyWithPlantability(SEVENTY_CENTS, AUGUST, plantability45To54SoyMonsanto2012));
			plantabilityPriceForRr.addRoyaltyValue(createRoyaltyWithPlantability(ONE_POINT_THREE_DOLLARS, FEBRUARY, plantability45To54SoyMonsanto2012));
			plantabilityPriceForRr.addRoyaltyValue(createRoyaltyWithPlantability(TWO_POINT_FIVE_DOLLARS, AUGUST, plantabilitySystemSoyMonsanto2012));
			plantabilityPriceForRr.addRoyaltyValue(createRoyaltyWithPlantability(FIFTY_CENTS, FEBRUARY, plantabilitySystemSoyMonsanto2012));
			plantabilityPriceForRr.addDueDate(new DueDateValue(NOVEMBER));

			Price plantabilityPriceForBt = new ByPlantabilityAndExpirationDate(template, systemTestFixture.bt);
			plantabilityPriceForBt.addRoyaltyValue(createRoyaltyWithPlantability(SEVENTY_CENTS, AUGUST, plantability45To54SoyMonsanto2012));
			plantabilityPriceForBt.addRoyaltyValue(createRoyaltyWithPlantability(ONE_POINT_THREE_DOLLARS, FEBRUARY, plantability45To54SoyMonsanto2012));
			plantabilityPriceForBt.addRoyaltyValue(createRoyaltyWithPlantability(TWO_POINT_FIVE_DOLLARS, AUGUST, plantabilitySystemSoyMonsanto2012));
			plantabilityPriceForBt.addRoyaltyValue(createRoyaltyWithPlantability(FIFTY_CENTS, FEBRUARY, plantabilitySystemSoyMonsanto2012));
			plantabilityPriceForBt.addDueDate(new DueDateValue(NOVEMBER));

			template.addPrices(plantabilityPriceForIntacta);
			template.addPrices(plantabilityPriceForRr);
			template.addPrices(plantabilityPriceForBt);

			return template;
		} catch (BusinessException e) {
			throw new IllegalStateException("Error creating SaleTemplate during SaleTestFixture", e);
		}
	}

	private RoyaltyValue createRoyaltyWithPlantability(BigDecimal value, Date royaltyDueDate, Plantability plantability) {
		RoyaltyValue royaltyValue = new RoyaltyValue(value, royaltyDueDate);
		royaltyValue.setPlantability(plantability);
		return royaltyValue;
	}

    private void createSimpleGrower(SystemTestFixture systemTestFixture) {
        chicoBentoSimpleDocument = PlayerTestData.createDocument(systemTestFixture.documentCnpj, CHICO_CNPJ);
        BusinessAddress businessAddress = PlayerTestData.createBusinessAddress(systemTestFixture.matoGrossoDoSul, systemTestFixture.vilaNova, systemTestFixture.brazil);
        BillingAddress billingAddress = PlayerTestData.createBillingAddress(systemTestFixture.matoGrossoDoSul, systemTestFixture.vilaNova, systemTestFixture.brazil);
        chicoBentoSimple = PlayerTestData.createGrower(chicoBentoDocument, billingAddress, businessAddress);
        persist(chicoBentoSimple);
    }

	private void createGrower(SystemTestFixture systemTestFixture) {
		chicoBentoDocument = PlayerTestData.createDocument(systemTestFixture.documentCnpj, CHICO_CNPJ);
		BusinessAddress businessAddress = PlayerTestData.createBusinessAddress(systemTestFixture.matoGrossoDoSul, systemTestFixture.vilaNova, systemTestFixture.brazil);
		BillingAddress billingAddress = PlayerTestData.createBillingAddress(systemTestFixture.matoGrossoDoSul, systemTestFixture.vilaNova, systemTestFixture.brazil);
		chicoBento = PlayerTestData.createGrower(chicoBentoDocument, billingAddress, businessAddress);
		persist(chicoBento);
        AgreementTemplateType agreementTemplateType = new AgreementTemplateType(systemTestFixture.soy, systemTestFixture.mons4ntoBr, systemTestFixture.intactaMons4nto, "TEST");
        persist(agreementTemplateType);
        AgreementTemplate agreementTemplate = new AgreementTemplate(systemTestFixture.soy, systemTestFixture.mons4ntoBr, systemTestFixture.intactaMons4nto, agreementTemplateType, "TEST", Boolean.TRUE);
        persist(agreementTemplate);
        // revisar customer.
        Agreement agreement = new Agreement(1l, "comment", Agreement.AgreementStatusEnum.APPROVED, agreementTemplate, chicoBento);
//        Address addr = PlayerTestData.createAddress(systemTestFixture.matoGrossoDoSul, systemTestFixture.vilaNova, systemTestFixture.brazil);
//        Customer cus = createNewCustomer(RandomTestData.createRandomString(5), PlayerTestData.createDocument(systemTestFixture.documentCnpj, "77784236909726"), addr, RandomTestData.createRandomNumberAsString(10));
//        persist(cus);
//        agreement.setCustomer(cus);
        persist(agreement);
        chicoBento.addAgreement(agreement);
        persist(chicoBento);
	}
	
	private void createGrowerJoao(SystemTestFixture systemTestFixture) {
		Document joaoDocument = PlayerTestData.createDocument(systemTestFixture.documentCnpj, JOAO_CNPJ);
		BusinessAddress businessAddress = PlayerTestData.createBusinessAddress(systemTestFixture.matoGrossoDoSul, systemTestFixture.vilaNova, systemTestFixture.brazil);
		BillingAddress billingAddress = PlayerTestData.createBillingAddress(systemTestFixture.matoGrossoDoSul, systemTestFixture.vilaNova, systemTestFixture.brazil);
		joaoDaSilva = PlayerTestData.createGrower(joaoDocument, billingAddress, businessAddress);
		joaoDaSilva.setAlias("JOAO");
		joaoDaSilva.setName("JOAO da SILVA");
		persist(joaoDaSilva);
	}
	
	private void createGrowerJose(SystemTestFixture systemTestFixture) {
		Document joseDocument = PlayerTestData.createDocument(systemTestFixture.documentCnpj, "33344555667768788");
		BusinessAddress businessAddress = PlayerTestData.createBusinessAddress(systemTestFixture.matoGrossoDoSul, systemTestFixture.campinas, systemTestFixture.brazil);
		BillingAddress billingAddress = PlayerTestData.createBillingAddress(systemTestFixture.matoGrossoDoSul, systemTestFixture.campinas, systemTestFixture.brazil);
		joseDaSilva = PlayerTestData.createGrower(joseDocument, billingAddress, businessAddress);
		joseDaSilva.setAlias("JOSE");
		joseDaSilva.setName("JOSE da SILVA");
		persist(joseDaSilva);
	}

	public static final Date createDate(int month, int day) {
		Calendar cal = createNewCalendarDate();
		cal.set(Calendar.MONTH, cal.get(Calendar.MONTH) + month);
		cal.set(Calendar.DAY_OF_MONTH, day);
	
		Date now = cal.getTime();
		return now;
	}

	private static Date createNow() {
		Calendar cal = createNewCalendarDate();
		return cal.getTime();  
	}
	
	private static Date createTomorrow() {
		// Get Calendar object set to the date and time of the given Date object  
		Calendar cal = createNewCalendarDate();
		cal.set(Calendar.HOUR_OF_DAY, 24);
		
		// Put it back in the Date object  
		return cal.getTime();  
	}
	
	private static Date createYesterday() {
		// Get Calendar object set to the date and time of the given Date object  
		Calendar cal = createNewCalendarDate();
		cal.add(Calendar.DATE, -1);
		
		// Put it back in the Date object  
		return cal.getTime();  
	}

	private static Calendar createNewCalendarDate() {
		Calendar cal = Calendar.getInstance();  
		cal.setTime(new Date());  
		
		// Set time fields to zero
		cal.set(Calendar.HOUR_OF_DAY, 0);
		cal.set(Calendar.MINUTE, 0);
		cal.set(Calendar.SECOND, 0);
		cal.set(Calendar.MILLISECOND, 0);
		return cal;
	}

    private SaleTemplate createTemplateSeamlessPricing(SystemTestFixture systemTestFixture) {
        try {
            SaleTemplate template = SaleTemplateTestData.createSaleTemplateTypeSeedSale(harvestSoyMonsanto2012);

            Price seamless = new SeamlessPricing(template, systemTestFixture.intacta);

            DueDatePrice dueDatePrice = new DueDatePrice(seamless);
            dueDatePrice.setPaymentCode("BB99");

            Calendar cal = Calendar.getInstance();

            DueDatePriceItem item1 = new DueDatePriceItem("JUNE");
            item1.setPriceValue(new BigDecimal(1000));
            item1.setDiscountValue(new BigDecimal(100));
            item1.setDueDatePrice(dueDatePrice);

            cal.set(2014, 06, 01);
            item1.setBeginDate(cal.getTime());

            cal.set(2014, 07, 01);
            item1.setEndDate(cal.getTime());

            cal.set(2014, 07, 05);
            item1.setDueDate(cal.getTime());

            List<DueDatePriceItem> items = new ArrayList<DueDatePriceItem>();
            items.add(item1);

            dueDatePrice.setDueDatePriceItems(items);

            seamless.setDueDatePrice(dueDatePrice);
            seamless.addDueDate(new DueDateValue(NOVEMBER));

            template.addPrices(seamless);

            return template;
        } catch (BusinessException e) {
            throw new IllegalStateException("Error creating SaleTemplate during SaleTestFixture", e);
        }
    }

}