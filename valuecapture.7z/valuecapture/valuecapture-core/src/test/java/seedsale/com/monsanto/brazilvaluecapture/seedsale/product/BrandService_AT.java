package com.monsanto.brazilvaluecapture.seedsale.product;

import java.sql.SQLException;
import java.util.List;

import junit.framework.Assert;

import org.hibernate.SessionFactory;
import org.hibernate.classic.Session;
import org.hibernate.exception.ConstraintViolationException;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;

import com.monsanto.brazilvaluecapture.core.base.model.bean.Company;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Country;
import com.monsanto.brazilvaluecapture.core.foundation.model.bean.StatusEnum;
import com.monsanto.brazilvaluecapture.core.foundation.service.BusinessException;
import com.monsanto.brazilvaluecapture.core.foundation.service.EntityAlreadyExistException;
import com.monsanto.brazilvaluecapture.core.foundation.test.AbstractServiceIntegrationTests;
import com.monsanto.brazilvaluecapture.core.foundation.test.dbunit.DbUnitHelper;
import com.monsanto.brazilvaluecapture.seedsale.product.model.bean.Brand;
import com.monsanto.brazilvaluecapture.seedsale.product.model.dao.BrandDAO;
import com.monsanto.brazilvaluecapture.seedsale.product.model.dao.BrandFilter;
import com.monsanto.brazilvaluecapture.seedsale.product.model.dao.impl.BrandDAOImpl;
import com.monsanto.brazilvaluecapture.seedsale.product.service.BrandService;
import com.monsanto.brazilvaluecapture.seedsale.product.service.BrandWithProductUndeletableException;

public class BrandService_AT extends AbstractServiceIntegrationTests {

	private static final Long BRAND_ID_STATUS_NULL = new Long("900000002");
	private static final String BRAND_DESCRIPTION_STATUS_NULL = "BRAND STATUS NULL";
	private static final String BRAND_DESCRIPTION = "BRAND TEST";
	private static final String COUNTRY_CODE = "BRR";
	private static final String COUNTRY_DESCRIPTION = "BRASIL TEST";
	private static final String COMPANY_DESCRIPTION = "COMPANY TEST";
	private static final Long BAND_ID = new Long("900000001");
	private static final Long COMPANY_ID = new Long("900000001");
	private static final Long COUNTRY_ID = new Long("900000001");

	@Autowired
	private BrandService brandService;

	@Before
	public void setup() throws Exception {
		DbUnitHelper.setup("/data/seedsale/product/valid-brand-dataset.xml");		
	}

	@Test
	public void when_i_search_without_status_thanReturn_All() throws Exception {
		
		Brand brand = brandService.selectById(BAND_ID);

		Brand b = new Brand();
		b.setDescription(brand.getDescription());

		Company company = new Company(COMPANY_DESCRIPTION);
		company.setId(COMPANY_ID);

		BrandFilter filter = BrandFilter.getInstance().add(b).add(company);
		List<Brand> brands = brandService.selectByFilter(filter);

		Assert.assertNotNull(brands);
		Assert.assertFalse(brands.isEmpty());
		Assert.assertTrue(brands.size() == 1);

		assertEquals(brand, brands.get(0));
	}

	@Test
	public void when_i_search_with_all_attribute_thanReturn_All() throws BusinessException {

		Country country = new Country(COUNTRY_DESCRIPTION, COUNTRY_CODE);
		country.setId(COUNTRY_ID);

		Company company = new Company();
		company.setId(COMPANY_ID);
		company.setDescription(COMPANY_DESCRIPTION);
		company.setCountry(country);

		Brand brand = new Brand(BRAND_DESCRIPTION, company, StatusEnum.ACTIVE);
		brand.setId(BAND_ID);

		BrandFilter filter = BrandFilter.getInstance().add(brand).add(company);
		List<Brand> brands = brandService.selectByFilter(filter);

		Assert.assertNotNull(brands);
		Assert.assertFalse(brands.isEmpty());
		Assert.assertTrue(brands.size() == 1);

		assertEquals(brand, brands.get(0));
	}

	@Test
	public void when_i_search_without_description_thanReturn_All() throws BusinessException {

		Company company = new Company();
		company.setId(COMPANY_ID);

		BrandFilter filter = BrandFilter.getInstance().add(new Brand()).add(company);
		List<Brand> brands = brandService.selectByFilter(filter);

		Assert.assertNotNull(brands);
		Assert.assertFalse(brands.isEmpty());
		Assert.assertTrue("Brand count expected: 1 but was: " + brands.size(), brands.size() == 1);
	}

	@Test
	public void when_i_search_by_id_thanReturn_theone() throws BusinessException {

		Brand brand = brandService.selectById(BAND_ID);

		Country country = new Country(COUNTRY_DESCRIPTION, COUNTRY_CODE);
		country.setId(COUNTRY_ID);

		Company company = new Company();
		company.setId(COMPANY_ID);
		company.setDescription(COMPANY_DESCRIPTION);
		company.setCountry(country);

		Brand brandExpected = new Brand(BRAND_DESCRIPTION, company, StatusEnum.ACTIVE);
		brandExpected.setId(BAND_ID);

		assertEquals(brand, brandExpected);
	}
	
	@Test
	public void test_save_brand() throws BusinessException {

		//Brand brand = brandService.selectById(BAND_ID);

		Company company = (Company) getSession().get(Company.class, 990000003L);
		String description = "Brand to save";
		Brand brand = new Brand(description, company, StatusEnum.ACTIVE);
		Assert.assertNull(brand.getId());
		//saving
		brandService.save(brand);
		//after save , verify id and description
		Assert.assertNotNull(brand.getId());
		Assert.assertEquals(description.toUpperCase(), brand.getDescription());

	}
	
	@Test(expected=ConstraintViolationException.class)
	public void test_delete_throw_constraintViolationException() throws BrandWithProductUndeletableException {
		Brand brand = brandService.selectById(BAND_ID);
		
		SessionFactory sessionFactory =Mockito.mock(SessionFactory.class);
		Session session = Mockito.mock(Session.class);
		Mockito.stub(sessionFactory.getCurrentSession()).toReturn(session);
		ConstraintViolationException exception = new ConstraintViolationException("Exception", new SQLException("MESSAGE"), "FK");
		//Mockito.stub(session.delete(Mockito.any())).toThrow(exception);
		Mockito.doThrow(exception).when(session).delete(Mockito.any());
		BrandDAO dao = new BrandDAOImpl(sessionFactory);
		dao.delete(brand);
		
	}
	
	@Test(expected=BrandWithProductUndeletableException.class)
	public void test_delete_throw_brandWithProductUndeletableException() throws BrandWithProductUndeletableException {
		Brand brand = brandService.selectById(BAND_ID);
		
		SessionFactory sessionFactory =Mockito.mock(SessionFactory.class);
		Session session = Mockito.mock(Session.class);
		Mockito.stub(sessionFactory.getCurrentSession()).toReturn(session);
		ConstraintViolationException exception = new ConstraintViolationException("Exception", new SQLException("FK_PRODUCT_FK_BRAND1_BRAND"), "FK");
		//Mockito.stub(session.delete(Mockito.any())).toThrow(exception);
		Mockito.doThrow(exception).when(session).delete(Mockito.any());
		BrandDAO dao = new BrandDAOImpl(sessionFactory);
		dao.delete(brand);
		
	}
	
	@Test(expected=ConstraintViolationException.class)
	public void test_save_throw_constraintViolationException() throws EntityAlreadyExistException {
		Brand brand = brandService.selectById(BAND_ID);
		
		SessionFactory sessionFactory =Mockito.mock(SessionFactory.class);
		Session session = Mockito.mock(Session.class);
		Mockito.stub(sessionFactory.getCurrentSession()).toReturn(session);
		ConstraintViolationException exception = new ConstraintViolationException("Exception", new SQLException("FK_PRODUCT_FK_BRAND1_BRAND"), "FK");
		//Mockito.stub(session.delete(Mockito.any())).toThrow(exception);
		Mockito.doThrow(exception).when(session).saveOrUpdate(Mockito.any());
		BrandDAO dao = new BrandDAOImpl(sessionFactory);
		dao.save(brand);
		
	}
	
	@Test(expected=EntityAlreadyExistException.class)
	public void test_save_throw_entityAlreadyExistException() throws EntityAlreadyExistException {
		Brand brand = brandService.selectById(BAND_ID);
		
		SessionFactory sessionFactory =Mockito.mock(SessionFactory.class);
		Session session = Mockito.mock(Session.class);
		Mockito.stub(sessionFactory.getCurrentSession()).toReturn(session);
		ConstraintViolationException exception = new ConstraintViolationException("Exception", new SQLException("UQ_BRAND_COMPANY_DESCRIPTION"), "FK");
		Mockito.doThrow(exception).when(session).saveOrUpdate(Mockito.any());
		BrandDAO dao = new BrandDAOImpl(sessionFactory);
		dao.save(brand);
		
	}

	@Test
	public void when_i_delete_by_id_thanReturn_null() throws BusinessException {

		Brand brand = brandService.selectById(BAND_ID);

		brandService.delete(brand);

		Brand deleted = brandService.selectById(BAND_ID);
		Assert.assertNull("no was deleted!", deleted);
	}

	@Test
	public void when_i_search_the_brand_with_status_null() throws Exception {

		Brand brand = brandService.selectById(BRAND_ID_STATUS_NULL);

		Assert.assertEquals(BRAND_DESCRIPTION_STATUS_NULL, brand.getDescription());
		Assert.assertNull(brand.getStatus());
	}

	private void assertEquals(Brand brand, Brand brandBase) {
		Assert.assertEquals(brand.getDescription(), brandBase.getDescription());
		Assert.assertEquals(brand.getCompany(), brandBase.getCompany());
		Assert.assertEquals(brand.getPrimaryKey(), brandBase.getPrimaryKey());
		Assert.assertEquals(brand.getStatus(), brandBase.getStatus());
	}

}
