package com.monsanto.brazilvaluecapture.seedsale.quota.service.impl;

import com.monsanto.brazilvaluecapture.core.base.model.bean.Company;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Crop;
import com.monsanto.brazilvaluecapture.core.base.model.bean.OperationalYear;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Customer;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Technology;
import com.monsanto.brazilvaluecapture.core.customer.model.dao.CustomerDAO;
import com.monsanto.brazilvaluecapture.core.customer.service.CustomerService;
import com.monsanto.brazilvaluecapture.core.foundation.service.BusinessException;
import com.monsanto.brazilvaluecapture.core.foundation.util.ItsFilter;
import com.monsanto.brazilvaluecapture.seedsale.harvest.model.dao.PlantabilityDAO;
import com.monsanto.brazilvaluecapture.seedsale.product.model.bean.Brand;
import com.monsanto.brazilvaluecapture.seedsale.product.model.bean.Product;
import com.monsanto.brazilvaluecapture.seedsale.product.model.dao.ProductDAO;
import com.monsanto.brazilvaluecapture.seedsale.quota.model.bean.Quota;
import com.monsanto.brazilvaluecapture.seedsale.quota.model.dao.QuotaDAO;
import junit.framework.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.mockito.Matchers.*;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class QuotaService_UT {

    @Mock
    private CustomerService customerService;

    @Mock
    private QuotaDAO quotaDAO;

    @Mock
    private ProductDAO productDAO;

    @Mock
    private PlantabilityDAO plantabilityDAO;

    @Mock
    private CustomerDAO customerDAO;

    @Mock
    private Company company;

    @Mock
    private Crop crop;

    @Mock
    private Customer dealerSelected;

    @InjectMocks
    private QuotaServiceImpl quotaService;


    @Before
    public void begin() {
        quotaService = new QuotaServiceImpl();
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void when_product_map_null_search_quota_by_filters() throws BusinessException {
        //@Given
        Technology technology = Mockito.mock(Technology.class);
        Brand brand = Mockito.mock(Brand.class);
        Product productSelected = Mockito.mock(Product.class);
        String productDescription = null;
        when(quotaDAO.getQuotasGroupBy(any(Company.class), any(Crop.class), any(Customer.class),
                any(OperationalYear.class), anyString(), any(Product.class), any(Brand.class),
                any(Technology.class))).thenReturn(new ArrayList<Map>());
        List<Product> productList = new ArrayList<Product>();
        productList.add(Mockito.mock(Product.class));
        when(productDAO.selectByFilter((ItsFilter) anyObject())).thenReturn(productList);
        OperationalYear operationalYear = new OperationalYear("2013");

        //@When
        List<Quota> quotas = quotaService.searchQuotaBy(company, crop, operationalYear, dealerSelected, technology, brand, productSelected, productDescription);

        //@Should
        Assert.assertNotNull(quotas);
    }

    @Test
    public void when_product_map_hasValue_search_quota_by_filters() throws BusinessException {
        //@Given
        Technology technology = Mockito.mock(Technology.class);
        Brand brand = Mockito.mock(Brand.class);
        Product productSelected = Mockito.mock(Product.class);
        String productDescription = "dummy";
        List<Map> mapList = new ArrayList<Map>();
        Map<String, Object> map1 = new HashMap<String, Object>();
        map1.put("productId", 3L);
        mapList.add(map1);
        when(quotaDAO.getQuotasGroupBy(any(Company.class), any(Crop.class), any(Customer.class),
                        any(OperationalYear.class), anyString(), any(Product.class), any(Brand.class),
                        any(Technology.class))).thenReturn(mapList);

        //@When
        List<Quota> quotas = quotaService.searchQuotaBy(company, crop, null, dealerSelected, technology, brand, productSelected, productDescription);

        //@Should
        Assert.assertNotNull(quotas);
    }

    @Test
    public void when_product_map_hasValue_search_quota_by_filters_complete() throws BusinessException {
        //@Given
        OperationalYear operationalYear = new OperationalYear("2013");
        Technology technology = Mockito.mock(Technology.class);
        Brand brand = Mockito.mock(Brand.class);
        Product productSelected = Mockito.mock(Product.class);
        String productDescription = "dummy";
        List<Map> mapList = new ArrayList<Map>();
        Map<String, Object> map1 = new HashMap<String, Object>();
        map1.put("productId", 3L);
        map1.put("multiplierId", 3L);
        map1.put("plantabilityId", 3L);
        mapList.add(map1);
        when(quotaDAO.getQuotasGroupBy(any(Company.class), any(Crop.class), any(Customer.class),
                                any(OperationalYear.class), anyString(), any(Product.class), any(Brand.class),
                                any(Technology.class))).thenReturn(mapList);

        //@When
        List<Quota> quotas = quotaService.searchQuotaBy(company, crop, operationalYear, dealerSelected, technology, brand, productSelected, productDescription);

        //@Should
        Assert.assertNotNull(quotas);
    }

}
