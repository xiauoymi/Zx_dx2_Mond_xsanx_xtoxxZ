package com.monsanto.brazilvaluecapture.seedsale.billing.service;

import org.junit.Assert;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.monsanto.brazilvaluecapture.core.foundation.test.AbstractServiceIntegrationTests;
import com.monsanto.brazilvaluecapture.seedsale.billing.model.dao.BilletTransactionDAO;
import com.monsanto.brazilvaluecapture.seedsale.billing.service.NotPossibleGetTransctionBilletException;

public class BilletTransaction_AT extends AbstractServiceIntegrationTests {

	@Autowired
	@Qualifier("currentBilletTransactionRepository")
	private BilletTransactionDAO billetTransactionDAO; 
	
	@Test
	public void getTransactionId() throws NotPossibleGetTransctionBilletException{
		Long idTrans = billetTransactionDAO.getTransactionId();
		Assert.assertNotNull("id should not be null",idTrans);
	}
}
