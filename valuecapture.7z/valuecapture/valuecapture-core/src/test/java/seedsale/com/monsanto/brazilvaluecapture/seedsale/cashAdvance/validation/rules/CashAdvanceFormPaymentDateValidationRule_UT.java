package com.monsanto.brazilvaluecapture.seedsale.cashAdvance.validation.rules;

import com.monsanto.brazilvaluecapture.core.foundation.validation.ValidationException;
import com.monsanto.brazilvaluecapture.core.presentation.beans.ResourceBundleTestHelper;
import com.monsanto.brazilvaluecapture.seedsale.cashAdvance.model.bean.CashAdvanceSourceOperationType;
import com.monsanto.brazilvaluecapture.seedsale.cashAdvance.model.bean.CashAdvanceTransaction;
import org.junit.Test;

import java.util.Date;

import static org.fest.assertions.Assertions.assertThat;
import static org.fest.assertions.Fail.fail;

public class CashAdvanceFormPaymentDateValidationRule_UT {
    @Test
    public void testValidateThrowsValidationException_WhenSourceTransactionTypeIsFormAndPaymentDateIsNull() {
        CashAdvanceFormPaymentDateValidationRule cashAdvanceFormPaymentDateValidationRule = new CashAdvanceFormPaymentDateValidationRule();
        CashAdvanceTransaction target = new CashAdvanceTransaction();
        target.setSourceOperationType(CashAdvanceSourceOperationType.FORM);

        try {
            cashAdvanceFormPaymentDateValidationRule.validate(target);
            fail("Should throw ValidationException");
        } catch (ValidationException e) {
            assertThat(e).hasMessage("cash.advance.message.payment.date.required");
        }
    }

    @Test
    public void testValidateDoNotThrowsValidationException_WhenSourceTransactionTypeIsFormAndPaymentDateIsNotNull() {
        CashAdvanceFormPaymentDateValidationRule cashAdvanceFormPaymentDateValidationRule = new CashAdvanceFormPaymentDateValidationRule();
        CashAdvanceTransaction target = new CashAdvanceTransaction();
        target.setSourceOperationType(CashAdvanceSourceOperationType.FORM);
        target.setPaymentDate(new Date());

        try {
            cashAdvanceFormPaymentDateValidationRule.validate(target);
        } catch (ValidationException e) {
            fail("Should not throw ValidationException");
        }
    }

    @Test
    public void testValidateWontThrowNullPointerException_WhenTargetIsNull() throws ValidationException {
        CashAdvanceFormPaymentDateValidationRule cashAdvanceFormPaymentDateValidationRule = new CashAdvanceFormPaymentDateValidationRule();

        try {
            cashAdvanceFormPaymentDateValidationRule.validate(null);
        } catch (NullPointerException e) {
            fail("Should not throw validation exception");
        }
    }

    private String[] messages = {"cash.advance.message.payment.date.required"};

    @Test
    public void testI18mMessages_Brazil() throws Exception {
        ResourceBundleTestHelper.assertLanguageStrExistsForBrazil(messages);
    }

    @Test
    public void testI18mMessages_English() throws Exception {
        ResourceBundleTestHelper.assertLanguageStrExistsForUS(messages);
    }
}