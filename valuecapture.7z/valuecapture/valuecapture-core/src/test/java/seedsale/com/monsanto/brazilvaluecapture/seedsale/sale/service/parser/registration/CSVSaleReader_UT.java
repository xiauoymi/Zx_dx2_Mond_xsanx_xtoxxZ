package com.monsanto.brazilvaluecapture.seedsale.sale.service.parser.registration;

import com.monsanto.brazilvaluecapture.core.base.SystemTestFixture;
import com.monsanto.brazilvaluecapture.core.foundation.util.csv.CSVInvalidLayoutException;
import com.monsanto.brazilvaluecapture.core.foundation.util.csv.CSVReadableInvalidException;
import com.monsanto.brazilvaluecapture.core.user.AccessControlTestFixture;
import com.monsanto.brazilvaluecapture.seedsale.sale.SaleTestFixture;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.CsvSale;
import com.monsanto.brazilvaluecapture.seedsale.sale.service.SaleDAO_AT.CsvTestData;
import com.monsanto.brazilvaluecapture.seedsale.sale.service.SaleService;
import junit.framework.Assert;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.io.IOException;
import java.io.InputStream;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.ResourceBundle;

import static org.mockito.Mockito.mock;

public class CSVSaleReader_UT {
    private static final Logger LOGGER = LogManager.getLogger(CSVSaleReader_UT.class);
	
	private AccessControlTestFixture accessControlTestFixture;
	private SystemTestFixture systemTestFixture;
	private SaleService saleServiceMock;
	private Locale localeBR = new Locale("pt", "BR");

	private SaleFileParser fileparser;
	
	private final InputStream CSV_SALE_TEST_EMPTY_FILE_PT_BR_CSV = getClass().getClassLoader().getResourceAsStream("csv/sale_test_empty_file_pt_BR.csv");
	private final InputStream VALID_PT_BR_CSV = getClass().getClassLoader().getResourceAsStream("csv/sale_test_success_layout_pt_BR.csv");
	private final InputStream INVALID_PT_BR_CSV = getClass().getClassLoader().getResourceAsStream("csv/sale_test_invalid_layout_pt_BR.csv");
	private ResourceBundle resourceBundle = ResourceBundle.getBundle("bundle/bundle");

	@Before
	public void setup() {
		systemTestFixture = new SystemTestFixture();
		accessControlTestFixture = new AccessControlTestFixture(systemTestFixture);
		saleServiceMock = mock(SaleService.class);
	}
	
	@After
	public void tearDown() {
		if ( fileparser != null ) {
			LOGGER.info(fileparser.getWarningsAsString(resourceBundle));
		}
	}
	
	@Test
	public void loadCsvToSale_br_with_success() throws IOException, CSVInvalidLayoutException, CSVReadableInvalidException {
		fileparser = new SaleFileParser(VALID_PT_BR_CSV, localeBR, accessControlTestFixture.superUser, saleServiceMock, "testname");
		fileparser.readFile();
		Assert.assertEquals("Should not have warnings", 0, fileparser.getErrorLines());
	}
	
	@Test
	public void given_a_two_csvSales_with_different_document_values_when_groupingSales_then_should_return_two_sales() {
		List<CsvSale> twoCsvSales = createTwoCsvSaleWithDifferentDocuments();
		
		SaleParserBuilder<CsvSale> builder = new DirectSaleParserBuilder();
		builder.setCsvSalesToProcess(twoCsvSales);
		builder.groupingSales();
		
		Assert.assertEquals("Should have two sales", 2, builder.countCandidateSales());
	}
	
	@Test
	public void given_a_two_csvSales_with_same_document_values_when_groupingSales_then_should_return_one_sale() {
		List<CsvSale> twoCsvSales = createTwoCsvSaleWithSameDocuments();
		
		SaleParserBuilder<CsvSale> builder = new DirectSaleParserBuilder();
		builder.setCsvSalesToProcess(twoCsvSales);
		builder.groupingSales();
		
		Assert.assertEquals("Should have one sale", 1, builder.countCandidateSales());
	}
	
	private List<CsvSale> createTwoCsvSales() {
		CsvSale aCsvSale = CsvTestData.createSaleCsv();
		CsvSale anotherCsvSale = CsvTestData.createSaleCsv();
		anotherCsvSale.setInvoiceNumber(aCsvSale.getInvoiceNumber());
		
		return Arrays.asList(new CsvSale[] {aCsvSale, anotherCsvSale});
	}

	private List<CsvSale> createTwoCsvSaleWithDifferentDocuments() {
		List<CsvSale> csvSales = createTwoCsvSales();
		
		csvSales.get(0).setCustomerDocument(SaleTestFixture.THE_CARGIL_CNPJ);
		csvSales.get(1).setCustomerDocument(SaleTestFixture.THE_AGROESTE_CNPJ);
		
		return csvSales;
	}
	
	private List<CsvSale> createTwoCsvSaleWithSameDocuments() {
		List<CsvSale> csvSales = createTwoCsvSales();
		
		csvSales.get(0).setCustomerDocument(SaleTestFixture.THE_CARGIL_CNPJ);
		csvSales.get(1).setCustomerDocument(SaleTestFixture.THE_CARGIL_CNPJ);
		
		return csvSales;
	}

}
