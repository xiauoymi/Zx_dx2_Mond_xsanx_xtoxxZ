package com.monsanto.brazilvaluecapture.seedsale.sale.service;

import static org.fest.assertions.Assertions.assertThat;
import static org.mockito.Mockito.mock;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;

import com.monsanto.brazilvaluecapture.core.base.model.bean.Company;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Technology;
import com.monsanto.brazilvaluecapture.seedsale.billing.model.bean.Billing;
import com.monsanto.brazilvaluecapture.seedsale.billing.model.bean.PaymentStatus;
import com.monsanto.brazilvaluecapture.seedsale.billing.model.bean.Royalty;

public class DetailedSale_UT {
	List<Billing> listBilling;
	Billing billing1;
	Billing billing2;
	DetailedSale detailedSale;
	
	@Before
	public void setUp(){
		listBilling = new ArrayList<Billing>();
		billing1 = new Billing();
		this.initalizateBilling(billing1);
		billing2 = new Billing();
		this.initalizateBilling(billing2);
	}
	
	@Test
	public void testCompaniesDisableForCancelNotPaidSaleOrderForParcialPaidBilling() {
		listBilling.clear();
		Company c1 = getCompany(billing1);
		
		// @Given a list with a parcial paid billing and not paid status
		billing1.setPaymentStatus(PaymentStatus.PARCIAL_PAID);
		listBilling.add(billing1);
		detailedSale = new DetailedSale();
		
		// @When validate which of those billings are able to cancelate an sale order
		List<Company> listUnvaibleCancelCompanies = detailedSale.getCompaniesThatCancelationOfBillingIsUnavailable(listBilling, PaymentStatus.NOT_PAID);
		
		// @Then get a list of Company how cannot cancel an sale order 
		assertThat(listUnvaibleCancelCompanies).contains(c1);		
	}

	@Test
	public void testCompaniesDisableForCancelNotPaidSaleOrderForFullyPaidBilling() {
		listBilling.clear();
		Company c1 = getCompany(billing1);
		
		// @Given a list with a fully paid billing and not paid status
		billing1.setPaymentStatus(PaymentStatus.FULLY_PAID);
		listBilling.add(billing1);
		detailedSale = new DetailedSale();
		
		// @When validate which of those billings are able to cancelate an sale order
		List<Company> listUnvaibleCancelCompanies = detailedSale.getCompaniesThatCancelationOfBillingIsUnavailable(listBilling, PaymentStatus.NOT_PAID);
		
		// @Then get a list of Company how cannot cancel an sale order 
		assertThat(listUnvaibleCancelCompanies).contains(c1);		
	}
	
	@Test
	public void testCompaniesDisableForCancelNotPaidSaleOrderForFullyOrParcialPaidBilling() {
		listBilling.clear();
		Company c1 = getCompany(billing1);
		Company c2 = getCompany(billing2);
		
		// @Given paid billing list and not paid status
		billing1.setPaymentStatus(PaymentStatus.PARCIAL_PAID);
		billing2.setPaymentStatus(PaymentStatus.FULLY_PAID);
		listBilling.add(billing1);
		listBilling.add(billing2);
		detailedSale = new DetailedSale();
		
		// @When validate which of those billings are able to cancelate an sale order
		List<Company> listUnvaibleCancelCompanies = detailedSale.getCompaniesThatCancelationOfBillingIsUnavailable(listBilling, PaymentStatus.NOT_PAID);
		
		// @Then get a list of Company how cannot cancel an sale order 
		assertThat(listUnvaibleCancelCompanies).contains(c1,c2);		
	}
	
	@Test
	public void testCompaniesDisableForCancelNotPaidSaleOrderForNotPaidOrFullyOrParcialPaidBilling() {
		listBilling.clear();
		Company c1 = getCompany(billing1);
		
		// @Given a list with a parcial paidm fully paid y not paid billings and not paid status
		billing1.setPaymentStatus(PaymentStatus.NOT_PAID);
		listBilling.add(billing1);
		detailedSale = new DetailedSale();
		
		// @When validate which of those billings are able to cancelate an sale order
		List<Company> listUnvaibleCancelCompanies = detailedSale.getCompaniesThatCancelationOfBillingIsUnavailable(listBilling, PaymentStatus.NOT_PAID);
		
		//@Then get a list of Company how can cancel an sale order
		assertThat(listUnvaibleCancelCompanies).excludes(c1);
	}
	
	
	@Test
	public void testCompaniesDisableForCancelNotPaidSaleOrderForNoValueBilling() {
		listBilling.clear();
		
		// @Given a list with a not value billing and not paid status
		billing1.setPaymentStatus(PaymentStatus.NO_VALUE);
		listBilling.add(billing1);
		detailedSale = new DetailedSale();
		
		// @When validate which of those billings are able to cancelate an sale order
		List<Company> listUnvaibleCancelCompanies = detailedSale.getCompaniesThatCancelationOfBillingIsUnavailable(listBilling, PaymentStatus.NOT_PAID);
		
		// @Then get a list of Company how cannot cancel an sale order 
		assertThat(listUnvaibleCancelCompanies).isEmpty();
	}
	
	@Test
	public void testCompaniesDisableForCancelPaidSaleOrdersForNotPaidBilling() {
		listBilling.clear();
		Company c1 = getCompany(billing1);
		
		// @Given a list with a not paid billing and fully paid status
		billing1.setPaymentStatus(PaymentStatus.NOT_PAID);
		listBilling.add(billing1);
		detailedSale = new DetailedSale();
		
		// @When validate which of those billings are able to cancelate an sale order
		List<Company> listUnvaibleCancelCompanies = detailedSale.getCompaniesThatCancelationOfBillingIsUnavailable(listBilling, PaymentStatus.FULLY_PAID);

		// @Then get a list of Company how cannot cancel an sale order 
		assertThat(listUnvaibleCancelCompanies).contains(c1);	
		
	}
	
	@Test
	public void testCompaniesDisableForCancelPaidSaleOrdersForParcialPaidBilling() {
		listBilling.clear();
		Company c1 = getCompany(billing1);
		
		// @Given a list with a parcial paid billing and fully paid status
		billing1.setPaymentStatus(PaymentStatus.PARCIAL_PAID);
		listBilling.add(billing1);
		detailedSale = new DetailedSale();
		
		// @When validate which of those billings are able to cancelate an sale order
		List<Company> listUnvaibleCancelCompanies = detailedSale.getCompaniesThatCancelationOfBillingIsUnavailable(listBilling, PaymentStatus.FULLY_PAID);

		// @Then get a list of Company how cannot cancel an sale order 
		assertThat(listUnvaibleCancelCompanies).contains(c1);	
		
	}
	
	@Test
	public void testCompaniesDisableForCancelPaidSaleOrdersForNotPaidAndParcialPaidBilling() {
		listBilling.clear();
		Company c1 = getCompany(billing1);
		Company c2 = getCompany(billing2);
		
		// @Given not fully paid billing list and fully paid status
		billing1.setPaymentStatus(PaymentStatus.PARCIAL_PAID);
		billing2.setPaymentStatus(PaymentStatus.NOT_PAID);
		listBilling.add(billing1);
		listBilling.add(billing2);
		detailedSale = new DetailedSale();
		
		// @When validate which of those billings are able to cancelate an sale order
		List<Company> listUnvaibleCancelCompanies = detailedSale.getCompaniesThatCancelationOfBillingIsUnavailable(listBilling, PaymentStatus.FULLY_PAID);

		// @Then get a list of Company how cannot cancel an sale order 
		assertThat(listUnvaibleCancelCompanies).contains(c1,c2);	
		
	}
	
	@Test
	public void testCompaniesDisableForCancelPaidSaleOrderForNoValueBilling() {
		listBilling.clear();
		Company c1 = getCompany(billing1);
		
		// @Given a list with a not value billing and not paid status
		billing1.setPaymentStatus(PaymentStatus.NO_VALUE);
		listBilling.add(billing1);
		detailedSale = new DetailedSale();
		
		// @When validate which of those billings are able to cancelate an sale order
		List<Company> listUnvaibleCancelCompanies = detailedSale.getCompaniesThatCancelationOfBillingIsUnavailable(listBilling, PaymentStatus.FULLY_PAID);
		
		// @Then get a list of Company how cannot cancel an sale order 
		assertThat(listUnvaibleCancelCompanies).contains(c1);
	}
	
	private Company getCompany(Billing b) {
		Company c1 = null;
		for (Royalty royalty : b.getRoyalties()) {
			c1 = royalty.getTechnology().getCompany();
		}
		return c1;
	}
	
	private void initalizateBilling(Billing billing){
		Technology t =new Technology();
		Company c = mock(Company.class);
		t.setCompany(c);
		Royalty r = new Royalty();
		r.setTechnology(t);
		billing.getRoyalties().add(r);
	}

}
