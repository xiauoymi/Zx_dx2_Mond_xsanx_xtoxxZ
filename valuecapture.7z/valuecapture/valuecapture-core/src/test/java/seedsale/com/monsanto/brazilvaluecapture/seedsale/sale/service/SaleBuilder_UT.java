package com.monsanto.brazilvaluecapture.seedsale.sale.service;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.stub;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Matchers;

import com.monsanto.brazilvaluecapture.core.base.SystemTestFixture;
import com.monsanto.brazilvaluecapture.seedsale.harvest.model.bean.Plantability;
import com.monsanto.brazilvaluecapture.seedsale.sale.SaleTestFixture;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.Sale;
import com.monsanto.brazilvaluecapture.seedsale.template.model.bean.Price;

public class SaleBuilder_UT {

	private SystemTestFixture systemTF;
	private SaleTestFixture saleTF;
	private PlantabilitiesSelector plantabilitySelector;

	private SaleBuilder builder;

	@Before
	public void init() {
		systemTF = new SystemTestFixture();
		saleTF = new SaleTestFixture(systemTF);
		plantabilitySelector = mock(PlantabilitiesSelector.class);
		stub(plantabilitySelector.getPlantabilityByPriceType(Matchers.any(Price.class))).toReturn(saleTF.plantabilitySystemSoyMonsanto2012);
		stub(plantabilitySelector.getCompletePlantability(Matchers.any(Plantability.class), Matchers.any(Price.class))).toReturn(null);

		builder = new SaleBuilder(systemTF.matoGrossoDoSul, plantabilitySelector);
	}
	
	@Test(expected=IllegalArgumentException.class)
	public void given_an_empty_saleBuilder_when_build_then_should_trhow_illegalStateException() {
		builder.buildSale();
		Assert.fail("Empty build should throw exception");
	}
	
	@Test(expected=IllegalArgumentException.class)
	public void given_a_saleBuilder_when_add_grower_and_build_then_should_trhow_illegalStateException() {
		builder.setGrower(saleTF.chicoBento).buildSale();
		Assert.fail("Builder should throw exception");
	}
	
	@Test(expected=IllegalArgumentException.class)
	public void given_a_saleBuilder_when_add_grower_add_distributor_and_build_then_should_trhow_illegalStateException() {
		builder.setGrower(saleTF.chicoBento).setCustomer(saleTF.headOfficeCargil.getCustomer()).buildSale();
		Assert.fail("Builder should throw exception");
	}
	
	@Test
	public void given_a_saleBuilder_when_add_grower_add_distributor_add_saleItem_and_build_then_should_return_success() {
		builder.addSaleItem(saleTF.productRRSoy, saleTF.templateIntactaNoValueRRNoValue, saleTF.headOfficeAffiliate, SaleTestFixture.TWO_POINT_FIVE_DOLLARS.longValue(), null, null, null);
		Sale sale = builder.setGrower(saleTF.chicoBento).setCustomer(saleTF.headOfficeCargil.getCustomer()).buildSale();
		Assert.assertNotNull("Created sale should not be null", sale);
		Assert.assertEquals("Sale should have one item", 1, sale.getItems().size());
	}
	
	@Test(expected=IllegalStateException.class)
	public void given_a_saleBuilder_when_add_item_for_sale_and_build_licenseSeed_then_should_throw_exception() {
		builder.addSaleItem(saleTF.productRRSoy, saleTF.templateIntactaNoValueRRNoValue, saleTF.headOfficeAffiliate, SaleTestFixture.TWO_POINT_FIVE_DOLLARS.longValue(), null, null, null);
		builder.setGrower(saleTF.chicoBento).setCustomer(saleTF.headOfficeCargil.getCustomer()).buildLicenseSeed();
		Assert.fail("Builder should throw exception");
	}
}