package com.monsanto.brazilvaluecapture.seedsale.billing.parser;

import java.util.Date;
import java.util.GregorianCalendar;
import java.util.ResourceBundle;

import junit.framework.Assert;

import org.junit.Test;

import com.monsanto.brazilvaluecapture.core.io.ImportedException;
import com.monsanto.brazilvaluecapture.core.io.WarningImportedException;
import com.monsanto.brazilvaluecapture.seedsale.billing.service.parser.CnabImportedLine;
import com.monsanto.brazilvaluecapture.seedsale.billing.service.parser.CnabLexicalAnalyzer;
import com.monsanto.brazilvaluecapture.seedsale.billing.service.parser.CnabParserAnalyzer;
import com.monsanto.brazilvaluecapture.seedsale.billing.service.parser.CnabSemanticAnalyzer;

public class ImportedFileException_UT {

	private static final String DEFAULT_MESSAGE_FOR_EXCEPTION = "Exception for unit test";
	
	private ResourceBundle resourceBundle = ResourceBundle.getBundle("bundle/bundle");

	@Test
	public void testing_formattedMessage_of_lexicalImportedException() {
		ImportedException ex = new WarningImportedException(DEFAULT_MESSAGE_FOR_EXCEPTION, 333);
		ex.add(CnabLexicalAnalyzer.CNAB_LEXICAL_ERROR_BUNDLE_KEY);
		
		String formattedMessage = ex.getFormattedMessage(resourceBundle);
		String message = ex.getMessage();
		
		assertExceptionMessages("Line 333: Invalid cnab line. Should have 400 characteres", formattedMessage, message);
	}

	@Test
	public void testing_formattedMessage_of_parseImportedException_on_case_of_billing_not_found_error_only() {
		ImportedException ex = new WarningImportedException(DEFAULT_MESSAGE_FOR_EXCEPTION, new CnabImportedLine("ABC", false, false, 231));
		ex.add(CnabParserAnalyzer.CNAB_PARSE_ERROR_TRANSACTION_NOTFOUND_BUNDLE_KEY, "12345678");
		
		String formattedMessage = ex.getFormattedMessage(resourceBundle);
		String message = ex.getMessage();
		
		assertExceptionMessages("Line 231: Billing with nosso-numero=12345678 not found.", formattedMessage, message);
	}
	
	@Test
	public void testing_formattedMessage_of_parseImportedException_on_case_of_date_and_value_wrongs() {
		ImportedException ex = new WarningImportedException(DEFAULT_MESSAGE_FOR_EXCEPTION, new CnabImportedLine("ABC", false, false, 231));
		ex.add(CnabParserAnalyzer.CNAB_PARSE_ERROR_DATE_INVALID_BUNDLE_KEY, "12345678");
		ex.add(CnabParserAnalyzer.CNAB_PARSE_ERROR_VALUE_INVALID_BUNDLE_KEY, "ascv");
		
		String formattedMessage = ex.getFormattedMessage(resourceBundle);
		String message = ex.getMessage();
		
		assertExceptionMessages("Line 231: invalid payment date (12345678); invalid payment value (ascv)", formattedMessage, message);
	}
	
	
	@Test
	public void testing_formattedMessage_of_overduePayment() {
		ImportedException ex = new WarningImportedException(DEFAULT_MESSAGE_FOR_EXCEPTION, new CnabImportedLine("ABC", false, false, 231));
		GregorianCalendar gregorianCalendar = new GregorianCalendar();
		//month starts at 0, example 0 - january, 11 - december
		gregorianCalendar.set(2012, 11, 30);
		Date now = gregorianCalendar.getTime();
		ex.add(CnabSemanticAnalyzer.CNAB_BILLING_IS_OVERDUE_ERROR_BUNDLE_KEY, now, now);
		
		String formattedMessage = ex.getFormattedMessage(resourceBundle);
		String message = ex.getMessage();
		
		assertExceptionMessages("Line 231: Billing due date was 30/12/2012 and was paid 30/12/2012.", formattedMessage, message);
	}
	
	private void assertExceptionMessages(String expectedFormattedMessage, String actualFormattedMessage, String actualMessage) {
		Assert.assertEquals("Formatted message is wrong", expectedFormattedMessage, actualFormattedMessage);
		Assert.assertEquals("Message exception is wrong", DEFAULT_MESSAGE_FOR_EXCEPTION, actualMessage);
	}
	
}
