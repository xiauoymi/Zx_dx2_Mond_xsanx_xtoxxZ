package com.monsanto.brazilvaluecapture.seedsale.product;

import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import junit.framework.Assert;

import org.hibernate.exception.ConstraintViolationException;
import org.junit.Test;

import com.monsanto.brazilvaluecapture.core.foundation.model.bean.StatusEnum;
import com.monsanto.brazilvaluecapture.core.foundation.service.BusinessException;
import com.monsanto.brazilvaluecapture.core.grower.CreateTestData;
import com.monsanto.brazilvaluecapture.seedsale.harvest.HarvestTestData;
import com.monsanto.brazilvaluecapture.seedsale.harvest.model.bean.Harvest;
import com.monsanto.brazilvaluecapture.seedsale.harvest.model.bean.Plantability;
import com.monsanto.brazilvaluecapture.seedsale.harvest.model.dao.PlantabilityDAO;
import com.monsanto.brazilvaluecapture.seedsale.harvest.service.impl.PlantabilityServiceImpl;

public class PlantablityServiceImpl_UT extends CreateTestData{

	@Test
	public void createPlantabilityTest () throws BusinessException {
		PlantabilityDAO dao = mock(PlantabilityDAO.class);
		
		PlantabilityServiceImpl service = new PlantabilityServiceImpl();
		
		service.setPlantabilityDAO(dao);
		Harvest harvest = createBasicHarvest(StatusEnum.ACTIVE);
		
		Plantability plantability = PlantabilityTestData.createPlantability(harvest);
		
		doNothing().when(dao).save(plantability);

		service.save(plantability);

		verify(dao).save(plantability);
	}
	
	@Test(expected = BusinessException.class)
	public void testUpdateException() throws BusinessException {
		
		PlantabilityDAO mockDAO = mock(PlantabilityDAO.class);
		Harvest harvest = createBasicHarvest(StatusEnum.ACTIVE);

		Plantability plantability = PlantabilityTestData.createPlantability(harvest);
		
		List<Plantability> plantabilities = new ArrayList<Plantability>();
		plantabilities.add(plantability);
		
		when(mockDAO.selectAllPlantabilityEquals(plantability)).thenReturn(plantabilities);
		
		doNothing().when(mockDAO).save(plantability);

		PlantabilityServiceImpl service = new PlantabilityServiceImpl();
		
		service.setPlantabilityDAO(mockDAO);

		service.save(plantability);

		verify(mockDAO).save(plantability);

	}
	
	@Test(expected=ConstraintViolationException.class)
	public void deletePlantabilityExceptionTest () throws BusinessException {
		PlantabilityDAO dao = mock(PlantabilityDAO.class);
		
		PlantabilityServiceImpl service = new PlantabilityServiceImpl();
		
		service.setPlantabilityDAO(dao);
		Harvest harvest = createBasicHarvest(StatusEnum.ACTIVE);
		
		Plantability plantability = PlantabilityTestData.createPlantability(harvest);
 		
		doNothing().when(dao).save(plantability);

		service.save(plantability);

		verify(dao).save(plantability);
		
		ConstraintViolationException mockException = mock(ConstraintViolationException.class);

		doThrow(mockException).when(dao).delete(plantability);

		service.delete(plantability);

		Assert.fail();
	}
	
	@Test
	public void deletePlantabilityTest () throws BusinessException {
		PlantabilityDAO dao = mock(PlantabilityDAO.class);
		
		PlantabilityServiceImpl service = new PlantabilityServiceImpl();
		
		service.setPlantabilityDAO(dao);
		Harvest harvest = createBasicHarvest(StatusEnum.ACTIVE);
		
		Plantability plantability = PlantabilityTestData.createPlantability(harvest);
 		
		doNothing().when(dao).save(plantability);

		service.save(plantability);

		verify(dao).save(plantability);
		
		Long id = plantability.getPrimaryKey();

		doNothing().when(dao).delete(plantability);

		service.delete(plantability);

		verify(dao).delete(plantability);
		
		when(dao.selectById(id)).thenReturn(null);
		
		Plantability plantabilityBase = service.selectById(id);
		
		Assert.assertNull(plantabilityBase);
	}
	
	@Test
	public void selectPlantabilityByFilterTest () {
		PlantabilityDAO dao = mock(PlantabilityDAO.class);
		
		PlantabilityServiceImpl service = new PlantabilityServiceImpl();
		
		service.setPlantabilityDAO(dao);
		Harvest harvest = createBasicHarvest(StatusEnum.ACTIVE);
		
		Plantability plantability = PlantabilityTestData.createPlantability(harvest);
		
		List<Plantability> plantabilities = createSomePlantability(createBasicHarvest(StatusEnum.ACTIVE));
		
		when(dao.selectByFilter(plantability)).thenReturn(plantabilities);
		
		List<Plantability> plantabilitiesBase = service.selectByFilter(plantability);
		
		Assert.assertEquals(plantabilities, plantabilitiesBase);
	}
	
	@Test
	public void selectPlantabilityByHarvest () {
		PlantabilityDAO dao = mock(PlantabilityDAO.class);

		PlantabilityServiceImpl service = new PlantabilityServiceImpl();
		service.setPlantabilityDAO(dao);
		
		Harvest itemHarvest = HarvestTestData.createABrazilianHarvest();
		
		List<Plantability> listResults = createSomePlantability(itemHarvest);

		Assert.assertNotNull(itemHarvest.getCompleteDescription());
		
		when(dao.selectByHarvest(itemHarvest)).thenReturn(listResults);
		
		// And execute search
		List<Plantability> list = service.selectByHarvest(itemHarvest);

		// Then result is not null
		Assert.assertNotNull(list);
	}
}
