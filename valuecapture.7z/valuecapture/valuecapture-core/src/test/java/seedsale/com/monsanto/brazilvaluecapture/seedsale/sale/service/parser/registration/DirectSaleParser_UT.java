package com.monsanto.brazilvaluecapture.seedsale.sale.service.parser.registration;

import com.monsanto.brazilvaluecapture.core.base.model.bean.OperationalYear;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Customer;
import com.monsanto.brazilvaluecapture.core.foundation.util.ErrorCode;
import com.monsanto.brazilvaluecapture.core.foundation.util.csv.CSVReadableInvalidException;
import com.monsanto.brazilvaluecapture.core.grower.model.bean.Grower;
import com.monsanto.brazilvaluecapture.core.user.model.bean.ItsUser;
import com.monsanto.brazilvaluecapture.core.user.model.bean.UserDecorator;
import com.monsanto.brazilvaluecapture.seedsale.product.model.bean.Product;
import com.monsanto.brazilvaluecapture.seedsale.quota.model.bean.Quota;
import com.monsanto.brazilvaluecapture.seedsale.quota.model.bean.QuotaType;
import com.monsanto.brazilvaluecapture.seedsale.quota.service.InsufficientBalanceQuotaException;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.Sale;
import com.monsanto.brazilvaluecapture.seedsale.sale.service.SaleConstraintViolationException;
import com.monsanto.brazilvaluecapture.seedsale.sale.service.SaleService;
import junit.framework.Assert;
import org.junit.Test;
import org.mockito.Mockito;
import org.mockito.internal.verification.VerificationModeFactory;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.ResourceBundle;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class DirectSaleParser_UT {

    private ResourceBundle resourceBundle = ResourceBundle.getBundle("bundle/bundle");

    @Test
    public void test_read_file() throws CSVReadableInvalidException {

        SaleService saleService = Mockito.mock(SaleService.class);
        UserDecorator userDecorator = Mockito.mock(UserDecorator.class);

        DirectSaleParser saleParser = new DirectSaleParser(userDecorator, saleService);
        saleParser.readFile();

    }

    @Test
    public void test_process_without_correct_sale() throws SaleConstraintViolationException {

        SaleService saleService = Mockito.mock(SaleService.class);
        UserDecorator userDecorator = Mockito.mock(UserDecorator.class);

        DirectSaleParser saleParser = new DirectSaleParser(userDecorator, saleService);

        saleParser.process();

        // Verify if csv save service wasn't invoked
        Mockito.verify(saleService, VerificationModeFactory.atLeast(0)).saveCsv((Sale) Mockito.anyObject(),
                (UserDecorator) Mockito.anyObject());

    }

    @Test
    public void test_process() throws SaleConstraintViolationException {

        SaleService saleService = Mockito.mock(SaleService.class);
        UserDecorator userDecorator = getUserDecorator();

        DirectSaleParser saleParser = new DirectSaleParser(userDecorator, saleService);
        saleParser.setSaleParserResult(new SaleParserResult());
        saleParser.getSaleParserResult().addCorrectSale(new Sale(new Customer(), new Grower()));

        saleParser.process();

        // Verify if csv save service was invoked exactly one time
        Mockito.verify(saleService, VerificationModeFactory.times(1)).saveCsv((Sale) Mockito.anyObject(),
                (UserDecorator) Mockito.anyObject());

    }

    private UserDecorator getUserDecorator() {
        UserDecorator userDecorator = Mockito.mock(UserDecorator.class);
        ItsUser user = mock(ItsUser.class);
        when(user.getLogin()).thenReturn("USERLOGIN");
        when(userDecorator.getLocalUser()).thenReturn(user);
        return userDecorator;
    }

    @Test
    public void test_process_with_insuficient_balance_quota() throws SaleConstraintViolationException {

        SaleService saleService = Mockito.mock(SaleService.class);
        UserDecorator userDecorator = getUserDecorator();

        DirectSaleParser saleParser = new DirectSaleParser(userDecorator, saleService);
        saleParser.setSaleParserResult(new SaleParserResult());
        saleParser.getSaleParserResult().addCorrectSale(new Sale(new Customer(), new Grower()));

        Quota quota = new Quota(new OperationalYear("2010"), new Customer(), new Product(), QuotaType.AVAILABLE);
        InsufficientBalanceQuotaException qe = new InsufficientBalanceQuotaException("insuficiente quota balance!",
                new BigDecimal("1000000"), quota);

        Mockito.doThrow(qe).when(saleService).saveCsv((Sale) Mockito.anyObject(), (UserDecorator) Mockito.anyObject());

        Assert.assertEquals(0, saleParser.getErrorLines());
        saleParser.process();
        Assert.assertEquals(1, saleParser.getErrorLines());

    }

    @Test
    public void test_process_with_sale_constraint() throws SaleConstraintViolationException {

        SaleService saleService = Mockito.mock(SaleService.class);
        UserDecorator userDecorator = getUserDecorator();

        DirectSaleParser saleParser = new DirectSaleParser(userDecorator, saleService);
        saleParser.setSaleParserResult(new SaleParserResult());
        saleParser.getSaleParserResult().addCorrectSale(new Sale(new Customer(), new Grower()));

        SaleConstraintViolationException exception = new SaleConstraintViolationException("error!");
        exception.add("Customer not found.", ErrorCode.NOT_FOUND_CODE, "sale-record.distributorDocument.label",
                new ArrayList<Integer>());

        Mockito.doThrow(exception).when(saleService)
                .saveCsv((Sale) Mockito.anyObject(), (UserDecorator) Mockito.anyObject());

        Assert.assertEquals(0, saleParser.getErrorLines());
        saleParser.process();
        Assert.assertEquals(1, saleParser.getErrorLines());

    }

    @Test
    public void sanity_sale_parser_test() {

        SaleService saleService = Mockito.mock(SaleService.class);
        UserDecorator userDecorator = Mockito.mock(UserDecorator.class);

        DirectSaleParser saleParser = new DirectSaleParser(userDecorator, saleService);
        saleParser.setSaleParserResult(new SaleParserResult());
        saleParser.getSaleParserResult().addCorrectSale(new Sale(new Customer(), new Grower()));

        Assert.assertFalse(saleParser.hasError("xxxxxxxxxxxxx"));
        Assert.assertTrue(saleParser.hasSuccess());
        Assert.assertNotNull(saleParser.getResolver());
        Assert.assertEquals(1, saleParser.getSuccessLines());
        Assert.assertEquals("", saleParser.getWarningsAsString(resourceBundle));
        Assert.assertEquals(0, saleParser.countCandidateSales());
        Assert.assertEquals(0, saleParser.countOccurrenceOfError("", true));
        Assert.assertEquals("import.sale.result.success.sales", saleParser.getSuccessBundleMessage());
        Assert.assertEquals("import.result.error.sales", saleParser.getErrorBundleMessage());
        Assert.assertTrue(saleParser.isLinesToProcess());

    }
}
