package com.monsanto.brazilvaluecapture.seedsale.sale.service.impl;

import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import com.monsanto.brazilvaluecapture.core.account.model.bean.Account;
import com.monsanto.brazilvaluecapture.core.account.model.bean.Entry;
import com.monsanto.brazilvaluecapture.core.account.model.bean.Transaction;
import com.monsanto.brazilvaluecapture.core.account.service.impl.AccountService;
import com.monsanto.brazilvaluecapture.core.base.model.bean.*;
import com.monsanto.brazilvaluecapture.core.base.service.BaseService;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Customer;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.HeadOffice;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.ParticipantTypeEnum;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Technology;
import com.monsanto.brazilvaluecapture.core.customer.model.dao.CustomerDAO;
import com.monsanto.brazilvaluecapture.core.customer.service.CustomerNotAllowedException;
import com.monsanto.brazilvaluecapture.core.customer.service.CustomerNotFoundException;
import com.monsanto.brazilvaluecapture.core.debt.dao.DebtDAO;
import com.monsanto.brazilvaluecapture.core.foundation.model.bean.*;
import com.monsanto.brazilvaluecapture.core.foundation.model.dao.SystemParameterDAO;
import com.monsanto.brazilvaluecapture.core.foundation.service.EntityNotFoundException;
import com.monsanto.brazilvaluecapture.core.foundation.service.MBusinessException;
import com.monsanto.brazilvaluecapture.core.foundation.service.SystemParameterService;
import com.monsanto.brazilvaluecapture.core.foundation.util.ItsFilter;
import com.monsanto.brazilvaluecapture.core.grower.model.bean.*;
import com.monsanto.brazilvaluecapture.core.grower.model.dao.GrowerDAO;
import com.monsanto.brazilvaluecapture.core.grower.service.BonusRulesService;
import com.monsanto.brazilvaluecapture.core.grower.service.GrowerNotFoundException;
import com.monsanto.brazilvaluecapture.core.grower.service.impl.CreateDebtDocumentServiceRunner;
import com.monsanto.brazilvaluecapture.core.grower.service.impl.InformDebtContinentalBankPYServiceRunner;
import com.monsanto.brazilvaluecapture.core.grower.service.impl.UpdateDebtProcessBatchServiceRunner;
import com.monsanto.brazilvaluecapture.core.regionalization.CountriesHolder;
import com.monsanto.brazilvaluecapture.core.regionalization.VCCountry;
import com.monsanto.brazilvaluecapture.core.user.model.bean.ItsUser;
import com.monsanto.brazilvaluecapture.core.user.model.bean.UserDecorator;
import com.monsanto.brazilvaluecapture.core.user.service.DocumentMismatchException;
import com.monsanto.brazilvaluecapture.seedsale.billing.model.bean.Billing;
import com.monsanto.brazilvaluecapture.seedsale.billing.model.bean.CreditStatus;
import com.monsanto.brazilvaluecapture.seedsale.billing.model.bean.PaymentStatus;
import com.monsanto.brazilvaluecapture.seedsale.billing.model.dao.BillingDAO;
import com.monsanto.brazilvaluecapture.seedsale.billing.model.dao.BillingFilter;
import com.monsanto.brazilvaluecapture.seedsale.bonus.BonusService;
import com.monsanto.brazilvaluecapture.seedsale.bonus.bulkimport.model.bean.BonusTransaction;
import com.monsanto.brazilvaluecapture.seedsale.extract.credit.model.bean.SummaryCreditExtract;
import com.monsanto.brazilvaluecapture.seedsale.harvest.model.bean.Harvest;
import com.monsanto.brazilvaluecapture.seedsale.harvest.model.bean.Plantability;
import com.monsanto.brazilvaluecapture.seedsale.harvest.model.bean.PlantabilitySystemEnum;
import com.monsanto.brazilvaluecapture.seedsale.harvest.model.dao.HarvestDAO;
import com.monsanto.brazilvaluecapture.seedsale.harvest.model.dao.PlantabilityDAO;
import com.monsanto.brazilvaluecapture.seedsale.harvest.service.PlantabilityService;
import com.monsanto.brazilvaluecapture.seedsale.product.model.bean.Brand;
import com.monsanto.brazilvaluecapture.seedsale.product.model.bean.Product;
import com.monsanto.brazilvaluecapture.seedsale.product.model.bean.ProductivityByRegion;
import com.monsanto.brazilvaluecapture.seedsale.product.model.bean.Region;
import com.monsanto.brazilvaluecapture.seedsale.product.model.dao.ProductDAO;
import com.monsanto.brazilvaluecapture.seedsale.product.model.dao.ProductFilter;
import com.monsanto.brazilvaluecapture.seedsale.product.service.ProductivityByRegionService;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.Cancellation;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.Sale;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.SaleItem;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.dao.SaleDAO;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.dao.SaleFilter;
import com.monsanto.brazilvaluecapture.seedsale.sale.service.DetailedSale;
import com.monsanto.brazilvaluecapture.seedsale.sale.service.PlantabilitiesSelector;
import com.monsanto.brazilvaluecapture.seedsale.sale.service.SaleConstraintViolationException;
import com.monsanto.brazilvaluecapture.seedsale.sale.service.SaleLinkDetailLinker;
import com.monsanto.brazilvaluecapture.seedsale.sale.validation.SaleValidatorBVC;
import com.monsanto.brazilvaluecapture.seedsale.template.model.bean.SaleTemplate;
import com.monsanto.brazilvaluecapture.seedsale.template.model.bean.SaleTemplateBillingMethodEnum;
import com.monsanto.brazilvaluecapture.seedsale.template.model.bean.SaleTemplateCreditCalculationEnum;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

import java.math.BigDecimal;
import java.util.*;

import static org.fest.assertions.Assertions.assertThat;
import static org.fest.reflect.core.Reflection.field;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

/**
 * User: PPERA
 * Date: 5/13/13
 * Time: 2:56 PM
 */
public class SaleServiceImpl_UT {
    public static final String I_SANTANDERRIO_BANK_DEBT_NOTIF = "I_SANTANDERRIO_BANK_DEBT_NOTIF";
    private SaleServiceImpl saleServiceImpl;
    private SaleDAO saleDao;
    private CountriesHolder countriesHolder;
    private SystemParameterDAO systemParameterDAO;
    private SystemParameterService systemParameterService;
    private DebtDAO debtDAO;
    private CreateDebtDocumentServiceRunner createDebtDocumentServiceRunner;
    private UpdateDebtProcessBatchServiceRunner updateDebtProcessBatchServiceRunner;
    private InformDebtContinentalBankPYServiceRunner informDebtContinentalBankPYServiceRunner;
    private BillingDAO billingDAO;
    private PlantabilityDAO plantabilityDAO;
    private PlantabilityService plantabilityService;
    private ProductivityByRegionService productivityByRegionService;
    private BonusRulesService bonusRulesService;
    private BonusService bonusService;

    private CustomerDAO customerDAO;
    private GrowerDAO growerDAO;
    private HarvestDAO harvestDAO;
    private ProductDAO productDAO;
    private SaleValidatorBVC saleValidatorBVC;
    private SaleValidator saleValidator;
    private BaseService baseService;
    private AccountManager accountManager;
    private SaleLinkDetailLinker saleLinkDetailLinker;

    @Before
    public void setUp() {
        this.saleServiceImpl = new SaleServiceImpl();
        this.saleDao = mock(SaleDAO.class);
        this.countriesHolder = mock(CountriesHolder.class);
        this.systemParameterDAO = mock(SystemParameterDAO.class);
        this.systemParameterService = mock(SystemParameterService.class);
        createDebtDocumentServiceRunner = mock(CreateDebtDocumentServiceRunner.class);
        updateDebtProcessBatchServiceRunner = mock(UpdateDebtProcessBatchServiceRunner.class);
        informDebtContinentalBankPYServiceRunner = mock(InformDebtContinentalBankPYServiceRunner.class);
        plantabilityDAO = mock(PlantabilityDAO.class);
        this.debtDAO = mock(DebtDAO.class);
        this.billingDAO = mock(BillingDAO.class);
        plantabilityService = mock(PlantabilityService.class);
        productivityByRegionService = mock(ProductivityByRegionService.class);
        customerDAO = mock(CustomerDAO.class);
        growerDAO = mock(GrowerDAO.class);
        harvestDAO = mock(HarvestDAO.class);
        productDAO = mock(ProductDAO.class);
        bonusRulesService = mock(BonusRulesService.class);
        bonusService = mock(BonusService.class);
        saleValidatorBVC = mock(SaleValidatorBVC.class);
        saleValidator = mock(SaleValidator.class);
        baseService = mock(BaseService.class);
        accountManager = mock(AccountManager.class);
        saleLinkDetailLinker = mock(SaleLinkDetailLinker.class);

        field("accountManager").ofType(AccountManager.class).in(this.saleServiceImpl).set(accountManager);
        field("saleDAO").ofType(SaleDAO.class).in(this.saleServiceImpl).set(this.saleDao);
        field("countriesHolder").ofType(CountriesHolder.class).in(this.saleServiceImpl).set(this.countriesHolder);
        field("systemParameterService").ofType(SystemParameterService.class).in(this.saleServiceImpl).set(this.systemParameterService);
        field("systemParameterDAO").ofType(SystemParameterDAO.class).in(this.saleServiceImpl).set(this.systemParameterDAO);
        field("createDebtDocumentServiceRunner").ofType(CreateDebtDocumentServiceRunner.class).in(this.saleServiceImpl).set(this.createDebtDocumentServiceRunner);
        field("updateDebtProcessBatchServiceRunner").ofType(UpdateDebtProcessBatchServiceRunner.class).in(this.saleServiceImpl).set(this.updateDebtProcessBatchServiceRunner);
        field("informDebtContinentalBankPYServiceRunner").ofType(InformDebtContinentalBankPYServiceRunner.class).in(this.saleServiceImpl).set(this.informDebtContinentalBankPYServiceRunner);
        field("debtDAO").ofType(DebtDAO.class).in(this.saleServiceImpl).set(this.debtDAO);
        field("billingDAO").ofType(BillingDAO.class).in(this.saleServiceImpl).set(this.billingDAO);
        field("plantabilityDAO").ofType(PlantabilityDAO.class).in(this.saleServiceImpl).set(plantabilityDAO);
        field("plantabilityService").ofType(PlantabilityService.class).in(this.saleServiceImpl).set(plantabilityService);
        field("productivityByRegionService").ofType(ProductivityByRegionService.class).in(this.saleServiceImpl).set(productivityByRegionService);
        field("bonusRulesService").ofType(BonusRulesService.class).in(this.saleServiceImpl).set(bonusRulesService);
        field("bonusService").ofType(BonusService.class).in(this.saleServiceImpl).set(bonusService);
        field("saleValidator").ofType(SaleValidator.class).in(saleServiceImpl).set(saleValidator);
        field("saleValidatorBVC").ofType(SaleValidatorBVC.class).in(saleServiceImpl).set(saleValidatorBVC);
        field("baseService").ofType(BaseService.class).in(saleServiceImpl).set(baseService);
        field("saleLinkDetailLinker").ofType(SaleLinkDetailLinker.class).in(saleServiceImpl).set(saleLinkDetailLinker);

        field("customerDAO").ofType(CustomerDAO.class).in(this.saleServiceImpl).set(customerDAO);
        field("growerDAO").ofType(GrowerDAO.class).in(this.saleServiceImpl).set(growerDAO);
        field("harvestDAO").ofType(HarvestDAO.class).in(this.saleServiceImpl).set(harvestDAO);
        field("productDAO").ofType(ProductDAO.class).in(this.saleServiceImpl).set(productDAO);

        try {
            when(baseService.getGrowerByCandidateKeyWithoutSalesInformation(anyString(), anyString())).thenReturn(new Grower());
        } catch (EntityNotFoundException e) {
            //Ignore
        }
    }

    @Test
    public void testGetSaleByIdCallsSaleDaoGetByFilter_WhenCountryIsBrazil() {
        // @Given a saleFilter and current country Brazil
        SaleFilter saleFilter = null;
        when(this.countriesHolder.getCountry()).thenReturn(VCCountry.BRAZIL);

        // @When getting a sale by a filter
        this.saleServiceImpl.getSaleBy(saleFilter);

        // @Then SaleDao getByFilter is called
        verify(this.saleDao, times(1)).getWithItemsByFilter(saleFilter);
    }

    @Test
    public void testGetSaleByIdCallsSaleDaoGetWithItemsByFilter_WhenCountryIsArgentina() {
        // @Given a saleFilter and current country Argentina
        SaleFilter saleFilter = null;
        when(this.countriesHolder.getCountry()).thenReturn(VCCountry.ARGENTINA);

        // @When getting a sale by a filter
        this.saleServiceImpl.getSaleBy(saleFilter);

        // @Then SaleDao getWithItemsByFilter is called
        verify(this.saleDao, times(1)).getWithItemsByFilter(saleFilter);
    }

    @Test
    public void testGetSaleByIdCallsSaleDaoGetWithItemsByFilter_WhenCountryIsParaguay() {
        // @Given a saleFilter and current country Paraguay
        SaleFilter saleFilter = null;
        when(this.countriesHolder.getCountry()).thenReturn(VCCountry.PARAGUAY);

        // @When getting a sale by a filter
        this.saleServiceImpl.getSaleBy(saleFilter);

        // @Then SaleDao getWithItemsByFilter is called
        verify(this.saleDao, times(1)).getWithItemsByFilter(saleFilter);
    }

    @Test
    public void testInformDebtBy_CallingFindByGroupAndCountryCodeParaguay_WithSaleItem() throws Exception {
        // @Given

        when(this.countriesHolder.getCountry()).thenReturn(VCCountry.PARAGUAY);
        SystemParameterValue systemParameterValue = new SystemParameterValue(TypeParameter.STRING, "true");
        SystemParameter systemParameter = new SystemParameter("COND", systemParameterValue);
        when(this.systemParameterService.selectParameterByGroupAndNameAndCountryCode(SaleServiceImpl.INFORM_DEBT_ENABLED_GROUP,SaleServiceImpl.INFORM_DEBT_ENABLED,VCCountry.PARAGUAY.getCountryCode())).thenReturn(systemParameter);
        //
        Sale sale = getSaleForTest();
        sale.setSaleType(Sale.SaleTypeEnum.DIRECT_SALE);

        // @When
        this.saleServiceImpl.informDebt(sale);
        // @Then
//        verify(informDebtContinentalBankPYServiceRunner, times(1)).setSale(any(Sale.class));
        verify(informDebtContinentalBankPYServiceRunner, times(1)).run(any(Sale.class));

    }

    private Sale getSaleForTest() {
        Sale sale = mock(Sale.class);
        Customer customer = mock(Customer.class);
        Grower grower = mock(Grower.class);
        Document document = mock(Document.class);
        when(grower.getDocument()).thenReturn(document);
        when(sale.getGrower()).thenReturn(grower);
        when(sale.getCustomer()).thenReturn(customer);
        when(grower.getId()).thenReturn(1L);
        when(sale.getSaleOrderSAPId()).thenReturn(1L);
        when(sale.getId()).thenReturn(null);
        return sale;
    }

    //makeDebtTransaction usar matchers para la invocacion del adapter

    @Test
    public void testBatchDebtNotifications_ByCallingUpdateDebtProcessBatch_WithMatchersParameters() throws Exception {
        // @Giving
        String bankGroupId = SaleServiceImpl.I_SANTANDERRIO_BANK_DEBT_NOTIF;
        HashMap<String, String> parameters = new HashMap<String, String>();
        parameters.put("COUNTRY_ID", String.valueOf(1L));
        TypeParameter type = TypeParameter.STRING;
        String value = "1";
        SystemParameterValue systemParameterValue = new SystemParameterValue(type, value);
        SystemParameter systemParameter = new SystemParameter("COUNTRY_ID", systemParameterValue);
        systemParameter.setCountryId(1L);
        ArrayList<SystemParameter> parameterList = Lists.newArrayList(systemParameter);
        when(this.systemParameterDAO.findByGroupAndCountryCode(I_SANTANDERRIO_BANK_DEBT_NOTIF, "AR")).thenReturn(parameterList);
        //  @When
        this.saleServiceImpl.batchDebtNotification(bankGroupId);
        // @Then
        verify(updateDebtProcessBatchServiceRunner, times(1)).setSign(Mockito.anyString());
        verify(updateDebtProcessBatchServiceRunner, times(1)).setProduct(Mockito.anyString());
        verify(updateDebtProcessBatchServiceRunner, times(1)).setAgreement(Mockito.anyString());
        verify(updateDebtProcessBatchServiceRunner, times(1)).setFile(Mockito.anyString());
        verify(updateDebtProcessBatchServiceRunner, times(1)).setCuit(Mockito.anyString());
        verify(updateDebtProcessBatchServiceRunner, times(1)).run();
//        verify(lasvcCreateDebtDocumentAdapter, times(1)).updateDebtProcessBatch(Matchers.any(String.class), Matchers.any(String.class), Matchers.any(String.class), Matchers.any(String.class), Matchers.any(String.class));

    }

    @Test
    public void testGetBillingsOfSaleReturnsDetailedSale_WhenSearchingBillings() {

        // @Given BillingFilter and PaymentStatus
        BillingFilter billingFilter = mock(BillingFilter.class);
        PaymentStatus paymentType = PaymentStatus.FULLY_PAID;
        when(this.billingDAO.getByFilter(billingFilter)).thenReturn(Lists.newArrayList(new Billing()));

        // @When search billings
        DetailedSale detailedSale = this.saleServiceImpl.getBillingsOfSale(billingFilter, paymentType);

        // @Then get a detailed sale
        assertThat(detailedSale.getBillings()).isEqualTo(this.billingDAO.getByFilter(billingFilter));
    }

    @Test
    public void testHasERPMethodReturnsTrue_WhenNeededReversalListOfBillingHasAtLeastOneBillingWithErpMethod() {

        // @Given List of Billing with ERP Method to reversal
        boolean reversal = true;
        Billing billing = new Billing();
        billing.setBillingMethod(SaleTemplateBillingMethodEnum.ERP);
        List<Billing> billingsToCancel = new ArrayList<Billing>();
        billingsToCancel.add(billing);

        // @When test if a billing has a erp method
        boolean hasERPMethod = this.saleServiceImpl.hasERPMethod(billingsToCancel, reversal);

        // @Then get a detailed sale
        Assert.assertTrue(hasERPMethod);
    }

    @Test
    public void testHasERPMethodReturnsFalse_WhenNeededReversalListOfBillingHasNotBillingWithErpMethod() {

        // @Given List of Billing with ERP Method to reversal
        boolean reversal = true;
        Billing billing = new Billing();
        billing.setBillingMethod(SaleTemplateBillingMethodEnum.DIRECT);
        List<Billing> billingsToCancel = new ArrayList<Billing>();
        billingsToCancel.add(billing);

        // @When test if a billing has a erp method
        boolean hasERPMethod = this.saleServiceImpl.hasERPMethod(billingsToCancel, reversal);

        // @Then get a detailed sale
        Assert.assertFalse(hasERPMethod);
    }

    @Test
    public void testHasERPMethodReturnsTrue_WhenNotIsReversal() {

        // @Given Reversal param in false
        boolean reversal = false;

        // @When test if a billing has a erp method
        boolean hasERPMethod = this.saleServiceImpl.hasERPMethod(null, reversal);

        // @Then get result about if some billing has erp method
        Assert.assertTrue(hasERPMethod);
    }

    @Test
    public void given_saleTemplate_set_by_state_when_getPlantabilities_calculate_plantabilities_by_state() {
        //@given
        State state = new State();
        Harvest harvest = new Harvest();
        Product product = new Product();
        Plantability plantability = new Plantability();
        Set<Plantability> plantabilities = Sets.newHashSet(plantability);
        when(plantabilityDAO.selectPlantabilitiesBy(state, harvest, product)).thenReturn(plantabilities);
        SaleTemplate saleTemplate = new SaleTemplate();
        saleTemplate.setHarvest(harvest);
        saleTemplate.setCreditCalculation(SaleTemplateCreditCalculationEnum.BY_STATE_OF_PLANTATION);
        Region region = new Region();

        //@When
        PlantabilitiesSelector actualPlantabilitySelector = saleServiceImpl.getPlantabilitiesBySaleTemplate(saleTemplate, state, region, product);

        //@Should
        assertSame(actualPlantabilitySelector.getPlantabilities(), plantabilities);
    }

    @Test
    public void given_saleTemplate_set_by_region_when_getPlantabilities_calculate_plantabilities_by_region() {
        //@given
        Region region = new Region();
        State state = new State();
        Harvest harvest = mock(Harvest.class);
        Product product = new Product();
        Plantability plantability = new Plantability(harvest, "Test plantability", StatusEnum.ACTIVE, PlantabilitySystemEnum.NO);
        List<Plantability> plantabilities = Lists.newArrayList(plantability);
        ProductivityByRegion productivityByRegion = new ProductivityByRegion();
        List<ProductivityByRegion> productivitiesByRegion = Lists.newArrayList(productivityByRegion);
        when(productivityByRegionService.getFromRegionProductivity(region)).thenReturn(productivitiesByRegion);
        when(plantabilityService.getPlantabilitiesByHarvestAndRegion(any(Harvest.class), anyList(), any(Region.class))).thenReturn(plantabilities);
        SaleTemplate saleTemplate = new SaleTemplate();
        saleTemplate.setHarvest(harvest);
        saleTemplate.setCreditCalculation(SaleTemplateCreditCalculationEnum.BY_REGION_OF_PLANTATION);

        //@When
        PlantabilitiesSelector actualPlantabilitySelector = saleServiceImpl.getPlantabilitiesBySaleTemplate(saleTemplate, state, region, product);

        //@Should
        assertEquals(1, actualPlantabilitySelector.getPlantabilities().size());
    }


    @Test
    public void given_documentNumber_stateRegistration_sapCode_null_null_when_getAllowedBy_should_return_customer() throws DocumentMismatchException, CustomerNotAllowedException, CustomerNotFoundException {

        Customer customertoReturn = new Customer("CustomerTest", null, null, "sapCodeTest");

        when(customerDAO.getAllowedBy(anyString(), anyString(), anyString(), any(ParticipantTypeEnum.class))).thenReturn(customertoReturn);

        Customer customer = this.saleServiceImpl.getAllowedBy("", "", "", null, null);

        assertEquals(customertoReturn, customer);

    }

    @Test
    public void given_documentNumber_stateRegistration_sapCode_null_null_when_getAllowedBy_should_return_null() throws DocumentMismatchException, CustomerNotAllowedException, CustomerNotFoundException {

        try {

            Customer customertoReturn = null;

            when(customerDAO.getAllowedBy(anyString(), anyString(), anyString(), any(ParticipantTypeEnum.class))).thenReturn(customertoReturn);

            this.saleServiceImpl.getAllowedBy("", "", "", null, null);

        } catch (CustomerNotFoundException ex) {
            assertEquals("Not found distributor with the documentNumber=", ex.getMessage());
        }

    }

    @Test
    public void given_documentNumber_stateRegistration_sapCode_ParticipantTypeEnum_UserDecorator_when_getAllowedBy_should_return_customer() throws DocumentMismatchException, CustomerNotAllowedException, CustomerNotFoundException {

        Customer customertoReturn = new Customer("CustomerTest", null, null, "sapCodeTest");

        ItsUser loggedUser = new ItsUser("login", ItsUser.UserTypeEnum.PARTICIPANT);
        UserDecorator userDecorator = new UserDecorator(null, loggedUser);
        Crop crop = mock(Crop.class);
        userDecorator.setContextCrop(crop);

        when(customerDAO.getAllowedBy(anyString(), anyString(), anyString(), any(ParticipantTypeEnum.class))).thenReturn(customertoReturn);

        when(customerDAO.verifyPermissionOfDistributorToParticipant(anyLong(), anyLong(), anyLong(), any(ParticipantTypeEnum.class))).thenReturn(Boolean.TRUE);

        Customer customer = this.saleServiceImpl.getAllowedBy("", "", "", ParticipantTypeEnum.GERMOPLASMA, userDecorator);

        assertEquals(customertoReturn, customer);
    }

    @Test
    public void given_documentNumber_stateRegistration_sapCode_ParticipantTypeEnum_UserDecorator_when_getAllowedBy_should_return_fail() throws DocumentMismatchException, CustomerNotAllowedException, CustomerNotFoundException {
        try {

            Customer customertoReturn = new Customer("CustomerTest", null, null, "sapCodeTest");

            ItsUser loggedUser = new ItsUser("login", ItsUser.UserTypeEnum.PARTICIPANT);
            UserDecorator userDecorator = new UserDecorator(null, loggedUser);
            Crop crop = mock(Crop.class);
            userDecorator.setContextCrop(crop);

            when(customerDAO.getAllowedBy(anyString(), anyString(), anyString(), any(ParticipantTypeEnum.class))).thenReturn(customertoReturn);

            when(customerDAO.verifyPermissionOfDistributorToParticipant(anyLong(), anyLong(), anyLong(), any(ParticipantTypeEnum.class))).thenReturn(Boolean.FALSE);

            this.saleServiceImpl.getAllowedBy("", "", "", ParticipantTypeEnum.GERMOPLASMA, userDecorator);

        } catch (CustomerNotAllowedException e) {
            assertEquals("User login is not allowed to access Customer with documentNumber=null", e.getMessage());
        }
    }


    @Test
    public void given_documentNumber_stateRegistration_sapCode_ParticipantTypeEnum_UserDecorator_when_getAllowedBy_should_fail() throws DocumentMismatchException, CustomerNotAllowedException, CustomerNotFoundException {

        try {
            Customer customertoReturn = new Customer("CustomerTest", null, null, "sapCodeTest");

            ItsUser loggedUser = new ItsUser("login", ItsUser.UserTypeEnum.JOBOPERATOR);
            UserDecorator userDecorator = new UserDecorator(null, loggedUser);
            Crop crop = mock(Crop.class);
            userDecorator.setContextCrop(crop);

            when(customerDAO.getAllowedBy(anyString(), anyString(), anyString(), any(ParticipantTypeEnum.class))).thenReturn(customertoReturn);

            when(customerDAO.verifyPermissionOfDistributorToParticipant(anyLong(), anyLong(), anyLong(), any(ParticipantTypeEnum.class))).thenReturn(Boolean.TRUE);

            this.saleServiceImpl.getAllowedBy("", "", "", ParticipantTypeEnum.GERMOPLASMA, userDecorator);
        } catch (CustomerNotAllowedException e) {
            assertEquals("User login is not allowed to access Customer with documentNumber=null", e.getMessage());
        }

    }


    @Test
    public void given_documentNumber_stateRegistration_sapCode_ParticipantTypeEnum_UserADMINISTRATOR_when_getAllowedBy_should_return_customer() throws DocumentMismatchException, CustomerNotAllowedException, CustomerNotFoundException {

        Customer customertoReturn = new Customer("CustomerTest", null, null, "sapCodeTest");

        ItsUser loggedUser = new ItsUser("login", ItsUser.UserTypeEnum.ADMINISTRATOR);
        UserDecorator userDecorator = new UserDecorator(null, loggedUser);
        userDecorator.setContextCrop(new Crop());
        userDecorator.setContextCompany(new Company());


        when(customerDAO.getAllowedBy(anyString(), anyString(), anyString(), any(ParticipantTypeEnum.class))).thenReturn(customertoReturn);

        when(customerDAO.getAllAssociationOf(any(Customer.class))).thenReturn(createHeadoffices());

        Customer customer = this.saleServiceImpl.getAllowedBy("", "", "", ParticipantTypeEnum.GERMOPLASMA, userDecorator);

        assertEquals(customertoReturn, customer);
    }


    @Test
    public void given_documentNumber_stateRegistration_sapCode_ParticipantTypeEnum_UserADMINISTRATOR_when_getAllowedBy_should_return_fail() throws DocumentMismatchException, CustomerNotAllowedException, CustomerNotFoundException {
        try {
            Customer customertoReturn = new Customer("CustomerTest", null, null, "sapCodeTest");

            ItsUser loggedUser = new ItsUser("login", ItsUser.UserTypeEnum.ADMINISTRATOR);
            UserDecorator userDecorator = new UserDecorator(null, loggedUser);
            userDecorator.setContextCrop(new Crop());

            when(customerDAO.getAllowedBy(anyString(), anyString(), anyString(), any(ParticipantTypeEnum.class))).thenReturn(customertoReturn);

            when(customerDAO.getAllAssociationOf(any(Customer.class))).thenReturn(createHeadoffices());

            this.saleServiceImpl.getAllowedBy("", "", "", ParticipantTypeEnum.GERMOPLASMA, userDecorator);

        } catch (CustomerNotAllowedException e) {
            assertEquals("User login is not allowed to access Customer with documentNumber=null", e.getMessage());
        }
    }

    @Test
    public void given_documentNumber_stateRegistration_sapCode_ParticipantTypeEnum_UserAJOBOPERATOR_when_getAllowedBy_should_return_fail() throws DocumentMismatchException, CustomerNotAllowedException, CustomerNotFoundException {
        try {
            Customer customertoReturn = new Customer("CustomerTest", null, null, "sapCodeTest");

            ItsUser loggedUser = new ItsUser("login", ItsUser.UserTypeEnum.JOBOPERATOR);
            UserDecorator userDecorator = new UserDecorator(null, loggedUser);
            userDecorator.setContextCompany(new Company());

            when(customerDAO.getAllowedBy(anyString(), anyString(), anyString(), any(ParticipantTypeEnum.class))).thenReturn(customertoReturn);

            when(customerDAO.getAllAssociationOf(any(Customer.class))).thenReturn(createHeadoffices());

            this.saleServiceImpl.getAllowedBy("", "", "", ParticipantTypeEnum.GERMOPLASMA, userDecorator);

        } catch (CustomerNotAllowedException e) {
            assertEquals("User login is not allowed to access Customer with documentNumber=null", e.getMessage());
        }
    }

    @Test
    public void given_documentNumber_when_getGrowerBy_should_return_Grower() throws GrowerNotFoundException {
        Grower growerToReturn = new Grower();
        when(growerDAO.selectBy(anyString(), anyBoolean())).thenReturn(growerToReturn);
        Grower grower = saleServiceImpl.getGrowerBy("");
        assertEquals(growerToReturn, grower);
    }


    @Test
    public void given_companies_crop_when_getHarvestsInVigor_should_return_harvests() throws GrowerNotFoundException {

        List<Harvest> harvestsToReturn = new ArrayList<Harvest>();
        harvestsToReturn.add(new Harvest());

        when(harvestDAO.selectHarvestsInVigor(any(List.class), any(Crop.class))).thenReturn(harvestsToReturn);
        List<Harvest> harvests = saleServiceImpl.getHarvestsInVigor(new ArrayList<Company>(), new Crop());

        assertEquals(harvestsToReturn.get(0), harvests.get(0));
    }


    @Test
    public void given_productFilter_when_getProductsBy_should_return_products() throws GrowerNotFoundException {


        List<Product> productsToReturn = new ArrayList<Product>();
        productsToReturn.add(new Product());

        when(productDAO.selectByFilter(any(ItsFilter.class))).thenReturn(productsToReturn);

        List<Product> products = saleServiceImpl.getProductsBy(ProductFilter.getInstance());

        assertEquals(productsToReturn.get(0), products.get(0));
    }


    private List<HeadOffice> createHeadoffices() {
        List<HeadOffice> offices = new ArrayList<HeadOffice>();
        HeadOffice headOffice = new HeadOffice();
        field("crop").ofType(Crop.class).in(headOffice).set(new Crop());
        field("company").ofType(Company.class).in(headOffice).set(new Company());
        offices.add(headOffice);
        return offices;
    }


    @Test
    public void testGetManualReleaseCreditBySaleIds() {
        // @When
        saleServiceImpl.getManualReleaseCreditBySaleIds(23L, 34L, 45L);

        // @Then
        verify(saleDao).getManualReleaseCreditBySaleIds(23L, 34L, 45L);
    }

    @Test
    public void test_get_credit_extract_with_a_valid_entry_should_return_a_list_with_one_valid_summaryCreditExtract_object() {
        List<Grower> growers = new ArrayList();
        Grower grower = mock(Grower.class);
        growers.add(grower);
        Crop crop = mock(Crop.class);
        Technology technology = mock(Technology.class);
        OperationalYear operationalYear = mock(OperationalYear.class);
        AccountService accountService = mock(AccountService.class);
        field("accountService").ofType(AccountService.class).in(saleServiceImpl).set(accountService);
        List<Entry> entries = new ArrayList<Entry>();

        Entry entry = mock(Entry.class);
        Account account = mock(Account.class);
        when(account.getOperationalYear()).thenReturn(operationalYear);
        when(account.getOwnerCode()).thenReturn(1L);
        when(account.getType()).thenReturn(Account.AccountType.AVAILABLE);
        Transaction transaction = mock(Transaction.class);
        when(transaction.getCode()).thenReturn(2L);
        when(entry.getTransaction()).thenReturn(transaction);
        when(entry.getAccount()).thenReturn(account);
        when(entry.getAmount()).thenReturn(new BigDecimal(1000));
        entries.add(entry);
        when(accountService.getEntriesBy(growers, crop, technology, operationalYear)).thenReturn(entries);

        List<SummaryCreditExtract> summaryCreditExtractList = saleServiceImpl.getCreditExtract(growers, crop, technology, operationalYear);

        assertThat(summaryCreditExtractList).isNotEmpty();

        assertThat(summaryCreditExtractList).onProperty("grower").isNotNull();
        assertThat(summaryCreditExtractList).onProperty("grower").isNotEmpty();

        assertThat(summaryCreditExtractList).onProperty("operationalYear").isNotNull();
        assertThat(summaryCreditExtractList).onProperty("operationalYear").isNotEmpty();

        assertThat(summaryCreditExtractList).onProperty("details").isNotNull();
        assertThat(summaryCreditExtractList).onProperty("details").isNotEmpty();
    }

    @Test
    public void test_updateForLASVC_throws_expection_if_saleId_is_null() {
        ItsUser loggedUser = new ItsUser("login", ItsUser.UserTypeEnum.PARTICIPANT);
        UserDecorator userDecorator = new UserDecorator(null, loggedUser);
        Crop crop = mock(Crop.class);
        userDecorator.setContextCrop(crop);


        try {
            saleServiceImpl.updateForLASVC(getSaleForTest(), userDecorator);
            fail();
        } catch (SaleConstraintViolationException ex) {
            assertEquals(ex.getMessage(), "Cannot update non existing sale");
        }

    }

    @Test
    public void test_save_calls_saleDAO_save() throws SaleConstraintViolationException, MBusinessException {
        ItsUser loggedUser = new ItsUser("login", ItsUser.UserTypeEnum.ADMINISTRATOR);

        UserDecorator userDecorator = new UserDecorator(null, loggedUser);
        Crop crop = mock(Crop.class);
        userDecorator.setContextCrop(crop);
        Sale sale = getSaleForTest();
        when(saleDao.save(sale)).thenReturn(sale);
        sale.setId(1L);
        saleServiceImpl.save(sale, userDecorator);

        verify(saleDao, times(1)).save(sale);

    }

    @Test
    public void testSaveBonusForSale_whenSavingSale() throws Exception {
        ItsUser loggedUser = new ItsUser("login", ItsUser.UserTypeEnum.ADMINISTRATOR);

        UserDecorator userDecorator = new UserDecorator(null, loggedUser);
        Crop crop = mock(Crop.class);
        userDecorator.setContextCrop(crop);
        Sale sale = getSaleForTest();
        when(saleDao.save(sale)).thenReturn(sale);
        long saleId = 102L;
        when(sale.getId()).thenReturn(saleId);
        SaleItem saleItem = mock(SaleItem.class);
        when(saleItem.getBonusAmount()).thenReturn(BigDecimal.TEN);
        when(saleItem.getBillingMethod()).thenReturn(SaleTemplateBillingMethodEnum.ERP);
        when(saleItem.getTechnologyDescription()).thenReturn("lala");
        Harvest harvest = mock(Harvest.class);
        Agreement agreement = mock(Agreement.class);
        when(agreement.isApproved()).thenReturn(true);
        when(agreement.getTechnologyDescription()).thenReturn("lala");

        BonusRules bonusRules = mock(BonusRules.class);
        Set<Agreement> agreements = new HashSet<Agreement>();
        agreements.add(agreement);
        when(sale.getGrower().getAgreements()).thenReturn(agreements);
        SaleTemplate saleTemplate = mock(SaleTemplate.class);

        when(sale.getSaleTemplate()).thenReturn(saleTemplate);
        OperationalYear operationalYear = mock(OperationalYear.class);
        Technology technology = mock(Technology.class);
        when(saleItem.getTechnology()).thenReturn(technology);
        when(bonusRulesService.findBonusRuleByAgreementTemplateAndOperationYear(any(AgreementTemplate.class),
                any(OperationalYear.class))).thenReturn(bonusRules);

        List<BonusRulesValue> bonusRulesValues = new ArrayList<BonusRulesValue>();
        BonusRulesValue bonusRulesValue = mock(BonusRulesValue.class);
        when(bonusRulesValue.getFrom()).thenReturn(new Date());
        when(bonusRulesValue.getTo()).thenReturn(new Date());
        bonusRulesValues.add(bonusRulesValue);

        when(bonusRules.getBonusRulesValues()).thenReturn(bonusRulesValues);


        when(harvest.getOperationalYear()).thenReturn(operationalYear);
        when(saleItem.getHarvest()).thenReturn(harvest);
        Set<SaleItem> items = new HashSet<SaleItem>();
        items.add(saleItem);
        when(sale.getItems()).thenReturn(items);

        saleServiceImpl.save(sale, userDecorator);

        verify(bonusService).updateBonus(any(String.class), any(Grower.class), any(Agreement.class)
                , any(OperationalYear.class), any(BigDecimal.class), any(BonusTransaction.CodeSource.class), eq(saleId));

    }

    @Test
    public void test_updateForLASVC_calls_saleDAO_save() throws SaleConstraintViolationException {
        ItsUser loggedUser = new ItsUser("login", ItsUser.UserTypeEnum.ADMINISTRATOR);
        UserDecorator userDecorator = new UserDecorator(null, loggedUser);
        Crop crop = mock(Crop.class);
        userDecorator.setContextCrop(crop);
        Sale sale = getSaleForTest();
        when(saleDao.save(sale)).thenReturn(sale);
        when(sale.getId()).thenReturn(1L);

        saleServiceImpl.updateForLASVC(sale, userDecorator);

        verify(saleDao, times(1)).save(sale);
    }

    @Test
    public void testCancellingBonusDoNotCancelBonus_WhenSaleItemDoesNotHaveBonus() throws Exception {
        Sale sale = mock(Sale.class);
        Customer customer = mock(Customer.class);
        Grower grower = mock(Grower.class);
        Document document = mock(Document.class);
        SaleItem item1 = mock(SaleItem.class);
        Harvest harvest = mock(Harvest.class);
        OperationalYear operationalYear = mock(OperationalYear.class);
        Set<SaleItem> saleItems = new HashSet<SaleItem>();
        saleItems.add(item1);

        when(item1.getBonusAmount()).thenReturn(null);
        when(harvest.getOperationalYear()).thenReturn(operationalYear);
        when(grower.getDocument()).thenReturn(document);
        when(sale.getGrower()).thenReturn(grower);
        when(sale.getCustomer()).thenReturn(customer);
        when(grower.getId()).thenReturn(1L);
        when(sale.getSaleOrderSAPId()).thenReturn(1L);
        when(sale.getId()).thenReturn(null);
        when(item1.getHarvest()).thenReturn(harvest);
        when(sale.getItems()).thenReturn(saleItems);
        when(saleDao.getById(anyLong())).thenReturn(sale);

        saleServiceImpl.cancellingBonus(sale.getId());

        verify(bonusService, never()).updateBonus(anyString(), (Grower) anyObject(), (Agreement) anyObject(), (OperationalYear) anyObject(), (BigDecimal) anyObject(), (BonusTransaction.CodeSource) anyObject());
    }

    @Test
    public void testSaveBonusForSaleWontAttemptToGenerateBonus_WhenBonusAmountIsNull() throws Exception {
        Sale sale = createSale(null);

        saleServiceImpl.saveBonusForSale(sale);

        verify(bonusService, never()).updateBonus(anyString(), any(Grower.class),
                any(Agreement.class), any(OperationalYear.class), any(BigDecimal.class),
                any(BonusTransaction.CodeSource.class), anyLong());
    }

    @Test
    public void testSaveBonusForSaleWontAttemptToGenerateBonus_WhenBonusAmountIsZero() throws Exception {
        Sale sale = createSale(BigDecimal.ZERO);

        saleServiceImpl.saveBonusForSale(sale);

        verify(bonusService, never()).updateBonus(anyString(), any(Grower.class),
                any(Agreement.class), any(OperationalYear.class), any(BigDecimal.class),
                any(BonusTransaction.CodeSource.class), anyLong());
    }

    @Test
    public void testCalculateBonusForSaleFindNoBonusRulesCandidate_WhenCalculatingBonus() {
        //@given
        Sale sale = createSale(BigDecimal.TEN);
        BonusRules bonusRule = new BonusRules();
        List<BonusRulesValue> list = new ArrayList<BonusRulesValue>();
        BonusRulesValue brv = new BonusRulesValue();
        brv.setBonusAmount(BigDecimal.ONE);
        brv.setAccrualAmount(BigDecimal.ONE);
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.MONTH, -2);
        brv.setFrom(calendar.getTime());
        calendar.add(Calendar.MONTH, 1);
        brv.setTo(calendar.getTime());
        list.add(brv);
        bonusRule.setBonusRulesValues(list);
        when(bonusRulesService.findBonusRuleByAgreementTemplateAndOperationYear(any(AgreementTemplate.class), any(OperationalYear.class))).thenReturn(bonusRule);
        //@When
        saleServiceImpl.calculateBonusForSale(sale);

        //@Verify
        verify(productivityByRegionService, never()).getFromRegionAndPlantabilityAndProduct(any(Region.class), any(Plantability.class), any(Product.class));

    }

    @Test
    public void testCalculateBonusForSaleNoAgreementFound_WhenCalculatingBonus() {
        //@Given
        Sale sale = createSale(BigDecimal.TEN);
        Grower grower = new Grower();
        grower.setDocument(new Document(new DocumentType("", new Country(), ""), ""));
        sale.setGrower(grower);
        //@When
        saleServiceImpl.calculateBonusForSale(sale);

        //@Verify
        verify(bonusRulesService, never()).findBonusRuleByAgreementTemplateAndOperationYear(any(AgreementTemplate.class), any(OperationalYear.class));
    }

    @Test
    public void testCalculateBonusForSaleHasValidPeriod_WhenCalculatingBonus() {

        Sale sale = createSale(BigDecimal.TEN);
        BonusRules bonusRule = new BonusRules();
        bonusRule.setCalculationType(BonusRules.CalculationType.KG);
        List<BonusRulesValue> list = new ArrayList<BonusRulesValue>();
        Calendar calendar = Calendar.getInstance();
        BonusRulesValue brv = new BonusRulesValue();
        brv.setBonusAmount(BigDecimal.ONE);
        brv.setAccrualAmount(BigDecimal.ONE);
        calendar.add(Calendar.MONTH, -3);
        brv.setFrom(calendar.getTime());
        calendar.add(Calendar.MONTH, 1);
        brv.setTo(calendar.getTime());
        list.add(brv);
        calendar = Calendar.getInstance();
        brv = new BonusRulesValue();
        brv.setBonusAmount(BigDecimal.ONE);
        brv.setAccrualAmount(BigDecimal.ONE);
        calendar.add(Calendar.MONTH, 1);
        brv.setFrom(calendar.getTime());
        calendar.add(Calendar.MONTH, -3);
        brv.setTo(calendar.getTime());
        list.add(brv);
        bonusRule.setBonusRulesValues(list);
        when(bonusRulesService.findBonusRuleByAgreementTemplateAndOperationYear(any(AgreementTemplate.class), any(OperationalYear.class))).thenReturn(bonusRule);
        //@When
        saleServiceImpl.calculateBonusForSale(sale);

        //@Verify
        Set<SaleItem> items = sale.getItems();
        Iterator<SaleItem> iterator = items.iterator();

        assertThat(iterator.next().getBonusAmount()).isSameAs(BigDecimal.TEN);
    }

    private Sale createSale(BigDecimal bonusAmount) {

        Customer dealer = new Customer();
        Grower grower = new Grower();
        grower.setDocument(new Document(new DocumentType("", new Country(), ""), ""));
        Agreement agreement = new Agreement();
        AgreementTemplate agreementTemplate = new AgreementTemplate();
        Technology technology = new Technology("Tech", null);
        agreementTemplate.setTechnology(technology);
        agreement.setAgreementTemplate(agreementTemplate);
        grower.addAgreement(new Agreement());

        Sale sale = new Sale(dealer, grower);
        sale.setRegion(new Region(""));
        sale.setCity(new City("", new State()));
        SaleItem saleItem = new SaleItem();
        saleItem.setBonusAmount(bonusAmount);
        final SaleTemplate saleTemplate = new SaleTemplate();
        saleTemplate.setHarvest(new Harvest());
        saleItem.setSaleTemplate(saleTemplate);
        Product product = new Product("Prod", StatusEnum.ACTIVE, new Crop(), technology, new Brand(), null);
        saleItem.setProduct(product);
        Set<SaleItem> saleItems = Sets.newHashSet(saleItem);
        sale.setItems(saleItems);
        when(saleDao.save(sale)).thenReturn(sale);
        return sale;
    }

    @Test
    public void testHandleCancelMultipleSalesUpdatesBonusOnlyOnce_whenCancellationIsInvokedWithOneSaleWithOneItemThatGeneratedBonus() throws Exception {
        Sale sale = new Sale();
        Grower grower = new Grower();
        Agreement agreement = new Agreement();
        agreement.setStatus(Agreement.AgreementStatusEnum.APPROVED);
        Technology technology = new Technology();
        technology.setDescription("DUMMY_TECHNOLOGY");
        AgreementTemplate agreementTemplate = new AgreementTemplate();
        agreementTemplate.setTechnology(technology);
        agreement.setAgreementTemplate(agreementTemplate);
        grower.addAgreement(agreement);
        sale.setGrower(grower);
        Address address = new Address();
        Country country = new Country();
        country.setCode("BR");
        address.setCountry(country);
        Customer customer = new Customer("DUMMY_NAME", new Document(), address, "DUMMY_SAP_CODE");
        sale.setCustomer(customer);
        Collection<Sale> sales = Arrays.asList(sale);
        Company company = new Company();
        List<Company> companies = Arrays.asList(company);
        Cancellation cancellation = new Cancellation();
        String userLogin = "DUMMY_USER";
        OperationalYear operationalYear = new OperationalYear("2014");
        OperationalYear nextOperationalYear = new OperationalYear("2015");
        operationalYear.setNextOperationalYear(nextOperationalYear);
        SaleItem saleItem = new SaleItem();
        Product product = new Product();
        product.setQuotaUsage(QuotaUsageEnum.DONT_USE_QUOTA);
        product.setCompany(company);
        product.setTechnology(technology);
        saleItem.setProduct(product);
        saleItem.setBonusAmount(new BigDecimal(50));
        SaleTemplate saleTemplate = new SaleTemplate();
        Harvest harvest = new Harvest();
        harvest.setOperationalYear(operationalYear);
        saleTemplate.setHarvest(harvest);
        saleItem.setSaleTemplate(saleTemplate);
        sale.addItem(saleItem);
        Long saleCode = 8l;
        sale.setId(saleCode);
        when(saleDao.getById(saleCode)).thenReturn(sale);
        Billing billing = new Billing();
        billing.setCreditStatus(CreditStatus.ABSENT);
        billing.setPaymentStatus(PaymentStatus.NOT_PAID);
        List<Billing> billings = Arrays.asList(billing);
        when(billingDAO.getByFilter(any(BillingFilter.class))).thenReturn(billings);

        saleServiceImpl.handleCancelMultipleSales(sales, companies, cancellation, userLogin);

        verify(bonusService).updateBonus(BonusTransaction.Type.CONSUMPTION.toString(), sale.getGrower(), agreement, operationalYear.getNextOperationalYear(), saleItem.getBonusAmount(), BonusTransaction.CodeSource.CONSUMPTION_CANCELLATION, saleCode);
    }

    @Test
    public void testSaveSaleLinksDealerSales() throws SaleConstraintViolationException {
        Sale sale = getSaleForTest();
        when(saleDao.save(sale)).thenReturn(sale);
        sale.setId(1L);
        UserDecorator userDecorator = mock(UserDecorator.class);

        saleServiceImpl.save(sale, userDecorator);

        verify(saleLinkDetailLinker).linkDealerSale(sale);
    }

    @Test
    public void testSaveCsvLinksDealerSales() throws SaleConstraintViolationException {
        Sale sale = getSaleForTest();
        when(saleDao.save(sale)).thenReturn(sale);
        sale.setId(1L);
        UserDecorator userDecorator = mock(UserDecorator.class);

        saleServiceImpl.saveCsv(sale, userDecorator);

        verify(saleLinkDetailLinker).linkDealerSale(sale);
    }
    @Test
    public void testGetSalesByGrowerDealerSaleTemplateForBonusPayment() {
        Customer dealer = new Customer();
        Grower grower = new Grower();
        SaleTemplate saleTemplate = new SaleTemplate();

        saleServiceImpl.getSaleItemsByGrowerDealerSaleTemplateForBonusPayment(dealer, grower, saleTemplate);

        verify(saleDao).getSaleItemsByGrowerDealerSaleTemplateForBonusPayment(dealer, grower, saleTemplate);
    }
}
