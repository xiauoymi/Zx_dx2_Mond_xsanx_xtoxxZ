package com.monsanto.brazilvaluecapture.jobs.importfile.messaging.executor.impl;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.ResourceBundle;

import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.dumbster.smtp.SimpleSmtpServer;
import com.monsanto.brazilvaluecapture.core.base.SystemTestFixture;
import com.monsanto.brazilvaluecapture.core.foundation.service.BusinessException;
import com.monsanto.brazilvaluecapture.core.foundation.test.AbstractServiceIntegrationTests;
import com.monsanto.brazilvaluecapture.core.importfile.model.bean.CsvImportFile;
import com.monsanto.brazilvaluecapture.core.io.ProcessorConfig;
import com.monsanto.brazilvaluecapture.core.user.AccessControlTestFixture;
import com.monsanto.brazilvaluecapture.core.user.model.bean.HierarchyLevel;
import com.monsanto.brazilvaluecapture.core.user.model.bean.UserContract;
import com.monsanto.brazilvaluecapture.core.user.model.bean.UserDecorator;
import com.monsanto.brazilvaluecapture.jobs.importfile.messaging.bean.FileImportDefinition;
import com.monsanto.brazilvaluecapture.jobs.importfile.messaging.bean.FileImportInfo;
import com.monsanto.brazilvaluecapture.jobs.importfile.messaging.bean.FileImportOperation;
import com.monsanto.brazilvaluecapture.seedsale.billing.model.bean.PaymentStatus;
import com.monsanto.brazilvaluecapture.seedsale.sale.SaleTestFixture;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.CsvSaleCancellationImportLine;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.CsvSaleCancellationImportResult;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.ImportFileStatus;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.Sale;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.dao.SaleFilter;
import com.monsanto.brazilvaluecapture.seedsale.sale.service.SaleBuilder;
import com.monsanto.brazilvaluecapture.seedsale.sale.service.SaleCancellationService;
import com.monsanto.brazilvaluecapture.seedsale.sale.service.SaleConstraintViolationException;
import com.monsanto.brazilvaluecapture.seedsale.sale.service.SaleService;
import com.monsanto.brazilvaluecapture.seedsale.sale.service.parser.cancellation.SaleCancellationProcessor;


public class CsvSaleCancellationFileCallbackTest_AT extends AbstractServiceIntegrationTests {
    @Autowired
    private CsvSaleCancellationFileCallback csvSaleCancellationFileCallback;

    @Autowired
    private SaleService saleService;

    @Autowired
    private SaleCancellationService saleCancellationService;

    private Locale localeBR = new Locale("pt", "BR");
    private ResourceBundle resourceBundle = ResourceBundle.getBundle("bundle/bundle");

    private static SimpleSmtpServer serverSMTP;
    private SaleBuilder builder;

    @Autowired
    @Qualifier("saleCancellationProcessor")
    private SaleCancellationProcessor saleCancellationProcessor;

    private ProcessorConfig processorConfig = new ProcessorConfig();

    @BeforeClass
    public static void start() {

        serverSMTP = SimpleSmtpServer.start(getEnviromentSpecificSmtpPort());
    }

    @AfterClass
    public static void stop() {
        if (serverSMTP != null) {
            serverSMTP.stop();
        }
    }

    @Test
    public void given_3_valid_lines_when_read_should_produce_file_with_3_lines() throws BusinessException, IOException {
        init();
//        createASale(SaleTestFixture.APRIL);

        CsvImportFile csvImportFile = saleCancellationProcessor.readLines(createLexicallyValidCsv(), processorConfig);

        List<CsvSaleCancellationImportLine> csvSaleCancellationImportLines = saleCancellationService.selectCsvImportLinesByFile(csvImportFile);
        Assert.assertEquals("Should be 3", 3, csvSaleCancellationImportLines.size());

        List<CsvSaleCancellationImportResult> csvSaleCancellationImportResults = saleCancellationService.selectCsvSaleCancellationImportResultByFile(csvImportFile);
        Assert.assertEquals("Should be 0", 0, csvSaleCancellationImportResults.size());
    }

    @Test
    public void given_2_invalid_lines_when_read_should_produce_file_with_2_results() throws BusinessException, IOException {
        init();
//        createASale(SaleTestFixture.APRIL);

        CsvImportFile csvImportFile = saleCancellationProcessor.readLines(createLexicallyInvalidCsv(), processorConfig);

        List<CsvSaleCancellationImportLine> csvSaleCancellationImportLines = saleCancellationService.selectCsvImportLinesByFile(csvImportFile);
        Assert.assertEquals("Should be 0", 0, csvSaleCancellationImportLines.size());

        List<CsvSaleCancellationImportResult> csvSaleCancellationImportResults = saleCancellationService.selectCsvSaleCancellationImportResultByFile(csvImportFile);
        Assert.assertEquals("Should be 2", 2, csvSaleCancellationImportResults.size());
    }

    @Test
    @Ignore
    public void given_one_sale_and_one_valid_one_invalid_and_one_bad_layout_should_have_1_line_two_results() throws IOException, BusinessException {
        init();

        createASale(SaleTestFixture.DATE_NOW);

        List<Sale> sales = saleService.getSaleBy(SaleFilter.getInstance().add(systemTestFixture.mons4ntoBr)
                .add(systemTestFixture.soyMons4nto).addCreationDateStart(SaleTestFixture.DATE_YESTERDAY)
                .addCreationDateEnd(SaleTestFixture.DATE_TOMORROW).addGrowerDocument(SaleTestFixture.CHICO_CNPJ));

        Assert.assertFalse("Should not be cancelled", PaymentStatus.CANCELLED==sales.iterator().next().getItems().iterator().next().getBilling().getPaymentStatus());
        CsvImportFile csvImportFile = saleCancellationProcessor.readLines(createAllTypesLines(SaleTestFixture.DATE_NOW), processorConfig);

        List<CsvSaleCancellationImportLine> csvSaleCancellationImportLines = saleCancellationService.selectCsvImportLinesByFile(csvImportFile);
        Assert.assertEquals("Should be 2", 2, csvSaleCancellationImportLines.size());

        List<CsvSaleCancellationImportResult> csvSaleCancellationImportResults = saleCancellationService.selectCsvSaleCancellationImportResultByFile(csvImportFile);
        Assert.assertEquals("Should be 1", 1, csvSaleCancellationImportResults.size());

        Long id = csvImportFile.getId();
        UserDecorator decorator = (UserDecorator) processorConfig.get(ProcessorConfig.ProcessorConfigProperties.LOGGED_USER);

        csvSaleCancellationFileCallback.importFileCallback(new FileImportInfo(csvImportFile, decorator,
                FileImportDefinition.CSV_SALE_CANCELLATION, FileImportOperation.IMPORT, localeBR, "bundle"));

        csvImportFile.setFileStatus(ImportFileStatus.AWAITING_PROCESSING);

        csvSaleCancellationImportLines = saleCancellationService.selectCsvImportLinesByFile(csvImportFile);
        Assert.assertEquals("Should be 1", 1, csvSaleCancellationImportLines.size());

        csvSaleCancellationImportResults = saleCancellationService.selectCsvSaleCancellationImportResultByFile(csvImportFile);
        Assert.assertEquals("Should be 2", 2, csvSaleCancellationImportResults.size());

        csvSaleCancellationFileCallback.importFileCallback(new FileImportInfo(csvImportFile, decorator,
                FileImportDefinition.CSV_SALE_CANCELLATION, FileImportOperation.PROCEED, localeBR, "bundle"));
        getSession().evict(csvImportFile);

        csvImportFile=null;
        csvImportFile=(CsvImportFile) getSession().get(CsvImportFile.class, id);

        csvSaleCancellationImportLines = saleCancellationService.selectCsvImportLinesByFile(csvImportFile);
        Assert.assertEquals("Should be 1", 1, csvSaleCancellationImportLines.size());

        csvSaleCancellationImportResults = saleCancellationService.selectCsvSaleCancellationImportResultByFile(csvImportFile);
        Assert.assertEquals("Should be 2", 2, csvSaleCancellationImportResults.size());

        sales = saleService.getSaleBy(SaleFilter.getInstance().add(systemTestFixture.mons4ntoBr)
                    .add(systemTestFixture.soyMons4nto).addCreationDateStart(SaleTestFixture.DATE_YESTERDAY)
                    .addCreationDateEnd(SaleTestFixture.DATE_TOMORROW).addGrowerDocument(SaleTestFixture.CHICO_CNPJ));

        Assert.assertEquals("Should be cancelled", PaymentStatus.CANCELLED, sales.iterator().next().getItems().iterator().next().getBilling().getPaymentStatus());
    }

    @Test
    @Ignore
    public void given_one_valid_sale_and_one_valid_line_should_produce_1_cancellation() throws IOException, BusinessException {
         init();

        Calendar jan2012 = Calendar.getInstance();
        jan2012.set(2012, 0, 1);

        Calendar dec2013 = Calendar.getInstance();
        dec2013.set(2013, 11, 31);

        createASale(SaleTestFixture.APRIL);

        CsvImportFile csvImportFile = saleCancellationProcessor.readLines(createExistentSale(SaleTestFixture.APRIL), processorConfig);

        List<CsvSaleCancellationImportLine> csvSaleCancellationImportLines = saleCancellationService.selectCsvImportLinesByFile(csvImportFile);
        Assert.assertEquals("Should be 1", 1, csvSaleCancellationImportLines.size());

        List<CsvSaleCancellationImportResult> csvSaleCancellationImportResults = saleCancellationService.selectCsvSaleCancellationImportResultByFile(csvImportFile);
        Assert.assertEquals("Should be 0", 0, csvSaleCancellationImportResults.size());

        Long id = csvImportFile.getId();
        UserDecorator decorator = (UserDecorator) processorConfig.get(ProcessorConfig.ProcessorConfigProperties.LOGGED_USER);

        csvSaleCancellationFileCallback.importFileCallback(new FileImportInfo(csvImportFile, decorator,
                FileImportDefinition.CSV_QUOTA, FileImportOperation.IMPORT, localeBR, "bundle"));

        csvImportFile.setFileStatus(ImportFileStatus.AWAITING_PROCESSING);

        csvSaleCancellationImportLines = saleCancellationService.selectCsvImportLinesByFile(csvImportFile);
        Assert.assertEquals("Should be 1", 1, csvSaleCancellationImportLines.size());

        csvSaleCancellationImportResults = saleCancellationService.selectCsvSaleCancellationImportResultByFile(csvImportFile);
        Assert.assertEquals("Should be 0", 0, csvSaleCancellationImportResults.size());

        csvSaleCancellationFileCallback.importFileCallback(new FileImportInfo(csvImportFile, decorator,
                FileImportDefinition.CSV_QUOTA, FileImportOperation.PROCEED, localeBR, "bundle"));
        getSession().evict(csvImportFile);

        csvImportFile=null;
        csvImportFile=(CsvImportFile) getSession().get(CsvImportFile.class, id);

        csvSaleCancellationImportLines = saleCancellationService.selectCsvImportLinesByFile(csvImportFile);
        Assert.assertEquals("Should be 1", 1, csvSaleCancellationImportLines.size());

        csvSaleCancellationImportResults = saleCancellationService.selectCsvSaleCancellationImportResultByFile(csvImportFile);
        Assert.assertEquals("Should be 0", 0, csvSaleCancellationImportResults.size());

        List<Sale> sales = saleService.getSaleBy(SaleFilter.getInstance().add(systemTestFixture.mons4ntoBr)
                    .add(systemTestFixture.soyMons4nto).addCreationDateStart(jan2012.getTime())
                    .addCreationDateEnd(dec2013.getTime()).addGrowerDocument(SaleTestFixture.CHICO_CNPJ));

        Assert.assertEquals("Should be cancelled", PaymentStatus.CANCELLED, sales.iterator().next().getItems().iterator().next().getBilling().getPaymentStatus());
    }

    private InputStream createLexicallyValidCsv() {
        String lines = "N�mero da Nota Fiscal;Tipo de Documento do Matriz;N�mero do Documento da Matriz;N�mero da Inscri��o Estadual da Matriz;C�digo ERP da Matriz;Tipo de Documento do Parceiro;N�mero do Documento do Parceiro;N�mero da Inscri��o Estadual do Parceiro;C�digo ERP do Parceiro;Tipo de Documento do Agricultor;N�mero do Documento do Agricultor;Data de Lan�amento;UF de Plantio;Empresa;Motivo\n" +
                ";CNPJ;12.345.678/9012-34;123456789;0001234567;CNPJ;12.345.678/9012-34;123456789;0001234567;CPF;123.456.789-00;26/04/2012;SP;Monsanto;3\n" +
                "9999;CNPJ;12.345.678/9012-34;;;CPF;123.456.789-00;123456789;0001234567;;;;;Monsanto;2\n" +
                ";CNPJ;12.345.678/9012-34;123456789;0001234567;CNPJ;12.345.678/9012-34;123456789;;CPF;123.456.789-00;26/04/2012;SP;Monsanto;1\n";

        return new ByteArrayInputStream(lines.getBytes());
    }

    private InputStream createLexicallyInvalidCsv() {
        String lines =
                "Nota Fiscal Numero;Tipo de documento do Matriz;Matriz;Tipo de documento do Parceiro;Numero do documento do Parceiro;Tipo de documento do agricultor;Numero do documento do Agricultor;Data de Lancamento;UF de plantio;Empresa;Motivo\n" +
                        ";CNPJ;12.345.678/9012-34;CNPJ;12.345.678/9012-34;CPF;123.456.789-00;30/02/2012;SP;mons4nto;Erro de cadastro\n" +
                        "9999;;;CNPJ;12.345.678/9012-34;CPF;123.456.789-00;asdfasdfdsf;;mons4nto;Erro de cadastro\n";
        return new ByteArrayInputStream(lines.getBytes());
    }

    private InputStream createExistentSale(Date date) {
        String csvSale = "Nota Fiscal Numero;Tipo de documento do Matriz;Matriz;Numero Inscri\u00e7\u00e3o Estadual Matriz;Codigo Sap Matriz;Tipo de documento do Parceiro;Numero do documento do Parceiro;Numero Inscri\u00e7\u00e3o Estadual Parceiro;Codigo Sap Parceiro;Tipo de documento do agricultor;Numero do documento do Agricultor;Data de Lancamento;UF de plantio;Empresa;Motivo\n"
                + ";CNPJ;77727239523705;;77349148138782;CNPJ;77727239523705;;77349148138782;CNPJ;77208382069704;{date};MSS;mons4nto;SALE_CANCELLATION_TEST_FIXTURE\n";
        return new ByteArrayInputStream(changeCsvDate(date, csvSale).getBytes());
    }

    private InputStream createAllTypesLines(Date date) {
        String csvSale = "Nota Fiscal Numero;Tipo de documento do Matriz;Matriz;Numero Inscri\u00e7\u00e3o Estadual Matriz;Codigo Sap Matriz;Tipo de documento do Parceiro;Numero do documento do Parceiro;Numero Inscri\u00e7\u00e3o Estadual Parceiro;Codigo Sap Parceiro;Tipo de documento do agricultor;Numero do documento do Agricultor;Data de Lancamento;UF de plantio;Empresa;Motivo\n"
                + ";CNPJ;77727239523705;;77349148138782;CNPJ;77727239523705;;77349148138782;CNPJ;77208382069704;{date};MSS;mons4nto;SALE_CANCELLATION_TEST_FIXTURE\n";
        csvSale += ";CNPJ;12.345.678/9012-34;CNPJ;12.345.678/9012-34;CPF;123.456.789-00;{date};SP;mons4nto;Erro de cadastro\n" +
        ";CNPJ;12.345.678/9012-34;123456789;0001234567;CNPJ;12.345.678/9012-34;123456789;0001234567;CPF;123.456.789-00;{date};SP;Monsanto;3\n";
        csvSale = changeCsvDate(date, csvSale);
        return new ByteArrayInputStream(csvSale.getBytes());
    }

    private String changeCsvDate(Date date, String csvSale) {
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        csvSale = csvSale.replace("{date}", sdf.format(date));
        return csvSale;
    }

//    private Sale createASaleWithInvoiceNumber() throws SaleConstraintViolationException {
//        return createASale("12345", SaleTestFixture.APRIL);
//    }

    private Sale createASale(Date date) throws SaleConstraintViolationException {
        return createASale(null, date);
    }

    private Sale createASale(String invoiceNumber, Date date) throws SaleConstraintViolationException {
        builder.clear();
        builder.addSaleItem(saleTestFixture.productIntactaSoyMons4nto,
                saleTestFixture.templateIntactaMons4nto,
                saleTestFixture.officeMons4nto,
                2000L,
                SaleTestFixture.TWO_POINT_FIVE_DOLLARS,
                saleTestFixture.plantability45To54SoyMons4nto2012,
                date);

        Sale sale = builder.setGrower(saleTestFixture.chicoBento).setCustomer(saleTestFixture.matrixMons4nto).buildSale();
        sale.setCreationDate(SaleTestFixture.APRIL);

        if (invoiceNumber != null) {
            sale.setInvoiceNumber(invoiceNumber);
        }
        saleService.save(sale, getParticipantUser());

        return sale;
    }


    private UserDecorator getParticipantUser() {

        UserDecorator participantUser = accessControlTestFixture.participantUser;
        UserContract contractWithMons4nto = new UserContract(participantUser.getCurrentUser(), saleTestFixture.contractMons4nto, saleTestFixture.matrixMons4nto, HierarchyLevel.HEAD_OFFICE);
        saveAndFlush(contractWithMons4nto);

        participantUser.addUserContract(contractWithMons4nto);
        participantUser.setContextCrop(systemTestFixture.soyMons4nto);
        participantUser.addCompany(systemTestFixture.mons4ntoBr);

        return participantUser;
    }

    public void init() {
        systemTestFixture = new SystemTestFixture(this);
        saleTestFixture = new SaleTestFixture(this, systemTestFixture);
        accessControlTestFixture = new AccessControlTestFixture(this, systemTestFixture);
        builder = new SaleBuilder(systemTestFixture.matoGrossoDoSul, saleTestFixture.plantabilitiesSelectorMons4nto);

        UserDecorator loggedSuperUser = accessControlTestFixture.superUser;
        loggedSuperUser.setContextCrop(systemTestFixture.soyMons4nto);
        loggedSuperUser.setContextCompany(systemTestFixture.mons4ntoBr);
        loggedSuperUser.addCompany(systemTestFixture.mons4ntoBr);

        processorConfig = new ProcessorConfig();
        processorConfig.put(ProcessorConfig.ProcessorConfigProperties.SELECTED_LOCALE, localeBR);
        processorConfig.put(ProcessorConfig.ProcessorConfigProperties.LOGGED_USER, loggedSuperUser);
        processorConfig.put(ProcessorConfig.ProcessorConfigProperties.FILENAME, "sample.csv");
        processorConfig.put(ProcessorConfig.ProcessorConfigProperties.BUNDLE, resourceBundle);

        createChargeConsolidateTypes();
    }
}
