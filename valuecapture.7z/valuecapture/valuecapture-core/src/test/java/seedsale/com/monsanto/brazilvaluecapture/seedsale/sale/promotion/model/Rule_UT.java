package com.monsanto.brazilvaluecapture.seedsale.sale.promotion.model;

import com.monsanto.brazilvaluecapture.core.customer.model.bean.Customer;
import com.monsanto.brazilvaluecapture.core.grower.model.bean.Grower;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.Sale;
import com.monsanto.brazilvaluecapture.seedsale.sale.promotion.model.bean.Rule;
import com.monsanto.brazilvaluecapture.seedsale.sale.promotion.model.bean.RuleCriteria;
import org.junit.Test;

import static org.fest.assertions.Assertions.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

/**
 * User: ppera
 * Date: 4/25/13
 * Time: 4:08 PM
 */
public class Rule_UT {

    @Test
    public void testAppliesReturnsFalse_WhenRuleHasNoCriteria() {
        // @Given a rule with no criteria
        Sale sale = new Sale(new Customer(), new Grower());
        Rule rule = new Rule();

        // @When asking if the rule applies
        boolean applies = rule.applies(sale);

        // @Then it returns false
        assertThat(applies).isFalse();
    }

    @Test
    public void testAppliesReturnsFalse_WhenRuleHasOneCriteriaThatDoesNotMatch() {
        // @Given a rule with no criteria
        Sale sale = new Sale(new Customer(), new Grower());
        Rule rule = new Rule();

        rule.addCriteria(newCriteria(sale, false));

        // @When asking if the rule applies
        boolean applies = rule.applies(sale);

        // @Then it returns false
        assertThat(applies).isFalse();
    }

    @Test
    public void testAppliesReturnsTrue_WhenRuleHasOneCriteriaThatMatches() {
        // @Given a rule with no criteria
        Sale sale = new Sale(new Customer(), new Grower());
        Rule rule = new Rule();

        rule.addCriteria(newCriteria(sale, true));

        // @When asking if the rule applies
        boolean applies = rule.applies(sale);

        // @Then it returns false
        assertThat(applies).isTrue();
    }

    @Test
    public void testAppliesReturnsTrue_WhenRuleHas5CriteriaThatMatches() {
        // @Given a rule with no criteria
        Sale sale = new Sale(new Customer(), new Grower());
        Rule rule = new Rule();

        rule.addCriteria(newCriteria(sale, true));
        rule.addCriteria(newCriteria(sale, true));
        rule.addCriteria(newCriteria(sale, true));
        rule.addCriteria(newCriteria(sale, true));
        rule.addCriteria(newCriteria(sale, true));

        // @When asking if the rule applies
        boolean applies = rule.applies(sale);

        // @Then it returns false
        assertThat(applies).isTrue();
    }

    @Test
    public void testAppliesReturnsTrue_WhenRuleHas2CriteriaThatMatchesAndOneThatDoesNot() {
        // @Given a rule with no criteria
        Sale sale = new Sale(new Customer(), new Grower());
        Rule rule = new Rule();

        rule.addCriteria(newCriteria(sale, true));
        rule.addCriteria(newCriteria(sale, false));
        rule.addCriteria(newCriteria(sale, true));

        // @When asking if the rule applies
        boolean applies = rule.applies(sale);

        // @Then it returns false
        assertThat(applies).isFalse();
    }

    private RuleCriteria newCriteria(Sale sale, boolean value) {
        RuleCriteria criteria3 = mock(RuleCriteria.class);
        when(criteria3.test(sale)).thenReturn(value);
        return criteria3;
    }

}
