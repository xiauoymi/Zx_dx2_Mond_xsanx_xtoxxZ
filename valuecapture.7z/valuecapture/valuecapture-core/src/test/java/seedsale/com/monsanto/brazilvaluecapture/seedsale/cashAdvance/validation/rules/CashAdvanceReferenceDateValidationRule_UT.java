package com.monsanto.brazilvaluecapture.seedsale.cashAdvance.validation.rules;

import com.monsanto.brazilvaluecapture.core.foundation.validation.ValidationException;
import com.monsanto.brazilvaluecapture.core.presentation.beans.ResourceBundleTestHelper;
import com.monsanto.brazilvaluecapture.seedsale.cashAdvance.model.bean.CashAdvanceTransaction;
import com.monsanto.brazilvaluecapture.seedsale.template.model.bean.DueDatePriceItem;
import org.junit.Test;

import static org.fest.assertions.Fail.fail;
import static org.fest.assertions.Assertions.*;

public class CashAdvanceReferenceDateValidationRule_UT {
    @Test
    public void testValidateThrowsValidationException_WhenCashAdvanceReferenceDateIsNull(){
        CashAdvanceReferenceDateValidationRule cashAdvanceReferenceDateValidationRule = new CashAdvanceReferenceDateValidationRule();
        CashAdvanceTransaction cashAdvanceTransaction = new CashAdvanceTransaction();

        try {
            cashAdvanceReferenceDateValidationRule.validate(cashAdvanceTransaction);
            fail("Should throw validation exception");
        } catch (ValidationException e) {
            assertThat(e).hasMessage("cash.advance.message.reference.date.required");
        }
    }

    @Test
    public void testValidateDoesNotThrowsValidationException_WhenCashAdvanceReferenceDateIsNotNull(){
        CashAdvanceReferenceDateValidationRule cashAdvanceReferenceDateValidationRule = new CashAdvanceReferenceDateValidationRule();
        CashAdvanceTransaction cashAdvanceTransaction = new CashAdvanceTransaction();
        cashAdvanceTransaction.setReferenceDate(new DueDatePriceItem("REF"));

        try {
            cashAdvanceReferenceDateValidationRule.validate(cashAdvanceTransaction);
        } catch (ValidationException e) {
            fail("Should not throw validation exception");
        }
    }

    @Test
    public void testValidateDoesNotThrowsNullPointerException_WhenCashAdvanceReferenceNull() throws ValidationException {
        CashAdvanceReferenceDateValidationRule cashAdvanceReferenceDateValidationRule = new CashAdvanceReferenceDateValidationRule();

        try {
            cashAdvanceReferenceDateValidationRule.validate(null);
        } catch (NullPointerException e) {
            fail("Should not throw NullPointerException");
        }
    }

    private String[] messages = {"cash.advance.message.reference.date.required"};

    @Test
    public void testI18mMessages_Brazil() throws Exception {
        ResourceBundleTestHelper.assertLanguageStrExistsForBrazil(messages);
    }

    @Test
    public void testI18mMessages_English() throws Exception {
        ResourceBundleTestHelper.assertLanguageStrExistsForUS(messages);
    }
}