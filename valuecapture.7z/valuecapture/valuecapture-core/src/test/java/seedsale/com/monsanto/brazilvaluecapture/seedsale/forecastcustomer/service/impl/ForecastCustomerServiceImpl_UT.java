package com.monsanto.brazilvaluecapture.seedsale.forecastcustomer.service.impl;

import static org.fest.reflect.core.Reflection.field;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.mockito.Mockito.doNothing;

import java.util.ArrayList;
import java.util.List;

import com.monsanto.brazilvaluecapture.core.serviceFee.model.bean.ServiceFeeProgram;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import static org.mockito.Matchers.any;

import com.monsanto.brazilvaluecapture.seedsale.forecastcustomer.model.bean.ForecastCustomer;
import com.monsanto.brazilvaluecapture.seedsale.forecastcustomer.model.dao.ForecastCustomerDAO;
import com.monsanto.brazilvaluecapture.seedsale.forecastcustomer.service.ForecastCustomerService;
import com.monsanto.brazilvaluecapture.seedsale.product.model.bean.Product;

public class ForecastCustomerServiceImpl_UT {
	
	ForecastCustomerService forecastCustomerService;
	
	@Mock
	ForecastCustomerDAO forecastCustomerDAO;

	@Before
	public void setUp() throws Exception {
        MockitoAnnotations.initMocks(this);
        this.forecastCustomerService = new ForecastCustomerServiceImpl();
        field("forecastCustomerDAO").ofType(ForecastCustomerDAO.class).in(this.forecastCustomerService).set(this.forecastCustomerDAO);
    }

	@Test
	public void testGetLastForecastCustomer() {
		List<ForecastCustomer> listForecastCustomer = this.forecastCustomerService.getLastForecastCustomer(new ServiceFeeProgram());
		assertNotNull(listForecastCustomer);
	}
	
	@Test
	public void testGetForecastCustomerbyServiceFeeProgram() {
		List<ForecastCustomer> listForecastCustomer = this.forecastCustomerService.getForecastCustomerbyServiceFeeProgram(new ServiceFeeProgram());
		assertNotNull(listForecastCustomer);
	}
	
	@Test
	public void testSave() {
		when(this.forecastCustomerDAO.getCurrentForecastNum()).thenReturn(1L);
		doNothing().when(this.forecastCustomerDAO).save(any(ForecastCustomer.class));
		List<ForecastCustomer> forecastCustomerlist = new ArrayList<ForecastCustomer>();
		ForecastCustomer forecastCustomer = new ForecastCustomer();
		forecastCustomerlist.add(forecastCustomer );
		this.forecastCustomerService.save(forecastCustomerlist);
		verify(this.forecastCustomerDAO, times(1)).save(any(ForecastCustomer.class));
	}

}
