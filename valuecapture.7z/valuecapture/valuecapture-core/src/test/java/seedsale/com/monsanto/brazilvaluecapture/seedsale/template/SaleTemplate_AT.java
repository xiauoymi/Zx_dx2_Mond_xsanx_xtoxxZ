package com.monsanto.brazilvaluecapture.seedsale.template;

import java.util.Collections;
import java.util.Date;
import java.util.List;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.monsanto.brazilvaluecapture.core.base.SystemTestFixture;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Address;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Customer;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.HeadOffice;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.ParticipantTypeEnum;
import com.monsanto.brazilvaluecapture.core.foundation.RandomTestData;
import com.monsanto.brazilvaluecapture.core.foundation.model.bean.StatusEnum;
import com.monsanto.brazilvaluecapture.core.foundation.service.BusinessException;
import com.monsanto.brazilvaluecapture.core.foundation.test.AbstractServiceIntegrationTests;
import com.monsanto.brazilvaluecapture.core.grower.PlayerTestData;
import com.monsanto.brazilvaluecapture.seedsale.harvest.HarvestTestData;
import com.monsanto.brazilvaluecapture.seedsale.harvest.model.bean.Harvest;
import com.monsanto.brazilvaluecapture.seedsale.product.ProductTestData;
import com.monsanto.brazilvaluecapture.seedsale.product.model.bean.Brand;
import com.monsanto.brazilvaluecapture.seedsale.product.model.bean.Product;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.Sale.SaleTypeEnum;
import com.monsanto.brazilvaluecapture.seedsale.template.model.bean.Price.PriceTypeEnum;
import com.monsanto.brazilvaluecapture.seedsale.template.model.bean.SaleTemplate;
import com.monsanto.brazilvaluecapture.seedsale.template.model.bean.SaleTemplateBillingMethodEnum;
import com.monsanto.brazilvaluecapture.seedsale.template.model.bean.SaleTemplateByPlantabilityEnum;
import com.monsanto.brazilvaluecapture.seedsale.template.model.dao.SaleTemplateDAO;

public class SaleTemplate_AT extends AbstractServiceIntegrationTests {

	@Autowired
	private SaleTemplateDAO saleTemplateDAO;
	
	private Harvest harvest2012;
	private Harvest harvest2011;
	private Product randomProduct;

	@Before
	public void init() {
		systemTestFixture = new SystemTestFixture(this);
		
		harvest2012 = HarvestTestData.createHarvest(systemTestFixture.soy, systemTestFixture.operationalYearOf2011,systemTestFixture.monsantoBr);
		getSession().saveOrUpdate(harvest2012);
		
		harvest2011 = HarvestTestData.createHarvest(systemTestFixture.soy, systemTestFixture.operationalYearOf2011,systemTestFixture.monsantoBr);
		getSession().saveOrUpdate(harvest2011);

		randomProduct = ProductTestData.createProduct(systemTestFixture.monsoy, systemTestFixture.soy, systemTestFixture.intacta, StatusEnum.ACTIVE, systemTestFixture.monsantoBr);
		getSession().saveOrUpdate(randomProduct);
		
	}

	@Test
	public void testDelete() throws BusinessException {
		SaleTemplate aNewSaleTemplate = createSaleTemplateWithOneFixPrice();
		saveAndFlush(aNewSaleTemplate);
		Assert.assertFalse("List should not be empty", saleTemplateDAO.selectByHarvest(harvest2011).isEmpty());
		getSession().clear();

		saleTemplateDAO.delete(aNewSaleTemplate);

		Assert.assertTrue("List should be empty", saleTemplateDAO.selectByHarvest(harvest2011).isEmpty());
	}
	
	@Test
	public void testInsert() throws BusinessException {
		SaleTemplate saleTemplateCreated = createSaleTemplateWithOneFixPrice();
		saleTemplateDAO.save(saleTemplateCreated);
		getSession().flush();
		Assert.assertNotNull(saleTemplateCreated.getId());
	}

	@Test
	public void testSelectAllSaleTemplateEqualsUpdate() {
		SaleTemplate saleTemplate1 = new SaleTemplate(harvest2011,
				RandomTestData.createRandomString(10), null, Boolean.FALSE,
				SaleTemplateByPlantabilityEnum.BY_PRODUCT, new Date(), new Date(), SaleTypeEnum.SALE_SEED, SaleTemplateBillingMethodEnum.DIRECT);
		getSession().saveOrUpdate(saleTemplate1);

		SaleTemplate saleTemplate2 =  new SaleTemplate(harvest2012,
				RandomTestData.createRandomString(10), null, Boolean.FALSE,
				SaleTemplateByPlantabilityEnum.BY_PRODUCT, new Date(), new Date(), SaleTypeEnum.SALE_SEED, SaleTemplateBillingMethodEnum.DIRECT);
		getSession().saveOrUpdate(saleTemplate2);

		// creating a new saleTemplate
		SaleTemplate saleTemplate = new SaleTemplate();
		saleTemplate.setId(saleTemplate1.getId());
		saleTemplate.setHarvest(saleTemplate2.getHarvest());
		saleTemplate.setDescription(saleTemplate2.getDescription());

		List<SaleTemplate> saleTemplateList = saleTemplateDAO
				.selectAllSaleTemplateEquals(saleTemplate);

		Assert.assertNotNull(saleTemplate);
		Assert.assertFalse(saleTemplateList.isEmpty());
		Assert.assertTrue(saleTemplateList.size() == 1);

	}

	@Test
	public void testSelectAllSaleTemplateEqualsInsert() {
		SaleTemplate aNewSaleTemplate = SaleTemplateTestData.createSaleTemplateTypeSeedSale(harvest2011);
		saveAndFlush(aNewSaleTemplate);
		aNewSaleTemplate.setId(null);

		List<SaleTemplate> saleTemplateList = saleTemplateDAO.selectAllSaleTemplateEquals(aNewSaleTemplate);

		Assert.assertFalse("List should not be empty", saleTemplateList.isEmpty());
	}

	@Test
	public void testSelectByProduct() throws BusinessException {
		SaleTemplate saleTemplateCreated = createSaleTemplateWithOneFixPrice();
		saveAndFlush(saleTemplateCreated);

		saleTemplateCreated.setProducts(Collections.singleton(randomProduct));

		// saving association
		saleTemplateDAO.save(saleTemplateCreated);

		// searching
		List<SaleTemplate> list = saleTemplateDAO
				.selectByProduct(randomProduct);

		// Then result is not null
		Assert.assertNotNull(list);
		Assert.assertFalse(list.isEmpty());
		Assert.assertTrue(list.size() >= 1);
	}

	@Test
	public void testMappingTemplateWithOneProduct() throws BusinessException {
		SaleTemplate saleTemplateCreated = createSaleTemplateWithOneFixPrice();
		saveAndFlush(saleTemplateCreated);
		
		Assert.assertNotNull(saleTemplateCreated);
		Assert.assertNotNull(saleTemplateCreated.getId());

		// creating a new brand
		Brand brand = new Brand("Syngenta", saleTemplateCreated.getHarvest()
				.getCompany(), StatusEnum.ACTIVE);
		getSession().save(brand);

		Assert.assertNotNull(brand);
		Assert.assertNotNull(brand.getId());

		// creating a new product
		Product product = new Product();
		product.setCrop(saleTemplateCreated.getHarvest().getCrop());
		product.setBrand(brand);
		product.setTechnology(saleTemplateCreated.getHarvest().getCompany().getTechnologies().iterator().next());
		product.setDescription("RR power");
		product.setStatus(StatusEnum.ACTIVE);

		getSession().save(product);

		Assert.assertNotNull(product);
		Assert.assertNotNull(product.getId());

		Long idSaleTemplate = saleTemplateCreated.getId();

		getSession().flush();

		// removing sale template Hibernate's session
		getSession().evict(saleTemplateCreated);
		// removing product Hibernate's session
		getSession().evict(product);

		// association template with product
		saleTemplateCreated.addProduct(product);
		product.addSaleTemplate(saleTemplateCreated);

		getSession().saveOrUpdate(saleTemplateCreated);

		Assert.assertEquals(idSaleTemplate, saleTemplateCreated.getId());
		Assert.assertFalse(saleTemplateCreated.getProducts().isEmpty());

		getSession().flush();
		// removing sale template Hibernate's session
		getSession().evict(saleTemplateCreated);

		SaleTemplate st = new SaleTemplate();
		st.setDescription(saleTemplateCreated.getDescription());
		st.setId(saleTemplateCreated.getId());
		st.setProducts(null);
		st.setStartDate(new Date());
		st.setEndDate(new Date());
		st.setPlantabilityBy(SaleTemplateByPlantabilityEnum.BY_PRODUCT);
		st.setSaleType(SaleTypeEnum.SALE_SEED);
		st.setBillingMethod(SaleTemplateBillingMethodEnum.DIRECT);
		getSession().saveOrUpdate(st);

		getSession().flush();
		
		getSession().evict(st);
		
		st = null;
		
		st = (SaleTemplate) getSession().get(SaleTemplate.class, idSaleTemplate);

		Assert.assertTrue(st.getProducts().isEmpty());
	}
	
	@Test
	public void testMappingTemplateWithManyProducts() throws BusinessException {
		SaleTemplate saleTemplateCreated = createSaleTemplateWithOneFixPrice();
		saveAndFlush(saleTemplateCreated);
		
		Assert.assertNotNull(saleTemplateCreated);
		Assert.assertNotNull(saleTemplateCreated.getId());

		// creating a new brand
		Brand brand = new Brand("Syngenta", saleTemplateCreated.getHarvest()
				.getCompany(), StatusEnum.ACTIVE);
		getSession().save(brand);

		Assert.assertNotNull(brand);
		Assert.assertNotNull(brand.getId());

		// creating a new product
		Product product = new Product();
		product.setCrop(saleTemplateCreated.getHarvest().getCrop());
		product.setBrand(brand);
		product.setTechnology(saleTemplateCreated.getHarvest().getCrop()
				.getCompany().getTechnologies().iterator().next());
		product.setDescription("RR power");
		product.setStatus(StatusEnum.ACTIVE);

		getSession().save(product);

		Assert.assertNotNull(product);
		Assert.assertNotNull(product.getId());

		// creating a new product
		Product product2 = new Product();
		product2.setCrop(saleTemplateCreated.getHarvest().getCrop());
		product2.setBrand(brand);
		product2.setTechnology(saleTemplateCreated.getHarvest().getCrop()
				.getCompany().getTechnologies().iterator().next());
		product2.setDescription("RR ultra");
		product2.setStatus(StatusEnum.ACTIVE);

		getSession().save(product2);

		Assert.assertNotNull(product2);
		Assert.assertNotNull(product2.getId());

		Long idSaleTemplate = saleTemplateCreated.getId();

		getSession().flush();

		// removing sale template Hibernate's session
		getSession().evict(saleTemplateCreated);
		// removing product Hibernate's session
		getSession().evict(product);

		// association template with product
		saleTemplateCreated.addProduct(product);
		saleTemplateCreated.addProduct(product2);
		product.addSaleTemplate(saleTemplateCreated);
		product2.addSaleTemplate(saleTemplateCreated);

		getSession().saveOrUpdate(saleTemplateCreated);

		Assert.assertEquals(idSaleTemplate, saleTemplateCreated.getId());
		Assert.assertFalse(saleTemplateCreated.getProducts().isEmpty());

		getSession().flush();
		// removing sale template Hibernate's session
		getSession().evict(saleTemplateCreated);

		SaleTemplate st = new SaleTemplate();
		st.setDescription(saleTemplateCreated.getDescription());
		st.setId(saleTemplateCreated.getId());

		getSession().saveOrUpdate(saleTemplateCreated);

		getSession().flush();

		Assert.assertFalse(saleTemplateCreated.getProducts().isEmpty());
		Assert.assertTrue(saleTemplateCreated.getProducts().size() == 2);
		
		for (Product p : saleTemplateCreated.getProducts()) {
			
			Assert.assertTrue(product.equals(p) || product2.equals(p));
		}
	}
	
	@Test
	public void tesTemplateWithProductsChange() throws BusinessException {
		SaleTemplate saleTemplateCreated = createSaleTemplateWithOneFixPrice();
		saveAndFlush(saleTemplateCreated);
		
		Assert.assertNotNull(saleTemplateCreated);
		Assert.assertNotNull(saleTemplateCreated.getId());

		// creating a new brand
		Brand brand = new Brand("Syngenta", saleTemplateCreated.getHarvest()
				.getCompany(), StatusEnum.ACTIVE);
		getSession().save(brand);

		Assert.assertNotNull(brand);
		Assert.assertNotNull(brand.getId());

		// creating a new product
		Product product = new Product();//TODO company
		product.setCrop(saleTemplateCreated.getHarvest().getCrop());
		product.setBrand(brand);
		product.setTechnology(saleTemplateCreated.getHarvest().getCrop()
				.getCompany().getTechnologies().iterator().next());
		product.setDescription("RR power");
		product.setStatus(StatusEnum.ACTIVE);

		getSession().save(product);

		Assert.assertNotNull(product);
		Assert.assertNotNull(product.getId());

		// creating a new product
		Product product2 = new Product();
		product2.setCrop(saleTemplateCreated.getHarvest().getCrop());
		product2.setBrand(brand);
		product2.setTechnology(saleTemplateCreated.getHarvest().getCrop()
				.getCompany().getTechnologies().iterator().next());
		product2.setDescription("RR ultra");
		product2.setStatus(StatusEnum.ACTIVE);

		getSession().save(product2);

		Assert.assertNotNull(product2);
		Assert.assertNotNull(product2.getId());

		Long idSaleTemplate = saleTemplateCreated.getId();

		getSession().flush();

		// removing sale template Hibernate's session
		getSession().evict(saleTemplateCreated);
		// removing product Hibernate's session
		getSession().evict(product);

		// association template with product
		saleTemplateCreated.addProduct(product);
		
		product.addSaleTemplate(saleTemplateCreated);

		getSession().saveOrUpdate(saleTemplateCreated);

		Assert.assertEquals(idSaleTemplate, saleTemplateCreated.getId());
		Assert.assertFalse(saleTemplateCreated.getProducts().isEmpty());

		getSession().flush();
		// removing sale template Hibernate's session
		getSession().evict(saleTemplateCreated);

		SaleTemplate st = new SaleTemplate();
		st.setDescription(saleTemplateCreated.getDescription());
		st.setId(saleTemplateCreated.getId());
		st.setStartDate(new Date());
		st.setEndDate(new Date());
		st.setPlantabilityBy(SaleTemplateByPlantabilityEnum.BY_PRODUCT);
		st.setSaleType(SaleTypeEnum.LICENSE_SEED);
		st.setBillingMethod(SaleTemplateBillingMethodEnum.DIRECT);
		
		getSession().saveOrUpdate(st);
		
		st.getProducts().clear();
		
		st.addProduct(product2);
		product2.addSaleTemplate(st);

		getSession().flush();

		Assert.assertFalse(st.getProducts().isEmpty());
		Assert.assertFalse(st.getProducts().size() == 2);
		Assert.assertEquals(st.getProducts().iterator().next(), product2);
	}
	
	@Test
	public void testMappingProductWithOneTemplate() throws BusinessException {
		SaleTemplate saleTemplateCreated = createSaleTemplateWithOneFixPrice();
		saveAndFlush(saleTemplateCreated);
		
		Assert.assertNotNull(saleTemplateCreated);
		Assert.assertNotNull(saleTemplateCreated.getId());

		// creating a new brand
		Brand brand = new Brand("Syngenta", saleTemplateCreated.getHarvest()
				.getCompany(), StatusEnum.ACTIVE);
		getSession().save(brand);

		Assert.assertNotNull(brand);
		Assert.assertNotNull(brand.getId());

		// creating a new product
		Product product = new Product();
		product.setCrop(saleTemplateCreated.getHarvest().getCrop());
		product.setBrand(brand);
		product.setTechnology(saleTemplateCreated.getHarvest().getCrop()
				.getCompany().getTechnologies().iterator().next());
		product.setDescription("RR power");
		product.setStatus(StatusEnum.ACTIVE);

		getSession().save(product);

		Assert.assertNotNull(product);
		Assert.assertNotNull(product.getId());

		Long idProduct = product.getId();

		getSession().flush();

		// removing sale template Hibernate's session
		getSession().evict(saleTemplateCreated);
		// removing product Hibernate's session
		getSession().evict(product);

		// association template with product
		saleTemplateCreated.addProduct(product);
		product.addSaleTemplate(saleTemplateCreated);

		getSession().saveOrUpdate(product);

		Assert.assertEquals(idProduct, product.getId());
		Assert.assertFalse(product.getSaleTemplates().isEmpty());

		getSession().flush();
		// removing sale template Hibernate's session
		getSession().evict(product);

		Product p = new Product();
		p.setDescription(product.getDescription());
		p.setId(product.getId());
		p.setBrand(product.getBrand());
		p.setCrop(product.getCrop());
		p.setTechnology(product.getTechnology());
		p.setStatus(product.getStatus());

		getSession().saveOrUpdate(p);

		getSession().flush();

		Assert.assertTrue(p.getSaleTemplates().isEmpty());
	}


	private SaleTemplate createSaleTemplateWithOneFixPrice() throws BusinessException {
		SaleTemplate saleTemplateCreated = SaleTemplateTestData.createSaleTemplateTypeSeedSale(harvest2011);
		saleTemplateCreated.addPrices(PriceTestData.createPrice(PriceTypeEnum.FIX, saleTemplateCreated, harvest2012.getCrop()
						.getCompany().getTechnologies().iterator().next()));
		return saleTemplateCreated;
	}

    @Test
    public void when_has_products_must_return_true() throws BusinessException  {

		SaleTemplate saleTemplateCreated = createSaleTemplateWithOneFixPrice();
		saveAndFlush(saleTemplateCreated);

		saleTemplateCreated.setProducts(Collections.singleton(randomProduct));

		// saving association
		saleTemplateDAO.save(saleTemplateCreated);
        
        Assert.assertTrue(saleTemplateDAO.hasProducts(saleTemplateCreated));
    }
    
    @Test
    public void when_has_not_products_must_return_false() throws BusinessException  {
        
		SaleTemplate saleTemplateCreated = createSaleTemplateWithOneFixPrice();
		saveAndFlush(saleTemplateCreated);

		// saving association
		saleTemplateDAO.save(saleTemplateCreated);
        
        Assert.assertFalse(saleTemplateDAO.hasProducts(saleTemplateCreated));
    }
	
    @Test
    public void when_has_headoffices_must_return_true() throws BusinessException  {

        Address address = PlayerTestData.createAddress(systemTestFixture.matoGrossoDoSul, systemTestFixture.vilaNova,
                systemTestFixture.brazil);
		
        Customer agroesteCustomer = new Customer("AGROESTE", PlayerTestData.createDocument(systemTestFixture.documentCnpj,
                "123456"), address, RandomTestData.createRandomString(5));
        getSession().saveOrUpdate(agroesteCustomer);
        
        HeadOffice randomHeadOffice = new HeadOffice(agroesteCustomer, agroesteCustomer, ParticipantTypeEnum.POD, systemTestFixture.soy, systemTestFixture.monsantoBr);	
        getSession().saveOrUpdate(randomHeadOffice);
        
		SaleTemplate saleTemplateCreated = createSaleTemplateWithOneFixPrice();
		saveAndFlush(saleTemplateCreated);

		saleTemplateCreated.setHeadOffices(Collections.singleton(randomHeadOffice));

		// saving association
		saleTemplateDAO.save(saleTemplateCreated);
        
        Assert.assertTrue(saleTemplateDAO.hasHeadOffices(saleTemplateCreated));
    }
    
    @Test
    public void when_has_saleItens_must_return_true() throws BusinessException  {

        Address address = PlayerTestData.createAddress(systemTestFixture.matoGrossoDoSul, systemTestFixture.vilaNova,
                systemTestFixture.brazil);
        
        Customer agroesteCustomer = new Customer("AGROESTE", PlayerTestData.createDocument(systemTestFixture.documentCnpj,
                "123456"), address, RandomTestData.createRandomString(5));
        getSession().saveOrUpdate(agroesteCustomer);
        
        HeadOffice randomHeadOffice = new HeadOffice(agroesteCustomer, agroesteCustomer, ParticipantTypeEnum.POD, systemTestFixture.soy, systemTestFixture.monsantoBr); 
        getSession().saveOrUpdate(randomHeadOffice);
        
        SaleTemplate saleTemplateCreated = createSaleTemplateWithOneFixPrice();
        saveAndFlush(saleTemplateCreated);

        saleTemplateCreated.setHeadOffices(Collections.singleton(randomHeadOffice));

        // saving association
        saleTemplateDAO.save(saleTemplateCreated);
        
        Assert.assertFalse(saleTemplateDAO.hasSaleTemplateOfSaleItem(saleTemplateCreated));
    }
    
    @Test
    public void when_has_not_headoffices_must_return_false() throws BusinessException  {
        
		SaleTemplate saleTemplateCreated = createSaleTemplateWithOneFixPrice();
		saveAndFlush(saleTemplateCreated);

		// saving association
		saleTemplateDAO.save(saleTemplateCreated);
        
        Assert.assertFalse(saleTemplateDAO.hasHeadOffices(saleTemplateCreated));
    }

}
