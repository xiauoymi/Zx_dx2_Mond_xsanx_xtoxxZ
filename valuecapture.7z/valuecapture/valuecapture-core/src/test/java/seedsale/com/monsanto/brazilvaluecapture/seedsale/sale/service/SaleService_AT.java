package com.monsanto.brazilvaluecapture.seedsale.sale.service;

import com.monsanto.brazilvaluecapture.core.account.model.bean.Account;
import com.monsanto.brazilvaluecapture.core.account.model.bean.Account.AccountType;
import com.monsanto.brazilvaluecapture.core.account.model.bean.Account.OwnerType;
import com.monsanto.brazilvaluecapture.core.account.model.bean.AccountDTO;
import com.monsanto.brazilvaluecapture.core.account.model.bean.BalanceDTO;
import com.monsanto.brazilvaluecapture.core.account.model.bean.ManualCreditTransactionType;
import com.monsanto.brazilvaluecapture.core.account.service.impl.AccountService;
import com.monsanto.brazilvaluecapture.core.base.CompanyTestData;
import com.monsanto.brazilvaluecapture.core.base.CropTestData;
import com.monsanto.brazilvaluecapture.core.base.SystemTestFixture;
import com.monsanto.brazilvaluecapture.core.base.TechnologyTestData;
import com.monsanto.brazilvaluecapture.core.base.model.bean.*;
import com.monsanto.brazilvaluecapture.core.base.service.BaseService;
import com.monsanto.brazilvaluecapture.core.base.service.ConstraintException;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.*;
import com.monsanto.brazilvaluecapture.core.customer.service.CustomerNotAllowedException;
import com.monsanto.brazilvaluecapture.core.customer.service.CustomerNotFoundException;
import com.monsanto.brazilvaluecapture.core.foundation.RandomTestData;
import com.monsanto.brazilvaluecapture.core.foundation.service.BusinessException;
import com.monsanto.brazilvaluecapture.core.foundation.service.EntityNotFoundException;
import com.monsanto.brazilvaluecapture.core.foundation.service.IndustrySystemOperationException;
import com.monsanto.brazilvaluecapture.core.foundation.test.AbstractServiceIntegrationTests;
import com.monsanto.brazilvaluecapture.core.foundation.test.dbunit.DbUnitHelper;
import com.monsanto.brazilvaluecapture.core.foundation.util.ConstraintViolation;
import com.monsanto.brazilvaluecapture.core.foundation.util.security.EnvironmentSpecificPropertyReader;
import com.monsanto.brazilvaluecapture.core.grower.PlayerTestData;
import com.monsanto.brazilvaluecapture.core.grower.model.bean.Agreement;
import com.monsanto.brazilvaluecapture.core.grower.model.bean.Agreement.AgreementStatusEnum;
import com.monsanto.brazilvaluecapture.core.grower.model.bean.AgreementTemplate;
import com.monsanto.brazilvaluecapture.core.grower.model.bean.Grower;
import com.monsanto.brazilvaluecapture.core.grower.service.GrowerNotFoundException;
import com.monsanto.brazilvaluecapture.core.regionalization.CountriesHolder;
import com.monsanto.brazilvaluecapture.core.revenue.model.bean.AdditionalCondition.ConditionEnum;
import com.monsanto.brazilvaluecapture.core.revenue.model.bean.*;
import com.monsanto.brazilvaluecapture.core.user.AccessControlTestFixture;
import com.monsanto.brazilvaluecapture.core.user.model.bean.HierarchyLevel;
import com.monsanto.brazilvaluecapture.core.user.model.bean.ItsUser.UserTypeEnum;
import com.monsanto.brazilvaluecapture.core.user.model.bean.UserContext;
import com.monsanto.brazilvaluecapture.core.user.model.bean.UserContract;
import com.monsanto.brazilvaluecapture.core.user.model.bean.UserDecorator;
import com.monsanto.brazilvaluecapture.core.user.service.DocumentMismatchException;
import com.monsanto.brazilvaluecapture.core.user.service.ManualCreditConstraintException;
import com.monsanto.brazilvaluecapture.core.user.service.UserService;
import com.monsanto.brazilvaluecapture.seedsale.billing.model.bean.Billing;
import com.monsanto.brazilvaluecapture.seedsale.billing.model.bean.BillingDTO;
import com.monsanto.brazilvaluecapture.seedsale.billing.model.bean.CreditStatus;
import com.monsanto.brazilvaluecapture.seedsale.billing.model.bean.PaymentStatus;
import com.monsanto.brazilvaluecapture.seedsale.billing.model.bean.PaymentStatusGroup.PaymentStatusAll;
import com.monsanto.brazilvaluecapture.seedsale.billing.model.dao.BillingFilter;
import com.monsanto.brazilvaluecapture.seedsale.billing.service.BillingConstraintViolationException;
import com.monsanto.brazilvaluecapture.seedsale.harvest.HarvestTestData;
import com.monsanto.brazilvaluecapture.seedsale.harvest.model.bean.Harvest;
import com.monsanto.brazilvaluecapture.seedsale.harvest.model.bean.Plantability;
import com.monsanto.brazilvaluecapture.seedsale.product.model.bean.Product;
import com.monsanto.brazilvaluecapture.seedsale.sale.SaleTestFixture;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.ManualReleaseCredit;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.NoValueByPlantability;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.Sale;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.Sale.SaleTypeEnum;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.SaleItem;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.dao.ManualReleaseCreditFilter;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.dao.RevenueSaleItemFilter;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.dao.SaleFilter;
import com.monsanto.brazilvaluecapture.seedsale.template.PriceTestData;
import com.monsanto.brazilvaluecapture.seedsale.template.SaleTemplateTestData;
import com.monsanto.brazilvaluecapture.seedsale.template.model.bean.*;
import com.monsanto.brazilvaluecapture.seedsale.template.model.bean.Price.PriceTypeEnum;
import com.monsanto.brazilvaluecapture.seedsale.template.model.bean.Price.ReleaseCreditTypeEnum;
import com.monsanto.brazilvaluecapture.seedsale.template.model.bean.RetributionFee.RetributionSourceType;
import junit.framework.Assert;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.math.BigDecimal;
import java.util.*;

import static org.mockito.Mockito.*;

public class SaleService_AT extends AbstractServiceIntegrationTests {

    @Autowired
    private SaleService saleService;

    @Autowired
    private BaseService baseService;

    private AccessControlTestFixture accessControlIntent;

    private SaleItemFactory saleItemFactory;

    @Autowired
    private AccountService accountService;

    @Autowired
    private UserService userServices;

    @Autowired
    private CountriesHolder countriesHolder;

    private SaleBuilder builder;
    
    private SaleTestData saleFactory;

    @Before
    public void init() throws BusinessException {
        systemTestFixture = new SystemTestFixture(this);
        accessControlTestFixture = new AccessControlTestFixture(systemTestFixture);
        accessControlIntent = new AccessControlTestFixture(this, systemTestFixture);
        saleTestFixture = new SaleTestFixture(this, systemTestFixture);
        saleItemFactory = SaleItemFactory.getInstance(systemTestFixture.matoGrossoDoSul, saleTestFixture.plantabilitiesSelector);

        createChargeConsolidateTypes();
        //Added for LASVC to return a country brazil
        String configuredHost = "CONFIGURED_AND_REQUESTED_HOST_SAME";
        EnvironmentSpecificPropertyReader env = mock(EnvironmentSpecificPropertyReader.class);
        countriesHolder.setEnvironmentSpecificPropertyReader(env);
        when(env.getEnvironmentSpecificProperty("host_name.argentina", null)).thenReturn("other");
        when(env.getEnvironmentSpecificProperty("host_name.brazil", null)).thenReturn(configuredHost);
        when(env.getEnvironmentSpecificProperty("host_name.paraguay", null)).thenReturn("another");

        countriesHolder.initialize();
        try {
            countriesHolder.resolveCountry(configuredHost);
        } catch (IllegalStateException ex) {
        }
        
        saleFactory = new SaleTestData(systemTestFixture.regionSaoPaulo2012);
    }

    @Test
    public void sanity_check() {
        Assert.assertNotNull("SaleService should not be null", saleService);
    }

    @Test(expected = GrowerNotFoundException.class)
    public void when_growerNotExist_getGrowerBy_shouldBeThrowDistributorNotFoundException() throws GrowerNotFoundException {
        saleService.getGrowerBy("12345");
        Assert.fail("Grower should not be there.");
    }

    @Test
    public void when_growerExist_getGrowerBy_shouldBeReturnSucess() throws GrowerNotFoundException {
        Grower grower = saleService.getGrowerBy(SaleTestFixture.CHICO_CNPJ);
        Assert.assertNotNull("Chico Bento should have been found", grower);
        Assert.assertEquals("Should be the Chico Bento CNPJ", saleTestFixture.chicoBento.getDocumentValue(), grower.getDocumentValue());
    }

    @Test
    public void when_distributorExist_getDistributorBy_shouldBeReturnSucess()
            throws CustomerNotFoundException, CustomerNotAllowedException,
            DocumentMismatchException {

        accessControlIntent.superUser.setContextCompany(systemTestFixture.monsantoBr);
        accessControlIntent.superUser.setContextCrop(systemTestFixture.soy);
        Customer customerFound = saleService.getAllowedBy(SaleTestFixture.THE_CARGIL_CNPJ_WITHOUT_MASK, null, null, ParticipantTypeEnum.DISTRIBUTOR, accessControlIntent.superUser);

        Assert.assertNotNull("Cargil should have been found", customerFound);
        Assert.assertEquals("Should be the cargil CNPJ", saleTestFixture.matrixCargil.getDocumentValue(), customerFound.getDocumentValue());
        logger.info("Number of states of country of distributor: " + customerFound.getStatesOfCountry());
    }

    @Test
    public void when_distributorExist_getStates_shouldBeReturnStatesListOfDistributorCountry()
            throws CustomerNotFoundException, CustomerNotAllowedException,
            DocumentMismatchException {
        accessControlIntent.superUser.setContextCompany(systemTestFixture.monsantoBr);
        accessControlIntent.superUser.setContextCrop(systemTestFixture.soy);
        Customer customerFound = saleService.getAllowedBy(SaleTestFixture.THE_CARGIL_CNPJ_WITHOUT_MASK, null, null, ParticipantTypeEnum.DISTRIBUTOR, accessControlIntent.superUser);

        Assert.assertEquals("Should be the cargil Country", customerFound.getCountry(), systemTestFixture.brazil);
    }

    @Test
    public void given_two_different_harvests_getActivityHarvests_of_monsanto_soy_should_return_a_list_with_one_harvest() {
        Company bayer = CompanyTestData.createCompany(systemTestFixture.brazil);
        bayer.setDescription("Bayer");
        saveAndFlush(bayer);
        Crop cotton = CropTestData.createCrop(bayer, systemTestFixture.brazil);
        saveAndFlush(cotton);
        Harvest harvest = HarvestTestData.createHarvest(cotton, this.systemTestFixture.operationalYearOf2011, bayer);
        saveAndFlush(harvest);
        Harvest monsantoHarvest = HarvestTestData.createHarvest(this.systemTestFixture.soy, this.systemTestFixture.operationalYearOf2011, systemTestFixture.monsantoBr);
        saveAndFlush(monsantoHarvest);

        List<Company> companies = new ArrayList<Company>();
        companies.add(bayer);

        List<Harvest> harvests = saleService.getHarvestsActive(companies, cotton);

        Assert.assertEquals("Should have only one harvest of cotton to bayer", 1, harvests.size());
    }

    @Test
    public void when_i_get_harvest_in_vigor_by_saleTemplateAndMatrix_thenReturnAllHarvest() throws BusinessException {

        Customer matrixCargil = new Customer(
                RandomTestData.createRandomString(5),
                PlayerTestData.createDocument(systemTestFixture.documentCnpj,
                        "22.333.999/9999/99388"), new Address(
                "Avenue of Fools", systemTestFixture.campinas,
                systemTestFixture.matoGrossoDoSul,
                systemTestFixture.brazil,
                RandomTestData.createRandomString(6)), RandomTestData.createRandomString(5));
        Customer affiliate = new Customer(RandomTestData.createRandomString(5),
                PlayerTestData.createDocument(systemTestFixture.documentCnpj,
                        "123456789"), new Address("Avenue of Fools",
                systemTestFixture.campinas,
                systemTestFixture.matoGrossoDoSul,
                systemTestFixture.brazil,
                RandomTestData.createRandomString(6)), RandomTestData.createRandomString(5));
        saveAndFlush(matrixCargil);
        saveAndFlush(affiliate);

        Crop suggar = CropTestData.createCrop(systemTestFixture.monsantoBr, systemTestFixture.brazil);
        saveAndFlush(suggar);

        Harvest harvest = HarvestTestData.createHarvest(suggar, this.systemTestFixture.operationalYearOf2011, systemTestFixture.monsantoBr);
        saveAndFlush(harvest);

        Contract contractCargil = new Contract(RandomTestData.createRandomString(5), matrixCargil, ParticipantTypeEnum.DISTRIBUTOR, suggar, systemTestFixture.monsantoBr);
        saveAndFlush(contractCargil);

        HeadOffice headOfficeCargil = new HeadOffice(matrixCargil, matrixCargil, ParticipantTypeEnum.DISTRIBUTOR, suggar, systemTestFixture.monsantoBr);
        HeadOffice headOfficeAffiliate = new HeadOffice(affiliate, matrixCargil, ParticipantTypeEnum.DISTRIBUTOR, suggar, systemTestFixture.monsantoBr);

        saveAndFlush(headOfficeCargil);
        saveAndFlush(headOfficeAffiliate);

        SaleTemplate st1 = createAConsistentSaleTemplateWithHeadOffice();
//		st1.setStartDate(randomDate(Calendar.MONTH, 1));
        st1.setHarvest(harvest);
        st1.addHeadOffice(headOfficeCargil);
        saveAndFlush(st1);
//		SaleTemplate st2 = createAConsistentSaleTemplateWithHeadOffice();

        List<Company> companies = new ArrayList<Company>();
        companies.add(systemTestFixture.monsantoBr);

        List<Harvest> harvests = saleService.selectHarvestsInVigorBy(companies, suggar, affiliate, new Date(), SaleTypeEnum.SALE_SEED);

        Assert.assertEquals("Should have only one sale template", 1, harvests.size());
    }

    @Test
    public void given_two_saleTemplates_with_different_types_getSaleTemplatesOf_for_licenseSeedSaleType_shouldReturnAListWithOneSaleTemplate_with_licenseSeedSaleType() throws BusinessException {

        SaleTemplate saleTemplateForLicenseSeed = createAConsistentSaleTemplateWithHeadOffice();
        saleTemplateForLicenseSeed.setSaleType(SaleTypeEnum.LICENSE_SEED);
        saleTemplateForLicenseSeed.setDescription(RandomTestData.createRandomString(10));
        saveAndFlush(saleTemplateForLicenseSeed);

        createAConsistentSaleTemplateWithHeadOffice();

        List<SaleTemplate> templates = saleService.getSaleTemplatesOf(saleTestFixture.headOfficeCargil, saleTestFixture.harvest2011SoyMonsanto, new Date(), SaleTypeEnum.LICENSE_SEED);

        Assert.assertEquals("Should have only one sale template", 1, templates.size());
        Assert.assertEquals("Sales Type should be LICENSE SEED", SaleTypeEnum.LICENSE_SEED, templates.get(0).getSaleType());
    }

    @Test
    public void when_i_search_a_saletemplate_LicenseSeedSaleType_getSaleTemplatesOf_shouldBeReturnAnEmptyList() throws BusinessException {

        createAConsistentSaleTemplateWithHeadOffice();

        List<SaleTemplate> templates = saleService.getSaleTemplatesOf(saleTestFixture.headOfficeCargil, saleTestFixture.harvest2011SoyMonsanto, new Date(), SaleTypeEnum.LICENSE_SEED);
        Assert.assertEquals("Should have no templates", 0, templates.size());
    }

    @Test
    public void when_distributorHasNotSaleTemplateAssociated_getSaleTemplatesOf_shouldBeReturnAnEmptyList() {
        Harvest harvest = HarvestTestData.createHarvest(this.systemTestFixture.soy, this.systemTestFixture.operationalYearOf2011, systemTestFixture.monsantoBr);
        saveAndFlush(harvest);
        SaleTemplate saleTemplate = SaleTemplateTestData.createSaleTemplateTypeSeedSale(harvest);
        saveAndFlush(saleTemplate);

        List<SaleTemplate> templates = saleService.getSaleTemplatesOf(saleTestFixture.headOfficeCargil, harvest, new Date(), SaleTypeEnum.SALE_SEED);

        Assert.assertEquals("Should have no templates", 0, templates.size());
    }

    @Test
    public void when_distributorHasOneSaleTemplateAssociated_getSaleTemplatesOf_shouldBeReturnAListWithOneSaleTemplate() throws BusinessException {

        createAConsistentSaleTemplateWithHeadOffice();

        List<SaleTemplate> templates = saleService.getSaleTemplatesOf(saleTestFixture.headOfficeCargil, saleTestFixture.harvest2011SoyMonsanto, new Date(), SaleTypeEnum.SALE_SEED);

        Assert.assertEquals("Should have one template", 1, templates.size());

        SaleTemplate theTemplate = templates.get(0);
        Assert.assertEquals("Company of SaleTemplate should have one technology", 3, theTemplate.getTechnologiesOfCompany().size());
        Assert.assertEquals("Company of SaleTemplate should have two brands", 1, theTemplate.getBrandsOfCompany().size());
    }

    @Test
    public void when_distributorHasOneSaleTemplateAssociated_getSaleTemplatesOf_shouldBeReturnTheSaleTemplateWithYourPrice() throws BusinessException {
        SaleTemplate saleTemplate = createAConsistentSaleTemplateWithHeadOffice();
        List<SaleTemplate> templates = saleService.getSaleTemplatesOf(saleTestFixture.headOfficeCargil, saleTestFixture.harvest2011SoyMonsanto, new Date(), SaleTypeEnum.SALE_SEED);
        Assert.assertEquals("Should have one template", 1, templates.size());

        SaleTemplate theTemplate = templates.get(0);
        Price intactaOnTheTemplate = theTemplate.getPriceOf(this.systemTestFixture.intacta);
        Assert.assertEquals("Template should have the price associated with Intacta technology", PriceTestData.createPrice(PriceTypeEnum.FIX, saleTemplate, this.systemTestFixture.intacta), intactaOnTheTemplate);
    }

    @Test
    public void when_consistentSaleTemplate_getSaleTemplatesOf_shouldBeReturnAFixPriceWithARoyaltValueAndDueDate() throws BusinessException {
        createAConsistentSaleTemplateWithHeadOffice();

        List<SaleTemplate> templates = saleService.getSaleTemplatesOf(saleTestFixture.headOfficeCargil, saleTestFixture.harvest2011SoyMonsanto, new Date(), SaleTypeEnum.SALE_SEED);
        Assert.assertEquals("Should have one template", 1, templates.size());

        SaleTemplate theTemplate = templates.get(0);
        Price intactaPrice = theTemplate.getPriceOf(this.systemTestFixture.intacta);
        Assert.assertEquals("Price should have one royalt value", 1, intactaPrice.getRoyaltyValues().size());
        Assert.assertEquals("Price should have one due date", 1, intactaPrice.getDueDates().size());
    }

    @Test
    public void when_saleTemplateHasOneNoValuePrice_getSaleTemplatesOf_shouldBeReturnOneSaleTemplateWithNoValuePrice() throws BusinessException {
        Technology java = TechnologyTestData.createTechnology(this.systemTestFixture.monsantoBr);
        java.setDescription("Java");
        saveAndFlush(java);

        Harvest exclusiveHarvest = HarvestTestData.createHarvest(systemTestFixture.soy, systemTestFixture.operationalYearOf2011, systemTestFixture.monsantoBr);
        saveAndFlush(exclusiveHarvest);
        SaleTemplate saleTemplate = SaleTemplateTestData.createSaleTemplateTypeSeedSale(exclusiveHarvest);
        saleTemplate.addHeadOffice(saleTestFixture.headOfficeCargil);
        Price noValuePrice = PriceTestData.createPrice(PriceTypeEnum.NO_VALUE, saleTemplate, java);
        saveAndFlush(saleTemplate);

        List<SaleTemplate> templates = saleService.getSaleTemplatesOf(saleTestFixture.headOfficeCargil, exclusiveHarvest, new Date(), SaleTypeEnum.SALE_SEED);
        Assert.assertEquals("Should have one template", 1, templates.size());

        SaleTemplate theTemplate = templates.get(0);
        Price javaPrice = theTemplate.getPriceOf(java);
        Assert.assertEquals("Price should be NoValue", noValuePrice, javaPrice);
    }

    @Test(expected = UnsupportedOperationException.class)
    public void when_consistentSaleTemplate_getSaleTemplatesOf_shouldBeReturnAFreePriceWithouARoyaltValueAndWithDueDate() throws BusinessException {
        createAConsistentSaleTemplateWithHeadOffice();

        List<SaleTemplate> templates = saleService.getSaleTemplatesOf(saleTestFixture.headOfficeCargil, saleTestFixture.harvest2011SoyMonsanto, new Date(), SaleTypeEnum.SALE_SEED);
        Assert.assertEquals("Should have one template", 1, templates.size());

        SaleTemplate theTemplate = templates.get(0);
        Price rrPrice = theTemplate.getPriceOf(systemTestFixture.rr);

        Assert.assertEquals("Price should have one due date", 1, rrPrice.getDueDates().size());
        rrPrice.getRoyaltyValues();
    }

    @Test(expected = UnsupportedOperationException.class)
    public void when_consistentSaleTemplate_getSaleTemplatesOf_shouldBeReturnANoValuePriceWithouARoyaltValueAndDueDate() throws BusinessException {
        createAConsistentSaleTemplateWithHeadOffice();

        List<SaleTemplate> templates = saleService.getSaleTemplatesOf(saleTestFixture.headOfficeCargil, saleTestFixture.harvest2011SoyMonsanto, new Date(), SaleTypeEnum.SALE_SEED);
        Assert.assertEquals("Should have one template", 1, templates.size());

        SaleTemplate theTemplate = templates.get(0);
        Price btPrice = theTemplate.getPriceOf(systemTestFixture.bt);

        Assert.assertEquals("Price should not have due date", 0, btPrice.getDueDates().size());
        btPrice.getRoyaltyValues();
    }

    @Test
    public void when_i_search_a_saleTemplate_with_a_dateGreaterThanEndDate_shouldBeReturn_noRecords() throws BusinessException {
        createAConsistentSaleTemplateWithHeadOffice();
        Calendar cal = Calendar.getInstance();

        cal.add(Calendar.YEAR, 1);

        Date creationDate = cal.getTime();

        List<SaleTemplate> templates = saleService.getSaleTemplatesOf(saleTestFixture.headOfficeCargil, saleTestFixture.harvest2011SoyMonsanto, creationDate, SaleTypeEnum.SALE_SEED);

        Assert.assertTrue("Should return only templates within the range of start and end date", templates.isEmpty());
    }

    @Test
    public void when_i_search_a_saleTemplate_with_a_dateLowerThanStartDate_shouldBeReturn_noRecords() throws BusinessException {
        createAConsistentSaleTemplateWithHeadOffice();
        Calendar cal = Calendar.getInstance();

        cal.add(Calendar.YEAR, -1);

        Date creationDate = cal.getTime();

        List<SaleTemplate> templates = saleService.getSaleTemplatesOf(saleTestFixture.headOfficeCargil, saleTestFixture.harvest2011SoyMonsanto, creationDate, SaleTypeEnum.SALE_SEED);

        Assert.assertTrue("Should return only templates within the range of start and end date", templates.isEmpty());
    }

    @Test
    public void when_i_search_a_saleTemplate_with_a_dateEqualsTheStartDate_shouldBeReturn_oneRecords() throws BusinessException {
        SaleTemplate saleTemplate = createAConsistentSaleTemplateWithHeadOffice();
        Date creationDate = saleTemplate.getStartDate();

        List<SaleTemplate> templates = saleService.getSaleTemplatesOf(saleTestFixture.headOfficeCargil, saleTestFixture.harvest2011SoyMonsanto, creationDate, SaleTypeEnum.SALE_SEED);

        Assert.assertFalse("Should return only templates within the range of start and end date", templates.isEmpty());
    }

    @Test
    public void when_i_search_a_saleTemplate_with_a_dateEqualsTheEndDate_shouldBeReturn_oneRecord() throws BusinessException {
        SaleTemplate saleTemplate = createAConsistentSaleTemplateWithHeadOffice();

        List<SaleTemplate> templates = saleService.getSaleTemplatesOf(saleTestFixture.headOfficeCargil, saleTestFixture.harvest2011SoyMonsanto, saleTemplate.getEndDate(), SaleTypeEnum.SALE_SEED);

        Assert.assertFalse("Should return only templates within the range of start and end date", templates.isEmpty());
    }

    @Test
    public void when_i_have_valid_sale_ShoulReturnSuccess() throws BusinessException {
        accessControlIntent.userAdminOfMonsantoBr.setContextCompany(systemTestFixture.monsantoBr);
        accessControlIntent.userAdminOfMonsantoBr.setContextCrop(systemTestFixture.soy);

        Sale sale = createSaleWithOneFixItemAndOneNoValueItem();

        saleService.save(sale, accessControlIntent.userAdminOfMonsantoBr);
        Assert.assertNotNull(sale.getItems().iterator().next().getTotalCreditValue());
    }

    @Test
    public void given_a_sale_with_two_itens_one_byPlantability_and_another_noValue_then_save_should_return_success() throws BusinessException {
        Sale sale = createSaleWithOneByPlantabilityItemAndOneNoValueItem();
        saleService.save(sale, getParticipantUser());

        Assert.assertNotNull(sale.getId());
        Assert.assertEquals(1, saleService.getBillingBy(new BillingFilter().add(sale.getId())).size());
        Assert.assertEquals(0, saleService.getBillingBy(new BillingFilter().add(PaymentStatus.NO_VALUE)).size());
        Assert.assertEquals(1, saleService.getBillingBy(new BillingFilter().add(PaymentStatus.NOT_PAID)).size());
    }

    @Ignore
    public void given_a_sale_with_noValue_when_cancel_sale_then_should_return_credit_reversal() throws BusinessException {
        Sale sale = createSaleSeedWithTwoNoValueItem();
        saleService.save(sale, getParticipantUser());

        Assert.assertEquals(1, saleService.getBillingBy(new BillingFilter().add(PaymentStatus.NO_VALUE)).size());
        Assert.assertEquals(0, saleService.getBillingBy(new BillingFilter().add(PaymentStatus.CANCELLED)).size());

        Account availableAccount = accountService.fetchOrCreateAccount(AccountType.AVAILABLE, saleTestFixture.chicoBento, systemTestFixture.soy, saleTestFixture.productIntactaSoy.getTechnology(), systemTestFixture.operationalYearOf2012);
        Account unusedAccount = accountService.fetchOrCreateAccount(AccountType.UNUSABLE, saleTestFixture.chicoBento, systemTestFixture.soy, saleTestFixture.productIntactaSoy.getTechnology(), systemTestFixture.operationalYearOf2012);

        Assert.assertEquals("Should have available credits", new BigDecimal(5050), availableAccount.getBalance());
        Assert.assertEquals("Should have unusable credits", BigDecimal.ZERO, unusedAccount.getBalance());

        saleService.cancelBillingPartially(sale.getId(), systemTestFixture.monsantoBr, saleTestFixture.saleCancellation, "vrodrigues");

        Assert.assertEquals(0, saleService.getBillingBy(new BillingFilter().add(PaymentStatus.NO_VALUE)).size());
        Assert.assertEquals(1, saleService.getBillingBy(new BillingFilter().add(PaymentStatus.CANCELLED)).size());

        availableAccount = accountService.fetchOrCreateAccount(AccountType.AVAILABLE, saleTestFixture.chicoBento, systemTestFixture.soy, saleTestFixture.productIntactaSoy.getTechnology(), systemTestFixture.operationalYearOf2012);
        unusedAccount = accountService.fetchOrCreateAccount(AccountType.UNUSABLE, saleTestFixture.chicoBento, systemTestFixture.soy, saleTestFixture.productIntactaSoy.getTechnology(), systemTestFixture.operationalYearOf2012);

        Assert.assertEquals("Should have available credits", BigDecimal.ZERO, availableAccount.getBalance());
        Assert.assertEquals("Should have unusable credits", new BigDecimal(5050), unusedAccount.getBalance());
    }

    @Test
    public void given_a_valid_sale_when_superUser_search_for_sales_should_return_the_valid_sale() throws BusinessException {
        saveAValidSaleForAParticipant();

        SaleFilter saleFilter = SaleFilter.getInstance();
        UserDecorator loggedSuperUser = accessControlIntent.superUser;
        loggedSuperUser.setContextCrop(systemTestFixture.soy);
        saleFilter.add(loggedSuperUser);
        saleFilter.addCreationDateEnd(new Date());

        List<Sale> sales = saleService.getSaleBy(saleFilter);

        Assert.assertEquals("Incorrect number of sales", 1, sales.size());
    }

    @Test
    public void given_a_valid_sale_when_superUser_search_for_sales_paid_manually_should_return_sale() throws BusinessException {
        Sale sale = saleFactory.createSale(saleTestFixture.matrixCargil, saleTestFixture.chicoBento, SaleTypeEnum.SALE_SEED);
        sale.setState(systemTestFixture.matoGrossoDoSul);
        SaleItem saleItemByPlantability = saleItemFactory.createByPlantabilityDueDateRangeItem(saleTestFixture.productIntactaSoy, saleTestFixture.templateIntactaByPlantabilityRRByExpirationBtFree, saleTestFixture.headOfficeCargil, 5l, SaleTestFixture.NOVEMBER, saleTestFixture.plantability45To54SoyMonsanto2012);
        sale.addItem(saleItemByPlantability);
        saveAValidSaleForAParticipant(sale);

        UserDecorator loggedSuperUser = accessControlIntent.superUser;
        loggedSuperUser.setContextCrop(systemTestFixture.soy);

        BillingFilter billingFilter = BillingFilter.getInstance()
                .add(sale.getId())
                .add(loggedSuperUser);

        List<BillingDTO> billingDTOList = saleService.getBillingsOfSale(billingFilter).getDecoratedBillings();

        Assert.assertEquals("Correct number of billing", 1, billingDTOList.size());

        Date nowDate = new Date();
        saleService.payBilling(billingDTOList.get(0).getBilling(), nowDate, BigDecimal.ONE, true);

        SaleFilter saleFilter = SaleFilter.getInstance();
        saleFilter.add(loggedSuperUser);
        saleFilter.addCreationDateEnd(new Date());

        List<PaymentStatus> statusEq = new ArrayList<PaymentStatus>();
        statusEq.add(PaymentStatus.PARCIAL_PAID);
        statusEq.add(PaymentStatus.FULLY_PAID);
        saleFilter.addBillingStatusEqAndPayManual(statusEq);

        List<Sale> sales = saleService.getSaleBy(saleFilter);

        Assert.assertEquals("Correct number of sales", 1, sales.size());
    }

    @Test
    public void given_a_valid_sale_when_superUser_search_for_sales_not_paid_should_return_sale() throws BusinessException {
        Sale sale = saleFactory.createSale(saleTestFixture.matrixCargil, saleTestFixture.chicoBento, SaleTypeEnum.SALE_SEED);
        sale.setState(systemTestFixture.matoGrossoDoSul);
        SaleItem saleItemByPlantability = saleItemFactory.createByPlantabilityDueDateRangeItem(saleTestFixture.productIntactaSoy, saleTestFixture.templateIntactaByPlantabilityRRByExpirationBtFree, saleTestFixture.headOfficeCargil, 5l, SaleTestFixture.NOVEMBER, saleTestFixture.plantability45To54SoyMonsanto2012);
        sale.addItem(saleItemByPlantability);
        saveAValidSaleForAParticipant(sale);

        SaleFilter saleFilter = SaleFilter.getInstance();
        UserDecorator loggedSuperUser = accessControlIntent.superUser;
        loggedSuperUser.setContextCrop(systemTestFixture.soy);
        saleFilter.add(loggedSuperUser);
        saleFilter.addCreationDateEnd(new Date());

        List<PaymentStatusAll> statusEq = new ArrayList<PaymentStatusAll>();
        statusEq.add(PaymentStatusAll.NOT_PAID);
        saleFilter.addBillingStatusEq(statusEq);

        List<PaymentStatusAll> statusNe = new ArrayList<PaymentStatusAll>();
        statusNe.add(PaymentStatusAll.CANCELLED);
        statusNe.add(PaymentStatusAll.FULLY_PAID);
        statusNe.add(PaymentStatusAll.PARCIAL_PAID);
//		saleFilter.addBillingStatusNe(statusNe);

        List<Sale> sales = saleService.getSaleBy(saleFilter);

        Assert.assertEquals("Correct number of sales", 1, sales.size());

        BillingFilter billingFilter = BillingFilter.getInstance()
                .add(sales.get(0).getId())
                .add(loggedSuperUser);

        List<BillingDTO> billingDTOList = saleService.getBillingsOfSale(billingFilter).getDecoratedBillings();

        Assert.assertEquals("Correct number of billing", 1, billingDTOList.size());

        Date nowDate = new Date();
        saleService.payBilling(billingDTOList.get(0).getBilling(), nowDate, BigDecimal.ONE, false);

        sales = saleService.getSaleBy(saleFilter);

        Assert.assertEquals("Correct number of sales", 0, sales.size());
    }

    @Test
    public void given_a_sale_when_an_adminUser_with_selected_company_search_sales_shouldReturn_sales_of_his_own_company() throws BusinessException {
        saveAValidSaleForAParticipant();

        UserDecorator loggedAdminUser = accessControlIntent.userAdminOfMonsantoBr;
        loggedAdminUser.setContextCompany(systemTestFixture.monsantoBr);

        SaleFilter saleFilter = SaleFilter.getInstance();
        saleFilter.add(loggedAdminUser);
        saleFilter.addCreationDateEnd(new Date());

        List<Sale> sales = saleService.getSaleBy(saleFilter);

        Assert.assertEquals("Incorrect number of sales", 1, sales.size());
    }

    @Test
    public void given_a_sale_when_an_adminUser_with_selected_company_search_sales_shouldNotReturn_sale_of_other_companies() throws BusinessException {
        saveAValidSaleForAParticipant();

        Company monsantoUs = new Company("Monsanto-US");
        saveAndFlush(monsantoUs);

        UserDecorator loggedAdminUser = accessControlIntent.userAdminOfMonsantoBr;
        loggedAdminUser.setContextCompany(monsantoUs);

        SaleFilter saleFilter = SaleFilter.getInstance();
        saleFilter.add(loggedAdminUser);
        saleFilter.addCreationDateEnd(new Date());

        List<Sale> sales = saleService.getSaleBy(saleFilter);

        Assert.assertEquals("Can not return any sale", 0, sales.size());
    }

    @Test
    public void given_a_sale_when_an_adminUser_with_selected_company_and_matrix_search_sales_shouldReturn_sale_of_matrix() throws BusinessException {
        saveAValidSaleForAParticipant();

        UserDecorator loggedAdminUser = accessControlIntent.userAdminOfMonsantoBr;
        loggedAdminUser.setContextCompany(systemTestFixture.monsantoBr);

        SaleFilter saleFilter = SaleFilter.getInstance();
        saleFilter.add(loggedAdminUser);
        saleFilter.addCreationDateEnd(new Date());
        saleFilter.addMatrix(saleTestFixture.headOfficeCargil.getMatrix());

        List<Sale> sales = saleService.getSaleBy(saleFilter);

        Assert.assertEquals("Can not return any sale", 1, sales.size());
    }

    @Test
    public void given_a_sale_when_an_participantUser_search_sales_shouldNotReturn_sale_of_other_contracts() throws BusinessException {
        saveAValidSaleForAParticipant();

        UserContext participant = mock(UserContext.class);
        stub(participant.getType()).toReturn(UserTypeEnum.PARTICIPANT);

        List<Customer> documentList = new ArrayList<Customer>();
        documentList.add(saleTestFixture.customer);

        stub(participant.getContextPartnersBy(ParticipantTypeEnum.DISTRIBUTOR)).toReturn(documentList);

        SaleFilter saleFilter = SaleFilter.getInstance().add(participant).addCreationDateEnd(new Date());

        List<Sale> sales = saleService.getSaleBy(saleFilter);

        Assert.assertEquals("Can not return any sale", 0, sales.size());
    }

    @Test
    public void given_a_sale_when_an_participantUser_search_sales_shouldReturn_sale_of_his_contracts() throws BusinessException {
        saveAValidSaleForAParticipant();

        SaleFilter saleFilter = SaleFilter.getInstance().add(getUserDecoratorBy(systemTestFixture.soy)).addCreationDateEnd(new Date());

        List<Sale> sales = saleService.getSaleBy(saleFilter);

        Assert.assertEquals("Incorrect number of sales", 1, sales.size());
    }

    @Test
    public void given_a_sale_when_an_participantUser_search_sales_by_affiliates_shouldReturn_sale_of_his_contracts() throws BusinessException {
        saleTestFixture.headOfficeCargil = (HeadOffice) getSession().get(HeadOffice.class, saleTestFixture.headOfficeCargil.getId());
        Sale sale = saleFactory.createSale(saleTestFixture.affiliate, saleTestFixture.chicoBento, SaleTypeEnum.SALE_SEED);
        sale.setState(systemTestFixture.matoGrossoDoSul);
        SaleItem saleItemByPlantability = saleItemFactory.createByPlantabilityDueDateRangeItem(saleTestFixture.productIntactaSoy, saleTestFixture.templateIntactaByPlantabilityRRByExpirationBtFree, saleTestFixture.headOfficeCargil, 5l, SaleTestFixture.NOVEMBER, saleTestFixture.plantability45To54SoyMonsanto2012);
        sale.addItem(saleItemByPlantability);
        saveAValidSaleForAParticipant(sale);

        SaleFilter saleFilter = SaleFilter.getInstance().add(getUserDecoratorBy(systemTestFixture.soy)).addCreationDateEnd(new Date());

        List<Sale> sales = saleService.getSaleBy(saleFilter);

        Assert.assertEquals("Incorrect number of sales", 1, sales.size());
    }

    @Test
    public void given_a_sale_when_an_participantUser_has_one_contract_with_affiliate_search_sales_by_affiliates_shouldReturn_sale_of_his_contracts() throws BusinessException {

        accessControlIntent.itsParticipantUser.addProfile(accessControlIntent.profileWithOneAction);
        accessControlIntent.itsParticipantUser.addUserContract(saleTestFixture.contractCargil, saleTestFixture.affiliate, HierarchyLevel.AFFILIATE);
        saveAndFlush(accessControlIntent.itsParticipantUser);

        UserDecorator participantUser = getUserDecoratorBy(systemTestFixture.soy);

        Sale sale = saleFactory.createSale(saleTestFixture.affiliate, saleTestFixture.chicoBento, SaleTypeEnum.SALE_SEED);
        sale.setState(systemTestFixture.matoGrossoDoSul);
        SaleItem saleItemByPlantability = saleItemFactory.createByPlantabilityDueDateRangeItem(saleTestFixture.productIntactaSoy, saleTestFixture.templateIntactaByPlantabilityRRByExpirationBtFree, saleTestFixture.headOfficeCargil, 5l, SaleTestFixture.NOVEMBER, saleTestFixture.plantability45To54SoyMonsanto2012);
        sale.addItem(saleItemByPlantability);

        saleService.save(sale, participantUser);

        SaleFilter saleFilter = SaleFilter.getInstance().add(participantUser).addCreationDateEnd(new Date());

        List<Sale> sales = saleService.getSaleBy(saleFilter);

        Assert.assertEquals("Incorrect number of sales", 1, sales.size());
    }

    @Test
    public void given_a_sale_when_an_participantUser_has_one_contract_with_affiliate_search_sales_by_matrix_shouldNotReturn_sale_of_his_contracts() throws BusinessException {

        accessControlIntent.itsParticipantUser.addProfile(accessControlIntent.profileWithOneAction);
        accessControlIntent.itsParticipantUser.addUserContract(saleTestFixture.contractCargil, saleTestFixture.affiliate, HierarchyLevel.AFFILIATE);
        saveAndFlush(accessControlIntent.itsParticipantUser);

        UserDecorator participantUser = getUserDecoratorBy(systemTestFixture.soy);

        Sale sale = saleFactory.createSale(saleTestFixture.matrixCargil, saleTestFixture.chicoBento, SaleTypeEnum.SALE_SEED);
        sale.setState(systemTestFixture.matoGrossoDoSul);
        SaleItem saleItemByPlantability = saleItemFactory.createByPlantabilityDueDateRangeItem(saleTestFixture.productIntactaSoy, saleTestFixture.templateIntactaByPlantabilityRRByExpirationBtFree, saleTestFixture.headOfficeCargil, 5l, SaleTestFixture.NOVEMBER, saleTestFixture.plantability45To54SoyMonsanto2012);
        sale.addItem(saleItemByPlantability);

        saleService.save(sale, accessControlIntent.userAdminOfMonsantoBr);

        SaleFilter saleFilter = SaleFilter.getInstance().add(participantUser).addCreationDateEnd(new Date());

        List<Sale> sales = saleService.getSaleBy(saleFilter);

        Assert.assertEquals("Incorrect number of sales", 0, sales.size());
    }

    @Test
    public void filter_by_creation_date_shouldNot_consider_the_time() throws BusinessException {
        saveAValidSaleForAParticipant(); // this sale have a creationDate equals new Date()

        SaleFilter saleFilter = SaleFilter.getInstance().addCreationDateEnd(new Date()).addCreationDateStart(new Date());
        List<Sale> sales = saleService.getSaleBy(saleFilter);
        Assert.assertEquals("Incorrect number of sales", 1, sales.size());
    }

    @Ignore
    public void when_i_register_a_licenseSeed_with_existingInvoiceNumber_shouldNotValidateInvoiceDuplicate() throws BusinessException {
        UserDecorator participantUser = accessControlIntent.participantUser;
        UserContract userContract = new UserContract(participantUser.getCurrentUser(), saleTestFixture.contractCargil, saleTestFixture.matrixCargil, HierarchyLevel.HEAD_OFFICE);
        saveAndFlush(userContract);

        participantUser.addUserContract(userContract);
        participantUser.setContextCrop(systemTestFixture.soy);

        Sale saleSeed = createSaleSeedWithTwoNoValueItem();
        saleService.save(saleSeed, participantUser);

        Sale licenseSeed = createReservedSeedWithTwoNoValueItem();
        licenseSeed.setInvoiceNumber(saleSeed.getInvoiceNumber());
        licenseSeed.setCustomer(saleSeed.getCustomer());
        saleService.save(licenseSeed, participantUser);

        SaleFilter saleFilter = SaleFilter.getInstance();
        saleFilter.addInvoiceNumber(saleSeed.getInvoiceNumber());
        saleFilter.addCreationDateEnd(new Date());

        List<Sale> sales = saleService.getSaleBy(saleFilter);

        Assert.assertEquals("Should return two sales", 2, sales.size());
    }

    @Ignore
    public void given_two_sales_with_different_types_and_same_invoice_number_when_filter_by_invoice_number_then_getSaleBy_should_return_two_sales() throws BusinessException {
        String invoiceNumber = createTwoSalesOfDifferentTypesAndSameInvoiceNumber();

        SaleFilter saleFilter = SaleFilter.getInstance();
        saleFilter.addInvoiceNumber(invoiceNumber);
        saleFilter.addCreationDateEnd(new Date());

        List<Sale> sales = saleService.getSaleBy(saleFilter);

        Assert.assertEquals("Should return two sales", 2, sales.size());
    }

    @Ignore
    public void given_two_sales_with_different_types_and_same_invoice_number_when_filter_by_invoice_number_and_one_type_then_getSaleBy_should_return_one_sale() throws BusinessException {
        String invoiceNumber = createTwoSalesOfDifferentTypesAndSameInvoiceNumber();

        SaleFilter saleFilter = SaleFilter.getInstance();
        saleFilter.addInvoiceNumber(invoiceNumber);
        saleFilter.addCreationDateEnd(new Date());
        saleFilter.addSaleType(SaleTypeEnum.SALE_SEED);

        List<Sale> sales = saleService.getSaleBy(saleFilter);

        Assert.assertEquals("Should return one sale", 1, sales.size());
    }

    @Ignore
    public void given_two_sales_with_different_types_and_same_invoice_number_when_filter_by_invoice_number_and_two_types_then_getSaleBy_should_return_two_sales() throws BusinessException {
        String invoiceNumber = createTwoSalesOfDifferentTypesAndSameInvoiceNumber();

        SaleFilter saleFilter = SaleFilter.getInstance();
        saleFilter.addInvoiceNumber(invoiceNumber);
        saleFilter.addCreationDateEnd(new Date());
        saleFilter.addSaleTypes(SaleTypeEnum.SALE_SEED, SaleTypeEnum.LICENSE_SEED);

        List<Sale> sales = saleService.getSaleBy(saleFilter);

        Assert.assertEquals("Should return one sale", 2, sales.size());
    }

    @Ignore
    public void given_two_sales_with_different_types_and_same_invoice_number_when_filter_by_invoice_number_and_another_type_then_getSaleBy_should_return_no_sales() throws BusinessException {
        String invoiceNumber = createTwoSalesOfDifferentTypesAndSameInvoiceNumber();

        SaleFilter saleFilter = SaleFilter.getInstance();
        saleFilter.addInvoiceNumber(invoiceNumber);
        saleFilter.addCreationDateEnd(new Date());
        saleFilter.addSaleType(SaleTypeEnum.DIRECT_SALE);

        List<Sale> sales = saleService.getSaleBy(saleFilter);

        Assert.assertEquals("Should return no sales", 0, sales.size());
    }

    private String createTwoSalesOfDifferentTypesAndSameInvoiceNumber() throws SaleConstraintViolationException, BusinessException {

        UserDecorator participantUser = accessControlIntent.participantUser;
        UserContract userContract = new UserContract(participantUser.getCurrentUser(), saleTestFixture.contractCargil, saleTestFixture.matrixCargil, HierarchyLevel.HEAD_OFFICE);
        saveAndFlush(userContract);

        participantUser.addUserContract(userContract);
        participantUser.setContextCrop(systemTestFixture.soy);

        Sale licenseSeed = createReservedSeedWithTwoNoValueItem();
        saleService.save(licenseSeed, participantUser);

        Sale saleSeed = createSaleSeedWithTwoNoValueItem();
        saleSeed.setInvoiceNumber(licenseSeed.getInvoiceNumber());
        saleSeed.setCustomer(licenseSeed.getCustomer());
        saleService.save(saleSeed, participantUser);

        return licenseSeed.getInvoiceNumber();
    }

    @Test
    public void given_sale_with_two_itens_novalue_and_fix_when_verify_some_billet_valid_should_return_true() throws BusinessException {
        DbUnitHelper.setup("classpath:data/core/system-parameter-bankslip-enabled-dataset.xml");

        Sale sale = createSaleWithOneFixItemAndOneNoValueItem();
        saleService.save(sale, getParticipantUser());
        Boolean billetValid = saleService.hasSomeBilletValid(sale.getId());

        Assert.assertNotNull(billetValid);
        Assert.assertTrue("billetValid = " + billetValid, billetValid);

    }

    @Test
    public void given_sale_with_two_itens_novalue_and_byPlantability_when_verify_some_billet_valid_should_return_true() throws BusinessException {
        DbUnitHelper.setup("classpath:data/core/system-parameter-bankslip-enabled-dataset.xml");
        Sale sale = createSaleWithOneByPlantabilityItemAndOneNoValueItem();
        saleService.save(sale, getParticipantUser());
        Boolean billetValid = saleService.hasSomeBilletValid(sale.getId());
        Assert.assertNotNull(billetValid);
        Assert.assertTrue(billetValid);
    }

    @Ignore
    public void given_sale_with_two_itens_novalue_when_save_should_sucssess_operation() throws BusinessException {

        Sale sale = createSaleSeedWithTwoNoValueItem();
        saleService.save(sale, getParticipantUser());
        Boolean billetValid = saleService.hasSomeBilletValid(sale.getId());
        Assert.assertNotNull(billetValid);
        Assert.assertFalse(billetValid);

    }

    @Ignore
    public void given_sale_with_affliateCustomer_when_save_should_sucssess_operation() throws BusinessException {

        saleTestFixture.headOfficeCargil = (HeadOffice) getSession().get(HeadOffice.class, saleTestFixture.headOfficeCargil.getId());
        Sale sale = createSaleSeedWithTwoNoValueItem();
        sale.setCustomer(saleTestFixture.affiliate);
        saleService.save(sale, getParticipantUser());
        Boolean billetValid = saleService.hasSomeBilletValid(sale.getId());
        Assert.assertNotNull(billetValid);
        Assert.assertFalse(billetValid);

    }

    @Test
    public void given_an_existent_company_description_when_getCompanyByDescription_then_saleService_should_return_success() throws EntityNotFoundException {
        Company company = saleService.getCompanyByDescription(systemTestFixture.monsantoEua.getDescription());
        Assert.assertEquals(systemTestFixture.monsantoEua, company);
    }

    @Test(expected = EntityNotFoundException.class)
    public void given_an_inexistent_company_description_when_getCompanyByDescription_then_saleService_should_throw_entityNotFoundException() throws EntityNotFoundException {
        saleService.getCompanyByDescription("sa�lkjapioquwer");
        Assert.fail("Company should not be found");
    }

    @Test
    public void given_an_existent_crop_when_getCropByCandidateKey_then_saleService_should_return_success() throws EntityNotFoundException {
        Crop crop = saleService.getCropByCandidateKey(systemTestFixture.soy.getDescription(), systemTestFixture.soy.getCompany());
        Assert.assertEquals(systemTestFixture.soy, crop);
    }

    @Test(expected = EntityNotFoundException.class)
    public void given_an_inexistent_crop_when_getCropByCandidateKey_then_saleService_should_throw_entityNotFoundException() throws EntityNotFoundException {
        saleService.getCropByCandidateKey("aasdfadfer", systemTestFixture.monsantoEua);
        Assert.fail("Crop should not be found");
    }

    @Test
    public void given_an_existent_operationalYear_when_getOperationalYearByCandidateKey_then_saleService_should_return_success() throws EntityNotFoundException {
        OperationalYear opYear = baseService.getOperationalYearByCandidateKey(systemTestFixture.operationalYearOf2009.getYear());
        Assert.assertEquals(systemTestFixture.operationalYearOf2009, opYear);
    }

    @Test(expected = EntityNotFoundException.class)
    public void given_an_inexistent_operationalYear_when_getOperationalYearByCandidateKey_then_saleService_should_throw_exception() throws EntityNotFoundException {
        baseService.getOperationalYearByCandidateKey("qewqerw");
        Assert.fail("Operational year should not be found");
    }

    @Test
    public void given_an_existent_harvest_when_getHarvestByFilter_then_saleService_should_return_success() throws EntityNotFoundException {
        Harvest expectedHarvest = saleTestFixture.harvestSoyMonsanto2012;
        Harvest harvest = saleService.getHarvestByCandidateKey(expectedHarvest.getDescription(), expectedHarvest.getCrop(), expectedHarvest.getOperationalYear(), expectedHarvest.getCompany());
        Assert.assertEquals(expectedHarvest, harvest);
    }

    @Test(expected = EntityNotFoundException.class)
    public void given_an_inexistent_harvest_when_getHarvestByFilter_then_saleService_should_throw_exception() throws EntityNotFoundException {
        Harvest expectedHarvest = saleTestFixture.harvestSoyMonsanto2012;
        saleService.getHarvestByCandidateKey("random description", expectedHarvest.getCrop(), expectedHarvest.getOperationalYear(), expectedHarvest.getCompany());
        Assert.fail("Harvest should not be found");
    }

    @Test
    public void given_a_existent_saleTemplate_when_getSaleTemplateByCandidateKey_then_saleService_should_return_one_saleTemplate() throws EntityNotFoundException {
        SaleTemplate expectedSaleTemplate = saleTestFixture.templateFixWithDueDateRange;
        SaleTemplate saleTemplate = saleService.getSaleTemplateByCandidateKey(expectedSaleTemplate.getDescription(), expectedSaleTemplate.getHarvest());
        Assert.assertEquals("Should be the same saleTemplate", expectedSaleTemplate, saleTemplate);
    }

    @Test(expected = EntityNotFoundException.class)
    public void given_an_inexisting_saleTemplate_when_getSaleTemplateByCandidateKey_should_throw_exception() throws EntityNotFoundException {
        SaleTemplate expectedSaleTemplate = saleTestFixture.templateFixWithDueDateRange;
        saleService.getSaleTemplateByCandidateKey("random description", expectedSaleTemplate.getHarvest());
        Assert.fail("Sale template should not be found!");
    }

    @Test
    public void given_an_existent_product_when_getProductById_then_saleService_should_return_success() throws EntityNotFoundException {
        Product expectedProduct = saleTestFixture.productIntactaSoy;
        Product product = saleService.getProductBy(expectedProduct.getId());
        Assert.assertEquals(expectedProduct, product);
    }

    @Test(expected = EntityNotFoundException.class)
    public void given_an_inexistent_product_when_getProductById_then_saleService_should_throw_exception() throws EntityNotFoundException {
        saleService.getProductBy(5656565L);
        Assert.fail("Product should not be found!");
    }

    @Test
    public void given_an_existent_state_when_getStateByCode_then_saleService_should_return_success() throws EntityNotFoundException {
        State expectedState = systemTestFixture.matoGrossoDoSul;
        State state = saleService.getStateByCode(expectedState.getCode());
        Assert.assertEquals(expectedState, state);
    }

    @Test(expected = EntityNotFoundException.class)
    public void given_an_inexistent_stateCode_when_getStateByCode_then_saleService_should_throw_exception() throws EntityNotFoundException {
        saleService.getStateByCode("qwerqer");
        Assert.fail("State should not be found!");
    }

    @Test
    public void given_an_existent_plantability_when_getPlantabilityByCandidateKey_then_saleService_should_return_success() throws BusinessException {
        Plantability expectedPlantability = saleTestFixture.plantabilitySystemSoyMonsanto2012;
        Plantability plantability = saleService.getPlantabilityByCandidateKey(expectedPlantability.getDescription(), expectedPlantability.getHarvest());
        Assert.assertEquals(expectedPlantability, plantability);
    }

    @Test(expected = EntityNotFoundException.class)
    public void given_an_inexistent_plantability_when_getPlantabilityByCandidateKey_then_saleService_should_throw_exception() throws BusinessException {
        saleService.getPlantabilityByCandidateKey("wertwerwt", saleTestFixture.harvest2009SoyMonsanto);
        Assert.fail("Plantability should not be found!");
    }

    @Test
    public void given_an_existent_grower_when_getGrowerByCandidateKey_then_saleService_should_return_success() throws EntityNotFoundException {
        Grower grower = baseService.getGrowerByCandidateKey(SaleTestFixture.CHICO_CNPJ, saleTestFixture.chicoBentoDocument.getDocumentTypeDescription());
        Assert.assertEquals(saleTestFixture.chicoBento, grower);
    }

    @Test(expected = EntityNotFoundException.class)
    public void given_an_inexistent_grower_when_getGrowerByCandidateKey_then_saleService_should_throw_exception() throws EntityNotFoundException {
        baseService.getGrowerByCandidateKey("2345234534252435", "iree");
        Assert.fail("Grower should not be found!");
    }

    private Sale saveAValidSaleForAParticipant() throws BusinessException {
        accessControlIntent.itsParticipantUser.addProfile(accessControlIntent.profileWithOneAction);
        accessControlIntent.itsParticipantUser.addUserContract(saleTestFixture.contractCargil, saleTestFixture.matrixCargil, HierarchyLevel.HEAD_OFFICE);
        saveAndFlush(accessControlIntent.itsParticipantUser);

        UserDecorator participantUser = getUserDecoratorBy(systemTestFixture.soy);

        Sale sale = createSaleWithOneFixItemAndOneNoValueItem();
        saleService.save(sale, participantUser);
        return sale;
    }

    private UserDecorator getUserDecoratorBy(Crop crop) throws BusinessException {
        UserDecorator userDecorator = userServices.getAuthenticatedUserBy(accessControlIntent.itsParticipantUser.getLogin());
        userDecorator.setContextCrop(crop);
        return userDecorator;
    }

    private Sale saveAValidSaleForAParticipant(Sale sale) throws BusinessException {
        return saveAValidSaleForAParticipant(sale, true);
    }

    private Sale saveAValidSaleForAParticipant(Sale sale, boolean saveParticipant) throws BusinessException {
        if (saveParticipant) {
            accessControlIntent.itsParticipantUser.addProfile(accessControlIntent.profileWithOneAction);
            accessControlIntent.itsParticipantUser.addUserContract(saleTestFixture.contractCargil, saleTestFixture.matrixCargil, HierarchyLevel.HEAD_OFFICE);
            saveAndFlush(accessControlIntent.itsParticipantUser);
        }

        UserDecorator participantUser = getUserDecoratorBy(systemTestFixture.soy);

        saleService.save(sale, participantUser);
        return sale;
    }

    private Sale createReservedSeedWithTwoNoValueItem() throws BusinessException {
        SaleTemplate templateReservedSeed = saleTestFixture.templateReservedSeedNoValue;
        Sale sale = createSaleWithTwoNoValueItem(templateReservedSeed);
        sale.setSaleType(SaleTypeEnum.LICENSE_SEED);
        return sale;
    }

    private Sale createSaleSeedWithTwoNoValueItem() throws BusinessException {
        SaleTemplate templateSaleSeed = saleTestFixture.templateIntactaNoValueRRNoValue;
        return createSaleWithTwoNoValueItem(templateSaleSeed);
    }

    private Sale createSaleWithTwoNoValueItem(SaleTemplate saleTemplate) {
        Sale sale = saleFactory.createSale(saleTestFixture.matrixCargil, saleTestFixture.chicoBento, SaleTypeEnum.SALE_SEED);
        sale.setState(systemTestFixture.matoGrossoDoSul);

        SaleItem saleItem = saleItemFactory.createNoValueItem(saleTestFixture.productIntactaSoy, saleTemplate, saleTestFixture.headOfficeCargil, 5l);
        saleItem.setSale(sale);
        sale.addItem(saleItem);

        SaleItem saleItem2 = saleItemFactory.createNoValueItem(saleTestFixture.productIntactaCoffee, saleTemplate, saleTestFixture.headOfficeCargil, 5l);
        saleItem2.setSale(sale);
        sale.addItem(saleItem2);

        return sale;
    }

    private Sale createSaleWithOneFixItemAndOneNoValueItem() throws BusinessException {
        Sale sale = saleFactory.createSale(saleTestFixture.matrixCargil, saleTestFixture.chicoBento, SaleTypeEnum.SALE_SEED);
        sale.setState(systemTestFixture.matoGrossoDoSul);

        sale.addItem(saleItemFactory.createFixValueItem(saleTestFixture.productIntactaSoy, saleTestFixture.templateIntactaFixRRRangeBtNoValue, saleTestFixture.headOfficeCargil, 5l));
//		sale.addItem(saleItemFactory.createNoValueItem(saleTestFixture.productBtSoy, saleTestFixture.templateIntactaFixRRRangeBtNoValue, saleTestFixture.headOfficeCargil, 5l));
        return sale;
    }

    private Sale createDirectSaleWithOneFixItemAndOneNoValueItem() throws BusinessException {
        Sale sale = saleFactory.createSale(saleTestFixture.matrixCargil, saleTestFixture.chicoBento, SaleTypeEnum.DIRECT_SALE);
        sale.setState(systemTestFixture.matoGrossoDoSul);

        sale.addItem(saleItemFactory.createFixValueItem(saleTestFixture.productIntactaSoy, saleTestFixture.templateDirectSaleIntactaFixRRRangeBtNoValue, saleTestFixture.headOfficeCargil, 5l));
//		sale.addItem(saleItemFactory.createNoValueItem(saleTestFixture.productBtSoy, saleTestFixture.templateIntactaFixRRRangeBtNoValue, saleTestFixture.headOfficeCargil, 5l));
        return sale;
    }

    private Sale createSaleWithOneByPlantabilityItemAndOneNoValueItem() {

        Sale sale = saleFactory.createSale(saleTestFixture.matrixCargil, saleTestFixture.chicoBento, SaleTypeEnum.SALE_SEED);
        sale.setState(systemTestFixture.matoGrossoDoSul);

        SaleItem saleItemByPlantability = saleItemFactory.createByPlantabilityDueDateRangeItem(saleTestFixture.productIntactaSoy, saleTestFixture.templateIntactaByPlantabilityRRByExpirationBtFree, saleTestFixture.headOfficeCargil, 5l, SaleTestFixture.NOVEMBER, saleTestFixture.plantability45To54SoyMonsanto2012);
        sale.addItem(saleItemByPlantability);
//		SaleItem saleItemNoValue = saleItemFactory.createNoValueItem(saleTestFixture.productBtSoy, saleTestFixture.templateIntactaFixRRRangeBtNoValue, saleTestFixture.headOfficeCargil, 5l);
//		sale.addItem(saleItemNoValue);

        return sale;
    }

    private SaleTemplate createAConsistentSaleTemplateWithHeadOffice() throws BusinessException {
        SaleTemplate saleTemplate = SaleTemplateTestData.createSaleTemplateTypeSeedSale(saleTestFixture.harvest2011SoyMonsanto);
        saleTemplate.addHeadOffice(saleTestFixture.headOfficeCargil);

        Price intactaPrice = PriceTestData.createPrice(PriceTypeEnum.FIX, saleTemplate, this.systemTestFixture.intacta);
        intactaPrice.addRoyaltyValue(new RoyaltyValue(BigDecimal.TEN));
        intactaPrice.addDueDate(new DueDateValue(new Date()));

        Price rrPrice = PriceTestData.createPrice(PriceTypeEnum.FREE_VALUE, saleTemplate, systemTestFixture.rr);
        rrPrice.addDueDate(new DueDateValue(new Date()));

        PriceTestData.createPrice(PriceTypeEnum.NO_VALUE, saleTemplate, systemTestFixture.bt);
        saveAndFlush(saleTemplate);

        return saleTemplate;
    }

    @Test
    public void testSaveSaleWithEqualsInvoiceAndDifferentTypeReturnError() throws BusinessException {

        UserDecorator participantUser = getParticipantUser();

        Sale sale = createSaleWithOneFixItemAndOneNoValueItem();
        saleService.save(sale, participantUser);
        getSession().clear();

        Sale saleDuplicate = createDirectSaleWithOneFixItemAndOneNoValueItem();

        saleDuplicate.setInvoiceNumber(sale.getInvoiceNumber());
        saleDuplicate.setCustomer(sale.getCustomer());

        try {
            saleService.save(saleDuplicate, participantUser);
            Assert.fail();
        } catch (SaleConstraintViolationException e) {
            SaleValidations_AT.verifyConstraintMessage("Invoice number duplicate.", e);
        }

    }

    @Test
    public void given_a_sale_with_number_when_an_participantUser_save_duplicate_shouldReturn_violations() throws BusinessException {

        UserDecorator participantUser = getParticipantUser();

        Sale sale = createSaleWithOneFixItemAndOneNoValueItem();
        saleService.save(sale, participantUser);
        getSession().clear();

        Sale saleDuplicate = createSaleWithOneFixItemAndOneNoValueItem();
        saleDuplicate.setInvoiceNumber(sale.getInvoiceNumber());
        saleDuplicate.setCustomer(sale.getCustomer());

        try {
            saleService.save(saleDuplicate, participantUser);
            Assert.fail();
        } catch (SaleConstraintViolationException e) {
            SaleValidations_AT.verifyConstraintMessage("Invoice number duplicate.", e);
        }
    }

    @Test
    public void given_a_sale_without_number_when_an_participantUser_save_duplicate_shouldReturn_violations() throws BusinessException {

        UserDecorator participantUser = getParticipantUser();

        Sale sale = createSaleWithOneFixItemAndOneNoValueItem();
        sale.setInvoiceNumber(null);
        saleService.save(sale, participantUser);
        getSession().clear();

        Sale saleDuplicate = createSaleWithOneFixItemAndOneNoValueItem();
        saleDuplicate.setInvoiceNumber("");
        saleDuplicate.setCustomer(sale.getCustomer());

        try {
            saleService.save(saleDuplicate, participantUser);
            Assert.fail();
        } catch (SaleConstraintViolationException e) {
            SaleValidations_AT.verifyConstraintMessage("Sale duplicate.", e);
        }
    }

    @Test
    public void given_a_sale_when_an_grower_no_has_agreement_shouldReturn_violations() throws BusinessException {

        AgreementTemplate agreementTemplate = new AgreementTemplate(
                saleTestFixture.productIntactaSoy.getCrop(),
                saleTestFixture.productIntactaSoy.getCompany(),
                saleTestFixture.productIntactaSoy.getTechnology(), "CONTENT",
                Boolean.TRUE);

        saveAndFlush(agreementTemplate);

        UserDecorator participantUser = getParticipantUser();

        Sale sale = createSaleWithOneFixItemAndOneNoValueItem();
        sale.setInvoiceNumber("123456");

        try {
            saleService.save(sale, participantUser);
            Assert.fail();
        } catch (SaleConstraintViolationException e) {
            SaleValidations_AT.verifyConstraintMessage("Not has permission to buy.", e);
        }
    }

    @Test
    public void given_a_sale_when_an_grower_has_agreement_shouldReturn_success() throws BusinessException {

        AgreementTemplate agreementTemplate = new AgreementTemplate(
                saleTestFixture.productIntactaSoy.getCrop(),
                saleTestFixture.productIntactaSoy.getCompany(),
                saleTestFixture.productIntactaSoy.getTechnology(), "CONTENT",
                Boolean.TRUE);

        saveAndFlush(agreementTemplate);

        Agreement agreement = new Agreement(1L, null, AgreementStatusEnum.APPROVED, agreementTemplate, saleTestFixture.chicoBento);
        saveAndFlush(agreement);

        UserDecorator participantUser = getParticipantUser();

        Sale sale = createSaleWithOneFixItemAndOneNoValueItem();
        sale.setInvoiceNumber("123456");

        try {
            saleService.save(sale, participantUser);
        } catch (SaleConstraintViolationException e) {
            Assert.fail();
        }
    }

    @Test
    public void given_a_sale_when_an_grower_has_agreement_but_template_not_required_shouldReturn_success() throws BusinessException {

        AgreementTemplate agreementTemplate = new AgreementTemplate(
                saleTestFixture.productIntactaSoy.getCrop(),
                saleTestFixture.productIntactaSoy.getCompany(),
                saleTestFixture.productIntactaSoy.getTechnology(), "CONTENT",
                Boolean.FALSE);

        saveAndFlush(agreementTemplate);

        Agreement agreement = new Agreement(1L, null, AgreementStatusEnum.APPROVED, agreementTemplate, saleTestFixture.chicoBento);
        saveAndFlush(agreement);

        UserDecorator participantUser = getParticipantUser();

        Sale sale = createSaleWithOneFixItemAndOneNoValueItem();
        sale.setInvoiceNumber("123456");

        try {
            saleService.save(sale, participantUser);
        } catch (SaleConstraintViolationException e) {
            Assert.fail();
        }
    }

    @Test
    public void when_i_register_a_sale_with_a_sale_template_with_same_name_of_a_sale_template_from_another_harvest_should_be_success() throws BusinessException {
        accessControlIntent.userAdminOfMonsantoBr.setContextCompany(systemTestFixture.monsantoBr);
        accessControlIntent.userAdminOfMonsantoBr.setContextCrop(systemTestFixture.soy);

        Sale sale = createSaleWithOneFixItemAndOneNoValueItem();

        SaleTemplate saleTemplate = sale.getItems().iterator().next().getSaleTemplate();
        SaleTemplate saleTemplateWithDuplicatedDescription = SaleTemplateTestData.createSaleTemplateTypeSeedSale(saleTestFixture.harvest2009SoyMonsanto);
        saleTemplateWithDuplicatedDescription.setDescription(saleTemplate.getDescription());
        saveAndFlush(saleTemplateWithDuplicatedDescription);

        saleService.save(sale, accessControlIntent.userAdminOfMonsantoBr);
        Assert.assertNotNull("Sale should be successfully saved", sale.getId());
    }

    @Ignore
    public void when_i_register_sale_with_duedate_notRequired_shouldNotBeReturned_ConstraintViolationException() throws BusinessException {
        Sale sale = createSaleWithOneFixItemAndOneNoValueItem();

        SaleTemplate saleTemplate = SaleTemplateTestData.createSaleTemplateTypeSeedSale(saleTestFixture.harvest2009SoyMonsanto);

        Price price = PriceTestData.createPrice(PriceTypeEnum.NO_VALUE, saleTemplate, systemTestFixture.intacta);
        saleTemplate.addPrices(price);

        saveAndFlush(saleTemplate);

        sale.addItem(saleItemFactory.createNoValueItem(saleTestFixture.productIntactaSoy, saleTemplate, saleTestFixture.headOfficeCargil, 5l));

        try {
            saleService.save(sale, accessControlIntent.superUser);
            Assert.fail("Should not return a ContraintViolation");
        } catch (SaleConstraintViolationException e) {
            List<ConstraintViolation> violations = e.getViolations();
            for (ConstraintViolation constraintViolation : violations) {
                if (constraintViolation.getMessage().equals("Due date is required.")) {
                    Assert.fail("Should not return a ContraintViolation");
                }
            }
        }
    }

    @Test
    public void when_i_search_account_by_filters_using_grower_document_should_return_a_balanceDTO_with_the_same_grower() throws BusinessException {
        BalanceDTO balanceDTO = saleService.getBalanceBy(saleTestFixture.chicoBento.getDocumentValue(), null);

        Assert.assertEquals("Must return same Grower", saleTestFixture.chicoBento, balanceDTO.getGrower());
    }

    @Test
    public void when_i_search_account_by_filters_using_superUser_document_should_return_balance_dto_with_All_account_status_available_and_balance_more_than_zero() throws BusinessException {
        createAccounts();

        BalanceDTO balanceDTO = saleService.getBalanceBy(saleTestFixture.joaoDaSilva.getDocumentValue(), accessControlIntent.superUser);

        Assert.assertEquals("Balance should have five accounts", 0, balanceDTO.getAccounts().size());
    }

    @Test
    public void when_i_search_account_by_filters_using_participantUser_document_should_return_balance_dto_with_All_account_from_companies_context_and_balance_more_than_zero() throws BusinessException {
        createAccounts();

        BalanceDTO balanceDTO = saleService.getBalanceBy(saleTestFixture.joaoDaSilva.getDocumentValue(), getParticipantUser());

        Assert.assertEquals("Balance should have Two accounts", 0, balanceDTO.getAccounts().size());
        for (AccountDTO account : balanceDTO.getAccounts()) {
            Assert.assertEquals(systemTestFixture.monsantoBr, account.getTechnology().getCompany());
        }
    }

    @Test
    public void when_i_search_account_by_filters_using_AdminUser_document_should_return_balance_dto_with_All_account_from_company_context_and_balance_more_than_zero() throws BusinessException {
        createAccounts();
        BalanceDTO balanceDTO = saleService.getBalanceBy(saleTestFixture.joaoDaSilva.getDocumentValue(), accessControlIntent.userAdminOfMonsantoEua);

        Assert.assertEquals("Balance should have Three accounts", 0, balanceDTO.getAccounts().size());
        for (AccountDTO account : balanceDTO.getAccounts()) {
            Assert.assertEquals(systemTestFixture.monsantoEua, account.getTechnology().getCompany());
        }
    }

    @Test
    public void when_i_save_a_sale_with_price_no_value_by_plantability_should_return_success() throws BusinessException {
        Sale sale = createValidSaleWithSaleItemOfTypeNoValueByPlantability();

        try {
            saleService.save(sale, accessControlIntent.participantUser);
        } catch (SaleConstraintViolationException e) {
            Assert.fail("Should save successfully a sale, with one item of type no value by plantability");
        }
    }

    @Test
    public void when_i_search_accounts_available_and_expeted_by_filters_using_AdminUser_document_should_return_balance_clustered_dto_with_All_account_from_company_context() throws BusinessException, ManualCreditConstraintException {
        createAccounts();

        accountService.generateCreditManually(systemTestFixture.soyEua, saleTestFixture.harvestSoyMonsantoEua2012.getOperationalYear(), systemTestFixture.intactaEua, saleTestFixture.joaoDaSilva,
                ManualCreditTransactionType.CREDIT, SaleTestFixture.EIGHT_DOLLARS, "Test reason 1", "ANDREGC");

        BalanceDTO balanceDTO = saleService.getBalanceBy(saleTestFixture.joaoDaSilva.getDocumentValue(), accessControlIntent.userAdminOfMonsantoEua);

        Assert.assertEquals("Balance should have one accounts", 1, balanceDTO.getAccounts().size());
        for (AccountDTO account : balanceDTO.getAccounts()) {
            Assert.assertEquals(systemTestFixture.monsantoEua, account.getTechnology().getCompany());
            if (saleTestFixture.harvestSoyMonsantoEua2012.getOperationalYear().equals(account.getOperationalYear())
                    && systemTestFixture.soyEua.equals(account.getCrop()) &&
                    systemTestFixture.intactaEua.equals(account.getTechnology())) {
                Assert.assertEquals("Balance should be 8", SaleTestFixture.EIGHT_DOLLARS, account.getBalance());
            }
        }
    }

    @Test(expected = ConstraintException.class)
    public void when_i_try_to_getCreditExtract_without_grower_shouldThrowException() throws ConstraintException {
        saleService.getCreditExtract(null, systemTestFixture.soy, systemTestFixture.monsantoBr);
        Assert.fail("Should throw ConstraintException");
    }

    private Sale createValidSaleWithSaleItemOfTypeNoValueByPlantability()
            throws BusinessException {
        Sale sale = saveAValidSaleForAParticipant();
        Price price = new NoValueByPlantability(saleTestFixture.templateIntactaNoValueByPlantability, saleTestFixture.productIntactaSoy.getTechnology());
        saleTestFixture.templateIntactaNoValueByPlantability.addPrices(price);
        saveAndFlush(saleTestFixture.templateIntactaNoValueByPlantability);

        SaleItem saleItem = saleItemFactory.createNoValueByPlantabilityItem(saleTestFixture.productIntactaSoy,
                saleTestFixture.templateIntactaNoValueByPlantability,
                saleTestFixture.headOfficeCargil,
                10l,
                saleTestFixture.plantability45To54SoyMonsanto2012);

        sale.getItems().clear();
        sale.addItem(saleItem);
        sale.setInvoiceNumber("123456");
        return sale;
    }

    private void createAccounts() {
        Account accountJoao2011SoyMonsantoBr = new Account(AccountType.AVAILABLE,
                OwnerType.GROWER, saleTestFixture.joaoDaSilva.getId(),
                systemTestFixture.bt,
                saleTestFixture.harvest2011SoyMonsanto.getOperationalYear(), saleTestFixture.harvest2011SoyMonsanto.getCrop());
        saveAndFlush(accountJoao2011SoyMonsantoBr);

        Account accountJoao2009SoyMonsantoBr = new Account(AccountType.AVAILABLE,
                OwnerType.GROWER, saleTestFixture.joaoDaSilva.getId(),
                systemTestFixture.intacta,
                saleTestFixture.harvest2009SoyMonsanto.getOperationalYear(), saleTestFixture.harvest2009SoyMonsanto.getCrop());
        saveAndFlush(accountJoao2009SoyMonsantoBr);

        Account accountJoaoBlock = new Account(AccountType.BLOCKED,
                OwnerType.GROWER, saleTestFixture.joaoDaSilva.getId(),
                systemTestFixture.bt,
                saleTestFixture.harvestSoyMonsanto2012.getOperationalYear(), saleTestFixture.harvestSoyMonsanto2012.getCrop());
        saveAndFlush(accountJoaoBlock);

        Account accountJoaoSoyMonsantoUsaIntacta = new Account(AccountType.AVAILABLE,
                OwnerType.GROWER, saleTestFixture.joaoDaSilva.getId(),
                systemTestFixture.intactaEua, saleTestFixture.harvestSoyMonsantoEua2012.getOperationalYear(), saleTestFixture.harvestSoyMonsantoEua2012.getCrop());
        saveAndFlush(accountJoaoSoyMonsantoUsaIntacta);

        Account accountJoaoSoyMonsantoUsaBt = new Account(AccountType.AVAILABLE,
                OwnerType.GROWER, saleTestFixture.joaoDaSilva.getId(),
                systemTestFixture.btEua, saleTestFixture.harvestSoyMonsantoEua2012.getOperationalYear(), saleTestFixture.harvestSoyMonsantoEua2012.getCrop());
        saveAndFlush(accountJoaoSoyMonsantoUsaBt);

        Account accountJoaoSoyMonsantoUsaRr = new Account(AccountType.AVAILABLE,
                OwnerType.GROWER, saleTestFixture.joaoDaSilva.getId(),
                systemTestFixture.rrEua, saleTestFixture.harvestSoyMonsantoEua2012.getOperationalYear(), saleTestFixture.harvestSoyMonsantoEua2012.getCrop());
        saveAndFlush(accountJoaoSoyMonsantoUsaRr);
    }

    private UserDecorator getParticipantUser() {
        UserDecorator participantUser = accessControlIntent.participantUser;

        UserContract userContract = new UserContract(
                participantUser.getCurrentUser(),
                saleTestFixture.contractCargil, saleTestFixture.matrixCargil,
                HierarchyLevel.HEAD_OFFICE);

        saveAndFlush(userContract);

        participantUser.addUserContract(userContract);
        participantUser.setContextCrop(systemTestFixture.soy);

        return participantUser;
    }

    @Test
    public void given_a_sale_when_an_adminUser_with_selected_company_see_sales_for_details_shouldReturn_sales_only_of_his_company() throws BusinessException {
        Sale sale = saleFactory.createSale(saleTestFixture.matrixCargil, saleTestFixture.chicoBento, SaleTypeEnum.SALE_SEED);
        sale.setState(systemTestFixture.matoGrossoDoSul);
        SaleItem saleItemByPlantability = saleItemFactory.createByPlantabilityDueDateRangeItem(saleTestFixture.productIntactaSoy, saleTestFixture.templateIntactaByPlantabilityRRByExpirationBtFree, saleTestFixture.headOfficeCargil, 5l, SaleTestFixture.NOVEMBER, saleTestFixture.plantability45To54SoyMonsanto2012);
        sale.addItem(saleItemByPlantability);
        saveAValidSaleForAParticipant(sale);

        UserDecorator loggedAdminUser = accessControlIntent.userAdminOfMonsantoBr;
        loggedAdminUser.setContextCompany(systemTestFixture.monsantoBr);

        Sale saleFilter = saleService.getSaleForDetailBy(sale.getId(), loggedAdminUser);

        Assert.assertEquals("Size of items equals one", 1, saleFilter.getItems().size());
    }

    @Test
    public void when_search_sale_to_manual_release_filtering_by_harvest_shouldReturn_sale() throws SaleConstraintViolationException {
        Sale sale = createSaleWithSaleTemplateManually("1234", saleTestFixture.templateFixWithDueDateRange, saleTestFixture.productIntactaSoy);

        ManualReleaseCreditFilter filter = ManualReleaseCreditFilter.getInstance().add(saleTestFixture.templateFixWithDueDateRange.getHarvest());

        List<ManualReleaseCredit> sales = saleService.getSalesFor(filter);

        Assert.assertEquals("Size of sales equals one", 1, sales.size());
        Assert.assertEquals("Sale equals one", sale, sales.get(0).getSale());
        Assert.assertNotNull("Billing should be not null", sales.get(0).getBilling());
    }

    @Test
    public void when_search_sale_to_manual_release_filtering_by_Technology_shouldReturn_sale() throws SaleConstraintViolationException {
        createSaleWithSaleTemplateManually("1234", saleTestFixture.templateFixWithDueDateRange, saleTestFixture.productIntactaSoy);
        createSaleWithSaleTemplateManually("12345", saleTestFixture.templateRangeWithDueDateRange, saleTestFixture.productRRSoy);

        ManualReleaseCreditFilter filter = ManualReleaseCreditFilter.getInstance().add(saleTestFixture.productIntactaSoy.getTechnology());

        List<ManualReleaseCredit> sales = saleService.getSalesFor(filter);

        Assert.assertEquals("Size of sales equals one", 1, sales.size());
    }

    @Test
    public void when_search_sale_to_manual_release_filtering_by_crop_shouldReturn_sale() throws SaleConstraintViolationException {
        createSaleWithSaleTemplateManually("1234", saleTestFixture.templateFixWithDueDateRange, saleTestFixture.productIntactaSoy);

        ManualReleaseCreditFilter filter = ManualReleaseCreditFilter.getInstance().add(saleTestFixture.productIntactaSoy.getCrop());

        List<ManualReleaseCredit> sales = saleService.getSalesFor(filter);

        Assert.assertEquals("Size of sales equals one", 1, sales.size());
    }

    @Test
    public void when_search_sale_to_manual_release_filtering_by_company_shouldReturn_sale() throws SaleConstraintViolationException {
        createSaleWithSaleTemplateManually("1234", saleTestFixture.templateFixWithDueDateRange, saleTestFixture.productIntactaSoy);

        ManualReleaseCreditFilter filter = ManualReleaseCreditFilter.getInstance().add(saleTestFixture.productIntactaSoy.getCompany());

        List<ManualReleaseCredit> sales = saleService.getSalesFor(filter);

        Assert.assertEquals("Size of sales equals one", 1, sales.size());
    }

    @Test
    public void when_search_sale_to_manual_release_filtering_by_Matrix_shouldReturn_sale() throws SaleConstraintViolationException {
        createSaleWithSaleTemplateManually("1234", saleTestFixture.templateFixWithDueDateRange, saleTestFixture.productIntactaSoy);

        ManualReleaseCreditFilter filter = ManualReleaseCreditFilter.getInstance().addMatrix(saleTestFixture.officeCustomer.getMatrix());

        List<ManualReleaseCredit> sales = saleService.getSalesFor(filter);

        Assert.assertEquals("Size of sales equals one", 1, sales.size());
    }

    @Test
    public void when_search_sale_to_manual_release_filtering_by_Distributor_shouldReturn_sale() throws SaleConstraintViolationException {
        createSaleWithSaleTemplateManually("1234", saleTestFixture.templateFixWithDueDateRange, saleTestFixture.productIntactaSoy);

        ManualReleaseCreditFilter filter = ManualReleaseCreditFilter.getInstance().addDistributor(saleTestFixture.customer);

        List<ManualReleaseCredit> sales = saleService.getSalesFor(filter);

        Assert.assertEquals("Size of sales equals one", 1, sales.size());
    }

    @Test
    public void when_search_sale_to_manual_release_filtering_by_Grower_shouldReturn_sale() throws SaleConstraintViolationException {
        createSaleWithSaleTemplateManually("1234", saleTestFixture.templateFixWithDueDateRange, saleTestFixture.productIntactaSoy);

        ManualReleaseCreditFilter filter = ManualReleaseCreditFilter.getInstance().add(saleTestFixture.chicoBento);

        List<ManualReleaseCredit> sales = saleService.getSalesFor(filter);

        Assert.assertEquals("Size of sales equals one", 1, sales.size());
    }

    @Test
    public void when_search_sale_to_manual_release_filtering_by_period_shouldReturn_sale() throws SaleConstraintViolationException {
        createSaleWithSaleTemplateManually("1234", saleTestFixture.templateFixWithDueDateRange, saleTestFixture.productIntactaSoy);
        createSaleWithSaleTemplateManually("12345", saleTestFixture.templateRangeWithDueDateRange, saleTestFixture.productRRSoy);

        ManualReleaseCreditFilter filter = ManualReleaseCreditFilter.getInstance()
                .addCreationDateStart(SaleTestFixture.DATE_YESTERDAY)
                .addCreationDateEnd(SaleTestFixture.DATE_TOMORROW);

        List<ManualReleaseCredit> sales = saleService.getSalesFor(filter);

        Assert.assertEquals("Size of sales equals one", 2, sales.size());
    }

    @Test
    public void given_a_manual_release_sale_stored_when_search_and_release_manually_then_should_update_billing() throws SaleConstraintViolationException {
        createSaleWithSaleTemplateManually("1234", saleTestFixture.templateFixWithDueDateRange, saleTestFixture.productIntactaSoy);
        ManualReleaseCreditFilter filter = ManualReleaseCreditFilter.getInstance();

        List<ManualReleaseCredit> sales = saleService.getSalesFor(filter);

        saleService.manageManualReleases(sales);
        for (ManualReleaseCredit releaseCredit : sales) {
            Assert.assertEquals("Should have billing credit status = RELEASED MANUALLY", CreditStatus.RELEASED_MANUALLY, releaseCredit.getBilling().getCreditStatus());
        }

    }

    @Test
    @Ignore
    public void given_a_manual_release_sale_cancelled_when_search_then_should_return_empty() throws SaleConstraintViolationException, IndustrySystemOperationException {
        Sale sale = createSaleWithSaleTemplateManually("1234", saleTestFixture.templateFixWithDueDateRange, saleTestFixture.productIntactaSoy);
        saleService.cancelBillingPartially(sale.getId(), systemTestFixture.monsantoBr, saleTestFixture.saleCancellation, "ALANBK");

        ManualReleaseCreditFilter filter = ManualReleaseCreditFilter.getInstance();

        List<ManualReleaseCredit> sales = saleService.getSalesFor(filter);

        Assert.assertEquals("Should be length 0", 0, sales.size());
    }

    @Test
    public void given_a_manual_release_sale_stored_when_search_and_release_manually_then_should_have_correct_balance() throws SaleConstraintViolationException {
        createSaleWithSaleTemplateManually("1234", saleTestFixture.templateFixWithDueDateRange, saleTestFixture.productIntactaSoy);

        Account account = accountService.fetchOrCreateAccount(AccountType.BLOCKED, saleTestFixture.chicoBento, systemTestFixture.soy, systemTestFixture.intacta, systemTestFixture.operationalYearOf2012);
        Assert.assertEquals("Should be equal to 1010000", 1010000L, account.getBalance().longValue());
        account = accountService.fetchOrCreateAccount(AccountType.AVAILABLE, saleTestFixture.chicoBento, systemTestFixture.soy, systemTestFixture.intacta, systemTestFixture.operationalYearOf2012);
        Assert.assertEquals("Should be equal to 1010000", 0L, account.getBalance().longValue());

        ManualReleaseCreditFilter filter = ManualReleaseCreditFilter.getInstance();

        List<ManualReleaseCredit> sales = saleService.getSalesFor(filter);

        saleService.manageManualReleases(sales);
        for (ManualReleaseCredit releaseCredit : sales) {
            Assert.assertEquals("Should have billing credit status = RELEASED MANUALLY", CreditStatus.RELEASED_MANUALLY, releaseCredit.getBilling().getCreditStatus());
        }

        account = accountService.fetchOrCreateAccount(AccountType.AVAILABLE, saleTestFixture.chicoBento, systemTestFixture.soy, systemTestFixture.intacta, systemTestFixture.operationalYearOf2012);
        Assert.assertEquals("Should be equal to 1010000 ", 1010000L, account.getBalance().longValue());

    }

    @Test
    public void given_two_manual_release_sale_stored_when_search_and_release_one_manually_then_should_have_correct_balance_in_blocked_and_available() throws SaleConstraintViolationException {
        createTwoSalesWithSaleTemplateManually("1234", saleTestFixture.templateFixWithDueDateRange, saleTestFixture.productIntactaSoy);

        Account account = accountService.fetchOrCreateAccount(AccountType.BLOCKED, saleTestFixture.chicoBento, systemTestFixture.soy, systemTestFixture.intacta, systemTestFixture.operationalYearOf2012);
        Assert.assertEquals("Should be equal to 1010000", 2020000L, account.getBalance().longValue());
        account = accountService.fetchOrCreateAccount(AccountType.AVAILABLE, saleTestFixture.chicoBento, systemTestFixture.soy, systemTestFixture.intacta, systemTestFixture.operationalYearOf2012);
        Assert.assertEquals("Should be equal to 1010000", 0L, account.getBalance().longValue());

        ManualReleaseCreditFilter filter = ManualReleaseCreditFilter.getInstance();

        List<ManualReleaseCredit> sales = saleService.getSalesFor(filter);
        sales.remove(1);

        saleService.manageManualReleases(sales);
        for (ManualReleaseCredit releaseCredit : sales) {
            Assert.assertEquals("Should have billing credit status = RELEASED MANUALLY", CreditStatus.RELEASED_MANUALLY, releaseCredit.getBilling().getCreditStatus());
        }

        account = accountService.fetchOrCreateAccount(AccountType.AVAILABLE, saleTestFixture.chicoBento, systemTestFixture.soy, systemTestFixture.intacta, systemTestFixture.operationalYearOf2012);
        Assert.assertEquals("Should be equal to 1010000 ", 1010000L, account.getBalance().longValue());

    }

    @Test
    public void given_two_manual_release_sale_stored_when_search_and_release_both_manually_then_should_have_correct_balance_in_available() throws SaleConstraintViolationException {
        createTwoSalesWithSaleTemplateManually("1234", saleTestFixture.templateFixWithDueDateRange, saleTestFixture.productIntactaSoy);

        Account account = accountService.fetchOrCreateAccount(AccountType.BLOCKED, saleTestFixture.chicoBento, systemTestFixture.soy, systemTestFixture.intacta, systemTestFixture.operationalYearOf2012);
        Assert.assertEquals("Should be equal to 1010000", 2020000L, account.getBalance().longValue());
        account = accountService.fetchOrCreateAccount(AccountType.AVAILABLE, saleTestFixture.chicoBento, systemTestFixture.soy, systemTestFixture.intacta, systemTestFixture.operationalYearOf2012);
        Assert.assertEquals("Should be equal to 1010000", 0L, account.getBalance().longValue());

        ManualReleaseCreditFilter filter = ManualReleaseCreditFilter.getInstance();

        List<ManualReleaseCredit> sales = saleService.getSalesFor(filter);

        saleService.manageManualReleases(sales);
        for (ManualReleaseCredit releaseCredit : sales) {
            Assert.assertEquals("Should have billing credit status = RELEASED MANUALLY", CreditStatus.RELEASED_MANUALLY, releaseCredit.getBilling().getCreditStatus());
        }

        account = accountService.fetchOrCreateAccount(AccountType.AVAILABLE, saleTestFixture.chicoBento, systemTestFixture.soy, systemTestFixture.intacta, systemTestFixture.operationalYearOf2012);
        Assert.assertEquals("Should be equal to 1010000 ", 2020000L, account.getBalance().longValue());

    }

    private Sale createSaleWithSaleTemplateManually(String invoiceNumber, SaleTemplate saleTemplate, Product product) throws SaleConstraintViolationException {

        saleTemplate.getPriceOf(product.getTechnology()).setReleaseCreditType(ReleaseCreditTypeEnum.MANUALLY);
        saveAndFlush(saleTemplate);

        return createGenericSale(invoiceNumber, saleTemplate, product);
    }

    private void createTwoSalesWithSaleTemplateManually(String invoiceNumber, SaleTemplate saleTemplate, Product product) throws SaleConstraintViolationException {

        saleTemplate.getPriceOf(product.getTechnology()).setReleaseCreditType(ReleaseCreditTypeEnum.MANUALLY);
        saveAndFlush(saleTemplate);

        createGenericSale(invoiceNumber, saleTemplate, product);
        createGenericSale(invoiceNumber + "8", saleTemplate, product);
    }

    private Sale createGenericSale(String invoiceNumber, SaleTemplate saleTemplate, Product product) throws SaleConstraintViolationException {

        builder = new SaleBuilder(systemTestFixture.matoGrossoDoSul, saleTestFixture.plantabilitiesSelector);

        builder.clear();
        builder.addSaleItem(product,
                saleTemplate,
                saleTestFixture.officeCustomer,
                2000L,
                SaleTestFixture.TWO_POINT_FIVE_DOLLARS,
                saleTestFixture.plantabilitySystemSoyMonsanto2012,
                SaleTestFixture.APRIL);

        Sale sale = builder.setGrower(saleTestFixture.chicoBento).setCustomer(saleTestFixture.customer).buildSale();
        sale.setCreationDate(SaleTestFixture.DATE_NOW);
        sale.setRegion(systemTestFixture.regionSaoPaulo2012);

        if (invoiceNumber != null) {
            sale.setInvoiceNumber(invoiceNumber);
        }

        accessControlTestFixture.superUser.setContextCrop(systemTestFixture.soy);
        accessControlTestFixture.superUser.setContextCompany(systemTestFixture.monsantoBr);

        saleService.save(sale, accessControlTestFixture.superUser);
        return sale;
    }

    @Test
    public void given_paid_partial_billing_when_CancellationManualPayment_was_called_then_should_reversed_credits() throws BusinessException {
        Sale sale = saleFactory.createSale(saleTestFixture.matrixCargil, saleTestFixture.chicoBento, SaleTypeEnum.SALE_SEED);
        sale.setState(systemTestFixture.matoGrossoDoSul);
        SaleItem saleItemByPlantability = saleItemFactory.createByPlantabilityDueDateRangeItem(saleTestFixture.productIntactaSoy, saleTestFixture.templateIntactaByPlantabilityRRByExpirationBtFree, saleTestFixture.headOfficeCargil, 5l, SaleTestFixture.NOVEMBER, saleTestFixture.plantability45To54SoyMonsanto2012);
        sale.addItem(saleItemByPlantability);
        saveAValidSaleForAParticipant(sale);

        UserDecorator loggedSuperUser = accessControlIntent.superUser;
        loggedSuperUser.setContextCrop(systemTestFixture.soy);

        BillingFilter billingFilter = BillingFilter.getInstance()
                .add(sale.getId())
                .add(loggedSuperUser);

        List<BillingDTO> billingDTOList = saleService.getBillingsOfSale(billingFilter).getDecoratedBillings();

        Assert.assertEquals("Correct number of billing", 1, billingDTOList.size());

        Date nowDate = new Date();
        saleService.payBilling(billingDTOList.get(0).getBilling(), nowDate, BigDecimal.ONE, true);

        saleService.cancelPayment(billingDTOList.get(0).getBilling());

        billingFilter = BillingFilter.getInstance()
                .add(sale.getId())
                .add(loggedSuperUser);

        billingDTOList = saleService.getBillingsOfSale(billingFilter).getDecoratedBillings();

        Assert.assertFalse("Should not have been paid", billingDTOList.get(0).getBilling().isPaid());
        Assert.assertEquals("Should have been peding status", PaymentStatus.NOT_PAID, billingDTOList.get(0).getBilling().getPaymentStatus());

    }

    @Test
    public void given_paid_billing_when_CancellationManualPayment_was_called_then_should_reversed_credits() throws BusinessException {
        Sale sale = saleFactory.createSale(saleTestFixture.matrixCargil, saleTestFixture.chicoBento, SaleTypeEnum.SALE_SEED);
        sale.setState(systemTestFixture.matoGrossoDoSul);
        SaleItem saleItemByPlantability = saleItemFactory.createByPlantabilityDueDateRangeItem(saleTestFixture.productIntactaSoy, saleTestFixture.templateIntactaByPlantabilityRRByExpirationBtFree, saleTestFixture.headOfficeCargil, 5l, SaleTestFixture.NOVEMBER, saleTestFixture.plantability45To54SoyMonsanto2012);
        sale.addItem(saleItemByPlantability);
        saveAValidSaleForAParticipant(sale);

        UserDecorator loggedSuperUser = accessControlIntent.superUser;
        loggedSuperUser.setContextCrop(systemTestFixture.soy);

        BillingFilter billingFilter = BillingFilter.getInstance()
                .add(sale.getId())
                .add(loggedSuperUser);

        List<BillingDTO> billingDTOList = saleService.getBillingsOfSale(billingFilter).getDecoratedBillings();

        Assert.assertEquals("Correct number of billing", 1, billingDTOList.size());

        Date nowDate = new Date();
        saleService.payBilling(billingDTOList.get(0).getBilling(), nowDate, new BigDecimal(3.5D), true);

        saleService.cancelPayment(billingDTOList.get(0).getBilling());

        billingFilter = BillingFilter.getInstance()
                .add(sale.getId())
                .add(loggedSuperUser);

        billingDTOList = saleService.getBillingsOfSale(billingFilter)
                .getDecoratedBillings();

        Assert.assertFalse("Should not have been paid", billingDTOList.get(0)
                .getBilling().isPaid());
        Assert.assertEquals("Should have been peding status",
                PaymentStatus.NOT_PAID, billingDTOList.get(0).getBilling()
                        .getPaymentStatus());
    }

    @Ignore
    public void given_two_sales_when_multiple_cancel_then_should_cancel_all() throws BusinessException {
        List<Sale> sales = new ArrayList<Sale>();
        Sale sale = createGenericSale("12345", saleTestFixture.templateFixWithDueDateRange, saleTestFixture.productIntactaSoy);
        sales.add(sale);

        sale = createGenericSale("123456", saleTestFixture.templateFixWithDueDateRange, saleTestFixture.productIntactaSoy);
        sales.add(sale);

        accessControlIntent.superUser.setContextCompany(systemTestFixture.monsantoBr);
        accessControlIntent.superUser.setContextCrop(systemTestFixture.soy);

        saleService.handleCancelMultipleSales(sales, accessControlIntent.superUser.getAllCompaniesForContext(), saleTestFixture.saleCancellation, "JOHN");
        SaleFilter filter = SaleFilter.getInstance().addCreationDateStart(new Date(0));
        sales = saleService.getSaleBy(filter);
        Iterator<Sale> iterator = sales.iterator();
        sale = iterator.next();
        Assert.assertEquals("Should be cancelled", PaymentStatus.CANCELLED, sale.getItems().iterator().next().getBilling().getPaymentStatus());
        sale = iterator.next();
        Assert.assertEquals("Should be cancelled", PaymentStatus.CANCELLED, sale.getItems().iterator().next().getBilling().getPaymentStatus());
    }

    @Test(expected = BillingCancellationWarningException.class)
    public void given_a_sales_when_multiple_cancel_without_balance_then_should_throw_exception() throws BusinessException, ManualCreditConstraintException {
        List<Sale> sales = new ArrayList<Sale>();
        saleTestFixture.templateFixWithDueDateRange.getPriceOf(saleTestFixture.productIntactaSoy.getTechnology()).setReleaseCreditType(ReleaseCreditTypeEnum.AUTOMATICALLY);
        saveAndFlush(saleTestFixture.templateFixWithDueDateRange);
        Sale sale = createGenericSale("12345", saleTestFixture.templateFixWithDueDateRange, saleTestFixture.productIntactaSoy);
        sales.add(sale);

        accountService.generateCreditManually(saleTestFixture.productIntactaSoy.getCrop(), saleTestFixture.templateFixWithDueDateRange.getHarvest().getOperationalYear(), saleTestFixture.productIntactaSoy.getTechnology(), saleTestFixture.chicoBento, ManualCreditTransactionType.DEBIT, BigDecimal.ONE, "dunno", "ANDREGC");

        accessControlIntent.superUser.setContextCompany(systemTestFixture.monsantoBr);
        accessControlIntent.superUser.setContextCrop(systemTestFixture.soy);

        saleService.handleCancelMultipleSales(sales, accessControlIntent.superUser.getAllCompaniesForContext(), saleTestFixture.saleCancellation, "JOHN");

//        SaleFilter filter = SaleFilter.getInstance().addCreationDateStart(new Date(0));
//        sales = saleService.getSaleBy(filter);
//        Iterator<Sale> iterator = sales.iterator();
//        sale = iterator.next();
//        Assert.assertEquals("Should be cancelled", PaymentStatus.CANCELLED, sale.getItems().iterator().next().getBilling().getPaymentStatus());
    }

    @Test(expected = BillingCancellationWarningException.class)
    public void given_a_sales_when_multiple_cancel_without_cancellation_then_should_throw_exception() throws BusinessException, ManualCreditConstraintException {
        List<Sale> sales = new ArrayList<Sale>();
        saleTestFixture.templateFixWithDueDateRange.getPriceOf(saleTestFixture.productIntactaSoy.getTechnology()).setReleaseCreditType(ReleaseCreditTypeEnum.AUTOMATICALLY);
        saveAndFlush(saleTestFixture.templateFixWithDueDateRange);
        Sale sale = createGenericSale("12345", saleTestFixture.templateFixWithDueDateRange, saleTestFixture.productIntactaSoy);
        sales.add(sale);

        accountService.generateCreditManually(saleTestFixture.productIntactaSoy.getCrop(), saleTestFixture.templateFixWithDueDateRange.getHarvest().getOperationalYear(), saleTestFixture.productIntactaSoy.getTechnology(), saleTestFixture.chicoBento, ManualCreditTransactionType.DEBIT, BigDecimal.ONE, "dunno", "ANDREGC");

        accessControlIntent.superUser.setContextCompany(systemTestFixture.monsantoBr);
        accessControlIntent.superUser.setContextCrop(systemTestFixture.soy);

        saleService.handleCancelMultipleSales(sales, accessControlIntent.superUser.getAllCompaniesForContext(), null, "JOHN");

//        SaleFilter filter = SaleFilter.getInstance().addCreationDateStart(new Date(0));
//        sales = saleService.getSaleBy(filter);
//        Iterator<Sale> iterator = sales.iterator();
//        sale = iterator.next();
//        Assert.assertEquals("Should be cancelled", PaymentStatus.CANCELLED, sale.getItems().iterator().next().getBilling().getPaymentStatus());
    }

    @Test(expected = BillingCancellationWarningException.class)
    public void given_not_paid_manual_billing_when_CancellationManualPayment_was_called_then_should_throw_exception() throws BusinessException {
        Sale sale = saleFactory.createSale(saleTestFixture.matrixCargil, saleTestFixture.chicoBento, SaleTypeEnum.SALE_SEED);
        sale.setState(systemTestFixture.matoGrossoDoSul);
        SaleItem saleItemByPlantability = saleItemFactory.createByPlantabilityDueDateRangeItem(saleTestFixture.productIntactaSoy, saleTestFixture.templateIntactaByPlantabilityRRByExpirationBtFree, saleTestFixture.headOfficeCargil, 5l, SaleTestFixture.NOVEMBER, saleTestFixture.plantability45To54SoyMonsanto2012);
        sale.addItem(saleItemByPlantability);
        saveAValidSaleForAParticipant(sale);

        UserDecorator loggedSuperUser = accessControlIntent.superUser;
        loggedSuperUser.setContextCrop(systemTestFixture.soy);

        BillingFilter billingFilter = BillingFilter.getInstance()
                .add(sale.getId())
                .add(loggedSuperUser);

        List<BillingDTO> billingDTOList = saleService.getBillingsOfSale(billingFilter).getDecoratedBillings();

        Assert.assertEquals("Correct number of billing", 1, billingDTOList.size());

        Date nowDate = new Date();
        saleService.payBilling(billingDTOList.get(0).getBilling(), nowDate, new BigDecimal(3.5D), false);

        saleService.verifyCancelManualPayment(sale, systemTestFixture.monsantoBr);
    }

    @Test(expected = BillingCancellationWarningException.class)
    public void given_paid_manual_billing_no_has_balance_when_CancellationManualPayment_was_called_then_should_throw_exception() throws BusinessException, ManualCreditConstraintException {
        Sale sale = saleFactory.createSale(saleTestFixture.matrixCargil, saleTestFixture.chicoBento, SaleTypeEnum.SALE_SEED);
        sale.setState(systemTestFixture.matoGrossoDoSul);
        SaleItem saleItemByPlantability = saleItemFactory.createByPlantabilityDueDateRangeItem(saleTestFixture.productIntactaSoy, saleTestFixture.templateIntactaByPlantabilityRRByExpirationBtFree, saleTestFixture.headOfficeCargil, 5l, SaleTestFixture.NOVEMBER, saleTestFixture.plantability45To54SoyMonsanto2012);
        sale.addItem(saleItemByPlantability);
        saveAValidSaleForAParticipant(sale);

        UserDecorator loggedSuperUser = accessControlIntent.superUser;
        loggedSuperUser.setContextCrop(systemTestFixture.soy);

        BillingFilter billingFilter = BillingFilter.getInstance()
                .add(sale.getId())
                .add(loggedSuperUser);

        List<BillingDTO> billingDTOList = saleService.getBillingsOfSale(billingFilter).getDecoratedBillings();

        Assert.assertEquals("Correct number of billing", 1, billingDTOList.size());

        Date nowDate = new Date();
        saleService.payBilling(billingDTOList.get(0).getBilling(), nowDate, new BigDecimal(3.5D), true);

        accountService.generateCreditManually(systemTestFixture.soy, saleTestFixture.templateIntactaByPlantabilityRRByExpirationBtFree.getHarvest().getOperationalYear(), systemTestFixture.intacta, saleTestFixture.chicoBento,
                ManualCreditTransactionType.DEBIT, SaleTestFixture.TWO_POINT_FIVE_DOLLARS, "Test reason 1", "ANDREGC");

        saleService.cancelPayment(billingDTOList.get(0).getBilling());
    }

    @Test
    public void given_paid_manual_billing_when_CancellationManualPayment_and_after_pay_again() throws BusinessException, ManualCreditConstraintException {
        Sale sale = saleFactory.createSale(saleTestFixture.matrixCargil, saleTestFixture.chicoBento, SaleTypeEnum.SALE_SEED);
        sale.setState(systemTestFixture.matoGrossoDoSul);
        SaleItem saleItemByPlantability = saleItemFactory.createByPlantabilityDueDateRangeItem(saleTestFixture.productIntactaSoy, saleTestFixture.templateIntactaByPlantabilityRRByExpirationBtFree, saleTestFixture.headOfficeCargil, 5l, SaleTestFixture.NOVEMBER, saleTestFixture.plantability45To54SoyMonsanto2012);
        sale.addItem(saleItemByPlantability);
        saveAValidSaleForAParticipant(sale);

        UserDecorator loggedSuperUser = accessControlIntent.superUser;
        loggedSuperUser.setContextCrop(systemTestFixture.soy);

        BillingFilter billingFilter = BillingFilter.getInstance()
                .add(sale.getId())
                .add(loggedSuperUser);

        List<BillingDTO> billingDTOList = saleService.getBillingsOfSale(billingFilter).getDecoratedBillings();

        Assert.assertEquals("Correct number of billing", 1, billingDTOList.size());

        Date nowDate = new Date();
        saleService.payBilling(billingDTOList.get(0).getBilling(), nowDate, new BigDecimal(3.5D), true);

        saleService.cancelPayment(billingDTOList.get(0).getBilling());

        saleService.payBilling(billingDTOList.get(0).getBilling(), nowDate, new BigDecimal(3.5D), true);
    }

    @Test
    public void given_unpaid_erp_sale_when_search_for_sales_to_revenue_then_should_return_erp_unapaid_sales() throws BusinessException {
        Sale sale = saleFactory.createSale(saleTestFixture.matrixCargil, saleTestFixture.chicoBento, SaleTypeEnum.SALE_SEED);
        sale.setState(systemTestFixture.matoGrossoDoSul);
        SaleItem saleItemByPlantability = saleItemFactory.createByPlantabilityDueDateRangeItem(saleTestFixture.productIntactaSoy, saleTestFixture.templateIntactaByPlantabilityRRByExpirationBtFreeErp, saleTestFixture.headOfficeCargil, 5l, SaleTestFixture.NOVEMBER, saleTestFixture.plantability45To54SoyMonsanto2012);
        sale.addItem(saleItemByPlantability);
        saveAValidSaleForAParticipant(sale);
        getSession().evict(sale);

        sale = saleFactory.createSale(saleTestFixture.matrixCargil, saleTestFixture.chicoBento, SaleTypeEnum.SALE_SEED);
        sale.setState(systemTestFixture.matoGrossoDoSul);
        saleItemByPlantability = saleItemFactory.createByPlantabilityDueDateRangeItem(saleTestFixture.productIntactaSoy, saleTestFixture.templateIntactaByPlantabilityRRByExpirationBtFree, saleTestFixture.headOfficeCargil, 5l, SaleTestFixture.NOVEMBER, saleTestFixture.plantability45To54SoyMonsanto2012);
        sale.addItem(saleItemByPlantability);
        saveAValidSaleForAParticipant(sale, false);

        // TODO: this can be a problem, once we're preventing UNPAID/ERP sales from being paid -- maybe change this to revenued when is ready (?)
        sale = saleFactory.createSale(saleTestFixture.matrixCargil, saleTestFixture.chicoBento, SaleTypeEnum.SALE_SEED);
        sale.setState(systemTestFixture.matoGrossoDoSul);
        saleItemByPlantability = saleItemFactory.createByPlantabilityDueDateRangeItem(saleTestFixture.productIntactaSoy, saleTestFixture.templateIntactaByPlantabilityRRByExpirationBtFreeErp, saleTestFixture.headOfficeCargil, 5l, SaleTestFixture.NOVEMBER, saleTestFixture.plantability45To54SoyMonsanto2012);
        sale.addItem(saleItemByPlantability);
        saveAValidSaleForAParticipant(sale, false);

        UserDecorator loggedSuperUser = accessControlIntent.superUser;
        loggedSuperUser.setContextCrop(systemTestFixture.soy);

        BillingFilter billingFilter = BillingFilter.getInstance()
                .add(sale.getId())
                .add(loggedSuperUser);

        List<BillingDTO> billingDTOList = saleService.getBillingsOfSale(billingFilter).getDecoratedBillings();

        Date nowDate = new Date();
        saleService.payBilling(billingDTOList.get(0).getBilling(), nowDate, new BigDecimal(3.5D), true);

        List<SaleItem> saleItems = saleService.getSaleItemsBy(RevenueSaleItemFilter.getInstance());
        Assert.assertEquals("Should have 1 entry", 1, saleItems.size());

    }

    @Test
    public void given_a_billing_with_one_item_when_i_pay_the_billing_then_sale_item_should_calculate_retribution_fees() throws BusinessException {
        Billing billing = createAndPayManuallyBillingWithSaleItemsThatHaveFees();

        Set<SaleItem> saleItems = billing.getItems();
        for (SaleItem saleItem : saleItems) {
            Assert.assertEquals("Retribution Fee value should be equals.", BigDecimal.ONE.setScale(2), saleItem.getRetributionFeeValue());
            Assert.assertEquals("Marketing Program value should be equals.", BigDecimal.ONE.setScale(2), saleItem.getMarketingProgramValue());
        }

    }

    @Test
    public void given_a_billing_manual_paid_with_one_item_that_have_retribution_fees_when_i_cancel_the_payment_then_fees_should_be_null() throws BusinessException {
        Billing billing = createAndPayManuallyBillingWithSaleItemsThatHaveFees();
        saleService.cancelPayment(billing);

        Set<SaleItem> saleItems = billing.getItems();
        for (SaleItem saleItem : saleItems) {
            Assert.assertNull("Retribution Fee value should be null.", saleItem.getRetributionFeeValue());
            Assert.assertNull("Marketing Program value should be null.", saleItem.getMarketingProgramValue());
        }
    }

    private Billing createAndPayManuallyBillingWithSaleItemsThatHaveFees()
            throws BusinessException, BillingConstraintViolationException {
        Billing billing = createBillingWithOneSaleItemThatHaveFees();
        saleService.payBilling(billing, SaleTestFixture.JANUARY, BigDecimal.TEN, true);
        return billing;
    }

    private Billing createBillingWithOneSaleItemThatHaveFees()
            throws BusinessException {
        Sale sale = saleFactory.createSale(saleTestFixture.matrixCargil, saleTestFixture.chicoBento, SaleTypeEnum.SALE_SEED);
        sale.setState(systemTestFixture.matoGrossoDoSul);

        SaleItem saleItemFix = saleItemFactory
                .createFixValueItem(saleTestFixture.productIntactaSoy,
                        saleTestFixture.templateIntactaFixRRRangeBtNoValue,
                        saleTestFixture.headOfficeCargil, 2L);

        sale.addItem(saleItemFix);
        saveAValidSaleForAParticipant(sale);

        UserDecorator loggedSuperUser = accessControlIntent.superUser;
        loggedSuperUser.setContextCrop(systemTestFixture.soy);

        BillingFilter billingFilter = BillingFilter.getInstance()
                .add(sale.getId())
                .add(loggedSuperUser);

        List<BillingDTO> billingDTOList = saleService.getBillingsOfSale(billingFilter).getDecoratedBillings();

        Assert.assertEquals("Correct number of billing", 1, billingDTOList.size());

        Billing billing = billingDTOList.get(0).getBilling();
        return billing;
    }

    @Test
    public void given_a_valid_sale_ERP_when_superUser_search_for_sales_paid_manually_should_return_sale() throws BusinessException {
        Sale sale = saleFactory.createSale(saleTestFixture.matrixCargil, saleTestFixture.chicoBento, SaleTypeEnum.SALE_SEED);
        sale.setState(systemTestFixture.matoGrossoDoSul);
        SaleItem saleItemByPlantability = saleItemFactory.createByPlantabilityDueDateRangeItem(saleTestFixture.productIntactaSoy, saleTestFixture.templateIntactaByPlantabilityRRByExpirationBtFree, saleTestFixture.headOfficeCargil, 5l, SaleTestFixture.NOVEMBER, saleTestFixture.plantability45To54SoyMonsanto2012);
        sale.addItem(saleItemByPlantability);
        saveAValidSaleForAParticipant(sale);

        UserDecorator loggedSuperUser = accessControlIntent.superUser;
        loggedSuperUser.setContextCrop(systemTestFixture.soy);

        BillingFilter billingFilter = BillingFilter.getInstance()
                .add(sale.getId())
                .add(loggedSuperUser);

        List<BillingDTO> billingDTOList = saleService.getBillingsOfSale(billingFilter).getDecoratedBillings();

        Assert.assertEquals("Correct number of billing", 1, billingDTOList.size());

        Date nowDate = new Date();
        Billing billing = billingDTOList.get(0).getBilling();
        billing.setBillingMethod(SaleTemplateBillingMethodEnum.ERP);
        saleService.payBilling(billing, nowDate, BigDecimal.ONE, true);

        RevenueAccount revenueAccount = new RevenueAccount(saleTestFixture.matrixCargil, "111", systemTestFixture.operationalYearOf2009, RevenueType.DISTRIBUTION, systemTestFixture.monsantoBr, new Date(), new Date());
        revenueAccount.setTotalRevenueBonus(BigDecimal.valueOf(100.22d));
        revenueAccount.setTotalRevenueMarketingFee(BigDecimal.valueOf(22.22d));
        revenueAccount.setTotalRevenueRetributionFee(BigDecimal.valueOf(432.1d));
        revenueAccount.setTotalRevenueValue(BigDecimal.valueOf(66.22d));
        revenueAccount.setIsZNET(false);

        OrderItem orderItem = new OrderItem();
        revenueAccount.addItem(orderItem);
        orderItem.setAmount(new BigDecimal(100));
        orderItem.setBonusValue(BigDecimal.valueOf(100.55d));
        orderItem.setCode("1111");
        orderItem.setComissionValue(BigDecimal.valueOf(55.22d));
        orderItem.setDescription("12345");
        orderItem.setMarketingValue(BigDecimal.valueOf(1234.56d));
        orderItem.setValue(BigDecimal.valueOf(111.22d));

        RevenueHandle handle = new RevenueHandle(1L);
        revenueAccount.addHandle(handle);

        RevenueAdditionalCondition additionalCondition = new RevenueAdditionalCondition(BigDecimal.valueOf(10.5d), ConditionEnum.CREDIT_CONSUMPTION);
        revenueAccount.addAdditionalCondition(additionalCondition);

        Assert.assertEquals("Should have 1 item", 1, revenueAccount.getItems().size());
        saveAndFlush(revenueAccount);

        saleItemByPlantability.setRevenueAccount(revenueAccount);
        saveAndFlush(saleItemByPlantability);

        SaleFilter saleFilter = SaleFilter.getInstance();
        saleFilter.add(loggedSuperUser);
        saleFilter.addCreationDateEnd(new Date());

        List<PaymentStatus> statusEq = new ArrayList<PaymentStatus>();
        statusEq.add(PaymentStatus.PARCIAL_PAID);
        statusEq.add(PaymentStatus.FULLY_PAID);
        saleFilter.addBillingStatusEqAndPayManual(statusEq);

        List<Sale> sales = saleService.getSaleBy(saleFilter);

        Assert.assertEquals("Correct number of sales", 1, sales.size());
    }

    @Test
    public void given_a_valid_sale_ERP_when_superUser_search_for_sales_paid_manually_but_revenue_paid_should_not_return_sale() throws BusinessException {
        Sale sale = saleFactory.createSale(saleTestFixture.matrixCargil, saleTestFixture.chicoBento, SaleTypeEnum.SALE_SEED);
        sale.setState(systemTestFixture.matoGrossoDoSul);
        SaleItem saleItemByPlantability = saleItemFactory.createByPlantabilityDueDateRangeItem(saleTestFixture.productIntactaSoy, saleTestFixture.templateIntactaByPlantabilityRRByExpirationBtFree, saleTestFixture.headOfficeCargil, 5l, SaleTestFixture.NOVEMBER, saleTestFixture.plantability45To54SoyMonsanto2012);
        sale.addItem(saleItemByPlantability);
        saveAValidSaleForAParticipant(sale);

        UserDecorator loggedSuperUser = accessControlIntent.superUser;
        loggedSuperUser.setContextCrop(systemTestFixture.soy);

        BillingFilter billingFilter = BillingFilter.getInstance()
                .add(sale.getId())
                .add(loggedSuperUser);

        List<BillingDTO> billingDTOList = saleService.getBillingsOfSale(billingFilter).getDecoratedBillings();

        Assert.assertEquals("Correct number of billing", 1, billingDTOList.size());

        Date nowDate = new Date();
        Billing billing = billingDTOList.get(0).getBilling();
        billing.setBillingMethod(SaleTemplateBillingMethodEnum.ERP);
        saleService.payBilling(billing, nowDate, BigDecimal.ONE, true);

        RevenueAccount revenueAccount = new RevenueAccount(saleTestFixture.matrixCargil, "111", systemTestFixture.operationalYearOf2009, RevenueType.DISTRIBUTION, systemTestFixture.monsantoBr, new Date(), new Date());
        revenueAccount.setTotalRevenueBonus(BigDecimal.valueOf(100.22d));
        revenueAccount.setTotalRevenueMarketingFee(BigDecimal.valueOf(22.22d));
        revenueAccount.setTotalRevenueRetributionFee(BigDecimal.valueOf(432.1d));
        revenueAccount.setTotalRevenueValue(BigDecimal.valueOf(66.22d));
        revenueAccount.setStatus(RevenueStatus.PAID);
        revenueAccount.setIsZNET(false);

        OrderItem orderItem = new OrderItem();
        revenueAccount.addItem(orderItem);
        orderItem.setAmount(new BigDecimal(100));
        orderItem.setBonusValue(BigDecimal.valueOf(100.55d));
        orderItem.setCode("1111");
        orderItem.setComissionValue(BigDecimal.valueOf(55.22d));
        orderItem.setDescription("12345");
        orderItem.setMarketingValue(BigDecimal.valueOf(1234.56d));
        orderItem.setValue(BigDecimal.valueOf(111.22d));

        RevenueHandle handle = new RevenueHandle(1L);
        revenueAccount.addHandle(handle);

        RevenueAdditionalCondition additionalCondition = new RevenueAdditionalCondition(BigDecimal.valueOf(10.5d), ConditionEnum.CREDIT_CONSUMPTION);
        revenueAccount.addAdditionalCondition(additionalCondition);

        Assert.assertEquals("Should have 1 item", 1, revenueAccount.getItems().size());
        saveAndFlush(revenueAccount);

        saleItemByPlantability.setRevenueAccount(revenueAccount);
        saveAndFlush(saleItemByPlantability);

        SaleFilter saleFilter = SaleFilter.getInstance();
        saleFilter.add(loggedSuperUser);
        saleFilter.addCreationDateEnd(new Date());

        List<PaymentStatus> statusEq = new ArrayList<PaymentStatus>();
        statusEq.add(PaymentStatus.PARCIAL_PAID);
        statusEq.add(PaymentStatus.FULLY_PAID);
        saleFilter.addBillingStatusEqAndPayManual(statusEq);

        List<Sale> sales = saleService.getSaleBy(saleFilter);

        Assert.assertEquals("Correct number of sales", 0, sales.size());
    }

    @Test
    public void given_a_valid_sale_ERP_and_BANKSLIP_when_superUser_search_for_sales_paid_manually_but_revenue_paid_should_not_return_sale() throws BusinessException {
        Sale sale = saleFactory.createSale(saleTestFixture.matrixCargil, saleTestFixture.chicoBento, SaleTypeEnum.SALE_SEED);
        sale.setState(systemTestFixture.matoGrossoDoSul);
        SaleItem saleItemByPlantability = saleItemFactory.createByPlantabilityDueDateRangeItem(saleTestFixture.productIntactaSoy, saleTestFixture.templateIntactaByPlantabilityRRByExpirationBtFree, saleTestFixture.headOfficeCargil, 5l, SaleTestFixture.NOVEMBER, saleTestFixture.plantability45To54SoyMonsanto2012);
        sale.addItem(saleItemByPlantability);
        SaleItem saleItemByPlantability2 = saleItemFactory.createByExpirationDateItem(saleTestFixture.productRRSoy, saleTestFixture.templateIntactaByPlantabilityRRByExpirationBtFree, saleTestFixture.headOfficeCargil, 5l);
        sale.addItem(saleItemByPlantability2);
        saveAValidSaleForAParticipant(sale);

        UserDecorator loggedSuperUser = accessControlIntent.superUser;
        loggedSuperUser.setContextCrop(systemTestFixture.soy);

        BillingFilter billingFilter = BillingFilter.getInstance()
                .add(sale.getId())
                .add(loggedSuperUser);

        List<BillingDTO> billingDTOList = saleService.getBillingsOfSale(billingFilter).getDecoratedBillings();

        Assert.assertEquals("Correct number of billing", 2, billingDTOList.size());

        Date nowDate = new Date();
        Billing billing = billingDTOList.get(0).getBilling();
        billing.setBillingMethod(SaleTemplateBillingMethodEnum.ERP);
        saleService.payBilling(billing, nowDate, BigDecimal.ONE, true);

        RevenueAccount revenueAccount = new RevenueAccount(saleTestFixture.matrixCargil, "111", systemTestFixture.operationalYearOf2009, RevenueType.DISTRIBUTION, systemTestFixture.monsantoBr, new Date(), new Date());
        revenueAccount.setTotalRevenueBonus(BigDecimal.valueOf(100.22d));
        revenueAccount.setTotalRevenueMarketingFee(BigDecimal.valueOf(22.22d));
        revenueAccount.setTotalRevenueRetributionFee(BigDecimal.valueOf(432.1d));
        revenueAccount.setTotalRevenueValue(BigDecimal.valueOf(66.22d));
        revenueAccount.setStatus(RevenueStatus.PAID);
        revenueAccount.setIsZNET(false);

        OrderItem orderItem = new OrderItem();
        revenueAccount.addItem(orderItem);
        orderItem.setAmount(new BigDecimal(100));
        orderItem.setBonusValue(BigDecimal.valueOf(100.55d));
        orderItem.setCode("1111");
        orderItem.setComissionValue(BigDecimal.valueOf(55.22d));
        orderItem.setDescription("12345");
        orderItem.setMarketingValue(BigDecimal.valueOf(1234.56d));
        orderItem.setValue(BigDecimal.valueOf(111.22d));

        RevenueHandle handle = new RevenueHandle(1L);
        revenueAccount.addHandle(handle);

        RevenueAdditionalCondition additionalCondition = new RevenueAdditionalCondition(BigDecimal.valueOf(10.5d), ConditionEnum.CREDIT_CONSUMPTION);
        revenueAccount.addAdditionalCondition(additionalCondition);

        Assert.assertEquals("Should have 1 item", 1, revenueAccount.getItems().size());
        saveAndFlush(revenueAccount);

        SaleItem saleItem = billing.getItems().iterator().next();
        saleItem.setRevenueAccount(revenueAccount);
        saveAndFlush(saleItem);

        SaleFilter saleFilter = SaleFilter.getInstance();
        saleFilter.add(loggedSuperUser);
        saleFilter.addCreationDateEnd(new Date());

        List<PaymentStatus> statusEq = new ArrayList<PaymentStatus>();
        statusEq.add(PaymentStatus.PARCIAL_PAID);
        statusEq.add(PaymentStatus.FULLY_PAID);
        saleFilter.addBillingStatusEqAndPayManual(statusEq);

        List<Sale> sales = saleService.getSaleBy(saleFilter);

        Assert.assertEquals("Correct number of sales", 0, sales.size());
    }

    @Test
    public void given_a_valid_sale_ERP_and_BANKSLIP_when_superUser_search_for_sales_paid_manually_but_revenue_billed_should_return_sale() throws BusinessException {
        Sale sale = saleFactory.createSale(saleTestFixture.matrixCargil, saleTestFixture.chicoBento, SaleTypeEnum.SALE_SEED);
        sale.setState(systemTestFixture.matoGrossoDoSul);
        SaleItem saleItemByPlantability = saleItemFactory.createByPlantabilityDueDateRangeItem(saleTestFixture.productIntactaSoy, saleTestFixture.templateIntactaByPlantabilityRRByExpirationBtFree, saleTestFixture.headOfficeCargil, 5l, SaleTestFixture.NOVEMBER, saleTestFixture.plantability45To54SoyMonsanto2012);
        sale.addItem(saleItemByPlantability);
        SaleItem saleItemByPlantability2 = saleItemFactory.createByExpirationDateItem(saleTestFixture.productRRSoy, saleTestFixture.templateIntactaByPlantabilityRRByExpirationBtFree, saleTestFixture.headOfficeCargil, 5l);
        sale.addItem(saleItemByPlantability2);
        saveAValidSaleForAParticipant(sale);

        UserDecorator loggedSuperUser = accessControlIntent.superUser;
        loggedSuperUser.setContextCrop(systemTestFixture.soy);

        BillingFilter billingFilter = BillingFilter.getInstance()
                .add(sale.getId())
                .add(loggedSuperUser);

        List<BillingDTO> billingDTOList = saleService.getBillingsOfSale(billingFilter).getDecoratedBillings();

        Assert.assertEquals("Correct number of billing", 2, billingDTOList.size());

        Date nowDate = new Date();
        Billing billing = billingDTOList.get(0).getBilling();
        billing.setBillingMethod(SaleTemplateBillingMethodEnum.ERP);
        saleService.payBilling(billing, nowDate, BigDecimal.ONE, true);

        RevenueAccount revenueAccount = new RevenueAccount(saleTestFixture.matrixCargil, "111", systemTestFixture.operationalYearOf2009, RevenueType.DISTRIBUTION, systemTestFixture.monsantoBr, new Date(), new Date());
        revenueAccount.setTotalRevenueBonus(BigDecimal.valueOf(100.22d));
        revenueAccount.setTotalRevenueMarketingFee(BigDecimal.valueOf(22.22d));
        revenueAccount.setTotalRevenueRetributionFee(BigDecimal.valueOf(432.1d));
        revenueAccount.setTotalRevenueValue(BigDecimal.valueOf(66.22d));
        revenueAccount.setStatus(RevenueStatus.BILLED);
        revenueAccount.setIsZNET(false);

        OrderItem orderItem = new OrderItem();
        revenueAccount.addItem(orderItem);
        orderItem.setAmount(new BigDecimal(100));
        orderItem.setBonusValue(BigDecimal.valueOf(100.55d));
        orderItem.setCode("1111");
        orderItem.setComissionValue(BigDecimal.valueOf(55.22d));
        orderItem.setDescription("12345");
        orderItem.setMarketingValue(BigDecimal.valueOf(1234.56d));
        orderItem.setValue(BigDecimal.valueOf(111.22d));

        RevenueHandle handle = new RevenueHandle(1L);
        revenueAccount.addHandle(handle);

        RevenueAdditionalCondition additionalCondition = new RevenueAdditionalCondition(BigDecimal.valueOf(10.5d), ConditionEnum.CREDIT_CONSUMPTION);
        revenueAccount.addAdditionalCondition(additionalCondition);

        Assert.assertEquals("Should have 1 item", 1, revenueAccount.getItems().size());
        saveAndFlush(revenueAccount);

        SaleItem saleItem = billing.getItems().iterator().next();
        saleItem.setRevenueAccount(revenueAccount);
        saveAndFlush(saleItem);

        SaleFilter saleFilter = SaleFilter.getInstance();
        saleFilter.add(loggedSuperUser);
        saleFilter.addCreationDateEnd(new Date());

        List<PaymentStatus> statusEq = new ArrayList<PaymentStatus>();
        statusEq.add(PaymentStatus.PARCIAL_PAID);
        statusEq.add(PaymentStatus.FULLY_PAID);
        saleFilter.addBillingStatusEqAndPayManual(statusEq);

        List<Sale> sales = saleService.getSaleBy(saleFilter);

        Assert.assertEquals("Correct number of sales", 1, sales.size());
    }

    @Test
    public void given_paid_billing_ERP_when_CancellationManualPayment_was_called_then_should_reversed_status() throws BusinessException {
        Sale sale = saleFactory.createSale(saleTestFixture.matrixCargil, saleTestFixture.chicoBento, SaleTypeEnum.SALE_SEED);
        sale.setState(systemTestFixture.matoGrossoDoSul);
        SaleItem saleItemByPlantability = saleItemFactory.createByPlantabilityDueDateRangeItem(saleTestFixture.productIntactaSoy, saleTestFixture.templateIntactaByPlantabilityRRByExpirationBtFree, saleTestFixture.headOfficeCargil, 5l, SaleTestFixture.NOVEMBER, saleTestFixture.plantability45To54SoyMonsanto2012);
        RetributionFee retributionFee = new RetributionFee();
        retributionFee.setMarketingProgramEnabled(true);
        retributionFee.setMarketingProgramSourceType(RetributionSourceType.ITS);
        retributionFee.setMarketingProgram(BigDecimal.TEN);
        retributionFee.setRetributionFeeEnabled(true);
        retributionFee.setRetributionFeeSourceType(RetributionSourceType.ITS);
        retributionFee.setRetributionFee(BigDecimal.TEN);
        saleItemByPlantability.getPriceOfTechnology().setRetributionFee(retributionFee);

        saleItemByPlantability.calculateRetributionFees(BigDecimal.ONE, new Date());
        Assert.assertFalse("Retribution fee should not be 0", saleItemByPlantability.getRetributionFeeValue().compareTo(BigDecimal.ZERO) == 0);
        Assert.assertFalse("Marketing fee should not be 0", saleItemByPlantability.getMarketingProgramValue().compareTo(BigDecimal.ZERO) == 0);
        sale.addItem(saleItemByPlantability);
        saveAValidSaleForAParticipant(sale);

        UserDecorator loggedSuperUser = accessControlIntent.superUser;
        loggedSuperUser.setContextCrop(systemTestFixture.soy);

        BillingFilter billingFilter = BillingFilter.getInstance()
                .add(sale.getId())
                .add(loggedSuperUser);

        List<BillingDTO> billingDTOList = saleService.getBillingsOfSale(billingFilter).getDecoratedBillings();

        Assert.assertEquals("Correct number of billing", 1, billingDTOList.size());

        Date nowDate = new Date();
        Billing billing = billingDTOList.get(0).getBilling();
        billing.setBillingMethod(SaleTemplateBillingMethodEnum.ERP);

        saleService.payBilling(billing, nowDate, new BigDecimal(3.5D), true);

        RevenueAccount revenueAccount = new RevenueAccount(saleTestFixture.matrixCargil, "111", systemTestFixture.operationalYearOf2009, RevenueType.DISTRIBUTION, systemTestFixture.monsantoBr, new Date(), new Date());
        revenueAccount.setTotalRevenueBonus(BigDecimal.valueOf(100.22d));
        revenueAccount.setTotalRevenueMarketingFee(BigDecimal.valueOf(22.22d));
        revenueAccount.setTotalRevenueRetributionFee(BigDecimal.valueOf(432.1d));
        revenueAccount.setTotalRevenueValue(BigDecimal.valueOf(66.22d));
        revenueAccount.setIsZNET(false);

        OrderItem orderItem = new OrderItem();
        revenueAccount.addItem(orderItem);
        orderItem.setAmount(new BigDecimal(100));
        orderItem.setBonusValue(BigDecimal.valueOf(100.55d));
        orderItem.setCode("1111");
        orderItem.setComissionValue(BigDecimal.valueOf(55.22d));
        orderItem.setDescription("12345");
        orderItem.setMarketingValue(BigDecimal.valueOf(1234.56d));
        orderItem.setValue(BigDecimal.valueOf(111.22d));

        RevenueHandle handle = new RevenueHandle(1L);
        revenueAccount.addHandle(handle);

        RevenueAdditionalCondition additionalCondition = new RevenueAdditionalCondition(BigDecimal.valueOf(10.5d), ConditionEnum.CREDIT_CONSUMPTION);
        revenueAccount.addAdditionalCondition(additionalCondition);

        Assert.assertEquals("Should have 1 item", 1, revenueAccount.getItems().size());
        saveAndFlush(revenueAccount);

        saleItemByPlantability.setRevenueAccount(revenueAccount);
        saveAndFlush(saleItemByPlantability);

        saleService.cancelPayment(billing);

        billing = (Billing) getSession().get(Billing.class, billing.getId());

        Assert.assertEquals("Expected billing payment status equals Billed", PaymentStatus.BILLED, billing.getPaymentStatus());
        Assert.assertFalse("Should have 1 saleItem", billing.getItems().size() == 0);
        for (SaleItem item : billing.getItems()) {
            Assert.assertFalse("Retribution fee should not be 0", item.getRetributionFeeValue().compareTo(BigDecimal.ZERO) == 0);
            Assert.assertFalse("Marketing fee should not be 0", item.getMarketingProgramValue().compareTo(BigDecimal.ZERO) == 0);
        }

        SaleFilter saleFilter = SaleFilter.getInstance();
        saleFilter.add(loggedSuperUser);
        saleFilter.addCreationDateEnd(new Date());

        List<PaymentStatus> statusEq = new ArrayList<PaymentStatus>();
        statusEq.add(PaymentStatus.PARCIAL_PAID);
        statusEq.add(PaymentStatus.FULLY_PAID);
        saleFilter.addBillingStatusEqAndPayManual(statusEq);

        List<Sale> sales = saleService.getSaleBy(saleFilter);

        Assert.assertEquals("Correct number of sales", 0, sales.size());
    }

    @Test
    public void when_customer_exist_getBySAPCode_number_should_return_a_customer()
            throws CustomerNotFoundException, CustomerNotAllowedException,
            DocumentMismatchException {
        accessControlIntent.superUser.setContextCompany(systemTestFixture.monsantoBr);
        accessControlIntent.superUser.setContextCrop(systemTestFixture.soy);

        Customer customerFound = saleService.getAllowedBy(SaleTestFixture.THE_CARGIL_CNPJ_WITHOUT_MASK, null, "00000085007465", ParticipantTypeEnum.DISTRIBUTOR, accessControlIntent.superUser);

        Assert.assertTrue("Customer was found", customerFound != null);
    }

    @Test
    public void test_get_allowed_distributor_by_with_state_registration()
            throws CustomerNotFoundException, CustomerNotAllowedException,
            DocumentMismatchException {
        accessControlIntent.superUser.setContextCompany(systemTestFixture.monsantoBr);
        accessControlIntent.superUser.setContextCrop(systemTestFixture.soy);

        Customer customerFound1 = saleService.getAllowedBy(SaleTestFixture.THE_CARGIL_CNPJ_WITHOUT_MASK, null, "00000085007465", ParticipantTypeEnum.DISTRIBUTOR, accessControlIntent.superUser);
        customerFound1.setStateRegistration("9999999999");
        saveAndFlush(customerFound1);

        Customer customerFound2 = saleService.getAllowedBy(SaleTestFixture.THE_CARGIL_CNPJ_WITHOUT_MASK, "9999999999", "00000085007465", ParticipantTypeEnum.DISTRIBUTOR, accessControlIntent.superUser);
        Assert.assertEquals(customerFound1.getId().longValue(), customerFound2.getId().longValue());
        Assert.assertEquals("9999999999", customerFound2.getStateRegistration());
    }

    @Test
    public void test_grower_required() {
        try {
            saleService.getCreditExtract(null, systemTestFixture.soy, systemTestFixture.monsantoBr);
            Assert.fail("Should return exception");
        } catch (ConstraintException e) {
            ConstraintViolation v = e.getViolations().get(0);
            Assert.assertEquals("Grower is required", v.getMessage());
        }
    }

    @Test
    public void test_company_required() {
        try {
            saleService.getCreditExtract(saleTestFixture.chicoBento, systemTestFixture.soy, null);
            Assert.fail("Should return exception");
        } catch (ConstraintException e) {
            ConstraintViolation v = e.getViolations().get(0);
            Assert.assertEquals("Company is required", v.getMessage());
        }
    }

    @Test
    public void testProfiledMethod() throws BusinessException {
        accessControlIntent.userAdminOfMonsantoBr.setContextCompany(systemTestFixture.monsantoBr);
        accessControlIntent.userAdminOfMonsantoBr.setContextCrop(systemTestFixture.soy);

        Sale sale = createSaleWithOneFixItemAndOneNoValueItem();

        saleService.save(sale, accessControlIntent.userAdminOfMonsantoBr);
        Assert.assertNotNull(sale.getItems().iterator().next().getTotalCreditValue());
    }

}
