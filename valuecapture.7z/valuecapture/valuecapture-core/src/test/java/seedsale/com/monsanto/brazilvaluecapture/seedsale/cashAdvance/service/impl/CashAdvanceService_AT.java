package com.monsanto.brazilvaluecapture.seedsale.cashAdvance.service.impl;

import com.monsanto.brazilvaluecapture.core.base.model.bean.Document;
import com.monsanto.brazilvaluecapture.core.base.model.bean.DocumentType;
import com.monsanto.brazilvaluecapture.core.base.model.bean.OperationalYear;
import com.monsanto.brazilvaluecapture.core.base.service.OperationalYearService;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Customer;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.ParticipantTypeEnum;
import com.monsanto.brazilvaluecapture.core.customer.service.CustomerService;
import com.monsanto.brazilvaluecapture.core.foundation.service.BusinessException;
import com.monsanto.brazilvaluecapture.core.foundation.test.AbstractServiceIntegrationTests;
import com.monsanto.brazilvaluecapture.seedsale.cashAdvance.model.bean.CashAdvanceBalanceByReferenceDate;
import com.monsanto.brazilvaluecapture.seedsale.cashAdvance.model.dto.CashAdvanceBalanceDTO;
import com.monsanto.brazilvaluecapture.seedsale.cashAdvance.service.CashAdvanceService;
import com.monsanto.brazilvaluecapture.seedsale.template.model.bean.Price;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

/**
 * Created by JMFURA on 24/07/2014.
 */
public class CashAdvanceService_AT extends AbstractServiceIntegrationTests {

    private static Price price = null;

    @Autowired
    private CashAdvanceService cashAdvanceService;

    @Autowired
    private CustomerService customerService;

    @Autowired
    private OperationalYearService operationalYearService;

    @Before
    public void init() throws BusinessException {
        initializePrice(4943L);
    }

    @Ignore
    @Test
    public void testGetAvailableBalanceForSale() {
        try {
            final Customer multiplier = customerService.getById(2627l);
            final Customer headOffice = customerService.getCustomerHeadOffice(multiplier, ParticipantTypeEnum.MULTIPLICADOR);
            final OperationalYear operationalYear = operationalYearService.selectExactOperationalYear(2014);

            List<CashAdvanceBalanceByReferenceDate> list = cashAdvanceService.getAllAvailableBalancesForPrice(price, multiplier, headOffice, operationalYear);
            System.out.println("ReturnedValues: " + list.size());

            for (CashAdvanceBalanceByReferenceDate advance : list) {
                System.out.println("Advance: " + advance.toString());
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void initializePrice(Long id) {
        price = new Price();
        price.setId(id);
    }

    private Customer createCustomer(String docType, String docNumber) {
        Customer customer = new Customer();
        customer.setDocument(new Document(new DocumentType(docType, null, null), docNumber));
        return customer;
    }

    private void print(String msg, boolean doIt) {
        if (doIt) {
            System.out.println(msg);
        }
    }


}
