package com.monsanto.brazilvaluecapture.seedsale.sale.service;

import com.monsanto.brazilvaluecapture.core.base.SystemTestFixture;
import com.monsanto.brazilvaluecapture.core.base.model.bean.City;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Crop;
import com.monsanto.brazilvaluecapture.core.foundation.service.BusinessException;
import com.monsanto.brazilvaluecapture.core.foundation.service.IndustrySystemOperationException;
import com.monsanto.brazilvaluecapture.core.foundation.test.AbstractServiceIntegrationTests;
import com.monsanto.brazilvaluecapture.core.foundation.util.security.EnvironmentSpecificPropertyReader;
import com.monsanto.brazilvaluecapture.core.regionalization.CountriesHolder;
import com.monsanto.brazilvaluecapture.core.user.AccessControlTestFixture;
import com.monsanto.brazilvaluecapture.core.user.model.bean.HierarchyLevel;
import com.monsanto.brazilvaluecapture.core.user.model.bean.ItsUser;
import com.monsanto.brazilvaluecapture.core.user.model.bean.UserDecorator;
import com.monsanto.brazilvaluecapture.core.user.service.UserService;
import com.monsanto.brazilvaluecapture.seedsale.billing.model.bean.Billing;
import com.monsanto.brazilvaluecapture.seedsale.billing.model.bean.PaymentStatus;
import com.monsanto.brazilvaluecapture.seedsale.billing.model.bean.PaymentStatusGroup.PaymentStatusAll;
import com.monsanto.brazilvaluecapture.seedsale.billing.model.dao.BillingFilter;
import com.monsanto.brazilvaluecapture.seedsale.billing.service.BillingConstraintViolationException;
import com.monsanto.brazilvaluecapture.seedsale.sale.SaleTestFixture;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.Sale;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.Sale.SaleTypeEnum;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.SaleItem;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.dao.AbstractSeedSaleReportFilter;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.dao.ReportSaleFilter;
import com.monsanto.brazilvaluecapture.seedsale.sale.report.SeedSaleReportDTO;
import com.monsanto.brazilvaluecapture.seedsale.template.model.bean.SaleTemplateBillingMethodEnum;
import junit.framework.Assert;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class ReportSale_AT extends AbstractServiceIntegrationTests {
	
	@Autowired
	private SaleService saleService;
	@Autowired
	private UserService userServices;

    @Autowired
    private CountriesHolder countriesHolder;

	private SaleItemFactory saleItemFactory;

    private SaleTestData saleTestData;

	@Before
	public void init() throws BusinessException {
		systemTestFixture = new SystemTestFixture(this);
		accessControlTestFixture = new AccessControlTestFixture(this, systemTestFixture);
		saleTestFixture = new SaleTestFixture(this, systemTestFixture);
		saleItemFactory = SaleItemFactory.getInstance(systemTestFixture.matoGrossoDoSul, saleTestFixture.plantabilitiesSelector);
		
		createChargeConsolidateTypes();

         //Added for LASVC to return a country brazil
         String configuredHost = "CONFIGURED_AND_REQUESTED_HOST_SAME";
		 EnvironmentSpecificPropertyReader env = mock(EnvironmentSpecificPropertyReader.class);
		 countriesHolder.setEnvironmentSpecificPropertyReader(env);
		 when(env.getEnvironmentSpecificProperty("host_name.argentina", null)).thenReturn("other");
		 when(env.getEnvironmentSpecificProperty("host_name.brazil", null)).thenReturn(configuredHost);
		 when(env.getEnvironmentSpecificProperty("host_name.paraguay", null)).thenReturn("another");

         countriesHolder.initialize();
         try{
            countriesHolder.resolveCountry(configuredHost);
         }catch(IllegalStateException ex)
         {

         }

        saleTestData = new SaleTestData(systemTestFixture.regionSaoPaulo2012);
	}
	
	@Test
	public void given_a_sale_when_an_adminUser_with_selected_company_see_sales_for_details_shouldReturn_sales_only_of_his_company() throws BusinessException {
		Sale sale = createSaleWithOneFixItemAndOneNoValueItem();
		saveAValidSaleForAParticipant(sale);
		
		AbstractSeedSaleReportFilter filter = ReportSaleFilter.getInstance(
				accessControlTestFixture.userAdminOfMonsantoBr,
				accessControlTestFixture.userAdminOfMonsantoBr
						.getContextCompany()).addCreationDateEnd(new Date());
		
		List<SeedSaleReportDTO> sales = saleService.getSalesBy(filter);
		
		Assert.assertEquals("Size of sales equals one", 1, sales.size());
	}
	
	@Test
	public void given_a_sale_when_an_participantUser_with_selected_company_see_sales_for_details_shouldReturn_sales_only_of_his_contract() throws BusinessException {
		Sale sale = createSaleWithOneFixItemAndOneNoValueItem();
		saveAValidSaleForAParticipant(sale);
		
		UserDecorator participant = getUserDecoratorBy(accessControlTestFixture.itsParticipantUser,systemTestFixture.soy);
		
		AbstractSeedSaleReportFilter filter = ReportSaleFilter.getInstance(participant,null).addCreationDateEnd(new Date());
		
		List<SeedSaleReportDTO> sales = saleService.getSalesBy(filter);
		
		Assert.assertEquals("Size of sales equals one", 1, sales.size());
	}
	
	@Test
	public void given_a_sale_when_an_adminUser_with_selected_hierarchy_grower_see_sales_for_details_shouldReturn_sales_only_of_hierarchy() throws BusinessException {
		Sale sale = createSaleWithOneFixItemAndOneNoValueItem();
		saveAValidSaleForAParticipant(sale);
		
		AbstractSeedSaleReportFilter filter = ReportSaleFilter.getInstance(accessControlTestFixture.userAdminOfMonsantoBr, accessControlTestFixture.userAdminOfMonsantoBr.getContextCompany()).addCreationDateEnd(new Date())
				.addHierarchyGrower(
						systemTestFixture.unity,
						systemTestFixture.region,
						systemTestFixture.districtVilaNova,
						systemTestFixture.commercialHierarchyMonsantoSoy
								.getCommercialHierType()
								.getCommercialHierTypeDesc());
		
		List<SeedSaleReportDTO> sales = saleService.getSalesBy(filter);
		
		Assert.assertEquals("Size of sales equals one", 1, sales.size());
	}
	
	@Test
	public void given_a_sale_when_an_adminUser_with_selected_grower_without_hierarchy_see_sales_for_details_shouldReturn_sales_only_of_hierarchy() throws BusinessException {
		
		City sp = new City("SAMPA", systemTestFixture.matoGrossoDoSul);
		saveAndFlush(sp);
		
		saleTestFixture.chicoBento.getBillingAddress().setCity(sp);
		saveAndFlush(saleTestFixture.chicoBento);
		
		Sale sale = createSaleWithOneFixItemAndOneNoValueItem();
		
		saveAValidSaleForAParticipant(sale);
		
		AbstractSeedSaleReportFilter filter = ReportSaleFilter
				.getInstance(accessControlTestFixture.userAdminOfMonsantoBr, accessControlTestFixture.userAdminOfMonsantoBr.getContextCompany())
				.addCreationDateEnd(new Date());
		
		List<SeedSaleReportDTO> sales = saleService.getSalesBy(filter);
		
		Assert.assertEquals("Size of sales equals one", 1, sales.size());
	}
		
	private PaymentStatusAll getPaymentStatusAllBy(Billing billing){
		PaymentStatusAll paymentStatus = null;
		
		switch (billing.getPaymentStatus()) {
		case BILLED:
			paymentStatus = PaymentStatusAll.BILLED;
			break;
		case CANCELLED:
			paymentStatus = PaymentStatusAll.CANCELLED;
			break;
		case FULLY_PAID:
			paymentStatus = PaymentStatusAll.FULLY_PAID;
			break;
		case PARCIAL_PAID:
			paymentStatus = PaymentStatusAll.PARCIAL_PAID;
			break;
		case NO_VALUE:
			paymentStatus = PaymentStatusAll.NO_VALUE;
			break;
		case NOT_PAID:
			if (billing.getBillingMethod().equals(SaleTemplateBillingMethodEnum.BANKSLIP)){
				paymentStatus = PaymentStatusAll.NOT_PAID;
			}else{
				paymentStatus = PaymentStatusAll.NOT_PAID_BILLING;
			}
			break;
		default:
			break;
		}
		return paymentStatus;
	}
	
	@Test
	public void given_a_sale_when_an_participantUser_has_one_contract_with_affiliate_search_sales_by_affiliates_shouldReturn_sale_of_his_contracts() throws BusinessException {
		
		accessControlTestFixture.itsParticipantUser.addProfile(accessControlTestFixture.profileWithOneAction);
		accessControlTestFixture.itsParticipantUser.addUserContract(saleTestFixture.contractCargil, saleTestFixture.affiliate, HierarchyLevel.AFFILIATE);
		saveAndFlush(accessControlTestFixture.itsParticipantUser);
		
		UserDecorator participantUser = getUserDecoratorBy(accessControlTestFixture.itsParticipantUser,systemTestFixture.soy);
		
		Sale sale = saleTestData.createSale(saleTestFixture.affiliate, saleTestFixture.chicoBento, SaleTypeEnum.SALE_SEED);
		sale.setState(systemTestFixture.matoGrossoDoSul);
		SaleItem saleItemByPlantability = saleItemFactory.createByPlantabilityDueDateRangeItem(saleTestFixture.productIntactaSoy, saleTestFixture.templateIntactaByPlantabilityRRByExpirationBtFree, saleTestFixture.headOfficeCargil, 5l, SaleTestFixture.NOVEMBER, saleTestFixture.plantability45To54SoyMonsanto2012);
		sale.addItem(saleItemByPlantability);
		
		saleService.save(sale, participantUser);
		
		PaymentStatusAll paymentStatus = getPaymentStatusAllBy(saleItemByPlantability.getBilling());
		List<PaymentStatusAll> statusList = new ArrayList<PaymentStatusAll>();
		statusList.add(paymentStatus);
		Calendar yesterday = Calendar.getInstance();
		yesterday.add(Calendar.DAY_OF_MONTH, -1);
		
		AbstractSeedSaleReportFilter filter = ReportSaleFilter.getInstance(participantUser, systemTestFixture.monsantoBr).addCreationDateEnd(new Date())
											.addBrand(saleTestFixture.productIntactaSoy.getBrand())
											.addState(systemTestFixture.matoGrossoDoSul)
											.addSaleTemplate(saleTestFixture.templateIntactaByPlantabilityRRByExpirationBtFree)
											.addHarvest(saleTestFixture.templateIntactaByPlantabilityRRByExpirationBtFree.getHarvest())
											.addTecnhology(saleTestFixture.productIntactaSoy.getTechnology())
											.addOperationalYear(saleTestFixture.templateIntactaByPlantabilityRRByExpirationBtFree.getHarvest().getOperationalYear())
											.addGrower(saleTestFixture.chicoBento)
											.addCustomer(saleTestFixture.affiliate)
											.addMatrix(saleTestFixture.headOfficeCargil.getMatrix())
											.addInvoiceNumber(sale.getInvoiceNumber())
											.addCreditStatus(saleItemByPlantability.getBilling().getCreditStatus())
											.addPaymentStatus(statusList)
											.addCreationDateStart(yesterday.getTime());
		
		List<SeedSaleReportDTO> sales = saleService.getSalesBy(filter);
		
		Assert.assertEquals("Size of sales equals one", 1, sales.size());
	}
	
	@Test
	public void given_a_sale_when_an_adminUser_with_selected_hierarchy_matrix_see_sales_for_details_shouldReturn_sales_only_of_hierarchy() throws BusinessException {
		Sale sale = createSaleWithOneFixItemAndOneNoValueItem();
		saveAValidSaleForAParticipant(sale);
		
		AbstractSeedSaleReportFilter filter = ReportSaleFilter.getInstance(accessControlTestFixture.userAdminOfMonsantoBr,accessControlTestFixture.userAdminOfMonsantoBr.getContextCompany()).addCreationDateEnd(new Date())
				.addHierarchyHeadoffice(
                        systemTestFixture.unity,
                        systemTestFixture.region,
                        systemTestFixture.districtCampinas,
                        systemTestFixture.commercialHierarchyMonsantoSoy
                                .getCommercialHierType()
                                .getCommercialHierTypeDesc());
		
		List<SeedSaleReportDTO> sales = saleService.getSalesBy(filter);
		
		Assert.assertEquals("Size of sales equals one", 1, sales.size());
	}
	
	@Test
	public void given_a_sale_when_an_adminUser_with_selected_hierarchy_partner_see_sales_for_details_shouldReturn_sales_only_of_hierarchy() throws BusinessException {
		Sale sale = createSaleWithOneFixItemAndOneNoValueItem();
		saveAValidSaleForAParticipant(sale);
		
		AbstractSeedSaleReportFilter filter = ReportSaleFilter
				.getInstance(accessControlTestFixture.userAdminOfMonsantoBr,
						accessControlTestFixture.userAdminOfMonsantoBr.getContextCompany())
				.addCreationDateEnd(new Date())
				.addHierarchyPartner(
						systemTestFixture.unity,
						systemTestFixture.region,
						systemTestFixture.districtCampinas,
						systemTestFixture.commercialHierarchyMonsantoSoy
								.getCommercialHierType()
								.getCommercialHierTypeDesc());
		
		List<SeedSaleReportDTO> sales = saleService.getSalesBy(filter);
		
		Assert.assertEquals("Size of sales equals one", 1, sales.size());
	}
	
	private UserDecorator getUserDecoratorBy (ItsUser user, Crop crop) throws BusinessException{
		UserDecorator userDecorator = userServices.getAuthenticatedUserBy(user.getLogin());
		userDecorator.setContextCrop(crop);
		return userDecorator;
	}
	
	private Sale saveAValidSaleForAParticipant(Sale sale) throws BusinessException {
		accessControlTestFixture.itsParticipantUser.addProfile(accessControlTestFixture.profileWithOneAction);
		accessControlTestFixture.itsParticipantUser.addUserContract(saleTestFixture.contractCargil, saleTestFixture.matrixCargil, HierarchyLevel.HEAD_OFFICE);
		saveAndFlush(accessControlTestFixture.itsParticipantUser);
		
		UserDecorator participantUser = getUserDecoratorBy(accessControlTestFixture.itsParticipantUser,systemTestFixture.soy);
		
		saleService.save(sale, participantUser);
		return sale;
	}
	
	private Sale createSaleWithOneFixItemAndOneNoValueItem() throws BusinessException {
		Sale sale = saleTestData.createSale(saleTestFixture.matrixCargil, saleTestFixture.chicoBento, SaleTypeEnum.SALE_SEED);
		sale.setState(systemTestFixture.matoGrossoDoSul);
		
		sale.addItem(saleItemFactory.createFixValueItem(saleTestFixture.productIntactaSoy, saleTestFixture.templateIntactaFixRRRangeBtNoValue, saleTestFixture.headOfficeCargil, 5l));
		//sale.addItem(saleItemFactory.createNoValueItem(saleTestFixture.productBtSoy, saleTestFixture.templateIntactaFixRRRangeBtNoValue, saleTestFixture.headOfficeCargil, 5l));
		return sale;
	}
	
	private Sale createSaleWithOneFixItem() throws BusinessException {
		Sale sale = saleTestData.createSale(saleTestFixture.matrixCargil, saleTestFixture.chicoBento, SaleTypeEnum.SALE_SEED);
		sale.setState(systemTestFixture.matoGrossoDoSul);
		
		sale.addItem(saleItemFactory.createFixValueItem(saleTestFixture.productIntactaSoy, saleTestFixture.templateIntactaFixRRRangeBtNoValue, saleTestFixture.headOfficeCargil, 5l));
		return sale;
	}
	
	
	
	private void payBillingOf(Sale sale, BigDecimal value) throws BillingConstraintViolationException, IndustrySystemOperationException {
		BillingFilter billingFilter = new BillingFilter(); 
		billingFilter.add(sale.getId()).add(PaymentStatus.NOT_PAID);
		List<Billing> billins  = saleService.getBillingBy(billingFilter);
		
		for (Billing billing : billins) {
		        try {
			    saleService.payBilling(billing, SaleTestFixture.DATE_NOW, value, true);
			} catch (BusinessException e) {
                            e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
                        }

		}
	}	
	
	private void cancelBillingOf(Sale sale) throws BillingCancellationWarningException, IndustrySystemOperationException {
		saleService.cancelBillingPartially(sale.getId(), sale.getCompanies().iterator().next(), saleTestFixture.saleCancellation, "remendes");
	}
	

	@Test
	public void given_paidBillingForSale_when_searchBy_paymentStatus_should_return_paid_sale() throws BusinessException {
		Sale sale = createSaleWithOneFixItemAndOneNoValueItem();
		saveAValidSaleForAParticipant(sale);
		payBillingOf(sale, BigDecimal.ONE);
		UserDecorator participant = getUserDecoratorBy(accessControlTestFixture.itsParticipantUser,systemTestFixture.soy);

		List<PaymentStatusAll> statusList = new ArrayList<PaymentStatusAll>();
		statusList.add(PaymentStatusAll.FULLY_PAID);
		statusList.add(PaymentStatusAll.PARCIAL_PAID);
		
		ReportSaleFilter reportSaleFilter = ReportSaleFilter.getInstance(participant, null);
		reportSaleFilter.addPaymentStatus(statusList).addCreationDateStart(SaleTestFixture.DATE_NOW);
		
		List<SeedSaleReportDTO> sales = saleService.getSalesBy(reportSaleFilter);
		Assert.assertEquals("Should have at least one paid sale", 1, sales.size());
	}
	
	@Test
	public void given_paidBillingForSale_when_searchBy_paymentDate_should_return_the_paid_sale() throws BusinessException {
		Sale sale = createSaleWithOneFixItemAndOneNoValueItem();
		saveAValidSaleForAParticipant(sale);
		payBillingOf(sale, BigDecimal.ONE);
		UserDecorator participant = getUserDecoratorBy(accessControlTestFixture.itsParticipantUser,systemTestFixture.soy);
		
		ReportSaleFilter reportSaleFilter = ReportSaleFilter.getInstance(participant, null);
		reportSaleFilter.addCreationDateStart(SaleTestFixture.DATE_NOW).addPaymentPeriod(SaleTestFixture.DATE_NOW,SaleTestFixture.DATE_NOW);
		
		List<SeedSaleReportDTO> sales = saleService.getSalesBy(reportSaleFilter);
		Assert.assertEquals("Should have at least one paid sale", 1, sales.size());
	}
	
	@Test
	public void given_reportSaleFilter_when_filters_are_null_should_return_no_sale() throws BusinessException {
		UserDecorator superUser = getUserDecoratorBy(accessControlTestFixture.itsSuperUser,systemTestFixture.soy);
		ReportSaleFilter reportSaleFilter = ReportSaleFilter.getInstance(superUser, systemTestFixture.monsantoBr);
		reportSaleFilter.addBrand(null).addCreditStatus(null).addCustomer(null).addGrower(null).addHarvest(null).addHierarchyGrower(null, null, null, null)
			.addHierarchyHeadoffice(null, null, null, null).addHierarchyPartner(null, null, null, null).addInvoiceNumber(null).addMatrix(null)
			.addOperationalYear(null).addPaymentPeriod(null,null).addPaymentStatus(null).addSaleTemplate(null).addState(null)
			.addTecnhology(null).addCreationDateStart(null).addCreationDateEnd(SaleTestFixture.DATE_NOW);
		
		List<SeedSaleReportDTO> sales = saleService.getSalesBy(reportSaleFilter);
		Assert.assertEquals("Should have no sales", 0, sales.size());
	}

	@Test
    @Ignore
	public void given_cancelledBillingForSale_when_searchBy_paymentStatusCancelled_and_creationDate_should_return_cancelled_sale() throws BusinessException {
		Sale sale = createSaleWithOneFixItem();
		saveAValidSaleForAParticipant(sale);
		cancelBillingOf(sale);
		
		UserDecorator participant = getUserDecoratorBy(accessControlTestFixture.itsParticipantUser,systemTestFixture.soy);

		List<PaymentStatusAll> statusList = new ArrayList<PaymentStatusAll>();
		statusList.add(PaymentStatusAll.CANCELLED);
		
		ReportSaleFilter reportSaleFilter = ReportSaleFilter.getInstance(participant, null);
		reportSaleFilter.addPaymentStatus(statusList)
		.addCreationDateStart(SaleTestFixture.DATE_NOW)
		.addCreationDateEnd(SaleTestFixture.DATE_NOW);
		
		List<SeedSaleReportDTO> sales = saleService.getSalesBy(reportSaleFilter);
		Assert.assertEquals("Should have at least one cancelled sale", 1, sales.size());
	}

	@Test
    @Ignore
	public void given_cancelledBillingForSale_when_searchBy_paymentStatusCancelled_and_paymentDate_should_return_no_sale() throws BusinessException {
		Sale sale = createSaleWithOneFixItem();
		saveAValidSaleForAParticipant(sale);
		cancelBillingOf(sale);
		
		UserDecorator participant = getUserDecoratorBy(accessControlTestFixture.itsParticipantUser,systemTestFixture.soy);

		List<PaymentStatusAll> statusList = new ArrayList<PaymentStatusAll>();
		statusList.add(PaymentStatusAll.CANCELLED);
		
		ReportSaleFilter reportSaleFilter = ReportSaleFilter.getInstance(participant, null);
		reportSaleFilter
		.addPaymentStatus(statusList)
		.addPaymentPeriod(SaleTestFixture.DATE_NOW,SaleTestFixture.DATE_NOW);
		
		List<SeedSaleReportDTO> sales = saleService.getSalesBy(reportSaleFilter);
		Assert.assertEquals("Should have no sales", 0, sales.size());
	}
}
