package com.monsanto.brazilvaluecapture.seedsale.tons.model.dao.impl;

import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import org.hibernate.SQLQuery;
import org.hibernate.SessionFactory;
import org.hibernate.classic.Session;
import org.hibernate.transform.ResultTransformer;
import org.hibernate.type.NullableType;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

import com.monsanto.brazilvaluecapture.seedsale.harvest.model.bean.Harvest;
import com.monsanto.brazilvaluecapture.seedsale.tons.model.dao.TonsDAO;

public class TonsDAOImpl_UT {

	private Session session;
	private TonsDAO tonsDAO;
	private SQLQuery sqlQuery;

	@Before
	public void setUp() throws Exception {
		SessionFactory sessionFactory = mock(SessionFactory.class);
		this.session = mock(Session.class);
		when(sessionFactory.getCurrentSession()).thenReturn(this.session);
		this.tonsDAO = new TonsDAOImpl(sessionFactory);
		this.sqlQuery = mock(SQLQuery.class);
		when(this.session.createSQLQuery(Mockito.anyString())).thenReturn(
				sqlQuery);
	}

	@Test
	public void testGetTonsLeakBalance() {
		when(this.sqlQuery.addScalar(anyString(), any(NullableType.class)))
				.thenReturn(this.sqlQuery);
		when(this.sqlQuery.setResultTransformer(any(ResultTransformer.class)))
				.thenReturn(this.sqlQuery);
		this.tonsDAO.getTonsLeakBalance(new Harvest(), "20202011369");
		verify(this.sqlQuery, times(1)).list();
	}

}
