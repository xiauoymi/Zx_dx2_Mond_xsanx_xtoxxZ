package com.monsanto.brazilvaluecapture.seedsale.sale.model.bean;

import org.junit.Test;

import java.math.BigDecimal;

import static org.fest.assertions.Assertions.assertThat;

public class SaleItem_UT {

    @Test
    public void testAddRevenueRecognitionAddsRevenueRecognition_WhenInitialValueIsNull() {
        SaleItem saleItem = new SaleItem();
        saleItem.setRevenueRecognition(null);

        saleItem.addRevenueRecognition(BigDecimal.TEN);

        assertThat(saleItem.getRevenueRecognition()).isEqualTo(BigDecimal.TEN);
    }

    @Test
    public void testAddRevenueRecognitionAddsRevenueRecognition_WhenInitialValueIs10() {
        SaleItem saleItem = new SaleItem();
        saleItem.setRevenueRecognition(BigDecimal.TEN);

        saleItem.addRevenueRecognition(BigDecimal.TEN);

        assertThat(saleItem.getRevenueRecognition()).isEqualTo(BigDecimal.valueOf(20));
    }
}