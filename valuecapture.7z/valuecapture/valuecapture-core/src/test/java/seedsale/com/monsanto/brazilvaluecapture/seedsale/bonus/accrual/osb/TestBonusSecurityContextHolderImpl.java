package com.monsanto.brazilvaluecapture.seedsale.bonus.accrual.osb;

import com.monsanto.brazilvaluecapture.osb.util.SecurityContextBadCredentialException;
import com.monsanto.brazilvaluecapture.osb.util.SecurityContextHolder;

public class TestBonusSecurityContextHolderImpl implements SecurityContextHolder {

	private static final String OSB_PROPERTIES = "com/monsanto/brazilvaluecapture/osb/util/OSB";
    protected static final String USERNAME_KEY = "sap.osb.user";
   // public static final String USERNAME = "APPQUASVC-BRAZIL_VC";
    public static final String USERNAME = "NA1000SVC-Brazil_VC";
    public static final String PASSWORD = "VoNAajFHJNtn2_A";
    private String username;
    private String password;

	public TestBonusSecurityContextHolderImpl() throws SecurityContextBadCredentialException {
			this.username = USERNAME;
			this.password = PASSWORD;
	}

	private String getPasswordFromProperty() throws SecurityContextBadCredentialException {
	    return password;
		
	}
	
	@Override
    public String getUserName()   {
        
		return this.username;
    }
	
	@Override
    public String getPassword() {
		
		return this.password;
    }


}
