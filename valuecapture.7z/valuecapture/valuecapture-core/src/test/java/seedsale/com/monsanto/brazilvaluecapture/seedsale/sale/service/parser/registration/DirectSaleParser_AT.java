package com.monsanto.brazilvaluecapture.seedsale.sale.service.parser.registration;

import com.monsanto.brazilvaluecapture.core.base.SystemTestFixture;
import com.monsanto.brazilvaluecapture.core.foundation.test.AbstractServiceIntegrationTests;
import com.monsanto.brazilvaluecapture.core.foundation.util.ErrorCode;
import com.monsanto.brazilvaluecapture.core.foundation.util.csv.CSVParserReader.CSV_ERROS;
import com.monsanto.brazilvaluecapture.core.foundation.util.csv.CSVReadableInvalidException;
import com.monsanto.brazilvaluecapture.core.user.AccessControlTestFixture;
import com.monsanto.brazilvaluecapture.seedsale.sale.SaleTestFixture;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.CsvSale;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.Sale.SaleTypeEnum;
import com.monsanto.brazilvaluecapture.seedsale.sale.service.SaleService;
import com.monsanto.brazilvaluecapture.seedsale.sale.service.parser.DirectSaleTestFixture;
import com.monsanto.brazilvaluecapture.seedsale.template.model.bean.DueDateValue;
import com.monsanto.brazilvaluecapture.seedsale.template.model.bean.Price;
import com.monsanto.brazilvaluecapture.seedsale.template.model.bean.Price.PriceTypeEnum;
import com.monsanto.brazilvaluecapture.seedsale.template.service.DueDateCanNotBeEqualsAnotherException;
import com.monsanto.brazilvaluecapture.seedsale.template.service.DueDateCanNotBeMoreThanTwoException;
import junit.framework.Assert;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.junit.After;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.ResourceBundle;

@Ignore("Ignore for now, until we finish refactor of async")
public class DirectSaleParser_AT extends AbstractServiceIntegrationTests{

	private static final int ONE_HUNDRED_ROWS = 1;

	private static final int NINETY_NINE = ONE_HUNDRED_ROWS-1;

    protected Logger logger = LogManager.getLogger(this.getClass());
	
	@Autowired
	private SaleService saleService;
	
	private DirectSaleParser parser;
	
	private ResourceBundle resourceBundle = ResourceBundle.getBundle("bundle/bundle");
	
	@Before
	public void setup() {
		systemTestFixture = new SystemTestFixture(this);
		saleTestFixture = new SaleTestFixture(this, systemTestFixture);
		directSaleTestFixture = new DirectSaleTestFixture(this);
		accessControlTestFixture = new AccessControlTestFixture(this, systemTestFixture);
		accessControlTestFixture.superUser.setContextCompany(systemTestFixture.monsantoBr);
		accessControlTestFixture.superUser.setContextCrop(systemTestFixture.soy);
	}
	
	@After
	public void tearDown() {
		logger.info(parser.getResultAsString(resourceBundle));
	}
	
	@Test
	public void given_import_data_avaiable_should_have_import_with_success() throws CSVReadableInvalidException, DueDateCanNotBeMoreThanTwoException, DueDateCanNotBeEqualsAnotherException{
		
		saleTestFixture.templateIntactaFixRRRangeBtNoValue.setSaleType(SaleTypeEnum.DIRECT_SALE);
		
		for (Price price : saleTestFixture.templateIntactaFixRRRangeBtNoValue.getPrices()) {
			if(!price.getType().equals(PriceTypeEnum.NO_VALUE)){
				price.getDueDates().clear();
				price.addDueDate(new DueDateValue(SaleTestFixture.AUGUST));		
			}		
		}
		
		
		saveAndFlush(saleTestFixture.templateIntactaFixRRRangeBtNoValue);
		
	    directSaleTestFixture.createImportationDataSuccess(saleTestFixture, systemTestFixture, ONE_HUNDRED_ROWS);
		parser = new DirectSaleParser(accessControlTestFixture.superUser, saleService);
		parser.readFile();
		parser.process();
		int actualRowsOfQueue = getSession().createCriteria(CsvSale.class).list().size();
		Assert.assertEquals("Should return 100 sales successfully",ONE_HUNDRED_ROWS,parser.getSuccessLines() );
		Assert.assertEquals("Should remove all row from queue in DB", 0, actualRowsOfQueue);
	}
	
	@Test
	public void given_import_no_data_avaiable_should_have_import_with_success() throws CSVReadableInvalidException{
		parser = new DirectSaleParser(accessControlTestFixture.superUser, saleService);
		parser.readFile();
		parser.process();
		int actualRowsOfQueue = getSession().createCriteria(CsvSale.class).list().size();
		Assert.assertEquals("Shoul return warn empty rows",1,parser.countOccurrenceOfError(CSV_ERROS.ERROR_EMPTY_FILE, true));
		Assert.assertEquals("Should remove all row from queue in DB", 0, actualRowsOfQueue);
	}
	
	@Test
	public void given_import_data_avaiable_with_erros_should_have_imported_erros() throws CSVReadableInvalidException{
		directSaleTestFixture.createImportationDataWithErrosOfDuplicationProducts(saleTestFixture, systemTestFixture, ONE_HUNDRED_ROWS);
		parser = new DirectSaleParser(accessControlTestFixture.superUser, saleService);
		parser.readFile();
		parser.process();
		int actualRowsOfQueue = getSession().createCriteria(CsvSale.class).list().size();
		Assert.assertEquals("Should return sale with erros ",1,parser.getErrorLines());
		Assert.assertEquals("Should return sales items with erros of duplicity",NINETY_NINE,parser.countOccurrenceOfError(ErrorCode.DUPLICITY_VALUE, true));
		Assert.assertEquals("Should not remove row from queue in DB", ONE_HUNDRED_ROWS, actualRowsOfQueue);
	}
}
