package com.monsanto.brazilvaluecapture.seedsale.product;

import junit.framework.Assert;

import org.junit.Before;
import org.junit.Test;

import com.monsanto.brazilvaluecapture.core.base.CompanyTestData;
import com.monsanto.brazilvaluecapture.core.base.CountryTestData;
import com.monsanto.brazilvaluecapture.core.base.CropTestData;
import com.monsanto.brazilvaluecapture.core.base.TechnologyTestData;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Company;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Country;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Crop;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Technology;
import com.monsanto.brazilvaluecapture.core.foundation.model.bean.StatusEnum;
import com.monsanto.brazilvaluecapture.seedsale.harvest.model.bean.Harvest;
import com.monsanto.brazilvaluecapture.seedsale.product.model.bean.Brand;
import com.monsanto.brazilvaluecapture.seedsale.product.model.bean.Product;
import com.monsanto.brazilvaluecapture.seedsale.product.model.dao.ProductFilter;
import com.monsanto.brazilvaluecapture.seedsale.template.SaleTemplateTestData;
import com.monsanto.brazilvaluecapture.seedsale.template.model.bean.SaleTemplate;

public class ProductFilter_UT {

	private Company company;
	private Crop crop;
	private Technology tech;
	private Brand brand;

	@Before
	public void setup() {
		Country country = CountryTestData.createBrazil();
		company = CompanyTestData.createCompany(country);
		company.setId(10l);
		crop = CropTestData.createCrop(company, country);
		crop.setId(20l);
		tech = TechnologyTestData.createTechnology(company);
		tech.setId(30l);
		brand = BrandTestData.createBrand(company);
		brand.setId(40l);
	}
	
	@Test
	public void when_addThreeDiferentCriterias_productFilter_shouldHaveThreeCriterias() {
		ProductFilter filter = ProductFilter.getInstance().add(crop).add(company).add(tech);
		
		Assert.assertEquals("Should have 3 criterias", 3, filter.countCriterias());
	}

	@Test
	public void when_addNullProductCriteria_productFilter_shouldHaveNoCriterias() {
		Product product = null;
		ProductFilter filter = ProductFilter.getInstance().add(product);
		
		Assert.assertEquals("Should have no criterias", 0, filter.countCriterias());
	}

	@Test
	public void when_addProductCriteria_productFilter_shouldHaveTwoCriterias() {
		Product product = ProductTestData.createProduct(brand, crop, tech, StatusEnum.ACTIVE, company);
		product.setId(1l);
		ProductFilter filter = ProductFilter.getInstance().add(product);
		
		Assert.assertEquals("Should have two criterias", 2, filter.countCriterias());
	}

	@Test
	public void when_addProductDescriptionAndSaleTemplateCriteria_productFilter_shouldHaveTwoCriterias() {
		Product product = ProductTestData.createProduct(brand, crop, tech, StatusEnum.ACTIVE, company);
		product.setId(1l);
		SaleTemplate saleTemplate = SaleTemplateTestData.createSaleTemplateTypeSeedSale(new Harvest());
		saleTemplate.setId(2l);
		ProductFilter filter = ProductFilter.getInstance().add(product);
		
		Assert.assertEquals("Should have two criterias", 2, filter.countCriterias());
	}

}
