package com.monsanto.brazilvaluecapture.seedsale.sale.service;

import com.monsanto.brazilvaluecapture.core.base.model.bean.Company;
import com.monsanto.brazilvaluecapture.core.base.model.bean.State;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Customer;
import com.monsanto.brazilvaluecapture.core.foundation.RandomTestData;
import com.monsanto.brazilvaluecapture.core.foundation.service.IllegalDateArgumentException;
import com.monsanto.brazilvaluecapture.core.user.model.bean.ItsUser;
import com.monsanto.brazilvaluecapture.core.user.model.bean.ItsUser.UserTypeEnum;
import com.monsanto.brazilvaluecapture.core.user.model.bean.UserContext;
import com.monsanto.brazilvaluecapture.core.user.model.bean.UserDecorator;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.dao.SaleFilter;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.util.Date;

/**
 * @author andregc
 */
public class SaleFilter_UT {
    private SaleFilter saleFilter = null;

    @Before
    public void setup() {
        saleFilter = SaleFilter.getInstance();
    }

    @Test
    public void when_i_dont_add_any_criteria_saleFilter_shouldHaveNoCriterias() {
        Assert.assertEquals("Should have no criteria", 0, saleFilter.countCriterias());
    }

    @Test
    public void when_i_addUserCriteria_admin_saleFilter_shouldHaveTwoCriteria() {
        ItsUser loggedUser = new ItsUser("login", UserTypeEnum.ADMINISTRATOR);
        UserContext user = new UserDecorator(null, loggedUser);
        user.setContextCompany(new Company());

        saleFilter.add(user);

        Assert.assertEquals("Should have two criteria", 2, saleFilter.countCriterias());
    }

    @Test
    public void when_i_addUserCriteria_super_saleFilter_shouldHaveOneCriteria() {
        ItsUser loggedUser = new ItsUser("login", UserTypeEnum.SUPER);
        UserContext user = new UserDecorator(null, loggedUser);

        saleFilter.add(user);

        Assert.assertEquals("Should have one criteria", 1, saleFilter.countCriterias());
    }

    @Test
    public void when_i_addCreationDateStart_and_addCreationDateEnd_saleFilter_shouldHave2Criterias() {
        saleFilter.addCreationDateStart(new Date());
        saleFilter.addCreationDateEnd(new Date());

        Assert.assertEquals("Should have two criterias", 2, saleFilter.countCriterias());
    }

    @Test
    public void when_i_addMatrix_saleFilter_shouldHave1Criterias() {
        saleFilter.addMatrix(new Customer());

        Assert.assertEquals("Should have two criterias", 1, saleFilter.countCriterias());
    }

    @Test
    public void when_i_add_invoiceNumber_and_customerDocument_and_growerDocument_saleFilter_shouldHave3Criterias() {
        saleFilter.addInvoiceNumber(RandomTestData.createRandomString(5));
        saleFilter.addCustomerDocument(RandomTestData.createRandomString(5));
        saleFilter.addGrowerDocument(RandomTestData.createRandomString(5));

        Assert.assertEquals("Should have three criterias", 3, saleFilter.countCriterias());
    }

    @Test
    public void when_i_add_state_saleFilter_shouldHave1Criteria() {
        saleFilter.add(new State());

        Assert.assertEquals("Should have one criterias", 1, saleFilter.countCriterias());
    }

    @Test
    public void saleFilterExcludePostedSale_ShouldHave1Criteria() {
        saleFilter.excludePostedSales();

        Assert.assertEquals("Should have one criterias", 1, saleFilter.countCriterias());
    }

    @Test(expected = IllegalDateArgumentException.class)
    public void saleFilter_should_have_start_or_end_creationDate() {
        saleFilter.buildCriteria(null);

        Assert.fail("SaleFilter should throw IllegalDateArgumentException");
    }
}
