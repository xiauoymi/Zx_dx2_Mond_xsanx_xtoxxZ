package com.monsanto.brazilvaluecapture.seedsale.mixed.service;

import com.monsanto.brazilvaluecapture.core.base.model.bean.Company;
import com.monsanto.brazilvaluecapture.core.base.model.dao.CompanyDAO;
import com.monsanto.brazilvaluecapture.core.base.model.dao.TechnologyDAO;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Customer;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Technology;
import com.monsanto.brazilvaluecapture.core.customer.model.dao.CustomerDAO;
import com.monsanto.brazilvaluecapture.core.foundation.test.AbstractServiceIntegrationTests;
import com.monsanto.brazilvaluecapture.core.foundation.test.dbunit.DbUnitHelper;
import com.monsanto.brazilvaluecapture.core.grower.model.bean.Grower;
import com.monsanto.brazilvaluecapture.core.grower.model.dao.GrowerDAO;
import com.monsanto.brazilvaluecapture.seedsale.harvest.model.bean.Harvest;
import com.monsanto.brazilvaluecapture.seedsale.harvest.model.dao.HarvestDAO;
import com.monsanto.brazilvaluecapture.seedsale.mixed.model.bean.InvoiceDetailPY;
import com.monsanto.brazilvaluecapture.seedsale.mixed.model.bean.InvoiceHeaderPY;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import java.util.Calendar;
import java.util.List;

public class InvoiceHeaderPYService_AT extends AbstractServiceIntegrationTests {

    @Autowired
    private InvoiceHeaderPYService invoiceHeaderPYService;

    @Autowired
    private GrowerDAO growerDAO;
    @Autowired
    private HarvestDAO harvestDAO;
    @Autowired
    private TechnologyDAO technologyDAO;
    @Autowired
    private CompanyDAO companyDAO;
    @Autowired
    private CustomerDAO customerDAO;

    private Grower grower;
    private Harvest harvest;
    private Company company;
    private Technology technology;
    private Customer customerWithSeedSaleRegistration;
    private Customer customerWithoutSeedSaleRegistration;

    @Before
	public void setup() throws Exception {
		DbUnitHelper.setup("classpath:data/seedsale/mixed/mixed-quota-dataset.xml");
        grower = growerDAO.selectBy(900000002L);
        harvest = harvestDAO.selectById(900000001L);
        company = companyDAO.selectById(900000001L);
        technology = technologyDAO.findTechnologyByCandidateKey("INTACTA", company);
        customerWithSeedSaleRegistration = customerDAO.selectBy("20234567129", "AR");
        customerWithoutSeedSaleRegistration = customerDAO.selectBy("20234567130", "AR");
    }

    private InvoiceHeaderPY createInvoiceHeader() {
        InvoiceHeaderPY invoiceHeader = new InvoiceHeaderPY();
        invoiceHeader.setCustomer(customerWithoutSeedSaleRegistration);
        invoiceHeader.setGrower(grower);
        invoiceHeader.setHarvest(harvest);
        invoiceHeader.setTechnology(technology);
        invoiceHeader.setInvoiceDate(Calendar.getInstance().getTime());
        invoiceHeader.setInvoiceNumber("1111");
        invoiceHeader.setTonsAmount(44L);
        invoiceHeader.addDetail(createInvoiceDetail("1", 5L));
        invoiceHeader.addDetail(createInvoiceDetail("2", 9L));
        return invoiceHeader;
    }

    private InvoiceDetailPY createInvoiceDetail(String batchNumber, Long numberOfBags) {
        InvoiceDetailPY invoiceDetail = new InvoiceDetailPY();
        invoiceDetail.setBatchNumber(batchNumber);
        invoiceDetail.setNumberOfBags(numberOfBags);
        invoiceDetail.setOrigin("ORIGIN_TEST");
        invoiceDetail.setVariety("VARIETY_TEST");
        return invoiceDetail;
    }

    @Test
	public void testSeedSaleRegistration() {
        InvoiceHeaderPY invoiceHeader = createInvoiceHeader();
        invoiceHeaderPYService.save(invoiceHeader);
        Assert.assertNotNull(invoiceHeader.getId());
        Assert.assertNotNull(invoiceHeader.getDetails());
        Assert.assertTrue(invoiceHeader.getDetails().size()>0);
        Assert.assertNotNull(invoiceHeader.getDetails().iterator().next().getId());
    }

    @Test
	public void testFindInvoicesByHarvestAndCustomerAndTechnology() {
        List<InvoiceHeaderPY> invoiceHeaders = invoiceHeaderPYService.findBy(harvest, technology, customerWithSeedSaleRegistration);
        Assert.assertNotNull(invoiceHeaders);
        Assert.assertEquals(invoiceHeaders.size(), 1);
    }

    @Test
	public void testFindInvoicesByHarvestAndCustomerAndTechnology_Empty_Results() {
        List<InvoiceHeaderPY> invoiceHeaders = invoiceHeaderPYService.findBy(harvest, technology, customerWithoutSeedSaleRegistration);
        Assert.assertNotNull(invoiceHeaders);
        Assert.assertEquals(invoiceHeaders.size(), 0);
    }

}
