package com.monsanto.brazilvaluecapture.seedsale.sale.model.dao.impl;

import com.monsanto.brazilvaluecapture.pod.rol.model.bean.VolumeOfBag;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.dao.VolumeOfBagDAO;
import junit.framework.Assert;
import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class VolumeOfBagDAOImpl_UT {

    private VolumeOfBagDAOImpl volumeOfBagDAO;

    @Before
    public void setUp(){
        this.volumeOfBagDAO = mock(VolumeOfBagDAOImpl.class);
        when(this.volumeOfBagDAO.getAll()).thenReturn(new ArrayList<VolumeOfBag>());
    }

    @Test
    public void testGetAllVolumeOfBag(){
        Assert.assertNotNull(this.volumeOfBagDAO.getAll());
    }
}
