package com.monsanto.brazilvaluecapture.seedsale;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

import com.monsanto.brazilvaluecapture.seedsale.billing.SuiteBilling;
import com.monsanto.brazilvaluecapture.seedsale.extract.DetailCredit_AT;
import com.monsanto.brazilvaluecapture.seedsale.harvest.SuiteHarvest;
import com.monsanto.brazilvaluecapture.seedsale.product.SuiteProduct;
import com.monsanto.brazilvaluecapture.seedsale.quota.SuiteQuota;
import com.monsanto.brazilvaluecapture.seedsale.revenue.service.RevenueManager_AT;
import com.monsanto.brazilvaluecapture.seedsale.sale.SuiteSale;


@RunWith(value = Suite.class)
@SuiteClasses(value = { 
		SuiteBilling.class,
		SuiteSale.class,
		SuiteProduct.class,
		SuiteHarvest.class,
		SuiteQuota.class,
		DetailCredit_AT.class, 
		RevenueManager_AT.class})
public class SuiteSeedSale {

}
