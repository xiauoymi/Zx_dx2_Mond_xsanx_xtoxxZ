package com.monsanto.brazilvaluecapture.seedsale.billing.model.dao.impl;

import com.google.common.collect.Lists;
import com.monsanto.brazilvaluecapture.core.foundation.service.EntityNotFoundException;
import com.monsanto.brazilvaluecapture.core.revenue.model.bean.RevenueAccount;
import com.monsanto.brazilvaluecapture.core.wsiconsole.dao.impl.BaseHibernateUnitTest;
import com.monsanto.brazilvaluecapture.seedsale.billing.model.bean.Billing;
import com.monsanto.brazilvaluecapture.seedsale.billing.model.bean.PaymentStatus;
import com.monsanto.brazilvaluecapture.seedsale.billing.model.dao.BillingDAO;
import com.monsanto.brazilvaluecapture.seedsale.billing.model.dao.BillingFilter;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.Sale;
import org.hibernate.Criteria;
import org.hibernate.criterion.SimpleExpression;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

import static org.fest.assertions.Assertions.assertThat;
import static org.fest.assertions.Fail.fail;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.*;

public class BillingDAOImpl_UT extends BaseHibernateUnitTest {
    @Test
    public void testGetBillingsFromRevenueAccountCreatesAQueryFromSession() {
        BillingDAO billingDAO = new BillingDAOImpl(sessionFactory);
        RevenueAccount revenueAccount = new RevenueAccount();

        billingDAO.getBillingsFromRevenueAccount(revenueAccount);

        verify(session).createQuery(anyString());
    }

    @Test
    public void testGetBillingsFromRevenueAccountSetsRevenueAccountParameterToQuery() {
        BillingDAO billingDAO = new BillingDAOImpl(sessionFactory);
        RevenueAccount revenueAccount = new RevenueAccount();

        billingDAO.getBillingsFromRevenueAccount(revenueAccount);

        verify(query).setParameter("revenueAccount", revenueAccount);
    }

    @Test
    public void testGetBillingsFromRevenueAccountListsTheQuery() {
        BillingDAO billingDAO = new BillingDAOImpl(sessionFactory);
        RevenueAccount revenueAccount = new RevenueAccount();

        billingDAO.getBillingsFromRevenueAccount(revenueAccount);

        verify(query).list();
    }

    @Test
    public void testGetBillingsFromRevenueAccountReturnsTheQueryList() {
        Billing billing = new Billing();
        when(query.list()).thenReturn(Lists.newArrayList(billing));
        BillingDAO billingDAO = new BillingDAOImpl(sessionFactory);
        RevenueAccount revenueAccount = new RevenueAccount();

        List<Billing> billingsFromRevenueAccount = billingDAO.getBillingsFromRevenueAccount(revenueAccount);

        assertThat(billingsFromRevenueAccount).contains(billing);
    }

    @Test
    public void testGetBillingsFromRevenueAccountCreatesQueryWithCorrectQueryString() {
        BillingDAO billingDAO = new BillingDAOImpl(sessionFactory);
        RevenueAccount revenueAccount = new RevenueAccount();

        billingDAO.getBillingsFromRevenueAccount(revenueAccount);

        assertQueryStringIsSameAs("select distinct saleItem.billing from SaleItem saleItem where saleItem.revenueAccount = :revenueAccount");
    }

    @Test
    public void testSaveSavesBilling() {
        BillingDAO billingDAO = new BillingDAOImpl(sessionFactory);
        Billing billing = new Billing();

        billingDAO.save(billing);

        verify(session).saveOrUpdate(billing);
    }

    @Test
    public void testSaveForcesHibernateToFlush() {
        BillingDAO billingDAO = new BillingDAOImpl(sessionFactory);
        Billing billing = new Billing();

        billingDAO.save(billing);

        verify(session).flush();
    }

    @Test
    public void testSaveReturnsUpdatedBilling() {
        BillingDAO billingDAO = new BillingDAOImpl(sessionFactory);
        Billing billing = new Billing();

        Billing savedBilling = billingDAO.save(billing);

        assertThat(billing).isEqualTo(savedBilling);
    }

    @Test
    public void testGetByFilterCreatesCriteriaFromGivenFilter() {
        BillingDAO billingDAO = new BillingDAOImpl(sessionFactory);
        BillingFilter billingFilter = mock(BillingFilter.class);
        Criteria filterCriteria = mock(Criteria.class);
        when(billingFilter.buildCriteria(session)).thenReturn(filterCriteria);

        billingDAO.getByFilter(billingFilter);

        verify(billingFilter).buildCriteria(session);
    }

    @Test
    public void testGetByFilterListsCriteriaCreatedFromFilter() {
        BillingDAO billingDAO = new BillingDAOImpl(sessionFactory);
        BillingFilter billingFilter = mock(BillingFilter.class);
        Criteria filterCriteria = mock(Criteria.class);
        when(billingFilter.buildCriteria(session)).thenReturn(filterCriteria);

        billingDAO.getByFilter(billingFilter);

        verify(filterCriteria).list();
    }

    @Test
    public void testGetByFilterReturnsCriteriaList() {
        BillingDAO billingDAO = new BillingDAOImpl(sessionFactory);
        BillingFilter billingFilter = mock(BillingFilter.class);
        Criteria filterCriteria = mock(Criteria.class);
        ArrayList<Billing> billings = Lists.newArrayList(new Billing());
        when(filterCriteria.list()).thenReturn(billings);
        when(billingFilter.buildCriteria(session)).thenReturn(filterCriteria);

        List<Billing> resultingBillings = billingDAO.getByFilter(billingFilter);

        assertThat(resultingBillings).contains(billings.toArray());
    }

    @Test
    public void testGetByTransactionIdThrowsIllegalArgumentException_WhenTransactionNumberIsNull() throws EntityNotFoundException {
        BillingDAO billingDAO = new BillingDAOImpl(sessionFactory);

        try {
            billingDAO.getByTransactionId(null);
        } catch (IllegalArgumentException e) {
            assertThat(e).hasNoCause().hasMessage("The argument transactionNumber cannot be null");
        }
    }

    @Test
    public void testGetByTransactionIdCreatesQueryFromQueryString_WhenTransactionNumberisNotNull() throws EntityNotFoundException {
        BillingDAO billingDAO = new BillingDAOImpl(sessionFactory);
        when(query.uniqueResult()).thenReturn(new Billing());

        billingDAO.getByTransactionId(10l);

        assertQueryStringIsSameAs("from Billing b join fetch b.payments where b.transactionNumber = :p_transactionNumber");
    }

    @Test
    public void testGetByTransactionIdRetrievesUniqueResultFromQuery_WhenTransactionNumberisNotNull() throws EntityNotFoundException {
        BillingDAO billingDAO = new BillingDAOImpl(sessionFactory);
        when(query.uniqueResult()).thenReturn(new Billing());

        billingDAO.getByTransactionId(10l);

        verify(query).uniqueResult();
    }

    @Test
    public void testGetByTransactionIdThrowsEntityNotFoundException_WhenNoBillingIsFound() {
        BillingDAO billingDAO = new BillingDAOImpl(sessionFactory);
        when(query.uniqueResult()).thenReturn(null);

        try {
            billingDAO.getByTransactionId(10l);
            fail("Should throw EntityNotFoundException");
        } catch (EntityNotFoundException e) {
            assertThat(e).hasNoCause().hasMessage("com.monsanto.brazilvaluecapture.seedsale.billing.model.bean.Billing not found");
        }
    }

    @Test
    public void testGetByTransactionIReturnsFoundBilling_WhenTransactionNumberisNotNull() throws EntityNotFoundException {
        BillingDAO billingDAO = new BillingDAOImpl(sessionFactory);
        Billing expectedValue = new Billing();
        when(query.uniqueResult()).thenReturn(expectedValue);

        Billing savedBilling = billingDAO.getByTransactionId(10l);

        assertThat(savedBilling).isEqualTo(expectedValue);
    }

    @Test
    public void testGetBillingByCreatesCriteriaForBillingClass() {
        BillingDAO billingDAO = new BillingDAOImpl(sessionFactory);

        billingDAO.getBillingBy(10l);

        verify(session).createCriteria(Billing.class, "billing");
    }

    @Test
    public void testGetBillingByCreatesLeftJoinWithRoyalties() {
        BillingDAO billingDAO = new BillingDAOImpl(sessionFactory);

        billingDAO.getBillingBy(10l);

        verify(criteria).createCriteria("billing.royalties", "royalties", Criteria.LEFT_JOIN);
    }

    @Test
    public void testGetBillingByCreatesLeftJoinWithSaleItems() {
        BillingDAO billingDAO = new BillingDAOImpl(sessionFactory);

        billingDAO.getBillingBy(11l);

        verify(criteria).createCriteria("billing.items", "items", Criteria.LEFT_JOIN);
    }

    @Test
    public void testGetBillingByCreatesLeftJoinWithPayments() {
        BillingDAO billingDAO = new BillingDAOImpl(sessionFactory);

        billingDAO.getBillingBy(12l);

        verify(criteria).createCriteria("billing.payments", "payments", Criteria.LEFT_JOIN);
    }

    @Test
    public void testGetBillingByAddsRestrictiontoCriteriaAboutBillingId_UsingIdArgument() {
        BillingDAO billingDAO = new BillingDAOImpl(sessionFactory);

        billingDAO.getBillingBy(12l);

        verify(criteria).add(any(SimpleExpression.class));
    }

    @Test
    public void testGetBillingByRetrievesUniqueResultFromCriteria() {
        BillingDAO billingDAO = new BillingDAOImpl(sessionFactory);

        billingDAO.getBillingBy(12l);

        verify(criteria).uniqueResult();
    }

    @Test
    public void testGetByPaymentStatusCreatesQueryFromString() {
        BillingDAO billingDAO = new BillingDAOImpl(sessionFactory);
        PaymentStatus status = PaymentStatus.BILLED;

        billingDAO.getByPaymentStatus(status);

        assertQueryStringIsSameAs("FROM Billing B WHERE B.paymentStatus = :status");
    }

    @Test
    public void testGetByPaymentStatusSetsParameterStatusBILLED_WhenArgumentStatusIsBILLED() {
        BillingDAO billingDAO = new BillingDAOImpl(sessionFactory);
        PaymentStatus status = PaymentStatus.BILLED;

        billingDAO.getByPaymentStatus(status);

        verify(query).setParameter("status", status);
    }

    @Test
    public void testGetByPaymentStatusSetsParameterStatusCANCELLED_WhenArgumentStatusIsCANCELLED() {
        BillingDAO billingDAO = new BillingDAOImpl(sessionFactory);
        PaymentStatus status = PaymentStatus.CANCELLED;

        billingDAO.getByPaymentStatus(status);

        verify(query).setParameter("status", status);
    }

    @Test
    public void testGetByPaymentStatusListsQuery() {
        BillingDAO billingDAO = new BillingDAOImpl(sessionFactory);
        PaymentStatus status = PaymentStatus.CANCELLED;

        billingDAO.getByPaymentStatus(status);

        verify(query).list();
    }

    @Test
    public void testGetByPaymentStatusAndSaleTypeCreatesQueryFromString() {
        BillingDAO billingDAO = new BillingDAOImpl(sessionFactory);

        billingDAO.getByPaymentStatusAndSaleType(PaymentStatus.CANCELLED, Sale.SaleTypeEnum.DIRECT_SALE);

        assertQueryStringIsSameAs("FROM Billing B WHERE B.paymentStatus = :status and B.saleCode in (select s.id from Sale s where s.saleType = :saleType)");
    }

    @Test
    public void testGetByPaymentStatusAndSaleTypeSetsParamenterStatusForQuery() {
        BillingDAO billingDAO = new BillingDAOImpl(sessionFactory);
        PaymentStatus status = PaymentStatus.CANCELLED;

        billingDAO.getByPaymentStatusAndSaleType(status, Sale.SaleTypeEnum.DIRECT_SALE);

        verify(query).setParameter("status", status);
    }

    @Test
    public void testGetByPaymentStatusAndSaleTypeSetsParamenterSaleTypeForQuery() {
        BillingDAO billingDAO = new BillingDAOImpl(sessionFactory);
        PaymentStatus status = PaymentStatus.CANCELLED;

        Sale.SaleTypeEnum saleType = Sale.SaleTypeEnum.DIRECT_SALE;
        billingDAO.getByPaymentStatusAndSaleType(status, saleType);

        verify(query).setParameter("saleType", saleType);
    }

    @Test
    public void testGetByPaymentStatusAndSaleTypeListsQuery() {
        BillingDAO billingDAO = new BillingDAOImpl(sessionFactory);
        PaymentStatus status = PaymentStatus.CANCELLED;

        Sale.SaleTypeEnum saleType = Sale.SaleTypeEnum.DIRECT_SALE;
        billingDAO.getByPaymentStatusAndSaleType(status, saleType);

        verify(query).list();
    }

    @Test
    public void testGetBySaleCodeCreatesQueryFromString() {
        BillingDAO billingDAO = new BillingDAOImpl(sessionFactory);

        billingDAO.getBySaleCode(13l);

        assertQueryStringIsSameAs("FROM Billing B WHERE B.saleCode = :saleCode");
    }

    @Test
    public void testGetBySaleCodeSetsParamenterSaleTo13_WhenCodeArgumentIs13() {
        BillingDAO billingDAO = new BillingDAOImpl(sessionFactory);
        long saleCode = 13l;

        billingDAO.getBySaleCode(saleCode);

        verify(query).setParameter("saleCode", saleCode);
    }

    @Test
    public void testGetBySaleCodeSetsParamenterSaleTo14_WhenCodeArgumentIs14() {
        BillingDAO billingDAO = new BillingDAOImpl(sessionFactory);
        long saleCode = 14l;

        billingDAO.getBySaleCode(saleCode);

        verify(query).setParameter("saleCode", saleCode);
    }

    @Test
    public void testGetBySaleCodeSetsListsQuery() {
        BillingDAO billingDAO = new BillingDAOImpl(sessionFactory);
        long saleCode = 14l;

        billingDAO.getBySaleCode(saleCode);

        verify(query).list();
    }

    @Test
    public void testGetBillingsAndSalesByRevenueAccountOrderBySaleCodeCreatesQueryFromString() {
        BillingDAO billingDAO = new BillingDAOImpl(sessionFactory);
        RevenueAccount revenueAccount = new RevenueAccount();

        billingDAO.getBillingsAndSalesByRevenueAccountOrderBySaleCode(revenueAccount);

        String hql = "select distinct billing, sale" +
                " from Sale sale" +
                ", Billing billing" +
                " join billing.royalties royalty" +
                " join fetch billing.items saleItem" +
                " where sale.id = billing.saleCode" +
                " and billing.saleCode in (" +
                "     select distinct saleItem.sale.id" +
                "     from SaleItem saleItem" +
                "     where saleItem.revenueAccount = :revenueAccount" +
                " )" +
                " and royalty.technology.company = :company" +
                " order by billing.saleCode";
        assertQueryStringIsSameAs(hql);
    }

    @Test
    public void testGetBillingsAndSalesByRevenueAccountOrderBySaleCodeSetsParamenterRevenueAccount() {
        BillingDAO billingDAO = new BillingDAOImpl(sessionFactory);
        RevenueAccount revenueAccount = new RevenueAccount();

        billingDAO.getBillingsAndSalesByRevenueAccountOrderBySaleCode(revenueAccount);

        verify(query).setParameter("revenueAccount", revenueAccount);
    }
}