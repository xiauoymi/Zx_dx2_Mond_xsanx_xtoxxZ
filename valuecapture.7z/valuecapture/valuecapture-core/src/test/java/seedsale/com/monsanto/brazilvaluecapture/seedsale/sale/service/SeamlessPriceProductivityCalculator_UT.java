package com.monsanto.brazilvaluecapture.seedsale.sale.service;

import com.google.common.collect.Sets;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Crop;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Technology;
import com.monsanto.brazilvaluecapture.core.foundation.service.BusinessException;
import com.monsanto.brazilvaluecapture.seedsale.harvest.model.bean.Plantability;
import com.monsanto.brazilvaluecapture.seedsale.product.model.bean.Product;
import com.monsanto.brazilvaluecapture.seedsale.product.model.bean.ProductivityByRegion;
import com.monsanto.brazilvaluecapture.seedsale.product.model.bean.ProductivityByRegionValue;
import com.monsanto.brazilvaluecapture.seedsale.product.model.bean.Region;
import com.monsanto.brazilvaluecapture.seedsale.product.service.ProductivityByRegionService;
import org.junit.Test;

import java.math.BigDecimal;

import static org.fest.assertions.Assertions.assertThat;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

/**
 * Created with IntelliJ IDEA.
 * User: IFERN1
 * Date: 11/28/13
 * Time: 12:01 PM
 * To change this template use File | Settings | File Templates.
 */
public class SeamlessPriceProductivityCalculator_UT {
    @Test
    public void given_region_and_plantability_calculates_productivity() throws BusinessException {
        //@Given
        Crop crop = new Crop();
        crop.setDescription("Test crop");
        Product product = new Product();
        product.setDescription("Test product");
        product.setCrop(crop);
        Technology technology = new Technology();
        technology.setDescription("Test technology");
        product.setTechnology(technology);

        Region region = new Region();
        Plantability plantability = new Plantability();
        ProductivityByRegionService productivityByRegionService = mock(ProductivityByRegionService.class);
        ProductivityByRegion productivityByRegion = new ProductivityByRegion();
        ProductivityByRegionValue productivityByRegionValue = new ProductivityByRegionValue();
        productivityByRegionValue.setProduct(product);
        productivityByRegionValue.setProductivityMin(BigDecimal.valueOf(10));
        productivityByRegionValue.setProductivityMax(BigDecimal.valueOf(10));
        productivityByRegion.setProductivityByRegionValues(Sets.newHashSet(productivityByRegionValue));
        when(productivityByRegionService.getFromRegionAndPlantability(region, plantability)).thenReturn(productivityByRegion);

        //@When
        SeamlessPriceProductivityCalculator seamlessPriceProductivityCalculator = new SeamlessPriceProductivityCalculator(productivityByRegionService, region);
        BigDecimal actualProductivity = seamlessPriceProductivityCalculator.calculate(product, plantability);

        //@Should
        BigDecimal expectedPlantability = BigDecimal.TEN;
        assertTrue(actualProductivity.compareTo(expectedPlantability) == 0);
    }

    @Test
    public void given_a_pair_of_region_plantability_that_does_not_matches_a_ProductivityByRegion_throws_businessException() {
        //@given
        Crop crop = new Crop();
        crop.setDescription("Test crop");
        Product product = new Product();
        product.setDescription("Test product");
        product.setCrop(crop);
        Technology technology = new Technology();
        technology.setDescription("Test technology");
        product.setTechnology(technology);
        Region region = new Region();
        Plantability plantability = new Plantability();
        ProductivityByRegionService productivityByRegionService = mock(ProductivityByRegionService.class);
        when(productivityByRegionService.getFromRegionAndPlantability(region, plantability)).thenReturn(null);

        //@When
        SeamlessPriceProductivityCalculator seamlessPriceProductivityCalculator = new SeamlessPriceProductivityCalculator(productivityByRegionService, region);
        try {
            seamlessPriceProductivityCalculator.calculate(product, plantability);
            fail("Should throw BusinessException");
        } catch (Exception e) {
            //@should
            assertThat(e).isInstanceOf(BusinessException.class).hasNoCause();
        }
    }

    @Test
    public void given_a_productivityBuRegion_that_doesnot_contains_the_product_throws_businessException() {
        //@Given
        Crop crop = new Crop();
        crop.setDescription("Test crop");
        Product product = new Product();
        product.setDescription("Test product");
        product.setCrop(crop);
        Technology technology = new Technology();
        technology.setDescription("Test technology");
        product.setTechnology(technology);

        Region region = new Region();
        Plantability plantability = new Plantability();
        ProductivityByRegionService productivityByRegionService = mock(ProductivityByRegionService.class);
        ProductivityByRegion productivityByRegion = new ProductivityByRegion();
        ProductivityByRegionValue productivityByRegionValue = new ProductivityByRegionValue();
        Product someOtherProduct = new Product();
        someOtherProduct.setDescription("Some other product");
        productivityByRegionValue.setProduct(someOtherProduct);
        when(productivityByRegionService.getFromRegionAndPlantability(region, plantability)).thenReturn(productivityByRegion);

        //@When
        SeamlessPriceProductivityCalculator seamlessPriceProductivityCalculator = new SeamlessPriceProductivityCalculator(productivityByRegionService, region);
        try {
            seamlessPriceProductivityCalculator.calculate(product, plantability);
            fail("Should throw BusinessException");
        } catch (Exception e) {
            //@should
            assertThat(e).isInstanceOf(BusinessException.class).hasNoCause();
        }
    }
}
