package com.monsanto.brazilvaluecapture.seedsale.bonus.payment.impl;

import com.google.common.collect.Lists;
import com.monsanto.brazilvaluecapture.multiplier.seedsale.model.dao.SaleLinkDetailDAO;
import com.monsanto.brazilvaluecapture.seedsale.bonus.payment.SaleItemTotalRoyaltyValueCalculator;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.SaleItem;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.SaleLinkDetail;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.SaleLinkDetailValue;
import org.junit.Test;

import java.math.BigDecimal;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.*;

public class DealerToGrowerSaleItemTotalRoyaltyValueCalculatorImpl_UT {

    private SaleLinkDetailDAO saleLinkDetailDao = mock(SaleLinkDetailDAO.class);

    private SaleItemTotalRoyaltyValueCalculator totalRoyaltyValueCalculator = new DealerToGrowerSaleItemTotalRoyaltyValueCalculatorImpl(saleLinkDetailDao);

    @Test
    public void testCalculateTotalRoyaltyValueInvokesGetMultiplierToDealerSalesLinkedWith_allways() {
        //@Given
        SaleItem saleItem = new SaleItem();
        //@When
        totalRoyaltyValueCalculator.calculateTotalRoyaltyValue(saleItem);
        //@Then
        verify(saleLinkDetailDao).getSaleLinkDetailValuesAssociatedWith(saleItem);
    }

    @Test
    public void testCalculateTotalRoyaltyValueReturns0_whenThereIsNoLinkedSales() {
        //@Given
        SaleItem saleItem = new SaleItem();
        when(saleLinkDetailDao.getSaleLinkDetailValuesAssociatedWith(saleItem)).thenReturn(Lists.<SaleLinkDetailValue>newArrayList());
        //@When
        BigDecimal actual = totalRoyaltyValueCalculator.calculateTotalRoyaltyValue(saleItem);
        //@Then
        assertEquals(BigDecimal.ZERO, actual);
    }

    @Test
    public void testCalculateTotalRoyaltyValueReturns100_whenPriceQty125SoldQty10HaAmount2AndConsumed4() {
        //@Given
        SaleItem dealerSaleItem = new SaleItem();
        dealerSaleItem.setId(2L);
        SaleItem multiplierSaleItem = new SaleItem();
        multiplierSaleItem.setId(1L);
        multiplierSaleItem.setPriceQuantity(BigDecimal.valueOf(125));
        multiplierSaleItem.setSoldQuantity(10L);
        multiplierSaleItem.setHaAmount(BigDecimal.valueOf(2));
        SaleLinkDetailValue saleLinkDetailValue = new SaleLinkDetailValue();
        dealerSaleItem.setSaleLinkDetailValue(saleLinkDetailValue);
        saleLinkDetailValue.setDealerSaleItem(dealerSaleItem);
        saleLinkDetailValue.setConsumed(BigDecimal.valueOf(4));
        SaleLinkDetail saleLinkDetail = new SaleLinkDetail();
        multiplierSaleItem.setSaleLinkDetail(saleLinkDetail);
        saleLinkDetail.setSaleItem(multiplierSaleItem);
        saleLinkDetail.addSaleLinkDetailValue(saleLinkDetailValue);
        when(saleLinkDetailDao.getSaleLinkDetailValuesAssociatedWith(dealerSaleItem)).thenReturn(Lists.newArrayList(saleLinkDetailValue));
        //@When
        BigDecimal actual = totalRoyaltyValueCalculator.calculateTotalRoyaltyValue(dealerSaleItem);
        //@Then
        assertEquals(BigDecimal.valueOf(100).setScale(2), actual);
    }

    @Test
    public void testCalculateTotalRoyaltyValueReturns1248_whenPriceQty312SoldQty60HaAmount12AndConsumed20() {
        //@Given
        SaleItem dealerSaleItem = new SaleItem();
        dealerSaleItem.setId(2L);
        SaleItem multiplierSaleItem = new SaleItem();
        multiplierSaleItem.setId(1L);
        multiplierSaleItem.setPriceQuantity(BigDecimal.valueOf(312));
        multiplierSaleItem.setSoldQuantity(60L);
        multiplierSaleItem.setHaAmount(BigDecimal.valueOf(12));
        SaleLinkDetailValue saleLinkDetailValue = new SaleLinkDetailValue();
        dealerSaleItem.setSaleLinkDetailValue(saleLinkDetailValue);
        saleLinkDetailValue.setDealerSaleItem(dealerSaleItem);
        saleLinkDetailValue.setConsumed(BigDecimal.valueOf(20));
        SaleLinkDetail saleLinkDetail = new SaleLinkDetail();
        multiplierSaleItem.setSaleLinkDetail(saleLinkDetail);
        saleLinkDetail.setSaleItem(multiplierSaleItem);
        saleLinkDetail.addSaleLinkDetailValue(saleLinkDetailValue);
        when(saleLinkDetailDao.getSaleLinkDetailValuesAssociatedWith(dealerSaleItem)).thenReturn(Lists.newArrayList(saleLinkDetailValue));
        //@When
        BigDecimal actual = totalRoyaltyValueCalculator.calculateTotalRoyaltyValue(dealerSaleItem);
        //@Then
        assertEquals(BigDecimal.valueOf(1248).setScale(2), actual);
    }

}