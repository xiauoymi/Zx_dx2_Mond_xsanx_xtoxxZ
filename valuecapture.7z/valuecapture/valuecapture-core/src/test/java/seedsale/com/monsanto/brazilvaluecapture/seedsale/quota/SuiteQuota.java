package com.monsanto.brazilvaluecapture.seedsale.quota;

import org.junit.extensions.cpsuite.ClasspathSuite;
import org.junit.extensions.cpsuite.ClasspathSuite.ClassnameFilters;
import org.junit.runner.RunWith;

@RunWith(value = ClasspathSuite.class)
@ClassnameFilters(value={
		"com.monsanto.brazilvaluecapture.seedsale.quota.*AT",
		"com.monsanto.brazilvaluecapture.seedsale.quota.*UT"})
public class SuiteQuota {

}
