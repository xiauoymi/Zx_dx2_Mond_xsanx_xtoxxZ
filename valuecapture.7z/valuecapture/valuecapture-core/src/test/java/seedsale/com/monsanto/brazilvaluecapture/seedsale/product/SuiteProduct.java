package com.monsanto.brazilvaluecapture.seedsale.product;

import org.junit.extensions.cpsuite.ClasspathSuite;
import org.junit.extensions.cpsuite.ClasspathSuite.ClassnameFilters;
import org.junit.runner.RunWith;



@RunWith(value = ClasspathSuite.class)
/*@SuiteClasses(value = {ProductFilter_UT.class,
		ProductivityServiceImpl_UT.class,
		ProductivityService_AT.class,
		Productivity_AT.class,
		Productivity_UT.class,
		ProductService_AT.class,
		Product_AT.class,
		Product_UT.class})*/
@ClassnameFilters(value={
		"com.monsanto.brazilvaluecapture.seedsale.product.*AT",
		"com.monsanto.brazilvaluecapture.seedsale.product.*UT"})
public class SuiteProduct {

	
	
}
