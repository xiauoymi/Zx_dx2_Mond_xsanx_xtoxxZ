package com.monsanto.brazilvaluecapture.seedsale.sale.service.parser;

import java.util.Locale;
import java.util.ResourceBundle;

import junit.framework.Assert;

import org.junit.Before;
import org.junit.Test;

import com.monsanto.brazilvaluecapture.core.foundation.test.AbstractTestFixture;
import com.monsanto.brazilvaluecapture.core.foundation.util.csv.CSVParserReader.CSV_ERROS;
import com.monsanto.brazilvaluecapture.seedsale.sale.service.parser.registration.GrowerLineResult;

/**
 * @author cmiranda
 * 
 */
public class GrowerLineResult_UT extends AbstractTestFixture {

    private ResourceBundle resourceBundle = ResourceBundle.getBundle("bundle/bundle");

    @Before
    public void setup() {
        Locale.setDefault(Locale.US);
    }

    @Test
    public void test_get_formatted_message_with_field() {

        GrowerLineResult result = new GrowerLineResult();
        result.setField("import.file.name");
        result.setCodeWarn(CSV_ERROS.ERROR_COLUMN_MUST_BE_EMPTY);
        String message = result.getFormattedMessage(resourceBundle);
        Assert.assertNotNull(message);

    }
    
    @Test
    public void test_get_formatted_message_without_field() {

        GrowerLineResult result = new GrowerLineResult();
        result.setLine("1");
        result.setColumn(1);
        result.setCodeWarn(CSV_ERROS.ERROR_COLUMN_MUST_BE_EMPTY);
        String message = result.getFormattedMessage(resourceBundle);
        Assert.assertNotNull(message);

    }
}
