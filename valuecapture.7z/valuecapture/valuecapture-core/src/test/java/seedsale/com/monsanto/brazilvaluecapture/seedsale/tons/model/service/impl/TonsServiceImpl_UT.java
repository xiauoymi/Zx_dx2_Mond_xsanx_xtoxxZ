/**
 * 
 */
package com.monsanto.brazilvaluecapture.seedsale.tons.model.service.impl;

import static org.fest.reflect.core.Reflection.field;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.monsanto.brazilvaluecapture.seedsale.harvest.model.bean.Harvest;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.TonsLeakReportDTO;
import com.monsanto.brazilvaluecapture.seedsale.tons.model.dao.TonsDAO;
import com.monsanto.brazilvaluecapture.seedsale.tons.model.service.TonsService;

/**
 * @author PDFOLG
 *
 */
public class TonsServiceImpl_UT {

	TonsService tonsService;

	@Mock
	private TonsDAO tonsDAO;

	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
		this.tonsService = new TonsServiceImpl();
		field("tonsDAO").ofType(TonsDAO.class).in(this.tonsService)
				.set(this.tonsDAO);
	}

	@Test
	public void testGetTonsLeakBalance() {
		 Harvest harvest = new Harvest();
		 String cuit = "20201231232";
		 when(tonsService.getTonsLeakBalance(harvest, cuit)).thenReturn(new ArrayList<TonsLeakReportDTO>());
		 this.tonsService.getTonsLeakBalance(harvest, cuit);
		 verify(tonsDAO, times(1)).getTonsLeakBalance(harvest,cuit);
	}

}
