package com.monsanto.brazilvaluecapture.seedsale.bonus.payment.impl;

import com.monsanto.brazilvaluecapture.seedsale.bonus.payment.SaleItemTotalRoyaltyValueCalculator;
import com.monsanto.brazilvaluecapture.seedsale.bonus.payment.SaleItemTotalRoyaltyValueCalculatorFactory;
import com.monsanto.brazilvaluecapture.seedsale.bonus.payment.exception.TotalRoyaltyValueCalculatorNotFoundException;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.Sale;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.SaleItem;
import org.junit.Test;

import static org.fest.assertions.Assertions.assertThat;
import static org.fest.assertions.Fail.fail;
import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.mock;

public class SaleItemTotalRoyaltyValueCalculatorFactoryImpl_UT {

    private SaleItemTotalRoyaltyValueCalculator dealerToGrowerCalculator = mock(DealerToGrowerSaleItemTotalRoyaltyValueCalculatorImpl.class);
    private SaleItemTotalRoyaltyValueCalculator multiplierToGrowerCalculator = mock(MultiplierToGrowerSaleItemTotalRoyaltyValueCalculatorImpl.class);
    private SaleItemTotalRoyaltyValueCalculatorFactory factory = new SaleItemTotalRoyaltyValueCalculatorFactoryImpl(dealerToGrowerCalculator, multiplierToGrowerCalculator);

    @Test
    public void testGetCalculatorForThrowsTotalRoyaltyValueCalculatorNotFoundException_whenInvalidSaleTypeIsUsed() {
        //@Given
        Sale sale = new Sale();
        sale.setSaleType(Sale.SaleTypeEnum.MULTIPLIER_SEED_SALE);
        SaleItem saleItem = new SaleItem();
        sale.addItem(saleItem);
        //@When
        try {
            factory.getCalculatorFor(saleItem);
            fail("Should throw TotalRoyaltyValueCalculatorNotFoundException for invalid Sale Type");
        } catch (TotalRoyaltyValueCalculatorNotFoundException e) {
            //@Then
            assertEquals("no.total.royalty.value.calculator.for.sale.type", e.getMessage());
        }
    }

    @Test
    public void testGetCalculatorForReturnsDealerToGrowerCalculator_whenSALE_SEEDSaleTypeIsUsed() throws TotalRoyaltyValueCalculatorNotFoundException {
        //@Given
        Sale sale = new Sale();
        sale.setSaleType(Sale.SaleTypeEnum.SALE_SEED);
        SaleItem saleItem = new SaleItem();
        sale.addItem(saleItem);
        //@When
        SaleItemTotalRoyaltyValueCalculator calculator = factory.getCalculatorFor(saleItem);
        assertThat(calculator).isInstanceOf(DealerToGrowerSaleItemTotalRoyaltyValueCalculatorImpl.class);
    }

    @Test
    public void testGetCalculatorForReturnsMultiplierToGrowerCalculator_whenMULTIPLIER_TO_GROWER_SEED_SALESaleTypeIsUsed() throws TotalRoyaltyValueCalculatorNotFoundException {
        //@Given
        Sale sale = new Sale();
        sale.setSaleType(Sale.SaleTypeEnum.MULTIPLIER_TO_GROWER_SEED_SALE);
        SaleItem saleItem = new SaleItem();
        sale.addItem(saleItem);
        //@When
        SaleItemTotalRoyaltyValueCalculator calculator = factory.getCalculatorFor(saleItem);
        assertThat(calculator).isInstanceOf(MultiplierToGrowerSaleItemTotalRoyaltyValueCalculatorImpl.class);
    }

}