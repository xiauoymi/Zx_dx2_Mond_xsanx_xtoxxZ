package com.monsanto.brazilvaluecapture.seedsale.quota;

import java.math.BigDecimal;
import java.util.ArrayList;

import junit.framework.Assert;

import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.monsanto.brazilvaluecapture.core.account.service.InsufficientBalanceException;
import com.monsanto.brazilvaluecapture.core.base.SystemTestFixture;
import com.monsanto.brazilvaluecapture.core.foundation.service.BusinessException;
import com.monsanto.brazilvaluecapture.seedsale.quota.model.bean.Quota;
import com.monsanto.brazilvaluecapture.seedsale.quota.model.bean.QuotaEntry;
import com.monsanto.brazilvaluecapture.seedsale.quota.model.bean.QuotaTransaction;
import com.monsanto.brazilvaluecapture.seedsale.quota.model.bean.QuotaTransaction.QuotaTransactionType;
import com.monsanto.brazilvaluecapture.seedsale.quota.model.bean.QuotaTransactionBuilder;
import com.monsanto.brazilvaluecapture.seedsale.quota.model.bean.QuotaType;
import com.monsanto.brazilvaluecapture.seedsale.sale.SaleTestFixture;

public class QuotaTransactionBuilder_UT {

	private QuotaTransactionBuilder quotaTransactionBuilder;
	
	private static SystemTestFixture systemTestFixture;
	private static SaleTestFixture saleTestFixture;
	
	@Before
	public void setup() {
		quotaTransactionBuilder = new QuotaTransactionBuilder(null,null, null, null);
	}
	
	@BeforeClass
	public static void onlyOnce() throws BusinessException {
		systemTestFixture = new SystemTestFixture();
		saleTestFixture = new SaleTestFixture(systemTestFixture);
	}
	
	@Test(expected=IllegalStateException.class)
	public void quotaTransactionBuilder_without_entries_throws_exception() {
		quotaTransactionBuilder.build();
	}
	
	@Test(expected=IllegalStateException.class)
	public void given_an_balance_without_entries_should_failCheckConstraint() {
		QuotaTransaction.checkConstraint(BigDecimal.ONE, new ArrayList<QuotaEntry>());
	}
	
	@Test
	public void given_a_quota_when_i_deposit_500_should_have_balance_500() {
		Quota quota = createQuota();
		
		BigDecimal depositFiveHundreed = new BigDecimal(500);
		QuotaTransaction quotaTransaction = quotaTransactionBuilder.addDeposit(quota, depositFiveHundreed).build();
		
		Assert.assertEquals("Should have 1 entry", 1, quota.getEntries().size());
		Assert.assertEquals("Transaction should have a balance of five hundreed", depositFiveHundreed, quotaTransaction.getBalance());
		Assert.assertEquals("Quota should have a balance of five hundreed", depositFiveHundreed, quota.getBalance());
	}

	private Quota createQuota() {
		return new Quota(systemTestFixture.operationalYearOf2012, saleTestFixture.customer, saleTestFixture.productBtSoy, QuotaType.AVAILABLE);
	}
	
	@Test(expected=InsufficientBalanceException.class)
	public void given_a_quota_with_zero_balance_when_i_withdrawal_should_throw_exception() {
		Quota quota = createQuota();

		quotaTransactionBuilder.addWithdrawal(quota, BigDecimal.ONE);
		Assert.fail("Should have thrown exception of insufficient balance");
	}
	
	@Test
	public void given_a_quota_with_one_depoist_of_ten_and_and_two_withdrawals_of_five_should_have_balance_zerp() {
		Quota quota = createQuota();
		
		BigDecimal valueFive = new BigDecimal(5);
		quotaTransactionBuilder = new QuotaTransactionBuilder(QuotaTransactionType.SALE, 123L, null, "JOHN");
		QuotaTransaction quotaTransaction = quotaTransactionBuilder.addDeposit(quota, BigDecimal.TEN).addWithdrawal(quota, valueFive).addWithdrawal(quota, valueFive).build();
		
		Assert.assertEquals("Should have two entries", 3, quotaTransaction.getEntries().size());
		Assert.assertEquals("Quota should have balance of zero", BigDecimal.ZERO, quota.getBalance());
	}
}
