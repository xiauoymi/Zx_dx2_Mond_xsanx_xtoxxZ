package com.monsanto.brazilvaluecapture.seedsale.harvest;

import org.junit.extensions.cpsuite.ClasspathSuite;
import org.junit.extensions.cpsuite.ClasspathSuite.ClassnameFilters;
import org.junit.runner.RunWith;

@RunWith(value = ClasspathSuite.class)
/*@SuiteClasses(value = 
		{OperationalYearServiceImpl_UT.class,
		OperationalYearService_AT.class,
		OperationalYear_AT.class,
		OperationalYear_UT.class,
		PlantabilityDAO_AT.class,
		PlantabilityService_AT.class,
		Plantability_UT.class,
		PlantablityServiceImpl_UT.class})*/
@ClassnameFilters(value={"com.monsanto.brazilvaluecapture.seedsale.harvest.*AT"})
public class SuiteHarvest{


}
