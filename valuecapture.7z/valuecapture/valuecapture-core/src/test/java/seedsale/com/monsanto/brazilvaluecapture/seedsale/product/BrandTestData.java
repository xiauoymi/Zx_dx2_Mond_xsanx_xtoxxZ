package com.monsanto.brazilvaluecapture.seedsale.product;

import com.monsanto.brazilvaluecapture.core.base.model.bean.Company;
import com.monsanto.brazilvaluecapture.core.foundation.RandomTestData;
import com.monsanto.brazilvaluecapture.core.foundation.model.bean.StatusEnum;
import com.monsanto.brazilvaluecapture.seedsale.product.model.bean.Brand;

public class BrandTestData {

	public static Brand createBrand(Company company) {
		Brand brand = new Brand(RandomTestData.createRandomString(6), company, StatusEnum.ACTIVE);
		company.addBrand(brand);
		return brand;
	}
}
