package com.monsanto.brazilvaluecapture.seedsale.sale.service.impl;

import com.monsanto.brazilvaluecapture.core.base.model.bean.Address;
import com.monsanto.brazilvaluecapture.core.base.model.bean.BillingAddress;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Country;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Customer;
import com.monsanto.brazilvaluecapture.core.foundation.service.BusinessException;
import com.monsanto.brazilvaluecapture.core.foundation.service.EntityNotFoundException;
import com.monsanto.brazilvaluecapture.core.foundation.service.ExpectedSingleEntityException;
import com.monsanto.brazilvaluecapture.core.foundation.service.SAPOperationException;
import com.monsanto.brazilvaluecapture.core.grower.model.bean.Grower;
import com.monsanto.brazilvaluecapture.core.grower.service.impl.PaymentRegistrationServiceRunner;
import com.monsanto.brazilvaluecapture.core.quota.model.bean.QuotaFY;
import com.monsanto.brazilvaluecapture.core.quota.model.bean.QuotaFYPaid;
import com.monsanto.brazilvaluecapture.core.quota.model.dao.QuotaFYDAO;
import com.monsanto.brazilvaluecapture.core.quota.model.dao.QuotaFYTransactionDAO;
import com.monsanto.brazilvaluecapture.core.regionalization.CountriesHolder;
import com.monsanto.brazilvaluecapture.core.regionalization.VCCountry;
import com.monsanto.brazilvaluecapture.core.serviceFee.service.impl.PostingDocVcSapServiceRunner;
import com.monsanto.brazilvaluecapture.core.serviceFee.model.bean.ServiceFeeProgram;
import com.monsanto.brazilvaluecapture.core.serviceFee.service.ServiceFeeService;
import com.monsanto.brazilvaluecapture.osb.its.sappaymentsregistration.bean.YtyPymntAdvice;
import com.monsanto.brazilvaluecapture.osb.its.serviceFeeAccruals.bean.YlasFiPostingDocVcSapResponse;
import com.monsanto.brazilvaluecapture.pod.rol.model.bean.GermoSupplierLocation;
import com.monsanto.brazilvaluecapture.seedsale.billing.model.bean.Billing;
import com.monsanto.brazilvaluecapture.seedsale.billing.model.bean.PaymentStatus;
import com.monsanto.brazilvaluecapture.seedsale.billing.model.bean.PossiblePayment;
import com.monsanto.brazilvaluecapture.seedsale.billing.model.dao.BillingDAO;
import com.monsanto.brazilvaluecapture.seedsale.billing.model.dao.BillingFilter;
import com.monsanto.brazilvaluecapture.seedsale.billing.service.BillingConstraintViolationException;
import com.monsanto.brazilvaluecapture.seedsale.feeAccount.model.bean.FeeAccount;
import com.monsanto.brazilvaluecapture.seedsale.feeAccount.service.FeeAccountService;
import com.monsanto.brazilvaluecapture.seedsale.harvest.model.bean.Harvest;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.Sale;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.SaleItem;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.dao.GermoSupplierLocationDAO;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.dao.SaleDAO;
import com.monsanto.brazilvaluecapture.seedsale.sale.service.IndustrySystemService;
import com.monsanto.brazilvaluecapture.seedsale.sale.service.PaymentRegistrationService;
import com.monsanto.brazilvaluecapture.seedsale.sale.service.SapPaidPayment;
import com.monsanto.brazilvaluecapture.seedsale.sale.service.SapPaymentFactory;
import com.monsanto.brazilvaluecapture.seedsale.template.model.bean.Price;
import com.monsanto.brazilvaluecapture.seedsale.template.model.bean.SaleTemplate;
import com.monsanto.brazilvaluecapture.seedsale.template.model.bean.SaleTemplatePaymentMethodEnum;
import com.monsanto.brazilvaluecapture.seedsale.template.model.bean.TechnologyFee;
import com.monsanto.brazilvaluecapture.seedsale.warehouse.model.bean.Warehouse;
import com.monsanto.brazilvaluecapture.seedsale.warehouse.service.WarehouseService;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import java.math.BigDecimal;
import java.util.*;

import static org.fest.reflect.core.Reflection.field;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.*;
import static org.mockito.internal.verification.VerificationModeFactory.times;

public class PaymentRegistrationServiceImpl_UT {

    PaymentRegistrationService paymentRegistrationService;

    @Mock
    BillingDAO billingDAO;

    @Mock
    SaleDAO saleDAO;

    @Mock
    PaymentRegistrationServiceRunner paymentRegistrationServiceRunner;

    @Mock
    QuotaFYDAO quotaFYDAO;

    @Mock
    QuotaFYTransactionDAO quotaFYTransactionDAO;

    @Mock
    AccountManager accountManager;

    @Mock
    IndustrySystemService industrySystemService;

    @Mock
    GermoSupplierLocationDAO germoSupplierLocationDAO;

    @Mock
    FeeAccountService feeAccountService;

    @Mock
    SapPaymentFactory sapPaymentFactory;

    @Mock
    CountriesHolder countriesHolder;
    @Mock
    WarehouseService warehouseService;
    @Mock
    Warehouse warehouse;

    @Mock
    PostingDocVcSapServiceRunner postingDocVcSapServiceRunner;
    @Mock
    QuotaFYDAO getQuotaFYDAO;

	@Mock
    ServiceFeeService serviceFeeService;

    @Before
    public void setUp() throws Exception {
        MockitoAnnotations.initMocks(this);
        paymentRegistrationService = new PaymentRegistrationServiceImpl();
        field("sapPaymentFactory").ofType(SapPaymentFactory.class).in(paymentRegistrationService).set(sapPaymentFactory);

    }

    private List<Billing> getBillings() {
        List<Billing> billings = new ArrayList<Billing>();
        Billing billing = new Billing();
        billing.setPaymentStatus(PaymentStatus.INVOICED);
        billings.add(billing);
        return billings;
    }

    private Set<SaleItem> getSaleItems() {
         Set<SaleItem> saleItems = new LinkedHashSet<SaleItem>();
        SaleItem saleItem = new SaleItem();
        saleItem.setSoldQuantity(20L);
        Billing billing = new Billing();
        billing.setPaymentStatus(PaymentStatus.INVOICED);
        billing.getPayments().add(new PossiblePayment());
        saleItem.setBilling(billing);
        saleItems.add(saleItem);

        return saleItems;
    }
    @Test
    public void testUpdatePayments_WhenSaleTypeParameterIsPreCampaignAndSaleGermoSupplierIsNotNullAndSaleSaleTypePreCampaignThenReleaseTonsAndUpdateQuota() throws BusinessException {

        field("billingDAO").ofType(BillingDAO.class).in(paymentRegistrationService).set(billingDAO);
        field("saleDAO").ofType(SaleDAO.class).in(paymentRegistrationService).set(saleDAO);
        field("quotaFYDAO").ofType(QuotaFYDAO.class).in(paymentRegistrationService).set(quotaFYDAO);
        field("quotaFYTransactionDAO").ofType(QuotaFYTransactionDAO.class).in(paymentRegistrationService).set(quotaFYTransactionDAO);

        QuotaFY quotaFY = new QuotaFY();
        quotaFY.setBalance(new BigDecimal(25));
        quotaFY.setDeliveryBalance(new BigDecimal(15));

        when(quotaFYDAO.selectBy(Matchers.<Long>any(), Matchers.<Long>any(), Matchers.<String>any())).thenReturn(quotaFY);

        List<Billing> billingList = new ArrayList<Billing>();
        Billing billing = new Billing();
        Long saleCode = new Long(25);
        billing.setSaleCode(saleCode);
        billingList.add(billing);
        billing.getPayments().add(new PossiblePayment());

        when(billingDAO.getByPaymentStatusAndSaleType(PaymentStatus.NOT_PAID, Sale.SaleTypeEnum.PRE_CAMPAIGN)).thenReturn(billingList);

        SaleItem saleItem = new SaleItem(null, null, null);
        saleItem.setBilling(billing);
        saleItem.setSoldQuantity(new Long(25));
        Set saleItemsSet = new HashSet<SaleItem>();
        saleItemsSet.add(saleItem);

        Grower grower = new Grower();

        Customer customer = new Customer();
        field("id").ofType(Long.class).in(customer).set(new Long(25));

        Sale sale = new Sale(customer, grower);
        sale.setWarehouse(new Warehouse());
        sale.setSaleType(Sale.SaleTypeEnum.PRE_CAMPAIGN);
        sale.setItems(saleItemsSet);
        field("saleOrderSAPId").ofType(Long.class).in(sale).set(new Long(25));
        field("id").ofType(Long.class).in(sale).set(saleCode);
        when(saleDAO.getById(Matchers.<Long>anyObject())).thenReturn(sale);

        AccountManager accountManagerService = mock(AccountManagerServiceImpl.class);
        field("accountManager").ofType(AccountManager.class).in(paymentRegistrationService).set(accountManagerService);
        IndustrySystemService industrySystemService = mock(IndustrySystemServiceImpl.class);
        field("industrySystemService").ofType(IndustrySystemService.class).in(paymentRegistrationService).set(industrySystemService);

        paymentRegistrationService.updatePayments(Sale.SaleTypeEnum.PRE_CAMPAIGN);

        verify(accountManagerService, times(1)).managePaymentFor(eq(grower), eq(billing));
        verify(industrySystemService, times(1)).registerPayment(eq(sale), Matchers.<BigDecimal>any());
    }

    @Test
    public void testUpdatePayments_WhenSaleTypeParameterIsSaleAndOrderObtentorAndThenReleaseTons() throws BusinessException {

        field("billingDAO").ofType(BillingDAO.class).in(paymentRegistrationService).set(billingDAO);
        field("saleDAO").ofType(SaleDAO.class).in(paymentRegistrationService).set(saleDAO);

        List<Billing> billingList = new ArrayList<Billing>();
        Billing billing = new Billing();
        Long saleCode = new Long(25);
        billing.setSaleCode(saleCode);
        billingList.add(billing);

        when(billingDAO.getByPaymentStatusAndSaleType(PaymentStatus.NOT_PAID, Sale.SaleTypeEnum.SALE_AND_ORDER_OBTENTOR)).thenReturn(billingList);

        Grower grower = new Grower();
        Sale sale = new Sale(null, grower);
        sale.setSaleType(Sale.SaleTypeEnum.SALE_AND_ORDER_OBTENTOR);
        field("id").ofType(Long.class).in(sale).set(saleCode);
        when(saleDAO.getById(Matchers.<Long>anyObject())).thenReturn(sale);

        AccountManager accountManagerService = mock(AccountManagerServiceImpl.class);
        field("accountManager").ofType(AccountManager.class).in(paymentRegistrationService).set(accountManagerService);
        IndustrySystemService industrySystemService = mock(IndustrySystemServiceImpl.class);
        field("industrySystemService").ofType(IndustrySystemService.class).in(paymentRegistrationService).set(industrySystemService);

        paymentRegistrationService.updatePayments(Sale.SaleTypeEnum.SALE_AND_ORDER_OBTENTOR);

        verify(accountManagerService, times(1)).managePaymentFor(eq(grower), eq(billing));
        verify(industrySystemService, times(1)).registerPayment(eq(sale), Matchers.<BigDecimal>any());
    }

    @Test
     public void testUpdatePayments_WhenValidDate() throws Exception {
        // @Given
        Date paymentDate = new Date();

        List<YtyPymntAdvice> payments = new ArrayList<YtyPymntAdvice>();

        YtyPymntAdvice payment = new YtyPymntAdvice();
        payment.setYidTransVc("1");
        payment.setYsalesOrderType("R");
        payment.setYstatus("PAGADO");
        payments.add(payment);


        Sale sale = new Sale();
        sale.setDateHours(new Date());
        Grower grower = new Grower();
        grower.setCustomerSapId("1");
        sale.setGrower(grower);
        Customer customer = new Customer();
        customer.setCustomerSAPCode("2");
        Country country = new Country();
        country.setCode("AR");
        Address address = new Address();
        address.setCountry(country);
        field("address").ofType(Address.class).in(customer).set(address);
        sale.setCustomer(customer);


        List<Billing> billingList = new ArrayList<Billing>();
        Billing billing = new Billing();
        Long saleCode = new Long(25);
        billing.setSaleCode(saleCode);
        billingList.add(billing);
        billing.getPayments().add(new PossiblePayment());
        billing.setPaymentStatus(PaymentStatus.NOT_PAID);

        SaleItem saleItem = new SaleItem(null, null, null);
        saleItem.setBilling(billing);
        saleItem.setSoldQuantity(new Long(25));
        saleItem.setTotalCreditValue(new Long(5));


        SaleTemplate saleTemplate = new SaleTemplate();
        Set<Price> priceSet = new LinkedHashSet<Price>();
        Price price = new Price();

        Set<TechnologyFee> technologyFeeSet = new LinkedHashSet<TechnologyFee>();
        TechnologyFee technologyFee = new TechnologyFee();
        technologyFee.setFeeValue(new BigDecimal(2));
        technologyFee.setType(TechnologyFee.TechFeeTypeEnum.TONS);
        technologyFee.setServiceFeeProgram(getServiceFeeProgramMock());
        technologyFeeSet.add(technologyFee);

        price.setTechnologyFees(technologyFeeSet);
        priceSet.add(price);

        saleTemplate.setPrices(priceSet);
        Harvest harvest = new Harvest();
        saleTemplate.setHarvest(harvest);
        saleItem.setSaleTemplate(saleTemplate);
        Set saleItemsSet = new HashSet<SaleItem>();
        saleItemsSet.add(saleItem);

        sale.setItems(saleItemsSet);

        FeeAccount feeAccount = new FeeAccount();

        field("id").ofType(Long.class).in(sale).set(new Long(1));
        field("id").ofType(Long.class).in(grower).set(new Long(2));
        field("id").ofType(Long.class).in(customer).set(new Long(3));
        List<Billing> billings = getBillings();
        billings.add(billing);

        field("paymentRegistrationServiceRunner").ofType(PaymentRegistrationServiceRunner.class).in(paymentRegistrationService).set(paymentRegistrationServiceRunner);
        field("billingDAO").ofType(BillingDAO.class).in(paymentRegistrationService).set(billingDAO);
        field("feeAccountService").ofType(FeeAccountService.class).in(paymentRegistrationService).set(feeAccountService);
        field("serviceFeeService").ofType(ServiceFeeService.class).in(paymentRegistrationService).set(serviceFeeService);
		field("postingDocVcSapServiceRunner").ofType(PostingDocVcSapServiceRunner.class).in(paymentRegistrationService).set(postingDocVcSapServiceRunner);
        YlasFiPostingDocVcSapResponse response = Mockito.mock(YlasFiPostingDocVcSapResponse.class);
        when(response.getObjKey()).thenReturn("");
        when(postingDocVcSapServiceRunner.getServiceResponse()).thenReturn(response);


        // @When
        when(paymentRegistrationServiceRunner.getPaymentsSapVcResponse()).thenReturn(payments);
        when(billingDAO.getByFilter(any(BillingFilter.class))).thenReturn(billings);
        when(feeAccountService.customerByYidTransVc(Long.valueOf(payment.getYidTransVc()))).thenReturn(sale);
        when(feeAccountService.getFeeAccountByCustomer(any(Customer.class), anyString())).thenReturn(null);
        SapPaidPayment sapPaidPayment = new SapPaidPayment(payment.getYlegalNumber(), SaleTemplatePaymentMethodEnum.BANK_SLIP,payment.getYfiDoc(),new Date(), billing);
        when(sapPaymentFactory.build(payment,billings.get(0))).thenReturn(sapPaidPayment);
        when(serviceFeeService.getServiceFeeProgramByCode(anyString())).thenReturn(getServiceFeeProgramMock());
		postingDocVcSapServiceRunner = Mockito.mock(PostingDocVcSapServiceRunner.class);



        paymentRegistrationService.updatePayments(paymentDate);

        //  @Should
        verify(paymentRegistrationServiceRunner).getPaymentsSapVcResponse();
        verify(billingDAO).getByFilter(any(BillingFilter.class));
    }

    @Test
    public void testUpdatePayments_WhenValidDateAndPaymentYidTransVcIsNull() throws Exception {
        // @Given
        Date paymentDate = new Date();

        List<YtyPymntAdvice> payments = new ArrayList<YtyPymntAdvice>();

        YtyPymntAdvice payment = new YtyPymntAdvice();
        payment.setYidTransVc(null);
        payments.add(payment);

        List<Billing> billings = getBillings();

        field("paymentRegistrationServiceRunner").ofType(PaymentRegistrationServiceRunner.class).in(paymentRegistrationService).set(paymentRegistrationServiceRunner);
        field("billingDAO").ofType(BillingDAO.class).in(paymentRegistrationService).set(billingDAO);

        // @When
        when(paymentRegistrationServiceRunner.getPaymentsSapVcResponse()).thenReturn(payments);
        when(billingDAO.getByFilter(any(BillingFilter.class))).thenReturn(billings);

        paymentRegistrationService.updatePayments(paymentDate);

        //  @Should
      /*  verify(paymentRegistrationServiceRunner).getPaymentsSapVcResponse();
        verify(billingDAO).getByFilter(any(BillingFilter.class)); */
    }

    @Test
    public void testUpdatePayments_WhenValidDateAndPaymentIsCooperative() throws Exception {
        // @Given
        Date paymentDate = new Date();

        List<YtyPymntAdvice> payments = new ArrayList<YtyPymntAdvice>();

        YtyPymntAdvice payment = new YtyPymntAdvice();
        payment.setYidTransVc("1");
        payment.setYsalesOrderType("C");
        payment.setYstatus("PAGADO");
        payments.add(payment);
        Billing billing = new Billing();
        Long saleCode = new Long(25);
        billing.setSaleCode(saleCode);
        billing.setPaymentStatus(PaymentStatus.NOT_PAID);

        List<Billing> billings = new ArrayList<Billing>();
        billings.add(billing);
        field("paymentRegistrationServiceRunner").ofType(PaymentRegistrationServiceRunner.class).in(paymentRegistrationService).set(paymentRegistrationServiceRunner);
        field("billingDAO").ofType(BillingDAO.class).in(paymentRegistrationService).set(billingDAO);

        // @When
        when(paymentRegistrationServiceRunner.getPaymentsSapVcResponse()).thenReturn(payments);
        when(billingDAO.getByFilter(any(BillingFilter.class))).thenReturn(billings);
        SapPaidPayment sapPaidPayment = new SapPaidPayment(payment.getYlegalNumber(), SaleTemplatePaymentMethodEnum.BANK_SLIP, payment.getYfiDoc(), new Date(), billings.get(0));
        when(sapPaymentFactory.build(payment, billings.get(0))).thenReturn(sapPaidPayment);

        paymentRegistrationService.updatePayments(paymentDate);

        //  @Should
        verify(paymentRegistrationServiceRunner).getPaymentsSapVcResponse();
        verify(billingDAO).getByFilter(any(BillingFilter.class));
    }

    @Test
    public void testUpdatePayments_WhenValidDateAndPaymentStatusIsNotPaidAndYpaidDateWrongFormat() throws Exception {
        // @Given
        Date paymentDate = new Date();

        List<YtyPymntAdvice> payments = new ArrayList<YtyPymntAdvice>();

        YtyPymntAdvice payment = new YtyPymntAdvice();
        payment.setYidTransVc("1");
        payment.setYpaidDate("1988/01/01");
        payment.setYsalesOrderType("G");
        payment.setYstatus("PAGADO");
        payments.add(payment);

        List<Billing> billings = new ArrayList<Billing>();
        Billing billing = new Billing();
        PossiblePayment possiblePayment = new PossiblePayment();
        possiblePayment.setPaidValue(new BigDecimal(1));
        Set<PossiblePayment> possiblePayments = new HashSet<PossiblePayment>();
        field("payments").ofType(Set.class).in(billing).set(possiblePayments);
        billing.setPaymentStatus(PaymentStatus.NOT_PAID);
        billings.add(billing);

        List<Sale> sales = new ArrayList<Sale>();
        Grower grower = new Grower();
        Sale sale = new Sale(null, grower);
        sales.add(sale);

        field("paymentRegistrationServiceRunner").ofType(PaymentRegistrationServiceRunner.class).in(paymentRegistrationService).set(paymentRegistrationServiceRunner);
        field("billingDAO").ofType(BillingDAO.class).in(paymentRegistrationService).set(billingDAO);
        field("saleDAO").ofType(SaleDAO.class).in(paymentRegistrationService).set(saleDAO);
        field("accountManager").ofType(AccountManager.class).in(paymentRegistrationService).set(accountManager);
        field("industrySystemService").ofType(IndustrySystemService.class).in(paymentRegistrationService).set(industrySystemService);

        // @When
        when(paymentRegistrationServiceRunner.getPaymentsSapVcResponse()).thenReturn(payments);
        when(billingDAO.getByFilter(any(BillingFilter.class))).thenReturn(billings);
        when(saleDAO.findByPaymentBatchId(any(Long.class))).thenReturn(sales);
        when(saleDAO.getById(any(Long.class))).thenReturn(sale);


        paymentRegistrationService.updatePayments(paymentDate);

        //  @Should
        verify(paymentRegistrationServiceRunner).getPaymentsSapVcResponse();
        verify(billingDAO).getByFilter(any(BillingFilter.class));
      //  verify(saleDAO).findByPaymentBatchId(any(Long.class));
      //  verify(saleDAO).getById(any(Long.class));

    }


    @Test
    public void testUpdatePayments_WhenValidDateAndPaymentStatusIsNotPaidAndCooperative() throws Exception {
        // @Given
        Date paymentDate = new Date();

        List<YtyPymntAdvice> payments = new ArrayList<YtyPymntAdvice>();

        YtyPymntAdvice payment = new YtyPymntAdvice();
        payment.setYidTransVc("1");
        payment.setYpaidDate("1988-01-01");
        payment.setYsalesOrderType("C");
        payment.setYstatus("PAGADO");
        payments.add(payment);

        List<Billing> billings = new ArrayList<Billing>();
        Billing billing = new Billing();
        PossiblePayment possiblePayment = new PossiblePayment();
        possiblePayment.setPaidValue(new BigDecimal(1));
        Set<PossiblePayment> possiblePayments = new HashSet<PossiblePayment>();
        field("payments").ofType(Set.class).in(billing).set(possiblePayments);
        billing.setPaymentStatus(PaymentStatus.NOT_PAID);
        billings.add(billing);

        List<Sale> sales = new ArrayList<Sale>();
        Grower grower = new Grower();
        Sale sale = new Sale(null, grower);
        sales.add(sale);

        field("paymentRegistrationServiceRunner").ofType(PaymentRegistrationServiceRunner.class).in(paymentRegistrationService).set(paymentRegistrationServiceRunner);
        field("billingDAO").ofType(BillingDAO.class).in(paymentRegistrationService).set(billingDAO);
        field("saleDAO").ofType(SaleDAO.class).in(paymentRegistrationService).set(saleDAO);
        field("accountManager").ofType(AccountManager.class).in(paymentRegistrationService).set(accountManager);
        field("industrySystemService").ofType(IndustrySystemService.class).in(paymentRegistrationService).set(industrySystemService);

        // @When
        when(paymentRegistrationServiceRunner.getPaymentsSapVcResponse()).thenReturn(payments);
        when(billingDAO.getByFilter(any(BillingFilter.class))).thenReturn(billings);
        when(saleDAO.findByPaymentBatchId(any(Long.class))).thenReturn(sales);
        when(saleDAO.getById(any(Long.class))).thenReturn(sale);
        SapPaidPayment sapPaidPayment = new SapPaidPayment(payment.getYlegalNumber(), SaleTemplatePaymentMethodEnum.BANK_SLIP, "12345678", new Date(), billings.get(0));
        when(sapPaymentFactory.build(payment, billings.get(0))).thenReturn(sapPaidPayment);

        paymentRegistrationService.updatePayments(paymentDate);

        //  @Should
        verify(paymentRegistrationServiceRunner).getPaymentsSapVcResponse();
        verify(billingDAO).getByFilter(any(BillingFilter.class));
        verify(saleDAO).findByPaymentBatchId(any(Long.class));
        verify(saleDAO).getById(any(Long.class));

    }

    @Test
    public void testUpdatePayments_WhenValidDateAndPaymentStatusIsNotPaidAndNotCooperative() throws Exception {
        // @Given
        Date paymentDate = new Date();

        List<YtyPymntAdvice> payments = new ArrayList<YtyPymntAdvice>();

        YtyPymntAdvice payment = new YtyPymntAdvice();
        payment.setYidTransVc("1");
        payment.setYpaidDate("1988-01-01");
        payment.setYsalesOrderType("NC");
        payment.setYstatus("PAGADO");
        payment.setYfiDoc("1");
        payments.add(payment);

        List<Billing> billings = new ArrayList<Billing>();
        Billing billing = new Billing();
        billing.setPaymentStatus(PaymentStatus.NOT_PAID);
        PossiblePayment possiblePayment = new PossiblePayment();
        possiblePayment.setPaidValue(new BigDecimal(1));
        Set<PossiblePayment> possiblePayments = new HashSet<PossiblePayment>();
        field("payments").ofType(Set.class).in(billing).set(possiblePayments);
        billing.setPaymentStatus(PaymentStatus.NOT_PAID);

        List<Sale> sales = new ArrayList<Sale>();
        Grower grower = new Grower();
        Sale sale = new Sale(null, grower);
        sale.setSaleType(Sale.SaleTypeEnum.RETAILER_SALE);
        SaleItem saleItem = new SaleItem();
        SaleTemplate saleTemplate = new SaleTemplate();
        saleTemplate.setIsTonsGenerator(Boolean.TRUE);
        saleItem.setSaleTemplate(saleTemplate);
        Set<SaleItem> saleItems = new LinkedHashSet<SaleItem>();
        saleItems.add(saleItem);
        sale.setItems(saleItems);
        Warehouse warehouse = new Warehouse();
        warehouse.setDescription("aaaa");
        sale.setWarehouse(warehouse);
        Customer customer = new Customer();
        customer.setId(1L);
        sale.setCustomer(customer);
        sales.add(sale);



        Billing billing1 = new Billing();
        billing.setPaymentStatus(PaymentStatus.NOT_PAID);
        SaleItem saleItem2 = new SaleItem();
        PossiblePayment possiblePayment1 = new PossiblePayment();
        field("receiptDate").ofType(Date.class).in(possiblePayment1).set(new Date());
        Set<PossiblePayment> possiblePayments1 = new HashSet<PossiblePayment>();
        possiblePayments.add(possiblePayment1);
        field("payments").ofType(Set.class).in(billing).set(possiblePayments);
        saleItem.setSoldQuantity(new Long(1));
        saleItem.setBilling(billing);
        saleTemplate.setIsTonsGenerator(false);
        saleItem.setSaleTemplate(saleTemplate);
        Set saleItemsSet = new HashSet<SaleItem>();
        saleItemsSet.add(saleItem);
        sale.setItems(saleItemsSet);

        billings.add(billing);


        field("paymentRegistrationServiceRunner").ofType(PaymentRegistrationServiceRunner.class).in(paymentRegistrationService).set(paymentRegistrationServiceRunner);
        field("billingDAO").ofType(BillingDAO.class).in(paymentRegistrationService).set(billingDAO);
        field("saleDAO").ofType(SaleDAO.class).in(paymentRegistrationService).set(saleDAO);
        field("accountManager").ofType(AccountManager.class).in(paymentRegistrationService).set(accountManager);
        field("industrySystemService").ofType(IndustrySystemService.class).in(paymentRegistrationService).set(industrySystemService);

        // @When
        when(paymentRegistrationServiceRunner.getPaymentsSapVcResponse()).thenReturn(payments);
        when(billingDAO.getByFilter(any(BillingFilter.class))).thenReturn(billings);
        when(saleDAO.findByPaymentBatchId(any(Long.class))).thenReturn(sales);
        when(saleDAO.getById(any(Long.class))).thenReturn(sale);
        SapPaidPayment sapPaidPayment = new SapPaidPayment(payment.getYlegalNumber(), SaleTemplatePaymentMethodEnum.BANK_SLIP,payment.getYfiDoc(),new Date(), billings.get(0));
        when(sapPaymentFactory.build(payment,billings.get(0))).thenReturn(sapPaidPayment);

        paymentRegistrationService.updatePayments(paymentDate);

        //  @Should
        verify(paymentRegistrationServiceRunner).getPaymentsSapVcResponse();
        verify(billingDAO).getByFilter(any(BillingFilter.class));
        verify(saleDAO, times(1)).getById(any(Long.class));

    }


    @Test
    public void testUpdateParaguayPayments_WhenSaleTypeIsPreCampainAndCountryNameParaguay() throws BusinessException {
        // @Given
        List<Billing> billings = getBillings();
        Sale sale = new Sale();
        Customer customer = new Customer();
        Address address = new Address();
        address.setCountry(new Country());
        field("address").ofType(Address.class).in(customer).set(address);
        customer.getCountry().setDescription(VCCountry.PARAGUAY.name());
        sale.setCustomer(customer);
        sale.setSaleType(Sale.SaleTypeEnum.PRE_CAMPAIGN);

        field("billingDAO").ofType(BillingDAO.class).in(paymentRegistrationService).set(billingDAO);
        field("saleDAO").ofType(SaleDAO.class).in(paymentRegistrationService).set(saleDAO);
        field("accountManager").ofType(AccountManager.class).in(paymentRegistrationService).set(accountManager);

        // @When
        when(billingDAO.getByPaymentStatusAndSaleType(any(PaymentStatus.class), any(Sale.SaleTypeEnum.class))).thenReturn(billings);
        when(saleDAO.getById(any(Long.class))).thenReturn(sale);
        paymentRegistrationService.updateParaguayPayments();

        // @Should
        verify(billingDAO).getByPaymentStatusAndSaleType(any(PaymentStatus.class), any(Sale.SaleTypeEnum.class));
        verify(saleDAO).getById(any(Long.class));

    }

    @Test
    public void testUpdateParaguayPayments_WhenSaleTypeIsPreCampainAndCountryNameParaguayAndGermoSupplierNotNullAndNoSaleItems() throws BusinessException {
        // @Given
        List<Billing> billings = getBillings();
        Sale sale = new Sale();
        Set<SaleItem> saleItems = getSaleItems();
        Customer customer = new Customer();
        customer.setId(1L);
        Grower grower = new Grower();
        grower.setId(1L);
        QuotaFY quotaFY = new QuotaFY();
        quotaFY.setBalance(new BigDecimal(1));
        quotaFY.setDeliveryBalance(new BigDecimal(1));
        quotaFY.setId(1L);
        Address address = new Address();
        address.setCountry(new Country());
        field("address").ofType(Address.class).in(customer).set(address);
        customer.getCountry().setDescription(VCCountry.PARAGUAY.name());
        sale.setCustomer(customer);
        sale.setSaleType(Sale.SaleTypeEnum.PRE_CAMPAIGN);
        Warehouse warehouse = new Warehouse();
        warehouse.setDescription("aaaa");
        sale.setWarehouse(warehouse);
        sale.setItems(saleItems);
        sale.setGrower(grower);
        sale.setSaleOrderSAPId(1L);

        field("billingDAO").ofType(BillingDAO.class).in(paymentRegistrationService).set(billingDAO);
        field("saleDAO").ofType(SaleDAO.class).in(paymentRegistrationService).set(saleDAO);
        field("accountManager").ofType(AccountManager.class).in(paymentRegistrationService).set(accountManager);
        field("quotaFYDAO").ofType(QuotaFYDAO.class).in(paymentRegistrationService).set(quotaFYDAO);
        field("quotaFYTransactionDAO").ofType(QuotaFYTransactionDAO.class).in(paymentRegistrationService).set(quotaFYTransactionDAO);

        // @When
        when(billingDAO.getByPaymentStatusAndSaleType(any(PaymentStatus.class), any(Sale.SaleTypeEnum.class))).thenReturn(billings);
        when(saleDAO.getById(any(Long.class))).thenReturn(sale);
        when(quotaFYDAO.selectBy(Matchers.<Long>any(), Matchers.<Long>any(), Matchers.<String>any())).thenReturn(quotaFY);

        paymentRegistrationService.updateParaguayPayments();

        // @Should
        verify(billingDAO).getByPaymentStatusAndSaleType(any(PaymentStatus.class), any(Sale.SaleTypeEnum.class));
       // verify(saleDAO).getById(any(Long.class));

    }

    @Test
    public void testUpdateParaguayPayments_WhenSaleTypeIsPreCampainAndCountryNameParaguayAndGermoSupplierNotNullAndSaleItems() throws BusinessException {
        // @Given
        List<Billing> billings = new ArrayList<Billing>();
        Customer customer = new Customer();
        field("id").ofType(Long.class).in(customer).set(new Long(25));
        Address address = new Address();
        address.setCountry(new Country());
        field("address").ofType(Address.class).in(customer).set(address);
        customer.getCountry().setDescription(VCCountry.PARAGUAY.name());
        Grower grower = new Grower();
        field("id").ofType(Long.class).in(grower).set(new Long(25));
        Sale sale = new Sale(customer, grower);
        field("id").ofType(Long.class).in(sale).set(new Long(25));
        sale.setSaleOrderSAPId(new Long(1));
        sale.setSaleType(Sale.SaleTypeEnum.PRE_CAMPAIGN);
        sale.setWarehouse(new Warehouse());
        Billing billing = new Billing();
        PossiblePayment possiblePayment = new PossiblePayment();
        possiblePayment.setPaidValue(new BigDecimal(1));
        Set<PossiblePayment> payments = new HashSet<PossiblePayment>();
        payments.add(possiblePayment);
        Set<SaleItem> saleItems = new HashSet<SaleItem>();
        SaleItem saleItem = new SaleItem();
        saleItem.setSoldQuantity(new Long(1));
        saleItem.setBilling(billing);
        saleItems.add(saleItem);
        field("payments").ofType(Set.class).in(billing).set(payments);
        field("items").ofType(Set.class).in(sale).set(saleItems);
        QuotaFY quotaFY = new QuotaFY();
        quotaFY.setBalance(new BigDecimal(1));
        quotaFY.setDeliveryBalance(new BigDecimal(1));
        QuotaFYPaid quotaFYPaid = new QuotaFYPaid();
        billings.add(billing);
        field("billingDAO").ofType(BillingDAO.class).in(paymentRegistrationService).set(billingDAO);
        field("saleDAO").ofType(SaleDAO.class).in(paymentRegistrationService).set(saleDAO);
        field("accountManager").ofType(AccountManager.class).in(paymentRegistrationService).set(accountManager);
        field("quotaFYDAO").ofType(QuotaFYDAO.class).in(paymentRegistrationService).set(quotaFYDAO);
        field("quotaFYTransactionDAO").ofType(QuotaFYTransactionDAO.class).in(paymentRegistrationService).set(quotaFYTransactionDAO);


        // @When
        when(billingDAO.getByPaymentStatusAndSaleType(any(PaymentStatus.class), any(Sale.SaleTypeEnum.class))).thenReturn(billings);
        when(saleDAO.getById(any(Long.class))).thenReturn(sale);
        when(quotaFYDAO.selectBy(any(Long.class), any(Long.class), any(String.class))).thenReturn(quotaFY);
        paymentRegistrationService.updateParaguayPayments();

        // @Should
        verify(billingDAO).getByPaymentStatusAndSaleType(any(PaymentStatus.class), any(Sale.SaleTypeEnum.class));
        verify(saleDAO, times(2)).getById(any(Long.class));
        verify(quotaFYDAO).selectBy(any(Long.class), any(Long.class), any(String.class));
    }


    @Test(expected = BillingConstraintViolationException.class)
    public void testUpdatePayments_WhenPaymentDateIsNull() throws BusinessException {
        Date paymentDate = null;
        paymentRegistrationService.updatePayments(paymentDate);
    }

    @Test(expected = BillingConstraintViolationException.class)
    public void testUpdatePayments_WhenPaymentDateIsFuture() throws BusinessException {
        Date aux = new Date();
        int year = aux.getYear() + 1;
        int month = aux.getMonth();
        int date = aux.getDate();
        Date paymentDate = new Date(year, month, date);

        paymentRegistrationService.updatePayments(paymentDate);
    }

    @Test(expected = BusinessException.class)
    public void testUpdateQuotaFromPayment_WhenSaleIsNull() throws BusinessException {
        // @Given
        field("saleDAO").ofType(SaleDAO.class).in(paymentRegistrationService).set(saleDAO);
        Sale sale = null;

        // @When
        when(saleDAO.getById(any(Long.class))).thenReturn(sale);
        paymentRegistrationService.updateQuotaFromPayment(any(Long.class));

        // @Should
    }

    @Test(expected = BusinessException.class)
    public void testUpdateQuotaFromPayment_WhenBillingCountPaymentsIsNotOne() throws BusinessException {
        // @Given
        field("saleDAO").ofType(SaleDAO.class).in(paymentRegistrationService).set(saleDAO);
        SaleItem saleItem = new SaleItem();
        Billing billing = new Billing();
        PossiblePayment possiblePayment1 = new PossiblePayment();
        field("receiptDate").ofType(Date.class).in(possiblePayment1).set(new Date());
        PossiblePayment possiblePayment2 = new PossiblePayment();
        Set<PossiblePayment> possiblePayments = new HashSet<PossiblePayment>();
        possiblePayments.add(possiblePayment1);
        possiblePayments.add(possiblePayment2);


        field("payments").ofType(Set.class).in(billing).set(possiblePayments);
        saleItem.setBilling(billing);
        Set saleItemsSet = new HashSet<SaleItem>();
        saleItemsSet.add(saleItem);
        Sale sale = new Sale();
        sale.setItems(saleItemsSet);
        sale.setWarehouse(new Warehouse());


        // @When
        when(saleDAO.getById(any(Long.class))).thenReturn(sale);
        paymentRegistrationService.updateQuotaFromPayment(any(Long.class));

        // @Should
    }

    @Test
    public void testUpdateQuotaFromPayment_WhenQuotaFYDAOThrowAnEntityNotFoundException() throws BusinessException {
        // @Given
        field("saleDAO").ofType(SaleDAO.class).in(paymentRegistrationService).set(saleDAO);
        field("quotaFYDAO").ofType(QuotaFYDAO.class).in(paymentRegistrationService).set(quotaFYDAO);
        field("germoSupplierLocationDAO").ofType(GermoSupplierLocationDAO.class).in(paymentRegistrationService).set(germoSupplierLocationDAO);
        field("quotaFYTransactionDAO").ofType(QuotaFYTransactionDAO.class).in(paymentRegistrationService).set(quotaFYTransactionDAO);
        field(("warehouseService")).ofType(WarehouseService.class).in(paymentRegistrationService).set(warehouseService);

        SaleItem saleItem = new SaleItem();
        Billing billing = new Billing();
        PossiblePayment possiblePayment1 = new PossiblePayment();
        field("receiptDate").ofType(Date.class).in(possiblePayment1).set(new Date());
        Set<PossiblePayment> possiblePayments = new HashSet<PossiblePayment>();
        possiblePayments.add(possiblePayment1);
        field("payments").ofType(Set.class).in(billing).set(possiblePayments);
        saleItem.setSoldQuantity(new Long(1));
        saleItem.setBilling(billing);
        Set saleItemsSet = new HashSet<SaleItem>();
        saleItemsSet.add(saleItem);

        Customer customer = new Customer();
        field("id").ofType(Long.class).in(customer).set(new Long(25));
        Grower grower = new Grower();
        BillingAddress billingAddress = new BillingAddress();
        Country country = new Country();
        country.setCode("XX");
        billingAddress.setCountry(country);
        grower.setBillingAddress(billingAddress);
        field("id").ofType(Long.class).in(grower).set(new Long(25));
        Sale sale = new Sale(customer, grower);
        sale.setItems(saleItemsSet);
        Warehouse warehouse = new Warehouse();
        warehouse.setDescription("qqqq");
        sale.setWarehouse(warehouse);
        sale.setSaleOrderSAPId(new Long(1));
        GermoSupplierLocation germoSupplierLocation = new GermoSupplierLocation();

        // @When
        when(saleDAO.getById(any(Long.class))).thenReturn(sale);
        when(quotaFYDAO.selectBy(any(Long.class), any(Long.class), any(String.class))).thenThrow(new EntityNotFoundException("Throwed EntityNotFoundException"));
        when(germoSupplierLocationDAO.selectBy(any(String.class), any(String.class))).thenReturn(germoSupplierLocation);
        when((warehouseService.selectBy(any(String.class), any(String.class)))).thenReturn(new Warehouse());
        paymentRegistrationService.updateQuotaFromPayment(any(Long.class));

        // @Should
    }

    private ServiceFeeProgram getServiceFeeProgramMock(){

        ServiceFeeProgram serviceFeeProgram = new ServiceFeeProgram();
        serviceFeeProgram.setId(1L);
        serviceFeeProgram.setCode("RETAILER");
        serviceFeeProgram.setName("Retailer");

        return serviceFeeProgram;
    }

}
