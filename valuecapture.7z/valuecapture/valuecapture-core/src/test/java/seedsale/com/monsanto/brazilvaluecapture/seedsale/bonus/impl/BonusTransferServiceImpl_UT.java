package com.monsanto.brazilvaluecapture.seedsale.bonus.impl;

import com.monsanto.brazilvaluecapture.core.foundation.service.BusinessException;
import com.monsanto.brazilvaluecapture.core.grower.model.bean.Grower;
import com.monsanto.brazilvaluecapture.core.grower.model.dao.AgreementDAO;
import com.monsanto.brazilvaluecapture.seedsale.bonus.BonusService;
import com.monsanto.brazilvaluecapture.seedsale.bonus.bulkimport.model.bean.BonusAccount;
import com.monsanto.brazilvaluecapture.seedsale.bonus.transfer.bean.BonusTransfer;
import com.monsanto.brazilvaluecapture.seedsale.bonus.transfer.bean.BonusTransferItem;
import com.monsanto.brazilvaluecapture.seedsale.bonus.transfer.bean.BonusTransferStateEnum;
import com.monsanto.brazilvaluecapture.seedsale.bonus.transfer.dao.impl.BonusTranferDAOImpl;
import com.monsanto.brazilvaluecapture.seedsale.bonus.transfer.service.BonusTransferService;
import com.monsanto.brazilvaluecapture.seedsale.bonus.transfer.service.impl.BonusTransferServiceImpl;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.List;

import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class BonusTransferServiceImpl_UT {

    @Mock
    private BonusTranferDAOImpl bonusTranferDAO;

    @Mock
    private BonusService bonusService;

    @Mock
    private AgreementDAO agreementDAO;

    @InjectMocks
    private BonusTransferService bonusTransferService = new BonusTransferServiceImpl();

    @Test
    public void when_approve_bonus_transfer_state_is_approved() throws BusinessException {
        //@Given
        BonusTransfer bonusTransfer = new BonusTransfer();
        bonusTransfer.setState(BonusTransferStateEnum.PENDING_APPROVAL);
        List<BonusTransferItem> bonusTransferItems = new ArrayList<BonusTransferItem>();
        bonusTransfer.setBonusTransferItems(bonusTransferItems);
        Grower grower = new Grower();
        when(agreementDAO.selectByGrower(bonusTransfer.getToGrower())).thenReturn(grower);

        //@When
        bonusTransferService.approveBonusTransfer(bonusTransfer);

        //@Should
        verify(bonusTranferDAO).createOrUpdate(bonusTransfer);
    }

    @Test
    public void when_reprove_bonus_transfer_state_is_reproved() throws BusinessException {
        //@Given
        BonusTransfer bonusTransfer = new BonusTransfer();
        List<BonusTransferItem> bonusTransferItems = new ArrayList<BonusTransferItem>();
        BonusTransferItem bonusTransferItem = new BonusTransferItem();
        BonusAccount bonusAccount = new BonusAccount();
        bonusTransferItem.setFromBonusAccount(bonusAccount);
        bonusTransferItems.add(bonusTransferItem);

        bonusTransfer.setBonusTransferItems(bonusTransferItems);
        bonusTransfer.setState(BonusTransferStateEnum.PENDING_APPROVAL);
        when(bonusTranferDAO.findById(bonusTransfer.getId())).thenReturn(bonusTransfer);

        //@When
        bonusTransferService.reproveBonusTransfer(bonusTransfer, null);

        //@Should
        verify(bonusTranferDAO).createOrUpdate(bonusTransfer);
    }
}
