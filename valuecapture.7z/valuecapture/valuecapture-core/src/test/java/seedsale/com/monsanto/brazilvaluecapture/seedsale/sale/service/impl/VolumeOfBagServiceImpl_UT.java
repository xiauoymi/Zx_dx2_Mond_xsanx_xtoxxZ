package com.monsanto.brazilvaluecapture.seedsale.sale.service.impl;

import com.monsanto.brazilvaluecapture.pod.rol.model.bean.VolumeOfBag;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.dao.SaleDAO;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.dao.VolumeOfBagDAO;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.dao.impl.VolumeOfBagDAOImpl;
import junit.framework.Assert;
import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;

import static org.fest.reflect.core.Reflection.field;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class VolumeOfBagServiceImpl_UT {

    private VolumeOfBagServiceImpl volumeOfBagServiceImpl;
    private VolumeOfBagDAO volumeOfBagDAO;

    @Before
    public void setUp(){
        this.volumeOfBagServiceImpl = new VolumeOfBagServiceImpl();
        this.volumeOfBagDAO = mock(VolumeOfBagDAO.class);

        field("volumeOfBagDAO").ofType(VolumeOfBagDAO.class).in(this.volumeOfBagServiceImpl).set(this.volumeOfBagDAO);

        when(this.volumeOfBagServiceImpl.getAll()).thenReturn(new ArrayList<VolumeOfBag>());
    }

    @Test
    public void testGetAllVolumeOfBag(){
        Assert.assertNotNull(this.volumeOfBagServiceImpl.getAll());
    }
}