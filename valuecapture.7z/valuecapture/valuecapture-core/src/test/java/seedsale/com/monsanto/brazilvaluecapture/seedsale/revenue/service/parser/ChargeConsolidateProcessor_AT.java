package com.monsanto.brazilvaluecapture.seedsale.revenue.service.parser;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import junit.framework.Assert;

import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.monsanto.brazilvaluecapture.core.base.SystemTestFixture;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Company;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Crop;
import com.monsanto.brazilvaluecapture.core.base.model.bean.OperationalYear;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Contract;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Customer;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.HeadOffice;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.ParticipantTypeEnum;
import com.monsanto.brazilvaluecapture.core.customer.service.ContractNotFoundException;
import com.monsanto.brazilvaluecapture.core.foundation.service.BusinessException;
import com.monsanto.brazilvaluecapture.core.foundation.service.EntityAlreadyExistException;
import com.monsanto.brazilvaluecapture.core.foundation.test.AbstractServiceIntegrationTests;
import com.monsanto.brazilvaluecapture.core.foundation.test.dbunit.DbUnitHelper;
import com.monsanto.brazilvaluecapture.core.io.ProcessorConfig;
import com.monsanto.brazilvaluecapture.core.io.WarningImportedException;
import com.monsanto.brazilvaluecapture.core.io.ProcessorConfig.ProcessorConfigProperties;
import com.monsanto.brazilvaluecapture.core.revenue.model.bean.ChargeConsolidate;
import com.monsanto.brazilvaluecapture.core.revenue.model.bean.ChargeConsolidateFilter;
import com.monsanto.brazilvaluecapture.core.revenue.model.bean.ChargeConsolidateOrigin;
import com.monsanto.brazilvaluecapture.core.revenue.model.bean.ChargeConsolidateType;
import com.monsanto.brazilvaluecapture.core.revenue.model.bean.ChargeConsolidateTypeEnum;
import com.monsanto.brazilvaluecapture.core.revenue.model.bean.ChargeGroupStatus;
import com.monsanto.brazilvaluecapture.core.revenue.model.bean.CompanyCropAccountNumber;
import com.monsanto.brazilvaluecapture.core.revenue.service.ChargeConsolidateConstraintException;
import com.monsanto.brazilvaluecapture.core.user.AccessControlTestFixture;
import com.monsanto.brazilvaluecapture.seedsale.chargeconsolidate.model.bean.ChargeConsolidateImportDTO;
import com.monsanto.brazilvaluecapture.seedsale.sale.SaleTestFixture;

public class ChargeConsolidateProcessor_AT extends AbstractServiceIntegrationTests {
    private Locale locale = new Locale("pt", "BR");

    @Autowired
    private ChargeConsolidateProcessor chargeConsolidateProcessor;

    @Autowired
    private ChargeConsolidateImportParser chargeConsolidateParser;

    private ChargeConsolidateCSVReader csvReader;

    private ProcessorConfig processorConfig = new ProcessorConfig();

    @Before
    public void init() {
        systemTestFixture = new SystemTestFixture(this);
        saleTestFixture = new SaleTestFixture(this, systemTestFixture);
        accessControlTestFixture = new AccessControlTestFixture(this, systemTestFixture);

        accessControlTestFixture.userAdminOfMonsantoBr.setContextCrop(systemTestFixture.soyMons4nto);
        accessControlTestFixture.userAdminOfMonsantoBr.setContextCompany(systemTestFixture.mons4ntoBr);

        csvReader = new ChargeConsolidateCSVReader(accessControlTestFixture.userAdminOfMonsantoBr);
        processorConfig.put(ProcessorConfigProperties.LOGGED_USER, accessControlTestFixture.userAdminOfMonsantoBr);
        processorConfig.put(ProcessorConfigProperties.SELECTED_LOCALE, locale);
        processorConfig.put(ProcessorConfigProperties.DTO, new ChargeConsolidateImportDTO());
    }

    @Test
    public void sanity_check() {
        Assert.assertNotNull("Charge consolidate processor should be available em application context",
                chargeConsolidateProcessor);
    }

    @Test
    public void given_null_file_should_validate_empty_file() throws IOException, BusinessException {
        StringBuffer csvFile = createCsvLine(null);
        ChargeConsolidateImportedFile file = csvReader.readFile(toInputStream(csvFile), locale);

        assertFile(file, 0, 0, 1, 1, 0);
    }

    @Test
    public void given_valid_values_should_build_a_chargeConsolidateImportLine_successfully() throws IOException,
            BusinessException {
        StringBuffer csvFile = createCsvLine(null, "CNPJ", "777777777", "", "", "SAFRINHA", "MODELO DE VENDA", "6",
                "2012", "20", "400");
        ChargeConsolidateImportedFile file = csvReader.readFile(toInputStream(csvFile), locale);

        assertFile(file, 0, 0, 1, 0, 1);
    }

    @Test
    public void given_valid_csv_with_empty_column_values_when_parse_should_have_import_with_one_warning_lines()
            throws IOException, BusinessException {
        StringBuffer csvFile = createCsvLine(null, "", "", "", "", "", "", "", "", "", "");
        ChargeConsolidateImportedFile file = chargeConsolidateProcessor.read(toInputStream(csvFile), processorConfig);

        assertFile(file, 0, 0, 1, 1, 1);
    }

    @Test
    public void given_csvLine_with_empty_documentType_should_add_warning_to_file() {
        ChargeConsolidateImportedLine importedLine = createImportedLine("", "123456789", BigDecimal.TEN, "harvest",
                "10", "2012", "sale template", BigDecimal.TEN, "", "");
        ArrayList<ChargeConsolidateImportedLine> lines = createImportedLinesList(importedLine);
        ChargeConsolidateImportedFile importedFile = createNewImportedFile(lines, ChargeConsolidateOrigin.SALE, false);

        chargeConsolidateParser.proccessFile(importedFile);

        assertFile(importedFile, 0, 0, 0, 1, 1);
    }

    @Test
    public void given_csvLine_with_empty_document_should_add_warning_to_file() {
        ChargeConsolidateImportedLine importedLine = createImportedLine("CNPJ", "", BigDecimal.TEN, "harvest", "10",
                "2012", "sale template", BigDecimal.TEN, "", "");
        ArrayList<ChargeConsolidateImportedLine> lines = createImportedLinesList(importedLine);
        ChargeConsolidateImportedFile importedFile = createNewImportedFile(lines, ChargeConsolidateOrigin.SALE, false);

        chargeConsolidateParser.proccessFile(importedFile);

        assertFile(importedFile, 0, 0, 0, 1, 1);
    }

    @Test
    public void given_csvLine_with_empty_harvest_and_originSale_should_add_warning_to_file() {
        ChargeConsolidateImportedLine importedLine = createImportedLine("CNPJ", "123456", BigDecimal.TEN, "", "10",
                "2012", "sale template", BigDecimal.TEN, "", "");
        ArrayList<ChargeConsolidateImportedLine> lines = createImportedLinesList(importedLine);
        ChargeConsolidateImportedFile importedFile = createNewImportedFile(lines, ChargeConsolidateOrigin.SALE, false);

        chargeConsolidateParser.proccessFile(importedFile);

        assertFile(importedFile, 0, 0, 0, 1, 1);
    }

    @Test
    public void given_csvLine_with_empty_month_and_originGrainReceive_should_add_warning_to_file() {
        ChargeConsolidateImportedLine importedLine = createImportedLine("CNPJ", "123456", BigDecimal.TEN, "harvest",
                "", "2012", "sale template", BigDecimal.TEN, "", "");
        ArrayList<ChargeConsolidateImportedLine> lines = createImportedLinesList(importedLine);
        ChargeConsolidateImportedFile importedFile = createNewImportedFile(lines, ChargeConsolidateOrigin.GRAINRECEIVE,
                false);

        chargeConsolidateParser.proccessFile(importedFile);

        assertFile(importedFile, 0, 0, 0, 1, 1);
    }

    @Test
    public void given_csvLine_with_empty_operationalYear_should_add_warning_to_file() {
        ChargeConsolidateImportedLine importedLine = createImportedLine("CNPJ", "123456", BigDecimal.TEN, "harvest",
                "10", "", "sale template", BigDecimal.TEN, "", "");
        ArrayList<ChargeConsolidateImportedLine> lines = createImportedLinesList(importedLine);
        ChargeConsolidateImportedFile importedFile = createNewImportedFile(lines, ChargeConsolidateOrigin.SALE, false);

        chargeConsolidateParser.proccessFile(importedFile);

        assertFile(importedFile, 0, 0, 0, 1, 1);
    }

    @Test
    public void given_csvLine_with_empty_saleTemplate_and_originSale_should_add_warning_to_file() {
        ChargeConsolidateImportedLine importedLine = createImportedLine("CNPJ", "123456", BigDecimal.TEN, "harvest",
                "10", "2012", "", BigDecimal.TEN, "", "");
        ArrayList<ChargeConsolidateImportedLine> lines = createImportedLinesList(importedLine);
        ChargeConsolidateImportedFile importedFile = createNewImportedFile(lines, ChargeConsolidateOrigin.SALE, false);

        chargeConsolidateParser.proccessFile(importedFile);

        assertFile(importedFile, 0, 0, 0, 1, 1);
    }

    @Test
    public void given_csvLine_with_empty_value_should_add_warning_to_file() {
        ChargeConsolidateImportedLine importedLine = createImportedLine("CNPJ", "123456", BigDecimal.TEN, "harvest",
                "10", "2012", "sale template", null, "", "");
        ArrayList<ChargeConsolidateImportedLine> lines = createImportedLinesList(importedLine);
        ChargeConsolidateImportedFile importedFile = createNewImportedFile(lines, ChargeConsolidateOrigin.SALE, false);

        chargeConsolidateParser.proccessFile(importedFile);

        assertFile(importedFile, 0, 0, 0, 1, 1);
    }

    @Test
    public void given_csvLine_with_negative_value_should_add_warning_to_file() {
        ChargeConsolidateImportedLine importedLine = createImportedLine("CNPJ", "123456", BigDecimal.TEN, "harvest",
                "10", "2012", "sale template", new BigDecimal("-3"), "", "");
        ArrayList<ChargeConsolidateImportedLine> lines = createImportedLinesList(importedLine);
        ChargeConsolidateImportedFile importedFile = createNewImportedFile(lines, ChargeConsolidateOrigin.SALE, true);

        chargeConsolidateParser.proccessFile(importedFile);

        assertFile(importedFile, 0, 0, 0, 1, 1);
    }

    @Test
    public void given_csvLine_with_zero_value_and_overwrite_false_should_add_warning_to_file() {
        ChargeConsolidateImportedLine importedLine = createImportedLine("CNPJ", "123456", BigDecimal.TEN, "harvest",
                "10", "2012", "sale template", BigDecimal.ZERO, "", "");
        ArrayList<ChargeConsolidateImportedLine> lines = createImportedLinesList(importedLine);
        ChargeConsolidateImportedFile importedFile = createNewImportedFile(lines, ChargeConsolidateOrigin.SALE, false);

        chargeConsolidateParser.proccessFile(importedFile);

        assertFile(importedFile, 0, 0, 0, 1, 1);
    }

    @Test
    public void given_csvLine_with_zero_chargePercentage_should_add_warning_to_file() {
        ChargeConsolidateImportedLine importedLine = createImportedLine("CNPJ", "123456", BigDecimal.ZERO, "harvest",
                "10", "2012", "sale template", BigDecimal.TEN, "", "");
        ArrayList<ChargeConsolidateImportedLine> lines = createImportedLinesList(importedLine);
        ChargeConsolidateImportedFile importedFile = createNewImportedFile(lines, ChargeConsolidateOrigin.SALE, false);

        chargeConsolidateParser.proccessFile(importedFile);

        assertFile(importedFile, 0, 0, 0, 1, 1);
    }

    @Test
    public void given_csvLine_with_inexistent_documentType_when_parse_should_add_warning_to_file() {
        ChargeConsolidateImportedLine importedLine = createImportedLine("INVALID", "123456", BigDecimal.TEN, "harvest",
                "10", systemTestFixture.operationalYearOf2011.getYear(), "sale template", BigDecimal.TEN, "", "");
        ArrayList<ChargeConsolidateImportedLine> lines = createImportedLinesList(importedLine);
        ChargeConsolidateImportedFile importedFile = createNewImportedFile(lines, ChargeConsolidateOrigin.SALE, false);

        chargeConsolidateParser.proccessFile(importedFile);

        assertFile(importedFile, 0, 0, 0, 1, 1);
    }

    @Test
    public void given_csvLine_with_invalidDocumentNumber_when_parse_should_add_warning() {
        ChargeConsolidateImportedLine importedLine = createImportedLine("CNPJ", "123456", BigDecimal.TEN, "harvest",
                "10", systemTestFixture.operationalYearOf2011.getYear(), "sale template", BigDecimal.TEN, "", "");
        ArrayList<ChargeConsolidateImportedLine> lines = createImportedLinesList(importedLine);
        ChargeConsolidateImportedFile importedFile = createNewImportedFile(lines, ChargeConsolidateOrigin.SALE, false);

        chargeConsolidateParser.proccessFile(importedFile);

        assertFile(importedFile, 0, 0, 0, 1, 1);
    }

    @Test
    public void given_csvLine_with_inexistentCustomer_when_parse_should_add_warning() {
        ChargeConsolidateImportedLine importedLine = createImportedLine("CNPJ", "48521737000186", BigDecimal.TEN,
                "harvest", "10", systemTestFixture.operationalYearOf2011.getYear(), "sale template", BigDecimal.TEN,
                "", "");
        ArrayList<ChargeConsolidateImportedLine> lines = createImportedLinesList(importedLine);
        ChargeConsolidateImportedFile importedFile = createNewImportedFile(lines, ChargeConsolidateOrigin.SALE, false);

        chargeConsolidateParser.proccessFile(importedFile);

        assertFile(importedFile, 0, 0, 0, 1, 1);
    }

    @Test
    public void given_csvLine_with_inexistentOperationalYear_when_parse_should_add_warning() {
        ChargeConsolidateImportedLine importedLine = createImportedLine("CNPJ",
                saleTestFixture.matrixMons4nto.getDocumentValue(), BigDecimal.TEN, "harvest", "10", "23451325",
                "sale template", BigDecimal.TEN, saleTestFixture.matrixMons4nto.getCustomerSAPCode(), "");
        ArrayList<ChargeConsolidateImportedLine> lines = createImportedLinesList(importedLine);
        ChargeConsolidateImportedFile importedFile = createNewImportedFile(lines, ChargeConsolidateOrigin.SALE, false);

        chargeConsolidateParser.proccessFile(importedFile);

        assertFile(importedFile, 0, 0, 0, 1, 1);
    }

    @Test
    public void given_csvLine_with_inexistentHarvest_when_parse_should_add_warning() {
        ChargeConsolidateImportedLine importedLine = createImportedLine("CNPJ",
                saleTestFixture.matrixMons4nto.getDocumentValue(), BigDecimal.TEN, "harvest", "10",
                systemTestFixture.operationalYearOf2011.getYear(), "sale template", BigDecimal.TEN,
                saleTestFixture.matrixMons4nto.getCustomerSAPCode(), "");
        ArrayList<ChargeConsolidateImportedLine> lines = createImportedLinesList(importedLine);
        ChargeConsolidateImportedFile importedFile = createNewImportedFile(lines, ChargeConsolidateOrigin.SALE, false);

        chargeConsolidateParser.proccessFile(importedFile);

        assertFile(importedFile, 0, 0, 0, 1, 1);
    }

    @Test
    public void given_csvLine_with_inexistentSaleTemplate_when_parse_should_add_warning() {
        ChargeConsolidateImportedLine importedLine = createImportedLine("CNPJ",
                saleTestFixture.matrixMons4nto.getDocumentValue(), BigDecimal.TEN,
                saleTestFixture.harvestSoyMons4nto2012.getDescription(), "10",
                systemTestFixture.operationalYearOf2012.getYear(), "sale template", BigDecimal.TEN, "", "");
        ArrayList<ChargeConsolidateImportedLine> lines = createImportedLinesList(importedLine);
        ChargeConsolidateImportedFile importedFile = createNewImportedFile(lines, ChargeConsolidateOrigin.SALE, false);

        chargeConsolidateParser.proccessFile(importedFile);

        assertFile(importedFile, 0, 0, 0, 1, 1);
    }

    @Test
    public void given_csvLine_with_invalidMonth_when_parse_should_add_warning() {
        ChargeConsolidateImportedLine importedLine = createImportedLine("CNPJ",
                saleTestFixture.matrixMons4nto.getDocumentValue(), BigDecimal.TEN,
                saleTestFixture.harvestSoyMons4nto2012.getDescription(), "13",
                systemTestFixture.operationalYearOf2012.getYear(),
                saleTestFixture.templateIntactaMons4nto.getDescription(), BigDecimal.TEN, "", "");
        ArrayList<ChargeConsolidateImportedLine> lines = createImportedLinesList(importedLine);
        ChargeConsolidateImportedFile importedFile = createNewImportedFile(lines, ChargeConsolidateOrigin.SALE, false);

        chargeConsolidateParser.proccessFile(importedFile);

        assertFile(importedFile, 0, 0, 0, 1, 1);
    }

    @Test
    public void given_csvLine_with_month_and_year_out_period_when_parse_should_add_warning() {
        ChargeConsolidateImportedLine importedLine = createImportedLine("CNPJ",
                saleTestFixture.matrixMons4nto.getDocumentValue(), BigDecimal.TEN,
                saleTestFixture.harvestSoyMons4nto2012.getDescription(), "12",
                systemTestFixture.operationalYearOf2012.getYear(),
                saleTestFixture.templateIntactaMons4nto.getDescription(), BigDecimal.TEN, "", "");
        ArrayList<ChargeConsolidateImportedLine> lines = createImportedLinesList(importedLine);
        ChargeConsolidateImportedFile importedFile = createNewImportedFile(lines, ChargeConsolidateOrigin.GRAINRECEIVE,
                false);

        ChargeConsolidateImportDTO dto = importedFile.getImportDTO();
        dto.setInitialMonth(Calendar.JANUARY);
        dto.setInitialYear(2008);
        dto.setFinalMonth(Calendar.JULY);
        dto.setFinalYear(2008);
        importedFile.setChargeConsolidateImportDTO(dto);

        // my date is 12/2008

        chargeConsolidateParser.proccessFile(importedFile);

        assertFile(importedFile, 0, 0, 0, 1, 1);
    }

    @Test
    public void given_csvLine_with_month_and_year_equals_period_when_parse_should_have_no_warnings() {
        ChargeConsolidateImportedLine importedLine = createImportedLine("CNPJ",
                saleTestFixture.matrixMons4nto.getDocumentValue(), BigDecimal.TEN,
                saleTestFixture.harvestSoyMons4nto2012.getDescription(), "07",
                systemTestFixture.operationalYearOf2012.getYear(),
                saleTestFixture.templateIntactaMons4nto.getDescription(), BigDecimal.TEN, "", "");
        ArrayList<ChargeConsolidateImportedLine> lines = createImportedLinesList(importedLine);
        ChargeConsolidateImportedFile importedFile = createNewImportedFile(lines, ChargeConsolidateOrigin.GRAINRECEIVE,
                false);

        ChargeConsolidateImportDTO dto = importedFile.getImportDTO();
        dto.setInitialMonth(Calendar.JULY);
        dto.setInitialYear(2012);
        dto.setFinalMonth(Calendar.JULY);
        dto.setFinalYear(2012);
        importedFile.setChargeConsolidateImportDTO(dto);

        // my date is 07/2012

        chargeConsolidateParser.proccessFile(importedFile);

        assertFile(importedFile, 1, 0, 0, 0, 1);
    }

    @Test
    public void given_csvLine_with_month_and_year_before_period_when_parse_should_add_warning() {
        ChargeConsolidateImportedLine importedLine = createImportedLine("CNPJ",
                saleTestFixture.matrixMons4nto.getDocumentValue(), BigDecimal.TEN,
                saleTestFixture.harvestSoyMons4nto2012.getDescription(), "02",
                systemTestFixture.operationalYearOf2012.getYear(),
                saleTestFixture.templateIntactaMons4nto.getDescription(), BigDecimal.TEN, "", "");
        ArrayList<ChargeConsolidateImportedLine> lines = createImportedLinesList(importedLine);
        ChargeConsolidateImportedFile importedFile = createNewImportedFile(lines, ChargeConsolidateOrigin.GRAINRECEIVE,
                false);

        ChargeConsolidateImportDTO dto = importedFile.getImportDTO();
        dto.setInitialMonth(Calendar.JULY);
        dto.setInitialYear(2008);
        dto.setFinalMonth(Calendar.DECEMBER);
        dto.setFinalYear(2008);
        importedFile.setChargeConsolidateImportDTO(dto);

        // my date is 02/2008

        chargeConsolidateParser.proccessFile(importedFile);

        assertFile(importedFile, 0, 0, 0, 1, 1);
    }

    @Test
    public void given_twoDuplicatedCsvLines_byHarvest_and_originSale_should_add_warning() {
        ChargeConsolidateImportedLine line1 = createImportedLine("CNPJ",
                saleTestFixture.matrixMons4nto.getDocumentValue(), BigDecimal.TEN,
                saleTestFixture.harvestSoyMons4nto2012.getDescription(), "11",
                systemTestFixture.operationalYearOf2012.getYear(),
                saleTestFixture.templateIntactaMons4nto.getDescription(), BigDecimal.TEN, "", "");
        ChargeConsolidateImportedLine line2 = createImportedLine("CNPJ",
                saleTestFixture.matrixMons4nto.getDocumentValue(), BigDecimal.TEN,
                saleTestFixture.harvestSoyMons4nto2012.getDescription(), "11",
                systemTestFixture.operationalYearOf2012.getYear(),
                saleTestFixture.templateIntactaMons4nto.getDescription(), BigDecimal.TEN, "", "");
        ArrayList<ChargeConsolidateImportedLine> lines = createImportedLinesList(line1, line2);
        ChargeConsolidateImportedFile importedFile = createNewImportedFile(lines, ChargeConsolidateOrigin.SALE, false);

        chargeConsolidateParser.proccessFile(importedFile);
        assertFile(importedFile, 1, 0, 0, 1, 2);
    }

    @Test
    public void given_twoDuplicatedCsvLines_byMonth_and_originGrainReceive_should_add_warning() {
        ChargeConsolidateImportedLine line1 = createImportedLine("CNPJ",
                saleTestFixture.matrixMons4nto.getDocumentValue(), BigDecimal.TEN,
                saleTestFixture.harvestSoyMons4nto2012.getDescription(), "11",
                systemTestFixture.operationalYearOf2012.getYear(),
                saleTestFixture.templateIntactaMons4nto.getDescription(), BigDecimal.TEN, "", "");
        ChargeConsolidateImportedLine line2 = createImportedLine("CNPJ",
                saleTestFixture.matrixMons4nto.getDocumentValue(), BigDecimal.TEN,
                saleTestFixture.harvestSoyMons4nto2012.getDescription(), "11",
                systemTestFixture.operationalYearOf2012.getYear(),
                saleTestFixture.templateIntactaMons4nto.getDescription(), BigDecimal.TEN, "", "");
        ArrayList<ChargeConsolidateImportedLine> lines = createImportedLinesList(line1, line2);
        ChargeConsolidateImportedFile importedFile = createNewImportedFile(lines, ChargeConsolidateOrigin.GRAINRECEIVE,
                false);
        importedFile.getImportDTO().setInitialYear(2012);
        importedFile.getImportDTO().setFinalYear(2012);

        chargeConsolidateParser.proccessFile(importedFile);
        assertFile(importedFile, 1, 0, 0, 1, 2);
    }

    @Test
    public void given_csvLine_when_saleTemplateNotAssociatedWithHeadOffice_should_have_one_warning() {
        ChargeConsolidateImportedLine line1 = createImportedLine("CNPJ",
                saleTestFixture.matrixMons4nto.getDocumentValue(), BigDecimal.TEN,
                saleTestFixture.harvestSoyMons4nto2012.getDescription(), "11",
                systemTestFixture.operationalYearOf2012.getYear(),
                saleTestFixture.templateIntactaMons4nto.getDescription(), BigDecimal.TEN, "", "");
        ArrayList<ChargeConsolidateImportedLine> lines = createImportedLinesList(line1);
        ChargeConsolidateImportedFile importedFile = createNewImportedFile(lines, ChargeConsolidateOrigin.SALE, false);

        saleTestFixture.templateIntactaMons4nto.setHeadOffices(null);
        saveAndFlush(saleTestFixture.templateIntactaMons4nto);

        chargeConsolidateParser.proccessFile(importedFile);
        assertFile(importedFile, 0, 0, 0, 1, 1);
    }

    @Test
    public void given_csvLinet_with_paidChargeConsolidate_when_processLine_should_add_warning()
            throws ChargeConsolidateConstraintException, ContractNotFoundException, EntityAlreadyExistException {
        setupDBUnit();
        updateContractsToRunInTestEnv();
        createChargeConsolidate(ChargeGroupStatus.PROCESSED);

        Customer customer = (Customer) getSession().get(Customer.class, 999000010L);
        Contract contract = customer.getContracts().iterator().next();

        accessControlTestFixture.userAdminOfMonsantoBr.setContextCompany(contract.getCompany());
        accessControlTestFixture.userAdminOfMonsantoBr.setContextCrop(contract.getCrop());
        createTemplateAssociations(contract);
        prepareHarvest("FILE_UPLOAD_HARVEST");
        ChargeConsolidateImportedLine line1 = createImportedLine("_CNPJ_", "232222123", BigDecimal.TEN,
                "FILE_UPLOAD_HARVEST", "", "2110", saleTestFixture.templateIntactaMons4nto.getDescription(),
                BigDecimal.TEN, "", "");
        ArrayList<ChargeConsolidateImportedLine> lines = createImportedLinesList(line1);
        ChargeConsolidateImportedFile importedFile = createNewImportedFile(lines, ChargeConsolidateOrigin.SALE, true);

        chargeConsolidateParser.proccessFile(importedFile);
        assertFile(importedFile, 0, 0, 0, 1, 1);
    }

    @Test
    public void given_validCsvLine_when_write_should_proccessLine_successfully_and_createChargeConsolidate()
            throws WarningImportedException {
        setupDBUnit();
        updateContractsToRunInTestEnv();

        ChargeConsolidateImportDTO dto = new ChargeConsolidateImportDTO();
        dto.setOverwriteCharge(Boolean.FALSE);
        dto.setChargeConsOriginCode(ChargeConsolidateOrigin.SALE);
        dto.setChargeConsTypeCode(ChargeConsolidateTypeEnum.SALEREGISTERCHARGE);
        Customer customer = (Customer) getSession().get(Customer.class, 999000010L);
        Contract contract = customer.getContracts().iterator().next();

        accessControlTestFixture.userAdminOfMonsantoBr.setContextCompany(contract.getCompany());
        accessControlTestFixture.userAdminOfMonsantoBr.setContextCrop(contract.getCrop());
        createTemplateAssociations(contract);
        prepareHarvest("_HARVEST_");
        ChargeConsolidateImportedLine line1 = new ChargeConsolidateImportedLine();
        line1.setCustomer(customer);
        line1.setHarvest(saleTestFixture.harvestSoyMons4nto2012);
        line1.setSaleTemplate(saleTestFixture.templateIntactaMons4nto);
        line1.setOperationalYear(saleTestFixture.harvestSoyMons4nto2012.getOperationalYear());
        line1.setMonth(10);
        line1.setChargePercentage(BigDecimal.TEN);
        line1.setValue(BigDecimal.TEN);
        ArrayList<ChargeConsolidateImportedLine> lines = createImportedLinesList(line1);
        ChargeConsolidateImportedFile importedFile = createNewImportedFile(lines, ChargeConsolidateOrigin.SALE, false);

        processorConfig.put(ProcessorConfigProperties.DTO, dto);

        importedFile.add(line1);
        chargeConsolidateProcessor.write(importedFile, processorConfig);

        assertFile(importedFile, 1, 0, 0, 0, 1);
    }

    private void prepareHarvest(String harvestDescription) {
        saleTestFixture.harvestSoyMons4nto2012.setOperationalYear((OperationalYear) getSession().get(
                OperationalYear.class, 900000001L));
        saleTestFixture.harvestSoyMons4nto2012.setDescription(harvestDescription);
        saveAndFlush(saleTestFixture.harvestSoyMons4nto2012);
    }

    private void createTemplateAssociations(Contract contract) {
        HeadOffice headOffice = (HeadOffice) getSession().get(HeadOffice.class, 999000010L);
        saleTestFixture.templateIntactaMons4nto.addHeadOffice(headOffice);
        saveAndFlush(saleTestFixture.templateIntactaMons4nto);
    }

    private void createChargeConsolidate(ChargeGroupStatus chargeStatus) throws ContractNotFoundException,
            EntityAlreadyExistException, ChargeConsolidateConstraintException {

        Customer customer = (Customer) getSession().get(Customer.class, 999000010L);
        OperationalYear operationalYear = (OperationalYear) getSession().get(OperationalYear.class, 900000001L);
        Contract contract = customer.getContracts().iterator().next();

        Company company = contract.getCompany();
        Crop crop = contract.getCrop();

        contract = Customer.selectContractsInVigorFromBy(customer.getContracts(), company, crop,
                ParticipantTypeEnum.DISTRIBUTOR, customer.getId());

        chargeConsolidateService.createChargeConsolidate("FILE_UPLOAD_HARVEST", customer, ChargeConsolidateOrigin.SALE,
                ChargeConsolidateTypeEnum.SALEREGISTERCHARGE, operationalYear, null, contract.getCompany(),
                contract.getCrop(), false, BigDecimal.TEN, null);

        ChargeConsolidateFilter filter = new ChargeConsolidateFilter();
        filter.setHarvest("FILE_UPLOAD_HARVEST");
        List<ChargeConsolidate> list = chargeConsolidateService.findCreditConsumptionChargeConsolidate(filter);
        Assert.assertEquals("Charge consolidate must be created", 1L, list.size());
        Assert.assertEquals("Charge consolidate create with wrong value", BigDecimal.TEN, list.get(0)
                .getChargeConsolidateValue());

        chargeConsolidateService.saveGroupChargeConsolidateList(list);

        list.get(0).getChargeGroup().setChargeGroupStatus(chargeStatus);
        saveAndFlush(list.get(0).getChargeGroup());
    }

    private void setupDBUnit() {

        DbUnitHelper.setup("classpath:data/core/fixture-system-dataset.xml",
                "classpath:data/core/participant-dataset.xml", "classpath:data/core/tax-dataset.xml",
                "classpath:data/core/customer-tax-dataset.xml");

        loadChargeConsolidateTypes();

        DbUnitHelper.setup("classpath:data/core/charge-group-dataset.xml",
                "classpath:data/core/charge-consolidate-dataset.xml");

    }

    private void loadChargeConsolidateTypes() {

        CompanyCropAccountNumber cc = (CompanyCropAccountNumber) this.getSession().get(CompanyCropAccountNumber.class,
                new Long(999000011L));

        Map<ChargeConsolidateTypeEnum, ChargeConsolidateType> map = chargeConsolidateService
                .findMapOfAllChargeConsolidateTypes();
        ChargeConsolidateTypeEnum[] values = ChargeConsolidateTypeEnum.values();

        long i = 0;
        for (ChargeConsolidateTypeEnum item : values) {
            if (!map.containsKey(item)) {
                ChargeConsolidateType type = new ChargeConsolidateType();
                type.setId(i);
                type.setChargeConsTypeCode(item);
                type.setChargeConsTypeBundle("bundle.teste");
                type.setCompanyCropAccountNumber(cc);
                type.setImported(item.isImported());
                type.setChargeConsolidateOrigin(item.getChargeConsOriginCode());
                saveAndFlush(type);

                i++;
            }
        }
    }

    private void updateContractsToRunInTestEnv() {
        Company company = (Company) getSession().get(Company.class, 2L);
        Crop crop = (Crop) getSession().get(Crop.class, 2L);
        if ((company != null) && (crop != null)) {
            Contract c1 = (Contract) getSession().get(Contract.class, 900000009L);
            Contract c2 = (Contract) getSession().get(Contract.class, 900000010L);

            c1.setCompany(company);
            c1.setCrop(crop);

            c2.setCompany(company);
            c2.setCrop(crop);

            CompanyCropAccountNumber cc = (CompanyCropAccountNumber) this.getSession().get(
                    CompanyCropAccountNumber.class, new Long(999000011L));

            cc.setCompany(company);
            cc.setCrop(crop);

            getSession().save(c1);
            getSession().save(c2);
            getSession().save(cc);
        }
    }

    private ChargeConsolidateImportedFile createNewImportedFile(ArrayList<ChargeConsolidateImportedLine> lines,
            ChargeConsolidateOrigin origin, boolean overwriteCharge) {
        ChargeConsolidateImportedFile importedFile = new ChargeConsolidateImportedFile();
        ChargeConsolidateImportDTO importDTO = new ChargeConsolidateImportDTO();
        importDTO.setOverwriteCharge(overwriteCharge);
        importDTO.setChargeConsOriginCode(origin);
        importDTO.setChargeConsTypeCode(ChargeConsolidateTypeEnum.SALEREGISTERCHARGE);
        importDTO.setInitialMonth(Calendar.JANUARY);
        importDTO.setInitialYear(2008);
        importDTO.setFinalMonth(Calendar.DECEMBER);
        importDTO.setFinalYear(2008);
        importedFile.setChargeConsolidateImportDTO(importDTO);
        importedFile.setAllEntities(lines);
        return importedFile;
    }

    private ArrayList<ChargeConsolidateImportedLine> createImportedLinesList(
            ChargeConsolidateImportedLine... importedLines) {
        ArrayList<ChargeConsolidateImportedLine> list = new ArrayList<ChargeConsolidateImportedLine>();
        for (int i = 0; i < importedLines.length; i++) {
            importedLines[i].setLine(i);
            list.add(importedLines[i]);
        }

        return list;
    }

    private ChargeConsolidateImportedLine createImportedLine(String documentType, String document,
            BigDecimal chargePercentage, String harvest, String month, String operationalYear, String saleTemplate,
            BigDecimal value, String customerStateRegistration, String customerSapCode) {
        ChargeConsolidateImportedLine importedLine = new ChargeConsolidateImportedLine();
        importedLine.setChargePercentage(chargePercentage);
        importedLine.setDocument(document);
        importedLine.setDocumentType(documentType);
        importedLine.setHarvestDescription(harvest);
        importedLine.setMonthDescription(month);
        importedLine.setOperationalYearDescription(operationalYear);
        importedLine.setSaleTemplateDescription(saleTemplate);
        importedLine.setCustomerStateRegistration(customerStateRegistration);
        importedLine.setCustomerSapCode(customerSapCode);
        importedLine.setUser(accessControlTestFixture.userAdminOfMonsantoBr);
        importedLine.setValue(value);

        return importedLine;
    }

    private void assertFile(ChargeConsolidateImportedFile file, int successLines, int errorLines, int totalLines,
            int warningLines, int allEntitiesCount) {
        Assert.assertEquals("Succcess lines don't match", successLines, file.countSuccess());
        Assert.assertEquals("Error lines don't match", errorLines, file.countErrors());
        Assert.assertEquals("Total lines don't match", totalLines, file.countTotalLines());
        Assert.assertEquals("Warning lines don't match", warningLines, file.countWarnings());
        Assert.assertEquals("Entities created from file don't match", allEntitiesCount, file.getAllEntities().size());
    }

    private ByteArrayInputStream toInputStream(StringBuffer csvFile) {
        return new ByteArrayInputStream(csvFile.toString().getBytes());
    }

    private StringBuffer createCsvLine(StringBuffer csv, String... args) {
        if (csv == null) {
            csv = new StringBuffer(
                    "Tipo de documento;Nº Documento Matriz;Inscri�ao estadual;Codigo ERP;Safra;Modelo de venda;Mês;Ano Operacional;Percentual(%);Valor(R$)");
        }
        if (args.length > 0) {
            csv.append("\n");
        }
        for (int i = 0; i < args.length; ++i) {
            csv.append(args[i] == null ? "" : args[i]);
            if (i < args.length - 1) {
                csv.append(";");
            }
        }
        return csv;
    }
}
