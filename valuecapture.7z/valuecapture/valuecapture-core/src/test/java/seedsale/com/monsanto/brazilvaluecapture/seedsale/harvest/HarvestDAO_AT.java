package com.monsanto.brazilvaluecapture.seedsale.harvest;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.monsanto.brazilvaluecapture.core.foundation.model.bean.StatusEnum;
import com.monsanto.brazilvaluecapture.seedsale.harvest.service.*;
import junit.framework.Assert;

import org.hibernate.SessionFactory;
import org.hibernate.classic.Session;
import org.hibernate.exception.ConstraintViolationException;
import org.hibernate.exception.GenericJDBCException;
import org.junit.Assume;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;

import com.monsanto.brazilvaluecapture.core.base.SystemTestFixture;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Company;
import com.monsanto.brazilvaluecapture.core.foundation.service.BusinessException;
import com.monsanto.brazilvaluecapture.core.foundation.service.EntityAlreadyExistException;
import com.monsanto.brazilvaluecapture.core.foundation.test.AbstractServiceIntegrationTests;
import com.monsanto.brazilvaluecapture.seedsale.harvest.model.bean.Harvest;
import com.monsanto.brazilvaluecapture.seedsale.harvest.model.bean.Plantability;
import com.monsanto.brazilvaluecapture.seedsale.harvest.model.dao.HarvestDAO;
import com.monsanto.brazilvaluecapture.seedsale.harvest.model.dao.HarvestFilter;
import com.monsanto.brazilvaluecapture.seedsale.harvest.model.dao.impl.HarvestDAOImpl;
import com.monsanto.brazilvaluecapture.seedsale.product.PlantabilityTestData;
import com.monsanto.brazilvaluecapture.seedsale.product.ProductivityTestData;
import com.monsanto.brazilvaluecapture.seedsale.product.model.bean.Productivity;
import com.monsanto.brazilvaluecapture.seedsale.sale.service.SaleService;
import com.monsanto.brazilvaluecapture.seedsale.template.SaleTemplateTestData;
import com.monsanto.brazilvaluecapture.seedsale.template.model.bean.SaleTemplate;

public class HarvestDAO_AT extends AbstractServiceIntegrationTests {

    private static final String ANY_MESSAGE = "MESSAGE";

    @Autowired
    HarvestDAO harvestDAO;

    @Autowired
    SaleService saleService;

    private Harvest theSavedHarvest;

    private Harvest aHarvest;

    private static final String aHarvestDescription = "Harvest of Sorrow";

    @Before
    public void init() {
        systemTestFixture = new SystemTestFixture(this);
        theSavedHarvest = HarvestTestData.createHarvest(this.systemTestFixture.soy,
                this.systemTestFixture.operationalYearOf2011, this.systemTestFixture.monsantoBr);
        saveAndFlush(theSavedHarvest);

        aHarvest = HarvestTestData.createHarvest(this.systemTestFixture.soy,
                this.systemTestFixture.operationalYearOf2011, this.systemTestFixture.monsantoBr);
        aHarvest.setDescription(aHarvestDescription);

    }

    @Test
    public void when_aHarvestDoesNotExist_save_shouldBeSuccess() throws EntityAlreadyExistException {
        Harvest harvestNew = HarvestTestData.createHarvest(this.systemTestFixture.soy,
                this.systemTestFixture.operationalYearOf2011, this.systemTestFixture.monsantoBr);
        harvestNew.setDescription("A New Hope");

        harvestDAO.save(harvestNew);
        Assert.assertNotNull(harvestNew.getId());
    }

    @Test(expected = EntityAlreadyExistException.class)
    public void when_alreadyExistsAHarvest_save_aHarvest_shouldBeThrow_EntityAlreadyExistException()
            throws EntityAlreadyExistException {
        getSession().saveOrUpdate(aHarvest);
        getSession().flush();

        Harvest harvestNew = HarvestTestData.createHarvest(this.systemTestFixture.soy,
                this.systemTestFixture.operationalYearOf2011, this.systemTestFixture.monsantoBr);
        harvestNew.setDescription(aHarvestDescription);

        harvestDAO.save(harvestNew);

        Assert.fail("Should be throw an Exception");
    }

    @Test(expected = ConstraintViolationException.class)
    public void when_alreadyExistsAHarvest_save_aHarvest_shouldBeThrow_ConstraintViolationException()
            throws EntityAlreadyExistException {
        SessionFactory sessionFactory = Mockito.mock(SessionFactory.class);
        Session session = Mockito.mock(Session.class);
        Mockito.stub(sessionFactory.getCurrentSession()).toReturn(session);
        ConstraintViolationException exception = new ConstraintViolationException("Exception", new SQLException(
                ANY_MESSAGE), "FK");
        Mockito.doThrow(exception).when(session).saveOrUpdate(Mockito.any());
        HarvestDAO dao = new HarvestDAOImpl(sessionFactory);
        dao.save(aHarvest);

        Assert.fail("Should be throw an Exception");
    }

    @Test
    public void when_hasASavedHarvest_delete_shouldBeSuccess() throws HarvestWithProductivityUndeletableException, HarvestWithSaleTemplateUndeletableException, HarvestWithHarvestCalendarUndeletableException, HarvestWithObtainerByMultiplierUndeletableException, HarvestWithVolumeReportUndeletableException {
        harvestDAO.delete(theSavedHarvest);
        Assert.assertNull(harvestDAO.selectById(theSavedHarvest.getId()));
    }

    @Test(expected = HarvestWithSaleTemplateUndeletableException.class)
    public void when_saleTemplateIsAssociatedWithSaleTemplate_delete_shouldBeThrowException() throws BusinessException {
        Assume.assumeTrue(getAssumptionTest().isEnvironmentWithSQLANSI());
        SaleTemplate saleTemplate = SaleTemplateTestData.createSaleTemplateTypeSeedSale(this.theSavedHarvest);
        getSession().saveOrUpdate(saleTemplate);
        getSession().flush();

        try {
            harvestDAO.delete(theSavedHarvest);
        } catch (GenericJDBCException ex) {
            // Workaround to HSQLDB... should not reach here now that an
            // assumption was added
            if (!getAssumptionTest().isEnvironmentWithSQLANSI()) {
                throw new HarvestWithSaleTemplateUndeletableException("Mock", ex);
            }
        }

        Assert.fail("Should be throw Exception");
    }

    @Test(expected = HarvestWithProductivityUndeletableException.class)
    public void when_productivityIsAssociatedWithSaleTemplate_delete_shouldBeThrowException() throws BusinessException {
        Assume.assumeTrue(getAssumptionTest().isEnvironmentWithSQLANSI());
        Plantability plantability = PlantabilityTestData.createPlantability(theSavedHarvest);
        getSession().saveOrUpdate(plantability);
        getSession().flush();

        Productivity productivityCreated = ProductivityTestData.createProductivity(
                this.systemTestFixture.matoGrossoDoSul, plantability);
        getSession().saveOrUpdate(productivityCreated);
        getSession().flush();

        try {
            harvestDAO.delete(theSavedHarvest);
        } catch (GenericJDBCException ex) {
            // Workaround to HSQLDB... should not reach here now that an
            // assumption was added
            if (!getAssumptionTest().isEnvironmentWithSQLANSI()) {
                throw new HarvestWithProductivityUndeletableException("Mock", ex);
            }
        }
        Assert.fail("Should be throw Exception");
    }

    @Test(expected=ConstraintViolationException.class)
    public void when_hasASavedHarvest_delete_shouldBeThrow_ConstraintViolationException()
            throws HarvestWithProductivityUndeletableException, HarvestWithSaleTemplateUndeletableException, HarvestWithHarvestCalendarUndeletableException, HarvestWithObtainerByMultiplierUndeletableException, HarvestWithVolumeReportUndeletableException {
        SessionFactory sessionFactory = Mockito.mock(SessionFactory.class);
        Session session = Mockito.mock(Session.class);
        Mockito.stub(sessionFactory.getCurrentSession()).toReturn(session);
        ConstraintViolationException exception = new ConstraintViolationException("Exception", new SQLException(
                ANY_MESSAGE), "FK");
        Mockito.doThrow(exception).when(session).delete(Mockito.any());
        HarvestDAO harvestDAO = new HarvestDAOImpl(sessionFactory);
        harvestDAO.delete(theSavedHarvest);

        Assert.fail();
    }

    @Test(expected=HarvestWithProductivityUndeletableException.class)
    public void when_hasASavedHarvest_delete_shouldBeThrow_HarvestWithProductivityUndeletableException()
            throws HarvestWithProductivityUndeletableException, HarvestWithSaleTemplateUndeletableException, HarvestWithHarvestCalendarUndeletableException, HarvestWithObtainerByMultiplierUndeletableException, HarvestWithVolumeReportUndeletableException {
        SessionFactory sessionFactory = Mockito.mock(SessionFactory.class);
        Session session = Mockito.mock(Session.class);
        Mockito.stub(sessionFactory.getCurrentSession()).toReturn(session);
        ConstraintViolationException exception = new ConstraintViolationException("Exception", new SQLException(
                "FK_PRODUCTI_FK_PLANTA_PLANTABI"), "FK");
        Mockito.doThrow(exception).when(session).delete(Mockito.any());
        HarvestDAO harvestDAO = new HarvestDAOImpl(sessionFactory);
        harvestDAO.delete(theSavedHarvest);

        Assert.fail();
    }

    @Test(expected=HarvestWithSaleTemplateUndeletableException.class)
    public void when_hasASavedHarvest_delete_shouldBeThrow_HarvestWithSaleTemplateUndeletableException()
            throws HarvestWithProductivityUndeletableException, HarvestWithSaleTemplateUndeletableException, HarvestWithHarvestCalendarUndeletableException, HarvestWithObtainerByMultiplierUndeletableException, HarvestWithVolumeReportUndeletableException {
        SessionFactory sessionFactory = Mockito.mock(SessionFactory.class);
        Session session = Mockito.mock(Session.class);
        Mockito.stub(sessionFactory.getCurrentSession()).toReturn(session);
        ConstraintViolationException exception = new ConstraintViolationException("Exception", new SQLException(
                "FK_SALE_TEM_FK_HARVES_HARVEST"), "FK");
        Mockito.doThrow(exception).when(session).delete(Mockito.any());
        HarvestDAO harvestDAO = new HarvestDAOImpl(sessionFactory);
        harvestDAO.delete(theSavedHarvest);

        Assert.fail();
    }

    @Test
    public void testSelectedByFilter() {
        HarvestFilter filter = HarvestFilter.getInstance().add(theSavedHarvest.getCompany())
                .add(theSavedHarvest.getCrop()).add(theSavedHarvest.getOperationalYear())
                .add(theSavedHarvest.getStatus());
        List<Harvest> harvests = harvestDAO.getHarvestsBy(filter);
        Assert.assertNotNull(harvests);
        Assert.assertFalse(harvests.isEmpty());
        Assert.assertTrue(harvests.size() == 1);
    }

    @Test
    public void testSelectByFilterWithoutOperationalYear() throws EntityAlreadyExistException {
        HarvestFilter filter = HarvestFilter.getInstance().add(theSavedHarvest.getCompany())
                .add(theSavedHarvest.getCrop()).add(theSavedHarvest.getStatus());
        List<Harvest> harvestBase = harvestDAO.getHarvestsBy(filter);
        Assert.assertNotNull(harvestBase);
        Assert.assertFalse(harvestBase.isEmpty());
        Assert.assertTrue(harvestBase.size() == 1);
        Assert.assertEquals(harvestBase.iterator().next().getId(), theSavedHarvest.getId());
    }

    @Test
    public void testSelectByFilterWithoutStatus() {
        HarvestFilter filter = HarvestFilter.getInstance().add(theSavedHarvest.getCrop())
                .add(systemTestFixture.operationalYearOf2011);
        List<Harvest> harvestBase = harvestDAO.getHarvestsBy(filter);
        Assert.assertNotNull(harvestBase);
        Assert.assertFalse(harvestBase.isEmpty());
        Assert.assertTrue(harvestBase.size() == 1);
        Assert.assertEquals(harvestBase.iterator().next().getId(), theSavedHarvest.getId());
    }

    @Test
    public void testSelectByFilterWithStatusAndCompanies() {
        HarvestFilter filter = HarvestFilter.getInstance().add(StatusEnum.ACTIVE).add(this.systemTestFixture.monsantoBr);
        List<Harvest> harvests = harvestDAO.getHarvestsBy(filter);
        Assert.assertTrue(harvests != null && harvests.size() > 0);
    }

    @Test
    public void testSelectByFilterWithoutFilters() throws EntityAlreadyExistException {
        HarvestFilter filter = HarvestFilter.getInstance().add(theSavedHarvest.getCrop());
        List<Harvest> harvestBase = harvestDAO.getHarvestsBy(filter);
        Assert.assertNotNull(harvestBase);
        Assert.assertFalse(harvestBase.isEmpty());
        Assert.assertTrue(harvestBase.size() == 1);
        Assert.assertEquals(harvestBase.iterator().next().getId(), theSavedHarvest.getId());
    }

    @Test
    public void testSelectAll() {
        List<Harvest> harvests = harvestDAO.selectAll();
        Assert.assertTrue(harvests != null);
    }

    @Test
    public void testGetHarvestsInVigor() {
        List<Company> listCompanies = new ArrayList<Company>(1);
        listCompanies.add(systemTestFixture.companyBayerBrazil);
        List<Harvest> harvestsInVigor = saleService.getHarvestsInVigor(listCompanies, systemTestFixture.soy);
        Assert.assertTrue(harvestsInVigor != null);
    }
}
