package com.monsanto.brazilvaluecapture.seedsale.template;

import com.monsanto.brazilvaluecapture.core.customer.model.bean.Technology;
import com.monsanto.brazilvaluecapture.core.foundation.RandomTestData;
import com.monsanto.brazilvaluecapture.core.foundation.service.BusinessException;
import com.monsanto.brazilvaluecapture.seedsale.harvest.model.bean.Harvest;
import com.monsanto.brazilvaluecapture.seedsale.harvest.model.bean.Plantability;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.Sale.SaleTypeEnum;
import com.monsanto.brazilvaluecapture.seedsale.template.model.bean.*;
import com.monsanto.brazilvaluecapture.seedsale.template.model.bean.Price.PriceTypeEnum;

import java.math.BigDecimal;
import java.util.Calendar;
import java.util.Date;

public class SaleTemplateTestData {

	/**
	 * @param harvest
	 * @return
	 */
	public static SaleTemplate createSaleTemplate(Harvest harvest, SaleTypeEnum saleType) {
		Calendar yesterday = Calendar.getInstance();
		yesterday.add(Calendar.DAY_OF_YEAR, -1);
		Date startDate = yesterday.getTime();
		
		Calendar tomorrow = Calendar.getInstance();
		tomorrow.add(Calendar.DAY_OF_YEAR, 1);
		Date endDate = tomorrow.getTime();
		
		//Creates a sale template with start date from one day before now and end date one day after.
		SaleTemplate saleTemplate = new SaleTemplate(harvest, RandomTestData.createRandomString(6), new Date(), Boolean.FALSE, SaleTemplateByPlantabilityEnum.BY_SALE_TEMPLATE, startDate, endDate, saleType, SaleTemplateBillingMethodEnum.BANKSLIP);
		saleTemplate.setBillAgainst(SaleTemplateBillAgainstEnum.GROWER);
		return saleTemplate;
	}
	
	public static SaleTemplate createSaleTemplateTypeSeedSale(Harvest harvest) {
		return createSaleTemplate(harvest, SaleTypeEnum.SALE_SEED);
	}
	
	/**
	 * Create a new pricing
	 * @param saleTemplate
	 * @param tech
	 * @return Pricing
	 * @throws BusinessException 
	 */
	public static Price createPrice(PriceTypeEnum priceTypeEnum, SaleTemplate saleTemplate, Technology tech) throws BusinessException {
		
		Price pricing = null;
		
		switch (priceTypeEnum) {
		case FIX:
			pricing = new Fix(saleTemplate, tech);
			RoyaltyValue royaltyWithoutExpirationDate = new RoyaltyValue(RandomTestData.createRandomBigDecimal());
			pricing.addRoyaltyValue(royaltyWithoutExpirationDate);
			break;
		default:
			break;
		}
		tech.addPricing(pricing);
		saleTemplate.addPrices(pricing);
		
		return pricing;
	}
	
	/**
	 * Create a new royalty value with date expiration
	 * 
	 * @return RoyaltyValue
	 */
	public static RoyaltyValue createRoyaltyValueWithPlantabilityExpirationDate(BigDecimal value, Date expirationDate, Plantability plantability){
		
		RoyaltyValue royalty = new RoyaltyValue();
		
		royalty.setValue(value);
		royalty.setExpirationDate(expirationDate);
		royalty.setPlantability(plantability);
		
		return royalty;
	}

    public static Price createSeamlessPrice(SaleTemplate saleTemplate, Technology tech) throws BusinessException {

        Price pricing = null;

        pricing = new SeamlessPricing(saleTemplate, tech);
        DueDatePrice ddp = new DueDatePrice(pricing);
        pricing.setDueDatePrice(ddp);
        tech.addPricing(pricing);
        saleTemplate.addPrices(pricing);

        return pricing;
    }

}
