package com.monsanto.brazilvaluecapture.seedsale.sale.model.bean;

import com.monsanto.brazilvaluecapture.pod.rol.model.bean.VolumeOfBag;
import com.monsanto.brazilvaluecapture.seedsale.billing.model.bean.PaymentStatus;
import com.monsanto.brazilvaluecapture.seedsale.template.model.bean.SaleTemplateBillingMethodEnum;
import org.junit.Test;

import java.math.BigDecimal;
import java.util.Collections;
import java.util.Date;
import java.util.Set;

import static com.monsanto.brazilvaluecapture.seedsale.billing.model.bean.PaymentStatusGroup.PaymentStatusOption;
import static com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.Sale.SaleTypeEnum;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

/**
 * Created with IntelliJ IDEA.
 * User: JFVERO
 * Date: 16/01/14
 * Time: 16:13
 */
public class SaleReportDTO_UT {

    @Test
    public void testGettersAndSetters() {
        VolumeOfBag volume = mock(VolumeOfBag.class);
        when(volume.getBagType()).thenReturn("AB");

        SaleItemMixedDetail detail = mock(SaleItemMixedDetail.class);
        when(detail.getVolumeOfBag()).thenReturn(volume);
        when(detail.getNumberOfBags()).thenReturn(86L);

        Set<SaleItemMixedDetail> details = Collections.singleton(detail);

        Date dateHours = new Date();

        SaleReportDTO dto = new SaleReportDTO();
        dto.setSaleId(52L);
        dto.setSaleOrderSAPId(285L);
        dto.setCustomerDocumentMask("00000-0-0");
        dto.setCustomerDocumentValue("8765");
        dto.setCustomerName("Customer");
        dto.setGrowerDocumentMask("000-00-00");
        dto.setGrowerDocumentValue("4237");
        dto.setGrowerName("Grower");
        dto.setGrowerBillingAddressStreet("Street");
        dto.setGrowerBillingAddressNumber("AddressNumber");
        dto.setGrowerBillingAddressStateDescription("State");
        dto.setGrowerBillingAddressCountryDescription("Country");
        dto.setHarvestDescription("Harvest");
        dto.setSaleTemplateDescription("SaleTemplate");
        dto.setProductDescription("Product");
        dto.setTechnologyDescription("Technology");
        dto.setBillingPaymentStatus(PaymentStatus.NOT_PAID);
        dto.setBillingMethod(SaleTemplateBillingMethodEnum.ERP);
        dto.setSaleItemSoldQuantity(84L);
        dto.setSaleItemTotalRoyaltyValue(BigDecimal.valueOf(51L));
        dto.setTotalNumberOfBags(28L);
        dto.setSaleItemMixedDetails(details);
        dto.setSaleNote("Note");
        dto.setCustomerSapId("AOPQ");
        dto.setSaleType(SaleTypeEnum.DIRECT_SALE);
        dto.setUser("User");
        dto.setDateHours(dateHours);
        dto.setWarehouseDescription("GermoSupplier");

        assertEquals(52L, dto.getSaleId().longValue());
        assertEquals(285L, dto.getSaleOrderSAPId().longValue());
        assertEquals("00000-0-0", dto.getCustomerDocumentMask());
        assertEquals("8765", dto.getCustomerDocumentValue());
        assertEquals("00087-6-5", dto.getCustomerDocumentValueFormatted());
        assertEquals("Customer", dto.getCustomerName());
        assertEquals("000-00-00", dto.getGrowerDocumentMask());
        assertEquals("4237", dto.getGrowerDocumentValue());
        assertEquals("000-42-37", dto.getGrowerDocumentValueFormatted());
        assertEquals("Grower", dto.getGrowerName());
        assertEquals("Street", dto.getGrowerBillingAddressStreet());
        assertEquals("AddressNumber", dto.getGrowerBillingAddressNumber());
        assertEquals("State", dto.getGrowerBillingAddressStateDescription());
        assertEquals("Country", dto.getGrowerBillingAddressCountryDescription());
        assertEquals("Street AddressNumber, State, Country", dto.getGrowerBillingAddressFormatted());
        assertEquals("Harvest", dto.getHarvestDescription());
        assertEquals("SaleTemplate", dto.getSaleTemplateDescription());
        assertEquals("Product", dto.getProductDescription());
        assertEquals("Technology", dto.getTechnologyDescription());
        assertEquals(PaymentStatus.NOT_PAID, dto.getBillingPaymentStatus());
        assertEquals(PaymentStatusOption.NOT_PAID_BILLING.getValue(), dto.getBillingPaymentStatusLabel());
        assertEquals(SaleTemplateBillingMethodEnum.ERP, dto.getBillingMethod());
        assertEquals(84L, dto.getSaleItemSoldQuantity().longValue());
        assertEquals(BigDecimal.valueOf(0.084D), dto.getSaleItemSoldQuantityInTons());
        assertEquals(BigDecimal.valueOf(51L), dto.getSaleItemTotalRoyaltyValue());
        assertEquals(28L, dto.getTotalNumberOfBags().longValue());
        assertEquals(details, dto.getSaleItemMixedDetails());
        assertEquals("AB (86) ", dto.getBagDetails());
        assertEquals("Note", dto.getSaleNote());
        assertEquals("AOPQ", dto.getCustomerSapId());
        assertEquals(SaleTypeEnum.DIRECT_SALE, dto.getSaleType());
        assertEquals("User", dto.getUserName());
        assertEquals(dateHours, dto.getDateHours());
        assertEquals("GermoSupplier", dto.getWarehouseDescription());
    }

    @Test
    public void testGetCustomerDocumentValueFormattedWithNullMask() {
        SaleReportDTO dto = new SaleReportDTO();
        dto.setCustomerDocumentMask(null);
        dto.setCustomerDocumentValue("3789");

        assertEquals("3789", dto.getCustomerDocumentValueFormatted());
    }

    @Test
    public void testGetGrowerDocumentValueFormattedWithNullMask() {
        SaleReportDTO dto = new SaleReportDTO();
        dto.setGrowerDocumentMask(null);
        dto.setGrowerDocumentValue("3789");

        assertEquals("3789", dto.getGrowerDocumentValueFormatted());
    }

    @Test
    public void testGetBillingPaymentStatusLabelWithNullStatus() {
        SaleReportDTO dto = new SaleReportDTO();
        dto.setBillingPaymentStatus(null);

        assertEquals("label.billing.novalue", dto.getBillingPaymentStatusLabel());
    }

    @Test
    public void testGetBillingPaymentStatusLabelWithoutMatchingPaymentStatusAll() {
        SaleReportDTO dto = new SaleReportDTO();
        dto.setBillingPaymentStatus(PaymentStatus.BILLED);
        dto.setBillingMethod(null);

        assertEquals(PaymentStatus.BILLED.getValue(), dto.getBillingPaymentStatusLabel());
    }

    @Test
    public void testGetSaleItemSoldQuantityInTonsWithNullValue() {
        SaleReportDTO dto = new SaleReportDTO();
        dto.setSaleItemSoldQuantity(null);

        assertNull(dto.getSaleItemSoldQuantityInTons());
    }

    @Test
    public void testGetBagDetailsWithNullSaleItemMixedDetails() {
        SaleReportDTO dto = new SaleReportDTO();
        dto.setSaleItemMixedDetails(null);

        assertEquals("NA", dto.getBagDetails());
    }

    @Test
    public void testGetBagDetailsWithEmptySaleItemMixedDetails() {
        SaleReportDTO dto = new SaleReportDTO();
        dto.setSaleItemMixedDetails(Collections.<SaleItemMixedDetail>emptySet());

        assertEquals("NA", dto.getBagDetails());
    }

}