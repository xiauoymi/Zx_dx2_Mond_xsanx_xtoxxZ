package com.monsanto.brazilvaluecapture.seedsale.sale.service;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.stub;

import java.math.BigDecimal;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Matchers;

import com.monsanto.brazilvaluecapture.core.base.SystemTestFixture;
import com.monsanto.brazilvaluecapture.core.foundation.service.IllegalDateArgumentException;
import com.monsanto.brazilvaluecapture.seedsale.harvest.model.bean.Plantability;
import com.monsanto.brazilvaluecapture.seedsale.sale.SaleTestFixture;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.SaleItem;
import com.monsanto.brazilvaluecapture.seedsale.sale.service.PlantabilitiesSelector;
import com.monsanto.brazilvaluecapture.seedsale.sale.service.SaleItemFactory;
import com.monsanto.brazilvaluecapture.seedsale.template.model.bean.Price;
import com.monsanto.brazilvaluecapture.seedsale.template.model.bean.Price.PriceTypeEnum;

public class SaleItemFactory_UT {

	private static final BigDecimal FIVE_TONS_OF_SEED = new BigDecimal("5000");
	private static final Long FIVE_TONS_OF_SEED_AS_LONG = FIVE_TONS_OF_SEED.longValue();
	private static final BigDecimal ONE_MILLION_OF_REAIS = new BigDecimal("1000000");
	private static final BigDecimal ONE_DOLLAR = new BigDecimal("1");
	private static final BigDecimal TWENTY_FIVE_CENTS = new BigDecimal("0.25");
	private SystemTestFixture systemTF = new SystemTestFixture();
	private SaleTestFixture saleTF = new SaleTestFixture(systemTF);
	
	private PlantabilitiesSelector plantabilitySelector;
	private SaleItem defaultExpectedSaleItem;
	private SaleItemFactory saleItemFactoryForMatoGrossoDoSul;

	@Before
	public void init() {
		plantabilitySelector = mock(PlantabilitiesSelector.class);
		stub(plantabilitySelector.getPlantabilityByPriceType(Matchers.any(Price.class))).toReturn(saleTF.plantabilitySystemSoyMonsanto2012);
		stub(plantabilitySelector.getCompletePlantability(Matchers.any(Plantability.class), Matchers.any(Price.class))).toReturn(null);

		defaultExpectedSaleItem = mock(SaleItem.class);
		stub(defaultExpectedSaleItem.getTypeOfPrice()).toReturn(PriceTypeEnum.FREE_VALUE);
		stub(defaultExpectedSaleItem.getSoldQuantity()).toReturn(FIVE_TONS_OF_SEED_AS_LONG);
		stub(defaultExpectedSaleItem.getDocumentHeadOfficeValue()).toReturn(saleTF.headOfficeCargil.getCustomerDocumentValue());
		stub(defaultExpectedSaleItem.getProduct()).toReturn(saleTF.productBtSoy);
		stub(defaultExpectedSaleItem.getPriceQuantity()).toReturn(ONE_MILLION_OF_REAIS);
		stub(defaultExpectedSaleItem.getDueDate()).toReturn(saleTF.templateIntactaByPlantabilityRRByExpirationBtFree.getPriceOf(systemTF.bt).getMaxDueDateValue().getValue());
		stub(defaultExpectedSaleItem.getPlantability()).toReturn(saleTF.plantabilitySystemSoyMonsanto2012.getDescription());
		// ATTENTION: Productivities are all the same. See SaleTestFixture
		stub(defaultExpectedSaleItem.getProductivityValue()).toReturn(saleTF.plantabilitySystemSoyMonsanto2012.getAverageProductivityValue(saleTF.productIntactaSoy, systemTF.matoGrossoDoSul));
		stub(defaultExpectedSaleItem.getTotalRoyaltyValue()).toReturn(ONE_MILLION_OF_REAIS.multiply(FIVE_TONS_OF_SEED));
		stub(defaultExpectedSaleItem.getTotalCreditValue()).toReturn(saleTF.plantabilitySystemSoyMonsanto2012.getAverageProductivityValue(saleTF.productIntactaSoy, systemTF.matoGrossoDoSul).multiply(BigDecimal.valueOf(FIVE_TONS_OF_SEED_AS_LONG)).longValue());
		
		saleItemFactoryForMatoGrossoDoSul = SaleItemFactory.getInstance(systemTF.matoGrossoDoSul, plantabilitySelector);
	}
	
	@Test(expected=IllegalArgumentException.class)
	public void given_noValueByPlantabilityPrice_when_build_an_item_with_a_systemPlantability_then_saleItemBuilder_should_throw_exception() {
		saleItemFactoryForMatoGrossoDoSul.createNoValueByPlantabilityItem(saleTF.productIntactaSoy,
				saleTF.templateIntactaNoValueByPlantability,
				saleTF.headOfficeCargil,
				FIVE_TONS_OF_SEED_AS_LONG, saleTF.plantabilitySystemSoyMonsanto2012);
		
		Assert.fail("Cannot build an item with price no value by plantability with a system plantability");
	}
	
	@Test(expected=IllegalArgumentException.class)
	public void given_byPlantabilityPrice_and_dueDateRange_when_build_an_item_with_dueDate_equal_max_date_of_range_and_a_systemPlantability_then_saleItemBuilder_should_throw_exception() {
		saleItemFactoryForMatoGrossoDoSul.createByPlantabilityDueDateRangeItem(saleTF.productIntactaSoy,
				saleTF.templateIntactaByPlantabilityRRByExpirationBtFree,
				saleTF.headOfficeCargil,
				FIVE_TONS_OF_SEED_AS_LONG, SaleTestFixture.NOVEMBER, saleTF.plantabilitySystemSoyMonsanto2012);
		
		Assert.fail("Cannot build an item with price by plantability with a system plantability");
	}
	
	@Test(expected=IllegalArgumentException.class)
	public void given_byPlantabilityPrice_and_dueDateRange_when_build_an_item_with_dueDate_equal_max_date_of_range_and_an_invalid_plantability_then_saleItemBuilder_should_throw_exception() {
		saleItemFactoryForMatoGrossoDoSul.createByPlantabilityDueDateRangeItem(saleTF.productIntactaSoy,
				saleTF.templateIntactaByPlantabilityRRByExpirationBtFree,
				saleTF.headOfficeCargil,
				FIVE_TONS_OF_SEED_AS_LONG, SaleTestFixture.NOVEMBER, saleTF.plantability76To84SoyMonsanto2009);
		
		Assert.fail("Cannot build an item with a plantability that not exist in the plantability selector");
	}
	
	@Test
	public void given_noValueByPlantabilityPrice_when_build_an_item_then_saleItemBuilder_should_return_success() {
		stub(plantabilitySelector.getCompletePlantability(Matchers.any(Plantability.class), Matchers.any(Price.class))).toReturn(saleTF.plantability45To54SoyMonsanto2012);

		SaleItem createdItem = saleItemFactoryForMatoGrossoDoSul.createNoValueByPlantabilityItem(saleTF.productIntactaSoy,
				saleTF.templateIntactaNoValueByPlantability,
				saleTF.headOfficeCargil,
				FIVE_TONS_OF_SEED_AS_LONG, saleTF.plantability45To54SoyMonsanto2012);
		
		stub(defaultExpectedSaleItem.getTypeOfPrice()).toReturn(PriceTypeEnum.NO_VALUE_BY_PLANTABILITY);
		stub(defaultExpectedSaleItem.getProduct()).toReturn(saleTF.productIntactaSoy);
		stub(defaultExpectedSaleItem.getDueDate()).toReturn(null);
		stub(defaultExpectedSaleItem.getPriceQuantity()).toReturn(BigDecimal.ZERO);
		stub(defaultExpectedSaleItem.getPlantability()).toReturn(saleTF.plantability45To54SoyMonsanto2012.getDescription());
		stub(defaultExpectedSaleItem.getTotalRoyaltyValue()).toReturn(BigDecimal.ZERO);

		assertSaleItem(defaultExpectedSaleItem, createdItem);
	}
	
	@Test
	public void given_byPlantabilityPrice_and_dueDateRange_when_build_an_item_with_dueDate_equal_min_date_of_range_then_saleItemBuilder_should_return_success() {
		stub(plantabilitySelector.getCompletePlantability(Matchers.any(Plantability.class), Matchers.any(Price.class))).toReturn(saleTF.plantability45To54SoyMonsanto2012);

		SaleItem createdItem = saleItemFactoryForMatoGrossoDoSul.createByPlantabilityDueDateRangeItem(saleTF.productIntactaSoy,
				saleTF.templateIntactaByPlantabilityRRByExpirationBtFree,
				saleTF.headOfficeCargil,
				FIVE_TONS_OF_SEED_AS_LONG, SaleTestFixture.APRIL, saleTF.plantability45To54SoyMonsanto2012);

		stub(defaultExpectedSaleItem.getTypeOfPrice()).toReturn(PriceTypeEnum.BY_PLANTABILITY_AND_EXPIRATION_DATE);
		stub(defaultExpectedSaleItem.getProduct()).toReturn(saleTF.productIntactaSoy);
		stub(defaultExpectedSaleItem.getDueDate()).toReturn(SaleTestFixture.APRIL);
		stub(defaultExpectedSaleItem.getPriceQuantity()).toReturn(SaleTestFixture.SEVENTY_CENTS);
		stub(defaultExpectedSaleItem.getTotalRoyaltyValue()).toReturn(SaleTestFixture.SEVENTY_CENTS.multiply(FIVE_TONS_OF_SEED));
		stub(defaultExpectedSaleItem.getPlantability()).toReturn(saleTF.plantability45To54SoyMonsanto2012.getDescription());
		
		assertSaleItem(defaultExpectedSaleItem, createdItem);
	}
	
	@Test
	public void given_byExpirationDatePrice_and_dueDateFix_when_build_an_item_then_saleItemBuilder_should_return_success() {
		SaleItem createdItem = saleItemFactoryForMatoGrossoDoSul.createByExpirationDateItem(saleTF.productRRSoy,
				saleTF.templateIntactaByPlantabilityRRByExpirationBtFree,
				saleTF.headOfficeCargil,
				FIVE_TONS_OF_SEED_AS_LONG);
		
		stub(defaultExpectedSaleItem.getTypeOfPrice()).toReturn(PriceTypeEnum.BY_EXPIRATION_DATE);
		stub(defaultExpectedSaleItem.getProduct()).toReturn(saleTF.productRRSoy);
		stub(defaultExpectedSaleItem.getPriceQuantity()).toReturn(SaleTestFixture.TWO_POINT_FIVE_DOLLARS);
		stub(defaultExpectedSaleItem.getTotalRoyaltyValue()).toReturn(SaleTestFixture.TWO_POINT_FIVE_DOLLARS.multiply(FIVE_TONS_OF_SEED));
		
		assertSaleItem(defaultExpectedSaleItem, createdItem);
	}
	
	@Test
	public void given_fixValuePrice_and_dueDateFix_when_build_an_item_then_saleItemBuilder_should_return_success() {
		SaleItem createdItem = saleItemFactoryForMatoGrossoDoSul.createFixValueItem(saleTF.productIntactaSoy,
				saleTF.templateIntactaFixRRRangeBtNoValue,
				saleTF.headOfficeCargil,
				FIVE_TONS_OF_SEED_AS_LONG);

		stub(defaultExpectedSaleItem.getTypeOfPrice()).toReturn(PriceTypeEnum.FIX);
		stub(defaultExpectedSaleItem.getProduct()).toReturn(saleTF.productIntactaSoy);
		stub(defaultExpectedSaleItem.getPriceQuantity()).toReturn(SaleTestFixture.FIVE_DOLLARS);
		stub(defaultExpectedSaleItem.getDueDate()).toReturn(saleTF.templateIntactaFixRRRangeBtNoValue.getPriceOf(systemTF.intacta).getMaxDueDateValue().getValue());
		stub(defaultExpectedSaleItem.getTotalRoyaltyValue()).toReturn(SaleTestFixture.FIVE_DOLLARS.multiply(FIVE_TONS_OF_SEED));
		
		assertSaleItem(defaultExpectedSaleItem, createdItem);
	}

	@Test
	public void given_rangePrice_and_dueDateFix_when_build_an_item_then_saleItemBuilder_should_return_success() {
		SaleItem createdItem = saleItemFactoryForMatoGrossoDoSul.createRangeItem(saleTF.productRRSoy,
				saleTF.templateIntactaFixRRRangeBtNoValue,
				saleTF.headOfficeCargil,
				FIVE_TONS_OF_SEED_AS_LONG, ONE_DOLLAR);

		stub(defaultExpectedSaleItem.getTypeOfPrice()).toReturn(PriceTypeEnum.RANGE);
		stub(defaultExpectedSaleItem.getProduct()).toReturn(saleTF.productRRSoy);
		stub(defaultExpectedSaleItem.getPriceQuantity()).toReturn(ONE_DOLLAR);
		stub(defaultExpectedSaleItem.getTotalRoyaltyValue()).toReturn(ONE_DOLLAR.multiply(FIVE_TONS_OF_SEED));
		stub(defaultExpectedSaleItem.getDueDate()).toReturn(saleTF.templateIntactaFixRRRangeBtNoValue.getPriceOf(systemTF.rr).getMaxDueDateValue().getValue());
		
		assertSaleItem(defaultExpectedSaleItem, createdItem);
	}

	@Test
	public void given_rangePrice_and_dueDateFix_with_seedPrice_equals_minSeedPriceValue_when_build_an_item_then_saleItemBuilder_should_return_success() {
		SaleItem createdItem = saleItemFactoryForMatoGrossoDoSul.createRangeItem(saleTF.productRRSoy,
				saleTF.templateIntactaFixRRRangeBtNoValue,
				saleTF.headOfficeCargil,
				FIVE_TONS_OF_SEED_AS_LONG, SaleTestFixture.FIFTY_CENTS);

		stub(defaultExpectedSaleItem.getTypeOfPrice()).toReturn(PriceTypeEnum.RANGE);
		stub(defaultExpectedSaleItem.getProduct()).toReturn(saleTF.productRRSoy);
		stub(defaultExpectedSaleItem.getPriceQuantity()).toReturn(SaleTestFixture.FIFTY_CENTS);
		stub(defaultExpectedSaleItem.getTotalRoyaltyValue()).toReturn(SaleTestFixture.FIFTY_CENTS.multiply(FIVE_TONS_OF_SEED));
		stub(defaultExpectedSaleItem.getDueDate()).toReturn(saleTF.templateIntactaFixRRRangeBtNoValue.getPriceOf(systemTF.rr).getMaxDueDateValue().getValue());
		
		assertSaleItem(defaultExpectedSaleItem, createdItem);
	}

	@Test
	public void given_rangePrice_and_dueDateFix_with_seedPrice_equals_maxSeedPriceValue_when_build_an_item_then_saleItemBuilder_should_return_success() {
		SaleItem createdItem = saleItemFactoryForMatoGrossoDoSul.createRangeItem(saleTF.productRRSoy,
				saleTF.templateIntactaFixRRRangeBtNoValue,
				saleTF.headOfficeCargil,
				FIVE_TONS_OF_SEED_AS_LONG, SaleTestFixture.TWO_POINT_FIVE_DOLLARS);

		stub(defaultExpectedSaleItem.getTypeOfPrice()).toReturn(PriceTypeEnum.RANGE);
		stub(defaultExpectedSaleItem.getProduct()).toReturn(saleTF.productRRSoy);
		stub(defaultExpectedSaleItem.getPriceQuantity()).toReturn(SaleTestFixture.TWO_POINT_FIVE_DOLLARS);
		stub(defaultExpectedSaleItem.getTotalRoyaltyValue()).toReturn(SaleTestFixture.TWO_POINT_FIVE_DOLLARS.multiply(FIVE_TONS_OF_SEED));
		stub(defaultExpectedSaleItem.getDueDate()).toReturn(saleTF.templateIntactaFixRRRangeBtNoValue.getPriceOf(systemTF.rr).getMaxDueDateValue().getValue());
		
		assertSaleItem(defaultExpectedSaleItem, createdItem);
	}
	
	@Test
	public void given_freeValuePriceThatGenerateCreditIsDisabled_when_build_an_item_then_saleItemBuilder_should_item_with_credit_zero() {
		SaleItem createdItem = saleItemFactoryForMatoGrossoDoSul.createFreeValueDueDateRangeItem(saleTF.productBtSoy, 
				saleTF.templateFreeWithDueDateRangeAndGenerationCreditDisabled, 
				saleTF.headOfficeCargil, 
				FIVE_TONS_OF_SEED_AS_LONG, ONE_MILLION_OF_REAIS,
				SaleTestFixture.AUGUST);

		
		stub(defaultExpectedSaleItem.getTotalCreditValue()).toReturn(0L);
		stub(defaultExpectedSaleItem.getDueDate()).toReturn(SaleTestFixture.AUGUST);
		assertSaleItem(defaultExpectedSaleItem, createdItem);
	}
	
	@Test
	public void given_freeValuePrice_and_dueDateFix_when_build_an_item_then_saleItemBuilder_should_return_success() {
		SaleItem createdItem = saleItemFactoryForMatoGrossoDoSul.createFreeValueItem(saleTF.productBtSoy, 
				saleTF.templateIntactaByPlantabilityRRByExpirationBtFree, 
				saleTF.headOfficeCargil, 
				FIVE_TONS_OF_SEED_AS_LONG, ONE_MILLION_OF_REAIS);

		assertSaleItem(defaultExpectedSaleItem, createdItem);
	}

	@Test
	public void given_freeValuePrice_and_dueDateRange_when_build_an_item_with_dueDate_that_fits_into_range_then_saleItemBuilder_should_return_success() {
		SaleItem createdItem = saleItemFactoryForMatoGrossoDoSul.createFreeValueDueDateRangeItem(saleTF.productBtSoy, 
				saleTF.templateFreeWithDueDateRange, 
				saleTF.headOfficeCargil, 
				FIVE_TONS_OF_SEED_AS_LONG, ONE_MILLION_OF_REAIS, SaleTestFixture.AUGUST);

		stub(defaultExpectedSaleItem.getDueDate()).toReturn(SaleTestFixture.AUGUST);
		assertSaleItem(defaultExpectedSaleItem, createdItem);
	}

	@Test
	public void given_noValuePrice_when_build_an_item_then_saleItemBuilder_should_return_success() {
		SaleItem createdItem = saleItemFactoryForMatoGrossoDoSul.createNoValueItem(saleTF.productIntactaSoy, 
				saleTF.templateIntactaNoValueRRNoValue, 
				saleTF.headOfficeCargil, 
				FIVE_TONS_OF_SEED_AS_LONG);

		stub(defaultExpectedSaleItem.getTypeOfPrice()).toReturn(PriceTypeEnum.NO_VALUE);
		stub(defaultExpectedSaleItem.getProduct()).toReturn(saleTF.productIntactaSoy);
		stub(defaultExpectedSaleItem.getPriceQuantity()).toReturn(BigDecimal.ZERO);
		stub(defaultExpectedSaleItem.getDueDate()).toReturn(null);
		stub(defaultExpectedSaleItem.getTotalRoyaltyValue()).toReturn(BigDecimal.ZERO);
		assertSaleItem(defaultExpectedSaleItem, createdItem);
	}
	
	@Test(expected=IllegalArgumentException.class)
	public void given_rangePrice_with_seedPrice_lessThan_range_then_saleItemBuilder_should_throwException() {
		saleItemFactoryForMatoGrossoDoSul.createRangeItem(saleTF.productRRSoy,
				saleTF.templateIntactaFixRRRangeBtNoValue,
				saleTF.headOfficeCargil,
				FIVE_TONS_OF_SEED_AS_LONG, TWENTY_FIVE_CENTS);
		
		Assert.fail("Factory method should throw exception");
	}
	
	@Test(expected=IllegalArgumentException.class)
	public void given_rangePrice_with_seedPrice_greaterThan_range_then_saleItemBuilder_should_throwException() {
		saleItemFactoryForMatoGrossoDoSul.createRangeItem(saleTF.productRRSoy,
				saleTF.templateIntactaFixRRRangeBtNoValue,
				saleTF.headOfficeCargil,
				FIVE_TONS_OF_SEED_AS_LONG, ONE_MILLION_OF_REAIS);
		
		Assert.fail("Factory method should throw exception");
	}

	@Test(expected=IllegalDateArgumentException.class)
	public void given_freeValuePrice_and_dueDateRange_when_build_an_item_with_dueDate_greaterThan_range_then_saleItemBuilder_should_throwException() {
		saleItemFactoryForMatoGrossoDoSul.createFreeValueDueDateRangeItem(saleTF.productBtSoy, 
				saleTF.templateFreeWithDueDateRange, 
				saleTF.headOfficeCargil, 
				FIVE_TONS_OF_SEED_AS_LONG, ONE_MILLION_OF_REAIS, SaleTestFixture.DECEMBER);

		Assert.fail("Factory method should throw exception");
	}

	@Test(expected=IllegalArgumentException.class)
	public void given_fixValuePrice_when_createNoValueItem_then_saleItemBuilder_should_throw_exception() {
		saleItemFactoryForMatoGrossoDoSul.createNoValueItem(saleTF.productIntactaSoy, 
				saleTF.templateIntactaFixRRRangeBtNoValue, 
				saleTF.headOfficeCargil, 
				FIVE_TONS_OF_SEED_AS_LONG);

		Assert.fail("Factory method should throw exception");
	}

	@Test(expected=IllegalArgumentException.class)
	public void given_noValuePrice_when_createFreeValueItem_then_saleItemBuilder_should_throw_exception() {
		saleItemFactoryForMatoGrossoDoSul.createFreeValueItem(saleTF.productBtSoy, 
				saleTF.templateIntactaFixRRRangeBtNoValue, 
				saleTF.headOfficeCargil, 
				FIVE_TONS_OF_SEED_AS_LONG, BigDecimal.ZERO);

		Assert.fail("Factory method should throw exception");
	}
	
	@Test(expected=IllegalArgumentException.class)
	public void given_null_arguments_when_createNoValueItem_then_factory_should_throw_exception() {
		saleItemFactoryForMatoGrossoDoSul.createNoValueItem(null, null, null, null);

		Assert.fail("Factory method should throw exception");
	}

	
	/* ABSTRACT FACTORY TESTS */
	
	@Test
	public void given_a_saleItemFactory_when_no_value_saleTemplate_is_then_factory_should_return_a_no_value_item() {
		SaleItem expectedSaleItem = saleItemFactoryForMatoGrossoDoSul.createNoValueItem(saleTF.productRRSoy, 
				saleTF.templateIntactaNoValueRRNoValue, 
				saleTF.headOfficeCargil, 
				FIVE_TONS_OF_SEED_AS_LONG);

		SaleItemFactory abstractSaleItemFactory = SaleItemFactory.getInstance(systemTF.matoGrossoDoSul, plantabilitySelector);
		SaleItem actualSaleItem = abstractSaleItemFactory.createSaleItem(saleTF.productRRSoy, 
				saleTF.templateIntactaNoValueRRNoValue, 
				saleTF.headOfficeCargil, 
				FIVE_TONS_OF_SEED_AS_LONG, 
				null,
				null,
				null);
		
		assertSaleItem(expectedSaleItem, actualSaleItem);
	}
	
	@Test
	public void given_a_saleItemFactory_when_noValue_price_is_and_range_due_date_is_then_factory_should_return_a_no_value_item() {
		SaleItem expectedSaleItem = saleItemFactoryForMatoGrossoDoSul.createNoValueDueDateRangeItem(saleTF.productRRSoy, 
				saleTF.templateIntactaNoValueRRNoValue, 
				saleTF.headOfficeCargil, 
				FIVE_TONS_OF_SEED_AS_LONG,
				SaleTestFixture.APRIL);

		SaleItemFactory abstractSaleItemFactory = SaleItemFactory.getInstance(systemTF.matoGrossoDoSul, plantabilitySelector);
		SaleItem actualSaleItem = abstractSaleItemFactory.createSaleItem(saleTF.productRRSoy, 
				saleTF.templateIntactaNoValueRRNoValue, 
				saleTF.headOfficeCargil, 
				FIVE_TONS_OF_SEED_AS_LONG, 
				null,
				null,
				SaleTestFixture.APRIL);
		
		assertSaleItem(expectedSaleItem, actualSaleItem);
	}
	
	@Test
	public void given_a_saleItemFactory_when_free_value_saleTemplate_is_then_factory_should_return_a_free_value_item() {
		SaleItem expectedItem = saleItemFactoryForMatoGrossoDoSul.createFreeValueItem(saleTF.productBtSoy, 
				saleTF.templateIntactaByPlantabilityRRByExpirationBtFree, 
				saleTF.headOfficeCargil, 
				FIVE_TONS_OF_SEED_AS_LONG, 
				ONE_MILLION_OF_REAIS);

		SaleItemFactory abstractSaleItemFactory = SaleItemFactory.getInstance(systemTF.matoGrossoDoSul, plantabilitySelector);
		SaleItem actualSaleItem = abstractSaleItemFactory.createSaleItem(saleTF.productBtSoy, 
				saleTF.templateIntactaByPlantabilityRRByExpirationBtFree, 
				saleTF.headOfficeCargil, 
				FIVE_TONS_OF_SEED_AS_LONG, 
				ONE_MILLION_OF_REAIS,
				null,
				null);

		assertSaleItem(expectedItem, actualSaleItem);
	}
	
	@Test
	public void given_a_saleItemFactory_when_freeValue_price_is_and_range_due_date_is_then_factory_should_return_a_free_value_item() {
		SaleItem expectedItem = saleItemFactoryForMatoGrossoDoSul.createFreeValueDueDateRangeItem(saleTF.productBtSoy, 
				saleTF.templateFreeWithDueDateRange, 
				saleTF.headOfficeCargil, 
				FIVE_TONS_OF_SEED_AS_LONG, 
				ONE_MILLION_OF_REAIS, 
				SaleTestFixture.AUGUST);

		SaleItemFactory abstractSaleItemFactory = SaleItemFactory.getInstance(systemTF.matoGrossoDoSul, plantabilitySelector);
		SaleItem actualSaleItem = abstractSaleItemFactory.createSaleItem(saleTF.productBtSoy, 
				saleTF.templateFreeWithDueDateRange, 
				saleTF.headOfficeCargil, 
				FIVE_TONS_OF_SEED_AS_LONG, 
				ONE_MILLION_OF_REAIS,
				null,
				SaleTestFixture.AUGUST);

		assertSaleItem(expectedItem, actualSaleItem);
	}
	
	@Test
	public void given_a_saleItemFactory_when_fix_value_saleTemplate_is_then_factory_should_return_a_fix_value_item() {
		SaleItem expectedItem = saleItemFactoryForMatoGrossoDoSul.createFixValueItem(saleTF.productIntactaSoy,
				saleTF.templateIntactaFixRRRangeBtNoValue,
				saleTF.headOfficeCargil,
				FIVE_TONS_OF_SEED_AS_LONG);
		
		SaleItemFactory abstractSaleItemFactory = SaleItemFactory.getInstance(systemTF.matoGrossoDoSul, plantabilitySelector);
		SaleItem actualSaleItem = abstractSaleItemFactory.createSaleItem(saleTF.productIntactaSoy,
				saleTF.templateIntactaFixRRRangeBtNoValue,
				saleTF.headOfficeCargil,
				FIVE_TONS_OF_SEED_AS_LONG,
				null,
				null,
				null);

		assertSaleItem(expectedItem, actualSaleItem);
	}
	
	@Test
	public void given_a_saleItemFactory_when_fix_value_price_is_and_range_due_date_is_then_factory_should_return_a_fix_value_item() {
		SaleItem expectedItem = saleItemFactoryForMatoGrossoDoSul.createFixValueDueDateRangeItem(saleTF.productIntactaSoy,
				saleTF.templateFixWithDueDateRange,
				saleTF.headOfficeCargil,
				FIVE_TONS_OF_SEED_AS_LONG, 
				SaleTestFixture.MAY);
		
		SaleItemFactory abstractSaleItemFactory = SaleItemFactory.getInstance(systemTF.matoGrossoDoSul, plantabilitySelector);
		SaleItem actualSaleItem = abstractSaleItemFactory.createSaleItem(saleTF.productIntactaSoy,
				saleTF.templateFixWithDueDateRange,
				saleTF.headOfficeCargil,
				FIVE_TONS_OF_SEED_AS_LONG,
				null,
				null,
				SaleTestFixture.MAY);

		assertSaleItem(expectedItem, actualSaleItem);
	}
	
	@Test
	public void given_a_saleItemFactory_when_range_value_saleTemplate_is_then_factory_should_return_a_range_value_item() {
		SaleItem expectedItem = saleItemFactoryForMatoGrossoDoSul.createRangeItem(saleTF.productRRSoy,
				saleTF.templateIntactaFixRRRangeBtNoValue,
				saleTF.headOfficeCargil,
				FIVE_TONS_OF_SEED_AS_LONG, 
				ONE_DOLLAR);

		SaleItemFactory abstractSaleItemFactory = SaleItemFactory.getInstance(systemTF.matoGrossoDoSul, plantabilitySelector);
		SaleItem actualSaleItem = abstractSaleItemFactory.createSaleItem(saleTF.productRRSoy,
				saleTF.templateIntactaFixRRRangeBtNoValue,
				saleTF.headOfficeCargil,
				FIVE_TONS_OF_SEED_AS_LONG, 
				ONE_DOLLAR,
				null,
				null);

		assertSaleItem(expectedItem, actualSaleItem);
	}
	
	@Test
	public void given_a_saleItemFactory_when_range_value_price_is_and_range_due_date_is_then_factory_should_return_a_range_value_item() {
		SaleItem expectedItem = saleItemFactoryForMatoGrossoDoSul.createRangeDueDateRangeItem(saleTF.productRRSoy,
				saleTF.templateRangeWithDueDateRange,
				saleTF.headOfficeCargil,
				FIVE_TONS_OF_SEED_AS_LONG, 
				ONE_DOLLAR,
				SaleTestFixture.APRIL);

		SaleItemFactory abstractSaleItemFactory = SaleItemFactory.getInstance(systemTF.matoGrossoDoSul, plantabilitySelector);
		SaleItem actualSaleItem = abstractSaleItemFactory.createSaleItem(saleTF.productRRSoy,
				saleTF.templateRangeWithDueDateRange,
				saleTF.headOfficeCargil,
				FIVE_TONS_OF_SEED_AS_LONG, 
				ONE_DOLLAR,
				null,
				SaleTestFixture.APRIL);

		assertSaleItem(expectedItem, actualSaleItem);
	}
	
	@Test
	public void given_a_saleItemFactory_when_byExpirationDate_saleTemplate_is_then_factory_should_return_a_byExpirationDate_value_item() {
		SaleItem expectedItem = saleItemFactoryForMatoGrossoDoSul.createByExpirationDateItem(saleTF.productRRSoy,
				saleTF.templateIntactaByPlantabilityRRByExpirationBtFree,
				saleTF.headOfficeCargil,
				FIVE_TONS_OF_SEED_AS_LONG);
		
		SaleItemFactory abstractSaleItemFactory = SaleItemFactory.getInstance(systemTF.matoGrossoDoSul, plantabilitySelector);
		SaleItem actualSaleItem = abstractSaleItemFactory.createSaleItem(saleTF.productRRSoy,
				saleTF.templateIntactaByPlantabilityRRByExpirationBtFree,
				saleTF.headOfficeCargil,
				FIVE_TONS_OF_SEED_AS_LONG,
				null,
				null,
				null);

		assertSaleItem(expectedItem, actualSaleItem);
	}
	
	@Test
	public void given_a_saleItemFactory_when_byExpirationDate_value_price_is_and_range_due_date_is_then_factory_should_return_a_byExpirationDate_value_item() {
		SaleItem expectedItem = saleItemFactoryForMatoGrossoDoSul.createByExpirationDateDueDateRangeItem(saleTF.productRRSoy,
				saleTF.templateByExpirationDateWithDueDateRange,
				saleTF.headOfficeCargil,
				FIVE_TONS_OF_SEED_AS_LONG,
				SaleTestFixture.AUGUST);
		
		SaleItemFactory abstractSaleItemFactory = SaleItemFactory.getInstance(systemTF.matoGrossoDoSul, plantabilitySelector);
		SaleItem actualSaleItem = abstractSaleItemFactory.createSaleItem(saleTF.productRRSoy,
				saleTF.templateByExpirationDateWithDueDateRange,
				saleTF.headOfficeCargil,
				FIVE_TONS_OF_SEED_AS_LONG,
				null,
				null,
				SaleTestFixture.AUGUST);

		assertSaleItem(expectedItem, actualSaleItem);
	}
	
	@Test
	public void given_a_saleItemFactory_when_byPlantability_saleTemplate_is_then_factory_should_return_a_byPlantability_value_item() {
		stub(plantabilitySelector.getCompletePlantability(Matchers.any(Plantability.class), Matchers.any(Price.class))).toReturn(saleTF.plantability45To54SoyMonsanto2012);

		SaleItem expectedItem = saleItemFactoryForMatoGrossoDoSul.createByPlantabilityItem(saleTF.productIntactaSoy,
				saleTF.templateByPlantabilityWithFixDueDate,
				saleTF.headOfficeCargil,
				FIVE_TONS_OF_SEED_AS_LONG, 
				saleTF.plantability45To54SoyMonsanto2012);

		SaleItemFactory abstractSaleItemFactory = SaleItemFactory.getInstance(systemTF.matoGrossoDoSul, plantabilitySelector);
		SaleItem actualSaleItem = abstractSaleItemFactory.createSaleItem(saleTF.productIntactaSoy,
				saleTF.templateByPlantabilityWithFixDueDate,
				saleTF.headOfficeCargil,
				FIVE_TONS_OF_SEED_AS_LONG,
				null,
				saleTF.plantability45To54SoyMonsanto2012,
				null);

		assertSaleItem(expectedItem, actualSaleItem);
	}
	
	@Test
	public void given_a_saleItemFactory_when_byPlantability_value_price_is_and_range_due_date_is_then_factory_should_return_a_byPlantability_value_item() {
		stub(plantabilitySelector.getCompletePlantability(Matchers.any(Plantability.class), Matchers.any(Price.class))).toReturn(saleTF.plantability45To54SoyMonsanto2012);

		SaleItem expectedItem = saleItemFactoryForMatoGrossoDoSul.createByPlantabilityDueDateRangeItem(saleTF.productIntactaSoy,
				saleTF.templateIntactaByPlantabilityRRByExpirationBtFree,
				saleTF.headOfficeCargil,
				FIVE_TONS_OF_SEED_AS_LONG, 
				SaleTestFixture.MAY, 
				saleTF.plantability45To54SoyMonsanto2012);
		
		SaleItemFactory abstractSaleItemFactory = SaleItemFactory.getInstance(systemTF.matoGrossoDoSul, plantabilitySelector);
		SaleItem actualSaleItem = abstractSaleItemFactory.createSaleItem(saleTF.productIntactaSoy,
				saleTF.templateIntactaByPlantabilityRRByExpirationBtFree,
				saleTF.headOfficeCargil,
				FIVE_TONS_OF_SEED_AS_LONG,
				null,
				saleTF.plantability45To54SoyMonsanto2012,
				SaleTestFixture.MAY);

		assertSaleItem(expectedItem, actualSaleItem);
	}
	
	@Test
	public void given_a_saleItemFactory_when_noValueByPlantability_saleTemplate_is_then_factory_should_return_a_no_value_item() {
		stub(plantabilitySelector.getCompletePlantability(Matchers.any(Plantability.class), Matchers.any(Price.class))).toReturn(saleTF.plantability45To54SoyMonsanto2012);
		
		SaleItem expectedSaleItem = saleItemFactoryForMatoGrossoDoSul.createNoValueByPlantabilityItem(saleTF.productIntactaSoy,
				saleTF.templateIntactaNoValueByPlantability,
				saleTF.headOfficeCargil,
				FIVE_TONS_OF_SEED_AS_LONG,
				saleTF.plantability45To54SoyMonsanto2012);

		SaleItemFactory abstractSaleItemFactory = SaleItemFactory.getInstance(systemTF.matoGrossoDoSul, plantabilitySelector);
		SaleItem actualSaleItem = abstractSaleItemFactory.createSaleItem(saleTF.productIntactaSoy, 
				saleTF.templateIntactaNoValueByPlantability, 
				saleTF.headOfficeCargil, 
				FIVE_TONS_OF_SEED_AS_LONG, 
				null,
				saleTF.plantability45To54SoyMonsanto2012,
				null);
		
		assertSaleItem(expectedSaleItem, actualSaleItem);
	}
	
	private void assertSaleItem(SaleItem expected, SaleItem actual) {
		Assert.assertEquals("Price type is wrong", expected.getTypeOfPrice(), actual.getTypeOfPrice());
		Assert.assertEquals("Sold quantity is wrong", expected.getSoldQuantity(), actual.getSoldQuantity());
		Assert.assertEquals("HeadOffice is wrong", expected.getDocumentHeadOfficeValue(), actual.getDocumentHeadOfficeValue());
		Assert.assertEquals("Product is missing", expected.getProduct(), actual.getProduct());
		Assert.assertEquals("Price quantity is wrong", expected.getPriceQuantity(), actual.getPriceQuantity());
		Assert.assertEquals("DueDate is wrong", expected.getDueDate(), actual.getDueDate());
		Assert.assertEquals("Plantability is wrong", expected.getPlantability(), actual.getPlantability());
		Assert.assertEquals("Productivity value is wrong", expected.getProductivityValue(), actual.getProductivityValue());
		Assert.assertEquals("Royalty value is wrong", expected.getTotalRoyaltyValue(), actual.getTotalRoyaltyValue());
		Assert.assertEquals("Credit value is wrong", expected.getTotalCreditValue(), actual.getTotalCreditValue());
	}
}
