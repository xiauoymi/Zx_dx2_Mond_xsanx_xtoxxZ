package com.monsanto.brazilvaluecapture.seedsale.template;

import com.monsanto.brazilvaluecapture.core.base.SystemTestFixture;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Technology;
import com.monsanto.brazilvaluecapture.core.foundation.RandomTestData;
import com.monsanto.brazilvaluecapture.core.foundation.service.BusinessException;
import com.monsanto.brazilvaluecapture.core.foundation.test.AbstractServiceIntegrationTests;
import com.monsanto.brazilvaluecapture.seedsale.harvest.HarvestTestData;
import com.monsanto.brazilvaluecapture.seedsale.harvest.model.bean.Harvest;
import com.monsanto.brazilvaluecapture.seedsale.product.model.bean.Product;
import com.monsanto.brazilvaluecapture.seedsale.sale.SaleTestFixture;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.NoValueByPlantability;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.Sale.SaleTypeEnum;
import com.monsanto.brazilvaluecapture.seedsale.template.model.bean.*;
import com.monsanto.brazilvaluecapture.seedsale.template.model.bean.Price.PriceTypeEnum;
import com.monsanto.brazilvaluecapture.seedsale.template.model.bean.RetributionFee.RetributionSourceType;
import com.monsanto.brazilvaluecapture.seedsale.template.service.SaleTemplateService;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

public class SaleTemplateService_AT extends AbstractServiceIntegrationTests {

    @Autowired
    private SaleTemplateService saleTemplateService;

    @Before
    public void init() {
        systemTestFixture = new SystemTestFixture(this);
        saleTestFixture = new SaleTestFixture(this, systemTestFixture);
    }

    @Test(expected = BusinessException.class)
    public void testUpdate() throws BusinessException {

        Harvest harvest = HarvestTestData.createHarvest(systemTestFixture.soy, systemTestFixture.operationalYearOf2011, systemTestFixture.monsantoBr);
        saveAndFlush(harvest);

        SaleTemplate saleTemplateCreated = SaleTemplateTestData.createSaleTemplateTypeSeedSale(harvest);
        saleTemplateCreated.setDescription("saleTemplateDescUpdated");

        saleTemplateService.save(saleTemplateCreated);

        String description = RandomTestData.createRandomString(12).toUpperCase();
        //creating a new saleTemplate
        SaleTemplate saleTemplate = SaleTemplateTestData.createSaleTemplateTypeSeedSale(harvest);
        saleTemplate.setDescription(description);

        saleTemplateService.save(saleTemplate);

        Assert.assertNotNull(saleTemplate);
        Assert.assertNotNull(saleTemplate.getId());
        Assert.assertEquals(saleTemplate.getDescription(), description);

        //using same description
        saleTemplate.setDescription("saleTemplateDescUpdated");

        saleTemplateService.save(saleTemplate);
        Assert.fail();

    }

    @Test
    public void test_delete_sale_template() throws BusinessException {
        //SaleTemplate saleTemplate = getSavedSaleTemplate();
        SaleTemplate saleTemplate = getSavedSaleTemplateSeamless();
        Long id = saleTemplate.getId();
        getSession().flush();
        //find the entity
        SaleTemplate template1 = saleTemplateService.selectById(id);

        Assert.assertNotNull(template1);
        getSession().evict(template1); //detach obj

        //delete entity
        saleTemplateService.delete(saleTemplate);
        //find the entity again
        SaleTemplate template2 = saleTemplateService.selectById(id);
        Assert.assertNull(template2);
    }

    @Test
    public void test_select_by_harvest() throws BusinessException {

        SaleTemplate saleTemplate = getSavedSaleTemplate();

        Long harvestId = saleTemplate.getHarvest().getId();

        Harvest harvest = (Harvest) getSession().get(Harvest.class, harvestId);

        List<SaleTemplate> saleTemplateList = saleTemplateService.selectByHarvest(harvest);

        Assert.assertEquals(1, saleTemplateList.size());

        SaleTemplate saleTemplate2 = (SaleTemplate) saleTemplateList.get(0);

        Assert.assertEquals(saleTemplate.getId().longValue(), saleTemplate2.getId().longValue());
    }


    @Test
    public void create_and_update_allTypesOfPricing_shouldBeReturnedsaveUpdatedPricingsOfFixValue() throws BusinessException {

        Harvest harvest = HarvestTestData.createHarvest(systemTestFixture.soy, systemTestFixture.operationalYearOf2011, systemTestFixture.monsantoBr);
        saveAndFlush(harvest);

        SaleTemplate saleTemplate = SaleTemplateTestData.createSaleTemplateTypeSeedSale(harvest);

        Technology technology = saleTemplate.getTechnologiesOfCompany().get(0);
        Price priceFix = PriceTestData.createPrice(PriceTypeEnum.FIX, saleTemplate, technology);
        Price priceRange = PriceTestData.createPrice(PriceTypeEnum.RANGE, saleTemplate, technology);
        Price priceExpiration = PriceTestData.createPrice(PriceTypeEnum.BY_EXPIRATION_DATE, saleTemplate, technology);

        saleTemplate.getPrices().clear();

        List<Price> prices = new ArrayList<Price>();
        RoyaltyValue royaltyValueOne = new RoyaltyValue(BigDecimal.ONE);
        RoyaltyValue royaltyValueTen = new RoyaltyValue(BigDecimal.TEN);

        prices.add(priceFix);
        prices.add(priceRange);

        priceExpiration.addDueDate(new DueDateValue(new Date()));
        prices.add(priceExpiration);

        Assert.assertNull("Sale template id must be null", saleTemplate.getId());
        Assert.assertTrue("Prices list must be empty", saleTemplate.getPrices().isEmpty());


        saleTemplateService.save(saleTemplate, prices);


        Assert.assertNotNull("Sale template id must not be null", saleTemplate.getId());
        Assert.assertFalse("Prices list must not be empty", saleTemplate.getPrices().isEmpty());
        Assert.assertTrue("Prices must have price fix", saleTemplate.getPrices().contains(priceFix));
        Assert.assertTrue("Prices must have price range", saleTemplate.getPrices().contains(priceRange));
        Assert.assertTrue("Prices must have price expiration", saleTemplate.getPrices().contains(priceExpiration));


        List<Price> newPrices = new ArrayList<Price>();

        priceFix.addRoyaltyValue(royaltyValueTen);

        newPrices.add(priceFix);

        priceRange.addRoyaltyValue(royaltyValueOne);
        priceRange.addRoyaltyValue(royaltyValueTen);
        newPrices.add(priceRange);

        //FIX: Was sometimes getting DueDateCanNotBeEqualsAnotherException if creating a new Date()
        long secondDate = System.currentTimeMillis() + 1000;

        priceExpiration.addDueDate(new DueDateValue(new Date(secondDate)));
        priceExpiration.addRoyaltyValue(new RoyaltyValue(BigDecimal.TEN, new Date(secondDate)));
        newPrices.add(priceExpiration);

        saleTemplateService.save(saleTemplate, newPrices);

        //TODO: test with others pricing types
        Assert.assertTrue("Prices must have price fix", saleTemplate.getPrices().contains(priceFix));
        Assert.assertTrue("Prices must have price range", saleTemplate.getPrices().contains(priceRange));
        Assert.assertTrue("Prices must have price expiration", saleTemplate.getPrices().contains(priceExpiration));
    }

    @Test
    public void test_save_merging_prices_with_different_royalt_values() throws BusinessException {

        Harvest harvest = HarvestTestData.createHarvest(systemTestFixture.soy, systemTestFixture.operationalYearOf2011, systemTestFixture.monsantoBr);
        saveAndFlush(harvest);

        SaleTemplate saleTemplate = SaleTemplateTestData.createSaleTemplateTypeSeedSale(harvest);

        Technology technology = saleTemplate.getTechnologiesOfCompany().get(0);
        Price priceRange = PriceTestData.createPrice(PriceTypeEnum.RANGE, saleTemplate, technology);
        //save price
        //saveAndFlush(priceRange);

        saleTemplate.getPrices().clear();

        List<Price> prices = new ArrayList<Price>();
        RoyaltyValue royalty1 = new RoyaltyValue(BigDecimal.ONE);


        //Adding first price
        prices.add(priceRange);
        priceRange.addRoyaltyValue(royalty1);

        Assert.assertNull("Sale template id must be null", saleTemplate.getId());
        Assert.assertTrue("Prices list must be empty", saleTemplate.getPrices().isEmpty());


        saleTemplateService.save(saleTemplate, prices);
        saleTemplateService.save(saleTemplate); //force to save the prices and assign new ids to the prices.

        Assert.assertNotNull("Sale template id must not be null", saleTemplate.getId());
        Assert.assertFalse("Prices list must not be empty", saleTemplate.getPrices().isEmpty());
        //price id
        Long priceId = new Long(priceRange.getId().longValue());
        //Creating new price list
        List<Price> newPrices = new ArrayList<Price>();

        //***************** adding a new price range with a royalt with different value ***************
        RoyaltyValue royalty2 = new RoyaltyValue(BigDecimal.TEN);
        royalty2.setId(royalty1.getId());
        Price priceRange2 = PriceTestData.createPrice(PriceTypeEnum.RANGE, saleTemplate, technology);
        priceRange2.addRoyaltyValue(royalty2);
        priceRange2.setId(priceId);
        newPrices.add(priceRange2);
        //saving the new prices
        saleTemplateService.save(saleTemplate, newPrices);
        //VERIFY THAT THE ROYALT WAS MERGED AND GET THE NEW VALUE
        for (Price price : saleTemplate.getPrices()) {
            if (price.getId().longValue() == priceId.longValue()) {
                RoyaltyValue rv = price.getRoyaltyValues().iterator().next();
                Assert.assertTrue(rv.getValue().compareTo(BigDecimal.TEN) == 0);
            }
        }


    }

    @Test
    public void given_a_sale_template_of_type_direct_sale_should_not_be_able_to_create_another_template_of_direct_sale_for_same_harvest() {
        SaleTemplate oneSaleTemplate = createSaleTemplateOfDirectSaleType();
        saveAndFlush(oneSaleTemplate);
        getSession().flush();

        SaleTemplate anotherSaleTemplate = createSaleTemplateOfDirectSaleType();
        Assert.assertEquals(true, saleTemplateService.hasSaleTemplateOfDirectSaleForHarvest(anotherSaleTemplate));
    }

    @Test
    public void given_a_sale_template_of_type_direct_sale_should_be_able_to_update_same_template_of_direct_sale() throws BusinessException {
        SaleTemplate oneSaleTemplate = createSaleTemplateOfDirectSaleType();
        saleTemplateService.save(oneSaleTemplate);

        Assert.assertEquals(false, saleTemplateService.hasSaleTemplateOfDirectSaleForHarvest(oneSaleTemplate));
    }

    @Test
    public void given_a_sale_template_of_type_direct_sale_should_save_with_no_errors() throws BusinessException {
        SaleTemplate saleTemplate = createSaleTemplateOfDirectSaleType();

        saleTemplateService.save(saleTemplate);

        Assert.assertEquals("Should be of direct sale type", SaleTypeEnum.DIRECT_SALE, saleTemplate.getSaleType());
    }

    @Test
    public void given_a_sale_template_of_type_sale_seed_and_direct_sale_should_save_with_no_errors() {
        SaleTemplate saleTemplateOfDirectSale = createSaleTemplateOfDirectSaleType();
        saveAndFlush(saleTemplateOfDirectSale);

        SaleTemplate saleTemplate = SaleTemplateTestData.createSaleTemplateTypeSeedSale(saleTestFixture.harvest2009SoyMonsanto);

        try {
            saleTemplateService.save(saleTemplate);
        } catch (BusinessException e) {
            Assert.fail();
        }
    }

    private SaleTemplate getSavedSaleTemplate() throws BusinessException {
        Harvest harvest = HarvestTestData.createHarvest(systemTestFixture.soy, systemTestFixture.operationalYearOf2011, systemTestFixture.monsantoBr);
        saveAndFlush(harvest);

        SaleTemplate saleTemplate = SaleTemplateTestData.createSaleTemplateTypeSeedSale(harvest);

        Technology technology = saleTemplate.getTechnologiesOfCompany().get(0);
        Price priceFix = PriceTestData.createPrice(PriceTypeEnum.FIX, saleTemplate, technology);
        Price priceRange = PriceTestData.createPrice(PriceTypeEnum.RANGE, saleTemplate, technology);
        Price priceExpiration = PriceTestData.createPrice(PriceTypeEnum.BY_EXPIRATION_DATE, saleTemplate, technology);

        saleTemplate.getPrices().clear();

        List<Price> prices = new ArrayList<Price>();
        /*RoyaltyValue royaltyValueOne = new RoyaltyValue(BigDecimal.ONE);
		RoyaltyValue royaltyValueTen = new RoyaltyValue(BigDecimal.TEN);*/

        prices.add(priceFix);
        prices.add(priceRange);

        priceExpiration.addDueDate(new DueDateValue(new Date()));
        prices.add(priceExpiration);

        Assert.assertNull("Sale template id must be null", saleTemplate.getId());
        Assert.assertTrue("Prices list must be empty", saleTemplate.getPrices().isEmpty());

        //add product
        Product prod = saleTestFixture.productIntactaSoy;
        saleTemplate.addProduct(prod);

        saleTemplateService.save(saleTemplate, prices);


        return saleTemplate;
    }

    private SaleTemplate createSaleTemplateOfDirectSaleType() {
        SaleTemplate oneSaleTemplate = SaleTemplateTestData.createSaleTemplateTypeSeedSale(saleTestFixture.harvest2009SoyMonsanto);
        oneSaleTemplate.setSaleType(SaleTypeEnum.DIRECT_SALE);
        return oneSaleTemplate;
    }

    @Test
    public void given_a_sale_template_with_price_type_noValueByPlantability_should_be_saved_succesfully() throws BusinessException {
        SaleTemplate saleTemplateWithPriceNoValueByPlantability = createAndSaveSaleTemplate();

        Price noValueByPlantability = new NoValueByPlantability(saleTemplateWithPriceNoValueByPlantability, systemTestFixture.intacta);
        List<Price> prices = new ArrayList<Price>();
        prices.add(noValueByPlantability);

        saleTemplateService.save(saleTemplateWithPriceNoValueByPlantability, prices);
        getSession().flush();

        Assert.assertEquals("Should have one price", 1, saleTemplateWithPriceNoValueByPlantability.getPrices().size());

    }

    @Test
    public void given_price_with_retributionFee_should_save_with_null_values() throws BusinessException {

        RetributionFee retributionFee = new RetributionFee();
        SaleTemplate freeValueSaleTemplate = createAndSaveSaleTemplate();
        Price freeValue = new FreeValue(freeValueSaleTemplate, systemTestFixture.intacta);

        freeValue.setRetributionFee(retributionFee);

        List<Price> prices = new ArrayList<Price>();
        prices.add(freeValue);

        saleTemplateService.save(freeValueSaleTemplate, prices);
        getSession().flush();

        Assert.assertEquals("Should have one price", 1, freeValueSaleTemplate.getPrices().size());
        assertRetributionFee(prices.get(0).getRetributionFee(), Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, null, null, null, null, null, null);
    }

    private void assertRetributionFee(RetributionFee result, Boolean retributionFeeEnabled, Boolean marketingProgramEnabled, Boolean fixValueEnabled,
                                      BigDecimal retributionFee, BigDecimal marketingProgram, BigDecimal fixValue, RetributionSourceType retributionFeeSourceType,
                                      RetributionSourceType marketingProgramSourceType, RetributionSourceType fixValueSourceType) {

        Assert.assertEquals("retributionFeeEnabled not match", retributionFeeEnabled, result.getRetributionFeeEnabled());
        Assert.assertEquals("marketingProgramEnabled not match", marketingProgramEnabled, result.getMarketingProgramEnabled());
        Assert.assertEquals("fixValueEnabled not match", fixValueEnabled, result.getFixValueEnabled());
        Assert.assertEquals("retributionFee not match", retributionFee, result.getRetributionFee());
        Assert.assertEquals("marketingProgram not match", marketingProgram, result.getMarketingProgram());
        Assert.assertEquals("fixValue not match", fixValue, result.getFixValue());
        Assert.assertEquals("retributionFeeSourceType not match", retributionFeeSourceType, result.getRetributionFeeSourceType());
        Assert.assertEquals("marketingProgramSourceType not match", marketingProgramSourceType, result.getMarketingProgramSourceType());
        Assert.assertEquals("fixValueSourceType not match", fixValueSourceType, result.getFixValueSourceType());
    }

    private SaleTemplate createAndSaveSaleTemplate() {
        SaleTemplate saleTemplate = SaleTemplateTestData.createSaleTemplateTypeSeedSale(saleTestFixture.harvest2009SoyMonsanto);
        saveAndFlush(saleTemplate);
        return saleTemplate;
    }

    @Test
    public void given_price_with_retributionFee_with_all_values_should_save_and_retrieve_allValues() throws BusinessException {
        RetributionFee retributionFee = new RetributionFee();
        retributionFee.setFixValue(new BigDecimal(2.58));
        retributionFee.setFixValueEnabled(Boolean.TRUE);
        retributionFee.setFixValueSourceType(RetributionSourceType.ITS);

        retributionFee.setMarketingProgram(new BigDecimal(3.47));
        retributionFee.setMarketingProgramEnabled(Boolean.TRUE);
        retributionFee.setMarketingProgramSourceType(RetributionSourceType.ITS);

        retributionFee.setRetributionFee(new BigDecimal(5.51));
        retributionFee.setRetributionFeeEnabled(Boolean.TRUE);
        retributionFee.setRetributionFeeSourceType(RetributionSourceType.ITS);

        SaleTemplate freeValueSaleTemplate = createAndSaveSaleTemplate();
        Price freeValue = new FreeValue(freeValueSaleTemplate, systemTestFixture.intacta);

        freeValue.setRetributionFee(retributionFee);

        List<Price> prices = new ArrayList<Price>();
        prices.add(freeValue);

        saleTemplateService.save(freeValueSaleTemplate, prices);
        getSession().flush();

        Assert.assertEquals("Should have one price", 1, freeValueSaleTemplate.getPrices().size());
        assertRetributionFee(prices.get(0).getRetributionFee(), Boolean.TRUE, Boolean.TRUE, Boolean.TRUE,
                new BigDecimal(5.51), new BigDecimal(3.47), new BigDecimal(2.58),
                RetributionSourceType.ITS, RetributionSourceType.ITS, RetributionSourceType.ITS);
    }

    private SaleTemplate getSavedSaleTemplateSeamless() throws BusinessException {
        Harvest harvest = HarvestTestData.createHarvest(systemTestFixture.soy, systemTestFixture.operationalYearOf2011, systemTestFixture.monsantoBr);
        saveAndFlush(harvest);

        SaleTemplate saleTemplate = SaleTemplateTestData.createSaleTemplateTypeSeedSale(harvest);

        Technology technology = saleTemplate.getTechnologiesOfCompany().get(0);
        Price priceFix = PriceTestData.createPrice(PriceTypeEnum.FIX, saleTemplate, technology);
        Price priceSeamless = PriceTestData.createPrice(PriceTypeEnum.SEAMLESS_PRICING, saleTemplate, technology);

        saleTemplate.getPrices().clear();

        List<Price> prices = new ArrayList<Price>();

        prices.add(priceFix);

        priceSeamless.addDueDate(new DueDateValue(new Date()));

        DueDatePrice dueDatePrice = new DueDatePrice(priceSeamless);
        dueDatePrice.addItem(buildDueDatePriceItem());
        priceSeamless.setDueDatePrice(dueDatePrice);

        prices.add(priceSeamless);

        Assert.assertNull("Sale template id must be null", saleTemplate.getId());
        Assert.assertTrue("Prices list must be empty", saleTemplate.getPrices().isEmpty());

        //add product
        Product prod = saleTestFixture.productIntactaSoy;
        saleTemplate.addProduct(prod);

        saleTemplateService.save(saleTemplate, prices);

        return saleTemplate;
    }

    private DueDatePriceItem buildDueDatePriceItem() {
        DueDatePriceItem dueDatePriceItem = new DueDatePriceItem("JUNE");
        dueDatePriceItem.setPriceValue(new BigDecimal(1000));
        dueDatePriceItem.setDiscountValue(new BigDecimal(100));
        dueDatePriceItem.setBeginDate(buildDate(2014, 06, 01));
        dueDatePriceItem.setEndDate(buildDate(2014, 06, 30));
        dueDatePriceItem.setDueDate(buildDate(2014, 07, 05));
        return dueDatePriceItem;
    }

    private Date buildDate(int year, int month, int day) {
        Calendar calendar = Calendar.getInstance();
        calendar.set(year, month, day);
        return calendar.getTime();
    }

}
