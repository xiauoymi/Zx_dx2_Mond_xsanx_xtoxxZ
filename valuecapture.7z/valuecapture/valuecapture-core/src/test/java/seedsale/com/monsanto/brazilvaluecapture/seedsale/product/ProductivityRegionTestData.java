package com.monsanto.brazilvaluecapture.seedsale.product;

import com.monsanto.brazilvaluecapture.core.base.CountryTestData;
import com.monsanto.brazilvaluecapture.core.base.StateTestData;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Country;
import com.monsanto.brazilvaluecapture.core.base.model.bean.State;
import com.monsanto.brazilvaluecapture.seedsale.harvest.HarvestTestData;
import com.monsanto.brazilvaluecapture.seedsale.harvest.model.bean.Harvest;
import com.monsanto.brazilvaluecapture.seedsale.harvest.model.bean.Plantability;
import com.monsanto.brazilvaluecapture.seedsale.product.model.bean.*;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: MEFAZZ
 * Date: 9/9/13
 * Time: 2:23 PM
 * To change this template use File | Settings | File Templates.
 */
public class ProductivityRegionTestData {


    public static List<ProductivityByRegion> createSomeProductivityRegions(){
        List<ProductivityByRegion> productivityByRegions = new ArrayList<ProductivityByRegion>();
        productivityByRegions.add(createFullProductivityRegion());
        productivityByRegions.add(createFullProductivityRegion());
        productivityByRegions.add(createFullProductivityRegion());
        productivityByRegions.add(createFullProductivityRegion());
        return productivityByRegions;
    }



    public static ProductivityByRegion createFullProductivityRegion(){
		Harvest harvest = HarvestTestData.createABrazilianHarvest();
		Plantability plantability = PlantabilityTestData.createPlantability(harvest);
        plantability.setId(1L);
        ProductivityByRegion productivityByRegion = new ProductivityByRegion();
        productivityByRegion.setPlantability(plantability);
        productivityByRegion.setRegion(RegionProductivityTestData.createRegionProductivity());
        productivityByRegion.setId(1l);
        productivityByRegion.setPlantability(plantability);
      	return productivityByRegion;
	}


     public static ProductivityDTO createProductivityDTO(Harvest harvest,
		Plantability plantability,Region regionProductivity,DefaultProductivity defaultProductivity) {

        ProductivityDTO productivityDTO = new ProductivityDTO();
        productivityDTO.setHarvest(harvest);
        productivityDTO.setPlantability(plantability);
        productivityDTO.setRegion(regionProductivity);
        productivityDTO.setDefaultProductivity(defaultProductivity);

		return productivityDTO;
	}

}
