package com.monsanto.brazilvaluecapture.seedsale.quota.model.dao;

import com.monsanto.brazilvaluecapture.core.customer.model.bean.Customer;
import com.monsanto.brazilvaluecapture.seedsale.harvest.model.bean.Plantability;
import org.junit.Test;

import static org.fest.assertions.Assertions.assertThat;

/**
 * Created with IntelliJ IDEA.
 * User: IFERN1
 * Date: 12/5/13
 * Time: 4:19 PM
 * To change this template use File | Settings | File Templates.
 */
public class QuotaFilter_UT {

    @Test
    public void when_addMultiplierPlantabilityLot_new_three_criterias_with_multiplier_plantability_lot_fields_are_added() {
        //@Given
        Customer multiplier = new Customer();
        Plantability plantability = new Plantability();
        String lot = "SomeLote";

        //@When
        QuotaFilter quotaFilter = QuotaFilter.getInstance();
        quotaFilter.add(multiplier, plantability, lot);

        //@Should
        assertThat(quotaFilter.countCriterias()).isEqualTo(3);
    }
    
}
