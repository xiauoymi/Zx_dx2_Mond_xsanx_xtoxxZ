package com.monsanto.brazilvaluecapture.seedsale.sale.validation;

import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.Sale;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.SaleItem;
import com.monsanto.brazilvaluecapture.seedsale.template.model.bean.SaleTemplate;
import org.junit.Test;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

import static org.fest.assertions.Assertions.assertThat;
import static org.junit.Assert.fail;

/**
 * Created with IntelliJ IDEA.
 * User: IFERN1
 * Date: 11/19/13
 * Time: 11:50 AM
 * To change this template use File | Settings | File Templates.
 */
public class SaleCityValidationRule_UT {
    @Test
    public void given_a_saletemplate_requiring_a_city_validation_fails_if_sale_dont_have_a_city() {
        //@Given
        SaleTemplate saleTemplate = new SaleTemplate();
        saleTemplate.setIsShowCityMandatory(Boolean.TRUE);
        SaleItem saleItem = new SaleItem();
        saleItem.setSaleTemplate(saleTemplate);
        Set<SaleItem> saleItems = new HashSet<SaleItem>(Arrays.asList(saleItem));
        Sale sale = new Sale();
        sale.setItems(saleItems);
        SaleCityValidationRule saleCityValidationRule = new SaleCityValidationRule();

        //@When
        try {
            saleCityValidationRule.validate(sale);
            fail("Should throw SaleValidationException");
        } catch (Exception e) {
            //@Should
            assertThat(e).isInstanceOf(SaleValidationException.class).hasNoCause();
        }
    }

    @Test
    public void given_a_saletemplate_with_NULL_city_requiring_criteria_validation_passes() {
        //@Given
        SaleTemplate saleTemplate = new SaleTemplate();
        saleTemplate.setIsShowCityMandatory(null);
        SaleItem saleItem = new SaleItem();
        saleItem.setSaleTemplate(saleTemplate);
        Set<SaleItem> saleItems = new HashSet<SaleItem>(Arrays.asList(saleItem));
        Sale sale = new Sale();
        sale.setItems(saleItems);
        SaleCityValidationRule saleCityValidationRule = new SaleCityValidationRule();

        //@When
        try {
            saleCityValidationRule.validate(sale);
        } catch (Exception e) {
            //@Should
            fail("Should not throw SaleValidationException");
        }
    }

    @Test
    public void given_a_sale_with_NULL_saletemplate_validation_passes() {
        //@Given
        Set<SaleItem> saleItems = new HashSet<SaleItem>();
        Sale sale = new Sale();
        sale.setItems(saleItems);
        SaleCityValidationRule saleCityValidationRule = new SaleCityValidationRule();

        //@When
        try {
            saleCityValidationRule.validate(sale);
        } catch (Exception e) {
            //@Should
            fail("Should not throw SaleValidationException");
        }
    }
}