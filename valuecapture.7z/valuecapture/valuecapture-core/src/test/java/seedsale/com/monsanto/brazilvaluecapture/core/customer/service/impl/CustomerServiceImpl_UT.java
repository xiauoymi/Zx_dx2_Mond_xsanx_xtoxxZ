package com.monsanto.brazilvaluecapture.core.customer.service.impl;

import com.monsanto.brazilvaluecapture.core.base.model.bean.Company;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Crop;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Customer;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.ParticipantTypeEnum;
import com.monsanto.brazilvaluecapture.core.customer.model.dao.CustomerDAO;
import com.monsanto.brazilvaluecapture.core.customer.model.dao.HeadOfficeDAO;
import com.monsanto.brazilvaluecapture.core.customer.service.CustomerNotFoundException;
import com.monsanto.brazilvaluecapture.core.user.model.bean.UserContext;
import org.junit.Before;
import org.junit.Test;

import static org.fest.reflect.core.Reflection.field;
import static org.mockito.Mockito.*;

/**
 * User: PPERA
 * Date: 5/13/13
 * Time: 4:02 PM
 */
public class CustomerServiceImpl_UT {
    private CustomerServiceImpl customerService;
    private CustomerDAO customerDAO;
    private HeadOfficeDAO headOfficeDAO;

    @Before
    public void setUp() {
        headOfficeDAO = mock(HeadOfficeDAO.class);
        this.customerDAO = mock(CustomerDAO.class);
        this.customerService = new CustomerServiceImpl(headOfficeDAO);
        field("customerDAO").ofType(CustomerDAO.class).in(this.customerService).set(this.customerDAO);
    }

    @Test
    public void testGetRetailersByParticipantAndCropCallsCustomerDaoGetRetailersByParticipant1AndInputCrop_WhenGettingRetailersForParticipant1AndACrop() {
        // @Given a crop and a participant with id 1
        Crop crop = new Crop();
        UserContext participant = mock(UserContext.class);
        when(participant.getPrimaryKey()).thenReturn(1l);

        // @When getting the retailers matching the participant and the crop
        this.customerService.getRetailersByCropAndParticipant(crop, participant);

        // @Then customerDao.getRetailersByCropAndParticipant is called with the input crop and participant id 1
        verify(this.customerDAO, times(1)).getRetailersByCropAndParticipant(crop, participant.getPrimaryKey());
    }

    @Test
    public void testGetRetailersByParticipantAndCropCallsCustomerDaoGetRetailersByParticipant56AndInputCrop_WhenGettingRetailersForParticipant56AndACrop() {
        // @Given a crop and a participant with id 56
        Crop crop = new Crop();
        UserContext participant = mock(UserContext.class);
        when(participant.getPrimaryKey()).thenReturn(56l);

        // @When getting the retailers matching the participant and the crop
        this.customerService.getRetailersByCropAndParticipant(crop, participant);

        // @Then customerDao.getRetailersByCropAndParticipant is called with the input crop and participant id 56
        verify(this.customerDAO, times(1)).getRetailersByCropAndParticipant(crop, participant.getPrimaryKey());
    }

    @Test
    public void testGetRetailersByCropAndCompanyCallsCustomerDaoGetRetailersByInputCropAndCompany_WhenGettingRetailersForACropAndACompany() {
        // @Given a crop and a company
        Crop crop = new Crop();
        Company company = new Company();

        // @When getting the retailers matching the crop and the company
        this.customerService.getRetailersByCropAndCompany(crop, company);

        // @Then customerDao.getRetailersByCropAndCompany is called with the input crop and company
        verify(this.customerDAO, times(1)).getRetailersByCropAndCompany(crop, company);
    }

    @Test
    public void testGetCustomerHeadOfficeCallHeadOfficeDao_WhenGettingHeadOfficeFromCustomerAndParticipanttype(){
        //@Given a headoffice and participant type
        Customer customer = new Customer();
        final ParticipantTypeEnum participantType = ParticipantTypeEnum.MULTIPLICADOR;

        //@When
        customerService.getCustomerHeadOffice(customer, participantType);

        //@Then
        verify(headOfficeDAO).getCustomerHeadOffice(customer, participantType);
    }
    
    @Test
    public void testGetGetByDocument_WhenGettingCustomerForDocumentAndCountry() throws CustomerNotFoundException{
        //@When
        customerService.getByDocument(anyString(), anyString());

        //@Then
        verify(customerDAO).getCustomerBy(anyString(), anyString());
    }
}
