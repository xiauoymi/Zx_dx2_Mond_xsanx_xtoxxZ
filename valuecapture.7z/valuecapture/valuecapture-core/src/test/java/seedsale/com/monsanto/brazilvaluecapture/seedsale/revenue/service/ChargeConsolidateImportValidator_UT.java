/**
 * 
 */
package com.monsanto.brazilvaluecapture.seedsale.revenue.service;

import java.util.Calendar;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.monsanto.brazilvaluecapture.core.revenue.model.bean.ChargeConsolidateOrigin;
import com.monsanto.brazilvaluecapture.core.revenue.model.bean.ChargeConsolidateTypeEnum;
import com.monsanto.brazilvaluecapture.seedsale.chargeconsolidate.model.bean.ChargeConsolidateImportDTO;

/**
 * @author andregc
 *
 */
public class ChargeConsolidateImportValidator_UT {

	@Autowired
	private ChargeConsolidateImportValidator validator;
	
	private ChargeConsolidateImportDTO chargeConsolidateImportDTO;
	
	@Before
	public void setUp() {
		validator = new ChargeConsolidateImportValidator();
		
		chargeConsolidateImportDTO = new ChargeConsolidateImportDTO();
		chargeConsolidateImportDTO.setChargeConsOriginCode(ChargeConsolidateOrigin.SALE);
		chargeConsolidateImportDTO.setChargeConsTypeCode(ChargeConsolidateTypeEnum.MARKETINGPROGRAM);
		Calendar calendar = Calendar.getInstance();
		calendar.set(2012, Calendar.DECEMBER, 10);
		chargeConsolidateImportDTO.setDeadlineRevenue(calendar.getTime());
		chargeConsolidateImportDTO.setInitialMonth(Calendar.JANUARY);
		chargeConsolidateImportDTO.setInitialYear(2012);
		chargeConsolidateImportDTO.setFinalMonth(Calendar.DECEMBER);
		chargeConsolidateImportDTO.setFinalYear(2012);
		chargeConsolidateImportDTO.setOverwriteCharge(true);
	}
	
	@Test
	public void given_a_valid_DTO_when_validate_then_shouldReturn_sucess() {
		int numExceptions = 0;
		
		try {
			validator.validate(chargeConsolidateImportDTO);
		} catch (ChargeConsolidateImportConstraintException e) {
			numExceptions = e.getViolations().size();
		}
		
		Assert.assertEquals("Should have no exception", 0, numExceptions);
	}
	
	@Test
	public void given_a_valid_DTO_with_origin_GRAINRECEIVE_when_validate_then_shouldReturn_sucess() {
		int numExceptions = 0;
		
		chargeConsolidateImportDTO.setChargeConsOriginCode(ChargeConsolidateOrigin.GRAINRECEIVE);
		
		try {
			validator.validate(chargeConsolidateImportDTO);
		} catch (ChargeConsolidateImportConstraintException e) {
			numExceptions = e.getViolations().size();
		}
		
		Assert.assertEquals("Should have no exception", 0, numExceptions);
	}

	@Test
	public void given_a_DTO_without_origin_when_validate_then_should_throw_exception() {
		int numExceptions = 0;
		
		chargeConsolidateImportDTO.setChargeConsOriginCode(null);
		
		try {
			validator.validate(chargeConsolidateImportDTO);
		} catch (ChargeConsolidateImportConstraintException e) {
			numExceptions = e.getViolations().size();
		}
		
		Assert.assertEquals("Should have one exception", 1, numExceptions);
	}

	@Test
	public void given_a_DTO_without_type_when_validate_then_should_throw_exception() {
		int numExceptions = 0;
		
		chargeConsolidateImportDTO.setChargeConsTypeCode(null);
		
		try {
			validator.validate(chargeConsolidateImportDTO);
		} catch (ChargeConsolidateImportConstraintException e) {
			numExceptions = e.getViolations().size();
		}
		
		Assert.assertEquals("Should have one exception", 1, numExceptions);
	}

	@Test
	public void given_a_DTO_with_origin_GRAINRECEIVE_without_deadLineRevenue_when_validate_then_should_throw_exception() {
		int numExceptions = 0;

		chargeConsolidateImportDTO.setChargeConsOriginCode(ChargeConsolidateOrigin.GRAINRECEIVE);
		chargeConsolidateImportDTO.setDeadlineRevenue(null);
		
		try {
			validator.validate(chargeConsolidateImportDTO);
		} catch (ChargeConsolidateImportConstraintException e) {
			numExceptions = e.getViolations().size();
		}
		
		Assert.assertEquals("Should have one exception", 1, numExceptions);
	}

	@Test
	public void given_a_DTO_with_origin_SALE_without_deadLineRevenue_when_validate_then_shouldReturn_success() {
		int numExceptions = 0;

		chargeConsolidateImportDTO.setChargeConsOriginCode(ChargeConsolidateOrigin.SALE);
		chargeConsolidateImportDTO.setDeadlineRevenue(null);
		
		try {
			validator.validate(chargeConsolidateImportDTO);
		} catch (ChargeConsolidateImportConstraintException e) {
			numExceptions = e.getViolations().size();
		}
		
		Assert.assertEquals("Should have no exception", 0, numExceptions);
	}
	
	@Test
	public void given_a_DTO_with_origin_SALE_and_without_period_when_validate_then_should_return_success() {
		int numExceptions = 0;
		
		chargeConsolidateImportDTO.setChargeConsOriginCode(ChargeConsolidateOrigin.SALE);
		chargeConsolidateImportDTO.setInitialMonth(null);
		chargeConsolidateImportDTO.setInitialYear(null);
		chargeConsolidateImportDTO.setFinalMonth(null);
		chargeConsolidateImportDTO.setFinalYear(null);
		
		try {
			validator.validate(chargeConsolidateImportDTO);
		} catch (ChargeConsolidateImportConstraintException e) {
			numExceptions = e.getViolations().size();
		}
		
		Assert.assertEquals("Should have no exception", 0, numExceptions);
	}

	@Test
	public void given_a_DTO_with_origin_GRAINRECEIVE_without_period_when_validate_then_should_throw_exception() {
		int numExceptions = 0;

		chargeConsolidateImportDTO.setChargeConsOriginCode(ChargeConsolidateOrigin.GRAINRECEIVE);
		chargeConsolidateImportDTO.setInitialMonth(null);
		chargeConsolidateImportDTO.setInitialYear(null);
		chargeConsolidateImportDTO.setFinalMonth(null);
		chargeConsolidateImportDTO.setFinalYear(null);
		
		try {
			validator.validate(chargeConsolidateImportDTO);
		} catch (ChargeConsolidateImportConstraintException e) {
			numExceptions = e.getViolations().size();
		}
		
		Assert.assertEquals("Should have one exception", 4, numExceptions);
	}

	@Test
	public void given_a_DTO_without_overwriteCharge_when_validate_then_should_throw_exception() {
		int numExceptions = 0;
		
		chargeConsolidateImportDTO.setOverwriteCharge(null);
		
		try {
			validator.validate(chargeConsolidateImportDTO);
		} catch (ChargeConsolidateImportConstraintException e) {
			numExceptions = e.getViolations().size();
		}
		
		Assert.assertEquals("Should have one exception", 1, numExceptions);
	}
	
	@Test
	public void given_initialPeriod_greater_than_finalPeriod_when_validate_should_throw_exception() {
		int numExceptions = 0;

		chargeConsolidateImportDTO.setChargeConsOriginCode(ChargeConsolidateOrigin.GRAINRECEIVE);
		chargeConsolidateImportDTO.setInitialMonth(Calendar.JANUARY);
		chargeConsolidateImportDTO.setInitialYear(2013);
		chargeConsolidateImportDTO.setFinalMonth(Calendar.DECEMBER);
		chargeConsolidateImportDTO.setFinalYear(2012);
		
		try {
			validator.validate(chargeConsolidateImportDTO);
		} catch (ChargeConsolidateImportConstraintException e) {
			numExceptions = e.getViolations().size();
		}
		
		Assert.assertEquals("Should have one exception", 1, numExceptions);
	}
	
	@Test
	public void given_deadlineRevenue_less_than_finalPeriod_when_validate_should_throw_exception() {
		int numExceptions = 0;

		chargeConsolidateImportDTO.setChargeConsOriginCode(ChargeConsolidateOrigin.GRAINRECEIVE);
		
		Calendar calendar = Calendar.getInstance();
		calendar.set(2012, Calendar.NOVEMBER, 1);
		chargeConsolidateImportDTO.setDeadlineRevenue(calendar.getTime());
		chargeConsolidateImportDTO.setInitialMonth(Calendar.JANUARY);
		chargeConsolidateImportDTO.setInitialYear(2012);
		chargeConsolidateImportDTO.setFinalMonth(Calendar.DECEMBER);
		chargeConsolidateImportDTO.setFinalYear(2012);
		
		try {
			validator.validate(chargeConsolidateImportDTO);
		} catch (ChargeConsolidateImportConstraintException e) {
			numExceptions = e.getViolations().size();
		}
		
		Assert.assertEquals("Should have one exception", 1, numExceptions);
	}
}
