package com.monsanto.brazilvaluecapture.seedsale.billing.parser;

import com.monsanto.brazilvaluecapture.core.foundation.service.BusinessException;
import com.monsanto.brazilvaluecapture.core.foundation.service.EntityNotFoundException;
import com.monsanto.brazilvaluecapture.core.foundation.util.ConstraintViolation;
import com.monsanto.brazilvaluecapture.core.io.*;
import com.monsanto.brazilvaluecapture.core.posting.model.bean.PostingReference;
import com.monsanto.brazilvaluecapture.core.posting.model.bean.ReferenceNameEnum;
import com.monsanto.brazilvaluecapture.core.posting.service.PostingService;
import com.monsanto.brazilvaluecapture.seedsale.billing.model.bean.Billing;
import com.monsanto.brazilvaluecapture.seedsale.billing.model.bean.PaymentStatus;
import com.monsanto.brazilvaluecapture.seedsale.billing.model.bean.PossiblePayment;
import com.monsanto.brazilvaluecapture.seedsale.billing.model.dao.BillingDAO;
import com.monsanto.brazilvaluecapture.seedsale.billing.service.BillingConstraintViolationException;
import com.monsanto.brazilvaluecapture.seedsale.billing.service.BillingHelper;
import com.monsanto.brazilvaluecapture.seedsale.billing.service.parser.*;
import com.monsanto.brazilvaluecapture.seedsale.billing.service.parser.CnabLexicalAnalyzer.CnabToken;
import com.monsanto.brazilvaluecapture.seedsale.io.ErrorImportedException;
import com.monsanto.brazilvaluecapture.seedsale.io.LexicalAnalyzer;
import com.monsanto.brazilvaluecapture.seedsale.io.SemanticAnalyzer;
import com.monsanto.brazilvaluecapture.seedsale.sale.SaleTestFixture;
import com.monsanto.brazilvaluecapture.seedsale.sale.service.SaleService;
import junit.framework.Assert;
import org.apache.commons.lang3.time.DateUtils;
import org.junit.Test;
import org.mockito.Matchers;
import org.mockito.Mockito;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.math.BigDecimal;
import java.text.ParseException;
import java.util.Date;
import java.util.SortedSet;

import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyLong;
import static org.mockito.Mockito.*;

public class CnabProcessor_UT {

	@Test
	public void given_a_importedFile_with_one_cnabLine_when_payBilling_throwException_then_write_should_return_success_but_mark_file_with_one_error() throws BillingConstraintViolationException {
		BillingConstraintViolationException violations = new BillingConstraintViolationException("Error of violations found");
		violations.add(new ConstraintViolation("Cannot pay a billing in status=", "invalidStatus", "error.sale.manualpayment.denied"));
		doThrow(violations).
		when(mockedSaleService).
		payBillingOfBillet(Matchers.any(Billing.class), Matchers.any(Date.class), Matchers.any(BigDecimal.class),  Matchers.any(BigDecimal.class), Matchers.any(BigDecimal.class));
		
		CnabImportedFile validFileWithOneLine = fakedValidImportedFile();
		
		CnabImportedFile processedFile = cnabProcessor.write(validFileWithOneLine);
		
		assertFileProcessed(0, 0, 1, processedFile);
	}

	@Test
	public void given_a_importedFile_with_one_valid_cnabLine_then_write_should_return_success() throws BillingConstraintViolationException {
		CnabImportedFile validFileWithOneLine = fakedValidImportedFile();
		
	    Mockito.when(mockedSaleService.payBillingOfBillet(Matchers.any(Billing.class), Matchers.any(Date.class), Matchers.any(BigDecimal.class),  Matchers.any(BigDecimal.class), Matchers.any(BigDecimal.class))).
	    thenReturn(new Billing());

		
		stub(mockedPostingService.getPostingReferenceByType(ReferenceNameEnum.ADVANCE)).toReturn(mockedPostingReference);
		stub(mockedPostingService.getPostingReferenceByType(ReferenceNameEnum.SOY_ROYALTIES)).toReturn(mockedPostingReference);
		
		CnabImportedFile processedFile = cnabProcessor.write(validFileWithOneLine);
		
		assertFileProcessed(1, 0, 0, processedFile);
	}

	@Test
	public void given_an_empty_importedFile_then_write_of_processor_should_return_sucess() {
		CnabImportedFile emptyFile = new CnabImportedFile();
		
		CnabImportedFile processedFile = cnabProcessor.write(emptyFile);
		
		assertFileProcessed(0, 0, 0, processedFile);
	}

	@Test(expected=IllegalArgumentException.class)
	public void given_a_null_file_to_processor_then_write_should_throw_exception() {
		CnabImportedFile fileProcessed = cnabProcessor.write(null);
		
		Assert.assertNull("FileProcessed should be null", fileProcessed);
		Assert.fail("Test should not have come here");
	}

	@Test(expected=ErrorImportedException.class)
	public void given_an_cnabLine_when_date_of_payment_exceeds_the_last_possible_dueDate_then_semantic_analyzer_should_throw_exception() throws ErrorImportedException {
		CnabImportedLine parsedCnabLine = mockedCnabLineOverdue();

		semanticAnalyzer.validate(parsedCnabLine);
		
		Assert.fail("Should have throw an exception");
	}

	private CnabImportedLine mockedCnabLineOverdue() {
		Billing stubedBilling = mock(Billing.class);
		stub(stubedBilling.isOverdueAt(any(Date.class))).toReturn(true);
		CnabImportedLine parsedCnabLine = new CnabImportedLine(CNAB_VALID_LINE, false, false, 0);
		parsedCnabLine.setBilling(stubedBilling);
		return parsedCnabLine;
	}
	
	@Test
	public void given_a_valid_cnabLine_then_parser_should_build_with_success() throws ParseException, ImportedException, EntityNotFoundException, WarningImportedException {
		stub(mockedBillingDAO.getByTransactionId(CNAB_VALID_TRANSACTION_ID_PARSED)).toReturn(stubedBilling());
		CnabImportedLine validCnabLine = lexicalAnalyzer.read(CNAB_VALID_LINE, 0);

		CnabImportedLine parsedCnabLine = parser.parse(validCnabLine);
		
		Assert.assertNotNull("Billing should not be null", parsedCnabLine.getBilling());
		Assert.assertEquals("Transaction should be the same as the cnab line", Long.valueOf(CNAB_VALID_TRANSACTION_ID), parsedCnabLine.getBilling().getTransactionNumber());
		Assert.assertEquals("Payment Date should be a valid date", DateUtils.parseDate(CNAB_VALID_DATE_OF_PAYMENT, "ddMMyy"), parsedCnabLine.getPaymentDate());
		Assert.assertEquals("Payment Value should be a valid number", CNAB_VALID_VALUE_OF_PAYMENT_PARSED, parsedCnabLine.getPaymentValue());
		Assert.assertEquals("Tariff Value should be a valid number", CNAB_VALID_VALUE_OF_TARIFF_PARSED, parsedCnabLine.getTariffValue());
		Assert.assertEquals("Launch Value should be a valid number", CNAB_VALID_VALUE_OF_LAUNCH_PARSED, parsedCnabLine.getLaunchValue());
	}

	@Test
	public void given_a_cnabLine_with_all_fields_invalid_then_parser_should_mark_many_errors_in_line() throws EntityNotFoundException, WarningImportedException {
		stub(mockedBillingDAO.getByTransactionId(anyLong())).toReturn(stubedBilling());
		CnabImportedLine invalidCnabLine = lexicalAnalyzer.read(CNAB_INVALID_LINE, 0);
		
		try {
			parser.parse(invalidCnabLine);
			Assert.fail("Parser should throw an exception");
		} catch ( ImportedException cpe) {
			Assert.assertEquals("Should have 5 errors", 5, cpe.countErrors());
			Assert.assertNotNull("CnabParseException should have a cnabLine instance", cpe.getDetail());
			CnabImportedLine detail = (CnabImportedLine) cpe.getDetail();
			Assert.assertNull("CnabLine should not have a paymentDate", detail.getPaymentDate());
			Assert.assertNull("CnabLine should not have a paymentValue", detail.getPaymentValue());
			Assert.assertNull("CnabLine should have a tariffValue", detail.getTariffValue());
			Assert.assertNull("CnabLine should have a launchValue", detail.getLaunchValue());
			Assert.assertNull("CnabLine should not have a billing", detail.getBilling());
		}
	}
	
	@Test
	public void given_a_cnabLine_when_parse_not_found_billing_relative_with_transactionId_then_parser_should_mark_line_with_an_error() throws EntityNotFoundException, WarningImportedException {
		stub(mockedBillingDAO.getByTransactionId(anyLong())).toThrow(new EntityNotFoundException(Billing.class));
		CnabImportedLine cnabLineThatRelativeBillingNotExist = lexicalAnalyzer.read(CNAB_VALID_LINE, 0);
		
		try {
			parser.parse(cnabLineThatRelativeBillingNotExist);
			Assert.fail("Parser should throw an exception");
		} catch ( ImportedException cpe) {
			Assert.assertEquals("Should have 1 error", 1, cpe.countErrors());
			Assert.assertNotNull("CnabParseException should have a cnabLine instance", cpe.getDetail());
			CnabImportedLine detail = (CnabImportedLine) cpe.getDetail();
			Assert.assertNotNull("CnabLine should have a paymentDate", detail.getPaymentDate());
			Assert.assertNotNull("CnabLine should have a paymentValue", detail.getPaymentValue());
			Assert.assertNotNull("CnabLine should have a tariffValue", detail.getTariffValue());
			Assert.assertNotNull("CnabLine should have a LaunchValue", detail.getLaunchValue());
			Assert.assertNull("CnabLine should not have a billing", detail.getBilling());
		}
	}
	
	@Test(expected=WarningImportedException.class)
	public void given_a_valid_cnabLine_billing_canceled_should_mark_line_with_an_error() throws ParseException, ImportedException, EntityNotFoundException, WarningImportedException {
		stub(mockedBillingDAO.getByTransactionId(CNAB_VALID_TRANSACTION_ID_PARSED)).toReturn(stubedBillingBy(PaymentStatus.CANCELLED, null));
		CnabImportedLine validCnabLine = lexicalAnalyzer.read(CNAB_VALID_LINE, 0);

		parser.parse(validCnabLine);
		
		Assert.fail();
	}
	
	@Test
	public void given_a_valid_cnabLine_billing_payment_greaterThan_billet_should_mark_line_with_an_error() throws IOException, BusinessException {
		stub(mockedBillingDAO.getByTransactionId(CNAB_VALID_TRANSACTION_ID_PARSED)).toReturn(stubedBillingBy(PaymentStatus.NOT_PAID, null));
		InputStream resourceAsStream = getClass().getResourceAsStream("/cnab/ArquivoRetornoBB_GreaterThan.ret");		
		CnabImportedFile cnabFile = cnabProcessor.read(resourceAsStream);
		
		Assert.assertEquals("Number of detail lines read", 1, cnabFile.countDetailLines());
		Assert.assertEquals("Number of lines with warning", 1, cnabFile.countWarnings());
	}
	
	@Test
	public void given_a_valid_cnabLine_billing_payment_lessThan_billet_should_mark_line_with_an_error() throws IOException, BusinessException {
		stub(mockedBillingDAO.getByTransactionId(CNAB_VALID_TRANSACTION_ID_PARSED)).toReturn(stubedBillingBy(PaymentStatus.NOT_PAID, null));
		InputStream resourceAsStream = getClass().getResourceAsStream("/cnab/ArquivoRetornoBB_LessThan.ret");		
		CnabImportedFile cnabFile = cnabProcessor.read(resourceAsStream);
		
		Assert.assertEquals("Number of detail lines read", 1, cnabFile.countDetailLines());
		Assert.assertEquals("Number of lines with warning", 1, cnabFile.countWarnings());
	}
	
	@Test
	public void given_a_valid_line_then_lexicalAnalyzer_should_read_with_success() throws WarningImportedException {
		ImportedLine validCnabLine = lexicalAnalyzer.read(CNAB_VALID_LINE, 0);
		Assert.assertNotNull("Should have an instance of cnabLine object", validCnabLine);
		Assert.assertEquals("Should have transactionId", CNAB_VALID_TRANSACTION_ID, validCnabLine.get(CnabToken.TRANSACTION_ID));
		Assert.assertEquals("Should have date of payment", CNAB_VALID_DATE_OF_PAYMENT, validCnabLine.get(CnabToken.DATE_OF_PAYMENT));
		Assert.assertEquals("Should have value of payment", CNAB_VALID_VALUE_OF_PAYMENT, validCnabLine.get(CnabToken.VALUE_OF_PAYMENT));
		Assert.assertEquals("Should have value of tariff", CNAB_VALID_VALUE_OF_TARIFF, validCnabLine.get(CnabToken.VALUE_OF_TARIFF));
		Assert.assertEquals("Should have value of tariff", CNAB_VALID_VALUE_OF_LAUNCH, validCnabLine.get(CnabToken.VALUE_OF_LAUNCH));
	}
	
	@Test(expected=WarningImportedException.class)
	public void given_a_blank_cnabLine_then_parser_should_throw_Exception() throws ParseException, ImportedException, EntityNotFoundException, WarningImportedException {
		lexicalAnalyzer.read("", 0);
		Assert.fail("Lexical should thrown an exception");
	}
	
	@Test(expected=WarningImportedException.class)
	public void given_an_invalid_line_then_lexicalAnalyzer_should_throw_exception() throws WarningImportedException {
		lexicalAnalyzer.read("ASDFAERQWERASDFA", 0);
		Assert.fail("Lexical should thrown an exception");
	}
	
	@Test
	public void given_duplicated_cnabLines_should_have_duplicatedValuesSum_in_cnabFile() throws IOException, BusinessException {
		stub(mockedBillingDAO.getByTransactionId(CNAB_VALID_TRANSACTION_ID_PARSED)).toReturn(stubedBillingBy(PaymentStatus.NOT_PAID, null));
		String cnab = createCnabFile(CNAB_VALID_LINE, CNAB_TRAIL, CNAB_VALID_LINE, CNAB_TRAIL, CNAB_VALID_LINE, CNAB_TRAIL);
		CnabImportedFile cnabImportedFile = cnabProcessor.read(new ByteArrayInputStream(cnab.getBytes()));
		Assert.assertEquals("Should have the accumulated value of 2 duplicated lines", new BigDecimal(14340).setScale(2), cnabImportedFile.getAdvanceValue());
	}
	
	@Test
	public void given_paidBillet_when_read_same_cnab_should_addValue_to_advance_transaction() throws IOException, BusinessException {
		stub(mockedBillingDAO.getByTransactionId(CNAB_VALID_TRANSACTION_ID_PARSED)).toReturn(stubedBillingBy(PaymentStatus.FULLY_PAID, new BigDecimal(500)));
		String cnab = createCnabFile(CNAB_VALID_LINE, CNAB_TRAIL);
		CnabImportedFile cnabImportedFile = cnabProcessor.read(new ByteArrayInputStream(cnab.getBytes()));
		Assert.assertEquals("Should have the accumulated value of the duplicated payment", new BigDecimal(5000).setScale(2), cnabImportedFile.getAdvanceValue());
	}
	
	private String createCnabFile(String... lines) {
      	StringBuilder cnab = new StringBuilder(CNAB_HEADER).append("\n");
        for(int i=0;i<lines.length;++i) {
            cnab.append(lines[i]).append("\n");
        }
        return cnab.toString();
	}

	private Billing stubedBillingBy(PaymentStatus status, BigDecimal valuePayment) {
		Billing billing = stubedBilling();
		SortedSet<PossiblePayment> payments = BillingHelper.createPaymentSet(SaleTestFixture.FEBRUARY);
		payments.iterator().next().setPaidValue(valuePayment);
		billing.getPayments().addAll(payments);
		billing.setPaymentStatus(status);
		return billing;
	}
	
	private Billing stubedBilling() {
		Billing billing = new Billing();
		billing.setTransactionNumber(Long.valueOf(CNAB_VALID_TRANSACTION_ID));
		billing.setPaymentStatus(PaymentStatus.NOT_PAID);
		return billing;
	}
	
	private CnabImportedFile fakedValidImportedFile() {
		CnabImportedFile file = new CnabImportedFile();
		CnabImportedLine read = new CnabImportedLine(CNAB_VALID_LINE, false, false, 0);
		read.setBilling(mock(Billing.class));
		read.setPaymentDate(new Date());
		file.add(read);
		return file;
	}
	
	private void assertFileProcessed(int expectedSuccededLines, int expectedWarnings, int expectedErrors, CnabImportedFile actual) {
		Assert.assertNotNull("File processed should not be null", actual);
		Assert.assertEquals("Wrong number of succeeded lines", expectedSuccededLines, actual.countSuccess());
		Assert.assertEquals("Wrong number of warnings", expectedWarnings, actual.countWarnings());
		Assert.assertEquals("Wrong number of errors", expectedErrors, actual.countErrors());
	}
	
	private static final String CNAB_INVALID_LINE = "70000000000000000313210000850061204062                         120406Abcw 42096310000001   01900000000000 1806300212                              00000000000005000000013037600230112000013a000000000000000000000000000000000000000000000000000000000000000000000AA0500000000000000000000000000000000000000000000000AA049986520000000000000          00000000000000000000000000000000000000000000000000010277900";
	private static final String CNAB_VALID_LINE   = "70000000000000000313210000850061204062                         1204062010142096310000001   01900000000000 1806200112                              000000000000050000000130376002301120000135000000000000000000000000000000000000000000000000000000000000000000000000500000000000000000000000000000000000000000000000000049986520000000000000          0000000000000000000000000000000000000000000000000001027790";
	private static final String CNAB_HEADER = "02RETORNO01COBRANCA       31321000085006000000MONSANTO DO BRASIL LTDA       001BANCO DO BRASIL2001120001570                      000002434202650202  1204062                                                                                                                                                                                                                                              000001";
	private static final String CNAB_TRAIL = "9201001          000000000000000000000000000000          000000000000000000000000000000          000000000000000000000000000000          000000000000000000000000000000                                                  000000000000000000000000000000                                                                                                                                                   027814";
	private static final String CNAB_VALID_TRANSACTION_ID = "0101420963";
	private static final String CNAB_VALID_DATE_OF_PAYMENT = "200112";
	private static final String CNAB_VALID_VALUE_OF_PAYMENT = "0000000500000";
	private static final String CNAB_VALID_VALUE_OF_TARIFF = "0000135";
	private static final String CNAB_VALID_VALUE_OF_LAUNCH =  "0000000499865";
	
	private static final BigDecimal CNAB_VALID_VALUE_OF_PAYMENT_PARSED = new BigDecimal("5000.00");
	private static final BigDecimal CNAB_VALID_VALUE_OF_TARIFF_PARSED = new BigDecimal("1.35");
	private static final BigDecimal CNAB_VALID_VALUE_OF_LAUNCH_PARSED = new BigDecimal("4998.65");

	private static final Long CNAB_VALID_TRANSACTION_ID_PARSED = new Long(CNAB_VALID_TRANSACTION_ID);

	private BillingDAO mockedBillingDAO = mock(BillingDAO.class);
	private SaleService mockedSaleService = mock(SaleService.class);
	private PostingService mockedPostingService = mock(PostingService.class);
	private LexicalAnalyzer<CnabImportedLine> lexicalAnalyzer = new CnabLexicalAnalyzer();
	private ParserAnalyzer<CnabImportedLine> parser = new CnabParserAnalyzer(mockedBillingDAO);
	private PostingReference mockedPostingReference = mock(PostingReference.class);
	private SemanticAnalyzer<CnabImportedLine> semanticAnalyzer = new CnabSemanticAnalyzer();
	private Processor<CnabImportedFile> cnabProcessor = new CnabProcessor(lexicalAnalyzer, parser, semanticAnalyzer, mockedSaleService, mockedPostingService);

}