package com.monsanto.brazilvaluecapture.seedsale.sale.model.dao.impl;

import com.google.common.base.Optional;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Company;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Crop;
import com.monsanto.brazilvaluecapture.seedsale.billing.model.bean.PaymentStatus;
import com.monsanto.brazilvaluecapture.seedsale.revenue.model.PostingStatusEnum;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.Sale;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.dao.MultiplierSaleDAOImpl;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.dao.MultiplierSaleFilter;
import com.monsanto.brazilvaluecapture.utils.DateRange;
import com.monsanto.brazilvaluecapture.utils.DateUtils;
import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.SessionFactory;
import org.hibernate.classic.Session;
import org.hibernate.criterion.Order;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import static org.fest.assertions.Assertions.assertThat;
import static org.junit.Assert.assertEquals;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class MultiplierSaleDAOImpl_UT {

    @Mock
    private SessionFactory sessionFactory;

    @InjectMocks
    private MultiplierSaleDAOImpl multiplierSaleDAO;

    @Mock
    private Session session;

    private Query query;

    @Before
    public void setUp() {
        query = mock(Query.class);
        when(sessionFactory.getCurrentSession()).thenReturn(session);
        when(session.createQuery(any(String.class))).thenReturn(query);
        when(query.setParameter(anyString(), any())).thenReturn(query);
    }

    @Test
    public void given_criteria_when_sale_getByFilter_then_return_list_of_sale() {
        MultiplierSaleFilter filter = mock(MultiplierSaleFilter.class);
        Criteria criteria = mock(Criteria.class);
        Sale sale = mock(Sale.class);
        Crop mockCrop = mock(Crop.class);
        Company mockCompany = mock(Company.class);
        List<Sale> saleList = new ArrayList<Sale>();
        saleList.add(sale);
        when(filter.add(mockCompany)).thenReturn(filter);
        when(filter.add(mockCrop)).thenReturn(filter);
        when(filter.buildCriteria(session)).thenReturn(criteria);
        when(criteria.addOrder((Order) any())).thenReturn(criteria);
        when(criteria.list()).thenReturn(saleList);

        // @Given
        Object expected = saleList.size();

        // @When
        Object result = multiplierSaleDAO.getByFilter(filter).size();
        verify(criteria).addOrder((Order) any());

        // @Then
        assertEquals(expected, result);

    }

    @Test
    public void testFindNotLinkedSalesInPreviousMonthForRevenueRecognition_FULLY_PAID() {
        //@Given

        //@When
        multiplierSaleDAO.findNotLinkedSalesInPreviousMonthForRevenueRecognition(PaymentStatus.FULLY_PAID, new DateRange(new Date(), new Date()), Optional.of(new DateRange(new Date(), new Date())));

        //@Should
        verify(session).createQuery(any(String.class));
        verify(query, times(8)).setParameter(any(String.class), any());
        verify(query).list();
    }

    @Test
    public void testFindNotLinkedSalesInPreviousMonthForRevenueRecognition_BILLED() {
        //@Given

        //@When
        multiplierSaleDAO.findNotLinkedSalesInPreviousMonthForRevenueRecognition(PaymentStatus.BILLED, new DateRange(new Date(), new Date()), Optional.of(new DateRange(new Date(), new Date())));

        //@Should
        verify(session).createQuery(any(String.class));
        verify(query, times(8)).setParameter(any(String.class), any(Date.class));
        verify(query).list();
    }

    @Test
    public void testFindNotLinkedSalesInPreviousMonthForRevenueRecognition_NOT_PAID() {
        //@Given

        //@When
        multiplierSaleDAO.findNotLinkedSalesInPreviousMonthForRevenueRecognition(PaymentStatus.NOT_PAID, new DateRange(new Date(), new Date()), Optional.of(new DateRange(new Date(), new Date())));

        //@Should
        verify(session).createQuery(any(String.class));
        verify(query, times(8)).setParameter(any(String.class), any(Date.class));
        verify(query).list();
    }

    @Test
    public void testGetMultiplierToGrowerSalesGeneratedAndConsumed() throws Exception {
        //@Given
        String queryStr = buildMultiplierBankSlipPaymentQueryForMultiplierToGrowerSales();
        //@When
        multiplierSaleDAO.getMultiplierToGrowerSalesGeneratedAndConsumed();
        //@Then
        DateRange range = DateUtils.getLastMonthDateRange();
        verify(session).createQuery(queryStr);
        verify(query).setParameter("saleType", Sale.SaleTypeEnum.MULTIPLIER_TO_GROWER_SEED_SALE);
        verify(query).setParameter("paymentStatus", PaymentStatus.FULLY_PAID);
        verify(query).setParameter("dateFrom", range.getDateFrom());
        verify(query).setParameter("dateTo", range.getDateTo());
        verify(query).list();
    }

    private String buildMultiplierBankSlipPaymentQueryForMultiplierToGrowerSales() {
        return new StringBuilder()
                .append(" select si ")
                .append(" from ")
                .append(" SaleItem as si ")
                .append(" join si.sale as s ")
                .append(" join si.billing as b ")
                .append(" join si.revenueAccount as ra ")
                .append(" where ")
                .append("   s.saleType = :saleType ")
                .append("   and ")
                .append("   b.paymentStatus = :paymentStatus ")
                .append("   and ")
                .append("   ( ")
                .append("     si.product.cultivar.obtainer.revenueRecognitionExcluded is null ")
                .append("     or si.product.cultivar.obtainer.revenueRecognitionExcluded = FALSE ")
                .append("   ) ")
                .append("and ")
                .append("   ra.paymentDate between :dateFrom and :dateTo ")
                .toString();
    }

    @Test
    public void searchMultiplierSalesNotCancelledGroupByObtainerInRangeDateCreateSQLQuery_whenDAOisInvoked() {
        SQLQuery sqlQuery = mock(SQLQuery.class);
        String query = new StringBuilder()
                .append(" select new com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.SaleItemGroupByObtainerDTO(obtainer, technology, sale_item, sum(sale_item.netRoyaltyValueQuantity)) ")
                .append(" from Sale sale ")
                .append("   join sale.items as sale_item ")
                .append("   join sale_item.billing as billing ")
                .append("   join sale_item.revenueAccount as revenue_account ")
                .append("   join sale_item.product as product ")
                .append("   join product.technology as technology ")
                .append("   join product.cultivar as cultivar ")
                .append("   join cultivar.obtainer as obtainer ")
                .append(" where ")
                .append("   sale.saleType in ('MULTIPLIER_SEED_SALE', 'MULTIPLIER_TO_GROWER_SEED_SALE') ")
                .append("   and billing.paymentStatus <> 'CANCELLED' ")
                .append("   and sale.creationDate between :startDate and :endDate ")
                .append(" group by ")
                .append("   obtainer, technology, sale_item ").toString();
        when(sessionFactory.getCurrentSession().createQuery(query)).thenReturn(sqlQuery);

        multiplierSaleDAO.searchMultiplierSalesNotCancelledGroupByObtainerInRangeDate(new Date(), new Date());

        verify(sessionFactory, times(2)).getCurrentSession();
    }

    @Test
    public void testGetLastMonthMultiplierSalesNotCancelledSaleItems() {
        DateRange range = DateUtils.getLastMonthDateRange();

        multiplierSaleDAO.getLastMonthMultiplierSalesNotCancelledSaleItems();

        String queryString =
                " select saleItem " +
                " from SaleItem saleItem  " +
                "   join saleItem.sale as sale  " +
                "   join saleItem.billing as billing  " +
                "   join saleItem.product as prod " +
                "   join prod.cultivar as cult " +
                "   join cult.obtainer as obt " +
                " where  " +
                "   sale.saleType in (:inMTD, :inMTG)  " +
                "   and (saleItem.postingStatus is null or saleItem.postingStatus = :notPosted or saleItem.postingStatus = :postingStatus)  " +
                "   and saleItem.valueShare is null  " +
                "   and billing.paymentStatus <> :paymentStatus  " +
                "   and sale.creationDate between :startDate and :endDate " +
                "   and exists (select 1 from ObtainerPercentage as op where op.obtainer = obt and op.percentage <> 0 and op.transTypeStatus = :activeObtainerPercentage) ";

        verify(session).createQuery(queryString);
        verify(query).setParameter("inMTD", Sale.SaleTypeEnum.MULTIPLIER_SEED_SALE);
        verify(query).setParameter("inMTG", Sale.SaleTypeEnum.MULTIPLIER_TO_GROWER_SEED_SALE);
        verify(query).setParameter("notPosted", PostingStatusEnum.NOT_POSTED);
        verify(query).setParameter("postingStatus", PostingStatusEnum.VALUE_SHARE_POSTED.getPrevious());
        verify(query).setParameter("paymentStatus", PaymentStatus.CANCELLED);
        verify(query).setParameter("startDate", range.getDateFrom());
        verify(query).setParameter("endDate", range.getDateTo());

        verify(query).list();
    }

    @Test
    public void testFindNotLinkedSalesInPreviousMonthForRevenueRecognitionFiltersByInvoiceDate_whenInvoiceDateRangeIsPresent() {
        //@When
        PaymentStatus paymentStatus = PaymentStatus.NOT_PAID;
        DateRange saleCreationDateRange = new DateRange(new Date(), new Date());
        Optional<DateRange> saleInvoiceDateRange = Optional.of(saleCreationDateRange);
        multiplierSaleDAO.findNotLinkedSalesInPreviousMonthForRevenueRecognition(paymentStatus, saleCreationDateRange, saleInvoiceDateRange);
        //@Then
        ArgumentCaptor<String> queryArgumentCaptor = ArgumentCaptor.forClass(String.class);
        verify(session).createQuery(queryArgumentCaptor.capture());
        assertThat(queryArgumentCaptor.getValue()).contains("and sale.invoiceDate between :invoiceStartDate and :invoiceEndDate");
    }

    @Test
    public void testFindNotLinkedSalesInPreviousMonthForRevenueRecognitionDoNotFiltersByInvoiceDate_whenInvoiceDateRangeIsAbsent() {
        //@When
        PaymentStatus paymentStatus = PaymentStatus.NOT_PAID;
        DateRange saleCreationDateRange = new DateRange(new Date(), new Date());
        Optional<DateRange> saleInvoiceDateRange = Optional.absent();
        multiplierSaleDAO.findNotLinkedSalesInPreviousMonthForRevenueRecognition(paymentStatus, saleCreationDateRange, saleInvoiceDateRange);
        //@Then
        ArgumentCaptor<String> queryArgumentCaptor = ArgumentCaptor.forClass(String.class);
        verify(session).createQuery(queryArgumentCaptor.capture());
        assertThat(queryArgumentCaptor.getValue()).doesNotContain("and sale.invoiceDate between :invoiceStartDate and :invoiceEndDate");
    }

    @Test
    public void testFindNotLinkedSalesInPreviousMonthSetsInvoiceStartDateParameters_whenSaleInvoiceDateIsPresent() {
        //@When
        PaymentStatus paymentStatus = PaymentStatus.NOT_PAID;
        DateRange saleCreationDateRange = new DateRange(new Date(), new Date());
        Optional<DateRange> saleInvoiceDateRange = Optional.of(saleCreationDateRange);
        multiplierSaleDAO.findNotLinkedSalesInPreviousMonthForRevenueRecognition(paymentStatus, saleCreationDateRange, saleInvoiceDateRange);
        //@Then
        verify(query).setParameter("invoiceStartDate", saleInvoiceDateRange.get().getDateFrom());
    }

    @Test
    public void testFindNotLinkedSalesInPreviousMonthSetsInvoiceStartEndParameters_whenSaleInvoiceDateIsPresent() {
        //@When
        PaymentStatus paymentStatus = PaymentStatus.NOT_PAID;
        DateRange saleCreationDateRange = new DateRange(new Date(), new Date());
        Optional<DateRange> saleInvoiceDateRange = Optional.of(saleCreationDateRange);
        multiplierSaleDAO.findNotLinkedSalesInPreviousMonthForRevenueRecognition(paymentStatus, saleCreationDateRange, saleInvoiceDateRange);
        //@Then
        verify(query).setParameter("invoiceEndDate", saleInvoiceDateRange.get().getDateTo());
    }

    @Test
    public void testFindNotLinkedSalesInPreviousMonthDoesNotSetsInvoiceStartDateParameters_whenSaleInvoiceDateIsPresent() {
        //@When
        PaymentStatus paymentStatus = PaymentStatus.NOT_PAID;
        DateRange saleCreationDateRange = new DateRange(new Date(), new Date());
        Optional<DateRange> saleInvoiceDateRange = Optional.absent();
        multiplierSaleDAO.findNotLinkedSalesInPreviousMonthForRevenueRecognition(paymentStatus, saleCreationDateRange, saleInvoiceDateRange);
        //@Then
        verify(query, never()).setParameter(eq("invoiceStartDate"), any(Date.class));
    }

    @Test
    public void testFindNotLinkedSalesInPreviousMonthDoesNotSetsInvoiceStartEndParameters_whenSaleInvoiceDateIsPresent() {
        //@When
        PaymentStatus paymentStatus = PaymentStatus.NOT_PAID;
        DateRange saleCreationDateRange = new DateRange(new Date(), new Date());
        Optional<DateRange> saleInvoiceDateRange = Optional.absent();
        multiplierSaleDAO.findNotLinkedSalesInPreviousMonthForRevenueRecognition(paymentStatus, saleCreationDateRange, saleInvoiceDateRange);
        //@Then
        verify(query, never()).setParameter(eq("invoiceEndDate"), any(Date.class));
    }

    @Test
    public void testListMultiplierToDealerSalesInPeriodCreatesTheCorrectQuery() {
        DateRange period = DateUtils.getLastMonthDateRange();

        multiplierSaleDAO.listMultiplierToDealerSalesInPeriod(period, Sale.SaleTypeEnum.MULTIPLIER_TO_GROWER_SEED_SALE);

        ArgumentCaptor<String> queryStringCaptor = ArgumentCaptor.forClass(String.class);
        verify(session).createQuery(queryStringCaptor.capture());
        String queryString = queryStringCaptor.getValue();
        String expectedQueryString = "SELECT DISTINCT sale FROM Sale sale " +
                "JOIN sale.items si " +
                "JOIN si.billing b " +
                "WHERE sale.saleType = :multiplierSaleType and " +
                "sale.creationDate BETWEEN :startDate and :endDate and " +
                "b.paymentStatus <> 'CANCELLED' and (" +
                "sale not in (SELECT sld.multiplierSale FROM SaleLinkDetail sld)" +
                ")";
        assertThat(queryString).isEqualTo(expectedQueryString);
    }

    @Test
    public void testListMultiplierToDealerSalesInPeriodSetsMultiplierToGrowerSaleTypeAsParameter() {
        final Sale.SaleTypeEnum multiplierToGrowerSeedSaleType = Sale.SaleTypeEnum.MULTIPLIER_TO_GROWER_SEED_SALE;
        DateRange period = DateUtils.getLastMonthDateRange();

        multiplierSaleDAO.listMultiplierToDealerSalesInPeriod(period, multiplierToGrowerSeedSaleType);

        verify(query).setParameter("multiplierSaleType", multiplierToGrowerSeedSaleType);
    }

    @Test
    public void testListMultiplierToDealerSalesInPeriodSetsDateFromAsParameter() {
        DateRange period = DateUtils.getLastMonthDateRange();

        multiplierSaleDAO.listMultiplierToDealerSalesInPeriod(period, Sale.SaleTypeEnum.MULTIPLIER_TO_GROWER_SEED_SALE);

        verify(query).setParameter("startDate", period.getDateFrom());
    }

    @Test
    public void testListMultiplierToDealerSalesInPeriodSetsDateToAsParameter() {
        DateRange period = DateUtils.getLastMonthDateRange();

        multiplierSaleDAO.listMultiplierToDealerSalesInPeriod(period, Sale.SaleTypeEnum.MULTIPLIER_TO_GROWER_SEED_SALE);

        verify(query).setParameter("endDate", period.getDateTo());
    }

}
