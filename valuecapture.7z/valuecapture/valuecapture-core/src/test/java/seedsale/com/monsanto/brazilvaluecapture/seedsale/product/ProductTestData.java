package com.monsanto.brazilvaluecapture.seedsale.product;

import com.monsanto.brazilvaluecapture.core.base.CompanyTestData;
import com.monsanto.brazilvaluecapture.core.base.CountryTestData;
import com.monsanto.brazilvaluecapture.core.base.CropTestData;
import com.monsanto.brazilvaluecapture.core.base.TechnologyTestData;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Company;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Country;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Crop;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Technology;
import com.monsanto.brazilvaluecapture.core.foundation.RandomTestData;
import com.monsanto.brazilvaluecapture.core.foundation.model.bean.StatusEnum;
import com.monsanto.brazilvaluecapture.seedsale.product.model.bean.Brand;
import com.monsanto.brazilvaluecapture.seedsale.product.model.bean.Product;

public class ProductTestData {

	public static Product createProduct() {

		Country country = CountryTestData.createBrazil(); 
		Company company = CompanyTestData.createACompanyInBrazil();
		Crop crop = CropTestData.createCrop(company, country);
		Brand brand = BrandTestData.createBrand(company);
		Technology tech = TechnologyTestData.createTechnology(company);

		return createProduct(brand, crop, tech, StatusEnum.ACTIVE, company);

	}
	

	public static Product createProduct(Brand brand, Crop crop, Technology tech, StatusEnum status, Company company) {
		String description = RandomTestData.createRandomString(10);
		Product product = new Product(description, status, crop, tech, brand, company); 
		crop.addProduct(product);
		brand.addProduct(product);
		tech.addProduct(product);
		company.addProduct(product);

		return product;
	}
}
