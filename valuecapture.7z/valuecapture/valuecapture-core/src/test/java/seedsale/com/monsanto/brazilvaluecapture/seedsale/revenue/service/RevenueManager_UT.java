package com.monsanto.brazilvaluecapture.seedsale.revenue.service;

import java.util.ArrayList;
import java.util.List;

import junit.framework.Assert;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;
import org.mockito.internal.verification.VerificationModeFactory;

import com.monsanto.brazilvaluecapture.core.base.model.bean.Address;
import com.monsanto.brazilvaluecapture.core.base.model.bean.City;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Company;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Country;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Crop;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Document;
import com.monsanto.brazilvaluecapture.core.base.model.bean.DocumentType;
import com.monsanto.brazilvaluecapture.core.base.model.bean.OperationalYear;
import com.monsanto.brazilvaluecapture.core.base.model.bean.State;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Customer;
import com.monsanto.brazilvaluecapture.core.foundation.service.BusinessException;
import com.monsanto.brazilvaluecapture.core.revenue.model.bean.ChargeConsolidate;
import com.monsanto.brazilvaluecapture.core.revenue.model.bean.ChargeConsolidateFilter;
import com.monsanto.brazilvaluecapture.core.revenue.model.bean.ChargeConsolidateStatus;
import com.monsanto.brazilvaluecapture.core.revenue.model.bean.ChargeConsolidateType;
import com.monsanto.brazilvaluecapture.core.revenue.model.bean.ChargeConsolidateTypeEnum;
import com.monsanto.brazilvaluecapture.core.revenue.model.bean.Division;
import com.monsanto.brazilvaluecapture.core.revenue.model.bean.RevenueAccount;
import com.monsanto.brazilvaluecapture.core.revenue.model.bean.RevenueType;
import com.monsanto.brazilvaluecapture.core.revenue.model.dao.RevenueAccountDAO;
import com.monsanto.brazilvaluecapture.core.revenue.model.dao.RevenueExtractFilter;
import com.monsanto.brazilvaluecapture.core.revenue.osb.OsbPaymentService;
import com.monsanto.brazilvaluecapture.core.revenue.service.ChargeConsolidateService;
import com.monsanto.brazilvaluecapture.core.revenue.service.PaymentDataService;
import com.monsanto.brazilvaluecapture.core.revenue.service.RevenueManager;
import com.monsanto.brazilvaluecapture.core.revenue.service.impl.RevenueServiceImpl;
import com.monsanto.brazilvaluecapture.osb.its.api.InfraException;
import com.monsanto.brazilvaluecapture.osb.its.api.SapPayment;
import com.monsanto.brazilvaluecapture.pod.revenue.service.ReportOnlineBillableProvider;

public class RevenueManager_UT {

    private RevenueServiceImpl revenueServiceImpl;

    private RevenueManager revenueManager = new RevenueManager();

    private ReportOnlineBillableProvider reportOnlineBillableProvider;

    private OsbPaymentService paymentService;

    private PaymentDataService paymentDataService;

    private RevenueAccountDAO revenueAccountDAO;

    private Country country;
    private Company company;
    private Crop crop;
    private City city;
    private State state;
    private Customer customer;
    private Document document;
    private DocumentType documentType;
    private OperationalYear operationalYear;
    private Address address;

    @Before
    public void init() throws BusinessException, InfraException {
        country = new Country("BRAZIL", "BR");
        company = new Company("PD Andersen");

        crop = new Crop("SOJA", company, country);
        operationalYear = new OperationalYear("2006");

        // dependency provider
        revenueServiceImpl = new RevenueServiceImpl();
        revenueManager.setRevenueService(revenueServiceImpl);

        // dependency revenue Account Impl
        revenueAccountDAO = Mockito.mock(RevenueAccountDAO.class);
        revenueServiceImpl.setRevenueAccountDAO(revenueAccountDAO);

        paymentDataService = Mockito.mock(PaymentDataService.class);
        revenueManager.setPaymentDataService(paymentDataService);

        paymentService = Mockito.mock(OsbPaymentService.class);
        revenueManager.setPaymentService(paymentService);

        reportOnlineBillableProvider = Mockito.mock(ReportOnlineBillableProvider.class);
	    Mockito.when(reportOnlineBillableProvider.getRevenueType()).thenReturn(RevenueType.POD);

        // Customer utilized in mock revenue Account
        createCustomer();

    }

    public void createCustomer() {
        documentType = new DocumentType("CPF", country, "999.999.999-99");
        document = new Document(documentType, "467.034.162-65");
        state = new State(country, "Disney", "Dis");
        city = new City("Patopolis", state);
        address = new Address("Rua um", city, state, country, "123456789");
        customer = new Customer("Tio Patinhas", document, address, "123");
    }

    @Test(expected = IllegalArgumentException.class)
    public void test_call_osb_and_update_payment_with_privader_and_company_is_null() throws BusinessException,
            InfraException {
        revenueManager.callOsbAndUpdatePayment(null, null);
    }

    @Test
    public void test_call_osb_and_update_payment_without_divisions() throws BusinessException, InfraException {
        Mockito.when(paymentDataService.selectAllDivisionByCompany((Company) Mockito.anyObject(), Mockito.anyBoolean()))
                .thenReturn(new ArrayList<Division>());
        revenueManager.callOsbAndUpdatePayment(reportOnlineBillableProvider, company);
        Mockito.verify(paymentService, VerificationModeFactory.noMoreInteractions())
                .selectPayments(Mockito.anyString());
    }

    @Test
    public void test_call_osb_and_update_payment_without_divisions_loadAllDivisionByCompany() throws BusinessException, InfraException {
        Mockito.when(paymentDataService.loadAllDivisionByCompany((Company) Mockito.anyObject(), Mockito.anyBoolean()))
                .thenReturn(new ArrayList<Division>());
        revenueManager.callOsbAndUpdatePayment(reportOnlineBillableProvider, company);
        Mockito.verify(paymentService, VerificationModeFactory.noMoreInteractions())
                .selectPayments(Mockito.anyString());
    }

    /**
     * @throws BusinessException
     * @throws InfraException
     */
    @Test
    public void test_call_osb_and_update_payment_with_divisions_and_sappayment_and_revenue_account()
            throws BusinessException, InfraException {
        // Mock of the Division
        List<Division> listDivisions = new ArrayList<Division>();
        Division division = new Division(1L, crop, company, 9282L, "BIOTECNOLOGIA", Boolean.TRUE);
        listDivisions.add(division);

        // Mock of the SapPayments
        List<SapPayment> listPayments = new ArrayList<SapPayment>();
        SapPayment sapPayment = new SapPayment("4168", "0100039077", "2600000458", "1800000027", "2006", "2008");
        listPayments.add(sapPayment);

        // Mock of the Revenue Account
        List<RevenueAccount> listRevenueAccounts = new ArrayList<RevenueAccount>();
        RevenueAccount revenueAccount = new RevenueAccount(customer, "123456", operationalYear, RevenueType.POD,
                company, sapPayment.getDocumentNumber());
        listRevenueAccounts.add(revenueAccount);

        Mockito.when(paymentDataService.loadAllDivisionByCompany((Company) Mockito.anyObject(), Mockito.anyBoolean()))
                .thenReturn(listDivisions);

        Mockito.when(paymentService.selectPayments(division.getDivisionCode().toString())).thenReturn(listPayments);

        Mockito.when(revenueAccountDAO.getByFilter((RevenueExtractFilter) Mockito.anyObject())).thenReturn(
                listRevenueAccounts);

        revenueManager.callOsbAndUpdatePayment(reportOnlineBillableProvider, company);

        // Verify osb is call list division times
        Mockito.verify(paymentService, VerificationModeFactory.times(listDivisions.size())).selectPayments(
                Mockito.anyString());

        // Check if dao is calling for any item on list payment
        Mockito.verify(revenueAccountDAO, VerificationModeFactory.times(listPayments.size())).getByFilter(
                (RevenueExtractFilter) Mockito.anyObject());

        // Check if provider is call across revenue service
        Mockito.verify(reportOnlineBillableProvider, VerificationModeFactory.times(listRevenueAccounts.size())).pay(
                (RevenueAccount) Mockito.anyObject());

        Assert.assertEquals("Revenue account must have FI document updated.", sapPayment.getfIDocumentNumber(),
                revenueAccount.getSapDocumentFiNumber());
        Assert.assertNotNull("Payment date must be not null.", revenueAccount.getPaymentDate());
    }

    /**
     * @throws BusinessException
     * @throws InfraException
     */
    @Test
    public void test_call_osb_and_update_payment_with_revenue_type_is_not_pod() throws BusinessException,
            InfraException {
        // Mock of the Division
        List<Division> listDivisions = new ArrayList<Division>();
        Division division = new Division(1L, crop, company, 9282L, "BIOTECNOLOGIA", Boolean.TRUE);
        listDivisions.add(division);

        // Mock of the SapPayments
        List<SapPayment> listPayments = new ArrayList<SapPayment>();
        SapPayment sapPayment = new SapPayment("4168", "0100039077", "2600000458", "1800000027", "2006", "2008");
        listPayments.add(sapPayment);

        // Mock of the Revenue Account
        List<RevenueAccount> listRevenueAccounts = new ArrayList<RevenueAccount>();
        RevenueAccount revenueAccount = new RevenueAccount(customer, "123456", operationalYear,
                RevenueType.DISTRIBUTION, company, sapPayment.getDocumentNumber());
        listRevenueAccounts.add(revenueAccount);

        Mockito.when(paymentDataService.loadAllDivisionByCompany((Company) Mockito.anyObject(), Mockito.anyBoolean()))
                .thenReturn(listDivisions);

        Mockito.when(paymentService.selectPayments(division.getDivisionCode().toString())).thenReturn(listPayments);

        Mockito.when(revenueAccountDAO.getByFilter((RevenueExtractFilter) Mockito.anyObject())).thenReturn(
                listRevenueAccounts);

        Mockito.doThrow(new BusinessException("Revenue account is different from type POD."))
                .when(reportOnlineBillableProvider).pay((RevenueAccount) Mockito.anyObject());

        revenueManager.callOsbAndUpdatePayment(reportOnlineBillableProvider, company);

        // Verify osb is call list division times
        Mockito.verify(paymentService, VerificationModeFactory.times(listDivisions.size())).selectPayments(
                Mockito.anyString());

        // Check if dao is calling for any item on list payment
        Mockito.verify(revenueAccountDAO, VerificationModeFactory.times(listPayments.size())).getByFilter(
                (RevenueExtractFilter) Mockito.anyObject());

    }

    /**
     * @throws BusinessException
     * @throws InfraException
     */
    @Test
    public void test_call_osb_and_update_payment_with_revenue_type_equals_pod_and_distribution() throws BusinessException, InfraException {
        // Mock of the Division
        List<Division> listDivisions = new ArrayList<Division>();
        Division division = new Division(1L, crop, company, 9282L, "BIOTECNOLOGIA", Boolean.TRUE);
        listDivisions.add(division);

        // Mock of the SapPayments
        List<SapPayment> listPayments = new ArrayList<SapPayment>();
        SapPayment sapPayment = new SapPayment("4168", "0100039077", "2600000458", "1800000027", "2006", "2008");
        listPayments.add(sapPayment);

        // Mock of the Revenue Account
        List<RevenueAccount> listRevenueAccounts = new ArrayList<RevenueAccount>();
        RevenueAccount revenueAccountDist = new RevenueAccount(customer, "dist", operationalYear,
                RevenueType.DISTRIBUTION, company, sapPayment.getDocumentNumber());
        RevenueAccount revenueAccountPod = new RevenueAccount(customer, "pod", operationalYear, RevenueType.POD,
                company, sapPayment.getDocumentNumber());
        listRevenueAccounts.add(revenueAccountDist);
        listRevenueAccounts.add(revenueAccountPod);

        Mockito.when(paymentDataService.loadAllDivisionByCompany((Company) Mockito.anyObject(), Mockito.anyBoolean()))
                .thenReturn(listDivisions);

        Mockito.when(paymentService.selectPayments(division.getDivisionCode().toString())).thenReturn(listPayments);

        Mockito.when(revenueAccountDAO.getByFilter((RevenueExtractFilter) Mockito.anyObject())).thenReturn(
                listRevenueAccounts);

        // Mock provider dependence
        ChargeConsolidateService chargeConsolidateService = Mockito.mock(ChargeConsolidateService.class);

        List<ChargeConsolidate> charges = new ArrayList<ChargeConsolidate>();
        ChargeConsolidate charge = new ChargeConsolidate();
        charge.setChargeConsolidateType(new ChargeConsolidateType());
        charge.getChargeConsolidateType().setChargeConsTypeCode(ChargeConsolidateTypeEnum.CREDITCONSUMPTIONCHARGE);
        charge.setChargeConsolidateStatus(ChargeConsolidateStatus.DISTRACTED);
        charges.add(charge);

        Mockito.when(chargeConsolidateService.findChargeConsolidate((ChargeConsolidateFilter) Mockito.anyObject()))
                .thenReturn(charges);

        // Instanciate provider
        reportOnlineBillableProvider = new ReportOnlineBillableProvider();
        reportOnlineBillableProvider.setChargeConsolidateService(chargeConsolidateService);

        revenueManager.callOsbAndUpdatePayment(reportOnlineBillableProvider, company);
            
        // Verify osb is call list division times
        Mockito.verify(paymentService, VerificationModeFactory.times(listDivisions.size())).selectPayments(
                Mockito.anyString());

        // Check if dao is calling for any item on list payment
        Mockito.verify(revenueAccountDAO, VerificationModeFactory.times(listPayments.size())).getByFilter(
                (RevenueExtractFilter) Mockito.anyObject());

        // Check if provider is call across revenue service
        Mockito.verify(chargeConsolidateService, VerificationModeFactory.times(1)).saveChargeConsolidate(
                (ChargeConsolidate) Mockito.anyObject());

        Assert.assertEquals("Revenue account must have FI document updated.", sapPayment.getfIDocumentNumber(),
                revenueAccountPod.getSapDocumentFiNumber());
        Assert.assertNotNull("Payment date must be not null.", revenueAccountPod.getPaymentDate());
    }
    
}
