package com.monsanto.brazilvaluecapture.seedsale.bonus.bulkimport;

import com.google.common.collect.Lists;
import com.monsanto.brazilvaluecapture.bonus.bulkimport.model.dao.BonusDAO;
import com.monsanto.brazilvaluecapture.bonus.bulkimport.model.dao.impl.BonusDAOImpl;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Company;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Country;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Crop;
import com.monsanto.brazilvaluecapture.core.base.model.bean.OperationalYear;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Customer;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Technology;
import com.monsanto.brazilvaluecapture.core.grower.model.bean.*;
import com.monsanto.brazilvaluecapture.core.wsiconsole.dao.impl.BaseHibernateUnitTest;
import com.monsanto.brazilvaluecapture.seedsale.bonus.BonusConsumptionFilter;
import com.monsanto.brazilvaluecapture.seedsale.bonus.bulkimport.model.bean.BonusAccount;
import com.monsanto.brazilvaluecapture.seedsale.bonus.bulkimport.model.bean.BonusEntry;
import com.monsanto.brazilvaluecapture.seedsale.bonus.bulkimport.model.bean.BonusTransaction;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import static org.fest.assertions.Assertions.assertThat;
import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.*;

class TestBonusFilter implements BonusConsumptionFilter {

    private List<Customer> matrixList;

    @Override
    public Company getCompany() {
        return null;
    }

    @Override
    public Crop getCrop() {
        return null;
    }

    @Override
    public Technology getTechnology() {
        return null;
    }

    @Override
    public OperationalYear getOperationalYear() {
        return null;
    }

    @Override
    public Grower getGrower() {
        return null;
    }

    @Override
    public AgreementTemplateType getAgreementTemplateType() {
        return null;
    }

    @Override
    public Date getDateFrom() {
        return null;
    }

    @Override
    public Date getDateTo() {
        return null;
    }

    @Override
    public Long getTermNo() {
        return null;
    }

    @Override
    public Customer getHeadOffice() {
        return null;
    }

    @Override
    public List<Customer> getMatrixList() {
        return matrixList;
    }

    public void setMatrixList(List<Customer> matrixList) {
        this.matrixList = matrixList;
    }

    @Override
    public BonusConsumptionStatusEnum getBonusConsumptionStatus() {
        return null;
    }
}

public class BonusDAOImpl_UT extends BaseHibernateUnitTest {

    private BonusDAO bonusDAO;
    private BonusConsumptionFilter filter;
    private BonusConsumptionFilter notReversibleFilter;
    private BonusConsumptionFilter emptyFilter = new BonusConsumptionFilter() {

        @Override
        public Company getCompany() {
            return null;
        }

        @Override
        public Crop getCrop() {
            return null;
        }

        @Override
        public Technology getTechnology() {
            return null;
        }

        @Override
        public OperationalYear getOperationalYear() {
            return null;
        }

        @Override
        public Grower getGrower() {
            return null;
        }

        @Override
        public AgreementTemplateType getAgreementTemplateType() {
            return null;
        }

        @Override
        public Date getDateFrom() {
            return null;
        }

        @Override
        public Date getDateTo() {
            return null;
        }

        @Override
        public Long getTermNo() {
            return null;
        }

        @Override
        public Customer getHeadOffice() {
            return null;
        }

        @Override
        public List<Customer> getMatrixList() {
            return Lists.newArrayList(new Customer());
        }

        @Override
        public BonusConsumptionStatusEnum getBonusConsumptionStatus() {
            return null;
        }
    };

    @Before
    public void setUp() {
        bonusDAO = new BonusDAOImpl(sessionFactory);
        final Company company = new Company("Company");
        final Country country = new Country("Cuba", "CU");
        final Crop crop = new Crop("Crop", company, country);
        final Technology technology = new Technology("Tech", company);
        final OperationalYear operationalYear = new OperationalYear("2000");
        final Grower grower = new Grower();
        final AgreementTemplateType agreementTemplateType = new AgreementTemplateType(crop, company, technology, "ATT");
        final Customer headOffice = new Customer();

        filter = new BonusConsumptionFilter() {

            private Date dateFrom = new Date();

            @Override
            public Company getCompany() {
                return company;
            }

            @Override
            public Crop getCrop() {
                return crop;
            }

            @Override
            public Technology getTechnology() {
                return technology;
            }

            @Override
            public OperationalYear getOperationalYear() {
                return operationalYear;
            }

            @Override
            public Grower getGrower() {
                return grower;
            }

            @Override
            public AgreementTemplateType getAgreementTemplateType() {
                return agreementTemplateType;
            }

            @Override
            public Date getDateFrom() {
                return dateFrom;
            }

            @Override
            public Date getDateTo() {
                return new Date(dateFrom.getTime() + 20);
            }

            @Override
            public Long getTermNo() {
                return 10L;
            }

            @Override
            public Customer getHeadOffice() {
                return headOffice;
            }

            @Override
            public List<Customer> getMatrixList() {
                return null;
            }

            @Override
            public BonusConsumptionStatusEnum getBonusConsumptionStatus() {
                return BonusConsumptionStatusEnum.REVERSED;
            }
        };

        notReversibleFilter = new BonusConsumptionFilter() {

            private Date dateFrom = new Date();

            @Override
            public Company getCompany() {
                return company;
            }

            @Override
            public Crop getCrop() {
                return crop;
            }

            @Override
            public Technology getTechnology() {
                return technology;
            }

            @Override
            public OperationalYear getOperationalYear() {
                return operationalYear;
            }

            @Override
            public Grower getGrower() {
                return grower;
            }

            @Override
            public AgreementTemplateType getAgreementTemplateType() {
                return agreementTemplateType;
            }

            @Override
            public Date getDateFrom() {
                return dateFrom;
            }

            @Override
            public Date getDateTo() {
                return new Date(dateFrom.getTime() + 20);
            }

            @Override
            public Long getTermNo() {
                return 10L;
            }

            @Override
            public Customer getHeadOffice() {
                return headOffice;
            }

            @Override
            public List<Customer> getMatrixList() {
                return null;
            }

            @Override
            public BonusConsumptionStatusEnum getBonusConsumptionStatus() {
                return BonusConsumptionStatusEnum.OPENED;
            }
        };
    }

    @Test
    public void createBonusTransaction() {
        //@Given
        final Date today = new Date();
        BonusTransaction bonusTransaction = new BonusTransaction();
        bonusTransaction.setTransactionDate(today);
        bonusTransaction.setCode(null);
        bonusTransaction.setTransactionType(BonusTransaction.Type.GENERATION);

        //@When
        bonusDAO.save(bonusTransaction);

        //@Should
        verify(sessionFactory, times(1)).getCurrentSession();
        verify(session, times(1)).saveOrUpdate(bonusTransaction);
    }

    @Test
    public void createBonusEntry() {
        //@Given
        BonusEntry bonusEntry = new BonusEntry();
        bonusEntry.setBonusAccount(new BonusAccount());
        bonusEntry.setBonusTransaction(new BonusTransaction());
        bonusEntry.setValue(BigDecimal.TEN);

        //@When
        bonusDAO.save(bonusEntry);

        //@Should
        verify(sessionFactory, times(1)).getCurrentSession();
        verify(session, times(1)).saveOrUpdate(bonusEntry);
    }

    @Test
    public void testFindBonusConsumptionsQueriesForCompanyAndCrop_GivenAnyFilter() {
        //@When
        bonusDAO.findBonusConsumptions(filter);

        //@Should
        ArgumentCaptor<String> queryCaptor = ArgumentCaptor.forClass(String.class);
        verify(session).createQuery(queryCaptor.capture());
        final String queryString = queryCaptor.getValue();
        assertThat(queryString).contains("select bc from BonusConsumption bc ").
                contains(" where technology.company = :company and agreementTemplateType.crop = :crop ");
        verify(query).setParameter("company", filter.getCompany());
        verify(query).setParameter("crop", filter.getCrop());
        verify(query).list();
    }

    @Test
    public void testFindBonusConsumptionsQueriesForHeadOffice_GivenAFilterWithHeadOffice() {
        //@When
        bonusDAO.findBonusConsumptions(filter);

        //@Should
        ArgumentCaptor<String> queryCaptor = ArgumentCaptor.forClass(String.class);
        verify(session).createQuery(queryCaptor.capture());
        final String queryString = queryCaptor.getValue();
        assertThat(queryString).contains("headOffice = :headOffice ");
        verify(query).setParameter("headOffice", filter.getHeadOffice());
    }

    @Test
    public void testFindBonusConsumptionsWontQueriesForPartner_GivenAFilterWithoutPartner() {
        //@When
        bonusDAO.findBonusConsumptions(emptyFilter);

        //@Should
        ArgumentCaptor<String> queryCaptor = ArgumentCaptor.forClass(String.class);
        verify(session).createQuery(queryCaptor.capture());
        final String queryString = queryCaptor.getValue();
        assertThat(queryString).doesNotContain("headOffice = :headOffice ");
        verify(query, never()).setParameter("headOffice", filter.getHeadOffice());
    }

    @Test
    public void testFindBonusConsumptionsQueriesForTechnology_GivenAFilterWithTechnology() {
        //@When
        bonusDAO.findBonusConsumptions(filter);

        //@Should
        ArgumentCaptor<String> queryCaptor = ArgumentCaptor.forClass(String.class);
        verify(session).createQuery(queryCaptor.capture());
        final String queryString = queryCaptor.getValue();
        assertThat(queryString).contains(" technology = :technology ");
        verify(query).setParameter("technology", filter.getTechnology());
    }

    @Test
    public void testFindBonusConsumptionsWontQueriesForTechnology_GivenAFilterWithoutTechnology() {
        //@When invoked with empty a filter with empty technology
        bonusDAO.findBonusConsumptions(emptyFilter);

        //@Should
        ArgumentCaptor<String> queryCaptor = ArgumentCaptor.forClass(String.class);
        verify(session).createQuery(queryCaptor.capture());
        final String queryString = queryCaptor.getValue();
        assertThat(queryString).doesNotContain(" technology = :technology ");
        verify(query, never()).setParameter("technology", filter.getTechnology());
    }

    @Test
    public void testFindBonusConsumptionsQueriesForOperationalYear_GivenAFilterWithOperationalYear() {
        //@When
        bonusDAO.findBonusConsumptions(filter);

        //@Should
        ArgumentCaptor<String> queryCaptor = ArgumentCaptor.forClass(String.class);
        verify(session).createQuery(queryCaptor.capture());
        final String queryString = queryCaptor.getValue();
        assertThat(queryString).contains(" operationalYear = :operationalYear ");
        verify(query).setParameter("operationalYear", filter.getOperationalYear());
    }

    @Test
    public void testFindBonusConsumptionsWontQueriesoperationalYear_GivenAFilterWithoutOperationalYear() {
        //@When invoked with empty a filter with empty technology
        bonusDAO.findBonusConsumptions(emptyFilter);

        //@Should
        ArgumentCaptor<String> queryCaptor = ArgumentCaptor.forClass(String.class);
        verify(session).createQuery(queryCaptor.capture());
        final String queryString = queryCaptor.getValue();
        assertThat(queryString).doesNotContain(" operationalYear = :operationalYear ");
        verify(query, never()).setParameter("technology", filter.getOperationalYear());
    }

    @Test
    public void testFindBonusConsumptionsQueriesForGrower_GivenAFilterWithGrower() {
        //@When
        bonusDAO.findBonusConsumptions(filter);

        //@Should
        ArgumentCaptor<String> queryCaptor = ArgumentCaptor.forClass(String.class);
        verify(session).createQuery(queryCaptor.capture());
        final String queryString = queryCaptor.getValue();
        assertThat(queryString).contains(" and grower = :grower ");
        verify(query).setParameter("grower", filter.getGrower());
    }

    @Test
    public void testFindBonusConsumptionsWontQueriesGrower_GivenAFilterWithoutGrower() {
        //@When invoked with empty a filter with empty technology
        bonusDAO.findBonusConsumptions(emptyFilter);

        //@Should
        ArgumentCaptor<String> queryCaptor = ArgumentCaptor.forClass(String.class);
        verify(session).createQuery(queryCaptor.capture());
        final String queryString = queryCaptor.getValue();
        assertThat(queryString).doesNotContain(" and grower = :grower ");
        verify(query, never()).setParameter("grower", filter.getGrower());
    }

    @Test
    public void testFindBonusConsumptionsQueriesForAgreementTemplateType_GivenAFilterWithAgreementTemplateType() {
        //@When
        bonusDAO.findBonusConsumptions(filter);

        //@Should
        ArgumentCaptor<String> queryCaptor = ArgumentCaptor.forClass(String.class);
        verify(session).createQuery(queryCaptor.capture());
        final String queryString = queryCaptor.getValue();
        assertThat(queryString).contains(" and grower in ( select a.grower from Agreement a where a.agreementTemplate.agreementTemplateType = :agreementTemplateType) ");
        verify(query).setParameter("agreementTemplateType", filter.getAgreementTemplateType());
    }

    @Test
    public void testFindBonusConsumptionsWontQueriesForAgreementTemplateType_GivenAFilterWithoutAgreementTemplateType() {
        //@When
        bonusDAO.findBonusConsumptions(emptyFilter);

        //@Should
        ArgumentCaptor<String> queryCaptor = ArgumentCaptor.forClass(String.class);
        verify(session).createQuery(queryCaptor.capture());
        final String queryString = queryCaptor.getValue();
        assertThat(queryString).doesNotContain(" and grower in( select g from Agreement a where a.agreementTemplate.agreementTemplateType = :agreementTemplateType) ");
        verify(query, never()).setParameter("agreementTemplateType", filter.getAgreementTemplateType());
    }

    @Test
    public void testFindBonusConsumptionsQueriesForConsumptionDateGreatThanDateFrom_GivenAFilterWithDateFrom() {
        //@When
        bonusDAO.findBonusConsumptions(getFilterWithOnlyDateFrom());

        //@Should
        ArgumentCaptor<String> queryCaptor = ArgumentCaptor.forClass(String.class);
        verify(session).createQuery(queryCaptor.capture());
        final String queryString = queryCaptor.getValue();
        assertThat(queryString).contains(" and consumptionDate >= :dateFrom ");
    }

    @Test
    public void createBonusConsumptionReversal() {
        //@Given
        BonusConsumptionReversal bonusConsumptionReversal = new BonusConsumptionReversal();
        BonusConsumption bonusConsumption = new BonusConsumption();
        bonusConsumptionReversal.setBonusConsumption(bonusConsumption);

        //@When
        bonusDAO.save(bonusConsumptionReversal);

        //@Should
        verify(sessionFactory, times(1)).getCurrentSession();
        verify(session, times(1)).saveOrUpdate(bonusConsumptionReversal);
    }

    @Test
    public void createBonusConsumptionPayment() {
        //@Given
        BonusConsumptionPayment bonusConsumptionPayment = new BonusConsumptionPayment();
        BonusConsumption bonusConsumption = new BonusConsumption();
        bonusConsumptionPayment.setBonusConsumption(bonusConsumption);

        //@When
        bonusDAO.save(bonusConsumptionPayment);

        //@Should
        verify(sessionFactory, times(1)).getCurrentSession();
        verify(session, times(1)).saveOrUpdate(bonusConsumptionPayment);
    }

    private BonusConsumptionFilter getFilterWithOnlyDateFrom() {
        return new BonusConsumptionFilter() {
            @Override
            public Company getCompany() {
                return null;
            }

            @Override
            public Crop getCrop() {
                return null;
            }

            @Override
            public Technology getTechnology() {
                return null;
            }

            @Override
            public OperationalYear getOperationalYear() {
                return null;
            }

            @Override
            public Grower getGrower() {
                return null;
            }

            @Override
            public AgreementTemplateType getAgreementTemplateType() {
                return null;
            }

            @Override
            public Date getDateFrom() {
                return new Date();
            }

            @Override
            public Date getDateTo() {
                return null;
            }

            @Override
            public Long getTermNo() {
                return null;
            }

            @Override
            public Customer getHeadOffice() {
                return null;
            }

            @Override
            public List<Customer> getMatrixList() {
                return null;
            }

            @Override
            public BonusConsumptionStatusEnum getBonusConsumptionStatus() {
                return null;
            }
        };
    }

    @Test
    public void testFindBonusConsumptionsWontQueriesForConsumptionDateGreatThanDateFrom_GivenAFilterWithoutDateFrom() {
        //@When
        bonusDAO.findBonusConsumptions(emptyFilter);

        //@Should
        ArgumentCaptor<String> queryCaptor = ArgumentCaptor.forClass(String.class);
        verify(session).createQuery(queryCaptor.capture());
        final String queryString = queryCaptor.getValue();
        assertThat(queryString).doesNotContain(" and consumptionDate >= :dateFrom ");
        verify(query, never()).setParameter("dateFrom", filter.getDateFrom());
    }

    @Test
    public void testFindBonusConsumptionsQueriesForConsumptionDateLessThanDateTo_GivenAFilterWithDateTo() {
        //@When
        bonusDAO.findBonusConsumptions(getFilterWithOnlyDateTo());

        //@Should
        ArgumentCaptor<String> queryCaptor = ArgumentCaptor.forClass(String.class);
        verify(session).createQuery(queryCaptor.capture());
        final String queryString = queryCaptor.getValue();
        assertThat(queryString).contains(" and consumptionDate <= :dateTo ");
    }

    private BonusConsumptionFilter getFilterWithOnlyDateTo() {
        return new BonusConsumptionFilter() {
            @Override
            public Company getCompany() {
                return null;
            }

            @Override
            public Crop getCrop() {
                return null;
            }

            @Override
            public Technology getTechnology() {
                return null;
            }

            @Override
            public OperationalYear getOperationalYear() {
                return null;
            }

            @Override
            public Grower getGrower() {
                return null;
            }

            @Override
            public AgreementTemplateType getAgreementTemplateType() {
                return null;
            }

            @Override
            public Date getDateFrom() {
                return null;
            }

            @Override
            public Date getDateTo() {
                return new Date();
            }

            @Override
            public Long getTermNo() {
                return null;
            }

            @Override
            public Customer getHeadOffice() {
                return null;
            }

            @Override
            public List<Customer> getMatrixList() {
                return null;
            }

            @Override
            public BonusConsumptionStatusEnum getBonusConsumptionStatus() {
                return null;
            }
        };
    }

    @Test
    public void testFindBonusConsumptionsWontQueriesForConsumptionDateLessThanDateTo_GivenAFilterWithoutDateTo() {
        //@When
        bonusDAO.findBonusConsumptions(emptyFilter);

        //@Should
        ArgumentCaptor<String> queryCaptor = ArgumentCaptor.forClass(String.class);
        verify(session).createQuery(queryCaptor.capture());
        final String queryString = queryCaptor.getValue();
        assertThat(queryString).doesNotContain(" and consumptionDate <= :dateTo ");
        verify(query, never()).setParameter("dateTo", filter.getDateTo());
    }

    @Test
    public void testFindBonusConsumptionsQueriesForConsumptionDateInBetweenDateFromAndDateDo_GivenAFilterWithDateFromAndDateTo() {
        //@When
        bonusDAO.findBonusConsumptions(filter);

        //@Should
        ArgumentCaptor<String> queryCaptor = ArgumentCaptor.forClass(String.class);
        verify(session).createQuery(queryCaptor.capture());
        final String queryString = queryCaptor.getValue();
        assertThat(queryString).contains(" and consumptionDate between :dateFrom and :dateTo ");
        verify(query).setParameter("dateFrom", filter.getDateFrom());
        verify(query).setParameter("dateTo", filter.getDateTo());
    }

    @Test
    public void testFindBonusConsumptionsWontQueriesForConsumptionDateLessThanDateTo_GivenAFilterWithDateFromAndDateTo() {
        //@When
        bonusDAO.findBonusConsumptions(filter);

        //@Should
        ArgumentCaptor<String> queryCaptor = ArgumentCaptor.forClass(String.class);
        verify(session).createQuery(queryCaptor.capture());
        final String queryString = queryCaptor.getValue();
        assertThat(queryString).doesNotContain(" and consumptionDate >= :dateFrom ");
        assertThat(queryString).doesNotContain(" and consumptionDate <= :dateTo ");
    }

    @Test
    public void testFindBonusConsumptionsQueriesForTermNo_GivenAFilterWithTermNo() {
        //@When
        bonusDAO.findBonusConsumptions(filter);

        //@Should
        ArgumentCaptor<String> queryCaptor = ArgumentCaptor.forClass(String.class);
        verify(session).createQuery(queryCaptor.capture());
        final String queryString = queryCaptor.getValue();
        assertThat(queryString).contains(" and id = :termNo ");
        verify(query).setParameter("termNo", filter.getTermNo());
    }

    @Test
    public void testFindBonusConsumptionsWontQueriesForTermNo_GivenAFilterWithoutTermNo() {
        //@When
        bonusDAO.findBonusConsumptions(emptyFilter);

        //@Should
        ArgumentCaptor<String> queryCaptor = ArgumentCaptor.forClass(String.class);
        verify(session).createQuery(queryCaptor.capture());
        final String queryString = queryCaptor.getValue();
        assertThat(queryString).doesNotContain(" and id = :termNo ");
        verify(query, never()).setParameter("termNo", filter.getTermNo());
    }

    @Test
    public void testFindBonusConsumptionsQueriesForRevertedConsumptions_GivenAFilterRevertedTrue() {
        //@Given
        bonusDAO.findBonusConsumptions(filter);

        //@Should
        ArgumentCaptor<String> queryCaptor = ArgumentCaptor.forClass(String.class);
        verify(session).createQuery(queryCaptor.capture());
        final String queryString = queryCaptor.getValue();
        assertThat(queryString).contains(" and bonusConsumptionStatus = :bonusConsumptionStatus ");
    }

    @Test
    public void testFindBonusConsumptionsWontQueriesForConsumptionsStatus_GivenNoStatus() {
        //@Given
        bonusDAO.findBonusConsumptions(emptyFilter);

        //@Should
        ArgumentCaptor<String> queryCaptor = ArgumentCaptor.forClass(String.class);
        verify(session).createQuery(queryCaptor.capture());
        final String queryString = queryCaptor.getValue();
        assertThat(queryString).doesNotContain(" and bonusConsumptionStatus = :bonusConsumptionStatus ");
    }

    @Test
    public void testFindBonusConsumptionsWillQueryAllRegisters_GivenAFilterWithoutInformationAboutReversedStatus() {
        //@Given
        bonusDAO.findBonusConsumptions(emptyFilter);

        //@Should
        ArgumentCaptor<String> queryCaptor = ArgumentCaptor.forClass(String.class);
        verify(session).createQuery(queryCaptor.capture());
        final String queryString = queryCaptor.getValue();
        assertThat(queryString).doesNotContain(" and reversedDate is null ");
        assertThat(queryString).doesNotContain(" and reversedDate is not null ");
    }

    @Test
    public void testFindBonusConsumptionWillQueryAllMatrix_WhenMatrixIsNull() {
        //@When
        bonusDAO.findBonusConsumptions(emptyFilter);

        //@Should
        ArgumentCaptor<String> queryCaptor = ArgumentCaptor.forClass(String.class);
        verify(session).createQuery(queryCaptor.capture());
        final String queryString = queryCaptor.getValue();
        assertThat(queryString).contains(" and headOffice in (:matrixList) ");
        verify(query).setParameterList("matrixList", emptyFilter.getMatrixList());
    }

    @Test
    public void testFindBonusConsumptionWillNotQueryAllMatrix_WhenMatrixListIsNull() {
        //@Given a filter with matrixList NULL
        TestBonusFilter filter = new TestBonusFilter();
        filter.setMatrixList(null);

        //@When
        bonusDAO.findBonusConsumptions(filter);

        //@Should
        ArgumentCaptor<String> queryCaptor = ArgumentCaptor.forClass(String.class);
        verify(session).createQuery(queryCaptor.capture());
        final String queryString = queryCaptor.getValue();
        assertThat(queryString).doesNotContain(" and headOffice in (:matrixList) ");
        verify(query, never()).setParameterList("matrixList", filter.getMatrixList());
    }

    @Test
    public void testFindBonusConsumptionWillNotQueryAllMatrix_WhenMatrixListIsEmpty() {
        //@Given a filter with matrixList NULL
        TestBonusFilter filter = new TestBonusFilter();
        filter.setMatrixList(new ArrayList<Customer>());

        //@When
        bonusDAO.findBonusConsumptions(filter);

        //@Should
        ArgumentCaptor<String> queryCaptor = ArgumentCaptor.forClass(String.class);
        verify(session).createQuery(queryCaptor.capture());
        final String queryString = queryCaptor.getValue();
        assertThat(queryString).doesNotContain(" and headOffice in (:matrixList) ");
        verify(query, never()).setParameterList("matrixList", filter.getMatrixList());
    }

    @Test
    public void testFindBonusConsumptionsEligibleForServiceFeeReturnsBonusConsumptions_whenDaoInvoked() {
        ArgumentCaptor<String> queryCaptor = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<List> argsCaptor = ArgumentCaptor.forClass(List.class);
        when(session.createQuery(queryCaptor.capture())).thenReturn(query);
        when(query.setParameterList(eq("availableStatus"), argsCaptor.capture())).thenReturn(query);

        bonusDAO.findBonusConsumptionsEligibleForServiceFee();

        assertEquals(queryCaptor.getValue(), " from BonusConsumption bonus where bonus.bonusConsumptionStatus in (:availableStatus) ");
        assertThat(argsCaptor.getValue()).containsExactly(BonusConsumptionStatusEnum.VOUCHER_RECEIVED, BonusConsumptionStatusEnum.PARTIALLY_PAID, BonusConsumptionStatusEnum.PARTIALLY_PAID_REVERSED);
    }

}
