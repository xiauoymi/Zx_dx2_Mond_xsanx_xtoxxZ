package com.monsanto.brazilvaluecapture.seedsale.sale.service;

import java.math.BigDecimal;
import java.util.Calendar;
import java.util.List;

import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.SalePrice;
import junit.framework.Assert;

import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.monsanto.brazilvaluecapture.core.base.SystemTestFixture;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Address;
import com.monsanto.brazilvaluecapture.core.base.model.bean.BillingAddress;
import com.monsanto.brazilvaluecapture.core.base.model.bean.BusinessAddress;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Customer;
import com.monsanto.brazilvaluecapture.core.foundation.RandomTestData;
import com.monsanto.brazilvaluecapture.core.foundation.model.bean.StatusEnum;
import com.monsanto.brazilvaluecapture.core.foundation.test.AbstractServiceIntegrationTests;
import com.monsanto.brazilvaluecapture.core.grower.PlayerTestData;
import com.monsanto.brazilvaluecapture.core.grower.model.bean.Grower;
import com.monsanto.brazilvaluecapture.seedsale.harvest.HarvestTestData;
import com.monsanto.brazilvaluecapture.seedsale.harvest.model.bean.Harvest;
import com.monsanto.brazilvaluecapture.seedsale.product.ProductTestData;
import com.monsanto.brazilvaluecapture.seedsale.product.model.bean.Product;
import com.monsanto.brazilvaluecapture.seedsale.sale.SaleTestFixture;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.CsvSale;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.Sale;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.SaleItem;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.Sale.SaleTypeEnum;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.dao.SaleDAO;
import com.monsanto.brazilvaluecapture.seedsale.template.SaleTemplateTestData;
import com.monsanto.brazilvaluecapture.seedsale.template.model.bean.SaleTemplate;

public class SaleDAO_AT extends AbstractServiceIntegrationTests {

	@Autowired
	private SaleDAO saleDAO;
	private Customer savedCustomer;
	private Grower savedGrower;
	private Product savedProduct;
	private SaleTemplate savedSaleTemplate;
	private CsvSale savedCsvSale;
	private CsvSale savedCsvSaleWithoutInvoice;
    private SaleTestData saleFactory;
	@Before
	public void init() {
		systemTestFixture = new SystemTestFixture(this);

		Address a = PlayerTestData.createAddress(systemTestFixture.matoGrossoDoSul, systemTestFixture.vilaNova, systemTestFixture.brazil);

		savedCustomer = new Customer(RandomTestData.createRandomString(5), PlayerTestData.createDocument(systemTestFixture.documentCnpj, "222222"), a, RandomTestData.createRandomString(5));

		BillingAddress bA = PlayerTestData.createBillingAddress(systemTestFixture.matoGrossoDoSul, systemTestFixture.vilaNova, systemTestFixture.brazil);
		BusinessAddress buA = PlayerTestData.createBusinessAddress(systemTestFixture.matoGrossoDoSul, systemTestFixture.vilaNova, systemTestFixture.brazil);
		savedGrower = PlayerTestData.createGrower(PlayerTestData.createDocument(systemTestFixture.documentCnpj, "222222"), bA, buA);
		savedProduct = ProductTestData.createProduct(this.systemTestFixture.monsoy, this.systemTestFixture.soy, this.systemTestFixture.intacta, StatusEnum.ACTIVE, systemTestFixture.monsantoBr);

		Harvest harvest = HarvestTestData.createHarvest(systemTestFixture.soy, systemTestFixture.operationalYearOf2011, systemTestFixture.monsantoBr);
		saveAndFlush(harvest);
		savedSaleTemplate = SaleTemplateTestData.createSaleTemplateTypeSeedSale(harvest);

		saveAndFlush(savedCustomer);
		saveAndFlush(savedGrower);
		saveAndFlush(savedProduct);
		saveAndFlush(savedSaleTemplate);

        saleFactory = new SaleTestData(systemTestFixture.regionSaoPaulo2012);

		Assert.assertNotNull("Customer was not saved.", savedCustomer.getId());
		Assert.assertNotNull("Grower was not saved.", savedGrower.getId());
		Assert.assertNotNull("Product was not saved.", savedProduct.getId());
		Assert.assertNotNull("SaleTemplate was not saved.", savedSaleTemplate.getId());
	}

	@Test
	public void sale_with_one_item_should_be_success() {
		Sale sale = saleFactory.createSale(savedCustomer, savedGrower, SaleTypeEnum.SALE_SEED);
		SaleTestData.createSaleItem(sale, savedSaleTemplate, savedProduct, null);

		Sale savedSale = saleDAO.save(sale);

		Grower theGrower = savedSale.getGrower();
		Customer theCustomer = savedSale.getCustomer();
		SaleItem theItem = savedSale.getItems().iterator().next();

		Assert.assertNotNull("Saved sale should have an id.", savedSale.getId());
		Assert.assertNotNull("Saved sale should have a saved grower", theGrower.getId());
		Assert.assertNotNull("Saved sale should have a saved distributor", theCustomer.getId());
		assertSaleItem(theItem);
	}

	@Test
	public void given_a_saved_direct_sale_without_invoice_number_when_i_getAllDirectSale_should_be_returned_a_csv_sale() {
		
		createAndSaveCsvSaleWithoutInvoice();
		List<CsvSale> directSales = saleDAO.getAllDirectSale();
		CsvSale saleWithoutInvoice = directSales.iterator().next();
		
		Assert.assertFalse("Should not have a empty list", directSales.isEmpty());
		Assert.assertEquals("Should be the same sale", savedCsvSaleWithoutInvoice, saleWithoutInvoice);
	}

	@Ignore
	public void given_a_saved_direct_sale_with_invoice_number_when_i_getAllDirectSale_should_be_returned_a_csv_sale() {
		createAndSaveCsvSaleWithInvoice();
		List<CsvSale> directSales = saleDAO.getAllDirectSale();
		CsvSale saleWithInvoice = directSales.iterator().next();

		Assert.assertFalse("Should not have a empty list", directSales.isEmpty());
		Assert.assertEquals("Should be the same sale", savedCsvSale, saleWithInvoice);
	}

	private void createAndSaveCsvSaleWithoutInvoice() {
		savedCsvSaleWithoutInvoice = CsvTestData.createSaleCsvWithoutInvoice();
		savedCsvSaleWithoutInvoice.setCreationDate(SaleTestFixture.DATE_NOW);
		saveAndFlush(savedCsvSaleWithoutInvoice);
	}

	private void createAndSaveCsvSaleWithInvoice() {
		savedCsvSale = CsvTestData.createSaleCsv();
		savedCsvSale.setCreationDate(SaleTestFixture.DATE_NOW);
		saveAndFlush(savedCsvSale);
	}

	private void assertSaleItem(SaleItem saleItem) {
		Assert.assertNotNull("SaleItem should have an id.", saleItem.getId());
		Assert.assertNotNull("SaleItem should have a saved product", saleItem.getProduct().getId());
		Assert.assertNotNull("SaleItem should have a saved saleTemplate", saleItem.getSaleTemplate().getId());
		Assert.assertNotNull("SaleItem must be a child of a sale", saleItem.getSale().getId());
		Assert.assertNotNull(saleItem.getPlantability());
		Assert.assertNotNull(saleItem.getPriceQuantity());
		Assert.assertNotNull(saleItem.getProductivityValue());
		Assert.assertNotNull(saleItem.getSoldQuantity());
		Assert.assertNotNull(saleItem.getTotalCreditValue());
		Assert.assertNotNull(saleItem.getTotalRoyaltyValue());
	}

	public static class CsvTestData {

		public static CsvSale createSaleCsv() {
			CsvSale csvSale = new CsvSale();

			csvSale.setCompany(RandomTestData.createRandomString(200));
			csvSale.setCreationDate(SaleTestFixture.DATE_NOW);
			csvSale.setCrop(RandomTestData.createRandomString(200));
			csvSale.setCustomerDocument(RandomTestData.createRandomString(50));
			csvSale.setCustomerDocumentType(RandomTestData.createRandomString(200));
			csvSale.setGrowerDocument(RandomTestData.createRandomString(50));
			csvSale.setGrowerDocumentType(RandomTestData.createRandomString(200));
			csvSale.setHeadOfficeDocument(RandomTestData.createRandomString(50));
			csvSale.setHeadOfficeDocumentType(RandomTestData.createRandomString(200));
			csvSale.setDueDate(SaleTestFixture.DECEMBER);
			csvSale.setHarvest(RandomTestData.createRandomString(200));
			csvSale.setInvoiceDate(SaleTestFixture.JANUARY);
			csvSale.setInvoiceNumber(RandomTestData.createRandomString(200));
			csvSale.setOperationalYear(RandomTestData.createRandomString(200));
			csvSale.setPlantability(RandomTestData.createRandomString(200));
			csvSale.setPriceQuantity(BigDecimal.TEN);
			csvSale.setProductCode(RandomTestData.createRandomLong());
			csvSale.setProductivityValue(RandomTestData.createRandomLong());
			csvSale.setSaleNote(RandomTestData.createRandomString(4000));
			csvSale.setSaleTemplate(RandomTestData.createRandomString(200));
			csvSale.setSoldQuantity(RandomTestData.createRandomLong());
			csvSale.setState(RandomTestData.createRandomString(200));

			return csvSale;
		}

		public static CsvSale createSaleCsvWithoutInvoice() {
			CsvSale csvSale = createSaleCsv();
			csvSale.setInvoiceNumber(null);
			csvSale.setInvoiceDate(null);

			return csvSale;
		}
	}

    private SalePrice createSalePrice(BigDecimal value) {
        SalePrice sp = new SalePrice();
        sp.setCode("code");
        sp.setCurrency("curr");
        sp.setDescription("desc");
        sp.setKind("kind");
        sp.setOrderSAPId(123L);
        sp.setValidToDate(Calendar.getInstance().getTime());
        return sp;
    }

    private Sale createWithPrices() {
        Sale sale = saleFactory.createSale(savedCustomer, savedGrower, SaleTypeEnum.SALE_SEED);
        sale.addSalePrice(createSalePrice(new BigDecimal(50)));
        sale.addSalePrice(createSalePrice(new BigDecimal(70)));
        return sale;
    }

    @Test
    public void testInsertWithPrices() {
        Sale sale = createWithPrices();
        Sale saleSaved = saleDAO.save(sale);
        Assert.assertNotNull(saleSaved.getSalePrices().iterator().next().getId());
    }

}
