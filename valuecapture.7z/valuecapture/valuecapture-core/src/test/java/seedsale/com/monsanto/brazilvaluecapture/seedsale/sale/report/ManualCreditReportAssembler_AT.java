package com.monsanto.brazilvaluecapture.seedsale.sale.report;

import com.monsanto.brazilvaluecapture.core.account.model.bean.ManualCredit;
import com.monsanto.brazilvaluecapture.core.account.model.bean.ManualCreditTransactionType;
import com.monsanto.brazilvaluecapture.core.account.model.dao.ManualCreditFilter;
import com.monsanto.brazilvaluecapture.core.account.service.impl.AccountService;
import com.monsanto.brazilvaluecapture.core.base.SystemTestFixture;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Crop;
import com.monsanto.brazilvaluecapture.core.base.model.bean.OperationalYear;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Technology;
import com.monsanto.brazilvaluecapture.core.foundation.service.BusinessException;
import com.monsanto.brazilvaluecapture.core.foundation.test.AbstractServiceIntegrationTests;
import com.monsanto.brazilvaluecapture.core.grower.model.bean.Grower;
import com.monsanto.brazilvaluecapture.core.user.AccessControlTestFixture;
import com.monsanto.brazilvaluecapture.seedsale.quota.report.EmptyReportException;
import com.monsanto.brazilvaluecapture.seedsale.sale.SaleTestFixture;
import junit.framework.Assert;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.ResourceBundle;

public class ManualCreditReportAssembler_AT extends AbstractServiceIntegrationTests {

	@Autowired
	private AccountService accountService;
	
	@Autowired
	private ManualCreditReportBuilder manualCreditReportBuilder;
	
	private ResourceBundle resourceBundle = ResourceBundle.getBundle("bundle/bundle");
	
	@Before
    public void init() throws BusinessException {
        systemTestFixture = new SystemTestFixture(this);
        accessControlTestFixture = new AccessControlTestFixture(systemTestFixture);
        saleTestFixture = new SaleTestFixture(this, systemTestFixture);
    }
	
	@Test
	public void given_manualCreditGenerated_when_search_by_filter_should_return_manualCreditDTO() {
		ManualCredit manualCredit = createAndSaveManualCredit(
				ManualCreditTransactionType.CREDIT, BigDecimal.TEN,
				systemTestFixture.soy, systemTestFixture.operationalYearOf2011,
				systemTestFixture.bt, saleTestFixture.chicoBento);
		
		ManualCreditFilter manualCreditFilter = ManualCreditFilter.getInstance();
		manualCreditFilter
				.addCompany(manualCredit.getTechnology().getCompany())
				.addCrop(manualCredit.getCrop())
				.addGrower(manualCredit.getGrower())
				.addOperationalYear(manualCredit.getOperationalYear())
				.addTechnology(manualCredit.getTechnology());
		
		List<ManualCreditReportDTO> list = accountService.getManualCreditDTOBy(manualCreditFilter);
		
		Assert.assertEquals("Should have one manualCreditDTO", 1, list.size());
		assertManualCreditDTO(manualCredit, list.get(0));
	}

	@Test(expected=EmptyReportException.class)
	public void given_no_manualCredit_when_buildReportFor_should_throwException() throws EmptyReportException, NoSuchMethodException, IOException {
		manualCreditReportBuilder.buildReportFor(ManualCreditFilter.getInstance(), resourceBundle);
	}
	
	@Test
	public void given_manualCredit_when_generate_report_should_create_report_with_one_row() throws EmptyReportException, NoSuchMethodException, IOException {
		ManualCredit manualCredit = createAndSaveManualCredit(ManualCreditTransactionType.CREDIT, BigDecimal.TEN,
				systemTestFixture.soy, systemTestFixture.operationalYearOf2011,	systemTestFixture.bt, saleTestFixture.chicoBento);
		
         ByteArrayOutputStream stream = manualCreditReportBuilder.buildReportFor(ManualCreditFilter.getInstance(), resourceBundle);
         assertReportStream(manualCredit, stream, 1);
	}
	
	@Test
	public void given_manualCredit_for_three_growers_when_generate_report_should_return_three_rows_orderedByCreationDate() throws EmptyReportException, NoSuchMethodException, IOException {
		ManualCredit manualCredit = createAndSaveManualCredit(ManualCreditTransactionType.CREDIT, BigDecimal.TEN,
				systemTestFixture.soy, systemTestFixture.operationalYearOf2009,	systemTestFixture.bt, saleTestFixture.chicoBento);
		ManualCredit manualCredit2 = createAndSaveManualCredit(ManualCreditTransactionType.CREDIT, BigDecimal.TEN,
				systemTestFixture.soy, systemTestFixture.operationalYearOf2011,	systemTestFixture.bt, saleTestFixture.joaoDaSilva);
		ManualCredit manualCredit3 = createAndSaveManualCredit(ManualCreditTransactionType.CREDIT, BigDecimal.TEN,
				systemTestFixture.soy, systemTestFixture.operationalYearOf2012,	systemTestFixture.bt, saleTestFixture.joseDaSilva);
		
		ByteArrayOutputStream stream = manualCreditReportBuilder.buildReportFor(ManualCreditFilter.getInstance(), resourceBundle);
		assertReportStream(manualCredit, stream, 1);
		assertReportStream(manualCredit2, stream, 2);
		assertReportStream(manualCredit3, stream, 3);
	}

	private void assertReportStream(ManualCredit manualCredit, ByteArrayOutputStream stream, int rowNum) throws IOException {
		SimpleDateFormat sdf = new SimpleDateFormat(resourceBundle.getString("pattern.date"));
		String year = manualCredit.getOperationalYear().getYear();
		assertSheetAndVerifyValue(stream, rowNum, 0, Double.valueOf(year));
		assertSheetAndVerifyValue(stream, rowNum, 1, sdf.format(manualCredit.getCreditDate()));
		assertSheetAndVerifyValue(stream, rowNum, 2, manualCredit.getGrower().getDocument().getValueFormatted());
		assertSheetAndVerifyValue(stream, rowNum, 3, manualCredit.getGrower().getName());
		assertSheetAndVerifyValue(stream, rowNum, 4, manualCredit.getGrower().getBillingAddress().getCity().getDescription());
		assertSheetAndVerifyValue(stream, rowNum, 5, manualCredit.getGrower().getBillingAddress().getState().getCode());
		assertSheetAndVerifyValue(stream, rowNum, 6, resourceBundle.getString(manualCredit.getOperationType().getLabel()));
		assertSheetAndVerifyValue(stream, rowNum, 7, manualCredit.getTechnology().getDescription());
		assertSheetAndVerifyValue(stream, rowNum, 8, manualCredit.getValue().doubleValue());
		assertSheetAndVerifyValue(stream, rowNum, 9, manualCredit.getReason());
		assertSheetAndVerifyValue(stream, rowNum, 10, manualCredit.getRequestLogin());
	}
	
    private void assertSheetAndVerifyValue(ByteArrayOutputStream baos, int rowNum, int cellPosition, Object expected) throws IOException {
    	HSSFCell cell = assertOutputStreamAndGetCell(baos, rowNum, cellPosition);
    	switch (cell.getCellType()) {
		case HSSFCell.CELL_TYPE_NUMERIC:
			Assert.assertEquals("Should have the expected value", expected, cell.getNumericCellValue());
			break;
		case HSSFCell.CELL_TYPE_STRING:
			Assert.assertEquals("Should have the expected value", expected, cell.getStringCellValue());
			break;
		default:
			Assert.fail("Should have cell type expected");
			break;
		}
    }
    
    private HSSFCell assertOutputStreamAndGetCell(ByteArrayOutputStream baos, int rowNum, int cellPosition) throws IOException {
		ByteArrayInputStream inputStream = new ByteArrayInputStream(baos.toByteArray());
    	HSSFWorkbook hssfWorkbook = new HSSFWorkbook(inputStream);
    	Assert.assertNotNull("workbook shouldn't be null", hssfWorkbook);
    	HSSFSheet sheet = hssfWorkbook.getSheetAt(0);
    	Assert.assertNotNull("Sheet shouldn't be null", sheet);
    	HSSFRow row = sheet.getRow(rowNum);
    	Assert.assertNotNull("Row shouldn't be null", row);
    	HSSFCell cell = row.getCell(cellPosition);
    	Assert.assertNotNull("Cell shouldn't be null", cell);
		return cell;
	}
	
	private void assertManualCreditDTO(ManualCredit manualCredit, ManualCreditReportDTO manualCreditReportDTO) {
		Assert.assertEquals("Grower not matching expected", manualCredit.getGrower().getName(), manualCreditReportDTO.getGrower());
		Assert.assertEquals("Grower Document not matching expected", manualCredit.getGrower().getDocument().getValueFormatted(), manualCreditReportDTO.getGrowerDocument());
		Assert.assertEquals("Operational Year not matching expected", manualCredit.getOperationalYear().getYear(), manualCreditReportDTO.getOperationalYear().getValue().toString());
		Assert.assertEquals("Technology not matching expected", manualCredit.getTechnology().getDescription(), manualCreditReportDTO.getTechnology());
		Assert.assertEquals("Reason not matching expected", manualCredit.getReason(), manualCreditReportDTO.getReason());
		Assert.assertEquals("OperationType not matching expected", manualCredit.getOperationType().getLabel(), manualCreditReportDTO.getOperationType());
		Assert.assertEquals("Grower city not matching expected", manualCredit.getGrower().getBillingAddress().getCity().getDescription(), manualCreditReportDTO.getGrowerCity());
		Assert.assertEquals("Grower state not matching expected", manualCredit.getGrower().getBillingAddress().getState().getCode(), manualCreditReportDTO.getGrowerState());
		Assert.assertEquals("Value not matching expected", manualCredit.getValue(), manualCreditReportDTO.getValue());
	}

	private ManualCredit createAndSaveManualCredit(ManualCreditTransactionType transactionType, BigDecimal transactionValue, Crop crop, OperationalYear operationalYear, Technology technology, Grower grower) {
		ManualCredit manualCredit = new ManualCredit(crop,
				operationalYear, technology,
				grower, transactionType,
				transactionValue, "reason", "vrodrigues");
		saveAndFlush(manualCredit);
		
		return manualCredit;
	}
}
