package com.monsanto.brazilvaluecapture.seedsale.sale.service.impl;

import com.monsanto.brazilvaluecapture.core.base.model.bean.Document;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Contract;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Customer;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Technology;
import com.monsanto.brazilvaluecapture.core.customer.model.dao.CustomerDAO;
import com.monsanto.brazilvaluecapture.core.customer.service.CustomerNotFoundException;
import com.monsanto.brazilvaluecapture.core.customer.service.CustomerService;
import com.monsanto.brazilvaluecapture.core.foundation.service.EntityNotFoundException;
import com.monsanto.brazilvaluecapture.core.foundation.service.IndustrySystemOperationException;
import com.monsanto.brazilvaluecapture.core.foundation.util.ConstraintViolation;
import com.monsanto.brazilvaluecapture.core.foundation.util.parser.ParsedLineResult;
import com.monsanto.brazilvaluecapture.core.grower.model.bean.Agreement;
import com.monsanto.brazilvaluecapture.core.grower.model.bean.Grower;
import com.monsanto.brazilvaluecapture.core.grower.model.dao.GrowerDAO;
import com.monsanto.brazilvaluecapture.core.regionalization.CountriesHolder;
import com.monsanto.brazilvaluecapture.core.regionalization.VCCountry;
import com.monsanto.brazilvaluecapture.core.regionalization.VCRegion;
import com.monsanto.brazilvaluecapture.core.user.model.bean.UserDecorator;
import com.monsanto.brazilvaluecapture.pod.rol.model.bean.GermoSupplier;
import com.monsanto.brazilvaluecapture.seedsale.billing.model.bean.Billing;
import com.monsanto.brazilvaluecapture.seedsale.billing.model.dao.BillingDAO;
import com.monsanto.brazilvaluecapture.seedsale.harvest.model.bean.Harvest;
import com.monsanto.brazilvaluecapture.seedsale.product.model.bean.Product;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.Sale;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.SaleItem;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.dao.GermoSupplierDAO;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.dao.SaleDAO;
import com.monsanto.brazilvaluecapture.seedsale.sale.service.IndustrySystemService;
import com.monsanto.brazilvaluecapture.seedsale.sale.service.SaleConstraintViolationException;
import com.monsanto.brazilvaluecapture.seedsale.sale.service.SaleOrderImportService;
import com.monsanto.brazilvaluecapture.seedsale.sale.service.SaleService;
import com.monsanto.brazilvaluecapture.seedsale.template.model.bean.SaleTemplate;
import com.monsanto.brazilvaluecapture.seedsale.template.model.bean.SaleTemplateBillingMethodEnum;
import com.monsanto.brazilvaluecapture.seedsale.template.model.dao.SaleTemplateDAO;
import junit.framework.Assert;
import org.apache.directory.shared.ldap.aci.UserClass;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;

import java.math.BigDecimal;
import java.util.*;

import static junit.framework.Assert.assertNotNull;
import static junit.framework.Assert.assertTrue;
import static junit.framework.Assert.fail;
import static org.fest.assertions.Assertions.assertThat;
import static org.fest.reflect.core.Reflection.field;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.*;

/**
 * Created by IntelliJ IDEA.
 * User: HGFIOR
 * Date: 10/07/13
 * Time: 17:02
 * To change this template use File | Settings | File Templates.
 */
public class SaleOrderImportServiceImpl_UT {

    public static final String DUMMY_DOCUMENT = "DUMMY_DOCUMENT";
    private SaleOrderImportServiceImpl saleOrderImportService;
    private SaleService saleService;
    private SaleDAO saleDAO;
    private CustomerService customerService;
    private GrowerDAO growerDAO;
    private GermoSupplierDAO germoSupplierDAO;
    private CountriesHolder countriesHolder;
    private SaleTemplateDAO saleTemplateDao;
    private BillingDAO billingDAO;
    private AccountManager accountManager;
    private IndustrySystemService industrySystemService;

    @Before
    public void setUp() throws Exception{
        MockitoAnnotations.initMocks(this);
        saleOrderImportService = new SaleOrderImportServiceImpl();
        this.saleService = mock(SaleService.class);
        this.saleDAO = mock(SaleDAO.class);
        this.customerService = mock(CustomerService.class);
        this.growerDAO = mock(GrowerDAO.class);
        this.germoSupplierDAO = mock(GermoSupplierDAO.class);
        this.countriesHolder = mock(CountriesHolder.class);
        this.saleTemplateDao = mock(SaleTemplateDAO.class);
        this.billingDAO = mock(BillingDAO.class);
        this.accountManager = mock(AccountManager.class);
        this.industrySystemService = mock(IndustrySystemService.class);

        field("countriesHolder").ofType(CountriesHolder.class).in(this.saleOrderImportService).set(this.countriesHolder);
        field("saleDAO").ofType(SaleDAO.class).in(this.saleOrderImportService).set(this.saleDAO);
        field("saleService").ofType(SaleService.class).in(this.saleOrderImportService).set(this.saleService);
        field("customerService").ofType(CustomerService.class).in(this.saleOrderImportService).set(this.customerService);
        field("growerDAO").ofType(GrowerDAO.class).in(this.saleOrderImportService).set(this.growerDAO);
        field("germoSupplierDAO").ofType(GermoSupplierDAO.class).in(this.saleOrderImportService).set(this.germoSupplierDAO);
        field("saleTemplateDao").ofType(SaleTemplateDAO.class).in(this.saleOrderImportService).set(this.saleTemplateDao);
        field("billingDAO").ofType(BillingDAO.class).in(this.saleOrderImportService).set(this.billingDAO);
        field("accountManager").ofType(AccountManager.class).in(this.saleOrderImportService).set(this.accountManager);
        field("industrySystemService").ofType(IndustrySystemService.class).in(this.saleOrderImportService).set(this.industrySystemService);


    }


    @Test
    public void testIsSaleOrderSapDuplicated() throws Exception {
        Sale sale = mock(Sale.class);
        Boolean duplicated =    saleOrderImportService.isSaleOrderSapDuplicated(sale);
        assertNotNull(duplicated);

    }

    @Test
    public void testGetCountry() {
        CountriesHolder countriesHolder = Mockito.mock(CountriesHolder.class);
        field("countriesHolder").ofType(CountriesHolder.class).in(saleOrderImportService).set(countriesHolder);
        when(countriesHolder.getCountry()).thenReturn(VCCountry.ARGENTINA);
        VCCountry country = saleOrderImportService.getCountry();
        assertNotNull(country);
    }

    @Test
    public void testGetSaleTemplate() {
        SaleTemplateDAO saleTemplateDAO = Mockito.mock(SaleTemplateDAO.class);
        field("saleTemplateDao").ofType(SaleTemplateDAO.class).in(saleOrderImportService).set(saleTemplateDAO);
        when(saleTemplateDAO.selectByType(any(Sale.SaleTypeEnum.class))).thenReturn(new SaleTemplate());
        SaleTemplate saleTemplate = saleOrderImportService.getSaleTemplate(Sale.SaleTypeEnum.PRE_CAMPAIGN);
        assertNotNull(saleTemplate);
    }


    @Test
    public void testGetCustomerBySapCodeWithWrongID() throws Exception {
        field("customerService").ofType(CustomerService.class).in(saleOrderImportService).set(this.customerService);
        when(customerService.getCustomerByCustomerSapCode("invalid_id")).thenThrow(EntityNotFoundException.class);
        try{
            Customer customer = saleOrderImportService.getCustomerBySapCode("invalid_id");
            fail();
        }catch (EntityNotFoundException e){
            assertThat(e).isInstanceOf(EntityNotFoundException.class);
        }
    }

     @Test
    public void testGetCustomerBySapCodeAndCustomerDoesNotExist() throws Exception {
        field("customerService").ofType(CustomerService.class).in(saleOrderImportService).set(this.customerService);
        when(customerService.getCustomerByCustomerSapCode("this_customer_does_not_exist")).thenThrow(CustomerNotFoundException.class);
        try{
            Customer customer = saleOrderImportService.getCustomerBySapCode("this_customer_does_not_exist");
            fail();
        }catch (CustomerNotFoundException e){
            assertThat(e).isInstanceOf(CustomerNotFoundException.class);
        }
    }

    @Test
    public void testGetGrowerByCustomerSapId() throws Exception {
        Customer customer = saleOrderImportService.getCustomerBySapCode("SAP_CODE");
        verify(customerService).getCustomerByCustomerSapCode("SAP_CODE");

    }

    @Test
    public void testSaveSale() throws Exception {
        field("saleService").ofType(SaleService.class).in(saleOrderImportService).set(this.saleService);
        Sale sale = Mockito.mock(Sale.class);
        UserDecorator userDecorator = Mockito.mock(UserDecorator.class);
        saleOrderImportService.saveSale(sale,userDecorator);
        verify(saleService).save(sale,userDecorator);
    }


    @Test
    public void testValidateSaleOrder(){
        Grower grower = new Grower();
        List<ConstraintViolation> violations = saleOrderImportService.validateSaleOrder(grower);
        assertTrue(!violations.isEmpty());
        assertTrue(violations.size()==3);
    }

    @Test
    public void testValidateSaleOrderAgreementNotApproved(){
        Grower grower = new Grower();
        Agreement agreement = new Agreement();
        agreement.setStatus(Agreement.AgreementStatusEnum.OBSERVED);
        grower.addAgreement(agreement);
        List<ConstraintViolation> violations = saleOrderImportService.validateSaleOrder(grower);
        assertTrue(!violations.isEmpty());
        assertTrue(violations.size()==3);
    }

     @Test
    public void testValidateSaleOrderCustomerBlockedGetBlockedViolation(){
         Grower grower = new Grower();
         Customer customer = new Customer();
         customer.setActive(false);
         Set<Customer> setOfCustomers = new HashSet<Customer>();
         setOfCustomers.add(customer);
         field("customer").ofType(Set.class).in(grower).set(setOfCustomers);
         List<ConstraintViolation> violations = saleOrderImportService.validateSaleOrder(grower);
         assertTrue(!violations.isEmpty());
         assertTrue(violations.size()==4);
    }

     @Test
    public void testValidateSaleOrderGetsNoViolations(){
         Grower grower = new Grower();
         field("id").ofType(Long.class).in(grower).set(1L);
         Agreement agreement = new Agreement();
         agreement.setStatus(Agreement.AgreementStatusEnum.APPROVED);
         grower.addAgreement(agreement);
         grower.setStatus(true);
         grower.setCustomerSapId("CUSTOMER_SAP_ID");
         Customer customer = new Customer();
         customer.setActive(true);
         Set<Customer> setOfCustomers = new HashSet<Customer>();
         setOfCustomers.add(customer);
         field("customer").ofType(Set.class).in(grower).set(setOfCustomers);
         List<ConstraintViolation> violations = saleOrderImportService.validateSaleOrder(grower);
         assertTrue(violations.isEmpty());
         assertTrue(violations.size()==0);
    }

    @Test
    public void test_saveImportedSaleOrderLAS_billing_interact_test(){
        Sale sale = prepareValidSale();

        UserDecorator userDecorator = mock(UserDecorator.class);
        saleOrderImportService.saveImportedSaleOrderLAS(sale,userDecorator, new ArrayList<ParsedLineResult>());
        verify(billingDAO).save(any(Billing.class));
    }

    @Test
    public void test_saveImportedSaleOrderLAS_saleDAO_interact_test(){
        Sale sale = prepareValidSale();

        UserDecorator userDecorator = mock(UserDecorator.class);
        saleOrderImportService.saveImportedSaleOrderLAS(sale,userDecorator, new ArrayList<ParsedLineResult>());
        verify(saleDAO).save(any(Sale.class));
    }

    @Test
    public void test_saveImportedSaleOrderLASAccountManagerIsCalled_WhenIsTonsGenerator(){
        Sale sale = prepareValidSale();

        UserDecorator userDecorator = mock(UserDecorator.class);
        saleOrderImportService.saveImportedSaleOrderLAS(sale,userDecorator, new ArrayList<ParsedLineResult>());
        verify(accountManager).managePaymentFor(any(Grower.class), any(Billing.class));
    }

    @Test
    public void test_saveImportedSaleOrderLASIndustrySystemServiceIsCalled_WhenIsTonsGenerator() throws IndustrySystemOperationException {
        Sale sale = prepareValidSale();

        UserDecorator userDecorator = mock(UserDecorator.class);
        saleOrderImportService.saveImportedSaleOrderLAS(sale,userDecorator, new ArrayList<ParsedLineResult>());
        verify(industrySystemService).registerPayment(eq(sale), isNull(BigDecimal.class));
    }

    @Test
    public void test_checkCustomerConstraintViolationsShouldReturnOneViolation_whenCustomerIsNull(){
        Customer customer = null;
        List<ConstraintViolation> violations = saleOrderImportService.checkCustomerConstraintViolations(customer);
        assertThat(violations).hasSize(1);
    }

    @Test
    public void test_checkCustomerConstraintViolations_ShouldReturnPartnerNotFoundErrorMessage_whenCustomerIsNull(){
        Customer customer = null;
        List<ConstraintViolation> violations = saleOrderImportService.checkCustomerConstraintViolations(customer);
        assertThat(violations).onProperty("message").contains("sale-record.partner.not.found");
    }

    @Test
    public void test_checkCustomerConstraintViolationsShouldReturnOneViolation_whenCustomerHasNoContracts(){
        Customer customer = new Customer();
        List<ConstraintViolation> violations = saleOrderImportService.checkCustomerConstraintViolations(customer);
        assertThat(violations).hasSize(1);
    }

    @Test
    public void test_checkCustomerConstraintViolations_ShouldReturnPartnerNotFoundErrorMessage_whenCustomerHasNoContracts(){
        Customer customer = new Customer();
        List<ConstraintViolation> violations = saleOrderImportService.checkCustomerConstraintViolations(customer);
        assertThat(violations).onProperty("message").contains("sale-record.partner.has-no-contract");
    }

    @Test
    public void test_checkCustomerConstraintViolationsShouldReturnOneViolation_whenCustomerHasNoValidContracts(){
        Customer customer = new Customer();
        customer.addContract(new Contract());
        List<ConstraintViolation> violations = saleOrderImportService.checkCustomerConstraintViolations(customer);
        assertThat(violations).hasSize(1);
    }

    @Test
    public void test_checkCustomerConstraintViolations_ShouldReturnPartnerNotFoundErrorMessage_whenCustomerHasNoValidContracts(){
        Customer customer = new Customer();
        customer.addContract(new Contract());
        List<ConstraintViolation> violations = saleOrderImportService.checkCustomerConstraintViolations(customer);
        assertThat(violations).onProperty("message").contains("sale-record.partner.has-no-valid-contract");
    }

    @Test
    public void test_getGrowerByDocument_ShouldCallGrowerDAO(){
        saleOrderImportService.getGrowerByDocument(DUMMY_DOCUMENT);
        verify(growerDAO).selectGrowerByDocument(any(Document.class));
    }

    private Sale prepareValidSale() {
        Sale sale = mock(Sale.class);
        SaleItem saleItem = mock(SaleItem.class);
        Set<SaleItem> items = new HashSet<SaleItem>();
        items.add(saleItem);
        Product product = mock(Product.class);
        Set<Product> products = new HashSet<Product>();
        products.add(product);
        Technology technology = mock(Technology.class);
        SaleTemplate saleTemplate = mock(SaleTemplate.class);
        Harvest harvest = mock(Harvest.class);


        when(sale.getItems()).thenReturn(items);
        when(saleDAO.save(sale)).thenReturn(sale);
        when(product.getTechnology()).thenReturn(technology);
        when(saleTemplate.getProducts()).thenReturn(products);
        when(saleItem.getBillingMethod()).thenReturn(SaleTemplateBillingMethodEnum.ERP);
        when(saleItem.getProduct()).thenReturn(product);
        when(saleItem.getTechnology()).thenReturn(technology);
        when(saleItem.getHarvest()).thenReturn(harvest);
        when(saleTemplate.getIsTonsGenerator()).thenReturn(Boolean.TRUE);
        when(sale.getSaleTemplate()).thenReturn(saleTemplate);
        return sale;
    }
}
