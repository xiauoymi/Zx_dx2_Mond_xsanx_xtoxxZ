package com.monsanto.brazilvaluecapture.seedsale.product;

import com.monsanto.brazilvaluecapture.core.base.CountryTestData;
import com.monsanto.brazilvaluecapture.core.base.StateTestData;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Country;
import com.monsanto.brazilvaluecapture.core.base.model.bean.State;
import com.monsanto.brazilvaluecapture.seedsale.harvest.HarvestTestData;
import com.monsanto.brazilvaluecapture.seedsale.harvest.model.bean.Harvest;
import com.monsanto.brazilvaluecapture.seedsale.harvest.model.bean.Plantability;
import com.monsanto.brazilvaluecapture.seedsale.product.model.bean.DefaultProductivity;
import com.monsanto.brazilvaluecapture.seedsale.product.model.bean.Product;
import com.monsanto.brazilvaluecapture.seedsale.product.model.bean.Productivity;
import com.monsanto.brazilvaluecapture.seedsale.product.model.bean.ProductivityDTO;
import com.monsanto.brazilvaluecapture.seedsale.product.model.bean.ProductivityValue;

import java.math.BigDecimal;

public class ProductivityTestData {

	public static final BigDecimal MINIMUM_PRODUCTIVITY_VALUE = BigDecimal.valueOf(10l);
	public static final BigDecimal MAXIMUM_PRODUCTIVITY_VALUE = BigDecimal.valueOf(999l);

	public static Productivity createProductivity(State state, Plantability plantability) {
		Productivity productivity = new Productivity();
		productivity.setState(state);
		productivity.setPlantability(plantability);
		productivity.setDefaultProductivity(DefaultProductivity.YES);
		plantability.addProductivity(productivity);
		return productivity;
	}

	public static Productivity createProductivityValue(State state, Plantability plantability, Product product) {
		Productivity productivity = createProductivity(state, plantability);
		addProductivityValue(productivity, product);
		return productivity;
	}
	
	public static ProductivityValue addProductivityValue(Productivity productivity, Product product) {
		ProductivityValue productivityValue = new ProductivityValue();
		productivityValue.setProductivityMax(MAXIMUM_PRODUCTIVITY_VALUE);
		productivityValue.setProductivityMin(MINIMUM_PRODUCTIVITY_VALUE);

		product.addProductivityValues(productivityValue);
		productivity.addProductivityValues(productivityValue);

		return productivityValue;
	}
	
	public static Productivity createFullProductivity(){
		Harvest harvest = HarvestTestData.createABrazilianHarvest();
		Plantability plantability = PlantabilityTestData.createPlantability(harvest);		
		Productivity productivity = createProductivity(plantability);
		return productivity;
	}
	public static Productivity createProductivity(Plantability plantability) {
		Country country = CountryTestData.createBrazil();
		State state = StateTestData.createState(country,"RJJ");
		Product product = ProductTestData.createProduct();
		Productivity productivity = ProductivityTestData.createProductivityValue(state, plantability, product);
		return productivity;
	}
	
	/**
	 * @param harvest
	 * @param state
	 * @param plantability
	 * @param defaultProductivity
	 * @return
	 */
	public static ProductivityDTO createProductivityDTO(Harvest harvest, State state,
			Plantability plantability, DefaultProductivity defaultProductivity) {

		ProductivityDTO productivityDTO = new ProductivityDTO();

		productivityDTO.setHarvest(harvest);
		productivityDTO.setState(state);
		productivityDTO.setPlantability(plantability);
		productivityDTO.setDefaultProductivity(defaultProductivity);

		return productivityDTO;
	}

	public static Productivity createProductivityWithoutProductivityValue(
			Harvest harvest, DefaultProductivity defaultProductivity) {
		Plantability plantability = PlantabilityTestData
				.createPlantability(harvest);
		Country country = CountryTestData.createBrazil();
		State state = StateTestData.createState(country, "state");

		Productivity productivity = ProductivityTestData.createProductivity(
				state, plantability);
		productivity.setDefaultProductivity(defaultProductivity);

		return productivity;
	}
	
	public static Productivity createProductivityWithProductivityValue(Harvest harvest) {
		Product product = harvest.getCrop().getProducts().iterator().next();
		Plantability plantability = PlantabilityTestData.createPlantability(harvest);		
		Country country = CountryTestData.createBrazil();
		State state = StateTestData.createState(country, "state");
		
		Productivity productivity = ProductivityTestData.createProductivityValue(state, plantability, product);
		
		return productivity;
	}
}
