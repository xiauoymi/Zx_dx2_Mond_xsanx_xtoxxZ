package com.monsanto.brazilvaluecapture.seedsale.product;

import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.Date;

import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.hibernate.classic.Session;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.monsanto.brazilvaluecapture.core.base.model.bean.Company;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Crop;
import com.monsanto.brazilvaluecapture.core.base.model.bean.OperationalYear;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Technology;
import com.monsanto.brazilvaluecapture.core.foundation.model.bean.StatusEnum;
import com.monsanto.brazilvaluecapture.core.foundation.service.BusinessException;
import com.monsanto.brazilvaluecapture.core.grower.CreateTestData;
import com.monsanto.brazilvaluecapture.seedsale.harvest.model.bean.Harvest;
import com.monsanto.brazilvaluecapture.seedsale.product.model.bean.Brand;
import com.monsanto.brazilvaluecapture.seedsale.product.model.bean.Product;
import com.monsanto.brazilvaluecapture.seedsale.product.model.dao.ProductDAO;
import com.monsanto.brazilvaluecapture.seedsale.product.model.dao.impl.ProductDAOImpl;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.Sale.SaleTypeEnum;
import com.monsanto.brazilvaluecapture.seedsale.template.model.bean.SaleTemplate;
import com.monsanto.brazilvaluecapture.seedsale.template.model.bean.SaleTemplateBillingMethodEnum;
import com.monsanto.brazilvaluecapture.seedsale.template.model.bean.SaleTemplateByPlantabilityEnum;

public class Product_UT extends CreateTestData{
	
	ProductDAO productDAO;
	Session mockSession;
	SessionFactory mockSessionFactory;

	@Before
	public void setup() {

		mockSessionFactory = mock(SessionFactory.class);
		mockSession = mock(Session.class);
		when(mockSessionFactory.getCurrentSession()).thenReturn(mockSession);

		productDAO = new ProductDAOImpl(mockSessionFactory);

	}

	@Test
	public void createProductEmptyTest() {

		Company company = new Company();
		Technology technology = new Technology();
		technology.setCompany(company);
		Brand brand = new Brand();
		brand.setCompany(company);
		Crop crop = new Crop();
		crop.setCompany(company);

		Product product = new Product();
		product.setBrand(brand);
		product.setCrop(crop);
		product.setTechnology(technology);
		product.setCompany(company);

		Assert.assertEquals(product.getDescription(), null);
		Assert.assertEquals(product.getCrop().getDescription(), null);
		Assert.assertEquals(product.getCompany().getDescription(),
				null);
		Assert.assertEquals(product.getBrand().getDescription(), null);
		Assert.assertEquals(product.getTechnology().getDescription(), null);
		Assert.assertEquals(product.getBrand().getCompany().getDescription(),
				null);
		Assert.assertEquals(product.getTechnology().getCompany()
				.getDescription(), null);

		Assert.assertTrue(product.getId() == null);
		Assert.assertTrue(product.getCrop().getPrimaryKey() == null);
		Assert.assertTrue(product.getCompany().getPrimaryKey() == null);
		Assert.assertTrue(product.getBrand().getId() == null);
		Assert.assertTrue(product.getTechnology().getId() == null);

	}
	
	//@Test(expected = NullPointerException.class)
	@Test
	public void createProductConstructorEmptyTest() {

		Company company = new Company();
		Technology technology = new Technology();
		technology.setCompany(company);
		Brand brand = new Brand();
		brand.setCompany(company);
		Crop crop = new Crop();
		crop.setCompany(company);

		Product product = new Product(null, null, crop, technology, brand, company);
		product.setCompany(company);

		Assert.assertEquals(product.getDescription(), null);
		Assert.assertEquals(product.getCrop().getDescription(), null);
		Assert.assertEquals(product.getCompany().getDescription(),
				null);
		Assert.assertEquals(product.getBrand().getDescription(), null);
		Assert.assertEquals(product.getTechnology().getDescription(), null);
		Assert.assertEquals(product.getBrand().getCompany().getDescription(),
				null);
		Assert.assertEquals(product.getTechnology().getCompany()
				.getDescription(), null);

		Assert.assertTrue(product.getId() == null);
		Assert.assertTrue(product.getCrop().getPrimaryKey() == null);
		Assert.assertTrue(product.getCompany().getPrimaryKey() == null);
		Assert.assertTrue(product.getBrand().getId() == null);
		Assert.assertTrue(product.getTechnology().getId() == null);

	}

	@Test
	public void createProductTest() {

		Product product = ProductTestData.createProduct();
		product.setId(1L);
		product.getCrop().setId(1L);
		product.getCompany().setId(1L);
		product.getBrand().setId(1L);
		product.getTechnology().setId(1L);

		Assert.assertNotNull(product.getDescription());
		Assert.assertNotNull(product.getStatus());
		Assert.assertNotNull(product.getCrop().getDescription());
		Assert.assertNotNull(product.getCompany().getDescription());
		Assert.assertNotNull(product.getCrop().getProducts());

		Assert.assertNotNull(product.getBrand().getDescription());
		Assert.assertNotNull(product.getBrand().getCompany().getDescription());
		Assert.assertNotNull(product.getBrand().getProducts());

		Assert.assertNotNull(product.getTechnology().getDescription());
		Assert.assertNotNull(product.getTechnology().getCompany().getDescription());
		Assert.assertNotNull(product.getTechnology().getProducts());

		Assert.assertTrue(product.getId() == 1L);
		Assert.assertTrue(product.getCrop().getId() == 1L);
		Assert.assertTrue(product.getCompany().getId() == 1L);
		Assert.assertTrue(product.getBrand().getId() == 1L);
		Assert.assertTrue(product.getTechnology().getId() == 1L);
	}

	@Test
	public void createProductTestFull() {

		Product product = new Product();

		product.setDescription(null);

		Assert.assertNull(product.getDescription());

		product.setDescription("Teste");

		Assert.assertEquals(product.getDescription(), "Teste".toUpperCase());
	}

	@Test
	public void testAddTemplateInProduct() {

		Product product = ProductTestData.createProduct();

		// creating new template by product created above
		Company monsanto = new Company("Monsanto");
		Harvest harvest = new Harvest(monsanto, "Safrinha", new OperationalYear("2012"), product.getCrop(), StatusEnum.ACTIVE);
		Date now = new Date();
		SaleTemplate template = new SaleTemplate(harvest, "Description safra", now, Boolean.FALSE, SaleTemplateByPlantabilityEnum.BY_PRODUCT, now, now, SaleTypeEnum.SALE_SEED, SaleTemplateBillingMethodEnum.DIRECT);
		// validate if is empty
		Assert.assertTrue(template.getProducts().isEmpty());

		// add new product
		Assert.assertTrue(product.addSaleTemplate(template));

		// validate if is not empty
		Assert.assertFalse(product.getSaleTemplates().isEmpty());

		Assert.assertTrue(product.getSaleTemplates().size() == 1);
		Assert.assertEquals(product.getSaleTemplates().iterator().next(), template);
	}

	@Test
	public void testAddTemplateInProductErrorNull() {

		Product product = ProductTestData.createProduct();

		// creating new template by product created above
		Company monsanto = new Company("Monsanto");
		Harvest harvest = new Harvest(monsanto, "Safrinha", new OperationalYear("2012"), product.getCrop(), StatusEnum.ACTIVE);
		Date now = new Date();
		SaleTemplate template = new SaleTemplate(harvest, "Description safra", now, Boolean.FALSE, SaleTemplateByPlantabilityEnum.BY_PRODUCT, now, now, SaleTypeEnum.SALE_SEED, SaleTemplateBillingMethodEnum.DIRECT);

		// validate if is empty
		Assert.assertTrue(template.getProducts().isEmpty());
		Assert.assertTrue(product.getSaleTemplates().isEmpty());

		product.setSaleTemplates(null);
		
		// add new product
		Assert.assertFalse(product.addSaleTemplate(template));

		Assert.assertNull(product.getSaleTemplates());
	}
	
	@Test
	public void testAddAnotherTemplateInProduct() {

		Product product = ProductTestData.createProduct();

		// creating new template by product created above
		Company monsanto = new Company("Monsanto");
		Harvest harvest = new Harvest(monsanto, "Safrinha", new OperationalYear("2012"), product.getCrop(), StatusEnum.ACTIVE);
		Date now = new Date();
		SaleTemplate template = new SaleTemplate(harvest, "Description safra", now, Boolean.FALSE, SaleTemplateByPlantabilityEnum.BY_PRODUCT, now, now, SaleTypeEnum.SALE_SEED, SaleTemplateBillingMethodEnum.DIRECT);

		// validate if is empty
		Assert.assertTrue(product.getSaleTemplates().isEmpty());

		// add new product
		Assert.assertTrue(product.addSaleTemplate(template));
		
		Product product2 = ProductTestData.createProduct();
		
		// creating new template by product created above
		SaleTemplate template2 = new SaleTemplate(harvest, "Description safra2", now, Boolean.FALSE, SaleTemplateByPlantabilityEnum.BY_PRODUCT, now, now, SaleTypeEnum.SALE_SEED, SaleTemplateBillingMethodEnum.DIRECT);
		
		// add new product
		Assert.assertTrue(product2.addSaleTemplate(template2));
	}
	
	@Test
	public void testAddTemplateWithNullProduct() {

		Product product = ProductTestData.createProduct();

		// creating new template by product created above
		Company monsanto = new Company("Monsanto");
		Harvest harvest = new Harvest(monsanto, "Safrinha", new OperationalYear("2012"), product.getCrop(), StatusEnum.ACTIVE);
		Date now = new Date();
		SaleTemplate template = new SaleTemplate(harvest, "Description safra", now, Boolean.FALSE, SaleTemplateByPlantabilityEnum.BY_PRODUCT, now, now, SaleTypeEnum.SALE_SEED, SaleTemplateBillingMethodEnum.DIRECT);

		// validate if is empty
		Assert.assertTrue(product.getSaleTemplates().isEmpty());

		// add new product
		Assert.assertTrue(product.addSaleTemplate(template));
	}

	@Test
	public void insertProductTest() throws BusinessException {

		when(mockSessionFactory.getCurrentSession()).thenReturn(mockSession);

		Product product = ProductTestData.createProduct();

		doNothing().when(mockSession).saveOrUpdate(product);

		productDAO.save(product);

		Assert.assertNotNull(product);
		Assert.assertNotNull(product.getDescription());
	}

	@Test
	public void deleteProductTest() throws BusinessException {

		when(mockSessionFactory.getCurrentSession()).thenReturn(mockSession);

		Product product = ProductTestData.createProduct();

		doNothing().when(mockSession).saveOrUpdate(product);

		productDAO.save(product);

		Long id = product.getPrimaryKey();

		doNothing().when(mockSession).delete(product);

		productDAO.delete(product);
		
		Query mockQuery = mock(Query.class);
		when(mockSession.createQuery(anyString())).thenReturn(mockQuery);
		when(mockQuery.setParameter("p_id", null)).thenReturn(mockQuery);
		when(mockQuery.uniqueResult()).thenReturn(null);

		Assert.assertNull(productDAO.selectById(id));
	}
	
}
