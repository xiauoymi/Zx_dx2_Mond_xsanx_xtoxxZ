package com.monsanto.brazilvaluecapture.seedsale.template;

import junit.framework.Assert;

import org.junit.Test;

import com.monsanto.brazilvaluecapture.core.foundation.util.ConstraintViolation;
import com.monsanto.brazilvaluecapture.seedsale.template.service.SaleTemplateConstraintViolationException;

public class SaleTemplateConstraintViolationException_UT {

    @Test
    public void test_add_constraint() {
        SaleTemplateConstraintViolationException exception = new SaleTemplateConstraintViolationException("error!");
        Assert.assertTrue(exception.isEmpty());
        exception.add(new ConstraintViolation());
        Assert.assertFalse(exception.isEmpty());
    }

    @Test
    public void test_add() {

        SaleTemplateConstraintViolationException exception = new SaleTemplateConstraintViolationException("error!");
        Assert.assertTrue(exception.isEmpty());
        exception.add("xxxxxxxxxxxx", "o1", "o2");
        Assert.assertFalse(exception.isEmpty());
        Assert.assertFalse(exception.getViolations().isEmpty());
    }
}
