package com.monsanto.brazilvaluecapture.seedsale.sale.service.parser.registration;

import com.monsanto.brazilvaluecapture.core.foundation.util.csv.CSVReadableInvalidException;
import com.monsanto.brazilvaluecapture.core.importfile.model.bean.CsvImportFile;
import com.monsanto.brazilvaluecapture.core.user.model.bean.UserDecorator;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.CsvMultiplierSale;
import com.monsanto.brazilvaluecapture.seedsale.sale.service.MultiplierSaleService;
import com.monsanto.brazilvaluecapture.seedsale.sale.validation.MultiplierToDealerSaleValidator;
import org.junit.Before;
import org.junit.Test;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import static org.mockito.Matchers.any;
import static org.mockito.Mockito.*;

/**
 * Test for class {@link MultiplierSaleFileParser}
 * 
 * @author CSOBR1
 *
 */
public class MultiplierSaleFileParser_UT {

	/**
	 * Class under test.
	 */
	private MultiplierSaleFileParser test;

    private MultiplierSaleService multiplierSaleService;
    private MultiplierToDealerSaleValidator multiplierToDealerSaleValidator;
	
	@Before
    public void setUp() throws Exception {

		multiplierSaleService = mock(MultiplierSaleService.class);
        multiplierToDealerSaleValidator = mock(MultiplierToDealerSaleValidator.class);
		test = new MultiplierSaleFileParser(mock(InputStream.class), new Locale("pt", "BR"), mock(UserDecorator.class), 
				multiplierSaleService, multiplierToDealerSaleValidator, "filename");
		
		this.test= spy(test);
		List<CsvMultiplierSale> list = new ArrayList<CsvMultiplierSale>();
		list.add(mock(CsvMultiplierSale.class));
		doReturn(list).when(test).getCsvSales();
    }
	
	@Test
	public void test_readFile() throws CSVReadableInvalidException {
		
		test.readFile();
		
		verify(multiplierSaleService).saveFileAndLines(any(CsvImportFile.class), anyList());
	}

}
