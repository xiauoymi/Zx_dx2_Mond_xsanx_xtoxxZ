package com.monsanto.brazilvaluecapture.seedsale.template;

import com.monsanto.brazilvaluecapture.core.customer.model.bean.Technology;
import com.monsanto.brazilvaluecapture.core.foundation.service.BusinessException;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.NoValueByPlantability;
import com.monsanto.brazilvaluecapture.seedsale.template.model.bean.*;
import com.monsanto.brazilvaluecapture.seedsale.template.model.bean.Price.PriceTypeEnum;
import com.monsanto.brazilvaluecapture.seedsale.template.model.bean.Price.ReleaseCreditTypeEnum;
import com.monsanto.brazilvaluecapture.seedsale.template.service.PriceTypeCanNotBeNoValueException;

public class PriceTestData {

	/**
	 * Create a new basic price
	 * 
	 * @param priceTypeEnum
	 * @param saleTemplate
	 * @param technology
	 * @return
	 * @throws PriceTypeCanNotBeNoValueException 
	 */
	public static Price createPrice(PriceTypeEnum priceTypeEnum, SaleTemplate saleTemplate, Technology technology) throws BusinessException {
		Price price;
		switch (priceTypeEnum) {
		case FIX:
			price = new Fix(saleTemplate, technology);
			break;
		case RANGE:
			price = new Range(saleTemplate, technology);
			break;
		case BY_EXPIRATION_DATE:
			price = new ByExpirationDate(saleTemplate, technology);
			break;
		case BY_PLANTABILITY_AND_EXPIRATION_DATE:
			price = new ByPlantabilityAndExpirationDate(saleTemplate, technology);
			break;
		case FREE_VALUE:
			price = new FreeValue(saleTemplate, technology);
			break;
		case NO_VALUE:
			price = new NoValue(saleTemplate, technology);
			break;
		case NO_VALUE_BY_PLANTABILITY:
			price = new NoValueByPlantability(saleTemplate, technology);
			break;
        case SEAMLESS_PRICING:
            price = new SeamlessPricing(saleTemplate, technology);
            break;
		default:
			throw new IllegalArgumentException("PriceTypeEnum invalid. Look at the implementation of createBasicPrice() method.");
		}
		//TODO: N�o deveriam estar no construtor?
		price.setReleaseCreditType(ReleaseCreditTypeEnum.AUTOMATICALLY);
		saleTemplate.addPrices(price);
		technology.addPricing(price);
		return price;
	}

	/**
	 * Create a new basic price
	 * @deprecated Use createBasicPrice(PriceTypeEnum priceTypeEnum, SaleTemplate saleTemplate, Technology technology) instead
	 * @param priceTypeEnum
	 * @return
	 * @throws PriceTypeCanNotBeNoValueException 
	 */
	public static Price createBasicPrice(PriceTypeEnum priceTypeEnum) throws BusinessException {
		return createPrice(priceTypeEnum, null, null);
	}

}
