package com.monsanto.brazilvaluecapture.seedsale.sale.service.impl;

import com.monsanto.brazilvaluecapture.core.base.model.bean.Country;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Document;
import com.monsanto.brazilvaluecapture.core.base.model.bean.DocumentType;
import com.monsanto.brazilvaluecapture.core.base.service.impl.CancelPaidSaleARServiceRunner;
import com.monsanto.brazilvaluecapture.core.base.service.impl.CancelUnpaidSaleARServiceRunner;
import com.monsanto.brazilvaluecapture.core.base.service.impl.RegisterPaymentARServiceRunner;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Customer;
import com.monsanto.brazilvaluecapture.core.grower.model.bean.Grower;
import com.monsanto.brazilvaluecapture.core.grower.service.LASVCPrepaidTonsAdapter;
import com.monsanto.brazilvaluecapture.osb.its.api.InfraException;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.Cancellation;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.Sale;
import org.apache.logging.log4j.Logger;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

import java.net.MalformedURLException;

import static org.fest.reflect.core.Reflection.field;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class IndustrySystemServiceImpl_UT {
    IndustrySystemServiceImpl industrySystemServiceImpl;
    LASVCPrepaidTonsAdapter lasvcPrepaidTonsAdapter;
    Sale sale;
    Cancellation cancellation;
    Logger logger;
    private CancelPaidSaleARServiceRunner cancelPaidSaleARServiceRunner;
    private CancelUnpaidSaleARServiceRunner cancelUnPaidSaleARServiceRunner;
    private RegisterPaymentARServiceRunner registerPaymentARServiceRunner;

    @Before
    public void setUp() throws Exception {
        industrySystemServiceImpl = new IndustrySystemServiceImpl();
        lasvcPrepaidTonsAdapter = mock(LASVCPrepaidTonsAdapter.class);
        cancelPaidSaleARServiceRunner = mock(CancelPaidSaleARServiceRunner.class);
        cancelUnPaidSaleARServiceRunner = mock(CancelUnpaidSaleARServiceRunner.class);
        registerPaymentARServiceRunner = mock(RegisterPaymentARServiceRunner.class);
        logger = mock(Logger.class);
        field("cancelPaidSaleARServiceRunner").ofType(CancelPaidSaleARServiceRunner.class).in(industrySystemServiceImpl).set(cancelPaidSaleARServiceRunner);
        field("cancelUnPaidSaleARServiceRunner").ofType(CancelUnpaidSaleARServiceRunner.class).in(industrySystemServiceImpl).set(cancelUnPaidSaleARServiceRunner);
        field("registerPaymentARServiceRunner").ofType(RegisterPaymentARServiceRunner.class).in(industrySystemServiceImpl).set(registerPaymentARServiceRunner);
        field("lasvcPrepaidTonsAdapter").ofType(LASVCPrepaidTonsAdapter.class).in(industrySystemServiceImpl).set(this.lasvcPrepaidTonsAdapter);
        field("logger").ofType(Logger.class).in(industrySystemServiceImpl).set(this.logger);
        initalizateSale();
        cancellation = mock(Cancellation.class);
    }

    @Test
    public void testCancelPaymentCallsLasvcPrepaidTonsAdapterCancelPayment_WhenCancellatingPaymentForBrazil()
            throws Exception, MalformedURLException,
            InfraException {
        // @Given sale for Brazil for and cancellation
        sale.getGrower().getDocument().getDocumentType().getCountry()
                .setCode("BR");

        // @When cancel a paid payment
        when(cancellation.isCancelPaidSaleOrder()).thenReturn(true);
        industrySystemServiceImpl.cancelPayment(sale, cancellation);

        // @Then no cancelation is performed
        Mockito.verify(cancelPaidSaleARServiceRunner, Mockito.never()).run(sale);

        // @Given sale for Brazil for and cancellation
        sale.getGrower().getDocument().getDocumentType().getCountry()
                .setCode("BR");

        // @When cancel a unpaid payment
        when(cancellation.isCancelPaidSaleOrder()).thenReturn(false);
        industrySystemServiceImpl.cancelPayment(sale, cancellation);

        // @Then no cancelation is performed
        Mockito.verify(cancelUnPaidSaleARServiceRunner, Mockito.never()).run(sale);
    }

    @Test
    public void testCancelPaymentCallsLasvcPrepaidTonsAdapterCancelPayment_WhenCancellatingPaymentForParaguay()
            throws Exception, MalformedURLException,
            InfraException {
        // @Given sale for Paraguay for and cancellation
        sale.getGrower().getDocument().getDocumentType().getCountry()
                .setCode("PY");

        // @When cancel a paid payment
        when(cancellation.isCancelPaidSaleOrder()).thenReturn(true);
        industrySystemServiceImpl.cancelPayment(sale, cancellation);

        // @Then no cancelation is performed
        Mockito.verify(cancelPaidSaleARServiceRunner, Mockito.never()).run(sale);

        // @Given sale for Paraguay for and cancellation
        sale.getGrower().getDocument().getDocumentType().getCountry()
                .setCode("PY");

        // @When cancel a unpaid payment
        when(cancellation.isCancelPaidSaleOrder()).thenReturn(false);
        industrySystemServiceImpl.cancelPayment(sale, cancellation);

        // @Then no cancelation is performed
        Mockito.verify(cancelUnPaidSaleARServiceRunner, Mockito.never()).run(sale);
    }

    @Test
    public void testCancelPaymentCallsLasvcPrepaidTonsAdapterCancelPaymentForcingException()
            throws Exception, MalformedURLException,
            InfraException {

        sale.getGrower().getDocument().getDocumentType().getCountry()
                .setCode("AR");
        // @Given cancelPaidSaleARServiceRunner.run throws exception
        when(cancellation.isCancelPaidSaleOrder()).thenReturn(true);
        Mockito.doThrow(Exception.class).when(cancelPaidSaleARServiceRunner).run(sale);

        // @When creating a payment cancellation
        industrySystemServiceImpl.cancelPayment(sale, cancellation);

        // @Then a logger is obtained
        Mockito.verify(logger, Mockito.times(1)).warn(Mockito.eq("Problem canceling sale in IS for Argentina"), Mockito.any(Exception.class));
    }

    private void initalizateSale() {
        Country country = new Country();
        DocumentType documentType = new DocumentType();
        documentType.setCountry(country);
        Document document = new Document();
        document.setDocumentType(documentType);
        Grower grower = new Grower();
        grower.setDocument(document);
        sale = new Sale(mock(Customer.class), grower);
        sale.setGrower(grower);
    }

}
