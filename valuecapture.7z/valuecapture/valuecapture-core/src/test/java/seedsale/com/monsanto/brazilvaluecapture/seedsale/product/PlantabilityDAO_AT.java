package com.monsanto.brazilvaluecapture.seedsale.product;

import java.math.BigDecimal;
import java.util.List;
import java.util.Set;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.monsanto.brazilvaluecapture.core.base.SystemTestFixture;
import com.monsanto.brazilvaluecapture.core.foundation.model.bean.StatusEnum;
import com.monsanto.brazilvaluecapture.core.foundation.test.AbstractServiceIntegrationTests;
import com.monsanto.brazilvaluecapture.seedsale.harvest.HarvestTestData;
import com.monsanto.brazilvaluecapture.seedsale.harvest.model.bean.Harvest;
import com.monsanto.brazilvaluecapture.seedsale.harvest.model.bean.Plantability;
import com.monsanto.brazilvaluecapture.seedsale.harvest.model.bean.PlantabilitySystemEnum;
import com.monsanto.brazilvaluecapture.seedsale.harvest.model.dao.PlantabilityDAO;
import com.monsanto.brazilvaluecapture.seedsale.harvest.service.PlantabilityWithProductivityUndeletableException;
import com.monsanto.brazilvaluecapture.seedsale.harvest.service.PlantabilityWithSaleTemplateUndeletableException;
import com.monsanto.brazilvaluecapture.seedsale.product.model.bean.Product;
import com.monsanto.brazilvaluecapture.seedsale.product.model.bean.Productivity;
import com.monsanto.brazilvaluecapture.seedsale.sale.service.PlantabilitiesSelector;
import com.monsanto.brazilvaluecapture.seedsale.template.model.bean.Fix;

public class PlantabilityDAO_AT extends AbstractServiceIntegrationTests {
	
	@Autowired
	private PlantabilityDAO plantabilityDAO;
	
	private Harvest harvest2012;
	private Product randomProduct;
	private Product randomProduct2;
	private Plantability anyPlantability;
	private Plantability anotherPlantability;
	private Plantability systemPlantability;

	@Before
	public void init() {
		systemTestFixture = new SystemTestFixture(this);
		
		harvest2012 = HarvestTestData.createHarvest(systemTestFixture.soy, systemTestFixture.operationalYearOf2011, systemTestFixture.monsantoBr);
		getSession().saveOrUpdate(harvest2012);

		randomProduct = ProductTestData.createProduct(systemTestFixture.monsoy, systemTestFixture.soy, systemTestFixture.intacta, StatusEnum.ACTIVE, systemTestFixture.monsantoBr);
		getSession().saveOrUpdate(randomProduct);
		
		randomProduct2 = ProductTestData.createProduct(systemTestFixture.monsoy, systemTestFixture.soy, systemTestFixture.rr, StatusEnum.ACTIVE, systemTestFixture.monsantoBr);
		getSession().saveOrUpdate(randomProduct2);
		
		anyPlantability = PlantabilityTestData.createPlantability(harvest2012);
		getSession().saveOrUpdate(anyPlantability);
		
		anotherPlantability = PlantabilityTestData.createPlantability(harvest2012);
		getSession().saveOrUpdate(anotherPlantability);
		
		systemPlantability = PlantabilityTestData.createPlantability(harvest2012);
		systemPlantability.setIsPlantabilitySystem(PlantabilitySystemEnum.YES);
		getSession().saveOrUpdate(systemPlantability);
	}

	private void createProductivityValuesFromMatoGrossoDoSul() {
		getSession().saveOrUpdate(ProductivityTestData.createProductivityValue(systemTestFixture.matoGrossoDoSul, anyPlantability, randomProduct));
		getSession().saveOrUpdate(ProductivityTestData.createProductivityValue(systemTestFixture.matoGrossoDoSul, anotherPlantability, randomProduct));
		getSession().saveOrUpdate(ProductivityTestData.createProductivityValue(systemTestFixture.matoGrossoDoSul, systemPlantability, randomProduct));
		
		getSession().saveOrUpdate(ProductivityTestData.createProductivityValue(systemTestFixture.matoGrossoDoSul, anyPlantability, randomProduct2));
		getSession().saveOrUpdate(ProductivityTestData.createProductivityValue(systemTestFixture.matoGrossoDoSul, anotherPlantability, randomProduct2));
		getSession().saveOrUpdate(ProductivityTestData.createProductivityValue(systemTestFixture.matoGrossoDoSul, systemPlantability, randomProduct2));
	}

	@Test
	public void when_stateHarvestProduct_doesnotHave_productivityValues_shoudBeReturn_anEmptyList() {
		getSession().saveOrUpdate(ProductivityTestData.createProductivity(systemTestFixture.matoGrossoDoSul, anyPlantability));
		getSession().saveOrUpdate(ProductivityTestData.createProductivity(systemTestFixture.matoGrossoDoSul, anotherPlantability));
		getSession().saveOrUpdate(ProductivityTestData.createProductivity(systemTestFixture.matoGrossoDoSul, systemPlantability));
		
		Set<Plantability> plantabilities = plantabilityDAO.selectPlantabilitiesBy(systemTestFixture.matoGrossoDoSul, harvest2012, randomProduct);
		
		Assert.assertNotNull("Plantabilities should not be null", plantabilities);
		Assert.assertEquals("Plantabilities should be empty", 0, plantabilities.size());
	}
	
	@Test
	public void when_stateHarvestProduct_have_productivityValue_shouldBeReturn_aListPlantabilities() {
		createProductivityValuesFromMatoGrossoDoSul();
		
		getSession().flush();
		
		Set<Plantability> plantabilities = plantabilityDAO.selectPlantabilitiesBy(systemTestFixture.matoGrossoDoSul, harvest2012, randomProduct);
		
		Assert.assertNotNull("Plantabilities should not be null", plantabilities);
		Assert.assertEquals("Should have plantabilities", 3, plantabilities.size());
	}
	
	@Test
	public void given_productivityValue_with_zeroValue_when_selectPlantabilitiesBy_then_should_return_noResults() {
		Productivity productivity = ProductivityTestData.createProductivityValue(systemTestFixture.matoGrossoDoSul, anyPlantability, randomProduct);
		productivity.getProductivityValues().iterator().next().setProductivityMax(BigDecimal.valueOf(0L));
		productivity.getProductivityValues().iterator().next().setProductivityMin(BigDecimal.valueOf(0L));
		
		getSession().saveOrUpdate(productivity);
		
		Set<Plantability> plantabilities = plantabilityDAO.selectPlantabilitiesBy(systemTestFixture.matoGrossoDoSul, harvest2012, randomProduct);
		
		Assert.assertEquals("Should have no plantabilities", 0, plantabilities.size());
	}
	
	@Test
	public void when_stateHarvestProduct_twice_have_productivityValue_shouldBeReturn_aListPlantabilities() {
		createProductivityValuesFromMatoGrossoDoSul();
		
		getSession().flush();
		
		Set<Plantability> plantabilities = plantabilityDAO.selectPlantabilitiesBy(systemTestFixture.matoGrossoDoSul, harvest2012, randomProduct);
		
		Assert.assertNotNull("Plantabilities should not be null", plantabilities);
		Assert.assertEquals("Should have plantabilities", 3, plantabilities.size());
		
		PlantabilitiesSelector selector = new PlantabilitiesSelector(plantabilityDAO.selectPlantabilitiesBy(systemTestFixture.matoGrossoDoSul, harvest2012, randomProduct2), systemTestFixture.matoGrossoDoSul);
		
		Plantability plantability = selector.getPlantabilityByPriceType(new Fix());
		plantability.getAverageProductivityValue(randomProduct2, systemTestFixture.matoGrossoDoSul);
	}

	@Test
	public void when_stateHarvestProduct_have_productivityValue_shouldBeReturn_theAverageProductivityValueOfState() {
		createProductivityValuesFromMatoGrossoDoSul();
		
		getSession().flush();
		
		Set<Plantability> plantabilities = plantabilityDAO.selectPlantabilitiesBy(systemTestFixture.matoGrossoDoSul, harvest2012, randomProduct);
		Plantability thePlantability = plantabilities.iterator().next();
		BigDecimal theValue = thePlantability.getAverageProductivityValue(randomProduct, systemTestFixture.matoGrossoDoSul);
		
		Long expectedAverage = (long) Math.round((ProductivityTestData.MAXIMUM_PRODUCTIVITY_VALUE.doubleValue() + ProductivityTestData.MINIMUM_PRODUCTIVITY_VALUE.doubleValue()) / 2 );
		Assert.assertEquals("Average productivity value is incorrect", new BigDecimal(expectedAverage), theValue);
	}

	@Test
	public void testInsert(){
		
		Plantability plantability = PlantabilityTestData.createPlantability(harvest2012);
		getSession().saveOrUpdate(plantability);
		
		plantabilityDAO.save(plantability);
		
		testAssert(plantability);
		
		Long id = plantability.getId();
		
		Plantability plantabilityBase = plantabilityDAO.selectById(id);
		
		Assert.assertNotNull(plantabilityBase);
		Assert.assertEquals(plantability, plantabilityBase);
		Assert.assertEquals(plantability.getId(), plantabilityBase.getId());
	}
	
	@Test
	public void testSelectAllPlantabilityEqualsInsert() {
        
//		Harvest harvest = getCreateTestData().createFullHarvest();
		
		Plantability plantability = PlantabilityTestData.createPlantability(harvest2012);
		getSession().saveOrUpdate(plantability);
		
    	// creating a new plantability
		Plantability plantabilityBase = new Plantability();
    	plantabilityBase.setHarvest(harvest2012);
    	plantabilityBase.setIsPlantabilitySystem(plantability.getIsPlantabilitySystem());
    	plantabilityBase.setStatus(plantability.getStatus());
    	plantabilityBase.setDescription(plantability.getDescription());
    	
    	List<Plantability> plantabilities = plantabilityDAO.selectAllPlantabilityEquals(plantabilityBase);
    	
    	Assert.assertNotNull(plantabilities);
    	Assert.assertFalse(plantabilities.isEmpty());
    	Assert.assertTrue(plantabilities.size() == 1);
    }
	
	@Test
	public void testSelectAllProductEqualsUpdate() {
		
		Plantability plantability = PlantabilityTestData.createPlantability(harvest2012);
		getSession().saveOrUpdate(plantability);
		Plantability plantability2 = PlantabilityTestData.createPlantability(harvest2012);
		getSession().saveOrUpdate(plantability2);
        
		// creating a new plantability
		Plantability plantabilityBase = new Plantability();
		plantabilityBase.setId(plantability2.getId());
    	plantabilityBase.setHarvest(harvest2012);
    	plantabilityBase.setIsPlantabilitySystem(plantability.getIsPlantabilitySystem());
    	plantabilityBase.setStatus(plantability.getStatus());
    	plantabilityBase.setDescription(plantability.getDescription());
    	
    	List<Plantability> plantabilities = plantabilityDAO.selectAllPlantabilityEquals(plantabilityBase);
    	
    	Assert.assertNotNull(plantabilities);
    	Assert.assertFalse(plantabilities.isEmpty());
    	Assert.assertTrue(plantabilities.size() == 1);
    }
	
		
	@Test
	public void testDelete() throws PlantabilityWithProductivityUndeletableException, PlantabilityWithSaleTemplateUndeletableException{
		
		Plantability plantability = PlantabilityTestData.createPlantability(harvest2012);
		getSession().saveOrUpdate(plantability);
		
		plantabilityDAO.save(plantability);
		
		testAssert(plantability);
		
		Long id = plantability.getId();
		
		plantabilityDAO.delete(plantability);
		
		Plantability plantabilityBase = plantabilityDAO.selectById(id);
		
		Assert.assertNull(plantabilityBase);
		
	}

		
	@Test
	public void testSelectAll(){
		
		int countBegore = plantabilityDAO.selectAll().size();
		
		Plantability plantability = PlantabilityTestData.createPlantability(harvest2012);
		getSession().saveOrUpdate(plantability);
		Plantability plantability2 = PlantabilityTestData.createPlantability(harvest2012);
		getSession().saveOrUpdate(plantability2);
		
		testAssert(plantability);
		testAssert(plantability2);
		
		List<Plantability> plantabilityBase = plantabilityDAO.selectAll();
		
		Assert.assertNotNull(plantabilityBase);
		Assert.assertFalse(plantabilityBase.isEmpty());
		Assert.assertTrue(plantabilityBase.size() == (countBegore+2));
	}

	@Test
	public void testSelectByFilter(){
		
		Plantability plantability = PlantabilityTestData.createPlantability(harvest2012);
		getSession().saveOrUpdate(plantability);
		
		testAssert(plantability);
		
		List<Plantability> plantabilityBase = plantabilityDAO.selectByFilter(plantability);
		
		Assert.assertNotNull(plantabilityBase);
		Assert.assertFalse(plantabilityBase.isEmpty());
		Assert.assertTrue(plantabilityBase.size() == 1);
		Assert.assertTrue(plantabilityBase.iterator().next().getId() == plantability.getId());
	}
	
	@Test
	public void testSelectByFilterNotSystemPlantability(){
		
		Harvest harvest = HarvestTestData.createHarvest(systemTestFixture.soy, systemTestFixture.operationalYearOf2011, systemTestFixture.monsantoBr);
		getSession().saveOrUpdate(harvest);
		
		Plantability plantability = PlantabilityTestData.createPlantability(harvest);
		plantabilityDAO.save(plantability);
		
		Plantability plantability2 = PlantabilityTestData.createPlantability(harvest);
		plantability2.setIsPlantabilitySystem(PlantabilitySystemEnum.NO);
		plantabilityDAO.save(plantability2);
		
		Plantability plantability3 = PlantabilityTestData.createPlantability(harvest);
		plantability3.setIsPlantabilitySystem(PlantabilitySystemEnum.YES);
		plantabilityDAO.save(plantability3);
		
		Plantability filter = new Plantability();
		filter.setHarvest(harvest);
		
		List<Plantability> plantabilityBase = plantabilityDAO.selectByFilter(filter);
		
		Assert.assertNotNull(plantabilityBase);
		Assert.assertFalse(plantabilityBase.isEmpty());
		Assert.assertTrue(plantabilityBase.size() == 2);
	}
	
	@Test
	public void testSelectByFilterWithoutDescription(){
		
		Harvest harvest = HarvestTestData.createHarvest(systemTestFixture.soy, systemTestFixture.operationalYearOf2011, systemTestFixture.monsantoBr);
		getSession().saveOrUpdate(harvest);
		
		Plantability plantability = PlantabilityTestData.createPlantability(harvest);
		getSession().saveOrUpdate(plantability);
		
		Plantability plantabilityFilter = PlantabilityTestData.createPlantability(plantability.getHarvest(), null, plantability.getStatus());
		
		testAssert(plantability);
		
		List<Plantability> plantabilityBase = plantabilityDAO.selectByFilter(plantabilityFilter);
		
		Assert.assertNotNull(plantabilityBase);
		Assert.assertFalse(plantabilityBase.isEmpty());
		Assert.assertTrue(plantabilityBase.size() == 1);
		Assert.assertTrue(plantabilityBase.iterator().next().getId() == plantability.getId());
	}
	
	@Test
	public void testSelectByHarvest(){
		Harvest harvest = HarvestTestData.createHarvest(systemTestFixture.soy, systemTestFixture.operationalYearOf2011, systemTestFixture.monsantoBr);
		getSession().saveOrUpdate(harvest);
		
		Plantability plantability = PlantabilityTestData.createPlantability(harvest);
		getSession().saveOrUpdate(plantability);
		
		testAssert(plantability);
		
		List<Plantability> plantabilityBase = plantabilityDAO.selectByHarvest(harvest);
		
		Assert.assertNotNull(plantabilityBase);
		Assert.assertFalse(plantabilityBase.isEmpty());
		Assert.assertTrue(plantabilityBase.size() == 1);
		Assert.assertTrue(plantabilityBase.iterator().next().getId() == plantability.getId());
		
	}
	
	private void testAssert(Plantability plantability) {		
		Assert.assertNotNull(plantability);
		Assert.assertNotNull(plantability.getDescription());
		Assert.assertNotNull(plantability.getHarvest());
		Assert.assertNotNull(plantability.getStatus());
		Assert.assertNotNull(plantability.getId());
	}

}
