package com.monsanto.brazilvaluecapture.seedsale.sale.service;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.hasSize;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;

import com.monsanto.brazilvaluecapture.core.foundation.service.IndustrySystemOperationException;
import junit.framework.Assert;

import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.monsanto.brazilvaluecapture.core.base.SystemTestFixture;
import com.monsanto.brazilvaluecapture.core.foundation.RandomTestData;
import com.monsanto.brazilvaluecapture.core.foundation.test.AbstractServiceIntegrationTests;
import com.monsanto.brazilvaluecapture.core.foundation.util.NumberUtils;
import com.monsanto.brazilvaluecapture.core.user.AccessControlTestFixture;
import com.monsanto.brazilvaluecapture.seedsale.billing.model.bean.Billing;
import com.monsanto.brazilvaluecapture.seedsale.billing.model.bean.CreditStatus;
import com.monsanto.brazilvaluecapture.seedsale.billing.model.dao.BillingFilter;
import com.monsanto.brazilvaluecapture.seedsale.billing.service.BillingConstraintViolationException;
import com.monsanto.brazilvaluecapture.seedsale.product.ProductivityTestData;
import com.monsanto.brazilvaluecapture.seedsale.sale.SaleTestFixture;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.BillingProduct;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.ManualReleaseCredit;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.Sale;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.SaleExtract;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.SaleItem;
import com.monsanto.brazilvaluecapture.seedsale.template.model.bean.Price.ReleaseCreditTypeEnum;
import com.monsanto.brazilvaluecapture.seedsale.template.model.bean.SaleTemplate;

public class SaleExtract_AT extends AbstractServiceIntegrationTests{

	private static final BigDecimal TWO = new BigDecimal(2);


	private static final BigDecimal FIVE_THOUSAND = new BigDecimal("5000.0");


	private static final BigDecimal ONE_MILION_AND_TEN_THOUNSAND = new BigDecimal("1010000");


	private SaleBuilder builder;
	
	
	@Autowired
	private SaleService saleService;
	
	@Before
	public void setup() {
		systemTestFixture = new SystemTestFixture(this);
		saleTestFixture = new SaleTestFixture(this, systemTestFixture);
		accessControlTestFixture = new AccessControlTestFixture(systemTestFixture);
		
		createChargeConsolidateTypes();
	}
	
	
	
	@Test
	public void given_aSale_registred_with_two_first_item_automatically_second_item_on_payment_when_extract_called_then_return_values_with_sucess() throws SaleConstraintViolationException{
		Sale sale = createSaleWithSaleTemplateAutomaticallyAndOnPayment(null);
		
		SaleExtract extract = saleService.getSaleExtract(sale);
		
		assertSummarySale(sale, extract);
		
		assertThat("Size amount by technology ",extract.getAmountByTechnologies(), 
												hasSize(2));
		
	/*	assertTechnologiesOccurrencesOn("Should have technology in amount details",
														extract.getAmountByTechnologies(),
														containsInAnyOrder(containsTechnology(systemTestFixture.intacta),
																		   containsTechnology(systemTestFixture.rr)));
		
		
		assertThat(extract.getAmountByTechnologies(),hasItem(both(containsTechnology(systemTestFixture.intacta)).
													  			and(containsCreditRelease(ONE_MILION_AND_TEN_THOUNSAND)).
													  			and(containsRoyaltyCost(FIVE_THOUSAND)).
													  			and(containsRoyaltyPaid(BigDecimal.ZERO)).
													  			and(containsCreditQuantity(ONE_MILION_AND_TEN_THOUNSAND))));
		

		assertThat(extract.getAmountByTechnologies(),hasItem(both(containsTechnology(systemTestFixture.rr)).
													  			and(containsCreditQuantity(ONE_MILION_AND_TEN_THOUNSAND)).
													  			and(containsRoyaltyCost(FIVE_THOUSAND)).
													  			and(containsRoyaltyPaid(BigDecimal.ZERO)).
													  			and(containsCreditRelease(BigDecimal.ZERO))));
*/
		Assert.assertEquals("Due Date Intacta",null, extract.getAmountByTechnologies().get(0).getDueDate());
		Assert.assertEquals("Due Date Intacta",null, extract.getAmountByTechnologies().get(0).getDueDate());
		
		assertThat("Blling and Product",extract.getBillingsDetails(), hasSize(2));
		Assert.assertEquals("Payment Value",FIVE_THOUSAND, extract.getBillingsDetails().get(0).getPaymentValue());
		Assert.assertEquals("Credit Amount",ONE_MILION_AND_TEN_THOUNSAND, extract.getBillingsDetails().get(0).getCreditAmount());
		Assert.assertEquals("Credits Released",ONE_MILION_AND_TEN_THOUNSAND, extract.getBillingsDetails().get(0).getReleaseCredit());
		Assert.assertEquals("Value Paid ", BigDecimal.ZERO, extract.getBillingsDetails().get(0).getPaidValue());
		Assert.assertEquals("Due Date", SaleTestFixture.APRIL, extract.getBillingsDetails().get(0).getDueDate());
		Assert.assertEquals("Payment Date", null, extract.getBillingsDetails().get(0).getPaymentDate());
		Assert.assertEquals("Billing Credit Status", CreditStatus.RELEASED_AUTOMATICALLY, extract.getBillingsDetails().get(0).getCreditStatus());
		
		
		Assert.assertEquals("Payment Value",FIVE_THOUSAND, extract.getBillingsDetails().get(1).getPaymentValue());
		Assert.assertEquals("Credit Amount",ONE_MILION_AND_TEN_THOUNSAND, extract.getBillingsDetails().get(1).getCreditAmount());
		Assert.assertEquals("Credits Released",BigDecimal.ZERO, extract.getBillingsDetails().get(1).getReleaseCredit());
		Assert.assertEquals("Value Paid ", BigDecimal.ZERO, extract.getBillingsDetails().get(1).getPaidValue());
		Assert.assertEquals("Due Date", SaleTestFixture.APRIL, extract.getBillingsDetails().get(1).getDueDate());
		Assert.assertEquals("Payment Date", null, extract.getBillingsDetails().get(1).getPaymentDate());
		Assert.assertEquals("Billing Credit Status", CreditStatus.ON_PAYMENT, extract.getBillingsDetails().get(1).getCreditStatus());
		
	}
	

	
	@Test
	public void given_aSale_registred_with_one_item_manually_creditstatus_when_extract_called_then_return_values_with_sucess() throws SaleConstraintViolationException{
		Sale sale = createSaleWithSaleTemplateManualRelease(null);
		
		SaleExtract extract = saleService.getSaleExtract(sale);
		
		assertSummarySale(sale, extract);
		
		assertThat("Size amount by technology ",extract.getAmountByTechnologies(), hasSize(1));

		Assert.assertEquals("Technology Intacta",saleTestFixture.productIntactaSoy.getTechnology(), extract.getAmountByTechnologies().get(0).getTechnology());
		Assert.assertEquals("Cost of Royalty Intacta",FIVE_THOUSAND, extract.getAmountByTechnologies().get(0).getRoyaltyCost());
		Assert.assertEquals("CreditQuantaty Intacta",ONE_MILION_AND_TEN_THOUNSAND, extract.getAmountByTechnologies().get(0).getCreditQuantaty());
		Assert.assertEquals("Due Date Intacta",null, extract.getAmountByTechnologies().get(0).getDueDate());
		Assert.assertEquals("Credits Released Intacta",BigDecimal.ZERO, extract.getAmountByTechnologies().get(0).getCreditRelease());
		Assert.assertEquals("Royalty Paid Intacta", BigDecimal.ZERO, extract.getAmountByTechnologies().get(0).getRoyaltyPaid());
		
		assertThat("",extract.getBillingsDetails(), hasSize(1));
		
		Assert.assertEquals("Sale Item Technology",saleTestFixture.productIntactaSoy.getTechnology(), extract.getBillingsDetails().get(0).getBillingsProducts().get(0).getTechnology());
		Assert.assertEquals("Sale Item Credit Amount",ONE_MILION_AND_TEN_THOUNSAND, extract.getBillingsDetails().get(0).getBillingsProducts().get(0).getCreditAmout());
		Assert.assertEquals("Sale Item Credit Released",BigDecimal.ZERO, extract.getBillingsDetails().get(0).getBillingsProducts().get(0).getCreditReleased());
		Assert.assertEquals("Sale item product", saleTestFixture.productIntactaSoy, extract.getBillingsDetails().get(0).getBillingsProducts().get(0).getProduct());
		Assert.assertEquals("Sale item productivity", new BigDecimal(505), extract.getBillingsDetails().get(0).getBillingsProducts().get(0).getProductivity());
		Assert.assertEquals("Sale item plantability", saleTestFixture.plantabilitySystemSoyMonsanto2012.getDescription(), extract.getBillingsDetails().get(0).getBillingsProducts().get(0).getPlantability());
		Assert.assertEquals("Sale item sold quantity", new Long(2000), extract.getBillingsDetails().get(0).getBillingsProducts().get(0).getSoldQuantity());
		
	}
	
	@Test
	public void given_aSale_registred_with_one_item_onPayment_creditstatus_when_extract_called_then_return_values_with_sucess() throws SaleConstraintViolationException, IndustrySystemOperationException {
		Sale sale = createSaleWithSaleTemplateOnPayment(null);
		
		payBillingOf(sale, new BigDecimal(2500), SaleTestFixture.DATE_NOW);
		
		SaleExtract extract = saleService.getSaleExtract(sale);
		
		assertSummarySale(sale, extract);
		
		assertThat("Size amount by technology ",extract.getAmountByTechnologies(), hasSize(1));
		final BigDecimal TWO_THOUNSAND_FIVE_HUNDREDED = NumberUtils.bigDecimalDivide(FIVE_THOUSAND,TWO).setScale(0);

		Assert.assertEquals("Technology Intacta",saleTestFixture.productIntactaSoy.getTechnology(), extract.getAmountByTechnologies().get(0).getTechnology());
		Assert.assertEquals("Cost of Royalty Intacta",FIVE_THOUSAND, extract.getAmountByTechnologies().get(0).getRoyaltyCost());
		Assert.assertEquals("CreditQuantaty Intacta",ONE_MILION_AND_TEN_THOUNSAND, extract.getAmountByTechnologies().get(0).getCreditQuantaty());
		Assert.assertEquals("Due Date Intacta",null, extract.getAmountByTechnologies().get(0).getDueDate());
		Assert.assertEquals("Credits Released Intacta",NumberUtils.bigDecimalDivide(ONE_MILION_AND_TEN_THOUNSAND,TWO).setScale(0), extract.getAmountByTechnologies().get(0).getCreditRelease());
		Assert.assertEquals("Royalty Paid Intacta", TWO_THOUNSAND_FIVE_HUNDREDED, extract.getAmountByTechnologies().get(0).getRoyaltyPaid());
		
		assertThat("Blling and Product",extract.getBillingsDetails(), hasSize(1));
		Assert.assertEquals("Payment Value",FIVE_THOUSAND, extract.getBillingsDetails().get(0).getPaymentValue());
		Assert.assertEquals("Credit Amount",ONE_MILION_AND_TEN_THOUNSAND, extract.getBillingsDetails().get(0).getCreditAmount());
		Assert.assertEquals("Credits Released",NumberUtils.bigDecimalDivide(ONE_MILION_AND_TEN_THOUNSAND,TWO).setScale(0), extract.getBillingsDetails().get(0).getReleaseCredit());
		Assert.assertEquals("Value Paid ", TWO_THOUNSAND_FIVE_HUNDREDED.setScale(4), extract.getBillingsDetails().get(0).getPaidValue());
		Assert.assertEquals("Due Date", SaleTestFixture.APRIL, extract.getBillingsDetails().get(0).getDueDate());
		Assert.assertEquals("Payment Date", SaleTestFixture.DATE_NOW, extract.getBillingsDetails().get(0).getPaymentDate());
		Assert.assertEquals("Billing Credit Status", CreditStatus.ON_PAYMENT, extract.getBillingsDetails().get(0).getCreditStatus());
		
	}
	
	
	@Test
	public void given_aSale_registred_with_one_item_onPayment_creditstatus_when_pay_partially_and_extract_called_then_return_values_with_sucess() throws SaleConstraintViolationException, IndustrySystemOperationException {
	
		final BigDecimal TWO_THOUSAND_FIVE_HUNDRED_POINT_FIFTY = new BigDecimal("2500.50");
		final BigDecimal FIVE_HUNDRED_FIVE_THOUSAND_ONE_HUNDRED_ONE = new BigDecimal("505101");
		
		Sale sale = createSaleWithSaleTemplateOnPayment(null);
		
		payBillingOf(sale, TWO_THOUSAND_FIVE_HUNDRED_POINT_FIFTY, SaleTestFixture.DATE_NOW);
		
		SaleExtract extract = saleService.getSaleExtract(sale);
		
		assertSummarySale(sale, extract);
		
		assertThat("Size amount by technology ",extract.getAmountByTechnologies(), hasSize(1));

		Assert.assertEquals("Technology Intacta",saleTestFixture.productIntactaSoy.getTechnology(), extract.getAmountByTechnologies().get(0).getTechnology());
		Assert.assertEquals("Cost of Royalty Intacta",FIVE_THOUSAND, extract.getAmountByTechnologies().get(0).getRoyaltyCost());
		Assert.assertEquals("CreditQuantaty Intacta",ONE_MILION_AND_TEN_THOUNSAND, extract.getAmountByTechnologies().get(0).getCreditQuantaty());
		Assert.assertEquals("Due Date Intacta",null, extract.getAmountByTechnologies().get(0).getDueDate());
		Assert.assertEquals("Credits Released Intacta",FIVE_HUNDRED_FIVE_THOUSAND_ONE_HUNDRED_ONE, extract.getAmountByTechnologies().get(0).getCreditRelease());
		Assert.assertEquals("Royalty Paid Intacta", TWO_THOUSAND_FIVE_HUNDRED_POINT_FIFTY, extract.getAmountByTechnologies().get(0).getRoyaltyPaid());
		
		assertThat("Blling and Product",extract.getBillingsDetails(), hasSize(1));
		Assert.assertEquals("Payment Value",FIVE_THOUSAND, extract.getBillingsDetails().get(0).getPaymentValue());
		Assert.assertEquals("Credit Amount",ONE_MILION_AND_TEN_THOUNSAND, extract.getBillingsDetails().get(0).getCreditAmount());
		Assert.assertEquals("Credits Released",FIVE_HUNDRED_FIVE_THOUSAND_ONE_HUNDRED_ONE, extract.getBillingsDetails().get(0).getReleaseCredit());
		Assert.assertEquals("Value Paid ", TWO_THOUSAND_FIVE_HUNDRED_POINT_FIFTY.setScale(4), extract.getBillingsDetails().get(0).getPaidValue());
		Assert.assertEquals("Due Date", SaleTestFixture.APRIL, extract.getBillingsDetails().get(0).getDueDate());
		Assert.assertEquals("Payment Date", SaleTestFixture.DATE_NOW, extract.getBillingsDetails().get(0).getPaymentDate());
		Assert.assertEquals("Billing Credit Status", CreditStatus.ON_PAYMENT, extract.getBillingsDetails().get(0).getCreditStatus());
		
	}
	
	
	@Test
	public void given_aSale_registred_with_one_item_manually_released_creditstatus_when_extract_called_then_return_values_with_sucess() throws SaleConstraintViolationException{
		Sale sale = createSaleWithSaleTemplateManualRelease(null);
		
		releaseManually(sale);
		
		SaleExtract extract = saleService.getSaleExtract(sale);
		
		assertSummarySale(sale, extract);
		
		assertThat("Size amount by technology ",extract.getAmountByTechnologies(), hasSize(1));

		Assert.assertEquals("Technology Intacta",saleTestFixture.productIntactaSoy.getTechnology(), extract.getAmountByTechnologies().get(0).getTechnology());
		Assert.assertEquals("Cost of Royalty Intacta",FIVE_THOUSAND, extract.getAmountByTechnologies().get(0).getRoyaltyCost());
		Assert.assertEquals("CreditQuantaty Intacta",ONE_MILION_AND_TEN_THOUNSAND, extract.getAmountByTechnologies().get(0).getCreditQuantaty());
		Assert.assertEquals("Due Date Intacta",null, extract.getAmountByTechnologies().get(0).getDueDate());
		Assert.assertEquals("Credits Released Intacta",ONE_MILION_AND_TEN_THOUNSAND, extract.getAmountByTechnologies().get(0).getCreditRelease());
		Assert.assertEquals("Royalty Paid Intacta", BigDecimal.ZERO, extract.getAmountByTechnologies().get(0).getRoyaltyPaid());
		
		assertThat("",extract.getBillingsDetails(), hasSize(1));
		
		Assert.assertEquals("Sale Item Technology",saleTestFixture.productIntactaSoy.getTechnology(), extract.getBillingsDetails().get(0).getBillingsProducts().get(0).getTechnology());
		Assert.assertEquals("Sale Item Credit Amount",ONE_MILION_AND_TEN_THOUNSAND, extract.getBillingsDetails().get(0).getBillingsProducts().get(0).getCreditAmout());
		Assert.assertEquals("Sale Item Credit Released",ONE_MILION_AND_TEN_THOUNSAND, extract.getBillingsDetails().get(0).getBillingsProducts().get(0).getCreditReleased());
		Assert.assertEquals("Sale item product", saleTestFixture.productIntactaSoy, extract.getBillingsDetails().get(0).getBillingsProducts().get(0).getProduct());
		Assert.assertEquals("Sale item productivity", new BigDecimal(505), extract.getBillingsDetails().get(0).getBillingsProducts().get(0).getProductivity());
		Assert.assertEquals("Sale item plantability", saleTestFixture.plantabilitySystemSoyMonsanto2012.getDescription(), extract.getBillingsDetails().get(0).getBillingsProducts().get(0).getPlantability());
		Assert.assertEquals("Sale item sold quantity", new Long(2000), extract.getBillingsDetails().get(0).getBillingsProducts().get(0).getSoldQuantity());
		
	}


	private void releaseManually(Sale sale) {
		Collection<ManualReleaseCredit> manualCredits = new ArrayList<ManualReleaseCredit>();
		BillingFilter billingFilter = new BillingFilter(); 
		billingFilter.add(sale.getId());
		List<Billing> billins  = saleService.getBillingBy(billingFilter);
		for (Billing billing : billins) {
			manualCredits.add(new ManualReleaseCredit(billing, sale));
			
		}	
		
		saleService.manageManualReleases( manualCredits );
	}

	@Test
	public void given_aSale_registred_with_three_items_automatically_creditstatus_when_extract_called_then_return_values_with_sucess() throws SaleConstraintViolationException{
		Sale sale = createSaleWithSaleTemplateWithThreeAutomatically(null);
		
		SaleExtract extract = saleService.getSaleExtract(sale);
		
		assertSummarySale(sale, extract);
		
		assertThat("Size amount by technology ",extract.getAmountByTechnologies(), hasSize(2));

		Assert.assertEquals("Technology Intacta",saleTestFixture.productIntactaSoy.getTechnology(), extract.getAmountByTechnologies().get(0).getTechnology());
		Assert.assertEquals("Technology RR",saleTestFixture.productRRSoy.getTechnology(), extract.getAmountByTechnologies().get(1).getTechnology());
		Assert.assertEquals("Cost of Royalty Intacta",FIVE_THOUSAND.multiply(TWO), extract.getAmountByTechnologies().get(0).getRoyaltyCost());
		Assert.assertEquals("Cost of Royalty RR",FIVE_THOUSAND, extract.getAmountByTechnologies().get(1).getRoyaltyCost());
		Assert.assertEquals("CreditQuantaty Intacta",ONE_MILION_AND_TEN_THOUNSAND.multiply(TWO), extract.getAmountByTechnologies().get(0).getCreditQuantaty());
		Assert.assertEquals("CreditQuantaty RR",ONE_MILION_AND_TEN_THOUNSAND.multiply(TWO), extract.getAmountByTechnologies().get(0).getCreditQuantaty());
		Assert.assertEquals("Credits Released Intacta",ONE_MILION_AND_TEN_THOUNSAND.multiply(TWO), extract.getAmountByTechnologies().get(0).getCreditRelease());
		Assert.assertEquals("Credits Released RR",ONE_MILION_AND_TEN_THOUNSAND, extract.getAmountByTechnologies().get(1).getCreditRelease());
		Assert.assertEquals("Royalty Paid Intacta", BigDecimal.ZERO, extract.getAmountByTechnologies().get(0).getRoyaltyPaid());
		Assert.assertEquals("Royalty Paid RR", BigDecimal.ZERO, extract.getAmountByTechnologies().get(1).getRoyaltyPaid());

	}




	private void payBillingOf(Sale sale, BigDecimal value, Date payDate)
            throws BillingConstraintViolationException, IndustrySystemOperationException {
		BillingFilter billingFilter = new BillingFilter(); 
		billingFilter.add(sale.getId());
		List<Billing> billins  = saleService.getBillingBy(billingFilter);
		
		for (Billing billing : billins) {
            try {
                saleService.payBilling(billing, payDate, value, true);
            } catch (com.monsanto.brazilvaluecapture.core.foundation.service.BusinessException e) {
                e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
            }
        }
	}


	private Sale createSaleWithSaleTemplateOnPayment(String invoiceNumber) throws SaleConstraintViolationException {
		saleTestFixture.templateFreeWithDueDateRange.
		getPriceOf(saleTestFixture.productIntactaSoy.getTechnology()).
				setReleaseCreditType(ReleaseCreditTypeEnum.ON_PAYMENT) ;

		saveAndFlush(saleTestFixture.templateFreeWithDueDateRange);
		
		SaleItemFactory saleItemFactory =  SaleItemFactory.getInstance(systemTestFixture.matoGrossoDoSul, saleTestFixture.plantabilitiesSelector);
		
		SaleItem saleItem =	saleItemFactory.createSaleItem(saleTestFixture.productIntactaSoy, 
		saleTestFixture.templateFreeWithDueDateRange, 
		saleTestFixture.officeCustomer, 
		2000L, 
		SaleTestFixture.TWO_POINT_FIVE_DOLLARS, 
		saleTestFixture.plantabilitySystemSoyMonsanto2012, 
		SaleTestFixture.APRIL);
		
		return createGenericSale(invoiceNumber, saleTestFixture.templateFreeWithDueDateRange,saleItem);
	}


	private void assertSummarySale(Sale sale, SaleExtract extract) {
		Assert.assertEquals("Creation Date",			sale.getCreationDate() , extract.getDate());
		Assert.assertEquals("Creation Invoice Number ",	sale.getInvoiceNumber() , extract.getInvoiceNumber());
		Assert.assertEquals("Creation Invoice Date ",	sale.getInvoiceDate() , extract.getInvoiceDate());
		Assert.assertEquals("Creation Customer",		sale.getDistributorFullNameAndDocument() , extract.getDistributor());
		Assert.assertEquals("Creation State",			sale.getState().getCode() , extract.getState());
	}
	
	private Sale createSaleWithSaleTemplateManualRelease(String invoiceNumber) throws SaleConstraintViolationException {

		saleTestFixture.templateFreeWithDueDateRange.
						getPriceOf(saleTestFixture.productIntactaSoy.getTechnology()).
								setReleaseCreditType(ReleaseCreditTypeEnum.MANUALLY) ;
		
		saveAndFlush(saleTestFixture.templateFreeWithDueDateRange);
		
		SaleItemFactory saleItemFactory =  SaleItemFactory.getInstance(systemTestFixture.matoGrossoDoSul, saleTestFixture.plantabilitiesSelector);
		
		SaleItem saleItem =	saleItemFactory.createSaleItem(saleTestFixture.productIntactaSoy, 
				saleTestFixture.templateFreeWithDueDateRange, 
				saleTestFixture.officeCustomer, 
				2000L, 
				SaleTestFixture.TWO_POINT_FIVE_DOLLARS, 
				saleTestFixture.plantabilitySystemSoyMonsanto2012, 
				SaleTestFixture.APRIL);
		
		return createGenericSale(invoiceNumber, saleTestFixture.templateFreeWithDueDateRange,saleItem);
	}
	
	private Sale createSaleWithSaleTemplateAutomaticallyAndOnPayment(String invoiceNumber) throws SaleConstraintViolationException {

		saleTestFixture.templateFreeWithDueDateRange.
						getPriceOf(saleTestFixture.productIntactaSoy.getTechnology()).
								setReleaseCreditType(ReleaseCreditTypeEnum.AUTOMATICALLY) ;
		
	
		
		saleTestFixture.templateFreeWithDueDateRange.addProduct(saleTestFixture.productRRSoy);
		
		saleTestFixture.templateFreeWithDueDateRange.
		getPriceOf(saleTestFixture.productRRSoy.getTechnology()).
				setReleaseCreditType(ReleaseCreditTypeEnum.ON_PAYMENT) ;
	
		saveAndFlush(saleTestFixture.templateFreeWithDueDateRange);
		
		SaleItemFactory saleItemFactory =  SaleItemFactory.getInstance(systemTestFixture.matoGrossoDoSul, saleTestFixture.plantabilitiesSelector);
		
		SaleItem saleItem =	saleItemFactory.createSaleItem(saleTestFixture.productIntactaSoy, 
				saleTestFixture.templateFreeWithDueDateRange, 
				saleTestFixture.officeCustomer, 
				2000L, 
				SaleTestFixture.TWO_POINT_FIVE_DOLLARS, 
				saleTestFixture.plantabilitySystemSoyMonsanto2012, 
				SaleTestFixture.APRIL);
		
		SaleItem saleItem2 =	saleItemFactory.createSaleItem(saleTestFixture.productRRSoy, 
				saleTestFixture.templateFreeWithDueDateRange, 
				saleTestFixture.officeCustomer, 
				2000L, 
				SaleTestFixture.TWO_POINT_FIVE_DOLLARS, 
				saleTestFixture.plantabilitySystemSoyMonsanto2012, 
				SaleTestFixture.APRIL);
		
		
		return createGenericSale(invoiceNumber, saleTestFixture.templateFreeWithDueDateRange, saleItem,saleItem2);
	}
	
	
	private Sale createSaleWithSaleTemplateWithThreeAutomatically(String invoiceNumber) throws SaleConstraintViolationException {

		saleTestFixture.templateFreeWithDueDateRange.
						getPriceOf(saleTestFixture.productIntactaSoy.getTechnology()).
								setReleaseCreditType(ReleaseCreditTypeEnum.AUTOMATICALLY) ;
		
		saleTestFixture.templateFreeWithDueDateRange.
						getPriceOf(saleTestFixture.productRRSoy.getTechnology()).
							setReleaseCreditType(ReleaseCreditTypeEnum.AUTOMATICALLY) ;
	
		ProductivityTestData.addProductivityValue(saleTestFixture.productivityOfSystemSoyMonsanto2012AtMatoGrossoDoSul, saleTestFixture.productIntactaSoy2);
		saveAndFlush(saleTestFixture.productivityOfSystemSoyMonsanto2012AtMatoGrossoDoSul);
		
		saleTestFixture.templateFreeWithDueDateRange.
					getPriceOf(saleTestFixture.productIntactaSoy2.getTechnology()).
							setReleaseCreditType(ReleaseCreditTypeEnum.AUTOMATICALLY) ;

		
		saleTestFixture.templateFreeWithDueDateRange.addProduct(saleTestFixture.productRRSoy);
		saleTestFixture.templateFreeWithDueDateRange.addProduct(saleTestFixture.productIntactaSoy2);
		
	
		saveAndFlush(saleTestFixture.templateFreeWithDueDateRange);
		
		SaleItemFactory saleItemFactory =  SaleItemFactory.getInstance(systemTestFixture.matoGrossoDoSul, saleTestFixture.plantabilitiesSelector);
		
		SaleItem saleItem =	saleItemFactory.createSaleItem(saleTestFixture.productIntactaSoy, 
				saleTestFixture.templateFreeWithDueDateRange, 
				saleTestFixture.officeCustomer, 
				2000L, 
				SaleTestFixture.TWO_POINT_FIVE_DOLLARS, 
				saleTestFixture.plantabilitySystemSoyMonsanto2012, 
				SaleTestFixture.APRIL);
		
		SaleItem saleItem2 =	saleItemFactory.createSaleItem(saleTestFixture.productRRSoy, 
				saleTestFixture.templateFreeWithDueDateRange, 
				saleTestFixture.officeCustomer, 
				2000L, 
				SaleTestFixture.TWO_POINT_FIVE_DOLLARS, 
				saleTestFixture.plantabilitySystemSoyMonsanto2012, 
				SaleTestFixture.APRIL);
		
		SaleItem saleItem3 =	saleItemFactory.createSaleItem(saleTestFixture.productIntactaSoy2, 
				saleTestFixture.templateFreeWithDueDateRange, 
				saleTestFixture.officeCustomer, 
				2000L, 
				SaleTestFixture.TWO_POINT_FIVE_DOLLARS, 
				saleTestFixture.plantabilitySystemSoyMonsanto2012, 
				SaleTestFixture.APRIL);
		
		return createGenericSale(invoiceNumber, saleTestFixture.templateFreeWithDueDateRange, saleItem,saleItem2,saleItem3);
	}
	
	private Sale createGenericSale(String invoiceNumber, SaleTemplate saleTemplate, SaleItem...saleItems)
			throws SaleConstraintViolationException {
		
		builder = new SaleBuilder(systemTestFixture.matoGrossoDoSul, saleTestFixture.plantabilitiesSelector);
		
		builder.clear();
		for (SaleItem saleItem : saleItems) {
			builder.add(saleItem);
		}
		
		Sale sale = builder.setGrower(saleTestFixture.chicoBento).setCustomer(saleTestFixture.customer).buildSale();
		sale.setCreationDate(SaleTestFixture.DATE_NOW);
        sale.setRegion(systemTestFixture.regionSaoPaulo2012);
		
		if ( invoiceNumber != null ) {
			sale.setInvoiceNumber(invoiceNumber);
		}
		
		accessControlTestFixture.superUser.setContextCrop(systemTestFixture.soy);
		accessControlTestFixture.superUser.setContextCompany(systemTestFixture.monsantoBr);
		
		saleService.save(sale, accessControlTestFixture.superUser);
		return sale;
	}
	
	@Test
	public void given_extract_with_two_tech_should_have_summarizedValues_by_tech_and_by_sale() throws SaleConstraintViolationException {
		Sale sale = createSaleWithSaleTemplateAutomaticallyAndOnPayment(null);
		SaleExtract extract = saleService.getSaleExtract(sale);
		
		BillingProduct billingProductTechnologyIntacta = extract.getBillingsDetails().get(0).getBillingsProducts().get(0);
		BillingProduct billingProductTechnologyRR = extract.getBillingsDetails().get(1).getBillingsProducts().get(0);
		
		Assert.assertEquals("Technology Intacta", systemTestFixture.intacta, billingProductTechnologyIntacta.getTechnology());
		Assert.assertEquals("Technology RR", systemTestFixture.rr, billingProductTechnologyRR.getTechnology());
		
		Assert.assertEquals("Intacta Should have total seed quantity of two thousand", new Long(2000), billingProductTechnologyIntacta.getSummaryTotal().getTotalSoldQuantity());
		Assert.assertEquals("Intacta Should have total credit of one million and ten thousand", ONE_MILION_AND_TEN_THOUNSAND, billingProductTechnologyIntacta.getSummaryTotal().getTotalCreditAmount());
		Assert.assertEquals("Intacta Should have total credit released of one million and ten thousand", ONE_MILION_AND_TEN_THOUNSAND, billingProductTechnologyIntacta.getSummaryTotal().getTotalCreditRelease());
		
		Assert.assertEquals("RR Should have total seed quantity of two thousand", new Long(2000), billingProductTechnologyRR.getSummaryTotal().getTotalSoldQuantity());
		Assert.assertEquals("RR Should have total credit of one million and ten thousand", ONE_MILION_AND_TEN_THOUNSAND, billingProductTechnologyRR.getSummaryTotal().getTotalCreditAmount());
		Assert.assertEquals("RR Should have total credit released of zero", BigDecimal.ZERO, billingProductTechnologyRR.getSummaryTotal().getTotalCreditRelease());
		
	}
	
	@Test
	public void given_aSale_with_one_tech_when_pay_more_than_receiptValue_should_release_all_sale_credit() throws SaleConstraintViolationException, IndustrySystemOperationException {
		Sale sale = createSaleWithSaleTemplateOnPayment(null);
		payBillingOf(sale, new BigDecimal(10000), SaleTestFixture.DATE_NOW);
		
		SaleExtract saleExtract = saleService.getSaleExtract(sale);
		
		Assert.assertEquals("Should have only one amount by technology", 1, saleExtract.getAmountByTechnologies().size());
		Assert.assertEquals("Should have one billing detail by technology", 1, saleExtract.getBillingsDetails().size());
		Assert.assertEquals("Should have one billing product by detail", 1, saleExtract.getBillingsDetails().get(0).getBillingsProducts().size());
		
		Assert.assertEquals("Should have one million and ten thousand credit released", ONE_MILION_AND_TEN_THOUNSAND, saleExtract.getAmountByTechnologies().get(0).getCreditRelease());
		Assert.assertEquals("Should have one million and ten thousand credit released", ONE_MILION_AND_TEN_THOUNSAND, saleExtract.getBillingsDetails().get(0).getBillingsProducts().get(0).getCreditReleased());
		Assert.assertEquals("Should have one million and ten thousand credit released", ONE_MILION_AND_TEN_THOUNSAND, saleExtract.getBillingsDetails().get(0).getReleaseCredit());
	}
	
	@Test
	public void given_aSale_with_two_possiblePayments_when_i_pay_last_date_should_display_given_paymentValue_of_date() throws SaleConstraintViolationException, IndustrySystemOperationException {
		SaleItemFactory saleItemFactory =  SaleItemFactory.getInstance(systemTestFixture.matoGrossoDoSul, saleTestFixture.plantabilitiesSelector);

		SaleItem saleItem = saleItemFactory
				.createByPlantabilityDueDateRangeItem(
						saleTestFixture.productIntactaSoy,
						saleTestFixture.templateIntactaByPlantabilityRRByExpirationBtFree,
						saleTestFixture.officeCustomer, 2000L,
						SaleTestFixture.NOVEMBER,
						saleTestFixture.plantability45To54SoyMonsanto2012);
		
		Sale sale = createGenericSale(""+RandomTestData.createRandomLong(), saleTestFixture.templateIntactaByPlantabilityRRByExpirationBtFree, saleItem);
		
		payBillingOf(sale, new BigDecimal(5000L), SaleTestFixture.FEBRUARY);
		
		SaleExtract saleExtract = saleService.getSaleExtract(sale);
		
		Assert.assertEquals("Payment value should match by given date", new BigDecimal(2600L).setScale(1), saleExtract.getBillingsDetails().get(0).getPaymentValue());
		Assert.assertEquals("Royalty cost should be the same of payment value", new BigDecimal(2600L).setScale(1), saleExtract.getAmountByTechnologies().get(0).getRoyaltyCost());
	}

/*	private Matcher<AmountRoyaltyByTechnology> containsRoyaltyPaid(
			BigDecimal fiveThousand) {
		return new IsRoyaltyPaid(fiveThousand);
	}

	private Matcher<AmountRoyaltyByTechnology> containsCreditRelease(
			BigDecimal oneMilionAndTenThounsand) {
		return new IsCreditRelease(oneMilionAndTenThounsand);
	}



	private Matcher<AmountRoyaltyByTechnology> containsRoyaltyCost(
			BigDecimal fiveThousand) {
		return new IsRoyaltyCost(fiveThousand);
	}

	private Matcher<AmountRoyaltyByTechnology> containsCreditQuantity(
		BigDecimal oneMilionAndTenThounsand) {
		return new IsCreditQuatity(oneMilionAndTenThounsand);
	}


	private void assertTechnologiesOccurrencesOn(String text, List<AmountRoyaltyByTechnology> royaltyByTechnology,
			final Matcher<Iterable<? extends AmountRoyaltyByTechnology>> matcher){
		assertThat(royaltyByTechnology, matcher);
	}
	
	@Factory
	public static Matcher<AmountRoyaltyByTechnology> containsTechnology(Technology technology) {
		return new IsTechnology(technology);
	}

	public static class IsTechnology extends TypeSafeMatcher<AmountRoyaltyByTechnology> {
		
		private Technology expectedTechnology;
		
		IsTechnology(Technology technology){
			this.expectedTechnology = technology;
		}

		
		@Override
		public void describeTo(Description description) {
			description.appendText("not have technology ").appendValue(expectedTechnology);
			
		}



		@Override
		protected boolean matchesSafely(AmountRoyaltyByTechnology amountExpected) {
			return this.expectedTechnology.equals(amountExpected.getTechnology());
		}

	}
	
	public static class IsDueDate extends TypeSafeMatcher<AmountRoyaltyByTechnology> {
		
		private Date expectedDueDate;
		
		IsDueDate(Date date){
			this.expectedDueDate = date;
		}

		
		@Override
		public void describeTo(Description description) {
			description.appendText("not have DueDate ").appendValue(expectedDueDate);
			
		}



		@Override
		protected boolean matchesSafely(AmountRoyaltyByTechnology amountExpected) {
			return amountExpected.getDueDate().compareTo(this.expectedDueDate)==0;
		}

	}
	
	public static class IsCreditRelease extends TypeSafeMatcher<AmountRoyaltyByTechnology> {
		
		private BigDecimal expectedValue;
		
		IsCreditRelease(BigDecimal decimal){
			this.expectedValue = decimal;
		}

		
		@Override
		public void describeTo(Description description) {
			description.appendText("not have credit release").appendValue(expectedValue);
			
		}



		@Override
		protected boolean matchesSafely(AmountRoyaltyByTechnology amountExpected) {
			return this.expectedValue.equals(amountExpected.getCreditRelease());
		}

	}
	
	
	public static class IsCreditQuatity extends TypeSafeMatcher<AmountRoyaltyByTechnology> {
		
		private BigDecimal expectedValue;
		
		IsCreditQuatity(BigDecimal decimal){
			this.expectedValue = decimal;
		}

		
		@Override
		public void describeTo(Description description) {
			description.appendText("not have credit quantity").appendValue(expectedValue);
			
		}



		@Override
		protected boolean matchesSafely(AmountRoyaltyByTechnology amountExpected) {
			return this.expectedValue.equals(amountExpected.getCreditQuantaty());
		}

	}
	
	public static class IsRoyaltyPaid extends TypeSafeMatcher<AmountRoyaltyByTechnology> {
		
		private BigDecimal expectedValue;
		
		IsRoyaltyPaid(BigDecimal decimal){
			this.expectedValue = decimal;
		}

		
		@Override
		public void describeTo(Description description) {
			description.appendText("not have Royalty Paid").appendValue(expectedValue);
			
		}



		@Override
		protected boolean matchesSafely(AmountRoyaltyByTechnology amountExpected) {
			return this.expectedValue.equals(amountExpected.getRoyaltyPaid());
		}

	}
	
	
	public static class IsRoyaltyCost extends TypeSafeMatcher<AmountRoyaltyByTechnology> {
		
		private BigDecimal expectedValue;
		
		IsRoyaltyCost(BigDecimal decimal){
			this.expectedValue = decimal;
		}

		
		@Override
		public void describeTo(Description description) {
			description.appendText("not have Royalty Cost").appendValue(expectedValue);
			
		}



		@Override
		protected boolean matchesSafely(AmountRoyaltyByTechnology amountExpected) {
			return this.expectedValue.equals(amountExpected.getRoyaltyCost());
		}

	}*/

	
	
}
