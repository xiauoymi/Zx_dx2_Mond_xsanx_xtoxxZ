package com.monsanto.brazilvaluecapture.seedsale.sale.service.parser;

import com.monsanto.brazilvaluecapture.core.base.SystemTestFixture;
import com.monsanto.brazilvaluecapture.core.base.model.bean.DocumentType.DocumentTypeEnum;
import com.monsanto.brazilvaluecapture.core.foundation.test.AbstractIntegrationTests;
import com.monsanto.brazilvaluecapture.core.foundation.test.AbstractTestFixture;
import com.monsanto.brazilvaluecapture.seedsale.sale.SaleTestFixture;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.CsvSale;

import java.util.ArrayList;
import java.util.List;

public class DirectSaleTestFixture extends AbstractTestFixture {
	
	public static List<CsvSale> importDataForDirectSale = new ArrayList<CsvSale>(); 

	
	public DirectSaleTestFixture(AbstractIntegrationTests context) {
		super(context);
		//setupFixture(saleTestFixture, systemTestFixture,countOfSales);
	}
	/*private void setupFixture(SaleTestFixture saleTestFixture, SystemTestFixture systemTestFixture, Integer countOfSales){
		createImportationDataSuccess(saleTestFixture, systemTestFixture,countOfSales);
	}*/
	public void createImportationDataSuccess(SaleTestFixture saleTestFixture, SystemTestFixture systemTestFixture, Integer countOfSales) {
		importDataForDirectSale = new ArrayList<CsvSale>(); 
		for (int invoiceNumber = 1; invoiceNumber <= countOfSales; invoiceNumber++) {
			importDataForDirectSale.add(createRow(saleTestFixture, systemTestFixture,String.valueOf(invoiceNumber)+"023341", systemTestFixture.monsantoBr.getDescription()));
		}

	}
	public void createImportationDataWithErrosOfDuplicationProducts(SaleTestFixture saleTestFixture, SystemTestFixture systemTestFixture, Integer countOfSales) {
		importDataForDirectSale = new ArrayList<CsvSale>(); 
		for (int invoiceNumber = 1; invoiceNumber <= countOfSales; invoiceNumber++) {
			importDataForDirectSale.add(createRow(saleTestFixture, systemTestFixture,"1234", systemTestFixture.monsantoBr.getDescription()));
		}
	}
	
	public void createImportationDataWithError(SaleTestFixture saleTestFixture, SystemTestFixture systemTestFixture, Integer countOfSales) {
		importDataForDirectSale = new ArrayList<CsvSale>(); 
		for (int invoiceNumber = 1; invoiceNumber <= countOfSales; invoiceNumber++) {
			importDataForDirectSale.add(createRow(saleTestFixture, systemTestFixture,"1234", "1234"));
		}
	}
	
	private CsvSale createRow(SaleTestFixture saleTestFixture, SystemTestFixture systemTestFixture, String invoiceNumber, String companyDescription) {
		CsvSale csvSale = new CsvSale();
		csvSale.setCompany(companyDescription);
		csvSale.setCreationDate(SaleTestFixture.DATE_NOW);
		csvSale.setCrop(systemTestFixture.soy.getDescription());
		
		csvSale.setCustomerDocument(saleTestFixture.matrixCargil.getDocumentValue());
		csvSale.setCustomerDocumentType(DocumentTypeEnum.CNPJ.name());
		csvSale.setCustomerStateRegistration(null);
		csvSale.setDistributorSapCode(saleTestFixture.matrixCargil.getCustomerSAPCode());
		
		csvSale.setDueDate(SaleTestFixture.DATE_NOW);
		csvSale.setGrowerDocument(SaleTestFixture.CHICO_CNPJ);
		csvSale.setGrowerDocumentType(DocumentTypeEnum.CNPJ.name());
		csvSale.setHarvest(saleTestFixture.harvestSoyMonsanto2012.getDescription());
		csvSale.setOperationalYear(systemTestFixture.operationalYearOf2012.getYear());
		
		csvSale.setHeadOfficeDocument(saleTestFixture.headOfficeCargil.getCustomerDocumentValue());
		csvSale.setHeadOfficeDocumentType(saleTestFixture.headOfficeCargil.getHeadOfficeType().name());
		csvSale.setHeadOfficeStateRegistration(null);
		csvSale.setHeadOfficeSapCode(saleTestFixture.headOfficeCargil.getMatrix().getCustomerSAPCode());
		
		csvSale.setInvoiceNumber(invoiceNumber);
		csvSale.setPlantability(saleTestFixture.plantabilitySystemSoyMonsanto2012.getDescription());
		csvSale.setPriceQuantity(SaleTestFixture.FIVE_DOLLARS);
		csvSale.setProductivityValue(505l);
		csvSale.setSaleTemplate(saleTestFixture.templateDirectSaleIntactaFixRRRangeBtNoValue.getDescription());
		csvSale.setSoldQuantity(5l);
		csvSale.setProductCode(saleTestFixture.productIntactaSoy.getId());
		csvSale.setState(systemTestFixture.matoGrossoDoSul.getCode());
		persist(csvSale);
		return csvSale;
	}
	
	
}
