package com.monsanto.brazilvaluecapture.seedsale.harvest.service;

import org.junit.Test;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

/**
 * Created with IntelliJ IDEA.
 * User: JFVERO
 * Date: 24/01/14
 * Time: 12:39
 */
public class HarvestWithVolumeReportUndeletableException_UT {

    @Test
    public void testConstructor() {
        String msg = "abdcd";
        Throwable throwable = mock(Throwable.class);

        HarvestWithVolumeReportUndeletableException exception = new HarvestWithVolumeReportUndeletableException(msg, throwable);

        assertEquals(msg, exception.getMessage());
        assertEquals(throwable, exception.getCause());
    }

}