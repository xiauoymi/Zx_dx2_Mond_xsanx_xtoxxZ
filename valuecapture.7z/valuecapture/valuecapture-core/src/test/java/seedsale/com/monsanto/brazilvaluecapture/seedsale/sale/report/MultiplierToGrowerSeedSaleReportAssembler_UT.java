package com.monsanto.brazilvaluecapture.seedsale.sale.report;

import com.monsanto.brazilvaluecapture.core.foundation.util.report.Money;
import com.monsanto.brazilvaluecapture.core.regionalization.VCCountry;
import junit.framework.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

import static org.mockito.Mockito.when;

/**
 * Created with IntelliJ IDEA.
 * User: AMMUNO
 * To change this template use File | Settings | File Templates.
 */
public class MultiplierToGrowerSeedSaleReportAssembler_UT {

    private final static int SIZE = 63;

    private MultiplierToGrowerSeedSaleReportAssembler assemblerForXLS;
    private MultiplierToGrowerSeedSaleReportAssembler assemblerForCSV;
    private ResourceBundle resourceBundle;

    @Before
    public void setUp() throws  Exception{

        List<SeedSaleReportDTO> seedSaleReportDTOs = new ArrayList<SeedSaleReportDTO>();
        seedSaleReportDTOs.add(Mockito.mock(SeedSaleReportDTO.class));
        seedSaleReportDTOs.add(createSeedSaleReportDTO());

        assemblerForXLS =  MultiplierToGrowerSeedSaleReportAssembler.buildAssembler(seedSaleReportDTOs,ReportOutputTypeEnum.XLS);
        assemblerForCSV =  MultiplierToGrowerSeedSaleReportAssembler.buildAssembler(seedSaleReportDTOs,ReportOutputTypeEnum.CSV);

        resourceBundle = ResourceBundle.getBundle("language", VCCountry.BRAZIL.getLocale());
    }

    private SeedSaleReportDTO createSeedSaleReportDTO() {

        SeedSaleReportDTO seedSaleReportDTO = Mockito.mock(SeedSaleReportDTO.class);

        when(seedSaleReportDTO.getPriceQuantity()).thenReturn(new Money(new BigDecimal(0.0)));
        when(seedSaleReportDTO.getTechnologyValue()).thenReturn(new Money(new BigDecimal(0.0)));
        when(seedSaleReportDTO.getValueTechnologyReceived()).thenReturn(new Money(new BigDecimal(0.0)));
        when(seedSaleReportDTO.getRetributionValue()).thenReturn(new Money(new BigDecimal(0.0)));

        return seedSaleReportDTO;
    }

    @Test
    public void test_build_XLS() throws IOException {

        //@When
        assemblerForXLS.build(resourceBundle);

        //@Should
        Assert.assertSame(ReportOutputTypeEnum.XLS, assemblerForXLS.getReportTypeEnum());
    }

    @Test
    public void test_build_CSV() throws IOException {

        //@When
        assemblerForCSV.buildCsv(resourceBundle);

        //@Should
        Assert.assertSame(ReportOutputTypeEnum.CSV, assemblerForCSV.getReportTypeEnum());

    }

}
