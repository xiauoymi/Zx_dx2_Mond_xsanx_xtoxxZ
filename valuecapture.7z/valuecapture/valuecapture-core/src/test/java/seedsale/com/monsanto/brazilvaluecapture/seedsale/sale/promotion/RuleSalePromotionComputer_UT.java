package com.monsanto.brazilvaluecapture.seedsale.sale.promotion;

import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Customer;
import com.monsanto.brazilvaluecapture.core.foundation.model.bean.SystemParameter;
import com.monsanto.brazilvaluecapture.core.foundation.model.bean.SystemParameterValue;
import com.monsanto.brazilvaluecapture.core.foundation.service.SystemParameterDuplicateException;
import com.monsanto.brazilvaluecapture.core.foundation.service.SystemParameterInvalidException;
import com.monsanto.brazilvaluecapture.core.foundation.service.SystemParameterNotFoundException;
import com.monsanto.brazilvaluecapture.core.foundation.service.SystemParameterService;
import com.monsanto.brazilvaluecapture.core.grower.model.bean.Grower;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.PricingCondition;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.Sale;
import com.monsanto.brazilvaluecapture.seedsale.sale.promotion.model.bean.Rule;
import com.monsanto.brazilvaluecapture.seedsale.sale.promotion.model.bean.SalePromotion;
import com.monsanto.brazilvaluecapture.seedsale.sale.promotion.model.dao.RuleDao;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.List;
import java.util.Set;
import java.util.concurrent.ExecutionException;

import static org.fest.assertions.Assertions.assertThat;
import static org.fest.reflect.core.Reflection.field;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

/**
 * User: ppera
 * Date: 4/25/13
 * Time: 3:12 PM
 */

@RunWith(MockitoJUnitRunner.class)
public class RuleSalePromotionComputer_UT {
    @Mock
    private RuleDao ruleDao;
    @Mock
    private SystemParameterService systemParameterService;
    @InjectMocks
    private RuleSalePromotionComputer ruleSalePromotionComputer;

    @Before
    public void setUp() throws SystemParameterNotFoundException, SystemParameterDuplicateException, SystemParameterInvalidException {
        SystemParameter concurrencySystemParameter = new SystemParameter();
        SystemParameterValue concurrencySystemParameterValue = new SystemParameterValue();
        field("value").ofType(String.class).in(concurrencySystemParameterValue).set("10");
        concurrencySystemParameter.setSystemParameterValue(concurrencySystemParameterValue);

        SystemParameter maxSizeSystemParameter = new SystemParameter();
        SystemParameterValue maxSizeSystemParameterValue = new SystemParameterValue();
        field("value").ofType(String.class).in(maxSizeSystemParameterValue).set("10");
        maxSizeSystemParameter.setSystemParameterValue(maxSizeSystemParameterValue);

        SystemParameter expirationSystemParameter = new SystemParameter();
        SystemParameterValue expirationSystemParameterValue = new SystemParameterValue();
        field("value").ofType(String.class).in(expirationSystemParameterValue).set("10");
        expirationSystemParameter.setSystemParameterValue(expirationSystemParameterValue);

        when(this.systemParameterService.selectParameterByName(RuleSalePromotionComputer.RULE_CACHE_CONCURRENCY_LEVEL_PARAMETER_NAME)).thenReturn(concurrencySystemParameter);
        when(this.systemParameterService.selectParameterByName(RuleSalePromotionComputer.RULE_CACHE_MAX_SIZE_PARAMETER_NAME)).thenReturn(maxSizeSystemParameter);
        when(this.systemParameterService.selectParameterByName(RuleSalePromotionComputer.RULE_CACHE_EXPIRATION_MINUTES_PARAMETER_NAME)).thenReturn(expirationSystemParameter);
    }

    @Test
    public void testComputeReturnsEmptySalePromotionList_WhenThereIsNoRule() throws ExecutionException, SystemParameterNotFoundException, SystemParameterDuplicateException, SystemParameterInvalidException {
        // @Given a Sale
        Sale sale = newSale();

        // @When computing the sale with no rules
        Set<SalePromotion> promotions = this.ruleSalePromotionComputer.compute(sale);

        // @Then no promotion applies
        assertThat(promotions).isNotNull();
        assertThat(promotions).isEmpty();
    }

    private Sale newSale() {
        Sale s = new Sale(new Customer(), new Grower());
        s.setSaleType(Sale.SaleTypeEnum.POD_SALE);
        return s;
    }

    @Test
    public void testComputeReturnsOnePromotion_WhenOneRuleWithOnePromotionPasses() throws ExecutionException, SystemParameterNotFoundException, SystemParameterDuplicateException, SystemParameterInvalidException {
        // @Given a sale
        Sale sale = newSale();
        sale.setSaleType(Sale.SaleTypeEnum.POD_SALE);
        Rule rule = mock(Rule.class);
        when(rule.getId()).thenReturn(1);
        when(rule.isEnabled()).thenReturn(true);
        when(this.ruleDao.findAllRules()).thenReturn(Lists.<Rule>newArrayList(rule));
        when(this.ruleDao.findRuleById(1)).thenReturn(rule);

        when(rule.applies(sale)).thenReturn(true);
        when(rule.getSalePromotions()).thenReturn(Sets.<SalePromotion>newHashSet(new SalePromotion(new PricingCondition("1", "A"))));
        sale.setSaleType(Sale.SaleTypeEnum.POD_SALE);
        // @When There is one rule with one promotion and the sale passes it
        Set<SalePromotion> salePromotions = this.ruleSalePromotionComputer.compute(sale);

        // @Then One promotion is returned
        assertThat(salePromotions).hasSize(1);
    }

    @Test
    public void testComputeReturnsNoPromotion_WhenOneRuleWithOnePromotionWouldPassButIsNotEnabled() throws ExecutionException, SystemParameterNotFoundException, SystemParameterDuplicateException, SystemParameterInvalidException {
        // @Given a sale
        Sale sale = newSale();
        Rule rule = mock(Rule.class);
        when(rule.getId()).thenReturn(1);
        when(rule.isEnabled()).thenReturn(false);
        when(this.ruleDao.findAllRules()).thenReturn(Lists.<Rule>newArrayList(rule));
        when(this.ruleDao.findRuleById(1)).thenReturn(rule);

        when(rule.applies(sale)).thenReturn(true);
        when(rule.getSalePromotions()).thenReturn(Sets.<SalePromotion>newHashSet(new SalePromotion(new PricingCondition("1", "A"))));

        // @When There is one rule with one promotion and the sale passes it
        Set<SalePromotion> salePromotions = this.ruleSalePromotionComputer.compute(sale);

        // @Then One promotion is returned
        assertThat(salePromotions).hasSize(0);
    }

    @Test
    public void testComputeReturnsEmptyList_WhenOneRuleWithOnePromotionDoesNotPass() throws ExecutionException, SystemParameterNotFoundException, SystemParameterDuplicateException, SystemParameterInvalidException {
        // @Given a sale
        Sale sale = newSale();
        Rule rule = mock(Rule.class);
        when(rule.getId()).thenReturn(1);
        when(this.ruleDao.findAllRules()).thenReturn(Lists.<Rule>newArrayList(rule));
        when(this.ruleDao.findRuleById(1)).thenReturn(rule);

        when(rule.applies(sale)).thenReturn(false);
        when(rule.getSalePromotions()).thenReturn(Sets.<SalePromotion>newHashSet(new SalePromotion(new PricingCondition("1", "A"))));

        // @When There is one rule with one promotion and the sale does not pass it
        Set<SalePromotion> salePromotions = this.ruleSalePromotionComputer.compute(sale);

        // @Then no promotion is returned
        assertThat(salePromotions).isEmpty();
    }

    @Test
    public void testAfterPropertiesSetCreatesACache_WhenInitializing() throws Exception {
        // @When initializing the cache
        this.ruleSalePromotionComputer.initialize();

        // @Then the ruleSalePromotionComputer cache is created
        assertThat(this.ruleSalePromotionComputer.getRuleCache()).isNotNull();
    }

    @Test
    public void testInitializeLoadsAllRulesIds_WhenInitializing() throws Exception {
        // @Given a rule in the repository
        Rule rule = new Rule();
        int ruleId = 1;
        field("id").ofType(Integer.class).in(rule).set(ruleId);
        rule.setEnabled(true);
        when(this.ruleDao.findAllRules()).thenReturn(Lists.<Rule>newArrayList(rule));
        when(this.ruleDao.findRuleById(rule.getId())).thenReturn(rule);

        // @When initializing the cache
        this.ruleSalePromotionComputer.initialize();

        // @Then the ruleSalePromotionComputer cache is created
        List allRulesIds = field("allRulesIds").ofType(List.class).in(this.ruleSalePromotionComputer).get();
        assertThat(allRulesIds).containsExactly(ruleId);
    }

    @Test
    public void testInitializeCreatesCache_WhenInitializing() throws Exception {
        // @Given a rule in the repository
        Rule rule = new Rule();
        int ruleId = 1;
        field("id").ofType(Integer.class).in(rule).set(ruleId);
        rule.setEnabled(true);
        when(this.ruleDao.findAllRules()).thenReturn(Lists.<Rule>newArrayList(rule));
        when(this.ruleDao.findRuleById(rule.getId())).thenReturn(rule);

        // @When initializing the cache
        this.ruleSalePromotionComputer.initialize();

        // @Then the ruleSalePromotionComputer cache is created
        assertThat(this.ruleSalePromotionComputer.getRuleCache()).isNotNull();
    }
}
