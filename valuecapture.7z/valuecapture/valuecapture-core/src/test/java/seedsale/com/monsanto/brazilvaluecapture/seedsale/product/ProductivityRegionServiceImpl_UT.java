package com.monsanto.brazilvaluecapture.seedsale.product;

import com.monsanto.brazilvaluecapture.core.foundation.service.BusinessException;
import com.monsanto.brazilvaluecapture.seedsale.harvest.HarvestTestData;
import com.monsanto.brazilvaluecapture.seedsale.harvest.model.bean.Plantability;
import com.monsanto.brazilvaluecapture.seedsale.product.model.bean.*;
import com.monsanto.brazilvaluecapture.seedsale.product.model.dao.ProductivityByRegionDAO;
import com.monsanto.brazilvaluecapture.seedsale.product.service.impl.ProductivityByRegionServiceImpl;
import org.junit.Assert;
import org.junit.Test;

import java.util.List;

import static org.mockito.Matchers.anyObject;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/**
 * Created by IntelliJ IDEA.
 * User: MEFAZZ
 * Date: 9/9/13
 * Time: 4:15 PM
 * To change this template use File | Settings | File Templates.
 */
public class ProductivityRegionServiceImpl_UT {

    @Test
    public void testSelectByAllFilter() throws BusinessException {

        ProductivityByRegion productivityByRegion = ProductivityRegionTestData.createFullProductivityRegion();

        List<ProductivityByRegion> productivities = ProductivityRegionTestData.createSomeProductivityRegions();

        ProductivityDTO pDto = ProductivityRegionTestData.createProductivityDTO(HarvestTestData.createABrazilianHarvest(), productivityByRegion.getPlantability(),
                productivityByRegion.getRegion(), DefaultProductivity.NOT);

        ProductivityByRegionDAO dao = mock(ProductivityByRegionDAO.class);

        ProductivityByRegionServiceImpl productivityService = new ProductivityByRegionServiceImpl();

        when(dao.selectByFilter((ProductivityDTO) anyObject())).thenReturn(productivities);

        productivityService.setProductivityByRegionDAO(dao);

        Assert.assertNotNull(productivityService.getProductivityByRegionDAO());

        List<ProductivityByRegion> productivitiesBase = productivityService.selectByFilter(pDto);

        Assert.assertNotNull(productivitiesBase);

    }


    @Test
    public void testSelectRegionProductivit() throws BusinessException {

        ProductivityByRegion productivityByRegion = ProductivityRegionTestData.createFullProductivityRegion();

        List<ProductivityByRegion> productivities = ProductivityRegionTestData.createSomeProductivityRegions();

        ProductivityByRegionDAO dao = mock(ProductivityByRegionDAO.class);

        ProductivityByRegionServiceImpl productivityService = new ProductivityByRegionServiceImpl();

        when(dao.selectByFilter((ProductivityDTO) anyObject())).thenReturn(productivities);

        productivityService.setProductivityByRegionDAO(dao);

        Assert.assertNotNull(productivityService.getProductivityByRegionDAO());

        List<ProductivityByRegion> productivitiesBase = productivityService.getFromRegionProductivity(RegionProductivityTestData.createRegionProductivity());

        Assert.assertNotNull(productivitiesBase);

    }

    @Test
    public void test_getFromProductRegionAndPlantability(){
        //@Given
        ProductivityByRegionDAO dao = mock(ProductivityByRegionDAO.class);
        Region region = new Region();
        Plantability plantability = new Plantability();


        //@When
        ProductivityByRegionServiceImpl service = new ProductivityByRegionServiceImpl();
        service.setProductivityByRegionDAO(dao);
        service.getFromRegionAndPlantability(region, plantability);

        //@should
        verify(dao).getFromRegionAndPlantability(region, plantability);
}

}
