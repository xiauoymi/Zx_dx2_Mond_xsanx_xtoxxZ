package com.monsanto.brazilvaluecapture.utils;

import org.apache.commons.collections.iterators.IteratorEnumeration;

import java.util.Enumeration;
import java.util.Map;
import java.util.ResourceBundle;

/**
 * User: ppera, asequ
 * Date: 19/07/13
 * Time: 11:17
 */
public class ResourceBundleStub extends ResourceBundle {

    private Map<String, String> properties;

    public ResourceBundleStub(Map<String, String> properties) {
        this.properties = properties;
    }


    @Override
    protected Object handleGetObject(String key) {
        return this.properties.get(key);
    }

    @Override
    public Enumeration<String> getKeys() {
        return new IteratorEnumeration(this.properties.keySet().iterator());
    }
}
