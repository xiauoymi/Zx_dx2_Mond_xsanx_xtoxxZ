package com.monsanto.brazilvaluecapture.seedsale.product;

import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.SessionFactory;
import org.hibernate.classic.Session;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.monsanto.brazilvaluecapture.core.base.CountryTestData;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Company;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Country;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Crop;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Technology;
import com.monsanto.brazilvaluecapture.core.foundation.model.bean.StatusEnum;
import com.monsanto.brazilvaluecapture.core.grower.CreateTestData;
import com.monsanto.brazilvaluecapture.seedsale.harvest.model.bean.Harvest;
import com.monsanto.brazilvaluecapture.seedsale.product.model.bean.Brand;
import com.monsanto.brazilvaluecapture.seedsale.product.model.bean.DefaultProductivity;
import com.monsanto.brazilvaluecapture.seedsale.product.model.bean.Product;
import com.monsanto.brazilvaluecapture.seedsale.product.model.bean.Productivity;
import com.monsanto.brazilvaluecapture.seedsale.product.model.bean.ProductivityDTO;
import com.monsanto.brazilvaluecapture.seedsale.product.model.bean.ProductivitySortComparator;
import com.monsanto.brazilvaluecapture.seedsale.product.model.bean.ProductivityValue;
import com.monsanto.brazilvaluecapture.seedsale.product.model.dao.ProductivityDAO;
import com.monsanto.brazilvaluecapture.seedsale.product.model.dao.impl.ProductivityDAOImpl;
import com.monsanto.brazilvaluecapture.seedsale.product.service.ProductivityAlreadyProductInProductvityValues;


public class Productivity_UT extends CreateTestData{

	ProductivityDAO productivityDAO;
	Session mockSession;
	SessionFactory mockSessionFactory;

	@Before
	public void setup(){
		mockSessionFactory = mock(SessionFactory.class);
		mockSession = mock(Session.class);
		when(mockSessionFactory.getCurrentSession()).thenReturn(mockSession);

		productivityDAO = new ProductivityDAOImpl(mockSessionFactory);
	}

	@Test
	public void createProductivityTest() {
		Productivity productivity = ProductivityTestData.createFullProductivity();
		productivity.setId(1L);

		Assert.assertFalse(productivity.getProductivityValues().isEmpty());
		
		ProductivityValue productivityValue =  new ProductivityValue(); 
		
		for (ProductivityValue pV : productivity.getProductivityValues()) {
		
			productivityValue = pV;
			
		}
		
		productivityValue.setId(1L);
		Assert.assertNotNull(productivityValue.getProductivityMax());
		Assert.assertNotNull(productivityValue.getProductivityMin());
		Assert.assertNotNull(productivityValue.getProductivity());
		Long averageCreated = (long) (Math.round((productivityValue.getProductivityMax().doubleValue() + productivityValue.getProductivityMin().doubleValue())/2));
		Assert.assertEquals(productivityValue.getAverage(), new BigDecimal(averageCreated) );
		
		Assert.assertFalse(productivity.getProductivityValuesComplete(productivity.getPlantability().getHarvest().getCrop()).isEmpty());
		
		//Does not have id, value is null
		Assert.assertNotNull(productivityValue.getProductivityMax());
		Assert.assertNotNull(productivityValue.getProductivityMin());
		
		Assert.assertNotNull(productivity.getId());
		Assert.assertNotNull(productivity.getDefaultProductivity());
		Assert.assertNotNull(productivity.getPlantability());
		Assert.assertNotNull(productivity.getState());
	}

	@Test
	public void selectByFilterTest(){

		when(mockSessionFactory.getCurrentSession()).thenReturn(mockSession);

		Productivity productivity = ProductivityTestData.createFullProductivity();

		doNothing().when(mockSession).saveOrUpdate(productivity);

		try {
			productivityDAO.save(productivity);
		} catch (ProductivityAlreadyProductInProductvityValues e) {
			Assert.fail();
		}

		Assert.assertNotNull(productivity);

		Criteria mockCriteria = mock(Criteria.class);

		when(mockSessionFactory.getCurrentSession()).thenReturn(mockSession);
		when(mockSession.createCriteria(Productivity.class, "productivity")).thenReturn(mockCriteria);

		List<Productivity> productivities = createSomeProductivities(DefaultProductivity.YES);

		when(mockCriteria.list()).thenReturn(productivities);

		ProductivityDTO pDto = ProductivityTestData.createProductivityDTO(productivity.getPlantability().getHarvest(), productivity.getState(),
				productivity.getPlantability(), productivity.getDefaultProductivity());

		List<Productivity> list = productivityDAO.selectByFilter(pDto);

		Assert.assertEquals(productivities, list);
		
	}

	@Test
	public void sortProduct(){
		
		List<ProductivityValue> productivityValues = new ArrayList<ProductivityValue>();
		List<Product> products = new ArrayList<Product>();
		Harvest harvest = createBasicHarvest(StatusEnum.ACTIVE);
		
		Technology techA = new Technology("TechA", null);
		Technology techB = new Technology("TechB", null);
		Technology techC = new Technology("TechC", null);
		
		Brand brandA = new Brand("BrandA", null, StatusEnum.ACTIVE);
		Brand brandB = new Brand("BrandB", null, StatusEnum.ACTIVE);
		Brand brandC = new Brand("BrandC", null, StatusEnum.ACTIVE);
		
		Country brazil = CountryTestData.createBrazil();
		Company monsantoBr = new Company("MONSANTO BRASIL");
		monsantoBr.setCountry(brazil);
		brazil.addCompany(monsantoBr);
		
		
		Crop crop = new Crop("cropDesc", monsantoBr, brazil);
		
		Product product1 = ProductTestData.createProduct(brandA, crop, techA, StatusEnum.ACTIVE, monsantoBr);
		product1.setDescription("productGeneratingQuota1");
		products.add(product1);
		Product product2 = ProductTestData.createProduct(brandA, crop, techB, StatusEnum.ACTIVE, monsantoBr);
		product2.setDescription("product2");
		products.add(product2);
		Product product3 = ProductTestData.createProduct(brandB, crop, techA, StatusEnum.ACTIVE, monsantoBr);
		product3.setDescription("product3");
		products.add(product3);
		Product product4 = ProductTestData.createProduct(brandB, crop, techC, StatusEnum.ACTIVE, monsantoBr);
		product4.setDescription("product4");	
		products.add(product4);
		Product product5 = ProductTestData.createProduct(brandC, crop, techB, StatusEnum.ACTIVE, monsantoBr);
		product5.setDescription("product5");
		products.add(product5);
		Product product6 = ProductTestData.createProduct(brandC, crop, techA, StatusEnum.ACTIVE, monsantoBr);
		product6.setDescription("productGeneratingQuota1");
		products.add(product6);
		
		Productivity productivity = ProductivityTestData.createProductivityWithoutProductivityValue(harvest, DefaultProductivity.NOT);
		
		for (Product product : products) {
			ProductivityValue productivityValue = new ProductivityValue();
			productivityValue.setProduct(product);
			productivityValue.setProductivity(productivity);
			productivityValues.add(productivityValue);
		}
		
		
		Collections.sort(productivityValues, new ProductivitySortComparator());
		
		Assert.assertEquals(product1, productivityValues.get(0).getProduct());
		Assert.assertEquals(product3, productivityValues.get(1).getProduct());
		Assert.assertEquals(product6, productivityValues.get(2).getProduct());
		Assert.assertEquals(product2, productivityValues.get(3).getProduct());
		Assert.assertEquals(product5, productivityValues.get(4).getProduct());
		Assert.assertEquals(product4, productivityValues.get(5).getProduct());
		
	}

	
}
