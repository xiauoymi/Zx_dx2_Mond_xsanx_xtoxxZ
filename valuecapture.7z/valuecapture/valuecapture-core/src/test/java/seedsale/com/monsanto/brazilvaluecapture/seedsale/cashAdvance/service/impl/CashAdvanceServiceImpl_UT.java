package com.monsanto.brazilvaluecapture.seedsale.cashAdvance.service.impl;

import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import com.monsanto.brazilvaluecapture.core.base.model.bean.*;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Customer;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Technology;
import com.monsanto.brazilvaluecapture.core.foundation.model.bean.StatusEnum;
import com.monsanto.brazilvaluecapture.core.foundation.service.BusinessException;
import com.monsanto.brazilvaluecapture.core.foundation.validation.ValidationException;
import com.monsanto.brazilvaluecapture.core.grower.model.bean.Grower;
import com.monsanto.brazilvaluecapture.seedsale.cashAdvance.model.bean.CashAdvanceBalanceByReferenceDate;
import com.monsanto.brazilvaluecapture.seedsale.cashAdvance.model.bean.CashAdvanceSourceOperationType;
import com.monsanto.brazilvaluecapture.seedsale.cashAdvance.model.bean.CashAdvanceTransaction;
import com.monsanto.brazilvaluecapture.seedsale.cashAdvance.model.dao.CashAdvanceDAO;
import com.monsanto.brazilvaluecapture.seedsale.cashAdvance.validation.impl.CashAdvanceCreditValidator;
import com.monsanto.brazilvaluecapture.seedsale.cashAdvance.validation.impl.CashAdvanceDebitValidator;
import com.monsanto.brazilvaluecapture.seedsale.harvest.model.bean.Harvest;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.Sale;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.SaleItem;
import com.monsanto.brazilvaluecapture.seedsale.sale.service.SaleConstraintViolationException;
import com.monsanto.brazilvaluecapture.seedsale.template.model.bean.DueDatePrice;
import com.monsanto.brazilvaluecapture.seedsale.template.model.bean.DueDatePriceItem;
import com.monsanto.brazilvaluecapture.seedsale.template.model.bean.Price;
import com.monsanto.brazilvaluecapture.seedsale.template.model.bean.SaleTemplate;
import com.monsanto.brazilvaluecapture.seedsale.template.model.dao.SaleTemplateDAO;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Set;

import static org.fest.assertions.Assertions.assertThat;
import static org.fest.assertions.Fail.fail;
import static org.fest.reflect.core.Reflection.field;
import static org.mockito.Mockito.*;

public class CashAdvanceServiceImpl_UT {

    private CashAdvanceDAO cashAdvanceDAO;
    private SaleTemplateDAO saleTemplateDAO;
    private CashAdvanceServiceImpl cashAdvanceService;
    private CashAdvanceDebitValidator cashAdvanceDebitValidator;
    private CashAdvanceCreditValidator cashAdvanceCreditValidator;
    private Company company;
    private OperationalYear operationalYear;
    private Country country;
    private Crop crop;
    private Harvest harvest;
    private DueDatePriceItem referenceDate;

    @Before
    public void setUp() {
        company = new Company("MONSANTO");
        operationalYear = new OperationalYear("14/15");
        country = new Country("CO", "CO");
        crop = new Crop("SOJA", company, country);
        harvest = new Harvest(company, "HARVEST", operationalYear, crop, StatusEnum.ACTIVE);
        referenceDate = new DueDatePriceItem("REF");

        cashAdvanceDAO = mock(CashAdvanceDAO.class);
        cashAdvanceDebitValidator = mock(CashAdvanceDebitValidator.class);
        cashAdvanceCreditValidator = mock(CashAdvanceCreditValidator.class);
        saleTemplateDAO = mock(SaleTemplateDAO.class);
        cashAdvanceService = spy(new CashAdvanceServiceImpl(cashAdvanceDAO, saleTemplateDAO, cashAdvanceCreditValidator));
        field("cashAdvanceDebitValidator").ofType(CashAdvanceDebitValidator.class).in(cashAdvanceService).set(cashAdvanceDebitValidator);
    }

    @Test
    public void testDebitCashAdvanceSavesCashAdvanceWithNegativeAmount_WhenACashAdvanceDebitIsPerformed() throws ValidationException {
        Customer customer = new Customer();
        DueDatePriceItem referenceDate = new DueDatePriceItem();
        BigDecimal amount = BigDecimal.TEN;
        CashAdvanceTransaction cashAdvanceTransaction = new CashAdvanceTransaction(customer, customer, null, referenceDate, amount, CashAdvanceSourceOperationType.FORM);

        cashAdvanceService.saveDebitCashAdvance(cashAdvanceTransaction);

        ArgumentCaptor<CashAdvanceTransaction> cashAdvanceArgumentCaptor = ArgumentCaptor.forClass(CashAdvanceTransaction.class);
        verify(cashAdvanceDAO).saveCashAdvance(cashAdvanceArgumentCaptor.capture());
        final CashAdvanceTransaction storedCashAdvanceTransaction = cashAdvanceArgumentCaptor.getValue();
        final BigDecimal negativeAmount = BigDecimal.TEN.negate();
        assertThat(storedCashAdvanceTransaction.getAmount()).isEqualTo(negativeAmount);
    }

    @Test
    public void testDebitCashAdvanceDoNotSavesCashAdvanceTransaction_WhenACashAdvanceTransactionHasAmountZero() throws ValidationException {
        Customer customer = new Customer();
        DueDatePriceItem referenceDate = new DueDatePriceItem();
        BigDecimal amount = BigDecimal.ZERO;
        CashAdvanceTransaction cashAdvanceTransaction = new CashAdvanceTransaction(customer, customer, null, referenceDate, amount, CashAdvanceSourceOperationType.FORM);

        cashAdvanceService.saveDebitCashAdvance(cashAdvanceTransaction);

        verify(cashAdvanceDAO, never()).saveCashAdvance(any(CashAdvanceTransaction.class));
    }

    @Test
    public void testCreditCashAdvanceDoNotSavesCashAdvanceTransaction_WhenACashAdvanceTransactionHasAmountZero() throws ValidationException {
        Customer customer = new Customer();
        DueDatePriceItem referenceDate = new DueDatePriceItem();
        BigDecimal amount = BigDecimal.ZERO;
        CashAdvanceTransaction cashAdvanceTransaction = new CashAdvanceTransaction(customer, customer, null, referenceDate, amount, CashAdvanceSourceOperationType.FORM);

        cashAdvanceService.saveCreditCashAdvance(cashAdvanceTransaction);

        verify(cashAdvanceDAO, never()).saveCashAdvance(any(CashAdvanceTransaction.class));
    }

    @Test
    public void testDebitCashAdvanceInvokesCashAdvanceDebitValidator_WhenDebitingCashAdvance() throws ValidationException {
        Customer customer = new Customer();
        DueDatePriceItem referenceDate = new DueDatePriceItem();
        BigDecimal amount = BigDecimal.ZERO;
        CashAdvanceTransaction cashAdvanceTransaction = new CashAdvanceTransaction(customer, customer, null, referenceDate, amount, CashAdvanceSourceOperationType.FORM);

        cashAdvanceService.saveDebitCashAdvance(cashAdvanceTransaction);

        verify(cashAdvanceDebitValidator).validate(cashAdvanceTransaction);
    }

    @Test
    public void testCreditCashAdvanceInvokesCashAdvanceCreditValidator_WhenCreditingCashAdvance() throws ValidationException {
        Customer customer = new Customer();
        DueDatePriceItem referenceDate = new DueDatePriceItem();
        BigDecimal amount = BigDecimal.ZERO;
        CashAdvanceTransaction cashAdvanceTransaction = new CashAdvanceTransaction(customer, customer, null, referenceDate, amount, CashAdvanceSourceOperationType.FORM);

        cashAdvanceService.saveCreditCashAdvance(cashAdvanceTransaction);

        verify(cashAdvanceCreditValidator).validate(cashAdvanceTransaction);
    }

    @Test
    public void testGetBalanceByReferenceDateInvokesCashAdvanceDAOGetBalanceByReferenceDate_WhenRetrievingBalanceByReferenceDate() {
        Price price = new Price();
        final CashAdvanceBalanceByReferenceDate cashAdvanceBalanceByReferenceDate = new CashAdvanceBalanceByReferenceDate(null, null);
        List<CashAdvanceBalanceByReferenceDate> balanceLists = Lists.newArrayList(cashAdvanceBalanceByReferenceDate);
        when(cashAdvanceDAO.getBalanceByReferenceDate(price)).thenReturn(balanceLists);

        List<CashAdvanceBalanceByReferenceDate> balanceByReferenceDate = cashAdvanceService.getBalanceByReferenceDate(price);

        verify(cashAdvanceDAO).getBalanceByReferenceDate(price);
        assertThat(balanceByReferenceDate).contains(cashAdvanceBalanceByReferenceDate);
    }

    @Test
    public void testGetReferenceDatesBySaleTemplateAndTechnologyInvokesSaleTemplateDAO_WhenRetrievingReferenceDates() {
        Technology technology = new Technology();
        SaleTemplate saleTemplate = new SaleTemplate();
        Price price = new Price();
        price.setTechnology(technology);
        DueDatePrice dueDatePrice = new DueDatePrice();
        DueDatePriceItem ddpi = new DueDatePriceItem("SOME REFERENCE");
        dueDatePrice.setDueDatePriceItems(Lists.newArrayList(ddpi));
        price.setDueDatePrice(dueDatePrice);
        saleTemplate.setPrices(Sets.newHashSet(price));


        List<DueDatePriceItem> referenceDates = cashAdvanceService.getReferenceDatesBySaleTemplateAndTechnology(saleTemplate, technology);

        verify(saleTemplateDAO).getReferenceDatesBySaleTemplateAndTechnology(saleTemplate, technology);
    }

    @Test
    public void testGetReferenceDatesBySaleTemplateAndTechnologyReturnsSaleTemplateDAOReturnValue_WhenRetrievingReferenceDates() {
        Technology technology = new Technology();
        SaleTemplate saleTemplate = new SaleTemplate();
        Price price = new Price();
        price.setTechnology(technology);
        DueDatePrice dueDatePrice = new DueDatePrice();
        DueDatePriceItem ddpi = new DueDatePriceItem("SOME REFERENCE");
        final ArrayList<DueDatePriceItem> expectedDueDateItemList = Lists.newArrayList(ddpi);
        dueDatePrice.setDueDatePriceItems(expectedDueDateItemList);
        price.setDueDatePrice(dueDatePrice);
        saleTemplate.setPrices(Sets.newHashSet(price));
        when(saleTemplateDAO.getReferenceDatesBySaleTemplateAndTechnology(saleTemplate, technology)).thenReturn(expectedDueDateItemList);


        List<DueDatePriceItem> referenceDates = cashAdvanceService.getReferenceDatesBySaleTemplateAndTechnology(saleTemplate, technology);

        assertThat(referenceDates).isSameAs(expectedDueDateItemList);
    }

    @Test
    public void testRevertCashAdvanceDebitFromSaleCreditsConsumedCashAdvanceFromSale_WhenRevertingCashAdvanceFromSale() throws ValidationException, BusinessException {
        Customer multiplier = getCPFCustomer();
        Customer matrix = new Customer();
        Sale sale = createSale(multiplier, matrix, BigDecimal.TEN);

        cashAdvanceService.revertCashAdvanceDebitFromSale(sale);

        verify(cashAdvanceService).saveCreditCashAdvance(any(CashAdvanceTransaction.class));
    }

    private Customer getCNPJCustomer() {
        DocumentType documentType = new DocumentType("CNPJ", null, "MASK");
        Document document = new Document(documentType, "000000");
        return new Customer("NAME", document, null, "CODE");
    }

    private Customer getCPFCustomer() {
        DocumentType documentType = new DocumentType("CPF", null, "MASK");
        Document document = new Document(documentType, "000000");
        return new Customer("CUSTOMER", document, null, "CODE");
    }

    private Sale createSale(Customer multiplier, Customer matrix, BigDecimal prepaidRoyaltyValueQuantity) {
        Grower grower = new Grower();
        Sale sale = new Sale(multiplier, grower);

        SaleItem saleItem = new SaleItem();
        saleItem.setCustomerParent(matrix);
        SaleTemplate saleTemplate = new SaleTemplate();
        saleTemplate.setHarvest(harvest);
        saleItem.setSaleTemplate(saleTemplate);
        saleItem.setDueDatePriceItem(referenceDate);
        saleItem.setPrepaidRoyaltyValueQuantity(prepaidRoyaltyValueQuantity);

        final Set<SaleItem> saleItems = Sets.newHashSet(saleItem);
        sale.setItems(saleItems);
        return sale;
    }

    @Test
    public void testRevertCashAdvanceDebitFromSaleCreatesCashAdvanceTransactionWithSaleMultiplier_WhenSalePartnerDocumentTypeIsCNPJ()
            throws ValidationException, BusinessException {
        Customer multiplier = getCNPJCustomer();
        Customer matrix = new Customer();
        Sale sale = createSale(multiplier, matrix, BigDecimal.TEN);

        cashAdvanceService.revertCashAdvanceDebitFromSale(sale);

        ArgumentCaptor<CashAdvanceTransaction> cashAdvanceTransactionArgumentCaptor = ArgumentCaptor.forClass(CashAdvanceTransaction.class);
        verify(cashAdvanceService).saveCreditCashAdvance(cashAdvanceTransactionArgumentCaptor.capture());
        final CashAdvanceTransaction cashAdvanceTransaction = cashAdvanceTransactionArgumentCaptor.getValue();
        assertThat(cashAdvanceTransaction.getPartner()).isSameAs(multiplier);
    }

    @Test
    public void testRevertCashAdvanceDebitFromSaleCreatesCashAdvanceTransactionWithSaleHeadOffice_WhenSalePartnerDocumentTypeIsCPF()
            throws ValidationException, BusinessException {
        Customer multiplier = getCPFCustomer();
        Customer matrix = new Customer();
        Sale sale = createSale(multiplier, matrix, BigDecimal.TEN);

        cashAdvanceService.revertCashAdvanceDebitFromSale(sale);

        ArgumentCaptor<CashAdvanceTransaction> cashAdvanceTransactionArgumentCaptor = ArgumentCaptor.forClass(CashAdvanceTransaction.class);
        verify(cashAdvanceService).saveCreditCashAdvance(cashAdvanceTransactionArgumentCaptor.capture());
        final CashAdvanceTransaction cashAdvanceTransaction = cashAdvanceTransactionArgumentCaptor.getValue();
        assertThat(cashAdvanceTransaction.getPartner()).isSameAs(multiplier);
    }

    @Test
    public void testRevertCashAdvanceDebitFromSaleCreatesCashAdvanceTransactionWithSaleOperationalYear_WhenRevertingCashAdvanceFromSale()
            throws ValidationException, BusinessException {
        Customer multiplier = getCPFCustomer();
        Customer matrix = new Customer();
        Sale sale = createSale(multiplier, matrix, BigDecimal.TEN);

        cashAdvanceService.revertCashAdvanceDebitFromSale(sale);

        ArgumentCaptor<CashAdvanceTransaction> cashAdvanceTransactionArgumentCaptor = ArgumentCaptor.forClass(CashAdvanceTransaction.class);
        verify(cashAdvanceService).saveCreditCashAdvance(cashAdvanceTransactionArgumentCaptor.capture());
        final CashAdvanceTransaction cashAdvanceTransaction = cashAdvanceTransactionArgumentCaptor.getValue();
        assertThat(cashAdvanceTransaction.getOperationalYear()).isSameAs(operationalYear);
    }


    @Test
    public void testRevertCashAdvanceDebitFromSaleCreatesCashAdvanceTransactionWithSaleItemReferenceDate_WhenRevertingCashAdvanceFromSale()
            throws ValidationException, BusinessException {
        Customer multiplier = getCPFCustomer();
        Customer matrix = new Customer();
        Sale sale = createSale(multiplier, matrix, BigDecimal.TEN);

        cashAdvanceService.revertCashAdvanceDebitFromSale(sale);

        ArgumentCaptor<CashAdvanceTransaction> cashAdvanceTransactionArgumentCaptor = ArgumentCaptor.forClass(CashAdvanceTransaction.class);
        verify(cashAdvanceService).saveCreditCashAdvance(cashAdvanceTransactionArgumentCaptor.capture());
        final CashAdvanceTransaction cashAdvanceTransaction = cashAdvanceTransactionArgumentCaptor.getValue();
        assertThat(cashAdvanceTransaction.getReferenceDate()).isSameAs(referenceDate);
    }


    @Test
    public void testRevertCashAdvanceDebitFromSaleCreatesCashAdvanceTransactionWithSaleItemAmount_WhenRevertingCashAdvanceFromSale()
            throws ValidationException, BusinessException {
        Customer multiplier = getCPFCustomer();
        Customer matrix = new Customer();
        Sale sale = createSale(multiplier, matrix, BigDecimal.TEN);

        cashAdvanceService.revertCashAdvanceDebitFromSale(sale);

        ArgumentCaptor<CashAdvanceTransaction> cashAdvanceTransactionArgumentCaptor = ArgumentCaptor.forClass(CashAdvanceTransaction.class);
        verify(cashAdvanceService).saveCreditCashAdvance(cashAdvanceTransactionArgumentCaptor.capture());
        final CashAdvanceTransaction cashAdvanceTransaction = cashAdvanceTransactionArgumentCaptor.getValue();
        assertThat(cashAdvanceTransaction.getAmount()).isEqualTo(BigDecimal.TEN);
    }

    @Test
    public void testRevertCashAdvanceDebitFromSaleCreatesCashAdvanceTransactionWithOperationTypeCANCELLATION_WhenRevertingCashAdvanceFromSale()
            throws ValidationException, BusinessException {
        Customer multiplier = getCPFCustomer();
        Customer matrix = new Customer();
        Sale sale = createSale(multiplier, matrix, BigDecimal.TEN);

        cashAdvanceService.revertCashAdvanceDebitFromSale(sale);

        ArgumentCaptor<CashAdvanceTransaction> cashAdvanceTransactionArgumentCaptor = ArgumentCaptor.forClass(CashAdvanceTransaction.class);
        verify(cashAdvanceService).saveCreditCashAdvance(cashAdvanceTransactionArgumentCaptor.capture());
        final CashAdvanceTransaction cashAdvanceTransaction = cashAdvanceTransactionArgumentCaptor.getValue();
        assertThat(cashAdvanceTransaction.getSourceOperationType()).isEqualTo(CashAdvanceSourceOperationType.SALE_CANCELLATION);
    }

    @Test
    public void testRevertCashAdvanceDebitFromSaleThrowsBusinessException_WhenInvalidCashAdvanceIsCreated() throws ValidationException {
        Customer multiplier = getCPFCustomer();
        Customer matrix = new Customer();
        final String expectedErrorMessage = "Expected Error Message";
        doThrow(new ValidationException(expectedErrorMessage)).when(cashAdvanceCreditValidator).validate(any(CashAdvanceTransaction.class));
        Sale sale = createSale(multiplier, matrix, BigDecimal.TEN);

        try {
            cashAdvanceService.revertCashAdvanceDebitFromSale(sale);
            fail("Should throw CashAdvanceConsumptionReversalError");
        } catch (CashAdvanceConsumptionReversalError e) {
            assertThat(e).hasMessage(expectedErrorMessage);
            assertThat(e.getCause()).isInstanceOf(ValidationException.class);
        }
    }

    @Test
    public void testGetAllAvailableBalancesForPrice() {
        Price price = new Price();
        Customer partner = getCNPJCustomer();
        Customer headOffice = new Customer();

        List<CashAdvanceBalanceByReferenceDate> advances = cashAdvanceService.getAllAvailableBalancesForPrice(price, partner, headOffice, operationalYear);

        verify(cashAdvanceDAO).getAllAvailableBalancesForPrice(price, partner, headOffice, operationalYear);
    }

    @Test
    public void testGetAvailableBalanceForReferenceDate() {
        Customer partner = getCNPJCustomer();
        Customer headOffice = new Customer();

        CashAdvanceBalanceByReferenceDate advance = cashAdvanceService.getAvailableBalanceForReferenceDate(referenceDate, partner, headOffice, operationalYear);

        verify(cashAdvanceDAO).getAvailableBalanceForReferenceDate(referenceDate, partner, headOffice, operationalYear);
    }

    @Test
    public void testCreateCashAdvanceDebitFromSaleInvokesSaveDebitTransaction_WhenDebitingCashAdvanceDuringSaleRegistration() throws ValidationException, SaleConstraintViolationException {
        Customer multiplier = getCPFCustomer();
        Customer matrix = new Customer();
        Sale sale = createSale(multiplier, matrix, BigDecimal.TEN);

        cashAdvanceService.createCashAdvanceDebitFromSale(sale);

        verify(cashAdvanceService).saveDebitCashAdvance(any(CashAdvanceTransaction.class));
    }

    @Test
    public void testCreateCashAdvanceDebitFromSaleCreatesCashAdvanceTransactionsWithTransactionTypeSALE_WhenDebitingCashAdvanceDuringSaleRegistration() throws ValidationException, SaleConstraintViolationException {
        Customer multiplier = getCPFCustomer();
        Customer matrix = new Customer();
        Sale sale = createSale(multiplier, matrix, BigDecimal.TEN);

        cashAdvanceService.createCashAdvanceDebitFromSale(sale);

        ArgumentCaptor<CashAdvanceTransaction> cashAdvanceTransactionArgumentCaptor = ArgumentCaptor.forClass(CashAdvanceTransaction.class);
        verify(cashAdvanceService).saveDebitCashAdvance(cashAdvanceTransactionArgumentCaptor.capture());
        final CashAdvanceTransaction cashAdvanceTransaction = cashAdvanceTransactionArgumentCaptor.getValue();
        assertThat(cashAdvanceTransaction.getSourceOperationType()).isEqualTo(CashAdvanceSourceOperationType.SALE);
    }

    @Test
    public void testCreateCashAdvanceDebitFromSaleCreatesCashAdvanceTransactionsWithSale_WhenDebitingCashAdvanceDuringSaleRegistration() throws ValidationException, SaleConstraintViolationException {
        Customer multiplier = getCPFCustomer();
        Customer matrix = new Customer();
        Sale sale = createSale(multiplier, matrix, BigDecimal.TEN);

        cashAdvanceService.createCashAdvanceDebitFromSale(sale);

        ArgumentCaptor<CashAdvanceTransaction> cashAdvanceTransactionArgumentCaptor = ArgumentCaptor.forClass(CashAdvanceTransaction.class);
        verify(cashAdvanceService).saveDebitCashAdvance(cashAdvanceTransactionArgumentCaptor.capture());
        final CashAdvanceTransaction cashAdvanceTransaction = cashAdvanceTransactionArgumentCaptor.getValue();
        assertThat(cashAdvanceTransaction.getSaleFrom()).isSameAs(sale);
    }

    @Test
    public void tesCreateCashAdvanceDebitFromSaleCreatesCashAdvanceTransactionWithSaleMultiplierAsCustomer_WhenSalePartnerDocumentTypeIsCNPJ()
            throws ValidationException, BusinessException {
        Customer multiplier = getCNPJCustomer();
        Customer matrix = new Customer();
        Sale sale = createSale(multiplier, matrix, BigDecimal.TEN);

        cashAdvanceService.createCashAdvanceDebitFromSale(sale);

        ArgumentCaptor<CashAdvanceTransaction> cashAdvanceTransactionArgumentCaptor = ArgumentCaptor.forClass(CashAdvanceTransaction.class);
        verify(cashAdvanceService).saveDebitCashAdvance(cashAdvanceTransactionArgumentCaptor.capture());
        final CashAdvanceTransaction cashAdvanceTransaction = cashAdvanceTransactionArgumentCaptor.getValue();
        assertThat(cashAdvanceTransaction.getPartner()).isSameAs(multiplier);
    }

    @Test
    public void tesCreateCashAdvanceDebitFromSaleCreatesCashAdvanceTransactionWithSaleMultiplierAsCustomer_WhenSalePartnerDocumentTypeIsCPF()
            throws ValidationException, BusinessException {
        Customer multiplier = getCPFCustomer();
        Customer matrix = new Customer();
        Sale sale = createSale(multiplier, matrix, BigDecimal.TEN);

        cashAdvanceService.createCashAdvanceDebitFromSale(sale);

        ArgumentCaptor<CashAdvanceTransaction> cashAdvanceTransactionArgumentCaptor = ArgumentCaptor.forClass(CashAdvanceTransaction.class);
        verify(cashAdvanceService).saveDebitCashAdvance(cashAdvanceTransactionArgumentCaptor.capture());
        final CashAdvanceTransaction cashAdvanceTransaction = cashAdvanceTransactionArgumentCaptor.getValue();
        assertThat(cashAdvanceTransaction.getPartner()).isSameAs(multiplier);
    }

    @Test
    public void testCreateCashAdvanceDebitFromSaleCreatesCashAdvanceTransactionWithSaleOperationalYear_WhenRevertingCashAdvanceFromSale()
            throws ValidationException, BusinessException {
        Customer multiplier = getCPFCustomer();
        Customer matrix = new Customer();
        Sale sale = createSale(multiplier, matrix, BigDecimal.TEN);

        cashAdvanceService.createCashAdvanceDebitFromSale(sale);

        ArgumentCaptor<CashAdvanceTransaction> cashAdvanceTransactionArgumentCaptor = ArgumentCaptor.forClass(CashAdvanceTransaction.class);
        verify(cashAdvanceService).saveDebitCashAdvance(cashAdvanceTransactionArgumentCaptor.capture());
        final CashAdvanceTransaction cashAdvanceTransaction = cashAdvanceTransactionArgumentCaptor.getValue();
        assertThat(cashAdvanceTransaction.getOperationalYear()).isSameAs(operationalYear);
    }


    @Test
    public void testCreateCashAdvanceDebitFromSaleCreatesCashAdvanceTransactionWithSaleItemReferenceDate_WhenRevertingCashAdvanceFromSale()
            throws ValidationException, BusinessException {
        Customer multiplier = getCPFCustomer();
        Customer matrix = new Customer();
        Sale sale = createSale(multiplier, matrix, BigDecimal.TEN);

        cashAdvanceService.createCashAdvanceDebitFromSale(sale);

        ArgumentCaptor<CashAdvanceTransaction> cashAdvanceTransactionArgumentCaptor = ArgumentCaptor.forClass(CashAdvanceTransaction.class);
        verify(cashAdvanceService).saveDebitCashAdvance(cashAdvanceTransactionArgumentCaptor.capture());
        final CashAdvanceTransaction cashAdvanceTransaction = cashAdvanceTransactionArgumentCaptor.getValue();
        assertThat(cashAdvanceTransaction.getReferenceDate()).isSameAs(referenceDate);
    }


    @Test
    public void testCreateCashAdvanceDebitFromSaleCreatesCashAdvanceTransactionWithSaleItemAmount_WhenRevertingCashAdvanceFromSale()
            throws ValidationException, BusinessException {
        Customer multiplier = getCPFCustomer();
        Customer matrix = new Customer();
        Sale sale = createSale(multiplier, matrix, BigDecimal.TEN);

        cashAdvanceService.createCashAdvanceDebitFromSale(sale);

        ArgumentCaptor<CashAdvanceTransaction> cashAdvanceTransactionArgumentCaptor = ArgumentCaptor.forClass(CashAdvanceTransaction.class);
        verify(cashAdvanceService).saveDebitCashAdvance(cashAdvanceTransactionArgumentCaptor.capture());
        final CashAdvanceTransaction cashAdvanceTransaction = cashAdvanceTransactionArgumentCaptor.getValue();
        assertThat(cashAdvanceTransaction.getAmount()).isEqualTo(BigDecimal.TEN.negate());
    }


    @Test
    public void testCreateCashAdvanceDebitFromSaleCreatesCashAdvanceTransactionWithSaleHeadOffice_WhenDebitingCashAdvanceFromSale()
            throws ValidationException, BusinessException {
        Customer multiplier = getCPFCustomer();
        Customer matrix = getCNPJCustomer();
        Sale sale = createSale(multiplier, matrix, BigDecimal.TEN);

        cashAdvanceService.createCashAdvanceDebitFromSale(sale);

        ArgumentCaptor<CashAdvanceTransaction> cashAdvanceTransactionArgumentCaptor = ArgumentCaptor.forClass(CashAdvanceTransaction.class);
        verify(cashAdvanceService).saveDebitCashAdvance(cashAdvanceTransactionArgumentCaptor.capture());
        final CashAdvanceTransaction cashAdvanceTransaction = cashAdvanceTransactionArgumentCaptor.getValue();
        assertThat(cashAdvanceTransaction.getHeadOffice()).isSameAs(matrix);
    }

    @Test
    public void testCreateCashAdvanceDebitFromSaleCreatesCashAdvanceTransactionWithPaymentDate_WhenDebitingCashAdvanceFromSale()
            throws ValidationException, BusinessException {
        Customer multiplier = getCPFCustomer();
        Customer matrix = getCNPJCustomer();
        Sale sale = createSale(multiplier, matrix, BigDecimal.TEN);

        cashAdvanceService.createCashAdvanceDebitFromSale(sale);

        ArgumentCaptor<CashAdvanceTransaction> cashAdvanceTransactionArgumentCaptor = ArgumentCaptor.forClass(CashAdvanceTransaction.class);
        verify(cashAdvanceService).saveDebitCashAdvance(cashAdvanceTransactionArgumentCaptor.capture());
        final CashAdvanceTransaction cashAdvanceTransaction = cashAdvanceTransactionArgumentCaptor.getValue();
        assertThat(cashAdvanceTransaction.getPaymentDate()).isNotNull().isInstanceOf(Date.class);
    }

    @Test
    public void testCreateCashAdvanceDebitFromSaleThrowsSaleConstraintViolationException_WhenCreatingTransactionFails() throws ValidationException {
        Customer multiplier = getCPFCustomer();
        Customer matrix = new Customer();
        Sale sale = createSale(multiplier, matrix, BigDecimal.TEN);
        final String expectedMessage = "extected expectedMessage";
        doThrow(new ValidationException(expectedMessage)).when(cashAdvanceDebitValidator).validate(any(CashAdvanceTransaction.class));

        try {
            cashAdvanceService.createCashAdvanceDebitFromSale(sale);
            fail("Should throw SaleConstraintViolationException");
        }catch (SaleConstraintViolationException e){
            assertThat(e).hasMessage(expectedMessage);
        }
    }

    @Test
    public void testCreateCashAdvanceDebitFromSaleWontSaveCashAdvanceTransaction_WhenCashAdvanceIsZero() throws ValidationException, SaleConstraintViolationException {
        Customer multiplier = getCPFCustomer();
        Customer matrix = new Customer();
        Sale sale = createSale(multiplier, matrix, BigDecimal.ZERO);

        cashAdvanceService.createCashAdvanceDebitFromSale(sale);

        verify(cashAdvanceService, never()).saveDebitCashAdvance(any(CashAdvanceTransaction.class));
    }

    @Test
    public void testCreateCashAdvanceDebitFromSaleWontSaveCashAdvanceTransaction_WhenCashAdvanceIsNull() throws ValidationException, SaleConstraintViolationException {
        Customer multiplier = getCPFCustomer();
        Customer matrix = new Customer();
        Sale sale = createSale(multiplier, matrix, null);

        cashAdvanceService.createCashAdvanceDebitFromSale(sale);

        verify(cashAdvanceService, never()).saveDebitCashAdvance(any(CashAdvanceTransaction.class));
    }

}