package com.monsanto.brazilvaluecapture.seedsale.sale.promotion.model;

import com.monsanto.brazilvaluecapture.core.customer.model.bean.Customer;
import com.monsanto.brazilvaluecapture.core.grower.model.bean.Grower;
import com.monsanto.brazilvaluecapture.seedsale.product.model.bean.Product;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.Sale;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.SaleItem;
import com.monsanto.brazilvaluecapture.seedsale.sale.promotion.model.bean.RuleCriteria;
import com.monsanto.brazilvaluecapture.seedsale.template.model.bean.SaleTemplate;
import org.junit.Test;

import static org.fest.assertions.Assertions.assertThat;

/**
 * User: ppera
 * Date: 4/25/13
 * Time: 4:41 PM
 */
public class RuleCriteria_UT {
    @Test
    public void testTestReturnsTrue_WhenScriptExecutionReturnsTrue() {
        // @Given a sale and a RuleCriteria that the sale passes
        Sale sale = new Sale(new Customer(), new Grower());
        RuleCriteria ruleCriteria = new RuleCriteria();
        ruleCriteria.setScript("true");

        // @When testing if the criteria applies
        boolean result = ruleCriteria.test(sale);

        // @Then it returns true
        assertThat(result).isTrue();
    }

    @Test
    public void testTestReturnsFalse_WhenScriptExecutionReturnsFalse() {
        // @Given a sale and a RuleCriteria that the sale passes
        Sale sale = new Sale(new Customer(), new Grower());
        RuleCriteria ruleCriteria = new RuleCriteria();
        ruleCriteria.setScript("false");

        // @When testing if the criteria applies
        boolean result = ruleCriteria.test(sale);

        // @Then it returns true
        assertThat(result).isFalse();
    }

    @Test
    public void testTestReturnsTrue_WhenScriptComparesSaleTemplateDescriptionToArgumentAndArgumentIsEqual() {
        // @Given a sale and a RuleCriteria that the sale passes
        Sale sale = new Sale(new Customer(), new Grower());
        SaleTemplate saleTemplate = new SaleTemplate();
        saleTemplate.setDescription("JohnyTemplate");// This does a toUpper inside the setter
        sale.addItem(new SaleItem(new Product(), saleTemplate, new Customer()));
        RuleCriteria ruleCriteria = new RuleCriteria();
        ruleCriteria.setArgumentValue("JOHNYTEMPLATE");
        ruleCriteria.setArgumentName("templateName");

        ruleCriteria.setScript("sale.items[0].saleTemplate.description == templateName");

        // @When testing if the criteria applies
        boolean result = ruleCriteria.test(sale);

        // @Then it returns true
        assertThat(result).isTrue();
    }

    @Test
    public void testTestReturnsFalse_WhenScriptComparesSaleTemplateDescriptionToArgumentAndArgumentIsNotEqual() {
        // @Given a sale and a RuleCriteria that the sale passes
        Sale sale = new Sale(new Customer(), new Grower());
        SaleTemplate saleTemplate = new SaleTemplate();
        saleTemplate.setDescription("JohnyTolengo");
        sale.addItem(new SaleItem(new Product(), saleTemplate, new Customer()));
        RuleCriteria ruleCriteria = new RuleCriteria();
        ruleCriteria.setArgumentValue("JohnyTemplate");
        ruleCriteria.setArgumentName("templateName");
        ruleCriteria.setScript("sale.items[0].saleTemplate.description == templateName");

        // @When testing if the criteria applies
        boolean result = ruleCriteria.test(sale);

        // @Then it returns true
        assertThat(result).isFalse();
    }

    @Test
    public void testTestReturnsasdasdFalse_WhenScriptComparesSaleTemplateDescriptionToArgumentAndArgumentIsNotEqual() {
        // @Given a sale and a RuleCriteria that the sale passes
        Sale sale = new Sale(new Customer(), new Grower());
        SaleTemplate saleTemplate = new SaleTemplate();
        saleTemplate.setSaleType(Sale.SaleTypeEnum.DIRECT_SALE);
        sale.addItem(new SaleItem(new Product(), saleTemplate, new Customer()));
        RuleCriteria ruleCriteria = new RuleCriteria();
        ruleCriteria.setArgumentValue("RETAILER_FIRST_YEAR");
        ruleCriteria.setArgumentName("templateName");
        ruleCriteria.setScript("sale.items[0].saleTemplate.saleType.toString() == templateName");

        // @When testing if the criteria applies
        boolean result = ruleCriteria.test(sale);

        // @Then it returns true
        assertThat(result).isFalse();
    }
}
