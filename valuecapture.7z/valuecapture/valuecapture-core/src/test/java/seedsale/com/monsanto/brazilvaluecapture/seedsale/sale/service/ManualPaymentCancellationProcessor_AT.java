package com.monsanto.brazilvaluecapture.seedsale.sale.service;

import com.monsanto.CountriesHolderInitializer;
import com.monsanto.brazilvaluecapture.core.account.model.bean.ManualCreditTransactionType;
import com.monsanto.brazilvaluecapture.core.account.service.impl.AccountService;
import com.monsanto.brazilvaluecapture.core.base.SystemTestFixture;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Company;
import com.monsanto.brazilvaluecapture.core.base.model.bean.State;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Customer;
import com.monsanto.brazilvaluecapture.core.foundation.service.BusinessException;
import com.monsanto.brazilvaluecapture.core.foundation.test.AbstractServiceIntegrationTests;
import com.monsanto.brazilvaluecapture.core.foundation.util.CalendarUtil;
import com.monsanto.brazilvaluecapture.core.grower.model.bean.Grower;
import com.monsanto.brazilvaluecapture.core.io.ProcessorConfig;
import com.monsanto.brazilvaluecapture.core.io.ProcessorConfig.ProcessorConfigProperties;
import com.monsanto.brazilvaluecapture.core.regionalization.CountriesHolder;
import com.monsanto.brazilvaluecapture.core.revenue.model.bean.ChargeConsolidateType;
import com.monsanto.brazilvaluecapture.core.revenue.model.bean.ChargeConsolidateTypeEnum;
import com.monsanto.brazilvaluecapture.core.user.AccessControlTestFixture;
import com.monsanto.brazilvaluecapture.core.user.model.bean.HierarchyLevel;
import com.monsanto.brazilvaluecapture.core.user.model.bean.UserContext;
import com.monsanto.brazilvaluecapture.core.user.model.bean.UserContract;
import com.monsanto.brazilvaluecapture.core.user.model.bean.UserDecorator;
import com.monsanto.brazilvaluecapture.core.user.service.ManualCreditConstraintException;
import com.monsanto.brazilvaluecapture.seedsale.billing.model.bean.BillingDTO;
import com.monsanto.brazilvaluecapture.seedsale.billing.model.bean.PaymentStatus;
import com.monsanto.brazilvaluecapture.seedsale.billing.model.dao.BillingFilter;
import com.monsanto.brazilvaluecapture.seedsale.sale.SaleTestFixture;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.ReleaseMatrix;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.ReleaseMatrixToBilling;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.Sale;
import com.monsanto.brazilvaluecapture.seedsale.sale.service.parser.cancellation.ManualPaymentCancellationProcessor;
import com.monsanto.brazilvaluecapture.seedsale.sale.service.parser.cancellation.SaleCancelationCsvImportedFile;
import junit.framework.Assert;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.math.BigDecimal;
import java.util.*;

public class ManualPaymentCancellationProcessor_AT extends AbstractServiceIntegrationTests {
    private static final Logger LOG = LogManager.getLogger(ManualPaymentCancellationProcessor_AT.class);
    
    @Autowired
    private SaleService saleService;
    
    
    private AccessControlTestFixture accessControlIntent;

    @Autowired
    private AccountService accountService;
    private ProcessorConfig processorConfig;
    
    @Autowired
    private ManualPaymentCancellationProcessor processor;
    
	private Locale localeBR = new Locale("pt", "BR");
	private ResourceBundle resourceBundle = ResourceBundle.getBundle("bundle/bundle");

    private SaleBuilder builder;

    @Autowired
    private CountriesHolder countriesHolder;
    
    @Before
    public void initClass() throws BusinessException {
        CountriesHolderInitializer.initialize(countriesHolder);
        systemTestFixture = new SystemTestFixture(this);
        accessControlTestFixture = new AccessControlTestFixture(systemTestFixture);
        accessControlIntent = new AccessControlTestFixture(this, systemTestFixture);
        saleTestFixture = new SaleTestFixture(this, systemTestFixture);
//        saleItemFactory = SaleItemFactory.getInstance(systemTestFixture.matoGrossoDoSul, saleTestFixture.plantabilitiesSelector);
        
        UserDecorator loggedSuperUser = accessControlIntent.superUser;
        loggedSuperUser.setContextCrop(systemTestFixture.soyMons4nto);
        loggedSuperUser.setContextCompany(systemTestFixture.mons4ntoBr);
        loggedSuperUser.addCompany(systemTestFixture.mons4ntoBr);

        processorConfig = new ProcessorConfig();
        processorConfig.put(ProcessorConfigProperties.SELECTED_LOCALE, localeBR);
        processorConfig.put(ProcessorConfigProperties.LOGGED_USER, loggedSuperUser);
        
		builder = new SaleBuilder(systemTestFixture.matoGrossoDoSul, saleTestFixture.plantabilitiesSelectorMons4nto);
		createChargeConsolidateTypes();
    }
    
    @Test
    public void given_a_csv_with_valid_number_of_fields_when_read_then_should_show_zero_errors() throws BusinessException, IOException {
        Sale sale = generateAPaidBilling("12345", 1400d, true);
        StringBuffer csv = createValidCSVLine(null, sale, saleTestFixture.matrixMons4nto, saleTestFixture.matrixMons4nto, saleTestFixture.chicoBento, systemTestFixture.mons4ntoBr);
        LOG.info("Generated CSV: " + csv.toString());
        SaleCancelationCsvImportedFile file = processor.read(new ByteArrayInputStream(csv.toString().getBytes()), processorConfig);
        LOG.info(file.getWarnings(resourceBundle));
        assertCancellationResultStatus(1, 1, 0, 0, 1, file);
    }
    
    
    @Test
    public void given_a_csv_with_valid_number_of_fields_when_read_one_sale_then_should_show_already_cancelled() throws BusinessException, IOException {
        Sale sale = generateAPaidBilling("12345", 1400d, true);
        sale.getItems().iterator().next().getBilling().setPaymentStatus(PaymentStatus.CANCELLED);
        saveAndFlush(sale);
        StringBuffer csv = createValidCSVLine(null, sale, saleTestFixture.matrixMons4nto, saleTestFixture.matrixMons4nto, saleTestFixture.chicoBento, systemTestFixture.mons4ntoBr);
        LOG.info("Generated CSV: " + csv.toString());
        SaleCancelationCsvImportedFile file = processor.read(new ByteArrayInputStream(csv.toString().getBytes()), processorConfig);
        LOG.info(file.getWarnings(resourceBundle));
        assertCancellationResultStatus(0, 0, 1, 0, 1, file);
    }
    
    
    @Test
    public void given_a_csv_with_valid_number_of_fields_when_read_two_sale_one_cancelled_and_one_should_have_successes() throws BusinessException, IOException {
        
        Sale saleOne = generateAPaidBilling("12345", 1400d, true);
        saleOne.getItems().iterator().next().getBilling().setPaymentStatus(PaymentStatus.CANCELLED);
        saveAndFlush(saleOne);
        StringBuffer csv = createValidCSVLine(null, saleOne, saleTestFixture.matrixMons4nto, saleTestFixture.matrixMons4nto, saleTestFixture.chicoBento, systemTestFixture.mons4ntoBr);
        LOG.info("Generated CSV: " + csv.toString());
        SaleCancelationCsvImportedFile file = processor.read(new ByteArrayInputStream(csv.toString().getBytes()), processorConfig);
        LOG.info(file.getWarnings(resourceBundle));
        Sale saleTwo = generateAPaidBilling("12345", 170d, true);
        csv = createValidCSVLine(null, saleTwo, saleTestFixture.matrixMons4nto, saleTestFixture.matrixMons4nto, saleTestFixture.chicoBento, systemTestFixture.mons4ntoBr);
        file = processor.read(new ByteArrayInputStream(csv.toString().getBytes()), processorConfig);
        
        assertCancellationResultStatus(1, 1, 0, 0, 1, file);
    }
    
    @Test
    public void given_a_csv_with_valid_number_of_fields_when_read_two_equals_sales() throws BusinessException, IOException {
        
        Sale saleOne = generateAPaidBilling("1", 1400d, true);
        Sale saleTwo = generateAPaidBilling(null,1400d, true);
        saleTwo.setInvoiceNumber("1");
        saveAndFlush(saleTwo);
        SaleCancelationCsvImportedFile file = processor.read(new ByteArrayInputStream(saleOne.toString().getBytes()), processorConfig);
        StringBuffer csv = createValidCSVLine(null, saleOne, saleTestFixture.matrixMons4nto, saleTestFixture.matrixMons4nto, saleTestFixture.chicoBento, systemTestFixture.mons4ntoBr);
        file = processor.read(new ByteArrayInputStream(csv.toString().getBytes()), processorConfig);
        
        assertCancellationResultStatus(0, 0, 1, 0, 1, file);
    }
    
    
	@Test
    public void given_a_csv_with_invalid_number_of_fields_when_read_then_should_show_one_warning() throws BusinessException, IOException {
        Sale sale = generateAPaidBilling("12345", 1400d, true);
        StringBuffer csv = createInvalidCSVLine(null, sale, saleTestFixture.matrixMons4nto, saleTestFixture.matrixMons4nto, saleTestFixture.chicoBento, systemTestFixture.mons4ntoBr);
        SaleCancelationCsvImportedFile file = processor.read(new ByteArrayInputStream(csv.toString().getBytes()), processorConfig);
        LOG.info(file.getWarnings(resourceBundle));
        assertCancellationResultStatus(0, 0, 1, 0, 1, file);
    }
	
	
	@Test
    public void given_a_csv_with_invalid_number_of_fields_when_read_then_should_show_date_invalid_warning() throws BusinessException, IOException {
	    Sale sale = generateAPaidBilling("12345", 1400d, true);
        sale.setCreationDate(CalendarUtil.add(Calendar.YEAR, 2, CalendarUtil.getDateNow()));
	    StringBuffer csv = createValidCSVLine(null, sale, saleTestFixture.matrixMons4nto, saleTestFixture.matrixMons4nto, saleTestFixture.chicoBento, systemTestFixture.mons4ntoBr);
	    LOG.info("Generated CSV: " + csv.toString());
        SaleCancelationCsvImportedFile file = processor.read(new ByteArrayInputStream(csv.toString().getBytes()), processorConfig);
        LOG.info(file.getWarnings(resourceBundle));
	
	}
	
	
	@Test
    public void given_a_csv_with_invalid_number_of_fields_when_read_then_should_show_state_invalid_warning() throws BusinessException, IOException {
        Sale sale = generateAPaidBilling("12345", 1400d, true);
        sale.setState(new State(systemTestFixture.brazil, null, "this state don't exist"));
        StringBuffer csv = createValidCSVLine(null, sale, saleTestFixture.matrixMons4nto, saleTestFixture.matrixMons4nto, saleTestFixture.chicoBento, systemTestFixture.mons4ntoBr);
        LOG.info("Generated CSV: " + csv.toString());
        SaleCancelationCsvImportedFile file = processor.read(new ByteArrayInputStream(csv.toString().getBytes()), processorConfig);
        LOG.info(file.getWarnings(resourceBundle));
    
    }
	
	@Test
    public void given_a_valid_csv_and_paid_billing_when_write_csv_then_should_have_full_successes() throws BusinessException, IOException {
        Sale sale = generateAPaidBilling("12345", 1400d, true);
        StringBuffer csv = createValidCSVLine(null, sale, saleTestFixture.matrixMons4nto, saleTestFixture.matrixMons4nto, saleTestFixture.chicoBento, systemTestFixture.mons4ntoBr);
        SaleCancelationCsvImportedFile file = processor.read(new ByteArrayInputStream(csv.toString().getBytes()), processorConfig);
        file = processor.write(file, processorConfig);
        assertCancellationResultStatus(1, 1, 0, 0, 1, file);
        assertBillingNotPaid(sale.getId(), accessControlIntent.superUser);
    }
 	
 	@Test
    public void given_a_valid_csv_and_partial_paid_billing_when_write_csv_then_should_have_full_successes() throws BusinessException, IOException {
        Sale sale = generateAPaidBilling("12345", 700d, true);
        StringBuffer csv = createValidCSVLine(null, sale, saleTestFixture.matrixMons4nto, saleTestFixture.matrixMons4nto, saleTestFixture.chicoBento, systemTestFixture.mons4ntoBr);
        SaleCancelationCsvImportedFile file = processor.read(new ByteArrayInputStream(csv.toString().getBytes()), processorConfig);
        file = processor.write(file, processorConfig);
        assertCancellationResultStatus(1, 1, 0, 0, 1, file);
        assertBillingNotPaid(sale.getId(), accessControlIntent.superUser);
    }      
 	
 	@Test
    public void given_a_valid_csv_and_unpaid_billing_when_write_csv_then_should_have_one_error() throws BusinessException, IOException {
        Sale sale = generateAPaidBilling("12345", 0d, true);
        StringBuffer csv = createValidCSVLine(null, sale, saleTestFixture.matrixMons4nto, saleTestFixture.matrixMons4nto, saleTestFixture.chicoBento, systemTestFixture.mons4ntoBr);
        SaleCancelationCsvImportedFile file = processor.read(new ByteArrayInputStream(csv.toString().getBytes()), processorConfig);
        file = processor.write(file, processorConfig);
        assertCancellationResultStatus(0, 0, 1, 0, 1, file);
        assertBillingNotPaid(sale.getId(), accessControlIntent.superUser);
    }      
 	
 	@Test
    public void given_a_valid_csv_and_paid_not_manual_billing_when_write_csv_then_should_have_one_error() throws BusinessException, IOException {
        Sale sale = generateAPaidBilling("12345", 1400d, false);
        StringBuffer csv = createValidCSVLine(null, sale, saleTestFixture.matrixMons4nto, saleTestFixture.matrixMons4nto, saleTestFixture.chicoBento, systemTestFixture.mons4ntoBr);
        SaleCancelationCsvImportedFile file = processor.read(new ByteArrayInputStream(csv.toString().getBytes()), processorConfig);
        file = processor.write(file, processorConfig);
        assertCancellationResultStatus(0, 0, 1, 0, 1, file);
    }      
 	
 	@Test
    public void given_a_valid_csv_with_two_lines_and_paid_manual_billings_when_write_csv_with_multiple_lines_then_should_have_full_successes() throws BusinessException, IOException {
        Sale sale = generateAPaidBilling("12345", 1400d, true);
        StringBuffer csv = createValidCSVLine(null, sale, saleTestFixture.matrixMons4nto, saleTestFixture.matrixMons4nto, saleTestFixture.chicoBento, systemTestFixture.mons4ntoBr);
        sale = generateAPaidBilling("123456", 1400d, true);
        csv = createValidCSVLine(csv, sale, saleTestFixture.matrixMons4nto, saleTestFixture.matrixMons4nto, saleTestFixture.chicoBento, systemTestFixture.mons4ntoBr);
        SaleCancelationCsvImportedFile file = processor.read(new ByteArrayInputStream(csv.toString().getBytes()), processorConfig);
        assertCancellationResultStatus(2, 2, 0, 0, 2, file);
        file = processor.write(file, processorConfig);
        assertCancellationResultStatus(2, 2, 0, 0, 2, file);
    }      
 	
 	@Test
    public void given_a_csv_with_two_valid_lines_and_an_invalid_line_and_paid_manual_billings_when_write_csv_with_multiple_lines_then_should_have_full_successes() throws BusinessException, IOException {
        Sale sale = generateAPaidBilling("12345", 1400d, true);
        StringBuffer csv = createValidCSVLine(null, sale, saleTestFixture.matrixMons4nto, saleTestFixture.matrixMons4nto, saleTestFixture.chicoBento, systemTestFixture.mons4ntoBr);
        sale = generateAPaidBilling("123456", 1400d, true);
        csv = createValidCSVLine(csv, sale, saleTestFixture.matrixMons4nto, saleTestFixture.matrixMons4nto, saleTestFixture.chicoBento, systemTestFixture.mons4ntoBr);
        csv = createValidCSVLine(csv, sale, saleTestFixture.matrixMons4nto, saleTestFixture.matrixCargil, saleTestFixture.chicoBento, systemTestFixture.mons4ntoBr);
        SaleCancelationCsvImportedFile file = processor.read(new ByteArrayInputStream(csv.toString().getBytes()), processorConfig);
        assertCancellationResultStatus(2, 2, 1, 0, 3, file);
        file = processor.write(file, processorConfig);
        assertCancellationResultStatus(2, 2, 1, 0, 3, file);
    }
 	
 	@Test
    public void given_a_csv_with_one_valid_line_and_paid_manual_billings_when_deduct_credit_manually_and_write_csv_with_multiple_lines_then_should_have_one_warning() throws BusinessException, IOException, ManualCreditConstraintException {
        Sale sale = generateAPaidBillingManualRelease("12345", 1400d, true);
	    accountService.generateCreditManually(systemTestFixture.soyMons4nto, saleTestFixture.harvestSoyMons4nto2012.getOperationalYear(), systemTestFixture.intactaMons4nto, saleTestFixture.chicoBento, ManualCreditTransactionType.DEBIT, BigDecimal.valueOf(1L), "system test", "ANDREGC");
        StringBuffer csv = createValidCSVLine(null, sale, saleTestFixture.matrixMons4nto, saleTestFixture.matrixMons4nto, saleTestFixture.chicoBento, systemTestFixture.mons4ntoBr);
        SaleCancelationCsvImportedFile file = processor.read(new ByteArrayInputStream(csv.toString().getBytes()), processorConfig);
        assertCancellationResultStatus(0, 0, 1, 0, 1, file);
    }
 	
 	@Test
    public void given_a_csv_with_two_valid_line_and_paid_manual_billings_when_deduct_credit_manually_and_write_csv_with_multiple_lines_then_should_have_one_error() throws BusinessException, IOException, ManualCreditConstraintException {
        Sale sale = generateAPaidBillingManualRelease("12345", 1400d, true);
        StringBuffer csv = createValidCSVLine(null, sale, saleTestFixture.matrixMons4nto, saleTestFixture.matrixMons4nto, saleTestFixture.chicoBento, systemTestFixture.mons4ntoBr);
        sale = generateAPaidBillingManualRelease("123456", 1400d, true);
        csv = createValidCSVLine(csv, sale, saleTestFixture.matrixMons4nto, saleTestFixture.matrixMons4nto, saleTestFixture.chicoBento, systemTestFixture.mons4ntoBr);
	    accountService.generateCreditManually(systemTestFixture.soyMons4nto, saleTestFixture.harvestSoyMons4nto2012.getOperationalYear(), systemTestFixture.intactaMons4nto, saleTestFixture.chicoBento, ManualCreditTransactionType.DEBIT, BigDecimal.valueOf(1L), "system test", "ANDREGC");
        SaleCancelationCsvImportedFile file = processor.read(new ByteArrayInputStream(csv.toString().getBytes()), processorConfig);
        file = processor.write(file, processorConfig);
        assertCancellationResultStatus(1, 2, 0, 1, 2, file);
    }
 	
 	private Sale generateAPaidBillingManualRelease(String invoiceNumber, double amount, boolean manualPayment) throws BusinessException {
        Sale sale = createASaleTemplateIntactaManualRelease(invoiceNumber);
        
        BillingFilter billingFilter = BillingFilter.getInstance()
                .add(sale.getId())
                .add((UserContext)accessControlIntent.superUser);
        
        List<BillingDTO> billingDTOList = saleService.getBillingsOfSale(billingFilter).getDecoratedBillings();
        
        createReleaseMatrixFor(billingDTOList);
        
        Assert.assertEquals("Correct number of billing", 1, billingDTOList.size());
        
        if(amount>0d) {
	        saleService.payBilling(billingDTOList.get(0).getBilling(), SaleTestFixture.DATE_NOW, new BigDecimal(amount), manualPayment);
        }
        return sale;
    }
	
	private Sale generateAPaidBilling(String invoiceNumber, double amount, boolean manualPayment) throws BusinessException {
        Sale sale = createASale(invoiceNumber);
        
        BillingFilter billingFilter = BillingFilter.getInstance()
                .add(sale.getId())
                .add((UserContext)accessControlIntent.superUser);
        
        List<BillingDTO> billingDTOList = saleService.getBillingsOfSale(billingFilter).getDecoratedBillings();
        
        Assert.assertEquals("Correct number of billing", 1, billingDTOList.size());
        
        Date nowDate = new Date();
        if(amount>0d) {
	        saleService.payBilling(billingDTOList.get(0).getBilling(), nowDate, new BigDecimal(amount), manualPayment);
        }
        
        createReleaseMatrixFor(billingDTOList);
        
        return sale;
    }
    
    private ReleaseMatrix createReleaseMatrixFor(List<BillingDTO> billing) throws BusinessException {
        ChargeConsolidateType saleRegisterChargeType = chargeConsolidateService.findConsolidateType(ChargeConsolidateTypeEnum.SALEREGISTERCHARGE);
        ReleaseMatrix releaseMatrix = new ReleaseMatrix(saleTestFixture.harvestSoyMonsanto2012, saleTestFixture.matrixCargil, saleRegisterChargeType);
        saveAndFlush(releaseMatrix);
        
        for (BillingDTO billingDTO : billing) {
            ReleaseMatrixToBilling releaseMatrixToBilling = new ReleaseMatrixToBilling(releaseMatrix, billingDTO.getBilling());
            releaseMatrix.addReleaseMatrixToBilling(releaseMatrixToBilling);
            saveAndFlush(releaseMatrixToBilling);
        }
        
        return releaseMatrix;

    }
    
//    private Sale saveAValidSaleForAParticipant(Sale sale) throws BusinessException {
//        accessControlIntent.itsParticipantUser.addProfile(accessControlIntent.profileWithOneAction);
//        accessControlIntent.itsParticipantUser.addUserContract(saleTestFixture.contractMons4nto, saleTestFixture.matrixMons4nto, HierarchyLevel.HEAD_OFFICE);
//        saveAndFlush(accessControlIntent.itsParticipantUser);
//        
//        UserDecorator participantUser = getUserDecoratorBy(accessControlIntent.itsParticipantUser,systemTestFixture.soyMons4nto);
//        
//        saleService.save(sale, participantUser);
//        return sale;
//    }
    
//    private UserDecorator getUserDecoratorBy (ItsUser user, Crop crop) throws BusinessException{
//        UserDecorator userDecorator = userServices.getAuthenticatedUserBy(accessControlIntent.itsParticipantUser.getEmail());
//        userDecorator.setContextCrop(crop);
//        return userDecorator;
//    }
    
    private StringBuffer createValidCSVLine(StringBuffer csv, Sale sale, Customer headOffice, Customer partner,
            Grower grower, Company company) {
        return createLineForInputStream(csv, sale.getInvoiceNumber(), headOffice.getDocument()
                .getDocumentTypeDescription(), headOffice.getDocumentValue(), headOffice.getStateRegistration(),
                headOffice.getCustomerSAPCode(), partner.getDocument().getDocumentTypeDescription(),
                partner.getDocumentValue(), partner.getStateRegistration(), partner.getCustomerSAPCode(), grower
                        .getDocument().getDocumentTypeDescription(), grower.getDocumentValue(),
                CalendarUtil.formatDate(sale.getCreationDate(), CalendarUtil.PATTERN_DD_MM_YYYY), sale.getState()
                        .getCode(), company == null ? "" : company.getDescription());
    }
    
    private StringBuffer createInvalidCSVLine(StringBuffer csv, Sale sale, Customer headOffice, Customer partner,
            Grower grower, Company company) {
        return createLineForInputStream(csv, sale.getInvoiceNumber(), headOffice.getDocument()
                .getDocumentTypeDescription(), headOffice.getDocumentValue(), partner.getDocument()
                .getDocumentTypeDescription(), partner.getDocumentValue(), grower.getDocument()
                .getDocumentTypeDescription(), grower.getDocumentValue());
    }

    private StringBuffer createLineForInputStream(StringBuffer csv, String... args) {
        if(csv==null) {
            csv = new StringBuffer("Nota Fiscal N\u00FAmero;Tipo de documento do Matriz;Matriz;Tipo de documento do Parceiro;N\u00FAmero do documento do Parceiro;Tipo de documento do agricultor;N\u00FAmero do documento do Agricultor;Data de Lan\u00E7amento;UF de plantio;Empresa");
            csv.append("\n");
        }
        for(int i=0;i<args.length;++i) {            
            csv.append(args[i]==null?"":args[i]);
            if(i<args.length) {
	            csv.append(";");
            }
        }
        csv.append("\n");
        return csv;
    }
    
    private void assertCancellationResultStatus(int expectedSuccessLinesCount, int expectedDetailLinesCount, int expectedWarningCount, int expectedErrorsCount, int totalLineNumber, SaleCancelationCsvImportedFile actualResult) {
        Assert.assertNotNull("Result of read file should not be null", actualResult);
        Assert.assertEquals("Number of success lines is wrong " + actualResult.getWarnings(resourceBundle), expectedSuccessLinesCount, actualResult.countSuccess());
        Assert.assertEquals("Number of detail lines is wrong", expectedDetailLinesCount, actualResult.countDetailLines());
        Assert.assertEquals("Number of warnings is wrong", expectedWarningCount, actualResult.countWarnings());
        Assert.assertEquals("Number of erros is wrong", expectedErrorsCount, actualResult.countErrors());
        Assert.assertEquals("Total # of lines is wrong", totalLineNumber, actualResult.countTotalLines());
    }
    
    private Sale createASale(String invoiceNumber) throws SaleConstraintViolationException {
        builder.clear();
        builder.addSaleItem(saleTestFixture.productIntactaSoyMons4nto, 
                saleTestFixture.templateIntactaMons4nto, 
                saleTestFixture.officeMons4nto, 
                2000L, 
                SaleTestFixture.TWO_POINT_FIVE_DOLLARS, 
                saleTestFixture.plantability45To54SoyMons4nto2012, 
                SaleTestFixture.APRIL);
        
        Sale sale = builder.setGrower(saleTestFixture.chicoBento).setCustomer(saleTestFixture.matrixMons4nto).buildSale();
        sale.setCreationDate(SaleTestFixture.DATE_NOW);
        sale.setRegion(systemTestFixture.regionSaoPaulo2012);
        sale.getState().setCode("MSS");
        
        if ( invoiceNumber != null ) {
            sale.setInvoiceNumber(invoiceNumber);
        }
        
        saleService.save(sale, getParticipantUser());
        
        
        return sale;
    }
    
    private Sale createASaleTemplateIntactaManualRelease(String invoiceNumber) throws SaleConstraintViolationException {
        builder.clear();
        builder.addSaleItem(saleTestFixture.productIntactaSoyMons4nto, 
                saleTestFixture.templateIntactaMons4ntoOnPayment, 
                saleTestFixture.officeMons4nto, 
                2000L, 
                SaleTestFixture.TWO_POINT_FIVE_DOLLARS, 
                saleTestFixture.plantability45To54SoyMons4nto2012, 
                SaleTestFixture.APRIL);
        
        Sale sale = builder.setGrower(saleTestFixture.chicoBento).setCustomer(saleTestFixture.matrixMons4nto).buildSale();
        sale.setCreationDate(SaleTestFixture.DATE_NOW);
        sale.setRegion(systemTestFixture.regionSaoPaulo2012);
        
        if ( invoiceNumber != null ) {
            sale.setInvoiceNumber(invoiceNumber);
        }
        
        sale.getState().setCode("MSS");
        
        saleService.save(sale, getParticipantUser());

        return sale;
    }
    
    private void assertBillingNotPaid(Long id, UserDecorator user) {
			BillingFilter billingFilter = BillingFilter.getInstance()
				.add(id)
				.add((UserContext)user);
			
			List<BillingDTO> billingDTOList = saleService.getBillingsOfSale(billingFilter).getDecoratedBillings();
			
			Assert.assertFalse("Should not have been paid",billingDTOList.get(0).getBilling().isPaid());
			Assert.assertEquals("Should have been peding status",PaymentStatus.NOT_PAID, billingDTOList.get(0).getBilling().getPaymentStatus());
    }
    
    private UserDecorator getParticipantUser() {

    	UserDecorator participantUser = accessControlIntent.participantUser;
        UserContract contractWithMons4nto = new UserContract(participantUser.getCurrentUser(),saleTestFixture.contractMons4nto, saleTestFixture.matrixMons4nto, HierarchyLevel.HEAD_OFFICE); 
        saveAndFlush(contractWithMons4nto);
        
        participantUser.addUserContract(contractWithMons4nto);
        participantUser.setContextCrop(systemTestFixture.soyMons4nto);
        participantUser.addCompany(systemTestFixture.mons4ntoBr);
        
        return participantUser;
    }
}
