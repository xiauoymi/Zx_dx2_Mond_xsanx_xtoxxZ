package com.monsanto.brazilvaluecapture.seedsale.product;

import com.monsanto.brazilvaluecapture.core.base.CountryTestData;
import com.monsanto.brazilvaluecapture.seedsale.harvest.HarvestTestData;
import com.monsanto.brazilvaluecapture.seedsale.product.model.bean.Region;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: MEFAZZ
 * Date: 9/9/13
 * Time: 3:14 PM
 * To change this template use File | Settings | File Templates.
 */
public class RegionProductivityTestData {


    public static Region createRegionProductivity(){
      Region regionProductivity  = new Region();
      regionProductivity.setOperationalYear(HarvestTestData.createABrazilianHarvest().getOperationalYear());
      regionProductivity.setCountry(CountryTestData.createBrazil());
      regionProductivity.setId(1l);
      regionProductivity.setRegionDescription("region");
      return regionProductivity;

    }

    public static List<Region> createSomeRegionProductivity(){
      List<Region> regionProductivities = new ArrayList<Region>();
      regionProductivities.add(createRegionProductivity());
      regionProductivities.add(createRegionProductivity());
      regionProductivities.add(createRegionProductivity());
      regionProductivities.add(createRegionProductivity());
      return regionProductivities;
    }

}
