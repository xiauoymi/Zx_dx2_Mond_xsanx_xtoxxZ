package com.monsanto.brazilvaluecapture.seedsale.bonus.transfer.dao;

import com.monsanto.brazilvaluecapture.core.base.model.bean.Company;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Crop;
import com.monsanto.brazilvaluecapture.core.commercialhierarchy.model.bean.ItsDistrict;
import com.monsanto.brazilvaluecapture.core.commercialhierarchy.model.bean.ItsRegion;
import com.monsanto.brazilvaluecapture.core.commercialhierarchy.model.bean.ItsUnity;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Technology;
import com.monsanto.brazilvaluecapture.core.grower.model.bean.AgreementTemplateType;
import com.monsanto.brazilvaluecapture.core.grower.model.bean.BonusExpiration;
import com.monsanto.brazilvaluecapture.core.grower.model.bean.Grower;
import com.monsanto.brazilvaluecapture.core.grower.model.dao.BonusExpirationFilter;
import com.monsanto.brazilvaluecapture.seedsale.bonus.transfer.bean.BonusTransfer;
import com.monsanto.brazilvaluecapture.seedsale.bonus.transfer.bean.BonusTransferStateEnum;
import junit.framework.Assert;
import org.hibernate.Criteria;
import org.hibernate.SessionFactory;
import org.hibernate.classic.Session;
import org.hibernate.engine.SessionFactoryImplementor;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.orm.hibernate3.HibernateTemplate;

import java.util.Date;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
import static org.mockito.Mockito.withSettings;

/**
 * User: GMNAVE
 * Date: 5/14/14
 * Time: 2:43 PM
 */
public class BonusTransferFilter_UT {

    BonusTransferFilter bonusTransferFilter;

    SessionFactory sf;
    SessionFactoryImplementor sfi;
    @Mock
    Session session;
    @Mock
    HibernateTemplate t;
    @Mock
    Criteria criteria;

    @Before
    public void setUp() throws Exception {
        MockitoAnnotations.initMocks(this);
        bonusTransferFilter = BonusTransferFilter.getInstance();

        sf = mock(SessionFactory.class, withSettings().extraInterfaces(SessionFactoryImplementor.class));
        sfi = (SessionFactoryImplementor) sf;
        when(sf.openSession()).thenReturn(session);
    }


    @Test
    public void testCreateCriteria_WhenOnlyTechnologyIsGiven(){

        //@ Given
        Technology technology = new Technology();
        technology.setId(1L);

        //@ When
        bonusTransferFilter.addFilter(technology);

        //@ Should
        Assert.assertEquals(bonusTransferFilter.countCriterias(), 1);
    }

    @Test
    public void testCreateCriteria_WhenOnlyCompanyIsGiven(){

        //@ Given
        Company company = new Company();
        company.setId(1L);

        //@ When
        bonusTransferFilter.addFilter(company);

        //@ Should
        Assert.assertEquals(bonusTransferFilter.countCriterias(), 1);
    }

    @Test
    public void testCreateCriteria_WhenOnlyCropIsGiven(){

        //@ Given
        Crop crop = new Crop();
        crop.setId(1L);

        //@ When
        bonusTransferFilter.addFilter(crop);

        //@ Should
        Assert.assertEquals(bonusTransferFilter.countCriterias(), 1);
    }

    @Test
    public void testCreateCriteria_WhenOnlyGrowersAreGiven(){

        //@ Given
        Grower from = new Grower();
        from.setId(1L);
        Grower to = new Grower();
        to.setId(1L);

        //@ When
        bonusTransferFilter.addGrowerFrom(from);
        bonusTransferFilter.addGrowerTo(to);

        //@ Should
        Assert.assertEquals(bonusTransferFilter.countCriterias(), 2);
    }

    @Test
    public void testCreateCriteria_WhenOnlyDatePeriodIsGiven(){

        //@ Given
        Date d1 = new Date();
        Date d2 = new Date();

        //@ When
        bonusTransferFilter.addDatePeriodFilter(d1, d2);

        //@ Should
        Assert.assertEquals(bonusTransferFilter.countCriterias(), 1);
    }

    @Test
    public void testCreateCriteria_WhenOnlyUnitRegionAndDistrictAreGiven(){

        //@ Given
        ItsUnity itsUnity = new ItsUnity();
        ItsRegion itsRegion = new ItsRegion();
        ItsDistrict itsDistrict = new ItsDistrict();

        //@ When
        bonusTransferFilter.addFilter(itsUnity, itsRegion, itsDistrict);

        //@ Should
        Assert.assertEquals(bonusTransferFilter.countCriterias(), 3);
    }

    @Test
    public void testCreateCriteria_WhenOnlyBonusTransferStateEnumIsGiven(){

        //@ Given
        BonusTransferStateEnum bonusTransferStateEnum = BonusTransferStateEnum.APPROVED;

        //@ When
        bonusTransferFilter.addFilter(bonusTransferStateEnum);

        //@ Should
        Assert.assertEquals(bonusTransferFilter.countCriterias(), 1);
    }

    @Test
    public void testCreateCriteria_WhenOnlyAgreementTemplateTypeIsGiven(){

        //@ Given
        AgreementTemplateType agreementTemplateType = new AgreementTemplateType();

        //@ When
        bonusTransferFilter.addFilter(agreementTemplateType);

        //@ Should
        Assert.assertEquals(bonusTransferFilter.countCriterias(), 1);
    }

    @Test
    public void testCreateCriteria_WhenCreateCriteria(){

        //@Given
        when(session.createCriteria(BonusTransfer.class,"bonusTransfer")).thenReturn(criteria);

        //@ When
        Criteria expected = bonusTransferFilter.createCriteria(session);

        //@ Should
        Assert.assertEquals(criteria, expected);
    }


}
