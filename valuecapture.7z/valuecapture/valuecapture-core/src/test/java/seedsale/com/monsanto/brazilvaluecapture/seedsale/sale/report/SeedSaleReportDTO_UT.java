package com.monsanto.brazilvaluecapture.seedsale.sale.report;

import com.monsanto.brazilvaluecapture.seedsale.billing.model.bean.CreditStatus;
import com.monsanto.brazilvaluecapture.seedsale.billing.model.bean.PaymentStatus;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.Sale;
import com.monsanto.brazilvaluecapture.seedsale.sale.report.model.bean.SeedSaleReportWithoutHierView;
import com.monsanto.brazilvaluecapture.seedsale.template.model.bean.SaleTemplateBillingMethodEnum;
import org.junit.Test;

import java.math.BigDecimal;

import static org.fest.assertions.Assertions.assertThat;

public class SeedSaleReportDTO_UT {

    @Test
    public void testSeedSaleReportDTODoNotInitializesPriceQty_WhenPaymentReceiptValueIsNull() {
        SeedSaleReportWithoutHierView saleReportView = createValidSeedSaleReportWithoutHierView();
        saleReportView.setPaymentReceiptValue(null);

        SeedSaleReportDTO saleReportDTO = new SeedSaleReportDTO(saleReportView);

        assertThat(saleReportDTO.getPriceQuantity()).isNull();
    }

    private SeedSaleReportWithoutHierView createValidSeedSaleReportWithoutHierView() {
        SeedSaleReportWithoutHierView saleReportView = new SeedSaleReportWithoutHierView();
        saleReportView.setSaleType(Sale.SaleTypeEnum.MULTIPLIER_TO_GROWER_SEED_SALE);
        saleReportView.setBillingMethod(SaleTemplateBillingMethodEnum.NO_BILLING);
        saleReportView.setPaymentStatus(PaymentStatus.FULLY_PAID);
        saleReportView.setCreditStatus(CreditStatus.ABSENT);
        saleReportView.setTotalSoldSeedQuantity(BigDecimal.ONE);
        saleReportView.setSoldQuantity(2l);
        saleReportView.setTotalCreditValue(2l);
        saleReportView.setCustomerParentDocument("Some Document");
        saleReportView.setCustomerParentDocMask("Some mask");
        saleReportView.setCustomerDocument("Some Document");
        saleReportView.setCustomerDocMask("Some mask");
        saleReportView.setGrowerDocMask("Some other mask");
        saleReportView.setGrowerDocument("Some other document");
        return saleReportView;
    }
}
