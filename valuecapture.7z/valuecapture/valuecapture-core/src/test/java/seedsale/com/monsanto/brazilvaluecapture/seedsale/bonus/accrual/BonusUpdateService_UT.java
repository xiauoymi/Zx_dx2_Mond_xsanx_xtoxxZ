package com.monsanto.brazilvaluecapture.seedsale.bonus.accrual;

import com.monsanto.brazilvaluecapture.bonus.bulkimport.model.dao.BonusDAO;
import com.monsanto.brazilvaluecapture.core.foundation.service.BusinessException;
import com.monsanto.brazilvaluecapture.core.foundation.util.log.bean.JobLogEntry;
import com.monsanto.brazilvaluecapture.core.grower.model.bean.BonusRulesValue;
import com.monsanto.brazilvaluecapture.core.grower.model.dao.BonusAccountDAO;
import com.monsanto.brazilvaluecapture.core.grower.model.dao.BonusExpirationDAO;
import com.monsanto.brazilvaluecapture.core.grower.model.dao.BonusRulesValuesDAO;
import com.monsanto.brazilvaluecapture.seedsale.bonus.accrual.service.impl.BonusUpdateServiceImpl;
import com.monsanto.brazilvaluecapture.seedsale.bonus.bulkimport.model.bean.BonusAccount;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import static org.fest.reflect.core.Reflection.field;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;
import static org.mockito.Mockito.*;

public class BonusUpdateService_UT {
    @Mock
    private BonusRulesValuesDAO bonusRulesValuesDAO;

    @Mock
    private BonusAccountDAO bonusAccountDAO;

    @Mock
    private BonusDAO bonusDAO;

    @Mock
    private BonusExpirationDAO bonusExpirationDAO;

    @InjectMocks
    private BonusUpdateServiceImpl bonusUpdateService;

    @Before
    public void setup() {
        bonusUpdateService = new BonusUpdateServiceImpl();
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void testCalculateRateToApplyWithNewValueOf18_5_LastValueOf19_3_RateToApplyOf0Returns0_043243243_WhenCalculatingTotalAccrual() {
        //@Given
        BigDecimal newValue = new BigDecimal("19.3");
        BigDecimal lastValue = new BigDecimal("18.5");
        BigDecimal rateToApply = new BigDecimal("0.043243243");
        //@When
        BigDecimal actual = bonusUpdateService.calculateRateToApply(newValue, lastValue);
        //@Then
        BigDecimal expected = rateToApply;
        assertTrue(areBigDecimalsEquals(actual, expected));
    }

    @Test
    public void testCalculateRateToApplyWithNewValueOf18_5_LastValueOf24_3_RateToApplyOf0Returns0_313513514_WhenCalculatingTotalAccrual() {
        //@Given
        BigDecimal newValue = new BigDecimal("24.3");
        BigDecimal lastValue = new BigDecimal("18.5");
        BigDecimal rateToApply = new BigDecimal("0.313513514");
        //@When
        BigDecimal actual = bonusUpdateService.calculateRateToApply(newValue, lastValue);
        //@Then
        BigDecimal expected = rateToApply;
        assertTrue(areBigDecimalsEquals(actual, expected));
    }

    @Test
    public void testFindRulesAtCurrentDateToApplyCheckIfCall_bonusRulesValuesDAO_findRulesAtCurrentDateToApply() {
        //@Given
        List<BonusRulesValue> rulesValueList = new ArrayList<BonusRulesValue>();
        //@When
        rulesValueList = bonusUpdateService.findRulesAtCurrentDateToApply();
        //@Then
        verify(bonusRulesValuesDAO).findRulesAtCurrentDateToApply();
    }

    @Test
    public void testFindRulesAtCurrentDateToApplyCallsDAO() {
        //@Given
        List<BonusRulesValue> bonusAccountsToUpdate = new ArrayList<BonusRulesValue>();
        BonusRulesValue bonusRulesValue = new BonusRulesValue();
        bonusRulesValue.setId(1l);
        //@When
        when(bonusRulesValuesDAO.findRulesAtCurrentDateToApply()).thenReturn(bonusAccountsToUpdate);
        bonusAccountsToUpdate = bonusUpdateService.findRulesAtCurrentDateToApply();
        //@Then
        verify(bonusRulesValuesDAO).findRulesAtCurrentDateToApply();
    }

    @Test
    public void testApplyRateToBalanceToBonusAccount_whenDecimalValuesAreUsed() throws BusinessException {

        BigDecimal lastValueAccrual = new BigDecimal(5.2);
        BigDecimal lastValueBonus = new BigDecimal(4.3);
        BonusAccount bonusAccount = new BonusAccount();
        bonusAccount.setBalance(new BigDecimal(100));
        BigDecimal newValueBonus = new BigDecimal(5.2);
        BigDecimal newValueAccrual = new BigDecimal(5.2);
        field("accrualTotalValue").ofType(BigDecimal.class).in(this.bonusUpdateService).set(new BigDecimal(0));
        field("jobLogEntry").ofType(JobLogEntry.class).in(this.bonusUpdateService).set(mock(JobLogEntry.class));

        try {
            bonusUpdateService.applyRateToBalanceToBonusAccount(newValueBonus, lastValueBonus, newValueAccrual, lastValueAccrual, bonusAccount);
        }catch (ArithmeticException e){
            fail("Should not throw ArithmeticException");
        }
    }

    private Boolean areBigDecimalsEquals(BigDecimal one, BigDecimal second) {
        return (one.compareTo(second) == 0);
    }
}
