package com.monsanto.brazilvaluecapture.seedsale.revenue.service;

import com.monsanto.brazilvaluecapture.core.foundation.test.AbstractServiceIntegrationTests;
import junit.framework.Assert;
import org.junit.Test;

public class RevenueManager_AT extends AbstractServiceIntegrationTests {

    @Test
    public void test() {
        Assert.assertEquals("test", "test");
    }

	/*@Autowired
    private SaleService saleService;

	private AccessControlTestFixture accessControlIntent;

	private SaleItemFactory saleItemFactory;

	@Autowired
	private UserService userServices;

	@Autowired
	private RevenueService revenueService;

   @Autowired
    private RevenueManager revenueManager;

   @Autowired
   private RevenueAccountDAO revenueAccountDAO;

    @Autowired
    private CountriesHolder countriesHolder;


	@Autowired
	private SaleBillableProvider billableProvider;

	@Autowired
	private AccountService accountService;

	private Cancellation cancellation;

	@Autowired
	private RevenueDetailedExtractLazyLoadBuilder lazyBuilder;

	private static final Calendar PAST;
	private static final Calendar FUTURE;
	private static final Calendar LESSPAST;

	static {
	    PAST = Calendar.getInstance();
	    PAST.set(1970, 1, 1);
	    FUTURE = Calendar.getInstance();
	    FUTURE.set(3000, 1, 1);
	    LESSPAST = Calendar.getInstance();
	    LESSPAST.set(1980, 1,1);
	}

	@SuppressWarnings("unchecked")
	@Before
	public void init() throws BusinessException, InfraException {
		systemTestFixture = new SystemTestFixture(this);
		accessControlIntent = new AccessControlTestFixture(this, systemTestFixture);
		saleTestFixture = new SaleTestFixture(this, systemTestFixture);
		saleItemFactory = SaleItemFactory.getInstance(systemTestFixture.matoGrossoDoSul, saleTestFixture.plantabilitiesSelector);

		OsbRevenueService osbService = mock(OsbRevenueService.class);
		OSBReturn result = new OSBReturn();
		result.setDocumentNumber(RandomTestData.createRandomLong().toString());
		result.setSaleOrderNmber(RandomTestData.createRandomLong().toString());
		stub(osbService.bill(Matchers.any(DocumentType.class), Matchers.any(String.class), Matchers.any(Boolean.class), Matchers.any(Date.class), Matchers.any(List.class), Matchers.any(List.class), Matchers.any(String.class))).toReturn(result);
		revenueManager.setOsbService(osbService);

		cancellation = new Cancellation();
		cancellation.setCode("cancellation code");
		cancellation.setDescription("description");
		saveAndFlush(cancellation);

		createChargeConsolidateTypes();

         //Added for LASVC to return a country brazil
         String configuredHost = "CONFIGURED_AND_REQUESTED_HOST_SAME";
		 EnvironmentSpecificPropertyReader env = mock(EnvironmentSpecificPropertyReader.class);
		 countriesHolder.setEnvironmentSpecificPropertyReader(env);
		 when(env.getEnvironmentSpecificProperty("host_name.argentina", null)).thenReturn("other");
		 when(env.getEnvironmentSpecificProperty("host_name.brazil", null)).thenReturn(configuredHost);
		 when(env.getEnvironmentSpecificProperty("host_name.paraguay", null)).thenReturn("another");

         countriesHolder.initialize();
         try{
            countriesHolder.resolveCountry(configuredHost);
         }catch(IllegalStateException ex)
         {

         }
	}


	@Test
    @Ignore
	public void given_sale_registered_when_bill_called_then_send_to_obs() throws BusinessException, InfraException {

		SaleItem saleItem = createAndSaveBilledSale();
		Assert.assertNotNull("Sale item shouldn't be null", saleItem);
		Assert.assertNotNull("Retribution value shouldn't be null", saleItem.getRetributionFeeValue());
		Assert.assertEquals("Payment status should be billed", PaymentStatus.BILLED, saleItem.getBilling().getPaymentStatus());
		Assert.assertEquals("Retribution 0.35" , 0, BigDecimal.valueOf(0.35d).compareTo(saleItem.getRetributionFeeValue()));
		RevenueAccount account = (RevenueAccount) getSession().get(RevenueAccount.class, saleItem.getRevenueAccount().getId());
		Assert.assertNotNull("Account shouldn't be null", account);
		Assert.assertEquals("Account should have status billed", RevenueStatus.BILLED, account.getStatus());
		Assert.assertEquals("Handle should equal sale item id", saleItem.getId(), account.getHandles().iterator().next().getHandle());

	}

	private Sale saveAValidSaleForAParticipant(Sale sale, Customer customer, Contract contract, boolean initMaterialContract) throws BusinessException {
		if(initMaterialContract) {
			accessControlIntent.itsParticipantUser.addProfile(accessControlIntent.profileWithOneAction);
			accessControlIntent.itsParticipantUser.addUserContract(contract, customer, HierarchyLevel.HEAD_OFFICE);
			saveAndFlush(accessControlIntent.itsParticipantUser);
		}

		UserDecorator participantUser = getUserDecoratorBy(accessControlIntent.itsParticipantUser,systemTestFixture.soy);

		saleService.save(sale, participantUser);
		return sale;
	}

	private UserDecorator getUserDecoratorBy (ItsUser user, Crop crop) throws BusinessException{
		UserDecorator userDecorator = userServices.getAuthenticatedUserBy(accessControlIntent.itsParticipantUser.getLogin());
		userDecorator.setContextCrop(crop);
		return userDecorator;
	}



	private void createMaterials(String sapCode, HeadOffice headOfficeAffiliate, boolean badContract, Long id) {
	    Contract contract = null;
	    if(badContract) {
	        contract = createBadContract(headOfficeAffiliate);
	    } else {
			contract = createContract(headOfficeAffiliate);
	    }


		MaterialDetail materialDetail = new MaterialDetail();
		materialDetail.setId(id);
		materialDetail.setMaterialSapId(sapCode);
		materialDetail.setMaterialDescription("Material 1");
		materialDetail.setContract(contract);
		saveAndFlush(materialDetail);

	}

	private Contract createBadContract(HeadOffice headOfficeAffiliate) {
	    Contract contract=null;
        for(Contract contract2: headOfficeAffiliate.getMatrix().getContracts()){
            contract =contract2;
        }
        contract = (Contract)getSession().get(Contract.class, contract.getId());
        contract.setStartDate(PAST.getDateTodayPreviousMonth());
        contract.setEndDate(LESSPAST.getDateTodayPreviousMonth());
        saveAndFlush(contract);

        return contract;
	}


	private Contract createContract(HeadOffice headOfficeAffiliate) {
		Contract contract=null;
		for(Contract contract2: headOfficeAffiliate.getMatrix().getContracts()){
			contract =contract2;
		}
		contract.setStartDate(PAST.getDateTodayPreviousMonth());
		contract.setEndDate(FUTURE.getDateTodayPreviousMonth());
		saveAndFlush(contract);

		return contract;
	}

	@Test(expected=RevenueAccountConstraintViolationException.class)
	public void given_revenueAccount_billed_when_reversalCode_null_should_validate_mandatory_fields_for_reversal() throws BusinessException {
		RevenueAccount revenueAccount = new RevenueAccount(saleTestFixture.matrixCargil, "111", systemTestFixture.operationalYearOf2009, RevenueType.DISTRIBUTION,systemTestFixture.monsantoBr, new Date(), new Date());
		saveAndFlush(revenueAccount);
		revenueService.reversal(billableProvider, revenueAccount, null, "reason", "vrodrigues", cancellation);
	}

	@Test(expected=RevenueAccountConstraintViolationException.class)
	public void given_revenueAccount_billed_when_reversalReason_null_should_validate_mandatory_fields_for_reversal() throws BusinessException {
		RevenueAccount revenueAccount = new RevenueAccount(saleTestFixture.matrixCargil, "111", systemTestFixture.operationalYearOf2009, RevenueType.DISTRIBUTION, systemTestFixture.monsantoBr, new Date(), new Date());
		saveAndFlush(revenueAccount);
		revenueService.reversal(billableProvider, revenueAccount, "erp code", null, "vrodrigues", cancellation);
	}

	@Test(expected=RevenueAccountConstraintViolationException.class)
	public void given_revenueAccount_billed_when_reversalLogin_null_should_validate_mandatory_fields_for_reversal() throws BusinessException {
		RevenueAccount revenueAccount = new RevenueAccount(saleTestFixture.matrixCargil, "111", systemTestFixture.operationalYearOf2009, RevenueType.DISTRIBUTION, systemTestFixture.monsantoBr, new Date(), new Date());
		saveAndFlush(revenueAccount);
		revenueService.reversal(billableProvider, revenueAccount, "erp code", "reason", null, cancellation);
	}

	@Test
	public void given_revenueAccount_billed_when_reversal_should_succeed() throws BusinessException {
		RevenueAccount revenueAccount = new RevenueAccount(saleTestFixture.matrixCargil, "111", systemTestFixture.operationalYearOf2009, RevenueType.DISTRIBUTION, systemTestFixture.monsantoBr, new Date(), new Date());
		saveAndFlush(revenueAccount);
		revenueAccount.addHandle(new RevenueHandle(1L));
		revenueService.reversal(billableProvider, revenueAccount, "erp code", "reason", "vrodrigues", cancellation);

		Assert.assertEquals("Should be in status reversed", RevenueStatus.REVERSED, revenueAccount.getStatus());
		Assert.assertEquals("Reversal reason not same", "reason", revenueAccount.getReversalReason());
		Assert.assertEquals("Reversal login not same", "vrodrigues", revenueAccount.getReversalLogin());
		Assert.assertEquals("Reversal erp code not same", "erp code", revenueAccount.getErpReversalCode());
	}

	@Test
	public void given_a_billed_sale_when_revenueReversal_should_cancel_sale_and_reversal_revenue() throws BusinessException, InfraException {
		SaleItem saleItem = createAndSaveBilledSale();
		RevenueAccount revenueAccount = (RevenueAccount) getSession().get(RevenueAccount.class, saleItem.getRevenueAccount().getId());

		List<Billing> billings = saleService.getBillingBy(BillingFilter.getInstance().add(PaymentStatus.BILLED));
		Assert.assertEquals("Should have one billed billing", 1, billings.size());

		revenueService.reversal(billableProvider, revenueAccount, "code", "reason", "vrodrigues", cancellation);
		getSession().flush();

		billings = saleService.getBillingBy(BillingFilter.getInstance().add(PaymentStatus.BILLED));
		Assert.assertEquals("Should have none billed billing", 0, billings.size());
		Assert.assertEquals("Revenue account status should be reversed", RevenueStatus.REVERSED, revenueAccount.getStatus());
	}

	@Test
    @Ignore
	public void given_a_paid_billed_sale_when_reversal_and_balance_is_insufficient_should_throw_exception() throws BusinessException, InfraException {
		SaleItem saleItem = createAndSaveBilledSale();
		RevenueAccount revenueAccount = (RevenueAccount) getSession().get(RevenueAccount.class, saleItem.getRevenueAccount().getId());

		List<Billing> billings = saleService.getBillingBy(BillingFilter.getInstance().add(PaymentStatus.BILLED));
		Assert.assertEquals("Should have one billed billing", 1, billings.size());
		saleService.payBilling(billings.get(0), new Date(), BigDecimal.TEN, true);

		Account accountAvailable = accountService.fetchOrCreateAccount(AccountType.AVAILABLE, saleTestFixture.chicoBento, saleTestFixture.productIntactaSoy.getCrop(), saleTestFixture.productIntactaSoy.getTechnology(), systemTestFixture.operationalYearOf2012);
		accountService.manageManualCredit(ManualCreditTransactionType.DEBIT, accountAvailable.getBalance(), saleTestFixture.chicoBento, saleTestFixture.productIntactaSoy.getCrop(), saleTestFixture.productIntactaSoy.getTechnology(), systemTestFixture.operationalYearOf2012, 1L);

		try {
			revenueService.reversal(billableProvider, revenueAccount, "code", "reason", "vrodrigues", cancellation);
			Assert.fail("Should have thrown exception");
		} catch (BillingCancellationWarningException e) {
			ConstraintViolation violation = e.getViolations().get(0);
			Assert.assertEquals("Should have insufficient balance error", ErrorCode.INSUFFICIENT_BALANCE, violation.getCode());
			Assert.assertEquals("Balance expected", BigDecimal.ZERO, (BigDecimal) violation.getInnerViolation().getPlaces().get(0));
		}
	}

	@Test
	public void given_a_paid_billed_sale_when_reversal_should_cancelSale_and_inutilizeCredits() throws BusinessException, InfraException {
		SaleItem saleItem = createAndSaveBilledSale();
		RevenueAccount revenueAccount = (RevenueAccount) getSession().get(RevenueAccount.class, saleItem.getRevenueAccount().getId());

		List<Billing> billings = saleService.getBillingBy(BillingFilter.getInstance().add(PaymentStatus.BILLED));
		Assert.assertEquals("Should have one billed billing", 1, billings.size());
		saleService.payBilling(billings.get(0), new Date(), BigDecimal.TEN, true);

		revenueService.reversal(billableProvider, revenueAccount, "code", "reason", "vrodrigues", cancellation);
		Assert.assertEquals("Should have insufficient balance error", RevenueStatus.REVERSED, revenueAccount.getStatus());
	}

	@Test
    @Ignore
	public void given_manySales_when_grower_has_balance_to_reverse_only_one_should_thrown_exception_with_full_original_balance() throws BusinessException, InfraException {
		SaleItem saleItem = createAndSaveBilledSale();
		SaleItem saleItem2 = createAndSaveBilledSale();
		SaleItem saleItemBankslip = createSaleForParticipant(SaleTemplateBillingMethodEnum.BANKSLIP);
		RevenueAccount revenueAccount = (RevenueAccount) getSession().get(RevenueAccount.class, saleItem.getRevenueAccount().getId());
		saleItem2.setRevenueAccount(revenueAccount);
		saleItemBankslip.setRevenueAccount(revenueAccount);
		saveAndFlush(saleItem2);
		saveAndFlush(saleItemBankslip);

		Account accountAvailable = accountService.fetchOrCreateAccount(AccountType.AVAILABLE, saleTestFixture.chicoBento, saleTestFixture.productIntactaSoy.getCrop(), saleTestFixture.productIntactaSoy.getTechnology(), systemTestFixture.operationalYearOf2012);
		Assert.assertEquals("Should have balance of 7575", new BigDecimal(7575), accountAvailable.getBalance());

		accountService.manageManualCredit(ManualCreditTransactionType.DEBIT, BigDecimal.TEN, saleTestFixture.chicoBento, saleTestFixture.productIntactaSoy.getCrop(), saleTestFixture.productIntactaSoy.getTechnology(), systemTestFixture.operationalYearOf2012, 1L);

		try {
			revenueService.reversal(billableProvider, revenueAccount, "code", "reason", "vrodrigues", cancellation);
			Assert.fail("Should have thrown exception");
		} catch (BillingCancellationWarningException e) {
			ConstraintViolation violation = e.getViolations().get(0);
			Assert.assertEquals("Should have insufficient balance error", ErrorCode.INSUFFICIENT_BALANCE, violation.getCode());
			Assert.assertEquals("Balance expected", new BigDecimal(7565), (BigDecimal) violation.getInnerViolation().getPlaces().get(0));
		}
	}

	@Test
	public void given_a_paid_bankslip_when_reversal_should_throw_exception() throws BusinessException {
		SaleItem saleItem = createSaleForParticipant(SaleTemplateBillingMethodEnum.BANKSLIP);
		RevenueAccount revenueAccount = new RevenueAccount(saleTestFixture.matrixCargil, "111", saleItem.getSaleTemplate().getHarvest().getOperationalYear(), RevenueType.DISTRIBUTION, systemTestFixture.monsantoBr, new Date(), new Date());
		RevenueHandle handle = new RevenueHandle(saleItem.getId());
		revenueAccount.addHandle(handle);
		saleItem.setRevenueAccount(revenueAccount);
		saveAndFlush(revenueAccount);

		List<Billing> billings = saleService.getBillingBy(BillingFilter.getInstance().add(PaymentStatus.NOT_PAID));
		Assert.assertEquals("Should have one not paid billing", 1, billings.size());
		saleService.payBilling(billings.get(0), new Date(), BigDecimal.TEN, true);

		try {
			revenueService.reversal(billableProvider, revenueAccount, "code", "reason", "vrodrigues", cancellation);
			Assert.fail("Should have thrown exception");
		} catch (BillingCancellationWarningException e) {
			Assert.assertEquals("Should have expected error code", e.getViolations().get(0).getCode(), "InvalidCancellation");
		}
	}

	@Test
	public void given_a_notPaid_bankslip_and_one_billed_sale_when_reversal_should_reversalSuccessfull() throws BusinessException, InfraException {
		SaleItem saleItem = createAndSaveBilledSale();
		SaleItem saleItemBankslip = createSaleForParticipant(SaleTemplateBillingMethodEnum.BANKSLIP);
		RevenueAccount revenueAccount = (RevenueAccount) getSession().get(RevenueAccount.class, saleItem.getRevenueAccount().getId());
		saleItemBankslip.setRevenueAccount(revenueAccount);

		revenueService.reversal(billableProvider, revenueAccount, "code", "reason", "vrodrigues", cancellation);

		List<Billing> billings = saleService.getBillingBy(BillingFilter.getInstance().add(PaymentStatus.CANCELLED));

		Assert.assertEquals("RevenueAccount should be reversed", RevenueStatus.REVERSED, revenueAccount.getStatus());
		Assert.assertEquals("Should have 2 cancelled billings", 2, billings.size());
	}

	@Test(expected=RevenueProblemSummaryException.class)
	public void given_a_sale_to_an_invalid_contract_should_throw_revenue_problems_exception() throws BusinessException, InfraException {
	    createAndSaveBilledSale(saleTestFixture.headOfficeCargil,saleTestFixture.matrixCargil,saleTestFixture.contractCargil,true, false);

	}

	@Test(expected=RevenueProblemSummaryException.class)
	public void given_a_sale_to_invalid_product_should_throw_revenue_problems_exception() throws BusinessException, InfraException{
	    createAndSaveBilledSale(saleTestFixture.headOfficeCargil,saleTestFixture.matrixCargil,saleTestFixture.contractCargil,true, true);
	}

	@Test
	public void given_a_sale_for_multiple_headoffices_with_one_invalid_contract_should_throw_exception() throws BusinessException, InfraException{
		createSaleForParticipant(SaleTemplateBillingMethodEnum.ERP, saleTestFixture.headOfficeCargil, saleTestFixture.matrixCargil, saleTestFixture.contractCargil, false, true,true, 999999998l);
		createSaleForParticipant(SaleTemplateBillingMethodEnum.ERP, saleTestFixture.agroSojaMatrix, saleTestFixture.agroSoja, saleTestFixture.agroSojaContract, false, false,true, 999999997l);
		createBadContract(saleTestFixture.agroSojaMatrix);
		try {
			bill(false, false, 2);
		} catch(RevenueProblemSummaryException e) {
		    Assert.assertEquals("Should have 1 exception", 1, e.getExceptionList().size());
		}
	}

		@Test
	public void given_several_sales_when_I_bill_should_produce_correct_number_of_revenue_handles() throws BusinessException, InfraException {
		SaleItem createSaleForParticipant = createSaleForParticipant(SaleTemplateBillingMethodEnum.ERP, saleTestFixture.headOfficeCargil, saleTestFixture.matrixCargil, saleTestFixture.contractCargil, false, true,true,999999998l);
		createSaleForParticipant(SaleTemplateBillingMethodEnum.ERP, saleTestFixture.headOfficeCargil, saleTestFixture.matrixCargil, saleTestFixture.contractCargil, false, false,false,999999998l);
		createSaleForParticipant(SaleTemplateBillingMethodEnum.ERP, saleTestFixture.headOfficeCargil, saleTestFixture.matrixCargil, saleTestFixture.contractCargil, false, false,false,999999998l);
		createSaleForParticipant(SaleTemplateBillingMethodEnum.ERP, saleTestFixture.headOfficeCargil, saleTestFixture.matrixCargil, saleTestFixture.contractCargil, false, false,false,999999998l);
		revenueManager.bill(billableProvider, systemTestFixture.monsantoBr);
		RevenueAccount object = (RevenueAccount) getSession().get(RevenueAccount.class, createSaleForParticipant.getRevenueAccount().getId());
		Long revenueAccountId=object.getId();

		Assert.assertEquals("Should have 4 handles", 4, object.getHandles().size());
		Long handleId = object.getHandles().get(0).getHandle();

		getSession().evict(object);
		object = revenueAccountDAO.selectRevenueAccountByTypeAndHandleId(RevenueType.DISTRIBUTION, handleId);
		Assert.assertEquals("Should have same id", revenueAccountId, object.getId());

	}

	private SaleItem createAndSaveBilledSale() throws BusinessException, InfraException {
	    return createAndSaveBilledSale(saleTestFixture.headOfficeCargil,saleTestFixture.matrixCargil, saleTestFixture.contractCargil,false, false);
	}

	private SaleItem createAndSaveBilledSale(HeadOffice headOffice, Customer customer, Contract contract, boolean badContract, boolean badProduct) throws BusinessException, InfraException {
		SaleItem saleItemByPlantability = createSaleForParticipant(SaleTemplateBillingMethodEnum.ERP, headOffice, customer, contract, false, true, true,999999998l);

		if(badContract) {
		    createBadContract(headOffice);
		}
		bill(badContract, badProduct, 1);

		return saleItemByPlantability;
	}


    private void bill(boolean badContract, boolean badProduct, int numBillables) throws BusinessException, InfraException {
        List<Billable> billables = billableProvider.getBillables(systemTestFixture.monsantoBr);
		Assert.assertNotNull("Billable not null", billables);
		Assert.assertEquals("Billable with " + numBillables + " item", numBillables, billables.size());

		if(badProduct) {
			Product product = (Product) getSession().get(Product.class,saleTestFixture.productIntactaSoy.getId());
			product.setProductSapCode("1111");
			saveAndFlush(product);
		}

		revenueManager.bill(billableProvider, systemTestFixture.monsantoBr);
		getSession().flush();
    }

	private SaleItem createSaleForParticipant(SaleTemplateBillingMethodEnum billingMethod) throws BusinessException {
	    return createSaleForParticipant(billingMethod, saleTestFixture.headOfficeCargil, saleTestFixture.matrixCargil, saleTestFixture.contractCargil, false, true,true,999999998l);
	}


	private SaleItem createSaleForParticipant(SaleTemplateBillingMethodEnum billingMethod, HeadOffice headOffice, Customer customer, Contract contract, boolean badContract, boolean initTemplate, boolean initMaterialContract, Long id) throws BusinessException {
		Sale sale = SaleTestData.createSale(customer, saleTestFixture.chicoBento, SaleTypeEnum.SALE_SEED);
		sale.setState(systemTestFixture.matoGrossoDoSul);
		SaleTemplate saletemplate = saleTestFixture.templateIntactaByPlantabilityRRByExpirationBtFree;
		Product productIntactaSoy = saleTestFixture.productIntactaSoy;
		if(initTemplate) {
			saletemplate.setBillingMethod(billingMethod);
			saveAndFlush(saletemplate);


			productIntactaSoy.setProductSapCode("000000000099999999");
			saveAndFlush(productIntactaSoy);

			RetributionFee fee = new RetributionFee();
			fee.setMarketingProgramEnabled(true);
			fee.setMarketingProgramSourceType(RetributionSourceType.ITS);
			fee.setMarketingProgram(BigDecimal.TEN);
			fee.setRetributionFeeEnabled(true);
			fee.setRetributionFeeSourceType(RetributionSourceType.ITS);
			fee.setRetributionFee(BigDecimal.TEN);

			saletemplate.getPriceOf(productIntactaSoy.getTechnology()).setRetributionFee(fee);
			saletemplate.getPriceOf(productIntactaSoy.getTechnology()).setReleaseCreditType(ReleaseCreditTypeEnum.AUTOMATICALLY);

			saveAndFlush(saletemplate);
		}

		SaleItem saleItemByPlantability = saleItemFactory.createByPlantabilityDueDateRangeItem(
				productIntactaSoy,
				saletemplate,
				headOffice,
				5l,
				SaleTestFixture.NOVEMBER,
				saleTestFixture.plantability45To54SoyMonsanto2012);

		if(initMaterialContract) {
		createMaterials(saleItemByPlantability.getProduct().getProductSapCode(), headOffice, badContract, id);
		}
		sale.addItem(saleItemByPlantability);
		saveAValidSaleForAParticipant(sale, customer, contract, initMaterialContract);
		return saleItemByPlantability;
	}

	private List<Sale> createManySalesForParticipant(SaleTemplateBillingMethodEnum billingMethod, HeadOffice headOffice, Customer customer, Contract contract) throws BusinessException {

		RetributionFee fee = new RetributionFee();
		fee.setMarketingProgramEnabled(true);
		fee.setMarketingProgramSourceType(RetributionSourceType.ITS);
		fee.setMarketingProgram(BigDecimal.TEN);
		fee.setRetributionFeeEnabled(true);
		fee.setRetributionFeeSourceType(RetributionSourceType.ITS);
		fee.setRetributionFee(BigDecimal.TEN);

		Product productIntactaSoy = saleTestFixture.productIntactaSoy;
		productIntactaSoy.setProductSapCode("100000000099999999");
		saveAndFlush(productIntactaSoy);

		createMaterials(productIntactaSoy.getProductSapCode(), headOffice, false, 111111111l);

		List<Sale> sales = new ArrayList<Sale>();

		SaleTemplate saletemplate1 = saleTestFixture.templateIntactaByPlantabilityRRByExpirationBtFree;
		saletemplate1.setBillingMethod(billingMethod);
		saletemplate1.getPriceOf(productIntactaSoy.getTechnology()).setRetributionFee(fee);
		saletemplate1.getPriceOf(productIntactaSoy.getTechnology()).setReleaseCreditType(ReleaseCreditTypeEnum.AUTOMATICALLY);
		saveAndFlush(saletemplate1);
		Sale sale1 = SaleTestData.createSale(saleTestFixture.matrixCargil, saleTestFixture.chicoBento, SaleTypeEnum.SALE_SEED);
		sale1.setState(systemTestFixture.matoGrossoDoSul);
		SaleItem saleItem1 = saleItemFactory.createByPlantabilityDueDateRangeItem(
				productIntactaSoy,
				saletemplate1,
				headOffice,
				5l,
				SaleTestFixture.NOVEMBER,
				saleTestFixture.plantability45To54SoyMonsanto2012);
		sale1.addItem(saleItem1);
		saveAValidSaleForAParticipant(sale1, customer, contract, true);
		sales.add(sale1);

		SaleTemplate saletemplate2 = saleTestFixture.templateIntactaFixRRRangeBtNoValue;
		saletemplate2.setBillingMethod(billingMethod);
		saletemplate2.getPriceOf(productIntactaSoy.getTechnology()).setRetributionFee(fee);
		saletemplate2.getPriceOf(productIntactaSoy.getTechnology()).setReleaseCreditType(ReleaseCreditTypeEnum.AUTOMATICALLY);
		saveAndFlush(saletemplate2);
		Sale sale2 = SaleTestData.createSale(saleTestFixture.matrixCargil, saleTestFixture.chicoBento, SaleTypeEnum.SALE_SEED);
		sale2.setState(systemTestFixture.matoGrossoDoSul);
		SaleItem saleItem2 = saleItemFactory.createFixValueItem(
				productIntactaSoy,
				saletemplate2,
				headOffice,
				5l);
		sale2.addItem(saleItem2);
		saveAValidSaleForAParticipant(sale2, customer, contract, true);
		sales.add(sale2);

		return sales;
	}

	@Test
	public void when_i_show_detailed_revenue_should_return_extract() throws BusinessException, InfraException{
		SaleItem i = createAndSaveBilledSale();

		if (!getAssumptionTest().isEnvironmentWithSQLANSI()) {
			List<RevenueAccount> accounts = new ArrayList<RevenueAccount>();
			accounts.add(i.getRevenueAccount());
			createRevenueDetailedExtract(accounts, i.getSale());
		}

		lazyBuilder.add(i.getRevenueAccount().getOrderNumber());

		List<RevenueDetailedExtractView> revenueExtract = lazyBuilder.getQueryList(0, 10);

		Assert.assertTrue("Could not empty", !revenueExtract.isEmpty());
		assertRevenueDetaleidExtract(revenueExtract, i.getSale(), i.getRevenueAccount());

	}

	private void assertRevenueDetaleidExtract(List<RevenueDetailedExtractView> revenueExtract, Sale sale, RevenueAccount revenueAccount){
		for (RevenueDetailedExtractView dto : revenueExtract) {
			Assert.assertEquals("Expected bonus null", null, dto.getBonusValue());
			Assert.assertEquals("Expected grower document", sale.getGrower().getDocument().getValueFormatted(), dto.getGrowerDocument());
			Assert.assertEquals("Expected grower document mask", sale.getGrower().getDocument().getDocumentType().getMask(), dto.getGrowerDocumentMask());
			Assert.assertEquals("Expected grower name", sale.getGrower().getName(), dto.getGrowerName());
			Assert.assertEquals("Expected invoice number", sale.getInvoiceNumber(), dto.getInvoiceNumber());
			Assert.assertEquals("Expected order number", revenueAccount.getOrderNumber(), dto.getOrderNumber());
			Assert.assertEquals("Expected customer document", sale.getCustomer().getDocument().getValueFormatted(), dto.getPartnerDocument());
			Assert.assertEquals("Expected customer document mask", sale.getCustomer().getDocument().getDocumentType().getMask(), dto.getPartnerDocumentMask());
			Assert.assertEquals("Expected customer name", sale.getCustomer().getName(), dto.getPartnerName());
			Assert.assertEquals("Expected payment value", getSumPaymentValue(sale), dto.getPaymentValue());
			Assert.assertEquals("Expected payment date", getMorePaymentDate(sale), dto.getPaymentDate());
			Assert.assertEquals("Expected retribution value", getSumRetributionValue(sale), dto.getRetributionValue());
		}

	}

	private void createRevenueDetailedExtract(List<RevenueAccount> revenue, Sale sale){
		for (RevenueAccount revenueAccount : revenue) {
			RevenueDetailedExtractView extract = new RevenueDetailedExtractView();
			extract.setBonusValue(null);
			extract.setGrowerDocument(sale.getGrowerDocument());
			extract.setGrowerDocumentMask(sale.getGrower().getDocument().getDocumentType().getMask());
			extract.setGrowerName(sale.getGrower().getName());
			extract.setInvoiceNumber(sale.getInvoiceNumber());
			extract.setOrderNumber(revenueAccount.getOrderNumber());
			extract.setPartnerDocument(sale.getCustomerDocument());
			extract.setPartnerDocumentMask(sale.getCustomer().getDocument().getDocumentType().getMask());
			extract.setPartnerName(sale.getCustomer().getName());
			extract.setPaymentValue(getSumPaymentValue(sale));
			extract.setPaymentDate(getMorePaymentDate(sale));
			extract.setRetributionValue(getSumRetributionValue(sale));
			extract.setSaleId(sale.getId());

			saveAndFlush(extract);
		}
	}

	private BigDecimal getSumRetributionValue(Sale sale){
		BigDecimal retribution = new BigDecimal(0);
		for(SaleItem i : sale.getItems()){
			retribution = retribution.add(i.getRetributionFeeValue());
		}
		return retribution;
	}

	private Date getMorePaymentDate(Sale sale){
		Date paymentDate = null;
		for(SaleItem i : sale.getItems()){
			for (PossiblePayment payment : i.getBilling().getPayments()){
				if (paymentDate == null){
					paymentDate = payment.getReceiptDate();
				}else if (paymentDate.compareTo(payment.getReceiptDate()) < 0){
					paymentDate = payment.getReceiptDate();
				}
			}
		}
		return paymentDate;
	}

	private BigDecimal getSumPaymentValue(Sale sale){
		BigDecimal paymentValue = new BigDecimal(0);
		for(SaleItem i : sale.getItems()){
			BigDecimal value = new BigDecimal(0);
			for (PossiblePayment payment : i.getBilling().getPayments()){
				if (payment.getReceiptValue().compareTo(value) > 0){
					value = payment.getReceiptValue();
				}
			}
			paymentValue = paymentValue.add(value);
		}
		return paymentValue;
	}


	@Test
	public void given_revenueAccount_billed_when_updatePayment_should_succeed() throws BusinessException {
		RevenueAccount revenueAccount = new RevenueAccount(saleTestFixture.matrixCargil, "111", systemTestFixture.operationalYearOf2009, RevenueType.DISTRIBUTION, systemTestFixture.monsantoBr, new Date(), new Date());
		saveAndFlush(revenueAccount);
		revenueAccount.addHandle(new RevenueHandle(1L));

		revenueService.updatePayment(revenueAccount, billableProvider, "0101122112", new Date());

		Assert.assertEquals("Should be in status paid", RevenueStatus.PAID, revenueAccount.getStatus());
	}


	@Test
    @Ignore
	public void given_a_billed_sale_when_updatePayment_should_pay_sale_and_pay_revenue() throws BusinessException, InfraException {
		SaleItem saleItem = createAndSaveBilledSale();

		List<Billing> billings = saleService.getBillingBy(BillingFilter.getInstance().add(PaymentStatus.BILLED));
		Assert.assertEquals("Should have one billed billing", 1, billings.size());
		getSession().flush();

		RevenueAccount revenueAccount = (RevenueAccount) getSession().get(RevenueAccount.class, saleItem.getRevenueAccount().getId());

		ChargeConsolidateFilter filter = new ChargeConsolidateFilter();
		filter.setCompany(saleItem.getCompany());
		filter.setCrop(saleItem.getCrop());
		filter.setHarvest(saleItem.getHarvestDescription());
		filter.setMatrix(saleItem.getCustomerParent());

		List<ChargeConsolidate> chargeConsolidateList = chargeConsolidateService.findCreditConsumptionChargeConsolidate(filter);
		Assert.assertEquals("Should not have ChargeConsolidate", 0, chargeConsolidateList.size());

		revenueService.updatePayment(revenueAccount, billableProvider, "0101122112", new Date());

		List<Billing> paidBillings = saleService.getBillingBy(BillingFilter.getInstance().add(PaymentStatus.FULLY_PAID));
		Assert.assertEquals("Should have one paid billing", 1, paidBillings.size());

		chargeConsolidateList = chargeConsolidateService.findCreditConsumptionChargeConsolidate(filter);
		Assert.assertEquals("Should have only one ChargeConsolidate", 1, chargeConsolidateList.size());

		Assert.assertEquals("Revenue account status should be paid", RevenueStatus.PAID, revenueAccount.getStatus());
	}


	@Test
	public void given_a_manuallyPaid_billed_sale_when_pay_revenue_should_succeed() throws BusinessException, InfraException {
		SaleItem saleItem = createAndSaveBilledSale();

		List<Billing> billings = saleService.getBillingBy(BillingFilter.getInstance().add(PaymentStatus.BILLED));
		Assert.assertEquals("Should have one billed billing", 1, billings.size());
		saleService.payBilling(billings.get(0), new Date(), BigDecimal.TEN, true);
		getSession().flush();

		ChargeConsolidateFilter filter = new ChargeConsolidateFilter();
		filter.setCompany(saleItem.getCompany());
		filter.setCrop(saleItem.getCrop());
		filter.setHarvest(saleItem.getHarvestDescription());
		filter.setMatrix(saleItem.getCustomerParent());

		List<ChargeConsolidate> chargeConsolidateList = chargeConsolidateService.findCreditConsumptionChargeConsolidate(filter);
		Assert.assertEquals("Should have only one ChargeConsolidate", 1, chargeConsolidateList.size());

		List<Billing> paidBillings = saleService.getBillingBy(BillingFilter.getInstance().add(PaymentStatus.FULLY_PAID));
		Assert.assertEquals("Should have one paid billing", 1, paidBillings.size());

		RevenueAccount revenueAccount = (RevenueAccount) getSession().get(RevenueAccount.class, saleItem.getRevenueAccount().getId());

		revenueService.updatePayment(revenueAccount, billableProvider, "0101122112", new Date());


		Assert.assertEquals("Revenue account status should be paid", RevenueStatus.PAID, revenueAccount.getStatus());
	}


	@Test
    @Ignore
	public void given_manySales_when_payment_should_paymentSuccessfull() throws BusinessException, InfraException {

		createManySalesForParticipant(SaleTemplateBillingMethodEnum.ERP, saleTestFixture.headOfficeCargil, saleTestFixture.matrixCargil, saleTestFixture.contractCargil);

		bill(false, false, 2);

		List<Billing> billings = saleService.getBillingBy(BillingFilter.getInstance().add(PaymentStatus.BILLED));
		Assert.assertEquals("Should have two billed billing", 2, billings.size());

		SaleItem saleItem = billings.get(0).getItems().iterator().next();

		ChargeConsolidateFilter filter = new ChargeConsolidateFilter();
		filter.setMatrix(saleTestFixture.headOfficeCargil.getCustomer());

		List<ChargeConsolidate> chargeConsolidateList = chargeConsolidateService.findCreditConsumptionChargeConsolidate(filter);
		Assert.assertEquals("Should not have ChargeConsolidate", 0, chargeConsolidateList.size());

		RevenueAccount revenueAccount = (RevenueAccount) getSession().get(RevenueAccount.class, saleItem.getRevenueAccount().getId());

		revenueService.updatePayment(revenueAccount, billableProvider, "0101122112", new Date());

		chargeConsolidateList = chargeConsolidateService.findCreditConsumptionChargeConsolidate(filter);
		Assert.assertEquals("Should have only one ChargeConsolidate", 1, chargeConsolidateList.size());

		List<Billing> paidBillings = saleService.getBillingBy(BillingFilter.getInstance().add(PaymentStatus.FULLY_PAID));
		Assert.assertEquals("Should have two paid billing", 2, paidBillings.size());

		Assert.assertEquals("Should be in status paid", RevenueStatus.PAID, revenueAccount.getStatus());

	}


	@Test
	public void given_manySales_with_manuallyPaid_when_payment_should_paymentSuccessfull() throws BusinessException, InfraException {

		createManySalesForParticipant(SaleTemplateBillingMethodEnum.ERP, saleTestFixture.headOfficeCargil, saleTestFixture.matrixCargil, saleTestFixture.contractCargil);

		bill(false, false, 2);

		List<Billing> billings = saleService.getBillingBy(BillingFilter.getInstance().add(PaymentStatus.BILLED));
		Assert.assertEquals("Should have two billed billing", 2, billings.size());

		SaleItem saleItem = billings.get(0).getItems().iterator().next();

		saleService.payBilling(billings.get(0), new Date(), BigDecimal.TEN, true);
		getSession().flush();

		List<Billing> paidBillings = saleService.getBillingBy(BillingFilter.getInstance().add(PaymentStatus.FULLY_PAID));
		Assert.assertEquals("Should have two paid billing", 1, paidBillings.size());

		RevenueAccount revenueAccount = (RevenueAccount) getSession().get(RevenueAccount.class, saleItem.getRevenueAccount().getId());

		revenueService.updatePayment(revenueAccount, billableProvider, "0101122112", new Date());

		paidBillings = saleService.getBillingBy(BillingFilter.getInstance().add(PaymentStatus.FULLY_PAID));
		Assert.assertEquals("Should have two paid billing", 2, paidBillings.size());

		Assert.assertEquals("Should be in status paid", RevenueStatus.PAID, revenueAccount.getStatus());

	}
                    */

}
