package com.monsanto.brazilvaluecapture.seedsale.extract;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.monsanto.brazilvaluecapture.core.foundation.service.IndustrySystemOperationException;
import junit.framework.Assert;

import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.monsanto.brazilvaluecapture.core.account.model.bean.Account;
import com.monsanto.brazilvaluecapture.core.account.model.bean.Account.AccountType;
import com.monsanto.brazilvaluecapture.core.account.model.bean.CreditExpiration;
import com.monsanto.brazilvaluecapture.core.account.model.bean.CreditTransferRequest;
import com.monsanto.brazilvaluecapture.core.account.model.bean.CreditTransferRequestAmount;
import com.monsanto.brazilvaluecapture.core.account.model.bean.Entry;
import com.monsanto.brazilvaluecapture.core.account.model.bean.ManualCreditTransactionType;
import com.monsanto.brazilvaluecapture.core.account.model.bean.TransactionType;
import com.monsanto.brazilvaluecapture.core.account.service.impl.AccountService;
import com.monsanto.brazilvaluecapture.core.base.SystemTestFixture;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Crop;
import com.monsanto.brazilvaluecapture.core.base.model.bean.OperationalYear;
import com.monsanto.brazilvaluecapture.core.base.service.ConstraintException;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Technology;
import com.monsanto.brazilvaluecapture.core.foundation.model.bean.TransferAccount;
import com.monsanto.brazilvaluecapture.core.foundation.service.BusinessException;
import com.monsanto.brazilvaluecapture.core.foundation.service.TransactionControlService;
import com.monsanto.brazilvaluecapture.core.foundation.test.AbstractServiceIntegrationTests;
import com.monsanto.brazilvaluecapture.core.grower.model.bean.Grower;
import com.monsanto.brazilvaluecapture.core.user.AccessControlTestFixture;
import com.monsanto.brazilvaluecapture.core.user.service.ManualCreditConstraintException;
import com.monsanto.brazilvaluecapture.seedsale.billing.model.bean.Billing;
import com.monsanto.brazilvaluecapture.seedsale.billing.model.bean.BillingDTO;
import com.monsanto.brazilvaluecapture.seedsale.billing.model.bean.PaymentStatus;
import com.monsanto.brazilvaluecapture.seedsale.billing.model.dao.BillingFilter;
import com.monsanto.brazilvaluecapture.seedsale.billing.service.BillingConstraintViolationException;
import com.monsanto.brazilvaluecapture.seedsale.extract.credit.model.bean.CreditExtractBuilder;
import com.monsanto.brazilvaluecapture.seedsale.extract.credit.model.bean.SummaryCreditExtract;
import com.monsanto.brazilvaluecapture.seedsale.extract.credit.model.bean.amount.CreditTransactionBalance;
import com.monsanto.brazilvaluecapture.seedsale.extract.credit.model.bean.amount.ICreditAmount;
import com.monsanto.brazilvaluecapture.seedsale.extract.credit.model.bean.amount.ReservedCreditAmount;
import com.monsanto.brazilvaluecapture.seedsale.extract.credit.model.bean.amount.TransferDonatedCreditAmount;
import com.monsanto.brazilvaluecapture.seedsale.extract.credit.model.bean.detail.DetailManualCreditAmount;
import com.monsanto.brazilvaluecapture.seedsale.extract.credit.model.bean.detail.DetailTransferCreditAmount;
import com.monsanto.brazilvaluecapture.seedsale.extract.credit.model.bean.detail.DetailedBlockedAndAvaliableCreditAmount;
import com.monsanto.brazilvaluecapture.seedsale.sale.SaleTestFixture;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.Sale;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.SaleItem;
import com.monsanto.brazilvaluecapture.seedsale.sale.service.SaleBuilder;
import com.monsanto.brazilvaluecapture.seedsale.sale.service.SaleConstraintViolationException;
import com.monsanto.brazilvaluecapture.seedsale.sale.service.SaleService;
import com.monsanto.brazilvaluecapture.seedsale.sale.service.impl.AccountManager;
import com.monsanto.brazilvaluecapture.seedsale.template.model.bean.Price.ReleaseCreditTypeEnum;
import com.monsanto.brazilvaluecapture.seedsale.template.model.bean.SaleTemplate;

public class DetailCredit_AT extends AbstractServiceIntegrationTests {

    @Autowired
    private AccountService accountService;

    @Autowired
    private SaleService saleService;

    private SaleBuilder builder;

    @Autowired
    private AccountManager manager;
    
    @Autowired
	@Qualifier("currentTransactionControlImplementation")
    private TransactionControlService transactionControlService;
    
    @Before
    public void setup() {
        systemTestFixture = new SystemTestFixture(this);
        saleTestFixture = new SaleTestFixture(this, systemTestFixture);
        accessControlTestFixture = new AccessControlTestFixture(systemTestFixture);
        
        createChargeConsolidateTypes();
    }

    @Test
    public void given_aAccounts_show_credit_details() throws ConstraintException {
        achieveSale(systemTestFixture.operationalYearOf2012, systemTestFixture.intacta, 1l);
        achieveSale(systemTestFixture.operationalYearOf2012, systemTestFixture.rr, 3l);

        achieveSale(systemTestFixture.operationalYearOf2011, systemTestFixture.intacta, 2l);
        achievePayment(systemTestFixture.operationalYearOf2012, systemTestFixture.intacta);
        achieveManualCredit(systemTestFixture.operationalYearOf2012, systemTestFixture.intacta, 1l);
        achieveManualCredit(systemTestFixture.operationalYearOf2012, systemTestFixture.rr, 2l);

        achieveDueAvailable(systemTestFixture.operationalYearOf2012, systemTestFixture.intacta);
        achieveExtension(systemTestFixture.operationalYearOf2012, systemTestFixture.intacta);

        List<SummaryCreditExtract> creditExtracts = saleService.getCreditExtract(saleTestFixture.chicoBento,
                systemTestFixture.soy, systemTestFixture.monsantoBr);

        for (SummaryCreditExtract summaryCreditExtract : creditExtracts) {
            System.out.println("++OperationalYear " + summaryCreditExtract.getOperationalYear().getYear()
                    + "| Balance Total Blocked $" + summaryCreditExtract.getTotalBlockedAmount().getValue()
                    + "| Balance Total Available $" + summaryCreditExtract.getTotalReleasedAmount().getValue()
                    + "| Balance Total Manual $" + summaryCreditExtract.getTotalManualReceivedAmount().getValue()
                    + "| Balance Total Extension $" + summaryCreditExtract.getTotalExtendedAmount().getValue()
                    + "| Balance Total Transfer $" + summaryCreditExtract.getTotalTransferReceivedAmount().getValue());
            for (CreditTransactionBalance transactionBalance : summaryCreditExtract.getDetails()) {
                System.out.println("++++Technology: " + transactionBalance.getTechnology().getDescription() + " Crop :"
                        + transactionBalance.getCrop().getDescription() + "| Balance Blocked $"
                        + transactionBalance.getBlockedCreditAmount().getValue() + "| Balance Available $"
                        + transactionBalance.getReleasedCreditAmount().getValue() + "| Balance Manual $"
                        + transactionBalance.getManualCreditAmount().getValue() + "| Balance Extension $"
                        + transactionBalance.getExtendedCreditAmount().getValue() + "| Balance Transfer $"
                        + transactionBalance.getTransferReceiveCreditAmount().getValue());
            }

        }

        Account accountAvailable = accountService.fetchOrCreateAccount(AccountType.AVAILABLE, saleTestFixture.chicoBento,
                systemTestFixture.soy, systemTestFixture.intacta, systemTestFixture.operationalYearOf2012);
        Account accountExAccount = accountService.fetchOrCreateAccount(AccountType.EXTENDED, saleTestFixture.chicoBento,
                systemTestFixture.soy, systemTestFixture.intacta, systemTestFixture.operationalYearOf2012);

        BigDecimal balance = accountAvailable.getBalance().add(accountExAccount.getBalance());

        Assert.assertEquals("Should have operationalYear ", systemTestFixture.operationalYearOf2012, creditExtracts
                .get(0).getOperationalYear());
        Assert.assertEquals("Should have operationalYear Total blocked ", BigDecimal.TEN, creditExtracts.get(0)
                .getTotalBlockedAmount().getValue());
        Assert.assertEquals("Should have operationalYear total Released ", BigDecimal.TEN, creditExtracts.get(0)
                .getTotalReleasedAmount().getValue());
        Assert.assertEquals("Should have operationalYear total Manual ", new BigDecimal(2), creditExtracts.get(0)
                .getTotalManualReceivedAmount().getValue());
        Assert.assertEquals("Should have operationalYear total Extention ", BigDecimal.TEN, creditExtracts.get(0)
                .getTotalExtendedAmount().getValue());
        Assert.assertEquals("Should have operationalYear total ", new BigDecimal(12), creditExtracts.get(0)
                .getTotalAvailable());
        // ROW ONE
        Assert.assertEquals("Should have details blocked intacta", BigDecimal.ZERO, creditExtracts.get(0).getDetails()
                .get(0).getBlockedCreditAmount().getValue());
        Assert.assertEquals("Should have details released intacta", BigDecimal.TEN, creditExtracts.get(0).getDetails()
                .get(0).getReleasedCreditAmount().getValue());
        Assert.assertEquals("Should have details manual intacta", BigDecimal.ONE, creditExtracts.get(0).getDetails()
                .get(0).getManualCreditAmount().getValue());
        Assert.assertEquals("Should have details extended intacta", BigDecimal.TEN, creditExtracts.get(0).getDetails()
                .get(0).getExtendedCreditAmount().getValue());
        Assert.assertEquals("Should have details available intacta", balance, creditExtracts.get(0).getDetails().get(0)
                .getTotalAvailable());
        // ROW TWO
        Assert.assertEquals("Should have details blocked rr", BigDecimal.TEN, creditExtracts.get(0).getDetails().get(1)
                .getBlockedCreditAmount().getValue());
        Assert.assertEquals("Should have details released rr", BigDecimal.ZERO,
                creditExtracts.get(0).getDetails().get(1).getReleasedCreditAmount().getValue());
        Assert.assertEquals("Should have details manual rr", BigDecimal.ONE, creditExtracts.get(0).getDetails().get(1)
                .getManualCreditAmount().getValue());
        Assert.assertEquals("Should have details extended rr", BigDecimal.ZERO,
                creditExtracts.get(0).getDetails().get(1).getExtendedCreditAmount().getValue());
        Assert.assertEquals("Should have details available intacta", BigDecimal.ONE, creditExtracts.get(0).getDetails()
                .get(1).getTotalAvailable());

        Assert.assertEquals("Should have operationalYear ", systemTestFixture.operationalYearOf2011, creditExtracts
                .get(1).getOperationalYear());
        Assert.assertEquals("Should have operationalYear Total blocked ", BigDecimal.TEN, creditExtracts.get(1)
                .getTotalBlockedAmount().getValue());
        Assert.assertEquals("Should have operationalYear total released ", BigDecimal.ZERO, creditExtracts.get(1)
                .getTotalReleasedAmount().getValue());
        Assert.assertEquals("Should have operationalYear total Manual ", BigDecimal.ZERO, creditExtracts.get(1)
                .getTotalManualReceivedAmount().getValue());
        Assert.assertEquals("Should have operationalYear total Extention ", BigDecimal.ZERO, creditExtracts.get(1)
                .getTotalExtendedAmount().getValue());
        // ROW ONE
        Assert.assertEquals("Should have details blocked intacta", BigDecimal.TEN, creditExtracts.get(1).getDetails()
                .get(0).getBlockedCreditAmount().getValue());
        Assert.assertEquals("Should have details released intacta", BigDecimal.ZERO, creditExtracts.get(1).getDetails()
                .get(0).getReleasedCreditAmount().getValue());
        Assert.assertEquals("Should have details manual intacta", BigDecimal.ZERO, creditExtracts.get(1).getDetails()
                .get(0).getManualCreditAmount().getValue());
        Assert.assertEquals("Should have details extended intacta", BigDecimal.ZERO, creditExtracts.get(1).getDetails()
                .get(0).getExtendedCreditAmount().getValue());

    }

    @Test
    public void given_transactions_realized_in_accounts_of_grower_show_available_credit_with_transfer_approve() throws ConstraintException {
        // Operations realized in accounts for available credits
        achieveSale(systemTestFixture.operationalYearOf2012, systemTestFixture.intacta, 1l);
        achievePayment(systemTestFixture.operationalYearOf2012, systemTestFixture.intacta);

        // Operations of transfer approved
        achieveTransferReserve(systemTestFixture.operationalYearOf2012, systemTestFixture.intacta);
        achieveTransfer(systemTestFixture.operationalYearOf2012, systemTestFixture.intacta, saleTestFixture.joaoDaSilva);

        // Build credits amount
        List<SummaryCreditExtract> creditExtracts = saleService.getCreditExtract(saleTestFixture.chicoBento,
                systemTestFixture.soy, systemTestFixture.monsantoBr);

        printExtractDetails(creditExtracts);

        BigDecimal ten = BigDecimal.TEN;

        Assert.assertEquals("Should have operationalYear ", systemTestFixture.operationalYearOf2012, creditExtracts
                .get(0).getOperationalYear());
        Assert.assertEquals("Should have operationalYear Total blocked ", BigDecimal.ZERO, creditExtracts.get(0)
                .getTotalBlockedAmount().getValue());
        Assert.assertEquals("Should have operationalYear total Available ", ten, creditExtracts.get(0)
                .getTotalReleasedAmount().getValue());
        Assert.assertEquals("Should have operationalYear total Manual ", BigDecimal.ZERO, creditExtracts.get(0)
                .getTotalManualReceivedAmount().getValue());
        Assert.assertEquals("Should have operationalYear total Extention ", BigDecimal.ZERO, creditExtracts.get(0)
                .getTotalExtendedAmount().getValue());
        Assert.assertEquals("Should have operationalYear total Transfer Receive ", BigDecimal.ZERO,
                creditExtracts.get(0).getTotalTransferReceivedAmount().getValue());
        Assert.assertEquals("Should have operationalYear total Transfer Donated ", ten, creditExtracts.get(0)
                .getTotalTransferDonatedAmount().getValue());
        // ROW ONE
        Assert.assertEquals("Should have details blocked intacta", BigDecimal.ZERO, creditExtracts.get(0).getDetails()
                .get(0).getBlockedCreditAmount().getValue());
        Assert.assertEquals("Should have details available intacta", BigDecimal.TEN, creditExtracts.get(0).getDetails()
                .get(0).getReleasedCreditAmount().getValue());
        Assert.assertEquals("Should have details manual intacta", BigDecimal.ZERO, creditExtracts.get(0).getDetails()
                .get(0).getManualCreditAmount().getValue());
        Assert.assertEquals("Should have details extended intacta", BigDecimal.ZERO, creditExtracts.get(0).getDetails()
                .get(0).getExtendedCreditAmount().getValue());
        Assert.assertEquals("Should have details extended Transfer Receive", BigDecimal.ZERO, creditExtracts.get(0)
                .getDetails().get(0).getTransferReceiveCreditAmount().getValue());
        Assert.assertEquals("Should have details extended Transfer Receive", ten, creditExtracts.get(0).getDetails()
                .get(0).getTransferDonatedCreditAmount().getValue());

        List<SummaryCreditExtract> creditExtractsJose = saleService.getCreditExtract(saleTestFixture.joaoDaSilva,
                systemTestFixture.soy, systemTestFixture.monsantoBr);

        printExtractDetails(creditExtractsJose);

        Assert.assertEquals("Should have operationalYear 2012 of Jose ", systemTestFixture.operationalYearOf2012,
                creditExtractsJose.get(0).getOperationalYear());
        Assert.assertEquals("Should have operationalYear 2012 of Jose Total blocked ", BigDecimal.ZERO,
                creditExtractsJose.get(0).getTotalBlockedAmount().getValue());
        Assert.assertEquals("Should have operationalYear 2012 of Jose total Available ", BigDecimal.ZERO,
                creditExtractsJose.get(0).getTotalReleasedAmount().getValue());
        Assert.assertEquals("Should have operationalYear 2012 of Jose total Manual ", BigDecimal.ZERO,
                creditExtractsJose.get(0).getTotalManualReceivedAmount().getValue());
        Assert.assertEquals("Should have operationalYear 2012 of Jose total Extention ", BigDecimal.ZERO,
                creditExtractsJose.get(0).getTotalExtendedAmount().getValue());
        Assert.assertEquals("Should have operationalYear 2012 of Jose total Transfer Receive", ten, creditExtractsJose
                .get(0).getTotalTransferReceivedAmount().getValue());
        // ROW ONE
        Assert.assertEquals("Should have details blocked intacta", BigDecimal.ZERO, creditExtractsJose.get(0)
                .getDetails().get(0).getBlockedCreditAmount().getValue());
        Assert.assertEquals("Should have details available intacta", BigDecimal.ZERO, creditExtractsJose.get(0)
                .getDetails().get(0).getReleasedCreditAmount().getValue());
        Assert.assertEquals("Should have details manual intacta", BigDecimal.ZERO, creditExtractsJose.get(0)
                .getDetails().get(0).getManualCreditAmount().getValue());
        Assert.assertEquals("Should have details extended intacta", BigDecimal.ZERO, creditExtractsJose.get(0)
                .getDetails().get(0).getExtendedCreditAmount().getValue());
        Assert.assertEquals("Should have details extended Transfer Receive", ten, creditExtractsJose.get(0)
                .getDetails().get(0).getTransferReceiveCreditAmount().getValue());

    }

    @Test
    public void given_transactions_realized_in_accounts_of_grower_show_available_credit_with_transfer_only_request() {
        // Operations realized in accounts for available credits
        achieveSale(systemTestFixture.operationalYearOf2012, systemTestFixture.intacta, 1l);
        achievePayment(systemTestFixture.operationalYearOf2012, systemTestFixture.intacta);

        // Operations of transfer approved
        achieveTransferReserve(systemTestFixture.operationalYearOf2012, systemTestFixture.intacta);

        // Build credits amount
        List<Entry> entries = accountService.getEntriesBy(saleTestFixture.chicoBento, systemTestFixture.soy,
                systemTestFixture.monsantoBr);

        CreditExtractBuilder builder = new CreditExtractBuilder(entries);
        List<SummaryCreditExtract> creditExtracts = builder.build();

        printExtractDetails(creditExtracts);

        Assert.assertEquals("Should have operationalYear ", systemTestFixture.operationalYearOf2012, creditExtracts
                .get(0).getOperationalYear());
        Assert.assertEquals("Should have operationalYear Total blocked ", BigDecimal.ZERO, creditExtracts.get(0)
                .getTotalBlockedAmount().getValue());
        Assert.assertEquals("Should have operationalYear total Available ", BigDecimal.TEN, creditExtracts.get(0)
                .getTotalReleasedAmount().getValue());
        Assert.assertEquals("Should have operationalYear total Manual ", BigDecimal.ZERO, creditExtracts.get(0)
                .getTotalManualReceivedAmount().getValue());
        Assert.assertEquals("Should have operationalYear total Extention ", BigDecimal.ZERO, creditExtracts.get(0)
                .getTotalExtendedAmount().getValue());
        Assert.assertEquals("Should have operationalYear 2012 total Transfer Receive", BigDecimal.ZERO, creditExtracts
                .get(0).getTotalTransferReceivedAmount().getValue());
        Assert.assertEquals("Should have operationalYear 2012 total Transfer Reserve", BigDecimal.TEN, creditExtracts
                .get(0).getTotalReserveAmount().getValue());
        // ROW ONE
        Assert.assertEquals("Should have details blocked intacta", BigDecimal.ZERO, creditExtracts.get(0).getDetails()
                .get(0).getBlockedCreditAmount().getValue());
        Assert.assertEquals("Should have details available intacta", BigDecimal.TEN, creditExtracts.get(0).getDetails()
                .get(0).getReleasedCreditAmount().getValue());
        Assert.assertEquals("Should have details manual intacta", BigDecimal.ZERO, creditExtracts.get(0).getDetails()
                .get(0).getManualCreditAmount().getValue());
        Assert.assertEquals("Should have details extended intacta", BigDecimal.ZERO, creditExtracts.get(0).getDetails()
                .get(0).getExtendedCreditAmount().getValue());
        Assert.assertEquals("Should have details extended Transfer Receive", BigDecimal.ZERO, creditExtracts.get(0)
                .getDetails().get(0).getTransferReceiveCreditAmount().getValue());
        Assert.assertEquals("Should have details extended Transfer Reserve", BigDecimal.TEN, creditExtracts.get(0)
                .getDetails().get(0).getReserveCreditAmount().getValue());

    }

    @Test
    public void given_transactions_realized_in_accounts_of_grower_show_available_credit_with_transfer_reprove() throws ConstraintException {
        // Operations realized in accounts for available credits
        achieveSale(systemTestFixture.operationalYearOf2012, systemTestFixture.intacta, 1l);
        achievePayment(systemTestFixture.operationalYearOf2012, systemTestFixture.intacta);

        // Operations of transfer approved
        achieveTransferReserve(systemTestFixture.operationalYearOf2012, systemTestFixture.intacta);
        achieveTransferReprove(systemTestFixture.operationalYearOf2012, systemTestFixture.intacta);

        List<SummaryCreditExtract> creditExtracts = saleService.getCreditExtract(saleTestFixture.chicoBento,
                systemTestFixture.soy, systemTestFixture.monsantoBr);

        printExtractDetails(creditExtracts);

        Assert.assertEquals("Should have operationalYear ", systemTestFixture.operationalYearOf2012, creditExtracts
                .get(0).getOperationalYear());
        Assert.assertEquals("Should have operationalYear Total blocked ", BigDecimal.ZERO, creditExtracts.get(0)
                .getTotalBlockedAmount().getValue());
        Assert.assertEquals("Should have operationalYear total Available ", BigDecimal.TEN, creditExtracts.get(0)
                .getTotalReleasedAmount().getValue());
        Assert.assertEquals("Should have operationalYear total Manual ", BigDecimal.ZERO, creditExtracts.get(0)
                .getTotalManualReceivedAmount().getValue());
        Assert.assertEquals("Should have operationalYear total Extention ", BigDecimal.ZERO, creditExtracts.get(0)
                .getTotalExtendedAmount().getValue());
        // ROW ONE
        Assert.assertEquals("Should have details blocked intacta", BigDecimal.ZERO, creditExtracts.get(0).getDetails()
                .get(0).getBlockedCreditAmount().getValue());
        Assert.assertEquals("Should have details available intacta", BigDecimal.TEN, creditExtracts.get(0).getDetails()
                .get(0).getReleasedCreditAmount().getValue());
        Assert.assertEquals("Should have details manual intacta", BigDecimal.ZERO, creditExtracts.get(0).getDetails()
                .get(0).getManualCreditAmount().getValue());
        Assert.assertEquals("Should have details extended intacta", BigDecimal.ZERO, creditExtracts.get(0).getDetails()
                .get(0).getExtendedCreditAmount().getValue());

    }

    @Test
    public void given_transactions_realized_in_accounts_of_grower_show_available_credit_with_auto_release() throws ConstraintException {
        achieveSale(systemTestFixture.operationalYearOf2012, systemTestFixture.intacta, 1l);
        achievePayment(systemTestFixture.operationalYearOf2012, systemTestFixture.intacta);

        achieveSale(systemTestFixture.operationalYearOf2012, systemTestFixture.intacta, 1l);
        achieveAutoRelease(systemTestFixture.operationalYearOf2012, systemTestFixture.intacta);

        List<SummaryCreditExtract> creditExtracts = saleService.getCreditExtract(saleTestFixture.chicoBento,
                systemTestFixture.soy, systemTestFixture.monsantoBr);

        printExtractDetails(creditExtracts);

        Account accountAvailable = accountService.fetchOrCreateAccount(AccountType.AVAILABLE, saleTestFixture.chicoBento,
                systemTestFixture.soy, systemTestFixture.intacta, systemTestFixture.operationalYearOf2012);

        Assert.assertEquals("Should have operationalYear ", systemTestFixture.operationalYearOf2012, creditExtracts
                .get(0).getOperationalYear());
        Assert.assertEquals("Should have operationalYear Total blocked ", BigDecimal.ZERO, creditExtracts.get(0)
                .getTotalBlockedAmount().getValue());
        Assert.assertEquals("Should have operationalYear total Available ", new BigDecimal(20), creditExtracts.get(0)
                .getTotalReleasedAmount().getValue());
        Assert.assertEquals("Should have operationalYear total Manual ", BigDecimal.ZERO, creditExtracts.get(0)
                .getTotalManualReceivedAmount().getValue());
        Assert.assertEquals("Should have operationalYear total Extention ", BigDecimal.ZERO, creditExtracts.get(0)
                .getTotalExtendedAmount().getValue());
        Assert.assertEquals("Should have operationalYear total ", accountAvailable.getBalance(), creditExtracts.get(0)
                .getTotalAvailable());
        // ROW ONE
        Assert.assertEquals("Should have details blocked intacta", BigDecimal.ZERO, creditExtracts.get(0).getDetails()
                .get(0).getBlockedCreditAmount().getValue());
        Assert.assertEquals("Should have details available intacta", new BigDecimal(20), creditExtracts.get(0)
                .getDetails().get(0).getReleasedCreditAmount().getValue());
        Assert.assertEquals("Should have details manual intacta", BigDecimal.ZERO, creditExtracts.get(0).getDetails()
                .get(0).getManualCreditAmount().getValue());
        Assert.assertEquals("Should have details extended intacta", BigDecimal.ZERO, creditExtracts.get(0).getDetails()
                .get(0).getExtendedCreditAmount().getValue());
        Assert.assertEquals("Should have details extended intacta", accountAvailable.getBalance(), creditExtracts
                .get(0).getDetails().get(0).getTotalAvailable());

    }

    @Test
    public void given_transactions_realized_in_accounts_of_grower_show_available_credit_with_manual_debit() {
        achieveSale(systemTestFixture.operationalYearOf2012, systemTestFixture.intacta, 1l);
        achievePayment(systemTestFixture.operationalYearOf2012, systemTestFixture.intacta);

        achieveManualDebit(systemTestFixture.operationalYearOf2012, systemTestFixture.intacta);

        List<Entry> entries = accountService.getEntriesBy(saleTestFixture.chicoBento, systemTestFixture.soy,
                systemTestFixture.monsantoBr);

        CreditExtractBuilder builder = new CreditExtractBuilder(entries);
        List<SummaryCreditExtract> creditExtracts = builder.build();

        printExtractDetails(creditExtracts);

        Assert.assertEquals("Should have operationalYear ", systemTestFixture.operationalYearOf2012, creditExtracts
                .get(0).getOperationalYear());
        Assert.assertEquals("Should have operationalYear Total blocked ", BigDecimal.ZERO, creditExtracts.get(0)
                .getTotalBlockedAmount().getValue());
        Assert.assertEquals("Should have operationalYear total Available ", BigDecimal.TEN, creditExtracts.get(0)
                .getTotalReleasedAmount().getValue());
        Assert.assertEquals("Should have operationalYear total Manual ", BigDecimal.ZERO, creditExtracts.get(0)
                .getTotalManualReceivedAmount().getValue());
        Assert.assertEquals("Should have operationalYear total Charged ", BigDecimal.TEN, creditExtracts.get(0)
                .getTotalManualChargedAmount().getValue());

        // ROW ONE
        Assert.assertEquals("Should have details blocked intacta", BigDecimal.ZERO, creditExtracts.get(0).getDetails()
                .get(0).getBlockedCreditAmount().getValue());
        Assert.assertEquals("Should have details available intacta", BigDecimal.TEN, creditExtracts.get(0).getDetails()
                .get(0).getReleasedCreditAmount().getValue());
        Assert.assertEquals("Should have details manual intacta", BigDecimal.ZERO, creditExtracts.get(0).getDetails()
                .get(0).getManualCreditAmount().getValue());
        Assert.assertEquals("Should have details extended intacta", BigDecimal.ZERO, creditExtracts.get(0).getDetails()
                .get(0).getExtendedCreditAmount().getValue());
        Assert.assertEquals("Should have details Charged intacta", BigDecimal.TEN, creditExtracts.get(0).getDetails()
                .get(0).getManualChargedCreditAmount().getValue());
        Assert.assertEquals("Should have details Charged intacta", null, creditExtracts.get(0).getDetails().get(0)
                .getDueDate());
        Assert.assertEquals("Should have details Charged intacta", null, creditExtracts.get(0).getDetails().get(0)
                .getExtensionDate());

    }

    @Test
    public void given_transactions_realized_in_accounts_of_grower_show_available_credit_with_expired() throws ConstraintException {
        achieveSale(systemTestFixture.operationalYearOf2012, systemTestFixture.intacta, 1l);
        achievePayment(systemTestFixture.operationalYearOf2012, systemTestFixture.intacta);

        achieveDueAvailable(systemTestFixture.operationalYearOf2012, systemTestFixture.intacta);

        List<SummaryCreditExtract> creditExtracts = saleService.getCreditExtract(saleTestFixture.chicoBento,
                systemTestFixture.soy, systemTestFixture.monsantoBr);

        printExtractDetails(creditExtracts);

        Assert.assertEquals("Should have operationalYear ", systemTestFixture.operationalYearOf2012, creditExtracts
                .get(0).getOperationalYear());
        Assert.assertEquals("Should have operationalYear Total blocked ", BigDecimal.ZERO, creditExtracts.get(0)
                .getTotalBlockedAmount().getValue());
        Assert.assertEquals("Should have operationalYear total Available ", BigDecimal.TEN, creditExtracts.get(0)
                .getTotalReleasedAmount().getValue());
        Assert.assertEquals("Should have operationalYear total Manual ", BigDecimal.ZERO, creditExtracts.get(0)
                .getTotalManualReceivedAmount().getValue());
        Assert.assertEquals("Should have operationalYear total Charged ", BigDecimal.ZERO, creditExtracts.get(0)
                .getTotalManualChargedAmount().getValue());
        Assert.assertEquals("Should have operationalYear total Due ", BigDecimal.TEN, creditExtracts.get(0)
                .getTotalDueAmount().getValue());

        // ROW ONE
        Assert.assertEquals("Should have details blocked intacta", BigDecimal.ZERO, creditExtracts.get(0).getDetails()
                .get(0).getBlockedCreditAmount().getValue());
        Assert.assertEquals("Should have details available intacta", BigDecimal.TEN, creditExtracts.get(0).getDetails()
                .get(0).getReleasedCreditAmount().getValue());
        Assert.assertEquals("Should have details manual intacta", BigDecimal.ZERO, creditExtracts.get(0).getDetails()
                .get(0).getManualCreditAmount().getValue());
        Assert.assertEquals("Should have details extended intacta", BigDecimal.ZERO, creditExtracts.get(0).getDetails()
                .get(0).getExtendedCreditAmount().getValue());
        Assert.assertEquals("Should have details Charged intacta", BigDecimal.ZERO, creditExtracts.get(0).getDetails()
                .get(0).getManualChargedCreditAmount().getValue());
        Assert.assertEquals("Should have details Due intacta", BigDecimal.TEN, creditExtracts.get(0).getDetails()
                .get(0).getDueCreditAmount().getValue());

    }

    @Test
    public void given_transactions_realized_in_accounts_of_grower_show_available_credit_with_partialPayment() throws ConstraintException {
        achieveSale(systemTestFixture.operationalYearOf2012, systemTestFixture.intacta, 1l);
        achievePartialPayment(systemTestFixture.operationalYearOf2012, systemTestFixture.intacta);

        List<SummaryCreditExtract> creditExtracts = saleService.getCreditExtract(saleTestFixture.chicoBento,
                systemTestFixture.soy, systemTestFixture.monsantoBr);

        printExtractDetails(creditExtracts);

        BigDecimal five = new BigDecimal(5);

        Assert.assertEquals("Should have operationalYear ", systemTestFixture.operationalYearOf2012, creditExtracts
                .get(0).getOperationalYear());
        Assert.assertEquals("Should have operationalYear Total blocked ", BigDecimal.ZERO, creditExtracts.get(0)
                .getTotalBlockedAmount().getValue());
        Assert.assertEquals("Should have operationalYear total Available ", five, creditExtracts.get(0)
                .getTotalReleasedAmount().getValue());
        Assert.assertEquals("Should have operationalYear total Manual ", BigDecimal.ZERO, creditExtracts.get(0)
                .getTotalManualReceivedAmount().getValue());
        Assert.assertEquals("Should have operationalYear total Charged ", BigDecimal.ZERO, creditExtracts.get(0)
                .getTotalManualChargedAmount().getValue());
        Assert.assertEquals("Should have operationalYear total Due ", BigDecimal.ZERO, creditExtracts.get(0)
                .getTotalDueAmount().getValue());

        // ROW ONE
        Assert.assertEquals("Should have details blocked intacta", BigDecimal.ZERO, creditExtracts.get(0).getDetails()
                .get(0).getBlockedCreditAmount().getValue());
        Assert.assertEquals("Should have details available intacta", five, creditExtracts.get(0).getDetails().get(0)
                .getReleasedCreditAmount().getValue());
        Assert.assertEquals("Should have details manual intacta", BigDecimal.ZERO, creditExtracts.get(0).getDetails()
                .get(0).getManualCreditAmount().getValue());
        Assert.assertEquals("Should have details extended intacta", BigDecimal.ZERO, creditExtracts.get(0).getDetails()
                .get(0).getExtendedCreditAmount().getValue());
        Assert.assertEquals("Should have details Charged intacta", BigDecimal.ZERO, creditExtracts.get(0).getDetails()
                .get(0).getManualChargedCreditAmount().getValue());
        Assert.assertEquals("Should have details Due intacta", BigDecimal.ZERO,
                creditExtracts.get(0).getDetails().get(0).getDueCreditAmount().getValue());

    }

    private void achieveAutoRelease(OperationalYear operationalYear, Technology technology) {
    	TransferAccount transferAccount = new TransferAccount(AccountType.BLOCKED, saleTestFixture.chicoBento, AccountType.AVAILABLE, saleTestFixture.chicoBento, operationalYear, technology, systemTestFixture.soy, BigDecimal.TEN);
        transactionControlService.saveTransfer(transferAccount, 1l, TransactionType.AUTO_RELEASE);
    }

    private void achieveTransferReserve(OperationalYear operationalYear, Technology technology) {
    	TransferAccount transferAccount = new TransferAccount(AccountType.AVAILABLE, saleTestFixture.chicoBento, AccountType.AVAILABLE_TRANSFER, saleTestFixture.chicoBento, operationalYear, technology, systemTestFixture.soy, BigDecimal.TEN);
        transactionControlService.saveTransfer(transferAccount, 1l, TransactionType.TRANSFER_REQUEST);
    }

    private void achieveTransfer(OperationalYear operationalYear, Technology technology, Grower growerTarget) {
    	TransferAccount transferAccount = new TransferAccount(AccountType.AVAILABLE_TRANSFER, saleTestFixture.chicoBento, AccountType.AVAILABLE, growerTarget, operationalYear, technology, systemTestFixture.soy, BigDecimal.TEN);
        transactionControlService.saveTransfer(transferAccount, 1l, TransactionType.TRANSFER_APPROVED);
    }

    private void achieveTransferReprove(OperationalYear operationalYear, Technology technology) {
    	TransferAccount transferAccount = new TransferAccount(AccountType.AVAILABLE_TRANSFER, saleTestFixture.chicoBento, AccountType.AVAILABLE, saleTestFixture.chicoBento, operationalYear, technology, systemTestFixture.soy, BigDecimal.TEN);
        transactionControlService.saveTransfer(transferAccount, 1l, TransactionType.TRANSFER_REPROVE);
    }

    private void achievePayment(OperationalYear operationalYear, Technology technology) {
    	TransferAccount transferAccount = new TransferAccount(AccountType.BLOCKED, saleTestFixture.chicoBento, AccountType.AVAILABLE, saleTestFixture.chicoBento, operationalYear, technology, systemTestFixture.soy, BigDecimal.TEN);
    	transactionControlService.saveTransfer(transferAccount, 1l, TransactionType.PAYMENT);
    }

    private void achievePartialPayment(OperationalYear operationalYear, Technology technology) {    	
    	List<TransferAccount> transfers = new ArrayList<TransferAccount>();
    	transfers.add(new TransferAccount(AccountType.BLOCKED, saleTestFixture.chicoBento, AccountType.AVAILABLE, saleTestFixture.chicoBento, operationalYear, technology, systemTestFixture.soy, new BigDecimal(5)));
    	transfers.add(new TransferAccount(AccountType.BLOCKED, saleTestFixture.chicoBento, AccountType.UNUSABLE, saleTestFixture.chicoBento, operationalYear, technology, systemTestFixture.soy, new BigDecimal(5)));
        
        transactionControlService.saveTransfer(transfers, 1l, TransactionType.PAYMENT);
    }

	private void achieveSale(OperationalYear operationalYear,
			Technology technology, long saleCode) {
		transactionControlService
				.saveDeposit(saleTestFixture.chicoBento, AccountType.BLOCKED,
						operationalYear, technology, systemTestFixture.soy,
						BigDecimal.TEN, saleCode, TransactionType.SALE);
	}

    private void achieveManualDebit(OperationalYear operationalYear, Technology technology) {
        transactionControlService.saveWithdrawal(saleTestFixture.chicoBento, AccountType.AVAILABLE, operationalYear, technology, systemTestFixture.soy, BigDecimal.TEN, 1l, TransactionType.MANUAL_GENERATION);
    }

    private void achieveManualCredit(OperationalYear operationalYear, Technology technology, long manualCreditCode) {
        transactionControlService.saveDeposit(saleTestFixture.chicoBento, AccountType.AVAILABLE, operationalYear, technology, systemTestFixture.soy, BigDecimal.ONE, manualCreditCode, TransactionType.MANUAL_GENERATION);
    }

    private void achieveDueAvailable(OperationalYear operationalYear, Technology technology) {
    	TransferAccount transferAccount = new TransferAccount(AccountType.AVAILABLE, saleTestFixture.chicoBento, AccountType.AVAILABLE_EXPIRED, saleTestFixture.chicoBento, operationalYear, technology, systemTestFixture.soy, BigDecimal.TEN);
        transactionControlService.saveTransfer(transferAccount, 1l, TransactionType.EXPIRATION);
    }

    private void achieveExtension(OperationalYear operationalYear, Technology technology) {       
		TransferAccount transferAccount = new TransferAccount(
				AccountType.AVAILABLE_EXPIRED, saleTestFixture.chicoBento,
				AccountType.EXTENDED, saleTestFixture.chicoBento,
				operationalYear, technology, systemTestFixture.soy,
				BigDecimal.TEN);
		transactionControlService.saveTransfer(transferAccount, 1l,
				TransactionType.EXTENSION);
    }

    // private void achieveExpiredExtended(OperationalYear operationalYear,
    // Technology technology) {
    // Account accountAvailable =
    // accountService.getAccount(AccountType.EXTENDED,
    // saleTestFixture.chicoBento, systemTestFixture.soy, technology,
    // operationalYear);
    // Account accountAvailableExpired =
    // accountService.getAccount(AccountType.EXTENDED_EXPIRED,
    // saleTestFixture.chicoBento, systemTestFixture.soy,
    // technology,operationalYear);
    //
    // final BigDecimal ten = BigDecimal.TEN;
    // Transaction transaction = new
    // TransactionBuilder(TransactionType.EXPIRATION,
    // 1l).addWithdrawal(accountAvailable,
    // ten).addDeposit(accountAvailableExpired, ten).build();
    // transactionDAO.save(transaction);
    // }

    private void printExtractDetails(List<SummaryCreditExtract> creditExtracts) {
        for (SummaryCreditExtract summaryCreditExtract : creditExtracts) {
            System.out.println("++OperationalYear 2012" + summaryCreditExtract.getOperationalYear().getYear()
                    + "| Balance Total Blocked $" + summaryCreditExtract.getTotalBlockedAmount().getValue()
                    + "| Balance Total Available $" + summaryCreditExtract.getTotalReleasedAmount().getValue()
                    + "| Balance Total Manual $" + summaryCreditExtract.getTotalManualReceivedAmount().getValue()
                    + "| Balance Total Extension $" + summaryCreditExtract.getTotalExtendedAmount().getValue()
                    + "| Balance Total Transfer Receive $"
                    + summaryCreditExtract.getTotalTransferReceivedAmount().getValue() + "| Balance Total Reserve $"
                    + summaryCreditExtract.getTotalReserveAmount().getValue() + "| Balance Total Transfer Donated$"
                    + summaryCreditExtract.getTotalTransferDonatedAmount().getValue());
            for (CreditTransactionBalance transactionBalance : summaryCreditExtract.getDetails()) {
                System.out.println("++++Technology: " + transactionBalance.getTechnology().getDescription() + " Crop :"
                        + transactionBalance.getCrop().getDescription() + "| Balance Blocked $"
                        + transactionBalance.getBlockedCreditAmount().getValue() + "| Balance Available $"
                        + transactionBalance.getReleasedCreditAmount().getValue() + "| Balance Manual $"
                        + transactionBalance.getManualCreditAmount().getValue() + "| Balance Extension $"
                        + transactionBalance.getExtendedCreditAmount().getValue() + "| Balance Transfer Receive $"
                        + transactionBalance.getTransferReceiveCreditAmount().getValue()
                        + "| Balance Transfer Donated $"
                        + transactionBalance.getTransferDonatedCreditAmount().getValue() + "| Balance Reserve $"
                        + transactionBalance.getReserveCreditAmount().getValue());
            }

        }
    }

    @Test
    public void when_i_want_to_show_detail_of_blocked_credit_amount_where_status_credit_is_waiting_manually()
            throws SaleConstraintViolationException, ConstraintException {

        Sale sale = createSaleWithSaleTemplateManually(null);

        List<SummaryCreditExtract> creditExtracts = saleService.getCreditExtract(saleTestFixture.chicoBento,
                systemTestFixture.soy, systemTestFixture.monsantoBr);

        printExtractDetails(creditExtracts);

        SaleItem item = sale.getItems().iterator().next();
        BigDecimal totalCreditBlocked = item.getProductivityValue().multiply(new BigDecimal(item
                .getSoldQuantity()));
        BigDecimal totalRoyalty = item.getPriceQuantity().multiply(new BigDecimal(item.getSoldQuantity()));

        Assert.assertEquals("Should have operationalYear ", systemTestFixture.operationalYearOf2012, creditExtracts
                .get(0).getOperationalYear());
        Assert.assertEquals("Should have operationalYear Total blocked ", totalCreditBlocked, creditExtracts.get(0)
                .getTotalBlockedAmount().getValue());
        Assert.assertEquals("Should have operationalYear total Released ", BigDecimal.ZERO, creditExtracts.get(0)
                .getTotalReleasedAmount().getValue());
        Assert.assertEquals("Should have operationalYear total Manual ", BigDecimal.ZERO, creditExtracts.get(0)
                .getTotalManualReceivedAmount().getValue());
        Assert.assertEquals("Should have operationalYear total Extention ", BigDecimal.ZERO, creditExtracts.get(0)
                .getTotalExtendedAmount().getValue());
        Assert.assertEquals("Should have operationalYear total ", BigDecimal.ZERO, creditExtracts.get(0)
                .getTotalAvailable());

        DetailedBlockedAndAvaliableCreditAmount details = saleService.getDetailOfBlocked(creditExtracts.get(0)
                .getDetails().get(0).getBlockedCreditAmount());

        Assert.assertEquals("Should have total credit blocked ", totalCreditBlocked, details.getTotalCreditQuantity());
        Assert.assertEquals("Should have total royalty ", totalRoyalty, details.getTotalRoyaltyValue());
        Assert.assertEquals("Should have total paid value ", BigDecimal.ZERO, details.getTotalPaidValue());
        Assert.assertEquals("Should have available credit ", BigDecimal.ZERO, details.getTotalAvailableCredit());
        Assert.assertEquals("Should have the same customer of the sale", details.getDecoratedBillings().get(0)
                .getCustomerName(), sale.getCustomer().getName());
        Assert.assertEquals("Should have the same billing of the sale", details.getDecoratedBillings().get(0)
                .getBilling().getSaleCode(), sale.getId());

    }

    @Test
    public void when_i_want_to_show_detail_of_blocked_credit_amount_where_status_credit_is_on_payment()
            throws SaleConstraintViolationException, ConstraintException {

        Sale sale = createSaleWithSaleTemplateOnPayment(null);

        List<SummaryCreditExtract> creditExtracts = saleService.getCreditExtract(saleTestFixture.chicoBento,
                systemTestFixture.soy, systemTestFixture.monsantoBr);

        printExtractDetails(creditExtracts);

        SaleItem item = sale.getItems().iterator().next();
        BigDecimal totalCreditBlocked = item.getProductivityValue().multiply(new BigDecimal(item
                .getSoldQuantity()));

        Assert.assertEquals("Should have operationalYear ", systemTestFixture.operationalYearOf2012, creditExtracts
                .get(0).getOperationalYear());
        Assert.assertEquals("Should have operationalYear Total blocked ", totalCreditBlocked, creditExtracts.get(0)
                .getTotalBlockedAmount().getValue());
        Assert.assertEquals("Should have operationalYear total Released ", BigDecimal.ZERO, creditExtracts.get(0)
                .getTotalReleasedAmount().getValue());
        Assert.assertEquals("Should have operationalYear total Manual ", BigDecimal.ZERO, creditExtracts.get(0)
                .getTotalManualReceivedAmount().getValue());
        Assert.assertEquals("Should have operationalYear total Extention ", BigDecimal.ZERO, creditExtracts.get(0)
                .getTotalExtendedAmount().getValue());
        Assert.assertEquals("Should have operationalYear total ", BigDecimal.ZERO, creditExtracts.get(0)
                .getTotalAvailable());

        DetailedBlockedAndAvaliableCreditAmount details = saleService.getDetailOfBlocked(creditExtracts.get(0)
                .getDetails().get(0).getBlockedCreditAmount());

        Assert.assertEquals("Should have the same customer of the sale", details.getDecoratedBillings().get(0)
                .getCustomerName(), sale.getCustomer().getName());
        Assert.assertEquals("Should have the same billing of the sale", details.getDecoratedBillings().get(0)
                .getBilling().getSaleCode(), sale.getId());

    }

    @Test
    public void when_i_want_to_show_detail_of_blocked_credit_amount_where_status_credit_is_on_payment_and_waiting_manually()
            throws SaleConstraintViolationException, ConstraintException {

        Sale saleManually = createSaleWithSaleTemplateManually("12345");
        Sale saleOnPay = createSaleWithSaleTemplateOnPayment("123456");

        List<SummaryCreditExtract> creditExtracts = saleService.getCreditExtract(saleTestFixture.chicoBento,
                systemTestFixture.soy, systemTestFixture.monsantoBr);

        printExtractDetails(creditExtracts);

        SaleItem item = saleOnPay.getItems().iterator().next();
        BigDecimal totalCreditBlocked = item.getProductivityValue().multiply(new BigDecimal(item
                .getSoldQuantity()));

        item = saleManually.getItems().iterator().next();
        totalCreditBlocked = totalCreditBlocked.add(item.getProductivityValue()
                .multiply(new BigDecimal(item.getSoldQuantity())));

        Assert.assertEquals("Should have operationalYear ", systemTestFixture.operationalYearOf2012, creditExtracts
                .get(0).getOperationalYear());
        Assert.assertEquals("Should have operationalYear Total blocked ", totalCreditBlocked, creditExtracts.get(0)
                .getTotalBlockedAmount().getValue());
        Assert.assertEquals("Should have operationalYear total Released ", BigDecimal.ZERO, creditExtracts.get(0)
                .getTotalReleasedAmount().getValue());
        Assert.assertEquals("Should have operationalYear total Manual ", BigDecimal.ZERO, creditExtracts.get(0)
                .getTotalManualReceivedAmount().getValue());
        Assert.assertEquals("Should have operationalYear total Extention ", BigDecimal.ZERO, creditExtracts.get(0)
                .getTotalExtendedAmount().getValue());
        Assert.assertEquals("Should have operationalYear total ", BigDecimal.ZERO, creditExtracts.get(0)
                .getTotalAvailable());

        DetailedBlockedAndAvaliableCreditAmount details = saleService.getDetailOfBlocked(creditExtracts.get(0)
                .getDetails().get(0).getBlockedCreditAmount());

        for (BillingDTO dto : details.getDecoratedBillings()) {
            if (saleManually.getId().equals(dto.getBilling().getSaleCode())) {
                Assert.assertEquals("Should have the same customer of the sale", dto.getCustomerName(), saleManually
                        .getCustomer().getName());
            } else {
                Assert.assertEquals("Should have the same customer of the sale", dto.getCustomerName(), saleOnPay
                        .getCustomer().getName());
            }
        }
    }

    @Test
    public void when_i_want_to_show_detail_of_blocked_credit_amount_where_status_credit_is_on_payment_and_waiting_manually_and_sale_with_status_credit_on_payment_is_pay()
            throws SaleConstraintViolationException, ConstraintException {

        Sale saleManually = createSaleWithSaleTemplateManually("12345");

        Sale saleOnPay = createSaleWithSaleTemplateOnPayment("123456");

        payBillingOf(saleOnPay);

        List<SummaryCreditExtract> creditExtracts = saleService.getCreditExtract(saleTestFixture.chicoBento,
                systemTestFixture.soy, systemTestFixture.monsantoBr);

        printExtractDetails(creditExtracts);

        SaleItem item = saleManually.getItems().iterator().next();
        BigDecimal manuallyCreditBlocked = item.getProductivityValue().multiply(new BigDecimal(item
                .getSoldQuantity()));

        item = saleOnPay.getItems().iterator().next();
        BigDecimal onPayCreditBlocked = item.getProductivityValue().multiply(new BigDecimal(item
                .getSoldQuantity()));

        Assert.assertEquals("Should have operationalYear Total blocked equals credit generate for saleManually",
                manuallyCreditBlocked, creditExtracts.get(0).getTotalBlockedAmount().getValue());
        Assert.assertEquals("Should have operationalYear ", systemTestFixture.operationalYearOf2012, creditExtracts
                .get(0).getOperationalYear());
        Assert.assertEquals("Should have operationalYear total Released ", onPayCreditBlocked, creditExtracts.get(0)
                .getTotalReleasedAmount().getValue());
        Assert.assertEquals("Should have operationalYear total Manual ", BigDecimal.ZERO, creditExtracts.get(0)
                .getTotalManualReceivedAmount().getValue());
        Assert.assertEquals("Should have operationalYear total Extention ", BigDecimal.ZERO, creditExtracts.get(0)
                .getTotalExtendedAmount().getValue());
        Assert.assertEquals("Should have operationalYear total ", onPayCreditBlocked, creditExtracts.get(0)
                .getTotalAvailable());

        DetailedBlockedAndAvaliableCreditAmount details = saleService.getDetailOfBlocked(creditExtracts.get(0)
                .getDetails().get(0).getBlockedCreditAmount());

        Assert.assertEquals("Should have the same customer of the sale", details.getDecoratedBillings().get(0)
                .getCustomerName(), saleManually.getCustomer().getName());
        Assert.assertEquals("Should have the same billing of the sale", details.getDecoratedBillings().get(0)
                .getBilling().getSaleCode(), saleManually.getId());

    }
    
    @Test
    public void when_i_want_to_show_detail_of_blocked_credit_amount_where_status_credit_is_on_payment_and_sale_with_status_credit_on_payment_is_billed()
            throws SaleConstraintViolationException, ConstraintException {

        Sale saleOnPay = createSaleWithSaleTemplateOnPayment("123456");

        List<Billing> saleBillings = saleService.getBillingBy(BillingFilter.getInstance().add(saleOnPay.getId()));
        for (Billing billing : saleBillings) {
			billing.setPaymentStatus(PaymentStatus.BILLED);
			saveAndFlush(billing);
		}

        List<SummaryCreditExtract> creditExtracts = saleService.getCreditExtract(saleTestFixture.chicoBento,
                systemTestFixture.soy, systemTestFixture.monsantoBr);
        
        printExtractDetails(creditExtracts);

        SaleItem item = saleOnPay.getItems().iterator().next();
        BigDecimal onPayCreditBlocked = item.getProductivityValue().multiply(new BigDecimal(item
                .getSoldQuantity()));

        Assert.assertEquals("Should have operationalYear ", systemTestFixture.operationalYearOf2012, creditExtracts
                .get(0).getOperationalYear());
        Assert.assertEquals("Should have operationalYear total Blocked ", onPayCreditBlocked, creditExtracts.get(0)
                .getTotalBlockedAmount().getValue());
        Assert.assertEquals("Should have operationalYear total ", BigDecimal.ZERO, creditExtracts.get(0)
                .getTotalAvailable());

        DetailedBlockedAndAvaliableCreditAmount details = saleService.getDetailOfBlocked(creditExtracts.get(0)
                .getDetails().get(0).getBlockedCreditAmount());

        Assert.assertEquals("Should have the same customer of the sale", details.getDecoratedBillings().get(0)
                .getCustomerName(), saleOnPay.getCustomer().getName());
        Assert.assertEquals("Should have the same billing of the sale", details.getDecoratedBillings().get(0)
                .getBilling().getSaleCode(), saleOnPay.getId());
    }

    @Test
    public void given_aSale_onPay_without_not_paid_that_was_canceled_when_search_credit_extract_then_release_credit_amount_should_not_be_subtract()
            throws SaleConstraintViolationException, ConstraintException, IndustrySystemOperationException {

        Sale sale = createSaleWithSaleTemplateOnPayment("123456");

        List<SummaryCreditExtract> creditExtracts = saleService.getCreditExtract(saleTestFixture.chicoBento,
                systemTestFixture.soy, systemTestFixture.monsantoBr);

        printExtractDetails(creditExtracts);

        BillingFilter billingFilter = BillingFilter.getInstance().add(sale.getId());

        List<Billing> billings = saleService.getBillingBy(billingFilter);

        manager.manageCancelledPaymentFor(saleTestFixture.chicoBento, billings.get(0));

        Assert.assertEquals("Should have operationalYear ", systemTestFixture.operationalYearOf2012, creditExtracts
                .get(0).getOperationalYear());
        Assert.assertEquals("Should have operationalYear total Released ", BigDecimal.ZERO, creditExtracts.get(0)
                .getTotalReleasedAmount().getValue());
        Assert.assertEquals("Should have operationalYear total Manual ", BigDecimal.ZERO, creditExtracts.get(0)
                .getTotalManualReceivedAmount().getValue());
        Assert.assertEquals("Should have operationalYear total Extention ", BigDecimal.ZERO, creditExtracts.get(0)
                .getTotalExtendedAmount().getValue());
        Assert.assertEquals("Should have operationalYear total ", BigDecimal.ZERO, creditExtracts.get(0)
                .getTotalAvailable());

    }

    @Test
    public void when_I_want_to_show_details_of_avaliable_credit_amount_where_status_credit_is_released_automatically()
            throws SaleConstraintViolationException, ConstraintException {

        Sale saleAutomatically = createSaleWithSaleTemplateAutomatically(null);

        List<SummaryCreditExtract> creditExtracts = saleService.getCreditExtract(saleTestFixture.chicoBento,
                systemTestFixture.soy, systemTestFixture.monsantoBr);

        printExtractDetails(creditExtracts);

        SaleItem item = saleAutomatically.getItems().iterator().next();
        BigDecimal totalCreditAvaliable = item.getProductivityValue().multiply(new BigDecimal(item
                .getSoldQuantity()));
        // BigDecimal totalRoyalty = item.getPriceQuantity().multiply(new
        // BigDecimal(item.getSoldQuantity()));

        Assert.assertEquals("Should have operationalYear ", systemTestFixture.operationalYearOf2012, creditExtracts
                .get(0).getOperationalYear());
        Assert.assertEquals("Should have operationalYear Total blocked ", BigDecimal.ZERO, creditExtracts.get(0)
                .getTotalBlockedAmount().getValue());
        Assert.assertEquals("Should have operationalYear total Released ", totalCreditAvaliable, creditExtracts.get(0)
                .getTotalReleasedAmount().getValue());
        Assert.assertEquals("Should have operationalYear total Manual ", BigDecimal.ZERO, creditExtracts.get(0)
                .getTotalManualReceivedAmount().getValue());
        Assert.assertEquals("Should have operationalYear total Extention ", BigDecimal.ZERO, creditExtracts.get(0)
                .getTotalExtendedAmount().getValue());
        Assert.assertEquals("Should have operationalYear total ", totalCreditAvaliable, creditExtracts.get(0)
                .getTotalAvailable());

        DetailedBlockedAndAvaliableCreditAmount details = saleService.getDetailOfAvaliable(creditExtracts.get(0)
                .getDetails().get(0).getReleasedCreditAmount());

        // Assert.assertEquals("Should have total credit blocked ",BigDecimal.ZERO
        // ,details.getTotalCreditQuantity());
        // Assert.assertEquals("Should have total royalty ",totalRoyalty
        // ,details.getTotalRoyaltyValue());
        // Assert.assertEquals("Should have total paid value ",BigDecimal.ZERO
        // ,details.getTotalPaidValue());
        // Assert.assertEquals("Should have available credit ",totalCreditAvaliable
        // ,details.getTotalAvailableCredit());

        Assert.assertEquals("Should have the same customer of the sale", details.getDecoratedBillings().get(0)
                .getCustomerName(), saleAutomatically.getCustomer().getName());
        Assert.assertEquals("Should have the same billing of the sale", details.getDecoratedBillings().get(0)
                .getBilling().getSaleCode(), saleAutomatically.getId());

    }

    @Test
    public void when_I_want_to_show_details_of_avaliable_credit_amount_not_show_sale_canceled()
            throws SaleConstraintViolationException, ConstraintException, IndustrySystemOperationException {

        Sale saleAutomatically = createSaleWithSaleTemplateAutomatically(null);

        List<SummaryCreditExtract> creditExtracts = saleService.getCreditExtract(saleTestFixture.chicoBento,
                systemTestFixture.soy, systemTestFixture.monsantoBr);

        printExtractDetails(creditExtracts);

        SaleItem item = saleAutomatically.getItems().iterator().next();
        BigDecimal totalCreditAvaliable = item.getProductivityValue().multiply(new BigDecimal(item
                .getSoldQuantity()));

        Assert.assertEquals("Should have operationalYear ", systemTestFixture.operationalYearOf2012, creditExtracts
                .get(0).getOperationalYear());
        Assert.assertEquals("Should have operationalYear Total blocked ", BigDecimal.ZERO, creditExtracts.get(0)
                .getTotalBlockedAmount().getValue());
        Assert.assertEquals("Should have operationalYear total Released ", totalCreditAvaliable, creditExtracts.get(0)
                .getTotalReleasedAmount().getValue());
        Assert.assertEquals("Should have operationalYear total Manual ", BigDecimal.ZERO, creditExtracts.get(0)
                .getTotalManualReceivedAmount().getValue());
        Assert.assertEquals("Should have operationalYear total Extention ", BigDecimal.ZERO, creditExtracts.get(0)
                .getTotalExtendedAmount().getValue());
        Assert.assertEquals("Should have operationalYear total ", totalCreditAvaliable, creditExtracts.get(0)
                .getTotalAvailable());

        DetailedBlockedAndAvaliableCreditAmount details = saleService.getDetailOfAvaliable(creditExtracts.get(0)
                .getDetails().get(0).getReleasedCreditAmount());

        Assert.assertEquals("Should have the same customer of the sale", details.getDecoratedBillings().get(0)
                .getCustomerName(), saleAutomatically.getCustomer().getName());
        Assert.assertEquals("Should have the same billing of the sale", details.getDecoratedBillings().get(0)
                .getBilling().getSaleCode(), saleAutomatically.getId());

        manager.manageCancelledPaymentFor(saleTestFixture.chicoBento, details.getDecoratedBillings().get(0)
                .getBilling());

        creditExtracts = saleService.getCreditExtract(saleTestFixture.chicoBento, systemTestFixture.soy,
                systemTestFixture.monsantoBr);
        Assert.assertEquals("Should have operationalYear total Released ", BigDecimal.ZERO, creditExtracts.get(0)
                .getTotalReleasedAmount().getValue());
        Assert.assertEquals("Should have operationalYear total ", BigDecimal.ZERO, creditExtracts.get(0)
                .getTotalAvailable());

    }

    @Test
    public void when_i_want_to_show_detail_of_avaliable_credit_amount_where_status_credit_is_on_payment_with_billing_paid()
            throws SaleConstraintViolationException, ConstraintException {

        Sale saleOnPay = createSaleWithSaleTemplateOnPayment(null);
        payBillingOf(saleOnPay);

        List<SummaryCreditExtract> creditExtracts = saleService.getCreditExtract(saleTestFixture.chicoBento,
                systemTestFixture.soy, systemTestFixture.monsantoBr);
        printExtractDetails(creditExtracts);

        SaleItem item = saleOnPay.getItems().iterator().next();
        BigDecimal totalCreditAvaliable = item.getProductivityValue().multiply(new BigDecimal(item
                .getSoldQuantity()));

        Assert.assertEquals("Should have operationalYear ", systemTestFixture.operationalYearOf2012, creditExtracts
                .get(0).getOperationalYear());
        Assert.assertEquals("Should have operationalYear Total blocked ", BigDecimal.ZERO, creditExtracts.get(0)
                .getTotalBlockedAmount().getValue());
        Assert.assertEquals("Should have operationalYear total Released ", totalCreditAvaliable, creditExtracts.get(0)
                .getTotalReleasedAmount().getValue());
        Assert.assertEquals("Should have operationalYear total Manual ", BigDecimal.ZERO, creditExtracts.get(0)
                .getTotalManualReceivedAmount().getValue());
        Assert.assertEquals("Should have operationalYear total Extention ", BigDecimal.ZERO, creditExtracts.get(0)
                .getTotalExtendedAmount().getValue());
        Assert.assertEquals("Should have operationalYear total ", totalCreditAvaliable, creditExtracts.get(0)
                .getTotalAvailable());

        DetailedBlockedAndAvaliableCreditAmount details = saleService.getDetailOfAvaliable(creditExtracts.get(0)
                .getDetails().get(0).getReleasedCreditAmount());

        Assert.assertEquals("Should have the same customer of the sale", details.getDecoratedBillings().get(0)
                .getCustomerName(), saleOnPay.getCustomer().getName());
        Assert.assertEquals("Should have the same billing of the sale", details.getDecoratedBillings().get(0)
                .getBilling().getSaleCode(), saleOnPay.getId());

    }

    @Test
    public void when_i_want_to_show_detail_of_avaliable_credit_amount_where_status_credit_is_on_payment_with_billing_paid_and_released_automatically()
            throws SaleConstraintViolationException, ConstraintException {

        Sale saleAutomatically = createSaleWithSaleTemplateAutomatically("123456");
        Sale saleOnPay = createSaleWithSaleTemplateOnPayment("1234567");

        payBillingOf(saleOnPay);

        List<SummaryCreditExtract> creditExtracts = saleService.getCreditExtract(saleTestFixture.chicoBento,
                systemTestFixture.soy, systemTestFixture.monsantoBr);

        printExtractDetails(creditExtracts);

        SaleItem item = saleOnPay.getItems().iterator().next();
        BigDecimal totalCreditBlocked = item.getProductivityValue().multiply(new BigDecimal(item
                .getSoldQuantity()));

        item = saleAutomatically.getItems().iterator().next();
        totalCreditBlocked = totalCreditBlocked.add(item.getProductivityValue()
                .multiply(new BigDecimal(item.getSoldQuantity())));

        Assert.assertEquals("Should have operationalYear ", systemTestFixture.operationalYearOf2012, creditExtracts
                .get(0).getOperationalYear());
        Assert.assertEquals("Should have operationalYear Total blocked ", BigDecimal.ZERO, creditExtracts.get(0)
                .getTotalBlockedAmount().getValue());
        Assert.assertEquals("Should have operationalYear total Released ", totalCreditBlocked, creditExtracts.get(0)
                .getTotalReleasedAmount().getValue());
        Assert.assertEquals("Should have operationalYear total Manual ", BigDecimal.ZERO, creditExtracts.get(0)
                .getTotalManualReceivedAmount().getValue());
        Assert.assertEquals("Should have operationalYear total Extention ", BigDecimal.ZERO, creditExtracts.get(0)
                .getTotalExtendedAmount().getValue());
        Assert.assertEquals("Should have operationalYear total ", totalCreditBlocked, creditExtracts.get(0)
                .getTotalAvailable());

        DetailedBlockedAndAvaliableCreditAmount details = saleService.getDetailOfAvaliable(creditExtracts.get(0)
                .getDetails().get(0).getReleasedCreditAmount());

        for (BillingDTO dto : details.getDecoratedBillings()) {
            if (saleAutomatically.getId().equals(dto.getBilling().getSaleCode())) {
                Assert.assertEquals("Should have the same customer of the sale", dto.getCustomerName(),
                        saleAutomatically.getCustomer().getName());
            } else {
                Assert.assertEquals("Should have the same customer of the sale", dto.getCustomerName(), saleOnPay
                        .getCustomer().getName());
            }
        }

    }

    @Test
    public void when_i_want_to_show_detail_of_avaliable_credit_amount_where_status_credit_is_on_payment_with_billing_not_paid_and_released_automatically()
            throws SaleConstraintViolationException, ConstraintException {

        Sale saleAutomatically = createSaleWithSaleTemplateAutomatically("12345");
        Sale saleOnPay = createSaleWithSaleTemplateOnPayment("123456");

        List<SummaryCreditExtract> creditExtracts = saleService.getCreditExtract(saleTestFixture.chicoBento,
                systemTestFixture.soy, systemTestFixture.monsantoBr);

        printExtractDetails(creditExtracts);

        SaleItem itemOnPay = saleOnPay.getItems().iterator().next();
        BigDecimal totalCreditBlocked = itemOnPay.getProductivityValue().multiply(new BigDecimal(
                itemOnPay.getSoldQuantity()));

        SaleItem itemAutomatically = saleAutomatically.getItems().iterator().next();
        BigDecimal totalCreditAvaliable = itemAutomatically.getProductivityValue()
                .multiply(new BigDecimal(itemAutomatically.getSoldQuantity()));

        Assert.assertEquals("Should have operationalYear ", systemTestFixture.operationalYearOf2012, creditExtracts
                .get(0).getOperationalYear());
        Assert.assertEquals("Should have operationalYear Total blocked ", totalCreditBlocked, creditExtracts.get(0)
                .getTotalBlockedAmount().getValue());
        Assert.assertEquals("Should have operationalYear total Released ", totalCreditAvaliable, creditExtracts.get(0)
                .getTotalReleasedAmount().getValue());
        Assert.assertEquals("Should have operationalYear total Manual ", BigDecimal.ZERO, creditExtracts.get(0)
                .getTotalManualReceivedAmount().getValue());
        Assert.assertEquals("Should have operationalYear total Extention ", BigDecimal.ZERO, creditExtracts.get(0)
                .getTotalExtendedAmount().getValue());
        Assert.assertEquals("Should have operationalYear total ", totalCreditAvaliable, creditExtracts.get(0)
                .getTotalAvailable());

        DetailedBlockedAndAvaliableCreditAmount details = saleService.getDetailOfAvaliable(creditExtracts.get(0)
                .getDetails().get(0).getReleasedCreditAmount());

        Assert.assertEquals("Should have the same customer of the sale", details.getDecoratedBillings().get(0)
                .getCustomerName(), saleAutomatically.getCustomer().getName());
        Assert.assertEquals("Should have the same billing of the sale", details.getDecoratedBillings().get(0)
                .getBilling().getSaleCode(), saleAutomatically.getId());

    }

    @Test
    public void when_i_want_to_show_detail_of_avaliable_credit_amount_where_status_credit_is_waiting_manually_and_released_automatically()
            throws SaleConstraintViolationException, ConstraintException {

        Sale saleAutomatically = createSaleWithSaleTemplateAutomatically("12345");
        Sale saleManually = createSaleWithSaleTemplateManually("123456");

        List<SummaryCreditExtract> creditExtracts = saleService.getCreditExtract(saleTestFixture.chicoBento,
                systemTestFixture.soy, systemTestFixture.monsantoBr);

        printExtractDetails(creditExtracts);

        SaleItem itemManually = saleManually.getItems().iterator().next();
        BigDecimal totalCreditBlocked = itemManually.getProductivityValue().multiply(new BigDecimal(
                itemManually.getSoldQuantity()));

        SaleItem itemAutomatically = saleAutomatically.getItems().iterator().next();
        BigDecimal totalCreditAvaliable = itemAutomatically.getProductivityValue()
                .multiply(new BigDecimal(itemAutomatically.getSoldQuantity()));

        Assert.assertEquals("Should have operationalYear ", systemTestFixture.operationalYearOf2012, creditExtracts
                .get(0).getOperationalYear());
        Assert.assertEquals("Should have operationalYear Total blocked ", totalCreditBlocked, creditExtracts.get(0)
                .getTotalBlockedAmount().getValue());
        Assert.assertEquals("Should have operationalYear total Released ", totalCreditAvaliable, creditExtracts.get(0)
                .getTotalReleasedAmount().getValue());
        Assert.assertEquals("Should have operationalYear total Manual ", BigDecimal.ZERO, creditExtracts.get(0)
                .getTotalManualReceivedAmount().getValue());
        Assert.assertEquals("Should have operationalYear total Extention ", BigDecimal.ZERO, creditExtracts.get(0)
                .getTotalExtendedAmount().getValue());
        Assert.assertEquals("Should have operationalYear total ", totalCreditAvaliable, creditExtracts.get(0)
                .getTotalAvailable());

        DetailedBlockedAndAvaliableCreditAmount details = saleService.getDetailOfAvaliable(creditExtracts.get(0)
                .getDetails().get(0).getReleasedCreditAmount());

        Assert.assertEquals("Should have the same customer of the sale", details.getDecoratedBillings().get(0)
                .getCustomerName(), saleAutomatically.getCustomer().getName());
        Assert.assertEquals("Should have the same billing of the sale", details.getDecoratedBillings().get(0)
                .getBilling().getSaleCode(), saleAutomatically.getId());

    }

    @Test
    public void when_i_want_to_show_detail_of_avaliable_credit_amount_where_status_credit_is_waiting_manually_and_on_payment_and_released_automatically()
            throws SaleConstraintViolationException, ConstraintException {

        Sale saleAutomatically = createSaleWithSaleTemplateAutomatically("12345");
        Sale saleManually = createSaleWithSaleTemplateManually("123456");
        Sale saleNotPaid = createSaleWithSaleTemplateOnPayment("1234567");
        Sale salePaid = createGenericSale("12345678", saleTestFixture.templateRangeWithDueDateRange);

        payBillingOf(salePaid);

        List<SummaryCreditExtract> creditExtracts = saleService.getCreditExtract(saleTestFixture.chicoBento,
                systemTestFixture.soy, systemTestFixture.monsantoBr);

        printExtractDetails(creditExtracts);

        SaleItem itemBlocked = saleManually.getItems().iterator().next();
        BigDecimal totalCreditBlocked = itemBlocked.getProductivityValue().multiply(new BigDecimal(
                itemBlocked.getSoldQuantity()));

        itemBlocked = saleNotPaid.getItems().iterator().next();
        totalCreditBlocked = totalCreditBlocked.add(itemBlocked.getProductivityValue()
                .multiply(new BigDecimal(itemBlocked.getSoldQuantity())));

        SaleItem itemAvaliable = saleAutomatically.getItems().iterator().next();
        BigDecimal totalCreditAvaliable = itemAvaliable.getProductivityValue().multiply(new BigDecimal(
                itemAvaliable.getSoldQuantity()));

        itemAvaliable = salePaid.getItems().iterator().next();
        totalCreditAvaliable = totalCreditAvaliable.add(itemAvaliable.getProductivityValue()
                .multiply(new BigDecimal(itemBlocked.getSoldQuantity())));

        Assert.assertEquals("Should have operationalYear ", systemTestFixture.operationalYearOf2012, creditExtracts
                .get(0).getOperationalYear());
        Assert.assertEquals("Should have operationalYear Total blocked ", totalCreditBlocked, creditExtracts.get(0)
                .getTotalBlockedAmount().getValue());
        Assert.assertEquals("Should have operationalYear total Released ", totalCreditAvaliable, creditExtracts.get(0)
                .getTotalReleasedAmount().getValue());
        Assert.assertEquals("Should have operationalYear total Manual ", BigDecimal.ZERO, creditExtracts.get(0)
                .getTotalManualReceivedAmount().getValue());
        Assert.assertEquals("Should have operationalYear total Extention ", BigDecimal.ZERO, creditExtracts.get(0)
                .getTotalExtendedAmount().getValue());
        Assert.assertEquals("Should have operationalYear total ", totalCreditAvaliable, creditExtracts.get(0)
                .getTotalAvailable());

        DetailedBlockedAndAvaliableCreditAmount details = saleService.getDetailOfAvaliable(creditExtracts.get(0)
                .getDetails().get(0).getReleasedCreditAmount());

        for (BillingDTO dto : details.getDecoratedBillings()) {
            if (saleAutomatically.getId().equals(dto.getBilling().getSaleCode())) {
                Assert.assertEquals("Should have the same customer of the sale", dto.getCustomerName(),
                        saleAutomatically.getCustomer().getName());
            } else {
                Assert.assertEquals("Should have the same customer of the sale", dto.getCustomerName(), salePaid
                        .getCustomer().getName());
            }
        }

    }

    @Test
    public void when_i_want_to_show_detail_of_blocked_credit_amount_where_not_exist_balance()
            throws SaleConstraintViolationException, ConstraintException {

        Sale sale = createSaleWithSaleTemplateOnPayment(null);

        payBillingOf(sale);

        List<SummaryCreditExtract> creditExtracts = saleService.getCreditExtract(saleTestFixture.chicoBento,
                systemTestFixture.soy, systemTestFixture.monsantoBr);

        printExtractDetails(creditExtracts);

        ICreditAmount creditAmount = creditExtracts.get(0).getDetails().get(0).getBlockedCreditAmount();
        creditAmount.getContentHandles().clear();

        DetailedBlockedAndAvaliableCreditAmount details = saleService.getDetailOfBlocked(creditAmount);

        Assert.assertNull("Should have the detailed null", details);

    }

    @Test
    public void when_I_want_to_show_details_of_avaliable_credit_amount_where_not_exist_balance()
            throws SaleConstraintViolationException, ConstraintException {

        createSaleWithSaleTemplateAutomatically(null);

        List<SummaryCreditExtract> creditExtracts = saleService.getCreditExtract(saleTestFixture.chicoBento,
                systemTestFixture.soy, systemTestFixture.monsantoBr);

        printExtractDetails(creditExtracts);

        ICreditAmount creditAmount = creditExtracts.get(0).getDetails().get(0).getReleasedCreditAmount();
        creditAmount.getContentHandles().clear();

        DetailedBlockedAndAvaliableCreditAmount details = saleService.getDetailOfAvaliable(creditAmount);

        Assert.assertNull("Should have the detailed null", details);

    }

    @Test
    public void given_a_credit_transfer_request_approved_available_than_should_to_return_detail_credit_received()
            throws ManualCreditConstraintException, BusinessException {

        BigDecimal thousand = new BigDecimal(1000);
        accountService.generateCreditManually(systemTestFixture.soy,
                saleTestFixture.harvestSoyMonsanto2012.getOperationalYear(), systemTestFixture.intacta,
                saleTestFixture.chicoBento, ManualCreditTransactionType.CREDIT, thousand, "Test reason 1", "ANDREGC");

        CreditTransferRequest creditTransferRequest = new CreditTransferRequest(systemTestFixture.soy,
                systemTestFixture.intacta, saleTestFixture.chicoBento, saleTestFixture.joaoDaSilva,
                systemTestFixture.reason, "Motivo de transferencia", "JOHN");

        CreditTransferRequestAmount creditTransferRequestAmount = new CreditTransferRequestAmount(thousand,
                saleTestFixture.harvestSoyMonsanto2012.getOperationalYear());
        creditTransferRequest.addCreditTransferRequestAmount(creditTransferRequestAmount);

        accountService.requestAndApproveCreditTransfer(creditTransferRequest,
                accessControlTestFixture.itsParticipantUser);

        List<SummaryCreditExtract> creditExtracts = saleService.getCreditExtract(saleTestFixture.joaoDaSilva,
                systemTestFixture.soy, systemTestFixture.monsantoBr);

        Assert.assertEquals("Should have operationalYear ", systemTestFixture.operationalYearOf2012, creditExtracts
                .get(0).getOperationalYear());
        Assert.assertEquals("Should have operationalYear Total blocked ", BigDecimal.ZERO, creditExtracts.get(0)
                .getTotalBlockedAmount().getValue());
        Assert.assertEquals("Should have operationalYear total Released ", BigDecimal.ZERO, creditExtracts.get(0)
                .getTotalReleasedAmount().getValue());
        Assert.assertEquals("Should have operationalYear total Manual ", BigDecimal.ZERO, creditExtracts.get(0)
                .getTotalManualReceivedAmount().getValue());
        Assert.assertEquals("Should have operationalYear total Extention ", BigDecimal.ZERO, creditExtracts.get(0)
                .getTotalExtendedAmount().getValue());
        Assert.assertEquals("Should have operationalYear total ", thousand, creditExtracts.get(0).getTotalAvailable());
        Assert.assertEquals("Should have operationalYear total ", thousand, creditExtracts.get(0)
                .getTotalTransferReceivedAmount().getValue());

        printExtractDetails(creditExtracts);

        ICreditAmount creditAmount = creditExtracts.get(0).getDetails().get(0).getTransferReceiveCreditAmount();

        DetailTransferCreditAmount details = saleService.getDetailOfTransferReceived(creditAmount);

        Assert.assertNotNull("Should not have the detailed null", details);
        Assert.assertEquals("Should have Hundred ", thousand, details.getTotalVolume());

    }

    @Test
    public void given_two_credit_transfer_request_approved_than_should_to_return_detail_credit_received()
            throws ManualCreditConstraintException, BusinessException {

        BigDecimal thousand = new BigDecimal(1000);
        BigDecimal fiveHundred = new BigDecimal(500);
        accountService.generateCreditManually(systemTestFixture.soy,
                saleTestFixture.harvestSoyMonsanto2012.getOperationalYear(), systemTestFixture.intacta,
                saleTestFixture.chicoBento, ManualCreditTransactionType.CREDIT, thousand, "Test reason 1", "ANDREGC");

        CreditTransferRequest creditTransferRequest = new CreditTransferRequest(systemTestFixture.soy,
                systemTestFixture.intacta, saleTestFixture.chicoBento, saleTestFixture.joaoDaSilva,
                systemTestFixture.reason, "Motivo de transferencia", "JOHN");

        CreditTransferRequestAmount creditTransferRequestAmount = new CreditTransferRequestAmount(fiveHundred,
                saleTestFixture.harvestSoyMonsanto2012.getOperationalYear());
        creditTransferRequest.addCreditTransferRequestAmount(creditTransferRequestAmount);

        accountService.requestAndApproveCreditTransfer(creditTransferRequest,
                accessControlTestFixture.itsParticipantUser);

        creditTransferRequest = new CreditTransferRequest(systemTestFixture.soy, systemTestFixture.intacta,
                saleTestFixture.chicoBento, saleTestFixture.joaoDaSilva, systemTestFixture.reason,
                "Motivo de transferencia", "JOHN");

        creditTransferRequestAmount = new CreditTransferRequestAmount(fiveHundred,
                saleTestFixture.harvestSoyMonsanto2012.getOperationalYear());
        creditTransferRequest.addCreditTransferRequestAmount(creditTransferRequestAmount);

        accountService.requestAndApproveCreditTransfer(creditTransferRequest,
                accessControlTestFixture.itsParticipantUser);

        List<SummaryCreditExtract> creditExtracts = saleService.getCreditExtract(saleTestFixture.joaoDaSilva,
                systemTestFixture.soy, systemTestFixture.monsantoBr);

        Assert.assertEquals("Should have operationalYear ", systemTestFixture.operationalYearOf2012, creditExtracts
                .get(0).getOperationalYear());
        Assert.assertEquals("Should have operationalYear Total blocked ", BigDecimal.ZERO, creditExtracts.get(0)
                .getTotalBlockedAmount().getValue());
        Assert.assertEquals("Should have operationalYear total Released ", BigDecimal.ZERO, creditExtracts.get(0)
                .getTotalReleasedAmount().getValue());
        Assert.assertEquals("Should have operationalYear total Manual ", BigDecimal.ZERO, creditExtracts.get(0)
                .getTotalManualReceivedAmount().getValue());
        Assert.assertEquals("Should have operationalYear total Extention ", BigDecimal.ZERO, creditExtracts.get(0)
                .getTotalExtendedAmount().getValue());
        Assert.assertEquals("Should have operationalYear total ", thousand, creditExtracts.get(0).getTotalAvailable());
        Assert.assertEquals("Should have operationalYear total ", thousand, creditExtracts.get(0)
                .getTotalTransferReceivedAmount().getValue());

        printExtractDetails(creditExtracts);

        ICreditAmount creditAmount = creditExtracts.get(0).getDetails().get(0).getTransferReceiveCreditAmount();

        DetailTransferCreditAmount details = saleService.getDetailOfTransferReceived(creditAmount);

        Assert.assertNotNull("Should not have the detailed null", details);
        Assert.assertEquals("Should have Hundred ", thousand, details.getTotalVolume());

    }

    @Test
    public void given_a_credit_transfer_request_approved_available_than_should_to_return_detail_credit_donated()
            throws ManualCreditConstraintException, BusinessException {

        BigDecimal thousand = new BigDecimal(1000);
        accountService.generateCreditManually(systemTestFixture.soy,
                saleTestFixture.harvestSoyMonsanto2012.getOperationalYear(), systemTestFixture.intacta,
                saleTestFixture.chicoBento, ManualCreditTransactionType.CREDIT, thousand, "Test reason 1", "ANDREGC");

        CreditTransferRequest creditTransferRequest = new CreditTransferRequest(systemTestFixture.soy,
                systemTestFixture.intacta, saleTestFixture.chicoBento, saleTestFixture.joaoDaSilva,
                systemTestFixture.reason, "Motivo de transferencia", "JOHN");

        CreditTransferRequestAmount creditTransferRequestAmount = new CreditTransferRequestAmount(thousand,
                saleTestFixture.harvestSoyMonsanto2012.getOperationalYear());
        creditTransferRequest.addCreditTransferRequestAmount(creditTransferRequestAmount);

        accountService.requestAndApproveCreditTransfer(creditTransferRequest,
                accessControlTestFixture.itsParticipantUser);

        List<SummaryCreditExtract> creditExtracts = saleService.getCreditExtract(saleTestFixture.chicoBento,
                systemTestFixture.soy, systemTestFixture.monsantoBr);

        Assert.assertEquals("Should have operationalYear ", systemTestFixture.operationalYearOf2012, creditExtracts
                .get(0).getOperationalYear());
        Assert.assertEquals("Should have operationalYear Total blocked ", BigDecimal.ZERO, creditExtracts.get(0)
                .getTotalBlockedAmount().getValue());
        Assert.assertEquals("Should have operationalYear total Released ", BigDecimal.ZERO, creditExtracts.get(0)
                .getTotalReleasedAmount().getValue());
        Assert.assertEquals("Should have operationalYear total Manual ", thousand, creditExtracts.get(0)
                .getTotalManualReceivedAmount().getValue());
        Assert.assertEquals("Should have operationalYear total Extention ", BigDecimal.ZERO, creditExtracts.get(0)
                .getTotalExtendedAmount().getValue());
        Assert.assertEquals("Should have operationalYear total available", BigDecimal.ZERO, creditExtracts.get(0)
                .getTotalAvailable());
        Assert.assertEquals("Should have operationalYear total received", BigDecimal.ZERO, creditExtracts.get(0)
                .getTotalTransferReceivedAmount().getValue());
        Assert.assertEquals("Should have operationalYear total transfer donated", thousand, creditExtracts.get(0)
                .getTotalTransferDonatedAmount().getValue());
        Assert.assertEquals("should have operationalYear total creditConsumption", BigDecimal.ZERO,
                creditExtracts.get(0).getTotalCreditConsumptionAmount().getValue());
        printExtractDetails(creditExtracts);

        TransferDonatedCreditAmount creditAmount = (TransferDonatedCreditAmount) creditExtracts.get(0).getDetails()
                .get(0).getTransferDonatedCreditAmount();

        DetailTransferCreditAmount details = saleService.getDetailOfTransferDonated(creditAmount);

        Assert.assertNotNull("Should not have the detailed null", details);
        Assert.assertEquals("Should have Hundred ", thousand, details.getTotalVolume());

    }

    @Test
    public void given_a_credit_transfer_request_not_approved_available_than_should_to_return_detail_credit_reserved()
            throws ManualCreditConstraintException, BusinessException {

        BigDecimal thousand = new BigDecimal(1000);
        accountService.generateCreditManually(systemTestFixture.soy,
                saleTestFixture.harvestSoyMonsanto2012.getOperationalYear(), systemTestFixture.intacta,
                saleTestFixture.chicoBento, ManualCreditTransactionType.CREDIT, thousand, "Test reason 1", "ANDREGC");

        CreditTransferRequest creditTransferRequest = new CreditTransferRequest(systemTestFixture.soy,
                systemTestFixture.intacta, saleTestFixture.chicoBento, saleTestFixture.joaoDaSilva,
                systemTestFixture.reason, "Motivo de transferencia", "JOHN");

        CreditTransferRequestAmount creditTransferRequestAmount = new CreditTransferRequestAmount(thousand,
                saleTestFixture.harvestSoyMonsanto2012.getOperationalYear());
        creditTransferRequest.addCreditTransferRequestAmount(creditTransferRequestAmount);

        accountService.requestCreditTransfer(creditTransferRequest);

        List<SummaryCreditExtract> creditExtracts = saleService.getCreditExtract(saleTestFixture.chicoBento,
                systemTestFixture.soy, systemTestFixture.monsantoBr);

        Assert.assertEquals("Should have operationalYear ", systemTestFixture.operationalYearOf2012, creditExtracts
                .get(0).getOperationalYear());
        Assert.assertEquals("Should have operationalYear Total blocked ", BigDecimal.ZERO, creditExtracts.get(0)
                .getTotalBlockedAmount().getValue());
        Assert.assertEquals("Should have operationalYear total Released ", BigDecimal.ZERO, creditExtracts.get(0)
                .getTotalReleasedAmount().getValue());
        Assert.assertEquals("Should have operationalYear total Manual ", thousand, creditExtracts.get(0)
                .getTotalManualReceivedAmount().getValue());
        Assert.assertEquals("Should have operationalYear total Extention ", BigDecimal.ZERO, creditExtracts.get(0)
                .getTotalExtendedAmount().getValue());
        Assert.assertEquals("Should have operationalYear total available", BigDecimal.ZERO, creditExtracts.get(0)
                .getTotalAvailable());
        Assert.assertEquals("Should have operationalYear total received", BigDecimal.ZERO, creditExtracts.get(0)
                .getTotalTransferReceivedAmount().getValue());
        Assert.assertEquals("Should have operationalYear total transfer donated", BigDecimal.ZERO, creditExtracts
                .get(0).getTotalTransferDonatedAmount().getValue());
        Assert.assertEquals("Should have operationalYear total transfer donated", thousand, creditExtracts.get(0)
                .getTotalReserveAmount().getValue());

        printExtractDetails(creditExtracts);

        ReservedCreditAmount creditAmount = (ReservedCreditAmount) creditExtracts.get(0).getDetails().get(0)
                .getReserveCreditAmount();

        DetailTransferCreditAmount details = saleService.getDetailOfReservedCredit(creditAmount);

        Assert.assertNotNull("Should not have the detailed null", details);
        Assert.assertEquals("Should have zero ", thousand, details.getTotalVolume());

    }

    @Test
    public void given_aManual_generate_credited_when_show_credit_available_then_retrieve_detail_of_manual_recieve()
            throws ManualCreditConstraintException, BusinessException {

        accountService.generateCreditManually(systemTestFixture.soy, systemTestFixture.operationalYearOf2012,
                systemTestFixture.intacta, saleTestFixture.chicoBento, ManualCreditTransactionType.CREDIT, BigDecimal.TEN,
                "Tests", "ANDREGC");

        List<SummaryCreditExtract> creditExtracts = saleService.getCreditExtract(saleTestFixture.chicoBento,
                systemTestFixture.soy, systemTestFixture.monsantoBr);

        ICreditAmount creditAmount = creditExtracts.get(0).getDetails().get(0).getManualCreditAmount();

        DetailManualCreditAmount detailManualReceived = saleService.getDetailOfManualReceivedCredit(creditAmount);

        Assert.assertNotNull("Should have the detailed not null", detailManualReceived.getCredits());
        Assert.assertEquals("Should have the detailed technology", systemTestFixture.intacta, detailManualReceived
                .getCredits().get(0).getTechnology());
        Assert.assertNotNull("Should have the detailed creditDate", detailManualReceived.getCredits().get(0)
                .getCreditDate());
        Assert.assertEquals("Should have the detailed Value", BigDecimal.TEN, detailManualReceived.getCredits().get(0)
                .getValue());
        Assert.assertEquals("Should have the detailed Reason", "TESTS", detailManualReceived.getCredits().get(0)
                .getReason());

    }

    @Test
    public void given_aManual_generate_debited_when_show_credit_available_then_retrieve_detail_of_manual_recieve()
            throws ManualCreditConstraintException, BusinessException {

        accountService.generateCreditManually(systemTestFixture.soy, systemTestFixture.operationalYearOf2012,
                systemTestFixture.intacta, saleTestFixture.chicoBento, ManualCreditTransactionType.CREDIT, BigDecimal.TEN,
                "Tests", "ANDREGC");

        accountService.generateCreditManually(systemTestFixture.soy, systemTestFixture.operationalYearOf2012,
                systemTestFixture.intacta, saleTestFixture.chicoBento, ManualCreditTransactionType.DEBIT, BigDecimal.TEN,
                "Tests", "ANDREGC");

        List<SummaryCreditExtract> creditExtracts = saleService.getCreditExtract(saleTestFixture.chicoBento,
                systemTestFixture.soy, systemTestFixture.monsantoBr);

        ICreditAmount creditAmount = creditExtracts.get(0).getDetails().get(0).getManualChargedCreditAmount();

        DetailManualCreditAmount detailManualReceived = saleService.getDetailOfManualChargedCredit(creditAmount);

        Assert.assertNotNull("Should have the detailed not null", detailManualReceived.getCredits());
        Assert.assertEquals("Should have the detailed technology", systemTestFixture.intacta, detailManualReceived
                .getCredits().get(0).getTechnology());
        Assert.assertNotNull("Should have the detailed creditDate", detailManualReceived.getCredits().get(0)
                .getCreditDate());
        Assert.assertEquals("Should have the detailed Value", BigDecimal.TEN, detailManualReceived.getCredits().get(0)
                .getValue());
        Assert.assertEquals("Should have the detailed Reason", "TESTS", detailManualReceived.getCredits().get(0)
                .getReason());

    }

    private void generateManualCreditTestData() throws BusinessException, ManualCreditConstraintException {
        accountService.generateCreditManually(systemTestFixture.soy,
                saleTestFixture.harvest2009SoyMonsanto.getOperationalYear(), systemTestFixture.bt,
                saleTestFixture.chicoBento, ManualCreditTransactionType.CREDIT, SaleTestFixture.EIGHT_DOLLARS,
                "Test reason 1", "ANDREGC");
        accountService.generateCreditManually(systemTestFixture.soy,
                saleTestFixture.harvest2011SoyMonsanto.getOperationalYear(), systemTestFixture.bt,
                saleTestFixture.joaoDaSilva, ManualCreditTransactionType.CREDIT, SaleTestFixture.FIVE_DOLLARS,
                "Test reason 2", "ANDREGC");

        accountService.generateCreditManually(systemTestFixture.soy,
                saleTestFixture.harvestSoyMonsanto2012.getOperationalYear(), systemTestFixture.intacta,
                saleTestFixture.chicoBento, ManualCreditTransactionType.CREDIT, BigDecimal.TEN, "Test reason 3", "ANDREGC");
        accountService.generateCreditManually(systemTestFixture.soy,
                saleTestFixture.harvestSoyMonsanto2012.getOperationalYear(), systemTestFixture.bt,
                saleTestFixture.chicoBento, ManualCreditTransactionType.CREDIT, BigDecimal.TEN, "Test reason 3", "ANDREGC");

        accountService.generateCreditManually(systemTestFixture.soy,
                saleTestFixture.harvest2011SoyMonsanto.getOperationalYear(), systemTestFixture.bt,
                saleTestFixture.joaoDaSilva, ManualCreditTransactionType.DEBIT, BigDecimal.ONE, "Test reason 2", "ANDREGC");

    }

    private void generateCreditExpirationTo(OperationalYear year, Crop crop, Technology tech, Date expiration,
            Date extension) {
        CreditExpiration credit = new CreditExpiration(crop, tech, year, expiration, extension);

        saveAndFlush(credit);
    }

    private void payBillingOf(Sale sale) throws BillingConstraintViolationException {
        BillingFilter billingFilter = BillingFilter.getInstance().add(sale.getId())
                .add(accessControlTestFixture.superUser);

        Billing billingForPay = saleService.getBillingBy(billingFilter).iterator().next();
        try { saleService.payBilling(billingForPay, billingForPay.getLastPaymentDate(), billingForPay.getDueValue(),
                Boolean.TRUE);
        } catch (BusinessException e) {
            e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
        }       
        Assert.assertTrue("Should pay the billing", billingForPay.isPaid());
    }

    private Sale createSaleWithSaleTemplateManually(String invoiceNumber) throws SaleConstraintViolationException {

        saleTestFixture.templateFixWithDueDateRange.getPriceOf(saleTestFixture.productIntactaSoy.getTechnology())
                .setReleaseCreditType(ReleaseCreditTypeEnum.MANUALLY);
        saveAndFlush(saleTestFixture.templateFixWithDueDateRange);

        return createGenericSale(invoiceNumber, saleTestFixture.templateFixWithDueDateRange);
    }

    private Sale createSaleWithSaleTemplateOnPayment(String invoiceNumber) throws SaleConstraintViolationException {

        saleTestFixture.templateRangeWithDueDateRange.getPriceOf(saleTestFixture.productIntactaSoy.getTechnology())
                .setReleaseCreditType(ReleaseCreditTypeEnum.ON_PAYMENT);
        saveAndFlush(saleTestFixture.templateRangeWithDueDateRange);

        return createGenericSale(invoiceNumber, saleTestFixture.templateRangeWithDueDateRange);
    }

    private Sale createSaleWithSaleTemplateAutomatically(String invoiceNumber) throws SaleConstraintViolationException {

        saleTestFixture.templateFreeWithDueDateRange.getPriceOf(saleTestFixture.productIntactaSoy.getTechnology())
                .setReleaseCreditType(ReleaseCreditTypeEnum.AUTOMATICALLY);
        saveAndFlush(saleTestFixture.templateFreeWithDueDateRange);

        return createGenericSale(invoiceNumber, saleTestFixture.templateFreeWithDueDateRange);
    }

    private Sale createGenericSale(String invoiceNumber, SaleTemplate saleTemplate)
            throws SaleConstraintViolationException {

        builder = new SaleBuilder(systemTestFixture.matoGrossoDoSul, saleTestFixture.plantabilitiesSelector);

        builder.clear();
        builder.addSaleItem(saleTestFixture.productIntactaSoy, saleTemplate, saleTestFixture.officeCustomer, 2000L,
                SaleTestFixture.TWO_POINT_FIVE_DOLLARS, saleTestFixture.plantabilitySystemSoyMonsanto2012,
                SaleTestFixture.APRIL);

        Sale sale = builder.setGrower(saleTestFixture.chicoBento).setCustomer(saleTestFixture.customer).buildSale();
        sale.setCreationDate(SaleTestFixture.DATE_NOW);
        sale.setRegion(systemTestFixture.regionSaoPaulo2012);

        if (invoiceNumber != null) {
            sale.setInvoiceNumber(invoiceNumber);
        }

        accessControlTestFixture.superUser.setContextCrop(systemTestFixture.soy);
        accessControlTestFixture.superUser.setContextCompany(systemTestFixture.monsantoBr);

        saleService.save(sale, accessControlTestFixture.superUser);
        return sale;
    }

}
