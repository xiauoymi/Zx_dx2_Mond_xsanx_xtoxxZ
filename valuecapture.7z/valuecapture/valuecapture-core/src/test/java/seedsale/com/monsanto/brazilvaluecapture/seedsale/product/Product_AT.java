package com.monsanto.brazilvaluecapture.seedsale.product;

import java.sql.SQLException;
import java.util.List;

import org.hibernate.SessionFactory;
import org.hibernate.classic.Session;
import org.hibernate.exception.ConstraintViolationException;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;

import com.monsanto.brazilvaluecapture.core.base.SystemTestFixture;
import com.monsanto.brazilvaluecapture.core.foundation.model.bean.StatusEnum;
import com.monsanto.brazilvaluecapture.core.foundation.service.BusinessException;
import com.monsanto.brazilvaluecapture.core.foundation.test.AbstractServiceIntegrationTests;
import com.monsanto.brazilvaluecapture.seedsale.product.model.bean.Product;
import com.monsanto.brazilvaluecapture.seedsale.product.model.dao.ProductDAO;
import com.monsanto.brazilvaluecapture.seedsale.product.model.dao.ProductFilter;
import com.monsanto.brazilvaluecapture.seedsale.product.model.dao.ProductivityDAO;
import com.monsanto.brazilvaluecapture.seedsale.product.model.dao.impl.ProductDAOImpl;
import com.monsanto.brazilvaluecapture.seedsale.product.service.ProductWithAssociatedSaleTemplateException;
import com.monsanto.brazilvaluecapture.seedsale.sale.SaleTestFixture;

public class Product_AT extends AbstractServiceIntegrationTests {

	@Autowired
    private ProductDAO producDAO;
	
	@Autowired
	ProductivityDAO productivityDAO;

	@Before
	public void init() {
		systemTestFixture = new SystemTestFixture(this);
		saleTestFixture = new SaleTestFixture(systemTestFixture);
	}
	
	@Test
	public void when_doesNotHave_negotiableProducts_then_returnEmptyCollection() {
		//TODO: For Sale screen
	}
	
	
	@Test
    public void when_aProductDoesNotExist_save_shouldBeSuccess() throws BusinessException {
		Product aProduct = ProductTestData.createProduct(this.systemTestFixture.monsoy, this.systemTestFixture.soy, this.systemTestFixture.intacta, StatusEnum.ACTIVE, this.systemTestFixture.monsantoBr);
		producDAO.save(aProduct);
		getSession().flush();
    	
        Assert.assertNotNull(aProduct.getId());
    }
	
	@Test
    public void testSelectById() {
		Product productCreated = ProductTestData.createProduct(this.systemTestFixture.monsoy, this.systemTestFixture.soy, this.systemTestFixture.intacta, StatusEnum.ACTIVE, this.systemTestFixture.monsantoBr);
		getSession().saveOrUpdate(productCreated);
		Long id = productCreated.getId();
		
        Assert.assertNotNull("Should have a product", producDAO.selectById(id));
    }
    
	@Test
    public void testDelete() throws BusinessException {
		Product productCreated = ProductTestData.createProduct(this.systemTestFixture.monsoy, this.systemTestFixture.soy, this.systemTestFixture.intacta, StatusEnum.ACTIVE, this.systemTestFixture.monsantoBr);
		getSession().saveOrUpdate(productCreated);
		getSession().flush();
        Long id = productCreated.getId();
        
        producDAO.delete(productCreated);
        
        Assert.assertNull("Product should have been deleted.", producDAO.selectById(id));
    }

	@Test
    public void when_productFilterHasCompanyAndCropAndDescription_and_existOneProductThatMatch_shouldBeReturn_aListWithProducts() {
		Product productThatMatch = ProductTestData.createProduct(this.systemTestFixture.monsoy, this.systemTestFixture.soy, this.systemTestFixture.intacta, StatusEnum.ACTIVE, this.systemTestFixture.monsantoBr);
		getSession().saveOrUpdate(productThatMatch);

		Product productThatDoesNotMatch = ProductTestData.createProduct(this.systemTestFixture.monsoy, this.systemTestFixture.soy, this.systemTestFixture.intacta, StatusEnum.ACTIVE, this.systemTestFixture.monsantoBr);
		productThatDoesNotMatch.setDescription("MyDescriptionUpdated");
		getSession().saveOrUpdate(productThatDoesNotMatch);
    	
		ProductFilter productFilter = ProductFilter.getInstance().add(this.systemTestFixture.monsantoBr).add(this.systemTestFixture.soy).add(productThatMatch);
    	
    	List<Product> products = producDAO.selectByFilter(productFilter);
    	
    	Assert.assertNotNull(products);
    	Assert.assertEquals("Should have exactaly one product", 1, products.size());
    	Assert.assertEquals("Returned product and productThatMatch should have same id.", productThatMatch.getId(), products.get(0).getId());
    }

    @Test
    public void when_productFilterHasAllProductAttributes_and_existOneProductThatMatch_shouldBeReturn_aListWithProducts() {
		Product productThatMatch = ProductTestData.createProduct(this.systemTestFixture.monsoy, this.systemTestFixture.soy, this.systemTestFixture.intacta, StatusEnum.ACTIVE, this.systemTestFixture.monsantoBr);
		getSession().saveOrUpdate(productThatMatch);

		ProductFilter productFilter = ProductFilter.getInstance().add(this.systemTestFixture.monsantoBr).add(this.systemTestFixture.monsoy).add(this.systemTestFixture.intacta).add(this.systemTestFixture.soy).add(productThatMatch);
    	List<Product> products = producDAO.selectByFilter(productFilter);
    	
    	Assert.assertNotNull("Products should not be null", products);
    	Assert.assertEquals("Should have one product", 1, products.size());
    }
    
    @Test
    public void when_productFilter_doesNotMatch_anyProduct_shouldBeReturn_emptyList() {
    	ProductFilter productFilter = ProductFilter.getInstance().add(this.systemTestFixture.monsantoBr).add(this.systemTestFixture.monsoy).add(this.systemTestFixture.intacta).add(this.systemTestFixture.soy);
    	
    	List<Product> products = producDAO.selectByFilter(productFilter);
    	
    	Assert.assertNotNull("Products should not be null", products);
    	Assert.assertEquals("Should have no products", 0, products.size());
    }

	@Test
	public void given_a_new_product_with_product_sap_code_when_i_search_should_return_a_product_with_the_given_code() throws BusinessException {
		Product productWithSapCode = saleTestFixture.productBtSoy;
		productWithSapCode.setProductSapCode("sap code");
		
		saveAndFlush(productWithSapCode);
		
		Product updatedProduct = producDAO.selectById(productWithSapCode.getId());
		
		Assert.assertNotNull("Should not be null", updatedProduct.getProductSapCode());
		Assert.assertEquals("Should have product sap code in product", "sap code", updatedProduct.getProductSapCode());
	}
	
	@Test(expected=ConstraintViolationException.class)
	public void test_delete_throw_constraintViolationException() throws ProductWithAssociatedSaleTemplateException {
		SessionFactory sessionFactory =Mockito.mock(SessionFactory.class);
		Session session = Mockito.mock(Session.class);
		Mockito.stub(sessionFactory.getCurrentSession()).toReturn(session);
		ConstraintViolationException exception = new ConstraintViolationException("Exception", new SQLException("MESSAGE"), "FK");
		//Mockito.stub(session.delete(Mockito.any())).toThrow(exception);
		Mockito.doThrow(exception).when(session).delete(Mockito.any());
		ProductDAO dao = new ProductDAOImpl(sessionFactory);
		dao.delete(saleTestFixture.productBtSoy);
		
	}
	
	@Test(expected=ProductWithAssociatedSaleTemplateException.class)
	public void test_delete_throw_productWithAssociatedSaleTemplateException() throws ProductWithAssociatedSaleTemplateException {
		SessionFactory sessionFactory =Mockito.mock(SessionFactory.class);
		Session session = Mockito.mock(Session.class);
		Mockito.stub(sessionFactory.getCurrentSession()).toReturn(session);
		ConstraintViolationException exception = new ConstraintViolationException("Exception", new SQLException("FK_SALE_TEM_FK_PRODUC_PRODUCT"), "FK");
		Mockito.doThrow(exception).when(session).delete(Mockito.any());
		ProductDAO dao = new ProductDAOImpl(sessionFactory);
		dao.delete(saleTestFixture.productBtSoy);
		
	}
	
	@Test(expected=ConstraintViolationException.class)
	public void test_save_throw_ConstraintViolationException() throws BusinessException {
		SessionFactory sessionFactory =Mockito.mock(SessionFactory.class);
		Session session = Mockito.mock(Session.class);
		Mockito.stub(sessionFactory.getCurrentSession()).toReturn(session);
		ConstraintViolationException exception = new ConstraintViolationException("Exception", new SQLException("FK_SALE_TEM_FK_PRODUC_PRODUCT"), "FK");
		Mockito.doThrow(exception).when(session).saveOrUpdate(Mockito.any());
		ProductDAO dao = new ProductDAOImpl(sessionFactory);
		dao.save(saleTestFixture.productBtSoy);
		
	}
	
	@Test(expected=BusinessException.class)
	public void test_save_throw_businessException() throws BusinessException {
		SessionFactory sessionFactory =Mockito.mock(SessionFactory.class);
		Session session = Mockito.mock(Session.class);
		Mockito.stub(sessionFactory.getCurrentSession()).toReturn(session);
		ConstraintViolationException exception = new ConstraintViolationException("Exception", new SQLException("UQ_PRODUCT1"), "FK");
		Mockito.doThrow(exception).when(session).saveOrUpdate(Mockito.any());
		ProductDAO dao = new ProductDAOImpl(sessionFactory);
		dao.save(saleTestFixture.productBtSoy);
		
	}
	
}
