package com.monsanto.brazilvaluecapture.seedsale.billing.service;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.stub;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.monsanto.brazilvaluecapture.core.base.model.bean.Company;
import com.monsanto.brazilvaluecapture.core.user.model.bean.ItsUser;
import com.monsanto.brazilvaluecapture.core.user.model.bean.ItsUser.UserTypeEnum;
import com.monsanto.brazilvaluecapture.core.user.model.bean.UserContext;
import com.monsanto.brazilvaluecapture.core.user.model.bean.UserDecorator;
import com.monsanto.brazilvaluecapture.seedsale.billing.model.dao.BillingFilter;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.Sale;

/**
 * 
 * @author rgaldino
 *
 */
public class BillingFilter_UT {

	private BillingFilter billingFilter;
	
	@Before
	public void setup(){
		billingFilter = BillingFilter.getInstance();	
	}
	
	@Test
	public void when_i_addUserCriteria_participant_billingFilter_shouldNotHaveCriteria() {
		ItsUser loggedUser = new ItsUser("login", UserTypeEnum.PARTICIPANT);
		UserContext user = new UserDecorator(null, loggedUser);
		
		billingFilter.add(user);
		
		Assert.assertEquals("Should not return 0 criteria", 0, billingFilter.countCriterias());
	}
	
	@Test
	public void when_i_addUserCriteria_administrator_billingFilter_shouldHaveOneCriteria() {
		ItsUser loggedUser = new ItsUser("login", UserTypeEnum.ADMINISTRATOR);
		UserContext user = new UserDecorator(null, loggedUser);
		
		user.setContextCompany(new Company());
		
		billingFilter.add(user);
		
		Assert.assertEquals("Should not return 1 criteria", 1, billingFilter.countCriterias());
	}
	
	
	@Test
	public void when_i_addSaleCriteria_billingFilter_shouldHaveOneCriteria() {
		Sale sale = mock(Sale.class);
		stub(sale.getId()).toReturn(1L);
		
		billingFilter.add(sale.getId());
		
		Assert.assertEquals("Should not return 1 criteria", 1, billingFilter.countCriterias());
	}

	@Test
	public void when_i_addCompanyCriteria_billingFilter_shouldHaveOneCriteria() {
		Company company = new Company();
			
		billingFilter.add(company);
		
		Assert.assertEquals("Should not return 1 criteria", 1, billingFilter.countCriterias());
	}
	
}
