package com.monsanto.brazilvaluecapture.seedsale.mixed.service;

import com.monsanto.brazilvaluecapture.core.base.model.bean.Company;
import com.monsanto.brazilvaluecapture.core.base.model.dao.CompanyDAO;
import com.monsanto.brazilvaluecapture.core.base.model.dao.TechnologyDAO;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Technology;
import com.monsanto.brazilvaluecapture.core.foundation.test.AbstractServiceIntegrationTests;
import com.monsanto.brazilvaluecapture.core.foundation.test.dbunit.DbUnitHelper;
import com.monsanto.brazilvaluecapture.core.grower.model.bean.Grower;
import com.monsanto.brazilvaluecapture.core.grower.model.dao.GrowerDAO;
import com.monsanto.brazilvaluecapture.seedsale.harvest.model.bean.Harvest;
import com.monsanto.brazilvaluecapture.seedsale.harvest.model.dao.HarvestDAO;
import com.monsanto.brazilvaluecapture.seedsale.mixed.model.bean.QuotaMixed;
import com.monsanto.brazilvaluecapture.seedsale.mixed.model.dao.QuotaMixedDAO;
import com.monsanto.brazilvaluecapture.seedsale.mixed.model.dao.QuotaMixedTransactionDAO;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.Sale;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.SaleItem;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import java.util.HashSet;
import java.util.Set;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class QuotaMixedService_AT extends AbstractServiceIntegrationTests {

    @Autowired
	private QuotaMixedService quotaMixedService;
    @Autowired
    private QuotaMixedDAO quotaMixedDAO;
    @Autowired
    private QuotaMixedTransactionDAO quotaMixedTransactionDAO;
    @Autowired
    private GrowerDAO growerDAO;
    @Autowired
    private HarvestDAO harvestDAO;
    @Autowired
    private TechnologyDAO technologyDAO;
    @Autowired
    private CompanyDAO companyDAO;

    private Grower growerWithExistingQuota;
    private Harvest harvest;
    private Company company;
    private Technology technology;

    //mocks
    private Sale validSale;
    private Sale invalidSale;

    @Before
	public void setup() throws Exception {
		DbUnitHelper.setup("classpath:data/seedsale/mixed/mixed-quota-dataset.xml");
        growerWithExistingQuota = growerDAO.selectBy(900000001L);
        harvest = harvestDAO.selectById(900000001L);
        company = companyDAO.selectById(900000001L);
        technology = technologyDAO.findTechnologyByCandidateKey("INTACTA", company);

        validSale = getSaleMock(100L);
        invalidSale = getSaleMock(101L);
    }

    private Sale getSaleMock(Long totalCreditValue) {
        Sale sale;
        SaleItem saleItem = mock(SaleItem.class);
        when(saleItem.getHarvest()).thenReturn(harvest);
        when(saleItem.getTechnology()).thenReturn(technology);
        Set<SaleItem> saleItems = new HashSet<SaleItem>();
        saleItems.add(saleItem);
        sale = mock(Sale.class);
        when(sale.getGrower()).thenReturn(growerWithExistingQuota);
        when(sale.getItems()).thenReturn(saleItems);
        when(saleItem.getSoldQuantity()).thenReturn(totalCreditValue);
        when(sale.getTotalCreditValue()).thenReturn(totalCreditValue);
        return sale;
    }

    private QuotaMixed getExistingQuotaMixed() {
        return quotaMixedDAO.findBy(growerWithExistingQuota, harvest, technology);
    }

    private int getNumberOfExistingQuotaTransactions() {
        return quotaMixedTransactionDAO.findAll().size();
    }

    @Test
	public void testUpdateQuota() {
        Long existingQuotaBalance = new Long(getExistingQuotaMixed().getBalance());
        int numberOfExistingQuotaTransactions = getNumberOfExistingQuotaTransactions();
        quotaMixedService.updateQuota(validSale);
        QuotaMixed updatedQuotaMixed = getExistingQuotaMixed();
        int numberOfQuotaTransactionsAfterUpdate = getNumberOfExistingQuotaTransactions();
        Assert.assertEquals(new Long(updatedQuotaMixed.getBalance()), new Long(existingQuotaBalance-validSale.getTotalCreditValue()));
        Assert.assertEquals(new Integer(numberOfQuotaTransactionsAfterUpdate), new Integer(numberOfExistingQuotaTransactions+1));
    }

    private void testHasValidAmountOfTons(Sale sale, boolean mustBeValid) {
        boolean isValidSale = quotaMixedService.hasValidAmountOfTons(sale);
        Assert.assertEquals(isValidSale, mustBeValid);
    }

    @Test
	public void testHasValidAmountOfTons_invalid() {
        testHasValidAmountOfTons(validSale, true);
    }

    @Test
	public void testHasValidAmountOfTons_valid() {
        testHasValidAmountOfTons(invalidSale, false);
    }

    @Test
	public void testUpdateQuotaFromCancellation() {
        Long existingQuotaBalance = new Long(getExistingQuotaMixed().getBalance());
        int numberOfExistingQuotaTransactions = getNumberOfExistingQuotaTransactions();
        quotaMixedService.updateQuotaFromCancellation(validSale);
        QuotaMixed updatedQuotaMixed = getExistingQuotaMixed();
        int numberOfQuotaTransactionsAfterUpdate = getNumberOfExistingQuotaTransactions();
        Assert.assertEquals(new Long(updatedQuotaMixed.getBalance()), new Long(existingQuotaBalance + validSale.getTotalCreditValue()));
        Assert.assertEquals(new Integer(numberOfQuotaTransactionsAfterUpdate), new Integer(numberOfExistingQuotaTransactions + validSale.getItems().size()));
    }
}