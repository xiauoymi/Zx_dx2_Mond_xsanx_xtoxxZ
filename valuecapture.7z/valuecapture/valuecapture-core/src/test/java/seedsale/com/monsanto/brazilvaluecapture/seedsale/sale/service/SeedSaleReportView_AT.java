package com.monsanto.brazilvaluecapture.seedsale.sale.service;

import com.monsanto.CountriesHolderInitializer;
import com.monsanto.brazilvaluecapture.core.base.CityTestData;
import com.monsanto.brazilvaluecapture.core.base.SystemTestFixture;
import com.monsanto.brazilvaluecapture.core.base.model.bean.City;
import com.monsanto.brazilvaluecapture.core.base.model.bean.CityHierarchyDetailView;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Company;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Crop;
import com.monsanto.brazilvaluecapture.core.commercialhierarchy.model.bean.*;
import com.monsanto.brazilvaluecapture.core.customer.CustomerTestData;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Customer;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.CustomerHierarchyDetailView;
import com.monsanto.brazilvaluecapture.core.foundation.service.BusinessException;
import com.monsanto.brazilvaluecapture.core.foundation.service.IndustrySystemOperationException;
import com.monsanto.brazilvaluecapture.core.foundation.test.AbstractServiceIntegrationTests;
import com.monsanto.brazilvaluecapture.core.regionalization.CountriesHolder;
import com.monsanto.brazilvaluecapture.core.user.AccessControlTestFixture;
import com.monsanto.brazilvaluecapture.core.user.model.bean.HierarchyLevel;
import com.monsanto.brazilvaluecapture.core.user.model.bean.ItsUser;
import com.monsanto.brazilvaluecapture.core.user.model.bean.UserDecorator;
import com.monsanto.brazilvaluecapture.core.user.service.UserService;
import com.monsanto.brazilvaluecapture.seedsale.billing.model.bean.Billing;
import com.monsanto.brazilvaluecapture.seedsale.billing.model.bean.PaymentStatus;
import com.monsanto.brazilvaluecapture.seedsale.billing.model.bean.PaymentStatusGroup.PaymentStatusAll;
import com.monsanto.brazilvaluecapture.seedsale.billing.model.dao.BillingFilter;
import com.monsanto.brazilvaluecapture.seedsale.billing.service.BillingConstraintViolationException;
import com.monsanto.brazilvaluecapture.seedsale.sale.SaleTestFixture;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.Sale;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.Sale.SaleTypeEnum;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.SaleItem;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.dao.AbstractSeedSaleReportFilter;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.dao.SeedSaleReportViewFilter;
import com.monsanto.brazilvaluecapture.seedsale.sale.report.SeedSaleReportDTO;
import com.monsanto.brazilvaluecapture.seedsale.sale.report.model.bean.SeedSaleReportWithoutHierView;
import com.monsanto.brazilvaluecapture.seedsale.template.model.bean.SaleTemplateBillingMethodEnum;
import junit.framework.Assert;
import org.hibernate.criterion.Restrictions;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

public class SeedSaleReportView_AT extends AbstractServiceIntegrationTests {
	
	private static final String GROWER_DUPLICATED_HIERARCHY_MESSAGE = "label.seedsale.report.grower.duplicated.hierarchy";
    private static final String MATRIX_DUPLICATED_HIERARCHY_MESSAGE = "label.seedsale.report.customer.parent.duplicated.hierarchy";
	private static final String PARTNER_DUPLICATED_HIERARCHY_MESSAGE = "label.seedsale.report.customer.duplicated.hierarchy";
	@Autowired
	private SaleService saleService;
	@Autowired
	private UserService userServices;
	
	private SaleItemFactory saleItemFactory;
	
	@Autowired
    private CountriesHolder countriesHolder;

    private SaleTestData salefactory;
	
	@Before
	public void init() throws BusinessException {
		systemTestFixture = new SystemTestFixture(this);
		accessControlTestFixture = new AccessControlTestFixture(this, systemTestFixture);
		saleTestFixture = new SaleTestFixture(this, systemTestFixture);
		saleItemFactory = SaleItemFactory.getInstance(systemTestFixture.matoGrossoDoSul, saleTestFixture.plantabilitiesSelector);
		
		CommercialHierType commercialHierType = (CommercialHierType) getSession()
		        .createCriteria(CommercialHierType.class, "c")
		        .add(Restrictions.eq("c.commercialHierTypeDesc", CommercialHierarchyType.DISTRIBUTOR.getValue()))
		        .uniqueResult();
		
		CustomerDistrict customerDistrict = (CustomerDistrict) getSession().createCriteria(CustomerDistrict.class)
                .add(Restrictions.eq("customer", saleTestFixture.matrixCargil)).uniqueResult();
		customerDistrict.setCommercialHierType(commercialHierType);
		saveAndFlush(customerDistrict);
		
		systemTestFixture.commercialHierarchyMonsantoSoy.setCommercialHierType(commercialHierType);
		saveAndFlush(systemTestFixture.commercialHierarchyMonsantoSoy);
		
		createChargeConsolidateTypes();
		
		//Added for LASVC to return a country brazil
        CountriesHolderInitializer.initialize(countriesHolder);

        salefactory = new SaleTestData(systemTestFixture.regionSaoPaulo2012);
	}
	
	@Test
	public void given_a_sale_when_an_adminUser_with_selected_company_see_sales_for_details_shouldReturn_sales_only_of_his_company() throws BusinessException {
		Sale sale = createSaleWithOneFixItemAndOneNoValueItem();
		saveAValidSaleForAParticipant(sale);
		createSeedSaleReportView(sale);
		
		AbstractSeedSaleReportFilter filter = SeedSaleReportViewFilter.getInstance(
				accessControlTestFixture.userAdminOfMonsantoBr,
				accessControlTestFixture.userAdminOfMonsantoBr.getContextCompany()).
				addCreationDateEnd(new Date());
		
		List<SeedSaleReportDTO> sales = saleService.getSalesBy(filter);
		
		Assert.assertEquals("Filter should return 1 sales", 1, sales.size());
	}

	private void createSeedSaleReportView(Sale sale) {
		if (!getAssumptionTest().isEnvironmentWithSQLANSI()) {
			for (SaleItem saleItem : sale.getItems()) {
				SeedSaleReportWithoutHierView view = new SeedSaleReportWithoutHierView();
				view.setSaleItemId(saleItem.getId());
				view.setCompanyId(saleItem.getCompany().getId());
				view.setCropId(saleItem.getCrop().getId());
				view.setCreationDate(sale.getCreationDate());
				view.setSaleType(sale.getSaleType());
				
				view.setCustomerId(sale.getCustomer().getId());
				view.setCustomerSapCode(sale.getCustomer().getCustomerSAPCode());
				view.setCustomerDocument(sale.getCustomer().getDocumentValue());
				view.setCustomerDocMask(sale.getCustomer().getDocument().getDocumentType().getMask());
				view.setCustomerDescription(sale.getCustomer().getName());
				view.setCustomerCityDesc(sale.getCustomer().getAddress().getCity().getDescription());
				view.setCustomerStateCode(sale.getCustomer().getAddress().getState().getCode());
				
				view.setCustomerParentId(saleItem.getCustomerParent().getId());
				view.setCustomerParentSapCode(saleItem.getCustomerParent().getCustomerSAPCode());
				view.setCustomerParentDocument(saleItem.getCustomerParent().getDocumentValue());
				view.setCustomerParentDocMask(saleItem.getCustomerParent().getDocument().getDocumentType().getMask());
				view.setCustomerParentDescription(saleItem.getCustomerParent().getName());
				view.setCustomerParentCityDesc(saleItem.getCustomerParent().getAddress().getCity().getDescription());
				view.setCustomerParentStateCode(saleItem.getCustomerParent().getAddress().getState().getCode());
				
				view.setGrowerId(sale.getGrowerId());
				view.setGrowerDocument(sale.getGrowerDocument());
				view.setGrowerDocMask(sale.getGrower().getDocument().getDocumentType().getMask());
				view.setGrowerCityId(sale.getGrower().getBillingAddress().getCity().getId());
				view.setGrowerCityDesc(sale.getGrower().getBillingAddress().getCity().getDescription());
				view.setGrowerStateDesc(sale.getGrower().getBillingAddress().getState().getCode());
				
				view.setBillingMethod(saleItem.getBillingMethod());
				view.setPaymentStatus(saleItem.getBilling().getPaymentStatus());
				view.setCreditStatus(saleItem.getBilling().getCreditStatus());
				view.setSoldQuantity(saleItem.getSoldQuantity());
				view.setTotalSoldSeedQuantity(saleItem.getBilling().getTotalSoldSeedQuantity());
				view.setTotalCreditValue(saleItem.getTotalCreditValue());

				view.setBrandId(saleItem.getBrand().getId());
				view.setBrandDescription(saleItem.getBrandDescription());
				view.setStateId(sale.getState().getId());
				view.setSaleStateCode(sale.getStateCode());
				view.setSaleTemplateId(saleItem.getSaleTemplate().getId());
				view.setSaleTemplateDescription(saleItem.getSaleTemplateDescription());
				view.setHarvestId(saleItem.getHarvest().getId());
				view.setHarvestDescription(saleItem.getHarvestDescription());
				view.setTechnologyId(saleItem.getTechnology().getId());
				view.setOperationalYearId(saleItem.getHarvest().getOperationalYear().getId());
				view.setOperationalYearDescription(saleItem.getHarvest().getOperationalYear().getYear());
				view.setInvoiceNumber(sale.getInvoiceNumber());
				if(saleItem.getBilling().getPossiblePaymentPaid()!=null) {
					view.setPaymentReceiptValue(saleItem.getBilling().getPossiblePaymentPaid().getReceiptValue());
					view.setPaymentReceiptDate(saleItem.getBilling().getPossiblePaymentPaid().getReceiptDate());
					view.setPaymentDate(saleItem.getBilling().getPossiblePaymentPaid().getPaymentDate());
				}
				if(saleItem.getRevenueAccount()!=null) {
					view.setSapOrderNumber(saleItem.getRevenueAccount().getOrderNumber());
					view.setSapDocumentNumber(saleItem.getRevenueAccount().getDocumentNumber());
				}
				saveAndFlush(view);
			}
		}
	}
	
	@Test
	public void given_a_sale_when_an_participantUser_with_selected_company_see_sales_for_details_shouldReturn_sales_only_of_his_contract() throws BusinessException {
		Sale sale = createSaleWithOneFixItemAndOneNoValueItem();
		saveAValidSaleForAParticipant(sale);
		createSeedSaleReportView(sale);
		
		UserDecorator participant = getUserDecoratorBy(accessControlTestFixture.itsParticipantUser,systemTestFixture.soy);
		
		AbstractSeedSaleReportFilter filter = SeedSaleReportViewFilter.getInstance(participant,null).addCreationDateEnd(new Date());
		
		List<SeedSaleReportDTO> sales = saleService.getSalesBy(filter);
		
		Assert.assertEquals("Size of sales equals one", 1, sales.size());
	}
	
	@Test
	public void given_a_sale_when_an_adminUser_with_selected_hierarchy_grower_see_sales_for_details_shouldReturn_sales_only_of_hierarchy() throws BusinessException {
		Sale sale = createSaleWithOneFixItemAndOneNoValueItem();
		saveAValidSaleForAParticipant(sale);
		createSeedSaleReportView(sale);
		
		AbstractSeedSaleReportFilter filter = SeedSaleReportViewFilter.getInstance(accessControlTestFixture.userAdminOfMonsantoBr, accessControlTestFixture.userAdminOfMonsantoBr.getContextCompany()).addCreationDateEnd(new Date())
				.addHierarchyGrower(
						systemTestFixture.unity,
						systemTestFixture.region,
						systemTestFixture.districtVilaNova,
						systemTestFixture.commercialHierarchyMonsantoSoy.getCommercialHierType().getCommercialHierTypeDesc());
		
		List<SeedSaleReportDTO> sales = saleService.getSalesBy(filter);
		
		Assert.assertEquals("Size of sales equals one", 1, sales.size());
	}
	
	@Test
	public void given_a_sale_when_an_adminUser_with_selected_grower_without_hierarchy_see_sales_for_details_shouldReturn_sales_only_of_hierarchy() throws BusinessException {
		
		City sp = new City("SAMPA", systemTestFixture.matoGrossoDoSul);
		saveAndFlush(sp);
		
		saleTestFixture.chicoBento.getBillingAddress().setCity(sp);
		saveAndFlush(saleTestFixture.chicoBento);
		
		Sale sale = createSaleWithOneFixItemAndOneNoValueItem();
		
		saveAValidSaleForAParticipant(sale);
		createSeedSaleReportView(sale);
		
		AbstractSeedSaleReportFilter filter = SeedSaleReportViewFilter
				.getInstance(accessControlTestFixture.userAdminOfMonsantoBr, accessControlTestFixture.userAdminOfMonsantoBr.getContextCompany())
				.addCreationDateEnd(new Date());
		
		List<SeedSaleReportDTO> sales = saleService.getSalesBy(filter);
		
		Assert.assertEquals("Size of sales equals one", 1, sales.size());
	}
		
	private PaymentStatusAll getPaymentStatusAllBy(Billing billing){
		PaymentStatusAll paymentStatus = null;
		
		switch (billing.getPaymentStatus()) {
		case BILLED:
			paymentStatus = PaymentStatusAll.BILLED;
			break;
		case CANCELLED:
			paymentStatus = PaymentStatusAll.CANCELLED;
			break;
		case FULLY_PAID:
			paymentStatus = PaymentStatusAll.FULLY_PAID;
			break;
		case PARCIAL_PAID:
			paymentStatus = PaymentStatusAll.PARCIAL_PAID;
			break;
		case NO_VALUE:
			paymentStatus = PaymentStatusAll.NO_VALUE;
			break;
		case NOT_PAID:
			if (billing.getBillingMethod().equals(SaleTemplateBillingMethodEnum.BANKSLIP)){
				paymentStatus = PaymentStatusAll.NOT_PAID;
			}else{
				paymentStatus = PaymentStatusAll.NOT_PAID_BILLING;
			}
			break;
		default:
			break;
		}
		return paymentStatus;
	}
	
	@Test
	public void given_a_sale_when_an_participantUser_has_one_contract_with_affiliate_search_sales_by_affiliates_shouldReturn_sale_of_his_contracts() throws BusinessException {
		
		accessControlTestFixture.itsParticipantUser.addProfile(accessControlTestFixture.profileWithOneAction);
		accessControlTestFixture.itsParticipantUser.addUserContract(saleTestFixture.contractCargil, saleTestFixture.affiliate, HierarchyLevel.AFFILIATE);
		saveAndFlush(accessControlTestFixture.itsParticipantUser);
		
		UserDecorator participantUser = getUserDecoratorBy(accessControlTestFixture.itsParticipantUser,systemTestFixture.soy);
		
		Sale sale = salefactory.createSale(saleTestFixture.affiliate, saleTestFixture.chicoBento, SaleTypeEnum.SALE_SEED);
		sale.setState(systemTestFixture.matoGrossoDoSul);
		SaleItem saleItemByPlantability = saleItemFactory.createByPlantabilityDueDateRangeItem(saleTestFixture.productIntactaSoy, saleTestFixture.templateIntactaByPlantabilityRRByExpirationBtFree, saleTestFixture.headOfficeCargil, 5l, SaleTestFixture.NOVEMBER, saleTestFixture.plantability45To54SoyMonsanto2012);
		sale.addItem(saleItemByPlantability);
		
		saleService.save(sale, participantUser);
		createSeedSaleReportView(sale);
		
		PaymentStatusAll paymentStatus = getPaymentStatusAllBy(saleItemByPlantability.getBilling());
		List<PaymentStatusAll> statusList = new ArrayList<PaymentStatusAll>();
		statusList.add(paymentStatus);
		Calendar yesterday = Calendar.getInstance();
		yesterday.add(Calendar.DAY_OF_MONTH, -1);
		
		AbstractSeedSaleReportFilter filter = SeedSaleReportViewFilter.getInstance(participantUser, systemTestFixture.monsantoBr).addCreationDateEnd(new Date())
											.addBrand(saleTestFixture.productIntactaSoy.getBrand())
											.addState(systemTestFixture.matoGrossoDoSul)
											.addSaleTemplate(saleTestFixture.templateIntactaByPlantabilityRRByExpirationBtFree)
											.addHarvest(saleTestFixture.templateIntactaByPlantabilityRRByExpirationBtFree.getHarvest())
											.addTecnhology(saleTestFixture.productIntactaSoy.getTechnology())
											.addOperationalYear(saleTestFixture.templateIntactaByPlantabilityRRByExpirationBtFree.getHarvest().getOperationalYear())
											.addGrower(saleTestFixture.chicoBento)
											.addCustomer(saleTestFixture.affiliate)
											.addMatrix(saleTestFixture.headOfficeCargil.getMatrix())
											.addInvoiceNumber(sale.getInvoiceNumber())
											.addCreditStatus(saleItemByPlantability.getBilling().getCreditStatus())
											.addPaymentStatus(statusList)
											.addCreationDateStart(yesterday.getTime());
		
		List<SeedSaleReportDTO> sales = saleService.getSalesBy(filter);
		
		Assert.assertEquals("Size of sales equals one", 1, sales.size());
	}
	
	@Test
	public void given_a_sale_when_an_adminUser_with_selected_hierarchy_matrix_see_sales_for_details_shouldReturn_sales_only_of_hierarchy() throws BusinessException {
		Sale sale = createSaleWithOneFixItemAndOneNoValueItem();
		saveAValidSaleForAParticipant(sale);
		createSeedSaleReportView(sale);
		
		
		
		AbstractSeedSaleReportFilter filter = SeedSaleReportViewFilter.getInstance(accessControlTestFixture.userAdminOfMonsantoBr,accessControlTestFixture.userAdminOfMonsantoBr.getContextCompany()).addCreationDateEnd(new Date())
				.addHierarchyHeadoffice(
						systemTestFixture.unity,
						systemTestFixture.region,
						systemTestFixture.districtCampinas,
						systemTestFixture.commercialHierarchyMonsantoSoy
								.getCommercialHierType()
								.getCommercialHierTypeDesc());
		
		List<SeedSaleReportDTO> sales = saleService.getSalesBy(filter);
		
		Assert.assertEquals("Size of sales equals one", 1, sales.size());
	}
	
	@Test
	public void given_a_sale_when_an_adminUser_with_selected_hierarchy_partner_see_sales_for_details_shouldReturn_sales_only_of_hierarchy() throws BusinessException {
		Sale sale = createSaleWithOneFixItemAndOneNoValueItem();
		saveAValidSaleForAParticipant(sale);
		createSeedSaleReportView(sale);
		
		AbstractSeedSaleReportFilter filter = SeedSaleReportViewFilter
				.getInstance(accessControlTestFixture.userAdminOfMonsantoBr,
						accessControlTestFixture.userAdminOfMonsantoBr.getContextCompany())
				.addCreationDateEnd(new Date())
				.addHierarchyPartner(
						systemTestFixture.unity,
						systemTestFixture.region,
						systemTestFixture.districtCampinas,
						systemTestFixture.commercialHierarchyMonsantoSoy
								.getCommercialHierType()
								.getCommercialHierTypeDesc());
		
		List<SeedSaleReportDTO> sales = saleService.getSalesBy(filter);
		
		Assert.assertEquals("Size of sales equals one", 1, sales.size());
	}
	
	private UserDecorator getUserDecoratorBy (ItsUser user, Crop crop) throws BusinessException{
		UserDecorator userDecorator = userServices.getAuthenticatedUserBy(user.getLogin());
		userDecorator.setContextCrop(crop);
		return userDecorator;
	}
	
	private Sale saveAValidSaleForAParticipant(Sale sale) throws BusinessException {
		accessControlTestFixture.itsParticipantUser.addProfile(accessControlTestFixture.profileWithOneAction);
		accessControlTestFixture.itsParticipantUser.addUserContract(saleTestFixture.contractCargil, saleTestFixture.matrixCargil, HierarchyLevel.HEAD_OFFICE);
		saveAndFlush(accessControlTestFixture.itsParticipantUser);
		
		UserDecorator participantUser = getUserDecoratorBy(accessControlTestFixture.itsParticipantUser,systemTestFixture.soy);
		
		saleService.save(sale, participantUser);
		return sale;
	}
	
	private Sale createSaleWithOneFixItemAndOneNoValueItem() throws BusinessException {
		Sale sale = salefactory.createSale(saleTestFixture.matrixCargil, saleTestFixture.chicoBento, SaleTypeEnum.SALE_SEED);
		sale.setState(systemTestFixture.matoGrossoDoSul);
		
		sale.addItem(saleItemFactory.createFixValueItem(saleTestFixture.productIntactaSoy, saleTestFixture.templateIntactaFixRRRangeBtNoValue, saleTestFixture.headOfficeCargil, 5l));
        //sale.addItem(saleItemFactory.createNoValueItem(saleTestFixture.productBtSoy, saleTestFixture.templateIntactaFixRRRangeBtNoValue, saleTestFixture.headOfficeCargil, 5l));
		return sale;
	}
	
	private Sale createSaleWithOneFixItem() throws BusinessException {
		Sale sale = salefactory.createSale(saleTestFixture.matrixCargil, saleTestFixture.chicoBento, SaleTypeEnum.SALE_SEED);
		sale.setState(systemTestFixture.matoGrossoDoSul);
		
		sale.addItem(saleItemFactory.createFixValueItem(saleTestFixture.productIntactaSoy, saleTestFixture.templateIntactaFixRRRangeBtNoValue, saleTestFixture.headOfficeCargil, 5l));
		return sale;
	}
	
	
	
	private void payBillingOf(Sale sale, BigDecimal value) throws BillingConstraintViolationException {
		BillingFilter billingFilter = new BillingFilter(); 
		billingFilter.add(sale.getId()).add(PaymentStatus.NOT_PAID);
		List<Billing> billings  = saleService.getBillingBy(billingFilter);
		
		for (Billing billing : billings) {
			try {
			    saleService.payBilling(billing, SaleTestFixture.DATE_NOW, value, true);
			} catch (BusinessException e) {
                            e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
                        }
		}
	}	
	
	private void cancelBillingOf(Sale sale) throws BillingCancellationWarningException, IndustrySystemOperationException {
		saleService.cancelBillingPartially(sale.getId(), sale.getCompanies().iterator().next(), saleTestFixture.saleCancellation, "remendes");
	}
	

	@Test
	public void given_paidBillingForSale_when_searchBy_paymentStatus_should_return_paid_sale() throws BusinessException {
		Sale sale = createSaleWithOneFixItemAndOneNoValueItem();
		saveAValidSaleForAParticipant(sale);
		payBillingOf(sale, BigDecimal.ONE);
		createSeedSaleReportView(sale);
		UserDecorator participant = getUserDecoratorBy(accessControlTestFixture.itsParticipantUser,systemTestFixture.soy);

		List<PaymentStatusAll> statusList = new ArrayList<PaymentStatusAll>();
		statusList.add(PaymentStatusAll.FULLY_PAID);
		statusList.add(PaymentStatusAll.PARCIAL_PAID);
		
		AbstractSeedSaleReportFilter reportSaleFilter = SeedSaleReportViewFilter.getInstance(participant, null);
		reportSaleFilter.addPaymentStatus(statusList).addCreationDateStart(SaleTestFixture.DATE_NOW);
		
		List<SeedSaleReportDTO> sales = saleService.getSalesBy(reportSaleFilter);
		Assert.assertEquals("Should have at least one paid sale", 1, sales.size());
	}
	
	@Test
	public void given_SeedSaleReportViewFilter_when_filters_are_null_should_return_no_sale() throws BusinessException {
		UserDecorator superUser = getUserDecoratorBy(accessControlTestFixture.itsSuperUser,systemTestFixture.soy);
		AbstractSeedSaleReportFilter reportSaleFilter = SeedSaleReportViewFilter.getInstance(superUser, systemTestFixture.monsantoBr);
		reportSaleFilter.addBrand(null).addCreditStatus(null).addCustomer(null).addGrower(null).addHarvest(null).addHierarchyGrower(null, null, null, null)
			.addHierarchyHeadoffice(null, null, null, null).addHierarchyPartner(null, null, null, null).addInvoiceNumber(null).addMatrix(null)
			.addOperationalYear(null).addPaymentPeriod(null,null).addPaymentStatus(null).addSaleTemplate(null).addState(null)
			.addTecnhology(null).addCreationDateStart(null).addCreationDateEnd(SaleTestFixture.DATE_NOW);
		
		List<SeedSaleReportDTO> sales = saleService.getSalesBy(reportSaleFilter);
		Assert.assertEquals("Should have no sales", 0, sales.size());
	}

	@Test
    @Ignore
	public void given_cancelledBillingForSale_when_searchBy_paymentStatusCancelled_and_creationDate_should_return_cancelled_sale() throws BusinessException {
		Sale sale = createSaleWithOneFixItem();
		saveAValidSaleForAParticipant(sale);
		cancelBillingOf(sale);
		createSeedSaleReportView(sale);
		
		UserDecorator participant = getUserDecoratorBy(accessControlTestFixture.itsParticipantUser,systemTestFixture.soy);

		List<PaymentStatusAll> statusList = new ArrayList<PaymentStatusAll>();
		statusList.add(PaymentStatusAll.CANCELLED);
		
		AbstractSeedSaleReportFilter reportSaleFilter = SeedSaleReportViewFilter.getInstance(participant, null);
		reportSaleFilter.addPaymentStatus(statusList)
		.addCreationDateStart(SaleTestFixture.DATE_NOW)
		.addCreationDateEnd(SaleTestFixture.DATE_NOW);
		
		List<SeedSaleReportDTO> sales = saleService.getSalesBy(reportSaleFilter);
		Assert.assertEquals("Should have at least one cancelled sale", 1, sales.size());
	}
	
	@Test
	public void when_customer_has_only_one_distributor_hierarchy_should_show_correct_hierarchy_for_partner_and_matrix() throws BusinessException {
		
	    Sale sale = createSaleWithOneFixItem();
		saveAValidSaleForAParticipant(sale);
		createSeedSaleReportView(sale);
		createCustomerHierarchyDetailView();
		
		UserDecorator participant = getUserDecoratorBy(accessControlTestFixture.itsSuperUser,systemTestFixture.soy);
		
		AbstractSeedSaleReportFilter filter = SeedSaleReportViewFilter.getInstance(participant,null).addCreationDateEnd(new Date());
		
		List<SeedSaleReportDTO> sales = saleService.getSalesBy(filter);
		
		Assert.assertEquals("Size of sales equals one", 1, sales.size());
		Assert.assertEquals(systemTestFixture.districtCampinas.getDistrictSapDesc(), sales.get(0).getCustomerDistributorDistrictSapDesc());
		Assert.assertEquals(systemTestFixture.region.getRegionSapDesc(), sales.get(0).getCustomerDistributorRegionSapDesc());
		Assert.assertEquals(systemTestFixture.unity.getUnitySapDesc(), sales.get(0).getCustomerDistributorUnitSapDesc());
		Assert.assertEquals(systemTestFixture.districtCampinas.getDistrictSapDesc(), sales.get(0).getCustomerParentDistributorDistrictSapDesc());
		Assert.assertEquals(systemTestFixture.region.getRegionSapDesc(), sales.get(0).getCustomerParentDistributorRegionSapDesc());
		Assert.assertEquals(systemTestFixture.unity.getUnitySapDesc(), sales.get(0).getCustomerParentDistributorUnitSapDesc());
	}
	
	@Test
	public void when_customer_has_two_distributor_hierarchy_should_show_duplicated_hierarchy_message_for_partner_and_matrix() throws BusinessException {
		Sale sale = createSaleWithOneFixItem();
		saveAValidSaleForAParticipant(sale);
		createSeedSaleReportView(sale);
		createCustomerDistrict(saleTestFixture.matrixCargil, systemTestFixture.commercialHierarchyMonsantoSoy, systemTestFixture.districtVilaNova);
		createCustomerHierarchyDetailView();
		
		UserDecorator participant = getUserDecoratorBy(accessControlTestFixture.itsSuperUser,systemTestFixture.soy);
		
		AbstractSeedSaleReportFilter filter = SeedSaleReportViewFilter.getInstance(participant,null).addCreationDateEnd(new Date());
		
		List<SeedSaleReportDTO> sales = saleService.getSalesBy(filter);
		
		Assert.assertEquals("Size of sales equals one", 1, sales.size());
		Assert.assertEquals(PARTNER_DUPLICATED_HIERARCHY_MESSAGE, sales.get(0).getCustomerDistributorDistrictSapDesc());
		Assert.assertEquals(PARTNER_DUPLICATED_HIERARCHY_MESSAGE, sales.get(0).getCustomerDistributorRegionSapDesc());
		Assert.assertEquals(PARTNER_DUPLICATED_HIERARCHY_MESSAGE, sales.get(0).getCustomerDistributorUnitSapDesc());
		Assert.assertEquals(MATRIX_DUPLICATED_HIERARCHY_MESSAGE, sales.get(0).getCustomerParentDistributorDistrictSapDesc());
		Assert.assertEquals(MATRIX_DUPLICATED_HIERARCHY_MESSAGE, sales.get(0).getCustomerParentDistributorRegionSapDesc());
		Assert.assertEquals(MATRIX_DUPLICATED_HIERARCHY_MESSAGE, sales.get(0).getCustomerParentDistributorUnitSapDesc());
	}
	
	@Test
	public void when_customer_has_only_one_distributor_and_one_pod_hierarchy_should_show_correct_hierarchy_for_partner_and_matrix() throws BusinessException {
		Sale sale = createSaleWithOneFixItem();
		saveAValidSaleForAParticipant(sale);
		createSeedSaleReportView(sale);
		CommercialHierarchy newCommercialHierarchy = createCommercialHierarchyByTypeAndCompany(CommercialHierarchyType.POD, systemTestFixture.monsantoBr);
		createCustomerDistrict(saleTestFixture.matrixCargil, newCommercialHierarchy, systemTestFixture.districtVilaNova);
		createCustomerHierarchyDetailView();
		
		UserDecorator participant = getUserDecoratorBy(accessControlTestFixture.itsSuperUser,systemTestFixture.soy);
		
		AbstractSeedSaleReportFilter filter = SeedSaleReportViewFilter.getInstance(participant,null).addCreationDateEnd(new Date());
		
		List<SeedSaleReportDTO> sales = saleService.getSalesBy(filter);
		
		Assert.assertEquals("Size of sales equals one", 1, sales.size());
		Assert.assertEquals(systemTestFixture.districtCampinas.getDistrictSapDesc(), sales.get(0).getCustomerDistributorDistrictSapDesc());
		Assert.assertEquals(systemTestFixture.region.getRegionSapDesc(), sales.get(0).getCustomerDistributorRegionSapDesc());
		Assert.assertEquals(systemTestFixture.unity.getUnitySapDesc(), sales.get(0).getCustomerDistributorUnitSapDesc());
		Assert.assertEquals(systemTestFixture.districtCampinas.getDistrictSapDesc(), sales.get(0).getCustomerParentDistributorDistrictSapDesc());
		Assert.assertEquals(systemTestFixture.region.getRegionSapDesc(), sales.get(0).getCustomerParentDistributorRegionSapDesc());
		Assert.assertEquals(systemTestFixture.unity.getUnitySapDesc(), sales.get(0).getCustomerParentDistributorUnitSapDesc());
	}
		
	private CommercialHierarchy createCommercialHierarchyByTypeAndCompany(CommercialHierarchyType type, Company company) {
		CommercialHierType anotherCommercialHierType = (CommercialHierType) getSession()
				.createCriteria(CommercialHierType.class, "c")
				.add(Restrictions.eq("c.commercialHierTypeDesc", type.getValue()))
				.uniqueResult();
		
		CommercialHierarchy newCommercialHierarchy = new CommercialHierarchy();
	    newCommercialHierarchy.setCommercialHierarchyId(13l);
	    newCommercialHierarchy.setCommercialHierType(anotherCommercialHierType);
	    newCommercialHierarchy.setCompany(company);
	    newCommercialHierarchy.setCrop(systemTestFixture.soy);
	    newCommercialHierarchy.addUnity(systemTestFixture.unity);
	    saveAndFlush(newCommercialHierarchy);
	    
	    return newCommercialHierarchy;
	}

	private void createCustomerDistrict(Customer customer, CommercialHierarchy commercialHierarchy, ItsDistrict itsDistrict) {
		CustomerDistrict customerDistrict = new CustomerDistrict(commercialHierarchy);
		customerDistrict.setCustomer(customer);
		customerDistrict.setItsDistrict(itsDistrict);
		customerDistrict.setCommercialHierType(commercialHierarchy.getCommercialHierType());
		saveAndFlush(customerDistrict);
		customer.addDistrict(customerDistrict);
		saveAndFlush(customer);
	}
	
	@SuppressWarnings("unchecked")
	private void createCustomerHierarchyDetailView() {
		if (!getAssumptionTest().isEnvironmentWithSQLANSI()) {
			List<Customer> customers = getSession().createCriteria(Customer.class).list();
			List<CustomerHierarchyDetailView> views = CustomerTestData.createCustomerDetailViewBy(customers);
			for (CustomerHierarchyDetailView view : views) {
				saveAndFlush(view);
			}
		}
	}
	
	@SuppressWarnings("unchecked")
    private void createGrowerCityHierarchyDetailView() {
	    if (!getAssumptionTest().isEnvironmentWithSQLANSI()) {
	        List<City> cities = getSession().createCriteria(City.class).list();
	        List<CityHierarchyDetailView> views = CityTestData.createCitiesHierarchyDetailViewBy(cities);
	        for (CityHierarchyDetailView view : views) {
                saveAndFlush(view);
            }
	    }
	}
	
	private void createDistrictCity(Company company, Crop crop, ItsUnity itsUnity, ItsRegion itsRegion, ItsDistrict itsDistrict, City city) {
		ItsDistrictCity newDistrictCity = new ItsDistrictCity(company, crop, "", itsUnity, itsRegion, itsDistrict, city, city.getState());
		saveAndFlush(newDistrictCity);
		city.getDistrictsCities().add(newDistrictCity);
        saveAndFlush(city);
	}
	
	@Test
	public void when_grower_city_has_only_one_hierarchy_should_show_correct_hierarchy_for_grower() throws BusinessException {
		Sale sale = createSaleWithOneFixItem();
		saveAValidSaleForAParticipant(sale);
		createSeedSaleReportView(sale);
		createGrowerCityHierarchyDetailView();
		
		UserDecorator participant = getUserDecoratorBy(accessControlTestFixture.itsSuperUser,systemTestFixture.soy);
		
		AbstractSeedSaleReportFilter filter = SeedSaleReportViewFilter.getInstance(participant,null).addCreationDateEnd(new Date());
		
		List<SeedSaleReportDTO> sales = saleService.getSalesBy(filter);
		
		Assert.assertEquals("Size of sales equals one", 1, sales.size());
		Assert.assertEquals(systemTestFixture.districtVilaNova.getDistrictSapDesc(), sales.get(0).getGrowerDistrictSapDesc());
		Assert.assertEquals(systemTestFixture.region.getRegionSapDesc(), sales.get(0).getGrowerRegionSapDesc());
		Assert.assertEquals(systemTestFixture.unity.getUnitySapDesc(), sales.get(0).getGrowerUnitSapDesc());
	}
	
	@Test
    public void when_grower_city_has_only_two_hierarchy_should_show_duplicated_hierarchy_for_grower() throws BusinessException {
        Sale sale = createSaleWithOneFixItem();
        saveAValidSaleForAParticipant(sale);
        createSeedSaleReportView(sale);
        createDistrictCity(systemTestFixture.monsantoBr, systemTestFixture.soy, systemTestFixture.unity, systemTestFixture.region, systemTestFixture.districtCampinas, systemTestFixture.vilaNova);
        createGrowerCityHierarchyDetailView();
        
        UserDecorator participant = getUserDecoratorBy(accessControlTestFixture.itsSuperUser,systemTestFixture.soy);
        
        AbstractSeedSaleReportFilter filter = SeedSaleReportViewFilter.getInstance(participant,null).addCreationDateEnd(new Date());
        
        List<SeedSaleReportDTO> sales = saleService.getSalesBy(filter);
        
        Assert.assertEquals("Size of sales equals one", 1, sales.size());
        Assert.assertEquals(GROWER_DUPLICATED_HIERARCHY_MESSAGE, sales.get(0).getGrowerDistrictSapDesc());
        Assert.assertEquals(GROWER_DUPLICATED_HIERARCHY_MESSAGE, sales.get(0).getGrowerRegionSapDesc());
        Assert.assertEquals(GROWER_DUPLICATED_HIERARCHY_MESSAGE, sales.get(0).getGrowerUnitSapDesc());
    }
	
}