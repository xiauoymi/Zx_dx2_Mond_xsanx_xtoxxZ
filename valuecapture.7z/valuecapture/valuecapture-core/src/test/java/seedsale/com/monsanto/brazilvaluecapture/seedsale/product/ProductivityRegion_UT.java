package com.monsanto.brazilvaluecapture.seedsale.product;

import com.monsanto.brazilvaluecapture.core.grower.CreateTestData;
import com.monsanto.brazilvaluecapture.seedsale.harvest.HarvestTestData;
import com.monsanto.brazilvaluecapture.seedsale.product.model.bean.*;
import com.monsanto.brazilvaluecapture.seedsale.product.model.dao.ProductivityByRegionDAO;
import com.monsanto.brazilvaluecapture.seedsale.product.model.dao.impl.ProductivityByRegionDAOImpl;
import com.monsanto.brazilvaluecapture.seedsale.product.service.ProductivityAlreadyProductInProductvityValues;
import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.hibernate.classic.Session;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Matchers;

import java.util.List;

import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

/**
 * Created by IntelliJ IDEA.
 * User: MEFAZZ
 * Date: 9/9/13
 * Time: 2:10 PM
 * To change this template use File | Settings | File Templates.
 */
public class ProductivityRegion_UT  extends CreateTestData {

   private	Session mockSession;
   private 	SessionFactory mockSessionFactory;
   private ProductivityByRegionDAO productivityByRegionDAO;

    @Before
	public void setup(){
		mockSessionFactory = mock(SessionFactory.class);
		mockSession = mock(Session.class);
		when(mockSessionFactory.getCurrentSession()).thenReturn(mockSession);
        productivityByRegionDAO = new ProductivityByRegionDAOImpl(mockSessionFactory);
    }

    	@Test
	   public void selectByFilterTest(){


        Query mockQuery  =  mock(Query.class);

		when(mockSessionFactory.getCurrentSession()).thenReturn(mockSession);

        when(mockSession.createQuery(anyString()))
                .thenReturn(mockQuery);



        ProductivityByRegion productivityByRegion =   ProductivityRegionTestData.createFullProductivityRegion();

		List<ProductivityByRegion> productivities =  ProductivityRegionTestData.createSomeProductivityRegions();

		when(mockQuery.list()).thenReturn(productivities);

		ProductivityDTO pDto = ProductivityRegionTestData.createProductivityDTO(HarvestTestData.createABrazilianHarvest(),productivityByRegion.getPlantability(),
               productivityByRegion.getRegion(),DefaultProductivity.NOT);

		List<ProductivityByRegion> list = productivityByRegionDAO.selectByFilter(pDto);

		Assert.assertEquals(productivities, list);

	}


     @Test
	public void selectFromRegionProductivityTest(){

		Criteria mockCriteria = mock(Criteria.class);

		when(mockSessionFactory.getCurrentSession()).thenReturn(mockSession);
		when(mockSession.createCriteria(ProductivityByRegion.class)).thenReturn(mockCriteria);

		List<ProductivityByRegion> productivities =  ProductivityRegionTestData.createSomeProductivityRegions();

		when(mockCriteria.list()).thenReturn(productivities);

        List<ProductivityByRegion> list = productivityByRegionDAO.getFromRegionProductivity(RegionProductivityTestData.createRegionProductivity());

		Assert.assertEquals(productivities, list);

	}



}
