package com.monsanto.brazilvaluecapture.seedsale.sale.model.dao.impl;

import com.monsanto.brazilvaluecapture.core.customer.model.bean.Customer;
import com.monsanto.brazilvaluecapture.core.foundation.util.csv.CSVParserReader;
import com.monsanto.brazilvaluecapture.core.grower.model.bean.Grower;
import com.monsanto.brazilvaluecapture.seedsale.billing.model.bean.PaymentStatus;
import com.monsanto.brazilvaluecapture.seedsale.revenue.model.PostingStatusEnum;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.CsvSale;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.Sale;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.dao.*;
import com.monsanto.brazilvaluecapture.seedsale.template.model.bean.SaleTemplate;
import com.monsanto.brazilvaluecapture.utils.DateRange;
import com.monsanto.brazilvaluecapture.utils.DateUtils;
import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.hibernate.classic.Session;
import org.hibernate.criterion.Order;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import static org.fest.assertions.Assertions.assertThat;
import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class SaleDAOImpl_UT {

    @Mock
    private SessionFactory sessionFactory;
    @InjectMocks
    private SaleDAOImpl dao;
    @Mock
    private Session session;
    @Mock
    private Query query;
    @Mock
    private Criteria criteria;

    @Before
    public void setUp() {
        when(sessionFactory.getCurrentSession()).thenReturn(session);
        when(session.createQuery(anyString())).thenReturn(query);
        when(query.setParameter(anyString(), anyObject())).thenReturn(query);
        when(session.createCriteria(any(Class.class), anyString())).thenReturn(criteria);
        when(session.createCriteria(any(Class.class))).thenReturn(criteria);
    }

    @Test
    public void testSave() {
        //@Given
        Sale expected = mock(Sale.class);
        //@When
        dao.save(expected);
        //@Then
        verify(session).saveOrUpdate(expected);
    }

    @Test
    public void testGetByFilter_givenSaleFilter() throws Exception {
        //@Given
        Criteria criteria = mock(Criteria.class);
        SaleFilter saleFilter = mock(SaleFilter.class);
        when(saleFilter.buildCriteria(session)).thenReturn(criteria);
        //@When
        dao.getByFilter(saleFilter);
        //@Then
        verify(saleFilter).buildCriteria(session);
        verify(criteria).addOrder(any(Order.class));
        verify(criteria).list();
    }

    @Test
    public void getWithItemsByFilterShouldSucceed() {
        SaleFilter filter = mock(SaleFilter.class);
        Criteria criteria = mock(Criteria.class);
        Sale sale = mock(Sale.class);
        List<Sale> saleList = new ArrayList<Sale>();
        saleList.add(sale);
        when(filter.setLoadSaleItems(true)).thenReturn(filter);
        when(filter.buildCriteria(session)).thenReturn(criteria);
        when(criteria.addOrder((Order) any())).thenReturn(criteria);
        when(criteria.list()).thenReturn(saleList);

        List<Sale> result = dao.getWithItemsByFilter(filter);

        assertEquals(1, result.size());
        assertEquals(sale, result.get(0));
        verify(filter).setLoadSaleItems(true);
        verify(criteria).addOrder((Order) any());
    }

    @Test
    public void testGetSaleReportDTOsByFilter() throws Exception {
        //@Given

        //@When

        //@Then

    }

    @Test
    public void testGetDuplicateByFilter() throws Exception {
        //@Given
        SaleDuplicateFilter saleFilter = mock(SaleDuplicateFilter.class);
        when(saleFilter.buildQuery(session)).thenReturn(query);
        //@When
        dao.getDuplicateByFilter(saleFilter);
        //@Then
        verify(saleFilter).buildQuery(session);
        verify(query).list();
    }

    @Test
    public void testGetById() throws Exception {
        //@Given
        Long saleId = 1L;
        //@When
        dao.getById(saleId);
        //@Then
        verify(session).get(Sale.class, saleId);
    }

    @Test
    public void testGetAllDirectSale_thenReturnNonEmptyList() throws Exception {
        //@Given
        List<CsvSale> csvSales;
        CsvSale csvSale = new CsvSale();
        when(criteria.list()).thenReturn(Arrays.asList(csvSale));
        //@When
        csvSales = dao.getAllDirectSale();
        //@Then
        verify(criteria).list();
        assertThat(csvSales).hasSize(1).contains(csvSale);
    }

    @Test
    public void testGetAllDirectSale_thenReturnEmptyList() throws Exception {
        //@Given
        List<CsvSale> csvSales;
        when(criteria.list()).thenReturn(new ArrayList());
        //@When
        csvSales = dao.getAllDirectSale();
        //@Then
        verify(criteria).list();
        assertThat(csvSales).hasSize(1).onProperty("warn").contains(CSVParserReader.CSV_ERROS.ERROR_EMPTY_FILE);
    }

    @Test
    public void testRemoveDirectSale() throws Exception {
        //@Given
        String invoiceNumber = "123";
        String queryStr = "delete from CsvSale where invoiceNumber = :invoiceNumber";
        //@When
        dao.removeDirectSale(invoiceNumber);
        //@Then
        verify(session).createQuery(queryStr);
        verify(query).setParameter("invoiceNumber", invoiceNumber);
        verify(query).executeUpdate();
    }

    @Test
    public void testGetSalesFor_givenManualReleaseCreditFilter() throws Exception {
        //@Given
        ManualReleaseCreditFilter filter = mock(ManualReleaseCreditFilter.class);
        when(filter.build(session)).thenReturn(query);
        //@When
        dao.getSalesFor(filter);
        //@Then
        verify(filter).build(session);
        verify(query).list();
    }

    @Test
    public void testGetByFilter_givenAbstractSeedSaleReportFilter() throws Exception {
        //@Given
        AbstractSeedSaleReportFilter saleFilter = mock(AbstractSeedSaleReportFilter.class);
        when(saleFilter.buildCriteria(session)).thenReturn(criteria);
        //@When
        dao.getByFilter(saleFilter);
        //@Then
        verify(saleFilter).buildCriteria(session);
        verify(criteria).list();
    }

    @Test
    public void testGetSaleReportByFilter_givenAbstractSeedSaleReportFilter() throws Exception {
        //@Given
        AbstractSeedSaleReportFilter saleFilter = mock(AbstractSeedSaleReportFilter.class);
        when(saleFilter.buildCriteria(session)).thenReturn(criteria);
        //@When
        dao.getSaleReportByFilter(saleFilter);
        //@Then
        verify(saleFilter).buildCriteria(session);
        verify(criteria).list();
    }

    @Test
    public void testGetSaleItemsFor_givenRevenueSaleItemFilter() throws Exception {
        RevenueSaleItemFilter filter = mock(RevenueSaleItemFilter.class);
        when(filter.buildCriteria(session)).thenReturn(criteria);
        //@When
        dao.getSaleItemsFor(filter);
        //@Then
        verify(filter).buildCriteria(session);
        verify(criteria).list();
    }

    @Test
    public void testSaveSaleItems() throws Exception {
        //@Given

        //@When

        //@Then

    }

    @Test
    public void testGetSalesFor_thenReturnListOfSale() throws Exception {
        //@Given

        //@When

        //@Then

    }

    @Test
    public void testGetSaleItemsFor_givenListOfRevenueHandle() throws Exception {
        //@Given

        //@When

        //@Then

    }

    @Test
    public void testGetManualReleaseCreditBySaleIds() {
        // @Given
        Long[] saleIds = new Long[]{23L, 34L, 45L};

        when(session.createQuery(anyString())).thenReturn(query);

        // @When
        dao.getManualReleaseCreditBySaleIds(saleIds);

        // @Then
        verify(query).list();
    }

    @Test
    public void testGetSalesByRange() {
        // @Given
        Date dateFrom = DateUtils.getLastMonthDateRange().getDateFrom();
        Date dateTo = DateUtils.getLastMonthDateRange().getDateTo();

        when(session.createQuery(anyString())).thenReturn(query);

        // @When
        dao.getSalesByRange(dateFrom, dateTo);

        // @Then
        verify(session).createQuery(getSalesByRangeQuery());
        verify(query).setParameter("paymentStatus", PaymentStatus.CANCELLED);
        verify(query).setParameter("notPosted", PostingStatusEnum.NOT_POSTED);
        verify(query).setParameter("dateFrom", dateFrom);
        verify(query).setParameter("dateTo", dateTo);
        verify(query).list();
    }

    @Test
    public void testGetSalesByGrowerDealerSaleTemplateForBonusPayment() {
        Customer dealer = new Customer();
        Grower grower = new Grower();
        SaleTemplate saleTemplate = new SaleTemplate();

        dao.getSaleItemsByGrowerDealerSaleTemplateForBonusPayment(dealer, grower, saleTemplate);

        String queryString = "" +
                "from SaleItem saleItem " +
                "where ( " +
                "(saleItem.sale.saleType = 'MULTIPLIER_TO_GROWER_SEED_SALE' and saleItem.totalRoyaltyValue is not null and saleItem.postingStatus <> :notPostedStatus) " +
                "or " +
                "(saleItem.sale.saleType = 'SALE_SEED' and (select sum(sldv.revenueRecognition) from SaleLinkDetailValue sldv where sldv.dealerSaleItem = saleItem) is not null) " +
                ") " +
                "and saleItem.sale.grower = :grower " +
                "and " +
                "( " +     //HeadOffice of Dealer in Sale
                "    (SELECT h.matrix FROM HeadOffice h WHERE h.id = (SELECT max(h1.id) FROM HeadOffice h1 WHERE h1.customer = saleItem.sale.customer and h1.type = :distributorType)) " +
                "    = " +   //HeadOffice of Dealer in bonus consumption
                "    (SELECT h.matrix FROM HeadOffice h WHERE h.id = (SELECT max(h1.id) FROM HeadOffice h1 WHERE h1.customer = :dealer and h1.type = :distributorType)) " +
                ") " +
                "and saleItem.saleTemplate = :saleTemplate ";
        verify(session).createQuery(queryString);
        verify(query).setParameter("dealer", dealer);
        verify(query).setParameter("grower", grower);
        verify(query).setParameter("saleTemplate", saleTemplate);
        verify(query).setParameter("notPostedStatus", PostingStatusEnum.NOT_POSTED);
    }

    private String getSalesByRangeQuery() {
        return new StringBuilder()
                .append(" select sale ")
                .append(" from Sale as sale ")
                .append(" join sale.items as sale_item ")
                .append(" where ")
                .append("   sale.saleType = 'SALE_SEED' ")
                .append("   and sale_item.billing.paymentStatus <> :paymentStatus ")
                .append("   and (sale_item.postingStatus is null or sale_item.postingStatus = :notPosted)")
                .append("   and sale.creationDate between :dateFrom and :dateTo ")
                .toString();
    }

    @Test
    public void testGetSaleItemsByRangeUsesTheCorrectQuery() {
        final DateRange lastMonthDateRange = DateUtils.getLastMonthDateRange();

        dao.getSaleItemsByRange(lastMonthDateRange.getDateFrom(), lastMonthDateRange.getDateTo());

        String queryString = " SELECT distinct saleItem FROM SaleItem AS saleItem " +
                "WHERE saleItem.sale.saleType = 'SALE_SEED' and " +
                "saleItem.billing.paymentStatus <> :paymentStatus and " +
                "(saleItem.postingStatus IS NULL or saleItem.postingStatus = :notPosted) and " +
                "saleItem.sale.creationDate BETWEEN :dateFrom and :dateTo and " +
                "(" +
                "   saleItem.product.cultivar.obtainer.revenueRecognitionExcluded IS NULL or " +
                "   saleItem.product.cultivar.obtainer.revenueRecognitionExcluded = false" +
                ") and " +
                "saleItem.soldQuantity > ( " +
                "   SELECT coalesce(sum(sldv.consumed), 0) FROM SaleLinkDetailValue as sldv " +
                "   WHERE sldv.dealerSaleItem = saleItem " +
                ") and EXISTS (" +
                "    SELECT 1 from SaleLinkDetail sld " +
                "    WHERE sld.saleItem.saleTemplate.harvest = saleItem.saleTemplate.harvest and " +
                "          sld.product = saleItem.product and " +
                "          sld.batchName = saleItem.lot and " +
                "          sld.plantability = saleItem.plantabilityId and " +
                "          sld.total > sld.consumed" +
                ")";
        assertQueryStringIsSameAs(queryString);
    }

    @Test
    public void testGetSaleItemsByRangeSetsPaymentStatusParameter() {
        final DateRange lastMonthDateRange = DateUtils.getLastMonthDateRange();

        dao.getSaleItemsByRange(lastMonthDateRange.getDateFrom(), lastMonthDateRange.getDateTo());

        verify(query).setParameter("paymentStatus", PaymentStatus.CANCELLED);
    }

    @Test
    public void testGetSaleItemsByRangeSetsPostedParameter() {
        final DateRange lastMonthDateRange = DateUtils.getLastMonthDateRange();

        dao.getSaleItemsByRange(lastMonthDateRange.getDateFrom(), lastMonthDateRange.getDateTo());

        verify(query).setParameter("notPosted", PostingStatusEnum.NOT_POSTED);
    }

    @Test
    public void testGetSaleItemsByRangeSetsDateFromParameter() {
        final DateRange lastMonthDateRange = DateUtils.getLastMonthDateRange();

        dao.getSaleItemsByRange(lastMonthDateRange.getDateFrom(), lastMonthDateRange.getDateTo());

        verify(query).setParameter("dateFrom", lastMonthDateRange.getDateFrom());
    }

    @Test
    public void testGetSaleItemsByRangeSetsDateToParameter() {
        final DateRange lastMonthDateRange = DateUtils.getLastMonthDateRange();

        dao.getSaleItemsByRange(lastMonthDateRange.getDateFrom(), lastMonthDateRange.getDateTo());

        verify(query).setParameter("dateTo", lastMonthDateRange.getDateTo());
    }

    protected void assertQueryStringIsSameAs(String queryStr) {
        ArgumentCaptor<String> queryStringCaptor = ArgumentCaptor.forClass(String.class);
        verify(session).createQuery(queryStringCaptor.capture());
        String queryString = queryStringCaptor.getValue();
        assertThat(queryString).isEqualTo(queryStr);
    }

}