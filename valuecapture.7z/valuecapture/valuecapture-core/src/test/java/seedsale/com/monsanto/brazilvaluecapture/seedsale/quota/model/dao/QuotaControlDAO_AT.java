package com.monsanto.brazilvaluecapture.seedsale.quota.model.dao;


import java.math.BigDecimal;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.monsanto.brazilvaluecapture.core.foundation.test.AbstractServiceIntegrationTests;
import com.monsanto.brazilvaluecapture.seedsale.quota.model.bean.QuotaTransaction.QuotaTransactionType;
import com.monsanto.brazilvaluecapture.seedsale.quota.model.bean.QuotaType;

public class QuotaControlDAO_AT  extends AbstractServiceIntegrationTests {
	

	@Autowired
	private QuotaControlDAO quotaControlDAO;
	
	@Before
	public void init() {
	}

	@Test
	@Ignore
	public void OnlyQuotaId() {
		Long customerId = 1374l;
		Long productId = 3l;
		Long operationalYearId = 2l;
		QuotaType type = QuotaType.UNUSED;
		
		Long quotaId = quotaControlDAO.fetchOnlyQuotaId(customerId, productId, operationalYearId, type, null, null, null);

		Assert.assertTrue(quotaId > 0);
		
		BigDecimal quotaBalance = quotaControlDAO.selectQuotaBalance(quotaId); 
		System.out.println("quotaBalance "+quotaBalance);
		
		Assert.assertTrue(quotaBalance.compareTo(BigDecimal.TEN) > 0);
	}
	
	@Test
	@Ignore
	public void OnlyQuotaIdNotExist() {
		Long customerId = 0l;
		Long productId = 0l;
		Long operationalYearId = 0l;
		QuotaType type = QuotaType.UNUSED;
		
		Long quotaId = quotaControlDAO.fetchOnlyQuotaId(customerId, productId, operationalYearId, type, null, null, null);

		Assert.assertTrue(quotaId == 0);
		
		BigDecimal quotaBalance = quotaControlDAO.selectQuotaBalance(quotaId); 
		System.out.println("quotaBalance "+quotaBalance);
		
		Assert.assertTrue(quotaBalance.compareTo(BigDecimal.ZERO) == 0);
	}
	
	@Test
	@Ignore
	public void createQuota(){
		long customerId = 2l;
		long productId = 3l;
		long operationalYearId = 2l;
		QuotaType type = QuotaType.UNUSED;
		
//		long quotaId = quotaControlDAO.createOrGetQuotaId(customerId, productId, operationalYearId, type);

//		Assert.assertTrue(quotaId > 0);
	}
	
	@Test
	@Ignore
	public void fetchQuotaAndSaveDeposit() {

		long code = 159951158l;
		long customerId = 2l;
		long productId = 3l;
		long operationalYearId = 2l;
		QuotaType type = QuotaType.AVAILABLE;
		
//		long quotaId = quotaControlDAO.createOrGetQuotaId(customerId, productId, operationalYearId, type);
//		Assert.assertTrue(quotaId > 0);
				
		String invoiceNumber = "12345001";
		String userLogin = "JOHN";
		
		BigDecimal depositValueof50Money = BigDecimal.valueOf(50l);
		
//		quotaControlDAO.saveDeposit(quotaId, QuotaTransactionType.SALE, code,
//				invoiceNumber,
//				userLogin, depositValueof50Money);
//
//		BigDecimal value = quotaControlDAO.selectEntryValue(quotaId, QuotaTransactionType.SALE, code);
//
//		Assert.assertEquals(depositValueof50Money, value);
//
//		BigDecimal balance = quotaControlDAO.selectQuotaBalance(quotaId);
//
//		Assert.assertEquals(depositValueof50Money, balance);
	}
	

	@Test
	@Ignore
	public void saveTransfer() {

		long code = 159951158l;
		long customerId = 2l;
		long productId = 3l;
		long operationalYearId = 2l;
		QuotaType fromType = QuotaType.AVAILABLE;
		QuotaType toType = QuotaType.UNUSED;
		
//		long fromQuotaId = quotaControlDAO.createOrGetQuotaId(customerId, productId, operationalYearId, fromType);
//		Assert.assertTrue(fromQuotaId > 0);
				
		String invoiceNumber = "12345001";
		String userLogin = "JOHN";
		
		BigDecimal depositValueof50Money = BigDecimal.valueOf(50l);
		
//		quotaControlDAO.saveDeposit(fromQuotaId, QuotaTransactionType.SALE, code,
//				invoiceNumber,
//				userLogin, depositValueof50Money);

//		BigDecimal value = quotaControlDAO.selectEntryValue(fromQuotaId, QuotaTransactionType.SALE, code);
		
//		Assert.assertEquals(depositValueof50Money, value);
//
//		BigDecimal fromBalance = quotaControlDAO.selectQuotaBalance(fromQuotaId);
//
//		Assert.assertEquals(depositValueof50Money, fromBalance);
		
		
		
//		long toQuotaId = quotaControlDAO.createOrGetQuotaId(customerId, productId, operationalYearId, toType);
//		Assert.assertTrue(toQuotaId > 0);

		
//		quotaControlDAO.saveTransfer(fromQuotaId, toQuotaId, QuotaTransactionType.REVERSAL, code, invoiceNumber, userLogin, depositValueof50Money);
				
		
//		BigDecimal fromEntryValue = quotaControlDAO.selectEntryValue(fromQuotaId, QuotaTransactionType.REVERSAL, code);
//		Assert.assertEquals(depositValueof50Money.negate(), fromEntryValue);
		
//		BigDecimal toEntryValue = quotaControlDAO.selectEntryValue(toQuotaId, QuotaTransactionType.REVERSAL, code);
//		Assert.assertEquals(depositValueof50Money, toEntryValue);
		
		
//		fromBalance = quotaControlDAO.selectQuotaBalance(fromQuotaId);
//		Assert.assertEquals(BigDecimal.ZERO, fromBalance);
		
//		BigDecimal toBalance = quotaControlDAO.selectQuotaBalance(toQuotaId);
//		Assert.assertEquals(depositValueof50Money, toBalance);
	}

}
