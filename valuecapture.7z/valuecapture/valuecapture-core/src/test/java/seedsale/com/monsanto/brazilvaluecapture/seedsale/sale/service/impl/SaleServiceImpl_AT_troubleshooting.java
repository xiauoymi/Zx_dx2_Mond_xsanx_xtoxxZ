package com.monsanto.brazilvaluecapture.seedsale.sale.service.impl;

import com.monsanto.brazilvaluecapture.core.base.model.bean.Company;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Crop;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Customer;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.HeadOffice;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.ParticipantTypeEnum;
import com.monsanto.brazilvaluecapture.core.customer.service.CustomerService;
import com.monsanto.brazilvaluecapture.core.foundation.test.AbstractServiceIntegrationTests;
import com.monsanto.brazilvaluecapture.seedsale.harvest.model.bean.Harvest;
import com.monsanto.brazilvaluecapture.seedsale.harvest.service.HarvestService;
import com.monsanto.brazilvaluecapture.seedsale.sale.service.SaleService;
import com.monsanto.brazilvaluecapture.seedsale.template.model.bean.SaleTemplate;
import com.monsanto.brazilvaluecapture.seedsale.template.service.SaleTemplateService;
import org.junit.Assert;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.util.StopWatch;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Test created in order to troubleshoot issue happening when hitting IT DB when using a customer's headoffices in
 * SaleWizardHarvestDataStepCC.filtrateDistributors.
 * I modified the mapping between HeadOffice and HeadOfficeDetail from oneToOne to a fake oneToMany and now it's not fetching the
 * headOfficeDetails... but the logic takes too long. I recommend:
 * 1) Simplifying the logic from SaleWizardHarvestDataStepCC
 * 2) Using a native sql query to fetch only what's needed
 *
 */
public class SaleServiceImpl_AT_troubleshooting extends AbstractServiceIntegrationTests {

    @Autowired
    SaleService saleService;

    @Autowired
    HarvestService harvestService;

    @Autowired
    CustomerService customerService;

    @Autowired
    SaleTemplateService saleTemplateService;

    @Test
    public void testSelectAllHeadOfficeBy() {

        StopWatch watch = new StopWatch();
        watch.start();

        getDistributors();

        watch.stop();
        Assert.assertTrue(watch.getTotalTimeSeconds()<60);

    }

    protected Set<HeadOffice> getDistributors() {
        Set<HeadOffice> distributors = new HashSet<HeadOffice>();
        Boolean isNotParticipant = Boolean.TRUE;

        Harvest harvest = harvestService.selectById(81L);

        for (SaleTemplate s: harvest.getSaleTemplates()) {
            if (isNotParticipant) {
                filtrateDistributors(distributors, s.getHeadOffices());
            } else {
                distributors.addAll(s.getHeadOffices());
            }
        }

        return distributors;
    }

    protected void filtrateDistributors(Set<HeadOffice> distributors, Set<HeadOffice> templateHeadoffices) {
		for (HeadOffice h : templateHeadoffices) {
            if (ParticipantTypeEnum.DISTRIBUTOR.equals(h.getType())) {
                Customer partner = saleService.getCustomerById(13932L);
				for (HeadOffice ho : partner.getHeadOffices()) {
							if (ParticipantTypeEnum.DISTRIBUTOR.equals(ho.getType())
								&& h.getCustomer().equals(ho.getMatrix())
								&& (h.getCompany().equals(ho.getCompany()))
								&& (h.getCrop().equals(ho.getCrop()))) {
						System.out.println("add distributors");
					}
				}
			}
		}
	}

    @Test
    public void testSelectAllHeadOfficeBy_query() {

        StopWatch watch = new StopWatch();
        watch.start();

        Customer customer = new Customer();
        customer.setId(13835L);
        Harvest  harvest = new Harvest();
        harvest.setId(81L);
        Company company = new Company();
        company.setId(21L);
        Crop crop = new Crop();
        crop.setId(21L);

        Set<HeadOffice> result = customerService.getDistributors(customer, harvest, company, crop, false);

        watch.stop();
        Assert.assertTrue(watch.getTotalTimeSeconds()<60);

    }


    @Test
    public void testSelectSaleTemplateForHeadOfficeWithContractsBy() {
        StopWatch watch = new StopWatch();
        watch.start();

        Harvest  harvest = new Harvest();
        harvest.setId(81L);
        Customer customer = new Customer();
        customer.setId(13988L);

        //Set<SaleTemplate> temaplates = saleTemplateService.getSaleTemplatesForHeadOffice(harvest, customer);

        watch.stop();
        Assert.assertTrue(watch.getTotalTimeSeconds()<60);
    }

}
