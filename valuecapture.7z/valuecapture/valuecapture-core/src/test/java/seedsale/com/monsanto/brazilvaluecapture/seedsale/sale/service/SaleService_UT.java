package com.monsanto.brazilvaluecapture.seedsale.sale.service;

import com.monsanto.brazilvaluecapture.core.base.SystemTestFixture;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Customer;
import com.monsanto.brazilvaluecapture.core.foundation.service.BusinessException;
import com.monsanto.brazilvaluecapture.core.foundation.service.SystemParameterService;
import com.monsanto.brazilvaluecapture.core.grower.model.bean.Grower;
import com.monsanto.brazilvaluecapture.seedsale.billing.model.bean.Billing;
import com.monsanto.brazilvaluecapture.seedsale.billing.model.bean.PossiblePayment;
import com.monsanto.brazilvaluecapture.seedsale.billing.service.BillingHelper;
import com.monsanto.brazilvaluecapture.seedsale.harvest.model.bean.Plantability;
import com.monsanto.brazilvaluecapture.seedsale.harvest.model.bean.PlantabilitySystemEnum;
import com.monsanto.brazilvaluecapture.seedsale.harvest.model.dao.PlantabilityDAO;
import com.monsanto.brazilvaluecapture.seedsale.product.ProductivityTestData;
import com.monsanto.brazilvaluecapture.seedsale.product.model.bean.DefaultProductivity;
import com.monsanto.brazilvaluecapture.seedsale.product.model.bean.Productivity;
import com.monsanto.brazilvaluecapture.seedsale.sale.SaleTestFixture;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.Sale;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.Sale.SaleTypeEnum;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.SaleItem;
import com.monsanto.brazilvaluecapture.seedsale.sale.service.impl.SaleServiceImpl;
import com.monsanto.brazilvaluecapture.seedsale.template.model.bean.ByPlantabilityAndExpirationDate;
import com.monsanto.brazilvaluecapture.seedsale.template.model.bean.Fix;
import com.monsanto.brazilvaluecapture.seedsale.template.model.bean.Price;
import com.monsanto.brazilvaluecapture.seedsale.template.model.bean.SaleTemplateBillingMethodEnum;
import junit.framework.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.mockito.Matchers;
import org.mockito.Mockito;

import java.math.BigDecimal;
import java.util.Date;
import java.util.HashSet;

import static org.fest.reflect.core.Reflection.field;
import static org.mockito.Mockito.*;

public class SaleService_UT {
	
	private static final String DISCOUNT_TECHNOLOGY_CALC = "DISCOUNT_TECHNOLOGY_CALC";

	private SaleService saleService;
	
	private PlantabilityDAO plantabilityDAO;
	
	private SystemParameterService systemParameterService;
	
	private static SystemTestFixture systemTestFixture;

	private static SaleTestFixture saleTestFixture;
    
    private SaleTestData saleFactory;

	@BeforeClass
	public static void onlyOnce() throws BusinessException {
		systemTestFixture = new SystemTestFixture();
		saleTestFixture = new SaleTestFixture(systemTestFixture);
	}
	
	@Before
	public void setup() {
		plantabilityDAO = mock(PlantabilityDAO.class);
		systemParameterService = mock(SystemParameterService.class);
		saleService = new SaleServiceImpl(plantabilityDAO);
		field("systemParameterService").ofType(SystemParameterService.class).in(saleService).set(systemParameterService);
        saleFactory = new SaleTestData(systemTestFixture.regionSaoPaulo2012);
	}
	
	@Test
	public void when_i_compare_sale_with_invoiceNumberAndCustomer_different_shoudBeReturnFalse(){
		
		Sale sale = saleFactory.createSale(saleTestFixture.matrixCargil, saleTestFixture.chicoBento, SaleTypeEnum.SALE_SEED);
		Sale otherSale = saleFactory.createSale(saleTestFixture.matrixCargil, saleTestFixture.chicoBento, SaleTypeEnum.SALE_SEED);
		
		Assert.assertNotSame(sale, otherSale);
	}
	
	@Test
	public void when_i_compare_sale_with_invoiceNumberAndCustomer_equals_shoudBeReturnTrue(){
		
		Sale sale = saleFactory.createSale(saleTestFixture.matrixCargil, saleTestFixture.chicoBento, SaleTypeEnum.SALE_SEED);
		Sale otherSale = saleFactory.createSale(saleTestFixture.matrixCargil, saleTestFixture.chicoBento, SaleTypeEnum.SALE_SEED);
		sale.setInvoiceNumber(otherSale.getInvoiceNumber());
		
		Assert.assertEquals(sale, otherSale);
	}
	
	@Test
	public void when_i_compare_sale_without_invoiceNumber_different_shoudBeReturnFalse(){
		
		Sale sale = saleFactory.createSale(saleTestFixture.matrixCargil, saleTestFixture.chicoBento, SaleTypeEnum.SALE_SEED);
		sale.setInvoiceNumber(null);
		Sale otherSale = saleFactory.createSale(saleTestFixture.matrixCargil, saleTestFixture.chicoBento, SaleTypeEnum.SALE_SEED);
		otherSale.setInvoiceNumber(null);
		
		Assert.assertNotSame(sale, otherSale);
	}
	
	@Test
	public void when_i_compare_sale_without_invoiceNumber_equals_shoudBeReturnTrue(){
		
		Sale sale = saleFactory.createSale(saleTestFixture.matrixCargil, saleTestFixture.chicoBento, SaleTypeEnum.SALE_SEED);
		sale.setInvoiceNumber(null);
		Sale otherSale = saleFactory.createSale(saleTestFixture.matrixCargil, saleTestFixture.chicoBento, SaleTypeEnum.SALE_SEED);
		otherSale.setInvoiceNumber(null);
		otherSale.setCreationDate(sale.getCreationDate());
		
		Assert.assertEquals(sale, otherSale);
	}
	
	@Test
	public void when_geTMethodBilling_shoudBeReturnTrue(){
		SaleItem saleItemMock = BillingHelper.createMockedSaleItem(systemTestFixture, saleTestFixture, systemTestFixture.intacta, saleTestFixture.harvestSoyMonsanto2012);
		stub(saleItemMock.getBillingMethod()).toReturn(SaleTemplateBillingMethodEnum.BANKSLIP);
		stub(saleItemMock.hasBillingMethodBankslip()).toReturn(Boolean.TRUE);
		
		Sale sale = new Sale(new Customer(), new Grower());
		
		sale.addItem(saleItemMock);
		
		Assert.assertTrue(sale.hasBillingMethodBankslip());
	}
	
	@Test
	public void when_selectPlantabilitiesByReturnAnEmptyCollection_getPlantabilitiesBy_shoudBeReturnAnEmptyPlantabilities() {
		
		when(plantabilityDAO.selectPlantabilitiesBy(systemTestFixture.matoGrossoDoSul, saleTestFixture.harvestSoyMonsanto2012, saleTestFixture.productIntactaSoy)).thenReturn(new HashSet<Plantability>());
		
		PlantabilitiesSelector plantabilities = saleService.getPlantabilitiesBy(systemTestFixture.matoGrossoDoSul, saleTestFixture.harvestSoyMonsanto2012, saleTestFixture.productIntactaSoy);
		
		Assert.assertEquals("Should be return zero", 0, plantabilities.countPlantabilities() );
		Assert.assertEquals("Should be an empty list", new HashSet<Plantability>(), plantabilities.getPlantabilities());
		Assert.assertNull("Should be null", plantabilities.getPlantabilityByPriceType(new Fix()) );
	}
	
	@Test
	public void when_selectPlantabilitiesByReturnOnePlantability_getPlantabilitiesBy_shouldBeReturnOnePlantability() {
		HashSet<Plantability> plantabilitySet = new HashSet<Plantability>();
		plantabilitySet.add(new Plantability());
		
		when(plantabilityDAO.selectPlantabilitiesBy(systemTestFixture.matoGrossoDoSul, saleTestFixture.harvestSoyMonsanto2012, saleTestFixture.productIntactaSoy)).thenReturn(plantabilitySet);
		
		PlantabilitiesSelector plantabilities = saleService.getPlantabilitiesBy(systemTestFixture.matoGrossoDoSul, saleTestFixture.harvestSoyMonsanto2012, saleTestFixture.productIntactaSoy);
		
		Assert.assertEquals("Should be return one", 1, plantabilities.countPlantabilities());
		Assert.assertNotNull("Should be not null", plantabilities.getPlantabilities());
		Assert.assertNull("Should be null", plantabilities.getPlantabilityByPriceType(new Fix()) );
	}
	
	@Test
	public void when_selectPlantabilityByReturnOnePlantability_getPlantabilityBy_shouldReturnTheSystemPlantabilityAsDefault() {
		HashSet<Plantability> plantabilitySet = new HashSet<Plantability>();
		Plantability systemPlantability = new Plantability(saleTestFixture.harvestSoyMonsanto2012, null, null, PlantabilitySystemEnum.YES);
		plantabilitySet.add(systemPlantability);
		
		when(plantabilityDAO.selectPlantabilitiesBy(systemTestFixture.matoGrossoDoSul, saleTestFixture.harvestSoyMonsanto2012, saleTestFixture.productIntactaSoy)).thenReturn(plantabilitySet);
		
		PlantabilitiesSelector plantabilities = saleService.getPlantabilitiesBy(systemTestFixture.matoGrossoDoSul, saleTestFixture.harvestSoyMonsanto2012, saleTestFixture.productIntactaSoy);
		
		Assert.assertEquals("Should be return one", 1, plantabilities.countPlantabilities());
		Assert.assertNotNull("Should be not null", plantabilities.getPlantabilities());
		Assert.assertEquals("Should be the system plantability", systemPlantability, plantabilities.getPlantabilityByPriceType(new Fix()));
	}
	
	@Test
	public void when_selectPlantabilityByReturnOnePlantability_getPlantability_shouldReturnTheDefaultPlantability() {
		HashSet<Plantability> plantabilitySet = new HashSet<Plantability>();
		Plantability plantability = new Plantability(saleTestFixture.harvestSoyMonsanto2012, "Normal", null, PlantabilitySystemEnum.NO);
		Plantability defaultPlantability = createDefaultPlantability();
		plantabilitySet.add(plantability);
		plantabilitySet.add(defaultPlantability);
		
		when(plantabilityDAO.selectPlantabilitiesBy(systemTestFixture.matoGrossoDoSul, saleTestFixture.harvestSoyMonsanto2012, saleTestFixture.productIntactaSoy)).thenReturn(plantabilitySet);
		
		PlantabilitiesSelector plantabilities = saleService.getPlantabilitiesBy(systemTestFixture.matoGrossoDoSul, saleTestFixture.harvestSoyMonsanto2012, saleTestFixture.productIntactaSoy);
		
		Assert.assertNotNull("Should be not null", plantabilities.getPlantabilities());
		Assert.assertEquals("Should be return two", 2, plantabilities.countPlantabilities());
		Assert.assertEquals("Should be the default plantability", defaultPlantability, plantabilities.getPlantabilityByPriceType(new ByPlantabilityAndExpirationDate()));
	}

	@Test
	public void when_selectPlantabilityByReturnPlantabilityWithoutSystem_getPlantability_shouldReturnPlantabilityWithoutSystem() {
		HashSet<Plantability> plantabilitySet = new HashSet<Plantability>();
		Plantability plantability = new Plantability(saleTestFixture.harvestSoyMonsanto2012, "Normal", null, PlantabilitySystemEnum.NO);
		Plantability systemPlantability = new Plantability(saleTestFixture.harvestSoyMonsanto2012, "System", null, PlantabilitySystemEnum.YES);
		Plantability defaultPlantability = createDefaultPlantability();
		plantabilitySet.add(plantability);
		plantabilitySet.add(systemPlantability);
		plantabilitySet.add(defaultPlantability);
		
		when(plantabilityDAO.selectPlantabilitiesBy(systemTestFixture.matoGrossoDoSul, saleTestFixture.harvestSoyMonsanto2012, saleTestFixture.productIntactaSoy)).thenReturn(plantabilitySet);
		
		PlantabilitiesSelector plantabilities = saleService.getPlantabilitiesBy(systemTestFixture.matoGrossoDoSul, saleTestFixture.harvestSoyMonsanto2012, saleTestFixture.productIntactaSoy);
		
		Assert.assertNotNull("Should be not null", plantabilities.getPlantabilities());
		Assert.assertEquals("Should be return three", 3, plantabilities.countPlantabilities());
		Assert.assertEquals("Should be the plantabilities without system", 2, plantabilities.getPlantabilities(new ByPlantabilityAndExpirationDate()).size());
		Assert.assertEquals("Should be return all plantabilities", 3, plantabilities.getPlantabilities().size());
	}

	@Test
	public void when_selectPlantabilityByReturnOnePlantability_getPlantability_shouldReturnTheDefaultPlantabilityOfTheSelectedState() {
		HashSet<Plantability> plantabilityOfStateOne = new HashSet<Plantability>();
		Plantability plantability = new Plantability(saleTestFixture.harvestSoyMonsanto2012, "Normal", null, PlantabilitySystemEnum.NO);
		Plantability defaultPlantability = createDefaultPlantability();
		plantabilityOfStateOne.add(plantability);
		plantabilityOfStateOne.add(defaultPlantability);
		
		when(plantabilityDAO.selectPlantabilitiesBy(systemTestFixture.matoGrossoDoSul, saleTestFixture.harvestSoyMonsanto2012, saleTestFixture.productIntactaSoy)).thenReturn(plantabilityOfStateOne);
		
		PlantabilitiesSelector plantabilities = saleService.getPlantabilitiesBy(systemTestFixture.matoGrossoDoSul, saleTestFixture.harvestSoyMonsanto2012, saleTestFixture.productIntactaSoy);

		PlantabilitiesSelector plantabilitiesSelector = new PlantabilitiesSelector(plantabilities.getPlantabilities(), systemTestFixture.california);
		
		Assert.assertNotNull("Should be not null", plantabilities.getPlantabilities());
		Assert.assertEquals("Should be return two", 2, plantabilities.countPlantabilities());
		Assert.assertEquals("Should be the default plantability", defaultPlantability, plantabilities.getPlantabilityByPriceType(new ByPlantabilityAndExpirationDate()));
		Assert.assertNotNull("Should be not null", plantabilitiesSelector.getPlantabilities());
		Assert.assertEquals("Should be return two", 2, plantabilitiesSelector.countPlantabilities());
		Assert.assertNull("Should be null", plantabilitiesSelector.getPlantabilityByPriceType(new Fix()));
	}
	
	private Plantability createDefaultPlantability() {
		Plantability defaultPlantability = new Plantability(saleTestFixture.harvestSoyMonsanto2012, "Default of Sao Paulo", null, PlantabilitySystemEnum.NO);
		Productivity productivityOfMs = ProductivityTestData.createProductivity(systemTestFixture.matoGrossoDoSul, defaultPlantability);
		productivityOfMs.setDefaultProductivity(DefaultProductivity.YES);
		return defaultPlantability;
	}

	@Test
	public void given_a_sale_item_with_full_payout_rate_when_i_calculate_retribution_fee_values_then_fees_should_be_full_value() {
		PlantabilitiesSelector plantabilitySelector = mock(PlantabilitiesSelector.class);
		stub(plantabilitySelector.getPlantabilityByPriceType(Matchers.any(Price.class))).toReturn(saleTestFixture.plantabilitySystemSoyMonsanto2012);
		stub(plantabilitySelector.getCompletePlantability(Matchers.any(Plantability.class), Matchers.any(Price.class))).toReturn(null);

		SaleItemFactory saleItemFactoryForMatoGrossoDoSul = SaleItemFactory.getInstance(systemTestFixture.matoGrossoDoSul, plantabilitySelector);

		SaleItem saleItem = saleItemFactoryForMatoGrossoDoSul
				.createFixValueItem(saleTestFixture.productIntactaSoy,
						saleTestFixture.templateIntactaFixRRRangeBtNoValue,
						saleTestFixture.headOfficeCargil, 10L);
        saleItem.setNetRoyaltyValueQuantity(new BigDecimal(50));

		PossiblePayment payment = new PossiblePayment();
		payment.setRoyaltyValue(saleItem.getTotalRoyaltyValue());
		Billing mockBilling = Mockito.mock(Billing.class);
		Mockito.when(mockBilling.getCandidatePaymentByMode(Mockito.any(Date.class))).thenReturn(payment);
		saleItem.setBilling(mockBilling);


		saleItem.calculateRetributionFees(new BigDecimal(1), new Date());

		Assert.assertEquals("Retribution Fee value should be 5", new BigDecimal("5").setScale(2), saleItem.getRetributionFeeValue());
		Assert.assertEquals("Marketing Program value should be 5", new BigDecimal("5").setScale(2), saleItem.getMarketingProgramValue());
	}
	
	@Test
	public void given_a_sale_item_with_half_payout_rate_when_i_calculate_retribution_fee_values_then_fees_should_be_half_value() {
		PlantabilitiesSelector plantabilitySelector = mock(PlantabilitiesSelector.class);
		stub(plantabilitySelector.getPlantabilityByPriceType(Matchers.any(Price.class))).toReturn(saleTestFixture.plantabilitySystemSoyMonsanto2012);
		stub(plantabilitySelector.getCompletePlantability(Matchers.any(Plantability.class), Matchers.any(Price.class))).toReturn(null);
		
		SaleItemFactory saleItemFactoryForMatoGrossoDoSul = SaleItemFactory.getInstance(systemTestFixture.matoGrossoDoSul, plantabilitySelector);
		
		SaleItem saleItem = saleItemFactoryForMatoGrossoDoSul
				.createFixValueItem(saleTestFixture.productIntactaSoy,
						saleTestFixture.templateIntactaFixRRRangeBtNoValue,
						saleTestFixture.headOfficeCargil, 10L);
        saleItem.setNetRoyaltyValueQuantity(new BigDecimal(50));
		
        PossiblePayment payment = new PossiblePayment();
        payment.setRoyaltyValue(saleItem.getTotalRoyaltyValue());
        Billing mockBilling = Mockito.mock(Billing.class);
        Mockito.when(mockBilling.getCandidatePaymentByMode(Mockito.any(Date.class))).thenReturn(payment);
        saleItem.setBilling(mockBilling);
		
		saleItem.calculateRetributionFees(new BigDecimal("0.5"), new Date());

		Assert.assertEquals("Retribution Fee value should be 2.5", new BigDecimal("2.5").setScale(2), saleItem.getRetributionFeeValue());
		Assert.assertEquals("Marketing Program value should be 2.5", new BigDecimal("2.5").setScale(2), saleItem.getMarketingProgramValue());
	}
	
	@Test
	public void given_a_sale_item_with_payout_rate_greater_than_value_when_i_calculate_retribution_fee_values_then_fees_should_be_full_value() {
		PlantabilitiesSelector plantabilitySelector = mock(PlantabilitiesSelector.class);
		stub(plantabilitySelector.getPlantabilityByPriceType(Matchers.any(Price.class))).toReturn(saleTestFixture.plantabilitySystemSoyMonsanto2012);
		stub(plantabilitySelector.getCompletePlantability(Matchers.any(Plantability.class), Matchers.any(Price.class))).toReturn(null);
		
		SaleItemFactory saleItemFactoryForMatoGrossoDoSul = SaleItemFactory.getInstance(systemTestFixture.matoGrossoDoSul, plantabilitySelector);
		
		SaleItem saleItem = saleItemFactoryForMatoGrossoDoSul
				.createFixValueItem(saleTestFixture.productIntactaSoy,
						saleTestFixture.templateIntactaFixRRRangeBtNoValue,
						saleTestFixture.headOfficeCargil, 10L);
        saleItem.setNetRoyaltyValueQuantity(new BigDecimal(50));

        PossiblePayment payment = new PossiblePayment();
        payment.setRoyaltyValue(saleItem.getTotalRoyaltyValue());
        Billing mockBilling = Mockito.mock(Billing.class);
        Mockito.when(mockBilling.getCandidatePaymentByMode(Mockito.any(Date.class))).thenReturn(payment);
        saleItem.setBilling(mockBilling);
		
		saleItem.calculateRetributionFees(new BigDecimal("2"), new Date());

		Assert.assertEquals("Retribution Fee value should be 5", new BigDecimal("5").setScale(2), saleItem.getRetributionFeeValue());
		Assert.assertEquals("Marketing Program value should be 5", new BigDecimal("5").setScale(2), saleItem.getMarketingProgramValue());
	}
	
	@SuppressWarnings("static-access")
	@Test
	public void given_a_sale_item_with_template_by_plantability_and_expiration_date_when_i_calculate_retribution_fee_value_should_be_corrected_value_for_pay_date() {
	
		SaleItem saleItem = saleTestFixture.saleItemFactoryForMatoGrossoDoSul
				.createByPlantabilityDueDateRangeItem(
						saleTestFixture.productIntactaSoy,
						saleTestFixture.templateIntactaByPlantabilityRRByExpirationBtFree,
						saleTestFixture.headOfficeCargil, 
						10L,
						SaleTestFixture.NOVEMBER,
						saleTestFixture.plantability45To54SoyMonsanto2012);
        saleItem.setNetRoyaltyValueQuantity(new BigDecimal(13));

		saleItem.calculateRetributionFees(new BigDecimal("1"), saleTestFixture.FEBRUARY);
		Assert.assertEquals("Retribution Fee value should be 1.3", new BigDecimal("1.3").setScale(2), saleItem.getRetributionFeeValue());

        saleItem.setNetRoyaltyValueQuantity(new BigDecimal(7));
		saleItem.calculateRetributionFees(new BigDecimal("1"), saleTestFixture.AUGUST);
		Assert.assertEquals("Retribution Fee value should be 0.7", new BigDecimal("0.7").setScale(2), saleItem.getRetributionFeeValue());
		
	}

}
