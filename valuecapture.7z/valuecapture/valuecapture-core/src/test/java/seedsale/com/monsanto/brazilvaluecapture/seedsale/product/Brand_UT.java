package com.monsanto.brazilvaluecapture.seedsale.product;

import junit.framework.Assert;

import org.junit.Test;

import com.monsanto.brazilvaluecapture.core.foundation.model.bean.StatusEnum;
import com.monsanto.brazilvaluecapture.core.grower.CreateTestData;
import com.monsanto.brazilvaluecapture.seedsale.product.model.bean.Brand;
import com.monsanto.brazilvaluecapture.seedsale.product.model.bean.Product;

public class Brand_UT extends CreateTestData{
	
	@Test
	public void testBiDirectionalWithProduct() {
		
		//=== Test of the association simple
		Product product = createBasicProduct(StatusEnum.ACTIVE);
		// creating a new technology
		Brand brand = createBasicBrand();
		
		Assert.assertTrue(brand.addProduct(product));

		Assert.assertTrue(brand.getProducts().size() == 1);
		Assert.assertEquals(brand.getProducts().iterator().next(), product);

		//=== Test of the transfer association
		Brand anotherBrand = createBasicBrand();
		
		// add the object pricing
		Assert.assertTrue(anotherBrand.addProduct(product));

		Assert.assertFalse(anotherBrand.getProducts().isEmpty());

		// change the object crop of anotherCompany to company
		Assert.assertTrue(brand.addProduct(product));

		Assert.assertEquals(brand.getProducts().iterator().next(), product);
		Assert.assertTrue(brand.getProducts().size() == 1);
		Assert.assertTrue(anotherBrand.getProducts().isEmpty());
		
		// Test adding with error
		anotherBrand.setProducts(null);
		
		// change the object crop of anotherCompany to company
		Assert.assertFalse(anotherBrand.addProduct(product));
		
		// change the object crop of anotherCompany to company
		Assert.assertFalse(brand.addProduct(product));
	}

}
