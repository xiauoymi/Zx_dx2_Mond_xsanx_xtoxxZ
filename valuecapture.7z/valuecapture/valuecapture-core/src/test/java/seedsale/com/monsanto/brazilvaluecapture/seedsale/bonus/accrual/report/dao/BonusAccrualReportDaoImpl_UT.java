package com.monsanto.brazilvaluecapture.seedsale.bonus.accrual.report.dao;

import com.monsanto.brazilvaluecapture.core.customer.model.bean.Customer;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Technology;
import com.monsanto.brazilvaluecapture.core.wsiconsole.dao.impl.BaseHibernateUnitTest;
import com.monsanto.brazilvaluecapture.seedsale.bonus.accrual.report.dto.BonusAccrualReportRequestDTO;
import com.monsanto.brazilvaluecapture.seedsale.bonus.accrual.report.dto.BonusAccrualReportResponseDTO;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;

import java.util.ArrayList;
import java.util.List;

import static org.fest.assertions.Assertions.assertThat;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/**
 * Created with IntelliJ IDEA.
 * User: ammuno
 * To change this template use File | Settings | File Templates.
 */
public class BonusAccrualReportDaoImpl_UT extends BaseHibernateUnitTest {

    private BonusAccrualReportDAOImpl bonusAccrualDaoImpl;

    @Before
    public void setUp(){
        bonusAccrualDaoImpl = new BonusAccrualReportDAOImpl(sessionFactory);
    }

    @Test
    public void testCreateQueryForReportAnalytic (){

        BonusAccrualReportRequestDTO bonusAccrualReportRequestDTO = new BonusAccrualReportRequestDTO();

        bonusAccrualDaoImpl.findBonusAccrualReportAnalytics(bonusAccrualReportRequestDTO);

        ArgumentCaptor<String> queryStringArgumentCaptor = ArgumentCaptor.forClass(String.class);
        verify(session).createQuery(queryStringArgumentCaptor.capture());

        String queryString = queryStringArgumentCaptor.getValue();

        assertThat(queryString).isNotEmpty();
    }

    @Test
    public void testFindBonusAccrualAnalyticReport () {

        //Given
        Technology technology = new Technology();
        BonusAccrualReportRequestDTO bonusAccrualReportRequestDTO = new BonusAccrualReportRequestDTO();
        bonusAccrualReportRequestDTO.setTechnology(technology);

        BonusAccrualReportResponseDTO bonusAccrualReportResponseDTO = new BonusAccrualReportResponseDTO();

        List<BonusAccrualReportResponseDTO> bonusAccrualReportResponseDTOListsExpected = new ArrayList<BonusAccrualReportResponseDTO>();

        bonusAccrualReportResponseDTOListsExpected.add(bonusAccrualReportResponseDTO);

        //when
        when(query.list()).thenReturn(bonusAccrualReportResponseDTOListsExpected);

        List<BonusAccrualReportResponseDTO> bonusAccrualReportResponseDTOList =  bonusAccrualDaoImpl.findBonusAccrualReportAnalytics(bonusAccrualReportRequestDTO);

        int expectedSize = 1;

        //Then
        assertThat(bonusAccrualReportResponseDTOList).isNotEmpty().hasSize(expectedSize).contains(bonusAccrualReportResponseDTO);
    }


    public void testCreateQueryForReportBalance (){

        BonusAccrualReportRequestDTO bonusAccrualReportRequestDTO = new BonusAccrualReportRequestDTO();

        bonusAccrualDaoImpl.findBonusAccrualReportNotExpiredBalance(bonusAccrualReportRequestDTO);

        ArgumentCaptor<String> queryStringArgumentCaptor = ArgumentCaptor.forClass(String.class);
        verify(session).createQuery(queryStringArgumentCaptor.capture());

        String queryString = queryStringArgumentCaptor.getValue();

        assertThat(queryString).isNotEmpty();
    }

    @Test
    public void testFindBonusAccrualNotExpiredBalanceReportWithValidMultiplierAndDealer () {

        //Given
        Technology technology = new Technology();
        Customer multiplier = new Customer();
        Customer dealer = new Customer();

        BonusAccrualReportRequestDTO bonusAccrualReportRequestDTO = new BonusAccrualReportRequestDTO();
        bonusAccrualReportRequestDTO.setTechnology(technology);

        bonusAccrualReportRequestDTO.setMultiplier(multiplier);
        bonusAccrualReportRequestDTO.setDealer(dealer);

        BonusAccrualReportResponseDTO bonusAccrualReportResponseDTO = new BonusAccrualReportResponseDTO();

        List<BonusAccrualReportResponseDTO> bonusAccrualReportResponseDTOListsExpected = new ArrayList<BonusAccrualReportResponseDTO>();

        bonusAccrualReportResponseDTOListsExpected.add(bonusAccrualReportResponseDTO);

        //when
        when(query.list()).thenReturn(bonusAccrualReportResponseDTOListsExpected);

        List<BonusAccrualReportResponseDTO> bonusAccrualReportResponseDTOList =  bonusAccrualDaoImpl.findBonusAccrualReportNotExpiredBalance(bonusAccrualReportRequestDTO);

        int expectedSize = 1;

        //Then
        assertThat(bonusAccrualReportResponseDTOList).isNotEmpty().hasSize(expectedSize).contains(bonusAccrualReportResponseDTO);
    }

    @Test
    public void testFindBonusAccrualNotExpiredBalanceReport () {

        //Given
        Technology technology = new Technology();
        BonusAccrualReportRequestDTO bonusAccrualReportRequestDTO = new BonusAccrualReportRequestDTO();
        bonusAccrualReportRequestDTO.setTechnology(technology);

        BonusAccrualReportResponseDTO bonusAccrualReportResponseDTO = new BonusAccrualReportResponseDTO();

        List<BonusAccrualReportResponseDTO> bonusAccrualReportResponseDTOListsExpected = new ArrayList<BonusAccrualReportResponseDTO>();

        bonusAccrualReportResponseDTOListsExpected.add(bonusAccrualReportResponseDTO);

        //when
        when(query.list()).thenReturn(bonusAccrualReportResponseDTOListsExpected);

        List<BonusAccrualReportResponseDTO> bonusAccrualReportResponseDTOList =  bonusAccrualDaoImpl.findBonusAccrualReportNotExpiredBalance(bonusAccrualReportRequestDTO);

        int expectedSize = 1;

        //Then
        assertThat(bonusAccrualReportResponseDTOList).isNotEmpty().hasSize(expectedSize).contains(bonusAccrualReportResponseDTO);
    }

    @Test
    public void testFindBonusAccrualExpiredBalanceReport () {

        //Given
        Technology technology = new Technology();
        BonusAccrualReportRequestDTO bonusAccrualReportRequestDTO = new BonusAccrualReportRequestDTO();
        bonusAccrualReportRequestDTO.setTechnology(technology);

        BonusAccrualReportResponseDTO bonusAccrualReportResponseDTO = new BonusAccrualReportResponseDTO();

        List<BonusAccrualReportResponseDTO> bonusAccrualReportResponseDTOListsExpected = new ArrayList<BonusAccrualReportResponseDTO>();

        bonusAccrualReportResponseDTOListsExpected.add(bonusAccrualReportResponseDTO);

        //when
        when(query.list()).thenReturn(bonusAccrualReportResponseDTOListsExpected);

        List<BonusAccrualReportResponseDTO> bonusAccrualReportResponseDTOList =  bonusAccrualDaoImpl.findBonusAccrualReportExpiredBalance(bonusAccrualReportRequestDTO);

        int expectedSize = 1;

        //Then
        assertThat(bonusAccrualReportResponseDTOList).isNotEmpty().hasSize(expectedSize).contains(bonusAccrualReportResponseDTO);
    }

    @Test
    public void testFindBonusAccrualBalanceWithoutExpirationReport () {

        //Given
        Technology technology = new Technology();
        BonusAccrualReportRequestDTO bonusAccrualReportRequestDTO = new BonusAccrualReportRequestDTO();
        bonusAccrualReportRequestDTO.setTechnology(technology);

        BonusAccrualReportResponseDTO bonusAccrualReportResponseDTO = new BonusAccrualReportResponseDTO();

        List<BonusAccrualReportResponseDTO> bonusAccrualReportResponseDTOListsExpected = new ArrayList<BonusAccrualReportResponseDTO>();

        bonusAccrualReportResponseDTOListsExpected.add(bonusAccrualReportResponseDTO);

        //when
        when(query.list()).thenReturn(bonusAccrualReportResponseDTOListsExpected);

        List<BonusAccrualReportResponseDTO> bonusAccrualReportResponseDTOList =  bonusAccrualDaoImpl.findBonusAccrualReportWithoutExpirationBalance(bonusAccrualReportRequestDTO);

        int expectedSize = 1;

        //Then
        assertThat(bonusAccrualReportResponseDTOList).isNotEmpty().hasSize(expectedSize).contains(bonusAccrualReportResponseDTO);
    }


    @Test
    public void testCreateQueryForReportMonthly (){

        BonusAccrualReportRequestDTO bonusAccrualReportRequestDTO = new BonusAccrualReportRequestDTO();

        bonusAccrualDaoImpl.findBonusAccrualReportMonthly(bonusAccrualReportRequestDTO);

        ArgumentCaptor<String> queryStringArgumentCaptor = ArgumentCaptor.forClass(String.class);
        verify(session).createQuery(queryStringArgumentCaptor.capture());

        String queryString = queryStringArgumentCaptor.getValue();

        assertThat(queryString).isNotEmpty();
    }

    @Test
    public void testFindBonusAccrualMonthlyReport () {

        //Given
        Technology technology = new Technology();
        BonusAccrualReportRequestDTO bonusAccrualReportRequestDTO = new BonusAccrualReportRequestDTO();
        bonusAccrualReportRequestDTO.setTechnology(technology);

        BonusAccrualReportResponseDTO bonusAccrualReportResponseDTO = new BonusAccrualReportResponseDTO();

        List<BonusAccrualReportResponseDTO> bonusAccrualReportResponseDTOListsExpected = new ArrayList<BonusAccrualReportResponseDTO>();

        bonusAccrualReportResponseDTOListsExpected.add(bonusAccrualReportResponseDTO);

        //when
        when(query.list()).thenReturn(bonusAccrualReportResponseDTOListsExpected);

        List<BonusAccrualReportResponseDTO> bonusAccrualReportResponseDTOList =  bonusAccrualDaoImpl.findBonusAccrualReportMonthly(bonusAccrualReportRequestDTO);

        int expectedSize = 1;

        //Then
        assertThat(bonusAccrualReportResponseDTOList).isNotEmpty().hasSize(expectedSize).contains(bonusAccrualReportResponseDTO);
    }

}
