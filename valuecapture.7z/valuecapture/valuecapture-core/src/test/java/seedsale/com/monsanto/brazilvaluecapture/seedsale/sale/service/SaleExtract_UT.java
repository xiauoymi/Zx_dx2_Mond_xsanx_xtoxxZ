package com.monsanto.brazilvaluecapture.seedsale.sale.service;

import com.monsanto.brazilvaluecapture.core.base.model.bean.Country;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Document;
import com.monsanto.brazilvaluecapture.core.base.model.bean.DocumentType;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Customer;
import com.monsanto.brazilvaluecapture.seedsale.billing.model.bean.Billing;
import com.monsanto.brazilvaluecapture.seedsale.product.model.bean.Region;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.Sale;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.SaleExtract;
import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;

import static org.junit.Assert.assertEquals;


/**
 * Created with IntelliJ IDEA.
 * User: IFERN1
 * Date: 10/3/13
 * Time: 11:47 AM
 * To change this template use File | Settings | File Templates.
 */
public class SaleExtract_UT {
    private SaleExtract saleExtract;
    private Sale sale;
    private Region region;
    private Customer multiplier;

    @Test
    public void test_SaleExtract_has_RegionProperty() {
        assertEquals(region, saleExtract.getRegion());
    }

    @Test
    public void test_SaleExtract_has_MultiplierProperty(){
        assertEquals(multiplier, saleExtract.getMultiplier());
    }

    @Before
    public void initSaleExtract() {
        //Region
        region = new Region();
        //Multiplier
        DocumentType documentType = new DocumentType("documentDescription", new Country("Country 1", "C2"), "documentMast");
        Document document = new Document(documentType, "documentValue");
        multiplier = new Customer("customerName", document, null, "SAPCode");
        //Customer
        Customer distributor = new Customer("customerName", document, null, "SAPCode");
        //Sale
        sale = new Sale(multiplier, distributor);
        sale.setRegion(region);
        sale.setCustomer(distributor);
        //SaleExtract
        saleExtract = new SaleExtract(sale, new ArrayList<Billing>());
    }
}
