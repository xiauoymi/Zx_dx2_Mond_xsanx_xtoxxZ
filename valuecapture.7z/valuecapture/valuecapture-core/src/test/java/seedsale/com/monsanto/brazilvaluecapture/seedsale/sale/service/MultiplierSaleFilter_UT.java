package com.monsanto.brazilvaluecapture.seedsale.sale.service;

import com.monsanto.brazilvaluecapture.core.base.model.bean.Company;
import com.monsanto.brazilvaluecapture.core.base.model.bean.State;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Customer;
import com.monsanto.brazilvaluecapture.core.foundation.RandomTestData;
import com.monsanto.brazilvaluecapture.core.foundation.service.IllegalDateArgumentException;
import com.monsanto.brazilvaluecapture.core.user.model.bean.ItsUser;
import com.monsanto.brazilvaluecapture.core.user.model.bean.UserContext;
import com.monsanto.brazilvaluecapture.core.user.model.bean.UserDecorator;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.dao.MultiplierSaleFilter;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.util.Date;

/**
 *
 * User: LSPOLU
 *
 */
public class MultiplierSaleFilter_UT {

    private MultiplierSaleFilter multiplierSaleFilter;

	@Before
	public void setup() {
		multiplierSaleFilter = MultiplierSaleFilter.getInstance();
	}

	@Test
	public void given_no_filter_when_count_criteria_then_have_none() {
        // @ given
        Object expected = 0;
        // @ when
        Object result = multiplierSaleFilter.countCriterias();
        // @ then
		Assert.assertEquals("Should have no criteria", expected, result);
	}

	@Test
	public void given_participant_user_filter_when_count_criteria_then_have_one() {
        // @ given
        ItsUser loggedUser = new ItsUser("login", ItsUser.UserTypeEnum.PARTICIPANT);
        UserContext user = new UserDecorator(null, loggedUser);
        multiplierSaleFilter.add(user);
        Object expected = 1;
        // @ when
        Object result = multiplierSaleFilter.countCriterias();
        // @ then
		Assert.assertEquals("Should have one criteria", expected, result);
	}

	@Test
	public void given_administrator_user_filter_when_count_criteria_then_have_two() {
        ItsUser loggedUser = new ItsUser("login", ItsUser.UserTypeEnum.ADMINISTRATOR);
      	UserContext user = new UserDecorator(null, loggedUser);
      	user.setContextCompany(new Company());

        // @ given
        multiplierSaleFilter.add(user);
        Object expected = 2;
        // @ when
        Object result = multiplierSaleFilter.countCriterias();
        // @ then
		Assert.assertEquals("Should have two criteria", expected,result);
	}

	@Test
	public void given_super_user_filter_when_count_criteria_then_have_one() {
		ItsUser loggedUser = new ItsUser("login", ItsUser.UserTypeEnum.SUPER);
		UserContext user = new UserDecorator(null, loggedUser);

        // @ given
        multiplierSaleFilter.add(user);
        Object expected = 1;
        // @ when
        Object result = multiplierSaleFilter.countCriterias();
        // @ then
		Assert.assertEquals("Should have one criteria", expected,result);
	}

	@Test
	public void given_addCreationDateStart_and_addCreationDateEnd_filter_when_count_criteria_then_have_two() {
        // @ given
        multiplierSaleFilter.addCreationDateStart(new Date());
        multiplierSaleFilter.addCreationDateEnd(new Date());
        Object expected = 2;
        // @ when
        Object result = multiplierSaleFilter.countCriterias();
        // @ then
		Assert.assertEquals("Should have one criteria", expected,result);
	}

	@Test
	public void given_customer_filter_when_count_criteria_then_have_one() {
        // @ given
        multiplierSaleFilter.addMatrix(new Customer());
        Object expected = 1;
        // @ when
        Object result = multiplierSaleFilter.countCriterias();
        // @ then
		Assert.assertEquals("Should have one criteria", expected,result);
	}

	@Test
	public void given_invoiceNumber_customerDocument_and_growerDocument_filter_when_count_criteria_then_have_three() {
        // @ given
        multiplierSaleFilter.addInvoiceNumber(RandomTestData.createRandomString(5));
        multiplierSaleFilter.addCustomerDocument(RandomTestData.createRandomString(5));
        multiplierSaleFilter.addDistributorDocument(RandomTestData.createRandomString(5));
        Object expected = 3;
        // @ when
        Object result = multiplierSaleFilter.countCriterias();
        // @ then
		Assert.assertEquals("Should have one criteria", expected,result);
	}

	@Test
	public void given_state_filter_when_count_criteria_then_have_one() {
        // @ given
        multiplierSaleFilter.add(new State());
        Object expected = 1;
        // @ when
        Object result = multiplierSaleFilter.countCriterias();
        // @ then
		Assert.assertEquals("Should have one criteria", expected,result);
	}

	@Test(expected=IllegalDateArgumentException.class)
	public void when_filter_does_not_have_start_or_end_creationDate_then_fail() {
        // @ when
        multiplierSaleFilter.buildCriteria(null);
        // @ then
		Assert.fail("SaleFilter should throw IllegalDateArgumentException");
	}

}
