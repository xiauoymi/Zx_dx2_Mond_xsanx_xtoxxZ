package com.monsanto.brazilvaluecapture.seedsale.billing.service;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.stub;

import java.math.BigDecimal;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;
import java.util.SortedSet;
import java.util.TreeSet;

import junit.framework.Assert;

import com.monsanto.brazilvaluecapture.core.base.SystemTestFixture;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Technology;
import com.monsanto.brazilvaluecapture.seedsale.billing.model.bean.Billing;
import com.monsanto.brazilvaluecapture.seedsale.billing.model.bean.BillingChannel;
import com.monsanto.brazilvaluecapture.seedsale.billing.model.bean.CreditStatus;
import com.monsanto.brazilvaluecapture.seedsale.billing.model.bean.PossiblePayment;
import com.monsanto.brazilvaluecapture.seedsale.billing.service.impl.BillingIndexer;
import com.monsanto.brazilvaluecapture.seedsale.billing.service.impl.SimpleBillingIndexer;
import com.monsanto.brazilvaluecapture.seedsale.harvest.model.bean.Harvest;
import com.monsanto.brazilvaluecapture.seedsale.sale.SaleTestFixture;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.Sale;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.SaleItem;
import com.monsanto.brazilvaluecapture.seedsale.template.model.bean.Price.ReleaseCreditTypeEnum;
import com.monsanto.brazilvaluecapture.seedsale.template.model.bean.SaleTemplate;
import com.monsanto.brazilvaluecapture.seedsale.template.model.bean.SaleTemplateBillAgainstEnum;
import com.monsanto.brazilvaluecapture.seedsale.template.model.bean.SaleTemplateBillingMethodEnum;

public final class BillingHelper {

	public static final long MOCKED_SALE_CODE = 123L;

	public static final BigDecimal TOTAL_ROYALTY_VALUE_TO_RECEIVE = new BigDecimal(660L);

	public static final BigDecimal PARCIAL_PAYMENT_VALUE_TO_RECEIVE = new BigDecimal(43L);


	public static final BigDecimal ONE_CREDITS = new BigDecimal("1");
	public static final BigDecimal TWO_CREDITS = new BigDecimal("2");
	public static final BigDecimal THREE_CREDITS = new BigDecimal("3");
	public static final BigDecimal FOUR_CREDITS = new BigDecimal("4");
	public static final BigDecimal FIVE_CREDITS = new BigDecimal("5");




	public static BillingChannel monsantoBillingChannel = new BillingChannel(SimpleBillingIndexer.MONSANTO_COVENANT_BANCO_DO_BRASIL, SimpleBillingIndexer.MONSANTO_COVENANT_BILLING, SimpleBillingIndexer.MONSANTO_BANCO_DO_BRASIL_MSG_INSTRUCTION);

	public static Set<SaleItem> createSaleItemSet(SaleItem... saleItems) {
		Set<SaleItem> saleItemSet = new HashSet<SaleItem>();
		for(SaleItem item : saleItems) {
			saleItemSet.add(item);
		}
		return saleItemSet;
	}
	
	public static BillingIndexer createBillingIndexer() {
		BillingIndexer billingIndexer = mock(BillingIndexer.class);
		stub(billingIndexer.getCreditStatus()).toReturn(CreditStatus.ON_PAYMENT);
		return billingIndexer;
	}

	public static SortedSet<PossiblePayment> createPaymentSet(Date... dueDates) {
		SortedSet<PossiblePayment> paymentList = new TreeSet<PossiblePayment>();
		for ( Date aDate : dueDates ) {
			PossiblePayment dueDate = new PossiblePayment(aDate);
			dueDate.setReceiptValue(TOTAL_ROYALTY_VALUE_TO_RECEIVE);
			paymentList.add(dueDate);
		}
		return paymentList;
	}

	public static SaleItem createMockedSaleItem(SystemTestFixture systemTestFixture, SaleTestFixture saleTestFixture, Technology technology, Harvest harvest) {
		return mockSaleItem(systemTestFixture, technology,	harvest, saleTestFixture.templateIntactaFixRRRangeBtNoValue);
	}

	public static SaleItem createMockedSaleItem(SystemTestFixture systemTestFixture, SaleTestFixture saleTestFixture, Technology technology, Harvest harvest, SaleTemplate saleTemplate) {
		return mockSaleItem(systemTestFixture, technology,	harvest, saleTemplate);
	}
	
	private static SaleItem mockSaleItem(SystemTestFixture systemTestFixture, Technology technology, Harvest harvest, SaleTemplate saleTemplate) {
		SaleItem saleItemMock = mock(SaleItem.class);
		stub(saleItemMock.getTechnology()).toReturn(technology);
		stub(saleItemMock.getHarvest()).toReturn(harvest);
		stub(saleItemMock.getCompany()).toReturn(systemTestFixture.monsantoBr);
		stub(saleItemMock.getPrices()).toReturn(createPaymentSet(SaleTestFixture.FEBRUARY));
		stub(saleItemMock.getBillingMethod()).toReturn(SaleTemplateBillingMethodEnum.BANKSLIP);
		stub(saleItemMock.getBillingRecipient()).toReturn(SaleTemplateBillAgainstEnum.GROWER);
		stub(saleItemMock.getSaleTemplate()).toReturn(saleTemplate);
		stub(saleItemMock.getPriceOfTechnology()).toReturn(saleTemplate.getPriceOf(technology));
		stub(saleItemMock.getDueDate()).toReturn(SaleTestFixture.AUGUST);
		stub(saleItemMock.getTotalCreditValue()).toReturn(FIVE_CREDITS.longValue());
		stub(saleItemMock.getTotalRoyaltyValue()).toReturn(TOTAL_ROYALTY_VALUE_TO_RECEIVE);
		stub(saleItemMock.getSoldQuantity()).toReturn(500L);
		stub(saleItemMock.getReleaseCreditType()).toReturn(ReleaseCreditTypeEnum.ON_PAYMENT);
		return saleItemMock;
	}
	
	public static SaleItem createManualReleaseMockedSaleItem(SystemTestFixture systemTestFixture, SaleTestFixture saleTestFixture, Technology technology, Harvest harvest) {
        SaleItem saleItemMock = mock(SaleItem.class);
        stub(saleItemMock.getTechnology()).toReturn(technology);
        stub(saleItemMock.getHarvest()).toReturn(harvest);
        stub(saleItemMock.getCompany()).toReturn(systemTestFixture.mons4ntoBr);
        stub(saleItemMock.getPrices()).toReturn(createPaymentSet(SaleTestFixture.FEBRUARY));
        stub(saleItemMock.getSaleTemplate()).toReturn(saleTestFixture.templateIntactaMons4ntoManualCreditRelease);
        stub(saleItemMock.getBillingMethod()).toReturn(SaleTemplateBillingMethodEnum.BANKSLIP);
        stub(saleItemMock.getBillingRecipient()).toReturn(SaleTemplateBillAgainstEnum.GROWER);
        stub(saleItemMock.getDueDate()).toReturn(SaleTestFixture.AUGUST);
        stub(saleItemMock.getTotalCreditValue()).toReturn(FIVE_CREDITS.longValue());
        stub(saleItemMock.getTotalRoyaltyValue()).toReturn(TOTAL_ROYALTY_VALUE_TO_RECEIVE);
        stub(saleItemMock.getSoldQuantity()).toReturn(500L);
        stub(saleItemMock.getReleaseCreditType()).toReturn(ReleaseCreditTypeEnum.MANUALLY);
        return saleItemMock;
    }

	public static Sale createMockedSale(Set<SaleItem> saleItems) {
		Sale mockedSale = mock(Sale.class);
		stub(mockedSale.getItems()).toReturn(saleItems);
		stub(mockedSale.getId()).toReturn(MOCKED_SALE_CODE);
		return mockedSale;
	}

	public static Billing createBillingWithOneItemForManyDueDates(SystemTestFixture systemTestFixture, SaleTestFixture saleTestFixture, BillingIndexer billingIndexer, Date... dueDates) {
		
	    SortedSet<PossiblePayment> payments = createPaymentSet(dueDates);
		SaleItem oneMockedSaleItem = createMockedSaleItem(systemTestFixture, saleTestFixture, systemTestFixture.intacta, saleTestFixture.harvest2009SoyMonsanto);
		stub(oneMockedSaleItem.getPrices()).toReturn(payments);
		stub(oneMockedSaleItem.getTechnology()).toReturn(systemTestFixture.intacta);
		stub(oneMockedSaleItem.getHarvest()).toReturn(saleTestFixture.harvest2009SoyMonsanto);
		stub(oneMockedSaleItem.getCompany()).toReturn(systemTestFixture.monsantoBr);

		Set<SaleItem> items = createSaleItemSet(oneMockedSaleItem);
		Billing billing = new Billing(items, billingIndexer);
		billing.setCreditStatus(CreditStatus.ON_PAYMENT);
		return billing;
	}

	public static Billing createAnotherBillingWithOneItemForManyDueDates(SystemTestFixture systemTestFixture, SaleTestFixture saleTestFixture, BillingIndexer billingIndexer, SaleTemplate saleTemplate, Date... dueDates) {
		SortedSet<PossiblePayment> payments = createPaymentSet(dueDates);
		
		SaleItem oneMockedSaleItem = createMockedSaleItem(systemTestFixture, saleTestFixture, systemTestFixture.intactaMons4nto, saleTestFixture.harvestSoyMons4nto2012, saleTemplate);
		stub(oneMockedSaleItem.getPrices()).toReturn(payments);
		stub(oneMockedSaleItem.getTechnology()).toReturn(systemTestFixture.intactaMons4nto);
		stub(oneMockedSaleItem.getHarvest()).toReturn(saleTestFixture.harvestSoyMons4nto2012);
		stub(oneMockedSaleItem.getCompany()).toReturn(systemTestFixture.mons4ntoBr);
		
		Set<SaleItem> items = createSaleItemSet(oneMockedSaleItem);
		Billing billing = new Billing(items, billingIndexer);
		
		return billing;
	}
	
	public static Billing createBillingWithOneItemForManyDueDatesManualRelease(SystemTestFixture systemTestFixture, SaleTestFixture saleTestFixture, BillingIndexer billingIndexer, Date... dueDates) {
	    SortedSet<PossiblePayment> payments = createPaymentSet(dueDates);
		SaleItem oneMockedSaleItem = createManualReleaseMockedSaleItem(systemTestFixture, saleTestFixture, systemTestFixture.intactaMons4nto, saleTestFixture.harvestSoyMons4nto2012);
		stub(oneMockedSaleItem.getPrices()).toReturn(payments);
		stub(oneMockedSaleItem.getTechnology()).toReturn(systemTestFixture.intactaMons4nto);
		stub(oneMockedSaleItem.getHarvest()).toReturn(saleTestFixture.harvestSoyMons4nto2012);
		stub(oneMockedSaleItem.getCompany()).toReturn(systemTestFixture.mons4ntoBr);
		
		Set<SaleItem> items = createSaleItemSet(oneMockedSaleItem);
		Billing billing = new Billing(items, billingIndexer);
		billing.setCreditStatus(CreditStatus.WAITING_FOR_RELEASE_MANUAL);
		return billing;
	}

	public static void assertBilling(int expectedPaymentCount, int expectedRoyaltyCount, SaleTemplateBillingMethodEnum expectedBillingMethod, SaleTemplateBillAgainstEnum expectedBillingRecipient, Date expectedDueDate, CreditStatus expectedCreditStatus, Billing actual) {
		Assert.assertEquals("Should have 1 payment", expectedPaymentCount, actual.countPayments());
		Assert.assertEquals("Should have 1 royalty", expectedRoyaltyCount, actual.countRoyalties());
		Assert.assertEquals("Billing recipient is wrong", expectedBillingRecipient, actual.getBillingRecipient());
		Assert.assertEquals("Billing method is wrong", expectedBillingMethod, actual.getBillingMethod());
		Assert.assertEquals("Billing credit status is wrong", expectedCreditStatus, actual.getCreditStatus());
		Assert.assertEquals("DueDate is wrong", expectedDueDate, actual.getDueDate());
	}

	/**
	 * @deprecated Use {@link #assertLastPayment(Date,BigDecimal,BigDecimal,Set<PossiblePayment>)} instead
	 */
	public static void assertLastPayment(Date expectedPaymentDate, BigDecimal expectedPaymentValue, Set<PossiblePayment> actualPayments) {
		assertLastPayment(expectedPaymentDate, expectedPaymentValue, null, null, actualPayments);
	}

	/**
	 * @deprecated Use {@link #assertLastPayment(Date,BigDecimal,BigDecimal,BigDecimal,Set<PossiblePayment>)} instead
	 */
	public static void assertLastPayment(Date expectedPaymentDate, BigDecimal expectedPaymentValue, BigDecimal expectedTariffValue, Set<PossiblePayment> actualPayments) {
		assertLastPayment(expectedPaymentDate, expectedPaymentValue, expectedTariffValue, null, actualPayments);
	}

	public static void assertLastPayment(Date expectedPaymentDate, BigDecimal expectedPaymentValue, BigDecimal expectedTariffValue, BigDecimal expectedLaunchValue, Set<PossiblePayment> actualPayments) {
		SortedSet<PossiblePayment> sortedPayments = new TreeSet<PossiblePayment>(actualPayments);
		PossiblePayment lastPayment = sortedPayments.last();
		Assert.assertTrue("Last payment should be paid", lastPayment.isPaid());
		Assert.assertEquals("Last payment should be paid",expectedTariffValue, lastPayment.getTariffValue());
		Assert.assertEquals("Payment Date is wrong", expectedPaymentDate, lastPayment.getPaymentDate());
		Assert.assertEquals("Payment Value is wrong", expectedPaymentValue, lastPayment.getPaidValue());
	}


}
