package com.monsanto.brazilvaluecapture.seedsale.bonus.impl;

import com.google.common.collect.Lists;
import com.monsanto.brazilvaluecapture.bonus.bulkimport.model.dao.BonusDAO;
import com.monsanto.brazilvaluecapture.core.base.DateUtil;
import com.monsanto.brazilvaluecapture.core.base.model.bean.OperationalYear;
import com.monsanto.brazilvaluecapture.core.base.model.dao.OperationalYearDAO;
import com.monsanto.brazilvaluecapture.core.base.model.dao.TechnologyDAO;
import com.monsanto.brazilvaluecapture.core.base.service.BaseService;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Customer;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Technology;
import com.monsanto.brazilvaluecapture.core.foundation.service.BusinessException;
import com.monsanto.brazilvaluecapture.core.grower.model.bean.*;
import com.monsanto.brazilvaluecapture.core.grower.model.dao.GrowerDAO;
import com.monsanto.brazilvaluecapture.core.revenue.model.bean.ChargeConsolidate;
import com.monsanto.brazilvaluecapture.core.revenue.model.bean.ChargeConsolidateStatus;
import com.monsanto.brazilvaluecapture.core.revenue.model.bean.ChargeGroup;
import com.monsanto.brazilvaluecapture.core.revenue.model.bean.ChargeGroupStatus;
import com.monsanto.brazilvaluecapture.core.revenue.service.ChargeConsolidateService;
import com.monsanto.brazilvaluecapture.core.revenue.service.ChargePaymentService;
import com.monsanto.brazilvaluecapture.seedsale.billing.model.bean.Billing;
import com.monsanto.brazilvaluecapture.seedsale.billing.model.bean.PaymentStatus;
import com.monsanto.brazilvaluecapture.seedsale.bonus.BonusConsumptionFilter;
import com.monsanto.brazilvaluecapture.seedsale.bonus.BonusService;
import com.monsanto.brazilvaluecapture.seedsale.bonus.bulkimport.model.bean.BonusAccount;
import com.monsanto.brazilvaluecapture.seedsale.bonus.bulkimport.model.bean.BonusEntry;
import com.monsanto.brazilvaluecapture.seedsale.bonus.bulkimport.model.bean.BonusTransaction;
import com.monsanto.brazilvaluecapture.seedsale.bonus.payment.SaleItemAvailableRoyaltiesConsumerAndCalculator;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.Sale;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.SaleItem;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.dao.SaleDAO;
import com.monsanto.brazilvaluecapture.seedsale.sale.service.SaleService;
import com.monsanto.brazilvaluecapture.seedsale.template.model.bean.SaleTemplate;
import edu.emory.mathcs.backport.java.util.Collections;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import static junit.framework.Assert.*;
import static org.fest.assertions.Assertions.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.same;
import static org.mockito.Mockito.*;

public class BonusServiceImpl_UT {
    public static final String LOGIN_USER_ID = "LOGIN_USER_ID";
    private static final SimpleDateFormat DATE_FORMATTER = new SimpleDateFormat("MM/dd/yyyy");
    GrowerDAO growerDAO = mock(GrowerDAO.class);
    TechnologyDAO technologyDAO = mock(TechnologyDAO.class);
    OperationalYearDAO operationalYearDAO = mock(OperationalYearDAO.class);
    AgreementTemplateType agreementTemplateType = new AgreementTemplateType();
    private BonusDAO bonusDAO = mock(BonusDAO.class);
    private BaseService baseService = mock(BaseService.class);
    private SaleService saleService = mock(SaleService.class);
    private ChargePaymentService chargePaymentService = mock(ChargePaymentService.class);
    private ChargeConsolidateService chargeConsolidateService = mock(ChargeConsolidateService.class);
    private DateUtil dateUtil = mock(DateUtil.class);
    private SaleDAO saleDao = mock(SaleDAO.class);
    private SaleItemAvailableRoyaltiesConsumerAndCalculator saleItemAvailableRoyaltiesConsumerAndCalculator = mock(SaleItemAvailableRoyaltiesConsumerAndCalculator.class);
    BonusService bonusService = spy(new BonusServiceImpl(growerDAO, technologyDAO, bonusDAO, operationalYearDAO, baseService, saleService, chargePaymentService, chargeConsolidateService, dateUtil, saleDao, saleItemAvailableRoyaltiesConsumerAndCalculator));
    private Grower grower = new Grower();

    @Before
    public void setUp() throws BusinessException {
        Agreement agreement = new Agreement();
        agreement.setStatus(Agreement.AgreementStatusEnum.APPROVED);
        AgreementTemplate agreementTemplate = new AgreementTemplate();
        agreementTemplate.setAgreementTemplateType(agreementTemplateType);
        agreement.setAgreementTemplate(agreementTemplate);

        BonusAccount bonusAccount = new BonusAccount();
        when(bonusDAO.getBonusAccount(any(Grower.class), any(Agreement.class), any(OperationalYear.class))).thenReturn(bonusAccount);
        grower.setId(100l);
        grower.addAgreement(agreement);
        when(baseService.selectGrowerByID(grower.getId())).thenReturn(grower);
    }

    @Test
    public void testFindBonusConsumptionsInvokesBonusDAO_GivenSomeFilter() {
        //@Given a filter
        BonusConsumptionFilter filter = mock(BonusConsumptionFilter.class);

        //@When
        bonusService.findBonusConsumptions(filter);

        //@Should
        verify(bonusDAO).findBonusConsumptions(same(filter));
    }

    @Test
    public void testRevertBonusConsumptionUpdateBonusConsumptionEntityAndSaveIt_WhenRevertingBonusConsumption() throws Exception {
        //@Given a bonus consumption to revert
        BonusConsumption bonusConsumption = new BonusConsumption();
        bonusConsumption.setAgreementTemplateType(agreementTemplateType);
        bonusConsumption.setConsumedAmount(BigDecimal.TEN);
        bonusConsumption.setGrower(grower);

        //@When
        String userName = "userName";
        String reversedComment = "Reversion comment";
        bonusService.revertBonusConsumption(bonusConsumption, userName, reversedComment);

        assertThat(bonusConsumption.getBonusConsumptionStatus()).isEqualTo(BonusConsumptionStatusEnum.REVERSED);
        verify(bonusDAO).save(bonusConsumption);
        verify(bonusDAO).save(any(BonusTransaction.class));
        verify(bonusDAO).save(any(BonusEntry.class));
        verify(bonusDAO).save(any(BonusConsumptionReversal.class));
    }

    @Test
    public void testRevertBonusConsumptionCancelsServiceFeeIfAny() throws Exception {
        //@Given a bonus consumption to revert
        BonusConsumption bonusConsumption = new BonusConsumption();
        bonusConsumption.setAgreementTemplateType(agreementTemplateType);
        bonusConsumption.setConsumedAmount(BigDecimal.TEN);
        bonusConsumption.setGrower(grower);
        BonusConsumptionPayment payment = new BonusConsumptionPayment();
        ChargeConsolidate chargeConsolidate = new ChargeConsolidate();
        chargeConsolidate.setChargeConsolidateStatus(ChargeConsolidateStatus.RELEASED);
        List<BonusConsumptionPayment> paymentList = new ArrayList<BonusConsumptionPayment>();
        paymentList.add(payment);
        chargeConsolidate.setBonusConsumptionPaymentList(paymentList);
        ChargeGroup chargeGroup = new ChargeGroup();
        chargeGroup.setChargeGroupStatus(ChargeGroupStatus.WAITING_INTERFACE);
        chargeConsolidate.setChargeGroup(chargeGroup);
        payment.setServiceFee(chargeConsolidate);
        bonusConsumption.getPayments().add(payment);

        //@When
        String userName = "userName";
        String reversedComment = "Reversion comment";
        bonusService.revertBonusConsumption(bonusConsumption, userName, reversedComment);

        assertThat(bonusConsumption.getBonusConsumptionStatus()).isEqualTo(BonusConsumptionStatusEnum.REVERSED);
        verify(bonusDAO).save(bonusConsumption);
        verify(bonusDAO).save(any(BonusTransaction.class));
        verify(bonusDAO).save(any(BonusEntry.class));
        verify(bonusDAO).save(any(BonusConsumptionReversal.class));
        verify(saleItemAvailableRoyaltiesConsumerAndCalculator).revertSaleItemRoyaltySpentInBonusConsumptionPaymentFor(any(BonusConsumptionPayment.class));
        verify(chargeConsolidateService).cancelGroupedChargeConsolidate(any(ChargeGroup.class), any(ChargeConsolidate.class));
    }

    @Test
    public void testRevertBonusConsumptionCancelsServiceFeeIfAnyAndAdjustsRemainingSaleAmountOnlyIfNotAlready() throws Exception {
        //@Given a bonus consumption to revert
        BonusConsumption bonusConsumption = new BonusConsumption();
        bonusConsumption.setAgreementTemplateType(agreementTemplateType);
        bonusConsumption.setConsumedAmount(BigDecimal.TEN);
        bonusConsumption.setGrower(grower);
        BonusConsumptionPayment payment = new BonusConsumptionPayment();
        ChargeConsolidate chargeConsolidate = new ChargeConsolidate();
        chargeConsolidate.setChargeConsolidateStatus(ChargeConsolidateStatus.CANCELLED);
        List<BonusConsumptionPayment> paymentList = new ArrayList<BonusConsumptionPayment>();
        paymentList.add(payment);
        chargeConsolidate.setBonusConsumptionPaymentList(paymentList);
        ChargeGroup chargeGroup = new ChargeGroup();
        chargeGroup.setChargeGroupStatus(ChargeGroupStatus.CANCELLED);
        chargeConsolidate.setChargeGroup(chargeGroup);
        payment.setServiceFee(chargeConsolidate);
        bonusConsumption.getPayments().add(payment);

        //@When
        String userName = "userName";
        String reversedComment = "Reversion comment";
        bonusService.revertBonusConsumption(bonusConsumption, userName, reversedComment);

        assertThat(bonusConsumption.getBonusConsumptionStatus()).isEqualTo(BonusConsumptionStatusEnum.REVERSED);
        verify(bonusDAO).save(bonusConsumption);
        verify(bonusDAO).save(any(BonusTransaction.class));
        verify(bonusDAO).save(any(BonusEntry.class));
        verify(bonusDAO).save(any(BonusConsumptionReversal.class));
        verifyZeroInteractions(saleItemAvailableRoyaltiesConsumerAndCalculator);
        verifyZeroInteractions(chargePaymentService);
        verifyZeroInteractions(chargeConsolidateService);
    }

    @Test
    public void testRevertBonusConsumptionThrowsBusinessException_WhenNoAgreementIsFound() {
        //@Given
        BonusConsumption bonusConsumption = new BonusConsumption();
        bonusConsumption.setConsumedAmount(BigDecimal.TEN);
        bonusConsumption.setGrower(grower);
        when(baseService.selectGrowerByID(anyLong())).thenReturn(grower);

        //@When
        String userName = "userName";
        String reversedComment = "Reversion comment";
        try {
            bonusService.revertBonusConsumption(bonusConsumption, userName, reversedComment);
            fail("Should throw BusinessException error");
        } catch (Exception e) {
            //@Should
            assertThat(e).isInstanceOf(BusinessException.class).hasMessage("import.file.bulk.bonus.no.valid.agreement.found.1");
            assertThat(bonusConsumption.getReversed()).isFalse();
        }
    }

    @Test
    public void testPartiallyRevertBonusConsumptionUpdateBonusConsumptionEntityAndSaveIt() throws Exception {
        BonusConsumption bonusConsumption = new BonusConsumption();
        bonusConsumption.setAgreementTemplateType(agreementTemplateType);
        bonusConsumption.setConsumedAmount(new BigDecimal("100"));
        bonusConsumption.setGrower(grower);

        String userName = "userName";
        String reversedComment = "Reversion comment";
        bonusService.partiallyRevertBonusConsumption(bonusConsumption, userName, reversedComment, new BigDecimal("50.00"));

        assertThat(bonusConsumption.getBonusConsumptionStatus()).isEqualTo(BonusConsumptionStatusEnum.PARTIALLY_PAID_REVERSED);
        verify(bonusDAO).save(bonusConsumption);
        verify(bonusDAO).save(any(BonusTransaction.class));
        verify(bonusDAO).save(any(BonusEntry.class));
        verify(bonusDAO).save(any(BonusConsumptionReversal.class));
    }

    @Test
    public void testPartiallyRevertBonusConsumptionThrowsBusinessException_WhenNoAgreementIsFound() {
        BonusConsumption bonusConsumption = new BonusConsumption();
        bonusConsumption.setConsumedAmount(new BigDecimal("100"));
        bonusConsumption.setGrower(grower);
        when(baseService.selectGrowerByID(anyLong())).thenReturn(grower);

        String userName = "userName";
        String reversedComment = "Reversion comment";
        try {
            bonusService.partiallyRevertBonusConsumption(bonusConsumption, userName, reversedComment, new BigDecimal("50.00"));
            fail("Should throw BusinessException error");
        } catch (Exception e) {
            assertThat(e).isInstanceOf(BusinessException.class).hasMessage("import.file.bulk.bonus.no.valid.agreement.found.1");
            assertThat(bonusConsumption.getReversed()).isFalse();
        }
    }

    @Test
    public void testFindBonusConsumptionsEligibleForServiceFeeReturnsBonusConsumptions_whenServiceIsCalled() {
        bonusService.findBonusConsumptionsEligibleForServiceFee();

        verify(bonusDAO).findBonusConsumptionsEligibleForServiceFee();
    }

    @Test
    public void testFindBonusConsumptionsEligibleForServiceFeeReturnsEmptyValue_whenOneBonusConsumptionIsFoundAndIsFullyPaid() {
        BonusConsumption bonusConsumption = createBonusConsumption(BigDecimal.valueOf(100), BigDecimal.valueOf(100), null);
        List<BonusConsumption> bonusConsumptions = Lists.newArrayList(bonusConsumption);
        when(bonusDAO.findBonusConsumptionsEligibleForServiceFee()).thenReturn(bonusConsumptions);

        List<BonusConsumption> result = bonusService.findBonusConsumptionsEligibleForServiceFee();

        assertTrue(result.isEmpty());
    }

    @Test
    public void testFindBonusConsumptionsEligibleForServiceFeeReturnsBonusConsumption_whenOneBonusConsumptionIsFoundAndHasRemainingValueToBePaid() {
        BonusConsumption bonusConsumption = createBonusConsumption(BigDecimal.valueOf(100), BigDecimal.valueOf(99), null);
        List<BonusConsumption> bonusConsumptions = Lists.newArrayList(bonusConsumption);
        when(bonusDAO.findBonusConsumptionsEligibleForServiceFee()).thenReturn(bonusConsumptions);

        List<BonusConsumption> result = bonusService.findBonusConsumptionsEligibleForServiceFee();

        assertFalse(result.isEmpty());
    }

    @Test
    public void testConfirmVoucherReceivedBonusConsumption() throws Exception {
        //@Given
        BonusConsumption bonusConsumption = new BonusConsumption();
        bonusConsumption.setBonusConsumptionStatus(BonusConsumptionStatusEnum.VOUCHER_RECEIVED);
        List<BonusConsumption> bonusConsumptionsList = Collections.singletonList(bonusConsumption);
        when(bonusDAO.save(bonusConsumption)).thenReturn(bonusConsumption);

        //@When
        bonusService.confirmOrUndoVoucherReceivedBonusConsumption(bonusConsumptionsList, LOGIN_USER_ID);

        //@Then
        final ArgumentCaptor<BonusConsumption> bonusConsumptionArgumentCaptor = ArgumentCaptor.forClass(BonusConsumption.class);
        verify(bonusDAO).save(bonusConsumptionArgumentCaptor.capture());
        assertThat(bonusConsumptionArgumentCaptor.getValue().getBonusConsumptionStatus()).isEqualTo(BonusConsumptionStatusEnum.VOUCHER_RECEIVED);
        assertThat(bonusConsumptionArgumentCaptor.getValue().getVoucherReceivedUserId()).isEqualTo(LOGIN_USER_ID);
        assertThat(DATE_FORMATTER.format(bonusConsumptionArgumentCaptor.getValue().getVoucherReceivedDate())).isEqualTo
                (DATE_FORMATTER.format(new Date()));
    }

    @Test
    public void testUndoVoucherReceivedBonusConsumption() throws Exception {
        //@Given
        BonusConsumption bonusConsumption = new BonusConsumption();
        bonusConsumption.setBonusConsumptionStatus(BonusConsumptionStatusEnum.OPENED);
        bonusConsumption.setVoucherReceivedUserId(LOGIN_USER_ID);
        bonusConsumption.setVoucherReceivedDate(new Date());

        BonusConsumptionPayment payment = new BonusConsumptionPayment();

        ChargeConsolidate chargeConsolidate = new ChargeConsolidate();
        chargeConsolidate.setChargeConsolidateStatus(ChargeConsolidateStatus.RELEASED);
        List<BonusConsumptionPayment> paymentList = new ArrayList<BonusConsumptionPayment>();
        paymentList.add(payment);
        chargeConsolidate.setBonusConsumptionPaymentList(paymentList);

        ChargeGroup chargeGroup = new ChargeGroup();
        chargeGroup.setChargeGroupStatus(ChargeGroupStatus.WAITING_INTERFACE);
        chargeConsolidate.setChargeGroup(chargeGroup);

        payment.setServiceFee(chargeConsolidate);
        bonusConsumption.getPayments().add(payment);

        List<BonusConsumption> bonusConsumptionsList = Collections.singletonList(bonusConsumption);

        when(chargePaymentService.cancelChargeGroup(chargeGroup, chargeConsolidate)).thenReturn(chargeGroup);
        doNothing().when(chargeConsolidateService).cancelChargeConsolidate(chargeConsolidate);
        when(bonusDAO.save(bonusConsumption)).thenReturn(bonusConsumption);

        //@When
        bonusService.confirmOrUndoVoucherReceivedBonusConsumption(bonusConsumptionsList, LOGIN_USER_ID);

        //@Then
        final ArgumentCaptor<BonusConsumptionPayment> bonusConsumptionPaymentArgumentCaptor = ArgumentCaptor.forClass(BonusConsumptionPayment.class);
        verify(saleItemAvailableRoyaltiesConsumerAndCalculator).revertSaleItemRoyaltySpentInBonusConsumptionPaymentFor(bonusConsumptionPaymentArgumentCaptor.capture());
        assertThat(bonusConsumptionPaymentArgumentCaptor.getValue()).isEqualTo(payment);

        final ArgumentCaptor<ChargeGroup> chargeGroupArgumentCaptor = ArgumentCaptor.forClass(ChargeGroup.class);
        verify(chargeConsolidateService).cancelGroupedChargeConsolidate(chargeGroupArgumentCaptor.capture(), eq(chargeConsolidate));
        assertThat(chargeGroupArgumentCaptor.getValue().getChargeGroupStatus()).isEqualTo(ChargeGroupStatus
                .WAITING_INTERFACE);

        final ArgumentCaptor<ChargeConsolidate> chargeConsolidateArgumentCaptor = ArgumentCaptor.forClass
                (ChargeConsolidate.class);
        verify(chargeConsolidateService).cancelGroupedChargeConsolidate(eq(chargeGroup),chargeConsolidateArgumentCaptor.capture());
        assertThat(chargeConsolidateArgumentCaptor.getValue().getChargeConsolidateStatus()).isEqualTo
                (ChargeConsolidateStatus.RELEASED);

        final ArgumentCaptor<BonusConsumption> bonusConsumptionArgumentCaptor = ArgumentCaptor.forClass(BonusConsumption.class);
        verify(bonusDAO).save(bonusConsumptionArgumentCaptor.capture());
        assertThat(bonusConsumptionArgumentCaptor.getValue().getBonusConsumptionStatus()).isEqualTo
                (BonusConsumptionStatusEnum.OPENED);
        assertThat(bonusConsumptionArgumentCaptor.getValue().getVoucherReceivedUserId()).isNull();
        assertThat(bonusConsumptionArgumentCaptor.getValue().getVoucherReceivedDate()).isNull();

    }

    @Test
    public void testGenerateBonusConsumptionsPaysShouldReturnEmptyCollection_whenThereIsNoBonusToPay() throws BusinessException {
        //@Given
        List<BonusConsumption> bonusConsumptions = Lists.newArrayList();
        Customer aDealer = new Customer();
        Grower aGrower = new Grower();
        SaleTemplate aSaleTemplate = new SaleTemplate();
        ChargeConsolidate aServiceFee = new ChargeConsolidate();
        when(saleService.getSaleItemsByGrowerDealerSaleTemplateForBonusPayment(aDealer, aGrower, aSaleTemplate)).thenReturn(Lists.<SaleItem>newArrayList());
        //@When
        List<BonusConsumption> paidBonusConsumptions = bonusService.generateBonusConsumptionsPays(bonusConsumptions, aDealer, aGrower, aSaleTemplate, aServiceFee);
        //@Then
        assertThat(paidBonusConsumptions).isEmpty();
    }

    @Test
    public void testGenerateBonusConsumptionsPaysShouldCallGetSaleItemsByGrowerDealerSaleTemplateForBonusPayment() throws BusinessException {
        //@Given
        BonusConsumption bonusConsumption = createBonusConsumption(BigDecimal.valueOf(30), null, null);
        List<BonusConsumption> bonusConsumptions = Lists.newArrayList(bonusConsumption);
        Customer aDealer = new Customer();
        Grower aGrower = new Grower();
        SaleTemplate aSaleTemplate = new SaleTemplate();
        ChargeConsolidate aServiceFee = new ChargeConsolidate();
        //@When
        bonusService.generateBonusConsumptionsPays(bonusConsumptions, aDealer, aGrower, aSaleTemplate, aServiceFee);
        //@Then
        verify(saleService).getSaleItemsByGrowerDealerSaleTemplateForBonusPayment(aDealer, aGrower, aSaleTemplate);
    }

    @Test
    public void testGenerateBonusConsumptionsPaysShouldReturnEmptyCollection_whenThereIsNoSaleItemsToUseToPay() throws BusinessException {
        //@Given
        BonusConsumption bonusConsumption = createBonusConsumption(BigDecimal.valueOf(30), null, null);
        List<BonusConsumption> bonusConsumptions = Lists.newArrayList(bonusConsumption);
        Customer aDealer = new Customer();
        Grower aGrower = new Grower();
        SaleTemplate aSaleTemplate = new SaleTemplate();
        ChargeConsolidate aServiceFee = new ChargeConsolidate();
        when(saleService.getSaleItemsByGrowerDealerSaleTemplateForBonusPayment(aDealer, aGrower, aSaleTemplate)).thenReturn(Lists.<SaleItem>newArrayList());
        //@When
        List<BonusConsumption> paidBonusConsumptions = bonusService.generateBonusConsumptionsPays(bonusConsumptions, aDealer, aGrower, aSaleTemplate, aServiceFee);
        //@Then
        verify(saleService).getSaleItemsByGrowerDealerSaleTemplateForBonusPayment(aDealer, aGrower, aSaleTemplate);
        assertThat(paidBonusConsumptions).isEmpty();
    }

    @Test
    public void testGenerateBonusConsumptionsPaysShouldCallGetRevenueRecognitionForBonusConsumptionPayment_whenThereIsOneValidSaleItemAndOneValidBonusConsumption() throws BusinessException {
        //@Given
        BonusConsumption bonusConsumption = createBonusConsumption(BigDecimal.valueOf(30), null, null);
        List<BonusConsumption> bonusConsumptions = Lists.newArrayList(bonusConsumption);
        Sale sale = createMultiplierToGrowerSale();
        Billing billing = createFullyPaidBilling();
        SaleItem saleItem = createSaleItem(1l, BigDecimal.valueOf(30), billing);
        sale.addItem(saleItem);
        List<SaleItem> saleItems = Lists.newArrayList(saleItem);
        Grower grower = createGrower();
        Customer dealer = createDealer();
        SaleTemplate saleTemplate = createSaleTemplate();
        ChargeConsolidate serviceFee = new ChargeConsolidate();
        when(saleService.getSaleItemsByGrowerDealerSaleTemplateForBonusPayment(dealer, grower, saleTemplate)).thenReturn(saleItems);
        when(saleItemAvailableRoyaltiesConsumerAndCalculator.getAvailableRoyaltiesForPayment(saleItem)).thenReturn(BigDecimal.TEN);
        //@When
        bonusService.generateBonusConsumptionsPays(bonusConsumptions, dealer, grower, saleTemplate, serviceFee);
        //@Then
        verify(saleItemAvailableRoyaltiesConsumerAndCalculator).getAvailableRoyaltiesForPayment(saleItem);
    }

    @Test
    public void testGenerateBonusConsumptionsPaysShouldSaveBonusConumptionPaid_whenThereIsOneValidSaleItemAndOneValidBonusConsumption() throws BusinessException {
        //@Given
        BonusConsumption bonusConsumption = createBonusConsumption(BigDecimal.valueOf(30), null, null);
        List<BonusConsumption> bonusConsumptions = Lists.newArrayList(bonusConsumption);
        Sale sale = createMultiplierToGrowerSale();
        Billing billing = createFullyPaidBilling();
        SaleItem saleItem = createSaleItem(1l, BigDecimal.valueOf(30), billing);
        sale.addItem(saleItem);
        List<SaleItem> saleItems = Lists.newArrayList(saleItem);
        Grower grower = createGrower();
        Customer dealer = createDealer();
        SaleTemplate saleTemplate = createSaleTemplate();
        ChargeConsolidate serviceFee = new ChargeConsolidate();
        when(saleService.getSaleItemsByGrowerDealerSaleTemplateForBonusPayment(dealer, grower, saleTemplate)).thenReturn(saleItems);
        when(saleItemAvailableRoyaltiesConsumerAndCalculator.getAvailableRoyaltiesForPayment(saleItem)).thenReturn(BigDecimal.TEN);
        //@When
        List<BonusConsumption> paidBonusConsumptions = bonusService.generateBonusConsumptionsPays(bonusConsumptions, dealer, grower, saleTemplate, serviceFee);
        //@Then
        verify(bonusDAO).save(paidBonusConsumptions.get(0));
    }

    @Test
    public void testGenerateBonusConsumptionsPaysShouldUpdateSaleItem_whenThereIsOneValidSaleItemAndOneValidBonusConsumption() throws BusinessException {
        //@Given
        BonusConsumption bonusConsumption = createBonusConsumption(BigDecimal.valueOf(30), null, null);
        List<BonusConsumption> bonusConsumptions = Lists.newArrayList(bonusConsumption);
        Sale sale = createMultiplierToGrowerSale();
        Billing billing = createFullyPaidBilling();
        SaleItem saleItem = createSaleItem(1l, BigDecimal.valueOf(30), billing);
        sale.addItem(saleItem);
        List<SaleItem> saleItems = Lists.newArrayList(saleItem);
        Grower grower = createGrower();
        Customer dealer = createDealer();
        SaleTemplate saleTemplate = createSaleTemplate();
        ChargeConsolidate serviceFee = new ChargeConsolidate();
        when(saleService.getSaleItemsByGrowerDealerSaleTemplateForBonusPayment(dealer, grower, saleTemplate)).thenReturn(saleItems);
        when(saleItemAvailableRoyaltiesConsumerAndCalculator.getAvailableRoyaltiesForPayment(saleItem)).thenReturn(BigDecimal.TEN);
        //@When
        bonusService.generateBonusConsumptionsPays(bonusConsumptions, dealer, grower, saleTemplate, serviceFee);
        //@Then
        verify(saleItemAvailableRoyaltiesConsumerAndCalculator).consumeSaleItemRoyaltiesWithoutDoubleCheck(saleItem, BigDecimal.TEN);
    }

    @Test
    public void testGenerateBonusConsumptionsPaysShouldUpdateSaleItemTwice_whenThereIsOneSaleItemToPayTwoBonusConsumption() throws BusinessException {
        //@Given
        BonusConsumption bonusConsumption1 = createBonusConsumption(BigDecimal.valueOf(30), null, null);
        BonusConsumption bonusConsumption2 = createBonusConsumption(BigDecimal.valueOf(30), null, null);
        List<BonusConsumption> bonusConsumptions = Lists.newArrayList(bonusConsumption1, bonusConsumption2);
        Sale sale = createMultiplierToGrowerSale();
        Billing billing = createFullyPaidBilling();
        SaleItem saleItem = createSaleItem(1l, BigDecimal.valueOf(50), billing);
        sale.addItem(saleItem);
        List<SaleItem> saleItems = Lists.newArrayList(saleItem);
        Grower grower = createGrower();
        Customer dealer = createDealer();
        SaleTemplate saleTemplate = createSaleTemplate();
        ChargeConsolidate serviceFee = new ChargeConsolidate();
        when(saleService.getSaleItemsByGrowerDealerSaleTemplateForBonusPayment(dealer, grower, saleTemplate)).thenReturn(saleItems);
        when(saleItemAvailableRoyaltiesConsumerAndCalculator.getAvailableRoyaltiesForPayment(saleItem)).thenReturn(BigDecimal.valueOf(50), BigDecimal.valueOf(20));
        //@When
        bonusService.generateBonusConsumptionsPays(bonusConsumptions, dealer, grower, saleTemplate, serviceFee);
        //@Then
        verify(saleItemAvailableRoyaltiesConsumerAndCalculator).consumeSaleItemRoyaltiesWithoutDoubleCheck(saleItem, BigDecimal.valueOf(30));
        verify(saleItemAvailableRoyaltiesConsumerAndCalculator).consumeSaleItemRoyaltiesWithoutDoubleCheck(saleItem, BigDecimal.valueOf(20));
    }

    @Test
    public void testGenerateBonusConsumptionsShouldReturnEmptyCollection_whenThereIsOneSaleItemWithNoAvailableAmount() throws BusinessException {
        //@Given
        BonusConsumption bonusConsumption = createBonusConsumption(BigDecimal.valueOf(30), null, null);
        List<BonusConsumption> bonusConsumptions = Lists.newArrayList(bonusConsumption);
        Sale sale = createMultiplierToGrowerSale();
        Billing billing = createFullyPaidBilling();
        SaleItem saleItem = createSaleItem(1l, BigDecimal.valueOf(30), billing);
        sale.addItem(saleItem);
        List<SaleItem> saleItems = Lists.newArrayList(saleItem);
        Grower grower = createGrower();
        Customer dealer = createDealer();
        SaleTemplate saleTemplate = createSaleTemplate();
        ChargeConsolidate serviceFee = new ChargeConsolidate();
        when(saleService.getSaleItemsByGrowerDealerSaleTemplateForBonusPayment(dealer, grower, saleTemplate)).thenReturn(saleItems);
        when(saleItemAvailableRoyaltiesConsumerAndCalculator.getAvailableRoyaltiesForPayment(saleItem)).thenReturn(BigDecimal.ZERO);
        //@When
        List<BonusConsumption> bonusConsumptionsPaid = bonusService.generateBonusConsumptionsPays(bonusConsumptions, dealer, grower, saleTemplate, serviceFee);
        //@Then
        assertThat(bonusConsumptionsPaid).isEmpty();
    }

    @Test
    public void testGenerateBonusConsumptionsShouldReturnOneBonusConsumptionPaidWithOnePaymentWithPaidAmount30_whenThereIsOneSaleItemWithAvailableAmount30() throws BusinessException {
        //@Given
        BonusConsumption bonusConsumption = createBonusConsumption(BigDecimal.valueOf(30), null, null);
        List<BonusConsumption> bonusConsumptions = Lists.newArrayList(bonusConsumption);
        Sale sale = createMultiplierToGrowerSale();
        Billing billing = createFullyPaidBilling();
        SaleItem saleItem = createSaleItem(1l, BigDecimal.valueOf(30), billing);
        sale.addItem(saleItem);
        List<SaleItem> saleItems = Lists.newArrayList(saleItem);
        Grower grower = createGrower();
        Customer dealer = createDealer();
        SaleTemplate saleTemplate = createSaleTemplate();
        ChargeConsolidate serviceFee = new ChargeConsolidate();
        when(saleService.getSaleItemsByGrowerDealerSaleTemplateForBonusPayment(dealer, grower, saleTemplate)).thenReturn(saleItems);
        when(saleItemAvailableRoyaltiesConsumerAndCalculator.getAvailableRoyaltiesForPayment(saleItem)).thenReturn(BigDecimal.valueOf(30));
        //@When
        List<BonusConsumption> bonusConsumptionsPaid = bonusService.generateBonusConsumptionsPays(bonusConsumptions, dealer, grower, saleTemplate, serviceFee);
        //@Then
        assertThat(bonusConsumptionsPaid).hasSize(1);
        BonusConsumption consumption = bonusConsumptionsPaid.get(0);
        assertThat(consumption.getPayments()).hasSize(1);
        assertThat(consumption.getPayments()).onProperty("paidAmount").containsExactly(BigDecimal.valueOf(30));
        BonusConsumptionPayment payment = consumption.getPayments().get(0);
        assertThat(payment.getDetails()).hasSize(1);
        assertThat(payment.getDetails()).onProperty("amountSpent").containsExactly(BigDecimal.valueOf(30));
        assertThat(payment.getDetails()).onProperty("saleItem").containsExactly(saleItem);
    }

    @Test
    public void testGenerateBonusConsumptionsShouldReturnTwoBonusConsumptionsPaidWithOnePaymentWithPaidAmount30Each_whenThereIsOneSaleItemWithAvailableAmount60() throws BusinessException {
        //@Given
        BonusConsumption bonusConsumption1 = createBonusConsumption(BigDecimal.valueOf(30), null, null);
        BonusConsumption bonusConsumption2 = createBonusConsumption(BigDecimal.valueOf(30), null, null);
        List<BonusConsumption> bonusConsumptions = Lists.newArrayList(bonusConsumption1, bonusConsumption2);
        Sale sale = createMultiplierToGrowerSale();
        Billing billing = createFullyPaidBilling();
        SaleItem saleItem = createSaleItem(1l, BigDecimal.valueOf(60), billing);
        sale.addItem(saleItem);
        List<SaleItem> saleItems = Lists.newArrayList(saleItem);
        Grower grower = createGrower();
        Customer dealer = createDealer();
        SaleTemplate saleTemplate = createSaleTemplate();
        ChargeConsolidate serviceFee = new ChargeConsolidate();
        when(saleService.getSaleItemsByGrowerDealerSaleTemplateForBonusPayment(dealer, grower, saleTemplate)).thenReturn(saleItems);
        when(saleItemAvailableRoyaltiesConsumerAndCalculator.getAvailableRoyaltiesForPayment(saleItem)).thenReturn(BigDecimal.valueOf(60), BigDecimal.valueOf(30));
        //@When
        List<BonusConsumption> bonusConsumptionsPaid = bonusService.generateBonusConsumptionsPays(bonusConsumptions, dealer, grower, saleTemplate, serviceFee);
        //@Then
        assertThat(bonusConsumptionsPaid).hasSize(2);
        BonusConsumption consumption1 = bonusConsumptionsPaid.get(0);
        assertThat(consumption1.getPayments()).hasSize(1);
        assertThat(consumption1.getPayments()).onProperty("paidAmount").containsExactly(BigDecimal.valueOf(30));
        BonusConsumptionPayment payment1 = consumption1.getPayments().get(0);
        assertThat(payment1.getDetails()).hasSize(1);
        assertThat(payment1.getDetails()).onProperty("amountSpent").containsExactly(BigDecimal.valueOf(30));
        assertThat(payment1.getDetails()).onProperty("saleItem").containsExactly(saleItem);

        BonusConsumption consumption2 = bonusConsumptionsPaid.get(1);
        assertThat(consumption2.getPayments()).hasSize(1);
        assertThat(consumption2.getPayments()).onProperty("paidAmount").containsExactly(BigDecimal.valueOf(30));
        BonusConsumptionPayment payment2 = consumption2.getPayments().get(0);
        assertThat(payment2.getDetails()).hasSize(1);
        assertThat(payment2.getDetails()).onProperty("amountSpent").containsExactly(BigDecimal.valueOf(30));
        assertThat(payment2.getDetails()).onProperty("saleItem").containsExactly(saleItem);
    }

    @Test
    public void testGenerateBonusConsumptionsShouldReturnOneBonusConsumptionPaidWithOnePaymentWithPaidAmount60_whenThereIsTwoSaleItemsWithAvailableAmount30Each() throws BusinessException {
        //@Given
        BonusConsumption bonusConsumption = createBonusConsumption(BigDecimal.valueOf(60), null, null);
        List<BonusConsumption> bonusConsumptions = Lists.newArrayList(bonusConsumption);
        Sale sale = createMultiplierToGrowerSale();
        Billing billing = createFullyPaidBilling();
        SaleItem saleItem1 = createSaleItem(1l, BigDecimal.valueOf(30), billing);
        sale.addItem(saleItem1);
        SaleItem saleItem2 = createSaleItem(2l, BigDecimal.valueOf(30), billing);
        sale.addItem(saleItem2);
        List<SaleItem> saleItems = Lists.newArrayList(saleItem1, saleItem2);
        Grower grower = createGrower();
        Customer dealer = createDealer();
        SaleTemplate saleTemplate = createSaleTemplate();
        ChargeConsolidate serviceFee = new ChargeConsolidate();
        when(saleService.getSaleItemsByGrowerDealerSaleTemplateForBonusPayment(dealer, grower, saleTemplate)).thenReturn(saleItems);
        when(saleItemAvailableRoyaltiesConsumerAndCalculator.getAvailableRoyaltiesForPayment(saleItem1)).thenReturn(BigDecimal.valueOf(30));
        when(saleItemAvailableRoyaltiesConsumerAndCalculator.getAvailableRoyaltiesForPayment(saleItem2)).thenReturn(BigDecimal.valueOf(30));
        //@When
        List<BonusConsumption> bonusConsumptionsPaid = bonusService.generateBonusConsumptionsPays(bonusConsumptions, dealer, grower, saleTemplate, serviceFee);
        //@Then
        assertThat(bonusConsumptionsPaid).hasSize(1);
        BonusConsumption consumption = bonusConsumptionsPaid.get(0);
        assertThat(consumption.getPayments()).hasSize(1);
        assertThat(consumption.getPayments()).onProperty("paidAmount").containsExactly(BigDecimal.valueOf(60));
        BonusConsumptionPayment payment = consumption.getPayments().get(0);
        assertThat(payment.getDetails()).hasSize(2);
        assertThat(payment.getDetails()).onProperty("amountSpent").containsExactly(BigDecimal.valueOf(30), BigDecimal.valueOf(30));
        assertThat(payment.getDetails()).onProperty("saleItem").containsExactly(saleItem1, saleItem2);
    }

    @Test
    public void testGenerateBonusConsumptionsShouldReturnOneBonusConsumptionPaidWithOnePaymentWithPaidAmount80_whenThereIsTwoSaleItemsWithAvailableAmount30Each() throws BusinessException {
        //@Given
        BonusConsumption bonusConsumption = createBonusConsumption(BigDecimal.valueOf(80), null, null);
        List<BonusConsumption> bonusConsumptions = Lists.newArrayList(bonusConsumption);
        Sale sale = createMultiplierToGrowerSale();
        Billing billing = createFullyPaidBilling();
        SaleItem saleItem1 = createSaleItem(1l, BigDecimal.valueOf(30), billing);
        sale.addItem(saleItem1);
        SaleItem saleItem2 = createSaleItem(2l, BigDecimal.valueOf(30), billing);
        sale.addItem(saleItem2);
        List<SaleItem> saleItems = Lists.newArrayList(saleItem1, saleItem2);
        Grower grower = createGrower();
        Customer dealer = createDealer();
        SaleTemplate saleTemplate = createSaleTemplate();
        ChargeConsolidate serviceFee = new ChargeConsolidate();
        when(saleService.getSaleItemsByGrowerDealerSaleTemplateForBonusPayment(dealer, grower, saleTemplate)).thenReturn(saleItems);
        when(saleItemAvailableRoyaltiesConsumerAndCalculator.getAvailableRoyaltiesForPayment(saleItem1)).thenReturn(BigDecimal.valueOf(30));
        when(saleItemAvailableRoyaltiesConsumerAndCalculator.getAvailableRoyaltiesForPayment(saleItem2)).thenReturn(BigDecimal.valueOf(30));
        //@When
        List<BonusConsumption> bonusConsumptionsPaid = bonusService.generateBonusConsumptionsPays(bonusConsumptions, dealer, grower, saleTemplate, serviceFee);
        //@Then
        assertThat(bonusConsumptionsPaid).hasSize(1);
        BonusConsumption consumption = bonusConsumptionsPaid.get(0);
        assertThat(consumption.getPayments()).hasSize(1);
        assertThat(consumption.getPayments()).onProperty("paidAmount").containsExactly(BigDecimal.valueOf(60));
        BonusConsumptionPayment payment = consumption.getPayments().get(0);
        assertThat(payment.getDetails()).hasSize(2);
        assertThat(payment.getDetails()).onProperty("amountSpent").containsExactly(BigDecimal.valueOf(30), BigDecimal.valueOf(30));
        assertThat(payment.getDetails()).onProperty("saleItem").containsExactly(saleItem1, saleItem2);
    }

    @Test
    public void testGenerateBonusConsumptionsShouldReturnOneBonusConsumptionPaidWithOnePaymentWithPaidAmount60_whenThereIsTwoSaleItemsWithAvailableAmount40Each() throws BusinessException {
        //@Given
        BonusConsumption bonusConsumption = createBonusConsumption(BigDecimal.valueOf(60), null, null);
        List<BonusConsumption> bonusConsumptions = Lists.newArrayList(bonusConsumption);
        Sale sale = createMultiplierToGrowerSale();
        Billing billing = createFullyPaidBilling();
        SaleItem saleItem1 = createSaleItem(1l, BigDecimal.valueOf(40), billing);
        sale.addItem(saleItem1);
        SaleItem saleItem2 = createSaleItem(2l, BigDecimal.valueOf(40), billing);
        sale.addItem(saleItem2);
        List<SaleItem> saleItems = Lists.newArrayList(saleItem1, saleItem2);
        Grower grower = createGrower();
        Customer dealer = createDealer();
        SaleTemplate saleTemplate = createSaleTemplate();
        ChargeConsolidate serviceFee = new ChargeConsolidate();
        when(saleService.getSaleItemsByGrowerDealerSaleTemplateForBonusPayment(dealer, grower, saleTemplate)).thenReturn(saleItems);
        when(saleItemAvailableRoyaltiesConsumerAndCalculator.getAvailableRoyaltiesForPayment(saleItem1)).thenReturn(BigDecimal.valueOf(40));
        when(saleItemAvailableRoyaltiesConsumerAndCalculator.getAvailableRoyaltiesForPayment(saleItem2)).thenReturn(BigDecimal.valueOf(40));
        //@When
        List<BonusConsumption> bonusConsumptionsPaid = bonusService.generateBonusConsumptionsPays(bonusConsumptions, dealer, grower, saleTemplate, serviceFee);
        //@Then
        assertThat(bonusConsumptionsPaid).hasSize(1);
        BonusConsumption consumption = bonusConsumptionsPaid.get(0);
        assertThat(consumption.getPayments()).hasSize(1);
        assertThat(consumption.getPayments()).onProperty("paidAmount").containsExactly(BigDecimal.valueOf(60));
        BonusConsumptionPayment payment = consumption.getPayments().get(0);
        assertThat(payment.getDetails()).hasSize(2);
        assertThat(payment.getDetails()).onProperty("amountSpent").containsExactly(BigDecimal.valueOf(40), BigDecimal.valueOf(20));
        assertThat(payment.getDetails()).onProperty("saleItem").containsExactly(saleItem1, saleItem2);
    }

    @Test
    public void testGenerateBonusConsumptionsShouldReturnOneBonusConsumptionPaidWithOnePaymentWithPaidAmount60_whenThereIsTwoSaleItemsWithAvailableAmount60And40() throws BusinessException {
        //@Given
        BonusConsumption bonusConsumption = createBonusConsumption(BigDecimal.valueOf(60), null, null);
        List<BonusConsumption> bonusConsumptions = Lists.newArrayList(bonusConsumption);
        Sale sale = createMultiplierToGrowerSale();
        Billing billing = createFullyPaidBilling();
        SaleItem saleItem1 = createSaleItem(1l, BigDecimal.valueOf(60), billing);
        sale.addItem(saleItem1);
        SaleItem saleItem2 = createSaleItem(2l, BigDecimal.valueOf(40), billing);
        sale.addItem(saleItem2);
        List<SaleItem> saleItems = Lists.newArrayList(saleItem1, saleItem2);
        Grower grower = createGrower();
        Customer dealer = createDealer();
        SaleTemplate saleTemplate = createSaleTemplate();
        ChargeConsolidate serviceFee = new ChargeConsolidate();
        when(saleService.getSaleItemsByGrowerDealerSaleTemplateForBonusPayment(dealer, grower, saleTemplate)).thenReturn(saleItems);
        when(saleItemAvailableRoyaltiesConsumerAndCalculator.getAvailableRoyaltiesForPayment(saleItem1)).thenReturn(BigDecimal.valueOf(60));
        when(saleItemAvailableRoyaltiesConsumerAndCalculator.getAvailableRoyaltiesForPayment(saleItem2)).thenReturn(BigDecimal.valueOf(40));
        //@When
        List<BonusConsumption> bonusConsumptionsPaid = bonusService.generateBonusConsumptionsPays(bonusConsumptions, dealer, grower, saleTemplate, serviceFee);
        //@Then
        assertThat(bonusConsumptionsPaid).hasSize(1);
        BonusConsumption consumption = bonusConsumptionsPaid.get(0);
        assertThat(consumption.getPayments()).hasSize(1);
        assertThat(consumption.getPayments()).onProperty("paidAmount").containsExactly(BigDecimal.valueOf(60));
        BonusConsumptionPayment payment = consumption.getPayments().get(0);
        assertThat(payment.getDetails()).hasSize(1);
        assertThat(payment.getDetails()).onProperty("amountSpent").containsExactly(BigDecimal.valueOf(60));
        assertThat(payment.getDetails()).onProperty("saleItem").containsExactly(saleItem1);
    }

    @Test
    public void testGenerateBonusConsumptionsShouldReturnOneBonusConsumptionPaidWithOnePaymentWithPaidAmount60_whenThereIsTwoSaleItemsWithAvailableAmount70And40() throws BusinessException {
        //@Given
        BonusConsumption bonusConsumption = createBonusConsumption(BigDecimal.valueOf(60), null, null);
        List<BonusConsumption> bonusConsumptions = Lists.newArrayList(bonusConsumption);
        Sale sale = createMultiplierToGrowerSale();
        Billing billing = createFullyPaidBilling();
        SaleItem saleItem1 = createSaleItem(1l, BigDecimal.valueOf(70), billing);
        sale.addItem(saleItem1);
        SaleItem saleItem2 = createSaleItem(2l, BigDecimal.valueOf(40), billing);
        sale.addItem(saleItem2);
        List<SaleItem> saleItems = Lists.newArrayList(saleItem1, saleItem2);
        Grower grower = createGrower();
        Customer dealer = createDealer();
        SaleTemplate saleTemplate = createSaleTemplate();
        ChargeConsolidate serviceFee = new ChargeConsolidate();
        when(saleService.getSaleItemsByGrowerDealerSaleTemplateForBonusPayment(dealer, grower, saleTemplate)).thenReturn(saleItems);
        when(saleItemAvailableRoyaltiesConsumerAndCalculator.getAvailableRoyaltiesForPayment(saleItem1)).thenReturn(BigDecimal.valueOf(70));
        when(saleItemAvailableRoyaltiesConsumerAndCalculator.getAvailableRoyaltiesForPayment(saleItem2)).thenReturn(BigDecimal.valueOf(40));
        //@When
        List<BonusConsumption> bonusConsumptionsPaid = bonusService.generateBonusConsumptionsPays(bonusConsumptions, dealer, grower, saleTemplate, serviceFee);
        //@Then
        assertThat(bonusConsumptionsPaid).hasSize(1);
        BonusConsumption consumption = bonusConsumptionsPaid.get(0);
        assertThat(consumption.getPayments()).hasSize(1);
        assertThat(consumption.getPayments()).onProperty("paidAmount").containsExactly(BigDecimal.valueOf(60));
        BonusConsumptionPayment payment = consumption.getPayments().get(0);
        assertThat(payment.getDetails()).hasSize(1);
        assertThat(payment.getDetails()).onProperty("amountSpent").containsExactly(BigDecimal.valueOf(60));
        assertThat(payment.getDetails()).onProperty("saleItem").containsExactly(saleItem1);
    }

    @Test
    public void testGenerateBonusConsumptionsShouldReturnOneBonusConsumptionPaidWithOnePaymentWithPaidAmount60_whenThereIsTwoSaleItemsWithAvailableAmount40And70() throws BusinessException {
        //@Given
        BonusConsumption bonusConsumption = createBonusConsumption(BigDecimal.valueOf(60), null, null);
        List<BonusConsumption> bonusConsumptions = Lists.newArrayList(bonusConsumption);
        Sale sale = createMultiplierToGrowerSale();
        Billing billing = createFullyPaidBilling();
        SaleItem saleItem1 = createSaleItem(1l, BigDecimal.valueOf(40), billing);
        sale.addItem(saleItem1);
        SaleItem saleItem2 = createSaleItem(2l, BigDecimal.valueOf(70), billing);
        sale.addItem(saleItem2);
        List<SaleItem> saleItems = Lists.newArrayList(saleItem1, saleItem2);
        Grower grower = createGrower();
        Customer dealer = createDealer();
        SaleTemplate saleTemplate = createSaleTemplate();
        ChargeConsolidate serviceFee = new ChargeConsolidate();
        when(saleService.getSaleItemsByGrowerDealerSaleTemplateForBonusPayment(dealer, grower, saleTemplate)).thenReturn(saleItems);
        when(saleItemAvailableRoyaltiesConsumerAndCalculator.getAvailableRoyaltiesForPayment(saleItem1)).thenReturn(BigDecimal.valueOf(40));
        when(saleItemAvailableRoyaltiesConsumerAndCalculator.getAvailableRoyaltiesForPayment(saleItem2)).thenReturn(BigDecimal.valueOf(70));
        //@When
        List<BonusConsumption> bonusConsumptionsPaid = bonusService.generateBonusConsumptionsPays(bonusConsumptions, dealer, grower, saleTemplate, serviceFee);
        //@Then
        assertThat(bonusConsumptionsPaid).hasSize(1);
        BonusConsumption consumption = bonusConsumptionsPaid.get(0);
        assertThat(consumption.getPayments()).hasSize(1);
        assertThat(consumption.getPayments()).onProperty("paidAmount").containsExactly(BigDecimal.valueOf(60));
        BonusConsumptionPayment payment = consumption.getPayments().get(0);
        assertThat(payment.getDetails()).hasSize(2);
        assertThat(payment.getDetails()).onProperty("amountSpent").containsExactly(BigDecimal.valueOf(40), BigDecimal.valueOf(20));
        assertThat(payment.getDetails()).onProperty("saleItem").containsExactly(saleItem1, saleItem2);
    }

    @Test
    public void testGenerateBonusConsumptionsShouldReturnTwoBonusConsumptionsPaidWithOnePaymentWithPaidAmount60Each_whenThereIsTwoSaleItemsWithAvailableAmount60EachAndTwoBonusConsumptionsWithPayableAmountOf60Each() throws BusinessException {
        //@Given
        BonusConsumption bonusConsumption1 = createBonusConsumption(BigDecimal.valueOf(60), null, null);
        BonusConsumption bonusConsumption2 = createBonusConsumption(BigDecimal.valueOf(60), null, null);
        List<BonusConsumption> bonusConsumptions = Lists.newArrayList(bonusConsumption1, bonusConsumption2);
        Sale sale = createMultiplierToGrowerSale();
        Billing billing = createFullyPaidBilling();
        SaleItem saleItem1 = createSaleItem(1l, BigDecimal.valueOf(60), billing);
        sale.addItem(saleItem1);
        SaleItem saleItem2 = createSaleItem(2l, BigDecimal.valueOf(60), billing);
        sale.addItem(saleItem2);
        List<SaleItem> saleItems = Lists.newArrayList(saleItem1, saleItem2);
        Grower grower = createGrower();
        Customer dealer = createDealer();
        SaleTemplate saleTemplate = createSaleTemplate();
        ChargeConsolidate serviceFee = new ChargeConsolidate();
        when(saleService.getSaleItemsByGrowerDealerSaleTemplateForBonusPayment(dealer, grower, saleTemplate)).thenReturn(saleItems);
        when(saleItemAvailableRoyaltiesConsumerAndCalculator.getAvailableRoyaltiesForPayment(saleItem1)).thenReturn(BigDecimal.valueOf(60), BigDecimal.valueOf(60));
        when(saleItemAvailableRoyaltiesConsumerAndCalculator.getAvailableRoyaltiesForPayment(saleItem2)).thenReturn(BigDecimal.valueOf(60), BigDecimal.valueOf(60));
        //@When
        List<BonusConsumption> bonusConsumptionsPaid = bonusService.generateBonusConsumptionsPays(bonusConsumptions, dealer, grower, saleTemplate, serviceFee);
        //@Then
        assertThat(bonusConsumptionsPaid).hasSize(2);
        BonusConsumption consumption1 = bonusConsumptionsPaid.get(0);
        assertThat(consumption1.getPayments()).hasSize(1);
        assertThat(consumption1.getPayments()).onProperty("paidAmount").containsExactly(BigDecimal.valueOf(60));
        BonusConsumptionPayment payment1 = consumption1.getPayments().get(0);
        assertThat(payment1.getDetails()).hasSize(1);
        assertThat(payment1.getDetails()).onProperty("amountSpent").containsExactly(BigDecimal.valueOf(60));
        assertThat(payment1.getDetails()).onProperty("saleItem").containsExactly(saleItem1);

        BonusConsumption consumption2 = bonusConsumptionsPaid.get(1);
        assertThat(consumption2.getPayments()).hasSize(1);
        assertThat(consumption2.getPayments()).onProperty("paidAmount").containsExactly(BigDecimal.valueOf(60));
        BonusConsumptionPayment payment2 = consumption2.getPayments().get(0);
        assertThat(payment2.getDetails()).hasSize(1);
        assertThat(payment2.getDetails()).onProperty("amountSpent").containsExactly(BigDecimal.valueOf(60));
        assertThat(payment2.getDetails()).onProperty("saleItem").containsExactly(saleItem1);
    }

    private BonusConsumption createBonusConsumption(BigDecimal consumedAmount, BigDecimal paidAmount, BigDecimal reversalAmount) {
        BonusConsumption bonusConsumption = new BonusConsumption();
        Grower grower = createGrower();
        bonusConsumption.setGrower(grower);
        bonusConsumption.setConsumedAmount(consumedAmount);
        if (paidAmount != null) {
            ArrayList<BonusConsumptionPayment> payments = new ArrayList<BonusConsumptionPayment>();
            BonusConsumptionPayment bonusConsumptionPayment = new BonusConsumptionPayment();
            bonusConsumptionPayment.setPaidAmount(paidAmount);
            ChargeConsolidate serviceFee = new ChargeConsolidate();
            ChargeGroup chargeGroup = new ChargeGroup();
            chargeGroup.setChargeGroupStatus(ChargeGroupStatus.PROCESSED);
            serviceFee.setChargeGroup(chargeGroup);
            bonusConsumptionPayment.setServiceFee(serviceFee);
            payments.add(bonusConsumptionPayment);
            bonusConsumption.setPayments(payments);
        }
        if (reversalAmount != null) {
            List<BonusConsumptionReversal> reversals = new ArrayList<BonusConsumptionReversal>();
            BonusConsumptionReversal bonusConsumptionReversal = new BonusConsumptionReversal();
            bonusConsumptionReversal.setReversedAmount(reversalAmount);
            reversals.add(bonusConsumptionReversal);
            bonusConsumption.setReversals(reversals);
        }
        return bonusConsumption;
    }

    public Sale createMultiplierToGrowerSale() {
        Sale sale = new Sale();
        sale.setSaleType(Sale.SaleTypeEnum.MULTIPLIER_TO_GROWER_SEED_SALE);
        return sale;
    }

    public Billing createFullyPaidBilling() {
        Billing billing = new Billing();
        billing.setPaymentStatus(PaymentStatus.FULLY_PAID);
        return billing;
    }

    public SaleItem createSaleItem(long id, BigDecimal netRoyaltyValueQuantity, Billing billing) {
        SaleItem saleItem = new SaleItem();
        saleItem.setId(id);
        saleItem.setNetRoyaltyValueQuantity(netRoyaltyValueQuantity);
        saleItem.setBilling(billing);
        return saleItem;
    }

    public Grower createGrower() {
        Grower grower = new Grower();
        grower.setName("DUMMY_GROWER");
        return grower;
    }

    public Customer createDealer() {
        Customer dealer = new Customer();
        dealer.setName("DUMMY_DEALER");
        return dealer;
    }

    public SaleTemplate createSaleTemplate() {
        SaleTemplate saleTemplate = new SaleTemplate();
        saleTemplate.setDescription("DUMMY_SALE_TEMPLATE");
        return saleTemplate;
    }

    @Test
    public void findAgreementByGrowerAndTechnologyWhenIncludingPendingShouldReturnPendingApprovalAgreement(){
        try {
            //we add an agreement with pending approval state
            Agreement agreement = new Agreement();
            Technology technology = new Technology();
            agreement.setStatus(Agreement.AgreementStatusEnum.PENDING_APPROVAL);
            AgreementTemplate agreementTemplate = new AgreementTemplate();
            agreementTemplate.setAgreementTemplateType(agreementTemplateType);
            agreementTemplate.setTechnology(technology);
            agreement.setAgreementTemplate(agreementTemplate);
            grower.getAgreements().clear();
            grower.addAgreement(agreement);

            Agreement agreement1 = bonusService.findAgreementBy(grower, technology, true);
            assertNotNull(agreement1);
            assertEquals(Agreement.AgreementStatusEnum.PENDING_APPROVAL,agreement1.getStatus());

        } catch (Exception e) {
            fail("Should not throw exception");
        }
    }

}