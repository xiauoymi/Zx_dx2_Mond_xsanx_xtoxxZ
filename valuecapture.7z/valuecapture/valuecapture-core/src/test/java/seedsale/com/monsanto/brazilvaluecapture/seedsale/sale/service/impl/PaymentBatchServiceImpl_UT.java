package com.monsanto.brazilvaluecapture.seedsale.sale.service.impl;

import com.google.common.collect.Lists;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Customer;
import com.monsanto.brazilvaluecapture.core.grower.model.bean.Grower;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.PaymentBatch;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.Sale;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.dao.PaymentBatchDAO;
import com.monsanto.brazilvaluecapture.seedsale.sale.service.PaymentBatchConstraintViolationException;
import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

import static org.fest.assertions.Assertions.assertThat;
import static org.fest.reflect.core.Reflection.field;
import static org.junit.Assert.fail;
import static org.mockito.Matchers.same;
import static org.mockito.Mockito.*;

/**
 * Created by IntelliJ IDEA.
 * User: PPERA
 * Date: 3/13/13
 * Time: 9:50 AM
 */
public class PaymentBatchServiceImpl_UT {
    private PaymentBatchServiceImpl paymentBatchService;
    private PaymentBatchDAO paymentBatchDao;

    @Before
    public void setUp() {
        this.paymentBatchService = new PaymentBatchServiceImpl();
        this.paymentBatchDao = mock(PaymentBatchDAO.class);
        field("paymentBatchDAO").ofType(PaymentBatchDAO.class).in(this.paymentBatchService).set(this.paymentBatchDao);
    }

    @Test
    public void testListPaymentBatchesByRetailerCallsPaymentBatchDaoListPaymentBatchesByRetailerWithInputRetailer_WhenListingPaymentBatchesOfInputRetailer() {
        // @Given a retailer
        Customer retailer = new Customer();

        // @When listing it's payment batches
        this.paymentBatchService.listPaymentBatchesByRetailer(retailer);

        // @Then paymentBatchDao.listPaymentBatchesByRetailer is called for this retailer
        verify(this.paymentBatchDao, times(1)).listPaymentBatchesByRetailer(same(retailer));
    }

    @Test
    public void testListPaymentBatchesByRetailerReturnsDaoResult_WhenListingPaymentBatchesByRetailer() {
        // @Given a retailer
        Customer retailer = new Customer();
        when(this.paymentBatchDao.listPaymentBatchesByRetailer(retailer)).thenReturn(new ArrayList<PaymentBatch>());

        // @When listing it's payment batches
        List<PaymentBatch> paymentBatches = this.paymentBatchService.listPaymentBatchesByRetailer(retailer);

        // @Then those batches found by the Dao are returned
        assertThat(paymentBatches).isSameAs(this.paymentBatchDao.listPaymentBatchesByRetailer(retailer));
    }

    @Test
    public void testSaveCallsPaymentBatchDaoSave_WhenSavingAPaymentBatch() throws PaymentBatchConstraintViolationException {
        // @Given a payment batch
        PaymentBatch paymentBatch = new PaymentBatch();
        paymentBatch.setSales(Lists.<Sale>newArrayList(new Sale(new Customer(), new Grower())));

        // @When saving the payment batch
        this.paymentBatchService.save(paymentBatch);

        // @Then PaymentBatchDao.save is called for the input
        verify(this.paymentBatchDao, times(1)).save(same(paymentBatch));
    }

    @Test
    public void testSaveReturnsDaoSaveReturnedBatch_WhenSavingAPaymentBatch() throws PaymentBatchConstraintViolationException {
        // @Given a payment batch
        PaymentBatch paymentBatch = new PaymentBatch();
        paymentBatch.setSales(Lists.<Sale>newArrayList(new Sale(new Customer(), new Grower())));

        when(this.paymentBatchDao.save(paymentBatch)).thenReturn(new PaymentBatch());

        // @When saving a payment batch
        PaymentBatch batch = this.paymentBatchService.save(paymentBatch);

        // @Then PaymentBachDao.save return value is returned
        assertThat(batch).isSameAs(this.paymentBatchDao.save(paymentBatch));
    }

    @Test
    public void testSaveThrowsPaymentBatchConstraintViolationException_WhenSavingAPaymentBatchWithNullSales() throws PaymentBatchConstraintViolationException {
        // @Given a payment batch
        PaymentBatch paymentBatch = new PaymentBatch();
        when(this.paymentBatchDao.save(paymentBatch)).thenReturn(new PaymentBatch());

        // @When saving a payment batch
        try{
            this.paymentBatchService.save(paymentBatch);
            fail();
        }catch (PaymentBatchConstraintViolationException e){
            // @Then a PaymentBatchConstraintViolationException is thrown
            assertThat(e).hasMessage("Sales can not be empty");
            assertThat(e.getBundleMsgKey()).isEqualTo("error.payment-batch.emptylist");
        }catch (Exception e){
            fail();
        }
    }

    @Test
    public void testUndoCallsPaymentBatchDaoRemove_WhenUndoingAPaymentBatch() {
        // @Given a payment batch
        PaymentBatch paymentBatch = new PaymentBatch();

        // @When saving the payment batch
        this.paymentBatchService.undo(paymentBatch);

        // @Then PaymentBatchDao.save is called for the input
        verify(this.paymentBatchDao, times(1)).remove(same(paymentBatch));
    }
}
