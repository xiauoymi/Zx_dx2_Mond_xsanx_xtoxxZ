package com.monsanto.brazilvaluecapture.core.quota.model.bean;

import com.monsanto.brazilvaluecapture.core.grower.model.bean.Grower;
import com.monsanto.brazilvaluecapture.seedsale.warehouse.model.bean.Warehouse;
import org.junit.Test;

import java.math.BigDecimal;
import java.util.List;

import static org.fest.assertions.Assertions.assertThat;
import static org.fest.reflect.core.Reflection.field;
import static org.mockito.Matchers.same;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;

/**
 * User: PPERA
 * Date: 6/15/13
 * Time: 4:32 PM
 */
public class DeliveryQuotaFY_UT {
    @Test
    public void testAddQuotaCallsQuotaListAddWithInputQuota_WhenAddingAQuotaToTheDeliveryQuotaFy() {
        // @Given a DeliveryQuotaFy with quotaList and a QuotaFy
        DeliveryQuotaFY deliveryQuotaFY = new DeliveryQuotaFY();
        QuotaFY quotaFY = new QuotaFY();
        List<QuotaFY> quotaFYList = mock(List.class);
        field("quotaFys").ofType(List.class).in(deliveryQuotaFY).set(quotaFYList);

        // @When adding the quotaFy to the delivery quota
        deliveryQuotaFY.addQuota(quotaFY);

        // @Then the quotaFy is added to the deliveryQuota's quota list
        verify(quotaFYList).add(same(quotaFY));
    }

    @Test
    public void testGetBalanceReturns0_WhenDeliveryQuotaHasNoQuotas() {
        // @Given a DeliveryQuotaFy with no quotas
        DeliveryQuotaFY deliveryQuotaFY = new DeliveryQuotaFY();

        // @When calculating the balance of the delivery quota
        BigDecimal balance = deliveryQuotaFY.getBalance();

        // @Then the balance is 0
        assertThat(balance).isEqualTo(BigDecimal.ZERO);
    }

    @Test
    public void testGetBalanceReturns10_WhenDeliveryQuotaHasOneQuotaWithBalance10() {
        // @Given a DeliveryQuotaFy with one quota with balance 10
        DeliveryQuotaFY deliveryQuotaFY = new DeliveryQuotaFY();
        QuotaFY quotaFY = new QuotaFY();
        quotaFY.setDeliveryBalance(BigDecimal.valueOf(10));
        deliveryQuotaFY.addQuota(quotaFY);

        // @When calculating the balance of the delivery quota
        BigDecimal balance = deliveryQuotaFY.getBalance();

        // @Then the balance is 10
        assertThat(balance).isEqualTo(BigDecimal.valueOf(10));
    }

    @Test
    public void testGetBalanceReturns54_WhenDeliveryQuotaHasOneQuotaWithBalance54() {
        // @Given a DeliveryQuotaFy with a quota balance 54
        DeliveryQuotaFY deliveryQuotaFY = new DeliveryQuotaFY();
        QuotaFY quotaFY = new QuotaFY();
        quotaFY.setDeliveryBalance(BigDecimal.valueOf(54));
        deliveryQuotaFY.addQuota(quotaFY);

        // @When calculating the balance of the delivery quota
        BigDecimal balance = deliveryQuotaFY.getBalance();

        // @Then the balance is 54
        assertThat(balance).isEqualTo(BigDecimal.valueOf(54));
    }

    @Test
    public void testGetBalanceReturns21_WhenDeliveryQuotaHasTwoQuotaWithBalances10And11() {
        // @Given a DeliveryQuotaFy with two quotas balance 10 and 11
        DeliveryQuotaFY deliveryQuotaFY = new DeliveryQuotaFY();
        QuotaFY quotaFY1 = new QuotaFY();
        quotaFY1.setDeliveryBalance(BigDecimal.valueOf(10));
        QuotaFY quotaFY2 = new QuotaFY();
        quotaFY2.setDeliveryBalance(BigDecimal.valueOf(11));
        deliveryQuotaFY.addQuota(quotaFY1);
        deliveryQuotaFY.addQuota(quotaFY2);

        // @When calculating the balance of the delivery quota
        BigDecimal balance = deliveryQuotaFY.getBalance();

        // @Then the balance is 21
        assertThat(balance).isEqualTo(BigDecimal.valueOf(21));
    }

    @Test
    public void testGetQuotaFyIdsReturns1_WhenDeliveryQuotaHasOneQuotaId1() {
        // @Given a DeliveryQuotaFy with one quota 1
        DeliveryQuotaFY deliveryQuotaFY = new DeliveryQuotaFY();
        QuotaFY quotaFY = new QuotaFY();
        quotaFY.setId(1l);
        deliveryQuotaFY.addQuota(quotaFY);

        // @When getting the quota ids
        List<Long> quotaFYIds = deliveryQuotaFY.getQuotaFYIds();

        // @Then id 1 is returned
        assertThat(quotaFYIds).containsOnly(1l);
    }

    @Test
    public void testGetQuotaFyIdsReturns2_WhenDeliveryQuotaHasOneQuotaId2() {
        // @Given a DeliveryQuotaFy with one quota 1
        DeliveryQuotaFY deliveryQuotaFY = new DeliveryQuotaFY();
        QuotaFY quotaFY = new QuotaFY();
        quotaFY.setId(2l);
        deliveryQuotaFY.addQuota(quotaFY);

        // @When getting the quota ids
        List<Long> quotaFYIds = deliveryQuotaFY.getQuotaFYIds();

        // @Then id 1 is returned
        assertThat(quotaFYIds).containsOnly(2l);
    }

    @Test
    public void testGetQuotaFyIdsReturns3And4_WhenDeliveryQuotaHasTwoQuotasId3And4() {
        // @Given a DeliveryQuotaFy with one quota 1
        DeliveryQuotaFY deliveryQuotaFY = new DeliveryQuotaFY();
        QuotaFY quotaFY1 = new QuotaFY();
        quotaFY1.setId(3l);
        deliveryQuotaFY.addQuota(quotaFY1);
        QuotaFY quotaFY2 = new QuotaFY();
        quotaFY2.setId(4l);
        deliveryQuotaFY.addQuota(quotaFY2);

        // @When getting the quota ids
        List<Long> quotaFYIds = deliveryQuotaFY.getQuotaFYIds();

        // @Then id 1 is returned
        assertThat(quotaFYIds).containsOnly(3l, 4l);
    }

    @Test
    public void testGetQuotaFyIdsReturns5And6_WhenDeliveryQuotaHasTwoQuotasId5And6() {
        // @Given a DeliveryQuotaFy with one quota 1
        DeliveryQuotaFY deliveryQuotaFY = new DeliveryQuotaFY();
        QuotaFY quotaFY1 = new QuotaFY();
        quotaFY1.setId(5l);
        deliveryQuotaFY.addQuota(quotaFY1);
        QuotaFY quotaFY2 = new QuotaFY();
        quotaFY2.setId(6l);
        deliveryQuotaFY.addQuota(quotaFY2);

        // @When getting the quota ids
        List<Long> quotaFYIds = deliveryQuotaFY.getQuotaFYIds();

        // @Then id 1 is returned
        assertThat(quotaFYIds).containsOnly(5l, 6l);
    }

    @Test
    public void testConstructorSetsGrowerAsInputQuotaFyGrower_WhenCreatingADeliveryQuotaFromAQuotaFy() {
        // @Given a quota with a grower
        QuotaFY quotaFY = new QuotaFY();
        Warehouse warehouse = new Warehouse();
        quotaFY.setWarehouse(warehouse);
        quotaFY.setGrower(new Grower());

        // @When creating a delivery quota from that quota
        DeliveryQuotaFY deliveryQuotaFY = new DeliveryQuotaFY(quotaFY);

        // @Then the delivery quota grower is the same as the quota's
        assertThat(deliveryQuotaFY.getGrower()).isSameAs(quotaFY.getGrower());
    }

    @Test
    public void testConstructorSetsGermoSupplierDescriptionAsJohn_WhenCreatingADeliveryQuotaFromAQuotaFyWithGermoSupplierNameJohn() {
        // @Given a quota with a grower
        QuotaFY quotaFY = new QuotaFY();
        Warehouse warehouse = new Warehouse();
        warehouse.setDescription("John");

        quotaFY.setGrower(new Grower());
        quotaFY.setWarehouse(warehouse);
        // @When creating a delivery quota from that quota
        DeliveryQuotaFY deliveryQuotaFY = new DeliveryQuotaFY(quotaFY);

        // @Then the delivery quota grower is the same as the quota's
        assertThat(deliveryQuotaFY.getWareHouseDescription()).isEqualTo("John");
    }

    @Test
    public void testConstructorSetsGermoSupplierDescriptionAsAdam_WhenCreatingADeliveryQuotaFromAQuotaFyWithGermoSupplierNameAdam() {
        // @Given a quota with a grower
        QuotaFY quotaFY = new QuotaFY();

        Warehouse warehouse = new Warehouse();
        warehouse.setDescription("Adam");
        quotaFY.setWarehouse(warehouse);
        quotaFY.setGrower(new Grower());

        // @When creating a delivery quota from that quota
        DeliveryQuotaFY deliveryQuotaFY = new DeliveryQuotaFY(quotaFY);

        // @Then the delivery quota grower is the same as the quota's
        assertThat(deliveryQuotaFY.getWareHouseDescription()).isEqualTo("Adam");
    }
}
