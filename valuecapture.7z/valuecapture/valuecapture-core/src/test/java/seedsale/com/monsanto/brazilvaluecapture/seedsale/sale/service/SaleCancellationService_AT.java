package com.monsanto.brazilvaluecapture.seedsale.sale.service;

import com.monsanto.brazilvaluecapture.core.base.SystemTestFixture;
import com.monsanto.brazilvaluecapture.core.foundation.service.BusinessException;
import com.monsanto.brazilvaluecapture.core.foundation.test.AbstractServiceIntegrationTests;
import com.monsanto.brazilvaluecapture.core.importfile.model.ImportFileType;
import com.monsanto.brazilvaluecapture.core.importfile.model.bean.CsvImportFile;
import com.monsanto.brazilvaluecapture.core.user.AccessControlTestFixture;
import com.monsanto.brazilvaluecapture.seedsale.sale.SaleTestFixture;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.Cancellation;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.Sale;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.Sale.SaleTypeEnum;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.SaleCancellationEntry;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.SaleCancellationResult;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class SaleCancellationService_AT extends AbstractServiceIntegrationTests {

    @Autowired
    private SaleService saleService;
    @Autowired
    private SaleCancellationService saleCancellationService;

    private AccessControlTestFixture accessControlIntent;
    private SaleItemFactory saleItemFactory;

    private SaleTestData saleFactory;

    @Before
    public void init() throws BusinessException {
        systemTestFixture = new SystemTestFixture(this);
        accessControlTestFixture = new AccessControlTestFixture(systemTestFixture);
        accessControlIntent = new AccessControlTestFixture(this, systemTestFixture);
        saleTestFixture = new SaleTestFixture(this, systemTestFixture);
        saleItemFactory = SaleItemFactory.getInstance(systemTestFixture.matoGrossoDoSul, saleTestFixture.plantabilitiesSelector);

        accessControlIntent.userAdminOfMonsantoBr.setContextCompany(systemTestFixture.monsantoBr);
        accessControlIntent.userAdminOfMonsantoBr.setContextCrop(systemTestFixture.soy);

        saleFactory = new SaleTestData(systemTestFixture.regionSaoPaulo2012);
    }

    private Sale createSaleWithOneFixItemAndOneNoValueItem() throws BusinessException {
        Sale sale = saleFactory.createSale(saleTestFixture.matrixCargil, saleTestFixture.chicoBento, SaleTypeEnum.SALE_SEED);
        sale.setState(systemTestFixture.matoGrossoDoSul);

        sale.addItem(saleItemFactory.createFixValueItem(saleTestFixture.productIntactaSoy, saleTestFixture.templateIntactaFixRRRangeBtNoValue, saleTestFixture.headOfficeCargil, 5l));
        //sale.addItem(saleItemFactory.createNoValueItem(saleTestFixture.productBtSoy, saleTestFixture.templateIntactaFixRRRangeBtNoValue, saleTestFixture.headOfficeCargil, 5l));
        return sale;
    }

    @Test
    public void given_one_valid_sale_and_request_cancellation_should_produce_one_cancellation_entry() throws IOException, BusinessException {
        Sale sale = createSaleWithOneFixItemAndOneNoValueItem();
        saleService.save(sale, accessControlIntent.userAdminOfMonsantoBr);

        List<Sale> sales = new ArrayList<Sale>();
        sales.add(sale);

        Cancellation cancellation = new Cancellation();
        cancellation.setCode("NO_VISIBLE_CANCELLATION_TEST");
        cancellation.setDescription("no visible cancellation");
        cancellation.setIsVisible(false);
        saveAndFlush(cancellation);

        CsvImportFile csvImportFile = saleCancellationService.saveRequestCancellation("TEST", "JOHN", ImportFileType.SALE_CANCELLATION, sales, cancellation);
        Assert.assertNotNull("CsvImportFile should have an id.", csvImportFile.getPrimaryKey());

        List<SaleCancellationEntry> entries = saleCancellationService.getSaleCancellationEntryByCsvImportFile(csvImportFile);
        Assert.assertEquals("Should be 1", 1, entries.size());
        Assert.assertNotNull("SaleCancellationEntry should have an id.", entries.get(0).getPrimaryKey());
    }


    @Test
    public void given_sale_cancellation_when_one_entry_sale_is_canceled_should_produce_one_cancellation_result() throws IOException, BusinessException {
        Sale sale = createSaleWithOneFixItemAndOneNoValueItem();
        saleService.save(sale, accessControlIntent.userAdminOfMonsantoBr);

        List<Sale> sales = new ArrayList<Sale>();
        sales.add(sale);

        Cancellation cancellation = new Cancellation();
        cancellation.setCode("NO_VISIBLE_CANCELLATION_TEST");
        cancellation.setDescription("no visible cancellation");
        cancellation.setIsVisible(false);
        saveAndFlush(cancellation);

        CsvImportFile csvImportFile = saleCancellationService.saveRequestCancellation("TEST", "JOHN", ImportFileType.SALE_CANCELLATION, sales, cancellation);
        Assert.assertNotNull("CsvImportFile should have an id.", csvImportFile.getPrimaryKey());

        List<SaleCancellationResult> saleCancellationResults = new ArrayList<SaleCancellationResult>();
        saleCancellationResults.add(new SaleCancellationResult("ERROR_MSG", csvImportFile, 1));
        saleCancellationService.saveCancellationResults(saleCancellationResults);

        List<SaleCancellationResult> results = saleCancellationService.selectSaleCancellationResults(csvImportFile);
        Assert.assertEquals("Should be 1", 1, results.size());
        Assert.assertNotNull("SaleCancellationResult should have an id.", results.get(0).getPrimaryKey());

    }
}
