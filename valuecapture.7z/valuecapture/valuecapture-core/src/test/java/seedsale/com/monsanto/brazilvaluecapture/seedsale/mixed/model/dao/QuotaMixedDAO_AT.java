package com.monsanto.brazilvaluecapture.seedsale.mixed.model.dao;

import com.monsanto.brazilvaluecapture.core.base.model.bean.Company;
import com.monsanto.brazilvaluecapture.core.base.model.dao.CompanyDAO;
import com.monsanto.brazilvaluecapture.core.base.model.dao.TechnologyDAO;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Technology;
import com.monsanto.brazilvaluecapture.core.foundation.service.EntityNotFoundException;
import com.monsanto.brazilvaluecapture.core.foundation.test.AbstractServiceIntegrationTests;
import com.monsanto.brazilvaluecapture.core.foundation.test.dbunit.DbUnitHelper;
import com.monsanto.brazilvaluecapture.core.grower.model.bean.Grower;
import com.monsanto.brazilvaluecapture.core.grower.model.dao.GrowerDAO;
import com.monsanto.brazilvaluecapture.seedsale.harvest.model.bean.Harvest;
import com.monsanto.brazilvaluecapture.seedsale.harvest.model.dao.HarvestDAO;
import com.monsanto.brazilvaluecapture.seedsale.mixed.model.bean.QuotaMixed;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

public class QuotaMixedDAO_AT extends AbstractServiceIntegrationTests {

    @Autowired
	private QuotaMixedDAO quotaMixedDAO;
    @Autowired
    private GrowerDAO growerDAO;
    @Autowired
    private HarvestDAO harvestDAO;
    @Autowired
    private TechnologyDAO technologyDAO;
    @Autowired
    private CompanyDAO companyDAO;

    private Grower growerWithExistingQuota;
    private Grower growerWithNoQuota;
    private Harvest harvest;
    private Company company;
    private Technology technology;

    private static final Long QUOTA_EXISTING_ID = 900000001L;
    private static final Long QUOTA_NEW_BALANCE = 500L;

    @Before
	public void setUp() throws EntityNotFoundException {
        DbUnitHelper.setup("classpath:data/seedsale/mixed/mixed-quota-dataset.xml");
        growerWithExistingQuota = growerDAO.selectBy(900000001L);
        growerWithNoQuota = growerDAO.selectBy(900000002L);
        harvest = harvestDAO.selectById(900000001L);
        company = companyDAO.selectById(900000001L);
        technology = technologyDAO.findTechnologyByCandidateKey("INTACTA", company);
    }

    @Test
	public void testInsert() {
        QuotaMixed quotaToInsert = new QuotaMixed(growerWithNoQuota, harvest, technology, 50L);
        quotaMixedDAO.createOrUpdate(quotaToInsert);
        Assert.assertNotNull(quotaToInsert.getId());
    }

    @Test
	public void testUpdate() {
        QuotaMixed quotaToUpdate = quotaMixedDAO.findById(QUOTA_EXISTING_ID);
        Assert.assertNotNull(quotaToUpdate);
        quotaToUpdate.setBalance(QUOTA_NEW_BALANCE);
        quotaMixedDAO.createOrUpdate(quotaToUpdate);
        QuotaMixed quotaUpdated = quotaMixedDAO.findById(QUOTA_EXISTING_ID);
        Assert.assertNotNull(quotaToUpdate);
        Assert.assertEquals(quotaUpdated.getBalance(), QUOTA_NEW_BALANCE);
    }

    @Test
	public void testDelete() {
        QuotaMixed quotaToDelete = quotaMixedDAO.findById(QUOTA_EXISTING_ID);
        Assert.assertNotNull(quotaToDelete);
        quotaMixedDAO.delete(quotaToDelete);
        QuotaMixed quotaDeleted = quotaMixedDAO.findById(QUOTA_EXISTING_ID);
        Assert.assertNull(quotaDeleted);
    }

    @Test
	public void testFindAll() {
        List<QuotaMixed> allQuotas = quotaMixedDAO.findAll();
        Assert.assertNotNull(allQuotas);
        Assert.assertEquals(allQuotas.size(), 1);
    }

    @Test
    public void testFindByGrowerHarvestAndTechnology() {
        QuotaMixed quotaMixedFound = quotaMixedDAO.findBy(growerWithExistingQuota, harvest, technology);
        Assert.assertNotNull(quotaMixedFound);
        Assert.assertEquals(quotaMixedFound.getId(), QUOTA_EXISTING_ID);
    }

}