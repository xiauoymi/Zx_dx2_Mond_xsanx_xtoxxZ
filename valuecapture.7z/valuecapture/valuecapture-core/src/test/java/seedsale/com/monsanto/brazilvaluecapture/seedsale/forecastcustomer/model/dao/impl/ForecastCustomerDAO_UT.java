package com.monsanto.brazilvaluecapture.seedsale.forecastcustomer.model.dao.impl;

import static org.mockito.Matchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.monsanto.brazilvaluecapture.core.serviceFee.model.bean.ServiceFeeProgram;
import org.hibernate.Criteria;
import org.hibernate.SessionFactory;
import org.hibernate.classic.Session;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Projection;
import org.junit.Before;
import org.junit.Test;

import com.monsanto.brazilvaluecapture.seedsale.forecastcustomer.model.bean.ForecastCustomer;
import com.monsanto.brazilvaluecapture.seedsale.forecastcustomer.model.dao.ForecastCustomerDAO;
import com.monsanto.brazilvaluecapture.seedsale.product.model.bean.Product;

public class ForecastCustomerDAO_UT {

	private Criteria criteria;
	private Session session;
	private ForecastCustomerDAO forecastCustomerDAO;

	@Before
	public void setUp() {
		SessionFactory sessionFactory = mock(SessionFactory.class);
		this.session = mock(Session.class);
		when(sessionFactory.getCurrentSession()).thenReturn(this.session);
		this.forecastCustomerDAO = new ForecastCustomerDAOImpl(sessionFactory);
		this.criteria = mock(Criteria.class);
		when(this.session.createCriteria(ForecastCustomer.class)).thenReturn(this.criteria);
		when(this.criteria.add(any(Criterion.class))).thenReturn(this.criteria);
	}
	
	@Test
	public void testGetLastForecastCustomer(){
		this.forecastCustomerDAO.getLastForecastCustomer(new ServiceFeeProgram());
		 verify(this.session, times(1)).createCriteria(ForecastCustomer.class);
		 verify(this.criteria, times(1)).list();
	}
	
	@Test
	public void tesSave() {
		ForecastCustomer forecastCustomer = new ForecastCustomer();
		this.forecastCustomerDAO.save(forecastCustomer);
		verify(this.session, times(1)).saveOrUpdate(forecastCustomer);
	}
	
	@Test
	public void testGetCurrentForecastNum() {
		when(this.session.createCriteria(ForecastCustomer.class).setProjection(any(Projection.class))).thenReturn(this.criteria);
		this.forecastCustomerDAO.getCurrentForecastNum();
		verify(this.criteria, times(1)).uniqueResult();
	}
	
	@Test
	public void testGetForecastCustomerbyServiceFeeProgram() {
		when(this.session.createCriteria(ForecastCustomer.class).add(any(Criterion.class))).thenReturn(this.criteria);
		when(this.session.createCriteria(ForecastCustomer.class).add(any(Criterion.class)).add(any(Criterion.class))).thenReturn(this.criteria);
		this.forecastCustomerDAO.getForecastCustomerByServiceFeeProgram(new ServiceFeeProgram());
		verify(this.criteria, times(1)).list();
	}
}
