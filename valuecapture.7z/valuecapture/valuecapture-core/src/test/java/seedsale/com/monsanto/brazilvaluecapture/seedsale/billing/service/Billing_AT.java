package com.monsanto.brazilvaluecapture.seedsale.billing.service;

import static org.mockito.Mockito.stub;

import java.math.BigDecimal;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Set;

import com.monsanto.CountriesHolderInitializer;
import com.monsanto.brazilvaluecapture.core.regionalization.CountriesHolder;
import org.apache.commons.lang3.time.DateUtils;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.monsanto.brazilvaluecapture.core.base.SystemTestFixture;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Company;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Technology;
import com.monsanto.brazilvaluecapture.core.foundation.service.BusinessException;
import com.monsanto.brazilvaluecapture.core.foundation.service.EntityNotFoundException;
import com.monsanto.brazilvaluecapture.core.foundation.test.AbstractServiceIntegrationTests;
import com.monsanto.brazilvaluecapture.core.foundation.test.dbunit.DbUnitHelper;
import com.monsanto.brazilvaluecapture.core.user.AccessControlTestFixture;
import com.monsanto.brazilvaluecapture.core.user.model.bean.ItsUser;
import com.monsanto.brazilvaluecapture.core.user.model.bean.ItsUser.UserTypeEnum;
import com.monsanto.brazilvaluecapture.core.user.model.bean.UserDecorator;
import com.monsanto.brazilvaluecapture.seedsale.billing.model.bean.Billing;
import com.monsanto.brazilvaluecapture.seedsale.billing.model.bean.PaymentStatus;
import com.monsanto.brazilvaluecapture.seedsale.billing.model.dao.BillingDAO;
import com.monsanto.brazilvaluecapture.seedsale.billing.model.dao.BillingFilter;
import com.monsanto.brazilvaluecapture.seedsale.billing.service.impl.BillingFactory;
import com.monsanto.brazilvaluecapture.seedsale.billing.service.impl.BillingIndexer;
import com.monsanto.brazilvaluecapture.seedsale.harvest.model.bean.Harvest;
import com.monsanto.brazilvaluecapture.seedsale.sale.SaleTestFixture;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.Cancellation;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.Sale;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.SaleItem;
import com.monsanto.brazilvaluecapture.seedsale.sale.service.BillingCancellationWarningException;
import com.monsanto.brazilvaluecapture.seedsale.sale.service.SaleService;
import com.monsanto.brazilvaluecapture.seedsale.template.model.bean.SaleTemplate;
import com.monsanto.brazilvaluecapture.seedsale.template.model.bean.SaleTemplateBillingMethodEnum;

public class Billing_AT extends AbstractServiceIntegrationTests {

    private static final long BILLING_TRANSACTION_NUMBER = 12345L;

    @Autowired
    private SaleService saleService;

    @Autowired
    private BillingDAO billingDAO;

    @Autowired
    private CountriesHolder countriesHolder;

    private static BillingIndexer mockedBillingIndexer;

    public UserDecorator userAdmin;
    public UserDecorator participantUser;
    public ItsUser itsParticipantUser;
    public ItsUser itsUserAdmin;

    @BeforeClass
    public static void onlyOnce() throws BusinessException {
        mockedBillingIndexer = BillingHelper.createBillingIndexer();
        stub(mockedBillingIndexer.getSaleCode()).toReturn(BillingHelper.MOCKED_SALE_CODE);
        stub(mockedBillingIndexer.getBillingMethod()).toReturn(SaleTemplateBillingMethodEnum.ERP);
    }

    @Before
    public void init() {
        CountriesHolderInitializer.initialize(countriesHolder);
        getSession().clear();
        systemTestFixture = new SystemTestFixture(this);
        saleTestFixture = new SaleTestFixture(this, systemTestFixture);

        itsParticipantUser = createUser("loginParticipant", UserTypeEnum.PARTICIPANT, "123456789", "rferreira@cit.com");
        participantUser = new UserDecorator(null, itsParticipantUser);
        itsUserAdmin = createUser("loginAdmin", UserTypeEnum.ADMINISTRATOR, "123456789", "rferreira@cit.com");
        userAdmin = new UserDecorator(null, itsUserAdmin);

        createChargeConsolidateTypes();
    }

    @Test
    public void sanity_check() {
        Assert.assertNotNull("SaleService should not be null.", saleService);
    }

    @Test(expected = EntityNotFoundException.class)
    public void when_transactionNumber_not_found_your_relative_billing_then_getByTransactionId_shoud_throw_exception()
            throws EntityNotFoundException {
        billingDAO.getByTransactionId(BILLING_TRANSACTION_NUMBER);
    }

    @Test(expected = IllegalArgumentException.class)
    public void when_transactionNumber_parameter_is_null_then_getByTransactionId_should_throw_exception()
            throws EntityNotFoundException {
        billingDAO.getByTransactionId(null);
    }

    @Test
    public void given_a_transactionNumber_when_billing_exists_then_getByTransactionId_should_return_one_billing()
            throws EntityNotFoundException {
        Billing billing = createBillingWithOneItemWithDueDateInAugust();
        billing.setTransactionNumber(BILLING_TRANSACTION_NUMBER);
        saveAndFlush(billing);

        Long transactionId = billing.getTransactionNumber();
        Billing billingByTransactionNumber = billingDAO.getByTransactionId(transactionId);

        Assert.assertNotNull("Should have found a billing", billingByTransactionNumber);
        Assert.assertEquals("Should have one payment", 1, billingByTransactionNumber.countPayments());
    }

    @Test(expected = BillingConstraintViolationException.class)
    public void given_a_paid_billing_then_payBilling_throw_exception() throws BillingConstraintViolationException, BusinessException {
        Billing billing = createAndSaveBillingWithOneItemWithDueDateInAugust();
        try {
            saleService.payBilling(billing, SaleTestFixture.MAY, BillingHelper.PARCIAL_PAYMENT_VALUE_TO_RECEIVE, true);
        } catch (BusinessException e) {
            e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
        }
        saleService.payBilling(billing, SaleTestFixture.AUGUST, BillingHelper.TOTAL_ROYALTY_VALUE_TO_RECEIVE, false);
    }

    @Test(expected = BillingConstraintViolationException.class)
    public void given_a_cancelled_billing_then_payBilling_throw_exception() throws BillingConstraintViolationException,
            BillingCancellationWarningException, BusinessException {
        Billing billing = createAndSaveBillingWithOneItemWithDueDateInAugust();
        saleService.cancelBillingPartially(billing.getSaleCode(), systemTestFixture.monsantoBr,
                saleTestFixture.saleCancellation, "JOHN");

            saleService.payBilling(billing, SaleTestFixture.AUGUST, BillingHelper.TOTAL_ROYALTY_VALUE_TO_RECEIVE, false);
    }

    @Test
    public void given_a_billing_with_one_possiblePayment_when_date_of_pay_exceeds_receiptDate_then_payBilling_use_the_lastPossiblePayment()
            throws BillingConstraintViolationException {
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.MONTH, -1);
        Billing billing = createAndSaveBillingWithOneItemWithManyDueDates(cal.getTime());

        Assert.assertEquals("Billing should not be in paid status", PaymentStatus.NOT_PAID, billing.getPaymentStatus());

        Date nowDate = new Date();
        try {
            saleService.payBilling(billing, nowDate, BigDecimal.ONE, false);
        } catch (BusinessException e) {
            e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
        }
        BillingHelper.assertLastPayment(nowDate, BigDecimal.ONE, null, null, billing.getPayments());
    }

    @Test
    public void given_a_billing_with_one_possiblePayment_when_try_pay_by_cnab_file_and_date_of_pay_exceeds_receiptDate_then_payBilling_use_the_lastPossiblePayment()
            throws BillingConstraintViolationException {
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.MONTH, -1);
        Billing billing = createAndSaveBillingWithOneItemWithManyDueDates(cal.getTime());

        Assert.assertEquals("Billing should not be in paid status", PaymentStatus.NOT_PAID, billing.getPaymentStatus());

        Date nowDate = new Date();
        BigDecimal tariffValue = new BigDecimal("0.5");
        BigDecimal launchValue = new BigDecimal("0.5");
        saleService.payBillingOfBillet(billing, nowDate, BigDecimal.ONE, tariffValue, launchValue);

        BillingHelper.assertLastPayment(nowDate, BigDecimal.ONE, tariffValue, launchValue, billing.getPayments());
    }

    @Test(expected = BillingConstraintViolationException.class)
    public void given_a_billing_with_one_possiblePayment_when_try_pay_by_cnab_file_with_tariff_value_null_then_throw_exception()
            throws BillingConstraintViolationException {
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.MONTH, -1);
        Billing billing = createAndSaveBillingWithOneItemWithManyDueDates(cal.getTime());

        Assert.assertEquals("Billing should not be in paid status", PaymentStatus.NOT_PAID, billing.getPaymentStatus());

        Date nowDate = new Date();
        BigDecimal launchValue = new BigDecimal("0.5");
        saleService.payBillingOfBillet(billing, nowDate, BigDecimal.ONE, null, launchValue);

        Assert.fail();
    }

    @Test(expected = BillingConstraintViolationException.class)
    public void given_a_billing_with_one_possiblePayment_when_try_pay_by_cnab_file_with_launch_value_null_then_throw_exception()
            throws BillingConstraintViolationException {
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.MONTH, -1);
        Billing billing = createAndSaveBillingWithOneItemWithManyDueDates(cal.getTime());

        Assert.assertEquals("Billing should not be in paid status", PaymentStatus.NOT_PAID, billing.getPaymentStatus());

        Date nowDate = new Date();
        BigDecimal tariffValue = new BigDecimal("0.5");
        saleService.payBillingOfBillet(billing, nowDate, BigDecimal.ONE, tariffValue, null);

        Assert.fail();
    }

    @Test(expected = BillingConstraintViolationException.class)
    public void given_a_billing_with_one_possiblePayment_when_try_pay_by_cnab_file_with_launch_value_and_tariff_value_greater_than_two_decimal_then_throw_exception()
            throws BillingConstraintViolationException {
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.MONTH, -1);
        Billing billing = createAndSaveBillingWithOneItemWithManyDueDates(cal.getTime());

        Assert.assertEquals("Billing should not be in paid status", PaymentStatus.NOT_PAID, billing.getPaymentStatus());

        Date nowDate = new Date();
        BigDecimal tariffValue = new BigDecimal("0.500");
        BigDecimal launchValue = new BigDecimal("0.500");
        saleService.payBillingOfBillet(billing, nowDate, BigDecimal.ONE, tariffValue, launchValue);

        Assert.fail();
    }

    @Test(expected = BillingConstraintViolationException.class)
    public void given_a_billing_with_one_possiblePayment_when_try_pay_by_cnab_file_with_launch_value_and_tariff_value_equals_zero_then_throw_exception()
            throws BillingConstraintViolationException {
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.MONTH, -1);
        Billing billing = createAndSaveBillingWithOneItemWithManyDueDates(cal.getTime());

        Assert.assertEquals("Billing should not be in paid status", PaymentStatus.NOT_PAID, billing.getPaymentStatus());

        Date nowDate = new Date();
        saleService.payBillingOfBillet(billing, nowDate, BigDecimal.ONE, BigDecimal.ZERO, BigDecimal.ZERO);

        Assert.fail();
    }

    @Test
    public void given_a_billing_with_one_possiblePayment_when_date_of_pay_precedes_receiptDate_and_payValue_is_complete_then_payBilling_save_billingStatus_in_fully_paid()
            throws BillingConstraintViolationException {
        Billing billing = createAndSaveBillingWithOneItemWithDueDateInAugust();
        Assert.assertEquals("Billing should not be in paid status", PaymentStatus.NOT_PAID, billing.getPaymentStatus());

        boolean manuallyPaid = true;
        Date paymentDate = SaleTestFixture.JANUARY;

        try {
            saleService.payBilling(billing, paymentDate, BillingHelper.TOTAL_ROYALTY_VALUE_TO_RECEIVE, manuallyPaid);
        } catch (BusinessException e) {
            e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
        }

        assertBilling(PaymentStatus.FULLY_PAID, manuallyPaid, paymentDate);
    }

    @Test
    public void given_a_billing_with_one_possiblePayment_when_date_of_pay_precedes_receiptDate_and_payValue_is_parcial_then_payBilling_save_billingStatus_in_parcial_paid()
            throws BillingConstraintViolationException {
        Billing billing = createAndSaveBillingWithOneItemWithDueDateInAugust();
        Assert.assertEquals("Billing should not be in paid status", PaymentStatus.NOT_PAID, billing.getPaymentStatus());

        boolean manuallyPaid = false;
        Date paymentDate = SaleTestFixture.FEBRUARY;

        try {
            saleService.payBilling(billing, paymentDate, BillingHelper.PARCIAL_PAYMENT_VALUE_TO_RECEIVE, manuallyPaid);
        } catch (BusinessException e) {
            e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
        }

        assertBilling(PaymentStatus.PARCIAL_PAID, manuallyPaid, paymentDate);
    }

    @Test
    public void when_i_payBilling_paymentDate_shouldBe_the_inputed_payDate() throws BillingConstraintViolationException {
        Billing billing = createAndSaveBillingWithOneItemWithDueDateInAugust();

        boolean manuallyPaid = true;
        Date paymentDate = SaleTestFixture.FEBRUARY;

        try {
            saleService.payBilling(billing, paymentDate, BillingHelper.TOTAL_ROYALTY_VALUE_TO_RECEIVE, manuallyPaid);
        } catch (BusinessException e) {
            e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
        }
        assertBilling(PaymentStatus.FULLY_PAID, manuallyPaid, paymentDate);
    }

    @Test(expected = BillingConstraintViolationException.class)
    public void given_a_billing_with_one_possiblePayment_when_payValue_and_payDate_is_null_then_payBilling_should_throw_exception()
            throws BillingConstraintViolationException, BusinessException {
        Billing billing = createAndSaveBillingWithOneItemWithDueDateInAugust();
        Assert.assertEquals("Billing should not be in paid status", PaymentStatus.NOT_PAID, billing.getPaymentStatus());

        saleService.payBilling(billing, null, null, false);
        
        Assert.fail("Should be throw an exception");
    }

    @Test(expected = BillingConstraintViolationException.class)
    public void given_a_billing_with_paymentDate_in_future_should_throw_exception()
            throws BillingConstraintViolationException, BusinessException {
        Billing billing = createAndSaveBillingWithOneItemWithDueDateInAugust();

        Calendar tomorrow = Calendar.getInstance();
        tomorrow.add(Calendar.DAY_OF_MONTH, 1);

        saleService.payBilling(billing, tomorrow.getTime(), BillingHelper.PARCIAL_PAYMENT_VALUE_TO_RECEIVE, false);
        
        Assert.fail("Should be throw an exception");
    }

    @Test
    public void when_i_register_a_billing_shouldBeReturned_a_BillingWithId() throws BusinessException {
        Billing billing = createBillingWithOneItemWithDueDateInAugust();

        billingDAO.save(billing);

        Assert.assertNotNull("Billing id should not be null", billing.getId());
    }

    @Test
    public void given_a_sale_when_an_participantUser_search_billings_shouldReturn_one_billing()
            throws BusinessException {
        createAndSaveBillingWithOneItemWithDueDateInAugust();
        AccessControlTestFixture actf = new AccessControlTestFixture(this, systemTestFixture);

        BillingFilter billingFilter = BillingFilter.getInstance().add(actf.participantUser)
                .add(BillingHelper.MOCKED_SALE_CODE);
        List<Billing> billings = saleService.getBillingBy(billingFilter);

        Assert.assertEquals("Must return one sale", 1, billings.size());
        Assert.assertEquals("Must return royalt list", 1, billings.get(0).countRoyalties());
        Assert.assertEquals("Must return payment list", 1, billings.get(0).countPayments());
    }

    @Test
    public void admin_of_monsantoEua_should_not_see_billing_of_monsantoBr() throws BusinessException {
        createAndSaveBillingWithOneItemWithDueDateInAugust();
        AccessControlTestFixture actf = new AccessControlTestFixture(this, systemTestFixture);

        BillingFilter billingFilter = BillingFilter.getInstance().add(actf.userAdminOfMonsantoEua)
                .add(BillingHelper.MOCKED_SALE_CODE);
        List<Billing> billings = saleService.getBillingBy(billingFilter);

        Assert.assertEquals("Must return one billing", 0, billings.size());
    }

    @Test
    public void given_a_sale_and_company_search_billings_shouldReturn_one_billing() throws BusinessException {
        createAndSaveBillingWithOneItemWithDueDateInAugust();

        BillingFilter billingFilter = BillingFilter.getInstance().add(systemTestFixture.monsantoBr)
                .add(BillingHelper.MOCKED_SALE_CODE);
        List<Billing> billings = saleService.getBillingBy(billingFilter);

        Assert.assertEquals("Must return one billing", 1, billings.size());
        Assert.assertEquals("Must return royalt list", 1, billings.get(0).countRoyalties());
        Assert.assertEquals("Must return company", systemTestFixture.monsantoBr, billings.get(0).getRoyalties()
                .iterator().next().getTechnology().getCompany());
    }

    @Test
    public void given_a_billing_with_two_paymentDates_search_billings_shouldReturn_only_one_billing() {
        createAndSaveBillingWithOneItemWithManyDueDates(SaleTestFixture.FEBRUARY, SaleTestFixture.AUGUST);

        BillingFilter billingFilter = BillingFilter.getInstance().add(BillingHelper.MOCKED_SALE_CODE);
        List<Billing> billings = saleService.getBillingBy(billingFilter);

        Assert.assertEquals("Search should return only one billing", 1, billings.size());
        Assert.assertEquals("This billing should have 2 possible payments", 2, billings.get(0).countPayments());
    }

    @Test
    public void given_two_billings_for_same_sale_search_billings_shouldReturn_two_billings() {
        createAndSaveBillingWithTwoItemFromSameCompanyAndDueDateAugust();

        BillingFilter billingFilter = BillingFilter.getInstance().add(BillingHelper.MOCKED_SALE_CODE)
                .add(SaleTemplateBillingMethodEnum.BANKSLIP);
        List<Billing> billingsResult = (List<Billing>) saleService.getBillingBy(billingFilter);

        Assert.assertEquals(2, billingsResult.size());
    }

    @Test
    public void given_saleCode_without_billings_then_generateBillet_should_return_no_billets()
            throws NotPossibleGetTransctionBilletException {
        List<Billing> billets = saleService.generateBilletTransactionNumber(BillingHelper.MOCKED_SALE_CODE);

        Assert.assertEquals("Should have just no billets", 0, billets.size());
    }

    @Test(expected = NotPossibleGetTransctionBilletException.class)
    public void given_saleCode_null_then_generateBillet_should_return_exception() throws NotPossibleGetTransctionBilletException {
        Long saleCode = null;
        saleService.generateBilletTransactionNumber(saleCode);
    }

    @Test
    public void given_saleCode_with_one_billing_when_billingMethod_is_erp_then_generateBillet_should_return_no_billets()
            throws NotPossibleGetTransctionBilletException {
        createAndSaveBillingWithOneItemWithDueDateInAugust();

        List<Billing> billets = saleService.generateBilletTransactionNumber(BillingHelper.MOCKED_SALE_CODE);

        Assert.assertEquals("Should have just no billets", 0, billets.size());
    }

    @Test
    public void given_saleCode_with_one_billing_when_billingMethod_is_direct_then_generateBillet_should_return_no_billets()
            throws NotPossibleGetTransctionBilletException {
        createAndSaveBillingWithOneItemWithDueDateInAugust();

        List<Billing> billets = saleService.generateBilletTransactionNumber(BillingHelper.MOCKED_SALE_CODE);

        Assert.assertEquals("Should have just no billets", 0, billets.size());
    }

    @Test
    public void given_saleCode_with_one_billing_when_billingMethod_is_bankslip_then_generateBillet_should_return_one_billet()
            throws NotPossibleGetTransctionBilletException {
        stub(mockedBillingIndexer.getBillingMethod()).toReturn(SaleTemplateBillingMethodEnum.BANKSLIP);
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(SaleTestFixture.DATE_NOW);
        stub(mockedBillingIndexer.getDueDate()).toReturn(calendar.getTime());
        Billing billing = createBillingWithOneItemWithDueDateInAugust();
        saveAndFlush(billing);
        Assert.assertNull("Billing should have a transaction number", billing.getTransactionNumber());
        List<Billing> billets = saleService.generateBilletTransactionNumber(BillingHelper.MOCKED_SALE_CODE);

        Assert.assertEquals("Should have one billet", 1, billets.size());
        assertBillet(billets.iterator().next());
    }

    @Test
    public void given_sale_when_verify_if_billing_has_billet_should_return_invalid() {
        stub(mockedBillingIndexer.getBillingMethod()).toReturn(SaleTemplateBillingMethodEnum.BANKSLIP);
        stub(mockedBillingIndexer.getDueDate()).toReturn(SaleTestFixture.APRIL);
        Billing billing = BillingHelper.createBillingWithOneItemForManyDueDates(systemTestFixture, saleTestFixture,
                mockedBillingIndexer, SaleTestFixture.APRIL);
        saveAndFlush(billing);
        Boolean isValid = saleService.hasSomeBilletValid(BillingHelper.MOCKED_SALE_CODE);
        Assert.assertFalse(isValid);
    }

    @Test
    public void given_sale_when_verify_if_billing_has_billet_should_return_valid() {
        DbUnitHelper.setup("classpath:data/core/system-parameter-bankslip-enabled-dataset.xml");
        stub(mockedBillingIndexer.getBillingMethod()).toReturn(SaleTemplateBillingMethodEnum.BANKSLIP);
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(SaleTestFixture.DATE_NOW);
        calendar.add(Calendar.DAY_OF_MONTH, 1);
        stub(mockedBillingIndexer.getDueDate()).toReturn(calendar.getTime());
        Billing billing = BillingHelper.createBillingWithOneItemForManyDueDates(systemTestFixture, saleTestFixture,
                mockedBillingIndexer, SaleTestFixture.APRIL);
        saveAndFlush(billing);
        Boolean isValid = saleService.hasSomeBilletValid(BillingHelper.MOCKED_SALE_CODE);
        Assert.assertTrue(isValid);
    }

    private void assertBillet(Billing billet) {
        Assert.assertEquals("Billing method should be Bankslip", SaleTemplateBillingMethodEnum.BANKSLIP,
                billet.getBillingMethod());
        Assert.assertNotNull("Billing should have a transaction number", billet.getTransactionNumber());
    }

    private void assertBilling(PaymentStatus expectedBillingStatus, boolean expectedPayMode, Date paymentDate) {
        getSession().clear();
        BillingFilter filter = BillingFilter.getInstance().add(BillingHelper.MOCKED_SALE_CODE);
        List<Billing> billings = saleService.getBillingBy(filter);
        Assert.assertEquals("Should have 1 billing", 1, billings.size());
        Billing actual = billings.get(0);
        Assert.assertEquals("Billing should be paid now", expectedBillingStatus, actual.getPaymentStatus());
        Assert.assertEquals("Pay mode is wrong", expectedPayMode, actual.isManuallyPaid());
        Assert.assertNotNull("Should be paid", actual.getPossiblePaymentPaid());

        paymentDate = DateUtils.truncate(paymentDate, Calendar.DAY_OF_MONTH);
        Date actualPaymentDate = actual.getPossiblePaymentPaid().getPaymentDate();
        Assert.assertEquals("Incorrect payment date", paymentDate.getTime(), actualPaymentDate.getTime());
    }

    @Test
    public void when_i_cancel_a_notPaidBilling_should_changeStatus() throws BillingCancellationWarningException, BusinessException {
        Billing billingToCancel = createAndSaveBillingWithOneItemWithDueDateInAugust();
        billingToCancel.setPaymentStatus(PaymentStatus.NOT_PAID);

        Company company = billingToCancel.getRoyalties().iterator().next().getTechnology().getCompany();

        saleService.cancelBillingPartially(billingToCancel.getSaleCode(), company, saleTestFixture.saleCancellation,
                "JOHN");

        Assert.assertEquals("Status should be cancelled", PaymentStatus.CANCELLED, billingToCancel.getPaymentStatus());
    }

    @Test
    public void when_i_cancel_a_fullyPaidBilling_should_not_changeStatus() throws BillingCancellationWarningException, BusinessException {
        Billing billingToCancel = createAndSaveBillingWithOneItemWithDueDateInAugust();
        billingToCancel.setPaymentStatus(PaymentStatus.FULLY_PAID);

        Company company = billingToCancel.getRoyalties().iterator().next().getTechnology().getCompany();

        saleService.cancelBillingPartially(billingToCancel.getSaleCode(), company, saleTestFixture.saleCancellation,
                "JOHN");

        Assert.assertEquals("Status should be fully paid", PaymentStatus.FULLY_PAID, billingToCancel.getPaymentStatus());
    }

    @Test
    public void when_i_cancel_a_billing_per_item_should_cancel_all_billing_from_same_company_and_sale()
            throws BusinessException {
        Billing billingToCancel = createAndSaveBillingWithOneItemWithDueDateInAugust();

        createAndSaveBillingWithOneItemWithDueDateInAugust();

        BillingFilter billingFilter = new BillingFilter();
        billingFilter.add(BillingHelper.MOCKED_SALE_CODE).add(systemTestFixture.monsantoBr);

        List<Billing> billings = saleService.getBillingBy(billingFilter);

        for (Billing billing : billings) {
            Assert.assertFalse("Billings should not be cancelled",
                    PaymentStatus.CANCELLED.equals(billing.getPaymentStatus()));
        }

        saleService.cancelBillingPartially(billingToCancel.getSaleCode(), systemTestFixture.monsantoBr,
                saleTestFixture.saleCancellation, "JOHN");

        billings = saleService.getBillingBy(billingFilter);

        for (Billing billing : billings) {
            Assert.assertTrue("Billings should be status cancelled.",
                    PaymentStatus.CANCELLED.equals(billing.getPaymentStatus()));
        }
    }

    @Test
    public void when_i_cancel_a_billing_per_item_should_notCancel_billings_from_another_company()
            throws BusinessException {
        List<Billing> billingsMonsantoEua = createBillingWithTwoItemWithDueDateInAugust(
                systemTestFixture.intactaMons4nto, systemTestFixture.rr, saleTestFixture.harvestSoyMons4nto2012,
                saleTestFixture.harvest2011SoyMonsanto, saleTestFixture.templateIntactaMons4nto,
                saleTestFixture.templateIntactaFixRRRangeBtNoValue);
        for (Billing billing : billingsMonsantoEua) {
            billing.setSaleCode(BillingHelper.MOCKED_SALE_CODE);
            saveAndFlush(billing);
        }

        Billing billingToCancel = createAndSaveBillingWithOneItemWithDueDateInAugust();
        billingToCancel.setSaleCode(BillingHelper.MOCKED_SALE_CODE);
        saveAndFlush(billingToCancel);

        BillingFilter billingFilter = new BillingFilter();
        billingFilter.add(BillingHelper.MOCKED_SALE_CODE);

        List<Billing> billings = saleService.getBillingBy(billingFilter);

        for (Billing billing : billings) {
            Assert.assertFalse("Billings should not be cancelled",
                    PaymentStatus.CANCELLED.equals(billing.getPaymentStatus()));
        }

        saleService.cancelBillingPartially(billingToCancel.getSaleCode(), systemTestFixture.monsantoBr,
                saleTestFixture.saleCancellation, "JOHN");

        billingFilter.add(systemTestFixture.monsantoBr);

        List<Billing> billingsCancelled = saleService.getBillingBy(billingFilter);

        Assert.assertEquals("Must return one billing cancelled", 2, billingsCancelled.size());

        for (Billing billing : billingsCancelled) {
            Assert.assertTrue("Billings should be status cancelled.",
                    PaymentStatus.CANCELLED.equals(billing.getPaymentStatus()));
        }
    }

    @Test
    public void when_i_cancel_a_billing_shouldBeReturnedTheCancellationReasonWhenSearchAgain()
            throws BillingCancellationWarningException, BusinessException {
        Billing billingToCancel = createAndSaveBillingWithOneItemWithDueDateInAugust();
        billingToCancel.setPaymentStatus(PaymentStatus.NOT_PAID);

        Company company = billingToCancel.getRoyalties().iterator().next().getTechnology().getCompany();

        Cancellation cancellation = saleTestFixture.saleCancellation;

        saleService.cancelBillingPartially(billingToCancel.getSaleCode(), company, cancellation, "JOHN");

        BillingFilter billingFilter = new BillingFilter();
        billingFilter.add(billingToCancel.getSaleCode()).add(company);

        List<Billing> billings = saleService.getBillingBy(billingFilter);

        for (Billing billing : billings) {
            Assert.assertTrue("Should have the same cancellation reason used to save",
                    cancellation.equals(billing.getCancellation()));
        }
    }

    @Test(expected=BillingCancellationWarningException.class)
    public void when_i_cancel_a_billing_without_cancellation_should_be_returned_illegalArgumentException()
            throws BillingCancellationWarningException, BusinessException {
        Billing billingToCancel = createAndSaveBillingWithOneItemWithDueDateInAugust();
        billingToCancel.setPaymentStatus(PaymentStatus.NOT_PAID);

        Company company = billingToCancel.getRoyalties().iterator().next().getTechnology().getCompany();

        saleService.cancelBillingPartially(billingToCancel.getSaleCode(), company, null, "JOHN");

        Assert.fail("Should be throw an exception");
    }

    private Billing createBillingWithOneItemWithDueDateInAugust() {
        return BillingHelper.createBillingWithOneItemForManyDueDates(systemTestFixture, saleTestFixture,
                mockedBillingIndexer, SaleTestFixture.AUGUST);
    }

    private Billing createAndSaveBillingWithOneItemWithDueDateInAugust() {
        return createAndSaveBillingWithOneItemWithManyDueDates(SaleTestFixture.AUGUST);
    }

    private Billing createAndSaveBillingWithOneItemWithManyDueDates(Date... dueDates) {
        Billing billing = BillingHelper.createBillingWithOneItemForManyDueDates(systemTestFixture, saleTestFixture,
                mockedBillingIndexer, dueDates);
        getSession().saveOrUpdate(billing);
        getSession().flush();

        Assert.assertEquals("Incorrect number of possible payments", dueDates.length, billing.countPayments());

        return billing;
    }

    private List<Billing> createBillingWithTwoItemWithDueDateInAugust(Technology tech1, Technology tech2,
            Harvest harvest1, Harvest harvest2, SaleTemplate saleTemplate1, SaleTemplate saleTemplate2) {
        SaleItem saleItemMock = BillingHelper.createMockedSaleItem(systemTestFixture, saleTestFixture, tech1, harvest1,
                saleTemplate1);
        stub(saleItemMock.getTechnology()).toReturn(tech1);
        stub(saleItemMock.getCompany()).toReturn(tech1.getCompany());

        SaleItem saleItemMockDiferentTech = BillingHelper.createMockedSaleItem(systemTestFixture, saleTestFixture,
                tech2, harvest2, saleTemplate2);
        stub(saleItemMockDiferentTech.getCompany()).toReturn(tech2.getCompany());
        stub(saleItemMockDiferentTech.getTechnology()).toReturn(tech2);
        Set<SaleItem> items = BillingHelper.createSaleItemSet(saleItemMock, saleItemMockDiferentTech);

        Sale saleMock = BillingHelper.createMockedSale(items);

        BillingFactory billingFactory = new BillingFactory();
        List<Billing> billings = billingFactory.buildBilling(saleMock);

        return billings;
    }

    @Test
    public void when_i_cancel_a_billing_with_paid_item_from_same_company_and_sale_must_not_cancel_items()
            throws BusinessException {
        createAndSaveBillingWithTwoItemFromSameCompanyAndDueDateAugust();

        itsUserAdmin.addCompany(systemTestFixture.monsantoBr);

        Billing billingToCancelPaid = createAndSaveBillingWithOneItemWithDueDateInAugust();
        billingToCancelPaid.setPaymentStatus(PaymentStatus.FULLY_PAID);

        BillingFilter billingFilter = new BillingFilter();
        billingFilter.add(BillingHelper.MOCKED_SALE_CODE).add(systemTestFixture.monsantoBr);

        List<Billing> billings = saleService.getBillingBy(billingFilter);

        for (Billing billing : billings) {
            Assert.assertFalse("Billings should not be cancelled",
                    PaymentStatus.CANCELLED.equals(billing.getPaymentStatus()));
        }

        AccessControlTestFixture accessControlIntent;
        accessControlIntent = new AccessControlTestFixture(this, systemTestFixture);

        accessControlIntent.superUser.setContextCompany(systemTestFixture.monsantoBr);
        accessControlIntent.superUser.setContextCrop(systemTestFixture.soy);

        try {
            saleService
                    .cancelBillingCompletely(billingToCancelPaid.getSaleCode(),
                            accessControlIntent.superUser.getAllCompaniesForContext(),
                            saleTestFixture.saleCancellation, "JOHN");
            Assert.fail();
        } catch (BillingCancellationWarningException e) {
            billings = saleService.getBillingBy(billingFilter);
            for (Billing billing : billings) {
                Assert.assertFalse("Billings should not be status cancelled.",
                        PaymentStatus.CANCELLED.equals(billing.getPaymentStatus()));
            }
        }
    }

    private void createAndSaveBillingWithTwoItemFromSameCompanyAndDueDateAugust() {
        List<Billing> billingsMonsanto = createBillingWithTwoItemWithDueDateInAugust(systemTestFixture.intacta,
                systemTestFixture.rr, saleTestFixture.harvest2011SoyMonsanto, saleTestFixture.harvest2011SoyMonsanto,
                saleTestFixture.templateIntactaFixRRRangeBtNoValue, saleTestFixture.templateIntactaFixRRRangeBtNoValue);

        for (Billing billing : billingsMonsanto) {
            billing.setSaleCode(BillingHelper.MOCKED_SALE_CODE);
            saveAndFlush(billing);
        }
    }

    @Test
    public void when_i_cancel_a_billing_with_paid_item_from_other_company_and_sale_must_cancel_items_from_company_cancelled()
            throws BusinessException {
        List<Billing> billingsMonsanto = createBillingWithTwoItemWithDueDateInAugust(systemTestFixture.intactaMons4nto,
                systemTestFixture.rr, saleTestFixture.harvestSoyMons4nto2012, saleTestFixture.harvest2011SoyMonsanto,
                saleTestFixture.templateIntactaMons4nto, saleTestFixture.templateIntactaFixRRRangeBtNoValue);

        for (Billing billing : billingsMonsanto) {
            billing.setSaleCode(BillingHelper.MOCKED_SALE_CODE);
            saveAndFlush(billing);
        }

        Billing billingFullPaid = BillingHelper.createAnotherBillingWithOneItemForManyDueDates(systemTestFixture,
                saleTestFixture, mockedBillingIndexer, saleTestFixture.templateIntactaMons4nto, SaleTestFixture.AUGUST);
        billingFullPaid.setSaleCode(BillingHelper.MOCKED_SALE_CODE);
        billingFullPaid.setPaymentStatus(PaymentStatus.FULLY_PAID);
        saveAndFlush(billingFullPaid);

        BillingFilter billingFilter = new BillingFilter();

        List<Billing> billings = saleService.getBillingBy(billingFilter);

        for (Billing billing : billings) {
            Assert.assertFalse("Billings should not be cancelled",
                    PaymentStatus.CANCELLED.equals(billing.getPaymentStatus()));
        }

        AccessControlTestFixture accessControlIntent;
        accessControlIntent = new AccessControlTestFixture(this, systemTestFixture);

        accessControlIntent.superUser.addCompany(systemTestFixture.monsantoBr);
        accessControlIntent.superUser.addCompany(systemTestFixture.mons4ntoBr);
        accessControlIntent.superUser.setContextCrop(systemTestFixture.soy);

        try {
            saleService
                    .cancelBillingCompletely(billingFullPaid.getSaleCode(),
                            accessControlIntent.superUser.getAllCompaniesForContext(),
                            saleTestFixture.saleCancellation, "JOHN");
            Assert.fail();
        } catch (BillingCancellationWarningException e) {
            billingFilter.add(BillingHelper.MOCKED_SALE_CODE).add(systemTestFixture.monsantoBr);
            billings = saleService.getBillingBy(billingFilter);
            Assert.assertEquals("Must have 1 billing", 1, billings.size());
            for (Billing billing : billings) {
                Assert.assertTrue("Billings status should be cancelled.",
                        PaymentStatus.CANCELLED.equals(billing.getPaymentStatus()));
            }
            billingFilter = new BillingFilter();
            billingFilter.add(BillingHelper.MOCKED_SALE_CODE).add(systemTestFixture.mons4ntoBr);
            billings = saleService.getBillingBy(billingFilter);
            Assert.assertEquals("Must have 2 billing", 2, billings.size());
            for (Billing billing : billings) {
                Assert.assertFalse("Billings should not be status cancelled.",
                        PaymentStatus.CANCELLED.equals(billing.getPaymentStatus()));
            }

        }

    }

    @Test
    public void given_a_billing_with_one_pay_manual_shouldReturn_billing() throws BillingConstraintViolationException {
        Billing billing = createAndSaveBillingWithOneItemWithDueDateInAugust();
        Assert.assertEquals("Billing should not be in paid status", PaymentStatus.NOT_PAID, billing.getPaymentStatus());

        boolean manuallyPaid = true;
        Date paymentDate = SaleTestFixture.JANUARY;

        try {
            saleService.payBilling(billing, paymentDate, BillingHelper.TOTAL_ROYALTY_VALUE_TO_RECEIVE, manuallyPaid);
        } catch (BusinessException e) {
            e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
        }

        assertBilling(PaymentStatus.FULLY_PAID, manuallyPaid, paymentDate);

        BillingFilter billingFilter = BillingFilter.getInstance().addIsPaymentManual();
        List<Billing> billingsResult = (List<Billing>) saleService.getBillingBy(billingFilter);

        Assert.assertEquals(1, billingsResult.size());
    }

}
