package com.monsanto.brazilvaluecapture.seedsale.sale.validation;

import com.monsanto.brazilvaluecapture.core.foundation.validation.ValidatorChain;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.Sale;
import org.junit.Before;
import org.junit.Test;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;

public class SaleValidatorBVC_UT {

    private SaleValidatorBVC saleValidatorBVC;
    private ValidatorChain validatorChain;

    @Before
    public void setUp() {
        saleValidatorBVC = new SaleValidatorBVC() {

            @Override
            protected ValidatorChain<Sale> createValidatorChain() {
                validatorChain = mock(ValidatorChain.class);
                return validatorChain;
            }
        };
    }

    @Test
    public void testCreateRulesAddsCustomerDocumentValidationRule() {
        SaleRegionValidationRule saleRegionValidationRule = mock(SaleRegionValidationRule.class);
        SaleCityValidationRule saleCityValidationRule = mock(SaleCityValidationRule.class);
        SaleItemProductQuotaAvailableValidationRule saleItemProductQuotaAvailableValidationRule = mock(SaleItemProductQuotaAvailableValidationRule.class);
        SaleItemProductDuplicityValidationRule saleItemProductDuplicityValidationRule = mock(SaleItemProductDuplicityValidationRule.class);
        saleValidatorBVC.setSaleRegionValidationRule(saleRegionValidationRule);
        saleValidatorBVC.setSaleCityValidationRule(saleCityValidationRule);
        saleValidatorBVC.setSaleItemProductQuotaAvailableValidationRule(saleItemProductQuotaAvailableValidationRule);
        saleValidatorBVC.setSaleItemProductDuplicityValidationRule(saleItemProductDuplicityValidationRule);

        saleValidatorBVC.createRules();

        verify(validatorChain).addRule(saleRegionValidationRule);
        verify(validatorChain).addRule(saleCityValidationRule);
        verify(validatorChain).addRule(saleItemProductQuotaAvailableValidationRule);
        verify(validatorChain).addRule(saleItemProductDuplicityValidationRule);


    }
}