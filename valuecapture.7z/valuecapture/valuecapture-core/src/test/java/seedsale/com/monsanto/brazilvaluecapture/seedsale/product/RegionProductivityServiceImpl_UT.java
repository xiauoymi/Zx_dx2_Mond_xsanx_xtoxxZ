package com.monsanto.brazilvaluecapture.seedsale.product;

import com.monsanto.brazilvaluecapture.core.base.model.bean.Country;
import com.monsanto.brazilvaluecapture.core.base.model.bean.OperationalYear;
import com.monsanto.brazilvaluecapture.core.foundation.service.BusinessException;
import com.monsanto.brazilvaluecapture.core.foundation.service.EntityAlreadyExistException;
import com.monsanto.brazilvaluecapture.seedsale.product.model.bean.Region;
import com.monsanto.brazilvaluecapture.seedsale.product.model.dao.RegionProductivityDAO;
import com.monsanto.brazilvaluecapture.seedsale.product.service.impl.RegionProductivityServiceImpl;
import org.junit.Assert;
import org.junit.Test;
import org.mockito.Mockito;

import java.util.ArrayList;
import java.util.List;

import static org.mockito.Matchers.anyObject;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

/**
 * Created by IntelliJ IDEA.
 * User: MEFAZZ
 * Date: 9/9/13
 * Time: 4:32 PM
 * To change this template use File | Settings | File Templates.
 */
public class RegionProductivityServiceImpl_UT {

    @Test
	public void testSelectAllTest() throws BusinessException {

        List<Region> regionProductivities = RegionProductivityTestData.createSomeRegionProductivity();

        RegionProductivityDAO dao = mock(RegionProductivityDAO.class);

        RegionProductivityServiceImpl regionProductivityService = new RegionProductivityServiceImpl();

		when(dao.getAll()).thenReturn(regionProductivities);

		regionProductivityService.setRegionProductivityDAO(dao);

        Assert.assertNotNull(regionProductivityService.getRegionProductivityDAO());

		List<Region> regionProductivitiesBase = regionProductivityService.getAll();

		Assert.assertNotNull(regionProductivitiesBase);

	}

    @Test
	public void testSelectRegionProductivityByCountryOperationalYearTest () throws BusinessException {

        List<Region> regionProductivities = RegionProductivityTestData.createSomeRegionProductivity();

        RegionProductivityDAO dao = mock(RegionProductivityDAO.class);

        RegionProductivityServiceImpl regionProductivityService = new RegionProductivityServiceImpl();

		when(dao.getRegionProductivityByCountryOperationalYear((Country) anyObject(),(OperationalYear)anyObject() )).thenReturn(regionProductivities);

		regionProductivityService.setRegionProductivityDAO(dao);

        Assert.assertNotNull(regionProductivityService.getRegionProductivityDAO());

		List<Region> regionProductivitiesBase = regionProductivityService.getRegionProductivityByCountryOperationalYear((Country) anyObject(),(OperationalYear)anyObject());

		Assert.assertNotNull(regionProductivitiesBase);

	}

    @Test
    public void delete_region() throws BusinessException {

        //@Given
        RegionProductivityServiceImpl regionProductivityService = new RegionProductivityServiceImpl();
        RegionProductivityDAO regionProductivityDAO = mock(RegionProductivityDAO.class);
        regionProductivityService.setRegionProductivityDAO(regionProductivityDAO);
        Region region = Mockito.mock(Region.class);

        //@When
        regionProductivityService.delete(region);

        //@Should
        Mockito.verify(regionProductivityDAO).delete(region);
    }

    @Test
    public void delete_regions() throws BusinessException {

        //@Given
        RegionProductivityServiceImpl regionProductivityService = new RegionProductivityServiceImpl();
        RegionProductivityDAO regionProductivityDAO = mock(RegionProductivityDAO.class);
        regionProductivityService.setRegionProductivityDAO(regionProductivityDAO);
        Region region1 = Mockito.mock(Region.class);
        Region region2 = Mockito.mock(Region.class);

        List<Region> regions = new ArrayList<Region>();
        regions.add(region1);
        regions.add(region2);

        //@When
        regionProductivityService.delete(regions);

        //@Should
        Mockito.verify(regionProductivityDAO).delete(region1);
        Mockito.verify(regionProductivityDAO).delete(region2);
}

    @Test
    public void delete_no_regions() throws BusinessException {

        //@Given
        RegionProductivityServiceImpl regionProductivityService = new RegionProductivityServiceImpl();
        RegionProductivityDAO regionProductivityDAO = mock(RegionProductivityDAO.class);
        regionProductivityService.setRegionProductivityDAO(regionProductivityDAO);

        List<Region> regions = null;

        //@When
        regionProductivityService.delete(regions);

        //@Should
    }

    @Test
    public void create_region_with_description_ok() throws BusinessException {

        //@Given
        RegionProductivityServiceImpl regionProductivityService = new RegionProductivityServiceImpl();
        RegionProductivityDAO regionProductivityDAO = mock(RegionProductivityDAO.class);
        regionProductivityService.setRegionProductivityDAO(regionProductivityDAO);
        Long regionId = 3L;
        Region region = Mockito.mock(Region.class);
        when(region.getRegionDescription()).thenReturn("DUMMY");
        when(regionProductivityDAO.save(region)).thenReturn(regionId);

        //@When
        Long regionCreated = regionProductivityService.save(region);

        //@Should
        Mockito.verify(regionProductivityDAO).save(region);
        Assert.assertNotNull(regionCreated);
    }

    @Test
    public void create_region_without_description_fail() throws BusinessException {

        //@Given
        RegionProductivityServiceImpl regionProductivityService = new RegionProductivityServiceImpl();
        RegionProductivityDAO regionProductivityDAO = mock(RegionProductivityDAO.class);
        regionProductivityService.setRegionProductivityDAO(regionProductivityDAO);
        Long regionId = 3L;
        Region region = Mockito.mock(Region.class);
        when(region.getRegionDescription()).thenReturn(null);
        when(regionProductivityDAO.save(region)).thenReturn(regionId);

        //@When
        Long regionCreated = regionProductivityService.save(region);

        //@Should
        Assert.assertNull(regionCreated);
    }
}
