package com.monsanto.brazilvaluecapture.seedsale.sale.service.impl;

import com.google.common.collect.Sets;
import com.monsanto.brazilvaluecapture.core.base.model.bean.State;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Customer;
import com.monsanto.brazilvaluecapture.core.foundation.service.SystemParameterDuplicateException;
import com.monsanto.brazilvaluecapture.core.foundation.service.SystemParameterInvalidException;
import com.monsanto.brazilvaluecapture.core.foundation.service.SystemParameterNotFoundException;
import com.monsanto.brazilvaluecapture.core.foundation.util.security.EnvironmentSpecificPropertyReader;
import com.monsanto.brazilvaluecapture.core.foundation.util.security.EnvironmentSpecificPropertyReaderFactory;
import com.monsanto.brazilvaluecapture.core.grower.model.bean.Grower;
import com.monsanto.brazilvaluecapture.core.regionalization.CountriesHolder;
import com.monsanto.brazilvaluecapture.osb.its.lasorderregistration.bean.YlasConditionvc;
import com.monsanto.brazilvaluecapture.osb.its.lasorderregistration.bean.YlasCustparamvc;
import com.monsanto.brazilvaluecapture.osb.util.SecurityContextBadCredentialException;
import com.monsanto.brazilvaluecapture.osb.util.SecurityContextHolderFactory;
import com.monsanto.brazilvaluecapture.pod.rol.model.bean.GermoSupplier;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.Cancellation;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.PricingCondition;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.Sale;
import com.monsanto.brazilvaluecapture.seedsale.sale.promotion.SalePromotionComputer;
import com.monsanto.brazilvaluecapture.seedsale.sale.promotion.model.bean.SalePromotion;
import com.monsanto.brazilvaluecapture.seedsale.warehouse.model.bean.Warehouse;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;

import java.math.BigDecimal;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ExecutionException;

import static org.fest.assertions.Assertions.assertThat;
import static org.fest.reflect.core.Reflection.field;
import static org.mockito.Matchers.same;
import static org.mockito.Mockito.*;

/**
 * User: ppera
 * Date: 4/25/13
 * Time: 10:58 AM
 */
@RunWith(MockitoJUnitRunner.class)
public class LASVCOrderRegistrationAdapterImpl_UT {

    private SalePromotionComputer salePromotionComputer;
    private SecurityContextHolderFactory securityContextHolderFactory;
    private LASVCOrderRegistrationAdapterImpl lasVCOrderRegistrationAdapterImpl;
    private EnvironmentSpecificPropertyReaderFactory environmentSpecificPropertyReaderFactory;
    private EnvironmentSpecificPropertyReader environmentSpecificPropertyReader;

    @Before
    public void setUp() throws SecurityContextBadCredentialException {
        this.salePromotionComputer = mock(SalePromotionComputer.class);
        this.securityContextHolderFactory = mock(SecurityContextHolderFactory.class);
        this.environmentSpecificPropertyReaderFactory = mock(EnvironmentSpecificPropertyReaderFactory.class);
        this.environmentSpecificPropertyReader = mock(EnvironmentSpecificPropertyReader.class);
        when(this.environmentSpecificPropertyReaderFactory.getEnvironmentSpecificPropertyReader()).thenReturn(this.environmentSpecificPropertyReader);

        this.lasVCOrderRegistrationAdapterImpl = new LASVCOrderRegistrationAdapterImpl(this.securityContextHolderFactory, this.environmentSpecificPropertyReaderFactory);

        field("salePromotionComputer").ofType(SalePromotionComputer.class).in(this.lasVCOrderRegistrationAdapterImpl).set(this.salePromotionComputer);
    }

    @Test
    public void testGetPricingConditionsCallsSalePromotionComputerComputeWithInputSale_WhenObtainingThePricingConditionsForTheSale() throws SystemParameterNotFoundException, ExecutionException, SystemParameterDuplicateException, SystemParameterInvalidException {
        // @Given a sale
        Customer customer = new Customer();
        Grower grower = new Grower();
        Sale sale = new Sale(customer, grower);

        // @When getting the pricing conditions for the sale
        this.lasVCOrderRegistrationAdapterImpl.getPricingConditions(sale);

        // @Then salePromotionComputer.compute is called
        verify(this.salePromotionComputer, times(1)).compute(same(sale));
    }

    @Test
    public void testGetPricingConditionsReturns1YlasConditionvcId1_WhenComputeReturnedOnePromotionForCondition1() throws ExecutionException, SystemParameterNotFoundException, SystemParameterDuplicateException, SystemParameterInvalidException {
        // @Given a Sale with one promotion applicable of condition 1
        Customer customer = new Customer();
        Grower grower = new Grower();
        Sale sale = new Sale(customer, grower);
        when(this.salePromotionComputer.compute(sale)).thenReturn(Sets.<SalePromotion>newHashSet(new SalePromotion(new PricingCondition("1", "A"))));

        // @When Getting the pricing conditions
        List<YlasConditionvc> ylasConditionvcs = this.lasVCOrderRegistrationAdapterImpl.getPricingConditions(sale);

        // @Then a list with one condition with id 1 is returned
        assertThat(ylasConditionvcs).onProperty("yyIdCondition").containsExactly("1");
    }

    @Test
    public void testGetPricingConditionsReturns1YlasConditionvcId6_WhenComputeReturnedOnePromotionForCondition6() throws ExecutionException, SystemParameterNotFoundException, SystemParameterDuplicateException, SystemParameterInvalidException {
        // @Given a Sale with one promotion applicable of condition 6
        Customer customer = new Customer();
        Grower grower = new Grower();
        Sale sale = new Sale(customer, grower);
        when(this.salePromotionComputer.compute(sale)).thenReturn(Sets.<SalePromotion>newHashSet(new SalePromotion(new PricingCondition("6", "A"))));

        // @When Getting the pricing conditions
        List<YlasConditionvc> ylasConditionvcs = this.lasVCOrderRegistrationAdapterImpl.getPricingConditions(sale);

        // @Then a list with one condition with id 6 is returned
        assertThat(ylasConditionvcs).onProperty("yyIdCondition").containsExactly("6");
    }

    @Test
    public void testGetPricingConditionsReturns1YlasConditionvcTypeA_WhenComputeReturnedOnePromotionForConditionTypeA() throws ExecutionException, SystemParameterNotFoundException, SystemParameterDuplicateException, SystemParameterInvalidException {
        // @Given a Sale with one promotion applicable of condition type A
        Customer customer = new Customer();
        Grower grower = new Grower();
        Sale sale = new Sale(customer, grower);
        when(this.salePromotionComputer.compute(sale)).thenReturn(Sets.<SalePromotion>newHashSet(new SalePromotion(new PricingCondition("6", "A"))));

        // @When Getting the pricing conditions
        List<YlasConditionvc> ylasConditionvcs = this.lasVCOrderRegistrationAdapterImpl.getPricingConditions(sale);

        // @Then a list with one condition with type A is returned
        assertThat(ylasConditionvcs).onProperty("yyType").containsExactly("A");
    }

    @Test
    public void testGetPricingConditionsReturns1YlasConditionvcTypeZZ_WhenComputeReturnedOnePromotionForConditionTypeZZ() throws ExecutionException, SystemParameterNotFoundException, SystemParameterDuplicateException, SystemParameterInvalidException {
        // @Given a Sale with one promotion applicable of condition type ZZ
        Customer customer = new Customer();
        Grower grower = new Grower();
        Sale sale = new Sale(customer, grower);
        when(this.salePromotionComputer.compute(sale)).thenReturn(Sets.<SalePromotion>newHashSet(new SalePromotion(new PricingCondition("6", "ZZ"))));

        // @When Getting the pricing conditions
        List<YlasConditionvc> ylasConditionvcs = this.lasVCOrderRegistrationAdapterImpl.getPricingConditions(sale);

        // @Then a list with one condition with type ZZ is returned
        assertThat(ylasConditionvcs).onProperty("yyType").containsExactly("ZZ");
    }

    @Test
    public void testGetPricingConditionsReturns1YlasConditionvcValue10_WhenComputeReturnedOnePromotionForConditionValue10() throws ExecutionException, SystemParameterNotFoundException, SystemParameterDuplicateException, SystemParameterInvalidException {
        // @Given a Sale with one promotion applicable of condition
        Customer customer = new Customer();
        Grower grower = new Grower();
        Sale sale = new Sale(customer, grower);
        when(this.salePromotionComputer.compute(sale)).thenReturn(Sets.<SalePromotion>newHashSet(new SalePromotion(new PricingCondition("6", "ZZ"))));

        // @When Getting the pricing conditions
        List<YlasConditionvc> ylasConditionvcs = this.lasVCOrderRegistrationAdapterImpl.getPricingConditions(sale);

        // @Then a list with one condition with value 10 is returned
        assertThat(ylasConditionvcs).onProperty("yyValue").containsExactly(BigDecimal.valueOf(0));
    }

    @Test
    public void testGetPricingConditionsReturns2YlasConditionvc_WhenComputeReturned2Promotion() throws ExecutionException, SystemParameterNotFoundException, SystemParameterDuplicateException, SystemParameterInvalidException {
        // @Given a Sale with 2 promotion applicable
        Customer customer = new Customer();
        Grower grower = new Grower();
        Sale sale = new Sale(customer, grower);
        when(this.salePromotionComputer.compute(sale)).thenReturn(Sets.<SalePromotion>newHashSet(new SalePromotion(new PricingCondition("6", "ZZ")), new SalePromotion(new PricingCondition("1", "BD"))));

        // @When Getting the pricing conditions
        List<YlasConditionvc> ylasConditionvcs = this.lasVCOrderRegistrationAdapterImpl.getPricingConditions(sale);

        // @Then a list with one condition with value 776 is returned
        assertThat(ylasConditionvcs).hasSize(2);
        assertThat(ylasConditionvcs).onProperty("yyIdCondition").containsOnly("1", "6");
        assertThat(ylasConditionvcs).onProperty("yyType").containsOnly("ZZ", "BD");
        assertThat(ylasConditionvcs).onProperty("yyValue").containsOnly(BigDecimal.valueOf(0), BigDecimal.valueOf(0));
    }
    
    
    @Test
    public void testGetCustParamsReturnsYlasCustparamvc_WhenCancellationIsNotNull() throws ExecutionException, SystemParameterNotFoundException, SystemParameterDuplicateException, SystemParameterInvalidException {
        // @Given a Cancellation
    	Cancellation cancellation = new Cancellation();
    	cancellation.setCode("Lala");
    	
        // @When get Custom Param for cancel an order
    	List<YlasCustparamvc> listCustParams = this.lasVCOrderRegistrationAdapterImpl.getCustParams(cancellation);

        // @Then get a List of YlasCustparamvc with one element which has a key "COD_RECHAZO" and a value as value given for cancellation
    	assertThat(listCustParams).hasSize(1);
        assertThat(listCustParams).onProperty("yyKey").containsExactly("COD_RECHAZO");
        assertThat(listCustParams).onProperty("yyValue").containsExactly("Lala");
    }
    
    @Test
    public void testGetCustParamsReturnsYlasCustparamvc_WhenCancellationIsNull() throws ExecutionException, SystemParameterNotFoundException, SystemParameterDuplicateException, SystemParameterInvalidException {
        // @Given a null Cancellation
    	Cancellation cancellation = null;
    	
        // @When get Custom Param for cancel an order
    	List<YlasCustparamvc> listCustParams = this.lasVCOrderRegistrationAdapterImpl.getCustParams(cancellation);

        // @Then get a List of YlasCustparamvc with one element which has a key "cod_rechazo" and a value as value given for cancellation
        assertThat(listCustParams).isEqualTo(null);
    }
    
    @Test
    public void testGetCustParamsReturnsYlasCustparamvc_WhenSaleIsNotNull() throws ExecutionException, SystemParameterNotFoundException, SystemParameterDuplicateException, SystemParameterInvalidException {
        // @Given a Cancellation
    	Sale sale = new Sale();
    	State state = new State();
    	state.setSapCode("00");
		sale.setState(state);
    	
        // @When get Custom Param for cancel an order
    	List<YlasCustparamvc> listCustParams = this.lasVCOrderRegistrationAdapterImpl.getCustParams(sale);

        // @Then get a List of YlasCustparamvc with one element which has a key "COD_RECHAZO" and a value as value given for cancellation
    	assertThat(listCustParams).hasSize(1);
        assertThat(listCustParams).onProperty("yyKey").containsExactly("PROVIIBB");
        assertThat(listCustParams).onProperty("yyValue").containsExactly("00");
    }
    
    @Test
    public void testGetCustParamsReturnsYlasCustparamvc_WhenSaleIsFirstYear() throws ExecutionException, SystemParameterNotFoundException, SystemParameterDuplicateException, SystemParameterInvalidException {
    	//The Sale
    	Sale sale = new Sale();
        Set<GermoSupplier> germoSuppliers = new HashSet<GermoSupplier>();
        germoSuppliers.add(new GermoSupplier("MONSANTO"));
    	Warehouse warehouse = new Warehouse();
        warehouse.setId(1L);
        warehouse.setDescription("MONSANTO");
        warehouse.setGermoSuppliers(germoSuppliers);
    	sale.setWarehouse(warehouse);
    	CountriesHolder countriesHolder = mock(CountriesHolder.class);
    	field("countriesHolder").ofType(CountriesHolder.class).in(lasVCOrderRegistrationAdapterImpl).set(countriesHolder);
    	when(countriesHolder.isCountryArgentina()).thenReturn(true);
    	//Get the list of custom parameters
    	List<YlasCustparamvc> listCustParams = this.lasVCOrderRegistrationAdapterImpl.getCustParams(sale);

        // @Then get a List of YlasCustparamvc with one element which has a key "COD_RECHAZO" and a value as value given for cancellation
    	assertThat(listCustParams).hasSize(1);
        assertThat(listCustParams).onProperty("yyKey").containsExactly("BREEDER");
        assertThat(listCustParams).onProperty("yyValue").containsExactly("MONSANTO");
    }
}
