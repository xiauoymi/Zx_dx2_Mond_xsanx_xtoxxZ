package com.monsanto.brazilvaluecapture.seedsale.quota.service.impl;

import com.monsanto.brazilvaluecapture.core.base.model.bean.OperationalYear;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Customer;
import com.monsanto.brazilvaluecapture.seedsale.harvest.model.bean.Plantability;
import com.monsanto.brazilvaluecapture.seedsale.product.model.bean.Product;
import com.monsanto.brazilvaluecapture.seedsale.quota.model.bean.Quota;
import com.monsanto.brazilvaluecapture.seedsale.quota.model.bean.QuotaTransaction;
import com.monsanto.brazilvaluecapture.seedsale.quota.model.bean.QuotaType;
import com.monsanto.brazilvaluecapture.seedsale.quota.model.dao.QuotaControlDAO;
import com.monsanto.brazilvaluecapture.seedsale.quota.model.dao.QuotaDAOImpl;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.math.BigDecimal;

import static org.mockito.Mockito.*;

/**
 * Created with IntelliJ IDEA.
 * User: IFERN1
 * Date: 12/3/13
 * Time: 11:36 AM
 * To change this template use File | Settings | File Templates.
 */
@RunWith(MockitoJUnitRunner.class)
public class QuotaControlServiceImpl_UT {
    @Mock
    private QuotaControlDAO quotaControlDAO;
    @Mock
    private QuotaDAOImpl quotaDAO;
    @InjectMocks
    private QuotaControlServiceImpl quotaControlService;

    @Test
    public void when_saveTransfer_quotaControlDAO_is_request_for_existence_created_and_saved() {
        //@Given
        Customer customer = new Customer();
        customer.setId(1l);
        Product product = new Product();
        product.setId(1l);
        OperationalYear operationalYear = new OperationalYear();
        operationalYear.setId(1l);
        QuotaType fromQuotaType = QuotaType.AVAILABLE;
        QuotaType toQuotaType = QuotaType.USED;
        BigDecimal value = BigDecimal.ZERO;
        QuotaTransaction.QuotaTransactionType quotaTransactionType = QuotaTransaction.QuotaTransactionType.SALE;
        Long code = 1l;
        String invoiceNumber = "12345";
        String login = "userLogin";
        Customer multiplier = new Customer();
        multiplier.setId(1l);
        Plantability plantability = new Plantability();
        plantability.setId(1l);
        String batchName = "batchName";
        Long fromQuotaId = 1l;
        when(quotaControlDAO.fetchOnlyQuotaId(customer.getId(), product.getId(), operationalYear.getId(),
                fromQuotaType, multiplier.getId(), plantability.getId(), batchName)).thenReturn(fromQuotaId);
        Long toQuotaId = 1l;
        when(quotaControlDAO.createOrGetQuotaId(customer.getId(), product.getId(), operationalYear.getId(),
                toQuotaType, multiplier.getId(), plantability.getId(), batchName)).thenReturn(toQuotaId);

        //@When
        quotaControlService.saveTransfer(customer, product, operationalYear, fromQuotaType,
                toQuotaType, value, quotaTransactionType, code, invoiceNumber, login, multiplier, plantability, batchName);

        //@Should
        verify(quotaControlDAO).fetchOnlyQuotaId(customer.getId(), product.getId(), operationalYear.getId(),
                fromQuotaType, multiplier.getId(), plantability.getId(), batchName);
        verify(quotaControlDAO).createOrGetQuotaId(customer.getId(), product.getId(), operationalYear.getId(),
                toQuotaType, multiplier.getId(), plantability.getId(), batchName);
        verify(quotaControlDAO).saveTransfer(fromQuotaId, toQuotaId, quotaTransactionType, code, invoiceNumber, login, value);
    }

    @Test
    public void when_saveDeposit_quota_is_created_and_deposit_saved() {
        //@Given
        Customer customer = new Customer();
        customer.setId(1l);
        Product product = new Product();
        product.setId(1l);
        OperationalYear operationalYear = new OperationalYear();
        operationalYear.setId(1l);
        QuotaType quotaType = QuotaType.USED;
        BigDecimal value = BigDecimal.ZERO;
        QuotaTransaction.QuotaTransactionType quotaTransactionType = QuotaTransaction.QuotaTransactionType.SALE;
        Long code = 1l;
        String invoiceNumber = "12345";
        String login = "userLogin";
        Customer multiplier = new Customer();
        multiplier.setId(1l);
        Plantability plantability = new Plantability();
        plantability.setId(1l);
        String batchName = "batchName";
        Long toQuotaId = 1l;
        when(quotaControlDAO.createOrGetQuotaId(customer.getId(), product.getId(), operationalYear.getId(),
                quotaType, multiplier.getId(), plantability.getId(), batchName)).thenReturn(toQuotaId);

        //@When
        quotaControlService.saveDeposit(customer, product, operationalYear, quotaType, value,
                quotaTransactionType, code, invoiceNumber, login, multiplier, plantability, batchName);

        //@Should
        verify(quotaControlDAO).createOrGetQuotaId(customer.getId(), product.getId(), operationalYear.getId(),
                quotaType, multiplier.getId(), plantability.getId(), batchName);
        verify(quotaControlDAO).saveDeposit(toQuotaId, quotaTransactionType, code, invoiceNumber, login, value);
    }

    @Test
    public void when_save_quota_is_created_and_refreshed() {
        //@Given
        Customer customer = new Customer();
        customer.setId(1l);
        Product product = new Product();
        product.setId(1l);
        OperationalYear operationalYear = new OperationalYear();
        operationalYear.setId(1l);
        QuotaType quotaType = QuotaType.USED;
        Customer multiplier = new Customer();
        multiplier.setId(1l);
        Plantability plantability = new Plantability();
        plantability.setId(1l);
        String batchName = "batchName";
        Quota quota = new Quota(operationalYear, customer, product, quotaType);
        quota.setLot(batchName);
        quota.setPlantability(plantability);
        quota.setMultiplier(multiplier);
        Long quotaId = 1l;
        when(quotaControlDAO.createOrGetQuotaId(quota.getCustomer().getId(),
                quota.getProduct().getId(), quota.getOperationalYear().getId(), quota.getType(),
                quota.getMultiplier().getId(), quota.getPlantability().getId(), quota.getLot())).thenReturn(quotaId);
        when(quotaDAO.getQuotaById(quotaId)).thenReturn(quota);
        when(quotaControlDAO.refresh(quota)).thenReturn(quota);

        //@When
        quotaControlService.save(quota);

        //@Should
        verify(quotaControlDAO).createOrGetQuotaId(quota.getCustomer().getId(), quota.getProduct().getId(),
                quota.getOperationalYear().getId(), quota.getType(),
                multiplier.getId(), plantability.getId(), batchName);
        verify(quotaControlDAO).refresh(quota);
    }
}
