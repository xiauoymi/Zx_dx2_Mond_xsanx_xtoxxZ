package com.monsanto.brazilvaluecapture.seedsale.cashAdvance.validation.rules;

import com.monsanto.brazilvaluecapture.core.foundation.validation.ValidationException;
import com.monsanto.brazilvaluecapture.core.presentation.beans.ResourceBundleTestHelper;
import com.monsanto.brazilvaluecapture.seedsale.cashAdvance.model.bean.CashAdvanceSourceOperationType;
import com.monsanto.brazilvaluecapture.seedsale.cashAdvance.model.bean.CashAdvanceTransaction;
import org.junit.Test;

import static org.fest.assertions.Fail.fail;
import static org.fest.assertions.Assertions.*;

public class CashAdvanceSourceOperationTypeValidationRule_UT {
    @Test
    public void testValidateThrowsValidationException_WhenSourceOperationTypeInNull(){
        CashAdvanceSourceOperationTypeValidationRule cashAdvanceSourceOperationTypeValidationRule = new CashAdvanceSourceOperationTypeValidationRule();
        CashAdvanceTransaction target = new CashAdvanceTransaction();

        try {
            cashAdvanceSourceOperationTypeValidationRule.validate(target);
            fail("Should throw ValidationException");
        } catch (ValidationException e) {
            assertThat(e).hasMessage("cash.advance.message.source.operation.type.required");
        }
    }

    @Test
    public void testValidateWontThrowsValidationException_WhenSourceOperationTypeInNotNull(){
        CashAdvanceSourceOperationTypeValidationRule cashAdvanceSourceOperationTypeValidationRule = new CashAdvanceSourceOperationTypeValidationRule();
        CashAdvanceTransaction target = new CashAdvanceTransaction();
        target.setSourceOperationType(CashAdvanceSourceOperationType.FORM);

        try {
            cashAdvanceSourceOperationTypeValidationRule.validate(target);
        } catch (ValidationException e) {
            fail("Should not throw ValidationException");
        }
    }

    @Test
    public void testValidateDoesNotThrowsNullPointerException_WhenTargetIsNull() throws ValidationException {
        CashAdvanceSourceOperationTypeValidationRule cashAdvanceSourceOperationTypeValidationRule = new CashAdvanceSourceOperationTypeValidationRule();

        try {
            cashAdvanceSourceOperationTypeValidationRule.validate(null);
        } catch (NullPointerException e) {
            fail("Should not throw NullPointerException");
        }
    }

    private String[] messages = {"cash.advance.message.source.operation.type.required"};

    @Test
    public void testI18mMessages_Brazil() throws Exception {
        ResourceBundleTestHelper.assertLanguageStrExistsForBrazil(messages);
    }

    @Test
    public void testI18mMessages_English() throws Exception {
        ResourceBundleTestHelper.assertLanguageStrExistsForUS(messages);
    }
}