package com.monsanto.brazilvaluecapture.seedsale.io;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import junit.framework.Assert;

import org.junit.Test;

import com.monsanto.brazilvaluecapture.core.io.ProcessorConfig;
import com.monsanto.brazilvaluecapture.core.io.ProcessorConfig.ProcessorConfigProperties;

public class ProcessorConfig_UT {

  @Test
    public void testProcessorConfig() {
        ProcessorConfig aProcessorConfig = new ProcessorConfig();
        Assert.assertTrue("Should be empty", aProcessorConfig.isEmpty());        String value = "Hello";
        String value2 = "World";
        aProcessorConfig.put(ProcessorConfigProperties.SELECTED_LOCALE, value2);        aProcessorConfig.put(ProcessorConfigProperties.LOGGED_USER, value);
        Assert.assertEquals("Should have size 2", 2, aProcessorConfig.size());
        Assert.assertTrue("Should have key", aProcessorConfig.containsKey(ProcessorConfigProperties.SELECTED_LOCALE));
        Assert.assertTrue("Should have value", aProcessorConfig.containsValue(value));
        Assert.assertEquals("Should be hello", value, aProcessorConfig.get(ProcessorConfigProperties.LOGGED_USER));
        aProcessorConfig.remove(ProcessorConfigProperties.LOGGED_USER);        Assert.assertFalse("Should not have key", aProcessorConfig.containsKey(ProcessorConfigProperties.LOGGED_USER));
        aProcessorConfig.clear();
        Assert.assertTrue("Should be empty", aProcessorConfig.isEmpty());
        Map<ProcessorConfigProperties, Object> map = new HashMap<ProcessorConfigProperties, Object>();
        map.put(ProcessorConfigProperties.LOGGED_USER, value);
        map.put(ProcessorConfigProperties.SELECTED_LOCALE, value2);
        aProcessorConfig.putAll(map);
        Assert.assertEquals("Should have size 2", 2, aProcessorConfig.size());
        Collection<Object> values = aProcessorConfig.values();
        Assert.assertTrue("Should contain value", values.contains(value));
        Set<ProcessorConfigProperties> keySet = aProcessorConfig.keySet();
        Assert.assertTrue("Should contain key", keySet.contains(ProcessorConfigProperties.LOGGED_USER));
        Set<Entry<ProcessorConfigProperties, Object>> entrySet = aProcessorConfig.entrySet();
        Assert.assertEquals("Should have size 2", 2, entrySet.size());
        for(Entry<ProcessorConfigProperties, Object> entry:entrySet) {
            if(entry.getKey().equals(ProcessorConfigProperties.LOGGED_USER)) {
                Assert.assertTrue("Should have proper value for key", entry.getValue().equals(value));
            }
            else if(entry.getKey().equals(ProcessorConfigProperties.SELECTED_LOCALE)) {
                Assert.assertTrue("Should have proper value for key", entry.getValue().equals(value2));
            }
        }
        
    }
}
