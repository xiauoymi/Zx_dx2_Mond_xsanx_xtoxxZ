package com.monsanto.brazilvaluecapture.seedsale.quota.report;

import com.csvreader.CsvReader;
import com.monsanto.brazilvaluecapture.core.base.SystemTestFixture;
import com.monsanto.brazilvaluecapture.core.commercialhierarchy.model.bean.*;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Customer;
import com.monsanto.brazilvaluecapture.core.foundation.RandomTestData;
import com.monsanto.brazilvaluecapture.core.foundation.service.EntityNotFoundException;
import com.monsanto.brazilvaluecapture.core.foundation.test.AbstractServiceIntegrationTests;
import com.monsanto.brazilvaluecapture.core.foundation.test.dbunit.DbUnitHelper;
import com.monsanto.brazilvaluecapture.core.foundation.util.ConstraintViolation;
import com.monsanto.brazilvaluecapture.core.user.AccessControlTestFixture;
import com.monsanto.brazilvaluecapture.seedsale.product.model.bean.Product;
import com.monsanto.brazilvaluecapture.seedsale.quota.model.bean.Quota;
import com.monsanto.brazilvaluecapture.seedsale.quota.model.bean.QuotaOwner;
import com.monsanto.brazilvaluecapture.seedsale.quota.model.bean.QuotaTransaction.QuotaTransactionType;
import com.monsanto.brazilvaluecapture.seedsale.quota.model.bean.QuotaType;
import com.monsanto.brazilvaluecapture.seedsale.quota.model.dao.QuotaFilter;
import com.monsanto.brazilvaluecapture.seedsale.quota.service.QuotaControlService;
import com.monsanto.brazilvaluecapture.seedsale.quota.service.QuotaService;
import com.monsanto.brazilvaluecapture.seedsale.sale.SaleTestFixture;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.Sale;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.Sale.SaleTypeEnum;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.SaleItem;
import com.monsanto.brazilvaluecapture.seedsale.sale.report.ReportOutputTypeEnum;
import com.monsanto.brazilvaluecapture.seedsale.sale.service.SaleConstraintViolationException;
import com.monsanto.brazilvaluecapture.seedsale.sale.service.SaleService;
import com.monsanto.brazilvaluecapture.seedsale.sale.service.SaleTestData;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.hibernate.criterion.Restrictions;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.math.BigDecimal;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

public class QuotaReportAssembler_AT extends AbstractServiceIntegrationTests {

	private ResourceBundle resourceBundle = ResourceBundle.getBundle("bundle/bundle");
	
	@Autowired
	private QuotaReportBuilder quotaReportBuilder;
	
	@Autowired
	private SaleService saleService;

	@Autowired
	@Qualifier("currentQuotaControlImplementation")
	private QuotaControlService quotaControlService;
	
	@Autowired
	private QuotaService quotaService;

    private SaleTestData saleFactory;
	
    @Before
    public void init() {
        systemTestFixture = new SystemTestFixture(this);
        saleTestFixture = new SaleTestFixture(this, systemTestFixture);
        accessControlTestFixture = new AccessControlTestFixture(this, systemTestFixture);

        CommercialHierType commercialHierType = (CommercialHierType) getSession()
		.createCriteria(CommercialHierType.class, "c")
		.add(Restrictions
				.eq("c.commercialHierTypeDesc",
						CommercialHierarchyType.DISTRIBUTOR.getValue()))
		.uniqueResult();

		
		CommercialHierarchy cHier = new CommercialHierarchy();
		cHier.setCommercialHierarchyId(1L);
		cHier.setCommercialHierType(commercialHierType);
		cHier.setCompany(systemTestFixture.mons4ntoBr);
		cHier.setCrop(systemTestFixture.soyMons4nto);
		
		saveAndFlush(cHier);
        
		ItsUnity unit = new ItsUnity();
		unit.setActivitySector(CommercialHierarchyType.ROYALTY.getValue());
		unit.setUnitySapDesc(RandomTestData.createRandomString(5));
		unit.setUnitySapId(RandomTestData.createRandomString(5));
		
		saveAndFlush(unit);
		
		ItsRegion region = new ItsRegion();
		region.setId(100000L);
		region.setActivitySector(RandomTestData.createRandomString(5));
		region.setItsUnity(unit);
		
		saveAndFlush(region);
		
		ItsDistrict district = new ItsDistrict();
		district.setId(10000L);
		district.setActivitySector(RandomTestData.createRandomString(5));
		district.setDistrictSapDesc(RandomTestData.createRandomString(5));
		district.setDistrictSapId(RandomTestData.createRandomString(5));
		district.setItsRegion(region);
		district.setItsUnity(unit);
		
		saveAndFlush(district);
		
		CustomerDistrict customerDistrict = new CustomerDistrict(10L,
				saleTestFixture.matrixMons4nto, commercialHierType, district, cHier);		
		
		saveAndFlush(customerDistrict);
		
		if (!getAssumptionTest().isEnvironmentWithSQLANSI()) {
			DbUnitHelper.setup("classpath:data/core/fixture-system-dataset.xml",
	                "classpath:data/core/participant-dataset.xml",
	                "classpath:data/commercialhierarchy/commercialhierarchy-dataset.xml");
			systemTestFixture.monsantoBr.setId(900000001L);
			systemTestFixture.soy.setDescription("SOJA");
			saleTestFixture.matrixCargil.setCustomerSAPCode("0001862846");
        }

        saleFactory = new SaleTestData(systemTestFixture.regionSaoPaulo2012);
    }
    
    @Test
    public void given_a_quota_with_balance_when_assemble_report_then_balance_should_display_correct_amount() throws NoSuchMethodException, IOException, EntityNotFoundException {
        Quota quota = quotaService.fetchOrCreateQuota(saleTestFixture.customer, saleTestFixture.productIntactaWithQuota, systemTestFixture.operationalYearOf2012, QuotaType.AVAILABLE, null, null, null);
        
        quotaControlService.saveDeposit(quota.getCustomer(), quota.getProduct(), quota.getOperationalYear(), quota.getType(), BigDecimal.TEN, QuotaTransactionType.SAP, null, null, "JOHN", null, null, null);
        
        
        QuotaFilter filter = QuotaFilter.getInstance()
				.add(saleTestFixture.customer)
				.add(systemTestFixture.operationalYearOf2012)
				.add(saleTestFixture.productIntactaWithQuota)
				.add(QuotaType.AVAILABLE);
        Quota quotaAvaible = quotaControlService.getQuotaBy(filter);
        
        List<Quota> quotaList = new ArrayList<Quota>();
        quotaList.add(quotaAvaible);
        ReportOutputTypeEnum reportOutputType = ReportOutputTypeEnum.XLS;
        QuotaReportAssembler assembler = QuotaReportAssembler.buildAssembler(quotaList, reportOutputType);
        ByteArrayOutputStream baos = assembler.build(resourceBundle, reportOutputType);
        
        Double balance = assertSheetAndGetBalance(baos, 1, 11);
        Assert.assertEquals("Should be 10", 0.0d, balance, 0.0d);
    }
    
    @Test
    public void given_three_quotas_in_list_when_assemble_report_then_should_have_4_lines_10_cols() throws NoSuchMethodException, IOException {
        List<Quota> quotaList = new ArrayList<Quota>();
        Quota quota = new Quota(systemTestFixture.operationalYearOf2012, saleTestFixture.customer, saleTestFixture.productIntactaWithQuota, QuotaType.AVAILABLE); 
        quotaList.add(quota);
        quota = new Quota(systemTestFixture.operationalYearOf2012, saleTestFixture.matrixMons4nto, saleTestFixture.productIntactaWithQuota, QuotaType.AVAILABLE); 
        quotaList.add(quota);
        quota = new Quota(systemTestFixture.operationalYearOf2011, saleTestFixture.customer, saleTestFixture.productIntactaWithQuota, QuotaType.AVAILABLE); 
        quotaList.add(quota);
        
        ReportOutputTypeEnum reportOutputType = ReportOutputTypeEnum.XLS;
        QuotaReportAssembler assembler = QuotaReportAssembler.buildAssembler(quotaList, reportOutputType);
        ByteArrayOutputStream baos = assembler.build(resourceBundle, reportOutputType);
        
    	Double d = assertSheetAndGetBalance(baos, 3, 11);
    	Assert.assertEquals("Should be 0", 0.0d, (double)d, 0.0d);
        
    }
    
    @Test
    public void given_two_stored_quotas_when_I_search_with_no_filter_then_should_generate_report_with_2_rows() throws QuotaReportConstraintException, EmptyReportException, IOException, NoSuchMethodException {
        List<Quota> quotaList = new ArrayList<Quota>();

        Quota quota = quotaService.fetchOrCreateQuota(saleTestFixture.customer, saleTestFixture.productIntactaWithQuota, systemTestFixture.operationalYearOf2012, QuotaType.AVAILABLE, null, null, null);
        quota.setOwner(QuotaOwner.DEALER);
        quotaList.add(quota);
        quota = quotaService.fetchOrCreateQuota(saleTestFixture.matrixMons4nto, saleTestFixture.productIntactaWithQuota, systemTestFixture.operationalYearOf2012, QuotaType.AVAILABLE, null, null, null);
        quota.setOwner(QuotaOwner.DEALER);
        quotaList.add(quota);
        quotaReportBuilder.clear();
        quotaReportBuilder.loadRecords(null, null, null, null, QuotaReportType.BALANCE, systemTestFixture.mons4ntoBr, systemTestFixture.soyMons4nto, null,null,null, QuotaOwner.DEALER, null, null, null);
        ByteArrayOutputStream report = quotaReportBuilder.buildReportFor(null, QuotaReportType.BALANCE);
        
        double d = assertSheetAndGetBalance(report, 2, 11);
        Assert.assertEquals("Should be 0", 0.0d, d, 0.0d);
    }
    
    @Test(expected=EmptyReportException.class)
    public void given_two_stored_quotas_when_I_search_with_invalid_document_then_should_throw_empty_report_exception() throws QuotaReportConstraintException, EmptyReportException, IOException, NoSuchMethodException {
        List<Quota> quotaList = new ArrayList<Quota>();
        Quota quota = quotaService.fetchOrCreateQuota(saleTestFixture.customer, saleTestFixture.productIntactaWithQuota, systemTestFixture.operationalYearOf2012, QuotaType.AVAILABLE, null, null, null);
        quota.setOwner(QuotaOwner.MULTIPLIER);
        quotaList.add(quota);
        quota = quotaService.fetchOrCreateQuota(saleTestFixture.matrixMons4nto, saleTestFixture.productIntactaWithQuota, systemTestFixture.operationalYearOf2012, QuotaType.AVAILABLE, null, null, null);
        quota.setOwner(QuotaOwner.MULTIPLIER);
        quotaList.add(quota);
        quotaReportBuilder.clear();
        quotaReportBuilder.loadRecords(null, saleTestFixture.matrixCargil, null, null, QuotaReportType.BALANCE, systemTestFixture.monsantoBr, systemTestFixture.soy, null,null,null, QuotaOwner.MULTIPLIER, null, null, null);
        quotaReportBuilder.buildReportFor(null, QuotaReportType.BALANCE);
    }

    @Test(expected=QuotaReportConstraintException.class)
    public void given_two_stored_quotas_when_I_search_with_product_with_no_quota_then_should_throw_constraint_exception() throws QuotaReportConstraintException, EmptyReportException, IOException, NoSuchMethodException {
        List<Quota> quotaList = new ArrayList<Quota>();
        Quota quota = quotaService.fetchOrCreateQuota(saleTestFixture.customer, saleTestFixture.productIntactaWithQuota, systemTestFixture.operationalYearOf2012, QuotaType.AVAILABLE, null, null, null);
        quota.setOwner(QuotaOwner.MULTIPLIER);
        quotaList.add(quota);
        quota = quotaService.fetchOrCreateQuota(saleTestFixture.matrixMons4nto, saleTestFixture.productIntactaWithQuota, systemTestFixture.operationalYearOf2012, QuotaType.AVAILABLE, null, null, null);
        quota.setOwner(QuotaOwner.MULTIPLIER);
        quotaList.add(quota);
        quotaReportBuilder.clear();
        quotaReportBuilder.loadRecords(null, null, null, null, QuotaReportType.BALANCE, systemTestFixture.monsantoBr, systemTestFixture.soy, null, saleTestFixture.productIntactaSoy,null, QuotaOwner.MULTIPLIER, null, null, null);
        quotaReportBuilder.buildReportFor(null, QuotaReportType.BALANCE);
    }
    
    @Test
    public void given_two_stored_quotas_when_I_search_with_all_filters_then_should_return_worksheet_with_1_row() throws QuotaReportConstraintException, EmptyReportException, IOException, NoSuchMethodException {
        List<Quota> quotaList = new ArrayList<Quota>();
        Quota quota = quotaService.fetchOrCreateQuota(saleTestFixture.customer, saleTestFixture.productIntactaWithQuota, systemTestFixture.operationalYearOf2012, QuotaType.AVAILABLE, null, null, null);
        quotaList.add(quota);
        quota.setOwner(QuotaOwner.DEALER);
        quota = quotaService.fetchOrCreateQuota(saleTestFixture.matrixMons4nto, saleTestFixture.productIntactaWithQuota, systemTestFixture.operationalYearOf2012, QuotaType.AVAILABLE, null, null, null);
        quota.setOwner(QuotaOwner.DEALER);
        quotaList.add(quota);

        quotaReportBuilder.clear();
        quotaReportBuilder.loadRecords(systemTestFixture.operationalYearOf2012, saleTestFixture.customer, systemTestFixture.intactaMons4nto,resourceBundle, QuotaReportType.BALANCE, systemTestFixture.mons4ntoBr, systemTestFixture.soyMons4nto, null, saleTestFixture.productIntactaWithQuota,null, QuotaOwner.DEALER, null, null, null);
        ByteArrayOutputStream report = quotaReportBuilder.buildReportFor(resourceBundle, QuotaReportType.BALANCE);
        
        double d = assertSheetAndGetBalance(report, 1, 11);
        Assert.assertEquals("Should be 0", 0.0d, d, 0.0d);
    }
    
    @Test(expected=QuotaReportConstraintException.class)
    public void when_buildReport_without_quotaReportType_should_throw_exception() throws QuotaReportConstraintException, EmptyReportException, IOException, NoSuchMethodException {
        quotaReportBuilder.clear();
        quotaReportBuilder.loadRecords(systemTestFixture.operationalYearOf2012, saleTestFixture.customer, systemTestFixture.intactaMons4nto,resourceBundle, null, systemTestFixture.monsantoBr, systemTestFixture.soy, null, saleTestFixture.productIntactaWithQuota,null, QuotaOwner.MULTIPLIER, null, null, null);
    	quotaReportBuilder.buildReportFor(resourceBundle, null);
    	Assert.fail("Should fail at this point!");
    }
    
    @Test
    public void when_buildReport_without_crop_should_throw_exception() throws EmptyReportException, IOException, NoSuchMethodException {
    	try {
    		quotaReportBuilder.clear();
            quotaReportBuilder.loadRecords(systemTestFixture.operationalYearOf2012, saleTestFixture.customer, systemTestFixture.intacta, resourceBundle, QuotaReportType.BALANCE, systemTestFixture.monsantoBr, null, null, saleTestFixture.productIntactaWithQuota,null, QuotaOwner.MULTIPLIER, null, null, null);
			quotaReportBuilder.buildReportFor(resourceBundle, QuotaReportType.BALANCE);
			Assert.fail("Should have thrown exception of crop required");
		} catch (QuotaReportConstraintException e) {
			Assert.assertTrue("Should require crop", hasExpectedMessage(e, "Crop is required."));
		}
    }
    
    @Test
    public void when_buildReport_without_company_should_throw_exception() throws EmptyReportException, IOException, NoSuchMethodException {
    	try {
    		quotaReportBuilder.clear();
            quotaReportBuilder.loadRecords(systemTestFixture.operationalYearOf2012, saleTestFixture.customer, systemTestFixture.intacta,resourceBundle, QuotaReportType.BALANCE, null, systemTestFixture.soy, null,saleTestFixture.productIntactaWithQuota,null, QuotaOwner.MULTIPLIER, null, null, null);
			quotaReportBuilder.buildReportFor(resourceBundle, QuotaReportType.BALANCE);
			Assert.fail("Should have thrown exception of company required");
		} catch (QuotaReportConstraintException e) {
			Assert.assertTrue("Should require company", hasExpectedMessage(e, "Company is required."));
		}
    }

	private boolean hasExpectedMessage(QuotaReportConstraintException e, String expectedMessage) {
		boolean hasExpectedViolation = false;
		for (ConstraintViolation violation : e.getViolations()) {
			if (expectedMessage.equals(violation.getMessage())) {
				hasExpectedViolation = true;
				break;
			}
		}
		return hasExpectedViolation;
	}
	
    @Ignore
    public void given_extractQuotaReport_when_one_quotaSaved_should_return_one_row() throws QuotaReportConstraintException, EmptyReportException, IOException, NoSuchMethodException, SaleConstraintViolationException {
    	if (!getAssumptionTest().isEnvironmentWithSQLANSI()) {
			DbUnitHelper.setup("classpath:data/seedsale/vw-quota-extract-report-dataset.xml");
    	}else{    		
    		createAndSaveQuotaForReport(BigDecimal.TEN, saleTestFixture.matrixCargil,QuotaOwner.MULTIPLIER);
    	}

    	quotaReportBuilder.clear();
        quotaReportBuilder.loadRecords(systemTestFixture.operationalYearOf2012, saleTestFixture.matrixCargil, null,resourceBundle, QuotaReportType.EXTRACT, systemTestFixture.monsantoBr, systemTestFixture.soy, null,null,null, QuotaOwner.MULTIPLIER, null, null, null);
    	ByteArrayOutputStream report = quotaReportBuilder.buildReportFor(resourceBundle, QuotaReportType.EXTRACT);
    	Double balance = assertSheetAndGetBalance(report, 1, 26);
    	Assert.assertEquals("Should have balance of ten", BigDecimal.TEN, new BigDecimal(balance));
    }
    
    @Ignore
    public void given_extractQuotaReport_when_one_quotaSaved_should_return_one_row_in_csv() throws QuotaReportConstraintException, EmptyReportException, IOException, NoSuchMethodException, SaleConstraintViolationException {
    	if (!getAssumptionTest().isEnvironmentWithSQLANSI()) {
			DbUnitHelper.setup("classpath:data/seedsale/vw-quota-extract-report-dataset.xml");
    	}else{
    		createAndSaveQuotaForReport(BigDecimal.TEN, saleTestFixture.matrixCargil, QuotaOwner.DEALER);
    	}
    	quotaReportBuilder.clear();
        quotaReportBuilder.loadRecords(systemTestFixture.operationalYearOf2012, saleTestFixture.matrixCargil, null, resourceBundle, QuotaReportType.EXTRACT, systemTestFixture.monsantoBr, systemTestFixture.soy, null,null,null, QuotaOwner.DEALER, null, null, null);
        if(ReportOutputTypeEnum.XLS.equals(quotaReportBuilder.getReportOutputType())){
        	quotaReportBuilder.setReportOutputType(ReportOutputTypeEnum.CSV);
   	 	}
        ByteArrayOutputStream report = quotaReportBuilder.buildReportFor(resourceBundle, QuotaReportType.EXTRACT);
    	InputStream inputStream = new ByteArrayInputStream(report.toByteArray());
        CsvReader csv = new CsvReader(inputStream, Charset.forName("Windows-1252"));
        csv.readHeaders();
        csv.readRecord();
        String[] rows = csv.getValues();
        String[] cols = rows[0].split(";");
        Assert.assertEquals("Should have balance of ten", BigDecimal.TEN, new BigDecimal(cols[26]).setScale(0));
    }
    
    @Ignore
    public void given_extractQuotaReport_when_sale_consuming_quota_should_return_two_row() throws QuotaReportConstraintException, EmptyReportException, IOException, NoSuchMethodException, SaleConstraintViolationException, InterruptedException {
    	if (!getAssumptionTest().isEnvironmentWithSQLANSI()) {
			DbUnitHelper.setup("classpath:data/seedsale/vw-quota-extract-report-dataset.xml");
    	}else{
    		createAndSaveQuotaForReport(BigDecimal.TEN, saleTestFixture.matrixCargil, QuotaOwner.MULTIPLIER);
        	
			//Pause for 3 seconds
            Thread.sleep(3000);
						
        	Sale saleConsumingQuota = createSaleWithItemConsumingQuota();
        	accessControlTestFixture.superUser.setContextCompany(systemTestFixture.monsantoBr);
        	accessControlTestFixture.superUser.setContextCrop(systemTestFixture.soy);
        	
        	saleService.save(saleConsumingQuota, accessControlTestFixture.superUser);
    	}    	
    	quotaReportBuilder.clear();
    	quotaReportBuilder.loadRecords(systemTestFixture.operationalYearOf2012, saleTestFixture.matrixCargil, null,resourceBundle, QuotaReportType.EXTRACT, systemTestFixture.monsantoBr, systemTestFixture.soy, null,null,null, QuotaOwner.MULTIPLIER, null, null, null);
    	ByteArrayOutputStream report = quotaReportBuilder.buildReportFor(resourceBundle, QuotaReportType.EXTRACT);
    	Double balanceAvailable = assertSheetAndGetBalance(report, 1, 26);
    	Assert.assertEquals("Should have balance of ten", new BigDecimal(10), new BigDecimal(balanceAvailable));
    	Double balanceConsumed = assertSheetAndGetBalance(report, 2, 26);
    	Assert.assertEquals("Should have balance of minus ten", new BigDecimal(-10), new BigDecimal(balanceConsumed));
    }
    
	private Sale createSaleWithItemConsumingQuota() {
		Sale saleConsumingQuota = saleFactory.createSale(saleTestFixture.matrixCargil, saleTestFixture.chicoBento, SaleTypeEnum.SALE_SEED);
		saleConsumingQuota.setState(systemTestFixture.matoGrossoDoSul);
    	SaleItem itemWithQuotaUsage = createSaleItemForQuotaConsumption(saleConsumingQuota, saleTestFixture.productIntactaWithQuotaForReport);
		saleConsumingQuota.addItem(itemWithQuotaUsage);
    	return saleConsumingQuota;
	}

    private SaleItem createSaleItemForQuotaConsumption(Sale saleConsumingQuota, Product product) {
        SaleItem itemWithQuotaUsage = SaleTestData.createSaleItem(saleConsumingQuota, saleTestFixture.templateIntactaByPlantabilityRRByExpirationBtFreeErp, product, saleTestFixture.matrixCargil);
        itemWithQuotaUsage.setPriceQuantity(new BigDecimal("0.7"));
        itemWithQuotaUsage.setPlantability(saleTestFixture.plantability45To54SoyMonsanto2012.getDescription());
    	itemWithQuotaUsage.setProductivityValue(BigDecimal.valueOf(505L));
    	itemWithQuotaUsage.setDueDate(SaleTestFixture.DATE_NOW);
        return itemWithQuotaUsage;
    }
    
	private Quota createAndSaveQuotaForReport(BigDecimal amount, Customer customer, QuotaOwner quotaOwner) {
		Quota quotaForConsumption = quotaService.fetchOrCreateQuota(customer, saleTestFixture.productIntactaWithQuotaForReport, systemTestFixture.operationalYearOf2012, QuotaType.AVAILABLE, null, null, null);
    	quotaForConsumption.setOwner(quotaOwner);
        quotaControlService.saveDeposit(quotaForConsumption.getCustomer(), quotaForConsumption.getProduct(), quotaForConsumption.getOperationalYear(), QuotaType.AVAILABLE, amount, QuotaTransactionType.CSV, null, null, "vrodrigues", null, null, null);
    	return quotaForConsumption;
	}
    
    private Double assertSheetAndGetBalance(ByteArrayOutputStream baos, int rowNum, int cellAmount) throws IOException {
        ByteArrayInputStream inputStream = new ByteArrayInputStream(baos.toByteArray());
    	HSSFWorkbook hssfWorkbook = new HSSFWorkbook(inputStream);
    	Assert.assertNotNull("workbook shouldn't be null", hssfWorkbook);
    	HSSFSheet sheet = hssfWorkbook.getSheetAt(0);
    	Assert.assertNotNull("Sheet shouldn't be null", sheet);
    	HSSFRow row = sheet.getRow(rowNum);
    	Assert.assertNotNull("Row shouldn't be null", row);
    	HSSFCell cell = row.getCell(cellAmount);
    	Assert.assertNotNull("Cell shouldn't be null", cell);
    	return cell.getNumericCellValue();
    }

}
