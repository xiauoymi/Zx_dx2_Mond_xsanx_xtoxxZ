/**
 * 
 */
package com.monsanto.brazilvaluecapture.seedsale.sale.service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import com.monsanto.CountriesHolderInitializer;
import com.monsanto.brazilvaluecapture.core.regionalization.CountriesHolder;
import junit.framework.Assert;

import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.monsanto.brazilvaluecapture.core.base.SystemTestFixture;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Crop;
import com.monsanto.brazilvaluecapture.core.foundation.model.bean.ApprovalEnum;
import com.monsanto.brazilvaluecapture.core.foundation.service.BusinessException;
import com.monsanto.brazilvaluecapture.core.foundation.test.AbstractServiceIntegrationTests;
import com.monsanto.brazilvaluecapture.core.revenue.model.bean.ChargeConsolidate;
import com.monsanto.brazilvaluecapture.core.revenue.model.bean.ChargeConsolidateFilter;
import com.monsanto.brazilvaluecapture.core.revenue.model.bean.ChargeConsolidateStatus;
import com.monsanto.brazilvaluecapture.core.revenue.model.bean.ChargeConsolidateType;
import com.monsanto.brazilvaluecapture.core.revenue.model.bean.ChargeConsolidateTypeEnum;
import com.monsanto.brazilvaluecapture.core.user.AccessControlTestFixture;
import com.monsanto.brazilvaluecapture.core.user.model.bean.HierarchyLevel;
import com.monsanto.brazilvaluecapture.core.user.model.bean.ItsUser;
import com.monsanto.brazilvaluecapture.core.user.model.bean.UserContext;
import com.monsanto.brazilvaluecapture.core.user.model.bean.UserDecorator;
import com.monsanto.brazilvaluecapture.core.user.service.UserService;
import com.monsanto.brazilvaluecapture.seedsale.billing.model.bean.Billing;
import com.monsanto.brazilvaluecapture.seedsale.billing.model.bean.BillingDTO;
import com.monsanto.brazilvaluecapture.seedsale.billing.model.dao.BillingFilter;
import com.monsanto.brazilvaluecapture.seedsale.billing.service.BillingConstraintViolationException;
import com.monsanto.brazilvaluecapture.seedsale.sale.SaleTestFixture;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.ReleaseMatrix;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.Sale;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.Sale.SaleTypeEnum;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.SaleItem;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.dao.ReleaseMatrixFilter;
import com.monsanto.brazilvaluecapture.seedsale.sale.service.impl.ChargeConsolidateManager;
import com.monsanto.brazilvaluecapture.seedsale.template.model.bean.Price;
import com.monsanto.brazilvaluecapture.seedsale.template.model.bean.RetributionFee;
import com.monsanto.brazilvaluecapture.seedsale.template.model.bean.RetributionFee.RetributionSourceType;

/**
 * @author andregc
 *
 */
public class ChargeConsolidateManager_AT extends AbstractServiceIntegrationTests {
	
	@Autowired
	private SaleService saleService;
	@Autowired
	private UserService userService;
	@Autowired
	private ReleaseMatrixService releaseMatrixService;
	
    @Autowired
    private ChargeConsolidateManager chargeConsolidateManager;

    @Autowired
    private CountriesHolder countriesHolder;
	
	private SaleItemFactory saleItemFactory;
	private ChargeConsolidateType saleRegisterType;
	private List<ChargeConsolidateType> saleRegisterTypeAsList;

    private SaleTestData saleFactory;

	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void setUp() throws Exception {
        CountriesHolderInitializer.initialize(countriesHolder);
		systemTestFixture = new SystemTestFixture(this);
		saleTestFixture = new SaleTestFixture(this, systemTestFixture);
		accessControlTestFixture = new AccessControlTestFixture(this, systemTestFixture);
		saleItemFactory = SaleItemFactory.getInstance(systemTestFixture.matoGrossoDoSul, saleTestFixture.plantabilitiesSelector);
		
		createChargeConsolidateTypes();
		
		saleRegisterType = chargeConsolidateService.findConsolidateType(ChargeConsolidateTypeEnum.SALEREGISTERCHARGE);
		saleRegisterTypeAsList = new ArrayList<ChargeConsolidateType>();
		saleRegisterTypeAsList.add(saleRegisterType);
		
		accessControlTestFixture.itsParticipantUser.addProfile(accessControlTestFixture.profileWithOneAction);
		accessControlTestFixture.itsParticipantUser.addUserContract(saleTestFixture.contractCargil, saleTestFixture.matrixCargil, HierarchyLevel.HEAD_OFFICE);
		saveAndFlush(accessControlTestFixture.itsParticipantUser);
		
		Price price = saleTestFixture.templateIntactaFixRRRangeBtNoValue.getPriceOf(systemTestFixture.intacta);
		RetributionFee retributionFee = new RetributionFee();
		retributionFee.setRetributionFeeEnabled(true);
		retributionFee.setRetributionFeeSourceType(RetributionSourceType.ITS);
		retributionFee.setRetributionFee(BigDecimal.TEN);
		price.setRetributionFee(retributionFee);
		saveAndFlush(price);

        saleFactory = new SaleTestData(systemTestFixture.regionSaoPaulo2012);
	}

	@Test
	public void sanity_check() {
		Assert.assertNotNull("SaleService should not be null", saleService);
		Assert.assertNotNull("ChargeConsolidateService should not be null", chargeConsolidateService);
		Assert.assertNotNull("UserService should not be null", userService);
	}

	
	@Test
	public void given_a_billing_associate_an_item_with_a_saleTemplate_that_generates_chargeConsolidate_when_I_pay_billing_should_generate_a_chargeConsolidate_for_the_matrix() throws BusinessException {
		createAndPayManuallyBillingWithSaleItemsThatHaveFees();
		
		ChargeConsolidateFilter filter = new ChargeConsolidateFilter();
		filter.setCompany(systemTestFixture.monsantoBr);
		filter.setContract(saleTestFixture.contractCargil);
		filter.setCrop(systemTestFixture.soy);
		filter.setHarvest(saleTestFixture.harvestSoyMonsanto2012.getDescription());
		filter.setMatrix(saleTestFixture.matrixCargil);
		filter.setOperationalYear(systemTestFixture.operationalYearOf2012);
		
		List<ChargeConsolidate> chargeConsolidateList = chargeConsolidateService.findCreditConsumptionChargeConsolidate(filter);
		Assert.assertEquals("Should have only one ChargeConsolidate", 1, chargeConsolidateList.size());
		ChargeConsolidate chargeConsolidate = chargeConsolidateList.iterator().next();
		Assert.assertEquals("ChargeConsolidate value should be 1", BigDecimal.ONE.setScale(2), chargeConsolidate.getChargeConsolidateValue());
	}

	
	@Test
	public void given_two_billing_that_generate_chargeConsolidate_when_i_pay_billings_should_sum_the_value() throws BusinessException {
		createAndPayManuallyBillingWithSaleItemsThatHaveFees();
		createAndPayManuallyBillingWithSaleItemsThatHaveFees();
		
		ChargeConsolidateFilter filter = new ChargeConsolidateFilter();
		filter.setCompany(systemTestFixture.monsantoBr);
		filter.setContract(saleTestFixture.contractCargil);
		filter.setCrop(systemTestFixture.soy);
		filter.setHarvest(saleTestFixture.harvestSoyMonsanto2012.getDescription());
		filter.setMatrix(saleTestFixture.matrixCargil);
		filter.setOperationalYear(systemTestFixture.operationalYearOf2012);
		
		List<ChargeConsolidate> chargeConsolidateList = chargeConsolidateService.findCreditConsumptionChargeConsolidate(filter);
		Assert.assertEquals("Should have only one ChargeConsolidate", 1, chargeConsolidateList.size());
		ChargeConsolidate chargeConsolidate = chargeConsolidateList.iterator().next();
		Assert.assertEquals("ChargeConsolidate value should be 1", new BigDecimal(2).setScale(2), chargeConsolidate.getChargeConsolidateValue());
	}
	
	@Test
	public void given_a_billing_with_one_item_of_a_matrix_that_dont_have_a_releaseMatrix_registered_when_i_pay_billing_then_releaseMatrix_shouldBe_generated_not_approved() throws BusinessException {
		createAndPayManuallyBillingWithSaleItemsThatHaveFees();
		
		ReleaseMatrixFilter releaseMatrixFilter = ReleaseMatrixFilter.getInstance()
				.addAproved(ApprovalEnum.DONT_APROVED)
				.addChargeConsolidateTypes(saleRegisterTypeAsList)
				.addMatrix(saleTestFixture.matrixCargil);
		
		List<ReleaseMatrix> matrixList = releaseMatrixService.getByFilter(releaseMatrixFilter);
		Assert.assertEquals("Should return 1 release matrix", 1, matrixList.size());
	}
	
	@Test
	public void given_a_matrix_approved_when_i_pay_billing_generated_chargeConsolidate_status_shouldBe_released() throws BusinessException {
		ReleaseMatrix releaseMatrix = new ReleaseMatrix(saleTestFixture.harvestSoyMonsanto2012, saleTestFixture.matrixCargil, saleRegisterType);
		releaseMatrix.setAproved(ApprovalEnum.APROVED);
		saveAndFlush(releaseMatrix);
		
		createAndPayManuallyBillingWithSaleItemsThatHaveFees();
		
		ChargeConsolidateFilter filter = new ChargeConsolidateFilter();
		filter.setCompany(systemTestFixture.monsantoBr);
		filter.setContract(saleTestFixture.contractCargil);
		filter.setCrop(systemTestFixture.soy);
		filter.setHarvest(saleTestFixture.harvestSoyMonsanto2012.getDescription());
		filter.setMatrix(saleTestFixture.matrixCargil);
		filter.setOperationalYear(systemTestFixture.operationalYearOf2012);
		
		List<ChargeConsolidate> chargeConsolidateList = chargeConsolidateService.findCreditConsumptionChargeConsolidate(filter);
		Assert.assertEquals("Should have only one ChargeConsolidate", 1, chargeConsolidateList.size());
		ChargeConsolidate chargeConsolidate = chargeConsolidateList.iterator().next();
		Assert.assertEquals("ChargeConsolidate status should be released", ChargeConsolidateStatus.RELEASED, chargeConsolidate.getChargeConsolidateStatus());
	}
	
	@Test
	public void given_billetBilling_when_i_pay_billet_should_generate_chargeConsolidate() throws BusinessException {
		createBilletBilling();
		
		ChargeConsolidateFilter filter = new ChargeConsolidateFilter();
		filter.setCompany(systemTestFixture.monsantoBr);
		filter.setContract(saleTestFixture.contractCargil);
		filter.setCrop(systemTestFixture.soy);
		filter.setHarvest(saleTestFixture.harvestSoyMonsanto2012.getDescription());
		filter.setMatrix(saleTestFixture.matrixCargil);
		filter.setOperationalYear(systemTestFixture.operationalYearOf2012);
		
		List<ChargeConsolidate> chargeConsolidateList = chargeConsolidateService.findCreditConsumptionChargeConsolidate(filter);
		Assert.assertEquals("Should have only one ChargeConsolidate", 1, chargeConsolidateList.size());
	}
	
	private Billing createAndPayManuallyBillingWithSaleItemsThatHaveFees()
			throws BusinessException, BillingConstraintViolationException {
		Billing billing = createBillingWithOneSaleItemThatHaveFees();
		saleService.payBilling(billing, SaleTestFixture.JANUARY, BigDecimal.TEN, true);
		return billing;
	}

	private Billing createBillingWithOneSaleItemThatHaveFees()
			throws BusinessException {
		Sale sale = saleFactory.createSale(saleTestFixture.matrixCargil, saleTestFixture.chicoBento, SaleTypeEnum.SALE_SEED);
		sale.setState(systemTestFixture.matoGrossoDoSul);
		
		SaleItem saleItemFix = saleItemFactory
				.createFixValueItem(saleTestFixture.productIntactaSoy,
						saleTestFixture.templateIntactaFixRRRangeBtNoValue,
						saleTestFixture.headOfficeCargil, 2L);
		
		sale.addItem(saleItemFix);
		saveSaleForSuperUser(sale);
		
		UserDecorator loggedSuperUser = accessControlTestFixture.superUser;
		loggedSuperUser.setContextCrop(systemTestFixture.soy);
		
		BillingFilter billingFilter = BillingFilter.getInstance()
				.add(sale.getId())
				.add((UserContext)loggedSuperUser);
		
		List<BillingDTO> billingDTOList = saleService.getBillingsOfSale(billingFilter).getDecoratedBillings();
		
		Assert.assertEquals("Correct number of billing", 1, billingDTOList.size());
		
		Billing billing = billingDTOList.get(0).getBilling();
		return billing;
	}
	
	private Sale saveSaleForSuperUser(Sale sale) throws BusinessException {
		UserDecorator participantUser = getUserDecoratorBy(accessControlTestFixture.itsParticipantUser,systemTestFixture.soy);
		
		saleService.save(sale, participantUser);
		return sale;
	}
	
	private Billing createBilletBilling() throws BusinessException {
		Sale sale = saleFactory.createSale(saleTestFixture.matrixCargil, saleTestFixture.chicoBento, SaleTypeEnum.SALE_SEED);
		sale.setState(systemTestFixture.matoGrossoDoSul);
		
		SaleItem saleItemFix = saleItemFactory
				.createFixValueItem(saleTestFixture.productIntactaSoy,
						saleTestFixture.templateIntactaFixRRRangeBtNoValue,
						saleTestFixture.headOfficeCargil, 2L);
		
		sale.addItem(saleItemFix);
		saveSaleForSuperUser(sale);
		
		UserDecorator loggedSuperUser = accessControlTestFixture.superUser;
		loggedSuperUser.setContextCrop(systemTestFixture.soy);
		
		BillingFilter billingFilter = BillingFilter.getInstance()
				.add(sale.getId())
				.add((UserContext)loggedSuperUser);
		
		List<BillingDTO> billingDTOList = saleService.getBillingsOfSale(billingFilter).getDecoratedBillings();
		
		Assert.assertEquals("Correct number of billing", 1, billingDTOList.size());
		
		Billing billing = billingDTOList.get(0).getBilling();
		saveAndFlush(billing);
		
		saleService.payBillingOfBillet(billing,  SaleTestFixture.JANUARY, BigDecimal.TEN, BigDecimal.TEN, BigDecimal.TEN);
		return billing;
	}
	
	private UserDecorator getUserDecoratorBy (ItsUser user, Crop crop) throws BusinessException{
		UserDecorator userDecorator = userService.getAuthenticatedUserBy(accessControlTestFixture.itsParticipantUser.getLogin());
		userDecorator.setContextCrop(crop);
		return userDecorator;
	}
    
    @Test
	public void given_a_billing_paid_with_chargeConsolidate_when_cancel_billing_should_no_chargeConsolidate() throws BusinessException {
    	Billing billing = createAndPayManuallyBillingWithSaleItemsThatHaveFees();
		
		List<ChargeConsolidate> chargeConsolidateList = chargeConsolidateService.findCreditConsumptionChargeConsolidate(new ChargeConsolidateFilter());
		Assert.assertEquals("Should have only one ChargeConsolidate", 1, chargeConsolidateList.size());
		
		ChargeConsolidate chargeConsolidate = chargeConsolidateList.iterator().next();
		Assert.assertEquals("ChargeConsolidate value should be 1", BigDecimal.ONE.setScale(2), chargeConsolidate.getChargeConsolidateValue());
		
		getSession().clear();
		
		chargeConsolidateManager.deleteOrUpdateAfterCancelBilling(billing);
		
		ChargeConsolidateFilter filter = new ChargeConsolidateFilter();
		filter.setMatrix(saleTestFixture.matrixCargil);
		chargeConsolidateList = chargeConsolidateService.findCreditConsumptionChargeConsolidate(filter);
		Assert.assertEquals("Should no ChargeConsolidate", 0, chargeConsolidateList.size());
	}
    
    
    @Test
	public void given_two_billings_paid_with_chargeConsolidate_when_cancel_only_one_billing_should_one_chargeHandleCode() throws BusinessException {
    	Billing billing1 = createAndPayManuallyBillingWithSaleItemsThatHaveFees();
    	createAndPayManuallyBillingWithSaleItemsThatHaveFees();		
    	getSession().flush();
    	
		List<ChargeConsolidate> chargeConsolidateList = chargeConsolidateService.findCreditConsumptionChargeConsolidate(new ChargeConsolidateFilter());
		ChargeConsolidate chargeConsolidate = chargeConsolidateList.iterator().next();
		Assert.assertEquals("Should have only one ChargeConsolidate", 1, chargeConsolidateList.size());
		Assert.assertEquals("Should have two ChargeHandleCode", 2, chargeConsolidate.getChargeHandleCode().size());
		
		Assert.assertEquals("ChargeConsolidate value should be 2", new BigDecimal("2").setScale(2), chargeConsolidate.getChargeConsolidateValue());
		
		getSession().clear();
		
		chargeConsolidateManager.deleteOrUpdateAfterCancelBilling(billing1);
		
		ChargeConsolidateFilter filter = new ChargeConsolidateFilter();
		filter.setMatrix(saleTestFixture.matrixCargil);
		chargeConsolidateList = chargeConsolidateService.findCreditConsumptionChargeConsolidate(filter);
		Assert.assertEquals("Should have  ChargeConsolidate", 1, chargeConsolidateList.size());
		chargeConsolidate = chargeConsolidateList.iterator().next();
		Assert.assertEquals("Should have one ChargeHandleCode", 1, chargeConsolidate.getChargeHandleCode().size());
		Assert.assertEquals("ChargeConsolidate value should be 1", new BigDecimal("1").setScale(2), chargeConsolidate.getChargeConsolidateValue());
	}
    
    
    @Test
	public void given_two_billings_paid_with_chargeConsolidate_when_cancel_two_billing_should_one_chargeHandleCode() throws BusinessException {
    	Billing billing1 = createAndPayManuallyBillingWithSaleItemsThatHaveFees();
    	Billing billing2 = createAndPayManuallyBillingWithSaleItemsThatHaveFees();		
    	getSession().flush();
    	
		List<ChargeConsolidate> chargeConsolidateList = chargeConsolidateService.findCreditConsumptionChargeConsolidate(new ChargeConsolidateFilter());
		ChargeConsolidate chargeConsolidate = chargeConsolidateList.iterator().next();
		Assert.assertEquals("Should have only one ChargeConsolidate", 1, chargeConsolidateList.size());
		Assert.assertEquals("Should have two ChargeHandleCode", 2, chargeConsolidate.getChargeHandleCode().size());
		
		Assert.assertEquals("ChargeConsolidate value should be 2", new BigDecimal("2").setScale(2), chargeConsolidate.getChargeConsolidateValue());
				
		chargeConsolidateManager.deleteOrUpdateAfterCancelBilling(billing1);
    	
		ChargeConsolidateFilter filter = new ChargeConsolidateFilter();
		filter.setMatrix(saleTestFixture.matrixCargil);
		chargeConsolidateList = chargeConsolidateService.findCreditConsumptionChargeConsolidate(filter);
		Assert.assertEquals("Should have  ChargeConsolidate", 1, chargeConsolidateList.size());
		chargeConsolidate = chargeConsolidateList.iterator().next();
		Assert.assertEquals("Should have one ChargeHandleCode", 1, chargeConsolidate.getChargeHandleCode().size());
		Assert.assertEquals("ChargeConsolidate value should be 1", new BigDecimal("1").setScale(2), chargeConsolidate.getChargeConsolidateValue());
		
		chargeConsolidateManager.deleteOrUpdateAfterCancelBilling(billing2);

		chargeConsolidateList = chargeConsolidateService.findCreditConsumptionChargeConsolidate(filter);
		Assert.assertEquals("Should have  ChargeConsolidate", 0, chargeConsolidateList.size());
		
	}
    
    
    
}
