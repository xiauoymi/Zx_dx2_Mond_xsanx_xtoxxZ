package com.monsanto.brazilvaluecapture.seedsale.saleWizard.service;

import org.junit.Test;

import static org.junit.Assert.assertEquals;

/**
 * Created with IntelliJ IDEA.
 * User: JFVERO
 * Date: 16/01/14
 * Time: 11:45
 */
public class ExceededMaximumTonsException_UT {

    @Test
    public void testConstructor() {
        Exception ex = new ExceededMaximumTonsException("blah");

        assertEquals("blah", ex.getMessage());
    }

}