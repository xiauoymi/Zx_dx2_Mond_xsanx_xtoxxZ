package com.monsanto.brazilvaluecapture.seedsale.sale.report;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.math.BigDecimal;
import java.nio.charset.Charset;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.ResourceBundle;

import com.monsanto.brazilvaluecapture.core.regionalization.VCCountry;
import junit.framework.Assert;

import org.apache.commons.lang3.StringUtils;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.csvreader.CsvReader;
import com.monsanto.brazilvaluecapture.core.base.SystemTestFixture;
import com.monsanto.brazilvaluecapture.core.foundation.service.BusinessException;
import com.monsanto.brazilvaluecapture.core.foundation.test.AbstractServiceIntegrationTests;
import com.monsanto.brazilvaluecapture.core.user.AccessControlTestFixture;
import com.monsanto.brazilvaluecapture.core.user.model.bean.HierarchyLevel;
import com.monsanto.brazilvaluecapture.core.user.model.bean.UserContext;
import com.monsanto.brazilvaluecapture.core.user.model.bean.UserContract;
import com.monsanto.brazilvaluecapture.core.user.model.bean.UserDecorator;
import com.monsanto.brazilvaluecapture.seedsale.billing.model.bean.BillingDTO;
import com.monsanto.brazilvaluecapture.seedsale.billing.model.bean.PaymentStatusGroup.PaymentStatusAll;
import com.monsanto.brazilvaluecapture.seedsale.billing.model.dao.BillingFilter;
import com.monsanto.brazilvaluecapture.seedsale.billing.service.BillingConstraintViolationException;
import com.monsanto.brazilvaluecapture.seedsale.quota.report.EmptyReportException;
import com.monsanto.brazilvaluecapture.seedsale.sale.SaleTestFixture;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.Sale;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.dao.AbstractSeedSaleReportFilter;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.dao.ConsolidateReportSaleFilter;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.dao.ReportSaleFilter;
import com.monsanto.brazilvaluecapture.seedsale.sale.service.PlantabilitiesSelector;
import com.monsanto.brazilvaluecapture.seedsale.sale.service.SaleBuilder;
import com.monsanto.brazilvaluecapture.seedsale.sale.service.SaleConstraintViolationException;
import com.monsanto.brazilvaluecapture.seedsale.sale.service.SaleService;

public class SeedSaleReportAssembler_AT extends AbstractServiceIntegrationTests {

    @Autowired
    private SaleService saleService;
    @Autowired
    private SeedSaleReportBuilder seedSaleReportBuilder;

    private SaleBuilder builder;

    private AccessControlTestFixture accessControlIntent;

    private ResourceBundle resourceBundle = resourceBundle = ResourceBundle.getBundle("language", VCCountry.BRAZIL.getLocale());
    private static final Date EPOCH = new Date(0L);

    @Before
    public void init() throws BusinessException {
        systemTestFixture = new SystemTestFixture(this);
        accessControlTestFixture = new AccessControlTestFixture(systemTestFixture);
        accessControlIntent = new AccessControlTestFixture(this, systemTestFixture);
        saleTestFixture = new SaleTestFixture(this, systemTestFixture);
        // saleItemFactory =
        // SaleItemFactory.getInstance(systemTestFixture.matoGrossoDoSul,
        // saleTestFixture.plantabilitiesSelector);

        UserDecorator loggedSuperUser = accessControlIntent.superUser;
        loggedSuperUser.setContextCrop(systemTestFixture.soyMons4nto);
        loggedSuperUser.setContextCompany(systemTestFixture.mons4ntoBr);
        loggedSuperUser.addCompany(systemTestFixture.mons4ntoBr);

        builder = new SaleBuilder(systemTestFixture.matoGrossoDoSul, saleTestFixture.plantabilitiesSelectorMons4nto);
        createChargeConsolidateTypes();
    }

    @Test
    public void sanityCheck() throws NoSuchMethodException {
        SeedSaleReportAssembler.buildAssembler(Arrays.asList(new SeedSaleReportDTO[] {}), ReportOutputTypeEnum.XLS);
    }

    @Test
    public void given_one_sale_when_query_and_feed_into_DTO_then_should_return_one_entry()
            throws SaleConstraintViolationException {
        createASale("12345");
        getSession().flush();

        List<SeedSaleReportDTO> sales = saleService.getSalesBy(ReportSaleFilter.getInstance(
                accessControlIntent.superUser, systemTestFixture.mons4ntoBr).addCreationDateStart(EPOCH));
        Assert.assertEquals("Should have one row", 1, sales.size());

        Assert.assertEquals("Should have one row", 1, sales.size());
    }

    @Test
    public void given_one_sale_with_multiple_sale_items_when_query_and_feed_into_DTO_then_should_return_3_entries()
            throws SaleConstraintViolationException {
        createASaleWithMultipleSaleItems("12345");
        getSession().flush();

        List<SeedSaleReportDTO> sales = saleService.getSalesBy(ReportSaleFilter.getInstance(
                accessControlIntent.superUser, systemTestFixture.mons4ntoBr).addCreationDateStart(EPOCH));
        Assert.assertEquals("Should have one row", 3, sales.size());
    }

    @Test
    public void given_one_sale_with_multiple_sale_items_when_query_and_feed_into_DTO_and_generate_report_then_should_have_3_rows()
            throws SaleConstraintViolationException, NoSuchMethodException, IOException {
        createASaleWithMultipleSaleItems("12345");
        getSession().flush();

        List<SeedSaleReportDTO> sales = saleService.getSalesBy(ReportSaleFilter.getInstance(
                accessControlIntent.superUser, systemTestFixture.mons4ntoBr).addCreationDateStart(EPOCH));
        Assert.assertEquals("Should have one row", 3, sales.size());
        SeedSaleReportAssembler assembler = SeedSaleReportAssembler.buildAssembler(sales, ReportOutputTypeEnum.XLS);
        ByteArrayOutputStream stream = assembler.build(resourceBundle);
        assertSheetAndVerifyBlank(stream, 3, 50, false);
    }

    @Test
    public void given_one_sale_when_query_then_pay_and_query_again_then_values_should_change()
            throws SaleConstraintViolationException, NoSuchMethodException, IOException, BusinessException {
        Sale sale = createASale("12345");

        List<SeedSaleReportDTO> sales = saleService.getSalesBy(ReportSaleFilter.getInstance(
                accessControlIntent.superUser, systemTestFixture.mons4ntoBr).addCreationDateStart(EPOCH));
        Assert.assertEquals("Should have one row", 1, sales.size());

        Assert.assertEquals("Should have one row", 1, sales.size());
        SeedSaleReportDTO dto = sales.get(0);

        Assert.assertEquals("Should be april", SaleTestFixture.APRIL, dto.getDueDate());
        assertReceivedValues(dto, BigDecimal.ZERO, BigDecimal.ZERO, BigDecimal.ZERO);

        Date nowDate = new Date();

        payBilling(sale, nowDate, 1400d, false);
        sales = saleService.getSalesBy(ReportSaleFilter.getInstance(accessControlIntent.superUser,
                systemTestFixture.mons4ntoBr).addCreationDateStart(EPOCH));
        Assert.assertEquals("Should have one row", 1, sales.size());
        dto = sales.get(0);
        Assert.assertEquals("Should be now", sale.getItems().iterator().next().getBilling().getPossiblePaymentPaid()
                .getReceiptDate(), dto.getDueDate());
        assertReceivedValues(dto, BigDecimal.valueOf(2000d), BigDecimal.valueOf(1400d), BigDecimal.valueOf(1010000d));

    }

    @Test
    public void given_one_sale_partially_paid_when_generate_report_lines_should_show_partial_amounts()
            throws SaleConstraintViolationException, BusinessException {
        Sale sale = createASale("12345");

        List<SeedSaleReportDTO> sales = saleService.getSalesBy(ReportSaleFilter.getInstance(
                accessControlIntent.superUser, systemTestFixture.mons4ntoBr).addCreationDateStart(EPOCH));

        Assert.assertEquals("Should have one row", 1, sales.size());
        SeedSaleReportDTO dto = sales.get(0);

        Assert.assertEquals("Should be april", SaleTestFixture.APRIL, dto.getDueDate());
        assertReceivedValues(dto, BigDecimal.ZERO, BigDecimal.ZERO, BigDecimal.ZERO);

        Date nowDate = new Date();
        payBilling(sale, nowDate, 700d, false);
        sales = saleService.getSalesBy(ReportSaleFilter.getInstance(accessControlIntent.superUser,
                systemTestFixture.mons4ntoBr).addCreationDateStart(EPOCH));
        Assert.assertEquals("Should have one row", 1, sales.size());
        dto = sales.get(0);
        Assert.assertEquals("Should be now", sale.getItems().iterator().next().getBilling().getPossiblePaymentPaid()
                .getReceiptDate(), dto.getDueDate());
        assertReceivedValues(dto, BigDecimal.valueOf(1000d), BigDecimal.valueOf(700d), BigDecimal.valueOf(505000d));
    }

    @Test(expected = com.monsanto.brazilvaluecapture.seedsale.sale.report.SeedSaleConstraintException.class)
    public void given_one_sale_unpaid_when_use_filter_with_no_date_then_should_receive_constraint_exception()
            throws SaleConstraintViolationException, EmptyReportException, SeedSaleConstraintException,
            NoSuchMethodException, IOException {
        createASale("12345");
        seedSaleReportBuilder.clear();
        seedSaleReportBuilder.loadRecords(SaleReportType.SALE,
                ReportSaleFilter.getInstance(accessControlIntent.superUser, systemTestFixture.mons4ntoBr),
                resourceBundle);
        seedSaleReportBuilder.buildReportFor(SaleReportType.SALE, resourceBundle);
    }

    @Test(expected = com.monsanto.brazilvaluecapture.seedsale.sale.report.SeedSaleConstraintException.class)
    public void given_no_sales_when_use_filter_then_should_receive_empty_report_exception()
            throws SaleConstraintViolationException, EmptyReportException, SeedSaleConstraintException,
            NoSuchMethodException, IOException {
        seedSaleReportBuilder.clear();
        seedSaleReportBuilder.loadRecords(SaleReportType.SALE,
                ReportSaleFilter.getInstance(accessControlIntent.superUser, systemTestFixture.mons4ntoBr)
                        .addCreationDateStart(EPOCH), resourceBundle);
        seedSaleReportBuilder.buildReportFor(SaleReportType.SALE, resourceBundle);
    }

    @Test
    public void given_one_sale_partially_paid_when_generateDetailedReport_should_return_paymentInfo()
            throws SaleConstraintViolationException, NoSuchMethodException, IOException, BusinessException {
        Sale sale = createASale("54321");
        payBilling(sale, SaleTestFixture.DATE_NOW, 10L, false);

        List<SeedSaleReportDTO> sales = saleService.getSalesBy(ReportSaleFilter.getInstance(
                accessControlIntent.superUser, systemTestFixture.mons4ntoBr).addCreationDateStart(EPOCH));

        SeedSaleDetailedReportAssembler assembler = SeedSaleDetailedReportAssembler.buildAssembler(sales,
                ReportOutputTypeEnum.XLS);
        ByteArrayOutputStream outputStream = assembler.build(resourceBundle);
        assertSheetAndVerifyValue(outputStream, 1, 52, 10L);
    }

    @Test
    public void given_one_sale_unpaid_when_use_filter_then_should_receive_one_row()
            throws SaleConstraintViolationException, EmptyReportException, SeedSaleConstraintException,
            NoSuchMethodException, IOException {
        createASale("12345");
        seedSaleReportBuilder.clear();
        AbstractSeedSaleReportFilter filter = ReportSaleFilter
                .getInstance(accessControlIntent.superUser, systemTestFixture.mons4ntoBr)
                .addCreationDateStart(SaleTestFixture.DATE_YESTERDAY).addCreationDateEnd(SaleTestFixture.DATE_TOMORROW);
        seedSaleReportBuilder.loadRecords(SaleReportType.SALE, filter, resourceBundle);
        ByteArrayOutputStream stream = seedSaleReportBuilder.buildReportFor(SaleReportType.SALE, resourceBundle);
        assertSheetAndVerifyBlank(stream, 1, 51, false);
    }

    @Test
    public void given_one_sale_unpaid_when_use_filter_then_should_receive_one_row_in_csv()
            throws SaleConstraintViolationException, EmptyReportException, SeedSaleConstraintException,
            NoSuchMethodException, IOException {
        createASale("12345");
        seedSaleReportBuilder.clear();
        AbstractSeedSaleReportFilter filter = ReportSaleFilter
                .getInstance(accessControlIntent.superUser, systemTestFixture.mons4ntoBr)
                .addCreationDateStart(SaleTestFixture.DATE_YESTERDAY).addCreationDateEnd(SaleTestFixture.DATE_TOMORROW);
        seedSaleReportBuilder.loadRecords(SaleReportType.SALE, filter, resourceBundle);
        if (ReportOutputTypeEnum.XLS.equals(seedSaleReportBuilder.getReportOutputType())) {
            seedSaleReportBuilder.setReportOutputType(ReportOutputTypeEnum.CSV);
        }
        ByteArrayOutputStream report = seedSaleReportBuilder.buildReportFor(SaleReportType.SALE, resourceBundle);
        InputStream inputStream = new ByteArrayInputStream(report.toByteArray());
        CsvReader csv = new CsvReader(inputStream, Charset.forName("Windows-1252"));
        csv.readHeaders();
        String[] cols = null;
        while (csv.readRecord()) {
            cols = csv.get(0).split(";");
        }
        Assert.assertEquals("Cell value should be ZERO", "0", cols[53]);
    }

    @Test
    public void given_one_paidSale_when_use_filter_then_should_receive_one_detailed_row()
            throws SaleConstraintViolationException, EmptyReportException, SeedSaleConstraintException,
            NoSuchMethodException, IOException, BusinessException {
        Sale sale = createASale("67890");
        payBilling(sale, SaleTestFixture.DATE_NOW, 100L, false);
        seedSaleReportBuilder.clear();
        AbstractSeedSaleReportFilter filter = ReportSaleFilter.getInstance(accessControlIntent.superUser,
                systemTestFixture.mons4ntoBr).addCreationDateStart(EPOCH);
//        mockLoadGrowersAndCustomers(sale, filter);
        seedSaleReportBuilder.loadRecords(SaleReportType.DETAILED, filter, resourceBundle);
        ByteArrayOutputStream stream = seedSaleReportBuilder.buildReportFor(SaleReportType.DETAILED, resourceBundle);
        assertSheetAndVerifyValue(stream, 1, 52, 100L);
    }

    @Test
    public void given_one_paidSale_when_use_filter_then_should_receive_one_detailed_row_in_csv()
            throws SaleConstraintViolationException, EmptyReportException, SeedSaleConstraintException,
            NoSuchMethodException, IOException, BusinessException {
        Sale sale = createASale("67890");
        payBilling(sale, SaleTestFixture.DATE_NOW, 100L, false);
        seedSaleReportBuilder.clear();
        AbstractSeedSaleReportFilter filter = ReportSaleFilter.getInstance(accessControlIntent.superUser,
                systemTestFixture.mons4ntoBr).addCreationDateStart(EPOCH);
//        mockLoadGrowersAndCustomers(sale, filter);
        seedSaleReportBuilder.loadRecords(SaleReportType.DETAILED, filter, resourceBundle);
        if (ReportOutputTypeEnum.XLS.equals(seedSaleReportBuilder.getReportOutputType())) {
            seedSaleReportBuilder.setReportOutputType(ReportOutputTypeEnum.CSV);
        }
        ByteArrayOutputStream report = seedSaleReportBuilder.buildReportFor(SaleReportType.DETAILED, resourceBundle);
        InputStream inputStream = new ByteArrayInputStream(report.toByteArray());
        CsvReader csv = new CsvReader(inputStream, Charset.forName("Windows-1252"));
        csv.readHeaders();
        String[] cols = null;
        while (csv.readRecord()) {
            cols = csv.get(0).split(";");
        }
        Assert.assertEquals("Cell value should be 100.00", "100.00", cols[52]);
    }

    @Test(expected = EmptyReportException.class)
    public void given_one_not_paid_sale_when_generate_report_should_not_have_any_rows()
            throws SaleConstraintViolationException, EmptyReportException, SeedSaleConstraintException,
            NoSuchMethodException, IOException {
        createASale("123213");
        AbstractSeedSaleReportFilter filter = ReportSaleFilter.getInstance(accessControlIntent.superUser,
                systemTestFixture.mons4ntoBr).addCreationDateStart(EPOCH);
        filter.addPaymentStatus(Arrays.asList(PaymentStatusAll.PARCIAL_PAID, PaymentStatusAll.FULLY_PAID));
        seedSaleReportBuilder.clear();
        seedSaleReportBuilder.loadRecords(SaleReportType.CONSOLIDATED, filter, resourceBundle);
        seedSaleReportBuilder.buildReportFor(SaleReportType.CONSOLIDATED, resourceBundle);
    }

    @Test(expected = IllegalArgumentException.class)
    public void given_generateReportBuildFor_consolidated_when_paymentStatus_not_added_then_should_throw_exception()
            throws EmptyReportException, SeedSaleConstraintException, NoSuchMethodException, IOException {
        seedSaleReportBuilder.clear();
        seedSaleReportBuilder.loadRecords(SaleReportType.CONSOLIDATED,
                ConsolidateReportSaleFilter.getInstance(accessControlIntent.superUser, systemTestFixture.mons4ntoBr),
                resourceBundle);
        seedSaleReportBuilder.buildReportFor(SaleReportType.CONSOLIDATED, resourceBundle);
    }

    @Test(expected = IllegalArgumentException.class)
    public void given_generateReportBuildFor_consolidated_when_paymentStatus_not_valid_then_should_throw_exception()
            throws EmptyReportException, SeedSaleConstraintException, NoSuchMethodException, IOException {
        ConsolidateReportSaleFilter filter = ConsolidateReportSaleFilter.getInstance(accessControlIntent.superUser,
                systemTestFixture.mons4ntoBr);
        filter.addPaymentStatus(Arrays.asList(PaymentStatusAll.CANCELLED, PaymentStatusAll.NO_VALUE,
                PaymentStatusAll.NOT_PAID));
        seedSaleReportBuilder.clear();
        seedSaleReportBuilder.loadRecords(SaleReportType.CONSOLIDATED, filter, resourceBundle);
        seedSaleReportBuilder.buildReportFor(SaleReportType.CONSOLIDATED, resourceBundle);
    }

    @Test
    public void given_one_paid_sale_when_generate_consolidatedReport_should_return_one_row_in_xls()
            throws SaleConstraintViolationException, EmptyReportException, SeedSaleConstraintException,
            NoSuchMethodException, IOException, BusinessException {
        Sale sale = createASale("123123");
        payBilling(sale, EPOCH, 10L, true);
        ConsolidateReportSaleFilter filter = (ConsolidateReportSaleFilter) ConsolidateReportSaleFilter.getInstance(
                accessControlIntent.superUser, systemTestFixture.mons4ntoBr).addCreationDateStart(EPOCH);
        filter.addPaymentStatus(Arrays.asList(PaymentStatusAll.FULLY_PAID, PaymentStatusAll.PARCIAL_PAID));

        seedSaleReportBuilder.clear();
//        mockLoadGrowersAndCustomers(sale, filter);
        seedSaleReportBuilder.loadRecords(SaleReportType.CONSOLIDATED, filter, resourceBundle);
        ByteArrayOutputStream report = seedSaleReportBuilder
                .buildReportFor(SaleReportType.CONSOLIDATED, resourceBundle);
        assertSheetAndVerifyValue(report, 1, 36, 2600L);
        assertSheetAndVerifyValue(report, 1, 37, 1010000L);
        assertSheetAndVerifyValue(report, 1, 38, 8L);
        assertSheetAndVerifyValue(report, 1, 39, 10d);
    }

    @Test
    public void given_one_paid_sale_when_generate_consolidatedReport_should_return_one_row_in_csv()
            throws SaleConstraintViolationException, EmptyReportException, SeedSaleConstraintException,
            NoSuchMethodException, IOException, BusinessException {
        Sale sale = createASale("123123");
        payBilling(sale, EPOCH, 10L, true);
        ConsolidateReportSaleFilter filter = (ConsolidateReportSaleFilter) ConsolidateReportSaleFilter.getInstance(
                accessControlIntent.superUser, systemTestFixture.mons4ntoBr).addCreationDateStart(EPOCH);
        filter.addPaymentStatus(Arrays.asList(PaymentStatusAll.FULLY_PAID, PaymentStatusAll.PARCIAL_PAID));

        seedSaleReportBuilder.clear();
        seedSaleReportBuilder.loadRecords(SaleReportType.CONSOLIDATED, filter, resourceBundle);
        if (ReportOutputTypeEnum.XLS.equals(seedSaleReportBuilder.getReportOutputType())) {
            seedSaleReportBuilder.setReportOutputType(ReportOutputTypeEnum.CSV);
        }
        ByteArrayOutputStream report = seedSaleReportBuilder
                .buildReportFor(SaleReportType.CONSOLIDATED, resourceBundle);
        InputStream inputStream = new ByteArrayInputStream(report.toByteArray());
        CsvReader csv = new CsvReader(inputStream, Charset.forName("Windows-1252"));
        csv.readHeaders();
        String[] cols = null;
        while (csv.readRecord()) {
            cols = csv.get(0).split(";");
        }
        Assert.assertEquals("", "2600.00", cols[36]);
        Assert.assertEquals("", "1010000", cols[37]);
        Assert.assertEquals("", "8", cols[38]);
        Assert.assertEquals("", "10.00", cols[39]);
    }

    @Test
    public void given_one_sale_with_multiple_itens_when_generate_consolidatedReport_should_return_one_row()
            throws SaleConstraintViolationException, EmptyReportException, SeedSaleConstraintException,
            NoSuchMethodException, IOException, BusinessException {
        Sale sale = createASaleWithMultipleSaleItems("12345");
        getSession().flush();
        payBilling(sale, EPOCH, 10L, true);
        ConsolidateReportSaleFilter filter = (ConsolidateReportSaleFilter) ConsolidateReportSaleFilter.getInstance(
                accessControlIntent.superUser, systemTestFixture.mons4ntoBr).addCreationDateStart(EPOCH);
        filter.addPaymentStatus(Arrays.asList(PaymentStatusAll.FULLY_PAID, PaymentStatusAll.PARCIAL_PAID));

        seedSaleReportBuilder.clear();
        seedSaleReportBuilder.loadRecords(SaleReportType.CONSOLIDATED, filter, resourceBundle);
        ByteArrayOutputStream report = seedSaleReportBuilder
                .buildReportFor(SaleReportType.CONSOLIDATED, resourceBundle);
        assertSheetAndVerifyValue(report, 1, 36, 2600L);
        assertSheetAndVerifyValue(report, 1, 37, 1010000L);
        assertSheetAndVerifyValue(report, 1, 38, 8L);
        assertSheetAndVerifyValue(report, 1, 39, 10d);
    }

    @Test
    public void given_one_paid_sale_with_two_items_same_saletemplate_and_different_matrix_when_generate_consolidatedReport_should_return_two_row()
            throws SaleConstraintViolationException, EmptyReportException, SeedSaleConstraintException,
            NoSuchMethodException, IOException, BusinessException {

        PlantabilitiesSelector plantabilities = new PlantabilitiesSelector(
                saleTestFixture.harvestSoyMonsanto2012.getPlantabilities(), systemTestFixture.matoGrossoDoSul);

        builder = new SaleBuilder(systemTestFixture.matoGrossoDoSul, plantabilities);

        builder.addSaleItem(saleTestFixture.productIntactaSoy, saleTestFixture.templateIntactaFixRRRangeBtNoValue,
                saleTestFixture.headOfficeCargil, 2000L, SaleTestFixture.TWO_POINT_FIVE_DOLLARS,
                saleTestFixture.plantabilitySystemSoyMonsanto2012, SaleTestFixture.APRIL);
        builder.addSaleItem(saleTestFixture.productCargilIntactaSoy,
                saleTestFixture.templateIntactaFixRRRangeBtNoValue, saleTestFixture.officeCustomer, 2000L,
                SaleTestFixture.TWO_POINT_FIVE_DOLLARS, saleTestFixture.plantabilitySystemSoyMonsanto2012,
                SaleTestFixture.APRIL);

        Sale sale = builder.setGrower(saleTestFixture.chicoBento).setCustomer(saleTestFixture.affiliate).buildSale();
        sale.setCreationDate(SaleTestFixture.DATE_NOW);
        sale.setSaleNote("HELLO");
        sale.setInvoiceNumber("12345");
        sale.setRegion(systemTestFixture.regionSaoPaulo2012);

        accessControlIntent.superUser.setContextCompany(systemTestFixture.monsantoBr);
        accessControlIntent.superUser.setContextCrop(systemTestFixture.soy);
        saleService.save(sale, accessControlIntent.superUser);

        payBilling(sale, EPOCH, 10L, true);
        ConsolidateReportSaleFilter filter = (ConsolidateReportSaleFilter) ConsolidateReportSaleFilter.getInstance(
                accessControlIntent.superUser, systemTestFixture.mons4ntoBr).addCreationDateStart(EPOCH);
        filter.addPaymentStatus(Arrays.asList(PaymentStatusAll.FULLY_PAID, PaymentStatusAll.PARCIAL_PAID));

        seedSaleReportBuilder.clear();
        seedSaleReportBuilder.loadRecords(SaleReportType.CONSOLIDATED, filter, resourceBundle);
        ByteArrayOutputStream report = seedSaleReportBuilder
                .buildReportFor(SaleReportType.CONSOLIDATED, resourceBundle);
        assertSheetAndVerifyValue(report, 1, 36, 20000L);
        assertSheetAndVerifyValue(report, 1, 37, 2020000L);
        assertSheetAndVerifyValue(report, 1, 38, 2d);
        assertSheetAndVerifyValue(report, 1, 39, 10d);

    }

    private void payBilling(Sale s, Date date, double amount, boolean payManually)
            throws BillingConstraintViolationException, BusinessException {
        BillingFilter billingFilter = BillingFilter.getInstance().add(s.getId())
                .add((UserContext) accessControlIntent.superUser);

        List<BillingDTO> billingDTOList = saleService.getBillingsOfSale(billingFilter).getDecoratedBillings();
        if (amount > 0d) {
            saleService.payBilling(billingDTOList.get(0).getBilling(), date, new BigDecimal(amount), payManually);
        }
    }

    private void assertReceivedValues(SeedSaleReportDTO dto, BigDecimal amountSeedReceived,
            BigDecimal valueTechnologyReceived, BigDecimal totalRoyaltyReleased) {
        Assert.assertTrue("Should be " + amountSeedReceived + ": " + dto.getAmountSeedReceived(),
                amountSeedReceived.compareTo(dto.getAmountSeedReceived()) == 0);
        Assert.assertTrue("Should be " + valueTechnologyReceived + ": " + dto.getValueTechnologyReceived(),
                valueTechnologyReceived.compareTo(dto.getValueTechnologyReceived().getAmount()) == 0);
        Assert.assertTrue("Should be " + totalRoyaltyReleased + ": " + dto.getTotalRoyaltyReleased(),
                totalRoyaltyReleased.compareTo(dto.getTotalRoyaltyReleased()) == 0);
    }

    private Sale createASale(String invoiceNumber) throws SaleConstraintViolationException {
        builder.clear();
        builder.addSaleItem(saleTestFixture.productIntactaSoyMons4nto,
                saleTestFixture.templateIntactaMons4ntoOnPayment, saleTestFixture.officeMons4nto, 2000L,
                SaleTestFixture.TWO_POINT_FIVE_DOLLARS, saleTestFixture.plantability45To54SoyMons4nto2012,
                SaleTestFixture.APRIL);

        Sale sale = builder.setGrower(saleTestFixture.chicoBento).setCustomer(saleTestFixture.matrixMons4nto)
                .buildSale();
        sale.setCreationDate(SaleTestFixture.DATE_NOW);
        sale.setRegion(systemTestFixture.regionSaoPaulo2012);
        if (invoiceNumber != null) {
            sale.setInvoiceNumber(invoiceNumber);
        }
        saleService.save(sale, getParticipantUser());

        return sale;
    }

    private Sale createASaleWithMultipleSaleItems(String invoiceNumber) throws SaleConstraintViolationException {
        builder.clear();
        builder.addSaleItem(saleTestFixture.productIntactaSoyMons4nto,
                saleTestFixture.templateIntactaMons4ntoOnPayment, saleTestFixture.officeMons4nto, 2000L,
                SaleTestFixture.TWO_POINT_FIVE_DOLLARS, saleTestFixture.plantability45To54SoyMons4nto2012,
                SaleTestFixture.APRIL);

        builder.addSaleItem(saleTestFixture.productRRSoyMons4nto, saleTestFixture.templateIntactaMons4ntoOnPayment,
                saleTestFixture.officeMons4nto, 2000L, SaleTestFixture.TWO_POINT_FIVE_DOLLARS,
                saleTestFixture.plantability45To54SoyMons4nto2012, SaleTestFixture.APRIL);

        builder.addSaleItem(saleTestFixture.productBTSoyMons4nto, saleTestFixture.templateIntactaMons4ntoOnPayment,
                saleTestFixture.officeMons4nto, 2000L, SaleTestFixture.TWO_POINT_FIVE_DOLLARS,
                saleTestFixture.plantability45To54SoyMons4nto2012, SaleTestFixture.APRIL);

        Sale sale = builder.setGrower(saleTestFixture.chicoBento).setCustomer(saleTestFixture.matrixMons4nto)
                .buildSale();
        sale.setCreationDate(SaleTestFixture.DATE_NOW);
        sale.setRegion(systemTestFixture.regionSaoPaulo2012);
        sale.setSaleNote("HELLO");

        if (invoiceNumber != null) {
            sale.setInvoiceNumber(invoiceNumber);
        }
        saleService.save(sale, getParticipantUser());

        return sale;
    }

    private UserDecorator getParticipantUser() {
        UserDecorator participantUser = accessControlIntent.participantUser;
        UserContract contractWithMons4nto = new UserContract(participantUser.getCurrentUser(),
                saleTestFixture.contractMons4nto, saleTestFixture.matrixMons4nto, HierarchyLevel.HEAD_OFFICE);
        saveAndFlush(contractWithMons4nto);

        participantUser.addUserContract(contractWithMons4nto);
        participantUser.setContextCrop(systemTestFixture.soyMons4nto);
        participantUser.addCompany(systemTestFixture.mons4ntoBr);

        return participantUser;
    }

    private void assertSheetAndVerifyBlank(ByteArrayOutputStream baos, int rowNum, int cellPosition, boolean isBlank)
            throws IOException {
        HSSFCell cell = assertOutputStreamAndGetCell(baos, rowNum, cellPosition);
        isBlankString(isBlank, cell);
    }

    private void assertSheetAndVerifyValue(ByteArrayOutputStream baos, int rowNum, int cellPosition,
            double expectedDouble) throws IOException {
        HSSFCell cell = assertOutputStreamAndGetCell(baos, rowNum, cellPosition);
        switch (cell.getCellType()) {
        case HSSFCell.CELL_TYPE_NUMERIC:
            Assert.assertEquals("Should have the expected value", expectedDouble, cell.getNumericCellValue());
            break;
        default:
            Assert.fail("Should have cell type numeric");
            break;
        }
    }

    private HSSFCell assertOutputStreamAndGetCell(ByteArrayOutputStream baos, int rowNum, int cellPosition)
            throws IOException {
        ByteArrayInputStream inputStream = new ByteArrayInputStream(baos.toByteArray());
        HSSFWorkbook hssfWorkbook = new HSSFWorkbook(inputStream);
        Assert.assertNotNull("workbook shouldn't be null", hssfWorkbook);
        HSSFSheet sheet = hssfWorkbook.getSheetAt(0);
        Assert.assertNotNull("Sheet shouldn't be null", sheet);
        HSSFRow row = sheet.getRow(rowNum);
        Assert.assertNotNull("Row shouldn't be null", row);
        HSSFCell cell = row.getCell(cellPosition);
        Assert.assertNotNull("Cell shouldn't be null", cell);
        return cell;
    }

    private void isBlankString(boolean isBlank, HSSFCell cell) {
        if (cell.getCellType() == Cell.CELL_TYPE_STRING) {
            if (isBlank) {
                Assert.assertTrue("This cell is blank", StringUtils.isBlank(cell.getStringCellValue()));
            } else {
                Assert.assertTrue("This cell is not blank", StringUtils.isNotBlank(cell.getStringCellValue()));
            }
        }

    }

}
