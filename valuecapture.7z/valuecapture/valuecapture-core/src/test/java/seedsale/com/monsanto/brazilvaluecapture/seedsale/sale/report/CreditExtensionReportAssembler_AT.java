package com.monsanto.brazilvaluecapture.seedsale.sale.report;

import com.monsanto.brazilvaluecapture.core.account.model.bean.CreditExtension;
import com.monsanto.brazilvaluecapture.core.account.model.dao.CreditExtensionFilter;
import com.monsanto.brazilvaluecapture.core.base.SystemTestFixture;
import com.monsanto.brazilvaluecapture.core.foundation.service.BusinessException;
import com.monsanto.brazilvaluecapture.core.foundation.test.AbstractServiceIntegrationTests;
import com.monsanto.brazilvaluecapture.core.grower.model.bean.Grower;
import com.monsanto.brazilvaluecapture.core.user.AccessControlTestFixture;
import com.monsanto.brazilvaluecapture.seedsale.quota.report.EmptyReportException;
import com.monsanto.brazilvaluecapture.seedsale.sale.SaleTestFixture;
import com.monsanto.brazilvaluecapture.seedsale.sale.report.CreditExtensionReportDTO.HasAttachment;
import junit.framework.Assert;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.ResourceBundle;

public class CreditExtensionReportAssembler_AT extends AbstractServiceIntegrationTests {

	@Autowired
	private CreditExtensionReportBuilder reportBuilder;
	
	private ResourceBundle resourceBundle = ResourceBundle.getBundle("bundle/bundle");
	
	CreditExtensionFilter filter = null;
	
	@Before
    public void init() throws BusinessException {
        systemTestFixture = new SystemTestFixture(this);
        accessControlTestFixture = new AccessControlTestFixture(systemTestFixture);
        saleTestFixture = new SaleTestFixture(this, systemTestFixture);
        filter = CreditExtensionFilter.getInstance(SaleTestFixture.DATE_NOW, SaleTestFixture.DATE_NOW);
    }
	
	@Test(expected=EmptyReportException.class)
	public void given_no_creditExtension_when_generate_report_should_throw_exception() throws EmptyReportException, NoSuchMethodException, IOException {
		reportBuilder.buildReportFor(filter, resourceBundle);
	}
	
	@Test
	public void given_creditExtended_when_generate_report_should_have_one_row() throws IOException, EmptyReportException, NoSuchMethodException {
		CreditExtension creditExtension = generateCreditExtended(saleTestFixture.chicoBento, SaleTestFixture.DATE_NOW);
		
		ByteArrayOutputStream stream = reportBuilder.buildReportFor(filter, resourceBundle);
		assertReportStream(creditExtension, stream, 1, HasAttachment.NO.getLabel());
	}
	
	@Test
	public void given_three_creditExtension_when_generate_report_should_return_orderedBy_creationDate() throws EmptyReportException, NoSuchMethodException, IOException {
		CreditExtension creditExtensionTomorrow = generateCreditExtended(saleTestFixture.chicoBento, SaleTestFixture.DATE_TOMORROW);
		CreditExtension creditExtensionTodayChico = generateCreditExtended(saleTestFixture.chicoBento, SaleTestFixture.DATE_NOW);
		CreditExtension creditExtensionTodayJoao = generateCreditExtended(saleTestFixture.joaoDaSilva, SaleTestFixture.DATE_NOW);
		
		ByteArrayOutputStream stream = reportBuilder.buildReportFor(CreditExtensionFilter.getInstance(SaleTestFixture.DATE_NOW, SaleTestFixture.DATE_TOMORROW), resourceBundle);
		assertReportStream(creditExtensionTodayChico, stream, 1, HasAttachment.NO.getLabel());
		assertReportStream(creditExtensionTodayJoao, stream, 2, HasAttachment.NO.getLabel());
		assertReportStream(creditExtensionTomorrow, stream, 3, HasAttachment.NO.getLabel());
	}
	
	private void assertReportStream(CreditExtension creditExtension, ByteArrayOutputStream stream, int rowNum, String hasAttachment) throws IOException {
		SimpleDateFormat sdf = new SimpleDateFormat(resourceBundle.getString("pattern.date"));
		String year = creditExtension.getOperationalYear().getYear();
        assertSheetAndVerifyValue(stream, rowNum, 0, Double.valueOf(year));
        assertSheetAndVerifyValue(stream, rowNum, 1, sdf.format(creditExtension.getCreationDate()));
		assertSheetAndVerifyValue(stream, rowNum, 2, creditExtension.getGrower().getDocument().getValueFormatted());
		assertSheetAndVerifyValue(stream, rowNum, 3, creditExtension.getGrower().getName());
        assertSheetAndVerifyValue(stream, rowNum, 4, creditExtension.getGrower().getBillingAddress().getState().getCode());
        assertSheetAndVerifyValue(stream, rowNum, 5, creditExtension.getGrower().getBillingAddress().getCity().getDescription());
		assertSheetAndVerifyValue(stream, rowNum, 6, creditExtension.getTechnology().getDescription());
		assertSheetAndVerifyValue(stream, rowNum, 7, creditExtension.getAmount().doubleValue());
		assertSheetAndVerifyValue(stream, rowNum, 8, creditExtension.getRequestDescription());
		assertSheetAndVerifyValue(stream, rowNum, 9, resourceBundle.getString(hasAttachment));
        assertSheetAndVerifyValue(stream, rowNum, 10, creditExtension.getRequesterLogin());
	}
	
	private void assertSheetAndVerifyValue(ByteArrayOutputStream baos, int rowNum, int cellPosition, Object expected) throws IOException {
    	HSSFCell cell = assertOutputStreamAndGetCell(baos, rowNum, cellPosition);
    	switch (cell.getCellType()) {
		case HSSFCell.CELL_TYPE_NUMERIC:
			Assert.assertEquals("Should have the expected value", expected, cell.getNumericCellValue());
			break;
		case HSSFCell.CELL_TYPE_STRING:
			Assert.assertEquals("Should have the expected value", expected, cell.getStringCellValue());
			break;
		default:
			Assert.fail("Should have cell type expected");
			break;
		}
    }
	
    private HSSFCell assertOutputStreamAndGetCell(ByteArrayOutputStream baos, int rowNum, int cellPosition) throws IOException {
		ByteArrayInputStream inputStream = new ByteArrayInputStream(baos.toByteArray());
    	HSSFWorkbook hssfWorkbook = new HSSFWorkbook(inputStream);
    	Assert.assertNotNull("workbook shouldn't be null", hssfWorkbook);
    	HSSFSheet sheet = hssfWorkbook.getSheetAt(0);
    	Assert.assertNotNull("Sheet shouldn't be null", sheet);
    	HSSFRow row = sheet.getRow(rowNum);
    	Assert.assertNotNull("Row shouldn't be null", row);
    	HSSFCell cell = row.getCell(cellPosition);
    	Assert.assertNotNull("Cell shouldn't be null", cell);
		return cell;
	}

	private CreditExtension generateCreditExtended(Grower grower, Date creationDate) {
		CreditExtension creditExtension = new CreditExtension("description", systemTestFixture.intacta, systemTestFixture.soy, systemTestFixture.operationalYearOf2012, grower, creationDate, "vrodrigues", BigDecimal.ONE);
		saveAndFlush(creditExtension);
		return creditExtension;
	}
}
