package com.monsanto.brazilvaluecapture.seedsale.template;

import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import junit.framework.Assert;

import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.hibernate.classic.Session;
import org.junit.Before;
import org.junit.Test;

import com.monsanto.brazilvaluecapture.core.grower.CreateTestData;
import com.monsanto.brazilvaluecapture.seedsale.harvest.HarvestTestData;
import com.monsanto.brazilvaluecapture.seedsale.product.ProductTestData;
import com.monsanto.brazilvaluecapture.seedsale.product.model.bean.Product;
import com.monsanto.brazilvaluecapture.seedsale.template.model.bean.SaleTemplate;
import com.monsanto.brazilvaluecapture.seedsale.template.model.bean.SaleTemplateToProduct;
import com.monsanto.brazilvaluecapture.seedsale.template.model.bean.SaleTemplateToProductPk;
import com.monsanto.brazilvaluecapture.seedsale.template.model.dao.SaleTemplateToProductDAO;
import com.monsanto.brazilvaluecapture.seedsale.template.model.dao.impl.SaleTemplateToProductDAOImpl;

public class SaleTemplateToProduct_UT extends CreateTestData{
	
	Session mockSession;
	SessionFactory mockSessionFactory;
	SaleTemplateToProductDAO saleTemplateToProductDAO;
	
	@Before
	public void setup() {
		mockSessionFactory = mock(SessionFactory.class);
		mockSession = mock(Session.class);
		when(mockSessionFactory.getCurrentSession()).thenReturn(mockSession);

		saleTemplateToProductDAO = new SaleTemplateToProductDAOImpl(mockSessionFactory);
	}
	
	@Test
	public void createObject() {
		
		SaleTemplateToProduct bean = new SaleTemplateToProduct();
		bean.setSaleTemplateToProductPk(new SaleTemplateToProductPk());
		bean.getSaleTemplateToProductPk().setProduct(null);
		bean.getSaleTemplateToProductPk().setSaleTemplate(null);
		
		Assert.assertNotNull(bean);
		Assert.assertNotNull(bean.getSaleTemplateToProductPk());
		Assert.assertNotNull(bean.getPrimaryKey());
		Assert.assertNull(bean.getSaleTemplateToProductPk().getPrimaryKey());
		Assert.assertNull(bean.getSaleTemplateToProductPk().getProduct());
		Assert.assertNull(bean.getSaleTemplateToProductPk().getSaleTemplate());
		
	}
	
	@Test
	public void insertSaleTemplateToProductTest() {

		when(mockSessionFactory.getCurrentSession()).thenReturn(mockSession);
		
		Product product = ProductTestData.createProduct();
		
		SaleTemplate template = SaleTemplateTestData.createSaleTemplateTypeSeedSale(HarvestTestData.createABrazilianHarvest());

		SaleTemplateToProduct bean = new SaleTemplateToProduct();
		bean.setSaleTemplateToProductPk(new SaleTemplateToProductPk());
		bean.getSaleTemplateToProductPk().setProduct(product);
		bean.getSaleTemplateToProductPk().setSaleTemplate(template);
		
		doNothing().when(mockSession).saveOrUpdate(bean);

		saleTemplateToProductDAO.save(bean);

		Assert.assertNotNull(bean);
		Assert.assertNotNull(bean.getSaleTemplateToProductPk());
		Assert.assertNotNull(bean.getSaleTemplateToProductPk().getProduct());
		Assert.assertNotNull(bean.getSaleTemplateToProductPk().getSaleTemplate());
	}
	
	@Test
	public void deleteSaleTemplateTest() {
		when(mockSessionFactory.getCurrentSession()).thenReturn(mockSession);
		
		Product product = ProductTestData.createProduct();
		
		SaleTemplate template = SaleTemplateTestData.createSaleTemplateTypeSeedSale(HarvestTestData.createABrazilianHarvest());
		
		SaleTemplateToProduct bean = new SaleTemplateToProduct();
		bean.setSaleTemplateToProductPk(new SaleTemplateToProductPk());
		bean.getSaleTemplateToProductPk().setProduct(product);
		bean.getSaleTemplateToProductPk().setSaleTemplate(template);
		
		SaleTemplateToProductPk pk = bean.getSaleTemplateToProductPk();

		doNothing().when(mockSession).saveOrUpdate(bean);

		saleTemplateToProductDAO.save(bean);

		doNothing().when(mockSession).delete(bean);

		saleTemplateToProductDAO.delete(bean);

		when(mockSession.get(SaleTemplate.class, pk)).thenReturn(null);

		Assert.assertNull(saleTemplateToProductDAO.selectById(pk));
	}
	
	@Test
	public void deleteAllProductSaleTemplateTest() {
		when(mockSessionFactory.getCurrentSession()).thenReturn(mockSession);
		
		Product product = ProductTestData.createProduct();
		
		SaleTemplate template = SaleTemplateTestData.createSaleTemplateTypeSeedSale(HarvestTestData.createABrazilianHarvest());

		SaleTemplateToProduct bean = new SaleTemplateToProduct();
		bean.setSaleTemplateToProductPk(new SaleTemplateToProductPk());
		bean.getSaleTemplateToProductPk().setProduct(product);
		bean.getSaleTemplateToProductPk().setSaleTemplate(template);
		
		SaleTemplateToProductPk pk = bean.getSaleTemplateToProductPk();

		doNothing().when(mockSession).saveOrUpdate(bean);

		saleTemplateToProductDAO.save(bean);

		Query mockQuery = mock(Query.class);
		
		when(mockSession.createQuery(anyString())).thenReturn(mockQuery);
		
		when(mockQuery.setEntity("param", template)).thenReturn(mockQuery);
		
		when(mockQuery.executeUpdate()).thenReturn(1);

		saleTemplateToProductDAO.deleteBySaleTemplate(template);

		when(mockSession.get(SaleTemplate.class, pk)).thenReturn(null);

		Assert.assertNull(saleTemplateToProductDAO.selectById(pk));
	}
	
	
	@Test
	public void selectAllTest() {
		
		Query mockQuery = mock(Query.class);
		
		when(mockSession.createQuery(anyString())).thenReturn(mockQuery);

		List<SaleTemplateToProduct> list = new ArrayList<SaleTemplateToProduct>();
		
		when(mockQuery.list()).thenReturn(list);

		List<SaleTemplateToProduct> list2 = saleTemplateToProductDAO.selectAll();

		// Then result is not null
		Assert.assertEquals(list, list2);

	}

}
