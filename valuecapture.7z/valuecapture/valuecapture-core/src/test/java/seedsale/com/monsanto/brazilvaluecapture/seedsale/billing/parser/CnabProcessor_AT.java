package com.monsanto.brazilvaluecapture.seedsale.billing.parser;

import static org.mockito.Mockito.stub;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.math.BigDecimal;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.monsanto.brazilvaluecapture.core.base.SystemTestFixture;
import com.monsanto.brazilvaluecapture.core.foundation.service.BusinessException;
import com.monsanto.brazilvaluecapture.core.foundation.test.AbstractServiceIntegrationTests;
import com.monsanto.brazilvaluecapture.core.foundation.test.dbunit.DbUnitHelper;
import com.monsanto.brazilvaluecapture.core.posting.model.bean.Posting;
import com.monsanto.brazilvaluecapture.core.posting.model.bean.PostingAccount;
import com.monsanto.brazilvaluecapture.core.revenue.model.bean.ChargeConsolidateType;
import com.monsanto.brazilvaluecapture.core.revenue.model.bean.ChargeConsolidateTypeEnum;
import com.monsanto.brazilvaluecapture.core.revenue.model.bean.CompanyCropAccountNumber;
import com.monsanto.brazilvaluecapture.core.revenue.service.ChargeConsolidateService;
import com.monsanto.brazilvaluecapture.seedsale.billing.model.bean.Billing;
import com.monsanto.brazilvaluecapture.seedsale.billing.service.BillingHelper;
import com.monsanto.brazilvaluecapture.seedsale.billing.service.impl.BillingIndexer;
import com.monsanto.brazilvaluecapture.seedsale.billing.service.parser.CnabImportedFile;
import com.monsanto.brazilvaluecapture.seedsale.billing.service.parser.CnabProcessor;
import com.monsanto.brazilvaluecapture.seedsale.product.model.bean.Product;
import com.monsanto.brazilvaluecapture.seedsale.sale.SaleTestFixture;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.SaleItem;
import com.monsanto.brazilvaluecapture.seedsale.sale.service.SaleItemFactory;
import com.monsanto.brazilvaluecapture.seedsale.template.model.bean.SaleTemplateBillingMethodEnum;

public class CnabProcessor_AT extends AbstractServiceIntegrationTests {

	@Autowired
	public CnabProcessor processor;
	
	private static BillingIndexer mockedBillingIndexer;
	private static BillingIndexer anotherMockedBillingIndexer;
	
	private static final String CNAB_HEADER = "02RETORNO01COBRANCA       31321000085006000000MONSANTO DO BRASIL LTDA       001BANCO DO BRASIL2001120001570                      000002434202650202  1204062                                                                                                                                                                                                                                              000001";
	private static final String CNAB_TRAIL = "9201001          000000000000000000000000000000          000000000000000000000000000000          000000000000000000000000000000          000000000000000000000000000000                                                  000000000000000000000000000000                                                                                                                                                   027814";
	private static final String CNAB_VALID_LINE   = "70000000000000000313210000850061204062                         1204062010142096310000001   01900000000000 1806200112                              000000000000050000000130376002301120000135000000000000000000000000000000000000000000000000000000000000000000000000500000000000000000000000000000000000000000000000000049986520000000000000          0000000000000000000000000000000000000000000000000001027790";
	private static final String CNAB_ANOTHER_VALID_LINE   = "70000000000000000313210000850061204062                         1204062010142096210000001   01900000000000 1806200112                              000000000000050000000130376002301120000135000000000000000000000000000000000000000000000000000000000000000000000000500000000000000000000000000000000000000000000000000049986520000000000000          0000000000000000000000000000000000000000000000000001027790";
	private static final Long CNAB_VALID_TRANSACTION_ID = new Long("0101420963");
	private static final Long CNAB_ANOTHER_VALID_TRANSACTION_ID = new Long("0101420962");

	@Autowired
	private ChargeConsolidateService chargeConsolidateService;
	
    private void loadChargeConsolidateTypes() {
    	CompanyCropAccountNumber cc = new CompanyCropAccountNumber(1L, systemTestFixture.monsantoBr, systemTestFixture.soy, new Long(999000011L));
    	saveAndFlush(cc);
    	
        Map<ChargeConsolidateTypeEnum, ChargeConsolidateType> map = chargeConsolidateService
                .findMapOfAllChargeConsolidateTypes();
        ChargeConsolidateTypeEnum[] values = ChargeConsolidateTypeEnum.values();

        long i = 0;
        for (ChargeConsolidateTypeEnum item : values) {
            if (!map.containsKey(item)) {
                ChargeConsolidateType type = new ChargeConsolidateType();
                type.setId(i);
                type.setChargeConsTypeCode(item);
                type.setChargeConsTypeBundle("bundle.teste");
                type.setCompanyCropAccountNumber(cc);
                type.setImported(item.isImported());
                type.setChargeConsolidateOrigin(item.getChargeConsOriginCode());
                saveAndFlush(type);

                i++;
            }
        }

    }
	
	@Test
	public void sanity_check() {
		Assert.assertNotNull("CnabProcessor should be a bean available in application context", processor);
	}
	
	@BeforeClass
	public static void onlyOnce() throws BusinessException {
		mockedBillingIndexer = BillingHelper.createBillingIndexer();
		stub(mockedBillingIndexer.getSaleCode()).toReturn(BillingHelper.MOCKED_SALE_CODE);
		stub(mockedBillingIndexer.getBillingMethod()).toReturn(SaleTemplateBillingMethodEnum.BANKSLIP);
		anotherMockedBillingIndexer = BillingHelper.createBillingIndexer();
		stub(anotherMockedBillingIndexer.getSaleCode()).toReturn(321L);
		stub(anotherMockedBillingIndexer.getBillingMethod()).toReturn(SaleTemplateBillingMethodEnum.BANKSLIP);
	}
	
	@Before
	public void init() {
		systemTestFixture = new SystemTestFixture(this);
		saleTestFixture = new SaleTestFixture(this, systemTestFixture);
		
		int postingAccounts = getSession().createCriteria(PostingAccount.class).list().size();
		if (postingAccounts == 0) {
			DbUnitHelper.setup("classpath:data/core/fixture-system-dataset.xml", "classpath:data/core/posting_account_posting_reference_dataset.xml");
		}
		
		loadChargeConsolidateTypes();
	}
	
	@Test
	public void given_two_billets_createdFromDifferentSales_should_have_summarizedTotals_per_techonology() throws NumberFormatException, IOException, BusinessException {
		createAndSaveBillingForTechnology(saleTestFixture.productIntactaSoy, CNAB_VALID_TRANSACTION_ID, mockedBillingIndexer);
		createAndSaveBillingForTechnology(saleTestFixture.productIntactaSoy, CNAB_ANOTHER_VALID_TRANSACTION_ID, anotherMockedBillingIndexer);
		
		StringBuffer cnab = createCnabFile(null, CNAB_ANOTHER_VALID_LINE, CNAB_TRAIL, CNAB_VALID_LINE, CNAB_TRAIL);
		CnabImportedFile cnabImportedFile = processor.read(new ByteArrayInputStream(cnab.toString().getBytes()));

		Assert.assertEquals("Should have the accumulated value for intacta", new BigDecimal(10000).setScale(2), cnabImportedFile.getTechnologyTotal(systemTestFixture.intacta));
		Assert.assertEquals("Should have the accumulated value in advance", BigDecimal.ZERO, cnabImportedFile.getAdvanceValue());
	}
	
	@Test
	public void given_two_cnabLines_for_sameTech_when_write_should_save_into_postings_one_registryOnly() throws IOException {
		createAndSaveBillingForTechnology(saleTestFixture.productIntactaSoy, CNAB_VALID_TRANSACTION_ID, mockedBillingIndexer);
		createAndSaveBillingForTechnology(saleTestFixture.productIntactaSoy, CNAB_ANOTHER_VALID_TRANSACTION_ID, anotherMockedBillingIndexer);
		StringBuffer cnab = createCnabFile(null, CNAB_ANOTHER_VALID_LINE, CNAB_TRAIL, CNAB_VALID_LINE, CNAB_TRAIL);
		CnabImportedFile cnabImportedFile = processor.read(new ByteArrayInputStream(cnab.toString().getBytes()));
		
		CnabImportedFile importedFile = processor.write(cnabImportedFile);
		
		@SuppressWarnings("unchecked")
		List<Posting> postings = getSession().createCriteria(Posting.class).list();
		
		Assert.assertEquals("Should have no errors", 0, importedFile.countErrors());
		Assert.assertEquals("Should have no warnings", 0, importedFile.countWarnings());
		Assert.assertEquals("Should have two success lines", 2, importedFile.countSuccess());
		Assert.assertEquals("Should have one registry in postings account", 1, postings.size());
	}
	
	@Test
	public void given_two_repeated_cnabLines_when_write_should_have_into_postings_two_registers() throws IOException {
		createAndSaveBillingForTechnology(saleTestFixture.productIntactaSoy, CNAB_VALID_TRANSACTION_ID, mockedBillingIndexer);
		StringBuffer cnab = createCnabFile(null, CNAB_VALID_LINE, CNAB_TRAIL, CNAB_VALID_LINE, CNAB_TRAIL);
		CnabImportedFile cnabImportedFile = processor.read(new ByteArrayInputStream(cnab.toString().getBytes()));
		
		CnabImportedFile importedFile = processor.write(cnabImportedFile);
		
		@SuppressWarnings("unchecked")
		List<Posting> postings = getSession().createCriteria(Posting.class).list();
		
		Assert.assertEquals("Should have no errors", 0, importedFile.countErrors());
		Assert.assertEquals("Should have one warning", 1, importedFile.countWarnings());
		Assert.assertEquals("Should have two success lines", 2, importedFile.countSuccess());
		Assert.assertEquals("Should have two registry in postings account", 2, postings.size());
	}
	
	private Billing createAndSaveBillingForTechnology(Product product, Long transactionId, BillingIndexer indexer) {
		SaleItemFactory saleItemFactory =  SaleItemFactory.getInstance(systemTestFixture.matoGrossoDoSul, saleTestFixture.plantabilitiesSelector);
		SaleItem saleItem =	saleItemFactory.createSaleItem(product, 
				saleTestFixture.templateFreeWithDueDateRange, 
				saleTestFixture.officeCustomer, 
				2000L, 
				SaleTestFixture.TWO_POINT_FIVE_DOLLARS, 
				saleTestFixture.plantabilitySystemSoyMonsanto2012, 
				SaleTestFixture.APRIL);

		saveAndFlush(saleItem);
		Set<SaleItem> saleItems = new HashSet<SaleItem>();
		saleItems.add(saleItem);
		Billing billing = new Billing(saleItems, indexer);
		billing.setTransactionNumber(transactionId);
		saveAndFlush(billing);
		return billing;
	}
	
	private StringBuffer createCnabFile(StringBuffer cnab, String... lines) {
        if(cnab==null) {
        	cnab = new StringBuffer(CNAB_HEADER);
        	cnab.append("\n");
        }
        for(int i=0;i<lines.length;++i) {            
            cnab.append(lines[i]);
            cnab.append("\n");
        }
        return cnab;
	}
	
}
