package com.monsanto.brazilvaluecapture.seedsale.bonus.payment.impl;

import com.monsanto.brazilvaluecapture.seedsale.bonus.payment.SaleItemTotalRoyaltyValueCalculator;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.SaleItem;
import org.junit.Test;

import java.math.BigDecimal;

import static org.junit.Assert.assertEquals;

public class MultiplierToGrowerSaleItemTotalRoyaltyValueCalculatorImpl_UT {

    private SaleItemTotalRoyaltyValueCalculator totalRoyaltyValueCalculator = new MultiplierToGrowerSaleItemTotalRoyaltyValueCalculatorImpl();

    @Test
    public void testCalculateTotalRoyaltyValueReturns120_whenTotalRoyaltyValueIs120() {
        //@Given
        SaleItem multiplierSaleItem = new SaleItem();
        multiplierSaleItem.setId(1L);
        multiplierSaleItem.setTotalRoyaltyValue(BigDecimal.valueOf(120));
        //@When
        BigDecimal actual = totalRoyaltyValueCalculator.calculateTotalRoyaltyValue(multiplierSaleItem);
        //@Then
        assertEquals(BigDecimal.valueOf(120).setScale(2), actual);
    }

}