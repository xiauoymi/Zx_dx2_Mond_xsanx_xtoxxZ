package com.monsanto.brazilvaluecapture.seedsale.quota.service.impl;

import com.monsanto.brazilvaluecapture.core.account.service.InsufficientBalanceException;
import com.monsanto.brazilvaluecapture.core.base.SystemTestFixture;
import com.monsanto.brazilvaluecapture.core.commercialhierarchy.model.bean.*;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Customer;
import com.monsanto.brazilvaluecapture.core.foundation.RandomTestData;
import com.monsanto.brazilvaluecapture.core.foundation.service.EntityNotFoundException;
import com.monsanto.brazilvaluecapture.core.foundation.service.IndustrySystemOperationException;
import com.monsanto.brazilvaluecapture.core.foundation.test.AbstractServiceIntegrationTests;
import com.monsanto.brazilvaluecapture.core.foundation.test.dbunit.DbUnitHelper;
import com.monsanto.brazilvaluecapture.core.foundation.util.security.EnvironmentSpecificPropertyReader;
import com.monsanto.brazilvaluecapture.core.regionalization.CountriesHolder;
import com.monsanto.brazilvaluecapture.core.user.AccessControlTestFixture;
import com.monsanto.brazilvaluecapture.core.user.model.bean.HierarchyLevel;
import com.monsanto.brazilvaluecapture.core.user.model.bean.UserDecorator;
import com.monsanto.brazilvaluecapture.core.user.service.UserAccessDeniedException;
import com.monsanto.brazilvaluecapture.core.user.service.UserNotFoundException;
import com.monsanto.brazilvaluecapture.core.user.service.UserService;
import com.monsanto.brazilvaluecapture.seedsale.product.model.bean.Product;
import com.monsanto.brazilvaluecapture.seedsale.quota.model.bean.Quota;
import com.monsanto.brazilvaluecapture.seedsale.quota.model.bean.QuotaEntry;
import com.monsanto.brazilvaluecapture.seedsale.quota.model.bean.QuotaReportExtractView;
import com.monsanto.brazilvaluecapture.seedsale.quota.model.bean.QuotaTransaction.QuotaTransactionType;
import com.monsanto.brazilvaluecapture.seedsale.quota.model.bean.QuotaType;
import com.monsanto.brazilvaluecapture.seedsale.quota.model.dao.QuotaDAO;
import com.monsanto.brazilvaluecapture.seedsale.quota.model.dao.QuotaExtractReportViewFilter;
import com.monsanto.brazilvaluecapture.seedsale.quota.model.dao.QuotaFilter;
import com.monsanto.brazilvaluecapture.seedsale.quota.service.QuotaControlService;
import com.monsanto.brazilvaluecapture.seedsale.quota.service.QuotaService;
import com.monsanto.brazilvaluecapture.seedsale.sale.SaleTestFixture;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.Sale;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.Sale.SaleTypeEnum;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.SaleItem;
import com.monsanto.brazilvaluecapture.seedsale.sale.service.SaleConstraintViolationException;
import com.monsanto.brazilvaluecapture.seedsale.sale.service.SaleService;
import com.monsanto.brazilvaluecapture.seedsale.sale.service.SaleTestData;
import org.apache.commons.lang3.time.DateUtils;
import org.hibernate.criterion.Restrictions;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import java.math.BigDecimal;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class QuotaService_AT extends AbstractServiceIntegrationTests {
    
    @Autowired
    private QuotaService quotaService;
    @Autowired
    private SaleService saleService;
    private SystemTestFixture systemTestFixture;
    private SaleTestFixture saleTestFixture;
    private AccessControlTestFixture accessControlTestFixture;
	private UserDecorator superUser;
	@Autowired
	private QuotaDAO quotaDAO;
	@Autowired
	private UserService userServices;
    @Autowired
    private CountriesHolder countriesHolder;
    @Autowired
	@Qualifier("currentQuotaControlImplementation")
    private QuotaControlService quotaControlService;

    private SaleTestData saleFactory;

    @Before
    public void init() {
		systemTestFixture = new SystemTestFixture(this);
		saleTestFixture = new SaleTestFixture(this, systemTestFixture);
		accessControlTestFixture = new AccessControlTestFixture(this, systemTestFixture);
		
		superUser = accessControlTestFixture.superUser;
		superUser.setContextCompany(saleTestFixture.officeMons4nto.getCompany());
		superUser.setContextCrop(saleTestFixture.officeMons4nto.getCrop());
		
		CommercialHierType commercialHierType = (CommercialHierType) getSession()
		.createCriteria(CommercialHierType.class, "c")
		.add(Restrictions
				.eq("c.commercialHierTypeDesc",
						CommercialHierarchyType.DISTRIBUTOR.getValue()))
		.uniqueResult();
		
		CommercialHierarchy cHier = new CommercialHierarchy();
		cHier.setCommercialHierarchyId(1L);
		cHier.setCommercialHierType(commercialHierType);
		cHier.setCompany(systemTestFixture.mons4ntoBr);
		cHier.setCrop(systemTestFixture.soyMons4nto);
		
		saveAndFlush(cHier);
		
		ItsUnity unit = new ItsUnity();
		unit.setActivitySector(RandomTestData.createRandomString(5));
		unit.setUnitySapDesc(RandomTestData.createRandomString(5));
		unit.setUnitySapId(RandomTestData.createRandomString(4));
		
		saveAndFlush(unit);
		
		ItsRegion region = new ItsRegion();
		region.setId(100000L);
		region.setActivitySector(RandomTestData.createRandomString(5));
		region.setItsUnity(unit);
		
		saveAndFlush(region);
		
		ItsDistrict district = new ItsDistrict();
		district.setId(10000L);
		district.setActivitySector(RandomTestData.createRandomString(5));
		district.setDistrictSapDesc(RandomTestData.createRandomString(5));
		district.setDistrictSapId(RandomTestData.createRandomString(4));
		district.setItsRegion(region);
		district.setItsUnity(unit);
		
		saveAndFlush(district);
		
		CustomerDistrict customerDistrict = new CustomerDistrict(10L,
				saleTestFixture.matrixMons4nto, commercialHierType, district, cHier);
//		customerDistrict.setCustomerDistrictId(10L);
//		customerDistrict.setCompany(systemTestFixture.mons4ntoBr);
//		customerDistrict.setCrop(systemTestFixture.soyMons4nto);
//		customerDistrict.setItsDistrict(district);
//		customerDistrict.setCustomer(saleTestFixture.matrixMons4nto);
//		customerDistrict.setCommercialHierType(commercialHierType);
		
		saveAndFlush(customerDistrict);
		
		CommercialHierType commercialHierTypeGERM = (CommercialHierType) getSession()
				.createCriteria(CommercialHierType.class, "c")
				.add(Restrictions
						.eq("c.commercialHierTypeDesc",
								CommercialHierarchyType.GERMPLASM.getValue()))
				.uniqueResult();
		
		CustomerDistrict customerDistrictGerm = new CustomerDistrict(10L,
				saleTestFixture.matrixMons4nto, commercialHierTypeGERM, district, cHier);
//		customerDistrictGerm.setCustomerDistrictId(100L);
//		customerDistrictGerm.setCompany(systemTestFixture.mons4ntoBr);
//		customerDistrictGerm.setCrop(systemTestFixture.soyMons4nto);
//		customerDistrictGerm.setItsDistrict(district);
//		customerDistrictGerm.setCustomer(saleTestFixture.matrixMons4nto);
//		customerDistrictGerm.setCommercialHierType(commercialHierTypeGERM);
		
		saveAndFlush(customerDistrictGerm);
		
		accessControlTestFixture.itsParticipantUser.addProfile(accessControlTestFixture.profileWithOneAction);
		
        saveAndFlush(accessControlTestFixture.itsParticipantUser);
        
		if (!getAssumptionTest().isEnvironmentWithSQLANSI()) {
			DbUnitHelper.setup("classpath:data/core/fixture-system-dataset.xml",
	                "classpath:data/core/participant-dataset.xml",
	                "classpath:data/commercialhierarchy/commercialhierarchy-dataset.xml");
			systemTestFixture.monsantoBr.setId(900000001L);
			systemTestFixture.soy.setDescription("SOJA");
			saleTestFixture.matrixCargil.setCustomerSAPCode("0001862846");
			saleTestFixture.productIntactaWithQuotaForReport.getTechnology().setDescription("_INTACTA_");
			saleTestFixture.productIntactaWithQuotaForReport.setId(21L);
        }

         //Added for LASVC to return a country brazil
         String configuredHost = "CONFIGURED_AND_REQUESTED_HOST_SAME";
		 EnvironmentSpecificPropertyReader env = mock(EnvironmentSpecificPropertyReader.class);
		 countriesHolder.setEnvironmentSpecificPropertyReader(env);
		 when(env.getEnvironmentSpecificProperty("host_name.argentina", null)).thenReturn("other");
		 when(env.getEnvironmentSpecificProperty("host_name.brazil", null)).thenReturn(configuredHost);
		 when(env.getEnvironmentSpecificProperty("host_name.paraguay", null)).thenReturn("another");

         countriesHolder.initialize();
         try{
            countriesHolder.resolveCountry(configuredHost);
        } catch (IllegalStateException ex) {

         }

        saleFactory = new SaleTestData(systemTestFixture.regionSaoPaulo2012);
    }
    
    @Test
    public void when_I_create_an_quota_and_save_should_return_persisted_quota() {
        Quota quota = new Quota(saleTestFixture.harvestSoyMons4nto2012.getOperationalYear(), saleTestFixture.matrixMons4nto, saleTestFixture.productIntactaSoyMons4nto, QuotaType.AVAILABLE);
        getSession().saveOrUpdate(quota);
        
        getSession().flush();
        
        Quota persistedQuota = quotaService.fetchOrCreateQuota(saleTestFixture.matrixMons4nto, saleTestFixture.productIntactaSoyMons4nto, saleTestFixture.harvestSoyMons4nto2012.getOperationalYear(), QuotaType.AVAILABLE, null, null, null);
        Assert.assertNotNull("Quota id should not be null", persistedQuota.getId());
    }
    
    @Test
    public void when_I_fetch_a_quota_with_none_created_should_return_valid_quota() {
        Quota persistedQuota = quotaService.fetchOrCreateQuota(saleTestFixture.matrixMons4nto, saleTestFixture.productIntactaSoyMons4nto, saleTestFixture.harvestSoyMons4nto2012.getOperationalYear(), QuotaType.AVAILABLE, null, null, null);
        Assert.assertNotNull("Quota id should not be null", persistedQuota);
    }
    
    @Test
    public void when_I_fetch_a_quota_after_persisting_two_different_types_should_return_persisted_quota() {
        Quota quota = new Quota(saleTestFixture.harvestSoyMons4nto2012.getOperationalYear(), saleTestFixture.matrixMons4nto, saleTestFixture.productIntactaSoyMons4nto, QuotaType.AVAILABLE);
        getSession().saveOrUpdate(quota);
        
        quota = new Quota(saleTestFixture.harvestSoyMons4nto2012.getOperationalYear(), saleTestFixture.matrixMons4nto, saleTestFixture.productIntactaSoyMons4nto, QuotaType.USED);
        getSession().saveOrUpdate(quota);
        getSession().flush();
        
        quotaService.fetchOrCreateQuota(saleTestFixture.matrixMons4nto, saleTestFixture.productIntactaSoyMons4nto, saleTestFixture.harvestSoyMons4nto2012.getOperationalYear(), QuotaType.AVAILABLE, null, null, null);
    }
    
    @Test
    public void when_I_register_CSV_credit_should_generate_credit_with_positive_balance() {
        Quota quota = quotaService.fetchOrCreateQuota(saleTestFixture.matrixMons4nto, saleTestFixture.productIntactaSoyMons4nto, saleTestFixture.harvestSoyMons4nto2012.getOperationalYear(), QuotaType.AVAILABLE, null, null, null);
        quotaService.registerCSVCreditQuotaFor(quota, BigDecimal.valueOf(1000L), "hello", "JOHN");
        getSession().flush();
        
        quota = null;
        quota = quotaService.fetchOrCreateQuota(saleTestFixture.matrixMons4nto, saleTestFixture.productIntactaSoyMons4nto, saleTestFixture.harvestSoyMons4nto2012.getOperationalYear(), QuotaType.AVAILABLE, null, null, null);
        
        QuotaEntry quotaEntry = quota.getEntries().get(0);
        Assert.assertEquals("Entry compareTo should be 0", 0, BigDecimal.valueOf(1000L).compareTo(quotaEntry.getAmount()));
        Assert.assertEquals("Should be CSV", QuotaTransactionType.CSV, quotaEntry.getQuotaTransaction().getType());
        Assert.assertEquals("Should be 0", 0, quota.getBalance().compareTo(BigDecimal.valueOf(1000L)));
    }
    
    @Test
    public void when_I_register_SAP_credit_should_generate_credit_with_positive_balance() {
        Quota quota = quotaService.fetchOrCreateQuota(saleTestFixture.matrixMons4nto, saleTestFixture.productIntactaSoyMons4nto, saleTestFixture.harvestSoyMons4nto2012.getOperationalYear(), QuotaType.AVAILABLE, null, null, null);
        quotaService.registerSAPQuotaFor(quota, BigDecimal.valueOf(1000L), "hello", "JOHN");
        getSession().flush();
        
        quota = null;
        quota = quotaService.fetchOrCreateQuota(saleTestFixture.matrixMons4nto, saleTestFixture.productIntactaSoyMons4nto, saleTestFixture.harvestSoyMons4nto2012.getOperationalYear(), QuotaType.AVAILABLE, null, null, null);
        
        QuotaEntry quotaEntry = quota.getEntries().get(0);
        Assert.assertEquals("Entry compareTo should be 0", 0, BigDecimal.valueOf(1000L).compareTo(quotaEntry.getAmount()));
        Assert.assertEquals("Should be SAP", QuotaTransactionType.SAP, quotaEntry.getQuotaTransaction().getType());
        Assert.assertEquals("Should be 0", 0, quota.getBalance().compareTo(BigDecimal.valueOf(1000L)));
    }
    
    @Test(expected=SaleConstraintViolationException.class)
    public void given_a_sale_consumingQuota_without_quota_available_should_throw_exception() throws SaleConstraintViolationException {
    	Sale saleConsumingQuota = createSaleWithItemConsumingQuota();
		saleService.save(saleConsumingQuota, superUser);
    }
    
    @Test
    public void given_a_sale_using_a_product_withQuota_should_withdrawal_the_soldQuantity_of_given_quota() throws SaleConstraintViolationException {
    	createAndSaveQuotaForConsumption(new BigDecimal(11));
    	Sale saleConsumingQuota = createSaleWithItemConsumingQuota();

    	saleService.save(saleConsumingQuota, superUser);

        Quota consumedQuota = quotaService.fetchOrCreateQuota(saleTestFixture.matrixMons4nto,
                saleTestFixture.productIntactaWithQuota, systemTestFixture.operationalYearOf2012, QuotaType.AVAILABLE, null, null, null);
        Quota usedQuota = quotaService.fetchOrCreateQuota(saleTestFixture.matrixMons4nto,
                saleTestFixture.productIntactaWithQuota, systemTestFixture.operationalYearOf2012, QuotaType.USED, null, null, null);
    	
    	Assert.assertEquals("Should have balance of one", BigDecimal.ONE, consumedQuota.getBalance());
    	Assert.assertEquals("Should have a quota used of ten", BigDecimal.TEN, usedQuota.getBalance());
    }

	private Sale createSaleWithItemConsumingQuota() {
		Sale saleConsumingQuota = saleFactory.createSale(saleTestFixture.matrixMons4nto, saleTestFixture.chicoBento, SaleTypeEnum.SALE_SEED);
		saleConsumingQuota.setState(systemTestFixture.matoGrossoDoSul);
    	SaleItem itemWithQuotaUsage = createSaleItemForQuotaConsumption(saleConsumingQuota, saleTestFixture.productIntactaWithQuota);
		saleConsumingQuota.addItem(itemWithQuotaUsage);
    	return saleConsumingQuota;
	}

    private SaleItem createSaleItemForQuotaConsumption(Sale saleConsumingQuota, Product product) {
        SaleItem itemWithQuotaUsage = SaleTestData.createSaleItem(saleConsumingQuota, saleTestFixture.templateIntactaMons4nto, product, saleTestFixture.matrixMons4nto);
    	itemWithQuotaUsage.setPriceQuantity(new BigDecimal("0.7"));
        itemWithQuotaUsage.setPlantability(saleTestFixture.plantability45To54SoyMons4nto2012.getDescription());
    	itemWithQuotaUsage.setProductivityValue(BigDecimal.valueOf(505L));

    	Date d = new Date();
    	d = DateUtils.truncate(d, Calendar.MINUTE);
    	d = DateUtils.truncate(d, Calendar.SECOND);
    	d = DateUtils.truncate(d, Calendar.MILLISECOND);
    	d = DateUtils.truncate(d, Calendar.HOUR);
    	
    	itemWithQuotaUsage.setDueDate(d);
        return itemWithQuotaUsage;
    }
	
	@Test(expected=InsufficientBalanceException.class)
	public void when_i_register_a_quota_ofDebit_without_sufficientBalance_then_should_throw_exception() {
        Quota quota = quotaService.fetchOrCreateQuota(saleTestFixture.matrixMons4nto,
                saleTestFixture.productIntactaWithQuota, systemTestFixture.operationalYearOf2012, QuotaType.AVAILABLE, null, null, null);
		quotaService.registerCSVDebtQuotaFor(quota, BigDecimal.valueOf(1000L), "hello", "JOHN");
	}
	
	private Quota createAndSaveQuotaForConsumption(BigDecimal amount) {
        Quota quotaForConsumption = quotaService.fetchOrCreateQuota(saleTestFixture.matrixMons4nto,
                saleTestFixture.productIntactaWithQuota, systemTestFixture.operationalYearOf2012, QuotaType.AVAILABLE, null, null, null);
		
    	
        quotaControlService.saveDeposit(quotaForConsumption.getCustomer(), quotaForConsumption.getProduct(),
                quotaForConsumption.getOperationalYear(), QuotaType.AVAILABLE, amount, QuotaTransactionType.CSV,
                null, null, "vrodrigues", null, null, null);

    	return quotaForConsumption;
	}
	
	@Test
	public void given_quota_with_balance_ten_when_i_register_debit_of_five_then_should_have_five_of_balance_available_and_five_used() {
		createAndSaveQuotaForConsumption(BigDecimal.TEN);
        Quota quota = quotaService.fetchOrCreateQuota(saleTestFixture.matrixMons4nto, saleTestFixture.productIntactaWithQuota, systemTestFixture.operationalYearOf2012, QuotaType.AVAILABLE, null, null, null);
		quotaService.registerCSVDebtQuotaFor(quota, new BigDecimal(5), "invoice", "vrodrigues");
		
        Quota quotaAvailable = quotaService.fetchOrCreateQuota(saleTestFixture.matrixMons4nto, saleTestFixture.productIntactaWithQuota, systemTestFixture.operationalYearOf2012, QuotaType.AVAILABLE, null, null, null);
        Quota quotaUnused = quotaService.fetchOrCreateQuota(saleTestFixture.matrixMons4nto, saleTestFixture.productIntactaWithQuota, systemTestFixture.operationalYearOf2012, QuotaType.UNUSED, null, null, null);
		
		Assert.assertEquals("Should have a balance of 5", new BigDecimal(5), quotaAvailable.getBalance());
		Assert.assertEquals("Should have a used balance of 5", new BigDecimal(5), quotaUnused.getBalance());
	}
	
	@Test
	public void given_a_quota_with_used_balance_when_reversal_is_done_then_balance_should_be_available() {
		Quota quota = createAndSaveQuotaForConsumption(BigDecimal.TEN);
		Quota quotaUsed = new Quota(systemTestFixture.operationalYearOf2012, saleTestFixture.matrixMons4nto, saleTestFixture.productIntactaWithQuota, QuotaType.USED);
		saveAndFlush(quotaUsed);
		
        quotaControlService.saveTransfer(quota.getCustomer(), quota.getProduct(), quota.getOperationalYear(), quota.getType(), QuotaType.USED, BigDecimal.valueOf(5L), QuotaTransactionType.SALE, 1L, null, "JOHN", null, null, null);
		
        quotaService.manageCancelFor(systemTestFixture.operationalYearOf2012, saleTestFixture.matrixMons4nto, saleTestFixture.productIntactaWithQuota, 1L, "JOHN", null, null, null);
		getSession().flush();
		
        quota = quotaService.fetchOrCreateQuota(saleTestFixture.matrixMons4nto, saleTestFixture.productIntactaWithQuota, systemTestFixture.operationalYearOf2012, QuotaType.AVAILABLE, null, null, null);
		Assert.assertEquals("Should be 0", 0, quota.getBalance().compareTo(BigDecimal.TEN));
	}
	

	@Test
    public void given_a_sale_that_consumes_quota_when_i_cancel_that_sale_then_quota_should_be_reversed() throws SaleConstraintViolationException, IndustrySystemOperationException {
        createAndSaveQuotaForConsumption(new BigDecimal(10));
        
        Sale saleConsumingQuota = createSaleWithItemConsumingQuota();
        saleService.save(saleConsumingQuota, superUser);
        
        Quota quotaAvailable = quotaService.fetchOrCreateQuota(saleTestFixture.matrixMons4nto, saleTestFixture.productIntactaWithQuota, systemTestFixture.operationalYearOf2012, QuotaType.AVAILABLE, null, null, null);
        Quota quotaUsed = quotaService.fetchOrCreateQuota(saleTestFixture.matrixMons4nto, saleTestFixture.productIntactaWithQuota, systemTestFixture.operationalYearOf2012, QuotaType.USED, null, null, null);
        
        Assert.assertEquals("Available quota should have balance of zero", BigDecimal.ZERO, quotaAvailable.getBalance());
        Assert.assertEquals("Used quota should have a quota used of ten", BigDecimal.TEN, quotaUsed.getBalance());
        
        saleService.cancelBillingPartially(saleConsumingQuota.getId(), systemTestFixture.mons4ntoBr, saleTestFixture.saleCancellation, "JOHN");
        
        quotaAvailable = quotaService.fetchOrCreateQuota(saleTestFixture.matrixMons4nto, saleTestFixture.productIntactaWithQuota, systemTestFixture.operationalYearOf2012, QuotaType.AVAILABLE, null, null, null);
        quotaUsed = quotaService.fetchOrCreateQuota(saleTestFixture.matrixMons4nto, saleTestFixture.productIntactaWithQuota, systemTestFixture.operationalYearOf2012, QuotaType.USED, null, null, null);
        
        Assert.assertEquals("Available quota should have balance of ten", BigDecimal.TEN, quotaAvailable.getBalance());
        Assert.assertEquals("Used quota should have a quota used of zero", BigDecimal.ZERO, quotaUsed.getBalance());
	}
	
	@Test
	public void given_a_sale_with_one_product_that_uses_quota_and_one_not_when_I_cancel_sale_then_should_not_generate_quota_for_non_using_product() throws SaleConstraintViolationException, IndustrySystemOperationException {
        createAndSaveQuotaForConsumption(new BigDecimal(10));
	    
        Sale saleConsumingQuota = createSaleWithItemConsumingQuota();
        createSaleItemForQuotaConsumption(saleConsumingQuota, saleTestFixture.productIntactaSoyMons4nto);
        saleService.save(saleConsumingQuota, superUser);
        
        saleService.cancelBillingPartially(saleConsumingQuota.getId(), systemTestFixture.mons4ntoBr, saleTestFixture.saleCancellation, "JOHN");
        
        List<Quota> quotaQuotas = quotaDAO.getQuotasBy(QuotaFilter.getInstance().add(saleTestFixture.matrixMons4nto).add(systemTestFixture.operationalYearOf2012).add(saleTestFixture.productIntactaWithQuota));        
        
        Assert.assertFalse("Should not be empty", quotaQuotas.isEmpty());
        
        List<Quota> noQuotaQuotas = quotaDAO.getQuotasBy(QuotaFilter.getInstance().add(saleTestFixture.matrixMons4nto).add(systemTestFixture.operationalYearOf2012).add(saleTestFixture.productIntactaSoyMons4nto));        
        Assert.assertTrue("Should be empty", noQuotaQuotas.isEmpty());
	}
	
	private Quota createAndSaveQuotaForReport(BigDecimal amount, Customer customer) {
        Quota quotaForConsumption = quotaService.fetchOrCreateQuota(customer, saleTestFixture.productIntactaWithQuotaForReport, systemTestFixture.operationalYearOf2012, QuotaType.AVAILABLE, null, null, null);
        quotaControlService.saveDeposit(quotaForConsumption.getCustomer(), quotaForConsumption.getProduct(), quotaForConsumption.getOperationalYear(), QuotaType.AVAILABLE, amount, QuotaTransactionType.CSV, null, null, "vrodrigues", null, null, null);
    	return quotaForConsumption;
	}
	
	private Sale createSaleWithItemConsumingQuotaForReport() {
		Sale saleConsumingQuota = saleFactory.createSale(saleTestFixture.matrixCargil, saleTestFixture.chicoBento, SaleTypeEnum.SALE_SEED);
		saleConsumingQuota.setState(systemTestFixture.matoGrossoDoSul);
    	SaleItem itemWithQuotaUsage = createSaleItemForQuotaConsumptionForReport(saleConsumingQuota, saleTestFixture.productIntactaWithQuotaForReport);
		saleConsumingQuota.addItem(itemWithQuotaUsage);
    	return saleConsumingQuota;
	}

    private SaleItem createSaleItemForQuotaConsumptionForReport(Sale saleConsumingQuota, Product product) {
        SaleItem itemWithQuotaUsage = SaleTestData.createSaleItem(saleConsumingQuota, saleTestFixture.templateIntactaByPlantabilityRRByExpirationBtFreeErp, product, saleTestFixture.matrixCargil);
        itemWithQuotaUsage.setPriceQuantity(new BigDecimal("0.7"));
        itemWithQuotaUsage.setPlantability(saleTestFixture.plantability45To54SoyMonsanto2012.getDescription());
    	itemWithQuotaUsage.setProductivityValue(BigDecimal.valueOf(505L));
    	itemWithQuotaUsage.setDueDate(SaleTestFixture.DATE_NOW);
        return itemWithQuotaUsage;
    }
	
	@Test
	public void i_want_to_see_quota_extract_by_filter_company_crop() throws SaleConstraintViolationException {
		
		if (!getAssumptionTest().isEnvironmentWithSQLANSI()) {
			DbUnitHelper.setup("classpath:data/seedsale/vw-quota-extract-report-dataset.xml");
    	}else{
    		createAndSaveQuotaForReport(BigDecimal.TEN, saleTestFixture.matrixCargil);
    		Sale saleConsumingQuota = createSaleWithItemConsumingQuotaForReport();
        	accessControlTestFixture.superUser.setContextCompany(systemTestFixture.monsantoBr);
        	accessControlTestFixture.superUser.setContextCrop(systemTestFixture.soy);
        	
        	saleService.save(saleConsumingQuota, accessControlTestFixture.superUser);
    	} 
  
        QuotaExtractReportViewFilter filter = QuotaExtractReportViewFilter.getInstance(systemTestFixture.monsantoBr, systemTestFixture.soy);
        
        List<QuotaReportExtractView> quotaQuotas = quotaDAO.getQuotaReportExtractViewByFilter(filter);
        
        validateQuotaExtract(quotaQuotas, 2);
        
	}
	
	@Test
	public void i_want_to_see_quota_extract_by_filter_company_crop_technology() throws SaleConstraintViolationException {
		
		if (!getAssumptionTest().isEnvironmentWithSQLANSI()) {
			DbUnitHelper.setup("classpath:data/seedsale/vw-quota-extract-report-dataset.xml");
    	}else{
    		createAndSaveQuotaForReport(BigDecimal.TEN, saleTestFixture.matrixCargil);
    		Sale saleConsumingQuota = createSaleWithItemConsumingQuotaForReport();
        	accessControlTestFixture.superUser.setContextCompany(systemTestFixture.monsantoBr);
        	accessControlTestFixture.superUser.setContextCrop(systemTestFixture.soy);
        	
        	saleService.save(saleConsumingQuota, accessControlTestFixture.superUser);
    	} 
  
        QuotaExtractReportViewFilter filter = QuotaExtractReportViewFilter.getInstance(systemTestFixture.monsantoBr, systemTestFixture.soy)
        		.addTechnology(saleTestFixture.productIntactaWithQuotaForReport.getTechnology());
        
        List<QuotaReportExtractView> quotaQuotas = quotaDAO.getQuotaReportExtractViewByFilter(filter);        
        
        validateQuotaExtract(quotaQuotas, 2);
	}
	
	 @Test
     public void i_want_to_see_quota_extract_by_filter_customer_different_contract_should_retrieve_zero_quota() throws UserNotFoundException, UserAccessDeniedException, EntityNotFoundException {
         createAndSaveQuotaForConsumption(new BigDecimal(10));
         
//         accessControlTestFixture.itsParticipantUser.addUserContract(saleTestFixture.contractMons4nto, saleTestFixture.matrixMons4nto, HierarchyLevel.AFFILIATE);
         accessControlTestFixture.itsParticipantUser.addUserContract(saleTestFixture.agroSojaContract, saleTestFixture.agroSoja, HierarchyLevel.HEAD_OFFICE);
         saveAndFlush(accessControlTestFixture.itsParticipantUser);
         
         
         UserDecorator userDecorator = userServices.getAuthenticatedUserBy(accessControlTestFixture.itsParticipantUser.getLogin());
         userDecorator.setContextCrop(systemTestFixture.soy);
         
         QuotaExtractReportViewFilter filter = QuotaExtractReportViewFilter
         .getInstance(saleTestFixture.productIntactaWithQuota.getCompany(), saleTestFixture.productIntactaWithQuota.getCrop())
         .addTechnology(saleTestFixture.productIntactaWithQuota.getTechnology()).addCustomerIn(userDecorator);
         
         List<QuotaReportExtractView> quotas = quotaDAO.getQuotaReportExtractViewByFilter(filter);
         Assert.assertEquals("One entry", 0, quotas.size());
     }
	
	@Test
	public void i_want_to_see_quota_extract_by_filter_company_crop_matrix() throws SaleConstraintViolationException {
		
		if (!getAssumptionTest().isEnvironmentWithSQLANSI()) {
			DbUnitHelper.setup("classpath:data/seedsale/vw-quota-extract-report-dataset.xml");
    	}else{
    		createAndSaveQuotaForReport(BigDecimal.TEN, saleTestFixture.matrixCargil);
    		Sale saleConsumingQuota = createSaleWithItemConsumingQuotaForReport();
        	accessControlTestFixture.superUser.setContextCompany(systemTestFixture.monsantoBr);
        	accessControlTestFixture.superUser.setContextCrop(systemTestFixture.soy);
        	
        	saleService.save(saleConsumingQuota, accessControlTestFixture.superUser);
    	} 
        
		QuotaExtractReportViewFilter filter = QuotaExtractReportViewFilter.getInstance(systemTestFixture.monsantoBr, systemTestFixture.soy)
        				.addCustomer(saleTestFixture.matrixCargil);
        
        List<QuotaReportExtractView> quotaQuotas = quotaDAO.getQuotaReportExtractViewByFilter(filter);        
        
        validateQuotaExtract(quotaQuotas, 2);
	}
	
	@Test
	public void i_want_to_see_quota_extract_by_filter_company_crop_product() throws SaleConstraintViolationException {
		

		if (!getAssumptionTest().isEnvironmentWithSQLANSI()) {
			DbUnitHelper.setup("classpath:data/seedsale/vw-quota-extract-report-dataset.xml");
    	}else{
    		createAndSaveQuotaForReport(BigDecimal.TEN, saleTestFixture.matrixCargil);
    		Sale saleConsumingQuota = createSaleWithItemConsumingQuotaForReport();
        	accessControlTestFixture.superUser.setContextCompany(systemTestFixture.monsantoBr);
        	accessControlTestFixture.superUser.setContextCrop(systemTestFixture.soy);
        	
        	saleService.save(saleConsumingQuota, accessControlTestFixture.superUser);
    	} 
        
		QuotaExtractReportViewFilter filter = QuotaExtractReportViewFilter.getInstance(systemTestFixture.monsantoBr, systemTestFixture.soy)
                .add(saleTestFixture.productIntactaWithQuotaForReport);
        
        List<QuotaReportExtractView> quotaQuotas = quotaDAO.getQuotaReportExtractViewByFilter(filter);        
        
        validateQuotaExtract(quotaQuotas, 2);
	}
	
	@Test
	public void i_want_to_see_quota_extract_by_filter_company_crop_operational_year() throws SaleConstraintViolationException {
		
		if (!getAssumptionTest().isEnvironmentWithSQLANSI()) {
			DbUnitHelper.setup("classpath:data/seedsale/vw-quota-extract-report-dataset.xml");
    	}else{
    		createAndSaveQuotaForReport(BigDecimal.TEN, saleTestFixture.matrixCargil);
    		Sale saleConsumingQuota = createSaleWithItemConsumingQuotaForReport();
        	accessControlTestFixture.superUser.setContextCompany(systemTestFixture.monsantoBr);
        	accessControlTestFixture.superUser.setContextCrop(systemTestFixture.soy);
        	
        	saleService.save(saleConsumingQuota, accessControlTestFixture.superUser);
    	} 

        
		QuotaExtractReportViewFilter filter = QuotaExtractReportViewFilter.getInstance(systemTestFixture.monsantoBr, systemTestFixture.soy)
        				.addOperationalYear(systemTestFixture.operationalYearOf2012);
        
        List<QuotaReportExtractView> quotaQuotas = quotaDAO.getQuotaReportExtractViewByFilter(filter);        
        
        validateQuotaExtract(quotaQuotas, 2);
	}
	
	@Test
	public void i_want_to_see_quota_extract_by_filter_company_crop_with_sale_canceled() throws SaleConstraintViolationException, IndustrySystemOperationException {
		if (!getAssumptionTest().isEnvironmentWithSQLANSI()) {
			DbUnitHelper.setup("classpath:data/seedsale/vw-quota-extract-report-dataset.xml");
			QuotaReportExtractView quotaReportExtractView = new QuotaReportExtractView();
			quotaReportExtractView.setQuotaEntryId(3L);
			quotaReportExtractView.setQuotaType(QuotaType.AVAILABLE);
			quotaReportExtractView.setAmount(BigDecimal.TEN);
			quotaReportExtractView.setCompanyId(systemTestFixture.monsantoBr.getId());
			quotaReportExtractView.setCropDescription(systemTestFixture.soy.getDescription());
			quotaReportExtractView.setCustomerId(saleTestFixture.matrixCargil.getId());
			quotaReportExtractView.setCustomerSapCode(saleTestFixture.matrixCargil.getCustomerSAPCode());
			quotaReportExtractView.setCustomerDescription(saleTestFixture.matrixCargil.getName());
			quotaReportExtractView.setCustomerDocument(saleTestFixture.matrixCargil.getDocumentValue());
			quotaReportExtractView.setCustomerDocumentTypeDesc(saleTestFixture.matrixCargil.getDocument().getDocumentTypeDescription());
			quotaReportExtractView.setOperationYearDescription(systemTestFixture.operationalYearOf2012.getYear());
			quotaReportExtractView.setProductCode(saleTestFixture.productIntactaWithQuotaForReport.getId());
			quotaReportExtractView.setProductDescription(saleTestFixture.productIntactaWithQuotaForReport.getDescription());
			quotaReportExtractView.setTechnologyDescription(saleTestFixture.productIntactaWithQuotaForReport.getTechnology().getDescription());
			quotaReportExtractView.setTransactionType(QuotaTransactionType.SALE);
			quotaReportExtractView.setTransactionDate(new Date());
			quotaReportExtractView.setLoginUser("JOHN");
			quotaReportExtractView.setPartnerId(saleTestFixture.matrixCargil.getId());
			quotaReportExtractView.setPartnerSapCode(saleTestFixture.matrixCargil.getCustomerSAPCode());
			quotaReportExtractView.setPartnerDescription(saleTestFixture.matrixCargil.getName());
			quotaReportExtractView.setPartnerDocument(saleTestFixture.matrixCargil.getDocumentValue());
			quotaReportExtractView.setPartnerDocumentTypeDesc(saleTestFixture.matrixCargil.getDocument().getDocumentTypeDescription());
			saveAndFlush(quotaReportExtractView);
			getSession().evict(quotaReportExtractView);
    	}else{
    		createAndSaveQuotaForReport(BigDecimal.TEN, saleTestFixture.matrixCargil);
    		Sale saleConsumingQuota = createSaleWithItemConsumingQuotaForReport();
        	accessControlTestFixture.superUser.setContextCompany(systemTestFixture.monsantoBr);
        	accessControlTestFixture.superUser.setContextCrop(systemTestFixture.soy);
        	
        	saleService.save(saleConsumingQuota, accessControlTestFixture.superUser);
        	saleService.cancelBillingPartially(saleConsumingQuota.getId(), systemTestFixture.monsantoBr, saleTestFixture.saleCancellation, "JOHN");
    	}
        
        QuotaExtractReportViewFilter filter = QuotaExtractReportViewFilter.getInstance(systemTestFixture.monsantoBr, systemTestFixture.soy)
							.addOperationalYear(systemTestFixture.operationalYearOf2012)
                .add(saleTestFixture.productIntactaWithQuotaForReport)
							.addCustomer(saleTestFixture.matrixCargil)
							.addTechnology(saleTestFixture.productIntactaWithQuotaForReport.getTechnology());        
        
        List<QuotaReportExtractView> quotaQuotas = quotaDAO.getQuotaReportExtractViewByFilter(filter);        
        
        validateQuotaExtract(quotaQuotas, 3);
	}
	
	@Test
	public void given_a_valid_quota_and_user_with_headoffice_contract_when_filter_by_user_then_should_retrieve_one_quota() throws UserNotFoundException, UserAccessDeniedException, EntityNotFoundException {
        createAndSaveQuotaForConsumption(new BigDecimal(10));
        
        accessControlTestFixture.itsParticipantUser.addUserContract(saleTestFixture.contractMons4nto, saleTestFixture.matrixMons4nto, HierarchyLevel.HEAD_OFFICE);
//        accessControlTestFixture.itsParticipantUser.addUserContract(saleTestFixture.agroSojaContract, saleTestFixture.agroSoja, HierarchyLevel.HEAD_OFFICE);
        saveAndFlush(accessControlTestFixture.itsParticipantUser);
        
        UserDecorator userDecorator = userServices.getAuthenticatedUserBy(accessControlTestFixture.itsParticipantUser.getLogin());
        userDecorator.setContextCrop(systemTestFixture.soyMons4nto);
        
        QuotaFilter filter = QuotaFilter.getInstance().addCompanyIn(userDecorator);
        
        List<Quota> quotas = quotaDAO.getQuotasBy(filter);
	    Assert.assertEquals("One entry", 1, quotas.size());
	}
	
	   @Test
	    public void given_a_valid_quota_and_user_with_affiliate_contract_when_filter_by_user_then_should_retrieve_one_quota() throws UserNotFoundException, UserAccessDeniedException, EntityNotFoundException {
	        createAndSaveQuotaForConsumption(new BigDecimal(10));
	        
	        accessControlTestFixture.itsParticipantUser.addUserContract(saleTestFixture.contractMons4nto, saleTestFixture.matrixMons4nto, HierarchyLevel.AFFILIATE);
//	        accessControlTestFixture.itsParticipantUser.addUserContract(saleTestFixture.agroSojaContract, saleTestFixture.agroSoja, HierarchyLevel.HEAD_OFFICE);
	        saveAndFlush(accessControlTestFixture.itsParticipantUser);
	        
	        UserDecorator userDecorator = userServices.getAuthenticatedUserBy(accessControlTestFixture.itsParticipantUser.getLogin());
	        userDecorator.setContextCrop(systemTestFixture.soyMons4nto);
	        
	        QuotaFilter filter = QuotaFilter.getInstance().addCompanyIn(userDecorator);
	        
	        List<Quota> quotas = quotaDAO.getQuotasBy(filter);
	        Assert.assertEquals("One entry", 1, quotas.size());
	    }
	   
	   @Test
       public void given_a_valid_quota_and_user_with_affiliate_contract_for_different_company_when_filter_by_user_then_should_retrieve_zero_quota() throws UserNotFoundException, UserAccessDeniedException, EntityNotFoundException {
           
		   if (!getAssumptionTest().isEnvironmentWithSQLANSI()) {
				DbUnitHelper.setup("classpath:data/seedsale/vw-quota-extract-report-dataset.xml");
	    	}else{
	    		createAndSaveQuotaForReport(BigDecimal.TEN, saleTestFixture.matrixCargil);	    	
	    	}
		   
		   accessControlTestFixture.itsParticipantUser.addUserContract(saleTestFixture.agroSojaContract, saleTestFixture.agroSoja, HierarchyLevel.HEAD_OFFICE);
           saveAndFlush(accessControlTestFixture.itsParticipantUser);
           
           UserDecorator userDecorator = userServices.getAuthenticatedUserBy(accessControlTestFixture.itsParticipantUser.getLogin());
           userDecorator.setContextCrop(systemTestFixture.soy);
           
           QuotaFilter filter = QuotaFilter.getInstance().addCompanyIn(userDecorator);
           
           List<Quota> quotas = quotaDAO.getQuotasBy(filter);
           Assert.assertEquals("One entry", 0, quotas.size());
       }
	   
       @Test
       public void given_a_valid_quota_and_when_filter_by_company_crop_then_should_return_one() throws UserNotFoundException, UserAccessDeniedException, EntityNotFoundException {
           createAndSaveQuotaForConsumption(new BigDecimal(10));
           
           QuotaFilter filter = QuotaFilter.getInstance().addCrop(systemTestFixture.soyMons4nto).addCompany(systemTestFixture.mons4ntoBr);
           
           List<Quota> quotas = quotaDAO.getQuotasBy(filter);
           Assert.assertEquals("One entry", 1, quotas.size());
       }

	private void validateQuotaExtract(List<QuotaReportExtractView> quotaQuotas, int size) {
		Assert.assertFalse("Should not be empty", quotaQuotas.isEmpty());
        Assert.assertTrue("Should has "+size+" item(s)", quotaQuotas.size() == size);
        
        for (QuotaReportExtractView quotaReportExtractView : quotaQuotas) {
        	Assert.assertNotNull("PrimaryKey Should not be empty", quotaReportExtractView.getPrimaryKey());
        	Assert.assertNotNull("QuotaEntryId Should not be empty", quotaReportExtractView.getQuotaEntryId());
        	Assert.assertNotNull("QuotaType Should not be empty", quotaReportExtractView.getQuotaType());
        	Assert.assertNotNull("CompanyId Should not be empty", quotaReportExtractView.getCompanyId());
        	Assert.assertNotNull("CropDescription Should not be empty", quotaReportExtractView.getCropDescription());
			Assert.assertNotNull("TechnologyDescription Should not be empty", quotaReportExtractView.getTechnologyDescription());
        	Assert.assertNotNull("OperationYearDescription Should not be empty", quotaReportExtractView.getOperationYearDescription());
        	Assert.assertNotNull("Amount Should not be empty", quotaReportExtractView.getAmount());
        	Assert.assertNotNull("TransactionType Should not be empty", quotaReportExtractView.getTransactionType());
        	Assert.assertNotNull("TransactionDate Should not be empty", quotaReportExtractView.getTransactionDate());
        	Assert.assertNotNull("ProductCode Should not be empty", quotaReportExtractView.getProductCode());
        	Assert.assertNotNull("ProductDescription Should not be empty", quotaReportExtractView.getProductDescription());
        	Assert.assertNotNull("LoginUser Should not be empty", quotaReportExtractView.getLoginUser());
        	Assert.assertNotNull("CustomerId Should not be empty", quotaReportExtractView.getCustomerId());
        	Assert.assertNotNull("CustomerDescription Should not be empty", quotaReportExtractView.getCustomerDescription());
        	Assert.assertNotNull("CustomerDocument Should not be empty", quotaReportExtractView.getCustomerDocument());
        	Assert.assertNotNull("CustomerDocumentTypeDesc Should not be empty", quotaReportExtractView.getCustomerDocumentTypeDesc());
        	Assert.assertNotNull("CustomerSapCode Should not be empty", quotaReportExtractView.getCustomerSapCode());
        	
			if (quotaReportExtractView.getTransactionType().equals(QuotaTransactionType.SALE)){
				Assert.assertNotNull("PartnerId Should not be empty", quotaReportExtractView.getPartnerId());
				Assert.assertNotNull("PartnerDescription Should not be empty", quotaReportExtractView.getPartnerDescription());
				Assert.assertNotNull("PartnerDocument Should not be empty", quotaReportExtractView.getPartnerDocument());
				Assert.assertNotNull("PartnerDocumentTypeDesc Should not be empty", quotaReportExtractView.getPartnerDocumentTypeDesc());
				Assert.assertNotNull("PartnerSapCode Should not be empty", quotaReportExtractView.getPartnerSapCode());
			}
		}
	}
}
