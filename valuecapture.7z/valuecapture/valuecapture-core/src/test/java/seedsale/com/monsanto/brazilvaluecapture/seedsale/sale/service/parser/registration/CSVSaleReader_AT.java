package com.monsanto.brazilvaluecapture.seedsale.sale.service.parser.registration;

import java.io.IOException;
import java.io.InputStream;
import java.text.ParseException;
import java.util.Locale;
import java.util.ResourceBundle;

import junit.framework.Assert;

import org.junit.After;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.monsanto.brazilvaluecapture.core.base.SystemTestFixture;
import com.monsanto.brazilvaluecapture.core.foundation.test.AbstractServiceIntegrationTests;
import com.monsanto.brazilvaluecapture.core.foundation.util.csv.CSVInvalidLayoutException;
import com.monsanto.brazilvaluecapture.core.foundation.util.csv.CSVParserReader.CSV_ERROS;
import com.monsanto.brazilvaluecapture.core.foundation.util.csv.CSVReadableInvalidException;
import com.monsanto.brazilvaluecapture.core.user.AccessControlTestFixture;
import com.monsanto.brazilvaluecapture.seedsale.sale.SaleTestFixture;
import com.monsanto.brazilvaluecapture.seedsale.sale.service.SaleService;

public class CSVSaleReader_AT extends AbstractServiceIntegrationTests{

	@Autowired
	private SaleService saleService;

	private SaleFileParser fileparser;	

	private Locale localeBR = new Locale("pt", "BR");

	private ResourceBundle resourceBundle = ResourceBundle.getBundle("bundle/bundle");


	@Before
	public void init(){
		systemTestFixture = new SystemTestFixture(this);
		saleTestFixture = new SaleTestFixture(this, systemTestFixture);
		accessControlTestFixture = new AccessControlTestFixture(this, systemTestFixture);
		accessControlTestFixture.superUser.setContextCompany(systemTestFixture.monsantoBr);
		accessControlTestFixture.superUser.setContextCrop(systemTestFixture.soy);
	}

	@After
	public void tearDown() {
		logger.info(fileparser.getResultAsString(resourceBundle));
	}

	@Test 
    @Ignore
	public void when_i_have_a_imported_sales_file_with_keys_nullable_shouldReturnException() throws CSVReadableInvalidException{
		InputStream inputFileErrorKeysNullable = getClass().getClassLoader().getResourceAsStream("csv/sale_test_error_keys_nullable_pt_BR.csv");
		fileparser = new SaleFileParser(inputFileErrorKeysNullable, localeBR, accessControlTestFixture.superUser, saleService, null);
		fileparser.readFile();
		
		Assert.assertTrue("Should have throw exception", fileparser.hasError(CSV_ERROS.ERROR_FIELD_REQUIRED));
	}

	@Test
    @Ignore
	public void when_i_have_a_imported_sales_file_with_errors_shouldReturnSpecificWarnings() throws CSVReadableInvalidException, ParseException, IOException, CSVInvalidLayoutException{
		InputStream inputFileError = getClass().getClassLoader().getResourceAsStream("csv/sale_test_error_pt_BR.csv");
		fileparser = new SaleFileParser(inputFileError, localeBR, accessControlTestFixture.superUser, saleService, null);
		fileparser.readFile();

		Assert.assertEquals(4, fileparser.getErrorLines());
		Assert.assertEquals("Should have occurence Of Sale Template",8, fileparser.countOccurrenceOfError("label.saletemplate", false));
		Assert.assertEquals("Should have occurence Of Headoffice",8, fileparser.countOccurrenceOfError("label.headoffice", false));
		Assert.assertEquals("Should have occurence Of Grower",4, fileparser.countOccurrenceOfError("sale-record.growerName.label", false));
		Assert.assertEquals("Should have occurence Of Distributor",4, fileparser.countOccurrenceOfError("sale-record.distributorDocument.label", false));
		Assert.assertEquals("Should have occurence Of Produtivity State",4, fileparser.countOccurrenceOfError("label.productivity.state", false));
		Assert.assertEquals("Should have occurence Of Product",0, fileparser.countOccurrenceOfError("sale-record.product.label", false));
	}

}
