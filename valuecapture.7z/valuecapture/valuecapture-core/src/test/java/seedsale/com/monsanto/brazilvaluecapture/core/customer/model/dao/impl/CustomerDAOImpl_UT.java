package com.monsanto.brazilvaluecapture.core.customer.model.dao.impl;

import com.google.common.collect.Lists;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Company;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Crop;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Customer;
import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.hibernate.classic.Session;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InOrder;

import java.util.List;

import static org.fest.assertions.Assertions.assertThat;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.*;

/**
 * User: PPERA
 * Date: 5/13/13
 * Time: 3:29 PM
 */
public class CustomerDAOImpl_UT {
    private CustomerDAOImpl customerDAO;
    private Session session;
    private Query query;

    @Before
    public void setUp() {
        SessionFactory sessionFactory = mock(SessionFactory.class);
        this.session = mock(Session.class);
        when(sessionFactory.getCurrentSession()).thenReturn(this.session);
        this.customerDAO = new CustomerDAOImpl(sessionFactory);
        this.query = mock(Query.class);
        when(this.session.createQuery(anyString())).thenReturn(this.query);
    }

    @Test
    public void testGetRetailersByParticipantCropAndCompanyCreatesAQueryWithParametersParticipant1AndInputCrop_WhenGetARetailerByParticipant1AndCrop() {
        // @Given a crop and a participant id 1
        Crop crop = new Crop();
        Long participantId = 1l;

        // @When getting a retailer by participant id and crop
        this.customerDAO.getRetailersByCropAndParticipant(crop, participantId);

        // @Then a query is created and participant id and crop are set as parameters, then the query is executed
        InOrder inOrder = inOrder(this.session, this.query);
        inOrder.verify(this.session, times(1)).createQuery(CustomerDAOImpl.FIND_RETAILERS_BY_PARTICIPANT_AND_CROP);
        inOrder.verify(this.query, times(1)).setParameter(eq("crop"), same(crop));
        inOrder.verify(this.query, times(1)).setParameter(eq("participantId"), same(participantId));
        inOrder.verify(this.query, times(1)).list();
    }

    @Test
    public void testGetRetailersByParticipantCropAndCompanyCreatesAQueryWithParametersParticipant5AndInputCrop_WhenGetARetailerByParticipant5AndCrop() {
        // @Given a crop and a participant id 5
        Crop crop = new Crop();
        Long participantId = 5l;

        // @When getting a retailer by participant id and crop
        this.customerDAO.getRetailersByCropAndParticipant(crop, participantId);

        // @Then a query is created and participant id and crop are set as parameters, then the query is executed
        InOrder inOrder = inOrder(this.session, this.query);
        inOrder.verify(this.session, times(1)).createQuery(CustomerDAOImpl.FIND_RETAILERS_BY_PARTICIPANT_AND_CROP);
        inOrder.verify(this.query, times(1)).setParameter(eq("crop"), same(crop));
        inOrder.verify(this.query, times(1)).setParameter(eq("participantId"), same(participantId));
        inOrder.verify(this.query, times(1)).list();
    }

    @Test
    public void testGetRetailersByParticipantCropAndCompanyReturnsQueryResult_WhenGettingARetailerByParticipantAndCrop() {
        // @Given a crop and a participant Id
        Crop crop = new Crop();
        Long participantId = 3l;
        when(this.query.list()).thenReturn(Lists.newArrayList());

        // @When getting a retailer by participant id and crop
        List<Customer> returnedRetailers = this.customerDAO.getRetailersByCropAndParticipant(crop, participantId);

        // @Then result is the result of the query
        assertThat(returnedRetailers).isSameAs(this.query.list());
    }

    @Test
    public void testGetRetailersByCropAndCompanyCreatesAQueryWithParametersInputCropAndInputCompany_WhenGetARetailerByCropAndCompany() {
        // @Given a crop and a company
        Crop crop = new Crop();
        Company company = new Company();

        // @When getting a retailer by crop and company
        this.customerDAO.getRetailersByCropAndCompany(crop, company);

        // @Then a query is created and company and crop are set as parameters, then the query is executed
        InOrder inOrder = inOrder(this.session, this.query);
        inOrder.verify(this.session, times(1)).createQuery(CustomerDAOImpl.FIND_RETAILER_BY_CROP_AND_COMPANY);
        inOrder.verify(this.query, times(1)).setParameter(eq("crop"), same(crop));
        inOrder.verify(this.query, times(1)).setParameter(eq("company"), same(company));
        inOrder.verify(this.query, times(1)).list();
    }

    @Test
    public void testGetRetailersByCropAndCompanyReturnsQueryResult_WhenGettingARetailerByCropAndCompany() {
        // @Given a crop and a company
        Crop crop = new Crop();
        Company company = new Company();
        when(this.query.list()).thenReturn(Lists.newArrayList());

        // @When getting a retailer by crop and company
        List<Customer> returnedRetailers = this.customerDAO.getRetailersByCropAndCompany(crop, company);

        // @Then result is the result of the query
        assertThat(returnedRetailers).isSameAs(this.query.list());
    }
}
