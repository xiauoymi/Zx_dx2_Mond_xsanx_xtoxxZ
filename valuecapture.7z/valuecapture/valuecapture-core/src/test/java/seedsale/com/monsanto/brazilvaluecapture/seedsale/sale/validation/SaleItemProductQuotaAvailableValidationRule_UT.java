package com.monsanto.brazilvaluecapture.seedsale.sale.validation;

import com.google.common.collect.Sets;
import com.monsanto.brazilvaluecapture.core.base.model.bean.OperationalYear;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Customer;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.ParticipantTypeEnum;
import com.monsanto.brazilvaluecapture.core.customer.service.CustomerService;
import com.monsanto.brazilvaluecapture.core.foundation.model.bean.QuotaUsageEnum;
import com.monsanto.brazilvaluecapture.core.foundation.validation.ValidationException;
import com.monsanto.brazilvaluecapture.seedsale.harvest.model.bean.Harvest;
import com.monsanto.brazilvaluecapture.seedsale.harvest.model.bean.Plantability;
import com.monsanto.brazilvaluecapture.seedsale.product.model.bean.Product;
import com.monsanto.brazilvaluecapture.seedsale.quota.model.bean.Quota;
import com.monsanto.brazilvaluecapture.seedsale.quota.model.bean.QuotaType;
import com.monsanto.brazilvaluecapture.seedsale.quota.service.QuotaService;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.Sale;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.SaleItem;
import com.monsanto.brazilvaluecapture.seedsale.template.model.bean.SaleTemplate;
import org.junit.Test;

import java.math.BigDecimal;

import static org.fest.assertions.Assertions.assertThat;
import static org.junit.Assert.fail;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;


/**
 * Created with IntelliJ IDEA.
 * User: IFERN1
 * Date: 12/2/13
 * Time: 8:55 AM
 * To change this template use File | Settings | File Templates.
 */
public class SaleItemProductQuotaAvailableValidationRule_UT {
    @Test
    public void given_a_product_that_dont_use_quota_when_validate_validation_passes() throws ValidationException {
        //@Given
        //Validation rule
        QuotaService quotaService = mock(QuotaService.class);
        CustomerService customerService = mock(CustomerService.class);
        SaleItemProductQuotaAvailableValidationRule saleItemProductQuotaAvailableValidationRule = new SaleItemProductQuotaAvailableValidationRule();
        saleItemProductQuotaAvailableValidationRule.setQuotaService(quotaService);
        saleItemProductQuotaAvailableValidationRule.setCustomerService(customerService);
        //Sale
        Sale sale = new Sale();
        SaleItem saleItem = new SaleItem();
        Product product = new Product();
        product.setQuotaUsage(QuotaUsageEnum.DONT_USE_QUOTA);
        saleItem.setProduct(product);
        sale.setItems(Sets.newHashSet(saleItem));

        //@When
        try {
            saleItemProductQuotaAvailableValidationRule.validate(sale);
            //@Should pass without exceptions
        } catch (Exception e) {
            fail("Should not throw an exception");
        }
    }

    @Test
    public void given_a_product_that_use_quota_when_validate_if_soldQty_exceeds_available_quota_validation_fails() throws ValidationException {
        //@Given
        OperationalYear operationalYear = new OperationalYear("2013");
        Customer customer = new Customer();
        Product product = new Product();
        product.setDescription("Product Description");
        String lot = "someLot";
        Customer multiplier = new Customer("Multiplier name", null, null, "Sap Code");
        Plantability plantability = new Plantability();
        //Validation rule
        QuotaService quotaService = mock(QuotaService.class);
        Quota quota = mock(Quota.class);
        CustomerService customerService = mock(CustomerService.class);
        when(quota.getBalance()).thenReturn(BigDecimal.ONE);
        Customer dealerHeadoffice = new Customer();
        dealerHeadoffice.setName("DUMMY_HEADOFFICE");
        when(quotaService.fetchOrCreateQuota(dealerHeadoffice, product, operationalYear, QuotaType.AVAILABLE, lot, multiplier, plantability)).thenReturn(quota);
        when(customerService.getCustomerHeadOffice(any(Customer.class), any(ParticipantTypeEnum.class))).thenReturn(dealerHeadoffice);
        SaleItemProductQuotaAvailableValidationRule saleItemProductQuotaAvailableValidationRule = new SaleItemProductQuotaAvailableValidationRule();
        saleItemProductQuotaAvailableValidationRule.setQuotaService(quotaService);
        saleItemProductQuotaAvailableValidationRule.setCustomerService(customerService);

        //Sale
        Sale sale = new Sale();
        sale.setCustomer(customer);
        SaleItem saleItem = new SaleItem();
        product.setQuotaUsage(QuotaUsageEnum.USE_QUOTA);
        saleItem.setProduct(product);
        saleItem.setSoldQuantity(10l);
        saleItem.setLot(lot);
        saleItem.setPlantabilityId(plantability);
        saleItem.setMultiplier(multiplier);
        saleItem.setCustomerParent(multiplier);
        SaleTemplate saleTemplate = new SaleTemplate();
        Harvest harvest = new Harvest();
        harvest.setOperationalYear(operationalYear);
        saleTemplate.setHarvest(harvest);
        saleItem.setSaleTemplate(saleTemplate);
        sale.setItems(Sets.newHashSet(saleItem));

        //@When
        try {
            saleItemProductQuotaAvailableValidationRule.validate(sale);
            fail("Should throw ValidationException");
        } catch (Exception e) {
            assertThat(e).isInstanceOf(SaleValidationException.class).hasNoCause();
        }
    }

    @Test
    public void given_a_product_that_use_quota_when_validate_if_no_quota_found_validation_fails() throws ValidationException {
        //@Given
        Customer customer = new Customer();
        Product product = new Product();
        product.setDescription("Product Description");
        String lot = "someLot";
        Customer multiplier = new Customer("Multiplier name", null, null, "Sap Code");
        Plantability plantability = new Plantability();
        //Validation rule
        QuotaService quotaService = mock(QuotaService.class);
        OperationalYear operationalYear = new OperationalYear("2013");
        Quota quota = mock(Quota.class);
        CustomerService customerService = mock(CustomerService.class);
        Customer dealerHeadoffice = new Customer();
        dealerHeadoffice.setName("DUMMY_HEADOFFICE");
        when(quota.getBalance()).thenReturn(null);
        when(quotaService.fetchOrCreateQuota(dealerHeadoffice, product, operationalYear, QuotaType.AVAILABLE, lot, multiplier, plantability)).thenReturn(quota);
        when(customerService.getCustomerHeadOffice(any(Customer.class), any(ParticipantTypeEnum.class))).thenReturn(dealerHeadoffice);
        SaleItemProductQuotaAvailableValidationRule saleItemProductQuotaAvailableValidationRule = new SaleItemProductQuotaAvailableValidationRule();
        saleItemProductQuotaAvailableValidationRule.setQuotaService(quotaService);
        saleItemProductQuotaAvailableValidationRule.setCustomerService(customerService);

        //Sale
        Sale sale = new Sale();
        sale.setCustomer(customer);
        SaleItem saleItem = new SaleItem();
        product.setQuotaUsage(QuotaUsageEnum.USE_QUOTA);
        saleItem.setProduct(product);
        saleItem.setSoldQuantity(10l);
        saleItem.setLot(lot);
        saleItem.setPlantabilityId(plantability);
        saleItem.setMultiplier(multiplier);
        saleItem.setCustomerParent(multiplier);
        SaleTemplate saleTemplate = new SaleTemplate();
        Harvest harvest = new Harvest();
        harvest.setOperationalYear(operationalYear);
        saleTemplate.setHarvest(harvest);
        saleItem.setSaleTemplate(saleTemplate);
        sale.setItems(Sets.newHashSet(saleItem));
        sale.setItems(Sets.newHashSet(saleItem));

        //@When
        try {
            saleItemProductQuotaAvailableValidationRule.validate(sale);
            fail("Should throw ValidationException");
        } catch (Exception e) {
            assertThat(e).isInstanceOf(SaleValidationException.class).hasNoCause();
        }
    }

    @Test
    public void given_a_product_that_use_quota_when_validate_if_soldQty_lessTan_uotaBalance_validation_passes() throws ValidationException {
        //@Given
        Customer customer = new Customer();
        Product product = new Product();
        product.setDescription("Product Description");
        String lot = "someLot";
        Customer multiplier = new Customer("Multiplier name", null, null, "Sap Code");
        Plantability plantability = new Plantability();
        //Validation rule
        QuotaService quotaService = mock(QuotaService.class);
        OperationalYear operationalYear = new OperationalYear("2013");
        Quota quota = mock(Quota.class);
        Customer dealerHeadoffice = new Customer();
        dealerHeadoffice.setName("DUMMY_HEADOFFICE");
        CustomerService customerService = mock(CustomerService.class);
        when(quota.getBalance()).thenReturn(BigDecimal.TEN);
        when(quotaService.fetchOrCreateQuota(dealerHeadoffice, product, operationalYear, QuotaType.AVAILABLE, lot, multiplier, plantability)).thenReturn(quota);
        when(customerService.getCustomerHeadOffice(any(Customer.class), any(ParticipantTypeEnum.class))).thenReturn(dealerHeadoffice);
        SaleItemProductQuotaAvailableValidationRule saleItemProductQuotaAvailableValidationRule = new SaleItemProductQuotaAvailableValidationRule();
        saleItemProductQuotaAvailableValidationRule.setQuotaService(quotaService);
        saleItemProductQuotaAvailableValidationRule.setCustomerService(customerService);

        //Sale
        Sale sale = new Sale();
        sale.setCustomer(customer);
        SaleItem saleItem = new SaleItem();
        product.setQuotaUsage(QuotaUsageEnum.USE_QUOTA);
        saleItem.setProduct(product);
        saleItem.setSoldQuantity(10l);
        saleItem.setLot(lot);
        saleItem.setPlantabilityId(plantability);
        saleItem.setMultiplier(multiplier);
        saleItem.setCustomerParent(multiplier);
        SaleTemplate saleTemplate = new SaleTemplate();
        Harvest harvest = new Harvest();
        harvest.setOperationalYear(operationalYear);
        saleTemplate.setHarvest(harvest);
        saleItem.setSaleTemplate(saleTemplate);
        sale.setItems(Sets.newHashSet(saleItem));
        sale.setItems(Sets.newHashSet(saleItem));

        //@When
        try {
            saleItemProductQuotaAvailableValidationRule.validate(sale);
        } catch (Exception e) {
            fail("Should not throw Exception");
        }
    }
}
