package com.monsanto.brazilvaluecapture.seedsale.billing.service;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.stub;

import java.math.BigDecimal;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.SortedSet;
import java.util.TreeSet;

import junit.framework.Assert;

import org.junit.BeforeClass;
import org.junit.Test;

import com.monsanto.brazilvaluecapture.core.base.SystemTestFixture;
import com.monsanto.brazilvaluecapture.core.foundation.service.BusinessException;
import com.monsanto.brazilvaluecapture.seedsale.billing.model.bean.Billing;
import com.monsanto.brazilvaluecapture.seedsale.billing.model.bean.CreditStatus;
import com.monsanto.brazilvaluecapture.seedsale.billing.model.bean.PaymentStatus;
import com.monsanto.brazilvaluecapture.seedsale.billing.model.bean.PossiblePayment;
import com.monsanto.brazilvaluecapture.seedsale.billing.model.bean.Royalty;
import com.monsanto.brazilvaluecapture.seedsale.billing.service.impl.BillingFactory;
import com.monsanto.brazilvaluecapture.seedsale.billing.service.impl.BillingIndexer;
import com.monsanto.brazilvaluecapture.seedsale.sale.SaleTestFixture;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.Sale;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.SaleItem;
import com.monsanto.brazilvaluecapture.seedsale.template.model.bean.Price.ReleaseCreditTypeEnum;
import com.monsanto.brazilvaluecapture.seedsale.template.model.bean.SaleTemplateBillAgainstEnum;
import com.monsanto.brazilvaluecapture.seedsale.template.model.bean.SaleTemplateBillingMethodEnum;

public class Billing_UT {

	@Test
	public void given_a_billing_with_onePossiblePayment_when_pay_after_last_due_date_then_should_throw_exception() {
		Billing billing = createBillingWithOneItemWithDueDateInAugust();
		
		billing.pay(SaleTestFixture.DECEMBER, BillingHelper.PARCIAL_PAYMENT_VALUE_TO_RECEIVE, true);
		
		BillingHelper.assertLastPayment(SaleTestFixture.DECEMBER, BillingHelper.PARCIAL_PAYMENT_VALUE_TO_RECEIVE, null, null, billing.getPayments());
	}
	
	@Test
	public void given_a_billing_parcial_paid_then_isOverdueAt_should_return_false() {
		Billing billing = createBillingWithOneItemWithDueDateInAugust();
		billing.setPaymentStatus(PaymentStatus.PARCIAL_PAID);
		
		Assert.assertFalse("Billing should NEVER overdue", billing.isOverdueAt(SaleTestFixture.DECEMBER));
	}
	
	@Test
	public void given_a_billing_canceled_then_isOverdueAt_should_return_false() {
		Billing billing = createBillingWithOneItemWithDueDateInAugust();
		billing.setPaymentStatus(PaymentStatus.CANCELLED);
		
		Assert.assertFalse("Billing should NEVER overdue", billing.isOverdueAt(SaleTestFixture.DECEMBER));
	}
	
	@Test
	public void given_a_billing_fully_paid_then_isOverdueAt_should_return_false() {
		Billing billing = createBillingWithOneItemWithDueDateInAugust();
		billing.setPaymentStatus(PaymentStatus.FULLY_PAID);
		
		Assert.assertFalse("Billing should NEVER overdue", billing.isOverdueAt(SaleTestFixture.DECEMBER));
	}
	
	@Test
	public void given_a_billing_with_onePaymentDate_at_newDate_when_parameterDate_equals_newDate_then_isOverdueAt_should_return_false() {
		Billing billing = BillingHelper.createBillingWithOneItemForManyDueDates(systemTestFixture, saleTestFixture, mockedBillingIndexer, new Date());
		Assert.assertFalse("Billing should NOT overdue", billing.isOverdueAt(new Date()));
	}
	
	@Test
	public void given_a_billing_with_onePaymentDate_when_parameterDate_equals_at_last_possiblePaymentDate_then_isOverdueAt_should_return_false() {
		Billing billing = createBillingWithOneItemWithDueDateInAugust();
		Assert.assertFalse("Billing should NOT overdue at august", billing.isOverdueAt(SaleTestFixture.AUGUST));
	}
	
	@Test
	public void given_a_billing_with_onePaymentDate_when_parameterDate_exceeds_last_possiblePaymentDate_then_isOverdueAt_should_return_true() {
		Billing billing = createBillingWithOneItemWithDueDateInAugust();
		Assert.assertTrue("Billing should overdue at december", billing.isOverdueAt(SaleTestFixture.DECEMBER));
	}
	
	@Test
	public void given_a_billing_with_onePaymentDate_when_parameterDate_is_less_than_possiblePaymentDate_then_isOverdueAt_should_return_false() {
		Billing billing = createBillingWithOneItemWithDueDateInAugust();
		Assert.assertFalse("Billing should NOT overdue at april", billing.isOverdueAt(SaleTestFixture.APRIL));
	}
	
	@Test
	public void given_sale_with_two_groupable_saleItems_billingFactory_should_return_one_billing() {
		SaleItem oneMockedSaleItem = BillingHelper.createMockedSaleItem(systemTestFixture, saleTestFixture, systemTestFixture.intacta, saleTestFixture.harvest2009SoyMonsanto);
		stub(oneMockedSaleItem.getReleaseCreditType()).toReturn(ReleaseCreditTypeEnum.MANUALLY);
		Set<SaleItem> saleItems = BillingHelper.createSaleItemSet(oneMockedSaleItem, oneMockedSaleItem);
		Sale mockedSale = BillingHelper.createMockedSale(saleItems);

		List<Billing> billings = billingFactory.buildBilling(mockedSale);
		
		Assert.assertEquals("Should have 1 billing", 1, billings.size());
		BillingHelper.assertBilling(1, 1, SaleTemplateBillingMethodEnum.BANKSLIP, SaleTemplateBillAgainstEnum.GROWER, SaleTestFixture.AUGUST, CreditStatus.WAITING_FOR_RELEASE_MANUAL, billings.get(0));
		Assert.assertEquals("Billing Channel is wrong", BillingHelper.monsantoBillingChannel, billings.get(0).getChannel());
	}
	
	@Test
	public void given_sale_with_one_saleItem_of_bayer_billingFactory_should_return_one_billing_without_billlingChannel() {
		SaleItem oneMockedSaleItem = BillingHelper.createMockedSaleItem(systemTestFixture, saleTestFixture, systemTestFixture.intacta, saleTestFixture.harvest2009SoyMonsanto);
		stub(oneMockedSaleItem.getCompany()).toReturn(systemTestFixture.companyBayerBrazil);
		stub(oneMockedSaleItem.getReleaseCreditType()).toReturn(ReleaseCreditTypeEnum.AUTOMATICALLY);
		Set<SaleItem> saleItems = BillingHelper.createSaleItemSet(oneMockedSaleItem);
		Sale mockedSale = BillingHelper.createMockedSale(saleItems);
		
		List<Billing> billings = billingFactory.buildBilling(mockedSale);
		
		Assert.assertEquals("Should have 1 billing", 1, billings.size());
		BillingHelper.assertBilling(1, 1, SaleTemplateBillingMethodEnum.BANKSLIP, SaleTemplateBillAgainstEnum.GROWER, SaleTestFixture.AUGUST, CreditStatus.RELEASED_AUTOMATICALLY, billings.get(0));
		Assert.assertNull("Billing Channel is wrong", billings.get(0).getChannel());
	}
	
	@Test
	public void given_sale_with_two_saleItems_with_diferent_companies_billingFactory_should_return_two_billings() {
		SaleItem oneMockedItem = BillingHelper.createMockedSaleItem(systemTestFixture, saleTestFixture, systemTestFixture.intacta, saleTestFixture.harvest2009SoyMonsanto);
		SaleItem mockedItemFromAnotherCompany = BillingHelper.createMockedSaleItem(systemTestFixture, saleTestFixture, systemTestFixture.intacta, saleTestFixture.harvest2009SoyMonsanto);
		stub(mockedItemFromAnotherCompany.getCompany()).toReturn(systemTestFixture.companyBayerBrazil);
		Set<SaleItem> saleItems = BillingHelper.createSaleItemSet(oneMockedItem, mockedItemFromAnotherCompany);
		Sale mockedSale = BillingHelper.createMockedSale(saleItems);
		
		List<Billing> billings = billingFactory.buildBilling(mockedSale);
		
		Assert.assertEquals("Should have 2 billing", 2, billings.size());
		BillingHelper.assertBilling(1, 1, SaleTemplateBillingMethodEnum.BANKSLIP, SaleTemplateBillAgainstEnum.GROWER, SaleTestFixture.AUGUST, CreditStatus.ON_PAYMENT, billings.get(0));
		BillingHelper.assertBilling(1, 1, SaleTemplateBillingMethodEnum.BANKSLIP, SaleTemplateBillAgainstEnum.GROWER, SaleTestFixture.AUGUST, CreditStatus.ON_PAYMENT, billings.get(1));
	}

	@Test
	public void given_sale_with_two_saleItems_with_diferent_billingMethods_billingFactory_should_return_two_billings() {
		SaleItem oneMockedItem = BillingHelper.createMockedSaleItem(systemTestFixture, saleTestFixture, systemTestFixture.intacta, saleTestFixture.harvest2009SoyMonsanto);
		SaleItem mockedItemFromAnotherCompany = BillingHelper.createMockedSaleItem(systemTestFixture, saleTestFixture, systemTestFixture.intacta, saleTestFixture.harvest2009SoyMonsanto);
		stub(mockedItemFromAnotherCompany.getBillingMethod()).toReturn(SaleTemplateBillingMethodEnum.DIRECT);
		Set<SaleItem> saleItems = BillingHelper.createSaleItemSet(oneMockedItem, mockedItemFromAnotherCompany);
		Sale mockedSale = BillingHelper.createMockedSale(saleItems);
		
		List<Billing> billings = billingFactory.buildBilling(mockedSale);
		
		Assert.assertEquals("Should have 2 billing", 2, billings.size());
		BillingHelper.assertBilling(1, 1, SaleTemplateBillingMethodEnum.BANKSLIP, SaleTemplateBillAgainstEnum.GROWER, SaleTestFixture.AUGUST, CreditStatus.ON_PAYMENT, billings.get(0));
		BillingHelper.assertBilling(1, 1, SaleTemplateBillingMethodEnum.DIRECT, SaleTemplateBillAgainstEnum.GROWER, SaleTestFixture.AUGUST, CreditStatus.ON_PAYMENT, billings.get(1));
	}

	@Test
	public void given_sale_with_two_saleItems_with_diferent_billingRecipients_billingFactory_should_return_two_billings() {
		SaleItem oneMockedItem = BillingHelper.createMockedSaleItem(systemTestFixture, saleTestFixture, systemTestFixture.intacta, saleTestFixture.harvest2009SoyMonsanto);
		SaleItem mockedItemFromAnotherCompany = BillingHelper.createMockedSaleItem(systemTestFixture, saleTestFixture, systemTestFixture.intacta, saleTestFixture.harvest2009SoyMonsanto);
		stub(mockedItemFromAnotherCompany.getBillingRecipient()).toReturn(SaleTemplateBillAgainstEnum.DISTRIBUTOR);
		Set<SaleItem> saleItems = BillingHelper.createSaleItemSet(oneMockedItem, mockedItemFromAnotherCompany);
		Sale mockedSale = BillingHelper.createMockedSale(saleItems);
		
		List<Billing> billings = billingFactory.buildBilling(mockedSale);
		
		Assert.assertEquals("Should have 2 billing", 2, billings.size());
		BillingHelper.assertBilling(1, 1, SaleTemplateBillingMethodEnum.BANKSLIP, SaleTemplateBillAgainstEnum.DISTRIBUTOR, SaleTestFixture.AUGUST, CreditStatus.ON_PAYMENT, billings.get(0));
		BillingHelper.assertBilling(1, 1, SaleTemplateBillingMethodEnum.BANKSLIP, SaleTemplateBillAgainstEnum.GROWER, SaleTestFixture.AUGUST, CreditStatus.ON_PAYMENT, billings.get(1));
	}
	
	@Test
	public void given_sale_with_two_billings_when_bankslip_and_duedate_greater_than_today_and_pendent_pay_should_return_billet_valid() {
		SortedSet<PossiblePayment> payments = BillingHelper.createPaymentSet(SaleTestFixture.FEBRUARY, SaleTestFixture.DATE_NOW);
		SaleItem oneMockedSaleItem = BillingHelper.createMockedSaleItem(systemTestFixture, saleTestFixture, systemTestFixture.intacta, saleTestFixture.harvest2009SoyMonsanto);
		stub(oneMockedSaleItem.getPrices()).toReturn(payments);
		mockedBillingIndexer = mock(BillingIndexer.class);
		stub(mockedBillingIndexer.getBillingMethod()).toReturn(SaleTemplateBillingMethodEnum.BANKSLIP);
		stub(mockedBillingIndexer.getBillingRecipient()).toReturn(SaleTemplateBillAgainstEnum.GROWER);
		stub(mockedBillingIndexer.getDueDate()).toReturn(SaleTestFixture.DATE_NOW);
		stub(mockedBillingIndexer.getCreditStatus()).toReturn(CreditStatus.ON_PAYMENT);
		Billing aBilling = new Billing(BillingHelper.createSaleItemSet(oneMockedSaleItem), mockedBillingIndexer);
		
		
		Assert.assertNotNull("Not null", aBilling);
		Assert.assertTrue("Has billet valid", aBilling.getHasBilletValid());
		BillingHelper.assertBilling(2, 1, SaleTemplateBillingMethodEnum.BANKSLIP, SaleTemplateBillAgainstEnum.GROWER,  SaleTestFixture.DATE_NOW, CreditStatus.ON_PAYMENT, aBilling);
	}
	
	@Test
	public void given_sale_with_two_billings_when_bankslip_and_duedate_greater_than_today_and_pendent_pay_should_return_billet_invalid() {
		SortedSet<PossiblePayment> payments = BillingHelper.createPaymentSet(SaleTestFixture.FEBRUARY, SaleTestFixture.APRIL);
		SaleItem oneMockedSaleItem = BillingHelper.createMockedSaleItem(systemTestFixture, saleTestFixture, systemTestFixture.intacta, saleTestFixture.harvest2009SoyMonsanto);
		stub(oneMockedSaleItem.getPrices()).toReturn(payments);
		mockedBillingIndexer = mock(BillingIndexer.class);
		stub(mockedBillingIndexer.getBillingMethod()).toReturn(SaleTemplateBillingMethodEnum.BANKSLIP);
		stub(mockedBillingIndexer.getBillingRecipient()).toReturn(SaleTemplateBillAgainstEnum.GROWER);
		stub(mockedBillingIndexer.getDueDate()).toReturn(SaleTestFixture.APRIL);
		stub(mockedBillingIndexer.getCreditStatus()).toReturn(CreditStatus.ON_PAYMENT);
		Billing aBilling = new Billing(BillingHelper.createSaleItemSet(oneMockedSaleItem), mockedBillingIndexer);
		
		
		Assert.assertNotNull("Not null", aBilling);
		Assert.assertFalse("Has billet invalid", aBilling.getHasBilletValid());
		BillingHelper.assertBilling(2, 1, SaleTemplateBillingMethodEnum.BANKSLIP, SaleTemplateBillAgainstEnum.GROWER, SaleTestFixture.APRIL, CreditStatus.ON_PAYMENT, aBilling);
	}

	@Test 
	public void given_two_saleItems_with_fix_value_should_return_one_billing_with_sum_of_credit_royaltyValue_and_soldQuantity() {
		SaleItem oneMockedSaleItem = BillingHelper.createMockedSaleItem(systemTestFixture, saleTestFixture, systemTestFixture.intacta, saleTestFixture.harvest2009SoyMonsanto);
		SaleItem anotherMockedSaleItem = BillingHelper.createMockedSaleItem(systemTestFixture, saleTestFixture, systemTestFixture.intacta, saleTestFixture.harvest2009SoyMonsanto);
		stub(anotherMockedSaleItem.getTotalCreditValue()).toReturn(8L);
		stub(anotherMockedSaleItem.getTotalRoyaltyValue()).toReturn(new BigDecimal(80L));
		stub(anotherMockedSaleItem.getSoldQuantity()).toReturn(800L);
		
		Billing aBilling = new Billing(BillingHelper.createSaleItemSet(oneMockedSaleItem, anotherMockedSaleItem), mockedBillingIndexer);
		
		Royalty theRoyalty = aBilling.getRoyalties().iterator().next();
		Assert.assertNotNull("Should have a royalty", theRoyalty);
		Assert.assertEquals("Royalty should have 13 units of credit", 13, theRoyalty.getCreditQuantity().intValue());
		Assert.assertEquals("Royalty should have 740 units of royalty", 740, theRoyalty.getRoyaltyCost().intValue());
		Assert.assertEquals("Royalty should have 1300 units of sold seed", 1300, theRoyalty.getSoldSeedQuantityValue().intValue());
	}

	@Test
	public void given_saleItem_with_fix_value_should_return_one_billing_with_one_royalty_and_one_payment_date() {
		SaleItem saleItemMock = BillingHelper.createMockedSaleItem(systemTestFixture, saleTestFixture, systemTestFixture.intacta, saleTestFixture.harvest2009SoyMonsanto);
		Billing aBilling = new Billing(BillingHelper.createSaleItemSet(saleItemMock), mockedBillingIndexer);
		
		Assert.assertEquals("Should return 1 payment", 1, aBilling.countPayments());
		Assert.assertEquals("Should return 1 royalty", 1, aBilling.countRoyalties());
	}
	
	@Test
	public void given_saleItem_with_NoValue_price_should_return_one_billing_with_one_royalty_and_payment_status_noValue() {
		SaleItem saleItemMock = BillingHelper.createMockedSaleItem(systemTestFixture, saleTestFixture, systemTestFixture.intacta, saleTestFixture.harvest2009SoyMonsanto);
		stub(saleItemMock.getPrices()).toReturn(new TreeSet<PossiblePayment>());
		
		Billing aBilling = new Billing(BillingHelper.createSaleItemSet(saleItemMock), mockedBillingIndexer);
		
		Assert.assertEquals("Should return 1 royalty", 1, aBilling.countRoyalties());
		Assert.assertEquals("Should return 0 payment", 0, aBilling.countPayments());
		Assert.assertEquals("Billing should be in NO_VALUE status", PaymentStatus.NO_VALUE, aBilling.getPaymentStatus());
	}

	@Test
	public void given_two_saleItems_with_fix_value_and_different_technologies_return_one_billing_with_two_royalties() {
		SaleItem oneMockedSaleItem = BillingHelper.createMockedSaleItem(systemTestFixture, saleTestFixture, systemTestFixture.intacta, saleTestFixture.harvest2009SoyMonsanto);
		SaleItem anotherMockedSaleItem = BillingHelper.createMockedSaleItem(systemTestFixture, saleTestFixture, systemTestFixture.rr, saleTestFixture.harvest2009SoyMonsanto);
		//stub(anotherMockedSaleItem.getTechnology()).toReturn(systemTestFixture.rr);
		
		Billing aBilling = new Billing(BillingHelper.createSaleItemSet(oneMockedSaleItem, anotherMockedSaleItem), mockedBillingIndexer);
		
		Assert.assertEquals("Should have 2 royalties", 2, aBilling.countRoyalties());
	}
	
	@Test
	public void given_two_saleItems_with_no_value_and_same_technologies_return_one_billing_with_full_paid() {
		SaleItem oneMockedSaleItem = BillingHelper.createMockedSaleItem(systemTestFixture, saleTestFixture, systemTestFixture.bt, saleTestFixture.harvest2009SoyMonsanto);
		SaleItem anotherMockedSaleItem = BillingHelper.createMockedSaleItem(systemTestFixture, saleTestFixture, systemTestFixture.bt, saleTestFixture.harvest2009SoyMonsanto);
		Billing aBilling = new Billing(BillingHelper.createSaleItemSet(oneMockedSaleItem, anotherMockedSaleItem), mockedBillingIndexer);
		
		Assert.assertEquals("Should have 1 royalties", 1, aBilling.countRoyalties());
	}

	@Test
	public void given_one_saleItem_with_two_due_dates_return_one_billing_with_two_payments() {
		SortedSet<PossiblePayment> payments = BillingHelper.createPaymentSet(SaleTestFixture.FEBRUARY, SaleTestFixture.AUGUST);
		SaleItem oneMockedSaleItem = BillingHelper.createMockedSaleItem(systemTestFixture, saleTestFixture, systemTestFixture.intacta, saleTestFixture.harvest2009SoyMonsanto);
		stub(oneMockedSaleItem.getPrices()).toReturn(payments);
		
		Billing aBilling = new Billing(BillingHelper.createSaleItemSet(oneMockedSaleItem), mockedBillingIndexer);
		
		Assert.assertEquals("Should have 2 payments", 2, aBilling.countPayments());
	}
	
	
	@Test
	public void given_one_saleItem_with_two_due_dates_return_one_billing_with_two_payments_and_values_diffs() {
		Billing aBilling = createMockedBilling();
		
		Assert.assertEquals("Should have 2 payments", 2, aBilling.countPayments());
		Assert.assertEquals("Should have last payment with value", BigDecimal.TEN, aBilling.getDueValue());
	}
	
	@Test(expected=IllegalStateException.class)
	public void given_no_saleItems_billing_throw_exception() {
		new Billing(new HashSet<SaleItem>(), mockedBillingIndexer);
	}
	
	@Test(expected=IllegalArgumentException.class)
	public void create_royalty_without_technology_throw_exception() {
		new Royalty(null, null, saleTestFixture.harvest2009SoyMonsanto);
	}
	
	@Test(expected=IllegalArgumentException.class)
	public void create_royalty_without_harvest_throw_exception() {
		new Royalty(systemTestFixture.intacta, null, null);
	}
	
	@Test
	public void given_a_cancelled_billing_isCancellableShouldReturnFalse() {
		Billing canceledBilling = createMockedBilling();
		canceledBilling.setPaymentStatus(PaymentStatus.CANCELLED);
		Assert.assertFalse("IsCancellable should return false", canceledBilling.isCancellable());
	}
	
	@Test
	public void given_a_paid_billing_isCancellableShouldReturnFalse() {
		Billing paidBilling = createMockedBilling();
		paidBilling.setPaymentStatus(PaymentStatus.FULLY_PAID);
		Assert.assertFalse("IsCancellable should return false", paidBilling.isCancellable());
	}
	
	@Test
	public void given_a_notPaid_billing_isCancellableShouldReturnTrue() {
		Billing notPaidBilling = createMockedBilling();
		notPaidBilling.setPaymentStatus(PaymentStatus.NOT_PAID);
		Assert.assertTrue("IsCancellable should return true", notPaidBilling.isCancellable());
	}
	
	@Test
	public void given_a_noValue_billing_isCancellableShouldReturnTrue() {
		Billing noValueBilling = createMockedBilling();
		noValueBilling.setPaymentStatus(PaymentStatus.NO_VALUE);
		Assert.assertTrue("IsCancellable should return true", noValueBilling.isCancellable());
	}

	private Billing createMockedBilling() {
		SaleItem oneMockedSaleItem = BillingHelper.createMockedSaleItem(systemTestFixture, saleTestFixture, systemTestFixture.intacta, saleTestFixture.harvest2009SoyMonsanto);
		stub(oneMockedSaleItem.getPrices()).toReturn(createPaymentWithTwoItem(SaleTestFixture.JANUARY,SaleTestFixture.FEBRUARY));
		
		return new Billing(BillingHelper.createSaleItemSet(oneMockedSaleItem), mockedBillingIndexer);
	}

	@Test
	public void when_billing_not_has_a_paid_possiblePayment_getPaid_should_return_a_possiblePayment_paid() {
		Billing aBilling = createMockedBilling();
		
		Assert.assertEquals("aBilling should have two payments.", aBilling.getPayments().size(), 2);
		Assert.assertNull("getPaid should return one possiblePayment of payments.", aBilling.getPossiblePaymentPaid());
	}
	
	@Test
	public void getRoyalty_should_return_sum_of_royaltyCost_of_royalties() {
		SaleItem oneMockedSaleItem = BillingHelper.createMockedSaleItem(systemTestFixture, saleTestFixture, systemTestFixture.intacta, saleTestFixture.harvest2009SoyMonsanto);
		SaleItem anotherMockedSaleItem = BillingHelper.createMockedSaleItem(systemTestFixture, saleTestFixture, systemTestFixture.intacta, saleTestFixture.harvest2009SoyMonsanto);
		stub(anotherMockedSaleItem.getTechnology()).toReturn(systemTestFixture.rr);
		
		Billing aBilling = new Billing(BillingHelper.createSaleItemSet(oneMockedSaleItem, anotherMockedSaleItem), mockedBillingIndexer);
		
		BigDecimal totalRoyalties = oneMockedSaleItem.getTotalRoyaltyValue().add(anotherMockedSaleItem.getTotalRoyaltyValue());
		
		Assert.assertEquals("aBilling should have two royalties.", aBilling.getRoyalties().size(), 2);
		Assert.assertEquals("getRoyalty should be equal the sum of all royalties.", totalRoyalties, aBilling.getTotalRoyalty());
	}

	private SortedSet<PossiblePayment> createPaymentWithTwoItem(Date date1, Date date2){
		SortedSet<PossiblePayment> paymentList = new TreeSet<PossiblePayment>();
		PossiblePayment dueDate1 = new PossiblePayment(date1);
		dueDate1.setReceiptValue(BigDecimal.ONE);
		PossiblePayment dueDate2 = new PossiblePayment(date2);
		dueDate2.setReceiptValue(BigDecimal.TEN);
		paymentList.add(dueDate1);
		paymentList.add(dueDate2);
		return paymentList;
	}

	private Billing createBillingWithOneItemWithDueDateInAugust() {
		return BillingHelper.createBillingWithOneItemForManyDueDates(systemTestFixture, saleTestFixture, mockedBillingIndexer, SaleTestFixture.AUGUST);
	}
	
	private static SystemTestFixture systemTestFixture;
	private static SaleTestFixture saleTestFixture;
	private static BillingIndexer mockedBillingIndexer;
	private static BillingFactory billingFactory;
	
	@BeforeClass
	public static void onlyOnce() throws BusinessException {
		systemTestFixture = new SystemTestFixture();
		saleTestFixture = new SaleTestFixture(systemTestFixture);
		mockedBillingIndexer = mock(BillingIndexer.class);
		billingFactory = new BillingFactory();
	}
	
	@Test
	public void given_a_billing_with_three_sale_items_from_different_harvests_and_same_technology_should_return_three_royalties() {
		SaleItem mockedSaleItemOne = BillingHelper.createMockedSaleItem(systemTestFixture, saleTestFixture, systemTestFixture.intacta, saleTestFixture.harvest2009SoyMonsanto);
		SaleItem mockedSaleItemTwo = BillingHelper.createMockedSaleItem(systemTestFixture, saleTestFixture, systemTestFixture.intacta, saleTestFixture.harvest2011SoyMonsanto);
		SaleItem mockedSaleItemThree = BillingHelper.createMockedSaleItem(systemTestFixture, saleTestFixture, systemTestFixture.intacta, saleTestFixture.harvestSoyMonsanto2012);
		
		Billing billing = new Billing(BillingHelper.createSaleItemSet(mockedSaleItemOne, mockedSaleItemTwo, mockedSaleItemThree), mockedBillingIndexer);
		
		Assert.assertEquals(3, billing.getRoyalties().size());
	}
	
	@Test
	public void given_a_billing_with_three_sale_items_from_different_technologies_and_same_harvests_should_return_three_royalties() {
		SaleItem mockedSaleItemOne = BillingHelper.createMockedSaleItem(systemTestFixture, saleTestFixture, systemTestFixture.intacta, saleTestFixture.harvest2011SoyMonsanto);
		SaleItem mockedSaleItemTwo = BillingHelper.createMockedSaleItem(systemTestFixture, saleTestFixture, systemTestFixture.rr, saleTestFixture.harvest2011SoyMonsanto);
		SaleItem mockedSaleItemThree = BillingHelper.createMockedSaleItem(systemTestFixture, saleTestFixture, systemTestFixture.bt, saleTestFixture.harvest2011SoyMonsanto);
		
		Billing billing = new Billing(BillingHelper.createSaleItemSet(mockedSaleItemOne, mockedSaleItemTwo, mockedSaleItemThree), mockedBillingIndexer);
		
		Assert.assertEquals(3, billing.getRoyalties().size());
	}
	
	@Test
	public void given_a_billing_with_duplicated_sale_item_should_return_one_royalty() {
		SaleItem mockedSaleItemOne = BillingHelper.createMockedSaleItem(systemTestFixture, saleTestFixture, systemTestFixture.intacta, saleTestFixture.harvest2011SoyMonsanto);
		
		Billing billing = new Billing(BillingHelper.createSaleItemSet(mockedSaleItemOne, mockedSaleItemOne), mockedBillingIndexer);
		
		Assert.assertEquals(1, billing.getRoyalties().size());
	}
	
	@Test
	public void given_sale_with_two_saleItem_same_saleTemplate_ERP_of_billingFactory_should_return_one_billing() {
		SaleItem oneMockedSaleItem = BillingHelper.createMockedSaleItem(systemTestFixture, saleTestFixture, systemTestFixture.intacta, saleTestFixture.harvest2009SoyMonsanto);
		stub(oneMockedSaleItem.getBillingMethod()).toReturn(SaleTemplateBillingMethodEnum.ERP);
		Set<SaleItem> saleItems = BillingHelper.createSaleItemSet(oneMockedSaleItem, oneMockedSaleItem);
		Sale mockedSale = BillingHelper.createMockedSale(saleItems);
		
		List<Billing> billings = billingFactory.buildBilling(mockedSale);
		
		Assert.assertEquals("Should have 1 billing", 1, billings.size());
		BillingHelper.assertBilling(1, 1, SaleTemplateBillingMethodEnum.ERP, SaleTemplateBillAgainstEnum.GROWER, SaleTestFixture.AUGUST, CreditStatus.ON_PAYMENT, billings.get(0));
		Assert.assertNull("Billing Channel is wrong", billings.get(0).getChannel());
	}
	
	@Test
	public void given_sale_with_two_saleItem_same_saleTemplate_ERP_and_matrix_different_of_billingFactory_should_return_two_billing() {
		SaleItem oneMockedSaleItem = BillingHelper.createMockedSaleItem(systemTestFixture, saleTestFixture, systemTestFixture.intacta, saleTestFixture.harvest2009SoyMonsanto);
		stub(oneMockedSaleItem.getBillingMethod()).toReturn(SaleTemplateBillingMethodEnum.ERP);
		stub(oneMockedSaleItem.getCustomerParent()).toReturn(saleTestFixture.affiliate);
		
		SaleItem twoMockedSaleItem = BillingHelper.createMockedSaleItem(systemTestFixture, saleTestFixture, systemTestFixture.intacta, saleTestFixture.harvest2009SoyMonsanto);
		stub(twoMockedSaleItem.getBillingMethod()).toReturn(SaleTemplateBillingMethodEnum.ERP);
		stub(twoMockedSaleItem.getCustomerParent()).toReturn(saleTestFixture.matrixCargil);
		
		Set<SaleItem> saleItems = BillingHelper.createSaleItemSet(oneMockedSaleItem, twoMockedSaleItem);
		Sale mockedSale = BillingHelper.createMockedSale(saleItems);
		
		List<Billing> billings = billingFactory.buildBilling(mockedSale);
		
		Assert.assertEquals("Should have 1 billing", 2, billings.size());
		BillingHelper.assertBilling(1, 1, SaleTemplateBillingMethodEnum.ERP, SaleTemplateBillAgainstEnum.GROWER, SaleTestFixture.AUGUST, CreditStatus.ON_PAYMENT, billings.get(0));
		Assert.assertNull("Billing Channel is wrong", billings.get(0).getChannel());
		
		BillingHelper.assertBilling(1, 1, SaleTemplateBillingMethodEnum.ERP, SaleTemplateBillAgainstEnum.GROWER, SaleTestFixture.AUGUST, CreditStatus.ON_PAYMENT, billings.get(1));
		Assert.assertNull("Billing Channel is wrong", billings.get(1).getChannel());
	}
	
	@Test
	public void given_sale_with_two_saleItem_different_saleTemplate_ERP_and_same_matrix_of_billingFactory_should_return_two_billing() {
		SaleItem oneMockedSaleItem = BillingHelper.createMockedSaleItem(systemTestFixture, saleTestFixture, systemTestFixture.intacta, saleTestFixture.harvest2009SoyMonsanto);
		stub(oneMockedSaleItem.getBillingMethod()).toReturn(SaleTemplateBillingMethodEnum.ERP);
		stub(oneMockedSaleItem.getCustomerParent()).toReturn(saleTestFixture.matrixCargil);
		
		SaleItem twoMockedSaleItem = BillingHelper.createMockedSaleItem(systemTestFixture, saleTestFixture, systemTestFixture.intacta, saleTestFixture.harvest2009SoyMonsanto, saleTestFixture.templateByExpirationDateWithDueDateRange);
		stub(twoMockedSaleItem.getBillingMethod()).toReturn(SaleTemplateBillingMethodEnum.ERP);
		stub(twoMockedSaleItem.getCustomerParent()).toReturn(saleTestFixture.matrixCargil);
		
		Set<SaleItem> saleItems = BillingHelper.createSaleItemSet(oneMockedSaleItem, twoMockedSaleItem);
		Sale mockedSale = BillingHelper.createMockedSale(saleItems);
		
		List<Billing> billings = billingFactory.buildBilling(mockedSale);
		
		Assert.assertEquals("Should have 1 billing", 2, billings.size());
		BillingHelper.assertBilling(1, 1, SaleTemplateBillingMethodEnum.ERP, SaleTemplateBillAgainstEnum.GROWER, SaleTestFixture.AUGUST, CreditStatus.ON_PAYMENT, billings.get(0));
		Assert.assertNull("Billing Channel is wrong", billings.get(0).getChannel());
		
		BillingHelper.assertBilling(1, 1, SaleTemplateBillingMethodEnum.ERP, SaleTemplateBillAgainstEnum.GROWER, SaleTestFixture.AUGUST, CreditStatus.ON_PAYMENT, billings.get(1));
		Assert.assertNull("Billing Channel is wrong", billings.get(1).getChannel());
	}
	
	@Test
	public void given_sale_with_two_saleItem_different_saleTemplate_ERP_and_different_matrix_of_billingFactory_should_return_two_billing() {
		SaleItem oneMockedSaleItem = BillingHelper.createMockedSaleItem(systemTestFixture, saleTestFixture, systemTestFixture.intacta, saleTestFixture.harvest2009SoyMonsanto);
		stub(oneMockedSaleItem.getBillingMethod()).toReturn(SaleTemplateBillingMethodEnum.ERP);
		stub(oneMockedSaleItem.getCustomerParent()).toReturn(saleTestFixture.affiliate);
		
		SaleItem twoMockedSaleItem = BillingHelper.createMockedSaleItem(systemTestFixture, saleTestFixture, systemTestFixture.intacta, saleTestFixture.harvest2009SoyMonsanto, saleTestFixture.templateByExpirationDateWithDueDateRange);
		stub(twoMockedSaleItem.getBillingMethod()).toReturn(SaleTemplateBillingMethodEnum.ERP);
		stub(twoMockedSaleItem.getCustomerParent()).toReturn(saleTestFixture.matrixCargil);
		
		Set<SaleItem> saleItems = BillingHelper.createSaleItemSet(oneMockedSaleItem, twoMockedSaleItem);
		Sale mockedSale = BillingHelper.createMockedSale(saleItems);
		
		List<Billing> billings = billingFactory.buildBilling(mockedSale);
		
		Assert.assertEquals("Should have 1 billing", 2, billings.size());
		BillingHelper.assertBilling(1, 1, SaleTemplateBillingMethodEnum.ERP, SaleTemplateBillAgainstEnum.GROWER, SaleTestFixture.AUGUST, CreditStatus.ON_PAYMENT, billings.get(0));
		Assert.assertNull("Billing Channel is wrong", billings.get(0).getChannel());
		
		BillingHelper.assertBilling(1, 1, SaleTemplateBillingMethodEnum.ERP, SaleTemplateBillAgainstEnum.GROWER, SaleTestFixture.AUGUST, CreditStatus.ON_PAYMENT, billings.get(1));
		Assert.assertNull("Billing Channel is wrong", billings.get(1).getChannel());
	}

    @Test
    public void fully_paid() {
        Billing billing = new Billing();
        billing.setPaymentStatus(PaymentStatus.FULLY_PAID);
        Assert.assertTrue("Billing should be Fully Paid", billing.isFullyPaid());
    }

}
