package com.monsanto.brazilvaluecapture.seedsale.product;

import com.monsanto.brazilvaluecapture.core.base.CountryTestData;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Country;
import com.monsanto.brazilvaluecapture.core.base.model.bean.OperationalYear;
import com.monsanto.brazilvaluecapture.seedsale.harvest.HarvestTestData;
import com.monsanto.brazilvaluecapture.seedsale.product.model.bean.Region;
import com.monsanto.brazilvaluecapture.seedsale.product.model.dao.RegionProductivityDAO;
import com.monsanto.brazilvaluecapture.seedsale.product.model.dao.impl.RegionProductivityDAOImpl;
import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.hibernate.classic.Session;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.util.List;

import static junit.framework.Assert.assertFalse;
import static junit.framework.Assert.assertTrue;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

/**
 * Created by IntelliJ IDEA.
 * User: MEFAZZ
 * Date: 9/9/13
 * Time: 3:13 PM
 * To change this template use File | Settings | File Templates.
 */
public class RegionProductivity_UT {

    private Session mockSession;
    private SessionFactory mockSessionFactory;
    private RegionProductivityDAO regionProductivityDAO;

    @Before
    public void setup() {
        mockSessionFactory = mock(SessionFactory.class);
        mockSession = mock(Session.class);
        when(mockSessionFactory.getCurrentSession()).thenReturn(mockSession);
        regionProductivityDAO = new RegionProductivityDAOImpl(mockSessionFactory);
    }


    @Test
    public void selectRegionProductivityByCountryOperationalYear() {


        Query mockQuery = mock(Query.class);

        when(mockSessionFactory.getCurrentSession()).thenReturn(mockSession);

        when(mockSession.createQuery(anyString())).thenReturn(mockQuery);

        List<Region> regionProductivities = RegionProductivityTestData.createSomeRegionProductivity();

        when(mockQuery.list()).thenReturn(regionProductivities);

        List<Region> list = regionProductivityDAO.getRegionProductivityByCountryOperationalYear(CountryTestData.createBrazil(), HarvestTestData.createABrazilianHarvest().getOperationalYear());

        Assert.assertEquals(regionProductivities, list);

    }


    @Test
    public void selectAlltest() {

        Criteria mockCriteria = mock(Criteria.class);

        when(mockSessionFactory.getCurrentSession()).thenReturn(mockSession);
        when(mockSession.createCriteria(Region.class)).thenReturn(mockCriteria);

        List<Region> regionProductivities = RegionProductivityTestData.createSomeRegionProductivity();

        when(mockCriteria.list()).thenReturn(regionProductivities);

        List<Region> list = regionProductivityDAO.getAll();

        Assert.assertEquals(regionProductivities, list);

    }

    @Test
    public void two_regions_are_equals_if_areTheSameObject(){
        Region region1 = new Region();
        assertTrue(region1.equals(region1));
    }

    @Test
    public void two_regions_are_different_ifHas_different_Country(){
        Country country1 = new Country("country1", "C1");
        Country country2 = new Country("country2", "C2");
        Region region1 = new Region();
        region1.setCountry(country1);
        Region region2 = new Region();
        region2.setCountry(country2);
        assertFalse(region1.equals(region2));
    }

    @Test
    public void two_regions_are_different_ifHas_different_OperationalYear(){
        OperationalYear oy1 = new OperationalYear("2001");
        OperationalYear oy2 = new OperationalYear("2002");
        assertFalse(oy1.equals(oy2));
        Country country = new Country("country1", "C1");
        Region region1 = new Region();
        region1.setCountry(country);
        region1.setOperationalYear(oy1);
        Region region2 = new Region();
        region2.setCountry(country);
        region2.setOperationalYear(oy2);
        assertFalse(region1.equals(region2));
    }

    @Test
    public void two_regions_are_different_ifHas_different_RegionDescription(){
        OperationalYear oy = new OperationalYear("2001");
        Country country = new Country("country1", "C1");
        Region region1 = new Region();
        region1.setRegionDescription("Region1");
        region1.setCountry(country);
        region1.setOperationalYear(oy);
        Region region2 = new Region();
        region2.setRegionDescription("Region2");
        region2.setCountry(country);
        region2.setOperationalYear(oy);
        assertFalse(region1.equals(region2));
    }

    @Test
    public void two_regions_are_equals_ifHas_sameOperationalYear_sameCountry_sameDescription(){
        OperationalYear oy = new OperationalYear("2001");
        Country country = new Country("country1", "C1");
        String description = "Region1";
        Region region1 = new Region();
        region1.setRegionDescription(description);
        region1.setCountry(country);
        region1.setOperationalYear(oy);
        Region region2 = new Region();
        region2.setRegionDescription(description);
        region2.setCountry(country);
        region2.setOperationalYear(oy);
        assertTrue(region1.equals(region2));
    }


}
