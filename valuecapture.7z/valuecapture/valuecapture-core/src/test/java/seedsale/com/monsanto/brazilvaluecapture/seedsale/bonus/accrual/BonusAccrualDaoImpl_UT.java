package com.monsanto.brazilvaluecapture.seedsale.bonus.accrual;

import com.monsanto.brazilvaluecapture.core.wsiconsole.dao.impl.BaseHibernateUnitTest;
import com.monsanto.brazilvaluecapture.seedsale.bonus.accrual.model.bean.BonusAccrualTotalForAccounts;
import com.monsanto.brazilvaluecapture.seedsale.bonus.accrual.model.dao.impl.BonusAccrualDAOImpl;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.math.BigDecimal;
import java.util.Date;
import java.util.HashSet;

import static org.mockito.Mockito.when;

/**
 * Created by AMMUNO on
 * 9/29/2014.
 */
public class BonusAccrualDaoImpl_UT extends BaseHibernateUnitTest {

    private static final Long FIRST_ID_BONUS_ACCOUNT = 15L;
    private static final Long SECOND_ID_BONUS_ACCOUNT = 16L;
    private static final Long THIRD_ID_BONUS_ACCOUNT = 17L;
    private static final Long FOURTH_ID_BONUS_ACCOUNT = 18L;
    private static int NO_RECORDS_TO_UPDATE = 0;
    private static int RECORDS_UPDATED = 4;
    private BonusAccrualDAOImpl bonusAccrualDaoImpl;

    @Before
    public void setUp() {
        bonusAccrualDaoImpl = new BonusAccrualDAOImpl(sessionFactory);
    }

    @Test
    public void testUpdatePostingDateForAccount_WhenAccountListEmpty() {

        BonusAccrualTotalForAccounts bonusAccrualTotalForAccounts = new BonusAccrualTotalForAccounts(BigDecimal.ZERO, new HashSet<Long>(), null);

        int result = bonusAccrualDaoImpl.updatePostingDateForAccount(bonusAccrualTotalForAccounts);

        Assert.assertEquals(result, NO_RECORDS_TO_UPDATE);

    }

    @Test
    public void testUpdatePostingDateForAccount_WhenAccountListHasObjects() {

        HashSet<Long> longs = new HashSet<Long>();

        longs.add(FIRST_ID_BONUS_ACCOUNT);
        longs.add(SECOND_ID_BONUS_ACCOUNT);
        longs.add(THIRD_ID_BONUS_ACCOUNT);
        longs.add(FOURTH_ID_BONUS_ACCOUNT);

        BonusAccrualTotalForAccounts bonusAccrualTotalForAccounts = new BonusAccrualTotalForAccounts(BigDecimal.ZERO, longs, null);

        bonusAccrualTotalForAccounts.setPostingDate(new Date());

        when(query.executeUpdate()).thenReturn(RECORDS_UPDATED);

        int result = bonusAccrualDaoImpl.updatePostingDateForAccount(bonusAccrualTotalForAccounts);

        Assert.assertEquals(result, longs.size());
    }

}
