package com.monsanto.brazilvaluecapture.seedsale.billing;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

import com.monsanto.brazilvaluecapture.seedsale.billing.parser.CnabProcessor_AT;
import com.monsanto.brazilvaluecapture.seedsale.billing.parser.CnabProcessor_UT;
import com.monsanto.brazilvaluecapture.seedsale.billing.parser.ImportedFileException_UT;
import com.monsanto.brazilvaluecapture.seedsale.billing.parser.cancellation.CnabCancellationProcessor_AT;
import com.monsanto.brazilvaluecapture.seedsale.billing.service.BilletTransaction_AT;
import com.monsanto.brazilvaluecapture.seedsale.billing.service.BillingFilter_UT;
import com.monsanto.brazilvaluecapture.seedsale.billing.service.Billing_AT;
import com.monsanto.brazilvaluecapture.seedsale.billing.service.Billing_UT;
import com.monsanto.brazilvaluecapture.seedsale.billing.service.SaleBillingDetails_UT;
import com.monsanto.brazilvaluecapture.seedsale.sale.service.SaleService_AT;


@RunWith(value = Suite.class)
@SuiteClasses(value = { 
		SaleService_AT.class,
		BilletTransaction_AT.class,
		Billing_UT.class,
		Billing_AT.class,
		BillingFilter_UT.class,
		SaleBillingDetails_UT.class,
		CnabProcessor_AT.class, 
		CnabProcessor_UT.class,
		CnabCancellationProcessor_AT.class,
		ImportedFileException_UT.class })
public class SuiteBilling {

}
