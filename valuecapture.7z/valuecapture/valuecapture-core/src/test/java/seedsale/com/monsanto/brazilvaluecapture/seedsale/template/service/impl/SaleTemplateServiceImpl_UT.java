package com.monsanto.brazilvaluecapture.seedsale.template.service.impl;

import static org.fest.reflect.core.Reflection.field;
import static org.junit.Assert.*;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.monsanto.brazilvaluecapture.core.customer.model.bean.Customer;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Technology;
import com.monsanto.brazilvaluecapture.core.foundation.service.BusinessException;
import com.monsanto.brazilvaluecapture.seedsale.harvest.model.bean.Harvest;
import com.monsanto.brazilvaluecapture.seedsale.product.model.bean.Product;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.Sale;
import com.monsanto.brazilvaluecapture.seedsale.template.model.bean.Price;
import com.monsanto.brazilvaluecapture.seedsale.template.model.bean.RoyaltyValue;
import com.monsanto.brazilvaluecapture.seedsale.template.model.bean.SaleTemplate;
import com.monsanto.brazilvaluecapture.seedsale.template.model.dao.SaleTemplateDAO;
import com.monsanto.brazilvaluecapture.seedsale.template.service.SaleTemplateService;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.Mockito;

import java.math.BigDecimal;
import java.util.*;

public class SaleTemplateServiceImpl_UT {

    public static final String SALE_TEMPLATE_DESCRIPTION = "Sale Template Description";
    private SaleTemplateService saleTemplateService;
    @Mock
    private SaleTemplateDAO saleTemplateDAO;

    @Before
    public void setUp(){
        saleTemplateService = new SaleTemplateServiceImpl();
        MockitoAnnotations.initMocks(this);
        field("saleTemplateDAO").ofType(SaleTemplateDAO.class).in(saleTemplateService).set(saleTemplateDAO);
    }

    @Test
    public void testGetSaleTemplatesByHarvestAndSaleTypeShouldCallSaleTemplateDAO_WhenGivenHarvestAndSaleTypes(){
        //@Given
        Harvest harvest = mock(Harvest.class);
        List<Sale.SaleTypeEnum> saleTypes = new ArrayList<Sale.SaleTypeEnum>();
        Sale.SaleTypeEnum saleType = Sale.SaleTypeEnum.DIRECT_SALE;
        saleTypes.add(saleType);
        //@When
        saleTemplateService.getSaleTemplatesByHarvestAndSaleType(harvest, saleTypes);
        //@Then
        verify(saleTemplateDAO).getSaleTemplatesByHarvestAndSaleType(harvest, saleTypes);
    }

    @Test
    public void testFindReferenceDatesShouldCallSaleTemplateDAO_WhenTechnologyAndSaleTemplateAreValid(){
        //@Given
        Technology technology = mock(Technology.class);
        SaleTemplate saleTemplate = mock(SaleTemplate.class);
        //@When
        saleTemplateService.findReferenceDates(technology, saleTemplate);
        //@Then
        verify(saleTemplateDAO).findReferenceDates(technology, saleTemplate);
    }

    @Test
    public void testGetSaleTemplatesForHeadOfficeShouldCallSaleTemplateDAO_WhenGivenHarvestCustomerAndSaleTypes(){
        //@Given
        Harvest harvest = mock(Harvest.class);
        List<Sale.SaleTypeEnum> saleTypes = new ArrayList<Sale.SaleTypeEnum>();
        Sale.SaleTypeEnum saleType = Sale.SaleTypeEnum.DIRECT_SALE;
        saleTypes.add(saleType);
        Customer customer = mock(Customer.class);
        //@When
        saleTemplateService.getSaleTemplatesForHeadOffice(harvest, customer, saleTypes);
        //@Then
        verify(saleTemplateDAO).getSaleTemplatesForHeadOffice(harvest, customer, saleTypes);
    }

    @Test
    public void testSelectByIdWithProductsShouldCallSaleTemplateDAO(){
        //@Given
        Long id = 1L;
        SaleTemplate saleTemplate = mock(SaleTemplate.class);
        //@When
        when(saleTemplate.getProducts()).thenReturn(new HashSet<Product>());
        when(saleTemplateService.selectById(id)).thenReturn(saleTemplate);
        saleTemplateService.selectByIdWithProducts(id);
        //@Then
        verify(saleTemplateDAO).selectById(id);

    }

    @Test
    public void testHasSaleItemsShouldCallSaleTemplateDAO_ForGivenSaleTemplate(){
        //@Given

        SaleTemplate saleTemplate = mock(SaleTemplate.class);
        //@When
        saleTemplateService.hasSaleItens(saleTemplate);
        //@Then
        verify(saleTemplateDAO).hasSaleTemplateOfSaleItem(saleTemplate);

    }

    @Test
    public void testHasSaleTemplateOfDirectSaleForHarvestShouldCallSaleTemplateDAO_ForGivenSaleTemplate(){
        //@Given

        SaleTemplate saleTemplate = mock(SaleTemplate.class);
        //@When
        saleTemplateService.hasSaleTemplateOfDirectSaleForHarvest(saleTemplate);
        //@Then
        verify(saleTemplateDAO).hasSaleTemplateOfDirectSaleForHarvest(saleTemplate);

    }

    @Test
    public void testHasHeadOfficesShouldCallSaleTemplateDAO_ForGivenSaleTemplate(){
        //@Given

        SaleTemplate saleTemplate = mock(SaleTemplate.class);
        //@When
        saleTemplateService.hasHeadOffices(saleTemplate);
        //@Then
        verify(saleTemplateDAO).hasHeadOffices(saleTemplate);

    }

    @Test
    public void testHasProductsShouldCallSaleTemplateDAO_ForGivenSaleTemplate(){
        //@Given

        SaleTemplate saleTemplate = mock(SaleTemplate.class);
        //@When
        saleTemplateService.hasProducts(saleTemplate);
        //@Then
        verify(saleTemplateDAO).hasProducts(saleTemplate);

    }

    @Test
    public void testSelectBySaleTemplateAndHarvestShouldCallSaleTemplateDAO_ForGivenSaleTemplateHarvestAndSaleType(){
        //@Given
        String saleTemplateDescription = SALE_TEMPLATE_DESCRIPTION;
        Harvest harvest = mock(Harvest.class);
        Sale.SaleTypeEnum saleType = Sale.SaleTypeEnum.DIRECT_SALE;
        //@When
        saleTemplateService.selectBySaleTemplateAndHarvest(saleTemplateDescription, harvest, saleType);
        //@Then
        verify(saleTemplateDAO).selectBySaleTemplateAndHarvest(saleTemplateDescription, harvest, saleType);

    }

    @Test
    public void testSaveShouldShouldInteractWithDAO_WhenUsingAValidSaleTemplateAndAListOfPrices() throws BusinessException {



        Set<RoyaltyValue> royaltyValues = new HashSet<RoyaltyValue>();
        RoyaltyValue royaltyValue = new RoyaltyValue();
        royaltyValue.setId(1L);
        Date expirationDate = new Date();
        royaltyValue.setExpirationDate(expirationDate);
        royaltyValue.setValue(BigDecimal.ONE);
        royaltyValues.add(royaltyValue);

        RoyaltyValue originalRoyaltyValue = new RoyaltyValue();
        originalRoyaltyValue.setId(1L);

        //@When
        List<Price> priceArrayList = new ArrayList<Price>();
        Price priceArray = new Price();
        priceArray.setId(1L);
        priceArray.setType(Price.PriceTypeEnum.BY_EXPIRATION_DATE);
        priceArray.setRoyaltyValues(royaltyValues);
        priceArrayList.add(priceArray);
        Set<Price> priceSet = new HashSet<Price>();
        Price price = new Price();
        price.setId(1L);
        price.setType(Price.PriceTypeEnum.BY_EXPIRATION_DATE);
        price.setRoyaltyValues(royaltyValues);
        priceSet.add(price);
        SaleTemplate saleTemplate = mock(SaleTemplate.class);
        when(saleTemplate.getPrices()).thenReturn(priceSet);
        saleTemplateService.save(saleTemplate, priceArrayList);

        //@Then
        verify(saleTemplateDAO).selectAllSaleTemplateEquals(saleTemplate);
    }

}