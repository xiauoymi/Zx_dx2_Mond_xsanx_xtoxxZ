package com.monsanto.brazilvaluecapture.seedsale.sale.model.bean;

import com.monsanto.brazilvaluecapture.core.base.model.bean.State;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Customer;
import com.monsanto.brazilvaluecapture.core.grower.model.bean.Grower;
import com.monsanto.brazilvaluecapture.seedsale.billing.model.bean.Billing;
import com.monsanto.brazilvaluecapture.seedsale.billing.model.bean.PaymentStatus;
import com.monsanto.brazilvaluecapture.seedsale.product.model.bean.Product;
import com.monsanto.brazilvaluecapture.seedsale.product.model.bean.Region;
import com.monsanto.brazilvaluecapture.seedsale.sale.service.SaleWithNoItemsException;
import com.monsanto.brazilvaluecapture.seedsale.template.model.bean.SaleTemplate;
import com.monsanto.brazilvaluecapture.seedsale.template.model.bean.SaleTemplateBillingMethodEnum;
import org.junit.Test;

import java.math.BigDecimal;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import static org.fest.assertions.Assertions.assertThat;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

/**
 * Created by IntelliJ IDEA.
 * User: PPERA
 * Date: 4/15/13
 * Time: 5:55 PM
 * To change this template use File | Settings | File Templates.
 */
public class Sale_UT {

    private SaleItem saleItem;
    private Billing billing;

    @Test
    public void testGetPaymentBatchPriceReturns100_WhenGettingThePaymentBatchPriceForASaleWithOneItemWithATotalRoyaltyValueOf100() throws SaleWithNoItemsException {
        // @Given a sale with a sale item with a total royalty value of 100
        Customer customer = new Customer();
        Grower grower = new Grower();
        Sale sale = new Sale(customer, grower);
        SaleTemplate saleTemplate = new SaleTemplate();
        Product product = new Product();
        SaleItem saleItem = new SaleItem(product, saleTemplate, customer);
        saleItem.setTotalRoyaltyValue(BigDecimal.valueOf(100));
        sale.addItem(saleItem);


        // @When getting the payment batch price
        BigDecimal paymentBatchPrice = sale.getPaymentBatchPrice();

        // @Then the price is 100
        assertThat(paymentBatchPrice).isEqualTo(BigDecimal.valueOf(100));
    }

    @Test
    public void testGetPaymentBatchPriceReturns258_WhenGettingThePaymentBatchPriceForASaleWithOneItemWithATotalRoyaltyValueOf258() throws SaleWithNoItemsException {
        // @Given a sale with a sale item with a total royalty value of 258
        Customer customer = new Customer();
        Grower grower = new Grower();
        Sale sale = new Sale(customer, grower);
        SaleTemplate saleTemplate = new SaleTemplate();
        Product product = new Product();
        SaleItem saleItem = new SaleItem(product, saleTemplate, customer);
        saleItem.setTotalRoyaltyValue(BigDecimal.valueOf(258));
        sale.addItem(saleItem);


        // @When getting the payment batch price
        BigDecimal paymentBatchPrice = sale.getPaymentBatchPrice();

        // @Then the price is 258
        assertThat(paymentBatchPrice).isEqualTo(BigDecimal.valueOf(258));
    }

    @Test
    public void testGetPaymentBatchPriceReturns250_WhenGettingThePaymentBatchPriceForASaleWithTwoItemWithATotalRoyaltyValueOf100And150() throws SaleWithNoItemsException {
        // @Given a sale with two sale items with a total royalty value of 100 and 150
        Customer customer = new Customer();
        Grower grower = new Grower();
        Sale sale = new Sale(customer, grower);
        SaleTemplate saleTemplate = new SaleTemplate();
        Product product = new Product();
        SaleItem saleItem1 = new SaleItem(product, saleTemplate, customer);
        SaleItem saleItem2 = new SaleItem(product, saleTemplate, customer);
        saleItem1.setTotalRoyaltyValue(BigDecimal.valueOf(100));
        saleItem2.setTotalRoyaltyValue(BigDecimal.valueOf(150));
        sale.addItem(saleItem1);
        sale.addItem(saleItem2);


        // @When getting the payment batch price
        BigDecimal paymentBatchPrice = sale.getPaymentBatchPrice();

        // @Then the price is 250
        assertThat(paymentBatchPrice).isEqualTo(BigDecimal.valueOf(250));
    }

    @Test
    public void testGetPaymentBatchPriceReturns368_WhenGettingThePaymentBatchPriceForASaleWithTwoItemsWithATotalRoyaltyValueOf125And243() throws SaleWithNoItemsException {
        // @Given a sale with two sale items with a total royalty value of 125 and 243
        Customer customer = new Customer();
        Grower grower = new Grower();
        Sale sale = new Sale(customer, grower);
        SaleTemplate saleTemplate = new SaleTemplate();
        Product product = new Product();
        SaleItem saleItem1 = new SaleItem(product, saleTemplate, customer);
        SaleItem saleItem2 = new SaleItem(product, saleTemplate, customer);
        saleItem1.setTotalRoyaltyValue(BigDecimal.valueOf(125));
        saleItem2.setTotalRoyaltyValue(BigDecimal.valueOf(243));
        sale.addItem(saleItem1);
        sale.addItem(saleItem2);


        // @When getting the payment batch price
        BigDecimal paymentBatchPrice = sale.getPaymentBatchPrice();

        // @Then the price is 258
        assertThat(paymentBatchPrice).isEqualTo(BigDecimal.valueOf(368));
    }

    @Test
    public void testGetPaymentBatchPriceThrowsException_WhenGettingThePaymentBatchPriceForASaleWithNoItems() throws SaleWithNoItemsException {
        // @Given a sale with two sale items with a total royalty value of 125 and 243
        Customer customer = new Customer();
        Grower grower = new Grower();
        Sale sale = new Sale(customer, grower);

        // @When getting the payment batch price
        try {
            sale.getPaymentBatchPrice();
            fail();
        } catch (SaleWithNoItemsException e) {
            assertThat(e).hasMessage("Sales must contain at least one item");
        } catch (Exception e) {
            fail();
        }
    }

    @Test
    public void isPayableOnlineShouldReturnFalseWhenHavingNoItems() {
        Customer customer = mock(Customer.class);
        Grower grower = mock(Grower.class);
        Sale sale = new Sale(customer, grower);

        boolean result = sale.isPayableOnline();

        assertFalse(result);
    }

    @Test
    public void isPayableOnlineShouldReturnFalseWhenNotHavingOnlyOneItem() {
        Sale sale = createSale(true, null, null);
        sale.setItems(new HashSet<SaleItem>());

        boolean result = sale.isPayableOnline();

        assertFalse(result);
    }

    @Test
    public void isPayableOnlineShouldReturnFalseWhenNotHavingBilling() {
        Sale sale = createSale(false, null, null);

        boolean result = sale.isPayableOnline();

        assertFalse(result);
    }

    @Test
    public void isPayableOnlineShouldReturnFalseWhenBillingMethodIsNotERP() {
        Sale sale = createSale(true, SaleTemplateBillingMethodEnum.DIRECT, null);

        boolean result = sale.isPayableOnline();

        assertFalse(result);
    }

    @Test
    public void isPayableOnlineShouldReturnFalseWhenPaymentStatusIsNotNOT_PAID() {
        Sale sale = createSale(true, null, PaymentStatus.BILLED);

        boolean result = sale.isPayableOnline();

        assertFalse(result);
    }

    @Test
    public void isPayableOnlineShouldReturnTrue() {
        Sale sale = createSale(true, null, null);

        boolean result = sale.isPayableOnline();

        assertTrue(result);
    }

    private Sale createSale(boolean hasBilling, SaleTemplateBillingMethodEnum billingMethod, PaymentStatus paymentStatus) {
        Customer customer = mock(Customer.class);
        Grower grower = mock(Grower.class);
        Sale sale = new Sale(customer, grower);
        SaleItem si = new SaleItem();
        si.setBilling(null);
        if (hasBilling) {
            Billing b = new Billing();
            b.setBillingMethod(SaleTemplateBillingMethodEnum.ERP);
            if (billingMethod != null) {
                b.setBillingMethod(billingMethod);
            }
            b.setPaymentStatus(PaymentStatus.NOT_PAID);
            if (paymentStatus != null) {
                b.setPaymentStatus(paymentStatus);
            }
            si.setBilling(b);
        }
        Set<SaleItem> saleItems = new HashSet<SaleItem>();
        saleItems.add(si);
        sale.setItems(saleItems);
        return sale;
    }

    @Test
    public void testIsCancelledOrFullyPaid() throws SaleWithNoItemsException {
        Customer customer = new Customer();
        Grower grower = new Grower();
        Sale sale = new Sale(customer, grower);

        // sale.items don't have elements.
        assertFalse(sale.isCancelledOrFullyPaid());

        Set<SaleItem> set = new HashSet<SaleItem>();
        SaleItem saleItem = new SaleItem(sale, null, null, null);
        set.add(saleItem);
        sale.setItems(set);
        Billing billing = new Billing();
        billing.setPaymentStatus(PaymentStatus.CANCELLED);
        saleItem.setBilling(billing);
        // Sale Cancelled.
        assertTrue(sale.isCancelledOrFullyPaid());

        billing.setPaymentStatus(PaymentStatus.NOT_PAID);
        // Sale Not Cancelled nor Fully paid.
        assertFalse(sale.isCancelledOrFullyPaid());

        billing.setPaymentStatus(PaymentStatus.FULLY_PAID);
        // Sale Fully paid.
        assertTrue(sale.isCancelledOrFullyPaid());
    }

    @Test
    public void fully_paid() {
        Billing billing = new Billing();
        billing.setPaymentStatus(PaymentStatus.FULLY_PAID);
        assertTrue("Billing should be Fully Paid", billing.isFullyPaid());
    }

    @Test
    public void selectSalePriceByCode_ShouldSelectSalePrice_WhenCorrespondingCodeIsSet() {
        Sale sale = new Sale(null, new Grower());
        SalePrice salePrice = new SalePrice();
        String code = "code";
        salePrice.setCode(code);
        sale.addSalePrice(salePrice);

        assertEquals(salePrice, sale.selectSalePriceByCode(code));
    }

    @Test
    public void selectSalePriceByCode_ShouldReturnNull_WhenCorrespondingCodeIsNotSet() {
        Sale sale = new Sale(null, new Grower());
        assertNull(sale.selectSalePriceByCode("code"));
    }

    @Test
    public void testCopyProperties() {
        Sale sale = new Sale();
        Long expectedId = 1l;
        sale.setId(expectedId);

        Date expectedDate = new Date();
        sale.setCreationDate(expectedDate);

        Customer expectedCustomer = new Customer();
        sale.setCustomer(expectedCustomer);

        Grower expectedGrower = new Grower();
        sale.setGrower(expectedGrower);

        Customer expectedDistributor = new Customer();
        sale.setDistributor(expectedDistributor);

        sale.setInvoiceDate(expectedDate);

        String expectedInvoideNumber = "123123123";
        sale.setInvoiceNumber(expectedInvoideNumber);

        String expectedSaleNote = "someSaleNote";
        sale.setSaleNote(expectedSaleNote);

        Region expectedRegion = new Region();
        sale.setRegion(expectedRegion);

        State expectedState = new State();
        sale.setState(expectedState);

        Sale anotherSale = new Sale();
        anotherSale.copyProperties(sale);

        assertEquals(expectedId, anotherSale.getId());
        assertEquals(expectedDate, anotherSale.getCreationDate());
        assertEquals(expectedCustomer, anotherSale.getCustomer());
        assertEquals(expectedGrower, anotherSale.getGrower());
        assertEquals(expectedDistributor, anotherSale.getDistributor());
        assertEquals(expectedDate, anotherSale.getInvoiceDate());
        assertEquals(expectedInvoideNumber, anotherSale.getInvoiceNumber());
        assertEquals(expectedSaleNote.toUpperCase(), anotherSale.getSaleNote());
        assertEquals(expectedRegion, anotherSale.getRegion());
        assertEquals(expectedState, anotherSale.getState());
    }

    @Test
    public void testGetPaymentStatus() {
        Customer customer = new Customer();
        Grower grower = new Grower();
        Sale sale = new Sale(customer, grower);

        // sale.items don't have elements.
        assertEquals("", sale.getPaymentStatus());

        Set<SaleItem> set = new HashSet<SaleItem>();
        SaleItem saleItem1 = new SaleItem(sale, null, null, null);

        Billing billing1 = new Billing();
        billing1.setPaymentStatus(PaymentStatus.CANCELLED);
        billing1.setDueDate(new Date());
        saleItem1.setBilling(billing1);

        set.add(saleItem1);
        sale.setItems(set);

        // sale.items have one element.
        assertEquals(PaymentStatus.CANCELLED.getValue(), sale.getPaymentStatusBVC());

        SaleItem saleItem2 = new SaleItem(sale, null, null, null);
        saleItem2.setBilling(billing1);

        set.add(saleItem2);
        sale.setItems(set);

        // sale.items have two elements with same billing.
        assertEquals(PaymentStatus.CANCELLED.getValue(), sale.getPaymentStatusBVC());

        SaleItem saleItem3 = new SaleItem(sale, null, null, null);

        Billing billing2 = new Billing();
        billing2.setPaymentStatus(PaymentStatus.CANCELLED);
        saleItem3.setBilling(billing2);

        set.add(saleItem3);
        sale.setItems(set);

        // sale.items have two elements with same billing.
        assertEquals("", sale.getPaymentStatusBVC());

    }

}