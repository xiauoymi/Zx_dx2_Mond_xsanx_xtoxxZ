package com.monsanto.brazilvaluecapture.seedsale.sale.service.parser.registration;

import java.util.Locale;
import java.util.ResourceBundle;

import junit.framework.Assert;

import org.junit.Before;
import org.junit.Test;

import com.monsanto.brazilvaluecapture.core.foundation.util.csv.CSVReadableInvalidException;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.CsvSale;

public class SaleDependencyNotFoundLineResult_UT {

    private ResourceBundle resourceBundle;

    @Before
    public void setup() {
        Locale.setDefault(Locale.US);
        resourceBundle = ResourceBundle.getBundle("bundle/bundle");
    }

    @Test
    public void test_get_formatted_message() throws CSVReadableInvalidException {

        CsvSale csvSale = new CsvSale();
        csvSale.setLine(9);
        String message = "invalid payment date ({0})";
        Object[] messageArgs = new Object[] { "10/10/2000" };

        SaleDependencyNotFoundLineResult result = new SaleDependencyNotFoundLineResult(csvSale, message, messageArgs);
        Assert.assertEquals("Linha 9  - invalid payment date (10/10/2000)\n",
                result.getFormattedMessage(resourceBundle));

    }

}
