package com.monsanto.brazilvaluecapture.seedsale.sale.service.impl;

import static org.fest.assertions.Assertions.assertThat;
import static org.fest.reflect.core.Reflection.field;
import static org.mockito.Mockito.mock;
import junit.framework.Assert;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

import com.monsanto.brazilvaluecapture.core.account.model.bean.TransactionType;
import com.monsanto.brazilvaluecapture.core.account.model.bean.Account.AccountType;
import com.monsanto.brazilvaluecapture.core.account.service.DuplicatedCancellationException;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Crop;
import com.monsanto.brazilvaluecapture.core.base.model.bean.OperationalYear;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Technology;
import com.monsanto.brazilvaluecapture.core.foundation.model.bean.TransferAccount;
import com.monsanto.brazilvaluecapture.core.foundation.service.IndustrySystemOperationException;
import com.monsanto.brazilvaluecapture.core.foundation.service.TransactionControlService;
import com.monsanto.brazilvaluecapture.core.grower.model.bean.Grower;
import com.monsanto.brazilvaluecapture.seedsale.billing.model.bean.Billing;
import com.monsanto.brazilvaluecapture.seedsale.billing.model.bean.Royalty;
import com.monsanto.brazilvaluecapture.seedsale.harvest.model.bean.Harvest;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.Cancellation;

public class AccountManagerServiceImpl_UT {

	AccountManagerServiceImpl accountManagerServiceImpl;
	Cancellation cancellation;
	TransactionControlService transactionControlService;
	Royalty royalty;

	@Before
	public void setUp() throws Exception {
		initalizateRoyal();
		accountManagerServiceImpl = new AccountManagerServiceImpl();
		transactionControlService = mock(TransactionControlService.class);
		field("transactionControlService").ofType(TransactionControlService.class).in(accountManagerServiceImpl).set(this.transactionControlService);
	}


	@Test
	public void testCreateTransactionOfCancelationCallsTransferControlServiceSaveTransferWithTransferTypeCancelation_WhenCreatingTransactionOfCancelationWithNullCancellation() throws IndustrySystemOperationException{
		
		// @Given a null Cancellation
		cancellation = null;
		
		// @When creating a transaction of cancelation
		accountManagerServiceImpl.createTransactionOfCancelation(null, royalty, null, cancellation);
		
		// @Then a new transfer with a Cancellation type is created 
		Mockito.verify(transactionControlService, Mockito.times(1)).saveTransfer(Mockito.<TransferAccount>any(), Mockito.anyLong(), Mockito.eq(TransactionType.CANCELLATION));
	}
	
	@Test
	public void testCreateTransactionOfCancelationCallsTransferControlServiceSaveTransferWithTransferTypeCancelation_WhenCreatingTransactionOfCancelationWithPaidSaleOrderCancellation() throws IndustrySystemOperationException{
		
		// @Given a paid sale order Cancellation
		cancellation = new Cancellation();
		cancellation.setCancelPaidSaleOrder(true);
		
		// @When creating a transaction of cancellation
		accountManagerServiceImpl.createTransactionOfCancelation(null, royalty, null, cancellation);
		
		// @Then a new transference with a Cancellation Paid Sale type is created 
		Mockito.verify(transactionControlService, Mockito.times(1)).saveTransfer(Mockito.<TransferAccount>any(), Mockito.anyLong(), Mockito.eq(TransactionType.CANCEL_PAID_SALE));
	
	}
	
	@Test
	public void testCreateTransactionOfCancelationCallsTransferControlServiceSaveTransferWithTransferTypeCancelation_WhenCreatingTransactionOfCancelationWithNotPaidSaleOrderCancellation()
			throws IndustrySystemOperationException {

		// @Given a not paid sale order Cancellation
		cancellation = new Cancellation();
		cancellation.setCancelPaidSaleOrder(false);

		// @When creating a transaction of cancellation
		accountManagerServiceImpl.createTransactionOfCancelation(null, royalty,	null, cancellation);

		// @Then a new transference  with a Cancellation type is created
		Mockito.verify(transactionControlService, Mockito.times(1)).saveTransfer(Mockito.<TransferAccount> any(),Mockito.anyLong(),  Mockito.eq(TransactionType.CANCELLATION));
	}
	
	@Test
	public void testCreateTransactionOfCancelationCallsHasTransactionAlreadyMadeFor_ForcingFalseReturn()
			throws IndustrySystemOperationException {

		// @Given transactionControlService.hasTransactionAlreadyMadeFor returns true
		Mockito.when(
				transactionControlService.hasTransactionAlreadyMadeFor(
						Mockito.<Grower> any(), Mockito.<AccountType> any(),
						Mockito.<OperationalYear> any(),
						Mockito.<Technology> any(), Mockito.<Crop> any(),
						Mockito.anyLong(), Mockito.<TransactionType> any()))
				.thenReturn(true);
		
		// @When creating a transaction of cancellation
		try {
			accountManagerServiceImpl.createTransactionOfCancelation(null,
					royalty, null, cancellation);
			Assert.fail();
		// @Then an exception is obtained
		} catch (DuplicatedCancellationException e) {
			assertThat(e).hasMessage("Duplicated cancellation");
		} catch (Throwable e) {
			Assert.fail();
		}

	}
	
	private void initalizateRoyal(){
		Harvest harvest = mock(Harvest.class);
		Technology technology = mock(Technology.class);
		Billing billing = mock(Billing.class);
		royalty = new Royalty(technology,billing,harvest);
	}

}

