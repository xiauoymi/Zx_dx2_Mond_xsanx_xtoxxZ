package com.monsanto.brazilvaluecapture.seedsale.product;

import static org.mockito.Matchers.anyObject;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.junit.Test;

import com.monsanto.brazilvaluecapture.core.foundation.service.BusinessException;
import com.monsanto.brazilvaluecapture.core.grower.CreateTestData;
import com.monsanto.brazilvaluecapture.seedsale.product.model.bean.DefaultProductivity;
import com.monsanto.brazilvaluecapture.seedsale.product.model.bean.Productivity;
import com.monsanto.brazilvaluecapture.seedsale.product.model.bean.ProductivityDTO;
import com.monsanto.brazilvaluecapture.seedsale.product.model.bean.ProductivityValue;
import com.monsanto.brazilvaluecapture.seedsale.product.model.dao.ProductivityDAO;
import com.monsanto.brazilvaluecapture.seedsale.product.service.ProductivityWithSaleTemplateUndeletableException;
import com.monsanto.brazilvaluecapture.seedsale.product.service.impl.ProductivityServiceImpl;

public class ProductivityServiceImpl_UT extends CreateTestData {

	@Test
	public void testSelectByAllFilter() throws BusinessException{

		Productivity productivityCreated = ProductivityTestData.createFullProductivity() ;

		List<Productivity> productivities = new ArrayList<Productivity>();
		
		productivities.add(productivityCreated);
		
		ProductivityDTO productivityDTO = ProductivityTestData.createProductivityDTO(
				productivityCreated.getPlantability().getHarvest(), productivityCreated.getState(), 
				productivityCreated.getPlantability(), productivityCreated.getDefaultProductivity());
		
		ProductivityDAO dao = mock(ProductivityDAO.class);
		
		ProductivityServiceImpl productivityService = new ProductivityServiceImpl();
		
		when(dao.selectByFilter((ProductivityDTO) anyObject())).thenReturn(productivities);
		
		productivityService.setProductivityDAO(dao);
		
		List<Productivity> productivitiesBase = productivityService
		.selectByFilter(productivityDTO);
		
		Assert.assertNotNull(productivitiesBase);

	}
	
	@Test
	public void testDelete() throws ProductivityWithSaleTemplateUndeletableException{ 
		Productivity productivity = ProductivityTestData.createFullProductivity();

		ProductivityDAO dao = mock(ProductivityDAO.class);

		ProductivityServiceImpl productivityService = new ProductivityServiceImpl();

		productivityService.setProductivityDAO(dao);
		
		doNothing().when(dao).delete(productivity);
		
		productivityService.delete(productivity);
		
		verify(dao).delete(productivity);
		
		when(dao.selectById(null)).thenReturn(null);
		
		Productivity productivityBase = productivityService.selectById(null);
		Assert.assertNull(productivityBase);
	}
	
	@Test
	public void testInsert() throws BusinessException{

		Productivity productivity = ProductivityTestData.createFullProductivity();

		ProductivityDAO dao = mock(ProductivityDAO.class);

		ProductivityServiceImpl productivityService = new ProductivityServiceImpl();

		productivityService.setProductivityDAO(dao);
		
		List<Productivity> productivities = new ArrayList<Productivity>();
		
		productivities.add(productivity);
		
		when(dao.selectByFilter((ProductivityDTO) anyObject())).thenReturn(productivities);
		doNothing().when(dao).save(productivity);
		productivityService.save(productivity);

		verify(dao).save(productivity);

	}
	
	@Test
	public void testInsertNotDefault() throws BusinessException{

		Productivity productivity = ProductivityTestData.createFullProductivity();
		productivity.setDefaultProductivity(DefaultProductivity.NOT);

		ProductivityDAO dao = mock(ProductivityDAO.class);

		ProductivityServiceImpl productivityService = new ProductivityServiceImpl();

		productivityService.setProductivityDAO(dao);
		
		doNothing().when(dao).save(productivity);
		productivityService.save(productivity);

		verify(dao).save(productivity);

	}
	
	@Test
	public void testInsertDefaultSameSate() throws BusinessException{

		Productivity productivity = ProductivityTestData.createFullProductivity();
		Productivity productivityDefault = ProductivityTestData.createFullProductivity();
		
		productivityDefault.setState(productivity.getState());
		
		ProductivityDAO dao = mock(ProductivityDAO.class);

		ProductivityServiceImpl productivityService = new ProductivityServiceImpl();

		productivityService.setProductivityDAO(dao);
		
		List<Productivity> productivities = new ArrayList<Productivity>();
		
		productivities.add(productivityDefault);
		
		when(dao.selectByFilter((ProductivityDTO) anyObject())).thenReturn(productivities);
		doNothing().when(dao).save(productivity);
		productivityService.save(productivity);

		verify(dao).save(productivity);
		
		Assert.assertEquals(productivityDefault.getDefaultProductivity(), DefaultProductivity.NOT);

	}
	
	@Test
	public void testInsertDefaultNotSameSate() throws BusinessException{

		Productivity productivity = ProductivityTestData.createFullProductivity();
		Productivity productivityDefault = ProductivityTestData.createFullProductivity();
		
		ProductivityDAO dao = mock(ProductivityDAO.class);

		ProductivityServiceImpl productivityService = new ProductivityServiceImpl();

		productivityService.setProductivityDAO(dao);
		
		List<Productivity> productivities = new ArrayList<Productivity>();
		
		productivities.add(productivityDefault);
		
		when(dao.selectByFilter((ProductivityDTO) anyObject())).thenReturn(productivities);
		doNothing().when(dao).save(productivity);
		productivityService.save(productivity);

		verify(dao).save(productivity);
		
		Assert.assertEquals(productivityDefault.getDefaultProductivity(), DefaultProductivity.YES);

	}
	
	@Test (expected = BusinessException.class)
	public void testInsertException() throws BusinessException{

		Productivity productivity = ProductivityTestData.createFullProductivity();
		
		for (ProductivityValue prod :productivity.getProductivityValues()){
			prod.setProductivityMin(BigDecimal.ONE);
			prod.setProductivityMax(BigDecimal.ZERO);
		}
		
		ProductivityDAO dao = mock(ProductivityDAO.class);

		ProductivityServiceImpl productivityService = new ProductivityServiceImpl();

		productivityService.setProductivityDAO(dao);
		
		doNothing().when(dao).save(productivity);
		productivityService.save(productivity);

	}
	
}
