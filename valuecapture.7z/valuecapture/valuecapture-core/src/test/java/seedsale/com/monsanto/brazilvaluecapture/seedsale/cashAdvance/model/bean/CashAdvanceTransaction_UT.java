package com.monsanto.brazilvaluecapture.seedsale.cashAdvance.model.bean;

import com.monsanto.brazilvaluecapture.core.base.model.bean.OperationalYear;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Customer;
import com.monsanto.brazilvaluecapture.seedsale.template.model.bean.DueDatePriceItem;
import org.junit.Test;

import java.math.BigDecimal;
import static org.fest.assertions.Assertions.*;

public class CashAdvanceTransaction_UT {
    @Test
    public void testCashAdvanceHasNoArgumentConstructor(){
        CashAdvanceTransaction cashAdvanceTransaction = new CashAdvanceTransaction();
        assertThat(cashAdvanceTransaction).isNotNull();
    }

    @Test
    public void testCashAdvanceConstructorInitializesCustomer_WhenConstructingCashAdvance(){
        Customer customer = new Customer();
        DueDatePriceItem referenceDate = null;
        BigDecimal amount = null;

        CashAdvanceTransaction cashAdvanceTransaction = new CashAdvanceTransaction(customer, customer, null, referenceDate, amount, null);

        assertThat(cashAdvanceTransaction.getPartner()).isSameAs(customer);
    }

    @Test
    public void testCashAdvanceConstructorInitializesReferenceDate_WhenConstructingCashAdvance(){
        Customer customer = new Customer();
        DueDatePriceItem referenceDate = new DueDatePriceItem();
        BigDecimal amount = null;

        CashAdvanceTransaction cashAdvanceTransaction = new CashAdvanceTransaction(customer, customer, null, referenceDate, amount, null);

        assertThat(cashAdvanceTransaction.getReferenceDate()).isSameAs(referenceDate);
    }

    @Test
    public void testCashAdvanceConstructorInitializesAmount_WhenConstructingCashAdvance(){
        Customer customer = new Customer();
        DueDatePriceItem referenceDate = new DueDatePriceItem();
        BigDecimal amount = BigDecimal.TEN;

        CashAdvanceTransaction cashAdvanceTransaction = new CashAdvanceTransaction(customer, customer, null, referenceDate, amount, null);

        assertThat(cashAdvanceTransaction.getAmount()).isSameAs(amount);
    }

    @Test
    public void testCashAdvanceConstructorInitializesOperationTypeWithFORM_WhenConstructingCashAdvance(){
        Customer customer = new Customer();
        DueDatePriceItem referenceDate = new DueDatePriceItem();
        BigDecimal amount = BigDecimal.TEN;
        CashAdvanceSourceOperationType operationType = CashAdvanceSourceOperationType.FORM;

        CashAdvanceTransaction cashAdvanceTransaction = new CashAdvanceTransaction(customer, customer, null, referenceDate, amount, operationType);

        assertThat(cashAdvanceTransaction.getSourceOperationType()).isSameAs(CashAdvanceSourceOperationType.FORM);
    }

    @Test
    public void testCashAdvanceConstructorInitializesOperationTypeWithMANUAL_WhenConstructingCashAdvance(){
        Customer customer = new Customer();
        DueDatePriceItem referenceDate = new DueDatePriceItem();
        BigDecimal amount = BigDecimal.TEN;
        CashAdvanceSourceOperationType operationType = CashAdvanceSourceOperationType.MANUAL;

        CashAdvanceTransaction cashAdvanceTransaction = new CashAdvanceTransaction(customer, customer, null, referenceDate, amount, operationType);

        assertThat(cashAdvanceTransaction.getSourceOperationType()).isSameAs(CashAdvanceSourceOperationType.MANUAL);
    }

    @Test
    public void testCashAdvanceConstructorInitializesOperationalYearAsPassedInConstructor_WhenConstructingCashAdvance(){
        Customer customer = new Customer();
        DueDatePriceItem referenceDate = new DueDatePriceItem();
        BigDecimal amount = BigDecimal.TEN;
        CashAdvanceSourceOperationType operationType = CashAdvanceSourceOperationType.MANUAL;
        OperationalYear operationalYear = new OperationalYear("2014/2015");

        CashAdvanceTransaction cashAdvanceTransaction = new CashAdvanceTransaction(customer, customer, operationalYear, referenceDate, amount, operationType);

        assertThat(cashAdvanceTransaction.getOperationalYear()).isSameAs(operationalYear);
    }

    @Test
    public void testCashAdvanceConstructorInitializesHeadOfficeAsPassedInConstructor_WhenConstructingCashAdvance(){
        Customer customer = new Customer();
        Customer headOffice = new Customer();
        DueDatePriceItem referenceDate = new DueDatePriceItem();
        BigDecimal amount = BigDecimal.TEN;
        CashAdvanceSourceOperationType operationType = CashAdvanceSourceOperationType.MANUAL;
        OperationalYear operationalYear = new OperationalYear("2014/2015");

        CashAdvanceTransaction cashAdvanceTransaction = new CashAdvanceTransaction(customer, headOffice,
                operationalYear, referenceDate, amount, operationType);

        assertThat(cashAdvanceTransaction.getHeadOffice()).isSameAs(headOffice);
    }

    @Test
    public void testGetTransactionTypeReturnsDEBIT_WhenAmountIsNegative(){
        CashAdvanceTransaction cashAdvanceTransaction = new CashAdvanceTransaction();
        cashAdvanceTransaction.setAmount(BigDecimal.TEN.negate());

        assertThat(cashAdvanceTransaction.getTransactionType()).isEqualTo(CashAdvanceTransaction.CashAdvanceType.DEBIT);
    }

    @Test
    public void testGetTransactionTypeReturnsCREDIT_WhenAmountIsNegative(){
        CashAdvanceTransaction cashAdvanceTransaction = new CashAdvanceTransaction();
        cashAdvanceTransaction.setAmount(BigDecimal.TEN);

        assertThat(cashAdvanceTransaction.getTransactionType()).isEqualTo(CashAdvanceTransaction.CashAdvanceType.CREDIT);
    }
}