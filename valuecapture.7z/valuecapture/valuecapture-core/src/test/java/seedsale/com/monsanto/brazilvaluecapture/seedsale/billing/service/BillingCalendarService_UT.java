package com.monsanto.brazilvaluecapture.seedsale.billing.service;

import com.monsanto.brazilvaluecapture.core.base.model.bean.Company;
import com.monsanto.brazilvaluecapture.core.revenue.model.bean.ChargeGroup;
import com.monsanto.brazilvaluecapture.seedsale.billing.model.bean.BillingCalendar;
import com.monsanto.brazilvaluecapture.seedsale.billing.model.bean.BillingCalendarLimit;
import com.monsanto.brazilvaluecapture.seedsale.billing.model.bean.BillingCalendarMaximumAndMinimumDates;
import com.monsanto.brazilvaluecapture.seedsale.billing.model.dao.BillingCalendarDao;
import com.monsanto.brazilvaluecapture.seedsale.billing.service.impl.BillingCalendarServiceImpl;
import junit.framework.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.*;

import static org.mockito.Matchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class BillingCalendarService_UT {

    @Mock
    private BillingCalendarDao billingCalendarDao;

    @InjectMocks
    private BillingCalendarService billingCalendarService = new BillingCalendarServiceImpl();

    @Before
    public void init() {
        List<BillingCalendar> billings = new ArrayList<BillingCalendar>();
        billings.add(Mockito.mock(BillingCalendar.class));

        when(billingCalendarDao.getBillingCalendarsByDateAndCompany(any(Date.class), any(Company.class))).thenReturn(billings);
    }

    @Test
    public void billingCalendarsByDateAndCompanyTest() {
        Date date = Mockito.mock(Date.class);
        Company company = Mockito.mock(Company.class);

        List<BillingCalendar> billingCalendars = billingCalendarService.getBillingCalendarsByDateAndCompany(date, company);

        Assert.assertNotNull(billingCalendars);
        Assert.assertFalse(billingCalendars.isEmpty());
    }

    @Test
    public void testFindBillingCalendarByChargeGroup(){

        ChargeGroup chargeGroup = mock(ChargeGroup.class);

        List<BillingCalendar> billingCalendarList = new ArrayList<BillingCalendar>();

        BillingCalendar billingCalendarExpected = mock(BillingCalendar.class);

        billingCalendarList.add(billingCalendarExpected);

        when(billingCalendarDao.getBillingCalendarByChargeGroup(chargeGroup)).thenReturn(billingCalendarList);

        List<BillingCalendar> billingCalendarResponse = billingCalendarService.getBillingCalendarByChargeGroup(chargeGroup);

        Assert.assertEquals(billingCalendarList, billingCalendarResponse);
        Assert.assertTrue(billingCalendarResponse.contains(billingCalendarExpected));
    }

    @Test
    public void testFindMaximumAndMinimumLimitsDatesForBillingCalendarByChargeGroup (){

        ChargeGroup chargeGroup = mock(ChargeGroup.class);

        BillingCalendarMaximumAndMinimumDates billingCalendarMaximumAndMinimumDatesExpected = getBillingCalendarMaximumAndMinimumDates(chargeGroup);

        BillingCalendarMaximumAndMinimumDates billingCalendarMaximumAndMinimumDates = billingCalendarService.findBillingCalendarMaximumAndMinimumDatesByChargeGroup(chargeGroup);

        Assert.assertEquals(billingCalendarMaximumAndMinimumDatesExpected.getFirstDate(), billingCalendarMaximumAndMinimumDates.getFirstDate());
        Assert.assertEquals(billingCalendarMaximumAndMinimumDatesExpected.getLastDate(), billingCalendarMaximumAndMinimumDates.getLastDate());

    }

    private BillingCalendarMaximumAndMinimumDates getBillingCalendarMaximumAndMinimumDates(ChargeGroup chargeGroup) {

        Calendar calendar = GregorianCalendar.getInstance();

        List<BillingCalendarLimit> billingCalendarLimits = new ArrayList<BillingCalendarLimit>();

        Date lastDate = calendar.getTime();

        BillingCalendarLimit billingCalendarLimit = new BillingCalendarLimit();

        billingCalendarLimit.setLimitDate(lastDate);

        billingCalendarLimits.add(billingCalendarLimit);

        calendar.set(Calendar.DAY_OF_MONTH, 1);

        Date firstDate =  calendar.getTime();

        billingCalendarLimit = new BillingCalendarLimit();

        billingCalendarLimit.setLimitDate(firstDate);

        billingCalendarLimits.add(billingCalendarLimit);

        calendar.set(Calendar.DAY_OF_MONTH, 5);

        Date dayFive = calendar.getTime();

        billingCalendarLimit = new BillingCalendarLimit();

        billingCalendarLimit.setLimitDate(dayFive);

        billingCalendarLimits.add(billingCalendarLimit);

        calendar.set(Calendar.DAY_OF_MONTH, 10);

        Date dayTen = calendar.getTime();

        billingCalendarLimit = new BillingCalendarLimit();

        billingCalendarLimit.setLimitDate(dayTen);

        billingCalendarLimits.add(billingCalendarLimit);

        BillingCalendar billingCalendar = new BillingCalendar();

        billingCalendar.setBillingCalendarLimits(billingCalendarLimits);

        List<BillingCalendar> billingCalendarList = new ArrayList<BillingCalendar>();

        billingCalendarList.add(billingCalendar);

        BillingCalendarMaximumAndMinimumDates billingCalendarMaximumAndMinimumDatesExpected = new BillingCalendarMaximumAndMinimumDates(firstDate, lastDate);

        when(billingCalendarDao.getBillingCalendarByChargeGroup(chargeGroup)).thenReturn(billingCalendarList);

        return billingCalendarMaximumAndMinimumDatesExpected;
    }
}
