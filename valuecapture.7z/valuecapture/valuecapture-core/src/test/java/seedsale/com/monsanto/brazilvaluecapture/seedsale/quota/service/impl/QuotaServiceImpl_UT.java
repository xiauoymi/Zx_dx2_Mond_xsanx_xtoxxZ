package com.monsanto.brazilvaluecapture.seedsale.quota.service.impl;

import com.google.common.collect.Sets;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Company;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Country;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Crop;
import com.monsanto.brazilvaluecapture.core.base.model.bean.OperationalYear;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Customer;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.ParticipantTypeEnum;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Technology;
import com.monsanto.brazilvaluecapture.core.customer.model.dao.CustomerDAO;
import com.monsanto.brazilvaluecapture.core.customer.service.CustomerService;
import com.monsanto.brazilvaluecapture.core.foundation.model.bean.QuotaUsageEnum;
import com.monsanto.brazilvaluecapture.core.foundation.model.bean.StatusEnum;
import com.monsanto.brazilvaluecapture.core.foundation.service.BusinessException;
import com.monsanto.brazilvaluecapture.core.foundation.service.EntityNotFoundException;
import com.monsanto.brazilvaluecapture.seedsale.harvest.model.bean.Harvest;
import com.monsanto.brazilvaluecapture.seedsale.harvest.model.bean.Plantability;
import com.monsanto.brazilvaluecapture.seedsale.harvest.model.dao.PlantabilityDAO;
import com.monsanto.brazilvaluecapture.seedsale.product.model.bean.Brand;
import com.monsanto.brazilvaluecapture.seedsale.product.model.bean.Product;
import com.monsanto.brazilvaluecapture.seedsale.product.model.dao.ProductDAO;
import com.monsanto.brazilvaluecapture.seedsale.quota.model.bean.Quota;
import com.monsanto.brazilvaluecapture.seedsale.quota.model.bean.QuotaTransaction;
import com.monsanto.brazilvaluecapture.seedsale.quota.model.bean.QuotaType;
import com.monsanto.brazilvaluecapture.seedsale.quota.model.dao.QuotaDAO;
import com.monsanto.brazilvaluecapture.seedsale.quota.model.dao.QuotaFilter;
import com.monsanto.brazilvaluecapture.seedsale.quota.service.QuotaControlService;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.Sale;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.SaleItem;
import com.monsanto.brazilvaluecapture.seedsale.template.model.bean.SaleTemplate;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static junit.framework.Assert.assertSame;
import static org.fest.assertions.Assertions.assertThat;
import static org.mockito.Matchers.*;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/**
 * Created with IntelliJ IDEA.
 * User: IFERN1
 * Date: 12/3/13
 * Time: 3:00 PM
 * To change this template use File | Settings | File Templates.
 */
@RunWith(MockitoJUnitRunner.class)
public class QuotaServiceImpl_UT {
    @Mock
    private QuotaControlService quotaControlService;

    @Mock
    private QuotaDAO quotaDAO;

    @Mock
    private CustomerService customerService;

    @Mock
    private ProductDAO productDAO;

    @Mock
    private CustomerDAO customerDAO;

    @Mock
    private PlantabilityDAO plantabilityDAO;

    @InjectMocks
    private QuotaServiceImpl quotaService;

    @Test
    public void when_manageForSale_quotaServiceControl_saveTransfer_is_invoked(){
        //@Given
        Customer multiplier = new Customer();
        Plantability plantability = new Plantability();
        Product product = new Product();
        product.setQuotaUsage(QuotaUsageEnum.USE_QUOTA);
        product.setDescription("Test product");
        product.setTechnology(new Technology("Test Technology", null));
        product.setCrop(new Crop("Test Crop", new Company("Test company"), new Country("Cuba", "CU")));
        Customer customer = new Customer();
        SaleTemplate saleTemplate = new SaleTemplate();
        Harvest harvest = new Harvest();
        OperationalYear operationalYear = new OperationalYear("2013");
        harvest.setOperationalYear(operationalYear);
        saleTemplate.setHarvest(harvest);
        Sale sale = new Sale();
        Customer dealer = new Customer();
        dealer.setName("DUMMY_DEALER");
        sale.setDistributor(dealer);
        SaleItem saleItem = new SaleItem();
        saleItem.setId(1l);
        saleItem.setProduct(product);
        saleItem.setSoldQuantity(1l);
        saleItem.setCustomerParent(customer);
        saleItem.setSaleTemplate(saleTemplate);
        saleItem.setMultiplier(multiplier);
        saleItem.setPlantabilityId(plantability);
        saleItem.setSoldQuantity(1l);
        String batchName = "batchName";
        saleItem.setLot(batchName);
        sale.setItems(Sets.newHashSet(saleItem));
        String login = "login";
        BigDecimal amount = BigDecimal.ONE;
        Customer dealerHeadoffice = new Customer();
        dealerHeadoffice.setName("DUMMY_HEADOFFICE");
        when(customerService.getCustomerHeadOffice(any(Customer.class), any(ParticipantTypeEnum.class))).thenReturn(dealerHeadoffice);

        //@when
        quotaService.manageForSale(sale, login);

        //@Should
        verify(customerService).getCustomerHeadOffice(any(Customer.class), any(ParticipantTypeEnum.class));
        verify(quotaControlService).saveTransfer(dealerHeadoffice,
                saleItem.getProduct(), saleItem.getHarvest()
                .getOperationalYear(), QuotaType.AVAILABLE,
                QuotaType.USED, amount, QuotaTransaction.QuotaTransactionType.SALE, saleItem
                .getId(), null, login, multiplier, plantability, batchName);
    }

    @Test
    public void given_search_criteria_when_searchQuotaBy_quota_list_is_returned() throws BusinessException {
        //@Given
        Company company = new Company();
        Crop crop = new Crop("Test crop", company, new Country("Cuba", "CU"));
        Customer dealer = new Customer();
        Technology technology = new Technology("Test technologu", company);
        Brand brand = new Brand();
        Product product = new Product("Test product", StatusEnum.ACTIVE, crop, technology, brand, company);
        product.setId(1l);
        String productDescription = "someProduct";
        Customer multiplier = new Customer();
        multiplier.setId(1l);
        Plantability plantability = new Plantability();
        plantability.setId(1l);
        OperationalYear operationalYear = new OperationalYear("2013");

        List<Map> quotas = new ArrayList<Map>();
        Map<String, Object> aQuotaMap = new HashMap<String, Object>();
        aQuotaMap.put("productId", 1l);
        aQuotaMap.put("plantabilityId", 1l);
        aQuotaMap.put("multiplierId", 1l);
        aQuotaMap.put("lot", "Test lot");
        aQuotaMap.put("balance", BigDecimal.TEN);
        quotas.add(aQuotaMap);
        Customer dealerHeadoffice = new Customer();
        dealerHeadoffice.setName("Dealer headoffice");
        when(customerService.getCustomerHeadOffice(any(Customer.class), any(ParticipantTypeEnum.class))).thenReturn(dealerHeadoffice);
        when(quotaDAO.getQuotasGroupBy(company, crop, dealerHeadoffice, operationalYear, productDescription, product, brand, technology)).thenReturn(quotas);
        when(productDAO.getById(1l)).thenReturn(product);
        when(customerDAO.getCustomerById(1l)).thenReturn(multiplier);
        when(plantabilityDAO.selectById(1l)).thenReturn(plantability);

        //@When
        List<Quota> quotaList = quotaService.searchQuotaBy(company, crop, operationalYear, dealer, technology, brand, product, productDescription);

        //@Should
        verify(quotaDAO).getQuotasGroupBy(company, crop, dealerHeadoffice, operationalYear, productDescription, product, brand, technology);
        assertThat(quotaList).hasSize(1);
    }

    @Test
    public void searchQuotaByInvokesCustomerService_whenSearchQuotaByIsCalled() throws BusinessException {
        //@Given
        Company company = new Company();
        Crop crop = new Crop();
        Customer dealer = new Customer();
        Technology technology = new Technology();
        Brand brand = new Brand();
        Product product = new Product();
        String productDescription = "DUMMY_PRODUCT";
        OperationalYear operationalYear = new OperationalYear();

        //@When
        quotaService.searchQuotaBy(company, crop, operationalYear, dealer, technology, brand, product, productDescription);

        verify(customerService).getCustomerHeadOffice(any(Customer.class), any(ParticipantTypeEnum.class));
    }

    @Test
    public void searchQuotaByUsesDealerHeadoffice_whenSearchQuotaByIsCalled() throws BusinessException {
        //@Given
        Company company = new Company();
        Crop crop = new Crop();
        Customer dealer = new Customer();
        Technology technology = new Technology();
        Brand brand = new Brand();
        Product product = new Product();
        String productDescription = "DUMMY_PRODUCT";
        OperationalYear operationalYear = new OperationalYear();
        Customer dealerHeadoffice = new Customer();
        dealerHeadoffice.setName("Dealer headoffice");
        when(customerService.getCustomerHeadOffice(any(Customer.class), any(ParticipantTypeEnum.class))).thenReturn(dealerHeadoffice);

        //@When
        quotaService.searchQuotaBy(company, crop, operationalYear, dealer, technology, brand, product, productDescription);

        verify(quotaDAO).getQuotasGroupBy(any(Company.class), any(Crop.class), eq(dealerHeadoffice), any(OperationalYear.class), anyString(), any(Product.class), any(Brand.class), any(Technology.class));
    }

    @Test
    public void when_fetchOrCreateQuota_if_quota_does_not_exists_new_quota_is_created() throws EntityNotFoundException {
        //@Given
        Customer customer = new Customer();
        Company company = new Company("Test company");
        Country country = new Country("Cuba", "CU");
        Crop crop = new Crop("Test crop", company, country);
        Technology technology = new Technology("Test technology", company);
        Brand brand = new Brand("Test Brand", company, StatusEnum.ACTIVE);
        Product product = new Product("Test Product", StatusEnum.ACTIVE, crop, technology, brand, company);
        OperationalYear operationalYear = new OperationalYear("2013");
        String lot = "someLot";
        Customer multiplier = new Customer();
        Plantability plantability = new Plantability();
        QuotaType quotaType = QuotaType.AVAILABLE;
        when(quotaControlService.getQuotaBy(any(QuotaFilter.class))).thenThrow(new EntityNotFoundException(""));

        //@When
        quotaService.fetchOrCreateQuota(customer, product, operationalYear, quotaType, lot, multiplier, plantability);

        //@Should
        verify(quotaControlService).save(any(Quota.class));
    }

    @Test
    public void when_fetchOrCreateQuota_if_quota_exists_that_quota_is_retrieved() throws EntityNotFoundException {
        //@Given
        Customer customer = new Customer();
        Company company = new Company("Test company");
        Country country = new Country("Cuba", "CU");
        Crop crop = new Crop("Test crop", company, country);
        Technology technology = new Technology("Test technology", company);
        Brand brand = new Brand("Test Brand", company, StatusEnum.ACTIVE);
        Product product = new Product("Test Product", StatusEnum.ACTIVE, crop, technology, brand, company);
        OperationalYear operationalYear = new OperationalYear("2013");
        String lot = "someLot";
        Customer multiplier = new Customer();
        Plantability plantability = new Plantability();
        QuotaType quotaType = QuotaType.AVAILABLE;
        Quota expectedQuota = new Quota();
        when(quotaControlService.getQuotaBy(any(QuotaFilter.class))).thenReturn(expectedQuota);

        //@When
        Quota resultQuota = quotaService.fetchOrCreateQuota(customer, product, operationalYear, quotaType, lot, multiplier, plantability);

        //@Should
        assertSame(expectedQuota, resultQuota);
    }

    @Test
    public void when_manageCancelFor_quota_cancellation_is_performed() throws EntityNotFoundException {
        //@Given
        OperationalYear operationalYear = new OperationalYear("2013");
        Customer customer = new Customer();
        Company company = new Company("Test company");
        Country country = new Country("Cuba", "CU");
        Crop crop = new Crop("Test crop", company, country);
        Technology technology = new Technology("Test technology", company);
        Brand brand = new Brand("Test Brand", company, StatusEnum.ACTIVE);
        Product product = new Product("Test Product", StatusEnum.ACTIVE, crop, technology, brand, company);
        Customer multiplier = new Customer();
        Plantability plantability = new Plantability();
        String batchName = "lot";
        Long saleCode = 1l;
        String userLogin = "userLogin";
        Quota quota = new Quota(operationalYear, customer, product, QuotaType.AVAILABLE);
        quota.setMultiplier(multiplier);
        quota.setPlantability(plantability);
        quota.setLot(batchName);
        when(quotaControlService.getQuotaBy(any(QuotaFilter.class))).thenReturn(quota);
        BigDecimal value = BigDecimal.ONE;
        when(quotaControlService.selectEntryValue(quota, saleCode, QuotaTransaction.QuotaTransactionType.REVERSAL)).thenReturn(null);
        when(quotaControlService.selectEntryValue(quota, saleCode, QuotaTransaction.QuotaTransactionType.SALE)).thenReturn(value);

        //@When
        quotaService.manageCancelFor(operationalYear, customer, product, saleCode, userLogin, batchName, multiplier, plantability);

        //@Should
        verify(quotaControlService).saveTransfer(quota.getCustomer(), quota.getProduct(), quota.getOperationalYear(),
                quota.getType(), quota.getType(), value.abs(), QuotaTransaction.QuotaTransactionType.REVERSAL,
                saleCode, null, userLogin, multiplier, plantability, batchName);
    }
}
