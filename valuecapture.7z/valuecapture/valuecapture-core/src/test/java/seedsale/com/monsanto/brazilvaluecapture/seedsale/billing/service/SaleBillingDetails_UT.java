package com.monsanto.brazilvaluecapture.seedsale.billing.service;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.stub;

import java.util.Arrays;
import java.util.ResourceBundle;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Matchers;

import com.monsanto.Util.StringUtils;
import com.monsanto.brazilvaluecapture.core.base.SystemTestFixture;
import com.monsanto.brazilvaluecapture.core.user.model.bean.UserContext;
import com.monsanto.brazilvaluecapture.seedsale.billing.model.bean.Billing;
import com.monsanto.brazilvaluecapture.seedsale.billing.model.bean.PaymentStatus;
import com.monsanto.brazilvaluecapture.seedsale.billing.model.bean.PaymentStatusGroup.PaymentStatusAll;
import com.monsanto.brazilvaluecapture.seedsale.billing.model.bean.PaymentStatusGroup.PaymentStatusOption;
import com.monsanto.brazilvaluecapture.seedsale.billing.model.bean.SaleBillingDetails;
import com.monsanto.brazilvaluecapture.seedsale.billing.model.dao.BillingFilter;
import com.monsanto.brazilvaluecapture.seedsale.sale.SaleTestFixture;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.Sale;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.Sale.SaleTypeEnum;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.SaleItem;
import com.monsanto.brazilvaluecapture.seedsale.sale.service.SaleService;
import com.monsanto.brazilvaluecapture.seedsale.sale.service.SaleTestData;
import com.monsanto.brazilvaluecapture.seedsale.template.model.bean.SaleTemplate;

public class SaleBillingDetails_UT {

	private SaleService saleService;
	private SaleBillingDetails saleBillingDetails;
	private UserContext loggedUser;
	private ResourceBundle resourceBundle = ResourceBundle.getBundle("bundle/bundle");
	
	private Billing mockedBillingFullyPaid;
	private Billing mockedBillingCancelled;
	private Billing mockedBillingParcialPaid;
	private Billing mockedBillingNotPaid;

	
	private Sale sale;
	private Sale saleLicense;
	private SaleItem saleItem;
	private SaleTemplate mockSaleTemplate;
	
	private SystemTestFixture systemTF = new SystemTestFixture();
	private SaleTestFixture saleTF = new SaleTestFixture(systemTF);

    private SaleTestData saleFactory;
	
	@Before
	public void init() {
		saleService = mock(SaleService.class);
		loggedUser = mock(UserContext.class);
		saleBillingDetails = new SaleBillingDetails(loggedUser, saleService);
		mockedBillingFullyPaid = mock(Billing.class);
		mockedBillingCancelled = mock(Billing.class);
		mockedBillingParcialPaid = mock(Billing.class);
		mockedBillingNotPaid = mock(Billing.class);
		stub(mockedBillingFullyPaid.getPaymentStatus()).toReturn(PaymentStatus.FULLY_PAID);
		stub(mockedBillingFullyPaid.getPaymentStatusByBillingMethod()).toReturn(PaymentStatus.FULLY_PAID);
		stub(mockedBillingCancelled.getPaymentStatus()).toReturn(PaymentStatus.CANCELLED);
		stub(mockedBillingCancelled.getPaymentStatusByBillingMethod()).toReturn(PaymentStatus.CANCELLED);
		stub(mockedBillingParcialPaid.getPaymentStatus()).toReturn(PaymentStatus.PARCIAL_PAID);
		stub(mockedBillingParcialPaid.getPaymentStatusByBillingMethod()).toReturn(PaymentStatus.PARCIAL_PAID);
		stub(mockedBillingNotPaid.getPaymentStatus()).toReturn(PaymentStatus.NOT_PAID);
		stub(mockedBillingNotPaid.getPaymentStatusByBillingMethod()).toReturn(PaymentStatus.NOT_PAID);

        saleFactory = new SaleTestData(systemTF.regionSaoPaulo2012);
		
		sale = saleFactory.createSale(saleTF.matrixCargil, saleTF.chicoBento, SaleTypeEnum.SALE_SEED);
		mockSaleTemplate = mock(SaleTemplate.class);
		saleItem = SaleTestData.createSaleItem(sale, mockSaleTemplate, saleTF.productBtSoy, null);
		sale.addItem(saleItem);
		
		saleLicense = saleFactory.createSale(saleTF.matrixCargil, saleTF.chicoBento, SaleTypeEnum.LICENSE_SEED);
		SaleTestData.createSaleItem(saleLicense, mockSaleTemplate, saleTF.productBtSoy, null);
		
	}
	
	@Test
	public void given_a_sale_with_one_billing_fullyPaid_should_be_returned_a_details_of_billing_status() {
		Billing[] billings = { mockedBillingFullyPaid };
		stub(saleService.getBillingBy(Matchers.any(BillingFilter.class))).toReturn(Arrays.asList(billings));
		
		String outputBillingStatus = saleBillingDetails.getOutputBillingStatus(resourceBundle);
		Assert.assertFalse("Should not be empty", StringUtils.isEmpty(outputBillingStatus));
		Assert.assertEquals("Should be returned an output with one status", "FULLY_PAID", outputBillingStatus);
	}
	
	@Test
	public void given_a_sale_with_one_billing_parcialPaid_should_be_returned_a_details_of_billing_status() {
		Billing[] billings = { mockedBillingParcialPaid };
		stub(saleService.getBillingBy(Matchers.any(BillingFilter.class))).toReturn(Arrays.asList(billings));
		
		String outputBillingStatus = saleBillingDetails.getOutputBillingStatus(resourceBundle);
		Assert.assertFalse("Should not be empty", StringUtils.isEmpty(outputBillingStatus));
		Assert.assertEquals("Should be returned an output with one status", "PARCIAL_PAID", outputBillingStatus);
	}
	
	@Test
	public void given_a_sale_with_one_billing_notPaid_should_be_returned_a_details_of_billing_status() {
		Billing[] billings = { mockedBillingNotPaid };
		stub(saleService.getBillingBy(Matchers.any(BillingFilter.class))).toReturn(Arrays.asList(billings));
		
		String outputBillingStatus = saleBillingDetails.getOutputBillingStatus(resourceBundle);
		Assert.assertFalse("Should not be empty", StringUtils.isEmpty(outputBillingStatus));
		Assert.assertEquals("Should be returned an output with one status", "NOT_PAID", outputBillingStatus);
	}
	
	@Test
	public void given_a_sale_with_one_billing_cancelled_should_be_returned_a_details_of_billing_status() {
		Billing[] billings = { mockedBillingCancelled };
		stub(saleService.getBillingBy(Matchers.any(BillingFilter.class))).toReturn(Arrays.asList(billings));
		
		String outputBillingStatus = saleBillingDetails.getOutputBillingStatus(resourceBundle);
		Assert.assertFalse("Should not be empty", StringUtils.isEmpty(outputBillingStatus));
		Assert.assertEquals("Should be returned an output with one status", "CANCELLED", outputBillingStatus);
	}
	
	@Test
	public void given_a_sale_with_four_billings_of_all_status_should_be_returned_a_details_of_given_billings_status() {
		Billing[] billings = { mockedBillingFullyPaid, mockedBillingNotPaid, mockedBillingParcialPaid, mockedBillingCancelled };
		stub(saleService.getBillingBy(Matchers.any(BillingFilter.class))).toReturn(Arrays.asList(billings));
		
		String outputBillingStatus = saleBillingDetails.getOutputBillingStatus(resourceBundle);
		Assert.assertFalse("Should not be empty", StringUtils.isEmpty(outputBillingStatus));
		Assert.assertEquals("Should be returned an output with one status", "CANCELLED <BR> FULLY_PAID <BR> NOT_PAID <BR> PARCIAL_PAID", outputBillingStatus);
	}
	
	@Test
	public void given_a_sale_with_three_billings_of_different_status_should_be_returned_a_details_of_given_billings_status() {
		Billing[] billings = { mockedBillingFullyPaid, mockedBillingParcialPaid, mockedBillingCancelled };
		stub(saleService.getBillingBy(Matchers.any(BillingFilter.class))).toReturn(Arrays.asList(billings));
		
		String outputBillingStatus = saleBillingDetails.getOutputBillingStatus(resourceBundle);
		Assert.assertFalse("Should not be empty", StringUtils.isEmpty(outputBillingStatus));
		Assert.assertEquals("Should be returned an output with one status", "CANCELLED <BR> FULLY_PAID <BR> PARCIAL_PAID", outputBillingStatus);
	}
	
	@Test
	public void given_a_sale_of_sale_type_seed_type_should_return_a_sale_type() {
		stub(mockSaleTemplate.getSaleType()).toReturn(SaleTypeEnum.SALE_SEED);
		
		SaleTypeEnum type = sale.getSaleType();
		
		Assert.assertNotNull("Should not be null",type);
		Assert.assertEquals("Should be equal", SaleTypeEnum.SALE_SEED, type);
		
	}
	
	@Test
	public void given_a_sale_of_sale_type_licenseSeed_type_should_return_a_sale_type() {
		stub(mockSaleTemplate.getSaleType()).toReturn(SaleTypeEnum.LICENSE_SEED);
		
		SaleTypeEnum type = saleLicense.getSaleType();
		
		Assert.assertNotNull("Should not be null",type);
		Assert.assertEquals("Should be equal", SaleTypeEnum.LICENSE_SEED, type);
		
	}
	
	@Test
	public void given_a_sale_without_sale_items_should_return_null() {
		sale.setSaleType(null);
		
		SaleTypeEnum type = sale.getSaleType();
		
		Assert.assertNull("Should be null",type);		
		
	}
	
	@Test
	public void sanity_check() {
		
		Assert.assertEquals("Should be equal", PaymentStatusAll.NOT_PAID_BILLING.getPaymentStatus(), PaymentStatusOption.NOT_PAID_BILLING);
		Assert.assertEquals("Should be equal", PaymentStatusAll.NOT_PAID.getPaymentStatus(), PaymentStatus.NOT_PAID);
		Assert.assertEquals("Should be equal", PaymentStatusAll.CANCELLED.getPaymentStatus(), PaymentStatus.CANCELLED);
		Assert.assertEquals("Should be equal", PaymentStatusAll.PARCIAL_PAID.getPaymentStatus(), PaymentStatus.PARCIAL_PAID);
		Assert.assertEquals("Should be equal", PaymentStatusAll.FULLY_PAID.getPaymentStatus(), PaymentStatus.FULLY_PAID);
		Assert.assertEquals("Should be equal", PaymentStatusAll.NO_VALUE.getPaymentStatus(), PaymentStatus.NO_VALUE);

	}
	
}
