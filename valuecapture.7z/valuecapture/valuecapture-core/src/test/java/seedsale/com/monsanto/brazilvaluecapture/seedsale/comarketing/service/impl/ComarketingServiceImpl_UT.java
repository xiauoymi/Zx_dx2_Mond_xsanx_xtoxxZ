package com.monsanto.brazilvaluecapture.seedsale.comarketing.service.impl;

import static org.fest.reflect.core.Reflection.field;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.fest.assertions.Assertions.assertThat;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.monsanto.brazilvaluecapture.core.customer.model.bean.Customer;
import com.monsanto.brazilvaluecapture.seedsale.comarketing.model.bean.ComktInvoice;
import com.monsanto.brazilvaluecapture.seedsale.comarketing.model.dao.ComarketingDAO;
import com.monsanto.brazilvaluecapture.seedsale.comarketing.service.ComarketingService;
import com.monsanto.brazilvaluecapture.seedsale.cutoffTons.model.dao.CutoffTonsDAO;
import com.monsanto.brazilvaluecapture.seedsale.cutoffTons.service.CutoffTonsService;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.CutOffTonsHeadOffice;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.CutOffTonsHeadOffice.HeadOfficeCutoffType;
import com.monsanto.brazilvaluecapture.seedsale.template.model.bean.SaleTemplate;

public class ComarketingServiceImpl_UT {

	private ComarketingService comarketingService;

	@Mock
	private ComarketingDAO comarketingDAO;
	
	@Mock
	private CutoffTonsService cutoffTonsService;

	private ComktInvoice comktInvoice;
	

	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
		comarketingService = new ComarketingServiceImpl();
		comktInvoice = new ComktInvoice();
		field("comarketingDAO").ofType(ComarketingDAO.class)
				.in(comarketingService).set(comarketingDAO);
	}

	@Test
	public void test_save() {
		comarketingService.save(comktInvoice);
		verify(comarketingDAO, times(1)).save(comktInvoice);
	}

	@Test
	public void test_saveComktHeadOfficeTonsAmount() {
		CutOffTonsHeadOffice tonsByHeadOffice = new CutOffTonsHeadOffice();
		cutoffTonsService.save(tonsByHeadOffice);
		verify(this.cutoffTonsService, times(1)).save(tonsByHeadOffice);
	}

	@Test
	public void test_getComarketingTonsLimit() {
		SaleTemplate st = any(SaleTemplate.class);
		Customer c = any(Customer.class);
		HeadOfficeCutoffType h = any(HeadOfficeCutoffType.class);
		assertThat(cutoffTonsService.getCutoffTonsHeadOffice(st,c,h)).isEmpty();
	}
}
