package com.monsanto.brazilvaluecapture.seedsale.product;

import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import junit.framework.Assert;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.hibernate.classic.Session;
import org.junit.Before;
import org.junit.Test;

import com.monsanto.brazilvaluecapture.core.foundation.RandomTestData;
import com.monsanto.brazilvaluecapture.core.foundation.model.bean.StatusEnum;
import com.monsanto.brazilvaluecapture.core.grower.CreateTestData;
import com.monsanto.brazilvaluecapture.seedsale.harvest.HarvestTestData;
import com.monsanto.brazilvaluecapture.seedsale.harvest.model.bean.Harvest;
import com.monsanto.brazilvaluecapture.seedsale.harvest.model.bean.Plantability;
import com.monsanto.brazilvaluecapture.seedsale.harvest.model.dao.PlantabilityDAO;
import com.monsanto.brazilvaluecapture.seedsale.harvest.model.dao.impl.PlantabilityDAOImpl;
import com.monsanto.brazilvaluecapture.seedsale.harvest.service.PlantabilityWithProductivityUndeletableException;
import com.monsanto.brazilvaluecapture.seedsale.harvest.service.PlantabilityWithSaleTemplateUndeletableException;

public class Plantability_UT extends CreateTestData {

	PlantabilityDAO plantabilityDAO;
	Session mockSession;
	SessionFactory mockSessionFactory;

	@Before
	public void setup() {

		mockSessionFactory = mock(SessionFactory.class);
		mockSession = mock(Session.class);
		when(mockSessionFactory.getCurrentSession()).thenReturn(mockSession);

		plantabilityDAO = new PlantabilityDAOImpl(mockSessionFactory);
	}

	private void testAssert(Plantability plantability) {
		Assert.assertNotNull(plantability);
		Assert.assertNotNull(plantability.getDescription());
		Assert.assertNotNull(plantability.getHarvest());
		Assert.assertNotNull(plantability.getStatus());
		Assert.assertNull(plantability.getId());
	}

//	@SuppressWarnings({ "unchecked", "rawtypes" })
//	@Test
//	public void descriptionIsNull() {
//		Plantability plantability = createPlantabilityByParameter(null, StatusEnum.ACTIVE, createBasicHarvest(StatusEnum.ACTIVE));
//
//		ClassValidator classValidator = new ClassValidator(plantability.getClass());  
//        InvalidValue[] invalidValues = classValidator.getInvalidValues(plantability);
//        
//        Assert.assertTrue(invalidValues.length == 1);
//	}
	
	@Test
	public void selectAllPlantabilityEqualsInsertTest() {

		Harvest harvest = createBasicHarvest(StatusEnum.ACTIVE);
		Plantability plantability = PlantabilityTestData.createPlantability(harvest);

		doNothing().when(mockSession).saveOrUpdate(plantability);

		plantabilityDAO.save(plantability);

		Assert.assertNotNull(plantability);

		Criteria mockCriteria = mock(Criteria.class);

		when(mockSession.createCriteria(Plantability.class, "plantability")).thenReturn(
				mockCriteria);

		List<Plantability> plantabilities = new ArrayList<Plantability>();
		plantabilities.add(plantability);

		when(mockCriteria.list()).thenReturn(plantabilities);

		List<Plantability> list = plantabilityDAO.selectAllPlantabilityEquals(plantability);

		Assert.assertEquals(plantabilities, list);

	}
	
	@Test
	public void selectAllProductEqualsUpdateTest() {

		Harvest harvest = createBasicHarvest(StatusEnum.ACTIVE);
		Plantability plantability = PlantabilityTestData.createPlantability(harvest);

		doNothing().when(mockSession).saveOrUpdate(plantability);

		plantabilityDAO.save(plantability);
		plantability.setId(RandomTestData.createRandomLong());

		Assert.assertNotNull(plantability);

		Criteria mockCriteria = mock(Criteria.class);

		when(mockSession.createCriteria(Plantability.class, "plantability")).thenReturn(
				mockCriteria);

		List<Plantability> plantabilities = new ArrayList<Plantability>();
		plantabilities.add(plantability);

		when(mockCriteria.list()).thenReturn(plantabilities);

		List<Plantability> list = plantabilityDAO.selectAllPlantabilityEquals(plantability);

		Assert.assertEquals(plantabilities, list);

	}

	@Test
	public void createDomainTest() {
		Harvest harvest = createBasicHarvest(StatusEnum.ACTIVE);
		Plantability plantability = PlantabilityTestData.createPlantability(harvest);
		testAssert(plantability);
	}

	@Test
	public void createDomainByHarvestTest() {
		Harvest harvest = createBasicHarvest(StatusEnum.ACTIVE);
		Plantability plantability = PlantabilityTestData.createPlantability(harvest);
		testAssert(plantability);
	}

	@Test
	public void createPlantabilityTest() {
		Harvest harvest = createBasicHarvest(StatusEnum.ACTIVE);
		Plantability plantability = PlantabilityTestData.createPlantability(harvest);

		doNothing().when(mockSession).saveOrUpdate(plantability);

		plantabilityDAO.save(plantability);

		testAssert(plantability);
	}

	@Test
	public void deletePlantabilityTest() throws PlantabilityWithProductivityUndeletableException, PlantabilityWithSaleTemplateUndeletableException {
		Harvest harvest = createBasicHarvest(StatusEnum.ACTIVE);
		Plantability plantability = PlantabilityTestData.createPlantability(harvest);

		doNothing().when(mockSession).delete(plantability);

		Long id = plantability.getPrimaryKey();

		plantabilityDAO.delete(plantability);

		when(mockSession.get(Plantability.class, id)).thenReturn(null);
		Plantability plantabilityBase = plantabilityDAO.selectById(id);
		Assert.assertNull(plantabilityBase);
	}

	@Test
	public void selectAllPlantabilityTest() {
		Query mockQuery = mock(Query.class);

		when(mockSession.createQuery(anyString())).thenReturn(mockQuery);

		List<Plantability> plantabilities = createSomePlantability(createBasicHarvest(StatusEnum.ACTIVE));

		when(mockQuery.list()).thenReturn(plantabilities);

		List<Plantability> plantabilitiesBase = plantabilityDAO
				.selectAll();

		Assert.assertEquals(plantabilities, plantabilitiesBase);
	}

	@Test
	public void selectPlantabilityByFilterTest() {
		Harvest harvest = createBasicHarvest(StatusEnum.ACTIVE);
		Plantability plantability = PlantabilityTestData.createPlantability(harvest);

		doNothing().when(mockSession).saveOrUpdate(plantability);

		plantabilityDAO.save(plantability);

		testAssert(plantability);

		Criteria mockCriteria = mock(Criteria.class);

		when(mockSession.createCriteria(Plantability.class, "p")).thenReturn(
				mockCriteria);

		List<Plantability> plantabilities = createSomePlantability(createBasicHarvest(StatusEnum.ACTIVE));

		when(mockCriteria.list()).thenReturn(plantabilities);

		List<Plantability> plantabilitiesBase = plantabilityDAO
				.selectByFilter(plantability);

		Assert.assertEquals(plantabilities, plantabilitiesBase);
	}

	@Test
	public void selectPlantabilityByFilterWithoutDescriptionTest() {
		Plantability plantability = PlantabilityTestData.createPlantability(
				createBasicHarvest(StatusEnum.ACTIVE), RandomTestData.createRandomString(),
				StatusEnum.ACTIVE);

		doNothing().when(mockSession).saveOrUpdate(plantability);

		plantabilityDAO.save(plantability);

		testAssert(plantability);

		plantability.setDescription(null);

		Criteria mockCriteria = mock(Criteria.class);

		when(mockSession.createCriteria(Plantability.class, "p")).thenReturn(
				mockCriteria);

		List<Plantability> plantabilities = createSomePlantability(createBasicHarvest(StatusEnum.ACTIVE));

		when(mockCriteria.list()).thenReturn(plantabilities);

		List<Plantability> plantabilitiesBase = plantabilityDAO
				.selectByFilter(plantability);

		Assert.assertEquals(plantabilities, plantabilitiesBase);
	}
	
	@Test
	public void selectPlantabilityByHarvest(){
		
		Harvest itemHarvest = HarvestTestData.createABrazilianHarvest();
		
		List<Plantability> listResults = createSomePlantability(itemHarvest);

		Assert.assertNotNull(itemHarvest.getCompleteDescription());

		Query mockQuery = mock(Query.class);

		when(mockSession.createQuery(anyString())).thenReturn(mockQuery);
		when(mockQuery.setParameter("p_harvest", itemHarvest)).thenReturn(mockQuery);
		
		when(mockQuery.list()).thenReturn(listResults);
		
		// And execute search
		List<Plantability> list = plantabilityDAO.selectByHarvest(itemHarvest);

		// Then result is not null
		Assert.assertNotNull(list);
		
	}
}
