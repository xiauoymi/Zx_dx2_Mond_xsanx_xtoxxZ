package com.monsanto.brazilvaluecapture.seedsale.sale.service.parser.saleOrder;

import com.monsanto.brazilvaluecapture.core.base.model.bean.Company;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Customer;
import com.monsanto.brazilvaluecapture.core.customer.service.CustomerNotFoundException;
import com.monsanto.brazilvaluecapture.core.foundation.service.EntityNotFoundException;
import com.monsanto.brazilvaluecapture.core.grower.model.bean.Grower;
import com.monsanto.brazilvaluecapture.core.user.service.DocumentMismatchException;
import com.monsanto.brazilvaluecapture.pod.rol.model.bean.GermoSupplier;
import com.monsanto.brazilvaluecapture.seedsale.product.model.bean.Product;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.Sale;
import com.monsanto.brazilvaluecapture.seedsale.sale.service.SaleOrderImportService;
import com.monsanto.brazilvaluecapture.seedsale.template.model.bean.DueDateValue;
import com.monsanto.brazilvaluecapture.seedsale.template.model.bean.Price;
import com.monsanto.brazilvaluecapture.seedsale.template.model.bean.SaleTemplate;
import com.monsanto.brazilvaluecapture.seedsale.template.service.DueDateCanNotBeEqualsAnotherException;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import static com.monsanto.brazilvaluecapture.core.regionalization.VCCountry.ARGENTINA;
import static org.fest.reflect.core.Reflection.field;
import static org.junit.Assert.*;
import static org.mockito.Matchers.any;

/**
 * Created by IntelliJ IDEA.
 * User: HGFIOR
 * Date: 04/07/13
 * Time: 16:52
 * To change this template use File | Settings | File Templates.
 */
public class PreCampaignConverter_UT {

    private CsvPreCampaign csvPreCampaign;

    @Before
    public void setUp() throws Exception {
        CsvPreCampaign csvPreCampaign = new CsvPreCampaign();
        field("saleOrderDate").ofType(String.class).in(csvPreCampaign).set("15.04.2013");
        field("SAPSaleOrderId").ofType(String.class).in(csvPreCampaign).set("107114");
        field("retailerSAPId").ofType(String.class).in(csvPreCampaign).set("1008080");
        field("growerSAPId").ofType(String.class).in(csvPreCampaign).set("0001099746");
        field("tonsAmount").ofType(String.class).in(csvPreCampaign).set("100.000");
        field("totalARS").ofType(String.class).in(csvPreCampaign).set("184852.50");
        field("totalUSD").ofType(String.class).in(csvPreCampaign).set("36750.00");
        field("germoSupplier").ofType(String.class).in(csvPreCampaign).set("1");
        field("paymentDate").ofType(String.class).in(csvPreCampaign).set("15.04.2013");
        field("invoiceSAPNumber").ofType(String.class).in(csvPreCampaign).set("666");
        field("receiptSAPNumber").ofType(String.class).in(csvPreCampaign).set("777");
        field("totalBag40").ofType(String.class).in(csvPreCampaign).set("10");
        field("totalBag25").ofType(String.class).in(csvPreCampaign).set("5");
        this.csvPreCampaign = csvPreCampaign;

    }

    private SaleOrderImportService initializeCSV() throws EntityNotFoundException, CustomerNotFoundException, DocumentMismatchException {
        SaleOrderImportService saleOrderImportService = Mockito.mock(SaleOrderImportService.class);
        Customer customer = Mockito.mock(Customer.class);
        Grower grower = Mockito.mock(Grower.class);
        GermoSupplier germoSupplier = Mockito.mock(GermoSupplier.class);
        SaleTemplate saleTemplate = Mockito.mock(SaleTemplate.class);

        Product product = Mockito.mock(Product.class);
        HashSet<Product> products = new HashSet<Product>();
        products.add(product);
        Company company = Mockito.mock(Company.class);
        Price price = Mockito.mock(Price.class);
        HashSet<Price> prices = new HashSet<Price>();
        prices.add(price);
        DueDateValue dueDate = new DueDateValue();
        Set<DueDateValue> dueDates = new HashSet<DueDateValue>();
        dueDates.add(dueDate);

        Mockito.when(saleOrderImportService.getCountry()).thenReturn(ARGENTINA);
        Mockito.when(saleOrderImportService.getCustomerBySapCode(any(String.class))).thenReturn(customer);
        Mockito.when(saleOrderImportService.getGrowerByCustomerSapId(any(String.class))).thenReturn(grower);
        Mockito.when(saleOrderImportService.getGermoSupplier(any(String.class))).thenReturn(germoSupplier);
        Mockito.when(saleOrderImportService.getSaleTemplate(any(Sale.SaleTypeEnum.class))).thenReturn(saleTemplate);

        Mockito.when(saleTemplate.getProducts()).thenReturn(products);
        Mockito.when(saleTemplate.getProducts()).thenReturn(products);
        Mockito.when(saleTemplate.getPrices()).thenReturn(prices);
        Mockito.when(price.getDueDates()).thenReturn(dueDates);
        return saleOrderImportService;
    }

    @Test
    public void testConvertIGetNoViolationsAndSaleIsNotNull() throws Exception {
        SaleOrderImportService saleOrderImportService = initializeCSV();

        PreCampaignConverter pc = new PreCampaignConverter(saleOrderImportService);
        pc.convert(csvPreCampaign);
        assertTrue(pc.getViolations().isEmpty());
        assertNotNull(pc.getSale());
        assertTrue(pc.getSale().getItems().iterator().next().getSoldQuantity() == Long.parseLong("525"));
    }

    @Test
    public void testConvertWithoutSaleOrderDateGivesAViolationAndNullSales() throws Exception {
        SaleOrderImportService saleOrderImportService = initializeCSV();

        PreCampaignConverter pc = new PreCampaignConverter(saleOrderImportService);

        field("saleOrderDate").ofType(String.class).in(csvPreCampaign).set(null);
        pc.convert(csvPreCampaign);
        assertTrue(!pc.getViolations().isEmpty());
        assertNull(pc.getSale());
        assertTrue(pc.getViolations().size()==1);
        assertTrue(pc.getViolations().get(0).getMessage().equalsIgnoreCase("Sale Order Date is required"));
    }

    @Test
    public void testConvertWithoutGrowerSaPIDGivesAViolationAndNullSales() throws Exception {
        SaleOrderImportService saleOrderImportService = initializeCSV();

        PreCampaignConverter pc = new PreCampaignConverter(saleOrderImportService);

        field("growerSAPId").ofType(String.class).in(csvPreCampaign).set(null);
        pc.convert(csvPreCampaign);
        assertTrue(!pc.getViolations().isEmpty());
        assertNull(pc.getSale());
        assertTrue(pc.getViolations().size()==1);
    }

     @Test
    public void testConvertWithEmptySAPSaleOrderIdGivesAViolationAndNullSales() throws Exception {
        SaleOrderImportService saleOrderImportService = initializeCSV();

        PreCampaignConverter pc = new PreCampaignConverter(saleOrderImportService);

        field("SAPSaleOrderId").ofType(String.class).in(csvPreCampaign).set(null);
        pc.convert(csvPreCampaign);
        assertTrue(!pc.getViolations().isEmpty());
        assertNull(pc.getSale());
        assertTrue(pc.getViolations().size()==1);
    }

    @Test
    public void testConvertWithNegativeSAPSaleOrderIdGivesAViolationAndNullSales() throws Exception {
        SaleOrderImportService saleOrderImportService = initializeCSV();

        PreCampaignConverter pc = new PreCampaignConverter(saleOrderImportService);

        field("SAPSaleOrderId").ofType(String.class).in(csvPreCampaign).set("-123456");
        pc.convert(csvPreCampaign);
        assertTrue(!pc.getViolations().isEmpty());
        assertNull(pc.getSale());
        assertTrue(pc.getViolations().size()==1);
    }

    @Test
    public void testConvertAndTotalARSFieldIsNotANumberGivesAViolationAndNullSales() throws Exception {
        SaleOrderImportService saleOrderImportService = initializeCSV();

        PreCampaignConverter pc = new PreCampaignConverter(saleOrderImportService);

        field("totalARS").ofType(String.class).in(csvPreCampaign).set("IT'S_NOT_A_NUMBER");
        pc.convert(csvPreCampaign);
        assertTrue(!pc.getViolations().isEmpty());
        assertNull(pc.getSale());
        assertTrue(pc.getViolations().size()==1);
    }

    @Test
    public void testConvertSaleOrderDateFormatIsInvalidAndRetailerSAPIdIsEmptyGives2ViolationsAndNullSales() throws Exception {
        SaleOrderImportService saleOrderImportService = initializeCSV();

        PreCampaignConverter pc = new PreCampaignConverter(saleOrderImportService);

        field("saleOrderDate").ofType(String.class).in(csvPreCampaign).set("15/04/2013");
        field("retailerSAPId").ofType(String.class).in(csvPreCampaign).set("");
        pc.convert(csvPreCampaign);
        assertTrue(!pc.getViolations().isEmpty());
        assertNull(pc.getSale());
        assertTrue(pc.getViolations().size()==2);
    }

    @Test
    public void testConvertRetailerSAPIdIsEmptyGivesAViolationAndNullSales() throws Exception {
        SaleOrderImportService saleOrderImportService = initializeCSV();

        PreCampaignConverter pc = new PreCampaignConverter(saleOrderImportService);

        field("retailerSAPId").ofType(String.class).in(csvPreCampaign).set(" ");
        pc.convert(csvPreCampaign);
        assertTrue(!pc.getViolations().isEmpty());
        assertNull(pc.getSale());
        assertTrue(pc.getViolations().size()==1);
    }

     @Test
    public void testConvertGermoSupplierIsNullGives2ViolationsAndNullSales() throws Exception {
        SaleOrderImportService saleOrderImportService = initializeCSV();

        PreCampaignConverter pc = new PreCampaignConverter(saleOrderImportService);

        field("germoSupplier").ofType(String.class).in(csvPreCampaign).set(null);
        Mockito.when(saleOrderImportService.getGermoSupplier(any(String.class))).thenReturn(null);
        pc.convert(csvPreCampaign);
        assertTrue(pc.getViolations().isEmpty());
        assertNotNull(pc.getSale());
        assertTrue(pc.getSale().getTotalCreditValue() == Long.parseLong("100000"));
        assertTrue(pc.getSale().getItems().iterator().next().getSoldQuantity() == Long.parseLong("100000"));
    }
}

