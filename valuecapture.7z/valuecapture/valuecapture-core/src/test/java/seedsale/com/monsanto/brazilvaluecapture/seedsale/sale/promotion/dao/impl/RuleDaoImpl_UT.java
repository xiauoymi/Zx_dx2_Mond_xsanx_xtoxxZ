package com.monsanto.brazilvaluecapture.seedsale.sale.promotion.dao.impl;

import com.google.common.collect.Lists;
import com.monsanto.brazilvaluecapture.seedsale.sale.promotion.model.bean.Rule;
import com.monsanto.brazilvaluecapture.seedsale.sale.promotion.model.dao.impl.RuleDaoImpl;
import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.hibernate.classic.Session;
import org.junit.Before;
import org.junit.Test;

import java.util.List;

import static org.fest.assertions.Assertions.assertThat;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.*;

/**
 * User: PPERA
 * Date: 4/29/13
 * Time: 12:40 PM
 */
public class RuleDaoImpl_UT {
    private RuleDaoImpl ruleDaoImpl;
    private Session session;
    private Query query;

    @Before
    public void setUp() {
        SessionFactory sessionFactory = mock(SessionFactory.class);
        this.session = mock(Session.class);
        when(sessionFactory.getCurrentSession()).thenReturn(this.session);
        this.ruleDaoImpl = new RuleDaoImpl(sessionFactory);
        this.query = mock(Query.class);
        when(this.session.createQuery(anyString())).thenReturn(this.query);
    }

    @Test
    public void testFindRuleByIdCallsSessionFindById1_WhenFindingRule1() {
        // @Given a rule id 1
        int ruleId = 1;

        // @When finding the rule
        this.ruleDaoImpl.findRuleById(ruleId);

        // @Then session.load is called for Rule and id 1
        verify(this.session, times(1)).load(Rule.class, ruleId);
    }

    @Test
    public void testFindRuleByIdCallsSessionFindById5_WhenFindingRule5() {
        // @Given a rule id 5
        int ruleId = 5;

        // @When finding the rule
        this.ruleDaoImpl.findRuleById(ruleId);

        // @Then session.load is called for Rule and id 5
        verify(this.session, times(1)).load(Rule.class, ruleId);
    }

    @Test
    public void testFindRuleByIdReturnsFoundRule_WhenFindingRule() {
        // @Given a rule id 5
        int ruleId = 5;
        Rule rule5 = new Rule();
        when(this.session.load(Rule.class, ruleId)).thenReturn(rule5);

        // @When finding the rule
        Rule rule = this.ruleDaoImpl.findRuleById(ruleId);

        // @Then session.load is called for Rule and id 5
        assertThat(rule).isSameAs(this.session.load(Rule.class, ruleId));
    }

    @Test
    public void testFindRuleAllRulesCreatesAndExecutesAQuery_WhenFindingAllRules() {
        // @When finding all the rules
        this.ruleDaoImpl.findAllRules();

        // @Then a query is created and executed
        verify(this.session, times(1)).createQuery(RuleDaoImpl.FIND_ALL_ENABLED_RULES);
        verify(this.query, times(1)).list();
    }

    @Test
    public void testFindRuleAllRulesReturnsQueryResult_WhenFindingAllRules() {
        // @Given a query result
        when(this.query.list()).thenReturn(Lists.newArrayList());

        // @When finding all the rules
        List<Rule> rules = this.ruleDaoImpl.findAllRules();

        // @Then query.list result is returned
        assertThat(rules).isSameAs(this.query.list());
    }
}
