package com.monsanto.brazilvaluecapture.seedsale.sale.model.bean;

import static junit.framework.Assert.fail;
import static org.fest.assertions.Assertions.assertThat;
import static org.mockito.Mockito.mock;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

import com.monsanto.brazilvaluecapture.core.base.model.bean.Company;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Crop;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Document;
import com.monsanto.brazilvaluecapture.core.base.model.bean.DocumentType;
import com.monsanto.brazilvaluecapture.core.base.model.bean.OperationalYear;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Customer;
import com.monsanto.brazilvaluecapture.core.foundation.service.BusinessException;
import com.monsanto.brazilvaluecapture.core.grower.model.bean.Grower;
import com.monsanto.brazilvaluecapture.core.grower.model.bean.Withholding;
import com.monsanto.brazilvaluecapture.seedsale.harvest.model.bean.Harvest;
import com.monsanto.brazilvaluecapture.seedsale.product.model.bean.Product;
import com.monsanto.brazilvaluecapture.seedsale.template.model.bean.SaleTemplate;

/**
 * Created by IntelliJ IDEA.
 * User: HGFIOR
 * Date: 30/05/13
 * Time: 16:34
 * To change this template use File | Settings | File Templates.
 */
public class PaymentSlipDTO_UT {
    @Test
    public void testGetHarvestsReturns2013_WhenGettingTheHarvestOfAPaymentSlipDTOWithASaleWithAnItemWithACompanyWithAHarvestWithYear2013() throws BusinessException {
        // @Given   a Sale, with an Item with a Company with a harvest for year 2013.
        Customer customer = new Customer();
        Sale sale = new Sale(customer, new Grower());
        Product product = new Product();
        /*Crop crop2 = mock(Crop.class);
        product.setCrop(crop2);*/
        Company company = new Company();
        product.setCompany(company);
        Harvest harvest = new Harvest();
        harvest.setOperationalYear(new OperationalYear("2013"));
        Crop crop = mock(Crop.class);
        harvest.setCrop(crop);
        company.addHarvest(harvest);
        SaleItem saleItem = new SaleItem(product, new SaleTemplate(), customer);
        saleItem.getSaleTemplate().setHarvest(harvest);
        sale.addItem(saleItem);
        OrderRegistrationResultFromSAPDTO orderRegistrationResultFromSAPDTO = null;
        BankAgreement bankAgreement = mock(BankAgreement.class);
        List<BankAgreement> bankAgreementList = new ArrayList<BankAgreement>();
        bankAgreementList.add(bankAgreement);
        Document document = new Document();
        DocumentType dt = new DocumentType();
        dt.setMask("");
        document.setDocumentType(dt);
        Withholding withholding = null;


        sale.getGrower().setDocument(document);
        PaymentSlipDTO paymentSlipDTO = new PaymentSlipDTO(sale, orderRegistrationResultFromSAPDTO, bankAgreementList, withholding);
        // @When   getting Harvest
        String paymentSlipDTOHarvest = paymentSlipDTO.getHarvest();
        // @Then   I get  2013
        assertThat(paymentSlipDTOHarvest).isEqualTo("2013/14");
    }

    @Test
    public void testGetHarvestsReturns2014_WhenGettingTheHarvestOfAPaymentSlipDTOWithASaleWithAnItemWithACompanyWithAHarvestWithYear2014() throws BusinessException {
        // @Given   a Sale, with an Item with a Company with a harvest for year 2014.
        Customer customer = new Customer();
        Sale sale = new Sale(customer, new Grower());
        Product product = new Product();
        Company company = new Company();
        product.setCompany(company);
        Harvest harvest = new Harvest();
        harvest.setOperationalYear(new OperationalYear("2014"));
        Crop crop = mock(Crop.class);
        harvest.setCrop(crop);
        company.addHarvest(harvest);
        SaleItem saleItem = new SaleItem(product, new SaleTemplate(), customer);
        saleItem.getSaleTemplate().setHarvest(harvest);
        sale.addItem(saleItem);
        OrderRegistrationResultFromSAPDTO orderRegistrationResultFromSAPDTO = null;
        BankAgreement bankAgreement = mock(BankAgreement.class);
        List<BankAgreement> bankAgreementList = new ArrayList<BankAgreement>();
        bankAgreementList.add(bankAgreement);
        Document document = new Document();
        DocumentType dt = new DocumentType();
        dt.setMask("");
        document.setDocumentType(dt);
        sale.getGrower().setDocument(document);
        Withholding withholding = null;

        PaymentSlipDTO paymentSlipDTO = new PaymentSlipDTO(sale, orderRegistrationResultFromSAPDTO, bankAgreementList, withholding);
        // @When   getting Harvest
        String paymentSlipDTOHarvest = paymentSlipDTO.getHarvest();
        // @Then   I get  2014
        assertThat(paymentSlipDTOHarvest).isEqualTo("2014/15");
    }

    @Test
    public void testGetHarvestsReturnsBusinessException_WhenSaleHasNoItems() throws BusinessException{
       // @Given   a Sale, with no Items with a Company with a harvest for any year .
        Customer customer = new Customer();
        Sale sale = new Sale(customer, new Grower());
        Product product = new Product();
        Company company = new Company();
        product.setCompany(company);
        Harvest harvest = new Harvest();
        harvest.setOperationalYear(new OperationalYear("YEAR"));
        company.addHarvest(harvest);
        OrderRegistrationResultFromSAPDTO orderRegistrationResultFromSAPDTO = null;
        List<BankAgreement> bankAgreementList = new ArrayList<BankAgreement>();
        BankAgreement bankAgreement = mock(BankAgreement.class);
        bankAgreementList.add(bankAgreement);
        Document document = new Document();
        DocumentType dt = new DocumentType();
        dt.setMask("");
        document.setDocumentType(dt);
        sale.getGrower().setDocument(document);
        Withholding withholding = null;

        PaymentSlipDTO paymentSlipDTO = new PaymentSlipDTO(sale, orderRegistrationResultFromSAPDTO, bankAgreementList, withholding);
        // @When   getting Harvest
        try {
            String paymentSlipDTOHarvest = paymentSlipDTO.getHarvest();
            fail();
        } catch (Exception e) {
            // @Then I get a BusinessException
            assertThat(e).isInstanceOf(BusinessException.class);
            assertThat(e).hasMessage("Illegal state");
        }
    }

}
