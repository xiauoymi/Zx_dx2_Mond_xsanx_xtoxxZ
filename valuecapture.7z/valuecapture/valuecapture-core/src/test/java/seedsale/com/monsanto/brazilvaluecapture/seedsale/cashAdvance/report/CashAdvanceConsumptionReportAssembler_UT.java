package com.monsanto.brazilvaluecapture.seedsale.cashAdvance.report;

import com.monsanto.brazilvaluecapture.core.base.model.bean.Company;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Crop;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Document;
import com.monsanto.brazilvaluecapture.core.base.model.bean.OperationalYear;
import com.monsanto.brazilvaluecapture.core.commercialhierarchy.model.bean.ItsDistrict;
import com.monsanto.brazilvaluecapture.core.commercialhierarchy.model.bean.ItsRegion;
import com.monsanto.brazilvaluecapture.core.commercialhierarchy.model.bean.ItsUnity;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Customer;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.HeadOffice;
import com.monsanto.brazilvaluecapture.seedsale.cashAdvance.model.bean.CashAdvanceTransaction;
import com.monsanto.brazilvaluecapture.seedsale.cashAdvance.model.dto.CashAdvanceReportResponseDTO;
import com.monsanto.brazilvaluecapture.seedsale.harvest.model.bean.Harvest;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.Sale;
import org.apache.commons.collections.iterators.IteratorEnumeration;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.*;

import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class CashAdvanceConsumptionReportAssembler_UT {

    CashAdvanceReportAssembler assembler;

    private final static int SIZE = 37;

    @Mock
    ItsDistrict itsDistrict;
    @Mock
    ItsUnity itsUnity;
    @Mock
    ItsRegion itsRegion;

    @Before
    public void setUp() throws Exception {
        MockitoAnnotations.initMocks(this);

        HashMap<String, String> map = new HashMap<String, String>();
        map.put("label.sale.type.multiplier","Dummy message");
        map.put("label.sale.type.grain.trade","Dummy message");


        RB resourceBundle = new RB();
        resourceBundle.setProperties((Map)map);

        assembler = new CashAdvanceConsumptionReportAssembler(resourceBundle);

        when(itsDistrict.getItsUnity()).thenReturn(itsUnity);
        when(itsDistrict.getItsRegion()).thenReturn(itsRegion);
        when(itsDistrict.getDistrictSapDesc()).thenReturn("Sap");
    }

    @Test
    public void testCreateSingleRow_WhenNothingIsNullAndSaleTypeIs_MULTIPLIER_SEED_SALE(){
        //@Given
        CashAdvanceReportResponseDTO cashAdvanceReportResponseDTO = mock(CashAdvanceReportResponseDTO.class);

        CashAdvanceTransaction cashAdvanceTransaction = mock(CashAdvanceTransaction.class);
        when(cashAdvanceReportResponseDTO.getCashAdvanceTransaction()).thenReturn(cashAdvanceTransaction);
            OperationalYear operationalYear = mock(OperationalYear.class);
            when(cashAdvanceTransaction.getOperationalYear()).thenReturn(operationalYear);
            when(operationalYear.getYear()).thenReturn("Year");

        Harvest harvest = mock(Harvest.class);
        when(cashAdvanceReportResponseDTO.getHarvest()).thenReturn(harvest);
            when(harvest.getCrop()).thenReturn(new Crop());
            when(harvest.getCompany()).thenReturn(new Company());

        Customer customer = mock(Customer.class);
        when(cashAdvanceReportResponseDTO.getCustomer()).thenReturn(customer);

            Document document  = new Document();
                     document.setValue("Document");
            when(customer.getDocument()).thenReturn(document);
            when(customer.getDistrictByCompanyCropType(any(Company.class), any(Crop.class), any(String.class))).thenReturn(itsDistrict);

            Set<HeadOffice> headOfficeSet = new HashSet<HeadOffice>();
                HeadOffice headOffice = new HeadOffice();
                headOffice.setMatrix(customer);
                headOfficeSet.add(headOffice);
            when(customer.getHeadOffices()).thenReturn(headOfficeSet);

        Sale sale = mock(Sale.class);
        when(cashAdvanceReportResponseDTO.getSale()).thenReturn(sale);
        when(sale.getSaleType()).thenReturn(Sale.SaleTypeEnum.MULTIPLIER_SEED_SALE);
        when(sale.getCustomer()).thenReturn(customer);

        //@When
        Object[] result = assembler.createSingleRow(cashAdvanceReportResponseDTO);

        //@Should
        assertTrue(SIZE == result.length);
    }

    @Test
    public void testCreateSingleRow_WhenNothingIsNullAndSaleTypeIsNot_MULTIPLIER_SEED_SALE(){
        //@Given
        CashAdvanceReportResponseDTO cashAdvanceReportResponseDTO = mock(CashAdvanceReportResponseDTO.class);

        CashAdvanceTransaction cashAdvanceTransaction = mock(CashAdvanceTransaction.class);
        when(cashAdvanceReportResponseDTO.getCashAdvanceTransaction()).thenReturn(cashAdvanceTransaction);
        OperationalYear operationalYear = mock(OperationalYear.class);
        when(cashAdvanceTransaction.getOperationalYear()).thenReturn(operationalYear);
        when(operationalYear.getYear()).thenReturn("Year");

        Harvest harvest = mock(Harvest.class);
        when(cashAdvanceReportResponseDTO.getHarvest()).thenReturn(harvest);
        when(harvest.getCrop()).thenReturn(new Crop());
        when(harvest.getCompany()).thenReturn(new Company());

        Customer customer = mock(Customer.class);
        when(cashAdvanceReportResponseDTO.getCustomer()).thenReturn(customer);

        Document document  = new Document();
        document.setValue("Document");
        when(customer.getDocument()).thenReturn(document);
        when(customer.getDistrictByCompanyCropType(any(Company.class), any(Crop.class), any(String.class))).thenReturn(itsDistrict);

        Set<HeadOffice> headOfficeSet = new HashSet<HeadOffice>();
        HeadOffice headOffice = new HeadOffice();
        headOffice.setMatrix(customer);
        headOfficeSet.add(headOffice);
        when(customer.getHeadOffices()).thenReturn(headOfficeSet);

        Sale sale = mock(Sale.class);
        when(cashAdvanceReportResponseDTO.getSale()).thenReturn(sale);
        when(sale.getSaleType()).thenReturn(Sale.SaleTypeEnum.GRAIN_TRADE_SALE);
        when(sale.getCustomer()).thenReturn(customer);

        //@When
        Object[] result = assembler.createSingleRow(cashAdvanceReportResponseDTO);

        //@Should
        assertTrue(SIZE == result.length);
    }


    @Test
    public void testCreateSingleRow_WhenEverythingIsNull(){
        //@Given
        CashAdvanceReportResponseDTO cashAdvanceReportResponseDTO = mock(CashAdvanceReportResponseDTO.class);

        CashAdvanceTransaction cashAdvanceTransaction = mock(CashAdvanceTransaction.class);
        when(cashAdvanceReportResponseDTO.getCashAdvanceTransaction()).thenReturn(cashAdvanceTransaction);
        when(cashAdvanceTransaction.getOperationalYear()).thenReturn(null);

        Harvest harvest = mock(Harvest.class);
        when(cashAdvanceReportResponseDTO.getHarvest()).thenReturn(harvest);
        when(harvest.getCrop()).thenReturn(new Crop());
        when(harvest.getCompany()).thenReturn(new Company());

        Customer customer = mock(Customer.class);
        when(cashAdvanceReportResponseDTO.getCustomer()).thenReturn(customer);

        Document document  = new Document();
        document.setValue("Document");
        when(customer.getDocument()).thenReturn(document);
        when(customer.getDistrictByCompanyCropType(any(Company.class), any(Crop.class), any(String.class))).thenReturn(null);

        when(customer.getHeadOffices()).thenReturn(null);

        when(cashAdvanceReportResponseDTO.getSale()).thenReturn(null);

        //@When
        Object[] result = assembler.createSingleRow(cashAdvanceReportResponseDTO);

        //@Should
        assertTrue(SIZE == result.length);
    }

    @Test
    public void testGenerateHeader(){
        //@Given

        //@When
        Object[] result = assembler.generateHeader();

        //@Should
        assertTrue(SIZE == result.length);
    }

    class RB extends ResourceBundle{

        private Map<String, String> properties;

        public Map<String, String> getProperties() {
            return properties;
        }

        public void setProperties(Map<String, String> properties) {
            this.properties = properties;
        }

        @Override
        protected Object handleGetObject(String key) {
            return this.properties.get(key);
        }

        @Override
        public Enumeration<String> getKeys() {
            return new IteratorEnumeration(this.properties.keySet().iterator());
        }
    };

}