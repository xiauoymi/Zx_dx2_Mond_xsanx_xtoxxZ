package com.monsanto.brazilvaluecapture.seedsale.cashAdvance.model.dao.impl;

import com.google.common.collect.Lists;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Document;
import com.monsanto.brazilvaluecapture.core.base.model.bean.DocumentType;
import com.monsanto.brazilvaluecapture.core.base.model.bean.OperationalYear;
import com.monsanto.brazilvaluecapture.core.commercialhierarchy.model.bean.ItsDistrict;
import com.monsanto.brazilvaluecapture.core.commercialhierarchy.model.bean.ItsRegion;
import com.monsanto.brazilvaluecapture.core.commercialhierarchy.model.bean.ItsUnity;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Customer;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.HeadOffice;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.ParticipantTypeEnum;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Technology;
import com.monsanto.brazilvaluecapture.core.wsiconsole.dao.impl.BaseHibernateUnitTest;
import com.monsanto.brazilvaluecapture.seedsale.cashAdvance.model.bean.CashAdvanceBalanceByReferenceDate;
import com.monsanto.brazilvaluecapture.seedsale.cashAdvance.model.bean.CashAdvanceTransaction;
import com.monsanto.brazilvaluecapture.seedsale.cashAdvance.model.dto.CashAdvanceReportRequestDTO;
import com.monsanto.brazilvaluecapture.seedsale.cashAdvance.model.dto.CashAdvanceReportResponseDTO;
import com.monsanto.brazilvaluecapture.seedsale.harvest.model.bean.Harvest;
import com.monsanto.brazilvaluecapture.seedsale.template.model.bean.DueDatePrice;
import com.monsanto.brazilvaluecapture.seedsale.template.model.bean.DueDatePriceItem;
import com.monsanto.brazilvaluecapture.seedsale.template.model.bean.Price;
import com.monsanto.brazilvaluecapture.seedsale.template.model.bean.SaleTemplate;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;

import java.math.BigDecimal;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import static org.fest.assertions.Assertions.assertThat;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

public class CashAdvanceDAOImpl_UT extends BaseHibernateUnitTest {

    private CashAdvanceDAOImpl cashAdvanceDAO;

    @Before
    public void setUp(){
        cashAdvanceDAO = new CashAdvanceDAOImpl(sessionFactory);
    }


    @Test
    public void testSaveCashAdvance(){
        //@Given
        CashAdvanceTransaction cashAdvanceTransaction = new CashAdvanceTransaction();

        //@When
        CashAdvanceTransaction result = cashAdvanceDAO.saveCashAdvance(cashAdvanceTransaction);

        //@Should
        assertThat(cashAdvanceTransaction).isEqualTo(result);
    }


    @Test
    public void testFindCashAdvanceReportBalanceExecutesQuery_WhenFindingCashAdvanceReportBalance(){
        CashAdvanceReportRequestDTO cashAdvanceReportRequestDTO = new CashAdvanceReportRequestDTO();

        cashAdvanceDAO.findCashAdvanceReportBalance(cashAdvanceReportRequestDTO);

        verify(query).list();
    }

    @Test
    public void testFindCashAdvanceReportBalanceContainsHarvestWhere_WhenFindingCashAdvanceReportBalanceWithHarvest(){
        CashAdvanceReportRequestDTO cashAdvanceReportRequestDTO = new CashAdvanceReportRequestDTO();

        Harvest harvest = new Harvest();
        cashAdvanceReportRequestDTO.setHarvest(harvest);

        cashAdvanceDAO.findCashAdvanceReportBalance(cashAdvanceReportRequestDTO);

        ArgumentCaptor<String> queryStringArgumentCaptor = ArgumentCaptor.forClass(String.class);
        verify(session).createQuery(queryStringArgumentCaptor.capture());
        String queryString = queryStringArgumentCaptor.getValue();

        assertThat(queryString).contains("harvest=:" + CashAdvanceDAOImpl.HARVEST_PARAM);
        verify(query).setParameter(CashAdvanceDAOImpl.HARVEST_PARAM, (Object)harvest);
    }

    @Test
    public void testFindCashAdvanceReportBalanceContainsAllFiltersWhere_WhenFindingCashAdvanceReportBalanceWithAllFilters(){
        cashAdvanceDAO = new CashAdvanceDAOImpl(sessionFactory);
        CashAdvanceReportRequestDTO cashAdvanceReportRequestDTO = new CashAdvanceReportRequestDTO();

        Harvest harvest = new Harvest();
        Customer partner = new Customer();
        SaleTemplate saleTemplate = new SaleTemplate();
        Technology technology = new Technology();
        String referenceDate = "";
        Date paymentDate = new Date();
        ItsUnity unity = new ItsUnity();
        ItsRegion region = new ItsRegion();
        ItsDistrict district = new ItsDistrict();
        Customer headOffice = new Customer();

        cashAdvanceReportRequestDTO.setHarvest(harvest);
        cashAdvanceReportRequestDTO.setPartner(partner);
        cashAdvanceReportRequestDTO.setSaleTemplate(saleTemplate);
        cashAdvanceReportRequestDTO.setTechnology(technology);
        cashAdvanceReportRequestDTO.setReferenceDate(referenceDate);
        cashAdvanceReportRequestDTO.setPaymentDateStart(paymentDate);
        cashAdvanceReportRequestDTO.setPaymentDateEnd(paymentDate);
        cashAdvanceReportRequestDTO.setItsUnityPartner(unity);
        cashAdvanceReportRequestDTO.setItsRegionPartner(region);
        cashAdvanceReportRequestDTO.setItsDistrictPartner(district);
        cashAdvanceReportRequestDTO.setHeadOffice(headOffice);
        cashAdvanceReportRequestDTO.setItsUnityHeadOffice(unity);
        cashAdvanceReportRequestDTO.setItsRegionHeadOffice(region);
        cashAdvanceReportRequestDTO.setItsDistrictHeadOffice(district);

        cashAdvanceDAO.findCashAdvanceReportBalance(cashAdvanceReportRequestDTO);

        ArgumentCaptor<String> queryStringArgumentCaptor = ArgumentCaptor.forClass(String.class);
        verify(session).createQuery(queryStringArgumentCaptor.capture());
        String queryString = queryStringArgumentCaptor.getValue();

        assertThat(queryString).contains("harvest=:" +  CashAdvanceDAOImpl.HARVEST_PARAM);

        assertThat(queryString).contains(" and customer=:" + CashAdvanceDAOImpl.CUSTOMER_PARAM  );
        assertThat(queryString).contains(" and saleTemplate=:" + CashAdvanceDAOImpl.SALE_TEMPLATE_PARAM);
        assertThat(queryString).contains(" and technology=:" + CashAdvanceDAOImpl.TECHNOLOGY_PARAM);
        assertThat(queryString).contains(" and dueDatePriceItem.reference=:" + CashAdvanceDAOImpl.REFERENCE_DATE_PARAM);
        assertThat(queryString).contains(" and cashAdvance.paymentDate >= :" + CashAdvanceDAOImpl.PAYMENT_DATE_FROM_PARAM);
        assertThat(queryString).contains(" and cashAdvance.paymentDate <= :" + CashAdvanceDAOImpl.PAYMENT_DATE_END_PARAM );
        assertThat(queryString).contains(" and cusDistricts.itsDistrict.itsUnity=:" + CashAdvanceDAOImpl.UNIT_CUSTOMER_PARAM );
        assertThat(queryString).contains(" and cusDistricts.itsDistrict.itsRegion=:" + CashAdvanceDAOImpl.REGION_CUSTOMER_PARAM );
        assertThat(queryString).contains(" and cusDistricts.itsDistrict=:" + CashAdvanceDAOImpl.DISTRICT_CUSTOMER_PARAM );
        assertThat(queryString).contains(" and headOffices.matrix=:" + CashAdvanceDAOImpl.HEADOFFICE_PARAM );
        assertThat(queryString).contains(" and cusDistricts.itsDistrict.itsUnity=:" + CashAdvanceDAOImpl.UNIT_HEADOFFICE_PARAM );
        assertThat(queryString).contains(" and cusDistricts.itsDistrict.itsRegion=:" + CashAdvanceDAOImpl.REGION_HEADOFFICE_PARAM );
        assertThat(queryString).contains(" and cusDistricts.itsDistrict=:" + CashAdvanceDAOImpl.DISTRICT_HEADOFFICE_PARAM );

        verify(query).setParameter(CashAdvanceDAOImpl.HARVEST_PARAM, cashAdvanceReportRequestDTO.getHarvest());
        verify(query).setParameter(CashAdvanceDAOImpl.CUSTOMER_PARAM, cashAdvanceReportRequestDTO.getPartner());
        verify(query).setParameter(CashAdvanceDAOImpl.SALE_TEMPLATE_PARAM, cashAdvanceReportRequestDTO.getSaleTemplate());
        verify(query).setParameter(CashAdvanceDAOImpl.TECHNOLOGY_PARAM, cashAdvanceReportRequestDTO.getTechnology());
        verify(query).setParameter(CashAdvanceDAOImpl.REFERENCE_DATE_PARAM, cashAdvanceReportRequestDTO.getReferenceDate());
        verify(query).setParameter(CashAdvanceDAOImpl.PAYMENT_DATE_FROM_PARAM, cashAdvanceReportRequestDTO.getPaymentDateStart());
        verify(query).setParameter(CashAdvanceDAOImpl.PAYMENT_DATE_END_PARAM, cashAdvanceReportRequestDTO.getPaymentDateEnd());
        verify(query).setParameter(CashAdvanceDAOImpl.UNIT_CUSTOMER_PARAM, cashAdvanceReportRequestDTO.getItsUnityPartner());
        verify(query).setParameter(CashAdvanceDAOImpl.REGION_CUSTOMER_PARAM, cashAdvanceReportRequestDTO.getItsRegionPartner());
        verify(query).setParameter(CashAdvanceDAOImpl.DISTRICT_CUSTOMER_PARAM , cashAdvanceReportRequestDTO.getItsDistrictPartner());
        verify(query).setParameter(CashAdvanceDAOImpl.HEADOFFICE_PARAM, cashAdvanceReportRequestDTO.getHeadOffice());
        verify(query).setParameter(CashAdvanceDAOImpl.UNIT_HEADOFFICE_PARAM, cashAdvanceReportRequestDTO.getItsUnityHeadOffice());
        verify(query).setParameter(CashAdvanceDAOImpl.REGION_HEADOFFICE_PARAM, cashAdvanceReportRequestDTO.getItsRegionHeadOffice());
        verify(query).setParameter(CashAdvanceDAOImpl.DISTRICT_HEADOFFICE_PARAM , cashAdvanceReportRequestDTO.getItsDistrictHeadOffice());
    }

    @Test
    public void testFindCashAdvanceReportTransactionExecutesQuery_WhenFindingCashAdvanceReportTransaction(){
        CashAdvanceReportRequestDTO cashAdvanceReportRequestDTO = new CashAdvanceReportRequestDTO();

        cashAdvanceDAO.findCashAdvanceReportTransaction(cashAdvanceReportRequestDTO);

        verify(query).list();
    }

    @Test
    public void testFindCashAdvanceReportTransactionReturnsQueryResult_WhenFindingCashAdvanceReportTransaction(){

        CashAdvanceReportRequestDTO cashAdvanceReportRequestDTO = new CashAdvanceReportRequestDTO();
        CashAdvanceReportResponseDTO expectedCashAdvanceReportResponseDTO = new CashAdvanceReportResponseDTO();

        List<CashAdvanceReportResponseDTO> reportResponseList = Lists.newArrayList(expectedCashAdvanceReportResponseDTO);

        when(query.list()).thenReturn(reportResponseList);

        List<CashAdvanceReportResponseDTO> cashAdvanceReportTransaction = cashAdvanceDAO.findCashAdvanceReportTransaction(cashAdvanceReportRequestDTO);

        assertThat(cashAdvanceReportTransaction).contains(expectedCashAdvanceReportResponseDTO);
    }

    @Test
    public void testFindCashAdvanceReportConsumptionExecutesQuery_WhenFindingCashAdvanceReportConsumption(){
        CashAdvanceReportRequestDTO cashAdvanceReportRequestDTO = new CashAdvanceReportRequestDTO();

        cashAdvanceDAO.findCashAdvanceReportConsumption(cashAdvanceReportRequestDTO);

        verify(query).list();
    }

    @Test
    public void testFindCashAdvanceReportConsumptionReturnsQueryResult_WhenFindingCashAdvanceReportConsumption(){

        CashAdvanceReportRequestDTO cashAdvanceReportRequestDTO = new CashAdvanceReportRequestDTO();
        CashAdvanceReportResponseDTO expectedCashAdvanceReportResponseDTO = new CashAdvanceReportResponseDTO();

        List<CashAdvanceReportResponseDTO> reportResponseList = Lists.newArrayList(expectedCashAdvanceReportResponseDTO);

        when(query.list()).thenReturn(reportResponseList);

        List<CashAdvanceReportResponseDTO> cashAdvanceReportConsumption = cashAdvanceDAO.findCashAdvanceReportConsumption(cashAdvanceReportRequestDTO);

        assertThat(cashAdvanceReportConsumption).contains(expectedCashAdvanceReportResponseDTO);
    }

    @Test
    public void testFindCashAdvanceReportBalanceReturnsQueryResult_WhenFindingCashAdvanceReportBalance(){
        CashAdvanceReportRequestDTO cashAdvanceReportRequestDTO = new CashAdvanceReportRequestDTO();
        CashAdvanceReportResponseDTO expectedCashAdvanceReportResponseDTO = new CashAdvanceReportResponseDTO();
        Customer partner = new Customer ();
        Document document = new Document();
        DocumentType documentType = new DocumentType();
        documentType.setDescription("");
        document.setDocumentType(documentType);
        partner.setDocument(document);

        Customer matrix = new Customer ();
        HeadOffice headOffice = new HeadOffice();
        headOffice.setMatrix(matrix);
        expectedCashAdvanceReportResponseDTO.setHeadOffice(headOffice);

        CashAdvanceTransaction cat = new CashAdvanceTransaction();
        expectedCashAdvanceReportResponseDTO.setCashAdvanceTransaction(cat);
        List<CashAdvanceReportResponseDTO> reportResponseList = Lists.newArrayList(expectedCashAdvanceReportResponseDTO);
        expectedCashAdvanceReportResponseDTO.setCustomer(partner);
        when(query.list()).thenReturn(reportResponseList);


        List<CashAdvanceReportResponseDTO> cashAdvanceReportBalance = cashAdvanceDAO.findCashAdvanceReportBalance(cashAdvanceReportRequestDTO);

        assertThat(cashAdvanceReportBalance).contains(expectedCashAdvanceReportResponseDTO);
    }

    @Test
    public void testFindCashAdvanceReportBalanceQueriesForHarvest_WhenReportFilterHasAHarvest() {
        CashAdvanceReportRequestDTO cashAdvanceReportRequestDTO = new CashAdvanceReportRequestDTO();

        cashAdvanceDAO.findCashAdvanceReportBalance(cashAdvanceReportRequestDTO);

        ArgumentCaptor<String> queryStringArgumentCaptor = ArgumentCaptor.forClass(String.class);
        verify(session).createQuery(queryStringArgumentCaptor.capture());
        String queryString = queryStringArgumentCaptor.getValue();

        StringBuilder q = buildBalanceQuery(cashAdvanceReportRequestDTO);

        assertThat(queryString).isEqualTo(q.toString());
    }

    @Test
    public void testFindCashAdvanceReportTransactionQueriesForHarvest_WhenReportFilterHasAHarvest() {
        CashAdvanceReportRequestDTO cashAdvanceReportRequestDTO = new CashAdvanceReportRequestDTO();

        cashAdvanceDAO.findCashAdvanceReportTransaction(cashAdvanceReportRequestDTO);

        ArgumentCaptor<String> queryStringArgumentCaptor = ArgumentCaptor.forClass(String.class);
        verify(session).createQuery(queryStringArgumentCaptor.capture());
        String queryString = queryStringArgumentCaptor.getValue();

        StringBuilder q = buildTransactionQuery(cashAdvanceReportRequestDTO);

        assertThat(queryString).isEqualTo(q.toString());
    }

    private StringBuilder buildTransactionQuery(CashAdvanceReportRequestDTO cashAdvanceReportRequestDTO) {

        StringBuilder q = new StringBuilder();

        q.append(" select new com.monsanto.brazilvaluecapture.seedsale.cashAdvance.model.dto.CashAdvanceReportResponseDTO( ");
        q.append("  cashAdvance, ");
        q.append("  harvest,");
        q.append("  cashAdvance.partner,");
        q.append("  headOffices,");
        q.append("  saleTemplate.description,");
        q.append("  technology.description)");

        q.append(" from CashAdvanceTransaction as cashAdvance, SaleTemplate as saleTemplate, Technology as technology, Harvest as harvest ");
        q.append(" join cashAdvance.partner as customer ");
        q.append(" join technology.prices as pricesTechnology ");
        q.append(" join saleTemplate.prices as pricesTemplate ");
        q.append(" join pricesTemplate.dueDatePrice.dueDatePriceItems as dueDatePriceItem ");
        q.append(" join cashAdvance.partner.headOffices as headOffices ");

        q.append(" where ");

        q.append("  harvest.company = technology.company and");
        q.append("  saleTemplate.harvest = harvest and ");
        q.append("  harvest.operationalYear = cashAdvance.operationalYear and ");
        q.append("  pricesTechnology.id = pricesTemplate.id and ");
        q.append("  dueDatePriceItem.id = cashAdvance.referenceDate and ");
        q.append("  headOffices.type = '" + ParticipantTypeEnum.MULTIPLICADOR + "' and ");

        q.append("  harvest=:harvestParam");

        return q;
    }

    private StringBuilder buildBalanceQuery(CashAdvanceReportRequestDTO cashAdvanceReportRequestDTO) {
        StringBuilder q = new StringBuilder();

        q.append(" select new com.monsanto.brazilvaluecapture.seedsale.cashAdvance.model.dto.CashAdvanceReportResponseDTO( ");
        q.append(" cashAdvance.operationalYear.year, ");
        q.append("  harvest,");
        q.append("  cashAdvance.partner,");
        q.append("  headOffices,");
        q.append("  saleTemplate,");
        q.append("  technology.description,");
        q.append("  sum(cashAdvance.amount))");

        q.append(" from CashAdvanceTransaction as cashAdvance, SaleTemplate as saleTemplate, Technology as technology, Harvest as harvest ");
        q.append(" join cashAdvance.partner as customer ");
        q.append(" join technology.prices as pricesTechnology ");
        q.append(" join saleTemplate.prices as pricesTemplate ");
        q.append(" join pricesTemplate.dueDatePrice.dueDatePriceItems as dueDatePriceItem ");
        q.append(" join cashAdvance.partner.headOffices as headOffices ");

        q.append(" where ");

        q.append("  harvest.company = technology.company and");
        q.append("  saleTemplate.harvest = harvest and ");
        q.append("  harvest.operationalYear = cashAdvance.operationalYear and ");
        q.append("  pricesTechnology.id = pricesTemplate.id and ");
        q.append("  dueDatePriceItem.id = cashAdvance.referenceDate and ");
        q.append("  headOffices.type = '" + ParticipantTypeEnum.MULTIPLICADOR + "' and ");
        q.append("  harvest=:harvestParam");

        q.append(" group by ");
        q.append(" cashAdvance.operationalYear.year, ");
        q.append("  harvest,");
        q.append("  cashAdvance.partner,");
        q.append("  headOffices,");
        q.append("  saleTemplate,");
        q.append("  technology.description");

        return q;
    }

    @Test
    public void testGetBalanceByReferenceDateCreatesQueryFromSession_WhenQueryingBalanceByReferenceDate() {
        Price price = new Price();

        cashAdvanceDAO.getBalanceByReferenceDate(price);

        verify(session).createQuery(anyString());
    }

    @Test
    public void testGetBalanceByReferenceDateListsCreatedQuery_WhenQueryingBalanceByReferenceDate() {
        Price price = new Price();

        cashAdvanceDAO.getBalanceByReferenceDate(price);

        verify(query).list();
    }

    @Test
    public void testGetBalanceByReferenceDateReturnsQueryList_WhenQueryingBalanceByReferenceDate() {
        CashAdvanceBalanceByReferenceDate cashAdvanceBalanceByReferenceDate = new CashAdvanceBalanceByReferenceDate(null, null);
        List<CashAdvanceBalanceByReferenceDate> balanceList = Lists.newArrayList(cashAdvanceBalanceByReferenceDate);
        when(query.list()).thenReturn(balanceList);
        Price price = new Price();

        final List<CashAdvanceBalanceByReferenceDate> balanceByReferenceDate = cashAdvanceDAO.getBalanceByReferenceDate(price);

        assertThat(balanceByReferenceDate).contains(cashAdvanceBalanceByReferenceDate);
    }

    @Test
    public void testFindCashAdvanceReportConsumption(){
        //@Given

        //@When
        CashAdvanceReportRequestDTO cashAdvanceReportRequestDTO = new CashAdvanceReportRequestDTO();
        cashAdvanceDAO.findCashAdvanceReportConsumption(cashAdvanceReportRequestDTO);
        ArgumentCaptor<String> queryStringArgumentCaptor = ArgumentCaptor.forClass(String.class);
        verify(session).createQuery(queryStringArgumentCaptor.capture());
        String queryString = queryStringArgumentCaptor.getValue();

        StringBuilder q = buildConsumptionQuery(cashAdvanceReportRequestDTO);

        assertThat(queryString).isEqualTo(q.toString());

        //@Should
        assertThat(queryString).isEqualTo(q.toString());
    }

    private StringBuilder buildConsumptionQuery(CashAdvanceReportRequestDTO cashAdvanceReportRequestDTO) {

        StringBuilder q = new StringBuilder();

        q.append(" select new com.monsanto.brazilvaluecapture.seedsale.cashAdvance.model.dto.CashAdvanceReportResponseDTO( ");
        q.append(" cashAdvance, ");
        q.append(" harvest,");
        q.append(" cashAdvance.partner,");
        q.append(" headOffices,");
        q.append(" saleTemplate.description,");
        q.append(" technology.description, ");
        q.append(" saleItem )");

        q.append(" from CashAdvanceTransaction as cashAdvance, SaleTemplate as saleTemplate, Technology as technology, Harvest as harvest, SaleItem as saleItem");
        q.append(" join cashAdvance.partner as customer ");
        q.append(" join technology.prices as pricesTechnology ");
        q.append(" join saleTemplate.prices as pricesTemplate ");
        q.append(" join pricesTemplate.dueDatePrice.dueDatePriceItems as dueDatePriceItem ");
        q.append(" join cashAdvance.saleFrom.items as saleItemCashAdvance ");
        q.append(" join cashAdvance.partner.headOffices as headOffices ");

        q.append(" where ");

        q.append("  saleItemCashAdvance.id = saleItem.id and");
        q.append("  harvest.company = technology.company and");
        q.append("  saleTemplate.harvest = harvest and ");
        q.append("  harvest.operationalYear = cashAdvance.operationalYear and ");
        q.append("  pricesTechnology.id = pricesTemplate.id and ");
        q.append("  dueDatePriceItem.id = cashAdvance.referenceDate and ");
        q.append("  headOffices.type = '" + ParticipantTypeEnum.MULTIPLICADOR + "' and ");

        q.append("  harvest=:harvestParam");

        return q;
    }

    @Test
    public void testGetAllAvailableBalancesForPrice(){
        //@Given
        Price price = new Price();
        price.setId(1L);
        Customer customer = mock(Customer.class);
        Document document = mock(Document.class);
        when(customer.getDocument()).thenReturn(document);
        when(document.getDocumentTypeDescription()).thenReturn("CNPJ");

        OperationalYear operationalYear = new OperationalYear();

        //@When
        cashAdvanceDAO.getAllAvailableBalancesForPrice(price, customer, customer, operationalYear);

        //@Should
        verify(query).setParameter("priceId", price.getId());
        verify(query).setParameter("operationalYear", operationalYear);
        verify(query).list();
    }

    @Test
    public void testGetAvailableBalanceForReferenceDate(){
        //@Given
        DueDatePriceItem dueDatePriceItem = new DueDatePriceItem();
        Customer customer = mock(Customer.class);
        Document document = mock(Document.class);
        when(customer.getDocument()).thenReturn(document);
        when(document.getDocumentTypeDescription()).thenReturn("CPF");

        OperationalYear operationalYear = new OperationalYear();

        //@When
        cashAdvanceDAO.getAvailableBalanceForReferenceDate(dueDatePriceItem, customer, customer, operationalYear);

        //@Should
        query.setParameter("dueDatePriceItemId", dueDatePriceItem.getId());
        query.setParameter("operationalYear", operationalYear);
        verify(query).uniqueResult();
    }

    @Test
    public void testFindCashAdvanceBalanceForCustomer(){
        //@Given
        SaleTemplate saleTemplateEntity = mock(SaleTemplate.class);
        Price price = mock(Price.class);
        Customer customer = mock(Customer.class);
        Document document = mock(Document.class);
        HeadOffice headOffice = mock(HeadOffice.class);
        when(customer.getDocument()).thenReturn(document);
        when(document.getDocumentTypeDescription()).thenReturn("CPF");


        CashAdvanceReportRequestDTO cashAdvanceReportRequestDTO = new CashAdvanceReportRequestDTO();

        CashAdvanceReportResponseDTO cashAdvanceReportResponseDTO = new CashAdvanceReportResponseDTO();
            cashAdvanceReportResponseDTO.setSaleTemplateEntity(saleTemplateEntity);
            cashAdvanceReportResponseDTO.setCustomer(customer);
            cashAdvanceReportResponseDTO.setHeadOffice(headOffice);

            Set<Price> prices = new HashSet<Price>();

        when(saleTemplateEntity.getPrices()).thenReturn(prices);
        when(headOffice.getMatrix()).thenReturn(customer);
        when(price.getDueDatePrice()).thenReturn(new DueDatePrice());

        //@When
        cashAdvanceDAO.findCashAdvanceBalanceForCustomer(cashAdvanceReportRequestDTO, cashAdvanceReportResponseDTO);

        //@Should
        verify(query).uniqueResult();
    }

}
