package com.monsanto.brazilvaluecapture.seedsale.sale.validation;

import com.google.common.collect.Sets;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Customer;
import com.monsanto.brazilvaluecapture.core.foundation.validation.ValidationException;
import com.monsanto.brazilvaluecapture.seedsale.harvest.model.bean.Plantability;
import com.monsanto.brazilvaluecapture.seedsale.product.model.bean.Product;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.Sale;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.SaleItem;
import org.junit.Assert;
import org.junit.Test;

import static org.fest.assertions.Fail.fail;

public class SaleItemProductDuplicityValidationRule_UT {

    @Test
    public void when_sale_item_has_same_product_plantability_lot_multiplier_dealer_then_fails() {

        //@Given
        SaleItemProductDuplicityValidationRule saleItemProductDuplicityValidationRule = new SaleItemProductDuplicityValidationRule();
        Sale sale = new Sale();
        SaleItem saleItem1 = new SaleItem();
        SaleItem saleItem2 = new SaleItem();

        Product product = new Product();
        saleItem1.setProduct(product);
        saleItem2.setProduct(product);

        String lot = "";
        saleItem1.setLot(lot);
        saleItem2.setLot(lot);

        Plantability plantability = new Plantability();
        saleItem1.setPlantabilityId(plantability);
        saleItem2.setPlantabilityId(plantability);

        Customer multiplier = new Customer();
        saleItem1.setMultiplier(multiplier);
        saleItem2.setMultiplier(multiplier);

        Customer dealer = new Customer();
        saleItem1.setCustomerParent(dealer);
        saleItem2.setCustomerParent(dealer);

        sale.setItems(Sets.newHashSet(saleItem1, saleItem2));

        //@When
        try {
            saleItemProductDuplicityValidationRule.validate(sale);
            fail("Should throw ValidationException");
        } catch (ValidationException e) {
            //@Should
            SaleValidationException ex = (SaleValidationException) e;
            Assert.assertFalse(ex.getSaleViolation().isEmpty());
        }
    }

    @Test
    public void when_sale_item_has_same_product_plantability_multiplier_dealer_but_different_lot_then_ok() throws ValidationException {

        //@Given
        SaleItemProductDuplicityValidationRule saleItemProductDuplicityValidationRule = new SaleItemProductDuplicityValidationRule();
        Sale sale = new Sale();
        SaleItem saleItem1 = new SaleItem();
        SaleItem saleItem2 = new SaleItem();

        Product product = new Product();
        saleItem1.setProduct(product);
        saleItem2.setProduct(product);

        String lot1 = "XX";
        String lot2 = "YY";
        saleItem1.setLot(lot1);
        saleItem2.setLot(lot2);

        Plantability plantability = new Plantability();
        saleItem1.setPlantabilityId(plantability);
        saleItem2.setPlantabilityId(plantability);

        Customer multiplier = new Customer();
        saleItem1.setMultiplier(multiplier);
        saleItem2.setMultiplier(multiplier);

        Customer dealer = new Customer();
        saleItem1.setCustomerParent(dealer);
        saleItem2.setCustomerParent(dealer);

        sale.setItems(Sets.newHashSet(saleItem1, saleItem2));

        //@When
        try {
            saleItemProductDuplicityValidationRule.validate(sale);
        } catch (ValidationException e) {
            fail("Should not throw exception");
        }
    }

}
