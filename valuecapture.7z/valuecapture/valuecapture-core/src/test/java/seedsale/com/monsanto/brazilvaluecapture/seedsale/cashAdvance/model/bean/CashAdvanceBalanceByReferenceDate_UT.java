package com.monsanto.brazilvaluecapture.seedsale.cashAdvance.model.bean;

import com.monsanto.brazilvaluecapture.seedsale.template.model.bean.DueDatePriceItem;
import org.junit.Test;

import java.math.BigDecimal;

import static org.fest.assertions.Assertions.assertThat;

public class CashAdvanceBalanceByReferenceDate_UT {
    @Test
    public void testCashAdvanceBalanceByReferenceDateInitializesDueDatePriceItem_WhenConstructingNewInstances() {
        DueDatePriceItem dueDatePriceItem = new DueDatePriceItem();

        CashAdvanceBalanceByReferenceDate cashAdvanceBalanceByReferenceDate = new CashAdvanceBalanceByReferenceDate(dueDatePriceItem, null);

        assertThat(cashAdvanceBalanceByReferenceDate.getDueDatePriceItem()).isSameAs(dueDatePriceItem);
    }

    @Test
    public void testCashAdvanceBalanceByReferenceDateInitializesBalance_WhenConstructingNewInstances() {
        DueDatePriceItem dueDatePriceItem = new DueDatePriceItem();
        BigDecimal balance = BigDecimal.TEN;

        CashAdvanceBalanceByReferenceDate cashAdvanceBalanceByReferenceDate = new CashAdvanceBalanceByReferenceDate(dueDatePriceItem, balance);

        assertThat(cashAdvanceBalanceByReferenceDate.getBalance()).isSameAs(balance);
    }
}
