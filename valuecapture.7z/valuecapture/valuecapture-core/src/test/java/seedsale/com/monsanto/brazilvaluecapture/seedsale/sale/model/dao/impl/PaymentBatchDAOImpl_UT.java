package com.monsanto.brazilvaluecapture.seedsale.sale.model.dao.impl;

import com.google.common.collect.Lists;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Customer;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.PaymentBatch;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.Sale;
import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.hibernate.classic.Session;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InOrder;

import java.util.ArrayList;
import java.util.List;

import static org.fest.assertions.Assertions.assertThat;
import static org.mockito.Mockito.*;

/**
 * Created by IntelliJ IDEA.
 * User: PPERA
 * Date: 3/13/13
 * Time: 10:04 AM
 */
public class PaymentBatchDAOImpl_UT {
    private PaymentBatchDAOImpl paymentBatchDao;
    private Query query;
    private Session session;

    @Before
    public void setUp() {
        SessionFactory sessionFactory = mock(SessionFactory.class);
        this.session = mock(Session.class);
        when(sessionFactory.getCurrentSession()).thenReturn(this.session);
        this.paymentBatchDao = new PaymentBatchDAOImpl(sessionFactory);
        this.query = mock(Query.class);
        when(this.session.createQuery(anyString())).thenReturn(this.query);
    }

    @Test
    public void testListPaymentBatchesByRetailerCreatesAQueryToFindBatchesByRetailerAndExecutesIt_WhenListingBatchesByRetailer() {
        // @Given a retailer
        Customer retailer = new Customer();

        // @When listing the retailers payment batches
        this.paymentBatchDao.listPaymentBatchesByRetailer(retailer);

        // @Then a query is creates, the retailer is set as a parameter and the query is executed
        verify(this.session, times(1)).createQuery(PaymentBatchDAOImpl.LIST_BY_RETAILER);
        verify(this.query, times(1)).setParameter("retailer", retailer);
        verify(this.query, times(1)).list();
    }

    @Test
    public void testListPaymentBatchesByRetailerReturnsQueryResult_WhenListingBatchesByRetailer() {
        // @Given a retailer
        Customer retailer = new Customer();
        when(this.query.list()).thenReturn(new ArrayList<PaymentBatch>());

        // @When listing the retailes payment batches
        List<PaymentBatch> paymentBatches = this.paymentBatchDao.listPaymentBatchesByRetailer(retailer);

        // @Then the result of the query is returned
        assertThat(paymentBatches).isSameAs(this.query.list());
    }

    @Test
    public void testSaveCallsSaveOrUpdateForInput_WhenSavingInputPaymentBatch() {
        // @Given a payment batch
        PaymentBatch paymentBatch = new PaymentBatch();
        paymentBatch.setSales(new ArrayList<Sale>());

        // @When saving the payment batch
        this.paymentBatchDao.save(paymentBatch);

        // @Then session.saveOrUpdate is called for that payment batch
        verify(this.session, times(1)).saveOrUpdate(paymentBatch);
    }

    @Test
    public void testSaveSetsInputPaymentBatchSalesItsPaymentBatchAttributeWithTheInputAndThenTheyAreSaved_WhenSavingInputPaymentBatch() {
        // @Given a payment batch
        PaymentBatch paymentBatch = new PaymentBatch();
        Sale sale1 = mock(Sale.class);
        Sale sale2 = mock(Sale.class);
        paymentBatch.setSales(Lists.<Sale>newArrayList(sale1, sale2));

        // @When saving the payment batch
        this.paymentBatchDao.save(paymentBatch);

        // @Then all the sales are set their paymentBatch to the input payment batch
        InOrder inOrder = inOrder(sale1, this.session);
        inOrder.verify(sale1, times(1)).setPaymentBatch(paymentBatch);
        inOrder.verify(this.session, times(1)).saveOrUpdate(sale1);

        InOrder inOrder2 = inOrder(sale2, this.session);
        inOrder2.verify(sale2, times(1)).setPaymentBatch(paymentBatch);
        inOrder2.verify(this.session, times(1)).saveOrUpdate(sale2);
    }

    @Test
    public void testSaveReturnsSavedBatch_WhenSavingPaymentBatch() {
        // @Given a payment batch
        PaymentBatch paymentBatch = new PaymentBatch();
        paymentBatch.setSales(new ArrayList<Sale>());

        // @When saving the payment batch
        PaymentBatch batch = this.paymentBatchDao.save(paymentBatch);

        // @Then the batch is returned
        assertThat(batch).isSameAs(paymentBatch);

    }

    @Test
    public void testRemoveUnassignsThePaymentBatchOfItSales_WhenRemovingThePaymentBatch(){
        // @Given a paymentBatch to remove that has sales
        PaymentBatch paymentBatch = new PaymentBatch();
        Sale sale1 = mock(Sale.class);
        Sale sale2 = mock(Sale.class);
        paymentBatch.setSales(Lists.<Sale>newArrayList(sale1, sale2));

        // @When removing the paymentBatch
        this.paymentBatchDao.remove(paymentBatch);

        // @Then the sale's payment batch is set to null and then saved
        InOrder inOrder = inOrder(sale1, this.session);
        inOrder.verify(sale1, times(1)).setPaymentBatch(null);
        inOrder.verify(this.session, times(1)).saveOrUpdate(sale1);

        InOrder inOrder2 = inOrder(sale2, this.session);
        inOrder2.verify(sale2, times(1)).setPaymentBatch(null);
        inOrder2.verify(this.session, times(1)).saveOrUpdate(sale2);
    }

    @Test
    public void testRemoveDeletesThePaymentBatch_WhenRemovingThePaymentBatch(){
        // @Given a paymentBatch
        PaymentBatch paymentBatch = new PaymentBatch();
        paymentBatch.setSales(new ArrayList<Sale>());

        // @When removing the payment batch
        this.paymentBatchDao.remove(paymentBatch);

        // @Then session.delete(paymentBatch) is called
        verify(this.session, times(1)).delete(paymentBatch);
    }
}
