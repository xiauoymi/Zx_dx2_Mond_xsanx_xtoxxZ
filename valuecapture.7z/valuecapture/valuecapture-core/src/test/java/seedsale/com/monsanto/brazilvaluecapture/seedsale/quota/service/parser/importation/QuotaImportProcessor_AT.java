package com.monsanto.brazilvaluecapture.seedsale.quota.service.parser.importation;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.monsanto.brazilvaluecapture.core.base.SystemTestFixture;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Address;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Document;
import com.monsanto.brazilvaluecapture.core.base.model.bean.OperationalYear;
import com.monsanto.brazilvaluecapture.core.base.service.OperationalYearService;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Customer;
import com.monsanto.brazilvaluecapture.core.foundation.service.BusinessException;
import com.monsanto.brazilvaluecapture.core.foundation.test.AbstractServiceIntegrationTests;
import com.monsanto.brazilvaluecapture.core.io.ProcessorConfig;
import com.monsanto.brazilvaluecapture.core.io.ProcessorConfig.ProcessorConfigProperties;
import com.monsanto.brazilvaluecapture.core.io.WarningImportedException;
import com.monsanto.brazilvaluecapture.core.user.AccessControlTestFixture;
import com.monsanto.brazilvaluecapture.core.user.model.bean.UserDecorator;
import com.monsanto.brazilvaluecapture.seedsale.product.model.bean.Product;
import com.monsanto.brazilvaluecapture.seedsale.quota.model.bean.Quota;
import com.monsanto.brazilvaluecapture.seedsale.quota.model.bean.QuotaImportedLine;
import com.monsanto.brazilvaluecapture.seedsale.quota.model.bean.QuotaImportedLine.QuotaImportedLineType;
import com.monsanto.brazilvaluecapture.seedsale.quota.model.bean.QuotaTransaction.QuotaTransactionType;
import com.monsanto.brazilvaluecapture.seedsale.quota.model.bean.QuotaType;
import com.monsanto.brazilvaluecapture.seedsale.quota.service.QuotaControlService;
import com.monsanto.brazilvaluecapture.seedsale.quota.service.QuotaService;
import com.monsanto.brazilvaluecapture.seedsale.sale.SaleTestFixture;

public class QuotaImportProcessor_AT extends AbstractServiceIntegrationTests {
	private Locale localeBR = new Locale("pt", "BR");		@Autowired	private QuotaImportProcessor quotaImportProcessor;		@Autowired	private QuotaImportParser importParser;	    @Autowired    private QuotaService quotaService;	    @Autowired    OperationalYearService operationalYearService;    	private QuotaImportedFile quotaImportedFile;	
	private ProcessorConfig processorConfig = new ProcessorConfig();
	

    @Autowired
	@Qualifier("currentQuotaControlImplementation")
    private QuotaControlService quotaControlService;
		@Before	public void init() {		systemTestFixture = new SystemTestFixture(this);		saleTestFixture = new SaleTestFixture(this, systemTestFixture);		accessControlTestFixture = new AccessControlTestFixture(systemTestFixture);		quotaImportedFile = new QuotaImportedFile();		accessControlTestFixture.superUser.setContextCompany(systemTestFixture.monsantoBr);		accessControlTestFixture.superUser.setContextCrop(systemTestFixture.soy);
		
		processorConfig = createProcessorConfigWithSuperUserAndMonsantoEuaAsSelectedCompany();
	}		@Test	public void given_a_importedLine_with_inexistent_customer_should_throw_exception() throws WarningImportedException {		QuotaImportedLine line = createValidQuotaImportedLine();		line.setCustomerDocument("123412132");		line.setCustomerDocumentTypeDescription("cnpj");				prepareQuotaImportedFile(line);		importParser.proccessFile(quotaImportedFile);				Assert.assertEquals("Should have one violation", 1, quotaImportedFile.countWarnings());	}	private void prepareQuotaImportedFile(QuotaImportedLine line) {		ArrayList<QuotaImportedLine> allEntities = new ArrayList<QuotaImportedLine>();		allEntities.add(line);		quotaImportedFile.setAllEntities(allEntities);	}		@Test	public void given_a_importedLine_with_inexistentProduct_should_have_one_warning() throws WarningImportedException {		QuotaImportedLine line = createValidQuotaImportedLine();		line.setProductCode(213123L);		prepareQuotaImportedFile(line);		importParser.proccessFile(quotaImportedFile);				Assert.assertEquals("Should have one violation", 1, quotaImportedFile.countWarnings());	}		@Test	public void given_a_importedLine_with_inexistentOperationalYear_should_have_one_warning() throws WarningImportedException {		QuotaImportedLine line = createValidQuotaImportedLine();		line.setOperationalYearDescription("blabla");		prepareQuotaImportedFile(line);		importParser.proccessFile(quotaImportedFile);				Assert.assertEquals("Should have one violation", 1, quotaImportedFile.countWarnings());	}		@Test	public void given_a_existentProduct_without_quotaUsage_should_have_one_warning() throws WarningImportedException {		QuotaImportedLine line = createValidQuotaImportedLine();		line.setProductCode(saleTestFixture.productIntactaSoyMons4nto.getId());		prepareQuotaImportedFile(line);		importParser.proccessFile(quotaImportedFile);				Assert.assertEquals("Should have one violation", 1, quotaImportedFile.countWarnings());	}		@Test	public void given_a_headOffice_notAllowed_for_loggedUser_have_one_warning() throws WarningImportedException {		QuotaImportedLine line = createValidQuotaImportedLine();		line.setEntityUser(accessControlTestFixture.userAdminOfMonsantoEua);		prepareQuotaImportedFile(line);		importParser.proccessFile(quotaImportedFile);				Assert.assertEquals("Should have one violation", 1, quotaImportedFile.countWarnings());	}		@Test	public void given_a_debit_when_a_quota_doesntHaveEnoughBalance_then_should_have_one_warning() {		createAndSaveQuotaWithBalanceTen();		QuotaImportedLine line = createValidQuotaImportedLine();		line.setEntityUser(accessControlTestFixture.superUser);		line.setAmount(BigDecimal.valueOf(11L));		line.setLineTransactionTypeCode(QuotaImportedLine.DEBIT);		prepareQuotaImportedFile(line);		importParser.proccessFile(quotaImportedFile);				Assert.assertEquals("Should have one violation", 1, quotaImportedFile.countWarnings());	}
	
	private void createAndSaveQuotaWithBalanceTen() {		quotaControlService.saveDeposit(saleTestFixture.customer, saleTestFixture.productIntactaWithQuota, systemTestFixture.operationalYearOf2012, QuotaType.AVAILABLE, BigDecimal.TEN, QuotaTransactionType.SAP, null, "1234", "vrodrigues", null, null, null);
	}		public QuotaImportedLine createValidQuotaImportedLine() {
	    return createQuotaImportedLine(saleTestFixture.customer, BigDecimal.ONE, saleTestFixture.productIntactaWithQuota,systemTestFixture.operationalYearOf2012,1,QuotaImportedLineType.SAP,"12345");	}	    private QuotaImportedLine createQuotaImportedLine(Customer customer, BigDecimal amount, Product product, OperationalYear operationalYear, Integer lineNumber, QuotaImportedLineType lineType, String invoice) {        QuotaImportedLine line = new QuotaImportedLine(customer, amount, product);        line.setOperationalYear(operationalYear);        line.setLine(lineNumber);        line.setLineType(lineType);        line.setInvoiceNumber(invoice);
        line.setCustomerDocument(customer.getDocumentValue());
        line.setCustomerDocumentTypeDescription(customer.getDocument().getDocumentTypeDescription());
        line.setCustomerStateRegistration(customer.getStateRegistration());
        line.setDistributorSapCode(customer.getCustomerSAPCode());
        line.setLineTransactionTypeCode(QuotaImportedLine.CREDIT);
        line.setOperationalYearDescription(operationalYear.getYear());
        line.setProductCode(product.getId());
        line.setEntityUser(accessControlTestFixture.superUser);
        return line;    }        @Test    public void given_multiple_imported_quota_lines_when_I_process_then_should_write_all_3_successfully() {        QuotaImportedFile file = new QuotaImportedFile();        QuotaImportedLine line = createQuotaImportedLine(saleTestFixture.customer, BigDecimal.valueOf(1000L), saleTestFixture.productIntactaWithQuota, systemTestFixture.operationalYearOf2012, 1, QuotaImportedLineType.SAP, "12345");         file.add(line);
        line = createQuotaImportedLine(saleTestFixture.customer, BigDecimal.valueOf(1000L), saleTestFixture.productIntactaWithQuota, systemTestFixture.operationalYearOf2012, 2, QuotaImportedLineType.SAP, "12345");        file.add(line);        line = createQuotaImportedLine(saleTestFixture.customer, BigDecimal.valueOf(500L), saleTestFixture.productIntactaWithQuota, systemTestFixture.operationalYearOf2011, 3, QuotaImportedLineType.SAP, "12345");        file.add(line);        quotaImportProcessor.write(file, processorConfig);        assertImportResultStatus(3, 3, 0, 0, 0, file);       }
    
             @Test    public void given_an_imported_quota_line_when_I_process_then_should_write_all_3_successfully() {        QuotaImportedFile file = new QuotaImportedFile();        QuotaImportedLine line = createQuotaImportedLine(saleTestFixture.customer, BigDecimal.valueOf(1000L), saleTestFixture.productIntactaWithQuota, systemTestFixture.operationalYearOf2012, 1, QuotaImportedLineType.SAP, "12345");         file.add(line);        quotaImportProcessor.write(file, processorConfig);        assertImportResultStatus(1, 1, 0, 0, 0, file);    }        @Test    public void given_3_persisted_lines_in_table_when_read_then_should_read_all_3() throws IOException, BusinessException {        createAndPersistImportedLines();        QuotaImportedFile file = quotaImportProcessor.read(processorConfig);        assertImportResultStatus(3, 3, 0, 0, 3, file);    }        @Test    public void when_I_store_3_lines_in_table_then_should_be_able_read_write_all_3() throws IOException, BusinessException {        createAndPersistImportedLines();        QuotaImportedFile file = quotaImportProcessor.read(processorConfig);        assertImportResultStatus(3, 3, 0, 0, 3, file);                quotaImportProcessor.write(file, processorConfig);        assertImportResultStatus(3, 3, 0, 0, 3, file);    }        public void when_I_store_3_lines_in_table_then_balance_should_be_correct() throws IOException, BusinessException {        createAndPersistImportedLines();        QuotaImportedFile file = quotaImportProcessor.read(processorConfig);        assertImportResultStatus(3, 3, 0, 0, 3, file);                quotaImportProcessor.write(file, processorConfig);        assertImportResultStatus(3, 3, 0, 0, 3, file);                OperationalYear opYear = operationalYearService.selectAllOrderDesc().iterator().next();                Quota quota = quotaService.fetchOrCreateQuota(saleTestFixture.customer, saleTestFixture.productIntactaWithQuota, opYear, QuotaType.AVAILABLE, null, null, null);
        Assert.assertEquals("Should be 0", 0, quota.getBalance().compareTo(BigDecimal.valueOf(2500L)));    }
    
    @Test
    public void when_I_store_3_SAP_lines_in_table_then_write_no_lines_should_be_left() throws IOException, BusinessException {
        createAndPersistImportedLines();
        QuotaImportedFile file = quotaImportProcessor.read(processorConfig);
        assertImportResultStatus(3, 3, 0, 0, 3, file);
        
        quotaImportProcessor.write(file, processorConfig);
        assertImportResultStatus(3, 3, 0, 0, 3, file);
        
        List<QuotaImportedLine> importedLines = quotaService.getAllQuotaImportedLines();
        Assert.assertEquals("Should be empty (0)" , 0, importedLines.size());
    }    private ProcessorConfig createProcessorConfig(UserDecorator user) {        ProcessorConfig aProcessorConfig = new ProcessorConfig();        aProcessorConfig.put(ProcessorConfigProperties.SELECTED_LOCALE, localeBR);        aProcessorConfig.put(ProcessorConfigProperties.LOGGED_USER, user);                return aProcessorConfig;    }        private void createAndPersistImportedLines() {        QuotaImportedLine line = createQuotaImportedLine(saleTestFixture.customer, BigDecimal.valueOf(1000L), saleTestFixture.productIntactaWithQuota, systemTestFixture.operationalYearOf2012, 1, QuotaImportedLineType.SAP, "12345"); 
        saveAndFlush(line);        line = createQuotaImportedLine(saleTestFixture.customer, BigDecimal.valueOf(1000L), saleTestFixture.productIntactaWithQuota, systemTestFixture.operationalYearOf2012, 2, QuotaImportedLineType.SAP, "12346");
        saveAndFlush(line);        line = createQuotaImportedLine(saleTestFixture.customer, BigDecimal.valueOf(500L), saleTestFixture.productIntactaWithQuota, systemTestFixture.operationalYearOf2011, 3, QuotaImportedLineType.SAP, "12347");
        saveAndFlush(line);    }        private ProcessorConfig createProcessorConfigWithSuperUserAndMonsantoEuaAsSelectedCompany() {        UserDecorator loggedSuperUser = accessControlTestFixture.superUser;		return createProcessorConfig(loggedSuperUser);    }        private void assertImportResultStatus(int expectedSuccessLinesCount, int expectedDetailLinesCount, int expectedWarningCount, int expectedErrorsCount, int totalLineNumber, QuotaImportedFile actualResult) {        Assert.assertNotNull("Result of read file should not be null", actualResult);        Assert.assertEquals("Number of success lines is wrong", expectedSuccessLinesCount, actualResult.countSuccess());        Assert.assertEquals("Number of detail lines is wrong", expectedDetailLinesCount, actualResult.countDetailLines());        Assert.assertEquals("Number of warnings is wrong", expectedWarningCount, actualResult.countWarnings());        Assert.assertEquals("Number of erros is wrong", expectedErrorsCount, actualResult.countErrors());        Assert.assertEquals("Total # of lines is wrong", totalLineNumber, actualResult.countTotalLines());    }
    
    @Test
    public void given_a_csv_invalid_should_return_one_warning() throws IOException, BusinessException {
    	InputStream resourceAsStream = getClass().getClassLoader().getResourceAsStream("csvQuota/emptyFile.csv");
    	
    	QuotaImportedFile quotaImportedFile = quotaImportProcessor.read(resourceAsStream, processorConfig);
    	assertImportResultStatus(0, 0, 1, 0, 1, quotaImportedFile);
    }
    
    @Test
    public void given_a_csv_with_many_lines_should_return_many_lines_with_warning_on_parserValidation() throws IOException, BusinessException {
    	InputStream resourceAsStream = getClass().getClassLoader().getResourceAsStream("csvQuota/parseValidations.csv");

    	QuotaImportedFile quotaImportedFile = quotaImportProcessor.read(resourceAsStream, processorConfig);
    	Assert.assertEquals("Should have read a file with 3 lines", 3, quotaImportedFile.getTotalLines());
    	assertImportResultStatus(0, 0, 3, 0, 3, quotaImportedFile);
    }
    
    @Test
    public void given_a_stream_with_a_valid_file_should_have_one_valid_line() throws IOException, BusinessException {
    	InputStream inputStream = createInputStreamForCSVReader(saleTestFixture.customer.getDocumentValue(), saleTestFixture.productIntactaWithQuota.getId(), "C", "100", saleTestFixture.customer.getStateRegistration(), saleTestFixture.customer.getCustomerSAPCode());
    	
    	QuotaImportedFile quotaImportedFile = quotaImportProcessor.read(inputStream, processorConfig);
    	Assert.assertEquals("Should have read a file with 1 lines", 1, quotaImportedFile.getTotalLines());
    	assertImportResultStatus(1, 1, 0, 0, 1, quotaImportedFile);
    }
    
    @Test
    public void given_a_stream_with_valid_file_when_customer_not_allowed_for_user_then_should_return_one_warning() throws IOException, BusinessException {
    	InputStream inputStream = createInputStreamForCSVReader(saleTestFixture.matrixCargil.getDocumentValue(), saleTestFixture.productIntactaWithQuota.getId(), "C", "123", saleTestFixture.matrixCargil.getStateRegistration(), saleTestFixture.matrixCargil.getCustomerSAPCode());
    	ProcessorConfig processor = createProcessorConfig(accessControlTestFixture.userAdminOfMonsantoEua);
    	
    	QuotaImportedFile quotaImportedFile = quotaImportProcessor.read(inputStream, processor);
    	Assert.assertEquals("Should have read a file with 1 lines", 1, quotaImportedFile.getTotalLines());
    	assertImportResultStatus(0, 0, 1, 0, 1, quotaImportedFile);
    }
    
    @Ignore
    @Test
    public void given_a_stream_with_valid_file_when_debitQuota_dont_have_enough_balance_then_should_return_one_warning() throws IOException, BusinessException {
        
        quotaControlService.saveDeposit(saleTestFixture.customer, saleTestFixture.productIntactaWithQuota,
                systemTestFixture.operationalYearOf2012, QuotaType.AVAILABLE, BigDecimal.valueOf(9000),
                QuotaTransactionType.SAP, null, "AK", "JOHN", null, null, null);
        
    	StringBuffer lineBuffer = createLineForInputStream(saleTestFixture.customer.getDocumentValue(),
                saleTestFixture.productIntactaWithQuota.getId(), "D", "5000",
                saleTestFixture.customer.getStateRegistration(), saleTestFixture.customer.getCustomerSAPCode(), "12345");
    	createLineForInputStream(lineBuffer, saleTestFixture.customer.getDocumentValue(),
                saleTestFixture.customer.getStateRegistration(), saleTestFixture.customer.getCustomerSAPCode(),
                saleTestFixture.productIntactaWithQuota.getId(), "D", "5000", "12346");
    	InputStream inputStream = new ByteArrayInputStream(lineBuffer.toString().getBytes());
    	
    	QuotaImportedFile quotaImportedFile = quotaImportProcessor.read(inputStream, processorConfig);
    	this.quotaImportedFile = quotaImportProcessor.write(quotaImportedFile, processorConfig);
    	assertImportResultStatus(1, 2, 0, 1, 2, quotaImportedFile);
    }
    
    
    @Test
    public void given_a_stream_with_valid_file_when_debitQuota_dont_have_enough_balance_then_should_accuse_error_on_read() throws IOException, BusinessException {
        StringBuffer lineBuffer = createLineForInputStream(saleTestFixture.customer.getDocumentValue(), saleTestFixture.productIntactaWithQuota.getId(), "D", "10000", saleTestFixture.customer.getStateRegistration(), saleTestFixture.customer.getCustomerSAPCode());
        InputStream inputStream = new ByteArrayInputStream(lineBuffer.toString().getBytes());
        
        QuotaImportedFile quotaImportedFile = quotaImportProcessor.read(inputStream, processorConfig);
        this.quotaImportedFile = quotaImportProcessor.write(quotaImportedFile, processorConfig);
        assertImportResultStatus(0, 0, 1, 0, 1, quotaImportedFile);
    }
    
    @Test
    public void given_a_stream_with_invalid_file_decimal_amount_when_parse_file_then_should_show_1_warning() throws IOException, BusinessException {
        StringBuffer lineBuffer = createLineForInputStream(saleTestFixture.customer.getDocumentValue(), saleTestFixture.productIntactaWithQuota.getId(), "C", "500,55", saleTestFixture.customer.getStateRegistration(), saleTestFixture.customer.getCustomerSAPCode());
        InputStream inputStream = new ByteArrayInputStream(lineBuffer.toString().getBytes());
        QuotaImportedFile quotaImportedFile = quotaImportProcessor.read(inputStream, processorConfig);
        assertImportResultStatus(0, 0, 1, 0, 1, quotaImportedFile);
    }
    
    @Test
    public void given_a_customer_that_is_not_headoffice_when_read_file_then_should_have_warning() throws IOException, BusinessException {
        
        Document document = Mockito.mock(Document.class);
        Mockito.when(document.getDocumentTypeDescription()).thenReturn("CNPJ");
        document.setValue("77227656245799");
        
        Customer customer = new Customer("cust", document, new Address(), "1234");
        customer.setStateRegistration("SP");
        
        StringBuffer csv = createLineForInputStream(customer.getDocumentValue(), saleTestFixture.productIntactaWithQuota.getId(), "C", "500", customer.getStateRegistration(), customer.getCustomerSAPCode());
    	InputStream inputStream = new ByteArrayInputStream(csv.toString().getBytes());
    	QuotaImportedFile quotaImportedFile = quotaImportProcessor.read(inputStream, processorConfig);
    	
        assertImportResultStatus(0, 0, 1, 0, 1, quotaImportedFile);
    }
    
    @Test
    public void given_a_customer_that_is_headoffice_when_read_file_then_should_have_no_warning() throws IOException, BusinessException {
        StringBuffer csv = createLineForInputStream(saleTestFixture.customer.getDocumentValue(), saleTestFixture.productIntactaWithQuota.getId(), "C", "500", saleTestFixture.customer.getStateRegistration(), saleTestFixture.customer.getCustomerSAPCode());
        InputStream inputStream = new ByteArrayInputStream(csv.toString().getBytes());
        QuotaImportedFile quotaImportedFile = quotaImportProcessor.read(inputStream, processorConfig);
        
        assertImportResultStatus(1, 1, 0, 0, 1, quotaImportedFile);
    }
    
	private InputStream createInputStreamForCSVReader(String documentValue, Long productCode, String transactionType, String amountInString, String stateRegistration, String sapCode) {
		StringBuffer csv = createLineForInputStream(documentValue, productCode, transactionType, amountInString, stateRegistration, sapCode);
    	InputStream inputStream = new ByteArrayInputStream(csv.toString().getBytes());
		return inputStream;
	}

    private StringBuffer createLineForInputStream(StringBuffer csv, String documentValue, String stateRegistration, String customerSapCode,
            Long productCode, String transactionType, String amountInString, String invoiceNumber) {
        if(csv==null) {
	        csv = new StringBuffer("Tipo de documento do Matriz;Matriz;Inscricao Estadual;Customer Sap Code;Tipo do Documento Multiplicador;N�mero do Documento do Multiplicador;N�mero da Inscri��o Estadual Multiplicador;C�digo ERP da Multiplicador;Codigo Produto;Lote;Faixa;Tipo Transação;Ano;Quantidate ;Numero Nota Fiscal\n");
        }
		csv.append("CNPJ;").append(documentValue + ";");
		csv.append(stateRegistration == null ? ";" : stateRegistration + ";");
		csv.append(customerSapCode + ";");
		csv.append(";");
		csv.append(";");
		csv.append(";");
		csv.append(";");
		csv.append(productCode +";");
		csv.append(";");
		csv.append(";");
    	csv.append(transactionType + ";").append("2008;").append(amountInString + ";");
    	csv.append(invoiceNumber == null ? "\n" : invoiceNumber + "\n");
        return csv;
    }
    
    @Test
    public void given_one_valid_line_and_one_invalid_document_type_when_parse_csv_then_should_have_one_warning() throws IOException, BusinessException {
        StringBuffer csv = createLineForInputStream(saleTestFixture.customer.getDocumentValue(), saleTestFixture.productIntactaWithQuota.getId(), "C", "500", saleTestFixture.customer.getStateRegistration(), saleTestFixture.customer.getCustomerSAPCode());
        csv = createInvalidDocumentTypeLineForInputStream(csv, saleTestFixture.customer.getDocumentValue(), null, null, saleTestFixture.productIntactaWithQuota.getId(), "C", "500");
        InputStream inputStream = new ByteArrayInputStream(csv.toString().getBytes());
        QuotaImportedFile quotaImportedFile = quotaImportProcessor.read(inputStream, processorConfig);
        
        assertImportResultStatus(1, 1, 1, 0, 2, quotaImportedFile);
    }
    
    private StringBuffer createInvalidDocumentTypeLineForInputStream(StringBuffer csv, String documentValue, String stateRegistration, String customerSapCode, Long productCode, String transactionType,
            String amountInString) {
        if(csv==null) {
            csv = new StringBuffer("Tipo de documento do Matriz;Matriz;Inscricao Estadual;Customer Sap Code;Tipo do Documento Multiplicador;N�mero do Documento do Multiplicador;N�mero da Inscri��o Estadual Multiplicador;C�digo ERP da Multiplicador;Codigo Produto;Lote;Faixa;Tipo Transação;Ano;Quantidate ;Numero Nota Fiscal\n");
        }
        csv.append("CNPU;").append(documentValue + ";");
        csv.append(stateRegistration == null ? ";" : stateRegistration + ";");
        csv.append(customerSapCode + ";");
		csv.append(";");
		csv.append(";");
		csv.append(";");
		csv.append(";");
        csv.append(productCode +";");
		csv.append(";");
		csv.append(";");
        csv.append(transactionType + ";").append("2008;").append(amountInString + ";\n");
        return csv;
    }
    
    private StringBuffer createLineForInputStream(String documentValue, Long productCode, String transactionType,
            String amountInString, String customerStateRegistration, String sapCode) {
    	return createLineForInputStream(null, documentValue, customerStateRegistration, sapCode, productCode, transactionType, amountInString, null);
    }
    
    private StringBuffer createLineForInputStream(String documentValue, Long productCode, String transactionType,
            String amountInString, String customerStateRegistration, String sapCode, String invoiceNumber) {
        return createLineForInputStream(null, documentValue, customerStateRegistration, sapCode, productCode, transactionType, amountInString, invoiceNumber);
    }
}