/**
 * 
 */
package com.monsanto.brazilvaluecapture.seedsale.sale.service;

import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.monsanto.brazilvaluecapture.core.base.SystemTestFixture;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Customer;
import com.monsanto.brazilvaluecapture.core.foundation.model.bean.ApprovalEnum;
import com.monsanto.brazilvaluecapture.core.foundation.service.BusinessException;
import com.monsanto.brazilvaluecapture.core.foundation.service.EntityNotFoundException;
import com.monsanto.brazilvaluecapture.core.foundation.test.AbstractServiceIntegrationTests;
import com.monsanto.brazilvaluecapture.core.foundation.test.dbunit.DbUnitHelper;
import com.monsanto.brazilvaluecapture.core.revenue.model.bean.ChargeConsolidateType;
import com.monsanto.brazilvaluecapture.core.revenue.model.bean.ChargeConsolidateTypeEnum;
import com.monsanto.brazilvaluecapture.core.user.AccessControlTestFixture;
import com.monsanto.brazilvaluecapture.seedsale.billing.model.bean.Billing;
import com.monsanto.brazilvaluecapture.seedsale.billing.model.bean.CreditStatus;
import com.monsanto.brazilvaluecapture.seedsale.sale.SaleTestFixture;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.ReleaseMatrix;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.ReleaseMatrixToBilling;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.dao.ReleaseMatrixDAO;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.dao.ReleaseMatrixFilter;

/**
 * @author andregc
 *
 */
public class ReleaseMatrix_AT extends AbstractServiceIntegrationTests {

    @Autowired
    private ReleaseMatrixService releaseMatrixService;
    	    
	private ChargeConsolidateType saleRegisterChargeType;	    
	private ReleaseMatrixFilter releaseMatrixFilter;
	
	private ChargeConsolidateType marketingProgramType;

	@Autowired
	private ReleaseMatrixDAO releaseMatrixDAO;
	
	@Before
	public void init() {
		systemTestFixture = new SystemTestFixture(this);
		accessControlTestFixture = new AccessControlTestFixture(this, systemTestFixture);
		saleTestFixture = new SaleTestFixture(this, systemTestFixture);
				
		DbUnitHelper.setup("classpath:data/core/fixture-system-dataset.xml", "classpath:data/core/participant-dataset.xml");
		createChargeConsolidateTypes();
		saleRegisterChargeType = chargeConsolidateService.findConsolidateType(ChargeConsolidateTypeEnum.SALEREGISTERCHARGE);
		marketingProgramType = chargeConsolidateService.findConsolidateType(ChargeConsolidateTypeEnum.MARKETINGPROGRAM);
		
		releaseMatrixFilter = ReleaseMatrixFilter.getInstance();
	}
	
	@Test(expected = IllegalArgumentException.class)
	public void given_an_empty_list_when_i_release_then_releaseMatrix_should_throw_exception() {
		ArrayList<ReleaseMatrix> list = new ArrayList<ReleaseMatrix>();
		
		releaseMatrixService.approve(list, "JOHN");
	}
	
	@Test
	public void given_one_releaseMatrix_when_i_release_then_releaseMatrix_shouldBe_approved() throws BusinessException {
		ReleaseMatrix matrix = createReleaseMatrixFor(saleTestFixture.matrixCargil, saleRegisterChargeType);
		
		ArrayList<ReleaseMatrix> list = new ArrayList<ReleaseMatrix>();
		list.add(matrix);
		
		releaseMatrixService.approve(list, "JOHN");
		Long id = matrix.getId();
		getSession().flush();
		getSession().evict(matrix);
		
		ReleaseMatrix matrixBD = (ReleaseMatrix) getSession().get(ReleaseMatrix.class, id);
		
		Assert.assertTrue("Release Matrix should be approved", matrixBD.isAproved());
	}
	
	@Test
	public void given_2_releaseMatrix_with_one_approved_when_i_release_then_shouldBe_return_sucess() throws BusinessException {
		ReleaseMatrix matrixNotApproved = createReleaseMatrixFor(saleTestFixture.matrixCargil, saleRegisterChargeType);
		ReleaseMatrix matrixApproved = createReleaseMatrixFor(saleTestFixture.matrixMons4nto, saleRegisterChargeType);
		
		ArrayList<ReleaseMatrix> list = new ArrayList<ReleaseMatrix>();
		list.add(matrixNotApproved);
		list.add(matrixApproved);
		
		releaseMatrixService.approve(list, "JOHN");
		getSession().flush();

		getSession().evict(matrixNotApproved);
		getSession().evict(matrixApproved);

		ReleaseMatrix matrixNotApprovedBD = (ReleaseMatrix) getSession().get(ReleaseMatrix.class, matrixNotApproved.getId());
		ReleaseMatrix matrixApprovedBD = (ReleaseMatrix) getSession().get(ReleaseMatrix.class, matrixApproved.getId());

		Assert.assertTrue("Release Matrix should be approved", matrixNotApprovedBD.isAproved());
		Assert.assertTrue("Release Matrix should be approved", matrixApprovedBD.isAproved());
	}
	
    @Test
	public void given_one_releaseMatrix_when_search_withoutFilter_shouldReturn_one_result() throws BusinessException{		
		createReleaseMatrixFor(saleTestFixture.matrixCargil, saleRegisterChargeType);

		List<ReleaseMatrix> list = releaseMatrixService.getByFilter(releaseMatrixFilter);
		
		Assert.assertEquals("Should have one result", 1, list.size());
	}
	
	@Test
	public void given_one_releaseMatrix_aproved_when_add_aprovedFilter_true_shouldReturn_one_result() throws BusinessException{		
		createApprovedReleaseMatrixFor(saleTestFixture.matrixCargil, saleRegisterChargeType);
		
		releaseMatrixFilter.addAproved(ApprovalEnum.APROVED);
		
		List<ReleaseMatrix> list = releaseMatrixService.getByFilter(releaseMatrixFilter);
		
		Assert.assertEquals("Should have one result", 1, list.size());
	}

	private ReleaseMatrix createApprovedReleaseMatrixFor(Customer matrix, ChargeConsolidateType chargeConsolidateType) throws BusinessException {
		ReleaseMatrix releaseMatrix = createReleaseMatrixFor(saleTestFixture.matrixCargil, saleRegisterChargeType);
		List<ReleaseMatrix> list = new ArrayList<ReleaseMatrix>();
		list.add(releaseMatrix);
		releaseMatrixService.approve(list, "JOHN");
		
		return releaseMatrix;
	}
	

	@Test
	public void given_one_releaseMatrix_aproved_when_add_aprovedFilter_false_shouldReturn_no_results() throws BusinessException{		
		createApprovedReleaseMatrixFor(saleTestFixture.matrixCargil, saleRegisterChargeType);
				
		releaseMatrixFilter.addAproved(ApprovalEnum.DONT_APROVED);
		
		List<ReleaseMatrix> list = releaseMatrixService.getByFilter(releaseMatrixFilter);
		
		Assert.assertEquals("Should no results", 0, list.size());
	}
	
	
	@Test
	public void given_one_releaseMatrix_aproved_when_add_operationalYearFilter_shouldReturn_one_result() throws BusinessException{		
		createReleaseMatrixFor(saleTestFixture.matrixCargil, saleRegisterChargeType);
				
		releaseMatrixFilter.addOperationalYear(saleTestFixture.harvestSoyMonsanto2012.getOperationalYear());
		
		List<ReleaseMatrix> list = releaseMatrixService.getByFilter(releaseMatrixFilter);
		
		Assert.assertEquals("Should have one result", 1, list.size());
	}
	

	@Test
	public void given_one_releaseMatrix_aproved_when_add_operationalYearFilter_shouldReturn_no_results() throws BusinessException{		
		createReleaseMatrixFor(saleTestFixture.matrixCargil, saleRegisterChargeType);
				
		releaseMatrixFilter.addOperationalYear(systemTestFixture.operationalYearOf2009);
		
		List<ReleaseMatrix> list = releaseMatrixService.getByFilter(releaseMatrixFilter);

		Assert.assertEquals("Should no results", 0, list.size());
	}
	
	
	@Test
	public void given_one_releaseMatrix_aproved_when_add_all_filters_shouldReturn_one_result() throws BusinessException{		
		createApprovedReleaseMatrixFor(saleTestFixture.matrixCargil, saleRegisterChargeType);
				
		List<ChargeConsolidateType> chargeConsolidateTypes = new ArrayList<ChargeConsolidateType>();
		chargeConsolidateTypes.add(saleRegisterChargeType);
		
		releaseMatrixFilter
			.addOperationalYear(saleTestFixture.harvestSoyMonsanto2012.getOperationalYear())
			.addHarvest(saleTestFixture.harvestSoyMonsanto2012)
			.addMatrix(saleTestFixture.matrixCargil)
			.addChargeConsolidateTypes(chargeConsolidateTypes)
			.addAproved(ApprovalEnum.APROVED);
		
		List<ReleaseMatrix> list = releaseMatrixService.getByFilter(releaseMatrixFilter);
		
		Assert.assertEquals("Should have one result", 1, list.size());
	}
	
	@Test
	public void given_one_releaseMatrix_aproved_when_add_hierarchyMatrixfilter_shouldReturn_one_result() throws BusinessException{		
		createApprovedReleaseMatrixFor(saleTestFixture.matrixCargil, saleRegisterChargeType);
				
		List<ChargeConsolidateType> chargeConsolidateTypes = new ArrayList<ChargeConsolidateType>();
		
		releaseMatrixFilter
			.addOperationalYear(saleTestFixture.harvestSoyMonsanto2012.getOperationalYear())
			.addHarvest(saleTestFixture.harvestSoyMonsanto2012)
			.addHierarchyMatrix(systemTestFixture.unity, systemTestFixture.region, systemTestFixture.districtCampinas)
			.addChargeConsolidateTypes(chargeConsolidateTypes)
			.addAproved(ApprovalEnum.APROVED);
		
		List<ReleaseMatrix> list = releaseMatrixService.getByFilter(releaseMatrixFilter);

		
		Assert.assertEquals("Should have one result", 1, list.size());
	}
	
	@Test
	public void given_one_releaseMatrix_aproved_when_add_null_filters_shouldReturn_one_result() throws BusinessException{		
		createApprovedReleaseMatrixFor(saleTestFixture.matrixCargil, marketingProgramType);
		
		releaseMatrixFilter
			.addOperationalYear(null)
			.addHarvest(null)
			.addMatrix(null)
			.addHierarchyMatrix(null, null, null)
			.addChargeConsolidateTypes(null)
			.addAproved(ApprovalEnum.APROVED);
		
		List<ReleaseMatrix> list = releaseMatrixService.getByFilter(releaseMatrixFilter);
		
		Assert.assertEquals("Should have one result", 1, list.size());
	}
	
	@Test
	public void given_one_releaseMatrix_MARKETINGPROGRAM_when_add_type_filter_shouldReturn_one_result() throws BusinessException {
		createReleaseMatrixFor(saleTestFixture.matrixCargil, marketingProgramType);
		
		List<ChargeConsolidateType> chargeConsolidateTypes = new ArrayList<ChargeConsolidateType>();
		chargeConsolidateTypes.add(marketingProgramType);
		
		releaseMatrixFilter.addChargeConsolidateTypes(chargeConsolidateTypes);
		
		List<ReleaseMatrix> list = releaseMatrixService.getByFilter(releaseMatrixFilter);
		
		Assert.assertEquals("Should have one result", 1, list.size());
		
	}

	private ReleaseMatrix createReleaseMatrixFor(Customer matrix, ChargeConsolidateType chargeConsolidateType) throws BusinessException {
		return createReleaseMatrixFor(matrix, chargeConsolidateType, getSavedBilling());
	}
	
	private ReleaseMatrix createReleaseMatrixFor(Customer matrix, ChargeConsolidateType chargeConsolidateType, Billing billing) throws BusinessException {
		ReleaseMatrix releaseMatrix = new ReleaseMatrix(saleTestFixture.harvestSoyMonsanto2012, matrix, chargeConsolidateType);
		saveAndFlush(releaseMatrix);
		
		ReleaseMatrixToBilling releaseMatrixToPayment = new ReleaseMatrixToBilling(releaseMatrix, billing);
		saveAndFlush(releaseMatrixToPayment);
		
		return releaseMatrix;

	}

	private Billing getSavedBilling() {
		Billing billing = new Billing();
		billing.setCreditStatus(CreditStatus.RELEASED_AUTOMATICALLY);
		saveAndFlush(billing);
		return billing;
	}
	
	@Test
	public void given_a_existent_releaseMatrix_when_i_search_shouldReturn_this() throws BusinessException {
		ReleaseMatrix matrix = createReleaseMatrixFor(saleTestFixture.matrixCargil, saleRegisterChargeType);
		getSession().flush();
		getSession().evict(matrix);
		
		ReleaseMatrix matrixDB = releaseMatrixService.getReleaseMatrixFor(matrix.getCustomer(), matrix.getHarvest(), saleRegisterChargeType);
		Assert.assertEquals(matrix.getId(), matrixDB.getId());
	}
	
	@Test
	public void when_i_search_for_a_releaseMatrix_that_doesnt_exist_then_shouldReturn_a_new_releaseMatrix_not_approved() throws BusinessException {
		Assert.assertTrue("Should not have ReleaseMatrix in DB", getSession().createQuery("from ReleaseMatrix r").list().isEmpty());
		releaseMatrixService.getReleaseMatrixFor(saleTestFixture.matrixCargil, saleTestFixture.harvestSoyMonsanto2012, marketingProgramType);
		Assert.assertEquals("Should have one ReleaseMatrix in DB", 1, getSession().createQuery("from ReleaseMatrix r").list().size());
	}
	
	@Test(expected=IllegalArgumentException.class)
	public void given_an_billing_not_associated_with_a_releaseMatrix_when_i_update_releaseMatrix_after_cancel_shouldThrowException() {
		Billing billing = getSavedBilling();
		releaseMatrixService.updateAfterCancelBilling(billing);
	}
	
	@Test
	public void given_an_billing_associated_with_a_releaseMatrix_when_i_update_after_cancellation_should_delete_the_releaseMatrixToBilling() throws BusinessException {
		Billing billing = getSavedBilling();
		createReleaseMatrixFor(saleTestFixture.matrixCargil, saleRegisterChargeType, billing);
		
		Assert.assertNotNull("ReleaseMatrixToBilling should not be null", releaseMatrixDAO.getReleaseMatrixToBillingBy(billing));
		
		releaseMatrixService.updateAfterCancelBilling(billing);
		
		try {
			releaseMatrixDAO.getReleaseMatrixToBillingBy(billing);
			Assert.fail("ReleaseMatrixToBilling should be deleted");
		} catch (EntityNotFoundException e) {
		}
	}
	
}
