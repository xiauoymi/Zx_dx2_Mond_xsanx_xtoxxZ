package com.monsanto.brazilvaluecapture.seedsale.forecastcustomer.service.impl;

import static org.fest.reflect.core.Reflection.field;
import static org.junit.Assert.fail;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyString;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.*;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.ResourceBundle;

import com.monsanto.brazilvaluecapture.core.serviceFee.model.bean.ServiceFeeProgram;
import com.monsanto.brazilvaluecapture.seedsale.forecastcustomer.validation.*;
import junit.framework.Assert;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.monsanto.brazilvaluecapture.core.base.model.bean.Country;
import com.monsanto.brazilvaluecapture.core.base.service.BaseService;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Customer;
import com.monsanto.brazilvaluecapture.core.customer.service.CustomerNotFoundException;
import com.monsanto.brazilvaluecapture.core.customer.service.CustomerService;
import com.monsanto.brazilvaluecapture.core.foundation.util.ConstraintViolation;
import com.monsanto.brazilvaluecapture.core.foundation.util.csv.CSVReadableInvalidException;
import com.monsanto.brazilvaluecapture.core.foundation.util.parser.ParsedLineResult;
import com.monsanto.brazilvaluecapture.seedsale.feeAccount.model.bean.FeeAccount;
import com.monsanto.brazilvaluecapture.seedsale.feeAccount.service.FeeAccountService;
import com.monsanto.brazilvaluecapture.seedsale.forecastcustomer.model.bean.ForecastCustomer;
import com.monsanto.brazilvaluecapture.seedsale.forecastcustomer.service.ForecastCustomerService;
import com.monsanto.brazilvaluecapture.seedsale.forecastcustomer.validation.ForecastCustomerAlreadyPaidValidationRule;
import com.monsanto.brazilvaluecapture.seedsale.forecastcustomer.validation.ForecastCustomerConstraintViolationException;
import com.monsanto.brazilvaluecapture.seedsale.forecastcustomer.validation.ForecastCustomerForecastValueValidationRule;
import com.monsanto.brazilvaluecapture.seedsale.forecastcustomer.validation.ForecastCustomerValidator;
import com.monsanto.brazilvaluecapture.seedsale.harvest.model.bean.Harvest;
import com.monsanto.brazilvaluecapture.seedsale.product.model.bean.Product;

public class ForecastCustomerFileParser_UT {

	@Mock
	private ForecastCustomerValidator forecastCustomerValidatorThrowsExceptionValidate;
	@Mock
	private ForecastCustomerValidator forecastCustomerValidator;
	private ForecastCustomerAlreadyPaidValidationRule forecastCustomerAlreadyPaidValidationRule;
	private ForecastCustomerForecastValueValidationRule forecastCustomerForecastValueValidationRule;
    private ForecastCustomerForecastDocumentValidationRule forecastCustomerForecastDocumentValidationRule;
    private ForecastCustomerForecastNameValidationRule forecastCustomerForecastNameValidationRule;
	@Mock
	private ForecastCustomerService forecastCustomerService;
	@Mock
	private ResourceBundle resourceBundle;
	private final static String SEPARATOR=";";
	private static final String DOCUMENT_NUMBER = "30550246771";
	private static final String NAME = "prueba1";
	private static final String FORECAST = "10";
	private Country country;
	@InjectMocks
	private ForecastCustomerFileParser validFileParser;
	@InjectMocks
    private ForecastCustomerFileParser invalidFileParser;
	@Mock
	private BaseService baseService;
	Locale locale;
	
	private List<ParsedLineResult> warnings = new ArrayList<ParsedLineResult>() ;
	
	@Mock
	private CustomerService customerService;
	
	@Mock
	private FeeAccountService feeAccountService;
	
	private Product product;
	
	private Harvest harvest;

    private ServiceFeeProgram serviceFeeProgram;
	
	private Customer customer;
	
	@Before
	public void setUp() throws ForecastCustomerConstraintViolationException,
			IOException, CustomerNotFoundException {

		MockitoAnnotations.initMocks(this);
		customer =  new Customer();
		when(forecastCustomerValidator.validate(any(ForecastCustomer.class))).thenReturn(new ForecastCustomer());

		locale = new Locale("ar", "AR");
		country = new Country("ar", "AR");
		product = new Product();
		harvest = new Harvest();
        serviceFeeProgram = new ServiceFeeProgram();
		validFileParser = new ForecastCustomerFileParser(resourceBundle,
				forecastCustomerService, "test", createValidInputStream(),
				locale, "User", country, forecastCustomerValidator, product,
				harvest, serviceFeeProgram);

		invalidFileParser = new ForecastCustomerFileParser(resourceBundle,
				forecastCustomerService, "test", createInValidInputStream(),
				locale, "User", country, forecastCustomerValidator, product,
				harvest, serviceFeeProgram);
		field("warnings").ofType(List.class).in(this.invalidFileParser)
				.set(warnings);

	}

	 private InputStream createInValidInputStream() throws IOException {
	        ByteArrayOutputStream outputStream=new ByteArrayOutputStream();

	        StringBuilder header=new StringBuilder("documentNumber").append(SEPARATOR).append("name").append(SEPARATOR).append("forecast\n");

	        StringBuilder line=new StringBuilder(DOCUMENT_NUMBER).append(SEPARATOR).append(NAME).append(SEPARATOR);
	        line.append("-1").append(SEPARATOR);

	        outputStream.write(header.toString().getBytes());
	        outputStream.write(line.toString().getBytes());

	        InputStream inputStream = new ByteArrayInputStream(outputStream.toByteArray());
	        outputStream.close();
	        return inputStream;
	}

	private InputStream createValidInputStream() throws IOException {
	        ByteArrayOutputStream outputStream=new ByteArrayOutputStream();

	        StringBuilder header=new StringBuilder("documentNumber").append(SEPARATOR).append("name").append(SEPARATOR).append("forecast\n");

	        StringBuilder line=new StringBuilder(DOCUMENT_NUMBER).append(SEPARATOR).append(NAME).append(SEPARATOR);
	        line.append(FORECAST);

	        outputStream.write(header.toString().getBytes());
	        outputStream.write(line.toString().getBytes());

	        InputStream inputStream = new ByteArrayInputStream(outputStream.toByteArray());
	        outputStream.close();
	        return inputStream;
	}
	 
	 
	@Test
    public void read_ShouldAddWarnings_WhenFileHasInvalidRecords(){

        try {
            invalidFileParser.readFile();
            invalidFileParser.process();

            Assert.assertEquals(1, invalidFileParser.getErrorLines());
            Assert.assertEquals(0,invalidFileParser.getSuccessLines());

        } catch (CSVReadableInvalidException e) {
            fail();
        }
    }
	
	@Test
	public void read_ShouldNotAddWarnings_WhenFileHasInvalidRecords() {

		try {
			validFileParser.readFile();
			validFileParser.process();

			Assert.assertEquals(0, validFileParser.getErrorLines());
			Assert.assertEquals(1, validFileParser.getSuccessLines());

		} catch (CSVReadableInvalidException e) {
			fail();
		}
	}
	
	@Test
	public void read_ShouldNotAddWarnings_CSVInvalidLayoutException() throws IOException {

		try {
			 invalidFileParser = new ForecastCustomerFileParser(resourceBundle,
						forecastCustomerService, "test", createInValidInputStream(),
						locale, "User", country, forecastCustomerValidator, product,
						harvest, serviceFeeProgram);

			 invalidFileParser.readFile();
			 invalidFileParser.process();

			Assert.assertEquals(1, invalidFileParser.getWarnings().size());

		} catch (CSVReadableInvalidException e) {
			fail();
		}
	}
	
	@Test
	public void read_ShouldAddWarnings_WhenFileHasInValidFeeAccountSettled() throws ForecastCustomerConstraintViolationException {

		try {
			ConstraintViolation violation = mock(ConstraintViolation.class);
			ForecastCustomerConstraintViolationException exception = new ForecastCustomerConstraintViolationException("error", violation);
			when(forecastCustomerValidator.validate(any(ForecastCustomer.class))).thenThrow(exception);
			FeeAccount feeAccount = new FeeAccount();
			feeAccount.setSettled(new BigDecimal(15));
			when(feeAccountService.getFeeAccountByCustomer(any(Customer.class),anyString())).thenReturn(feeAccount);
			validFileParser.readFile();
			validFileParser.process();

			Assert.assertEquals(1, validFileParser.getErrorLines());
			Assert.assertEquals(0, validFileParser.getSuccessLines());

		} catch (CSVReadableInvalidException e) {
			fail();
		}
	}

    public ServiceFeeProgram getServiceFeeProgram() {
        return serviceFeeProgram;
    }

    public void setServiceFeeProgram(ServiceFeeProgram serviceFeeProgram) {
        this.serviceFeeProgram = serviceFeeProgram;
    }
}
