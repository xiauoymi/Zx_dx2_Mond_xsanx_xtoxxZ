package com.monsanto.brazilvaluecapture.seedsale.sale.service;

import java.math.BigDecimal;

import com.monsanto.brazilvaluecapture.core.base.model.bean.State;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Customer;
import com.monsanto.brazilvaluecapture.core.foundation.RandomTestData;
import com.monsanto.brazilvaluecapture.core.grower.model.bean.Grower;
import com.monsanto.brazilvaluecapture.seedsale.product.model.bean.Product;
import com.monsanto.brazilvaluecapture.seedsale.product.model.bean.Region;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.Sale;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.Sale.SaleTypeEnum;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.SaleItem;
import com.monsanto.brazilvaluecapture.seedsale.template.model.bean.SaleTemplate;

public class SaleTestData {

    private Region region;
    private State state;

    public SaleTestData(Region region) {
        this.region = region;
    }

    public SaleTestData setState(State state) {
        this.state = state;
        return this;
    }

    /**
	 * 
	 * @param customer
	 * @param grower
	 * @return
	 */
	public Sale createSale(Customer customer, Grower grower, SaleTypeEnum saleType) {
		Sale sale =  new Sale(customer, grower);
		sale.setInvoiceDate(RandomTestData.createRandomDateInThePast());
		sale.setInvoiceNumber(RandomTestData.createRandomLong()+"");
		sale.setSaleNote(RandomTestData.createRandomString(20));
		sale.setSaleType(saleType);
        sale.setRegion(region);
        sale.setState(state);
		return sale;
	}
	
	/**
	 * 
	 * @param sale
	 * @param saleTemplate
	 * @param product
	 * @return
	 */
	public static SaleItem createSaleItem(Sale sale, SaleTemplate saleTemplate, Product product, Customer matrix) {
		SaleItem saleItem = new SaleItem(sale, saleTemplate, product, matrix);
		
		saleItem.setPlantability(RandomTestData.createRandomString());
		saleItem.setPriceQuantity(new BigDecimal(11));
		saleItem.setProductivityValue(BigDecimal.valueOf(10L));
		saleItem.setSoldQuantity(10L);
		saleItem.setTotalCreditValue(10L);
		saleItem.setTotalRoyaltyValue(new BigDecimal(10));
		
		return saleItem;
	}

}