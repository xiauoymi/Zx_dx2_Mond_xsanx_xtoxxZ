package com.monsanto.brazilvaluecapture.core.grower.model.bean;

import com.monsanto.brazilvaluecapture.core.customer.model.bean.Customer;
import com.monsanto.brazilvaluecapture.core.revenue.model.bean.ChargeConsolidate;
import com.monsanto.brazilvaluecapture.core.revenue.model.bean.ChargeGroup;
import com.monsanto.brazilvaluecapture.core.revenue.model.bean.ChargeGroupStatus;
import edu.emory.mathcs.backport.java.util.Arrays;
import org.junit.Test;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import static junit.framework.Assert.assertEquals;
import static junit.framework.Assert.assertNotNull;
import static org.fest.assertions.Assertions.assertThat;
import static org.junit.Assert.assertNull;

public class BonusConsumption_UT {
    @Test
    public void testGetHeadOfficeReturnsACustomerInstance() {
        //@Given a consumption with a head office associated
        BonusConsumption bonusConsumption = new BonusConsumption();
        Customer headOffice = new Customer();
        bonusConsumption.setHeadOffice(headOffice);

        //@When head office is requested
        Customer resultingHeadOffice = bonusConsumption.getHeadOffice();

        //@Then should return the same instance of customer
        assertThat(resultingHeadOffice).isNotNull();
        assertThat(resultingHeadOffice).isEqualTo(headOffice);
    }

    @Test
    public void testGetVoucherReceived_WhenBonusConsumptionStatusIsVoucherReceived() {
        BonusConsumption bonusConsumption = new BonusConsumption();
        bonusConsumption.setBonusConsumptionStatus(BonusConsumptionStatusEnum.VOUCHER_RECEIVED);

        assertThat(bonusConsumption.getVoucherReceived()).isTrue();
    }

    @Test
    public void testGetVoucherReceived_WhenBonusConsumptionStatusIsNotVoucherReceived() {
        BonusConsumption bonusConsumption = new BonusConsumption();
        bonusConsumption.setBonusConsumptionStatus(BonusConsumptionStatusEnum.OPENED);

        assertThat(bonusConsumption.getVoucherReceived()).isFalse();
    }

    @Test
    public void testGetPartiallyPaid() {
        BonusConsumption bonusConsumption = new BonusConsumption();
        bonusConsumption.setBonusConsumptionStatus(BonusConsumptionStatusEnum.PARTIALLY_PAID);
        assertEquals(Boolean.TRUE, bonusConsumption.getPartiallyPaid());

        bonusConsumption.setBonusConsumptionStatus(null);
        assertThat(bonusConsumption.getPartiallyPaid()).isFalse();
    }

    @Test
    public void testGetPartiallyReversible() {
        // should be true when Consumption is partially paid
        BonusConsumption bonusConsumption1 = new BonusConsumption();
        bonusConsumption1.setBonusConsumptionStatus(BonusConsumptionStatusEnum.PARTIALLY_PAID);
        assertEquals(Boolean.TRUE, bonusConsumption1.getPartiallyReversible());

        // should be false when Consumption is partially paid
        BonusConsumption bonusConsumption2 = new BonusConsumption();
        bonusConsumption2.setBonusConsumptionStatus(BonusConsumptionStatusEnum.PAID);
        assertEquals(Boolean.FALSE, bonusConsumption2.getPartiallyReversible());

        // should be true when (consumption amount - paid - reversed amount) > 0
        BonusConsumption bonusConsumption3 = new BonusConsumption();
        bonusConsumption3.setBonusConsumptionStatus(BonusConsumptionStatusEnum.PARTIALLY_PAID_REVERSED);
        bonusConsumption3.setConsumedAmount(new BigDecimal("300.1"));
        List<BonusConsumptionReversal> reversalList = new ArrayList<BonusConsumptionReversal>();
        BonusConsumptionReversal bonusConsumptionReversal1 = new BonusConsumptionReversal();
        bonusConsumptionReversal1.setReversedAmount(new BigDecimal("100"));
        BonusConsumptionReversal bonusConsumptionReversal2 = new BonusConsumptionReversal();
        bonusConsumptionReversal2.setReversedAmount(new BigDecimal("100"));
        reversalList.add(bonusConsumptionReversal1);
        reversalList.add(bonusConsumptionReversal2);
        bonusConsumption3.setReversals(reversalList);
        List<BonusConsumptionPayment> payments = new ArrayList<BonusConsumptionPayment>();
        BonusConsumptionPayment bonusConsumptionPayment = new BonusConsumptionPayment();
        bonusConsumptionPayment.setPaidAmount(new BigDecimal("100"));
        ChargeConsolidate serviceFee = new ChargeConsolidate();
        ChargeGroup chargeGroup = new ChargeGroup();
        chargeGroup.setChargeGroupStatus(ChargeGroupStatus.PROCESSED);
        serviceFee.setChargeGroup(chargeGroup);
        bonusConsumptionPayment.setServiceFee(serviceFee);
        payments.add(bonusConsumptionPayment);
        bonusConsumption3.setPayments(payments);
        assertEquals(Boolean.TRUE, bonusConsumption3.getPartiallyReversible());
    }

    @Test
    public void testGetTotalPaymentsReturnsNull_whenServiceFeeIsNull() {
        BonusConsumption bonusConsumption = new BonusConsumption();

        BigDecimal result = bonusConsumption.getTotalPayments(null);

        assertNull(result);
    }

    @Test
    public void testGetTotalPaymentsReturnsResult_whenServiceFeeIsNotNullAndPaymentIsFound() {
        BonusConsumption bonusConsumption = new BonusConsumption();
        BonusConsumptionPayment payment = new BonusConsumptionPayment();
        ChargeConsolidate serviceFee = new ChargeConsolidate();
        payment.setServiceFee(serviceFee);
        payment.setPaidAmount(new BigDecimal(4));
        List<BonusConsumptionPayment> payments = Arrays.asList(new BonusConsumptionPayment[]{payment});
        bonusConsumption.setPayments(payments);

        BigDecimal result = bonusConsumption.getTotalPayments(serviceFee);

        assertNotNull(result);
        assertEquals(result, new BigDecimal(4));
    }

    @Test
    public void testGetTotalPaymentsReturnsNull_whenServiceFeeIsNotNullAndPaymentsAreNull() {
        BonusConsumption bonusConsumption = new BonusConsumption();
        bonusConsumption.setPayments(null);
        ChargeConsolidate serviceFee = new ChargeConsolidate();

        BigDecimal result = bonusConsumption.getTotalPayments(serviceFee);

        assertNull(result);
    }

}