package com.monsanto.brazilvaluecapture.seedsale.bonus.accrual.report.service;

import com.monsanto.brazilvaluecapture.core.grower.model.bean.Grower;
import com.monsanto.brazilvaluecapture.seedsale.bonus.accrual.report.dao.BonusAccrualReportDAOImpl;
import com.monsanto.brazilvaluecapture.seedsale.bonus.accrual.report.dto.BonusAccrualReportRequestDTO;
import com.monsanto.brazilvaluecapture.seedsale.bonus.accrual.report.dto.BonusAccrualReportResponseDTO;
import com.monsanto.brazilvaluecapture.seedsale.bonus.accrual.report.dto.BonusAccrualReportStatusType;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.math.BigDecimal;
import java.util.*;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

/**
 * Created by AMMUNO.
 */
public class BonusAccrualReportService_UT {

    private static final int LAST_HOUR = 23;
    private static final int LAST_MINUTES = 59;

    private BonusAccrualReportService bonusAccrualReportService;

    private BonusAccrualReportDAOImpl bonusAccrualDAO;

    @Before
    public void setUp(){
        bonusAccrualDAO = mock(BonusAccrualReportDAOImpl.class);
        bonusAccrualReportService = new BonusAccrualReportServiceImpl(bonusAccrualDAO);
    }


    private List<BonusAccrualReportResponseDTO> createCases() {

        ArrayList<BonusAccrualReportResponseDTO> result = new ArrayList<BonusAccrualReportResponseDTO>();

        Calendar calendar = GregorianCalendar.getInstance();

        Date today = setLasTimeToDate(calendar.getTime());

        result.add(createBonusAccrualResponse(today, BonusAccrualReportStatusType.GENERATED, "Grower1", "200", "250"));

        result.add(createBonusAccrualResponse(today, BonusAccrualReportStatusType.GENERATED, "Grower1", "300", "350"));

        result.add(createBonusAccrualResponse(today, BonusAccrualReportStatusType.CONSUMED, "Grower1", "100", "150"));

        result.add(createBonusAccrualResponse(today, BonusAccrualReportStatusType.CONSUMED, "Grower1", "100", "150"));

        result.add(createBonusAccrualResponse(today, BonusAccrualReportStatusType.CONSUMED, "Grower1", "100", "150"));

        calendar.add(Calendar.DAY_OF_MONTH, 1);

        Date tomorrow = setLasTimeToDate(calendar.getTime());

        result.add(createBonusAccrualResponse(tomorrow, BonusAccrualReportStatusType.CONSUMED, "Grower1", "100", "150"));

        result.add(createBonusAccrualResponse(today, BonusAccrualReportStatusType.CONSUMED, "Grower2", "110", "220"));

        result.add(createBonusAccrualResponse(today, BonusAccrualReportStatusType.CONSUMED, "Grower2", "110", "220"));

        result.add(createBonusAccrualResponse(today, BonusAccrualReportStatusType.CONSUMED, "Grower2", "110", "220"));

        result.add(createBonusAccrualResponse(today, BonusAccrualReportStatusType.EXPIRED, "Grower2", "110", "220"));

        result.add(createBonusAccrualResponse(today, BonusAccrualReportStatusType.EXPIRED, "Grower2", "110", "220"));

        result.add(createBonusAccrualResponse(today, BonusAccrualReportStatusType.EXPIRED, "Grower2", "110", "220"));


        return result;
    }

    private BonusAccrualReportResponseDTO createBonusAccrualResponse(Date today, BonusAccrualReportStatusType statusType,
                                            String growerName, String bonusValue, String bonusAccrualValue) {

        Grower growerMock1 = createGrower(growerName);

        BonusAccrualReportResponseDTO bonusAccrualReportResponseDTO1 = new BonusAccrualReportResponseDTO();

        bonusAccrualReportResponseDTO1.setGrower(growerMock1);
        bonusAccrualReportResponseDTO1.setCodeSourceForViewReport(statusType);
        bonusAccrualReportResponseDTO1.setExpirationDate(today);
        bonusAccrualReportResponseDTO1.setBonusValue(new BigDecimal(bonusValue));
        bonusAccrualReportResponseDTO1.setBonusAccrualValue(new BigDecimal(bonusAccrualValue));

        return bonusAccrualReportResponseDTO1;
    }


    @Test
    public void testFindBonusAccrualMonthlyReport_when (){

        List<BonusAccrualReportResponseDTO> response = createCases();

        BonusAccrualReportRequestDTO bonusAccrualReportRequestDTO = new BonusAccrualReportRequestDTO();

        when(bonusAccrualDAO.findBonusAccrualReportMonthly(bonusAccrualReportRequestDTO)).thenReturn(response);

        List<BonusAccrualReportResponseDTO> bonusAccrualMonthlyReport = bonusAccrualReportService.findBonusAccrualMonthlyReport(bonusAccrualReportRequestDTO);

        Assert.assertEquals(new BigDecimal(500), bonusAccrualMonthlyReport.get(0).getBonusValue());
        Assert.assertEquals(new BigDecimal(600), bonusAccrualMonthlyReport.get(0).getBonusAccrualValue());

        Assert.assertEquals(new BigDecimal(300), bonusAccrualMonthlyReport.get(1).getBonusValue());
        Assert.assertEquals(new BigDecimal(450), bonusAccrualMonthlyReport.get(1).getBonusAccrualValue());

        Assert.assertEquals(new BigDecimal(100), bonusAccrualMonthlyReport.get(2).getBonusValue());
        Assert.assertEquals(new BigDecimal(150), bonusAccrualMonthlyReport.get(2).getBonusAccrualValue());

        Assert.assertEquals(new BigDecimal(330), bonusAccrualMonthlyReport.get(3).getBonusValue());
        Assert.assertEquals(new BigDecimal(660), bonusAccrualMonthlyReport.get(3).getBonusAccrualValue());

        Assert.assertEquals(new BigDecimal(330), bonusAccrualMonthlyReport.get(4).getBonusValue());
        Assert.assertEquals(new BigDecimal(660), bonusAccrualMonthlyReport.get(4).getBonusAccrualValue());

        Assert.assertEquals(5, bonusAccrualMonthlyReport.size());
    }

    private Grower createGrower(String alias) {
        Grower growerMock1 = new Grower ();
        growerMock1.setAlias(alias);
        return growerMock1;
    }

    public Date setLasTimeToDate(Date date){

        if (date == null){
            return null;
        }

        java.util.Calendar calendar = GregorianCalendar.getInstance();

        calendar.setTime(date);

        calendar.set(java.util.Calendar.HOUR_OF_DAY, LAST_HOUR );
        calendar.set(java.util.Calendar.MINUTE, LAST_MINUTES);
        calendar.set(java.util.Calendar.SECOND, LAST_MINUTES);

        return calendar.getTime();
    }
}
