package com.monsanto.brazilvaluecapture.seedsale.comarketing.model.dao.impl;

import static org.mockito.Matchers.anyString;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.SessionFactory;
import org.hibernate.classic.Session;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

import com.monsanto.brazilvaluecapture.core.customer.model.bean.Customer;
import com.monsanto.brazilvaluecapture.seedsale.comarketing.model.bean.ComktInvoice;
import com.monsanto.brazilvaluecapture.seedsale.comarketing.model.dao.ComarketingDAO;
import com.monsanto.brazilvaluecapture.seedsale.cutoffTons.model.dao.CutoffTonsDAO;
import com.monsanto.brazilvaluecapture.seedsale.cutoffTons.model.dao.impl.CutoffTonsDAOImpl;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.CutOffTons;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.CutOffTons.EntityTypeEnum;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.CutOffTonsHeadOffice;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.CutOffTonsHeadOffice.HeadOfficeCutoffType;
import com.monsanto.brazilvaluecapture.seedsale.template.model.bean.SaleTemplate;

public class ComarketingDAOImpl_UT {
	
	private ComarketingDAO comarketingDao; 
	private Session session;
	private CutoffTonsDAO cuttOffTonsDAO;
	
	@Before
	public void setUp() throws Exception {
		SessionFactory sessionFactory = mock(SessionFactory.class);
		this.session = mock(Session.class);
		when(sessionFactory.getCurrentSession()).thenReturn(this.session);
		comarketingDao = new ComarketingDAOImpl(sessionFactory);
		cuttOffTonsDAO = new CutoffTonsDAOImpl(sessionFactory);
	}

	@Test
	public void test_save() {
        ComktInvoice comkt =  new ComktInvoice();
        comarketingDao.save(comkt);
        verify(this.session, times(1)).saveOrUpdate(comkt);
    }
	
	@Test
	public void test_saveComktHeadOfficeTonsAmount() {
        CutOffTonsHeadOffice tonsByHeadOffice = new CutOffTonsHeadOffice();
        tonsByHeadOffice.setEntityType(EntityTypeEnum.GROWER);
        tonsByHeadOffice.setEntityId(1L);
        SaleTemplate saleTemplate = new SaleTemplate();
        saleTemplate.setId(1L);
		tonsByHeadOffice.setSaleTemplate(saleTemplate );
		Query hqlQuery = Mockito.mock(Query.class);
		when(this.session.createQuery(anyString())).thenReturn(hqlQuery);
        cuttOffTonsDAO.save(tonsByHeadOffice);
        verify(this.session, times(1)).save(tonsByHeadOffice);
    }
	
	@Test
	public void test_getComarketingTonsLimit() {
        SaleTemplate st = new SaleTemplate();
        st.setId(1L);
        Customer cus = new Customer();
        cus.setId(1L);
        SQLQuery sqlQuery = Mockito.mock(SQLQuery.class);
		when(this.session.createSQLQuery(anyString())).thenReturn(sqlQuery);
		when(sqlQuery.addEntity(CutOffTons.class)).thenReturn(sqlQuery);
		when(sqlQuery.setLong(eq("saleTemplateId"), eq(st.getId()))).thenReturn(sqlQuery);
		when(sqlQuery.setLong(eq("customerId"), eq(cus.getId()))).thenReturn(sqlQuery);
		when(sqlQuery.setString(eq("entityType"),eq(EntityTypeEnum.HEAD_OFFICE.name()))).thenReturn(sqlQuery);
		cuttOffTonsDAO.getCutoffTonsHeadOffice(st,cus,HeadOfficeCutoffType.WithCutoff);
        verify(sqlQuery, times(1)).list();
    }

}
