/**
 * 
 */
package com.monsanto.brazilvaluecapture.seedsale.billing.parser.cancellation;

import com.monsanto.CountriesHolderInitializer;
import com.monsanto.brazilvaluecapture.core.account.model.bean.Account;
import com.monsanto.brazilvaluecapture.core.account.model.bean.Account.AccountType;
import com.monsanto.brazilvaluecapture.core.account.model.bean.ManualCreditTransactionType;
import com.monsanto.brazilvaluecapture.core.account.service.impl.AccountService;
import com.monsanto.brazilvaluecapture.core.base.SystemTestFixture;
import com.monsanto.brazilvaluecapture.core.foundation.service.BusinessException;
import com.monsanto.brazilvaluecapture.core.foundation.service.IndustrySystemOperationException;
import com.monsanto.brazilvaluecapture.core.foundation.test.AbstractServiceIntegrationTests;
import com.monsanto.brazilvaluecapture.core.io.ProcessorConfig;
import com.monsanto.brazilvaluecapture.core.io.ProcessorConfig.ProcessorConfigProperties;
import com.monsanto.brazilvaluecapture.core.regionalization.CountriesHolder;
import com.monsanto.brazilvaluecapture.core.user.AccessControlTestFixture;
import com.monsanto.brazilvaluecapture.core.user.model.bean.UserContext;
import com.monsanto.brazilvaluecapture.core.user.model.bean.UserDecorator;
import com.monsanto.brazilvaluecapture.core.user.service.UserService;
import com.monsanto.brazilvaluecapture.seedsale.billing.model.bean.Billing;
import com.monsanto.brazilvaluecapture.seedsale.billing.model.bean.BillingDTO;
import com.monsanto.brazilvaluecapture.seedsale.billing.model.dao.BillingFilter;
import com.monsanto.brazilvaluecapture.seedsale.billing.service.BillingConstraintViolationException;
import com.monsanto.brazilvaluecapture.seedsale.billing.service.BillingHelper;
import com.monsanto.brazilvaluecapture.seedsale.billing.service.impl.BillingIndexer;
import com.monsanto.brazilvaluecapture.seedsale.billing.service.parser.cancellation.CnabCancellationCsvImportedFile;
import com.monsanto.brazilvaluecapture.seedsale.billing.service.parser.cancellation.CnabCancellationCsvImportedLine;
import com.monsanto.brazilvaluecapture.seedsale.billing.service.parser.cancellation.CnabCancellationParser;
import com.monsanto.brazilvaluecapture.seedsale.billing.service.parser.cancellation.CnabCancellationProcessor;
import com.monsanto.brazilvaluecapture.seedsale.sale.SaleTestFixture;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.Sale;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.Sale.SaleTypeEnum;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.SaleItem;
import com.monsanto.brazilvaluecapture.seedsale.sale.service.SaleItemFactory;
import com.monsanto.brazilvaluecapture.seedsale.sale.service.SaleService;
import com.monsanto.brazilvaluecapture.seedsale.sale.service.SaleTestData;
import com.monsanto.brazilvaluecapture.seedsale.template.model.bean.SaleTemplateBillingMethodEnum;
import org.junit.*;
import org.springframework.beans.factory.annotation.Autowired;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import static org.mockito.Mockito.stub;

/**
 * @author andregc
 *
 */
public class CnabCancellationProcessor_AT extends AbstractServiceIntegrationTests {

	
	private CnabCancellationCsvImportedFile importedFile;
	private static BillingIndexer mockedBillingIndexer;
	private ProcessorConfig processorConfig;
	private Locale localeBR = new Locale("pt", "BR");

    @Autowired
    private CountriesHolder countriesHolder;

	@Autowired
	private CnabCancellationParser importParser;
	
	@Autowired
	private CnabCancellationProcessor importProcessor;
	
	@Autowired
	private SaleService saleService;
	
	private SaleItemFactory saleItemFactory;

    private SaleTestData saleFactory;
	
	@Autowired
	private UserService userServices;
	@Autowired
	private AccountService accountService;
	@BeforeClass
	public static void onlyOnce() throws BusinessException {
		mockedBillingIndexer = BillingHelper.createBillingIndexer();
		stub(mockedBillingIndexer.getSaleCode()).toReturn(BillingHelper.MOCKED_SALE_CODE);
		stub(mockedBillingIndexer.getBillingMethod()).toReturn(SaleTemplateBillingMethodEnum.ERP);
	}
	
	
	@Before
	public void init() {
		getSession().clear();
		systemTestFixture = new SystemTestFixture(this);
		saleTestFixture = new SaleTestFixture(this, systemTestFixture);
		accessControlTestFixture = new AccessControlTestFixture(this, systemTestFixture);
		
		importedFile = new CnabCancellationCsvImportedFile();

		UserDecorator loggedSuperUser = accessControlTestFixture.userAdminOfMonsantoBr;
        loggedSuperUser.setContextCompany(systemTestFixture.monsantoBr);
        loggedSuperUser.addCompany(systemTestFixture.monsantoBr);
		
        processorConfig = new ProcessorConfig();
        processorConfig.put(ProcessorConfigProperties.SELECTED_LOCALE, localeBR);
        processorConfig.put(ProcessorConfigProperties.LOGGED_USER, loggedSuperUser);

		saleItemFactory = SaleItemFactory.getInstance(systemTestFixture.matoGrossoDoSul, saleTestFixture.plantabilitiesSelector);
		createChargeConsolidateTypes();

         //Added for LASVC to return a country brazil
        CountriesHolderInitializer.initialize(countriesHolder);

        saleFactory = new SaleTestData(systemTestFixture.regionSaoPaulo2012);
	}

	@Test
	public void given_an_importedLine_without_transaction_number_when_process_file_then_should_throw_exception() {
		CnabCancellationCsvImportedLine importedLine = createImportedLine(1, null);
		
		prepareImportedFile(importedLine);
		importParser.proccessFile(importedFile);

		Assert.assertEquals("Should have one violation", 1, importedFile.countWarnings());
	}
	
	@Test
	public void given_a_duplicated_importedLine_when_process_file_then_duplicated_lines_should_be_one() {
		ArrayList<CnabCancellationCsvImportedLine> allEntities = new ArrayList<CnabCancellationCsvImportedLine>();
		
		CnabCancellationCsvImportedLine importedLine = createImportedLine(1, 123L);
		allEntities.add(importedLine);
		CnabCancellationCsvImportedLine importedLine2 = createImportedLine(1, 123L);
		allEntities.add(importedLine2);
		
		importedFile.setAllEntities(allEntities);
		
		importParser.proccessFile(importedFile);

		Assert.assertEquals("Should have one line duplicated", 1, importedFile.countDuplicatedLines());
	}

	@Test
	public void given_an_importedLine_with_userAdmin_of_another_company_when_process_file_then_should_throw_exception() throws BillingConstraintViolationException {
		createPaidBilletBilling(123L);
		
		CnabCancellationCsvImportedLine importedLine = createImportedLine(1, 123L);
		importedLine.setUser(accessControlTestFixture.userAdminOfMonsantoEua);
		
		prepareImportedFile(importedLine);
		importParser.proccessFile(importedFile);

		Assert.assertEquals("Should have one violation", 1, importedFile.countWarnings());
	}

	@Test
	public void given_an_importedLine_without_billing_when_process_file_then_should_throw_exception() {
		CnabCancellationCsvImportedLine importedLine = createImportedLine(1, 123L);
		
		prepareImportedFile(importedLine);
		importParser.proccessFile(importedFile);

		Assert.assertEquals("Should have one violation", 1, importedFile.countWarnings());
	}
	
	@Test
	public void given_an_importedLine_with_billing_not_paid_when_process_file_then_should_throw_exception() {
		Billing billing = BillingHelper.createBillingWithOneItemForManyDueDates(systemTestFixture, saleTestFixture, mockedBillingIndexer, SaleTestFixture.AUGUST);
		billing.setTransactionNumber(123L);
		saveAndFlush(billing);
		
		CnabCancellationCsvImportedLine importedLine = createImportedLine(1, 123L);
		
		prepareImportedFile(importedLine);
		importParser.proccessFile(importedFile);

		Assert.assertEquals("Should have one violation", 1, importedFile.countWarnings());
	}
	
	@Test
	public void given_an_importedLine_with_billing_manually_paid_when_process_file_then_should_throw_exception() throws BillingConstraintViolationException, IndustrySystemOperationException {
		Billing billing = BillingHelper.createBillingWithOneItemForManyDueDates(systemTestFixture, saleTestFixture, mockedBillingIndexer, SaleTestFixture.AUGUST);
		billing.setTransactionNumber(123L);
		saveAndFlush(billing);
		try {
                    saleService.payBilling(billing, SaleTestFixture.AUGUST, BigDecimal.TEN, true);
                } catch (BusinessException e) {
                    e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
                }
		
		CnabCancellationCsvImportedLine importedLine = createImportedLine(1, 123L);
		
		prepareImportedFile(importedLine);
		importParser.proccessFile(importedFile);

		Assert.assertEquals("Should have one violation", 1, importedFile.countWarnings());
	}
	
	@Test
	public void given_an_importedLine_with_billing_valid_when_process_file_then_should_be_success() throws BillingConstraintViolationException {
		createPaidBilletBilling(123L);
		
		CnabCancellationCsvImportedLine importedLine = createImportedLine(1, 123L);
		
		prepareImportedFile(importedLine);
		importParser.proccessFile(importedFile);

		Assert.assertEquals("Should not have violation", 0, importedFile.countWarnings());
	}
	
	@Test
	public void given_two_valid_lines_when_read_file_then_should_read_all_with_success() throws IOException, BusinessException {
		createPaidBilletBilling(123L);
		createPaidBilletBilling(124L);
		
		StringBuffer csvLine = createLineForInputStream(null, "123");
		csvLine = createLineForInputStream(csvLine, "124");
		CnabCancellationCsvImportedFile file = importProcessor.read(new ByteArrayInputStream(csvLine.toString().getBytes()), processorConfig);
		
		assertImportedFile(file, 0, 2, 2, 0, 0, 2);
	}
	
	@Test
	public void given_an_importedLine_with_billing_manually_paid_read_file_then_should_have_one_warning() throws IOException, BusinessException {
		Billing billing = BillingHelper.createBillingWithOneItemForManyDueDates(systemTestFixture, saleTestFixture, mockedBillingIndexer, SaleTestFixture.AUGUST);
		billing.setTransactionNumber(123L);
		saveAndFlush(billing);
		saleService.payBilling(billing, SaleTestFixture.AUGUST, BigDecimal.TEN, true);
		
		StringBuffer csvLine = createLineForInputStream(null, "123");
		CnabCancellationCsvImportedFile file = importProcessor.read(new ByteArrayInputStream(csvLine.toString().getBytes()), processorConfig);

		assertImportedFile(file, 0, 0, 0, 1, 0, 1);
	}
	
	@Test
	public void given_two_lines_with_one_duplicated_when_read_file_then_should_read_one_with_success_and_one_duplicated() throws IOException, BusinessException {
		createPaidBilletBilling(123L);
		
		StringBuffer csvLine = createLineForInputStream(null, "123");
		csvLine = createLineForInputStream(csvLine, "123");
		CnabCancellationCsvImportedFile file = importProcessor.read(new ByteArrayInputStream(csvLine.toString().getBytes()), processorConfig);
		
		assertImportedFile(file, 1, 1, 1, 0, 0, 2);
	}
	
	@Test
	public void given_a_file_with_invalid_layout_when_read_file_then_should_have_one_warning_line() throws IOException, BusinessException {
		StringBuffer csvLine = new StringBuffer(";;");
		CnabCancellationCsvImportedFile file = importProcessor.read(new ByteArrayInputStream(csvLine.toString().getBytes()), processorConfig);
		
		assertImportedFile(file, 0, 0, 0, 1, 0, 1);
	}
	
    @Test
    @Ignore
    public void given_a_file_with_3_lines_when_I_process_then_should_write_all_3_successfully() throws IOException, BusinessException {
    	Billing billing1 = createBillingWithSale(1L);
    	Billing billing2 = createBillingWithSale(2L);
    	Billing billing3 = createBillingWithSale(3L);

    	StringBuffer csvLine = createLineForInputStream(null, billing1.getTransactionNumber().toString());
    	csvLine = createLineForInputStream(csvLine, billing2.getTransactionNumber().toString());
    	csvLine = createLineForInputStream(csvLine, billing3.getTransactionNumber().toString());

		CnabCancellationCsvImportedFile file = importProcessor.read(new ByteArrayInputStream(csvLine.toString().getBytes()), processorConfig);
    	importProcessor.write(file, processorConfig);
    	
		assertImportedFile(file, 0, 3, 3, 0, 0, 3);
    }
    
	
    @Test
    @Ignore
    public void given_a_grower_without_credit_when_I_process_file_then_should_throw_insufficient_balance_exception() throws IOException, BusinessException {
    	Billing billing1 = createBillingWithSale(1L);
    	
    	Account accountAvailable = accountService.fetchOrCreateAccount(AccountType.AVAILABLE, saleTestFixture.chicoBento, saleTestFixture.productIntactaSoy.getCrop(), saleTestFixture.productIntactaSoy.getTechnology(), systemTestFixture.operationalYearOf2012);
		accountService.manageManualCredit(ManualCreditTransactionType.DEBIT, accountAvailable.getBalance(), saleTestFixture.chicoBento, saleTestFixture.productIntactaSoy.getCrop(), saleTestFixture.productIntactaSoy.getTechnology(), systemTestFixture.operationalYearOf2012, 1L);

    	StringBuffer csvLine = createLineForInputStream(null, billing1.getTransactionNumber().toString());

		CnabCancellationCsvImportedFile file = importProcessor.read(new ByteArrayInputStream(csvLine.toString().getBytes()), processorConfig);
    	importProcessor.write(file, processorConfig);
    	
		assertImportedFile(file, 0, 0, 1, 0, 1, 1);
    }

	private void assertImportedFile(CnabCancellationCsvImportedFile file,
			int duplicatedLines, int successLines, int detailLines, int warningLines, int errorLines, int totalLines) {
		
		Assert.assertNotNull("Result of read file should not be null", file);
		Assert.assertEquals("Number of duplicated lines is wrong", duplicatedLines, file.countDuplicatedLines());
		Assert.assertEquals("Number of success lines is wrong", successLines, file.countSuccess());
		Assert.assertEquals("Number of detail lines is wrong", detailLines, file.countDetailLines());
		Assert.assertEquals("Number of warnings is wrong", warningLines, file.countWarnings());
		Assert.assertEquals("Number of errors is wrong", errorLines, file.countErrors());
		Assert.assertEquals("Total # of lines is wrong", totalLines, file.countTotalLines());
	}


	private void createPaidBilletBilling(Long transactionNumber) throws BillingConstraintViolationException {
		Billing billing = BillingHelper.createBillingWithOneItemForManyDueDates(systemTestFixture, saleTestFixture, mockedBillingIndexer, SaleTestFixture.AUGUST);
		billing.setTransactionNumber(transactionNumber);
		saveAndFlush(billing);
		
		saleService.payBillingOfBillet(billing, SaleTestFixture.AUGUST, BigDecimal.TEN, BigDecimal.ONE, BigDecimal.ONE);
	}
	
	private Billing createBillingWithSale(Long transactionNumber)
			throws BusinessException, BillingConstraintViolationException {
		Sale sale = saleFactory.createSale(saleTestFixture.matrixCargil, saleTestFixture.chicoBento, SaleTypeEnum.SALE_SEED);
		sale.setState(systemTestFixture.matoGrossoDoSul);
		
		SaleItem saleItemFix = saleItemFactory
				.createFixValueItem(saleTestFixture.productIntactaSoy,
						saleTestFixture.templateIntactaFixRRRangeBtNoValue,
						saleTestFixture.headOfficeCargil, 2L);
		
		sale.addItem(saleItemFix);
		saveSaleForSuperUser(sale);
		
		UserDecorator loggedSuperUser = accessControlTestFixture.superUser;
		loggedSuperUser.setContextCrop(systemTestFixture.soy);
		
		BillingFilter billingFilter = BillingFilter.getInstance()
				.add(sale.getId())
				.add((UserContext)loggedSuperUser);
		
		List<BillingDTO> billingDTOList = saleService.getBillingsOfSale(billingFilter).getDecoratedBillings();
		
		Assert.assertEquals("Correct number of billing", 1, billingDTOList.size());
		
		Billing billing = billingDTOList.get(0).getBilling();
		billing.setTransactionNumber(transactionNumber);
		saveAndFlush(billing);
		
		saleService.payBillingOfBillet(billing,  SaleTestFixture.JANUARY, BigDecimal.TEN, BigDecimal.TEN, BigDecimal.TEN);
		return billing;
	}
	
	private Sale saveSaleForSuperUser(Sale sale) throws BusinessException {
		UserDecorator user = userServices.getAuthenticatedUserBy(accessControlTestFixture.itsSuperUser.getLogin());
		user.setContextCrop(systemTestFixture.soy);
		user.setContextCompany(systemTestFixture.monsantoBr);
		
		saleService.save(sale, user);
		return sale;
	}
	
	private CnabCancellationCsvImportedLine createImportedLine(Integer lineNumber, Long transactionNumber) {
		CnabCancellationCsvImportedLine importedLine = new CnabCancellationCsvImportedLine();
		importedLine.setLine(lineNumber);
		importedLine.setTransactionNumber(transactionNumber);
		importedLine.setUser(accessControlTestFixture.userAdminOfMonsantoBr);
		
		return importedLine;
	}

	private void prepareImportedFile(CnabCancellationCsvImportedLine importedLine) {
		ArrayList<CnabCancellationCsvImportedLine> allEntities = new ArrayList<CnabCancellationCsvImportedLine>();
		allEntities.add(importedLine);
		importedFile.setAllEntities(allEntities);
	}
	
	private StringBuffer createLineForInputStream(StringBuffer csv, String arg) {
        if(csv==null) {
            csv = new StringBuffer("N\u00FAmero boleto");
            csv.append("\n");
        }
        
        csv.append(arg==null?"":arg);
        csv.append("\n");
        
        return csv;
    }
}
