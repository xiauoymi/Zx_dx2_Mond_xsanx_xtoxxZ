package com.monsanto.brazilvaluecapture.seedsale.product;

import java.util.List;

import com.monsanto.CountriesHolderInitializer;
import com.monsanto.brazilvaluecapture.core.regionalization.CountriesHolder;
import com.monsanto.brazilvaluecapture.multiplier.cultivar.CultivarTestData;
import com.monsanto.brazilvaluecapture.multiplier.cultivar.model.bean.Cultivar;
import com.monsanto.brazilvaluecapture.multiplier.obtainer.ObtainerTestData;
import com.monsanto.brazilvaluecapture.multiplier.obtainer.model.bean.Obtainer;
import junit.framework.Assert;

import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.monsanto.brazilvaluecapture.core.base.SystemTestFixture;
import com.monsanto.brazilvaluecapture.core.foundation.model.bean.QuotaUsageEnum;
import com.monsanto.brazilvaluecapture.core.foundation.model.bean.SendValueRevenueEnum;
import com.monsanto.brazilvaluecapture.core.foundation.model.bean.StatusEnum;
import com.monsanto.brazilvaluecapture.core.foundation.service.BusinessException;
import com.monsanto.brazilvaluecapture.core.foundation.service.EntityNotFoundException;
import com.monsanto.brazilvaluecapture.core.foundation.test.AbstractServiceIntegrationTests;
import com.monsanto.brazilvaluecapture.seedsale.product.model.bean.Product;
import com.monsanto.brazilvaluecapture.seedsale.product.model.dao.ProductFilter;
import com.monsanto.brazilvaluecapture.seedsale.product.service.ProductService;

public class ProductService_AT extends AbstractServiceIntegrationTests{
	
	@Autowired
	private ProductService productService;

	private Product product;
	private String productDescription = "Product Description".toUpperCase();
	private Obtainer obtainer;

	private Cultivar cultivar;
    @Autowired
    private CountriesHolder countriesHolder;
	
	@Before
	public void init() {
        CountriesHolderInitializer.initialize(countriesHolder);
		systemTestFixture = new SystemTestFixture(this);
        obtainer = ObtainerTestData.createActiveObtainer("Obtainer Test", systemTestFixture.soy);
		saveAndFlush(obtainer);
        cultivar = getNewCultivar();

		product = ProductTestData.createProduct(systemTestFixture.monsoy, systemTestFixture.soy, systemTestFixture.intacta, StatusEnum.ACTIVE, systemTestFixture.monsantoBr);
		product.setDescription(productDescription);
        product.setCultivar(cultivar);
		saveAndFlush(product);

        cultivar.setProduct(product);
        saveAndFlush(cultivar);
	}
	
	@Test
	public void given_that_i_have_a_valid_productProductShouldBeSaved() throws BusinessException {
        Assert.assertNotNull(product.getId());
    }
	
	
	@Test
	public void given_that_i_have_a_product_SelectByIdShouldReturAProduct() throws BusinessException {
    	
    	Product productSelected = productService.selectById(product.getId());
    	
        Assert.assertNotNull(productSelected);
        Assert.assertNotNull(productSelected.getId());
        Assert.assertEquals(productSelected.getId(), product.getId());
        Assert.assertTrue(productSelected.getIsAllowChanges());
        Assert.assertEquals(productSelected.getDescription(), product.getDescription());
    }
	
	
	@Test
	public void given_that_i_have_product_not_associated_with_sale_template_ProductShoulBeDeleted() throws BusinessException {
    	
    	Product productCreated = ProductTestData.createProduct(this.systemTestFixture.monsoy, this.systemTestFixture.soy, this.systemTestFixture.intacta, StatusEnum.ACTIVE, this.systemTestFixture.monsantoBr);   	
    	Long id = productCreated.getId();
    	
    	productService.delete(productCreated);
    	
        Product productSelected = null;

        try {
            productSelected = productService.selectById(id);
        } catch (EntityNotFoundException e) {

        }
    	
        Assert.assertNull(productSelected);
    }
	
		
	@Test
	public void given_that_i_have_products_and_search_SelectByFilterShouldReturnAListOfProducts() throws BusinessException {
    	Product productCreated = ProductTestData.createProduct(this.systemTestFixture.monsoy, this.systemTestFixture.soy, this.systemTestFixture.intacta, StatusEnum.ACTIVE, this.systemTestFixture.monsantoBr);
    	saveAndFlush(productCreated);
    	
    	ProductFilter productFilter = ProductFilter.getInstance().add(this.systemTestFixture.monsantoBr).add(this.systemTestFixture.monsoy).add(this.systemTestFixture.intacta).add(this.systemTestFixture.soy).add(productCreated);
    	
		List<Product> products = productService.selectByFilter(productFilter);
        
        Assert.assertNotNull(products);
        Assert.assertFalse(products.isEmpty());
    }

	@Test
	public void given_a_product_without_quotaUsage_should_save_successfully() throws BusinessException {
		Product product = ProductTestData.createProduct(this.systemTestFixture.monsoy, this.systemTestFixture.soy, this.systemTestFixture.intacta, StatusEnum.ACTIVE, this.systemTestFixture.monsantoBr);
        product.setCultivar(getNewCultivar());

		productService.save(product);
		
		Assert.assertNotNull("Product id should not be null", product.getId());
		Assert.assertEquals("Product quota usage should be 0", QuotaUsageEnum.DONT_USE_QUOTA, product.getQuotaUsage());
	}

    private Cultivar getNewCultivar() {
        Cultivar cultivar = CultivarTestData.createActiveCultivar(this.systemTestFixture.soy, this.obtainer);
        saveAndFlush(cultivar);
        return cultivar;
    }

    @Test
	public void given_a_product_with_quotaUsage_and_sapCode_should_save_successfully() throws BusinessException {
		Product product = ProductTestData.createProduct(this.systemTestFixture.monsoy, this.systemTestFixture.soy, this.systemTestFixture.intacta, StatusEnum.ACTIVE, this.systemTestFixture.monsantoBr);
		product.setQuotaUsage(QuotaUsageEnum.USE_QUOTA);
		product.setProductSapCode("sap code");
        product.setCultivar(getNewCultivar());
		
		productService.save(product);
		
		Assert.assertEquals("Product quota usage should be 1", QuotaUsageEnum.USE_QUOTA, product.getQuotaUsage());
	}
	
	/**
	 * @param product the product to set
	 */
	public void setProduct(Product product) {
		this.product = product;
	}

	/**
	 * @return the product
	 */
	public Product getProduct() {
		return product;
	}
    
    @Test
    public void given_a_product_with_sendValueRevenue_should_save_successfully() throws BusinessException {
        Product product = ProductTestData.createProduct(this.systemTestFixture.monsoy, this.systemTestFixture.soy, this.systemTestFixture.intacta, StatusEnum.ACTIVE, this.systemTestFixture.monsantoBr);
        product.setSendValueRevenue(SendValueRevenueEnum.SEND_VALUE);
        product.setCultivar(getNewCultivar());
        
        productService.save(product);
        
        Assert.assertEquals("Product send value revenue should be 1", SendValueRevenueEnum.SEND_VALUE, product.getSendValueRevenue());
    }
    
	@Test
    public void given_a_product_without_sendValueRevenue_should_save_successfully() throws BusinessException {
        Product product = ProductTestData.createProduct(this.systemTestFixture.monsoy, this.systemTestFixture.soy, this.systemTestFixture.intacta, StatusEnum.ACTIVE, this.systemTestFixture.monsantoBr);
        product.setCultivar(getNewCultivar());

        productService.save(product);
        
        Assert.assertNotNull("Product id should not be null", product.getId());
        Assert.assertEquals("Product send value revenue should be 0", SendValueRevenueEnum.DONT_SEND_VALUE, product.getSendValueRevenue());
        
    }
	
	@Test
    public void given_that_i_have_products_and_search_SelectByFilterShouldReturnAListOfProductsWithSendValueRevenue() throws BusinessException {
	    Product productCreated = ProductTestData.createProduct(this.systemTestFixture.monsoy, this.systemTestFixture.soy, this.systemTestFixture.intacta, StatusEnum.ACTIVE, this.systemTestFixture.monsantoBr);
	    productCreated.setSendValueRevenue(SendValueRevenueEnum.SEND_VALUE);
        
        saveAndFlush(productCreated);
        
        ProductFilter productFilter = ProductFilter.getInstance().add(this.systemTestFixture.monsantoBr).add(this.systemTestFixture.monsoy).add(this.systemTestFixture.intacta).add(this.systemTestFixture.soy).add(productCreated);
        
        List<Product> products = productService.selectByFilter(productFilter);
        
        Assert.assertNotNull(products);
        Assert.assertFalse(products.isEmpty());
        Assert.assertEquals("Product send value revenue should be 1", SendValueRevenueEnum.SEND_VALUE, products.get(0).getSendValueRevenue());
    }

    @Test(expected = BusinessException.class)
	public void given_a_new_product_with_multiplierProduct_used_should_not_save() throws BusinessException {
		Product product = ProductTestData.createProduct(this.systemTestFixture.monsoy, this.systemTestFixture.soy, this.systemTestFixture.intacta, StatusEnum.ACTIVE, this.systemTestFixture.monsantoBr);
        product.setCultivar(cultivar);

        productService.save(product);

        Assert.assertNull("Product Id should be null", product.getId());
	}

    @Test
	public void given_a_new_product_without_multiplierProduct_should_not_throw_BusinessException() throws BusinessException {
		Product product = ProductTestData.createProduct(this.systemTestFixture.monsoy, this.systemTestFixture.soy, this.systemTestFixture.intacta, StatusEnum.ACTIVE, this.systemTestFixture.monsantoBr);

        productService.save(product);

        Assert.assertNotNull("Product Id should not be null", product.getId());
	}

    @Test
    public void given_a_saved_product_without_mp_should_not_fail_when_update() throws BusinessException{
        product = ProductTestData.createProduct(systemTestFixture.monsoy, systemTestFixture.soy, systemTestFixture.intacta, StatusEnum.ACTIVE, systemTestFixture.monsantoBr);
        saveAndFlush(product);

        productService.save(product);
    }

}
