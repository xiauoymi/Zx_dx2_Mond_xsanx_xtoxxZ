package com.monsanto.brazilvaluecapture.seedsale.cashAdvance.validation.rules;

import com.monsanto.brazilvaluecapture.core.base.model.bean.OperationalYear;
import com.monsanto.brazilvaluecapture.core.foundation.validation.ValidationException;
import com.monsanto.brazilvaluecapture.core.presentation.beans.ResourceBundleTestHelper;
import com.monsanto.brazilvaluecapture.seedsale.cashAdvance.model.bean.CashAdvanceTransaction;
import org.junit.Test;

import static org.fest.assertions.Fail.fail;
import static org.fest.assertions.Assertions.*;

public class CashAdvanceOperationalYearValidationRule_UT {
    @Test
    public void testValidateThrowsValidationException_WhenOperationalYearIsNull(){
        CashAdvanceOperationalYearValidationRule cashAdvanceOperationalYearValidationRule = new CashAdvanceOperationalYearValidationRule();
        final CashAdvanceTransaction cashAdvanceTransaction = new CashAdvanceTransaction();

        try {
            cashAdvanceOperationalYearValidationRule.validate(cashAdvanceTransaction);
            fail("Should Throw ValidationException");
        } catch (ValidationException e) {
            assertThat(e).hasMessage("cash.advance.message.operational.year.required");
        }
    }
    @Test
    public void testValidateDoesNotThrowsValidationException_WhenOperationalYearIsNotNull(){
        CashAdvanceOperationalYearValidationRule cashAdvanceOperationalYearValidationRule = new CashAdvanceOperationalYearValidationRule();
        final CashAdvanceTransaction cashAdvanceTransaction = new CashAdvanceTransaction();
        cashAdvanceTransaction.setOperationalYear(new OperationalYear("YEAR"));

        try {
            cashAdvanceOperationalYearValidationRule.validate(cashAdvanceTransaction);
        } catch (ValidationException e) {
            fail("Should Not Throw ValidationException");
        }
    }

    @Test
    public void testValidateWontthrowNullPointerException_WhenTargetIsNull() throws ValidationException {
        CashAdvanceOperationalYearValidationRule cashAdvanceOperationalYearValidationRule = new CashAdvanceOperationalYearValidationRule();

        try {
            cashAdvanceOperationalYearValidationRule.validate(null);
        } catch (NullPointerException e) {
            fail("Should not throw NullPointerException");
        }
    }

    private String[] messages = {"cash.advance.message.operational.year.required"};

    @Test
    public void testI18mMessages_Brazil() throws Exception {
        ResourceBundleTestHelper.assertLanguageStrExistsForBrazil(messages);
    }

    @Test
    public void testI18mMessages_English() throws Exception {
        ResourceBundleTestHelper.assertLanguageStrExistsForUS(messages);
    }
}