package com.monsanto.brazilvaluecapture.seedsale.bonus.accrual;

import com.google.common.base.Optional;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.monsanto.brazilvaluecapture.core.base.model.bean.OperationalYear;
import com.monsanto.brazilvaluecapture.core.foundation.service.BusinessException;
import com.monsanto.brazilvaluecapture.core.grower.model.bean.BonusExpiration;
import com.monsanto.brazilvaluecapture.core.grower.model.bean.BonusRules;
import com.monsanto.brazilvaluecapture.core.grower.model.bean.BonusRulesValue;
import com.monsanto.brazilvaluecapture.seedsale.bonus.accrual.model.bean.BonusAccrualTotalForAccounts;
import com.monsanto.brazilvaluecapture.seedsale.bonus.accrual.model.bean.BonusCalendarRule;
import com.monsanto.brazilvaluecapture.seedsale.bonus.accrual.model.dao.BonusAccrualDAO;
import com.monsanto.brazilvaluecapture.seedsale.bonus.accrual.model.dao.BonusCalendarRuleDAO;
import com.monsanto.brazilvaluecapture.seedsale.bonus.accrual.service.impl.BonusAccrualServiceImpl;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.math.BigDecimal;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static junit.framework.Assert.fail;
import static org.fest.assertions.Assertions.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.*;

public class BonusAccrualService_UT {

    @Mock
    private BonusAccrualDAO bonusAccrualDAO;
    @Mock
    private BonusCalendarRuleDAO bonusCalendarRuleDAO;

    @InjectMocks
    private BonusAccrualServiceImpl bonusAccrualService;

    private Map<Long, BigDecimal> map;

    @Before
    public void setup() {
        MockitoAnnotations.initMocks(this);

        //@Given
        when(bonusCalendarRuleDAO.findBonusCalendarRuleByJobDate(any(Date.class))).thenReturn(Optional.<BonusCalendarRule>absent());

        map = Maps.newHashMap();
        map.put(10l, BigDecimal.TEN);
        map.put(11l, BigDecimal.TEN);
        when(bonusAccrualDAO.findBonusTotal(null)).thenReturn(map);

    }

    @Test
    public void testCalculateTotalAccrualFindNoBonusCalendarRuleNoTransactions_whenCalculatingTotalBonusAccrual() {
        //@Given
        when(bonusCalendarRuleDAO.findBonusCalendarRuleByJobDate(any(Date.class))).thenReturn(Optional.<BonusCalendarRule>absent());
        Map<Long, BigDecimal> mapEmpty = Maps.newHashMap();
        when(bonusAccrualDAO.findBonusTotal(null)).thenReturn(mapEmpty);

        //@When
        try {
            bonusAccrualService.calculateTotalAccrual();
            fail("should have failed");
        } catch (Exception e) {
            assertThat(e.getMessage().compareTo("No bonus transactions were found."));
        }

        verify(bonusAccrualDAO).findBonusTotal(any(BonusCalendarRule.class));

    }

    @Test
    public void testCalculateTotalAccrualFindBonusCalendarRuleNoTransactions_whenCalculatingTotalBonusAccrual() {
        //@Given
        BonusCalendarRule bonusCalendarRule = new BonusCalendarRule();
        Optional<BonusCalendarRule> optBonusCalendarRule = Optional.of(new BonusCalendarRule());

        when(bonusCalendarRuleDAO.findBonusCalendarRuleByJobDate(any(Date.class))).thenReturn(optBonusCalendarRule);
        Map<Long, BigDecimal> mapEmpty = Maps.newHashMap();
        when(bonusAccrualDAO.findBonusTotal(bonusCalendarRule)).thenReturn(mapEmpty);

        //@When
        try {
            bonusAccrualService.calculateTotalAccrual();
            fail("should have failed");
        } catch (Exception e) {
            assertThat(e.getMessage().compareTo("No bonus transactions were found."));
        }

        verify(bonusCalendarRuleDAO).findBonusCalendarRuleByJobDate(any(Date.class));
        verify(bonusAccrualDAO).findBonusTotal(any(BonusCalendarRule.class));
    }

    @Test
    public void testCalculateTotalAccrualNoBonusRuleFound_WhenCalculatingTotalAccrual() throws BusinessException {
        //@Given
        BonusCalendarRule bonusCalendarRule = new BonusCalendarRule();
        Optional<BonusCalendarRule> optBonusCalendarRule = Optional.of(bonusCalendarRule);

        when(bonusCalendarRuleDAO.findBonusCalendarRuleByJobDate(any(Date.class))).thenReturn(optBonusCalendarRule);
        when(bonusAccrualDAO.findBonusTotal(bonusCalendarRule)).thenReturn(map);
        when(bonusAccrualDAO.findBonusRuleValueForBonusAccount(anyLong())).thenReturn(Optional.<BonusRulesValue>absent());

        //@when
        try {
            bonusAccrualService.calculateTotalAccrual();
            fail("Should have failed");
        } catch (BusinessException e) {
            assertThat(e.getMessage().compareTo("Bonus Accrual is 0, the job will not be posted."));
        }

        verify(bonusAccrualDAO, times(2)).findBonusRuleValueForBonusAccount(anyLong());
    }

    @Test
    public void testCalculateTotalAccrualZeroDivisionFailure_WhenCalculatingTotalAccrualWithBonusAmountInZero() throws BusinessException {
        //@Given

        BonusRulesValue brv = new BonusRulesValue();
        brv.setAccrualAmount(BigDecimal.TEN);
        brv.setBonusAmount(BigDecimal.ZERO);
        BonusRules br = new BonusRules();
        br.setOperationalYear(new OperationalYear());
        brv.setBonusRules(br);
        Optional<BonusRulesValue> optionalBrv = Optional.of(brv);
        when(bonusAccrualDAO.findBonusRuleValueForBonusAccount(anyLong())).thenReturn(optionalBrv);

        //@when
        try {
            bonusAccrualService.calculateTotalAccrual();
            fail("Should have failed");
        } catch (BusinessException e) {
            assertThat(e.getMessage().compareTo("Bonus Accrual is 0, the job will not be posted."));
        }

    }

    @Test
    public void testCalculateBonusAccraulReturnsZERO_WhenCalculatingBonusAccrual() {
        //@Given
        BonusRulesValue brv = new BonusRulesValue();
        brv.setAccrualAmount(BigDecimal.ZERO);
        brv.setBonusAmount(BigDecimal.TEN);
        BonusRules br = new BonusRules();
        br.setOperationalYear(new OperationalYear());
        brv.setBonusRules(br);
        Optional<BonusRulesValue> bonusRulesValueOptional = Optional.of(brv);
        when(bonusAccrualDAO.findBonusRuleValueForBonusAccount(anyLong())).thenReturn(bonusRulesValueOptional);
        //@when
        try {
            bonusAccrualService.calculateTotalAccrual();
        } catch (BusinessException e) {
            assertThat(e.getMessage().compareTo("Bonus Accrual is 0, the job will not be posted.") == 0);

        }

    }

    @Test
    public void testCalculateBonusAccraulReturnsTEN_WhenCalculatingBonusAccrual() {
        //@Given
        BonusRulesValue brv = new BonusRulesValue();
        brv.setAccrualAmount(BigDecimal.TEN);
        brv.setBonusAmount(BigDecimal.TEN);
        BonusRules br = new BonusRules();
        br.setOperationalYear(new OperationalYear());
        brv.setBonusRules(br);
        BonusAccrualTotalForAccounts accrualValue = new BonusAccrualTotalForAccounts(BigDecimal.ZERO, null, null);
        BigDecimal expectedValue = BigDecimal.ZERO;
        Optional<BonusRulesValue> bonusRulesValueOptional = Optional.of(brv);
        when(bonusAccrualDAO.findBonusRuleValueForBonusAccount(anyLong())).thenReturn(bonusRulesValueOptional);
        //@when
        try {
            accrualValue = bonusAccrualService.calculateTotalAccrual();
        } catch (BusinessException e) {
            assertThat(e.getMessage().compareTo("Bonus Accrual is 0, the job will not be posted.") == 0);
        }

        assertThat(accrualValue.getTotal().compareTo(expectedValue) == 0);

    }

    @Test
    public void testCalculateTotalReversalReturnsZERO_WhenCalculatingTotalReversalWithNoAplicableBonusExpirations() {
        //@given
        //BigDecimal expectedReturnValue = BigDecimal.ZERO;
        Map<Long, BigDecimal> expectedReturnValue = new HashMap<Long, BigDecimal>();
        expectedReturnValue.put(1l, BigDecimal.ZERO);
        List<BonusExpiration> bonusExpirations = Lists.newArrayList(new BonusExpiration());
        BonusRulesValue brv = new BonusRulesValue();
        brv.setAccrualAmount(BigDecimal.TEN);
        brv.setBonusAmount(BigDecimal.TEN);
        BonusRules br = new BonusRules();
        br.setOperationalYear(new OperationalYear());
        brv.setBonusRules(br);
        Optional<BonusRulesValue> bonusRulesValueOptional = Optional.of(brv);
        when(bonusAccrualDAO.findLatestBonusRuleValueForBonusAccount(anyLong())).thenReturn(bonusRulesValueOptional);
        when(bonusAccrualDAO.findBonusExpirationByDate(any(Date.class))).thenReturn(bonusExpirations);
        when(bonusAccrualDAO.findBonusTotalReversalByBonusExpiration(bonusExpirations)).thenReturn(expectedReturnValue);

        //@when
        try {
            bonusAccrualService.calculateTotalReversal();
            fail("Should have fail");
        } catch (BusinessException e) {
            assertThat(e).hasMessage("The Bonus Total Reversal is 0, the job will not be posted.");

        }

        verify(bonusAccrualDAO).findBonusExpirationByDate(any(Date.class));
        verify(bonusAccrualDAO).findBonusTotalReversalByBonusExpiration(bonusExpirations);

    }

    @Test
    public void testCalculateTotalReversalNoExpirationFound_WhenCalculatingTotalReversal() {
        //@given
        when(bonusAccrualDAO.findBonusExpirationByDate(any(Date.class))).thenReturn(anyListOf(BonusExpiration.class));

        //@when
        try {
            bonusAccrualService.calculateTotalReversal();
            fail("Should have fail");
        } catch (BusinessException e) {
            assertThat(e.getMessage().contains("No bonus expirations were found."));

        }

        verify(bonusAccrualDAO).findBonusExpirationByDate(any(Date.class));

    }

    @Test
    public void testCalculateTotalReversalReturnsTEN_WhenCalculatingTotalReversal() throws BusinessException {
        //@given
        BigDecimal expectedReturnValue = BigDecimal.TEN;
        Map<Long, BigDecimal> expectedReturnValuePerAccount = new HashMap<Long, BigDecimal>();
        expectedReturnValuePerAccount.put(1l, BigDecimal.TEN);
        BonusRulesValue brv = new BonusRulesValue();
        brv.setAccrualAmount(BigDecimal.TEN);
        brv.setBonusAmount(BigDecimal.TEN);
        BonusRules br = new BonusRules();
        br.setOperationalYear(new OperationalYear());
        brv.setBonusRules(br);
        Optional<BonusRulesValue> bonusRulesValueOptional = Optional.of(brv);
        List<BonusExpiration> bonusExpirations = Lists.newArrayList(new BonusExpiration());
        when(bonusAccrualDAO.findBonusExpirationByDate(any(Date.class))).thenReturn(bonusExpirations);
        when(bonusAccrualDAO.findBonusTotalReversalByBonusExpiration(bonusExpirations)).thenReturn(expectedReturnValuePerAccount);
        when(bonusAccrualDAO.findLatestBonusRuleValueForBonusAccount(anyLong())).thenReturn(bonusRulesValueOptional);

        //@when
        BigDecimal totalReversal = bonusAccrualService.calculateTotalReversal();

        assertThat(totalReversal.compareTo(expectedReturnValue) == 0);
        verify(bonusAccrualDAO).findBonusExpirationByDate(any(Date.class));
        verify(bonusAccrualDAO).findBonusTotalReversalByBonusExpiration(bonusExpirations);

    }

}
