package com.monsanto.brazilvaluecapture.seedsale.product;

import java.math.BigDecimal;
import java.util.List;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.monsanto.brazilvaluecapture.core.base.SystemTestFixture;
import com.monsanto.brazilvaluecapture.core.foundation.model.bean.StatusEnum;
import com.monsanto.brazilvaluecapture.core.foundation.service.BusinessException;
import com.monsanto.brazilvaluecapture.core.foundation.test.AbstractServiceIntegrationTests;
import com.monsanto.brazilvaluecapture.seedsale.harvest.HarvestTestData;
import com.monsanto.brazilvaluecapture.seedsale.harvest.model.bean.Harvest;
import com.monsanto.brazilvaluecapture.seedsale.harvest.model.bean.Plantability;
import com.monsanto.brazilvaluecapture.seedsale.product.model.bean.Product;
import com.monsanto.brazilvaluecapture.seedsale.product.model.bean.Productivity;
import com.monsanto.brazilvaluecapture.seedsale.product.model.bean.ProductivityValue;
import com.monsanto.brazilvaluecapture.seedsale.product.service.ProductivityService;
import com.monsanto.brazilvaluecapture.seedsale.product.service.ProductivityValueMaxLowerThanMinValueException;
import com.monsanto.brazilvaluecapture.seedsale.product.service.ProductivityValuesShouldNotEmptyException;
import com.monsanto.brazilvaluecapture.seedsale.product.service.ProductivityWithSaleTemplateUndeletableException;
import com.monsanto.brazilvaluecapture.seedsale.sale.SaleTestFixture;

public class ProductivityService_AT extends AbstractServiceIntegrationTests{

	@Autowired
	private ProductivityService productivityService;
	
	private Harvest harvest;
	
	private Plantability plantability;
	
	private Productivity productivityCreated;

    private Productivity productivityWithValue;
	
	private Product product;
	
	@Before
	public void init() {
		systemTestFixture = new SystemTestFixture(this);
		
		harvest = HarvestTestData.createHarvest(this.systemTestFixture.soy, this.systemTestFixture.operationalYearOf2011, systemTestFixture.monsantoBr);
		getSession().saveOrUpdate(harvest);
		
		plantability = PlantabilityTestData.createPlantability(harvest);
		getSession().saveOrUpdate(plantability);

    	product = ProductTestData.createProduct(this.systemTestFixture.monsoy, this.systemTestFixture.soy, this.systemTestFixture.intacta, StatusEnum.ACTIVE, this.systemTestFixture.monsantoBr);
    	getSession().saveOrUpdate(product);

		productivityCreated = ProductivityTestData.createProductivity(this.systemTestFixture.matoGrossoDoSul, plantability);
    	ProductivityTestData.addProductivityValue(productivityCreated, product);
        getSession().saveOrUpdate(productivityCreated);
		

    	
		getSession().flush();
	}
	
	@Test
	public void testSelectByAllFilter() throws BusinessException{
    	
		List<Productivity> productivities = productivityService
				.selectByFilter(ProductivityTestData.createProductivityDTO(
						harvest, this.systemTestFixture.matoGrossoDoSul, 
						plantability, productivityCreated.getDefaultProductivity()));
        
        Assert.assertNotNull(productivities);
        Assert.assertFalse(productivities.isEmpty());
		
	}

	@Test
	public void testSelectByHarvestFilter() throws BusinessException{
    	
		List<Productivity> productivities = productivityService
				.selectByFilter(ProductivityTestData.createProductivityDTO(
						harvest, null, 
						null, null));
        
        Assert.assertNotNull(productivities);
        Assert.assertFalse(productivities.isEmpty());
		
	}
	
	@Test
	public void testSelectByHarvestStateFilter() throws BusinessException{
    	
		List<Productivity> productivities = productivityService
				.selectByFilter(ProductivityTestData.createProductivityDTO(
						harvest, this.systemTestFixture.matoGrossoDoSul, 
						null, null));
        
        Assert.assertNotNull(productivities);
        Assert.assertFalse(productivities.isEmpty());
		
	}

	@Test
	public void testSelectByHarvestStatePlantabilityFilter() throws BusinessException{
    	
		List<Productivity> productivities = productivityService
				.selectByFilter(ProductivityTestData.createProductivityDTO(
						harvest, this.systemTestFixture.matoGrossoDoSul, 
						plantability, null));
        
        Assert.assertNotNull(productivities);
        Assert.assertFalse(productivities.isEmpty());
		
	}
	
	@Test
	public void testDelete() throws ProductivityWithSaleTemplateUndeletableException{
		Productivity productivity = ProductivityTestData.createProductivityValue(this.systemTestFixture.matoGrossoDoSul, plantability, product);
		getSession().saveOrUpdate(productivity);
		getSession().flush();
		
		Long id = productivity.getId();
		
		assertNotNullProductivity(productivity);
		
		productivityService.delete(productivity);
		
		Assert.assertNull(productivityService.selectById(id));
	}
	

	//PRODUCTION_FIX: CAV-1370 - should not be able to delete a productivity if it is used in a plantability that is used in a sale template
	@Test(expected=ProductivityWithSaleTemplateUndeletableException.class) 
	public void shold_not_delete_if_productivity_is_used_in_a_sale_tamplate() throws ProductivityWithSaleTemplateUndeletableException{
		
		saleTestFixture =  new SaleTestFixture(this, systemTestFixture);	
		
		productivityService.delete(saleTestFixture.productivityOfIntactaSoy2012NoSystem);
	}

	@Test(expected=ProductivityValuesShouldNotEmptyException.class)
	public void when_has_productivity_values_is_empty_ShouldRiseAProductivityValuesShouldNotEmpty() throws BusinessException{
		Productivity productivity = ProductivityTestData.createProductivity(this.systemTestFixture.matoGrossoDoSul, plantability);
		productivityService.save(productivity);
	}
	
	@Test(expected=ProductivityValueMaxLowerThanMinValueException.class)
	public void when_productivity_values_contains_max_value_lower_than_minor_value_ShouldRiseAProductivityValueMaxLowerThanMinValueException() throws BusinessException{
		Productivity productivity = ProductivityTestData.createProductivity(this.systemTestFixture.matoGrossoDoSul, plantability);
		ProductivityValue productivityValue = ProductivityTestData.addProductivityValue(productivity, product);
		productivityValue.setProductivityMin(productivityValue.getProductivityMax().add(BigDecimal.valueOf(1L)));
		productivityService.save(productivity);
	}
	
	@Test
    public void testGetFirstProductivityForHarvest() throws BusinessException {
        BigDecimal firstProductivityFound = productivityService.getFirstProductivityFor(harvest);
        Assert.assertNotNull(firstProductivityFound);
    }

	private void assertNotNullProductivity(Productivity productivity) {
		Assert.assertNotNull(productivity);
        Assert.assertNotNull(productivity.getId());
        Assert.assertFalse(productivity.getProductivityValues().isEmpty());
        Assert.assertNotNull(productivity.getProductivityValues().iterator().next().getId());
	}
	
}
