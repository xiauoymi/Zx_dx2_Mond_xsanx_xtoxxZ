package com.monsanto.brazilvaluecapture.seedsale.bonus.payment.impl;

import com.google.common.collect.Lists;
import com.monsanto.brazilvaluecapture.core.foundation.service.BusinessException;
import com.monsanto.brazilvaluecapture.core.grower.model.bean.BonusConsumptionPayment;
import com.monsanto.brazilvaluecapture.core.grower.model.bean.BonusConsumptionPaymentDetail;
import com.monsanto.brazilvaluecapture.seedsale.billing.model.bean.Billing;
import com.monsanto.brazilvaluecapture.seedsale.billing.model.bean.PaymentStatus;
import com.monsanto.brazilvaluecapture.seedsale.bonus.payment.SaleItemAvailableRoyaltiesConsumerAndCalculator;
import com.monsanto.brazilvaluecapture.seedsale.bonus.payment.SaleItemTotalRoyaltyValueCalculator;
import com.monsanto.brazilvaluecapture.seedsale.bonus.payment.SaleItemTotalRoyaltyValueCalculatorFactory;
import com.monsanto.brazilvaluecapture.seedsale.bonus.payment.exception.TotalRoyaltyValueCalculatorNotFoundException;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.Sale;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.SaleItem;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.dao.SaleDAO;
import org.junit.Test;

import java.math.BigDecimal;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;
import static org.mockito.Mockito.*;

public class SaleItemAvailableRoyaltiesConsumerAndCalculatorImpl_UT {

    private SaleDAO saleDAO = mock(SaleDAO.class);
    private SaleItemTotalRoyaltyValueCalculatorFactory calculatorFactory = mock(SaleItemTotalRoyaltyValueCalculatorFactory.class);
    private SaleItemAvailableRoyaltiesConsumerAndCalculator availableRoyaltiesCalculator = new SaleItemAvailableRoyaltiesConsumerAndCalculatorImpl(saleDAO, calculatorFactory);

    @Test
    public void testGetAvailableRoyaltiesForPaymentInvokesCalculateTotalRoyaltyValue_whenMethodIsInvoked() throws TotalRoyaltyValueCalculatorNotFoundException {
        //@Given
        SaleItem saleItem = buildMultiplierToGrowerSaleItem(BigDecimal.TEN, null, null);
        SaleItemTotalRoyaltyValueCalculator multiplierToGrowerCalculator = mock(MultiplierToGrowerSaleItemTotalRoyaltyValueCalculatorImpl.class);
        when(calculatorFactory.getCalculatorFor(saleItem)).thenReturn(multiplierToGrowerCalculator);
        when(multiplierToGrowerCalculator.calculateTotalRoyaltyValue(saleItem)).thenReturn(BigDecimal.ZERO);
        //@When
        availableRoyaltiesCalculator.getAvailableRoyaltiesForPayment(saleItem);
        //@Then
        verify(calculatorFactory).getCalculatorFor(saleItem);
        verify(multiplierToGrowerCalculator).calculateTotalRoyaltyValue(saleItem);
    }

    @Test
    public void testGetAvailableRoyaltiesForPaymentShouldReturn10_whenSaleItemIsMultiplierToGrowerAndHaveRevenueRecognition10() throws TotalRoyaltyValueCalculatorNotFoundException {
        //@Given
        SaleItem saleItem = buildMultiplierToGrowerSaleItem(BigDecimal.TEN, null, null);
        SaleItemTotalRoyaltyValueCalculator multiplierToGrowerCalculator = mock(MultiplierToGrowerSaleItemTotalRoyaltyValueCalculatorImpl.class);
        when(calculatorFactory.getCalculatorFor(saleItem)).thenReturn(multiplierToGrowerCalculator);
        when(multiplierToGrowerCalculator.calculateTotalRoyaltyValue(saleItem)).thenReturn(BigDecimal.TEN);
        //@When
        BigDecimal available = availableRoyaltiesCalculator.getAvailableRoyaltiesForPayment(saleItem);
        //@Then
        assertEquals(BigDecimal.TEN, available);
    }

    @Test
    public void testGetAvailableRoyaltiesForPaymentShouldReturn30_whenSaleItemIsMultiplierToGrowerAndHaveRevenueRecognition30() throws TotalRoyaltyValueCalculatorNotFoundException {
        //@Given
        SaleItem saleItem = buildMultiplierToGrowerSaleItem(BigDecimal.valueOf(30), null, null);
        SaleItemTotalRoyaltyValueCalculator multiplierToGrowerCalculator = mock(MultiplierToGrowerSaleItemTotalRoyaltyValueCalculatorImpl.class);
        when(calculatorFactory.getCalculatorFor(saleItem)).thenReturn(multiplierToGrowerCalculator);
        when(multiplierToGrowerCalculator.calculateTotalRoyaltyValue(saleItem)).thenReturn(BigDecimal.valueOf(30));
        //@When
        BigDecimal available = availableRoyaltiesCalculator.getAvailableRoyaltiesForPayment(saleItem);
        //@Then
        assertEquals(BigDecimal.valueOf(30), available);
    }

    @Test
    public void testGetAvailableRoyaltiesForPaymentShouldReturn10_whenSaleItemIsDealerToGrowerAndHaveRevenueRecognition10() throws TotalRoyaltyValueCalculatorNotFoundException {
        //@Given
        SaleItem saleItem = buildDealerToGrowerSaleItem(null, null);
        SaleItemTotalRoyaltyValueCalculator dealerToGrowerCalculator = mock(DealerToGrowerSaleItemTotalRoyaltyValueCalculatorImpl.class);
        when(calculatorFactory.getCalculatorFor(saleItem)).thenReturn(dealerToGrowerCalculator);
        when(dealerToGrowerCalculator.calculateTotalRoyaltyValue(saleItem)).thenReturn(BigDecimal.TEN);
        //@When
        BigDecimal available = availableRoyaltiesCalculator.getAvailableRoyaltiesForPayment(saleItem);
        //@Then
        assertEquals(BigDecimal.TEN, available);
    }

    @Test
    public void testConsumeRoyaltiesShouldUpdateTotalRoyaltySpendTo20_whenSaleItemAlreadyHaveTotalRoyaltySpend10AndConsume10More() throws BusinessException {
        //@Given
        SaleItem saleItem = buildMultiplierToGrowerSaleItem(BigDecimal.valueOf(30), BigDecimal.TEN, null);
        SaleItemTotalRoyaltyValueCalculator multiplierToGrowerCalculator = mock(MultiplierToGrowerSaleItemTotalRoyaltyValueCalculatorImpl.class);
        when(calculatorFactory.getCalculatorFor(saleItem)).thenReturn(multiplierToGrowerCalculator);
        when(multiplierToGrowerCalculator.calculateTotalRoyaltyValue(saleItem)).thenReturn(BigDecimal.valueOf(30));
        //@When
        BigDecimal amount = BigDecimal.TEN;
        availableRoyaltiesCalculator.consumeSaleItemRoyalties(saleItem, amount);
        //@Then
        assertEquals(BigDecimal.valueOf(20), saleItem.getSaleItemRoyaltiesSpent().getTotalRoyaltySpent());
    }

    @Test
    public void testConsumeRoyaltiesShouldUpdateTotalRoyaltySpendTo30_whenSaleItemAlreadyHaveTotalRoyaltySpend20AndConsume10More() throws BusinessException {
        //@Given
        SaleItem saleItem = buildMultiplierToGrowerSaleItem(BigDecimal.valueOf(30), BigDecimal.TEN, null);
        SaleItemTotalRoyaltyValueCalculator multiplierToGrowerCalculator = mock(MultiplierToGrowerSaleItemTotalRoyaltyValueCalculatorImpl.class);
        when(calculatorFactory.getCalculatorFor(saleItem)).thenReturn(multiplierToGrowerCalculator);
        when(multiplierToGrowerCalculator.calculateTotalRoyaltyValue(saleItem)).thenReturn(BigDecimal.valueOf(30));
        //@When
        BigDecimal amount = BigDecimal.valueOf(20);
        availableRoyaltiesCalculator.consumeSaleItemRoyalties(saleItem, amount);
        //@Then
        assertEquals(BigDecimal.valueOf(30), saleItem.getSaleItemRoyaltiesSpent().getTotalRoyaltySpent());
    }

    @Test
    public void testConsumeRoyaltiesShouldThrowBusinessException_whenSaleItemHaveTotalAvailableOf20AndConsume30More() throws TotalRoyaltyValueCalculatorNotFoundException {
        //@Given
        SaleItem saleItem = buildMultiplierToGrowerSaleItem(BigDecimal.valueOf(30), BigDecimal.TEN, null);
        SaleItemTotalRoyaltyValueCalculator multiplierToGrowerCalculator = mock(MultiplierToGrowerSaleItemTotalRoyaltyValueCalculatorImpl.class);
        when(calculatorFactory.getCalculatorFor(saleItem)).thenReturn(multiplierToGrowerCalculator);
        when(multiplierToGrowerCalculator.calculateTotalRoyaltyValue(saleItem)).thenReturn(BigDecimal.valueOf(30));
        //@When
        BigDecimal amount = BigDecimal.valueOf(30);
        try {
            availableRoyaltiesCalculator.consumeSaleItemRoyalties(saleItem, amount);
            fail("A BusinessException must be thrown because the amount to consume is greater than available amount");
        } catch (BusinessException e) {
            //@Then
            assertEquals("bonus.consumption.available.royalties.lower.than.amount", e.getMessage());
        }
    }

    @Test
    public void testConsumeRoyaltiesShouldNotCallUpdateSaleItem_whenConsumptionIs0() throws BusinessException {
        //@Given
        SaleItem saleItem = buildMultiplierToGrowerSaleItem(BigDecimal.valueOf(30), BigDecimal.TEN, null);
        SaleItemTotalRoyaltyValueCalculator multiplierToGrowerCalculator = mock(MultiplierToGrowerSaleItemTotalRoyaltyValueCalculatorImpl.class);
        when(calculatorFactory.getCalculatorFor(saleItem)).thenReturn(multiplierToGrowerCalculator);
        when(multiplierToGrowerCalculator.calculateTotalRoyaltyValue(saleItem)).thenReturn(BigDecimal.valueOf(30));
        //@When
        BigDecimal amount = BigDecimal.ZERO;
        availableRoyaltiesCalculator.consumeSaleItemRoyalties(saleItem, amount);
        //@Then
        verify(saleDAO, never()).updateSaleItem(saleItem);
    }

    @Test
    public void testConsumeRoyaltiesShouldThrowBusinessException_whenConsumptionIsLowerThan0() throws TotalRoyaltyValueCalculatorNotFoundException {
        //@Given
        SaleItem saleItem = buildMultiplierToGrowerSaleItem(BigDecimal.valueOf(30), BigDecimal.TEN, null);
        SaleItemTotalRoyaltyValueCalculator multiplierToGrowerCalculator = mock(MultiplierToGrowerSaleItemTotalRoyaltyValueCalculatorImpl.class);
        when(calculatorFactory.getCalculatorFor(saleItem)).thenReturn(multiplierToGrowerCalculator);
        when(multiplierToGrowerCalculator.calculateTotalRoyaltyValue(saleItem)).thenReturn(BigDecimal.valueOf(30));
        //@When
        BigDecimal amount = BigDecimal.valueOf(-1);
        try {
            availableRoyaltiesCalculator.consumeSaleItemRoyalties(saleItem, amount);
            fail("A BusinessException must be thrown because the amount to consume is lower than zero");
        } catch (BusinessException e) {
            //@Then
            assertEquals("bonus.consumption.amount.lower.than.zero", e.getMessage());
        }
    }

    @Test
    public void testConsumeRoyaltiesWithoutDoubleCheckShouldUpdateTotalRoyaltySpendTo20_whenSaleItemAlreadyHaveTotalRoyaltySpend10AndConsume10More() throws BusinessException {
        //@Given
        SaleItem saleItem = buildMultiplierToGrowerSaleItem(BigDecimal.valueOf(30), BigDecimal.TEN, null);
        SaleItemTotalRoyaltyValueCalculator multiplierToGrowerCalculator = mock(MultiplierToGrowerSaleItemTotalRoyaltyValueCalculatorImpl.class);
        when(calculatorFactory.getCalculatorFor(saleItem)).thenReturn(multiplierToGrowerCalculator);
        when(multiplierToGrowerCalculator.calculateTotalRoyaltyValue(saleItem)).thenReturn(BigDecimal.valueOf(30));
        //@When
        BigDecimal amount = BigDecimal.TEN;
        availableRoyaltiesCalculator.consumeSaleItemRoyaltiesWithoutDoubleCheck(saleItem, amount);
        //@Then
        assertEquals(BigDecimal.valueOf(20), saleItem.getSaleItemRoyaltiesSpent().getTotalRoyaltySpent());
    }

    @Test
    public void testConsumeRoyaltiesWithoutDoubleCheckShouldUpdateTotalRoyaltySpendTo30_whenSaleItemAlreadyHaveTotalRoyaltySpend20AndConsume10More() throws BusinessException {
        //@Given
        SaleItem saleItem = buildMultiplierToGrowerSaleItem(BigDecimal.valueOf(30), BigDecimal.TEN, null);
        SaleItemTotalRoyaltyValueCalculator multiplierToGrowerCalculator = mock(MultiplierToGrowerSaleItemTotalRoyaltyValueCalculatorImpl.class);
        when(calculatorFactory.getCalculatorFor(saleItem)).thenReturn(multiplierToGrowerCalculator);
        when(multiplierToGrowerCalculator.calculateTotalRoyaltyValue(saleItem)).thenReturn(BigDecimal.valueOf(30));
        //@When
        BigDecimal amount = BigDecimal.valueOf(20);
        availableRoyaltiesCalculator.consumeSaleItemRoyaltiesWithoutDoubleCheck(saleItem, amount);
        //@Then
        assertEquals(BigDecimal.valueOf(30), saleItem.getSaleItemRoyaltiesSpent().getTotalRoyaltySpent());
    }

    @Test
    public void testConsumeRoyaltiesWithoutDoubleCheckShouldNotCallUpdateSaleItem_whenConsumptionIs0() throws BusinessException {
        //@Given
        SaleItem saleItem = buildMultiplierToGrowerSaleItem(BigDecimal.valueOf(30), BigDecimal.TEN, null);
        SaleItemTotalRoyaltyValueCalculator multiplierToGrowerCalculator = mock(MultiplierToGrowerSaleItemTotalRoyaltyValueCalculatorImpl.class);
        when(calculatorFactory.getCalculatorFor(saleItem)).thenReturn(multiplierToGrowerCalculator);
        when(multiplierToGrowerCalculator.calculateTotalRoyaltyValue(saleItem)).thenReturn(BigDecimal.valueOf(30));
        //@When
        BigDecimal amount = BigDecimal.ZERO;
        availableRoyaltiesCalculator.consumeSaleItemRoyaltiesWithoutDoubleCheck(saleItem, amount);
        //@Then
        verify(saleDAO, never()).updateSaleItem(saleItem);
    }

    @Test
    public void testConsumeRoyaltiesWithoutDoubleCheckShouldThrowBusinessException_whenConsumptionIsLowerThan0() throws TotalRoyaltyValueCalculatorNotFoundException {
        //@Given
        SaleItem saleItem = buildMultiplierToGrowerSaleItem(BigDecimal.valueOf(30), BigDecimal.TEN, null);
        SaleItemTotalRoyaltyValueCalculator multiplierToGrowerCalculator = mock(MultiplierToGrowerSaleItemTotalRoyaltyValueCalculatorImpl.class);
        when(calculatorFactory.getCalculatorFor(saleItem)).thenReturn(multiplierToGrowerCalculator);
        when(multiplierToGrowerCalculator.calculateTotalRoyaltyValue(saleItem)).thenReturn(BigDecimal.valueOf(30));
        //@When
        BigDecimal amount = BigDecimal.valueOf(-1);
        try {
            availableRoyaltiesCalculator.consumeSaleItemRoyaltiesWithoutDoubleCheck(saleItem, amount);
            fail("A BusinessException must be thrown because the amount to consume is lower than zero");
        } catch (BusinessException e) {
            //@Then
            assertEquals("bonus.consumption.amount.lower.than.zero", e.getMessage());
        }
    }

    @Test
    public void testRevertSaleItemRoyaltySpentInBonusConsumptionPaymentForShouldCallUpdateSaleItem_whenThereIsOneSaleItemWithTotalSpent50AndTotalRoyalties50AndBonusConsumptionPaymentWithOneDetailWithPayment50() {
        //@Given
        SaleItem saleItem = buildMultiplierToGrowerSaleItem(BigDecimal.valueOf(50), BigDecimal.valueOf(50), null);
        BonusConsumptionPaymentDetail bonusConsumptionPaymentDetail = new BonusConsumptionPaymentDetail(saleItem, BigDecimal.valueOf(50));
        List<BonusConsumptionPaymentDetail> bonusConsumptionPaymentDetailList = Lists.newArrayList(bonusConsumptionPaymentDetail);
        BonusConsumptionPayment bonusConsumptionPayment = new BonusConsumptionPayment();
        bonusConsumptionPayment.setPaidAmount(BigDecimal.valueOf(50));
        bonusConsumptionPayment.setDetails(bonusConsumptionPaymentDetailList);
        //@When
        availableRoyaltiesCalculator.revertSaleItemRoyaltySpentInBonusConsumptionPaymentFor(bonusConsumptionPayment);
        //@Then
        verify(saleDAO).updateSaleItem(saleItem);
    }

    @Test
    public void testRevertSaleItemRoyaltySpentInBonusConsumptionPaymentForShouldNotCallUpdateSaleItem_whenThereIsOneBonusConsumptionPaymentWithNoDetails() {
        //@Given
        BonusConsumptionPayment bonusConsumptionPayment = new BonusConsumptionPayment();
        bonusConsumptionPayment.setDetails(Lists.<BonusConsumptionPaymentDetail>newArrayList());
        //@When
        availableRoyaltiesCalculator.revertSaleItemRoyaltySpentInBonusConsumptionPaymentFor(bonusConsumptionPayment);
        //@Then
        verify(saleDAO, never()).updateSaleItem(any(SaleItem.class));
    }

    @Test
    public void testRevertSaleItemRoyaltySpentInBonusConsumptionPaymentForShouldCallUpdateSaleItemTwice_whenThereIsTwoSaleItemsWithTotalSpent50AndTotalRoyalties50EachAndBonusConsumptionPaymentWithTwoDetailsWithPayment50Each() {
        //@Given
        SaleItem saleItem1 = buildMultiplierToGrowerSaleItem(BigDecimal.valueOf(50), BigDecimal.valueOf(50), 1L);
        SaleItem saleItem2 = buildMultiplierToGrowerSaleItem(BigDecimal.valueOf(50), BigDecimal.valueOf(50), 2L);
        BonusConsumptionPaymentDetail bonusConsumptionPaymentDetail1 = new BonusConsumptionPaymentDetail(saleItem1, BigDecimal.valueOf(50));
        BonusConsumptionPaymentDetail bonusConsumptionPaymentDetail2 = new BonusConsumptionPaymentDetail(saleItem2, BigDecimal.valueOf(50));
        List<BonusConsumptionPaymentDetail> bonusConsumptionPaymentDetailList = Lists.newArrayList(bonusConsumptionPaymentDetail1, bonusConsumptionPaymentDetail2);
        BonusConsumptionPayment bonusConsumptionPayment = new BonusConsumptionPayment();
        bonusConsumptionPayment.setPaidAmount(BigDecimal.valueOf(100));
        bonusConsumptionPayment.setDetails(bonusConsumptionPaymentDetailList);
        //@When
        availableRoyaltiesCalculator.revertSaleItemRoyaltySpentInBonusConsumptionPaymentFor(bonusConsumptionPayment);
        //@Then
        verify(saleDAO).updateSaleItem(saleItem1);
        verify(saleDAO).updateSaleItem(saleItem2);
    }

    @Test
    public void testRevertSaleItemRoyaltySpentInBonusConsumptionPaymentForShouldUpdateSaleItemTotalRoyaltySpentTo0_whenThereIsOneSaleItemWithTotalSpent50AndTotalRoyalties50AndBonusConsumptionPaymentWithOneDetailWithPayment50() {
        //@Given
        SaleItem saleItem = buildMultiplierToGrowerSaleItem(BigDecimal.valueOf(50), BigDecimal.valueOf(50), null);
        BonusConsumptionPaymentDetail bonusConsumptionPaymentDetail = new BonusConsumptionPaymentDetail(saleItem, BigDecimal.valueOf(50));
        List<BonusConsumptionPaymentDetail> bonusConsumptionPaymentDetailList = Lists.newArrayList(bonusConsumptionPaymentDetail);
        BonusConsumptionPayment bonusConsumptionPayment = new BonusConsumptionPayment();
        bonusConsumptionPayment.setPaidAmount(BigDecimal.valueOf(50));
        bonusConsumptionPayment.setDetails(bonusConsumptionPaymentDetailList);
        //@When
        availableRoyaltiesCalculator.revertSaleItemRoyaltySpentInBonusConsumptionPaymentFor(bonusConsumptionPayment);
        //@Then
        assertEquals(BigDecimal.ZERO, saleItem.getSaleItemRoyaltiesSpent().getTotalRoyaltySpent());
    }

    @Test
    public void testRevertSaleItemRoyaltySpentInBonusConsumptionPaymentForShouldUpdateSaleItemTotalRoyaltySpentTo30_whenThereIsOneSaleItemWithTotalSpent50AndTotalRoyalties50AndBonusConsumptionPaymentWithOneDetailWithPayment20() {
        //@Given
        SaleItem saleItem = buildMultiplierToGrowerSaleItem(BigDecimal.valueOf(50), BigDecimal.valueOf(50), null);
        BonusConsumptionPaymentDetail bonusConsumptionPaymentDetail = new BonusConsumptionPaymentDetail(saleItem, BigDecimal.valueOf(20));
        List<BonusConsumptionPaymentDetail> bonusConsumptionPaymentDetailList = Lists.newArrayList(bonusConsumptionPaymentDetail);
        BonusConsumptionPayment bonusConsumptionPayment = new BonusConsumptionPayment();
        bonusConsumptionPayment.setPaidAmount(BigDecimal.valueOf(50));
        bonusConsumptionPayment.setDetails(bonusConsumptionPaymentDetailList);
        //@When
        availableRoyaltiesCalculator.revertSaleItemRoyaltySpentInBonusConsumptionPaymentFor(bonusConsumptionPayment);
        //@Then
        assertEquals(BigDecimal.valueOf(30), saleItem.getSaleItemRoyaltiesSpent().getTotalRoyaltySpent());
    }

    public SaleItem buildMultiplierToGrowerSaleItem(BigDecimal royalties, BigDecimal royaltiesSpend, Long id) {
        Sale sale = new Sale();
        sale.setSaleType(Sale.SaleTypeEnum.MULTIPLIER_TO_GROWER_SEED_SALE);
        Billing billing = new Billing();
        billing.setPaymentStatus(PaymentStatus.FULLY_PAID);
        SaleItem saleItem = new SaleItem();
        saleItem.setId(id);
        saleItem.setTotalRoyaltyValue(royalties);
        saleItem.initializeRoyaltiesSpent();
        if (royaltiesSpend == null) {
            royaltiesSpend = BigDecimal.ZERO;
        }
        saleItem.getSaleItemRoyaltiesSpent().setTotalRoyaltySpent(royaltiesSpend);
        sale.addItem(saleItem);
        return saleItem;
    }

    public SaleItem buildDealerToGrowerSaleItem(BigDecimal royaltiesSpend, Long id) {
        Sale sale = new Sale();
        sale.setSaleType(Sale.SaleTypeEnum.SALE_SEED);
        Billing billing = new Billing();
        billing.setPaymentStatus(PaymentStatus.FULLY_PAID);
        SaleItem saleItem = new SaleItem();
        saleItem.setId(id);
        saleItem.initializeRoyaltiesSpent();
        if (royaltiesSpend == null) {
            royaltiesSpend = BigDecimal.ZERO;
        }
        saleItem.getSaleItemRoyaltiesSpent().setTotalRoyaltySpent(royaltiesSpend);
        sale.addItem(saleItem);
        return saleItem;
    }

}