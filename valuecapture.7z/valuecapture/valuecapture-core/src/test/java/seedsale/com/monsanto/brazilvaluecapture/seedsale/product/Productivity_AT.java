package com.monsanto.brazilvaluecapture.seedsale.product;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.hibernate.SessionFactory;
import org.hibernate.classic.Session;
import org.hibernate.exception.ConstraintViolationException;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;

import com.monsanto.brazilvaluecapture.core.base.SystemTestFixture;
import com.monsanto.brazilvaluecapture.core.base.TechnologyTestData;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Technology;
import com.monsanto.brazilvaluecapture.core.foundation.model.bean.StatusEnum;
import com.monsanto.brazilvaluecapture.core.foundation.test.AbstractServiceIntegrationTests;
import com.monsanto.brazilvaluecapture.seedsale.harvest.HarvestTestData;
import com.monsanto.brazilvaluecapture.seedsale.harvest.model.bean.Harvest;
import com.monsanto.brazilvaluecapture.seedsale.harvest.model.bean.Plantability;
import com.monsanto.brazilvaluecapture.seedsale.product.model.bean.Brand;
import com.monsanto.brazilvaluecapture.seedsale.product.model.bean.DefaultProductivity;
import com.monsanto.brazilvaluecapture.seedsale.product.model.bean.Product;
import com.monsanto.brazilvaluecapture.seedsale.product.model.bean.Productivity;
import com.monsanto.brazilvaluecapture.seedsale.product.model.bean.ProductivityDTO;
import com.monsanto.brazilvaluecapture.seedsale.product.model.bean.ProductivityValue;
import com.monsanto.brazilvaluecapture.seedsale.product.model.dao.ProductivityDAO;
import com.monsanto.brazilvaluecapture.seedsale.product.model.dao.impl.ProductivityDAOImpl;
import com.monsanto.brazilvaluecapture.seedsale.product.service.ProductivityAlreadyProductInProductvityValues;

public class Productivity_AT extends AbstractServiceIntegrationTests {

    @Autowired
    ProductivityDAO productivityDAO;

    private Harvest savedHarvest;

    private Productivity productivitySaved;

    private Product product;

    private Plantability plantability;

    private SessionFactory mockSessionFactory;

    private Session mockSession;

    private ProductivityDAO mockProductivityDAO;

    @Before
    public void init() {
        systemTestFixture = new SystemTestFixture(this);

        savedHarvest = HarvestTestData.createHarvest(this.systemTestFixture.soy,
                this.systemTestFixture.operationalYearOf2011, systemTestFixture.monsantoBr);
        getSession().saveOrUpdate(savedHarvest);

        plantability = PlantabilityTestData.createPlantability(savedHarvest);
        getSession().saveOrUpdate(plantability);

        product = ProductTestData.createProduct(this.systemTestFixture.monsoy, this.systemTestFixture.soy,
                this.systemTestFixture.intacta, StatusEnum.ACTIVE, this.systemTestFixture.monsantoBr);
        getSession().saveOrUpdate(product);

        productivitySaved = ProductivityTestData.createProductivityValue(this.systemTestFixture.matoGrossoDoSul,
                plantability, product);
        getSession().saveOrUpdate(productivitySaved);

        getSession().flush();

        mockSessionFactory = Mockito.mock(SessionFactory.class);
        mockSession = Mockito.mock(Session.class);
        mockProductivityDAO = new ProductivityDAOImpl(mockSessionFactory);
        Mockito.stub(mockSessionFactory.getCurrentSession()).toReturn(mockSession);

    }

    @Test
    public void testSelectedAllFilters() {

        ProductivityDTO dto = ProductivityTestData.createProductivityDTO(savedHarvest,
                this.systemTestFixture.matoGrossoDoSul, plantability, productivitySaved.getDefaultProductivity());

        List<Productivity> productivities = productivityDAO.selectByFilter(dto);

        assertNotNullProductivities(productivities);
    }

    @Test
    public void testSelectedByHarvest() {

        List<Productivity> productivities = productivityDAO.selectByFilter(ProductivityTestData.createProductivityDTO(
                savedHarvest, null, null, null));

        assertNotNullProductivities(productivities);

    }

    @Test
    public void testSelectedByHarvestState() {

        ProductivityDTO dto = ProductivityTestData.createProductivityDTO(savedHarvest,
                this.systemTestFixture.matoGrossoDoSul, null, null);

        List<Productivity> productivities = productivityDAO.selectByFilter(dto);

        assertNotNullProductivities(productivities);

    }

    @Test
    public void testSelectedByHarvestStatePlantibility() {

        ProductivityDTO dto = ProductivityTestData.createProductivityDTO(savedHarvest,
                this.systemTestFixture.matoGrossoDoSul, plantability, null);

        List<Productivity> productivities = productivityDAO.selectByFilter(dto);

        assertNotNullProductivities(productivities);

    }

    @Test
    public void testSelectedByDefaultProductivityALL() {

        ProductivityDTO dto = ProductivityTestData.createProductivityDTO(savedHarvest,
                this.systemTestFixture.matoGrossoDoSul, plantability, DefaultProductivity.ALL);

        List<Productivity> productivities = productivityDAO.selectByFilter(dto);

        assertNotNullProductivities(productivities);

    }

    @Test
    public void testInsert() {
        Productivity productivityCreated = ProductivityTestData.createProductivityValue(
                this.systemTestFixture.matoGrossoDoSul, plantability, product);
        getSession().saveOrUpdate(productivityCreated);
        getSession().flush();

        assertNotNullProductivity(productivityCreated);
    }

    @Test
    public void testUpdateDefaultProductivity() {
        Productivity productivityCreated = ProductivityTestData.createProductivityValue(
                this.systemTestFixture.matoGrossoDoSul, plantability, product);
        getSession().saveOrUpdate(productivityCreated);
        getSession().flush();

        List<Productivity> prodList = new ArrayList<Productivity>();
        prodList.add(productivityCreated);

        ProductivityDTO pDto = ProductivityTestData.createProductivityDTO(savedHarvest, null, null,
                DefaultProductivity.ALL);
        Productivity productivitySaved = productivityDAO.selectById(productivityCreated.getId());

        Assert.assertEquals(productivityCreated, productivitySaved);

        productivityCreated.setDefaultProductivity(DefaultProductivity.YES);
        try {
            productivityDAO.save(productivityCreated);
        } catch (ProductivityAlreadyProductInProductvityValues e) {
            Assert.fail();
        }

        pDto.setProductivity(productivityCreated);

        List<Productivity> productivities = productivityDAO.selectByFilter(pDto);

        Assert.assertNotSame(prodList, productivities.get(0));
    }

    @Test(expected = ConstraintViolationException.class)
    public void testUpdateDefaultProductivity_shouldThrow_ConstraintViolationException()
            throws ProductivityAlreadyProductInProductvityValues {
        ConstraintViolationException exception = new ConstraintViolationException("Exception", new SQLException(
                StringUtils.EMPTY), "FK");
        Mockito.doThrow(exception).when(mockSession).saveOrUpdate(Mockito.any());

        Productivity mockProductivity = Mockito.mock(Productivity.class);
        mockProductivityDAO.save(mockProductivity);

        Assert.fail();
    }

    @Test
    public void testDelete() {
        Productivity productivity = ProductivityTestData.createProductivityValue(
                this.systemTestFixture.matoGrossoDoSul, plantability, product);
        getSession().saveOrUpdate(productivity);
        getSession().flush();

        Long id = productivity.getId();

        assertNotNullProductivity(productivity);

        productivityDAO.delete(productivity);

        Assert.assertNull(productivityDAO.selectById(id));

    }

    @Test
    public void testInsertProductivityWithoutProductivityValue() {

        Productivity productivity = ProductivityTestData.createProductivityWithoutProductivityValue(savedHarvest,
                DefaultProductivity.YES);
        getSession().saveOrUpdate(productivity);

        Assert.assertNotNull(productivity.getProductivityValuesComplete(savedHarvest.getCrop()));

        for (ProductivityValue productivityValue : productivity.getProductivityValuesComplete(savedHarvest.getCrop())) {
            Assert.assertEquals(productivity.getId(), productivityValue.getProductivity().getId());
            Assert.assertEquals(productivity.getPlantability().getId(), productivityValue.getProductivity()
                    .getPlantability().getId());
            Assert.assertEquals(savedHarvest.getCrop().getProducts().iterator().next().getId(), productivityValue
                    .getProduct().getId());
            Assert.assertNull(productivityValue.getProductivityMax());
            Assert.assertNull(productivityValue.getProductivityMin());
        }
    }

    @Test
    public void testInsertProductivityWithProductivityValue() {

        Productivity productivity = ProductivityTestData.createProductivityWithProductivityValue(savedHarvest);
        getSession().saveOrUpdate(productivity);

        Assert.assertNotNull(productivity.getProductivityValuesComplete(savedHarvest.getCrop()));

        for (ProductivityValue productivityValue : productivity.getProductivityValuesComplete(savedHarvest.getCrop())) {
            Assert.assertEquals(productivity.getId(), productivityValue.getProductivity().getId());
            Assert.assertEquals(productivity.getPlantability().getId(), productivityValue.getProductivity()
                    .getPlantability().getId());
            Assert.assertEquals(savedHarvest.getCrop().getProducts().iterator().next().getId(), productivityValue
                    .getProduct().getId());
            Assert.assertNotNull(productivityValue.getProductivityMax());
            Assert.assertNotNull(productivityValue.getProductivityMin());
        }

    }

    @Test
    public void testInsertProductivityWithAndWithoutProductivityValue() {

        Productivity productivity = ProductivityTestData.createProductivityWithProductivityValue(savedHarvest);
        getSession().saveOrUpdate(productivity);

        Technology technology = TechnologyTestData.createTechnology(savedHarvest.getCrop().getCompany());
        Brand brand = BrandTestData.createBrand(savedHarvest.getCrop().getCompany());

        Product product = new Product("productBasic", StatusEnum.ACTIVE, savedHarvest.getCrop(), technology, brand,
                savedHarvest.getCrop().getCompany());

        // Testing Product Inative
        Product productInative = new Product("productBasicInative", StatusEnum.INACTIVE, savedHarvest.getCrop(),
                technology, brand, savedHarvest.getCrop().getCompany());

        savedHarvest.getCrop().addProduct(product);
        savedHarvest.getCrop().addProduct(productInative);

        List<ProductivityValue> productivityValues = productivity.getProductivityValuesComplete(savedHarvest.getCrop());

        Assert.assertNotNull(productivityValues);

        // verifying product inative
        for (ProductivityValue productivityValue : productivityValues) {
            if (productivityValue.getProduct().equals(productInative)) {
                Assert.fail();
            }
        }

        for (ProductivityValue productivityValue : productivityValues) {

            if (productivityValue.getId() != null) {
                Assert.assertEquals(productivity.getId(), productivityValue.getProductivity().getId());
                Assert.assertEquals(productivity.getPlantability().getId(), productivityValue.getProductivity()
                        .getPlantability().getId());
                Assert.assertNotNull(productivityValue.getProduct());
                Assert.assertNotNull(productivityValue.getProductivityMax());
                Assert.assertNotNull(productivityValue.getProductivityMin());
            } else {
                Assert.assertNull(productivityValue.getProductivityMax());
                Assert.assertNull(productivityValue.getProductivityMin());
            }
        }

    }

    // TODO verify
    // public void testDeleteProductivityValue(){
    // Productivity productivityCreated =
    // getCreateTestData().createFullProductivity(DefaultProductivity.YES);
    //
    // assertNotNullProductivity(productivityCreated);
    //
    // ProductivityValue productivityValue =
    // productivityCreated.getProductivityValues().iterator().next();
    //
    // productivityCreated.getProductivityValues().remove(productivityValue);
    //
    // productivityRepository.save(productivityCreated);
    //
    // Assert.assertTrue(productivityCreated.getProductivityValues().isEmpty());
    // }

    private void assertNotNullProductivity(Productivity productivityCreated) {
        Assert.assertNotNull(productivityCreated);
        Assert.assertNotNull(productivityCreated.getId());
        Assert.assertFalse(productivityCreated.getProductivityValues().isEmpty());
        Assert.assertNotNull(productivityCreated.getProductivityValues().iterator().next().getId());
    }

    private void assertNotNullProductivities(List<Productivity> productivities) {
        Assert.assertNotNull(productivities);
        Assert.assertFalse(productivities.isEmpty());
        Assert.assertTrue(productivities.size() == 1);
    }
}
