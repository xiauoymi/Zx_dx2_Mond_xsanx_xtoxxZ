package com.monsanto.brazilvaluecapture.core.quota.service.impl;

import com.monsanto.brazilvaluecapture.core.quota.model.dao.QuotaFYDAO;
import com.monsanto.brazilvaluecapture.core.quota.service.QuotaFYService;
import org.junit.Before;
import org.junit.Test;

import static org.fest.reflect.core.Reflection.field;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;

/**
 * User: PPERA
 * Date: 6/19/13
 * Time: 11:57 AM
 */
public class QuotaFYServiceImpl_UT {
    private QuotaFYService quotaFYServiceImpl;
    private QuotaFYDAO quotaFYDAO;

    @Before
    public void setUp(){
        this.quotaFYServiceImpl = new QuotaFYServiceImpl();
        this.quotaFYDAO = mock(QuotaFYDAO.class);
        field("quotaDAO").ofType(QuotaFYDAO.class).in(this.quotaFYServiceImpl).set(this.quotaFYDAO);
    }

    @Test
    public void testGetQuotaFYCallsQuotaFyDAOWithGermoSupplierJohn_WhenGettingTheQuotaFYsForGermoSupplierJohn() {
        // @Given a germo supplier "John"
        String germoSupplier = "John";
        String growerDocument = null;
        String countryCD = null;

        // @When getting his quotafys
        this.quotaFYServiceImpl.getQuotaFY(germoSupplier, growerDocument, countryCD);

        //@ Then quotafyDAO.getQuotaFy is called with germo supplier John
        verify(this.quotaFYDAO).findQuotaFY(germoSupplier, growerDocument, countryCD);
    }

    @Test
    public void testGetQuotaFYCallsQuotaFyDAOWithGermoSupplierMary_WhenGettingTheQuotaFYsForGermoSupplierMary() {
        // @Given a germo supplier "Mary"
        String germoSupplier = "Mary";
        String growerDocument = null;
        String countryCD = null;

        // @When getting his quotafys
        this.quotaFYServiceImpl.getQuotaFY(germoSupplier, growerDocument, countryCD);

        //@ Then quotafyDAO.getQuotaFy is called with germo supplier John
        verify(this.quotaFYDAO).findQuotaFY(germoSupplier, growerDocument, countryCD);
    }
}
