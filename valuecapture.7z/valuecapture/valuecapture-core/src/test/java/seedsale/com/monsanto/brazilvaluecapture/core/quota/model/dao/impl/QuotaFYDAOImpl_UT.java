package com.monsanto.brazilvaluecapture.core.quota.model.dao.impl;

import com.monsanto.brazilvaluecapture.core.quota.model.bean.QuotaFY;
import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.hibernate.classic.Session;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Restrictions;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentMatcher;
import org.mockito.Matchers;

import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.*;

/**
 * User: PPERA
 * Date: 6/19/13
 * Time: 11:10 AM
 */
public class QuotaFYDAOImpl_UT {
    private QuotaFYDAOImpl quotaFYDAOImpl;
    private SessionFactory sessionFactory;
    private Session session;
    private Query query;
    private Criteria criteria;

    @Before
    public void setUp() {
        SessionFactory sessionFactory = mock(SessionFactory.class);
        this.session = mock(Session.class);
        when(sessionFactory.getCurrentSession()).thenReturn(this.session);
        this.criteria = mock(Criteria.class);
        when(this.session.createCriteria(QuotaFY.class, "q")).thenReturn(this.criteria);
        when(this.criteria.createCriteria(anyString(), anyString())).thenReturn(this.criteria);
        when(this.criteria.add(Matchers.<Criterion>any())).thenReturn(this.criteria);
        this.quotaFYDAOImpl = new QuotaFYDAOImpl(sessionFactory);
    }

    @Test
    public void testFindQuotaFYCreatesACriteriaWithQuotaFyAndBillingAddressCountryAndGermoSupplierLocationCountryAndGermoSupplier_WhenFindingQuotaFYs() {
        // @Given a country code "AR"
        String countryCode = null;
        String germoSupplier = null;
        String growerDocument = null;

        // @When finding quotaFys
        this.quotaFYDAOImpl.findQuotaFY(germoSupplier, growerDocument, countryCode);

        // @Then a criteria is created with grower, grower country, germo supplier location country and germo supplier
        verify(this.criteria).createCriteria("q.grower", "g");
        verify(this.criteria).createCriteria("g.billingAddress.country", "gc");
        verify(this.criteria).createCriteria("q.germoSupplierLocation", "gsl");
        verify(this.criteria).createCriteria("gsl.germoSupplier", "gs");
        verify(this.criteria).createCriteria("gsl.country", "gslc");
    }

    @Test
    public void testFindQuotaFYAddsRestrictionForGrowerBillingAddressCountryCodeAR_WhenFindingQuotaFYsWithCountryCodeAR() {
        // @Given a country code "AR"
        String countryCode = "AR";
        String germoSupplier = null;
        String growerDocument = null;

        // @When finding quotaFys
        this.quotaFYDAOImpl.findQuotaFY(germoSupplier, growerDocument, countryCode);

        // @Then a criteria is created and a restriction for billing address country code is added
        verify(this.criteria).add(argThat(new ArgumentMatcher<Criterion>() {
            @Override
            public boolean matches(Object o) {
                return "gc.code=AR".equals(o.toString());
            }
        }));
    }

    @Test
    public void testFindQuotaFYAddsRestrictionForGermoSupplierLocationCountryCodeAR_WhenFindingQuotaFYsWithCountryCodeAR() {
        // @Given a country code "AR"
        String countryCode = "AR";
        String germoSupplier = null;
        String growerDocument = null;

        // @When finding quotaFys
        this.quotaFYDAOImpl.findQuotaFY(germoSupplier, growerDocument, countryCode);

        // @Then a criteria is created and a restriction for germo supplier location country is added
        verify(this.criteria).add(argThat(new ArgumentMatcher<Criterion>() {
            @Override
            public boolean matches(Object o) {
                return "gslc.code=AR".equals(o.toString());
            }
        }));
    }

    @Test
    public void testFindQuotaFYAddsRestrictionForGrowerBillingAddressCountryCodePY_WhenFindingQuotaFYsWithCountryCodePY() {
        // @Given a country code "PY"
        String countryCode = "PY";
        String germoSupplier = null;
        String growerDocument = null;

        // @When finding quotaFys
        this.quotaFYDAOImpl.findQuotaFY(germoSupplier, growerDocument, countryCode);

        // @Then a criteria is created and a restriction for billing address country code is added
        verify(this.criteria).add(argThat(new ArgumentMatcher<Criterion>() {
            @Override
            public boolean matches(Object o) {
                return "gc.code=PY".equals(o.toString());
            }
        }));
    }

    @Test
    public void testFindQuotaFYAddsRestrictionForGermoSupplierLocationCountryCodePY_WhenFindingQuotaFYsWithCountryCodePY() {
        // @Given a country code "PY"
        String countryCode = "PY";
        String germoSupplier = null;
        String growerDocument = null;

        // @When finding quotaFys
        this.quotaFYDAOImpl.findQuotaFY(germoSupplier, growerDocument, countryCode);

        // @Then a criteria is created and a restriction for germo supplier location country is added
        verify(this.criteria).add(argThat(new ArgumentMatcher<Criterion>() {
            @Override
            public boolean matches(Object o) {
                return "gslc.code=PY".equals(o.toString());
            }
        }));
    }

    @Test
    public void testFindQuotaFYAddsRestrictionForGermoSupplierNameJohn_WhenFindingQuotaFYsWithGermoSupplierJohn() {
        // @Given a country code "AR"
        String countryCode = "dummy";
        String germoSupplier = "John";
        String growerDocument = null;

        // @When finding quotaFys
        this.quotaFYDAOImpl.findQuotaFY(germoSupplier, growerDocument, countryCode);

        // @Then a criteria is created and a restriction for billing address country code is added
        verify(this.criteria).add(argThat(new ArgumentMatcher<Criterion>() {
            @Override
            public boolean matches(Object o) {
                return "gs.name=John".equals(o.toString());
            }
        }));
    }

    @Test
    public void testFindQuotaFYAddsRestrictionForGermoSupplierNameTony_WhenFindingQuotaFYsWithGermoSupplierTony() {
        // @Given a country code "AR"
        String countryCode = "dummy";
        String germoSupplier = "Tony";
        String growerDocument = null;

        // @When finding quotaFys
        this.quotaFYDAOImpl.findQuotaFY(germoSupplier, growerDocument, countryCode);

        // @Then a criteria is created and a restriction for billing address country code is added
        verify(this.criteria).add(argThat(new ArgumentMatcher<Criterion>() {
            @Override
            public boolean matches(Object o) {
                return "gs.name=Tony".equals(o.toString());
            }
        }));
    }

    @Test
    public void testFindQuotaFYDoesNotAddsRestrictionForGermoSupplierName_WhenFindingQuotaFYsWithGermoSupplierNull() {
        // @Given a country code "AR"
        String countryCode = "dummy";
        String germoSupplier = null;
        String growerDocument = null;

        // @When finding quotaFys
        this.quotaFYDAOImpl.findQuotaFY(germoSupplier, growerDocument, countryCode);

        // @Then a criteria is created and a restriction for billing address country code is added
        verify(this.criteria, times(0)).add(argThat(new ArgumentMatcher<Criterion>() {
            @Override
            public boolean matches(Object o) {
                return o.toString().startsWith("gs.name");
            }
        }));
    }

    @Test
    public void testFindQuotaFYDoesNotAddsRestrictionForGrowerDocument_WhenFindingQuotaFYsWithGrowerDocumentNull() {
        // @Given a country code "AR"
        String countryCode = "dummy";
        String germoSupplier = null;
        String growerDocument = null;

        // @When finding quotaFys
        this.quotaFYDAOImpl.findQuotaFY(germoSupplier, growerDocument, countryCode);

        // @Then a criteria is created and a restriction for billing address country code is added
        verify(this.criteria, times(0)).add(argThat(new ArgumentMatcher<Criterion>() {
            @Override
            public boolean matches(Object o) {
                return o.toString().startsWith("g.document.value");
            }
        }));
    }

    @Test
    public void testFindQuotaFYDoesNotAddsRestrictionForGermoSupplierName_WhenFindingQuotaFYsWithGermoSupplierEmpty() {
        // @Given a country code "AR"
        String countryCode = "dummy";
        String germoSupplier = "";
        String growerDocument = null;

        // @When finding quotaFys
        this.quotaFYDAOImpl.findQuotaFY(germoSupplier, growerDocument, countryCode);

        // @Then a criteria is created and a restriction for billing address country code is added
        verify(this.criteria, times(0)).add(argThat(new ArgumentMatcher<Criterion>() {
            @Override
            public boolean matches(Object o) {
                return o.toString().startsWith("gs.name");
            }
        }));
    }

    @Test
    public void testFindQuotaFYDoesNotAddsRestrictionForGrowerDocument_WhenFindingQuotaFYsWithGrowerDocumentEmpty() {
        // @Given a country code "AR"
        String countryCode = "dummy";
        String germoSupplier = null;
        String growerDocument = "";

        // @When finding quotaFys
        this.quotaFYDAOImpl.findQuotaFY(germoSupplier, growerDocument, countryCode);

        // @Then a criteria is created and a restriction for billing address country code is added
        verify(this.criteria, times(0)).add(argThat(new ArgumentMatcher<Criterion>() {
            @Override
            public boolean matches(Object o) {
                return o.toString().startsWith("g.document.value");
            }
        }));
    }

    @Test
    public void testFindQuotaFYAddsRestrictionForGrowerDocumentTony_WhenFindingQuotaFYsWithGrowerDocumentTony() {
        // @Given a country code "AR"
        String countryCode = "dummy";
        String germoSupplier = null;
        String growerDocument = "Tony";

        // @When finding quotaFys
        this.quotaFYDAOImpl.findQuotaFY(germoSupplier, growerDocument, countryCode);

        // @Then a criteria is created and a restriction for billing address country code is added
        verify(this.criteria).add(argThat(new ArgumentMatcher<Criterion>() {
            @Override
            public boolean matches(Object o) {
                return "g.document.value=Tony".equals(o.toString());
            }
        }));
    }

    @Test
    public void testFindQuotaFYAddsRestrictionForGrowerDocumentJohn_WhenFindingQuotaFYsWithGrowerDocumentJohn() {
        // @Given a country code "AR"
        String countryCode = "dummy";
        String germoSupplier = null;
        String growerDocument = "John";

        // @When finding quotaFys
        this.quotaFYDAOImpl.findQuotaFY(germoSupplier, growerDocument, countryCode);

        // @Then a criteria is created and a restriction for billing address country code is added
        verify(this.criteria).add(argThat(new ArgumentMatcher<Criterion>() {
            @Override
            public boolean matches(Object o) {
                return "g.document.value=John".equals(o.toString());
            }
        }));
    }
}
