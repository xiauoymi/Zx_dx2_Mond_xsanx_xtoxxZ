package com.monsanto.brazilvaluecapture.seedsale.product;

import com.monsanto.brazilvaluecapture.core.foundation.RandomTestData;
import com.monsanto.brazilvaluecapture.core.foundation.model.bean.StatusEnum;
import com.monsanto.brazilvaluecapture.seedsale.harvest.model.bean.Harvest;
import com.monsanto.brazilvaluecapture.seedsale.harvest.model.bean.Plantability;
import com.monsanto.brazilvaluecapture.seedsale.harvest.model.bean.PlantabilitySystemEnum;

public class PlantabilityTestData {

	/**
	 * Create a new Plantability by Harvest.
	 * @param harvest
	 * @return Plantability
	 */
	public static Plantability createPlantability(Harvest harvest) {
		String description = RandomTestData.createRandomString(10);
		Plantability plantability = createPlantability(harvest, description, StatusEnum.ACTIVE);
		return plantability;
	}

	/**
	 * Create a new Plantability by parameters informed
	 * @param harvest
	 * @param description
	 * @param status
	 * @return Plantability
	 */
	public static Plantability createPlantability(Harvest harvest, String description, StatusEnum status) {
		Plantability plantability = new Plantability(harvest, description, status, PlantabilitySystemEnum.NO);
		harvest.addPlantability(plantability);
		return plantability;
	}

}
