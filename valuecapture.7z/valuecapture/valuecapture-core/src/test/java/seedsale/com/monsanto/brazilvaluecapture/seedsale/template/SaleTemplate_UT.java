package com.monsanto.brazilvaluecapture.seedsale.template;

import com.monsanto.brazilvaluecapture.core.base.CountryTestData;
import com.monsanto.brazilvaluecapture.core.base.CropTestData;
import com.monsanto.brazilvaluecapture.core.base.SystemTestFixture;
import com.monsanto.brazilvaluecapture.core.base.TechnologyTestData;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Company;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Country;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Crop;
import com.monsanto.brazilvaluecapture.core.base.model.bean.OperationalYear;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Technology;
import com.monsanto.brazilvaluecapture.core.foundation.model.bean.StatusEnum;
import com.monsanto.brazilvaluecapture.core.foundation.service.BusinessException;
import com.monsanto.brazilvaluecapture.core.grower.CreateTestData;
import com.monsanto.brazilvaluecapture.seedsale.billing.model.bean.PossiblePayment;
import com.monsanto.brazilvaluecapture.seedsale.harvest.HarvestTestData;
import com.monsanto.brazilvaluecapture.seedsale.harvest.model.bean.Harvest;
import com.monsanto.brazilvaluecapture.seedsale.product.BrandTestData;
import com.monsanto.brazilvaluecapture.seedsale.product.ProductTestData;
import com.monsanto.brazilvaluecapture.seedsale.product.model.bean.Brand;
import com.monsanto.brazilvaluecapture.seedsale.product.model.bean.Product;
import com.monsanto.brazilvaluecapture.seedsale.sale.SaleTestFixture;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.Sale.SaleTypeEnum;
import com.monsanto.brazilvaluecapture.seedsale.template.model.bean.*;
import com.monsanto.brazilvaluecapture.seedsale.template.model.bean.Price.PriceTypeEnum;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import java.util.Set;
import java.util.SortedSet;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.fest.assertions.Assertions.*;

public class SaleTemplate_UT extends CreateTestData{
	private static SystemTestFixture systemTestFixture;
	private static SaleTestFixture saleTestFixture;
	
	@BeforeClass
	public static void onlyOnce() {
		systemTestFixture = new SystemTestFixture();
		saleTestFixture = new SaleTestFixture(systemTestFixture);
	}


	@Test
	public void given_a_price_one_dueDate_when_parameter_less_than_due_date_then_isDueDateFitsIntoAllowedDueDatesBySaleTemplate_return_false() {
		boolean dueDateLessThanAugust = saleTestFixture.templateIntactaByPlantabilityRRByExpirationBtFree.isDueDateFitsIntoAllowedDueDates(
				SaleTestFixture.JANUARY, systemTestFixture.rr);
		assertFalse("Should not fit into due date available", dueDateLessThanAugust);
	}

	@Test
	public void given_a_price_one_dueDate_when_parameter_greater_than_due_date_then_isDueDateFitsIntoAllowedDueDatesBySaleTemplate_return_false() {
		boolean dueDateGreaterThanAugust = saleTestFixture.templateIntactaByPlantabilityRRByExpirationBtFree.isDueDateFitsIntoAllowedDueDates(
				SaleTestFixture.DECEMBER, systemTestFixture.rr);
		assertFalse("Should not fit into due date available", dueDateGreaterThanAugust);
	}

	@Test
	public void given_a_price_one_dueDate_when_parameter_equals_due_date_then_isDueDateFitsIntoAllowedDueDatesBySaleTemplate_return_true() {
		boolean dueDateInNovember = saleTestFixture.templateIntactaByPlantabilityRRByExpirationBtFree.isDueDateFitsIntoAllowedDueDates(
				SaleTestFixture.NOVEMBER, systemTestFixture.rr);
		assertTrue("Should fit into due date available", dueDateInNovember);
	}

	@Test
	public void given_a_price_with_two_dueDates_when_parameter_less_than_all_due_dates_then_isDueDateFitsIntoAllowedDueDatesBySaleTemplate_return_false() {
		boolean dueDateIsAugust = saleTestFixture.templateIntactaByPlantabilityRRByExpirationBtFree.isDueDateFitsIntoAllowedDueDates(
				SaleTestFixture.JANUARY, systemTestFixture.intacta);
		assertFalse("Should not fit into due date available", dueDateIsAugust);
	}

	@Test
	public void given_a_price_with_two_dueDates_when_parameter_greater_than_all_due_dates_then_isDueDateFitsIntoAllowedDueDatesBySaleTemplate_return_false() {
		boolean dueDateIsAugust = saleTestFixture.templateIntactaByPlantabilityRRByExpirationBtFree.isDueDateFitsIntoAllowedDueDates(
				SaleTestFixture.DECEMBER, systemTestFixture.intacta);
		assertFalse("Should not fit into due date available", dueDateIsAugust);
	}

	@Test
	public void given_a_price_with_two_dueDates_when_parameter_fits_into_all_due_dates_then_isDueDateFitsIntoAllowedDueDatesBySaleTemplate_return_true() {
		boolean dueDateIsAugust = saleTestFixture.templateIntactaByPlantabilityRRByExpirationBtFree.isDueDateFitsIntoAllowedDueDates(
				SaleTestFixture.MAY, systemTestFixture.intacta);
		assertTrue("Should fit into due date available", dueDateIsAugust);
	}

	@Test
	public void given_a_price_with_two_dueDates_when_parameter_equals_minor_due_date_then_isDueDateFitsIntoAllowedDueDatesBySaleTemplate_return_true() {
		boolean dueDateIsAugust = saleTestFixture.templateIntactaByPlantabilityRRByExpirationBtFree.isDueDateFitsIntoAllowedDueDates(
				SaleTestFixture.APRIL, systemTestFixture.intacta);
		assertTrue("Should fit into due date available", dueDateIsAugust);
	}

	@Test
	public void given_a_price_with_two_dueDates_when_parameter_equals_major_due_date_then_isDueDateFitsIntoAllowedDueDatesBySaleTemplate_return_true() {
		boolean dueDateIsAugust = saleTestFixture.templateIntactaByPlantabilityRRByExpirationBtFree.isDueDateFitsIntoAllowedDueDates(
				SaleTestFixture.AUGUST, systemTestFixture.intacta);
		assertTrue("Should fit into due date available", dueDateIsAugust);
	}

	@Test
	public void given_a_noValue_price_when_parameter_equals_major_due_date_then_isDueDateFitsIntoAllowedDueDatesBySaleTemplate_return_true() {
		boolean dueDateIsAugust = saleTestFixture.templateIntactaFixRRRangeBtNoValue.isDueDateFitsIntoAllowedDueDates(
				SaleTestFixture.AUGUST, systemTestFixture.bt);
		assertTrue("Should fit into due date available", dueDateIsAugust);
	}

	@Test
	public void given_a_plantabilityPrice_with_two_royaltyValues_when_dueDate_exceeds_only_first_date_then_getPossiblePayments_returns_one_paymentDate() {
		SortedSet<PossiblePayment> possiblePayments = saleTestFixture.templateIntactaByPlantabilityRRByExpirationBtFree.getPossiblePayments(
				systemTestFixture.intacta, SaleTestFixture.JANUARY, ONE_THOUSAND_AS_lONG, SaleTestFixture.EIGHT_DOLLARS, saleTestFixture.plantabilitySystemSoyMonsanto2012.getDescription(), null, null);

		Assert.assertEquals("Should have 1 payment dates", 1, possiblePayments.size());
		assertPaymentDate(SaleTestFixture.JANUARY, SaleTestFixture.FIFTY_CENTS, ONE_THOUSAND_OF_SEEDS, possiblePayments.last());
	}

	@Test
	public void given_a_plantabilityPrice_with_two_royaltyValues_when_dueDate_fits_with_one_date_then_getPossiblePayments_returns_one_paymentDate() {
		SortedSet<PossiblePayment> possiblePayments = saleTestFixture.templateIntactaByPlantabilityRRByExpirationBtFree.getPossiblePayments(
				systemTestFixture.intacta, SaleTestFixture.FEBRUARY, ONE_THOUSAND_AS_lONG, SaleTestFixture.EIGHT_DOLLARS, saleTestFixture.plantabilitySystemSoyMonsanto2012.getDescription(), null, null);

		Assert.assertEquals("Should have 1 payment dates", 1, possiblePayments.size());
		assertPaymentDate(SaleTestFixture.FEBRUARY, SaleTestFixture.FIFTY_CENTS, ONE_THOUSAND_OF_SEEDS, possiblePayments.last());
	}

	@Test
	public void given_a_plantabilityPrice_with_two_royaltyValues_when_dueDate_exceeds_all_dates_then_getPossiblePayments_returns_two_paymentDates() {
		SortedSet<PossiblePayment> possiblePayments = saleTestFixture.templateIntactaByPlantabilityRRByExpirationBtFree.getPossiblePayments(
				systemTestFixture.intacta, SaleTestFixture.DECEMBER, ONE_THOUSAND_AS_lONG, SaleTestFixture.EIGHT_DOLLARS, saleTestFixture.plantabilitySystemSoyMonsanto2012.getDescription(), null, null);

		Assert.assertEquals("Should have 2 payment dates", 2, possiblePayments.size());
		assertPaymentDate(SaleTestFixture.FEBRUARY, SaleTestFixture.FIFTY_CENTS, ONE_THOUSAND_OF_SEEDS, possiblePayments.first());
		assertPaymentDate(SaleTestFixture.AUGUST, SaleTestFixture.TWO_POINT_FIVE_DOLLARS, ONE_THOUSAND_OF_SEEDS, possiblePayments.last());
	}

	@Test
	public void given_a_plantabilityPrice_with_two_royaltyValues_when_dueDate_exceeds_all_dates_then_getLastPossiblePaymentByDueDate_returns_the_lastPaymentDateEquals_getPossiblePayments_lastPayment() {

		BigDecimal lastPaymentDateRoyaltyPrice = saleTestFixture.templateIntactaByPlantabilityRRByExpirationBtFree.getLastPossiblePaymentValue(systemTestFixture.intacta, SaleTestFixture.DECEMBER,
				ONE_THOUSAND_AS_lONG, SaleTestFixture.EIGHT_DOLLARS,	saleTestFixture.plantabilitySystemSoyMonsanto2012.getDescription(), null);

		SortedSet<PossiblePayment> possiblePayments = saleTestFixture.templateIntactaByPlantabilityRRByExpirationBtFree.getPossiblePayments(
				systemTestFixture.intacta, SaleTestFixture.DECEMBER, ONE_THOUSAND_AS_lONG, SaleTestFixture.EIGHT_DOLLARS, saleTestFixture.plantabilitySystemSoyMonsanto2012.getDescription(), null, null);

		Assert.assertEquals("Should have 2 payment dates", 2, possiblePayments.size());
		Assert.assertEquals("Should be the same paymentDate", possiblePayments.last().getRoyaltyValue(), lastPaymentDateRoyaltyPrice);
	}

	@Test
	public void given_a_noValuePrice_then_getLastPossiblePaymentByDueDate_returns_zero() {

		BigDecimal lastPaymentDateRoyaltyPrice = saleTestFixture.templateIntactaFixRRRangeBtNoValue.getLastPossiblePaymentValue(systemTestFixture.bt, null,
				ONE_THOUSAND_AS_lONG, SaleTestFixture.EIGHT_DOLLARS,	saleTestFixture.plantabilitySystemSoyMonsanto2012.getDescription(), null);

		Assert.assertEquals("Should be zero", BigDecimal.ZERO, lastPaymentDateRoyaltyPrice);
	}

	@Test
	public void given_a_expirationDatePrice_with_two_royaltyValues_when_dueDate_exceeds_only_first_date_then_getPossiblePayments_returns_one_paymentDate() {
		SortedSet<PossiblePayment> possiblePayments = saleTestFixture.templateIntactaByPlantabilityRRByExpirationBtFree.getPossiblePayments(
				systemTestFixture.rr, SaleTestFixture.JANUARY, ONE_THOUSAND_AS_lONG, SaleTestFixture.EIGHT_DOLLARS, null, null, null);

		Assert.assertEquals("Should have 1 payment dates", 1, possiblePayments.size());
		assertPaymentDate(SaleTestFixture.JANUARY, SaleTestFixture.FIFTY_CENTS, ONE_THOUSAND_OF_SEEDS, possiblePayments.last());
	}

	@Test
	public void given_a_expirationDatePrice_with_two_royaltyValues_when_dueDate_fits_with_one_date_then_getPossiblePayments_returns_one_paymentDate() {
		SortedSet<PossiblePayment> possiblePayments = saleTestFixture.templateIntactaByPlantabilityRRByExpirationBtFree.getPossiblePayments(
				systemTestFixture.rr, SaleTestFixture.FEBRUARY, ONE_THOUSAND_AS_lONG, SaleTestFixture.EIGHT_DOLLARS, null, null, null);

		Assert.assertEquals("Should have 1 payment dates", 1, possiblePayments.size());
		assertPaymentDate(SaleTestFixture.FEBRUARY, SaleTestFixture.FIFTY_CENTS, ONE_THOUSAND_OF_SEEDS, possiblePayments.last());
	}

	@Test
	public void given_a_expirationDatePrice_with_two_royaltyValues_when_dueDate_exceeds_all_dates_then_getPossiblePayments_returns_two_paymentDates() {
		SortedSet<PossiblePayment> possiblePayments = saleTestFixture.templateIntactaByPlantabilityRRByExpirationBtFree.getPossiblePayments(
				systemTestFixture.rr, SaleTestFixture.DECEMBER, ONE_THOUSAND_AS_lONG, SaleTestFixture.EIGHT_DOLLARS, null, null, null);

		Assert.assertEquals("Should have 2 payment dates", 2, possiblePayments.size());
		assertPaymentDate(SaleTestFixture.FEBRUARY, SaleTestFixture.FIFTY_CENTS, ONE_THOUSAND_OF_SEEDS, possiblePayments.first());
		assertPaymentDate(SaleTestFixture.AUGUST, SaleTestFixture.TWO_POINT_FIVE_DOLLARS, ONE_THOUSAND_OF_SEEDS, possiblePayments.last());
	}

	@Test
	public void given_a_fixPrice_with_one_royaltyValue_getPossiblePayments_return_one_paymentDate() throws BusinessException {
		SortedSet<PossiblePayment> possiblePayments = saleTestFixture.templateIntactaFixRRRangeBtNoValue.getPossiblePayments(
				systemTestFixture.intacta, SaleTestFixture.AUGUST, ONE_THOUSAND_AS_lONG, SaleTestFixture.EIGHT_DOLLARS, null, null, null);

		Assert.assertEquals("Should have 1 possible payment", 1, possiblePayments.size());
		assertPaymentDate(SaleTestFixture.AUGUST, SaleTestFixture.FIVE_DOLLARS, ONE_THOUSAND_OF_SEEDS, possiblePayments.last());
	}

	@Test
	public void given_a_rangeValuePrice_getPossiblePayments_return_one_paymentDate() throws BusinessException {
		SortedSet<PossiblePayment> possiblePayments = saleTestFixture.templateIntactaFixRRRangeBtNoValue.getPossiblePayments(
				systemTestFixture.rr, SaleTestFixture.FEBRUARY, ONE_THOUSAND_AS_lONG, SaleTestFixture.EIGHT_DOLLARS, null, null, null);

		Assert.assertEquals("Should have 1 possible payment", 1, possiblePayments.size());
		assertPaymentDate(SaleTestFixture.FEBRUARY, SaleTestFixture.EIGHT_DOLLARS, ONE_THOUSAND_OF_SEEDS, possiblePayments.last());
	}

	@Test
	public void given_a_freePrice_with_one_royaltyValue_without_param_getPossiblePayments_return_one_paymentDate() throws BusinessException {
		SortedSet<PossiblePayment> possiblePayments = saleTestFixture.templateIntactaByPlantabilityRRByExpirationBtFree.getPossiblePayments(
				systemTestFixture.bt, SaleTestFixture.AUGUST, ONE_THOUSAND_AS_lONG, SaleTestFixture.EIGHT_DOLLARS, null, null, null);

		Assert.assertEquals("Should have 1 possible payment", 1, possiblePayments.size());
		assertPaymentDate(SaleTestFixture.AUGUST, SaleTestFixture.EIGHT_DOLLARS, ONE_THOUSAND_OF_SEEDS, possiblePayments.last());
	}

    @Test
	public void given_a_freePrice_with_one_royaltyValue_with_param_getPossiblePayments_return_one_paymentDate() throws BusinessException {
		SortedSet<PossiblePayment> possiblePayments = saleTestFixture.templateIntactaByPlantabilityRRByExpirationBtFree.getPossiblePayments(
				systemTestFixture.bt, SaleTestFixture.AUGUST, ONE_THOUSAND_AS_lONG, SaleTestFixture.EIGHT_DOLLARS, null, SaleTestFixture.EIGHT_DOLLARS.multiply(BigDecimal.valueOf(ONE_THOUSAND_AS_lONG)), null);

		Assert.assertEquals("Should have 1 possible payment", 1, possiblePayments.size());
		assertPaymentDate(SaleTestFixture.AUGUST, SaleTestFixture.EIGHT_DOLLARS, ONE_THOUSAND_OF_SEEDS, possiblePayments.last());
	}

	@Test
	public void given_a_noValuePrice_getPossiblePayments_return_no_paymentDate() throws BusinessException {
		Set<PossiblePayment> possiblePayments = saleTestFixture.templateIntactaFixRRRangeBtNoValue.getPossiblePayments(
				systemTestFixture.bt, SaleTestFixture.AUGUST, ONE_THOUSAND_AS_lONG, SaleTestFixture.FIVE_DOLLARS, null, null, null);

		PossiblePayment expectedPaymentDate = new PossiblePayment(SaleTestFixture.AUGUST);
		Assert.assertEquals("Should have no possible payment", 0, possiblePayments.size());
		assertFalse("ExpectedPayment not found", possiblePayments.contains(expectedPaymentDate));
	}

	@Test
	public void given_a_dueDate_greaterThan_price_last_expirationDate_and_lowerThan_the_rangeLimit_of_price_dueDate_should_be_returned_a_new_possiblePayment_with_the_given_date() {
		SortedSet<PossiblePayment> possiblePayments = saleTestFixture.templateIntactaByPlantabilityRRByExpirationBtFree.getPossiblePayments(
				systemTestFixture.rr, SaleTestFixture.OCTOBER, ONE_THOUSAND_AS_lONG, SaleTestFixture.EIGHT_DOLLARS, null, null, null);

		Assert.assertEquals("Should have 3 payment dates", 3, possiblePayments.size());
		assertPaymentDate(SaleTestFixture.FEBRUARY, SaleTestFixture.FIFTY_CENTS, ONE_THOUSAND_OF_SEEDS, possiblePayments.first());
		assertPaymentDate(SaleTestFixture.OCTOBER, SaleTestFixture.TWO_POINT_FIVE_DOLLARS, ONE_THOUSAND_OF_SEEDS, possiblePayments.last());
	}

	@Test
	public void given_a_dueDate_greaterThan_price_last_expirationDate_and_equals_the_rangeLimit_of_dueDate_should_be_returned_a_new_possiblePayment_with_the_given_date() {
		SortedSet<PossiblePayment> possiblePayments = saleTestFixture.templateIntactaByPlantabilityRRByExpirationBtFree.getPossiblePayments(
				systemTestFixture.rr, SaleTestFixture.NOVEMBER, ONE_THOUSAND_AS_lONG, SaleTestFixture.EIGHT_DOLLARS, null, null, null);
		
		Assert.assertEquals("Should have 3 payment dates", 3, possiblePayments.size());
		assertPaymentDate(SaleTestFixture.FEBRUARY, SaleTestFixture.FIFTY_CENTS, ONE_THOUSAND_OF_SEEDS, possiblePayments.first());
		assertPaymentDate(SaleTestFixture.NOVEMBER, SaleTestFixture.TWO_POINT_FIVE_DOLLARS, ONE_THOUSAND_OF_SEEDS, possiblePayments.last());
	}


	private static final BigDecimal ONE_THOUSAND_OF_SEEDS = new BigDecimal(new Long(1000));
	private static final Long ONE_THOUSAND_AS_lONG = ONE_THOUSAND_OF_SEEDS.longValue();

	private void assertPaymentDate(Date expectedDate, BigDecimal expectedRoyaltyUnitValue, BigDecimal expectedSoldQuantityValue, PossiblePayment actual) {
		Assert.assertEquals("First PaymentDate is wrong", expectedDate, actual.getReceiptDate());
		Assert.assertEquals("Royalty unit value is wrong", expectedRoyaltyUnitValue, actual.getRoyaltyValue());
		BigDecimal expectedValue = expectedRoyaltyUnitValue.multiply(expectedSoldQuantityValue);
		Assert.assertEquals("Payment Value is wrong", expectedValue, actual.getReceiptValue());
	}

	// TODO: REVIEW ALL THESE TESTS BELLOW
	
	@Test
	public void createObject() {
		Assert.assertNotNull(saleTestFixture.templateIntactaFixRRRangeBtNoValue.getHarvest().getDescription());

		Assert.assertNotNull(saleTestFixture.templateIntactaFixRRRangeBtNoValue.getDescription());
		
		Assert.assertNotNull(saleTestFixture.templateIntactaFixRRRangeBtNoValue.getPlantabilityBy());

		Assert.assertNotNull(saleTestFixture.templateIntactaFixRRRangeBtNoValue.getHarvest().getCrop().getDescription());

		Assert.assertNotNull(saleTestFixture.templateIntactaFixRRRangeBtNoValue.getHarvest().getCompleteDescription());

		Assert.assertNotNull(saleTestFixture.templateIntactaFixRRRangeBtNoValue.getHarvest().getOperationalYear().getYear());

		Assert.assertNotNull(saleTestFixture.templateIntactaFixRRRangeBtNoValue.getHarvest().getCompleteDescription());

		saleTestFixture.templateIntactaFixRRRangeBtNoValue.setDescription("DescriptionEdited");
		saleTestFixture.templateIntactaFixRRRangeBtNoValue.getHarvest().setDescription("HarvestEdited");
		saleTestFixture.templateIntactaFixRRRangeBtNoValue.getHarvest().getOperationalYear().setYear("2013");
		saleTestFixture.templateIntactaFixRRRangeBtNoValue.getHarvest().getCrop().setDescription("CropEdited");
		saleTestFixture.templateIntactaFixRRRangeBtNoValue.getHarvest().getCompany()
				.setDescription("COMPANYEDITED");

		Assert.assertEquals("HarvestEdited".toUpperCase(), saleTestFixture.templateIntactaFixRRRangeBtNoValue
				.getHarvest().getDescription());
		assertTrue("2013".equalsIgnoreCase(saleTestFixture.templateIntactaFixRRRangeBtNoValue.getHarvest()
				.getOperationalYear().getYear()));
		Assert.assertEquals("CropEdited".toUpperCase(), saleTestFixture.templateIntactaFixRRRangeBtNoValue.getHarvest().getCrop()
				.getDescription());
		Assert.assertEquals("COMPANYEDITED", saleTestFixture.templateIntactaFixRRRangeBtNoValue.getHarvest().getCrop()
				.getCompany().getDescription());
		Assert.assertEquals("HARVESTEDITED - CropEdited - 2013 - CompanyEdited".toUpperCase(),
				saleTestFixture.templateIntactaFixRRRangeBtNoValue.getHarvest().getCompleteDescription());

		Assert.assertEquals("DescriptionEdited".toUpperCase(),
				saleTestFixture.templateIntactaFixRRRangeBtNoValue.getDescription());

	}

	@Test
	public void createSaleTemplateWithNewPricing() throws BusinessException {
		Country brazil = CountryTestData.createBrazil();
		Company monsanto = new Company("Monsanto");
		Crop crop = CropTestData.createCrop(monsanto,brazil);
		Brand brand = BrandTestData.createBrand(monsanto);
		Technology technology = TechnologyTestData.createTechnology(monsanto);
		Product product = ProductTestData.createProduct(brand, crop, technology, StatusEnum.ACTIVE, monsanto);

		// creating new template by product created above
		Harvest harvest = new Harvest(monsanto, "Safrinha", new OperationalYear("2012"), crop, StatusEnum.ACTIVE);
		Date now = new Date();
		SaleTemplate template = new SaleTemplate(harvest, "Description", now, Boolean.FALSE, SaleTemplateByPlantabilityEnum.BY_PRODUCT, now, now, SaleTypeEnum.SALE_SEED, SaleTemplateBillingMethodEnum.DIRECT);
		// get All Template's pricing
		List<Price> createdTemplatePrice = template.getTemplatePrice();
		// expected a pricing
		Assert.assertEquals(1, createdTemplatePrice.size());
		// validate if the value of price is zero
		for (Technology tech : product.getCompany().getTechnologies()) {
			Assert.assertEquals(tech, createdTemplatePrice.iterator().next().getTechnology());
			Price price = createdTemplatePrice.iterator().next();
			Assert.assertEquals(BigDecimal.ZERO, price.getRoyaltyValues().iterator().next().getValue());
		} 

	}

	@Test
	public void createSaleTemplateFull() {
		Date d = new Date();

		saleTestFixture.templateIntactaFixRRRangeBtNoValue.setInvoice(new SaleTemplateInvoice());
		saleTestFixture.templateIntactaFixRRRangeBtNoValue.getInvoice().setDocumentRequired(true);
		saleTestFixture.templateIntactaFixRRRangeBtNoValue.getInvoice().setDtInitial(d);

		Assert.assertNotNull(saleTestFixture.templateIntactaFixRRRangeBtNoValue.getInvoice());

		Assert.assertEquals(saleTestFixture.templateIntactaFixRRRangeBtNoValue.getInvoice().getDocumentRequired(), true);
		Assert.assertEquals(saleTestFixture.templateIntactaFixRRRangeBtNoValue.getInvoice().getDtInitial(), d);
	}

	@Test
	public void createSaleTemplateInvoiceFull() {

		Date d = new Date();

		SaleTemplateInvoice invoice = new SaleTemplateInvoice(true, d);

		Assert.assertEquals(invoice.getDocumentRequired(), true);
		Assert.assertEquals(invoice.getDtInitial(), d);

		invoice = new SaleTemplateInvoice(false, null);

		Assert.assertEquals(invoice.getDocumentRequired(), false);
		Assert.assertNull(invoice.getDtInitial());

	}

	@Test(expected = IllegalArgumentException.class)
	public void createSaleTemplateInvoiceException() {

		new SaleTemplateInvoice(true, null);

		Assert.fail();
	}

	@Test
	public void testAddNewPricing() throws BusinessException {
		SaleTemplate saleTemplate = SaleTemplateTestData.createSaleTemplateTypeSeedSale(new Harvest());
		
		Price pricing = createPriceDefaultTech(PriceTypeEnum.FIX, saleTemplate);

		assertTrue(saleTemplate.getPrices().size() == 1);
		Assert.assertEquals(saleTemplate.getPrices().iterator().next(), pricing);
	}

	@Test
	public void testAddPricingAnotherTemplate() throws BusinessException {
		// creating a new saleTemplate
		SaleTemplate template = SaleTemplateTestData.createSaleTemplateTypeSeedSale(new Harvest());
		SaleTemplate templateAnother = SaleTemplateTestData.createSaleTemplateTypeSeedSale(new Harvest());
		templateAnother.setDescription("Another Template");
		
		// creating new pricing by templateAnother
		Price price = createPriceDefaultTech(PriceTypeEnum.FIX, templateAnother);

		// change the object pricing of templateAnother to template
		assertTrue(template.addPrices(price));

		Assert.assertEquals(template.getPrices().iterator().next(), price);
		assertTrue(template.getPrices().size() == 1);
		assertTrue(templateAnother.getPrices().isEmpty());

	}

	@Test
	public void testAddPricingTemplateError() throws BusinessException {
		// creating new pricing by templateAnother
		Price pricing = createPriceDefaultTech(PriceTypeEnum.FIX, saleTestFixture.templateIntactaFixRRRangeBtNoValue);

		// change the object pricing of templateAnother to template
		assertFalse(saleTestFixture.templateIntactaFixRRRangeBtNoValue.addPrices(pricing));
	}

	@Test
	public void testAddProductInTemplate() {
		Product product = ProductTestData.createProduct();

		// validate if not is empty
		int initSize = saleTestFixture.templateIntactaFixRRRangeBtNoValue.getProducts().size();
		assertTrue(!saleTestFixture.templateIntactaFixRRRangeBtNoValue.getProducts().isEmpty());
		assertTrue("Greater then zero", 0 < initSize);
		// add new product in template
		assertTrue(saleTestFixture.templateIntactaFixRRRangeBtNoValue.addProduct(product));

		// validate if is not empty
		assertFalse(saleTestFixture.templateIntactaFixRRRangeBtNoValue.getProducts().isEmpty());
		assertTrue(saleTestFixture.templateIntactaFixRRRangeBtNoValue.getProducts().size() == ++initSize);
		assertTrue(saleTestFixture.templateIntactaFixRRRangeBtNoValue.getProducts().contains(product));
	}

	@Test
	public void testAddProductWithNullTemplate() {
		Product product = ProductTestData.createProduct();
		assertTrue(saleTestFixture.templateIntactaFixRRRangeBtNoValue.addProduct(product));
	}

	@Test
	public void createSaleTemplateWithExistingPriceFix() throws BusinessException {
		
		// creating a new saleTemplate
		SaleTemplate template = SaleTemplateTestData.createSaleTemplateTypeSeedSale(HarvestTestData.createABrazilianHarvest());
		
		// creating new pricing by templateAnother
		Price pricing = SaleTemplateTestData.createPrice(PriceTypeEnum.FIX,template, template.getHarvest().getCompany().getTechnologies().iterator().next());

		// get All Template's pricing
		template.getTemplatePrice();
		// expected a pricing
		assertTrue(template.getPrices().size() == 1);
		// validate if the value of price is zero
		for (Technology tech : template.getHarvest().getCompany().getTechnologies()) {
			Assert.assertEquals(tech, template.getPrices().iterator().next()
					.getTechnology());
			Assert.assertEquals(pricing.getRoyaltyValues().iterator().next().getValue(), template.getPrices()
					.iterator().next().getRoyaltyValues().iterator().next().getValue());
		}
	}

	@Test
	public void createSaleTemplateWithExistingPricingAndNewPriceFix() throws BusinessException {
		
		// creating a new saleTemplate
		SaleTemplate template = SaleTemplateTestData.createSaleTemplateTypeSeedSale(HarvestTestData.createABrazilianHarvest());
		
		// creating new pricing by templateAnother
		Price pricing = SaleTemplateTestData.createPrice(PriceTypeEnum.FIX, template, template.getHarvest().getCrop()
				.getCompany().getTechnologies().iterator().next());

		template.addPrices(pricing);
		// creating a new technology
		Technology technology = createTechnology(template.getHarvest().getCrop()
				.getCompany()); 

		// get All Template's pricing
		List<Price> createdTemplatePrice = template.getTemplatePrice();

		// expected two pricing
		assertTrue(createdTemplatePrice.size() == 2);

		// validate if contains a price with the value zero and another
		// different of zero
		for (Price p : createdTemplatePrice) {
			if (p.getTechnology().equals(technology)) {
				Assert.assertEquals(BigDecimal.ZERO, p.getRoyaltyValues().iterator().next().getValue());
			} else {
				Assert.assertEquals(pricing.getRoyaltyValues().iterator().next().getValue(), p.getRoyaltyValues().iterator().next().getValue());
			}
		}
	}

	@Test
	public void createSaleTemplateWithOrderedListOfPrices() throws BusinessException {
		Country brazil = CountryTestData.createBrazil();
		Company company = new Company("Monsanto - BR");
		company.setCountry(brazil);
		brazil.addCompany(company);

		Technology technologyA = new Technology("A", company);
		Technology technologyB = new Technology("B", company);
		Technology technologyC = new Technology("C", company);
		
		company.addTechnology(technologyC);
		company.addTechnology(technologyB);
		company.addTechnology(technologyA);
		
		Harvest harvest = new Harvest(company, "Safrinha", new OperationalYear("2012"), new Crop("Soja", company, brazil), StatusEnum.ACTIVE);
		
		SaleTemplate saleTemplate =  SaleTemplateTestData.createSaleTemplateTypeSeedSale(harvest);
		
		List<Price> prices = saleTemplate.getTemplatePrice();

		Assert.assertEquals("A", prices.get(0).getTechnology().getDescription());
		Assert.assertEquals("B", prices.get(1).getTechnology().getDescription());
		Assert.assertEquals("C", prices.get(2).getTechnology().getDescription());
	}
	
    @Test
    public void testCalculateProductivityByRegionReturnsTrue_WhenSaleTypeIsSALE_SEEDAndCreditCalculationIsBY_REGION_OF_PLANTATION(){
        //@Given
        SaleTemplate saleTemplate = new SaleTemplate();
        saleTemplate.setSaleType(SaleTypeEnum.SALE_SEED);
        saleTemplate.setCreditCalculation(SaleTemplateCreditCalculationEnum.BY_REGION_OF_PLANTATION);

        //@When
        Boolean calculateProductivityByRegion = saleTemplate.calculateProductivityByRegion();

        //@Should
        assertTrue(calculateProductivityByRegion);
}

    @Test
    public void testCalculateProductivityByRegionReturnsTrue_WhenSaleTypeIsDIRECT_SALEAndCreditCalculationIsBY_REGION_OF_PLANTATION(){
        //@Given
        SaleTemplate saleTemplate = new SaleTemplate();
        saleTemplate.setSaleType(SaleTypeEnum.DIRECT_SALE);
        saleTemplate.setCreditCalculation(SaleTemplateCreditCalculationEnum.BY_REGION_OF_PLANTATION);

        //@When
        Boolean calculateProductivityByRegion = saleTemplate.calculateProductivityByRegion();

        //@Should
        assertTrue(calculateProductivityByRegion);
    }

    @Test
    public void testCalculateProductivityByRegionReturnsTrue_WhenSaleTypeIsLICENSE_SEEDAndCreditCalculationIsBY_REGION_OF_PLANTATION(){
        //@Given
        SaleTemplate saleTemplate = new SaleTemplate();
        saleTemplate.setSaleType(SaleTypeEnum.LICENSE_SEED);
        saleTemplate.setCreditCalculation(SaleTemplateCreditCalculationEnum.BY_REGION_OF_PLANTATION);

        //@When
        Boolean calculateProductivityByRegion = saleTemplate.calculateProductivityByRegion();

        //@Should
        assertTrue(calculateProductivityByRegion);
    }

    @Test
    public void testCalculateProductivityByRegionReturnsFalse_WhenSaleTypeIsLICENSE_SEEDAndCreditCalculationIsNull(){
        //@Given
        SaleTemplate saleTemplate = new SaleTemplate();
        saleTemplate.setSaleType(SaleTypeEnum.LICENSE_SEED);
        saleTemplate.setCreditCalculation(null);

        //@When
        Boolean calculateProductivityByRegion = saleTemplate.calculateProductivityByRegion();

        //@Should
        assertFalse(calculateProductivityByRegion);
    }

    @Test
    public void testCalculateProductivityByRegionReturnsFalse_WhenSaleTypeIsMULTIPLIER_TO_GROWER_SEED_SALEAndCreditCalculationIsNull(){
        //@Given
        SaleTemplate saleTemplate = new SaleTemplate();
        saleTemplate.setSaleType(SaleTypeEnum.MULTIPLIER_TO_GROWER_SEED_SALE);
        saleTemplate.setCreditCalculation(null);

        //@When
        Boolean calculateProductivityByRegion = saleTemplate.calculateProductivityByRegion();

        //@Should
        assertFalse(calculateProductivityByRegion);
    }

    @Test
    public void testCalculateProductivityByRegionReturnsTrue_WhenSaleTypeIsMULTIPLIER_TO_GROWER_SEED_SALEAndCreditCalculationIsBY_REGION_OF_PLANTATION(){
        //@Given
        SaleTemplate saleTemplate = new SaleTemplate();
        saleTemplate.setSaleType(SaleTypeEnum.MULTIPLIER_TO_GROWER_SEED_SALE);
        saleTemplate.setCreditCalculation(SaleTemplateCreditCalculationEnum.BY_REGION_OF_PLANTATION);

        //@When
        Boolean calculateProductivityByRegion = saleTemplate.calculateProductivityByRegion();

        //@Should
        assertTrue(calculateProductivityByRegion);
    }

    @Test
    public void testCalculateProductivityByRegionReturnsFalse_WhenSaleTypeIsLICENSE_SEEDAndCreditCalculationIsBY_STATE_OF_PLANTATION(){
        //@Given
        SaleTemplate saleTemplate = new SaleTemplate();
        saleTemplate.setSaleType(SaleTypeEnum.LICENSE_SEED);
        saleTemplate.setCreditCalculation(SaleTemplateCreditCalculationEnum.BY_STATE_OF_PLANTATION);

        //@When
        Boolean calculateProductivityByRegion = saleTemplate.calculateProductivityByRegion();

        //@Should
        assertFalse(calculateProductivityByRegion);
    }

    @Test
    public void testCalculateProductivityByStateReturnsTrue_WhenSaleTypeIsLICENSE_SEEDAndCreditCalculationIsBY_STATE_OF_PLANTATION(){
        //@Given
        SaleTemplate saleTemplate = new SaleTemplate();
        saleTemplate.setSaleType(SaleTypeEnum.LICENSE_SEED);
        saleTemplate.setCreditCalculation(SaleTemplateCreditCalculationEnum.BY_STATE_OF_PLANTATION);

        //@When
        Boolean calculateProductivityByState = saleTemplate.calculateProductivityByState();

        //@Should
        assertTrue(calculateProductivityByState);
    }

    @Test
    public void testCalculateProductivityByStateReturnsTrue_WhenSaleTypeIsLICENSE_SEEDAndCreditCalculationIsNull(){
        //@Given
        SaleTemplate saleTemplate = new SaleTemplate();
        saleTemplate.setSaleType(SaleTypeEnum.LICENSE_SEED);
        saleTemplate.setCreditCalculation(null);

        //@When
        Boolean calculateProductivityByState = saleTemplate.calculateProductivityByState();

        //@Should
        assertTrue(calculateProductivityByState);
    }

    @Test
    public void testGetIsShowCityMandatoryReturnsFalse_WhenIsShowCityMandatoryIsNull(){
        SaleTemplate saleTemplate = new SaleTemplate();
        saleTemplate.setIsShowCityMandatory(null);

        assertThat(saleTemplate.getIsShowCityMandatory()).isEqualTo(false);
    }

}
