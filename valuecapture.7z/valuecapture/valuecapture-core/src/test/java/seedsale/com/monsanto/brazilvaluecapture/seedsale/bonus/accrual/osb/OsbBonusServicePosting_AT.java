package com.monsanto.brazilvaluecapture.seedsale.bonus.accrual.osb;

import com.monsanto.brazilvaluecapture.osb.its.api.InfraException;
import com.monsanto.brazilvaluecapture.osb.its.api.PostingDocument;
import com.monsanto.brazilvaluecapture.osb.util.PropertyReaderException;
import com.monsanto.brazilvaluecapture.osb.util.SecurityContextBadCredentialException;
import com.monsanto.brazilvaluecapture.osb.util.SecurityContextHolder;
import com.monsanto.brazilvaluecapture.seedsale.posting.osb.OsbBonusPostingService;
import junit.framework.Assert;
import org.junit.Ignore;
import org.junit.Test;

import java.math.BigDecimal;
import java.net.MalformedURLException;
import java.util.Date;

import static junit.framework.Assert.assertTrue;

/**
 * Created by AJMILD1 on 29/07/14.
 */
@Ignore
public class OsbBonusServicePosting_AT {
    private static final String POSTING_WSDL_URL = "http://services-t.monsanto.com:80/FI-SD_Brazil_Value_Capture_External/Posting";
    private OsbBonusPostingService osbPostingService;

    @Test
    public void when_calling_posting_should_return_ok()
            throws MalformedURLException,
            SecurityContextBadCredentialException,
            InfraException {

        osbPostingService = new OsbBonusPostingService() {
            @Override
            protected SecurityContextHolder getSecurityContextHolder() throws SecurityContextBadCredentialException {
                return new TestBonusSecurityContextHolderImpl();
            }

            @Override
            protected String getOsbUrlProperty() throws PropertyReaderException {
                return POSTING_WSDL_URL;
            }
        };

        Date paymentAndFileDate = new Date();
        PostingDocument postingDocument = osbPostingService.post(new BigDecimal(150000), "BONUS ACCRUAL", paymentAndFileDate, paymentAndFileDate, OsbBonusPostingService.DEFAULT_TECHNOLOGY);

        Assert.assertNotNull(postingDocument.getFiDocument());
    }

    @Test
    public void test_post_wrongAccount()
            throws MalformedURLException,
            SecurityContextBadCredentialException,
            InfraException {

        osbPostingService = new OsbBonusPostingService() {
            @Override
            protected SecurityContextHolder getSecurityContextHolder() throws SecurityContextBadCredentialException {
                return new TestBonusSecurityContextHolderImpl();
            }

            @Override
            protected String getOsbUrlProperty() throws PropertyReaderException {
                return POSTING_WSDL_URL;
            }
        };
        try {
            Date paymentAndFileDate = new Date();
            PostingDocument postingDocument = osbPostingService.post(new BigDecimal(150000), "BONUS ACCRUAL EXPIRATION", paymentAndFileDate, paymentAndFileDate, OsbBonusPostingService.DEFAULT_TECHNOLOGY);
            Assert.fail("Shuld fail");
        } catch (InfraException e) {
            assertTrue(e.getMessage().contains("Error in document: BKPFF $ Q08CLNT430"));
        }

    }
}