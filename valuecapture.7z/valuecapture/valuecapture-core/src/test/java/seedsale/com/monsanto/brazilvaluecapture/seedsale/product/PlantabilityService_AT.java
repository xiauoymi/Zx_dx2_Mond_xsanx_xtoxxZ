package com.monsanto.brazilvaluecapture.seedsale.product;

import java.util.List;

import junit.framework.Assert;

import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.monsanto.brazilvaluecapture.core.base.SystemTestFixture;
import com.monsanto.brazilvaluecapture.core.foundation.model.bean.StatusEnum;
import com.monsanto.brazilvaluecapture.core.foundation.service.BusinessException;
import com.monsanto.brazilvaluecapture.core.foundation.test.AbstractServiceIntegrationTests;
import com.monsanto.brazilvaluecapture.seedsale.harvest.HarvestTestData;
import com.monsanto.brazilvaluecapture.seedsale.harvest.model.bean.Harvest;
import com.monsanto.brazilvaluecapture.seedsale.harvest.model.bean.Plantability;
import com.monsanto.brazilvaluecapture.seedsale.harvest.model.bean.PlantabilitySystemEnum;
import com.monsanto.brazilvaluecapture.seedsale.harvest.service.PlantabilityService;
import com.monsanto.brazilvaluecapture.seedsale.product.model.bean.Product;

public class PlantabilityService_AT extends AbstractServiceIntegrationTests{
	
	@Autowired
	private PlantabilityService plantabilityService;
	
	private Harvest harvest2012;
	private Product randomProduct;
	private Plantability anyPlantability;
	private Plantability anotherPlantability;
	private Plantability systemPlantability;

	@Before
	public void init() {
		systemTestFixture = new SystemTestFixture(this);
		
		harvest2012 = HarvestTestData.createHarvest(systemTestFixture.soy, systemTestFixture.operationalYearOf2011, systemTestFixture.monsantoBr);
		getSession().saveOrUpdate(harvest2012);

		randomProduct = ProductTestData.createProduct(systemTestFixture.monsoy, systemTestFixture.soy, systemTestFixture.intacta, StatusEnum.ACTIVE, systemTestFixture.monsantoBr);
		getSession().saveOrUpdate(randomProduct);
		
		anyPlantability = PlantabilityTestData.createPlantability(harvest2012);
		getSession().saveOrUpdate(anyPlantability);
		
		anotherPlantability = PlantabilityTestData.createPlantability(harvest2012);
		getSession().saveOrUpdate(anotherPlantability);
		
		systemPlantability = PlantabilityTestData.createPlantability(harvest2012);
		systemPlantability.setIsPlantabilitySystem(PlantabilitySystemEnum.YES);
		getSession().saveOrUpdate(systemPlantability);
	}
	@Test
	public void testInsert() throws BusinessException {
		
		Plantability plantability =  PlantabilityTestData.createPlantability(harvest2012);
		plantabilityService.save(plantability);
		
		Assert.assertNotNull(plantability);
		Assert.assertNotNull(plantability.getId());
		
		Long id = plantability.getId();
		
		Plantability plantabilityBase = plantabilityService.selectById(id);
		
		Assert.assertNotNull(plantabilityBase);
		Assert.assertEquals(plantability, plantabilityBase);
		Assert.assertEquals(plantability.getId(), plantabilityBase.getId());
		 
	}
	
	@Test
	public void testInsertException() throws BusinessException {
		
		Plantability plantability =  PlantabilityTestData.createPlantability(harvest2012);
		plantabilityService.save(plantability);

		try{
			Plantability plantabilityBase = PlantabilityTestData.createPlantability(harvest2012, 
					plantability.getDescription(), plantability.getStatus());
			plantabilityService.save(plantabilityBase);
			
			Assert.fail();
		}catch (BusinessException e) {
			Assert.assertTrue(true);
		}
	}
	
	@Test
	public void testUpdateException() throws BusinessException {
		
		Plantability plantability =  PlantabilityTestData.createPlantability(harvest2012);
		plantabilityService.save(plantability);
		Plantability plantability2 =  PlantabilityTestData.createPlantability(harvest2012);
		plantabilityService.save(plantability2);
		
		// creating a new plantability
		Plantability plantabilityBase = new Plantability();
		plantabilityBase.setId(plantability2.getId());
    	plantabilityBase.setHarvest(harvest2012);
    	plantabilityBase.setIsPlantabilitySystem(plantability.getIsPlantabilitySystem());
    	plantabilityBase.setStatus(plantability.getStatus());
    	plantabilityBase.setDescription(plantability.getDescription());
        
        try{
        	plantabilityService.save(plantabilityBase);
        	Assert.fail();
        }catch (BusinessException e){
			Assert.assertTrue(true);
		}
    }
	
	@Test
	public void testDelete() throws BusinessException{
		
		Plantability plantability =  PlantabilityTestData.createPlantability(harvest2012);
		plantabilityService.save(plantability);
		
		Long id = plantability.getId();
		
		plantabilityService.delete(plantability);
		
		Plantability plantabilityBase = plantabilityService.selectById(id);
		
		Assert.assertNull(plantabilityBase); 
		
	} 
	
	
	@Test
	public void testSelectBytFilter() throws BusinessException{
		
		Plantability plantability =  PlantabilityTestData.createPlantability(harvest2012);
		plantabilityService.save(plantability);
		
		List<Plantability> plantabilityBase = plantabilityService.selectByFilter(plantability);
		
		Assert.assertNotNull(plantabilityBase);
		Assert.assertFalse(plantabilityBase.isEmpty());
		Assert.assertTrue(plantabilityBase.size() == 1);
		Assert.assertTrue(plantabilityBase.iterator().next().getId() == plantability.getId());
	}
	
	@Test
	public void testSelectByFilterWithoutDescription() throws BusinessException{
		
		Harvest harvest = HarvestTestData.createHarvest(systemTestFixture.soy, systemTestFixture.operationalYearOf2011, systemTestFixture.monsantoBr);
		getSession().saveOrUpdate(harvest);
		
		Plantability plantability =  PlantabilityTestData.createPlantability(harvest);
		plantabilityService.save(plantability);
		
		Plantability plantabilityFilter = PlantabilityTestData.createPlantability(plantability.getHarvest(), null, plantability.getStatus());
		
		List<Plantability> plantabilityBase = plantabilityService.selectByFilter(plantabilityFilter);
		
		Assert.assertNotNull(plantabilityBase);
		Assert.assertFalse(plantabilityBase.isEmpty());
		Assert.assertTrue(plantabilityBase.size() == 1);
		Assert.assertTrue(plantabilityBase.iterator().next().getId() == plantability.getId());
	}

}
