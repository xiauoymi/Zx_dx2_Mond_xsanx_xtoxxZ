package com.monsanto.brazilvaluecapture.seedsale.sale.service;

import com.monsanto.brazilvaluecapture.core.base.SystemTestFixture;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Address;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Company;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Document;
import com.monsanto.brazilvaluecapture.core.base.model.bean.State;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Contract;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Customer;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.HeadOffice;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.ParticipantTypeEnum;
import com.monsanto.brazilvaluecapture.core.customer.service.CustomerNotAllowedException;
import com.monsanto.brazilvaluecapture.core.customer.service.CustomerNotFoundException;
import com.monsanto.brazilvaluecapture.core.foundation.RandomTestData;
import com.monsanto.brazilvaluecapture.core.foundation.model.bean.StatusEnum;
import com.monsanto.brazilvaluecapture.core.foundation.service.BusinessException;
import com.monsanto.brazilvaluecapture.core.foundation.test.AbstractServiceIntegrationTests;
import com.monsanto.brazilvaluecapture.core.foundation.util.ConstraintViolation;
import com.monsanto.brazilvaluecapture.core.grower.PlayerTestData;
import com.monsanto.brazilvaluecapture.core.grower.model.bean.Grower;
import com.monsanto.brazilvaluecapture.core.user.AccessControlTestFixture;
import com.monsanto.brazilvaluecapture.core.user.model.bean.HierarchyLevel;
import com.monsanto.brazilvaluecapture.core.user.model.bean.UserContract;
import com.monsanto.brazilvaluecapture.core.user.model.bean.UserDecorator;
import com.monsanto.brazilvaluecapture.core.user.service.DocumentMismatchException;
import com.monsanto.brazilvaluecapture.seedsale.harvest.HarvestTestData;
import com.monsanto.brazilvaluecapture.seedsale.harvest.model.bean.Harvest;
import com.monsanto.brazilvaluecapture.seedsale.product.ProductTestData;
import com.monsanto.brazilvaluecapture.seedsale.product.model.bean.Product;
import com.monsanto.brazilvaluecapture.seedsale.product.model.dao.ProductFilter;
import com.monsanto.brazilvaluecapture.seedsale.sale.SaleTestFixture;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.Sale;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.Sale.SaleTypeEnum;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.SaleItem;
import com.monsanto.brazilvaluecapture.seedsale.template.PriceTestData;
import com.monsanto.brazilvaluecapture.seedsale.template.SaleTemplateTestData;
import com.monsanto.brazilvaluecapture.seedsale.template.model.bean.*;
import com.monsanto.brazilvaluecapture.seedsale.template.model.bean.Price.PriceTypeEnum;
import junit.framework.Assert;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

public class SaleValidations_AT extends AbstractServiceIntegrationTests {

	@Autowired
	private SaleService saleService;
    
    private SaleTestData saleFactory;
	
	@Before
	public void init() throws BusinessException {
		systemTestFixture = new SystemTestFixture(this);
		accessControlTestFixture = new AccessControlTestFixture(this, systemTestFixture);
		saleTestFixture = new SaleTestFixture(this, systemTestFixture);

		accessControlTestFixture.itsParticipantUser.addUserContract(saleTestFixture.contract, saleTestFixture.customer, HierarchyLevel.HEAD_OFFICE);
        
        saleFactory = new SaleTestData(systemTestFixture.regionSaoPaulo2012).setState(systemTestFixture.saoPaulo);
	}

	@Test
	public void sanity_check() {
		Assert.assertNotNull("SaleService should not be null", saleService);
	}
	
	@Test
	public void when_customer_is_affiliate_the_HeadOffice_should_be_on_theList_of_headoffices_and_the_afffiliate_should_not(){
		
		List<Company> companies = new ArrayList<Company>();
		companies.add(saleTestFixture.headOfficeAffiliate.getCompany());
		
		List<HeadOffice> matrixes = saleService.getMatrixOf(saleTestFixture.affiliate2, companies, saleTestFixture.headOfficeAffiliate.getCrop());
		
		Assert.assertNotNull(matrixes);
		Assert.assertFalse(matrixes.isEmpty());
		Assert.assertTrue(matrixes.iterator().next().getHeadOfficeType().equals(HierarchyLevel.HEAD_OFFICE));
		Assert.assertTrue(matrixes.iterator().next().getCustomer().equals(saleTestFixture.matrixCargil));
		Assert.assertFalse(matrixes.iterator().next().getCustomer().equals(saleTestFixture.affiliate));
	}
	
	@Test(expected=CustomerNotFoundException.class)
	public void when_customer_does_not_exist_should_throw_CustomerNotFoundException()
			throws CustomerNotFoundException, CustomerNotAllowedException,
			DocumentMismatchException {
		saleService.getAllowedBy("12345", null, null, ParticipantTypeEnum.DISTRIBUTOR, null);
	}

	@Test(expected=CustomerNotAllowedException.class)
	public void when_customer_exist_but_user_does_not_has_access_should_throw_CustomerNotAllowedException()
			throws CustomerNotAllowedException, CustomerNotFoundException, DocumentMismatchException {
		
		Address a = PlayerTestData.createAddress(systemTestFixture.matoGrossoDoSul, systemTestFixture.vilaNova, systemTestFixture.brazil);

		Customer newcustomer = new Customer(RandomTestData.createRandomString(5), PlayerTestData.createDocument(systemTestFixture.documentCnpj, "777777"), a, RandomTestData.createRandomString(5));
		
		saveAndFlush(newcustomer);
		
		HeadOffice head = new HeadOffice(newcustomer, newcustomer, ParticipantTypeEnum.DISTRIBUTOR, systemTestFixture.soy, systemTestFixture.monsantoBr);
		saveAndFlush(head);

		saleService.getAllowedBy("777777", null, null, ParticipantTypeEnum.DISTRIBUTOR, accessControlTestFixture.participantUser); 
	}
	
	@Test
	public void when_customer_exist_and_user_has_access_should_return_a_Customer()
			throws CustomerNotAllowedException, CustomerNotFoundException, DocumentMismatchException {
		
		UserContract userContract = new UserContract(accessControlTestFixture.itsParticipantUser, saleTestFixture.contract, saleTestFixture.customer, HierarchyLevel.HEAD_OFFICE);
		saveAndFlush(userContract);
		accessControlTestFixture.participantUser.addUserContract(userContract);
		accessControlTestFixture.participantUser.setContextCrop(systemTestFixture.soy);
		Customer customerFound = saleService.getAllowedBy("77784236909725", null,null, ParticipantTypeEnum.DISTRIBUTOR, accessControlTestFixture.participantUser);
		
		Assert.assertTrue("Customer was found", customerFound != null);
		Assert.assertEquals("Customer is the correct one", "77784236909725", customerFound.getDocument().getValue());
		
	}
	
	@Test
	public void when_customer_exist_and_user_is_super_should_return_a_Customer()
			throws CustomerNotAllowedException, CustomerNotFoundException, DocumentMismatchException {
		
		accessControlTestFixture.superUser.setContextCompany(systemTestFixture.monsantoBr);
		accessControlTestFixture.superUser.setContextCrop(systemTestFixture.soy);
		Customer customerFound = saleService.getAllowedBy("77784236909725", null, null, ParticipantTypeEnum.DISTRIBUTOR, accessControlTestFixture.superUser);
		
		Assert.assertTrue("Customer was found", customerFound != null);
		Assert.assertEquals("Customer is the correct one", "77784236909725", customerFound.getDocument().getValue());
	}

	@Test
	public void when_customer_exist_and_user_is_admin_should_return_a_Customer()
			throws CustomerNotAllowedException, CustomerNotFoundException, DocumentMismatchException {
		
		accessControlTestFixture.userAdminOfMonsantoBr.setContextCompany(systemTestFixture.monsantoBr);
		accessControlTestFixture.userAdminOfMonsantoBr.setContextCrop(systemTestFixture.soy);
		Customer customerFound = saleService.getAllowedBy("77784236909725", null, null, ParticipantTypeEnum.DISTRIBUTOR, accessControlTestFixture.userAdminOfMonsantoBr);
		
		Assert.assertTrue("Customer was found", customerFound != null);
		Assert.assertEquals("Customer is the correct one", "77784236909725", customerFound.getDocument().getValue());
		
	}
	
	@Test
	public void when_saleTemplateHasProduct_getProductsBy_shouldBeReturnListOfValues() {
		SaleTemplate theTemplate = SaleTemplateTestData.createSaleTemplateTypeSeedSale(saleTestFixture.harvest2011SoyMonsanto);
		saveAndFlush(theTemplate);
		SaleTemplateToProduct templateXProduct = new SaleTemplateToProduct(theTemplate, saleTestFixture.productIntactaSoy);
		saveAndFlush(templateXProduct);

		ProductFilter productFilter = ProductFilter.getInstance().add(theTemplate);
		List<Product> products = saleService.getProductsBy(productFilter);

		Assert.assertEquals("Should have 1 product", 1, products.size());
	}

	@Test
	public void when_saleTemplateHasTwoProducts_getProductsByFilterWithSaleTemplate_shouldBeReturnTwoValues() throws BusinessException {
		SaleTemplate theTemplate = createSaleTemplateAssociatedWithTwoProducts();

		ProductFilter productFilter = ProductFilter.getInstance().add(theTemplate);
		Assert.assertEquals("Should have 2 product", 2, saleService.getProductsBy(productFilter).size());
	}

	@Test
	public void when_saleTemplateHasTwoProducts_getProductsByFilterWithSaleTemplateAndDescription_shouldBeReturnOneValue() throws BusinessException {
		SaleTemplate theTemplate = createSaleTemplateAssociatedWithTwoProducts();

		ProductFilter productFilter = ProductFilter.getInstance().add(theTemplate).addProductDescription("precio");
		Assert.assertEquals("Should have 1 product", 1, saleService.getProductsBy(productFilter).size());
	}

	@Test(expected=SaleConstraintViolationException.class)
	public void when_i_register_a_saleWithInvalidFields_shouldBeReturned_ConstraintViolationException() throws SaleConstraintViolationException {
		
		Sale sale = new Sale(saleTestFixture.matrixCargil, saleTestFixture.chicoBento);
		sale.setSaleType(SaleTypeEnum.SALE_SEED);

		Assert.assertNull("State value must be null", sale.getState());
		
		saleService.save(sale, accessControlTestFixture.superUser);
		
	}
	
	@Test(expected=SaleConstraintViolationException.class)
	public void when_i_register_a_saleWithInvalidInvoiceValues_shouldBeReturned_ConstraintViolationException() throws BusinessException {
		
		Sale sale = new Sale(saleTestFixture.matrixCargil, saleTestFixture.chicoBento);
		sale.setSaleType(SaleTypeEnum.SALE_SEED);
		
		sale.setState(systemTestFixture.matoGrossoDoSul);
		
		SaleTemplate saleTemplate = createAConsistentSaleTemplateWithHeadOffice();
		
		AbstractPrice price = new Range(saleTemplate,systemTestFixture.intacta);
		RoyaltyValue royaltyValue = new RoyaltyValue(BigDecimal.ONE);
		royaltyValue.setPrice(price);
		price.addRoyaltyValue(royaltyValue);
		saleTemplate.addPrices(price);
		
		saleTemplate.getInvoice().setDocumentRequired(Boolean.TRUE);
		SaleItem item = new SaleItem(sale, saleTemplate, saleTestFixture.productIntactaSoy, null);
		
		sale.getItems().add(item);
		
		Assert.assertNull("Invoice number value must be null", sale.getInvoiceNumber());
		Assert.assertNull("Invoice date value must be null", sale.getInvoiceDate());
		
		saleService.save(sale, accessControlTestFixture.superUser);
		
	}
	
	
	@Test
	public void when_i_register_a_saleWithInvoiceDocumentRequired() throws BusinessException {
		
		Sale sale = new Sale(saleTestFixture.matrixCargil, saleTestFixture.chicoBento);
		sale.setSaleType(SaleTypeEnum.SALE_SEED);
		
		sale.setState(systemTestFixture.matoGrossoDoSul);
		
		SaleTemplate saleTemplate = createSaleTemplateAssociatedWithTwoProducts();
		saleTemplate.getInvoice().setDocumentRequired(Boolean.TRUE);
		Date now = new Date();
		saleTemplate.getInvoice().setDtInitial(now);
		createAndAddFixPriceOfIntactaTechnologyToSaleTemplate(saleTemplate);
		saveAndFlush(saleTemplate);
		
		SaleTestData.createSaleItem(sale, saleTemplate, saleTestFixture.productIntactaSoy, null);
		
		sale.getItems().iterator().next().setPlantability("TextPlantability");
		sale.getItems().iterator().next().setProductivityValue(BigDecimal.valueOf(10L));
		
		sale.setInvoiceDate(new Date(now.getTime() + 1));
		sale.setInvoiceNumber(null);
		
		Assert.assertEquals("Invoice date value must be equals now", now.getTime() + 1, sale.getInvoiceDate().getTime());
		
		try {
			saleService.save(sale, accessControlTestFixture.superUser);
			Assert.fail("Should not return a ContraintViolation");
		} catch (SaleConstraintViolationException e) {
			verifyConstraintMessage("Invoice number value is required.", e);
		}
	}

	@Test(expected=SaleConstraintViolationException.class)
	public void when_i_register_a_saleWithInvoiceDocumentRequiredWithInvalidInvoiceDate() throws BusinessException {
		
		Sale sale = new Sale(saleTestFixture.matrixCargil, saleTestFixture.chicoBento);
		sale.setSaleType(SaleTypeEnum.SALE_SEED);
		
		sale.setState(systemTestFixture.matoGrossoDoSul);
		

		SaleTemplate saleTemplate = createAConsistentSaleTemplateWithHeadOffice();
				
		AbstractPrice price = new Range(saleTemplate,systemTestFixture.intacta);
		RoyaltyValue royaltyValue = new RoyaltyValue(BigDecimal.ONE);
		royaltyValue.setPrice(price);
		price.addRoyaltyValue(royaltyValue);
		saleTemplate.addPrices(price);
		
		saleTemplate.getInvoice().setDocumentRequired(Boolean.TRUE);
		Date now = new Date();
		saleTemplate.getInvoice().setDtInitial(now);
		SaleItem item = new SaleItem(sale, saleTemplate, saleTestFixture.productIntactaSoy, null);
		
		sale.setInvoiceDate(new Date(now.getTime() - 1));
		sale.setInvoiceNumber("12345");
			sale.getItems().add(item);
		
		Assert.assertNotSame("Invoice date value must not be equals now", now, sale.getInvoiceDate());
		
		saleService.save(sale, accessControlTestFixture.superUser);
		
	}
	
	@Test(expected=SaleConstraintViolationException.class)
	public void when_i_register_a_saleWithEmptyCreationDate_shouldBeReturned_ConstraintViolationException() throws SaleConstraintViolationException {
		Sale sale = new Sale(saleTestFixture.matrixCargil, saleTestFixture.chicoBento);
		sale.setSaleType(SaleTypeEnum.SALE_SEED);
		sale.setState(systemTestFixture.matoGrossoDoSul);
		sale.setCreationDate(null);
		
		saleService.save(sale, accessControlTestFixture.superUser);
	}	
	
	@Test
    @Ignore
	public void when_i_register_a_customer_and_grower_required_shouldBeReturned_ConstraintViolationException() {
		
		Sale sale = new Sale(new Customer(null, null, null, RandomTestData.createRandomString(5)), new Grower());
		sale.setSaleType(SaleTypeEnum.SALE_SEED);

		Assert.assertNull("State value must be null", sale.getState());
		
		try {
			saleService.save(sale, accessControlTestFixture.superUser);
			Assert.fail("Should not return a ContraintViolation");
		} catch (SaleConstraintViolationException e) {
			verifyConstraintMessage("Customer is required.", e);
			verifyConstraintMessage("Grower is required.", e);
		}
	}
	
	@Test
	public void when_i_register_a_customer_and_grower_invalid_shouldBeReturned_ConstraintViolationException() {
		
		Document documentGrower = PlayerTestData.createDocument(this.systemTestFixture.documentCnpj, "77438888685761");
		Address address = PlayerTestData.createAddress(this.systemTestFixture.matoGrossoDoSul, this.systemTestFixture.vilaNova, this.systemTestFixture.brazil);
		
		Customer wrongCustomer = new Customer(
				RandomTestData.createRandomString(5), 
				PlayerTestData.createDocument(systemTestFixture.documentCnpj, "77915226984724"), 
				address, RandomTestData.createRandomNumberAsString(10));
		Grower grower = PlayerTestData.createGrower(
				documentGrower, 
				PlayerTestData.createBillingAddress(this.systemTestFixture.matoGrossoDoSul, this.systemTestFixture.vilaNova, this.systemTestFixture.brazil), 
				PlayerTestData.createBusinessAddress(this.systemTestFixture.matoGrossoDoSul, this.systemTestFixture.vilaNova, this.systemTestFixture.brazil));
		
		Sale sale = new Sale(wrongCustomer, grower);
		sale.setSaleType(SaleTypeEnum.SALE_SEED);

		Assert.assertNull("State value must be null", sale.getState());
		
		try {
			saleService.save(sale, accessControlTestFixture.superUser);
			Assert.fail("Should not return a ContraintViolation");
		} catch (SaleConstraintViolationException e) {
			verifyConstraintMessage("Customer not found.", e);
			verifyConstraintMessage("Grower not found.", e);
		}
	}
	
	@Test
	public void when_i_register_a_customer_duplicate_invalid_shouldBeReturned_ConstraintViolationException() {
		
		Document documentGrower = PlayerTestData.createDocument(this.systemTestFixture.documentCnpj, "99991239912399388");
		Address a = PlayerTestData.createAddress(systemTestFixture.matoGrossoDoSul, systemTestFixture.vilaNova, systemTestFixture.brazil);
		
		Customer newcustomer = new Customer(
				RandomTestData.createRandomString(5),
				PlayerTestData.createDocument(systemTestFixture.documentCnpj,
						"77915226984724"), a, "234");
		newcustomer.setStateRegistration("12345678");
		
		
		saveAndFlush(newcustomer);
		
		Customer new2customer = new Customer(
				RandomTestData.createRandomString(5),
				PlayerTestData.createDocument(systemTestFixture.documentCnpj,
						"77915226984724"), a, "234");
		new2customer.setStateRegistration("12345679");
		
		
		saveAndFlush(new2customer);
		
		HeadOffice head = new HeadOffice(newcustomer, newcustomer,
				ParticipantTypeEnum.DISTRIBUTOR, systemTestFixture.soy,
				systemTestFixture.monsantoBr);
		saveAndFlush(head);
		
		HeadOffice head2 = new HeadOffice(new2customer, new2customer,
				ParticipantTypeEnum.DISTRIBUTOR, systemTestFixture.soy,
				systemTestFixture.monsantoBr);
		saveAndFlush(head2);
		
		Grower grower = PlayerTestData.createGrower(
				documentGrower, 
				PlayerTestData.createBillingAddress(this.systemTestFixture.matoGrossoDoSul, this.systemTestFixture.vilaNova, this.systemTestFixture.brazil), 
				PlayerTestData.createBusinessAddress(this.systemTestFixture.matoGrossoDoSul, this.systemTestFixture.vilaNova, this.systemTestFixture.brazil));
		
		Customer customerDuplicate = new Customer(null,
				PlayerTestData.createDocument(systemTestFixture.documentCnpj,
						"77915226984724"), a, "234");
		

		
		Sale sale = new Sale(customerDuplicate, grower);
		sale.setSaleType(SaleTypeEnum.SALE_SEED);

		Assert.assertNull("State value must be null", sale.getState());
		
		try {
			UserDecorator superUser = accessControlTestFixture.superUser;
			saleService.save(sale, superUser);
			Assert.fail("Should not return a ContraintViolation");
		} catch (SaleConstraintViolationException e) {
			verifyConstraintMessage("Customer document number mismatch.", e);
		}
	}
	
	@Test
	public void when_i_register_a_customer_not_allowed_shouldBeReturned_ConstraintViolationException() {
		
		Document documentGrower = PlayerTestData.createDocument(this.systemTestFixture.documentCnpj, "99991239912399388");
		
		Grower grower = PlayerTestData.createGrower(
				documentGrower, 
				PlayerTestData.createBillingAddress(systemTestFixture.matoGrossoDoSul, systemTestFixture.vilaNova, systemTestFixture.brazil), 
				PlayerTestData.createBusinessAddress(systemTestFixture.matoGrossoDoSul, systemTestFixture.vilaNova, systemTestFixture.brazil));
		
		Sale sale = new Sale(saleTestFixture.customer, grower);
		sale.setSaleType(SaleTypeEnum.SALE_SEED);

		Assert.assertNull("State value must be null", sale.getState());
		
		try {
			UserDecorator userDecorator = new UserDecorator(accessControlTestFixture.itsParticipantUser,accessControlTestFixture.itsParticipantUser);
			userDecorator.setContextCrop(systemTestFixture.soy);
			saleService.save(sale, userDecorator);
			Assert.fail("Should not return a ContraintViolation");
		} catch (SaleConstraintViolationException e) {
			verifyConstraintMessage("Customer not allowed.", e);
		}
	}
	
	@Test
	public void when_i_register_sale_without_saleItem_shouldBeReturned_ConstraintViolationException()  {
		
		Sale sale = saleFactory.createSale(saleTestFixture.matrixCargil, saleTestFixture.chicoBento, SaleTypeEnum.SALE_SEED);
		sale.setSaleType(SaleTypeEnum.SALE_SEED);
		
		try {
			saleService.save(sale, accessControlTestFixture.superUser);
			Assert.fail("Should not return a ContraintViolation");
		} catch (SaleConstraintViolationException e) {
			verifyConstraintMessage("List of product is required.", e);
		}
	}
	
	@Test
	public void when_i_register_harvest_required_shouldBeReturned_ConstraintViolationException() throws BusinessException {
		
		Sale sale = saleFactory.createSale(saleTestFixture.matrixCargil, saleTestFixture.chicoBento, SaleTypeEnum.SALE_SEED);
		sale.setSaleType(SaleTypeEnum.SALE_SEED);

		SaleTemplate saleTemplate1 = createAConsistentSaleTemplateWithHeadOffice();
		
		saleTemplate1.getHarvest().setDescription(null);
		Product product = ProductTestData.createProduct();
		product.setId(1L);
		
		SaleTestData.createSaleItem(sale, saleTemplate1, product, null);
		
		try {
			saleService.save(sale, accessControlTestFixture.superUser);
			Assert.fail("Should not return a ContraintViolation");
		} catch (SaleConstraintViolationException e) {
			verifyConstraintMessage("Harvest is required.", e);
		}
	}
	
	@Test
	public void when_i_register_company_required_shouldBeReturned_ConstraintViolationException() throws BusinessException {
		
		Sale sale = saleFactory.createSale(saleTestFixture.matrixCargil, saleTestFixture.chicoBento, SaleTypeEnum.SALE_SEED);
		
		SaleTemplate saleTemplate1 = createAConsistentSaleTemplateWithHeadOffice();
		
		saleTemplate1.getHarvest().getCompany().setDescription(null);
		Product product = ProductTestData.createProduct();
		product.setId(1L);
		
		SaleTestData.createSaleItem(sale, saleTemplate1, product, null);
		
		try {
			saleService.save(sale, accessControlTestFixture.superUser);
			Assert.fail("Should not return a ContraintViolation");
		} catch (SaleConstraintViolationException e) {
			verifyConstraintMessage("Company is required.", e);
		}
	}
	
	@Test
	public void when_i_register_crop_required_shouldBeReturned_ConstraintViolationException() throws BusinessException {
		
		Sale sale = saleFactory.createSale(saleTestFixture.matrixCargil, saleTestFixture.chicoBento, SaleTypeEnum.SALE_SEED);
		
		SaleTemplate saleTemplate1 = createAConsistentSaleTemplateWithHeadOffice();
		
		saleTemplate1.getHarvest().getCrop().setDescription(null);
		Product product = ProductTestData.createProduct();
		product.setId(1L);
		
		SaleTestData.createSaleItem(sale, saleTemplate1, product, null);
		
		try {
			saleService.save(sale, accessControlTestFixture.superUser);
			Assert.fail("Should not return a ContraintViolation");
		} catch (SaleConstraintViolationException e) {
			verifyConstraintMessage("Crop is required.", e);
		}
	}
	
	@Test
	public void when_i_register_saletemplate_required_shouldBeReturned_ConstraintViolationException() {
		
		Sale sale = saleFactory.createSale(saleTestFixture.matrixCargil, saleTestFixture.chicoBento, SaleTypeEnum.SALE_SEED);
		Product product = ProductTestData.createProduct();
		product.setId(1L);
		SaleTemplate saleTemplate = SaleTemplateTestData.createSaleTemplateTypeSeedSale(saleTestFixture.harvest2011SoyMonsanto);
		saleTemplate.setDescription(null);
		
		SaleTestData.createSaleItem(sale, saleTemplate, product, null);
		
		try {
			saleService.save(sale, accessControlTestFixture.superUser);
			Assert.fail("Should not return a ContraintViolation");
		} catch (SaleConstraintViolationException e) {
			verifyConstraintMessage("Sale Template is required.", e);
		}
	}
	
	@Test
	public void when_i_register_product_required_shouldBeReturned_ConstraintViolationException() {
		
		Sale sale = saleFactory.createSale(saleTestFixture.matrixCargil, saleTestFixture.chicoBento, SaleTypeEnum.SALE_SEED);
		SaleTemplate saleTemplate = SaleTemplateTestData.createSaleTemplateTypeSeedSale(saleTestFixture.harvest2011SoyMonsanto);
		Product product = ProductTestData.createProduct();
		SaleTestData.createSaleItem(sale, saleTemplate, product, null);
		
		try {
			saleService.save(sale, accessControlTestFixture.superUser);
			Assert.fail("Should not return a ContraintViolation");
		} catch (SaleConstraintViolationException e) {
			verifyConstraintMessage("Product is required.", e);
		}
	}
	
	@Test
	public void when_i_register_plantability_required_shouldBeReturned_ConstraintViolationException() {
		
		Sale sale = saleFactory.createSale(saleTestFixture.matrixCargil, saleTestFixture.chicoBento, SaleTypeEnum.SALE_SEED);
		
		SaleTemplate saleTemplate = SaleTemplateTestData.createSaleTemplateTypeSeedSale(saleTestFixture.harvest2011SoyMonsanto);
		Product product = ProductTestData.createProduct();
		product.setId(1L);
		SaleTestData.createSaleItem(sale, saleTemplate, product, null);
		
		sale.getItems().iterator().next().setPlantability(null);
		
		try {
			saleService.save(sale, accessControlTestFixture.superUser);
			Assert.fail("Should not return a ContraintViolation");
		} catch (SaleConstraintViolationException e) {
			verifyConstraintMessage("Plantability is required.", e);
		}
	}
	
	@Test
	public void when_i_register_productivity_required_shouldBeReturned_ConstraintViolationException() {
		
		Sale sale = saleFactory.createSale(saleTestFixture.matrixCargil, saleTestFixture.chicoBento, SaleTypeEnum.SALE_SEED);
		
		SaleTemplate saleTemplate = SaleTemplateTestData.createSaleTemplateTypeSeedSale(saleTestFixture.harvest2011SoyMonsanto);
		Product product = ProductTestData.createProduct();
		product.setId(1L);
		SaleTestData.createSaleItem(sale, saleTemplate, product, null);
		
		sale.getItems().iterator().next().setProductivityValue(null);
		
		try {
			saleService.save(sale, accessControlTestFixture.superUser);
			Assert.fail("Should not return a ContraintViolation");
		} catch (SaleConstraintViolationException e) {
			verifyConstraintMessage("Productivity is required.", e);
		}
	}
	
	
	@Test
	public void when_i_register_product_invactive_shouldBeReturned_ConstraintViolationException()
			throws BusinessException {
		Sale sale = new Sale(saleTestFixture.matrixCargil,
				saleTestFixture.chicoBento);
		sale.setSaleType(SaleTypeEnum.SALE_SEED);

		sale.setState(systemTestFixture.matoGrossoDoSul);

		SaleTemplate saleTemplate = createAConsistentSaleTemplateWithHeadOffice();

		AbstractPrice price = new Range(saleTemplate, systemTestFixture.intacta);
		RoyaltyValue royaltyValue = new RoyaltyValue(BigDecimal.ONE);
		royaltyValue.setPrice(price);
		price.addRoyaltyValue(royaltyValue);
		saleTemplate.addPrices(price);

		saleTemplate.setIsShowNoteMandatory(Boolean.TRUE);
		saleTestFixture.productIntactaSoy.setStatus(StatusEnum.INACTIVE);
		saveAndFlush(saleTestFixture.productIntactaSoy);
		SaleItem item = new SaleItem(sale, saleTemplate,
				saleTestFixture.productIntactaSoy, null);

		item.setPlantability("TextPlantability");
		item.setProductivityValue(BigDecimal.valueOf(10L));
		sale.setSaleNote("SALENOTETEXT");
		sale.getItems().add(item);

		try {
			saleService.save(sale, accessControlTestFixture.superUser);
			Assert.fail("Should not return a ContraintViolation");
		} catch (SaleConstraintViolationException e) {
			verifyConstraintMessage("Product is invalid.", e);
		}

	}
	
	@Test(expected=SaleConstraintViolationException.class)
	public void when_i_register_a_saleWithNullSaleNote_shouldBeReturned_ConstraintViolationException() throws BusinessException {
		
		Sale sale = new Sale(saleTestFixture.matrixCargil, saleTestFixture.chicoBento);
		sale.setSaleType(SaleTypeEnum.SALE_SEED);		
		sale.setState(systemTestFixture.matoGrossoDoSul);
		

		SaleTemplate saleTemplate = createAConsistentSaleTemplateWithHeadOffice();
		
		AbstractPrice price = new Range(saleTemplate,systemTestFixture.intacta);
		RoyaltyValue royaltyValue = new RoyaltyValue(BigDecimal.ONE);
		royaltyValue.setPrice(price);
		price.addRoyaltyValue(royaltyValue);
		saleTemplate.addPrices(price);
		
		saleTemplate.setIsShowNoteMandatory(Boolean.TRUE);
		SaleItem item = new SaleItem(sale, saleTemplate, saleTestFixture.productIntactaSoy, null);
		
		item.setPlantability("TextPlantability");
		item.setProductivityValue(BigDecimal.valueOf(10L));
		sale.getItems().add(item);
		
		Assert.assertNull("Sale Note value must be null", sale.getSaleNote());
		
		saleService.save(sale, accessControlTestFixture.superUser);
		
	}
	
	@Test (expected=SaleConstraintViolationException.class)
	public void when_i_register_a_saleWithSaleNote_shouldReturnSuccess() throws BusinessException {
		
		Sale sale = new Sale(saleTestFixture.matrixCargil, saleTestFixture.chicoBento);
		sale.setSaleType(SaleTypeEnum.SALE_SEED);
		
		sale.setState(systemTestFixture.matoGrossoDoSul);
		
		SaleTemplate saleTemplate = createAConsistentSaleTemplateWithHeadOffice();
		
		AbstractPrice price = new Range(saleTemplate,systemTestFixture.intacta);
		RoyaltyValue royaltyValue = new RoyaltyValue(BigDecimal.ONE);
		royaltyValue.setPrice(price);
		price.addRoyaltyValue(royaltyValue);
		saleTemplate.addPrices(price);
		
		saleTemplate.setIsShowNoteMandatory(Boolean.TRUE);
		SaleItem item = new SaleItem(sale, saleTemplate, saleTestFixture.productIntactaSoy, null);
		
		item.setPlantability("TextPlantability");
		item.setProductivityValue(BigDecimal.valueOf(10L));
		sale.setSaleNote("SALENOTETEXT");
		sale.getItems().add(item);
		
		Assert.assertEquals("SALENOTETEXT", sale.getSaleNote());		
		saleService.save(sale, accessControlTestFixture.superUser);
		
	}
	
	
	
	
	@Test
	public void when_i_register_a_sale_withoutSoldQuantity_shouldBeReturned_a_constraintViolationException() {
		
		Sale sale = saleFactory.createSale(saleTestFixture.matrixCargil, saleTestFixture.chicoBento, SaleTypeEnum.SALE_SEED);
		
		SaleTemplate saleTemplate = SaleTemplateTestData.createSaleTemplateTypeSeedSale(saleTestFixture.harvest2011SoyMonsanto);
		Product product = ProductTestData.createProduct();
		
		SaleTestData.createSaleItem(sale, saleTemplate, product, null);
		
		sale.getItems().iterator().next().setSoldQuantity(null);
		
		try {
			saleService.save(sale, accessControlTestFixture.superUser);
			Assert.fail("Should not return a ContraintViolation");
		} catch (SaleConstraintViolationException e) {
			verifyConstraintMessage("Sold quantity is required.", e);
		}
	}
	
	@Test
	public void when_i_register_a_sale_SoldQuantity_ZERO_shouldBeReturned_a_constraintViolationException() {
		
		Sale sale = saleFactory.createSale(saleTestFixture.matrixCargil, saleTestFixture.chicoBento, SaleTypeEnum.SALE_SEED);
		
		SaleTemplate saleTemplate = SaleTemplateTestData.createSaleTemplateTypeSeedSale(saleTestFixture.harvest2011SoyMonsanto);
		Product product = ProductTestData.createProduct();
		
		SaleTestData.createSaleItem(sale, saleTemplate, product, null);
		
		sale.getItems().iterator().next().setSoldQuantity(0L);
		
		try {
			saleService.save(sale, accessControlTestFixture.superUser);
			Assert.fail("Should not return a ContraintViolation");
		} catch (SaleConstraintViolationException e) {
			verifyConstraintMessage("Sold quantity is required.", e);
		}
	}
	
	@Test
	public void when_i_register_a_sale_without_saleType_shouldBeReturned_a_constraintViolationException() {
		
		Sale sale = saleFactory.createSale(saleTestFixture.matrixCargil, saleTestFixture.chicoBento, null);
		
		SaleTemplate saleTemplate = SaleTemplateTestData.createSaleTemplateTypeSeedSale(saleTestFixture.harvest2011SoyMonsanto);
		Product product = ProductTestData.createProduct();
		
		SaleTestData.createSaleItem(sale, saleTemplate, product, null);
		
		sale.getItems().iterator().next().setSoldQuantity(null);
		
		try {
			saleService.save(sale, accessControlTestFixture.superUser);
		} catch (SaleConstraintViolationException e) {
			verifyConstraintMessage("Sale type is required.", e);
		}
	}
	
	@Test
	public void when_i_register_sale_with_saletemplate_by_different_plantability_shouldBeReturned_ConstraintViolationException() throws BusinessException {
		
		Sale sale = saleFactory.createSale(saleTestFixture.matrixCargil, saleTestFixture.chicoBento, SaleTypeEnum.SALE_SEED);
		
		SaleTemplate saleTemplate1 = createAConsistentSaleTemplateWithHeadOffice();
		
		saleTemplate1.setPlantabilityBy(SaleTemplateByPlantabilityEnum.BY_SALE_TEMPLATE);
		
		Product productIntactaSoy = ProductTestData.createProduct(systemTestFixture.monsoy, systemTestFixture.soy, systemTestFixture.intacta, StatusEnum.ACTIVE, systemTestFixture.monsantoBr);
		saveAndFlush(productIntactaSoy);
		
		SaleItem item = SaleTestData.createSaleItem(sale, saleTemplate1, saleTestFixture.productIntactaSoy, null);
		item.setPlantability(saleTestFixture.plantabilitySystemOfHarvest2011Soy.getDescription());
		SaleItem item2 = SaleTestData.createSaleItem(sale, saleTemplate1, productIntactaSoy, null);
		item2.setPlantability(saleTestFixture.anotherPlantability.getDescription());
		
		try {
			saleService.save(sale, accessControlTestFixture.superUser);
			Assert.fail("Should not return a ContraintViolation");
		} catch (SaleConstraintViolationException e) {
			verifyConstraintMessage("All items in sale of the sales model must have the same plantability.", e);
		}
	}
	
	@Test
	public void when_i_register_sale_with_saletemplate_whith_plantability_inactive_ConstraintViolationException() throws BusinessException {
		
		Sale sale = saleFactory.createSale(saleTestFixture.matrixCargil, saleTestFixture.chicoBento, SaleTypeEnum.SALE_SEED);
		
		SaleTemplate saleTemplate1 = createAConsistentSaleTemplateWithHeadOffice();
		
		saleTemplate1.setPlantabilityBy(SaleTemplateByPlantabilityEnum.BY_SALE_TEMPLATE);
		
		
		Product productIntactaSoy = ProductTestData.createProduct(systemTestFixture.monsoy, systemTestFixture.soy, systemTestFixture.intacta, StatusEnum.INACTIVE, systemTestFixture.monsantoBr);
		saveAndFlush(productIntactaSoy);
		
		SaleItem item = SaleTestData.createSaleItem(sale, saleTemplate1, saleTestFixture.productIntactaSoy, null);
		item.setPlantability(saleTestFixture.plantabilitySystemSoyMonsanto2012.getDescription());
		SaleItem item2 = SaleTestData.createSaleItem(sale, saleTemplate1, productIntactaSoy, null);
		item2.setPlantability(saleTestFixture.anotherPlantability.getDescription());
		saleTestFixture.anotherPlantability.setStatus(StatusEnum.INACTIVE);
		saveAndFlush(saleTestFixture.anotherPlantability);
		
		try {
			saleService.save(sale, accessControlTestFixture.superUser);
		} catch (SaleConstraintViolationException e) {
			verifyConstraintMessage("All items in sale of the sales model must have the same plantability.", e);
		}
	}
	
	@Test
	public void when_i_register_sale_with_saletemplate_by_different_duedate_shouldBeReturned_ConstraintViolationException() throws BusinessException {
		
		Product productIntactaSoy = ProductTestData.createProduct(systemTestFixture.monsoy, systemTestFixture.soy, systemTestFixture.intacta, StatusEnum.ACTIVE, systemTestFixture.monsantoBr);
		saveAndFlush(productIntactaSoy);
		
		Sale sale = saleFactory.createSale(saleTestFixture.matrixCargil, saleTestFixture.chicoBento, SaleTypeEnum.SALE_SEED);
		
		SaleTemplate saleTemplate1 = createAConsistentSaleTemplateWithHeadOffice();
		
		saleTemplate1.setPlantabilityBy(SaleTemplateByPlantabilityEnum.BY_SALE_TEMPLATE);
		
		SaleItem item = SaleTestData.createSaleItem(sale, saleTemplate1, saleTestFixture.productIntactaSoy, null);
		item.setDueDate(randomDate(Calendar.MONTH,0));
		item.setPlantability(saleTestFixture.plantabilitySystemOfHarvest2011Soy.getDescription());
		
		SaleItem item2 = SaleTestData.createSaleItem(sale, saleTemplate1, productIntactaSoy, null);
		item2.setPlantability(saleTestFixture.plantabilitySystemOfHarvest2011Soy.getDescription());
		item2.setDueDate(randomDate(Calendar.MONTH,-1));
		
		try {
			saleService.save(sale, accessControlTestFixture.superUser);
			Assert.fail("Should not return a ContraintViolation");
		} catch (SaleConstraintViolationException e) {
			verifyConstraintMessage("All items in sale of the sales model and techology must have the same due date.", e);
		}
	}
	
	@Test
	public void when_i_register_sale_with_priceBySeed_invalid_shouldBeReturned_ConstraintViolationException() throws BusinessException {
		
		
		SaleTemplate saleTemplate1 = SaleTemplateTestData.createSaleTemplateTypeSeedSale(saleTestFixture.harvest2011SoyMonsanto);
		
		AbstractPrice price = new Range(saleTemplate1,systemTestFixture.intacta);
		RoyaltyValue royaltyValueOne = new RoyaltyValue(BigDecimal.ONE);
		RoyaltyValue royaltyValueFive = new RoyaltyValue(new BigDecimal(5));
		
		royaltyValueOne.setPrice(price);
		royaltyValueFive.setPrice(price);
		
		price.addRoyaltyValue(royaltyValueOne);
		price.addRoyaltyValue(royaltyValueFive);
		
		Date now = new Date();
		
		price.addDueDate(new DueDateValue(now));
		
		saleTemplate1.addPrices(price);
		getSession().saveOrUpdate(saleTemplate1);
		
		// When i create a sale item with a value(in this case 11) greater than the range (1 to 5) of price an exception should be returned
		Sale sale = saleFactory.createSale(saleTestFixture.matrixCargil, saleTestFixture.chicoBento, SaleTypeEnum.SALE_SEED);
		SaleItem item = SaleTestData.createSaleItem(sale, saleTemplate1, saleTestFixture.productIntactaSoy, null);
		item.setDueDate(now);
		item.setPriceQuantity(new BigDecimal(23));
		item.setPlantability(saleTestFixture.plantabilitySystemOfHarvest2011Soy.getDescription());
		
		try {
			saleService.save(sale, accessControlTestFixture.superUser);
			Assert.fail("Should not return a ContraintViolation");
		} catch (SaleConstraintViolationException e) {
			verifyConstraintMessage("Value price per kg of seed out of range.", e);
		}
	}
	
	@Test
	public void when_i_register_sale_with_duedate_required_shouldBeReturned_ConstraintViolationException() throws BusinessException {
		Sale sale = saleFactory.createSale(saleTestFixture.matrixCargil, saleTestFixture.chicoBento, SaleTypeEnum.SALE_SEED);
		
		SaleTemplate saleTemplate = createAConsistentSaleTemplateWithHeadOffice();
		
		AbstractPrice price = new Range(saleTemplate,systemTestFixture.intacta);
		RoyaltyValue royaltyValue = new RoyaltyValue(BigDecimal.ONE);
		royaltyValue.setPrice(price);
		price.addRoyaltyValue(royaltyValue);
		saleTemplate.addPrices(price);
		
		SaleTestData.createSaleItem(sale, saleTemplate, saleTestFixture.productIntactaSoy, null);
		
		sale.getItems().iterator().next().setDueDate(null);
		
		try {
			saleService.save(sale, accessControlTestFixture.superUser);
			Assert.fail("Should return a ContraintViolation");
		} catch (SaleConstraintViolationException e) {
			verifyConstraintMessage("Due date is required.", e);
		}
	}
	
	@Test
	public void when_i_register_sale_with_duedate_invalid_shouldBeReturned_ConstraintViolationException() throws BusinessException {
		
		Sale sale = saleFactory.createSale(saleTestFixture.matrixCargil, saleTestFixture.chicoBento, SaleTypeEnum.SALE_SEED);
		
		SaleTemplate saleTemplate = SaleTemplateTestData.createSaleTemplateTypeSeedSale(saleTestFixture.harvest2011SoyMonsanto);
		
		AbstractPrice price = new Range(saleTemplate,systemTestFixture.intacta);
		RoyaltyValue royaltyValue = new RoyaltyValue(BigDecimal.ONE);
		royaltyValue.setPrice(price);
		price.addRoyaltyValue(royaltyValue);
		
		price.addDueDate(new DueDateValue(randomDate(Calendar.MONTH,0)));
		price.addDueDate(new DueDateValue(randomDate(Calendar.MONTH,2)));
		
		saleTemplate.addPrices(price);
		getSession().saveOrUpdate(saleTemplate);

		SaleTestData.createSaleItem(sale, saleTemplate, saleTestFixture.productIntactaSoy, null);
		
		sale.getItems().iterator().next().setDueDate(randomDate(Calendar.MONTH,3));
		try {
			saleService.save(sale, accessControlTestFixture.superUser);
			Assert.fail("Should not return a ContraintViolation");
		} catch (SaleConstraintViolationException e) {
			verifyConstraintMessage("Value due date out of range.", e);
		}
	}
	
	@Test
	public void when_i_register_sale_with_priceQuantity_required_shouldBeReturned_ConstraintViolationException() throws BusinessException {
		
		Sale sale = saleFactory.createSale(saleTestFixture.matrixCargil, saleTestFixture.chicoBento, SaleTypeEnum.SALE_SEED);
		
		SaleTemplate saleTemplate = createAConsistentSaleTemplateWithHeadOffice();
		
		Price price = saleTemplate.getPriceOf(systemTestFixture.intacta);
		
		saleTemplate.getPrices().remove(price);
		
		price = PriceTestData.createPrice(PriceTypeEnum.RANGE, saleTemplate, this.systemTestFixture.intacta);
		RoyaltyValue royaltyValue = new RoyaltyValue(BigDecimal.ONE);
		royaltyValue.setPrice(price);
		price.addRoyaltyValue(royaltyValue);
		saleTemplate.addPrices(price);
		getSession().saveOrUpdate(saleTemplate);

		SaleTestData.createSaleItem(sale, saleTemplate, saleTestFixture.productIntactaSoy, null);
		
		sale.getItems().iterator().next().setPriceQuantity(null);
		
		try {
			saleService.save(sale, accessControlTestFixture.superUser);
			Assert.fail("Should not return a ContraintViolation");
		} catch (SaleConstraintViolationException e) {
			verifyConstraintMessage("Value price per kg of seed is required.", e);
		}
	}
	
	@Test
	public void when_i_register_sale_with_priceQuantity_notRequired_shouldNotBeReturned_ConstraintViolationException() throws BusinessException {
		
		Sale sale = saleFactory.createSale(saleTestFixture.matrixCargil, saleTestFixture.chicoBento, SaleTypeEnum.SALE_SEED);
		
		SaleTemplate saleTemplate = SaleTemplateTestData.createSaleTemplateTypeSeedSale(saleTestFixture.harvest2011SoyMonsanto);
		
		AbstractPrice price = new NoValue(saleTemplate,systemTestFixture.intacta);
		saleTemplate.addPrices(price);
		
		Product product = ProductTestData.createProduct();
		product.setId(1L);
		product.setTechnology(systemTestFixture.intacta);
		SaleItem item = SaleTestData.createSaleItem(sale, saleTemplate, product, null);
		item.setPriceQuantity(null);
		item.setDueDate(new Date());
		item.setPlantability(saleTestFixture.plantabilitySystemOfHarvest2011Soy.getDescription());
		
		try {
			saleService.save(sale, accessControlTestFixture.superUser);
			Assert.fail("Should not return a ContraintViolation");
		} catch (SaleConstraintViolationException e) {
			List<ConstraintViolation> violations = e.getViolations();
			for (ConstraintViolation constraintViolation : violations) {
				if (constraintViolation.getMessage().equals("Price per kg seed is invalid.")){
					Assert.fail("Should not return a ContraintViolation");
				}
			}
		}
	}
	
	//BEGIN rgaldino
	public void when_i_register_sale_with_harvest_notExisting_shouldReturn_ConstraintViolationException() throws BusinessException {
		Sale sale = saleFactory.createSale(saleTestFixture.matrixCargil, saleTestFixture.chicoBento, SaleTypeEnum.SALE_SEED);
		
		SaleTemplate saleTemplate = SaleTemplateTestData.createSaleTemplateTypeSeedSale(saleTestFixture.harvest2011SoyMonsanto);
		
		Harvest inexistHarvest = HarvestTestData.createABrazilianHarvest();
		
		inexistHarvest.setDescription("InexistHarvest");
		
		AbstractPrice price = new NoValue(saleTemplate,saleTemplate.getHarvest().getCompany().getTechnologies().iterator().next());
		saleTemplate.addPrices(price);
		
		Product product = ProductTestData.createProduct();

		product.setId(1L);
		product.setTechnology(saleTemplate.getHarvest().getCompany().getTechnologies().iterator().next());
		SaleTestData.createSaleItem(sale, saleTemplate, product, null);
		
		sale.getItems().iterator().next().getSaleTemplate().setHarvest(inexistHarvest);
		
		try {
			saleService.save(sale, accessControlTestFixture.superUser);
			Assert.fail("Should not return a ContraintViolation");
		} catch (SaleConstraintViolationException e) {
			List<ConstraintViolation> violations = e.getViolations();
			for (ConstraintViolation constraintViolation : violations) {
				Assert.assertEquals("Invalid Harvest Association.", constraintViolation.getMessage());
			}
		}
	}
	
	@Test
	public void when_i_register_a_saleWithStateInvalid_shouldBeReturned_ConstraintViolationException() throws BusinessException {
		
		Sale sale = new Sale(saleTestFixture.matrixCargil, saleTestFixture.chicoBento);
		sale.setSaleType(SaleTypeEnum.SALE_SEED);
		
		sale.setState(new State(systemTestFixture.brazil, null , "Not found"));
		
		try {
			saleService.save(sale, accessControlTestFixture.superUser);
			Assert.fail("Should not return a ContraintViolation");
		} catch (SaleConstraintViolationException e) {
			verifyConstraintMessage("State value is invalid.", e);
		}
	}
	
	@Test
	public void when_i_register_sale_with_saletemplate_notInVigor_shouldBeReturned_ConstraintViolationException() throws BusinessException {
		
		Sale sale = saleFactory.createSale(saleTestFixture.matrixCargil, saleTestFixture.chicoBento, SaleTypeEnum.SALE_SEED);
		
		SaleTemplate saleTemplate = SaleTemplateTestData.createSaleTemplateTypeSeedSale(saleTestFixture.harvest2011SoyMonsanto);
		saleTemplate.setEndDate(saleTemplate.getStartDate());
		
		getSession().saveOrUpdate(saleTemplate);
		
		Product product = ProductTestData.createProduct();
		product.setId(1L);
		product.setTechnology(saleTemplate.getHarvest().getCompany().getTechnologies().iterator().next());
		SaleTestData.createSaleItem(sale, saleTemplate, product, null);
		
		try {
			saleService.save(sale, accessControlTestFixture.superUser);
			Assert.fail("Should not return a ContraintViolation");
		} catch (SaleConstraintViolationException e) {
			verifyConstraintMessage("Sale Template is not in vigor.", e);
		}
	}
	
	@Test
	public void when_i_register_sale_with_product_invalid_shouldBeReturned_ConstraintViolationException() throws BusinessException {
		
		SaleTemplate saleTemplate = SaleTemplateTestData.createSaleTemplateTypeSeedSale(saleTestFixture.harvest2011SoyMonsanto);
		
		createAndAddFixPriceOfIntactaTechnologyToSaleTemplate(saleTemplate);
		
		getSession().saveOrUpdate(saleTemplate);
		
		Product product = new Product();
		product.setBrand(saleTestFixture.productIntactaSoy.getBrand());
		product.setCompany(saleTestFixture.productIntactaSoy.getCompany());
		product.setCrop(saleTestFixture.productIntactaSoy.getCrop());
		product.setDescription("BLA");
		product.setTechnology(saleTestFixture.productIntactaSoy.getTechnology());
		product.setStatus(StatusEnum.ACTIVE);
		product.setId(1L);
		
		Sale sale = saleFactory.createSale(saleTestFixture.matrixCargil, saleTestFixture.chicoBento, SaleTypeEnum.SALE_SEED);
		sale.setState(saleTestFixture.productivityOfIntactaSoy.getState());
		SaleTestData.createSaleItem(sale, saleTemplate, product, null);
		
		try {
			saleService.save(sale, accessControlTestFixture.superUser);
			Assert.fail("Should not return a ContraintViolation");
		} catch (SaleConstraintViolationException e) {
			verifyConstraintMessage("Product is invalid.", e);
		}
	}
	
    @Ignore
	@Test
	public void when_i_register_sale_with_product_duplicity_shouldBeReturned_ConstraintViolationException() throws BusinessException {
		
		Sale sale = saleFactory.createSale(saleTestFixture.matrixCargil, saleTestFixture.chicoBento, SaleTypeEnum.SALE_SEED);
		
		SaleTemplate saleTemplate = createAConsistentSaleTemplateWithHeadOffice();
		
		getSession().saveOrUpdate(saleTemplate);
		
		SaleTestData.createSaleItem(sale, saleTemplate, saleTestFixture.productIntactaSoy, null);
		SaleTestData.createSaleItem(sale, saleTemplate, saleTestFixture.productBtSoy, null);
		
		for (SaleItem item : sale.getItems()) {
			item.setProduct(saleTestFixture.productIntactaSoy);
		}
		
		try {
			saleService.save(sale, accessControlTestFixture.superUser);
			Assert.fail("Should not return a ContraintViolation");
		} catch (SaleConstraintViolationException e) {
			verifyConstraintMessage("Product duplicate.", e);
		}
	}
	
	@Test
	public void when_i_register_sale_with_plantability_invalid_shouldBeReturned_ConstraintViolationException() throws BusinessException {
		
		SaleTemplate saleTemplate = SaleTemplateTestData.createSaleTemplateTypeSeedSale(saleTestFixture.harvest2011SoyMonsanto);
		
		createAndAddFixPriceOfIntactaTechnologyToSaleTemplate(saleTemplate);
		
		getSession().saveOrUpdate(saleTemplate);
		
		Sale sale = saleFactory.createSale(saleTestFixture.matrixCargil, saleTestFixture.chicoBento, SaleTypeEnum.SALE_SEED);
		sale.setState(saleTestFixture.productivityOfIntactaSoy.getState());
		SaleItem item = SaleTestData.createSaleItem(sale, saleTemplate, saleTestFixture.productIntactaSoy, null);
		item.setPlantability(saleTestFixture.plantabilitySystemOfHarvest2011Soy.getDescription());
		item.setPlantability("NOT FOUND");
		
		try {
			saleService.save(sale, accessControlTestFixture.superUser);
			Assert.fail("Should not return a ContraintViolation");
		} catch (SaleConstraintViolationException e) {
			verifyConstraintMessage("Plantability is invalid.", e);
		}
	}
	
	@Test
	public void when_i_register_sale_with_productivity_invalid_shouldBeReturned_ConstraintViolationException() throws BusinessException {
		
		SaleTemplate saleTemplate = SaleTemplateTestData.createSaleTemplateTypeSeedSale(saleTestFixture.harvest2011SoyMonsanto);
		
		createAndAddFixPriceOfIntactaTechnologyToSaleTemplate(saleTemplate);
		
		getSession().saveOrUpdate(saleTemplate);
		
		Sale sale = saleFactory.createSale(saleTestFixture.matrixCargil, saleTestFixture.chicoBento, SaleTypeEnum.SALE_SEED);
		sale.setState(saleTestFixture.productivityOfIntactaSoy.getState());
		SaleItem item = SaleTestData.createSaleItem(sale, saleTemplate, saleTestFixture.productIntactaSoy, null);
		item.setPlantability(saleTestFixture.plantabilitySystemOfHarvest2011Soy.getDescription());
		item.setProductivityValue(BigDecimal.valueOf(1L));
		
		try {
			saleService.save(sale, accessControlTestFixture.superUser);
			Assert.fail("Should not return a ContraintViolation");
		} catch (SaleConstraintViolationException e) {
			verifyConstraintMessage("Productivity is invalid.", e);
		}
	}

	private void createAndAddFixPriceOfIntactaTechnologyToSaleTemplate(SaleTemplate saleTemplate) throws BusinessException {
		PriceTestData.createPrice(PriceTypeEnum.FIX, saleTemplate, systemTestFixture.intacta);
	}
	
	@Test
	public void when_i_register_sale_with_headOffice_invalid_shouldBeReturned_ConstraintViolationException() throws BusinessException {
		
		SaleTemplate saleTemplate = SaleTemplateTestData.createSaleTemplateTypeSeedSale(saleTestFixture.harvest2011SoyMonsanto);
		
		createAndAddFixPriceOfIntactaTechnologyToSaleTemplate(saleTemplate);
		
		getSession().saveOrUpdate(saleTemplate);
		
		Sale sale = saleFactory.createSale(saleTestFixture.matrixMons4nto, saleTestFixture.chicoBento, SaleTypeEnum.SALE_SEED);
		sale.setState(saleTestFixture.productivityOfIntactaSoy.getState());
		
		//Customer matrix = new Customer(null, new Document(saleTestFixture.matrixCargil.getDocument().getDocumentType(), saleTestFixture.matrixCargil.getDocumentValue()), null, null);
		Customer matrix = saleTestFixture.officeCustomer.getMatrix();
				
		SaleItem item = SaleTestData.createSaleItem(sale, saleTemplate, saleTestFixture.productIntactaSoy, matrix);
		item.setPlantability(saleTestFixture.plantabilitySystemOfHarvest2011Soy.getDescription());
		
		try {
			saleService.save(sale, accessControlTestFixture.superUser);
			Assert.fail("Should not return a ContraintViolation");
		} catch (SaleConstraintViolationException e) {
			verifyConstraintMessage("Document's Headoffice is invalid.", e);
		}
	}
	
	@Test
	public void when_i_register_sale_with_headOffice_null_shouldBeReturned_ConstraintViolationException() throws BusinessException {
		
		SaleTemplate saleTemplate = SaleTemplateTestData.createSaleTemplateTypeSeedSale(saleTestFixture.harvest2011SoyMonsanto);
		createAndAddFixPriceOfIntactaTechnologyToSaleTemplate(saleTemplate);
		getSession().saveOrUpdate(saleTemplate);
		
		Sale sale = saleFactory.createSale(saleTestFixture.matrixCargil, saleTestFixture.chicoBento, SaleTypeEnum.SALE_SEED);
		sale.setState(saleTestFixture.productivityOfIntactaSoy.getState());
		SaleItem item = SaleTestData.createSaleItem(sale, saleTemplate, saleTestFixture.productIntactaSoy, null);
		item.setPlantability(saleTestFixture.plantabilitySystemOfHarvest2011Soy.getDescription());
		
		try {
			saleService.save(sale, accessControlTestFixture.superUser);
			Assert.fail("Should not return a ContraintViolation");
		} catch (SaleConstraintViolationException e) {
			verifyConstraintMessage("Document's Headoffice is required.", e);
		}
	}
	
	@Test
	public void when_i_register_sale_with_distributor_not_belongs_headOffice_shouldBeReturned_ConstraintViolationException() throws BusinessException {
		
		SaleTemplate saleTemplate = createAConsistentSaleTemplateWithHeadOffice();
		
		getSession().saveOrUpdate(saleTemplate);
		
		Sale sale = saleFactory.createSale(saleTestFixture.matrixCargil, saleTestFixture.chicoBento, SaleTypeEnum.SALE_SEED);
		sale.setState(saleTestFixture.productivityOfIntactaSoy.getState());
		sale.setCustomer(saleTestFixture.customer);
		
		Customer matrix = saleTestFixture.officeCustomer.getMatrix();
		
		SaleItem item = SaleTestData.createSaleItem(sale, saleTemplate, saleTestFixture.productIntactaSoy, matrix);
		item.setPlantability(saleTestFixture.plantabilitySystemOfHarvest2011Soy.getDescription());
		
		try {
			saleService.save(sale, accessControlTestFixture.superUser);
			Assert.fail("Should not return a ContraintViolation");
		} catch (SaleConstraintViolationException e) {
			verifyConstraintMessage("Document's Headoffice is invalid.", e);
		}
	}
	
	//Inicio Maxlength
	@Test
	public void when_i_have_sale_with_invoice_number_maxlength_invalid_ShoulBeReturn_ConstraintViolationException() throws BusinessException {	
		Sale sale = saleFactory.createSale(saleTestFixture.matrixCargil, saleTestFixture.chicoBento, SaleTypeEnum.SALE_SEED);
		sale.setInvoiceNumber(RandomTestData.createRandomString(21));
		
		try {
			saleService.save(sale, accessControlTestFixture.superUser);
			Assert.fail();
		} catch (SaleConstraintViolationException e) {
			verifyConstraintMessage("Invalid Maxlength.", e);
		}
		
	}
	
	public void when_i_have_sale_with_sale_note_maxlength_invalid_ShoulBeReturn_ConstraintViolationException() throws BusinessException {	
		Sale sale = saleFactory.createSale(saleTestFixture.matrixCargil, saleTestFixture.chicoBento, SaleTypeEnum.SALE_SEED);
		sale.setSaleNote(RandomTestData.createRandomString(4001));	
		try {
			saleService.save(sale, accessControlTestFixture.superUser);
			Assert.fail();
		} catch (SaleConstraintViolationException e) {
			verifyConstraintMessage("Invalid Maxlength.", e);
		}
	}
	
	
	@Test
	public void when_i_have_sale_with_saleItem_with_price_invalid_ShoulBeReturn_ConstraintViolationException() throws BusinessException {	
		Sale sale = saleFactory.createSale(saleTestFixture.matrixCargil, saleTestFixture.chicoBento, SaleTypeEnum.SALE_SEED);
		
		SaleTemplate saleTemplate = createSaleTemplateAssociatedWithTwoProducts();
		saleTemplate.getInvoice().setDocumentRequired(Boolean.TRUE);
		SaleItem item = new SaleItem(sale, saleTemplate, saleTestFixture.productIntactaSoy, null);
		BigDecimal veryBigDecimal = new BigDecimal(999999999999d);
		item.setPriceQuantity(veryBigDecimal);
		
		sale.getItems().add(item);
		
		try {
			saleService.save(sale, accessControlTestFixture.superUser);
			Assert.fail();
		} catch (SaleConstraintViolationException e) {
			verifyConstraintMessage("Invalid bigDecimal value.", e);
		}		
	}

	@Test
	public void when_i_have_sale_with_saleItem_with_soldQuantity_invalid_ShoulBeReturn_ConstraintViolationException() throws BusinessException {	
		Sale sale = saleFactory.createSale(saleTestFixture.matrixCargil, saleTestFixture.chicoBento, SaleTypeEnum.SALE_SEED);
		
		SaleTemplate saleTemplate = createSaleTemplateAssociatedWithTwoProducts();
		saleTemplate.getInvoice().setDocumentRequired(Boolean.TRUE);
		SaleItem item = new SaleItem(sale, saleTemplate, saleTestFixture.productIntactaSoy, null);
		item.setPriceQuantity(RandomTestData.createRandomBigDecimal());
		item.setSoldQuantity(9999999999l);
		
		sale.getItems().add(item);
		
		try {
			saleService.save(sale, accessControlTestFixture.superUser);
			Assert.fail();
		} catch (SaleConstraintViolationException e) {
			verifyConstraintMessage("Invalid Long value.", e);
		}		
	}
	
	@Test
	public void when_i_have_sale_with_empty_operationalYear_ShoulBeReturn_ConstraintViolationException() throws BusinessException {	
		Sale sale = saleFactory.createSale(saleTestFixture.matrixCargil, saleTestFixture.chicoBento, SaleTypeEnum.SALE_SEED);
		
		SaleTemplate saleTemplate = createSaleTemplateAssociatedWithTwoProducts();
		saleTemplate.getHarvest().getOperationalYear().setYear(null);
		SaleItem item = new SaleItem(sale, saleTemplate, saleTestFixture.productIntactaSoy, null);
		
		sale.getItems().add(item);
		
		try {
			saleService.save(sale, accessControlTestFixture.superUser);
			Assert.fail();
		} catch (SaleConstraintViolationException e) {
			verifyConstraintMessage("Operational year is required.", e);
		}
	}
	
	@Test
	public void when_i_have_sale_with_null_operationalYear_ShoulBeReturn_ConstraintViolationException() throws BusinessException {	
		Sale sale = saleFactory.createSale(saleTestFixture.matrixCargil, saleTestFixture.chicoBento, SaleTypeEnum.SALE_SEED);
		
		SaleTemplate saleTemplate = createSaleTemplateAssociatedWithTwoProducts();
		saleTemplate.getHarvest().setOperationalYear(null);
		SaleItem item = new SaleItem(sale, saleTemplate, saleTestFixture.productIntactaSoy, null);
		
		sale.getItems().add(item);
		
		try {
			saleService.save(sale, accessControlTestFixture.superUser);
			Assert.fail();
		} catch (SaleConstraintViolationException e) {
			verifyConstraintMessage("Operational year is required.", e);
		}		
	}

	@Test
	public void when_i_have_sale_with_null_company_ShoulBeReturn_ConstraintViolationException() throws BusinessException {	
		Sale sale = saleFactory.createSale(saleTestFixture.matrixCargil, saleTestFixture.chicoBento, SaleTypeEnum.SALE_SEED);
		
		SaleTemplate saleTemplate = createSaleTemplateAssociatedWithTwoProducts();
		saleTemplate.getHarvest().setCompany(null);
		SaleItem item = new SaleItem(sale, saleTemplate, saleTestFixture.productIntactaSoy, null);
		
		sale.getItems().add(item);
		
		try {
			saleService.save(sale, accessControlTestFixture.superUser);
			Assert.fail();
		} catch (SaleConstraintViolationException e) {
			verifyConstraintMessage("Company is required.", e);
		}		
	}
	
	@Test
	public void when_i_have_sale_with_null_crop_ShoulBeReturn_ConstraintViolationException() throws BusinessException {	
		Sale sale = saleFactory.createSale(saleTestFixture.matrixCargil, saleTestFixture.chicoBento, SaleTypeEnum.SALE_SEED);
		
		SaleTemplate saleTemplate = createSaleTemplateAssociatedWithTwoProducts();
		saleTemplate.getHarvest().setCrop(null);
		SaleItem item = new SaleItem(sale, saleTemplate, saleTestFixture.productIntactaSoy, null);
		
		sale.getItems().add(item);
		
		try {
			saleService.save(sale, accessControlTestFixture.superUser);
			Assert.fail();
		} catch (SaleConstraintViolationException e) {
			verifyConstraintMessage("Crop is required.", e);
		}		
	}
	
	@Test
	public void when_i_have_sale_with_null_harvest_ShoulBeReturn_ConstraintViolationException() throws BusinessException {	
		Sale sale = saleFactory.createSale(saleTestFixture.matrixCargil, saleTestFixture.chicoBento, SaleTypeEnum.SALE_SEED);
		
		SaleTemplate saleTemplate = createSaleTemplateAssociatedWithTwoProducts();
		saleTemplate.setHarvest(null);
		SaleItem item = new SaleItem(sale, saleTemplate, saleTestFixture.productIntactaSoy, null);
		
		sale.getItems().add(item);
		
		try {
			saleService.save(sale, accessControlTestFixture.superUser);
			Assert.fail();
		} catch (SaleConstraintViolationException e) {
			verifyConstraintMessage("Harvest is required.", e);
		}		
	}
	
	public static void verifyConstraintMessage(String expectedViolationMessage, SaleConstraintViolationException actualViolations) {
		boolean violationFound = actualViolations.hasViolationWithMessage(expectedViolationMessage);
		Assert.assertTrue("Violation: '" + expectedViolationMessage + "' not found", violationFound);
	}
	
	private SaleTemplate createAConsistentSaleTemplateWithHeadOffice() throws BusinessException {
		SaleTemplate saleTemplate = SaleTemplateTestData.createSaleTemplateTypeSeedSale(saleTestFixture.harvest2011SoyMonsanto);
		saleTemplate.addHeadOffice(saleTestFixture.headOfficeCargil);
		
		Price intactaPrice = PriceTestData.createPrice(PriceTypeEnum.FIX, saleTemplate, this.systemTestFixture.intacta);
		intactaPrice.addRoyaltyValue(new RoyaltyValue(BigDecimal.TEN));
		intactaPrice.addDueDate(new DueDateValue(new Date()));

		Price rrPrice = PriceTestData.createPrice(PriceTypeEnum.FREE_VALUE, saleTemplate, systemTestFixture.rr);
		rrPrice.addDueDate(new DueDateValue(new Date()));
		
		PriceTestData.createPrice(PriceTypeEnum.NO_VALUE, saleTemplate, systemTestFixture.bt);
		saveAndFlush(saleTemplate);

		return saleTemplate;
	}

	private SaleTemplate createSaleTemplateAssociatedWithTwoProducts() throws BusinessException {
		SaleTemplate theTemplate = SaleTemplateTestData.createSaleTemplateTypeSeedSale(saleTestFixture.harvest2011SoyMonsanto);
		Product product = ProductTestData.createProduct(this.systemTestFixture.monsoy, this.systemTestFixture.soy, this.systemTestFixture.intacta, StatusEnum.ACTIVE, this.systemTestFixture.monsantoBr);
		Product anotherProduct = product;
		anotherProduct.setDescription("My Precious");
		saveAndFlush(anotherProduct);
		theTemplate.addProduct(saleTestFixture.productIntactaSoy);
		theTemplate.addProduct(anotherProduct);
		createAndAddFixPriceOfIntactaTechnologyToSaleTemplate(theTemplate);
		saveAndFlush(theTemplate);
		return theTemplate;
	}
	
	private Sale createSaleWithItemConsumingQuota(SaleTypeEnum saleType) {
		Sale saleConsumingQuota = saleFactory.createSale(saleTestFixture.matrixMons4nto, saleTestFixture.chicoBento, saleType);
		saleConsumingQuota.setState(systemTestFixture.matoGrossoDoSul);
		SaleItem itemWithQuotaUsage = SaleTestData.createSaleItem(saleConsumingQuota, saleTestFixture.templateIntactaMons4nto, saleTestFixture.productIntactaWithQuota, saleTestFixture.matrixMons4nto);
    	itemWithQuotaUsage.setPriceQuantity(new BigDecimal("0.7"));
		itemWithQuotaUsage.setPlantability(saleTestFixture.plantability45To54SoyMons4nto2012.getDescription());
    	itemWithQuotaUsage.setProductivityValue(BigDecimal.valueOf(505L));
    	itemWithQuotaUsage.setDueDate(new Date());
		saleConsumingQuota.addItem(itemWithQuotaUsage);
    	return saleConsumingQuota;
	}
	
	@Test
	public void given_a_licenseSeed_consuming_quota_when_balance_is_insufficient_then_should_not_validate_insufficientBalance() throws SaleConstraintViolationException {
		Sale saleConsumingQuota = createSaleWithItemConsumingQuota(SaleTypeEnum.LICENSE_SEED);
		
		try {
			saleService.save(saleConsumingQuota, accessControlTestFixture.superUser);
			Assert.fail();
		} catch (SaleConstraintViolationException e) {
			Assert.assertFalse("Should not have the insufficient balance violation", e.hasViolationWithMessage("Insufficient balance for product and headoffice"));
		}
	}
	
	@Test
	public void when_i_register_sale_with_matrix_without_contract_shouldBeReturned_ConstraintViolationException() throws BusinessException {
		
		Sale sale = saleFactory.createSale(saleTestFixture.affiliate, saleTestFixture.chicoBento, SaleTypeEnum.SALE_SEED);
		
		SaleTemplate saleTemplate = createAConsistentSaleTemplateWithHeadOffice();
		
		saleTemplate.addHeadOffice(saleTestFixture.headOfficeAffiliate3);
		
		getSession().saveOrUpdate(saleTemplate);
		
		SaleTestData.createSaleItem(sale, saleTemplate, saleTestFixture.productIntactaSoy, saleTestFixture.affiliate);
		
		accessControlTestFixture.superUser.setContextCompany(systemTestFixture.monsantoBr);
		accessControlTestFixture.superUser.setContextCrop(systemTestFixture.soy);
		
		try {
			saleService.save(sale, accessControlTestFixture.superUser);
			Assert.fail("Should not return a ContraintViolation");
		} catch (SaleConstraintViolationException e) {
			verifyConstraintMessage("Contract not found.", e);
		}
	}
	
	@Test
	public void when_i_register_sale_with_matrix_with_contract_duplicated_shouldBeReturned_ConstraintViolationException() throws BusinessException {
		
		Sale sale = saleFactory.createSale(saleTestFixture.matrixCargil, saleTestFixture.chicoBento, SaleTypeEnum.SALE_SEED);
		
		SaleTemplate saleTemplate = createAConsistentSaleTemplateWithHeadOffice();
		
		saleTemplate.addHeadOffice(saleTestFixture.headOfficeAffiliate3);
		
		getSession().saveOrUpdate(saleTemplate);
		
		Contract contract = new Contract("", saleTestFixture.matrixCargil, ParticipantTypeEnum.DISTRIBUTOR, systemTestFixture.soy, systemTestFixture.monsantoBr);
		
		saveAndFlush(contract);
		
		SaleTestData.createSaleItem(sale, saleTemplate, saleTestFixture.productIntactaSoy, saleTestFixture.matrixCargil);
		
		try {
			saleService.save(sale, accessControlTestFixture.superUser);
			Assert.fail("Should not return a ContraintViolation");
		} catch (SaleConstraintViolationException e) {
			verifyConstraintMessage("Contract duplicated.", e);
		}
	}
}
