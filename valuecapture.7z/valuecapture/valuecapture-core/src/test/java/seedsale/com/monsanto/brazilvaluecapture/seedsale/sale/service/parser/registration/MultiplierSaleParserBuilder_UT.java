package com.monsanto.brazilvaluecapture.seedsale.sale.service.parser.registration;

import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.mock;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;

import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.CsvMultiplierSale;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.Sale;

/**
 * Test for class {@link MultiplierSaleParserBuilder}
 * 
 * @author CSOBR1
 *
 */
public class MultiplierSaleParserBuilder_UT {

	/**
	 * Class under test.
	 */
	private MultiplierSaleParserBuilder test;
	
	@Before
    public void setUp() throws Exception {
		
		test = new MultiplierSaleParserBuilder();
    }
	
	@Test
	public void test_createSaleFrom() {
		
		List<CsvMultiplierSale> list = new ArrayList<CsvMultiplierSale>();
		list.add(mock(CsvMultiplierSale.class));
		Sale result = test.createSaleFrom(mock(CsvMultiplierSale.class), list);
		
		assertNotNull(result);
		
	}

}
