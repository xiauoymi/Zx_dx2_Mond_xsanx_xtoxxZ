package com.monsanto.brazilvaluecapture.seedsale.harvest;

import com.monsanto.brazilvaluecapture.core.base.CompanyTestData;
import com.monsanto.brazilvaluecapture.core.base.CropTestData;
import com.monsanto.brazilvaluecapture.core.base.OperationalYearTestData;
import com.monsanto.brazilvaluecapture.core.base.TechnologyTestData;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Company;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Crop;
import com.monsanto.brazilvaluecapture.core.base.model.bean.OperationalYear;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Technology;
import com.monsanto.brazilvaluecapture.core.foundation.RandomTestData;
import com.monsanto.brazilvaluecapture.core.foundation.model.bean.StatusEnum;
import com.monsanto.brazilvaluecapture.seedsale.harvest.model.bean.Harvest;
import com.monsanto.brazilvaluecapture.seedsale.product.BrandTestData;
import com.monsanto.brazilvaluecapture.seedsale.product.ProductTestData;
import com.monsanto.brazilvaluecapture.seedsale.product.model.bean.Brand;

public class HarvestTestData {

	public static Harvest createABrazilianHarvest() {
		Company company = CompanyTestData.createACompanyInBrazil();
		Crop crop = CropTestData.createCrop(company, company.getCountry());
		OperationalYear operationalYear = OperationalYearTestData.createOperationalYear();

		Brand brand = BrandTestData.createBrand(company);
		Technology tech = TechnologyTestData.createTechnology(company);
		ProductTestData.createProduct(brand, crop, tech, StatusEnum.ACTIVE, company);

		return createHarvest(crop, operationalYear, company);
	}

	/**
	 * create a new Harvest informing Crop and OperationalYear
	 * 
	 * @param crop
	 * @param operationalYear
	 * @param company 
	 * @return Harvest
	 */
	public static Harvest createHarvest(Crop crop, OperationalYear operationalYear, Company company) {
		Harvest harvest = new Harvest(company, RandomTestData.createRandomString(10), operationalYear, crop, StatusEnum.ACTIVE);
		crop.addHarvest(harvest);

		return harvest;
	}

}
