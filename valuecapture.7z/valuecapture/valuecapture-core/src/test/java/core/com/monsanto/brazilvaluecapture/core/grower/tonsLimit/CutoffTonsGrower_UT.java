package com.monsanto.brazilvaluecapture.core.grower.tonsLimit;

import org.junit.Test;

import com.monsanto.brazilvaluecapture.core.foundation.test.AssertHelper;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.CutOffTonsGrower;

public class CutoffTonsGrower_UT {

	@Test
	public void test_getters_and_setters_growerTonsLimitDTO() {
	    AssertHelper.testGettersAndSetters(new  CutOffTonsGrower());
	}

}
