package com.monsanto.brazilvaluecapture.core.grower.service.impl;

import com.monsanto.brazilvaluecapture.core.account.model.bean.TransactionType;
import com.monsanto.brazilvaluecapture.core.account.model.dao.TransactionDAO;
import com.monsanto.brazilvaluecapture.core.base.model.dao.OperationalYearDAO;
import com.monsanto.brazilvaluecapture.core.base.service.ServiceRunner;
import com.monsanto.brazilvaluecapture.core.base.service.ServiceRunnerDataService;
import com.monsanto.brazilvaluecapture.core.base.service.impl.RegisterPaymentARServiceRunner;
import com.monsanto.brazilvaluecapture.osb.its.api.LASVCPrepaidTonsServiceAR;
import com.monsanto.brazilvaluecapture.osb.util.SecurityContextBadCredentialException;
import org.junit.Before;
import org.junit.Test;

import java.net.MalformedURLException;

import static org.fest.reflect.core.Reflection.field;
import static org.junit.Assert.*;
import static org.mockito.Mockito.when;

/**
 * Register Payment Service Runner Unit tests
 *
 * @author Fdez, Israel
 * @author Folgar, Pablo
 * @since 3.1.1
 */
public class RegisterPaymentARServiceRunner_UT extends BaseARServiceRunnerTest {
    private RegisterPaymentARServiceRunner registerPaymentARServiceRunner;

    @Before
    public void setUp() {
        initializateSale();
        when(transactionDAO.findTransactionBy(sale.getItems().iterator().next().getBilling().getId(), TransactionType.PAYMENT)).thenReturn(transaction);
    }

    /**
     * Tests that the right property is used to call the service URL
     * The property is in ITS-Environment-Specific.properties
     */
    @Test
    public void testRegisterPaymentServiceRunnerUsesTheCorrectServiceURL() {
        String expectedURLProperty = "osb_lasvc_prepaid_tons_pod_ar_url";
        assertEquals("Incorrect Service URL property used", expectedURLProperty, RegisterPaymentARServiceRunner.getServiceURLProperty());
    }

    @Test
    public void testServiceNameIsNotNull_AndCorrect() throws MalformedURLException, SecurityContextBadCredentialException {
        initServiceRunner();
        String expectedServiceName = ServiceRunner.ServiceEnum.PREPAID_TONS_AR.getValue();
        assertEquals(expectedServiceName, registerPaymentARServiceRunner.getServiceName());
    }

    @Test
    public void testOperationNameInNotNull_AndCorrect() throws MalformedURLException, SecurityContextBadCredentialException {
        initServiceRunner();
        String expectedOperationName = ServiceRunner.OperationEnum.REGISTRO_PAGOS.getValue();
        assertEquals(expectedOperationName, registerPaymentARServiceRunner.getOperationName());
    }

    @Test
    public void testWhen_runnerExecutesWithNoError_Then_StatusIsOK() throws Exception {
        initServiceRunner();
        registerPaymentARServiceRunner.run(sale);
        assertTrue(registerPaymentARServiceRunner.getStatus());
    }

    @Test
    public void testIsRetryIsFalse() throws MalformedURLException, SecurityContextBadCredentialException {
        initServiceRunner();
        assertFalse(registerPaymentARServiceRunner.getIsRetry());
    }

    @Test
    public void testWhen_runnerExecutesWithErrors_Then_StatusIsNotOK() throws Exception {
        try {
            registerPaymentARServiceRunner = new RegisterPaymentARServiceRunner();
            registerPaymentARServiceRunner.run(sale);
        } catch (Exception e) {
            assertFalse(registerPaymentARServiceRunner.getStatus());
        }
    }

    @Test
    public void testWhen_RunnerExecutes_Then_RequestAndResponseExists() throws Exception {
        initServiceRunner();
        registerPaymentARServiceRunner.run(sale);
        assertFalse(registerPaymentARServiceRunner.getRequest().keySet().isEmpty());
        assertFalse(registerPaymentARServiceRunner.getResponse().keySet().isEmpty());
        assertNotNull(registerPaymentARServiceRunner.getRequestDate());
        assertNotNull(registerPaymentARServiceRunner.getResponseDate());
    }

    private void initServiceRunner() throws SecurityContextBadCredentialException, MalformedURLException {
        registerPaymentARServiceRunner = new RegisterPaymentARServiceRunner();
        field("operationalYearDAO").ofType(OperationalYearDAO.class).in(registerPaymentARServiceRunner).set(operationalYearDAO);
        field("osbService").ofType(LASVCPrepaidTonsServiceAR.class).in(registerPaymentARServiceRunner).set(osbService);
        field("transactionDAO").ofType(TransactionDAO.class).in(registerPaymentARServiceRunner).set(transactionDAO);
        field("serviceRunnerDataService").ofType(ServiceRunnerDataService.class).in(registerPaymentARServiceRunner).set(serviceRunnerDataService);
    }

    @Test()
    public void testWhen_RunnerFails_Then_RequestAndResponseExists() throws Exception {
        try {
            registerPaymentARServiceRunner = new RegisterPaymentARServiceRunner();
            registerPaymentARServiceRunner.run(sale);
        } catch (Exception e) {
            assertFalse(registerPaymentARServiceRunner.getRequest().keySet().isEmpty());
            assertFalse(registerPaymentARServiceRunner.getResponse().keySet().isEmpty());
            assertNotNull(registerPaymentARServiceRunner.getRequestDate());
            assertNotNull(registerPaymentARServiceRunner.getResponseDate());
        }
    }

}
