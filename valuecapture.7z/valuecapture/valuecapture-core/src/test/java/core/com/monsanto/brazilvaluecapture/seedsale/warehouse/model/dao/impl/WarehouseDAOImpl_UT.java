package com.monsanto.brazilvaluecapture.seedsale.warehouse.model.dao.impl;

import com.monsanto.brazilvaluecapture.core.base.model.bean.City;
import com.monsanto.brazilvaluecapture.core.base.model.bean.State;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Customer;
import com.monsanto.brazilvaluecapture.core.foundation.service.EntityNotFoundException;
import com.monsanto.brazilvaluecapture.pod.rol.model.bean.GermoSupplier;
import com.monsanto.brazilvaluecapture.seedsale.warehouse.model.bean.Warehouse;
import com.monsanto.brazilvaluecapture.seedsale.warehouse.model.bean.WarehouseToCustomerAudit;
import com.monsanto.brazilvaluecapture.seedsale.warehouse.model.bean.WarehouseToGermoAudit;
import org.hibernate.*;
import org.hibernate.classic.Session;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Restrictions;
import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Matchers.anyObject;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.*;

/**
 * Created by RVOROZ on 02/09/2014.
 */
public class WarehouseDAOImpl_UT {

    private WarehouseDAOImpl warehouseDAO;
    private Query query;
    private SQLQuery sqlQuery;
    private Session session;
    private Criteria criteria;

    @Before
    public void setUp() {
        SessionFactory sessionFactory = mock(SessionFactory.class);
        this.session = mock(Session.class);
        when(sessionFactory.getCurrentSession()).thenReturn(this.session);
        this.warehouseDAO = new WarehouseDAOImpl(sessionFactory);
        this.query = mock(Query.class);
        this.sqlQuery = mock(SQLQuery.class);
        this.criteria = mock(Criteria.class);
    }

    @Test
    public void test_getWarehouses() {
        when(this.session.createCriteria(Warehouse.class)).thenReturn(this.criteria);
        when(this.criteria.list()).thenReturn(getWarehouseListMock());

        List<Warehouse> data = warehouseDAO.getWarehouses();

        assertEquals(data.size(), 10);
    }

    @Test
    public void test_getByCountry() {
        when(this.session.createQuery(anyString())).thenReturn(this.query);
        when(this.query.setParameter(anyString(), anyObject())).thenReturn(this.query);
        when(this.query.list()).thenReturn(getWarehouseListMock());

        List<Warehouse> data = warehouseDAO.getByCountry("AR");

        assertEquals(data.size(), 10);
        verify(this.query, times(1)).setParameter("countryCode", "AR");
    }

    @Test
    public void test_selectBy() throws EntityNotFoundException {
        when(this.session.createQuery(anyString())).thenReturn(this.query);
        when(this.query.setParameter(anyString(), anyObject())).thenReturn(this.query);
        when(this.query.uniqueResult()).thenReturn(getWarehouseMock());

        Warehouse data = warehouseDAO.selectBy("Warehouse", "AR");

        assertNotNull(data);
        verify(this.query, times(1)).setParameter("countryCode", "AR");
        verify(this.query, times(1)).setParameter("wareHouseDescription", "Warehouse");
    }

    @Test
    public void test_getByCustomer() {
        when(this.session.createQuery(anyString())).thenReturn(this.query);
        when(this.query.setParameter(anyString(), anyObject())).thenReturn(this.query);
        when(this.query.list()).thenReturn(getWarehouseListMock());

        List<Warehouse> data = warehouseDAO.getByCustomer(1L, "AR");

        assertEquals(data.size(), 10);
        verify(this.query, times(1)).setParameter("customerId", 1L);
        verify(this.query, times(1)).setParameter("countryCode", "AR");
    }

    @Test
    public void test_getById() {
        when(this.session.createCriteria(Warehouse.class)).thenReturn(this.criteria);
        when(this.criteria.add(any(Criterion.class))).thenReturn(this.criteria);
        when(this.criteria.setFetchMode(anyString(), any(FetchMode.class))).thenReturn(this.criteria);
        when(this.criteria.uniqueResult()).thenReturn(getWarehouseMock());

        Warehouse data = warehouseDAO.getById(1L);

        assertNotNull(data);
        verify(this.criteria, times(1)).add(Restrictions.eq("id", anyLong()));
    }

    @Test
    public void test_getByFilters() {
        when(this.session.createQuery(anyString())).thenReturn(this.query);
        when(this.query.setParameter(anyString(), anyObject())).thenReturn(this.query);
        when(this.query.list()).thenReturn(getWarehouseListMock());
        State state = new State();
        state.setId(1L);
        City city = new City();
        city.setId(1L);
        Date date = new Date();

        List<Warehouse> data = warehouseDAO.getByFilters("Warehouse", state, city, "ACTIVE", date, date, "AR");

        assertEquals(data.size(), 10);
        verify(this.query, times(1)).setParameter("warehouseDescription", "%WAREHOUSE%");
        verify(this.query, times(1)).setParameter("warehouseState", state.getId());
        verify(this.query, times(1)).setParameter("warehouseCity", city.getId());
        verify(this.query, times(1)).setParameter("status", "ACTIVE");
        verify(this.query, times(1)).setDate("warehouseCreationDateStart", date);
        verify(this.query, times(1)).setDate("warehouseCreationDateEnd", date);
        verify(this.query, times(1)).setParameter("countryCode", "AR");
    }

    @Test
    public void test_save() {
        Warehouse warehouse = getWarehouseMock();
        warehouseDAO.save(warehouse);
        verify(this.session, times(1)).saveOrUpdate(warehouse);
    }

    @Test
    public void test_saveRelateCustomersToWarehouse() {
        when(this.session.createSQLQuery(anyString())).thenReturn(this.sqlQuery);

        Warehouse warehouse = getWarehouseMock();

        List<Customer> customersToRelate = new ArrayList<Customer>();
        Customer customerRelate = new Customer();
        customerRelate.setId(1L);
        customerRelate.setName("Customer");
        customersToRelate.add(customerRelate);

        List<Customer> customersToUnrelate = new ArrayList<Customer>();
        Customer customerUnrelate = new Customer();
        customerUnrelate.setId(2L);
        customerUnrelate.setName("Customer");
        customersToUnrelate.add(customerUnrelate);
        String user = "ADAMA_S";
        warehouseDAO.saveRelateCustomersToWarehouse(warehouse, customersToRelate, customersToUnrelate, user);

        verify(this.session, times(3)).saveOrUpdate(any(WarehouseToCustomerAudit.class));
        verify(this.session, times(1)).saveOrUpdate(warehouse);
    }

    @Test
    public void test_saveRelatedGermosToWarehouse() {
        when(this.session.createSQLQuery(anyString())).thenReturn(this.sqlQuery);

        Warehouse warehouse = getWarehouseMock();

        List<GermoSupplier> germosToRelate = new ArrayList<GermoSupplier>();
        GermoSupplier germoRelate = new GermoSupplier();
        germoRelate.setId(1L);
        germoRelate.setName("GermoSupplier");
        germosToRelate.add(germoRelate);

        List<GermoSupplier> germosToUnrelate = new ArrayList<GermoSupplier>();
        GermoSupplier germoUnrelate = new GermoSupplier();
        germoUnrelate.setId(2L);
        germoUnrelate.setName("GermoSupplier");
        germosToUnrelate.add(germoUnrelate);

        String user = "ADAMA_S";
        warehouseDAO.saveRelatedGermosToWarehouse(warehouse, germosToRelate, germosToUnrelate, user);

        verify(this.session, times(3)).saveOrUpdate(any(WarehouseToGermoAudit.class));
        verify(this.session, times(1)).saveOrUpdate(warehouse);
    }

    private Warehouse getWarehouseMock() {
        Warehouse warehouse = new Warehouse();
        warehouse.setId(1L);
        warehouse.setDescription("Warehouse");

        List<Customer> customers = new ArrayList<Customer>();
        Customer customer = new Customer();
        customer.setId(100L);
        customer.setName("Customer");
        customers.add(customer);
        warehouse.setCustomers(new HashSet<Customer>(customers));

        List<GermoSupplier> germoSuppliers = new ArrayList<GermoSupplier>();
        GermoSupplier germoSupplier = new GermoSupplier();
        germoSupplier.setId(100L);
        germoSupplier.setName("GermoSupplier");
        germoSuppliers.add(germoSupplier);
        warehouse.setGermoSuppliers(new HashSet<GermoSupplier>(germoSuppliers));
        return warehouse;
    }

    private List<Warehouse> getWarehouseListMock() {

        List<Warehouse> data = new ArrayList<Warehouse>();

        for (int i = 0; i < 10; i++) {
            Warehouse row = new Warehouse();
            row.setId(new Long(i));
            row.setDescription(String.valueOf(i));
            data.add(row);
        }

        return data;
    }


}
