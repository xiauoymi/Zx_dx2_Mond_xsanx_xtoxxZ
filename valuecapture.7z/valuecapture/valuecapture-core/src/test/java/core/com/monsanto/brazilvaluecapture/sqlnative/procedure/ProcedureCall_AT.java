package com.monsanto.brazilvaluecapture.sqlnative.procedure;

import com.monsanto.brazilvaluecapture.core.base.SystemTestFixture;
import com.monsanto.brazilvaluecapture.core.base.service.CompanyService;
import com.monsanto.brazilvaluecapture.core.foundation.service.BusinessException;
import com.monsanto.brazilvaluecapture.core.foundation.service.EntityAlreadyExistException;
import com.monsanto.brazilvaluecapture.core.foundation.service.EntityNotFoundException;
import com.monsanto.brazilvaluecapture.core.foundation.test.AbstractServiceIntegrationTests;
import com.monsanto.brazilvaluecapture.core.grower.model.bean.Agreement;
import com.monsanto.brazilvaluecapture.core.grower.model.bean.AgreementTemplate;
import com.monsanto.brazilvaluecapture.core.user.AccessControlTestFixture;
import com.monsanto.brazilvaluecapture.core.user.model.bean.HierarchyLevel;
import com.monsanto.brazilvaluecapture.seedsale.sale.SaleTestFixture;
import junit.framework.Assert;
import org.junit.Assume;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

@Ignore
public class ProcedureCall_AT extends AbstractServiceIntegrationTests {

	@Autowired
	private CompanyService companyService;
	protected AgreementTemplate agreement;

	
	
	@Before
	public void init() throws BusinessException {
		systemTestFixture = new SystemTestFixture(this);
		accessControlTestFixture = new AccessControlTestFixture(this, systemTestFixture);
		saleTestFixture = new SaleTestFixture(this, systemTestFixture);

		accessControlTestFixture.itsParticipantUser.addUserContract(saleTestFixture.contract, saleTestFixture.customer, HierarchyLevel.HEAD_OFFICE);
		
		agreement = new AgreementTemplate(systemTestFixture.soy, systemTestFixture.monsantoBr, systemTestFixture.intacta, "CONTENT", Boolean.TRUE);
		
		saveAndFlush(agreement);
		
	
	}

	@Test
	public void when_i_generate_agreement_thenReturn_agreement_generated()
			throws EntityNotFoundException, EntityAlreadyExistException {
				
				Assume.assumeTrue(getAssumptionTest().isEnvironmentWithSQLANSI());
				
				AgreementTemplate agreementTemplate = new AgreementTemplate(systemTestFixture.coffee, systemTestFixture.monsantoBr, systemTestFixture.intacta, "CONTENT", Boolean.TRUE);
				
				saveAndFlush(agreementTemplate);
				
				Agreement agreementJoaoDaSilva = companyService.generateAgreement(systemTestFixture.monsantoBr, systemTestFixture.coffee, systemTestFixture.intacta, null, saleTestFixture.joaoDaSilva,saleTestFixture.customer,"as12","user", null,null);

				Agreement agreementChicoBento = companyService.generateAgreement(systemTestFixture.monsantoBr, systemTestFixture.coffee, systemTestFixture.intacta, null, saleTestFixture.chicoBento,saleTestFixture.customer,"as12","user", null, null);
				
				Assert.assertNotNull(agreementJoaoDaSilva);
				Assert.assertNotNull(agreementJoaoDaSilva.getPrimaryKey());
				
				Assert.assertNotNull(agreementChicoBento);
				Assert.assertNotNull(agreementChicoBento.getPrimaryKey());
				
				Assert.assertTrue(agreementJoaoDaSilva.getCode() < agreementChicoBento.getCode());
			}

}
