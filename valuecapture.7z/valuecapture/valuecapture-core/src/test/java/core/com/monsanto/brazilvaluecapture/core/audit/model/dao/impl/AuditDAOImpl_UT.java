package com.monsanto.brazilvaluecapture.core.audit.model.dao.impl;

import com.monsanto.brazilvaluecapture.core.customer.model.bean.ParticipantTypeEnum;
import com.monsanto.brazilvaluecapture.core.foundation.model.bean.StatusEnum;
import com.monsanto.brazilvaluecapture.core.regionalization.VCCountry;
import com.monsanto.brazilvaluecapture.core.user.model.bean.ItsUser;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.SessionFactory;
import org.hibernate.classic.Session;
import org.junit.Before;
import org.junit.Test;

import java.util.Date;

import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.*;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

/**
 * Created with IntelliJ IDEA.
 * User: AFREI
 * Date: 28/01/14
 * Time: 10:20
 */
public class AuditDAOImpl_UT {
    private AuditDAOImpl auditDAO;
    private Query query;
    private Session session;
    private SQLQuery sqlQuery;

    @Before
    public void setUp() {
        SessionFactory sessionFactory = mock(SessionFactory.class);
        this.session = mock(Session.class);
        when(sessionFactory.getCurrentSession()).thenReturn(this.session);
        this.auditDAO = new AuditDAOImpl(sessionFactory);
        this.query = mock(Query.class);
        this.sqlQuery = mock(SQLQuery.class);
        when(this.session.createQuery(anyString())).thenReturn(this.query);
        when(this.session.createSQLQuery(anyString())).thenReturn(this.sqlQuery);
    }

    @Test
    public void testGetProfileByCreatesAQueryToFindRelationsBetweenUserAndProfiles_AndSetUserNameParam() {
        VCCountry country = VCCountry.ARGENTINA;
        String userName = "userName";

        String query = auditDAO.getProfileByQuery(userName,null,null,null,null);
        auditDAO.getProfileBy(country,userName,null,null,null,null,true);

        // @Then a query is created, the parameters ares set and the query is executed
        verify(this.session, times(1)).createQuery(eq(query));
        verify(this.query, times(1)).setParameter("p_userName", userName);
        verify(this.query, times(1)).setMaxResults(AuditDAOImpl.SEARCH_LAS_RESULTS_LIMIT);
        verify(this.query, times(1)).list();

    }

    @Test
    public void testGetProfileByCreatesAQueryToFindRelationsBetweenUserAndProfiles_AndSetLoginUserParam() {
        VCCountry country = VCCountry.ARGENTINA;
        String loginUser = "loginUser";
        boolean limitResults = true;

        String query = auditDAO.getProfileByQuery(null,loginUser,null,null,null);
        auditDAO.getProfileBy(country,null,loginUser,null,null,null,limitResults);

        // @Then a query is created, the parameters ares set and the query is executed
        verify(this.session, times(1)).createQuery(eq(query));
        verify(this.query, times(1)).setParameter("p_loginUser",loginUser.toUpperCase());
        verify(this.query, times(1)).setMaxResults(AuditDAOImpl.SEARCH_LAS_RESULTS_LIMIT);
        verify(this.query, times(1)).list();

    }

    @Test
    public void testGetProfileByCreatesAQueryToFindRelationsBetweenUserAndProfiles_AndSetDocNumberParam() {
        VCCountry country = VCCountry.ARGENTINA;
        String documentNumber = "123456789";
        boolean limitResults = true;

        String query = auditDAO.getProfileByQuery(null,null,documentNumber,null,null);
        auditDAO.getProfileBy(country,null,null,documentNumber,null,null,limitResults);

        // @Then a query is created, the parameters ares set and the query is executed
        verify(this.session, times(1)).createQuery(eq(query));
        verify(this.query, times(1)).setParameter("p_documentNumber",documentNumber);
        verify(this.query, times(1)).setMaxResults(AuditDAOImpl.SEARCH_LAS_RESULTS_LIMIT);
        verify(this.query, times(1)).list();

    }

    @Test
    public void testGetProfileByCreatesAQueryToFindRelationsBetweenUserAndProfiles_AndSetProfileParam() {
        VCCountry country = VCCountry.ARGENTINA;
        String profile = "profile";
        boolean limitResults = true;

        String query = auditDAO.getProfileByQuery(null,null,null,profile,null);
        auditDAO.getProfileBy(country,null,null,null,profile,null,limitResults);

        // @Then a query is created, the parameters ares set and the query is executed
        verify(this.session, times(1)).createQuery(eq(query));
        verify(this.query, times(1)).setParameter("p_profile",profile);
        verify(this.query, times(1)).setMaxResults(AuditDAOImpl.SEARCH_LAS_RESULTS_LIMIT);
        verify(this.query, times(1)).list();

    }

    @Test
    public void testGetProfileByCreatesAQueryToFindRelationsBetweenUserAndProfiles_AndSetStatusParam() {
        VCCountry country = VCCountry.ARGENTINA;
        StatusEnum status = StatusEnum.ACTIVE;
        boolean limitResults = true;

        String query = auditDAO.getProfileByQuery(null,null,null,null,status);
        auditDAO.getProfileBy(country,null,null,null,null,status,limitResults);

        // @Then a query is created, the parameters ares set and the query is executed
        verify(this.session, times(1)).createQuery(eq(query));
        verify(this.query, times(1)).setParameter("p_status",status);
        verify(this.query, times(1)).setMaxResults(AuditDAOImpl.SEARCH_LAS_RESULTS_LIMIT);
        verify(this.query, times(1)).list();

    }

    @Test
    public void testGetProfileByCreatesAQueryToFindRelationsBetweenUserAndProfiles_AndSetAllParams_AndDoNotLimitResults() {
        VCCountry country = VCCountry.ARGENTINA;
        String userName = "userName";
        String loginUser = "loginUser";
        String documentNumber = "123456789";
        String profile = "profile";
        StatusEnum status = StatusEnum.ACTIVE;
        boolean limitResults = false;

        String query = auditDAO.getProfileByQuery(userName,loginUser,documentNumber,profile,status);
        auditDAO.getProfileBy(country,userName,loginUser,documentNumber,profile,status,limitResults);

        // @Then a query is created, the parameters ares set and the query is executed
        verify(this.session, times(1)).createQuery(eq(query));
        verify(this.query, times(1)).setParameter("p_userName",userName);
        verify(this.query, times(1)).setParameter("p_loginUser",loginUser.toUpperCase());
        verify(this.query, times(1)).setParameter("p_documentNumber",documentNumber);
        verify(this.query, times(1)).setParameter("p_status",status);
        verify(this.query, times(1)).setParameter("p_profile",profile);
        verify(this.query, times(0)).setMaxResults(AuditDAOImpl.SEARCH_LAS_RESULTS_LIMIT);
        verify(this.query, times(1)).list();

    }

    @Test
    public void testGetUserLoginAttemptsByCreatesAQueryToFindUserLoginAttempts_AndSetLoginUserParam() {
        VCCountry country = VCCountry.ARGENTINA;
        String loginUser = "loginUser";
        Date dateFrom = new Date();
        Date dateTo = new Date();
        boolean limitResults = true;

        String query = auditDAO.getUserLoginAttemptsByQuery(loginUser,null,null);
        auditDAO.getUserLoginAttemptsBy(country,loginUser,null,null,limitResults);

        // @Then a query is created, the parameters ares set and the query is executed
        verify(this.session, times(1)).createQuery(eq(query));
        verify(this.query, times(1)).setParameter("p_loginUser",loginUser.toUpperCase());
        verify(this.query, times(0)).setParameter("p_dateFrom",dateFrom);
        verify(this.query, times(0)).setParameter("p_dateTo",dateTo);
        verify(this.query, times(1)).setMaxResults(AuditDAOImpl.SEARCH_LAS_RESULTS_LIMIT);
        verify(this.query, times(1)).list();

    }

    @Test
    public void testGetUserLoginAttemptsByCreatesAQueryToFindUserLoginAttempts_AndSetDateFromParam() {
        VCCountry country = VCCountry.ARGENTINA;
        String loginUser = "loginUser";
        Date dateFrom = new Date();
        Date dateTo = new Date();
        boolean limitResults = true;

        String query = auditDAO.getUserLoginAttemptsByQuery(null,dateFrom,null);
        auditDAO.getUserLoginAttemptsBy(country,null,dateFrom,null,limitResults);

        // @Then a query is created, the parameters ares set and the query is executed
        verify(this.session, times(1)).createQuery(eq(query));
        verify(this.query, times(0)).setParameter("p_loginUser",loginUser.toUpperCase());
        verify(this.query, times(1)).setParameter("p_dateFrom",dateFrom);
        verify(this.query, times(0)).setParameter("p_dateTo",dateTo);
        verify(this.query, times(1)).setMaxResults(AuditDAOImpl.SEARCH_LAS_RESULTS_LIMIT);
        verify(this.query, times(1)).list();

    }

    @Test
    public void testGetUserLoginAttemptsByCreatesAQueryToFindUserLoginAttempts_AndSetDateToParam() {
        VCCountry country = VCCountry.ARGENTINA;
        String loginUser = "loginUser";
        Date dateFrom = new Date();
        Date dateTo = new Date();
        boolean limitResults = true;

        String query = auditDAO.getUserLoginAttemptsByQuery(null,null,dateTo);
        auditDAO.getUserLoginAttemptsBy(country,null,null,dateTo,limitResults);

        // @Then a query is created, the parameters ares set and the query is executed
        verify(this.session, times(1)).createQuery(eq(query));
        verify(this.query, times(0)).setParameter("p_loginUser",loginUser.toUpperCase());
        verify(this.query, times(0)).setParameter("p_dateFrom",dateFrom);
        verify(this.query, times(1)).setParameter("p_dateTo",dateTo);
        verify(this.query, times(1)).setMaxResults(AuditDAOImpl.SEARCH_LAS_RESULTS_LIMIT);
        verify(this.query, times(1)).list();

    }


    @Test
    public void testGetUserLoginAttemptsByCreatesAQueryToFindUserLoginAttempts_AndSetAllParams_AndDoNotLimitResults() {
        VCCountry country = VCCountry.ARGENTINA;
        String loginUser = "loginUser";
        Date dateFrom = new Date();
        Date dateTo = new Date();
        boolean limitResults = false;

        String query = auditDAO.getUserLoginAttemptsByQuery(loginUser,dateFrom,dateTo);
        auditDAO.getUserLoginAttemptsBy(country,loginUser,dateFrom,dateTo,limitResults);

        // @Then a query is created, the parameters ares set and the query is executed
        verify(this.session, times(1)).createQuery(eq(query));
        verify(this.query, times(1)).setParameter("p_loginUser",loginUser.toUpperCase());
        verify(this.query, times(1)).setParameter("p_dateFrom",dateFrom);
        verify(this.query, times(1)).setParameter("p_dateFrom",dateTo);
        verify(this.query, times(0)).setMaxResults(AuditDAOImpl.SEARCH_LAS_RESULTS_LIMIT);
        verify(this.query, times(1)).list();

    }

    @Test
    public void testGetUserInformationByCreatesAQueryToFindUserInformation_AndUserLoginParam() {
        VCCountry country = VCCountry.ARGENTINA;
        String loginUser = "loginUser";
        boolean limitResults = true;

        String query = auditDAO.getUserInformationByQuery(loginUser);
        auditDAO.getUserInformationBy(country,loginUser,limitResults);

        // @Then a query is created, the parameters ares set and the query is executed
        verify(this.session, times(1)).createQuery(eq(query));
        verify(this.query, times(1)).setParameter("p_loginUser",loginUser.toUpperCase());
        verify(this.query, times(1)).setMaxResults(AuditDAOImpl.SEARCH_LAS_RESULTS_LIMIT);
        verify(this.query, times(1)).list();

    }

    @Test
    public void testGetUserInformationByCreatesAQueryToFindUserInformation_AndDoNotLimitResults() {
        VCCountry country = VCCountry.ARGENTINA;
        String loginUser = "loginUser";
        boolean limitResults = false;

        String query = auditDAO.getUserInformationByQuery(null);
        auditDAO.getUserInformationBy(country,null,limitResults);

        // @Then a query is created, the parameters ares set and the query is executed
        verify(this.session, times(1)).createQuery(eq(query));
        verify(this.query, times(0)).setParameter("p_loginUser",loginUser.toUpperCase());
        verify(this.query, times(0)).setMaxResults(AuditDAOImpl.SEARCH_LAS_RESULTS_LIMIT);
        verify(this.query, times(1)).list();

    }

    @Test
    public void testGetBasicUserByCreatesAQueryToFindBasicUser() {
        String userName = "userName";
        String loginUser = "loginUser";
        String documentNumber = "123456789";
        VCCountry country = VCCountry.ARGENTINA;
        boolean limitResults = true;
        String query = auditDAO.getBasicUserByQuery(userName, loginUser,documentNumber, ItsUser.UserTypeEnum.SUPER.name(), StatusEnum.ACTIVE.name(),limitResults);
        auditDAO.getBasicUser(country, userName, loginUser,documentNumber, ItsUser.UserTypeEnum.SUPER.name(), StatusEnum.ACTIVE.name(), limitResults);
        // @Then a query is created, the parameters ares set and the query is executed
        verify(this.session, times(1)).createSQLQuery(eq(query));
        verify(this.sqlQuery, times(1)).setParameter("p_user",userName.toUpperCase());
        verify(this.sqlQuery, times(1)).setParameter("p_userLogin",loginUser.toUpperCase());
        verify(this.sqlQuery, times(1)).setParameter("p_document",documentNumber.toUpperCase());
        verify(this.sqlQuery, times(1)).setParameter("p_country",country.name());
        verify(this.sqlQuery, times(1)).setParameter("p_userType",ItsUser.UserTypeEnum.SUPER.toString());
        verify(this.sqlQuery, times(1)).setParameter("p_status",1);
        verify(this.sqlQuery, times(1)).list();
     }

    @Test
    public void testGetUserContractByCreatesAQueryToFindUserContract() {
        String userName = "userName";
        String query = auditDAO.getUsersContractReportsQuery(userName, ParticipantTypeEnum.DISTRIBUTOR.name());
        auditDAO.getUsersContractReports(userName, ParticipantTypeEnum.DISTRIBUTOR.name(),true);
        // @Then a query is created, the parameters ares set and the query is executed
        verify(this.session, times(1)).createQuery(eq(query));
        verify(this.query, times(1)).setParameter("p_user",userName.toUpperCase());
        verify(this.query, times(1)).setParameter("p_participantType",ParticipantTypeEnum.DISTRIBUTOR);
        verify(this.query, times(1)).list();
    }






}
