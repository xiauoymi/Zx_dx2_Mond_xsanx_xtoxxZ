package com.monsanto.brazilvaluecapture.multiplier.revenue.service.impl;

import com.google.common.collect.Lists;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Technology;
import com.monsanto.brazilvaluecapture.core.foundation.RandomTestData;
import com.monsanto.brazilvaluecapture.core.foundation.service.BusinessException;
import com.monsanto.brazilvaluecapture.core.posting.model.bean.ReferenceNameEnum;
import com.monsanto.brazilvaluecapture.core.posting.service.PostingService;
import com.monsanto.brazilvaluecapture.multiplier.cultivar.model.bean.Cultivar;
import com.monsanto.brazilvaluecapture.multiplier.obtainer.model.bean.Obtainer;
import com.monsanto.brazilvaluecapture.multiplier.obtainer.model.bean.ObtainerPercentage;
import com.monsanto.brazilvaluecapture.multiplier.obtainer.service.ObtainerPercentageService;
import com.monsanto.brazilvaluecapture.seedsale.product.model.bean.Product;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.Sale;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.SaleItem;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.dao.MultiplierSaleDAO;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.dao.SaleDAO;
import com.monsanto.brazilvaluecapture.utils.DateUtils;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import static junit.framework.Assert.assertEquals;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class PostValueShareImpl_UT {

    public static final double DEFAULT_PERCENTAGE = 2.00;

    @Mock
    PostingService postingService;
    @Mock
    private MultiplierSaleDAO multiplierSaleDAO;
    @Mock
    private ObtainerPercentageService obtainerPercentageService;
    @Mock
    private SaleDAO saleDAO;
    @InjectMocks
    private PostValueShareImpl postValueShareImpl;

    @Before
    public void setUp() {
    }

    @Test
    public void testCalculateAndPostValueShareInvokesGetLastMonthMultiplierSalesNotCancelledSaleItems() throws BusinessException {
        //@When
        postValueShareImpl.calculateAndPostValueShare();
        //@Then
        verify(multiplierSaleDAO).getLastMonthMultiplierSalesNotCancelledSaleItems();
    }

    @Test
    public void testCalculateAndPostValueShareInvokesGetActiveObtainerPercentagesFor_whenThereIsSaleItemsToProcess() throws BusinessException {
        //@Given
        SaleItem saleItem = buildSaleItem();
        when(multiplierSaleDAO.getLastMonthMultiplierSalesNotCancelledSaleItems()).thenReturn(Lists.newArrayList(saleItem));
        when(obtainerPercentageService.getActiveObtainerPercentagesFor(saleItem.getProduct().getCultivar().getObtainer())).thenReturn(Lists.<ObtainerPercentage>newArrayList());
        //@When
        postValueShareImpl.calculateAndPostValueShare();
        //@Then
        verify(obtainerPercentageService).getActiveObtainerPercentagesFor(saleItem.getProduct().getCultivar().getObtainer());
    }

    @Test
    public void testCalculateAndPostValueShareInvokes1TimeGetActiveObtainerPercentagesFor_whenThereIs2SaleItemsToProcessWithTheSameObtainer() throws BusinessException {
        //@Given
        Obtainer obtainer = buildObtainer();
        SaleItem saleItem1 = buildSaleItem(obtainer);
        SaleItem saleItem2 = buildSaleItem(obtainer);
        List<SaleItem> saleItems = Lists.newArrayList();
        saleItems.add(saleItem1);
        saleItems.add(saleItem2);
        when(multiplierSaleDAO.getLastMonthMultiplierSalesNotCancelledSaleItems()).thenReturn(saleItems);
        when(obtainerPercentageService.getActiveObtainerPercentagesFor(obtainer)).thenReturn(Lists.<ObtainerPercentage>newArrayList());
        //@When
        postValueShareImpl.calculateAndPostValueShare();
        //@Then
        verify(obtainerPercentageService).getActiveObtainerPercentagesFor(obtainer);
    }

    @Test
    public void testCalculateAndPostValueShareInvokes2TimesGetActiveObtainerPercentagesFor_whenThereIs2SaleItemsToProcessWithDifferentObtainer() throws BusinessException {
        //@Given
        SaleItem saleItem1 = buildSaleItem();
        SaleItem saleItem2 = buildSaleItem();
        List<SaleItem> saleItems = Lists.newArrayList();
        saleItems.add(saleItem1);
        saleItems.add(saleItem2);
        when(multiplierSaleDAO.getLastMonthMultiplierSalesNotCancelledSaleItems()).thenReturn(saleItems);
        when(obtainerPercentageService.getActiveObtainerPercentagesFor(any(Obtainer.class))).thenReturn(Lists.<ObtainerPercentage>newArrayList());
        //@When
        postValueShareImpl.calculateAndPostValueShare();
        //@Then
        verify(obtainerPercentageService, times(2)).getActiveObtainerPercentagesFor(any(Obtainer.class));
    }

    @Test
    public void testCalculateAndPostValueShareNotInvokesGetActiveObtainerPercentagesFor_whenThereIsNoSaleItemsToProcess() throws BusinessException {
        //@Given
        when(multiplierSaleDAO.getLastMonthMultiplierSalesNotCancelledSaleItems()).thenReturn(Lists.<SaleItem>newArrayList());
        //@When
        postValueShareImpl.calculateAndPostValueShare();
        //@Then
        verify(obtainerPercentageService, never()).getActiveObtainerPercentagesFor(any(Obtainer.class));
    }

    @Test
    public void testCalculateAndPostValueShareNotInvokesSubmitAndSaveBonusPosting_whenNoSaleItemsHasValueShare() throws BusinessException {
        //@Given
        SaleItem saleItem = buildSaleItem();
        when(multiplierSaleDAO.getLastMonthMultiplierSalesNotCancelledSaleItems()).thenReturn(Lists.newArrayList(saleItem));
        when(obtainerPercentageService.getActiveObtainerPercentagesFor(saleItem.getProduct().getCultivar().getObtainer())).thenReturn(Lists.<ObtainerPercentage>newArrayList());
        //@When
        postValueShareImpl.calculateAndPostValueShare();
        //@Then
        verify(postingService, never()).submitAndSaveBonusPosting(
                any(BigDecimal.class),
                any(ReferenceNameEnum.class),
                anyString(),
                any(Date.class),
                any(Date.class),
                anyString());
    }

    @Test
    public void testCalculateAndPostValueShareNotInvokesUpdateSaleItem_whenNoSaleItemsHasValueShare() throws BusinessException {
        //@Given
        SaleItem saleItem = buildSaleItem();
        when(multiplierSaleDAO.getLastMonthMultiplierSalesNotCancelledSaleItems()).thenReturn(Lists.newArrayList(saleItem));
        when(obtainerPercentageService.getActiveObtainerPercentagesFor(saleItem.getProduct().getCultivar().getObtainer())).thenReturn(Lists.<ObtainerPercentage>newArrayList());
        //@When
        postValueShareImpl.calculateAndPostValueShare();
        //@Then
        verify(saleDAO, never()).updateSaleItem(saleItem);
    }

    @Test
    public void testCalculateAndPostValueShareNotInvokesSubmitAndSaveBonusPosting_whenSaleItemValueShareIs0() throws BusinessException {
        //@Given
        SaleItem saleItem = buildSaleItem();
        List<ObtainerPercentage> obtainerPercentages = buildObtainerPercentages(saleItem, 0);
        when(multiplierSaleDAO.getLastMonthMultiplierSalesNotCancelledSaleItems()).thenReturn(Lists.newArrayList(saleItem));
        when(obtainerPercentageService.getActiveObtainerPercentagesFor(saleItem.getProduct().getCultivar().getObtainer())).thenReturn(Lists.newArrayList(obtainerPercentages));
        //@When
        postValueShareImpl.calculateAndPostValueShare();
        //@Then
        verify(postingService, never()).submitAndSaveBonusPosting(
                any(BigDecimal.class),
                any(ReferenceNameEnum.class),
                anyString(),
                any(Date.class),
                any(Date.class),
                anyString());
    }

    @Test
    public void testCalculateAndPostValueShareSaleItemValueShareMustBe2_whenSaleItemNetRoyatyValueQuantityIs100AndObtainerPercentageIs2() throws BusinessException {
        //@Given
        SaleItem saleItem = buildSaleItem();
        List<ObtainerPercentage> obtainerPercentages = buildObtainerPercentages(saleItem);
        when(multiplierSaleDAO.getLastMonthMultiplierSalesNotCancelledSaleItems()).thenReturn(Lists.newArrayList(saleItem));
        when(obtainerPercentageService.getActiveObtainerPercentagesFor(saleItem.getProduct().getCultivar().getObtainer())).thenReturn(Lists.newArrayList(obtainerPercentages));
        //@When
        postValueShareImpl.calculateAndPostValueShare();
        //@Then
        double obtainerPercentage = 2;
        BigDecimal expectedSaleItemValueShare = BigDecimal.valueOf(obtainerPercentage).setScale(2, BigDecimal.ROUND_HALF_UP);
        assertEquals(expectedSaleItemValueShare, saleItem.getValueShare());
    }

    @Test
    public void testCalculateAndPostValueShareSaleItemValueShareMustBe75_whenSaleItemNetRoyatyValueQuantityIs1500AndObtainerPercentageIs5() throws BusinessException {
        //@Given
        SaleItem saleItem = buildSaleItem();
        saleItem.setNetRoyaltyValueQuantity(BigDecimal.valueOf(1500));
        List<ObtainerPercentage> obtainerPercentages = buildObtainerPercentages(saleItem, 5);
        when(multiplierSaleDAO.getLastMonthMultiplierSalesNotCancelledSaleItems()).thenReturn(Lists.newArrayList(saleItem));
        when(obtainerPercentageService.getActiveObtainerPercentagesFor(saleItem.getProduct().getCultivar().getObtainer())).thenReturn(Lists.newArrayList(obtainerPercentages));
        //@When
        postValueShareImpl.calculateAndPostValueShare();
        //@Then
        double expected = 75;
        BigDecimal expectedSaleItemValueShare = BigDecimal.valueOf(expected).setScale(2, BigDecimal.ROUND_HALF_UP);
        assertEquals(expectedSaleItemValueShare, saleItem.getValueShare());
    }

    @Test
    public void testCalculateAndPostValueShareInvokesSubmitAndSavePostingWithPostingValue6_whenSaleItemNetRoyatyValueQuantityIs200AndObtainerPercentageIs3() throws BusinessException {
        //@Given
        SaleItem saleItem = buildSaleItem();
        saleItem.setNetRoyaltyValueQuantity(BigDecimal.valueOf(200));
        List<ObtainerPercentage> obtainerPercentages = buildObtainerPercentages(saleItem, 3);
        when(multiplierSaleDAO.getLastMonthMultiplierSalesNotCancelledSaleItems()).thenReturn(Lists.newArrayList(saleItem));
        when(obtainerPercentageService.getActiveObtainerPercentagesFor(saleItem.getProduct().getCultivar().getObtainer())).thenReturn(obtainerPercentages);
        //@When
        postValueShareImpl.calculateAndPostValueShare();
        //@Then
        double expected = 6;
        BigDecimal expectedSaleItemValueShare = BigDecimal.valueOf(expected).setScale(2, BigDecimal.ROUND_HALF_UP);
        verify(postingService).submitAndSaveBonusPosting(
                eq(expectedSaleItemValueShare),
                any(ReferenceNameEnum.class),
                anyString(),
                any(Date.class),
                any(Date.class),
                anyString());
    }

    @Test
    public void testCalculateAndPostValueShareInvokesSubmitAndSavePostingWithReferenceNameValueShare_whenThereIsValidSaleItemsToPost() throws BusinessException {
        //@Given
        SaleItem saleItem = buildSaleItem();
        List<ObtainerPercentage> obtainerPercentages = buildObtainerPercentages(saleItem);
        when(multiplierSaleDAO.getLastMonthMultiplierSalesNotCancelledSaleItems()).thenReturn(Lists.newArrayList(saleItem));
        when(obtainerPercentageService.getActiveObtainerPercentagesFor(saleItem.getProduct().getCultivar().getObtainer())).thenReturn(obtainerPercentages);
        //@When
        postValueShareImpl.calculateAndPostValueShare();
        //@Then
        verify(postingService).submitAndSaveBonusPosting(
                any(BigDecimal.class),
                eq(ReferenceNameEnum.VALUE_SHARE),
                anyString(),
                any(Date.class),
                any(Date.class),
                anyString());
    }

    @Test
    public void testCalculateAndPostValueShareInvokesSubmitAndSavePostingWithReferenceExtendedDescriptionEqObtainerDescription_whenThereIsValidSaleItemsToPost() throws BusinessException {
        //@Given
        SaleItem saleItem = buildSaleItem();
        List<ObtainerPercentage> obtainerPercentages = buildObtainerPercentages(saleItem);
        when(multiplierSaleDAO.getLastMonthMultiplierSalesNotCancelledSaleItems()).thenReturn(Lists.newArrayList(saleItem));
        when(obtainerPercentageService.getActiveObtainerPercentagesFor(saleItem.getProduct().getCultivar().getObtainer())).thenReturn(obtainerPercentages);
        //@When
        postValueShareImpl.calculateAndPostValueShare();
        //@Then
        String expectedObtainerDescription = saleItem.getProduct().getCultivar().getObtainer().getDescription();
        verify(postingService).submitAndSaveBonusPosting(
                any(BigDecimal.class),
                any(ReferenceNameEnum.class),
                eq(expectedObtainerDescription),
                any(Date.class),
                any(Date.class),
                anyString());
    }

    @Test
    public void testCalculateAndPostValueShareInvokesSubmitAndSavePostingWithFileDateEqLastDateOfPreviousMonth_whenThereIsValidSaleItemsToPost() throws BusinessException {
        //@Given
        SaleItem saleItem = buildSaleItem();
        List<ObtainerPercentage> obtainerPercentages = buildObtainerPercentages(saleItem);
        when(multiplierSaleDAO.getLastMonthMultiplierSalesNotCancelledSaleItems()).thenReturn(Lists.newArrayList(saleItem));
        when(obtainerPercentageService.getActiveObtainerPercentagesFor(saleItem.getProduct().getCultivar().getObtainer())).thenReturn(obtainerPercentages);
        //@When
        postValueShareImpl.calculateAndPostValueShare();
        //@Then
        Date lastDateOfPreviousMonth = DateUtils.getLastDateOfPreviousMonth();
        verify(postingService).submitAndSaveBonusPosting(
                any(BigDecimal.class),
                any(ReferenceNameEnum.class),
                anyString(),
                eq(lastDateOfPreviousMonth),
                any(Date.class),
                anyString());
    }

    @Test
    public void testCalculateAndPostValueShareInvokesSubmitAndSavePostingWithPaymentDateEqLastDateOfPreviousMonth_whenThereIsValidSaleItemsToPost() throws BusinessException {
        //@Given
        SaleItem saleItem = buildSaleItem();
        List<ObtainerPercentage> obtainerPercentages = buildObtainerPercentages(saleItem);
        when(multiplierSaleDAO.getLastMonthMultiplierSalesNotCancelledSaleItems()).thenReturn(Lists.newArrayList(saleItem));
        when(obtainerPercentageService.getActiveObtainerPercentagesFor(saleItem.getProduct().getCultivar().getObtainer())).thenReturn(obtainerPercentages);
        //@When
        postValueShareImpl.calculateAndPostValueShare();
        //@Then
        Date lastDateOfPreviousMonth = DateUtils.getLastDateOfPreviousMonth();
        verify(postingService).submitAndSaveBonusPosting(
                any(BigDecimal.class),
                any(ReferenceNameEnum.class),
                anyString(),
                any(Date.class),
                eq(lastDateOfPreviousMonth),
                anyString());
    }

    @Test
    public void testCalculateAndPostValueShareInvokesSubmitAndSavePostingWithDefaultTechnologyNameEqSaleItemTechnologyDescription_whenThereIsValidSaleItemsToPost() throws BusinessException {
        //@Given
        SaleItem saleItem = buildSaleItem();
        List<ObtainerPercentage> obtainerPercentages = buildObtainerPercentages(saleItem);
        when(multiplierSaleDAO.getLastMonthMultiplierSalesNotCancelledSaleItems()).thenReturn(Lists.newArrayList(saleItem));
        when(obtainerPercentageService.getActiveObtainerPercentagesFor(saleItem.getProduct().getCultivar().getObtainer())).thenReturn(obtainerPercentages);
        //@When
        postValueShareImpl.calculateAndPostValueShare();
        //@Then
        String expectedTechnologyDescription = saleItem.getTechnologyDescription();
        verify(postingService).submitAndSaveBonusPosting(
                any(BigDecimal.class),
                any(ReferenceNameEnum.class),
                anyString(),
                any(Date.class),
                any(Date.class),
                eq(expectedTechnologyDescription));
    }

    @Test
    public void testCalculateAndPostValueShareInvokesUpdateSaleItem_whenSaleItemNetRoyatyValueQuantityIs200AndObtainerPercentageIs3() throws BusinessException {
        //@Given
        SaleItem saleItem = buildSaleItem();
        saleItem.setNetRoyaltyValueQuantity(BigDecimal.valueOf(200));
        List<ObtainerPercentage> obtainerPercentages = buildObtainerPercentages(saleItem, 3);
        when(multiplierSaleDAO.getLastMonthMultiplierSalesNotCancelledSaleItems()).thenReturn(Lists.newArrayList(saleItem));
        when(obtainerPercentageService.getActiveObtainerPercentagesFor(saleItem.getProduct().getCultivar().getObtainer())).thenReturn(obtainerPercentages);
        //@When
        postValueShareImpl.calculateAndPostValueShare();
        //@Then
        verify(saleDAO).updateSaleItem(saleItem);
    }

    @Test
    public void testCalculateAndPostValueShareInvokesSubmitAndSaveBonusWithPostingValue4_whenThereIs2SaleItemsWithNetRoyaltyValueQuantity100AndTheSameObtainerWithObtainerPercentage2AndTheSameTechnology() throws BusinessException {
        //@Given
        Obtainer obtainer1 = buildObtainer();
        Technology technology1 = buildTechnology();
        SaleItem saleItem11A = buildSaleItem(obtainer1, technology1);
        SaleItem saleItem11B = buildSaleItem(obtainer1, technology1);
        List<ObtainerPercentage> obtainerPercentages1 = buildObtainerPercentages(saleItem11A);
        List<SaleItem> saleItems = Lists.newArrayList();
        saleItems.add(saleItem11A);
        saleItems.add(saleItem11B);
        when(multiplierSaleDAO.getLastMonthMultiplierSalesNotCancelledSaleItems()).thenReturn(saleItems);
        when(obtainerPercentageService.getActiveObtainerPercentagesFor(obtainer1)).thenReturn(obtainerPercentages1);
        //@When
        postValueShareImpl.calculateAndPostValueShare();
        //@Then
        double expected = 4;
        BigDecimal expectedObtainerTechnologyValueShare = BigDecimal.valueOf(expected).setScale(2, BigDecimal.ROUND_HALF_UP);
        verify(postingService).submitAndSaveBonusPosting(
                eq(expectedObtainerTechnologyValueShare),
                any(ReferenceNameEnum.class),
                anyString(),
                any(Date.class),
                any(Date.class),
                anyString());
    }

    @Test
    public void testCalculateAndPostValueShareInvokesSubmitAndSaveBonusWithPostingValue4And8_whenThereIs4SaleItemsWithNetRoyaltyValueQuantity100And2WithTheSameObtainerWithObtainerPercentage2And2WithTheSameObtainerWithObtainerPercentage4AndTheSameTechnology() throws BusinessException {
        //@Given
        Obtainer obtainer1 = buildObtainer();
        Obtainer obtainer2 = buildObtainer();
        Technology technology1 = buildTechnology();
        SaleItem saleItem11A = buildSaleItem(obtainer1, technology1);
        SaleItem saleItem11B = buildSaleItem(obtainer1, technology1);
        SaleItem saleItem21A = buildSaleItem(obtainer2, technology1);
        SaleItem saleItem21B = buildSaleItem(obtainer2, technology1);
        List<ObtainerPercentage> obtainerPercentages1 = buildObtainerPercentages(saleItem11A);
        List<ObtainerPercentage> obtainerPercentages2 = buildObtainerPercentages(saleItem11A, 4);
        List<SaleItem> saleItems = Lists.newArrayList();
        saleItems.add(saleItem11A);
        saleItems.add(saleItem11B);
        saleItems.add(saleItem21A);
        saleItems.add(saleItem21B);
        when(multiplierSaleDAO.getLastMonthMultiplierSalesNotCancelledSaleItems()).thenReturn(saleItems);
        when(obtainerPercentageService.getActiveObtainerPercentagesFor(obtainer1)).thenReturn(obtainerPercentages1);
        when(obtainerPercentageService.getActiveObtainerPercentagesFor(obtainer2)).thenReturn(obtainerPercentages2);
        //@When
        postValueShareImpl.calculateAndPostValueShare();
        //@Then
        double expected1 = 4;
        BigDecimal expectedObtainer1TechnologyValueShare = BigDecimal.valueOf(expected1).setScale(2, BigDecimal.ROUND_HALF_UP);
        double expected2 = 8;
        BigDecimal expectedObtainer2TechnologyValueShare = BigDecimal.valueOf(expected2).setScale(2, BigDecimal.ROUND_HALF_UP);
        verify(postingService).submitAndSaveBonusPosting(
                eq(expectedObtainer1TechnologyValueShare),
                any(ReferenceNameEnum.class),
                anyString(),
                any(Date.class),
                any(Date.class),
                anyString());
        verify(postingService).submitAndSaveBonusPosting(
                eq(expectedObtainer2TechnologyValueShare),
                any(ReferenceNameEnum.class),
                anyString(),
                any(Date.class),
                any(Date.class),
                anyString());
    }

    private List<ObtainerPercentage> buildObtainerPercentages(SaleItem saleItem) {
        return buildObtainerPercentages(saleItem, DEFAULT_PERCENTAGE);
    }

    private List<ObtainerPercentage> buildObtainerPercentages(SaleItem saleItem, double percentage) {
        List<ObtainerPercentage> obtainerPercentages = Lists.newArrayList();
        ObtainerPercentage obtainerPercentage = new ObtainerPercentage();
        obtainerPercentage.setObtainer(saleItem.getProduct().getCultivar().getObtainer());
        obtainerPercentage.setPercentage(percentage);
        obtainerPercentages.add(obtainerPercentage);
        return obtainerPercentages;
    }

    private Obtainer buildObtainer() {
        Obtainer obtainer = new Obtainer();
        obtainer.setDescription(RandomTestData.createRandomString(10));
        return obtainer;
    }

    public Technology buildTechnology() {
        Technology technology = new Technology();
        technology.setDescription(RandomTestData.createRandomString(10));
        return technology;
    }

    private SaleItem buildSaleItem() {
        return buildSaleItem(null, null);
    }

    private SaleItem buildSaleItem(Obtainer obtainer) {
        if (obtainer == null) {
            obtainer = buildObtainer();
        }
        return buildSaleItem(obtainer, null);
    }

    private SaleItem buildSaleItem(Technology technology) {
        if (technology == null) {
            technology = buildTechnology();
        }
        return buildSaleItem(null, technology);
    }

    private SaleItem buildSaleItem(Obtainer obtainer, Technology technology) {
        if (obtainer == null) {
            obtainer = buildObtainer();
        }
        if (technology == null) {
            technology = buildTechnology();
        }
        Cultivar cultivar = new Cultivar();
        cultivar.setDescription(RandomTestData.createRandomString(10));
        cultivar.setObtainer(obtainer);
        Product product = new Product();
        product.setDescription(RandomTestData.createRandomString(10));
        product.setTechnology(technology);
        product.setCultivar(cultivar);
        SaleItem saleItem = new SaleItem();
        saleItem.setNetRoyaltyValueQuantity(BigDecimal.valueOf(100));
        saleItem.setProduct(product);
        Sale sale = new Sale();
        sale.setSaleType(Sale.SaleTypeEnum.MULTIPLIER_TO_GROWER_SEED_SALE);
        sale.addItem(saleItem);
        return saleItem;
    }

}