package com.monsanto.brazilvaluecapture.seedsale.sale.service.impl;

import com.google.common.collect.Sets;
import com.monsanto.brazilvaluecapture.core.base.model.bean.*;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Customer;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Technology;
import com.monsanto.brazilvaluecapture.core.customer.service.CustomerService;
import com.monsanto.brazilvaluecapture.core.foundation.service.EntityNotFoundException;
import com.monsanto.brazilvaluecapture.core.user.service.DocumentMismatchException;
import com.monsanto.brazilvaluecapture.seedsale.harvest.model.bean.Plantability;
import com.monsanto.brazilvaluecapture.seedsale.product.model.bean.*;
import com.monsanto.brazilvaluecapture.seedsale.product.service.ProductService;
import com.monsanto.brazilvaluecapture.seedsale.product.service.ProductivityByRegionService;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.Sale;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.SaleItem;
import com.monsanto.brazilvaluecapture.seedsale.sale.service.MultiplierSaleService;
import com.monsanto.brazilvaluecapture.seedsale.sale.service.SaleConstraintViolationException;
import com.monsanto.brazilvaluecapture.seedsale.sale.service.SaleService;
import com.monsanto.brazilvaluecapture.seedsale.template.model.bean.*;
import com.monsanto.brazilvaluecapture.seedsale.template.service.SaleTemplateService;
import edu.emory.mathcs.backport.java.util.Arrays;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.math.BigDecimal;
import java.util.List;
import java.util.Set;

import static junit.framework.Assert.assertTrue;
import static org.mockito.Matchers.anyLong;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.*;

/**
 * Created with IntelliJ IDEA.
 * User: IFERN1
 * Date: 9/18/13
 * Time: 9:36 AM
 * To change this template use File | Settings | File Templates.
 */
@RunWith(MockitoJUnitRunner.class)
public class MultiplierSaleValidator_UT {
    @Mock
    private ProductService productService;
    @Mock
    private SaleTemplateService saleTemplateService;
    @Mock
    private MultiplierSaleService multiplierSaleService;
    @Mock
    private SaleService saleService;
    @Mock
    private CustomerService customerService;
    @Mock
    private ProductivityByRegionService productivityByRegionService;
    @InjectMocks
    MultiplierSaleValidator multiplierSaleValidator;

    Customer multiplier = new Customer();
    Customer distributor = new Customer();
    Sale sale;

    @Before
    public void setUp() throws Exception {
        sale = new Sale(multiplier, distributor);
        when(productService.selectById(anyLong())).thenReturn(null);
    }

    @After
    public void tearDown() throws Exception {

    }

    @Test
    public void testValidateSaleType() throws Exception {
        sale.setSaleType(null);
        SaleConstraintViolationException saleConstraintViolationException = multiplierSaleValidator.validate(sale);
        assertTrue(saleConstraintViolationException.hasViolationWithMessage("Sale type is required."));
    }

    @Test
    public void testValidateCustomersHasDocuments() throws Exception {
        DocumentType documentType = new DocumentType("CNPJ", new Country(), "someMask");
        Document document = new Document(documentType, "12345566");
        multiplier = new Customer("someName", document, null, "someSapCode");
        sale = new Sale(multiplier, distributor);
        sale.setSaleType(Sale.SaleTypeEnum.MULTIPLIER_SEED_SALE);
        SaleConstraintViolationException saleConstraintViolationException = multiplierSaleValidator.validate(sale);
        assertTrue(saleConstraintViolationException.hasViolationWithMessage("Distributor is required."));
        assertTrue(saleConstraintViolationException.hasViolationWithMessage("Customer document type and document number combination is incorrect."));
    }

    @Test
    public void testValidateDealerHasDocuments() throws Exception {
        DocumentType documentType = new DocumentType("CNPJ", new Country(), "someMask");
        Document document = new Document(documentType, "12345566");
        distributor = new Customer("someName", document, null, "someSapCode");
        sale = new Sale(multiplier, distributor);
        sale.setSaleType(Sale.SaleTypeEnum.MULTIPLIER_SEED_SALE);
        SaleConstraintViolationException saleConstraintViolationException = multiplierSaleValidator.validate(sale);
        assertTrue(saleConstraintViolationException.hasViolationWithMessage("Customer is required."));
        assertTrue(saleConstraintViolationException.hasViolationWithMessage("Distributor document type and document number combination is incorrect."));
    }

    @Test
    public void testCreationDateConstraints() throws EntityNotFoundException, DocumentMismatchException {
        Customer customer = mock(Customer.class);
        when(customer.getDocumentValue()).thenReturn("someDocumentValue");
        when(customerService.getCustomerByCandidateKey(anyString(), anyString(), anyString(), anyString())).thenReturn(customer);
        DocumentType documentType = new DocumentType("someDesc", new Country(), "someMask");
        Document document = new Document(documentType, "12345566");
        multiplier = new Customer("someName", document, null, "someSapCode");
        distributor = new Customer("someName", document, null, "someSapCode");
        sale = new Sale(multiplier, distributor);
        sale.setCreationDate(null);
        sale.setSaleType(Sale.SaleTypeEnum.MULTIPLIER_SEED_SALE);
        SaleConstraintViolationException saleConstraintViolationException = multiplierSaleValidator.validate(sale);
        assertTrue(saleConstraintViolationException.hasViolationWithMessage("Creation date is required."));
    }

    @Test
    public void testSaleItemsExists() throws EntityNotFoundException, DocumentMismatchException {
        Customer customer = mock(Customer.class);
        when(customer.getDocumentValue()).thenReturn("someDocumentValue");
        when(customerService.getCustomerByCandidateKey(anyString(), anyString(), anyString(), anyString())).thenReturn(customer);
        DocumentType documentType = new DocumentType("someDesc", new Country(), "someMask");
        Document document = new Document(documentType, "12345566");
        multiplier = new Customer("someName", document, null, "someSapCode");
        distributor = new Customer("someName", document, null, "someSapCode");
        sale = new Sale(multiplier, distributor);
        sale.setCreationDate(null);
        sale.setSaleType(Sale.SaleTypeEnum.MULTIPLIER_SEED_SALE);
        SaleConstraintViolationException saleConstraintViolationException = multiplierSaleValidator.validate(sale);
        assertTrue(saleConstraintViolationException.hasViolationWithMessage("List of product is required."));
    }

    @Test
    public void testSaleItemsHasDueDate() {
        SaleItem saleItem = mock(SaleItem.class);
        when(saleItem.getSaleTemplate()).thenReturn(mock(SaleTemplate.class));
        when(saleItem.getProduct()).thenReturn(mock(Product.class));
        when(saleItem.isDueDateMandatory()).thenReturn(Boolean.TRUE);
        when(saleItem.hasDueDate()).thenReturn(Boolean.FALSE);
        when(saleItem.getSale()).thenReturn(mock(Sale.class));
        SaleConstraintViolationException saleConstraintViolationException = new SaleConstraintViolationException("someMessage");
        multiplierSaleValidator.verifyConstraintDueDate(saleItem, saleConstraintViolationException);
        assertTrue(saleConstraintViolationException.hasViolationWithMessage("Due date is required."));
    }

    @Test
    public void testCalculateCreditAndRoyaltyValuesInvokesGetCreditValueByRegionWithProductivityValue_whenCreditValueByRegionIsCalculated() {
        Sale sale = new Sale();
        Region region = new Region();
        sale.setRegion(region);
        State state = new State();
        sale.setState(state);
        SaleItem item = new SaleItem();
        Product product = new Product();
        Company company = new Company();
        Country country = new Country();
        country.setCode("br");
        company.setCountry(country);
        product.setCompany(company);
        Technology technology = new Technology();
        technology.setDescription("DUMMY_DESCRIPTION");
        product.setTechnology(technology);
        ProductivityByRegionValue productivityByRegionValue = new ProductivityByRegionValue();
        ProductivityByRegion productivityByRegion = new ProductivityByRegion();
        Plantability plantability = new Plantability();
        plantability.setDescription("DUMMY_PLANTABILITY");
        Productivity productivity = new Productivity();
        ProductivityValue productivityValue = new ProductivityValue();
        productivityValue.setProduct(product);
        productivityValue.setProductivityMax(new BigDecimal(35));
        productivityValue.setProductivityMin(new BigDecimal(25));
        productivity.addProductivityValues(productivityValue);
        plantability.addProductivity(productivity);
        productivity.setState(state);
        item.setPlantability(plantability.getDescription());
        item.setPlantabilityId(plantability);
        item.setProductivityValue(new BigDecimal(30));
        productivityByRegion.setPlantability(plantability);
        productivityByRegion.setRegion(region);
        productivityByRegionValue.setProductivityByRegion(productivityByRegion);
        productivityByRegionValue.setKgxha(new BigDecimal(55));
        Set<ProductivityByRegionValue> productivityByRegionValues = Sets.newHashSet(productivityByRegionValue);
        product.setProductivityByRegionValues(productivityByRegionValues);
        item.setProduct(product);
        item.setSoldQuantity(33l);
        SaleTemplate saleTemplate = new SaleTemplate();
        saleTemplate.setSaleType(Sale.SaleTypeEnum.MULTIPLIER_TO_GROWER_SEED_SALE);
        saleTemplate.setCreditCalculation(SaleTemplateCreditCalculationEnum.BY_REGION_OF_PLANTATION);
        Price price = new SeamlessPricing();
        DueDatePrice dueDatePrice = new DueDatePrice();
        price.setDueDatePrice(dueDatePrice);
        price.setTechnology(technology);
        saleTemplate.setPrices(Sets.newHashSet(price));
        item.setSaleTemplate(saleTemplate);
        SaleConstraintViolationException saleViolation = null;
        sale.addItem(item);
        when(multiplierSaleService.getCreditValueByRegion(BigDecimal.valueOf(item.getSoldQuantity()), item.getProductivityValue())).thenReturn(new BigDecimal(83));
        List<ProductivityByRegion> productivityByRegions = Arrays.asList(new ProductivityByRegion[] {productivityByRegion});
        when(productivityByRegionService.getFromRegionProductivity(item.getSale().getRegion())).thenReturn(productivityByRegions);
        when(productivityByRegionService.getFromRegionAndPlantabilityDescriptionAndProduct(item.getSale().getRegion(), item.getPlantability(), item.getProduct())).thenReturn(productivityByRegionValue);

        multiplierSaleValidator.calculateCreditAndRoyaltyValues(item, saleViolation);

        verify(multiplierSaleService).getCreditValueByRegion(BigDecimal.valueOf(item.getSoldQuantity()), item.getProductivityValue());
    }

}
