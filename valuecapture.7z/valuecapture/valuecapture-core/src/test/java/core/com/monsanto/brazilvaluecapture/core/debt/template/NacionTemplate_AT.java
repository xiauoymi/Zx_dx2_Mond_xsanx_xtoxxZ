package com.monsanto.brazilvaluecapture.core.debt.template;

import com.google.common.base.Strings;
import com.monsanto.brazilvaluecapture.core.debt.bean.DebtFooterDTO;
import com.monsanto.brazilvaluecapture.core.debt.bean.DebtHeaderDTO;
import com.monsanto.brazilvaluecapture.core.debt.bean.DebtItemDTO;
import com.monsanto.brazilvaluecapture.core.debt.dao.DebtDAO;
import com.monsanto.brazilvaluecapture.core.foundation.model.dao.SystemParameterDAO;
import com.monsanto.brazilvaluecapture.core.foundation.test.AbstractServiceIntegrationTests;
import com.monsanto.brazilvaluecapture.core.foundation.test.dbunit.DbUnitHelper;
import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.*;

import static org.fest.assertions.Assertions.assertThat;

/**
 * Created by IntelliJ IDEA.
 * User: ASEQU
 * Date: 6/12/13
 * Time: 7:05 PM
 * To change this template use File | Settings | File Templates.
 */
public class NacionTemplate_AT extends AbstractServiceIntegrationTests {

    @Autowired
    SystemParameterDAO systemParameterDAO;
    @Autowired
    private DebtDAO dao;
    private static final String DATE_PATTERN = "yyyyMMdd";
    private static final String COMA_SEPARATOR = ";";
    private static final String NACION_GROUP = "I_NACION_DEBT_NOTIFICATION";
    private static final String NACION_AGREEMENT_NUMBER_NAME = "H_NUMERO_CONVENIO";
    private static final String NACION_COMPANY_CUIT_NAME = "H_CUIT_MONSANTO";
    private static final String NACION_COMPANY_NAME = "H_NOMBRE_EMPRESA";
    private static final String NACION_SENT_NUMBER_NAME = "H_NUMERO_ENVIO";
    private static final String NACION_SENT_TYPE_NAME = "H_TIPO_ENVIO";
    private static final String NACION_TYPE_NAME = "H_TYPE";
    private static final String MACRO_BANK = "I_NACION_DEBT_NOTIFICATION";
    private static final Long ARGENTINA_ID = new Long(33261);

    private String today;
    private String expirationDate;
    private String aplicabilityDate;

    @Before
    public void setUp() throws Exception {
        String dataSetLocations = "classpath:data/core/debt-dataset.xml";
        DbUnitHelper.setup(dataSetLocations);

        SimpleDateFormat dateFormat = new SimpleDateFormat(DATE_PATTERN);
        this.today = dateFormat.format(new Date());
        this.expirationDate = dateFormat.format(getExpirationDate());
        this.aplicabilityDate = dateFormat.format(getNewApplicabilityDate());
    }

    @Test
    public void testFormatHeader_WhenDtoIsFormattedThenReturnStringWithKnowFormat(){

        DebtTemplate template = new NacionTemplate(new Date());

        DebtHeaderDTO dto = DebtHeaderDTO.getNacionInstance(this.systemParameterDAO.selectParameterValueByGroupAndNameAndCountryCode(NACION_GROUP, NACION_TYPE_NAME, "AR"),
                                            this.systemParameterDAO.selectParameterValueByGroupAndNameAndCountryCode(NACION_GROUP, NACION_AGREEMENT_NUMBER_NAME, "AR"),
                                            this.systemParameterDAO.selectParameterValueByGroupAndNameAndCountryCode(NACION_GROUP, NACION_COMPANY_CUIT_NAME, "AR"),
                                            this.systemParameterDAO.selectParameterValueByGroupAndNameAndCountryCode(NACION_GROUP, NACION_COMPANY_NAME, "AR"),
                                            this.systemParameterDAO.selectParameterValueByGroupAndNameAndCountryCode(NACION_GROUP, NACION_SENT_NUMBER_NAME, "AR"),
                                            this.systemParameterDAO.selectParameterValueByGroupAndNameAndCountryCode(NACION_GROUP, NACION_SENT_TYPE_NAME, "AR"));

        SimpleDateFormat dateFormat = new SimpleDateFormat(DATE_PATTERN);

        String stringDto = template.formatHeader(dto);

        assertThat(stringDto.substring(0, 1)).isEqualTo("H");
        assertThat(stringDto.substring(1, 11)).isEqualTo("0000000001");
        assertThat(stringDto.substring(11, 22)).isEqualTo("30503508725");
        assertThat(stringDto.substring(22, 52)).isEqualTo("MONSANTO ARGENTINA            ");
        assertThat(stringDto.substring(52, 62)).isEqualTo("0012345678");
        assertThat(stringDto.substring(62, 70)).isEqualTo(this.today);
        assertThat(stringDto.substring(76, 77)).isEqualTo("A");
        assertThat(stringDto.substring(77, 300)).isEqualTo(Strings.repeat(" ", 223));
    }

    @Test
    public void testFormatItems_WhenDtoListIsFormattedThenReturnStringWithKnowFormat(){

        List<DebtItemDTO> items = dao.getDebtItemsBy(MACRO_BANK, ARGENTINA_ID);

        DebtTemplate template = new NacionTemplate(getExpirationDate());
        String stringDto = template.formatItems(items);

        assertThat(stringDto.substring(0, 1)).isEqualTo("D");
        assertThat(stringDto.substring(1, 2)).isEqualTo("8");
        assertThat(stringDto.substring(2, 12)).isEqualTo("0001099596");
        assertThat(stringDto.substring(12, 23)).isEqualTo("30641405554");
        assertThat(stringDto.substring(23, 25)).isEqualTo("PA");
        assertThat(stringDto.substring(25, 41)).isEqualTo("107173          ");
        assertThat(stringDto.substring(41, 49)).isEqualTo(this.today);
        assertThat(stringDto.substring(49, 57)).isEqualTo(this.expirationDate);
        assertThat(stringDto.substring(57, 65)).isEqualTo(this.expirationDate);
        assertThat(stringDto.substring(65, 73)).isEqualTo("00000000");
        assertThat(stringDto.substring(73, 81)).isEqualTo("00000000");
        assertThat(stringDto.substring(81, 89)).isEqualTo("00000000");
        assertThat(stringDto.substring(89, 91)).isEqualTo("01");
        assertThat(stringDto.substring(91, 106)).isEqualTo("000000000125452");
        assertThat(stringDto.substring(106, 121)).isEqualTo("000000000000000");
        assertThat(stringDto.substring(121, 136)).isEqualTo("000000000000000");
        assertThat(stringDto.substring(136, 141)).isEqualTo("00000");
        assertThat(stringDto.substring(141, 143)).isEqualTo("80");
        assertThat(stringDto.substring(143, 149)).isEqualTo("      ");
        assertThat(stringDto.substring(149, 151)).isEqualTo("  ");
        assertThat(stringDto.substring(151, 161)).isEqualTo("NNNNNNNNNN");
        assertThat(stringDto.substring(161, 164)).isEqualTo("000");
        assertThat(stringDto.substring(164, 166)).isEqualTo("00");
        assertThat(stringDto.substring(166, 168)).isEqualTo("00");
        assertThat(stringDto.substring(168, 198)).isEqualTo(Strings.repeat(" ", 30));
        assertThat(stringDto.substring(198, 218)).isEqualTo(Strings.repeat(" ", 20));
        assertThat(stringDto.substring(218, 226)).isEqualTo(Strings.repeat(" ", 8));
        assertThat(stringDto.substring(226, 256)).isEqualTo("AEROLINEAS ARGENTINAS         ");
        assertThat(stringDto.substring(256, 300)).isEqualTo(Strings.repeat(" ", 44));
    }

    @Test
    public void testFormatFooter_WhenDtoListIsFormattedThenReturnStringWithKnowFormat(){

        DebtTemplate template = new NacionTemplate(new Date());

        DebtFooterDTO dto = DebtFooterDTO.getNacionInstance(this.systemParameterDAO.selectParameterValueByGroupAndNameAndCountryCode(NACION_GROUP, "T_TYPE", "AR"),
                                            new BigDecimal(1),
                                            this.systemParameterDAO.selectParameterValueByGroupAndNameAndCountryCode(NACION_GROUP, "D_CURRENCY", "AR"),
                                            new BigDecimal("1254.52"));

        String stringDto = template.formatFooter(dto);
        StringTokenizer tokenizer = new StringTokenizer(stringDto, COMA_SEPARATOR);

        assertThat(stringDto.substring(0, 1)).isEqualTo("T");
        assertThat(stringDto.substring(1, 8)).isEqualTo("0000001");
        assertThat(stringDto.substring(8, 10)).isEqualTo("80");
        assertThat(stringDto.substring(10, 25)).isEqualTo("000000000125452");
        assertThat(stringDto.substring(25, 27)).isEqualTo("02");
        assertThat(stringDto.substring(27, 42)).isEqualTo(Strings.repeat("0", 15));
        assertThat(stringDto.substring(42, 300)).isEqualTo(Strings.repeat(" ", 258));
    }

    @Test
    public void testPaddingNumber_WhenFiveDigitNumberGivenRetunStringLengthTenFulledWithFiveZerosToLeft() {

        NacionTemplate template = new NacionTemplate(new Date());

        assertThat(template.paddingNumber("12345", 10)).isEqualTo("0000012345");
    }

    @Test
    public void testPaddingAlphaNumeric_GivenStringWhenLengthFiveReturnStringsTenFulledWithBlanksToRigth() {
        NacionTemplate template = new NacionTemplate(new Date());

        assertThat(template.paddingAlphaNumeric("Hello", 10).length()).isEqualTo(10);
    }

    @Test
    public void testPaddingAlphaNumeric_GivenStringWhenIsLongerThanTheTotalLengthTruncateItToTheTotalLengthTen(){
        NacionTemplate template = new NacionTemplate(new Date());

        assertThat(template.paddingAlphaNumeric("This is the hello world example with..", 10).length()).isEqualTo(10);
    }

    @Test
    public void testPaddingAlphaNumeric_GivenLongWhenLengthFiveReturnStringsTenFulledWithBlanksToRigth() {
        NacionTemplate template = new NacionTemplate(new Date());

        assertThat(template.paddingAlphaNumeric(new Long(12345), 10)).isEqualTo("12345     ");
    }

    @Test
    public void testToUnformatedString_GivenNumberStringWithDotAndTwoDecimalsReturnStringNumberNoComaEndingWithTheTwoDecimals(){

        NacionTemplate template = new NacionTemplate(new Date());

        assertThat(template.toUnformatedString("1252.54")).isEqualTo("125254");
    }

    @Test
    public void testToUnformatedString_GivenNumberStringWithDotAndOneDecimalsReturnStringNumberNoComaEndingWithTheTwoDecimals(){

        NacionTemplate template = new NacionTemplate(new Date());

        assertThat(template.toUnformatedString("1252.5")).isEqualTo("125250");
    }

    @Test
    public void testToUnformatedString_GivenIntegerNumberStringReturnStringNumberNoComaEndingWithTwoZeros(){

        NacionTemplate template = new NacionTemplate(new Date());

        assertThat(template.toUnformatedString("1252")).isEqualTo("125200");
    }

    public Date getNewApplicabilityDate() {
        Calendar cal = new GregorianCalendar();
        Date date = new Date();
        cal.setTimeInMillis(date.getTime());
        cal.add(Calendar.DATE, 1);
        return new Date(cal.getTimeInMillis());
    }

    public Date getExpirationDate() {
        GregorianCalendar calendar = new GregorianCalendar();

		int dayOfTheWeek = calendar.get(Calendar.DAY_OF_WEEK)-1;
		if (dayOfTheWeek > 0 && dayOfTheWeek < 5){
			calendar.add(calendar.DAY_OF_MONTH, 1);
		}
		if (dayOfTheWeek == 5){
			calendar.add(calendar.DAY_OF_MONTH, 3);
		}
		if (dayOfTheWeek == 6){
			calendar.add(calendar.DAY_OF_MONTH, 2);
		}
		if (dayOfTheWeek == 0){
			calendar.add(calendar.DAY_OF_MONTH, 1);
		}

        return calendar.getTime();
    }
}
