package com.monsanto.brazilvaluecapture.seedsale.cashAdvance.validation.rules;

import com.monsanto.brazilvaluecapture.core.customer.model.bean.Customer;
import com.monsanto.brazilvaluecapture.core.foundation.validation.ValidationException;
import com.monsanto.brazilvaluecapture.core.presentation.beans.ResourceBundleTestHelper;
import com.monsanto.brazilvaluecapture.seedsale.cashAdvance.model.bean.CashAdvanceTransaction;
import org.junit.Test;

import static org.fest.assertions.Fail.fail;
import static org.fest.assertions.Assertions.*;

public class CashAdvancePartnerValidationRule_UT {
    @Test
    public void testValidateThrowsValidationException_WhenCashAdvanceTransactionHaveNoPartner(){
        CashAdvanceTransaction cashAdvanceTransaction = new CashAdvanceTransaction();
        CashAdvancePartnerValidationRule cashAdvancePartnerValidationRule = new CashAdvancePartnerValidationRule();

        try {
            cashAdvancePartnerValidationRule.validate(cashAdvanceTransaction);
            fail("should throw validation exception");
        } catch (ValidationException e) {
            assertThat(e).hasMessage("cash.advance.message.partner.required");
        }
    }

    @Test
    public void testValidateDoesNotThrowsValidationException_WhenCashAdvanceTransactionHavePartner(){
        CashAdvanceTransaction cashAdvanceTransaction = new CashAdvanceTransaction();
        cashAdvanceTransaction.setPartner(new Customer());
        CashAdvancePartnerValidationRule cashAdvancePartnerValidationRule = new CashAdvancePartnerValidationRule();

        try {
            cashAdvancePartnerValidationRule.validate(cashAdvanceTransaction);
        } catch (ValidationException e) {
            fail("should not throw validation exception");
        }
    }

    @Test
    public void testValidateDoesNotThrowsNullPointerException_WhenCashAdvanceTransactionIsNull() throws ValidationException {
        CashAdvancePartnerValidationRule cashAdvancePartnerValidationRule = new CashAdvancePartnerValidationRule();

        try {
            cashAdvancePartnerValidationRule.validate(null);
        } catch (NullPointerException e) {
            fail("should not throw NullPointerException");
        }
    }

    private String[] messages = {"cash.advance.message.partner.required"};

    @Test
    public void testI18mMessages_Brazil() throws Exception {
        ResourceBundleTestHelper.assertLanguageStrExistsForBrazil(messages);
    }

    @Test
    public void testI18mMessages_English() throws Exception {
        ResourceBundleTestHelper.assertLanguageStrExistsForUS(messages);
    }
}