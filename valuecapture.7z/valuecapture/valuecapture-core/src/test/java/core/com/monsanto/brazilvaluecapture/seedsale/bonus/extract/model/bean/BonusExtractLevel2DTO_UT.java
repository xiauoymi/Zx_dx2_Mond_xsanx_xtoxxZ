package com.monsanto.brazilvaluecapture.seedsale.bonus.extract.model.bean;

import com.monsanto.brazilvaluecapture.core.base.TechnologyTestData;
import org.junit.Test;

import static org.fest.assertions.Assertions.assertThat;

public class BonusExtractLevel2DTO_UT {

    @Test
   	public void testEquals_returnsTue_whenAreTheSame() {
        BonusExtractLevel2DTO dto = new BonusExtractLevel2DTO();
        assertThat(dto.equals(dto)).isTrue();
    }

    @Test
   	public void testEquals_returnsFalse_whenAreOfDifferentType() {
        BonusExtractLevel2DTO dto = new BonusExtractLevel2DTO();
        assertThat(dto.equals("string")).isFalse();
    }

    @Test
   	public void testEquals_returnsFalse_whenHaveDifferentAttributes() {
        BonusExtractLevel2DTO dto;
        BonusExtractLevel2DTO anotherDto;

        dto = new BonusExtractLevel2DTO();
        dto.setTechnology(TechnologyTestData.INTACTA);
        anotherDto = new BonusExtractLevel2DTO();
        anotherDto.setTechnology(TechnologyTestData.INTACTA_RR2);
        assertThat(dto.equals(anotherDto)).isFalse();
    }

    @Test
   	public void testEquals_returnsTue_whenHaveSameAttributes() {
        BonusExtractLevel2DTO dto;
        BonusExtractLevel2DTO anotherDto;

        dto = new BonusExtractLevel2DTO();
        anotherDto = new BonusExtractLevel2DTO();
        assertThat(dto.equals(anotherDto)).isTrue();

        dto = new BonusExtractLevel2DTO();
        dto.setTechnology(TechnologyTestData.INTACTA);
        anotherDto = new BonusExtractLevel2DTO();
        anotherDto.setTechnology(TechnologyTestData.INTACTA);
        assertThat(dto.equals(anotherDto)).isTrue();
    }
}
