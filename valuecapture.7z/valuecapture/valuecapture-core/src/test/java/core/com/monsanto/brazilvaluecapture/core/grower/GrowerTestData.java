package com.monsanto.brazilvaluecapture.core.grower;

import com.monsanto.brazilvaluecapture.core.base.model.bean.Company;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Country;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Crop;
import com.monsanto.brazilvaluecapture.core.foundation.RandomTestData;
import com.monsanto.brazilvaluecapture.core.grower.model.bean.Grower;

import static com.monsanto.brazilvaluecapture.core.base.CompanyTestData.BAYER;
import static com.monsanto.brazilvaluecapture.core.base.CompanyTestData.MONSANTO;
import static com.monsanto.brazilvaluecapture.core.base.CountryTestData.ARGENTINA;
import static com.monsanto.brazilvaluecapture.core.base.CountryTestData.PARAGUAY;

public class GrowerTestData {

    public static Grower GROWER_WITH_NAME_PEPE = createGrowerWithName("PEPE");
    public static Grower GROWER_WITH_NAME_JOSE = createGrowerWithName("JOSE");

	public static Grower createGrowerWithName(String name) {
        Grower grower = new Grower();
        grower.setName(name);
		return grower;
	}
}
