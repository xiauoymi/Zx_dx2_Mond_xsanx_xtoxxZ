package com.monsanto.brazilvaluecapture.jobs.importfile.messaging.executor.impl;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.ResourceBundle;

import com.monsanto.brazilvaluecapture.core.foundation.util.security.EnvironmentSpecificPropertyReader;
import com.monsanto.brazilvaluecapture.core.regionalization.CountriesHolder;
import junit.framework.Assert;

import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.monsanto.brazilvaluecapture.core.base.model.bean.Company;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Crop;
import com.monsanto.brazilvaluecapture.core.base.model.bean.DocumentType;
import com.monsanto.brazilvaluecapture.core.base.model.bean.OperationalYear;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Customer;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Technology;
import com.monsanto.brazilvaluecapture.core.foundation.service.BusinessException;
import com.monsanto.brazilvaluecapture.core.foundation.test.AbstractServiceIntegrationTests;
import com.monsanto.brazilvaluecapture.core.foundation.test.AssertHelper;
import com.monsanto.brazilvaluecapture.core.foundation.test.dbunit.DbUnitHelper;
import com.monsanto.brazilvaluecapture.core.importfile.model.ImportFileType;
import com.monsanto.brazilvaluecapture.core.importfile.model.bean.CsvImportFile;
import com.monsanto.brazilvaluecapture.core.importfile.model.dao.CsvImportFileFilter;
import com.monsanto.brazilvaluecapture.core.importfile.service.CsvImportFileService;
import com.monsanto.brazilvaluecapture.core.io.ProcessorConfig;
import com.monsanto.brazilvaluecapture.core.io.ProcessorConfig.ProcessorConfigProperties;
import com.monsanto.brazilvaluecapture.core.user.model.bean.UserDecorator;
import com.monsanto.brazilvaluecapture.core.user.service.UserNotFoundException;
import com.monsanto.brazilvaluecapture.core.user.service.UserService;
import com.monsanto.brazilvaluecapture.jobs.importfile.messaging.bean.FileImportDefinition;
import com.monsanto.brazilvaluecapture.jobs.importfile.messaging.bean.FileImportInfo;
import com.monsanto.brazilvaluecapture.jobs.importfile.messaging.bean.FileImportOperation;
import com.monsanto.brazilvaluecapture.multiplier.cultivar.model.bean.Cultivar;
import com.monsanto.brazilvaluecapture.multiplier.itsclass.model.bean.ItsClass;
import com.monsanto.brazilvaluecapture.multiplier.obtainer.model.bean.Obtainer;
import com.monsanto.brazilvaluecapture.multiplier.revenue.model.bean.BillingGermplasmCsvImportedLine;
import com.monsanto.brazilvaluecapture.multiplier.revenue.model.bean.BillingGermplasmImportDTO;
import com.monsanto.brazilvaluecapture.multiplier.revenue.model.bean.GermplasmRevenue;
import com.monsanto.brazilvaluecapture.multiplier.revenue.model.bean.VolumeCommercializedType;
import com.monsanto.brazilvaluecapture.multiplier.revenue.service.parser.BillingGermplasmCsvImportedFile;
import com.monsanto.brazilvaluecapture.multiplier.revenue.service.parser.BillingGermplasmCsvReader;
import com.monsanto.brazilvaluecapture.multiplier.revenue.service.parser.BillingGermplasmProcessor;
import com.monsanto.brazilvaluecapture.multiplier.volumereport.model.bean.VolumeReportDetail;
import com.monsanto.brazilvaluecapture.seedsale.harvest.model.bean.Harvest;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.ImportFileStatus;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

/**
 * 
 * @author carlos
 * 
 */
public class CsvBillingGermplasmFileCallback_AT extends
		AbstractServiceIntegrationTests {

	private static final String CSV_HEADER = "Tipo Documento Parceito;N�mero Documento Filial;C�digo ERP do Filial;Tipo Documento Matriz;N�mero Documento Matriz;C�digo ERP da Matriz;Empresa;Cultura;Ano Operacional;Safra;Tecnologia;Obtentora;Cultivar;Classe;Vencimento;Volume Comercializado;Valor Germoplasma;Observa��o";

	@Autowired
	@Qualifier("billingGermplasmProcessor")
	private BillingGermplasmProcessor billingGermplasmProcessor;

	@Autowired
	private CsvBillingGermplasmFileCallback csvBillingGermplasmFileCallback;

	@Autowired
	private CsvImportFileService csvImportFileService;
	
    @Autowired
    private UserService userService;

    @Autowired
    private CountriesHolder countriesHolder;

	private Locale localeBR = new Locale("pt", "BR");
	private ResourceBundle resourceBundle = ResourceBundle
			.getBundle("bundle/bundle");

	private ProcessorConfig processorConfig;
	private OperationalYear operationalYear;
	private Customer customer;
	private DocumentType customerDocumentType;
	private Harvest harvest;
	private Company company;
	private Crop crop;
	private UserDecorator user;
	private Customer matrix;
	private Obtainer obtainer;
	private ItsClass itsClass;
	private Cultivar cultivar;
	private Technology technology;
	private VolumeCommercializedType volumeCommercializedType;

	private VolumeReportDetail detail;

	@Before
	public void setup() throws UserNotFoundException {

		DbUnitHelper.setup("classpath:data/multiplier/basic-fixture.xml",
				"classpath:data/multiplier/revenue-multiplier-dataset.xml");


         //Added for LASVC to return a country brazil
         String configuredHost = "CONFIGURED_AND_REQUESTED_HOST_SAME";
		 EnvironmentSpecificPropertyReader env = mock(EnvironmentSpecificPropertyReader.class);
		 countriesHolder.setEnvironmentSpecificPropertyReader(env);
		 when(env.getEnvironmentSpecificProperty("host_name.argentina", null)).thenReturn("other");
		 when(env.getEnvironmentSpecificProperty("host_name.brazil", null)).thenReturn(configuredHost);
		 when(env.getEnvironmentSpecificProperty("host_name.paraguay", null)).thenReturn("another");

         countriesHolder.initialize();
         try{
            countriesHolder.resolveCountry(configuredHost);
         }catch(IllegalStateException ex)
         {

         }
		
		detail = (VolumeReportDetail) getSession().get(VolumeReportDetail.class, 991000008L);
		customer = (Customer) getSession().get(Customer.class, 900000003L);
		customerDocumentType = customer.getDocument().getDocumentType();
		harvest = (Harvest) getSession().get(Harvest.class, 900000001L);
		operationalYear = (OperationalYear) getSession().get(OperationalYear.class, 900000002L);
		company = (Company) getSession().get(Company.class, 900000001L);
		crop = (Crop) getSession().get(Crop.class, 900000001L);
		matrix = (Customer) getSession().get(Customer.class, 900000004L);
		obtainer = (Obtainer) getSession().get(Obtainer.class, 991000001L);
		itsClass = (ItsClass) getSession().get(ItsClass.class, 991000001L);
		cultivar = (Cultivar) getSession().get(Cultivar.class, 991000001L);
		technology = (Technology) getSession().get(Technology.class, 900000001L);
		volumeCommercializedType = VolumeCommercializedType.ONE;
		
		user = userService.getAuthenticatedUserBy("DANDRADE_S");
		user.setContextCompany(company);
		
		processorConfig = new ProcessorConfig();
		processorConfig
				.put(ProcessorConfigProperties.SELECTED_LOCALE, localeBR);
		processorConfig.put(ProcessorConfigProperties.LOGGED_USER, user);
		processorConfig.put(ProcessorConfigProperties.FILENAME, "sample.csv");
		processorConfig.put(ProcessorConfigProperties.BUNDLE, resourceBundle);


	}

	@Test
	public void test_getters_and_setters() {
		AssertHelper
				.testGettersAndSetters(new CsvBillingGermplasmFileCallback());
	}

	@Test
	public void given_valid_csv_line_when_awaiting_cancelling_and_orper_cancel_status_should_be_cancelled()
			throws IOException, BusinessException {

		initProcessorConfigDTO(false);

		InputStream resourceAsStream = getCsvInputStream();
		CsvImportFile csvImportFile = billingGermplasmProcessor.readLines(
				resourceAsStream, processorConfig);

		csvImportFile.setFileStatus(ImportFileStatus.AWAITING_CANCELLING);

		createValidLine(csvImportFile);

		csvBillingGermplasmFileCallback.setBundle(resourceBundle, localeBR);
		csvBillingGermplasmFileCallback.importFileCallback(new FileImportInfo(
				csvImportFile, user,
				FileImportDefinition.CSV_BILLING_GERMPLASM,
				FileImportOperation.CANCEL, localeBR, "bundle"));

		List<CsvImportFile> lines = csvImportFileService
				.selectByFilter(CsvImportFileFilter
						.getInstance()
						.addImportFileStatus(ImportFileStatus.CANCELLED)
						.addImportFileType(
								ImportFileType.CSV_BILLING_GERMPLASM));

		Assert.assertEquals(1, lines.size());
	}

	@Test
	public void given_valid_csv_line_when_uploaded_and_orper_import_status_should_be_awaiting_confirm()
			throws IOException, BusinessException {

		initProcessorConfigDTO(false);

		InputStream resourceAsStream = getCsvInputStream();
		CsvImportFile csvImportFile = billingGermplasmProcessor.readLines(
				resourceAsStream, processorConfig);

		createValidLine(csvImportFile);

		csvImportFile.setFileStatus(ImportFileStatus.UPLOADED);

		csvBillingGermplasmFileCallback.setBundle(resourceBundle, localeBR);

		csvBillingGermplasmFileCallback.importFileCallback(new FileImportInfo(
				csvImportFile, user,
				FileImportDefinition.CSV_BILLING_GERMPLASM,
				FileImportOperation.IMPORT, localeBR, "bundle"));

		List<CsvImportFile> lines = csvImportFileService
				.selectByFilter(CsvImportFileFilter
						.getInstance()
						.addImportFileStatus(ImportFileStatus.AWAITING_CONFIRM)
						.addImportFileType(
								ImportFileType.CSV_BILLING_GERMPLASM));

		Assert.assertEquals(1, lines.size());

	}

	@Test
	public void given_valid_csv_line_when_awaiting_processing_and_orper_proceed_status_should_be_processed()
			throws IOException, BusinessException {

		initProcessorConfigDTO(true);

		InputStream resourceAsStream = getCsvInputStream();
		CsvImportFile csvImportFile = billingGermplasmProcessor.readLines(
				resourceAsStream, processorConfig);

		createValidLine(csvImportFile);

		csvImportFile.setFileStatus(ImportFileStatus.AWAITING_PROCESSING);
		getSession().saveOrUpdate(csvImportFile);

		csvBillingGermplasmFileCallback.setBundle(resourceBundle, localeBR);

		csvBillingGermplasmFileCallback.importFileCallback(new FileImportInfo(
				csvImportFile, user,
				FileImportDefinition.CSV_BILLING_GERMPLASM,
				FileImportOperation.PROCEED, localeBR, "bundle"));

		List<CsvImportFile> lines = csvImportFileService
				.selectByFilter(CsvImportFileFilter
						.getInstance()
						.addImportFileStatus(ImportFileStatus.PROCESSED)
						.addImportFileType(
								ImportFileType.CSV_BILLING_GERMPLASM));

		Assert.assertEquals(1, lines.size());
	}

	@Test
	public void given_a_detail_with_two_germplasmRevenue_one_open_and_one_billed_and_a_line_that_overwrites_imports_when_I_process_file_then_only_open_germplasmRevenue_should_be_overwritten()
			throws IOException, BusinessException {
		initProcessorConfigDTO(true);

		BillingGermplasmCsvImportedLine validLine = new BillingGermplasmCsvImportedLine();
		validLine.setOverwriteImported(true);
		validLine.setVolumeReportDetail(detail);
		validLine.setVolumeCommercializedType(VolumeCommercializedType.THREE);
		validLine.setDueDate(getFutureDate());
		validLine.setBillingGermplasmNote("OVERWRITTEN");
		
		BillingGermplasmCsvImportedFile csvImportFile = new BillingGermplasmCsvImportedFile();
		csvImportFile.add(validLine);
		
		csvImportFile = billingGermplasmProcessor.write(csvImportFile, processorConfig);
		
		GermplasmRevenue revenueBilled = (GermplasmRevenue) getSession().get(GermplasmRevenue.class, 993000009L);
		Assert.assertFalse("Billed germplasm revenue should not be changed the observation", validLine.getBillingGermplasmNote().equals(revenueBilled.getObservation()));
		
		GermplasmRevenue revenueOpen = (GermplasmRevenue) getSession().get(GermplasmRevenue.class, 993000008L);
		Assert.assertEquals("Open germplasm revenue should be overwritten", validLine.getBillingGermplasmNote(), revenueOpen.getObservation());
	}

	@Test
	public void given_and_invalid_typeNumber_when_read_lines_should_have_one_warning()
			throws IOException, BusinessException {

		initProcessorConfigDTO(true);
		Locale locale = (Locale) processorConfig.get(ProcessorConfigProperties.SELECTED_LOCALE);
		BillingGermplasmImportDTO dto = (BillingGermplasmImportDTO) processorConfig.get(ProcessorConfigProperties.DTO);


		DateFormat df = new SimpleDateFormat("dd/MM/yyyy");
		StringBuilder csv = createLineForInputStream(null, 
				customerDocumentType.getDescription(),
				customer.getDocumentValue(), 
				customer.getCustomerSAPCode(),
				matrix.getDocument().getDocumentTypeDescription(),
				matrix.getDocumentValue(), 
				matrix.getCustomerSAPCode(),
				company.getDescription(),
				crop.getDescription(),
				operationalYear.getYear(), 
				harvest.getDescription(), 
				technology.getDescription(), 
				obtainer.getDescription(), 
				cultivar.getDescription(),
				itsClass.getAbbreviation(),
				df.format(getFutureDate()),
				"TYPE INVALID~", 
				BigDecimal.ONE.toString(),
				"Importacao referente safra 2013"
				);

		InputStream resourceAsStream = new ByteArrayInputStream(csv.toString().getBytes());
		
		BillingGermplasmCsvReader csvReader = new BillingGermplasmCsvReader(dto.isOverwriteImported());
		BillingGermplasmCsvImportedFile csvFile = csvReader.readFile(resourceAsStream, locale);
		
		Assert.assertEquals("Should have one warning", 1, csvFile.countWarnings());
		Assert.assertEquals("Should have not have valid lines", 0, csvFile.getAllEntities().size());
	}

	@Test
	public void given_and_invalid_dueDate_when_read_lines_should_have_one_warning()
			throws IOException, BusinessException {

		initProcessorConfigDTO(true);
		Locale locale = (Locale) processorConfig.get(ProcessorConfigProperties.SELECTED_LOCALE);
		BillingGermplasmImportDTO dto = (BillingGermplasmImportDTO) processorConfig.get(ProcessorConfigProperties.DTO);

		StringBuilder csv = createLineForInputStream(null, 
				customerDocumentType.getDescription(),
				customer.getDocumentValue(), 
				customer.getCustomerSAPCode(),
				matrix.getDocument().getDocumentTypeDescription(),
				matrix.getDocumentValue(), 
				matrix.getCustomerSAPCode(),
				company.getDescription(),
				crop.getDescription(),
				operationalYear.getYear(), 
				harvest.getDescription(), 
				technology.getDescription(), 
				obtainer.getDescription(), 
				cultivar.getDescription(),
				itsClass.getAbbreviation(),
				"INVALID DATE",
				volumeCommercializedType.getValue().toString(), 
				BigDecimal.ONE.toString(),
				"Importacao referente safra 2013"
				);

		InputStream resourceAsStream = new ByteArrayInputStream(csv.toString().getBytes());
		
		BillingGermplasmCsvReader csvReader = new BillingGermplasmCsvReader(dto.isOverwriteImported());
		BillingGermplasmCsvImportedFile csvFile = csvReader.readFile(resourceAsStream, locale);
		
		Assert.assertEquals("Should have one warning", 1, csvFile.countWarnings());
		Assert.assertEquals("Should have not have valid lines", 0, csvFile.getAllEntities().size());
	}

	private InputStream getCsvInputStream() {
		
		DateFormat df = new SimpleDateFormat("dd/MM/yyyy");

		StringBuilder csv = createLineForInputStream(null, 
				customerDocumentType.getDescription(),
				customer.getDocumentValue(), 
				customer.getCustomerSAPCode(),
				matrix.getDocument().getDocumentTypeDescription(),
				matrix.getDocumentValue(), 
				matrix.getCustomerSAPCode(),
				company.getDescription(),
				crop.getDescription(),
				operationalYear.getYear(), 
				harvest.getDescription(), 
				technology.getDescription(), 
				obtainer.getDescription(), 
				cultivar.getDescription(),
				itsClass.getAbbreviation(),
				df.format(getFutureDate()),
				volumeCommercializedType.getValue().toString(), 
				BigDecimal.ONE.toString(),
				"Importacao referente safra 2013"
				);

		return new ByteArrayInputStream(csv.toString().getBytes());
	}

	private Date getFutureDate() {
		Calendar calendar = Calendar.getInstance();
		calendar.add(Calendar.MONTH, 1);
		return calendar.getTime();
	}

	private StringBuilder createLineForInputStream(StringBuilder csv,
			String partnerDocumentType, String customerDocument,
			String customerSAPCode, String matrixDocumentType,
			String matrixDocument, String matrixSAPCode, String companyDescription,
			String cropDescription, String operationalYearDescription, String harvestDescription,
			String technologyDescription, String obtainerDescription, String cultivarDescription,
			String classAbbreaviation, String dueDate,
			String volumeCommercialized, String volumeGermplasm,
			String billingGermplasmNote) {
		
        if(csv==null) {
            csv = new StringBuilder(CSV_HEADER);
            csv.append("\n");
        }
     
		csv.append(partnerDocumentType == null ? "" : partnerDocumentType).append(";");
		csv.append(customerDocument == null ? "" : customerDocument).append(";");
		csv.append(customerSAPCode == null ? "" : customerSAPCode).append(";");
		csv.append(matrixDocumentType == null ? "" : matrixDocumentType).append(";");
		csv.append(matrixDocument == null ? "" : matrixDocument).append(";");
		csv.append(matrixSAPCode == null ? "" : matrixSAPCode).append(";");
		csv.append(companyDescription == null ? "" : companyDescription).append(";");
		csv.append(cropDescription == null ? "" : cropDescription).append(";");
		csv.append(operationalYearDescription == null ? "" : operationalYearDescription).append(";");
		csv.append(harvestDescription == null ? "" : harvestDescription).append(";");
		csv.append(technologyDescription == null ? "" : technologyDescription).append(";");
		csv.append(obtainerDescription == null ? "" : obtainerDescription).append(";");
		csv.append(cultivarDescription == null ? "" : cultivarDescription).append(";");
		csv.append(classAbbreaviation == null ? "" : classAbbreaviation).append(";");
		csv.append(dueDate == null ? "" : dueDate).append(";");
		csv.append(volumeCommercialized == null ? "" : volumeCommercialized).append(";");
		csv.append(volumeGermplasm == null ? "" : volumeGermplasm).append(";");
		csv.append(billingGermplasmNote == null ? "" : billingGermplasmNote);
		        
		csv.append("\n");
        
        return csv;
    }

	private void initProcessorConfigDTO(boolean overwriteImported) {
		BillingGermplasmImportDTO dto = new BillingGermplasmImportDTO();
		dto.setOverwriteImported(overwriteImported);
		processorConfig.put(ProcessorConfigProperties.DTO, dto);
	}

	private void createValidLine(CsvImportFile csvImportFile) {
		BillingGermplasmCsvImportedLine line = createImportedLine(
				csvImportFile,
				customerDocumentType.getDescription(),
				customer.getDocumentValue(), 
				customer.getCustomerSAPCode(),
				matrix.getDocument().getDocumentTypeDescription(),
				matrix.getDocumentValue(), 
				matrix.getCustomerSAPCode(),
				company.getDescription(),
				crop.getDescription(),
				operationalYear.getYear(), 
				harvest.getDescription(), 
				technology.getDescription(), 
				obtainer.getDescription(), 
				cultivar.getDescription(),
				itsClass.getAbbreviation(),
				getFutureDate(),
				volumeCommercializedType.getValue(), 
				BigDecimal.ONE,
				"Importacao referente safra 2013",
				1);

		saveAndFlush(line);
	}

	private BillingGermplasmCsvImportedLine createImportedLine(CsvImportFile csvImportFile,
			String partnerDocumentType, String customerDocument,
			String customerSAPCode, String matrixDocumentType,
			String matrixDocument, String matrixSAPCode, String companyDescription,
			String cropDescription, String operationalYearDescription, String harvestDescription,
			String technologyDescription, String obtainerDescription, String cultivarDescription,
			String classAbbreaviation, Date dueDate,
			Integer volumeCommercialized, BigDecimal volumeGermplasm,
			String billingGermplasmNote,
			int lineNumber) {
		
		BillingGermplasmCsvImportedLine line = new BillingGermplasmCsvImportedLine();
		line.setCsvImportFile(csvImportFile);
		line.setLine(lineNumber);		
		
		BillingGermplasmImportDTO dto = (BillingGermplasmImportDTO) processorConfig
				.get(ProcessorConfigProperties.DTO);
		line.setOverwriteImported(dto.isOverwriteImported());
		
		line.setCustomerDocumentTypeDescription(partnerDocumentType);
		line.setCustomerDocument(customerDocument);
		line.setCustomerSAPCode(customerSAPCode);
		line.setMatrixDocumentTypeDescription(matrixDocumentType);
		line.setMatrixDocument(matrixDocument);
		line.setMatrixSAPCode(matrixSAPCode);
		line.setCompanyDescription(companyDescription);
		line.setCropDescription(cropDescription);
		line.setOperationalYearDescription(operationalYearDescription);
		line.setHarvestDescription(harvestDescription);
		line.setTechnologyDescription(technologyDescription);
		line.setObtainerDescription(obtainerDescription);
		line.setCultivarDescription(cultivarDescription);
		line.setClassAbbreviation(classAbbreaviation);
		line.setDueDate(dueDate);
		line.setVolumeCommercializedTypeNumber(volumeCommercialized);
		line.setVolumeGermplasm(volumeGermplasm);
		line.setBillingGermplasmNote(billingGermplasmNote);
		
		return line;
	}

}
