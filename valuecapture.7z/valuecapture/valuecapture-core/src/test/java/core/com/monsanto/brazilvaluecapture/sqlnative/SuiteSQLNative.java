package com.monsanto.brazilvaluecapture.sqlnative;

import org.junit.Ignore;
import org.junit.extensions.cpsuite.ClasspathSuite;
import org.junit.extensions.cpsuite.ClasspathSuite.ClassnameFilters;
import org.junit.runner.RunWith;

@Ignore
@RunWith(value = ClasspathSuite.class)
@ClassnameFilters(value={"com.monsanto.brazilvaluecapture.sqlnative.*AT",
						"com.monsanto.brazilvaluecapture.sqlnative.*UT"})		
public class SuiteSQLNative {

}
