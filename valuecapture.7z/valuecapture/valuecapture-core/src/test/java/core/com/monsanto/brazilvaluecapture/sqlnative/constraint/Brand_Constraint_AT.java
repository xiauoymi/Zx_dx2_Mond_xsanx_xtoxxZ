package com.monsanto.brazilvaluecapture.sqlnative.constraint;

import com.monsanto.brazilvaluecapture.core.base.SystemTestFixture;
import com.monsanto.brazilvaluecapture.core.foundation.RandomTestData;
import com.monsanto.brazilvaluecapture.core.foundation.model.bean.StatusEnum;
import com.monsanto.brazilvaluecapture.core.foundation.service.BusinessException;
import com.monsanto.brazilvaluecapture.core.foundation.service.EntityAlreadyExistException;
import com.monsanto.brazilvaluecapture.core.foundation.test.AbstractServiceIntegrationTests;
import com.monsanto.brazilvaluecapture.seedsale.product.ProductTestData;
import com.monsanto.brazilvaluecapture.seedsale.product.model.bean.Brand;
import com.monsanto.brazilvaluecapture.seedsale.product.model.bean.Product;
import com.monsanto.brazilvaluecapture.seedsale.product.service.BrandService;
import com.monsanto.brazilvaluecapture.seedsale.product.service.BrandWithProductUndeletableException;
import junit.framework.Assert;
import org.hibernate.exception.GenericJDBCException;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

@Ignore
public class Brand_Constraint_AT extends AbstractServiceIntegrationTests {

	@Autowired
	private BrandService brandService;

	@Before
	public void init() {
		systemTestFixture = new SystemTestFixture(this);
	}

	@Test(expected = EntityAlreadyExistException.class)
	public void when_i_save_with_brand_existing_thanReturn_Exception()
			throws BusinessException {
		Brand brand = new Brand(RandomTestData.createRandomString(),
				systemTestFixture.monsantoBr, StatusEnum.INACTIVE);

		brandService.save(brand);

		Assert.assertNotNull(brand);
		Assert.assertNotNull(brand.getId());

		Brand b = new Brand();
		b.setDescription(brand.getDescription());
		b.setCompany(systemTestFixture.monsantoBr);
		b.setStatus(StatusEnum.ACTIVE);

		brandService.save(b);

		Assert.fail();

	}

	@Test(expected = BrandWithProductUndeletableException.class)
	public void when_i_delete_with_product_thanReturn_Exception()
			throws BusinessException {
		Brand brand = new Brand(RandomTestData.createRandomString(),
				systemTestFixture.monsantoBr, StatusEnum.INACTIVE);

		brandService.save(brand);

		Assert.assertNotNull(brand);
		Assert.assertNotNull(brand.getId());

		Product oneProduct = ProductTestData.createProduct(brand,
				this.systemTestFixture.soy, this.systemTestFixture.intacta,
				StatusEnum.ACTIVE, this.systemTestFixture.monsantoBr);
		getSession().saveOrUpdate(oneProduct);

		getSession().flush();

		getSession().evict(brand);
		getSession().evict(oneProduct);
		
		try {
			brandService.delete(brand);
		} catch (GenericJDBCException ex) {
			// Workaround to HSQLDB
			if (!getAssumptionTest().isEnvironmentWithSQLANSI()) {
				throw new BrandWithProductUndeletableException("Mock", ex);
			}
		}

		Assert.fail();

	}

}