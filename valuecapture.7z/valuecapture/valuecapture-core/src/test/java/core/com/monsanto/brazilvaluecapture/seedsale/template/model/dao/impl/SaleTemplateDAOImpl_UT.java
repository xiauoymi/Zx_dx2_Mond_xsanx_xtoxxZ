package com.monsanto.brazilvaluecapture.seedsale.template.model.dao.impl;

import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Technology;
import com.monsanto.brazilvaluecapture.core.wsiconsole.dao.impl.BaseHibernateUnitTest;
import com.monsanto.brazilvaluecapture.seedsale.template.model.bean.DueDatePrice;
import com.monsanto.brazilvaluecapture.seedsale.template.model.bean.DueDatePriceItem;
import com.monsanto.brazilvaluecapture.seedsale.template.model.bean.Price;
import com.monsanto.brazilvaluecapture.seedsale.template.model.bean.SaleTemplate;
import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

import static org.fest.assertions.Assertions.assertThat;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

public class SaleTemplateDAOImpl_UT extends BaseHibernateUnitTest {
    private SaleTemplateDAOImpl saleTemplateDAO;

    @Before
    public void setUp() {
        saleTemplateDAO = new SaleTemplateDAOImpl(sessionFactory);
    }

    @Test
    public void testGetReferenceDatesBySaleTemplateAndTechnologyReturnsReferenceDateListFromPrice_WhenRetrievingReferenceDates() {
        Technology technology = new Technology();
        SaleTemplate saleTemplate = new SaleTemplate();
        Price price = new Price();
        price.setTechnology(technology);
        DueDatePrice dueDatePrice = new DueDatePrice();
        DueDatePriceItem ddpi = new DueDatePriceItem("SOME REFERENCE");
        final ArrayList<DueDatePriceItem> expectedReferenceDateList = Lists.newArrayList(ddpi);
        dueDatePrice.setDueDatePriceItems(expectedReferenceDateList);
        price.setDueDatePrice(dueDatePrice);
        saleTemplate.setPrices(Sets.newHashSet(price));
        when(session.get(SaleTemplate.class,saleTemplate.getId())).thenReturn(saleTemplate);
        final List<DueDatePriceItem> actualReferenceDateList = saleTemplateDAO.getReferenceDatesBySaleTemplateAndTechnology(saleTemplate, technology);

        assertThat(actualReferenceDateList).isSameAs(expectedReferenceDateList);
    }

    @Test
    public void testGetReferenceDatesBySaleTemplateAndTechnologyReturnsRefreshesSaleTemplate_WhenRetrievingReferenceDates() {
        Technology technology = new Technology();
        SaleTemplate saleTemplate = new SaleTemplate();
        Price price = new Price();
        price.setTechnology(technology);
        DueDatePrice dueDatePrice = new DueDatePrice();
        DueDatePriceItem ddpi = new DueDatePriceItem("SOME REFERENCE");
        final ArrayList<DueDatePriceItem> expectedReferenceDateList = Lists.newArrayList(ddpi);
        dueDatePrice.setDueDatePriceItems(expectedReferenceDateList);
        price.setDueDatePrice(dueDatePrice);
        saleTemplate.setPrices(Sets.newHashSet(price));
        when(session.get(SaleTemplate.class,saleTemplate.getId())).thenReturn(saleTemplate);

        saleTemplateDAO.getReferenceDatesBySaleTemplateAndTechnology(saleTemplate, technology);

        verify(session).get(SaleTemplate.class, saleTemplate.getId());
    }

    @Test
    public void testGetReferenceDatesBySaleTemplateAndTechnologyReturnsEmptyList_WhenTechnologyDoesNotHaveDueDatePrice() {
        Technology technology = new Technology();
        SaleTemplate saleTemplate = new SaleTemplate();
        Price price = new Price();
        price.setTechnology(technology);
        saleTemplate.setPrices(Sets.newHashSet(price));
        when(session.get(SaleTemplate.class,saleTemplate.getId())).thenReturn(saleTemplate);

        final List<DueDatePriceItem> referenceDates = saleTemplateDAO.getReferenceDatesBySaleTemplateAndTechnology(saleTemplate, technology);

        assertThat(referenceDates).isEmpty();
    }
}