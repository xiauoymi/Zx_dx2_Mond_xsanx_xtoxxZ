package com.monsanto.brazilvaluecapture.core.grower.model.dao.impl;

import static org.junit.Assert.assertNotNull;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyBoolean;
import static org.mockito.Matchers.anyCollectionOf;
import static org.mockito.Matchers.anyList;
import static org.mockito.Matchers.anyLong;
import static org.mockito.Matchers.anyString;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import com.monsanto.brazilvaluecapture.core.grower.model.bean.*;
import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.SessionFactory;
import org.hibernate.classic.Session;
import org.hibernate.criterion.Restrictions;
import org.hibernate.criterion.SQLCriterion;
import org.hibernate.transform.ResultTransformer;
import org.hibernate.type.NullableType;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

import com.monsanto.brazilvaluecapture.core.base.model.bean.Country;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Document;
import com.monsanto.brazilvaluecapture.core.regionalization.VCCountry;
import com.monsanto.brazilvaluecapture.seedsale.billing.model.bean.PaymentStatus;
import com.monsanto.brazilvaluecapture.seedsale.cutoffTons.model.dao.impl.CutoffTonsDAOImpl;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.CutOffTons;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.CutOffTonsGrower;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.CutOffTons.EntityTypeEnum;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.CutOffTonsGrower.GrowerCutoffType;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.Sale.SaleTypeEnum;
import com.monsanto.brazilvaluecapture.seedsale.template.model.bean.SaleTemplate;


/**
 * Created by AFREI on 10/02/14.
 */
public class GrowerDAOImpl_UT {

    public static final String SOME_DOCUMENT_NUMBER = "Some document number";
    private GrowerDAOImpl growerDAO;
    private Query query;
    private SQLQuery sqlQuery;
    private Session session;
    private CutoffTonsDAOImpl cutoffTonsDAO;


    @Before
    public void setUp() {
        SessionFactory sessionFactory = mock(SessionFactory.class);
        this.session = mock(Session.class);
        when(sessionFactory.getCurrentSession()).thenReturn(this.session);
        this.growerDAO = new GrowerDAOImpl(sessionFactory);
        this.cutoffTonsDAO = new CutoffTonsDAOImpl(sessionFactory);
        this.query = mock(Query.class);
        this.sqlQuery = mock(SQLQuery.class);
        when(this.session.createQuery(anyString())).thenReturn(this.query);
        when(this.session.createSQLQuery(anyString())).thenReturn(sqlQuery);
        when(this.sqlQuery.addEntity(GrowerStatusView.class)).thenReturn(sqlQuery);
    }


    @Test
    public void testGrowerStatusByCreatesAQueryToFindGrowerStatus_AndSetAllPossibleParams() {
        VCCountry country = VCCountry.ARGENTINA;
        GrowerStatusModuleEnum statusModule = GrowerStatusModuleEnum.APPROVAL;
        String state = "state";
        String license = "1234";
        String creationUser = "user";
        String customerAgent = "customerAgent";
        String statusUser = "statusUser";
        Date dateFrom = new Date();
        Date dateTo = new Date();
        List<String> growersList = Arrays.asList(new String[]{""});
        boolean limitResults = true;

        String query = growerDAO.getGrowerStatusByQuery(growersList, license, statusModule, creationUser, customerAgent, statusUser, dateFrom, dateTo, state);
        growerDAO.getGrowerStatusBy(country, growersList, license, statusModule, creationUser, customerAgent, statusUser, dateFrom, dateTo, state, limitResults);

        // @Then a query is created, the parameters ares set and the query is executed
        verify(this.session, times(1)).createSQLQuery(eq(query));
        verify(this.sqlQuery, times(1)).setParameter("country", country.toString());
        verify(this.sqlQuery, times(1)).setParameterList("grower_list", growersList);
        verify(this.sqlQuery, times(1)).setParameter("licenseNumber", license);
        verify(this.sqlQuery, times(1)).setParameter("module", statusModule.toString());
        verify(this.sqlQuery, times(1)).setParameter("creationUser", creationUser);
        verify(this.sqlQuery, times(1)).setParameter("customerAgent", customerAgent);
        verify(this.sqlQuery, times(1)).setParameter("statusUser", statusUser);
        verify(this.sqlQuery, times(1)).setParameter("dateFrom", dateFrom);
        verify(this.sqlQuery, times(1)).setParameter("dateTo", dateTo);
        verify(this.sqlQuery, times(1)).setParameter("status", state);
        verify(this.sqlQuery, times(1)).setMaxResults(GrowerDAOImpl.SEARCH_LAS_RESULTS_LIMIT);
        verify(this.sqlQuery, times(1)).list();
    }

    @Test
    public void testGrowerStatusByCreatesAQueryToFindGrowerStatus_AndSetGrowerListParam() {
        VCCountry country = VCCountry.ARGENTINA;
        List<String> growersList = Arrays.asList(new String[]{""});
        boolean limitResults = true;

        String query = growerDAO.getGrowerStatusByQuery(growersList, null, null, null, null, null, null, null, null);
        growerDAO.getGrowerStatusBy(country, growersList, null, null, null, null, null, null, null, null, limitResults);

        // @Then a query is created, the parameters ares set and the query is executed
        verify(this.session, times(1)).createSQLQuery(eq(query));
        verify(this.sqlQuery, times(1)).setParameter("country", country.toString());
        verify(this.sqlQuery, times(1)).setParameterList("grower_list", growersList);
        verify(this.sqlQuery, times(0)).setParameter(eq("licenseNumber"), anyString());
        verify(this.sqlQuery, times(0)).setParameter(eq("module"), anyString());
        verify(this.sqlQuery, times(0)).setParameter(eq("creationUser"), anyString());
        verify(this.sqlQuery, times(0)).setParameter(eq("customerAgent"), anyString());
        verify(this.sqlQuery, times(0)).setParameter(eq("statusUser"), anyString());
        verify(this.sqlQuery, times(0)).setParameter(eq("dateFrom"), any(Date.class));
        verify(this.sqlQuery, times(0)).setParameter(eq("dateTo"), any(Date.class));
        verify(this.sqlQuery, times(0)).setParameter(eq("status"), anyString());
        verify(this.sqlQuery, times(1)).setMaxResults(GrowerDAOImpl.SEARCH_LAS_RESULTS_LIMIT);
        verify(this.sqlQuery, times(1)).list();
    }

    @Test
    public void testGrowerStatusByCreatesAQueryToFindGrowerStatus_AndSetLicenseParam() {
        VCCountry country = VCCountry.ARGENTINA;
        String license = "1234";
        boolean limitResults = true;

        String query = growerDAO.getGrowerStatusByQuery(null, license, null, null, null, null, null, null, null);
        growerDAO.getGrowerStatusBy(country, null, license, null, null, null, null, null, null, null, limitResults);

        // @Then a query is created, the parameters ares set and the query is executed
        verify(this.session, times(1)).createSQLQuery(eq(query));
        verify(this.sqlQuery, times(1)).setParameter("country", country.toString());
        verify(this.sqlQuery, times(0)).setParameterList(eq("grower_list"), anyCollectionOf(Grower.class));
        verify(this.sqlQuery, times(1)).setParameter("licenseNumber", license);
        verify(this.sqlQuery, times(0)).setParameter(eq("module"), anyString());
        verify(this.sqlQuery, times(0)).setParameter(eq("creationUser"), anyString());
        verify(this.sqlQuery, times(0)).setParameter(eq("customerAgent"), anyString());
        verify(this.sqlQuery, times(0)).setParameter(eq("statusUser"), anyString());
        verify(this.sqlQuery, times(0)).setParameter(eq("dateFrom"), any(Date.class));
        verify(this.sqlQuery, times(0)).setParameter(eq("dateTo"), any(Date.class));
        verify(this.sqlQuery, times(0)).setParameter(eq("status"), anyString());
        verify(this.sqlQuery, times(1)).setMaxResults(GrowerDAOImpl.SEARCH_LAS_RESULTS_LIMIT);
        verify(this.sqlQuery, times(1)).list();
    }

    @Test
    public void testGrowerStatusByCreatesAQueryToFindGrowerStatus_AndSetStatusModuleParam() {
        VCCountry country = VCCountry.ARGENTINA;
        GrowerStatusModuleEnum statusModule = GrowerStatusModuleEnum.APPROVAL;
        boolean limitResults = true;

        String query = growerDAO.getGrowerStatusByQuery(null, null, statusModule, null, null, null, null, null, null);
        growerDAO.getGrowerStatusBy(country, null, null, statusModule, null, null, null, null, null, null, limitResults);

        // @Then a query is created, the parameters ares set and the query is executed
        verify(this.session, times(1)).createSQLQuery(eq(query));
        verify(this.sqlQuery, times(1)).setParameter("country", country.toString());
        verify(this.sqlQuery, times(0)).setParameterList(eq("grower_list"), anyCollectionOf(Grower.class));
        verify(this.sqlQuery, times(0)).setParameter(eq("licenseNumber"), anyString());
        verify(this.sqlQuery, times(1)).setParameter("module", statusModule.toString());
        verify(this.sqlQuery, times(0)).setParameter(eq("creationUser"), anyString());
        verify(this.sqlQuery, times(0)).setParameter(eq("customerAgent"), anyString());
        verify(this.sqlQuery, times(0)).setParameter(eq("statusUser"), anyString());
        verify(this.sqlQuery, times(0)).setParameter(eq("dateFrom"), any(Date.class));
        verify(this.sqlQuery, times(0)).setParameter(eq("dateTo"), any(Date.class));
        verify(this.sqlQuery, times(0)).setParameter(eq("status"), anyString());
        verify(this.sqlQuery, times(1)).setMaxResults(GrowerDAOImpl.SEARCH_LAS_RESULTS_LIMIT);
        verify(this.sqlQuery, times(1)).list();
    }

    @Test
    public void testGrowerStatusByCreatesAQueryToFindGrowerStatus_AndSetCreationUserParam() {
        VCCountry country = VCCountry.ARGENTINA;
        String creationUser = "user";
        boolean limitResults = true;

        String query = growerDAO.getGrowerStatusByQuery(null, null, null, creationUser, null, null, null, null, null);
        growerDAO.getGrowerStatusBy(country, null, null, null, creationUser, null, null, null, null, null, limitResults);

        // @Then a query is created, the parameters ares set and the query is executed
        verify(this.session, times(1)).createSQLQuery(eq(query));
        verify(this.sqlQuery, times(1)).setParameter("country", country.toString());
        verify(this.sqlQuery, times(0)).setParameterList(eq("grower_list"), anyCollectionOf(Grower.class));
        verify(this.sqlQuery, times(0)).setParameter(eq("licenseNumber"), anyString());
        verify(this.sqlQuery, times(0)).setParameter(eq("module"), anyString());
        verify(this.sqlQuery, times(1)).setParameter("creationUser", creationUser);
        verify(this.sqlQuery, times(0)).setParameter(eq("customerAgent"), anyString());
        verify(this.sqlQuery, times(0)).setParameter(eq("statusUser"), anyString());
        verify(this.sqlQuery, times(0)).setParameter(eq("dateFrom"), any(Date.class));
        verify(this.sqlQuery, times(0)).setParameter(eq("dateTo"), any(Date.class));
        verify(this.sqlQuery, times(0)).setParameter(eq("status"), anyString());
        verify(this.sqlQuery, times(1)).setMaxResults(GrowerDAOImpl.SEARCH_LAS_RESULTS_LIMIT);
        verify(this.sqlQuery, times(1)).list();
    }

    @Test
    public void testGrowerStatusByCreatesAQueryToFindGrowerStatus_AndSetCustomerAgentParam() {
        VCCountry country = VCCountry.ARGENTINA;
        String customerAgent = "customerAgent";
        boolean limitResults = true;

        String query = growerDAO.getGrowerStatusByQuery(null, null, null, null, customerAgent, null, null, null, null);
        growerDAO.getGrowerStatusBy(country, null, null, null, null, customerAgent, null, null, null, null, limitResults);

        // @Then a query is created, the parameters ares set and the query is executed
        verify(this.session, times(1)).createSQLQuery(eq(query));
        verify(this.sqlQuery, times(1)).setParameter("country", country.toString());
        verify(this.sqlQuery, times(0)).setParameterList(eq("grower_list"), anyCollectionOf(Grower.class));
        verify(this.sqlQuery, times(0)).setParameter(eq("licenseNumber"), anyString());
        verify(this.sqlQuery, times(0)).setParameter(eq("module"), anyString());
        verify(this.sqlQuery, times(0)).setParameter(eq("creationUser"), anyString());
        verify(this.sqlQuery, times(1)).setParameter("customerAgent", customerAgent);
        verify(this.sqlQuery, times(0)).setParameter(eq("statusUser"), anyString());
        verify(this.sqlQuery, times(0)).setParameter(eq("dateFrom"), any(Date.class));
        verify(this.sqlQuery, times(0)).setParameter(eq("dateTo"), any(Date.class));
        verify(this.sqlQuery, times(0)).setParameter(eq("status"), anyString());
        verify(this.sqlQuery, times(1)).setMaxResults(GrowerDAOImpl.SEARCH_LAS_RESULTS_LIMIT);
        verify(this.sqlQuery, times(1)).list();
    }

    @Test
    public void testGrowerStatusByCreatesAQueryToFindGrowerStatus_AndSetStatusUserParam() {
        VCCountry country = VCCountry.ARGENTINA;
        String statusUser = "statusUser";
        boolean limitResults = true;

        String query = growerDAO.getGrowerStatusByQuery(null, null, null, null, null, statusUser, null, null, null);
        growerDAO.getGrowerStatusBy(country, null, null, null, null, null, statusUser, null, null, null, limitResults);

        // @Then a query is created, the parameters ares set and the query is executed
        verify(this.session, times(1)).createSQLQuery(eq(query));
        verify(this.sqlQuery, times(1)).setParameter("country", country.toString());
        verify(this.sqlQuery, times(0)).setParameterList(eq("grower_list"), anyCollectionOf(Grower.class));
        verify(this.sqlQuery, times(0)).setParameter(eq("licenseNumber"), anyString());
        verify(this.sqlQuery, times(0)).setParameter(eq("module"), anyString());
        verify(this.sqlQuery, times(0)).setParameter(eq("creationUser"), anyString());
        verify(this.sqlQuery, times(0)).setParameter(eq("customerAgent"), anyString());
        verify(this.sqlQuery, times(1)).setParameter("statusUser", statusUser);
        verify(this.sqlQuery, times(0)).setParameter(eq("dateFrom"), any(Date.class));
        verify(this.sqlQuery, times(0)).setParameter(eq("dateTo"), any(Date.class));
        verify(this.sqlQuery, times(0)).setParameter(eq("status"), anyString());
        verify(this.sqlQuery, times(1)).setMaxResults(GrowerDAOImpl.SEARCH_LAS_RESULTS_LIMIT);
        verify(this.sqlQuery, times(1)).list();
    }

    @Test
    public void testGrowerStatusByCreatesAQueryToFindGrowerStatus_AndSetDateFromParam() {
        VCCountry country = VCCountry.ARGENTINA;
        Date dateFrom = new Date();
        boolean limitResults = true;

        String query = growerDAO.getGrowerStatusByQuery(null, null, null, null, null, null, dateFrom, null, null);
        growerDAO.getGrowerStatusBy(country, null, null, null, null, null, null, dateFrom, null, null, limitResults);

        // @Then a query is created, the parameters ares set and the query is executed
        verify(this.session, times(1)).createSQLQuery(eq(query));
        verify(this.sqlQuery, times(1)).setParameter("country", country.toString());
        verify(this.sqlQuery, times(0)).setParameterList(eq("grower_list"), anyCollectionOf(Grower.class));
        verify(this.sqlQuery, times(0)).setParameter(eq("licenseNumber"), anyString());
        verify(this.sqlQuery, times(0)).setParameter(eq("module"), anyString());
        verify(this.sqlQuery, times(0)).setParameter(eq("creationUser"), anyString());
        verify(this.sqlQuery, times(0)).setParameter(eq("customerAgent"), anyString());
        verify(this.sqlQuery, times(0)).setParameter(eq("statusUser"), anyString());
        verify(this.sqlQuery, times(1)).setParameter("dateFrom", dateFrom);
        verify(this.sqlQuery, times(0)).setParameter(eq("dateTo"), any(Date.class));
        verify(this.sqlQuery, times(0)).setParameter(eq("status"), anyString());
        verify(this.sqlQuery, times(1)).setMaxResults(GrowerDAOImpl.SEARCH_LAS_RESULTS_LIMIT);
        verify(this.sqlQuery, times(1)).list();
    }

    @Test
    public void testGrowerStatusByCreatesAQueryToFindGrowerStatus_AndSetDateToParam() {
        VCCountry country = VCCountry.ARGENTINA;
        Date dateTo = new Date();
        boolean limitResults = true;

        String query = growerDAO.getGrowerStatusByQuery(null, null, null, null, null, null,null, dateTo, null);
        growerDAO.getGrowerStatusBy(country, null, null, null, null, null, null, null,dateTo, null, limitResults);

        // @Then a query is created, the parameters ares set and the query is executed
        verify(this.session, times(1)).createSQLQuery(eq(query));
        verify(this.sqlQuery, times(1)).setParameter("country", country.toString());
        verify(this.sqlQuery, times(0)).setParameterList(eq("grower_list"), anyCollectionOf(Grower.class));
        verify(this.sqlQuery, times(0)).setParameter(eq("licenseNumber"), anyString());
        verify(this.sqlQuery, times(0)).setParameter(eq("module"), anyString());
        verify(this.sqlQuery, times(0)).setParameter(eq("creationUser"), anyString());
        verify(this.sqlQuery, times(0)).setParameter(eq("customerAgent"), anyString());
        verify(this.sqlQuery, times(0)).setParameter(eq("statusUser"), anyString());
        verify(this.sqlQuery, times(0)).setParameter(eq("dateFrom"), any(Date.class));
        verify(this.sqlQuery, times(1)).setParameter("dateTo", dateTo);
        verify(this.sqlQuery, times(0)).setParameter(eq("status"), anyString());
        verify(this.sqlQuery, times(1)).setMaxResults(GrowerDAOImpl.SEARCH_LAS_RESULTS_LIMIT);
        verify(this.sqlQuery, times(1)).list();
    }

    @Test
    public void testGrowerStatusByCreatesAQueryToFindGrowerStatus_AndSetStatusParam() {
        VCCountry country = VCCountry.ARGENTINA;
        String state = "state";
        boolean limitResults = true;

        String query = growerDAO.getGrowerStatusByQuery(null, null, null, null, null, null, null, null,state);
        growerDAO.getGrowerStatusBy(country, null, null, null, null, null, null, null,null, state, limitResults);

        // @Then a query is created, the parameters ares set and the query is executed
        verify(this.session, times(1)).createSQLQuery(eq(query));
        verify(this.sqlQuery, times(1)).setParameter("country", country.toString());
        verify(this.sqlQuery, times(0)).setParameterList(eq("grower_list"), anyCollectionOf(Grower.class));
        verify(this.sqlQuery, times(0)).setParameter(eq("licenseNumber"), anyString());
        verify(this.sqlQuery, times(0)).setParameter(eq("module"), anyString());
        verify(this.sqlQuery, times(0)).setParameter(eq("creationUser"), anyString());
        verify(this.sqlQuery, times(0)).setParameter(eq("customerAgent"), anyString());
        verify(this.sqlQuery, times(0)).setParameter(eq("statusUser"), anyString());
        verify(this.sqlQuery, times(0)).setParameter(eq("dateFrom"), any(Date.class));
        verify(this.sqlQuery, times(0)).setParameter(eq("dateTo"), any(Date.class));
        verify(this.sqlQuery, times(1)).setParameter("status", state);
        verify(this.sqlQuery, times(1)).setMaxResults(GrowerDAOImpl.SEARCH_LAS_RESULTS_LIMIT);
        verify(this.sqlQuery, times(1)).list();
    }
    
    @Test
    public void testHasSale() {
    	Long l = new Long(1L);
        growerDAO.hasSale(l, "2014",new ArrayList(), PaymentStatus.FULLY_PAID);

        // @Then a query is created, the parameters ares set and the query is executed
        verify(this.query, times(1)).setParameter("growerId", l);
        verify(this.query, times(1)).setParameter("operationalYear", "2014");
        verify(this.query, times(1)).setParameterList(eq("saleTypes"), anyCollectionOf(SaleTypeEnum.class));
        verify(this.query, times(1)).setParameter(eq("paymentStatus"), any(PaymentStatus.class));
        verify(this.query, times(1)).list();
    }
    
    @Test
    public void test_GetPaidCutoffTonsGrower(){
    	SaleTemplate saleTemplate = new SaleTemplate();
    	saleTemplate.setId(2363L);
		Grower grower = new Grower();
		grower.setId(273127L);
        Document document = new Document();
        document.setValue(SOME_DOCUMENT_NUMBER);
        grower.setDocument(document);
		Country country = new Country("AR", "AR");
		Query hqlQquery = mock(Query.class);
		when(this.session.createQuery(anyString())).thenReturn(hqlQquery );
		when(hqlQquery.setBoolean(anyString(), anyBoolean())).thenReturn(hqlQquery);
		when(hqlQquery.setParameterList(anyString(), anyList())).thenReturn(hqlQquery);
		when(hqlQquery.setLong(anyString(), any(Long.class))).thenReturn(hqlQquery);
		when(hqlQquery.setParameter(anyString(), any(NullableType.class))).thenReturn(hqlQquery);
        
		this.cutoffTonsDAO.getPaidCutoffTonsGrower(saleTemplate , grower,country,GrowerStatusEnum.ACTIVE,GrowerBillingStatus.ACTIVE );
		verify(hqlQquery, times(1)).list();
    }
    
    @Test
    public void test_GetConsumedTonsByGrowerAndSaleTemplate(){
    	SaleTemplate saleTemplate = new SaleTemplate();
    	saleTemplate.setId(2363L);
		Grower grower = new Grower();
		grower.setId(273127L);
		when(this.session.createQuery(anyString())).thenReturn(query);
		when(query.setParameter(anyString(), anyLong())).thenReturn(query);
		when(query.setParameter(anyString(),any(NullableType.class))).thenReturn(query);
    	this.cutoffTonsDAO.getConsumedTonsByGrowerAndSaleTemplate(saleTemplate, grower);
    	verify(this.query, times(1)).uniqueResult();
    }
    
    @Test
	public void test_GetCutoffTonsGrower() {
		SaleTemplate saleTemplate = new SaleTemplate();
		saleTemplate.setId(2363L);
		Grower grower = new Grower();
		Country country = new Country("AR", "AR");
		grower.setId(273127L);

		SQLQuery sqlQuery = Mockito.mock(SQLQuery.class);
		when(this.session.createSQLQuery(anyString())).thenReturn(sqlQuery);
		when(sqlQuery.addEntity(CutOffTons.class)).thenReturn(sqlQuery);
		when(sqlQuery.setLong(eq("saleTemplateId"), eq(saleTemplate.getId()))).thenReturn(sqlQuery);
		when(sqlQuery.setLong(eq("growerId"), eq(grower.getId()))).thenReturn(sqlQuery);
		when(sqlQuery.setString(eq("entityType"),eq(EntityTypeEnum.GROWER.name()))).thenReturn(sqlQuery);
		this.cutoffTonsDAO.getCutoffTonsGrower(saleTemplate, grower, country,GrowerCutoffType.WithCutoff);
		verify(sqlQuery, times(1)).list();
	}
    
    
    @Test
    public void test_GetGrowersToSetCutoffTons(){
    	SaleTemplate saleTemplate = new SaleTemplate();
    	saleTemplate.setId(2363L);
		Grower grower = new Grower();
		grower.setId(273127L);
		Country country = new Country("AR", "AR");
		SQLQuery sqlQuery = Mockito.mock(SQLQuery.class);
		when(this.session.createSQLQuery(anyString())).thenReturn(sqlQuery);
		when(sqlQuery.addEntity(CutOffTons.class)).thenReturn(sqlQuery);
		when(sqlQuery.setLong(eq("saleTemplateId"), eq(saleTemplate.getId()))).thenReturn(sqlQuery);
		when(sqlQuery.setLong(eq("growerId"), eq(grower.getId()))).thenReturn(sqlQuery);
		when(sqlQuery.setString(eq("entityType"),eq(EntityTypeEnum.GROWER.name()))).thenReturn(sqlQuery);
		List<CutOffTonsGrower> l = this.cutoffTonsDAO.getCutoffTonsGrower(saleTemplate, grower, country,GrowerCutoffType.WithCutoff);
    	assertNotNull(l);
    }
}
