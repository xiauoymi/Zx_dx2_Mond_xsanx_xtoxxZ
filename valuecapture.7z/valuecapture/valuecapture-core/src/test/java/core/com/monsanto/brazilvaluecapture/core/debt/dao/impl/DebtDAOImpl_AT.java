package com.monsanto.brazilvaluecapture.core.debt.dao.impl;

import com.google.common.collect.Iterables;
import com.monsanto.brazilvaluecapture.core.debt.bean.DebtItemDTO;
import com.monsanto.brazilvaluecapture.core.debt.dao.DebtDAO;
import com.monsanto.brazilvaluecapture.core.foundation.test.AbstractServiceIntegrationTests;
import com.monsanto.brazilvaluecapture.core.foundation.test.dbunit.DbUnitHelper;
import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

import static org.fest.assertions.Assertions.assertThat;

/**
 * Created by IntelliJ IDEA.
 * User: ASEQU
 * Date: 6/6/13
 * Time: 3:50 PM
 * To change this template use File | Settings | File Templates.
 */
public class DebtDAOImpl_AT extends AbstractServiceIntegrationTests {

    private static final String MACRO_BANK = "I_MACRO_DEBT_NOTIFICATION";
    private static final String D_TYPE = "D";
    private static final String SERVICE_CODE = "0123";
    private static final String DOCUMENT_TYPE = "80";
    private static final String CURRENCY_CODE = "80";
    private static final String ORIGIN_COMPANY_CUIT = "30641405554";
    private static final String TEXT_ONE = "DEUDA TECNOLOGIA INTACTA";
    private static final String TEXT_TWO = "MONSANTO ARGENTINA";
    private static final Long ARGENTINA_ID = new Long(33261);

    @Autowired
    private DebtDAO dao;

    @Before
    public void setUp() throws Exception {
        String dataSetLocations = "classpath:data/core/debt-dataset.xml";
        DbUnitHelper.setup(dataSetLocations);
    }

    @Test
    public void testGetDebtItems_WhenTheBankParameterIsMacroReturnItemsWithBankGroupColumnsCompleted() {

        List<DebtItemDTO> items = dao.getDebtItemsBy(MACRO_BANK, ARGENTINA_ID);
        DebtItemDTO debt = Iterables.getOnlyElement(items);

        assertThat(items).isNotEmpty();
        assertThat(debt.getType()).isEqualTo(D_TYPE);
        assertThat(debt.getServiceCode()).isEqualTo(SERVICE_CODE);
        assertThat(debt.getDocumentType()).isEqualTo(DOCUMENT_TYPE);
        assertThat(debt.getCurrencyCode()).isEqualTo(CURRENCY_CODE);
        assertThat(debt.getDebtorDocumentNumber()).isEqualTo(ORIGIN_COMPANY_CUIT);
        assertThat(debt.getTextOne()).isEqualTo(TEXT_ONE);
        assertThat(debt.getTextTwo()).isEqualTo(TEXT_TWO);
    }

    @Test
    public void testGetDebtItems_WhenTheBankParameterIsBlankReturnItemsWithBankGroupColumnsEmpty() {

        List<DebtItemDTO> items = dao.getDebtItemsBy("", ARGENTINA_ID);
        DebtItemDTO debt = Iterables.getOnlyElement(items);

        assertThat(items).isNotEmpty();
        assertThat(debt.getType()).isNullOrEmpty();
        assertThat(debt.getServiceCode()).isNullOrEmpty();
        assertThat(debt.getDocumentType()).isNullOrEmpty();
        assertThat(debt.getCurrencyCode()).isNullOrEmpty();
        assertThat(debt.getOriginCompanyCuit()).isNullOrEmpty();
        assertThat(debt.getTextOne()).isNullOrEmpty();
        assertThat(debt.getTextTwo()).isNullOrEmpty();
    }

    @Test
    public void testGetDebtItems_WhenTheBankParameterIsNullReturnItemsWithBankGroupColumnsEmpty() {

        List<DebtItemDTO> items = dao.getDebtItemsBy(null, ARGENTINA_ID);
        DebtItemDTO debt = Iterables.getOnlyElement(items);

        assertThat(items).isNotEmpty();
        assertThat(debt.getType()).isNullOrEmpty();
        assertThat(debt.getServiceCode()).isNullOrEmpty();
        assertThat(debt.getDocumentType()).isNullOrEmpty();
        assertThat(debt.getCurrencyCode()).isNullOrEmpty();
        assertThat(debt.getOriginCompanyCuit()).isNullOrEmpty();
        assertThat(debt.getTextOne()).isNullOrEmpty();
        assertThat(debt.getTextTwo()).isNullOrEmpty();
    }
}
