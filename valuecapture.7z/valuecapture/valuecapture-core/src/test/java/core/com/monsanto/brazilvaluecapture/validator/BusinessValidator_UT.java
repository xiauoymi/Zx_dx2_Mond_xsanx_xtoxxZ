package com.monsanto.brazilvaluecapture.validator;

import com.monsanto.brazilvaluecapture.core.foundation.validation.IsValidBusiness;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;


public class BusinessValidator_UT {

    @Before
    public void setUp(){
    }

    @Test
    public void operationalYearShouldBeValidYearNumberAfter2000() {
        String operationalYear = "";
        assertFalse(IsValidBusiness.operationalYear(operationalYear));

        operationalYear = "1976";
        assertFalse(IsValidBusiness.operationalYear(operationalYear));

        operationalYear = "2015";
        assertTrue(IsValidBusiness.operationalYear(operationalYear));
    }

    @Test
    public void documentTypeShouldBe_IN_CNPJ_CNPF() {
        String documentType = "";
        assertFalse(IsValidBusiness.documentType(documentType));

        documentType = "CNPJ";
        assertTrue(IsValidBusiness.documentType(documentType));

        documentType = "CPF";
        assertTrue(IsValidBusiness.documentType(documentType));

        documentType = "CUIT";
        assertTrue(IsValidBusiness.documentType(documentType));

        documentType = "Cedula";
        assertTrue(IsValidBusiness.documentType(documentType));

        documentType = "RUC_SOCIEDAD";
        assertTrue(IsValidBusiness.documentType(documentType));

        documentType = "RUC_PJ";
        assertTrue(IsValidBusiness.documentType(documentType));
    }

    @Test
    public void CNPJ_documentNumberShouldMatchDocumenttypeMask() {
        String documentType = "CNPJ";
        String documentNumber = "";
        assertFalse(IsValidBusiness.document(documentType, documentNumber));

        documentType = "CNPJ";
        documentNumber = "12.345.678/9012-34";
        assertFalse(IsValidBusiness.document(documentType, documentNumber));

        documentType = "CNPJ";
        documentNumber = "76.177.187/0001-65";
        assertTrue(IsValidBusiness.document(documentType, documentNumber));
    }

    @Test
    public void CPF_documentNumberShouldMatchDocumenttypeMask() {
        String documentType = "CPF";
        String documentNumber = "";
        assertFalse(IsValidBusiness.document(documentType, documentNumber));

        documentType = "CPF";
        documentNumber = null;
        assertFalse(IsValidBusiness.document(documentType, documentNumber));

        documentType = "CPF";
        documentNumber = "364.704.220-04";
        assertTrue(IsValidBusiness.document(documentType, documentNumber));
    }

    @Test
    public void Cedula_documentNumberShouldMatchDocumenttypeMask() {
        String documentType = "Cedula";
        String documentNumber = "";
        assertFalse(IsValidBusiness.document(documentType, documentNumber));

        documentType = "Cedula";
        documentNumber = null;
        assertFalse(IsValidBusiness.document(documentType, documentNumber));

        documentType = "Cedula";
        //documentNumber = "15563658"; // EL CEDULA VALIDATOR ADMITE ENTRE 6 y 7 CARACTERES
        documentNumber = "1556365";
        assertTrue(IsValidBusiness.document(documentType, documentNumber));
    }

    @Test
    public void RUC_Sociedad_documentNumberShouldMatchDocumenttypeMask() {
        String documentType = "RUC_SOCIEDAD";
        String documentNumber = "";
        assertFalse(IsValidBusiness.document(documentType, documentNumber));

        documentType = "RUC_SOCIEDAD";
        documentNumber = null;
        assertFalse(IsValidBusiness.document(documentType, documentNumber));

        documentType = "RUC_SOCIEDAD";
        documentNumber = "80003302-7";
        assertTrue(IsValidBusiness.document(documentType, documentNumber));

    }

    @Test
    public void RUC_PJ_documentNumberShouldMatchDocumenttypeMask() {
        String documentType = "RUC_PJ";
        String documentNumber = "";
        assertFalse(IsValidBusiness.document(documentType, documentNumber));

        documentType = "RUC_PJ";
        documentNumber = null;
        assertFalse(IsValidBusiness.document(documentType, documentNumber));

        //DocumentUtils.removeMask will remove the A at the end...
        documentType = "RUC_PJ";
        documentNumber = "1889721A-4";
        assertTrue(IsValidBusiness.document(documentType, documentNumber));
    }
}
