package com.monsanto.brazilvaluecapture.core.grower.model.dao.impl;

import com.monsanto.brazilvaluecapture.core.grower.model.bean.Grower;
import com.monsanto.brazilvaluecapture.core.grower.model.bean.Notification;
import com.monsanto.brazilvaluecapture.core.grower.model.bean.NotificationStatusEnum;
import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.hibernate.classic.Session;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Date;

import static org.hamcrest.core.IsAnything.any;
import static org.mockito.Matchers.anyObject;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.*;

/**
 * Created with IntelliJ IDEA.
 * User: ENGUAN
 * Date: 4/14/14
 * Time: 3:32 PM
 * To change this template use File | Settings | File Templates.
 */
public class NotificationDAOImpl_UT {

    @Mock
    private SessionFactory sessionFactory;
    @Mock
    private Session session;
    @Mock
    private Query query;
    @Mock
    private Criteria criteria;

    private NotificationDAOimpl notificationDAOimpl;

    @Before
    public void setUp() throws Exception {
        MockitoAnnotations.initMocks(this);

        this.session = mock(Session.class);
        when(sessionFactory.getCurrentSession()).thenReturn(this.session);
        notificationDAOimpl = new NotificationDAOimpl(sessionFactory);
        this.query = mock(Query.class);
        when(this.session.createQuery(anyString())).thenReturn(this.query);
    }

    @Test
    public void save_notification_test(){
        Notification notification1 = mock(Notification.class);

        //@When
        notificationDAOimpl.save(notification1);
        //@Should
        verify(session).saveOrUpdate(notification1);
    }


    @Test

    public void getNotifications_test(){
        Grower grower = mock(Grower.class);
        Date dateFrom = new Date();
        Date dateTo = new Date();
        notificationDAOimpl.getNotifications(grower, dateFrom, dateTo, NotificationStatusEnum.SENT,null);
        verify(this.query, times(1)).setParameter("notificationStatusEnum", NotificationStatusEnum.SENT);
        verify(this.query, times(1)).setParameter("grower", grower);
        verify(this.query, times(1)).setParameter("dateFromFilter",dateFrom);
        verify(this.query, times(1)).setParameter("dateToFilter", dateTo);
        verify(this.query, times(1)).list();
    }



}
