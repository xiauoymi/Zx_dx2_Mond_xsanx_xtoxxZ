package com.monsanto.brazilvaluecapture.core.grower;

import com.monsanto.brazilvaluecapture.core.base.model.bean.Address;
import com.monsanto.brazilvaluecapture.core.base.model.bean.BillingAddress;
import com.monsanto.brazilvaluecapture.core.base.model.bean.BusinessAddress;
import com.monsanto.brazilvaluecapture.core.base.model.bean.City;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Country;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Document;
import com.monsanto.brazilvaluecapture.core.base.model.bean.DocumentType;
import com.monsanto.brazilvaluecapture.core.base.model.bean.State;
import com.monsanto.brazilvaluecapture.core.foundation.RandomTestData;
import com.monsanto.brazilvaluecapture.core.grower.model.bean.Grower;

public class PlayerTestData {

	/**
	 * @return
	 */
	public static Grower createRandomGrower() {
		return createGrower(null, null, null);
	}
	
	/**
	 * @return Grower
	 */
	public static Grower createGrower(Document document, BillingAddress billingAddress, BusinessAddress businessAddress){
		String name = "Chico Bento";
		String alias = "chico";
		String email = "chico@bento.com";
		Grower grower = new Grower(document, name, alias, email, billingAddress, businessAddress);
		grower.setStatus(Boolean.TRUE);
		return grower;
	}

	/**
	 * Create a new billing address
	 * @return BillingAddress
	 */
	public static BillingAddress createBillingAddress(State state, City city, Country country){
		
		BillingAddress a = new BillingAddress();
		
		a.setCity(city);
		a.setCountry(country);
		a.setStreet(RandomTestData.createRandomString(15));
		a.setState(state);
		a.setComplement(RandomTestData.createRandomString(10));
		a.setFax(RandomTestData.createRandomString(10));
		a.setTelephone(RandomTestData.createRandomString(10));
		a.setNeighborhood(RandomTestData.createRandomString(5));
		a.setNumber(RandomTestData.createRandomString(3));
		a.setZipCode(RandomTestData.createRandomString(8));
		
		return a;
	}

	/**
	 * Create a new business address
	 * @return BusinessAddress
	 */
	public static BusinessAddress createBusinessAddress(State state, City city, Country country){
		
		BusinessAddress a = new BusinessAddress();
		
		a.setCity(city);
		a.setCountry(country);
		a.setStreet(RandomTestData.createRandomString(15));
		a.setState(state);
		a.setComplement(RandomTestData.createRandomString(10));
		a.setFax(RandomTestData.createRandomString(10));
		a.setTelephone(RandomTestData.createRandomString(10));
		a.setNeighborhood(RandomTestData.createRandomString(5));
		a.setNumber(RandomTestData.createRandomString(3));
		a.setZipCode(RandomTestData.createRandomString(8));
		
		return a;
	}

	/**
	 * TODO: Extrair para DocumentTestData
	 * @param documentType
	 * @param value
	 * @return
	 */
	public static Document createDocument(DocumentType documentType, String value) {
		return new Document(documentType, value);
	}

	/**
	 * TODO: Extrair para DocumentTestData
	 * @param country 
	 * @return
	 */
	public static DocumentType createDocumentType(Country country) {
		String mask = "";
		String description = "";
		DocumentType documentType = new DocumentType(description, country, mask);
		//TODO: Mover para o construtor de DocumentType
		country.addDocumentType(documentType);
		return documentType;
	}
	
	/**
	 * Create a new address
	 * 
	 * @return Address
	 */
	public static Address createAddress(State state, City city, Country country) {

		Address a = new Address();

		a.setCity(city);
		a.setCountry(country);
		a.setStreet(RandomTestData.createRandomString(15));
		a.setState(state);
		a.setZipCode(RandomTestData.createRandomString(8));

		return a;
	}
	
	
}
