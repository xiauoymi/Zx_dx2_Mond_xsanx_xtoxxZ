package com.monsanto.brazilvaluecapture.core.grower.model.bean;

import junit.framework.Assert;
import org.junit.Before;
import org.junit.Test;

import java.util.Date;

public class LicensesByGowerDTO_UT {
    @Before
    public void setUp() throws Exception {

    }

    @Test
    public void testConstructorAndGetters() throws Exception {


        Long agreementId = 1L;
        String licenseNumber = "licenseNumber";
        Date agreementCreationDate = new Date();
        Agreement.AgreementStatusEnum agreementStatus = Agreement.AgreementStatusEnum.APPROVED;
        int agreementAttachmentsSize = 3;
        String customerDocument = "customerDocument";
        String customerName = "customerName";
        Long growerId = 4L;
        String growerDocument = "growerDocument";
        String growerName = "growerName";
        String companyDescription = "companyDescription";
        String cropDescription = "cropDescription";
        String technologyDescription = "technologyDescription";

        String approvalUser = "approvalUser";
        Date approvalDate = new Date();
        String approvalComment = "approvalComment";

        String creationUser = "creationUser";
        String sapCustomerNumber = "sapCustomerNumber" ;
        String managerName = "managerName";

        LicensesByGowerDTO dto =
                new LicensesByGowerDTO( agreementId,
                                        licenseNumber,
                                        agreementCreationDate,
                                        agreementStatus,
                                        agreementAttachmentsSize,
                                        customerDocument,
                                        customerName,

                                        approvalUser,
                                        approvalDate,
                                        approvalComment,

                                        growerId,
                                        growerDocument,
                                        growerName,
                                        companyDescription,
                                        cropDescription,
                                        technologyDescription,
                                        creationUser,
                                        sapCustomerNumber,
                                        managerName);

        Assert.assertEquals("agreementId parameter is not correct", agreementId, dto.getAgreementId());
        Assert.assertEquals("approvalUser parameter is not correct", approvalUser, dto.getApprovalUser());
        Assert.assertEquals("approvalDate parameter is not correct", approvalDate, dto.getApprovalDate());
        Assert.assertEquals("approvalComment parameter is not correct", approvalComment, dto.getApprovalComment());
        Assert.assertEquals("licenseNumber parameter is not correct", licenseNumber, dto.getLicenseNumber());
        Assert.assertEquals("agreementCreationDate parameter is not correct", agreementCreationDate, dto.getAgreementCreationDate());
        Assert.assertEquals("agreementStatus parameter is not correct", agreementStatus, dto.getAgreementStatus());
        Assert.assertEquals("customerDocument parameter is not correct", customerDocument, dto.getCustomerDocument());
        Assert.assertEquals("customerName parameter is not correct", customerName, dto.getCustomerName());
        Assert.assertEquals("growerDocument parameter is not correct", growerDocument, dto.getGrowerDocument());
        Assert.assertEquals("growerName parameter is not correct", growerName, dto.getGrowerName());
        Assert.assertEquals("companyDescription parameter is not correct", companyDescription, dto.getCompanyDescription());
        Assert.assertEquals("cropDescription parameter is not correct", cropDescription, dto.getCropDescription());
        Assert.assertEquals("technologyDescription parameter is not correct", technologyDescription, dto.getTechnologyDescription());

        Assert.assertEquals("creationUser parameter is not correct", creationUser, dto.getAgreementCreationUser());
        Assert.assertEquals("sapCustomerNumber parameter is not correct", sapCustomerNumber, dto.getSapCustomerNumber());
        Assert.assertEquals("managerName parameter is not correct", managerName, dto.getManagerName());
    }
}
