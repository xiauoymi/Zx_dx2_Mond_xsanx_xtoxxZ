package com.monsanto.brazilvaluecapture.seedsale.sale.model.dao;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

/**
 * Created by AJMILD1 on 24/09/14.
 */
public class MultiplierToGrowerSaleFilter_UT {
    private MultiplierToGrowerSaleFilter multiplierToGrowerSaleFilter = null;

    @Before
    public void setup() {
        multiplierToGrowerSaleFilter = MultiplierToGrowerSaleFilter.getInstance();
    }

    @Test
    public void testExcludePostedSales() throws Exception {
        multiplierToGrowerSaleFilter.excludePostedSales();

        Assert.assertEquals("Should have one criterias", 1, multiplierToGrowerSaleFilter.countCriterias());

    }
}
