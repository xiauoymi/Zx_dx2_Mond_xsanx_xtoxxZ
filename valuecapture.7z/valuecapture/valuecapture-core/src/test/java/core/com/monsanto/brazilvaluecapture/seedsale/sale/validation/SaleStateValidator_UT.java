package com.monsanto.brazilvaluecapture.seedsale.sale.validation;

import com.monsanto.brazilvaluecapture.core.base.model.bean.State;
import com.monsanto.brazilvaluecapture.core.base.service.RegionService;
import com.monsanto.brazilvaluecapture.core.foundation.service.EntityNotFoundException;
import com.monsanto.brazilvaluecapture.core.foundation.util.ErrorCode;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.Sale;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import static org.fest.assertions.Assertions.assertThat;
import static org.junit.Assert.fail;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.when;

/**
 * Created with IntelliJ IDEA.
 * User: IFERN1
 * Date: 11/8/13
 * Time: 12:29 PM
 * To change this template use File | Settings | File Templates.
 */
@RunWith(MockitoJUnitRunner.class)
public class SaleStateValidator_UT {
    @Mock
    private RegionService regionService;

    @InjectMocks
    SaleStateValidationRule saleStateValidator;

    @Test
    public void given_stateless_sale_validation_fails() {
        //@Given
        Sale sale = new Sale();

        //@When
        try {
            saleStateValidator.validate(sale);
            fail("Should throw SaleValidationException");
        } catch (Exception e) {
            //@Should
            assertThat(e).isInstanceOf(SaleValidationException.class).hasNoCause();
            SaleValidationException sve = (SaleValidationException) e;
        }
    }

    @Test
    public void given_miss_configured_state_sale_validation_fails() {
        //@Given
        Sale sale = new Sale();
        State state = new State();
        sale.setState(state);

        //@When
        try {
            saleStateValidator.validate(sale);
            fail("Should throw SaleValidationException");
        } catch (Exception e) {
            //@Should
            assertThat(e).isInstanceOf(SaleValidationException.class).hasNoCause();
        }
    }

    @Test
    public void given_unexisting_state_sale_validation_fails() throws EntityNotFoundException {
        //@Given
        Sale sale = new Sale();
        State state = new State(null, "description", "code");
        sale.setState(state);
        when(regionService.selectByCode(anyString())).thenThrow(EntityNotFoundException.class);

        //@When
        try {
            saleStateValidator.validate(sale);
            fail("Should throw SaleValidationException");
        } catch (Exception e) {
            //@Should
            assertThat(e).isInstanceOf(SaleValidationException.class).hasNoCause();
        }
    }
}
