package com.monsanto.brazilvaluecapture.seedsale.billing.model.bean;

import com.monsanto.brazilvaluecapture.core.base.model.bean.Company;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Country;
import com.monsanto.brazilvaluecapture.seedsale.harvest.model.bean.Harvest;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import static org.fest.assertions.Assertions.assertThat;
import static org.fest.reflect.core.Reflection.field;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class BillingDTO_UT {

    @InjectMocks
    private BillingDTO billingDTO;
    @Mock
    private Billing billing;
    @Mock
    private Royalty royalty;

    @Before
    public void setUp() {
        field("billing").ofType(Billing.class).in(this.billingDTO).set(billing);
    }

    @Test
    public void isBillingForManualPayment_returnsTrue_whenIsNotPaidAndNotErp() throws Exception {
        setCountryCodeToRoyalty("BR");
        when(billing.isNotPaid()).thenReturn(true);
        when(billing.isErp()).thenReturn(false);

        boolean result = billingDTO.isBillingForManualPayment();

        assertThat(result).isTrue();
    }

    @Test
    public void isBillingForManualPayment_returnsTrue_whenIsLasAndNotPaidAndErp() throws Exception {
        setCountryCodeToRoyalty("AR");
        when(billing.isNotPaid()).thenReturn(true);
        when(billing.isErp()).thenReturn(true);

        boolean result = billingDTO.isBillingForManualPayment();

        assertThat(result).isTrue();
    }

    @Test
    public void isBillingForManualPayment_returnsFalse_whenIsBrasilAndNotPaidAndErp() throws Exception {
        setCountryCodeToRoyalty("BR");
        when(billing.isNotPaid()).thenReturn(true);
        when(billing.isErp()).thenReturn(true);

        boolean result = billingDTO.isBillingForManualPayment();

        assertThat(result).isFalse();
    }

    @Test
    public void isBillingForManualPayment_returnsTrue_whenIsBilled() throws Exception {
        setCountryCodeToRoyalty("AR");
        when(billing.isBilled()).thenReturn(true);

        boolean result = billingDTO.isBillingForManualPayment();

        assertThat(result).isTrue();
    }

    @Test
    public void isBillingForManualPayment_returnsFalse_whenIsNotBilledAndNotPaidAndNotLas() throws Exception {
        setCountryCodeToRoyalty("AR");
        boolean result = billingDTO.isBillingForManualPayment();

        assertThat(result).isFalse();
    }

    private void setCountryCodeToRoyalty(String countryCode) {
        Harvest harvest = new Harvest();
        Company company = new Company();
        Country country = new Country();
        country.setCode(countryCode);
        harvest.setCompany(company);
        company.setCountry(country);
        when(royalty.getHarvest()).thenReturn(harvest);
    }

}
