package com.monsanto.brazilvaluecapture.core.grower.service.impl;

import com.monsanto.brazilvaluecapture.core.base.service.BaseService;
import com.monsanto.brazilvaluecapture.core.base.service.impl.BaseServiceImpl;
import com.monsanto.brazilvaluecapture.core.foundation.util.csv.CSVReadableInvalidException;
import com.monsanto.brazilvaluecapture.core.foundation.util.parser.BeanParserResult;
import com.monsanto.brazilvaluecapture.core.grower.model.bean.Grower;
import com.monsanto.brazilvaluecapture.core.grower.service.GrowerConstraintViolationException;
import org.junit.Assert;
import org.junit.Test;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.util.List;
import java.util.Locale;

/**
 * Created by IntelliJ IDEA.
 * User: CGLLLO
 * Date: 2/13/13
 * Time: 3:24 PM
 */
public class GrowerFileParserLAS_AT {

    private static final String LOGIN = "steve";

    private void testImport(String documentType, String documentNumber, String name, String alias, String street, String number, String neighborhood, String country, String state, String city, String zipCode, String telephone) throws UnsupportedEncodingException, CSVReadableInvalidException {
        StringBuilder sb = new StringBuilder("header\n");
        sb.append("PRODUCTOR");
        sb.append(";");
        sb.append(documentType);
        sb.append(";");
        sb.append(documentNumber);
        sb.append(";");
        sb.append(name);
        sb.append(";");
        sb.append(alias);
        sb.append(";");
        sb.append(";");
        sb.append(street);
        sb.append(";");
        sb.append(number);
        sb.append(";");
        sb.append(";");
        sb.append(neighborhood);
        sb.append(";");
        sb.append(country);
        sb.append(";");
        sb.append(state);
        sb.append(";");
        sb.append(city);
        sb.append(";");
        sb.append(zipCode);
        sb.append(";");
        sb.append(telephone);
        sb.append(";");
        sb.append(";");
        sb.append(";");
        sb.append(";");
        sb.append(";");
        sb.append(";");
        sb.append(";");
        sb.append(";");
        sb.append(";");
        sb.append(";");
        sb.append(";");
        sb.append(";");
        sb.append("1");

        InputStream inputStream = new ByteArrayInputStream(sb.toString().getBytes("UTF-8"));

        Locale locale = new Locale("es", "AR");

        BaseService baseService = new BaseServiceImpl() {
            public void validateGrower(Grower grower) throws GrowerConstraintViolationException {

            }
        };

        GrowerFileParserLAS growerFileParserLAS = new GrowerFileParserLAS(inputStream, locale, baseService, LOGIN);
        growerFileParserLAS.readFile();
        BeanParserResult<Grower> growerParserResult = growerFileParserLAS.getGrowerParserResult();
        List<Grower> growers = growerParserResult.getCorrectBeans();
        Grower grower = growers.get(0);

        Assert.assertEquals("DocumentType Assertion Failed: ", documentType, grower.getDocument().getDocumentType().getDescription());
        Assert.assertEquals("DocumentNumber Assertion Failed: ", documentNumber, grower.getDocument().getValue());
        Assert.assertEquals("name Assertion Failed: ", name, grower.getName());
        Assert.assertEquals("alias Assertion Failed: ", alias.toUpperCase(), grower.getAlias());
        Assert.assertEquals("street Assertion Failed: ", street.toUpperCase(), grower.getBillingAddress().getStreet());
        Assert.assertEquals("number Assertion Failed: ", number, grower.getBillingAddress().getNumber());
        Assert.assertEquals("neighborhood Assertion Failed: ", neighborhood, grower.getBillingAddress().getNeighborhood());
        Assert.assertEquals("country Assertion Failed: ", country, grower.getBillingAddress().getCountry().getDescription());
        Assert.assertEquals("state Assertion Failed: ", state, grower.getBillingAddress().getState().getCode());
        Assert.assertEquals("city Assertion Failed: ", city, grower.getBillingAddress().getCity().getDescription());
        Assert.assertEquals("zipCode Assertion Failed: ", zipCode, grower.getBillingAddress().getZipCode());
        Assert.assertEquals("telephone Assertion Failed: ", telephone, grower.getBillingAddress().getTelephone());
    }

    @Test
    public void when_i_have_a_file_with_no_errors_should_import_the_grower() throws UnsupportedEncodingException, CSVReadableInvalidException {
        String documentType = "CUIT";
        String documentNumber = "30657906294";
        String name = "ABANJA SA";
        String alias = "Javier Rocchiccioli";
        String street = "sin calle";
        String number = "9999";
        String neighborhood ="GENERICO";
        String country = "ARGENTINA";
        String state = "BSAS";
        String city = "Quilmes";
        String zipCode = "11111";
        String telephone = "3562477745";

        testImport(documentType, documentNumber, name, alias, street, number, neighborhood, country, state, city, zipCode, telephone);
    }

}