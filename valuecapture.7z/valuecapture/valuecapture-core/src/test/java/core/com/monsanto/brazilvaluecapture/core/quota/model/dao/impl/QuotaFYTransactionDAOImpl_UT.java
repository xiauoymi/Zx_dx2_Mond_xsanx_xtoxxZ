package com.monsanto.brazilvaluecapture.core.quota.model.dao.impl;

import com.google.common.collect.Lists;
import com.monsanto.brazilvaluecapture.core.quota.model.bean.DeliveryQuotaFY;
import com.monsanto.brazilvaluecapture.core.quota.model.bean.QuotaFY;
import com.monsanto.brazilvaluecapture.core.quota.model.bean.QuotaFYTransaction;
import com.monsanto.brazilvaluecapture.core.quota.model.bean.QuotaFYTransactionType;
import org.hibernate.Criteria;
import org.hibernate.SessionFactory;
import org.hibernate.classic.Session;
import org.hibernate.criterion.Criterion;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentMatcher;
import org.mockito.Matchers;

import static org.mockito.Matchers.argThat;
import static org.mockito.Mockito.*;

/**
 * User: PPERA
 * Date: 6/20/13
 * Time: 11:43 AM
 */
public class QuotaFYTransactionDAOImpl_UT {
    private QuotaFYTransactionDAOImpl quotaFYTransactionDAOImpl;
    private Session session;
    private Criteria criteria;

    @Before
    public void setUp() {
        SessionFactory sessionFactory = mock(SessionFactory.class);
        this.session = mock(Session.class);
        this.criteria = mock(Criteria.class);
        when(sessionFactory.getCurrentSession()).thenReturn(this.session);
        when(this.session.createCriteria(Matchers.<Class>any())).thenReturn(this.criteria);
        when(this.criteria.add(Matchers.<Criterion>any())).thenReturn(this.criteria);
        this.quotaFYTransactionDAOImpl = new QuotaFYTransactionDAOImpl(sessionFactory);
    }

    @Test
    public void testSelectByDeliveryQuotaFYCreatesACriteriaForQuotaFYTransaction_WhenSelectingTransactionsForADeliveryQuota() {
        // @Given a delivery quota
        DeliveryQuotaFY deliveryQuotaFY = new DeliveryQuotaFY();

        // @When selecting transactions for the delivery quota
        this.quotaFYTransactionDAOImpl.selectByDeliveryQuotaFY(deliveryQuotaFY);

        // @Then a criteria is created for QuotaFYTransaction
        verify(this.session).createCriteria(QuotaFYTransaction.class);
    }

    @Test
    public void testSelectByDeliveryQuotaFYAddsInRestrictionForDeliveryQuotaIds1_WhenSelectingTransactionsForADeliveryQuotaWithOneQuotaOfId1() {
        // @Given a delivery quota with quota with id 1
        DeliveryQuotaFY deliveryQuotaFY = new DeliveryQuotaFY();
        QuotaFY quotaFY = new QuotaFY();
        quotaFY.setId(1l);
        deliveryQuotaFY.addQuota(quotaFY);

        // @When selecting transactions for the delivery quota
        this.quotaFYTransactionDAOImpl.selectByDeliveryQuotaFY(deliveryQuotaFY);

        // @Then a restriction for the quota ids is created
        verify(this.criteria).add(argThat(new ArgumentMatcher<Criterion>() {
            @Override
            public boolean matches(Object o) {
                return "quota.id in (1)".equals(o.toString());
            }
        }));
    }

    @Test
    public void testSelectByDeliveryQuotaFYAddsInRestrictionForDeliveryQuotaIds2And3_WhenSelectingTransactionsForADeliveryQuotaWithTwoQuotasOfId2And3() {
        // @Given a delivery quota with quotas with ids 2 and 3
        DeliveryQuotaFY deliveryQuotaFY = new DeliveryQuotaFY();
        QuotaFY quotaFY1 = new QuotaFY();
        quotaFY1.setId(2l);
        deliveryQuotaFY.addQuota(quotaFY1);
        QuotaFY quotaFY2 = new QuotaFY();
        quotaFY2.setId(3l);
        deliveryQuotaFY.addQuota(quotaFY2);

        // @When selecting transactions for the delivery quota
        this.quotaFYTransactionDAOImpl.selectByDeliveryQuotaFY(deliveryQuotaFY);

        // @Then a restriction for the quota ids is created
        verify(this.criteria).add(argThat(new ArgumentMatcher<Criterion>() {
            @Override
            public boolean matches(Object o) {
                return "quota.id in (2, 3)".equals(o.toString());
            }
        }));
    }

    @Test
    public void testSelectByDeliveryQuotaFYAddsInRestrictionForTransactionTypes_WhenSelectingTransactionsForADeliveryQuota() {
        // @Given a delivery quota with quota with id 1
        DeliveryQuotaFY deliveryQuotaFY = new DeliveryQuotaFY();
        QuotaFY quotaFY = new QuotaFY();
        quotaFY.setId(1l);
        deliveryQuotaFY.addQuota(quotaFY);

        // @When selecting transactions for the delivery quota
        this.quotaFYTransactionDAOImpl.selectByDeliveryQuotaFY(deliveryQuotaFY);

        // @Then a criteria is created for QuotaFYTransaction
        verify(this.criteria).add(argThat(new ArgumentMatcher<Criterion>() {
            @Override
            public boolean matches(Object o) {
                return ("transactionType in (" + QuotaFYTransactionType.PAID.getValue() + ", " + QuotaFYTransactionType.TRANSFER_DEBIT.getValue() + ", " + QuotaFYTransactionType.TRANSFER_CREDIT.getValue() + ")").equals(o.toString());
            }
        }));
    }

    //======================================================

        @Test
    public void testSelectByDeliveryQuotaFYsCreatesACriteriaForQuotaFYTransaction_WhenSelectingTransactionsForADeliveryQuota() {
        // @Given a delivery quota
        DeliveryQuotaFY deliveryQuotaFY = new DeliveryQuotaFY();

        // @When selecting transactions for the delivery quota
        this.quotaFYTransactionDAOImpl.selectByDeliveryQuotaFYs(Lists.newArrayList(deliveryQuotaFY));

        // @Then a criteria is created for QuotaFYTransaction
        verify(this.session).createCriteria(QuotaFYTransaction.class);
    }

    @Test
    public void testSelectByDeliveryQuotaFYsAddsInRestrictionForDeliveryQuotaIds1_WhenSelectingTransactionsForADeliveryQuotaWithOneQuotaOfId1() {
        // @Given a delivery quota with quota with id 1
        DeliveryQuotaFY deliveryQuotaFY = new DeliveryQuotaFY();
        QuotaFY quotaFY = new QuotaFY();
        quotaFY.setId(1l);
        deliveryQuotaFY.addQuota(quotaFY);

        // @When selecting transactions for the delivery quota
        this.quotaFYTransactionDAOImpl.selectByDeliveryQuotaFYs(Lists.newArrayList(deliveryQuotaFY));

        // @Then a restriction for the quota ids is created
        verify(this.criteria).add(argThat(new ArgumentMatcher<Criterion>() {
            @Override
            public boolean matches(Object o) {
                return "quota.id in (1)".equals(o.toString());
            }
        }));
    }

    @Test
    public void testSelectByDeliveryQuotaFYsAddsInRestrictionForDeliveryQuotaIds2And3_WhenSelectingTransactionsForADeliveryQuotaWithTwoQuotasOfId2And3() {
        // @Given a delivery quota with quotas with ids 2 and 3
        DeliveryQuotaFY deliveryQuotaFY = new DeliveryQuotaFY();
        QuotaFY quotaFY1 = new QuotaFY();
        quotaFY1.setId(2l);
        deliveryQuotaFY.addQuota(quotaFY1);
        QuotaFY quotaFY2 = new QuotaFY();
        quotaFY2.setId(3l);
        deliveryQuotaFY.addQuota(quotaFY2);

        // @When selecting transactions for the delivery quota
        this.quotaFYTransactionDAOImpl.selectByDeliveryQuotaFYs(Lists.newArrayList(deliveryQuotaFY));

        // @Then a restriction for the quota ids is created
        verify(this.criteria).add(argThat(new ArgumentMatcher<Criterion>() {
            @Override
            public boolean matches(Object o) {
                return "quota.id in (2, 3)".equals(o.toString());
            }
        }));
    }

    @Test
    public void testSelectByDeliveryQuotaFYsAddsInRestrictionForDeliveryQuotaIds1And2And3_WhenSelectingTransactionsForADeliveryQuotasWithQuotasOfIds1And2And3() {
        // @Given a delivery quota with quota 1 and another with ids 2 and 3
                DeliveryQuotaFY deliveryQuotaFY1 = new DeliveryQuotaFY();
        QuotaFY quotaFY = new QuotaFY();
        quotaFY.setId(1l);
        deliveryQuotaFY1.addQuota(quotaFY);

        DeliveryQuotaFY deliveryQuotaFY2 = new DeliveryQuotaFY();
        QuotaFY quotaFY1 = new QuotaFY();
        quotaFY1.setId(2l);
        deliveryQuotaFY2.addQuota(quotaFY1);
        QuotaFY quotaFY2 = new QuotaFY();
        quotaFY2.setId(3l);
        deliveryQuotaFY2.addQuota(quotaFY2);

        // @When selecting transactions for the delivery quota
        this.quotaFYTransactionDAOImpl.selectByDeliveryQuotaFYs(Lists.newArrayList(deliveryQuotaFY1, deliveryQuotaFY2));

        // @Then a restriction for the quota ids is created
        verify(this.criteria).add(argThat(new ArgumentMatcher<Criterion>() {
            @Override
            public boolean matches(Object o) {
                return "quota.id in (1, 2, 3)".equals(o.toString());
            }
        }));
    }

    @Test
    public void testSelectByDeliveryQuotaFYsAddsInRestrictionForTransactionTypes_WhenSelectingTransactionsForADeliveryQuota() {
        // @Given a delivery quota with quota with id 1
        DeliveryQuotaFY deliveryQuotaFY = new DeliveryQuotaFY();
        QuotaFY quotaFY = new QuotaFY();
        quotaFY.setId(1l);
        deliveryQuotaFY.addQuota(quotaFY);

        // @When selecting transactions for the delivery quota
        this.quotaFYTransactionDAOImpl.selectByDeliveryQuotaFYs(Lists.newArrayList(deliveryQuotaFY));

        // @Then a criteria is created for QuotaFYTransaction
        verify(this.criteria).add(argThat(new ArgumentMatcher<Criterion>() {
            @Override
            public boolean matches(Object o) {
                return ("transactionType in (" + QuotaFYTransactionType.PAID.getValue() + ", " + QuotaFYTransactionType.TRANSFER_DEBIT.getValue() + ", " + QuotaFYTransactionType.TRANSFER_CREDIT.getValue() + ")").equals(o.toString());
            }
        }));
    }


     //======================================================

    @Test
    public void testSelectByQuotaFYsCreatesACriteriaForQuotaFYTransaction_WhenSelectingTransactionsForAQuota() {
        // @Given a quota
        QuotaFY quotaFY = new QuotaFY();

        // @When selecting transactions for the quota
        this.quotaFYTransactionDAOImpl.selectByQuotaFYs(Lists.newArrayList(quotaFY));

        // @Then a criteria is created for QuotaFYTransaction
        verify(this.session).createCriteria(QuotaFYTransaction.class);
    }

    @Test
    public void testSelectByQuotaFYsAddsInRestrictionForQuotaIds1_WhenSelectingTransactionsForAQuotaWithQuotaOfId1AndQuotaOfId2() {
        // @Given a quota with quota with id 1
        QuotaFY quotaFY = new QuotaFY();
        quotaFY.setId(1l);

        // @Given a quota with quota with id 2
        QuotaFY quotaFY2 = new QuotaFY();
        quotaFY2.setId(2l);

        // @When selecting transactions for the delivery quota
        this.quotaFYTransactionDAOImpl.selectByQuotaFYs(Lists.newArrayList(quotaFY,quotaFY2));

        // @Then a restriction for the quota ids is created
        verify(this.criteria).add(argThat(new ArgumentMatcher<Criterion>() {
            @Override
            public boolean matches(Object o) {
                return "quota.id in (1, 2)".equals(o.toString());
            }
        }));
    }
}
