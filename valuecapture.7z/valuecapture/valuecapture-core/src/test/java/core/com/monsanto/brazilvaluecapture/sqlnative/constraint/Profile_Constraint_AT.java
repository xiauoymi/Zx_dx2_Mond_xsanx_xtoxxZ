package com.monsanto.brazilvaluecapture.sqlnative.constraint;

import com.monsanto.brazilvaluecapture.core.base.SystemTestFixture;
import com.monsanto.brazilvaluecapture.core.foundation.model.bean.StatusEnum;
import com.monsanto.brazilvaluecapture.core.foundation.service.EntityAlreadyExistException;
import com.monsanto.brazilvaluecapture.core.foundation.test.AbstractServiceIntegrationTests;
import com.monsanto.brazilvaluecapture.core.user.AccessControlTestFixture;
import com.monsanto.brazilvaluecapture.core.user.model.bean.Profile;
import com.monsanto.brazilvaluecapture.core.user.service.UserService;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

@Ignore
public class Profile_Constraint_AT extends AbstractServiceIntegrationTests {
	
	@Autowired
	private UserService userServices;
	
	private AccessControlTestFixture accessControlIntent;


	@Before
	public void init(){
		systemTestFixture = new SystemTestFixture(this);
		accessControlIntent = new AccessControlTestFixture(this, systemTestFixture);
	}


	@Test(expected=EntityAlreadyExistException.class)
	public void not_must_be_able_to_save_a_profile_with_same_description_and_crop() throws EntityAlreadyExistException {
		Profile profileToBeSaved = new Profile("Master Distribuitor");
		profileToBeSaved.setCrop(systemTestFixture.soy);
		profileToBeSaved.setDetail("Has access to Sale functions with squery and update permission");
		profileToBeSaved.setStatus(StatusEnum.ACTIVE);
		profileToBeSaved.addAction(accessControlIntent.seedSaleEditAction);
		profileToBeSaved.addAction(accessControlIntent.seedSaleSelectAction);
		
		userServices.saveProfile(profileToBeSaved);
		
		Profile anotherProfileToBeSaved = new Profile("Master Distribuitor");
		anotherProfileToBeSaved.setCrop(systemTestFixture.soy);
		anotherProfileToBeSaved
		.setDetail("Has access to Sale functions with squery and update permission");
		anotherProfileToBeSaved.setStatus(StatusEnum.ACTIVE);
		anotherProfileToBeSaved.addAction(accessControlIntent.seedSaleEditAction);
		anotherProfileToBeSaved.addAction(accessControlIntent.seedSaleSelectAction);
		
		userServices.saveProfile(anotherProfileToBeSaved);
		
		Assert.fail();
	}
	
}
