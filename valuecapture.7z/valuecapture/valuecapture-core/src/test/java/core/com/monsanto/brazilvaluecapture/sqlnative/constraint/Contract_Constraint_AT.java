package com.monsanto.brazilvaluecapture.sqlnative.constraint;

import com.monsanto.brazilvaluecapture.core.base.SystemTestFixture;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Address;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Contract;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Customer;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.HeadOffice;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.ParticipantTypeEnum;
import com.monsanto.brazilvaluecapture.core.customer.service.ContractNotFoundException;
import com.monsanto.brazilvaluecapture.core.customer.service.ContractService;
import com.monsanto.brazilvaluecapture.core.foundation.RandomTestData;
import com.monsanto.brazilvaluecapture.core.foundation.test.AbstractServiceIntegrationTests;
import com.monsanto.brazilvaluecapture.core.grower.PlayerTestData;
import junit.framework.Assert;
import org.junit.Assume;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

@Ignore
public class Contract_Constraint_AT extends AbstractServiceIntegrationTests {

	@Autowired
	private ContractService contractService;
	private Customer affiliate;
	private HeadOffice headOffice;
	private HeadOffice headOfficeAffiliate;
	
	private Customer customer;
	
	
	
	
	@Before
	public void contractSetup(){
		systemTestFixture = new SystemTestFixture(this);
		Address a = PlayerTestData.createAddress(systemTestFixture.matoGrossoDoSul, systemTestFixture.vilaNova, systemTestFixture.brazil);
		
		customer = new Customer("C�rgil Nordeste SA", PlayerTestData.createDocument(systemTestFixture.documentCnpj, "222222"), a, RandomTestData.createRandomLong().toString());
		affiliate = new Customer(RandomTestData.createRandomString(5), PlayerTestData.createDocument(systemTestFixture.documentCnpj, "111111"), a, RandomTestData.createRandomLong().toString());
		
		saveAndFlush(customer);
		saveAndFlush(affiliate);
		
		Contract contract = new Contract(RandomTestData.createRandomString(5), customer, ParticipantTypeEnum.DISTRIBUTOR, systemTestFixture.soy, systemTestFixture.monsantoBr);
		saveAndFlush(contract);
		
		headOffice = new HeadOffice(customer, customer, ParticipantTypeEnum.DISTRIBUTOR, systemTestFixture.soy, systemTestFixture.monsantoBr);
		headOfficeAffiliate = new HeadOffice(affiliate, customer, ParticipantTypeEnum.DISTRIBUTOR, systemTestFixture.soy, systemTestFixture.monsantoBr);
		
		saveAndFlush(headOffice);
		saveAndFlush(headOfficeAffiliate);
		 
		
	}

	
	@Test
	public void when_search_contracts_of_by_filter_only_name_must_return() throws ContractNotFoundException{
		Assume.assumeTrue(getAssumptionTest().isEnvironmentWithSQLANSI());
		
		List<Contract> contracts = contractService.getContractsByFilter(systemTestFixture.soy, systemTestFixture.monsantoBr, "", "Cargil", null, ParticipantTypeEnum.DISTRIBUTOR);
		Assert.assertEquals("must return 1",1,contracts.size());
	}
	
	@Test
	public void when_search_contracts_of_by_filter_only_name_upcase_must_return() throws ContractNotFoundException{
		Assume.assumeTrue(getAssumptionTest().isEnvironmentWithSQLANSI());
		
		List<Contract> contracts = contractService.getContractsByFilter(systemTestFixture.soy, systemTestFixture.monsantoBr, "", "CARGIL", null, ParticipantTypeEnum.DISTRIBUTOR);
		Assert.assertEquals("must return 1",1,contracts.size());
	}
	@Test
	public void when_search_contracts_of_by_filter_only_name_lowercase_must_return() throws ContractNotFoundException{
		Assume.assumeTrue(getAssumptionTest().isEnvironmentWithSQLANSI());
		
		List<Contract> contracts = contractService.getContractsByFilter(systemTestFixture.soy, systemTestFixture.monsantoBr, "", "cargil", null, ParticipantTypeEnum.DISTRIBUTOR);
		Assert.assertEquals("must return 1",1,contracts.size());
	}

	
	
}
