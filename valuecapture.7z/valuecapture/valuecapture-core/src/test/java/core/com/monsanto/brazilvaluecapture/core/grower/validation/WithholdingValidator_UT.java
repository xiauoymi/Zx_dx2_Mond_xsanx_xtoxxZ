package com.monsanto.brazilvaluecapture.core.grower.validation;

import com.monsanto.brazilvaluecapture.core.base.service.BaseService;
import com.monsanto.brazilvaluecapture.core.foundation.validation.ValidationException;
import com.monsanto.brazilvaluecapture.core.grower.model.bean.Withholding;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import static junit.framework.Assert.assertNull;
import static org.fest.reflect.core.Reflection.field;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;

public class WithholdingValidator_UT {
	
	private WithholdingValidator withholdingValidator;
	
	@Mock
    private WithholdingExistsGrowerValidationRule withholdingExistsGrowerValidationRule;
    
	@Mock
    private WithholdingDocumentValidationRule withholdingDocumentValidationRule;

    @Mock
    private WithholdingFieldsValidationRule withholdingFieldsValidationRule;
	
	private Withholding withholding;
    

    @Mock
    private BaseService baseService;
    
	@Before
	public void setUp() throws Exception {
        MockitoAnnotations.initMocks(this);
        withholding = new Withholding();
        withholdingValidator = new WithholdingValidator();

        field("withholdingExistsGrowerValidationRule").ofType(WithholdingExistsGrowerValidationRule.class).in(withholdingValidator).set(withholdingExistsGrowerValidationRule);
        field("withholdingDocumentValidationRule").ofType(WithholdingDocumentValidationRule.class).in(withholdingValidator).set(withholdingDocumentValidationRule);
        field("withholdingFieldsValidationRule").ofType(WithholdingFieldsValidationRule.class).in(withholdingValidator).set(withholdingFieldsValidationRule);

        when(withholdingDocumentValidationRule.validate(any(Withholding.class))).thenReturn(withholding);

        withholdingValidator.createRules();
    }

	@Test
	public void testValidate_Succesful() throws WithholdingConstraintViolationException {
		assertNull(withholdingValidator.validate(any(Withholding.class)));
	}
	
	@Test
	public void testValidate_Error() throws ValidationException{
		try {
			doThrow(ValidationException.class).when(withholdingDocumentValidationRule).validate(any(Withholding.class));
			withholdingValidator.validate(any(Withholding.class));
			fail();
		}catch (WithholdingConstraintViolationException e) {
			assertEquals(e.getMessage(),"Invalid Withholding");
		}
	}


}
