package com.monsanto.brazilvaluecapture.seedsale.revenue.service.impl;

import com.google.common.base.Optional;
import com.google.common.collect.Lists;
import com.monsanto.brazilvaluecapture.core.foundation.service.BusinessException;
import com.monsanto.brazilvaluecapture.core.posting.model.bean.ReferenceNameEnum;
import com.monsanto.brazilvaluecapture.core.posting.service.PostingService;
import com.monsanto.brazilvaluecapture.seedsale.billing.model.bean.PaymentStatus;
import com.monsanto.brazilvaluecapture.seedsale.posting.osb.OsbBonusPostingService;
import com.monsanto.brazilvaluecapture.seedsale.revenue.model.PostingStatusEnum;
import com.monsanto.brazilvaluecapture.seedsale.revenue.service.CalendarRule;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.SaleItem;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.dao.MultiplierSaleDAO;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.dao.SaleDAO;
import com.monsanto.brazilvaluecapture.utils.DateRange;
import com.monsanto.brazilvaluecapture.utils.DateUtils;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.math.BigDecimal;
import java.util.Date;

import static junit.framework.Assert.assertEquals;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class PostMultiplierToGrowerSalesRecognizerImpl_UT {

    private static final Date osbDate = DateUtils.getLastDateOfPreviousMonth();
    @Mock
    private MultiplierSaleDAO multiplierSaleDAO;
    @Mock
    private PostingService postingService;
    @Mock
    private SaleDAO saleDAO;
    @Mock
    private CalendarRule calendarRule;
    @InjectMocks
    private PostMultiplierToGrowerSalesRecognizerImpl postMultiplierToGrowerSalesRecognizer;

    @Test
    public void testRecognizeRevenueFromSalesInvokesFindNotLinkedSalesInPreviousMonthForRevenueRecognitionWithPaymentStatusNOT_PAID() throws BusinessException {
        //@Given
        //@When
        postMultiplierToGrowerSalesRecognizer.recognizeRevenueFromSales();
        //@Then
        verify(multiplierSaleDAO).findNotLinkedSalesInPreviousMonthForRevenueRecognition(eq(PaymentStatus.NOT_PAID), any(DateRange.class), any(Optional.class));
    }

    @Test
    public void testRecognizeRevenueFromSalesInvokesFindNotLinkedSalesInPreviousMonthForRevenueRecognitionWithPaymentStatusBILLED() throws BusinessException {
        //@Given
        //@When
        postMultiplierToGrowerSalesRecognizer.recognizeRevenueFromSales();
        //@Then
        verify(multiplierSaleDAO).findNotLinkedSalesInPreviousMonthForRevenueRecognition(eq(PaymentStatus.BILLED), any(DateRange.class), any(Optional.class));
    }

    @Test
    public void testRecognizeRevenueFromSalesInvokesFindNotLinkedSalesInPreviousMonthForRevenueRecognitionWithPaymentStatusFULLY_PAID() throws BusinessException {
        //@Given
        //@When
        postMultiplierToGrowerSalesRecognizer.recognizeRevenueFromSales();
        //@Then
        verify(multiplierSaleDAO).findNotLinkedSalesInPreviousMonthForRevenueRecognition(eq(PaymentStatus.FULLY_PAID), any(DateRange.class), any(Optional.class));
    }

    @Test
    public void testRecognizeRevenueFromSalesNotInvokesUpdateSaleItem_whenFindNotLinkedSalesInPreviousMonthForRevenueRecognitionRetrieves0Results() throws BusinessException {
        //@Given
        when(multiplierSaleDAO.findNotLinkedSalesInPreviousMonthForRevenueRecognition(any(PaymentStatus.class), any(DateRange.class), any(Optional.class))).thenReturn(Lists.<SaleItem>newArrayList());
        //@When
        postMultiplierToGrowerSalesRecognizer.recognizeRevenueFromSales();
        //@Then
        verify(saleDAO, never()).updateSaleItem(any(SaleItem.class));
    }

    @Test
    public void testRecognizeRevenueFromSalesNotInvokesSubmitAndSaveBonusPosting_whenFindNotLinkedSalesInPreviousMonthForRevenueRecognitionRetrieves0Results() throws BusinessException {
        //@Given
        when(multiplierSaleDAO.findNotLinkedSalesInPreviousMonthForRevenueRecognition(any(PaymentStatus.class), any(DateRange.class), any(Optional.class))).thenReturn(Lists.<SaleItem>newArrayList());
        //@When
        postMultiplierToGrowerSalesRecognizer.recognizeRevenueFromSales();
        //@Then
        verify(postingService, never()).submitAndSaveBonusPosting(any(BigDecimal.class), any(ReferenceNameEnum.class), anyString(), any(Date.class), any(Date.class), anyString());
    }

    @Test
    public void testRecognizeRevenueFromSalesSaleItemPostingStatusMustBeREVENUE_RECOGNITION_POSTED_whenFindNotLinkedSalesInPreviousMonthForRevenueRecognitionWithPaymentStatusNOT_PAIDRetrievesSaleItems() throws BusinessException {
        //@Given
        SaleItem saleItem = buildSaleItem();
        when(multiplierSaleDAO.findNotLinkedSalesInPreviousMonthForRevenueRecognition(eq(PaymentStatus.NOT_PAID), any(DateRange.class), any(Optional.class))).thenReturn(Lists.newArrayList(saleItem));
        //@When
        postMultiplierToGrowerSalesRecognizer.recognizeRevenueFromSales();
        //@Then
        assertEquals(PostingStatusEnum.REVENUE_RECOGNITION_POSTED, saleItem.getPostingStatus());
    }

    @Test
    public void testRecognizeRevenueFromSalesSaleItemPostingDateMustBeOSBDate_whenFindNotLinkedSalesInPreviousMonthForRevenueRecognitionWithPaymentStatusNOT_PAIDRetrievesSaleItems() throws BusinessException {
        //@Given
        SaleItem saleItem = buildSaleItem();
        when(multiplierSaleDAO.findNotLinkedSalesInPreviousMonthForRevenueRecognition(eq(PaymentStatus.NOT_PAID), any(DateRange.class), any(Optional.class))).thenReturn(Lists.newArrayList(saleItem));
        //@When
        postMultiplierToGrowerSalesRecognizer.recognizeRevenueFromSales();
        //@Then
        assertEquals(osbDate, saleItem.getPostingDate());
    }

    @Test
    public void testRecognizeRevenueFromSalesInvokesUpdateSaleItem_whenFindNotLinkedSalesInPreviousMonthForRevenueRecognitionWithPaymentStatusNOT_PAIDRetrievesSaleItems() throws BusinessException {
        //@Given
        SaleItem saleItem = buildSaleItem();
        when(multiplierSaleDAO.findNotLinkedSalesInPreviousMonthForRevenueRecognition(eq(PaymentStatus.NOT_PAID), any(DateRange.class), any(Optional.class))).thenReturn(Lists.newArrayList(saleItem));
        //@When
        postMultiplierToGrowerSalesRecognizer.recognizeRevenueFromSales();
        //@Then
        verify(saleDAO).updateSaleItem(saleItem);
    }

    @Test
    public void testRecognizeRevenueFromSalesInvokesSubmitAndSavePosting_whenFindNotLinkedSalesInPreviousMonthForRevenueRecognitionWithPaymentStatusNOT_PAIDRetrievesSaleItems() throws BusinessException {
        //@Given
        SaleItem saleItem = buildSaleItem();
        when(multiplierSaleDAO.findNotLinkedSalesInPreviousMonthForRevenueRecognition(eq(PaymentStatus.NOT_PAID), any(DateRange.class), any(Optional.class))).thenReturn(Lists.newArrayList(saleItem));
        //@When
        postMultiplierToGrowerSalesRecognizer.recognizeRevenueFromSales();
        //@Then
        verify(postingService).submitAndSaveBonusPosting(any(BigDecimal.class), any(ReferenceNameEnum.class), anyString(), any(Date.class), any(Date.class), anyString());
    }

    @Test
    public void testRecognizeRevenueFromSalesInvokesSubmitAndSavePostingWithPostingValueSaleItemRevenueRecognition_whenFindNotLinkedSalesInPreviousMonthForRevenueRecognitionWithPaymentStatusNOT_PAIDRetrievesSaleItems() throws BusinessException {
        //@Given
        SaleItem saleItem = buildSaleItem();
        when(multiplierSaleDAO.findNotLinkedSalesInPreviousMonthForRevenueRecognition(eq(PaymentStatus.NOT_PAID), any(DateRange.class), any(Optional.class))).thenReturn(Lists.newArrayList(saleItem));
        //@When
        postMultiplierToGrowerSalesRecognizer.recognizeRevenueFromSales();
        //@Then
        verify(postingService).submitAndSaveBonusPosting(eq(saleItem.getRevenueRecognition()), any(ReferenceNameEnum.class), anyString(), any(Date.class), any(Date.class), anyString());
    }

    @Test
    public void testRecognizeRevenueFromSalesInvokesSubmitAndSavePostingWithReferenceNameEnumROYALTIES_REVENUE_RECOGNITION_whenFindNotLinkedSalesInPreviousMonthForRevenueRecognitionWithPaymentStatusNOT_PAIDRetrievesSaleItems() throws BusinessException {
        //@Given
        SaleItem saleItem = buildSaleItem();
        when(multiplierSaleDAO.findNotLinkedSalesInPreviousMonthForRevenueRecognition(eq(PaymentStatus.NOT_PAID), any(DateRange.class), any(Optional.class))).thenReturn(Lists.newArrayList(saleItem));
        //@When
        postMultiplierToGrowerSalesRecognizer.recognizeRevenueFromSales();
        //@Then
        verify(postingService).submitAndSaveBonusPosting(any(BigDecimal.class), eq(ReferenceNameEnum.ROYALTIES_REVENUE_RECOGNITION), anyString(), any(Date.class), any(Date.class), anyString());
    }

    @Test
    public void testRecognizeRevenueFromSalesInvokesSubmitAndSavePostingWithReferenceExtendedDescriptionNull_whenFindNotLinkedSalesInPreviousMonthForRevenueRecognitionWithPaymentStatusNOT_PAIDRetrievesSaleItems() throws BusinessException {
        //@Given
        SaleItem saleItem = buildSaleItem();
        when(multiplierSaleDAO.findNotLinkedSalesInPreviousMonthForRevenueRecognition(eq(PaymentStatus.NOT_PAID), any(DateRange.class), any(Optional.class))).thenReturn(Lists.newArrayList(saleItem));
        //@When
        postMultiplierToGrowerSalesRecognizer.recognizeRevenueFromSales();
        //@Then
        String expectedReferenceExtendedDescription = null;
        verify(postingService).submitAndSaveBonusPosting(any(BigDecimal.class), any(ReferenceNameEnum.class), eq(expectedReferenceExtendedDescription), any(Date.class), any(Date.class), anyString());
    }

    @Test
    public void testRecognizeRevenueFromSalesInvokesSubmitAndSavePostingWithDefaultTechnology_whenFindNotLinkedSalesInPreviousMonthForRevenueRecognitionWithPaymentStatusNOT_PAIDRetrievesSaleItems() throws BusinessException {
        //@Given
        SaleItem saleItem = buildSaleItem();
        when(multiplierSaleDAO.findNotLinkedSalesInPreviousMonthForRevenueRecognition(eq(PaymentStatus.NOT_PAID), any(DateRange.class), any(Optional.class))).thenReturn(Lists.newArrayList(saleItem));
        //@When
        postMultiplierToGrowerSalesRecognizer.recognizeRevenueFromSales();
        //@Then
        verify(postingService).submitAndSaveBonusPosting(any(BigDecimal.class), any(ReferenceNameEnum.class), anyString(), any(Date.class), any(Date.class), eq(OsbBonusPostingService.DEFAULT_TECHNOLOGY));
    }

    @Test
    public void testRecognizeRevenueFromSalesInvokesSubmitAndSavePostingWithPostingValueSaleItemRevenueRecognition_whenFindNotLinkedSalesInPreviousMonthForRevenueRecognitionWithPaymentStatusFULLY_PAIDRetrievesSaleItems() throws BusinessException {
        //@Given
        SaleItem saleItem = buildSaleItem();
        when(multiplierSaleDAO.findNotLinkedSalesInPreviousMonthForRevenueRecognition(eq(PaymentStatus.FULLY_PAID), any(DateRange.class), any(Optional.class))).thenReturn(Lists.newArrayList(saleItem));
        //@When
        postMultiplierToGrowerSalesRecognizer.recognizeRevenueFromSales();
        //@Then
        verify(postingService).submitAndSaveBonusPosting(eq(saleItem.getRevenueRecognition()), any(ReferenceNameEnum.class), anyString(), any(Date.class), any(Date.class), anyString());
    }

    @Test
    public void testRecognizeRevenueFromSalesInvokesSubmitAndSavePostingWithReferenceNameEnumROYALTIES_REVENUE_RECOGNITION_whenFindNotLinkedSalesInPreviousMonthForRevenueRecognitionWithPaymentStatusFULLY_PAIDRetrievesSaleItems() throws BusinessException {
        //@Given
        SaleItem saleItem = buildSaleItem();
        when(multiplierSaleDAO.findNotLinkedSalesInPreviousMonthForRevenueRecognition(eq(PaymentStatus.FULLY_PAID), any(DateRange.class), any(Optional.class))).thenReturn(Lists.newArrayList(saleItem));
        //@When
        postMultiplierToGrowerSalesRecognizer.recognizeRevenueFromSales();
        //@Then
        verify(postingService).submitAndSaveBonusPosting(any(BigDecimal.class), eq(ReferenceNameEnum.REVERT_CASH_GT_REVENUE_RECOGNITION), anyString(), any(Date.class), any(Date.class), anyString());
    }

    @Test
    public void testRecognizeRevenueFromSalesInvokesSubmitAndSavePostingWithReferenceExtendedDescriptionNull_whenFindNotLinkedSalesInPreviousMonthForRevenueRecognitionWithPaymentStatusFULLY_PAIDRetrievesSaleItems() throws BusinessException {
        //@Given
        SaleItem saleItem = buildSaleItem();
        when(multiplierSaleDAO.findNotLinkedSalesInPreviousMonthForRevenueRecognition(eq(PaymentStatus.FULLY_PAID), any(DateRange.class), any(Optional.class))).thenReturn(Lists.newArrayList(saleItem));
        //@When
        postMultiplierToGrowerSalesRecognizer.recognizeRevenueFromSales();
        //@Then
        String expectedReferenceExtendedDescription = null;
        verify(postingService).submitAndSaveBonusPosting(any(BigDecimal.class), any(ReferenceNameEnum.class), eq(expectedReferenceExtendedDescription), any(Date.class), any(Date.class), anyString());
    }

    @Test
    public void testRecognizeRevenueFromSalesInvokesSubmitAndSavePostingWithDefaultTechnology_whenFindNotLinkedSalesInPreviousMonthForRevenueRecognitionWithPaymentStatusFULLY_PAIDRetrievesSaleItems() throws BusinessException {
        //@Given
        SaleItem saleItem = buildSaleItem();
        when(multiplierSaleDAO.findNotLinkedSalesInPreviousMonthForRevenueRecognition(eq(PaymentStatus.NOT_PAID), any(DateRange.class), any(Optional.class))).thenReturn(Lists.newArrayList(saleItem));
        //@When
        postMultiplierToGrowerSalesRecognizer.recognizeRevenueFromSales();
        //@Then
        verify(postingService).submitAndSaveBonusPosting(any(BigDecimal.class), any(ReferenceNameEnum.class), anyString(), any(Date.class), any(Date.class), eq(OsbBonusPostingService.DEFAULT_TECHNOLOGY));
    }

    @Test
    public void testRecognizeRevenueFromSalesInvokesSubmitAndSavePostingWithPostingValueSaleItemRevenueRecognition_whenFindNotLinkedSalesInPreviousMonthForRevenueRecognitionWithPaymentStatusBILLEDRetrievesSaleItems() throws BusinessException {
        //@Given
        SaleItem saleItem = buildSaleItem();
        when(multiplierSaleDAO.findNotLinkedSalesInPreviousMonthForRevenueRecognition(eq(PaymentStatus.BILLED), any(DateRange.class), any(Optional.class))).thenReturn(Lists.newArrayList(saleItem));
        //@When
        postMultiplierToGrowerSalesRecognizer.recognizeRevenueFromSales();
        //@Then
        verify(postingService).submitAndSaveBonusPosting(eq(saleItem.getRevenueRecognition()), any(ReferenceNameEnum.class), anyString(), any(Date.class), any(Date.class), anyString());
    }

    @Test
    public void testRecognizeRevenueFromSalesInvokesSubmitAndSavePostingWithReferenceNameEnumROYALTIES_REVENUE_RECOGNITION_whenFindNotLinkedSalesInPreviousMonthForRevenueRecognitionWithPaymentStatusBILLEDRetrievesSaleItems() throws BusinessException {
        //@Given
        SaleItem saleItem = buildSaleItem();
        when(multiplierSaleDAO.findNotLinkedSalesInPreviousMonthForRevenueRecognition(eq(PaymentStatus.BILLED), any(DateRange.class), any(Optional.class))).thenReturn(Lists.newArrayList(saleItem));
        //@When
        postMultiplierToGrowerSalesRecognizer.recognizeRevenueFromSales();
        //@Then
        verify(postingService).submitAndSaveBonusPosting(any(BigDecimal.class), eq(ReferenceNameEnum.REVERT_BILLING_GT_REVENUE_RECOGNITION), anyString(), any(Date.class), any(Date.class), anyString());
    }

    @Test
    public void testRecognizeRevenueFromSalesInvokesSubmitAndSavePostingWithReferenceExtendedDescriptionNull_whenFindNotLinkedSalesInPreviousMonthForRevenueRecognitionWithPaymentStatusBILLEDRetrievesSaleItems() throws BusinessException {
        //@Given
        SaleItem saleItem = buildSaleItem();
        when(multiplierSaleDAO.findNotLinkedSalesInPreviousMonthForRevenueRecognition(eq(PaymentStatus.BILLED), any(DateRange.class), any(Optional.class))).thenReturn(Lists.newArrayList(saleItem));
        //@When
        postMultiplierToGrowerSalesRecognizer.recognizeRevenueFromSales();
        //@Then
        String expectedReferenceExtendedDescription = null;
        verify(postingService).submitAndSaveBonusPosting(any(BigDecimal.class), any(ReferenceNameEnum.class), eq(expectedReferenceExtendedDescription), any(Date.class), any(Date.class), anyString());
    }

    @Test
    public void testRecognizeRevenueFromSalesInvokesSubmitAndSavePostingWithDefaultTechnology_whenFindNotLinkedSalesInPreviousMonthForRevenueRecognitionWithPaymentStatusBILLEDRetrievesSaleItems() throws BusinessException {
        //@Given
        SaleItem saleItem = buildSaleItem();
        when(multiplierSaleDAO.findNotLinkedSalesInPreviousMonthForRevenueRecognition(eq(PaymentStatus.BILLED), any(DateRange.class), any(Optional.class))).thenReturn(Lists.newArrayList(saleItem));
        //@When
        postMultiplierToGrowerSalesRecognizer.recognizeRevenueFromSales();
        //@Then
        verify(postingService).submitAndSaveBonusPosting(any(BigDecimal.class), any(ReferenceNameEnum.class), anyString(), any(Date.class), any(Date.class), eq(OsbBonusPostingService.DEFAULT_TECHNOLOGY));
    }

    @Test
    public void testRecognizeRevenueFromSalesSaleItemRevenueRecognitionMustBe1000_whenFindNotLinkedSalesInPreviousMonthForRevenueRecognitionWithPaymentStatusNOT_PAIDRetrievesSaleItemsWithNetRoyaltyValueQuantity1000() throws BusinessException {
        //@Given
        SaleItem saleItem = buildSaleItem();
        when(multiplierSaleDAO.findNotLinkedSalesInPreviousMonthForRevenueRecognition(eq(PaymentStatus.NOT_PAID), any(DateRange.class), any(Optional.class))).thenReturn(Lists.newArrayList(saleItem));
        //@When
        postMultiplierToGrowerSalesRecognizer.recognizeRevenueFromSales();
        //@Then
        assertEquals(BigDecimal.valueOf(1000), saleItem.getRevenueRecognition());
    }

    @Test
    public void testRecognizeRevenueFromSalesSaleItemRevenueRecognitionMustBe1500_whenFindNotLinkedSalesInPreviousMonthForRevenueRecognitionWithPaymentStatusNOT_PAIDRetrievesSaleItemsWithNetRoyaltyValueQuantity1500() throws BusinessException {
        //@Given
        SaleItem saleItem = buildSaleItem();
        saleItem.setNetRoyaltyValueQuantity(BigDecimal.valueOf(1500));
        when(multiplierSaleDAO.findNotLinkedSalesInPreviousMonthForRevenueRecognition(eq(PaymentStatus.NOT_PAID), any(DateRange.class), any(Optional.class))).thenReturn(Lists.newArrayList(saleItem));
        //@When
        postMultiplierToGrowerSalesRecognizer.recognizeRevenueFromSales();
        //@Then
        assertEquals(BigDecimal.valueOf(1500), saleItem.getRevenueRecognition());
    }

    private SaleItem buildSaleItem() {
        SaleItem saleItem = new SaleItem();
        saleItem.setNetRoyaltyValueQuantity(BigDecimal.valueOf(1000));
        return saleItem;
    }

    @Test
    public void testRecognizeRevenueFromSalesSearchForSaleCreationDateRange_WhenRecognizingSales() throws BusinessException {
        postMultiplierToGrowerSalesRecognizer.recognizeRevenueFromSales();

        verify(calendarRule).getSaleCreationDateRange();
    }

    @Test
    public void testRecognizeRevenueFromSalesFindsNotLinkedSalesInPreviousMonthForRevenueRecognition_WithSaleCreationDateRange() throws BusinessException {
        DateRange dateRange = new DateRange(new Date(), new Date());
        when(calendarRule.getSaleCreationDateRange()).thenReturn(dateRange);
        postMultiplierToGrowerSalesRecognizer.recognizeRevenueFromSales();

        verify(multiplierSaleDAO, times(3)).findNotLinkedSalesInPreviousMonthForRevenueRecognition(any(PaymentStatus.class), eq(dateRange), any(Optional.class));
    }

    @Test
    public void testRecognizeRevenueFromSalesSearchForSaleInvoiceDateRange_WhenRecognizingSales() throws BusinessException {
        postMultiplierToGrowerSalesRecognizer.recognizeRevenueFromSales();

        verify(calendarRule).getSaleInvoiceDateRange();
    }

    @Test
    public void testRecognizeRevenueFromSalesFindNotLinkedSalesInPreviousMonthForRevenueRecognition_WithSaleInvoiceDateRange() throws BusinessException {
        Optional<DateRange> dateRange = Optional.of(new DateRange(new Date(), new Date()));
        when(calendarRule.getSaleInvoiceDateRange()).thenReturn(dateRange);
        postMultiplierToGrowerSalesRecognizer.recognizeRevenueFromSales();

        verify(multiplierSaleDAO, times(3)).findNotLinkedSalesInPreviousMonthForRevenueRecognition(any(PaymentStatus.class), any(DateRange.class), eq(dateRange));
    }

}