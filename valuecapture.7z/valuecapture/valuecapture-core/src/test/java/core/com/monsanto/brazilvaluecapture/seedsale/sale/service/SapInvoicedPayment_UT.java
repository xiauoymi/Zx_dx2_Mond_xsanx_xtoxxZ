package com.monsanto.brazilvaluecapture.seedsale.sale.service;

import com.monsanto.brazilvaluecapture.seedsale.billing.model.bean.Billing;
import com.monsanto.brazilvaluecapture.seedsale.billing.model.bean.PossiblePayment;
import com.monsanto.brazilvaluecapture.seedsale.billing.service.BillingConstraintViolationException;
import com.monsanto.brazilvaluecapture.seedsale.template.model.bean.SaleTemplatePaymentMethodEnum;
import org.junit.Before;
import org.junit.Test;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import static org.fest.assertions.Assertions.assertThat;
import static org.fest.reflect.core.Reflection.field;

/**
 * Created by HGFIOR on 30/06/2014.
 */
public class SapInvoicedPayment_UT {

    public static final String Y_FI_DOC = "11111111";
        public static final String INVOICE_NUMBER = "123456";
        private SapInvoicedPayment sapPayment;

        @Before
        public void setUp() throws BillingConstraintViolationException {
            Date dummyDate = new Date();
            Billing billing = new Billing();
            PossiblePayment possiblePayment = new PossiblePayment();
            Set possiblePayments = new HashSet();
            possiblePayments.add(possiblePayment);
            field("payments").ofType(Set.class).in(billing).set(possiblePayments);
            sapPayment = new SapInvoicedPayment(INVOICE_NUMBER, SaleTemplatePaymentMethodEnum.GRAIN_TRADE, Y_FI_DOC, dummyDate,billing);
        }

        @Test
        public void test_BillingPaymentStatusIsUpdatedWhenYFiDocIsNotEmpty(){
            sapPayment.updateBillingPaymentStatus();
            assertThat(sapPayment.getBilling().getPaymentStatus()).isEqualTo(sapPayment.getPaymentStatus());
        }

        @Test
        public void test_ShouldUpdateBillingReturnsTrueWhenYFiDocIsNotEmpty(){
            boolean shouldUpdateBilling = sapPayment.shouldUpdateBilling();
            assertThat(shouldUpdateBilling).isTrue();
        }

        @Test
        public void test_BillingSapReceiptNumberShouldBeYFiDocWhenYFiDocIsNotEmptyAndOrderTypeIsBankSlip(){
            sapPayment.setPaymentMethod(SaleTemplatePaymentMethodEnum.BANK_SLIP);
            sapPayment.setSapReceiptNumber(sapPayment.getBilling().getPayments().iterator().next());
            Long receiptValue = sapPayment.getBilling().getPayments().iterator().next().getSapReceiptNumber();
            assertThat(receiptValue).isEqualTo(Long.parseLong(sapPayment.getyFiDoc()));
        }

        @Test
        public void test_BillingSapReceiptNumberShouldNotChangeWhenYFiDocIsNotEmptyAndOrderTypeIsNOTBankSlip(){
            sapPayment.setPaymentMethod(SaleTemplatePaymentMethodEnum.GRAIN_TRADE);
            sapPayment.setSapReceiptNumber(sapPayment.getBilling().getPayments().iterator().next());
            Long receiptValue = sapPayment.getBilling().getPayments().iterator().next().getSapReceiptNumber();
            assertThat(receiptValue).isNull();
        }

        @Test
        public void test_BillingSapContractNumberShouldBeYFiDocWhenYFiDocIsNotEmptyAndOrderTypeIsGrainTrade(){
            sapPayment.setPaymentMethod(SaleTemplatePaymentMethodEnum.GRAIN_TRADE);
            sapPayment.setSapContractNumber();
            assertThat(sapPayment.getBilling().getSapContractNumber()).isEqualTo(sapPayment.getyFiDoc());
        }

        @Test
        public void test_BillingSapContractNumberShouldNotChangeWhenYFiDocIsNotEmptyAndOrderTypeIsNOTBankSlip(){
            sapPayment.setPaymentMethod(SaleTemplatePaymentMethodEnum.BANK_SLIP);
            sapPayment.setSapContractNumber();
            assertThat(sapPayment.getBilling().getSapContractNumber()).isNull();
        }

}
