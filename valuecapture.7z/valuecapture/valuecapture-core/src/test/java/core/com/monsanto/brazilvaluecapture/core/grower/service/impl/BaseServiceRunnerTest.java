package com.monsanto.brazilvaluecapture.core.grower.service.impl;

import com.monsanto.brazilvaluecapture.core.account.model.bean.Transaction;
import com.monsanto.brazilvaluecapture.core.account.model.bean.TransactionType;
import com.monsanto.brazilvaluecapture.core.account.model.dao.TransactionDAO;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Company;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Crop;
import com.monsanto.brazilvaluecapture.core.base.model.bean.OperationalYear;
import com.monsanto.brazilvaluecapture.core.base.model.dao.OperationalYearDAO;
import com.monsanto.brazilvaluecapture.core.base.service.ServiceRunnerDataService;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Customer;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Technology;
import com.monsanto.brazilvaluecapture.core.foundation.model.bean.StatusEnum;
import com.monsanto.brazilvaluecapture.core.foundation.util.security.EnvironmentSpecificPropertyReader;
import com.monsanto.brazilvaluecapture.core.foundation.util.security.EnvironmentSpecificPropertyReaderFactory;
import com.monsanto.brazilvaluecapture.core.grower.model.bean.Grower;
import com.monsanto.brazilvaluecapture.osb.its.api.InfraException;
import com.monsanto.brazilvaluecapture.osb.util.SecurityContextBadCredentialException;
import com.monsanto.brazilvaluecapture.osb.util.SecurityContextHolder;
import com.monsanto.brazilvaluecapture.osb.util.SecurityContextHolderFactory;
import com.monsanto.brazilvaluecapture.seedsale.billing.model.bean.Billing;
import com.monsanto.brazilvaluecapture.seedsale.harvest.model.bean.Harvest;
import com.monsanto.brazilvaluecapture.seedsale.product.model.bean.Product;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.Sale;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.SaleItem;
import com.monsanto.brazilvaluecapture.seedsale.template.model.bean.SaleTemplate;
import org.junit.Before;

import java.net.MalformedURLException;
import java.util.ArrayList;

import static org.fest.reflect.core.Reflection.field;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

/**
 * @author Fernández, Israel
 * @author Folgar, Pablo
 * @since 3.1.1
 */
public abstract class BaseServiceRunnerTest {
    protected SecurityContextHolder securityContextHolder;
    protected TransactionDAO transactionDAO;
    protected OperationalYearDAO operationalYearDAO;
    protected EnvironmentSpecificPropertyReaderFactory environmentSpecificPropertyReaderFactory;
    protected SecurityContextHolderFactory securityContextHolderFactory;
    protected EnvironmentSpecificPropertyReader environmentSpecificPropertyReader;
    protected OperationalYear operationalYear = new OperationalYear("2013");
    protected Transaction transaction;
    protected Sale sale;
    protected ServiceRunnerDataService serviceRunnerDataService;

    @Before
    public void init() throws SecurityContextBadCredentialException, MalformedURLException, InfraException {
        serviceRunnerDataService = mock(ServiceRunnerDataService.class);
        securityContextHolder = mock(SecurityContextHolder.class);
        environmentSpecificPropertyReader = mock(EnvironmentSpecificPropertyReader.class);
        environmentSpecificPropertyReaderFactory = mock(EnvironmentSpecificPropertyReaderFactory.class);
        securityContextHolderFactory = new SecurityContextHolderFactory() {
            @Override
            public SecurityContextHolder getSecurityContextHolder(TARGET target) throws SecurityContextBadCredentialException {
                return securityContextHolder;
            }
        };
        when(environmentSpecificPropertyReaderFactory.getEnvironmentSpecificPropertyReader()).thenReturn(environmentSpecificPropertyReader);
        when(environmentSpecificPropertyReader.getEnvironmentSpecificProperty("osb_lasvc_prepaid_tons_url", null)).thenReturn("http://www.google.com");

        initOsbService();

//        when(lASVCPrepaidTonsServiceFactory.create(this.securityContextHolder, "http://www.google.com")).thenReturn(osbService);

        operationalYearDAO = mock(OperationalYearDAO.class);
        when(operationalYearDAO.selectAllOrderDesc()).thenReturn(new ArrayList<OperationalYear>() {
            {
                add(operationalYear);
            }
        });

        initTransactionDAO();
    }

    protected abstract void initOsbService() throws InfraException ;

    private void initTransactionDAO() {
        transactionDAO = mock(TransactionDAO.class);
        transaction = mock(Transaction.class);
        when(transaction.getId()).thenReturn(1l);
        when(transaction.getType()).thenReturn(TransactionType.PAYMENT);
    }

    protected void initializateSale() {
        sale = new Sale(new Customer(), new Grower());
        field("id").ofType(Long.class).in(sale).set(1l);
        Product product = new Product();
        Company company = new Company();
        product.setCompany(company);
        Technology technology = new Technology();
        technology.setId(1l);
        product.setTechnology(technology);
        Crop crop = new Crop();
        crop.setId(1l);
        product.setCrop(crop);

        Harvest harvest = new Harvest(company, "", operationalYear, crop, StatusEnum.ACTIVE);

        SaleTemplate saleTemplate = new SaleTemplate();
        saleTemplate.setHarvest(harvest);

        SaleItem saleItem = new SaleItem(sale, saleTemplate, product, null);

        Billing billing = new Billing();
        billing.setId(1L);
        saleItem.setBilling(billing);
        saleItem.setTotalCreditValue(1L);
        sale.getItems().add(saleItem);
    }
}
