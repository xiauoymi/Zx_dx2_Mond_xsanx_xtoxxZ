package com.monsanto.brazilvaluecapture.core.grower.service.impl;

import com.monsanto.brazilvaluecapture.core.account.model.bean.Transaction;
import com.monsanto.brazilvaluecapture.core.account.model.bean.TransactionType;
import com.monsanto.brazilvaluecapture.core.account.model.dao.TransactionDAO;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Company;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Crop;
import com.monsanto.brazilvaluecapture.core.base.model.bean.OperationalYear;
import com.monsanto.brazilvaluecapture.core.base.model.dao.OperationalYearDAO;
import com.monsanto.brazilvaluecapture.core.base.service.ServiceRunnerDataService;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Customer;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Technology;
import com.monsanto.brazilvaluecapture.core.foundation.model.bean.StatusEnum;
import com.monsanto.brazilvaluecapture.core.foundation.util.security.EnvironmentSpecificPropertyReader;
import com.monsanto.brazilvaluecapture.core.foundation.util.security.EnvironmentSpecificPropertyReaderFactory;
import com.monsanto.brazilvaluecapture.core.grower.model.bean.Grower;
import com.monsanto.brazilvaluecapture.osb.its.api.InfraException;
import com.monsanto.brazilvaluecapture.osb.its.api.LASVCPrepaidTonsServiceAR;
import com.monsanto.brazilvaluecapture.osb.its.api.LASVCPrepaidTonsServicePY;
import com.monsanto.brazilvaluecapture.osb.util.SecurityContextBadCredentialException;
import com.monsanto.brazilvaluecapture.osb.util.SecurityContextHolder;
import com.monsanto.brazilvaluecapture.osb.util.SecurityContextHolderFactory;
import com.monsanto.brazilvaluecapture.seedsale.billing.model.bean.Billing;
import com.monsanto.brazilvaluecapture.seedsale.harvest.model.bean.Harvest;
import com.monsanto.brazilvaluecapture.seedsale.product.model.bean.Product;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.Sale;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.SaleItem;
import com.monsanto.brazilvaluecapture.seedsale.template.model.bean.SaleTemplate;
import org.junit.Before;
import org.mockito.Mockito;

import java.net.MalformedURLException;
import java.util.ArrayList;

import static org.fest.reflect.core.Reflection.field;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

/**
 * @author Fernández, Israel
 * @author Folgar, Pablo
 * @since 3.1.1
 */
public class BaseARServiceRunnerTest extends BaseServiceRunnerTest {

    protected LASVCPrepaidTonsServiceAR osbService;

    protected void initOsbService() throws InfraException {
        osbService = mock(LASVCPrepaidTonsServiceAR.class);
        com.monsanto.brazilvaluecapture.osb.its.lasprepaidtonsar.bean.Transaction isTransaction =
                mock(com.monsanto.brazilvaluecapture.osb.its.lasprepaidtonsar.bean.Transaction.class);
        when(osbService.manageAccount(Mockito.anyString(), Mockito.anyString(), Mockito.eq(isTransaction))).thenReturn(1l);
    }
}
