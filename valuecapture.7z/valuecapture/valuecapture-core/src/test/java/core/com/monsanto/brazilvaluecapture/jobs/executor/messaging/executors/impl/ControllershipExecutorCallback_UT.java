package com.monsanto.brazilvaluecapture.jobs.executor.messaging.executors.impl;

import com.monsanto.brazilvaluecapture.core.foundation.service.BusinessException;
import com.monsanto.brazilvaluecapture.core.foundation.util.log.bean.JobLogEntry;
import com.monsanto.brazilvaluecapture.jobs.executor.messaging.bean.JobExecutionInfo;
import com.monsanto.brazilvaluecapture.multiplier.revenue.service.ControllershipJob;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import static org.fest.assertions.Assertions.assertThat;
import static org.junit.Assert.fail;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class ControllershipExecutorCallback_UT {

    @Mock
    private ControllershipJob controllershipJob;
    @Mock
    private JobExecutionInfo jobExecutionInfo;
    @InjectMocks
    private ControllershipExecutorCallback callback;

    @Before
    public void setUp() {
        when(jobExecutionInfo.getEntry()).thenReturn(new JobLogEntry());
    }

    @Test
    public void testDoWorkShouldSucceed() throws Exception {
        //@When
        callback.doWork(jobExecutionInfo);
        //@Then
        verify(controllershipJob).execute();
    }

    @Test
    public void testDoWork_whenOneStepFails_thenJobExecutionExceptionMustBeThrown() throws BusinessException {
        //@Given
        doThrow(BusinessException.class).when(controllershipJob).execute();
        //@When
        try {
            callback.doWork(jobExecutionInfo);
            fail("It must be throw a JobExecutionException");
        } catch (JobExecutionException e) {
            //@Then
            assertThat(e).hasMessage("Error executing controllership job");
        }

    }

}