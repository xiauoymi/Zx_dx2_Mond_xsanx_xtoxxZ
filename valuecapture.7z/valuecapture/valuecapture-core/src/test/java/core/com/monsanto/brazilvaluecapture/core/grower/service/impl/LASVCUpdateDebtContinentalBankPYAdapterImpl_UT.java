package com.monsanto.brazilvaluecapture.core.grower.service.impl;

import com.monsanto.brazilvaluecapture.core.debt.bean.DebtItemDTO;
import com.monsanto.brazilvaluecapture.core.debt.service.DebtNotFoundException;
import com.monsanto.brazilvaluecapture.core.debt.service.DebtService;
import com.monsanto.brazilvaluecapture.core.foundation.model.dao.SystemParameterDAO;
import com.monsanto.brazilvaluecapture.core.foundation.util.security.EnvironmentSpecificPropertyReader;
import com.monsanto.brazilvaluecapture.core.foundation.util.security.EnvironmentSpecificPropertyReaderFactory;
import com.monsanto.brazilvaluecapture.osb.its.api.InfraException;
import com.monsanto.brazilvaluecapture.osb.its.api.LASVCUpdateDebtContinentalBankPYService;
import com.monsanto.brazilvaluecapture.osb.its.api.LASVCUpdateDebtContinentalBankPYServiceFactory;
import com.monsanto.brazilvaluecapture.osb.its.lascontinentalbankpy.bean.OperationResult;
import com.monsanto.brazilvaluecapture.osb.util.SecurityContextBadCredentialException;
import com.monsanto.brazilvaluecapture.osb.util.SecurityContextHolder;
import com.monsanto.brazilvaluecapture.osb.util.SecurityContextHolderFactory;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Matchers;

import javax.activation.DataHandler;
import java.net.MalformedURLException;
import java.util.ArrayList;

import static org.fest.reflect.core.Reflection.field;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.*;

/**
 * Created by IntelliJ IDEA.
 * User: HGFIOR
 * Date: 11/06/13
 * Time: 16:44
 * To change this template use File | Settings | File Templates.
 */
public class LASVCUpdateDebtContinentalBankPYAdapterImpl_UT {
    private LASVCUpdateDebtContinentalBankPYAdapterImpl lasvcUpdateDebtContinentalBankPYAdapter;
    private SecurityContextHolderFactory securityContextHolderFactory;
    private EnvironmentSpecificPropertyReaderFactory environmentSpecificPropertyReaderFactory;
    private EnvironmentSpecificPropertyReader environmentSpecificPropertyReader;
    private SecurityContextHolder securityContextHolder;
    private SystemParameterDAO systemParameterDAO;
    private LASVCUpdateDebtContinentalBankPYServiceFactory lasvcUpdateDebtContinentalBankPYServiceFactory;
    private LASVCUpdateDebtContinentalBankPYService lasvcUpdateDebtContinentalBankPYService;
    private DebtService debtService;

    @Before
    public void setUp() throws SecurityContextBadCredentialException, MalformedURLException, InfraException, DebtNotFoundException {
        securityContextHolder = mock(SecurityContextHolder.class);
        securityContextHolderFactory = mock(SecurityContextHolderFactory.class);
        when(securityContextHolderFactory.getSecurityContextHolder(SecurityContextHolderFactory.TARGET.SAP)).thenReturn(securityContextHolder);

        environmentSpecificPropertyReader = mock(EnvironmentSpecificPropertyReader.class);
        environmentSpecificPropertyReaderFactory = mock(EnvironmentSpecificPropertyReaderFactory.class);
        when(environmentSpecificPropertyReaderFactory.getEnvironmentSpecificPropertyReader()).thenReturn(environmentSpecificPropertyReader);
        when(environmentSpecificPropertyReader.getEnvironmentSpecificProperty("osb_lasvc_inform_debt_continental_bank_py_url", null)).thenReturn("http://www.google.com");

        systemParameterDAO = mock(SystemParameterDAO.class);
        when(systemParameterDAO.selectParameterValueByGroupAndNameAndCountryCode(LASVCUpdateDebtContinentalBankPYAdapterImpl.I_CONTINENTAL_BANK_DEBT_NOTIFICATION, "CURRENCY", LASVCUpdateDebtContinentalBankPYAdapterImpl.COUNTRY_CODE)).thenReturn("CURRENCY");
        when(systemParameterDAO.selectParameterValueByGroupAndNameAndCountryCode(LASVCUpdateDebtContinentalBankPYAdapterImpl.I_CONTINENTAL_BANK_DEBT_NOTIFICATION, "CONCEPT", LASVCUpdateDebtContinentalBankPYAdapterImpl.COUNTRY_CODE)).thenReturn("CONCEPT");
        when(systemParameterDAO.selectParameterValueByGroupAndNameAndCountryCode(LASVCUpdateDebtContinentalBankPYAdapterImpl.I_CONTINENTAL_BANK_DEBT_NOTIFICATION, "DUE_DATE", LASVCUpdateDebtContinentalBankPYAdapterImpl.COUNTRY_CODE)).thenReturn("12/12/2012");

        debtService = mock(DebtService.class);
        when(debtService.getContinentalBankDebtItems()).thenReturn(new ArrayList<DebtItemDTO>());

        lasvcUpdateDebtContinentalBankPYService = mock(LASVCUpdateDebtContinentalBankPYService.class);
        OperationResult operationResult = new OperationResult();
        when(lasvcUpdateDebtContinentalBankPYService.updateDebt(anyString(), any(DataHandler.class))).thenReturn(operationResult);
        lasvcUpdateDebtContinentalBankPYServiceFactory = mock(LASVCUpdateDebtContinentalBankPYServiceFactory.class);
        when(lasvcUpdateDebtContinentalBankPYServiceFactory.create(any(SecurityContextHolder.class), anyString())).thenReturn(lasvcUpdateDebtContinentalBankPYService);

        lasvcUpdateDebtContinentalBankPYAdapter = new LASVCUpdateDebtContinentalBankPYAdapterImpl(securityContextHolderFactory, environmentSpecificPropertyReaderFactory);
        field("systemParameterDAO").ofType(SystemParameterDAO.class).in(lasvcUpdateDebtContinentalBankPYAdapter).set(systemParameterDAO);
        field("debtService").ofType(DebtService.class).in(lasvcUpdateDebtContinentalBankPYAdapter).set(debtService);
        field("lasvcUpdateDebtContinentalBankPYServiceFactory").ofType(LASVCUpdateDebtContinentalBankPYServiceFactory.class).in(lasvcUpdateDebtContinentalBankPYAdapter).set(lasvcUpdateDebtContinentalBankPYServiceFactory);
    }

    @Test
    public void testUpdateDebt() throws Exception {
        // @Given a retailer sale with SaleType = RETAILER_SALE

        // @When informing the debt
        lasvcUpdateDebtContinentalBankPYAdapter.updateDebt();

        // @Then The interface is called with the debts file
        verify(lasvcUpdateDebtContinentalBankPYService, times(1)).updateDebt(anyString(), Matchers.<DataHandler>any());
    }
}
