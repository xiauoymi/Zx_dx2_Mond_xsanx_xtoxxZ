package com.monsanto.brazilvaluecapture.seedsale.cashAdvance.validation.rules;

import com.monsanto.brazilvaluecapture.core.customer.model.bean.Customer;
import com.monsanto.brazilvaluecapture.core.foundation.validation.ValidationException;
import com.monsanto.brazilvaluecapture.core.presentation.beans.ResourceBundleTestHelper;
import com.monsanto.brazilvaluecapture.seedsale.cashAdvance.model.bean.CashAdvanceSourceOperationType;
import com.monsanto.brazilvaluecapture.seedsale.cashAdvance.model.bean.CashAdvanceTransaction;
import com.monsanto.brazilvaluecapture.seedsale.template.model.bean.DueDatePriceItem;
import org.junit.Test;

import java.math.BigDecimal;

import static org.fest.assertions.Fail.fail;
import static org.fest.assertions.Assertions.*;

public class CashAdvanceAmountValidationRule_UT {
    @Test
    public void testValidateThrowsValidationException_WhenCashAdvanceAmountIsEqualToZero() {
        Customer partner = new Customer();
        DueDatePriceItem referenceDate = new DueDatePriceItem();
        BigDecimal amount = BigDecimal.ZERO;
        CashAdvanceTransaction cashAdvanceTransaction = new CashAdvanceTransaction(partner, partner, null, referenceDate, amount, CashAdvanceSourceOperationType.FORM);
        CashAdvanceAmountValidationRule cashAdvanceAmountValidationRule = new CashAdvanceAmountValidationRule();

        try {
            cashAdvanceAmountValidationRule.validate(cashAdvanceTransaction);
            fail("Should throw ValidationException");
        } catch (ValidationException e) {
            assertThat(e).hasMessage("cash.advance.message.invalid.amount");
        }
    }

    @Test
    public void testValidateThrowsValidationException_WhenCashAdvanceAmountIsNull() {
        Customer partner = new Customer();
        DueDatePriceItem referenceDate = new DueDatePriceItem();
        BigDecimal amount = null;
        CashAdvanceTransaction cashAdvanceTransaction = new CashAdvanceTransaction(partner, partner, null, referenceDate, amount, CashAdvanceSourceOperationType.FORM);
        CashAdvanceAmountValidationRule cashAdvanceAmountValidationRule = new CashAdvanceAmountValidationRule();

        try {
            cashAdvanceAmountValidationRule.validate(cashAdvanceTransaction);
            fail("Should throw ValidationException");
        } catch (ValidationException e) {
            assertThat(e).hasMessage("cash.advance.message.invalid.amount");
        }
    }

    @Test
    public void testValidateDoesNotThrowsValidationException_WhenCashAdvanceAmountIsNotEqualToZero() {
        Customer partner = new Customer();
        DueDatePriceItem referenceDate = new DueDatePriceItem();
        BigDecimal amount = BigDecimal.TEN;
        CashAdvanceTransaction cashAdvanceTransaction = new CashAdvanceTransaction(partner, partner, null, referenceDate, amount, CashAdvanceSourceOperationType.FORM);
        CashAdvanceAmountValidationRule cashAdvanceAmountValidationRule = new CashAdvanceAmountValidationRule();

        try {
            cashAdvanceAmountValidationRule.validate(cashAdvanceTransaction);
        } catch (ValidationException e) {
            fail("Should not throw ValidationException");
        }
    }

    @Test
    public void testValidateDoesNotThrowsNullPointerException_WhenCashAdvanceAmountIsNull() throws ValidationException {
        CashAdvanceAmountValidationRule cashAdvanceAmountValidationRule = new CashAdvanceAmountValidationRule();

        try {
            cashAdvanceAmountValidationRule.validate(null);
        } catch (NullPointerException e) {
            fail("Should not throw NullPointerException");
        }
    }

    private String[] messages = {"cash.advance.message.invalid.amount"};

    @Test
    public void testI18mMessages_Brazil() throws Exception {
        ResourceBundleTestHelper.assertLanguageStrExistsForBrazil(messages);
    }

    @Test
    public void testI18mMessages_English() throws Exception {
        ResourceBundleTestHelper.assertLanguageStrExistsForUS(messages);
    }
}