package com.monsanto.brazilvaluecapture.seedsale.billing.service.impl;

import com.monsanto.brazilvaluecapture.core.base.model.bean.Company;
import com.monsanto.brazilvaluecapture.seedsale.billing.model.bean.BillingCalendar;
import com.monsanto.brazilvaluecapture.seedsale.billing.model.bean.BillingCalendarLimit;
import com.monsanto.brazilvaluecapture.seedsale.billing.model.dao.BillingCalendarDao;
import com.monsanto.brazilvaluecapture.seedsale.template.model.bean.SaleTemplate;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import static org.junit.Assert.assertSame;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/**
 * Created by IntelliJ IDEA.
 * User: CGLLLO
 * Date: 19/09/13
 * Time: 15:18
 */
public class BillingCalendarServiceImpl_UT {

    @Mock
    private BillingCalendarDao billingCalendarDao;

    @InjectMocks
    private BillingCalendarServiceImpl billingCalendarService;

    @Before
    public void setUp() throws Exception {
        billingCalendarService = new BillingCalendarServiceImpl();
        MockitoAnnotations.initMocks(this);
    }


    @Test
    public void given_billingCalendar_when_save_should_createOrUpdate() throws Exception {
        // @Given
        BillingCalendar billingCalendar = new BillingCalendar();
        // @When
        billingCalendarService.save(billingCalendar);
        // @Should
        verify(billingCalendarDao).createOrUpdate(billingCalendar);
    }

    @Test
    public void given_date_and_company_when_getBillingCalendarsByDateAndCompany_should_return_billingCalendar() throws Exception {
        // @Given
        Date date = new Date();
        Company company = new Company();

        List<BillingCalendar> expected = new ArrayList<BillingCalendar>();
        when(billingCalendarDao.getBillingCalendarsByDateAndCompany(any(Date.class), any(Company.class))).thenReturn(expected);

        // @When
        Object result = billingCalendarService.getBillingCalendarsByDateAndCompany(date, company);

        // @Should
        assertSame(expected, result);
    }

    @Test
    public void given_limits_when_deleteBillingCalendarLimits_should_execute_billingCalendarDao_deleteBillingCalendarLimits() {
        // @Given
        List<BillingCalendarLimit> limits = new ArrayList<BillingCalendarLimit>();
        // @When
        billingCalendarService.deleteBillingCalendarLimits(limits);
        // @Should
        verify(billingCalendarDao).deleteBillingCalendarLimits(limits);
    }

    @Test
    public void given_saleTemplate_when_getBillingCalendarBySaleTemplate_should_return_billingCalendarList() {
        // @Given
        SaleTemplate saleTemplate = new SaleTemplate();
        BillingCalendar expected = new BillingCalendar();
        when(billingCalendarDao.getBillingCalendarBySaleTemplate(saleTemplate)).thenReturn(expected);
        // @When
        Object result = billingCalendarService.getBillingCalendarBySaleTemplate(saleTemplate);
        // @Should
        assertSame(expected, result);
    }
}
