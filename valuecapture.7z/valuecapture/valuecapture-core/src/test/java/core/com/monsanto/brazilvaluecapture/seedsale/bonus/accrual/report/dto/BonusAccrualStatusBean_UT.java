package com.monsanto.brazilvaluecapture.seedsale.bonus.accrual.report.dto;

import com.monsanto.brazilvaluecapture.seedsale.bonus.bulkimport.model.bean.BonusTransaction;
import org.junit.Test;

import static org.fest.assertions.Assertions.assertThat;

public class BonusAccrualStatusBean_UT {

    @Test
   	public void testEquals_returnsTue_whenAreTheSame() {
        BonusAccrualStatusBean bean = new BonusAccrualStatusBean(null);
        assertThat(bean.equals(bean)).isTrue();
    }

    @Test
   	public void testEquals_returnsFalse_whenAreOfDifferentType() {
        BonusAccrualStatusBean bean = new BonusAccrualStatusBean(null);
        assertThat(bean.equals(null)).isFalse();
        assertThat(bean.equals("string")).isFalse();
    }

    @Test
   	public void testEquals_returnsFalse_whenHaveDifferentAttributes() {
        BonusAccrualStatusBean bean;
        BonusAccrualStatusBean anotherBean;

        bean = new BonusAccrualStatusBean(BonusTransaction.CodeSource.BONUS_UPDATE);
        anotherBean = new BonusAccrualStatusBean(BonusTransaction.CodeSource.CONSUMPTION);
        assertThat(bean.equals(anotherBean)).isFalse();

        bean = new BonusAccrualStatusBean(null, BonusTransaction.Type.CONSUMPTION);
        anotherBean = new BonusAccrualStatusBean(null, BonusTransaction.Type.GENERATION);
        assertThat(bean.equals(anotherBean)).isFalse();

        bean = new BonusAccrualStatusBean(BonusTransaction.CodeSource.BONUS_UPDATE, BonusTransaction.Type.CONSUMPTION);
        anotherBean = new BonusAccrualStatusBean(BonusTransaction.CodeSource.CONSUMPTION, BonusTransaction.Type.GENERATION);
        assertThat(bean.equals(anotherBean)).isFalse();
    }

    @Test
   	public void testEquals_returnsTue_whenHaveSameAttributes() {
        BonusAccrualStatusBean bean;
        BonusAccrualStatusBean anotherBean;

        bean = new BonusAccrualStatusBean(BonusTransaction.CodeSource.CONSUMPTION);
        anotherBean = new BonusAccrualStatusBean(BonusTransaction.CodeSource.CONSUMPTION);
        assertThat(bean.equals(anotherBean)).isTrue();

        bean = new BonusAccrualStatusBean(null, BonusTransaction.Type.CONSUMPTION);
        anotherBean = new BonusAccrualStatusBean(null, BonusTransaction.Type.CONSUMPTION);
        assertThat(bean.equals(anotherBean)).isTrue();

        bean = new BonusAccrualStatusBean(BonusTransaction.CodeSource.CONSUMPTION, BonusTransaction.Type.CONSUMPTION);
        anotherBean = new BonusAccrualStatusBean(BonusTransaction.CodeSource.CONSUMPTION, BonusTransaction.Type.CONSUMPTION);
        assertThat(bean.equals(anotherBean)).isTrue();
    }

}
