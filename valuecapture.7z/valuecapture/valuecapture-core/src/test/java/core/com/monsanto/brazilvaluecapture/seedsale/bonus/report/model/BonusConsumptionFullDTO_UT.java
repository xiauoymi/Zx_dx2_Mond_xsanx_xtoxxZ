package com.monsanto.brazilvaluecapture.seedsale.bonus.report.model;

import com.monsanto.brazilvaluecapture.core.base.model.bean.*;
import com.monsanto.brazilvaluecapture.core.commercialhierarchy.model.bean.ItsDistrictCity;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Contract;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Customer;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Technology;
import com.monsanto.brazilvaluecapture.core.grower.model.bean.AgreementTemplateType;
import com.monsanto.brazilvaluecapture.core.grower.model.bean.BonusConsumption;
import com.monsanto.brazilvaluecapture.core.grower.model.bean.BonusConsumptionStatusEnum;
import com.monsanto.brazilvaluecapture.core.grower.model.bean.Grower;
import com.monsanto.brazilvaluecapture.utils.ResourceBundleStub;
import org.junit.Before;
import org.junit.Test;

import java.math.BigDecimal;
import java.util.*;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class BonusConsumptionFullDTO_UT {

    private Map<String, String> properties;

    @Before
    public void init() {
        properties = new HashMap<String, String>();
        properties.put("bonus.consumption.status.opened", "");
        properties.put("bonus.consumption.status.reversed", "");
    }

    @Test
    public void testBonusConsumptionNew_whenNew() {
        BonusConsumption bonusConsumption = mock(BonusConsumption.class);
        when(bonusConsumption.getBonusConsumptionStatus()).thenReturn(BonusConsumptionStatusEnum.OPENED);
        Crop crop = mock(Crop.class);
        Company company = mock(Company.class);
        ResourceBundle bundle = new ResourceBundleStub(properties);

        BonusConsumptionFullDTO result = new BonusConsumptionFullDTO(bonusConsumption, crop, company, bundle);

        assertNotNull(result);
    }

    @Test
    public void testBonusConsumptionNew_whenOperationalYearIsIncluded() {
        BonusConsumption bonusConsumption = mock(BonusConsumption.class);
        when(bonusConsumption.getBonusConsumptionStatus()).thenReturn(BonusConsumptionStatusEnum.OPENED);
        OperationalYear operationalYear = mock(OperationalYear.class);
        String operationalYearYear = "2014";
        when(bonusConsumption.getOperationalYear()).thenReturn(operationalYear);
        when(operationalYear.getYear()).thenReturn(operationalYearYear);
        Crop crop = mock(Crop.class);
        Company company = mock(Company.class);
        ResourceBundle bundle = new ResourceBundleStub(properties);

        BonusConsumptionFullDTO result = new BonusConsumptionFullDTO(bonusConsumption, crop, company, bundle);

        assertEquals(operationalYearYear, result.getOperationalYear());
    }

    @Test
    public void testBonusConsumptionNew_whenConsumptionDateIsIncluded() {
        BonusConsumption bonusConsumption = mock(BonusConsumption.class);
        when(bonusConsumption.getBonusConsumptionStatus()).thenReturn(BonusConsumptionStatusEnum.OPENED);
        Date date = new Date();
        when(bonusConsumption.getConsumptionDate()).thenReturn(date);

        Crop crop = mock(Crop.class);
        Company company = mock(Company.class);
        ResourceBundle bundle = new ResourceBundleStub(properties);

        BonusConsumptionFullDTO result = new BonusConsumptionFullDTO(bonusConsumption, crop, company, bundle);

        assertEquals(date.toString(), result.getConsumptionDate());
    }

    @Test
    public void testBonusConsumptionNew_whenPartnerIsIncluded() {
        BonusConsumption bonusConsumption = mock(BonusConsumption.class);
        when(bonusConsumption.getBonusConsumptionStatus()).thenReturn(BonusConsumptionStatusEnum.OPENED);
        Customer partner = mock(Customer.class);
        when(partner.getName()).thenReturn("DUMMY_NAME");
        when(bonusConsumption.getPartner()).thenReturn(partner);

        Crop crop = mock(Crop.class);
        Company company = mock(Company.class);
        ResourceBundle bundle = new ResourceBundleStub(properties);

        BonusConsumptionFullDTO result = new BonusConsumptionFullDTO(bonusConsumption, crop, company, bundle);

        assertEquals(partner.getName(), result.getPartner());
    }

    @Test
    public void testBonusConsumptionNew_whenPartnerDocumentIsIncluded() {
        BonusConsumption bonusConsumption = mock(BonusConsumption.class);
        when(bonusConsumption.getBonusConsumptionStatus()).thenReturn(BonusConsumptionStatusEnum.OPENED);
        Customer partner = mock(Customer.class);
        when(partner.getName()).thenReturn("DUMMY_NAME");
        Document document = mock(Document.class);
        when(partner.getDocument()).thenReturn(document);
        when(bonusConsumption.getPartner()).thenReturn(partner);

        Crop crop = mock(Crop.class);
        Company company = mock(Company.class);
        ResourceBundle bundle = new ResourceBundleStub(properties);

        BonusConsumptionFullDTO result = new BonusConsumptionFullDTO(bonusConsumption, crop, company, bundle);

        assertEquals(partner.getDocument().getValueFormatted(), result.getPartnerDocument());
    }

    @Test
    public void testBonusConsumptionNew_whenPartnerAddressCityIsIncluded() {
        BonusConsumption bonusConsumption = mock(BonusConsumption.class);
        when(bonusConsumption.getBonusConsumptionStatus()).thenReturn(BonusConsumptionStatusEnum.OPENED);
        Customer partner = mock(Customer.class);
        Address address = mock(Address.class);
        City city = mock(City.class);
        when(city.getDescription()).thenReturn("DUMMY_CITY_DESCRIPTION");
        when(address.getCity()).thenReturn(city);
        when(partner.getAddress()).thenReturn(address);
        when(bonusConsumption.getPartner()).thenReturn(partner);

        Crop crop = mock(Crop.class);
        Company company = mock(Company.class);
        ResourceBundle bundle = new ResourceBundleStub(properties);

        BonusConsumptionFullDTO result = new BonusConsumptionFullDTO(bonusConsumption, crop, company, bundle);

        assertEquals(partner.getAddress().getCity().getDescription(), result.getPartnerCity());
    }

    @Test
    public void testBonusConsumptionNew_whenPartnerAddressDistrictCitiesAreIncluded() {
        BonusConsumption bonusConsumption = mock(BonusConsumption.class);
        when(bonusConsumption.getBonusConsumptionStatus()).thenReturn(BonusConsumptionStatusEnum.OPENED);
        Customer partner = mock(Customer.class);
        Address address = mock(Address.class);
        City city = mock(City.class);
        Set<ItsDistrictCity> districtCities = new HashSet<ItsDistrictCity>();
        ItsDistrictCity districtCity = mock(ItsDistrictCity.class);
        when(districtCity.getCity()).thenReturn(city);
        districtCities.add(districtCity);
        when(city.getDistrictsCities()).thenReturn(districtCities);
        when(address.getCity()).thenReturn(city);
        when(partner.getAddress()).thenReturn(address);
        when(bonusConsumption.getPartner()).thenReturn(partner);

        Crop crop = mock(Crop.class);
        Company company = mock(Company.class);
        ResourceBundle bundle = new ResourceBundleStub(properties);

        BonusConsumptionFullDTO result = new BonusConsumptionFullDTO(bonusConsumption, crop, company, bundle);

        assertEquals(partner.getAddress().getCity().getDescription(), result.getPartnerCity());
    }

    @Test
    public void testBonusConsumptionNew_whenPartnerAddressStateIsIncluded() {
        BonusConsumption bonusConsumption = mock(BonusConsumption.class);
        when(bonusConsumption.getBonusConsumptionStatus()).thenReturn(BonusConsumptionStatusEnum.OPENED);
        Customer partner = mock(Customer.class);
        Address address = mock(Address.class);
        State state = mock(State.class);
        when(state.getDescription()).thenReturn("DUMMY_STATE_DESCRIPTION");
        when(address.getState()).thenReturn(state);
        when(partner.getAddress()).thenReturn(address);
        when(bonusConsumption.getPartner()).thenReturn(partner);

        Crop crop = mock(Crop.class);
        Company company = mock(Company.class);
        ResourceBundle bundle = new ResourceBundleStub(properties);

        BonusConsumptionFullDTO result = new BonusConsumptionFullDTO(bonusConsumption, crop, company, bundle);

        assertEquals(partner.getAddress().getState().getDescription(), result.getPartnerState());
    }

    @Test
    public void testBonusConsumptionNew_whenPartnerContractsAreIncluded() {
        BonusConsumption bonusConsumption = mock(BonusConsumption.class);
        when(bonusConsumption.getBonusConsumptionStatus()).thenReturn(BonusConsumptionStatusEnum.OPENED);
        Customer partner = mock(Customer.class);

        Set<Contract> contracts = new HashSet<Contract>();
        Contract contract = mock(Contract.class);
        when(contract.getContractCode()).thenReturn("DUMMY_CONTRACT_CODE");
        when(contract.getCustomer()).thenReturn(partner);
        contracts.add(contract);
        when(partner.getContracts()).thenReturn(contracts);
        when(bonusConsumption.getPartner()).thenReturn(partner);

        Crop crop = mock(Crop.class);
        Company company = mock(Company.class);
        ResourceBundle bundle = new ResourceBundleStub(properties);

        BonusConsumptionFullDTO result = new BonusConsumptionFullDTO(bonusConsumption, crop, company, bundle);

        assertEquals(contract.getContractCode(), result.getContractNumber());
    }

    @Test
    public void testBonusConsumptionNew_whenHeadofficeIsIncluded() {
        BonusConsumption bonusConsumption = mock(BonusConsumption.class);
        when(bonusConsumption.getBonusConsumptionStatus()).thenReturn(BonusConsumptionStatusEnum.OPENED);
        Customer headoffice = mock(Customer.class);
        when(headoffice.getName()).thenReturn("DUMMY_NAME");
        when(bonusConsumption.getHeadOffice()).thenReturn(headoffice);

        Crop crop = mock(Crop.class);
        Company company = mock(Company.class);
        ResourceBundle bundle = new ResourceBundleStub(properties);

        BonusConsumptionFullDTO result = new BonusConsumptionFullDTO(bonusConsumption, crop, company, bundle);

        assertEquals(headoffice.getName(), result.getHeadOffice());
    }

    @Test
    public void testBonusConsumptionNew_whenHeadofficeAddressCityIsIncluded() {
        BonusConsumption bonusConsumption = mock(BonusConsumption.class);
        when(bonusConsumption.getBonusConsumptionStatus()).thenReturn(BonusConsumptionStatusEnum.OPENED);
        Customer headoffice = mock(Customer.class);
        Address address = mock(Address.class);
        City city = mock(City.class);
        when(city.getDescription()).thenReturn("DUMMY_CITY_DESCRIPTION");
        when(address.getCity()).thenReturn(city);
        when(headoffice.getAddress()).thenReturn(address);
        when(bonusConsumption.getHeadOffice()).thenReturn(headoffice);

        Crop crop = mock(Crop.class);
        Company company = mock(Company.class);
        ResourceBundle bundle = new ResourceBundleStub(properties);

        BonusConsumptionFullDTO result = new BonusConsumptionFullDTO(bonusConsumption, crop, company, bundle);

        assertEquals(headoffice.getAddress().getCity().getDescription(), result.getHeadOfficeCity());
    }

    @Test
    public void testBonusConsumptionNew_whenHeadofficeAddressDistrictCitiesAreIncluded() {
        BonusConsumption bonusConsumption = mock(BonusConsumption.class);
        when(bonusConsumption.getBonusConsumptionStatus()).thenReturn(BonusConsumptionStatusEnum.OPENED);
        Customer headoffice = mock(Customer.class);
        Address address = mock(Address.class);
        City city = mock(City.class);
        Set<ItsDistrictCity> districtCities = new HashSet<ItsDistrictCity>();
        ItsDistrictCity districtCity = mock(ItsDistrictCity.class);
        when(districtCity.getCity()).thenReturn(city);
        districtCities.add(districtCity);
        when(city.getDistrictsCities()).thenReturn(districtCities);
        when(address.getCity()).thenReturn(city);
        when(headoffice.getAddress()).thenReturn(address);
        when(bonusConsumption.getHeadOffice()).thenReturn(headoffice);

        Crop crop = mock(Crop.class);
        Company company = mock(Company.class);
        ResourceBundle bundle = new ResourceBundleStub(properties);

        BonusConsumptionFullDTO result = new BonusConsumptionFullDTO(bonusConsumption, crop, company, bundle);

        assertEquals(headoffice.getAddress().getCity().getDescription(), result.getHeadOfficeCity());
    }

    @Test
    public void testBonusConsumptionNew_whenHeadofficeAddressStateIsIncluded() {
        BonusConsumption bonusConsumption = mock(BonusConsumption.class);
        when(bonusConsumption.getBonusConsumptionStatus()).thenReturn(BonusConsumptionStatusEnum.OPENED);
        Customer headoffice = mock(Customer.class);
        Address address = mock(Address.class);
        State state = mock(State.class);
        when(state.getDescription()).thenReturn("DUMMY_STATE_DESCRIPTION");
        when(address.getState()).thenReturn(state);
        when(headoffice.getAddress()).thenReturn(address);
        when(bonusConsumption.getHeadOffice()).thenReturn(headoffice);

        Crop crop = mock(Crop.class);
        Company company = mock(Company.class);
        ResourceBundle bundle = new ResourceBundleStub(properties);

        BonusConsumptionFullDTO result = new BonusConsumptionFullDTO(bonusConsumption, crop, company, bundle);

        assertEquals(headoffice.getAddress().getState().getDescription(), result.getHeadOfficeState());
    }

    @Test
    public void testBonusConsumptionNew_whenGrowerIsIncluded() {
        BonusConsumption bonusConsumption = mock(BonusConsumption.class);
        when(bonusConsumption.getBonusConsumptionStatus()).thenReturn(BonusConsumptionStatusEnum.OPENED);
        Grower grower = mock(Grower.class);
        when(grower.getName()).thenReturn("DUMMY_GROWER_NAME");
        when(bonusConsumption.getGrower()).thenReturn(grower);

        Crop crop = mock(Crop.class);
        Company company = mock(Company.class);
        ResourceBundle bundle = new ResourceBundleStub(properties);

        BonusConsumptionFullDTO result = new BonusConsumptionFullDTO(bonusConsumption, crop, company, bundle);

        assertEquals(grower.getName(), result.getGrower());
    }

    @Test
    public void testBonusConsumptionNew_whenGrowerWithDocumentIsIncluded() {
        BonusConsumption bonusConsumption = mock(BonusConsumption.class);
        when(bonusConsumption.getBonusConsumptionStatus()).thenReturn(BonusConsumptionStatusEnum.OPENED);
        Grower grower = mock(Grower.class);
        Document document = mock(Document.class);
        when(document.getValue()).thenReturn("DUMMY_DOCUMENT_VALUE");
        DocumentType documentType = mock(DocumentType.class);
        when(document.getDocumentType()).thenReturn(documentType);
        when(grower.getDocument()).thenReturn(document);
        when(bonusConsumption.getGrower()).thenReturn(grower);

        Crop crop = mock(Crop.class);
        Company company = mock(Company.class);
        ResourceBundle bundle = new ResourceBundleStub(properties);

        BonusConsumptionFullDTO result = new BonusConsumptionFullDTO(bonusConsumption, crop, company, bundle);

        assertEquals(document.getValue(), result.getDocumentNo());
    }

    @Test
    public void testBonusConsumptionNew_whenTechnologyIsIncluded() {
        BonusConsumption bonusConsumption = mock(BonusConsumption.class);
        when(bonusConsumption.getBonusConsumptionStatus()).thenReturn(BonusConsumptionStatusEnum.OPENED);

        Technology technology = mock(Technology.class);
        when(technology.getDescription()).thenReturn("DUMMY_TECHNOLOGY_DESCRIPTION");
        when(bonusConsumption.getTechnology()).thenReturn(technology);

        Crop crop = mock(Crop.class);
        Company company = mock(Company.class);
        ResourceBundle bundle = new ResourceBundleStub(properties);

        BonusConsumptionFullDTO result = new BonusConsumptionFullDTO(bonusConsumption, crop, company, bundle);

        assertEquals(technology.getDescription(), result.getTechnology());
    }

    @Test
    public void testBonusConsumptionNew_whenAgreementTemplateTypeIsIncluded() {
        BonusConsumption bonusConsumption = mock(BonusConsumption.class);
        when(bonusConsumption.getBonusConsumptionStatus()).thenReturn(BonusConsumptionStatusEnum.OPENED);

        AgreementTemplateType agreementTemplateType = mock(AgreementTemplateType.class);
        when(agreementTemplateType.getDescription()).thenReturn("DUMMY_AGREEMENT_TEMPLATE_TYPE_DESCRIPTION");
        when(bonusConsumption.getAgreementTemplateType()).thenReturn(agreementTemplateType);

        Crop crop = mock(Crop.class);
        Company company = mock(Company.class);
        ResourceBundle bundle = new ResourceBundleStub(properties);

        BonusConsumptionFullDTO result = new BonusConsumptionFullDTO(bonusConsumption, crop, company, bundle);

        assertEquals(agreementTemplateType.getDescription(), result.getAgreementType());
    }

    @Test
    public void testBonusConsumptionNew_whenConsumedAmountIsIncluded() {
        BonusConsumption bonusConsumption = mock(BonusConsumption.class);
        when(bonusConsumption.getBonusConsumptionStatus()).thenReturn(BonusConsumptionStatusEnum.OPENED);

        BigDecimal consumedAmount = BigDecimal.TEN;
        when(bonusConsumption.getConsumedAmount()).thenReturn(consumedAmount);

        Crop crop = mock(Crop.class);
        Company company = mock(Company.class);
        ResourceBundle bundle = new ResourceBundleStub(properties);

        BonusConsumptionFullDTO result = new BonusConsumptionFullDTO(bonusConsumption, crop, company, bundle);

        assertEquals(consumedAmount.toString(), result.getBonusConsumed());
    }

   /* @Test
    public void testBonusConsumptionNew_whenReversedDateIsIncluded() {
        BonusConsumption bonusConsumption = mock(BonusConsumption.class);
        BonusConsumptionReversal bonusConsumptionReversal = mock(BonusConsumptionReversal.class);
        List<BonusConsumptionReversal> bonusConsumptionReversals = new ArrayList<BonusConsumptionReversal>();
        bonusConsumptionReversals.add(bonusConsumptionReversal);
        bonusConsumption.setBonusConsumptionStatus(BonusConsumptionStatusEnum.REVERSED);
        when(bonusConsumption.getReversals()).thenReturn(bonusConsumptionReversals);

        Date reversedDate = mock(Date.class);
        when(bonusConsumptionReversal.getReversedDate()).thenReturn(reversedDate);

        Crop crop = mock(Crop.class);
        Company company = mock(Company.class);
        ResourceBundle bundle = new ResourceBundleStub(properties);

        BonusConsumptionFullDTO result = new BonusConsumptionFullDTO(bonusConsumption, crop, company, bundle);

        assertEquals(reversedDate.toString(), result.getReversedDate());
    }*/

    @Test
    public void testBonusConsumptionGettersAndSetters() {

        BonusConsumption bonusConsumption = mock(BonusConsumption.class);
        when(bonusConsumption.getBonusConsumptionStatus()).thenReturn(BonusConsumptionStatusEnum.OPENED);

        Crop crop = mock(Crop.class);
        Company company = mock(Company.class);
        ResourceBundle bundle = new ResourceBundleStub(properties);

        BonusConsumptionFullDTO result = new BonusConsumptionFullDTO(bonusConsumption, crop, company, bundle);

        String companyString = "";
        Long termNumber = new Long(4);
        String cropString = "DUMMY_CROP_STRING";
        String operationalYear = "DUMMY_OPERATIONAL_YEAR";
        String partner = "DUMMY_PARTNER";
        String partnerCity = "DUMMY_PARTNER_CITY";
        String partnerState = "DUMMY_PARTNER_STATE";
        String partnerUnit = "DUMMY_PARTNER_UNIT";
        String consumptionDate = "DUMMY_CONSUMPTION_DATE";
        String createdBy = "DUMMY_CREATED_BY";
        String partnerERPCode = "DUMMY_PARTNER_ERP_CODE";
        String partnerDocument = "DUMMY_PARTNER_DOCUMENT";
        String partnerRegion = "DUMMY_PARTNER_REGION";
        String partnerDistrict = "DUMMY_PARTNER_DISTRICT";
        String contractNumber = "DUMMY_CONTRACT_NUMBER";
        String headofficeERPCode = "DUMMY_ERP_CODE";
        String headofficeDocument = "DUMMY_HEADOFFICE_DOCUMENT";
        String headoffice = "DUMMY_HEADOFFICE";
        String headofficeCity = "DUMMY_HEADOFFICE_CITY";
        String headofficeState = "DUMMY_HEADOFFICE_STATE";
        String headofficeUnit = "DUMMY_HEADOFFICE_UNIT";
        String headofficeRegion = "DUMMY_HEADOFFICE_REGION";
        String headofficeDistrict = "DUMMY_HEADOFFICE_DISTRICT";
        String documentType = "DUMMY_DOCUMENT_TYPE";
        String documentNo = "DUMMY_DOCUMENT_NO";
        String grower = "DUMMY_GROWER";
        String technology = "DUMMY_TECHNOLOGY";
        String agreementType = "DUMMY_AGREEMENT_TYPE";
        String bonusConsumed = "DUMMY_BONUS_CONSUMED";
        String status = "DUMMY_STATUS";
        String reversedDate = "DUMMY_REVERSED_DATE";
        String reversedBy = "DUMMY_REVERSED_BY";
        String reason = "DUMMY_REASON";

        result.setCompany(companyString);
        result.setTermNumber(termNumber);
        result.setCrop(cropString);
        result.setOperationalYear(operationalYear);
        result.setConsumptionDate(consumptionDate);
        result.setCreatedBy(createdBy);
        result.setPartnerERPCode(partnerERPCode);
        result.setPartnerDocument(partnerDocument);
        result.setPartner(partner);
        result.setPartnerCity(partnerCity);
        result.setPartnerState(partnerState);
        result.setPartnerUnit(partnerUnit);
        result.setPartnerRegion(partnerRegion);
        result.setPartnerDistrict(partnerDistrict);
        result.setContractNumber(contractNumber);
        result.setHeadOfficeERPCode(headofficeERPCode);
        result.setHeadOfficeDocument(headofficeDocument);
        result.setHeadOffice(headoffice);
        result.setHeadOfficeCity(headofficeCity);
        result.setHeadOfficeState(headofficeState);
        result.setHeadOfficeUnit(headofficeUnit);
        result.setHeadOfficeRegion(headofficeRegion);
        result.setHeadOfficeDistrict(headofficeDistrict);
        result.setDocumentType(documentType);
        result.setDocumentNo(documentNo);
        result.setGrower(grower);
        result.setTechnology(technology);
        result.setAgreementType(agreementType);
        result.setBonusConsumed(bonusConsumed);
        result.setStatus(status);
        result.setReversedDate(reversedDate);
        result.setReversedBy(reversedBy);
        result.setReason(reason);

        assertEquals(companyString, result.getCompany());
        assertEquals(cropString, result.getCrop());
        assertEquals(termNumber, result.getTermNumber());
        assertEquals(operationalYear, result.getOperationalYear());
        assertEquals(consumptionDate, result.getConsumptionDate());
        assertEquals(createdBy, result.getCreatedBy());
        assertEquals(partnerERPCode, result.getPartnerERPCode());
        assertEquals(partnerDocument, result.getPartnerDocument());
        assertEquals(partner, result.getPartner());
        assertEquals(partnerCity, result.getPartnerCity());
        assertEquals(partnerState, result.getPartnerState());
        assertEquals(partnerUnit, result.getPartnerUnit());
        assertEquals(partnerRegion, result.getPartnerRegion());
        assertEquals(partnerDistrict, result.getPartnerDistrict());
        assertEquals(contractNumber, result.getContractNumber());
        assertEquals(headofficeERPCode, result.getHeadOfficeERPCode());
        assertEquals(headofficeDocument, result.getHeadOfficeDocument());
        assertEquals(headofficeDistrict, result.getHeadOfficeDistrict());
        assertEquals(documentType, result.getDocumentType());
        assertEquals(documentNo, result.getDocumentNo());
        assertEquals(grower, result.getGrower());
        assertEquals(technology, result.getTechnology());
        assertEquals(agreementType, result.getAgreementType());
        assertEquals(bonusConsumed, result.getBonusConsumed());
        assertEquals(status, result.getStatus());
        assertEquals(reversedDate, result.getReversedDate());
        assertEquals(reversedBy, result.getReversedBy());
        assertEquals(reason, result.getReason());
        assertEquals(headoffice, result.getHeadOffice());
        assertEquals(headofficeCity, result.getHeadOfficeCity());
        assertEquals(headofficeState, result.getHeadOfficeState());
        assertEquals(headofficeUnit, result.getHeadOfficeUnit());
        assertEquals(headofficeRegion, result.getHeadOfficeRegion());
    }
}
