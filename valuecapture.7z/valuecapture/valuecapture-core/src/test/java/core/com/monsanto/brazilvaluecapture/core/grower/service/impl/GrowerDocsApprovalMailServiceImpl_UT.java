package com.monsanto.brazilvaluecapture.core.grower.service.impl;


import com.monsanto.brazilvaluecapture.core.base.model.bean.Country;
import com.monsanto.brazilvaluecapture.core.base.model.dao.CountryDAO;
import com.monsanto.brazilvaluecapture.core.foundation.util.mail.MailManager;
import com.monsanto.brazilvaluecapture.core.foundation.util.mail.ParseTemplateException;
import com.monsanto.brazilvaluecapture.core.foundation.util.mail.SendMailFailedException;
import com.monsanto.brazilvaluecapture.core.grower.model.bean.EmailParameters;
import com.monsanto.brazilvaluecapture.core.grower.model.bean.Grower;
import com.monsanto.brazilvaluecapture.core.grower.model.bean.GrowerDocsApproval;
import com.monsanto.brazilvaluecapture.core.grower.model.dao.EmailParametersDAO;
import com.monsanto.brazilvaluecapture.core.grower.service.GrowerDocsApprovalMailService;
import com.monsanto.brazilvaluecapture.core.regionalization.CountriesHolder;
import com.monsanto.brazilvaluecapture.core.regionalization.VCCountry;
import com.monsanto.brazilvaluecapture.core.user.model.bean.UserContext;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentMatcher;
import org.mockito.Mock;
import org.mockito.Mockito;

import java.util.Map;

import static org.fest.reflect.core.Reflection.field;
import static org.mockito.Matchers.*;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.fest.assertions.Assertions.assertThat;

/**
 * Created with IntelliJ IDEA.
 * User: HGFIOR
 * Date: 10/02/14
 * Time: 11:39
 * To change this template use File | Settings | File Templates.
 */
public class GrowerDocsApprovalMailServiceImpl_UT {
    private GrowerDocsApprovalMailService growerDocsApprovalMailService = new GrowerDocsApprovalMailServiceImpl();
    @Mock
    private GrowerDocsApproval growerDocsApproval;
    @Mock
    private UserContext userContext;
    @Mock
    private CountryDAO countryDAO;
    @Mock
    private MailManager mailManager;
    @Mock
    private EmailParametersDAO emailParametersDAO;
    private EmailParameters emailParameters;

    @Before
    public void setUp() throws Exception {
        CountriesHolder countriesHolder = Mockito.mock(CountriesHolder.class);
        when(countriesHolder.getCountry()).thenReturn(VCCountry.ARGENTINA);
        mailManager = Mockito.mock(MailManager.class);
        countryDAO = Mockito.mock(CountryDAO.class);
        field("countriesHolder").ofType(CountriesHolder.class).in(growerDocsApprovalMailService).set(countriesHolder);
        field("mailManager").ofType(MailManager.class).in(growerDocsApprovalMailService).set(mailManager);
        field("countryDAO").ofType(CountryDAO.class).in(growerDocsApprovalMailService).set(countryDAO);
        Country country = Mockito.mock(Country.class);
        when(countryDAO.selectByDescription(anyString())).thenReturn(country);
        when(country.getId()).thenReturn(new Long(1));
        emailParametersDAO = Mockito.mock(EmailParametersDAO.class);
        field("emailParametersDAO").ofType(EmailParametersDAO.class).in(growerDocsApprovalMailService).set(emailParametersDAO);
        emailParameters = new EmailParameters();
        emailParameters.setAction("APPROVAL");
        emailParameters.setCountry(country);
        emailParameters.setGroupParams("GROWER_DOCS_APPROVAL");
        emailParameters.setMessage("Email Test Message. CUIT: ${cuit}, Razon Social : ${razon_social}, Comments : ${comment}");
        growerDocsApproval = Mockito.mock(GrowerDocsApproval.class);
        Grower grower = Mockito.mock(Grower.class);
        when(grower.getDocumentValueFormatted()).thenReturn("12345678901");
        when(grower.getName()).thenReturn("Grower Name");
        when(growerDocsApproval.getGrower()).thenReturn(grower);
        when(growerDocsApproval.getComment()).thenReturn("Some random comment");
        userContext = Mockito.mock(UserContext.class);
        when(userContext.getLogin()).thenReturn("The_LOGGED_USER");

    }

    @Test
    public void approvalGrowerDocsMail_APPROVAL_Test() throws ParseTemplateException, SendMailFailedException {
        // @Given a mail template and a body containing "dummy content"
        when(emailParametersDAO.getEmailParameters(anyString(),anyString(),anyLong())).thenReturn(emailParameters);


        // @When sending the grower docs approval mail
        growerDocsApprovalMailService.sendNotification(GrowerDocsApproval.ApprovalState.SENT_TO_APPROVAL, growerDocsApproval, userContext);

        // @Then the variables contain a "mailBody" with the expected content
        verify(mailManager).sendMimeMail(anyString(), anyString(), anyString(), argThat(new ArgumentMatcher<Map<String, Object>>() {
            @Override
            public boolean matches(Object argument) {
                return argument instanceof Map && "Email Test Message. CUIT: 12345678901, Razon Social : Grower Name, Comments : Some random comment".equals(((Map) argument).get("mailBody"));

            }
        }), anyString(), anyBoolean());

    }

    @Test
     public void approvalGrowerDocsMail_OBSERVE_Test() throws ParseTemplateException, SendMailFailedException {
         // @Given a mail template and a body containing "dummy content"
         when(emailParametersDAO.getEmailParameters(anyString(),anyString(),anyLong())).thenReturn(emailParameters);

         // @When sending the grower docs approval mail
         growerDocsApprovalMailService.sendNotification(GrowerDocsApproval.ApprovalState.OBSERVED, growerDocsApproval, userContext);

         // @Then the variables contain a "mailBody" with the expected content
         verify(mailManager).sendMimeMail(anyString(), anyString(), anyString(), argThat(new ArgumentMatcher<Map<String, Object>>() {
             @Override
             public boolean matches(Object argument) {
                 return argument instanceof Map && "Email Test Message. CUIT: 12345678901, Razon Social : Grower Name, Comments : Some random comment".equals(((Map) argument).get("mailBody"));

             }
         }), anyString(), anyBoolean());

     }
}
