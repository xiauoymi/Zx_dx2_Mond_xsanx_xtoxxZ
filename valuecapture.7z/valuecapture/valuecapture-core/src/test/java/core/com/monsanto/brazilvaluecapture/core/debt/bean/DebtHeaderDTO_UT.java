package com.monsanto.brazilvaluecapture.core.debt.bean;

import org.junit.Before;
import org.junit.Test;

/**
 * Created by IntelliJ IDEA.
 * User: ASEQU
 * Date: 6/12/13
 * Time: 2:41 PM
 * To change this template use File | Settings | File Templates.
 */
public class DebtHeaderDTO_UT {
    @Before
    public void setUp() throws Exception {

    }

    @Test
    public void testNacionBankConstructor() {
        DebtHeaderDTO dto = DebtHeaderDTO.getNacionInstance(null, null,null, null,null,null);

        System.out.println("Date= " + dto.getShipmentDate());
        System.out.println("Hour= "+ dto.getShipmentHour());
    }
}
