package com.monsanto.brazilvaluecapture.seedsale.sale.model.dao.impl;

import com.google.common.collect.Iterables;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.GrainTradeDeliveryDate;
import org.hibernate.Criteria;
import org.hibernate.SessionFactory;
import org.hibernate.classic.Session;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.SimpleExpression;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.List;

import static org.fest.assertions.Assertions.assertThat;
import static org.fest.reflect.core.Reflection.field;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.*;

/**
 * User: HGFIOR
 * Date: 16/05/14
 * Time: 11:39
 */
@RunWith(MockitoJUnitRunner.class)
public class GrainTradeDeliveryDateDAOImpl_UT {
    @Mock
    private SessionFactory sessionFactory;
    @InjectMocks
    private GrainTradeDeliveryDateDAOImpl dao;
    private Session session;
    private Criteria criteria;
    private GrainTradeDeliveryDate grainTradeDeliveryDate;
    private final static String DUMMY_COUNTRY_CODE = "AR";
    private List<GrainTradeDeliveryDate> grainTradeDeliveryDateList = new ArrayList<GrainTradeDeliveryDate>();

    @Before
    public void setUp() {
        session = mock(Session.class);
        when(sessionFactory.getCurrentSession()).thenReturn(session);
        criteria = mock(Criteria.class);
        grainTradeDeliveryDate = mock(GrainTradeDeliveryDate.class);
        grainTradeDeliveryDateList.add(grainTradeDeliveryDate);
        when(session.createCriteria(GrainTradeDeliveryDate.class)).thenReturn(criteria);
        when(criteria.add(any(Criterion.class))).thenReturn(criteria);
        when(criteria.list()).thenReturn(grainTradeDeliveryDateList);
    }

    // @Ignore
    @Test
    public void test_getAllByCountryCodeInvokesAddRestrictionWithPropertyNameCountryCode_WhenAddingRestriction() {


        //@When
        List<GrainTradeDeliveryDate> result = dao.getAllByCountryCode(DUMMY_COUNTRY_CODE);

        //@Then
        ArgumentCaptor<SimpleExpression> argumentCaptor = ArgumentCaptor.forClass(SimpleExpression.class);
        verify(criteria, times(2)).add(argumentCaptor.capture());
        SimpleExpression value = Iterables.getFirst(argumentCaptor.getAllValues(), null);
        String code = field("propertyName").ofType(String.class).in(value).get();
        String expectedCode = "countryCode";
        assertThat(code).isEqualTo(expectedCode);
    }

    @Test
    public void test_getAllByCountryCodeGetSentCountryCode_WhenAddingRestriction() {


        //@When
        List<GrainTradeDeliveryDate> result = dao.getAllByCountryCode(DUMMY_COUNTRY_CODE);

        //@Then
        ArgumentCaptor<SimpleExpression> argumentCaptor = ArgumentCaptor.forClass(SimpleExpression.class);
        verify(criteria, times(2)).add(argumentCaptor.capture());
        SimpleExpression value = Iterables.getFirst(argumentCaptor.getAllValues(), null);
        String code = field("value").ofType(Object.class).in(value).get().toString();
        assertThat(code).isEqualTo(DUMMY_COUNTRY_CODE);
    }

    @Test
    public void test_getAllByCountryCodeSendCountryCodePropertyWithDummyCountryCodeAsValue_WhenAddingRestriction() {


        //@When
        List<GrainTradeDeliveryDate> result = dao.getAllByCountryCode(DUMMY_COUNTRY_CODE);

        //@Then
        ArgumentCaptor<SimpleExpression> argumentCaptor = ArgumentCaptor.forClass(SimpleExpression.class);
        verify(criteria, times(2)).add(argumentCaptor.capture());
        SimpleExpression value = Iterables.getFirst(argumentCaptor.getAllValues(), null);
        String valueField = field("value").ofType(Object.class).in(value).get().toString();
        String propertyField = field("propertyName").ofType(String.class).in(value).get();
        assertThat(valueField).isEqualTo(DUMMY_COUNTRY_CODE);
        assertThat(propertyField).isEqualTo("countryCode");
    }

    @Test
    public void test_getAllByCountryCodeInvokesAddRestrictionWithPropertyNameIsVisible_WhenAddingRestriction() {


        //@When
        List<GrainTradeDeliveryDate> result = dao.getAllByCountryCode(DUMMY_COUNTRY_CODE);

        //@Then
        ArgumentCaptor<SimpleExpression> argumentCaptor = ArgumentCaptor.forClass(SimpleExpression.class);
        verify(criteria, times(2)).add(argumentCaptor.capture());
        SimpleExpression value = Iterables.getLast(argumentCaptor.getAllValues(), null);
        String code = field("propertyName").ofType(String.class).in(value).get();
        String expectedCode = "isVisible";
        assertThat(code).isEqualTo(expectedCode);
    }

    @Test
    public void test_getAllByCountryCodeUseTrueValue_WhenAddingRestriction() {


        //@When
        List<GrainTradeDeliveryDate> result = dao.getAllByCountryCode(DUMMY_COUNTRY_CODE);

        //@Then
        ArgumentCaptor<SimpleExpression> argumentCaptor = ArgumentCaptor.forClass(SimpleExpression.class);
        verify(criteria, times(2)).add(argumentCaptor.capture());
        SimpleExpression value = Iterables.getLast(argumentCaptor.getAllValues(), null);
        Boolean code = new Boolean(field("value").ofType(Object.class).in(value).get().toString());
        assertThat(code).isEqualTo(Boolean.TRUE);
    }

    @Test
    public void test_getAllByCountryCodeSendIsVisiblePropertyWithTrueAsValue_WhenAddingRestriction() {


        //@When
        List<GrainTradeDeliveryDate> result = dao.getAllByCountryCode(DUMMY_COUNTRY_CODE);

        //@Then
        ArgumentCaptor<SimpleExpression> argumentCaptor = ArgumentCaptor.forClass(SimpleExpression.class);
        verify(criteria, times(2)).add(argumentCaptor.capture());
        SimpleExpression value = Iterables.getLast(argumentCaptor.getAllValues(), null);
        Boolean valueField = new Boolean(field("value").ofType(Object.class).in(value).get().toString());
        String propertyField = field("propertyName").ofType(String.class).in(value).get();
        assertThat(valueField).isEqualTo(true);
        assertThat(propertyField).isEqualTo("isVisible");
    }

    @Test
    public void test_getAllByCountryCodeReturnsTheSameExpectedObject_WhenGettingAllByCountryCode() {

        //@Given

        //@When
        List<GrainTradeDeliveryDate> result = dao.getAllByCountryCode(DUMMY_COUNTRY_CODE);

        //@Then
        assertThat(result).isSameAs(grainTradeDeliveryDateList);
    }

    @Test
    public void test_getAllByCountryCodeInvokesCriteriaListMethod_WhenGettingAllByCountryCode() {

        //@Given

        //@When
        dao.getAllByCountryCode(DUMMY_COUNTRY_CODE);

        //@Then
        verify(criteria,times(1)).list();
    }


}
