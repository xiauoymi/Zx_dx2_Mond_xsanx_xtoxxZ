package com.monsanto.brazilvaluecapture.seedsale.sale.service;

import com.monsanto.brazilvaluecapture.osb.its.sappaymentsregistration.bean.YtyPymntAdvice;
import com.monsanto.brazilvaluecapture.seedsale.billing.model.bean.Billing;
import com.monsanto.brazilvaluecapture.seedsale.billing.model.bean.PaymentStatus;
import com.monsanto.brazilvaluecapture.seedsale.billing.model.bean.PossiblePayment;
import com.monsanto.brazilvaluecapture.seedsale.billing.service.BillingConstraintViolationException;
import com.monsanto.brazilvaluecapture.seedsale.template.model.bean.SaleTemplatePaymentMethodEnum;
import org.junit.Before;
import org.junit.Test;
import static org.fest.assertions.Assertions.assertThat;
import static org.fest.reflect.core.Reflection.field;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import java.math.BigDecimal;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

/**
 * Created by HGFIOR on 30/06/2014.
 */
public class SapPaidPayment_UT {

    public static final String Y_FI_DOC = "11111111";
    public static final String INVOICE_NUMBER = "123456";
    private SapPaidPayment sapPaidPayment;

    @Before
    public void setUp() throws BillingConstraintViolationException {
        Date dummyDate = new Date();
        Billing billing = new Billing();
        PossiblePayment possiblePayment = new PossiblePayment();
        Set possiblePayments = new HashSet();
        possiblePayments.add(possiblePayment);
        field("payments").ofType(Set.class).in(billing).set(possiblePayments);
        sapPaidPayment = new SapPaidPayment(INVOICE_NUMBER, SaleTemplatePaymentMethodEnum.GRAIN_TRADE, Y_FI_DOC, dummyDate,billing);
    }

    @Test
    public void test_BillingPaymentStatusIsUpdatedWhenYFiDocIsNotEmpty(){
        sapPaidPayment.updateBillingPaymentStatus();
        assertThat(sapPaidPayment.getBilling().getPaymentStatus()).isEqualTo(sapPaidPayment.getPaymentStatus());
    }

    @Test
    public void test_ShouldUpdateBillingReturnsTrueWhenYFiDocIsNotEmpty(){
        boolean shouldUpdateBilling = sapPaidPayment.shouldUpdateBilling();
        assertThat(shouldUpdateBilling).isTrue();
    }

    @Test
    public void test_BillingSapReceiptNumberShouldBeYFiDocWhenYFiDocIsNotEmptyAndOrderTypeIsBankSlip(){
        sapPaidPayment.setPaymentMethod(SaleTemplatePaymentMethodEnum.BANK_SLIP);
        sapPaidPayment.setSapReceiptNumber(sapPaidPayment.getBilling().getPayments().iterator().next());
        Long receiptValue = sapPaidPayment.getBilling().getPayments().iterator().next().getSapReceiptNumber();
        assertThat(receiptValue).isEqualTo(Long.parseLong(sapPaidPayment.getyFiDoc()));
    }

    @Test
    public void test_BillingSapReceiptNumberShouldNotChangeWhenYFiDocIsNotEmptyAndOrderTypeIsNOTBankSlip(){
        sapPaidPayment.setPaymentMethod(SaleTemplatePaymentMethodEnum.GRAIN_TRADE);
        sapPaidPayment.setSapReceiptNumber(sapPaidPayment.getBilling().getPayments().iterator().next());
        Long receiptValue = sapPaidPayment.getBilling().getPayments().iterator().next().getSapReceiptNumber();
        assertThat(receiptValue).isNull();
    }

    @Test
    public void test_BillingSapContractNumberShouldBeYFiDocWhenYFiDocIsNotEmptyAndOrderTypeIsGrainTrade(){
        sapPaidPayment.setPaymentMethod(SaleTemplatePaymentMethodEnum.GRAIN_TRADE);
        sapPaidPayment.setSapContractNumber();
        assertThat(sapPaidPayment.getBilling().getSapContractNumber()).isEqualTo(sapPaidPayment.getyFiDoc());
    }

    @Test
    public void test_BillingSapContractNumberShouldNotChangeWhenYFiDocIsNotEmptyAndOrderTypeIsNOTBankSlip(){
        sapPaidPayment.setPaymentMethod(SaleTemplatePaymentMethodEnum.BANK_SLIP);
        sapPaidPayment.setSapContractNumber();
        assertThat(sapPaidPayment.getBilling().getSapContractNumber()).isNull();
    }


}
