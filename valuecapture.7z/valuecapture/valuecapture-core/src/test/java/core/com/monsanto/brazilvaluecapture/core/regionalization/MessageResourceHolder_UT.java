package com.monsanto.brazilvaluecapture.core.regionalization;

import junit.framework.TestCase;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.ResourceBundle;

import static org.fest.assertions.Assertions.assertThat;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class MessageResourceHolder_UT extends TestCase {

    @Mock
    private CountriesHolder countriesHolder;
    @InjectMocks
    private MessageResourceHolder messageResourceHolder;

    @Before
    public void setUp() {
        when(countriesHolder.getCountry()).thenReturn(VCCountry.ARGENTINA);
    }

    @Test
    public void getMessageResource() {
        ResourceBundle result = messageResourceHolder.getMessageResource();
        assertThat(result.getLocale().getCountry()).isEqualTo("AR");
    }

    @Test
    public void getLocalizedLanguageMessage() {
        String result = messageResourceHolder.getLocalizedLanguageMessage("action.back");
        assertThat(result).isEqualTo("Volver");
    }

}
