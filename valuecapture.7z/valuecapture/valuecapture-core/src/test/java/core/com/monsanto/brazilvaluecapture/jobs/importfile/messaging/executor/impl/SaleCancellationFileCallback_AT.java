package com.monsanto.brazilvaluecapture.jobs.importfile.messaging.executor.impl;

import com.monsanto.CountriesHolderInitializer;
import com.monsanto.brazilvaluecapture.core.account.model.bean.ManualCreditTransactionType;
import com.monsanto.brazilvaluecapture.core.account.service.impl.AccountService;
import com.monsanto.brazilvaluecapture.core.base.SystemTestFixture;
import com.monsanto.brazilvaluecapture.core.foundation.service.BusinessException;
import com.monsanto.brazilvaluecapture.core.foundation.test.AbstractServiceIntegrationTests;
import com.monsanto.brazilvaluecapture.core.importfile.model.ImportFileType;
import com.monsanto.brazilvaluecapture.core.importfile.model.bean.CsvImportFile;
import com.monsanto.brazilvaluecapture.core.regionalization.CountriesHolder;
import com.monsanto.brazilvaluecapture.core.user.AccessControlTestFixture;
import com.monsanto.brazilvaluecapture.core.user.model.bean.HierarchyLevel;
import com.monsanto.brazilvaluecapture.core.user.model.bean.UserContract;
import com.monsanto.brazilvaluecapture.core.user.model.bean.UserDecorator;
import com.monsanto.brazilvaluecapture.core.user.service.ManualCreditConstraintException;
import com.monsanto.brazilvaluecapture.jobs.importfile.messaging.bean.FileImportDefinition;
import com.monsanto.brazilvaluecapture.jobs.importfile.messaging.bean.FileImportInfo;
import com.monsanto.brazilvaluecapture.jobs.importfile.messaging.bean.FileImportOperation;
import com.monsanto.brazilvaluecapture.seedsale.billing.model.bean.PaymentStatusGroup.PaymentStatusAll;
import com.monsanto.brazilvaluecapture.seedsale.sale.SaleTestFixture;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.Sale;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.SaleCancellationEntry;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.SaleCancellationResult;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.dao.SaleFilter;
import com.monsanto.brazilvaluecapture.seedsale.sale.service.SaleBuilder;
import com.monsanto.brazilvaluecapture.seedsale.sale.service.SaleCancellationService;
import com.monsanto.brazilvaluecapture.seedsale.sale.service.SaleConstraintViolationException;
import com.monsanto.brazilvaluecapture.seedsale.sale.service.SaleService;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.math.BigDecimal;
import java.util.*;

public class SaleCancellationFileCallback_AT extends AbstractServiceIntegrationTests {

	@Autowired
	private SaleService saleService;

	@Autowired
	private SaleCancellationCallback saleCancellationCallback;

	@Autowired
	private SaleCancellationService saleCancellationService;

	private ResourceBundle resourceBundle = ResourceBundle.getBundle("bundle/bundle");

	@Autowired
	private AccountService accountService;

    @Autowired
    private CountriesHolder countriesHolder;

	private Locale localeBR = new Locale("pt", "BR");

	private SaleBuilder builder;

    private UserDecorator getParticipantUser() {

        UserDecorator participantUser = accessControlTestFixture.participantUser;
        UserContract contractWithMons4nto = new UserContract(participantUser.getCurrentUser(), saleTestFixture.contractMons4nto, saleTestFixture.matrixMons4nto, HierarchyLevel.HEAD_OFFICE);
        saveAndFlush(contractWithMons4nto);

        participantUser.addUserContract(contractWithMons4nto);
        participantUser.setContextCrop(systemTestFixture.soyMons4nto);
        participantUser.addCompany(systemTestFixture.mons4ntoBr);

        return participantUser;
    }

    @Before
    public void init() {
        CountriesHolderInitializer.initialize(countriesHolder);
        systemTestFixture = new SystemTestFixture(this);
        saleTestFixture = new SaleTestFixture(this, systemTestFixture);
        accessControlTestFixture = new AccessControlTestFixture(this, systemTestFixture);
        builder = new SaleBuilder(systemTestFixture.matoGrossoDoSul, saleTestFixture.plantabilitiesSelectorMons4nto);

    }

    private Sale createASale(String invoiceNumber, Date date) throws SaleConstraintViolationException {
        builder.clear();
        builder.addSaleItem(saleTestFixture.productIntactaSoyMons4nto,
                saleTestFixture.templateIntactaMons4nto,
                saleTestFixture.officeMons4nto,
                2000L,
                SaleTestFixture.TWO_POINT_FIVE_DOLLARS,
                saleTestFixture.plantability45To54SoyMons4nto2012,
                date);

        Sale sale = builder.setGrower(saleTestFixture.chicoBento).setCustomer(saleTestFixture.matrixMons4nto).buildSale();
        sale.setCreationDate(SaleTestFixture.DATE_NOW);

        if (invoiceNumber != null) {
            sale.setInvoiceNumber(invoiceNumber);
        }
        saleService.save(sale, getParticipantUser());

        return sale;
    }

	@Test
    @Ignore
	public void given_one_file_with_one_entry_should_cancel_sale_succesfull() throws SaleConstraintViolationException {
		CsvImportFile file = new CsvImportFile("cancellation file", getParticipantUser().getLogin(), ImportFileType.SALE_CANCELLATION);
		saveAndFlush(file);

		SaleCancellationEntry entry = new SaleCancellationEntry(createASale("1235432", SaleTestFixture.DATE_NOW), saleTestFixture.saleCancellation, file);
		saveAndFlush(entry);

		saleCancellationCallback.doProceed(new FileImportInfo(file,
				getParticipantUser(), FileImportDefinition.SALE_CANCELLATION,
				FileImportOperation.PROCEED, localeBR, "bundle"));

		List<PaymentStatusAll> statusEq = new ArrayList<PaymentStatusAll>();
		statusEq.add(PaymentStatusAll.CANCELLED);
		List<Sale> sales = saleService.getSaleBy(SaleFilter.getInstance()
				.addBillingStatusEq(statusEq)
				.addCreationDateStart(SaleTestFixture.DATE_NOW)
				.addCreationDateEnd(SaleTestFixture.DATE_NOW));

		Assert.assertEquals("Should have one cancelled sale", 1, sales.size());
	}

	@Test
    @Ignore
	public void given_one_sale_without_balance_to_cancel_when_i_try_to_cancel_should_save_error_result() throws ManualCreditConstraintException, BusinessException {
		CsvImportFile file = new CsvImportFile("cancellation file", getParticipantUser().getLogin(), ImportFileType.SALE_CANCELLATION);
		saveAndFlush(file);
		Sale sale = createASale("1235432", SaleTestFixture.DATE_NOW);
		SaleCancellationEntry entry = new SaleCancellationEntry(sale, saleTestFixture.saleCancellation, file);
		saveAndFlush(entry);

		accountService.generateCreditManually(saleTestFixture.productIntactaSoyMons4nto
				.getCrop(), saleTestFixture.templateIntactaMons4nto
				.getHarvest().getOperationalYear(),
				saleTestFixture.productIntactaSoyMons4nto.getTechnology(),
				saleTestFixture.chicoBento, ManualCreditTransactionType.DEBIT,
				BigDecimal.ONE, "dunno", "vrodrigues");

        FileImportInfo fileImportInfo = new FileImportInfo(file,
				                                           getParticipantUser(),
                                                           FileImportDefinition.SALE_CANCELLATION,
				                                           FileImportOperation.PROCEED,
                                                           resourceBundle.getLocale(),
                                                           "bundle/bundle");
		saleCancellationCallback.doProceed(fileImportInfo);

		List<SaleCancellationResult> results = saleCancellationService.selectSaleCancellationResults(file);
		Assert.assertEquals("Should have one result", 1, results.size());
		System.out.println(results.get(0).getResult());
	}

	@Test(expected=UnsupportedOperationException.class)
	public void when_try_to_import_cancellation_file_should_throw_unsupportedOperationException() {
		saleCancellationCallback.doImport(new FileImportInfo(new CsvImportFile(
				"cancellation file", getParticipantUser().getLogin(),
				ImportFileType.SALE_CANCELLATION), getParticipantUser(),
				FileImportDefinition.SALE_CANCELLATION,
				FileImportOperation.IMPORT, resourceBundle.getLocale(),
				"bundle/bundle"));
	}

	@Test(expected=UnsupportedOperationException.class)
	public void when_try_to_cancel_cancellation_file_should_throw_unsupportedOperationException() {
		saleCancellationCallback.doCancel(new FileImportInfo(new CsvImportFile(
				"cancellation file", getParticipantUser().getLogin(),
				ImportFileType.SALE_CANCELLATION), getParticipantUser(),
				FileImportDefinition.SALE_CANCELLATION,
				FileImportOperation.CANCEL, resourceBundle.getLocale(),
				"bundle/bundle"));
	}

}
