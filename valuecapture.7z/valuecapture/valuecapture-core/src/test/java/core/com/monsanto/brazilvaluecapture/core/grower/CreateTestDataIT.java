package com.monsanto.brazilvaluecapture.core.grower;

import java.util.Date;

import org.hibernate.SessionFactory;
import org.junit.Ignore;

import com.monsanto.brazilvaluecapture.core.base.CityTestData;
import com.monsanto.brazilvaluecapture.core.base.CompanyTestData;
import com.monsanto.brazilvaluecapture.core.base.CropTestData;
import com.monsanto.brazilvaluecapture.core.base.OperationalYearTestData;
import com.monsanto.brazilvaluecapture.core.base.TechnologyTestData;
import com.monsanto.brazilvaluecapture.core.base.model.bean.BillingAddress;
import com.monsanto.brazilvaluecapture.core.base.model.bean.BusinessAddress;
import com.monsanto.brazilvaluecapture.core.base.model.bean.City;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Company;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Country;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Crop;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Document;
import com.monsanto.brazilvaluecapture.core.base.model.bean.DocumentType;
import com.monsanto.brazilvaluecapture.core.base.model.bean.OperationalYear;
import com.monsanto.brazilvaluecapture.core.base.model.bean.State;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Technology;
import com.monsanto.brazilvaluecapture.core.foundation.RandomTestData;
import com.monsanto.brazilvaluecapture.core.foundation.model.bean.StatusEnum;
import com.monsanto.brazilvaluecapture.core.foundation.service.BusinessException;
import com.monsanto.brazilvaluecapture.core.grower.model.bean.Grower;
import com.monsanto.brazilvaluecapture.seedsale.harvest.HarvestTestData;
import com.monsanto.brazilvaluecapture.seedsale.harvest.model.bean.Harvest;
import com.monsanto.brazilvaluecapture.seedsale.product.BrandTestData;
import com.monsanto.brazilvaluecapture.seedsale.product.ProductTestData;
import com.monsanto.brazilvaluecapture.seedsale.product.model.bean.Brand;
import com.monsanto.brazilvaluecapture.seedsale.product.model.bean.Product;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.Sale.SaleTypeEnum;
import com.monsanto.brazilvaluecapture.seedsale.template.PriceTestData;
import com.monsanto.brazilvaluecapture.seedsale.template.model.bean.Price.PriceTypeEnum;
import com.monsanto.brazilvaluecapture.seedsale.template.model.bean.SaleTemplate;
import com.monsanto.brazilvaluecapture.seedsale.template.model.bean.SaleTemplateBillingMethodEnum;
import com.monsanto.brazilvaluecapture.seedsale.template.model.bean.SaleTemplateByPlantabilityEnum;

@Ignore
public class CreateTestDataIT extends CreateTestData{
	
	SessionFactory sessionFactory;
	
	public CreateTestDataIT(){
		
	}
	
	public CreateTestDataIT(SessionFactory sessionFactory){
		this.sessionFactory = sessionFactory;
	}
	
	/**
	 * Create a new harvest
	 * @param country TODO
	 * 
	 * @return Harvest
	 */
	public Harvest createFullHarvest(Country country){
		
		OperationalYear operationalYear = OperationalYearTestData.createOperationalYear();
		saveOrUpdate(operationalYear);
		
		Company company = CompanyTestData.createACompanyInBrazil();
		saveOrUpdate(company);
		Crop crop = CropTestData.createCrop(company, country);
		saveOrUpdate(crop);
		
		Brand brand = BrandTestData.createBrand(company);
		saveOrUpdate(brand);
		Technology tech = TechnologyTestData.createTechnology(company);
		saveOrUpdate(tech);
		
		createProduct(StatusEnum.ACTIVE, crop, brand, tech, company);
		
		Harvest harvest = HarvestTestData.createHarvest(crop, operationalYear, company);
		
		saveOrUpdate(harvest);
		
		return  harvest;
	}
		
	/**
	 * Create a new company
	 * 
	 * @return Company
	 */
	public Company createFullCompany(){
		Company company = super.createFullCompany();
		
		saveOrUpdate(company);
		
		return company;
	}
	
	/**
	 * Create a new full sale template
	 * 
	 * @param initialDate
	 * @param credit
	 * @param document
	 * @param country TODO
	 * @return SaleTemplate
	 * @throws BusinessException 
	 * @throws  
	 */
	public SaleTemplate createFullSaleTemplate(Date initialDate, Boolean credit, Boolean document, Country country) throws BusinessException {

		Harvest harvest = createFullHarvest(country);

		SaleTemplate saleTemplate = new SaleTemplate(harvest,
				RandomTestData.createRandomString(10), initialDate, document,
				SaleTemplateByPlantabilityEnum.BY_PRODUCT, new Date(), new Date(), SaleTypeEnum.SALE_SEED, SaleTemplateBillingMethodEnum.DIRECT);
		
		saleTemplate.addPrices(PriceTestData.createPrice(PriceTypeEnum.FIX, saleTemplate, harvest.getCompany().getTechnologies().iterator().next()));
		
		saveOrUpdate(saleTemplate);
		
		return saleTemplate;

	}
	
	/**
	 * TODO: Criar os demais testdata: country/state/city, documentType/document
	 * Create a new full grower
	 * 
	 * @return Grower
	 */
	public Grower createFullGrower() {
		Country country = createBasicCountry();
		State state = createStateByCountry(country);
		City city = createCityByState(state);
		DocumentType documentType = createDocumentType(country);
		Document document = createDocument(documentType);

		BusinessAddress businessAddress = PlayerTestData.createBusinessAddress(
				state, city, country);
		BillingAddress billingAddress = PlayerTestData.createBillingAddress(
				state, city, country);

		Grower grower = PlayerTestData.createGrower(document, billingAddress,
				businessAddress);

		return grower;
	}
	
	/**
	 * Create company
	 * @return Company
	 */
	public Company createBasicCompany(){
		
		Company c = super.createBasicCompany();
		
		saveOrUpdate(c);
		
		return c;
	}
	
	/**
	 * Create a new crop by company
	 * @param company
	 * @return
	 */
	public Crop createCrop(Company company, Country country){
		
		Crop crop = super.createCrop(company, country);
		
		company.addCrop(crop);
		
		saveOrUpdate(crop);
		
		return crop;
	}
	
	/**
	 * Create a new brand by company
	 * @param company
	 * @return
	 */
	public Brand createBrand(Company company){
		
		Brand brand = super.createBrand(company);
		
		company.addBrand(brand);
		
		saveOrUpdate(brand);
		
		return brand;
	}
	
	/**
	 * Create a new technology by company
	 * @param company
	 * @return
	 */
	public Technology createTechnology(Company company){
		
		Technology tech = super.createTechnology(company);
		
		company.addTechnology(tech);
		
		saveOrUpdate(tech);
		
		return tech;
	}
	
	/**
	 * TODO re-factoring
	 * Create a new full product
	 * 
	 * @param status
	 * @param country TODO
	 * @return Product
	 */
	public Product createFullProduct(StatusEnum status, Country country){
		
		Company company =  CompanyTestData.createACompanyInBrazil();
		saveOrUpdate(company);
		Crop crop = CropTestData.createCrop(company, country);
		saveOrUpdate(crop);
		Brand brand = BrandTestData.createBrand(company);
		saveOrUpdate(brand);
		Technology tech = TechnologyTestData.createTechnology(company);
		saveOrUpdate(tech);
		Product product = ProductTestData.createProduct(brand, crop, tech, status, company);
		saveOrUpdate(product);
		
		return product;
		
	}
	


	/**
	 * Create a new product
	 * 
	 * @param status
	 * @param crop
	 * @param brand
	 * @param tech
	 * @param company TODO
	 * @return Product
	 */
	public Product createProduct(StatusEnum status, Crop crop, Brand brand, Technology tech, Company company) {
		Product product = ProductTestData.createProduct(brand, crop, tech, status, company);
		saveOrUpdate(product);
		return product;
	}
	
	/**
	 * Create a new state
	 * @return State
	 */
	public State createStateByCountry(Country country){
		State s = super.createStateByCountry(country);
		saveOrUpdate(s);

		return s;
	}
	
	/**
	 * Create a new city
	 * @return City
	 */
	public City createCityByState(State state){
		
		City c = CityTestData.createCityByState(state);
		saveOrUpdate(c);
		
		return c;
	}
	
	/**
	 * Create a new document type by country
	 * @param country
	 * @return DocumentType
	 */
	public DocumentType createDocumentType(Country country){
		DocumentType d = super.createDocumentType(country);
		
		saveOrUpdate(d);
		
		return d;
	}
	
	/**
	 * Create a new country
	 * @return Country
	 */
	public Country createBasicCountry(){
		
		Country c = super.createBasicCountry();
		saveOrUpdate(c);
		return c;
	}
	
	public Country createCountryWithStates(){
		
		Country c = super.createCountryWithStates();
		saveOrUpdate(c);
		return c;
	}
	
	/**
	 * Create a new country associated with company
	 */
	public Country createCountryByCompany(Company company){
		Country c = super.createCountryByCompany(company);
		saveOrUpdate(c);
		return c;
	}
	
	private void saveOrUpdate(Object  obj){
		sessionFactory.getCurrentSession().saveOrUpdate(obj);
	}

}
