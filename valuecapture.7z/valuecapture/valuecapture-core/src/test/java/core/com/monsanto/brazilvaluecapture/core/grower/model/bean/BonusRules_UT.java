package com.monsanto.brazilvaluecapture.core.grower.model.bean;

import com.google.common.collect.Lists;
import org.joda.time.DateTime;
import org.junit.Test;

import java.util.Date;
import java.util.List;

import static org.fest.assertions.Assertions.assertThat;

public class BonusRules_UT {

    @Test
    public void testGetBonusRuleValueForServiceFeeReturnsNull_whenThereIsNoBonusRulesValues() {
        //@Given
        BonusRules bonusRules = new BonusRules();
        List<BonusRulesValue> bonusRulesValues = Lists.newArrayList();
        bonusRules.setBonusRulesValues(bonusRulesValues);
        //@When
        BonusRulesValue actual = bonusRules.getBonusRuleValueForServiceFee(buildDate(2014, 10, 4));
        //@Then
        assertThat(actual).isNull();
    }

    @Test
    public void testGetBonusRuleValueForServiceFeeReturnsNull_whenBonusRulesValuesIsNull() {
        //@Given
        BonusRules bonusRules = new BonusRules();
        //@When
        BonusRulesValue actual = bonusRules.getBonusRuleValueForServiceFee(buildDate(2014, 10, 4));
        //@Then
        assertThat(actual).isNull();
    }

    @Test
    public void testGetBonusRuleValueForServiceFeeReturnsNull_whenConsumptionDateIsNull() {
        //@Given
        BonusRules bonusRules = new BonusRules();
        BonusRulesValue bonusRulesValue = buildBonusRuleValue(buildDate(2014, 10, 3), buildDate(2014, 10, 5));
        List<BonusRulesValue> bonusRulesValues = Lists.newArrayList(bonusRulesValue);
        bonusRules.setBonusRulesValues(bonusRulesValues);
        //@When
        BonusRulesValue actual = bonusRules.getBonusRuleValueForServiceFee(null);
        //@Then
        assertThat(actual).isNull();
    }

    @Test
    public void testGetBonusRuleValueForServiceFeeReturnsBonusRuleValue01012014_31012014_whenConsumptionDateIs05012014IsIncludedInRange() {
        //@Given
        BonusRules bonusRules = new BonusRules();
        BonusRulesValue bonusRulesValue = buildBonusRuleValue(buildDate(2014, 1, 1), buildDate(2014, 1, 31));
        List<BonusRulesValue> bonusRulesValues = Lists.newArrayList(bonusRulesValue);
        bonusRules.setBonusRulesValues(bonusRulesValues);
        //@When
        BonusRulesValue actual = bonusRules.getBonusRuleValueForServiceFee(buildDate(2014, 1, 5));
        //@Then
        assertThat(actual).isEqualTo(bonusRulesValue);
    }

    @Test
    public void testGetBonusRuleValueForServiceFeeReturnsBonusRuleValue01032014_30042014_whenConsumptionDateIs05012014IsIncludedInRange() {
        //@Given
        BonusRules bonusRules = new BonusRules();
        BonusRulesValue bonusRulesValue1 = buildBonusRuleValue(buildDate(2014, 1, 1), buildDate(2014, 2, 28));
        BonusRulesValue bonusRulesValue2 = buildBonusRuleValue(buildDate(2014, 3, 1), buildDate(2014, 4, 30));
        List<BonusRulesValue> bonusRulesValues = Lists.newArrayList(bonusRulesValue1, bonusRulesValue2);
        bonusRules.setBonusRulesValues(bonusRulesValues);
        //@When
        BonusRulesValue actual = bonusRules.getBonusRuleValueForServiceFee(buildDate(2014, 3, 21));
        //@Then
        assertThat(actual).isEqualTo(bonusRulesValue2);
    }

    @Test
    public void testGetBonusRuleValueForServiceFeeReturnsThePreviousBonusRuleValue01042014_31052014_whenConsumptionDateIs20062014IsIsAfterAllRanges() {
        //@Given
        BonusRules bonusRules = new BonusRules();
        BonusRulesValue bonusRulesValue1 = buildBonusRuleValue(buildDate(2014, 2, 1), buildDate(2014, 3, 31));
        BonusRulesValue bonusRulesValue2 = buildBonusRuleValue(buildDate(2014, 4, 1), buildDate(2014, 5, 31));
        List<BonusRulesValue> bonusRulesValues = Lists.newArrayList(bonusRulesValue1, bonusRulesValue2);
        bonusRules.setBonusRulesValues(bonusRulesValues);
        //@When
        BonusRulesValue actual = bonusRules.getBonusRuleValueForServiceFee(buildDate(2014, 6, 20));
        //@Then
        assertThat(actual).isEqualTo(bonusRulesValue2);
    }

    @Test
    public void testGetBonusRuleValueForServiceFeeReturnsTheNextBonusRuleValue01022014_31032014_whenConsumptionDateIs05012014IsBeforeAllRanges() {
        //@Given
        BonusRules bonusRules = new BonusRules();
        BonusRulesValue bonusRulesValue1 = buildBonusRuleValue(buildDate(2014, 2, 1), buildDate(2014, 3, 31));
        BonusRulesValue bonusRulesValue2 = buildBonusRuleValue(buildDate(2014, 4, 1), buildDate(2014, 5, 31));
        List<BonusRulesValue> bonusRulesValues = Lists.newArrayList(bonusRulesValue1, bonusRulesValue2);
        bonusRules.setBonusRulesValues(bonusRulesValues);
        //@When
        BonusRulesValue actual = bonusRules.getBonusRuleValueForServiceFee(buildDate(2014, 1, 5));
        //@Then
        assertThat(actual).isEqualTo(bonusRulesValue1);
    }

    @Test
    public void testGetBonusRuleValueForServiceFeeReturnsThePreviousBonusRuleValue01042014_31052014_whenConsumptionDateIs20062014HasPreviousAndNextRanges() {
        //@Given
        BonusRules bonusRules = new BonusRules();
        BonusRulesValue bonusRulesValue1 = buildBonusRuleValue(buildDate(2014, 2, 1), buildDate(2014, 3, 31));
        BonusRulesValue bonusRulesValue2 = buildBonusRuleValue(buildDate(2014, 4, 1), buildDate(2014, 5, 31));
        BonusRulesValue bonusRulesValue3 = buildBonusRuleValue(buildDate(2014, 9, 1), buildDate(2014, 12, 31));
        List<BonusRulesValue> bonusRulesValues = Lists.newArrayList(bonusRulesValue1, bonusRulesValue2, bonusRulesValue3);
        bonusRules.setBonusRulesValues(bonusRulesValues);
        //@When
        BonusRulesValue actual = bonusRules.getBonusRuleValueForServiceFee(buildDate(2014, 6, 20));
        //@Then
        assertThat(actual).isEqualTo(bonusRulesValue2);
    }

    private Date buildDate(int year, int month, int day) {
        return new DateTime().withYear(year).withMonthOfYear(month).withDayOfMonth(day).toDate();
    }

    private BonusRulesValue buildBonusRuleValue(Date dateFrom, Date dateTo) {
        BonusRulesValue bonusRulesValue = new BonusRulesValue();
        bonusRulesValue.setFrom(dateFrom);
        bonusRulesValue.setTo(dateTo);
        return bonusRulesValue;
    }

}