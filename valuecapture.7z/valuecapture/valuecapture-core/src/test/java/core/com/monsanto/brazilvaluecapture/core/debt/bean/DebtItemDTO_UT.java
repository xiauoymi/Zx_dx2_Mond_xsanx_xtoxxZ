package com.monsanto.brazilvaluecapture.core.debt.bean;

import com.google.common.base.Strings;
import com.google.common.collect.Iterables;
import org.junit.Before;
import org.junit.Test;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import static org.fest.assertions.Assertions.assertThat;

/**
 * Created by IntelliJ IDEA.
 * User: ASEQU
 * Date: 6/11/13
 * Time: 9:10 AM
 * To change this template use File | Settings | File Templates.
 */
public class DebtItemDTO_UT {

    private static final String DATE_PATTERN = "yyyy-MM-dd";

    @Before
    public void setUp() throws Exception {

    }

    @Test
    public void testDefaultConstructor_WhenObjectIsInstantiateWithTheDefaultConstructorThenInputDateIsSetWithCurrentDate() {

        SimpleDateFormat ft = new SimpleDateFormat(DATE_PATTERN);
        Date today = new Date();

        DebtItemDTO header = new DebtItemDTO();

        assertThat(ft.format(header.getImputationDate())).isEqualTo(ft.format(today));
    }

    @Test
    public void testDefaultConstructor_WhenObjectIsInstantiateWithTheDefaultConstructorThenAmountDateOneIsSetWithCurrentDate() {

        SimpleDateFormat ft = new SimpleDateFormat(DATE_PATTERN);
        Date today = new Date();

        DebtItemDTO header = new DebtItemDTO();

        assertThat(ft.format(header.getAmountDateOne())).isEqualTo(ft.format(today));
    }

    @Test
    public void testDefaultConstructor_WhenObjectIsInstantiateDefaultAttributesInformationIsLoad() {

        DebtItemDTO header = new DebtItemDTO();

        assertThat(header.getAmountTwo()).isNotEmpty();
        assertThat(header.getAmountDateTwo()).isNotEmpty();
        assertThat(header.getAmountThree()).isNotEmpty();
        assertThat(header.getAmountDateThree()).isNotEmpty();
        assertThat(header.getIndentDebt()).isNotEmpty();
        assertThat(header.getArea()).isNotEmpty();
        assertThat(header.getAreaName()).isNotEmpty();
        assertThat(header.getTextThree()).isNotEmpty();
        assertThat(header.getTextFour()).isNotEmpty();
        assertThat(header.getTextFive()).isNotEmpty();
        assertThat(header.getTextSix()).isNotEmpty();
        assertThat(header.getTextSeven()).isNotEmpty();
        assertThat(header.getTextEight()).isNotEmpty();
        assertThat(header.getTextNine()).isNotEmpty();
        assertThat(header.getTextTen()).isNotEmpty();
    }
}
