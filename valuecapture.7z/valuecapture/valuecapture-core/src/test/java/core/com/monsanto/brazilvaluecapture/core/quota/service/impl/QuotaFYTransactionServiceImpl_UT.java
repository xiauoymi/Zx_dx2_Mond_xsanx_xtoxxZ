package com.monsanto.brazilvaluecapture.core.quota.service.impl;

import com.google.common.collect.Lists;
import com.monsanto.brazilvaluecapture.core.quota.model.bean.DeliveryQuotaFY;
import com.monsanto.brazilvaluecapture.core.quota.model.bean.QuotaFY;
import com.monsanto.brazilvaluecapture.core.quota.model.bean.QuotaFYTransaction;
import com.monsanto.brazilvaluecapture.core.quota.model.dao.QuotaFYTransactionDAO;
import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

import static org.fest.assertions.Assertions.assertThat;
import static org.fest.reflect.core.Reflection.field;
import static org.mockito.Matchers.same;
import static org.mockito.Mockito.*;

/**
 * User: PPERA
 * Date: 6/20/13
 * Time: 12:30 PM
 */
public class QuotaFYTransactionServiceImpl_UT {
    private QuotaFYTransactionServiceImpl quotaFYTransactionServiceImpl;
    private QuotaFYTransactionDAO quotaFYTransactionDAO;

    @Before
    public void setUp() {
        this.quotaFYTransactionServiceImpl = new QuotaFYTransactionServiceImpl();
        this.quotaFYTransactionDAO = mock(QuotaFYTransactionDAO.class);
        field("dao").ofType(QuotaFYTransactionDAO.class).in(this.quotaFYTransactionServiceImpl).set(this.quotaFYTransactionDAO);
    }

    @Test
    public void testGetByDeliveryQuotaFyCallsDaoWithInputDeliveryQuota_WhenGettingTheTransactionsOfInputDeliveryQuota() {
        // @Given a delivery quota
        DeliveryQuotaFY deliveryQuotaFY = new DeliveryQuotaFY();

        // @When getting the transactions
        this.quotaFYTransactionServiceImpl.getByDeliveryQuotaFY(deliveryQuotaFY);

        // @Then dao.selectByDeliveryQuota is called with input delivery quota
        verify(this.quotaFYTransactionDAO).selectByDeliveryQuotaFY(same(deliveryQuotaFY));
    }

    @Test
    public void testGetByDeliveryQuotaFyReturnsDaoResult_WhenGettingTheTransactionsOfInputDeliveryQuota() {
        // @Given a delivery quota
        DeliveryQuotaFY deliveryQuotaFY = new DeliveryQuotaFY();
        when(this.quotaFYTransactionDAO.selectByDeliveryQuotaFY(deliveryQuotaFY)).thenReturn(Lists.<QuotaFYTransaction>newArrayList());

        // @When getting the transactions
        List<QuotaFYTransaction> result = this.quotaFYTransactionServiceImpl.getByDeliveryQuotaFY(deliveryQuotaFY);

        // @Then dao.selectByDeliveryQuota is called with input delivery quota
        assertThat(result).isSameAs(this.quotaFYTransactionDAO.selectByDeliveryQuotaFY(deliveryQuotaFY));
    }

    //===========================

    @Test
    public void testGetByDeliveryQuotaFysCallsDaoWithInputDeliveryQuotas_WhenGettingTheTransactionsOfInputDeliveryQuotas() {
        // @Given a delivery quota
        DeliveryQuotaFY deliveryQuotaFY = new DeliveryQuotaFY();
        List<DeliveryQuotaFY> deliveryQuotaFYList = Lists.newArrayList(deliveryQuotaFY);

        // @When getting the transactions
        this.quotaFYTransactionServiceImpl.getByDeliveryQuotaFYs(deliveryQuotaFYList);

        // @Then dao.selectByDeliveryQuota is called with input delivery quota
        verify(this.quotaFYTransactionDAO).selectByDeliveryQuotaFYs(same(deliveryQuotaFYList));
    }

    @Test
    public void testGetByDeliveryQuotaFysReturnsDaoResult_WhenGettingTheTransactionsOfInputDeliveryQuotas() {
        // @Given a delivery quota
        DeliveryQuotaFY deliveryQuotaFY = new DeliveryQuotaFY();
         List<DeliveryQuotaFY> deliveryQuotaFYList = Lists.newArrayList(deliveryQuotaFY);
        when(this.quotaFYTransactionDAO.selectByDeliveryQuotaFYs(deliveryQuotaFYList)).thenReturn(Lists.<QuotaFYTransaction>newArrayList());

        // @When getting the transactions
        List<QuotaFYTransaction> result = this.quotaFYTransactionServiceImpl.getByDeliveryQuotaFYs(deliveryQuotaFYList);

        // @Then dao.selectByDeliveryQuota is called with input delivery quota
        assertThat(result).isSameAs(this.quotaFYTransactionDAO.selectByDeliveryQuotaFYs(deliveryQuotaFYList));
    }


     //===========================

    @Test
    public void testGetByQuotaFysCallsDaoWithInputQuotas_WhenGettingTheTransactionsOfInputQuotas() {
        // @Given a delivery quota
        QuotaFY quotaFY = new QuotaFY();
        List<QuotaFY> quotaFYList = Lists.newArrayList(quotaFY);

        // @When getting the transactions
        this.quotaFYTransactionServiceImpl.getByQuotaFYs(quotaFYList);

        // @Then dao.selectByQuotaFYs is called with input quota
        verify(this.quotaFYTransactionDAO).selectByQuotaFYs(same(quotaFYList));
    }

    @Test
    public void testGetByQuotaFysReturnsDaoResult_WhenGettingTheTransactionsOfInputQuotas() {
        // @Given a quota
        QuotaFY quotaFY = new QuotaFY();
        List<QuotaFY> quotaFYList = Lists.newArrayList(quotaFY);
        when(this.quotaFYTransactionDAO.selectByQuotaFYs(quotaFYList)).thenReturn(Lists.<QuotaFYTransaction>newArrayList());

        // @When getting the transactions
        List<QuotaFYTransaction> result = this.quotaFYTransactionServiceImpl.getByQuotaFYs(quotaFYList);

        // @Then dao.selectByQuotaFYs is called with input delivery quota
        assertThat(result).isSameAs(this.quotaFYTransactionDAO.selectByQuotaFYs(quotaFYList));
    }
}
