package com.monsanto.brazilvaluecapture.core;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

import com.monsanto.brazilvaluecapture.core.base.Address_UT;
import com.monsanto.brazilvaluecapture.core.base.Country_UT;
import com.monsanto.brazilvaluecapture.core.base.DocumentTypeServiceImpl_UT;
import com.monsanto.brazilvaluecapture.core.base.DocumentType_UT;
import com.monsanto.brazilvaluecapture.core.base.RegionService_AT;
import com.monsanto.brazilvaluecapture.core.foundation.SuiteSystemService;
import com.monsanto.brazilvaluecapture.core.foundation.SystemParameterServiceImpl_UT;
import com.monsanto.brazilvaluecapture.core.foundation.SystemParameterService_AT;
import com.monsanto.brazilvaluecapture.core.foundation.SystemParameter_AT;
import com.monsanto.brazilvaluecapture.core.foundation.SystemParameter_UT;
import com.monsanto.brazilvaluecapture.core.foundation.TypeParameter_UT;
import com.monsanto.brazilvaluecapture.core.grower.GrowerService_AT;
import com.monsanto.brazilvaluecapture.core.grower.Grower_UT;
import com.monsanto.brazilvaluecapture.core.importfile.CsvImportFileService_AT;
import com.monsanto.brazilvaluecapture.core.reminder.model.dao.ReminderDAO_AT;
import com.monsanto.brazilvaluecapture.core.user.UserDecorator_UT;
import com.monsanto.brazilvaluecapture.core.user.User_AT;

@RunWith(value = Suite.class)
@SuiteClasses(value = {
		SuiteCompany.class,
		SuiteSystemService.class,
		Address_UT.class,
		Country_UT.class,
		CsvImportFileService_AT.class,
		DocumentTypeServiceImpl_UT.class,
		DocumentType_UT.class,
		GrowerService_AT.class,
		Grower_UT.class,
		SystemParameterServiceImpl_UT.class,
		SystemParameterService_AT.class,
		SystemParameter_AT.class,
		SystemParameter_UT.class,
		RegionService_AT.class,
		TypeParameter_UT.class,
		UserDecorator_UT.class,
		ReminderDAO_AT.class,
		User_AT.class})
public class SuiteSystem {

	
}
