package com.monsanto.brazilvaluecapture.core.quota.dao;

import com.monsanto.brazilvaluecapture.core.customer.model.bean.Customer;
import com.monsanto.brazilvaluecapture.core.customer.model.dao.CustomerDAO;
import com.monsanto.brazilvaluecapture.core.foundation.service.EntityNotFoundException;
import com.monsanto.brazilvaluecapture.core.foundation.test.AbstractServiceIntegrationTests;
import com.monsanto.brazilvaluecapture.core.foundation.test.dbunit.DbUnitHelper;
import com.monsanto.brazilvaluecapture.core.grower.model.bean.Grower;
import com.monsanto.brazilvaluecapture.core.grower.model.dao.GrowerDAO;
import com.monsanto.brazilvaluecapture.core.quota.model.bean.QuotaFY;
import com.monsanto.brazilvaluecapture.core.quota.model.dao.QuotaFYDAO;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.dao.GermoSupplierLocationDAO;
import com.monsanto.brazilvaluecapture.seedsale.warehouse.model.bean.Warehouse;
import com.monsanto.brazilvaluecapture.seedsale.warehouse.model.dao.WarehouseDAO;
import junit.framework.Assert;
import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.math.BigDecimal;

import static org.junit.Assert.fail;

/**
 * Created by IntelliJ IDEA.
 * User: gavelo
 * Date: 4/9/13
 * Time: 12:27 PM
 * To change this template use File | Settings | File Templates.
 */
public class QuotaFYDAO_AT extends AbstractServiceIntegrationTests {

    @Autowired
    private QuotaFYDAO quotaDAO;

    @Autowired
    private GrowerDAO growerDAO;

    @Autowired
    private CustomerDAO customerDAO;

    @Autowired
    private GermoSupplierLocationDAO germoSupplierLocationDAO;

    @Autowired
    private WarehouseDAO warehouseDAO;

    private Grower grower;
    private Customer customer;
    private Warehouse warehouse;

    private static final String GERMOS = "DON MARIO";
    private static final String COUNTRY_CD = "BR";
    private static final String UNKNOWN_GERMOS = "UNKNOWN_GERMOS";

    @Before
    public void setUp() throws Exception {
        DbUnitHelper.setup("classpath:data/core/basic-fixture.xml", "classpath:data/core/quotaFY-dataset.xml");

        customer = customerDAO.getCustomerById(900000001L);
        grower = growerDAO.selectBy(900000001L);
        warehouse = warehouseDAO.getById(900000001L);

    }

    @Test
    public void testSelectByCustomerDocumentGrowerDocumentAndGermoSupplier() throws Exception{

        QuotaFY  quota = quotaDAO.selectBy(grower.getDocument().getValue(),customer.getDocument().getValue(),GERMOS,COUNTRY_CD);

        Assert.assertNotNull( quota );
        Assert.assertNotNull( quota.getId() );

        Assert.assertEquals(GERMOS,quota.getWarehouse().getDescription());
        Assert.assertEquals(grower.getDocument().getValue(),quota.getGrower().getDocument().getValue());
        Assert.assertEquals(customer.getDocument().getValue(),quota.getCustomer().getDocument().getValue());

    }


   @Test
   public void testSelectByCustomerDocumentGrowerDocumentAndUnknownGermoSupplier() throws Exception{
       try{
           QuotaFY  quota = quotaDAO.selectBy(grower.getDocument().getValue(),customer.getDocument().getValue(),UNKNOWN_GERMOS,COUNTRY_CD);
           fail("Should throw an Exception");
       } catch (EntityNotFoundException e) {

       }
   }


    @Test
    public void testSelectByCustomerDocumentGrowerDocumentAndGermoSupplierWithUnknownCountryCD() throws Exception{
        try{
            QuotaFY  quota = quotaDAO.selectBy(grower.getDocument().getValue(),customer.getDocument().getValue(),GERMOS,"AR");
            fail("Should throw an Exception");
        } catch (EntityNotFoundException e) {

        }
    }

    @Test
    public void testSelectByCustomerDocumentGrowerDocumentAndGermoSupplierWithUnknownCustomerDocument() throws Exception{
        try {
            QuotaFY  quota = quotaDAO.selectBy("UNKNOWNDOC",customer.getDocument().getValue(),GERMOS,"AR");
            fail("Should throw an Exception");
        } catch (EntityNotFoundException e) {

        }
    }


    @Test
    public void testSelectByCustomerDocumentGrowerDocumentAndGermoSupplierWithUnknownGrowerDoc() throws Exception{
        try {
            QuotaFY  quota = quotaDAO.selectBy(grower.getDocument().getValue(),"UNKNOWNDOC",GERMOS,COUNTRY_CD);
            fail("Should throw an Exception");
        } catch (EntityNotFoundException e) {

        }
    }


    @Test
    public void testSelectByCustomerIdGrowerIdAndGermoSupplier() throws Exception{

        QuotaFY  quota = quotaDAO.selectBy(grower.getId(),customer.getId(),GERMOS);

        Assert.assertNotNull( quota );
        Assert.assertNotNull( quota.getId() );

        Assert.assertEquals(GERMOS,quota.getWarehouse().getDescription());
        Assert.assertEquals(grower.getId(),quota.getGrower().getId());
        Assert.assertEquals(customer.getId(),quota.getCustomer().getId());

    }

    @Test
    public void testSelectByCustomerIdGrowerIdAndUnknownGermoSupplier() throws Exception{
        try {
            QuotaFY  quota = quotaDAO.selectBy(grower.getId(),customer.getId(),UNKNOWN_GERMOS);
            fail("Should throw an Exception");
        } catch (EntityNotFoundException e) {

        }
    }


    @Test
    public void testSelectByUnknownCustomerIdGrowerIdAndUnknownGermoSupplier() throws Exception{
        try{
            QuotaFY  quota = quotaDAO.selectBy(1L,customer.getId(),GERMOS);
            fail("Should throw an Exception");
        } catch (EntityNotFoundException e) {

        }
    }


    @Test
    public void testSelectByCustomerIdUnknownGrowerIdAndUnknownGermoSupplier() throws Exception{
        try{
            QuotaFY  quota = quotaDAO.selectBy(grower.getId(),1L,GERMOS);
            fail("Should throw an Exception");
        } catch (EntityNotFoundException e) {

        }
    }


    @Test
    public void testInsert() {
        QuotaFY quota = createQuotaFY();
        Assert.assertNull(quota.getId());
        quotaDAO.save(quota);
        Assert.assertNotNull( quota.getId() );
    }


    @Test
    public void testMapping() {

        QuotaFY quota = createQuotaFY();
        quotaDAO.save(quota);

        flushObject(quota);

        QuotaFY quotaDb = ( QuotaFY ) getSession().load(QuotaFY.class,quota.getId());

        Assert.assertEquals( quota.getCustomer().getId(), quotaDb.getCustomer().getId());
        Assert.assertEquals( quota.getGrower().getId(), quotaDb.getGrower().getId());
        Assert.assertEquals( quota.getWarehouse().getId(), quotaDb.getWarehouse().getId());
        Assert.assertEquals( quota.getBalance(),quotaDb.getBalance());
    }

    private QuotaFY createQuotaFY() {
        QuotaFY quota = new QuotaFY();

        quota.setBalance(BigDecimal.valueOf(100));
        quota.setDeliveryBalance(BigDecimal.valueOf(100));
        quota.setCustomer(customer);
        quota.setGrower(grower);
        quota.setWarehouse(warehouse);

        return quota;
    }

}