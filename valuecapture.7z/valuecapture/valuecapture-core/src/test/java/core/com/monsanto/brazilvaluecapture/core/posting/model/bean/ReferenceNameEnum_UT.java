package com.monsanto.brazilvaluecapture.core.posting.model.bean;

import com.monsanto.brazilvaluecapture.core.presentation.beans.ResourceBundleTestHelper;
import org.junit.Test;

import static org.fest.assertions.Assertions.assertThat;

public class ReferenceNameEnum_UT {
    @Test
    public void referenceNameEnumROYALTIES_REV_REC_isTranslated() {
        final String label = ReferenceNameEnum.ROYALTIES_REVENUE_RECOGNITION.getLabel();

        ResourceBundleTestHelper.assertLanguageStrExistsForUS(new String[]{label});
        ResourceBundleTestHelper.assertLanguageStrExistsForBrazil(new String[]{label});
    }

    @Test
    public void referenceNameEnumREVERT_ROYALTIES_REV_REC_isTranslated() {
        final String label = ReferenceNameEnum.REVERSAL_ROYALTIES_REVENUE_RECOGNITION.getLabel();

        ResourceBundleTestHelper.assertLanguageStrExistsForUS(new String[]{label});
        ResourceBundleTestHelper.assertLanguageStrExistsForBrazil(new String[]{label});
    }

    @Test
    public void referenceNameEnumBILLING_GT_REV_REC_isTranslated() {
        final String label = ReferenceNameEnum.REVERT_BILLING_GT_REVENUE_RECOGNITION.getLabel();

        ResourceBundleTestHelper.assertLanguageStrExistsForUS(new String[]{label});
        ResourceBundleTestHelper.assertLanguageStrExistsForBrazil(new String[]{label});
    }

    @Test
    public void referenceNameEnumADJUST_CASH_GT_REV_REC_isTranslated() {
        final String label = ReferenceNameEnum.ADJUST_CASH_GT_REVENUE_RECOGNITION.getLabel();

        ResourceBundleTestHelper.assertLanguageStrExistsForUS(new String[]{label});
        ResourceBundleTestHelper.assertLanguageStrExistsForBrazil(new String[]{label});
    }

    @Test
    public void referenceNameEnumREVERT_BILLING_GT_REV_REC_isTranslated() {
        final String label = ReferenceNameEnum.REVERT_BILLING_GT_REVENUE_RECOGNITION.getLabel();

        ResourceBundleTestHelper.assertLanguageStrExistsForUS(new String[]{label});
        ResourceBundleTestHelper.assertLanguageStrExistsForBrazil(new String[]{label});
    }

    @Test
    public void referenceNameEnumREVERT_CASH_GT_REV_REC_isTranslated() {
        final String label = ReferenceNameEnum.REVERT_CASH_GT_REVENUE_RECOGNITION.getLabel();

        ResourceBundleTestHelper.assertLanguageStrExistsForUS(new String[]{label});
        ResourceBundleTestHelper.assertLanguageStrExistsForBrazil(new String[]{label});
    }

    @Test
    public void testROYALTIES_REVENUE_RECOGNITION_ErpCodeIs_RoyaltiesRevenueRecognition() {
        assertThat(ReferenceNameEnum.ROYALTIES_REVENUE_RECOGNITION.getErpCode()).isEqualTo("ROYALTIES REVENUE RECOGNITION");
    }

    @Test
    public void testVALUE_SHARE_ErpCodeIsVALUE_SHARE() {
        assertThat(ReferenceNameEnum.VALUE_SHARE.getErpCode()).isEqualTo("VALUE SHARE");
    }

    @Test
    public void testREVERT_BILLING_GT_REVENUE_RECOGNITION_ErpCodeIsReverBilLargerThanRevRecog() {
        assertThat(ReferenceNameEnum.REVERT_BILLING_GT_REVENUE_RECOGNITION.getErpCode()).isEqualTo("REVER.BIL.LARGER THAN REV.REC");
    }

    @Test
    public void testREVERT_CASH_GT_REVENUE_RECOGNITION_ErpCodeIsAdjustCashLargerThanRev() {
        assertThat(ReferenceNameEnum.REVERT_CASH_GT_REVENUE_RECOGNITION.getErpCode()).isEqualTo("REVERS.CASH LARGER THAN REV.");
    }

    @Test
    public void testADJUST_CASH_GT_REVENUE_RECOGNITION_ErpCodeIsAdjustCashLargerThanRev() {
        assertThat(ReferenceNameEnum.ADJUST_CASH_GT_REVENUE_RECOGNITION.getErpCode()).isEqualTo("ADJUST.CASH LARGER THAN REV.");
    }

    @Test
    public void testREVERSAL_ROYALTIES_REVENUE_RECOGNITION_ErpCodeIsReversalRoyaltiesRevRecog() {
        assertThat(ReferenceNameEnum.REVERSAL_ROYALTIES_REVENUE_RECOGNITION.getErpCode()).isEqualTo("REVERSAL ROYALTIES REV.RECOG .");
    }

    @Test
    public void testBILLING_LARGER_THAN_REVENUE_RECOGNITION_ErpCodeIsBillingLargerThanRevRecog() {
        assertThat(ReferenceNameEnum.BILLING_LARGER_THAN_REVENUE_RECOGNITION.getErpCode()).isEqualTo("BILLING LARGER THAN REV.RECOG");
    }

}