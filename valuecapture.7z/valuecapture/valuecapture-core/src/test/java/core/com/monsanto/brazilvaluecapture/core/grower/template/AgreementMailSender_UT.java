package com.monsanto.brazilvaluecapture.core.grower.template;

import com.monsanto.brazilvaluecapture.core.foundation.util.mail.MailManager;
import com.monsanto.brazilvaluecapture.core.foundation.util.mail.ParseTemplateException;
import com.monsanto.brazilvaluecapture.core.foundation.util.mail.SendMailFailedException;
import com.monsanto.brazilvaluecapture.core.regionalization.CountriesHolder;
import com.monsanto.brazilvaluecapture.core.regionalization.VCCountry;
import org.junit.Test;
import java.util.Map;
import org.mockito.ArgumentMatcher;
import org.mockito.Mockito;
import static org.fest.assertions.Assertions.assertThat;
import static org.fest.reflect.core.Reflection.field;
import static org.mockito.Matchers.anyBoolean;
import static org.mockito.Matchers.anyString;
import static org.mockito.Matchers.argThat;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/**
 * Created with IntelliJ IDEA.
 * User: HGFIOR
 * Date: 21/11/13
 * Time: 12:39
 * To change this template use File | Settings | File Templates.
 */
public class AgreementMailSender_UT {

    @Test
    public void sendToApprovalAgreementTest() throws ParseTemplateException, SendMailFailedException {

        // @Given a mail template and a body containing "dummy content"
        AgreementMailSender mailSender = new AgreementMailSender();
        mailSender.setMailBody("dummy content");
        MailManager mailManager = Mockito.mock(MailManager.class);
        CountriesHolder countriesHolder = Mockito.mock(CountriesHolder.class);
        when(countriesHolder.getCountry()).thenReturn(VCCountry.ARGENTINA);
        field("countriesHolder").ofType(CountriesHolder.class).in(mailSender).set(countriesHolder);
        field("mailManager").ofType(MailManager.class).in(mailSender).set(mailManager);

        // @When sending the agreement mail
        mailSender.sendAgreementMail();

        // @Then the variables contain a "mailBody" with "dummy content"
        verify(mailManager).sendMimeMail(anyString(), anyString(), anyString(), argThat(new ArgumentMatcher<Map<String, Object>>() {
            @Override
            public boolean matches(Object argument) {
                return argument instanceof Map && "dummy content".equals(((Map) argument).get("mailBody"));

            }
        }), anyString(), anyBoolean());




    }
}
