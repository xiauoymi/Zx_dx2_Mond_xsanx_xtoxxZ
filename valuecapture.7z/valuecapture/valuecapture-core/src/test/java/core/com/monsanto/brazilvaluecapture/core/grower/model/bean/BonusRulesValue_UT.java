package com.monsanto.brazilvaluecapture.core.grower.model.bean;

import com.google.common.collect.Lists;
import org.joda.time.DateTime;
import org.junit.Test;

import java.util.Collections;
import java.util.Date;
import java.util.List;

import static org.fest.assertions.Assertions.assertThat;

public class BonusRulesValue_UT {

    @Test
    public void testOnSortACollectionOfBonusRulesValue1() {
        //@Given
        Date from1 = buildDate(2014, 1, 1);
        Date to1 = buildDate(2014, 2, 28);
        Date from2 = buildDate(2014, 1, 1);
        Date to2 = buildDate(2014, 4, 30);
        BonusRulesValue bonusRulesValue1 = buildBonusRuleValue(from1, to1);
        BonusRulesValue bonusRulesValue2 = buildBonusRuleValue(from2, to2);
        List<BonusRulesValue> bonusRulesValues = Lists.newArrayList(bonusRulesValue2, bonusRulesValue1);
        //@When
        Collections.sort(bonusRulesValues);
        //@Then
        assertThat(bonusRulesValues).containsSequence(bonusRulesValue1, bonusRulesValue2);
    }

    @Test
    public void testOnSortACollectionOfBonusRulesValue2() {
        //@Given
        Date from1 = buildDate(2014, 1, 1);
        Date to1 = buildDate(2014, 2, 28);
        Date from2 = buildDate(2014, 2, 1);
        Date to2 = buildDate(2014, 4, 30);
        BonusRulesValue bonusRulesValue1 = buildBonusRuleValue(from1, to1);
        BonusRulesValue bonusRulesValue2 = buildBonusRuleValue(from2, to2);
        List<BonusRulesValue> bonusRulesValues = Lists.newArrayList(bonusRulesValue2, bonusRulesValue1);
        //@When
        Collections.sort(bonusRulesValues);
        //@Then
        assertThat(bonusRulesValues).containsSequence(bonusRulesValue1, bonusRulesValue2);
    }

    private Date buildDate(int year, int month, int day) {
        return new DateTime().withYear(year).withMonthOfYear(month).withDayOfMonth(day).toDate();
    }

    private BonusRulesValue buildBonusRuleValue(Date dateFrom, Date dateTo) {
        BonusRulesValue bonusRulesValue = new BonusRulesValue();
        bonusRulesValue.setFrom(dateFrom);
        bonusRulesValue.setTo(dateTo);
        return bonusRulesValue;
    }

}