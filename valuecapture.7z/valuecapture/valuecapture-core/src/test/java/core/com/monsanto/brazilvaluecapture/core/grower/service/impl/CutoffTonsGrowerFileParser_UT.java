package com.monsanto.brazilvaluecapture.core.grower.service.impl;

import static org.fest.reflect.core.Reflection.field;
import static org.junit.Assert.fail;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.when;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.ResourceBundle;

import junit.framework.Assert;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.monsanto.brazilvaluecapture.core.base.model.bean.Country;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Document;
import com.monsanto.brazilvaluecapture.core.base.model.bean.DocumentType;
import com.monsanto.brazilvaluecapture.core.base.model.dao.DocumentTypeDAO;
import com.monsanto.brazilvaluecapture.core.base.service.BaseService;
import com.monsanto.brazilvaluecapture.core.foundation.util.ConstraintViolation;
import com.monsanto.brazilvaluecapture.core.foundation.util.csv.CSVReadableInvalidException;
import com.monsanto.brazilvaluecapture.core.foundation.util.parser.ParsedLineResult;
import com.monsanto.brazilvaluecapture.core.grower.model.bean.Grower;
import com.monsanto.brazilvaluecapture.core.grower.model.dao.GrowerDAO;
import com.monsanto.brazilvaluecapture.core.grower.service.GrowerNotFoundException;
import com.monsanto.brazilvaluecapture.core.grower.validation.CutoffTonsGrowerConstraintViolationException;
import com.monsanto.brazilvaluecapture.core.grower.validation.CutoffTonsGrowerFieldsValidationRule;
import com.monsanto.brazilvaluecapture.core.grower.validation.CutoffTonsGrowerMaxAmountTonsValidationRule;
import com.monsanto.brazilvaluecapture.core.grower.validation.CutoffTonsValidator;
import com.monsanto.brazilvaluecapture.seedsale.cutoffTons.service.CutoffTonsService;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.CutOffTonsGrower;
import com.monsanto.brazilvaluecapture.seedsale.template.model.bean.SaleTemplate;

public class CutoffTonsGrowerFileParser_UT {
	
	@Mock
	private CutoffTonsValidator cutoffTonsValidatorValidatorThrowsExceptionValidat;
	
	private CutoffTonsValidator cutoffTonsValidator;
	
	@Mock
	private ResourceBundle resourceBundle;
	
	@Mock
	private BaseService baseService;
	
	@Mock
	private CutoffTonsService cutoffTonsService; 
	
	@Mock
	private DocumentTypeDAO documentTypeDao; 
	
	@InjectMocks
	private CutoffTonsGrowerLimitFileParser validFileParser;
	
	@InjectMocks
    private CutoffTonsGrowerLimitFileParser invalidFileParser;
	
	@Mock
	private GrowerDAO growerDAO;

	private CutoffTonsGrowerMaxAmountTonsValidationRule cutoffTonsGrowerMaxAmountTonsValidationRule;
	private CutoffTonsGrowerFieldsValidationRule cutoffTonsGrowerFieldsValidationRule;
	
	private Country country;
	
	private Locale locale;
	
	private SaleTemplate saleTemplate;

	private List<ParsedLineResult> warnings = new ArrayList<ParsedLineResult>() ;

	
	private final static String SEPARATOR=";";

	private static final String DOCUMENTO_PRODUCTOR = "20040629441";

	private static final String NOMBRE_PRODUCTOR = "ROPPER JULIAN";

	private static final String TONELADAS_PAGAS = "77.332";

	private static final String TOPE_TONELADAS = "19.333";
	
	@Before
	public void setUp() throws CutoffTonsGrowerConstraintViolationException, IOException {

		MockitoAnnotations.initMocks(this);

		List<ConstraintViolation> constraintViolations = new ArrayList<ConstraintViolation>();
		constraintViolations
				.add(new ConstraintViolation("msg", "code", "field"));

		doThrow(
				new CutoffTonsGrowerConstraintViolationException("",
						constraintViolations)).when(
								cutoffTonsValidatorValidatorThrowsExceptionValidat).validate(
				Matchers.<CutOffTonsGrower> any());

		locale = new Locale("ar", "AR");
		country = new Country("ar", "AR");
		cutoffTonsValidator = new CutoffTonsValidator();
		saleTemplate = new SaleTemplate();
		
		
		
		cutoffTonsGrowerMaxAmountTonsValidationRule = new CutoffTonsGrowerMaxAmountTonsValidationRule();
		field("cutoffTonsService").ofType(CutoffTonsService.class).in(cutoffTonsGrowerMaxAmountTonsValidationRule).set(cutoffTonsService);
		field("cutoffTonsGrowerMaxAmountTonsValidationRule").ofType(CutoffTonsGrowerMaxAmountTonsValidationRule.class).in(cutoffTonsValidator).set(cutoffTonsGrowerMaxAmountTonsValidationRule);
        
		cutoffTonsGrowerFieldsValidationRule = new CutoffTonsGrowerFieldsValidationRule();
        field("cutoffTonsGrowerFieldsValidationRule").ofType(CutoffTonsGrowerFieldsValidationRule.class).in(cutoffTonsValidator).set(cutoffTonsGrowerFieldsValidationRule);
		 cutoffTonsValidator.createRules();
		
		 doNothing().when(cutoffTonsService).save(any(List.class));
		 validFileParser = new CutoffTonsGrowerLimitFileParser(resourceBundle, "test",createValidInputStream(),locale, "User", country,
				 								cutoffTonsValidator,saleTemplate, cutoffTonsService, growerDAO);
		 								            
		
		 invalidFileParser = new CutoffTonsGrowerLimitFileParser(resourceBundle, "test",createInValidInputStream(),locale, "User", country,
					cutoffTonsValidator,saleTemplate, cutoffTonsService,growerDAO);
		 field("warnings").ofType(List.class).in(this.invalidFileParser).set(warnings);
		 

	}
	
	private InputStream createValidInputStream() throws IOException {
        ByteArrayOutputStream outputStream=new ByteArrayOutputStream();
        
        StringBuilder header=new StringBuilder("DOCUMENTO_PRODUCTOR").append(SEPARATOR).append("NOMBRE_PRODUCTOR").append(SEPARATOR).append("TONELADAS_PAGAS");
        header.append(SEPARATOR).append("TOPE_TONELADAS\n");

        StringBuilder line=new StringBuilder(DOCUMENTO_PRODUCTOR).append(SEPARATOR).append(NOMBRE_PRODUCTOR).append(SEPARATOR);
        line.append(TONELADAS_PAGAS).append(SEPARATOR);
        line.append(TOPE_TONELADAS);

        outputStream.write(header.toString().getBytes());
        outputStream.write(line.toString().getBytes());

        InputStream inputStream = new ByteArrayInputStream(outputStream.toByteArray());
        outputStream.close();
        return inputStream;
}
	 private InputStream createInValidInputStream() throws IOException {
	        ByteArrayOutputStream outputStream=new ByteArrayOutputStream();

	        StringBuilder header=new StringBuilder("DOCUMENTO_PRODUCTOR").append(SEPARATOR).append("NOMBRE_PRODUCTOR").append(SEPARATOR).append("TONELADAS_PAGAS");
	        header.append(SEPARATOR).append("TOPE_TONELADAS\n");

	        StringBuilder line=new StringBuilder(DOCUMENTO_PRODUCTOR).append(SEPARATOR).append(NOMBRE_PRODUCTOR).append(SEPARATOR);
	        line.append(TONELADAS_PAGAS).append(SEPARATOR);
	        line.append("-5");

	        outputStream.write(header.toString().getBytes());
	        outputStream.write(line.toString().getBytes());

	        InputStream inputStream = new ByteArrayInputStream(outputStream.toByteArray());
	        outputStream.close();
	        return inputStream;
	}
	 
	 @Test
	    public void read_ShouldAddWarnings_WhenFileHasInvalidRecords() throws GrowerNotFoundException{

	        try {
	        	Grower grower = new Grower();
	        	grower.setId(1L);
	        	Document document = new Document(new DocumentType(),"22123446");
				grower.setDocument(document );
				when(growerDAO.selectBy(anyString(), anyString())).thenReturn(grower);
	            invalidFileParser.readFile();
	            invalidFileParser.process();

	            Assert.assertEquals(1, invalidFileParser.getErrorLines());
	            Assert.assertEquals(0,invalidFileParser.getSuccessLines());

	        } catch (CSVReadableInvalidException e) {
	            fail();
	        }
	    }
	 
	 @Test
		public void read_ShouldNotAddWarnings_WhenFileHasInvalidRecords() throws GrowerNotFoundException {

			try {
				Mockito.when(documentTypeDao.selectDocumentTypeByDocumentDescription(Mockito.anyString())).thenReturn(new DocumentType());
				Mockito.when(cutoffTonsService.getConsumedTonsByGrowerAndSaleTemplate(Mockito.any(SaleTemplate.class), Mockito.any(Grower.class))).thenReturn(BigDecimal.ZERO);
				Grower grower = new Grower();
	        	grower.setId(1L);
	        	Document document = new Document(new DocumentType(),"22123446");
				grower.setDocument(document );
				when(growerDAO.selectBy(anyString(), anyString())).thenReturn(grower);
				validFileParser.readFile();
				validFileParser.process();

				Assert.assertEquals(0, validFileParser.getErrorLines());
				Assert.assertEquals(1, validFileParser.getSuccessLines());

			} catch (CSVReadableInvalidException e) {
				fail();
			}
		}
	 
	 @Test
		public void read_ShouldNotAddWarnings_CSVInvalidLayoutException() throws IOException, GrowerNotFoundException {

			try {
				Grower grower = new Grower();
	        	grower.setId(1L);
	        	Document document = new Document(new DocumentType(),"22123446");
				grower.setDocument(document );
				when(growerDAO.selectBy(anyString(), anyString())).thenReturn(grower);
				 invalidFileParser = new CutoffTonsGrowerLimitFileParser(resourceBundle, "test",createInValidInputStream(),locale, "User", country,
							cutoffTonsValidator,saleTemplate, cutoffTonsService,growerDAO);

				 invalidFileParser.readFile();
				 invalidFileParser.process();

				Assert.assertEquals(1, invalidFileParser.getWarnings().size());

			} catch (CSVReadableInvalidException e) {
				fail();
			}
		}

}
