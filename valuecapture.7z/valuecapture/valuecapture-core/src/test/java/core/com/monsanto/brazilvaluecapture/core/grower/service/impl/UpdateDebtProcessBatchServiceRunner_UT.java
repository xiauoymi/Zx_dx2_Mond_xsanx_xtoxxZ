package com.monsanto.brazilvaluecapture.core.grower.service.impl;

import java.util.Date;
import java.util.Map;

import com.monsanto.brazilvaluecapture.core.base.service.ServiceRunnerDataService;
import com.monsanto.brazilvaluecapture.core.wsiconsole.bean.WsiServiceInstance;
import com.monsanto.brazilvaluecapture.osb.its.api.InfraException;
import com.monsanto.brazilvaluecapture.osb.its.api.LASVCCreateDebtDocumentService;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import static junit.framework.Assert.*;

/**
 * Unit test fot the UpdateDebtProcessBatchServiceRunner
 *
 * @author Fdez, Israel
 * @since 3.1.1
 */
@RunWith(MockitoJUnitRunner.class)
public class UpdateDebtProcessBatchServiceRunner_UT {
    private final String SERVICE_URL_PROPERTY = "osb_lasvc_sap_debt_creation_url";
    private final String SAMPLE_CUIT = "someCUIT";
    private final String SAMPLE_PRODUCT = "someProduct";
    private final String SAMPLE_AGREEMENT = "someAgreement";
    private final String SAMPLE_FILE = "someFile";
    private final String SAMPLE_SIGN = "someSign";

    @Mock
    private LASVCCreateDebtDocumentService osbService;
    
    @Mock
    private ServiceRunnerDataService serviceRunnerDataService; 

    @InjectMocks
    UpdateDebtProcessBatchServiceRunner updateDebtProcessBatchServiceRunner;

    @Before
    public void setUp() throws Exception {
    	Mockito.when(serviceRunnerDataService.registerData(Mockito.any(WsiServiceInstance.class), Mockito.anyString(), 
    			Mockito.anyString(), Mockito.anyBoolean(), Mockito.any(Map.class), Mockito.any(Map.class), 
    			Mockito.anyBoolean(), Mockito.any(Date.class), Mockito.any(Date.class))).thenReturn(new WsiServiceInstance());
    }

    @Test
    public void testGetServiceURLProperty() throws Exception {
        String expectedServiceURLProperty = SERVICE_URL_PROPERTY;
        assertEquals(expectedServiceURLProperty, BaseDebtDocumentServiceRunner.getServiceURLProperty());
    }

    @Test
    public void testProperties() {
        String expectedCUIT = "someCUIT";
        updateDebtProcessBatchServiceRunner.setCuit(expectedCUIT);
        assertEquals(expectedCUIT, updateDebtProcessBatchServiceRunner.getCuit());

        String expectedProduct = "someProduct";
        updateDebtProcessBatchServiceRunner.setProduct(expectedProduct);
        assertEquals(expectedProduct, updateDebtProcessBatchServiceRunner.getProduct());

        String expectedAgreement = "someAgreement";
        updateDebtProcessBatchServiceRunner.setAgreement(expectedAgreement);
        assertEquals(expectedAgreement, updateDebtProcessBatchServiceRunner.getAgreement());

        String expectedFile = "someFile";
        updateDebtProcessBatchServiceRunner.setFile(expectedFile);
        assertEquals(expectedFile, updateDebtProcessBatchServiceRunner.getFile());

        String expectedSign = "someSign";
        updateDebtProcessBatchServiceRunner.setSign(expectedSign);
        assertEquals(expectedSign, updateDebtProcessBatchServiceRunner.getSign());
    }

    @Test
    public void testServiceNameInNotNull() {
        assertNotNull(updateDebtProcessBatchServiceRunner.getServiceName());
    }

    @Test
    public void testOperationNameIsNotNull() {
        assertNotNull(updateDebtProcessBatchServiceRunner.getOperationName());
    }

    @Test
    public void testServiceRunnerProperties() {
        assertFalse(updateDebtProcessBatchServiceRunner.getIsRetry());
    }

    @Test
    public void testRunGenerateRequestAndResponseParamenters() throws Exception {
        //@Given a set if valid service invocation parameters
        updateDebtProcessBatchServiceRunner.setCuit(SAMPLE_CUIT);
        updateDebtProcessBatchServiceRunner.setProduct(SAMPLE_PRODUCT);
        updateDebtProcessBatchServiceRunner.setAgreement(SAMPLE_AGREEMENT);
        updateDebtProcessBatchServiceRunner.setFile(SAMPLE_FILE);

        //@When the service invocation occurs with no errors
        Mockito.when(osbService.updateDebtProcessBatch(SAMPLE_CUIT, SAMPLE_PRODUCT, SAMPLE_AGREEMENT,
                SAMPLE_FILE, SAMPLE_SIGN)).thenReturn("SERVICE_RESPONSE");
        updateDebtProcessBatchServiceRunner.run();

        //@Then the service runner stores request and response parameters
        assertTrue(updateDebtProcessBatchServiceRunner.getRequest().containsKey("cuit"));
        assertTrue(updateDebtProcessBatchServiceRunner.getRequest().containsKey("product"));
        assertTrue(updateDebtProcessBatchServiceRunner.getRequest().containsKey("agreement"));
        assertTrue(updateDebtProcessBatchServiceRunner.getResponse().containsKey("response"));
        assertNotNull(updateDebtProcessBatchServiceRunner.getRequestDate());
        assertNotNull(updateDebtProcessBatchServiceRunner.getResponseDate());
    }

    @Test
    public void testRunGenerateRequestAndResponseParamenters_WhenErrorsOccurs() throws Exception {
        //@Given a set if valid service invocation parameters
        updateDebtProcessBatchServiceRunner.setCuit(SAMPLE_CUIT);
        updateDebtProcessBatchServiceRunner.setProduct(SAMPLE_PRODUCT);
        updateDebtProcessBatchServiceRunner.setAgreement(SAMPLE_AGREEMENT);
        updateDebtProcessBatchServiceRunner.setFile(SAMPLE_FILE);
        updateDebtProcessBatchServiceRunner.setSign(SAMPLE_SIGN);

        //@When the service invocation occurs with no errors
        Mockito.when(osbService.updateDebtProcessBatch(SAMPLE_CUIT, SAMPLE_PRODUCT, SAMPLE_AGREEMENT,
                SAMPLE_FILE, SAMPLE_SIGN)).thenThrow(new InfraException());
        try {
            updateDebtProcessBatchServiceRunner.run();
            fail("Service Runner invocation is stubbed to throw an exception");
        } catch (Exception e) {
        }

        //@Then the service runner stores request and response parameters
        assertTrue(updateDebtProcessBatchServiceRunner.getRequest().containsKey("cuit"));
        assertTrue(updateDebtProcessBatchServiceRunner.getRequest().containsKey("product"));
        assertTrue(updateDebtProcessBatchServiceRunner.getRequest().containsKey("agreement"));
        assertTrue(updateDebtProcessBatchServiceRunner.getResponse().containsKey("ERROR_EXCEPTION"));
        assertTrue(updateDebtProcessBatchServiceRunner.getResponse().containsKey("ERROR_EXCEPTION_MESSAGE"));
        assertNotNull(updateDebtProcessBatchServiceRunner.getRequestDate());
        assertNotNull(updateDebtProcessBatchServiceRunner.getResponseDate());
    }

    @Test
    public void testRunStatusIsUpdatedWhenNoError() throws Exception {
        //@Given a set if valid service invocation parameters
        updateDebtProcessBatchServiceRunner.setCuit(SAMPLE_CUIT);
        updateDebtProcessBatchServiceRunner.setProduct(SAMPLE_PRODUCT);
        updateDebtProcessBatchServiceRunner.setAgreement(SAMPLE_AGREEMENT);
        updateDebtProcessBatchServiceRunner.setFile(SAMPLE_FILE);

        //@When the service invocation occurs with no errors
        Mockito.when(osbService.updateDebtProcessBatch(SAMPLE_CUIT, SAMPLE_PRODUCT, SAMPLE_AGREEMENT,
                SAMPLE_FILE, SAMPLE_SIGN)).thenReturn("SERVICE_RESPONSE");
        updateDebtProcessBatchServiceRunner.run();

        //@Then the service runner signals its execution status as Ok
        assertTrue(updateDebtProcessBatchServiceRunner.getStatus());
        assertNotNull(updateDebtProcessBatchServiceRunner.getRequestDate());
        assertNotNull(updateDebtProcessBatchServiceRunner.getResponseDate());
    }

    @Test
    public void testRunStatusIsUpdatedWhenError() throws Exception {
        //@Given a set if valid service invocation parameters
        updateDebtProcessBatchServiceRunner.setCuit(SAMPLE_CUIT);
        updateDebtProcessBatchServiceRunner.setProduct(SAMPLE_PRODUCT);
        updateDebtProcessBatchServiceRunner.setAgreement(SAMPLE_AGREEMENT);
        updateDebtProcessBatchServiceRunner.setFile(SAMPLE_FILE);
        updateDebtProcessBatchServiceRunner.setSign(SAMPLE_SIGN);

        //@When the service invocation occurs with no errors
        Mockito.when(osbService.updateDebtProcessBatch(SAMPLE_CUIT, SAMPLE_PRODUCT, SAMPLE_AGREEMENT,
                SAMPLE_FILE, SAMPLE_SIGN)).thenThrow(new InfraException());
        try {
            updateDebtProcessBatchServiceRunner.run();
            fail("Service Runner invocation is stubbed to throw an exception");
        } catch (Exception e) {
        }

        //@Then the service runner signals its execution status as not Ok
        assertFalse(updateDebtProcessBatchServiceRunner.getStatus());
        assertNotNull(updateDebtProcessBatchServiceRunner.getRequestDate());
        assertNotNull(updateDebtProcessBatchServiceRunner.getResponseDate());
    }
}
