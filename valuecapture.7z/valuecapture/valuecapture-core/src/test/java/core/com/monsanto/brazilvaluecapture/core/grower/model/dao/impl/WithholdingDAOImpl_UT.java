package com.monsanto.brazilvaluecapture.core.grower.model.dao.impl;

import static org.fest.assertions.Assertions.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.when;
import static org.mockito.Mockito.verify;

import org.mockito.Mockito;

import org.hibernate.Criteria;
import org.hibernate.SessionFactory;
import org.hibernate.classic.Session;
import org.hibernate.Query;
import org.junit.Before;
import org.junit.Test;

import com.monsanto.brazilvaluecapture.core.grower.model.bean.Grower;
import com.monsanto.brazilvaluecapture.core.grower.model.bean.Withholding;
import com.monsanto.brazilvaluecapture.core.grower.model.bean.WithholdingAudit;
import com.monsanto.brazilvaluecapture.core.grower.model.dao.WithholdingDAO;

public class WithholdingDAOImpl_UT {

	private Criteria criteria;
	private Session session;
	private WithholdingDAO withholdingDAO;
	private Withholding withholding = mock(Withholding.class);
	private Query query;

	@Before
	public void setUp() throws Exception {
		SessionFactory sessionFactory = mock(SessionFactory.class);
		this.session = mock(Session.class);
		when(sessionFactory.getCurrentSession()).thenReturn(this.session);
		this.withholdingDAO = new WithholdingDAOImpl(sessionFactory);
		this.criteria = mock(Criteria.class);
		this.query = mock(Query.class);
		when(this.session.createCriteria(Withholding.class)).thenReturn(this.criteria);
		when(this.session.createQuery(Mockito.anyString())).thenReturn(query);
	}

	@Test
	public void testSearch() {
		when(this.criteria.uniqueResult()).thenReturn(withholding);
		assertThat(this.withholdingDAO.search(withholding).equals(withholding));
	}
	
	@Test
	public void testSave() {
		this.withholdingDAO.save(withholding);
		verify(this.session,times(1)).saveOrUpdate(Mockito.any());
	}
	
	@Test
	public void testDelete() {
		this.withholdingDAO.delete(withholding);
		verify(this.session,times(1)).delete(Mockito.any());
	}
	
	@Test
	public void testSaveAudit() {
		this.withholdingDAO.saveAudit(Mockito.mock(WithholdingAudit.class));
		verify(this.session,times(1)).save(Mockito.any());
	}
	
	@Test
	public void testGetAll() {
		this.withholdingDAO.getAll();
		verify(this.criteria,times(1)).list();
	}
	
	@Test
	public void testGetPercentajes() {
		this.withholdingDAO.getPercentages();
		verify(this.session,times(1)).createQuery(Mockito.anyString());
	}
	
	@Test
	public void testGetBy() {
		this.withholdingDAO.getBy("", 1);
		verify(this.query,times(1)).list();
	}
	

	@Test
	public void testSearchByGrower() {
		Grower grower = Mockito.mock(Grower.class);
		this.withholdingDAO.searchByGrower(grower );
		verify(this.criteria,times(1)).uniqueResult();
		
	}
}
