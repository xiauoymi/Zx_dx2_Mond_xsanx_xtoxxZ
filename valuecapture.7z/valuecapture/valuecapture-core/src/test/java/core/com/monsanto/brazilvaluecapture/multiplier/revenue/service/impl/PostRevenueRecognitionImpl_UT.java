package com.monsanto.brazilvaluecapture.multiplier.revenue.service.impl;

import com.google.common.collect.Lists;
import com.monsanto.brazilvaluecapture.core.foundation.service.BusinessException;
import com.monsanto.brazilvaluecapture.core.posting.model.bean.ReferenceNameEnum;
import com.monsanto.brazilvaluecapture.core.posting.service.PostingService;
import com.monsanto.brazilvaluecapture.multiplier.revenue.service.PostRevenueRecognition;
import com.monsanto.brazilvaluecapture.multiplier.revenue.service.RevenueRecognitionCalculator;
import com.monsanto.brazilvaluecapture.seedsale.billing.model.bean.PaymentStatus;
import com.monsanto.brazilvaluecapture.seedsale.posting.osb.OsbBonusPostingService;
import com.monsanto.brazilvaluecapture.seedsale.product.model.bean.Product;
import com.monsanto.brazilvaluecapture.seedsale.revenue.model.PostingStatusEnum;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.Sale;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.SaleItem;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.SaleLinkDetail;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.SaleLinkDetailValue;
import com.monsanto.brazilvaluecapture.seedsale.sale.service.impl.ControllershipTestConfigurator;
import com.monsanto.brazilvaluecapture.utils.DateRange;
import com.monsanto.brazilvaluecapture.utils.DateUtils;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import static org.fest.assertions.Assertions.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class PostRevenueRecognitionImpl_UT extends ControllershipTestConfigurator {

    @Captor
    ArgumentCaptor<List<SaleItem>> itemsCaptor;
    private PostingService postingService;
    private RevenueRecognitionCalculator revenueRecognitionCalculator;
    private PostRevenueRecognition postRevenueRecognition;
    private DateRange defaultPeriod = DateUtils.getLastMonthDateRange();

    @Before
    public void setUp() {
        //Needed to use @Captor
        MockitoAnnotations.initMocks(this);
        revenueRecognitionCalculator = mock(RevenueRecognitionCalculator.class);
        postingService = mock(PostingService.class);
        postRevenueRecognition = new PostRevenueRecognitionImpl(postingService, revenueRecognitionCalculator, saleLinkDetailDAO, saleDAO);
        stubRevenueRecognitionCalculatorToReturn(BigDecimal.TEN);
    }

    @Test
    public void testPostRevenueRecognitionInvokesSubmitAndSavePosting_whenFindLinkedSalesInPreviousMonthForRevenueRecognitionWithPaymentStatusNOT_PAIDRetrievesSaleItems() throws BusinessException {
        //@Given
        stubSaleLinkDetailDAO(BigDecimal.valueOf(200));
        stubRevenueRecognitionCalculatorToReturn(BigDecimal.ONE);
        //@When
        postRevenueRecognition.postRevenueRecognition();
        //@Then
        verify(postingService, times(3)).submitAndSaveBonusPosting(any(BigDecimal.class), any(ReferenceNameEnum.class), anyString(), any(Date.class), any(Date.class), anyString());
    }

    @Test
    public void testPostRevenueRecognitionWillPostWithReferenceROYALTIES_REVENUE_RECOGNITION_WhenPaymentStatusIsNOT_PAID() throws BusinessException {
        //@Given
        stubSaleLinkDetailDAO(BigDecimal.valueOf(200));
        stubRevenueRecognitionCalculatorToReturn(BigDecimal.ONE);
        //@When
        postRevenueRecognition.postRevenueRecognition();
        //@Then
        verify(postingService, times(1)).submitAndSaveBonusPosting(any(BigDecimal.class), eq(ReferenceNameEnum.ROYALTIES_REVENUE_RECOGNITION), anyString(), any(Date.class), any(Date.class), anyString());
    }

    @Test
    public void testPostRevenueRecognitionInvokesSubmitAndSavePostingWithReferenceExtendedDescriptionNull_whenFindLinkedSalesInPreviousMonthForRevenueRecognitionWithPaymentStatusNOT_PAIDRetrievesSaleItems() throws BusinessException {
        //@Given
        stubSaleLinkDetailDAO(BigDecimal.valueOf(200));
        stubRevenueRecognitionCalculatorToReturn(BigDecimal.ONE);
        //@When
        postRevenueRecognition.postRevenueRecognition();
        //@Then
        String expectedReferenceExtendedDescription = null;
        verify(postingService, times(3)).submitAndSaveBonusPosting(any(BigDecimal.class), any(ReferenceNameEnum.class), eq(expectedReferenceExtendedDescription), any(Date.class), any(Date.class), anyString());
    }

    @Test
    public void testPostRevenueRecognitionInvokesSubmitAndSavePostingWithDefaultTechnology_whenFindLinkedSalesInPreviousMonthForRevenueRecognitionWithPaymentStatusNOT_PAIDRetrievesSaleItems() throws BusinessException {
        //@Given
        stubSaleLinkDetailDAO(BigDecimal.valueOf(200));
        stubRevenueRecognitionCalculatorToReturn(BigDecimal.ONE);
        //@When
        postRevenueRecognition.postRevenueRecognition();
        //@Then
        verify(postingService, times(3)).submitAndSaveBonusPosting(any(BigDecimal.class), any(ReferenceNameEnum.class), anyString(), any(Date.class), any(Date.class), eq(OsbBonusPostingService.DEFAULT_TECHNOLOGY));
    }

    @Test
    public void testPostRevenueRecognitionPostsWithReferenceROYALTIES_REVENUE_RECOGNITION_WhenPaimentStatusIsFULLY_PAID() throws BusinessException {
        //@Given
        stubSaleLinkDetailDAO(BigDecimal.valueOf(200));
        stubRevenueRecognitionCalculatorToReturn(BigDecimal.ONE);
        //@When
        postRevenueRecognition.postRevenueRecognition();
        //@Then
        verify(postingService, times(1)).submitAndSaveBonusPosting(any(BigDecimal.class), eq(ReferenceNameEnum.REVERT_CASH_GT_REVENUE_RECOGNITION), anyString(), any(Date.class), any(Date.class), anyString());
    }

    @Test
    public void testPostRevenueRecognitionPostWithReferenceExtendedDescriptionNull_whenPaymentStatusFULLY_PAID() throws BusinessException {
        //@Given
        stubSaleLinkDetailDAO(BigDecimal.valueOf(200));
        stubRevenueRecognitionCalculatorToReturn(BigDecimal.ONE);
        //@When
        postRevenueRecognition.postRevenueRecognition();
        //@Then
        String expectedReferenceExtendedDescription = null;
        verify(postingService, times(3)).submitAndSaveBonusPosting(any(BigDecimal.class), any(ReferenceNameEnum.class), eq(expectedReferenceExtendedDescription), any(Date.class), any(Date.class), anyString());
    }

    @Test
    public void testPostRevenueRecognitionInvokesSubmitAndSavePostingWithDefaultTechnology_whenFindLinkedSalesInPreviousMonthForRevenueRecognitionWithPaymentStatusFULLY_PAIDRetrievesSaleItems() throws BusinessException {
        //@Given
        stubSaleLinkDetailDAO(BigDecimal.valueOf(200));
        stubRevenueRecognitionCalculatorToReturn(BigDecimal.ONE);
        //@When
        postRevenueRecognition.postRevenueRecognition();
        //@Then
        verify(postingService, times(3)).submitAndSaveBonusPosting(any(BigDecimal.class), any(ReferenceNameEnum.class), anyString(), any(Date.class), any(Date.class), eq(OsbBonusPostingService.DEFAULT_TECHNOLOGY));
    }

    @Test
    public void testPostRevenueRecognitiontestPostWithReferenceNameREVERT_BILLING_GT_REVENUE_RECOGNITION_whenPaymentStatusBILLED() throws BusinessException {
        //@Given
        SaleLinkDetail saleLinkDetail = stubSaleLinkDetailDAO(BigDecimal.valueOf(200));
        //@When
        postRevenueRecognition.postRevenueRecognition();
        //@Then
        verify(postingService).submitAndSaveBonusPosting(any(BigDecimal.class), eq(ReferenceNameEnum.REVERT_BILLING_GT_REVENUE_RECOGNITION), anyString(), any(Date.class), any(Date.class), anyString());
    }

    @Test
    public void testPostRevenueRecognitionPostWithReferenceExtendedDescriptionNull_whenPaymentStatusBILLED() throws BusinessException {
        //@Given
        stubSaleLinkDetailDAO(BigDecimal.valueOf(200));
        stubRevenueRecognitionCalculatorToReturn(BigDecimal.ONE);
        //@When
        postRevenueRecognition.postRevenueRecognition();
        //@Then
        String expectedReferenceExtendedDescription = null;
        verify(postingService, times(3)).submitAndSaveBonusPosting(any(BigDecimal.class), any(ReferenceNameEnum.class), eq(expectedReferenceExtendedDescription), any(Date.class), any(Date.class), anyString());
    }

    @Test
    public void testPostRevenueRecognitionPostWithDefaultTechnology_whenPaymentStatusBILLED() throws BusinessException {
        //@Given
        stubSaleLinkDetailDAO(BigDecimal.valueOf(200));
        stubRevenueRecognitionCalculatorToReturn(BigDecimal.ONE);
        //@When
        postRevenueRecognition.postRevenueRecognition();
        //@Then
        verify(postingService, times(3)).submitAndSaveBonusPosting(any(BigDecimal.class), any(ReferenceNameEnum.class), anyString(), any(Date.class), any(Date.class), eq(OsbBonusPostingService.DEFAULT_TECHNOLOGY));
    }

    @Test
    public void testPostRevenueRecognitionCalculatesTotalToPostIs1000_whenCollectionHas1ElementWithRevRecOf1000() throws BusinessException {
        //@Given
        SaleLinkDetail saleLinkDetail = stubSaleLinkDetailDAO(BigDecimal.valueOf(5000));
        when(revenueRecognitionCalculator.getRevenueRecognition(saleLinkDetail, defaultPeriod)).thenReturn(BigDecimal.valueOf(1000));
        //@When
        postRevenueRecognition.postRevenueRecognition();
        //@Then
        BigDecimal expectedPostingValue = BigDecimal.valueOf(1000);
        verify(postingService, times(3)).submitAndSaveBonusPosting(
                eq(expectedPostingValue),
                any(ReferenceNameEnum.class),
                anyString(),
                any(Date.class),
                any(Date.class),
                anyString());
    }

    @Test
    public void testPostRevenueRecognitionWillNotPost_WhenExistingRevenueRecognitionIsGreatThanNetRoyaltyValue() throws BusinessException {
        //@Given
        final BigDecimal netRoyaltyValueQuantity = BigDecimal.valueOf(500);
        SaleLinkDetail saleLinkDetail = stubSaleLinkDetailDAO(netRoyaltyValueQuantity);
        final BigDecimal existingRevenueRecognition = BigDecimal.valueOf(1000);
        addExistingPostedSaleLinkDetailValue(saleLinkDetail, existingRevenueRecognition);
        when(revenueRecognitionCalculator.getRevenueRecognition(saleLinkDetail, defaultPeriod)).thenReturn(BigDecimal.valueOf(1000));
        //@When
        postRevenueRecognition.postRevenueRecognition();
        //@Then
        verify(postingService, times(1)).submitAndSaveBonusPosting(
                any(BigDecimal.class),
                eq(ReferenceNameEnum.ROYALTIES_REVENUE_RECOGNITION),
                anyString(),
                any(Date.class),
                any(Date.class),
                anyString());
    }

    private void addExistingPostedSaleLinkDetailValue(SaleLinkDetail saleLinkDetail, BigDecimal existingRevenueRecognition) {
        final SaleItem existingDealerSaleItem = new SaleItem();
        existingDealerSaleItem.setRevenueRecognition(existingRevenueRecognition);
        existingDealerSaleItem.setPostingStatus(PostingStatusEnum.REVENUE_RECOGNITION_POSTED);
        SaleLinkDetailValue exisingSaleLinkgDetailValue = new SaleLinkDetailValue(new Sale(), existingDealerSaleItem, BigDecimal.TEN, saleLinkDetail);
        exisingSaleLinkgDetailValue.setRevenueRecognition(existingRevenueRecognition);
        saleLinkDetail.getSaleLinkDetailValueSet().add(exisingSaleLinkgDetailValue);
    }

    @Test
    public void testPostRevenueRecognitionCalculatesTotalToPostIs1000_whenCollectionHasMoreThan1ElementWithSumOfRevRecIs1000() throws BusinessException {
        //@Given
        stubSaleLinkDetailDAOWithTwoElement(BigDecimal.valueOf(600));
        when(revenueRecognitionCalculator.getRevenueRecognition(any(SaleLinkDetail.class), eq(defaultPeriod))).thenReturn(BigDecimal.valueOf(500), BigDecimal.valueOf(500));
        //@When
        postRevenueRecognition.postRevenueRecognition();
        //@Then
        BigDecimal expectedPostingValue = BigDecimal.valueOf(1000);
        verify(postingService, times(3)).submitAndSaveBonusPosting(
                eq(expectedPostingValue),
                any(ReferenceNameEnum.class),
                anyString(),
                any(Date.class),
                any(Date.class),
                anyString());
    }

    @Test
    public void testPostRevenueRecognitionWillNotPostForFULLY_PAID_or_BILLED_WhenAccumulatedNetRoyaltyValueIsLessThanExistingRevenueRecognition() throws BusinessException {
        final BigDecimal netRoyaltyValueQuantity = BigDecimal.valueOf(200);
        final BigDecimal revenueRecognition = BigDecimal.valueOf(400);
        final SaleLinkDetail saleLinkDetail = stubSaleLinkDetailDAO(netRoyaltyValueQuantity);
        addExistingPostedSaleLinkDetailValue(saleLinkDetail, revenueRecognition);
        when(revenueRecognitionCalculator.getRevenueRecognition(saleLinkDetail, defaultPeriod)).thenReturn(revenueRecognition);

        postRevenueRecognition.postRevenueRecognition();

        verify(postingService, times(1)).submitAndSaveBonusPosting(
                eq(revenueRecognition),
                eq(ReferenceNameEnum.ROYALTIES_REVENUE_RECOGNITION),
                anyString(),
                any(Date.class),
                any(Date.class),
                anyString());
    }

    @Test
    public void testPostRevenueRecognitionWillPost_WhenPaymentStatusIsNOT_PAID() throws BusinessException {
        final BigDecimal netRoyaltyValueQuantity = BigDecimal.valueOf(200);
        final BigDecimal revenueRecognition = BigDecimal.valueOf(400);
        final SaleLinkDetail saleLinkDetail = stubSaleLinkDetailDAO(netRoyaltyValueQuantity);
        addExistingPostedSaleLinkDetailValue(saleLinkDetail, revenueRecognition);
        when(revenueRecognitionCalculator.getRevenueRecognition(any(SaleLinkDetail.class), eq(defaultPeriod))).thenReturn(revenueRecognition);

        postRevenueRecognition.postRevenueRecognition();

        verify(postingService, times(1)).submitAndSaveBonusPosting(
                eq(revenueRecognition),
                eq(ReferenceNameEnum.ROYALTIES_REVENUE_RECOGNITION),
                anyString(),
                any(Date.class),
                any(Date.class),
                anyString());
    }

    @Test
    public void testPostRevenueRecognitionWillPost_WhenTotalRevenueRecognitionIsGreaterThanZero() throws BusinessException {
        final BigDecimal netRoyaltyValueQuantity = BigDecimal.valueOf(200);
        final BigDecimal revenueRecognition = BigDecimal.valueOf(400);
        final SaleLinkDetail saleLinkDetail = stubSaleLinkDetailDAO(netRoyaltyValueQuantity);
        addExistingPostedSaleLinkDetailValue(saleLinkDetail, revenueRecognition);
        when(revenueRecognitionCalculator.getRevenueRecognition(any(SaleLinkDetail.class), eq(defaultPeriod))).thenReturn(revenueRecognition);

        postRevenueRecognition.postRevenueRecognition();

        verify(postingService).submitAndSaveBonusPosting(
                any(BigDecimal.class),
                eq(ReferenceNameEnum.ROYALTIES_REVENUE_RECOGNITION),
                anyString(),
                any(Date.class),
                any(Date.class),
                anyString());
    }

    @Test
    public void testPostRevenueRecognitionDoNotPost_WhenTotalRevenueRecognitionIsZero() throws BusinessException {
        final BigDecimal netRoyaltyValueQuantity = BigDecimal.ZERO;
        final BigDecimal revenueRecognition = BigDecimal.ZERO;
        stubSaleLinkDetailDAO(netRoyaltyValueQuantity);
        when(revenueRecognitionCalculator.getRevenueRecognition(any(SaleLinkDetail.class), eq(defaultPeriod))).thenReturn(revenueRecognition);

        postRevenueRecognition.postRevenueRecognition();

        verifyNoMoreInteractions(postingService);
    }

    @Test
    public void testPostRevenueRecognitionSavesSaleItems_WhenNetRoyaltyValueIsGreatThanRevenueRecognition() throws BusinessException {
        final BigDecimal netRoyaltyValueQuantity = BigDecimal.valueOf(400);
        final BigDecimal revenueRecognition = BigDecimal.valueOf(100);
        final SaleLinkDetail saleLinkDetail = stubSaleLinkDetailDAO(netRoyaltyValueQuantity);
        consumeFromSaleLinkDetail(saleLinkDetail);
        when(revenueRecognitionCalculator.getRevenueRecognition(saleLinkDetail, defaultPeriod)).thenReturn(revenueRecognition);

        postRevenueRecognition.postRevenueRecognition();

        final SaleItem expectedSaleItem = saleLinkDetail.getSaleLinkDetailValueSet().iterator().next().getDealerSaleItem();
        ArgumentCaptor<List> saleItemListCaptor = ArgumentCaptor.forClass(List.class);
        verify(saleDAO).saveSaleItems(saleItemListCaptor.capture());
        final List<SaleItem> value = saleItemListCaptor.getValue();
        assertThat(value).contains(expectedSaleItem);
    }

    @Test
    public void testPostRevenueRecognitionMarkSaleItemAsPosted() throws BusinessException {
        final BigDecimal netRoyaltyValueQuantity = BigDecimal.valueOf(400);
        final BigDecimal revenueRecognition = BigDecimal.valueOf(100);
        final SaleLinkDetail saleLinkDetail = stubSaleLinkDetailDAO(netRoyaltyValueQuantity);
        consumeFromSaleLinkDetail(saleLinkDetail);
        when(revenueRecognitionCalculator.getRevenueRecognition(saleLinkDetail, defaultPeriod)).thenReturn(revenueRecognition);

        postRevenueRecognition.postRevenueRecognition();

        ArgumentCaptor<List> saleItemListCaptor = ArgumentCaptor.forClass(List.class);
        verify(saleDAO).saveSaleItems(saleItemListCaptor.capture());
        final List<SaleItem> savedSaleItems = saleItemListCaptor.getValue();
        assertThat(savedSaleItems).onProperty("postingStatus").contains(PostingStatusEnum.REVENUE_RECOGNITION_POSTED);
    }

    @Test
    public void testPostRevenueRecognitionUpdatesSaleItemsPostingDate() throws BusinessException {
        final BigDecimal netRoyaltyValueQuantity = BigDecimal.valueOf(400);
        final BigDecimal revenueRecognition = BigDecimal.valueOf(100);
        final SaleLinkDetail saleLinkDetail = stubSaleLinkDetailDAO(netRoyaltyValueQuantity);
        consumeFromSaleLinkDetail(saleLinkDetail);
        when(revenueRecognitionCalculator.getRevenueRecognition(saleLinkDetail, defaultPeriod)).thenReturn(revenueRecognition);

        postRevenueRecognition.postRevenueRecognition();

        ArgumentCaptor<List> saleItemListCaptor = ArgumentCaptor.forClass(List.class);
        verify(saleDAO).saveSaleItems(saleItemListCaptor.capture());
        final List<SaleItem> savedSaleItems = saleItemListCaptor.getValue();
        assertThat(savedSaleItems).onProperty("postingDate").contains(DateUtils.getLastDateOfPreviousMonth());
    }

    @Test
    public void testPostRevenueRecognitionUpdatesSaleItemsRevenueRecognition() throws BusinessException {
        final BigDecimal netRoyaltyValueQuantity = BigDecimal.valueOf(400);
        final BigDecimal revenueRecognition = BigDecimal.valueOf(100);
        final SaleLinkDetail saleLinkDetail = stubSaleLinkDetailDAO(netRoyaltyValueQuantity);
        consumeFromSaleLinkDetail(saleLinkDetail);
        when(revenueRecognitionCalculator.getRevenueRecognition(saleLinkDetail, defaultPeriod)).thenReturn(revenueRecognition);

        postRevenueRecognition.postRevenueRecognition();

        ArgumentCaptor<List> saleItemListCaptor = ArgumentCaptor.forClass(List.class);
        verify(saleDAO).saveSaleItems(saleItemListCaptor.capture());
        final List<SaleItem> savedSaleItems = saleItemListCaptor.getValue();
        assertThat(savedSaleItems).onProperty("revenueRecognition").isNotNull();
    }

    @Test
    public void testPostRevenueRecognitionQueriesSaleLinkDetail_WithPaymentStatus() throws BusinessException {
        final BigDecimal netRoyaltyValueQuantity = BigDecimal.valueOf(400);
        final BigDecimal revenueRecognition = BigDecimal.valueOf(100);
        final SaleLinkDetail saleLinkDetail = stubSaleLinkDetailDAO(netRoyaltyValueQuantity);
        consumeFromSaleLinkDetail(saleLinkDetail);
        when(revenueRecognitionCalculator.getRevenueRecognition(saleLinkDetail, defaultPeriod)).thenReturn(revenueRecognition);

        postRevenueRecognition.postRevenueRecognition();

        ArgumentCaptor<PaymentStatus> paymentCaptor = ArgumentCaptor.forClass(PaymentStatus.class);
        verify(saleLinkDetailDAO, times(3)).findLinkedSalesByPaymentStatusAndCreatedInPeriod(paymentCaptor.capture(), any(DateRange.class));
        final List<PaymentStatus> allValues = paymentCaptor.getAllValues();
        assertThat(allValues).containsExactly(PaymentStatus.NOT_PAID, PaymentStatus.BILLED, PaymentStatus.FULLY_PAID);
    }

    @Test
    public void testPostRevenueRecognitionQueriesSaleLinkDetail_WithLastMonthDateRange() throws BusinessException {
        final BigDecimal netRoyaltyValueQuantity = BigDecimal.valueOf(400);
        final BigDecimal revenueRecognition = BigDecimal.valueOf(100);
        final SaleLinkDetail saleLinkDetail = stubSaleLinkDetailDAO(netRoyaltyValueQuantity);
        consumeFromSaleLinkDetail(saleLinkDetail);
        when(revenueRecognitionCalculator.getRevenueRecognition(saleLinkDetail, defaultPeriod)).thenReturn(revenueRecognition);

        postRevenueRecognition.postRevenueRecognition();

        ArgumentCaptor<DateRange> dateRangeCaptor = ArgumentCaptor.forClass(DateRange.class);
        verify(saleLinkDetailDAO, times(3)).findLinkedSalesByPaymentStatusAndCreatedInPeriod(any(PaymentStatus.class), dateRangeCaptor.capture());
        final List<DateRange> dateRanges = dateRangeCaptor.getAllValues();
        final DateRange lastMonthDateRange = DateUtils.getLastMonthDateRange();
        assertThat(dateRanges).onProperty("dateFrom").contains(lastMonthDateRange.getDateFrom());
        assertThat(dateRanges).onProperty("dateTo").contains(lastMonthDateRange.getDateTo());
    }

    @Test
    public void testPostRevenueRecognitionUpdatesSaleLinkDetail_WhenPostingReveueRecognition() throws BusinessException {
        final BigDecimal netRoyaltyValueQuantity = BigDecimal.valueOf(400);
        final BigDecimal revenueRecognition = BigDecimal.valueOf(100);
        final SaleLinkDetail saleLinkDetail = stubSaleLinkDetailDAO(netRoyaltyValueQuantity);
        consumeFromSaleLinkDetail(saleLinkDetail);
        when(revenueRecognitionCalculator.getRevenueRecognition(saleLinkDetail, defaultPeriod)).thenReturn(revenueRecognition);

        postRevenueRecognition.postRevenueRecognition();

        verify(saleLinkDetailDAO, atLeastOnce()).save(saleLinkDetail);
    }

    private void consumeFromSaleLinkDetail(SaleLinkDetail saleLinkDetail) {
        final Sale dealerSale = createDealerSale(DateUtils.getLastMonthDateRange().getDateTo());
        Product product = createProduct("product 1", false);
        final SaleItem dealerSaleItem = addSaleItemToSale(dealerSale, new ItemDescription(BigDecimal.TEN, product, "batchName", plantability, BigDecimal.valueOf(20)), null);
        saleLinkDetail.consume(dealerSale, BigDecimal.TEN, dealerSaleItem);
    }

    public SaleLinkDetail stubSaleLinkDetailDAO(BigDecimal netRoyaltyValueQuantity) {
        SaleLinkDetail saleLinkDetail = createSaleLinkDetail(netRoyaltyValueQuantity);
        List<SaleLinkDetail> saleLinkDetails = Lists.newArrayList(saleLinkDetail);
        when(saleLinkDetailDAO.findLinkedSalesByPaymentStatusAndCreatedInPeriod(any(PaymentStatus.class), any(DateRange.class))).thenReturn(saleLinkDetails);
        return saleLinkDetail;
    }

    public List<SaleLinkDetail> stubSaleLinkDetailDAOWithTwoElement(BigDecimal netRoyaltyValueQuantity) {
        SaleLinkDetail saleLinkDetail1 = createSaleLinkDetail(netRoyaltyValueQuantity);
        SaleLinkDetail saleLinkDetail2 = createSaleLinkDetail(netRoyaltyValueQuantity);
        List<SaleLinkDetail> saleLinkDetails = Lists.newArrayList(saleLinkDetail1, saleLinkDetail2);
        when(saleLinkDetailDAO.findLinkedSalesByPaymentStatusAndCreatedInPeriod(any(PaymentStatus.class), any(DateRange.class))).thenReturn(saleLinkDetails);
        return saleLinkDetails;
    }

    public SaleLinkDetail createSaleLinkDetail(BigDecimal netRoyaltyValueQuantity) {
        Sale multiplierSale = createMultiplierSale();
        Product product = createProduct("product", false);
        SaleItem multiplierSaleItem = addSaleItemToSale(multiplierSale, new ItemDescription(BigDecimal.valueOf(100), product, "batchName", plantability, BigDecimal.valueOf(20)), null);
        multiplierSaleItem.setNetRoyaltyValueQuantity(netRoyaltyValueQuantity);
        final SaleLinkDetail saleLinkDetail = new SaleLinkDetail(multiplierSale, multiplierSaleItem);
        return saleLinkDetail;
    }

    private SaleItem buildSaleItemWithSaleLinkDetail(BigDecimal netRoyaltyValue) {
        SaleItem saleItem = new SaleItem();
        saleItem.setHaAmount(BigDecimal.valueOf(7l));
        saleItem.setSoldQuantity(21l);
        saleItem.setNetQuantity(BigDecimal.valueOf(33));
        saleItem.setNetRoyaltyValueQuantity(netRoyaltyValue);
        saleItem.setSaleLinkDetail(buildSaleLinkDetail(saleItem));
        return saleItem;
    }

    private SaleLinkDetail buildSaleLinkDetail(SaleItem saleItem) {
        SaleLinkDetail saleLinkDetail = new SaleLinkDetail();
        saleLinkDetail.setSaleItem(saleItem);
        saleLinkDetail.setConsumed(BigDecimal.valueOf(20));
        return saleLinkDetail;
    }

    public void stubRevenueRecognitionCalculatorToReturn(BigDecimal revenueRecognition) {
        when(revenueRecognitionCalculator.getRevenueRecognition(any(SaleLinkDetail.class), eq(defaultPeriod))).thenReturn(revenueRecognition);
    }

}