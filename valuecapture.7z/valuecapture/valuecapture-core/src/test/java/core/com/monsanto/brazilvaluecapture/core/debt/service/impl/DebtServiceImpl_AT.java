package com.monsanto.brazilvaluecapture.core.debt.service.impl;

import com.monsanto.brazilvaluecapture.core.base.model.bean.Country;
import com.monsanto.brazilvaluecapture.core.base.model.dao.CountryDAO;
import com.monsanto.brazilvaluecapture.core.debt.service.DebtNotFoundException;
import com.monsanto.brazilvaluecapture.core.debt.service.DebtService;
import com.monsanto.brazilvaluecapture.core.foundation.test.AbstractServiceIntegrationTests;
import com.monsanto.brazilvaluecapture.core.foundation.test.dbunit.DbUnitHelper;
import org.fest.assertions.Assertions;
import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Date;
import java.util.StringTokenizer;

import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;

/**
 * Created by IntelliJ IDEA.
 * User: ASEQU
 * Date: 6/17/13
 * Time: 3:57 PM
 * To change this template use File | Settings | File Templates.
 */
public class DebtServiceImpl_AT extends AbstractServiceIntegrationTests {

    private static final String ARGENTINA_COUNTRY_CODE = "AR";

    @Autowired
    DebtService debtService;
    @Autowired
    CountryDAO countryDAO;
    Country country;

    @Before
    public void setUp() throws Exception {
        String dataSetLocations = "classpath:data/core/debt-dataset.xml";
        DbUnitHelper.setup(dataSetLocations);

        this.country = countryDAO.selectByDescription("ARGENTINA");
        country.getId();
    }

    @Test
    public void testGetNacionBankDebtFile_WhenTheServiceMethodIsCallWithArgCountryIdAndCodeReturnThreeLineString() throws IOException, DebtNotFoundException {

        InputStreamReader input = new InputStreamReader(this.debtService.getNacionBankDebtFile(this.country.getId(), this.country.getCode(),new Date()));
        BufferedReader bufferedReader = new BufferedReader(input);

        assertTrue(bufferedReader.readLine().startsWith("H"));
        assertTrue(bufferedReader.readLine().startsWith("D"));
        assertTrue(bufferedReader.readLine().startsWith("T"));
        assertTrue(bufferedReader.readLine() == null);
    }

    @Test
    public void testGetNacionBankDebtFile_WhenIsItemListSizeBiggerThanZeroReturnTheAdditionInTheFooter() throws IOException, DebtNotFoundException {
        InputStreamReader input = new InputStreamReader(this.debtService.getNacionBankDebtFile(this.country.getId(), this.country.getCode(),new Date()));
        BufferedReader bufferedReader = new BufferedReader(input);
        String line = "";

        for(int i = 0; i < 3; i++){
            line = bufferedReader.readLine();
        }

        String amount = line.substring(10, 25);

        //Assertions.assertThat(amount).isEqualTo("000000000125452");
        Assertions.assertThat(amount).isEqualTo("000000000000000");
    }

    @Test
    public void testGetMacroBankDebtFile_WhenTheServiceMethodIsCallWithArgCountryIdAndCodeReturnThreeLineString() throws IOException, DebtNotFoundException {

        InputStreamReader input = new InputStreamReader(this.debtService.getMacroBankDebtFile(this.country.getId(), this.country.getCode(), new Date()));
        BufferedReader bufferedReader = new BufferedReader(input);

        assertTrue(bufferedReader.readLine().startsWith("H"));
        assertTrue(bufferedReader.readLine().startsWith("D"));
        assertTrue(bufferedReader.readLine().startsWith("T"));
        assertTrue(bufferedReader.readLine() == null);
    }

    @Test
    public void testGetMacroBankDebtFile_WhenIsItemListSizeBiggerThanZeroReturnTheAdditionInTheFooter() throws IOException, DebtNotFoundException {
        InputStreamReader input = new InputStreamReader(this.debtService.getMacroBankDebtFile(this.country.getId(), this.country.getCode(), new Date()));
        BufferedReader bufferedReader = new BufferedReader(input);
        String line = "";

        for(int i = 0; i < 3; i++){
            line = bufferedReader.readLine();
        }

        String amount = line.substring(6, 21);

        Assertions.assertThat(amount).isEqualTo("000000000125452");
    }

    @Test
    public void testGetMacroBankDebtFile_WhenIsItemListSizeOneTheFooterRegisterCounterIsThree() throws IOException, DebtNotFoundException {
        InputStreamReader input = new InputStreamReader(this.debtService.getMacroBankDebtFile(this.country.getId(), this.country.getCode(), new Date()));
        BufferedReader bufferedReader = new BufferedReader(input);
        String line = "";

        for(int i = 0; i < 3; i++){
            line = bufferedReader.readLine();
        }

        String amount = line.substring(1, 6);

        Assertions.assertThat(amount).isEqualTo("00003");
    }
}
