package com.monsanto.brazilvaluecapture.core.grower.report;

import com.monsanto.brazilvaluecapture.core.base.SystemTestFixture;
import com.monsanto.brazilvaluecapture.core.base.model.bean.BillingAddress;
import com.monsanto.brazilvaluecapture.core.base.model.bean.BusinessAddress;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Document;
import com.monsanto.brazilvaluecapture.core.commercialhierarchy.model.bean.CommercialHierType;
import com.monsanto.brazilvaluecapture.core.commercialhierarchy.model.bean.CommercialHierarchy;
import com.monsanto.brazilvaluecapture.core.commercialhierarchy.model.bean.CommercialHierarchyType;
import com.monsanto.brazilvaluecapture.core.foundation.service.BusinessException;
import com.monsanto.brazilvaluecapture.core.foundation.test.AbstractServiceIntegrationTests;
import com.monsanto.brazilvaluecapture.core.grower.PlayerTestData;
import com.monsanto.brazilvaluecapture.core.grower.model.bean.Agreement;
import com.monsanto.brazilvaluecapture.core.grower.model.bean.Agreement.AgreementStatusEnum;
import com.monsanto.brazilvaluecapture.core.grower.model.bean.AgreementTemplate;
import com.monsanto.brazilvaluecapture.core.grower.model.bean.AgreementTemplateType;
import com.monsanto.brazilvaluecapture.core.grower.model.bean.Grower;
import com.monsanto.brazilvaluecapture.core.grower.model.dao.GrowerDAO;
import com.monsanto.brazilvaluecapture.core.grower.model.dao.impl.GrowerAgreementReportFilter;
import com.monsanto.brazilvaluecapture.core.user.AccessControlTestFixture;
import com.monsanto.brazilvaluecapture.seedsale.quota.report.EmptyReportException;
import com.monsanto.brazilvaluecapture.seedsale.sale.SaleTestFixture;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.hibernate.criterion.Restrictions;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

public class GrowerAgreementReportAssembler_AT extends AbstractServiceIntegrationTests {

    private static final String JOSE_CNPJ = "888888888888888";

    private ResourceBundle resourceBundle = ResourceBundle.getBundle("bundle/bundle");

    private Agreement agreementIntactaChico;
    private Agreement agreementIntactaChico2;
    private Agreement agreementRRChico;
    private Agreement agreementRRjoao;

    private Agreement agreementIntactaJose;

    private Grower joseDePaula;

    @Autowired
    private GrowerDAO growerDAO;
    @Autowired
    private GrowerAgreementReportBuilder growerAgreementReportBuilder;

    @Before
    public void init() throws BusinessException {
        systemTestFixture = new SystemTestFixture(this);
        accessControlTestFixture = new AccessControlTestFixture(this, systemTestFixture);
        saleTestFixture = new SaleTestFixture(this, systemTestFixture);

        AgreementTemplateType agreementTemplateTypeIntacta = new AgreementTemplateType(systemTestFixture.soy, systemTestFixture.mons4ntoBr, systemTestFixture.intactaMons4nto, "TEST");
        saveAndFlush(agreementTemplateTypeIntacta);

        AgreementTemplateType agreementTemplateTypeIntacta2 = new AgreementTemplateType(systemTestFixture.soy, systemTestFixture.mons4ntoBr, systemTestFixture.intactaMons4nto, "TEST2");
        saveAndFlush(agreementTemplateTypeIntacta2);

        AgreementTemplateType agreementTemplateTypeRR = new AgreementTemplateType(systemTestFixture.soy, systemTestFixture.mons4ntoBr, systemTestFixture.rrMons4nto, "TEST");
        saveAndFlush(agreementTemplateTypeRR);

        AgreementTemplate agreementTemplateIntacta = new AgreementTemplate(systemTestFixture.soy, systemTestFixture.monsantoBr, systemTestFixture.intacta, agreementTemplateTypeIntacta, "CONTENT", Boolean.TRUE);
        AgreementTemplate agreementTemplateIntacta2 = new AgreementTemplate(systemTestFixture.soy, systemTestFixture.monsantoBr, systemTestFixture.intacta, agreementTemplateTypeIntacta2, "CONTENT test 2", Boolean.TRUE);
        AgreementTemplate agreementTemplateRR = new AgreementTemplate(systemTestFixture.soy, systemTestFixture.monsantoBr, systemTestFixture.rr, agreementTemplateTypeRR, "CONTENT", Boolean.TRUE);

        createGrowerWithoutAgreements();

        saveAndFlush(agreementTemplateIntacta);
        saveAndFlush(agreementTemplateIntacta2);
        saveAndFlush(agreementTemplateRR);

        agreementIntactaChico = new Agreement(1L, null, AgreementStatusEnum.APPROVED, agreementTemplateIntacta, saleTestFixture.chicoBento);
        agreementIntactaChico2 = new Agreement(2L, null, AgreementStatusEnum.DISAPPROVED, agreementTemplateIntacta2, saleTestFixture.chicoBento);
        agreementRRChico = new Agreement(3L, null, AgreementStatusEnum.APPROVED, agreementTemplateRR, saleTestFixture.chicoBento);
        agreementRRjoao = new Agreement(4L, null, AgreementStatusEnum.APPROVED, agreementTemplateRR, saleTestFixture.joaoDaSilva);
        agreementIntactaJose = new Agreement(5L, null, AgreementStatusEnum.APPROVED, agreementTemplateIntacta, saleTestFixture.joseDaSilva);

        saveAndFlush(agreementIntactaChico);
        saveAndFlush(agreementIntactaChico2);
        saveAndFlush(agreementRRChico);
        saveAndFlush(agreementRRjoao);
        saveAndFlush(agreementIntactaJose);

    }

    private void createGrowerWithoutAgreements() {
        Document joseDocument = PlayerTestData.createDocument(systemTestFixture.documentCnpj, JOSE_CNPJ);
        BusinessAddress businessAddress = PlayerTestData.createBusinessAddress(systemTestFixture.matoGrossoDoSul, systemTestFixture.vilaNova, systemTestFixture.brazil);
        BillingAddress billingAddress = PlayerTestData.createBillingAddress(systemTestFixture.matoGrossoDoSul, systemTestFixture.vilaNova, systemTestFixture.brazil);
        joseDePaula = PlayerTestData.createGrower(joseDocument, billingAddress, businessAddress);
        joseDePaula.setAlias("Jose");
        joseDePaula.setName("Jose de Paula");
        saveAndFlush(joseDePaula);

    }

    @Test
    public void given_one_grower_in_list_when_assemble_report_then_should_have_1_lines_23_cols() throws IOException, NoSuchMethodException, EmptyReportException, EmptyRequiredGrowerAgreementReportFieldException {

        List<AgreementStatusEnum> agreStatusEnums = new ArrayList<AgreementStatusEnum>();

        agreStatusEnums.add(AgreementStatusEnum.APPROVED);

        growerAgreementReportBuilder.loadRecords(saleTestFixture.chicoBento, resourceBundle, systemTestFixture.monsantoBr, systemTestFixture.soy, null, null, null, agreStatusEnums, null, null, null, null);
        ByteArrayOutputStream baos = growerAgreementReportBuilder.buildReportFor(resourceBundle);

        assertSheetAndVerifyBlank(baos, 1, 22, false);
    }

    @Test
    public void given_three_growers_with_all_agreements_in_list_when_assemble_report_then_should_have_3_technologies() throws NoSuchMethodException, IOException, EmptyReportException, EmptyRequiredGrowerAgreementReportFieldException {

        List<AgreementStatusEnum> agreStatusEnums = new ArrayList<AgreementStatusEnum>();
        agreStatusEnums.add(AgreementStatusEnum.DISAPPROVED);
        agreStatusEnums.add(AgreementStatusEnum.WITHOUT_AGREEMENT);
        agreStatusEnums.add(AgreementStatusEnum.PENDING_AGREEMENT);
        agreStatusEnums.add(AgreementStatusEnum.PENDING_APPROVAL);
        agreStatusEnums.add(AgreementStatusEnum.APPROVED);
        agreStatusEnums.add(AgreementStatusEnum.OBSERVED);
        agreStatusEnums.add(AgreementStatusEnum.DIGITAL_PREAPPROVED);
        agreStatusEnums.add(AgreementStatusEnum.SUSPENDED);

        growerAgreementReportBuilder.loadRecords(saleTestFixture.chicoBento, resourceBundle, systemTestFixture.monsantoBr, systemTestFixture.soy, null, null, null, agreStatusEnums, null, null, null, null);
        ByteArrayOutputStream baos = growerAgreementReportBuilder.buildReportFor(resourceBundle);

        HSSFSheet sheet = assertAndReturnSheet(baos);

        int lastRowNum = sheet.getLastRowNum();
        Assert.assertEquals("LastRowNum should be three", 1, lastRowNum);

        HSSFRow lastRow = sheet.getRow(lastRowNum);
        Assert.assertNotNull("LastRow shouldn't be null", lastRow);

        Assert.assertEquals("Intacta", lastRow.getCell(15).getStringCellValue());
        Assert.assertEquals("TEST", lastRow.getCell(16).getStringCellValue());

        Assert.assertEquals("Intacta", lastRow.getCell(23).getStringCellValue());
        Assert.assertEquals("TEST2", lastRow.getCell(24).getStringCellValue());

        Assert.assertEquals("RR", lastRow.getCell(31).getStringCellValue());
        Assert.assertEquals("TEST", lastRow.getCell(32).getStringCellValue());


    }

    @Test
    public void given_three_growers_with_four_agreements_in_list_when_assemble_report_then_should_have_3_rows() throws NoSuchMethodException, IOException, EmptyReportException, EmptyRequiredGrowerAgreementReportFieldException {

        List<AgreementStatusEnum> agreStatusEnums = new ArrayList<AgreementStatusEnum>();
        agreStatusEnums.add(AgreementStatusEnum.APPROVED);

        growerAgreementReportBuilder.loadRecords(null, resourceBundle, systemTestFixture.monsantoBr, systemTestFixture.soy, null, null, null, agreStatusEnums, null, null, systemTestFixture.unity, null);
        ByteArrayOutputStream baos = growerAgreementReportBuilder.buildReportFor(resourceBundle);

        HSSFSheet sheet = assertAndReturnSheet(baos);

        int lastRowNum = sheet.getLastRowNum();
        Assert.assertEquals("LastRowNum should be three", 3, lastRowNum);

        HSSFRow lastRow = sheet.getRow(lastRowNum);
        Assert.assertNotNull("LastRow shouldn't be null", lastRow);

        int cellPositionIntacta = 15;
        int cellPositionRR = 23;
        if (systemTestFixture.intacta.getId() > systemTestFixture.rr.getId()) {
            cellPositionIntacta = 23;
            cellPositionRR = 15;
        }

        for (int rowNum = 1; rowNum <= sheet.getLastRowNum(); rowNum++) {
            HSSFRow row = sheet.getRow(rowNum);
            Assert.assertNotNull("Row shouldn't be null", row);

            HSSFCell cellGrowerName = row.getCell(2);
            Assert.assertNotNull("Cell shouldn't be null", cellGrowerName);

            if (saleTestFixture.chicoBento.getName().equals(cellGrowerName.getStringCellValue())) {
                assertCellAndVerifyValue(row, 1, saleTestFixture.chicoBento.getDocument().getValueFormatted());
                assertCellAndVerifyValue(row, 2, saleTestFixture.chicoBento.getName());
                assertCellAndVerifyValue(row, cellPositionIntacta, agreementIntactaChico.getAgreementTemplate().getTechnology().getDescription());
                assertCellAndVerifyValue(row, cellPositionRR, agreementRRChico.getAgreementTemplate().getTechnology().getDescription());
            }
            if (saleTestFixture.joaoDaSilva.getName().equals(cellGrowerName.getStringCellValue())) {
                assertCellAndVerifyValue(row, 1, saleTestFixture.joaoDaSilva.getDocument().getValueFormatted());
                assertCellAndVerifyValue(row, 2, saleTestFixture.joaoDaSilva.getName());
                assertCellAndVerifyValue(row, cellPositionIntacta, "");
                assertCellAndVerifyValue(row, cellPositionRR, agreementRRjoao.getAgreementTemplate().getTechnology().getDescription());
            }
            if (saleTestFixture.joseDaSilva.getName().equals(cellGrowerName.getStringCellValue())) {
                assertCellAndVerifyValue(row, 1, saleTestFixture.joseDaSilva.getDocument().getValueFormatted());
                assertCellAndVerifyValue(row, 2, saleTestFixture.joseDaSilva.getName());
                assertCellAndVerifyValue(row, cellPositionIntacta, agreementIntactaJose.getAgreementTemplate().getTechnology().getDescription());
                assertCellAndVerifyValue(row, cellPositionRR, "");
            }
        }

    }

    private void assertCellAndVerifyValue(HSSFRow row, int cellPosition, Object expected) {
        HSSFCell cell = row.getCell(cellPosition);
        switch (cell.getCellType()) {
            case HSSFCell.CELL_TYPE_NUMERIC:
                Assert.assertEquals("Should have the expected value", expected, cell.getNumericCellValue());
                break;
            case HSSFCell.CELL_TYPE_STRING:
                Assert.assertEquals("Should have the expected value", expected, cell.getStringCellValue());
                break;
            default:
                Assert.fail("Should have cell type expected");
                break;
        }
    }

    private HSSFSheet assertAndReturnSheet(ByteArrayOutputStream baos) throws IOException {
        ByteArrayInputStream inputStream = new ByteArrayInputStream(baos.toByteArray());
        HSSFWorkbook hssfWorkbook = new HSSFWorkbook(inputStream);
        Assert.assertNotNull("workbook shouldn't be null", hssfWorkbook);
        HSSFSheet sheet = hssfWorkbook.getSheetAt(0);
        Assert.assertNotNull("Sheet shouldn't be null", sheet);
        return sheet;
    }


    @Test
    public void given_one_grower_with_no_agreements_in_list_when_assemble_report_then_should_have_1_line_with_14_cols() throws NoSuchMethodException, IOException, EmptyReportException, EmptyRequiredGrowerAgreementReportFieldException {

        List<AgreementStatusEnum> agreStatusEnums = new ArrayList<AgreementStatusEnum>();

        agreStatusEnums.add(AgreementStatusEnum.WITHOUT_AGREEMENT);

        growerAgreementReportBuilder.loadRecords(null, resourceBundle, systemTestFixture.monsantoBr, systemTestFixture.soy, null, null, null, agreStatusEnums, null, null, systemTestFixture.unity, null);
        ByteArrayOutputStream baos = growerAgreementReportBuilder.buildReportFor(resourceBundle);

        assertSheetAndVerifyBlank(baos, 1, 14, false);

    }

    @Test
    public void test_grower_agreement_reportfilter_by_technology() {
        GrowerAgreementReportFilter filter = GrowerAgreementReportFilter.getInstanceFilterToWithAgreement(systemTestFixture.monsantoBr, systemTestFixture.soy, systemTestFixture.rr);

        List<GrowerReportDTO> reports = growerDAO.getGrowersReportDTOBy(filter);
        Assert.assertTrue(!reports.isEmpty());
        Assert.assertEquals("Must have two growers", 2, reports.size());

    }

    @Test
    public void test_groweragreementreportfilter_by_state_and_city() {
        GrowerAgreementReportFilter filter = GrowerAgreementReportFilter.getInstanceFilterToWithAgreement(systemTestFixture.monsantoBr, systemTestFixture.soy, null);
        filter.add(systemTestFixture.matoGrossoDoSul);
        filter.add(systemTestFixture.vilaNova);

        List<GrowerReportDTO> reports = growerDAO.getGrowersReportDTOBy(filter);
        Assert.assertTrue(!reports.isEmpty());
        Assert.assertEquals("Must have three growers", 4, reports.size());

    }

    @Test
    public void test_grower_agreement_reportfilter_by_unit() {
        GrowerAgreementReportFilter filter = GrowerAgreementReportFilter
                .getInstanceFilterToWithAgreement(systemTestFixture.monsantoBr,
                        systemTestFixture.soy, null);
        filter.addFromUnity(systemTestFixture.unity);

        List<GrowerReportDTO> reports = growerDAO.getGrowersReportDTOBy(filter);
        Assert.assertTrue(!reports.isEmpty());
        Assert.assertEquals("Must have four growers", 5, reports.size());

    }

    @Test
    public void test_grower_agreement_reportfilter_by_unit_region() {
        GrowerAgreementReportFilter filter = GrowerAgreementReportFilter
                .getInstanceFilterToWithAgreement(systemTestFixture.monsantoBr,
                        systemTestFixture.soy, null);
        filter.addFromUnity(systemTestFixture.unity);
        filter.addFromRegion(systemTestFixture.region);

        List<GrowerReportDTO> reports = growerDAO.getGrowersReportDTOBy(filter);
        Assert.assertTrue(!reports.isEmpty());
        Assert.assertEquals("Must have four growers", 5, reports.size());

    }

    @Test
    public void test_grower_agreement_reportfilter_by_unit_region_district() {
        GrowerAgreementReportFilter filter = GrowerAgreementReportFilter
                .getInstanceFilterToWithAgreement(systemTestFixture.monsantoBr,
                        systemTestFixture.soy, null);
        filter.addFromUnity(systemTestFixture.unity);
        filter.addFromRegion(systemTestFixture.region);
        filter.addFromDistrict(systemTestFixture.districtVilaNova);

        List<GrowerReportDTO> reports = growerDAO.getGrowersReportDTOBy(filter);
        Assert.assertTrue(!reports.isEmpty());
        Assert.assertEquals("Must have two growers", 4, reports.size());

    }

    @Test
    public void test_grower_agreement_reportfilter_by_unit_region_district_hier_type() {
        GrowerAgreementReportFilter filter = GrowerAgreementReportFilter
                .getInstanceFilterToWithAgreement(systemTestFixture.monsantoBr,
                        systemTestFixture.soy, null);
        filter.addFromUnity(systemTestFixture.unity);
        filter.addFromRegion(systemTestFixture.region);
        filter.addFromDistrict(systemTestFixture.districtVilaNova);
        filter.addTypeOfHierarchy(systemTestFixture.commercialHierarchyMonsantoSoy.getCommercialHierType().getCommercialHierTypeDesc());

        List<GrowerReportDTO> reports = growerDAO.getGrowersReportDTOBy(filter);
        Assert.assertTrue(!reports.isEmpty());
        Assert.assertEquals("Must have two growers", 4, reports.size());

    }

    @Test
    public void test_grower_agreement_reportfilter_by_unit_region_district_hier_type_should_retrieve_hierarchy() throws EmptyReportException, NoSuchMethodException, IOException, EmptyRequiredGrowerAgreementReportFieldException {

        CommercialHierType commercialHierTypeDistributor = (CommercialHierType) getSession()
                .createCriteria(CommercialHierType.class, "c")
                .add(Restrictions
                        .eq("c.commercialHierTypeDesc",
                                CommercialHierarchyType.DISTRIBUTOR.getValue()))
                .uniqueResult();

        CommercialHierarchy commercialHierarchyMonsantoSoy = new CommercialHierarchy();
        commercialHierarchyMonsantoSoy.setCommercialHierarchyId(12l);
        commercialHierarchyMonsantoSoy
                .setCommercialHierType(commercialHierTypeDistributor);
        commercialHierarchyMonsantoSoy.setCompany(systemTestFixture.monsantoBr);
        commercialHierarchyMonsantoSoy.setCrop(systemTestFixture.soy);
        commercialHierarchyMonsantoSoy.addUnity(systemTestFixture.unity);
        saveAndFlush(commercialHierarchyMonsantoSoy);

        List<AgreementStatusEnum> agreStatusEnums = new ArrayList<AgreementStatusEnum>();

        agreStatusEnums.add(AgreementStatusEnum.APPROVED);

        growerAgreementReportBuilder.loadRecords(null, resourceBundle, systemTestFixture.monsantoBr, systemTestFixture.soy, null, null, null, agreStatusEnums, systemTestFixture.districtVilaNova, systemTestFixture.region, systemTestFixture.unity, commercialHierarchyMonsantoSoy.getCommercialHierType().getCommercialHierTypeDesc());
        ByteArrayOutputStream baos = growerAgreementReportBuilder.buildReportFor(resourceBundle);

        assertSheetAndVerifyBlank(baos, 1, 14, false);

    }

    private void assertSheetAndVerifyBlank(ByteArrayOutputStream baos, int rowNum, int cellPosition, boolean isBlank) throws IOException {
        ByteArrayInputStream inputStream = new ByteArrayInputStream(baos.toByteArray());
        HSSFWorkbook hssfWorkbook = new HSSFWorkbook(inputStream);
        Assert.assertNotNull("workbook shouldn't be null", hssfWorkbook);
        HSSFSheet sheet = hssfWorkbook.getSheetAt(0);
        Assert.assertNotNull("Sheet shouldn't be null", sheet);
        HSSFRow row = sheet.getRow(rowNum);
        Assert.assertNotNull("Row shouldn't be null", row);
        HSSFCell cell = row.getCell(cellPosition);
        Assert.assertNotNull("Cell shouldn't be null", cell);
        isBlankString(isBlank, cell);
    }

    private void isBlankString(boolean isBlank, HSSFCell cell) {
        if (cell.getCellType() == Cell.CELL_TYPE_STRING) {
            if (isBlank) {
                Assert.assertTrue("This cell is blank", "".equals(cell.getStringCellValue().trim()));
            } else {
                Assert.assertTrue("This cell is not blank", !"".equals(cell.getStringCellValue().trim()));
            }
        }

    }

}
