package com.monsanto.brazilvaluecapture.utils;

import junit.framework.Assert;
import org.joda.time.DateTime;
import org.junit.Test;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import static junit.framework.Assert.*;

public class DateUtils_UT {
    private SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");

    @Test
    public void test_When_Date_Is_Between_Range_ThenReturn_True() throws ParseException {
        Date startDate = dateFormat.parse("01-01-2013");
        Date theDate = dateFormat.parse("06-06-2013");
        Date endDate = dateFormat.parse("31-12-2013");

        assertTrue(DateUtils.isDateBetween(theDate, startDate, endDate));
    }


    @Test
    public void test_When_Date_Is_Between_Range_OfSameDates_ThenReturn_True() throws ParseException {
        Date startDate = dateFormat.parse("01-01-2013");
        Date theDate = startDate;
        Date endDate = startDate;

        assertTrue(DateUtils.isDateBetween(theDate, startDate, endDate));
    }

    @Test
    public void test_When_Date_Is_Before_Range_ThenReturn_False() throws ParseException {
        Date theDate = dateFormat.parse("01-01-2013");
        Date startDate = dateFormat.parse("06-06-2013");
        Date endDate = dateFormat.parse("31-12-2013");

        assertFalse(DateUtils.isDateBetween(theDate, startDate, endDate));
    }

    @Test
    public void test_When_Date_Is_After_Range_ThenReturn_False() throws ParseException {
        Date startDate = dateFormat.parse("01-01-2013");
        Date endDate = dateFormat.parse("31-12-2013");
        Date theDate = dateFormat.parse("01-01-2014");

        assertFalse(DateUtils.isDateBetween(theDate, startDate, endDate));
    }

    @Test
    public void test_When_date_passed_with_time_ThenReturn_date_without_time() {
        //@Given
        Date date = new DateTime(2014, 01, 01, 10, 10).toDate();

        //@When
        Date dateActual = DateUtils.removeTime(date);

        //@Should
        Date dateExpected = new DateTime(2014, 01, 01, 0, 0).toDate();
        Assert.assertEquals(dateExpected, dateActual);
    }

    @Test
    public void testGetFirstDateOfPreviousMonth_AndGetFirstDateOfPreviousMonth() {
        //@Given
        Calendar cal = Calendar.getInstance();
        Date date = cal.getTime();

        //@When
        Date first = DateUtils.getFirstDateOfPreviousMonth();
        Date last = DateUtils.getLastDateOfPreviousMonth();

        //@Should
        assertNotNull(first);
        assertNotNull(last);
        assertTrue(first.before(date));
        assertTrue(last.before(date));
        assertTrue(first.before(last));
    }

    @Test
    public void testGetSearchLastMonthDateRange() throws Exception {
        //@Given
        Calendar calendar = Calendar.getInstance();
        Calendar lastMonthCalendar = Calendar.getInstance();
        lastMonthCalendar.add(Calendar.MONTH, -1);
        //@When
        DateRange dateRange = DateUtils.getLastMonthDateRange();
        //@Then
        assertNotNull(dateRange);
        assertNotNull(dateRange.getDateFrom());
        assertNotNull(dateRange.getDateTo());

        assertTrue(dateRange.getDateFrom().before(calendar.getTime()));
        assertTrue(dateRange.getDateTo().before(calendar.getTime()));
        assertTrue(dateRange.getDateFrom().before(dateRange.getDateTo()));

        assertEquals(dateRange.getCalendarFrom().get(Calendar.DAY_OF_MONTH), lastMonthCalendar.getActualMinimum(Calendar.DAY_OF_MONTH));
        assertEquals(dateRange.getCalendarFrom().get(Calendar.MONTH), lastMonthCalendar.get(Calendar.MONTH));
        assertEquals(dateRange.getCalendarFrom().get(Calendar.YEAR), lastMonthCalendar.get(Calendar.YEAR));

        assertEquals(dateRange.getCalendarTo().get(Calendar.DAY_OF_MONTH), lastMonthCalendar.getActualMaximum(Calendar.DAY_OF_MONTH));
        assertEquals(dateRange.getCalendarTo().get(Calendar.MONTH), lastMonthCalendar.get(Calendar.MONTH));
        assertEquals(dateRange.getCalendarTo().get(Calendar.YEAR), lastMonthCalendar.get(Calendar.YEAR));

    }

}
