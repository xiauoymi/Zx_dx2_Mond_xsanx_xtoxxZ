package com.monsanto.brazilvaluecapture.core.grower.service.impl;

import static org.fest.reflect.core.Reflection.field;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import static org.fest.assertions.Assertions.assertThat;

import com.monsanto.brazilvaluecapture.core.base.model.bean.Crop;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Technology;
import com.monsanto.brazilvaluecapture.core.foundation.util.security.EnvironmentSpecificPropertyReader;
import com.monsanto.brazilvaluecapture.core.foundation.util.security.EnvironmentSpecificPropertyReaderFactory;
import com.monsanto.brazilvaluecapture.core.grower.model.bean.Agreement;
import com.monsanto.brazilvaluecapture.core.grower.model.bean.AgreementTemplate;
import com.monsanto.brazilvaluecapture.core.grower.model.bean.Agreement.AgreementStatusEnum;
import com.monsanto.brazilvaluecapture.core.grower.model.bean.Grower;
import com.monsanto.brazilvaluecapture.osb.its.api.LASVCSAPStoreGLAStatusService;
import com.monsanto.brazilvaluecapture.osb.its.laslicenses.bean.YlasSdLicenceVcToSapResponse;
import com.monsanto.brazilvaluecapture.osb.util.SecurityContextHolder;
import com.monsanto.brazilvaluecapture.osb.util.SecurityContextHolderFactory;

@RunWith(MockitoJUnitRunner.class)
public class StorageGLAStatusServiceRunner_UT {
	
	private SecurityContextHolder securityContextHolder;
	private SecurityContextHolderFactory securityContextHolderFactory;
	private EnvironmentSpecificPropertyReaderFactory environmentSpecificPropertyReaderFactory;
	private EnvironmentSpecificPropertyReader environmentSpecificPropertyReader;
	private StorageGLAStatusServiceRunner storageGLAStatusServiceRunner;
	private YlasSdLicenceVcToSapResponse licensesSapVcResponse;
	private LASVCSAPStoreGLAStatusService osbService;
	private Agreement agreement;
	 
	@Before
	public void setUp() throws Exception {
		securityContextHolder = mock(SecurityContextHolder.class);
        securityContextHolderFactory = mock(SecurityContextHolderFactory.class);
        when(securityContextHolderFactory.getSecurityContextHolder(SecurityContextHolderFactory.TARGET.DATA_POWER_TO_SAP)).thenReturn(securityContextHolder);

        environmentSpecificPropertyReader = mock(EnvironmentSpecificPropertyReader.class);
        environmentSpecificPropertyReaderFactory = mock(EnvironmentSpecificPropertyReaderFactory.class);
        when(environmentSpecificPropertyReaderFactory.getEnvironmentSpecificPropertyReader()).thenReturn(environmentSpecificPropertyReader);
        when(environmentSpecificPropertyReader.getEnvironmentSpecificProperty("osb_lasvc_sap_store_gla_status_url", null)).thenReturn("http://www.google.com");
        
        licensesSapVcResponse = mock(YlasSdLicenceVcToSapResponse.class);
        osbService = mock(LASVCSAPStoreGLAStatusService.class);
        storageGLAStatusServiceRunner = new StorageGLAStatusServiceRunner();
        storageGLAStatusServiceRunner.setOsbService(osbService);
        when(osbService.ylasSdLicenceVcToSap(anyString(), anyString(), anyString(), anyString(), anyString(), anyString())).thenReturn(licensesSapVcResponse);
        when(licensesSapVcResponse.getResult()).thenReturn(new String());
        
        agreement = new Agreement();
        AgreementTemplate agrt = new AgreementTemplate();
        Technology technology = new Technology();
        technology.setDescription("");
        agrt.setTechnology(technology );
        Crop crop = new Crop();
        crop.setCropErpName("");
        agrt.setCrop(crop );
        Grower grower = new Grower();
        grower.setCustomerSapId("");
        agreement.setLicenseNumber("");
        agreement.setGrower(grower );
        agreement.setAgreementTemplate(agrt);
	}

	@Test
	public void testDoRun_ObservedStatusNOk() throws Exception {
		agreement.setStatus(AgreementStatusEnum.OBSERVED);
		try {
			storageGLAStatusServiceRunner.doRun(agreement);
			fail();
		} catch (Exception e) {
			assertFalse(storageGLAStatusServiceRunner.getStatus());
		}
	}
	
	@Test
	public void testDoRun_SuspendedtatusOk() throws Exception {
		agreement.setStatus(AgreementStatusEnum.SUSPENDED);
		when(licensesSapVcResponse.getResult()).thenReturn("0");
		storageGLAStatusServiceRunner.doRun(agreement);
		assertTrue(storageGLAStatusServiceRunner.getStatus());
	}
	
	@Test
	public void testDoRun_DigitalPreApprovedStatus() throws Exception {
		agreement.setStatus(AgreementStatusEnum.DIGITAL_PREAPPROVED);
		when(licensesSapVcResponse.getResult()).thenReturn("0");
		storageGLAStatusServiceRunner.doRun(agreement);
		assertThat(storageGLAStatusServiceRunner.getStatus());
	}
	
	@Test
	public void testDoRun_PendindAgreementStatus() throws Exception {
		agreement.setStatus(AgreementStatusEnum.PENDING_AGREEMENT);
		Mockito.doThrow(Exception.class).when(osbService).ylasSdLicenceVcToSap(anyString(), anyString(), anyString(),anyString(), anyString(), anyString());
		licensesSapVcResponse = null;
		field("licensesSapVcResponse").ofType(YlasSdLicenceVcToSapResponse.class).in(storageGLAStatusServiceRunner).set(licensesSapVcResponse);
		try {
			storageGLAStatusServiceRunner.doRun(agreement);
			fail();
		} catch (Exception e) {
			assertThat(storageGLAStatusServiceRunner.getResponse().containsKey("ERROR_EXCEPTION"));
		}
	}
	
	@Test
	public void testDoRun_ApprovedtatusWithAgreementCreatedInSap() throws Exception {
		agreement.setStatus(AgreementStatusEnum.APPROVED);
		when(licensesSapVcResponse.getResult()).thenReturn("0");
		storageGLAStatusServiceRunner.doRun(agreement);
		assertThat(storageGLAStatusServiceRunner.getStatus());
	}
	
	@Test
	public void testDoRun_ApprovedtatusWithOutAgreementCreatedInSap()
			throws Exception {
		agreement.setStatus(AgreementStatusEnum.APPROVED);
		when(licensesSapVcResponse.getResult()).thenReturn("4");
		try {
			storageGLAStatusServiceRunner.doRun(agreement);
			fail();
		} catch (Exception e) {
			assertThat(storageGLAStatusServiceRunner.getResponse().containsKey(
					"ERROR_EXCEPTION"));
		}
		assertThat(storageGLAStatusServiceRunner.getStatus());
	}

}
