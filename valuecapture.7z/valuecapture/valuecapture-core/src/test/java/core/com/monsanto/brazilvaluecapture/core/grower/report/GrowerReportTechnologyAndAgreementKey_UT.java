package com.monsanto.brazilvaluecapture.core.grower.report;

import junit.framework.Assert;
import org.junit.Test;

import java.util.*;

/**
 * Created with IntelliJ IDEA.
 * User: AMMUNO
 * To change this template use File | Settings | File Templates.
 */
public class GrowerReportTechnologyAndAgreementKey_UT {

    @Test
    public void test_GrowerReportTechnologyAndAgreementKey_EqualKey() {

        Map<GrowerReportTechnologyAndAgreementKey, String> mapTest = new HashMap<GrowerReportTechnologyAndAgreementKey, String>();

        GrowerReportTechnologyAndAgreementKey growerReportTechnologyAndAgreementKey = new GrowerReportTechnologyAndAgreementKey(1L, 2L);

        mapTest.put(growerReportTechnologyAndAgreementKey, "first Object");

        GrowerReportTechnologyAndAgreementKey growerReportTechnologyAndAgreementKey2 = new GrowerReportTechnologyAndAgreementKey(1L, 2L);

        if (mapTest.containsKey(growerReportTechnologyAndAgreementKey2))
            Assert.assertEquals("first Object", mapTest.get(growerReportTechnologyAndAgreementKey));
        else
            Assert.fail("It shouldn't pass");
    }

    @Test
    public void test_GrowerReportTechnologyAndAgreementKey_NotEqualKey() {

        Map<GrowerReportTechnologyAndAgreementKey, String> mapTest = new HashMap<GrowerReportTechnologyAndAgreementKey, String>();

        GrowerReportTechnologyAndAgreementKey growerReportTechnologyAndAgreementKey = new GrowerReportTechnologyAndAgreementKey(1L, 2L);

        mapTest.put(growerReportTechnologyAndAgreementKey, "first Object");

        GrowerReportTechnologyAndAgreementKey growerReportTechnologyAndAgreementKey2 = new GrowerReportTechnologyAndAgreementKey(1L, 3L);

        Assert.assertFalse(mapTest.containsKey(growerReportTechnologyAndAgreementKey2));
    }

    @Test
    public void test_GrowerReportTechnologyAndAgreementKey_2ObjectsSimilars() {

        Map<GrowerReportTechnologyAndAgreementKey, String> mapTest = new HashMap<GrowerReportTechnologyAndAgreementKey, String>();

        GrowerReportTechnologyAndAgreementKey growerReportTechnologyAndAgreementKey = new GrowerReportTechnologyAndAgreementKey(1L, 2L);

        mapTest.put(growerReportTechnologyAndAgreementKey, "first Object");

        GrowerReportTechnologyAndAgreementKey growerReportTechnologyAndAgreementKey2 = new GrowerReportTechnologyAndAgreementKey(2L, 1L);

        Assert.assertFalse(mapTest.containsKey(growerReportTechnologyAndAgreementKey2));

        mapTest.put(growerReportTechnologyAndAgreementKey2, "second Object");

        Assert.assertTrue(mapTest.size() == 2);
        Assert.assertEquals(mapTest.get(growerReportTechnologyAndAgreementKey2), "second Object");
    }

    @Test
    public void test_GrowerReportTechnologyAndAgreementKey_1ObjectNull() {

        Map<GrowerReportTechnologyAndAgreementKey, String> mapTest = new HashMap<GrowerReportTechnologyAndAgreementKey, String>();

        GrowerReportTechnologyAndAgreementKey growerReportTechnologyAndAgreementKey = new GrowerReportTechnologyAndAgreementKey(1L, 2L);

        mapTest.put(growerReportTechnologyAndAgreementKey, "first Object");

        GrowerReportTechnologyAndAgreementKey growerReportTechnologyAndAgreementKey2 = new GrowerReportTechnologyAndAgreementKey(null, null);

        Assert.assertFalse(mapTest.containsKey(growerReportTechnologyAndAgreementKey2));
    }

    @Test
    public void test_GrowerReportTechnologyAndAgreementKey_2ObjectsNull() {

        Map<GrowerReportTechnologyAndAgreementKey, String> mapTest = new HashMap<GrowerReportTechnologyAndAgreementKey, String>();

        GrowerReportTechnologyAndAgreementKey growerReportTechnologyAndAgreementKey = new GrowerReportTechnologyAndAgreementKey(null, null);

        mapTest.put(growerReportTechnologyAndAgreementKey, "first Object");

        GrowerReportTechnologyAndAgreementKey growerReportTechnologyAndAgreementKey2 = new GrowerReportTechnologyAndAgreementKey(null, null);

        Assert.assertFalse(mapTest.containsKey(growerReportTechnologyAndAgreementKey2));
    }

    @Test
    public void test_GrowerReportTechnologyAndAgreementKey_OrderArray() {

        List<GrowerReportTechnologyAndAgreementKey> listTest = new ArrayList<GrowerReportTechnologyAndAgreementKey>();

        GrowerReportTechnologyAndAgreementKey growerReportTechnologyAndAgreementKey = new GrowerReportTechnologyAndAgreementKey(3L, 2L);

        listTest.add(growerReportTechnologyAndAgreementKey);

        GrowerReportTechnologyAndAgreementKey growerReportTechnologyAndAgreementKey2 = new GrowerReportTechnologyAndAgreementKey(3L, 3L);

        listTest.add(growerReportTechnologyAndAgreementKey2);

        GrowerReportTechnologyAndAgreementKey growerReportTechnologyAndAgreementKey3 = new GrowerReportTechnologyAndAgreementKey(1L, 2L);

        listTest.add(growerReportTechnologyAndAgreementKey3);

        GrowerReportTechnologyAndAgreementKey growerReportTechnologyAndAgreementKey4 = new GrowerReportTechnologyAndAgreementKey(2L, 4L);

        listTest.add(growerReportTechnologyAndAgreementKey4);

        Collections.sort(listTest);

        Assert.assertEquals(growerReportTechnologyAndAgreementKey3, listTest.get(0));

        Assert.assertEquals(growerReportTechnologyAndAgreementKey4, listTest.get(1));

        Assert.assertEquals(growerReportTechnologyAndAgreementKey, listTest.get(2));

        Assert.assertEquals(growerReportTechnologyAndAgreementKey2, listTest.get(3));


    }
}
