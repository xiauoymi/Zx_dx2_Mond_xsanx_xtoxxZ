package com.monsanto.brazilvaluecapture.sqlnative.constraint;

import com.monsanto.brazilvaluecapture.core.base.SystemTestFixture;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Country;
import com.monsanto.brazilvaluecapture.core.base.model.bean.State;
import com.monsanto.brazilvaluecapture.core.foundation.model.bean.StatusEnum;
import com.monsanto.brazilvaluecapture.core.foundation.service.BusinessException;
import com.monsanto.brazilvaluecapture.core.foundation.test.AbstractServiceIntegrationTests;
import com.monsanto.brazilvaluecapture.seedsale.harvest.HarvestTestData;
import com.monsanto.brazilvaluecapture.seedsale.harvest.model.bean.Harvest;
import com.monsanto.brazilvaluecapture.seedsale.harvest.model.bean.Plantability;
import com.monsanto.brazilvaluecapture.seedsale.harvest.model.bean.PlantabilitySystemEnum;
import com.monsanto.brazilvaluecapture.seedsale.harvest.model.dao.PlantabilityDAO;
import com.monsanto.brazilvaluecapture.seedsale.harvest.model.dao.impl.PlantabilityDAOImpl;
import com.monsanto.brazilvaluecapture.seedsale.harvest.service.PlantabilityService;
import com.monsanto.brazilvaluecapture.seedsale.harvest.service.PlantabilityWithProductivityUndeletableException;
import com.monsanto.brazilvaluecapture.seedsale.harvest.service.PlantabilityWithSaleTemplateUndeletableException;
import com.monsanto.brazilvaluecapture.seedsale.product.PlantabilityTestData;
import com.monsanto.brazilvaluecapture.seedsale.product.ProductTestData;
import com.monsanto.brazilvaluecapture.seedsale.product.ProductivityTestData;
import com.monsanto.brazilvaluecapture.seedsale.product.model.bean.Product;
import com.monsanto.brazilvaluecapture.seedsale.product.model.bean.Productivity;
import com.monsanto.brazilvaluecapture.seedsale.product.service.ProductWithAssociatedSaleTemplateException;
import junit.framework.Assert;
import org.hibernate.SessionFactory;
import org.hibernate.classic.Session;
import org.hibernate.exception.ConstraintViolationException;
import org.hibernate.exception.GenericJDBCException;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;

import java.sql.SQLException;

@Ignore
public class Plantability_Constraint_AT extends AbstractServiceIntegrationTests {

    @Autowired
    private PlantabilityService plantabilityService;

    @Autowired
    private PlantabilityDAO plantabilityDAO;
    protected Harvest harvest2012;

    public Plantability_Constraint_AT() {
        super();
    }

    private Product randomProduct;
    private Product randomProduct2;
    private Plantability anyPlantability;
    private Plantability anotherPlantability;
    private Plantability systemPlantability;

    @Before
    public void plantabilitySetup() {
        systemTestFixture = new SystemTestFixture(this);

        harvest2012 = HarvestTestData.createHarvest(systemTestFixture.soy, systemTestFixture.operationalYearOf2011,
                systemTestFixture.monsantoBr);
        getSession().saveOrUpdate(harvest2012);

        randomProduct = ProductTestData.createProduct(systemTestFixture.monsoy, systemTestFixture.soy,
                systemTestFixture.intacta, StatusEnum.ACTIVE, systemTestFixture.monsantoBr);
        getSession().saveOrUpdate(randomProduct);

        randomProduct2 = ProductTestData.createProduct(systemTestFixture.monsoy, systemTestFixture.soy,
                systemTestFixture.rr, StatusEnum.ACTIVE, systemTestFixture.monsantoBr);
        getSession().saveOrUpdate(randomProduct2);

        anyPlantability = PlantabilityTestData.createPlantability(harvest2012);
        getSession().saveOrUpdate(anyPlantability);

        anotherPlantability = PlantabilityTestData.createPlantability(harvest2012);
        getSession().saveOrUpdate(anotherPlantability);

        systemPlantability = PlantabilityTestData.createPlantability(harvest2012);
        systemPlantability.setIsPlantabilitySystem(PlantabilitySystemEnum.YES);
        getSession().saveOrUpdate(systemPlantability);
    }

    @Test
    public void testInsertExceptionDuplicate() {
        Plantability plantability = PlantabilityTestData.createPlantability(harvest2012);
        getSession().saveOrUpdate(plantability);

        plantabilityDAO.save(plantability);

        testAssert(plantability);

        try {
            Plantability plantabilityBase = PlantabilityTestData.createPlantability(harvest2012,
                    plantability.getDescription(), plantability.getStatus());
            plantabilityDAO.save(plantabilityBase);
            getSession().flush();

            Assert.fail();
        } catch (ConstraintViolationException e) {
            Assert.assertTrue(true);
        }

    }

    @Test(expected = PlantabilityWithProductivityUndeletableException.class)
    public void testDeletePlantabilityAssociatedWithProductivity()
            throws PlantabilityWithProductivityUndeletableException, PlantabilityWithSaleTemplateUndeletableException {
        Plantability plantability = PlantabilityTestData.createPlantability(harvest2012);
        getSession().saveOrUpdate(plantability);

        Country country = new Country("country", "code");
        getSession().saveOrUpdate(country);

        State state = new State(country, "state", "code");
        getSession().saveOrUpdate(state);

        Productivity productivity = ProductivityTestData.createProductivity(state, plantability);
        getSession().saveOrUpdate(productivity);
        try {
            plantabilityDAO.delete(plantability);
            Assert.fail();
        } catch (GenericJDBCException e) {
            // Workaround to HSQLDB
            if (!getAssumptionTest().isEnvironmentWithSQLANSI()) {
                throw new PlantabilityWithProductivityUndeletableException(e.getMessage(), e.getCause());
            }
        }
    }

    @Test(expected = ConstraintViolationException.class)
    public void given_a_product_should_throw_exception() throws ProductWithAssociatedSaleTemplateException,
            PlantabilityWithProductivityUndeletableException, PlantabilityWithSaleTemplateUndeletableException {
        SessionFactory sessionFactory = Mockito.mock(SessionFactory.class);
        Session session = Mockito.mock(Session.class);
        Mockito.stub(sessionFactory.getCurrentSession()).toReturn(session);
        ConstraintViolationException exception = new ConstraintViolationException("Exception", new SQLException(
                "MESSAGE"), "FK");
        // Mockito.stub(session.delete(Mockito.any())).toThrow(exception);
        Mockito.doThrow(exception).when(session).delete(Mockito.any());
        PlantabilityDAO dao = new PlantabilityDAOImpl(sessionFactory);
        dao.delete(anyPlantability);

    }

    @Test(expected = PlantabilityWithProductivityUndeletableException.class)
    public void given_a_product_should_throw_exception2() throws ProductWithAssociatedSaleTemplateException,
            PlantabilityWithProductivityUndeletableException, PlantabilityWithSaleTemplateUndeletableException {
        SessionFactory sessionFactory = Mockito.mock(SessionFactory.class);
        Session session = Mockito.mock(Session.class);
        Mockito.stub(sessionFactory.getCurrentSession()).toReturn(session);
        ConstraintViolationException exception = new ConstraintViolationException("Exception", new SQLException(
                "FK_PRODUCTI_FK_PLANTA_PLANTABI"), "FK");
        Mockito.doThrow(exception).when(session).delete(Mockito.any());
        PlantabilityDAO dao = new PlantabilityDAOImpl(sessionFactory);
        dao.delete(anyPlantability);

    }

    @Test(expected = PlantabilityWithSaleTemplateUndeletableException.class)
    public void given_a_product_should_throw_exception3() throws ProductWithAssociatedSaleTemplateException,
            PlantabilityWithProductivityUndeletableException, PlantabilityWithSaleTemplateUndeletableException {
        SessionFactory sessionFactory = Mockito.mock(SessionFactory.class);
        Session session = Mockito.mock(Session.class);
        Mockito.stub(sessionFactory.getCurrentSession()).toReturn(session);
        ConstraintViolationException exception = new ConstraintViolationException("Exception", new SQLException(
                "FK_ROYALTY_PLANT_ID"), "FK");
        Mockito.doThrow(exception).when(session).delete(Mockito.any());
        PlantabilityDAO dao = new PlantabilityDAOImpl(sessionFactory);
        dao.delete(anyPlantability);

    }

    @Test(expected = PlantabilityWithProductivityUndeletableException.class)
    public void testShouldNotDeletePlantabilityAssociatedWithProductivity() throws BusinessException {
        Productivity productivityCreated = ProductivityTestData.createProductivity(systemTestFixture.matoGrossoDoSul,
                anyPlantability);
        getSession().saveOrUpdate(productivityCreated);

        try {
            plantabilityService.delete(productivityCreated.getPlantability());
            Assert.fail("A plantability with productivity cannot be deleted.");
        } catch (GenericJDBCException e) {
            // Workaround to HSQLDB
            if (!getAssumptionTest().isEnvironmentWithSQLANSI()) {
                throw new PlantabilityWithProductivityUndeletableException(e.getMessage(), e.getCause());
            }
        }
    }

    private void testAssert(Plantability plantability) {
        Assert.assertNotNull(plantability);
        Assert.assertNotNull(plantability.getDescription());
        Assert.assertNotNull(plantability.getHarvest());
        Assert.assertNotNull(plantability.getStatus());
        Assert.assertNotNull(plantability.getId());
    }

}