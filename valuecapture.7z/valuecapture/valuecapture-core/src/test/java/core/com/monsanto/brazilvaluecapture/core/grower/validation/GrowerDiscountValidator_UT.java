package com.monsanto.brazilvaluecapture.core.grower.validation;

import com.monsanto.brazilvaluecapture.core.grower.model.bean.GrowerDiscount;
import com.monsanto.brazilvaluecapture.core.grower.report.GrowerDiscountsReportDTO;
import com.monsanto.brazilvaluecapture.core.grower.service.GrowerDiscountService;

import junit.framework.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.JUnit4;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import static org.fest.assertions.Fail.fail;
import static org.fest.reflect.core.Reflection.field;
import static org.mockito.Mockito.when;

/**
 * Created with IntelliJ IDEA.
 * User: AFREI
 * Date: 27/12/13
 * Time: 15:51
 */
@RunWith(JUnit4.class)
public class GrowerDiscountValidator_UT{

    private GrowerDiscountUniqueForGivenRangeValidationRule growerDiscountUniqueForGivenRangeValidationRule;
    private GrowerDiscountRangeValidationRule growerDiscountRangeValidationRule;
    private GrowerDiscountDocumentValidationRule growerDiscountDocumentValidationRule;
    private GrowerDiscountValueValidationRule growerDiscountValueValidationRule;
    private GrowerDiscountValidator growerDiscountValidator;

    @Mock
    private GrowerDiscountService growerDiscountService;

    @Before
    public void setUp() throws Exception {
        MockitoAnnotations.initMocks(this);


        growerDiscountValidator = new GrowerDiscountValidator();

        growerDiscountUniqueForGivenRangeValidationRule = new GrowerDiscountUniqueForGivenRangeValidationRule();
        field("growerDiscountService").ofType(GrowerDiscountService.class).in(growerDiscountUniqueForGivenRangeValidationRule).set(growerDiscountService);
        field("growerDiscountUniqueForGivenRangeValidationRule").ofType(GrowerDiscountUniqueForGivenRangeValidationRule.class).in(growerDiscountValidator).set(growerDiscountUniqueForGivenRangeValidationRule);

        growerDiscountRangeValidationRule = new GrowerDiscountRangeValidationRule();
        field("growerDiscountRangeValidationRule").ofType(GrowerDiscountRangeValidationRule.class).in(growerDiscountValidator).set(growerDiscountRangeValidationRule);

        growerDiscountDocumentValidationRule = new GrowerDiscountDocumentValidationRule();
        field("growerDiscountDocumentValidationRule").ofType(GrowerDiscountDocumentValidationRule.class).in(growerDiscountValidator).set(growerDiscountDocumentValidationRule);

        growerDiscountValueValidationRule = new GrowerDiscountValueValidationRule();
        field("growerDiscountValueValidationRule").ofType(GrowerDiscountValueValidationRule.class).in(growerDiscountValidator).set(growerDiscountValueValidationRule);

        growerDiscountValidator.createRules();

    }

    @Test
    public void testValidatorReturnsGrowerDiscountsIfValidationsDoesNotFail() {
        GrowerDiscount growerDiscount = getValidGrowerDiscount();
        when(growerDiscountService.selectDiscountsBy(growerDiscount.getDocumentNumber(), null, true, null, null)).thenReturn(getValidGrowerDiscountsReportDTOListForGrowerDiscount(growerDiscount));

        try{
            GrowerDiscount validatedGrowerDiscount = growerDiscountValidator.validate(growerDiscount);
            Assert.assertEquals(growerDiscount, validatedGrowerDiscount);
        }catch (GrowerDiscountConstraintViolationException e){
            fail();
        }
    }

    private List<GrowerDiscountsReportDTO> getValidGrowerDiscountsReportDTOListForGrowerDiscount(GrowerDiscount growerDiscount){
        List<GrowerDiscountsReportDTO> growerDiscountsReportDTOs = new ArrayList<GrowerDiscountsReportDTO>();

        //same grower, diff date ranges (after)
        GrowerDiscountsReportDTO sameGrowerDiffDateRange = new GrowerDiscountsReportDTO(1L,
                growerDiscount.getDocumentNumber(), growerDiscount.getDiscountValue(), growerDiscount.getDescription(),
                new Date(growerDiscount.getToDate().getTime() + 1000), new Date(growerDiscount.getToDate().getTime() + 2000),
                new Date(), "tester", true, null);

        //same grower, diff date ranges (before)
        GrowerDiscountsReportDTO sameGrowerDiffDateRange2 = new GrowerDiscountsReportDTO(1L,
                growerDiscount.getDocumentNumber(), growerDiscount.getDiscountValue(), growerDiscount.getDescription(),
                new Date(growerDiscount.getFromDate().getTime() - 3000), new Date(growerDiscount.getFromDate().getTime() - 5000),
                new Date(), "tester", true, null);

        growerDiscountsReportDTOs.add(sameGrowerDiffDateRange);
        growerDiscountsReportDTOs.add(sameGrowerDiffDateRange2);

        return growerDiscountsReportDTOs;
    }

    @Test
    public void testValidatorThrowExceptionIfGrowerDiscountUniqueForGivenRangeValidationRuleFails() {
        GrowerDiscount growerDiscount = getValidGrowerDiscount();
        when(growerDiscountService.selectDiscountsBy(growerDiscount.getDocumentNumber(), null, true, null, null)).thenReturn(getInValidGrowerDiscountsReportDTOListForGrowerDiscount(growerDiscount));

        try{
            growerDiscountValidator.validate(growerDiscount);
            fail();
        }catch (GrowerDiscountConstraintViolationException e){
            Assert.assertTrue(!e.isEmpty());
        }

    }

    private List<GrowerDiscountsReportDTO> getInValidGrowerDiscountsReportDTOListForGrowerDiscount(GrowerDiscount growerDiscount){
        List<GrowerDiscountsReportDTO> growerDiscountsReportDTOs = new ArrayList<GrowerDiscountsReportDTO>();

        //same date ranges (after)
        GrowerDiscountsReportDTO sameGrowerDiffDateRange = new GrowerDiscountsReportDTO(1L,
                growerDiscount.getDocumentNumber(), growerDiscount.getDiscountValue(), growerDiscount.getDescription(),
                new Date(growerDiscount.getToDate().getTime() - 1000), new Date(growerDiscount.getToDate().getTime() - 500),
                new Date(), "tester", true, null);

        //same date ranges (before)
        GrowerDiscountsReportDTO sameGrowerDiffDateRange2 = new GrowerDiscountsReportDTO(1L,
                growerDiscount.getDocumentNumber(), growerDiscount.getDiscountValue(), growerDiscount.getDescription(),
                new Date(growerDiscount.getFromDate().getTime() - 1000), new Date(growerDiscount.getFromDate().getTime()+500),
                new Date(), "tester", true, null);

        growerDiscountsReportDTOs.add(sameGrowerDiffDateRange);
        growerDiscountsReportDTOs.add(sameGrowerDiffDateRange2);

        return growerDiscountsReportDTOs;
    }


    @Test
    public void testValidatorThrowExceptionIfGrowerDiscountRangeValidationRuleFails() {
        GrowerDiscount growerDiscount = getValidGrowerDiscount();
        when(growerDiscountService.selectDiscountsBy(growerDiscount.getDocumentNumber(), null, true, null, null)).thenReturn(getValidGrowerDiscountsReportDTOListForGrowerDiscount(growerDiscount));

        //invalidates grower
        growerDiscount.setFromDate(new Date());
        growerDiscount.setToDate(new Date(growerDiscount.getFromDate().getTime()-1000));


        try{
            growerDiscountValidator.validate(growerDiscount);
            fail();
        }catch (GrowerDiscountConstraintViolationException e){
            Assert.assertTrue(!e.isEmpty());
        }

    }

    @Test
    public void testValidatorThrowExceptionIfGrowerDiscountDocumentValidationRuleFails() {
        GrowerDiscount growerDiscount = getValidGrowerDiscount();
        when(growerDiscountService.selectDiscountsBy(growerDiscount.getDocumentNumber(), null, true, null, null)).thenReturn(getValidGrowerDiscountsReportDTOListForGrowerDiscount(growerDiscount));

        //invalidates grower
        growerDiscount.setDocumentNumber("123456e");

        try{
            growerDiscountValidator.validate(growerDiscount);
            fail();
        }catch (GrowerDiscountConstraintViolationException e){
            Assert.assertTrue(!e.isEmpty());
        }

    }

    @Test
    public void testValidatorThrowExceptionIfGrowerDiscountValueValidationRuleFails() {
        GrowerDiscount growerDiscount = getValidGrowerDiscount();
        when(growerDiscountService.selectDiscountsBy(growerDiscount.getDocumentNumber(), null, true, null, null)).thenReturn(getValidGrowerDiscountsReportDTOListForGrowerDiscount(growerDiscount));

        //invalidates grower
        growerDiscount.setDiscountValue("-1");

        try{
            growerDiscountValidator.validate(growerDiscount);
            fail();
        }catch (GrowerDiscountConstraintViolationException e){
            Assert.assertTrue(!e.isEmpty());
        }

        //invalidates grower
        growerDiscount.setDiscountValue("148");

        try{
            growerDiscountValidator.validate(growerDiscount);
            fail();
        }catch (GrowerDiscountConstraintViolationException e){
            Assert.assertTrue(!e.isEmpty());
        }

        //invalidates grower
        growerDiscount.setDiscountValue("12a");

        try{
            growerDiscountValidator.validate(growerDiscount);
            fail();
        }catch (GrowerDiscountConstraintViolationException e){
            Assert.assertTrue(!e.isEmpty());
        }



    }



    private GrowerDiscount getValidGrowerDiscount(){
        Calendar calendarFrom = Calendar.getInstance();
        calendarFrom.set(2013, Calendar.SEPTEMBER, 1);

        Calendar calendarTo = Calendar.getInstance();
        calendarTo.set(2013, Calendar.DECEMBER, 1);


        GrowerDiscount growerDiscount = new GrowerDiscount();
        growerDiscount.setDocumentNumber("123456");
        growerDiscount.setFromDate(calendarFrom.getTime());
        growerDiscount.setToDate(calendarTo.getTime());
        growerDiscount.setDiscountValue("20");
        growerDiscount.setDescription("test");
        return growerDiscount;
    }



}
