package com.monsanto.brazilvaluecapture.jobs.executor.messaging.executors.impl;

import com.monsanto.brazilvaluecapture.core.foundation.service.BusinessException;
import com.monsanto.brazilvaluecapture.jobs.executor.messaging.bean.JobExecutionInfo;
import com.monsanto.brazilvaluecapture.pod.waybill.service.WaybillImportService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class FetchWaybillARExecutorCallback_UT {

    @Mock private WaybillImportService waybillImportService;
    @Mock private JobExecutionInfo jobExecutionInfo;
    @InjectMocks private FetchWaybillARExecutorCallback callback;

    @Test
    public void doWorkShouldSucceed() throws Exception {
        callback.doWork(jobExecutionInfo);

        verify(waybillImportService).doImportWaybills();
    }

    @Test
    public void doWorkShouldThrowJobExecutionExceptionWhenBusinessExceptionIsRaised() throws Exception {
        BusinessException exception = mock(BusinessException.class);
        doThrow(exception).when(waybillImportService).doImportWaybills();

        try {
            callback.doWork(jobExecutionInfo);
            fail();
        } catch (JobExecutionException ex) {
            verify(waybillImportService).doImportWaybills();
        }
    }

}