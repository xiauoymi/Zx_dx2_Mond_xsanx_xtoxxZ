package com.monsanto.brazilvaluecapture.jobs.executor.messaging.executors.impl;

import com.monsanto.brazilvaluecapture.core.base.model.bean.Company;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Crop;
import com.monsanto.brazilvaluecapture.core.foundation.service.BusinessException;
import com.monsanto.brazilvaluecapture.core.foundation.util.log.bean.JobLogEntry;
import com.monsanto.brazilvaluecapture.core.regionalization.VCCountry;
import com.monsanto.brazilvaluecapture.core.revenue.service.MultiplierSaleBillRevenueManager;
import com.monsanto.brazilvaluecapture.core.revenue.service.RevenueProblemSummaryException;
import com.monsanto.brazilvaluecapture.jobs.executor.messaging.bean.JobDefinition;
import com.monsanto.brazilvaluecapture.jobs.executor.messaging.bean.JobExecutionInfo;
import com.monsanto.brazilvaluecapture.multiplier.revenue.service.MultiplierSaleBillableProvider;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import static org.fest.assertions.Assertions.assertThat;
import static org.junit.Assert.fail;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doThrow;

@RunWith(MockitoJUnitRunner.class)
public class MultiplierSaleBillExecutorCallback_UT {

    private MultiplierSaleBillExecutorCallback multiplierSaleBillExecutorCallback;

    @Mock
    private MultiplierSaleBillableProvider mockMultiplierSaleBillableProvider;

    @Mock
    private MultiplierSaleBillRevenueManager mockMultiplierSaleBillRevenueManager;

    @Before
    public void setUp() throws Exception {
        multiplierSaleBillExecutorCallback = new MultiplierSaleBillExecutorCallback();
        multiplierSaleBillExecutorCallback.setBillableProvider(mockMultiplierSaleBillableProvider);
        multiplierSaleBillExecutorCallback.setMultiplierSaleBillRevenueManager(mockMultiplierSaleBillRevenueManager);
    }

    @Test
    public void testDoWork() throws Exception {
        //@Given
        Crop crop = new Crop();
        Company company = new Company("MONSANTO");
        JobExecutionInfo jobExecutionInfo = new JobExecutionInfo(crop, company, null,
                JobDefinition.BILL_MULTIPLIER_SALES, VCCountry.BRAZIL);
        JobLogEntry jobLogEntry = new JobLogEntry();
        jobExecutionInfo.setEntry(jobLogEntry);

        doNothing().when(mockMultiplierSaleBillRevenueManager).bill(mockMultiplierSaleBillableProvider,
                company);

        //@When
        multiplierSaleBillExecutorCallback.doWork(jobExecutionInfo);

        //@Then
        assertThat(jobLogEntry.getSummary()).isEqualTo(MultiplierSaleBillExecutorCallback.JOB_EXECUTED_SUCCESSFULLY);
    }

    @Test
    public void testDoWork_ThrowsRevenueProblemSummaryException() throws Exception {
        //@Given
        Crop crop = new Crop();
        Company company = new Company("MONSANTO");
        JobExecutionInfo jobExecutionInfo = new JobExecutionInfo(crop, company, null,
                JobDefinition.BILL_MULTIPLIER_SALES, VCCountry.BRAZIL);
        JobLogEntry jobLogEntry = new JobLogEntry();
        jobExecutionInfo.setEntry(jobLogEntry);

        RevenueProblemSummaryException exception = new RevenueProblemSummaryException("REVENUE_PROBLEM_EXCEPTION");
        exception.addException(new Exception("EXCEPTION_1"));
        doThrow(exception).when(mockMultiplierSaleBillRevenueManager).bill(mockMultiplierSaleBillableProvider,
                company);

        //@When
        try {
            multiplierSaleBillExecutorCallback.doWork(jobExecutionInfo);
            fail("Should not be executed");
        } catch (Exception ex) {
            assertThat(ex).isInstanceOf(JobExecutionException.class);
            assertThat(ex.getMessage()).isEqualTo("Error executing sale billing REVENUE_PROBLEM_EXCEPTION: EXCEPTION_1");
        }

        //@Then
        assertThat(jobLogEntry.getSummary()).isEqualTo("Job executed with 1 exceptions");
    }


    @Test
    public void testDoWork_ThrowsException() throws Exception {
        //@Given
        Crop crop = new Crop();
        Company company = new Company("MONSANTO");
        JobExecutionInfo jobExecutionInfo = new JobExecutionInfo(crop, company, null,
                JobDefinition.BILL_MULTIPLIER_SALES, VCCountry.BRAZIL);
        JobLogEntry jobLogEntry = new JobLogEntry();
        jobExecutionInfo.setEntry(jobLogEntry);

        BusinessException exception = new BusinessException("EXCEPTION");
        doThrow(exception).when(mockMultiplierSaleBillRevenueManager).bill(mockMultiplierSaleBillableProvider,
                company);

        //@When
        try {
            multiplierSaleBillExecutorCallback.doWork(jobExecutionInfo);
            fail("Should not be executed");
        } catch (Exception ex) {
            assertThat(ex).isInstanceOf(JobExecutionException.class);
            assertThat(ex.getMessage()).isEqualTo("Error executing sale billing EXCEPTION");
        }

        //@Then
        assertThat(jobLogEntry.getEntryItemsTransient().toString()).isEqualTo("[EXCEPTION]");
        assertThat(jobLogEntry.getSummary()).isEqualTo("Job executed with exception");
    }
}