package com.monsanto.brazilvaluecapture.jobs.importfile.messaging.executor.impl;

import static org.fest.reflect.core.Reflection.field;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyCollectionOf;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;

import com.monsanto.brazilvaluecapture.core.importfile.model.bean.CsvImportFile;
import com.monsanto.brazilvaluecapture.jobs.importfile.messaging.bean.FileImportInfo;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.CsvMultiplierSaleImportLine;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.Indexable;
import com.monsanto.brazilvaluecapture.seedsale.sale.service.SaleService;

/**
 * Test for class {@link CsvMultiplierSaleFileCallback}
 * 
 * @author CSOBR1
 *
 */
public class CsvMultiplierSaleFileCallback_UT {

	/**
	 * Class under test.
	 */
	private CsvMultiplierSaleFileCallback test;
	
	private SaleService saleService;
	
	@Before
	@SuppressWarnings("unchecked")
    public void setUp() throws Exception {
		test = new CsvMultiplierSaleFileCallback();
		
		saleService = mock(SaleService.class);
		List<CsvMultiplierSaleImportLine> list = new ArrayList<CsvMultiplierSaleImportLine>();
		list.add(mock(CsvMultiplierSaleImportLine.class));
		when(saleService.selectCsvImportLinesByFile(
				any(Class.class), any(CsvImportFile.class))).thenReturn(list); 
		field("saleService").ofType(SaleService.class).in(test).set(saleService);
    }
	
	@Test
	public void test_protectedMethod_doImport() {
		FileImportInfo fileImportInfo = mock(FileImportInfo.class);
		when(fileImportInfo.getFile()).thenReturn(mock(CsvImportFile.class));
		
		test.doImport(fileImportInfo);
		
		verify(saleService).saveFileAndLines(any(CsvImportFile.class), anyCollectionOf(Indexable.class));
	}
	
	@Test
	public void test_protectedMethod_doProceed() {
		FileImportInfo fileImportInfo = mock(FileImportInfo.class);
		when(fileImportInfo.getFile()).thenReturn(mock(CsvImportFile.class));
		
		test.doProceed(fileImportInfo);
		
		verify(saleService).saveFileAndLines(any(CsvImportFile.class), anyCollectionOf(Indexable.class));
	}

}
