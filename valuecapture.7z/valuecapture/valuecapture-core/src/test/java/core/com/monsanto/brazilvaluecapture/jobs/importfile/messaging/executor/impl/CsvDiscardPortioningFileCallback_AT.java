package com.monsanto.brazilvaluecapture.jobs.importfile.messaging.executor.impl;


import com.monsanto.brazilvaluecapture.core.base.model.bean.Company;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Crop;
import com.monsanto.brazilvaluecapture.core.base.model.bean.OperationalYear;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Customer;
import com.monsanto.brazilvaluecapture.core.foundation.service.BusinessException;
import com.monsanto.brazilvaluecapture.core.foundation.test.AbstractServiceIntegrationTests;
import com.monsanto.brazilvaluecapture.core.foundation.test.dbunit.DbUnitHelper;
import com.monsanto.brazilvaluecapture.core.grower.model.bean.Grower;
import com.monsanto.brazilvaluecapture.core.importfile.model.ImportFileType;
import com.monsanto.brazilvaluecapture.core.importfile.model.bean.CsvImportFile;
import com.monsanto.brazilvaluecapture.core.importfile.model.dao.CsvImportFileFilter;
import com.monsanto.brazilvaluecapture.core.importfile.service.CsvImportFileService;
import com.monsanto.brazilvaluecapture.core.io.ProcessorConfig;
import com.monsanto.brazilvaluecapture.core.io.ProcessorConfig.ProcessorConfigProperties;
import com.monsanto.brazilvaluecapture.core.user.model.bean.ItsUser;
import com.monsanto.brazilvaluecapture.core.user.model.bean.ItsUser.UserTypeEnum;
import com.monsanto.brazilvaluecapture.core.user.model.bean.UserDecorator;
import com.monsanto.brazilvaluecapture.jobs.importfile.messaging.bean.FileImportDefinition;
import com.monsanto.brazilvaluecapture.jobs.importfile.messaging.bean.FileImportInfo;
import com.monsanto.brazilvaluecapture.jobs.importfile.messaging.bean.FileImportOperation;
import com.monsanto.brazilvaluecapture.multiplier.cultivar.model.bean.Cultivar;
import com.monsanto.brazilvaluecapture.multiplier.discardportioning.model.bean.DiscardPortioningImportDTO;
import com.monsanto.brazilvaluecapture.multiplier.itsclass.model.bean.ItsClass;
import com.monsanto.brazilvaluecapture.multiplier.obtainer.model.bean.Obtainer;
import com.monsanto.brazilvaluecapture.multiplier.volumereport.model.bean.DiscardPortioningCsvImportedLine;
import com.monsanto.brazilvaluecapture.multiplier.volumereport.model.bean.VolumeReportDetail;
import com.monsanto.brazilvaluecapture.multiplier.volumereport.service.parser.DiscardPortioningProcessor;
import com.monsanto.brazilvaluecapture.seedsale.harvest.model.bean.Harvest;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.ImportFileStatus;
import junit.framework.Assert;
import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.math.BigDecimal;
import java.util.List;
import java.util.Locale;
import java.util.ResourceBundle;


/**
 * 
 * @author carlos
 *
 */
public class CsvDiscardPortioningFileCallback_AT extends AbstractServiceIntegrationTests {
	
	private static final String CSV_HEADER = "Descarte para Cooperante;Ano Operacional;Nome da Safra;Tipo Documento Filial;N�mero Documento Filial;C�digo ERP Filial;Nome Obtentora;Abrevia��o da Classe;C�digo Cultivar;Tipo Documento Cooperante;N�mero Documento Cooperante;�rea Hectare";

	@Autowired
	@Qualifier("discardPortioningProcessor")
	private DiscardPortioningProcessor discardPortioningProcessor;
	
	@Autowired
	private CsvDiscardPortioningFileCallback csvDiscardPortioningFileCallback;
	
	@Autowired
    private CsvImportFileService csvImportFileService;
    
	private Locale localeBR = new Locale("pt", "BR");
	private ResourceBundle resourceBundle = ResourceBundle.getBundle("bundle/bundle");

	private ProcessorConfig processorConfig;
	
	private UserDecorator decorator;
	
	private OperationalYear operationalYear;

	private Harvest harvest;

	private Company company;

	private Crop crop;

	private Customer customer;

	private Obtainer obtainer;

	private ItsClass itsClass;

	private Cultivar cultivar;
	
	private Grower cooperative;

	private VolumeReportDetail detail;

	private Customer matrix;
	
	@Before
	public void setup() {
		UserDecorator decorator = new UserDecorator(null, new ItsUser("userLogin", UserTypeEnum.SUPER));
		
		processorConfig = new ProcessorConfig();
        processorConfig.put(ProcessorConfigProperties.SELECTED_LOCALE, localeBR);
        processorConfig.put(ProcessorConfigProperties.LOGGED_USER, decorator);
        processorConfig.put(ProcessorConfigProperties.FILENAME, "sample.csv");
        processorConfig.put(ProcessorConfigProperties.BUNDLE, resourceBundle);
	
        DbUnitHelper.setup(
                "classpath:data/multiplier/basic-fixture.xml",
                "classpath:data/multiplier/discard-portioning-dataset.xml");
        
        detail = (VolumeReportDetail) getSession().get(VolumeReportDetail.class, 900000005L);
        detail.getEnteredArea().setValue(BigDecimal.TEN);
        saveAndFlush(detail);
		harvest = detail.getVolumeReportHeader().getHarvest(); // 900000001L
        operationalYear = harvest.getOperationalYear();
        company = harvest.getCompany();
        crop = harvest.getCrop();
        matrix = detail.getVolumeReportHeader().getMatrix(); // 900000004L
		customer = detail.getVolumeReportHeader().getCustomer(); // 900000003L
		obtainer = detail.getVolumeReportHeader().getObtainer(); // 900000001L
		itsClass = detail.getItsClass(); // 900000001L
		cultivar = detail.getCultivar(); // 900000001L
		cooperative = (Grower) getSession().get(Grower.class, 900000005L);
    }
	
	@Test
	public void given_valid_csv_line_when_awaiting_cancelling_and_orper_cancel_status_should_be_cancelled() throws IOException, BusinessException {
		
		initProcessorConfigDTO(crop, company, customer);
		
		InputStream resourceAsStream = getCsvInputStream();
		CsvImportFile csvImportFile = discardPortioningProcessor.readLines(resourceAsStream, processorConfig);

		csvImportFile.setFileStatus(ImportFileStatus.AWAITING_CANCELLING);
		
		createValidLine(csvImportFile);
		
		csvDiscardPortioningFileCallback.setBundle(resourceBundle, localeBR);
		csvDiscardPortioningFileCallback.importFileCallback(new FileImportInfo(csvImportFile,
				decorator, FileImportDefinition.CSV_DISCARD_PORTIONING,
				FileImportOperation.CANCEL, localeBR, "bundle"));
		
		List<CsvImportFile> lines = csvImportFileService.selectByFilter(CsvImportFileFilter.getInstance()
				.addImportFileStatus(ImportFileStatus.CANCELLED)
				.addImportFileType(ImportFileType.CSV_DISCARD_PORTIONING));
		
		Assert.assertEquals(1, lines.size());
	}
	
	@Test
	public void given_valid_csv_line_when_uploaded_and_orper_import_status_should_be_awaiting_confirm() throws IOException, BusinessException {
		
		initProcessorConfigDTO(crop, company, customer);
		
		InputStream resourceAsStream = getCsvInputStream();
		CsvImportFile csvImportFile = discardPortioningProcessor.readLines(resourceAsStream, processorConfig);
		
		createValidLine(csvImportFile);
		
		csvImportFile.setFileStatus(ImportFileStatus.UPLOADED);

		csvDiscardPortioningFileCallback.setBundle(resourceBundle, localeBR);
		
		csvDiscardPortioningFileCallback.importFileCallback(new FileImportInfo(csvImportFile,
				decorator, FileImportDefinition.CSV_DISCARD_PORTIONING,
				FileImportOperation.IMPORT, localeBR, "bundle"));
		
		List<CsvImportFile> lines = csvImportFileService.selectByFilter(CsvImportFileFilter.getInstance()
				.addImportFileStatus(ImportFileStatus.AWAITING_CONFIRM)
				.addImportFileType(ImportFileType.CSV_DISCARD_PORTIONING));
		
		Assert.assertEquals(1, lines.size());

	}
		
	@Test
	public void given_valid_csv_line_when_awaiting_processing_and_orper_proceed_status_should_be_processed() throws IOException, BusinessException {
		
		initProcessorConfigDTO(crop, company, customer);
		
		InputStream resourceAsStream = getCsvInputStream();
		CsvImportFile csvImportFile = discardPortioningProcessor.readLines(resourceAsStream, processorConfig);
		
		createValidLine(csvImportFile);
		
		csvImportFile.setFileStatus(ImportFileStatus.AWAITING_PROCESSING);
		getSession().saveOrUpdate(csvImportFile);

		csvDiscardPortioningFileCallback.setBundle(resourceBundle, localeBR);
		
		csvDiscardPortioningFileCallback.importFileCallback(new FileImportInfo(csvImportFile,
				decorator, FileImportDefinition.CSV_DISCARD_PORTIONING,
				FileImportOperation.PROCEED, localeBR, "bundle"));
		
		List<CsvImportFile> lines = csvImportFileService.selectByFilter(CsvImportFileFilter.getInstance()
				.addImportFileStatus(ImportFileStatus.PROCESSED)
				.addImportFileType(ImportFileType.CSV_DISCARD_PORTIONING));
		
		Assert.assertEquals(1, lines.size());
	}
	
	private InputStream getCsvInputStream() {
		
		StringBuilder csv = createLineForInputStream(null, "S",
				operationalYear.getYear(),
				harvest.getDescription(),
				customer.getDocument().getDocumentTypeDescription(),
				customer.getDocumentValue(),
				customer.getCustomerSAPCode(),
				obtainer.getDescription(),
				itsClass.getAbbreviation(),
				cultivar.getDescription(), 
				cooperative.getDocument().getDocumentTypeDescription(), 
				cooperative.getDocumentValue(),
				"500");
		
		return new ByteArrayInputStream(csv.toString().getBytes());
	}
	
	private StringBuilder createLineForInputStream(StringBuilder csv,
			String cooperativeDiscard, String operationalYear, String harvest,
			String customerDocumentType, String customerDocument, String customerSAPCode,
			String obtainer, String classAbbreaviation,
			String cultivarDescription, String cooperativeDocumentType,
			String cooperativeDocument, String area) {
		
        if(csv==null) {
            csv = new StringBuilder(CSV_HEADER);
            csv.append("\n");
        }

		csv.append(cooperativeDiscard == null ? "" : cooperativeDiscard).append(";");
		csv.append(operationalYear == null ? "" : operationalYear).append(";");
		csv.append(harvest == null ? "" : harvest).append(";");
		csv.append(customerDocumentType == null ? "" : customerDocumentType).append(";");
		csv.append(customerDocument == null ? "" : customerDocument).append(";");
		csv.append(customerSAPCode == null ? "" : customerSAPCode).append(";");
		csv.append(obtainer == null ? "" : obtainer).append(";");
		csv.append(classAbbreaviation == null ? "" : classAbbreaviation).append(";");
		csv.append(cultivarDescription == null ? "" : cultivarDescription).append(";");
		csv.append(cooperativeDocumentType == null ? "" : cooperativeDocumentType).append(";");
		csv.append(cooperativeDocument == null ? "" : cooperativeDocument).append(";");
		csv.append(area == null ? "" : area);
        
        csv.append("\n");
        
        return csv;
    }
	
    private void initProcessorConfigDTO(Crop crop, Company company, Customer matrix) {
        DiscardPortioningImportDTO dto = new DiscardPortioningImportDTO();
        dto.setCompany(company);
        dto.setCrop(crop);
        dto.setMatrix(matrix);
        processorConfig.put(ProcessorConfigProperties.DTO,dto);
    }
    
	private void createValidLine(CsvImportFile csvImportFile) {
		DiscardPortioningCsvImportedLine line = createImportedLine(csvImportFile,
				"S",
				operationalYear.getYear(),
				harvest.getDescription(),
				customer.getDocument().getDocumentTypeDescription(),
				customer.getDocumentValue(),
				customer.getCustomerSAPCode(),
				obtainer.getDescription(),
				itsClass.getAbbreviation(),
				cultivar.getDescription(), 
				cooperative.getDocument().getDocumentTypeDescription(), 
				cooperative.getDocumentValue(), new BigDecimal("500"), 1);
		
		line.setCropCode(crop.getId());
		line.setCompanyCode(company.getId());
		line.setMatrixCode(matrix.getId());

		saveAndFlush(line);
	}
	
	private DiscardPortioningCsvImportedLine createImportedLine(
			CsvImportFile csvImportFile, String cooperativeDiscard,
			String operationalYearDescription, String harvestDescription,
			String customerDocumentType, String customerDocument,
			String customerSAPCode, String obtainerDescription,
			String classDescription, String cultivarDescription,
			String cooperativeDocumentType, String cooperativeDocument,
			BigDecimal area, int lineNumber) {
		DiscardPortioningCsvImportedLine line = new DiscardPortioningCsvImportedLine();
		line.setCooperativeDiscard(cooperativeDiscard);
		line.setOperationalYearDescription(operationalYearDescription);
		line.setHarvestDescription(harvestDescription);
		line.setCustomerDocumentTypeDescription(customerDocumentType);
		line.setCustomerDocument(customerDocument);
		line.setCustomerSAPCode(customerSAPCode);
		line.setObtainerDescription(obtainerDescription);
		line.setClassAbbreviation(classDescription);
		line.setCultivarDescription(cultivarDescription);
		line.setCooperativeDocumentTypeDescription(cooperativeDocumentType);
		line.setCooperativeDocument(cooperativeDocument);
		line.setArea(area);
		line.setLine(lineNumber);
		line.setCsvImportFile(csvImportFile);
		return line;
	}

}
