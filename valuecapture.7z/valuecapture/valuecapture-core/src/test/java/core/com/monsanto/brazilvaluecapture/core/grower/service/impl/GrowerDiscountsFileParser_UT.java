package com.monsanto.brazilvaluecapture.core.grower.service.impl;

import com.monsanto.brazilvaluecapture.core.foundation.util.ConstraintViolation;
import com.monsanto.brazilvaluecapture.core.foundation.util.csv.CSVReadableInvalidException;
import com.monsanto.brazilvaluecapture.core.grower.model.bean.Agreement;
import com.monsanto.brazilvaluecapture.core.grower.model.bean.AgreementTemplate;
import com.monsanto.brazilvaluecapture.core.grower.model.bean.GrowerDiscount;
import com.monsanto.brazilvaluecapture.core.grower.service.GrowerConstraintViolationException;
import com.monsanto.brazilvaluecapture.core.grower.service.GrowerDiscountService;
import com.monsanto.brazilvaluecapture.core.grower.validation.*;
import junit.framework.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.*;

import static org.fest.reflect.core.Reflection.field;
import static org.junit.Assert.fail;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;

/**
 * Created with IntelliJ IDEA.
 * User: AFREI
 * Date: 27/12/13
 * Time: 15:52
 */
public class GrowerDiscountsFileParser_UT {

    private String CUIT_PRODUCTOR = "27324612888";
    private String DESCUENTO = "20";
    private String OBSERVACIONES = "test";
    private SimpleDateFormat DATE_FORMAT=new SimpleDateFormat("dd/MM/yyyy");

    @Mock
    private GrowerDiscountService growerDiscountService;

    @Mock
    private GrowerDiscountValidator growerDiscountValidatorThrowsExceptionValidate;

    @InjectMocks
    private GrowerDiscountsFileParser invalidFileParser;

    @InjectMocks
    private GrowerDiscountsFileParser validFileParser;



    @Mock
    private ResourceBundle resourceBundle;

    private final static String SEPARATOR=";";

    private GrowerDiscountUniqueForGivenRangeValidationRule growerDiscountUniqueForGivenRangeValidationRule;
    private GrowerDiscountRangeValidationRule growerDiscountRangeValidationRule;
    private GrowerDiscountDocumentValidationRule growerDiscountDocumentValidationRule;
    private GrowerDiscountValueValidationRule growerDiscountValueValidationRule;
    private GrowerDiscountValidator growerDiscountValidator;


    @Before
    public void setUp() throws GrowerDiscountConstraintViolationException, IOException {


        MockitoAnnotations.initMocks(this);



        List<ConstraintViolation> constraintViolations=new ArrayList<ConstraintViolation>();
        constraintViolations.add(new ConstraintViolation("msg","code","field"));

        doThrow(new GrowerDiscountConstraintViolationException("", constraintViolations)).when(growerDiscountValidatorThrowsExceptionValidate).validate(Matchers.<GrowerDiscount>any());

        Locale locale=new Locale("ar","AR");

        growerDiscountValidator = new GrowerDiscountValidator();

        growerDiscountUniqueForGivenRangeValidationRule = new GrowerDiscountUniqueForGivenRangeValidationRule();
        field("growerDiscountService").ofType(GrowerDiscountService.class).in(growerDiscountUniqueForGivenRangeValidationRule).set(growerDiscountService);
        field("growerDiscountUniqueForGivenRangeValidationRule").ofType(GrowerDiscountUniqueForGivenRangeValidationRule.class).in(growerDiscountValidator).set(growerDiscountUniqueForGivenRangeValidationRule);

        growerDiscountRangeValidationRule = new GrowerDiscountRangeValidationRule();
        field("growerDiscountRangeValidationRule").ofType(GrowerDiscountRangeValidationRule.class).in(growerDiscountValidator).set(growerDiscountRangeValidationRule);

        growerDiscountDocumentValidationRule = new GrowerDiscountDocumentValidationRule();
        field("growerDiscountDocumentValidationRule").ofType(GrowerDiscountDocumentValidationRule.class).in(growerDiscountValidator).set(growerDiscountDocumentValidationRule);

        growerDiscountValueValidationRule = new GrowerDiscountValueValidationRule();
        field("growerDiscountValueValidationRule").ofType(GrowerDiscountValueValidationRule.class).in(growerDiscountValidator).set(growerDiscountValueValidationRule);

        growerDiscountValidator.createRules();

        doNothing().when(growerDiscountService).save(any(GrowerDiscount.class));
        validFileParser = new GrowerDiscountsFileParser(resourceBundle,growerDiscountService,"test",createValidInputStream(),locale,"User",growerDiscountValidator);
        invalidFileParser = new GrowerDiscountsFileParser(resourceBundle,growerDiscountService,"test",createInValidInputStream(),locale,"User",growerDiscountValidator);

    }


    private InputStream createValidInputStream() throws IOException {
        Calendar todayDate = Calendar.getInstance();
        todayDate.set(2013, 9, 26);
        Date FECHA_DESDE = todayDate.getTime();
        todayDate.add(Calendar.MONTH,6);
        Date FECHA_HASTA = todayDate.getTime();

        ByteArrayOutputStream outputStream=new ByteArrayOutputStream();

        StringBuilder header=new StringBuilder("documentNumber").append(SEPARATOR).append("discount").append(SEPARATOR).append("dateFrom");
        header.append(SEPARATOR).append("dateTo").append(SEPARATOR).append("observation\n");

        StringBuilder line=new StringBuilder(CUIT_PRODUCTOR).append(SEPARATOR).append(DESCUENTO).append(SEPARATOR);
        line.append(DATE_FORMAT.format(FECHA_DESDE)).append(SEPARATOR);
        line.append((DATE_FORMAT.format(FECHA_HASTA))).append(SEPARATOR).append(OBSERVACIONES);

        outputStream.write(header.toString().getBytes());
        outputStream.write(line.toString().getBytes());

        InputStream inputStream = new ByteArrayInputStream(outputStream.toByteArray());
        outputStream.close();
        return inputStream;
    }


    private InputStream createInValidInputStream() throws IOException {
        Calendar todayDate = Calendar.getInstance();
        todayDate.set(2013, 9, 26);
        Date FECHA_DESDE = todayDate.getTime();
        todayDate.add(Calendar.MONTH, -6);
        Date FECHA_HASTA = todayDate.getTime();

        ByteArrayOutputStream outputStream=new ByteArrayOutputStream();

        StringBuilder header=new StringBuilder("documentNumber").append(SEPARATOR).append("discount").append(SEPARATOR).append("dateFrom");
        header.append(SEPARATOR).append("dateTo").append(SEPARATOR).append("observation\n");

        StringBuilder line=new StringBuilder(CUIT_PRODUCTOR).append(SEPARATOR).append(DESCUENTO).append(SEPARATOR);
        line.append(DATE_FORMAT.format(FECHA_DESDE)).append(SEPARATOR);
        line.append((DATE_FORMAT.format(FECHA_HASTA))).append(SEPARATOR).append(OBSERVACIONES);

        outputStream.write(header.toString().getBytes());
        outputStream.write(line.toString().getBytes());

        InputStream inputStream = new ByteArrayInputStream(outputStream.toByteArray());
        outputStream.close();
        return inputStream;
    }

    private InputStream createInValidLayoutInputStream() throws IOException {
        Calendar todayDate = Calendar.getInstance();
        todayDate.set(2013, 9, 26);
        Date FECHA_DESDE = todayDate.getTime();
        todayDate.add(Calendar.MONTH, -6);
        Date FECHA_HASTA = todayDate.getTime();

        ByteArrayOutputStream outputStream=new ByteArrayOutputStream();

        StringBuilder header=new StringBuilder("documentNumber").append(SEPARATOR).append("discount").append(SEPARATOR).append("dateFrom");
        header.append(SEPARATOR).append("dateTo").append(SEPARATOR).append("observation\n");

        StringBuilder line=new StringBuilder(CUIT_PRODUCTOR).append(SEPARATOR).append(DESCUENTO).append(SEPARATOR);
        line.append(DATE_FORMAT.format(FECHA_DESDE)).append(SEPARATOR).append("INVALID FIELD").append(SEPARATOR);
        line.append((DATE_FORMAT.format(FECHA_HASTA))).append(SEPARATOR).append(OBSERVACIONES);

        outputStream.write(header.toString().getBytes());
        outputStream.write(line.toString().getBytes());

        InputStream inputStream = new ByteArrayInputStream(outputStream.toByteArray());
        outputStream.close();
        return inputStream;
    }

    @Test
    public void read_ShouldAddWarnings_WhenFileHasInvalidRecords(){

        try {

            invalidFileParser.readFile();
            invalidFileParser.process();

            Assert.assertEquals(1, invalidFileParser.getErrorLines());
            Assert.assertEquals(0,invalidFileParser.getSuccessLines());

        } catch (CSVReadableInvalidException e) {
            fail();
        }
    }

    @Test
    public void read_ShouldNotAddWarnings_WhenFileHasInvalidRecords(){

        try {

            validFileParser.readFile();
            validFileParser.process();

            Assert.assertEquals(0, validFileParser.getErrorLines());
            Assert.assertEquals(1,validFileParser.getSuccessLines());

        } catch (CSVReadableInvalidException e) {
            fail();
        }
    }
}
