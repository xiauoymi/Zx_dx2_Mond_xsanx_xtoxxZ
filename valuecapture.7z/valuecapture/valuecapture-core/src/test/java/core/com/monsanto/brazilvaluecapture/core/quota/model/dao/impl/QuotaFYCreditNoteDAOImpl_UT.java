package com.monsanto.brazilvaluecapture.core.quota.model.dao.impl;

import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.hibernate.classic.Session;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.math.BigDecimal;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class QuotaFYCreditNoteDAOImpl_UT {

    private static final Long WAREHOUSE_ID = Long.valueOf(7);
    private static final String REFERENCE_INVOICE_NUMBER = "1";
    private static final BigDecimal SUM = BigDecimal.ONE;

    @Mock private SessionFactory sessionFactory;
    @InjectMocks private QuotaFYCreditNoteDAOImpl dao;
    @Mock private Session session;
    @Mock private Query query;

    @Before
    public void setUp() {
        when(sessionFactory.getCurrentSession()).thenReturn(session);
    }

    @Test
    public void getEntryValueSumShouldSucceed() {
        when(session.createQuery(any(String.class))).thenReturn(query);
        when(query.setString(any(String.class), any(String.class))).thenReturn(query);
        when(query.setLong(any(String.class), any(Long.class))).thenReturn(query);
        when(query.uniqueResult()).thenReturn(SUM);

        BigDecimal result = dao.getEntryValueSum(WAREHOUSE_ID, REFERENCE_INVOICE_NUMBER);

        assertEquals(SUM, result);
        verify(query).setLong("wareHouseId", WAREHOUSE_ID);
        verify(query).setString("referenceInvoiceNumber", REFERENCE_INVOICE_NUMBER);
    }

    @Test
    public void getEntryValueSumShouldSucceedWhenNotFound() {
        when(session.createQuery(any(String.class))).thenReturn(query);
        when(query.setString(any(String.class), any(String.class))).thenReturn(query);
        when(query.setLong(any(String.class), any(Long.class))).thenReturn(query);
        when(query.uniqueResult()).thenReturn(null);

        BigDecimal result = dao.getEntryValueSum(WAREHOUSE_ID, REFERENCE_INVOICE_NUMBER);

        assertEquals(BigDecimal.ZERO, result);
        verify(query).setLong("wareHouseId", WAREHOUSE_ID);
        verify(query).setString("referenceInvoiceNumber", REFERENCE_INVOICE_NUMBER);
    }

}