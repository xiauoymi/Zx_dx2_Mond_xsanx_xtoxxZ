package com.monsanto.brazilvaluecapture.sqlnative.constraint;

import com.monsanto.brazilvaluecapture.core.base.SystemTestFixture;
import com.monsanto.brazilvaluecapture.core.foundation.model.bean.StatusEnum;
import com.monsanto.brazilvaluecapture.core.foundation.service.BusinessException;
import com.monsanto.brazilvaluecapture.core.foundation.test.AbstractServiceIntegrationTests;
import com.monsanto.brazilvaluecapture.seedsale.harvest.HarvestTestData;
import com.monsanto.brazilvaluecapture.seedsale.harvest.model.bean.Harvest;
import com.monsanto.brazilvaluecapture.seedsale.harvest.model.bean.Plantability;
import com.monsanto.brazilvaluecapture.seedsale.product.PlantabilityTestData;
import com.monsanto.brazilvaluecapture.seedsale.product.ProductTestData;
import com.monsanto.brazilvaluecapture.seedsale.product.ProductivityTestData;
import com.monsanto.brazilvaluecapture.seedsale.product.model.bean.Product;
import com.monsanto.brazilvaluecapture.seedsale.product.model.bean.Productivity;
import com.monsanto.brazilvaluecapture.seedsale.product.model.bean.ProductivityValue;
import com.monsanto.brazilvaluecapture.seedsale.product.model.dao.ProductivityDAO;
import com.monsanto.brazilvaluecapture.seedsale.product.service.ProductivityAlreadyProductInProductvityValues;
import com.monsanto.brazilvaluecapture.seedsale.product.service.ProductivityService;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.math.BigDecimal;

@Ignore
public class Productivity_Constraint_AT extends AbstractServiceIntegrationTests {
	
	@Autowired
	private ProductivityService productivityService;
	
	@Autowired
	ProductivityDAO productivityDAO;

	
	private Harvest harvest;
	
	private Plantability plantability;
	
	private Productivity productivityCreated;
	
	private Product product;
	
	@Before
	public void init() {
		systemTestFixture = new SystemTestFixture(this);
		
		harvest = HarvestTestData.createHarvest(this.systemTestFixture.soy, this.systemTestFixture.operationalYearOf2011, systemTestFixture.monsantoBr);
		getSession().saveOrUpdate(harvest);
		
		plantability = PlantabilityTestData.createPlantability(harvest);
		getSession().saveOrUpdate(plantability);
		
		productivityCreated = ProductivityTestData.createProductivity(this.systemTestFixture.matoGrossoDoSul, plantability);
    	getSession().saveOrUpdate(productivityCreated);
		
    	product = ProductTestData.createProduct(this.systemTestFixture.monsoy, this.systemTestFixture.soy, this.systemTestFixture.intacta, StatusEnum.ACTIVE, this.systemTestFixture.monsantoBr);
    	getSession().saveOrUpdate(product);
    	
		getSession().flush();
	}

	@Test (expected=ProductivityAlreadyProductInProductvityValues.class)
	public void when_insert_the_same_product_in_productivityValue_mustRiseException() throws ProductivityAlreadyProductInProductvityValues {
		Productivity productivityCreated = ProductivityTestData.createProductivityValue(this.systemTestFixture.matoGrossoDoSul, plantability, product);
		ProductivityTestData.addProductivityValue(productivityCreated, product);
		try{
			productivityDAO.save(productivityCreated);
			Assert.fail();
		}catch (ProductivityAlreadyProductInProductvityValues e) {
			throw new ProductivityAlreadyProductInProductvityValues(e.getMessage(), e.getCause());
		}
	}


	@Test(expected=ProductivityAlreadyProductInProductvityValues.class)
	public void when_productivity_values_already_contains_a_product_ShouldRiseAProductivityAlreadyProductInProductvityValues() throws BusinessException{
		Productivity productivity = ProductivityTestData.createProductivity(this.systemTestFixture.matoGrossoDoSul, plantability);
		
		ProductivityValue productivityValue1 = ProductivityTestData.addProductivityValue(productivity, product);
		productivityValue1.setProductivityMin(productivityValue1.getProductivityMax().subtract(BigDecimal.valueOf(1L)));
		
		ProductivityValue productivityValue2 = ProductivityTestData.addProductivityValue(productivity, product);
		productivityValue2.setProductivityMin(productivityValue2.getProductivityMax().subtract(BigDecimal.valueOf(1L)));
			
		productivityService.save(productivity);
		
	}
}
