package com.monsanto.brazilvaluecapture.seedsale.cashAdvance.report;

import com.monsanto.brazilvaluecapture.seedsale.cashAdvance.model.dto.CashAdvanceReportResponseDTO;
import com.monsanto.brazilvaluecapture.seedsale.cashAdvance.model.dto.CashAdvanceReportType;
import com.monsanto.brazilvaluecapture.seedsale.sale.report.ReportOutputTypeEnum;
import junit.framework.Assert;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

import static org.junit.Assert.assertEquals;

public class CashAdvanceReportAssembler_UT {



    @Test
    public void testBuildAssembler_WhenReportTypeIsBalance(){
        //@Given
        List<CashAdvanceReportResponseDTO> cashAdvanceList = new ArrayList<CashAdvanceReportResponseDTO>();
        ReportOutputTypeEnum reportOutputType = ReportOutputTypeEnum.XLS;
        CashAdvanceReportType cashAdvanceReportType = CashAdvanceReportType.BALANCE;
        ResourceBundle resourceBundle = null;
        CashAdvanceReportAssembler result = null;
        //@When
        try {
            result = CashAdvanceReportAssembler.buildAssembler(cashAdvanceList, reportOutputType, cashAdvanceReportType, resourceBundle);
        }catch (Exception e){
            e.printStackTrace();
            Assert.fail("Should not trow");
        }

        //@Should
        assertEquals(result.getClass(), CashAdvanceBalanceReportAssembler.class);
    }

    @Test
    public void testBuildAssembler_WhenReportTypeIsConsumption(){
        //@Given
        List<CashAdvanceReportResponseDTO> cashAdvanceList = new ArrayList<CashAdvanceReportResponseDTO>();
        ReportOutputTypeEnum reportOutputType = ReportOutputTypeEnum.XLS;
        CashAdvanceReportType cashAdvanceReportType = CashAdvanceReportType.CONSUMPTIONS;
        ResourceBundle resourceBundle = null;
        CashAdvanceReportAssembler result = null;
        //@When
        try {
            result = CashAdvanceReportAssembler.buildAssembler(cashAdvanceList, reportOutputType, cashAdvanceReportType, resourceBundle);
        }catch (Exception e){
            e.printStackTrace();
            Assert.fail("Should not trow");
        }

        //@Should
        assertEquals(result.getClass(), CashAdvanceConsumptionReportAssembler.class);
    }

    @Test
    public void testBuildAssembler_WhenReportTypeIsTransaction(){
        //@Given
        List<CashAdvanceReportResponseDTO> cashAdvanceList = new ArrayList<CashAdvanceReportResponseDTO>();
        ReportOutputTypeEnum reportOutputType = ReportOutputTypeEnum.XLS;
        CashAdvanceReportType cashAdvanceReportType = CashAdvanceReportType.TRANSACTIONS;
        ResourceBundle resourceBundle = null;
        CashAdvanceReportAssembler result = null;
        //@When
        try {
            result = CashAdvanceReportAssembler.buildAssembler(cashAdvanceList, reportOutputType, cashAdvanceReportType, resourceBundle);
        }catch (Exception e){
            e.printStackTrace();
            Assert.fail("Should not trow");
        }

        //@Should
        assertEquals(result.getClass(), CashAdvanceTransactionReportAssembler.class);
    }

    @Test
    public void test(){
        //@Given

        //@When
        //CashAdvanceReportAssembler

        //@Should
    }

}