package com.monsanto.brazilvaluecapture.core.grower;

import com.monsanto.brazilvaluecapture.core.base.model.bean.BillingAddress;
import com.monsanto.brazilvaluecapture.core.base.model.bean.BusinessAddress;
import com.monsanto.brazilvaluecapture.core.base.model.bean.City;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Country;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Document;
import com.monsanto.brazilvaluecapture.core.base.model.bean.DocumentType;
import com.monsanto.brazilvaluecapture.core.base.model.bean.State;
import com.monsanto.brazilvaluecapture.core.grower.model.bean.Grower;
import com.monsanto.brazilvaluecapture.core.grower.service.impl.CsvGrower;

final class CsvGrowerToDomain {

	public Grower convertToDomain(CsvGrower csvGrower) {
		
		BillingAddress billingAddress = buildBillingAddress(csvGrower);

		BusinessAddress businessAddress = buildBusinessAddress(csvGrower);

		Document document = buildDocument(csvGrower);
		
		return new Grower(document, csvGrower.getName(), csvGrower.getAlias(), csvGrower.getEmail(), billingAddress, businessAddress);
	}

	private Document buildDocument(CsvGrower csvGrower) {
		DocumentType documentType = new DocumentType(csvGrower.getDocumentType(), null, null);
		return new Document(documentType, csvGrower.getDocumentNumber());
	}

	private BillingAddress buildBillingAddress(CsvGrower csvGrower) {
		Country billingCountry = new Country(csvGrower.getBillingCountry(), null);
		State billingState = new State(null, csvGrower.getBillingState(), null);
		City billingCity = new City(csvGrower.getBillingCity(), null);

		return new BillingAddress(
				csvGrower.getBillingAddress(), csvGrower.getBillingNumber(),
				csvGrower.getBillingInfo(), csvGrower.getBillingNeighborhood(),
				csvGrower.getBillingZipCode(),
				csvGrower.getBillingPhoneNumber(), csvGrower.getBillingFax(),
				billingCity, billingState, billingCountry);
	}

	private BusinessAddress buildBusinessAddress(CsvGrower csvGrower) {
		Country businessCountry = new Country(csvGrower.getBusinessCountry(), null);
		State businessState = new State(null, csvGrower.getBusinessState(), null);
		City businessCity = new City(csvGrower.getBusinessCity(), null);
		
		return new BusinessAddress(
				csvGrower.getBusinessAddress(), csvGrower.getBusinessNumber(),
				csvGrower.getBusinessInfo(), csvGrower.getBusinessNeighborhood(),
				csvGrower.getBusinessZipCode(),
				csvGrower.getBusinessPhoneNumber(), csvGrower.getBillingFax(),
				businessCity, businessState, businessCountry);
	}
}
