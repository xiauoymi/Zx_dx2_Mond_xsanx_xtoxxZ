package com.monsanto.brazilvaluecapture.core.grower.service.impl;

import com.monsanto.brazilvaluecapture.core.grower.model.bean.AgreementApprovalLog;
import com.monsanto.brazilvaluecapture.core.grower.model.bean.GrowerEventDTO;
import com.monsanto.brazilvaluecapture.core.grower.model.dao.AgreementApprovalLogDAO;
import com.monsanto.brazilvaluecapture.core.grower.model.dao.GrowerDAO;
import com.monsanto.brazilvaluecapture.core.regionalization.VCCountry;
import edu.emory.mathcs.backport.java.util.Arrays;
import org.junit.Before;
import org.junit.Test;

import java.util.*;

import static org.fest.assertions.Assertions.assertThat;
import static org.fest.reflect.core.Reflection.field;
import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.*;

/**
 * Created by AFREI on 11/02/14.
 */
public class GrowerEventReportServiceImpl_UT {

    private GrowerEventReportServiceImpl growerEventReportService;
    private GrowerDAO growerDAO;
    private AgreementApprovalLogDAO agreementApprovalLogDAO;

    @Before
    public void setUp() {
        this.growerEventReportService = new GrowerEventReportServiceImpl();
        this.growerDAO = mock(GrowerDAO.class);
        this.agreementApprovalLogDAO = mock(AgreementApprovalLogDAO.class);
        field("growerDAO").ofType(GrowerDAO.class).in(this.growerEventReportService).set(this.growerDAO);
        field("agreementApprovalLogDAO").ofType(AgreementApprovalLogDAO.class).in(this.growerEventReportService).set(this.agreementApprovalLogDAO);
    }

    @Test
    public void testFetchGrowerEventsCallsGrowerDaoGetGrowerEventDTOsBy() {
        String countryCode = VCCountry.ARGENTINA.getLocale().getCountry();
        String documentNumber = "123456789";
        boolean limitResults = false;

        growerEventReportService.fetchGrowerEvents(countryCode,documentNumber,null, null,null, null,limitResults);

        verify(this.growerDAO, times(1)).getGrowerEventDTOsBy(countryCode, documentNumber, null, null,null, null, limitResults);

    }

    @Test
    public void testFetchGrowerEventsReturnsDaoResult_WhenFetchGrowerEvents() {
        // @Given
        String countryCode = VCCountry.ARGENTINA.getLocale().getCountry();
        String documentNumber = "123456789";
        boolean limitResults = false;

        when(growerDAO.getGrowerEventDTOsBy(countryCode, documentNumber, null, null,null, null, limitResults)).thenReturn(new ArrayList<GrowerEventDTO>());

        // @When
        List<GrowerEventDTO> growerEventDTOList = growerEventReportService.fetchGrowerEvents(countryCode, documentNumber,null, null,null, null, limitResults);

        // @Then
        assertThat(growerEventDTOList).isSameAs(growerDAO.getGrowerEventDTOsBy(countryCode, documentNumber,null, null,null, null, limitResults));
    }
    @Test
    public void testFetchGrowerEventsCallsAgreementApprovalLogDAOGetLatestSentForApprovalLogsFor_WhenGrowerDAOGetGrowerEventDTOsByReturnsAtLeastOneResult(){
        //@Given
        String countryCode = VCCountry.ARGENTINA.getLocale().getCountry();
        String documentNumber = "123456789";
        boolean limitResults = false;

        GrowerEventDTO growerEventDTO = mock(GrowerEventDTO.class);
        when(growerEventDTO.getGrowerId()).thenReturn(1L);
        when(growerEventDTO.getGrowerAgreementLicenseNumber()).thenReturn("1234");

        when(growerDAO.getGrowerEventDTOsBy(countryCode, documentNumber, null, null,null, null, limitResults)).thenReturn(Arrays.asList(new GrowerEventDTO[]{growerEventDTO}));

        growerEventReportService.fetchGrowerEvents(countryCode,documentNumber, null, null,null, null,limitResults);

        // @Then
        verify(this.agreementApprovalLogDAO, times(1)).getLatestSentForApprovalLogsFor(anySet(), anySet());
    }

    @Test
    public void testFetchGrowerEventsCallsAgreementApprovalLogDAOGetAgreementApprovalLogsPadFor_WhenGrowerDAOGetGrowerEventDTOsByReturnsAtLeastOneResult(){
        //@Given
        String countryCode = VCCountry.ARGENTINA.getLocale().getCountry();
        String documentNumber = "123456789";
        boolean limitResults = false;

        GrowerEventDTO growerEventDTO = mock(GrowerEventDTO.class);
        when(growerEventDTO.getGrowerId()).thenReturn(1L);
        when(growerEventDTO.getGrowerAgreementLicenseNumber()).thenReturn("1234");

        when(growerDAO.getGrowerEventDTOsBy(countryCode, documentNumber, null, null,null, null, limitResults)).thenReturn(Arrays.asList(new GrowerEventDTO[]{growerEventDTO}));

        growerEventReportService.fetchGrowerEvents(countryCode,documentNumber, null, null,null, null,limitResults);

        // @Then
        verify(this.agreementApprovalLogDAO, times(1)).getAgreementApprovalLogsPadFor(anySet(), anySet());
    }

    @Test
    public void testFetchGrowerEventsAddPadLogsInfoToEvents_WhenGrowerDAOGetGrowerEventDTOsByReturnsAtLeastOneResult(){
        //@Given
        String countryCode = VCCountry.ARGENTINA.getLocale().getCountry();
        String documentNumber = "123456789";
        boolean limitResults = false;

        GrowerEventDTO growerEventDTO = new GrowerEventDTO();
        growerEventDTO.setGrowerId(1L);
        growerEventDTO.setGrowerAgreementLicenseNumber("1234");

        AgreementApprovalLog agreementApprovalLog = new AgreementApprovalLog();
        agreementApprovalLog.setApprovalDate(new Date());
        agreementApprovalLog.setComments("a comment");
        agreementApprovalLog.setLoginUser("user");
        Map<String, AgreementApprovalLog> agreementApprovalLogMap = new HashMap<String, AgreementApprovalLog>();
        agreementApprovalLogMap.put(growerEventDTO.getGrowerId()+AgreementApprovalLogDAO.AGREEMENT_APPROVAL_LOGS_MAP_KEY_SEPARATOR+growerEventDTO.getGrowerAgreementLicenseNumber(),agreementApprovalLog);

        when(agreementApprovalLogDAO.getAgreementApprovalLogsPadFor(anySet(),anySet())).thenReturn(agreementApprovalLogMap);

        when(growerDAO.getGrowerEventDTOsBy(countryCode, documentNumber,  null, null,null, null, limitResults)).thenReturn(Arrays.asList(new GrowerEventDTO[]{growerEventDTO}));

        growerEventReportService.fetchGrowerEvents(countryCode, documentNumber,  null, null,null, null,limitResults);

        // @Then
        assertEquals(growerEventDTO.getGrowerAgreementApprovalCommentPad(),agreementApprovalLog.getComments());
        assertEquals(growerEventDTO.getGrowerAgreementApprovalDatePad(),agreementApprovalLog.getApprovalDate());
        assertEquals(growerEventDTO.getGrowerAgreementApprovalUserPad(),agreementApprovalLog.getLoginUser());
    }

    @Test
    public void testFetchGrowerEventsAddLogsInfoToEvents_WhenGrowerDAOGetGrowerEventDTOsByReturnsAtLeastOneResult(){
        //@Given
        String countryCode = VCCountry.ARGENTINA.getLocale().getCountry();
        String documentNumber = "123456789";
        boolean limitResults = false;

        GrowerEventDTO growerEventDTO = new GrowerEventDTO();
        growerEventDTO.setGrowerId(1L);
        growerEventDTO.setGrowerAgreementLicenseNumber("1234");

        AgreementApprovalLog agreementApprovalLog = new AgreementApprovalLog();
        agreementApprovalLog.setApprovalDate(new Date());
        agreementApprovalLog.setComments("a comment");
        agreementApprovalLog.setLoginUser("user");
        Map<String, AgreementApprovalLog> agreementApprovalLogMap = new HashMap<String, AgreementApprovalLog>();
        agreementApprovalLogMap.put(growerEventDTO.getGrowerId()+AgreementApprovalLogDAO.AGREEMENT_APPROVAL_LOGS_MAP_KEY_SEPARATOR+growerEventDTO.getGrowerAgreementLicenseNumber(),agreementApprovalLog);

        when(agreementApprovalLogDAO.getLatestSentForApprovalLogsFor(anySet(),anySet())).thenReturn(agreementApprovalLogMap);

        when(growerDAO.getGrowerEventDTOsBy(countryCode, documentNumber,  null, null,null, null,limitResults)).thenReturn(Arrays.asList(new GrowerEventDTO[]{growerEventDTO}));

        growerEventReportService.fetchGrowerEvents(countryCode, documentNumber, null, null,null, null, limitResults);

        // @Then
        assertEquals(growerEventDTO.getGrowerAgreementSentForApprovalComments(),agreementApprovalLog.getComments());
        assertEquals(growerEventDTO.getGrowerAgreementSentForApprovalDate(),agreementApprovalLog.getApprovalDate());
        assertEquals(growerEventDTO.getGrowerAgreementSentForApprovalUser(),agreementApprovalLog.getLoginUser());
    }
}
