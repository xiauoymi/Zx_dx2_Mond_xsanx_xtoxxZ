package com.monsanto.brazilvaluecapture.core.grower.service.impl;

import com.monsanto.brazilvaluecapture.core.base.model.bean.*;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Customer;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.HeadOffice;
import com.monsanto.brazilvaluecapture.core.customer.model.dao.CustomerDAO;
import com.monsanto.brazilvaluecapture.core.customer.model.dao.HeadOfficeDAO;
import com.monsanto.brazilvaluecapture.core.customer.service.CustomerService;
import com.monsanto.brazilvaluecapture.core.foundation.model.bean.SystemParameter;
import com.monsanto.brazilvaluecapture.core.foundation.model.bean.SystemParameterValue;
import com.monsanto.brazilvaluecapture.core.foundation.model.dao.SystemParameterDAO;
import com.monsanto.brazilvaluecapture.core.grower.model.bean.Grower;
import com.monsanto.brazilvaluecapture.core.grower.model.dao.GrowerDAO;
import com.monsanto.brazilvaluecapture.core.grower.model.dao.GrowerFastTrackDAO;
import com.monsanto.brazilvaluecapture.core.grower.service.GrowerFastTrackService;
import org.apache.logging.log4j.Logger;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.MockitoAnnotations;

import javax.persistence.PersistenceException;

import static org.fest.assertions.Assertions.assertThat;
import static org.fest.reflect.core.Reflection.field;
import static org.junit.Assert.*;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.*;

public class GrowerFastTrackServiceImpl_UT {

    private static final String GRAIN_TRADE_ENABLE_PARAMETER_NAME = "CUSTOMER_ENABLED_GRAIN_TRADE";
    private static final String GRAIN_TRADE_ENABLE_PARAMETER_GROUP = "CUSTOMER";
    private static final String CUSTOMER_ROG_ENABLE_STRING = "99Y";
    private static final String FAST_TRACK = "FAST_TRACK";
    private static final String CUSTOMER_ACTIVE_PARAMETER_NAME = "CUSTOMER_ACTIVE";
    private static final String CUSTOMER_ACTIVE_PARAMETER_GROUP = "CUSTOMER";

    private GrowerFastTrackService growerFastTrackService;
    private CustomerDAO customerDAO;
    private CustomerService customerService;
    private SystemParameterDAO systemParameterDAO;
    private HeadOfficeDAO headOfficeDAO;
    private GrowerDAO growerDAO;
    private GrowerFastTrackDAO growerFastTrackDAO;

    @Before
    public void setUp(){
        MockitoAnnotations.initMocks(this);
        growerFastTrackService = new GrowerFastTrackServiceImpl();
        customerDAO = mock(CustomerDAO.class);
        customerService = mock(CustomerService.class);
        systemParameterDAO = mock(SystemParameterDAO.class);
        headOfficeDAO = mock(HeadOfficeDAO.class);
        growerDAO = mock(GrowerDAO.class);
        growerFastTrackDAO = mock(GrowerFastTrackDAO.class);
        field("customerDAO").ofType(CustomerDAO.class).in(growerFastTrackService).set(customerDAO);
        field("customerService").ofType(CustomerService.class).in(growerFastTrackService).set(customerService);
        field("systemParameterDAO").ofType(SystemParameterDAO.class).in(growerFastTrackService).set(systemParameterDAO);
        field("headOfficeDAO").ofType(HeadOfficeDAO.class).in(growerFastTrackService).set(headOfficeDAO);
        field("growerDAO").ofType(GrowerDAO.class).in(growerFastTrackService).set(growerDAO);
        field("growerFastTrackDAO").ofType(GrowerFastTrackDAO.class).in(growerFastTrackService).set(growerFastTrackDAO);
        Logger mockLogger = mock(Logger.class);
        doNothing().when(mockLogger).error(any(String.class));
        field("logger").ofType(Logger.class).in(growerFastTrackService).set(mockLogger);

    }

    @Test
    public void test_canCreateCustomerWhenGrowerAlreadyHasACustomer(){
        Grower grower = mock(Grower.class);
        when(grower.getCustomerSapId()).thenReturn("Fake Valid Sap Customer Id");
        when(customerDAO.getCustomersByCustomerSapCode(grower.getCustomerSapId())).thenReturn(1L);
        boolean canCreate = growerFastTrackService.canCreateFastTrackCustomer(grower);
        verify(customerDAO).getCustomersByCustomerSapCode(grower.getCustomerSapId());
        assertThat(canCreate).isFalse();
    }

    @Test
    public void test_canCreateCustomerWhenGrowerAlreadyHasNoCustomer(){
        Grower grower = mock(Grower.class);
        when(grower.getCustomerSapId()).thenReturn("Fake Invalid Sap Customer Id");
        when(customerDAO.getCustomersByCustomerSapCode(grower.getCustomerSapId())).thenReturn(0L);
        boolean canCreate = growerFastTrackService.canCreateFastTrackCustomer(grower);
        verify(customerDAO).getCustomersByCustomerSapCode(grower.getCustomerSapId());
        assertThat(canCreate).isTrue();
    }

    @Test
    public void test_createFastTrackCustomerWhenSapEnabledChangeIsTrueAndFastTrackIsTrue(){
        ArgumentCaptor<HeadOffice> headOfficeArgumentCaptor = ArgumentCaptor.forClass(HeadOffice.class);
        Grower grower = mock(Grower.class);
        when(grower.getFastTrack()).thenReturn(true);
        String loggedUser = "Fake Logged User";
        Crop crop = mock(Crop.class);
        Company company = mock(Company.class);
        Boolean sapEnabledChange = Boolean.TRUE;
        BillingAddress billingAddress = mock(BillingAddress.class);
        State mockState = mock(State.class);
        when(billingAddress.getState()).thenReturn(mockState);
        Country mockCountry = mock(Country.class);
        when(billingAddress.getCountry()).thenReturn(mockCountry);
        when(mockCountry.getCode()).thenReturn("AR");
        when(grower.getBillingAddress()).thenReturn(billingAddress);
        SystemParameter mockSystemParamCustomerActive = mock(SystemParameter.class);
        SystemParameter mockSystemParamGrainTrade = mock(SystemParameter.class);
        SystemParameterValue systemParamValueActive = mock(SystemParameterValue.class);
        SystemParameterValue systemParamValueCustomerROG = mock(SystemParameterValue.class);
        when(mockSystemParamCustomerActive.getSystemParameterValue()).thenReturn(systemParamValueActive);
        when(mockSystemParamGrainTrade.getSystemParameterValue()).thenReturn(systemParamValueCustomerROG);
        Address address = new Address();
        address.setCountry(grower.getBillingAddress().getCountry());
        address.setState(grower.getBillingAddress().getState());
        Customer fastTrackCustomer = new Customer(grower.getName(),grower.getDocument(),address,grower.getCustomerSapId(), true, "99Y", FAST_TRACK);
        fastTrackCustomer.setId(1L);
        when(customerService.createFastTrackCustomer(fastTrackCustomer)).thenReturn(fastTrackCustomer);
        when(systemParameterDAO.selectParameterByGroupAndNameAndCountryCode(CUSTOMER_ACTIVE_PARAMETER_GROUP, CUSTOMER_ACTIVE_PARAMETER_NAME, "AR")).thenReturn(mockSystemParamCustomerActive);
        when(systemParameterDAO.selectParameterByGroupAndNameAndCountryCode(GRAIN_TRADE_ENABLE_PARAMETER_GROUP, GRAIN_TRADE_ENABLE_PARAMETER_NAME, "AR")).thenReturn(mockSystemParamGrainTrade);

        growerFastTrackService.createFastTrackCustomer(grower, crop, company, loggedUser, sapEnabledChange);

        verify(this.headOfficeDAO).save(headOfficeArgumentCaptor.capture());
        verify(systemParameterDAO).selectParameterByGroupAndNameAndCountryCode(CUSTOMER_ACTIVE_PARAMETER_GROUP, CUSTOMER_ACTIVE_PARAMETER_NAME, "AR");
        verify(systemParameterDAO).selectParameterByGroupAndNameAndCountryCode(GRAIN_TRADE_ENABLE_PARAMETER_GROUP, GRAIN_TRADE_ENABLE_PARAMETER_NAME, "AR");
        assertThat(headOfficeArgumentCaptor.getValue().getCrop()).isEqualTo(crop);
    }

    @Test
    public void test_createFastTrackCustomerWhenCustomerServiceThrowsException(){
        ArgumentCaptor<Grower> growerArgumentCaptor = ArgumentCaptor.forClass(Grower.class);
        Grower grower = mock(Grower.class);
        when(grower.getFastTrack()).thenReturn(true);
        String loggedUser = "Fake Logged User";
        Crop crop = mock(Crop.class);
        Company company = mock(Company.class);
        Boolean sapEnabledChange = Boolean.TRUE;
        BillingAddress billingAddress = mock(BillingAddress.class);
        State mockState = mock(State.class);
        when(billingAddress.getState()).thenReturn(mockState);
        Country mockCountry = mock(Country.class);
        when(billingAddress.getCountry()).thenReturn(mockCountry);
        when(mockCountry.getCode()).thenReturn("AR");
        when(grower.getBillingAddress()).thenReturn(billingAddress);
        SystemParameter mockSystemParamCustomerActive = mock(SystemParameter.class);
        SystemParameter mockSystemParamGrainTrade = mock(SystemParameter.class);
        SystemParameterValue systemParamValueActive = mock(SystemParameterValue.class);
        SystemParameterValue systemParamValueCustomerROG = mock(SystemParameterValue.class);
        when(mockSystemParamCustomerActive.getSystemParameterValue()).thenReturn(systemParamValueActive);
        when(mockSystemParamGrainTrade.getSystemParameterValue()).thenReturn(systemParamValueCustomerROG);
        Address address = new Address();
        address.setCountry(grower.getBillingAddress().getCountry());
        address.setState(grower.getBillingAddress().getState());
        Customer fastTrackCustomer = new Customer(grower.getName(),grower.getDocument(),address,grower.getCustomerSapId(), true, "99Y", FAST_TRACK);
        fastTrackCustomer.setId(1L);
        when(customerService.createFastTrackCustomer(any(Customer.class))).thenThrow(PersistenceException.class);
        when(systemParameterDAO.selectParameterByGroupAndNameAndCountryCode(CUSTOMER_ACTIVE_PARAMETER_GROUP, CUSTOMER_ACTIVE_PARAMETER_NAME, "AR")).thenReturn(mockSystemParamCustomerActive);
        when(systemParameterDAO.selectParameterByGroupAndNameAndCountryCode(GRAIN_TRADE_ENABLE_PARAMETER_GROUP, GRAIN_TRADE_ENABLE_PARAMETER_NAME, "AR")).thenReturn(mockSystemParamGrainTrade);

        growerFastTrackService.createFastTrackCustomer(grower, crop, company, loggedUser, sapEnabledChange);
        when(grower.getFastTrack()).thenReturn(false);
        verify(growerDAO).save(growerArgumentCaptor.capture());
        assertThat(growerArgumentCaptor.getValue().getFastTrack()).isFalse();

    }


}