package com.monsanto.brazilvaluecapture.core.grower.service.impl;

import com.monsanto.brazilvaluecapture.core.base.model.bean.File;
import com.monsanto.brazilvaluecapture.core.base.service.CompanyService;
import com.monsanto.brazilvaluecapture.core.foundation.util.ConstraintViolation;
import com.monsanto.brazilvaluecapture.core.grower.model.bean.Agreement;
import com.monsanto.brazilvaluecapture.core.grower.model.bean.AgreementTemplate;
import com.monsanto.brazilvaluecapture.core.grower.service.GrowerConstraintViolationException;
import org.hamcrest.BaseMatcher;
import org.hamcrest.Description;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.runners.MockitoJUnitRunner;
import org.mockito.stubbing.Answer;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

import static org.mockito.Mockito.*;

/**
 * Created by IntelliJ IDEA.
 * User: LSCHW1
 */

public class FileEntry_UT {

    private FileEntry correctRootFileEntry;
    private FileEntry correctSubFileEntry;

    private final static String MASKED_DOCUMENT="32-145-67";
    private final static String UNMASKED_DOCUMENT="3214567";

    private final static byte[] FILE_CONTENT={0,1,0,1};
    private static final String FILE_EXTENSION = ".pdf";
    private static final String MIME_TYPE = "application/pdf";
    private static final String SUB_FILE_NAME = "file";


    @Before
    public void setUp() throws IOException {
        correctRootFileEntry=createCorrectRootFileEntry();
        correctSubFileEntry=createSubFileEntry();
    }


    private ZipInputStream createZipInputStreamMock() throws IOException {

        ZipInputStream zis=mock(ZipInputStream.class);

        doAnswer(new Answer<Integer>() {
            @Override
            public Integer answer(InvocationOnMock invocation) throws Throwable {
                Object[] arguments = invocation.getArguments();

                if (arguments != null && arguments.length > 0 && arguments[0] != null && arguments[0] instanceof byte[]){
                    System.arraycopy(FILE_CONTENT, 0, arguments[0], 0, FILE_CONTENT.length);
                }
                return FILE_CONTENT.length;
            }
        }).when(zis).read(Matchers.<byte[]>argThat(new ByteArrayMatcher(createEmptyByteArray())));//Only When input buffer is empty.

        return zis;
    }

    private byte[] createEmptyByteArray() {
        return new byte[FileEntry.BUFFER_WRITER];
    }

    private class ByteArrayMatcher extends BaseMatcher {

        private final byte[] targetArray;

        public ByteArrayMatcher(byte[] targetArray) {
            this.targetArray = targetArray;
        }

        @Override
        public boolean matches(Object o) {
            if (o != null && o instanceof byte[]) {
                return Arrays.equals((byte[]) o,targetArray);
            }
            return false;
        }

        @Override
        public void describeTo(Description description) {
            description.appendText("Matches a class");
        }
    }

    private FileEntry createCorrectRootFileEntry() throws IOException {
        ZipEntry zeRoot=mock(ZipEntry.class);
        when(zeRoot.isDirectory()).thenReturn(false);
        when(zeRoot.getName()).thenReturn(MASKED_DOCUMENT+FILE_EXTENSION);

        ZipInputStream zis=createZipInputStreamMock();

        return new FileEntry(zis,zeRoot);
    }

     private FileEntry createSubFileEntry() throws IOException {
        ZipEntry zeSubFile=mock(ZipEntry.class);
        when(zeSubFile.isDirectory()).thenReturn(false);
        when(zeSubFile.getName()).thenReturn(MASKED_DOCUMENT+FileEntry.FILE_ZIP_SEPARATOR+SUB_FILE_NAME+FILE_EXTENSION);

        ZipInputStream zis=createZipInputStreamMock();

        return new FileEntry(zis,zeSubFile);
    }

    private FileEntry createFileEntryDirectory(){
        ZipEntry ze=mock(ZipEntry.class);
        when(ze.isDirectory()).thenReturn(true);
        return new FileEntry(mock(ZipInputStream.class),ze);
    }

    private FileEntry createFileEntryAboveSubDirectory() {
        ZipEntry ze=mock(ZipEntry.class);
        when(ze.getName()).thenReturn("folder1"+FileEntry.FILE_ZIP_SEPARATOR+"folder2"+FileEntry.FILE_ZIP_SEPARATOR+SUB_FILE_NAME+FILE_EXTENSION);
        when(ze.isDirectory()).thenReturn(false);
        return new FileEntry(mock(ZipInputStream.class),ze);
    }

    @Test
    public void getDocument_ShouldReturnNull_WhenCharsetIsNotSupported(){
        FileEntry fileEntryCharsetUnsupported=FileEntry.unsupportedCharsetFileEntry();

        String document=fileEntryCharsetUnsupported.getDocument();

        Assert.assertNull(document);
    }

    @Test
    public void getDocument_ShouldReturnNull_WhenEntryIsADirectory(){
        FileEntry fileEntry=createFileEntryDirectory();

        String document=fileEntry.getDocument();

        Assert.assertNull(document);
    }

    @Test
    public void getDocument_ShouldReturnNull_WhenEntryIsAboveSubDirectory(){
        FileEntry fileEntry=createFileEntryAboveSubDirectory();

        String document=fileEntry.getDocument();

        Assert.assertNull(document);
    }

    @Test
    public void getDocument_ShouldReturnFolderNameWithoutMask_WhenEntryIsCorrectSubFile(){

        String document=correctSubFileEntry.getDocument();

        Assert.assertEquals(UNMASKED_DOCUMENT, document);
    }

    @Test
    public void getDocument_ShouldReturnFileNameWithoutMaskAndExtension_WhenEntryIsCorrectRootFile(){

        String document=correctRootFileEntry.getDocument();

        Assert.assertEquals(UNMASKED_DOCUMENT, document);
    }

    @Test
    public void createFile_ShouldReturnNull_WhenCharsetIsNotSupported() throws IOException {
        FileEntry fileEntryCharsetUnsupported=FileEntry.unsupportedCharsetFileEntry();

        File file=fileEntryCharsetUnsupported.createFile();

        Assert.assertNull(file);
    }

    @Test
    public void createFile_ShouldReturnValidFile_WhenRootFileEntryIsCorrect() throws IOException {
        FileEntry fileEntry=createCorrectRootFileEntry();

        File file=fileEntry.createFile();

        Assert.assertEquals(MASKED_DOCUMENT+FILE_EXTENSION,file.getFileName());
        Assert.assertEquals(MIME_TYPE,file.getMimeType());
        Assert.assertNull(file.getContent().getId());
        Assert.assertArrayEquals(FILE_CONTENT, file.getContent().getValue());
        Assert.assertNull(file.getId());
    }


    @Test
    public void createFile_ShouldReturnValidFile_WhenSubFileEntryIsCorrect() throws IOException {
        FileEntry fileEntry=createSubFileEntry();

        File file=fileEntry.createFile();

        Assert.assertEquals(SUB_FILE_NAME+FILE_EXTENSION,file.getFileName());
        Assert.assertEquals(MIME_TYPE,file.getMimeType());
        Assert.assertNull(file.getContent().getId());
        Assert.assertArrayEquals(FILE_CONTENT, file.getContent().getValue());
        Assert.assertNull(file.getId());
    }


}
