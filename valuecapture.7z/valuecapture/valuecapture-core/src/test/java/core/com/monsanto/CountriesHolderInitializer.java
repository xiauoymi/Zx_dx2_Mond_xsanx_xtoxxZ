package com.monsanto;

import com.monsanto.brazilvaluecapture.core.customer.ParticipantServiceImpl_AT;
import com.monsanto.brazilvaluecapture.core.foundation.util.security.EnvironmentSpecificPropertyReader;
import com.monsanto.brazilvaluecapture.core.regionalization.CountriesHolder;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class CountriesHolderInitializer {

    public static void initialize(CountriesHolder countriesHolder) {
        String configuredHost = "CONFIGURED_AND_REQUESTED_HOST_SAME";
                EnvironmentSpecificPropertyReader env = mock(EnvironmentSpecificPropertyReader.class);
                countriesHolder.setEnvironmentSpecificPropertyReader(env);
                when(env.getEnvironmentSpecificProperty("host_name.argentina", null)).thenReturn("other");
                when(env.getEnvironmentSpecificProperty("host_name.brazil", null)).thenReturn(configuredHost);
                when(env.getEnvironmentSpecificProperty("host_name.paraguay", null)).thenReturn("another");

                countriesHolder.initialize();
                try{
                   countriesHolder.resolveCountry(configuredHost);
                }catch(IllegalStateException ex)
                {

                }

    }
}