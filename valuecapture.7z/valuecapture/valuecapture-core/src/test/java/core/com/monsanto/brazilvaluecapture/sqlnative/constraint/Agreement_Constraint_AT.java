package com.monsanto.brazilvaluecapture.sqlnative.constraint;

import com.monsanto.brazilvaluecapture.core.base.SystemTestFixture;
import com.monsanto.brazilvaluecapture.core.base.service.CompanyService;
import com.monsanto.brazilvaluecapture.core.foundation.service.BusinessException;
import com.monsanto.brazilvaluecapture.core.foundation.service.EntityAlreadyExistException;
import com.monsanto.brazilvaluecapture.core.foundation.test.AbstractServiceIntegrationTests;
import com.monsanto.brazilvaluecapture.core.grower.model.bean.AgreementTemplate;
import com.monsanto.brazilvaluecapture.core.user.AccessControlTestFixture;
import com.monsanto.brazilvaluecapture.core.user.model.bean.HierarchyLevel;
import com.monsanto.brazilvaluecapture.seedsale.sale.SaleTestFixture;
import junit.framework.Assert;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

@Ignore
public class Agreement_Constraint_AT extends
		AbstractServiceIntegrationTests {

	@Autowired
	private CompanyService companyService;
	protected AgreementTemplate agreement;

	public Agreement_Constraint_AT() {
		super();
	}
	
	@Before
	public void init() throws BusinessException {
		systemTestFixture = new SystemTestFixture(this);
		accessControlTestFixture = new AccessControlTestFixture(this, systemTestFixture);
		saleTestFixture = new SaleTestFixture(this, systemTestFixture);

		accessControlTestFixture.itsParticipantUser.addUserContract(saleTestFixture.contract, saleTestFixture.customer, HierarchyLevel.HEAD_OFFICE);
		
		agreement = new AgreementTemplate(systemTestFixture.soy, systemTestFixture.monsantoBr, systemTestFixture.intacta, "CONTENT", Boolean.TRUE);
		
		saveAndFlush(agreement);
		
	
	}

	@Test(expected = EntityAlreadyExistException.class)
	public void when_i_save_with_agreementTemplate_existing_shouldReturn_exception()
			throws BusinessException {
				
				AgreementTemplate newAgreement = new AgreementTemplate(systemTestFixture.soy, systemTestFixture.monsantoBr, systemTestFixture.intacta, "CONTENT", Boolean.TRUE);
				
				Assert.assertEquals(newAgreement.getCrop(), agreement.getCrop());
				Assert.assertEquals(newAgreement.getCompany(), agreement.getCompany());
				Assert.assertEquals(newAgreement.getTechnology(), agreement.getTechnology());
				
				companyService.saveAgreementTemplate(newAgreement);
				
				Assert.fail("Should not save a new agreement template");
			}

	
}