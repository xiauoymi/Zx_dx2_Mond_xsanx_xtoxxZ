package com.monsanto.brazilvaluecapture.seedsale.quota.model.dao;

import com.monsanto.brazilvaluecapture.core.base.model.bean.Company;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Crop;
import com.monsanto.brazilvaluecapture.core.base.model.bean.OperationalYear;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Customer;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Technology;
import com.monsanto.brazilvaluecapture.multiplier.cultivar.model.bean.Cultivar;
import com.monsanto.brazilvaluecapture.seedsale.product.model.bean.Brand;
import com.monsanto.brazilvaluecapture.seedsale.product.model.bean.Product;
import com.monsanto.brazilvaluecapture.seedsale.quota.model.bean.Quota;
import junit.framework.Assert;
import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.hibernate.classic.Session;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.*;
import static org.fest.assertions.Assertions.assertThat;

public class QuotaDAOImpl_UT {

    Session currentSession;
    @Mock
    private SessionFactory sessionFactory;
    @Mock
    private Customer dealerSelected;
    private Query query;
    private QuotaDAO quotaDAO;

    @Before
    public void init() {
        MockitoAnnotations.initMocks(this);
        quotaDAO = new QuotaDAOImpl(sessionFactory);


        currentSession = mock(Session.class);
        when(sessionFactory.getCurrentSession()).thenReturn(currentSession);

        query = mock(Query.class);
        when(currentSession.createQuery(anyString())).thenReturn(query);
    }

    @Test
    public void when_not_all_data_provided_return_data() {
        //@Given
        Company company = mock(Company.class);
        Crop crop = mock(Crop.class);
        OperationalYear operationalYear = new OperationalYear("2013");
        Technology technology = null;
        Brand brand = null;
        Product productSelected = null;
        String productDescription = null;
        Session currentSession = mock(Session.class);
        when(sessionFactory.getCurrentSession()).thenReturn(currentSession);
        Query query = mock(Query.class);
        when(currentSession.createQuery(anyString())).thenReturn(query);
        List<Quota> returnList = new ArrayList();
        returnList.add(mock(Quota.class));
        when(query.list()).thenReturn(returnList);

        //@When
        List<Map> mapList = quotaDAO.getQuotasGroupBy(company, crop, dealerSelected, operationalYear, productDescription, productSelected, brand, technology);

        //@Should
        Assert.assertNotNull(mapList);
        Assert.assertFalse(mapList.isEmpty());
    }

    @Test
    public void when_all_data_provided_return_data() {
        //@Given
        Company company = mock(Company.class);
        Crop crop = mock(Crop.class);
        Technology technology = mock(Technology.class);
        Brand brand = mock(Brand.class);
        Product productSelected = Mockito.mock(Product.class);
        String productDescription = "dummy";
        List<Quota> returnList = new ArrayList();
        returnList.add(mock(Quota.class));
        when(query.list()).thenReturn(returnList);

        //@When
        List<Map> mapList = quotaDAO.getQuotasGroupBy(company, crop, dealerSelected, null, productDescription, productSelected, brand, technology);

        //@Should
        Assert.assertNotNull(mapList);
        Assert.assertFalse(mapList.isEmpty());
    }

    @Test
    public void testGetCultivarsForHeadOfficeAndOperationalYearRetreivesCultivars_WhenThereIsQuotaForHOInOY(){
        //@Given headOffice and operational year
        Cultivar cultivar = new Cultivar();
        cultivar.setDescription("Cultivar 1");
        Customer headOffice = new Customer("headOffice 1", null, null, "SAP CODE");
        headOffice.setActive(true);
        OperationalYear operationalYear = new OperationalYear("AAAA");

        //@When getCultivarFor
        final List<Cultivar> cultivars = quotaDAO.getCultivarsFor(headOffice, operationalYear);

        //@Should
        ArgumentCaptor<String> queryStringCaptor = ArgumentCaptor.forClass(String.class);
        verify(currentSession).createQuery(queryStringCaptor.capture());
        String queryString = queryStringCaptor.getValue();
        String expectedQuery = "SELECT q.product.cultivar FROM Quota q " +
                "WHERE q.operationalYear = :operationalYear and q.customer = :headOffice and q.owner = 'MULTIPLIER' " +
                "and q.product.cultivar.obtainer.status = 1";
        assertThat(queryString).isEqualTo(expectedQuery);
        verify(query).setParameter("operationalYear", operationalYear);
        verify(query).setParameter("headOffice", headOffice);
    }

    @Test
    public void testGetCultivarsReturnsDTO_WhenSearchingQuotaByCultivar(){
        //@given head office and operational year
        Customer headOffice = new Customer();
        OperationalYear operationalYear = new OperationalYear();

        //@When
        quotaDAO.getQuotaByCultivars(operationalYear, headOffice);

        //@Then
        ArgumentCaptor<String> queryStringCaptor = ArgumentCaptor.forClass(String.class);
        verify(currentSession).createQuery(queryStringCaptor.capture());
        String queryString = queryStringCaptor.getValue();
        assertThat(queryString).isEqualTo("SELECT new com.monsanto.brazilvaluecapture.seedsale.quota.model.bean.QuotaByCultivar(quota.product.cultivar, sum(quota.balance))" +
                        "FROM Quota quota " +
                        "WHERE quota.operationalYear = :operationalYear and quota.customer = :headOffice and quota.owner = 'MULTIPLIER' and " +
                        "quota.type = 'AVAILABLE' " +
                        "GROUP BY quota.product.cultivar");
        verify(query).setParameter("operationalYear", operationalYear);
        verify(query).setParameter("headOffice", headOffice);
    }
}
