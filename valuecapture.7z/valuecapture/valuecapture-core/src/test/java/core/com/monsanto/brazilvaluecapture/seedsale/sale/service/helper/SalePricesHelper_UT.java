package com.monsanto.brazilvaluecapture.seedsale.sale.service.helper;

import com.monsanto.brazilvaluecapture.core.regionalization.CountriesHolder;
import com.monsanto.brazilvaluecapture.core.regionalization.VCCountry;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.PriceFromSAPDTO;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.PricingCondition;
import com.monsanto.brazilvaluecapture.seedsale.sale.service.PricingConditionService;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.fest.reflect.core.Reflection.field;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.*;

/**
 * Created by AFREI on 17/02/14.
 */
public class SalePricesHelper_UT {

    @Mock
    private PricingConditionService pricingConditionService;
    @Mock
    private CountriesHolder countriesHolder;

    private SalePricesHelper salePricesHelper;

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
        salePricesHelper = new SalePricesHelper();
        field("pricingConditionService").ofType(PricingConditionService.class).in(salePricesHelper).set(pricingConditionService);
        field("countriesHolder").ofType(CountriesHolder.class).in(salePricesHelper).set(countriesHolder);
        when(countriesHolder.getCountry()).thenReturn(VCCountry.ARGENTINA);
    }


    @Test
    public void testGetFilteredPriceListReceiveAPriceListAndReturnItFilteredAvoidingPricesWithZeroOrNullValue(){
        //@Given
        PriceFromSAPDTO priceFromSAPDTO_zero = mock(PriceFromSAPDTO.class);
        when(priceFromSAPDTO_zero.getPrice()).thenReturn(BigDecimal.ZERO);
        when(priceFromSAPDTO_zero.getIdCondition()).thenReturn("code");
        PriceFromSAPDTO priceFromSAPDTO_null = mock(PriceFromSAPDTO.class);
        when(priceFromSAPDTO_null.getPrice()).thenReturn(null);
        when(priceFromSAPDTO_null.getIdCondition()).thenReturn("code");
        PriceFromSAPDTO priceFromSAPDTO_ten = mock(PriceFromSAPDTO.class);
        when(priceFromSAPDTO_ten.getPrice()).thenReturn(BigDecimal.TEN);
        when(priceFromSAPDTO_ten.getIdCondition()).thenReturn("code");
        List<PriceFromSAPDTO> priceFromSAPDTOList = Arrays.asList(new PriceFromSAPDTO[]{priceFromSAPDTO_null,priceFromSAPDTO_zero,priceFromSAPDTO_ten});
        PricingCondition pricingCondition = mock(PricingCondition.class);
        when(pricingCondition.getSapCode()).thenReturn("code");
        when(pricingConditionService.getPricingCondition(countriesHolder.getCountry().getLocale().getCountry())).thenReturn(Arrays.asList(new PricingCondition[]{pricingCondition}));


        //@When
        List<PriceFromSAPDTO> filteredList = salePricesHelper.getFilteredPriceList(priceFromSAPDTOList);


        //@Then
        assertTrue(filteredList.contains(priceFromSAPDTO_ten));
        assertFalse(filteredList.contains(priceFromSAPDTO_zero));
        assertFalse(filteredList.contains(priceFromSAPDTO_null));
    }

    @Test
    public void testGetFilteredPriceListReceiveAPriceListAndReturnItFilteredInOrderToWhatPricingConditionServiceGetPricingConditionReturns(){
        //@Given
        PriceFromSAPDTO priceFromSAPDTO_invalid = mock(PriceFromSAPDTO.class);
        when(priceFromSAPDTO_invalid.getPrice()).thenReturn(BigDecimal.TEN);
        when(priceFromSAPDTO_invalid.getIdCondition()).thenReturn("InvalidCode");
        PriceFromSAPDTO priceFromSAPDTO_valid = mock(PriceFromSAPDTO.class);
        when(priceFromSAPDTO_valid.getPrice()).thenReturn(BigDecimal.TEN);
        when(priceFromSAPDTO_valid.getIdCondition()).thenReturn("code");
        List<PriceFromSAPDTO> priceFromSAPDTOList = Arrays.asList(new PriceFromSAPDTO[]{priceFromSAPDTO_invalid,priceFromSAPDTO_valid});
        PricingCondition pricingCondition = mock(PricingCondition.class);
        when(pricingCondition.getSapCode()).thenReturn("code");
        when(pricingConditionService.getPricingCondition(countriesHolder.getCountry().getLocale().getCountry())).thenReturn(Arrays.asList(new PricingCondition[]{pricingCondition}));

        //@When
        List<PriceFromSAPDTO> filteredList = salePricesHelper.getFilteredPriceList(priceFromSAPDTOList);

         //@Then
        assertTrue(filteredList.contains(priceFromSAPDTO_valid));
        assertFalse(filteredList.contains(priceFromSAPDTO_invalid));
    }

    @Test
    public void testGetFilteredPriceListCallsPricingConditionServiceGetPricingCondition(){
        //@Given
        List<PriceFromSAPDTO> priceFromSAPDTOList = new ArrayList<PriceFromSAPDTO>();

        //@When
        salePricesHelper.getFilteredPriceList(priceFromSAPDTOList);

        //@Then
        verify(pricingConditionService,times(1)).getPricingCondition(countriesHolder.getCountry().getLocale().getCountry());
    }
}
