package com.monsanto.brazilvaluecapture.core;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

import com.monsanto.brazilvaluecapture.core.base.CompanyService_AT;
import com.monsanto.brazilvaluecapture.core.base.Company_AT;
import com.monsanto.brazilvaluecapture.core.base.Company_UT;
import com.monsanto.brazilvaluecapture.core.base.Crop_UT;
import com.monsanto.brazilvaluecapture.core.base.Technology_UT;
import com.monsanto.brazilvaluecapture.core.customer.Customer_AT;
import com.monsanto.brazilvaluecapture.core.customer.ParticipantServiceImpl_AT;
import com.monsanto.brazilvaluecapture.core.user.AgreementContentManager_UT;
import com.monsanto.brazilvaluecapture.core.user.AgreementTemplate_AT;
import com.monsanto.brazilvaluecapture.core.user.Agreement_AT;
import com.monsanto.brazilvaluecapture.core.user.Agreement_UT;

@RunWith(value = Suite.class)
@SuiteClasses(value = {
		//SuiteHarvest.class,
		//SuiteProduct.class,
		AgreementContentManager_UT.class,
		AgreementTemplate_AT.class,
		Agreement_AT.class,
		Agreement_UT.class,
		//BrandService_AT.class,
		//Brand_UT.class,
		CompanyService_AT.class,
		Company_AT.class,
		Company_UT.class,
		Crop_UT.class,
		Customer_AT.class,
		ParticipantServiceImpl_AT.class,
		Technology_UT.class})
public class SuiteCompany {

	
}
