package com.monsanto.brazilvaluecapture.jobs.importfile.messaging.executor.impl;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.ResourceBundle;

import org.hibernate.criterion.Restrictions;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;

import com.monsanto.CountriesHolderInitializer;
import com.monsanto.brazilvaluecapture.core.base.SystemTestFixture;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Customer;
import com.monsanto.brazilvaluecapture.core.foundation.test.AbstractServiceIntegrationTests;
import com.monsanto.brazilvaluecapture.core.foundation.util.CalendarUtil;
import com.monsanto.brazilvaluecapture.core.foundation.util.csv.CSVInvalidLayoutException;
import com.monsanto.brazilvaluecapture.core.foundation.util.csv.CSVReadableInvalidException;
import com.monsanto.brazilvaluecapture.core.importfile.model.ImportFileType;
import com.monsanto.brazilvaluecapture.core.importfile.model.bean.CsvImportFile;
import com.monsanto.brazilvaluecapture.core.importfile.model.dao.CsvImportFileDAO;
import com.monsanto.brazilvaluecapture.core.importfile.service.CsvImportFileService;
import com.monsanto.brazilvaluecapture.core.regionalization.CountriesHolder;
import com.monsanto.brazilvaluecapture.core.user.AccessControlTestFixture;
import com.monsanto.brazilvaluecapture.core.user.model.bean.UserDecorator;
import com.monsanto.brazilvaluecapture.jobs.importfile.messaging.bean.FileImportDefinition;
import com.monsanto.brazilvaluecapture.jobs.importfile.messaging.bean.FileImportInfo;
import com.monsanto.brazilvaluecapture.jobs.importfile.messaging.bean.FileImportOperation;
import com.monsanto.brazilvaluecapture.jobs.importfile.messaging.executor.ImportFileCallbackException;
import com.monsanto.brazilvaluecapture.seedsale.sale.SaleTestFixture;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.CsvSale;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.CsvSaleImportLine;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.CsvSaleImportResult;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.ImportFileStatus;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.Indexable;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.Sale;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.dao.CsvMDImportDAO;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.dao.CsvSaleImportDAO;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.dao.SaleFilter;
import com.monsanto.brazilvaluecapture.seedsale.sale.service.SaleService;
import com.monsanto.brazilvaluecapture.seedsale.sale.service.parser.DirectSaleTestFixture;
import com.monsanto.brazilvaluecapture.seedsale.sale.service.parser.registration.DirectSaleParser;
import com.monsanto.brazilvaluecapture.seedsale.sale.service.parser.registration.SaleFileParser;

public class CsvSaleImportFileCallback_AT extends AbstractServiceIntegrationTests {

    @Autowired
    private SaleService saleService;

    @Autowired
    private CsvImportFileService csvImportFileService;

    @Autowired
    private CsvSaleImportFileCallback csvSaleImportFileCallback;
    
    @Autowired
    private CsvDirectSaleImportFileCallback csvDirectSaleImportFileCallback;
    
    @Autowired
    private CsvMDImportDAO csvMDImportDAO;
    
    @Autowired
    private CsvImportFileDAO csvImportFileDAO;
    
    @Autowired
    private CsvSaleImportDAO csvSaleImportDao;

    @Autowired
    private CountriesHolder countriesHolder;

//    private CsvMDImportDAO mockedCsvMDImportDAO;
    
    private Locale localeBR = new Locale("pt", "BR");

    private ResourceBundle resourceBundle = ResourceBundle.getBundle("bundle/bundle");
    
    private UserDecorator mockedUserDecorator;
    
//	private static SimpleSmtpServer serverSMTP;
    
//  Really neccessary?
//	@BeforeClass
//	public static void start() {
//	
//		 serverSMTP = SimpleSmtpServer.start(getEnviromentSpecificSmtpPort());	 
//	}
//	
//	@AfterClass
//	public static void stop() {
//		if ( serverSMTP != null){
//			serverSMTP.stop();
//		}
//	}
	
    @Before
    public void init() {
        CountriesHolderInitializer.initialize(countriesHolder);
    	systemTestFixture = new SystemTestFixture(this);
        accessControlTestFixture = new AccessControlTestFixture(this, systemTestFixture);
        saleTestFixture = new SaleTestFixture(this, systemTestFixture);
		
        mockedUserDecorator = Mockito.mock(UserDecorator.class);
        Mockito.when(mockedUserDecorator.getLogin()).thenReturn("vrodrigues");
        
//		if (!getAssumptionTest().isEnvironmentWithSQLANSI()) {
//			mockedCsvMDImportDAO = Mockito.mock(CsvMDImportDAO.class);
//			Mockito.when(csvMDImportDAO.transferDirectSales("vrodrigues")).thenReturn(1L);
//			saleService = new SaleServiceImpl(mockedCsvMDImportDAO);
//		}
    }
    
    @Test
    public void given_one_direct_sale_to_process_when_import_should_update_status_for_loaded_and_set_csv_sale_file_line_id() {
    	directSaleTestFixture = new DirectSaleTestFixture(this);
    	directSaleTestFixture.createImportationDataSuccess(saleTestFixture, systemTestFixture, 1);
    	
    	CsvSale csvSale = (CsvSale) getSession().get(CsvSale.class, DirectSaleTestFixture.importDataForDirectSale.get(0).getId());
    	Assert.assertFalse("CsvSale status for import should be false", csvSale.isLoaded());
    	
    	Long csvSaleImportLineId = null;
    	
    	if (!getAssumptionTest().isEnvironmentWithSQLANSI()) {
    		createFileAndLineAndUpdateCsvSale(new CsvImportFile("Arquivo", "vrodrigues", ImportFileType.CSV_DIRECT_SALE), csvSale);
    		csvSaleImportLineId = csvSale.getId();
    		Assert.assertTrue("CsvSale status loaded should be true", csvSale.isLoaded());
    		Assert.assertEquals("CsvSaleImportLine id should be equals", csvSaleImportLineId, csvSale.getId());
//    	} else {
//    		CsvImportFile csvImportFile = saleService.createFileAndTransferDirectSales(mockedUserDecorator);
//    		List<CsvSaleImportLine> list = saleService.selectCsvImportLinesByFile(CsvSaleImportLine.class, CsvSaleImportLine.class, csvImportFile);
//    		Assert.assertEquals("List should be size 1", 1, list.size());
//    		
//    		csvSaleImportLineId = list.get(0).getCsvSaleId();
//    		csvSale = (CsvSale) getSession().createCriteria(CsvSale.class).add(Restrictions.eq("id", csvSaleImportLineId)).uniqueResult();
//    	}
    	}
    	
    }

    @Test
    public void given_loaded_csvSale_when_cancel_file_should_turn_status_to_false() {
    	directSaleTestFixture = new DirectSaleTestFixture(this);
    	directSaleTestFixture.createImportationDataSuccess(saleTestFixture, systemTestFixture, 1);
    	CsvSale csvSale = (CsvSale) getSession().get(CsvSale.class, DirectSaleTestFixture.importDataForDirectSale.get(0).getId());
    	CsvImportFile csvImportFile = null;
    	
    	UserDecorator userDecorator = new UserDecorator(accessControlTestFixture.itsSuperUser,accessControlTestFixture.itsSuperUser);
    	userDecorator.setContextCompany(systemTestFixture.monsantoBr);
    	userDecorator.setContextCrop(systemTestFixture.soy);
    	userDecorator.addProfile(accessControlTestFixture.profileWithOneAction);

    	if (!getAssumptionTest().isEnvironmentWithSQLANSI()) {
    		csvImportFile = createFileAndLineAndUpdateCsvSale(new CsvImportFile("Arquivo", "vrodrigues", ImportFileType.CSV_DIRECT_SALE), csvSale);
    	} else {
    		csvImportFile = saleService.createFileAndTransferDirectSales(userDecorator);
    	}
    	
    	csvDirectSaleImportFileCallback.doCancel(new FileImportInfo(
				csvImportFile, userDecorator,
				FileImportDefinition.CSV_DIRECT_SALE,
				FileImportOperation.CANCEL, localeBR, "bundle"));
    	
    	csvSale = (CsvSale) getSession().createCriteria(CsvSale.class).add(Restrictions.eq("id", DirectSaleTestFixture.importDataForDirectSale.get(0).getId())).uniqueResult();
    	List<CsvSaleImportLine> linesCancelled = saleService.selectCsvImportLinesByFile(CsvSaleImportLine.class, csvImportFile);
    	
    	Assert.assertFalse("Status loaded should be false after cancel file", csvSale.isLoaded());
    	Assert.assertEquals("CsvSaleImportLines should be empty", 0, linesCancelled.size());
    }
    
    @Test
    public void given_success_file_with_sale_errors_when_import_should_update_csvSale_statusLoaded_to_false() {
    	directSaleTestFixture = new DirectSaleTestFixture(this);
    	directSaleTestFixture.createImportationDataWithError(saleTestFixture, systemTestFixture, 1);
    	CsvSale csvSale = (CsvSale) getSession().get(CsvSale.class, DirectSaleTestFixture.importDataForDirectSale.get(0).getId());
    	CsvImportFile csvImportFile = null;
    	
    	UserDecorator userDecorator = new UserDecorator(accessControlTestFixture.itsSuperUser,accessControlTestFixture.itsSuperUser);
        userDecorator.setContextCompany(systemTestFixture.monsantoBr);
        userDecorator.setContextCrop(systemTestFixture.soy);
        userDecorator.addProfile(accessControlTestFixture.profileWithOneAction);
    	
        Assert.assertFalse("CsvSale status for import should be false", csvSale.isLoaded());
        
    	if (!getAssumptionTest().isEnvironmentWithSQLANSI()) {
    		csvImportFile = createFileAndLineAndUpdateCsvSale(new CsvImportFile("Arquivo", "vrodrigues", ImportFileType.CSV_DIRECT_SALE), csvSale);
    	} else {
    		csvImportFile = saleService.createFileAndTransferDirectSales(userDecorator);
    	}
    
		csvDirectSaleImportFileCallback.doImport(new FileImportInfo(
				csvImportFile, userDecorator,
				FileImportDefinition.CSV_DIRECT_SALE,
				FileImportOperation.IMPORT, localeBR, "bundle"));
		
		csvSale = (CsvSale) getSession().createCriteria(CsvSale.class).add(Restrictions.eq("id", DirectSaleTestFixture.importDataForDirectSale.get(0).getId())).uniqueResult();
		Assert.assertFalse("Status loaded should be false after import with errors file", csvSale.isLoaded());
    }
    
    @SuppressWarnings("unchecked")
	@Test
    public void given_success_file_with_valid_sale_when_process_should_process_sale_and_delete_from_csvSale() {
    	directSaleTestFixture = new DirectSaleTestFixture(this);
    	directSaleTestFixture.createImportationDataSuccess(saleTestFixture, systemTestFixture, 1);
    	CsvSale csvSale = (CsvSale) getSession().get(CsvSale.class, DirectSaleTestFixture.importDataForDirectSale.get(0).getId());
    	CsvImportFile csvImportFile = null;
    	
    	UserDecorator userDecorator = new UserDecorator(accessControlTestFixture.itsSuperUser,accessControlTestFixture.itsSuperUser);
        userDecorator.setContextCompany(systemTestFixture.monsantoBr);
        userDecorator.setContextCrop(systemTestFixture.soy);
        userDecorator.addProfile(accessControlTestFixture.profileWithOneAction);
    	
        Assert.assertFalse("CsvSale status for import should be false", csvSale.isLoaded());
        
    	if (!getAssumptionTest().isEnvironmentWithSQLANSI()) {
			csvImportFile = createFileAndLineAndUpdateCsvSale(
					new CsvImportFile("Arquivo", "vrodrigues",
							ImportFileType.CSV_DIRECT_SALE), csvSale);
    	} else {
    		csvImportFile = saleService.createFileAndTransferDirectSales(userDecorator);
    	}
    
		csvDirectSaleImportFileCallback.doProceed(new FileImportInfo(
				csvImportFile, userDecorator,
				FileImportDefinition.CSV_DIRECT_SALE,
				FileImportOperation.PROCEED, localeBR, "bundle"));
		
//		csvSale = (CsvSale) getSession().get(CsvSale.class, DirectSaleTestFixture.importDataForDirectSale.get(0).getId());
		List<CsvSale> list = (List<CsvSale>) getSession().createCriteria(CsvSale.class).list();
		Assert.assertTrue("CsvSales should be empty after successfull process", list.isEmpty());
    }
    
    @Test
    public void given_two_directSales_one_valid_other_with_error_when_process_should_deleteValidFromCsvSale_and_updateInvalidSaleStatusLoadedToFalse() {
    	directSaleTestFixture = new DirectSaleTestFixture(this);
    	directSaleTestFixture.createImportationDataWithError(saleTestFixture, systemTestFixture, 1);
    	directSaleTestFixture.createImportationDataSuccess(saleTestFixture, systemTestFixture, 1);
		CsvImportFile csvImportFile = null;
		
		UserDecorator userDecorator = new UserDecorator(accessControlTestFixture.itsSuperUser,accessControlTestFixture.itsSuperUser);
		userDecorator.setContextCompany(systemTestFixture.monsantoBr);
		userDecorator.setContextCrop(systemTestFixture.soy);
		userDecorator.addProfile(accessControlTestFixture.profileWithOneAction);

		if (!getAssumptionTest().isEnvironmentWithSQLANSI()) {
			CsvSale[] cSales = new CsvSale[DirectSaleTestFixture.importDataForDirectSale.size()];
			for (int i = 0; i < cSales.length; i++) {
				cSales[i] = DirectSaleTestFixture.importDataForDirectSale.get(i);
			}
			csvImportFile = createFileAndLineAndUpdateCsvSale(
					new CsvImportFile("Arquivo", "vrodrigues",
							ImportFileType.CSV_DIRECT_SALE),
							cSales);
		} else {
			csvImportFile = saleService.createFileAndTransferDirectSales(userDecorator);
		}
    	
        csvDirectSaleImportFileCallback.doProceed(new FileImportInfo(
				csvImportFile, userDecorator,
				FileImportDefinition.CSV_DIRECT_SALE,
				FileImportOperation.PROCEED, localeBR, "bundle"));
        
        List<CsvSale> list = saleService.getDirectSalesAvailable();
        Assert.assertEquals("Should have only one sale", 1, list.size());
        Assert.assertFalse("Should be in not loaded status", list.get(0).isLoaded());
    }
    
    @SuppressWarnings("unchecked")
	@Test
    public void given_one_invalid_directSale_when_load_more_sales_to_queue_then_getDirectSalesAvailable_should_only_return_not_loaded_csvSales() {
    	if (getAssumptionTest().isEnvironmentWithSQLANSI()) {

    		directSaleTestFixture = new DirectSaleTestFixture(this);
	    	directSaleTestFixture.createImportationDataSuccess(saleTestFixture, systemTestFixture, 1);
    	
	    	CsvImportFile csvImportFile = saleService.createFileAndTransferDirectSales(mockedUserDecorator);
	    	List<CsvSaleImportLine> list = saleService.selectCsvImportLinesByFile(CsvSaleImportLine.class, csvImportFile);
	    	Assert.assertEquals("Should have only one line", 1, list.size());
    	
	    	directSaleTestFixture.createImportationDataSuccess(saleTestFixture, systemTestFixture, 2);
	    	
    		csvImportFile = saleService.createFileAndTransferDirectSales(mockedUserDecorator);
    		list = saleService.selectCsvImportLinesByFile(CsvSaleImportLine.class, csvImportFile);
    		Assert.assertEquals("Should have two line", 2, list.size());
    		
    		List<CsvSale> existentCsvSales = getSession().createCriteria(CsvSale.class).list();
    		Assert.assertEquals("Should have three line", 3, existentCsvSales.size());
    	}
    }
    
    @Test
    public void given_one_invalid_directSale_when_i_reImport_should_bring_the_same_sale_again() {
    	if (getAssumptionTest().isEnvironmentWithSQLANSI()) {
	    	directSaleTestFixture = new DirectSaleTestFixture(this);
	    	directSaleTestFixture.createImportationDataWithError(saleTestFixture, systemTestFixture, 1);
	    	CsvSale csvSale = (CsvSale) getSession().get(CsvSale.class, DirectSaleTestFixture.importDataForDirectSale.get(0).getId());
	    	CsvImportFile csvImportFile = null;
	    	
	    	UserDecorator userDecorator = new UserDecorator(accessControlTestFixture.itsSuperUser,accessControlTestFixture.itsSuperUser);
			userDecorator.setContextCompany(systemTestFixture.monsantoBr);
			userDecorator.setContextCrop(systemTestFixture.soy);
			userDecorator.addProfile(accessControlTestFixture.profileWithOneAction);
	    	
			Long fileId = csvMDImportDAO.transferDirectSales("vrodrigues");
			getSession().flush();
    		csvImportFile = csvImportFileDAO.selectById(fileId);
	    	
    		csvSale = (CsvSale) getSession().createCriteria(CsvSale.class).add(Restrictions.eq("id", DirectSaleTestFixture.importDataForDirectSale.get(0).getId())).uniqueResult();
			Assert.assertTrue("CsvSale loaded status should be true after load", csvSale.isLoaded());
	    	
	    	csvDirectSaleImportFileCallback.doImport(new FileImportInfo(
					csvImportFile, userDecorator,
					FileImportDefinition.CSV_DIRECT_SALE,
					FileImportOperation.IMPORT, localeBR, "bundle"));
	    	
	    	csvSale = (CsvSale) getSession().createCriteria(CsvSale.class).add(Restrictions.eq("id", DirectSaleTestFixture.importDataForDirectSale.get(0).getId())).uniqueResult();
			Assert.assertFalse("CsvSale loaded status should be false after import", csvSale.isLoaded());
		
			Long fileId2 = csvMDImportDAO.transferDirectSales("vrodrigues");
			getSession().flush();
			CsvImportFile csvImportFile2 = csvImportFileDAO.selectById(fileId2);
//    		CsvImportFile csvImportFile2 = saleService.createFileAndTransferDirectSales(userDecorator);
    		
    		Assert.assertNotSame("Files should not be the same", csvImportFile, csvImportFile2);
    		
    		csvSale = (CsvSale) getSession().createCriteria(CsvSale.class).add(Restrictions.eq("id", DirectSaleTestFixture.importDataForDirectSale.get(0).getId())).uniqueResult();
			Assert.assertTrue("CsvSale loaded status should be true after load", csvSale.isLoaded());
    	}
    }
    
	private CsvImportFile createFileAndLineAndUpdateCsvSale(CsvImportFile csvImportFile, CsvSale... csvSales) {
		saveAndFlush(csvImportFile);
		
		for (CsvSale csvSale : csvSales) {
			CsvSaleImportLine csvSaleImportLine = new CsvSaleImportLine(csvSale, csvImportFile);
			saveAndFlush(csvSaleImportLine);
			csvSale.setLoaded(true);
			saveAndFlush(csvSale);
		}
		return csvImportFile;
	}
    
	@Test
	public void given_number_of_direct_sales_should_generate_csv_sale_lines() throws CSVReadableInvalidException {
		directSaleTestFixture = new DirectSaleTestFixture(this);
		directSaleTestFixture.createImportationDataSuccess(saleTestFixture, systemTestFixture, 10);
        
		DirectSaleParser parser = new DirectSaleParser(new UserDecorator(accessControlTestFixture.itsSuperUser,accessControlTestFixture.itsSuperUser), saleService);
        
        if(getAssumptionTest().isEnvironmentWithSQLANSI()) {
			parser.readFile();
	        
			CsvImportFile file = parser.getFile();
	        List<CsvSaleImportLine> lines = saleService.selectCsvImportLinesByFile(CsvSaleImportLine.class, file);
	        
	        Assert.assertEquals(10, lines.size());
        }
	}
    
	@Test
	public void given_number_of_direct_sales_should_import_process_10_lines() throws CSVReadableInvalidException, ImportFileCallbackException{
		directSaleTestFixture = new DirectSaleTestFixture(this);
        Calendar jan2012 = Calendar.getInstance();
        jan2012.set(2012, 0, 1);

        Calendar dec2013 = Calendar.getInstance();
        dec2013.set(2013, 11, 31);
        
		directSaleTestFixture.createImportationDataSuccess(saleTestFixture, systemTestFixture, 10);
        
		UserDecorator userDecorator = new UserDecorator(accessControlTestFixture.itsSuperUser,accessControlTestFixture.itsSuperUser);
        userDecorator.setContextCompany(systemTestFixture.monsantoBr);
        userDecorator.setContextCrop(systemTestFixture.soy);
        userDecorator.addProfile(accessControlTestFixture.profileWithOneAction);
		DirectSaleParser parser = new DirectSaleParser(userDecorator, saleService);
        
        if(getAssumptionTest().isEnvironmentWithSQLANSI()) {
    		parser.readFile();
            
    		CsvImportFile file = parser.getFile();
            file.setFileStatus(ImportFileStatus.UPLOADED); // temp fix until proc is altered
            saveAndFlush(file);
        
            List<CsvSaleImportLine> lines = saleService.selectCsvImportLinesByFile(CsvSaleImportLine.class, file);
            Assert.assertEquals(10, lines.size());
            
            
            csvDirectSaleImportFileCallback.importFileCallback(new FileImportInfo(parser.getFile(), userDecorator,
                    FileImportDefinition.CSV_DIRECT_SALE, FileImportOperation.IMPORT, localeBR, "bundle"));
            
            CsvImportFile csvFile = (CsvImportFile) getSession().get(CsvImportFile.class, parser.getFile().getId());
            
            List<CsvSaleImportResult> results = saleService.selectCsvSaleImportResultByFile(CsvSaleImportResult.class, csvFile);
            Assert.assertEquals(0, results.size());
          
			parser.setFile(csvFile);
            parser.getFile().setFileStatus(ImportFileStatus.AWAITING_PROCESSING);
            saveAndFlush(parser.getFile());
            csvDirectSaleImportFileCallback.importFileCallback(new FileImportInfo(parser.getFile(), userDecorator,
                    FileImportDefinition.CSV_DIRECT_SALE, FileImportOperation.PROCEED, localeBR, "bundle"));
            
            List<Sale> saleBy = saleService.getSaleBy(SaleFilter.getInstance().add(systemTestFixture.monsantoBr)
                    .add(systemTestFixture.soy).addCreationDateStart(jan2012.getTime())
                    .addCreationDateEnd(dec2013.getTime()).addGrowerDocument(SaleTestFixture.CHICO_CNPJ));
            Assert.assertEquals(10, saleBy.size());

            
        }
	}

    @Test
    public void sanity_test() throws CSVReadableInvalidException, CSVInvalidLayoutException, IOException {
        CsvImportFile file = csvImportFileService.saveFile(new CsvImportFile("sample.csv",
                accessControlTestFixture.itsSuperUser.getLogin(), ImportFileType.CSV_SALE));
        Assert.assertNotNull(file.getId());
        List<CsvSale> csvSales = generateDummyStringCsvSales();

        Long fileId = file.getId();
        getSession().evict(file);
        file = null;

        file = csvImportFileService.selectById(fileId);
        Assert.assertNotNull(file);
        Assert.assertEquals("sample.csv", file.getFileName());

        List<CsvSaleImportLine> dbLines = saleService.selectCsvImportLinesByFile(CsvSaleImportLine.class, file);
        Assert.assertEquals(0, dbLines.size());

        List<Indexable> lines = new ArrayList<Indexable>();
        for (CsvSale sale : csvSales) {
            lines.add(new CsvSaleImportLine(sale, file));
        }
        int numLines = lines.size();
        saleService.saveFileAndLines(file, lines);

        for (Indexable line : lines) {
            Assert.assertNotNull(line.getId());
            getSession().evict(line);
        }

        dbLines = null;
        dbLines = saleService.selectCsvImportLinesByFile(CsvSaleImportLine.class, file);
        Assert.assertEquals(numLines, dbLines.size());

        file = saleService.cancelImportFile(CsvSaleImportLine.class, file);
        Assert.assertNotNull(file);

        dbLines = saleService.selectCsvImportLinesByFile(CsvSaleImportLine.class, file);
        Assert.assertEquals(0, dbLines.size());
    }

    @Test
    public void given_invalid_line_should_flag_correct_sales_false() throws Exception {
        SaleFileParser parser = createAndValidateInValidSale();
        parser.readFile();
        Assert.assertTrue(parser.getFile().getValidFile());
        csvSaleImportFileCallback.setBundle(resourceBundle, localeBR);
        csvSaleImportFileCallback.importFileCallback(new FileImportInfo(parser.getFile(), new UserDecorator(
                accessControlTestFixture.itsSuperUser, accessControlTestFixture.itsSuperUser),
                FileImportDefinition.CSV_SALE, FileImportOperation.IMPORT, localeBR, "bundle"));
        List<CsvSaleImportLine> csvLines = saleService.selectCsvImportLinesByFile(CsvSaleImportLine.class, parser.getFile());
        Assert.assertEquals(1, csvLines.size());
        long saleGroup = 0;
        for (CsvSaleImportLine line : csvLines) {
            // Assert.assertEquals("", line.getCodeWarn());
            Assert.assertNotNull(line.getSaleGroup());
            saleGroup = line.getSaleGroup();
        }

        List<CsvSaleImportResult> csvResults = csvSaleImportDao.selectCsvSaleResults(CsvSaleImportResult.class, parser.getFile());
        Assert.assertEquals(1, csvResults.size());
        for (CsvSaleImportResult result : csvResults) {
            Assert.assertNotNull(result.getImportResult());
            Assert.assertEquals(saleGroup, result.getSaleGroup().longValue());
        }

        Long id = parser.getFile().getId();
        getSession().evict(parser.getFile());
        CsvImportFile file = csvImportFileService.selectById(id);
        Assert.assertFalse(file.getValidFile());
    }

    @Test
    public void test_valid_sale() throws Exception {
        Calendar jan2012 = Calendar.getInstance();
        jan2012.set(2012, 0, 1);

        Calendar dec2113 = Calendar.getInstance();
        dec2113.set(2113, 11, 31);

        SaleFileParser parser = makeValidLine();
        parser.readFile();
        Assert.assertTrue(parser.getFile().getValidFile());
        csvSaleImportFileCallback.setBundle(resourceBundle, localeBR);
        UserDecorator user = new UserDecorator(accessControlTestFixture.itsSuperUser,
                accessControlTestFixture.itsSuperUser);
        user.setContextCompany(systemTestFixture.mons4ntoBr);
        user.setContextCrop(systemTestFixture.soyMons4nto);
        user.addProfile(accessControlTestFixture.profileWithOneAction);
        
        csvSaleImportFileCallback.importFileCallback(new FileImportInfo(parser.getFile(), user,
                FileImportDefinition.CSV_SALE, FileImportOperation.IMPORT, localeBR, "bundle"));
        List<CsvSaleImportResult> csvResults = csvSaleImportDao.selectCsvSaleResults(CsvSaleImportResult.class, parser.getFile());
        Assert.assertEquals(1, csvResults.size());
        
//        assertEmailSent();
        
        parser.getFile().setFileStatus(ImportFileStatus.AWAITING_PROCESSING);
        csvSaleImportFileCallback.importFileCallback(new FileImportInfo(parser.getFile(), user,
                FileImportDefinition.CSV_SALE, FileImportOperation.PROCEED, localeBR, "bundle"));
        csvResults = csvSaleImportDao.selectCsvSaleResults(CsvSaleImportResult.class, parser.getFile());
        List<Sale> saleBy = saleService.getSaleBy(SaleFilter.getInstance().add(systemTestFixture.mons4ntoBr)
                .add(systemTestFixture.soyMons4nto).addInvoiceNumber("9999").addCreationDateStart(jan2012.getTime())
                .addCreationDateEnd(dec2113.getTime()));
        Assert.assertEquals(0, saleBy.size());
        
        
        assertEmailSent();
	
    }

	private void assertEmailSent() {
		
//		EnvironmentSpecificPropertyReader environment = new EnvironmentSpecificPropertyReader();
		
//		String envName = environment.getEnvironmentSpecificProperty("reset.password.subject.environment", null);
//		
//		@SuppressWarnings("unchecked")
//		Iterator<SmtpMessage> receivedEmail = serverSMTP.getReceivedEmail();
//        while (receivedEmail.hasNext()){
//        	System.out.println("###############################################################################");
//        	SmtpMessage msg = receivedEmail.next();
//			System.out.println(msg);
//        	System.out.println("###############################################################################");
//        	Assert.assertEquals("Asserting TO ", "rferreira@cit.com", msg.getHeaderValue("To"));
//			String envEspecificSubject = subject +" (" +envName +")";
//			Assert.assertEquals("Asserting Subject ", envEspecificSubject, msg.getHeaderValue("Subject"));
//        }
	}
    
    @Test
    public void test_valid_invalid_sale() throws Exception {
        Calendar jan2012 = Calendar.getInstance();
        jan2012.set(2012, 0, 1);

        Calendar dec2113 = Calendar.getInstance();
        dec2113.set(2113, 11, 31);

        SaleFileParser parser = createValidInvalidSales();
        parser.readFile();
        Assert.assertTrue(parser.getFile().getValidFile());
        csvSaleImportFileCallback.setBundle(resourceBundle, localeBR);
        UserDecorator user = new UserDecorator(accessControlTestFixture.itsSuperUser,
                accessControlTestFixture.itsSuperUser);
        user.setContextCompany(systemTestFixture.mons4ntoBr);
        user.setContextCrop(systemTestFixture.soyMons4nto);
        user.addProfile(accessControlTestFixture.profileWithOneAction);
        int count = saleService.selectCsvImportLinesByFile(CsvSaleImportLine.class, parser.getFile()).size();
        Assert.assertEquals(2, count);
        csvSaleImportFileCallback.importFileCallback(new FileImportInfo(parser.getFile(), user,
                FileImportDefinition.CSV_SALE, FileImportOperation.IMPORT, localeBR, "bundle"));
        int count2 = saleService.selectCsvImportLinesByFile(CsvSaleImportLine.class, parser.getFile()).size();
        Assert.assertEquals(count, count2);
      //  Assert.assertTrue(parser.getFile().getValidFile());
        List<CsvSaleImportResult> csvResults = csvSaleImportDao.selectCsvSaleResults(CsvSaleImportResult.class, parser.getFile());
        Assert.assertEquals(1, csvResults.size());
        parser.getFile().setFileStatus(ImportFileStatus.AWAITING_PROCESSING);
        csvSaleImportFileCallback.importFileCallback(new FileImportInfo(parser.getFile(), user,
                FileImportDefinition.CSV_SALE, FileImportOperation.PROCEED, localeBR, "bundle"));
        csvResults = csvSaleImportDao.selectCsvSaleResults(CsvSaleImportResult.class, parser.getFile());
        Assert.assertEquals(1, csvResults.size());
        SaleFilter saleFilter = SaleFilter.getInstance().add(systemTestFixture.mons4ntoBr)
                .add(systemTestFixture.soyMons4nto).addInvoiceNumber("9999").addCreationDateStart(jan2012.getTime())
                .addCreationDateEnd(dec2113.getTime());
        List<Sale> saleBy = saleService.getSaleBy(saleFilter);
        Assert.assertEquals(0, saleBy.size());
    }

    private List<CsvSale> generateDummyStringCsvSales() throws IOException, CSVInvalidLayoutException,
            CSVReadableInvalidException {
        return createParser(
                new String[][] { { "9999", "20/04/2012", "CNPJ", "12.345.678/9012-34", "123456789", "120032", "CPF",
                        "123.456.789-00", "SP","10","11", CalendarUtil.formatDate(new Date(), "dd/MM/yyyy"), "Soja", "monsanto", "Safrinha", "2012", "CNPJ",
                        "12.345.678/9012-34", "123456789", "122300", "Cobran�a de Royalt via boleto", "10516534",
                        "01/12/2012", "45 a 54 Kg","CNPJ","12.345.678/9012-34","1243","69"
                        , "0,3", "1000", "Venda de Soja Monsanto" } }).getCsvSales();
    }

    private SaleFileParser createParser(String[][] values) throws CSVReadableInvalidException,
            CSVInvalidLayoutException, IOException {
        // SaleFileParser parser = new SaleFileParser(
        // sample line
        StringBuilder build = null;
        for (String[] value : values) {
            build = generateCsvLine(value, build);
        }
        ByteArrayInputStream bais = new ByteArrayInputStream(build.toString().getBytes());
        SaleFileParser parser = new SaleFileParser(bais, localeBR, new UserDecorator(
                accessControlTestFixture.itsSuperUser, accessControlTestFixture.itsSuperUser), saleService,
                "sample.csv");
        return parser;
    }

    private SaleFileParser makeValidLine() throws CSVReadableInvalidException, CSVInvalidLayoutException, IOException {
        return createParser(new String[][] { createValidLine() });
    }

    private String[] createValidLine() {
        Customer c = saleTestFixture.matrixMons4nto;
        return new String[] { "9999", "26/04/2012", "CNPJ", c.getDocument().getValue(), "", c.getCustomerSAPCode(),
                "CNPJ", saleTestFixture.chicoBento.getDocument().getValue(),
                systemTestFixture.matoGrossoDoSul.getCode(), CalendarUtil.formatDate(new Date(), "dd/MM/yyyy"),
                systemTestFixture.soyMons4nto.getDescription(), systemTestFixture.mons4ntoBr.getDescription(),
                saleTestFixture.harvestSoyMons4nto2012.getDescription(),
                saleTestFixture.harvestSoyMons4nto2012.getOperationalYear().getYear(), "CNPJ",
                c.getDocument().getValue(), "", c.getCustomerSAPCode(),
                saleTestFixture.templateIntactaMons4nto.getDescription(),
                saleTestFixture.productIntactaSoyMons4nto.getId().toString(), CalendarUtil.formatDate(new Date(), "dd/MM/yyyy"),
                saleTestFixture.plantability45To54SoyMons4nto2012.getDescription(), "505", "0,7", "100", "NOTE" };
    }

    private SaleFileParser createAndValidateInValidSale() throws CSVReadableInvalidException,
            CSVInvalidLayoutException, IOException { // TODO need to generate
                                                     // valid sale
        return createParser(new String[][] { createInvalidLine() });
    }

    private SaleFileParser createValidInvalidSales() throws CSVReadableInvalidException, CSVInvalidLayoutException,
            IOException {
        return createParser(new String[][] { createInvalidLine(), createValidLine() });
    }
    
    private String[] createInvalidLine() {
        return new String[] { "83", "20/04/12", "CNPJ", "77046101298780", "", "", "CPF",
                "64534466269", "MSS", CalendarUtil.formatDate(new Date(), "dd/MM/yyyy"), "SOJA IMPORT", "MONSANTO IMPORT", "HARVEST TO IMPORT",
                "2008", "CNPJ", "77727239523705", "", "", "TEMPLATE TO IMPORT", "1", "01/12/12",
                "System Plantability of Harvest Soy Monsanto 2012", "505", "0", "1000", "teste" };
    }

    private StringBuilder generateCsvLine(String[] lineData, StringBuilder builder) {
        if (builder == null) {
            builder = new StringBuilder();
            builder.append("Nota Fiscal N�mero;Data de Emiss�o da Nota Fiscal;Tipo de documento do Parceiro;N�mero do documento do Parceiro;N�mero da Inscri��o Estadual do Parceiro;"
                    + "C�digo ERP Parceiro;Tipo de documento do agricultor;N�mero do documento do Agricultor;UF de Plantio;Data de Lan�amento;Cultura;Empresa;Safra;Ano Operacional;"
                    + "Tipo de documento da matriz;N�mero do documento da Matriz;N�mero da Inscri��o Estadual da Matriz;C�digo ERP Matriz;Modelo de Venda;C�digo do Produto;Data do Vencimento Pagamento;"
                    + "Plantabilidade ;Quantidade Produtividade;Pre�o por Kg de semente;Quantidade de Semente Vendida;Observa��o");
            builder.append("\n");
        }
        for (int i = 0; i < lineData.length; i++) {
            builder.append(lineData[i]);
            if (i < lineData.length - 1) {
                builder.append(";");
            }
        }
        builder.append("\n");

        return builder;
    }
}
