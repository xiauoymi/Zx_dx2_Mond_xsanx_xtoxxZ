package com.monsanto.brazilvaluecapture.jobs.executor.messaging.service.impl;

import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.monsanto.brazilvaluecapture.core.base.SystemTestFixture;
import com.monsanto.brazilvaluecapture.core.foundation.service.EntityNotFoundException;
import com.monsanto.brazilvaluecapture.core.foundation.test.AbstractServiceIntegrationTests;
import com.monsanto.brazilvaluecapture.core.user.AccessControlTestFixture;
import com.monsanto.brazilvaluecapture.core.user.model.bean.UserContext;
import com.monsanto.brazilvaluecapture.core.user.model.bean.UserDecorator;
import com.monsanto.brazilvaluecapture.jobs.executor.messaging.bean.JobDefinition;
import com.monsanto.brazilvaluecapture.jobs.executor.messaging.service.ExecutorDispatcher;

public class ExecutorDispatcher_AT extends AbstractServiceIntegrationTests {

    @Autowired
    private ExecutorDispatcher executorDispatcher;

    private UserContext user;

    @Before
    public void init() {
        this.systemTestFixture = new SystemTestFixture(this);
        this.accessControlTestFixture = new AccessControlTestFixture(this, systemTestFixture);
        user = new UserDecorator(this.accessControlTestFixture.itsSuperUser, this.accessControlTestFixture.itsSuperUser);
    }

    @Test
    public void when_expire_credit_should_pass() throws EntityNotFoundException {
        executorDispatcher.sendMessage(systemTestFixture.soyMons4nto.getDescription(),
                systemTestFixture.mons4ntoBr.getDescription(), "CREDIT_EXPIRATION", user);
        executorDispatcher.sendMessage(systemTestFixture.soyMons4nto, systemTestFixture.mons4ntoBr,
                JobDefinition.BILL_SALES, user);
    }

    @Test(expected = EntityNotFoundException.class)
    public void when_expire_credit_with_invalid_crop_should_throw_enfe() throws EntityNotFoundException {
        executorDispatcher.sendMessage("", systemTestFixture.mons4ntoBr.getDescription(), "CREDIT_EXPIRATION", user);
    }

    @Test(expected = EntityNotFoundException.class)
    public void when_expire_credit_with_invalid_company_should_throw_enfe() throws EntityNotFoundException {
        executorDispatcher.sendMessage(systemTestFixture.soyMons4nto.getDescription(), "", "CREDIT_EXPIRATION", user);
    }

    @Test(expected = IllegalArgumentException.class)
    public void when_expire_credit_with_invalid_job_name_should_throw_iae() throws EntityNotFoundException {
        executorDispatcher.sendMessage(systemTestFixture.soyMons4nto.getDescription(),
                systemTestFixture.mons4ntoBr.getDescription(), "CREDIT_EXPIRAT", user);
    }

    @Test
    public void when_generate_tax_compensation_should_pass() throws EntityNotFoundException {
        executorDispatcher.sendMessage(systemTestFixture.soyMons4nto.getDescription(),
                systemTestFixture.mons4ntoBr.getDescription(), "TAX_COMPENSATION_ROL", user);
    }

    @Test
    public void when_pay_billings_seed_sale_should_pass() throws EntityNotFoundException {
        executorDispatcher.sendMessage(systemTestFixture.soyMons4nto.getDescription(),
                systemTestFixture.mons4ntoBr.getDescription(), "PAY_BILLINGS_SEED_SALE", user);
    }

    @Test(expected = EntityNotFoundException.class)
    public void when_pay_billings_seed_sale_with_invalid_crop_should_throw_enfe() throws EntityNotFoundException {
        executorDispatcher.sendMessage("", systemTestFixture.mons4ntoBr.getDescription(),
                JobDefinition.PAY_BILLINGS_SEED_SALE.name(), user);
    }

    @Test(expected = EntityNotFoundException.class)
    public void when_pay_billings_seed_sale_with_invalid_company_should_throw_enfe() throws EntityNotFoundException {
        executorDispatcher.sendMessage(systemTestFixture.soyMons4nto.getDescription(), "",
                JobDefinition.PAY_BILLINGS_SEED_SALE.name(), user);
    }

    @Test(expected = IllegalArgumentException.class)
    public void when_pay_billings_seed_sale_with_invalid_job_name_should_throw_iae() throws EntityNotFoundException {
        executorDispatcher.sendMessage(systemTestFixture.soyMons4nto.getDescription(),
                systemTestFixture.mons4ntoBr.getDescription(), "PAY_BILL_SEED_SAL", user);
    }

    @Test
    public void when_pay_billings_pod_should_pass() throws EntityNotFoundException {
        executorDispatcher.sendMessage(systemTestFixture.soyMons4nto.getDescription(),
                systemTestFixture.mons4ntoBr.getDescription(), "PAY_BILLING_POD", user);
    }

    @Test
    public void when_generate_charge_consolidate_should_pass() throws EntityNotFoundException {
        executorDispatcher.sendMessage(systemTestFixture.soyMons4nto.getDescription(),
                systemTestFixture.mons4ntoBr.getDescription(), "GENERATE_CHARGE_CONSOLIDATE", user);
    }
    
    @Test
    public void when_send_charge_consolidate_erp_should_pass() throws EntityNotFoundException {
        executorDispatcher.sendMessage(systemTestFixture.soyMons4nto.getDescription(),
                systemTestFixture.mons4ntoBr.getDescription(), "SEND_CHARGE_CONSOLIDATE_ERP", user);
    }
    
    @Test
    public void when_send_provisioning_should_pass() throws EntityNotFoundException {
        executorDispatcher.sendMessage(systemTestFixture.soyMons4nto.getDescription(),
                systemTestFixture.mons4ntoBr.getDescription(), "SEND_PROVISIONING", user);
    }
}
