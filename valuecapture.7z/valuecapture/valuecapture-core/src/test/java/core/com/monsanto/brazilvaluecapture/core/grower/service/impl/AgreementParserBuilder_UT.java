package com.monsanto.brazilvaluecapture.core.grower.service.impl;

import com.monsanto.brazilvaluecapture.core.base.service.CompanyService;
import com.monsanto.brazilvaluecapture.core.foundation.util.ConstraintViolation;
import com.monsanto.brazilvaluecapture.core.grower.model.bean.Agreement;
import com.monsanto.brazilvaluecapture.core.grower.model.bean.AgreementTemplate;
import com.monsanto.brazilvaluecapture.core.grower.service.GrowerConstraintViolationException;
import junit.framework.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import static org.mockito.Mockito.doThrow;

/**
 * Created by IntelliJ IDEA.
 * User: LSCHW1
 */

@RunWith(MockitoJUnitRunner.class)
public class AgreementParserBuilder_UT {


    @Mock
    private CompanyService companyService;

    @InjectMocks
    private AgreementParserBuilder agreementParserBuilder;

    private CsvAgreement validCsvAgreement;

    private static final Agreement.AgreementStatusEnum validCsvAgreementStatus=Agreement.AgreementStatusEnum.APPROVED;


    @Before
    public void setUp(){
        validCsvAgreement=new CsvAgreement();
        validCsvAgreement.setLicensedNumber("123");
        validCsvAgreement.setAgreementStatus(String.valueOf(validCsvAgreementStatus.getValue()));
        validCsvAgreement.setReproveComment("comment");
        validCsvAgreement.setDocumentNumber("5555");
        validCsvAgreement.setAgreementDate(new Date());
    }

    @Test
    public void searchErrors_ShouldAddWarnings_WhenCsvAgreementsHaveWarnings(){

        List<CsvAgreement> csvAgreements = createCvsAgreementsWithWarnings();
        agreementParserBuilder.setCsvAgreementToProcess(csvAgreements);

        agreementParserBuilder.searchErrors();

        Assert.assertFalse(agreementParserBuilder.getAgreementParserResult().getWarnings().isEmpty());
    }

    private List<CsvAgreement> createCvsAgreementsWithWarnings() {
        List<CsvAgreement> csvAgreements = new ArrayList<CsvAgreement>();
        CsvAgreement agreementWithWarn=new CsvAgreement();
        agreementWithWarn.setWarn("warnCode");
        csvAgreements.add(agreementWithWarn);
        return csvAgreements;
    }


    @Test
    public void searchErrors_ShouldNotAddWarnings_WhenCsvAgreementsAreValid(){

        List<CsvAgreement> csvAgreements = createCvsAgreementsValids();
        agreementParserBuilder.setCsvAgreementToProcess(csvAgreements);

        agreementParserBuilder.searchErrors();

        Assert.assertTrue(agreementParserBuilder.getAgreementParserResult().getWarnings().isEmpty());
    }

    private List<CsvAgreement> createCvsAgreementsValids() {
        List<CsvAgreement> csvAgreements = new ArrayList<CsvAgreement>();
        csvAgreements.add(validCsvAgreement);
        return csvAgreements;
    }

    @Test
    public void build_ShouldNotAddResults_WhenCvsAgreementHasWarnings(){

        agreementParserBuilder.setCsvAgreementToProcess(createCvsAgreementsWithWarnings());
        agreementParserBuilder.build();

        Assert.assertTrue(agreementParserBuilder.getAgreementParserResult().getCorrectBeans().isEmpty());
    }

    @Test
    public void build_ShouldAddCorrectResults_WhenCvsAgreementAreValid(){

        agreementParserBuilder.setCsvAgreementToProcess(createCvsAgreementsValids());
        agreementParserBuilder.build();

        Assert.assertFalse(agreementParserBuilder.getAgreementParserResult().getCorrectBeans().isEmpty());

        Agreement result=agreementParserBuilder.getAgreementParserResult().getCorrectBeans().iterator().next();
        Assert.assertEquals(validCsvAgreement.getAgreementDate(),result.getAgreementDate());
        Assert.assertEquals(validCsvAgreement.getLicensedNumber(),result.getLicenseNumber());
        Assert.assertEquals(validCsvAgreementStatus,result.getStatus());
        Assert.assertEquals(validCsvAgreement.getReproveComment(),result.getComment());
        Assert.assertEquals(validCsvAgreement.getDocumentNumber(),result.getGrowerDocument());
    }

    @Test
    public void build_ShouldAddCorrectResults_WhenCvsAgreementAreValidAndAvoidInvalids(){

        agreementParserBuilder.setCsvAgreementToProcess(createMixedCvsAgreement());
        agreementParserBuilder.build();

        Assert.assertEquals(1, agreementParserBuilder.getAgreementParserResult().getCorrectBeans().size());

        Agreement result=agreementParserBuilder.getAgreementParserResult().getCorrectBeans().iterator().next();
        Assert.assertEquals(validCsvAgreement.getAgreementDate(),result.getAgreementDate());
        Assert.assertEquals(validCsvAgreement.getLicensedNumber(),result.getLicenseNumber());
        Assert.assertEquals(validCsvAgreementStatus,result.getStatus());
        Assert.assertEquals(validCsvAgreement.getReproveComment(),result.getComment());
        Assert.assertEquals(validCsvAgreement.getDocumentNumber(),result.getGrowerDocument());
    }

    private List<? extends CsvAgreement> createMixedCvsAgreement() {
        List<CsvAgreement> csvAgreements=createCvsAgreementsWithWarnings();
        csvAgreements.add(validCsvAgreement);
        return csvAgreements;
    }


    @Test
    public void build_ShouldNotAddResults_WhenCvsAgreementIsInvalid() throws GrowerConstraintViolationException {

        List<ConstraintViolation> constraintViolations=new ArrayList<ConstraintViolation>();
        constraintViolations.add(new ConstraintViolation("msg","code","field"));
        doThrow(new GrowerConstraintViolationException("", constraintViolations)).when(companyService).validateAgreement(Matchers.<Agreement>any(), Matchers.<AgreementTemplate>any(), Matchers.<List>any());
        agreementParserBuilder.setCsvAgreementToProcess(createCvsAgreementsValids());

        agreementParserBuilder.build();

        Assert.assertFalse(agreementParserBuilder.getAgreementParserResult().getWarnings().isEmpty());
        Assert.assertTrue(agreementParserBuilder.getAgreementParserResult().getCorrectBeans().isEmpty());
    }

}
