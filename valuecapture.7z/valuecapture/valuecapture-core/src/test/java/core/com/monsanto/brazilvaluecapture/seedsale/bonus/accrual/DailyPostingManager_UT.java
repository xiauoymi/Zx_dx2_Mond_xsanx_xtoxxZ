package com.monsanto.brazilvaluecapture.seedsale.bonus.accrual;

import com.monsanto.brazilvaluecapture.core.foundation.service.BusinessException;
import com.monsanto.brazilvaluecapture.core.posting.model.bean.ReferenceNameEnum;
import com.monsanto.brazilvaluecapture.core.posting.service.PostingService;
import com.monsanto.brazilvaluecapture.jobs.executor.messaging.bean.JobExecutionInfo;
import com.monsanto.brazilvaluecapture.osb.its.api.InfraException;
import com.monsanto.brazilvaluecapture.seedsale.bonus.accrual.service.BonusAccrualService;
import com.monsanto.brazilvaluecapture.seedsale.posting.osb.OsbBonusPostingService;
import junit.framework.TestCase;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.math.BigDecimal;
import java.util.Date;

import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.*;
import static org.mockito.MockitoAnnotations.initMocks;

@RunWith(MockitoJUnitRunner.class)
public class DailyPostingManager_UT extends TestCase {

    @Mock
    private PostingService postingService;

    @Mock
    private BonusAccrualService bonusAccrualService;

    @InjectMocks
    private DailyPostingManager dailyPostingManager;

    @Before
    public void init() {
        dailyPostingManager = new DailyPostingManager();
        initMocks(this);
    }

    @Test
    public void testExecutesubmitAndSaveBonusPosting_whenJobIsExecuted() throws BusinessException, InfraException {
        JobExecutionInfo executionInfo = mock(JobExecutionInfo.class);
        BigDecimal bonusTotalReversal = BigDecimal.TEN;
        when(bonusAccrualService.calculateTotalReversal()).thenReturn(bonusTotalReversal);

        dailyPostingManager.execute(executionInfo);

        verify(postingService).submitAndSaveBonusPosting(eq(bonusTotalReversal), eq(ReferenceNameEnum.BONUS_ACCRUAL_EXPIRATION), anyString(), any(Date.class), any(Date.class), eq(OsbBonusPostingService.DEFAULT_TECHNOLOGY));
    }
}