package com.monsanto.brazilvaluecapture.pod.rol.model.bean;

import com.monsanto.brazilvaluecapture.core.customer.model.bean.Customer;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.HeadOffice;


public class RolStatusTestData {

    public static RolStatus createRolStatusWithCode(String code) {
        RolStatus rolStatus = new RolStatus();
        rolStatus.setRolStatusCode(code);
        return rolStatus;
    }
}
