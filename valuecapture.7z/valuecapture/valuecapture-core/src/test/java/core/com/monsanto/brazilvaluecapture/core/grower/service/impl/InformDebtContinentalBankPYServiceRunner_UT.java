package com.monsanto.brazilvaluecapture.core.grower.service.impl;

import com.monsanto.brazilvaluecapture.core.base.model.bean.Document;
import com.monsanto.brazilvaluecapture.core.base.service.ServiceRunner;
import com.monsanto.brazilvaluecapture.core.base.service.ServiceRunnerDataService;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Customer;
import com.monsanto.brazilvaluecapture.core.foundation.model.dao.SystemParameterDAO;
import com.monsanto.brazilvaluecapture.core.grower.model.bean.Grower;
import com.monsanto.brazilvaluecapture.core.grower.service.WithholdingService;
import com.monsanto.brazilvaluecapture.core.wsiconsole.bean.WsiServiceInstance;
import com.monsanto.brazilvaluecapture.osb.its.api.LASVCInformDebtContinentalBankPYService;
import com.monsanto.brazilvaluecapture.osb.its.api.LASVCInformDebtContinentalBankPYServiceFactory;
import com.monsanto.brazilvaluecapture.osb.its.lascontinentalbankpy.bean.OperationResult;
import com.monsanto.brazilvaluecapture.osb.util.SecurityContextHolder;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.Sale;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.Spy;
import org.mockito.runners.MockitoJUnitRunner;

import java.math.BigDecimal;
import java.util.Date;
import java.util.Map;

import static junit.framework.Assert.*;
import static org.fest.reflect.core.Reflection.field;


/**
 * Tests for InformDebtContinentalBankPYServiceRunner
 *
 * @author Fdez, Israel
 * @since 3.1.1
 */
@RunWith(MockitoJUnitRunner.class)
public class InformDebtContinentalBankPYServiceRunner_UT {
    private final String SERVICE_URL_PROPERTY = "osb_lasvc_inform_debt_continental_bank_py_url";

    @Mock
    private LASVCInformDebtContinentalBankPYServiceFactory lasvcInformDebtContinentalBankPYServiceFactory;

    @Mock
    private LASVCInformDebtContinentalBankPYService osbService;

    @Mock
    private SecurityContextHolder securityContext;

    @Mock
    private SystemParameterDAO systemParameterDAO;

    @Mock
    ServiceRunnerDataService serviceRunnerDataService;
    
    @Mock
    WithholdingService withholdingService;
    
    

    @Spy
    @InjectMocks
    private InformDebtContinentalBankPYServiceRunner informDebtContinentalBankPYServiceRunner;

    private OperationResult operationResult;

    private Sale sale;
    private Grower grower;
    private final String SOME_DATE_VALUE = "12/12/12";

    @Before
    public void setUp() throws Exception {
        grower = new Grower();
        Document document = new Document(null, "docValue");
        grower.setDocument(document);
        Customer customer = new Customer();
        sale = Mockito.spy(new Sale(customer, grower));
        Mockito.when(sale.getSaleOrderSAPId()).thenReturn(1l);
        Mockito.when(sale.getTotalRoyaltyValue()).thenReturn(BigDecimal.ONE);
        field("id").ofType(Long.class).in(sale).set(1l);
        operationResult = new OperationResult();
        operationResult.setMessage("someMessage");
        operationResult.setResultCode(1);
        Mockito.when(lasvcInformDebtContinentalBankPYServiceFactory.create(Mockito.eq(securityContext), 
        		Mockito.anyString())).thenReturn(osbService);

        Mockito.when(informDebtContinentalBankPYServiceRunner.parseDate(SOME_DATE_VALUE)).thenReturn(new Date());
        Mockito.when(systemParameterDAO.selectParameterValueByGroupAndNameAndCountryCode(Mockito.anyString(),
                Mockito.anyString(), Mockito.anyString())).thenReturn(SOME_DATE_VALUE);
    	Mockito.when(serviceRunnerDataService.registerData(Mockito.any(WsiServiceInstance.class), Mockito.anyString(), 
    			Mockito.anyString(), Mockito.anyBoolean(), Mockito.any(Map.class), Mockito.any(Map.class), 
    			Mockito.anyBoolean(), Mockito.any(Date.class), Mockito.any(Date.class))).thenReturn(new WsiServiceInstance());
    	Mockito.when(withholdingService.searchByGrower(grower)).thenReturn(null);
    }

    @Test
    public void testGetServiceURLProperty() throws Exception {
        String expectedServiceURLProperty = SERVICE_URL_PROPERTY;
        assertEquals(expectedServiceURLProperty, InformDebtContinentalBankPYServiceRunner.getServiceURLProperty());
    }

    @Test
    public void testServiceRunnerProperties() {
        assertFalse(informDebtContinentalBankPYServiceRunner.getIsRetry());
    }

    @Test
    public void testServiceNameIsNotNull_And_Correct() {
        assertNotNull(informDebtContinentalBankPYServiceRunner.getServiceName());
        assertEquals(ServiceRunner.ServiceEnum.DOCU_MON.getValue(), informDebtContinentalBankPYServiceRunner.getServiceName());
    }

    @Test
    public void testIsRetryIsFalse() {
        assertFalse(informDebtContinentalBankPYServiceRunner.getIsRetry());
    }

    @Test
    public void testOperationNameIsNotNull_And_Correct() {
        assertNotNull(informDebtContinentalBankPYServiceRunner.getOperationName());
        assertEquals(ServiceRunner.OperationEnum.INFOMR_DEBT_CONTINENTAL_BANK.getValue(), informDebtContinentalBankPYServiceRunner.getOperationName());
    }

    @Test
    public void testServiceRunnerGeneratesRequestData_WhenNoError() throws Exception {
        Mockito.when(osbService.informDebt(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(),
                Mockito.anyString(), Mockito.anyString(), Mockito.any(BigDecimal.class), Mockito.anyString(), Mockito.anyString(),
                Mockito.anyString(), Mockito.any(Date.class))).thenReturn(operationResult);

        informDebtContinentalBankPYServiceRunner.run(sale);
        Mockito.verify(osbService).informDebt(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(),
                Mockito.anyString(), Mockito.anyString(), Mockito.any(BigDecimal.class), Mockito.anyString(), Mockito.anyString(),
                Mockito.anyString(), Mockito.any(Date.class));

        assertNotNull(informDebtContinentalBankPYServiceRunner.getRequestDate());
        assertNotNull(informDebtContinentalBankPYServiceRunner.getResponseDate());
        assertFalse(informDebtContinentalBankPYServiceRunner.getRequest().isEmpty());
        assertFalse(informDebtContinentalBankPYServiceRunner.getResponse().isEmpty());
        assertTrue(informDebtContinentalBankPYServiceRunner.getStatus());
        assertNotNull(informDebtContinentalBankPYServiceRunner.getRequestDate());
        assertNotNull(informDebtContinentalBankPYServiceRunner.getResponseDate());
    }

    @Test
    public void testServiceRunnerGeneratesRequestData_WhenError() throws Exception {
        Mockito.when(osbService.informDebt(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(),
                Mockito.anyString(), Mockito.anyString(), Mockito.any(BigDecimal.class), Mockito.anyString(), Mockito.anyString(),
                Mockito.anyString(), Mockito.any(Date.class))).thenThrow(Exception.class);
//        informDebtContinentalBankPYServiceRunner.setSale(sale);

        try {
            informDebtContinentalBankPYServiceRunner.run(sale);
            fail("Service runner is stubbed to fail");
        } catch (Exception e) {
        }

        assertNotNull(informDebtContinentalBankPYServiceRunner.getRequestDate());
        assertNotNull(informDebtContinentalBankPYServiceRunner.getResponseDate());
        assertFalse(informDebtContinentalBankPYServiceRunner.getRequest().isEmpty());
        assertFalse(informDebtContinentalBankPYServiceRunner.getResponse().isEmpty());
        assertFalse(informDebtContinentalBankPYServiceRunner.getStatus());
        assertNotNull(informDebtContinentalBankPYServiceRunner.getRequestDate());
        assertNotNull(informDebtContinentalBankPYServiceRunner.getResponseDate());
    }

}
