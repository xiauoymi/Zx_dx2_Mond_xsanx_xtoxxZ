package com.monsanto.brazilvaluecapture.core.grower.model.dao.impl;

import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.io.Serializable;

import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.hibernate.classic.Session;
import org.junit.Before;
import org.junit.Test;

import com.monsanto.brazilvaluecapture.core.grower.model.bean.Grower;
import com.monsanto.brazilvaluecapture.seedsale.cutoffTons.model.dao.impl.CutoffTonsDAOImpl;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.CutOffTons;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.CutOffTonsGrower;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.CutOffTons.EntityTypeEnum;
import com.monsanto.brazilvaluecapture.seedsale.template.model.bean.SaleTemplate;

public class CutoffDAOImpl_UT {

	private CutoffTonsDAOImpl cutoffDAOImpl;
	private Session session;
	private Query hqlQuery;

	@Before
	public void setUp() {
		SessionFactory sessionFactory = mock(SessionFactory.class);
		this.session = mock(Session.class);
		when(sessionFactory.getCurrentSession()).thenReturn(this.session);
		this.hqlQuery = mock(Query.class);
		when(session.createQuery(anyString())).thenReturn(hqlQuery);
		this.cutoffDAOImpl = new CutoffTonsDAOImpl(sessionFactory);
	}
	
	@Test
	public void test_SaveExistentCutoff(){
		Grower g = new Grower();
		g.setId(1L);
		SaleTemplate st = new SaleTemplate();
		st.setId(1L);
		CutOffTonsGrower c = new CutOffTonsGrower();
		c.setGrower(g);
		c.setSaleTemplate(st);
		c.setEntityType(EntityTypeEnum.GROWER);
		c.setEntityId(g.getId());
		when(hqlQuery.uniqueResult()).thenReturn(c);
		doNothing().when(session).saveOrUpdate(c);
		this.cutoffDAOImpl.save(c);
		verify(this.session, times(1)).saveOrUpdate(c);
	}
	
	@Test
	public void test_SaveNewCutoff(){
		Grower g = new Grower();
		g.setId(1L);
		SaleTemplate st = new SaleTemplate();
		st.setId(1L);
		CutOffTons c = new CutOffTonsGrower();
		c.setSaleTemplate(st);
		c.setEntityType(EntityTypeEnum.GROWER);
		c.setEntityId(g.getId());
		when(hqlQuery.uniqueResult()).thenReturn(null);
		this.cutoffDAOImpl.save(c);
		verify(this.session, times(1)).save(c);
	}

}

