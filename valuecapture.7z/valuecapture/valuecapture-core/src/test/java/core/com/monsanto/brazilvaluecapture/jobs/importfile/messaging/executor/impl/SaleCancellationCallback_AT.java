package com.monsanto.brazilvaluecapture.jobs.importfile.messaging.executor.impl;

import com.monsanto.CountriesHolderInitializer;
import com.monsanto.brazilvaluecapture.core.account.model.bean.ManualCreditTransactionType;
import com.monsanto.brazilvaluecapture.core.account.service.impl.AccountService;
import com.monsanto.brazilvaluecapture.core.base.SystemTestFixture;
import com.monsanto.brazilvaluecapture.core.foundation.service.BusinessException;
import com.monsanto.brazilvaluecapture.core.foundation.service.IndustrySystemOperationException;
import com.monsanto.brazilvaluecapture.core.foundation.test.AbstractServiceIntegrationTests;
import com.monsanto.brazilvaluecapture.core.importfile.model.ImportFileType;
import com.monsanto.brazilvaluecapture.core.importfile.model.bean.CsvImportFile;
import com.monsanto.brazilvaluecapture.core.importfile.model.dao.CsvImportFileFilter;
import com.monsanto.brazilvaluecapture.core.importfile.service.CsvImportFileService;
import com.monsanto.brazilvaluecapture.core.io.ProcessorConfig;
import com.monsanto.brazilvaluecapture.core.io.ProcessorConfig.ProcessorConfigProperties;
import com.monsanto.brazilvaluecapture.core.regionalization.CountriesHolder;
import com.monsanto.brazilvaluecapture.core.user.AccessControlTestFixture;
import com.monsanto.brazilvaluecapture.core.user.model.bean.HierarchyLevel;
import com.monsanto.brazilvaluecapture.core.user.model.bean.UserContract;
import com.monsanto.brazilvaluecapture.core.user.model.bean.UserDecorator;
import com.monsanto.brazilvaluecapture.core.user.service.ManualCreditConstraintException;
import com.monsanto.brazilvaluecapture.jobs.importfile.messaging.bean.FileImportDefinition;
import com.monsanto.brazilvaluecapture.jobs.importfile.messaging.bean.FileImportInfo;
import com.monsanto.brazilvaluecapture.jobs.importfile.messaging.bean.FileImportOperation;
import com.monsanto.brazilvaluecapture.seedsale.billing.model.bean.Billing;
import com.monsanto.brazilvaluecapture.seedsale.billing.model.dao.BillingFilter;
import com.monsanto.brazilvaluecapture.seedsale.billing.service.BillingConstraintViolationException;
import com.monsanto.brazilvaluecapture.seedsale.sale.SaleTestFixture;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.Cancellation;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.ImportFileStatus;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.Sale;
import com.monsanto.brazilvaluecapture.seedsale.sale.service.BillingCancellationWarningException;
import com.monsanto.brazilvaluecapture.seedsale.sale.service.SaleBuilder;
import com.monsanto.brazilvaluecapture.seedsale.sale.service.SaleConstraintViolationException;
import com.monsanto.brazilvaluecapture.seedsale.sale.service.SaleService;
import com.monsanto.brazilvaluecapture.seedsale.sale.service.parser.cancellation.SaleCancelationCsvImportedFile;
import com.monsanto.brazilvaluecapture.seedsale.sale.service.parser.cancellation.SaleCancellationProcessor;
import junit.framework.Assert;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.ResourceBundle;

/**
 * @author dirceu
 */
public class SaleCancellationCallback_AT extends AbstractServiceIntegrationTests {
    private static final Logger LOG = LogManager.getLogger(SaleCancellationCallback_AT.class);

	@Autowired
	@Qualifier("saleCancellationProcessor")
	private SaleCancellationProcessor saleCancellationProcessor;
	
	@Autowired
	private CsvSaleCancellationFileCallback csvSaleCancellationFileCallback;
	
	@Autowired
	private SaleService saleService;
	
	@Autowired
    private CsvImportFileService csvImportFileService;
	
    @Autowired
    private AccountService accountService;

    @Autowired
    CountriesHolder countriesHolder;
    
	private Locale localeBR = new Locale("pt", "BR");
	private ResourceBundle resourceBundle = ResourceBundle.getBundle("bundle/bundle");

	private SaleBuilder builder;
	private SaleCancelationCsvImportedFile cancelationResult;
	private ProcessorConfig processorConfig;
	
	private UserDecorator decorator;

	@Test
	public void given_a_lexical_valid_csv_when_read_return_no_errors() throws IOException, BusinessException {
		InputStream resourceAsStream = getClass().getClassLoader().getResourceAsStream("csvSaleCancelation/lexicalValid-hypoteticalValues.csv");

		cancelationResult = saleCancellationProcessor.read(resourceAsStream, processorConfig);
		
		assertCancellationResultStatus(0, 0, 5, 0, 5, cancelationResult);
	}
	
	private void initProcessorConfig(UserDecorator context) {
        processorConfig.put(ProcessorConfigProperties.SELECTED_LOCALE, localeBR);
        processorConfig.put(ProcessorConfigProperties.LOGGED_USER, context);
        processorConfig.put(ProcessorConfigProperties.FILENAME, "sample.csv");
        processorConfig.put(ProcessorConfigProperties.BUNDLE, resourceBundle);
	}
	
	private UserDecorator initUser() {
		UserDecorator decorator = new UserDecorator(accessControlTestFixture.itsSuperUser, accessControlTestFixture.itsSuperUser);
		decorator.setContextCompany(systemTestFixture.monsantoBr);
        decorator.setContextCrop(systemTestFixture.soy);
        return decorator;
	}
	
	@Test
	public void given_valid_csvLine_when_import_should_save_and_status_shouldBe_awating_confirm() throws IOException, BusinessException {
		initProcessorConfig(decorator);
		
		InputStream resourceAsStream = getClass().getClassLoader().getResourceAsStream("csvSaleCancelation/invalid-cancellation-reason.csv");
		CsvImportFile csvImportFile = saleCancellationProcessor.readLines(resourceAsStream, processorConfig);

		csvSaleCancellationFileCallback.setBundle(resourceBundle, localeBR);
		csvSaleCancellationFileCallback.importFileCallback(new FileImportInfo(csvImportFile,
				decorator, FileImportDefinition.CSV_SALE_CANCELLATION,
				FileImportOperation.IMPORT, localeBR, "bundle"));
		
		List<CsvImportFile> lines = csvImportFileService.selectByFilter(CsvImportFileFilter.getInstance()
				.addImportFileStatus(ImportFileStatus.AWAITING_CONFIRM)
				.addImportFileType(ImportFileType.CSV_SALE_CANCELLATION));
		
		Assert.assertEquals(1, lines.size());
	}
	
	@Test
	public void given_csvLine_when_cancel_status_shouldBe_cancelled() throws IOException, BusinessException {
		initProcessorConfig(decorator);
		
		InputStream resourceAsStream = getClass().getClassLoader().getResourceAsStream("csvSaleCancelation/invalid-cancellation-reason.csv");
		CsvImportFile csvImportFile = saleCancellationProcessor.readLines(resourceAsStream, processorConfig);

		csvSaleCancellationFileCallback.setBundle(resourceBundle, localeBR);
		
		
		csvSaleCancellationFileCallback.importFileCallback(new FileImportInfo(csvImportFile,
				decorator, FileImportDefinition.CSV_SALE_CANCELLATION,
				FileImportOperation.IMPORT, localeBR, "bundle"));
		
		csvImportFile.setFileStatus(ImportFileStatus.AWAITING_CANCELLING);
		csvSaleCancellationFileCallback.importFileCallback(new FileImportInfo(csvImportFile,
				decorator, FileImportDefinition.CSV_SALE_CANCELLATION,
				FileImportOperation.CANCEL, localeBR, "bundle"));
		
		List<CsvImportFile> lines = csvImportFileService.selectByFilter(CsvImportFileFilter.getInstance()
				.addImportFileStatus(ImportFileStatus.CANCELLED)
				.addImportFileType(ImportFileType.CSV_SALE_CANCELLATION));
		
		Assert.assertEquals(1, lines.size());
	}
	
	@Test
	public void given_valid_csvFile_when_proceed_status_should_processed() throws IOException, BusinessException {
		initProcessorConfig(decorator);
		
		InputStream resourceAsStream = getClass().getClassLoader().getResourceAsStream("csvSaleCancelation/invalid-cancellation-reason.csv");
		CsvImportFile csvImportFile = saleCancellationProcessor.readLines(resourceAsStream, processorConfig);

		csvSaleCancellationFileCallback.setBundle(resourceBundle, localeBR);
		
		
		csvSaleCancellationFileCallback.importFileCallback(new FileImportInfo(csvImportFile,
				decorator, FileImportDefinition.CSV_SALE_CANCELLATION,
				FileImportOperation.IMPORT, localeBR, "bundle"));
		
		csvImportFile.setFileStatus(ImportFileStatus.AWAITING_PROCESSING);
		csvSaleCancellationFileCallback.importFileCallback(new FileImportInfo(csvImportFile,
				decorator, FileImportDefinition.CSV_SALE_CANCELLATION,
				FileImportOperation.PROCEED, localeBR, "bundle"));
		
		List<CsvImportFile> lines = csvImportFileService.selectByFilter(CsvImportFileFilter.getInstance()
				.addImportFileStatus(ImportFileStatus.PROCESSED)
				.addImportFileType(ImportFileType.CSV_SALE_CANCELLATION));
		
		Assert.assertEquals(1, lines.size());
	}
	
	@Test
	public void given_a_csv_with_a_cancellation_reason_no_visible_should_return_error() throws IOException, BusinessException {
		InputStream resourceAsStream = getClass().getClassLoader().getResourceAsStream("csvSaleCancelation/invalid-cancellation-reason.csv");
		createASale(SaleTestFixture.APRIL);
		
		Cancellation saleCancellation = new Cancellation();
		saleCancellation.setCode("NO_VISIBLE_CANCELLATION_TEST");
		saleCancellation.setDescription("no visible cancellation");
		saleCancellation.setIsVisible(false);
		saveAndFlush(saleCancellation);
		
		cancelationResult = saleCancellationProcessor.read(resourceAsStream, processorConfig);
		
		assertCancellationResultStatus(0, 0, 1, 0, 1, cancelationResult);
	}

	@Test
	public void given_a_lexical_invalid_csv_when_read_return_one_error_per_line() throws IOException, BusinessException {
		InputStream resourceAsStream = getClass().getClassLoader().getResourceAsStream("csvSaleCancelation/lexicalInvalid-hypoteticalValues.csv");

		cancelationResult = saleCancellationProcessor.read(resourceAsStream, processorConfig);
		
		assertCancellationResultStatus(0, 0, 2, 0, 2, cancelationResult);
	}
	
	@Test
	public void given_existent_entities_when_sale_does_not_exist_then_proccess_should_return_warning() throws IOException, BusinessException {
//		InputStream resourceAsStream = getClass().getClassLoader().getResourceAsStream("csvSaleCancelation/existent-sales.csv");
		InputStream resourceAsStream = new ByteArrayInputStream(createExistentSale(SaleTestFixture.DATE_NOW).getBytes());

		cancelationResult = saleCancellationProcessor.read(resourceAsStream, processorConfig);
		cancelationResult = saleCancellationProcessor.write(cancelationResult, processorConfig);
		
		assertCancellationResultStatus(0, 0, 1, 0, 1, cancelationResult);
	}

	@Test
	public void given_a_simple_sale_with_a_not_paid_billing_when_proccess_a_valid_csv_then_return_success() throws IOException, BusinessException {
//		InputStream resourceAsStream = getClass().getClassLoader().getResourceAsStream("csvSaleCancelation/existent-sales.csv");
		InputStream resourceAsStream = new ByteArrayInputStream(createExistentSale(SaleTestFixture.DATE_NOW).getBytes());
		createASale(SaleTestFixture.APRIL);

		cancelationResult = saleCancellationProcessor.read(resourceAsStream, processorConfig);
		cancelationResult = saleCancellationProcessor.write(cancelationResult, processorConfig);
		
		assertCancellationResultStatus(1, 1, 0, 0, 1, cancelationResult);
	}
	

	@Test
    public void given_a_simple_sale_with_mixed_case_then_return_success() throws IOException, BusinessException {
        InputStream resourceAsStream = getClass().getClassLoader().getResourceAsStream("csvSaleCancelation/mixed_case_sale.csv");
        createASale("12345", SaleTestFixture.APRIL);
        createASale("54321", SaleTestFixture.APRIL);

        cancelationResult = saleCancellationProcessor.read(resourceAsStream, processorConfig);
        cancelationResult = saleCancellationProcessor.write(cancelationResult, processorConfig);
        
        assertCancellationResultStatus(0, 0, 2, 0, 2, cancelationResult);
    }

	@Test
	public void given_a_simple_sale_with_a_paid_billing_when_proccess_a_valid_csv_then_return_warning() throws IOException, BusinessException {
//		InputStream resourceAsStream = getClass().getClassLoader().getResourceAsStream("csvSaleCancelation/existent-sales.csv");
		InputStream resourceAsStream = new ByteArrayInputStream(createExistentSale(SaleTestFixture.DATE_NOW).getBytes());
		Sale sale = createASale(SaleTestFixture.APRIL);
		paySale(sale);
		
		cancelationResult = saleCancellationProcessor.read(resourceAsStream, processorConfig);
		cancelationResult = saleCancellationProcessor.write(cancelationResult, processorConfig);
		
		assertCancellationResultStatus(0, 0, 1, 0, 1, cancelationResult);
	}

	@Test
	public void given_a_simple_sale_with_cancelled_billing_when_proccess_a_valid_csv_then_return_warning() throws IOException, BusinessException {
//		InputStream resourceAsStream = getClass().getClassLoader().getResourceAsStream("csvSaleCancelation/existent-sales.csv");
		InputStream resourceAsStream = new ByteArrayInputStream(createExistentSale(SaleTestFixture.DATE_NOW).getBytes());
		Sale sale = createASale(SaleTestFixture.APRIL);
		cancelSale(sale);
		
		cancelationResult = saleCancellationProcessor.read(resourceAsStream, processorConfig);
		cancelationResult = saleCancellationProcessor.write(cancelationResult, processorConfig);
		
		assertCancellationResultStatus(0, 0, 1, 0, 1, cancelationResult);
	}

	@Test
	public void given_two_sales_when_proccess_a_valid_csv_then_return_warning_and_cancel_sales_successful() throws IOException, BusinessException {
//		InputStream resourceAsStream = getClass().getClassLoader().getResourceAsStream("csvSaleCancelation/existent-sales.csv");
		InputStream resourceAsStream = new ByteArrayInputStream(createExistentSale(SaleTestFixture.DATE_NOW).getBytes());
		createASale("12345", SaleTestFixture.APRIL);
		createASale(SaleTestFixture.APRIL);
		
		cancelationResult = saleCancellationProcessor.read(resourceAsStream, processorConfig);
		cancelationResult = saleCancellationProcessor.write(cancelationResult, processorConfig);
		
		assertCancellationResultStatus(1, 1, 0, 0, 1, cancelationResult);
	}
	
	@Test
	public void should_not_be_able_to_cancel_a_licenseSeed_sale() throws IOException, BusinessException {
//		InputStream resourceAsStream = getClass().getClassLoader().getResourceAsStream("csvSaleCancelation/existent-sales.csv");
		InputStream resourceAsStream = new ByteArrayInputStream(createExistentSale(SaleTestFixture.DATE_NOW).getBytes());
		createALicenseSeed();
		
		cancelationResult = saleCancellationProcessor.read(resourceAsStream, processorConfig);
		cancelationResult = saleCancellationProcessor.write(cancelationResult, processorConfig);
		
		assertCancellationResultStatus(0, 0, 1, 0, 1, cancelationResult);
	}

	@Test
	public void should_not_be_able_to_cancel_a_sale_when_grower_informed_differs_of_grower_of_sale() throws IOException, BusinessException {
		InputStream resourceAsStream = getClass().getClassLoader().getResourceAsStream("csvSaleCancelation/sale-with-invoice-but-wrong-grower.csv");
		createASaleWithInvoiceNumber();
		
		cancelationResult = saleCancellationProcessor.read(resourceAsStream, processorConfig);
		cancelationResult = saleCancellationProcessor.write(cancelationResult, processorConfig);
		
		assertCancellationResultStatus(0, 0, 1, 0, 1, cancelationResult);
	}

	@Test
	public void given_cancellable_sales_when_csv_has_two_lines_representing_same_sale_then_processor_should_return_one_success_and_one_warning() throws IOException, BusinessException {
		InputStream resourceAsStream = new ByteArrayInputStream(createTwoRepeatedSales(SaleTestFixture.DATE_NOW).getBytes());
		createASaleWithInvoiceNumber();
		createASale(SaleTestFixture.APRIL);
		
		cancelationResult = saleCancellationProcessor.read(resourceAsStream, processorConfig);
	    assertCancellationResultStatus(1, 1, 3, 0, 4, cancelationResult);

		cancelationResult = saleCancellationProcessor.write(cancelationResult, processorConfig);
		assertCancellationResultStatus(1, 1, 3, 0, 4, cancelationResult);
	}

	private String createTwoRepeatedSales(Date date) {
		String csvSale = "Nota Fiscal Numero;Tipo de documento do Matriz;Matriz;Tipo de documento do Parceiro;Numero do documento do Parceiro;Tipo de documento do agricultor;Numero do documento do Agricultor;Data de Lancamento;UF de plantio;Empresa;Motivo\n"
				+ ";CNPJ;77727239523705;;77349148138782;CNPJ;77727239523705;;77349148138782;CNPJ;77208382069704;{date};MSS;mons4nto;SALE_CANCELLATION_TEST_FIXTURE\n"
				+ "12345;;;;;CNPJ;77727239523705;;77349148138782;CNPJ;77208382069704;{date};MSS;mons4nto;SALE_CANCELLATION_TEST_FIXTURE\n"
				+ "12345;;;;;CNPJ;77046101298780;;77374317071729;CNPJ;77208382069704;{date};MSS;mons4nto;SALE_CANCELLATION_TEST_FIXTURE\n"
				+ ";CNPJ;77727239523705;;77349148138782;CNPJ;77727239523705;;77349148138782;CNPJ;77208382069704;{date};MSS;mons4nto;SALE_CANCELLATION_TEST_FIXTURE";
		
		return changeCsvDate(date, csvSale);
	}

	private String createExistentSale(Date date) {
		String csvSale = "Nota Fiscal N�mero;Tipo de documento do Matriz;Matriz;Numero Inscrição Estadual Matriz;Codigo Sap Matriz;Tipo de documento do Parceiro;N�mero do documento do Parceiro;Numero Inscrição Estadual Parceiro;Codigo Sap Parceiro;Tipo de documento do agricultor;N�mero do documento do Agricultor;Data de Lan�amento;UF de plantio;Empresa;Motivo\n"
				+ ";CNPJ;77727239523705;;77349148138782;CNPJ;77727239523705;;77349148138782;CNPJ;77208382069704;{date};MSS;mons4nto;SALE_CANCELLATION_TEST_FIXTURE";
		return changeCsvDate(date, csvSale);
	}

	private String changeCsvDate(Date date, String csvSale) {
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		csvSale = csvSale.replace("{date}", sdf.format(date));
		return csvSale;
	}
	
	@Test
	public void given_a_cancellable_sale_of_monsanto_when_super_user_logged_at_monsantoEua_then_sale_should_not_be_cancellable() throws IOException, BusinessException {
//		InputStream resourceAsStream = getClass().getClassLoader().getResourceAsStream("csvSaleCancelation/existent-sales.csv");
		InputStream resourceAsStream = new ByteArrayInputStream(createExistentSale(SaleTestFixture.DATE_NOW).getBytes());
		ProcessorConfig processorConfigWithSuperUserAndMonsantoAsSelectedCompany = createProcessorConfigWithSuperUserAndMonsantoEuaAsSelectedCompany();
		createASale(SaleTestFixture.APRIL);
		
		cancelationResult = saleCancellationProcessor.read(resourceAsStream, processorConfigWithSuperUserAndMonsantoAsSelectedCompany );
		cancelationResult = saleCancellationProcessor.write(cancelationResult, processorConfigWithSuperUserAndMonsantoAsSelectedCompany);
		
		assertCancellationResultStatus(0, 0, 1, 0, 1, cancelationResult);
	}

	@Test
	public void given_a_cancellable_sale_of_monsanto_when_administrator_user_logged_at_monsantoEua_then_sale_should_not_be_cancellable() throws IOException, BusinessException {
//		InputStream resourceAsStream = getClass().getClassLoader().getResourceAsStream("csvSaleCancelation/existent-sales.csv");
		InputStream resourceAsStream = new ByteArrayInputStream(createExistentSale(SaleTestFixture.DATE_NOW).getBytes());
		ProcessorConfig processorConfigWithAdministratorUserAndMonsantoAsSelectedCompany = createProcessorConfigWithAdministratorUserAndMonsantoEuaAsSelectedCompany();
		createASale(SaleTestFixture.APRIL);
		
		cancelationResult = saleCancellationProcessor.read(resourceAsStream, processorConfigWithAdministratorUserAndMonsantoAsSelectedCompany );
		cancelationResult = saleCancellationProcessor.write(cancelationResult, processorConfigWithAdministratorUserAndMonsantoAsSelectedCompany);
		
		assertCancellationResultStatus(0, 0, 1, 0, 1, cancelationResult);
	}

	@Test
	public void given_a_cancellable_sale_of_monsanto_when_participant_user_logged_at_monsantoEua_then_sale_should_be_cancellable() throws IOException, BusinessException {
//		InputStream resourceAsStream = getClass().getClassLoader().getResourceAsStream("csvSaleCancelation/existent-sales.csv");
		InputStream resourceAsStream = new ByteArrayInputStream(createExistentSale(SaleTestFixture.DATE_NOW).getBytes());
//		ProcessorConfig processorConfigWithAdministratorUserAndMonsantoAsSelectedCompany = createProcessorConfigWithParticipantUserAndMonsantoEuaAsSelectedCompany();
		createASale(SaleTestFixture.APRIL);
		
		cancelationResult = saleCancellationProcessor.read(resourceAsStream, processorConfig );
		cancelationResult = saleCancellationProcessor.write(cancelationResult, processorConfig);
		
		assertCancellationResultStatus(1, 1, 0, 0, 1, cancelationResult);
	}

	@Test
	public void given_a_cancellable_sale_of_monsanto_and_participant_user_logged_at_monsantoEua_when_csv_have_one_inexistent_company_then_sale_should_be_cancellable() throws IOException, BusinessException {
//		InputStream resourceAsStream = getClass().getClassLoader().getResourceAsStream("csvSaleCancelation/two-lines-one-inexistent-company.csv");
		InputStream resourceAsStream = new ByteArrayInputStream(createTwoLinesOfInexistentCompany(SaleTestFixture.DATE_NOW).getBytes());
//		ProcessorConfig processorConfigWithAdministratorUserAndMonsantoAsSelectedCompany = createProcessorConfigWithParticipantUserAndMonsantoEuaAsSelectedCompany();
		createASale(SaleTestFixture.APRIL);

		cancelationResult = saleCancellationProcessor.read(resourceAsStream, processorConfig );
		assertCancellationResultStatus(1, 1, 1, 0, 2, cancelationResult);

		cancelationResult = saleCancellationProcessor.write(cancelationResult, processorConfig);
		assertCancellationResultStatus(1, 1, 1, 0, 2, cancelationResult);
	}
	
	private String createTwoLinesOfInexistentCompany(Date date) {
		String csvSale = "Nota Fiscal N�mero;Tipo de documento do Matriz;Matriz;Tipo de documento do Parceiro;N�mero do documento do Parceiro;Tipo de documento do agricultor;N�mero do documento do Agricultor;Data de Lan�amento;UF de plantio;Empresa;Motivo\n"
				+ ";CNPJ;77727239523705;;77349148138782;CNPJ;77727239523705;;77349148138782;CNPJ;77208382069704;{date};MSS;maosanta;SALE_CANCELLATION_TEST_FIXTURE\n"
				+ ";CNPJ;77727239523705;;77349148138782;CNPJ;77727239523705;;77349148138782;CNPJ;77208382069704;{date};MSS;mons4nto;SALE_CANCELLATION_TEST_FIXTURE";
		
		return changeCsvDate(date, csvSale);
	}
	
	@Test
	public void given_a_cancellable_sale_of_monsanto_and_not_enough_credit_for_reversal_should_give_error() throws IOException, BusinessException, ManualCreditConstraintException {
//		InputStream resourceAsStream = getClass().getClassLoader().getResourceAsStream("csvSaleCancelation/existent-sales.csv");
		InputStream resourceAsStream = new ByteArrayInputStream(createExistentSale(SaleTestFixture.DATE_NOW).getBytes());
//		ProcessorConfig processorConfigWithAdministratorUserAndMonsantoAsSelectedCompany = createProcessorConfigWithParticipantUserAndMonsantoEuaAsSelectedCompany();
		createASale(SaleTestFixture.APRIL);
		
		accountService.generateCreditManually(systemTestFixture.soyMons4nto,
				saleTestFixture.harvestSoyMons4nto2012.getOperationalYear(),
				systemTestFixture.intactaMons4nto, saleTestFixture.chicoBento,
				ManualCreditTransactionType.DEBIT, BigDecimal.valueOf(1L),
				"system test", "ANDREGC");

		cancelationResult = saleCancellationProcessor.read(resourceAsStream, processorConfig );
		assertCancellationResultStatus(1, 1, 0, 0, 1, cancelationResult);
		
		cancelationResult = saleCancellationProcessor.write(cancelationResult, processorConfig);
		assertCancellationResultStatus(0, 1, 0, 1, 1, cancelationResult);
		
	}
	
	@Before
	public void init() {
        CountriesHolderInitializer.initialize(countriesHolder);
		systemTestFixture = new SystemTestFixture(this);
		saleTestFixture = new SaleTestFixture(this, systemTestFixture);
		accessControlTestFixture = new AccessControlTestFixture(this, systemTestFixture);
		builder = new SaleBuilder(systemTestFixture.matoGrossoDoSul, saleTestFixture.plantabilitiesSelectorMons4nto);
		
		UserDecorator loggedSuperUser = accessControlTestFixture.superUser;
		loggedSuperUser.setContextCrop(systemTestFixture.soyMons4nto);
		loggedSuperUser.setContextCompany(systemTestFixture.mons4ntoBr);
		loggedSuperUser.addCompany(systemTestFixture.mons4ntoBr);
		
		decorator = initUser();

		processorConfig = new ProcessorConfig();
		processorConfig.put(ProcessorConfigProperties.SELECTED_LOCALE, localeBR);
		processorConfig.put(ProcessorConfigProperties.LOGGED_USER, loggedSuperUser);
		processorConfig.put(ProcessorConfigProperties.BUNDLE, resourceBundle);
		processorConfig.put(ProcessorConfigProperties.BUNDLE_NAME, "bundle");
		
		createChargeConsolidateTypes();
	}
	
	@After
	public void finalize() {
		if (cancelationResult != null) {
			String errors = cancelationResult.getErrors(resourceBundle);
			if ( !errors.isEmpty() ) {
				LOG.info("getErrors: ");
				LOG .info(errors);
			}
			
			String warnings = cancelationResult.getWarnings(resourceBundle);
			if ( !warnings.isEmpty() ) {
				LOG.info("getWarnings: ");
				LOG .info(warnings);
			}
		}
	}

//	private ProcessorConfig createProcessorConfigWithParticipantUserAndMonsantoEuaAsSelectedCompany() throws BusinessException {
//		
//		Contract contractForMonsantoSoy = new Contract("", saleTestFixture.matrixMons4nto, ParticipantTypeEnum.DISTRIBUTOR, systemTestFixture.soyMons4nto, systemTestFixture.mons4ntoBr);
//		Contract contractForMonsantoEuaSoy = new Contract("", saleTestFixture.matrixCargil, ParticipantTypeEnum.DISTRIBUTOR, systemTestFixture.soy, systemTestFixture.monsantoEua);
//		
//		saveAndFlush(contractForMonsantoSoy);
//		saveAndFlush(contractForMonsantoEuaSoy);
//		
//		HeadOffice officeMons4nto = new HeadOffice(saleTestFixture.matrixMons4nto, saleTestFixture.matrixMons4nto, ParticipantTypeEnum.DISTRIBUTOR, systemTestFixture.soyMons4nto, systemTestFixture.mons4ntoBr);
//		saveAndFlush(officeMons4nto);
//		
//		HeadOffice officeCargil = new HeadOffice(saleTestFixture.matrixCargil, saleTestFixture.matrixCargil, ParticipantTypeEnum.DISTRIBUTOR, systemTestFixture.soy, systemTestFixture.monsantoEua);
//		saveAndFlush(officeCargil); 
//		
//		List<HeadOffice> offices = new ArrayList<HeadOffice>();
//		offices.add(officeCargil);
//		offices.add(officeMons4nto);
//		
//		UserContract contractWithMonsanto = new UserContract(contractForMonsantoSoy, saleTestFixture.matrixMons4nto);
//		UserContract contractWithMonsantoEua = new UserContract(contractForMonsantoEuaSoy, saleTestFixture.matrixCargil);
//		
//		UserDecorator participantUser = accessControlIntent.participantUser;
//		participantUser.addUserContract(contractWithMonsanto);
//		participantUser.addUserContract(contractWithMonsantoEua);
//		participantUser.setContextCrop(systemTestFixture.soy);
//		participantUser.addCompany(systemTestFixture.monsantoEua);
//		participantUser.setHeadOffices(offices);
//
//		return createProcessorConfig(participantUser);
//	}

	private ProcessorConfig createProcessorConfigWithAdministratorUserAndMonsantoEuaAsSelectedCompany() {
		UserDecorator loggedAdministratorUser = accessControlTestFixture.userAdminOfMonsantoEua;
		loggedAdministratorUser.setContextCrop(systemTestFixture.soy);
		loggedAdministratorUser.setContextCompany(systemTestFixture.monsantoEua);
		
		return createProcessorConfig(loggedAdministratorUser);
	}

	private ProcessorConfig createProcessorConfigWithSuperUserAndMonsantoEuaAsSelectedCompany() {
		UserDecorator loggedSuperUser = accessControlTestFixture.superUser;
		loggedSuperUser.setContextCrop(systemTestFixture.soy);
		loggedSuperUser.setContextCompany(systemTestFixture.monsantoEua);

		return createProcessorConfig(loggedSuperUser);
	}

	private ProcessorConfig createProcessorConfig(UserDecorator user) {
		ProcessorConfig aProcessorConfig = new ProcessorConfig();
		aProcessorConfig.put(ProcessorConfigProperties.SELECTED_LOCALE, localeBR);
		aProcessorConfig.put(ProcessorConfigProperties.LOGGED_USER, user);
		
		return aProcessorConfig;
	}

	private void assertCancellationResultStatus(int expectedSuccessLinesCount, int expectedDetailLinesCount, int expectedWarningCount, int expectedErrorsCount, int totalLineNumber, SaleCancelationCsvImportedFile actualResult) {
		Assert.assertNotNull("Result of read file should not be null", actualResult);
		Assert.assertEquals("Number of success lines is wrong", expectedSuccessLinesCount, actualResult.countSuccess());
		Assert.assertEquals("Number of detail lines is wrong", expectedDetailLinesCount, actualResult.countDetailLines());
		Assert.assertEquals("Number of warnings is wrong", expectedWarningCount, actualResult.countWarnings());
		Assert.assertEquals("Number of erros is wrong", expectedErrorsCount, actualResult.countErrors());
		Assert.assertEquals("Total # of lines is wrong", totalLineNumber, actualResult.countTotalLines());
	}

	private void cancelSale(Sale sale) throws BillingCancellationWarningException, IndustrySystemOperationException {
		saleService.cancelBillingCompletely(sale.getId(), getParticipantUser().getAllCompaniesForContext(), saleTestFixture.saleCancellation, "JOHN");
	}

	private void paySale(Sale sale) throws BillingConstraintViolationException, IndustrySystemOperationException {
		Billing billing = getBilling(sale);
        try {
            saleService.payBilling(billing, SaleTestFixture.APRIL, new BigDecimal("936"), true);
        } catch (BusinessException e) {
            e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
        }
    }

	private Billing getBilling(Sale sale) {
		BillingFilter billingFilter = BillingFilter.getInstance().add(sale.getId());
		List<Billing> billings = saleService.getBillingBy(billingFilter);
		Assert.assertEquals("Should return only one billing", 1, billings.size());
		Billing billing = billings.get(0);
		return billing;
	}

	private Sale createALicenseSeed() throws SaleConstraintViolationException {
		builder.clear();
		builder.addSaleItem(saleTestFixture.productIntactaSoyMons4nto, 
				saleTestFixture.templateLicenseSeedMons4nto, 
				saleTestFixture.officeMons4nto, 
				2000L, 
				SaleTestFixture.TWO_POINT_FIVE_DOLLARS, 
				saleTestFixture.plantability45To54SoyMons4nto2012, 
				SaleTestFixture.APRIL);
		
		Sale sale = builder.setGrower(saleTestFixture.chicoBento).setCustomer(saleTestFixture.matrixMons4nto).buildLicenseSeed();
		sale.setCreationDate(SaleTestFixture.DATE_NOW);
        sale.setRegion(systemTestFixture.regionSaoPaulo2012);
		saleService.save(sale, getParticipantUser());

		return sale;
	}
	
	private Sale createASaleWithInvoiceNumber() throws SaleConstraintViolationException {
		return createASale("12345", SaleTestFixture.APRIL);
	}

	private Sale createASale(Date date) throws SaleConstraintViolationException {
		return createASale(null, date);
	}
	
	private Sale createASale(String invoiceNumber, Date date) throws SaleConstraintViolationException {
		builder.clear();
		builder.addSaleItem(saleTestFixture.productIntactaSoyMons4nto, 
				saleTestFixture.templateIntactaMons4nto, 
				saleTestFixture.officeMons4nto, 
				2000L, 
				SaleTestFixture.TWO_POINT_FIVE_DOLLARS, 
				saleTestFixture.plantability45To54SoyMons4nto2012, 
				date);
		
		Sale sale = builder.setGrower(saleTestFixture.chicoBento).setCustomer(saleTestFixture.matrixMons4nto).buildSale();
		sale.setCreationDate(SaleTestFixture.DATE_NOW);
        sale.setRegion(systemTestFixture.regionSaoPaulo2012);
		
		if ( invoiceNumber != null ) {
			sale.setInvoiceNumber(invoiceNumber);
		}
		saleService.save(sale, getParticipantUser());

		return sale;
	}
	
	private UserDecorator getParticipantUser() {
		
		UserDecorator participantUser = accessControlTestFixture.participantUser;
		UserContract contractWithMons4nto = new UserContract(participantUser.getCurrentUser(),saleTestFixture.contractMons4nto, saleTestFixture.matrixMons4nto, HierarchyLevel.HEAD_OFFICE);
		saveAndFlush(contractWithMons4nto);
					
		participantUser.addUserContract(contractWithMons4nto);
		participantUser.setContextCrop(systemTestFixture.soyMons4nto);
		participantUser.addCompany(systemTestFixture.mons4ntoBr);
		
		return participantUser;
	}
}
