package com.monsanto.brazilvaluecapture.core.grower.report;

import com.monsanto.brazilvaluecapture.core.account.model.bean.Account;
import com.monsanto.brazilvaluecapture.core.account.model.bean.ManualCreditTransactionType;
import com.monsanto.brazilvaluecapture.core.account.service.impl.AccountService;
import com.monsanto.brazilvaluecapture.core.base.SystemTestFixture;
import com.monsanto.brazilvaluecapture.core.foundation.service.BusinessException;
import com.monsanto.brazilvaluecapture.core.foundation.test.AbstractServiceIntegrationTests;
import com.monsanto.brazilvaluecapture.core.grower.model.dao.GrowerDAO;
import com.monsanto.brazilvaluecapture.core.grower.model.dao.impl.GrowerCreditReportFilter;
import com.monsanto.brazilvaluecapture.core.user.service.ManualCreditConstraintException;
import com.monsanto.brazilvaluecapture.seedsale.quota.report.EmptyReportException;
import com.monsanto.brazilvaluecapture.seedsale.sale.SaleTestFixture;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;


public class GrowerCreditReportAssembler_AT extends AbstractServiceIntegrationTests{

	private ResourceBundle resourceBundle = ResourceBundle.getBundle("bundle/bundle");


	@Autowired
	private GrowerDAO growerDAO;
	
	@Autowired
	private AccountService accountService;
	
	@Autowired
	private GrowerCreditReportBuilder growerCreditReportBuilder;
	
	public static final BigDecimal FIVE_CREDITS = new BigDecimal("5");
	
	@Before
	public void init() throws BusinessException, ManualCreditConstraintException {
		systemTestFixture = new SystemTestFixture(this);
		saleTestFixture = new SaleTestFixture(this, systemTestFixture);
		
		accountService.generateCreditManually(systemTestFixture.soy, saleTestFixture.harvestSoyMonsanto2012.getOperationalYear(), systemTestFixture.intacta, saleTestFixture.chicoBento,
				ManualCreditTransactionType.CREDIT, BigDecimal.TEN, "Test reason 3", "ANDREGC");

		
	}

	@Test
	public void given_one_grower_in_list_when_assemble_report_then_should_have_1_lines_23_cols() throws IOException, NoSuchMethodException, EmptyReportException, EmptyRequiredGrowerAgreementReportFieldException{

		ByteArrayOutputStream baos =  growerCreditReportBuilder.buildReportFor(resourceBundle, systemTestFixture.monsantoBr, systemTestFixture.soy , null, saleTestFixture.chicoBento, null, null, systemTestFixture.operationalYearOf2012, null, null, null, null); 
		
		assertSheetAndVerifyBlank(baos, 1, 7, false);
	}
	
	@Test
	public void test_grower_credit_reportfilter() {
		GrowerCreditReportFilter filter =  new GrowerCreditReportFilter(systemTestFixture.monsantoBr, systemTestFixture.soy , null, null, null, null, systemTestFixture.operationalYearOf2012,  null, null, null, null);
		List<Account> accounts = new ArrayList<Account>();
		List<GrowerReportDTO> reports=  growerDAO.getGrowerCreditReportDTOBy(filter);
		Assert.assertTrue(!reports.isEmpty());
		for (GrowerReportDTO growerReportDTO : reports) {
			if (growerReportDTO.getGrowerName().equals(saleTestFixture.chicoBento.getName())){
				Assert.assertNotNull("Must have one Account", growerReportDTO.getAccount());
				accounts.add(growerReportDTO.getAccount());
				Assert.assertEquals(saleTestFixture.chicoBento.getId(), growerReportDTO.getAccount().getOwnerCode());
			}
		}
		
		Assert.assertTrue(!accounts.isEmpty());		
	}

	@Test
	public void test_grower_credit_reportfilter_by_balance() {
		GrowerCreditReportFilter filter =  new GrowerCreditReportFilter(systemTestFixture.monsantoBr, systemTestFixture.soy , systemTestFixture.intacta, null, null, null, systemTestFixture.operationalYearOf2012,  null, null, null, null);
		List<GrowerReportDTO> reports=  growerDAO.getGrowerCreditReportDTOBy(filter);
		Assert.assertTrue(!reports.isEmpty());
		for (GrowerReportDTO growerReportDTO : reports) {
			Assert.assertNotNull(growerReportDTO.getAccount());				
			Assert.assertEquals("Balance must be 5", systemTestFixture.intacta, growerReportDTO.getAccount().getTechnology());
		}
	}
	
	@Test
	public void test_grower_credit_reportfilter_by_grower() {
		GrowerCreditReportFilter filter =  new GrowerCreditReportFilter(systemTestFixture.monsantoBr, systemTestFixture.soy , null, saleTestFixture.chicoBento, null, null, systemTestFixture.operationalYearOf2012, null, null, null, null);
		
		List<GrowerReportDTO> reports=  growerDAO.getGrowerCreditReportDTOBy(filter);
		
		Assert.assertTrue("Must return only one grower", reports.size()==1);
		Assert.assertEquals("Grower must be chico bento", saleTestFixture.chicoBento.getName(), reports.iterator().next().getGrowerName());
		
	}

	@Test
	public void test_grower_credit_reportfilter_by_state() {
		GrowerCreditReportFilter filter =  new GrowerCreditReportFilter(systemTestFixture.monsantoBr, systemTestFixture.soy , null, null, systemTestFixture.matoGrossoDoSul, null, systemTestFixture.operationalYearOf2012, null, null, null, null);
		
		List<GrowerReportDTO> reports = growerDAO.getGrowerCreditReportDTOBy(filter);
		
		Assert.assertTrue(!reports.isEmpty());
		for (GrowerReportDTO growerReportDTO : reports) {
			Assert.assertEquals("Must be Mato Grosso do Sul", systemTestFixture.matoGrossoDoSul.getCode(), growerReportDTO.getGrowerBillingState());
		}
		
	}
	
	@Test
	public void test_grower_credit_reportfilter_by_city() {
		GrowerCreditReportFilter filter =  new GrowerCreditReportFilter(systemTestFixture.monsantoBr, systemTestFixture.soy , null, null, null, systemTestFixture.vilaNova, systemTestFixture.operationalYearOf2012, null, null, null, null);
		
		List<GrowerReportDTO> reports=  growerDAO.getGrowerCreditReportDTOBy(filter);

		Assert.assertTrue(!reports.isEmpty());
		for (GrowerReportDTO growerReportDTO : reports) {
			Assert.assertEquals("Must be Vila Nova", systemTestFixture.vilaNova.getDescription(), growerReportDTO.getGrowerBillingCity());
		}
	}
	
	@Test
	public void test_grower_credit_reportfilter_by_unity_region_district_hierarchyType() {
		GrowerCreditReportFilter filter =  new GrowerCreditReportFilter(systemTestFixture.monsantoBr, systemTestFixture.soy , null, null, null, null, systemTestFixture.operationalYearOf2012, systemTestFixture.districtVilaNova, systemTestFixture.region, systemTestFixture.unity, systemTestFixture.commercialHierarchyMonsantoSoy.getCommercialHierType().getCommercialHierTypeDesc());
		
		List<GrowerReportDTO> reports=  growerDAO.getGrowerCreditReportDTOBy(filter);

		Assert.assertTrue(!reports.isEmpty());
		for (GrowerReportDTO growerReportDTO : reports) {
			Assert.assertEquals("Must be same District description", systemTestFixture.districtVilaNova.getDistrictSapDesc(), growerReportDTO.getGrowerDistrict());
			Assert.assertEquals("Must be same Region description", systemTestFixture.region.getRegionSapDesc(), growerReportDTO.getGrowerRegional());
			Assert.assertEquals("Must be same Unity description", systemTestFixture.unity.getUnitySapDesc(), growerReportDTO.getGrowerUnity());
		}
	}
	
	@Test
	public void test_grower_credit_reportfilter_by_unity_region_district() {
		GrowerCreditReportFilter filter =  new GrowerCreditReportFilter(systemTestFixture.monsantoBr, systemTestFixture.soy , null, null, null, null, systemTestFixture.operationalYearOf2012, systemTestFixture.districtVilaNova, null, null, null);
		
		List<GrowerReportDTO> reports=  growerDAO.getGrowerCreditReportDTOBy(filter);

		Assert.assertTrue(!reports.isEmpty());
		for (GrowerReportDTO growerReportDTO : reports) {
			Assert.assertEquals("Must be same District description", systemTestFixture.districtVilaNova.getDistrictSapDesc(), growerReportDTO.getGrowerDistrict());
			Assert.assertEquals("Must be same Region description", systemTestFixture.region.getRegionSapDesc(), growerReportDTO.getGrowerRegional());
			Assert.assertEquals("Must be same Unity description", systemTestFixture.unity.getUnitySapDesc(), growerReportDTO.getGrowerUnity());
		}
	}
	
	@Test
	public void test_grower_credit_reportfilter_by_unity_region() {
		GrowerCreditReportFilter filter =  new GrowerCreditReportFilter(systemTestFixture.monsantoBr, systemTestFixture.soy , null, null, null, systemTestFixture.vilaNova, systemTestFixture.operationalYearOf2012, null, systemTestFixture.region, systemTestFixture.unity, null);
		
		List<GrowerReportDTO> reports=  growerDAO.getGrowerCreditReportDTOBy(filter);

		Assert.assertTrue(!reports.isEmpty());
		for (GrowerReportDTO growerReportDTO : reports) {
			Assert.assertEquals("Must be same Region description", systemTestFixture.region.getRegionSapDesc(), growerReportDTO.getGrowerRegional());
			Assert.assertEquals("Must be same Unity description", systemTestFixture.unity.getUnitySapDesc(), growerReportDTO.getGrowerUnity());
		}
	}
	
	@Test
	public void test_grower_credit_reportfilter_by_unity() {
		GrowerCreditReportFilter filter =  new GrowerCreditReportFilter(systemTestFixture.monsantoBr, systemTestFixture.soy , null, null, null, null, systemTestFixture.operationalYearOf2012, null, null, systemTestFixture.unity, systemTestFixture.commercialHierarchyMonsantoSoy.getCommercialHierType().getCommercialHierTypeDesc());
		
		List<GrowerReportDTO> reports=  growerDAO.getGrowerCreditReportDTOBy(filter);

		Assert.assertTrue(!reports.isEmpty());
		for (GrowerReportDTO growerReportDTO : reports) {
			Assert.assertEquals("Must be same Unity description", systemTestFixture.unity.getUnitySapDesc(), growerReportDTO.getGrowerUnity());
		}
	}
	private void assertSheetAndVerifyBlank(ByteArrayOutputStream baos, int rowNum, int cellPosition, boolean isBlank) throws IOException {
		ByteArrayInputStream inputStream = new ByteArrayInputStream(baos.toByteArray());
		HSSFWorkbook hssfWorkbook = new HSSFWorkbook(inputStream);
		Assert.assertNotNull("workbook shouldn't be null", hssfWorkbook);
		HSSFSheet sheet = hssfWorkbook.getSheetAt(0);
		Assert.assertNotNull("Sheet shouldn't be null", sheet);
		HSSFRow row = sheet.getRow(rowNum);
		Assert.assertNotNull("Row shouldn't be null", row);
		HSSFCell cell = row.getCell(cellPosition);
		Assert.assertNotNull("Cell shouldn't be null", cell);
		isBlankString(isBlank, cell);
	}

	private void isBlankString(boolean isBlank, HSSFCell cell) {
		if(cell.getCellType() == Cell.CELL_TYPE_STRING) {
			if(isBlank){
				Assert.assertTrue("This cell is blank", "".equals(cell.getStringCellValue().trim()));
			}else {
				Assert.assertTrue("This cell is not blank", !"".equals(cell.getStringCellValue().trim()));
			}			
		}

	}
	
}
