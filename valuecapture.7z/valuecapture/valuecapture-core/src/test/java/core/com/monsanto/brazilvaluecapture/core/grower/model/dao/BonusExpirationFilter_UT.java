package com.monsanto.brazilvaluecapture.core.grower.model.dao;

import com.monsanto.brazilvaluecapture.core.base.model.bean.OperationalYear;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Technology;
import com.monsanto.brazilvaluecapture.core.grower.model.bean.BonusExpiration;
import junit.framework.Assert;
import org.hibernate.Criteria;
import org.hibernate.SessionFactory;
import org.hibernate.classic.Session;
import org.hibernate.engine.SessionFactoryImplementor;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.orm.hibernate3.HibernateTemplate;

import static org.mockito.Matchers.anyObject;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
import static org.mockito.Mockito.withSettings;

/**
 * User: GMNAVE
 * Date: 4/30/14
 * Time: 12:59 PM
 */
public class BonusExpirationFilter_UT{

    BonusExpirationFilter bonusExpirationFilter;

    SessionFactory sf;
    SessionFactoryImplementor sfi;
    @Mock
    Session session;
    @Mock
    HibernateTemplate t;
    @Mock
    Criteria criteria;

    @Before
    public void setUp() throws Exception {
        MockitoAnnotations.initMocks(this);
        bonusExpirationFilter = BonusExpirationFilter.getInstance();

        sf = mock(SessionFactory.class, withSettings().extraInterfaces(SessionFactoryImplementor.class));
        sfi = (SessionFactoryImplementor) sf;
        when(sf.openSession()).thenReturn(session);
    }

    @Test
    public void testCreateCriteria_WhenOnlyTechnologyIsGiven(){

        //@ Given
        Technology technology = new Technology();

        //@ When
        bonusExpirationFilter.addTechnology(technology);

        //@ Should
        Assert.assertEquals(bonusExpirationFilter.countCriterias(), 1);
    }

    @Test
    public void testCreateCriteria_WhenOnlyOperationalYearIsGiven(){

        //@ Given
        OperationalYear operationalYear = new OperationalYear();

        //@ When
        bonusExpirationFilter.addOperationalYear(operationalYear);

        //@ Should
        Assert.assertEquals(bonusExpirationFilter.countCriterias(), 1);
    }

    @Test
    public void testCreateCriteria_WhenCreateCriteria(){

        //@Given
        when(session.createCriteria(BonusExpiration.class, "bonusExpiration")).thenReturn(criteria);

        //@ When
        Criteria expected = bonusExpirationFilter.createCriteria(session);

        //@ Should
        Assert.assertEquals(criteria, expected);
    }

}
