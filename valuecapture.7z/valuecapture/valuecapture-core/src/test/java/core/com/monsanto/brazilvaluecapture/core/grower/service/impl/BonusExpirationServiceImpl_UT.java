package com.monsanto.brazilvaluecapture.core.grower.service.impl;

import com.google.common.collect.Lists;
import com.monsanto.brazilvaluecapture.core.base.model.bean.OperationalYear;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Technology;
import com.monsanto.brazilvaluecapture.core.grower.model.bean.BonusConsumption;
import com.monsanto.brazilvaluecapture.core.grower.model.bean.BonusExpiration;
import com.monsanto.brazilvaluecapture.core.grower.model.bean.BonusExpirationSaleTemplate;
import com.monsanto.brazilvaluecapture.core.grower.model.bean.Grower;
import com.monsanto.brazilvaluecapture.core.grower.model.dao.BonusAccountDAO;
import com.monsanto.brazilvaluecapture.core.grower.model.dao.BonusExpirationDAO;
import com.monsanto.brazilvaluecapture.core.grower.model.dao.BonusExpirationFilter;
import com.monsanto.brazilvaluecapture.core.grower.model.dao.BonusExpirationSaleTemplateDAO;
import com.monsanto.brazilvaluecapture.seedsale.template.model.bean.SaleTemplate;
import org.joda.time.DateTime;
import org.junit.Before;
import org.junit.Test;
import org.mockito.*;

import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.*;

public class BonusExpirationServiceImpl_UT {

    @Mock
    private BonusExpirationDAO bonusExpirationDAO;

    @Mock
    private BonusExpirationSaleTemplateDAO bonusExpirationSaleTemplateDAO;

    @Mock
    private BonusAccountDAO bonusAccountDAO;

    @InjectMocks
    private BonusExpirationServiceImpl bonusExpirationService;


    @Before
    public void setUp() throws Exception {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void testSelectBonusExpirationByFilter() throws Exception {
        //@ When
        bonusExpirationService.selectBonusExpirationByFilter((BonusExpirationFilter) Matchers.anyObject());

        //@ Should
        verify(bonusExpirationDAO).findByFilter((BonusExpirationFilter) Matchers.anyObject());
    }

    @Test
    public void testCreateOrUpdate() throws Exception {
        //@ When
        bonusExpirationService.createOrUpdate((BonusExpiration) Matchers.anyObject());

        //@ Should
        verify(bonusExpirationDAO).createOrUpdate((BonusExpiration) Matchers.anyObject());
    }

    @Test
    public void testFindBonusExpirationCallsfindBonusExpirationBy_whenServiceIsInvokedWithValidBonusConsumption() throws Exception {
        BonusConsumption bonusConsumption = new BonusConsumption();
        bonusConsumption.setConsumptionDate(new DateTime(2014, 5, 10, 0, 0).toDate());
        Grower grower = new Grower();
        grower.setName("DUMMY_GROWER");
        bonusConsumption.setGrower(grower);
        Technology technology = new Technology();
        technology.setDescription("DUMMY_TECHNOLOGY");
        bonusConsumption.setTechnology(technology);
        OperationalYear operationalYear = new OperationalYear();
        bonusConsumption.setOperationalYear(operationalYear);

        bonusExpirationService.findBonusExpiration(bonusConsumption);

        verify(bonusExpirationDAO).findBonusExpirationBy(bonusConsumption.getOperationalYear(), bonusConsumption.getTechnology(), bonusConsumption.getAgreementTemplateType());
    }

    @Test
    public void testFindBonusExpirationReturnsBonusExpiration_whenServiceIsInvokedWithValidBonusConsumption() throws Exception {
        BonusConsumption bonusConsumption = new BonusConsumption();
        Grower grower = new Grower();
        grower.setName("DUMMY_GROWER");
        bonusConsumption.setGrower(grower);
        Technology technology = new Technology();
        technology.setDescription("DUMMY_TECHNOLOGY");
        bonusConsumption.setTechnology(technology);
        OperationalYear operationalYear = new OperationalYear();
        bonusConsumption.setOperationalYear(operationalYear);
        BonusExpiration bonusExpiration = new BonusExpiration();
        when(bonusExpirationDAO.findBonusExpirationBy(bonusConsumption.getOperationalYear(), bonusConsumption.getTechnology(), bonusConsumption.getAgreementTemplateType())).thenReturn(bonusExpiration);

        BonusExpiration result = bonusExpirationService.findBonusExpiration(bonusConsumption);

        assertNotNull(result);
        assertEquals(bonusExpiration, result);
    }

    @Test
    public void testFindBonusExpirations() throws Exception {
        BonusExpirationSaleTemplate bonusExpirationSaleTemplate1 = new BonusExpirationSaleTemplate();
        BonusExpiration bonusExpiration1 = new BonusExpiration();
        bonusExpirationSaleTemplate1.setBonusExpiration(bonusExpiration1);
        BonusExpirationSaleTemplate bonusExpirationSaleTemplate2 = new BonusExpirationSaleTemplate();
        BonusExpiration bonusExpiration2 = new BonusExpiration();
        bonusExpirationSaleTemplate2.setBonusExpiration(bonusExpiration2);
        SaleTemplate saleTemplate = new SaleTemplate();
        when(bonusExpirationSaleTemplateDAO.findBy(saleTemplate))
                .thenReturn(Lists.newArrayList(bonusExpirationSaleTemplate1, bonusExpirationSaleTemplate2));

        List<BonusExpiration> bonusExpirations = bonusExpirationService.findBonusExpirations(saleTemplate);

        assertEquals(Lists.newArrayList(bonusExpiration1, bonusExpiration2), bonusExpirations);
    }

    @Test
    public void testUpdateMappings_WhenNoMappingsToUpdate() throws Exception {
        BonusExpiration bonusExpiration = new BonusExpiration();
        bonusExpiration.setId(-1L);
        SaleTemplate saleTemplate = new SaleTemplate();
        BonusExpirationSaleTemplate bonusExpirationSaleTemplate =
                new BonusExpirationSaleTemplate(saleTemplate, bonusExpiration);
        when(bonusExpirationSaleTemplateDAO.findBy(saleTemplate))
                .thenReturn(Lists.newArrayList(bonusExpirationSaleTemplate));

        bonusExpirationService.updateMappings(saleTemplate, Lists.newArrayList(bonusExpiration));

        verify(bonusExpirationSaleTemplateDAO).findBy(saleTemplate);
        verifyNoMoreInteractions(bonusExpirationSaleTemplateDAO);
    }

    @Test
    public void testUpdateMappings_WhenNewMappingToAdd() throws Exception {
        BonusExpiration bonusExpiration1 = new BonusExpiration();
        bonusExpiration1.setId(-1L);
        BonusExpiration bonusExpiration2 = new BonusExpiration();
        bonusExpiration2.setId(-2L);
        SaleTemplate saleTemplate = new SaleTemplate();
        BonusExpirationSaleTemplate bonusExpirationSaleTemplate =
                new BonusExpirationSaleTemplate(saleTemplate, bonusExpiration1);
        when(bonusExpirationSaleTemplateDAO.findBy(saleTemplate))
                .thenReturn(Lists.newArrayList(bonusExpirationSaleTemplate));

        bonusExpirationService.updateMappings(saleTemplate, Lists.newArrayList(bonusExpiration1, bonusExpiration2));

        ArgumentCaptor<BonusExpirationSaleTemplate> bonusExpirationSaleTemplateArgumentCaptor =
                ArgumentCaptor.forClass(BonusExpirationSaleTemplate.class);
        verify(bonusExpirationSaleTemplateDAO).createOrUpdate(bonusExpirationSaleTemplateArgumentCaptor.capture());
        BonusExpirationSaleTemplate savedBonusExpirationSaleTemplate =
                bonusExpirationSaleTemplateArgumentCaptor.getValue();
        assertEquals(bonusExpiration2, savedBonusExpirationSaleTemplate.getBonusExpiration());
        assertEquals(saleTemplate, savedBonusExpirationSaleTemplate.getSaleTemplate());
        verify(bonusExpirationSaleTemplateDAO).findBy(saleTemplate);
        verifyNoMoreInteractions(bonusExpirationSaleTemplateDAO);
    }

    @Test
    public void testUpdateMappings_WhenUnwantedMappingToRemove() throws Exception {
        BonusExpiration bonusExpiration1 = new BonusExpiration();
        bonusExpiration1.setId(-1L);
        BonusExpiration bonusExpiration2 = new BonusExpiration();
        bonusExpiration2.setId(-2L);
        SaleTemplate saleTemplate = new SaleTemplate();
        BonusExpirationSaleTemplate bonusExpirationSaleTemplate1 =
                new BonusExpirationSaleTemplate(saleTemplate, bonusExpiration1);
        BonusExpirationSaleTemplate bonusExpirationSaleTemplate2 =
                new BonusExpirationSaleTemplate(saleTemplate, bonusExpiration2);
        when(bonusExpirationSaleTemplateDAO.findBy(saleTemplate))
                .thenReturn(Lists.newArrayList(bonusExpirationSaleTemplate1, bonusExpirationSaleTemplate2));

        bonusExpirationService.updateMappings(saleTemplate, Lists.newArrayList(bonusExpiration1));

        ArgumentCaptor<BonusExpirationSaleTemplate> bonusExpirationSaleTemplateArgumentCaptor =
                ArgumentCaptor.forClass(BonusExpirationSaleTemplate.class);
        verify(bonusExpirationSaleTemplateDAO).delete(bonusExpirationSaleTemplateArgumentCaptor.capture());
        BonusExpirationSaleTemplate savedBonusExpirationSaleTemplate =
                bonusExpirationSaleTemplateArgumentCaptor.getValue();
        assertEquals(bonusExpiration2, savedBonusExpirationSaleTemplate.getBonusExpiration());
        assertEquals(saleTemplate, savedBonusExpirationSaleTemplate.getSaleTemplate());
        verify(bonusExpirationSaleTemplateDAO).findBy(saleTemplate);
        verifyNoMoreInteractions(bonusExpirationSaleTemplateDAO);
    }
}
