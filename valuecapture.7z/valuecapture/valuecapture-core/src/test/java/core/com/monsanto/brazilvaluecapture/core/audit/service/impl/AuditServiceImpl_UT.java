package com.monsanto.brazilvaluecapture.core.audit.service.impl;

import com.monsanto.brazilvaluecapture.core.audit.model.bean.report.UserInformationReportDTO;
import com.monsanto.brazilvaluecapture.core.audit.model.bean.report.UserLoginAttemptReportDTO;
import com.monsanto.brazilvaluecapture.core.audit.model.bean.report.UserProfileReportDTO;
import com.monsanto.brazilvaluecapture.core.audit.model.dao.AuditDAO;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.ParticipantTypeEnum;
import com.monsanto.brazilvaluecapture.core.foundation.model.bean.StatusEnum;
import com.monsanto.brazilvaluecapture.core.foundation.service.ReportBasicUsersDTO;
import com.monsanto.brazilvaluecapture.core.foundation.service.UsersContractReportsDTO;
import com.monsanto.brazilvaluecapture.core.regionalization.VCCountry;
import com.monsanto.brazilvaluecapture.core.user.model.bean.ItsUser;
import com.monsanto.brazilvaluecapture.core.user.model.dao.ProfileDAO;
import org.junit.Before;
import org.junit.Test;

import java.util.*;

import static org.fest.assertions.Assertions.assertThat;
import static org.fest.reflect.core.Reflection.field;
import static org.mockito.Mockito.*;

/**
 * Created with IntelliJ IDEA.
 * User: AFREI
 * Date: 28/01/14
 * Time: 11:22
 */
public class AuditServiceImpl_UT {
    private AuditServiceImpl auditService;
    private AuditDAO auditDAO;
    private ProfileDAO profileDAO;

    @Before
    public void setUp() {
        this.auditService = new AuditServiceImpl();
        this.auditDAO = mock(AuditDAO.class);
        this.profileDAO = mock(ProfileDAO.class);
        field("auditDAO").ofType(AuditDAO.class).in(this.auditService).set(this.auditDAO);
        field("profileDAO").ofType(ProfileDAO.class).in(this.auditService).set(this.profileDAO);
    }

    @Test
    public void testGetProfileByCallsAuditDaoGetProfileBy() {
        VCCountry country = VCCountry.ARGENTINA;
        String userName = "userName";
        String loginUser = "loginUser";
        String documentNumber = "123456789";
        String profile = "profile";
        StatusEnum status = StatusEnum.ACTIVE;
        boolean limitResults = false;

        auditService.getProfileBy(country,userName,loginUser,documentNumber,profile,status,limitResults);

        verify(this.auditDAO, times(1)).getProfileBy(country,userName,loginUser,documentNumber,profile,status,limitResults);

    }

    @Test
    public void testGetProfileByReturnsDaoResult_WhenGetProfileBy() {
        // @Given
        VCCountry country = VCCountry.ARGENTINA;
        String userName = "userName";
        String loginUser = "loginUser";
        String documentNumber = "123456789";
        String profile = "profile";
        StatusEnum status = StatusEnum.ACTIVE;
        boolean limitResults = false;
        when(auditDAO.getProfileBy(country,userName,loginUser,documentNumber,profile,status,limitResults)).thenReturn(new ArrayList<UserProfileReportDTO>());

        // @When
        List<UserProfileReportDTO> userProfileReportDTOList = auditService.getProfileBy(country,userName,loginUser,documentNumber,profile,status,limitResults);

        // @Then
        assertThat(userProfileReportDTOList).isSameAs(auditDAO.getProfileBy(country, userName, loginUser, documentNumber, profile, status, limitResults));
    }

    @Test
    public void testGetUserInformationByCallsAuditDaoGetUserInformationBy() {
        VCCountry country = VCCountry.ARGENTINA;
        String loginUser = "loginUser";
        boolean limitResults = false;

        auditService.getUserInformationBy(country, loginUser, limitResults);

        verify(this.auditDAO, times(1)).getUserInformationBy(country, loginUser, limitResults);

    }

    @Test
    public void testGetUserInformationByReturnsDaoResult_WhenGetUserInformationBy() {
        // @Given
        VCCountry country = VCCountry.ARGENTINA;
        String loginUser = "loginUser";
        boolean limitResults = false;
        when(auditDAO.getUserInformationBy(country, loginUser, limitResults)).thenReturn(new ArrayList<UserInformationReportDTO>());

        // @When
        List<UserInformationReportDTO> userInformationReportDTOList = auditService.getUserInformationBy(country, loginUser, limitResults);

        // @Then
        assertThat(userInformationReportDTOList).isSameAs(auditDAO.getUserInformationBy(country, loginUser, limitResults));
    }

    @Test
    public void testGetUserLoginAttemptsByCallsAuditDaoGetUserLoginAttemptsBy() {
        VCCountry country = VCCountry.ARGENTINA;
        String userName = "userName";
        String loginUser = "loginUser";
        String documentNumber = "123456789";
        String profile = "profile";
        StatusEnum status = StatusEnum.ACTIVE;
        boolean limitResults = false;

        auditService.getProfileBy(country,userName,loginUser,documentNumber,profile,status,limitResults);

        verify(this.auditDAO, times(1)).getProfileBy(country,userName,loginUser,documentNumber,profile,status,limitResults);

    }

    @Test
    public void testGetUserLoginAttemptsByReturnsDaoResult_WhenUserLoginAttemptsBy() {
        // @Given
        VCCountry country = VCCountry.ARGENTINA;
        String loginUser = "loginUser";
        Date dateFrom = new Date();
        Date dateTo = new Date();
        boolean limitResults = false;
        when(auditDAO.getUserLoginAttemptsBy(country, loginUser, dateFrom, dateTo, limitResults)).thenReturn(new ArrayList<UserLoginAttemptReportDTO>());

        // @When
        List<UserLoginAttemptReportDTO> userProfileReportDTOList = auditService.getUserLoginAttemptsBy(country, loginUser, dateFrom, dateTo, limitResults);

        // @Then
        assertThat(userProfileReportDTOList).isSameAs(auditDAO.getUserLoginAttemptsBy(country, loginUser, dateFrom, dateTo, limitResults));
    }

    @Test
    public void testGetProfileDescriptionsByCallsProfileDaoGetAllDescriptionsBy() {
        String countryCode = VCCountry.ARGENTINA.getLocale().getCountry();

        auditService.getProfileDescriptionsBy(countryCode);

        verify(this.profileDAO, times(1)).getAllDescriptionsBy(countryCode);

    }

    @Test
    public void testGetProfileDescriptionsByReturnsDaoResult_WhenGetProfileDescriptionsBy() {
        // @Given
        String countryCode = VCCountry.ARGENTINA.getLocale().getCountry();
        when(profileDAO.getAllDescriptionsBy(countryCode)).thenReturn(new TreeSet<String>());

        // @When
        Set<String> profileDescriptionsSet = auditService.getProfileDescriptionsBy(countryCode);

        // @Then
        assertThat(profileDescriptionsSet).isSameAs(profileDAO.getAllDescriptionsBy(countryCode));
    }

    @Test
    public  void testGetBasicUserByCallsAuditDaoTestGetBasicUser(){
        String fullName = "ADAMA_S";
        String loginUser= "ADAMA_S";
        String document= "1111111111";
        VCCountry country = VCCountry.ARGENTINA;
        boolean limitResults = true;
        auditService.getBasicUser(country, fullName,loginUser,document,ItsUser.UserTypeEnum.SUPER.name(),StatusEnum.ACTIVE.name(), limitResults);
        verify(this.auditDAO, times(1)).getBasicUser(country, fullName, loginUser, document, ItsUser.UserTypeEnum.SUPER.name(), StatusEnum.ACTIVE.name(), limitResults);
    }


    @Test
    public  void testGetBasicUserReturnsDaoResult_WhenGetBasicUser(){


        String fullName = "ADAMA_S";
        String loginUser= "ADAMA_S";
        String document= "1111111111";
        VCCountry country = VCCountry.ARGENTINA;
        boolean limitResults = true;

        when(auditDAO.getBasicUser(country, fullName,loginUser,document,ItsUser.UserTypeEnum.SUPER.name(),StatusEnum.ACTIVE.name(), limitResults)).thenReturn(new ArrayList<ReportBasicUsersDTO>());
        List<ReportBasicUsersDTO> reportBasicUsersDTOList = auditService.getBasicUser(country, fullName,loginUser,document,ItsUser.UserTypeEnum.SUPER.name(),StatusEnum.ACTIVE.name(), limitResults);
        assertThat(reportBasicUsersDTOList).isSameAs(auditDAO.getBasicUser(country, fullName,loginUser,document,ItsUser.UserTypeEnum.SUPER.name(),StatusEnum.ACTIVE.name(), limitResults));

    }


    @Test
    public  void testGetUsersContractReportsByCallsAuditDaoTestGetUsersContractReports(){
        String fullName = "ADAMA_S";
        auditService.getUsersContractReports(fullName, ParticipantTypeEnum.DISTRIBUTOR.name(), true);
        verify(this.auditDAO, times(1)).getUsersContractReports(fullName, ParticipantTypeEnum.DISTRIBUTOR.name(), true);
    }


    @Test
    public  void testGetUsersContractReportsReturnsDaoResult_WhenGetUsersContractReports(){
        String fullName = "ADAMA_S";
        when(auditDAO.getUsersContractReports(fullName,ParticipantTypeEnum.DISTRIBUTOR.name(),true )).thenReturn(new ArrayList<UsersContractReportsDTO>());
        List<UsersContractReportsDTO> usersContractReportsDTOs = auditService.getUsersContractReports(fullName,ParticipantTypeEnum.DISTRIBUTOR.name(), true);
        assertThat(usersContractReportsDTOs).isSameAs(auditDAO.getUsersContractReports(fullName,ParticipantTypeEnum.DISTRIBUTOR.name(), true));

    }


}
