package com.monsanto.brazilvaluecapture.core.grower.service.impl;

import com.monsanto.brazilvaluecapture.core.foundation.service.EntityNotFoundException;
import com.monsanto.brazilvaluecapture.core.grower.model.bean.Grower;
import com.monsanto.brazilvaluecapture.core.grower.model.bean.GrowerDocsApproval;
import com.monsanto.brazilvaluecapture.core.grower.model.bean.GrowerDocsApprovalLog;
import com.monsanto.brazilvaluecapture.core.grower.model.dao.GrowerDocsApprovalDAO;
import com.monsanto.brazilvaluecapture.core.grower.model.dao.GrowerDocsApprovalLogDAO;
import com.monsanto.brazilvaluecapture.core.grower.service.GrowerDocsApprovalFlowException;
import com.monsanto.brazilvaluecapture.core.grower.service.GrowerDocsApprovalMailService;
import com.monsanto.brazilvaluecapture.core.user.model.bean.UserContext;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import static org.fest.assertions.Fail.fail;
import static org.fest.reflect.core.Reflection.field;
import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.*;

/**
 * Created by AFREI on 04/04/14.
 */
public class GrowerDocsApprovalService_UT {

    private static final String LABEL_GROWER_DOCS_APPROVAL_ERROR_UPDATE_TO_APPROVED = "label.grower.docs.approval.error.update.to.approved";
    private static final String LABEL_GROWER_DOCS_APPROVAL_ERROR_UPDATE_TO_OBSERVED = "label.grower.docs.approval.error.update.to.observed";
    private static final String LABEL_GROWER_DOCS_APPROVAL_ERROR_UPDATE_TO_PENDING_APPROVAL = "label.grower.docs.approval.error.update.to.pending_approval";
    private static final String LABEL_GROWER_DOCS_APPROVAL_ERROR_UPDATE_TO_SENT_TO_APPROVAL = "label.grower.docs.approval.error.update.to.sent_to_approval";

    @Mock
    private GrowerDocsApprovalDAO growerDocsApprovalDAO;
    @Mock
    private GrowerDocsApprovalLogDAO growerDocsApprovalLogDAO;
    @Mock
    private GrowerDocsApprovalMailService growerDocsApprovalMailService;

    private GrowerDocsApprovalServiceImpl growerDocsApprovalService;

    @Before
    public void setUp() throws Exception {
        MockitoAnnotations.initMocks(this);
        growerDocsApprovalService = new GrowerDocsApprovalServiceImpl();
        field("growerDocsApprovalDAO").ofType(GrowerDocsApprovalDAO.class).in(growerDocsApprovalService).set(growerDocsApprovalDAO);
        field("growerDocsApprovalLogDAO").ofType(GrowerDocsApprovalLogDAO.class).in(growerDocsApprovalService).set(growerDocsApprovalLogDAO);
        field("growerDocsApprovalMailService").ofType(GrowerDocsApprovalMailService.class).in(growerDocsApprovalService).set(growerDocsApprovalMailService);
    }

    @Test
    public void test_getGrowerDocsApprovalCallsGrowerDocsApprovalService_getGrowerDocsApproval() throws EntityNotFoundException {
        Grower aGrower = new Grower();
        aGrower.setId(1L);
        growerDocsApprovalService.getGrowerDocsApproval(aGrower);
        verify(growerDocsApprovalDAO,times(1)).selectBy(aGrower.getId());
    }

    @Test
    public void test_whenGrowerDocsDontHaveAStateThenPENDING_APPROVAL_isSettedup() throws EntityNotFoundException, GrowerDocsApprovalFlowException {
        //@Given
        Grower aGrower = new Grower();
        aGrower.setId(1L);
        UserContext loginUser = mock(UserContext.class);
        when(loginUser.getLogin()).thenReturn("aUserLogin");
        when(growerDocsApprovalDAO.selectBy(aGrower.getId())).thenThrow(new EntityNotFoundException(""));

        //@When
        growerDocsApprovalService.resetGrowerDocs(aGrower,loginUser);

        //@Then
        ArgumentCaptor<GrowerDocsApproval> argumentCaptor = ArgumentCaptor.forClass(GrowerDocsApproval.class);
        verify(growerDocsApprovalDAO, times(1)).save(argumentCaptor.capture());

        GrowerDocsApproval approval = argumentCaptor.getValue();
        assertEquals(approval.getState(), GrowerDocsApproval.ApprovalState.PENDING_APPROVAL);
        assertEquals(approval.getLoginUser(),loginUser.getLogin());
        assertEquals(approval.getComment(),"");

        verify(growerDocsApprovalLogDAO,times(1)).save(any(GrowerDocsApprovalLog.class));

    }

    //camino feliz para el resetGrowerDocs
    @Test
    public void test_resetGrowerDocsSavesApprovalInPENDING_APPROVALState() throws EntityNotFoundException, GrowerDocsApprovalFlowException {

        //@Given
        Grower aGrower = new Grower();
        aGrower.setId(1L);
        UserContext loginUser = mock(UserContext.class);
        when(loginUser.getLogin()).thenReturn("aUserLogin");
        GrowerDocsApproval growerDocsApproval = new GrowerDocsApproval();
        growerDocsApproval.setState(GrowerDocsApproval.ApprovalState.OBSERVED);
        when(growerDocsApprovalDAO.selectBy(aGrower.getId())).thenReturn(growerDocsApproval);

        //@When
        growerDocsApprovalService.resetGrowerDocs(aGrower,loginUser);

        //@Then
        assertEquals(growerDocsApproval.getState(),GrowerDocsApproval.ApprovalState.PENDING_APPROVAL);
        assertEquals(growerDocsApproval.getLoginUser(),loginUser.getLogin());
        assertEquals(growerDocsApproval.getComment(),"");
        verify(growerDocsApprovalDAO,times(1)).save(growerDocsApproval);
        verify(growerDocsApprovalLogDAO,times(1)).save(any(GrowerDocsApprovalLog.class));
    }

    //camino no feliz para el resetGrowerDocs
    @Test
    public void test_resetGrowerDocsThrowsGrowerDocsApprovalFlowExceptionWhenActualStateIsNotObserved() throws EntityNotFoundException {

        //@Given
        Grower aGrower = new Grower();
        aGrower.setId(1L);
        UserContext loginUser = mock(UserContext.class);
        when(loginUser.getLogin()).thenReturn("aUserLogin");
        GrowerDocsApproval growerDocsApproval = new GrowerDocsApproval();
        growerDocsApproval.setState(GrowerDocsApproval.ApprovalState.APPROVED);
        when(growerDocsApprovalDAO.selectBy(aGrower.getId())).thenReturn(growerDocsApproval);

        try {
            //@When
            growerDocsApprovalService.resetGrowerDocs(aGrower,loginUser);
            fail();
        } catch (GrowerDocsApprovalFlowException e) {
            //@Then
            assertEquals(e.getLanguageKey(),LABEL_GROWER_DOCS_APPROVAL_ERROR_UPDATE_TO_PENDING_APPROVAL);
            assertEquals(e.getMessage(),"Cannot set grower docs state to "+ GrowerDocsApproval.ApprovalState.PENDING_APPROVAL.toString()+". Expected state [" +
                    GrowerDocsApproval.ApprovalState.OBSERVED.name() + "], current state is [" + growerDocsApproval.getState().name() + "]");

        }
    }

    //camino feliz para el approveGrowerDocs
    @Test
    public void test_ApproveGrowerDocsSavesApprovalInAPPROVEDStateAndSendNotification() throws EntityNotFoundException, GrowerDocsApprovalFlowException {

        //@Given
        String aComment = "aComment";
        Grower aGrower = new Grower();
        aGrower.setId(1L);
        UserContext loginUser = mock(UserContext.class);
        when(loginUser.getLogin()).thenReturn("aUserLogin");
        GrowerDocsApproval growerDocsApproval = new GrowerDocsApproval();
        growerDocsApproval.setState(GrowerDocsApproval.ApprovalState.SENT_TO_APPROVAL);
        when(growerDocsApprovalDAO.selectBy(aGrower.getId())).thenReturn(growerDocsApproval);

        //@When
        growerDocsApprovalService.approveGrowerDocs(aGrower, loginUser, aComment);

        //@Then
        assertEquals(growerDocsApproval.getState(),GrowerDocsApproval.ApprovalState.APPROVED);
        assertEquals(growerDocsApproval.getLoginUser(),loginUser.getLogin());
        assertEquals(growerDocsApproval.getComment(),aComment);
        verify(growerDocsApprovalDAO,times(1)).save(growerDocsApproval);
        verify(growerDocsApprovalLogDAO,times(1)).save(any(GrowerDocsApprovalLog.class));
        verify(growerDocsApprovalMailService,times(1)).sendNotification(GrowerDocsApproval.ApprovalState.APPROVED,growerDocsApproval,loginUser);
    }

    //camino no feliz para el approveGrowerDocs
    @Test
    public void test_ApproveGrowerDocsThrowsGrowerDocsApprovalFlowExceptionWhenActualStateIsNotSENT_TO_APPROVAL() throws EntityNotFoundException {

        //@Given
        String aComment = "aComment";
        Grower aGrower = new Grower();
        aGrower.setId(1L);
        UserContext loginUser = mock(UserContext.class);
        when(loginUser.getLogin()).thenReturn("aUserLogin");
        GrowerDocsApproval growerDocsApproval = new GrowerDocsApproval();
        growerDocsApproval.setState(GrowerDocsApproval.ApprovalState.APPROVED);
        when(growerDocsApprovalDAO.selectBy(aGrower.getId())).thenReturn(growerDocsApproval);

        try {
            //@When
            growerDocsApprovalService.approveGrowerDocs(aGrower, loginUser, aComment);
            fail();
        } catch (GrowerDocsApprovalFlowException e) {
            //@Then
            assertEquals(e.getLanguageKey(),LABEL_GROWER_DOCS_APPROVAL_ERROR_UPDATE_TO_APPROVED);
            assertEquals(e.getMessage(),"Cannot approve grower docs. Expected state [" +
                    GrowerDocsApproval.ApprovalState.SENT_TO_APPROVAL.name() + "], current state is [" + growerDocsApproval.getState().name() + "]");
        }
    }

    //camino feliz para el observeGrowerDocs
    @Test
    public void test_observeGrowerDocsSavesApprovalInOBSERVEDStateAndSendNotification() throws EntityNotFoundException, GrowerDocsApprovalFlowException {

        //@Given
        String aComment = "aComment";
        Grower aGrower = new Grower();
        aGrower.setId(1L);
        UserContext loginUser = mock(UserContext.class);
        when(loginUser.getLogin()).thenReturn("aUserLogin");
        GrowerDocsApproval growerDocsApproval = new GrowerDocsApproval();
        growerDocsApproval.setState(GrowerDocsApproval.ApprovalState.SENT_TO_APPROVAL);
        when(growerDocsApprovalDAO.selectBy(aGrower.getId())).thenReturn(growerDocsApproval);

        //@When
        growerDocsApprovalService.observeGrowerDocs(aGrower, loginUser, aComment);

        //@Then
        assertEquals(growerDocsApproval.getState(),GrowerDocsApproval.ApprovalState.OBSERVED);
        assertEquals(growerDocsApproval.getLoginUser(),loginUser.getLogin());
        assertEquals(growerDocsApproval.getComment(),aComment);
        verify(growerDocsApprovalDAO,times(1)).save(growerDocsApproval);
        verify(growerDocsApprovalLogDAO,times(1)).save(any(GrowerDocsApprovalLog.class));
        verify(growerDocsApprovalMailService,times(1)).sendNotification(GrowerDocsApproval.ApprovalState.OBSERVED,growerDocsApproval,loginUser);
    }

    //camino no feliz para el observeGrowerDocs
    @Test
    public void test_observeGrowerDocsThrowsGrowerDocsApprovalFlowExceptionWhenActualStateIsNotSENT_TO_APPROVAL() throws EntityNotFoundException {

        //@Given
        String aComment = "aComment";
        Grower aGrower = new Grower();
        aGrower.setId(1L);
        UserContext loginUser = mock(UserContext.class);
        when(loginUser.getLogin()).thenReturn("aUserLogin");
        GrowerDocsApproval growerDocsApproval = new GrowerDocsApproval();
        growerDocsApproval.setState(GrowerDocsApproval.ApprovalState.APPROVED);
        when(growerDocsApprovalDAO.selectBy(aGrower.getId())).thenReturn(growerDocsApproval);

        try {
            //@When
            growerDocsApprovalService.observeGrowerDocs(aGrower, loginUser, aComment);
            fail();
        } catch (GrowerDocsApprovalFlowException e) {
            //@Then
            assertEquals(e.getLanguageKey(),LABEL_GROWER_DOCS_APPROVAL_ERROR_UPDATE_TO_OBSERVED);
            assertEquals(e.getMessage(),"Cannot observe grower docs. Expected state [" +
                    GrowerDocsApproval.ApprovalState.SENT_TO_APPROVAL.name() + "], current state is [" + growerDocsApproval.getState().name() + "]");
        }
    }

    //camino feliz para el sendToApprovalGrowerDocs
    @Test
    public void test_sendToApprovalGrowerDocsSavesApprovalInSENT_TO_APPROVALStateAndSendNotification() throws EntityNotFoundException, GrowerDocsApprovalFlowException {

        //@Given
        String aComment = "aComment";
        Grower aGrower = new Grower();
        aGrower.setId(1L);
        UserContext loginUser = mock(UserContext.class);
        when(loginUser.getLogin()).thenReturn("aUserLogin");
        GrowerDocsApproval growerDocsApproval = new GrowerDocsApproval();
        growerDocsApproval.setState(GrowerDocsApproval.ApprovalState.PENDING_APPROVAL);
        when(growerDocsApprovalDAO.selectBy(aGrower.getId())).thenReturn(growerDocsApproval);

        //@When
        growerDocsApprovalService.sendToApprovalGrowerDocs(aGrower, loginUser, aComment);

        //@Then
        assertEquals(growerDocsApproval.getState(),GrowerDocsApproval.ApprovalState.SENT_TO_APPROVAL);
        assertEquals(growerDocsApproval.getLoginUser(),loginUser.getLogin());
        assertEquals(growerDocsApproval.getComment(),aComment);
        verify(growerDocsApprovalDAO,times(1)).save(growerDocsApproval);
        verify(growerDocsApprovalLogDAO,times(1)).save(any(GrowerDocsApprovalLog.class));
        verify(growerDocsApprovalMailService,times(1)).sendNotification(GrowerDocsApproval.ApprovalState.SENT_TO_APPROVAL,growerDocsApproval,loginUser);
    }

    //camino no feliz para el sendToApprovalGrowerDocs
    @Test
    public void test_sendToApprovalGrowerDocsThrowsGrowerDocsApprovalFlowExceptionWhenActualStateIsNotPENDING_APPROVAL() throws EntityNotFoundException {

        //@Given
        String aComment = "aComment";
        Grower aGrower = new Grower();
        aGrower.setId(1L);
        UserContext loginUser = mock(UserContext.class);
        when(loginUser.getLogin()).thenReturn("aUserLogin");
        GrowerDocsApproval growerDocsApproval = new GrowerDocsApproval();
        growerDocsApproval.setState(GrowerDocsApproval.ApprovalState.APPROVED);
        when(growerDocsApprovalDAO.selectBy(aGrower.getId())).thenReturn(growerDocsApproval);

        try {
            //@When
            growerDocsApprovalService.sendToApprovalGrowerDocs(aGrower, loginUser, aComment);
            fail();
        } catch (GrowerDocsApprovalFlowException e) {
            //@Then
            assertEquals(e.getLanguageKey(),LABEL_GROWER_DOCS_APPROVAL_ERROR_UPDATE_TO_SENT_TO_APPROVAL);
            assertEquals(e.getMessage(),"Cannot send to approval grower docs. Expected state [" +
                    GrowerDocsApproval.ApprovalState.PENDING_APPROVAL.name() + "], current state is [" + growerDocsApproval.getState().name() + "]");
        }
    }

}
