package com.monsanto.brazilvaluecapture.core.grower;

import static org.fest.assertions.Assertions.assertThat;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import junit.framework.Assert;

import org.hibernate.Criteria;
import org.hibernate.SessionFactory;
import org.hibernate.classic.Session;
import org.junit.Before;
import org.junit.Test;

import com.monsanto.brazilvaluecapture.core.base.CityTestData;
import com.monsanto.brazilvaluecapture.core.base.model.bean.BillingAddress;
import com.monsanto.brazilvaluecapture.core.base.model.bean.BusinessAddress;
import com.monsanto.brazilvaluecapture.core.base.model.bean.City;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Country;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Document;
import com.monsanto.brazilvaluecapture.core.base.model.bean.DocumentType;
import com.monsanto.brazilvaluecapture.core.base.model.bean.State;
import com.monsanto.brazilvaluecapture.core.foundation.RandomTestData;
import com.monsanto.brazilvaluecapture.core.grower.model.bean.Grower;
import com.monsanto.brazilvaluecapture.core.grower.model.dao.GrowerDAO;
import com.monsanto.brazilvaluecapture.core.grower.model.dao.impl.GrowerDAOImpl;

public class Grower_UT  extends CreateTestData{
	
	private static final int TEN = 10;
	
	GrowerDAO growerDAO;
	Session mockSession;
	SessionFactory mockSessionFactory;
	
	@Before
	public void setup(){
		mockSessionFactory = mock(SessionFactory.class);
		mockSession = mock(Session.class);
		when(mockSessionFactory.getCurrentSession()).thenReturn(mockSession);
		growerDAO = new GrowerDAOImpl(mockSessionFactory);		
	}
	
	@Test
	public void createObjectTest() {
		
		Grower grower = createFullGrower();
		
		testAssert(grower);
		
	}
	
	@Test
	public void createObjectConstructorTest() {
		
		Country country = createBasicCountry();
		State state = createStateByCountry(country);
		City city = CityTestData.createCityByState(state);
		String randomString = RandomTestData.createRandomString(TEN);
		BusinessAddress businessAddress = new BusinessAddress(randomString,randomString,randomString,randomString,randomString,randomString,randomString,city,state,country);
		BillingAddress billingAddress = new BillingAddress(randomString,randomString,randomString,randomString,randomString,randomString,randomString,city,state,country); 
		DocumentType documentType = createDocumentType(country);
		Document document = createDocument(documentType);
		
		Grower grower = PlayerTestData.createGrower(document, billingAddress, businessAddress);
		
		testAssert(grower);
		
	}
	
	@Test
	public void createObjectConstructorNullTest() {
		
		Country country = createBasicCountry();
		State state = createStateByCountry(country);
		City city = CityTestData.createCityByState(state);
		
		BusinessAddress businessAddress = new BusinessAddress(null,null,null,null,null,null,null,city,state,country);
		BillingAddress billingAddress = new BillingAddress(null,null,null,null,null,null,null,city,state,country);
		
		DocumentType documentType = createDocumentType(country);
		Document document = createDocument(documentType);
		
		Grower grower = new Grower(document, null, null, null, billingAddress, businessAddress);
		
		testAssertNull(grower);
		
	}

	@Test
	public void setVariablesNullTest() {
		
		Grower grower = new Grower();
		BillingAddress billingAddress = new BillingAddress();
		BusinessAddress businessAddress = new BusinessAddress();
				
		billingAddress.setStreet(null);
		billingAddress.setNumber(null);
		billingAddress.setComplement(null);
		billingAddress.setNeighborhood(null);
		billingAddress.setZipCode(null);
		billingAddress.setTelephone(null);
		billingAddress.setFax(null);
		
		businessAddress.setStreet(null);
		businessAddress.setNumber(null);
		businessAddress.setComplement(null);
		businessAddress.setNeighborhood(null);
		businessAddress.setZipCode(null);
		businessAddress.setTelephone(null);
		businessAddress.setFax(null);
		
		grower.setAlias(null);
		grower.setEmail(null);
		grower.setName(null);
		grower.setBillingAddress(billingAddress);
		grower.setBusinessAddress(businessAddress);
				
		Assert.assertNull(grower.getAlias());
		Assert.assertNull(grower.getEmail());
		Assert.assertNull(grower.getName());
		
		testAssertNull(grower);
	}

	private void testAssertNull(Grower grower) {
		Assert.assertNull(grower.getName());
		Assert.assertNull(grower.getAlias());
		Assert.assertNull(grower.getEmail());

		Assert.assertNull(grower.getBillingAddress().getStreet());
		Assert.assertNull(grower.getBillingAddress().getNumber());
		Assert.assertNull(grower.getBillingAddress().getComplement());
		Assert.assertNull(grower.getBillingAddress().getNeighborhood());
		Assert.assertNull(grower.getBillingAddress().getZipCode());
		Assert.assertNull(grower.getBillingAddress().getTelephone());
		Assert.assertNull(grower.getBillingAddress().getFax());
		
		Assert.assertNull(grower.getBusinessAddress().getStreet());
		Assert.assertNull(grower.getBusinessAddress().getNumber());
		Assert.assertNull(grower.getBusinessAddress().getComplement());
		Assert.assertNull(grower.getBusinessAddress().getNeighborhood());
		Assert.assertNull(grower.getBusinessAddress().getZipCode());
		Assert.assertNull(grower.getBusinessAddress().getTelephone());
		Assert.assertNull(grower.getBusinessAddress().getFax());
	}
	
	@Test
	public void createPlantabilityTest() {
		Grower grower = createFullGrower();

		doNothing().when(mockSession).saveOrUpdate(grower);

		growerDAO.save(grower);
		
		Assert.assertNotNull(grower);

		testAssert(grower);
	}
	
	@Test
	public void selectAllGrowerEqualsInsertTest() {

		Grower grower = createFullGrower();

		doNothing().when(mockSession).saveOrUpdate(grower);

		growerDAO.save(grower);

		testAssert(grower);

		Criteria mockCriteria = mock(Criteria.class);

		when(mockSession.createCriteria(Grower.class, "g")).thenReturn(mockCriteria);

		List<Grower> growers = new ArrayList<Grower>();
		growers.add(grower);

		when(mockCriteria.list()).thenReturn(growers);

		List<Grower> list = growerDAO.selectAllGrowerEquals(grower);

		Assert.assertEquals(growers, list);
	}
	
	@Test
	public void selectAllGrowerEqualsUpdateTest() {

		Grower grower = createFullGrower();

		doNothing().when(mockSession).saveOrUpdate(grower);

		growerDAO.save(grower);
		grower.setId(RandomTestData.createRandomLong());

		Assert.assertNotNull(grower);

		Criteria mockCriteria = mock(Criteria.class);

		when(mockSession.createCriteria(Grower.class, "g")).thenReturn(mockCriteria);

		List<Grower> growers = new ArrayList<Grower>();
		growers.add(grower);

		when(mockCriteria.list()).thenReturn(growers);

		List<Grower> list = growerDAO.selectAllGrowerEquals(grower);

		Assert.assertEquals(growers, list);

	}
	
	/**
	 * Validating of grower
	 * 
	 * @param grower
	 */
	private void testAssert(Grower grower){
		
		Assert.assertNotNull(grower);
		Assert.assertNotNull(grower.getName());
		Assert.assertNull(grower.getPrimaryKey());
		Assert.assertNotNull(grower.getAlias());
		Assert.assertNotNull(grower.getEmail());
		
		Assert.assertNotNull(grower.getDocument());
		Assert.assertNotNull(grower.getDocument().getValue());
		Assert.assertNull(grower.getDocument().getPrimaryKey());
		Assert.assertNotNull(grower.getDocument().getDocumentType());
		Assert.assertNotNull(grower.getDocument().getDocumentType().getMask());
		Assert.assertNotNull(grower.getDocument().getDocumentType().getDescription());
		Assert.assertNull(grower.getDocument().getDocumentType().getPrimaryKey());
		Assert.assertNotNull(grower.getDocument().getDocumentType().getCountry());
		
		Assert.assertNotNull(grower.getBillingAddress());
		Assert.assertNull(grower.getBillingAddress().getPrimaryKey());
		Assert.assertNotNull(grower.getBillingAddress().getComplement());
		Assert.assertNotNull(grower.getBillingAddress().getFax());
		Assert.assertNotNull(grower.getBillingAddress().getNeighborhood());
		Assert.assertNotNull(grower.getBillingAddress().getNumber());
		Assert.assertNotNull(grower.getBillingAddress().getStreet());
		Assert.assertNotNull(grower.getBillingAddress().getTelephone());
		Assert.assertNotNull(grower.getBillingAddress().getZipCode());
		
		Assert.assertNotNull(grower.getBillingAddress().getCity());
		Assert.assertNull(grower.getBillingAddress().getCity().getPrimaryKey());
		Assert.assertNotNull(grower.getBillingAddress().getCity().getDescription());
		Assert.assertNotNull(grower.getBillingAddress().getCity().getState());
		
		Assert.assertNotNull(grower.getBillingAddress().getState());
		Assert.assertNull(grower.getBillingAddress().getState().getPrimaryKey());
		Assert.assertNotNull(grower.getBillingAddress().getState().getDescription());
		Assert.assertNotNull(grower.getBillingAddress().getState().getCode());
		Assert.assertNotNull(grower.getBillingAddress().getState().getCountry());
		
		Assert.assertNotNull(grower.getBillingAddress().getCountry());
		Assert.assertNull(grower.getBillingAddress().getCountry().getPrimaryKey());
		Assert.assertNotNull(grower.getBillingAddress().getCountry().getDescription());
		Assert.assertNotNull(grower.getBillingAddress().getCountry().getCode());
		
		Assert.assertNotNull(grower.getBusinessAddress());
		Assert.assertNull(grower.getBusinessAddress().getPrimaryKey());
		Assert.assertNotNull(grower.getBusinessAddress().getComplement());
		Assert.assertNotNull(grower.getBusinessAddress().getFax());
		Assert.assertNotNull(grower.getBusinessAddress().getNeighborhood());
		Assert.assertNotNull(grower.getBusinessAddress().getNumber());
		Assert.assertNotNull(grower.getBusinessAddress().getStreet());
		Assert.assertNotNull(grower.getBusinessAddress().getTelephone());
		Assert.assertNotNull(grower.getBusinessAddress().getZipCode());
		
		Assert.assertNotNull(grower.getBusinessAddress().getCity());
		Assert.assertNull(grower.getBusinessAddress().getCity().getPrimaryKey());
		Assert.assertNotNull(grower.getBusinessAddress().getCity().getDescription());
		Assert.assertNotNull(grower.getBusinessAddress().getCity().getState());
		
		Assert.assertNotNull(grower.getBusinessAddress().getState());
		Assert.assertNull(grower.getBusinessAddress().getState().getPrimaryKey());
		Assert.assertNotNull(grower.getBusinessAddress().getState().getDescription());
		Assert.assertNotNull(grower.getBusinessAddress().getState().getCode());
		Assert.assertNotNull(grower.getBusinessAddress().getState().getCountry());
		
		Assert.assertNotNull(grower.getBusinessAddress().getCountry());
		Assert.assertNull(grower.getBusinessAddress().getCountry().getPrimaryKey());
		Assert.assertNotNull(grower.getBusinessAddress().getCountry().getDescription());
		Assert.assertNotNull(grower.getBusinessAddress().getCountry().getCode());
		
	}

    @Test
	public void getDocumentValueWithMaskUsingDefaultCharactersArgentina() {
        Grower grower = new Grower();
        Country country = createBasicCountry();
	    State state = createStateByCountry(country);
		City city = CityTestData.createCityByState(state);
		DocumentType documentType = createDocumentType(country);
        documentType.setMask("##-########-#");
		Document document = createDocument(documentType);
        document.setValue("30500031960");
        grower.setDocument(document);
        String value = grower.getDocumentSAPValue();
        assertThat(value).isEqualToIgnoringCase("30-50003196-0");
    }

    @Test
	public void getDocumentValueWithMaskUsingNumbersArgentina() {
        Grower grower = new Grower();
        Country country = createBasicCountry();
	    State state = createStateByCountry(country);
		City city = CityTestData.createCityByState(state);
		DocumentType documentType = createDocumentType(country);
        documentType.setMask("99-99999999-9");
		Document document = createDocument(documentType);
        document.setValue("30500031960");
        grower.setDocument(document);
        String value = grower.getDocumentSAPValue();
        assertThat(value).isEqualToIgnoringCase("30-50003196-0");
    }

    @Test
    public void getDocumentValueWithMaskUsingDefaultCharactersParaguay() {
        Grower grower = new Grower();
        Country country = createBasicCountry();
        State state = createStateByCountry(country);
        City city = CityTestData.createCityByState(state);
        DocumentType documentType = createDocumentType(country);
        documentType.setMask("##########-#");
        Document document = createDocument(documentType);
        document.setValue("30500031960");
        grower.setDocument(document);
        String value = grower.getDocumentSAPValue();
        assertThat(value).isEqualToIgnoringCase("3050003196-0");
    }

    @Test
    public void getDocumentValueWithMaskUsingNumbersParaguay() {
        Grower grower = new Grower();
        Country country = createBasicCountry();
        State state = createStateByCountry(country);
        City city = CityTestData.createCityByState(state);
        DocumentType documentType = createDocumentType(country);
        documentType.setMask("9999999999-9");
        Document document = createDocument(documentType);
        document.setValue("30500031960");
        grower.setDocument(document);
        String value = grower.getDocumentSAPValue();
        assertThat(value).isEqualToIgnoringCase("3050003196-0");
    }

    @Test
    public void getDocumentValueWithNullMask() {
        Grower grower = new Grower();
        Country country = createBasicCountry();
        State state = createStateByCountry(country);
        City city = CityTestData.createCityByState(state);
        DocumentType documentType = createDocumentType(country);
        documentType.setMask(null);
        Document document = createDocument(documentType);
        document.setValue("30500031960");
        grower.setDocument(document);
        String value = grower.getDocumentSAPValue();
        assertThat(value).isEqualToIgnoringCase("30500031960");
    }
}
