package com.monsanto.brazilvaluecapture.seedsale.sale.validation;

import com.monsanto.brazilvaluecapture.core.base.model.bean.Country;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Document;
import com.monsanto.brazilvaluecapture.core.base.model.bean.DocumentType;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Customer;
import com.monsanto.brazilvaluecapture.core.foundation.util.ConstraintViolation;
import com.monsanto.brazilvaluecapture.core.foundation.util.ErrorCode;
import com.monsanto.brazilvaluecapture.core.foundation.validation.ValidationException;
import com.monsanto.brazilvaluecapture.core.grower.model.bean.Grower;
import com.monsanto.brazilvaluecapture.seedsale.product.model.bean.Product;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.Sale;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.SaleItem;
import com.monsanto.brazilvaluecapture.seedsale.sale.service.SaleConstraintViolationException;
import com.monsanto.brazilvaluecapture.seedsale.template.model.bean.SaleTemplate;
import org.junit.Test;

import java.util.List;

import static org.fest.assertions.Assertions.assertThat;
import static org.fest.assertions.Fail.fail;

public class CustomerDocumentValidationRule_UT {
    @Test
    public void testValidateThrowsValidationException_WhenSaleCustomerDocumentTypeIsIncorrect() {
        Sale sale = createSale("documentNumber");
        CustomerDocumentValidationRule customerDocumentValidationRule = new CustomerDocumentValidationRule();

        try {
            customerDocumentValidationRule.validate(sale);
            fail("Should fail with ValidationException");
        } catch (ValidationException e) {
            assertThat(e).isInstanceOf(SaleValidationException.class);
            SaleValidationException saleValidationException = (SaleValidationException) e;
            SaleConstraintViolationException saleViolation = saleValidationException.getSaleViolation();
            assertThat(saleViolation).hasMessage("Invalid document");
            List<ConstraintViolation> violations = saleViolation.getViolations();
            int expectedViolationNumber = 1;
            assertThat(violations).hasSize(expectedViolationNumber);
            assertThat(violations).onProperty("message").contains("Invalid document");
            assertThat(violations).onProperty("code").contains(ErrorCode.INVALID_VALUE);
            assertThat(violations).onProperty("field").contains("import.parse.headoffice.document.type");
        }
    }

    @Test
    public void testValidateDoNotThrowsValidationException_WhenSaleCustomerDocumentTypeIsCorrect() {
        Sale sale = createSale("93424620003235");
        CustomerDocumentValidationRule customerDocumentValidationRule = new CustomerDocumentValidationRule();

        try {
            customerDocumentValidationRule.validate(sale);
        } catch (ValidationException e) {
            fail("Should not fail with ValidationException");
        }
    }

    private Sale createSale(String documentNumber) {
        Customer dealer = new Customer();
        DocumentType documentTypeCNPJ = new DocumentType("CNPJ", new Country(), "99.999.999/9999-99");
        Document document = new Document(documentTypeCNPJ, documentNumber);
        dealer.setDocument(document);
        Grower grower = new Grower();
        Sale sale = new Sale(dealer, grower);
        SaleItem saleItem = new SaleItem(sale, new SaleTemplate(), new Product(), new Customer());
        saleItem.setCustomerParent(dealer);
        return sale;
    }

}
