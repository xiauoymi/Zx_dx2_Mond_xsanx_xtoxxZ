package com.monsanto.brazilvaluecapture.core.quota.service;

import com.monsanto.brazilvaluecapture.core.foundation.test.AbstractServiceIntegrationTests;
import com.monsanto.brazilvaluecapture.core.foundation.test.dbunit.DbUnitHelper;
import com.monsanto.brazilvaluecapture.core.quota.model.bean.QuotaFYTransaction;
import com.monsanto.brazilvaluecapture.core.quota.service.impl.QuotaFYTransactionServiceImpl;
import org.hibernate.Hibernate;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: GAVELO
 * Date: 4/26/13
 * Time: 4:41 PM
 * To change this template use File | Settings | File Templates.
 */
public class QuotaFYTransactionService_AT extends AbstractServiceIntegrationTests {


    @Autowired
    private QuotaFYTransactionService service;

    @Before
    public void setUp() {

        DbUnitHelper.setup("classpath:data/core/basic-fixture.xml", "classpath:data/core/quotaFY-dataset.xml", "classpath:data/core/quotaFYTransaction-dataset.xml");

    }


    @Test
    public void testgetByQuotaFYId() {

        List<QuotaFYTransaction> transactions = service.getByQuotaFYId(990000003L);

        Assert.assertNotNull(transactions);
        Assert.assertEquals(2,transactions.size());

    }


}
