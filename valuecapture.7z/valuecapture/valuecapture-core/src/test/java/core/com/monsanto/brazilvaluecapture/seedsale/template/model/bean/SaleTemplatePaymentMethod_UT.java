package com.monsanto.brazilvaluecapture.seedsale.template.model.bean;

import junit.framework.Assert;
import org.junit.Test;

/**
 * Created by IntelliJ IDEA.
 * User: JAKAGI
 * Date: 09/10/13
 * Time: 15:21
 * To change this template use File | Settings | File Templates.
 */
public class SaleTemplatePaymentMethod_UT {
    @Test
    public void when_hashCode(){
        SaleTemplate st = new SaleTemplate(){
                                @Override
                                public int hashCode() {
                                    return 2;
                                }
                            };

        SaleTemplatePaymentMethod s = new SaleTemplatePaymentMethod(null,st);
        Assert.assertEquals("when_hashCode ", 62, s.hashCode());
    }
}
