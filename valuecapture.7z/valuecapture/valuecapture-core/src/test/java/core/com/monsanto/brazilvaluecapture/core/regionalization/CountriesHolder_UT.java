package com.monsanto.brazilvaluecapture.core.regionalization;

import static org.fest.assertions.Assertions.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.monsanto.brazilvaluecapture.core.foundation.util.security.EnvironmentSpecificPropertyReader;
import org.springframework.test.util.ReflectionTestUtils;

public class CountriesHolder_UT {

	private CountriesHolder countriesHolder;
	
	private EnvironmentSpecificPropertyReader env;
	
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
		countriesHolder = new CountriesHolder();
		env = mock(EnvironmentSpecificPropertyReader.class);
		countriesHolder.setEnvironmentSpecificPropertyReader(env);
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testInitialize() {
		countriesHolder.initialize();
		verify(env).getEnvironmentSpecificProperty("host_name.argentina", null);
		verify(env).getEnvironmentSpecificProperty("host_name.paraguay", null);
		verify(env).getEnvironmentSpecificProperty("host_name.brazil", null);
		
	}

	@Test
	public void whenURLMatchesConfigurationArgentinaKey() {
		
		String configuredHost = "CONFIGURED_AND_REQUESTED_HOST_SAME";
		
		when(env.getEnvironmentSpecificProperty("host_name.argentina", null)).thenReturn(configuredHost);
		when(env.getEnvironmentSpecificProperty("host_name.brazil", null)).thenReturn("other");
		when(env.getEnvironmentSpecificProperty("host_name.paraguay", null)).thenReturn("another");
		
		countriesHolder.initialize();
		countriesHolder.resolveCountry(configuredHost);
		
		VCCountry actualCountry = countriesHolder.getCountry();
		Assert.assertEquals(VCCountry.ARGENTINA, actualCountry);
	}
	
	@Test
	public void whenURLMatchesConfigurationBrazilKey() {
		
		String configuredHost = "CONFIGURED_AND_REQUESTED_HOST_SAME";
		
		when(env.getEnvironmentSpecificProperty("host_name.argentina", null)).thenReturn("other");
		when(env.getEnvironmentSpecificProperty("host_name.brazil", null)).thenReturn(configuredHost);
		when(env.getEnvironmentSpecificProperty("host_name.paraguay", null)).thenReturn("another");

		countriesHolder.initialize();
		countriesHolder.resolveCountry(configuredHost);
		
		VCCountry actualCountry = countriesHolder.getCountry();
		Assert.assertEquals(VCCountry.BRAZIL, actualCountry);
	}
	
	@Test
	public void whenURLMatchesConfigurationParaguayKey() {

		String configuredHost = "CONFIGURED_AND_REQUESTED_HOST_SAME";
		
		
		when(env.getEnvironmentSpecificProperty("host_name.argentina", null)).thenReturn("other");
		when(env.getEnvironmentSpecificProperty("host_name.brazil", null)).thenReturn("another");
		when(env.getEnvironmentSpecificProperty("host_name.paraguay", null)).thenReturn(configuredHost);

		countriesHolder.initialize();
		countriesHolder.resolveCountry(configuredHost);

		VCCountry actualCountry = countriesHolder.getCountry();
		Assert.assertEquals(VCCountry.PARAGUAY, actualCountry);
	}
	
	@Test(expected=RuntimeException.class)
	public void whenURLDoesntMatchesConfiguration() {
		
		String configuredHost = "CONFIGURED_HOST";
		String requestedHost = "REQUESTED_HOST";
		
		when(env.getEnvironmentSpecificProperty("host_name.argentina", null)).thenReturn(configuredHost);
		when(env.getEnvironmentSpecificProperty("host_name.brazil", null)).thenReturn("other");
		when(env.getEnvironmentSpecificProperty("host_name.paraguay", null)).thenReturn("another");
		
		countriesHolder.initialize();
		countriesHolder.resolveCountry(requestedHost);
		countriesHolder.getCountry();
	}
	
	@Test(expected = IllegalStateException.class)
	public void whenFinalizeIsCalledThreadEndsClean() {
		whenURLMatchesConfigurationArgentinaKey();
		countriesHolder.forget();
		countriesHolder.getCountry();
	}
	
	@Test(expected = IllegalStateException.class)
	public void whenCountrySettedAgain() {
		
		String configuredHost = "CONFIGURED_AND_REQUESTED_HOST_SAME";
		
				when(env.getEnvironmentSpecificProperty("host_name.argentina", null)).thenReturn(configuredHost);
		when(env.getEnvironmentSpecificProperty("host_name.brazil", null)).thenReturn("other");
		when(env.getEnvironmentSpecificProperty("host_name.paraguay", null)).thenReturn("another");
		
		countriesHolder.initialize();

		countriesHolder.resolveCountry(configuredHost);
		countriesHolder.resolveCountry(configuredHost);

	}

    @Test
    public void isLASShouldSuccessWhenCountryIsArgentina() throws Exception {
        ThreadLocal<VCCountry> mockCountries = mock(ThreadLocal.class);
        when(mockCountries.get()).thenReturn(VCCountry.ARGENTINA);
        CountriesHolder countriesHolder=new CountriesHolder();
        ReflectionTestUtils.setField(countriesHolder,"countries",mockCountries);
        assertThat(countriesHolder.isLAS()).isTrue();
    }

    @Test
    public void isLASShouldSuccessWhenCountryIsParaguay() throws Exception {
        ThreadLocal<VCCountry> mockCountries = mock(ThreadLocal.class);
        when(mockCountries.get()).thenReturn(VCCountry.PARAGUAY);
        CountriesHolder countriesHolder=new CountriesHolder();
        ReflectionTestUtils.setField(countriesHolder,"countries",mockCountries);
        assertThat(countriesHolder.isLAS()).isTrue();
    }


}
