package com.monsanto.brazilvaluecapture.core.grower.service.impl;

import com.monsanto.brazilvaluecapture.core.grower.model.bean.Grower;
import com.monsanto.brazilvaluecapture.core.grower.model.bean.GrowerStatusModuleEnum;
import com.monsanto.brazilvaluecapture.core.grower.model.dao.GrowerDAO;
import com.monsanto.brazilvaluecapture.core.grower.service.GrowerStatusReportService;
import com.monsanto.brazilvaluecapture.core.regionalization.VCCountry;
import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import static org.fest.reflect.core.Reflection.field;
import static org.mockito.Mockito.*;

/**
 * Created by afrei on 06/02/14.
 */
public class GrowerStatusReportServiceImpl_UT {

    private GrowerStatusReportService growerStatusReportService;
    private GrowerDAO growerDAO;

    @Before
    public void setUp() {
        growerStatusReportService = new GrowerStatusReportServiceImpl();
        growerDAO = mock(GrowerDAO.class);
        field("growerDAO").ofType(GrowerDAO.class).in(growerStatusReportService).set(growerDAO);
    }

    @Test
    public void testGetProfileByCallsAuditDaoGetProfileBy() {
        VCCountry country = VCCountry.ARGENTINA;
        GrowerStatusModuleEnum statusModule = GrowerStatusModuleEnum.APPROVAL;
        String state = "state";
        String license = "1234";
        String creationUser = "user";
        String customerAgent = "customerAgent";
        String statusUser = "statusUser";
        Date dateFrom = new Date();
        Date dateTo = new Date();
        List<String> growersList = new ArrayList<String>();
        boolean limitResults = true;

        growerStatusReportService.getGrowerStatusBy(country,growersList,license,statusModule,creationUser,customerAgent,statusUser,dateFrom,dateTo,state,limitResults);

        verify(this.growerDAO, times(1)).getGrowerStatusBy(country, growersList, license, statusModule, creationUser, customerAgent, statusUser, dateFrom, dateTo, state, limitResults);

    }
}
