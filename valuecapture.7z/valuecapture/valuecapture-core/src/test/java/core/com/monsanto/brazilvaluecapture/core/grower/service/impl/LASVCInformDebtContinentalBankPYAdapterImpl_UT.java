package com.monsanto.brazilvaluecapture.core.grower.service.impl;

import com.monsanto.brazilvaluecapture.core.base.model.bean.Address;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Document;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Customer;
import com.monsanto.brazilvaluecapture.core.foundation.model.dao.SystemParameterDAO;
import com.monsanto.brazilvaluecapture.core.foundation.util.security.EnvironmentSpecificPropertyReader;
import com.monsanto.brazilvaluecapture.core.foundation.util.security.EnvironmentSpecificPropertyReaderFactory;
import com.monsanto.brazilvaluecapture.core.grower.model.bean.Grower;
import com.monsanto.brazilvaluecapture.core.interfaces.model.bean.InterfaceLog;
import com.monsanto.brazilvaluecapture.core.interfaces.service.InterfaceLogService;
import com.monsanto.brazilvaluecapture.osb.its.api.InfraException;
import com.monsanto.brazilvaluecapture.osb.its.api.LASVCInformDebtContinentalBankPYService;
import com.monsanto.brazilvaluecapture.osb.its.api.LASVCInformDebtContinentalBankPYServiceFactory;
import com.monsanto.brazilvaluecapture.osb.its.lascontinentalbankpy.bean.OperationResult;
import com.monsanto.brazilvaluecapture.osb.util.SecurityContextBadCredentialException;
import com.monsanto.brazilvaluecapture.osb.util.SecurityContextHolder;
import com.monsanto.brazilvaluecapture.osb.util.SecurityContextHolderFactory;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.Sale;
import org.junit.Before;
import org.junit.Test;

import java.math.BigDecimal;
import java.net.MalformedURLException;
import java.util.Date;

import static org.fest.assertions.Assertions.assertThat;
import static org.fest.reflect.core.Reflection.field;
import static org.junit.Assert.fail;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.*;

/**
 * Created by IntelliJ IDEA.
 * User: CGLLLO
 * Date: 4/24/13
 * Time: 3:24 PM
 */
@Deprecated
public class LASVCInformDebtContinentalBankPYAdapterImpl_UT {

    private LASVCInformDebtContinentalBankPYAdapterImpl lasvcInformDebtContinentalBankPYAdapter;
    private SecurityContextHolderFactory securityContextHolderFactory;
    private EnvironmentSpecificPropertyReaderFactory environmentSpecificPropertyReaderFactory;
    private EnvironmentSpecificPropertyReader environmentSpecificPropertyReader;
    private SecurityContextHolder securityContextHolder;
    private SystemParameterDAO systemParameterDAO;
    private LASVCInformDebtContinentalBankPYServiceFactory lasvcInformDebtContinentalBankPYServiceFactory;
    private LASVCInformDebtContinentalBankPYService lasvcInformDebtContinentalBankPYService;
    private InterfaceLogService interfaceLogService;

    @Before
    public void setUp() throws SecurityContextBadCredentialException, MalformedURLException, InfraException {
        securityContextHolder = mock(SecurityContextHolder.class);
        securityContextHolderFactory = mock(SecurityContextHolderFactory.class);
        when(securityContextHolderFactory.getSecurityContextHolder(SecurityContextHolderFactory.TARGET.SAP)).thenReturn(securityContextHolder);

        environmentSpecificPropertyReader = mock(EnvironmentSpecificPropertyReader.class);
        environmentSpecificPropertyReaderFactory = mock(EnvironmentSpecificPropertyReaderFactory.class);
        when(environmentSpecificPropertyReaderFactory.getEnvironmentSpecificPropertyReader()).thenReturn(environmentSpecificPropertyReader);
        when(environmentSpecificPropertyReader.getEnvironmentSpecificProperty("osb_lasvc_inform_debt_continental_bank_py_url", null)).thenReturn("http://www.google.com");

        systemParameterDAO = mock(SystemParameterDAO.class);
        when(systemParameterDAO.selectParameterValueByGroupAndNameAndCountryCode(LASVCInformDebtContinentalBankPYAdapterImpl.I_CONTINENTAL_BANK_DEBT_NOTIFICATION, "CURRENCY", LASVCInformDebtContinentalBankPYAdapterImpl.COUNTRY_CODE)).thenReturn("CURRENCY");
        when(systemParameterDAO.selectParameterValueByGroupAndNameAndCountryCode(LASVCInformDebtContinentalBankPYAdapterImpl.I_CONTINENTAL_BANK_DEBT_NOTIFICATION, "CONCEPT", LASVCInformDebtContinentalBankPYAdapterImpl.COUNTRY_CODE)).thenReturn("CONCEPT");
        when(systemParameterDAO.selectParameterValueByGroupAndNameAndCountryCode(LASVCInformDebtContinentalBankPYAdapterImpl.I_CONTINENTAL_BANK_DEBT_NOTIFICATION, "DUE_DATE", LASVCInformDebtContinentalBankPYAdapterImpl.COUNTRY_CODE)).thenReturn("12/12/2012");

        lasvcInformDebtContinentalBankPYService = mock(LASVCInformDebtContinentalBankPYService.class);
        OperationResult operationResult = new OperationResult();
        when(lasvcInformDebtContinentalBankPYService.informDebt(anyString(), anyString(), anyString(), anyString(), anyString(), anyString(), any(BigDecimal.class), anyString(), anyString(), anyString(), any(Date.class))).thenReturn(operationResult);
        lasvcInformDebtContinentalBankPYServiceFactory = mock(LASVCInformDebtContinentalBankPYServiceFactory.class);
        when(lasvcInformDebtContinentalBankPYServiceFactory.create(any(SecurityContextHolder.class), anyString())).thenReturn(lasvcInformDebtContinentalBankPYService);

        interfaceLogService = mock(InterfaceLogService.class);

        lasvcInformDebtContinentalBankPYAdapter = new LASVCInformDebtContinentalBankPYAdapterImpl(securityContextHolderFactory, environmentSpecificPropertyReaderFactory);
        field("systemParameterDAO").ofType(SystemParameterDAO.class).in(lasvcInformDebtContinentalBankPYAdapter).set(systemParameterDAO);
        field("lasvcInformDebtContinentalBankPYServiceFactory").ofType(LASVCInformDebtContinentalBankPYServiceFactory.class).in(lasvcInformDebtContinentalBankPYAdapter).set(lasvcInformDebtContinentalBankPYServiceFactory);
        field("interfaceLogService").ofType(InterfaceLogService.class).in(lasvcInformDebtContinentalBankPYAdapter).set(interfaceLogService);
    }

    @Test
    public void testInformDebtCallsSapInterfaceInformDebtWithSaleTypeRETAILER_SALE_WhenInformingTheDebtOfaSale() throws Exception {
        // @Given a retailer sale with SaleType = RETAILER_SALE
        Sale sale = createSale(Sale.SaleTypeEnum.RETAILER_SALE);

        // @When informing the debt
        lasvcInformDebtContinentalBankPYAdapter.informDebt(sale);

        // @Then The interface is called with saleType RETAILER_SALE
        verify(lasvcInformDebtContinentalBankPYService, times(1)).informDebt(anyString(), anyString(), anyString(), anyString(), anyString(), anyString(), any(BigDecimal.class), anyString(), anyString(), anyString(), any(Date.class));
        // @Then Log the interface response
        verify(interfaceLogService, times(1)).logInterface(any(InterfaceLog.class));
        verify(lasvcInformDebtContinentalBankPYService, times(1)).informDebt(anyString(), anyString(), anyString(), anyString(), anyString(), anyString(), any(BigDecimal.class), anyString(), anyString(), anyString(), any(Date.class));
    }

    @Test
    public void testInformDebtCallsSapInterfaceInformDebtSaleTypeCOOPERATIVE_SALE_WhenInformingTheDebtOfaSale() throws Exception {
        // @Given a retailer sale with SaleType = COOPERATIVE_SALE
        Sale sale = createSale(Sale.SaleTypeEnum.COOPERATIVE_SALE);

        // @When informing the debt
        lasvcInformDebtContinentalBankPYAdapter.informDebt(sale);

        // @Then The interface is called with saleType RETAILER_SALE
        verify(lasvcInformDebtContinentalBankPYService, times(0)).informDebt(anyString(), anyString(), anyString(), anyString(), anyString(), anyString(), any(BigDecimal.class), anyString(), anyString(), anyString(), any(Date.class));
        // @Then Log the interface response
        verify(interfaceLogService, times(0)).logInterface(any(InterfaceLog.class));
    }

    @Test
    public void testInformDebtCallsSapInterfaceInformDebtWithSaleTypeRETAILER_SALE_WhenThrowException() throws Exception {
        InfraException infraException = new InfraException("msg");
        when(lasvcInformDebtContinentalBankPYService.informDebt(anyString(), anyString(), anyString(), anyString(), anyString(), anyString(), any(BigDecimal.class), anyString(), anyString(), anyString(), any(Date.class))).thenThrow(infraException);

        // @Given a retailer sale with SaleType = RETAILER_SALE
        Sale sale = createSale(Sale.SaleTypeEnum.RETAILER_SALE);

        // @When informing the debt
        try {
            lasvcInformDebtContinentalBankPYAdapter.informDebt(sale);
            fail();
        } catch (InfraException ex) {
            assertThat(ex).isSameAs(infraException);
            // @Then The interface is called with saleType RETAILER_SALE
            verify(lasvcInformDebtContinentalBankPYService, times(1)).informDebt(anyString(), anyString(), anyString(), anyString(), anyString(), anyString(), any(BigDecimal.class), anyString(), anyString(), anyString(), any(Date.class));
            // @Then Log the interface response
            verify(interfaceLogService, times(1)).logInterface(any(InterfaceLog.class));
            verify(lasvcInformDebtContinentalBankPYService, times(1)).informDebt(anyString(), anyString(), anyString(), anyString(), anyString(), anyString(), any(BigDecimal.class), anyString(), anyString(), anyString(), any(Date.class));
        }
    }
    
    @Test
    public void testInformDebtCallsSapInterfaceInformDebtWithSaleTypeRETAILER_SALE_WhenThrowExceptionWithCause() throws Exception {
        InfraException infraException = new InfraException("msg", new Exception("causeMsg"));
        when(lasvcInformDebtContinentalBankPYService.informDebt(anyString(), anyString(), anyString(), anyString(), anyString(), anyString(), any(BigDecimal.class), anyString(), anyString(), anyString(), any(Date.class))).thenThrow(infraException);

        // @Given a retailer sale with SaleType = RETAILER_SALE
        Sale sale = createSale(Sale.SaleTypeEnum.RETAILER_SALE);

        // @When informing the debt
        try {
            lasvcInformDebtContinentalBankPYAdapter.informDebt(sale);
            fail();
        } catch (InfraException ex) {
            assertThat(ex).isSameAs(infraException);
            // @Then The interface is called with saleType RETAILER_SALE
            verify(lasvcInformDebtContinentalBankPYService, times(1)).informDebt(anyString(), anyString(), anyString(), anyString(), anyString(), anyString(), any(BigDecimal.class), anyString(), anyString(), anyString(), any(Date.class));
            // @Then Log the interface response
            verify(interfaceLogService, times(1)).logInterface(any(InterfaceLog.class));
            verify(lasvcInformDebtContinentalBankPYService, times(1)).informDebt(anyString(), anyString(), anyString(), anyString(), anyString(), anyString(), any(BigDecimal.class), anyString(), anyString(), anyString(), any(Date.class));
        }
    }

    @Test
    public void testInformDebtCallsSapInterfaceInformDebtWithSaleTypeRETAILER_SALE_WhenThrowExceptionWithCauseLength500() throws Exception {
        String causeMsg = "";
        for (int i=0; i<60; i++) {
            causeMsg += "1234567890";
        }
        InfraException infraException = new InfraException("msg", new Exception(causeMsg));
        when(lasvcInformDebtContinentalBankPYService.informDebt(anyString(), anyString(), anyString(), anyString(), anyString(), anyString(), any(BigDecimal.class), anyString(), anyString(), anyString(), any(Date.class))).thenThrow(infraException);

        // @Given a retailer sale with SaleType = RETAILER_SALE
        Sale sale = createSale(Sale.SaleTypeEnum.RETAILER_SALE);

        // @When informing the debt
        try {
            lasvcInformDebtContinentalBankPYAdapter.informDebt(sale);
            fail();
        } catch (InfraException ex) {
            assertThat(ex).isSameAs(infraException);
            // @Then The interface is called with saleType RETAILER_SALE
            verify(lasvcInformDebtContinentalBankPYService, times(1)).informDebt(anyString(), anyString(), anyString(), anyString(), anyString(), anyString(), any(BigDecimal.class), anyString(), anyString(), anyString(), any(Date.class));
            // @Then Log the interface response
            verify(interfaceLogService, times(1)).logInterface(any(InterfaceLog.class));
            verify(lasvcInformDebtContinentalBankPYService, times(1)).informDebt(anyString(), anyString(), anyString(), anyString(), anyString(), anyString(), any(BigDecimal.class), anyString(), anyString(), anyString(), any(Date.class));
        }
    }

    private Sale createSale(Sale.SaleTypeEnum saleType) {
        Grower grower = new Grower();
        Document document = new Document();
        document.setValue("11111111");
        grower.setDocument(document);
        grower.setId(1L);
        Customer customer = new Customer("Paul", new Document(), new Address(), "SAP");
        Sale sale = new Sale(customer, grower);
        sale.setSaleType(saleType);
        sale.setSaleOrderSAPId(3L);
        field("id").ofType(Long.class).in(sale).set(Long.valueOf(2L));
        return sale;
    }

}
