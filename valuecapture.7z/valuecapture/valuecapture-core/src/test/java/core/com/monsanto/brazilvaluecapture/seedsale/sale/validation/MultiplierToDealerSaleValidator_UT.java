package com.monsanto.brazilvaluecapture.seedsale.sale.validation;

import com.monsanto.brazilvaluecapture.core.foundation.validation.ValidationRule;
import com.monsanto.brazilvaluecapture.core.foundation.validation.ValidatorChain;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.Sale;
import com.monsanto.brazilvaluecapture.seedsale.sale.service.impl.MultiplierSaleValidator;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.List;

import static org.fest.assertions.Assertions.assertThat;
import static org.mockito.Mockito.atLeastOnce;
import static org.mockito.Mockito.verify;


@RunWith(MockitoJUnitRunner.class)
public class MultiplierToDealerSaleValidator_UT  {
    @Mock
    private MultiplierSaleValidator multiplierSaleValidator;
    @Mock
    private SaleItemsAllDueDatesMustBeTheSameValidationRule saleItemsAllDueDatesMustBeTheSameValidationRule;
    @Mock
    private SaleTotalCashAdvanceAvailableValidationRule saleTotalCashAdvanceAvailableValidationRule;
    @Mock
    private SaleItemNetRoyaltyValueLessThanCashAdvanceValidationRule saleItemNetRoyaltyValueLessThanCashAdvanceValidationRule;
    @Mock
    private ValidatorChain<Sale> validatorChain;

    @InjectMocks
    private MultiplierToDealerSaleValidator multiplierToDealerSaleValidator = new MultiplierToDealerSaleValidator(){
        @Override
        protected ValidatorChain<Sale> createValidatorChain() {
            return validatorChain;
        }
    };


    @Before
    public void setUp() throws Exception {
        multiplierToDealerSaleValidator.setMultiplierSaleValidator(new MultiplierSaleValidator());
    }

    @Test
    public void testCreateRulesAddsSaleItemNetRoyaltyValueLessThanCashAdvanceValidationRule_WhenCreatingRules(){
        multiplierToDealerSaleValidator.createRules();

        assertRuleIsAdded(saleItemNetRoyaltyValueLessThanCashAdvanceValidationRule);
    }

    @Test
    public void testCreateRulesAddsSaleTotalCashAdvanceAvailableValidationRule_WhenCreatingRules(){
        multiplierToDealerSaleValidator.createRules();

        assertRuleIsAdded(saleTotalCashAdvanceAvailableValidationRule);
    }

    @Test
    public void testCreateRulesAddsSaleItemsAllDueDatesMustBeTheSameValidationRule_WhenCreatingRules(){

        multiplierToDealerSaleValidator.createRules();

        assertRuleIsAdded(saleItemsAllDueDatesMustBeTheSameValidationRule);
    }

    //TODO: test validate method!!!

    private void assertRuleIsAdded(ValidationRule<Sale> saleItemNetRoyaltyValueLessThanCashAdvanceValidationRule1) {
        ArgumentCaptor<ValidationRule> ruleCaptor = ArgumentCaptor.forClass(ValidationRule.class);
        verify(validatorChain, atLeastOnce()).addRule(ruleCaptor.capture());
        final List<ValidationRule> allValues = ruleCaptor.getAllValues();
        assertThat(allValues).contains(saleItemNetRoyaltyValueLessThanCashAdvanceValidationRule1);
    }

}
