package com.monsanto.brazilvaluecapture.core.grower;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.io.IOException;
import java.io.InputStream;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import com.monsanto.brazilvaluecapture.core.foundation.util.Messages;
import junit.framework.Assert;

import org.apache.commons.io.IOUtils;
import org.hibernate.Query;
import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.monsanto.brazilvaluecapture.core.account.model.bean.Account;
import com.monsanto.brazilvaluecapture.core.account.model.bean.Account.AccountType;
import com.monsanto.brazilvaluecapture.core.account.model.bean.Account.OwnerType;
import com.monsanto.brazilvaluecapture.core.account.model.bean.CreditTransferRequest;
import com.monsanto.brazilvaluecapture.core.account.model.bean.CreditTransferRequestAmount;
import com.monsanto.brazilvaluecapture.core.base.CityTestData;
import com.monsanto.brazilvaluecapture.core.base.SystemTestFixture;
import com.monsanto.brazilvaluecapture.core.base.model.bean.BillingAddress;
import com.monsanto.brazilvaluecapture.core.base.model.bean.BusinessAddress;
import com.monsanto.brazilvaluecapture.core.base.model.bean.City;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Company;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Country;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Document;
import com.monsanto.brazilvaluecapture.core.base.model.bean.DocumentType;
import com.monsanto.brazilvaluecapture.core.base.model.bean.File;
import com.monsanto.brazilvaluecapture.core.base.model.bean.FileContent;
import com.monsanto.brazilvaluecapture.core.base.model.bean.OperationalYear;
import com.monsanto.brazilvaluecapture.core.base.model.bean.State;
import com.monsanto.brazilvaluecapture.core.base.service.BaseService;
import com.monsanto.brazilvaluecapture.core.base.service.GrowerCanNotBeDeletedException;
import com.monsanto.brazilvaluecapture.core.base.service.GrowerFromAnotherCompanyCanNotBeDeletedException;
import com.monsanto.brazilvaluecapture.core.commercialhierarchy.model.bean.CommercialHierarchyType;
import com.monsanto.brazilvaluecapture.core.commercialhierarchy.model.bean.ItsDistrict;
import com.monsanto.brazilvaluecapture.core.commercialhierarchy.model.bean.ItsRegion;
import com.monsanto.brazilvaluecapture.core.commercialhierarchy.model.bean.ItsUnity;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Customer;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Technology;
import com.monsanto.brazilvaluecapture.core.foundation.RandomTestData;
import com.monsanto.brazilvaluecapture.core.foundation.service.BusinessException;
import com.monsanto.brazilvaluecapture.core.foundation.test.AbstractServiceIntegrationTests;
import com.monsanto.brazilvaluecapture.core.foundation.test.dbunit.DbUnitHelper;
import com.monsanto.brazilvaluecapture.core.foundation.util.CalendarUtil;
import com.monsanto.brazilvaluecapture.core.foundation.util.ConstraintViolation;
import com.monsanto.brazilvaluecapture.core.grower.model.bean.Agreement;
import com.monsanto.brazilvaluecapture.core.grower.model.bean.Agreement.AgreementStatusEnum;
import com.monsanto.brazilvaluecapture.core.grower.model.bean.AgreementTemplate;
import com.monsanto.brazilvaluecapture.core.grower.model.bean.Grower;
import com.monsanto.brazilvaluecapture.core.grower.model.dao.impl.GrowerHierQueryFilter;
import com.monsanto.brazilvaluecapture.core.grower.service.GrowerConstraintViolationException;
import com.monsanto.brazilvaluecapture.core.grower.service.GrowerNotFoundException;
import com.monsanto.brazilvaluecapture.core.user.AccessControlTestFixture;
import com.monsanto.brazilvaluecapture.core.user.service.UserNotFoundException;
import com.monsanto.brazilvaluecapture.seedsale.billing.model.bean.CreditStatus;
import com.monsanto.brazilvaluecapture.seedsale.billing.model.bean.PaymentStatusGroup.PaymentStatusAll;
import com.monsanto.brazilvaluecapture.seedsale.harvest.model.bean.Harvest;
import com.monsanto.brazilvaluecapture.seedsale.product.model.bean.Brand;
import com.monsanto.brazilvaluecapture.seedsale.sale.SaleTestFixture;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.dao.AbstractSeedSaleReportFilter;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.dao.SeedSaleReportViewFilter;
import com.monsanto.brazilvaluecapture.seedsale.template.model.bean.SaleTemplate;

public class GrowerService_AT extends AbstractServiceIntegrationTests{
	
	@Autowired
	private BaseService baseService;
	
	private Grower completeGrower;
	private BusinessAddress businessAddress;
	private BillingAddress billingAddress;
	private Document theGrowerDocument;
	
    private Grower growerBR;

    private Grower growerUS;

    private Document growerUSDocument;

    private long usCountryId=900000077;

    private long brCountryId=900000022;
    
    private City novaAndradina;
    
	@Before
	public void init() {
		systemTestFixture = new SystemTestFixture(this);
		accessControlTestFixture = new AccessControlTestFixture(this, systemTestFixture);
		saleTestFixture = new SaleTestFixture(systemTestFixture);

		novaAndradina = CityTestData.createCityByState(systemTestFixture.saoPaulo);
		saveAndFlush(novaAndradina);
		
		businessAddress = PlayerTestData.createBusinessAddress(systemTestFixture.saoPaulo, novaAndradina, systemTestFixture.brazil);
		billingAddress = PlayerTestData.createBillingAddress(systemTestFixture.saoPaulo, novaAndradina, systemTestFixture.brazil); 
		theGrowerDocument = PlayerTestData.createDocument(systemTestFixture.documentCnpjEua, "57722426000176");
		
		completeGrower = PlayerTestData.createGrower(theGrowerDocument, billingAddress, businessAddress);
		saveAndFlush(completeGrower);       
	}
	
	@Before
    public void setUp() throws Exception {
        growerBR = new Grower();
        growerBR.setName("_CHICO BENTO_");
        Document validDocumentGrower = new Document();
        validDocumentGrower.setValue("99999999999999389");
        growerBR.setDocument(validDocumentGrower);
        Country countryByCountryId = new Country();
        countryByCountryId.setId(brCountryId);
        BillingAddress billingAddress = new BillingAddress();
        billingAddress.setCountry(countryByCountryId);
        growerBR.setBillingAddress(billingAddress);
        growerUS = new Grower();
        growerUSDocument = new Document();
        growerUSDocument.setValue("9999999999999999");
        growerUS.setDocument(growerUSDocument);

    }

	@Test
	public void testInsert() throws BusinessException {
		baseService.saveGrower(completeGrower);
		
		getSession().flush();
		
		Long id = completeGrower.getId();
		
		getSession().evict(completeGrower);
		
		Grower grower = (Grower) getSession().get(Grower.class, id);		
		
		Assert.assertNotNull(grower);
		Assert.assertNotNull(grower.getName());
		Assert.assertNotNull(grower.getPrimaryKey());
		Assert.assertNotNull(grower.getAlias());
		Assert.assertNotNull(grower.getEmail());
		
		Assert.assertNotNull(grower.getDocument());
		Assert.assertNotNull(grower.getDocument().getValue());
		Assert.assertNull(grower.getDocument().getPrimaryKey());
		Assert.assertNotNull(grower.getDocument().getDocumentType());
		Assert.assertNotNull(grower.getDocument().getDocumentType().getDescription());
		Assert.assertNotNull(grower.getDocument().getDocumentType().getPrimaryKey());
		Assert.assertNotNull(grower.getDocument().getDocumentType().getCountry());
		
		Assert.assertNotNull(grower.getBillingAddress());
		Assert.assertNotNull(grower.getBillingAddress().getComplement());
		Assert.assertNotNull(grower.getBillingAddress().getFax());
		Assert.assertNotNull(grower.getBillingAddress().getNeighborhood());
		Assert.assertNotNull(grower.getBillingAddress().getNumber());
		Assert.assertNotNull(grower.getBillingAddress().getStreet());
		Assert.assertNotNull(grower.getBillingAddress().getTelephone());
		Assert.assertNotNull(grower.getBillingAddress().getZipCode());
		
		Assert.assertNotNull(grower.getBillingAddress().getCity());
		Assert.assertNotNull(grower.getBillingAddress().getCity().getPrimaryKey());
		Assert.assertNotNull(grower.getBillingAddress().getCity().getDescription());
		Assert.assertNotNull(grower.getBillingAddress().getCity().getState());
		
		Assert.assertNotNull(grower.getBillingAddress().getState());
		Assert.assertNotNull(grower.getBillingAddress().getState().getPrimaryKey());
		Assert.assertNotNull(grower.getBillingAddress().getState().getDescription());
		Assert.assertNotNull(grower.getBillingAddress().getState().getCode());
		Assert.assertNotNull(grower.getBillingAddress().getState().getCountry());
		
		Assert.assertNotNull(grower.getBillingAddress().getCountry());
		Assert.assertNotNull(grower.getBillingAddress().getCountry().getPrimaryKey());
		Assert.assertNotNull(grower.getBillingAddress().getCountry().getDescription());
		Assert.assertNotNull(grower.getBillingAddress().getCountry().getCode());
		
		Assert.assertNotNull(grower.getBusinessAddress());
		Assert.assertNotNull(grower.getBusinessAddress().getComplement());
		Assert.assertNotNull(grower.getBusinessAddress().getFax());
		Assert.assertNotNull(grower.getBusinessAddress().getNeighborhood());
		Assert.assertNotNull(grower.getBusinessAddress().getNumber());
		Assert.assertNotNull(grower.getBusinessAddress().getStreet());
		Assert.assertNotNull(grower.getBusinessAddress().getTelephone());
		Assert.assertNotNull(grower.getBusinessAddress().getZipCode());
		
		Assert.assertNotNull(grower.getBusinessAddress().getCity());
		Assert.assertNotNull(grower.getBusinessAddress().getCity().getPrimaryKey());
		Assert.assertNotNull(grower.getBusinessAddress().getCity().getDescription());
		Assert.assertNotNull(grower.getBusinessAddress().getCity().getState());
		
		Assert.assertNotNull(grower.getBusinessAddress().getState());
		Assert.assertNotNull(grower.getBusinessAddress().getState().getPrimaryKey());
		Assert.assertNotNull(grower.getBusinessAddress().getState().getDescription());
		Assert.assertNotNull(grower.getBusinessAddress().getState().getCode());
		Assert.assertNotNull(grower.getBusinessAddress().getState().getCountry());
		
		Assert.assertNotNull(grower.getBusinessAddress().getCountry());
		Assert.assertNotNull(grower.getBusinessAddress().getCountry().getPrimaryKey());
		Assert.assertNotNull(grower.getBusinessAddress().getCountry().getDescription());
		Assert.assertNotNull(grower.getBusinessAddress().getCountry().getCode());
	}

	@Test(expected=BusinessException.class)
	public void testInsertException() throws BusinessException{
		baseService.saveGrower(completeGrower);
		
		Grower newGrower = PlayerTestData.createGrower(theGrowerDocument, billingAddress, businessAddress);
		
		baseService.saveGrower(newGrower);
		Assert.fail();
	}
	
	@Test
	public void when_i_register_a_grower_null_shouldBeReturned_ConstraintViolationException() {
		try {
			baseService.saveGrowerCSV(null);
			Assert.fail();
		} catch (GrowerConstraintViolationException e) {
			verifyConstraintMessage(e, "Grower is required.");
		}
	}
	
	@Test
	public void when_i_register_a_grower_withNullCountry_shouldBeReturnedConstraintViolationException() {
		completeGrower.getBillingAddress().setCountry(null);
		
		try {
			baseService.saveGrowerCSV(completeGrower);
			Assert.fail();
		} catch (GrowerConstraintViolationException e) {
			verifyConstraintMessage(e, "Country is required.");
		}
	}

	@Test
	public void when_i_register_a_grower_countryWithEmptyDescription_shouldBeReturnedConstraintViolationException() {
		completeGrower.getBillingAddress().setCountry(new Country(null, null));
		
		try {
			baseService.saveGrowerCSV(completeGrower);
			Assert.fail();
		} catch (GrowerConstraintViolationException e) {
			verifyConstraintMessage(e, "Country is required.");
		}
	}
	
	@Test
	public void when_i_register_a_growerWithInexistentCountry_shouldBeReturnedConstraintViolationException() {
		completeGrower.getBillingAddress().setCountry(new Country("404 not found", "NOT-FOUND"));
		
		try {
			baseService.saveGrowerCSV(completeGrower);
			Assert.fail();
		} catch (GrowerConstraintViolationException e) {
			verifyConstraintMessage(e, "Country not found.");
		}
		
	}
	
	@Test
	public void when_i_register_a_growerWithNullState_shouldBeReturnedConstraintViolationException() {
		completeGrower.getBillingAddress().setState(null);
		
		try {
			baseService.saveGrowerCSV(completeGrower);
			Assert.fail();
		} catch (GrowerConstraintViolationException e) {
			verifyConstraintMessage(e, "State is required.");
		}
	}
	
	@Test
	public void when_i_register_a_growerWithInexistentStateDescription_shouldBeReturnedConstraintViolationException() {
		completeGrower.getBillingAddress().setState(new State(systemTestFixture.brazil, null, "one does not simply find this state"));
		
		try {
			baseService.saveGrowerCSV(completeGrower);
			Assert.fail();
		} catch (GrowerConstraintViolationException e) {
			verifyConstraintMessage(e, "State not valid.");
		}
	}
	
	@Test
	public void when_i_register_a_growerWithInexistentStateCountry_shouldBeReturnedConstraintViolationException() {
		completeGrower.getBillingAddress().setState(new State(new Country("unknown country", null), null, "unknown state"));
		
		try {
			baseService.saveGrowerCSV(completeGrower);
			Assert.fail();
		} catch (GrowerConstraintViolationException e) {
			verifyConstraintMessage(e, "State not valid.");
		}
	}
	
	@Test
	public void when_i_register_a_growerWithNullCity_shouldBeReturnedConstraintViolationException() {
		completeGrower.getBillingAddress().setCity(null);
		
		try {
			baseService.saveGrowerCSV(completeGrower);
			Assert.fail();
		} catch (GrowerConstraintViolationException e) {
			verifyConstraintMessage(e, "City is required.");
		}
	}
	
	@Test
	public void when_i_register_a_growerWithEmptyCityDescription_shouldBeReturnedConstraintViolationException() {
		completeGrower.getBillingAddress().setCity(new City("  ", systemTestFixture.saoPaulo));
		
		try {
			baseService.saveGrowerCSV(completeGrower);
			Assert.fail();
		} catch (GrowerConstraintViolationException e) {
			verifyConstraintMessage(e, "City is required.");
		}
	}
	
	@Test
	public void when_i_register_a_growerWithInexistentCity_shouldBeReturnedConstraintViolationException() {
		completeGrower.getBillingAddress().setCity(new City("Ghost Town", systemTestFixture.saoPaulo));
		
		try {
			baseService.saveGrowerCSV(completeGrower);
			Assert.fail();
		} catch (GrowerConstraintViolationException e) {
			verifyConstraintMessage(e, "City not valid.");
		}
	}
	
	@Test
	public void when_i_register_a_grower_withNullName_shouldBeReturnedConstraintViolationException() {
		completeGrower.setName(null);
		
		try {
			baseService.saveGrowerCSV(completeGrower);
			Assert.fail();
		} catch (GrowerConstraintViolationException e) {
			verifyConstraintMessage(e, "Field is required.");
		}
	}
	
	@Test
	public void when_i_register_a_grower_withNameMoreThan200Characters_shouldBeReturnedConstraintViolationException() {
		completeGrower.setName(RandomTestData.createRandomString(201));
		
		try {
			baseService.saveGrowerCSV(completeGrower);
			Assert.fail();
		} catch (GrowerConstraintViolationException e) {
			verifyConstraintMessage(e, "Invalid Maxlength.");
		}		
	}
	
	@Test
	public void when_i_register_a_grower_withEmptyName_shouldBeReturnedConstraintViolationException() {
		completeGrower.setName("   ");
		
		try {
			baseService.saveGrowerCSV(completeGrower);
			Assert.fail();
		} catch (GrowerConstraintViolationException e) {
			verifyConstraintMessage(e, "Field is required.");
		}
		
	}
	
	@Test
	public void when_i_register_a_grower_withNullBillingStreet_shouldBeReturnedConstraintViolationException() {
		completeGrower.getBillingAddress().setStreet(null);
		
		try {
			baseService.saveGrowerCSV(completeGrower);
			Assert.fail();
		} catch (GrowerConstraintViolationException e) {
			verifyConstraintMessage(e, "Field is required.");
		}
	}
	
	@Test
	public void when_i_register_a_grower_withBillingStreetMoreThan200Characters_shouldBeReturnedConstraintViolationException() {
		completeGrower.getBillingAddress().setStreet(RandomTestData.createRandomString(201));
		
		try {
			baseService.saveGrowerCSV(completeGrower);
			Assert.fail();
		} catch (GrowerConstraintViolationException e) {
			verifyConstraintMessage(e, "Invalid Maxlength.");
		}		
	}
	
	@Test
	public void when_i_register_a_grower_withEmptyBillingStreet_shouldBeReturnedConstraintViolationException() {
		completeGrower.getBillingAddress().setStreet(" ");
		
		try {
			baseService.saveGrowerCSV(completeGrower);
			Assert.fail();
		} catch (GrowerConstraintViolationException e) {
			verifyConstraintMessage(e, "Field is required.");
		}
		
	}
	
	@Test
	public void when_i_register_a_grower_withNullBillingAddressNumber_shouldBeReturnedConstraintViolationException() {
		completeGrower.getBillingAddress().setNumber(null);
		
		try {
			baseService.saveGrowerCSV(completeGrower);
			Assert.fail();
		} catch (GrowerConstraintViolationException e) {
			verifyConstraintMessage(e, "Field is required.");
		}
	}
	
	@Test
	public void when_i_register_a_grower_withBillingAddressNumbertMoreThan10Characters_shouldBeReturnedConstraintViolationException() {
		completeGrower.getBillingAddress().setNumber(RandomTestData.createRandomString(11));
		
		try {
			baseService.saveGrowerCSV(completeGrower);
			Assert.fail();
		} catch (GrowerConstraintViolationException e) {
			verifyConstraintMessage(e, "Invalid Maxlength.");
		}		
	}
	
	@Test
	public void when_i_register_a_grower_withEmptyBillingAddressNumber_shouldBeReturnedConstraintViolationException() {
		completeGrower.getBillingAddress().setNumber("   ");
		
		try {
			baseService.saveGrowerCSV(completeGrower);
			Assert.fail();
		} catch (GrowerConstraintViolationException e) {
			verifyConstraintMessage(e, "Field is required.");
		}
	}
	
	
	@Test
	public void when_i_register_a_grower_withNullBillingNeighborhood_shouldBeReturnedConstraintViolationException() {
		completeGrower.getBillingAddress().setNeighborhood(null);
		
		try {
			baseService.saveGrowerCSV(completeGrower);
			Assert.fail();
		} catch (GrowerConstraintViolationException e) {
			verifyConstraintMessage(e, "Field is required.");
		}
	}
	
	@Test
	public void when_i_register_a_grower_withBillingAddressNeighborhoodMoreThan50Characters_shouldBeReturnedConstraintViolationException() {
		completeGrower.getBillingAddress().setNeighborhood(RandomTestData.createRandomString(51));
		
		try {
			baseService.saveGrowerCSV(completeGrower);
			Assert.fail();
		} catch (GrowerConstraintViolationException e) {
			verifyConstraintMessage(e, "Invalid Maxlength.");
		}		
	}
	
	@Test
	public void when_i_register_a_grower_withEmptyBillingAddressNeighborhood_shouldBeReturnedConstraintViolationException() {
		completeGrower.getBillingAddress().setNeighborhood("      ");
		
		try {
			baseService.saveGrowerCSV(completeGrower);
			Assert.fail();
		} catch (GrowerConstraintViolationException e) {
			verifyConstraintMessage(e, "Field is required.");
		}
	}
	
	@Test
	public void when_i_register_a_grower_withNullBillingPhone_shouldBeReturnedConstraintViolationException() {
		completeGrower.getBillingAddress().setTelephone(null);
		
		try {
			baseService.saveGrowerCSV(completeGrower);
			Assert.fail();
		} catch (GrowerConstraintViolationException e) {
			verifyConstraintMessage(e, "Field is required.");
		}
	}
	
	@Test
	public void when_i_register_a_grower_withBillingPhoneMoreThan50Characters_shouldBeReturnedConstraintViolationException() {
		completeGrower.getBillingAddress().setTelephone(RandomTestData.createRandomString(51));
		
		try {
			baseService.saveGrowerCSV(completeGrower);
			Assert.fail();
		} catch (GrowerConstraintViolationException e) {
			verifyConstraintMessage(e, "Invalid Maxlength.");
		}		
	}
	
	@Test
	public void when_i_register_a_grower_withEmptyBillingPhone_shouldBeReturnedConstraintViolationException() {
		completeGrower.getBillingAddress().setTelephone("          ");
		
		try {
			baseService.saveGrowerCSV(completeGrower);
			Assert.fail();
		} catch (GrowerConstraintViolationException e) {
			verifyConstraintMessage(e, "Field is required.");
		}
	}
	
	@Test
	public void when_i_register_a_grower_withNullBillingZipCode_shouldBeReturnedConstraintViolationException() {
		completeGrower.getBillingAddress().setZipCode(null);
		
		try {
			baseService.saveGrowerCSV(completeGrower);
			Assert.fail();
		} catch (GrowerConstraintViolationException e) {
			verifyConstraintMessage(e, "Field is required.");
		}
	}
	
	@Test
	public void when_i_register_a_grower_withBillingZipCodeMoreThan30Characters_shouldBeReturnedConstraintViolationException() {
		completeGrower.getBillingAddress().setZipCode(RandomTestData.createRandomString(31));
		
		try {
			baseService.saveGrowerCSV(completeGrower);
			Assert.fail();
		} catch (GrowerConstraintViolationException e) {
			verifyConstraintMessage(e, "Invalid Maxlength.");
		}		
	}
	
	@Test
	public void when_i_register_a_grower_withEmptyBillingZipCode_shouldBeReturnedConstraintViolationException() {
		completeGrower.getBillingAddress().setZipCode(" ");
		
		try {
			baseService.saveGrowerCSV(completeGrower);
			Assert.fail();
		} catch (GrowerConstraintViolationException e) {
			verifyConstraintMessage(e, "Field is required.");
		}
	}
	
	@Test
	public void when_i_register_a_grower_typeDocumentNull_shouldBeReturnedConstraintViolationException() {
		completeGrower.getDocument().setDocumentType(new DocumentType(null, null, null));
		
		try {
			baseService.saveGrowerCSV(completeGrower);
			Assert.fail();
		} catch (GrowerConstraintViolationException e) {
			verifyConstraintMessage(e, "Document type is required.");
		}
	}
	
	@Test
	public void when_i_register_a_grower_typeDocumentInvalid_shouldBeReturnedConstraintViolationException() {
		completeGrower.getBillingAddress().setCountry(new Country(systemTestFixture.eua.getDescription(), null));
		completeGrower.getDocument().setDocumentType(new DocumentType("CPF", null, null));
		try {
			baseService.saveGrowerCSV(completeGrower);
			Assert.fail();
		} catch (GrowerConstraintViolationException e) {
			verifyConstraintMessage(e, "Document type is invalid.");
		}
	}
	
	@Test
	public void when_i_register_a_grower_DocumentNumberNull_shouldBeReturnedConstraintViolationException() {
		completeGrower.getDocument().setValue(null);
		
		try {
			baseService.saveGrowerCSV(completeGrower);
			Assert.fail();
		} catch (GrowerConstraintViolationException e) {
			verifyConstraintMessage(e, "Grower document number is required.");
		}
	}
	
	@Test
	public void when_i_register_a_grower_DocumentNumberCNPJInvalid_shouldBeReturnedConstraintViolationException() {
		completeGrower.getDocument().setValue("1234567");
		
		try {
			baseService.saveGrowerCSV(completeGrower);
			Assert.fail();
		} catch (GrowerConstraintViolationException e) {
			verifyConstraintMessage(e, "Grower document number is invalid.");
		}
	}
	
	@Test
	public void when_i_register_a_grower_DocumentNumberCPFInvalid_shouldBeReturnedConstraintViolationException() {
		completeGrower.getDocument().setDocumentType(systemTestFixture.documentCpf);
		completeGrower.getDocument().setValue("1234567");
		
		try {
			baseService.saveGrowerCSV(completeGrower);
			Assert.fail();
		} catch (GrowerConstraintViolationException e) {
			verifyConstraintMessage(e, "Grower document number is invalid.");
		}
	}
	
	@Test
	public void when_i_register_a_grower_DocumentNumberCNPJ_Incorrect_shouldBeReturnedConstraintViolationException() {
		completeGrower.getDocument().setValue("11.111.111/1234-00");
		
		try {
			baseService.saveGrowerCSV(completeGrower);
			Assert.fail();
		} catch (GrowerConstraintViolationException e) {
			verifyConstraintMessage(e, "Grower document number is invalid.");
		}
	}
	
	@Test
	public void when_i_register_a_grower_DocumentNumberCPF_Incorrect_shouldBeReturnedConstraintViolationException() {
		completeGrower.getDocument().setDocumentType(systemTestFixture.documentCpf);
		completeGrower.getDocument().setValue("12.356.897-4");
		
		try {
			baseService.saveGrowerCSV(completeGrower);
			Assert.fail();
		} catch (GrowerConstraintViolationException e) {
			verifyConstraintMessage(e, "Grower document number is invalid.");
		}
	}
	
	private void verifyConstraintMessage(GrowerConstraintViolationException e, String expectedMessage) {
		List<ConstraintViolation> violations = e.getViolations();
		int count = 0;
		for (ConstraintViolation constraintViolation : violations) {
			if (constraintViolation.getMessage().equals(expectedMessage)){
				count++;
			}
		}
		if (!(count == 1)){
			Assert.fail();
		}
	}

	///Business Addresss - street, number, neghtboard, country, state, city, phone, zip
	@Test
	public void when_i_register_a_grower_withBusinessAddressZipCodeMoreThan30Characters_shouldBeReturnedConstraintViolationException() {
		completeGrower.getBusinessAddress().setZipCode(RandomTestData.createRandomString(51));
		
		try {
			baseService.saveGrowerCSV(completeGrower);
			Assert.fail();
		} catch (GrowerConstraintViolationException e) {
			verifyConstraintMessage(e, "Invalid Maxlength.");
		}		
	}
	
	@Test
	public void when_i_register_a_grower_withBusinessAddressPhoneMoreThan50Characters_shouldBeReturnedConstraintViolationException() {
		completeGrower.getBusinessAddress().setTelephone(RandomTestData.createRandomString(51));
		
		try {
			baseService.saveGrowerCSV(completeGrower);
			Assert.fail();
		} catch (GrowerConstraintViolationException e) {
			verifyConstraintMessage(e, "Invalid Maxlength.");
		}		
	}
	
	@Test
	public void when_i_register_a_grower_withBusinessAddressNeighborhoodMoreThan50Characters_shouldBeReturnedConstraintViolationException() {
		completeGrower.getBusinessAddress().setNeighborhood(RandomTestData.createRandomString(51));
		
		try {
			baseService.saveGrowerCSV(completeGrower);
			Assert.fail();
		} catch (GrowerConstraintViolationException e) {
			verifyConstraintMessage(e, "Invalid Maxlength.");
		}		
	}
	
	@Test
	public void when_i_register_a_grower_withBusinessStreetMoreThan200Characters_shouldBeReturnedConstraintViolationException() {
		completeGrower.getBusinessAddress().setStreet(RandomTestData.createRandomString(201));
		
		try {
			baseService.saveGrowerCSV(completeGrower);
			Assert.fail();
		} catch (GrowerConstraintViolationException e) {
			verifyConstraintMessage(e, "Invalid Maxlength.");
		}		
	}
	
	@Test
	public void when_i_register_a_grower_withBusinessAddressNumbertMoreThan10Characters_shouldBeReturnedConstraintViolationException() {
		completeGrower.getBusinessAddress().setNumber(RandomTestData.createRandomString(11));
		
		try {
			baseService.saveGrowerCSV(completeGrower);
			Assert.fail();
		} catch (GrowerConstraintViolationException e) {
			verifyConstraintMessage(e, "Invalid Maxlength.");
		}
	}
	
	@Test
	public void when_i_register_a_growerBusinessDataWithCountry_shouldValidateTheExistenceOfTheCountry() {
		completeGrower.getBusinessAddress().setCountry(new Country("this country don't exist", null));
		
		try {
			baseService.saveGrowerCSV(completeGrower);
			Assert.fail();
		} catch (GrowerConstraintViolationException e) {
			verifyConstraintMessage(e, "Country not found.");
		}
	}
	
	@Test
	public void when_i_register_a_growerBusinessDataWithInvalidState_shouldValidateTheExistenceOfTheState() {
		completeGrower.getBusinessAddress().setState(new State(systemTestFixture.brazil, null, "this state don't exist"));
		
		try {
			baseService.saveGrowerCSV(completeGrower);
			Assert.fail();
		} catch (GrowerConstraintViolationException e) {
			verifyConstraintMessage(e, "State not valid.");
		}
	}
	
	@Test
	public void when_i_register_a_growerBusinessDataWithInvalidCity_shouldValidateTheExistenceOfTheCity() {
		completeGrower.getBusinessAddress().setCity(new City("unexisting city", systemTestFixture.saoPaulo));
		
		try {
			baseService.saveGrowerCSV(completeGrower);
			Assert.fail();
		} catch (GrowerConstraintViolationException e) {
			verifyConstraintMessage(e, "City not valid.");
		}
	}
	
	@Test
	public void when_i_register_a_growerBillingCountryChanged_shouldValidateTheCanNotBeChanged() {
		
		completeGrower.getBillingAddress().setCountry(systemTestFixture.eua);
		State state = systemTestFixture.eua.getStates().iterator().next();
		completeGrower.getBillingAddress().setState(state);
		completeGrower.getBillingAddress().setCity(state.getCities().iterator().next());

		Grower grower = new Grower(completeGrower.getDocument(),
				completeGrower.getName(), completeGrower.getAlias(),
				completeGrower.getEmail(), completeGrower.getBillingAddress(),
				completeGrower.getBusinessAddress());
		
		grower.getDocument().setValue("57.722.426/0001-76");
		
		try {
			baseService.saveGrowerCSV(grower);
			Assert.fail();
		} catch (GrowerConstraintViolationException e) {
			verifyConstraintMessage(e, "Country can not be changed.");
		}
	}
	
	@Test
	public void when_i_update_a_grower_shouldReturnSuccess() {		
		Grower grower = new Grower(completeGrower.getDocument(),
				completeGrower.getName(), completeGrower.getAlias(),
				completeGrower.getEmail(), completeGrower.getBillingAddress(),
				completeGrower.getBusinessAddress());
		
		grower.getDocument().setValue("57.722.426/0001-76");
		
		try {
			baseService.saveGrowerCSV(grower);
		} catch (GrowerConstraintViolationException e) {
			Assert.fail("Should not return violations.");
		}
	}
	
	@Test
	public void when_i_update_a_grower_to_collaborator_shouldReturnSuccess() {		
		Grower grower = new Grower(completeGrower.getDocument(),
				completeGrower.getName(), completeGrower.getAlias(),
				completeGrower.getEmail(), completeGrower.getBillingAddress(),
				completeGrower.getBusinessAddress());
		
		grower.setIsCollaborator(true);
		
		try {
			baseService.saveGrowerCSV(grower);
		} catch (GrowerConstraintViolationException e) {
			Assert.fail("Should not return violations.");
		}
		
		Assert.assertTrue(grower.getIsCollaborator());
	}
	
	@Test
	public void when_i_update_a_grower_not_collaborator_shouldReturnSuccess() {		
		Grower grower = new Grower(completeGrower.getDocument(),
				completeGrower.getName(), completeGrower.getAlias(),
				completeGrower.getEmail(), completeGrower.getBillingAddress(),
				completeGrower.getBusinessAddress());
		
		grower.setIsCollaborator(false);
		
		try {
			baseService.saveGrowerCSV(grower);
		} catch (GrowerConstraintViolationException e) {
			Assert.fail("Should not return violations.");
		}
		
		Assert.assertFalse(grower.getIsCollaborator());
	}
	
	private void loadDataSet(){
	    String dataSetLocations="classpath:data/pod/credit/credit-dataset.xml";          
        DbUnitHelper.setup(dataSetLocations); 
	}
	
	@Test(expected=GrowerNotFoundException.class)
    public void when_i_search_ground_with_document_invalid_expected_GrowerNotFound() throws GrowerNotFoundException { 
	    loadDataSet();
        Document document = new Document();
        document.setValue("900000003979797979");
        baseService.selectGrowerDocumentByCountry(document, brCountryId);
    }
	
    @Test
    public void when_i_search_Grower_return_a_instance_of_grower() throws GrowerNotFoundException {
        loadDataSet();
        assertTrue(baseService.selectGrowerDocumentByCountry(growerBR.getDocument(), growerBR.getBillingAddress()
                .getCountry().getId()) instanceof Grower);
    }

    @Test
    public void  when_i_search_ground_by_document_valid_return_a_grower() throws GrowerNotFoundException {
        loadDataSet();
        Grower grower = baseService.selectGrowerDocumentByCountry(growerBR.getDocument(), growerBR.getBillingAddress()
                .getCountry().getId());
        assertEquals("Grower Found by Document", grower.getDocumentValue(), growerBR.getDocumentValue());
    }

    @Test
    public void when_i_search_a_grower_with_name_valid_return_a_grower() throws GrowerNotFoundException {
        loadDataSet();
        Grower grower = baseService.selectGrowerDocumentByCountry(growerBR.getDocument(), growerBR.getBillingAddress()
                .getCountry().getId());
        assertEquals("Grower Found by Name",growerBR.getName(), grower.getName());
    }

    @Test(expected = GrowerNotFoundException.class)
    public void when_i_search_a_grower_to_different_country_of_company_is_invalid() throws GrowerNotFoundException {
        loadDataSet();
        Country brazilCountryId = new Country();
        brazilCountryId.setId(brCountryId);
        BillingAddress billingAddress = new BillingAddress();
        billingAddress.setCountry(brazilCountryId);
        growerUS.setBillingAddress(billingAddress);
        baseService.selectGrowerDocumentByCountry(growerUSDocument, brazilCountryId.getId());
    }

    @Test
    public void when_i_search_grower_with_partial_document_its_found() throws GrowerNotFoundException {
        loadDataSet();
        Document document = new Document();
        String value = "999";
        document.setValue(value);
        List<Country> countries = new ArrayList<Country>();
        countries.add(growerBR.getBillingAddress().getCountry());
        List<Grower> listGrowers = baseService.selectGrowersByCriteria(document, growerBR.getName(), countries);
        for (Grower grower : listGrowers) {
            assertTrue(grower.getDocumentValue().startsWith(value));
        }
    }

    @Test
    public void when_i_search_grower_with_partial_name_its_found() throws GrowerNotFoundException {
        loadDataSet();
        Document document = new Document();
        String documentValue = new String();
        document.setValue(documentValue);
        String name = "HICO";
        List<Country> countries = new ArrayList<Country>();
        countries.add(growerBR.getBillingAddress().getCountry());
        List<Grower> growers = baseService.selectGrowersByCriteria(document, name, countries);
        for (Grower grower : growers) {
            assertTrue(grower.getName().contains(name));
        }
    }

    @Test
    public void when_i_search_grower_only_by_name_its_found() throws GrowerNotFoundException {
        loadDataSet();
        String nameGrower = null;
        List<Country> countries = new ArrayList<Country>();
        countries.add(growerBR.getBillingAddress().getCountry());
        List<Grower> listGrowersFound = baseService.selectGrowersByCriteria(growerBR.getDocument(), nameGrower, countries);
        for (Grower grower : listGrowersFound) {
            assertEquals("Grower found by name",grower.getDocumentValue(),growerBR.getDocumentValue());
        }
    }

    @Test
    public void when_i_search_grower_by_name_and_document_valid_its_found() throws GrowerNotFoundException {
        loadDataSet();
        List<Country> countries = new ArrayList<Country>();
        countries.add(growerBR.getBillingAddress().getCountry());
        List<Grower> listGrowers = baseService.selectGrowersByCriteria(growerBR.getDocument(), growerBR.getName(), countries);
        for (Grower grower : listGrowers) {
            assertEquals("Grower found by document and name",grower.getDocumentValue(), growerBR.getDocumentValue());
        }
    }

 
    @Test
    public void when_i_search_grower_by_document_and_name_partial_its_found() throws GrowerNotFoundException {
        loadDataSet();
        Document documentParcial = new Document();
        documentParcial.setValue("999");
        String nameGrowerParcial = "IC";
        
        Country c = (Country) getSession().get(Country.class, brCountryId);
        
        List<Country> countries = new ArrayList<Country>();
        countries.add(c);
        
        List<Grower> listGrowers = baseService.selectGrowersByCriteria(documentParcial, nameGrowerParcial, countries);
        for (Grower grower : listGrowers) {
            assertTrue(grower.getDocumentValue().startsWith(documentParcial.getValue()));
        }
    }

    @Test(expected = GrowerNotFoundException.class)
    public void when_i_search_grower_with_document_and_name_invalid_its_not_found() throws GrowerNotFoundException {
        loadDataSet();
        String nameGrower = "RANK";
        Document document = new Document();
        document.setValue("1234");
        
        Country c = (Country) getSession().get(Country.class, brCountryId);
        
        List<Country> countries = new ArrayList<Country>();
        countries.add(c);
        
        baseService.selectGrowersByCriteria(document, nameGrower, countries);
    }

    @Test(expected = GrowerNotFoundException.class)
    public void when_i_search_grower_with_description_not_exist_growerNotfoundException() throws GrowerNotFoundException {
        loadDataSet();
        Document document = new Document();
        document.setValue(new String());
        String nameGrower = "cit";
        
        Country c = (Country) getSession().get(Country.class, usCountryId);
        
        List<Country> countries = new ArrayList<Country>();
        countries.add(c);
        
        baseService.selectGrowersByCriteria(document, nameGrower, countries);
    }

    @Test(expected = GrowerNotFoundException.class)
    public void when_i_search_grower_with_document_not_exist_growetNotFoundException() throws GrowerNotFoundException {
        loadDataSet();
        String nameGrower = null;
        Document document = new Document();
        document.setValue("00000000001");
        
        Country c = (Country) getSession().get(Country.class, usCountryId);
        
        List<Country> countries = new ArrayList<Country>();
        countries.add(c);
        
        baseService.selectGrowersByCriteria(document, nameGrower, countries);
    }

    @Test(expected = IllegalArgumentException.class)
    public void when_i_search_grower_by_description_and_document_with_value_empty_its_notfound() throws GrowerNotFoundException {
        loadDataSet();
        String nameGrower = null;
        Document document = new Document();
        
        Country c = (Country) getSession().get(Country.class, usCountryId);
        
        List<Country> countries = new ArrayList<Country>();
        countries.add(c);
        
        baseService.selectGrowersByCriteria(document, nameGrower, countries);
    }

    @Test
    public void when_i_search_grower_by_name_and_document_and_onlyCooperative_valid_its_found() throws GrowerNotFoundException {
        loadDataSet();
        List<Country> countries = new ArrayList<Country>();
        Grower growerCooperative = (Grower) getSession().get(Grower.class, 900000066L);
		countries.add(growerCooperative.getBillingAddress().getCountry());
        List<Grower> listGrowers = baseService.selectGrowersByCriteria(growerCooperative.getDocument(), growerCooperative.getName(), countries, true);
        Assert.assertFalse("Should return result", listGrowers.isEmpty());
        for (Grower grower : listGrowers) {
        	Assert.assertTrue("Should be cooperative", grower.getIsCooperative());
        }
    }

    @Test
    public void given_a_document_of_grower_cooperative_when_search_growerByDocument_onlyCooperative_should_return_the_grower() throws GrowerNotFoundException {
        loadDataSet();
        String documentGrowerCooperative = "9999999999999979";
        
		Grower growerResult = baseService.getGrowerBy(documentGrowerCooperative, true);
        Assert.assertNotNull("Should return result", growerResult);
    	Assert.assertTrue("Should be cooperative", growerResult.getIsCooperative());
    }

    @Test(expected = GrowerNotFoundException.class)
    public void given_a_document_of_grower_not_cooperative_when_search_growerByDocument_onlyCooperative_should_not_return_the_grower() throws GrowerNotFoundException {
        loadDataSet();
        String documentGrowerCooperative = "9999999999999999";
        
		baseService.getGrowerBy(documentGrowerCooperative, true);
    }
    
    @Test(expected = GrowerCanNotBeDeletedException.class)
    public void given_a_grower_with_an_account_associated_when_i_try_to_delete_then_needs_to_throw_exception() throws GrowerCanNotBeDeletedException, GrowerFromAnotherCompanyCanNotBeDeletedException {
		Account account = new Account(AccountType.BLOCKED, OwnerType.GROWER,
				completeGrower.getId(), systemTestFixture.bt,
				systemTestFixture.operationalYearOf2012,
				systemTestFixture.soy);
		saveAndFlush(account);
		
		List<Company> companiesOfLoggedUser = new ArrayList<Company>();
		companiesOfLoggedUser.add(systemTestFixture.monsantoBr);
		
		baseService.deleteGrower(completeGrower, companiesOfLoggedUser);
    }    
    
    @Test(expected = GrowerFromAnotherCompanyCanNotBeDeletedException.class)
    public void given_a_grower_with_an_account_of_another_company_associated_when_i_try_to_delete_then_needs_to_throw_exception() throws GrowerCanNotBeDeletedException, GrowerFromAnotherCompanyCanNotBeDeletedException {
		Account account = new Account(AccountType.BLOCKED, OwnerType.GROWER,
				completeGrower.getId(), systemTestFixture.bt,
				systemTestFixture.operationalYearOf2012,
				systemTestFixture.soy);
		saveAndFlush(account);
		
		List<Company> companiesOfLoggedUser = new ArrayList<Company>();
		companiesOfLoggedUser.add(systemTestFixture.monsantoEua);
		
		baseService.deleteGrower(completeGrower, companiesOfLoggedUser);
    }
    
    @Test(expected = GrowerCanNotBeDeletedException.class)
    public void given_a_grower_with_a_credit_transfer_request_when_i_try_to_delete_then_needs_to_throw_exception() throws GrowerCanNotBeDeletedException, GrowerFromAnotherCompanyCanNotBeDeletedException {
    	saveAndFlush(saleTestFixture.chicoBentoSimple);
    	
    	CreditTransferRequest creditTransferRequest = new CreditTransferRequest(
				systemTestFixture.soy, systemTestFixture.bt,
				saleTestFixture.chicoBentoSimple, completeGrower,
				systemTestFixture.reason, "Motivo de transferencia", "JOHN");
		
    	CreditTransferRequestAmount creditTransferRequestAmount = new CreditTransferRequestAmount(BigDecimal.ONE, saleTestFixture.harvest2009SoyMonsanto.getOperationalYear());
		creditTransferRequest.addCreditTransferRequestAmount(creditTransferRequestAmount);
		
    	saveAndFlush(creditTransferRequest);
		
		List<Company> companiesOfLoggedUser = new ArrayList<Company>();
		companiesOfLoggedUser.add(systemTestFixture.monsantoBr);
		
		baseService.deleteGrower(completeGrower, companiesOfLoggedUser);
    }    
    
    
    @Test(expected = GrowerFromAnotherCompanyCanNotBeDeletedException.class)
    public void given_a_grower_with_a_credit_transfer_request_in_another_company_when_i_try_to_delete_then_needs_to_throw_exception() throws GrowerCanNotBeDeletedException, GrowerFromAnotherCompanyCanNotBeDeletedException {
    	saveAndFlush(saleTestFixture.chicoBentoSimple);
    	
    	CreditTransferRequest creditTransferRequest = new CreditTransferRequest(
				systemTestFixture.soy, systemTestFixture.bt,
				saleTestFixture.chicoBentoSimple, completeGrower,
				systemTestFixture.reason, "Motivo de transferencia", "JOHN");
		
    	CreditTransferRequestAmount creditTransferRequestAmount = new CreditTransferRequestAmount(BigDecimal.ONE, saleTestFixture.harvest2009SoyMonsanto.getOperationalYear());
		creditTransferRequest.addCreditTransferRequestAmount(creditTransferRequestAmount);
		
    	saveAndFlush(creditTransferRequest);
		
		List<Company> companiesOfLoggedUser = new ArrayList<Company>();
		companiesOfLoggedUser.add(systemTestFixture.monsantoEua);
		
		baseService.deleteGrower(completeGrower, companiesOfLoggedUser);
    } 
    
    
    @Test
    public void given_a_grower_when_delete_him_then_needs_to_be_deleted() throws GrowerCanNotBeDeletedException, GrowerFromAnotherCompanyCanNotBeDeletedException {
    	Long id = completeGrower.getId();
    	
    	Grower growerExpected = baseService.selectGrowerByID(id);
    	Assert.assertNotNull("Grower should exists.", growerExpected);
    	getSession().evict(growerExpected);
    	
		baseService.deleteGrower(completeGrower, null);
		Assert.assertNull("Grower should not exists.", baseService.selectGrowerByID(id));
    }
    
    @Test
    public void given_a_grower_with_agreement_when_delete_him_then_needs_to_be_deleted() throws GrowerCanNotBeDeletedException, IOException, GrowerFromAnotherCompanyCanNotBeDeletedException {
		AgreementTemplate agreementTemplate = new AgreementTemplate(systemTestFixture.soy, systemTestFixture.monsantoBr, systemTestFixture.intacta, "CONTENT", Boolean.TRUE);
		saveAndFlush(agreementTemplate);
    	
		Agreement agreement = new Agreement(1L, null, AgreementStatusEnum.APPROVED, agreementTemplate, completeGrower);
		File file = createFile("file");
		agreement.addFiles(file);
		saveAndFlush(agreement);
		
		completeGrower.addAgreement(agreement);
		saveAndFlush(completeGrower);
		getSession().evict(completeGrower);
		
		Long idAgreement = agreement.getId();
		
    	Long id = completeGrower.getId();
		baseService.deleteGrower(completeGrower, null);
		Assert.assertNull("Grower should not exists.", baseService.selectGrowerByID(id));
		
		Agreement baseAgreement = (Agreement) getSession().get(Agreement.class, idAgreement);
		Assert.assertNull("Agreement should not exists", baseAgreement);
    }
    
	private File createFile(String fileName) throws IOException {
		InputStream inputFile = getClass().getClassLoader().getResourceAsStream("fileContent/TermoCondicao.htm");
		byte[] bytes = IOUtils.toByteArray(inputFile);
		
		FileContent content = new FileContent();
		content.setValue(bytes);
		
		File file = new File( fileName + ".htm");
		file.setContent(content);
		file.setMimeType("mime type");
		return file;
	}
	
	@Test(expected=BusinessException.class)
    public void testInsertDocumentTypeInvalidException() throws BusinessException{        
	    Document newDocument = PlayerTestData.createDocument(systemTestFixture.documentInsEstadual, "123123123123123");
	    
        Grower newGrower = PlayerTestData.createGrower(newDocument, billingAddress, businessAddress);
        
        baseService.saveGrower(newGrower);
        Assert.fail();
    }
	

	@Test
	public void test_build_query_grower_hier_without_parameters() throws UserNotFoundException{
		AbstractSeedSaleReportFilter filter = SeedSaleReportViewFilter.getInstance(accessControlTestFixture.userAdminOfMonsantoBr,
				accessControlTestFixture.userAdminOfMonsantoBr.getContextCompany());
		GrowerHierQueryFilter queryFilter = GrowerHierQueryFilter.getInstance(filter);
		Query query = queryFilter.build(getSession());
				
		Assert.assertEquals(query.getQueryString().length(), queryFilter.getQuery().length());
		
		Assert.assertEquals(0, query.getNamedParameters().length);
	}
	
	
	@Test
	public void test_build_query_grower_hier_with_all_parameters() throws UserNotFoundException{
		Brand brand = new Brand();
		brand.setId(5L);
		
		State state = new State();
		state.setId(2L);
		
		SaleTemplate saleTemplate = new SaleTemplate();
		saleTemplate.setId(145L);
		
		Harvest harvest = new Harvest();
		harvest.setId(143L);
		
		Technology technology = new Technology();
		technology.setId(3L);
		
		OperationalYear operationalYear = new OperationalYear();
		operationalYear.setId(2L);
		
		Grower grower = new Grower();
		grower.setId(27L);
		
		Customer partner = new Customer();
		partner.setId(3933L);
		
		Customer headoffice = new Customer();
		headoffice.setId(3933L);
		
		String invoiceNumber = "10875858";
		
		CreditStatus creditStatus = CreditStatus.ON_PAYMENT;
		
		Date paymentDateStart = CalendarUtil.getDate(2013, 1, 10);
		Date paymentDateEnd = CalendarUtil.getDate(2013, 1, 20);
		
		
		List<PaymentStatusAll> statusList = new ArrayList<PaymentStatusAll>();
		statusList.addAll(Arrays.asList(PaymentStatusAll.FULLY_PAID));
		

		CommercialHierarchyType commercialHierarchyType = CommercialHierarchyType.DISTRIBUTOR;
		
		ItsUnity unit = new ItsUnity(1L);
		ItsRegion region = new ItsRegion(1L); 
		ItsDistrict district = new ItsDistrict(1L); 
		
		
		AbstractSeedSaleReportFilter filter = SeedSaleReportViewFilter.getInstance(accessControlTestFixture.userAdminOfMonsantoBr,
				accessControlTestFixture.userAdminOfMonsantoBr.getContextCompany())
				//.addCreationDateStart(CalendarUtil.getDate(2013, 0, 1))
				//.addCreationDateEnd(CalendarUtil.getDate(2013, 0, 31))
				.addBrand(brand)
				.addState(state)
				.addSaleTemplate(saleTemplate)
				.addHarvest(harvest)
				.addTecnhology(technology)
				.addOperationalYear(operationalYear)
				.addGrower(grower)
				.addCustomer(partner)
				.addMatrix(headoffice)
				.addInvoiceNumber(invoiceNumber)
				.addCreditStatus(creditStatus)
				.addPaymentPeriod(paymentDateStart, paymentDateEnd)
				.addPaymentStatus(statusList)
				.addHierarchyGrower(unit, region, district, commercialHierarchyType.name());				
		

		GrowerHierQueryFilter queryFilter = GrowerHierQueryFilter.getInstance(filter);
		Query query = queryFilter.build(getSession());
		

		Assert.assertEquals(query.getQueryString().length(), queryFilter.getQuery().length());
		
		for (int i = 0; i < query.getNamedParameters().length; i++) {
			System.out.println(query.getNamedParameters()[i]);
			
		}
		
		Assert.assertEquals(query.getNamedParameters().length, 16);
	}
	
	@Test
	public void when_search_growers_by_list_of_documents_should_return_growers_with_any_document_in_list() {
		theGrowerDocument = PlayerTestData.createDocument(systemTestFixture.documentCnpjEua, "11111111111111");
		Grower grower1 = PlayerTestData.createGrower(theGrowerDocument, billingAddress, businessAddress);
		saveAndFlush(grower1);
		
		theGrowerDocument = PlayerTestData.createDocument(systemTestFixture.documentCnpjEua, "22222222222222");
		Grower grower2 = PlayerTestData.createGrower(theGrowerDocument, billingAddress, businessAddress);
		saveAndFlush(grower2);
		
		theGrowerDocument = PlayerTestData.createDocument(systemTestFixture.documentCnpjEua, "33333333333333");
		businessAddress = PlayerTestData.createBusinessAddress(systemTestFixture.saoPaulo, novaAndradina, systemTestFixture.eua);
		billingAddress = PlayerTestData.createBillingAddress(systemTestFixture.saoPaulo, novaAndradina, systemTestFixture.eua);
		Grower grower3 = PlayerTestData.createGrower(theGrowerDocument, billingAddress, businessAddress);
		saveAndFlush(grower3);
		
		List<String> documents = new ArrayList<String>();
		documents.add("11111111111111");
		documents.add("22222222222222");
		documents.add("33333333333333");
		
		List<Grower> growers = baseService.selectGrowersBy(systemTestFixture.brazil, documents);
		
		Assert.assertTrue(growers.contains(grower1));
		Assert.assertTrue(growers.contains(grower2));
		Assert.assertFalse(growers.contains(grower3));
	}


    @Test
	public void testSaveGrowerWithStatusTrueThenTrowsBusinessExceptionIfDoesNotHaveApprovedDocs_LASVC() throws BusinessException{
		try{
            baseService.saveGrower_LASVC(completeGrower, false, "STEVE", null,null );
        }catch (BusinessException e){
            assertEquals(e.getMessage(), Messages.MESSAGE_ERROR_GROWER_WITH_DOC_PENDING_APPROVAL);
        }
	}

}