package com.monsanto.brazilvaluecapture.pod.rol.model.bean;

import org.junit.Test;

import static org.fest.assertions.Assertions.assertThat;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

public class RolStatus_UT {

    public static final String ROL_STATUS_CODE_1 = "rolStatusCode1";
    public static final String ROL_STATUS_CODE_2 = "rolStatusCode2";
    public static final String ROL_STATUS_BUNDLE_1 = "rolStatusBundle1";
    public static final String ROL_STATUS_BUNDLE_2 = "rolStatusBundle2";
    public static final short SHORT1 = (short) 1;
    public static final short SHORT2 = (short) 2;

    private RolStatus rolStatus;
    private RolStatus anotherRolStatus;

    @Test
   	public void testEquals_returnsTue_whenAreTheSame() {
        rolStatus = new RolStatus();
        assertThat(rolStatus.equals(rolStatus)).isTrue();
    }

    @Test
   	public void testEquals_returnsFalse_whenAreDifferentType() {
        RolStatus account = new RolStatus();
        assertThat(account.equals(null)).isFalse();
        assertThat(account.equals("string")).isFalse();
    }

    @Test
   	public void testEquals_returnsFalse_whenHaveDifferentAttributes() {
        // rolStatusCode
        rolStatus = new RolStatus(null, ROL_STATUS_CODE_1, null);
        anotherRolStatus = new RolStatus(null, ROL_STATUS_CODE_2, null);
        assertFalse(rolStatus.equals(anotherRolStatus));

        // rolStatusBundle
        rolStatus = new RolStatus(null, null, ROL_STATUS_BUNDLE_1);
        anotherRolStatus = new RolStatus(null, null, ROL_STATUS_BUNDLE_2);
        assertFalse(rolStatus.equals(anotherRolStatus));

        // rolStatusOrder
        rolStatus = new RolStatus(0, null, null, SHORT1);
        anotherRolStatus = new RolStatus(0, null, null, SHORT2);
        assertFalse(rolStatus.equals(anotherRolStatus));
    }

    @Test
   	public void testEquals_returnsTue_whenHaveSameAttributes() {
        // null
        rolStatus = new RolStatus();
        anotherRolStatus = new RolStatus();
        assertTrue(rolStatus.equals(anotherRolStatus));

        // rolStatusCode
        rolStatus = new RolStatus(null, ROL_STATUS_CODE_1, null);
        anotherRolStatus = new RolStatus(null, ROL_STATUS_CODE_1, null);
        assertTrue(rolStatus.equals(anotherRolStatus));

        // rolStatusBundle
        rolStatus = new RolStatus(null, null,ROL_STATUS_BUNDLE_1);
        anotherRolStatus = new RolStatus(null, null, ROL_STATUS_BUNDLE_1);
        assertTrue(rolStatus.equals(anotherRolStatus));

        // rolStatusOrder
        rolStatus = new RolStatus(0, null, null, SHORT1);
        anotherRolStatus = new RolStatus(0, null, null, SHORT1);
        assertTrue(rolStatus.equals(anotherRolStatus));
    }

}
