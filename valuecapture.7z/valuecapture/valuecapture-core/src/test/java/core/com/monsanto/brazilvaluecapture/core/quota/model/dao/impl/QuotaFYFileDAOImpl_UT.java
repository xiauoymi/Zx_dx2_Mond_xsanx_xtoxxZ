package com.monsanto.brazilvaluecapture.core.quota.model.dao.impl;

import com.monsanto.brazilvaluecapture.core.quota.model.bean.QuotaFYFile;
import org.hibernate.Criteria;
import org.hibernate.SessionFactory;
import org.hibernate.classic.Session;
import org.hibernate.criterion.Criterion;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.Date;
import java.util.List;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class QuotaFYFileDAOImpl_UT {

    private static final String COUNTRY_CODE = "PY";
    private static final String GERMO_SUPPLIER_DESCRIPTION = "Don Pepe";
    private static final String FILE_NAME = "file.csv";

    @Mock private SessionFactory sessionFactory;
    @InjectMocks private QuotaFYFileDAOImpl dao;
    @Mock private Session session;
    @Mock private QuotaFYFile quotaFYFile;
    @Mock Date startDate;
    @Mock Date endDate;
    @Mock Criteria criteria;
    @Mock List<QuotaFYFile> quotaFYFileList;

    @Before
    public void setUp() {
        when(sessionFactory.getCurrentSession()).thenReturn(session);
    }

    @Test
    public void findByShouldSucceed() {
        when(session.createCriteria(Matchers.<Class>any(), Matchers.<String>any())).thenReturn(criteria);
        when(criteria.createCriteria(Matchers.<String>any(), Matchers.<String>any())).thenReturn(criteria);
        when(criteria.add(Matchers.<Criterion>any())).thenReturn(criteria);
        when(criteria.list()).thenReturn(quotaFYFileList);

        List<QuotaFYFile> result = dao.findBy(startDate, endDate, GERMO_SUPPLIER_DESCRIPTION, FILE_NAME, COUNTRY_CODE);

        assertEquals(quotaFYFileList, result);
        verify(criteria, times(5)).add(any(Criterion.class));
    }

    @Test
    public void findByWithoutGermoSupplierDescriptionAndFileNameShouldSucceed() {
        when(session.createCriteria(Matchers.<Class>any(), Matchers.<String>any())).thenReturn(criteria);
        when(criteria.createCriteria(Matchers.<String>any(), Matchers.<String>any())).thenReturn(criteria);
        when(criteria.add(Matchers.<Criterion>any())).thenReturn(criteria);
        when(criteria.list()).thenReturn(quotaFYFileList);

        List<QuotaFYFile> result = dao.findBy(startDate, endDate, null, null, COUNTRY_CODE);

        assertEquals(quotaFYFileList, result);
        verify(criteria, times(3)).add(any(Criterion.class));
    }

    @Test
    public void saveShouldSucceed() {
        dao.save(quotaFYFile);

        verify(session).saveOrUpdate(quotaFYFile);
    }

}