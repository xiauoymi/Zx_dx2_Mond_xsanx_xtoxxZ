package com.monsanto.brazilvaluecapture.core.grower.report;

import junit.framework.Assert;

import org.junit.Test;

public class GrowerHierDTO_UT {

    /**
     * 
     */
    @Test
    public void sanity_test() {

        GrowerHierDTO dto = new GrowerHierDTO();
        dto.setGrowerCityCount(1);
        dto.setGrowerCityDescription("x");
        dto.setGrowerCityId(1L);
        dto.setGrowerDescription("xc");
        dto.setGrowerDistrictDesc("xde");
        dto.setGrowerDistrictId(3L);
        dto.setGrowerDocument("de");
        dto.setGrowerDocumentTypeDesc("se");
        dto.setGrowerId(4L);
        dto.setGrowerRegionDesc("er");
        dto.setGrowerRegionId(5L);
        dto.setGrowerStateCode("sp");
        dto.setGrowerUnityDesc("uio");
        dto.setGrowerUnityDesc("poi");
        dto.setGrowerUnityId(6L);

        dto.getGrowerCityCount();
        dto.getGrowerCityDescription();
        dto.getGrowerCityId();
        dto.getGrowerDescription();
        dto.getGrowerDistrictDesc();
        dto.getGrowerDistrictId();
        dto.getGrowerDocument();
        dto.getGrowerDocumentTypeDesc();
        dto.getGrowerId();
        dto.getGrowerRegionDesc();
        dto.getGrowerRegionId();
        dto.getGrowerStateCode();
        dto.getGrowerUnityDesc();
        dto.getGrowerUnityDesc();
        dto.getGrowerUnityId();

        dto.hashCode();
        Assert.assertFalse(dto.equals("NO"));
        Assert.assertFalse(dto.equals(new GrowerHierDTO()));
        Assert.assertTrue(dto.equals(dto));
        Assert.assertTrue(new GrowerHierDTO().equals(new GrowerHierDTO()));
        Assert.assertTrue(new GrowerHierDTO(1000L).equals(new GrowerHierDTO(1000L)));
        Assert.assertFalse(new GrowerHierDTO().equals(new GrowerHierDTO(4545L)));
        Assert.assertFalse(new GrowerHierDTO().equals(null));

    }

}
