package com.monsanto.brazilvaluecapture.pod.rol.model.service;

import com.monsanto.brazilvaluecapture.core.account.model.bean.Account;
import com.monsanto.brazilvaluecapture.core.base.TechnologyTestData;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.HeadOffice;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Technology;
import com.monsanto.brazilvaluecapture.utils.DateUtils;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

import static com.monsanto.brazilvaluecapture.core.base.OperationalYearTestData.createOperationalYear;
import static com.monsanto.brazilvaluecapture.core.base.OperationalYearTestData.createOperationalYearWithYear;
import static com.monsanto.brazilvaluecapture.core.base.TechnologyTestData.createTechnologyListWithElement;
import static com.monsanto.brazilvaluecapture.core.customer.CustomerTestData.createCustomerWithName;
import static com.monsanto.brazilvaluecapture.core.customer.model.bean.HeadOfficeTestData.createHeadOffice;
import static com.monsanto.brazilvaluecapture.pod.rol.model.bean.RolStatusTestData.createRolStatusWithCode;
import static org.fest.assertions.Assertions.assertThat;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

public class ReportOnLineFilter_UT {

    private ReportOnLineFilter reportOnLineFilter;
    private ReportOnLineFilter anotherReportOnLineFilter;

    @Test
   	public void testEquals_returnsTue_whenAreTheSame() {
        ReportOnLineFilter reportOnLineFilter = new ReportOnLineFilter();
        assertThat(reportOnLineFilter.equals(reportOnLineFilter)).isTrue();
    }

    @Test
   	public void testEquals_returnsFalse_whenAreDifferentType() {
        ReportOnLineFilter reportOnLineFilter = new ReportOnLineFilter();
        assertThat(reportOnLineFilter.equals(null)).isFalse();
        assertThat(reportOnLineFilter.equals("string")).isFalse();
    }

    @Test
   	public void testEquals_returnsFalse_whenHaveDifferentAttributes() {

        List<HeadOffice> headOfficeList =
                createHeadOfficeListWithElement(createHeadOffice(createCustomerWithName("Pepe")));
        reportOnLineFilter = new ReportOnLineFilter();
        reportOnLineFilter.setHeadOfficeList(headOfficeList);
        headOfficeList = createHeadOfficeListWithElement(createHeadOffice(createCustomerWithName("Jose")));
        anotherReportOnLineFilter = new ReportOnLineFilter();
        anotherReportOnLineFilter.setHeadOfficeList(headOfficeList);
        assertFalse(reportOnLineFilter.equals(anotherReportOnLineFilter));

        reportOnLineFilter = new ReportOnLineFilter();
        reportOnLineFilter.setInitDate(DateUtils.getFirstDateOfCurrentMonth());
        anotherReportOnLineFilter = new ReportOnLineFilter();
        anotherReportOnLineFilter.setInitDate(DateUtils.getFirstDateOfPreviousMonth());
        assertFalse(reportOnLineFilter.equals(anotherReportOnLineFilter));

        reportOnLineFilter = new ReportOnLineFilter();
        reportOnLineFilter.setEndDate(DateUtils.getFirstDateOfCurrentMonth());
        anotherReportOnLineFilter = new ReportOnLineFilter();
        anotherReportOnLineFilter.setEndDate(DateUtils.getFirstDateOfPreviousMonth());
        assertFalse(reportOnLineFilter.equals(anotherReportOnLineFilter));

        reportOnLineFilter = new ReportOnLineFilter();
        reportOnLineFilter.setRolStatus(createRolStatusWithCode("1"));
        anotherReportOnLineFilter = new ReportOnLineFilter();
        anotherReportOnLineFilter.setRolStatus(createRolStatusWithCode("2"));
        assertFalse(reportOnLineFilter.equals(anotherReportOnLineFilter));

        reportOnLineFilter = new ReportOnLineFilter();
        reportOnLineFilter.setOperationalYear(createOperationalYearWithYear("2013"));
        anotherReportOnLineFilter = new ReportOnLineFilter();
        anotherReportOnLineFilter.setOperationalYear(createOperationalYearWithYear("2014"));
        assertFalse(reportOnLineFilter.equals(anotherReportOnLineFilter));

        reportOnLineFilter = new ReportOnLineFilter();
        reportOnLineFilter.setOnlyRolUpdatedAfterBilled(true);
        anotherReportOnLineFilter = new ReportOnLineFilter();
        anotherReportOnLineFilter.setOnlyRolUpdatedAfterBilled(false);
        assertFalse(reportOnLineFilter.equals(anotherReportOnLineFilter));

        reportOnLineFilter = new ReportOnLineFilter();
        reportOnLineFilter.setOnlyEditedReport(true);
        anotherReportOnLineFilter = new ReportOnLineFilter();
        anotherReportOnLineFilter.setOnlyEditedReport(false);
        assertFalse(reportOnLineFilter.equals(anotherReportOnLineFilter));

        reportOnLineFilter = new ReportOnLineFilter();
        reportOnLineFilter.setShowBillingColumn(true);
        anotherReportOnLineFilter = new ReportOnLineFilter();
        anotherReportOnLineFilter.setShowBillingColumn(false);
        assertFalse(reportOnLineFilter.equals(anotherReportOnLineFilter));

        reportOnLineFilter = new ReportOnLineFilter();
        reportOnLineFilter.setOrderNumber("1");
        anotherReportOnLineFilter = new ReportOnLineFilter();
        anotherReportOnLineFilter.setOrderNumber("2");
        assertFalse(reportOnLineFilter.equals(anotherReportOnLineFilter));

        reportOnLineFilter = new ReportOnLineFilter();
        reportOnLineFilter.setUniqueOrderNumber("1");
        anotherReportOnLineFilter = new ReportOnLineFilter();
        anotherReportOnLineFilter.setUniqueOrderNumber("2");
        assertFalse(reportOnLineFilter.equals(anotherReportOnLineFilter));

        reportOnLineFilter = new ReportOnLineFilter();
        reportOnLineFilter.setDocumentNumber("1");
        anotherReportOnLineFilter = new ReportOnLineFilter();
        anotherReportOnLineFilter.setDocumentNumber("2");
        assertFalse(reportOnLineFilter.equals(anotherReportOnLineFilter));

        reportOnLineFilter = new ReportOnLineFilter();
        reportOnLineFilter.setInitRevenueDate(DateUtils.getFirstDateOfCurrentMonth());
        anotherReportOnLineFilter = new ReportOnLineFilter();
        anotherReportOnLineFilter.setInitRevenueDate(DateUtils.getFirstDateOfPreviousMonth());
        assertFalse(reportOnLineFilter.equals(anotherReportOnLineFilter));

        reportOnLineFilter = new ReportOnLineFilter();
        reportOnLineFilter.setEndRevenueDate(DateUtils.getFirstDateOfCurrentMonth());
        anotherReportOnLineFilter = new ReportOnLineFilter();
        anotherReportOnLineFilter.setEndRevenueDate(DateUtils.getFirstDateOfPreviousMonth());
        assertFalse(reportOnLineFilter.equals(anotherReportOnLineFilter));

        reportOnLineFilter = new ReportOnLineFilter();
        reportOnLineFilter.setBringOnlyRolIds(true);
        anotherReportOnLineFilter = new ReportOnLineFilter();
        anotherReportOnLineFilter.setBringOnlyRolIds(false);
        assertFalse(reportOnLineFilter.equals(anotherReportOnLineFilter));

        reportOnLineFilter = new ReportOnLineFilter();
        reportOnLineFilter.setBringUsedRolParamter(true);
        anotherReportOnLineFilter = new ReportOnLineFilter();
        anotherReportOnLineFilter.setBringUsedRolParamter(false);
        assertFalse(reportOnLineFilter.equals(anotherReportOnLineFilter));

        reportOnLineFilter = new ReportOnLineFilter();
        reportOnLineFilter.setTechnologies(createTechnologyListWithElement(TechnologyTestData.INTACTA));
        anotherReportOnLineFilter = new ReportOnLineFilter();
        anotherReportOnLineFilter.setTechnologies(createTechnologyListWithElement(TechnologyTestData.INTACTA_RR2));
        assertFalse(reportOnLineFilter.equals(anotherReportOnLineFilter));
    }

    private List<HeadOffice> createHeadOfficeListWithElement(HeadOffice headOffice) {
        List<HeadOffice> headOfficeList = new ArrayList<HeadOffice>();
        headOfficeList.add(headOffice);
        return headOfficeList;
    }

    @Test
   	public void testEquals_returnsTue_whenHaveSameAttributes() {
        // null
        reportOnLineFilter = new ReportOnLineFilter();
        anotherReportOnLineFilter = new ReportOnLineFilter();
        assertThat(reportOnLineFilter.equals(anotherReportOnLineFilter)).isTrue();

        List<HeadOffice> headOfficeList =
                createHeadOfficeListWithElement(createHeadOffice(createCustomerWithName("Pepe")));
        reportOnLineFilter = new ReportOnLineFilter();
        reportOnLineFilter.setHeadOfficeList(headOfficeList);
        headOfficeList = createHeadOfficeListWithElement(createHeadOffice(createCustomerWithName("Pepe")));
        anotherReportOnLineFilter = new ReportOnLineFilter();
        anotherReportOnLineFilter.setHeadOfficeList(headOfficeList);
        assertTrue(reportOnLineFilter.equals(anotherReportOnLineFilter));

        reportOnLineFilter = new ReportOnLineFilter();
        reportOnLineFilter.setInitDate(DateUtils.getFirstDateOfCurrentMonth());
        anotherReportOnLineFilter = new ReportOnLineFilter();
        anotherReportOnLineFilter.setInitDate(DateUtils.getFirstDateOfCurrentMonth());
        assertTrue(reportOnLineFilter.equals(anotherReportOnLineFilter));

        reportOnLineFilter = new ReportOnLineFilter();
        reportOnLineFilter.setEndDate(DateUtils.getFirstDateOfCurrentMonth());
        anotherReportOnLineFilter = new ReportOnLineFilter();
        anotherReportOnLineFilter.setEndDate(DateUtils.getFirstDateOfCurrentMonth());
        assertTrue(reportOnLineFilter.equals(anotherReportOnLineFilter));

        reportOnLineFilter = new ReportOnLineFilter();
        reportOnLineFilter.setRolStatus(createRolStatusWithCode("1"));
        anotherReportOnLineFilter = new ReportOnLineFilter();
        anotherReportOnLineFilter.setRolStatus(createRolStatusWithCode("1"));
        assertTrue(reportOnLineFilter.equals(anotherReportOnLineFilter));

        reportOnLineFilter = new ReportOnLineFilter();
        reportOnLineFilter.setOperationalYear(createOperationalYearWithYear("2013"));
        anotherReportOnLineFilter = new ReportOnLineFilter();
        anotherReportOnLineFilter.setOperationalYear(createOperationalYearWithYear("2013"));
        assertTrue(reportOnLineFilter.equals(anotherReportOnLineFilter));

        reportOnLineFilter = new ReportOnLineFilter();
        reportOnLineFilter.setOnlyRolUpdatedAfterBilled(true);
        anotherReportOnLineFilter = new ReportOnLineFilter();
        anotherReportOnLineFilter.setOnlyRolUpdatedAfterBilled(true);
        assertTrue(reportOnLineFilter.equals(anotherReportOnLineFilter));

        reportOnLineFilter = new ReportOnLineFilter();
        reportOnLineFilter.setOnlyEditedReport(true);
        anotherReportOnLineFilter = new ReportOnLineFilter();
        anotherReportOnLineFilter.setOnlyEditedReport(true);
        assertTrue(reportOnLineFilter.equals(anotherReportOnLineFilter));

        reportOnLineFilter = new ReportOnLineFilter();
        reportOnLineFilter.setShowBillingColumn(true);
        anotherReportOnLineFilter = new ReportOnLineFilter();
        anotherReportOnLineFilter.setShowBillingColumn(true);
        assertTrue(reportOnLineFilter.equals(anotherReportOnLineFilter));

        reportOnLineFilter = new ReportOnLineFilter();
        reportOnLineFilter.setOrderNumber("1");
        anotherReportOnLineFilter = new ReportOnLineFilter();
        anotherReportOnLineFilter.setOrderNumber("1");
        assertTrue(reportOnLineFilter.equals(anotherReportOnLineFilter));

        reportOnLineFilter = new ReportOnLineFilter();
        reportOnLineFilter.setUniqueOrderNumber("1");
        anotherReportOnLineFilter = new ReportOnLineFilter();
        anotherReportOnLineFilter.setUniqueOrderNumber("1");
        assertTrue(reportOnLineFilter.equals(anotherReportOnLineFilter));

        reportOnLineFilter = new ReportOnLineFilter();
        reportOnLineFilter.setDocumentNumber("1");
        anotherReportOnLineFilter = new ReportOnLineFilter();
        anotherReportOnLineFilter.setDocumentNumber("1");
        assertTrue(reportOnLineFilter.equals(anotherReportOnLineFilter));

        reportOnLineFilter = new ReportOnLineFilter();
        reportOnLineFilter.setInitRevenueDate(DateUtils.getFirstDateOfCurrentMonth());
        anotherReportOnLineFilter = new ReportOnLineFilter();
        anotherReportOnLineFilter.setInitRevenueDate(DateUtils.getFirstDateOfCurrentMonth());
        assertTrue(reportOnLineFilter.equals(anotherReportOnLineFilter));

        reportOnLineFilter = new ReportOnLineFilter();
        reportOnLineFilter.setEndRevenueDate(DateUtils.getFirstDateOfCurrentMonth());
        anotherReportOnLineFilter = new ReportOnLineFilter();
        anotherReportOnLineFilter.setEndRevenueDate(DateUtils.getFirstDateOfCurrentMonth());
        assertTrue(reportOnLineFilter.equals(anotherReportOnLineFilter));

        reportOnLineFilter = new ReportOnLineFilter();
        reportOnLineFilter.setBringOnlyRolIds(true);
        anotherReportOnLineFilter = new ReportOnLineFilter();
        anotherReportOnLineFilter.setBringOnlyRolIds(true);
        assertTrue(reportOnLineFilter.equals(anotherReportOnLineFilter));

        reportOnLineFilter = new ReportOnLineFilter();
        reportOnLineFilter.setBringUsedRolParamter(true);
        anotherReportOnLineFilter = new ReportOnLineFilter();
        anotherReportOnLineFilter.setBringUsedRolParamter(true);
        assertTrue(reportOnLineFilter.equals(anotherReportOnLineFilter));

        reportOnLineFilter = new ReportOnLineFilter();
        reportOnLineFilter.setTechnologies(createTechnologyListWithElement(TechnologyTestData.INTACTA));
        anotherReportOnLineFilter = new ReportOnLineFilter();
        anotherReportOnLineFilter.setTechnologies(createTechnologyListWithElement(TechnologyTestData.INTACTA));
        assertTrue(reportOnLineFilter.equals(anotherReportOnLineFilter));
    }

}
