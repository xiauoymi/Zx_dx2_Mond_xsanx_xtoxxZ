package com.monsanto.brazilvaluecapture.seedsale.product.model.dao.impl;

import com.monsanto.brazilvaluecapture.core.base.model.bean.Country;
import com.monsanto.brazilvaluecapture.core.base.model.bean.OperationalYear;
import com.monsanto.brazilvaluecapture.core.foundation.service.EntityAlreadyExistException;
import com.monsanto.brazilvaluecapture.seedsale.product.model.bean.Region;
import junit.framework.Assert;
import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.hibernate.classic.Session;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertSame;
import static org.mockito.Matchers.anyObject;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.when;

/**
 * Created by IntelliJ IDEA.
 * User: CGLLLO
 * Date: 20/09/13
 * Time: 11:48
 */
public class RegionProductivityDAOImpl_UT {

    @Mock
    private SessionFactory sessionFactory;
    @Mock
    private Session session;
    @Mock
    private Query query;
    @Mock
    private Criteria criteria;

    private RegionProductivityDAOImpl regionProductivityDAO;

    @Before
    public void setUp() throws Exception {
        MockitoAnnotations.initMocks(this);
        regionProductivityDAO = new RegionProductivityDAOImpl(sessionFactory);
        when(sessionFactory.getCurrentSession()).thenReturn(session);
        when(session.createQuery(anyString())).thenReturn(query);
        when(session.save(anyObject())).thenReturn(1L);
        when(query.setParameter(anyString(), anyObject())).thenReturn(query);
        when(session.createCriteria(Region.class)).thenReturn(criteria);
    }

    @Test
    public void when_getAll_should_return_all_regions() throws Exception {
        // @Given
        List<Region> expected = new ArrayList<Region>();
        when(criteria.list()).thenReturn(expected);

        // @When
        Object result = regionProductivityDAO.getAll();

        // @Should
        assertSame(expected, result);
    }

    @Test
    public void when_getRegionProductivityByCountryOperationalYear_should_return_selected_regions() throws Exception {
        // @Given
        List<Region> expected = new ArrayList<Region>();
        Country country = new Country();
        OperationalYear operationalYear = new OperationalYear();
        when(query.list()).thenReturn(expected);

        // @When
        Object result = regionProductivityDAO.getRegionProductivityByCountryOperationalYear(country, operationalYear);

        // @Should
        assertSame(expected, result);
    }

    @Test
    public void delete_region() {
        //@Given
        Region region = Mockito.mock(Region.class);

        //@When
        regionProductivityDAO.delete(region);
}

    @Test
    public void when_save_region_created_ok() throws EntityAlreadyExistException {
        //@Given
        Region region = Mockito.mock(Region.class);
        when(region.getOperationalYear()).thenReturn(Mockito.mock(OperationalYear.class));
        when(query.uniqueResult()).thenReturn(null);

        //@When
        Long regionCreated = regionProductivityDAO.save(region);

        //@Should
        Assert.assertNotNull(regionCreated);
    }

    @Test(expected = EntityAlreadyExistException.class)
    public void when_save_region_exception_already_exists() throws EntityAlreadyExistException {
        //@Given
        Region region = Mockito.mock(Region.class);
        when(region.getOperationalYear()).thenReturn(Mockito.mock(OperationalYear.class));
        when(query.uniqueResult()).thenReturn(Mockito.mock(Region.class));

        //@When
        regionProductivityDAO.save(region);
    }
}
