package com.monsanto.brazilvaluecapture.seedsale.warehouse.service.impl;

import com.monsanto.brazilvaluecapture.core.customer.model.bean.Customer;
import com.monsanto.brazilvaluecapture.pod.rol.model.bean.GermoSupplier;
import com.monsanto.brazilvaluecapture.seedsale.warehouse.model.bean.Warehouse;
import com.monsanto.brazilvaluecapture.seedsale.warehouse.model.dao.WarehouseDAO;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

import static org.fest.reflect.core.Reflection.field;
import static org.mockito.Matchers.anyListOf;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

/**
 * Created by RVOROZ on 9/8/2014.
 */

public class WarehouseServiceImpl_UT {

    private WarehouseServiceImpl warehouseService;

    @Mock
    private WarehouseDAO warehouseDAO;

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
        this.warehouseService = new WarehouseServiceImpl();
        field("warehouseDAO").ofType(WarehouseDAO.class).in(this.warehouseService).set(this.warehouseDAO);
    }

    @Test
    public void testSaveRelateCustomersToWarehouse() {
        Warehouse warehouse = getWarehouseMock();
        List<Customer> customers = getCustomerListMock();
        String user = "ADAMA_S";
        warehouseService.saveRelateCustomersToWarehouse(warehouse, customers, user);
        verify(warehouseDAO, times(1)).saveRelateCustomersToWarehouse(eq(warehouse), eq(customers), anyListOf(Customer.class), eq(user));
    }

    @Test
    public void testSaveRelatedGermosToWarehouse() {
        Warehouse warehouse = getWarehouseMock();
        List<GermoSupplier> germos = getGermoListMock();
        String user = "ADAMA_S";
        warehouseService.saveRelatedGermosToWarehouse(warehouse, germos, user);
        verify(warehouseDAO, times(1)).saveRelatedGermosToWarehouse(eq(warehouse), eq(germos), anyListOf(GermoSupplier.class), eq(user));
    }


    private Warehouse getWarehouseMock() {
        Warehouse warehouse = new Warehouse();
        warehouse.setId(1L);
        warehouse.setDescription("Warehouse");

        List<Customer> customers = new ArrayList<Customer>();
        Customer customer = new Customer();
        customer.setId(100L);
        customer.setName("Customer");
        customers.add(customer);
        warehouse.setCustomers(new HashSet<Customer>(customers));

        List<GermoSupplier> germoSuppliers = new ArrayList<GermoSupplier>();
        GermoSupplier germoSupplier = new GermoSupplier();
        germoSupplier.setId(100L);
        germoSupplier.setName("GermoSupplier");
        germoSuppliers.add(germoSupplier);
        warehouse.setGermoSuppliers(new HashSet<GermoSupplier>(germoSuppliers));
        return warehouse;
    }

    private List<Customer> getCustomerListMock() {

        List<Customer> data = new ArrayList<Customer>();

        for (int i = 0; i < 10; i++) {
            Customer row = new Customer();
            row.setId(new Long(i));
            row.setName("Customer " + i);
            data.add(row);
        }

        return data;
    }

    private List<GermoSupplier> getGermoListMock() {

        List<GermoSupplier> data = new ArrayList<GermoSupplier>();

        for (int i = 0; i < 10; i++) {
            GermoSupplier row = new GermoSupplier();
            row.setId(new Long(i));
            row.setName("Germo " + i);
            data.add(row);
        }

        return data;
    }

}
