package com.monsanto.brazilvaluecapture.seedsale.sale.validation;

import com.monsanto.brazilvaluecapture.core.foundation.util.ErrorCode;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.Sale;
import org.junit.Test;

import static org.fest.assertions.Assertions.assertThat;
import static org.junit.Assert.fail;

/**
 * Created with IntelliJ IDEA.
 * User: IFERN1
 * Date: 11/7/13
 * Time: 3:06 PM
 * To change this template use File | Settings | File Templates.
 */
public class MultiplierSaleTypeValidator_UT {
    @Test
    public void given_a_multiplier_seed_sale_validation_passes() {
        //@given
        MultiplierSaleTypeValidationRule multiplierSaleTypeValidator = new MultiplierSaleTypeValidationRule();
        Sale sale = new Sale();
        sale.setSaleType(Sale.SaleTypeEnum.MULTIPLIER_SEED_SALE);

        //@When
        try {
            multiplierSaleTypeValidator.validate(sale);
        } catch (Exception e) {
            fail("Should not fail");
        }
    }

    @Test
    public void given_a_non_multiplier_seed_sale_validation_fails() {
        //@given
        MultiplierSaleTypeValidationRule multiplierSaleTypeValidator = new MultiplierSaleTypeValidationRule();
        Sale sale = new Sale();
        sale.setSaleType(Sale.SaleTypeEnum.COOPERATIVE_SALE);

        //@When
        try {
            multiplierSaleTypeValidator.validate(sale);
            fail("Should throw ValidationException");
        } catch (Exception e) {
            assertThat(e).isInstanceOf(SaleValidationException.class).hasNoCause();
        }
    }

    @Test
    public void given_a_sale_with_no_sale_type_validation_fails() {
        //@given
        MultiplierSaleTypeValidationRule multiplierSaleTypeValidator = new MultiplierSaleTypeValidationRule();
        Sale sale = new Sale();
        sale.setSaleType(null);

        //@When
        try {
            multiplierSaleTypeValidator.validate(sale);
            fail("Should throw ValidationException");
        } catch (Exception e) {
            assertThat(e).isInstanceOf(SaleValidationException.class).hasNoCause();
            SaleValidationException sve = (SaleValidationException) e;
        }
    }
}
