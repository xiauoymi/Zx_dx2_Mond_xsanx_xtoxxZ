package com.monsanto.brazilvaluecapture.jobs.importfile.messaging.executor.impl;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.math.BigDecimal;
import java.util.List;
import java.util.Locale;
import java.util.ResourceBundle;

import org.apache.commons.lang3.StringUtils;
import org.junit.Assert;
import org.junit.Ignore;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.monsanto.brazilvaluecapture.core.base.SystemTestFixture;
import com.monsanto.brazilvaluecapture.core.base.model.bean.OperationalYear;
import com.monsanto.brazilvaluecapture.core.base.service.OperationalYearService;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Customer;
import com.monsanto.brazilvaluecapture.core.foundation.service.BusinessException;
import com.monsanto.brazilvaluecapture.core.foundation.test.AbstractServiceIntegrationTests;
import com.monsanto.brazilvaluecapture.core.importfile.model.bean.CsvImportFile;
import com.monsanto.brazilvaluecapture.core.io.ProcessorConfig;
import com.monsanto.brazilvaluecapture.core.io.ProcessorConfig.ProcessorConfigProperties;
import com.monsanto.brazilvaluecapture.core.user.AccessControlTestFixture;
import com.monsanto.brazilvaluecapture.core.user.model.bean.UserDecorator;
import com.monsanto.brazilvaluecapture.jobs.importfile.messaging.bean.FileImportDefinition;
import com.monsanto.brazilvaluecapture.jobs.importfile.messaging.bean.FileImportInfo;
import com.monsanto.brazilvaluecapture.jobs.importfile.messaging.bean.FileImportOperation;
import com.monsanto.brazilvaluecapture.jobs.importfile.messaging.executor.ImportFileCallbackException;
import com.monsanto.brazilvaluecapture.seedsale.product.model.bean.Product;
import com.monsanto.brazilvaluecapture.seedsale.quota.model.bean.CsvQuotaImportLine;
import com.monsanto.brazilvaluecapture.seedsale.quota.model.bean.CsvQuotaImportResult;
import com.monsanto.brazilvaluecapture.seedsale.quota.model.bean.MDQuotaImportLine;
import com.monsanto.brazilvaluecapture.seedsale.quota.model.bean.Quota;
import com.monsanto.brazilvaluecapture.seedsale.quota.model.bean.QuotaImportedLine;
import com.monsanto.brazilvaluecapture.seedsale.quota.model.bean.QuotaImportedLine.QuotaImportedLineType;
import com.monsanto.brazilvaluecapture.seedsale.quota.model.bean.QuotaType;
import com.monsanto.brazilvaluecapture.seedsale.quota.service.QuotaService;
import com.monsanto.brazilvaluecapture.seedsale.quota.service.parser.importation.QuotaImportProcessor;
import com.monsanto.brazilvaluecapture.seedsale.sale.SaleTestFixture;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.ImportFileStatus;

public class CsvQuotaImportFileCallback_AT extends
		AbstractServiceIntegrationTests {

	    @Autowired
        @Qualifier("csvQuotaImportFileCallback")
	    private CsvQuotaImportFileCallback csvQuotaImportFileCallback;

        @Autowired
        @Qualifier("MDQuotaImportFileCallback")
        private MDQuotaImportFileCallback mdQuotaImportFileCallback;

	    @Autowired
	    private QuotaService quotaService;

	    private Locale localeBR = new Locale("pt", "BR");

	    private ResourceBundle resourceBundle = ResourceBundle.getBundle("bundle/bundle");
	    
//	    really neccessary?
//		private static SimpleSmtpServer serverSMTP;
	    
    	@Autowired
    	private QuotaImportProcessor quotaImportProcessor;
        
    	private ProcessorConfig processorConfig = new ProcessorConfig();

        @Autowired
        private OperationalYearService operationalYearService;
//
//        @BeforeClass
//		public static void start() {
//		
//			 serverSMTP = SimpleSmtpServer.start(getEnviromentSpecificSmtpPort());	 
//		}
//		
//		@AfterClass
//		public static void stop() {
//			if ( serverSMTP != null){
//				serverSMTP.stop();
//			}
//		}
        
        
		@Test
		public void given_valid_line_when_read_lines_should_save_one_valid_line() throws IOException, BusinessException {
            initFixtures();
            UserDecorator decorator = initUser();
            initProcessorConfig(decorator);
            
            CsvImportFile file = createOneValidLineAndLoad();
            
            List<CsvQuotaImportLine> lines = quotaService.selectCsvImportLinesByFile(file);
            Assert.assertEquals(1,lines.size());
            
            Assert.assertEquals(lines.size(), file.getTotalEntities().longValue());
            
            List<CsvQuotaImportResult> results = quotaService.selectCsvQuotaImportResultByFile(file);
            Assert.assertEquals(0, results.size());
            
            Assert.assertTrue(file.getValidFile());
		}
        
		@Test
		public void given_line_with_too_large_field_should_store_line() throws IOException, BusinessException {
            initFixtures();
            UserDecorator decorator = initUser();
            initProcessorConfig(decorator);
            
            StringBuffer csv = createInvalidTooLargeLineForInputStream(null, saleTestFixture.customer.getDocumentValue(), saleTestFixture.customer.getStateRegistration(), saleTestFixture.customer.getCustomerSAPCode(), 
					saleTestFixture.productIntactaWithQuota.getId(), "C", "500");
            CsvImportFile file = quotaImportProcessor.readLines(new ByteArrayInputStream(csv.toString().getBytes()),processorConfig);
            
            List<CsvQuotaImportLine> lines = quotaService.selectCsvImportLinesByFile(file);
            Assert.assertEquals(0,lines.size());
            
            Assert.assertEquals(1, file.getTotalEntities().longValue());
            
            List<CsvQuotaImportResult> results = quotaService.selectCsvQuotaImportResultByFile(file);
            Assert.assertEquals(1, results.size());
            
            Assert.assertFalse(file.getValidFile());
		}
		
		@Test
		public void given_invalid_layout_when_read_lines_should_have_one_result() throws IOException, BusinessException {
			initFixtures();
            UserDecorator decorator = initUser();
            initProcessorConfig(decorator);
            
            StringBuffer csv = createInvalidLayoutLineForInputStream(null);
            CsvImportFile file = quotaImportProcessor.readLines(new ByteArrayInputStream(csv.toString().getBytes()),processorConfig);
            Assert.assertNotNull(file);
            
            List<CsvQuotaImportLine> lines = quotaService.selectCsvImportLinesByFile(file);
            Assert.assertEquals(0,lines.size());
            
            List<CsvQuotaImportResult> results = quotaService.selectCsvQuotaImportResultByFile(file);
            Assert.assertEquals(1, results.size());
            
            Assert.assertFalse(file.getValidFile());
		}
		
		@Test
		public void given_invalid_line_when_read_lines_then_import_should_have_one_result() throws IOException, BusinessException { 
			initFixtures();
            UserDecorator decorator = initUser();
            initProcessorConfig(decorator);
            
	        StringBuffer csv = createInvalidDocumentTypeLineForInputStream(null, saleTestFixture.customer.getDocumentValue(), null, null, saleTestFixture.productIntactaWithQuota.getId(), "C", "500");
            CsvImportFile file = quotaImportProcessor.readLines(new ByteArrayInputStream(csv.toString().getBytes()),processorConfig);
            Assert.assertNotNull(file);
            
            List<CsvQuotaImportLine> lines = quotaService.selectCsvImportLinesByFile(file);
            Assert.assertEquals(1,lines.size());
            
            List<CsvQuotaImportResult> results = quotaService.selectCsvQuotaImportResultByFile(file);
            Assert.assertEquals(0, results.size());
            
            csvQuotaImportFileCallback.importFileCallback(new FileImportInfo(file, decorator,
                    FileImportDefinition.CSV_QUOTA, FileImportOperation.IMPORT, localeBR, "bundle"));
            
            lines = quotaService.selectCsvImportLinesByFile(file);
            Assert.assertEquals(0,lines.size());
            
            results = quotaService.selectCsvQuotaImportResultByFile(file);
            Assert.assertEquals(1, results.size());
            
            Assert.assertFalse(file.getValidFile());
		}
		
		@Test
		@Ignore
		public void given_one_invalid_layout_one_invalid_line_one_valid_line_should_have_one_result_before_import_two_after_one_success() throws IOException, BusinessException {
			initFixtures();
            UserDecorator decorator = initUser();
            initProcessorConfig(decorator);
            
            StringBuffer csv = createInvalidLayoutLineForInputStream(null);
	        createInvalidDocumentTypeLineForInputStream(csv, saleTestFixture.customer.getDocumentValue(), null, null, saleTestFixture.productIntactaWithQuota.getId(), "C", "500");
//			createLineForInputStream(csv, saleTestFixture.customer.getDocumentValue(), saleTestFixture.productIntactaWithQuota.getId(), "C", "500", saleTestFixture.customer.getStateRegistration(), saleTestFixture.customer.getCustomerSAPCode());
			createLineForInputStream(csv, saleTestFixture.customer.getDocumentValue(), saleTestFixture.customer.getStateRegistration(), saleTestFixture.customer.getCustomerSAPCode(), 
					saleTestFixture.productIntactaWithQuota.getId(), "C", "500");
            CsvImportFile file = quotaImportProcessor.readLines(new ByteArrayInputStream(csv.toString().getBytes()),processorConfig);
			
            List<CsvQuotaImportLine> lines = quotaService.selectCsvImportLinesByFile(file);
            Assert.assertEquals(2,lines.size());
            
            List<CsvQuotaImportResult> results = quotaService.selectCsvQuotaImportResultByFile(file);
            Assert.assertEquals(1, results.size());
            
            csvQuotaImportFileCallback.importFileCallback(new FileImportInfo(file, decorator,
                    FileImportDefinition.CSV_QUOTA, FileImportOperation.IMPORT, localeBR, "bundle"));
            
            lines = quotaService.selectCsvImportLinesByFile(file);
            Assert.assertEquals(1,lines.size());
            
            results = quotaService.selectCsvQuotaImportResultByFile(file);
            Assert.assertEquals(2, results.size());
            
            Assert.assertTrue(file.getValidFile());
            
	        file.setFileStatus(ImportFileStatus.AWAITING_PROCESSING);
            csvQuotaImportFileCallback.importFileCallback(new FileImportInfo(file, decorator,
                    FileImportDefinition.CSV_QUOTA, FileImportOperation.PROCEED, localeBR, "bundle"));
            
            lines = quotaService.selectCsvImportLinesByFile(file);
            Assert.assertEquals(1,lines.size());

            results = quotaService.selectCsvQuotaImportResultByFile(file);
            Assert.assertEquals(2, results.size());
            
	        Quota quota = quotaService.fetchOrCreateQuota(saleTestFixture.customer, saleTestFixture.productIntactaWithQuota, systemTestFixture.operationalYearOf2012, QuotaType.AVAILABLE, null, null, null);
	        Assert.assertEquals(quota.getBalance().compareTo(BigDecimal.valueOf(500)), 0);
		}

        @Test
        public void given_valid_quota_lines_persisted_should_get_to_end() throws ImportFileCallbackException {
            initFixtures();
            UserDecorator decorator = initUser();
            initProcessorConfig(decorator);

            if(assumptionTest.isEnvironmentWithSQLANSI()) {
                createAndPersistImportedLines();
                CsvImportFile file = quotaImportProcessor.readImportedLines(processorConfig);
                Assert.assertNotNull("File should not be null", file);
                List<MDQuotaImportLine> mdQuotaImportLines = quotaService.selectMDImportLinesByFile(file);
                Assert.assertEquals(3, mdQuotaImportLines.size());

                mdQuotaImportFileCallback.importFileCallback(new FileImportInfo(file, decorator,
                    FileImportDefinition.CSV_MD_QUOTA, FileImportOperation.IMPORT, localeBR, "bundle"));

                mdQuotaImportLines = quotaService.selectMDImportLinesByFile(file);
                Assert.assertEquals(3, mdQuotaImportLines.size());

                file.setFileStatus(ImportFileStatus.AWAITING_PROCESSING);
                mdQuotaImportFileCallback.importFileCallback(new FileImportInfo(file, decorator,
                        FileImportDefinition.CSV_MD_QUOTA, FileImportOperation.PROCEED, localeBR, "bundle"));

                OperationalYear year = operationalYearService.selectAllOrderDesc().iterator().next();

                Quota quota = quotaService.fetchOrCreateQuota(saleTestFixture.customer, saleTestFixture.productIntactaWithQuota, year, QuotaType.AVAILABLE, null, null, null);
                Assert.assertEquals(quota.getBalance().compareTo(BigDecimal.valueOf(2500)), 0);
            }
        }
        
		@Test
		public void given_valid_quota_lines_persisted_then_when_transfer_should_have_three_lines() {
			initFixtures();
            UserDecorator decorator = initUser();
            initProcessorConfig(decorator);

            if(assumptionTest.isEnvironmentWithSQLANSI()) {
                 createAndPersistImportedLines();

                 Assert.assertEquals(3, getSession().createCriteria(QuotaImportedLine.class).list().size());

                 CsvImportFile file = quotaImportProcessor.readImportedLines(processorConfig);

                 List<MDQuotaImportLine> lines = quotaService.selectMDImportLinesByFile(file);

                 Assert.assertEquals(3, lines.size());
            }
		}

		private CsvImportFile createOneValidLineAndLoad() throws IOException,
				BusinessException {
			StringBuffer csv = createLineForInputStream(saleTestFixture.customer.getDocumentValue(), saleTestFixture.productIntactaWithQuota.getId(), "C", "500", saleTestFixture.customer.getStateRegistration(), saleTestFixture.customer.getCustomerSAPCode());
            CsvImportFile file = quotaImportProcessor.readLines(new ByteArrayInputStream(csv.toString().getBytes()), processorConfig);
            Assert.assertNotNull(file);
			return file;
		}
        
		@Test
		public void given_valid_line_when_read_lines_then_import_should_have_one_valid_line() throws IOException, BusinessException {
            initFixtures();
            UserDecorator decorator = initUser();
            initProcessorConfig(decorator);
			
            CsvImportFile file = createOneValidLineAndLoad();
            
            List<CsvQuotaImportLine> lines = quotaService.selectCsvImportLinesByFile(file);
            Assert.assertEquals(1, lines.size());
            Assert.assertEquals(lines.size(), file.getTotalEntities().longValue());
            Long id = file.getId();
            getSession().evict(file);
            file=null;
            file=(CsvImportFile) getSession().get(CsvImportFile.class, id);
            
            csvQuotaImportFileCallback.importFileCallback(new FileImportInfo(file, decorator,
                    FileImportDefinition.CSV_QUOTA, FileImportOperation.IMPORT, localeBR, "bundle"));
            getSession().evict(file);
            file=null;
            
            file=(CsvImportFile) getSession().get(CsvImportFile.class, id);
            
            lines = quotaService.selectCsvImportLinesByFile(file);
            Assert.assertEquals(1,lines.size());
            
            Assert.assertEquals(lines.size(), file.getTotalEntities().longValue());
            
            List<CsvQuotaImportResult> results = quotaService.selectCsvQuotaImportResultByFile(file);
            Assert.assertEquals(0, results.size());
            
            Assert.assertTrue(file.getValidFile());
		}
		
		
		@Test
		public void given_valid_line_when_import_then_proceed_should_have_one_valid_line() throws IOException, BusinessException {
            initFixtures();
            UserDecorator decorator = initUser();
            initProcessorConfig(decorator);
            
            CsvImportFile file = createOneValidLineAndLoad();
            Long id = file.getId();
            
            csvQuotaImportFileCallback.importFileCallback(new FileImportInfo(file, decorator,
                    FileImportDefinition.CSV_QUOTA, FileImportOperation.IMPORT, localeBR, "bundle"));
            
	        file.setFileStatus(ImportFileStatus.AWAITING_PROCESSING);
            csvQuotaImportFileCallback.importFileCallback(new FileImportInfo(file, decorator,
                    FileImportDefinition.CSV_QUOTA, FileImportOperation.PROCEED, localeBR, "bundle"));
            getSession().evict(file);
            file=null;
            file=(CsvImportFile) getSession().get(CsvImportFile.class, id);
            
            List<CsvQuotaImportLine> lines = quotaService.selectCsvImportLinesByFile(file);
            Assert.assertEquals(1,lines.size());
            
            Assert.assertEquals(lines.size(), file.getTotalEntities().longValue());
            
            List<CsvQuotaImportResult> results = quotaService.selectCsvQuotaImportResultByFile(file);
            Assert.assertEquals(0, results.size());
	        Quota quota = quotaService.fetchOrCreateQuota(saleTestFixture.customer, saleTestFixture.productIntactaWithQuota, systemTestFixture.operationalYearOf2008, QuotaType.AVAILABLE, null, null, null);
	        Assert.assertEquals(quota.getBalance().compareTo(BigDecimal.valueOf(500)), 0);
		}
        
		private UserDecorator initUser() {
			UserDecorator decorator = new UserDecorator(accessControlTestFixture.itsSuperUser, accessControlTestFixture.itsSuperUser);
			decorator.setContextCompany(systemTestFixture.monsantoBr);
            decorator.setContextCrop(systemTestFixture.soy);
            return decorator;
		}
        
		private void initFixtures() {
			systemTestFixture = new SystemTestFixture(this);
            saleTestFixture = new SaleTestFixture(this, systemTestFixture);
            accessControlTestFixture = new AccessControlTestFixture(this, systemTestFixture);
		}
        
		private void initProcessorConfig(UserDecorator context) {
            processorConfig.put(ProcessorConfigProperties.SELECTED_LOCALE, localeBR);
            processorConfig.put(ProcessorConfigProperties.LOGGED_USER, context);
            processorConfig.put(ProcessorConfigProperties.FILENAME, "sample.csv");
            processorConfig.put(ProcessorConfigProperties.BUNDLE, resourceBundle);
		}
        
		private StringBuffer createInvalidLayoutLineForInputStream(StringBuffer csv) {
	        if(csv==null) {
		        csv = new StringBuffer("Tipo de documento do Matriz;Matriz;Inscricao Estadual;Customer Sap Code;Codigo Produto;Tipo Transação;Ano;Quantidate ;Numero Nota Fiscal\n");
	        }
	        csv.append("CNPJ;").append("111.11.11;");
	        csv.append(";");
	    	csv.append("C" + ";").append("2008;").append("500" + ";\n");
	    	return csv;
			
		}

	    private StringBuffer createLineForInputStream(StringBuffer csv, String documentValue, String stateRegistration, String customerSapCode,
	            Long productCode, String transactionType, String amountInString) {
	        if(csv==null) {
		        csv = new StringBuffer("Tipo de documento do Matriz;Matriz;Inscricao Estadual;Customer Sap Code;Tipo do Documento Multiplicador;N�mero do Documento do Multiplicador;N�mero da Inscri��o Estadual Multiplicador;C�digo ERP da Multiplicador;Codigo Produto;Lote;Faixa;Tipo Transação;Ano;Quantidate ;Numero Nota Fiscal\n");
	        }
			csv.append("CNPJ;").append(documentValue + ";");
			csv.append(stateRegistration == null ? ";" : stateRegistration + ";");
			csv.append(customerSapCode + ";");
			csv.append(";");
			csv.append(";");
			csv.append(";");
			csv.append(";");
			csv.append(productCode +";");
			csv.append(";");
			csv.append(";");
	    	csv.append(transactionType + ";").append("2008;").append(amountInString + ";\n");
	        return csv;
	    }
        
	    private StringBuffer createInvalidDocumentTypeLineForInputStream(StringBuffer csv, String documentValue, String stateRegistration, String customerSapCode, Long productCode, String transactionType,
	            String amountInString) {
	        if(csv==null) {
	            csv = new StringBuffer("Tipo de documento do Matriz;Matriz;Inscricao Estadual;Customer Sap Code;Tipo do Documento Multiplicador;N�mero do Documento do Multiplicador;N�mero da Inscri��o Estadual Multiplicador;C�digo ERP da Multiplicador;Codigo Produto;Lote;Faixa;Tipo Transação;Ano;Quantidate ;Numero Nota Fiscal\n");
	        }
	        csv.append("CNPU;").append(documentValue + ";");
	        csv.append(stateRegistration == null ? ";" : stateRegistration + ";");
	        csv.append(customerSapCode + ";");
			csv.append(";");
			csv.append(";");
			csv.append(";");
			csv.append(";");
	        csv.append(productCode +";");
			csv.append(";");
			csv.append(";");
	        csv.append(transactionType + ";").append("2008;").append(amountInString + ";\n");
	        return csv;
	    }
        
	    private StringBuffer createInvalidTooLargeLineForInputStream(StringBuffer csv, String documentValue, String stateRegistration, String customerSapCode,
	            Long productCode, String transactionType, String amountInString) {
	        if(csv==null) {
		        csv = new StringBuffer("Tipo de documento do Matriz;Matriz;Inscricao Estadual;Customer Sap Code;Codigo Produto;Tipo Transação;Ano;Quantidate ;Numero Nota Fiscal\n");
	        }
			csv.append("CNPJ;").append(documentValue + ";");
			csv.append(stateRegistration == null ? ";" : stateRegistration + ";");
			csv.append(customerSapCode + ";");
			csv.append(productCode +";");
	    	csv.append(transactionType + ";").append("2008;").append(amountInString + ";");
            csv.append(StringUtils.leftPad("123", 201, "0")); // max size is 200
			csv.append("\n");
	        return csv;
	    }
        
	    private void createAndPersistImportedLines() {
	        QuotaImportedLine line = createQuotaImportedLine(saleTestFixture.customer, BigDecimal.valueOf(1000L), saleTestFixture.productIntactaWithQuota, systemTestFixture.operationalYearOf2012, 1, QuotaImportedLineType.SAP, "12345"); 
	        saveAndFlush(line);
	        line = createQuotaImportedLine(saleTestFixture.customer, BigDecimal.valueOf(1000L), saleTestFixture.productIntactaWithQuota, systemTestFixture.operationalYearOf2012, 2, QuotaImportedLineType.SAP, "12345");
	        saveAndFlush(line);
	        line = createQuotaImportedLine(saleTestFixture.customer, BigDecimal.valueOf(500L), saleTestFixture.productIntactaWithQuota, systemTestFixture.operationalYearOf2011, 3, QuotaImportedLineType.SAP, "12345");
	        saveAndFlush(line);
	    }
        
	    private QuotaImportedLine createQuotaImportedLine(Customer customer, BigDecimal amount, Product product, OperationalYear operationalYear, Integer lineNumber, QuotaImportedLineType lineType, String invoice) {
	        QuotaImportedLine line = new QuotaImportedLine(customer, amount, product);
	        line.setOperationalYear(operationalYear);
	        line.setLine(lineNumber);
	        line.setLineType(lineType);
	        line.setInvoiceNumber(invoice);
	        line.setCustomerDocument(customer.getDocumentValue());
	        line.setCustomerDocumentTypeDescription(customer.getDocument().getDocumentTypeDescription());
	        line.setCustomerStateRegistration(customer.getStateRegistration());
	        line.setDistributorSapCode(customer.getCustomerSAPCode());
	        line.setLineTransactionTypeCode(QuotaImportedLine.CREDIT);
	        line.setOperationalYearDescription(operationalYear.getYear());
	        line.setProductCode(product.getId());
	        line.setEntityUser(accessControlTestFixture.superUser);
	        return line;
	    }
	    
	    private StringBuffer createLineForInputStream(String documentValue, Long productCode, String transactionType,
	            String amountInString, String customerStateRegistration, String sapCode) {
	        return createLineForInputStream(null, documentValue, customerStateRegistration, sapCode, productCode, transactionType, amountInString);
	    }
}
