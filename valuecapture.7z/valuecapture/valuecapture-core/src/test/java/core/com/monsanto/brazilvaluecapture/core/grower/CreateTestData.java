package com.monsanto.brazilvaluecapture.core.grower;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import com.monsanto.brazilvaluecapture.core.base.CityTestData;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Address;
import com.monsanto.brazilvaluecapture.core.base.model.bean.BillingAddress;
import com.monsanto.brazilvaluecapture.core.base.model.bean.BusinessAddress;
import com.monsanto.brazilvaluecapture.core.base.model.bean.City;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Company;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Country;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Crop;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Document;
import com.monsanto.brazilvaluecapture.core.base.model.bean.DocumentType;
import com.monsanto.brazilvaluecapture.core.base.model.bean.State;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Technology;
import com.monsanto.brazilvaluecapture.core.foundation.RandomTestData;
import com.monsanto.brazilvaluecapture.core.foundation.model.bean.StatusEnum;
import com.monsanto.brazilvaluecapture.core.foundation.service.BusinessException;
import com.monsanto.brazilvaluecapture.core.grower.model.bean.Grower;
import com.monsanto.brazilvaluecapture.seedsale.harvest.model.bean.Harvest;
import com.monsanto.brazilvaluecapture.seedsale.harvest.model.bean.Plantability;
import com.monsanto.brazilvaluecapture.seedsale.product.PlantabilityTestData;
import com.monsanto.brazilvaluecapture.seedsale.product.ProductivityTestData;
import com.monsanto.brazilvaluecapture.seedsale.product.model.bean.Brand;
import com.monsanto.brazilvaluecapture.seedsale.product.model.bean.DefaultProductivity;
import com.monsanto.brazilvaluecapture.seedsale.product.model.bean.Product;
import com.monsanto.brazilvaluecapture.seedsale.product.model.bean.Productivity;
import com.monsanto.brazilvaluecapture.seedsale.template.PriceTestData;
import com.monsanto.brazilvaluecapture.seedsale.template.model.bean.Price;
import com.monsanto.brazilvaluecapture.seedsale.template.model.bean.Price.PriceTypeEnum;
import com.monsanto.brazilvaluecapture.seedsale.template.model.bean.SaleTemplate;

/**
 * Class responsible for creating test mass
 * 
 * @author rferreira
 * 
 */
public class CreateTestData {

	/**
	 * Create a new basic pricing
	 * 
	 * @return Pricing
	 * @throws BusinessException 
	 */
	public Price createPriceDefaultTech(PriceTypeEnum priceTypeEnum,
			SaleTemplate saleTemplate) throws BusinessException {

		Company company = createBasicCompany();
		Technology tech = createTechnology(company);

		Price pricing = PriceTestData.createPrice(priceTypeEnum, saleTemplate,
				tech);

		pricing.setId(null);

		return pricing;
	}

	/**
	 * Create a new harvest
	 * 
	 * @param status
	 * 
	 * @return Harvest
	 */
	public Harvest createBasicHarvest(StatusEnum status) {

		Harvest harvest = new Harvest();

		harvest.setDescription(RandomTestData.createRandomString(10));
		harvest.setStatus(status);

		return harvest;
	}

	/**
	 * Create company
	 * 
	 * @return Company
	 */
	public Company createBasicCompany() {
		Company company = new Company();
		company.setDescription(RandomTestData.createRandomString(10));

		return company;
	}

	/**
	 * Create a full company
	 * 
	 * @return Company
	 */
	public Company createFullCompany() {

		Company company = new Company(RandomTestData.createRandomString(10));
		Country country = createCountryByCompany(company);

		company.setBrands(createSomeBrand(company));
		company.setCrops(createSomeCrop(company, country));
		company.setTechnologies(createSomeTechnology(company));
		company.setCountry(country);

		return company;
	}

	/**
	 * Create a new crop by company
	 * 
	 * @param company
	 * @param country TODO
	 * @return
	 */
	public Crop createCrop(Company company, Country country) {

		Crop crop = new Crop(RandomTestData.createRandomString(10), company, country);


		return crop;
	}

	/**
	 * Create a new basic crop by company
	 * 
	 * @return
	 */
	public Crop createBasicCrop() {

		Crop crop = new Crop();
		crop.setDescription(RandomTestData.createRandomString(10));

		return crop;
	}

	/**
	 * Create a new basic brand by company
	 * 
	 * @param company
	 * @return
	 */
	public Brand createBasicBrand() {

		Brand brand = new Brand();
		brand.setDescription(RandomTestData.createRandomString(10));

		return brand;
	}

	/**
	 * Create a new brand by company
	 * 
	 * @param company
	 * @return
	 */
	public Brand createBrand(Company company) {

		Brand brand = new Brand(RandomTestData.createRandomString(10), company, StatusEnum.ACTIVE);

		company.addBrand(brand);

		return brand;
	}

	/**
	 * Create a new technology by company
	 * 
	 * @return
	 */
	public Technology createBasicTechnology() {

		Technology tech = new Technology();
		tech.setDescription(RandomTestData.createRandomString(10));

		return tech;
	}

	/**
	 * Create a new technology by company
	 * 
	 * @param company
	 * @return
	 */
	public Technology createTechnology(Company company) {

		Technology tech = new Technology(RandomTestData.createRandomString(10),
				company);

		company.addTechnology(tech);

		return tech;
	}

	/**
	 * Create some crop by company
	 * 
	 * @param company
	 * @param country TODO
	 * @return Set<Crop>
	 */
	public Set<Crop> createSomeCrop(Company company, Country country) {

		Set<Crop> crops = new HashSet<Crop>();

		crops.add(createCrop(company, country));
		crops.add(createCrop(company, country));
		crops.add(createCrop(company, country));

		return crops;
	}

	/**
	 * Create some brand by company
	 * 
	 * @param company
	 * @return Set<Brand>
	 */
	public Set<Brand> createSomeBrand(Company company) {
		Set<Brand> brands = new HashSet<Brand>();

		brands.add(createBrand(company));
		brands.add(createBrand(company));
		brands.add(createBrand(company));

		return brands;
	}

	/**
	 * Create some technology by company
	 * 
	 * @param company
	 * @return Set<Technology>
	 */
	public Set<Technology> createSomeTechnology(Company company) {

		Set<Technology> tech = new HashSet<Technology>();

		tech.add(createTechnology(company));
		tech.add(createTechnology(company));
		tech.add(createTechnology(company));

		return tech;
	}

	/**
	 * Create some plantability by Harvest
	 * 
	 * @param plantability
	 * @return Set<Plantability>
	 */
	public List<Plantability> createSomePlantability(Harvest harvest) {

		List<Plantability> plantabilities = new ArrayList<Plantability>();

		plantabilities.add(PlantabilityTestData.createPlantability(harvest));
		plantabilities.add(PlantabilityTestData.createPlantability(harvest));
		plantabilities.add(PlantabilityTestData.createPlantability(harvest));

		return plantabilities;
	}

//	 /**
//	 * Create some companies
//	 *
//	 * @param status
//	 * @return List<Company>
//	 */
//	 public List<Company> createSomeCompanies() {
//	 List<Company> companies = new ArrayList<Company>();
//	
//	 companies.add(createFullCompany());
//	 companies.add(createFullCompany());
//	 companies.add(createFullCompany());
//	
//	 return companies;
//	 }

	/**
	 * Create some Productivities
	 * 
	 * @param
	 * @return List<Productivity>
	 */
	public List<Productivity> createSomeProductivities(
			DefaultProductivity defaultProductivity) {

		List<Productivity> productivities = new ArrayList<Productivity>();

		productivities.add(ProductivityTestData.createFullProductivity());
		productivities.add(ProductivityTestData.createFullProductivity());
		productivities.add(ProductivityTestData.createFullProductivity());

		return productivities;
	}

	/**
	 * Create a new basic product
	 * 
	 * @param status
	 * @return Product
	 */
	public Product createBasicProduct(StatusEnum status) {

		Product product = new Product();
		product.setDescription(RandomTestData.createRandomString(10));
		product.setStatus(status);

		return product;
	}

	/**
	 * Create a new country
	 * 
	 * @return Country
	 */
	public Country createBasicCountry() {

		Country c = new Country();

		c.setDescription(RandomTestData.createRandomString(10));
		c.setCode(RandomTestData.createRandomString(5));

		return c;
	}

	/**
	 * Create a new Country with States Associated
	 */
	public Country createCountryWithStates() {

		Country c = new Country();

		c.setDescription(RandomTestData.createRandomString(10));
		c.setCode(RandomTestData.createRandomString(5));
		c.setStates(createSomeStates(c));

		return c;
	}

	public Set<State> createSomeStates(Country c) {
		Set<State> states = new HashSet<State>();
		states.add(createStateByCountry(c));
		states.add(createStateByCountry(c));
		states.add(createStateByCountry(c));
		return states;
	}

	/**
	 * Create a new Country
	 * 
	 * @return State
	 */
	public Country createCountryByCompany(Company company) {

		Country c = new Country();

		c.setDescription(RandomTestData.createRandomString(10));
		c.setCode(RandomTestData.createRandomString(5));
		c.addCompany(company);

		return c;
	}

	/**
	 * Create a new state
	 * 
	 * @return State
	 */
	public State createStateByCountry(Country country) {

		State s = new State();

		s.setDescription(RandomTestData.createRandomString(10));
		s.setCode(RandomTestData.createRandomString(5));
		s.setCountry(country);

		return s;
	}

	/**
	 * Create a new address
	 * 
	 * @deprecated use method on PlayerTestData
	 * @return Address
	 */
	public Address createAddress(State state, City city, Country country) {

		Address a = new Address();

		a.setCity(city);
		a.setCountry(country);
		a.setStreet(RandomTestData.createRandomString(15));
		a.setState(state);

		return a;
	}

	/**
	 * Create a new document type by country
	 * 
	 * @param country
	 * @return DocumentType
	 */
	public DocumentType createDocumentType(Country country) {
		DocumentType d = new DocumentType();

		d.setCountry(country);
		d.setDescription(RandomTestData.createRandomString(10));
		d.setMask(RandomTestData.createRandomString(10));

		return d;
	}

	/**
	 * Create a new document by document type
	 * 
	 * @param DocumentType
	 * @return Document
	 */
	public Document createDocument(DocumentType type) {
		Document d = new Document();

		d.setDocumentType(type);
		d.setValue(RandomTestData.createRandomString(10));

		return d;
	}

	/**
	 * TODO: Criar os demais testdata: country/state/city, documentType/document
	 * Create a new full grower
	 * 
	 * @return Grower
	 */
	public Grower createFullGrower() {
		Country country = createBasicCountry();
		State state = createStateByCountry(country);
		City city = CityTestData.createCityByState(state);
		DocumentType documentType = createDocumentType(country);
		Document document = createDocument(documentType);

		BusinessAddress businessAddress = PlayerTestData.createBusinessAddress(
				state, city, country);
		BillingAddress billingAddress = PlayerTestData.createBillingAddress(
				state, city, country);

		Grower grower = PlayerTestData.createGrower(document, billingAddress,
				businessAddress);

		return grower;
	}

}
