package com.monsanto.brazilvaluecapture.core.grower.service.impl;

import com.monsanto.Util.StringUtils;
import com.monsanto.brazilvaluecapture.core.base.model.bean.BillingAddress;
import com.monsanto.brazilvaluecapture.core.base.model.bean.City;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Country;
import com.monsanto.brazilvaluecapture.core.base.model.bean.State;
import com.monsanto.brazilvaluecapture.core.base.model.dao.CountryDAO;
import com.monsanto.brazilvaluecapture.core.grower.model.bean.Agreement;
import com.monsanto.brazilvaluecapture.core.grower.model.bean.AgreementApprovalLog;
import com.monsanto.brazilvaluecapture.core.grower.model.bean.EmailParameters;
import com.monsanto.brazilvaluecapture.core.grower.model.bean.Grower;
import com.monsanto.brazilvaluecapture.core.grower.model.dao.EmailParametersDAO;
import com.monsanto.brazilvaluecapture.core.grower.service.AgreementApprovalLogService;
import com.monsanto.brazilvaluecapture.core.grower.template.AgreementMailSender;
import com.monsanto.brazilvaluecapture.core.regionalization.CountriesHolder;
import com.monsanto.brazilvaluecapture.core.regionalization.MessageResourceHolder;
import com.monsanto.brazilvaluecapture.core.regionalization.VCCountry;
import com.monsanto.brazilvaluecapture.core.user.model.bean.ItsUserDTO;
import com.monsanto.brazilvaluecapture.core.user.service.UserService;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import static com.monsanto.brazilvaluecapture.core.grower.model.bean.AgreementApprovalLog.AgreementStatus.APPROVED;
import static com.monsanto.brazilvaluecapture.core.grower.service.impl.EmailParametersServiceImpl.*;
import static org.fest.assertions.Assertions.assertThat;
import static org.fest.reflect.core.Reflection.field;
import static org.mockito.Matchers.anyLong;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.*;


/**
 * Created by IntelliJ IDEA.
 * User: HGFIOR
 * Date: 18/09/13
 * Time: 15:38
 * To change this template use File | Settings | File Templates.
 */
@RunWith(MockitoJUnitRunner.class)
public class EmailParametersServiceImpl_UT {

    public static final String LOGGED_USER = "LOGGED_USER";

    @Mock
    private EmailParametersDAO emailParametersDAO;
    @Mock
    private CountriesHolder countriesHolder;
    @Mock
    private MessageResourceHolder messageResourceHolder;
    @Mock
    private CountryDAO countryDAO;
    @Mock
    private AgreementMailSender agreementMailSender = Mockito.mock(AgreementMailSender.class);
    @Mock
    private Agreement agreement = Mockito.mock(Agreement.class);
    @Mock
    private Grower grower = Mockito.mock(Grower.class);
    @Mock
    private BillingAddress billingAddress = Mockito.mock(BillingAddress.class);
    @Mock
    private AgreementApprovalLog agreementApprovalLog = Mockito.mock(AgreementApprovalLog.class);
    @Mock
    private UserService userService = Mockito.mock(UserService.class);
    @Mock
    private EmailParameters emailParameters = Mockito.mock(EmailParameters.class);
    @Mock
    private AgreementApprovalLogService agreementApprovalLogService;

    @InjectMocks
    private EmailParametersServiceImpl emailParametersService = new EmailParametersServiceImpl();

    public static final String MESSAGE = "Message: ${licenseNumber} / ${growerName} / ${byExceptionLiteral}";
    private ItsUserDTO itsUserDTO;
    public static final String AGREEMENT_EMAIL_SUBJECT = "Licencia Pre Aprobada Digitalmente";

    @Before
    public void setUp() {
        field("countriesHolder").ofType(CountriesHolder.class).in(emailParametersService).set(countriesHolder);
        field("countryDAO").ofType(CountryDAO.class).in(emailParametersService).set(countryDAO);
        field("emailParametersDAO").ofType(EmailParametersDAO.class).in(emailParametersService).set(emailParametersDAO);
        field("agreementMailSender").ofType(AgreementMailSender.class).in(emailParametersService).set(agreementMailSender);
        Country country = Mockito.mock(Country.class);
        when(country.getId()).thenReturn((long) 33261);
        when(countryDAO.selectByDescription("ARGENTINA")).thenReturn(country);
        when(countriesHolder.getCountry()).thenReturn((VCCountry.ARGENTINA));
        when(emailParametersDAO.getEmailParameters(anyString(), anyString(), anyLong())).thenReturn(emailParameters);
        when(grower.getName()).thenReturn("Juan Grower");
        when(grower.getDocumentValueFormatted()).thenReturn("20-66666666-1");
        when(agreement.getGrower()).thenReturn(grower);
        when(agreement.getLicenseNumber()).thenReturn("123456");
        when(billingAddress.getFullAddress()).thenReturn("Always Evergreen Terrance 742");
        when(billingAddress.getTelephone()).thenReturn("5555-5555");
        when(grower.getBillingAddress()).thenReturn(billingAddress);
        when(agreementApprovalLog.getGrower()).thenReturn(grower);
        when(agreementApprovalLog.getLicenseNumber()).thenReturn("123456");
        when(agreementApprovalLog.getComments()).thenReturn("123456");

        when(billingAddress.getStreet()).thenReturn("Always Evergreen Terrance");
        when(billingAddress.getNumber()).thenReturn("742");
        State state = new State();
        state.setDescription("The State");
        when(billingAddress.getState()).thenReturn(state);
        City city = new City();
        city.setDescription("Springfield");
        when(billingAddress.getCity()).thenReturn(city);
       // Mockito.when(emailParametersDAO.getEmailParameters(AgreementApprovalLog.AgreementStatus.GROWER_CREATION,"LICENCIAMIENTO", new Long(33261))).thenReturn(emailParameters);
        when(emailParametersDAO.getEmailParametersByAction(AgreementApprovalLog.AgreementStatus.GROWER_CREATION, new Long(33261))).thenReturn(emailParameters);
        itsUserDTO = new ItsUserDTO(new Long(1), LOGGED_USER, "valid@mail.com");
        ItsUserDTO itsUserDTOInvalid = new ItsUserDTO(new Long(2),"LOGGED_USER_INVALID","invalid_mail.com");
        when(userService.getByLogin(LOGGED_USER)).thenReturn(itsUserDTO);
        when(userService.getByLogin("LOGGED_USER_INVALID")).thenReturn(itsUserDTOInvalid);

    }

    @Test
    public void sentToApprovalMailTest() {
        emailParametersService.sendSendToApprovalAgreementMail(agreement);
        verify(this.countryDAO, times(1)).selectByDescription(VCCountry.ARGENTINA.toString());
        verify(this.emailParametersDAO, times(1)).getEmailParameters(AgreementApprovalLog.AgreementStatus.SEND_TO_APPROVED.name(),"LICENCIAMIENTO", new Long(33261));
        assertThat(agreementMailSender).isNotNull();
        assertThat(agreementMailSender.getMailBody()).isEqualTo(emailParameters.getMessage());
        assertThat(agreementMailSender.getRecipient()).isEqualTo(emailParameters.getRecipient());
        verify(agreementMailSender, times(1)).sendAgreementMail(); //MERGE: Conflict detected merging TRUNK to VC_POD branch (revisions 2469 - 2753). Kept VC_POD version.
    }

    @Test
    public void approvalMailTest() {
        emailParametersService.sendApprovalAgreementMail(agreement);
        verify(this.countryDAO, times(1)).selectByDescription(VCCountry.ARGENTINA.toString());
        verify(this.emailParametersDAO, times(1)).getEmailParameters(APPROVED.name(),"LICENCIAMIENTO", new Long(33261));
        assertThat(agreementMailSender).isNotNull();
        assertThat(agreementMailSender.getMailBody()).isEqualTo(parseApprovalMessage(emailParameters.getMessage(), agreement.getLicenseNumber()));
        assertThat(agreementMailSender.getRecipient()).isEqualTo(emailParameters.getRecipient());
        verify(agreementMailSender, times(1)).sendAgreementMail(); //MERGE: Conflict detected merging TRUNK to VC_POD branch (revisions 2469 - 2753). Kept VC_POD version.
    }

    @Test
    public void observeMailTest() {
        emailParametersService.sendObserveAgreementMail(agreementApprovalLog);
        verify(this.countryDAO, times(1)).selectByDescription(VCCountry.ARGENTINA.toString());
        verify(this.emailParametersDAO, times(1)).getEmailParameters(AgreementApprovalLog.AgreementStatus.OBSERVED.name(),"LICENCIAMIENTO", new Long(33261));
        assertThat(agreementMailSender).isNotNull();
        assertThat(agreementMailSender.getMailBody()).isEqualTo(parseObserveMessage(emailParameters.getMessage(), agreementApprovalLog.getComments()));
        assertThat(agreementMailSender.getRecipient()).isEqualTo(emailParameters.getRecipient());
        verify(agreementMailSender, times(1)).sendAgreementMail(); //MERGE: Conflict detected merging TRUNK to VC_POD branch (revisions 2469 - 2753). Kept VC_POD version.
    }


    @Test
    public void sendToNotifyNewGrowerAccountMailTest() {
        Country country = new Country();
        country.setCode("AR");
        country.setId(new Long(33261));
        emailParametersService.sendNewGrowerAccountMail(anyString(), anyString(), country);
        //java.util.Locale locale=mock(java.util.Locale.class);
        assertThat(agreementMailSender).isNotNull();
        verify(agreementMailSender, times(1)).sendAgreementMail();


    }

    private String parseApprovalMessage(String message, String licenseNumber) {
        return StringUtils.replace(message, "${licenseNumber}", licenseNumber);
    }

    private String parseObserveMessage(String message, String comment) {
        return StringUtils.replace(message, "${comment}", comment);
    }

    private String parseSuspendedMessage(String message, String comment) {
        return StringUtils.replace(message, "${comment}", comment);
    }

    private String parseHolderNumberAndNameMessage(String message, String holderNumber, String holderName) {
        String parsedMessage = StringUtils.replace(message, "${holderNumber}", holderNumber);
        parsedMessage = StringUtils.replace(parsedMessage, "${holderName}", holderName);
        return parsedMessage;
    }

    @Test
    public void testParseApprovalMessage() {
        agreement.setLicenseNumber("12356");
        String message = emailParametersService.parseApprovalMessage("This is a license number : ${licenseNumber}", agreement);
        assertThat(message).isNotNull();
        assertThat(message).isEqualTo("This is a license number : 123456");
    }

    @Test
    public void testParseObserveMessage() {
        String message = emailParametersService.parseObserveMessage("This is a license number : ${comment}", agreementApprovalLog);
        assertThat(message).isNotNull();
        assertThat(message).isEqualTo("This is a license number : 123456");
    }

    @Test
    public void testCreateSendToApprovalMailTemplateInstance() {
        AgreementMailSender sendToApprovalMailTemplate = emailParametersService.createAgreementMailSenderInstance();
        assertThat(sendToApprovalMailTemplate).isNotNull();
        assertThat(sendToApprovalMailTemplate).isInstanceOf(AgreementMailSender.class);
    }

    @Test
    public void testCreateObserveMailTemplateInstance() {
        AgreementMailSender observeMailTemplate = emailParametersService.createAgreementMailSenderInstance();
        assertThat(observeMailTemplate).isNotNull();
        assertThat(observeMailTemplate).isInstanceOf(AgreementMailSender.class);
    }

    @Test
    public void testCreateApprovalMailTemplateInstance() {
        AgreementMailSender approvalMailTemplate = emailParametersService.createAgreementMailSenderInstance();
        assertThat(approvalMailTemplate).isNotNull();
        assertThat(approvalMailTemplate).isInstanceOf(AgreementMailSender.class);
    }


    @Test
    public void testParseHolderNumberAndNameMessage() {
        String message = emailParametersService.parseHolderNumberAndNameMessage("Datos de Productos:\n" +
                "CUIT: ${cuit}\n" +
                "RAZON SOCIAL: ${razon_social}\n", "123456", "RAZON SOCIAL 1");
        assertThat(message).isNotNull();
        assertThat(message).isEqualTo("Datos de Productos:\n" +
                "CUIT: 123456\n" +
                "RAZON SOCIAL: RAZON SOCIAL 1\n");
    }

    @Test
    public void suspendMailTest_when_backoffice_mail_is_invalid() {
        emailParametersService.sendSuspendAgreementMail(agreementApprovalLog, LOGGED_USER);
        verify(this.countryDAO, times(1)).selectByDescription(VCCountry.ARGENTINA.toString());
        verify(this.emailParametersDAO, times(1)).getEmailParameters(AgreementApprovalLog.AgreementStatus.SUSPENDED.name(), "LICENCIAMIENTO", new Long(33261));
        assertThat(agreementMailSender).isNotNull();
        assertThat(agreementMailSender.getMailBody()).isEqualTo(parseSuspendedMessage(emailParameters.getMessage(), agreementApprovalLog.getComments()));
        assertThat(agreementMailSender.getRecipient()).isEqualTo(emailParameters.getRecipient());
        verify(agreementMailSender, times(1)).sendAgreementMail();
    }

    @Test
    public void testSendAgreementMailToLicenseManagerByStatus_normal() {
        Agreement agreement = createAgreement();
        when(emailParameters.getMessage()).thenReturn(MESSAGE);
        when(agreementApprovalLogService.getAgreementManager(agreement)).thenReturn(LOGGED_USER);
        when(messageResourceHolder.getLocalizedLanguageMessage(AGREEMENT_APPROVAL_MANAGER_SUBJECT)).thenReturn(AGREEMENT_EMAIL_SUBJECT);

        emailParametersService.sendAgreementMailToLicenseManagerByStatus(agreement, APPROVED);

        verify(agreementMailSender, times(1)).setMailBody("Message: license number / GROWER NAME / ");
        verify(agreementMailSender, times(1)).setRecipient(itsUserDTO.getEmail());
        verify(agreementMailSender, times(1)).setSubject(AGREEMENT_EMAIL_SUBJECT);
        verify(agreementMailSender, times(1)).setMailTemplate(AGREEMENT_MAIL_TEMPLATE);
    }

    @Test
    public void testSendAgreementMailToLicenseManagerByStatus_byException() {
        Agreement agreement = createAgreement();
        agreement.setReason(Agreement.AgreementReasonEnum.EXCEPTION);
        when(emailParameters.getMessage()).thenReturn(MESSAGE);
        when(agreementApprovalLogService.getAgreementManager(agreement)).thenReturn(LOGGED_USER);
        when(messageResourceHolder.getLocalizedLanguageMessage(AGREEMENT_APPROVAL_MANAGER_SUBJECT)).thenReturn(AGREEMENT_EMAIL_SUBJECT);
        String message = "por Excepcion";
        when(messageResourceHolder.getLocalizedLanguageMessage(BY_EXCEPTION_KEY)).thenReturn(message);

        emailParametersService.sendAgreementMailToLicenseManagerByStatus(agreement, APPROVED);

        verify(agreementMailSender, times(1)).setMailBody("Message: license number / GROWER NAME / " + " " + message);
        verify(agreementMailSender, times(1)).setRecipient(itsUserDTO.getEmail());
        verify(agreementMailSender, times(1)).setSubject(AGREEMENT_EMAIL_SUBJECT );
        verify(agreementMailSender, times(1)).setMailTemplate(AGREEMENT_MAIL_TEMPLATE);
    }

    private Agreement createAgreement() {
        Agreement agreement = new Agreement();
        agreement.setLicenseNumber("license number");
        Grower grower = new Grower();
        grower.setName("grower name");
        agreement.setGrower(grower);
        return agreement;
    }

}
