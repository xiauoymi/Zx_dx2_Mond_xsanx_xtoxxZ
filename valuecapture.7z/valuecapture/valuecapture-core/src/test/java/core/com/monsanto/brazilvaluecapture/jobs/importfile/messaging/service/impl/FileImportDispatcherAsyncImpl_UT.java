package com.monsanto.brazilvaluecapture.jobs.importfile.messaging.service.impl;

import static org.fest.reflect.core.Reflection.field;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;

import org.junit.Before;
import org.junit.Test;
import org.springframework.core.task.TaskExecutor;

import com.monsanto.brazilvaluecapture.jobs.importfile.messaging.bean.FileImportInfo;
import com.monsanto.brazilvaluecapture.jobs.importfile.messaging.gateway.ImportFileGateway;

/**
 * Test for class {@link FileImportDispatcherAsyncImpl}
 * 
 * @author CSOBR1
 * 
 */
public class FileImportDispatcherAsyncImpl_UT {

	/**
	 * Class under test.
	 */
	private FileImportDispatcherAsyncImpl test;
	
	private ImportFileGateway importFileGateway;

	@Before
    public void setUp() throws Exception {
		
		test = new FileImportDispatcherAsyncImpl();
		
		importFileGateway = mock(ImportFileGateway.class);
		
		field("taskExecutor").ofType(TaskExecutor.class).in(test).set(mock(TaskExecutor.class));
		field("importFileGateway").ofType(ImportFileGateway.class).in(test).set(importFileGateway);
    }
	
	@Test
	public void test_sendFileImportRequest() {
		test.sendFileImportRequest(null, null, null, null, null, null);
		test.run();
		
		verify(importFileGateway).importFile(any(FileImportInfo.class));
	}

}
