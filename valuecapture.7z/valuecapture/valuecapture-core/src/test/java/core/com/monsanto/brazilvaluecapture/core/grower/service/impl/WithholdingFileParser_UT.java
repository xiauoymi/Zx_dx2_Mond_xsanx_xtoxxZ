package com.monsanto.brazilvaluecapture.core.grower.service.impl;

import com.monsanto.brazilvaluecapture.core.base.model.bean.Country;
import com.monsanto.brazilvaluecapture.core.base.model.bean.DocumentType;
import com.monsanto.brazilvaluecapture.core.base.model.dao.DocumentTypeDAO;
import com.monsanto.brazilvaluecapture.core.base.service.BaseService;
import com.monsanto.brazilvaluecapture.core.foundation.util.ConstraintViolation;
import com.monsanto.brazilvaluecapture.core.foundation.util.csv.CSVReadableInvalidException;
import com.monsanto.brazilvaluecapture.core.foundation.util.parser.ParsedLineResult;
import com.monsanto.brazilvaluecapture.core.grower.model.bean.Withholding;
import com.monsanto.brazilvaluecapture.core.grower.service.WithholdingService;
import com.monsanto.brazilvaluecapture.core.grower.validation.*;
import junit.framework.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.*;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.ResourceBundle;

import static org.fest.reflect.core.Reflection.field;
import static org.junit.Assert.fail;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doThrow;

public class WithholdingFileParser_UT {

	@Mock
	private WithholdingValidator withholdingValidatorThrowsExceptionValidat;
	private WithholdingValidator withholdingValidator;
	private WithholdingExistsGrowerValidationRule withholdingExistsGrowerValidationRule;
	private WithholdingDocumentValidationRule withholdingDocumentValidationRule;
    private WithholdingFieldsValidationRule withholdingFieldsValidationRule;
	@Mock
	private WithholdingService withholdingService;
	@Mock
	private ResourceBundle resourceBundle;
	private final static String SEPARATOR=";";
	private static final String DOCUMENT_TYPE = "RUC_PJ";
	private static final String DOCUMENT_NUMBER = "20212127";
	private static final String NAME = "EZE AGRI";
	private static final String WITHHOLDING_PERCENTAJE = "30";
	private Country country;
	@InjectMocks
	private WithholdingFileParser validFileParser;
	@InjectMocks
    private WithholdingFileParser invalidFileParser;
	@Mock
	private DocumentTypeDAO documentTypeDao; 
	@Mock
	private BaseService baseService;
	Locale locale;
	
	private List<ParsedLineResult> warnings = new ArrayList<ParsedLineResult>() ;

	@Before
	public void setUp() throws WithholdingConstraintViolationException, IOException {

		MockitoAnnotations.initMocks(this);

		List<ConstraintViolation> constraintViolations = new ArrayList<ConstraintViolation>();
		constraintViolations
				.add(new ConstraintViolation("msg", "code", "field"));

		doThrow(
				new WithholdingConstraintViolationException("",
						constraintViolations)).when(
				withholdingValidatorThrowsExceptionValidat).validate(
				Matchers.<Withholding> any());

		locale = new Locale("py", "PY");
		country = new Country("py", "PY");
		withholdingValidator = new WithholdingValidator();
		
		
		withholdingDocumentValidationRule = new  WithholdingDocumentValidationRule();
		field("documentTypeDao").ofType(DocumentTypeDAO.class).in(withholdingDocumentValidationRule).set(documentTypeDao);
		field("withholdingDocumentValidationRule").ofType(WithholdingDocumentValidationRule.class).in(withholdingValidator).set(withholdingDocumentValidationRule);
		
		withholdingExistsGrowerValidationRule = new WithholdingExistsGrowerValidationRule();
		field("baseService").ofType(BaseService.class).in(withholdingExistsGrowerValidationRule).set(baseService);
		field("withholdingExistsGrowerValidationRule").ofType(WithholdingExistsGrowerValidationRule.class).in(withholdingValidator).set(withholdingExistsGrowerValidationRule);
        withholdingFieldsValidationRule = new WithholdingFieldsValidationRule();
        field("withholdingFieldsValidationRule").ofType(WithholdingFieldsValidationRule.class).in(withholdingValidator).set(withholdingFieldsValidationRule);
		 withholdingValidator.createRules();
		
		 doNothing().when(withholdingService).save(any(List.class));
		 validFileParser = new WithholdingFileParser(resourceBundle,withholdingService,"test",createValidInputStream(),locale,"User",country,withholdingValidator);
		 								            
		
		 invalidFileParser = new WithholdingFileParser(resourceBundle,withholdingService,"test",createInValidInputStream(),locale,"User",country,withholdingValidator);
		 field("warnings").ofType(List.class).in(this.invalidFileParser).set(warnings);

	}

	 private InputStream createInValidInputStream() throws IOException {
	        ByteArrayOutputStream outputStream=new ByteArrayOutputStream();

	        StringBuilder header=new StringBuilder("documentType").append(SEPARATOR).append("documentNumber").append(SEPARATOR).append("name");
	        header.append(SEPARATOR).append("withholdingPercentaje\n");

	        StringBuilder line=new StringBuilder("RUC").append(SEPARATOR).append(DOCUMENT_NUMBER).append(SEPARATOR);
	        line.append(NAME).append(SEPARATOR);
	        line.append(WITHHOLDING_PERCENTAJE);

	        outputStream.write(header.toString().getBytes());
	        outputStream.write(line.toString().getBytes());

	        InputStream inputStream = new ByteArrayInputStream(outputStream.toByteArray());
	        outputStream.close();
	        return inputStream;
	}

	private InputStream createValidInputStream() throws IOException {
	        ByteArrayOutputStream outputStream=new ByteArrayOutputStream();

	        StringBuilder header=new StringBuilder("documentType").append(SEPARATOR).append("documentNumber").append(SEPARATOR).append("name");
	        header.append(SEPARATOR).append("withholdingPercentaje\n");

	        StringBuilder line=new StringBuilder(DOCUMENT_TYPE).append(SEPARATOR).append(DOCUMENT_NUMBER).append(SEPARATOR);
	        line.append(NAME).append(SEPARATOR);
	        line.append(WITHHOLDING_PERCENTAJE);

	        outputStream.write(header.toString().getBytes());
	        outputStream.write(line.toString().getBytes());

	        InputStream inputStream = new ByteArrayInputStream(outputStream.toByteArray());
	        outputStream.close();
	        return inputStream;
	}
	 
	 
	@Test
    public void read_ShouldAddWarnings_WhenFileHasInvalidRecords(){

        try {

            invalidFileParser.readFile();
            invalidFileParser.process();

            Assert.assertEquals(1, invalidFileParser.getErrorLines());
            Assert.assertEquals(0,invalidFileParser.getSuccessLines());

        } catch (CSVReadableInvalidException e) {
            fail();
        }
    }
	
	@Test
	public void read_ShouldNotAddWarnings_WhenFileHasInvalidRecords() {

		try {
			Mockito.when(documentTypeDao.selectDocumentTypeByDocumentDescription(Mockito.anyString())).thenReturn(new DocumentType());

			validFileParser.readFile();
			validFileParser.process();

			Assert.assertEquals(0, validFileParser.getErrorLines());
			Assert.assertEquals(1, validFileParser.getSuccessLines());

		} catch (CSVReadableInvalidException e) {
			fail();
		}
	}
	
	@Test
	public void read_ShouldNotAddWarnings_CSVInvalidLayoutException() throws IOException {

		try {
			 invalidFileParser = new WithholdingFileParser(resourceBundle,withholdingService,"test",createInValidInputStream(),locale,"User",country,withholdingValidator);

			 invalidFileParser.readFile();
			 invalidFileParser.process();

			Assert.assertEquals(1, invalidFileParser.getWarnings().size());

		} catch (CSVReadableInvalidException e) {
			fail();
		}
	}

}
