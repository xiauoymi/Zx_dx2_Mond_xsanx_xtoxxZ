package com.monsanto.brazilvaluecapture.seedsale.cashAdvance.validation;

import com.monsanto.brazilvaluecapture.core.foundation.validation.ValidationException;
import com.monsanto.brazilvaluecapture.core.foundation.validation.ValidationRule;
import com.monsanto.brazilvaluecapture.core.foundation.validation.ValidatorChain;
import com.monsanto.brazilvaluecapture.seedsale.cashAdvance.model.bean.CashAdvanceTransaction;
import com.monsanto.brazilvaluecapture.seedsale.cashAdvance.validation.impl.CashAdvanceCreditValidator;
import com.monsanto.brazilvaluecapture.seedsale.cashAdvance.validation.rules.*;
import org.junit.Test;
import org.mockito.ArgumentCaptor;

import java.util.List;

import static org.fest.assertions.Assertions.assertThat;
import static org.mockito.Mockito.*;

public class CashAdvanceCreditValidator_UT {
    private ValidatorChain<CashAdvanceTransaction> validatorChain = mock(ValidatorChain.class);

    @Test
    public void testCreateRulesAddCashAdvanceAmountValidationRule_WhenCreatingRules() {
        CashAdvanceCreditValidator cashAdvanceValidator = createCashAdvanceValidator();
        final int ruleIndex = 0;

        cashAdvanceValidator.createRules();

        verifyValidationRuleType(CashAdvanceAmountValidationRule.class, ruleIndex);
    }

    @Test
    public void testCreateRulesAddCashAdvancePartnerValidationRule_WhenCreatingRules() {
        CashAdvanceCreditValidator cashAdvanceValidator = createCashAdvanceValidator();
        final int ruleIndex = 1;

        cashAdvanceValidator.createRules();

        verifyValidationRuleType(CashAdvancePartnerValidationRule.class, ruleIndex);
    }

    @Test
    public void testCreateRulesAddCashAdvanceReferenceDateValidationRule_WhenCreatingRules(){
        CashAdvanceCreditValidator cashAdvanceValidator = createCashAdvanceValidator();
        int ruleIndex = 2;

        cashAdvanceValidator.createRules();

        verifyValidationRuleType(CashAdvanceReferenceDateValidationRule.class, ruleIndex);
    }

    @Test
    public void testCreateRulesAddCashAdvanceOperationalYearValidationRule_WhenCreatingRules(){
        CashAdvanceCreditValidator cashAdvanceValidator = createCashAdvanceValidator();
        int ruleIndex = 3;

        cashAdvanceValidator.createRules();

        verifyValidationRuleType(CashAdvanceOperationalYearValidationRule.class, ruleIndex);
    }

    @Test
    public void testCreateRulesAddCashAdvanceFormPaymentDateValidationRule_WhenCreatingRules(){
        CashAdvanceCreditValidator cashAdvanceValidator = createCashAdvanceValidator();
        int ruleIndex = 5;

        cashAdvanceValidator.createRules();

        verifyValidationRuleType(CashAdvanceFormPaymentDateValidationRule.class, ruleIndex);
    }

    @Test
    public void testCreateRulesAddCashAdvanceSourceOperationTypeValidationRule_WhenCreatingRules(){
        CashAdvanceCreditValidator cashAdvanceValidator = createCashAdvanceValidator();
        int ruleIndex = 4;

        cashAdvanceValidator.createRules();

        verifyValidationRuleType(CashAdvanceSourceOperationTypeValidationRule.class, ruleIndex);
    }



    private void verifyValidationRuleType(Class<?> validationRuleType, int index) {
        ArgumentCaptor<ValidationRule> validationRuleArgumentCaptor = ArgumentCaptor.forClass(ValidationRule.class);
        verify(validatorChain, atLeastOnce()).addRule(validationRuleArgumentCaptor.capture());
        final List<ValidationRule> validationRuleArgumentCaptorAllValues = validationRuleArgumentCaptor.getAllValues();
        assertThat(validationRuleArgumentCaptorAllValues.get(index)).isInstanceOf(validationRuleType);
    }

    @Test
    public void testValidateInvokesValidatorChain_WhenValidatingCashAdvanceTransaction() throws ValidationException {
        CashAdvanceCreditValidator cashAdvanceValidator = createCashAdvanceValidator();
        cashAdvanceValidator.createRules();
        CashAdvanceTransaction cashAdvanceTransaction = new CashAdvanceTransaction();

        cashAdvanceValidator.validate(cashAdvanceTransaction);

        verify(validatorChain).validate(cashAdvanceTransaction);
    }

    private CashAdvanceCreditValidator createCashAdvanceValidator() {
        return new CashAdvanceCreditValidator() {
            @Override
            protected ValidatorChain<CashAdvanceTransaction> createValidatorChain() {
                return CashAdvanceCreditValidator_UT.this.validatorChain;
            }
        };
    }
}