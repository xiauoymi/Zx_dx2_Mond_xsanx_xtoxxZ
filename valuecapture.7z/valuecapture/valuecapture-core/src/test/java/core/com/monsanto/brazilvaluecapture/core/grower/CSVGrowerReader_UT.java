package com.monsanto.brazilvaluecapture.core.grower;

import static org.mockito.Mockito.mock;

import java.io.IOException;
import java.io.InputStream;
import java.util.Locale;

import com.monsanto.brazilvaluecapture.core.grower.service.impl.GrowerFileParserBrazil;
import junit.framework.Assert;

import org.junit.Before;
import org.junit.Test;

import com.monsanto.brazilvaluecapture.core.base.service.BaseService;
import com.monsanto.brazilvaluecapture.core.foundation.util.csv.CSVInvalidLayoutException;
import com.monsanto.brazilvaluecapture.core.foundation.util.csv.CSVParserReader.CSV_ERROS;
import com.monsanto.brazilvaluecapture.core.foundation.util.csv.CSVReadableInvalidException;
import com.monsanto.brazilvaluecapture.core.grower.service.impl.GrowerFileParser;

public class CSVGrowerReader_UT {

    private static final String LOGIN = "dave";

	private BaseService baseServiceMock;
	
	@Before
	public void setup(){
		baseServiceMock = mock(BaseService.class);
	}

	@Test
	public void loadCsvToGrower_br_with_success() throws IOException, CSVInvalidLayoutException, CSVReadableInvalidException{
	
		InputStream inputFile = getClass().getClassLoader().getResourceAsStream("csv/grower_test_success_pt_BR.csv");
		 Locale localeBR = new Locale("pt", "BR");
	
		 GrowerFileParser fileparser = new GrowerFileParserBrazil(inputFile, localeBR, baseServiceMock, LOGIN);
		 fileparser.readFile();
		 Assert.assertEquals("Number of warning should be zero", 0, fileparser.getErrorLines());
		 Assert.assertTrue("Number of grower should be mroe than zero", fileparser.hasSuccess());
		 
	}

	@Test
	public void loadCsvToGrower_br_with_invalid_layout() throws IOException, CSVInvalidLayoutException, CSVReadableInvalidException{
	
		InputStream inputFile = getClass().getClassLoader().getResourceAsStream("csv/grower_test_invalid_layout_pt_BR.csv");
		Locale localeBR = new Locale("pt", "BR");

		GrowerFileParser fileparser = new GrowerFileParserBrazil(inputFile, localeBR, baseServiceMock, LOGIN);
		fileparser.readFile();
		
		Assert.assertEquals("Give me Warning  001 - Invalid Layout", CSV_ERROS.ERROR_ILLEGAL_LAYOUT , fileparser.getGrowerParserResult().getWarnings().get(6).getCodeWarn());
	}
	
}