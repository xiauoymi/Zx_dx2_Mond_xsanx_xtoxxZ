package com.monsanto.brazilvaluecapture.seedsale.revenue.service;


import com.google.common.base.Optional;
import com.monsanto.brazilvaluecapture.seedsale.bonus.accrual.model.bean.BonusCalendarRule;
import com.monsanto.brazilvaluecapture.seedsale.bonus.accrual.model.dao.BonusCalendarRuleDAO;
import com.monsanto.brazilvaluecapture.utils.DateRange;
import com.monsanto.brazilvaluecapture.utils.DateUtils;
import org.joda.time.DateTime;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.Date;

import static org.fest.assertions.Assertions.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class RevenueRecognitionCalendarRule_UT {
    @Mock
    private BonusCalendarRuleDAO bonusCalendarRuleDAO;

    @Test
    public void testGetRangeReturnsLastMonthDateRange_WhenNoBonusCalendarRuleIsFound() {
        madeBonusCalendarRuleDAOReturnNothing();
        CalendarRule revenueRecognitionCalendarRule = new RevenueRecognitionCalendarRule(bonusCalendarRuleDAO);

        DateRange dateRange = revenueRecognitionCalendarRule.getSaleCreationDateRange();

        DateRange lastMonthDateRange = DateUtils.getLastMonthDateRange();
        assertThat(dateRange.getDateFrom()).isEqualTo(lastMonthDateRange.getDateFrom());
        assertThat(dateRange.getDateTo()).isEqualTo(lastMonthDateRange.getDateTo());
    }

    @Test
    public void testGetRangeReturnsBonusCalendarRuleBasedOnSaleCreationDates_WhenBonusCalendarRuleExistsForToday() {
        DateRange expectedDateRange = new DateRange(getDateFrom(), getDateTo());
        madeBonusCalendarRuleDAOReturnDateRange(expectedDateRange, null);
        CalendarRule revenueRecognitionCalendarRule = new RevenueRecognitionCalendarRule(bonusCalendarRuleDAO);

        DateRange dateRange = revenueRecognitionCalendarRule.getSaleCreationDateRange();

        assertThat(dateRange.getDateFrom()).isEqualTo(expectedDateRange.getDateFrom());
        assertThat(dateRange.getDateTo()).isEqualTo(expectedDateRange.getDateTo());
    }

    @Test
    public void testGetSaleInvoiceDateRangeReturnsInexistingRangeDate_WhenNoBonusCalendarRuleExistsForToday() {
        madeBonusCalendarRuleDAOReturnNothing();
        CalendarRule revenueRecognitionCalendarRule = new RevenueRecognitionCalendarRule(bonusCalendarRuleDAO);

        Optional<DateRange> saleInvoiceDateRange = revenueRecognitionCalendarRule.getSaleInvoiceDateRange();

        assertThat(saleInvoiceDateRange.isPresent()).isFalse();
    }

    @Test
    public void testGetSaleInvoiceDateRangeReturnsRangeDate_WhenBonusCalendarRuleExistsForToday() {
        DateRange expectedDateRange = new DateRange(getDateFrom(), getDateTo());
        madeBonusCalendarRuleDAOReturnDateRange(null, expectedDateRange);
        CalendarRule revenueRecognitionCalendarRule = new RevenueRecognitionCalendarRule(bonusCalendarRuleDAO);

        Optional<DateRange> saleInvoiceDateRange = revenueRecognitionCalendarRule.getSaleInvoiceDateRange();

        DateRange actualDateRange = saleInvoiceDateRange.get();
        assertThat(expectedDateRange.getDateFrom()).isEqualTo(actualDateRange.getDateFrom());
        assertThat(expectedDateRange.getDateTo()).isEqualTo(actualDateRange.getDateTo());
    }

    private void madeBonusCalendarRuleDAOReturnNothing() {
        when(bonusCalendarRuleDAO.findBonusCalendarRuleByJobDate(any(Date.class))).thenReturn(Optional.<BonusCalendarRule>absent());
    }

    private void madeBonusCalendarRuleDAOReturnDateRange(DateRange saleItemDateRange, DateRange saleInvoiceDateRange) {
        BonusCalendarRule bonusCalendarRule = new BonusCalendarRule();
        if (saleItemDateRange != null) {
            bonusCalendarRule.setSaleCreationDateFrom(saleItemDateRange.getDateFrom());
            bonusCalendarRule.setSaleCreationDateTo(saleItemDateRange.getDateTo());
        }
        if (saleInvoiceDateRange != null) {
            bonusCalendarRule.setInvoiceDateFrom(saleInvoiceDateRange.getDateFrom());
            bonusCalendarRule.setInvoiceDateTo(saleInvoiceDateRange.getDateTo());
        }

        Optional<BonusCalendarRule> expectedOptionalDateRange = Optional.of(bonusCalendarRule);
        when(bonusCalendarRuleDAO.findBonusCalendarRuleByJobDate(any(Date.class))).thenReturn(expectedOptionalDateRange);
    }

    private Date getDateTo() {
        return new DateTime().withDate(2014, 01, 01).toDate();
    }

    private Date getDateFrom() {
        return new DateTime().withDate(2014, 12, 31).toDate();
    }
}
