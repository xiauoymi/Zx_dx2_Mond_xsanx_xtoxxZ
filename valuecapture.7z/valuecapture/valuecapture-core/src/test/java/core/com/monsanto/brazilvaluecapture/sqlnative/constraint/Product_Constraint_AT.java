package com.monsanto.brazilvaluecapture.sqlnative.constraint;

import com.monsanto.brazilvaluecapture.core.base.SystemTestFixture;
import com.monsanto.brazilvaluecapture.core.foundation.model.bean.StatusEnum;
import com.monsanto.brazilvaluecapture.core.foundation.service.BusinessException;
import com.monsanto.brazilvaluecapture.core.foundation.test.AbstractServiceIntegrationTests;
import com.monsanto.brazilvaluecapture.seedsale.harvest.HarvestTestData;
import com.monsanto.brazilvaluecapture.seedsale.harvest.model.bean.Harvest;
import com.monsanto.brazilvaluecapture.seedsale.product.ProductTestData;
import com.monsanto.brazilvaluecapture.seedsale.product.model.bean.Product;
import com.monsanto.brazilvaluecapture.seedsale.product.model.dao.ProductDAO;
import com.monsanto.brazilvaluecapture.seedsale.product.service.ProductService;
import com.monsanto.brazilvaluecapture.seedsale.product.service.ProductWithAssociatedSaleTemplateException;
import com.monsanto.brazilvaluecapture.seedsale.template.SaleTemplateTestData;
import com.monsanto.brazilvaluecapture.seedsale.template.model.bean.SaleTemplate;
import junit.framework.Assert;
import org.hibernate.exception.GenericJDBCException;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Collections;

@Ignore
public class Product_Constraint_AT extends AbstractServiceIntegrationTests{
	
	@Autowired
	private ProductService productService;
	
	@Autowired
    private ProductDAO dao;
	

	private Product product;
	private String productDescription = "Product Description".toUpperCase();
	
	@Before
	public void init() {
		systemTestFixture = new SystemTestFixture(this);
		product = ProductTestData.createProduct(systemTestFixture.monsoy, systemTestFixture.soy, systemTestFixture.intacta, StatusEnum.ACTIVE, systemTestFixture.monsantoBr);
		product.setDescription(productDescription);
		saveAndFlush(product);
	}

	
	@Test(expected = BusinessException.class)
	public void given_that_i_have_a_product_and_try_save_product_with_same_attributes_ProductShouldRisedABusinessException()  throws BusinessException {
		Product sameProduct = new Product(productDescription, StatusEnum.ACTIVE, systemTestFixture.soy, systemTestFixture.intacta, systemTestFixture.monsoy, systemTestFixture.monsantoBr);
		productService.save(sameProduct);
	}
	
	@Test(expected = ProductWithAssociatedSaleTemplateException.class)
	public void given_that_i_have_product_associated_with_sale_template_and_delete_this_product_ProductShouldRisedAProductWithAssociatedSaleTemplateException() throws ProductWithAssociatedSaleTemplateException {
		Harvest harvest = HarvestTestData.createHarvest(systemTestFixture.soy, systemTestFixture.operationalYearOf2011, systemTestFixture.monsantoBr);
		saveAndFlush(harvest);
		
		SaleTemplate saleTemplate = SaleTemplateTestData.createSaleTemplateTypeSeedSale(harvest);
				
		saleTemplate.setProducts(Collections.singleton(product));
		saveAndFlush(saleTemplate);
		try {
			productService.delete(product);    
		} catch (GenericJDBCException e) {
			// Workaround to HSQLDB
			if (!getAssumptionTest().isEnvironmentWithSQLANSI()) {
				throw new ProductWithAssociatedSaleTemplateException(e.getMessage(), e.getCause());
			}
		}
	}
	
	
	@Test(expected=BusinessException.class)
	public void given_that_i_have_a_product_ProductShouldBeUpdated() throws BusinessException {
    	Product productCreated = ProductTestData.createProduct(this.systemTestFixture.monsoy, this.systemTestFixture.soy, this.systemTestFixture.intacta, StatusEnum.ACTIVE, this.systemTestFixture.monsantoBr);
    	productCreated.setDescription("ProductDescription1");
    	productService.save(productCreated);
    	
    	// creating a new product
		Product product = new Product();
		product.setBrand(productCreated.getBrand());
		product.setCrop(productCreated.getCrop());
		product.setTechnology(productCreated.getTechnology());
		product.setStatus(StatusEnum.ACTIVE);
		product.setDescription("ProductDescription3");
    	productService.save(product);
    	
        Assert.assertNotNull(product);
        Assert.assertNotNull(product.getId());
        Assert.assertEquals(product.getDescription(), "ProductDescription3".toUpperCase());
        
        product.setDescription("ProductDescription1");
        
        try{
        	productService.save(product);
		} catch (GenericJDBCException e) {
			// Workaround to HSQLDB
			if (!getAssumptionTest().isEnvironmentWithSQLANSI()) {
				throw new BusinessException(e.getMessage(), e.getCause());
			}
		}
    }
	
	@Test(expected=BusinessException.class)
	public void when_hasAProduct_save_anIdenticalProduct_shouldBeThrowException() throws BusinessException {
		String name = "myProduct";
		Product aProduct = ProductTestData.createProduct(this.systemTestFixture.monsoy, this.systemTestFixture.soy, this.systemTestFixture.intacta, StatusEnum.ACTIVE, this.systemTestFixture.monsantoBr);
		aProduct.setDescription(name);
		getSession().saveOrUpdate(aProduct);
		getSession().flush();
		
		Product anotherProduct = ProductTestData.createProduct(this.systemTestFixture.monsoy, this.systemTestFixture.soy, this.systemTestFixture.intacta, StatusEnum.ACTIVE, this.systemTestFixture.monsantoBr);
		anotherProduct.setDescription(name);
		dao.save(anotherProduct);
		
		Assert.fail("Shoud be throw a BusinessException");
	}


}
