package com.monsanto.brazilvaluecapture.core.grower;

import java.io.InputStream;
import java.util.List;
import java.util.Locale;
import java.util.ResourceBundle;

import com.monsanto.brazilvaluecapture.core.grower.service.impl.GrowerFileParserBrazil;
import junit.framework.Assert;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.monsanto.brazilvaluecapture.core.base.SystemTestFixture;
import com.monsanto.brazilvaluecapture.core.base.model.bean.AbstractAddress;
import com.monsanto.brazilvaluecapture.core.base.service.BaseService;
import com.monsanto.brazilvaluecapture.core.foundation.test.AbstractServiceIntegrationTests;
import com.monsanto.brazilvaluecapture.core.foundation.util.csv.CSVReadableInvalidException;
import com.monsanto.brazilvaluecapture.core.foundation.util.parser.ParsedLineResult;
import com.monsanto.brazilvaluecapture.core.grower.model.bean.Grower;
import com.monsanto.brazilvaluecapture.core.grower.service.impl.GrowerFileParser;

public class CSVGrowerReader_AT extends AbstractServiceIntegrationTests{

    private static final String LOGIN = "stuart";

	@Autowired
	private BaseService baseService;
	
	private GrowerFileParser fileparser;
	
	private InputStream inputFileSuccess = getClass().getClassLoader().getResourceAsStream("csv/grower_test_success_pt_BR.csv");
	
	private InputStream inputFileError = getClass().getClassLoader().getResourceAsStream("csv/grower_test_error_pt_BR.csv");
	
	private ResourceBundle resourceBundle = ResourceBundle.getBundle("bundle/bundle");

	private Locale localeBR = new Locale("pt", "BR");
	
	@Before
	public void init(){
		systemTestFixture = new SystemTestFixture(this);
	}

	@After
	public void tearDown() {
		logger.info(fileparser.getResultAsString(resourceBundle));
	}
	
	@Test
	@SuppressWarnings("unchecked")
	public void when_i_have_a_valid_imported_growers_file_must_save_ten_growers() throws CSVReadableInvalidException{
		fileparser = new GrowerFileParserBrazil(inputFileSuccess,localeBR,baseService,LOGIN);
		fileparser.readFile();
		fileparser.process();
		
		Assert.assertEquals("Should not have error at import of growers", 0, fileparser.getErrorLines());

		for (Grower grower : (List<Grower>) getSession().createQuery("from Grower where email like '%@email.com'").list()) {
			assertAddressNotNull("Billing Address", grower.getBillingAddress());
			assertAddressNotNull("Businness Address", grower.getBusinessAddress());
		}
	}

	@Test
	public void when_i_have_a_imported_growers_file_with_errors_shouldReturnSpecificWarnings() throws CSVReadableInvalidException{
		fileparser = new GrowerFileParserBrazil(inputFileError,localeBR,baseService,LOGIN);
		fileparser.readFile();
		
		for (ParsedLineResult parse : fileparser.getGrowerParserResult().getWarnings()){
			System.out.println("Error line " + parse.getLine() + " code warning " + parse.getCodeWarn() + " Field " + parse.getField());
		}
		Assert.assertTrue("Should have warning", fileparser.getErrorLines() > 0);
		Assert.assertEquals("Should have no success lines", 0, fileparser.getSuccessLines());
		fileparser.process();
		Assert.assertEquals(0, fileparser.getErrorLines());
	}
	
	@Test
	public void when_i_have_a_imported_file_with_no_success_lines_should_not_show_success_message() throws CSVReadableInvalidException {
		fileparser = new GrowerFileParserBrazil(inputFileError,localeBR,baseService,LOGIN);
		fileparser.readFile();
		fileparser.process();
		
		Assert.assertEquals("Should have no success lines", 0, fileparser.getSuccessLines());
		Assert.assertTrue("Should not have success message", fileparser.getResultAsString(resourceBundle).indexOf("Importação realizada com sucesso!") == -1);
	}
	
	private void assertAddressNotNull(String addressName, AbstractAddress billingAddress) {
		Assert.assertNotNull(addressName + " cannot be Empty", billingAddress);
		Assert.assertNotNull(addressName + " City cannot be Empty", billingAddress.getCity());
		Assert.assertNotNull(addressName + " Country cannot be Empty", billingAddress.getCountry());
		Assert.assertNotNull(addressName + " State cannot be Empty", billingAddress.getState());
	}
	
}