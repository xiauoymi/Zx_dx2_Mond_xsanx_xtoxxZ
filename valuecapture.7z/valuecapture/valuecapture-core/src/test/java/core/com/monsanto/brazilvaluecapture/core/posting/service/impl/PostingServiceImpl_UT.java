package com.monsanto.brazilvaluecapture.core.posting.service.impl;

import com.google.common.collect.Lists;
import com.monsanto.brazilvaluecapture.core.base.model.dao.TechnologyDAO;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Technology;
import com.monsanto.brazilvaluecapture.core.foundation.service.BusinessException;
import com.monsanto.brazilvaluecapture.core.foundation.util.CalendarUtil;
import com.monsanto.brazilvaluecapture.core.posting.model.bean.Posting;
import com.monsanto.brazilvaluecapture.core.posting.model.bean.PostingReference;
import com.monsanto.brazilvaluecapture.core.posting.model.bean.ReferenceNameEnum;
import com.monsanto.brazilvaluecapture.core.posting.model.dao.PostingDAO;
import com.monsanto.brazilvaluecapture.core.posting.model.dao.PostingReferenceDAO;
import com.monsanto.brazilvaluecapture.osb.its.api.InfraException;
import com.monsanto.brazilvaluecapture.osb.its.api.PostingDocument;
import com.monsanto.brazilvaluecapture.seedsale.posting.osb.OsbBonusPostingService;
import com.monsanto.brazilvaluecapture.utils.DateUtils;
import junit.framework.Assert;
import org.joda.time.DateTime;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import static junit.framework.Assert.assertEquals;
import static junit.framework.Assert.fail;
import static org.mockito.Mockito.*;
import static org.mockito.MockitoAnnotations.initMocks;

@RunWith(MockitoJUnitRunner.class)
public class PostingServiceImpl_UT {

    @Mock
    private OsbBonusPostingService osbBonusPostingService;

    @Mock
    private PostingDAO postingDAO;

    @Mock
    private PostingReferenceDAO referenceDAO;

    @Mock
    private TechnologyDAO technologyDAO;

    @InjectMocks
    private PostingServiceImpl postingService;

    @Before
    public void init() {
        postingService = spy(new PostingServiceImpl());
        initMocks(this);
        postingService.setOsbBonusPostingService(osbBonusPostingService);
    }

    @Test
    public void testSubmitAndSaveBonusPostingValueShareOsbBonusPostingServiceIsPosted_whenItIsInvokedWithValidDynamicReferenceString() throws Exception {
        BigDecimal postingValue = BigDecimal.ZERO;
        String dynamicReferenceString = "obtainer1";
        Date paymentAndFileDate = new Date();
        Technology technology = new Technology();
        List<Technology> technologyList = Lists.newArrayList(technology);
        String technologyName = "DUMMY_TECH_NAME";
        PostingDocument postingDocument = new PostingDocument("DUMMY_FI", "DUMMY_COMPANY", "DUMMY_POSTING_YEAR");
        PostingReference postingReference = new PostingReference();
        when(osbBonusPostingService.post(postingValue, getReferenceDescription(ReferenceNameEnum.VALUE_SHARE, dynamicReferenceString), paymentAndFileDate, paymentAndFileDate, technologyName)).thenReturn(postingDocument);
        when(postingService.getDateTodayPreviousMonth()).thenReturn(paymentAndFileDate);
        when(technologyDAO.findTechnologyByName(technologyName)).thenReturn(technologyList);
        when(referenceDAO.getByName(ReferenceNameEnum.VALUE_SHARE)).thenReturn(postingReference);

        postingService.submitAndSaveBonusPosting(postingValue, ReferenceNameEnum.VALUE_SHARE, dynamicReferenceString, paymentAndFileDate, paymentAndFileDate, technologyName);

        verify(osbBonusPostingService).post(postingValue, String.format("%s - %s", ReferenceNameEnum.VALUE_SHARE.getErpCode(), dynamicReferenceString), paymentAndFileDate, paymentAndFileDate, technologyName);
    }

    @Test
    public void testSubmitAndSaveBonusPostingValueShareOsbBonusPostingServiceIsPosted_whenItIsInvokedWithNullDynamicReferenceString() throws Exception {
        BigDecimal postingValue = BigDecimal.ZERO;
        Date paymentAndFileDate = new Date();
        Technology technology = new Technology();
        List<Technology> technologyList = Lists.newArrayList(technology);
        String technologyName = "DUMMY_TECH_NAME";
        PostingDocument postingDocument = new PostingDocument("DUMMY_FI", "DUMMY_COMPANY", "DUMMY_POSTING_YEAR");
        PostingReference postingReference = new PostingReference();
        when(osbBonusPostingService.post(postingValue, getReferenceDescription(ReferenceNameEnum.VALUE_SHARE, null), paymentAndFileDate, paymentAndFileDate, technologyName)).thenReturn(postingDocument);
        when(postingService.getDateTodayPreviousMonth()).thenReturn(paymentAndFileDate);
        when(technologyDAO.findTechnologyByName(technologyName)).thenReturn(technologyList);
        when(referenceDAO.getByName(ReferenceNameEnum.VALUE_SHARE)).thenReturn(postingReference);

        postingService.submitAndSaveBonusPosting(postingValue, ReferenceNameEnum.VALUE_SHARE, null, paymentAndFileDate, paymentAndFileDate, technologyName);

        verify(osbBonusPostingService).post(postingValue, ReferenceNameEnum.VALUE_SHARE.getErpCode(), paymentAndFileDate, paymentAndFileDate, technologyName);
    }

    @Test
    public void testSubmitAndSaveBonusPostingValueShareOsbBonusPostingServiceIsSaved_whenItIsInvoked() throws Exception {
        BigDecimal postingValue = BigDecimal.ZERO;
        String dynamicReferenceString = "obtainer1";
        Date paymentAndFileDate = new Date();
        Technology technology = new Technology();
        List<Technology> technologyList = Lists.newArrayList(technology);
        String technologyName = "DUMMY_TECH_NAME";
        PostingDocument postingDocument = new PostingDocument("DUMMY_FI", "DUMMY_COMPANY", "DUMMY_POSTING_YEAR");
        PostingReference postingReference = new PostingReference();
        Date postingDate = CalendarUtil.getDateNow();
        when(osbBonusPostingService.post(postingValue, getReferenceDescription(ReferenceNameEnum.VALUE_SHARE, dynamicReferenceString), paymentAndFileDate, paymentAndFileDate, technologyName)).thenReturn(postingDocument);
        when(postingService.getDateTodayPreviousMonth()).thenReturn(paymentAndFileDate);
        when(technologyDAO.findTechnologyByName(technologyName)).thenReturn(technologyList);
        when(referenceDAO.getByName(ReferenceNameEnum.VALUE_SHARE)).thenReturn(postingReference);
        when(postingService.getToday()).thenReturn(postingDate);

        postingService.submitAndSaveBonusPosting(postingValue, ReferenceNameEnum.VALUE_SHARE, dynamicReferenceString, paymentAndFileDate, paymentAndFileDate, technologyName);

        verify(postingService).savePosting(postingValue, ReferenceNameEnum.VALUE_SHARE, technologyName, postingDocument.getFiDocument(), paymentAndFileDate, postingDate);
    }

    @Test
    public void testSubmitAndSaveBonusPostingUsePaymentDateAsPostingDateWhenSavingPosting() throws Exception {
        BigDecimal postingValue = BigDecimal.ZERO;
        String dynamicReferenceString = "obtainer1";
        Date paymentAndFileDate = new DateTime().withDate(2013, 01, 11).toDate();
        Technology technology = new Technology();
        List<Technology> technologyList = Lists.newArrayList(technology);
        String technologyName = "DUMMY_TECH_NAME";
        PostingDocument postingDocument = new PostingDocument("DUMMY_FI", "DUMMY_COMPANY", "DUMMY_POSTING_YEAR");
        PostingReference postingReference = new PostingReference();
        Date postingDate = CalendarUtil.getDateNow();
        when(osbBonusPostingService.post(postingValue, getReferenceDescription(ReferenceNameEnum.VALUE_SHARE, dynamicReferenceString), paymentAndFileDate, paymentAndFileDate, technologyName)).thenReturn(postingDocument);
        when(postingService.getDateTodayPreviousMonth()).thenReturn(paymentAndFileDate);
        when(technologyDAO.findTechnologyByName(technologyName)).thenReturn(technologyList);
        when(referenceDAO.getByName(ReferenceNameEnum.VALUE_SHARE)).thenReturn(postingReference);
        when(postingService.getToday()).thenReturn(postingDate);

        postingService.submitAndSaveBonusPosting(postingValue, ReferenceNameEnum.VALUE_SHARE, dynamicReferenceString, paymentAndFileDate, paymentAndFileDate, technologyName);

        verify(postingService).savePosting(postingValue, ReferenceNameEnum.VALUE_SHARE, technologyName, postingDocument.getFiDocument(), paymentAndFileDate, postingDate);
    }

    @Test
    public void testSubmitAndSaveBonusPostingValueShareOsbBonusPostingServiceThrowsInfraException_whenPostingFails() throws Exception {
        BigDecimal postingValue = BigDecimal.ZERO;
        String dynamicReferenceString = "obtainer1";
        Date paymentAndFileDate = new Date();
        Technology technology = new Technology();
        List<Technology> technologyList = Lists.newArrayList(technology);
        String technologyName = "DUMMY_TECH_NAME";
        PostingReference postingReference = new PostingReference();
        InfraException infraException = new InfraException();
        when(osbBonusPostingService.post(postingValue, getReferenceDescription(ReferenceNameEnum.VALUE_SHARE, dynamicReferenceString), paymentAndFileDate, paymentAndFileDate, technologyName)).thenThrow(infraException);
        when(technologyDAO.findTechnologyByName(technologyName)).thenReturn(technologyList);
        when(referenceDAO.getByName(ReferenceNameEnum.VALUE_SHARE)).thenReturn(postingReference);
        when(postingService.getDateTodayPreviousMonth()).thenReturn(paymentAndFileDate);

        postingService.submitAndSaveBonusPosting(postingValue, ReferenceNameEnum.VALUE_SHARE, dynamicReferenceString, paymentAndFileDate, paymentAndFileDate, technologyName);

        verify(postingService).savePosting(postingValue, ReferenceNameEnum.VALUE_SHARE, technologyName, null, paymentAndFileDate, null);
    }

    @Test
    public void testSavePostingInvokesPostingDao_whenTechnologyAndPostingReferenceAreNotNull() throws BusinessException {
        //@Given
        BigDecimal postingValue = BigDecimal.TEN;
        ReferenceNameEnum reference = ReferenceNameEnum.ROYALTIES_REVENUE_RECOGNITION;
        String technologyName = "Intacta";
        String postingNumber = "202020";
        Date postingCreationDate = DateUtils.getLastDateOfPreviousMonth();
        PostingReference postingReference = new PostingReference();
        when(referenceDAO.getByName(reference)).thenReturn(postingReference);
        Technology technology = new Technology();
        technology.setDescription(technologyName);
        List<Technology> technologyList = Lists.newArrayList(technology);

        Date postingDate = new Date();
        when(technologyDAO.findTechnologyByName(technologyName)).thenReturn(technologyList);
        Posting posting = new Posting(postingReference, postingValue, technology, Posting.PostingOrigin.AUTOMATIC, postingCreationDate, postingNumber, postingDate);
        //@When
        postingService.savePosting(postingValue, reference, technologyName, postingNumber, postingCreationDate, postingDate);
        //@Then
        verify(postingDAO).save(posting);
    }

    @Test
    public void testSavePostingPostingCreationDateEqualsPostingCreationDateParameter_whenMethodIsInvoked() throws BusinessException {
        //@Given
        BigDecimal postingValue = BigDecimal.TEN;
        ReferenceNameEnum reference = ReferenceNameEnum.ROYALTIES_REVENUE_RECOGNITION;
        String technologyName = "Intacta";
        String postingNumber = "202020";
        Date postingCreationDate = DateUtils.getLastDateOfPreviousMonth();
        PostingReference postingReference = new PostingReference();
        when(referenceDAO.getByName(reference)).thenReturn(postingReference);
        Technology technology = new Technology();
        technology.setDescription(technologyName);
        List<Technology> technologyList = Lists.newArrayList(technology);
        when(technologyDAO.findTechnologyByName(technologyName)).thenReturn(technologyList);
        ArgumentCaptor<Posting> postingArgumentCaptor = ArgumentCaptor.forClass(Posting.class);
        doNothing().when(postingDAO).save(postingArgumentCaptor.capture());
        Date postingDate = new Date();
        //@When
        postingService.savePosting(postingValue, reference, technologyName, postingNumber, postingCreationDate, postingDate);
        //@Then
        assertEquals(postingArgumentCaptor.getValue().getPostingCreationDate(), postingCreationDate);
    }

    @Test
    public void testSavePostingPostingDateEqualsCalendarUtilGetDateNow_whenMethodIsInvoked() throws BusinessException {
        //@Given
        BigDecimal postingValue = BigDecimal.TEN;
        ReferenceNameEnum reference = ReferenceNameEnum.ROYALTIES_REVENUE_RECOGNITION;
        String technologyName = "Intacta";
        String postingNumber = "202020";
        Date postingCreationDate = DateUtils.getLastDateOfPreviousMonth();
        PostingReference postingReference = new PostingReference();
        when(referenceDAO.getByName(reference)).thenReturn(postingReference);
        Technology technology = new Technology();
        technology.setDescription(technologyName);
        List<Technology> technologyList = Lists.newArrayList(technology);
        when(technologyDAO.findTechnologyByName(technologyName)).thenReturn(technologyList);
        ArgumentCaptor<Posting> postingArgumentCaptor = ArgumentCaptor.forClass(Posting.class);
        doNothing().when(postingDAO).save(postingArgumentCaptor.capture());
        Date dateNow = CalendarUtil.getDateNow();
        //@When
        postingService.savePosting(postingValue, reference, technologyName, postingNumber, postingCreationDate, dateNow);
        //@Then
        assertEquals(postingArgumentCaptor.getValue().getPostingDate(), dateNow);
    }

    @Test
    public void testSavePostingShouldThrowBusinessException_whenTechnologyIsNull() {
        //@Given
        BigDecimal postingValue = BigDecimal.TEN;
        ReferenceNameEnum reference = ReferenceNameEnum.ROYALTIES_REVENUE_RECOGNITION;
        String technologyName = "SOME_TECHNOLOGY";
        String postingNumber = "202020";
        Date postingCreationDate = DateUtils.getLastDateOfPreviousMonth();
        PostingReference postingReference = new PostingReference();
        when(referenceDAO.getByName(reference)).thenReturn(postingReference);
        List<Technology> technologyList = Lists.newArrayList();
        when(technologyDAO.findTechnologyByName(technologyName)).thenReturn(technologyList);
        //@When
        try {
            postingService.savePosting(postingValue, reference, technologyName, postingNumber, postingCreationDate, new Date());
            fail("BusinessException must be thrown");
        } catch (BusinessException e) {
            //@Then
            assertEquals(e.getMessage(), "Input data error, either the technology or the posting reference are wrong");
        }
    }

    @Test
    public void testSavePostingShouldThrowBusinessException_whenPostingReferenceIsNull() {
        //@Given
        BigDecimal postingValue = BigDecimal.TEN;
        ReferenceNameEnum reference = ReferenceNameEnum.ROYALTIES_REVENUE_RECOGNITION;
        String technologyName = "SOME_TECHNOLOGY";
        String postingNumber = "202020";
        Date postingCreationDate = DateUtils.getLastDateOfPreviousMonth();
        when(referenceDAO.getByName(reference)).thenReturn(null);
        Technology technology = new Technology();
        technology.setDescription(technologyName);
        List<Technology> technologyList = Lists.newArrayList(technology);
        when(technologyDAO.findTechnologyByName(technologyName)).thenReturn(technologyList);
        //@When
        try {
            postingService.savePosting(postingValue, reference, technologyName, postingNumber, postingCreationDate, new Date());
            fail("BusinessException must be thrown");
        } catch (BusinessException e) {
            //@Then
            assertEquals(e.getMessage(), "Input data error, either the technology or the posting reference are wrong");
        }
    }

    private String getReferenceDescription(ReferenceNameEnum reference, String referenceExtendedDescription) {
        if (referenceExtendedDescription != null) {
            return String.format("%s - %s", reference.getErpCode(), referenceExtendedDescription);
        } else {
            return reference.getErpCode();
        }
    }


    @Test
    public void testSubmitAndSavePostingWhenFailsVerifyPaymentCreationDate_SubmitAndSavePosting() throws InfraException, BusinessException {

        try {
            Technology technology = new Technology();
            List<Technology> technologyList = Lists.newArrayList(technology);
            String technologyName = same(OsbBonusPostingService.DEFAULT_TECHNOLOGY);
            PostingReference postingReference = new PostingReference();

            when(technologyDAO.findTechnologyByName(technologyName)).thenReturn(technologyList);
            when(referenceDAO.getByName(ReferenceNameEnum.VALUE_SHARE)).thenReturn(postingReference);
            when(osbBonusPostingService.post(any(BigDecimal.class), anyString(), any(Date.class), any(Date.class), same(OsbBonusPostingService.DEFAULT_TECHNOLOGY))).thenThrow(InfraException.class);

            ArgumentCaptor<Posting> postingArgumentCaptor = ArgumentCaptor.forClass(Posting.class);
            doNothing().when(postingDAO).save(postingArgumentCaptor.capture());

            postingService.submitAndSaveBonusPosting(new BigDecimal(1234567890), ReferenceNameEnum.VALUE_SHARE, null, new Date(), new Date(), OsbBonusPostingService.DEFAULT_TECHNOLOGY);

            Assert.assertNotNull(postingArgumentCaptor.getValue().getPostingCreationDate());
            Assert.assertNull(postingArgumentCaptor.getValue().getPostingDate());

            verify(osbBonusPostingService).post(any(BigDecimal.class), anyString(), any(Date.class), any(Date.class), same(OsbBonusPostingService.DEFAULT_TECHNOLOGY));
        } catch (InfraException e) {
            Assert.fail("Shouldn't fail");
        } catch (BusinessException e) {
            Assert.fail("Shouldn't fail");
        }

    }


    @Test
    public void testSubmitAndSavePostingWhenWorksVerifyPaymentCreationDate_SubmitAndSavePosting() throws InfraException, BusinessException {

        try {

            Technology technology = new Technology();
            List<Technology> technologyList = Lists.newArrayList(technology);
            String technologyName = same(OsbBonusPostingService.DEFAULT_TECHNOLOGY);
            PostingReference postingReference = new PostingReference();

            when(technologyDAO.findTechnologyByName(technologyName)).thenReturn(technologyList);
            when(referenceDAO.getByName(ReferenceNameEnum.VALUE_SHARE)).thenReturn(postingReference);
            PostingDocument postingDocument = new PostingDocument("DUMMY_FI", "DUMMY_COMPANY", "DUMMY_POSTING_YEAR");
            when(osbBonusPostingService.post(any(BigDecimal.class), anyString(), any(Date.class), any(Date.class), same(OsbBonusPostingService.DEFAULT_TECHNOLOGY))).thenReturn(postingDocument);

            ArgumentCaptor<Posting> postingArgumentCaptor = ArgumentCaptor.forClass(Posting.class);
            doNothing().when(postingDAO).save(postingArgumentCaptor.capture());

            postingService.submitAndSaveBonusPosting(new BigDecimal(1234567890), ReferenceNameEnum.VALUE_SHARE, null, new Date(), new Date(), OsbBonusPostingService.DEFAULT_TECHNOLOGY);

            Assert.assertNotNull(postingArgumentCaptor.getValue().getPostingDate());
            Assert.assertNotNull(postingArgumentCaptor.getValue().getPostingCreationDate());

            verify(osbBonusPostingService).post(any(BigDecimal.class), anyString(), any(Date.class), any(Date.class), same(OsbBonusPostingService.DEFAULT_TECHNOLOGY));
        } catch (InfraException e) {
            Assert.fail("Shouldn't fail");
        } catch (BusinessException e) {
            Assert.fail("Shouldn't fail");
        }

    }

}
