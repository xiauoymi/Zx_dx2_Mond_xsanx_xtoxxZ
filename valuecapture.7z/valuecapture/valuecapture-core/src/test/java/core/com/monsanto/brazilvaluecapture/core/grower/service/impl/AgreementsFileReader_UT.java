package com.monsanto.brazilvaluecapture.core.grower.service.impl;

import com.monsanto.brazilvaluecapture.core.foundation.service.BusinessException;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.io.IOException;
import java.io.InputStream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

import static junit.framework.Assert.fail;
import static org.fest.reflect.core.Reflection.field;
import static org.mockito.Mockito.*;

/**
 * Created by IntelliJ IDEA.
 * User: LSCHW1
 */

public class AgreementsFileReader_UT {


    private AgreementsFileReader agreementsFileReader;
    private ZipInputStream zipInputStream;

    @Before
    public void setUp() throws IOException {

        agreementsFileReader=new AgreementsFileReader(mock(InputStream.class));

        zipInputStream=mock(ZipInputStream.class);
        field("zis").ofType(ZipInputStream.class).in(agreementsFileReader).set(zipInputStream);
    }

    @Test
    public void readNextEntry_ShouldReturnNull_WhenNoMoreEntries() throws IOException, BusinessException {

        when(zipInputStream.getNextEntry()).thenReturn(null);

        FileEntry fileEntry=agreementsFileReader.readNextEntry();

        Assert.assertNull(fileEntry);
    }

    @Test
    public void readNextEntry_ShouldReturnUnsupportedCharsetFileEntry_WhenEntryNameCharsetIsNotSupport() throws IOException, BusinessException {
        doThrow(IllegalArgumentException.class).when(zipInputStream).getNextEntry();

        FileEntry fileEntry=agreementsFileReader.readNextEntry();

        Assert.assertNotNull(fileEntry);
        Assert.assertTrue(fileEntry.isCharsetUnsupported());
    }

     @Test
    public void readNextEntry_ShouldThrownBusinessException_WhenCannotReadEntry() throws IOException {
        doThrow(IOException.class).when(zipInputStream).getNextEntry();

        FileEntry fileEntry=null;
        try{
            fileEntry=agreementsFileReader.readNextEntry();
            fail();
        }catch (BusinessException e){
            Assert.assertNull(fileEntry);
        }
    }

    @Test
    public void readNextEntry_ShouldReturnValidFileEntry_WhenCanReadNextEntry() throws IOException, BusinessException {
        ZipEntry ze=new ZipEntry("name");
        when(zipInputStream.getNextEntry()).thenReturn(ze);

        FileEntry fileEntry=agreementsFileReader.readNextEntry();

        Assert.assertNotNull(fileEntry);
        Assert.assertFalse(fileEntry.isCharsetUnsupported());
    }

    @Test
    public void closeQuietly_ShouldNotThrowException_WhenFileNotExists() throws IOException {
        zipInputStream=null;
        field("zis").ofType(ZipInputStream.class).in(agreementsFileReader).set(zipInputStream);

        try{

            agreementsFileReader.closeQuietly();

            Assert.assertTrue(true);
        }catch (Exception e){
            fail();
        }
    }

    @Test
    public void closeQuietly_ShouldCloseFileAndLastEntry_WhenFileExists() throws IOException {

        agreementsFileReader.closeQuietly();

        verify(zipInputStream, atLeastOnce()).closeEntry();
        verify(zipInputStream, atLeastOnce()).close();
    }

}
