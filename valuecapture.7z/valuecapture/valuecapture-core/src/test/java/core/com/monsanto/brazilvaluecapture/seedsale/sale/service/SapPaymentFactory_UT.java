package com.monsanto.brazilvaluecapture.seedsale.sale.service;


import com.monsanto.brazilvaluecapture.osb.its.sappaymentsregistration.bean.YtyPymntAdvice;
import com.monsanto.brazilvaluecapture.seedsale.billing.model.bean.Billing;
import com.monsanto.brazilvaluecapture.seedsale.billing.model.bean.PaymentStatus;
import com.monsanto.brazilvaluecapture.seedsale.billing.service.BillingConstraintViolationException;
import com.monsanto.brazilvaluecapture.seedsale.template.model.bean.SaleTemplatePaymentMethodEnum;
import org.junit.Before;
import org.junit.Test;

import java.text.MessageFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import static org.fest.assertions.Assertions.assertThat;
/**
 * Created by HGFIOR on 30/06/2014.
 */
public class SapPaymentFactory_UT {

    public static final String DATE_FORMAT = "yyyy-MM-dd";
    public static final String VALID_YFIDOC = "11111111111111";
    public static final String VALID_SALE_ID = "1";
    public static final String VALID_INVOICE_NUMBER = "2222222222";
    public static final String VALID_STRING_DATE = "2014-06-17";
    public static final String GRAIN_TRADE_ORDER_TYPE = "G";
    public static final String PAID_STATUS = "PAGADO";
    public static final String INVOICED_PAYMENT_STATUS = "FACTURADO";
    public static final String SIGNED_PAYMENT_STATUS = "FIRMADO";
    public static final String NOT_EXPECTED_PAYMENT_METHOD = "NOT_EXPECTED";
    public static final String SETTLED_PAYMENT_METHOD = "LIQUIDADO";
    private SapPaymentFactory factory;
    private Billing billing;
    private YtyPymntAdvice paymentAdvice;

    @Before
    public void setUp(){
        factory = new SapPaymentFactory();
        billing = new Billing();
        paymentAdvice = new YtyPymntAdvice();
        paymentAdvice.setYfiDoc(VALID_YFIDOC);
        paymentAdvice.setYidTransVc(VALID_SALE_ID);
        paymentAdvice.setYlegalNumber(VALID_INVOICE_NUMBER);
        paymentAdvice.setYpaidDate(VALID_STRING_DATE);
        paymentAdvice.setYsalesOrderType(GRAIN_TRADE_ORDER_TYPE);
    }

    @Test
    public void testFactoryReturnAPaidSapPaymentWhenPaymentIsFullyPaid() throws BillingConstraintViolationException {
        paymentAdvice.setYstatus(PAID_STATUS);
        AbstractSapPayment payment = factory.build(paymentAdvice, billing);
        assertThat(payment).isInstanceOf(SapPaidPayment.class);
        assertThat(payment.getPaymentMethod()).isEqualTo(SaleTemplatePaymentMethodEnum.GRAIN_TRADE);
        assertThat(payment.getPaymentStatus()).isEqualTo(PaymentStatus.FULLY_PAID);
        assertThat(payment.getyFiDoc()).isSameAs(VALID_YFIDOC);
        assertThat(payment.getInvoiceNumber()).isSameAs(VALID_INVOICE_NUMBER);
        assertThat(payment.getBilling()).isSameAs(billing);
        assertThat(payment.getPaymentDate()).isEqualTo(getDate(paymentAdvice.getYpaidDate()));
    }

    @Test
    public void testFactoryReturnAInvoicedSapPaymentWhenPaymentIsInvoiced() throws BillingConstraintViolationException {
        paymentAdvice.setYstatus(INVOICED_PAYMENT_STATUS);
        AbstractSapPayment payment = factory.build(paymentAdvice, billing);
        assertThat(payment).isInstanceOf(SapInvoicedPayment.class);
        assertThat(payment.getPaymentMethod()).isEqualTo(SaleTemplatePaymentMethodEnum.GRAIN_TRADE);
        assertThat(payment.getPaymentStatus()).isEqualTo(PaymentStatus.INVOICED);
        assertThat(payment.getyFiDoc()).isSameAs(VALID_YFIDOC);
        assertThat(payment.getInvoiceNumber()).isSameAs(VALID_INVOICE_NUMBER);
        assertThat(payment.getBilling()).isSameAs(billing);
        assertThat(payment.getPaymentDate()).isEqualTo(getDate(paymentAdvice.getYpaidDate()));
    }

    @Test
    public void testFactoryReturnASignedSapPaymentWhenPaymentIsSigned() throws BillingConstraintViolationException {
        paymentAdvice.setYstatus(SIGNED_PAYMENT_STATUS);
        AbstractSapPayment payment = factory.build(paymentAdvice, billing);
        assertThat(payment).isInstanceOf(SapSignedPayment.class);
        assertThat(payment.getPaymentMethod()).isEqualTo(SaleTemplatePaymentMethodEnum.GRAIN_TRADE);
        assertThat(payment.getPaymentStatus()).isEqualTo(PaymentStatus.SIGNED);
        assertThat(payment.getyFiDoc()).isSameAs(VALID_YFIDOC);
        assertThat(payment.getInvoiceNumber()).isSameAs(VALID_INVOICE_NUMBER);
        assertThat(payment.getBilling()).isSameAs(billing);
        assertThat(payment.getPaymentDate()).isEqualTo(getDate(paymentAdvice.getYpaidDate()));
    }

    @Test
    public void testFactoryReturnASettledSapPaymentWhenPaymentIsSettled() throws BillingConstraintViolationException {
        paymentAdvice.setYstatus(SETTLED_PAYMENT_METHOD);
        AbstractSapPayment payment = factory.build(paymentAdvice, billing);
        assertThat(payment).isInstanceOf(SapSettledPayment.class);
        assertThat(payment.getPaymentMethod()).isEqualTo(SaleTemplatePaymentMethodEnum.GRAIN_TRADE);
        assertThat(payment.getPaymentStatus()).isEqualTo(PaymentStatus.SETTLED);
        assertThat(payment.getyFiDoc()).isSameAs(VALID_YFIDOC);
        assertThat(payment.getInvoiceNumber()).isSameAs(VALID_INVOICE_NUMBER);
        assertThat(payment.getBilling()).isSameAs(billing);
        assertThat(payment.getPaymentDate()).isEqualTo(getDate(paymentAdvice.getYpaidDate()));
    }

    @Test
    public void testFactoryReturnADefaultSapPaymentWhenPaymentIsNotExpected() throws BillingConstraintViolationException {
        paymentAdvice.setYstatus(NOT_EXPECTED_PAYMENT_METHOD);
        AbstractSapPayment payment = factory.build(paymentAdvice, billing);
        assertThat(payment).isInstanceOf(SapDefaultPayment.class);
        assertThat(payment.getPaymentMethod()).isEqualTo(SaleTemplatePaymentMethodEnum.GRAIN_TRADE);
        assertThat(payment.getPaymentStatus()).isEqualTo(PaymentStatus.SETTLED);
        assertThat(payment.getyFiDoc()).isSameAs(VALID_YFIDOC);
        assertThat(payment.getInvoiceNumber()).isSameAs(VALID_INVOICE_NUMBER);
        assertThat(payment.getBilling()).isSameAs(billing);
        assertThat(payment.getPaymentDate()).isEqualTo(getDate(paymentAdvice.getYpaidDate()));
    }

    private Object getDate(String ypaidDate) throws BillingConstraintViolationException {
        Date paymentDate = null;
        try {
            paymentDate = new SimpleDateFormat(DATE_FORMAT).parse(ypaidDate);
        } catch (ParseException e) {
            throw new BillingConstraintViolationException(MessageFormat.format("Date Format Error in: {0}, the format should be: {1}", ypaidDate, DATE_FORMAT));
        }
        return paymentDate;
    }
}
