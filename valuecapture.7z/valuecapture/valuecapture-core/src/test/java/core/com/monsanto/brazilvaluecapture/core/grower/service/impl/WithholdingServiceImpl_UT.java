package com.monsanto.brazilvaluecapture.core.grower.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.mockito.internal.verification.VerificationModeFactory;
import static org.fest.reflect.core.Reflection.field;

import com.monsanto.brazilvaluecapture.core.grower.model.bean.Grower;
import com.monsanto.brazilvaluecapture.core.grower.model.bean.Withholding;
import com.monsanto.brazilvaluecapture.core.grower.model.bean.WithholdingAudit;
import com.monsanto.brazilvaluecapture.core.grower.model.dao.WithholdingDAO;
import com.monsanto.brazilvaluecapture.core.grower.service.WithholdingService;

@RunWith(MockitoJUnitRunner.class)
public class WithholdingServiceImpl_UT {

	@Mock
	private WithholdingDAO withholdingDAO;
	
	private WithholdingService withholdingService;
	
	Grower grower = Mockito.mock(Grower.class);
	Withholding withholding = Mockito.mock(Withholding.class);;
	WithholdingAudit withholdingAudit = Mockito.mock(WithholdingAudit.class);

	@Before
	public void setUp() throws Exception {
		withholdingService = new WithholdingServiceImpl();
		Mockito.when(withholdingDAO.searchByGrower(grower)).thenReturn(withholding);
		Mockito.doNothing().when(withholdingDAO).delete(withholding);
		Mockito.doNothing().when(withholdingDAO).save(withholding);
		Mockito.doNothing().when(withholdingDAO).saveAudit(withholdingAudit);
		field("withholdingDAO").ofType(WithholdingDAO.class).in(withholdingService).set(withholdingDAO);
	}

	@Test
	public void testSave_WithoutDeletePreviousWithholding() {
		List<Withholding> listWithholding = new ArrayList<Withholding>();
		withholding.setGrower(grower);
		listWithholding.add(withholding );
		withholdingService.save(listWithholding);
		
		Mockito.verify(withholdingDAO,VerificationModeFactory.times(1)).save(withholding);
	}
	
	@Test
	public void testSave_DeleteingPreviousWithholding() {
		List<Withholding> listWithholding = new ArrayList<Withholding>();
		Grower grower = new Grower();
		Withholding withholding = new Withholding();
		withholding.setGrower(grower);
		listWithholding.add(withholding );
		Mockito.when(withholdingDAO.searchByGrower(grower)).thenReturn(withholding);
		withholdingService.save(listWithholding);
		
		Mockito.verify(withholdingDAO,VerificationModeFactory.times(1)).clearWithholdings();
	}

}
