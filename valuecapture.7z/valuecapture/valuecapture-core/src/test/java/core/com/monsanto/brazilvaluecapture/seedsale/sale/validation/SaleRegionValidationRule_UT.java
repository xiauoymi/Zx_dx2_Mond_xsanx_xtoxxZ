package com.monsanto.brazilvaluecapture.seedsale.sale.validation;

import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.Sale;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.SaleItem;
import com.monsanto.brazilvaluecapture.seedsale.template.model.bean.SaleTemplate;
import com.monsanto.brazilvaluecapture.seedsale.template.model.bean.SaleTemplateCreditCalculationEnum;
import org.junit.Test;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

import static junit.framework.Assert.fail;
import static org.fest.assertions.Assertions.assertThat;

public class SaleRegionValidationRule_UT {

    @Test
    public void given_a_saletemplate_that_requires_a_region_given_a_sale_without_region_validation_fails() {
        //@Given
        SaleTemplate saleTemplate = new SaleTemplate();
        saleTemplate.setCreditCalculation(SaleTemplateCreditCalculationEnum.BY_REGION_OF_PLANTATION);
        SaleItem saleItem = new SaleItem();
        saleItem.setSaleTemplate(saleTemplate);
        Set<SaleItem> saleItems = new HashSet<SaleItem>(Arrays.asList(saleItem));
        Sale sale = new Sale();
        sale.setItems(saleItems);

        //@When
        SaleRegionValidationRule saleRegionValidationRule = new SaleRegionValidationRule();
        try {
            saleRegionValidationRule.validate(sale);
            fail("Should fail with SaleValidationException");
        } catch (Exception e) {
            //@Should
            assertThat(e).isInstanceOf(SaleValidationException.class).hasNoCause();
        }
    }
}
