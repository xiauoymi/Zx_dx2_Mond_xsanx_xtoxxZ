package com.monsanto.brazilvaluecapture.seedsale.sale.validation;

import com.monsanto.brazilvaluecapture.core.base.model.bean.Company;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Technology;
import com.monsanto.brazilvaluecapture.core.grower.model.bean.Agreement;
import com.monsanto.brazilvaluecapture.core.grower.service.AgreementService;
import com.monsanto.brazilvaluecapture.core.grower.service.impl.AgreementServiceImpl;
import com.monsanto.brazilvaluecapture.seedsale.product.model.bean.Product;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.Sale;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.SaleItem;
import org.junit.Test;

import java.util.*;

import static junit.framework.Assert.fail;
import static org.fest.assertions.Assertions.assertThat;
import static org.fest.reflect.core.Reflection.field;
import static org.mockito.Mockito.*;

/**
 * Created with IntelliJ IDEA.
 * User: IFERN1
 * Date: 11/19/13
 * Time: 9:14 AM
 * To change this template use File | Settings | File Templates.
 */
public class GrowerGLAValidationRule_UT {
    private AgreementService agreementService;

    @Test
    public void given_a_grower_without_licence_given_a_product_validation_fails() {
        //@Given
        Sale sale = new Sale();
        sale.setGrower(null);
        GrowerGLAValidationRule growerGLAValidationRule = new GrowerGLAValidationRule();
        agreementService = spy(new AgreementServiceImpl());
        field("agreementService").ofType(AgreementService.class).in(growerGLAValidationRule).set(agreementService);
        List<Agreement> list = new ArrayList<Agreement>();
        doReturn(list).when(agreementService).getActiveAgreementsByGrower(null);

        Product mockProduct = mock(Product.class);
        Technology mockTechnology = mock(Technology.class);
        Company mockCompany = mock(Company.class);
        doReturn("technologyDescription").when(mockTechnology).getDescription();
        doReturn(mockTechnology).when(mockProduct).getTechnology();
        doReturn(mockCompany).when(mockTechnology).getCompany();
        doReturn("companyDescription").when(mockCompany).getDescription();

        SaleItem saleItem = new SaleItem();
        saleItem.setProduct(mockProduct);
        Set<SaleItem> saleItems = new HashSet<SaleItem>(Arrays.asList(saleItem));
        sale.setItems(saleItems);

        //@When
        try {
            growerGLAValidationRule.validate(sale);
            fail("Should fail with SaleValidationException");
        } catch (Exception e) {
            //@Should
            assertThat(e).isInstanceOf(SaleValidationException.class).hasNoCause();
        }
    }
}
