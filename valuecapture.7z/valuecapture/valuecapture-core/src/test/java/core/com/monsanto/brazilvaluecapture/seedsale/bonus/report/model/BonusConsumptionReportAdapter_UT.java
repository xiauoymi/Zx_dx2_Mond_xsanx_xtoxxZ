package com.monsanto.brazilvaluecapture.seedsale.bonus.report.model;

import com.google.common.collect.Lists;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Company;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Crop;
import com.monsanto.brazilvaluecapture.core.grower.model.bean.BonusConsumption;
import com.monsanto.brazilvaluecapture.core.grower.model.bean.BonusConsumptionPayment;
import com.monsanto.brazilvaluecapture.core.grower.model.bean.BonusConsumptionReversal;
import com.monsanto.brazilvaluecapture.core.grower.model.bean.BonusConsumptionStatusEnum;
import com.monsanto.brazilvaluecapture.utils.ResourceBundleStub;
import junit.framework.Assert;
import org.junit.Before;
import org.junit.Test;

import java.math.BigDecimal;
import java.util.*;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

/**
 * Created by AJMILD1 on 18/11/2014.
 */
public class BonusConsumptionReportAdapter_UT {

    public static final int EXPECTED_ONE = 1;
    private static final int EXPECTED_TWO = 2;
    public static final String DUMMY_REVERSAL_COMMENT = "DUMMY_REVERSAL_COMMENT";
    public static final String DUMMY_REVERSAL_REVERSED_USER = "DUMMY_REVERSAL_REVERSED_USER";
    public static final long REVERSED_AMOUNT = 10l;
    private static final long PAID_AMOUNT = 10l;
    private static final String DUMMY_PAID_USER_ID = "DUMMY_PAID_USER_ID";
    private static final int EXPECTED_THREE = 3;
    private Map<String, String> properties;

    BonusConsumptionReportAdapter adapter;
    List<BonusConsumptionReversal> reversals;
    List<BonusConsumptionPayment> payments;

    @Before
    public void init() {
        properties = new HashMap<String, String>();
        properties.put("bonus.consumption.status.opened", "OPENED");
        properties.put("bonus.consumption.status.reversed", "REVERSED");
        properties.put("bonus.consumption.status.partial_reversal", "PARTIAL_REVERSAL");
        properties.put("bonus.consumption.status.voucherReceived", "VOUCHER_RECEIVED");
        properties.put("bonus.consumption.status.paid" , "PAID");
        properties.put("bonus.consumption.status.partiallyPaid" , "PARTIALLY_PAID");
        properties.put("bonus.consumption.status.partiallyPaidReversed", "PARTIALLY_PAID_REVERSED");
        Crop crop = mock(Crop.class);
        Company company = mock(Company.class);
        ResourceBundle bundle = new ResourceBundleStub(properties);
        adapter = new BonusConsumptionReportAdapter(crop,company,bundle);

        BonusConsumptionReversal reversal = new BonusConsumptionReversal();
        reversal.setReversedDate(new Date());
        reversal.setReversedAmount(new BigDecimal(REVERSED_AMOUNT));
        reversal.setReversedComment(DUMMY_REVERSAL_COMMENT);
        reversal.setReversedUser(DUMMY_REVERSAL_REVERSED_USER);
        reversals = Lists.newArrayList(reversal);

        BonusConsumptionPayment payment = new BonusConsumptionPayment();
        payment.setPaidDate(new Date());
        payment.setPaidAmount(new BigDecimal(PAID_AMOUNT));
        payment.setPaidUserId(DUMMY_PAID_USER_ID);
        payments = Lists.newArrayList(payment);
    }
    @Test
    public void testBonusConsumptionToBonusConsumptionFullDTOAdapterGenerateOpenedRow_whenBonusComptionStautusOpened(){
        BonusConsumption bonusConsumptionsOpened = mock(BonusConsumption.class);
        bonusConsumptionsOpened.setBonusConsumptionStatus(BonusConsumptionStatusEnum.OPENED);
        int expected = EXPECTED_ONE;

        List<BonusConsumptionFullDTO> result = adapter.BonusConsumptionToBonusConsumptionFullDTOAdapter(bonusConsumptionsOpened);

        Assert.assertEquals(expected , result.size());
    }


    @Test
    public void testBonusConsumptionToBonusConsumptionFullDTOAdapterGenerateReversalRows_whenBonusComptionStautusReversed(){
        BonusConsumption bonusConsumptionsReversed = mock(BonusConsumption.class);
        when(bonusConsumptionsReversed.getBonusConsumptionStatus()).thenReturn(BonusConsumptionStatusEnum.REVERSED);
        when(bonusConsumptionsReversed.getReversed()).thenReturn(Boolean.TRUE);
        when(bonusConsumptionsReversed.getReversals()).thenReturn(reversals);
        int expected = EXPECTED_TWO;

        List<BonusConsumptionFullDTO> result = adapter.BonusConsumptionToBonusConsumptionFullDTOAdapter(bonusConsumptionsReversed);

        Assert.assertEquals(expected , result.size());
    }

    @Test
    public void testBonusConsumptionToBonusConsumptionFullDTOAdapterGeneratePaidRows_whenBonusComptionStautusPaid(){
        BonusConsumption bonusConsumptionsPaid = mock(BonusConsumption.class);
        when(bonusConsumptionsPaid.getBonusConsumptionStatus()).thenReturn(BonusConsumptionStatusEnum.PAID);
        when(bonusConsumptionsPaid.getPaid()).thenReturn(Boolean.TRUE);
        when(bonusConsumptionsPaid.getPayments()).thenReturn(payments);
        int expected = EXPECTED_TWO;

        List<BonusConsumptionFullDTO> result = adapter.BonusConsumptionToBonusConsumptionFullDTOAdapter(bonusConsumptionsPaid);

        Assert.assertEquals(expected , result.size());
    }

    @Test
    public void testBonusConsumptionToBonusConsumptionFullDTOAdapterGeneratePartiallyPaidRows_whenBonusComptionStautusPartiallyPaid(){
        BonusConsumption bonusConsumptionsPartiallyPaid= mock(BonusConsumption.class);
        when(bonusConsumptionsPartiallyPaid.getPartiallyPaid()).thenReturn(Boolean.TRUE);
        when(bonusConsumptionsPartiallyPaid.getBonusConsumptionStatus()).thenReturn(BonusConsumptionStatusEnum.PARTIALLY_PAID);
        when(bonusConsumptionsPartiallyPaid.getPayments()).thenReturn(payments);
        int expected = EXPECTED_TWO;

        List<BonusConsumptionFullDTO> result = adapter.BonusConsumptionToBonusConsumptionFullDTOAdapter(bonusConsumptionsPartiallyPaid);

        Assert.assertEquals(expected , result.size());
    }

    @Test
    public void testBonusConsumptionToBonusConsumptionFullDTOAdapterGeneratePartiallyPaidReversalRows_whenBonusComptionStautusPartiallyPaidReversed(){
        BonusConsumption bonusConsumptionsPartiallyPaidReversed= mock(BonusConsumption.class);
        when(bonusConsumptionsPartiallyPaidReversed.getPartiallyPaidReversed()).thenReturn(Boolean.TRUE);
        when(bonusConsumptionsPartiallyPaidReversed.getBonusConsumptionStatus()).thenReturn(BonusConsumptionStatusEnum.PARTIALLY_PAID_REVERSED);
        when(bonusConsumptionsPartiallyPaidReversed.getPayments()).thenReturn(payments);
        when(bonusConsumptionsPartiallyPaidReversed.getReversals()).thenReturn(reversals);
        int expected = EXPECTED_THREE;

        List<BonusConsumptionFullDTO> result = adapter.BonusConsumptionToBonusConsumptionFullDTOAdapter(bonusConsumptionsPartiallyPaidReversed);

        Assert.assertEquals(expected , result.size());
    }
}
