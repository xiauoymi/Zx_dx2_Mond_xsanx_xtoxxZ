package com.monsanto.brazilvaluecapture.core.grower.service.impl;

import com.monsanto.brazilvaluecapture.core.base.model.bean.Document;
import com.monsanto.brazilvaluecapture.core.base.service.ServiceRunnerDataService;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Customer;
import com.monsanto.brazilvaluecapture.core.foundation.model.dao.SystemParameterDAO;
import com.monsanto.brazilvaluecapture.core.foundation.util.IPrimaryKey;
import com.monsanto.brazilvaluecapture.core.grower.model.bean.Grower;
import com.monsanto.brazilvaluecapture.core.wsiconsole.bean.WsiServiceInstance;
import com.monsanto.brazilvaluecapture.osb.its.api.InfraException;
import com.monsanto.brazilvaluecapture.osb.its.api.LASVCCreateDebtDocumentService;
import com.monsanto.brazilvaluecapture.osb.its.createdebtdocument.bean.DocumentoDeuda;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.Sale;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.Date;
import java.util.Map;

import static junit.framework.Assert.*;
import static org.fest.reflect.core.Reflection.field;
import static org.mockito.Mockito.mock;


/**
 * Tests for the CreateDebtDocumentServiceRunner class
 *
 * @author Fernández, Israel
 * @since 3.1.1
 */
@RunWith(MockitoJUnitRunner.class)
public class CreateDebtDocumentServiceRunner_UT {
    @Mock
    private LASVCCreateDebtDocumentService osbService;

    @Mock
    private ServiceRunnerDataService serviceRunnerDataService;

    @InjectMocks
    CreateDebtDocumentServiceRunner createDebtDocumentServiceRunner;

    private final String SERVICE_URL_PROPERTY = "osb_lasvc_sap_debt_creation_url";
    private final String SAMPLE_CUIT = "someCUIT";
    private final String SAMPLE_PRODUCT = "someProduct";
    private final String SAMPLE_AGREEMENT = "someAgreement";
    private final DocumentoDeuda SAMPLE_DEBTDOC = new DocumentoDeuda();
    private Sale sale;

    @Before
    public void setUp() throws Exception {
        sale = new Sale(new Customer(), new Grower());
        field("id").ofType(Long.class).in(sale).set(1l);
        Mockito.when(serviceRunnerDataService.registerData(Mockito.any(WsiServiceInstance.class), Mockito.anyString(), 
    			Mockito.anyString(), Mockito.anyBoolean(), Mockito.any(Map.class), Mockito.any(Map.class), 
    			Mockito.anyBoolean(), Mockito.any(Date.class), Mockito.any(Date.class),Mockito.any(IPrimaryKey.class))).thenReturn(new WsiServiceInstance());
    }

    @Test
    public void testGetServiceURLProperty() throws Exception {
        String expectedServiceURLProperty = SERVICE_URL_PROPERTY;
        assertEquals(expectedServiceURLProperty, BaseDebtDocumentServiceRunner.getServiceURLProperty());
    }

    @Test
    public void testProperties() {
        String expectedCUIT = "someCUIT";
        createDebtDocumentServiceRunner.setCuit(expectedCUIT);
        assertEquals(expectedCUIT, createDebtDocumentServiceRunner.getCuit());

        String expectedProduct = "someProduct";
        createDebtDocumentServiceRunner.setProduct(expectedProduct);
        assertEquals(expectedProduct, createDebtDocumentServiceRunner.getProduct());

        String expectedAgreement = "someAgreement";
        createDebtDocumentServiceRunner.setAgreement(expectedAgreement);
        assertEquals(expectedAgreement, createDebtDocumentServiceRunner.getAgreement());

        DocumentoDeuda expectedDebtDocument = new DocumentoDeuda();
        createDebtDocumentServiceRunner.setDebtDocument(expectedDebtDocument);
        assertEquals(expectedDebtDocument, createDebtDocumentServiceRunner.getDebtDocument());
    }

    @Test
    public void testServiceNameInNotNull() {
        assertNotNull(createDebtDocumentServiceRunner.getServiceName());
    }

    @Test
    public void testOperationNameIsNotNull() {
        assertNotNull(createDebtDocumentServiceRunner.getOperationName());
    }

    @Test
    public void testServiceRunnerProperties() {
        assertFalse(createDebtDocumentServiceRunner.getIsRetry());
    }

    @Test
    public void testRunGenerateRequestAndResponseParamenters() throws Exception {
    	SystemParameterDAO systemParameterDAO = mock(SystemParameterDAO.class);
    	field("systemParameterDAO").ofType(SystemParameterDAO.class).in(createDebtDocumentServiceRunner).set(systemParameterDAO);
        //@Given a set if valid service invocation parameters
        createDebtDocumentServiceRunner.setCuit(SAMPLE_CUIT);
        createDebtDocumentServiceRunner.setProduct(SAMPLE_PRODUCT);
        createDebtDocumentServiceRunner.setAgreement(SAMPLE_AGREEMENT);
        createDebtDocumentServiceRunner.setDebtDocument(SAMPLE_DEBTDOC);
        

        //@When the service invocation occurs with no errors
        Mockito.when(osbService.createDebtDocument(SAMPLE_CUIT, SAMPLE_PRODUCT, SAMPLE_AGREEMENT,
                SAMPLE_DEBTDOC, null)).thenReturn("SERVICE_RESPONSE");
        Grower grower = new Grower();
        grower.setDocument(new Document());
        grower.setId(1L);
        grower.setCustomerSapId("1");
        grower.setName("");
        Sale sale = new Sale(new Customer(),grower);
        sale.setSaleOrderSAPId(1L);
        createDebtDocumentServiceRunner.run(sale);
        
        //@Then the service runner stores request and response parameters
        assertTrue(createDebtDocumentServiceRunner.getRequest().containsKey("cuit"));
        assertTrue(createDebtDocumentServiceRunner.getRequest().containsKey("product"));
        assertTrue(createDebtDocumentServiceRunner.getRequest().containsKey("agreement"));
        assertTrue(createDebtDocumentServiceRunner.getRequest().containsKey("debtdocument.IdCliente"));
        assertTrue(createDebtDocumentServiceRunner.getRequest().containsKey("debtdocument.RefPago"));
        assertTrue(createDebtDocumentServiceRunner.getRequest().containsKey("debtdocument.IdClienteMonsanto"));
        assertTrue(createDebtDocumentServiceRunner.getRequest().containsKey("debtdocument.Importe"));
        assertTrue(createDebtDocumentServiceRunner.getRequest().containsKey("debtdocument.Moneda"));
        assertTrue(createDebtDocumentServiceRunner.getRequest().containsKey("debtdocument.NombreCliente"));
        assertTrue(createDebtDocumentServiceRunner.getRequest().containsKey("debtdocument.Concepto"));
        assertTrue(createDebtDocumentServiceRunner.getRequest().containsKey("debtdocument.FechaVencimiento"));
        assertTrue(createDebtDocumentServiceRunner.getResponse().containsKey("response"));
        assertNotNull(createDebtDocumentServiceRunner.getRequestDate());
        assertNotNull(createDebtDocumentServiceRunner.getResponseDate());
    }

    @Test
    public void testRunGenerateRequestAndResponseParamenters_WhenErrorsOccurs() throws Exception {
        //@Given a set if valid service invocation parameters
        createDebtDocumentServiceRunner.setCuit(SAMPLE_CUIT);
        createDebtDocumentServiceRunner.setProduct(SAMPLE_PRODUCT);
        createDebtDocumentServiceRunner.setAgreement(SAMPLE_AGREEMENT);
        createDebtDocumentServiceRunner.setDebtDocument(SAMPLE_DEBTDOC);

        //@When the service invocation occurs with errors
        Mockito.when(osbService.createDebtDocument(SAMPLE_CUIT, SAMPLE_PRODUCT, SAMPLE_AGREEMENT,
                SAMPLE_DEBTDOC, null)).thenThrow(new InfraException());
        try {
            createDebtDocumentServiceRunner.run(sale);
            fail("Service Runner invocation is stubbed to throw an exception");
        } catch (Exception e) {
        }

        //@Then the service runner stores request and response parameters
        assertTrue(createDebtDocumentServiceRunner.getResponse().containsKey("ERROR_EXCEPTION"));
        assertTrue(createDebtDocumentServiceRunner.getResponse().containsKey("ERROR_EXCEPTION_MESSAGE"));
    }

    @Test
    public void testRunStatusIsUpdatedWhenNoError() throws Exception {
    	SystemParameterDAO systemParameterDAO = mock(SystemParameterDAO.class);
    	field("systemParameterDAO").ofType(SystemParameterDAO.class).in(createDebtDocumentServiceRunner).set(systemParameterDAO);
        //@Given a set if valid service invocation parameters
        createDebtDocumentServiceRunner.setCuit(SAMPLE_CUIT);
        createDebtDocumentServiceRunner.setProduct(SAMPLE_PRODUCT);
        createDebtDocumentServiceRunner.setAgreement(SAMPLE_AGREEMENT);
        createDebtDocumentServiceRunner.setDebtDocument(SAMPLE_DEBTDOC);

        //@When the service invocation occurs with no errors
        Mockito.when(osbService.createDebtDocument(SAMPLE_CUIT, SAMPLE_PRODUCT, SAMPLE_AGREEMENT,
                SAMPLE_DEBTDOC, null)).thenReturn("SERVICE_RESPONSE");
        Grower grower = new Grower();
        grower.setDocument(new Document());
        grower.setId(1L);
        grower.setCustomerSapId("1");
        grower.setName("");
        Sale sale = new Sale(new Customer(),grower);
        sale.setSaleOrderSAPId(1L);
        createDebtDocumentServiceRunner.run(sale);

        //@Then the service runner signals its execution status as Ok
        assertTrue(createDebtDocumentServiceRunner.getStatus());
    }

    @Test
    public void testRunStatusIsUpdatedWhenError() throws Exception {
        //@Given a set if valid service invocation parameters
        createDebtDocumentServiceRunner.setCuit(SAMPLE_CUIT);
        createDebtDocumentServiceRunner.setProduct(SAMPLE_PRODUCT);
        createDebtDocumentServiceRunner.setAgreement(SAMPLE_AGREEMENT);
        createDebtDocumentServiceRunner.setDebtDocument(SAMPLE_DEBTDOC);

        //@When the service invocation occurs with errors
        Mockito.when(osbService.createDebtDocument(SAMPLE_CUIT, SAMPLE_PRODUCT, SAMPLE_AGREEMENT,
                SAMPLE_DEBTDOC, null)).thenThrow(new InfraException());
        try {
            createDebtDocumentServiceRunner.run(sale);
            fail("Service Runner invocation is stubbed to throw an exception");
        } catch (Exception e) {
        }

        //@Then the service runner signals its execution status as not Ok
        assertFalse(createDebtDocumentServiceRunner.getStatus());
    }
}
