package com.monsanto.brazilvaluecapture.core.grower.service.impl;

import com.monsanto.brazilvaluecapture.bonus.bulkimport.model.dao.BonusDAO;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Company;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Crop;
import com.monsanto.brazilvaluecapture.core.base.model.bean.OperationalYear;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Technology;
import com.monsanto.brazilvaluecapture.core.grower.model.bean.Grower;
import com.monsanto.brazilvaluecapture.seedsale.bonus.bulkimport.model.bean.BonusAccount;
import com.monsanto.brazilvaluecapture.seedsale.bonus.service.impl.BonusReportServiceImpl;
import com.monsanto.brazilvaluecapture.seedsale.quota.report.EmptyReportException;
import junit.framework.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;


import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyLong;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.when;



/**
 * Created with IntelliJ IDEA.
 * User: MEFAZZ
 * Date: 3/18/14
 * Time: 1:52 PM
 * To change this template use File | Settings | File Templates.
 */
@RunWith(MockitoJUnitRunner.class)
public class BonusReportServiceImpl_UT {

    @Mock
    private BonusDAO bonusDao;

    @InjectMocks
    private BonusReportServiceImpl bonusReportService;


    private ResourceBundle resourceBundle;

    private Company company;

    private Crop crop;

    private Technology technology;

    private OperationalYear operationalYear ;

    private Grower grower;

    @Before
    public void before(){

      company = Mockito.mock(Company.class);
      crop = Mockito.mock(Crop.class);
      technology = Mockito.mock(Technology.class);
      operationalYear = Mockito.mock(OperationalYear.class);
      grower = Mockito.mock(Grower.class);
      resourceBundle = ResourceBundle.getBundle("bundle/bundle");

    }

   @Test
   public void when_buildReport_should_return_byteArrayOutputStream(){

       when(bonusDao.getBonusAccountByGrowerTechnologyOperationalYear(any(Grower.class),any(Technology.class),any(OperationalYear.class))).thenReturn(createListBonusAccounts());

       try {
           ByteArrayOutputStream byteArrayOutputStream = bonusReportService.buildReport(company,crop,technology,operationalYear,grower,resourceBundle);

           Assert.assertNotNull(byteArrayOutputStream);

       } catch (NoSuchMethodException e) {
           e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
       } catch (IOException e) {
           e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
       } catch (EmptyReportException e) {
           e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
       }
   }


    @Test
    public void when_buildReport_should_return_exception(){

       when(bonusDao.getBonusAccountByGrowerTechnologyOperationalYear(any(Grower.class),any(Technology.class),any(OperationalYear.class))).thenReturn(new ArrayList<BonusAccount>());

       try {

           ByteArrayOutputStream byteArrayOutputStream = bonusReportService.buildReport(company,crop,technology,operationalYear,grower,resourceBundle);
           Assert.fail();
       } catch (Exception e) {
           Assert.assertEquals("Report is empty",e.getMessage());
       }
   }


   private List<BonusAccount> createListBonusAccounts(){
       List<BonusAccount> bonusAccounts = new ArrayList<BonusAccount>();
       BonusAccount bonusAccount = new BonusAccount();
       bonusAccount.setId(1l);
       bonusAccounts.add(bonusAccount);
       return bonusAccounts;
   }

}
