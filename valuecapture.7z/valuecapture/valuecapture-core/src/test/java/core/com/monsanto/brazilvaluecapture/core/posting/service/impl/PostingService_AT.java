package com.monsanto.brazilvaluecapture.core.posting.service.impl;

import com.monsanto.brazilvaluecapture.core.customer.model.bean.Technology;
import com.monsanto.brazilvaluecapture.core.foundation.service.BusinessException;
import com.monsanto.brazilvaluecapture.core.foundation.test.AbstractServiceIntegrationTests;
import com.monsanto.brazilvaluecapture.core.foundation.test.dbunit.DbUnitHelper;
import com.monsanto.brazilvaluecapture.core.foundation.util.CalendarUtil;
import com.monsanto.brazilvaluecapture.core.foundation.util.ConstraintViolation;
import com.monsanto.brazilvaluecapture.core.posting.model.bean.*;
import com.monsanto.brazilvaluecapture.core.posting.model.bean.Posting.PostingOrigin;
import com.monsanto.brazilvaluecapture.core.posting.model.dao.PostingFilter;
import com.monsanto.brazilvaluecapture.core.posting.service.PostingConstraintException;
import com.monsanto.brazilvaluecapture.core.posting.service.PostingService;
import com.monsanto.brazilvaluecapture.core.revenue.osb.OsbProvisionService;
import com.monsanto.brazilvaluecapture.osb.its.api.InfraException;
import com.monsanto.brazilvaluecapture.osb.its.api.PostingDocument;
import com.monsanto.brazilvaluecapture.seedsale.posting.osb.OsbBonusPostingService;
import junit.framework.Assert;
import org.hibernate.Query;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyString;
import static org.mockito.Matchers.same;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

public class PostingService_AT extends AbstractServiceIntegrationTests {

    @Autowired
    private PostingService postingService;

    @Before
    public void setup() throws InfraException {
        OsbProvisionService osb = Mockito.mock(OsbProvisionService.class);


        PostingDocument value = new PostingDocument("1", "COMP", "NOT_USED");
        when(
                osb.post(any(ReferenceNameEnum.class), any(BigDecimal.class),
                        any(BigDecimal.class), any(BigDecimal.class), anyString())).thenReturn(
                value);

        postingService.setOsbProvisionService(osb);

        int postingAccounts = getSession().createCriteria(PostingAccount.class).list().size();
        if (postingAccounts == 0) {
            DbUnitHelper.setup("classpath:data/core/fixture-system-dataset.xml",
                    "classpath:data/core/posting_account_posting_reference_dataset.xml");
        }
    }

    private void assertPostingReference(PostingReference postingReference, String expectedDebitAccountNumber,
                                        String expectedCreditAccountNumber, Boolean hasTechnology, Boolean validateDebitAccountBalance) {
        Assert.assertNotNull("Posting Reference should not be null", postingReference);
        Assert.assertNotNull("Posting Debit Account should not be null", postingReference.getDebitAccount());
        Assert.assertNotNull("Posting Credit Account should not be null", postingReference.getCreditAccount());
        Assert.assertEquals("Posting Reference debit account number should be",
                Long.valueOf(expectedDebitAccountNumber), postingReference.getDebitAccount().getAccountNumber());
        Assert.assertEquals("Posting Reference credit account number should be",
                Long.valueOf(expectedCreditAccountNumber), postingReference.getCreditAccount().getAccountNumber());
        Assert.assertEquals("Has Technology", hasTechnology, postingReference.getHasTechnology());
    }

    @Test
    public void given_advancePostingReferenceType_when_search_for_postinReference_should_return_postingReference_with_two_postingAccounts() {
        PostingReference postingReference = postingService.getPostingReferenceByType(ReferenceNameEnum.ADVANCE);
        assertPostingReference(postingReference, "10101185", "21495051", false, false);
    }

    @Test
    public void given_advanceConsumptionPostingReferenceType_when_search_for_postinReference_should_return_postingReference_with_two_postingAccounts() {
        PostingReference postingReference = postingService
                .getPostingReferenceByType(ReferenceNameEnum.ADVANCE_CONSUMPTION);
        assertPostingReference(postingReference, "21495051", "32110000", true, true);
    }

    @Test
    public void given_soyRoyaltiesPostingReferenceType_when_search_for_postinReference_should_return_postingReference_with_two_postingAccounts() {
        PostingReference postingReference = postingService.getPostingReferenceByType(ReferenceNameEnum.SOY_ROYALTIES);
        assertPostingReference(postingReference, "10101185", "32110000", true, false);
    }

    @Test
    public void given_soyReversalPostingReferenceType_when_search_for_postinReference_should_return_postingReference_with_two_postingAccounts() {
        PostingReference postingReference = postingService.getPostingReferenceByType(ReferenceNameEnum.SOY_REVERSAL);
        assertPostingReference(postingReference, "32110000", "21495051", true, true);
    }

    @Test
    public void given_taxedReclassificationPostingReferenceType_when_search_for_postinReference_should_return_postingReference_with_two_postingAccounts() {
        PostingReference postingReference = postingService
                .getPostingReferenceByType(ReferenceNameEnum.TAXED_RECLASSIFICATION);
        assertPostingReference(postingReference, "21495051", "32110000", true, true);
    }

    @Test
    public void given_soyReturnPostingReferenceType_when_search_for_postinReference_should_return_postingReference_with_two_postingAccounts() {
        PostingReference postingReference = postingService.getPostingReferenceByType(ReferenceNameEnum.SOY_RETURN);
        assertPostingReference(postingReference, "21495051", "10101185", true, true);
    }

    @Test
    public void given_one_posting_with_negative_value_should_throw_exception() {
        Technology technology = (Technology) getSession().createCriteria(Technology.class).list().get(0);
        PostingReference postingReference = postingService
                .getPostingReferenceByType(ReferenceNameEnum.TAXED_RECLASSIFICATION);

        try {
            postingService.save(postingReference, BigDecimal.ZERO, technology, PostingOrigin.MANUAL);
            Assert.fail();
        } catch (PostingConstraintException e) {
            ConstraintViolation violation = e.getViolations().get(0);
            Assert.assertEquals("Should have a violation of zero or negative value", "error.posting.value.invalid",
                    violation.getMessage());
        }
    }

    @Test
    public void given_one_posting_without_value_should_throw_exception() {
        PostingReference postingReference = postingService.getPostingReferenceByType(ReferenceNameEnum.SOY_ROYALTIES);
        Technology technology = (Technology) getSession().createCriteria(Technology.class).list().get(0);
        try {
            postingService.save(postingReference, null, technology, PostingOrigin.MANUAL);
            Assert.fail();
        } catch (PostingConstraintException e) {
            ConstraintViolation violation = e.getViolations().get(0);
            Assert.assertEquals("Should have a violation of required value", "error.posting.field.required",
                    violation.getMessage());
        }
    }

    @Test
    public void given_one_posting_without_reference_should_throw_exception() {
        Technology technology = (Technology) getSession().createCriteria(Technology.class).list().get(0);

        try {
            postingService.save(null, BigDecimal.ONE, technology, PostingOrigin.MANUAL);
            Assert.fail();
        } catch (PostingConstraintException e) {
            ConstraintViolation violation = e.getViolations().get(0);
            Assert.assertEquals("Should have a violation of required value", "error.posting.field.required",
                    violation.getMessage());
        }
    }

    @Test
    public void given_one_posting_without_technology_should_throw_exception() {
        PostingReference postingReference = postingService.getPostingReferenceByType(ReferenceNameEnum.SOY_ROYALTIES);

        try {
            postingService.save(postingReference, BigDecimal.ONE, null, PostingOrigin.MANUAL);
            Assert.fail();
        } catch (PostingConstraintException e) {
            ConstraintViolation violation = e.getViolations().get(0);
            Assert.assertEquals("Should have a violation of required value", "error.posting.field.required",
                    violation.getMessage());
        }
    }

    @Test
    public void given_one_postingReference_when_savePosting_should_create_a_Posting_and_save_successfully()
            throws PostingConstraintException {
        Technology technology = (Technology) getSession().createCriteria(Technology.class).list().get(0);
        PostingReference postingReference = postingService.getPostingReferenceByType(ReferenceNameEnum.ADVANCE);

        postingService.save(postingReference, BigDecimal.TEN, technology, PostingOrigin.MANUAL);

        Query query = getSession().createQuery("select post from Posting post " +
                "where post.postingReference = :postingReference " +
                "and post.technology = :technology and post.origin = :origin");

        query.setParameter("postingReference", postingReference);
        query.setParameter("technology", technology);
        query.setParameter("origin", PostingOrigin.MANUAL);

        Posting posting = (Posting) query.uniqueResult();
        Assert.assertEquals("Value should be same", BigDecimal.TEN, posting.getPostingValue());
        Assert.assertEquals("Technology should match", technology, posting.getTechnology());
    }

    @Test
    public void given_one_postingReference_and_hasAccounting_when_savePosting_should_create_a_Posting_and_save_successfully()
            throws PostingConstraintException {
        Technology technology = (Technology) getSession().createCriteria(Technology.class).list().get(0);
        PostingReference postingReference = postingService.getPostingReferenceByType(ReferenceNameEnum.BAIXA_NC_POD);

        postingService.save(postingReference, BigDecimal.ZERO, BigDecimal.ZERO, BigDecimal.TEN, technology,
                PostingOrigin.AUTOMATIC, Boolean.FALSE);

        Query query = getSession().createQuery("select post from Posting post " +
                "where post.postingReference = :postingReference " +
                "and post.technology = :technology and post.origin = :origin");

        query.setParameter("postingReference", postingReference);
        query.setParameter("technology", technology);
        query.setParameter("origin", PostingOrigin.AUTOMATIC);

        Posting posting = (Posting) query.uniqueResult();

        Assert.assertEquals("Value should be same", BigDecimal.ZERO, posting.getPostingValue());
        Assert.assertEquals("Charge Value should be same", BigDecimal.TEN, posting.getPostingChargeValue());
        Assert.assertEquals("Technology should match", technology, posting.getTechnology());
        Assert.assertFalse("Has Accounting should match", posting.getHasAccounting());
    }

    @Test(expected = PostingConstraintException.class)
    public void given_one_postingReference_and_hasAccounting_when_savePosting_should_throw_constraint_exception()
            throws PostingConstraintException {
        Technology technology = (Technology) getSession().createCriteria(Technology.class).list().get(0);
        PostingReference postingReference = postingService.getPostingReferenceByType(ReferenceNameEnum.ADVANCE);

        postingService.save(postingReference, BigDecimal.ZERO, BigDecimal.ZERO, BigDecimal.ZERO, technology,
                PostingOrigin.AUTOMATIC, Boolean.FALSE);
    }

    @Test
    public void given_one_posting_when_postingAccount_doenstHaveBalance_should_throw_insuficcientBalanceException() {
        Technology technology = (Technology) getSession().createCriteria(Technology.class).list().get(0);
        PostingReference postingReference = postingService
                .getPostingReferenceByType(ReferenceNameEnum.ADVANCE_CONSUMPTION);

        try {
            postingService.save(postingReference, BigDecimal.TEN, technology, PostingOrigin.MANUAL);
            Assert.fail();
        } catch (PostingConstraintException e) {
            ConstraintViolation violation = e.getViolations().get(0);
            Assert.assertEquals("Should have insufficient balance code", "error.posting.account.balance.invalid",
                    violation.getMessage());
        }
    }

    @Test
    public void when_call_getPostingAccountValidateBalance_should_return_only_account_that_validate_balance() {
        List<PostingAccount> accounts = postingService.getPostingAccountValidateBalance();
        Assert.assertNotNull("Should return a list of posting accounts", accounts);

        for (PostingAccount account : accounts) {
            Assert.assertTrue("Should not return accounts that not validade balance", account.getValidateBalance());
        }
    }

    @Test
    public void search_without_filters_should_return_only_postings_with_creationDate_between_intial_and_final_date() {

        Technology tech = (Technology) getSession().createCriteria(Technology.class).list().get(0);

        createGenericPosting(ReferenceNameEnum.SOY_ROYALTIES, BigDecimal.TEN, tech, PostingOrigin.AUTOMATIC);
        createGenericPosting(ReferenceNameEnum.ADVANCE, BigDecimal.ONE, null, PostingOrigin.AUTOMATIC);

        Date filterStartDate = CalendarUtil.getDateNow();
        Date filterEndDate = CalendarUtil.getDateNow();

        PostingFilter filter = PostingFilter.getInstance(filterStartDate, filterEndDate);
        List<Posting> postings = postingService.getByFilter(filter);

        Assert.assertFalse("Should return postings", postings.isEmpty());
    }

    @Test
    public void search_by_postingReference_should_return_only_postings_with_reference_filtered() {

        Technology tech = (Technology) getSession().createCriteria(Technology.class).list().get(0);

        createGenericPosting(ReferenceNameEnum.SOY_ROYALTIES, BigDecimal.TEN, tech, PostingOrigin.AUTOMATIC);
        createGenericPosting(ReferenceNameEnum.ADVANCE, BigDecimal.ONE, null, PostingOrigin.AUTOMATIC);

        Date filterStartDate = CalendarUtil.getDateNow();
        Date filterEndDate = CalendarUtil.getDateNow();

        PostingReference filterReference = postingService.getPostingReferenceByType(ReferenceNameEnum.SOY_ROYALTIES);

        PostingFilter filter = PostingFilter.getInstance(filterStartDate, filterEndDate);
        filter.add(filterReference);

        List<Posting> postings = postingService.getByFilter(filter);

        Assert.assertFalse("Should return postings", postings.isEmpty());

        for (Posting posting : postings) {
            Assert.assertEquals("Should return posting with reference filtered", filterReference,
                    posting.getPostingReference());
        }
    }

    @Test
    public void search_by_technology_should_return_only_postings_with_technology_filtered() {

        Technology tech = (Technology) getSession().createCriteria(Technology.class).list().get(0);
        createGenericPosting(ReferenceNameEnum.SOY_ROYALTIES, BigDecimal.TEN, tech, PostingOrigin.AUTOMATIC);

        Technology filterTechnology = (Technology) getSession().createCriteria(Technology.class).list().get(1);
        createGenericPosting(ReferenceNameEnum.SOY_REVERSAL, BigDecimal.ONE, filterTechnology, PostingOrigin.AUTOMATIC);

        Date filterStartDate = CalendarUtil.getDateNow();
        Date filterEndDate = CalendarUtil.getDateNow();

        PostingFilter filter = PostingFilter.getInstance(filterStartDate, filterEndDate);
        filter.add(filterTechnology);

        List<Posting> postings = postingService.getByFilter(filter);

        Assert.assertFalse("Should return postings", postings.isEmpty());

        for (Posting posting : postings) {
            Assert.assertEquals("Should return posting with technology filtered", filterTechnology,
                    posting.getTechnology());
        }
    }

    @Test
    public void search_by_technology_should_not_return_posting_with_reference_advance() {

        Technology filterTechnology = (Technology) getSession().createCriteria(Technology.class).list().get(0);

        createGenericPosting(ReferenceNameEnum.SOY_REVERSAL, BigDecimal.ONE, filterTechnology, PostingOrigin.AUTOMATIC);
        createGenericPosting(ReferenceNameEnum.ADVANCE, BigDecimal.TEN, null, PostingOrigin.AUTOMATIC);

        Date filterStartDate = CalendarUtil.getDateNow();
        Date filterEndDate = CalendarUtil.getDateNow();
        PostingReference reference = postingService.getPostingReferenceByType(ReferenceNameEnum.ADVANCE);

        PostingFilter filter = PostingFilter.getInstance(filterStartDate, filterEndDate);
        filter.add(filterTechnology);

        List<Posting> postings = postingService.getByFilter(filter);

        Assert.assertFalse("Should return postings", postings.isEmpty());

        for (Posting posting : postings) {
            Assert.assertNotSame("Should not return posting with reference advance", reference,
                    posting.getPostingReference());
        }
    }

    @Test
    public void search_without_startDate_should_return_exception() {
        try {
            PostingFilter.getInstance(null, new Date());
            Assert.fail("Should return IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            Assert.assertEquals("Creation Date Start should be a valid date before Creation Date End", e.getMessage());
        }
    }

    @Test
    public void search_without_endDate_should_return_exception() {
        try {
            PostingFilter.getInstance(new Date(), null);
            Assert.fail("Should return IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            Assert.assertEquals("Creation Date Start should be a valid date before Creation Date End", e.getMessage());
        }
    }

    @Test
    public void search_with_startDate_greater_then_endDate_should_return_exception() {
        Date filterStartDate = CalendarUtil.getDate(2012, 1, 2);
        Date filterEndDate = CalendarUtil.getDate(2012, 1, 1);
        try {
            PostingFilter.getInstance(filterStartDate, filterEndDate);
            Assert.fail("Should return IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            Assert.assertEquals("Creation Date Start should be a valid date before Creation Date End", e.getMessage());
        }
    }

    @Test
    public void search_with_filter_hasAccounting_should_return_only_postings_with_accounting() {

        Technology tech = (Technology) getSession().createCriteria(Technology.class).list().get(0);

        createGenericPosting(ReferenceNameEnum.SOY_ROYALTIES, BigDecimal.TEN, tech, PostingOrigin.AUTOMATIC);
        createGenericPosting(ReferenceNameEnum.BAIXA_NC_POD, BigDecimal.ONE, null, PostingOrigin.AUTOMATIC);
        createGenericPostingWithoutAccounting(ReferenceNameEnum.BAIXA_NC_POD, BigDecimal.ONE, null,
                PostingOrigin.AUTOMATIC);

        Date filterStartDate = CalendarUtil.getDateNow();
        Date filterEndDate = CalendarUtil.getDateNow();

        PostingFilter filter = PostingFilter.getInstance(filterStartDate, filterEndDate);
        filter.add(Boolean.TRUE);
        List<Posting> postings = postingService.getByFilter(filter);

        Assert.assertFalse("Should return postings", postings.isEmpty());

        for (Posting posting : postings) {
            Assert.assertTrue(posting.getHasAccounting());
        }
    }

    @Test
    public void search_with_filter_hasAccounting_should_return_only_postings_without_accounting() {

        Technology tech = (Technology) getSession().createCriteria(Technology.class).list().get(0);

        createGenericPosting(ReferenceNameEnum.SOY_ROYALTIES, BigDecimal.TEN, tech, PostingOrigin.AUTOMATIC);
        createGenericPosting(ReferenceNameEnum.BAIXA_NC_POD, BigDecimal.ONE, null, PostingOrigin.AUTOMATIC);
        createGenericPostingWithoutAccounting(ReferenceNameEnum.BAIXA_NC_POD, BigDecimal.ONE, null,
                PostingOrigin.AUTOMATIC);

        Date filterStartDate = CalendarUtil.getDateNow();
        Date filterEndDate = CalendarUtil.getDateNow();

        PostingFilter filter = PostingFilter.getInstance(filterStartDate, filterEndDate);
        filter.add(Boolean.FALSE);
        List<Posting> postings = postingService.getByFilter(filter);

        Assert.assertFalse("Should return postings", postings.isEmpty());

        for (Posting posting : postings) {
            Assert.assertFalse(posting.getHasAccounting());
        }
    }

    @Test
    public void when_posting_has_not_number_delete_should_be_success() {

        Posting posting = createGenericPosting(ReferenceNameEnum.ADVANCE, BigDecimal.ONE, null, PostingOrigin.MANUAL);

        Date filterStartDate = CalendarUtil.getDateNow();
        Date filterEndDate = CalendarUtil.getDateNow();

        PostingFilter filter = PostingFilter.getInstance(filterStartDate, filterEndDate);

        List<Posting> postings = postingService.getByFilter(filter);

        Assert.assertTrue(postings.contains(posting));

        try {
            getSession().clear();
            postingService.delete(posting);
        } catch (PostingConstraintException e) {
            Assert.fail("Should be success");
        }

        postings = postingService.getByFilter(filter);

        Assert.assertFalse(postings.contains(posting));
    }

    @Test
    public void when_posting_has_number_delete_should_return_exception() {

        Posting posting = createGenericPosting(ReferenceNameEnum.ADVANCE, BigDecimal.ONE, null, PostingOrigin.MANUAL);
        posting.setPostingNumber("0123456789");
        saveAndFlush(posting);

        Date filterStartDate = CalendarUtil.getDateNow();
        Date filterEndDate = CalendarUtil.getDateNow();

        PostingFilter filter = PostingFilter.getInstance(filterStartDate, filterEndDate);

        List<Posting> postings = postingService.getByFilter(filter);

        Assert.assertFalse("Should return postings", postings.isEmpty());

        try {
            getSession().clear();
            postingService.delete(posting);
            Assert.fail("Should return exception");
        } catch (PostingConstraintException e) {
            ConstraintViolation violation = e.getViolations().get(0);
            Assert.assertEquals("error.posting.has.number", violation.getMessage());
        }

    }

    @Test
    public void when_delete_posting_becomes_credit_account_balance_negative_should_return_exception() {

        Technology tech = (Technology) getSession().createCriteria(Technology.class).list().get(0);

        Posting postingToDelete = createGenericPosting(ReferenceNameEnum.ADVANCE, BigDecimal.ONE, null,
                PostingOrigin.MANUAL);

        createGenericPosting(ReferenceNameEnum.SOY_RETURN, BigDecimal.ONE, tech, PostingOrigin.MANUAL);

        try {
            getSession().clear();
            postingService.delete(postingToDelete);
            Assert.fail("Should return exception");
        } catch (PostingConstraintException e) {
            ConstraintViolation violation = e.getViolations().get(0);
            Assert.assertEquals("error.posting.balance.insufficient.delete", violation.getMessage());
        }

    }

    @Test
    public void when_credit_account_does_not_valitade_balance_delete_should_return_success() {

        Technology tech = (Technology) getSession().createCriteria(Technology.class).list().get(0);

        createGenericPosting(ReferenceNameEnum.ADVANCE, BigDecimal.ONE, null, PostingOrigin.MANUAL);

        Posting postingToDelete = createGenericPosting(ReferenceNameEnum.SOY_RETURN, BigDecimal.ONE, tech,
                PostingOrigin.MANUAL);

        Date filterStartDate = CalendarUtil.getDateNow();
        Date filterEndDate = CalendarUtil.getDateNow();

        PostingFilter filter = PostingFilter.getInstance(filterStartDate, filterEndDate);

        List<Posting> postings = postingService.getByFilter(filter);

        Assert.assertTrue(postings.contains(postingToDelete));

        try {
            getSession().clear();
            postingService.delete(postingToDelete);
        } catch (PostingConstraintException e) {
            Assert.fail("Should return success");
        }

        postings = postingService.getByFilter(filter);

        Assert.assertFalse(postings.contains(postingToDelete));

    }

    @Test
    public void given_one_posting_totalizerAccounts_should_return_two_account_with_correct_values() {
        List<Posting> postingList = new ArrayList<Posting>();
        Posting posting = createGenericPosting(ReferenceNameEnum.ADVANCE, BigDecimal.TEN, null, PostingOrigin.AUTOMATIC);
        postingList.add(posting);

        List<TotalizedAccountDTO> totalizedAccounts = postingService.totalizeAccounts(postingList);

        Assert.assertEquals(2, totalizedAccounts.size());

        TotalizedAccountDTO advanced = totalizedAccounts.get(totalizedAccounts.indexOf(new TotalizedAccountDTO(
                "advance", 21495051L)));
        Assert.assertEquals(advanced.getCreditedValue(), BigDecimal.TEN);
        Assert.assertEquals(advanced.getDebitedValue(), BigDecimal.ZERO);
        Assert.assertEquals(advanced.getBalance(), BigDecimal.TEN);

        TotalizedAccountDTO reception = totalizedAccounts.get(totalizedAccounts.indexOf(new TotalizedAccountDTO(
                "reception", 10101185L)));
        Assert.assertEquals(reception.getCreditedValue(), BigDecimal.ZERO);
        Assert.assertEquals(reception.getDebitedValue(), BigDecimal.TEN);
        Assert.assertEquals(reception.getBalance(), BigDecimal.TEN.negate());
    }

    @Test
    public void given_three_difserent_postings_totalizerAccounts_should_return_three_account_with_correct_values() {
        List<Posting> postingList = new ArrayList<Posting>();
        Posting advanced = createGenericPosting(ReferenceNameEnum.ADVANCE, BigDecimal.TEN, null,
                PostingOrigin.AUTOMATIC);
        Posting advancedComsumption = createGenericPosting(ReferenceNameEnum.ADVANCE_CONSUMPTION, BigDecimal.TEN, null,
                PostingOrigin.AUTOMATIC);
        Posting soyRoyalties = createGenericPosting(ReferenceNameEnum.SOY_ROYALTIES, BigDecimal.TEN, null,
                PostingOrigin.AUTOMATIC);
        postingList.add(advanced);
        postingList.add(advancedComsumption);
        postingList.add(soyRoyalties);

        List<TotalizedAccountDTO> totalizedAccounts = postingService.totalizeAccounts(postingList);

        Assert.assertEquals(3, totalizedAccounts.size());

        BigDecimal twenty = new BigDecimal(20);

        TotalizedAccountDTO advancedAccount = totalizedAccounts.get(totalizedAccounts.indexOf(new TotalizedAccountDTO(
                "advance", 21495051L)));
        Assert.assertEquals(advancedAccount.getCreditedValue(), BigDecimal.TEN);
        Assert.assertEquals(advancedAccount.getDebitedValue(), BigDecimal.TEN);
        Assert.assertEquals(advancedAccount.getBalance(), BigDecimal.ZERO);

        TotalizedAccountDTO soyRoyaltyAccount = totalizedAccounts.get(totalizedAccounts
                .indexOf(new TotalizedAccountDTO("soybeanroyalty", 32110000L)));
        Assert.assertEquals(soyRoyaltyAccount.getCreditedValue(), twenty);
        Assert.assertEquals(soyRoyaltyAccount.getDebitedValue(), BigDecimal.ZERO);
        Assert.assertEquals(soyRoyaltyAccount.getBalance(), twenty);

        TotalizedAccountDTO receptionAccount = totalizedAccounts.get(totalizedAccounts.indexOf(new TotalizedAccountDTO(
                "reception", 10101185L)));
        Assert.assertEquals(receptionAccount.getCreditedValue(), BigDecimal.ZERO);
        Assert.assertEquals(receptionAccount.getDebitedValue(), twenty);
        Assert.assertEquals(receptionAccount.getBalance(), twenty.negate());
    }

    private Posting createGenericPosting(ReferenceNameEnum nameEnum, BigDecimal value, Technology tech,
                                         PostingOrigin origin) {
        PostingReference reference = postingService.getPostingReferenceByType(nameEnum);
        Posting newPosting = new Posting(reference, value, tech, origin);
        saveAndFlush(newPosting);
        return newPosting;
    }

    private Posting createGenericPostingWithoutAccounting(ReferenceNameEnum nameEnum, BigDecimal chargeValue,
                                                          Technology tech, PostingOrigin origin) {
        PostingReference reference = postingService.getPostingReferenceByType(nameEnum);
        Posting newPosting = new Posting(reference, chargeValue, BigDecimal.ZERO, tech, origin, Boolean.FALSE);
        newPosting.setPostingNumber("0");
        saveAndFlush(newPosting);
        return newPosting;
    }

    @Test
    public void test_send_pendent_posting_to_erp() throws InfraException {
        Technology technology = (Technology) getSession().createCriteria(Technology.class).list().get(0);

        technology.setErpName("RR");
        Posting posting = createGenericPosting(ReferenceNameEnum.SOY_ROYALTIES, BigDecimal.ONE, technology,
                PostingOrigin.MANUAL);
        postingService.submitPendentPostingToERP(posting);
        Assert.assertNotNull(posting.getPostingNumber());
    }

    @Test
    public void test_send_all_types_pendent_posting_to_erp() throws InfraException {
        testPosting(ReferenceNameEnum.ADVANCE, null, 1, 2, 3);

        testPosting(ReferenceNameEnum.SOY_ROYALTIES, "RR", 4, 5, 6);
        testPosting(ReferenceNameEnum.SOY_ROYALTIES, "INTACTA RR", 7, 8, 9);

        testPosting(ReferenceNameEnum.TAXED_RECLASSIFICATION, "RR", 10, 11, 12);
        testPosting(ReferenceNameEnum.TAXED_RECLASSIFICATION, "INTACTA RR", 13, 14, 15);

        testPosting(ReferenceNameEnum.ADVANCE_CONSUMPTION, "RR", 16, 17, 18);
        testPosting(ReferenceNameEnum.ADVANCE_CONSUMPTION, "INTACTA RR", 19, 20, 21);

        testPosting(ReferenceNameEnum.SOY_REVERSAL, "RR", 22, 23, 24);
        testPosting(ReferenceNameEnum.SOY_REVERSAL, "INTACTA RR", 25, 26, 27);

        testPosting(ReferenceNameEnum.SOY_RETURN, "RR", 28, 29, 30);
        testPosting(ReferenceNameEnum.SOY_RETURN, "INTACTA RR", 31, 32, 33);

        testPosting(ReferenceNameEnum.ADVANCE, null, 34, 0, 0);

        testPosting(ReferenceNameEnum.SOY_ROYALTIES, "RR", 35, 0, 0);
        testPosting(ReferenceNameEnum.SOY_ROYALTIES, "INTACTA RR", 36, 0, 0);

        testPosting(ReferenceNameEnum.TAXED_RECLASSIFICATION, "RR", 37, 0, 0);
        testPosting(ReferenceNameEnum.TAXED_RECLASSIFICATION, "INTACTA RR", 38, 0, 0);

        testPosting(ReferenceNameEnum.ADVANCE_CONSUMPTION, "RR", 39, 0, 0);
        testPosting(ReferenceNameEnum.ADVANCE_CONSUMPTION, "INTACTA RR", 40, 0, 0);

        testPosting(ReferenceNameEnum.SOY_REVERSAL, "RR", 41, 0, 0);
        testPosting(ReferenceNameEnum.SOY_REVERSAL, "INTACTA RR", 42, 0, 0);

        testPosting(ReferenceNameEnum.SOY_RETURN, "RR", 43, 0, 0);
        testPosting(ReferenceNameEnum.SOY_RETURN, "INTACTA RR", 44, 0, 0);
    }


    @Test
    public void testSubmitAndSavePosting_SubmitAndSavePosting() throws InfraException, BusinessException {

        try {
            //@given
            PostingDocument value = new PostingDocument("1", "COMP", "NOT_USED");
            OsbBonusPostingService bonusOsb = Mockito.mock(OsbBonusPostingService.class);
            when(bonusOsb.post(any(BigDecimal.class), anyString(), any(Date.class), any(Date.class), same(OsbBonusPostingService.DEFAULT_TECHNOLOGY))).thenReturn(value);
            postingService.setOsbBonusPostingService(bonusOsb);
            PostingDocument postingDocument = postingService.submitAndSaveBonusPosting(new BigDecimal(1234567890), ReferenceNameEnum.BONUS_ACCRUAL, null, new Date(), new Date(), OsbBonusPostingService.DEFAULT_TECHNOLOGY);
            Assert.assertEquals(value, postingDocument);
            verify(bonusOsb).post(any(BigDecimal.class), anyString(), any(Date.class), any(Date.class), same(OsbBonusPostingService.DEFAULT_TECHNOLOGY));
        } catch (InfraException e) {
            Assert.fail("Shouldn't fail");
        } catch (BusinessException e) {
            Assert.fail("Shouldn't fail");
        }


    }

    /**
     * @return
     * @throws InfraException
     */
    private void testPosting(ReferenceNameEnum type, String technology, double postingValue, double chargeValue,
                             double mktValue) throws InfraException {
        Technology tech;
        if (technology != null) {
            tech = (Technology) getSession().createCriteria(Technology.class).list().get(0);
            tech.setErpName(technology);
        }

        Posting posting = createGenericPosting(type, BigDecimal.valueOf(postingValue), null, PostingOrigin.MANUAL);
        Assert.assertNull(posting.getPostingNumber());
        posting.setPostingChargeValue(BigDecimal.valueOf(chargeValue));
        posting.setPostingMktProgramValue(BigDecimal.valueOf(mktValue));
        postingService.submitPendentPostingToERP(posting);
        Assert.assertNotNull(posting.getPostingNumber());
        logger.info("[" + type.getErpCode() + "] [" + technology + "]: amount=(" + postingValue + ") charge=("
                + chargeValue + ") mkt=(" + mktValue + ") docNumber = " + posting.getPostingNumber());
    }

}
