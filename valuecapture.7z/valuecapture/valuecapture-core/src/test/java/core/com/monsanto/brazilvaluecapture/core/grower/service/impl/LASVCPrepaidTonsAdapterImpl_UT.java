package com.monsanto.brazilvaluecapture.core.grower.service.impl;

import com.monsanto.brazilvaluecapture.core.account.model.bean.Transaction;
import com.monsanto.brazilvaluecapture.core.account.model.bean.TransactionType;
import com.monsanto.brazilvaluecapture.core.account.model.dao.TransactionDAO;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Company;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Crop;
import com.monsanto.brazilvaluecapture.core.base.model.bean.OperationalYear;
import com.monsanto.brazilvaluecapture.core.base.model.dao.OperationalYearDAO;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Customer;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Technology;
import com.monsanto.brazilvaluecapture.core.foundation.model.bean.StatusEnum;
import com.monsanto.brazilvaluecapture.core.foundation.util.security.EnvironmentSpecificPropertyReader;
import com.monsanto.brazilvaluecapture.core.foundation.util.security.EnvironmentSpecificPropertyReaderFactory;
import com.monsanto.brazilvaluecapture.core.grower.model.bean.Grower;
import com.monsanto.brazilvaluecapture.osb.its.api.InfraException;
import com.monsanto.brazilvaluecapture.osb.its.api.LASVCPrepaidTonsServiceAR;
import com.monsanto.brazilvaluecapture.osb.its.api.LASVCPrepaidTonsServiceFactory;
import com.monsanto.brazilvaluecapture.osb.util.SecurityContextBadCredentialException;
import com.monsanto.brazilvaluecapture.osb.util.SecurityContextHolder;
import com.monsanto.brazilvaluecapture.osb.util.SecurityContextHolderFactory;
import com.monsanto.brazilvaluecapture.seedsale.billing.model.bean.Billing;
import com.monsanto.brazilvaluecapture.seedsale.harvest.model.bean.Harvest;
import com.monsanto.brazilvaluecapture.seedsale.product.model.bean.Product;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.Cancellation;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.Sale;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.SaleItem;
import com.monsanto.brazilvaluecapture.seedsale.template.model.bean.SaleTemplate;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

import java.net.MalformedURLException;
import java.util.ArrayList;

import static org.fest.reflect.core.Reflection.field;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.*;

public class LASVCPrepaidTonsAdapterImpl_UT {

	private LASVCPrepaidTonsAdapterImpl lASVCPrepaidTonsAdapterImpl;
	private LASVCPrepaidTonsServiceAR osbService;
	private TransactionDAO transactionDAO;
	private Sale sale;
    private OperationalYear operationalYear = new OperationalYear("2013");
	private SecurityContextHolderFactory securityContextHolderFactory;
	private SecurityContextHolder securityContextHolder;
	private LASVCPrepaidTonsServiceFactory lASVCPrepaidTonsServiceFactory;
	private EnvironmentSpecificPropertyReaderFactory environmentSpecificPropertyReaderFactory;
	private EnvironmentSpecificPropertyReader environmentSpecificPropertyReader;
	private OperationalYearDAO operationalYearDAO;

	@Before
	public void setUp() throws MalformedURLException, SecurityContextBadCredentialException {
		securityContextHolder = mock(SecurityContextHolder.class);
		securityContextHolderFactory = new SecurityContextHolderFactory() {

			@Override
			public SecurityContextHolder getSecurityContextHolder(TARGET target) throws SecurityContextBadCredentialException {
				return securityContextHolder;
			}
		};

		this.environmentSpecificPropertyReader = mock(EnvironmentSpecificPropertyReader.class);
		this.environmentSpecificPropertyReaderFactory = mock(EnvironmentSpecificPropertyReaderFactory.class);
		when(environmentSpecificPropertyReaderFactory.getEnvironmentSpecificPropertyReader()).thenReturn(environmentSpecificPropertyReader);
		when(environmentSpecificPropertyReader.getEnvironmentSpecificProperty("osb_lasvc_prepaid_tons_url", null)).thenReturn("http://www.google.com");

		this.lASVCPrepaidTonsAdapterImpl = new LASVCPrepaidTonsAdapterImpl("osb_lasvc_prepaid_tons_url", SecurityContextHolderFactory.TARGET.INDUSTRY_SYSTEM, this.securityContextHolderFactory, this.environmentSpecificPropertyReaderFactory);

		osbService = mock(LASVCPrepaidTonsServiceAR.class);
		this.lASVCPrepaidTonsServiceFactory = mock(LASVCPrepaidTonsServiceFactory.class);
        when(lASVCPrepaidTonsServiceFactory.create(this.securityContextHolder, "http://www.google.com")).thenReturn(osbService);
		field("lASVCPrepaidTonsServiceFactory").ofType(LASVCPrepaidTonsServiceFactory.class).in(this.lASVCPrepaidTonsAdapterImpl).set(this.lASVCPrepaidTonsServiceFactory);

		this.transactionDAO = mock(TransactionDAO.class);
		field("transactionDAO").ofType(TransactionDAO.class).in(lASVCPrepaidTonsAdapterImpl).set(transactionDAO);

		operationalYearDAO = mock(OperationalYearDAO.class);
		field("operationalYearDAO").ofType(OperationalYearDAO.class).in(lASVCPrepaidTonsAdapterImpl).set(operationalYearDAO);

		initializateOperationalYear();
		initializateSale();
	}

	@Test
	public void testCancelPaymentCallsTransactionDaoFindTransactionBy_WhenCancelingOrderPayment() throws MalformedURLException, InfraException {
		Transaction transaction = new Transaction(1L);
		transaction.setType(TransactionType.CANCEL_PAID_SALE);
		transaction.getId();
		com.monsanto.brazilvaluecapture.osb.its.lasprepaidtonsar.bean.Transaction isTransaction =
                mock(com.monsanto.brazilvaluecapture.osb.its.lasprepaidtonsar.bean.Transaction.class);
		when(transactionDAO.findTransactionBy(Mockito.anyLong(), Mockito.eq(TransactionType.CANCEL_PAID_SALE))).thenReturn(transaction);
		when(osbService.manageAccount(anyString(), anyString(), Mockito.eq(isTransaction))).thenReturn(1l);

		// @Given a sale and a cancellation paid order
		Cancellation cancellation = new Cancellation();
		cancellation.setCancelPaidSaleOrder(true);

		// @When cancel a payment
		this.lASVCPrepaidTonsAdapterImpl.cancelPayment(sale, cancellation);

		// @Then a transaction is searched
		verify(this.transactionDAO, times(1)).findTransactionBy(Mockito.anyLong(), Mockito.eq(TransactionType.CANCEL_PAID_SALE));

	}
	
	private void initializateSale() {
		sale = new Sale(new Customer(), new Grower());
		Product product = new Product();
		Company company = new Company();
		product.setCompany(company);
		Technology technology = new Technology();
		technology.setId(1l);
		product.setTechnology(technology);
		Crop crop = new Crop();
		crop.setId(1l);
		product.setCrop(crop);

        Harvest harvest = new Harvest(company, "", operationalYear, crop, StatusEnum.ACTIVE);

        SaleTemplate saleTemplate = new SaleTemplate();
        saleTemplate.setHarvest(harvest);

        SaleItem saleItem = new SaleItem(sale, saleTemplate, product, null);

		Billing billing = new Billing();
		billing.setId(1L);
		saleItem.setBilling(billing);
		saleItem.setTotalCreditValue(1L);
		sale.getItems().add(saleItem);
	}

	private void initializateOperationalYear() {
		when(operationalYearDAO.selectAllOrderDesc()).thenReturn(new ArrayList<OperationalYear>() {
			{
				add(operationalYear);
			}
		});
	}
}
