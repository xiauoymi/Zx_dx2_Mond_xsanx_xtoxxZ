package com.monsanto.brazilvaluecapture.core.grower.model.dao.impl;

import com.monsanto.brazilvaluecapture.core.grower.model.bean.BonusExpirationSaleTemplate;
import com.monsanto.brazilvaluecapture.core.grower.model.dao.BonusExpirationSaleTemplateDAO;
import com.monsanto.brazilvaluecapture.core.wsiconsole.dao.impl.BaseHibernateUnitTest;
import com.monsanto.brazilvaluecapture.seedsale.template.model.bean.SaleTemplate;
import edu.emory.mathcs.backport.java.util.Collections;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.mockito.Matchers.anyString;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class BonusExpirationSaleTemplateDAOImpl_UT extends BaseHibernateUnitTest {
    private BonusExpirationSaleTemplateDAO dao;
    @Mock
    private SaleTemplate saleTemplate;
    @Mock
    private BonusExpirationSaleTemplate bonusExpirationSaleTemplate;

    @Before
    public void setUp() throws Exception {
        dao = new BonusExpirationSaleTemplateDAOImpl(sessionFactory);
    }

    @Test
    public void testFindBySaleTemplate() throws Exception {
        List expectedList = Collections.singletonList(bonusExpirationSaleTemplate);
        when(query.list()).thenReturn(expectedList);

        List<BonusExpirationSaleTemplate> bonusExpirationSaleTemplates = dao.findBy(saleTemplate);

        assertEquals(expectedList, bonusExpirationSaleTemplates);
        verify(query).setParameter(anyString(), eq(saleTemplate));
    }
}