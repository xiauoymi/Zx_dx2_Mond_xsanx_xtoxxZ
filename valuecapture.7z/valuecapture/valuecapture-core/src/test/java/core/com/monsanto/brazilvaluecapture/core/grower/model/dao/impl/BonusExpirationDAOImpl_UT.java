package com.monsanto.brazilvaluecapture.core.grower.model.dao.impl;

import com.monsanto.brazilvaluecapture.core.grower.model.dao.BonusExpirationFilter;
import com.monsanto.brazilvaluecapture.core.grower.model.dao.BonusRulesFilter;
import com.monsanto.brazilvaluecapture.core.wsiconsole.dao.impl.BaseHibernateUnitTest;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;

import static org.mockito.Matchers.anyObject;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/**
 * User: GMNAVE
 * Date: 4/30/14
 * Time: 12:24 PM
 */
@RunWith(MockitoJUnitRunner.class)

public class BonusExpirationDAOImpl_UT extends BaseHibernateUnitTest {

    private BonusExpirationDAOImpl bonusExpirationDAO;

    @Before
     public void setUp() {
        bonusExpirationDAO = new BonusExpirationDAOImpl(sessionFactory);
         MockitoAnnotations.initMocks(bonusExpirationDAO);
    }

    @Test
    public void testFindByFilter() throws Exception {

        //@Given
        BonusExpirationFilter filter = BonusExpirationFilter.getInstance();
        when(filter.buildCriteria(session)).thenReturn(criteria);

        //@When
        bonusExpirationDAO.findByFilter(filter);

        //@Should
        verify(criteria).list();

    }
}
