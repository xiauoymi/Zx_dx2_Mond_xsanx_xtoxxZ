package com.monsanto.brazilvaluecapture.seedsale.extract.credit.model.bean;

import com.monsanto.brazilvaluecapture.core.account.model.bean.Account;
import com.monsanto.brazilvaluecapture.core.account.model.bean.Entry;
import com.monsanto.brazilvaluecapture.core.account.model.bean.Transaction;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Crop;
import com.monsanto.brazilvaluecapture.core.base.model.bean.OperationalYear;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Technology;
import com.monsanto.brazilvaluecapture.core.grower.model.bean.Grower;
import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;
import static org.fest.assertions.Assertions.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

/**
 * User: HGFIOR
 * Date: 08/04/14
 * Time: 09:13
 */
public class CreditExtractLASBuilder_UT {

    private CreditExtractLASBuilder creditExtractLASBuilder;

    @Before
    public void setUp(){

    }

    @Test
    public void  test_build_given_a_valid_entry_should_return_a_list_with_one_valid_summaryCreditExtract_object(){
        List<Entry> entries = new ArrayList<Entry>();
        Account account = mock(Account.class);
        Technology technology = mock(Technology.class);
        Crop crop = mock(Crop.class);
        OperationalYear operationalYear = mock(OperationalYear.class);
        when(account.getTechnology()).thenReturn(technology);
        when(account.getCrop()).thenReturn(crop);
        when(account.getOperationalYear()).thenReturn(operationalYear);
        Entry dummyEntry = mock(Entry.class);
        when(dummyEntry.getAccount()).thenReturn(account);
        Transaction transaction = mock(Transaction.class);
        when(dummyEntry.getTransaction()).thenReturn(transaction);
        entries.add(dummyEntry);
        List<Grower> growers = new ArrayList<Grower>();
        Grower grower = mock(Grower.class);
        growers.add(grower);
        creditExtractLASBuilder = new CreditExtractLASBuilder(entries,growers);
        List<SummaryCreditExtract> summaryCreditExtractList = creditExtractLASBuilder.build(grower);

        assertThat(creditExtractLASBuilder).isNotNull();

        assertThat(summaryCreditExtractList).isNotEmpty();

        assertThat(summaryCreditExtractList).onProperty("grower").isNotNull();
        assertThat(summaryCreditExtractList).onProperty("grower").isNotEmpty();

        assertThat(summaryCreditExtractList).onProperty("operationalYear").isNotNull();
        assertThat(summaryCreditExtractList).onProperty("operationalYear").isNotEmpty();

        assertThat(summaryCreditExtractList).onProperty("details").isNotNull();
        assertThat(summaryCreditExtractList).onProperty("details").isNotEmpty();

    }


}
