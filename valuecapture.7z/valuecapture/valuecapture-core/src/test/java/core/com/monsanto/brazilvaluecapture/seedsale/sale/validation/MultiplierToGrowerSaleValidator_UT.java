package com.monsanto.brazilvaluecapture.seedsale.sale.validation;

import com.monsanto.brazilvaluecapture.core.foundation.util.ConstraintViolation;
import com.monsanto.brazilvaluecapture.core.foundation.validation.ValidationException;
import com.monsanto.brazilvaluecapture.core.foundation.validation.ValidationRule;
import com.monsanto.brazilvaluecapture.core.foundation.validation.ValidatorChain;
import com.monsanto.brazilvaluecapture.core.user.model.bean.UserDecorator;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.Sale;
import com.monsanto.brazilvaluecapture.seedsale.sale.service.SaleConstraintViolationException;
import com.monsanto.brazilvaluecapture.seedsale.sale.service.impl.MultiplierSaleValidator;
import org.apache.commons.lang3.RandomStringUtils;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.*;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.List;

import static junit.framework.Assert.fail;
import static org.fest.assertions.Assertions.assertThat;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class MultiplierToGrowerSaleValidator_UT {

    @Mock
    private GrowerValidationRule growerValidationRule;

    @Mock
    private GrowerGLAValidationRule growerGLAValidationRule;

    @Mock
    private SaleCityValidationRule saleCityValidationRule;

    @Mock
    private SaleItemsAllDueDatesMustBeTheSameValidationRule saleItemsAllDueDatesMustBeTheSameValidationRule;

    @Mock
    private SaleTotalCashAdvanceAvailableValidationRule saleTotalCashAdvanceAvailableValidationRule;

    @Mock
    private MultiplierSaleValidator multiplierSaleValidator;

    @Spy
    private ValidatorChain<Sale> validatorChain = new ValidatorChain<Sale>();
    @InjectMocks
    private MultiplierToGrowerSaleValidator multiplierToGrowerSaleValidator = new MultiplierToGrowerSaleValidator() {
        @Override
        protected ValidatorChain<Sale> createValidatorChain() {
            return validatorChain;
        }
    };
    @Mock
    private SaleItemNetRoyaltyValueLessThanCashAdvanceValidationRule saleItemNetRoyaltyValueLessThanCashAdvanceValidationRule;
    private UserDecorator userDecorator;


    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
        multiplierToGrowerSaleValidator.createRules();
        userDecorator = mock(UserDecorator.class);
    }

    @Test
    public void testCreateRulesAddsSaleItemNetRoyaltyValueLessThanCashAdvanceValidationRule_WhenCreatingRules() {
        //assertRuleIsAdded(growerValidationRule);
        assertRuleIsAdded(growerGLAValidationRule);
        assertRuleIsAdded(saleCityValidationRule);
        assertRuleIsAdded(saleItemsAllDueDatesMustBeTheSameValidationRule);
        assertRuleIsAdded(saleTotalCashAdvanceAvailableValidationRule);
        assertRuleIsAdded(saleItemNetRoyaltyValueLessThanCashAdvanceValidationRule);
    }

    private void assertRuleIsAdded(ValidationRule<Sale> rule) {
        ArgumentCaptor<ValidationRule> ruleCaptor = ArgumentCaptor.forClass(ValidationRule.class);
        verify(validatorChain, atLeastOnce()).addRule(ruleCaptor.capture());
        final List<ValidationRule> allValues = ruleCaptor.getAllValues();

        assertThat(allValues).contains(rule);
    }

    @Test
    public void testValidateInvokesMultiplierSaleValidationValidateMethod_WhenValidatingSale() throws SaleConstraintViolationException {
        Sale sale = new Sale();
        UserDecorator userDecorator = mock(UserDecorator.class);
        SaleConstraintViolationException expectedException = new SaleConstraintViolationException("ERROR MESSAGE");
        when(multiplierSaleValidator.validate(sale)).thenReturn(expectedException);

        multiplierToGrowerSaleValidator.validate(sale);

        verify(multiplierSaleValidator).validate(sale);
    }

    @Test
    public void testValidateThrowsException_WhenMultiplierSaleValidationFails() {
        Sale sale = new Sale();
        SaleConstraintViolationException expectedException = new SaleConstraintViolationException("ERROR MESSAGE");
        expectedException.add(new ConstraintViolation("MESG", "CODE", "FIELD"));
        when(multiplierSaleValidator.validate(sale)).thenReturn(expectedException);

        try {
            multiplierToGrowerSaleValidator.validate(sale);
            fail("Should throw SaleConstraintViolationException");
        } catch (SaleConstraintViolationException e) {
            assertThat(e).isInstanceOf(SaleConstraintViolationException.class);
        }
    }

    @Test
    public void validateCollectingAllViolationsThrowsSaleConstraintViolationException_WhenMultiplierSaleValidatorThrowsSaleConstraintViolationException() {
        Sale sale = new Sale();
        SaleConstraintViolationException saleConstraintValidationException = createSaleConstraintViolationExceptionWithViolations();
        when(multiplierSaleValidator.validate(sale)).thenReturn(saleConstraintValidationException);

        try {
            multiplierToGrowerSaleValidator.validateCollectingAllViolations(sale);
            fail("Should throw SaleConstraintViolationException");
        } catch (SaleConstraintViolationException e) {
            ConstraintViolation constraintViolation = saleConstraintValidationException.getViolations().get(0);
            assertThat(e.getViolations()).contains(constraintViolation);
        }
    }

    @Test
    public void validateCollectingAllViolationsThrowsViolationsFromMultiplierSaleValidatorAndValidationRules() throws ValidationException {
        Sale sale = new Sale();
        SaleConstraintViolationException errorFromSaleValidator = createSaleConstraintViolationExceptionWithViolations();
        when(multiplierSaleValidator.validate(sale)).thenReturn(errorFromSaleValidator);

        SaleConstraintViolationException errorFromGrowerGLAValidationRule = createSaleConstraintViolationExceptionWithViolations();
        when(growerGLAValidationRule.validate(sale)).thenThrow(new SaleValidationException(errorFromGrowerGLAValidationRule));

        SaleConstraintViolationException errorFromSaleCityValidationRule = createSaleConstraintViolationExceptionWithViolations();
        when(saleCityValidationRule.validate(sale)).thenThrow(new SaleValidationException(errorFromSaleCityValidationRule));

        try {
            multiplierToGrowerSaleValidator.validateCollectingAllViolations(sale);
            fail("Should throw SaleConstraintViolationException");
        } catch (SaleConstraintViolationException e) {
            assertThat(e.getViolations()).contains(errorFromSaleValidator.getViolations().get(0));
            assertThat(e.getViolations()).contains(errorFromGrowerGLAValidationRule.getViolations().get(0));
            assertThat(e.getViolations()).contains(errorFromSaleCityValidationRule.getViolations().get(0));
        }
    }

    @Test
    public void validateCollectingAllValidationDoNotThrowsSaleViolationException_WhenNoViolationsAreFound() {
        Sale sale = new Sale();
        SaleConstraintViolationException errorFromSaleValidator = new SaleConstraintViolationException("");
        when(multiplierSaleValidator.validate(sale)).thenReturn(errorFromSaleValidator);

        try {
            multiplierToGrowerSaleValidator.validateCollectingAllViolations(sale);
        } catch (SaleConstraintViolationException e) {
            fail("Should not throw SaleContraintViolationException");
        }
    }

    private SaleConstraintViolationException createSaleConstraintViolationExceptionWithViolations() {
        SaleConstraintViolationException saleConstraintValidationException = new SaleConstraintViolationException("Message");
        saleConstraintValidationException.add(new ConstraintViolation(RandomStringUtils.random(5), "code", "field"));
        return saleConstraintValidationException;
    }


}
