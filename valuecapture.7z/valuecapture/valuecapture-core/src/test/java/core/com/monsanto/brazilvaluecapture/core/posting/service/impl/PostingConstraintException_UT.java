package com.monsanto.brazilvaluecapture.core.posting.service.impl;

import java.util.Locale;
import java.util.ResourceBundle;

import junit.framework.Assert;

import org.junit.Before;
import org.junit.Test;

import com.monsanto.brazilvaluecapture.core.foundation.util.ConstraintViolation;
import com.monsanto.brazilvaluecapture.core.foundation.util.ErrorCode;
import com.monsanto.brazilvaluecapture.core.posting.service.PostingConstraintException;

/**
 * @author cmiranda
 * 
 */
public class PostingConstraintException_UT {

    // Resource bundle
    private ResourceBundle resourceBundle = ResourceBundle.getBundle("bundle/bundle");

    @Before
    public void setup() {
        Locale.setDefault(Locale.US);
    }

    @Test
    public void test_get_formatted_message_for_import_without_violations() {

        PostingConstraintException exception = new PostingConstraintException("error!");
        Assert.assertEquals("", exception.getFormattedMessageForImport(resourceBundle));

    }

    @Test
    public void test_get_formatted_message_for_import() {

        PostingConstraintException exception = new PostingConstraintException("error!");
        exception.add(new ConstraintViolation("error.posting.balance.insufficient.delete",
                ErrorCode.INSUFFICIENT_BALANCE, "label.posting.account.credit", 1000));

        Assert.assertEquals(
                "Posting can not be deleted because Credit Account does not have sufficient balance. Current Balance:  {1}\n",
                exception.getFormattedMessageForImport(resourceBundle));

    }

}
