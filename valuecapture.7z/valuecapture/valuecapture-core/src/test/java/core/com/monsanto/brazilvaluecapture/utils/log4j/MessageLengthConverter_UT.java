package com.monsanto.brazilvaluecapture.utils.log4j;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.core.LogEvent;
import org.apache.logging.log4j.message.Message;
import org.junit.Test;

import static junit.framework.Assert.*;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;


public class MessageLengthConverter_UT {
    private Logger logger = LogManager.getLogger(MessageLengthConverter_UT.class);

    @Test
    public void testConverterCanBeCreatedFromStatic_newInstance_method() {
        MessageLengthConverter lengthConverter = MessageLengthConverter.newInstance(null, new String[]{"10"});
        assertNotNull(lengthConverter);
        assertTrue(lengthConverter.getFormats().length == 1);
    }

    @Test
    public void testNullMessage_doNot_modifyOriginalTheMessage() {
        LogEvent logEvent = mock(LogEvent.class);
        when(logEvent.getMessage()).thenReturn(null);

        MessageLengthConverter lengthConverter = MessageLengthConverter.newInstance(null, new String[]{"10"});
        StringBuilder sb = new StringBuilder();
        lengthConverter.format(logEvent, sb);

        assertTrue(sb.toString().length() == 0);
    }

    @Test
    public void testFormatsLessInvocation_doNot_modifyOriginalTheMessage() {
        final String originalMessage = "unmodified message";
        LogEvent logEvent = mock(LogEvent.class);
        Message message = mock(Message.class);
        when(message.getFormattedMessage()).thenReturn(originalMessage);
        when(logEvent.getMessage()).thenReturn(message);

        MessageLengthConverter lengthConverter = MessageLengthConverter.newInstance(null, new String[]{});
        StringBuilder sb = new StringBuilder();
        lengthConverter.format(logEvent, sb);

        assertEquals(originalMessage, sb.toString());
    }

    @Test
    public void testNotNumericFormattingOption_when_newInstanceThrowsException() {
        final String originalMessage = "unmodified message";
        LogEvent logEvent = mock(LogEvent.class);
        Message message = mock(Message.class);
        when(message.getFormattedMessage()).thenReturn(originalMessage);
        when(logEvent.getMessage()).thenReturn(message);

        MessageLengthConverter lengthConverter = null;
        try {
            lengthConverter = MessageLengthConverter.newInstance(null, new String[]{"a"});
            fail("Should throw exception");
        } catch (IllegalArgumentException e) {

        }
        assertNull(lengthConverter);
    }

    @Test
    public void testNegativeFormattingOption_when_newInstanceThrowsException() {
        final String originalMessage = "unmodified message";
        LogEvent logEvent = mock(LogEvent.class);
        Message message = mock(Message.class);
        when(message.getFormattedMessage()).thenReturn(originalMessage);
        when(logEvent.getMessage()).thenReturn(message);

        MessageLengthConverter lengthConverter = null;
        try {
            lengthConverter = MessageLengthConverter.newInstance(null, new String[]{"-1000"});
            fail("Should throw exception");
        } catch (IllegalArgumentException e) {

        }
        assertNull(lengthConverter);
    }

    @Test
    public void testOriginalMessageIsNotModifiedWhenMaxLenghtFormatOption_isGreatThan_actualMessageLength() {
        final String originalMessage = "unmodified message";
        LogEvent logEvent = mock(LogEvent.class);
        Message message = mock(Message.class);
        when(message.getFormattedMessage()).thenReturn(originalMessage);
        when(logEvent.getMessage()).thenReturn(message);

        MessageLengthConverter lengthConverter = MessageLengthConverter.newInstance(null, new String[]{"100"});
        StringBuilder sb = new StringBuilder();
        lengthConverter.format(logEvent, sb);
        assertEquals(originalMessage, sb.toString());
    }

    @Test
    public void testOriginalMessageIsTruncatedToTheLengthSpecifiedInTheFormat() {
        final String originalMessage = "ABCDEFGHIJKLMNÑOPQRSTUVWXYZ";
        LogEvent logEvent = mock(LogEvent.class);
        Message message = mock(Message.class);
        when(message.getFormattedMessage()).thenReturn(originalMessage);
        when(logEvent.getMessage()).thenReturn(message);

        MessageLengthConverter lengthConverter = MessageLengthConverter.newInstance(null, new String[]{"10"});
        StringBuilder sb = new StringBuilder();
        lengthConverter.format(logEvent, sb);
        String expectedMessage = "ABCDEFGHIJ";
        assertTrue(sb.toString().equals(expectedMessage));
    }
}
