package com.monsanto.brazilvaluecapture.core.grower.service.impl;

import com.monsanto.brazilvaluecapture.core.base.model.bean.OperationalYear;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Technology;
import com.monsanto.brazilvaluecapture.core.foundation.service.MBusinessException;
import com.monsanto.brazilvaluecapture.core.grower.model.bean.*;
import com.monsanto.brazilvaluecapture.core.grower.model.dao.BonusRulesDAO;
import com.monsanto.brazilvaluecapture.core.grower.model.dao.BonusRulesFilter;
import com.monsanto.brazilvaluecapture.core.grower.service.AgreementService;
import com.monsanto.brazilvaluecapture.seedsale.bonus.BonusService;
import edu.emory.mathcs.backport.java.util.Arrays;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class BonusRulesServiceImpl_UT {

    @Mock
    private BonusRulesDAO bonusRulesDAO;

    @Mock
    private AgreementService agreementService;

    @Mock
    private BonusService bonusService;

    @InjectMocks
    private BonusRulesServiceImpl bonusRulesService;

    @Test
    public void test_findByCompanyCropTechnology() throws Exception {
        //@Given
        AgreementTemplate agreementTemplate = Mockito.mock(AgreementTemplate.class);
        OperationalYear operationalYear = Mockito.mock(OperationalYear.class);
        BonusRules.Status status = BonusRules.Status.ACTIVE;

        //@When
        bonusRulesService.findByAgreementTemplateOperationalYearStatus(agreementTemplate, operationalYear, status);

        //@Then
        verify(bonusRulesDAO).findByFilter((BonusRulesFilter) any());
    }

    @Test
    public void test_disable() throws Exception {
        //@Given
        BonusRules bonusRules = new BonusRules();

        //@When
        bonusRulesService.disable(bonusRules);

        //@Then
        verify(bonusRulesDAO).createOrUpdate(bonusRules);
    }

    @Test
    public void test_createOrUpdate() throws Exception {
        //@Given
        BonusRules bonusRules = new BonusRules();

        //@When
        bonusRulesService.createOrUpdate(bonusRules);

        //@Then
        verify(bonusRulesDAO).createOrUpdate(bonusRules);
    }

    @Test
    public void testFindBonusRuleCallsFindBonusRuleByAgreementTemplateAndOperationYear_whenGrowerHasOneActiveAgreementForGivenBonusConsumption() throws Exception {
        BonusConsumption bonusConsumption = new BonusConsumption();
        OperationalYear operationalYear = new OperationalYear("2014");
        bonusConsumption.setOperationalYear(operationalYear);
        Agreement agreement1 = createAgreement("DUMMY_TECHNOLOGY_1", "AGREEMENT_TEMPLATE_TYPE_1");
        bonusConsumption.setAgreementTemplateType(agreement1.getAgreementTemplate().getAgreementTemplateType());
        List<Agreement> agreementList = Arrays.asList(new Agreement[]{agreement1});
        when(agreementService.getActiveAgreementsByGrower(bonusConsumption.getGrower())).thenReturn(agreementList);
        when(bonusService.findAgreementBy(bonusConsumption.getGrower(), bonusConsumption.getTechnology())).thenReturn(agreement1);
        when(bonusRulesDAO.findBonusRuleByAgreementTemplateAndOperationYear(Matchers.<AgreementTemplate>anyObject(), Matchers.<OperationalYear>anyObject())).thenReturn(new BonusRules());

        bonusRulesService.findBonusRule(bonusConsumption);

        verify(bonusService).findAgreementBy(bonusConsumption.getGrower(), bonusConsumption.getTechnology());
        verify(bonusRulesDAO).findBonusRuleByAgreementTemplateAndOperationYear(agreement1.getAgreementTemplate(), operationalYear);
    }

    @Test(expected = MBusinessException.class)
    public void testFindBonusRuleCallsFindBonusRuleByAgreementTemplateAndOperationYear_whenThereIsNoValidBonusRule() throws Exception {
        BonusConsumption bonusConsumption = new BonusConsumption();
        OperationalYear operationalYear = new OperationalYear("2014");
        bonusConsumption.setOperationalYear(operationalYear);
        Agreement agreement1 = createAgreement("DUMMY_TECHNOLOGY_1", "AGREEMENT_TEMPLATE_TYPE_1");
        bonusConsumption.setAgreementTemplateType(agreement1.getAgreementTemplate().getAgreementTemplateType());
        List<Agreement> agreementList = Arrays.asList(new Agreement[]{agreement1});
        when(agreementService.getActiveAgreementsByGrower(bonusConsumption.getGrower())).thenReturn(agreementList);
        when(bonusService.findAgreementBy(bonusConsumption.getGrower(), bonusConsumption.getTechnology())).thenReturn(agreement1);

        bonusRulesService.findBonusRule(bonusConsumption);

        verify(bonusService).findAgreementBy(bonusConsumption.getGrower(), bonusConsumption.getTechnology());
        verify(bonusRulesDAO).findBonusRuleByAgreementTemplateAndOperationYear(agreement1.getAgreementTemplate(), operationalYear);
    }

    @Test
    public void testFindBonusRuleFails_whenAgreementCannotBeFound() throws Exception {
        BonusConsumption bonusConsumption = new BonusConsumption();
        OperationalYear operationalYear = new OperationalYear("2014");
        bonusConsumption.setOperationalYear(operationalYear);
        Agreement agreement1 = createAgreement("DUMMY_TECHNOLOGY_1", "AGREEMENT_TEMPLATE_TYPE_1");
        bonusConsumption.setAgreementTemplateType(agreement1.getAgreementTemplate().getAgreementTemplateType());
        List<Agreement> agreementList = Arrays.asList(new Agreement[]{agreement1});
        when(agreementService.getActiveAgreementsByGrower(bonusConsumption.getGrower())).thenReturn(agreementList);
        MBusinessException exception = new MBusinessException("");
        when(bonusService.findAgreementBy(bonusConsumption.getGrower(), bonusConsumption.getTechnology())).thenThrow(exception);

        try {
            bonusRulesService.findBonusRule(bonusConsumption);
            fail("Should not happen");
        } catch (MBusinessException e) {
            assertEquals(e.getMessage(), "import.file.bulk.bonus.no.valid.agreement.found.1");
        }
    }

    private Agreement createAgreement(String technologyName, String agreementTemplateTypeDescription) {
        Agreement agreement = new Agreement();
        AgreementTemplate agreementTemplate = new AgreementTemplate();
        Technology technology = new Technology();
        technology.setDescription(technologyName);
        agreementTemplate.setTechnology(technology);
        AgreementTemplateType agreementTemplateType = new AgreementTemplateType();
        agreementTemplateType.setDescription(agreementTemplateTypeDescription);
        agreementTemplate.setAgreementTemplateType(agreementTemplateType);
        agreement.setAgreementTemplate(agreementTemplate);

        return agreement;
    }

}