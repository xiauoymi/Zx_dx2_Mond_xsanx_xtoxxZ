package com.monsanto.brazilvaluecapture.seedsale.billing.model.dao.impl;

import com.monsanto.brazilvaluecapture.seedsale.billing.service.NotPossibleGetTransctionBilletException;
import junit.framework.Assert;
import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.hibernate.classic.Session;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyObject;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.*;

/**
 * Created by IntelliJ IDEA.
 * User: JAKAGI
 * Date: 08/10/13
 * Time: 15:21
 * To change this template use File | Settings | File Templates.
 */
public class BilletTransactionDAOMockedImpl_UT {


    @Mock
    private SessionFactory sessionFactory;

    @Before
    public void setUp() throws Exception {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void when_getTransactionIdException() throws Exception {

        boolean error=false;

        BilletTransactionDAOMockedImpl billetTransactionDAOMockedImpl = new BilletTransactionDAOMockedImpl(sessionFactory);
        BilletTransactionDAOMockedImpl spy = Mockito.spy(billetTransactionDAOMockedImpl);

        doThrow(new HibernateException("Fake Exception Error")).when(spy).generateTransactionNumber();
        try{
            when(spy.getTransactionId()).thenCallRealMethod();
            spy.getTransactionId();
            error=true;
        }catch (Exception e){
            if (!(e instanceof NotPossibleGetTransctionBilletException)){
                error=true;
            }

        }

        Assert.assertEquals("when_getTransactionIdException fail", error, false);


    }

}
