package com.monsanto.brazilvaluecapture.core.grower.model.dao.impl;

import com.monsanto.brazilvaluecapture.core.foundation.util.HibernateDAO;
import com.monsanto.brazilvaluecapture.core.grower.model.bean.AgreementApprovalLog;
import com.monsanto.brazilvaluecapture.core.grower.model.bean.EmailParameters;

import org.hibernate.Query;
import org.hibernate.classic.Session;
import org.hibernate.criterion.Criterion;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.hibernate.SessionFactory;
import org.mockito.runners.MockitoJUnitRunner;

import static org.fest.assertions.Assertions.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.*;

/**
 * User: HGFIOR
 * Date: 19/09/13
 * Time: 16:49
 */
public class EmailParametersDAOImpl_UT {

    @Mock
    private SessionFactory sessionFactory = Mockito.mock(SessionFactory.class);
    @Mock private Session session;
    @InjectMocks
    private EmailParametersDAOImpl dao;
    @Mock private Query query = Mockito.mock(Query.class);

    protected static final String EMAIL_PARAMETERS_QUERY = "select ep from EmailParameters ep where ep.action=:action and ep.country.id=:countryId";

    @Before
    public void setUp() {
        SessionFactory sessionFactory = mock(SessionFactory.class);
        this.session = mock(Session.class);
        when(sessionFactory.getCurrentSession()).thenReturn(this.session);
        this.dao = new EmailParametersDAOImpl(sessionFactory);
        this.query = mock(Query.class);
        when(this.session.createQuery(anyString())).thenReturn(this.query);
        when(query.uniqueResult()).thenReturn(Mockito.mock(EmailParameters.class));
    }
    @Test
    public void testGetEmailParametersByAction(){
        EmailParameters emailParameters = dao.getEmailParametersByAction(AgreementApprovalLog.AgreementStatus.APPROVED,new Long(33261));
        assertThat(emailParameters).isNotNull();
        verify(session).createQuery(EMAIL_PARAMETERS_QUERY);
        verify(this.query, times(1)).setParameter("action", AgreementApprovalLog.AgreementStatus.APPROVED.name());
        verify(this.query, times(1)).setParameter("countryId", new Long(33261));
        verify(this.query, times(1)).uniqueResult();
    }



}
