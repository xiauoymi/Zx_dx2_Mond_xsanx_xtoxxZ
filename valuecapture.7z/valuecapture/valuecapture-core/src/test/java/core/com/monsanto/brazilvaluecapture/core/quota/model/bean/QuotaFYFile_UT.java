package com.monsanto.brazilvaluecapture.core.quota.model.bean;

import org.junit.Test;

import static org.junit.Assert.*;

public class QuotaFYFile_UT {

    @Test
    public void getErrorFileNameShouldReturnNull() {
        QuotaFYFile file = new QuotaFYFile();

        assertNull(file.getErrorFileName());
    }

    @Test
    public void getErrorFileNameShouldReturnCorrectValue() {
        QuotaFYFile file = new QuotaFYFile();
        file.setFileName("hello_world.csv");

        assertEquals("hello_worldError.txt", file.getErrorFileName());
    }

    @Test
    public void getErrorFileNameShouldReturnCorrectValue2() {
        QuotaFYFile file = new QuotaFYFile();
        file.setFileName("hello_world");

        assertEquals("hello_worldError.txt", file.getErrorFileName());
    }

}
