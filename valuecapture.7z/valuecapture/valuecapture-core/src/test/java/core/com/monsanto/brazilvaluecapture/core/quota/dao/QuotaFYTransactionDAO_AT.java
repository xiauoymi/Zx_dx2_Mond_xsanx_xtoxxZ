package com.monsanto.brazilvaluecapture.core.quota.dao;

import com.monsanto.brazilvaluecapture.core.foundation.test.AbstractServiceIntegrationTests;
import com.monsanto.brazilvaluecapture.core.foundation.test.dbunit.DbUnitHelper;
import com.monsanto.brazilvaluecapture.core.quota.model.bean.*;
import com.monsanto.brazilvaluecapture.core.quota.model.dao.QuotaFYTransactionDAO;
import com.monsanto.brazilvaluecapture.seedsale.warehouse.model.bean.Warehouse;
import com.monsanto.brazilvaluecapture.seedsale.warehouse.model.dao.WarehouseDAO;
import org.hibernate.Hibernate;
import org.hibernate.PropertyValueException;
import org.hibernate.exception.ConstraintViolationException;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.math.BigDecimal;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;

import static org.fest.assertions.Assertions.assertThat;
import static org.junit.Assert.fail;

/**
 * Created by IntelliJ IDEA.
 * User: GAVELO
 * Date: 4/25/13
 * Time: 6:09 PM
 * To change this template use File | Settings | File Templates.
 */
public class QuotaFYTransactionDAO_AT extends AbstractServiceIntegrationTests {

    private static final String EXCEPTION_MESSAGE_QUOTA_FY_CREDIT_NOTE = "com.monsanto.brazilvaluecapture.core.quota.model.bean.QuotaFYCreditNote";
    private static final String EXCEPTION_MESSAGE_QUOTA_FY_PAID = "com.monsanto.brazilvaluecapture.core.quota.model.bean.QuotaFYPaid";
    private static final String EXCEPTION_MESSAGE_QUOTA_FY_BILLED = "com.monsanto.brazilvaluecapture.core.quota.model.bean.QuotaFYBilled";
    @Autowired
    private QuotaFYTransactionDAO dao;
    @Autowired
    private WarehouseDAO warehouseDAO;
    private QuotaFY quota;

    @Before
    public void setUp() {

        DbUnitHelper.setup("classpath:data/core/basic-fixture.xml", "classpath:data/core/quotaFY-dataset.xml", "classpath:data/core/quotaFYTransaction-dataset.xml");

        quota = (QuotaFY) getSession().load(QuotaFY.class, 990000003L);
        Hibernate.initialize(quota);

    }

    // QuotaFYPaid

    @Test
    public void testSaveQuotaFYPaid() {

        QuotaFYPaid transaction = createQuotaFYPaid();

        Assert.assertNull(transaction.getId());

        dao.save(transaction);

        Assert.assertNotNull(transaction.getId());

    }

    @Test(expected = PropertyValueException.class)
    public void testSaveQuotaFYPaidWithNullInvoice() {

        QuotaFYPaid transaction = createQuotaFYPaid();
        transaction.setInvoiceNumber(null);

        dao.save(transaction);

        Assert.fail();


    }


    @Test(expected = PropertyValueException.class)
    public void testSaveQuotaFYPaidWithNullEntryValue() {

        QuotaFYPaid transaction = createQuotaFYPaid();
        transaction.setEntryValue(null);

        dao.save(transaction);

        Assert.fail();

    }


    @Test(expected = PropertyValueException.class)
    public void testSaveQuotaFYPaidWithNullQuotaFY() {

        QuotaFYPaid transaction = createQuotaFYPaid();
        transaction.setQuota(null);

        dao.save(transaction);

        Assert.fail();

    }

    @Test
    public void testQuotaFYTransactionDAOThrowHibernateExceptionWhenSaveDuplicateQuotaFYPaidUniqueAttributes() {

        QuotaFYPaid transaction = createQuotaFYPaid();

        dao.save(transaction);

        transaction = createQuotaFYPaid();

        try{
            dao.save(transaction);
            fail();
        } catch (ConstraintViolationException e) {
            assertThat(e).hasMessage("could not insert: [" + EXCEPTION_MESSAGE_QUOTA_FY_PAID + "]");
        } catch (Exception e) {
            fail();
        }
    }

    @Test
    public void testSaveQuotaFYPaidMapping() {

        QuotaFYPaid transaction = createQuotaFYPaid();

        Assert.assertNull(transaction.getId());

        dao.save(transaction);

        Assert.assertNotNull(transaction.getId());

        flushObject(transaction);

        QuotaFYPaid transactionDb = (QuotaFYPaid) getSession().load(QuotaFYPaid.class, transaction.getId());

        Assert.assertEquals(transaction.getId(), transactionDb.getId());
        Assert.assertEquals(transaction.getInvoiceNumber(), transactionDb.getInvoiceNumber());
        Assert.assertEquals(transaction.getEntryValue(), transactionDb.getEntryValue());
        Assert.assertEquals(transaction.getQuota().getId(), transactionDb.getQuota().getId());
        Assert.assertEquals(transaction.getSaleOrder(), transactionDb.getSaleOrder());
        Assert.assertEquals(this.getGregorianCalendarDate(transaction.getTransactionDate(), Calendar.DAY_OF_MONTH), this.getGregorianCalendarDate(transactionDb.getTransactionDate(), Calendar.DAY_OF_MONTH));
        Assert.assertEquals(this.getGregorianCalendarDate(transaction.getTransactionDate(), Calendar.MONTH), this.getGregorianCalendarDate(transactionDb.getTransactionDate(), Calendar.MONTH));
        Assert.assertEquals(this.getGregorianCalendarDate(transaction.getTransactionDate(), Calendar.YEAR), this.getGregorianCalendarDate(transactionDb.getTransactionDate(), Calendar.YEAR));
        Assert.assertEquals(transaction.getTransactionType(), transactionDb.getTransactionType());
    }

    /**
     * Get the date data using the gregorian calendar
     * @param transactionDate
     * @param period is the type of information to get from the date
     * @return the gregorian calendar representation of the date data
     */
    private int getGregorianCalendarDate(Date transactionDate, int period) {
        GregorianCalendar gcExpected = new GregorianCalendar();
        gcExpected.setTime(transactionDate);

        return gcExpected.get(period);
    }


    @Test
    public void testQuotaFYPaidSelectById() {

        quota = (QuotaFY) getSession().load(QuotaFY.class, 990000004L);
        Hibernate.initialize(quota);

        QuotaFYPaid transaction = createQuotaFYPaid();
        transaction.setQuota(quota);

        Assert.assertNull(transaction.getId());

        dao.save(transaction);

        Assert.assertNotNull(transaction.getId());

        flushObject(transaction);

        List<QuotaFYTransaction> transactionList = dao.selectByQuotaFYId(quota.getId());

        Assert.assertEquals(1,transactionList.size());
        QuotaFYTransaction savedTransaction = transactionList.get(0);
        Assert.assertEquals( QuotaFYPaid.class, savedTransaction.getClass());

    }



    // QuotaFYCreditNote


    @Test
    public void testSaveQuotaFYCreditNote() throws Exception {

        QuotaFYCreditNote transaction = createQuotaFYCreditNote();

        Assert.assertNull(transaction.getId());

        dao.save(transaction);

        Assert.assertNotNull(transaction.getId());

    }

    @Test(expected = PropertyValueException.class)
    public void testQuotaFYCreditNoteWithNullGermoSupplierLocation() throws Exception {

        QuotaFYCreditNote transaction = createQuotaFYCreditNote();
        transaction.setWarehouse(null);

        dao.save(transaction);

        Assert.fail();


    }


    @Test(expected = PropertyValueException.class)
    public void testQuotaFYCreditNoteWithNullLoginUser() throws Exception {

        QuotaFYCreditNote transaction = createQuotaFYCreditNote();
        transaction.setLoginUser(null);

        dao.save(transaction);

        Assert.fail();

    }


    @Test(expected = PropertyValueException.class)
    public void testQuotaFYCreditNoteWithNullReferenceInvoiceNumber() throws Exception {

        QuotaFYCreditNote transaction = createQuotaFYCreditNote();
        transaction.setReferenceInvoiceNumber(null);

        dao.save(transaction);

        Assert.fail();

    }


    @Test
    public void testQuotaFYCreditNoteMapping() throws Exception {

        QuotaFYCreditNote transaction = createQuotaFYCreditNote();

        Assert.assertNull(transaction.getId());

        dao.save(transaction);

        Assert.assertNotNull(transaction.getId());

        flushObject(transaction);

        QuotaFYCreditNote transactionDb = (QuotaFYCreditNote) getSession().load(QuotaFYCreditNote.class, transaction.getId());

        Assert.assertEquals(transaction.getId(), transactionDb.getId());
        Assert.assertEquals(transaction.getEntryValue(), transactionDb.getEntryValue());
        Assert.assertEquals(transaction.getQuota().getId(), transactionDb.getQuota().getId());
        Assert.assertEquals(transaction.getSaleOrder(), transactionDb.getSaleOrder());
        Assert.assertEquals(this.getGregorianCalendarDate(transaction.getTransactionDate(), Calendar.DAY_OF_MONTH), this.getGregorianCalendarDate(transactionDb.getTransactionDate(), Calendar.DAY_OF_MONTH));
        Assert.assertEquals(this.getGregorianCalendarDate(transaction.getTransactionDate(), Calendar.MONTH), this.getGregorianCalendarDate(transactionDb.getTransactionDate(), Calendar.MONTH));
        Assert.assertEquals(this.getGregorianCalendarDate(transaction.getTransactionDate(), Calendar.YEAR), this.getGregorianCalendarDate(transactionDb.getTransactionDate(), Calendar.YEAR));
        Assert.assertEquals(transaction.getTransactionType(), transactionDb.getTransactionType());
        Assert.assertEquals(transaction.getCreditNoteNumber(), transactionDb.getCreditNoteNumber());
        Assert.assertEquals(transaction.getLoginUser(), transactionDb.getLoginUser());
        Assert.assertEquals(transaction.getReferenceInvoiceNumber(), transactionDb.getReferenceInvoiceNumber());

    }


    @Test
    public void testQuotaFYCreditNoteSelectById() throws Exception {

        quota = (QuotaFY) getSession().load(QuotaFY.class, 990000004L);
        Hibernate.initialize(quota);

        QuotaFYCreditNote transaction = createQuotaFYCreditNote();
        transaction.setQuota(quota);

        Assert.assertNull(transaction.getId());

        dao.save(transaction);

        Assert.assertNotNull(transaction.getId());

        flushObject(transaction);

        List<QuotaFYTransaction> transactionList = dao.selectByQuotaFYId(quota.getId());

        Assert.assertEquals(1,transactionList.size());
        QuotaFYTransaction savedTransaction = transactionList.get(0);
        Assert.assertEquals( QuotaFYCreditNote.class, savedTransaction.getClass());

    }

    @Test
    public void testQuotaFYTransactionDAOThrowHibernateExceptionWhenSaveDuplicateQuotaFYCreditNotedUniqueAttributes()
            throws Exception {

        QuotaFYCreditNote transaction = createQuotaFYCreditNote();

        dao.save(transaction);

        transaction = createQuotaFYCreditNote();

        try{
            dao.save(transaction);
           // fail();
        } catch (ConstraintViolationException e) {
            assertThat(e).hasMessage("could not insert: [" + EXCEPTION_MESSAGE_QUOTA_FY_CREDIT_NOTE + "]");
        } catch (Exception e) {
            fail();
        }
    }

    // QuotaFYBilled


    @Test
    public void testSaveQuotaFYBilled() throws Exception {

        QuotaFYBilled transaction = createQuotaFYBilled();

        Assert.assertNull(transaction.getId());

        dao.save(transaction);

        Assert.assertNotNull(transaction.getId());

    }


    @Test(expected = PropertyValueException.class)
    public void testQuotaFYBilledWithNullGermoSupplierLocation() throws Exception {

        QuotaFYBilled transaction = createQuotaFYBilled();
        transaction.setWarehouse(null);

        dao.save(transaction);

        Assert.fail();


    }


    @Test(expected = PropertyValueException.class)
    public void testQuotaFYBilledWithNullLoginUser() throws Exception {

        QuotaFYBilled transaction = createQuotaFYBilled();
        transaction.setLoginUser(null);

        dao.save(transaction);

        Assert.fail();

    }


    @Test(expected = PropertyValueException.class)
    public void testQuotaFYBilledWithNullInvoiceNumber() throws Exception {

        QuotaFYBilled transaction = createQuotaFYBilled();
        transaction.setInvoiceNumber(null);

        dao.save(transaction);

        Assert.fail();

    }


    @Test
    public void testQuotaFYTransactionDAOThrowHibernateExceptionWhenSaveDuplicateQuotaFYBilledUniqueAttributes()
            throws Exception {

        QuotaFYBilled transaction = createQuotaFYBilled();

        dao.save(transaction);

        transaction = createQuotaFYBilled();

        try{
            dao.save(transaction);
          //  fail();
        } catch (ConstraintViolationException e) {
            assertThat(e).hasMessage("could not insert: [" + EXCEPTION_MESSAGE_QUOTA_FY_BILLED + "]");
        } catch (Exception e) {
            fail();
        }
    }


    @Test
    public void testQuotaFYBilledMapping() throws Exception {

        QuotaFYBilled transaction = createQuotaFYBilled();

        Assert.assertNull(transaction.getId());

        dao.save(transaction);

        Assert.assertNotNull(transaction.getId());

        flushObject(transaction);

        QuotaFYBilled transactionDb = (QuotaFYBilled) getSession().load(QuotaFYBilled.class, transaction.getId());

        Assert.assertEquals(transaction.getId(), transactionDb.getId());
        Assert.assertEquals(transaction.getEntryValue(), transactionDb.getEntryValue());
        Assert.assertEquals(transaction.getQuota().getId(), transactionDb.getQuota().getId());
        Assert.assertEquals(transaction.getSaleOrder(), transactionDb.getSaleOrder());
        Assert.assertEquals(this.getGregorianCalendarDate(transaction.getTransactionDate(), Calendar.DAY_OF_MONTH), this.getGregorianCalendarDate(transactionDb.getTransactionDate(), Calendar.DAY_OF_MONTH));
        Assert.assertEquals(this.getGregorianCalendarDate(transaction.getTransactionDate(), Calendar.MONTH), this.getGregorianCalendarDate(transactionDb.getTransactionDate(), Calendar.MONTH));
        Assert.assertEquals(this.getGregorianCalendarDate(transaction.getTransactionDate(), Calendar.YEAR), this.getGregorianCalendarDate(transactionDb.getTransactionDate(), Calendar.YEAR));
        Assert.assertEquals(transaction.getTransactionType(), transactionDb.getTransactionType());

      //  Assert.assertEquals(transaction.getWarehouse(), transactionDb.getWarehouse());
        Assert.assertEquals(transaction.getLoginUser(), transactionDb.getLoginUser());
        Assert.assertEquals(transaction.getInvoiceNumber(), transactionDb.getInvoiceNumber());

    }

    @Test
    public void testQuotaFYBilledSelectById() throws Exception {

        quota = (QuotaFY) getSession().load(QuotaFY.class, 990000004L);
        Hibernate.initialize(quota);

        QuotaFYBilled transaction = createQuotaFYBilled();
        transaction.setQuota(quota);

        Assert.assertNull(transaction.getId());

        dao.save(transaction);

        Assert.assertNotNull(transaction.getId());

        flushObject(transaction);

        List<QuotaFYTransaction> transactionList = dao.selectByQuotaFYId(quota.getId());

        Assert.assertEquals(1,transactionList.size());
        QuotaFYTransaction savedTransaction = transactionList.get(0);
        Assert.assertEquals( QuotaFYBilled.class, savedTransaction.getClass());

    }

    private QuotaFYPaid createQuotaFYPaid() {

        QuotaFYPaid transaction = new QuotaFYPaid();
        transaction.setQuota(quota);
        transaction.setLoginUser("USER");
        transaction.setEntryValue(BigDecimal.valueOf(100L));
        transaction.setSaleOrder(1L);
        transaction.setTransactionDate(new Date());
        transaction.setTransactionType("Paid");
        transaction.setInvoiceNumber("9816A00000001");

        return transaction;

    }

    private QuotaFYCreditNote createQuotaFYCreditNote() throws Exception {

        Warehouse warehouse = warehouseDAO.getById(900000001L);

        QuotaFYCreditNote transaction = new QuotaFYCreditNote();
        transaction.setQuota(quota);
        transaction.setLoginUser("USER");
        transaction.setEntryValue(BigDecimal.valueOf(100L));
        transaction.setSaleOrder(1L);
        transaction.setTransactionDate(new Date());
        transaction.setTransactionType("Paid");
        transaction.setCreditNoteNumber("321L");
        transaction.setWarehouse(warehouse);
        transaction.setLoginUser("GERMOS");
        transaction.setReferenceInvoiceNumber("123L");

        return transaction;

    }

    private QuotaFYBilled createQuotaFYBilled() throws Exception {

        Warehouse warehouse = warehouseDAO.getById(900000001L);

        QuotaFYBilled transaction = new QuotaFYBilled();
        transaction.setQuota(quota);
        transaction.setLoginUser("USER");
        transaction.setEntryValue(BigDecimal.valueOf(100L));
        transaction.setSaleOrder(1L);
        transaction.setTransactionDate(new Date());
        transaction.setTransactionType("Paid");
        transaction.setInvoiceNumber("321L");
        transaction.setWarehouse(warehouse);
        transaction.setLoginUser("GERMOS");

        return transaction;

    }

}