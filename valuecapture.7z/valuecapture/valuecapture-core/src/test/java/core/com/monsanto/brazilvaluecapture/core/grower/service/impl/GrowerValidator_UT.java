package com.monsanto.brazilvaluecapture.core.grower.service.impl;

import com.monsanto.brazilvaluecapture.core.base.model.bean.*;
import com.monsanto.brazilvaluecapture.core.base.service.RegionService;
import com.monsanto.brazilvaluecapture.core.foundation.util.ConstraintViolation;
import com.monsanto.brazilvaluecapture.core.grower.model.bean.Grower;
import com.monsanto.brazilvaluecapture.core.regionalization.CountriesHolder;
import com.monsanto.brazilvaluecapture.core.regionalization.VCCountry;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

import static org.fest.reflect.core.Reflection.field;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.when;
import static org.fest.assertions.Assertions.assertThat;

/**
 * User: HGFIOR
 * Date: 13/03/14
 * Time: 09:44
 */
public class GrowerValidator_UT {

    private GrowerValidator growerValidator;
    private Grower grower;
    private Grower noBillingDataGrower;
    private Grower noBusinessDateGrower;
    private Grower noContactInfoGrower;
    @Mock
    private RegionService regionService;
    @Mock
    private CountriesHolder countriesHolder;

    @Before
    public void setUp() throws Exception {
        MockitoAnnotations.initMocks(this);

        growerValidator = new GrowerValidator();
        BillingAddress billingAddress = new BillingAddress();
        Country country = new Country();
        State state = new State();
        state.setDescription("Buenos Aires");
        state.setCountry(country);
        state.setCode("BA");
        City city = new City();
        city.setDescription("Springfield");
        city.setState(state);
        state.setCities(new HashSet<City>());
        state.getCities().add(city);
        country.setCode("AR");
        country.setDescription("Argentina");
        country.setStates(new HashSet<State>());
        country.getStates().add(state);

        billingAddress.setCountry(country);
        billingAddress.setState(state);
        billingAddress.setCity(city);
        billingAddress.setNumber("742");
        billingAddress.setStreet("Evergreen Terrance");
        billingAddress.setNumberForLAS("742");
        billingAddress.setTelephoneForLAS("5555-5555");
        billingAddress.setZipCodeForLAS("90210");

        BusinessAddress businessAddress = new BusinessAddress();
        businessAddress.setCountry(country);
        businessAddress.setState(state);
        businessAddress.setCity(city);
        businessAddress.setNumber("742");
        businessAddress.setStreet("Evergreen Terrance");
        businessAddress.setNumber("742");
        businessAddress.setTelephone("5555-5555");
        businessAddress.setZipCode("90210");

        UserContactInfo userContactInfo = new UserContactInfo();
        UserContactAddress userContactAddress = new UserContactAddress();
        userContactAddress.setCountry(country);
        userContactAddress.setState(state);
        userContactAddress.setCity(city);
        userContactAddress.setNumber("742");
        userContactAddress.setStreet("Evergreen Terrance");
        userContactAddress.setNumber("742");
        userContactAddress.setTelephone("5555-5555");
        userContactAddress.setZipCode("90210");
        userContactInfo.setDocument("11111111");
        userContactInfo.setEmail("somerandom@mail.com");
        userContactInfo.setName("John Grower's Contact");
        userContactInfo.setUserContactAddress(userContactAddress);

        DocumentType documentType = new DocumentType();
        documentType.setCountry(country);
        documentType.setDescription("CUIT");
        Document document = new Document(documentType,"12345678");

        grower = new Grower();
        grower.setBillingAddress(billingAddress);
        grower.setBusinessAddress(businessAddress);
        grower.setUserContactInfo(userContactInfo);
        grower.setName("John Grower");
        grower.setEmail("john@grower.com");
        grower.setDocument(document);


        List<DocumentType> documentTypeList = new ArrayList<DocumentType>();
        documentTypeList.add(documentType);

        when(regionService.selectByDescription(anyString())).thenReturn(country);
        when(regionService.selectAllByCountry(country)).thenReturn(documentTypeList);
        field("regionService").ofType(RegionService.class).in(growerValidator).set(regionService);


        when(countriesHolder.getCountry()).thenReturn(VCCountry.ARGENTINA);
        field("countriesHolder").ofType(CountriesHolder.class).in(growerValidator).set(countriesHolder);
    }

    @Test
    public void validate_grower_when_all_the_fields_are_filled_should_return_no_violations (){
        List<ConstraintViolation> constraintViolations = growerValidator.validateGrowerLASRequiredFields(grower);
        assertThat(constraintViolations).isEmpty();
    }

    @Test
    public void validate_grower_when_billing_address_fields_are_empty_should_return_5_violations (){
        grower.getBillingAddress().setNumber(null);
        grower.getBillingAddress().setState(null);
        grower.getBillingAddress().setStreet("");
        grower.getBillingAddress().setTelephone("");
        grower.getBillingAddress().setZipCode(null);

        List<ConstraintViolation> constraintViolations = growerValidator.validateGrowerLASRequiredFields(grower);
        assertThat(constraintViolations).isNotEmpty();
        assertThat(constraintViolations.size()).isEqualTo(5);
        assertThat(constraintViolations).onProperty("field").contains("import.grower.billingdata.address.number");
        assertThat(constraintViolations).onProperty("message").contains("State is required.");
        assertThat(constraintViolations).onProperty("field").contains("import.grower.billingdata.address");
        assertThat(constraintViolations).onProperty("field").contains("import.grower.billingdata.phonenumber");
        assertThat(constraintViolations).onProperty("field").contains("import.grower.billingdata.zipcode");
    }

    @Test
    public void validate_grower_when_contact_info_fields_are_empty_should_return_8_violation (){
        grower.getUserContactInfo().getUserContactAddress().setNumber(null);
        grower.getUserContactInfo().getUserContactAddress().setState(null);
        grower.getUserContactInfo().getUserContactAddress().setStreet("");
        grower.getUserContactInfo().getUserContactAddress().setTelephone("");
        grower.getUserContactInfo().getUserContactAddress().setZipCode(null);
        grower.getUserContactInfo().setEmail("");
        grower.getUserContactInfo().setDocument("");

        List<ConstraintViolation> constraintViolations = growerValidator.validateGrowerLASRequiredFields(grower);
        assertThat(constraintViolations).isNotEmpty();
        assertThat(constraintViolations.size()).isEqualTo(8);
        assertThat(constraintViolations).onProperty("field").contains("import.grower.contact.info.address.number");
        assertThat(constraintViolations).onProperty("field").contains("import.grower.contact.info.state");
        assertThat(constraintViolations).onProperty("field").contains("import.grower.contact.info.address");
        assertThat(constraintViolations).onProperty("field").contains("import.grower.contact.info.phonenumber");
        assertThat(constraintViolations).onProperty("field").contains("import.grower.contact.info.zipcode");
        assertThat(constraintViolations).onProperty("field").contains("import.grower.contact.info.email");
        assertThat(constraintViolations).onProperty("message").contains("Invalid E-mail Format.");
        assertThat(constraintViolations).onProperty("field").contains("import.grower.contact.info.document");

    }


    @Test
    public void validate_grower_when_all_the_fields_are_filled_should_return_no_violations_with_no_user_contact_validation(){
        grower.getBillingAddress().setNeighborhood("Chelsea");
        List<ConstraintViolation> constraintViolations = growerValidator.validateConstraint(grower);
        assertThat(constraintViolations).isEmpty();
    }

    @Test
    public void validate_grower_when_grower_is_null_should_return_1_violation(){
        List<ConstraintViolation> constraintViolations = growerValidator.validateConstraint(null);
        assertThat(constraintViolations).isNotEmpty();
        assertThat(constraintViolations).onProperty("field").contains("sale-record.invoiceDate.label");
        assertThat(constraintViolations).onProperty("message").contains("Grower is required.");
    }

    @Test
    public void validate_grower_change_3_fields_should_return_3_violation(){
        Grower growerChanged = new Grower();
        DocumentType documentType = new DocumentType();
        documentType.setDescription("DESCRIPTION_HAS_CHANGED");
        Document document = new Document(documentType,"22222222");
        Country country = new Country();
        country.setDescription("OTHER_COUNTRY");
        growerChanged.setDocument(document);
        growerChanged.setBillingAddress(new BillingAddress());
        growerChanged.getBillingAddress().setCountry(country);
        List<ConstraintViolation> constraintViolations = growerValidator.verifyConstraintGrowerFieldsNotChange(grower,growerChanged);
        assertThat(constraintViolations).isNotEmpty();
        assertThat(constraintViolations.size()).isEqualTo(3);
        assertThat(constraintViolations).onProperty("field").contains("label.grower.number.document");
        assertThat(constraintViolations).onProperty("field").contains("label.grower.document");
        assertThat(constraintViolations).onProperty("field").contains("import.grower.billingdata.country");
    }

}
