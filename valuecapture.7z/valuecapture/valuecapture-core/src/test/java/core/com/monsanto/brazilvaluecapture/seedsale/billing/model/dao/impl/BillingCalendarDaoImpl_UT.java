package com.monsanto.brazilvaluecapture.seedsale.billing.model.dao.impl;

import com.google.common.collect.Lists;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Company;
import com.monsanto.brazilvaluecapture.core.revenue.model.bean.ChargeGroup;
import com.monsanto.brazilvaluecapture.seedsale.billing.model.bean.BillingCalendar;
import com.monsanto.brazilvaluecapture.seedsale.billing.model.bean.BillingCalendarLimit;
import com.monsanto.brazilvaluecapture.seedsale.template.model.bean.SaleTemplate;
import junit.framework.Assert;
import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.hibernate.classic.Session;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;

import static org.junit.Assert.assertSame;
import static org.mockito.Matchers.*;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/**
 * Created by IntelliJ IDEA.
 * User: CGLLLO
 * Date: 19/09/13
 * Time: 10:50
 */
public class BillingCalendarDaoImpl_UT {

    @Mock
    private SessionFactory sessionFactory;
    @Mock
    private Session session;
    @Mock
    private Query query;
    @Mock
    private Company company;

    private BillingCalendarDaoImpl billingCalendarDao;

    @Before
    public void setUp() throws Exception {
        MockitoAnnotations.initMocks(this);
        billingCalendarDao = new BillingCalendarDaoImpl(sessionFactory);
        when(sessionFactory.getCurrentSession()).thenReturn(session);
        when(session.createQuery(anyString())).thenReturn(query);
        when(query.setParameter(anyString(), anyObject())).thenReturn(query);
    }

    @Test
    public void given_date_when_getBillingCalendarsByDate_should_return_billingCalendar() throws Exception {
        // @Given
        Date date = new Date();

        List<BillingCalendar> expected = new ArrayList<BillingCalendar>();
        when(query.list()).thenReturn(expected);

        // @When
        Object result = billingCalendarDao.getBillingCalendarsByDateAndCompany(date, company);

        // @Should
        assertSame(expected, result);
    }

    @Test
    public void given_SaleTemplate_When_getBillingCalendarBySaleTempleteAndHarvest_ShouldReturnBillingCalendar(){
        //@Given SaleTemplate
        SaleTemplate saleTemplate = new SaleTemplate();


        BillingCalendar expectedResult = new BillingCalendar();
        when(query.list()).thenReturn(Lists.newArrayList(expectedResult));

        //@When
        BillingCalendar result = billingCalendarDao.getBillingCalendarBySaleTemplate(saleTemplate);

        //@Should
        assertSame(expectedResult, result);
    }

    @Test
    public void given_limits_when_deleteBillingCalendarLimits_should_execute_query_delete() {
        // @Given
        List<BillingCalendarLimit> limits = new LinkedList<BillingCalendarLimit>();
        // @When
        billingCalendarDao.deleteBillingCalendarLimits(limits);
        // @Should
        verify(query).setParameterList(anyString(), same(limits));
        verify(query).executeUpdate();
    }
    @Test
    public void testFindBillingCalendarByChargeGroupReturnBillingCalendar(){

        //@Given SaleTemplate
        ChargeGroup chargeGroup = new ChargeGroup();

        BillingCalendar expectedResult = new BillingCalendar();

        when(query.list()).thenReturn(Lists.newArrayList(expectedResult));

        //@When
        List<BillingCalendar> result = billingCalendarDao.getBillingCalendarByChargeGroup(chargeGroup);

        //@Should
        Assert.assertTrue(result.contains(expectedResult));

    }
}
