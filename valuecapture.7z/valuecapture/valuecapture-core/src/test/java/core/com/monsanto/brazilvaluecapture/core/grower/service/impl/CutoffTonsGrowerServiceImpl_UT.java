package com.monsanto.brazilvaluecapture.core.grower.service.impl;

import static org.fest.reflect.core.Reflection.field;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;

import com.monsanto.brazilvaluecapture.core.base.model.bean.Country;
import com.monsanto.brazilvaluecapture.core.grower.model.bean.Grower;
import com.monsanto.brazilvaluecapture.seedsale.cutoffTons.model.dao.CutoffTonsDAO;
import com.monsanto.brazilvaluecapture.seedsale.cutoffTons.service.impl.CutoffTonsServiceImpl;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.CutOffTons;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.CutOffTonsGrower;
import com.monsanto.brazilvaluecapture.seedsale.sale.model.bean.CutOffTonsGrower.GrowerCutoffType;
import com.monsanto.brazilvaluecapture.seedsale.template.model.bean.SaleTemplate;

public class CutoffTonsGrowerServiceImpl_UT {

	private CutoffTonsDAO cutoffDAO;
	
	
	private CutoffTonsServiceImpl cutoffTonsGrowerServiceImpl;
	
	@Before
	public void setUp() {
		cutoffTonsGrowerServiceImpl = new CutoffTonsServiceImpl();
		cutoffDAO = mock(CutoffTonsDAO.class);
		field("cutoffTonsDAO").ofType(CutoffTonsDAO.class).in(cutoffTonsGrowerServiceImpl).set(cutoffDAO);
	}

	@Test
	public void test_save() {
		List<CutOffTons> listCutoffTonsGrower = new ArrayList<CutOffTons>();
		CutOffTonsGrower cutoffTonsGrower = new CutOffTonsGrower();
		listCutoffTonsGrower.add(cutoffTonsGrower);
		doNothing().when(cutoffDAO).save(cutoffTonsGrower);
		cutoffTonsGrowerServiceImpl.save(listCutoffTonsGrower);
		verify(cutoffDAO,times(1)).save(any(CutOffTonsGrower.class));
	}
	
	@Test
	public void test_getConsumedTonsByGrowerAndSaleTemplate(){
		SaleTemplate saleTemplate = mock(SaleTemplate.class);
		Grower grower = mock(Grower.class);
		cutoffTonsGrowerServiceImpl.getConsumedTonsByGrowerAndSaleTemplate(saleTemplate, grower);
		verify(cutoffDAO,times(1)).getConsumedTonsByGrowerAndSaleTemplate(saleTemplate, grower);
	}
	
	@Test
	public void test_getGrowerPaidTonsLimitDTO(){
		SaleTemplate saleTemplate = mock(SaleTemplate.class);
		Grower grower = mock(Grower.class);
		Country country = new Country("AR", "AR");
		cutoffTonsGrowerServiceImpl.getCutoffTonsGrower(saleTemplate, grower,country,GrowerCutoffType.All);
		verify(cutoffDAO,times(1)).getCutoffTonsGrower(saleTemplate, grower,country,GrowerCutoffType.All);
	}

}
