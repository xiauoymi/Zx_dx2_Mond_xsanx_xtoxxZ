package com.monsanto.brazilvaluecapture.seedsale.cashAdvance.report;

import com.monsanto.brazilvaluecapture.core.base.model.bean.Company;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Crop;
import com.monsanto.brazilvaluecapture.core.base.model.bean.Document;
import com.monsanto.brazilvaluecapture.core.base.model.bean.OperationalYear;
import com.monsanto.brazilvaluecapture.core.commercialhierarchy.model.bean.ItsDistrict;
import com.monsanto.brazilvaluecapture.core.commercialhierarchy.model.bean.ItsRegion;
import com.monsanto.brazilvaluecapture.core.commercialhierarchy.model.bean.ItsUnity;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Customer;
import com.monsanto.brazilvaluecapture.seedsale.cashAdvance.model.bean.CashAdvanceTransaction;
import com.monsanto.brazilvaluecapture.seedsale.cashAdvance.model.dto.CashAdvanceReportResponseDTO;
import com.monsanto.brazilvaluecapture.seedsale.harvest.model.bean.Harvest;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class CashAdvanceBalanceReportAssembler_UT {

    CashAdvanceReportAssembler assembler;

    private final static int SIZE = 19;

    @Mock
    ItsDistrict itsDistrict;
    @Mock
    ItsUnity itsUnity;
    @Mock
    ItsRegion itsRegion;

    @Before
    public void setUp() throws Exception {
        MockitoAnnotations.initMocks(this);

        assembler = new CashAdvanceBalanceReportAssembler();

        when(itsDistrict.getItsUnity()).thenReturn(itsUnity);
        when(itsDistrict.getItsRegion()).thenReturn(itsRegion);
        when(itsDistrict.getDistrictSapDesc()).thenReturn("Sap");
    }

    @Test
    public void testCreateSingleRow_WhenNothingIsNull(){
        //@Given
        CashAdvanceReportResponseDTO cashAdvanceReportResponseDTO = mock(CashAdvanceReportResponseDTO.class);
        CashAdvanceTransaction cashAdvanceTransaction = mock(CashAdvanceTransaction.class);
            when(cashAdvanceReportResponseDTO.getCashAdvanceTransaction()).thenReturn(cashAdvanceTransaction);
            OperationalYear operationalYear = mock(OperationalYear.class);
            when(cashAdvanceTransaction.getOperationalYear()).thenReturn(operationalYear);
            when(operationalYear.getYear()).thenReturn("Year");

        Harvest harvest = mock(Harvest.class);
        when(cashAdvanceReportResponseDTO.getHarvest()).thenReturn(harvest);
            when(harvest.getCrop()).thenReturn(new Crop());
            when(harvest.getCompany()).thenReturn(new Company());

        Customer customer = mock(Customer.class);
        when(cashAdvanceReportResponseDTO.getCustomer()).thenReturn(customer);

            Document document  = new Document();
            document.setValue("Document");
            when(customer.getDocument()).thenReturn(document);
            when(customer.getDistrictByCompanyCropType(any(Company.class), any(Crop.class), any(String.class))).thenReturn(itsDistrict);


        //@When
        Object[] result = assembler.createSingleRow(cashAdvanceReportResponseDTO);

        //@Should
        assertTrue(SIZE == result.length);
    }

    @Test
    public void testCreateSingleRow_WhenDistrictIsNull(){
        //@Given
        CashAdvanceReportResponseDTO cashAdvanceReportResponseDTO = mock(CashAdvanceReportResponseDTO.class);
        CashAdvanceTransaction cashAdvanceTransaction = mock(CashAdvanceTransaction.class);
        when(cashAdvanceReportResponseDTO.getCashAdvanceTransaction()).thenReturn(cashAdvanceTransaction);
        OperationalYear operationalYear = mock(OperationalYear.class);
        when(cashAdvanceTransaction.getOperationalYear()).thenReturn(operationalYear);
        when(operationalYear.getYear()).thenReturn("Year");

        Harvest harvest = mock(Harvest.class);
        when(cashAdvanceReportResponseDTO.getHarvest()).thenReturn(harvest);
        when(harvest.getCrop()).thenReturn(new Crop());
        when(harvest.getCompany()).thenReturn(new Company());

        Customer customer = mock(Customer.class);
        when(cashAdvanceReportResponseDTO.getCustomer()).thenReturn(customer);

        Document document  = new Document();
        document.setValue("Document");
        when(customer.getDocument()).thenReturn(document);
        when(customer.getDistrictByCompanyCropType(any(Company.class), any(Crop.class), any(String.class))).thenReturn(null);


        //@When
        Object[] result = assembler.createSingleRow(cashAdvanceReportResponseDTO);

        //@Should
        assertTrue(SIZE == result.length);
    }

    @Test
    public void testCreateSingleRow_WhenCustomerIsNull(){
        //@Given
        CashAdvanceReportResponseDTO cashAdvanceReportResponseDTO = mock(CashAdvanceReportResponseDTO.class);
        CashAdvanceTransaction cashAdvanceTransaction = mock(CashAdvanceTransaction.class);
        when(cashAdvanceReportResponseDTO.getCashAdvanceTransaction()).thenReturn(cashAdvanceTransaction);
        OperationalYear operationalYear = mock(OperationalYear.class);
        when(cashAdvanceTransaction.getOperationalYear()).thenReturn(operationalYear);
        when(operationalYear.getYear()).thenReturn("Year");

        Harvest harvest = mock(Harvest.class);
        when(cashAdvanceReportResponseDTO.getHarvest()).thenReturn(harvest);
        when(harvest.getCrop()).thenReturn(new Crop());
        when(harvest.getCompany()).thenReturn(new Company());

        when(cashAdvanceReportResponseDTO.getCustomer()).thenReturn(null);


        //@When
        Object[] result = assembler.createSingleRow(cashAdvanceReportResponseDTO);

        //@Should
        assertTrue(SIZE == result.length);
    }

    @Test
    public void testGenerateHeader(){
        //@Given

        //@When
        Object[] result = assembler.generateHeader();

        //@Should
        assertTrue(SIZE == result.length);
    }

}