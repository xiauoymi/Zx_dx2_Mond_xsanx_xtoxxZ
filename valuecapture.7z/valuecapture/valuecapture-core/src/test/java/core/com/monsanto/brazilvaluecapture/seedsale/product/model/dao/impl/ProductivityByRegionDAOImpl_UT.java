package com.monsanto.brazilvaluecapture.seedsale.product.model.dao.impl;

import com.monsanto.brazilvaluecapture.seedsale.harvest.model.bean.Plantability;
import com.monsanto.brazilvaluecapture.seedsale.product.model.bean.ProductivityByRegion;
import com.monsanto.brazilvaluecapture.seedsale.product.model.bean.Region;
import com.monsanto.brazilvaluecapture.seedsale.product.service.ProductivityAlreadyProductInProductvityValues;
import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.hibernate.classic.Session;
import org.hibernate.criterion.Criterion;
import org.hibernate.exception.ConstraintViolationException;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.*;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyObject;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.*;
import org.apache.commons.logging.Log;

/**
 * Created by IntelliJ IDEA.
 * User: JAKAGI
 * Date: 07/10/13
 * Time: 12:01
 * To change this template use File | Settings | File Templates.
 */
public class ProductivityByRegionDAOImpl_UT {
    @Mock
    private SessionFactory sessionFactory;
    @Mock
    private Session session;
    @Mock
    private Query query;
    @Mock
    private Criteria criteria;

    private Log logger;

    private ProductivityByRegionDAOImpl productivityByRegionDAOImpl;

    @Before
    public void setUp() throws Exception {
        MockitoAnnotations.initMocks(this);
        productivityByRegionDAOImpl = new ProductivityByRegionDAOImpl(sessionFactory);
        when(sessionFactory.getCurrentSession()).thenReturn(session);
        when(session.createQuery(anyString())).thenReturn(query);
        when(query.setParameter(anyString(), anyObject())).thenReturn(query);
        when(session.createCriteria(any(Class.class), anyString())).thenReturn(criteria);
        when(session.createCriteria(ProductivityByRegion.class)).thenReturn(criteria);
    }

    @Test
    public void when_findIsInUseBySaleTemplate() throws Exception {
        List<ProductivityByRegion> expected = new ArrayList<ProductivityByRegion>();
        expected.add(mock(ProductivityByRegion.class));
        when(criteria.list()).thenReturn(expected);

        boolean result = productivityByRegionDAOImpl.findIsInUseBySaleTemplate(mock(ProductivityByRegion.class));

        assertSame(true, result);
    }
    @Test
    public void when_delete() throws Exception {
        productivityByRegionDAOImpl.delete(mock(ProductivityByRegion.class));
    }

    @Test
    public void when_saveOK() throws Exception {
        productivityByRegionDAOImpl.save(mock(ProductivityByRegion.class));
    }

    @Test
    public void when_saveFailGeneralConstraint() throws Exception {
        boolean fail=false;

        try{

            SQLException sQLException = mock(SQLException.class);
            ConstraintViolationException constraintViolationException = mock( ConstraintViolationException.class);
            when(constraintViolationException.getSQLException()).thenReturn(sQLException);
            when(constraintViolationException.getSQLException().getLocalizedMessage()).thenReturn("Fake Constraint");

            doThrow(constraintViolationException).when(session).flush();

            productivityByRegionDAOImpl.save(mock(ProductivityByRegion.class));
            fail=true;
        }catch (Exception e){
            if (!(e instanceof ConstraintViolationException))
            {
                fail=true;
            }

        }
        assertFalse(fail);

    }


    @Test
    public void when_saveFailSpecificConstraint() throws Exception {

        boolean fail=false;

        try{

            SQLException sQLException = mock(SQLException.class);
            ConstraintViolationException constraintViolationException = mock( ConstraintViolationException.class);
            when(constraintViolationException.getSQLException()).thenReturn(sQLException);
            when(constraintViolationException.getSQLException().getLocalizedMessage()).thenReturn("UQ_PRODUCTIVITY_BY_REG_TO_PRO");

            doThrow(constraintViolationException).when(session).flush();

            productivityByRegionDAOImpl.save(mock(ProductivityByRegion.class));
            fail=true;
        }catch (Exception e){
            if (!((e instanceof ProductivityAlreadyProductInProductvityValues.ProductivityByRegionAlreadyProductInProductvityValues)
            && (e.getMessage().contains("The value of the product is already in productivityByRegionValues."))))
            {
                fail=true;
            }

        }
        assertFalse(fail);
    }

    @Test
    public void test_getFromRegionAndPlantability(){
        when(criteria.add(any(Criterion.class))).thenReturn(criteria);
        //@Given
        Region region = new Region();
        Plantability plantability = new Plantability();

        //@When
        ProductivityByRegion fromRegionAndPlantability = productivityByRegionDAOImpl.getFromRegionAndPlantability(region, plantability);

        //@should
        verify(session).createCriteria(ProductivityByRegion.class);
        verify(criteria, times(2)).add(any(Criterion.class));
        verify(criteria).uniqueResult();
}
}



