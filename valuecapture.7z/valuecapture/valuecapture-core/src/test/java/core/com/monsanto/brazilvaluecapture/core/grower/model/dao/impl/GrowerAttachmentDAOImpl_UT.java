package com.monsanto.brazilvaluecapture.core.grower.model.dao.impl;

import com.monsanto.brazilvaluecapture.core.grower.model.bean.GrowerAttachment;
import org.hibernate.Criteria;
import org.hibernate.SessionFactory;
import org.hibernate.classic.Session;
import org.hibernate.criterion.Criterion;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class GrowerAttachmentDAOImpl_UT {

    private static final Long ID = 1L;

    @Mock private SessionFactory sessionFactory;
    @InjectMocks private GrowerAttachmentDAOImpl dao;
    @Mock private Session session;
    @Mock private Criteria criteria;
    @Mock private GrowerAttachment growerAttachment;

    @Before
    public void setUp() {
        when(sessionFactory.getCurrentSession()).thenReturn(session);
        when(session.createCriteria(any(Class.class), anyString())).thenReturn(criteria);
        when(criteria.createCriteria(anyString(), anyString())).thenReturn(criteria);
        when(criteria.add(any(Criterion.class))).thenReturn(criteria);
    }

    @Test
    public void findByShouldSucceed() {
        List<GrowerAttachment> attachmentList = new ArrayList<GrowerAttachment>();
        attachmentList.add(growerAttachment);
        when(criteria.list()).thenReturn(attachmentList);

        List<GrowerAttachment> result = dao.findBy(ID);

        assertEquals(1, result.size());
        assertEquals(growerAttachment, result.get(0));
        verify(session).createCriteria(eq(GrowerAttachment.class), anyString());
        verify(criteria).add(any(Criterion.class));
    }

    @Test
    public void saveShouldSucceed() {
        dao.save(growerAttachment);

        verify(session).saveOrUpdate(growerAttachment);
    }

    @Test
    public void deleteShouldSucceed() {
        dao.delete(growerAttachment);

        verify(session).delete(growerAttachment);
    }

}
