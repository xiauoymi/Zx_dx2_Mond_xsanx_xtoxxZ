package com.monsanto.brazilvaluecapture.core.debt.template;

import com.google.common.base.Strings;
import com.monsanto.brazilvaluecapture.core.debt.bean.DebtFooterDTO;
import com.monsanto.brazilvaluecapture.core.debt.bean.DebtHeaderDTO;
import com.monsanto.brazilvaluecapture.core.debt.bean.DebtItemDTO;
import com.monsanto.brazilvaluecapture.core.debt.dao.DebtDAO;
import com.monsanto.brazilvaluecapture.core.foundation.model.dao.SystemParameterDAO;
import com.monsanto.brazilvaluecapture.core.foundation.test.AbstractServiceIntegrationTests;
import com.monsanto.brazilvaluecapture.core.foundation.test.dbunit.DbUnitHelper;
import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.StringTokenizer;

import static org.fest.assertions.Assertions.assertThat;

public class MacroTemplate_AT extends AbstractServiceIntegrationTests {

    @Autowired
    SystemParameterDAO systemParameterDAO;

    @Autowired
    private DebtDAO dao;

    private static final String DATE_PATTERN = "yyyyMMdd";
    private static final String MACRO_GROUP = "I_MACRO_DEBT_NOTIFICATION";
    private static final String HEADER_TYPE = "H_TYPE";
    private static final String FOOTER_TYPE = "T_TYPE";
    private static final String MACRO_HEADER_IDENTIFICATION = "H_INDENTIFICATION";
    private static final String MACRO_SENT_FILE_NUMBER_NAME = "H_NRO_ARCHIVO_ENVIADO";
    private static final Long ARGENTINA_ID = new Long(33261);

    private String today;

    @Before
    public void setUp() throws Exception {
        String dataSetLocations = "classpath:data/core/debt-dataset.xml";
        DbUnitHelper.setup(dataSetLocations);

        SimpleDateFormat dateFormat = new SimpleDateFormat(DATE_PATTERN);
        this.today = dateFormat.format(new Date());
    }

    @Test
    public void testFormatHeader_WhenDtoIsFormattedThenReturnStringWithKnowFormat(){

        DebtTemplate template = new MacroTemplate(new Date());

        DebtHeaderDTO dto = DebtHeaderDTO.getMacroInstance(this.systemParameterDAO.selectParameterValueByGroupAndNameAndCountryCode(MACRO_GROUP, HEADER_TYPE, "AR"),
                                    this.systemParameterDAO.selectParameterValueByGroupAndNameAndCountryCode(MACRO_GROUP, MACRO_HEADER_IDENTIFICATION, "AR"),
                                    this.systemParameterDAO.selectParameterValueByGroupAndNameAndCountryCode(MACRO_GROUP, MACRO_SENT_FILE_NUMBER_NAME, "AR"));

        SimpleDateFormat dateFormat = new SimpleDateFormat(DATE_PATTERN);

        String stringDto = template.formatHeader(dto);

        assertThat(stringDto.substring(0, 1)).isEqualTo("H");
        assertThat(stringDto.substring(1, 11)).isEqualTo("XXX       ");
        assertThat(stringDto.substring(11, 19)).isEqualTo(this.today);
        assertThat(stringDto.substring(25, 29)).isEqualTo("0000");
        assertThat(stringDto.substring(29, 33)).isEqualTo(Strings.repeat("0", 4));
        assertThat(stringDto.substring(33, 41)).isEqualTo(Strings.repeat("0", 8));
    }

    @Test
    public void testFormatItems_WhenDtoListIsFormattedThenReturnStringWithKnowFormat(){

        List<DebtItemDTO> items = dao.getDebtItemsBy(MACRO_GROUP, ARGENTINA_ID);

        DebtTemplate template = new MacroTemplate(new Date());
        String stringDto = template.formatItems(items);

        assertThat(stringDto.substring(0, 1)).isEqualTo("D");
        assertThat(stringDto.substring(1, 5)).isEqualTo("0123");
        assertThat(stringDto.substring(5, 23)).isEqualTo("1099596           ");
        assertThat(stringDto.substring(23, 41)).isEqualTo("107173            ");
        assertThat(stringDto.substring(41, 43)).isEqualTo("80");
        assertThat(stringDto.substring(43, 56)).isEqualTo("30641405554  ");
        assertThat(stringDto.substring(56, 64)).isEqualTo(this.today);
        assertThat(stringDto.substring(64, 72)).isEqualTo(this.today);
        assertThat(stringDto.substring(72, 87)).isEqualTo("000000000125452");
        assertThat(stringDto.substring(87, 95)).isEqualTo(this.today);
        assertThat(stringDto.substring(95, 110)).isEqualTo(Strings.repeat(" ", 15));
        assertThat(stringDto.substring(110, 118)).isEqualTo(Strings.repeat(" ", 8));
        assertThat(stringDto.substring(118, 133)).isEqualTo(Strings.repeat(" ", 15));
        assertThat(stringDto.substring(133, 141)).isEqualTo(Strings.repeat(" ", 8));
        assertThat(stringDto.substring(141, 171)).isEqualTo("AEROLINEAS ARGENTINAS         ");
        assertThat(stringDto.substring(171, 201)).isEqualTo(Strings.repeat(" ", 30));
        assertThat(stringDto.substring(201, 207)).isEqualTo(Strings.repeat(" ", 6));
        assertThat(stringDto.substring(207, 237)).isEqualTo(Strings.repeat(" ", 30));
        assertThat(stringDto.substring(237, 239)).isEqualTo("80");
        assertThat(stringDto.substring(239, 250)).isEqualTo("30503508725");
        assertThat(stringDto.substring(250, 288)).isEqualTo("DEUDA TECNOLOGIA INTACTA              ");
        assertThat(stringDto.substring(288, 326)).isEqualTo("MONSANTO ARGENTINA                    ");
        assertThat(stringDto.substring(326, 364)).isEqualTo(Strings.repeat(" ", 38));
        assertThat(stringDto.substring(364, 402)).isEqualTo(Strings.repeat(" ", 38));
        assertThat(stringDto.substring(402, 440)).isEqualTo(Strings.repeat(" ", 38));
        assertThat(stringDto.substring(440, 478)).isEqualTo(Strings.repeat(" ", 38));
        assertThat(stringDto.substring(478, 516)).isEqualTo(Strings.repeat(" ", 38));
        assertThat(stringDto.substring(516, 554)).isEqualTo(Strings.repeat(" ", 38));
        assertThat(stringDto.substring(554, 592)).isEqualTo(Strings.repeat(" ", 38));
        assertThat(stringDto.substring(592, 630)).isEqualTo(Strings.repeat(" ", 38));
    }

    @Test
    public void testFormatFooter_WhenDtoListIsFormattedThenReturnStringWithKnowFormat(){

        DebtTemplate template = new MacroTemplate(new Date());

        DebtFooterDTO dto = DebtFooterDTO.getMacroInstance(this.systemParameterDAO.selectParameterValueByGroupAndNameAndCountryCode(MACRO_GROUP, FOOTER_TYPE, "AR"),
                                    new BigDecimal(3),
                                    new BigDecimal("1254.52"));

        String stringDto = template.formatFooter(dto);

        assertThat(stringDto.substring(0, 1)).isEqualTo("T");
        assertThat(stringDto.substring(1, 6)).isEqualTo("00003");
        assertThat(stringDto.substring(6, 21)).isEqualTo("000000000125452");
    }

    @Test
    public void testPaddingNumber_WhenFiveDigitNumberGivenRetunStringLengthTenFulledWithFiveZerosToLeft() {

        MacroTemplate template = new MacroTemplate(new Date());

        assertThat(template.paddingNumber("12345", 10)).isEqualTo("0000012345");
    }

    @Test
    public void testPaddingAlphaNumeric_GivenStringWhenLengthFiveReturnStringsTenFulledWithBlanksToRigth() {
        MacroTemplate template = new MacroTemplate(new Date());

        assertThat(template.paddingAlphaNumeric("Hello", 10)).isEqualTo("Hello     ");
    }

    @Test
    public void testPaddingAlphaNumeric_GivenLongWhenLengthFiveReturnStringsTenFulledWithBlanksToRigth() {
        MacroTemplate template = new MacroTemplate(new Date());

        assertThat(template.paddingAlphaNumeric(new Long(12345), 10)).isEqualTo("12345     ");
    }

    @Test
    public void testToUnformatedString_GivenNumberStringWithDotAndTwoDecimalsReturnStringNumberNoComaEndingWithTheTwoDecimals(){

        MacroTemplate template = new MacroTemplate(new Date());

        assertThat(template.toUnformatedString("1252.54")).isEqualTo("125254");
    }

    @Test
    public void testToUnformatedString_GivenNumberStringWithDotAndOneDecimalsReturnStringNumberNoComaEndingWithTheTwoDecimals(){

        MacroTemplate template = new MacroTemplate(new Date());

        assertThat(template.toUnformatedString("1252.5")).isEqualTo("125250");
    }

    @Test
    public void testToUnformatedString_GivenIntegerNumberStringReturnStringNumberNoComaEndingWithTwoZeros(){

        MacroTemplate template = new MacroTemplate(new Date());

        assertThat(template.toUnformatedString("1252")).isEqualTo("125200");
    }
}
