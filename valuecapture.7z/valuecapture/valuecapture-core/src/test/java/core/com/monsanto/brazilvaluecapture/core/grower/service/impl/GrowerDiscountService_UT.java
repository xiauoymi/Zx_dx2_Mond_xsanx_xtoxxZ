package com.monsanto.brazilvaluecapture.core.grower.service.impl;

import com.monsanto.brazilvaluecapture.core.foundation.service.EntityNotFoundException;
import com.monsanto.brazilvaluecapture.core.grower.model.dao.GrowerDiscountDAO;
import com.monsanto.brazilvaluecapture.core.grower.service.GrowerDiscountService;
import org.mockito.Mock;
import org.junit.Before;
import org.junit.Test;
import org.mockito.MockitoAnnotations;

import static org.fest.reflect.core.Reflection.field;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

/**
 * Created by AFREI on 08/04/14.
 */
public class GrowerDiscountService_UT {

    @Mock
    private GrowerDiscountDAO growerDiscountDAO;
    private GrowerDiscountService growerDiscountService;

    @Before
    public void setUp() throws Exception {
        MockitoAnnotations.initMocks(this);
        growerDiscountService = new GrowerDiscountServiceImpl();
        field("growerDiscountDAO").ofType(GrowerDiscountDAO.class).in(growerDiscountService).set(growerDiscountDAO);
    }

    @Test
    public void test_selectByCallsGrowerDiscountDAOSelectBy() throws EntityNotFoundException {
        String documentNumber = "aDoc";
        growerDiscountService.selectBy(documentNumber);
        verify(growerDiscountDAO,times(1)).selectBy(documentNumber);
    }


}
