package com.monsanto.brazilvaluecapture.core.grower.model.bean;

import com.monsanto.brazilvaluecapture.core.account.model.bean.Account;
import com.monsanto.brazilvaluecapture.core.base.CompanyTestData;
import com.monsanto.brazilvaluecapture.core.base.model.bean.OperationalYear;
import org.junit.Test;

import static com.monsanto.brazilvaluecapture.core.base.CropTestData.SOJA_BAYER_ARGENTINA;
import static com.monsanto.brazilvaluecapture.core.base.CropTestData.SOJA_MONSANTO_ARGENTINA;
import static com.monsanto.brazilvaluecapture.core.base.TechnologyTestData.INTACTA;
import static com.monsanto.brazilvaluecapture.core.base.TechnologyTestData.INTACTA_RR2;
import static junit.framework.Assert.assertTrue;
import static org.fest.assertions.Assertions.assertThat;
import static org.junit.Assert.assertFalse;

public class AgreementTemplateType_UT {

    private AgreementTemplateType agreementTemplateType;
    private AgreementTemplateType anotherAgreementTemplateType;

    @Test
   	public void testEquals_returnsTue_whenAreTheSame() {
        AgreementTemplateType agreementTemplateType = new AgreementTemplateType();
        assertThat(agreementTemplateType.equals(agreementTemplateType)).isTrue();
    }

    @Test
   	public void testEquals_returnsFalse_whenAreDifferentType() {
        AgreementTemplateType agreementTemplateType = new AgreementTemplateType();
        assertThat(agreementTemplateType.equals(null)).isFalse();
        assertThat(agreementTemplateType.equals("string")).isFalse();
    }

    @Test
   	public void testEquals_returnsFalse_whenHaveDifferentAttributes() {
        // crop
        agreementTemplateType = new AgreementTemplateType(SOJA_MONSANTO_ARGENTINA, null, null, null);
        anotherAgreementTemplateType = new AgreementTemplateType(SOJA_BAYER_ARGENTINA, null, null, null);
        assertFalse(agreementTemplateType.equals(anotherAgreementTemplateType));

        // company
        agreementTemplateType = new AgreementTemplateType(null, CompanyTestData.MONSANTO_ARGENTINA, null, null);
        anotherAgreementTemplateType = new AgreementTemplateType(null, CompanyTestData.MONSANTO_PARAGUAY, null, null);
        assertFalse(agreementTemplateType.equals(anotherAgreementTemplateType));

        // technology
        agreementTemplateType = new AgreementTemplateType(null, null, INTACTA, null);
        anotherAgreementTemplateType = new AgreementTemplateType(null, null, INTACTA_RR2, null);
        assertFalse(agreementTemplateType.equals(anotherAgreementTemplateType));

        // operationalYear
        agreementTemplateType = new AgreementTemplateType(null, null, null, "description1");
        anotherAgreementTemplateType = new AgreementTemplateType(null, null, null, "description2");
        assertFalse(agreementTemplateType.equals(anotherAgreementTemplateType));
    }

    @Test
   	public void testEquals_returnsTue_whenHaveSameAttributes() {
        // null
        agreementTemplateType = new AgreementTemplateType();
        anotherAgreementTemplateType = new AgreementTemplateType();
        assertTrue(agreementTemplateType.equals(anotherAgreementTemplateType));

        // crop
        agreementTemplateType = new AgreementTemplateType(SOJA_MONSANTO_ARGENTINA, null, null, null);
        anotherAgreementTemplateType = new AgreementTemplateType(SOJA_MONSANTO_ARGENTINA, null, null, null);
        assertTrue(agreementTemplateType.equals(anotherAgreementTemplateType));

        // company
        agreementTemplateType = new AgreementTemplateType(null, CompanyTestData.MONSANTO_ARGENTINA, null, null);
        anotherAgreementTemplateType = new AgreementTemplateType(null, CompanyTestData.MONSANTO_ARGENTINA, null, null);
        assertTrue(agreementTemplateType.equals(anotherAgreementTemplateType));

        // technology
        agreementTemplateType = new AgreementTemplateType(null, null, INTACTA, null);
        anotherAgreementTemplateType = new AgreementTemplateType(null, null, INTACTA, null);
        assertTrue(agreementTemplateType.equals(anotherAgreementTemplateType));

        // operationalYear
        agreementTemplateType = new AgreementTemplateType(null, null, null, "description");
        anotherAgreementTemplateType = new AgreementTemplateType(null, null, null, "description");
        assertTrue(agreementTemplateType.equals(anotherAgreementTemplateType));
    }


}
