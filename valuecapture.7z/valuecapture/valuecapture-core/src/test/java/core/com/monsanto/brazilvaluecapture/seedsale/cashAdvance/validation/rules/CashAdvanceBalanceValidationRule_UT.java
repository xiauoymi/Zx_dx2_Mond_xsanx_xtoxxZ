package com.monsanto.brazilvaluecapture.seedsale.cashAdvance.validation.rules;

import com.monsanto.brazilvaluecapture.core.base.model.bean.OperationalYear;
import com.monsanto.brazilvaluecapture.core.customer.model.bean.Customer;
import com.monsanto.brazilvaluecapture.core.foundation.validation.ValidationException;
import com.monsanto.brazilvaluecapture.core.presentation.beans.ResourceBundleTestHelper;
import com.monsanto.brazilvaluecapture.seedsale.cashAdvance.model.bean.CashAdvanceBalanceByReferenceDate;
import com.monsanto.brazilvaluecapture.seedsale.cashAdvance.model.bean.CashAdvanceSourceOperationType;
import com.monsanto.brazilvaluecapture.seedsale.cashAdvance.model.bean.CashAdvanceTransaction;
import com.monsanto.brazilvaluecapture.seedsale.cashAdvance.service.CashAdvanceService;
import com.monsanto.brazilvaluecapture.seedsale.template.model.bean.DueDatePriceItem;
import org.junit.Test;

import java.math.BigDecimal;

import static org.fest.assertions.Assertions.assertThat;
import static org.fest.assertions.Fail.fail;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;


public class CashAdvanceBalanceValidationRule_UT {
    @Test
    public void testValidateThrowsValidateException_WhenCashAdvanceBalanceIsLessThanCashAdvanceTransactionAmount(){
        Customer partner = new Customer();
        DueDatePriceItem referenceDate = new DueDatePriceItem();
        BigDecimal amount = BigDecimal.ONE;
        OperationalYear operationalYear = new OperationalYear("2014");
        CashAdvanceTransaction cashAdvanceTransaction = new CashAdvanceTransaction(partner, partner, operationalYear, referenceDate, amount, CashAdvanceSourceOperationType.FORM);
        CashAdvanceBalanceByReferenceDate balanceByReferenceDate = new CashAdvanceBalanceByReferenceDate(referenceDate, BigDecimal.ZERO);
        CashAdvanceService cashAdvanceService = mock(CashAdvanceService.class);
        when(cashAdvanceService.getAvailableBalanceForReferenceDate(referenceDate, partner, partner, operationalYear)).thenReturn(balanceByReferenceDate);
        CashAdvanceBalanceValidationRule cashAdvanceBalanceValidationRule = new CashAdvanceBalanceValidationRule(cashAdvanceService);

        try {
            cashAdvanceBalanceValidationRule.validate(cashAdvanceTransaction);
            fail("Should throw validation exception");
        }catch (ValidationException e){
            assertThat(e).hasMessage("cash.advance.message.balance.not.enough");
        }
    }

    @Test
    public void testValidateThrowsValidateException_WhenNoBalanceExists(){
        Customer partner = new Customer();
        DueDatePriceItem referenceDate = new DueDatePriceItem();
        BigDecimal amount = BigDecimal.ONE;
        OperationalYear operationalYear = new OperationalYear("2014");
        CashAdvanceTransaction cashAdvanceTransaction = new CashAdvanceTransaction(partner, partner, operationalYear, referenceDate, amount, CashAdvanceSourceOperationType.FORM);
        CashAdvanceService cashAdvanceService = mock(CashAdvanceService.class);
        when(cashAdvanceService.getAvailableBalanceForReferenceDate(referenceDate, partner, partner, operationalYear)).thenReturn(null);
        CashAdvanceBalanceValidationRule cashAdvanceBalanceValidationRule = new CashAdvanceBalanceValidationRule(cashAdvanceService);

        try {
            cashAdvanceBalanceValidationRule.validate(cashAdvanceTransaction);
            fail("Should throw validation exception");
        }catch (ValidationException e){
            assertThat(e).hasMessage("cash.advance.message.balance.not.enough");
        }
    }

    @Test
    public void testValidateDoNotThrowsValidateException_WhenCashAdvanceBalanceIsGreatThanCashAdvanceTransactionAmount(){
        Customer partner = new Customer();
        DueDatePriceItem referenceDate = new DueDatePriceItem();
        BigDecimal amount = BigDecimal.ONE;
        OperationalYear operationalYear = new OperationalYear("2014");
        CashAdvanceTransaction cashAdvanceTransaction = new CashAdvanceTransaction(partner, partner, operationalYear, referenceDate, amount, CashAdvanceSourceOperationType.FORM);
        CashAdvanceService cashAdvanceService = mock(CashAdvanceService.class);
        CashAdvanceBalanceByReferenceDate balanceByReferenceDate = new CashAdvanceBalanceByReferenceDate(referenceDate, BigDecimal.TEN);
        when(cashAdvanceService.getAvailableBalanceForReferenceDate(referenceDate, partner, partner, operationalYear)).thenReturn(balanceByReferenceDate);
        CashAdvanceBalanceValidationRule cashAdvanceBalanceValidationRule = new CashAdvanceBalanceValidationRule(cashAdvanceService);

        try {
            cashAdvanceBalanceValidationRule.validate(cashAdvanceTransaction);
        }catch (ValidationException e){
            fail("Should not throw validation exception");
        }
    }

    private String[] messages = {"cash.advance.message.balance.not.enough"};

    @Test
    public void testI18mMessages_Brazil() throws Exception {
        ResourceBundleTestHelper.assertLanguageStrExistsForBrazil(messages);
    }

    @Test
    public void testI18mMessages_English() throws Exception {
        ResourceBundleTestHelper.assertLanguageStrExistsForUS(messages);
    }

}
