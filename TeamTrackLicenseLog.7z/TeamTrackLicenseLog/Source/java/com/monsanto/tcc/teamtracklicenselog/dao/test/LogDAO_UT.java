/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.teamtracklicenselog.dao.test;

import com.monsanto.tcc.teamtracklicenselog.dao.LogDAO;
import com.monsanto.tcc.teamtracklicenselog.model.NoTypeLogEntry;
import com.monsanto.wst.dbtemplate.test.mock.MockDBTemplate;
import junit.framework.TestCase;

/**
 * Filename:    $RCSfile: LogDAO_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: zznels $    	 On:	$Date: 2007-12-11 23:22:35 $
 *
 * @author zznels
 * @version $Revision: 1.2 $
 */
public class LogDAO_UT extends TestCase {

  private MockDBTemplate mockTemplate;
  private LogDAO testDAO;

  public void setUp() throws Exception{
    super.setUp();
    mockTemplate = new MockDBTemplate();
    testDAO = new LogDAO(mockTemplate);
  }

  public void testInsertLogCallsCorrectQuery() throws Exception {
    testDAO.insertLog(new NoTypeLogEntry());

    mockTemplate.wasStatementNameCalled(LogDAO.INSERT_LOG_QUERY_NAME);
  }

}