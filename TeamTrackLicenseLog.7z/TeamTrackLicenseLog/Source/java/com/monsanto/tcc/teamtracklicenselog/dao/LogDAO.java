/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.teamtracklicenselog.dao;

import com.monsanto.wst.dbtemplate.DBTemplate;
import com.monsanto.wst.dbtemplate.transaction.TransactionManager;
import com.monsanto.tcc.teamtracklicenselog.model.LogEntry;

import java.sql.SQLException;

/**
 * Filename:    $RCSfile: LogDAO.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: zznels $    	 On:	$Date: 2007-12-11 23:22:35 $
 *
 * @author zznels
 * @version $Revision: 1.2 $
 */
public class LogDAO {
  private DBTemplate template;
  public static final String INSERT_LOG_QUERY_NAME = "insertLog";

  public LogDAO(DBTemplate template) {
    this.template = template;
  }

  public LogDAO() {
    this.template = new LogDAOTemplate();
  }

  public LogDAO(TransactionManager txManager) {
    this.template = new LogDAOTemplate(txManager);
  }

  public void insertLog(LogEntry entry) throws SQLException {
    template.executeInsert(INSERT_LOG_QUERY_NAME, entry);
  }
}