package com.monsanto.tcc.teamtracklicenselog.servlet;


import com.monsanto.AbstractLogging.Logger;
import com.monsanto.Util.databasepasswordencryption.EncryptionUtils;
import com.monsanto.Util.EnvironmentHelper;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStore;
import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.dbdataservices.PersistentStoreOracleCachedType2;

import java.util.ResourceBundle;

/**
 *
 * <p>Title: TeamTrackLicenseLogPersistentStoreFactory</p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Monsanto</p>
 * @author Java Framework Code Generator 3.0
 * @version $Id: TeamTrackLicenseLogPersistentStoreFactory.java,v 1.2 2007-10-01 16:02:03 zznels Exp $
 */
public class TeamTrackLicenseLogPersistentStoreFactory
{
   public static final String DEFAULT_BUNDLE        = "com.monsanto.tcc.teamtracklicenselog.servlet.TeamTrackLicenseLog";
   public static final String PERSISTENT_STORE_NAME = "TeamTrackLicenseLog";

  /**
       * Returns a Persistent Store.
       *
       * @param cstrResourceBundleName The name of the resource bundle that points
       *                               to the correct database.
       * @return A PersistentStore object.
       * @throws WrappingException
       */
      public static PersistentStore getStore(String cstrResourceBundleName) throws WrappingException {
         Logger.traceEntry();

         ResourceBundle bundle = ResourceBundle.getBundle(cstrResourceBundleName);
         PersistentStore RetVal = getPersistentStore(bundle);

         return (PersistentStore) Logger.traceExit(RetVal);
      }


      public static PersistentStoreConnection getDefaultConnection() throws WrappingException {
         final PersistentStore store = getStore(DEFAULT_BUNDLE);
         PersistentStore.registerInstance(TeamTrackLicenseLogPersistentStoreFactory.PERSISTENT_STORE_NAME, store);

         return PersistentStore.instance(TeamTrackLicenseLogPersistentStoreFactory.PERSISTENT_STORE_NAME).connect();
      }

      private static PersistentStore getPersistentStore(ResourceBundle bundle) throws WrappingException {
         String userName     = null;
         String sequenceName = null;
         String dataSource   = null;
         String password     = null;

         String storageEnvVariable = "MONCRYPTJV";

	//Todo: fix the three strings based on your project and remove the syntax error line
	//ToDo: & fix TeamTrackLicenseLog.properties file

         String appFolderName      = "TeamTrackLicenseLog";
         String encryptedFileName  = "CipherValue.hex";
         String keyFileName        = "Keyvalue.hex";

         /*
            Example section from ResourceBundle

            dev.UserName=XXXXXXXX
            dev.DataSource=Devl
            dev.SequenceName=shared_code.SHARED_ID_SEQ
            dev.MinConnections=1
            dev.MaxConnections=3
            dev.Increment=1
         */
         try {
            userName     = bundle.getString(EnvironmentHelper.getPropertyPrefix() + "UserName");
            sequenceName = bundle.getString(EnvironmentHelper.getPropertyPrefix() + "SequenceName");
            dataSource   = bundle.getString(EnvironmentHelper.getPropertyPrefix() + "DataSource");

            password = EncryptionUtils.GetDecryptedStringFromExternalStorage(storageEnvVariable,
                                                                             appFolderName,
                                                                             encryptedFileName,
                                                                             keyFileName);
         } catch (Exception e) {
            throw new WrappingException(e);
         }

         return new PersistentStoreOracleCachedType2(userName, password, dataSource, sequenceName);
      }

  }