/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.teamtracklicenselog.controller;

import java.io.File;
import java.io.FileNotFoundException;

/**
 * Filename:    $RCSfile: main.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: zznels $    	 On:	$Date: 2007-12-18 15:49:26 $
 *
 * @author zznels
 * @version $Revision: 1.2 $
 */
public class main {
  private static final String MONCRYPTJV = "MONCRYPTJV";
  private static final String LSI_FUNCTION = "lsi.function";

  static public void main(String[] argv){
    if(argv.length!=2){
      System.out.println("Invalid Arguments. 2 Arguments Required (filename, date (mm-dd-yyyy))");
      System.exit(1);
    }

    if (System.getProperty(MONCRYPTJV) == null) {
      System.setProperty(MONCRYPTJV, System.getenv(MONCRYPTJV));
    }
    if (System.getProperty(LSI_FUNCTION) == null) {
      System.setProperty(LSI_FUNCTION, "win");
    }

    File inputFile = new File(argv[0]);
    try {
      new LogParserController().processLogFile(inputFile, argv[1]);
    } catch (FileNotFoundException e) {
      System.out.println("Invalid Filename: File Not Found");
      System.exit(1);
    } catch (IllegalArgumentException ex) {
      System.out.println("Invalid Date Format");
      System.exit(1);
    }
    System.out.println("Processing Complete");
  }
}