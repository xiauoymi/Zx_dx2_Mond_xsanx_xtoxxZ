/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.teamtracklicenselog.model;

import com.monsanto.tcc.teamtracklicenselog.dao.LogDAO;

import java.util.Date;
import java.sql.SQLException;

/**
 * Filename:    $RCSfile: LogEntry.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: zznels $    	 On:	$Date: 2007-12-14 20:05:30 $
 *
 * @author zznels
 * @version $Revision: 1.4 $
 */
public abstract class LogEntry {
  private String userID;
  private Date date;
  private String time;
  private String workstation;
  private boolean namedLicense;

  public LogEntry() {
    userID = "";
    date = new Date();
    time = "00:00:00";
    workstation = "";
    namedLicense = false;
  }

  public String getUserID() {
    return userID;
  }

  public void setUserID(String userID) {
    this.userID = userID;
  }

  public Date getDate() {
    return date;
  }

  public void setDate(Date date) {
    this.date = date;
  }

  public String getTime() {
    return time;
  }

  public void setTime(String time) {
    this.time = time;
  }

  public String getWorkstation() {
    return workstation;
  }

  public void setWorkstation(String workStation) {
    this.workstation = workStation;
  }

  public boolean isNamedLicense(){
    return namedLicense;
  }

  public String getNamedLicense() {
    return namedLicense?"Y":"N";
  }

  public void setNamedLicense(boolean namedLicense) {
    this.namedLicense = namedLicense;
  }

  public Date getDateTime() {
    long dtime = getDate().getTime();
    dtime += getTimeInms();
    return new Date(dtime);
  }

  public long getTimeInms() {
    String[] times = getTime().split(":");
    long dtime = 3600000*Integer.valueOf(times[0]);
    dtime += 60000*Integer.valueOf(times[1]);
    dtime += 1000*Integer.valueOf(times[2]);
    return dtime;
  }

  public abstract String getLogType();

  public boolean save(LogDAO DAO) {
    try{
      DAO.insertLog(this);
    } catch (SQLException ex){
      return false;
    }
    return true;
  }
}

