/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.teamtracklicenselog.controller.test;

import com.monsanto.tcc.teamtracklicenselog.controller.LogParserController;
import com.monsanto.tcc.teamtracklicenselog.dao.LogDAO;
import com.monsanto.wst.dbtemplate.test.mock.MockDBTemplate;
import junit.framework.TestCase;

import java.io.File;
import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;

/**
 * Filename:    $RCSfile: LogParserController_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: zznels $    	 On:	$Date: 2007-12-11 23:22:35 $
 *
 * @author zznels
 * @version $Revision: 1.1 $
 */
public class LogParserController_UT extends TestCase {
  private LogParserController controller = new LogParserController();

  public void testConvertsDateStringToDateType() throws Exception {
    Date testDate = controller.convertDate("12-10-2007");

    Calendar calendar = Calendar.getInstance();
    calendar.set(2007, 11, 10, 0, 0 ,0);
    calendar.setTimeZone(TimeZone.getTimeZone("CST"));
    assertEquals(calendar.getTime(), testDate);
  }

  public void testConvertDateThrowsExceptionWithInvalidDateFormat() throws Exception {
    try{
      controller.convertDate("");
      fail();
    } catch (IllegalArgumentException ex){
      //expected path
    }

    try{
      controller.convertDate(null);
      fail();
    } catch (IllegalArgumentException ex){
      //expected path
    }

    try{
      controller.convertDate("a-b-c");
      fail();
    } catch (IllegalArgumentException ex){
      //expected path
    }

    try{
      controller.convertDate("1231232-123213");
      fail();
    } catch (IllegalArgumentException ex){
      //expected path
    }

    try{
      controller.convertDate("190312-123123-89327408132");
      fail();
    } catch (IllegalArgumentException ex){
      //expected path
    }
  }

  public void testProcessLogFileDelegatesToParser() throws Exception {
    File testFile = new File("fileNotRequiredForTest");

    MockLogParser parser = new MockLogParser();
    controller.setLogFileParser(parser);

    controller.processLogFile(testFile, "12-10-2007");

    assertTrue(parser.wasCalled());
  }
  
  public void testProcessLogFileInsertsToDB() throws Exception {
    MockDBTemplate mockTemplate = new MockDBTemplate();
    LogDAO testDAO = new LogDAO(mockTemplate);
    File testFile = new File("source/java/com/monsanto/tcc/teamtracklicenselog/controller/test/test.log");

    controller.setLogDAO(testDAO);

    controller.processLogFile(testFile, "12-10-2007");

    assertTrue(mockTemplate.wasStatementNameCalled(LogDAO.INSERT_LOG_QUERY_NAME));
  }

}