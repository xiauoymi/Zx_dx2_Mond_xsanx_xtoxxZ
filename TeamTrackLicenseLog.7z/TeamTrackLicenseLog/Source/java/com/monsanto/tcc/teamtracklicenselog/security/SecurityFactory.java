package com.monsanto.tcc.teamtracklicenselog.security;

import com.monsanto.AbstractLogging.Logger;
import com.monsanto.security.SecurityServer;
import com.monsanto.security.SecurityServiceException;
import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.SecurityServerFactory.SecurityServerFactory;
import com.monsanto.tcc.teamtracklicenselog.servlet.TeamTrackLicenseLogServlet;

import java.util.ResourceBundle;

/**
 *
 * <p>Title: SecurityFactory</p>
 * <p>Description: Creates a SecureUser object and passes it to the caller.</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Monsanto</p>
 * @author Java Framework Code Generator 3.0
 * @version $Id: SecurityFactory.java,v 1.1 2007-09-19 19:42:09 mterry Exp $
 */
public class SecurityFactory
{
   protected SecurityFactory()
   {
      Logger.traceEntry();

      Logger.traceExit();
   }

   /**
    * @return com.monsanto.security.SecurityServer
    */
   public static SecurityServer buildSecurityServer(UCCHelper helper) throws SecurityServiceException
   {
      Logger.traceEntry();

      ResourceBundle bundle = ResourceBundle.getBundle(TeamTrackLicenseLogServlet.s_cstrResourceBundle);
      SecurityServerFactory factory = new SecurityServerFactory(helper, bundle);

      return (SecurityServer) Logger.traceExit(factory.buildSecurityServer());
   }

   public static String getAppName ()
   {
      Logger.traceEntry();

      return Logger.traceExit("TeamTrackLicenseLog");
   }
}
