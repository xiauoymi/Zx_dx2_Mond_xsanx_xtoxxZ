/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.teamtracklicenselog.logParser.test;

import com.monsanto.tcc.teamtracklicenselog.logParser.TTLogParser;
import com.monsanto.tcc.teamtracklicenselog.model.LogEntry;
import junit.framework.TestCase;

import java.io.File;
import java.util.Date;
import java.util.List;

/**
 * Filename:    $RCSfile: TTLogParser_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: zznels $    	 On:	$Date: 2007-12-14 21:29:43 $
 *
 * @author zznels
 * @version $Revision: 1.1 $
 */
public class TTLogParser_UT extends TestCase {

  TTLogParser lP;

  public void setUp() throws Exception {
    super.setUp();
    lP = new TTLogParser();
  }

  public void testParseFileReturnsListOfEntries() throws Exception {
    List<LogEntry> result = lP.parse(new File("source/java/com/monsanto/tcc/teamtracklicenselog/logParser/test/test.log"), new Date(0));

    assertNotNull(result);
    int numOfEntries = 102; //includes NoType Entries
    assertEquals(numOfEntries, result.size());
  }

  public void testParseFileIncrementsDateAsAppropriate() throws Exception {
    List<LogEntry> result = lP.parse(new File("source/java/com/monsanto/tcc/teamtracklicenselog/logParser/test/twodaytest.log"), new Date(0));

    assertNotNull(result);
    int numOfEntries = 74;
    assertEquals(numOfEntries, result.size());
    assertTrue(result.get(1).getTimeInms() > result.get(result.size()-1).getTimeInms());
    assertTrue(result.get(1).getDateTime().getTime() < result.get(result.size()-1).getDateTime().getTime());
  }

}