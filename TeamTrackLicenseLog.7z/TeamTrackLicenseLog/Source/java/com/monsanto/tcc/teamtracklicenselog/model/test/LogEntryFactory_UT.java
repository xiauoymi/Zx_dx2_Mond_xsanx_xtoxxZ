/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.teamtracklicenselog.model.test;

import com.monsanto.tcc.teamtracklicenselog.model.*;
import junit.framework.TestCase;

/**
 * Filename:    $RCSfile: LogEntryFactory_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: zznels $    	 On:	$Date: 2007-12-11 23:22:35 $
 *
 * @author zznels
 * @version $Revision: 1.1 $
 */
public class LogEntryFactory_UT extends TestCase {
  LogEntryFactory testFactory;

  public void setUp() throws Exception {
    super.setUp();
    testFactory = new LogEntryFactory();
  }

  public void testFactoryReturnsLogEntry() throws Exception {
    LogEntry test = testFactory.createEntry("18:23:34 (blah)");

    assertNotNull(test);
  }
  
  public void testCreateReturnsNoTypeEntryWithNullOrEmptyLine() throws Exception {
    LogEntry testEntry = testFactory.createEntry(null);

    assertNull(testEntry);

    LogEntry testEntry2 = testFactory.createEntry(" ");

    assertNull(testEntry2);
  }

  public void testCreateStandardInType() throws Exception {
    String test = "12:28:44 (merant) IN: \"TeamTrack\" TASCHA1@tascha1";

    LogEntry result = testFactory.createEntry(test);

    assertTrue(result.getTime().equals("12:28:44"));
    assertTrue(result.getUserID().equals("TASCHA1"));
    assertTrue(result.getWorkstation().equals("tascha1"));
    assertTrue(result instanceof InLogEntry);
  }

  public void testCreateStandardOutType() throws Exception {
    String test = "12:25:25 (merant) OUT: \"TeamTrack\" JJKAPA@jjkapa-2";

    LogEntry result = testFactory.convertToEntry(test);

    assertTrue(result.getTime().equals("12:25:25"));
    assertTrue(result.getUserID().equals("JJKAPA"));
    assertTrue(result.getWorkstation().equals("jjkapa-2"));
    assertTrue(result instanceof OutLogEntry);
  }

  public void testCreateDeclineNamedLicense() throws Exception {
    String test = "12:22:59 (merant) DENIED: \"TeamTrack_named\" RLHENL@rlhenl-2  (User is not on the include list and cannot be added because Auto-Add is not turned on for this feature.)";

    LogEntry result = testFactory.createEntry(test);

    assertTrue(result instanceof NoTypeLogEntry);
  }

  public void testCreateDeclineTooManyLicensesOut() throws Exception {
    String test = "16:01:31 (merant) DENIED: \"TeamTrack\" RRPALL@rrpall-1  (Licensed number of users already reached. (-4,342))";

    LogEntry result = testFactory.createEntry(test);

    assertTrue(result instanceof DeniedLogEntry);
  }

  public void testCreateUnsupported() throws Exception {
    String test = "16:01:27 (merant) UNSUPPORTED: \"TeamTrack\" (001E 928E 7BD9 44F1 ) RRPALL@rrpall-1  (License server system does not support this feature. (-18,327))";

    LogEntry result = testFactory.convertToEntry(test);

    assertNotNull(result);
    assertTrue(result instanceof NoTypeLogEntry);
  }

  public void testCreateNamed() throws Exception {
    String test = "12:30:49 (merant) OUT: \"TeamTrackTTT_named\" 8845484907@w3stats";

    LogEntry result = testFactory.convertToEntry(test);

    assertTrue(result.isNamedLicense());
  }

}