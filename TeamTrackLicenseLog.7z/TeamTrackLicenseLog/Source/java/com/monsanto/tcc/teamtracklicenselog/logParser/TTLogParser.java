/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.teamtracklicenselog.logParser;

import com.monsanto.tcc.teamtracklicenselog.model.LogEntry;
import com.monsanto.tcc.teamtracklicenselog.model.LogEntryFactory;

import java.io.*;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Filename:    $RCSfile: TTLogParser.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: zznels $    	 On:	$Date: 2007-12-14 21:29:43 $
 *
 * @author zznels
 * @version $Revision: 1.1 $
 */

public class TTLogParser {
  private BufferedReader reader;
  private static final int ONE_DAY_IN_MILLISECS = 86400000;
  private LogEntryFactory entryFactory = new LogEntryFactory();


  /**
   *
   * @param file: Log File to parse
   * @param startDate: The Date (at midnight) the log was started
   * @return List<LogEntry>: A list of LogEntries represented by this file
   * @throws FileNotFoundException: If the log file cannot be opened
   */
  public List<LogEntry> parse(File file, Date startDate) throws FileNotFoundException {
    reader = new BufferedReader(new FileReader(file));
    List<LogEntry> result = new ArrayList<LogEntry>();

    String line;
    long currTime = 0;
    try {
      while((line=getNextLine())!=null){
        LogEntry entry = entryFactory.createEntry(line);

        if(entry != null){
          if(currTime > entry.getTimeInms()){
            startDate = new Date(startDate.getTime()+ ONE_DAY_IN_MILLISECS);
          }
          currTime = entry.getTimeInms();
          entry.setDate(startDate);

          result.add(entry);
        }
      }
    } catch (IOException e) {
      e.printStackTrace();
    }
    return result;
  }
  
  private String getNextLine() throws IOException {
    return reader.readLine();
  }

}