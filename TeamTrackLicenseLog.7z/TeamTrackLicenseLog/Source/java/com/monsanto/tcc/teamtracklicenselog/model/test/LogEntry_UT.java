/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.teamtracklicenselog.model.test;

import com.monsanto.tcc.teamtracklicenselog.dao.LogDAO;
import com.monsanto.tcc.teamtracklicenselog.model.InLogEntry;
import com.monsanto.tcc.teamtracklicenselog.model.LogEntry;
import com.monsanto.tcc.teamtracklicenselog.model.NoTypeLogEntry;
import com.monsanto.wst.dbtemplate.factory.AbstractTransactionManagerFactory;
import com.monsanto.wst.dbtemplate.transaction.TransactionManager;
import junit.framework.TestCase;

import java.util.Date;

/**
 * Filename:    $RCSfile: LogEntry_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: zznels $    	 On:	$Date: 2007-12-11 23:22:35 $
 *
 * @author zznels
 * @version $Revision: 1.2 $
 */
public class LogEntry_UT extends TestCase {

  public void testConverToDateTime() throws Exception {
    LogEntry entry = new NoTypeLogEntry();
    entry.setDate(new Date(0));
    entry.setTime("02:03:45");
    int testDateTime = 7425000;

    assertEquals(testDateTime, entry.getDateTime().getTime());
  }

  public void testSaveToDAO() throws Exception {
    LogEntry inEntry = new InLogEntry();
    LogEntry noTypeEntry = new NoTypeLogEntry();

    TransactionManager txManager = AbstractTransactionManagerFactory.newInstance(
                "com/monsanto/tcc/teamtracklicenselog/dao/licenselogDBConfig.xml").getTransactionManager();
    LogDAO testDAO = new LogDAO(txManager);

    assertTrue(inEntry.save(testDAO)); //test Default
    assertFalse(noTypeEntry.save(testDAO)); //test Override

    txManager.rollbackTransaction();
  }

}