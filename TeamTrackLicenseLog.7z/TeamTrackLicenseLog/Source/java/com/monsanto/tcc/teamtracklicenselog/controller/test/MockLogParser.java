/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.teamtracklicenselog.controller.test;

import com.monsanto.tcc.teamtracklicenselog.model.LogEntry;
import com.monsanto.tcc.teamtracklicenselog.logParser.TTLogParser;

import java.util.List;
import java.util.Date;
import java.util.ArrayList;
import java.io.File;
import java.io.FileNotFoundException;

/**
 * Filename:    $RCSfile: MockLogParser.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: zznels $    	 On:	$Date: 2007-12-14 21:29:43 $
 *
 * @author zznels
 * @version $Revision: 1.3 $
 */
public class MockLogParser extends TTLogParser {
  private boolean wasCalled = false;

  public boolean wasCalled() {
    return wasCalled;
  }

  @Override
  public List<LogEntry> parse(File file, Date startDate) throws FileNotFoundException {
    wasCalled = true;
    return new ArrayList<LogEntry>();
  }
}