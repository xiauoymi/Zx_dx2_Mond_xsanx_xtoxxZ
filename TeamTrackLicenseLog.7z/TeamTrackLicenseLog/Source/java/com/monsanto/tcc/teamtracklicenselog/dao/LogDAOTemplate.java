/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.teamtracklicenselog.dao;

import com.monsanto.wst.dbtemplate.DBTemplateImpl;
import com.monsanto.wst.dbtemplate.transaction.TransactionManager;

/**
 * Filename:    $RCSfile: LogDAOTemplate.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: zznels $    	 On:	$Date: 2007-12-11 23:22:35 $
 *
 * @author zznels
 * @version $Revision: 1.2 $
 */
public class LogDAOTemplate extends DBTemplateImpl {
  private static final String CONFIG = "com/monsanto/tcc/teamtracklicenselog/dao/LicenseLogDBConfig.xml";
  private static final String[] MAPPINGS = {"com/monsanto/tcc/teamtracklicenselog/dao/LicenseLogDBQueryMapping.xml"};

  public LogDAOTemplate() {
    super(CONFIG, MAPPINGS);
  }

  public LogDAOTemplate(TransactionManager txManager) {
    super(txManager, MAPPINGS);
  }
}