/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.teamtracklicenselog.model;

import com.monsanto.tcc.teamtracklicenselog.dao.LogDAO;

/**
 * Filename:    $RCSfile: NoTypeLogEntry.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: zznels $    	 On:	$Date: 2007-12-11 23:22:35 $
 *
 * @author zznels
 * @version $Revision: 1.1 $
 */
public class NoTypeLogEntry extends LogEntry{
  public String getLogType() {
    return "NO_TYPE";
  }

  @SuppressWarnings({"RefusedBequest"})
  public boolean save(LogDAO DAO) {
    return false;
  }
}