/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.teamtracklicenselog.controller;

import com.monsanto.tcc.teamtracklicenselog.dao.LogDAO;
import com.monsanto.tcc.teamtracklicenselog.model.LogEntry;
import com.monsanto.tcc.teamtracklicenselog.logParser.TTLogParser;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

/**
 * Filename:    $RCSfile: LogParserController.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: zznels $    	 On:	$Date: 2007-12-14 21:29:43 $
 *
 * @author zznels
 * @version $Revision: 1.3 $
 */
public class LogParserController {
  private TTLogParser parser = new TTLogParser();
  private LogDAO DAO = new LogDAO();

  public Date convertDate(String s) throws IllegalArgumentException {
    String[] part;
    try{
      part = s.split("-");
    } catch (Exception ex){
      throw new IllegalArgumentException("Invalid Date Format");
    }
    if(part.length!=3){
      throw new IllegalArgumentException("Invalid Date Format");
    }
    Calendar ret = Calendar.getInstance();
    try{
      ret.set(Integer.parseInt(part[2]), Integer.parseInt(part[0])-1, Integer.parseInt(part[1]), 0 , 0 , 0);
    } catch (NumberFormatException ex){
      throw new IllegalArgumentException("Invalid Date Format");
    }
    return ret.getTime();
  }

  public void processLogFile(File logFile, String startDate) throws FileNotFoundException {
    List<LogEntry> logEntries = parser.parse(logFile, convertDate(startDate));
    for(LogEntry entry: logEntries){
      entry.save(DAO);
    }
  }

  public void setLogFileParser(com.monsanto.tcc.teamtracklicenselog.logParser.TTLogParser parser) {
    this.parser = parser;
  }

  public void setLogDAO(LogDAO dao) {
    this.DAO = dao;
  }
}