/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.teamtracklicenselog.dao.test;

import com.monsanto.tcc.teamtracklicenselog.dao.LogDAO;
import com.monsanto.tcc.teamtracklicenselog.model.LogEntry;
import com.monsanto.tcc.teamtracklicenselog.model.NoTypeLogEntry;
import com.monsanto.wst.dbtemplate.factory.AbstractTransactionManagerFactory;
import com.monsanto.wst.dbtemplate.transaction.TransactionManager;
import junit.framework.TestCase;

import java.util.Date;

/**
 * Filename:    $RCSfile: LogDAO_AT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: zznels $    	 On:	$Date: 2007-12-11 23:22:35 $
 *
 * @author zznels
 * @version $Revision: 1.3 $
 */
public class LogDAO_AT extends TestCase {
  private TransactionManager txManager;
  private LogDAO testDAO;

  public void setUp() throws Exception{
    super.setUp();
    txManager = AbstractTransactionManagerFactory.newInstance(
                "com/monsanto/tcc/teamtracklicenselog/dao/licenselogDBConfig.xml").getTransactionManager();
    this.testDAO = new LogDAO(txManager);
  }

  protected void tearDown() throws Exception {
    super.tearDown();
    txManager.rollbackTransaction();
  }
  
  public void testInsertLog() throws Exception {
    LogEntry log = new NoTypeLogEntry();
    log.setUserID("testID");
    log.setWorkstation("testStation");
    log.setDate(new Date());
    log.setTime("01:02:03");
    log.setNamedLicense(false);

    testDAO.insertLog(log);
    //passes if no exception thrown
  }

}