package com.monsanto.tcc.teamtracklicenselog.servlet;

import com.monsanto.AbstractLogging.DebugLogEvent;
import com.monsanto.AbstractLogging.LoggableError;
import com.monsanto.AbstractLogging.LoggableInfo;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.POSServlet.POSErrorResponse;
import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.ServletFramework.UseCaseController;
import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.XMLUtil.ParserException;
import com.monsanto.XMLUtil.ValidationException;
import com.monsanto.dataservices.PersistentStore;
import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.tcc.teamtracklicenselog.security.SecurityFactory;
import com.monsanto.security.LoginBrief;
import com.monsanto.security.LogonFailedException;
import com.monsanto.security.NoLogonInformationException;
import com.monsanto.security.SecureUser;
import com.monsanto.security.SecurityGateKeeper;
import com.monsanto.security.SecurityServiceException;
import com.monsanto.user.NoSuchUserException;
import com.monsanto.SecurityServerFactory.SecurityServerFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMResult;
import javax.xml.transform.dom.DOMSource;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.ResourceBundle;

public abstract class TeamTrackLicenseLogBasePOSController implements UseCaseController {
  private static final String EMPTY_STRING = "";
  public static final String PASSWORD_REQUEST_PARAM = "Password";
  public static final String USERNAME_REQUEST_PARAM = "UserName";
  public static final String SCHEMA_SOURCE = "posEnvelope.xsd";
  public static final String SCHEMAS_DIR = "/schemas/";
  public static final String NAME_SPACE = "http://www.monsanto.com/pos ";

  public void run(UCCHelper helper) throws IOException {
    try {
      String inputDocPath = getInputDocumentPath(helper);
      String absolutePathToSchemaDir = getAbsolutePathToSchemaDir(helper);
      Document inputDocument = validateDocument(inputDocPath, absolutePathToSchemaDir);
      authorizeUser(inputDocument, helper);
      Document childDocument = validateChildDocument(inputDocument, absolutePathToSchemaDir);
      runImplementation(helper, childDocument);
    }
    catch (SAXException e) {
      displayAndLogToError(e, helper);
    }
    catch (NoLogonInformationException e) {
      displayAndLogToInfo(e, helper);
    }
    catch (LogonFailedException e) {
      displayAndLogToInfo(e, helper);
    }
    catch (ValidationException e) {
      displayAndLogToError(e, helper);
    }
    catch (ParserException e) {
      displayAndLogToError(e, helper);
    }
    catch (TransformerException e) {
      displayAndLogToError(e, helper);
    }
  }

  protected abstract void runImplementation(UCCHelper helper, Document inputDocument) throws IOException;

  protected abstract String getPosSchemaPath();

  private String getAbsolutePathToSchemaDir(UCCHelper helper) {
    String currentDirectory = helper.getCurrentDirectory();
    currentDirectory = currentDirectory.replace('\\','/');
    return currentDirectory + SCHEMAS_DIR;
  }

  private String getInputDocumentPath(UCCHelper helper) throws IOException, ValidationException {
    helper.setImportFileDir(File.separator + "import");
    ArrayList fileList = helper.getClientFiles();
    if (fileList != null && fileList.size() > 0) {
      return fileList.get(0).toString();
    }
    else {
      ArrayList list = new ArrayList(1);
      list.add("Could not find input document");
      throw new ValidationException(list);
    }
  }

  protected Document validateDocument(String documentPath, String absolutePathToSchemaDir)
          throws IOException, SAXException, ValidationException, ParserException {
    Document document = DOMUtil.newDocument(documentPath);
    String schemaPath = NAME_SPACE + absolutePathToSchemaDir + SCHEMA_SOURCE;
    ArrayList reasons = DOMUtil.schemaValidate(document, schemaPath);
    if (reasons.size() > 0) {
      throw new ValidationException(reasons);
    }
    return document;
  }

  protected Document validateChildDocument(Document inputDocument, String absolutePathToSchemaDir)
          throws ValidationException, IOException, SAXException, TransformerException {
    Node posNode = getPosNode(inputDocument);
    Document document = DOMUtil.newDocument();
    addThePosNodeToTheNewDocument(document, posNode);

    ArrayList reasons = DOMUtil.schemaValidate(document, NAME_SPACE + absolutePathToSchemaDir + getPosSchemaPath());
    if (reasons.size() > 0) {
      throw new ValidationException(reasons);
    }
    return document;
  }

  private Node getPosNode(Document inputDocument) {
    Node commandNode = getFirstNode(inputDocument, "command");
    return commandNode.getFirstChild();
  }

  private void addThePosNodeToTheNewDocument(Document document, Node posNode) throws TransformerException {
    Transformer transformer = TransformerFactory.newInstance().newTransformer();
    transformer.setOutputProperty(OutputKeys.METHOD, "xml");
    transformer.setOutputProperty(OutputKeys.INDENT, "yes");
    DOMResult domResult = new DOMResult(document);
    transformer.transform(new DOMSource(posNode), domResult);
  }

  protected PersistentStoreConnection getConnection() throws WrappingException {
    PersistentStore persistentStore = PersistentStore.instance();
    return persistentStore.connect();
  }

  protected void closeConnection(final PersistentStoreConnection conn) throws WrappingException {
    if (conn != null) {
      conn.close();
    }
  }

  protected void displayErrorMessage(final Throwable throwable, final UCCHelper helper) {
    POSErrorResponse errorResponse = new POSErrorResponse(throwable);
    final Document document = errorResponse.toXML();
    helper.writeXMLDocument(document);
  }

  protected void logError(Throwable throwable) {
    logError(throwable, EMPTY_STRING);
  }

  protected void logError(Throwable throwable, String prependMessage) {
    Logger.log(new LoggableError(prependMessage + throwable.toString()));
  }

  protected void logInfo(Throwable throwable) {
    logError(throwable, EMPTY_STRING);
  }

  protected void logInfo(Throwable e, String prependMessage) {
    Logger.log(new LoggableInfo(prependMessage + e.toString()));
  }

  protected void displayAndLogToInfo(final Throwable e, final UCCHelper helper) {
    displayAndLogToInfo(e, helper, EMPTY_STRING);
  }

  protected void displayAndLogToInfo(final Throwable e, final UCCHelper helper, String prependMessage) {
    logInfo(e, prependMessage);
    displayErrorMessage(e, helper);
  }

  protected void displayAndLogToError(final Throwable e, final UCCHelper helper) {
    displayAndLogToError(e, helper, EMPTY_STRING);
  }

  protected void displayAndLogToError(final Throwable e, final UCCHelper helper, String prependMessage) {
    logError(e, prependMessage);
    displayErrorMessage(e, helper);
  }

  private LoginBrief authorizeUser(Document inputDocument, UCCHelper helper) throws LogonFailedException, NoLogonInformationException, SecurityServiceException {
    SecureUser secureUser = buildSecureUser(inputDocument, helper);
    SecurityGateKeeper gateKeeper = new SecurityGateKeeper();
		ResourceBundle bundle = ResourceBundle.getBundle(TeamTrackLicenseLogServlet.s_cstrResourceBundle);
		SecurityServerFactory factory = new SecurityServerFactory(helper, bundle);
    LoginBrief retVal = gateKeeper.login(secureUser, SecurityFactory.getAppName(), factory.buildSecurityServer());
    Logger.log(new LoggableInfo("Logged on user: " + secureUser.userId()));
    return retVal;
  }

  private SecureUser buildSecureUser(Document inputDocument, UCCHelper helper) throws LogonFailedException, NoLogonInformationException {
  	String userName = helper.getAuthenticatedUserID(); // Authenticated user from Kerberos
  	String password = ""; // no password needed for Kerberos
  	// userid not provided by Kerberos, see if it comes from inputDocument
  	if ((userName == null) || userName.equals("")) {
    	Node securityNode = getFirstNode(inputDocument, "security");
    	userName = getUserNameFromDocument(securityNode);
    	password = getPasswordFromDocument(securityNode, userName);
    }

    return createSecureUser(userName, password);
  }

  protected Node getFirstNode(Document inputDocument, String tagName) {
    NodeList nodeList = getNodesForTag(inputDocument, tagName);
    Node node = nodeList.item(0);
    return node;
  }

  protected NodeList getNodesForTag(Document inputDocument, String tagName) {
    return inputDocument.getElementsByTagName(tagName);
  }

  private String getUserNameFromDocument(Node securityNode) throws NoLogonInformationException {
    String userName = DOMUtil.getChildValue(securityNode, "userName");
    if (userName == null || userName.equals("")) {
      Logger.log(new DebugLogEvent("Login Failed: No Username provided."));
      throw new NoLogonInformationException("Login Failed: No Username provided.");
    }
    return userName;
  }

  private String getPasswordFromDocument(Node securityNode, String userName) throws NoLogonInformationException {
    String password = DOMUtil.getChildValue(securityNode, "password");
    if (password == null || password.equals("")) {
      Logger.log(new DebugLogEvent("Login Failed: No Password provided for user: " + userName));
      throw new NoLogonInformationException("Login Failed: No Password provided.");
    }
    return password;
  }

  private SecureUser createSecureUser(String cstrUsername, String cstrPassword) throws LogonFailedException {
    SecureUser user = null;
    try {
      user = new SecureUser(cstrUsername, cstrPassword);
    }
    catch (WrappingException e) {
      Logger.log(new DebugLogEvent("Login Failed: Problem occurred while getting AlhenaSecureUser from DB"));
      throw new LogonFailedException("Login Failed: Problem with DB.");
    }
    catch (NoSuchUserException e) {
      Logger.log(new DebugLogEvent("Login Failed: User does not exist - " + cstrUsername));
      throw new LogonFailedException("Login Failed: User " + cstrUsername + " does not exist.");
    }
    return user;
  }
}
