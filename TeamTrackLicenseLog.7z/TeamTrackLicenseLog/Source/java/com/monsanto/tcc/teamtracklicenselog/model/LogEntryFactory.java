/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.teamtracklicenselog.model;

/**
 * Filename:    $RCSfile: LogEntryFactory.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: zznels $    	 On:	$Date: 2007-12-14 20:05:30 $
 *
 * @author zznels
 * @version $Revision: 1.2 $
 */
public class LogEntryFactory {
  public LogEntry createEntry(String line) {
    return convertToEntry(line);
  }

  /**
   *
   * @param line: Line the log file to convert to an LogEntry
   * @return LogEntry: representing the line inputted. Will return null if line is null or empty.
   */
  public LogEntry convertToEntry(String line){
    if(line == null){
      return null;
    }
    String[] part;
    part = line.split(" ");

    if(part.length == 0 || part[0].equals("")){
      return null;
    }

    LogEntry result = QualifyLine(line);
    result.setTime(part[0]);
    if(!(result instanceof NoTypeLogEntry)){
      parseLogInfo(result, part);
    }
    return result;
  }

  private void parseLogInfo(LogEntry result, String[] part) {
    result.setNamedLicense(part[3].endsWith("_named\""));
    result.setUserID(part[4].split("@")[0]);
    result.setWorkstation(part[4].split("@")[1]);
  }

  private LogEntry QualifyLine(String line){
    LogEntry result;

    if(line==null){
      return new NoTypeLogEntry();
    }

    String[] part = line.split(" ");
    if(part.length<4){
      result = new NoTypeLogEntry();
    }
    else{
      result = parseLogType(part);
      if(result instanceof DeniedLogEntry){
        if(part[6].equals("(User")){
          result = new NoTypeLogEntry();
        }
      }
    }
    return result;
  }

  private LogEntry parseLogType(String[] part) {
    LogEntry result;
    String type = part[2].replaceAll(":", "");
    if("IN".equals(type)){
      result = new InLogEntry();
    }
    else if("OUT".equals(type)){
      result = new OutLogEntry();
    }
    else if("DENIED".equals(type)){
      result = new DeniedLogEntry();
    }
    else{
      result = new NoTypeLogEntry();
    }
    return result;
  }
}