package com.monsanto.tcc.teamtracklicenselog.servlet;



import java.io.File;




/**
 *
 * <p>Title: I_TeamTrackLicenseLogSessionParams</p>
 * <p>Description: This will serve for constants for putting proposal session lists</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Monsanto</p>
 * @author Java Framework Code Generator 3.0
 * @version $Id: I_SessionParams.java,v 1.1 2007-09-19 19:42:51 mterry Exp $
 */
public interface I_SessionParams
{
   /*  User roles  */
   public static final String sf_cstrSECURITY_GATEKEEPER = "TeamTrackLicenseLogSecurityGatekeeper";
   public static final String sf_cstrCURRENT_USER        = "TeamTrackLicenseLogUser";

   /*  Directories.  */
   public static final String sf_cstrCONFIG_DIR = "../Config";     // Properties files
   public static final String sf_cstrLINKFILES_DIR = "../linkfiles";  // Files for temp html links
   public static final String sf_cstrIMPORT_DIR = File.separator + "import";        // Uploaded files
   public static final String sf_cstrJAVASCRIPT_DIR = "../JavaScript"; // JavaScript files
   public static final String sf_cstrSTYLESHEET_DIR = "../Stylesheet"; // Stylesheets
   public static final String sf_cstrHTML_DIR = "../html";       // Static html files
   public static final String sf_cstrXML_SCHEMAS_DIR = "";
}
