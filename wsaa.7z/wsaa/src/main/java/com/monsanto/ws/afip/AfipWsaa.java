package com.monsanto.ws.afip;

/**
 *
 * Authentication and Authorization Service WebServices (WSAA) belonging
 * to the AFIP. This service is required for the AFIP External Entities
 * (EE) to access the WebServices Business (WSN) offered by the AFIP.
 *
 * Created by SHELG on 10/21/2014.
 */
public interface AfipWsaa {


    /**
     *
     * @param LoginTicketRequestXmlCms byte[]
     * @param endpoint String
     * @return String
     * @throws Exception e
     */
    String invokeWsaa(byte[] LoginTicketRequestXmlCms, String endpoint)throws Exception;

    /**
     *
     * @param p12file String
     * @param p12pass String
     * @param signer String
     * @param dstDN String
     * @param service String
     * @param uniqueId String
     * @param offsetTime Long
     * @param ticketTime Long
     * @return byte[]
     */
    byte[] createCms(String p12file, String p12pass, String signer, String dstDN, String service,
                     String uniqueId, Long offsetTime, Long ticketTime);

}