package com.monsanto.ws;

import javax.jws.WebService;
import java.util.Date;

/**
 * @see com.monsanto.ws.Ping
 *
 * Created by SHELG on 10/21/2014.
 */
@WebService(endpointInterface="com.monsanto.ws.Ping")
public class PingImpl implements Ping{


    /**
     * @see com.monsanto.ws.Ping#ping()
     */
    public String ping() {

        return "Ping back @" + new Date( System.currentTimeMillis() );
    }
}
