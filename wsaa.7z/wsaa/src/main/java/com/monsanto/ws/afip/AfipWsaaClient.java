package com.monsanto.ws.afip;

import org.apache.axis.client.Call;
import org.apache.axis.client.Service;
import org.apache.axis.encoding.Base64;
import org.apache.axis.encoding.XMLType;
import org.bouncycastle.cms.CMSProcessable;
import org.bouncycastle.cms.CMSProcessableByteArray;
import org.bouncycastle.cms.CMSSignedData;
import org.bouncycastle.cms.CMSSignedDataGenerator;
import org.bouncycastle.jce.provider.BouncyCastleProvider;

import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;
import javax.xml.rpc.ParameterMode;
import java.io.File;
import java.io.FileInputStream;
import java.net.URL;
import java.net.URLDecoder;
import java.security.KeyStore;
import java.security.PrivateKey;
import java.security.Security;
import java.security.cert.CertStore;
import java.security.cert.CollectionCertStoreParameters;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;

/**
 * @see com.monsanto.ws.afip.AfipWsaa
 *
 * Created by SHELG on 10/21/2014.
 */
public class AfipWsaaClient implements AfipWsaa{

    /**
     * @see com.monsanto.ws.afip.AfipWsaa#invokeWsaa(byte[], String)
     */
    public String invokeWsaa(byte[] loginTicketRequestXmlCms, String endpoint)throws Exception {
        String loginTicketResponse;

        Call call = (Call) new Service().createCall();

        call.setTargetEndpointAddress(new URL(endpoint));
        call.setOperationName("loginCms");
        call.addParameter("request", XMLType.XSD_STRING, ParameterMode.IN);
        call.setReturnType(XMLType.XSD_STRING);

        loginTicketResponse = (String) call.invoke(new Object[]{Base64.encode(loginTicketRequestXmlCms)});

        return loginTicketResponse;
    }

    /**
     * @see com.monsanto.ws.afip.AfipWsaa#createCms(String, String, String, String, String, String, Long, Long)
     */
    public byte[] createCms(String p12file, String p12pass, String signer, String dstDN, String service, String uniqueId, Long offsetTime, Long ticketTime) {
        PrivateKey pKey;
        X509Certificate pCertificate;
        byte[] asn1Cms;
        CertStore cstore;

        String signerDN;
        try {
            KeyStore ks = KeyStore.getInstance("pkcs12");

            ClassLoader loader = AfipWsaaClient.class.getClassLoader();
            URL url = loader.getResource(p12file);
            String path = (url != null) ? url.getPath() : "";
            String decodedPath = URLDecoder.decode(path, "UTF-8");
            FileInputStream p12stream = new FileInputStream(new File(decodedPath).getAbsolutePath());
            ks.load(p12stream, p12pass.toCharArray());
            p12stream.close();

            pKey = (PrivateKey) ks.getKey(signer, p12pass.toCharArray());
            pCertificate = (X509Certificate) ks.getCertificate(signer);
            signerDN = pCertificate.getSubjectDN().toString();

            List<X509Certificate> certList = new ArrayList<X509Certificate>();
            certList.add(pCertificate);

            if (Security.getProvider("BC") == null) {
                Security.addProvider(new BouncyCastleProvider());
            }
            cstore = CertStore.getInstance("Collection", new CollectionCertStoreParameters(certList), "BC");

            String loginTicketRequest_xml = createLoginTicketRequest(signerDN, dstDN, service, uniqueId, offsetTime, ticketTime);

            CMSSignedDataGenerator gen = new CMSSignedDataGenerator();
            gen.addSigner(pKey, pCertificate, CMSSignedDataGenerator.DIGEST_SHA1);
            gen.addCertificatesAndCRLs(cstore);

            CMSProcessable data = new CMSProcessableByteArray(loginTicketRequest_xml.getBytes());
            CMSSignedData signed = gen.generate(data, true, "BC");

            asn1Cms = signed.getEncoded();
        } catch (Exception e) {
            throw new IllegalStateException(e);
        }

        return asn1Cms;
    }

    /**
     *
     * @param signerDN String
     * @param dstDN String
     * @param service String
     * @param uniqueId String
     * @param offsetTime Long
     * @param ticketTime Long
     * @return String
     */
    private String createLoginTicketRequest(String signerDN, String dstDN, String service, String uniqueId, Long offsetTime, Long ticketTime) throws Exception {
        Date initTime = new Date();
        GregorianCalendar genTime = new GregorianCalendar();
        GregorianCalendar expTime = new GregorianCalendar();

        if ((uniqueId == null) || (uniqueId.equals(""))) {
            uniqueId = Long.toString(initTime.getTime() / 1000L);
        }
        genTime.setTime(new Date(initTime.getTime() - offsetTime));
        expTime.setTime(new Date(initTime.getTime() + ticketTime));
        String loginTicketRequestXml;

        try {
            XMLGregorianCalendar XMLGenTime = DatatypeFactory.newInstance().newXMLGregorianCalendar(genTime);
            XMLGregorianCalendar XMLExpTime = DatatypeFactory.newInstance().newXMLGregorianCalendar(expTime);

            loginTicketRequestXml = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><loginTicketRequest version=\"1.0\"><header><source>" +
                    signerDN + "</source>" +
                    "<destination>" + dstDN + "</destination>" +
                    "<uniqueId>" + uniqueId + "</uniqueId>" +
                    "<generationTime>" + XMLGenTime + "</generationTime>" +
                    "<expirationTime>" + XMLExpTime + "</expirationTime>" +
                    "</header>" +
                    "<service>" + service + "</service>" +
                    "</loginTicketRequest>";


        } catch (Exception e) {
           throw new Exception(e);
        }
        return loginTicketRequestXml;
    }


}