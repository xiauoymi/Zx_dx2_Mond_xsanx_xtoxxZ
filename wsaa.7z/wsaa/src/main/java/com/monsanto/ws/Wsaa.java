package com.monsanto.ws;

import com.monsanto.ws.entity.LoginTicketRsp;
import com.monsanto.ws.exception.WsaaException;

import javax.jws.WebParam;
import javax.jws.WebResult;
import javax.jws.WebService;

/**
 * Authentication and Authorization Service WebServices (WSAA) belonging
 * to the AFIP. This service is required for the AFIP External Entities
 * (EE) to access the WebServices Business (WSN) offered by the AFIP.
 *
 * Created by SHELG on 10/21/2014.
 */
@WebService(targetNamespace = "http://monsanto.com/SD/AFIPWebServices")
public interface Wsaa {

    /**
     * The WSAA, published by the AFIP WS that implements authentication of
     * computers EE (CEE) using X.509 digital certificates and authorization
     * of the consumer as a specific WebService Business (WSN).
     *
     * Should you encounter an error, the SOAP message will return a "SoapFault" containing the error code
     * and description produced. The description may additionally contain specific details of the error
     * (eg the XML expired 10 minutes ago).
     * The following table lists the error codes and corresponding description. If deemed necessary by the AFIP,
     * new error codes and their description will be added.
     * The EEC receiving WSAA codes different errors. Or wsn.unavailable should not request new TA until they
     * have solved the problem, either by managing the access rights to the service through Relations Manager,
     * synchronizing the date and time EWC, validating its developments, etc.
     * For other errors, the EEC should not request new TA within within 60 seconds.
     *
     * <p>
     *
     * Código 							Descripción
     * coe.notAuthorized				CEE no autorizado a acceder los servicio de AFIP.
     *                                  No deberá solicitar nuevos TA hasta que no haya
     *                                  gestionado el acceso WSN correspondiente.
     * coe.alreadyAuthenticated	    	El CEE ha solicitado un ticket de acceso para el cual ya
     *                                  dispone de TA validos. No deberá solicitar nuevos TA
     *                                  mientras disponga de TA validos para ese WSN correspondiente.
     * cms.bad  						El CMS no es valido
     * cms.bad.base64 					No se puede decodificar el BASE64
     * cms.cert.notFound 				No se ha encontrado certificado de firma en el CMS
     * cms.sign.invalid 				Firma inválida o algoritmo no soportado
     * cms.cert.expired 				Certificado expirado
     * cms.cert.invalid 				Certificado con fecha de generación posterior a la actual
     * cms.cert.untrusted 				Certificado no emitido por AC de confianza
     * xml.bad 						    No se ha podido interpretar el XML contra el SCHEMA
     * xml.source.invalid 				El atributo 'source' no se corresponde con el DN del Certificado
     * xml.destination.invalid 		    El atributo 'destination' no se corresponde con el DN del WSAA
     * xml.version.notSupported 		La versión del documento no es soportada
     * xml.generationTime.invalid 		El tiempo de generación es posterior a la hora actual o posee más de 24 horas de antigüedad
     * xml.expirationTime.expired 		El tiempo de expiración es inferior a la hora actual
     * xml.expirationTime.invalid 		El tiempo de expiración del documento es superior a 24 horas
     * wsn.unavailable 				    El servicio al que se desea acceder se encuentra momentáneamente fuera de servicio
     * wsn.notFound 					Servicio informado inexistente
     * wsaa.unavailable 				El servicio de autenticación/autorización se encuentra momentáneamente fuera de servicio
     * wsaa.internalError 				No se ha podido procesar el requerimiento
     * </p>
     *
     *
     * @param service String
     * @param uniqueId String
     * @return LoginTicketRsp loginTicketRsp
     * @throws WsaaException wse
     */
    @WebResult(name = "loginTicketResponse")
    LoginTicketRsp loginTicket(@WebParam(name = "service") String service,
                               @WebParam(name = "uniqueId") String uniqueId)
            throws WsaaException;

}