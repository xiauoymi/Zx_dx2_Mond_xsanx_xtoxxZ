package com.monsanto.ws;

import javax.jws.WebService;

/**
 * Web service that exposes a method that can be used to test connexion with this application
 *
 * Created by SHELG on 10/21/2014.
 */
@WebService
public interface Ping {

    /**
     * Method that can be used to test connexion with this application.
     *
     * <p>
     *      The metod returns "Ping back @" and timestamp.
     * </p>
     *
     * @return String ping
     */
    String ping();

}