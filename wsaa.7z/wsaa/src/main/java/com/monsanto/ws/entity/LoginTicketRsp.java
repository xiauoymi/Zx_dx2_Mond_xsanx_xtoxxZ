package com.monsanto.ws.entity;

import java.io.Serializable;

/**
 * Return of service with the authentication data
 *
 * Created by SHELG on 10/21/2014.
 */
public class LoginTicketRsp implements Serializable {

    private String token;
    private String sign;

    public String getToken() {
        return token;
    }

    public String getSign() {
        return sign;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public void setSign(String sign) {
        this.sign = sign;
    }
}