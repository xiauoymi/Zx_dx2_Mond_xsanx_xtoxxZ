package com.monsanto.ws.exception;

/**
 * WsaaException custom exception for WS
 * Created by SHELG on 10/21/2014.
 */
public class WsaaException extends Exception {


    public WsaaException(String message) {
        super(message);
    }

    public WsaaException(String message, Throwable t) {
        super(message, t);
    }

    public WsaaException(Throwable t) {
        super(t);
    }

}