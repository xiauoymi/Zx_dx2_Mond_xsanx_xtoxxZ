package com.monsanto.ws;

import com.monsanto.ws.afip.AfipWsaa;
import com.monsanto.ws.entity.LoginTicketRsp;
import com.monsanto.ws.exception.WsaaException;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

import javax.jws.WebService;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import java.io.StringReader;

/**
 * @see com.monsanto.ws.Wsaa
 *
 * Created by SHELG on 10/21/2014.
 */
@WebService(endpointInterface = "com.monsanto.ws.Wsaa")
public class WsaaImpl implements Wsaa {

    private AfipWsaa afipClient;

    private String srv;
    private String endPoint;
    private String dstDn;
    private String keyStore;
    private String keyStoreSigner;
    private String keyStorePassword;
    private String offsetTime;
    private String ticketTime;


    /**
     * @see com.monsanto.ws.Wsaa#loginTicket(String, String)
     */
    public LoginTicketRsp loginTicket(String service, String uniqueId) throws WsaaException {

        String loginTicketResponse;

        LoginTicketRsp rsp = new LoginTicketRsp();
        try {

            if (service == null) {
                service = this.srv;
            }
            String endpoint = this.endPoint;
            String dstDN = this.dstDn;

            String p12file = this.keyStore;
            String signer = this.keyStoreSigner;
            String p12pass = this.keyStorePassword;

            Long offsetTime = Long.valueOf(this.offsetTime);
            Long ticketTime = Long.valueOf(this.ticketTime);

            byte[] loginTicketRequestXmlCms = afipClient.createCms(p12file, p12pass, signer, dstDN, service, uniqueId, offsetTime, ticketTime);

            loginTicketResponse = afipClient.invokeWsaa(loginTicketRequestXmlCms, endpoint);


            DocumentBuilder db = DocumentBuilderFactory.newInstance().newDocumentBuilder();
            InputSource is = new InputSource();
            is.setCharacterStream(new StringReader(loginTicketResponse));

            org.w3c.dom.Document xml = db.parse(is);


            NodeList nodeLst = xml.getElementsByTagName("credentials");

            for (int s = 0; s < nodeLst.getLength(); s++) {
                Node fstNode = nodeLst.item(s);
                if (fstNode.getNodeType() == Node.ELEMENT_NODE) {

                    Element fstElmnt = (Element) fstNode;
                    NodeList fstNmElmntLst = fstElmnt.getElementsByTagName("token");
                    Element fstNmElmnt = (Element) fstNmElmntLst.item(0);
                    NodeList fstNm = fstNmElmnt.getChildNodes();

                    rsp.setToken(fstNm.item(0).getNodeValue());

                    NodeList lstNmElmntLst = fstElmnt.getElementsByTagName("sign");
                    Element lstNmElmnt = (Element) lstNmElmntLst.item(0);
                    NodeList lstNm = lstNmElmnt.getChildNodes();

                    rsp.setSign(lstNm.item(0).getNodeValue());

                    break;
                }
            }
        } catch (Exception e) {
            throw new WsaaException(e);
        }
        return rsp;
    }


    public void setAfipClient(AfipWsaa afipClient) {
        this.afipClient = afipClient;
    }

    public void setSrv(String srv) {
        this.srv = srv;
    }

    public void setEndPoint(String endPoint) {
        this.endPoint = endPoint;
    }

    public void setDstDn(String dstDn) {
        this.dstDn = dstDn;
    }

    public void setKeyStore(String keyStore) {
        this.keyStore = keyStore;
    }

    public void setKeyStoreSigner(String keyStoreSigner) {
        this.keyStoreSigner = keyStoreSigner;
    }

    public void setKeyStorePassword(String keyStorePassword) {
        this.keyStorePassword = keyStorePassword;
    }

    public void setOffsetTime(String offsetTime) {
        this.offsetTime = offsetTime;
    }

    public void setTicketTime(String ticketTime) {
        this.ticketTime = ticketTime;
    }
}
