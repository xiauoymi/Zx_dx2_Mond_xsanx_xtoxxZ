package com.monsanto.ws;

import com.monsanto.ws.afip.AfipWsaa;
import static org.junit.Assert.*;
import com.monsanto.ws.afip.AfipWsaaClient;
import org.junit.Test;
import java.io.InputStreamReader;
import java.util.Properties;

/**
 * Test Class to WSAA Client
 *
 * Created by SHELG on 10/21/2014.
 */
public class Wsaa_UT {

    @Test
    public void test_TicketResponseAfipWsaaClient() {
        String loginTicketResponse;
        AfipWsaa wsaaCliet = new AfipWsaaClient();

        try {
            Properties config = new Properties();

            String service = config.getProperty("prop.service");
            String uniqueId = "555";

            config.load(new InputStreamReader(Wsaa_UT.class.getClassLoader()
                    .getResourceAsStream("wsaa.properties")));
            String endpoint = config.getProperty("prop.endpoint");
            String dstDN = config.getProperty("prop.dstdn");

            String p12file = config.getProperty("prop.keystore");
            String signer = config.getProperty("prop.keystore.signer");
            String p12pass = config.getProperty("prop.keystore.password");

            Long offsetTime = new Long(config.getProperty("prop.offset.time"));
            Long ticketTime = new Long(config.getProperty("prop.ticket.time"));

            byte[] loginTicketRequestXmlCms = wsaaCliet.createCms(
                    p12file, p12pass, signer, dstDN, service, uniqueId, offsetTime, ticketTime);

            loginTicketResponse = wsaaCliet.invokeWsaa( loginTicketRequestXmlCms, endpoint);
        } catch (Exception e) {
            loginTicketResponse = "<Fault><type>" +
                    e.getClass().getSimpleName() + "</type>" +
                    "<message>" + e.getMessage() + "</message>" +
                    "</Fault>";
        }

        assertNotNull(loginTicketResponse);
    }
}