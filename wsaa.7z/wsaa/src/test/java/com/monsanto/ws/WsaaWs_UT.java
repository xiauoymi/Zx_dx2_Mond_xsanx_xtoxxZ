package com.monsanto.ws;

import com.monsanto.ws.afip.AfipWsaaClient;
import com.monsanto.ws.entity.LoginTicketRsp;
import com.monsanto.ws.exception.WsaaException;
import org.junit.Test;

import static org.junit.Assert.assertNotNull;

/**
 * Test Class to WSAA Client
 *
 * Created by SHELG on 10/21/2014.
 */
public class WsaaWs_UT {

    @Test
    public void test_TicketResponse() throws WsaaException {

        WsaaImpl wsaa = new WsaaImpl();

        wsaa.setSrv("wslpg");
        wsaa.setEndPoint("https://wsaahomo.afip.gov.ar/ws/services/LoginCms");
        wsaa.setDstDn("cn=wsaahomo,o=afip,c=ar,serialNumber=CUIT 33693450239");
        wsaa.setKeyStore("Monsanto.p12");
        wsaa.setKeyStoreSigner("Monsanto");
        wsaa.setKeyStorePassword("Mon123$");
        wsaa.setOffsetTime("1200");
        wsaa.setTicketTime("3600000");

        wsaa.setAfipClient(new AfipWsaaClient());

        String service = "wslpg";
        String uniqueId = "";

        LoginTicketRsp resp = wsaa.loginTicket(service, uniqueId);

        assertNotNull(resp);
    }


    @Test(expected = com.monsanto.ws.exception.WsaaException.class)
    public void test_TicketResponse_exc() throws WsaaException {

        Wsaa wsaa = new WsaaImpl();

        String service = "wsfex";
        String uniqueId = "555";

        wsaa.loginTicket(service, uniqueId);
    }
}