package com.monsanto.ws;

import static org.junit.Assert.*;
import org.junit.Test;

import java.util.logging.Logger;

/**
 * Test Class to WSAA Client
 *
 * Created by SHELG on 10/21/2014.
 */
public class PingWs_UT {

    private static final Logger log = Logger.getLogger(PingWs_UT.class.toString());

    @Test
    public void test_Ping(){

        Ping ping = new PingImpl();
        String str = ping.ping();
        assertNotNull(str);
        log.info(str);
        assertTrue(str.contains("Ping back @"));
    }
}