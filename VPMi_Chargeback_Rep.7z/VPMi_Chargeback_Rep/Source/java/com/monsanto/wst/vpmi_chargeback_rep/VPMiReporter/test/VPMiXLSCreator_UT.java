/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.vpmi_chargeback_rep.VPMiReporter.test;

import com.monsanto.wst.vpmi_chargeback_rep.VPMiChargebackData.CCReport;
import com.monsanto.wst.vpmi_chargeback_rep.VPMiChargebackData.Chargeback;
import com.monsanto.wst.vpmi_chargeback_rep.VPMiChargebackData.Month;
import com.monsanto.wst.vpmi_chargeback_rep.VPMiChargebackData.MonthReport;
import com.monsanto.wst.vpmi_chargeback_rep.VPMiReporter.VPMiXLSCreator;
import junit.framework.TestCase;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

import java.io.File;

/**
 * Filename:    $RCSfile: VPMiXLSCreator_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: zznels $    	 On:	$Date: 2007-11-13 14:41:10 $
 *
 * @author zznels
 * @version $Revision: 1.5 $
 */
public class VPMiXLSCreator_UT extends TestCase {
  private VPMiXLSCreator testCreator;
  private static final int TEST_YEAR = 2007;
  private static final String TEST_COST_CENTER = "1-2-3-456";

  public void setUp() throws Exception {
    super.setUp();
    testCreator = new VPMiXLSCreator();
  }

  public void testCellStylePassedIsUsedInReport() throws Exception {
    MockVPMiReportCellStyle mockCellStyle = new MockVPMiReportCellStyle();
    VPMiXLSCreator creator = new VPMiXLSCreator(mockCellStyle);

    creator.createReport(new CCReport(TEST_COST_CENTER), "./com/monsanto/wst/vpmi_chargeback_rep/VPMiReporter/test/testOutput.xls");

    assertTrue(mockCellStyle.isStyleUsed());

    File testFile = new File("./com/monsanto/wst/vpmi_chargeback_rep/VPMiReporter/test/testOutput.xls");
    assertTrue(testFile.exists());
    testFile.delete(); //todo: refuses to delete
  }

  public void testCellStylePassedIsUsedInMonthReport() throws Exception {
    MockVPMiReportCellStyle mockCellStyle = new MockVPMiReportCellStyle();
    VPMiXLSCreator creator = new VPMiXLSCreator(mockCellStyle);

    creator.createMonthReport(new MonthReport(Month.Jan), mockCellStyle.getNewWorkbook().createSheet(), 0);

    assertTrue(mockCellStyle.isStyleUsed());
  }

  public void testcreateReport_MonthReportSheetNotNull() throws Exception {
    MonthReport testReport = new MonthReport(Month.Jan);
    testReport.add(new Chargeback(TEST_COST_CENTER,"Desc",123.45,Month.Jan, TEST_YEAR));
    HSSFWorkbook workbook = new HSSFWorkbook();
    HSSFSheet sheet = workbook.createSheet();

    testCreator.createMonthReport(testReport, sheet, 0);

    assertNotNull(sheet);
    assertEquals("Jan", sheet.getRow(0).getCell((short)0).getStringCellValue());
  }

  public void testcreateReport_CCReportSheetNotNull() throws Exception {
    HSSFWorkbook workbook = new HSSFWorkbook();
    HSSFSheet sheet = workbook.createSheet();

    CCReport testReport = new CCReport(TEST_COST_CENTER);
    testReport.addCharge(new Chargeback(TEST_COST_CENTER,"Desc",1234.45,Month.Jan, TEST_YEAR));
    testReport.addCharge(new Chargeback(TEST_COST_CENTER,"Desc2",123.45,Month.Jan, TEST_YEAR));
    testReport.addCharge(new Chargeback(TEST_COST_CENTER,"Desc",123.45,Month.Feb, TEST_YEAR));
    testReport.addCharge(new Chargeback(TEST_COST_CENTER,"Desc2",1234.45,Month.Feb, TEST_YEAR));
    testReport.addCharge(new Chargeback(TEST_COST_CENTER,"Desc",123.45,Month.Mar, TEST_YEAR));
    testCreator.createCCReport(testReport, sheet, 0);

    assertNotNull(sheet);
  }

  public void testcreateReport_CCReportFileExists() throws Exception {
    CCReport testReport = new CCReport(TEST_COST_CENTER);
    testReport.addCharge(new Chargeback(TEST_COST_CENTER,"Desc",1234.45,Month.Jan, TEST_YEAR));
    testReport.addCharge(new Chargeback(TEST_COST_CENTER,"Desc2",123.45,Month.Jan, TEST_YEAR));
    testReport.addCharge(new Chargeback(TEST_COST_CENTER,"Desc",123.45,Month.Feb, TEST_YEAR));
    testReport.addCharge(new Chargeback(TEST_COST_CENTER,"Desc2",1234.45,Month.Feb, TEST_YEAR));
    testReport.addCharge(new Chargeback(TEST_COST_CENTER,"Desc",123.45,Month.Mar, TEST_YEAR));

    testCreator.createReport(testReport, "./com/monsanto/wst/vpmi_chargeback_rep/VPMiReporter/test/testOutput.xls");

    File testFile = new File("./com/monsanto/wst/vpmi_chargeback_rep/VPMiReporter/test/testOutput.xls");
    assertTrue(testFile.exists());
    testFile.deleteOnExit(); //todo: refuses to delete
  }


}