package com.monsanto.wst.vpmi_chargeback_rep.servlet;


import com.monsanto.AbstractLogging.Logger;
import com.monsanto.Util.databasepasswordencryption.EncryptionUtils;
import com.monsanto.Util.EnvironmentHelper;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStore;
import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.dbdataservices.PersistentStoreOracleCachedType2;

import java.util.ResourceBundle;

/**
 *
 * <p>Title: VPMi_Chargeback_RepPersistentStoreFactory</p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Monsanto</p>
 * @author Java Framework Code Generator 3.0
 * @version $Id: VPMi_Chargeback_RepPersistentStoreFactory.java,v 1.2 2007-07-19 18:10:21 zznels Exp $
 */
public class VPMi_Chargeback_RepPersistentStoreFactory
{
   public static final String DEFAULT_BUNDLE        = "com.monsanto.wst.vpmi_chargeback_rep.servlet.VPMi_Chargeback_Rep";
   public static final String PERSISTENT_STORE_NAME = "VPMi_Chargeback_Rep";

  /**
       * Returns a Persistent Store.
       *
       * @param cstrResourceBundleName The name of the resource bundle that points
       *                               to the correct database.
       * @return A PersistentStore object.
       * @throws WrappingException
       */
      public static PersistentStore getStore(String cstrResourceBundleName) throws WrappingException {
         Logger.traceEntry();

         ResourceBundle bundle = ResourceBundle.getBundle(cstrResourceBundleName);
         PersistentStore RetVal = getPersistentStore(bundle);

         return (PersistentStore) Logger.traceExit(RetVal);
      }


      public static PersistentStoreConnection getDefaultConnection() throws WrappingException {
         final PersistentStore store = getStore(DEFAULT_BUNDLE);
         PersistentStore.registerInstance(VPMi_Chargeback_RepPersistentStoreFactory.PERSISTENT_STORE_NAME, store);

         return PersistentStore.instance(VPMi_Chargeback_RepPersistentStoreFactory.PERSISTENT_STORE_NAME).connect();
      }

      private static PersistentStore getPersistentStore(ResourceBundle bundle) throws WrappingException {
         String userName     = null;
         String sequenceName = null;
         String dataSource   = null;
         String password     = null;

         String storageEnvVariable = "MONCRYPTJV";

	//Todo: fix the three strings based on your project and remove the syntax error line
	//ToDo: & fix VPMi_Chargeback_Rep.properties file

//	__This_line_causes_an_error___So_that_you_look_here__You_need_to_read_the_above_message_prior_to_removing_this_line__

         String appFolderName      = "Needs to be set for project - application folder name";
         String encryptedFileName  = "Needs to be set for project - encrypted password file name";
         String keyFileName        = "Needs to be set for project - key file name";

         /*
            Example section from ResourceBundle

            dev.UserName=XXXXXXXX
            dev.DataSource=Devl
            dev.SequenceName=shared_code.SHARED_ID_SEQ
            dev.MinConnections=1
            dev.MaxConnections=3
            dev.Increment=1
         */
         try {
            userName     = bundle.getString(EnvironmentHelper.getPropertyPrefix() + "UserName");
            sequenceName = bundle.getString(EnvironmentHelper.getPropertyPrefix() + "SequenceName");
            dataSource   = bundle.getString(EnvironmentHelper.getPropertyPrefix() + "DataSource");

            password = EncryptionUtils.GetDecryptedStringFromExternalStorage(storageEnvVariable,
                                                                             appFolderName,
                                                                             encryptedFileName,
                                                                             keyFileName);
         } catch (Exception e) {
            throw new WrappingException(e);
         }

         return new PersistentStoreOracleCachedType2(userName, password, dataSource, sequenceName);
      }

  }