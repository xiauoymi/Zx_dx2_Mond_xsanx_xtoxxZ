/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.vpmi_chargeback_rep.VPMiChargebackData.test;

import junit.framework.TestCase;
import com.monsanto.wst.vpmi_chargeback_rep.VPMiChargebackData.Chargeback;
import com.monsanto.wst.vpmi_chargeback_rep.VPMiChargebackData.Month;

import java.security.InvalidParameterException;

/**
 * Filename:    $RCSfile: Chargeback_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: zznels $    	 On:	$Date: 2007-12-13 22:53:03 $
 *
 * @author zznels
 * @version $Revision: 1.3 $
 */
public class Chargeback_UT extends TestCase {

  public void testConstructorThrowsExceptionWithInvalidCCFormat() throws Exception {
    try{
      new Chargeback("Invalid", "testDesc", 123.23, Month.Jan, 2007);
      fail("Should throw invalid parameter exception");
    } catch (InvalidParameterException ex){
      //expected path
    }
  }

  public void testGetFullCostCenterFormatsCorrectly() throws Exception {
    Chargeback testCharge = new Chargeback();
    testCharge.setCO_Code("1");
    testCharge.setBA("2");
    testCharge.setACCT("3");
    testCharge.setCost_Center("4");
    assertEquals("1-2-3-4", testCharge.getFullCostCenter());
  }

  public void testGetFullCostCenterUsesWBSIfNoCostCenter() throws Exception {
    Chargeback testCharge = new Chargeback();
    testCharge.setCO_Code("1");
    testCharge.setBA("2");
    testCharge.setACCT("3");
    testCharge.setWBS("WBS");
    assertEquals("1-2-3-WBS", testCharge.getFullCostCenter());
  }

  public void testGetFullCostCenterFormatsCorrectlyNoParams() throws Exception {
    Chargeback testCharge = new Chargeback();
    assertNull(testCharge.getFullCostCenter());
  }

  public void testToStringFormatsCorrectly() throws Exception {
    Chargeback testCharge = new Chargeback();
    testCharge.setDesc("Desc");
    testCharge.setAmount(123.45);
    assertEquals("Desc 123.45", testCharge.toString());
  }

  public void testToStringNoParamsReturnsNull() throws Exception {
    Chargeback testCharge = new Chargeback();
    assertNull(testCharge.toString());
  }

}