/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.vpmi_chargeback_rep.controller;

import com.monsanto.AbstractLogging.LoggableError;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.Util.validation.ParameterValidation;
import com.monsanto.wst.dbtemplate.dao.DBTemplateDaoException;
import com.monsanto.wst.vpmi_chargeback_rep.VPMiChargebackData.*;
import com.monsanto.wst.vpmi_chargeback_rep.VPMiReporter.VPMiReportReader;
import com.monsanto.wst.vpmi_chargeback_rep.VPMiReporter.VPMiReportReaderImpl;
import com.monsanto.wst.vpmi_chargeback_rep.VPMiReporter.VPMiXLSCreator;
import com.monsanto.wst.vpmi_chargeback_rep.dao.ChargebackDAO;
import com.monsanto.wst.vpmi_chargeback_rep.emailer.VPMiReportEmailObject;
import com.monsanto.wst.vpmi_chargeback_rep.emailer.VPMiReportEmailer;
import com.monsanto.wst.vpmi_chargeback_rep.emailer.VPMiReportMessageTemplateFactory;
import com.monsanto.wst.vpmi_chargeback_rep.userInterface.ParameterSource;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Filename:    $RCSfile: VPMiChargebackRepController.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: zznels $    	 On:	$Date: 2007-12-18 15:58:55 $
 *
 * @author zznels
 * @version $Revision: 1.5 $
 */
public class VPMiChargebackRepController implements VPMiController {


  public void run(ParameterSource source){
    ParameterValidation.objectNotNull(source, "ParameterSource");

    try{
      List<Chargeback> chargebacks = readInputFile(source.getInputFile(), source.getReportMonth(), source.getReportYear());

      insertChargesIntoDB(chargebacks);

      createAndEmailReports(chargebacks, new VPMiReportEmailer(new VPMiReportMessageTemplateFactory()));

    } catch(Exception e){
      Logger.log(new LoggableError("An Error Occured:\n"));
      e.printStackTrace();
      Logger.log(new LoggableError("Processing Incomplete\n"));
    }
  }

  public void createAndEmailReports(List<Chargeback> chargebacks, VPMiReportEmailer emailService) {
    ChargebackDAO dao = createChargebackDAO();

    String tmpDir = System.getProperty("java.io.tmpdir");

    Logger.log(new LoggableError("Generating Chargeback Reports...\n"));
    List<CCReport> reports = new CCReportBuilder().parse(chargebacks);

    Logger.log(new LoggableError("Emailing Reports To Owners...\n"));
    for(CCReport report: reports){
      //Note: This loop currently only processes the first MonthReport contained in each CCReport
      List<CCOwner> owners = dao.getOwners(report.getCost_Center());
      if(!owners.isEmpty()){
        try {
          File reportFile = createOneReport(tmpDir, report);

          VPMiReportEmailObject emailObject = createEmailObject(report);

          for(CCOwner owner: owners){
            emailObject.setOwner(owner);
            emailReportToOwner(emailObject, reportFile, emailService);
          }

        } catch (IOException ex) {
          Logger.log(new LoggableError("ERROR: "+ex.getMessage()));
          throw new RuntimeException(ex);
        }
      }
    }
  }

  public VPMiReportEmailObject createEmailObject(CCReport report) {
    VPMiReportEmailObject emailObject = new VPMiReportEmailObject();
    emailObject.setMonthRep(report.getMonthReports().get(0));
    return emailObject;
  }

  public File createOneReport(String tmpDir, CCReport report) throws IOException {
    String reportFileName = tmpDir + report.getCost_Center() + report.getMonthReports().get(0).getMonth() + ".xls";
    VPMiXLSCreator creator = new VPMiXLSCreator();
    creator.createReport(report, reportFileName);
    return new File(reportFileName);
  }

  public void emailReportToOwner(VPMiReportEmailObject emailObject, File reportFile,
                                 VPMiReportEmailer emailService) throws
    FileNotFoundException {

    sendReportEmail(emailObject, reportFile, emailService);
    reportFile.deleteOnExit();
  }

  private void sendReportEmail(VPMiReportEmailObject emailObject, File report, VPMiReportEmailer emailService) throws FileNotFoundException {

    emailService.sendMessage(emailObject.getOwner(), emailObject.getMonthRep().getMonth(), report);
  }

  private void insertChargesIntoDB(List<Chargeback> chargebacks) throws Exception {
    ChargebackDAO dao = createChargebackDAO();

    try{
      Logger.log(new LoggableError("Inserting Chargebacks Into Database...\n"));
      for(Chargeback charge: chargebacks){
        dao.insertChargeback(charge);
      }
    } catch (DBTemplateDaoException ex){
      Logger.log(new LoggableError("ERROR: Encountered Error While Inserting Data Into Database\n" +
          "This report may have been entered already\n"));
      throw new RuntimeException(ex);
    }
  }

  protected ChargebackDAO createChargebackDAO() {
    return new ChargebackDAO();
  }

  public List<Chargeback> readInputFile(File inputFile, Month reportMonth, int reportYear) throws IOException {
    List<Chargeback> chargebacks = new ArrayList<Chargeback>();

    try{
      VPMiReportReader reader = new VPMiReportReaderImpl();
      Logger.log(new LoggableError("Reading File...\n"));
      chargebacks = reader.readReport(inputFile);
      Logger.log(new LoggableError("FileReader Complete\n"));
      DateAssigner.assign(chargebacks, reportMonth, reportYear);
    } catch (IOException ex) {
      Logger.log(new LoggableError("ERROR: Could Not Read Input File\n"));
      throw ex;
    }
    return chargebacks;
  }
}