/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.vpmi_chargeback_rep.userInterface.test;

import com.monsanto.AbstractLogging.Logger;
import com.monsanto.AbstractLogging.Test.MockErrorLog;
import com.monsanto.Util.Exceptions.NullParameterException;
import com.monsanto.wst.vpmi_chargeback_rep.logging.CommandLineLog;
import com.monsanto.wst.vpmi_chargeback_rep.userInterface.CommandLineUIStrategyImpl;
import com.monsanto.wst.vpmi_chargeback_rep.controller.VPMiController;
import com.monsanto.wst.vpmi_chargeback_rep.controller.test.MockController;
import junit.framework.TestCase;

/**
 * Filename:    $RCSfile: CommandlineUIStrategyImpl_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: zznels $    	 On:	$Date: 2007-11-13 14:41:10 $
 *
 * @author zznels
 * @version $Revision: 1.3 $
 */
public class CommandlineUIStrategyImpl_UT extends TestCase {
  private VPMiController controller;


  protected void setUp() throws Exception {
    super.setUp();
    controller = new MockController();
  }

  public void testConstructorDoesNotAcceptNullParams() throws Exception {
    try{
      new CommandLineUIStrategyImpl(null, controller);
      fail("Should Throw Null Parameter Exception");
    } catch (NullParameterException ex){
      //expected path
    }

    try{
      new CommandLineUIStrategyImpl(new MockParameterSource(), null, controller);
      fail("Should Throw Null Parameter Exception");
    } catch (NullParameterException ex){
      //expected path
    }

  }

  public void testRegistersLogGivenInAbstractLogger() throws Exception {
    MockErrorLog logger = new MockErrorLog();
    new CommandLineUIStrategyImpl(new MockParameterSource(), logger, controller);

    assertTrue(Logger.isRegistered("Error"));
  }

  public void testRegistersCommandLineLogWhenNoLogGiven() throws Exception {
    new CommandLineUIStrategyImpl(new MockParameterSource(), controller);

    assertTrue(Logger.isRegistered(new CommandLineLog().type()));
  }

  public void testLoggerWrittenToIfInvalidParams() throws Exception {
    MockErrorLog log = new MockErrorLog();
    CommandLineUIStrategyImpl stratImpl = new CommandLineUIStrategyImpl(new MockParameterSource(), log, controller);

    stratImpl.process();

    assertTrue(log.hasMessageBeenLoggedContaining("Test Error Message"));
  }


}