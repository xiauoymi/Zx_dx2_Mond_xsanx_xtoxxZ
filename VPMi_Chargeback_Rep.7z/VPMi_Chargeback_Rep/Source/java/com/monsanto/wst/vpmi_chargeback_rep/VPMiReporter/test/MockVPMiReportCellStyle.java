/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.vpmi_chargeback_rep.VPMiReporter.test;

import com.monsanto.wst.vpmi_chargeback_rep.VPMiReporter.VPMiReportCellStyle;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

/**
 * Filename:    $RCSfile: MockVPMiReportCellStyle.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: zznels $    	 On:	$Date: 2007-11-13 14:41:10 $
 *
 * @author zznels
 * @version $Revision: 1.1 $
 */
public class MockVPMiReportCellStyle implements VPMiReportCellStyle {

  private boolean styleUsed = false;

  public HSSFCellStyle getStyle(String styleName) {
    styleUsed = true;
    return new HSSFWorkbook().createCellStyle();
  }

  public HSSFWorkbook getNewWorkbook() {
    return new HSSFWorkbook();
  }

  public boolean isStyleUsed() {
    return styleUsed;
  }
}