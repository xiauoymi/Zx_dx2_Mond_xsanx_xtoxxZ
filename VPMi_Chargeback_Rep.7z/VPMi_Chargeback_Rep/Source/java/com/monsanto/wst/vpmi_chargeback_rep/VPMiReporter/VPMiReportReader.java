/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.vpmi_chargeback_rep.VPMiReporter;

import com.monsanto.wst.vpmi_chargeback_rep.VPMiChargebackData.Chargeback;

import java.io.File;
import java.io.IOException;
import java.util.List;

/**
 * Filename:    $RCSfile: VPMiReportReader.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: zznels $    	 On:	$Date: 2007-09-27 14:58:30 $
 *
 * @author zznels
 * @version $Revision: 1.1 $
 */
public interface VPMiReportReader {
  List<Chargeback> readReport(File report) throws IOException;
}