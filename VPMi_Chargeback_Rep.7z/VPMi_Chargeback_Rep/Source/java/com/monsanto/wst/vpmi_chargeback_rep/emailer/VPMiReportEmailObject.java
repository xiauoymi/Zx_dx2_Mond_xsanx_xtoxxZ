/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.vpmi_chargeback_rep.emailer;

import com.monsanto.wst.vpmi_chargeback_rep.VPMiChargebackData.CCOwner;
import com.monsanto.wst.vpmi_chargeback_rep.VPMiChargebackData.MonthReport;
import com.monsanto.wst.vpmi_chargeback_rep.VPMiChargebackData.Month;

/**
 * Filename:    $RCSfile: VPMiReportEmailObject.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: zznels $    	 On:	$Date: 2007-10-12 20:12:40 $
*
* @author zznels
* @version $Revision: 1.1 $
* @description: This class is used in the VPMiReportEmailer to hold information used in the form letter
*/
public class VPMiReportEmailObject {
  public CCOwner owner = new CCOwner();
  public MonthReport monthRep = new MonthReport(Month.Jan);

  public CCOwner getOwner() {
    return owner;
  }

  public void setOwner(CCOwner owner) {
    this.owner = owner;
  }

  public MonthReport getMonthRep() {
    return monthRep;
  }

  public void setMonthRep(MonthReport monthRep) {
    this.monthRep = monthRep;
  }
}