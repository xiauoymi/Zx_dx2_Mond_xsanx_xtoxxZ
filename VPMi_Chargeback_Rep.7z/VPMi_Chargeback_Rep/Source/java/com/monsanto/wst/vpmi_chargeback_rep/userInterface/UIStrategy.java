/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.vpmi_chargeback_rep.userInterface;

import com.monsanto.AbstractLogging.Logger;
import com.monsanto.AbstractLogging.FatalEvent;
import com.monsanto.AbstractLogging.LoggableError;
import com.monsanto.wst.vpmi_chargeback_rep.controller.VPMiController;

/**
 * Filename:    $RCSfile: UIStrategy.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: zznels $    	 On:	$Date: 2007-12-13 22:53:02 $
 *
 * @author zznels
 * @version $Revision: 1.4 $
 */
public abstract class UIStrategy {
  protected ParameterSource parameters;
  private VPMiController controller;

  public UIStrategy(ParameterSource argv, VPMiController controller) {
    parameters = argv;
    this.controller = controller;
  }

  public void process() {
    if(parameters.isValid()){
      controller.run(parameters);
      Logger.log(new LoggableError("Program Complete\n"));
    } else {
      Logger.log(new FatalEvent(parameters.getErrorMessage()));
    }
  }
}