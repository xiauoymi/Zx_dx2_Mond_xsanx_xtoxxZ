/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.vpmi_chargeback_rep.userInterface;

import com.monsanto.AbstractLogging.LogRegistrationException;
import com.monsanto.AbstractLogging.LoggableError;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.wst.vpmi_chargeback_rep.controller.VPMiController;
import com.monsanto.wst.vpmi_chargeback_rep.logging.VPMiSwingLog;

/**
 * Filename:    $RCSfile: UIStrategyImplFactory.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: zznels $
 * On:	$Date: 2007-12-13 22:53:02 $
 *
 * @author zznels
 * @version $Revision: 1.6 $
 */
public class UIStrategyImplFactory {
  private VPMiController controller;
  private VPMiSwingDialog dialog;


  public UIStrategyImplFactory(VPMiController controller) {
    this(controller, new SwingParameterDialog());
  }

  public UIStrategyImplFactory(VPMiController controller, VPMiSwingDialog dialog){
    this.controller = controller;
    this.dialog = dialog;
  }

  public UIStrategy getStrategyImplementation(String[] argv) throws LogRegistrationException {
    if (argv == null || argv.length == 0) {
      dialog.showDialog();
      dialog.waitForClose();

      Logger.log(new LoggableError("Parameters Received"));

      if(dialog.wasCancelled()){
        return null;
      }

      VPMiSwingLog log = new VPMiSwingLog(dialog);
      return createSwingUIStrategyImpl(new SwingParameterSource(dialog), log, controller);
    } else {
      return new CommandLineUIStrategyImpl(new CommandLineParameterSource(argv), controller);
    }
  }

  protected SwingUIStrategyImpl createSwingUIStrategyImpl(SwingParameterSource source, VPMiSwingLog log,
                                                          VPMiController controller) throws LogRegistrationException {
    return new SwingUIStrategyImpl(source, log, controller);
  }
}