/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.vpmi_chargeback_rep.VPMiChargebackData.test;

import junit.framework.TestCase;
import com.monsanto.wst.vpmi_chargeback_rep.VPMiChargebackData.CCReport;
import com.monsanto.wst.vpmi_chargeback_rep.VPMiChargebackData.Chargeback;
import com.monsanto.wst.vpmi_chargeback_rep.VPMiChargebackData.Month;

/**
 * Filename:    $RCSfile: CCReport_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: zznels $    	 On:	$Date: 2007-09-25 20:31:35 $
 *
 * @author zznels
 * @version $Revision: 1.2 $
 */
public class CCReport_UT extends TestCase {
  
  public void testaddCharge_addOneCharge() throws Exception {
    CCReport testRep = new CCReport("1-2-3-4");
    testRep.addCharge(new Chargeback("1-2-3-4","Desc",123.45, Month.Jan, 2007));
    assertEquals(1,testRep.getNumMonths());
  }

  public void testaddCharge_addMultipleCharges() throws Exception {
    CCReport testRep = new CCReport("1-2-3-4");
    testRep.addCharge(new Chargeback("1-2-3-4","Desc",123.45, Month.Jan, 2007));
    testRep.addCharge(new Chargeback("1-2-3-4","Desc",123.45, Month.Mar, 2007));
    testRep.addCharge(new Chargeback("1-2-3-4","Desc",123.45, Month.Feb, 2007));
    testRep.addCharge(new Chargeback("1-2-3-4","Desc2",123.45, Month.Jan, 2007));
    assertEquals(3,testRep.getNumMonths());
  }

  public void testaddCharge_DontAddDiffCostCenter() throws Exception {
    CCReport testRep = new CCReport("1-2-3-4");
    assertFalse(testRep.addCharge(new Chargeback("1-2-3-5","Desc",123.45,Month.Jan, 2007)));
  }

}