/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.vpmi_chargeback_rep.dao;

import com.monsanto.wst.dbtemplate.DBTemplateImpl;
import com.monsanto.wst.dbtemplate.transaction.TransactionManager;

/**
 * Filename:    $RCSfile: ChargebackDAOTemplate.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: zznels $    	 On:	$Date: 2007-10-15 19:36:08 $
 *
 * @author zznels
 * @version $Revision: 1.2 $
 */
public class ChargebackDAOTemplate extends DBTemplateImpl {
  private static final String CONFIG = "com/monsanto/wst/vpmi_chargeback_rep/dao/ChargebackDBConfig.xml";
  private static final String[] MAPPINGS = {"com/monsanto/wst/vpmi_chargeback_rep/dao/ChargebackDBQueryMapping.xml"};

  public ChargebackDAOTemplate() {
    super(CONFIG, MAPPINGS);
  }

  public ChargebackDAOTemplate(TransactionManager txManager) {
    super(txManager, MAPPINGS);   
  }
}