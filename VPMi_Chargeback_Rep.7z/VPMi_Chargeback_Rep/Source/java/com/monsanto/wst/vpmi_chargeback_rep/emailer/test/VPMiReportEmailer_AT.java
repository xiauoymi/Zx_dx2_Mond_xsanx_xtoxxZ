/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.vpmi_chargeback_rep.emailer.test;

import com.monsanto.JavaMail.JavaMailMailSystem;
import com.monsanto.JavaMail.Test.JavaMailTestUtilities;
import com.monsanto.Mail.*;
import com.monsanto.wst.commonutils.xml.XalanXPathUtils;
import com.monsanto.wst.vpmi_chargeback_rep.VPMiChargebackData.CCOwner;
import com.monsanto.wst.vpmi_chargeback_rep.VPMiChargebackData.Month;
import com.monsanto.wst.vpmi_chargeback_rep.emailer.VPMiReportEmailer;
import com.monsanto.wst.vpmi_chargeback_rep.emailer.VPMiReportMessageTemplateFactory;
import junit.framework.TestCase;

import javax.xml.transform.TransformerException;
import java.io.File;

/**
 * Filename:    $RCSfile: VPMiReportEmailer_AT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: zznels $    	 On:	$Date: 2007-11-13 14:41:10 $
 *
 * @author zznels
 * @version $Revision: 1.3 $
 */
public class VPMiReportEmailer_AT extends TestCase {
  private JavaMailTestUtilities javaMailTestUtilities;
  private JavaMailMailSystem jmms;
  private VPMiReportEmailer emailService;

  //Thanks Nate
  private static final String TO_EMAIL_ADDRESS = "nathan@WOODSTORK.NA.DS.MONSANTO.COM";
  private File EMAILER_TEST_FILE;
  private String cstrInboxFolder = "Inbox";

  protected void setUp() throws Exception {
    super.setUp();
    emailService = new VPMiReportEmailer(new VPMiReportMessageTemplateFactory());
    EMAILER_TEST_FILE = new File("C:/projects/VPMi_Chargeback_rep/source/java/com/monsanto/wst/vpmi_chargeback_rep/emailer/test/testReport.xls");
    this.javaMailTestUtilities = new JavaMailTestUtilities();
    this.jmms = javaMailTestUtilities.createJavaMailMailSystem("/com/monsanto/wst/vpmi_chargeback_rep/emailer/test/mail.properties");
  }

  public void testSendMessage() throws Exception {
    try {
      MailFolder inboxFolder = jmms.getFolderByName(cstrInboxFolder);

      CCOwner owner = new CCOwner();
      owner.setEmail(TO_EMAIL_ADDRESS);
      owner.setName("TestName");

      assertTrue(EMAILER_TEST_FILE.exists());

      emailService.sendMessage(owner, Month.Jan,  EMAILER_TEST_FILE);
      javaMailTestUtilities.sleepFor(10);

      verifyEmailWasReceivedAndDelete(inboxFolder); //assert

      inboxFolder.close();
    } finally {
      closeJMMS();
    }
  }

  private void closeJMMS() {
    if (jmms != null) {
      boolean leaveLoop = false;
      int count = 0;
      while (!leaveLoop && count < 5) {
        try {
          jmms.close();
          jmms = null;
          leaveLoop = true;
        } catch (java.util.ConcurrentModificationException e) {
          count++;
          javaMailTestUtilities.sleepFor(1);
        }
      }
    }
  }

  private void verifyEmailWasReceivedAndDelete(MailFolder folder) throws MailAccessException, TransformerException {
    MailDocumentIterator inboxIterator = folder.getDocIterByDate();
    boolean wasFound = false;
    while (inboxIterator.hasNext()) {
      MailDocument tempDoc = inboxIterator.next();
      tempDoc.setAttachmentSavePath("user.dir");
      XalanXPathUtils xpathUtils = new XalanXPathUtils();
      String subject = null;
      try {
        subject = xpathUtils.evalToString(tempDoc.toXML(), "//SUBJECT");
      } catch (MessageParseException e) {
        e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
      }
      if (VPMiReportEmailer.SUBJECT.equalsIgnoreCase(subject)) {
        wasFound = true;
        inboxIterator.removeAndDelete();
      }
    }
    assertTrue(wasFound);
  }

}