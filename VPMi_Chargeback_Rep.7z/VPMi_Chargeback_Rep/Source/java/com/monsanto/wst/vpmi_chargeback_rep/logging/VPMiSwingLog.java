/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.vpmi_chargeback_rep.logging;

import com.monsanto.AbstractLogging.IErrorLog;
import com.monsanto.wst.vpmi_chargeback_rep.userInterface.VPMiSwingDialog;

/**
 * Filename:    $RCSfile: VPMiSwingLog.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: zznels $    	 On:	$Date: 2007-11-28 22:11:52 $
 *
 * @author zznels
 * @version $Revision: 1.3 $
 */
public class VPMiSwingLog implements IErrorLog {
  private VPMiSwingDialog dialog;

  public VPMiSwingLog(VPMiSwingDialog dialog) {
    this.dialog = dialog;
  }

  public void removeLogDevices() {
  }

  public String name() {
    return "SwingLog";
  }

  public String type() {
    return "Error";
  }

  public int numLogDevices() {
    return 0;
  }

  public String getLogDeviceType(int j) {
    return null;
  }

  public String getLogDeviceLocation(int j) {
    return null;
  }

  public void log(String cstrMessage) {
    dialog.addLogMessage(cstrMessage);
  }

  public void close() {
  }

}