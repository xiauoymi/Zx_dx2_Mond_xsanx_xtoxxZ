/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.vpmi_chargeback_rep.userInterface;

import com.monsanto.wst.vpmi_chargeback_rep.VPMiChargebackData.Month;
import com.monsanto.Util.validation.ParameterValidation;

import java.io.File;

/**
 * Filename:    $RCSfile: SwingParameterSource.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: zznels $    	 On:	$Date: 2007-12-04 22:41:22 $
*
* @author zznels
* @version $Revision: 1.6 $
*/
public class SwingParameterSource extends ParameterSource {
  private VPMiSwingDialog dialog;

  private boolean dialogShown;

  private static final String INVALID_FILE_ERR = "Invalid File Entered";
  private static final String INVALID_MONTH_ERR = "Invalid Month Entered";
  private boolean invFileFlag = false;
  private boolean invMonthFlag = false;

  public SwingParameterSource(VPMiSwingDialog dialog) {
    ParameterValidation.objectNotNull(dialog, "dialog");

    this.dialog = dialog;
    dialogShown = false;
  }

  private void showDialogIfNotShownYet() {
    if (!dialogShown) {
      dialogShown = true;
      dialog.showDialog();
    }
  }

  public boolean isValid() {
    return !getDialog().wasCancelled() && super.isValid();
  }

  public File getInputFile() {
    File inputFile = getDialog().getInputFile();
    if (inputFile == null || !inputFile.exists()) {
      invFileFlag = true;
      return null;
    } else {
      return getDialog().getInputFile();
    }
  }

  public Month getReportMonth() {
    if(getDialog().getMonth()==null){
      invMonthFlag = true;
      return null;
    }
    return getDialog().getMonth();
  }

  public int getReportYear() {
    return getDialog().getYear();
  }

  public String getErrorMessage() {
    String message = "";
    if(invFileFlag){
      message = INVALID_FILE_ERR;
    }
    if(invMonthFlag){
      message += INVALID_MONTH_ERR;
    }
    return message;
  }

  private VPMiSwingDialog getDialog() {
    return dialog;
  }
}