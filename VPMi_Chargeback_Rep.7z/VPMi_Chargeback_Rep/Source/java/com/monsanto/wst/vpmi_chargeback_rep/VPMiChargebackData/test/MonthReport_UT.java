/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.vpmi_chargeback_rep.VPMiChargebackData.test;

import junit.framework.TestCase;
import com.monsanto.wst.vpmi_chargeback_rep.VPMiChargebackData.MonthReport;
import com.monsanto.wst.vpmi_chargeback_rep.VPMiChargebackData.Chargeback;
import com.monsanto.wst.vpmi_chargeback_rep.VPMiChargebackData.Month;

/**
 * Filename:    $RCSfile: MonthReport_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: zznels $    	 On:	$Date: 2007-10-15 21:40:22 $
 *
 * @author zznels
 * @version $Revision: 1.3 $
 */
public class MonthReport_UT extends TestCase {
  
  public void testadd_ReturnFalseOnAddingDiffMonth() throws Exception {
    MonthReport testReport = new MonthReport(Month.Jan);
    assertFalse(testReport.add(new Chargeback("1-2-3-4", "desc", 1, Month.Feb, 2007)));
  }

  public void test_ReturnFalseOnAddingDiffYear() throws Exception {
    MonthReport testReport = new MonthReport(Month.Jan);
    testReport.add(new Chargeback("1-2-3-4", "desc", 1, Month.Jan, 2007));

    assertFalse(testReport.add(new Chargeback("1-2-3-4", "desc", 1, Month.Jan, 2005)));
  }

  public void test_ReturnFalseOnAddingDiffCostCenter() throws Exception {
    MonthReport testReport = new MonthReport(Month.Jan);
    testReport.add(new Chargeback("1-2-3-4", "desc", 1, Month.Jan, 2007));

    assertFalse(testReport.add(new Chargeback("1-2-3-5", "desc", 1, Month.Jan, 2007)));
  }

  public void testadd_ReturnTrueIfAdded() throws Exception {
    MonthReport testReport = new MonthReport(Month.Jan);
    assertTrue(testReport.add(new Chargeback("1-2-3-4", "Desc", 123.45, Month.Jan, 2007)));
  }

  public void testtoString_NotNull() throws Exception {
    MonthReport testReport = new MonthReport(Month.Jan);
    testReport.add(new Chargeback("1-2-3-4", "Desc", 123.45, Month.Jan, 2007));
    testReport.add(new Chargeback("1-2-3-4", "Desc2", 123.45, Month.Jan, 2007));
    String testResult = testReport.toString();
    assertNotNull(testResult);
    assertEquals("Jan 2007\n" +
                 "Desc 123.45\n" +
                 "Desc2 123.45\n" +
                 "Total: 246.9", testResult);
  }

}