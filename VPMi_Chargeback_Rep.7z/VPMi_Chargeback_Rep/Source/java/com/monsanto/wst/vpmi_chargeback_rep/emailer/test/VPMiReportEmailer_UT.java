/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.vpmi_chargeback_rep.emailer.test;

import com.monsanto.wst.commonutils.template.MessageTemplate;
import com.monsanto.wst.emailtemplate.domain.EmailHeaderInfo;
import com.monsanto.wst.emailtemplate.facade.MessageTemplateFactory;
import com.monsanto.wst.emailtemplate.services.test.MonsantoEmailService_UT;
import com.monsanto.wst.emailtemplate.transport.AbstractEmailTransporterFactory;
import com.monsanto.wst.vpmi_chargeback_rep.emailer.VPMiReportEmailer;
import com.monsanto.wst.vpmi_chargeback_rep.VPMiChargebackData.CCOwner;
import com.monsanto.wst.vpmi_chargeback_rep.VPMiChargebackData.Month;
import com.monsanto.Util.Exceptions.NullParameterException;
import junit.framework.TestCase;

import java.io.File;
import java.io.FileNotFoundException;

/**
 * Filename:    $RCSfile: VPMiReportEmailer_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: zznels $    	 On:	$Date: 2007-11-13 14:41:10 $
 *
 * @author zznels
 * @version $Revision: 1.2 $
 */
public class VPMiReportEmailer_UT extends TestCase {

  protected void setUp() throws Exception {
    super.setUp();
    AbstractEmailTransporterFactory.setImplementation(MonsantoEmailService_UT.MockEmailTransporterFactory.class.getName());
  }

  protected void tearDown() throws Exception {
    AbstractEmailTransporterFactory.setImplementation(null);
    super.tearDown();
  }

  public void testSendEmailCallsCorrectTransporterFunction() throws Exception {
    MonsantoEmailService_UT.MockEmailTransporterFactory.transporter = new MonsantoEmailService_UT.MockEmailTransporter();
    VPMiReportEmailer emailer = new VPMiReportEmailer(new MockMessageTemplateFactory());
    emailer.sendEmail("test", new EmailHeaderInfo("Test_To", "Test_From", "Test_Subject"), new Object());
    assertTrue(MonsantoEmailService_UT.MockEmailTransporterFactory.transporter.isEmailSent());
  }

  private class MockMessageTemplateFactory implements MessageTemplateFactory{
    public MessageTemplate getTemplateById(String templateId) {
      return new MockMessageTemplate();
    }
  }
  
  private class MockMessageTemplate implements MessageTemplate {
    public String getFormattedMessage(Object object) {
      return object.toString();
    }
  }

  public void testSendMessageDoesNotAcceptNullParams() throws Exception {
    VPMiReportEmailer emailService = new VPMiReportEmailer(new MockMessageTemplateFactory());
    
    try{
      emailService.sendMessage(null, Month.Jan,  new File("NotAFile"));
      fail("Should Throw Null Param Exception");
    } catch (NullParameterException ex){
      //expected path
    }

    try{
      emailService.sendMessage(new CCOwner(), null, new File("NotAFile"));
      fail("Should Throw Null Param Exception");
    } catch (NullParameterException ex){
      //expected path
    }

    try{
      emailService.sendMessage(new CCOwner(), Month.Jan,  null);
      fail("Should Throw Null Param Exception");
    } catch (NullParameterException ex){
      //expected path
    }

    try{
      emailService.sendMessage(new CCOwner(), Month.Jan,  new File("NotAFile"));
      fail("Should Throw File Not Found Exception");
    } catch (FileNotFoundException ex){
      //expected path
    }
  }
}