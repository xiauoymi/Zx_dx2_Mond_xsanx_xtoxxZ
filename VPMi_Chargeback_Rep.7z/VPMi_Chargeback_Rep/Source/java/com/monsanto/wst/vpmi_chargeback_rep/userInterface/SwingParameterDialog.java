package com.monsanto.wst.vpmi_chargeback_rep.userInterface;

import com.monsanto.KerberosEnvironment.developerdesktop.ExampleFileFilter;
import com.monsanto.wst.vpmi_chargeback_rep.VPMiChargebackData.Month;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.File;

public class SwingParameterDialog extends JDialog  implements VPMiSwingDialog {
  private LockHandler lockHandler = new LockHandler();
  private JPanel contentPane;
  private JButton buttonOK;
  private JButton buttonCancel;
  private JComboBox monthComboBox;
  private JTextField yearTextField;
  private JTextField filenameTextBox;
  private JButton pickFileButton;
  private JTextArea errorTextBox;

  private boolean cancelled = false;
  private boolean wasSubmitted = false;

  public SwingParameterDialog() {
    contentPane = new JPanel();
    filenameTextBox = new JTextField();
    pickFileButton = new JButton("Choose File");
    monthComboBox = new JComboBox();
    yearTextField = new JTextField();
    errorTextBox = new JTextArea();
    buttonOK = new JButton("OK");
    buttonCancel = new JButton("Cancel");

    setPanelDesign();

    setContentPane(contentPane);
    getRootPane().setDefaultButton(buttonOK);

    errorTextBox.setEditable(false);
    
    errorTextBox.append("Waiting for input:\n");
    errorTextBox.append("Select a VPMi Chargeback Report file\n");
    errorTextBox.append("Select the corresponding month\n");
    errorTextBox.append("Enter the corresponding year\n");

    filenameTextBox.setEditable(false);
    filenameTextBox.setText("Select A File");
    
    monthComboBox.addItem("Select A Month");
    for(Month month : Month.values()) {
      monthComboBox.addItem(month);
    }

    buttonOK.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        onOK();
      }
    });

    buttonCancel.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        onCancel();
      }
    });

// call onCancel() when cross is clicked
    setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
    addWindowListener(new WindowAdapter() {
      public void windowClosing(WindowEvent e) {
        onCancel();
      }
    });

// call onCancel() on ESCAPE
    contentPane.registerKeyboardAction(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        onCancel();
      }
    }, KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0), JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT);

    pickFileButton.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        chooseFile();
        pack();
      }
    });
  }

  private void setPanelDesign() {
    filenameTextBox.setPreferredSize(new Dimension(150, 25));
    yearTextField.setPreferredSize(new Dimension(105, 25));

    JPanel inputPane = new JPanel();
    inputPane.add(new JLabel("Report File:"));
    inputPane.add(filenameTextBox);
    inputPane.add(pickFileButton);
    inputPane.add(new JLabel("Month:"));
    inputPane.add(monthComboBox);
    inputPane.add(new JLabel("Year:"));
    inputPane.add(yearTextField);

    JScrollPane errorPane = new JScrollPane(errorTextBox, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
                                            JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
    
    JPanel buttonPane = new JPanel();
    buttonPane.setLayout(new BoxLayout(buttonPane, BoxLayout.LINE_AXIS));
    buttonPane.setBorder(BorderFactory.createEmptyBorder(0, 10, 10, 10));
    JLabel statusLbl = new JLabel("Status:");
    buttonPane.add(statusLbl);
    buttonPane.add(Box.createRigidArea(new Dimension(5,0)));
    buttonPane.add(errorPane);
    buttonPane.add(Box.createRigidArea(new Dimension(20, 0)));
    buttonPane.add(buttonOK);
    buttonPane.add(Box.createRigidArea(new Dimension(10, 0)));
    buttonPane.add(buttonCancel);

    contentPane.setLayout(new BoxLayout(contentPane, BoxLayout.PAGE_AXIS));
    contentPane.add(inputPane);
    contentPane.add(buttonPane);
    contentPane.setPreferredSize(new Dimension(700, 200));
  }

  public int getYear() throws NumberFormatException{
    return Integer.parseInt(yearTextField.getText());
  }

  public Month getMonth() {
    return (Month) monthComboBox.getSelectedItem();
  }

  public File getInputFile(){
    return new File(filenameTextBox.getText());
  }

  public boolean wasCancelled() {
    return cancelled;
  }

  public void addLogMessage(String message) {
    errorTextBox.setText(errorTextBox.getText()+message);
  }

  public void showDialog() {
    pack();
    setVisible(true);
  }

  public void waitForClose() {
      lockHandler.waitForLock();
  }

  private void chooseFile() {
    JFileChooser chooser = new JFileChooser();
    ExampleFileFilter filter = new ExampleFileFilter();
    filter.addExtension("xls");
    filter.setDescription("VPMi Chargeback Reports (Excel format)");
    chooser.setFileFilter(filter);
    chooser.setCurrentDirectory(new File(System.getProperty("user.dir")));
    int returnVal = chooser.showOpenDialog(this);
    if(returnVal == JFileChooser.APPROVE_OPTION) {
      filenameTextBox.setText(chooser.getSelectedFile().getAbsolutePath());
    }
  }
  
  public void onOK() {
    if(validateYear()&&validateMonth()&&validateFile()){
      errorTextBox.setText("");
      wasSubmitted = true;
      lockHandler.releaseLock();
    }
    lockHandler.releaseLock();
  }

  private boolean validateFile() {
    return !filenameTextBox.getText().equals("Select A File");
  }

  private boolean validateMonth() {
    try{
      getMonth();
      return true;
    }
    catch (Exception ex){
      return false;
    }
  }

  private boolean validateYear() {
    return yearTextField.getText().length()==4 && yearTextField.getText().matches("[0-9]+");
  }

  public void onCancel() {
    cancelled = true;
    dispose();
    lockHandler.releaseLock();
  }

  public String getLogMessages() {
    return errorTextBox.getText();
  }

  public boolean wasSubmitted() {
    return wasSubmitted;
  }

  public static void main(String[] args) {
    SwingParameterDialog dialog = new SwingParameterDialog();
    dialog.pack();
    dialog.setVisible(true);
    System.exit(0);
  }
}