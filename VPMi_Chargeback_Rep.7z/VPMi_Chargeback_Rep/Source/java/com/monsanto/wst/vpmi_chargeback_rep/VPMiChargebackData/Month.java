package com.monsanto.wst.vpmi_chargeback_rep.VPMiChargebackData;

/**
 * Filename:    $RCSfile: Month.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: zznels $    	 On:	$Date: 2007-10-12 20:12:40 $
 *
 * @author zznels
 * @version $Revision: 1.3 $
 */
public enum Month{
  Jan ("Jan"),
  Feb ("Feb"),
  Mar ("Mar"),
  Apr ("Apr"),
  May ("May"),
  June ("June"),
  July ("July"),
  Aug ("Aug"),
  Sep ("Sep"),
  Oct ("Oct"),
  Nov ("Nov"),
  Dec ("Dec");

  private final String month;

  Month(String mo){
    this.month = mo;
  }

  public String toString(){
    return this.month;
  }
}
