/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.vpmi_chargeback_rep.emailer;

import com.monsanto.wst.emailtemplate.facade.MessageTemplateFactory;
import com.monsanto.wst.commonutils.template.MessageTemplate;
import com.monsanto.wst.commonutils.template.FileMessageTemplate;
import com.monsanto.wst.commonutils.template.TemplateNotFoundException;
import com.monsanto.wst.commonutils.reflection.ObjectInspector;

import java.util.Map;
import java.util.HashMap;

/**
 * Filename:    $RCSfile: VPMiReportMessageTemplateFactory.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: zznels $    	 On:	$Date: 2007-11-13 14:41:10 $
 *
 * @author zznels
 * @version $Revision: 1.2 $
 */
public class VPMiReportMessageTemplateFactory implements MessageTemplateFactory {
    private final Map templates;

    public VPMiReportMessageTemplateFactory() {
        templates = new HashMap();
        templates.put("reportEmail", "com/monsanto/wst/vpmi_chargeback_rep/emailer/VpmiReport.email");
    }

    public MessageTemplate getTemplateById(String templateId) {
        String templatePath = (String) templates.get(templateId);
        if (templatePath != null) {
            return new FileMessageTemplate(templatePath, new ObjectInspector());
        }
        throw new TemplateNotFoundException("Unable to find template with id: '" + templateId + "'.");
    }
}