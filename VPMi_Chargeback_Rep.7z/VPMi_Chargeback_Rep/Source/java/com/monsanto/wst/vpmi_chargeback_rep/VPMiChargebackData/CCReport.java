/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.vpmi_chargeback_rep.VPMiChargebackData;

import java.util.List;
import java.util.Vector;
import java.util.Iterator;

/**
 * Filename:    $RCSfile: CCReport.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: zznels $    	 On:	$Date: 2007-11-13 14:41:10 $
 *
 * @author zznels
 * @version $Revision: 1.7 $
 *
 * NOTE: Class only valid for 1 year's worth of data. Please make seperate instances for each year you wish to track.
 * Months will be created in the order they are needed (inputted). It is beneficial to input data in chronological
 * order, in order for it to print in that order.
 */
public class CCReport {
  public String Cost_Center;
  public List<MonthReport> monthReports;

  public CCReport(String Cost_Center) {
    this.Cost_Center = Cost_Center;
    this.monthReports = new Vector<MonthReport>();
  }

  public String toString(){
    String result = Cost_Center + "\n";
    for(MonthReport monthRep: monthReports){
      result+=monthRep.toString();
    }
    return result;
  }

  public String getCost_Center() {
    return Cost_Center;
  }

  public int getNumMonths(){
    return monthReports.size();
  }

  public List<Month> getMonths(){
    Vector<Month> result = new Vector<Month>();
    for(MonthReport monthRep: monthReports){
      result.add(monthRep.getMonth());
    }
    return result;
  }

  public Iterator<MonthReport> getMonthRepIterator(){
    return monthReports.iterator();
  }

  public List<MonthReport> getMonthReports() {
    return monthReports;
  }

  /**
   * Desc: adds the chargeback if it is for the same cost center as this CCReport.
   *       Chargeback is added to the corresponding month in the CCReport
   * @param charge: Chargeback to add
   * @return boolean: wether the chargeback was successfully added or not
   */
  public boolean addCharge(Chargeback charge){
    boolean success = false;
    if(charge.getFullCostCenter().equals(this.Cost_Center))
    {
      Month month = Month.valueOf(charge.getMonth());
      boolean found = false;
      for(MonthReport monthRep: monthReports)
      {
        if(monthRep.getMonth() == month)
        {
          monthRep.add(charge);
          found = true;
          break;
        }
      }
      if(!found){
        MonthReport tempRep = new MonthReport(month);
        tempRep.add(charge);
        monthReports.add(tempRep);
      }
      success = true;
    }
    return success;
  }
}