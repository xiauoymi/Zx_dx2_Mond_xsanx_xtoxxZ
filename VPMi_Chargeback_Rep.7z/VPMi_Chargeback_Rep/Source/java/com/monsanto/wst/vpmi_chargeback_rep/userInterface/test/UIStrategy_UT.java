/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.vpmi_chargeback_rep.userInterface.test;

import com.monsanto.AbstractLogging.Logger;
import com.monsanto.AbstractLogging.Test.MockErrorLog;
import com.monsanto.wst.vpmi_chargeback_rep.controller.VPMiController;
import com.monsanto.wst.vpmi_chargeback_rep.controller.test.MockController;
import com.monsanto.wst.vpmi_chargeback_rep.userInterface.ParameterSource;
import com.monsanto.wst.vpmi_chargeback_rep.userInterface.UIStrategy;
import junit.framework.TestCase;

/**
 * Filename:    $RCSfile: UIStrategy_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: zznels $    	 On:	$Date: 2007-12-04 22:41:22 $
 *
 * @author zznels
 * @version $Revision: 1.5 $
 */
public class UIStrategy_UT extends TestCase {

  public void testProcessMethodCallsController() throws Exception {
    MockController controller = new MockController();
    MockUIStrategy strat = new MockUIStrategy(new MockParameterValidSource(), controller);
    strat.process();
    assertTrue(controller.wasControllerCalled());
  }

  public void testMessagesAreDisplayedDuringProcessing() throws Exception {
    MockController controller = new MockController();
    MockUIStrategy strat = new MockUIStrategy(new MockParameterValidSource(), controller);
    MockErrorLog log = new MockErrorLog();
    Logger.register(log);

    strat.process();

    assertTrue(Logger.isRegistered("Error"));
    assertTrue(log.hasMessageBeenLoggedContaining("MockController Logged"));
  }



  /////////////Mocks//////////////////
  private static class MockUIStrategy extends UIStrategy {
    public MockUIStrategy(ParameterSource argv, VPMiController controller) {
      super(argv, controller);
    }
  }

  private static class MockParameterValidSource extends MockParameterSource {
    @SuppressWarnings({"RefusedBequest"})
    public boolean isValid() {
      return true;
    }
  }
}