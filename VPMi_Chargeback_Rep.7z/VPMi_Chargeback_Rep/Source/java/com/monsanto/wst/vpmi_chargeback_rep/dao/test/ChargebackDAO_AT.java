/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.vpmi_chargeback_rep.dao.test;

import com.monsanto.wst.dbtemplate.dao.DBTemplateDaoException;
import com.monsanto.wst.dbtemplate.factory.AbstractTransactionManagerFactory;
import com.monsanto.wst.dbtemplate.transaction.TransactionManager;
import com.monsanto.wst.vpmi_chargeback_rep.VPMiChargebackData.CCOwner;
import com.monsanto.wst.vpmi_chargeback_rep.VPMiChargebackData.Chargeback;
import com.monsanto.wst.vpmi_chargeback_rep.VPMiChargebackData.Month;
import com.monsanto.wst.vpmi_chargeback_rep.dao.ChargebackDAO;
import com.monsanto.wst.vpmi_chargeback_rep.dao.ChargebackDAOTemplate;
import junit.framework.TestCase;

import java.util.List;

/**
 * Filename:    $RCSfile: ChargebackDAO_AT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: zznels $    	 On:	$Date: 2007-12-13 22:53:03 $
 *
 * @author zznels
 * @version $Revision: 1.6 $
 */
public class ChargebackDAO_AT extends TestCase {

  private ChargebackDAO testDAO;
  TransactionManager txManager;
  private ChargebackDAOTemplate template;

  public void setUp() throws Exception{
    super.setUp();
        txManager = AbstractTransactionManagerFactory.newInstance(
                        "com/monsanto/wst/vpmi_chargeback_rep/dao/ChargebackDBConfig.xml").getTransactionManager();
    this.testDAO = new ChargebackDAO(txManager);
    this.template = new ChargebackDAOTemplate();
  }

  protected void tearDown() throws Exception {
    super.tearDown();
    txManager.rollbackTransaction();
  }

  public void testInsertDoesNotThrowException() throws Exception {
    testDAO.insertChargeback(new Chargeback("1-2-3-4", "Desc", 123.45, Month.Jan, 2007));
  }

  public void testInsertEmptyChargeThrowsException() throws Exception {
    try{
      testDAO.insertChargeback(new Chargeback());
      fail("should throw exception for inserting Null into Database");
    } catch (DBTemplateDaoException ex){
    }
  }

  public void testGetSingleOwnerReturnsCorrectInfo() throws Exception {
    CCOwner owner = new CCOwner();
    owner.setCostCenter("1-2-3-4");
    owner.setName("Zach Nelson");
    owner.setUserID("zznels");
    owner.setToReceive(true);
    testDAO.insertOwner(owner);

    List<CCOwner> list = testDAO.getOwners("1-2-3-4");

    assertEquals(1, list.size());
    assertEquals("Zach Nelson", list.get(0).getName());
  }

  public void testGetOwnerDNEReturnsEmptyList() throws Exception {
    List<CCOwner> list = testDAO.getOwners("1-2-3-4");

    assertTrue(list.isEmpty());
  }
}