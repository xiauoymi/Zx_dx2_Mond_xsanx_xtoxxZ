/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.vpmi_chargeback_rep.VPMiChargebackData.test;

import junit.framework.TestCase;
import com.monsanto.wst.vpmi_chargeback_rep.VPMiChargebackData.Chargeback;
import com.monsanto.wst.vpmi_chargeback_rep.VPMiChargebackData.CCReportBuilder;
import com.monsanto.wst.vpmi_chargeback_rep.VPMiChargebackData.CCReport;
import com.monsanto.wst.vpmi_chargeback_rep.VPMiChargebackData.Month;

import java.util.Vector;
import java.util.List;

/**
 * Filename:    $RCSfile: CCReportBuilder_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: zznels $    	 On:	$Date: 2007-09-25 20:31:35 $
 *
 * @author zznels
 * @version $Revision: 1.2 $
 */
public class CCReportBuilder_UT extends TestCase {
  
  public void testparse_NumCCEquals2() throws Exception {
    Vector<Chargeback> testList = new Vector<Chargeback>();
    testList.add(new Chargeback("1-2-3-4","Desc",123.34, Month.Jan, 2007));
    testList.add(new Chargeback("1-2-3-5","Desc",123.34, Month.Jan, 2007));
    testList.add(new Chargeback("1-2-3-4","Desc",123.34, Month.Jan, 2007));
    CCReportBuilder parser = new CCReportBuilder();
    List<CCReport> result = parser.parse(testList);
    assertEquals(2, result.size());
  }

  public void testparse_freshListEachCall() throws Exception {
    Vector<Chargeback> testList1 = new Vector<Chargeback>();
    testList1.add(new Chargeback("1-2-3-4","Desc",123.34, Month.Jan, 2007));
    testList1.add(new Chargeback("1-2-3-4","Desc",123.34, Month.Jan, 2007));
    CCReportBuilder parser = new CCReportBuilder();
    parser.parse(testList1);
    Vector<Chargeback> testList2 = new Vector<Chargeback>();
    testList2.add(new Chargeback("1-2-3-5","Desc",123.34, Month.Jan, 2007));
    List<CCReport> result = parser.parse(testList2);
    assertEquals(1, result.size());
  }

}