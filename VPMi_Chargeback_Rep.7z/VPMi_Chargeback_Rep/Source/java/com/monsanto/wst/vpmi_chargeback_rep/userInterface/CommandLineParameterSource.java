/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.vpmi_chargeback_rep.userInterface;

import com.monsanto.wst.vpmi_chargeback_rep.VPMiChargebackData.Month;

import java.io.File;

/**
 * Filename:    $RCSfile: CommandLineParameterSource.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: zznels $    	 On:	$Date: 2007-11-28 22:11:52 $
*
* @author zznels
* @version $Revision: 1.4 $
*/
public class CommandLineParameterSource extends ParameterSource {
  private String[] args;
  private String arg1 = "", arg2 = "", arg3 = "";
  
  private static final String INVALID_NUM_PARAMS_ERR = "Invalid Number of Parameters\n";
  private static final String INVALID_FILE_ERR = "Invalid File Entered\n";
  private static final String INVALID_MONTH_ERR = "Invalid Month Entered\n";
  private static final String INVALID_YEAR_ERR = "Invalid Year Entered\n";
  private boolean invNumParamsFlag = false;
  private boolean invFileFlag = false;
  private boolean invMonthFlag = false;
  private boolean invYearFlag = false;

  public CommandLineParameterSource(String[] args) {
    this.args = args;
    if(args.length == 3){
       arg1 = args[0];
       arg2 = args[1];
       arg3 = args[2];
     } else {
      invNumParamsFlag = true;
    }
  }

  public boolean isValid() {
     return args.length == 3 && super.isValid();
  }

  public File getInputFile() {
    File file = new File(arg1);
    if(file.exists()){
      return file;
    }
    else{
      invFileFlag = true;
      return null;
    }
  }

  public Month getReportMonth() {
    Month ret;
    try{
      ret = Month.valueOf(arg2);
    } catch (IllegalArgumentException ex) {
      ret = null;
      invMonthFlag = true;
    }
    return ret;
  }

  public int getReportYear() {
    int ret;
    try{
      ret = Integer.parseInt(arg3);
    } catch (NumberFormatException ex) {
      ret = -1;
      invYearFlag = true;
    }
    return ret;
  }

  public String getErrorMessage() {
    String message = "";
    if(invNumParamsFlag){
      message = INVALID_NUM_PARAMS_ERR;
    }
    if(invFileFlag){
      message += INVALID_FILE_ERR;
    }
    if(invMonthFlag){
      message += INVALID_MONTH_ERR;
    }
    if(invYearFlag){
      message += INVALID_YEAR_ERR;
    }
    return message;
  }
}