/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.vpmi_chargeback_rep.userInterface;

import com.monsanto.wst.vpmi_chargeback_rep.VPMiChargebackData.Month;

import java.io.File;

/**
 * Filename:    $RCSfile: ParameterSource.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: zznels $    	 On:	$Date: 2007-10-25 15:51:53 $
*
* @author zznels
* @version $Revision: 1.2 $
*/
public abstract class ParameterSource {
  public boolean isValid() {
      return getReportMonth() !=null &&  getInputFile() != null && getReportYear() != -1;
  }
  
  public abstract File getInputFile();
  public abstract Month getReportMonth();
  public abstract int getReportYear();
  public abstract String getErrorMessage();
}