/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.vpmi_chargeback_rep.userInterface.test;

import com.monsanto.Util.Exceptions.NullParameterException;
import com.monsanto.wst.vpmi_chargeback_rep.VPMiChargebackData.Month;
import com.monsanto.wst.vpmi_chargeback_rep.userInterface.SwingParameterSource;
import junit.framework.TestCase;

import java.io.File;

/**
 * Filename:    $RCSfile: SwingParameterSource_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: zznels $    	 On:	$Date: 2007-11-28 22:11:52 $
 *
 * @author zznels
 * @version $Revision: 1.3 $
 */
public class SwingParameterSource_UT extends TestCase {
  private static final String TESTREPORT_XLS =
                              "./com/monsanto/wst/vpmi_chargeback_rep/userInterface/test/testReport.xls";
  private static final int TEST_YEAR = 2007;
  private static final Month TEST_MONTH = Month.Jan;

  public void testThrowsExceptionIfParamNull() throws Exception {
    try{
      new SwingParameterSource(null);
      fail("Should Throw Null Param Exception");
    } catch (NullParameterException ex) {
      //expected Path
    }
  }

  public void testGetsValidParametersFromDialog() throws Exception {
    MockSwingDialog mockDialog = new MockSwingDialog();
    mockDialog.setInputFile(new File(TESTREPORT_XLS));
    mockDialog.setMonth(TEST_MONTH);
    mockDialog.setYear(TEST_YEAR);
    SwingParameterSource source = new SwingParameterSource(mockDialog);

    assertTrue(source.isValid());
    assertEquals(new File(TESTREPORT_XLS), source.getInputFile());
    assertEquals(TEST_MONTH, source.getReportMonth());
    assertEquals(TEST_YEAR, source.getReportYear());
  }

  public void testInvalidMonthReturnsNullLogsError() throws Exception {
    MockSwingDialog mockDialog = new MockSwingDialog();
    mockDialog.setInputFile(new File(TESTREPORT_XLS));
    mockDialog.setMonth(null);
    mockDialog.setYear(TEST_YEAR);
    SwingParameterSource source = new SwingParameterSource(mockDialog);

    assertFalse(source.isValid());
    assertNull(source.getReportMonth());
    assertTrue(source.getErrorMessage().contains("Invalid Month Entered"));
  }

  public void testInvalidFileReturnsNullLogsError() throws Exception {
    MockSwingDialog mockDialog = new MockSwingDialog();
    mockDialog.setInputFile(new File("invalidFile.xls"));
    mockDialog.setMonth(TEST_MONTH);
    mockDialog.setYear(TEST_YEAR);
    SwingParameterSource source = new SwingParameterSource(mockDialog);

    assertFalse(source.isValid());
    assertNull(source.getInputFile());
    assertTrue(source.getErrorMessage().contains("Invalid File Entered"));
  }

  public void testErrorMessageContainsOnlyOneOfEachMessage() throws Exception {
    SwingParameterSource source = new SwingParameterSource(new MockSwingDialog());

    assertFalse(source.isValid());
    source.getInputFile();
    assertEquals(null, source.getReportMonth());

    String[] result = source.getErrorMessage().split("Invalid Month Entered");
    assertEquals(1, result.length);
  }
}