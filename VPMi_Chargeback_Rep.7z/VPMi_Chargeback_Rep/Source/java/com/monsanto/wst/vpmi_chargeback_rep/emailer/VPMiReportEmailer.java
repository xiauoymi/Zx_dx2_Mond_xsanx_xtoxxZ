/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.vpmi_chargeback_rep.emailer;

import com.monsanto.wst.emailtemplate.facade.MessageTemplateFactory;
import com.monsanto.wst.emailtemplate.services.MonsantoEmailService;
import com.monsanto.wst.emailtemplate.domain.EmailHeaderInfo;
import com.monsanto.wst.vpmi_chargeback_rep.VPMiChargebackData.CCOwner;
import com.monsanto.wst.vpmi_chargeback_rep.VPMiChargebackData.MonthReport;
import com.monsanto.wst.vpmi_chargeback_rep.VPMiChargebackData.Month;
import com.monsanto.Util.validation.ParameterValidation;

import java.io.File;
import java.io.FileNotFoundException;

/**
 * Filename:    $RCSfile: VPMiReportEmailer.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: zznels $    	 On:	$Date: 2007-11-13 14:41:10 $
 *
 * @author zznels
 * @version $Revision: 1.2 $
 */
public class VPMiReportEmailer extends MonsantoEmailService {
  public static final String SUBJECT = "Your Monthy WST Chargeback Report";
  private static final String FROM_EMAIL_ADDRESS = "VPMiRepAutoEmailer@monsanto.com";

  public VPMiReportEmailer(MessageTemplateFactory messageTemplateFactory) {
    super(messageTemplateFactory);
  }

  public VPMiReportEmailer(){
    super(new VPMiReportMessageTemplateFactory());
  }

  /**
   * 
   * @param owner: The owner to send the email to. The email field of owner must be set correctly
   * @param report: The file to send as an attachment to the owner
   * @param mo: The month of the report file
   * @throws FileNotFoundException: Thrown if report doesn't not exist or cannot be found
   */
  public void sendMessage(CCOwner owner, Month mo, File report) throws FileNotFoundException {
    ParameterValidation.objectNotNull(owner, "Owner");
    ParameterValidation.objectNotNull(mo, "Month");
    ParameterValidation.objectNotNull(report, "VPMi Report File");
    
    EmailHeaderInfo headerInfo = new EmailHeaderInfo(owner.getEmail(), FROM_EMAIL_ADDRESS, SUBJECT);
    headerInfo.addAttachment(report);
    VPMiReportEmailer emailService = new VPMiReportEmailer(new VPMiReportMessageTemplateFactory());

    VPMiReportEmailObject emailObject = new VPMiReportEmailObject();
    emailObject.owner.setName(owner.getName());
    emailObject.setMonthRep(new MonthReport(mo));

    emailService.sendEmail("reportEmail", headerInfo, emailObject);
  }
}