/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.vpmi_chargeback_rep.userInterface;

import com.monsanto.AbstractLogging.LogRegistrationException;
import com.monsanto.wst.vpmi_chargeback_rep.controller.VPMiChargebackRepController;

/**
 * Filename:    $RCSfile: ProgramEntry.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: zznels $    	 On:	$Date: 2007-12-18 15:58:55 $
 *
 * @author zznels
 * @version $Revision: 1.5 $
 */
public class ProgramEntry {
  private static final String MONCRYPTJV = "MONCRYPTJV";
  private static final String LSI_FUNCTION = "lsi.function";

  public static void main(String[] argv) throws LogRegistrationException {
    if (System.getProperty(MONCRYPTJV) == null) {
      System.setProperty(MONCRYPTJV, System.getenv(MONCRYPTJV));
    }
    if (System.getProperty(LSI_FUNCTION) == null) {
      System.setProperty(LSI_FUNCTION, "win");
    }
    UIStrategy strat = new UIStrategyImplFactory(new VPMiChargebackRepController()).getStrategyImplementation(argv);
    if(strat!=null){
      strat.process();
    }
  }
  
}