/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.vpmi_chargeback_rep.VPMiChargebackData;

import java.util.List;
import java.util.Vector;

/**
 * Filename:    $RCSfile: CCReportBuilder.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: zznels $    	 On:	$Date: 2007-08-14 15:32:25 $
 *
 * @author zznels
 * @version $Revision: 1.1 $
 */
public class CCReportBuilder {

  Vector<CCReport> result;

  /**
   * Function: parse
   * Desc: puts each charge in a CCReport under the correct Cost-Center and Month
   * @param charges: List of all the chargebacks for a range of months (not valid for more than 12 months)
   * @return List<CCReport>: List of Cost Center Reports containing all the Chargebacks from charges
   * Limitations: Not valid for more than 12 months of data (restriction inherited from CCReport)
   */
  public List<CCReport> parse(List<Chargeback> charges) {
    result = new Vector<CCReport>();
    for (Chargeback currCharge : charges) {
      int index = findCC(currCharge);
      if (index == -1) // if Cost Center not found 
      {
        index = createCC(result, currCharge);
      }
      addCharge(index, currCharge);
    }
    return result;
  }

  private void addCharge(int index, Chargeback currCharge) {
    result.get(index).addCharge(currCharge);
  }

  private int createCC(Vector<CCReport> result, Chargeback currCharge) {
    String CC = currCharge.getFullCostCenter();
    result.add(new CCReport(CC));
    return result.size()-1; //lastIndex
  }

  private int findCC(Chargeback currCharge){
    String CC = currCharge.getFullCostCenter();
    int index = -1;
    for (CCReport tempCCR : result) {
      if (tempCCR.Cost_Center.equals(CC)) {
        index = result.indexOf(tempCCR);
        break;
      }
    }
    return index;
  }

}