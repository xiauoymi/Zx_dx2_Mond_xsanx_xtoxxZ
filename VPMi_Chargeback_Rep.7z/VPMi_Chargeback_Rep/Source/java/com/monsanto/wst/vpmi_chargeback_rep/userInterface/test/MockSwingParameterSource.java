/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.vpmi_chargeback_rep.userInterface.test;

import com.monsanto.wst.vpmi_chargeback_rep.userInterface.SwingParameterSource;
import com.monsanto.wst.vpmi_chargeback_rep.userInterface.VPMiSwingDialog;

/**
 * Filename:    $RCSfile: MockSwingParameterSource.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: zznels $    	 On:	$Date: 2007-10-31 16:08:27 $
 *
 * @author zznels
 * @version $Revision: 1.1 $
 */
public class MockSwingParameterSource extends SwingParameterSource {

  public MockSwingParameterSource() {
    super(new MockSwingDialog());
  }

  public MockSwingParameterSource(VPMiSwingDialog dialog) {
    super(dialog);
  }

  public boolean isValid() {
    return false;
  }

  public String getErrorMessage() {
    return "Test Error Message";
  }
}