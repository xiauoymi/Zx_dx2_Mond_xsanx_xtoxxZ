package com.monsanto.wst.vpmi_chargeback_rep.servlet;


import com.monsanto.AbstractLogging.LogRegistrationException;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.ServletFramework.GatewayServlet;
import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.ServletFramework.UCCServletHelper;
import com.monsanto.dataservices.PersistentStore;
import com.monsanto.Util.Exceptions.WrappingException;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;



/**
 *
 * <p>Title: VPMi_Chargeback_RepServlet</p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Monsanto</p>
 * @author Java Framework Code Generator 3.0
 * @version $Id: VPMi_Chargeback_RepServlet.java,v 1.1 2007-06-28 20:06:35 mterry Exp $
 */
public class VPMi_Chargeback_RepServlet extends GatewayServlet
{
   public static final String s_cstrResourceBundle = "com.monsanto.wst.vpmi_chargeback_rep.servlet.VPMi_Chargeback_Rep";
   public static VPMi_Chargeback_RepLoggerFactory loggerFactory = null;

   public VPMi_Chargeback_RepServlet()
   {
      super();
   }

   public void init(ServletConfig servletConfig) throws ServletException
   {
      super.init(servletConfig);

      Logger.traceEntry();

      try {
        if (loggerFactory == null) {
          loggerFactory = new VPMi_Chargeback_RepLoggerFactory();
          loggerFactory.setupLogging();
        }
      }
      catch (LogRegistrationException lre) {
         throw new ServletException(lre.toString());
      }
      catch (IOException ioe) {
         throw new ServletException(ioe.toString());
      }

      Logger.traceExit();
   }

   public void destroy()
   {
      Logger.traceEntry();

      try {
         PersistentStore.registerInstance(VPMi_Chargeback_RepPersistentStoreFactory.PERSISTENT_STORE_NAME, null);
         PersistentStore.dropAllInstances();
      }
      catch (WrappingException e) {
      }

      super.destroy();

      Logger.traceExit();
   }

   /**
    * This static method will create an instance of the desired PersistentStore based on
    * data within a property file.
    * @param request - The HttpServlet Request from the servlet container
    * @param response - The HttpServletResponse to be sent back to the servlet container.
    * @throws java.io.IOException
    * @throws javax.servlet.ServletException
    */
   public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException
   {
      Logger.traceEntry();

      try {

         /*  Register the persistent store with this servlet instance.  */
         PersistentStore ps = VPMi_Chargeback_RepPersistentStoreFactory.getStore(s_cstrResourceBundle);
         PersistentStore.registerInstance(VPMi_Chargeback_RepPersistentStoreFactory.PERSISTENT_STORE_NAME, ps);

         /*  Pass the doGet along.  */
         super.doGet(request, response);
      }
      catch (WrappingException we) {
         UCCHelper helper = new UCCServletHelper(getServletConfig(), request, response);
         helper.reportError("Error accessing database.  Please notify your technical support contact or try again later.\n" + we.toString());
         helper.closeSession();
      }

      Logger.traceExit();
   }
}
