/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.vpmi_chargeback_rep.VPMiChargebackData;

import java.util.List;
import java.util.Vector;
import java.util.Iterator;

/**
 * Filename:    $RCSfile: MonthReport.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: zznels $    	 On:	$Date: 2007-10-17 14:11:27 $
 *
 * @author zznels
 * @version $Revision: 1.7 $
 */


/**
 * Class: MonthReport
 * Desc: Represents one months report for a specific cost center
 *       Note: MonthReport is defined by the first Chargeback added to it. The addition of chargebacks beyond
 *             the first will be constrained to match the cost-center and month of the first
 */
public class MonthReport {
  private Month month;
  private double totalCharge;
  private List<Chargeback> charges;

  public MonthReport(Month month){
    this.month = month;
    this.totalCharge = 0;
    this.charges = new Vector<Chargeback>();
  }

  public int getNumberCharges(){
    return charges.size();
  }

  public Iterator<Chargeback> getChargebackIterator(){
    return charges.iterator();
  }

  public Month getMonth() {
    return month;
  }

  public List<Chargeback> getCharges() {
    return charges;
  }

  public double getTotalCharge() {
    return totalCharge;
  }

  /**
   * Function: add
   * Desc:  Adds charge to this MonthReport if the charge has the same month
   * @param charge: The Chargeback to be added
   * @return boolean: Wether charge was added to MonthReport
   */
  public boolean add(Chargeback charge){
    boolean result = false;
    if(isValidMonth(charge) &&
        isValidYear(charge) &&
        isValidCostCenter(charge))
    {
      charges.add(charge);
      totalCharge += charge.getAmount();
      result = true;
    }
    return result;
  }

  private boolean isValidCostCenter(Chargeback charge) {
    return getCostCenter() == (null) ||
           charge.getFullCostCenter().equals(getCostCenter());
  }

  private boolean isValidMonth(Chargeback charge) {
    return charge.getMonth() == this.month.toString();
  }

  private boolean isValidYear(Chargeback charge) {
    return (charge.getYear() == getYear() || getYear() == -1);
  }

  private int getYear() {
    if(charges.isEmpty())
      return -1;
    else
      return this.charges.get(0).getYear();
  }

  /**
   * Function: toString
   * Desc: outputs a formatted string with all MonthReport information, including sum of all charges
   * Dependencies: Uses Chargeback's toString function to print each Chargeback's info
   * @return String: The formatted string output
   */
  public String toString(){
    String result = month + " " + charges.get(0).getYear() + "\n";
    for(Chargeback currCharge: charges){
      result += currCharge.toString()+'\n';
    }
    result += "Total: " + totalCharge;
    return result;
  }

  public String getCostCenter() {
    if(charges.isEmpty())
      return null;
    else
      return charges.get(0).getFullCostCenter();
  }

}