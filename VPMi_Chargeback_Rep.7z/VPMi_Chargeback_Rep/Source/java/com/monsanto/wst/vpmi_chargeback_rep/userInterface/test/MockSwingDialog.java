/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.vpmi_chargeback_rep.userInterface.test;

import com.monsanto.wst.vpmi_chargeback_rep.userInterface.VPMiSwingDialog;
import com.monsanto.wst.vpmi_chargeback_rep.userInterface.LockHandler;
import com.monsanto.wst.vpmi_chargeback_rep.VPMiChargebackData.Month;

import java.io.File;

/**
 * Filename:    $RCSfile: MockSwingDialog.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: zznels $    	 On:	$Date: 2007-12-13 22:53:02 $
 *
 * @author zznels
 * @version $Revision: 1.5 $
 */
public class MockSwingDialog implements VPMiSwingDialog {
  private LockHandler lockHandler = new LockHandler();
  private File inputFile = null;
  private Month month = null;
  private int year = 0;
  private String errorMessage = "";
  private boolean wasSubmitted = false;
  private boolean cancelled = false;

  public int getYear() throws NumberFormatException {
    return year;
  }

  public Month getMonth() {
    return month;
  }

  public File getInputFile() {
    return inputFile;
  }

  public boolean wasCancelled() {
    return cancelled;
  }

  public void addLogMessage(String message) {
    errorMessage += (message + "\n");
  }

  public void showDialog() {
  }

  public void waitForClose() {
    if(!wasSubmitted()&&!wasCancelled()){
      lockHandler.waitForLock();
    }
  }

  public void onOK() {
    lockHandler.releaseLock();
    this.wasSubmitted = true;
  }

  public void onCancel() {
    lockHandler.releaseLock();
    this.cancelled = true;
  }

  public String getLogMessages(){
    return errorMessage;
  }

  public void setInputFile(File file) {
    this.inputFile = file;
  }

  public void setMonth(Month month) {
    this.month = month;
  }

  public void setYear(int year) {
    this.year = year;
  }

  public boolean wasSubmitted(){
    return wasSubmitted;
  }

  public void setWasSubmitted(boolean submitted){
    this.wasSubmitted = submitted;
  }

  public void setCancelled(boolean cancelled) {
    this.cancelled = cancelled;
  }
}
