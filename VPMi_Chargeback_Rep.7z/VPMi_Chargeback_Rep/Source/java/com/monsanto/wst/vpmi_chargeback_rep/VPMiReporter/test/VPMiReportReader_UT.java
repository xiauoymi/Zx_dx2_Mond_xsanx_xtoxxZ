/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.vpmi_chargeback_rep.VPMiReporter.test;

import com.monsanto.wst.vpmi_chargeback_rep.VPMiReporter.VPMiReportReader;
import com.monsanto.wst.vpmi_chargeback_rep.VPMiReporter.VPMiReportReaderImpl;
import com.monsanto.wst.vpmi_chargeback_rep.VPMiChargebackData.Chargeback;
import junit.framework.TestCase;

import java.io.File;
import java.io.IOException;
import java.util.List;

/**
 * Filename:    $RCSfile: VPMiReportReader_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: zznels $    	 On:	$Date: 2007-11-13 14:41:10 $
 *
 * @author zznels
 * @version $Revision: 1.4 $
 */
public class VPMiReportReader_UT extends TestCase {
  
  public void testreadReport_ListSizeEquals4() throws Exception {
    VPMiReportReader repReader = new VPMiReportReaderImpl();
    File testFile = new File("com\\monsanto\\wst\\vpmi_chargeback_rep\\VPMiReporter\\test\\testReport.xls");
    List<Chargeback> testResult = repReader.readReport(testFile);
    assertEquals(4, testResult.size());
    assertEquals("5180-12345-45000999-TEST", testResult.get(0).getFullCostCenter());
    assertEquals("IT - asgrowanddekalb.com Redesign Phase I - Restyling", testResult.get(1).getDesc());
  }

  public void testreadReportWithInvalidHeaderThrowsException() throws Exception {
    VPMiReportReader repReader = new VPMiReportReaderImpl();
    File testFile = new File("com\\monsanto\\wst\\vpmi_chargeback_rep\\VPMiReporter\\test\\testReportWithInvalidHeader.xls");
    try{
      repReader.readReport(testFile);
      fail("Should Throw IOException");
    } catch (IOException ex){
      //expected path
    }
  }

  public void testreadReportWithBadDataThrowsException() throws Exception {
    VPMiReportReader repReader = new VPMiReportReaderImpl();
    File testFile = new File("com\\monsanto\\wst\\vpmi_chargeback_rep\\VPMiReporter\\test\\testReportWithBadData.xls");
    try{
      repReader.readReport(testFile);
      fail("Should Throw IOException");
    } catch (IOException ex){
      //expected path
    }
  }

}