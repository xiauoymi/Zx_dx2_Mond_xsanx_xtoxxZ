/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.vpmi_chargeback_rep.userInterface.test;

import com.monsanto.wst.vpmi_chargeback_rep.VPMiChargebackData.Month;
import com.monsanto.wst.vpmi_chargeback_rep.controller.VPMiController;
import com.monsanto.wst.vpmi_chargeback_rep.controller.test.MockController;
import com.monsanto.wst.vpmi_chargeback_rep.userInterface.*;
import com.monsanto.AbstractLogging.LogRegistrationException;
import junit.framework.TestCase;

import java.io.File;

/**
 * Filename:    $RCSfile: UIStrategyImplFactory_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: zznels $    	 On:	$Date: 2007-12-13 22:53:02 $
 *
 * @author zznels
 * @version $Revision: 1.7 $
 */
public class UIStrategyImplFactory_UT extends TestCase {
  private VPMiController controller;


  protected void setUp() throws Exception {
    super.setUp();
    controller = new MockController();
  }

  public void testCreatesGuiIfNoParamsAvailable() throws Exception {
    MockSwingDialog dialog = new MockSwingDialog();
    dialog.setWasSubmitted(true);

    UIStrategyImplFactory uiStrategyImplFactory = new UIStrategyImplFactory(controller, dialog);
    UIStrategy impl = uiStrategyImplFactory.getStrategyImplementation(new String[]{});

    assertTrue(impl instanceof SwingUIStrategyImpl);
  }

  public void testCreatesGuiIfParamsNull() throws Exception {
    MockSwingDialog dialog = new MockSwingDialog();
    dialog.setWasSubmitted(true);
    UIStrategy impl = new UIStrategyImplFactory(controller, dialog).getStrategyImplementation(null);

    assertTrue(impl instanceof SwingUIStrategyImpl);
  }

  public void testCreatesCommandLineIfAnyParamsAvailable() throws Exception {
    UIStrategy impl = new UIStrategyImplFactory(controller).getStrategyImplementation(new String[]{"test"});

    assertTrue(impl instanceof CommandLineUIStrategyImpl);
  }

  public void testDataFromDialogPassedToStrategyImpl() throws Exception {
    MockSwingDialog dialog = new MockSwingDialog();
    dialog.setYear(2007);
    dialog.setMonth(Month.Jan);
    File testFile = new File("./com/monsanto/wst/vpmi_chargeback_rep/userInterface/test/testReport.xls");
    dialog.setInputFile(testFile);
    dialog.setWasSubmitted(true);

    MockUIStrategyImplFactory mockFactory = new MockUIStrategyImplFactory(new MockController(), dialog);
    MockSwingUIStrategyImpl strategyImplementation = (MockSwingUIStrategyImpl) mockFactory.getStrategyImplementation(new String[]{});

    assertEquals(2007, strategyImplementation.source.getReportYear());
    assertEquals(Month.Jan, strategyImplementation.source.getReportMonth());
    assertEquals(testFile.getName(), strategyImplementation.source.getInputFile().getName());
  }

  //NOTE: This test does not pass when run with the rest of this test file
  public void testFactoryGetStratImplBlocksUntilDialogWasCanceled() throws Exception {
    LockHandler lockHandler = new LockHandler();
    MockSwingDialog dialog = new MockSwingDialog();
    dialog.setWasSubmitted(false);

    MockUIStrategyImplFactory mockFactory = new MockUIStrategyImplFactory(new MockController(), dialog);

    DialogBlockTestThread t = new DialogBlockTestThread(mockFactory, lockHandler);
    t.start();
    while (!t.started) {
      Thread.sleep(25);
    }
    assertFalse(t.isDoneWithDialog());
    lockHandler.reset();
    t.cancel();
    lockHandler.waitForLock();
    assertTrue(t.isDoneWithDialog());
    t.interrupt();
    t.join();
  }

  private static class DialogBlockTestThread extends Thread {
    private boolean started = false;
    private LockHandler lockHandler;
    private MockUIStrategyImplFactory mockFactory;
    private boolean doneWithDialog = false;

    public DialogBlockTestThread(MockUIStrategyImplFactory mockFactory, LockHandler lockHandler ) {
      this.lockHandler = lockHandler;
      this.mockFactory = mockFactory;
    }

    public synchronized boolean isDoneWithDialog() {
      return doneWithDialog;
    }

    public synchronized void setDoneWithDialog(boolean doneWithDialog) {
      this.doneWithDialog = doneWithDialog;
      lockHandler.releaseLock();
    }

    public void run() {
      super.run();
      try {
        started = true;
//        System.out.println("Test1");
        mockFactory.getStrategyImplementation(new String[]{});
//        System.out.println("Test2");
        setDoneWithDialog(true);
//        System.out.println("Test3");
      } catch (LogRegistrationException e) {
        throw new RuntimeException(e);
      }
    }

    public void cancel() {
      mockFactory.cancel();
    }

    public void submit() {
      mockFactory.submit();
    }
  }

  public void testFactoryGetStratImplBlocksUntilDialogWasSubmitted() throws Exception {
    LockHandler lockHandler = new LockHandler();
    MockSwingDialog dialog = new MockSwingDialog();
    dialog.setWasSubmitted(false);

    MockUIStrategyImplFactory mockFactory = new MockUIStrategyImplFactory(new MockController(), dialog);

    DialogBlockTestThread t = new DialogBlockTestThread(mockFactory, lockHandler);
    t.start();
    while (!t.started) {
      Thread.sleep(25);
    }
    assertFalse(t.isDoneWithDialog());
    lockHandler.reset();
    t.submit();
    lockHandler.waitForLock();
    assertTrue(t.isDoneWithDialog());
    t.interrupt();
    t.join();
  }
  
  public void testGetStratImplDialogCancelledReturnsNull() throws Exception {
    MockSwingDialog dialog = new MockSwingDialog();
    dialog.setCancelled(true);
    UIStrategy impl = new UIStrategyImplFactory(controller, dialog).getStrategyImplementation(new String[]{});

    assertEquals(null, impl);
  }

//  public static void main(String[] args) throws Exception {
//    UIStrategyImplFactory_UT test = new UIStrategyImplFactory_UT();
//    test.testControllerSpike();
//  }

//  public void testControllerSpike() throws Exception {
//    UIStrategy impl = new UIStrategyImplFactory(new SpikeController()).getStrategyImplementation(null);
//    impl.process();
//    Logger.log(new FatalEvent("Just testing"));
//  }

//  private class SpikeController extends MockController {
//    public void run(ParameterSource source) {
//      File input = source.getInputFile();
//      Logger.log(new FatalEvent("input.exists() = " + input.exists()));
//      Logger.log(new FatalEvent("input.length() = " + input.length()));
//      Logger.log(new FatalEvent("input.lastModified() = " + input.lastModified()));
//    }
//  }
}