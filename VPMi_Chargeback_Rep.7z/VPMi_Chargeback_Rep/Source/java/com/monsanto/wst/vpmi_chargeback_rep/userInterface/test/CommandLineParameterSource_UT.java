/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.vpmi_chargeback_rep.userInterface.test;

import com.monsanto.wst.vpmi_chargeback_rep.userInterface.CommandLineParameterSource;
import com.monsanto.wst.vpmi_chargeback_rep.VPMiChargebackData.Month;
import junit.framework.TestCase;

import java.io.File;

/**
 * Filename:    $RCSfile: CommandLineParameterSource_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: zznels $    	 On:	$Date: 2007-11-28 22:11:52 $
 *
 * @author zznels
 * @version $Revision: 1.4 $
 */
public class CommandLineParameterSource_UT extends TestCase {
  private static final String TESTREPORT_XLS =
      "C:\\projects\\VPMi_Chargeback_Rep\\Source\\java\\com\\monsanto\\wst\\vpmi_chargeback_rep\\userInterface\\test\\testReport.xls";


  public void testValidParameters() throws Exception {
    CommandLineParameterSource source = new CommandLineParameterSource(
        new String[]{TESTREPORT_XLS, "Jan", "2007"});

    assertTrue(source.isValid());
    assertEquals(Month.Jan, source.getReportMonth());
    assertEquals(new File(TESTREPORT_XLS), source.getInputFile());
    assertEquals(2007, source.getReportYear());
  }

  public void testInvalidMonthReturnsNullLogsError() throws Exception {
    CommandLineParameterSource source = new CommandLineParameterSource(
        new String[]{TESTREPORT_XLS, "NotAMonth", "2007"});

    assertFalse(source.isValid());
    assertNull(source.getReportMonth());
    assertTrue(source.getErrorMessage().contains("Invalid Month Entered"));
  }

  public void testInvalidYearReturnsNegativeLogsError() throws Exception {
    CommandLineParameterSource source = new CommandLineParameterSource(
        new String[]{TESTREPORT_XLS, "Jan", "abc"});

    assertFalse(source.isValid());
    assertEquals(-1, source.getReportYear());
    assertTrue(source.getErrorMessage().contains("Invalid Year Entered"));
  }

  public void testInvalidFileReturnsNullLogsError() throws Exception {
    CommandLineParameterSource source = new CommandLineParameterSource(
        new String[]{"file.xls", "Jan", "2007"});

    assertFalse(source.isValid());
    assertNull(source.getInputFile());
    assertTrue(source.getErrorMessage().contains("Invalid File Entered"));
  }

  public void testLessThan3ParamsLogsError() throws Exception {
    CommandLineParameterSource source = new CommandLineParameterSource(new String[0]);

    assertFalse(source.isValid());
    assertNull(source.getInputFile());
    assertNull(source.getInputFile());
    assertEquals(-1, source.getReportYear());
    assertTrue(source.getErrorMessage().contains("Invalid Number of Parameters"));
  }

  public void testErrorMessageContainsOnlyOneOfEachMessage() throws Exception {
    CommandLineParameterSource source = new CommandLineParameterSource(
        new String[]{TESTREPORT_XLS, "Jan", "abc"});

    assertFalse(source.isValid());
    assertEquals(-1, source.getReportYear());

    String[] result = source.getErrorMessage().split("Invalid Year Entered");
    assertEquals(2, result.length);
  }
}