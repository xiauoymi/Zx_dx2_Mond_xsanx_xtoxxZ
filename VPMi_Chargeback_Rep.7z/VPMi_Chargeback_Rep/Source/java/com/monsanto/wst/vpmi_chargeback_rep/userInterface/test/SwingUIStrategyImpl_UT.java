/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.vpmi_chargeback_rep.userInterface.test;

import com.monsanto.AbstractLogging.IErrorLog;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.AbstractLogging.Test.MockErrorLog;
import com.monsanto.Util.Exceptions.NullParameterException;
import com.monsanto.wst.vpmi_chargeback_rep.userInterface.SwingUIStrategyImpl;
import com.monsanto.wst.vpmi_chargeback_rep.controller.VPMiController;
import com.monsanto.wst.vpmi_chargeback_rep.controller.test.MockController;
import junit.framework.TestCase;

/**
 * Filename:    $RCSfile: SwingUIStrategyImpl_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: zznels $    	 On:	$Date: 2007-11-13 14:41:10 $
 *
 * @author zznels
 * @version $Revision: 1.2 $
 */
public class SwingUIStrategyImpl_UT extends TestCase {
  private VPMiController controller;


  protected void setUp() throws Exception {
    super.setUp();
    controller = new MockController();
  }
  
//  public void testClickingOKDoesntCloseDialog() throws Exception {
//
//    fail("");
//  }
//
//  public void testClickingOKStartsController() throws Exception {
//    fail();
//  }
//
//  public void testLogMessagesFromControllerAreDisplayed() throws Exception {
//    fail();
//  }

  public void testConstructorDoesNotAcceptNullParams() throws Exception {
    try{
      new SwingUIStrategyImpl(null, controller);
      fail("Should Throw Null Parameter Exception");
    } catch (NullParameterException ex){
      //expected path
    }

    try{
      new SwingUIStrategyImpl(new MockSwingParameterSource(), null);
      fail("Should Throw Null Parameter Exception");
    } catch (NullParameterException ex){
      //expected path
    }
  }

    public void testRegistersLogGivenInAbstractLogger() throws Exception {
    MockErrorLog logger = new MockErrorLog();
    new SwingUIStrategyImpl(new MockSwingParameterSource(), logger, controller);

    Logger.register(new MockErrorLog());
    assertTrue(Logger.isRegistered("Error"));
    //todo: this does not check if MockErrorLog is registered, just if A IErrorLog is registered
    Logger.register((IErrorLog) null);
  }

  public void testLoggerWrittenToIfInvalidParams() throws Exception {
    MockErrorLog log = new MockErrorLog();
    SwingUIStrategyImpl stratImpl = new SwingUIStrategyImpl(new MockSwingParameterSource(), log, controller);

    stratImpl.process();

    assertEquals(1, log.messagesReceived());
    assertTrue(log.hasMessageBeenLoggedContaining(new MockSwingParameterSource().getErrorMessage()));
  }
}