/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.vpmi_chargeback_rep.controller.test;

import com.monsanto.wst.vpmi_chargeback_rep.emailer.VPMiReportEmailer;
import com.monsanto.wst.vpmi_chargeback_rep.VPMiChargebackData.CCOwner;
import com.monsanto.wst.vpmi_chargeback_rep.VPMiChargebackData.Month;

import java.io.File;
import java.io.FileNotFoundException;

/**
 * Filename:    $RCSfile: MockVPMiReportEmailer.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: zznels $    	 On:	$Date: 2007-11-13 22:55:11 $
 *
 * @author zznels
 * @version $Revision: 1.1 $
 */
public class MockVPMiReportEmailer extends VPMiReportEmailer {
  private CCOwner owner;
  private Month month;
  private File report;

  public void sendMessage(CCOwner owner, Month mo, File report) throws FileNotFoundException {
    this.owner = owner;
    this.month = mo;
    this.report = report;
  }

  public CCOwner getOwner() {
    return owner;
  }

  public Month getMonth() {
    return month;
  }

  public File getReport() {
    return report;
  }
}