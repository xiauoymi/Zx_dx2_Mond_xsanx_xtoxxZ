/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.vpmi_chargeback_rep.logging.test;

import com.monsanto.wst.vpmi_chargeback_rep.logging.VPMiSwingLog;
import com.monsanto.wst.vpmi_chargeback_rep.userInterface.test.MockSwingDialog;
import junit.framework.TestCase;

/**
 * Filename:    $RCSfile: VPMiSwingLog_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: zznels $    	 On:	$Date: 2007-11-28 22:11:53 $
 *
 * @author zznels
 * @version $Revision: 1.3 $
 */
public class VPMiSwingLog_UT extends TestCase {

  public void testLogIsOfTypeError() throws Exception {
    assertEquals("Error", new VPMiSwingLog(new MockSwingDialog()).type());
  }

  public void testLogAddsErrorMessageToDialog() throws Exception {
    MockSwingDialog dialog = new MockSwingDialog();
    VPMiSwingLog log = new VPMiSwingLog(dialog);

    log.log("Test Error Message");
    assertEquals("Test Error Message\n", dialog.getLogMessages());
    log.log("Second Test Message");
    assertEquals("Test Error Message\nSecond Test Message\n", dialog.getLogMessages());
  }

}