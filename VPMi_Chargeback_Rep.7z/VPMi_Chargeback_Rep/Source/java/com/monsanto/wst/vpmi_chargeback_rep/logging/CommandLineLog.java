/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.vpmi_chargeback_rep.logging;

import com.monsanto.AbstractLogging.IErrorLog;

/**
 * Filename:    $RCSfile: CommandLineLog.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: zznels $    	 On:	$Date: 2007-11-13 14:41:10 $
 *
 * @author zznels
 * @version $Revision: 1.1 $
 */
public class CommandLineLog implements IErrorLog {
  public void removeLogDevices() {
  }

  public String name() {
    return "CommandLineLog";
  }

  public String type() {
    return "Error";
  }

  public int numLogDevices() {
    return 0;
  }

  public String getLogDeviceType(int j) {
    return null;
  }

  public String getLogDeviceLocation(int j) {
    return null;
  }

  public void log(String cstrMessage) {
    System.out.println(cstrMessage);
  }

  public void close() {
  }
}