package com.monsanto.wst.vpmi_chargeback_rep.servlet;

import com.monsanto.ServletFramework.FormRequestData;

/**
 * <p>Title: MainMenuBean</p>
 * <p>Description: Bean (implementing FormRequestData) to carry data for MainMenu JSP.
 * <p>Copyright: Copyright (c) 2007</p>
 * <p>Company: Monsanto</p>
 * @author Java Framework Code Generator 3.0
 * @version $Id: MainMenuBean.java,v 1.1 2007-06-28 20:06:35 mterry Exp $
 */
public class MainMenuBean implements FormRequestData {
	private String resultMessage = null;
	private boolean result = false;
	private String title = null;
	private String userid = null;
	private String fullName = null;
	private int failedLogonAttempts = -1;
	private String lastLogonDate = null;

	public int getFailedLogonAttempts() {
		return failedLogonAttempts;
	}

	public void setFailedLogonAttempts(int failedLogonAttempts) {
		this.failedLogonAttempts = failedLogonAttempts;
	}

	public String getFullName() {
		return fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

	public String getLastLogonDate() {
		return lastLogonDate;
	}

	public void setLastLogonDate(String lastLogonDate) {
		this.lastLogonDate = lastLogonDate;
	}

	public boolean isResult() {
		return result;
	}

	public void setResult(boolean result) {
		this.result = result;
	}

	public String getResultMessage() {
		return resultMessage;
	}

	public void setResultMessage(String resultMessage) {
		this.resultMessage = resultMessage;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getUserid() {
		return userid;
	}

	public void setUserid(String userid) {
		this.userid = userid;
	}


}
