/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.vpmi_chargeback_rep.VPMiChargebackData;

import java.security.InvalidParameterException;

/**
 * Filename:    $RCSfile: Chargeback.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: zznels $    	 On:	$Date: 2007-12-13 22:53:02 $
 *
 * @author zznels
 * @version $Revision: 1.10 $
 */


public class Chargeback {

  private String Desc;
  private String CO_Code, BA, ACCT, Cost_Center, WBS;
  private double amount;
  private Month month;
  private int year;

  public Chargeback(){}

  public Chargeback(String Full_Cost_Center, String Desc, double amount, Month month, int year) {
    String[] FCC = Full_Cost_Center.split("-");

    if(FCC.length!=4){
      throw new InvalidParameterException("Cost Center Has Invalid Format");
    }

    this.CO_Code = FCC[0];
    this.BA = FCC[1];
    this.ACCT = FCC[2];
    this.Cost_Center = FCC[3];
    this.Desc = Desc;
    this.amount = amount;
    this.month = month;
    this.year = year;
  }

  //Setter Methods
  public void setCO_Code(String code){
    this.CO_Code = code;
  }

  public void setCO_Code(Integer code){
    this.CO_Code = code.toString();
  }

  public void setBA(String ba){
    this.BA = ba;
  }

  public void setBA(Integer ba){
    this.BA = ba.toString();
  }

  public void setACCT(String acct){
    this.ACCT = acct;
  }

  public void setACCT(Integer acct){
    this.ACCT = acct.toString();
  }

  public void setDesc(String desc) {
    this.Desc = desc;
  }

  public void setMonth(String month) {
    this.month = Month.valueOf(month);
  }

  public void setMonth(Month month) {
    this.month = month;
  }

  public void setYear(int year){
    this.year = year;
  }

  public void setAmount(Double amount) {
    this.amount = amount;
  }

  public void setCost_Center(String cc){
    this.Cost_Center = cc;
  }

  public String toString(){
    if(Desc==null)
      return null;
    else
      return(Desc + " " + amount);
  }

  //Getter Methods
  public String getDesc() {
    return Desc;
  }

  public String getCost_Center() {
    return Cost_Center;
  }

  public String getMonth() {
    if (month == null) {
      return "";
    } else {
      return month.toString();
    }
  }

  public int getYear(){
    return year;
  }

  public double getAmount() {
    return amount;
  }

  public String getFullCostCenter() {
    if(CO_Code==null || BA==null || ACCT==null)
      return null;
    else{
      String ret = CO_Code + '-' +
             BA + '-' +
             ACCT + '-';
      if(Cost_Center == null || Cost_Center == ""){
        ret += WBS;
      } else {
        ret += Cost_Center;
      }
      return ret;
    }
  }

  public void setWBS(String wbs) {
    this.WBS = wbs;
  }
}