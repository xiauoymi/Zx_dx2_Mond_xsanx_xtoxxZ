/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.vpmi_chargeback_rep.VPMiChargebackData;

/**
 * Filename:    $RCSfile: CCOwner.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: zznels $    	 On:	$Date: 2007-11-13 14:41:10 $
 *
 * @author zznels
 * @version $Revision: 1.4 $
 */
public class CCOwner {
  private String userID, name;
  private String costCenter;
  private boolean toReceive;
  private String email;

  public String getUserID() {
    return userID;
  }

  public void setUserID(String userID) {
    this.userID = userID;
    setEmail(userID + "@monsanto.com");
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public String getCostCenter() {
    return costCenter;
  }

  public void setCostCenter(String costCenter) {
    this.costCenter = costCenter;
  }

  public boolean isToReceive() {
    return toReceive;
  }

  public String getToReceive() {
    return (toReceive)?"Y":"N";
  }

  public void setToReceive(Boolean toReceive) {
    this.toReceive = toReceive;
  }

  public void setEmail(String email) {
    this.email = email;
  }

  public String getEmail() {
    return email==null ? getUserID() + "@monsanto.com" : email;
  }
}