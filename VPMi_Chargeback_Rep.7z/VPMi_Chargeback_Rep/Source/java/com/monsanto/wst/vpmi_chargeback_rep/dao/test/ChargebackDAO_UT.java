/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.vpmi_chargeback_rep.dao.test;

import junit.framework.TestCase;
import com.monsanto.wst.dbtemplate.test.mock.MockDBTemplate;
import com.monsanto.wst.vpmi_chargeback_rep.dao.ChargebackDAO;
import com.monsanto.wst.vpmi_chargeback_rep.VPMiChargebackData.Chargeback;
import com.monsanto.wst.vpmi_chargeback_rep.VPMiChargebackData.CCOwner;

/**
 * Filename:    $RCSfile: ChargebackDAO_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: zznels $    	 On:	$Date: 2007-10-17 14:31:01 $
 *
 * @author zznels
 * @version $Revision: 1.4 $
 */
public class ChargebackDAO_UT extends TestCase {

  private MockDBTemplate mockTemplate;
  private ChargebackDAO testDAO;

  public void setUp() throws Exception{
    super.setUp();
    mockTemplate = new MockDBTemplate();
    testDAO = new ChargebackDAO(mockTemplate);
  }

  public void testInsertChargebackCallsCorrectFunction() throws Exception {
    testDAO.insertChargeback(new Chargeback());

    assertTrue(mockTemplate.wasStatementNameCalled(ChargebackDAO.INSERT_CHARGEBACK_STATEMENT));
  }

  public void testGetOwnerCallsCorrectFunction() throws Exception {
    testDAO.getOwners("1-2-3-4");

    assertTrue(mockTemplate.wasStatementNameCalled(ChargebackDAO.GET_OWNERS_STATEMENT));
  }

  public void testInsertOwner() throws Exception {
    CCOwner owner = new CCOwner();
    testDAO.insertOwner(owner);

    assertTrue(mockTemplate.wasStatementNameCalled(ChargebackDAO.INSERT_OWNER_STATEMENT));
  }
}