/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.vpmi_chargeback_rep.controller.test;

import com.monsanto.wst.dbtemplate.dao.DBTemplateDaoException;
import com.monsanto.wst.vpmi_chargeback_rep.VPMiChargebackData.Chargeback;
import com.monsanto.wst.vpmi_chargeback_rep.dao.ChargebackDAO;

/**
 * Filename:    $RCSfile: MockChargebackDAO.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: zznels $    	 On:	$Date: 2007-12-13 22:53:02 $
 *
 * @author zznels
 * @version $Revision: 1.2 $
 */
public class MockChargebackDAO extends ChargebackDAO {
  private Chargeback charge;

  public void insertChargeback(Chargeback chargeback) throws DBTemplateDaoException {
    charge = chargeback;
  }

  public Chargeback getInsertedChargeback() {
    return charge;
  }
}