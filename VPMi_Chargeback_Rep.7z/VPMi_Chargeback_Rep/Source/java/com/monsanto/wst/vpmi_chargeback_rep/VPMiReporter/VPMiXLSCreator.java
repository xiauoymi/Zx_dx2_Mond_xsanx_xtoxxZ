/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.vpmi_chargeback_rep.VPMiReporter;

import com.monsanto.wst.vpmi_chargeback_rep.VPMiChargebackData.CCReport;
import com.monsanto.wst.vpmi_chargeback_rep.VPMiChargebackData.Chargeback;
import com.monsanto.wst.vpmi_chargeback_rep.VPMiChargebackData.MonthReport;
import org.apache.poi.hssf.usermodel.*;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

/**
 * Filename:    $RCSfile: VPMiXLSCreator.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: zznels $    	 On:	$Date: 2007-11-13 14:41:10 $
 *
 * Description: This class is responsible for formatting the VPMiReport being created, while deferring the individual
 *              cell styles to the VPMiReportCellStyle object.
 * @author zznels
 * @version $Revision: 1.6 $
 */
public class VPMiXLSCreator {

  private VPMiReportCellStyle cellStyles;

  /**
   * VPMiReportDefaultCellStyle sets up and contains the default cell styles used in writing the report
   * In order to use these styles, you must use the getNewWorkbook function to produce workbooks to write to.
   * (This is because cellstyles are contained within a workbook)
   */
  public VPMiXLSCreator(){
    cellStyles = new VPMiReportDefaultCellStyle();
  }

  public VPMiXLSCreator(VPMiReportCellStyle cellStyles) {
    this.cellStyles = cellStyles;
  }

  /**
   * Function: createReport(MonthReport, HSSFSheet, int)
   * Desc: writes month report to HSSFSheet
   * Limitation: In order to get the cells styled as provided in the VPMiReportCellStyle object
   *             registered in this class, the HSSFSheet passed must be from a workbook created from
   *             the VPMiReportCellStyle registered in this class.
   * @param report: MonthReport to write out
   * @param sheet: HSSFSheet to write to
   * @param rowNum: starts writing at this Row Number
   * @return int: next row number available (row after last one written to)
   */
  public int createMonthReport(MonthReport report, HSSFSheet sheet, int rowNum){
    HSSFRow row;
    HSSFCell cell;

    //Month Title Writing
    row = sheet.createRow(rowNum++);
    cell = row.createCell((short)0);
    cell.setCellStyle(cellStyles.getStyle("monthTitleStyle"));
    cell.setCellValue(report.getMonth()+"");

    //Individual Charge Writing
    for(Chargeback currCharge: report.getCharges()){
      //Charge Desc
      row = sheet.createRow(rowNum++);
      cell = row.createCell((short)0);
      cell.setCellStyle(cellStyles.getStyle("descStyle"));
      cell.setCellValue("  " + currCharge.getDesc());

      setColWidth(currCharge.getDesc(),sheet,(short)0);

      //Charge Amount
      cell = row.createCell((short)1);
      cell.setCellStyle(cellStyles.getStyle("amountStyle"));
      cell.setCellValue(currCharge.getAmount());
    }

    //Month Total Title Writing
    row = sheet.createRow(rowNum++);
    cell = row.createCell((short)0);
    cell.setCellStyle(cellStyles.getStyle("monthTotalStyle"));
    cell.setCellValue(report.getMonth()+" Total");

    setColWidth(report.getMonth()+" Total", sheet, (short)0);

    //Month Total Amount Writing
    cell = row.createCell((short)1);
    cell.setCellStyle(cellStyles.getStyle("monthTotalAmountStyle"));
    cell.setCellValue(report.getTotalCharge());

    setColWidth(report.getTotalCharge()+"", sheet, (short)1);

    return rowNum;
  }

  /**
   * Function: createCCReport(CCReport, HSSFSheet, int)
   * Desc: writes cost center report to HSSFSheet
   * Limitation: In order to get the cells styled as provided in the VPMiReportCellStyle object
   *             registered in this class, the HSSFSheet passed must be from a workbook created from
   *             the VPMiReportCellStyle registered in this class.
   * @param ccReport: CCReport to write out
   * @param sheet: HSSFSheet to write to
   * @param rowNum: starts writing at this Row Number
   * @return int: next row number available (row after last one written to)
   */
  public int createCCReport(CCReport ccReport, HSSFSheet sheet, int rowNum) {
    double totalCharge = 0;

    //Cost Center Title Writing
    HSSFRow row = sheet.createRow(rowNum++);
    HSSFCell cell = row.createCell((short)0);
    cell.setCellStyle(cellStyles.getStyle("ccTitleStyle"));
    cell.setCellValue(ccReport.Cost_Center);

    //Individual Month Report Writing
    for(MonthReport currMonth: ccReport.monthReports){
      rowNum = createMonthReport(currMonth, sheet, rowNum);
      totalCharge += currMonth.getTotalCharge();
    }

    //Cost Center Total Title Writing
    row = sheet.createRow(rowNum++);
    cell = row.createCell((short)0);
    cell.setCellStyle(cellStyles.getStyle("ccTotalStyle"));
    cell.setCellValue(ccReport.Cost_Center + " Total");

    setColWidth(ccReport.Cost_Center + " Total", sheet, (short)0);

    //Cost Center Total Amount Writing
    cell = row.createCell((short)1);
    cell.setCellStyle(cellStyles.getStyle("ccTotalAmountStyle"));
    cell.setCellValue(totalCharge);

    setColWidth(totalCharge+"", sheet, (short)1);

    return rowNum;
  }

  /**
   * Description: sets the column width of a specified column to a size greater than the cellValue text
   * @param cellValue: String text to size entire column to
   * @param sheet: HSSFSheet containing the column
   * @param column: Column number
   */
  private void setColWidth(String cellValue, HSSFSheet sheet, short column){
    int colWidth = sheet.getColumnWidth(column);
    if(colWidth < ((cellValue.length()+5)*256)){
        sheet.setColumnWidth(column, (short)((cellValue.length()+5)*256));
    }
  }

  /**
   * Desc: writes a CCReport to the file specified by filename
   * @param report: CCReport to write out
   * @param filename: path of file to write report to. Created if DNE
   * @throws IOException: Thrown if problem with file path
   */
  public void createReport(CCReport report, String filename) throws IOException {
    File file = new File(filename);
    HSSFWorkbook workbook = cellStyles.getNewWorkbook();
    if(!file.exists()){
      file.createNewFile();
    }
    createCCReport(report, workbook.createSheet(), 0);
    workbook.write(new FileOutputStream(filename));

    FileOutputStream fileStream = new FileOutputStream(filename);
    workbook.write(fileStream);
    fileStream.flush();
    fileStream.close();
  }




}