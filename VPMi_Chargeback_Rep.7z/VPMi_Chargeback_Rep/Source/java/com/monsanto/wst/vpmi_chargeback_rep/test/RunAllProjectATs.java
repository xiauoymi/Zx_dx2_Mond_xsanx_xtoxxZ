/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.vpmi_chargeback_rep.test;

import junit.framework.TestCase;
import junit.framework.Test;
import com.monsanto.testutil.TestCollector;

/**
 *
 * <p>Title: RunAllProjectATs</p>
 * <p>Description: This test runs all Acceptance tests under the project specific package.</p>
 * @author Java Framework Code Generator 3.0
 * @version $Id: RunAllProjectATs.java,v 1.1 2007-06-28 20:06:01 mterry Exp $
 */
public class RunAllProjectATs extends TestCase {
  private static final String AT_TEST_CASE_FILTER = ".+_AT\\.class";


  public static Test suite(){
    TestCollector testCollector =  new TestCollector();
    String[] packages = new String[1];
    packages[0] = "com.monsanto.wst.vpmi_chargeback_rep";
    testCollector.setTestCaseFilter(AT_TEST_CASE_FILTER);
    return testCollector.createSuiteOfTestCases(packages);
  }
}