/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.vpmi_chargeback_rep.controller.test;

import com.monsanto.Util.Exceptions.NullParameterException;
import com.monsanto.wst.vpmi_chargeback_rep.VPMiChargebackData.*;
import com.monsanto.wst.vpmi_chargeback_rep.controller.VPMiChargebackRepController;
import com.monsanto.wst.vpmi_chargeback_rep.dao.ChargebackDAO;
import com.monsanto.wst.vpmi_chargeback_rep.emailer.VPMiReportEmailObject;
import com.monsanto.wst.vpmi_chargeback_rep.emailer.VPMiReportEmailer;
import com.monsanto.wst.vpmi_chargeback_rep.userInterface.ParameterSource;
import com.monsanto.wst.vpmi_chargeback_rep.userInterface.test.MockParameterSource;
import junit.framework.TestCase;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Filename:    $RCSfile: VPMiChargebackRepController_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: zznels $    	 On:	$Date: 2007-11-28 22:11:52 $
 *
 * @author zznels
 * @version $Revision: 1.3 $
 */
public class VPMiChargebackRepController_UT extends TestCase {
  private static final String TEST_COST_CENTER = "1-2-3-4";
  private static final int TEST_YEAR = 2007;

  public void testControllerThrowsExceptionWithNullParam() throws Exception {
    try{
      new VPMiChargebackRepController().run(null);
      fail("Should Throw Null Param Exception");
    } catch (NullParameterException ex){
      //expected path
    }
  }

  public void testReadInputFileReturnsChargebackList() throws Exception {
    File testFile = new File("./com/monsanto/wst/vpmi_chargeback_rep/controller/test/testInputReport.xls");

    final VPMiChargebackRepController vpMiChargebackRepController = new VPMiChargebackRepController();
    List<Chargeback> chargebacks = vpMiChargebackRepController.readInputFile(testFile,
        Month.Jan, 2007);

    assertTrue(chargebacks.size()>0);
    assertEquals("5180-12345-45000999-TEST" , chargebacks.get(0).getFullCostCenter());
  }

  public void testInsertIntoDBCallsDBProperly() throws Exception {

    MockVPMiChargebackRepController controller = new MockVPMiChargebackRepController();
    ParameterSource source = new MockParameterSource();
    controller.run(source);

    MockChargebackDAO dao = controller.getDao();

    assertEquals("a-b-c-d", dao.getInsertedChargeback().getFullCostCenter());
  }

  public void testEmailReportToOwner() throws Exception {
    VPMiChargebackRepController controller = new VPMiChargebackRepController();

    VPMiReportEmailObject emailObject = new VPMiReportEmailObject();
    emailObject.setMonthRep(new MonthReport(Month.Jan));
    CCOwner owner = new CCOwner();
    owner.setEmail("testEmail");
    emailObject.setOwner(owner);
    MockVPMiReportEmailer service = new MockVPMiReportEmailer();
    controller.emailReportToOwner(emailObject, new File("NotImportant.txt"), service);

    assertEquals(Month.Jan , service.getMonth());
    assertEquals("testEmail", service.getOwner().getEmail());
  }

  public void testCreateOneReportMakesReport() throws Exception {
    VPMiChargebackRepController controller = new VPMiChargebackRepController();

    CCReport testReport = new CCReport(TEST_COST_CENTER);
    testReport.addCharge(new Chargeback(TEST_COST_CENTER,"Desc",1234.45,Month.Jan, TEST_YEAR));
    testReport.addCharge(new Chargeback(TEST_COST_CENTER,"Desc2",123.45,Month.Jan, TEST_YEAR));
    String tmpDir = System.getProperty("java.io.tmpdir");

    File resultReport = controller.createOneReport(tmpDir, testReport);

    assertEquals(tmpDir + TEST_COST_CENTER + Month.Jan + ".xls", resultReport.getAbsolutePath());
    assertTrue(resultReport.exists());
  }

  public void testCreateEmailObject() throws Exception {
    VPMiChargebackRepController controller = new VPMiChargebackRepController();

    CCReport testReport = new CCReport(TEST_COST_CENTER);
    testReport.addCharge(new Chargeback(TEST_COST_CENTER,"Desc",1234.45,Month.Jan, TEST_YEAR));
    testReport.addCharge(new Chargeback(TEST_COST_CENTER,"Desc2",123.45,Month.Jan, TEST_YEAR));

    VPMiReportEmailObject emailObject = controller.createEmailObject(testReport);

    assertEquals(Month.Jan, emailObject.getMonthRep().getMonth());
    assertEquals(TEST_COST_CENTER, emailObject.getMonthRep().getCostCenter());
  }

  

  /*********************************Mocks****************************************/
  private class MockVPMiChargebackRepController extends VPMiChargebackRepController{
    private MockChargebackDAO dao;

    public MockChargebackDAO getDao() {
      return dao;
    }

    @SuppressWarnings({"RefusedBequest"})
    public void createAndEmailReports(List<Chargeback> chargebacks, VPMiReportEmailer emailService) {
    }

    @SuppressWarnings({"RefusedBequest"})
    public List<Chargeback> readInputFile(File inputFile, Month reportMonth, int reportYear) throws IOException {
      List<Chargeback> list = new ArrayList<Chargeback>();
      list.add(new Chargeback("a-b-c-d", "testDesc", 123, Month.Jan, 2007));
      return list;
    }

    @SuppressWarnings({"RefusedBequest"})
    protected ChargebackDAO createChargebackDAO() {
      dao = new MockChargebackDAO();
      return dao;
    }
  }

}