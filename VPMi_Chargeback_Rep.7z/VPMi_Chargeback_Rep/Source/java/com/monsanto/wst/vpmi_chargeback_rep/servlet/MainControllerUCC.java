package com.monsanto.wst.vpmi_chargeback_rep.servlet;

import com.monsanto.AbstractLogging.LoggableInfo;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.ServletFramework.UseCaseController;
import com.monsanto.wst.vpmi_chargeback_rep.security.DisplayLogonError;

import java.io.IOException;
import java.util.Date;
import java.text.SimpleDateFormat;

/**
 * <p>Title: MainControllerUCC</p>
 * <p>Description: Use Case Controller for main menu:
 * <p>  1. Populates bean with data from Kerberos
 * <p>  2. Forwards to MainMenu JSP.
 * <p>Copyright: Copyright (c) 2007</p>
 * <p>Company: Monsanto</p>
 * @author Java Framework Code Generator 3.0
 * @version $Id: MainControllerUCC.java,v 1.1 2007-06-28 20:06:35 mterry Exp $
 */
public class MainControllerUCC implements UseCaseController {
	public static final String FORWARD_LOCATION = "/jsp/MainMenu.jsp";
	public static final String SUCCESS_MESSAGE_BASE = "Logon Successful";
	public static final String FAILURE_MESSAGE_BASE = "Logon Failed";
	public static final String TITLE = "Main Menu";

	public void run(UCCHelper helper) throws IOException {
		Logger.traceEntry();
		try {

			MainMenuBean bean = (MainMenuBean) helper.getFormRequestData();
			bean.setTitle(TITLE);
			setupResponseFormData(bean, SUCCESS_MESSAGE_BASE, true, helper);

			helper.forward(FORWARD_LOCATION);

			Logger.traceExit();
		} catch (Exception e) {
			Logger.log(new LoggableInfo("Logon failed: " + e.toString()));
			DisplayLogonError.displayLogonFailed(helper.getPrintWriter(), e.getMessage());
		}
	}

	private void setupResponseFormData(MainMenuBean bean, String resultMessage,
																		 boolean success, UCCHelper helper) {
		bean.setResultMessage(resultMessage);
		bean.setResult(success);
		bean.setUserid(helper.getAuthenticatedUserID());
		bean.setFullName(helper.getAuthenticatedUserFullName());
		bean.setFailedLogonAttempts(helper.getFailedLogonAttempts());
		String lastLogonDate = getLastLogonAsString(helper.getLastLogon());
		bean.setLastLogonDate(lastLogonDate);
	}

	private String getLastLogonAsString(Date lastLogon) {
		SimpleDateFormat format = new SimpleDateFormat("yyyy/MM/dd");
		return format.format(lastLogon);
	}
}
