/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.vpmi_chargeback_rep.userInterface;

/**
 * Filename:    $RCSfile: LockHandler.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: zznels $    	 On:	$Date: 2007-12-04 22:41:22 $
*
* @author zznels
* @version $Revision: 1.1 $
*/
public class LockHandler {
  private Object lockObj = null;

  public void waitForLock() {
    synchronized (this) {
      if (lockObj == null) {
        lockObj = new Object();
      } else {
        throw new RuntimeException("Can't wait multiple times");
      }
    }
//
    try {
      synchronized(lockObj) {
        lockObj.wait();
      }
    } catch (InterruptedException e) {
      throw new RuntimeException(e);
    }
  }

  public void releaseLock() {
    if (lockObj != null) {
      synchronized(lockObj) {
        lockObj.notifyAll();
      }
    }
  }

  public void reset() {
    lockObj = null;
  }
}