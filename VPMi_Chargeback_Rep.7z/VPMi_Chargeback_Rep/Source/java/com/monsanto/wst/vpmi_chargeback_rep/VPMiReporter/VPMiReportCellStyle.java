/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.vpmi_chargeback_rep.VPMiReporter;

import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

/**
 * Filename:    $RCSfile: VPMiReportCellStyle.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: zznels $    	 On:	$Date: 2007-11-13 14:41:10 $
 *
 * @author zznels
 * @version $Revision: 1.1 $
 */
public interface VPMiReportCellStyle {

  //Implementations must contain the following styles
  String CC_TITLE_STYLE = "ccTitleStyle";
  String MONTH_TITLE_STYLE = "monthTitleStyle";
  String MONTH_TOTAL_STYLE = "monthTotalStyle";
  String AMOUNT_STYLE = "amountStyle";
  String DESC_STYLE = "descStyle";
  String CC_TOTAL_STYLE = "ccTotalStyle";
  String MONTH_TOTAL_AMOUNT_STYLE = "monthTotalAmountStyle";
  String CC_TOTAL_AMOUNT_STYLE = "ccTotalAmountStyle";

  HSSFCellStyle getStyle(String styleName);

  HSSFWorkbook getNewWorkbook();
}