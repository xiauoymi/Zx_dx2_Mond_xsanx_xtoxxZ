/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.vpmi_chargeback_rep.userInterface.test;

import com.monsanto.wst.vpmi_chargeback_rep.userInterface.*;
import com.monsanto.wst.vpmi_chargeback_rep.controller.VPMiController;
import com.monsanto.wst.vpmi_chargeback_rep.logging.VPMiSwingLog;
import com.monsanto.AbstractLogging.LogRegistrationException;

/**
 * Filename:    $RCSfile: MockUIStrategyImplFactory.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: zznels $    	 On:	$Date: 2007-12-04 22:41:22 $
 *
 * @author zznels
 * @version $Revision: 1.2 $
 */
public class MockUIStrategyImplFactory extends UIStrategyImplFactory {
  public MockSwingUIStrategyImpl stratImpl;
  private VPMiSwingDialog dialog;

  public MockUIStrategyImplFactory(VPMiController controller, VPMiSwingDialog dialog) {
    super(controller, dialog);
    this.dialog = dialog;
  }

  @SuppressWarnings({"RefusedBequest"})
  protected SwingUIStrategyImpl createSwingUIStrategyImpl(SwingParameterSource source, VPMiSwingLog log,
                                                          VPMiController controller) throws LogRegistrationException {
    this.stratImpl = new MockSwingUIStrategyImpl(source, log, controller);
    return stratImpl;
  }

  public void cancel() {
    dialog.onCancel();
  }

  public void submit() {
    dialog.onOK();
  }
}