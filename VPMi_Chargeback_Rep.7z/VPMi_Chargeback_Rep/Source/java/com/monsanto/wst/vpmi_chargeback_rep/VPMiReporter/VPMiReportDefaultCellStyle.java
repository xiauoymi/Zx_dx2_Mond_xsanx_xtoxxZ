/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.vpmi_chargeback_rep.VPMiReporter;

import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

import java.util.Map;
import java.util.HashMap;

/**
 * Filename:    $RCSfile: VPMiReportDefaultCellStyle.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: zznels $    	 On:	$Date: 2007-11-13 14:41:10 $
 *
 * @author zznels
 * @version $Revision: 1.1 $
 */
public class VPMiReportDefaultCellStyle implements VPMiReportCellStyle {
  private HSSFWorkbook workbook;

  private Map<String, HSSFCellStyle> cellStyleMap;
  private static final String FONT_NAME = "Bookman";


  public VPMiReportDefaultCellStyle() {
    workbook = new HSSFWorkbook();
    cellStyleMap = new HashMap<String, HSSFCellStyle>();
    setCellStyles();
  }

  private void setCellStyles() {
    SetCostCenterTitleFont();

    SetMonthTitleFont();

    SetDescriptionFont();

    SetStandardAmountFont();

    SetMonthlyTotalTitleFont();

    SetCostCenterTotalTitleFont();

    SetMontlyTotalAmount();

    SetCostCenterTotalAmountFont();
  }

  private void SetCostCenterTotalAmountFont() {
    HSSFFont ccTotalAmountFont = workbook.createFont();
    ccTotalAmountFont.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
    ccTotalAmountFont.setFontHeightInPoints((short)11);
    ccTotalAmountFont.setFontName(FONT_NAME);

    HSSFCellStyle ccTotalAmountStyle = workbook.createCellStyle();
    ccTotalAmountStyle.setFont(ccTotalAmountFont);
    ccTotalAmountStyle.setBorderTop(HSSFCellStyle.BORDER_MEDIUM);
    ccTotalAmountStyle.setDataFormat((short)7);

    cellStyleMap.put(CC_TOTAL_AMOUNT_STYLE, ccTotalAmountStyle);
  }

  private void SetMontlyTotalAmount() {
    HSSFFont monthTotalAmountFont = workbook.createFont();
    monthTotalAmountFont.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
    monthTotalAmountFont.setFontName(FONT_NAME);

    HSSFCellStyle monthTotalAmountStyle = workbook.createCellStyle();
    monthTotalAmountStyle.setFont(monthTotalAmountFont);
    monthTotalAmountStyle.setDataFormat((short)7);

    cellStyleMap.put(MONTH_TOTAL_AMOUNT_STYLE, monthTotalAmountStyle);
  }

  private void SetCostCenterTotalTitleFont() {
    HSSFFont ccTotalFont = workbook.createFont();
    ccTotalFont.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
    ccTotalFont.setFontHeightInPoints((short)11);
    ccTotalFont.setFontName(FONT_NAME);

    HSSFCellStyle ccTotalStyle = workbook.createCellStyle();
    ccTotalStyle.setFont(ccTotalFont);
    ccTotalStyle.setBorderTop(HSSFCellStyle.BORDER_MEDIUM);

    cellStyleMap.put(CC_TOTAL_STYLE, ccTotalStyle);
  }

  private void SetMonthlyTotalTitleFont() {
    HSSFFont totalFont = workbook.createFont();
    totalFont.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
    totalFont.setFontName(FONT_NAME);

    HSSFCellStyle monthTotalStyle = workbook.createCellStyle();
    monthTotalStyle.setFont(totalFont);

    cellStyleMap.put(MONTH_TOTAL_STYLE, monthTotalStyle);
  }

  private void SetStandardAmountFont() {
    HSSFFont amountFont = workbook.createFont();
    amountFont.setFontName(FONT_NAME);

    HSSFCellStyle amountStyle = workbook.createCellStyle();
    amountStyle.setFont(amountFont);
    amountStyle.setDataFormat((short)7);

    cellStyleMap.put(AMOUNT_STYLE, amountStyle);
  }

  private void SetDescriptionFont() {
    HSSFFont descFont = workbook.createFont();
    descFont.setFontName(FONT_NAME);

    HSSFCellStyle descStyle = workbook.createCellStyle();
    descStyle.setFont(descFont);

    cellStyleMap.put(DESC_STYLE, descStyle);
  }

  private void SetMonthTitleFont() {
    HSSFFont monthFont = workbook.createFont();
    monthFont.setFontName(FONT_NAME);

    HSSFCellStyle monthTitleStyle = workbook.createCellStyle();
    monthTitleStyle.setFont(monthFont);

    cellStyleMap.put(MONTH_TITLE_STYLE, monthTitleStyle);
  }

  private void SetCostCenterTitleFont() {
    HSSFFont ccFont = workbook.createFont();
    ccFont.setFontHeightInPoints((short)11);
    ccFont.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
    ccFont.setFontName(FONT_NAME);

    HSSFCellStyle ccTitleStyle = workbook.createCellStyle();
    ccTitleStyle.setFont(ccFont);

    cellStyleMap.put(CC_TITLE_STYLE, ccTitleStyle);
  }

  public HSSFCellStyle getStyle(String styleName) {
    return cellStyleMap.get(styleName);
  }

  public HSSFWorkbook getNewWorkbook() {
    workbook = new HSSFWorkbook();
    setCellStyles();
    return workbook;
  }
}