/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.vpmi_chargeback_rep.VPMiReporter.test;

import junit.framework.TestCase;
import com.monsanto.wst.vpmi_chargeback_rep.VPMiChargebackData.*;
import com.monsanto.wst.vpmi_chargeback_rep.VPMiReporter.VPMiReportReaderImpl;
import com.monsanto.wst.vpmi_chargeback_rep.VPMiReporter.VPMiReportReader;
import com.monsanto.wst.vpmi_chargeback_rep.VPMiReporter.VPMiXLSCreator;

import java.io.File;
import java.util.List;

/**
 * Filename:    $RCSfile: VPMiReporter_AT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: zznels $    	 On:	$Date: 2007-11-13 14:41:10 $
 *
 * @author zznels
 * @version $Revision: 1.1 $
 */
public class VPMiReporter_AT extends TestCase {
  private static final int TEST_YEAR = 2007;


  public void testCreateRealFile() throws Exception {
    VPMiXLSCreator testCreator = new VPMiXLSCreator();
    VPMiReportReader repReader = new VPMiReportReaderImpl();
    File testFile = new File("./com/monsanto/wst/vpmi_chargeback_rep/VPMiReporter/test/testReportFullDataSet.xls");
    File outputFile = new File("testOutput.xls");
    outputFile.delete();

    List<Chargeback> testResult = repReader.readReport(testFile);
    DateAssigner.assign(testResult, Month.May, TEST_YEAR);
    List<CCReport> testReports = new CCReportBuilder().parse(testResult);

    testCreator.createReport(testReports.get(2), "testOutput.xls");

    assertTrue(outputFile.exists());
    outputFile.deleteOnExit();
  }

}