function getLookupData(selectedLookup){
    var lookupId = selectedLookup.options[selectedLookup.selectedIndex].value;
    document.forms[0].action="/usseedplanning/servlet/display_lookup.htm?selectedLookup=" + lookupId + "";
    document.forms[0].submit();
}

function preUpdateLookup(type){
    document.forms[0].action="/usseedplanning/servlet/update_lookup.htm?process=" + type + "";
    document.forms[0].submit();
}
function getPlanChannelList(){
	var fromPlan = document.getElementById("fromPlan");
	fromPlan.value = "true";
    document.forms[0].action="/usseedplanning/servlet/generatePlan.htm?";
    document.forms[0].submit();
}
