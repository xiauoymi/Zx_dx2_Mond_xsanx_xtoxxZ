// Create the namespaces in the path if they do not exist.
JSAN.use("Lib.Utils.NamespaceUtils");
Lib.Utils.NamespaceUtils.createIfNecessary("WST.Domain");

WST.Domain.Log = function(xml, objectUtils) {
    this._xml = xml;
    this._objectUtils = objectUtils;
}

WST.Domain.Log.prototype.getFileName = function() {
    var logFileElement = this._xml.getElementsByTagName('logFile')[0];
    return logFileElement.getAttribute('name');
}

WST.Domain.Log.prototype.getLines = function() {
    var lines = new Array();
    var lineElements = this._xml.getElementsByTagName('line');
    for (var i = 0; i < lineElements.length; i++) {
        if (this._objectUtils.isDefined(lineElements[i].firstChild)) {
            lines.push(lineElements[i].firstChild.nodeValue);
        } else {
            lines.push('');
        }
    }
    return lines;
}