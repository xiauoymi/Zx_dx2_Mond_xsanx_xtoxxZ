// Create the namespaces in the path if they do not exist.
JSAN.use("Lib.Utils.NamespaceUtils");
Lib.Utils.NamespaceUtils.createIfNecessary("WST.Model");

WST.Model.LogFileListModel = function(service, objectUtils) {
    this._service = service;
    this._objectUtils = objectUtils;
    this._listeners = new Array();
    this._logFiles = new Array();
    this._registerServiceListener();
}

WST.Model.LogFileListModel.prototype.loadLogFileList = function() {
    this._service.executeCommand('lookupLogFileList');
}

WST.Model.LogFileListModel.prototype.parseLogFileList = function(response) {
    var logFileListElement = response.getElementsByTagName('logFileList')[0];
    if (typeof logFileListElement != 'undefined' && logFileListElement != null) {
        var logFileElements = logFileListElement.getElementsByTagName('logFile');
        for (var i = 0; i < logFileElements.length; i++) {
            this._parseLogFile(logFileElements[i]);
        }
        this._notifyListeners();
    }
}

WST.Model.LogFileListModel.prototype.getLogFiles = function() {
    return this._logFiles;
}

WST.Model.LogFileListModel.prototype.registerListener = function(listener) {
    this._listeners.push(listener);
}

WST.Model.LogFileListModel.prototype._registerServiceListener = function() {
    var reference = this._objectUtils.weakBind(this.parseLogFileList, this);
    this._service.addProcessor('lookupLogFileList', reference);
}

WST.Model.LogFileListModel.prototype._parseLogFile = function(element) {
    this._logFiles.push(element.firstChild.nodeValue);
}

WST.Model.LogFileListModel.prototype._notifyListeners = function() {
    for (var i = 0; i < this._listeners.length; i++) {
        this._listeners[i](this._logFiles);
    }
}