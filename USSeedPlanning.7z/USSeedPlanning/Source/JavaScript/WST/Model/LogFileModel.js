// Create the namespaces in the path if they do not exist.
JSAN.use("Lib.Utils.NamespaceUtils");
JSAN.use('WST.Domain.Log');
Lib.Utils.NamespaceUtils.createIfNecessary("WST.Model");

WST.Model.LogFileModel = function(service, objectUtils) {
    this._service = service;
    this._objectUtils = objectUtils;
    this._listeners = new Array();
    this._log;
    this._registerWithService(service, objectUtils);
}

WST.Model.LogFileModel.prototype.registerListener = function(listener) {
    this._listeners.push(listener);
}

WST.Model.LogFileModel.prototype.registerStatusMessageListener = function(listener) {
    this._service.addStatusMessageListener('lookupLogFile', listener);
}

WST.Model.LogFileModel.prototype.lookupLogFile = function(logFileName) {
    var paramMap = {};
    paramMap['logFileName'] = logFileName;
    this._service.executeCommand('lookupLogFile', paramMap);
}

WST.Model.LogFileModel.prototype.createLog = function(response) {
    this._log = new WST.Domain.Log(response, this._objectUtils);
    this._notifyListeners();
}

WST.Model.LogFileModel.prototype._registerWithService = function(service, objectUtils) {
    var reference = objectUtils.weakBind(this.createLog, this);
    service.addProcessor('lookupLogFile', reference);
}

WST.Model.LogFileModel.prototype._notifyListeners = function() {
    for (var i = 0; i < this._listeners.length; i++) {
        this._listeners[i](this._log);
    }
}

