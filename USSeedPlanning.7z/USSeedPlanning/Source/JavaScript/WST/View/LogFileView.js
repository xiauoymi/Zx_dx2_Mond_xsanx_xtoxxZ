// Create the namespaces in the path if they do not exist.
JSAN.use("Lib.Utils.NamespaceUtils");
JSAN.use('Lib.Utils.ObjectUtils');
JSAN.use('Lib.Service.View.ServiceDisplayManager');
Lib.Utils.NamespaceUtils.createIfNecessary("WST.View");

WST.View.LogFileView = function(targetElement, xmlUtils, model, statusMessageStyles) {
    var infoElement = cssQuery('#info', targetElement)[0];
    Lib.Service.View.ServiceDisplayManager.call(
            this,
            infoElement,
            xmlUtils,
            'Loading Log File',
            statusMessageStyles);
    this._infoContainer = targetElement;
    this._xmlUtils = xmlUtils;
    this._registerWithModel(model);
}

// This defines that EmployeeIndexView is a subclass of ServiceDisplayManager.
Lib.Utils.ObjectUtils.extend(WST.View.LogFileView.prototype, Lib.Service.View.ServiceDisplayManager.prototype);

WST.View.LogFileView.prototype.createLog = function(log) {
    var header = cssQuery('#infoHeader', this._infoContainer)[0];
    if (Lib.Utils.ObjectUtils.isDefined(header.firstChild)) {
        header.firstChild.nodeValue = log.getFileName();
    } else {
        header.appendChild(document.createTextNode(log.getFileName()));
    }

    this.clear();
    var lines = log.getLines();
    var logElement = document.createElement('p');
    logElement.id = 'log'
    for (var i = 0; i < lines.length; i++) {
        logElement.appendChild(document.createTextNode(lines[i]));
        logElement.appendChild(document.createElement('br'));
    }
    this.cacheElement(logElement);
    this.commit();
}

WST.View.LogFileView.prototype._registerWithModel = function(model) {
    var reference = Lib.Utils.ObjectUtils.weakBind(this.createLog, this);
    model.registerListener(reference);
    reference = Lib.Utils.ObjectUtils.weakBind(this.displayStatusMessage, this);
    model.registerStatusMessageListener(reference);
}