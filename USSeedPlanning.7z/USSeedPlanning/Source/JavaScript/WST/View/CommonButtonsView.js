// Create the namespaces in the path if they do not exist.
JSAN.use("Lib.Utils.NamespaceUtils");
JSAN.use('Lib.Utils.ObjectUtils');
Lib.Utils.NamespaceUtils.createIfNecessary("WST.View");

WST.View.CommonButtonsView = function(template, containerElement) {
  this._template = template;
  this._containerElement = containerElement;
}

WST.View.CommonButtonsView.prototype.attachCommonButtons = function() {
  var element = this._template.getRootElement();
  if (Lib.Utils.ObjectUtils.isDefined(this._containerElement)) {
    this._containerElement.appendChild(element);
  }
}
