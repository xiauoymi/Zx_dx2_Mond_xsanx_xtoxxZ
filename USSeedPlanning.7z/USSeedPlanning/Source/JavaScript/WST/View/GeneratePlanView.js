// Create the namespaces in the path if they do not exist.
JSAN.use("Lib.Utils.NamespaceUtils");
JSAN.use("WST.Event.GeneratePlan.UpdateSelectedRevisionsEvent");
Lib.Utils.NamespaceUtils.createIfNecessary("WST.View");

/**
* author: Nate Minshew
* date created: 11/22/2006
* description:
*   This object is a view object for the generate plan page.  It is used to interact with the page and bind events
*   to elements on the page.
*/
WST.View.GeneratePlanView = function() {
  this._formElement = document.getElementById('generatePlanForm');
  this._attachUpdateSelectedRevisionsEvent();
}

/**
* author: Nate Minshew
* date created: 11/22/2006
* access level: private
* description:
*   This method attaches the update selected revision event to the appropriate element on the page.
*/
WST.View.GeneratePlanView.prototype._attachUpdateSelectedRevisionsEvent = function() {
  var planSelectElement = cssQuery('#plan_id', this._formElement)[0];
  var event = new WST.Event.GeneratePlan.UpdateSelectedRevisionsEvent(this._formElement, this);
  event.attachEvent(planSelectElement, 'change');
}

/**
* author: Nate Minshew
* date created: 11/22/2006
* access level: public
* description:
*   This method resets the method input field to empty.
*/
WST.View.GeneratePlanView.prototype.resetMethod = function() {
  var methodElement = cssQuery('#method', this._formElement)[0];
  methodElement.value = '';
}