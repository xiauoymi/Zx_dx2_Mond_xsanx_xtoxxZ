// Create the namespaces in the path if they do not exist.
JSAN.use("Lib.Utils.NamespaceUtils");
JSAN.use('WST.Event.CriteriaEvent.LookupLogEvent');
JSAN.use('WST.Event.CriteriaEvent.ResetLogListEvent');
Lib.Utils.NamespaceUtils.createIfNecessary("WST.View");

WST.View.LogFileListView = function(baseElement, xmlUtils, objectUtils, logFileListModel, logFileModel, eventHandler) {
    this._baseElement = baseElement;
    this._xmlUtils = xmlUtils;
    this._objectUtils = objectUtils;
    this._registerWithModel(logFileListModel);
    this._attachOpenButtonEvent(eventHandler, logFileModel);
    this._attachResetButtonEvent(eventHandler);
}

WST.View.LogFileListView.prototype.addLogFiles = function(logFiles) {
    var viewLogElement = cssQuery('#logFileName', this._baseElement)[0];
    this._xmlUtils.removeAllChildren(viewLogElement);
    for (var i = 0; i < logFiles.length; i++) {
        var option = document.createElement('option');
        option.value = logFiles[i];
        option.appendChild(document.createTextNode(logFiles[i]));
        viewLogElement.appendChild(option);
    }
    viewLogElement.options[0].selected = 'selected';
}

WST.View.LogFileListView.prototype._registerWithModel = function(model) {
    var reference = this._objectUtils.weakBind(this.addLogFiles, this);
    model.registerListener(reference);
}

WST.View.LogFileListView.prototype._attachOpenButtonEvent = function(eventHandler, logFileModel) {
    var openButton = cssQuery('#openButton', this._baseElement)[0];
    var selectElement = cssQuery('#logFileName', this._baseElement)[0];
    var event = new WST.Event.CriteriaEvent.LookupLogEvent(selectElement, logFileModel, eventHandler);
    event.attachEvent(openButton, 'click');
}

WST.View.LogFileListView.prototype._attachResetButtonEvent = function(eventHandler) {
    var resetButton = cssQuery('#resetButton', this._baseElement)[0];
    var selectElement = cssQuery('#logFileName', this._baseElement)[0];
    var event = new WST.Event.CriteriaEvent.ResetLogListEvent(selectElement, eventHandler);
    event.attachEvent(resetButton, 'click');
}