// Create the namespaces in the path if they do not exist.
JSAN.use("Lib.Utils.NamespaceUtils");
Lib.Utils.NamespaceUtils.createIfNecessary("WST.Event.CriteriaEvent");

WST.Event.CriteriaEvent.ResetLogListEvent = function(selectElement, eventHandler) {
    this._eventHandler = eventHandler;
    this._selectElement = selectElement;
}

WST.Event.CriteriaEvent.ResetLogListEvent.prototype.attachEvent = function(element, type) {
    this._eventHandler.addEvent(element, type, this.executeEvent, this);
}

WST.Event.CriteriaEvent.ResetLogListEvent.prototype.executeEvent = function(evt) {
    this._eventHandler.cancelDefaultAction(evt);
    this._selectElement.selectedIndex = 0;
}