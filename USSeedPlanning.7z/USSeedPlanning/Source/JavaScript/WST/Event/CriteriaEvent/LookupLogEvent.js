// Create the namespaces in the path if they do not exist.
JSAN.use("Lib.Utils.NamespaceUtils");
Lib.Utils.NamespaceUtils.createIfNecessary("WST.Event.CriteriaEvent");

WST.Event.CriteriaEvent.LookupLogEvent = function(targetElement, logFileModel, eventHandler) {
    this._eventHandler = eventHandler;
    this._targetElement = targetElement;
    this._logFileModel = logFileModel;
}

WST.Event.CriteriaEvent.LookupLogEvent.prototype.attachEvent = function(element, type) {
    this._eventHandler.addEvent(element, type, this.executeEvent, this);
}

WST.Event.CriteriaEvent.LookupLogEvent.prototype.executeEvent = function(evt) {
    this._eventHandler.cancelDefaultAction(evt);
    var fileName = this._targetElement.options[this._targetElement.selectedIndex].value;
    this._logFileModel.lookupLogFile(fileName);
}