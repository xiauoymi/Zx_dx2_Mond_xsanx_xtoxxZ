// Create the namespaces in the path if they do not exist.
JSAN.use("Lib.Utils.NamespaceUtils");
JSAN.use("Lib.Utils.EventUtils");
Lib.Utils.NamespaceUtils.createIfNecessary("WST.Event.GeneratePlan");

/**
* author: Nate Minshew
* date created: 11/22/2006
* description:
*   This object is a redirect implementation of the update selected revisions event.  It submits the current form when
*   a plan is selected so that the revision drop downs will be populated with the revisions associated with that plan.
*
* @param formElement - Element representing the form.
* @param generatePlanView - View object for the generate plan page.
*/
WST.Event.GeneratePlan.RedirectUpdateSelectedRevisionsEvent = function(formElement, generatePlanView) {
  this._formElement = formElement;
  this._generatePlanView = generatePlanView;
}

/**
* author: Nate Minshew
* date created: 11/22/2006
* access level: public
* description:
*   This method attachs this event to the specified element with the specified event type.
*
* @param element - Html element to attach event to.
* @param type - Type of event to attach, ie. click, change, etc.
*/
WST.Event.GeneratePlan.RedirectUpdateSelectedRevisionsEvent.prototype.attachEvent = function(element, type) {
  Lib.Utils.EventUtils.addEvent(element, type, this.executeEvent, this);
}

/**
* author: Nate Minshew
* date created: 11/22/2006
* access level: public
* description:
*   This method executes the event.
*
* @param event - Implicit native event object.
*/
WST.Event.GeneratePlan.RedirectUpdateSelectedRevisionsEvent.prototype.executeEvent = function(event) {
  this._generatePlanView.resetMethod();
  this._formElement.submit();
}