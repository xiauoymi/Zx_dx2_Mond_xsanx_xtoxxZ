JSAN.addRepository('JavaScript');
JSAN.addRepository('../JavaScript');
JSAN.use('Lib.Utils.EventUtils');
JSAN.use('Lib.Utils.ObjectUtils');
JSAN.use('Lib.Utils.NamespaceUtils');

JSAN.use('WST.View.GeneratePlanView');
JSAN.use('WST.Event.GeneratePlan.RedirectUpdateSelectedRevisionsEvent');

// Load the main object when the page loads.
Lib.Utils.EventUtils.addEvent(window, 'load', initializeGeneratePlanMain);
// Clear the context objects to prevent memory leaks when the page unloads.
Lib.Utils.EventUtils.addEvent(window, 'unload', clearCtx);

/**
 * author: Nate Minshew
 * date created: 07/05/2006
 * access level: global
 * description:
 *   This method instantiates the GeneratePlanMain object and then calls initialize.
 */
function initializeGeneratePlanMain() {
  var main = new GeneratePlanMain();
  main.initialize();
}

/**
 * author: Nate Minshew
 * date created: 07/05/2006
 * access level: global
 * description:
 *   This method clears the cached context objects.
 */
function clearCtx() {
  Lib.Utils.ObjectUtils.clearContextObjects();
}

/**
* author: Nate Minshew
* date created: 11/22/2006
* @constructor
* description:
*   This object is the main object for the generate plan page.  It creates all objects that will be used by the page and
*   sets up what implementations will be used.
*/
GeneratePlanMain = function() {
}

/**
* author: Nate Minshew
* date created: 11/22/2006
* access level: public
* description:
*   This method initializes the generate plan page creating any needed objects and defining what implementations will
*   be used.
*/
GeneratePlanMain.prototype.initialize = function() {
  this._assignImplementations();
  new WST.View.GeneratePlanView();
}

/**
* author: Nate Minshew
* date created: 11/22/2006
* access level: private
* description:
*   This method assigns implementations to abstractions. 
*/
GeneratePlanMain.prototype._assignImplementations = function() {
  WST.Event.GeneratePlan.UpdateSelectedRevisionsEvent = WST.Event.GeneratePlan.RedirectUpdateSelectedRevisionsEvent;
}