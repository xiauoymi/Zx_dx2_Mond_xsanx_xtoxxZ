JSAN.addRepository('JavaScript');
JSAN.addRepository('../JavaScript');
JSAN.use('Lib.Utils.EventUtils');
JSAN.use('Lib.Utils.XML.XMLUtils');
JSAN.use('Lib.Utils.XML.AjaxUtils');
JSAN.use('Lib.Utils.ObjectUtils');

JSAN.use('Lib.View.Template');

JSAN.use('WST.Utils.DateUtils');
JSAN.use('WST.View.FormView');
JSAN.use('WST.View.CommonButtonsView');

// Load the main object when the page loads.
Lib.Utils.EventUtils.addEvent(window, 'load', createUSSeedMain);
// Clear the context objects to prevent memory leaks when the page unloads.
Lib.Utils.EventUtils.addEvent(window, 'unload', clearCtx);

/**
* author: Nate Minshew
* date created: 07/05/2006
* access level: global
* description:
*   This method instantiates the USSeedMain object.
*/
function createUSSeedMain() {
    new USSeedMain();
}

/**
* author: Nate Minshew
* date created: 07/05/2006
* access level: global
* description:
*   This method clears the cached context objects.
*/
function clearCtx() {
    Lib.Utils.ObjectUtils.clearContextObjects();
}

/**
* author: Nate Minshew
* date created: 07/05/2006
* @constructor
* description:
*   This object is the main object for the TTS application.  It handles wiring up all global events.
*/
USSeedMain = function() {
    var dateUtils = this._createDateUtils();
    var formView = this._createFormView();
    var commonButtonsTemplate = this._createTemplate('commonButtons');
    //debug(commonButtonsTemplate.getRootElement().outerHTML);
    var commonButtonsView = this._createCommonButtonsView(commonButtonsTemplate);
    commonButtonsView.attachCommonButtons();
}

/**
* author: Nate Minshew
* date created: 07/05/2006
* access level: private
* description:
*   This method creates a date utils object.
*/
USSeedMain.prototype._createDateUtils = function() {
    return new WST.Utils.DateUtils();
}

/**
* author: Nate Minshew
* date created: 07/27/2006
* access level: private
* description:
*   This method creates the form view object.
*/
USSeedMain.prototype._createFormView = function() {
    return new WST.View.FormView(Lib.Utils.XML.XMLUtils, Lib.Utils.ObjectUtils);
}

USSeedMain.prototype._createCommonButtonsView = function(template) {
    var element = cssQuery('.commonButtonsContainer')[0];
    return new WST.View.CommonButtonsView(template, element);
}

USSeedMain.prototype._createTemplate = function(id) {
    return new Lib.View.Template(Lib.Utils.XML.AjaxUtils, this._getTemplateUrl(), id, Lib.Utils.ObjectUtils);
}

USSeedMain.prototype._getTemplateUrl = function() {
    return BASE_URL + "/JavaScript/templates/template.html";
}