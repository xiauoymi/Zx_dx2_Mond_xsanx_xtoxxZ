JSAN.addRepository('JavaScript');
JSAN.addRepository('../JavaScript');
JSAN.use('Lib.Adapters.EventHandler');
JSAN.use('Lib.Utils.XML.XMLUtils');
JSAN.use('WST.Model.LogFileListModel');
JSAN.use('WST.View.LogFileListView');
JSAN.use('Lib.Utils.ObjectUtils');
JSAN.use('Lib.Service.AJAX.AJAXParameterDispatchService');
JSAN.use('Lib.Utils.XML.AjaxUtils');
JSAN.use('WST.Model.LogFileModel');
JSAN.use('WST.View.LogFileView');
JSAN.use('Lib.Service.View.StatusMessageStyles');

if (JSAN.errorMessage != "") {
    alert(JSAN.errorMessage);
}

// create a new BioBookFilterMain js object when the page loads.
var eventHandler = Lib.Adapters.EventHandler;
eventHandler.addEvent(
    window,
    'load',
    function() {
        new AdminMain();
    });
eventHandler.addEvent(window, 'unload', function() { Lib.Utils.ObjectUtils.clearContextObjects() });

AdminMain = function() {
    var url = document.getElementById('adminForm').action;

    this._applyNiftyCorners();
    var service = this._createService(url);
    var logFileListModel = this._createLogFileListModel(service);
    var logFileModel = this._createLogFileModel(service);
    var logFileListView = this._createLogFileListView(logFileListModel, logFileModel);
    var logFileView = this._createLogFileView(logFileModel);

    logFileListModel.loadLogFileList();
}

AdminMain.prototype._applyNiftyCorners = function() {
    if (typeof NiftyCheck != 'undefined' && NiftyCheck()) {
        this._applyLeftColumnCorners();
        this._applyRightColumnCorners();
    }
}

/**
* author: Nate Minshew (NJMINSH)
* date created: 01/04/2006
* access level: non-public
* description:
*   This method applies nifty corners to the elements on the left column of the page.
*/
AdminMain.prototype._applyLeftColumnCorners = function() {
    var infoOptions = document.getElementById('infoOptions');
    this._createNiftyContainerLeftColumn(infoOptions);
    Rounded("div.niftyContainerLeft", "tr", "#CCC", "#EEE", "smooth");
    Rounded("div.niftyContainerLeft", "br", "#CCC", "#EEE", "smooth");
}

/**
* author: Nate Minshew (NJMINSH)
* date created: 12/19/2005
* access level: private
* description:
*   This method applies a rounded corner container to the specified element on the left column.
*
* @param element - Page element that needs rounded corners.
*/
AdminMain.prototype._createNiftyContainerLeftColumn = function(element) {
    var niftyContainer = document.createElement('div');
    niftyContainer.className = 'niftyContainerLeft';
    Lib.Utils.XML.XMLUtils.insertBefore(niftyContainer, element);
    element.parentNode.removeChild(element);
    niftyContainer.appendChild(element);
}

/**
* author: Nate Minshew (NJMINSH)
* date created: 01/04/2006
* access level: non-public
* description:
*   This method applies nifty corners to the elements on the right column of the page.
*/
AdminMain.prototype._applyRightColumnCorners = function() {
    var infoContainer = document.getElementById('infoContainer');
    this._createNiftyContainerRightColumn(infoContainer);
    Rounded("div.niftyContainerRight", "tl", "#CCC", "#EEE", "smooth");
    Rounded("div.niftyContainerRight", "bl", "#CCC", "#EEE", "smooth");
}

/**
* author: Nate Minshew (NJMINSH)
* date created: 12/19/2005
* access level: private
* description:
*   This method applies a rounded corner container to the specified element on the right column.
*
* @param element - Page element that needs rounded corners.
*/
AdminMain.prototype._createNiftyContainerRightColumn = function(element) {
    var niftyContainer = document.createElement('div');
    niftyContainer.className = 'niftyContainerRight';
    Lib.Utils.XML.XMLUtils.insertBefore(niftyContainer, element);
    element.parentNode.removeChild(element);
    niftyContainer.appendChild(element);
}

AdminMain.prototype._createService = function(url) {
    return new Lib.Service.AJAX.AJAXParameterDispatchService(
            url,
            Lib.Utils.XML.AjaxUtils,
            Lib.Utils.ObjectUtils.ArrayUtils,
            'method',
            Lib.Utils.ObjectUtils);
}

AdminMain.prototype._createLogFileListModel = function(service) {
    return new WST.Model.LogFileListModel(service, Lib.Utils.ObjectUtils);
}

AdminMain.prototype._createLogFileListView = function(logFileListModel, logFileModel) {
    var infoOptionsElement = document.getElementById('infoOptions');
    return new WST.View.LogFileListView(infoOptionsElement, Lib.Utils.XML.XMLUtils, Lib.Utils.ObjectUtils, logFileListModel, logFileModel, eventHandler);
}

AdminMain.prototype._createLogFileModel = function(service) {
    return new WST.Model.LogFileModel(service, Lib.Utils.ObjectUtils);
}

AdminMain.prototype._createLogFileView = function(logFileModel) {
    var infoContainer = document.getElementById('infoContainer');
    var styles = this._createLogFileStatusStyles();
    return new WST.View.LogFileView(infoContainer, Lib.Utils.XML.XMLUtils, logFileModel, styles);
}

AdminMain.prototype._createLogFileStatusStyles = function() {
    return new Lib.Service.View.StatusMessageStyles(
            'statusContainer',
            'statusHeader',
            'status1',
            'status2',
            'status3',
            'status4',
            'activeStatus',
            'errorStatus',
            'statusTextBlock',
            'statusText',
            'close',
            'statusMessageTitleBar');
}
