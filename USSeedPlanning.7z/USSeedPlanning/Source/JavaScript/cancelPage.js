function cancelAction(type){
	document.forms[0].action="/usseedplanning/servlet/maintenance.htm";
	document.forms[0].submit();
}