function updatePickListsFormSubmit(submitTo) {
      document.forms[0].action = submitTo;
      document.forms[0].submit();
    }
