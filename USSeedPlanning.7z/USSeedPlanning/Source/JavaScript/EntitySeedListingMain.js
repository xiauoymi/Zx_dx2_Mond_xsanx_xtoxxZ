JSAN.addRepository('JavaScript');
JSAN.addRepository('../JavaScript');
JSAN.use('Lib.Utils.EventUtils');
JSAN.use('Lib.Utils.XML.XMLUtils');
JSAN.use('Lib.Utils.ObjectUtils');

JSAN.use('WST.View.FooterView');
JSAN.use('WST.Utils.DateUtils');
JSAN.use('WST.View.FormView');

// Load the main object when the page loads.
Lib.Utils.EventUtils.addEvent(window, 'load', getAllYears);

function getAllYears(object){
	var queryString = window.location.href;
	if(queryString.match("/servlet/buildBaseEntity.htm") != null){
        document.forms[0].action=CONTEXT_ROOT + "/servlet/listEntities.htm?selectedYear=ALL";
	    document.forms[0].submit();
	}
}
function getEntityList(selectedYear){
    var year = selectedYear.options[selectedYear.selectedIndex].value;
    document.forms[0].action=CONTEXT_ROOT + "/servlet/listEntities.htm?selectedYear=" + year + "";
    document.forms[0].submit();
}

function createNewSeedEntity(){
    document.forms[0].action=CONTEXT_ROOT + "/servlet/preDisplayEntity.htm";
    document.forms[0].submit();
}