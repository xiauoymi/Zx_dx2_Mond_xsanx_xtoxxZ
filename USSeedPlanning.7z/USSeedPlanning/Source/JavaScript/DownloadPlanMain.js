JSAN.addRepository('JavaScript');
JSAN.addRepository('../JavaScript');
JSAN.use('Lib.Utils.EventUtils');
JSAN.use('Lib.Utils.DocumentUtils');
JSAN.use('Lib.Utils.ObjectUtils');

// Load the main object when the page loads.
Lib.Utils.EventUtils.addEvent(window, 'load', initializeDownloadPlanMain);
// Clear the context objects to prevent memory leaks when the page unloads.
Lib.Utils.EventUtils.addEvent(window, 'unload', clearCtx);

/**
 * author: Nate Minshew
 * date created: 07/05/2006
 * access level: global
 * description:
 *   This method instantiates the GeneratePlanMain object and then calls initialize.
 */
function initializeDownloadPlanMain() {
    new DownloadPlanMain();
}

/**
 * author: Nate Minshew
 * date created: 07/05/2006
 * access level: global
 * description:
 *   This method clears the cached context objects.
 */
function clearCtx() {
    Lib.Utils.ObjectUtils.clearContextObjects();
}

DownloadPlanMain = function() {
    document.getElementById('downloadPlanForm').submit();
    this._currentIndex = 0;
    this._changeBarReference = Lib.Utils.ObjectUtils.weakBind(this._changeBar, this);
    this._changeBar();
}

DownloadPlanMain.prototype._changeBar = function() {
    if (cssQuery('span.filledBar').length > 0) {
        var previous = cssQuery('span.filledBar')[0];
        Lib.Utils.DocumentUtils.removeClass(previous, 'filledBar');
    }
    var barElement = cssQuery('span.bar')[this._currentIndex];
    Lib.Utils.DocumentUtils.addClass(barElement, 'filledBar');
    this._incrementIndex();
    setTimeout(this._changeBarReference, 1000);
}

DownloadPlanMain.prototype._incrementIndex = function() {
    if (this._currentIndex == 3) {
        this._currentIndex = 0;
    } else {
        this._currentIndex = this._currentIndex + 1;
    }
}