/*
 Copyright:  Copyright � 2006 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package test;

import com.monsanto.testutil.TestCollector;

import java.io.File;
import java.io.FilenameFilter;

/**
 * Filename:    $RCSfile: Filter.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: njminsh $    	 On:	$Date:
 * 2006/10/20 13:46:21 $
 *
 * @author jdpoul
 * @version $Revision: 1.1 $
 */
public class Filter extends TestCollector {


  public Filter() {
    super();
  }

  protected FilenameFilter getTestCaseFilter() {
    return new FilenameFilter() {
      public boolean accept(File dir, String name) {
        boolean accept = name.matches(s_testCaseFilter) || name.matches(".+UT\\.class");
        if (accept) {
          accept = (!name.matches(".+Collector_UT\\.class"));
        }
        return accept;
      }
    };
  }


}