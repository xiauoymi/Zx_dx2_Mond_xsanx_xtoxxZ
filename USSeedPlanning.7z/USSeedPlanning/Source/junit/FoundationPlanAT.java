package test;

import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.ServletFramework.UseCaseController;
import com.monsanto.wst.commonutils.resources.ResourceUtils;
import com.monsanto.wst.dbtemplate.DBTemplate;
import com.monsanto.wst.dbtemplate.transaction.TransactionManager;
import com.monsanto.wst.dbtemplate.dao.DBTemplateNoResultsException;
import com.monsanto.wst.factory.AbstractGenericFactory;
import com.monsanto.wst.usseedplanning.constants.MainConstants;
import com.monsanto.wst.usseedplanning.model.core.LoginUser;
import com.monsanto.wst.usseedplanning.model.planning.Plan;
import com.monsanto.wst.usseedplanning.model.planning.PlanType;
import com.monsanto.wst.usseedplanning.utils.testutils.USSeedPlanningBaseTransactionTestCase;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * Created by IntelliJ IDEA.
 * Date: Oct 31, 2006
 * Time: 3:29:05 PM
 * <p/>
 * Integration test for generating a snap shot of the current Foundation plan.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class FoundationPlanAT extends USSeedPlanningBaseTransactionTestCase {
    private String outputPath = "";
    private File planFile;

    protected void setUp() throws Exception {
        super.setUp();
        System.setProperty("lsi.function", "test");
        File directory = new ResourceUtils().convertPathToFile(this.outputPath);
        String date = new SimpleDateFormat("yyyy-MM-dd").format(new Date());
        this.planFile = new File(directory.getAbsolutePath() + "/FoundationPlan_" + date + ".xls");
        this.planFile.delete();
        this.planFile.createNewFile();
    }

    protected String getConfigPath() {
        return "com/monsanto/wst/commonutils/dbunit/emptyDataSet.xml";
    }

    protected void cleanDatabase(TransactionManager txManager) {
    }

    public void testGenerateFoundationPlan() throws Exception {
        UseCaseController controller = (UseCaseController) AbstractGenericFactory.getInstance().getBean("planController");
        MockUCCHelper helper = setupRequest();
        controller.run(helper);
        assertNotNull(helper.getRequestAttributeValue("plan"));
        Plan plan = (Plan) helper.getRequestAttributeValue("plan");
        writeFile(plan.toByteArray());
    }

    private void writeFile(byte[] bytes) throws IOException {
        FileOutputStream stream = new FileOutputStream(planFile);
        stream.write(bytes);
        stream.close();
    }

    private MockUCCHelper setupRequest() throws Exception {
        List demandCriteriaList = getDemandCriteria();
        Long supplyRevisionId = getSupplyRevision();
        MockUCCHelper helper = new MockUCCHelper(null);
        helper.setRequestParameterValue("method", "generatePlan");
        helper.setRequestParameterValue("plan_name", "test");
        helper.setRequestParameterValue("plan_description", "test");
        helper.setRequestParameterValue("supplyRev", supplyRevisionId);
        helper.setRequestParameterValue("plan_type", "794");
        helper.setRequestParameterValue("channelRev", demandCriteriaList.toArray(new String[demandCriteriaList.size()]));
        helper.setSessionParameter(MainConstants.LOGINUSER, new LoginUser("NJMINSH"));
        return helper;
    }

    private Long getSupplyRevision() throws DBTemplateNoResultsException {
        DBTemplate template = (DBTemplate) AbstractGenericFactory.getInstance().getBean("dbTemplate");
        Map resultMap = (Map) template.executeSingleResultQuery("lookupLatestSupplyRevision", PlanType.PARENT_PLAN_TYPE_ID);
        return (Long) resultMap.get("REVISION_ID");
    }

    private List getDemandCriteria() {
        DBTemplate template = (DBTemplate) AbstractGenericFactory.getInstance().getBean("dbTemplate");
        List resultList = (List) template.executeListResultQuery("lookupLatestDemandRevisionsByChannel", PlanType.PARENT_PLAN_TYPE_ID);
        List demandCriteriaList = new ArrayList();
        for (int i = 0; i < resultList.size(); i++) {
            Map resultMap = (Map) resultList.get(i);
            demandCriteriaList.add((Long) resultMap.get("CHANNEL_ID") + "-" + (Long) resultMap.get("REVISION_ID"));
        }
        return demandCriteriaList;
    }
}
