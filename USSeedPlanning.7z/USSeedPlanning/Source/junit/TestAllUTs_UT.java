package test;/*
 Copyright:  Copyright � 2006 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/

import com.monsanto.testutil.MonsantoTestCollector;
import com.monsanto.testutil.TestCollector;

/**
 * Filename:    $RCSfile: TestAllUTs_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: njminsh $    	 On:	$Date:
 * 2006/10/20 13:46:21 $
 *
 * @author jdpoul
 * @version $Revision: 1.2 $
 */
public class TestAllUTs_UT extends MonsantoTestCollector {


  public TestAllUTs_UT(String name) {
    super(name);
  }

  public void testCollectAllTestCases() throws Exception {
    String[] packages = new String[1];
    packages[0] = "com.monsanto.wst.usseedplanning";
    runTest(packages, TestAllUTs_UT.class);
  }

  protected TestCollector getTestCollector() {
    return new test.Filter();
  }


}