/*
 CommonUploadValidator was created on Oct 10, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.usseedplanning.controller.validator;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.wst.validator.HttpRequestErrors;
import com.monsanto.wst.validator.HttpValidator;
import org.apache.commons.lang.StringUtils;

import java.io.IOException;

/**
 * Created by IntelliJ IDEA.
 * Date: Aug 15, 2006
 * Time: 9:59:55 AM
 * <p/>
 * This class is used to validate common forecast requests.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class CommonUploadValidator implements HttpValidator {
    public HttpRequestErrors validate(UCCHelper helper) throws IOException {
        HttpRequestErrors errors = new HttpRequestErrors();
	    String comments = helper.getRequestParameterValue("comments");
	    String columnName = helper.getRequestParameterValue("columnName");
	    if (StringUtils.isEmpty(comments))
	        errors.addError("comments", "Comment should not be left empty.");
	    if (helper.getClientFiles().size() != 1)
	        errors.addError("commonFile", "Please select file to upload.");
	    if (columnName == null || columnName.equals("0"))
		    errors.addError("columnName", "Please select a column.");

        return errors;
    }
}