/*
 SupplyControllerAT was created on Jan 24, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.usseedplanning.controller.maintenance.test;

import com.monsanto.wst.usseedplanning.utils.testutils.USSeedPlanningBaseTransactionTestCase;
import com.monsanto.wst.usseedplanning.constants.MainConstants;
import com.monsanto.wst.usseedplanning.model.core.LoginUser;
import com.monsanto.wst.usseedplanning.model.maintenance.supply.SupplyType;
import com.monsanto.wst.usseedplanning.model.planning.PlanType;
import com.monsanto.wst.factory.GenericFactory;
import com.monsanto.wst.factory.AbstractGenericFactory;
import com.monsanto.wst.servletframework.AbstractDispatchController;
import com.monsanto.wst.commonutils.resources.ResourceUtils;
import com.monsanto.wst.validator.HttpRequestMessages;
import com.monsanto.wst.dbtemplate.transaction.TransactionManager;
import com.monsanto.ServletFramework.Test.MockUCCHelper;

import java.io.File;

/**
 * Filename:    $RCSfile: SupplyControllerAT.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: njminsh $    	 On:	$Date: 2007-02-10 16:30:21 $
 *
 * @author vrbethi
 * @version $Revision: 1.4 $
 */
public class SupplyControllerAT extends USSeedPlanningBaseTransactionTestCase {
    protected String getConfigPath() {
        return "com/monsanto/wst/usseedplanning/dao/test/dbUnit/commonUploadDataSet.xml";
    }

    protected void cleanDatabase(TransactionManager txManager) {
    }

    public void testUploadYATPFND() throws Exception {
        GenericFactory container = AbstractGenericFactory.getInstance();
        AbstractDispatchController commonUploadController=(AbstractDispatchController) container.getBean("/servlet/supply.htm");
        MockUCCHelper helper = new MockUCCHelper(null);
        File file = new ResourceUtils().convertPathToFile("com/monsanto/wst/usseedplanning/services/mock/yaptfnd.xls");
        helper.addClientFile(file.getAbsolutePath());
        helper.setRequestParameterValue("method", "updateSupply");
        helper.setRequestParameterValue("comments", "addCommonUpload");
        helper.setRequestParameterValue("supplyType", SupplyType.ATP_SUPPLY_TYPE);
        helper.setRequestParameterValue("planType", PlanType.PARENT_PLAN_TYPE_ID);
        helper.setSessionParameter(MainConstants.LOGINUSER, new LoginUser("DBUNIT"));
        commonUploadController.run(helper);
        HttpRequestMessages httpRequestMessages = (HttpRequestMessages) helper.getRequestAttributeValue("messages");
        String message = (String) httpRequestMessages.getMessages().get(0);
        assertEquals("Supply Update Successful",message);

    }
}