package com.monsanto.wst.usseedplanning.controller.core.test;

import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.wst.usseedplanning.controller.core.UsSeedMainController;
import com.monsanto.wst.usseedplanning.view.factory.ViewFactory;
import com.monsanto.wst.usseedplanning.view.factory.mock.MockViewFactory;
import com.monsanto.wst.view.test.mock.MockView;
import junit.framework.TestCase;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Aug 15, 2006
 * Time: 3:43:49 PM
 * To change this template use File | Settings | File Templates.
 */
public class UsSeedMainController_UT extends TestCase {
    private MockUCCHelper helper;

    protected void setUp() throws Exception {
        helper = new MockUCCHelper(null);
    }

    public void testCreate() throws Exception {
        UsSeedMainController controller = new UsSeedMainController((ViewFactory)null);
        assertNotNull(controller);
    }

    public void testRenderViewTomainPage() throws Exception {
        ViewFactory viewFactory = new MockViewFactory();
        UsSeedMainController controller = new UsSeedMainController(viewFactory);
        controller.run(helper);
        MockView view = (MockView) viewFactory.getUSSeedHomeView();
        assertTrue(view.wasViewRendered());
    }
}
