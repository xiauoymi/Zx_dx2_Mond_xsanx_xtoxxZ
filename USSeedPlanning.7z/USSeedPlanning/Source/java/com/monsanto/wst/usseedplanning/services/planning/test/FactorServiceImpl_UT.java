/*
 FactorServiceImpl_UT was created on Oct 3, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.usseedplanning.services.planning.test;

import com.monsanto.wst.usseedplanning.dao.mock.MockFactorDao;
import com.monsanto.wst.usseedplanning.services.planning.FactorServiceImpl;
import junit.framework.TestCase;

import java.util.List;

/**
 * Filename:    $RCSfile: FactorServiceImpl_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ffbrac $    	 On:	$Date: 2006-10-03 18:05:11 $
 *
 * @author ffbrac
 * @version $Revision: 1.1 $
 */
public class FactorServiceImpl_UT extends TestCase {
	public void testCreate() throws Exception {
		FactorServiceImpl service = new FactorServiceImpl(new MockFactorDao());
		assertNotNull(service);
	}
	public void testGetStageFactorList() throws Exception {
		FactorServiceImpl service = new FactorServiceImpl(new MockFactorDao());
		List testList = service.getStageFactorList();
		assertNotNull(testList);
		assertEquals(2, testList.size());

	}
	public void testGetQAFactorList() throws Exception {
		FactorServiceImpl service = new FactorServiceImpl(new MockFactorDao());
		List testList = service.getQAFactorList();
		assertNotNull(testList);
		assertEquals(2, testList.size());

	}
	public void testGetYieldFactorList() throws Exception {
		FactorServiceImpl service = new FactorServiceImpl(new MockFactorDao());
		List testList = service.getYieldFactorList();
		assertNotNull(testList);
		assertEquals(2, testList.size());

	}
}