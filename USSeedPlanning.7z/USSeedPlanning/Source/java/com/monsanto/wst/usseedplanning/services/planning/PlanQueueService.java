/*
 PlanQueueService was created on Feb 5, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.usseedplanning.services.planning;

import com.monsanto.wst.usseedplanning.model.planning.PlanSummary;
import com.monsanto.wst.usseedplanning.model.planning.PlanCriteria;
import com.monsanto.wst.usseedplanning.model.planning.Plan;
import com.monsanto.wst.usseedplanning.model.core.LoginUser;

import java.util.List;
import java.io.File;
import java.io.IOException;

/**
 * Filename:    $RCSfile: PlanQueueService.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: njminsh $    	 On:	$Date: 2007-02-23 20:22:02 $
 *
 * @author VRBETHI
 * @version $Revision: 1.4 $
 */
public class PlanQueueService implements PlanService{
  
  public void generatePlan(PlanSummary summary, PlanCriteria criteria, LoginUser currentUser) throws Exception {
  }

  public Plan lookupPlanByCriteria(PlanCriteria criteria) {
    return null;
  }

    public Plan lookupPlanSummaryByCriteria(PlanCriteria criteria) {
      return null;
    }

    public void savePlan(File planSpreadsheet, LoginUser loginUser, String comments) throws Exception {
    }

  public List lookupAllPlans() {
    return null;
  }

  public List lookupPlansByPlanType(Long planTypeId) {
    return null;
  }

  public void commitPlan(LoginUser loginUser, String comments, Long planRevisionId, Long planId) throws IOException {
  }
}