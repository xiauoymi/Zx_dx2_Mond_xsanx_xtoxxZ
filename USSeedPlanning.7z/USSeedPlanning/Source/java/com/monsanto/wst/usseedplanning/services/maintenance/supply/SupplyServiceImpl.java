package com.monsanto.wst.usseedplanning.services.maintenance.supply;

import com.monsanto.wst.usseedplanning.dao.SupplyDao;
import com.monsanto.wst.usseedplanning.dao.YearDao;
import com.monsanto.wst.usseedplanning.model.core.LoginUser;
import com.monsanto.wst.usseedplanning.model.maintenance.Year;
import com.monsanto.wst.usseedplanning.model.planning.SupplyRevisionCriteria;

import java.io.File;
import java.io.IOException;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * Date: Aug 16, 2006
 * Time: 5:00:55 PM
 * <p/>
 * This class is a generic implementation of the SupplyService interface.  It is used to retrieve and modify supply
 * information.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class SupplyServiceImpl implements SupplyService {
    private SupplyDao supplyDao;
    private YearDao yearDao;
    private UpdateSupplyServiceFactory updateSupplyServiceFactory;


    /**
     * This constructor takes all dependencies.
     *
     * @param supplyDao                SupplyDao object representing the supply data access object.
     * @param yearDao
     * @param updateSupplyServiceFactory
     */
    public SupplyServiceImpl(SupplyDao supplyDao, YearDao yearDao, UpdateSupplyServiceFactory updateSupplyServiceFactory) {
        this.updateSupplyServiceFactory = updateSupplyServiceFactory;
        this.supplyDao = supplyDao;
        this.yearDao = yearDao;
    }

    /**
     * This method returns a list of supply revisions based on the criteria specified.
     *
     * @param planTypeId
     * @return List - Representing the revisions.
     */
    public List lookupSupplyRevisionsByCriteria(Long planTypeId) {
        Year year = this.yearDao.lookupCurrentYear();
        SupplyRevisionCriteria criteria = new SupplyRevisionCriteria(planTypeId, year.getYear());
        return this.supplyDao.lookupRevisionsByCriteria(criteria);
    }

    public void updateSupply(File file, LoginUser owner, String supplyType, Long planType, String comments) throws IOException {
        UpdateSupplyService updateSupplyService = updateSupplyServiceFactory.getUpdateSupplyService(supplyType);
        updateSupplyService.updateSupply(file, comments, owner, planType);
    }
}
