/*
CommonUploadConstants was created on Nov 14, 2006 using Monsanto
resources and is the sole property of Monsanto.  Any duplication of the
code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.usseedplanning.utils;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Filename:    $RCSfile: CommonUploadConstants.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: uukola $
 * On:	$Date: 2007-02-26 18:21:42 $
 *
 * @author vrbethi
 * @version $Revision: 1.11 $
 */
public class CommonUploadConstants {

  Map commonUploadConstants = new LinkedHashMap();

  Map commonUploadTables = new LinkedHashMap();

  public CommonUploadConstants() {
    commonUploadConstants.clear();
    commonUploadConstants.put("base_name", "F - Base Name");
    commonUploadConstants.put("hcl_base", "I - HCL Base");
    commonUploadConstants.put("pre_fiscal", "BN - Pre-Fiscal Pitch");
    commonUploadConstants.put("qa_loss", "BO - QA % Loss");
    commonUploadConstants.put("planned_marketing", "BR - Mkt Discard, Planned");
    commonUploadConstants.put("approved_quality", "BU - QA Discard, Approved");
    commonUploadConstants.put("approved_mktg", "BV - Mkt Discard, Approved");
    commonUploadConstants.put("misc_monthly", "BW - Monthly, Misc");
    commonUploadConstants.put("misc_offs", "BX - Write-offs, Misc");
    commonUploadConstants.put("other_demand", "CB - Other Demand");
    commonUploadConstants.put("eb_carryover", "CC - EB from Carryover");
    commonUploadConstants.put("summer_prod_plan", "CF - Planned Summer Production");
    commonUploadConstants.put("winter_prod_plan", "CG - Planned Winter Production");
    commonUploadConstants.put("summer_prod_act_us", "CI - Actual US Summer Production");
    commonUploadConstants.put("winter_prod_act_us", "CJ - Actual US Winter Production");
    commonUploadConstants.put("summer_prod", "CL - Actual Licensee Summer Production");
    commonUploadConstants.put("winter_prod", "CM - Actual Licensee Winter Production");
    commonUploadConstants.put("msis", "DD - MSIS (usage)");
    commonUploadConstants.put("yield_target", "HF - Target Yield");

    commonUploadTables.put("base_name", "base_name");
    commonUploadTables.put("hcl_base", "hcl_base");
    commonUploadTables.put("pre_fiscal", "pre_fiscal_pitch");
    commonUploadTables.put("qa_loss", "qa_perc_loss");
    commonUploadTables.put("planned_marketing", "planned_marketing");
    commonUploadTables.put("approved_quality", "approved_quality");
    commonUploadTables.put("approved_mktg", "approved_mktg");
    commonUploadTables.put("misc_monthly", "misc_monthly");
    commonUploadTables.put("misc_offs", "misc_offs");
    commonUploadTables.put("other_demand", "other_demand");
    commonUploadTables.put("eb_carryover", "eb_carryover");
    commonUploadTables.put("summer_prod_plan", "summer_prod_planned");
    commonUploadTables.put("winter_prod_plan", "winter_prod_planned");
    commonUploadTables.put("summer_prod_act_us", "summer_prod_act_us");
    commonUploadTables.put("winter_prod_act_us", "winter_prod_act_us");
    commonUploadTables.put("summer_prod", "summer_prod_act_lic");
    commonUploadTables.put("winter_prod", "winter_prod_act_lic");
    commonUploadTables.put("msis", "msis");
    commonUploadTables.put("yield_target", "common_target_yield");
  }


  public String getCommonUploadConstantValue(String uploadConstant) {
    return (String) commonUploadConstants.get(uploadConstant);
  }

  public String getCommonUploadTableName(String tableKey) {
    return (String) commonUploadTables.get(tableKey);
  }


  public Map getcommonUploadConstants() {
    return commonUploadConstants;
  }

  public Map getCommonUploadTables() {
    return commonUploadTables;
  }
}