/*
 ProductLookupServiceUtil_UT was created on Oct 1, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.usseedplanning.utils.test;

import com.monsanto.wst.usseedplanning.model.maintenance.NameType;
import com.monsanto.wst.usseedplanning.model.cache.ProductCriteria;
import com.monsanto.wst.usseedplanning.model.cache.test.ProductCriteriaUT;
import com.monsanto.wst.usseedplanning.utils.ProductLookupServiceUtil;
import junit.framework.TestCase;

import java.util.ArrayList;
import java.util.List;

/**
 * Filename:    $RCSfile: ProductLookupServiceUtil_UT.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: njminsh $    	 On:	$Date: 2007-01-31 21:55:34 $
 *
 * @author VRBETHI
 * @version $Revision: 1.5 $
 */
public class ProductLookupServiceUtil_UT extends TestCase{

  public void testSortProductCriteriaList() throws Exception {
    ProductLookupServiceUtil util = new ProductLookupServiceUtil();
    List productCriteriaList = getTestProductCriteriaList();
    productCriteriaList = util.sortProductCriteriaList(productCriteriaList);
    assertEquals("product4", ((ProductCriteria)productCriteriaList.get(0)).getProductName());
    assertEquals("product1", ((ProductCriteria)productCriteriaList.get(4)).getProductName());
  }

  public void testSortProductCriteriaList_PutsNullValuesAtTheEnd() throws Exception {
    ProductLookupServiceUtil util = new ProductLookupServiceUtil();
    List productCriteriaList = getTestProductCriteriaListWithNullValue();
    productCriteriaList = util.sortProductCriteriaList(productCriteriaList);
    assertEquals("product4", ((ProductCriteria)productCriteriaList.get(0)).getProductName());
    assertEquals("product1", ((ProductCriteria)productCriteriaList.get(2)).getProductName());
  }

  public void testSortProductCriteriaList_PutsObjectsWithInvalidTypesAtTheEnd() throws Exception {
    ProductLookupServiceUtil util = new ProductLookupServiceUtil();
    List productCriteriaList = getTestProductCriteriaListWithInvalidValues();
    productCriteriaList = util.sortProductCriteriaList(productCriteriaList);
    assertEquals("product4", ((ProductCriteria)productCriteriaList.get(0)).getProductName());
    assertEquals("product1", ((ProductCriteria)productCriteriaList.get(3)).getProductName());
  }

  private List getTestProductCriteriaListWithInvalidValues() {
    List productCriteriaList = new ArrayList();
    productCriteriaList.add(ProductCriteriaUT.createProductCriteria("product1", new NameType(NameType.MANUFACTURING)));
    productCriteriaList.add(ProductCriteriaUT.createProductCriteria("product2", new NameType(NameType.PRECOMMERCIAL)));
    productCriteriaList.add("NotAProductCriteriaTypeObject");
    productCriteriaList.add(ProductCriteriaUT.createProductCriteria("product4", new NameType(NameType.COMMERCIAL)));
    productCriteriaList.add(ProductCriteriaUT.createProductCriteria("product5", new NameType(NameType.PRECOMMERCIAL)));
    return productCriteriaList;
  }

  private List getTestProductCriteriaListWithNullValue() {
    List productCriteriaList = new ArrayList();
    productCriteriaList.add(ProductCriteriaUT.createProductCriteria("product1", new NameType(NameType.MANUFACTURING)));
    productCriteriaList.add(ProductCriteriaUT.createProductCriteria("product2", null));
    productCriteriaList.add(null);
    productCriteriaList.add(ProductCriteriaUT.createProductCriteria("product3", new NameType((String) null)));
    productCriteriaList.add(ProductCriteriaUT.createProductCriteria("product4", new NameType(NameType.COMMERCIAL)));
    productCriteriaList.add(ProductCriteriaUT.createProductCriteria("product5", new NameType(NameType.PRECOMMERCIAL)));
    return productCriteriaList;
  }

  private List getTestProductCriteriaList() {
    List productCriteriaList = new ArrayList();
    productCriteriaList.add(ProductCriteriaUT.createProductCriteria("product1", new NameType(NameType.MANUFACTURING)));
    productCriteriaList.add(ProductCriteriaUT.createProductCriteria("product2", new NameType(NameType.PRECOMMERCIAL)));
    productCriteriaList.add(ProductCriteriaUT.createProductCriteria("product3", new NameType(NameType.PRECOMMERCIAL)));
    productCriteriaList.add(ProductCriteriaUT.createProductCriteria("product4", new NameType(NameType.COMMERCIAL)));
    productCriteriaList.add(ProductCriteriaUT.createProductCriteria("product5", new NameType(NameType.PRECOMMERCIAL)));
    return productCriteriaList;
  }
}