/*
 LookupService was created on Oct 24, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.usseedplanning.services.core;

import com.monsanto.wst.usseedplanning.model.planning.Plan;

import java.util.Date;
import java.util.List;

/**
 * Filename:    $RCSfile: LookupService.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ffbrac $    	 On:	$Date: 2006-10-31 20:53:46 $
 *
 * @author ffbrac
 * @version $Revision: 1.3 $
 */
public interface LookupService {
	public Date lookupLastRevisionDate();
	public String lookupReleaseTrackingValue();
	public List lookupPlanRevisionList();
	public List lookupGeneratedPlanComponents(Long planId);
	public List lookupPlanListByPlanTypeName(String planTypeName);
	public Plan lookupPlanByPlanId(Long planId);
	public List lookupPlanDetailsByPlanId(Long planId);
}