package com.monsanto.wst.usseedplanning.controller.maintenance.seedEntity.test;

import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.wst.usseedplanning.constants.ControllerConstants;
import com.monsanto.wst.usseedplanning.constants.MainConstants;
import com.monsanto.wst.usseedplanning.controller.maintenance.seedEntity.QaThresholdFormController;
import com.monsanto.wst.usseedplanning.model.maintenance.QaThreshold;
import com.monsanto.wst.usseedplanning.services.maintenance.seedEntity.*;
import com.monsanto.wst.usseedplanning.services.maintenance.seedEntity.mock.*;
import com.monsanto.wst.usseedplanning.view.factory.ViewFactory;
import com.monsanto.wst.usseedplanning.view.factory.mock.MockViewFactory;
import com.monsanto.wst.view.test.mock.MockView;
import junit.framework.TestCase;

import java.util.Collection;
import java.util.Iterator;

/**
 * Created by IntelliJ IDEA. User: rgeorge Date: Aug 8, 2006 Time: 8:46:03 AM To change this template use File |
 * Settings | File Templates.
 */
public class QaThresholdFormController_UT extends TestCase {

    MockUCCHelper helper = null;

    protected void setUp() throws Exception {
        helper = new MockUCCHelper(null);
    }

    public void testCreate() throws Exception {
        QaThresholdFormController controller = new QaThresholdFormController((QaThresholdService) null, (ViewFactory) null,
                null, null, null, null);
        assertNotNull(controller);

    }

    public void testDisplayQaThresholdFormUC() throws Exception {
        MockUCCHelper helper = new MockUCCHelper(null);
        ViewFactory factory = new MockViewFactory();
        QaThresholdFormController controller = getMockedOutQaThresholdFormController(new MockQaThresholdService(), factory);
        controller.displayQaThresholdFormView(helper);
        MockView view = (MockView) factory.getQaThresholdFormView(
        );
        assertTrue(view.wasViewRendered());

    }

    public void testSaveQaThresholdInstanceFormWasRendered() throws Exception {
        MockUCCHelper helper = new MockUCCHelper(null);
        ViewFactory factory = new MockViewFactory();
        MockQaThresholdService service = new MockQaThresholdService();
        QaThresholdFormController controller = getMockedOutQaThresholdFormController(service, factory);
        controller.formSubmittedSave(helper);
        MockView view = (MockView) factory.getQaThresholdFormView(
        );
        assertTrue(view.wasViewRendered());

    }

    public void testSaveQaThresholdCheckIfSaved() throws Exception {
        MockUCCHelper helper = new MockUCCHelper(null);
        ViewFactory factory = new MockViewFactory();
        MockQaThresholdService service = new MockQaThresholdService();
        QaThresholdFormController controller = getMockedOutQaThresholdFormController(service, factory);
        addAllValidQaThresholdFieldsToUccHelper(helper);
        controller.formSubmittedSave(helper);
        assertEquals(1, service.getQaThresholds().size());
    }

    public void testSaveQaThresholdValidationErrorsAreAddedToHttpErrors() throws Exception {
        MockUCCHelper helper = new MockUCCHelper(null);
        MockViewFactory factory = new MockViewFactory();
        MockQaThresholdService service = new MockQaThresholdService();
        setValidComparisonStrategyIdParam(helper);
        setValidQaThresholdTypeIdParam(helper);
        QaThresholdFormController controller = getMockedOutQaThresholdFormController(service, factory);
        controller.formSubmittedSave(helper);
        assertNotNull(helper.getRequestAttributeValue(ControllerConstants.ERRORS_REQUEST_ATTRIBUTE));
        assertNotNull(helper.getRequestAttributeValue(MainConstants.QaThresholdConstants.GENDERS_PICK_LIST_ATTRIBUTE));
        assertNotNull(helper.getRequestAttributeValue(MainConstants.QaThresholdConstants.YEAR_PICK_LIST_ATTRIBUTE));
        assertNotNull(helper.getRequestAttributeValue(MainConstants.QaThresholdConstants.QA_THRESHOLD_TYPES_PICK_LIST_ATTRIBUTE));
        assertNotNull(helper.getRequestAttributeValue(MainConstants.QaThresholdConstants.QA_THRESHOLD_COMPARISON_STRATEGY_PICK_LIST_ATTRIBUTE));
    }

    public void testSaveQaThresholdCheckIfCorrectQaThresholdWasSaved() throws Exception {
        MockUCCHelper helper = new MockUCCHelper(null);
        ViewFactory factory = new MockViewFactory();
        MockQaThresholdService service = new MockQaThresholdService();
        addAllValidQaThresholdFieldsToUccHelper(helper);
        QaThresholdFormController controller = getMockedOutQaThresholdFormController(service, factory);
        controller.formSubmittedSave(helper);
        Collection thresholds = service.getQaThresholds();
        for (Iterator iterator = thresholds.iterator(); iterator.hasNext();) {
            QaThreshold qaThreshold = (QaThreshold) iterator.next();
            assertEquals(new Long(100), qaThreshold.getGender().getId());
        }
    }

    public void testUpdatePickListsInForm() throws Exception {
        MockUCCHelper helper = new MockUCCHelper(null);
        ViewFactory factory = new MockViewFactory();
        QaThresholdFormController controller = getMockedOutQaThresholdFormController(new MockQaThresholdService(), factory);
        addAllValidQaThresholdFieldsToUccHelper(helper);
        controller.formSubmittedUpdatePickLists(helper);
        MockView view = (MockView) factory.getQaThresholdFormView();
        QaThreshold threshold = (QaThreshold) helper
                .getRequestAttributeValue(MainConstants.QaThresholdConstants.QA_THRESHOLD_BEAN_PARAM_NAME);
        assertNotNull(threshold);
        assertEquals("90", threshold.getValue());
        assertEquals(new Long(200), threshold.getYear().getId());
        assertEquals(new Long(200), threshold.getComparisonStrategy().getId());
        assertEquals(new Long(100), threshold.getThresholdType().getId());
        assertEquals(new Long(100), threshold.getGender().getId());
        assertEquals(Boolean.TRUE, threshold.getActive());
        assertEquals("testComment", helper.getRequestAttributeValue(MainConstants.REVISION_COMMENT));
    }

    private QaThresholdFormController getMockedOutQaThresholdFormController(QaThresholdService thresholdService,
                                                                            ViewFactory factory) {
        YearService yearService = new MockYearService();
        GenderService genderService = new MockGenderService();
        QaThresholdComparisonStrategyService comparisonService = new MockQaThresholdComparisonStrategyService();
        QaThresholdTypeService typeService = new MockQaThresholdTypeService();
        return new QaThresholdFormController(thresholdService, factory, yearService, genderService, comparisonService,
                typeService);
    }

    private void addAllValidQaThresholdFieldsToUccHelper(MockUCCHelper helper) {
        setValidGenderIdParam(helper);
        setValidQaThresholdTypeIdParam(helper);
        setValidComparisonStrategyIdParam(helper);
        setValidYearIdParam(helper);
        setValidRevisionCommentParam(helper);
        setValidFactorValueParam(helper);
        setValidActiveValueParam(helper);

    }


    private void setValidFactorValueParam(MockUCCHelper helper) {
        helper.setRequestParameterValue(MainConstants.QaThresholdConstants.VALUE_PARAM_NAME, "90");
    }

    private void setValidRevisionCommentParam(MockUCCHelper helper) {
        helper.setRequestParameterValue(MainConstants.REVISION_COMMENT, "testComment");
    }

    private void setValidYearIdParam(MockUCCHelper helper) {
        helper.setRequestParameterValue(MainConstants.QaThresholdConstants.YEAR_ID_PARAM_NAME, "200");
    }

    private void setValidComparisonStrategyIdParam(MockUCCHelper helper) {
        helper.setRequestParameterValue(MainConstants.QaThresholdConstants.COMPARISON_STRATEGY_ID_PARAM_NAME, "200");
    }

    private void setValidQaThresholdTypeIdParam(MockUCCHelper helper) {
        helper.setRequestParameterValue(MainConstants.QaThresholdConstants.QA_THRESHOLD_TYPE_ID_PARAM_NAME, "100");
    }

    private void setValidGenderIdParam(MockUCCHelper helper) {
        helper.setRequestParameterValue(MainConstants.QaThresholdConstants.GENDER_ID_PARAM_NAME, "100");
    }

    private void setValidActiveValueParam(MockUCCHelper helper) {
        helper.setRequestParameterValue(MainConstants.QaThresholdConstants.ACTIVE_PARAM_NAME, "true");
    }


}
