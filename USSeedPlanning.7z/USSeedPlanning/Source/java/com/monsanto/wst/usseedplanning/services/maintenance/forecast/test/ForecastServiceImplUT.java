package com.monsanto.wst.usseedplanning.services.maintenance.forecast.test;

import com.monsanto.wst.commonutils.testutils.TestUtils;
import com.monsanto.wst.usseedplanning.constants.MainConstants;
import com.monsanto.wst.usseedplanning.dao.*;
import com.monsanto.wst.usseedplanning.dao.mock.*;
import com.monsanto.wst.usseedplanning.exception.NoResultsException;
import com.monsanto.wst.usseedplanning.model.core.LoginUser;
import com.monsanto.wst.usseedplanning.model.maintenance.Channel;
import com.monsanto.wst.usseedplanning.model.maintenance.ChannelCriteria;
import com.monsanto.wst.usseedplanning.model.maintenance.DemandForecast;
import com.monsanto.wst.usseedplanning.model.planning.ChannelizedDemandRevisions;
import com.monsanto.wst.usseedplanning.model.planning.PlanType;
import com.monsanto.wst.usseedplanning.services.core.ImportSpreadsheetService;
import com.monsanto.wst.usseedplanning.services.core.mock.MockImportSpreadsheetService;
import com.monsanto.wst.usseedplanning.services.maintenance.forecast.ForecastServiceImpl;
import com.monsanto.wst.usseedplanning.services.maintenance.forecast.InvalidForecastException;
import junit.framework.TestCase;

import java.io.File;
import java.util.List;

/**
 * Created by IntelliJ IDEA. Date: Aug 8, 2006 Time: 12:06:42 PM <p/> Unit test for the ForecastServiceImpl object.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class ForecastServiceImplUT extends TestCase {
    protected void setUp() throws Exception {
        TestUtils testUtils = new TestUtils();
        testUtils.setupLogging(MainConstants.APPLICATION_NAME);
        super.setUp();
    }

    public void testCreate() throws Exception {
        ForecastServiceImpl service = new ForecastServiceImpl((ImportSpreadsheetService) null, (DemandDao) null,
                (ChannelDao) null, (RevisionDao) null, (YearDao) null);
        assertNotNull(service);
    }

    public void testAddCommonForecastsSuccess() throws Exception {
        MockImportSpreadsheetService spreadsheetService = new MockImportSpreadsheetService();
        MockDemandDao demandDao = new MockDemandDao();
        MockChannelDao channelDao = new MockChannelDao();
        MockRevisionDao revisionDao = new MockRevisionDao();
        ForecastServiceImpl service = new ForecastServiceImpl(spreadsheetService, demandDao,
                channelDao, revisionDao, (YearDao) null);
        File file = new File("");
        service.addCommonForecasts(file, PlanType.PARENT_PLAN_TYPE_ID, new LoginUser("tester"),
                "Test Comment");
        assertEquals(file, spreadsheetService.getSpreadsheet());
        List demandForecastList = demandDao.getAllAddedDemandForecasts();
        DemandForecast demandForecast = (DemandForecast) demandForecastList.get(0);
        assertNotNull(demandForecast);
        assertEquals(PlanType.PARENT_PLAN_TYPE_ID, demandForecast.getPlanTypeId());
        assertEquals("HC1151", demandForecast.getCommonName());
        assertEquals("ASI", demandForecast.getChannel().getName());
        assertNotNull(demandForecast.getChannel().getId());
        assertEquals(new Long(12345), demandForecast.getChannel().getId());
        assertNotNull(demandForecast.getRevision());
        assertNotNull(demandForecast.getNameType());
    }

    public void testAddCommonForecastUnknownChannelName() throws Exception {
        MockImportSpreadsheetService spreadsheetService = new MockImportSpreadsheetService();
        MockDemandDao demandDao = new MockDemandDao();
        MockChannelDaoNoResults channelDao = new MockChannelDaoNoResults();
        MockRevisionDao revisionDao = new MockRevisionDao();
        ForecastServiceImpl service = new ForecastServiceImpl(spreadsheetService, demandDao,
                channelDao, revisionDao, (YearDao) null);
        File file = new File("");
        try {
            service.addCommonForecasts(file, PlanType.PARENT_PLAN_TYPE_ID, new LoginUser("tester"),
                    "Test Comment");
            fail("This should have thrown an exception.");
        } catch (InvalidForecastException e) {
            assertEquals("Unable to find channel: 'ASI' in the system.", e.getMessage());
        }
    }

    public void testAddCommonForecastUnknownNameType() throws Exception {
        MockImportSpreadsheetService spreadsheetService = new MockImportSpreadsheetService();
        MockDemandDao demandDao = new MockDemandDao();
        MockChannelDaoNameTypeNoResults channelDao = new MockChannelDaoNameTypeNoResults();
        MockRevisionDao revisionDao = new MockRevisionDao();
        ForecastServiceImpl service = new ForecastServiceImpl(spreadsheetService, demandDao,
                channelDao, revisionDao, (YearDao) null);
        File file = new File("");
        try {
            service.addCommonForecasts(file, PlanType.PARENT_PLAN_TYPE_ID, new LoginUser("tester"),
                    "Test Comment");
            fail("This should have thrown an exception.");
        } catch (InvalidForecastException e) {
            assertEquals("Unable to determine the appropriate product name type based on the " +
                    "channel: 'Test' and the plan type specified.", e.getMessage());
        }
    }

    public void testAddDemandForecast() throws Exception {
        MockImportSpreadsheetService spreadsheetService = new MockImportSpreadsheetService();
        MockDemandDao demandDao = new MockDemandDao();
        MockChannelDao channelDao = new MockChannelDao();
        MockRevisionDao revisionDao = new MockRevisionDao();
        MockYearDao yearDao = new MockYearDao();
        ForecastServiceImpl service = new ForecastServiceImpl(spreadsheetService, demandDao,
                channelDao, revisionDao, yearDao);
        File file = new File("");
        service.addDemandForecasts(file, new LoginUser("tester"), "Test Comment");
        assertEquals(file, spreadsheetService.getSpreadsheet());
        List demandForecastList = demandDao.getAllAddedDemandForecasts();
        DemandForecast demandForecast = (DemandForecast) demandForecastList.get(0);
        assertNotNull(demandForecast);
        assertEquals(PlanType.HYBRID_PLAN_TYPE_ID, demandForecast.getPlanTypeId());
        assertEquals("HC1151", demandForecast.getCommonName());
        assertEquals(Channel.BRANDED_CHANNEL, demandForecast.getChannel().getName());
        assertNotNull(demandForecast.getChannel().getId());
        assertEquals(new Long(12345), demandForecast.getChannel().getId());
        assertNotNull(demandForecast.getRevision());
        assertNotNull(demandForecast.getNameType());
        assertEquals(new Integer(2007), demandForecast.getYear());
    }

    public void testAddDemandForecastUnknownChannelName() throws Exception {
        MockImportSpreadsheetService spreadsheetService = new MockImportSpreadsheetService();
        MockDemandDao demandDao = new MockDemandDao();
        MockChannelDaoNoResults channelDao = new MockChannelDaoNoResults();
        MockRevisionDao revisionDao = new MockRevisionDao();
        MockYearDao yearDao = new MockYearDao();
        ForecastServiceImpl service = new ForecastServiceImpl(spreadsheetService, demandDao,
                channelDao, revisionDao, yearDao);
        File file = new File("");
        try {
            service.addDemandForecasts(file, new LoginUser("tester"), "Test Comment");
            fail("This should have thrown an exception.");
        } catch (InvalidForecastException e) {
            assertEquals("Unable to find channel: '" + Channel.BRANDED_CHANNEL + "' in the system.", e.getMessage());
        }
    }

    public void testAddDemandForecastUnknownNameType() throws Exception {
        MockImportSpreadsheetService spreadsheetService = new MockImportSpreadsheetService();
        MockDemandDao demandDao = new MockDemandDao();
        MockChannelDaoNameTypeNoResults channelDao = new MockChannelDaoNameTypeNoResults();
        MockRevisionDao revisionDao = new MockRevisionDao();
        MockYearDao yearDao = new MockYearDao();
        ForecastServiceImpl service = new ForecastServiceImpl(spreadsheetService, demandDao,
                channelDao, revisionDao, yearDao);
        File file = new File("");
        try {
            service.addDemandForecasts(file, new LoginUser("tester"), "Test Comment");
            fail("This should have thrown an exception.");
        } catch (InvalidForecastException e) {
            assertEquals("Unable to determine the appropriate product name type based on the " +
                    "channel: 'Test' and the plan type specified.", e.getMessage());
        }
    }

    public void testLookupDemandRevisionByCriteria() throws Exception {
        MockImportSpreadsheetService spreadsheetService = new MockImportSpreadsheetService();
        MockDemandDao demandDao = new MockDemandDao();
        MockChannelDao channelDao = new MockChannelDao();
        MockRevisionDao revisionDao = new MockRevisionDao();
        MockYearDao yearDao = new MockYearDao();
        ForecastServiceImpl service = new ForecastServiceImpl(spreadsheetService, demandDao,
                channelDao, revisionDao, yearDao);
        List channelizedDemandRevisions = service.lookupDemandRevisionByChannel(PlanType.PARENT_PLAN_TYPE_ID);
        assertNotNull(channelizedDemandRevisions);
        assertEquals(2, channelizedDemandRevisions.size());
        ChannelizedDemandRevisions revisions = (ChannelizedDemandRevisions) channelizedDemandRevisions.get(0);
        assertEquals(2, revisions.getDemandRevisions().size());
    }

    private class MockChannelDaoNameTypeNoResults extends MockChannelDaoNoResults {
        public Channel lookupChannelByName(ChannelCriteria criteria) throws NoResultsException {
            Channel channel = new Channel();
            channel.setId(new Long(12345));
            channel.setName("Test");
            channel.setActive(Boolean.TRUE);
            channel.setDescription("Test channel");
            return channel;
        }
    }
}
