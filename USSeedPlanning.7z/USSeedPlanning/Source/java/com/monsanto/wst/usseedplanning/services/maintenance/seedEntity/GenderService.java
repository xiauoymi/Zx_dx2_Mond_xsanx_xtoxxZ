package com.monsanto.wst.usseedplanning.services.maintenance.seedEntity;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Aug 17, 2006
 * Time: 9:11:05 AM
 * To change this template use File | Settings | File Templates.
 */
public interface GenderService {

    public List getActiveGenders();

}
