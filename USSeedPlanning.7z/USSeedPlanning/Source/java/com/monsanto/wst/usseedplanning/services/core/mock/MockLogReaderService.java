package com.monsanto.wst.usseedplanning.services.core.mock;

import com.monsanto.wst.usseedplanning.services.core.LogReaderService;

import java.util.List;
import java.io.File;

/**
 * Created by IntelliJ IDEA.
 * Date: Apr 10, 2006
 * Time: 8:42:22 AM
 * <p/>
 * This class is a mock implementation of the LogReaderService.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class MockLogReaderService implements LogReaderService {
    private String fileName;

    public List getLogFileList() {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public File getLogFile(String fileName) {
        this.fileName = fileName;
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public String getFileName() {
        return this.fileName;
    }

}
