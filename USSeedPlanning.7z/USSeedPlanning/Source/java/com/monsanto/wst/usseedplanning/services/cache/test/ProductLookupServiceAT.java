/*
 ProductLookupServiceImplAT was created on Aug 18, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.usseedplanning.services.cache.test;

import com.monsanto.wst.factory.AbstractGenericFactory;
import com.monsanto.wst.usseedplanning.model.maintenance.NameType;
import com.monsanto.wst.usseedplanning.model.cache.ProductCriteria;
import com.monsanto.wst.usseedplanning.model.cache.ProductDetails;
import com.monsanto.wst.usseedplanning.services.cache.ProductLookupService;
import com.monsanto.wst.usseedplanning.utils.testutils.USSeedPlanningBaseTransactionTestCase;
import com.monsanto.wst.dbtemplate.DBTemplate;
import com.monsanto.wst.dbtemplate.transaction.TransactionManager;

import java.util.ArrayList;
import java.util.List;

/**
 * Filename:
 * RCSfile: ProductLookupServiceImplAT.java, v
 * Label:
 * Name:
 * Last Change:
 * Author: njminsh
 * On:
 * Date: 2006/09/06 12:25:43
 *
 * @author sspati1
 * @version 1.2
 */
public class ProductLookupServiceAT extends USSeedPlanningBaseTransactionTestCase {
    private String originalLsi = System.getProperty("lsi.function");

    protected void setUp() throws Exception {
        super.setUp();    //To change body of overridden methods use File | Settings | File Templates.
        System.setProperty("lsi.function", "prod");
    }

    protected void tearDown() throws Exception {
        System.setProperty("lsi.function", originalLsi);
        super.tearDown();    //To change body of overridden methods use File | Settings | File Templates.
    }

    protected String getConfigPath() {
        return "com/monsanto/wst/usseedplanning/services/cache/test/dbunit/productLookupDataSet.xml";
    }

    protected void cleanDatabase(TransactionManager txManager) {
        DBTemplate dbTemplate = (DBTemplate) AbstractGenericFactory.getInstance().getBean("dbTemplate");
        dbTemplate.executeDelete("deleteAllPlanDetails", null);
        dbTemplate.executeDelete("deleteAllBaseNames", null);
    }
//todo fix this
//    public void testProductDetailsForCommercialProductDK585() throws Exception {
//        ProductLookupService lookupService = (ProductLookupService) AbstractGenericFactory.getInstance().getBean("productLookupService");
//        ProductCriteria criteria = new ProductCriteria();
//        criteria.setCommonName("DK585");
//        criteria.setProductName("DK585");
//        criteria.setNameType(new NameType(NameType.COMMERCIAL));
//        List criteriaList = new ArrayList();
//        criteriaList.add(criteria);
//        List productDetailsList = lookupService.lookupProductDetailByCriteria(criteriaList);
//        assertEquals(1, productDetailsList.size());
//        ProductDetails details = (ProductDetails) productDetailsList.get(0);
//        assertEquals("CM", details.getStage());
//        assertEquals("EXP758", details.getPreCommercialName());
//        assertEquals("HCL307+HCL526", details.getManufacturingName());
//        assertEquals("91INH2", details.getFemaleParent().getPreCommercialName());
//        assertEquals("90DJD28", details.getMaleParent().getPreCommercialName());
//    }

    public void testProductDetailsForCommercialProductDK537() throws Exception {
        ProductLookupService lookupService = (ProductLookupService) AbstractGenericFactory.getInstance().getBean("productLookupService");
        ProductCriteria criteria = new ProductCriteria();
        criteria.setCommonName("DK537");
        criteria.setProductName("DK537");
        criteria.setNameType(new NameType(NameType.COMMERCIAL));
        List criteriaList = new ArrayList();
        criteriaList.add(criteria);
        List productDetailsList = lookupService.lookupProductDetailByCriteria(criteriaList);
        assertEquals(1, productDetailsList.size());
        ProductDetails details = (ProductDetails) productDetailsList.get(0);
        assertEquals("CM", details.getStage());
    }

    public void testProductDetailsForPreCommercialNameWKDL7() throws Exception {
        ProductLookupService lookupService = (ProductLookupService) AbstractGenericFactory.getInstance().getBean("productLookupService");
        ProductCriteria criteria = new ProductCriteria();
        criteria.setCommonName("WKDL7");
        criteria.setProductName("WKDL7");
        criteria.setNameType(new NameType(NameType.COMMERCIAL));
        List criteriaList = new ArrayList();
        criteriaList.add(criteria);
        List productDetailsList = lookupService.lookupProductDetailByCriteria(criteriaList);
        assertEquals(1, productDetailsList.size());
        ProductDetails details = (ProductDetails) productDetailsList.get(0);
        assertEquals("INBR", details.getStage());
    }

    public void testProductDetailsForPreCommercialNameHC34SDMS() throws Exception {
        ProductLookupService lookupService = (ProductLookupService) AbstractGenericFactory.getInstance().getBean("productLookupService");
        ProductCriteria criteria = new ProductCriteria();
        criteria.setCommonName("HC34SDMS");
        criteria.setProductName("HC34SDMS");
        criteria.setNameType(new NameType(NameType.COMMERCIAL));
        List criteriaList = new ArrayList();
        criteriaList.add(criteria);
        List productDetailsList = lookupService.lookupProductDetailByCriteria(criteriaList);
        assertEquals(1, productDetailsList.size());
        ProductDetails productDetails = (ProductDetails) productDetailsList.get(0);
        assertEquals("HC34", productDetails.getMaleParent().getPreCommercialName());
        assertEquals("HC34", productDetails.getMaleParent().getManufacturingName());
        assertEquals(ProductDetails.PRODUCT_TYPE_STERILE, productDetails.getProductType());
    }

//    public void testProductDetailsForPreCommercialNameTXP260CD() throws Exception {
//        ProductLookupService lookupService = (ProductLookupService) AbstractGenericFactory.getInstance().getBean("productLookupService");
//        ProductCriteria criteria = new ProductCriteria();
//        criteria.setCommonName("TXP260C-D");
//        criteria.setProductName("TXP260C-D");
//        criteria.setNameType(new NameType(NameType.COMMERCIAL));
//        List criteriaList = new ArrayList();
//        criteriaList.add(criteria);
//        List productDetailsList = lookupService.lookupProductDetailByCriteria(criteriaList);
//        assertEquals(1, productDetailsList.size());
//    }

    public void testProductDetailsForCommercialNameDK477() throws Exception {
        ProductLookupService lookupService = (ProductLookupService) AbstractGenericFactory.getInstance().getBean("productLookupService");
        ProductCriteria criteria = new ProductCriteria();
        criteria.setCommonName("DK477");
        criteria.setProductName("DK477");
        criteria.setNameType(new NameType(NameType.COMMERCIAL));
        List criteriaList = new ArrayList();
        criteriaList.add(criteria);
        List productDetailsList = lookupService.lookupProductDetailByCriteria(criteriaList);
        assertEquals(1, productDetailsList.size());
    }

    public void testLookupProductDetailsForHybridProductWithoutParents() throws Exception {
        ProductLookupService lookupService = (ProductLookupService) AbstractGenericFactory.getInstance().getBean("productLookupService");
        ProductCriteria criteria = new ProductCriteria();
        criteria.setCommonName("NA3702EZN3");
        criteria.setProductName("NA3702EZN3");
        criteria.setNameType(new NameType(NameType.COMMERCIAL));
        List criteriaList = new ArrayList();
        criteriaList.add(criteria);
        List productDetailsList = lookupService.lookupProductDetailByCriteria(criteriaList);
        assertEquals(1, productDetailsList.size());
        ProductDetails productDetails = (ProductDetails) productDetailsList.get(0);
        assertEquals("NA3702EZN3", productDetails.getPreCommercialName());
        assertEquals("_NA3702EZN3_F", productDetails.getFemaleParent().getPreCommercialName());
        assertEquals("_NA3702EZN3_M", productDetails.getMaleParent().getPreCommercialName());
        assertEquals(ProductDetails.PRODUCT_TYPE_HYBRID, productDetails.getProductType());
    }
}