/*
 Copyright:  Copyright � 2006 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.usseedplanning.services.maintenance.seedEntity.mock;

import com.monsanto.wst.usseedplanning.services.maintenance.seedEntity.QaThresholdComparisonStrategyService;

import java.util.List;
import java.util.ArrayList;

/**
 * Filename:    $RCSfile: MockQaThresholdComparisonStrategyService.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: jdpoul $    	 On:	$Date: 2006-09-26 20:51:21 $
 *
 * @author jdpoul
 * @version $Revision: 1.2 $
 */
public class MockQaThresholdComparisonStrategyService implements QaThresholdComparisonStrategyService {
  public List getActiveQaThresholdComparisonStrategiesForQaThresholdType(Long criteria) {
    return new ArrayList();
  }

  public List getActiveQaThresholdComparisonStrategies() {
    return new ArrayList();
  }
}