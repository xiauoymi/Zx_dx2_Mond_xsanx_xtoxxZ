/*
 Copyright:  Copyright � 2006 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.usseedplanning.services.planning.test;

import com.monsanto.wst.commonutils.resources.ResourceUtils;
import com.monsanto.wst.dbtemplate.DBTemplate;
import com.monsanto.wst.factory.AbstractGenericFactory;
import com.monsanto.wst.usseedplanning.constants.DatabaseConstants;
import com.monsanto.wst.usseedplanning.model.core.LoginUser;
import com.monsanto.wst.usseedplanning.model.maintenance.DemandForecast;
import com.monsanto.wst.usseedplanning.model.planning.*;
import com.monsanto.wst.usseedplanning.services.planning.PlanService;
import com.monsanto.wst.usseedplanning.utils.testutils.USSeedPlanningBaseTransactionTestCase;

import java.io.File;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.List;

/**
 * Filename:    $RCSfile: ParentPlanServiceAT.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: njminsh $    	 On:	$Date: 2007-03-07 17:28:48 $
 *
 * @author rdesai2
 * @version $Revision: 1.11 $
 */
public class ParentPlanServiceAT extends USSeedPlanningBaseTransactionTestCase {
    private String outputPath = "";
    private String originalLsi = System.getProperty("lsi.function");
    private File opennedParentPlanFile;

    protected void setUp() throws Exception {
        super.setUp();
        System.setProperty("lsi.function", "test");
        File directory = new ResourceUtils().convertPathToFile(this.outputPath);
        this.opennedParentPlanFile = new File(directory.getAbsolutePath() + "/opennedParentPlan.xls");
        this.opennedParentPlanFile.delete();
        this.opennedParentPlanFile.createNewFile();
    }

    protected void tearDown() throws Exception {
        System.setProperty("lsi.function", originalLsi);
        super.tearDown();    //To change body of overridden methods use File | Settings | File Templates.
    }

    protected String getConfigPath() {
        return "com/monsanto/wst/usseedplanning/services/planning/test/dbunit/planDataSet.xml";
    }

    public void testGeneratePlan() throws Exception {
        PlanService planService = (PlanService) AbstractGenericFactory.getInstance().getBean("planService");
        PlanSummary summary = new PlanSummary("test foundation plan");
        PlanCriteria criteria = new PlanCriteria(new Long(100), PlanType.PARENT_PLAN_TYPE_ID, null, null);
        criteria.setYear(new Integer(3007));
        criteria.setPlanType(new PlanType());
        criteria.getPlanType().setId(new Long(794));
        criteria.addDemandCriteria(new DemandCriteria(new Long(100), new Long(5880)));
        criteria.addDemandCriteria(new DemandCriteria(new Long(100), new Long(5881)));
        criteria.addDemandCriteria(new DemandCriteria(new Long(100), new Long(5882)));
        criteria.addDemandCriteria(new DemandCriteria(new Long(100), new Long(5887)));
        LoginUser currentUser = new LoginUser("DBUNIT");
        currentUser.setLastName("DBUNIT");
        currentUser.setEmail("DBUNIT@monsanto.com");
        planService.generatePlan(summary, criteria, currentUser);
    }

    public void testLookupPlanByCriteria() throws Exception {
        PlanService planService = (PlanService) AbstractGenericFactory.getInstance().getBean("planService");
        PlanCriteria criteria = new PlanCriteria(new Long(100), new Long(100));
        Plan plan = planService.lookupPlanByCriteria(criteria);
        assertEquals(new Integer(1), plan.getPlanSummary().getMajorVersion());
        assertEquals(new Integer(0), plan.getPlanSummary().getMinorVersion());
        assertEquals("this is for testing", plan.getPlanSummary().getName());
        assertEquals(new SimpleDateFormat("yyyy-MM-dd").parse("2006-01-01"), plan.getPlanSummary().getLastModifiedDate());
        PlanEntry entry = (PlanEntry) plan.getEntries().get(plan.getEntries().size() - 1);
        checkReciprocalFlipsParents(entry);

        // Create Plan for visual testing
        FileOutputStream fileOut = new FileOutputStream(this.opennedParentPlanFile);
        fileOut.write(plan.toByteArray());
    }

    private void checkReciprocalFlipsParents(PlanEntry entry) {
        assertTrue(entry.getProductDetails().isReciprocal());
        assertEquals("HCL345", entry.getProductDetails().getFemaleParent().getManufacturingName());
        assertEquals("HCL123", entry.getProductDetails().getMaleParent().getManufacturingName());
    }

    public void testSavePlan() throws Exception {
        PlanService planService = (PlanService) AbstractGenericFactory.getInstance().getBean("planService");
        File savedPlanFile = new ResourceUtils().convertPathToFile("com/monsanto/wst/usseedplanning/services/planning/test/savedParentPlan.xls");
        planService.savePlan(savedPlanFile, new LoginUser("DBUNIT"), "Saving test plan");

        DBTemplate template = (DBTemplate) AbstractGenericFactory.getInstance().getBean("dbTemplate");
        List planEntries = template.executeListResultQuery("lookupLatestPlanDetails", new Long(100));
        assertEquals(8, planEntries.size());
        PlanEntry entry = (PlanEntry) planEntries.get(planEntries.size() - 1);
        assertEquals("test-a", entry.getCommonName());
        checkUserData(entry);
        checkCrossPlanData(entry);
        checkFlippedParentLimits(entry);
        checkCacheWasNotUpdatedForReciprocal();
        checkCacheWasUpdatedForFemale();
        checkCacheWasUpdatedForMale();
        checkCacheWasNotUpdatedWhenParentsWereNotChanged();
        checkParentOverLimitFlag(entry);
        checkCacheWasUpdatedForChangedMFGName();
    }

    public void testCommitPlanWithReciprocalFlagSet() throws Exception {
        LoginUser user = new LoginUser("DBUNIT");
        PlanService planService = (PlanService) AbstractGenericFactory.getInstance().getBean("planService");
        planService.commitPlan(user, "Test Committing Parent Plan", new Long(100), new Long(100));

        DBTemplate template = (DBTemplate) AbstractGenericFactory.getInstance().getBean("dbTemplate");
        List demandList = template.executeListResultQuery("lookupNewDemandByName", "HCL123");
        assertEquals(2, demandList.size());
        DemandForecast forecast = (DemandForecast) demandList.get(0);
        checkCommittedDemand(forecast, new Long(101), new Long(5886), new Integer(3006), "HCL123");
        forecast = (DemandForecast) demandList.get(1);
        checkCommittedDemand(forecast, new Long(103), new Long(5886), new Integer(3007), "HCL123");

        demandList = template.executeListResultQuery("lookupNewDemandByName", "HCL345");
        assertEquals(2, demandList.size());
        forecast = (DemandForecast) demandList.get(0);
        checkCommittedDemand(forecast, new Long(100), new Long(5886), new Integer(3006), "HCL345");
        forecast = (DemandForecast) demandList.get(1);
        checkCommittedDemand(forecast, new Long(102), new Long(5886), new Integer(3007), "HCL345");
    }

    public void testCommitPlanWithoutReciprocalFlagSet() throws Exception {
        LoginUser user = new LoginUser("DBUNIT");
        PlanService planService = (PlanService) AbstractGenericFactory.getInstance().getBean("planService");
        planService.commitPlan(user, "Test Committing Parent Plan", new Long(100), new Long(100));

        DBTemplate template = (DBTemplate) AbstractGenericFactory.getInstance().getBean("dbTemplate");
        List demandList = template.executeListResultQuery("lookupNewDemandByName", "91L27");
        assertEquals(2, demandList.size());
        DemandForecast forecast = (DemandForecast) demandList.get(0);
        checkCommittedDemand(forecast, new Long(101), new Long(5886), new Integer(3006), "91L27");
        forecast = (DemandForecast) demandList.get(1);
        checkCommittedDemand(forecast, new Long(103), new Long(5886), new Integer(3007), "91L27");

        demandList = template.executeListResultQuery("lookupNewDemandByName", "91L26");
        assertEquals(2, demandList.size());
        forecast = (DemandForecast) demandList.get(0);
        checkCommittedDemand(forecast, new Long(100), new Long(5886), new Integer(3006), "91L26");
        forecast = (DemandForecast) demandList.get(1);
        checkCommittedDemand(forecast, new Long(102), new Long(5886), new Integer(3007), "91L26");
    }

    public void testLookupPlansByPlanTypeId() throws Exception {
        PlanService planService = (PlanService) AbstractGenericFactory.getInstance().getBean("planService");
        List planList = planService.lookupPlansByPlanType(PlanType.PARENT_PLAN_TYPE_ID);
        assertEquals(1, planList.size());
        Plan plan = (Plan) planList.get(0);
        assertEquals(new Integer(1), plan.getPlanSummary().getMajorVersion());
        assertEquals(new Integer(0), plan.getPlanSummary().getMinorVersion());
        assertEquals("this is for testing", plan.getPlanSummary().getName());
        assertEquals(new SimpleDateFormat("yyyy-MM-dd").parse("2006-01-01"), plan.getPlanSummary().getLastModifiedDate());
    }

    private void checkCommittedDemand(DemandForecast forecast, Long units, Long channelId, Integer year, String name) {
        assertEquals(name, forecast.getCommonName());
        assertEquals(year, forecast.getYear());
        assertEquals(units, forecast.getData().getUnits());
        assertEquals(channelId, forecast.getChannel().getId());
    }

    private void checkCacheWasUpdatedForFemale() {
        DBTemplate template = (DBTemplate) AbstractGenericFactory.getInstance().getBean("dbTemplate");
        Long cacheId = (Long) template.executeSingleResultQuery("lookupLatestCacheEntryByPCMName", "DK7779");
        assertNotSame(new Long(104), cacheId);
    }

    private void checkCacheWasUpdatedForMale() {
        DBTemplate template = (DBTemplate) AbstractGenericFactory.getInstance().getBean("dbTemplate");
        Long cacheId = (Long) template.executeSingleResultQuery("lookupLatestCacheEntryByPCMName", "DK7780");
        assertNotSame(new Long(103), cacheId);
    }

    private void checkCacheWasNotUpdatedWhenParentsWereNotChanged() {
        DBTemplate template = (DBTemplate) AbstractGenericFactory.getInstance().getBean("dbTemplate");
        Long cacheId = (Long) template.executeSingleResultQuery("lookupLatestCacheEntryByPCMName", "EXP110");
        assertEquals(new Long(107), cacheId);
    }

    private void checkUserData(PlanEntry entry) {
        assertEquals(new Long(70), entry.getUserData().getLicPlan());
        assertEquals(new Long(71), entry.getUserData().getLicSa());
        assertEquals(new Long(72), entry.getUserData().getLicHi());
        assertEquals(new Long(73), entry.getUserData().getLicOth1());
        assertEquals(new Long(74), entry.getUserData().getLicOth2());
        assertEquals(new Long(75), entry.getUserData().getUsPlan());
        assertEquals(new Long(76), entry.getUserData().getUsSa());
        assertEquals(new Long(77), entry.getUserData().getUsHi());
        assertEquals(new Long(78), entry.getUserData().getUsOth1());
        assertEquals(new Long(79), entry.getUserData().getUsOth2());
        assertEquals(DatabaseConstants.TRUE_INDICATOR, entry.getUserData().getReciprocal());
        assertEquals(new Long(0), entry.getUserData().getY1Gap());
        assertEquals(new Long(83), entry.getUserData().getAdjustment());
        assertEquals("test plan", entry.getUserData().getPlanComment());
        assertEquals(new Double(84), entry.getUserData().getUsProdFactor1());
        assertEquals(new Double(85), entry.getUserData().getUsProdFactor2());
        assertEquals(new Double(86), entry.getUserData().getLicProdFactor1());
        assertEquals(new Double(87), entry.getUserData().getLicProdFactor2());
        assertEquals(new Double(0.1), entry.getUserData().getQaPercLossHeader());
        assertEquals(new Double(1), entry.getUserData().getForcedQaLossHeader());
        assertEquals(new Double(0), entry.getUserData().getMonthlyInventoryAdjustmentAuditHeader());
        assertEquals(new Double(1), entry.getUserData().getStageFactorHeader());
        assertEquals(new Double(0), entry.getUserData().getSomForcedHeader());
        assertEquals(new Double(.016), entry.getUserData().getReplantHeader());
        assertEquals(new Double(.24), entry.getUserData().getPipelineFactorHeader());
        assertEquals(new Double(0), entry.getUserData().getYearPlusOneSomForcedHeader());
        assertEquals(new Double(1), entry.getUserData().getHybridProdFactor1Header());
        assertEquals(new Double(1), entry.getUserData().getHybridProdFactor2Header());
        assertEquals(new Double(1), entry.getUserData().getParentProdFactor1Header());
        assertEquals(new Double(1), entry.getUserData().getParentProdFactor2Header());
    }

    private void checkCrossPlanData(PlanEntry entry) {
        assertEquals(new Double(782.25), entry.getCrossPlanData().getPlannedFemaleSeed());
        assertEquals(new Double(276.58125), entry.getCrossPlanData().getPlannedMaleSeed());
        assertEquals(new Double(0), entry.getCrossPlanData().getYearPlusOneFemaleSeed());
        assertEquals(new Double(0), entry.getCrossPlanData().getYearPlusOneMaleSeed());
        assertEquals(new Double(745), entry.getCrossPlanData().getAvailableSeed());
    }

    private void checkFlippedParentLimits(PlanEntry entry) {
        assertEquals(new Double(1000), entry.getParentLimit().getFemaleLimit());
        assertEquals(new Double(3000), entry.getParentLimit().getMaleLimit());
    }

    private void checkCacheWasNotUpdatedForReciprocal() {
        DBTemplate template = (DBTemplate) AbstractGenericFactory.getInstance().getBean("dbTemplate");
        Long cacheId = (Long) template.executeSingleResultQuery("lookupLatestCacheEntryByPCMName", "test-a");
        assertEquals(new Long(101), cacheId);
    }

    private void checkParentOverLimitFlag(PlanEntry entry) {
        assertEquals("", entry.getParentLimit().getOverlimitIndicator());
    }

    private void checkCacheWasUpdatedForChangedMFGName() {
        DBTemplate template = (DBTemplate) AbstractGenericFactory.getInstance().getBean("dbTemplate");
        Long cacheId = (Long) template.executeSingleResultQuery("lookupLatestCacheEntryByPCMName", "AS4500");
        assertNotSame(new Long(106), cacheId);
    }
}
