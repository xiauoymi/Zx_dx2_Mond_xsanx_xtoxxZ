package com.monsanto.wst.usseedplanning.services.maintenance.supply;

import com.monsanto.wst.usseedplanning.model.core.LoginUser;
import com.monsanto.wst.usseedplanning.model.maintenance.Revision;
import com.monsanto.wst.usseedplanning.model.maintenance.Channel;
import com.monsanto.wst.usseedplanning.model.maintenance.Year;
import com.monsanto.wst.usseedplanning.model.maintenance.supply.SupplyType;
import com.monsanto.wst.usseedplanning.model.maintenance.supply.Supply;
import com.monsanto.wst.usseedplanning.model.maintenance.supply.conversion.UomConversion;
import com.monsanto.wst.usseedplanning.model.maintenance.supply.data.SupplyMVK;
import com.monsanto.wst.usseedplanning.model.maintenance.supply.data.SupplyPartialBagPounds;
import com.monsanto.wst.usseedplanning.model.maintenance.supply.data.SupplyBulk;
import com.monsanto.wst.usseedplanning.model.maintenance.supply.experiment.SupplyTestResults;
import com.monsanto.wst.usseedplanning.services.core.ImportSpreadsheetService;
import com.monsanto.wst.usseedplanning.dao.*;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.regex.Pattern;
import java.util.regex.Matcher;

/**
 * Created by IntelliJ IDEA.
 * Date: Feb 12, 2007
 * Time: 3:44:48 PM
 * <p/>
 * TODO: Enter description for class.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class ZDCAUpdateSupplyService extends AbstractUpdateSupplyService {
    private ImportSpreadsheetService importSpreadsheetService;
    private SupplyDao supplyDao;
    private UomConversionDao uomConversionDao;
    private YearDao yearDao;

    public ZDCAUpdateSupplyService(ImportSpreadsheetService importSpreadsheetService, SupplyDao supplyDao, SupplyTypeDao supplyTypeDao, RevisionDao revisionDao, ChannelDao channelDao, UomConversionDao uomConversionDao, YearDao yearDao) {
        super(supplyTypeDao, revisionDao, channelDao);
        this.importSpreadsheetService = importSpreadsheetService;
        this.supplyDao = supplyDao;
        this.uomConversionDao = uomConversionDao;
        this.yearDao = yearDao;
    }

    // TODO: Change so that plan type id is passed in instead of name.
    public void updateSupply(File file, String comments, LoginUser owner, Long planType) throws IOException {
        List supplyList = this.importSpreadsheetService.getZDCASupply(file);
        Revision revision = createRevision(comments, owner, "Adding ZDCA Supply.");
        List factorsList = this.uomConversionDao.getAllFactors();
        Channel brandedChannel = getChannel(planType, Channel.BRANDED_CHANNEL);
        Year currentYear = this.yearDao.lookupCurrentYear();
        SupplyType supplyType = lookupSupplyType(SupplyType.ZDCA_SUPPLY_TYPE);
        for (int i = 0; i < supplyList.size(); i++) {
            Supply supply = (Supply) supplyList.get(i);
            setDefaults(supply);
            supply.setYear(currentYear);
            supply.setOwner(owner);
            supply.setRevision(revision);
            supply.setSupplyType(supplyType);
            supply.getIdentifiers().setChannel(brandedChannel);
            convertToSSU(factorsList, supply);
        }
        this.supplyDao.addSupply(supplyList);
    }

    private void setDefaults(Supply supply) {
        supply.setTestResults(new SupplyTestResults());
        supply.getData().setMVK(new SupplyMVK());
        supply.getData().setPartialBagPounds(new SupplyPartialBagPounds());
        supply.getData().setBulk(new SupplyBulk());
    }

    private void convertToSSU(List factorsList, Supply supply) {

        double factor = getFactorForDescription(factorsList, supply);

        supply.getData().getBags().setUnrestricted(
                new Double(supply.getData().getBags().getUnrestricted().doubleValue() *
                        factor));

        supply.getData().getBags().setRestricted(
                new Double(supply.getData().getBags().getRestricted().doubleValue() *
                        factor));

        supply.getData().getBags().setBlocked(
                new Double(supply.getData().getBags().getBlocked().doubleValue() *
                        factor));

    }

    private double getFactorForDescription(List factorsList, Supply supply) {
        Pattern pattern;
        Matcher matcher;
        boolean matched = false;
        double factor = 0;

        String description = supply.getIdentifiers().getDescription();
        description = description.replaceAll(supply.getIdentifiers().getManufacturingName(), "");

        for (int i = 0; i < factorsList.size(); i++) {
            pattern = Pattern.compile(((UomConversion) factorsList.get(i)).getDescription().toUpperCase());
            matcher = pattern.matcher(description.toUpperCase());
            if (matcher.find()) {
                matched = true;
                factor = ((UomConversion) factorsList.get(i)).getFactor().doubleValue();
                break;
            }
        }

        if (!matched) {
            throw new IllegalStateException("Unable to find a factor for description " + supply.getIdentifiers().getDescription() + " in conversion table");
        }
        return factor;
    }
}
