package com.monsanto.wst.usseedplanning.services.core;

import com.monsanto.wst.usseedplanning.model.planning.Plan;

import java.io.IOException;

/**
 * Created by IntelliJ IDEA.
 * Date: Sep 22, 2006
 * Time: 6:25:39 PM
 * <p/>
 * This interface defines the contract for export spreadsheets.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public interface ExportSpreadsheetService {
    /**
     * This method exports the specified plan object to a spreadsheet.
     *
     * @param plan Plan object representing the plan.
     * @return byte[] - Representing the bytes of the spreadsheet.
     * @throws java.io.IOException - If unable to create the spreadsheet.
     */
    byte[] getPlanSpreadsheet(Plan plan) throws IOException;
}
