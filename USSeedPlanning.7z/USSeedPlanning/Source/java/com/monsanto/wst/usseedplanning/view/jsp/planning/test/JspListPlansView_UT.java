package com.monsanto.wst.usseedplanning.view.jsp.planning.test;

import com.monsanto.wst.usseedplanning.utils.testutils.USSeedPlanningBaseTestCase;
import com.monsanto.wst.usseedplanning.view.jsp.planning.JspListPlansView;
import com.monsanto.wst.view.test.mock.MockUCCHelperThrowsIOException;
import com.monsanto.wst.view.ViewRenderingException;
import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.AbstractLogging.Logger;

/**
 * Created by IntelliJ IDEA.
 * Date: Nov 5, 2006
 * Time: 6:38:51 PM
 * <p/>
 * Unit test for the JspListPlansView object.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class JspListPlansView_UT extends USSeedPlanningBaseTestCase {
  public void testCreate() throws Exception {
    JspListPlansView view = new JspListPlansView();
    assertNotNull(view);
  }

  public void testRenderView() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);
    JspListPlansView view = new JspListPlansView();
    view.renderView(helper);
    assertTrue(helper.wasSentTo("/WEB-INF/jsp/planning/listPlans.jspx"));
  }

  public void testRenderViewThrowsException() throws Exception {
    MockUCCHelperThrowsIOException helper = new MockUCCHelperThrowsIOException(null);
    JspListPlansView view = new JspListPlansView();
    Logger.enableLogger(Logger.ERROR_LOG);
    try {
      view.renderView(helper);
      fail("This should have thrown an exception.");
    } catch (ViewRenderingException e) {
      assertEquals("Unable to Render View", e.getMessage());
    }

    Logger.disableLogger(Logger.ERROR_LOG);
    try {
      view.renderView(helper);
      fail("This should have thrown an exception.");
    } catch (ViewRenderingException e) {
      assertEquals("Unable to Render View", e.getMessage());
    }
  }
}
