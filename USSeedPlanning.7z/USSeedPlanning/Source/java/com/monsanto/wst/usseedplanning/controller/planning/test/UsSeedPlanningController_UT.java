/*
 UsSeedPlanningController_UT was created on Aug 17, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.usseedplanning.controller.planning.test;

import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.wst.usseedplanning.controller.planning.UsSeedPlanningController;
import com.monsanto.wst.usseedplanning.view.factory.ViewFactory;
import com.monsanto.wst.usseedplanning.view.factory.mock.MockViewFactory;
import com.monsanto.wst.view.test.mock.MockView;
import junit.framework.TestCase;

/**
 * Filename:    $RCSfile: UsSeedPlanningController_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: rgeorge $    	 On:	$Date: 2006-08-18 14:39:05 $
 *
 * @author ffbrac
 * @version $Revision: 1.1 $
 */
public class UsSeedPlanningController_UT extends TestCase {
	private MockUCCHelper helper;

	protected void setUp() throws Exception {
	    helper = new MockUCCHelper(null);
	}

	public void testCreate() throws Exception {
	    UsSeedPlanningController controller = new UsSeedPlanningController((ViewFactory)null);
	    assertNotNull(controller);
	}

	public void testRenderViewTomainPage() throws Exception {
	    ViewFactory viewFactory = new MockViewFactory();
	    UsSeedPlanningController controller = new UsSeedPlanningController(viewFactory);
	    controller.run(helper);
	    MockView view = (MockView) viewFactory.getPlanningView();
	    assertTrue(view.wasViewRendered());
	}

}