package com.monsanto.wst.usseedplanning.services.cache.mock;

import com.monsanto.wst.usseedplanning.model.cache.ProductDetails;
import com.monsanto.wst.usseedplanning.model.core.LoginUser;
import com.monsanto.wst.usseedplanning.services.cache.ProductCachingService;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * Date: Feb 23, 2007
 * Time: 1:20:41 PM
 * <p/>
 * TODO: Enter description for class.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class MockProductCachingService implements ProductCachingService {

    public List cacheSelectedProducts(List productCriteria, LoginUser currentUser) throws Exception {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public void cacheProductDetailsList(LoginUser currentUser, List productDetailsToCacheList) {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    public void addNewCacheEntry(String comments, LoginUser currentUser, ProductDetails productDetails) {
        //To change body of implemented methods use File | Settings | File Templates.
    }
}
