/*
 Copyright:  Copyright � 2006 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.usseedplanning.services.maintenance.seedEntity.dbServices.test;

import com.monsanto.wst.usseedplanning.model.maintenance.Active;
import com.monsanto.wst.usseedplanning.services.maintenance.seedEntity.dbServices.IsActiveAcceptTest;
import junit.framework.TestCase;

/**
 * Filename:    $RCSfile: IsActiveAcceptTest_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: jdpoul $
 * On:	$Date: 2006-10-11 21:24:32 $
 *
 * @author jdpoul
 * @version $Revision: 1.2 $
 */
public class IsActiveAcceptTest_UT extends TestCase {

  private IsActiveAcceptTest filter;

  public IsActiveAcceptTest_UT(String name) {
    super(name);
  }

  protected void setUp() throws Exception {
    super.setUp();
    filter = new IsActiveAcceptTest();
  }

  public void testCreate() throws Exception {
    IsActiveAcceptTest filter = new IsActiveAcceptTest();
    assertNotNull(filter);
  }

  public void testFilterNull() throws Exception {
    assertFalse(filter.accept(null));
  }

  public void testFilterActiveItem() throws Exception {
    Active active = new Active() {
      public Boolean getActiveStatus() {
        return Boolean.TRUE;
      }
    };

    assertTrue(filter.accept(active));

  }

  public void testFilterActiveItemShouldFilterTrue() throws Exception {
    Active active = new Active() {
      public Boolean getActiveStatus() {
        return Boolean.FALSE;
      }
    };

    assertFalse(filter.accept(active));

  }
}