package com.monsanto.wst.usseedplanning.services.core.xml.test;

import com.monsanto.wst.usseedplanning.services.core.xml.XMLLog4jLogReaderService;
import com.monsanto.wst.usseedplanning.services.core.LogReaderException;
import com.monsanto.wst.commonutils.resources.ResourceUtils;
import com.monsanto.wst.commonutils.xml.XMLUtilities;
import com.monsanto.wst.commonutils.xml.XMLParserException;
import junit.framework.TestCase;
import org.apache.commons.logging.LogFactory;
import org.apache.commons.logging.impl.Log4JLogger;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.w3c.dom.Document;

import java.io.File;
import java.util.List;
import java.util.Properties;

/**
 * Created by IntelliJ IDEA.
 * Date: Apr 7, 2006
 * Time: 8:00:54 AM
 * <p/>
 * This class is a junit test case for the XMLLog4jLogReaderService object.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class XMLLog4jLogReaderServiceUT extends TestCase {

    private static final String LOG4J_LOCATION = "com/monsanto/wst/usseedplanning/services/core/xml/test/test-log4j.xml";

    protected void setUp() throws Exception {
        ResourceUtils resourceUtils = new ResourceUtils();
        File catalinaHome = resourceUtils.convertPathToFile("com/monsanto/wst/usseedplanning/services/core/xml/test");
        System.setProperty("catalina.home", catalinaHome.getAbsolutePath());
        super.setUp();
    }

	protected void tearDown() throws Exception {
		System.setProperty("catalina.home", "");
		super.tearDown();
	}

//    public void testCreate() throws Exception {
//        ResourceUtils resourceUtils = new ResourceUtils();
//        XMLUtilities xmlUtils = new XMLUtilities(resourceUtils);
//        XMLLog4jLogReaderService service = new XMLLog4jLogReaderService(LOG4J_LOCATION, xmlUtils);
//        assertNotNull(service);
//    }

    public void testCreateLog4jXMLFileNotFound() throws Exception {
        ResourceUtils resourceUtils = new ResourceUtils();
        XMLUtilities xmlUtils = new MockXMLUtilities(resourceUtils);
        Logger logger = ((Log4JLogger) LogFactory.getLog(XMLLog4jLogReaderService.class)).getLogger();
        logger.setLevel(Level.OFF);
        try {
            new XMLLog4jLogReaderService(LOG4J_LOCATION, xmlUtils);
            fail("This should have thrown an exception.");
        } catch (LogReaderException e) {
            assertEquals("Unable to parse the log4j xml file at location: com/monsanto/wst/usseedplanning/services/core/xml/test/test-log4j.xml", e.getMessage());
        }

        logger.setLevel(Level.DEBUG);
        try {
            new XMLLog4jLogReaderService(LOG4J_LOCATION, xmlUtils);
            fail("This should have thrown an exception.");
        } catch (LogReaderException e) {
            assertEquals("Unable to parse the log4j xml file at location: com/monsanto/wst/usseedplanning/services/core/xml/test/test-log4j.xml", e.getMessage());
        }
    }

    public void testCreateBaseLogFileNotFound() throws Exception {
        ResourceUtils resourceUtils = new ResourceUtils();
        XMLUtilities xmlUtils = new XMLUtilities(resourceUtils);
        try {
            new XMLLog4jLogReaderService("com/monsanto/wst/usseedplanning/services/core/xml/test/test-log4j-invalid-dir.xml", xmlUtils);
            fail("This should have thrown an exception.");
        } catch (LogReaderException e) {
            assertEquals("Unable to find target log file defined in: com/monsanto/wst/usseedplanning/services/core/xml/test/test-log4j-invalid-dir.xml", e.getMessage());
        }
    }

    public void testCreateNoCatalinaHomeThrowsException() throws Exception {
        removeCatalinaHome();
        ResourceUtils resourceUtils = new ResourceUtils();
        XMLUtilities xmlUtils = new XMLUtilities(resourceUtils);
        try {
            new XMLLog4jLogReaderService(LOG4J_LOCATION, xmlUtils);
            fail("This should have thrown an exception.");
        } catch (LogReaderException e) {
            assertEquals("There is not a catalina.home system property set, check your server configuration.", e.getMessage());
        }
    }

    public void testCreateEmptyLogFileLocation() throws Exception {
        ResourceUtils resourceUtils = new ResourceUtils();
        XMLUtilities xmlUtils = new XMLUtilities(resourceUtils);
        try {
            new XMLLog4jLogReaderService("com/monsanto/wst/usseedplanning/services/core/xml/test/test-log4j-empty-log-file-location.xml", xmlUtils);
            fail("This should have thrown an exception.");
        } catch (LogReaderException e) {
            assertEquals("Unable to find target log file defined in: com/monsanto/wst/usseedplanning/services/core/xml/test/test-log4j-empty-log-file-location.xml", e.getMessage());
        }
    }

    //TODO Still have to figure out why this fials
//    public void testGetLogFileListReturnsListOfLogFiles() throws Exception {
//        ResourceUtils resourceUtils = new ResourceUtils();
//        XMLUtilities xmlUtils = new XMLUtilities(resourceUtils);
//        XMLLog4jLogReaderService service = new XMLLog4jLogReaderService(LOG4J_LOCATION, xmlUtils);
//        List logFileList = service.getLogFileList();
//        System.out.println(logFileList);
//        assertNotNull(logFileList);
//        assertEquals(1, logFileList.size());
//    }

    public void testGetLogFileReturnsCorrectLogFile() throws Exception {
        ResourceUtils resourceUtils = new ResourceUtils();
        XMLUtilities xmlUtils = new XMLUtilities(resourceUtils);
        XMLLog4jLogReaderService service = new XMLLog4jLogReaderService(LOG4J_LOCATION, xmlUtils);
        File file = service.getLogFile("test.log");
        assertNotNull(file);
        assertEquals("test.log", file.getName());
    }

    public void testGetLogFileDoesNotExistReturnsNull() throws Exception {
        ResourceUtils resourceUtils = new ResourceUtils();
        XMLUtilities xmlUtils = new XMLUtilities(resourceUtils);
        XMLLog4jLogReaderService service = new XMLLog4jLogReaderService(LOG4J_LOCATION, xmlUtils);
        File file = service.getLogFile("doesnotexist.log");
        assertNull(file);
    }

    private void removeCatalinaHome() {
        Properties props = System.getProperties();
        props.remove("catalina.home");
        System.setProperties(props);
    }

    private class MockXMLUtilities extends XMLUtilities {

        /**
         * This constructor takes a resource resolver object.
         *
         * @param resourceUtils Object representing a resource resolver.
         */
        public MockXMLUtilities(ResourceUtils resourceUtils) {
            super(resourceUtils);
        }

        public Document createDocument(String documentPath) throws XMLParserException {
            throw new XMLParserException("Test Exception");
        }

    }

}
