/*
 Copyright:  Copyright � 2006 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.usseedplanning.services.maintenance.seedEntity.dbServices.test;

import junit.framework.TestCase;
import com.monsanto.wst.usseedplanning.services.maintenance.seedEntity.dbServices.YearServiceDbImpl;
import com.monsanto.wst.usseedplanning.dao.mock.MockYearDao;

import java.util.List;

/**
 * Filename:    $RCSfile: YearDbServiceImpl_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: jdpoul $    	 On:	$Date: 2006-09-15 19:26:37 $
 *
 * @author JDPOUL
 * @version $Revision: 1.1 $
 */
public class YearDbServiceImpl_UT extends TestCase {
  public YearDbServiceImpl_UT(String name) {
    super(name);
  }

  public void testCreate() throws Exception {
    YearServiceDbImpl service = new YearServiceDbImpl(new MockYearDao());
    assertNotNull(service);
  }

  public void testCreateWNullDao() throws Exception {
    try {
      YearServiceDbImpl service = new YearServiceDbImpl(null);
      fail("When passed a null value, the constructor of YearServiceImpl should throw an IllegalArgumentException.");
    } catch (IllegalArgumentException e) {
      assertEquals("The YearServiceImpl constructor should throw an IllegalArgumentException when passed a null Dao.", e.getMessage());

    }

  }

  public void testGetActiveYearsWResults() throws Exception {
    YearServiceDbImpl service = new YearServiceDbImpl(new MockYearDao());
    List years = service.getActiveYears();
    assertEquals(2, years.size());
  }
}