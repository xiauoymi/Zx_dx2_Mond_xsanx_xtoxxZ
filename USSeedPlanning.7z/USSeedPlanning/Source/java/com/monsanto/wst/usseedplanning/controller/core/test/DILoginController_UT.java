package com.monsanto.wst.usseedplanning.controller.core.test;

import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.ServletFramework.UseCaseController;
import com.monsanto.securityinterfaces.SystemSecurityProxy;
import com.monsanto.securityinterfaces.Test.MockSystemSecurityProxy;
import com.monsanto.wst.commonutils.reflection.ObjectInspector;
import com.monsanto.wst.dbtemplate.transaction.test.mock.MockTransactionManager;
import com.monsanto.wst.emailtemplate.domain.EmailHeaderInfo;
import com.monsanto.wst.emailtemplate.services.EmailService;
import com.monsanto.wst.factory.AbstractGenericFactory;
import com.monsanto.wst.factory.AbstractLocatorGenericFactory;
import com.monsanto.wst.factory.BeanInitializationException;
import com.monsanto.wst.servletframework.DITransactionalController;
import com.monsanto.wst.usseedplanning.constants.MainConstants;
import com.monsanto.wst.usseedplanning.controller.core.DILoginController;
import com.monsanto.wst.usseedplanning.model.core.LoginUser;
import com.monsanto.wst.usseedplanning.services.core.LatestRevisionService;
import com.monsanto.wst.usseedplanning.services.core.LoginService;
import com.monsanto.wst.usseedplanning.services.core.LookupService;
import com.monsanto.wst.usseedplanning.services.core.UserRoleService;
import com.monsanto.wst.usseedplanning.services.core.mock.MockLatestRevisionService;
import com.monsanto.wst.usseedplanning.services.core.mock.MockLoginService;
import com.monsanto.wst.usseedplanning.services.core.mock.MockLookupService;
import com.monsanto.wst.usseedplanning.services.core.mock.MockUserRoleService;
import com.monsanto.wst.usseedplanning.utils.testutils.USSeedPlanningBaseTestCase;
import com.monsanto.wst.usseedplanning.view.factory.ViewFactory;
import com.monsanto.wst.usseedplanning.view.factory.mock.MockViewFactory;
import com.monsanto.wst.view.test.mock.MockView;
import com.monsanto.wst.view.View;
import org.apache.commons.logging.LogFactory;
import org.apache.commons.logging.impl.Log4JLogger;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;

import java.io.IOException;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by IntelliJ IDEA. User: rgeorge Date: Aug 3, 2006 Time: 1:42:56 PM To change this template use File |
 * Settings | File Templates.
 */
public class DILoginController_UT extends USSeedPlanningBaseTestCase {
    LoginMockUCCHelper helper = null;

    protected void setUp() throws Exception {
        super.setUp();
        AbstractGenericFactory.clear();
        AbstractGenericFactory.setImplementation(
                "com.monsanto.wst.usseedplanning.controller.core.test.DILoginController_UT$MockGenericFactory");
        helper = new LoginMockUCCHelper("/test");
        MockTransactionManager txManager = new MockTransactionManager();
        AbstractGenericFactory.getInstance().addBean("transactionManager", txManager, true);
        helper.setContextAttribute(DITransactionalController.TRANSACTION_MANAGER_CTX_ATTRIBUTE, txManager);
    }

    public void testCreate() throws Exception {
        DILoginController controller = new DILoginController();
        assertNotNull(controller);
    }

    public void testLoginSuccess() throws Exception {
        MockGenericFactory.loginService = new MockLoginService();
        MockGenericFactory.controller = new MockController();
        DILoginController controller = new DILoginController();
        controller.run(helper);
        assertNotNull(helper.getSessionParameter(MainConstants.LOGINUSER));
        MockGenericFactory container = (MockGenericFactory) AbstractGenericFactory.getInstance();
        assertTrue(((MockController) container.getBean("/test")).wasRunCalled());
        assertEquals(MockSystemSecurityProxy.class, container.getBean("systemSecurityProxy").getClass());
        assertEquals(1073741824, helper.getMaxImportFileSize());
    }

    public void testLoginOnlyOncePerSession() throws Exception {
        MockLoginService mockLoginService = new MockLoginService();
        MockGenericFactory.loginService = mockLoginService;
        MockGenericFactory.controller = new MockController();
        DILoginController controller = new DILoginController();
        helper.setSessionParameter(MainConstants.LOGINUSER, new LoginUser());
        controller.run(helper);
        assertNotNull(helper.getSessionParameter(MainConstants.LOGINUSER));
        assertFalse(mockLoginService.wasAuthorized());
        assertFalse(mockLoginService.wasUserRetrieved());
    }

    public void testLoginFailed() throws Exception {
        MockGenericFactory.loginService = new MockLoginService();
        MockGenericFactory.controller = new MockController();
        ((MockLoginService) MockGenericFactory.loginService).setIsAuthorized(false);
        DILoginController controller = new DILoginController();
        controller.run(helper);
        assertNull(helper.getSessionParameter(MainConstants.LOGINUSER));
        MockGenericFactory container = (MockGenericFactory) AbstractGenericFactory.getInstance();
        assertFalse(((MockController) container.getBean("/test")).wasRunCalled());
        assertTrue(((MockView) container.getBean("errorPage")).wasViewRendered());
    }

    public void testExceptionCausesNotificationEmail() throws Exception {
        MockGenericFactory.loginService = new MockLoginService();
        MockGenericFactory.emailService = new MockEmailService();
        MockGenericFactory.controller = new MockControllerThrowsException();
        DILoginController controller = new DILoginController();
        controller.run(helper);
        MockEmailService emailService = (MockEmailService) MockGenericFactory.emailService;
        assertTrue(emailService.getHeaderInfo().getToEmailAddresses().contains("junit@monsanto.com"));
        assertEquals("unexpectedErrorEmail", emailService.getTemplateId());
    }

    public void testWhenExceptionOccursUserIsForwardedToGeneralErrorPage() throws Exception {
        MockGenericFactory.loginService = new MockLoginService();
        MockGenericFactory.emailService = new MockEmailService();
        MockGenericFactory.controller = new MockControllerThrowsException();
        DILoginController controller = new DILoginController();
        MockGenericFactory container = (MockGenericFactory) AbstractGenericFactory.getInstance();
        helper.setRequestParameterValue("testParam", "testValue");
        Logger logger = ((Log4JLogger) LogFactory.getLog(DILoginController.class)).getLogger();
        logger.setLevel(Level.OFF);
        controller.run(helper);
        assertTrue(((MockView) container.getBean("allExceptionsView")).wasViewRendered());
        assertEquals(Boolean.TRUE, helper.getRequestAttributeValue(DITransactionalController.ROLLBACK__FLAG));

        logger.setLevel(Level.DEBUG);
        controller.run(helper);
        assertTrue(((MockView) container.getBean("allExceptionsView")).wasViewRendered());
        assertEquals(Boolean.TRUE, helper.getRequestAttributeValue(DITransactionalController.ROLLBACK__FLAG));
    }

    private class LoginMockUCCHelper extends MockUCCHelper {
        private String contextPath;
        private int maxImportSize;

        public LoginMockUCCHelper(String cstrRequestedURL) {
            super(cstrRequestedURL);
        }

        public LoginMockUCCHelper(String cstrRequestedURL, String cstrServletName) {
            super(cstrRequestedURL, cstrServletName);
        }

        public LoginMockUCCHelper(String cstrRequestedURL, boolean systemSecurityEnabled, SystemSecurityProxy proxy) {
            super(cstrRequestedURL, systemSecurityEnabled, proxy);
        }

        public Date getLastLogon() {
            return new Date();
        }

        public LoginMockUCCHelper(String cstrRequestedURL, boolean boolApplyStylesheet) {
            super(cstrRequestedURL, boolApplyStylesheet);
        }

        public String getAuthenticatedUserID() {
            return "JUNIT";
        }

        public String getAuthenticatedUserFullName() {
            return "GEORGE, RIJO C [AG/CONTRACTOR - 1000]";
        }

        public void setContextPath(String contextPath) {
            this.contextPath = contextPath;
        }

        public String getContextPath() {
            return this.contextPath;
        }

        public SystemSecurityProxy getSystemSecurityProxy() {
            return new MockSystemSecurityProxy();
        }

        public int setMaxImportFileSize(int iMaxSize) {
            this.maxImportSize = iMaxSize;
            return 0;
        }

        public int getMaxImportFileSize() {
            return this.maxImportSize;
        }
    }

    private static class MockController implements UseCaseController {
        private boolean wasCalled = false;

        public void run(UCCHelper helper) throws IOException {
            this.wasCalled = true;
        }

        public boolean wasRunCalled() {
            return this.wasCalled;
        }
    }

    private static class MockControllerThrowsException implements UseCaseController {
        public void run(UCCHelper helper) throws IOException {
            throw new IOException();
        }
    }

    public static class MockGenericFactory extends AbstractLocatorGenericFactory {
        private static UseCaseController controller;
        private String beanId;
        public static LoginService loginService;
        public static EmailService emailService;
        private MockUserRoleService userRoleService = new MockUserRoleService();
        private MockLookupService lookupService = new MockLookupService();
        private LatestRevisionService latestRevisionService = new MockLatestRevisionService();
        private MockViewFactory viewFactory = new MockViewFactory();
        private MockView errorPage = new MockView();
        private MockView exceptionPage = new MockView();
        private Map addedBeans = new HashMap();

        public MockGenericFactory() {
            super(new ObjectInspector());
        }

        public Object getBean(String beanId) throws BeanInitializationException {
            this.beanId = beanId;
            if ("/test".equals(beanId)) {
                return controller;
            } else if ("systemSecurityProxy".equals(beanId)) {
                return getSystemSecurityProxy();
            } else if (addedBeans.containsKey(beanId)) {
                return addedBeans.get(beanId);
            }
            return super.getBean(beanId);
        }

        public void addBean(String beanId, Object obj, boolean isSingleton) {
            this.addedBeans.put(beanId, obj);
        }

        public String getBeanId() {
            return this.beanId;
        }

        public LoginService getLoginService() {
            return loginService;
        }

        public UserRoleService getUserRoleService() {
            return this.userRoleService;
        }

        public LookupService getLookupService() {
            return this.lookupService;
        }

        public LatestRevisionService getLatestRevisionSerivce() {
            return this.latestRevisionService;
        }

        public ViewFactory getViewFactory() {
            return this.viewFactory;
        }

        public String getDataSourceConfigFile() {
            return "database/dbtemplate-config.xml";
        }

        public SystemSecurityProxy getSystemSecurityProxy() {
            return (SystemSecurityProxy) this.addedBeans.get("systemSecurityProxy");
        }

        public EmailService getEmailService() {
            return emailService;
        }

        public View getAllExceptionsView() {
            return exceptionPage;
        }

        public View getErrorPage() {
            return errorPage;
        }
    }

    private class MockEmailService implements EmailService {
        private EmailHeaderInfo headerInfo;
        private String templateId;

        public void sendEmail(String templateId, EmailHeaderInfo headerInfo, Object mapping) {
            this.headerInfo = headerInfo;
            this.templateId = templateId;
        }

        public EmailHeaderInfo getHeaderInfo() {
            return headerInfo;
        }

        public String getTemplateId() {
            return templateId;
        }
    }
}
