/*
 MockStageFactoryService was created on Sep 18, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.usseedplanning.services.maintenance.seedEntity.mock;

import com.monsanto.wst.usseedplanning.model.maintenance.Stage;
import com.monsanto.wst.usseedplanning.model.maintenance.StageFactor;
import com.monsanto.wst.usseedplanning.model.maintenance.Year;
import com.monsanto.wst.usseedplanning.services.maintenance.seedEntity.StageFactorService;

import java.util.List;
import java.util.ArrayList;

/**
 * Filename:    $RCSfile: MockStageFactorService.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: njminsh $
 * On:	$Date: 2007-02-13 19:21:05 $
 *
 * @author sspati1
 * @version $Revision: 1.8 $
 */
public class MockStageFactorService implements StageFactorService {

  private boolean getAllApplicableStageFactors = false;
  private boolean wasAdded = false;
  private boolean isRetrieveByRevisionId = false;


  public StageFactor lookupStageFactorsByRevisionId(Long revisionId) {
    StageFactor stageFactor = null;
    if (revisionId != null) {
      isRetrieveByRevisionId = true;
      stageFactor = new StageFactor();
      Stage stage = new Stage();
      stage.setStageId(new Long(123));
      stage.setStage("test stage");
      stageFactor.setStage(stage);
      Year year = new Year();
      year.setId(new Long(12));
      year.setYear(new Integer(2006));
      stageFactor.setYear(year);
    }
    return stageFactor;
  }

  public void saveStageFactor(StageFactor stageFactor, String comments) {
    this.wasAdded = true;
  }

  public boolean isWasAdded() {
    return wasAdded;
  }


  public boolean isRetrieveByRevisionId() {
    return isRetrieveByRevisionId;
  }

  public List getAllApplicableStageFactorsInOrderOfPrecedence(String productNameCriteria, Long yearCriteria,
                                                              Long genderCriteria, Long maxRevisionId) {
    getAllApplicableStageFactors = true;
    return new ArrayList();
  }

  public StageFactor getMostAppropriateStageFactor(String productNameCriteria, Long yearCriteria, Long genderCriteria,
                                                   Long maxRevisionId) {
    return new StageFactor();
  }

  public boolean isGetAllApplicableStageFactors() {
    return getAllApplicableStageFactors;
  }

}