package com.monsanto.wst.usseedplanning.services.maintenance.seedEntity.dbServices;

import com.monsanto.AbstractLogging.LoggableError;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.wst.commonutils.collection.CollectionUtil;
import com.monsanto.wst.usseedplanning.dao.RevisionDao;
import com.monsanto.wst.usseedplanning.dao.YieldTargetDao;
import com.monsanto.wst.usseedplanning.model.core.LoginUser;
import com.monsanto.wst.usseedplanning.model.maintenance.Gender;
import com.monsanto.wst.usseedplanning.model.maintenance.Revision;
import com.monsanto.wst.usseedplanning.model.maintenance.Year;
import com.monsanto.wst.usseedplanning.model.maintenance.YieldTargetFactor;
import com.monsanto.wst.usseedplanning.services.maintenance.seedEntity.YieldTargetService;
import com.monsanto.wst.usseedplanning.utils.factor.OrderOfPrecedenceBasedObjectComparator;

import java.util.*;

/**
 * Created by IntelliJ IDEA. User: rgeorge Date: Aug 4, 2006 Time: 1:42:53 PM To change this template use File |
 * Settings | File Templates.
 */
public class YieldTargetDbServiceImpl implements YieldTargetService {

  private static final String TARGET_YEAR_FIELD_NAME = "targetYear.id";
  private static final String GENDER_FIELD_NAME = "gender.id";
  private static final String PRODUCT_NAME_FIELD_NAME = "productName";

  private static final Map ORDER_OF_PRECEDENCE_MAP = new HashMap();
  private static final Set FIELDS_TO_COMPARE_SET = new HashSet();

  static {
    ORDER_OF_PRECEDENCE_MAP.put(PRODUCT_NAME_FIELD_NAME, new Integer(3));
    ORDER_OF_PRECEDENCE_MAP.put(TARGET_YEAR_FIELD_NAME, new Integer(2));

    FIELDS_TO_COMPARE_SET.add(TARGET_YEAR_FIELD_NAME);
    FIELDS_TO_COMPARE_SET.add(GENDER_FIELD_NAME);
    FIELDS_TO_COMPARE_SET.add(PRODUCT_NAME_FIELD_NAME);

  }

  private YieldTargetDao yieldTargetDao;
  private RevisionDao revisionDao;


  public YieldTargetDbServiceImpl(YieldTargetDao yieldTargetDao, RevisionDao revisionDao) {
    this.yieldTargetDao = yieldTargetDao;
    this.revisionDao = revisionDao;
  }

  public void saveYieldTargetFactor(YieldTargetFactor yieldTargetFactor) {
    Long revisionId = revisionDao.insert(getRevision(yieldTargetFactor));
    yieldTargetFactor.getRevision().setId(revisionId);
    yieldTargetDao.insert(yieldTargetFactor);
  }

  private Revision getRevision(YieldTargetFactor yieldTargetFactor) {
    return new Revision(null, yieldTargetFactor.getRevision().getComment(), yieldTargetFactor.getModDate(), null,
        yieldTargetFactor.getModUser(), new LoginUser(yieldTargetFactor.getModUser()));
  }

  public YieldTargetFactor getYieldTargetByRevisionId(String revisionIdString) {
    Long revisionId = getRevisionIdInValidFormat(revisionIdString);
    if (revisionId != null) {
      return yieldTargetDao.getYieldTargetByRevisionId(revisionId);
    }
    return null;
  }

  public List getAllApplicableYieldTargetFactorsInOrderOfPrecedence(String productNameCriteria, Long yearCriteria,
                                                                    Long genderCriteria, Long maxRevisionId) {
    List unsortedYieldTargets = yieldTargetDao.getAllApplicableYieldTargetFactors(maxRevisionId);
    if (unsortedYieldTargets.isEmpty()) {
      return unsortedYieldTargets;
    } else {
      List sortedFactors = sortFactorsByPrecedence(yearCriteria, genderCriteria, productNameCriteria,
          unsortedYieldTargets);
      return removeNotApplicableYieldTargetFactorsFromListSortedByPrecedence(sortedFactors);
    }
  }

  public YieldTargetFactor getMostAppropriateYieldTargetFactor(String productNameCriteria, Long yearCriteria,
                                                               Long genderCriteria, Long maxRevisionId) {
    List allApplicableYieldTargetFactors = getAllApplicableYieldTargetFactorsInOrderOfPrecedence(productNameCriteria,
        yearCriteria, genderCriteria, maxRevisionId);
    if (allApplicableYieldTargetFactors != null && allApplicableYieldTargetFactors.size() > 0) {
      return findFirstActiveTargetFactorInList(getAllApplicableYieldTargetFactorsInOrderOfPrecedence(
          productNameCriteria, yearCriteria, genderCriteria, maxRevisionId));
    } else {
      return null;
    }

  }

  public List removeNotApplicableYieldTargetFactorsFromListSortedByPrecedence(List sortedYieldTargets) {
    return CollectionUtil.truncateList(sortedYieldTargets, new IsDefaultAcceptTest());
  }

  private YieldTargetFactor findFirstActiveTargetFactorInList(List allApplicableYieldTargetFactorsInOrderOfPrecedence) {
    CollectionUtil.filter(allApplicableYieldTargetFactorsInOrderOfPrecedence, new IsActiveAcceptTest());
    if (allApplicableYieldTargetFactorsInOrderOfPrecedence != null &&
        allApplicableYieldTargetFactorsInOrderOfPrecedence.size() > 0) {
      return (YieldTargetFactor) allApplicableYieldTargetFactorsInOrderOfPrecedence.get(0);
    }
    return null;
  }


  private List sortFactorsByPrecedence(Long yearCriteria, Long genderCriteria, String productNameCriteria,
                                       List unsortedYieldTargets) {
    YieldTargetFactor compareTo = createShellYieldTargetFactorFromCriteria(yearCriteria, genderCriteria,
        productNameCriteria);

    return sortYieldTargetsByOrderOfPrecedence(compareTo, unsortedYieldTargets);
  }


  private List sortYieldTargetsByOrderOfPrecedence(YieldTargetFactor compareTo, List unsortedYieldTargets) {
    OrderOfPrecedenceBasedObjectComparator yieldTargetComparator = new OrderOfPrecedenceBasedObjectComparator();
    yieldTargetComparator.setFieldNamesToCompare(FIELDS_TO_COMPARE_SET);
    yieldTargetComparator.setDimensionComparisonOrderOfPrecedence(ORDER_OF_PRECEDENCE_MAP);


    yieldTargetComparator.setObjectToCompareTo(compareTo);

    Collections.sort(unsortedYieldTargets, yieldTargetComparator);
    return unsortedYieldTargets;
  }


  private Long getRevisionIdInValidFormat(String revisionId) {
    try {
      return new Long(String.valueOf(Long.parseLong(revisionId)));
    } catch (Exception e) {
      if (Logger.isEnabled(Logger.ERROR_LOG)) {
        Logger
            .log(new LoggableError("YieldTargetDbServiceImpl.getYieldTargetByRevisionId(): Invalid revisionId string"));
      }
    }
    return null;
  }

  private YieldTargetFactor createShellYieldTargetFactorFromCriteria(Long yearCriteria, Long genderCriteria,
                                                                     String productNameCriteria) {
    YieldTargetFactor compareTo = new YieldTargetFactor();
    compareTo.setProductName(productNameCriteria);
    Gender gender = new Gender();
    gender.setId(genderCriteria);
    Year year = new Year();
    year.setId(yearCriteria);
    compareTo.setGender(gender);
    compareTo.setTargetYear(year);
    return compareTo;
  }


}