package com.monsanto.wst.usseedplanning.container;

import com.monsanto.wst.factory.ApplicationContainerAware;
import com.monsanto.wst.factory.GenericFactory;
import com.monsanto.wst.dbtemplate.DBTemplate;
import com.monsanto.wst.dbtemplate.DBTemplateImpl;
import com.monsanto.wst.dbtemplate.transaction.TransactionManager;
import com.monsanto.wst.usseedplanning.dao.*;
import com.monsanto.wst.usseedplanning.dao.dbTemplate.*;

/**
 * Created by IntelliJ IDEA.
 * Date: Feb 11, 2007
 * Time: 6:14:40 PM
 * <p/>
 * TODO: Enter description for class.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class DaoFactory implements ApplicationContainerAware {
    private GenericFactory container;

    public String getDataSourceConfigFile() {
        return "database/dbtemplate-config.xml";
    }

    /**
     * This method returns the mapping files used by dbtemplate.
     *
     * @return String[] - Representing the mapping files.
     */
    public String[] getDBTemplateMappings() {
        return new String[] {
                "database/dbTemplate.xml",
                "database/dbTemplate-planning.xml",
                "database/dbTemplate-supply.xml",
                "database/dbtemplate-reference-data.xml",
                "database/dbtemplate-demand.xml",
                "database/dbtemplate-security.xml"
        };
    }

    /**
     * This method returns the current implementation of the dbtemplate object.
     *
     * @return DBTemplate - Object used for accessing a database.
     */
    public DBTemplate getDbTemplate() {
        TransactionManager txManager = (TransactionManager) container.getBean("transactionManager");
        return new DBTemplateImpl(txManager, getDBTemplateMappings());
    }

    /**
     * This method returns the current implementation of the channel dao object.
     *
     * @return ChannelDao - Object representing the channel dao.
     */
    public ChannelDao getChannelDao() {
        return new DBTemplateChannelDao(getDbTemplate());
    }

    public LookupDao getLookupDao() {
        return new DBTemplateLookupDao(getDbTemplate());
    }

    public CommonUploadDao getCommonUploadDao() {
        return new DBTemplateCommonUploadDao(getDbTemplate());
    }

    public DashboardReportDao getDashboardReportDao() {
        return new DBTemplateDashboardReportDao(getDbTemplate());
    }

    public FactorDao getFactorDao() {
        return new DBTemplateFactorDao(getDbTemplate());
    }

    public PlanRevisionDao getPlanRevisionDao() {
        return new DBTemplatePlanRevisionDao(getDbTemplate());
    }

    /**
     * This method returns the current implementation of the uomConversion dao object.
     *
     * @return UomConversion - Object representing the UomConversion dao.
     */
    public UomConversionDao getUomConversionDao() {
        return new DBTemplateUomConversionDao(getDbTemplate());
    }

    public YearDao getYearDao() {
        return new DbTemplateYearDao(getDbTemplate());
    }

    public GenderDao getGenderDao() {
        return new DbTemplateGenderDao(getDbTemplate());
    }

    public QaThresholdTypeDao getQaThresholdTypeDao() {
        return new DbTemplateQaThresholdTypeDao(getDbTemplate());
    }

    /**
     * This method returns the current implementation of the revision dao object.
     *
     * @return RevisionDao - Object representing the revision dao.
     */
    public RevisionDao getRevisionDao() {
        return new DBTemplateRevisionDao(getDbTemplate());
    }


    /**
     * This method returns the current implementation of the stage factor dao object.
     *
     * @return StageFactorDao - Object representing the stageFactor dao.
     */
    public StageFactorDao getStageFactorDao() {
        return new DBTemplateStageFactorDao(getDbTemplate());
    }

    /**
     * This method returns the current implementation of the stage dao object.
     *
     * @return StageDao - Object representing the stage dao.
     */
    public StageDao getStageDao() {
        return new DBTemplateStageDao(getDbTemplate());
    }

    /**
     * This method returns the current implementation of the demand dao object.
     *
     * @return DemandDao - Object representing the demand dao.
     */
    public DemandDao getDemandDao() {
        return new DBTemplateDemandDao(getDbTemplate());
    }

    /**
     * This method returns the current implementation of the login dao object.
     *
     * @return LoginDAO - Object representing the demand dao.
     */
    public LoginDAO getLoginDao() {
        return new DBTemplateLoginDao(getDbTemplate());
    }

    public UserRoleDao getUserRoleDao() {
        return new DBTemplateUserRoleDao(getDbTemplate());
    }

    /**
     * This method returns the current implementation of the supply dao object.
     *
     * @return SupplyDao - Object representing the supply dao.
     */
    public SupplyDao getSupplyDao() {
        return new DBTemplateSupplyDao(getDbTemplate());
    }

    /**
     * This method returns the current implementation of the supply type dao object.
     *
     * @return SupplyTypeDao - Object representing the supply type dao.
     */
    public SupplyTypeDao getSupplyTypeDao() {
        return new DBTemplateSupplyTypeDao(getDbTemplate());
    }

    public QaThresholdDao getQaThresholdDao() {
        return new DBTemplateQAThresholdDAO(getDbTemplate());
    }

    /**
     * This method returns an instance of the current PlanDao implementation.
     *
     * @return PlanDao - Object representing the plan dao.
     */
    public PlanDao getPlanDao() {
        return new DBTemplatePlanDao(getDbTemplate());
    }

    public QaThresholdComparisonStrategyDao getQaThresholdComparisonStrategyDao() {
        return new DbTemplateQaThresholdComparisonStrategyDao(getDbTemplate());
    }

    public YieldTargetDao getYieldTargetDao() {
        return new DbTemplateYieldTargetDao(getDbTemplate());
    }

    public ProductDetailsDao getProductDetailsDao() {
        return new DBTemplateProductDetailsDao(getDbTemplate());
    }

    public BatchDao getBatchDao() {
        return new DBTemplateBatchDao(getDbTemplate());
    }

    public PlanTypeDao getPlanTypeDao() {
        return new DBTemplatePlanTypeDao(getDbTemplate());
    }

    public void setApplicationContainer(GenericFactory container) {
        this.container = container;
    }
}
