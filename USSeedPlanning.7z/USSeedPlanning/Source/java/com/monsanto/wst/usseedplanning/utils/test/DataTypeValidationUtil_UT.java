package com.monsanto.wst.usseedplanning.utils.test;

import com.monsanto.wst.usseedplanning.utils.DataTypeValidationUtil;
import com.monsanto.wst.usseedplanning.utils.exception.InvalidFormatException;
import junit.framework.TestCase;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Aug 4, 2006
 * Time: 9:33:49 AM
 * To change this template use File | Settings | File Templates.
 */
public class DataTypeValidationUtil_UT extends TestCase {

    public void testCreate() throws Exception {
        DataTypeValidationUtil util = new DataTypeValidationUtil();
        assertNotNull(util);
    }

    public void testCheckIfdoubleValueIsCorrect() throws InvalidFormatException {
        Double value = null;
        value = new Double(DataTypeValidationUtil.getdoubleValue("0"));
        assertEquals("0.0",String.valueOf(value));
        value = new Double(DataTypeValidationUtil.getdoubleValue(".5"));
        assertEquals("0.5",String.valueOf(value));
        value = new Double(DataTypeValidationUtil.getdoubleValue("25.55"));
        assertEquals("25.55",String.valueOf(value));
        value = new Double(DataTypeValidationUtil.getdoubleValue("100"));
        assertEquals("100.0",String.valueOf(value));
    }

    public void testCheckIfDoubleValueIsCorrect() throws InvalidFormatException {
        Double value = null;
        value = DataTypeValidationUtil.getDoubleValue("0");
        assertEquals("0.0",String.valueOf(value));
        value = DataTypeValidationUtil.getDoubleValue(".5");
        assertEquals("0.5",String.valueOf(value));
        value = DataTypeValidationUtil.getDoubleValue("25.55");
        assertEquals("25.55",String.valueOf(value));
        value = DataTypeValidationUtil.getDoubleValue("100");
        assertEquals("100.0",String.valueOf(value));
        value = DataTypeValidationUtil.getDoubleValue("");
        assertEquals("0.0",String.valueOf(value));
        value = DataTypeValidationUtil.getDoubleValue(null);
        assertEquals("0.0",String.valueOf(value));
    }

    public void testAlphaCharactersConvertToDoubleThrowsException() {
        try {
                DataTypeValidationUtil.getDoubleValue("Hello");
                fail("Exception Not thrown.");
        } catch (InvalidFormatException e) {
            assertTrue(true);
            assertEquals("Cannot Format String into Double", e.getMessage());
        }
    }

    public void testNumericAndAlphaCharactersConvertToDoubleThrowsException(){
        try {
                DataTypeValidationUtil.getDoubleValue("23.Pls");
                fail("Exception Not thrown.");
        } catch (InvalidFormatException e) {
            assertTrue(true);
            assertEquals("Cannot Format String into Double", e.getMessage());
        }
    }

    public void testAlphaCharactersConvertTodoubleThrowsException() {
        try {
                DataTypeValidationUtil.getdoubleValue("Hello");
                fail("Should have throw an Exception");
        } catch (InvalidFormatException e) {
            assertTrue(true);
            assertEquals("Cannot Format String into Double", e.getMessage());
        }
    }

    public void testNumericAndAlphaCharactersConvertTodoubleThrowsException(){
        try {
                DataTypeValidationUtil.getdoubleValue("23.Pls");
                fail("Should have throw an Exception");
        } catch (InvalidFormatException e) {
            assertTrue(true);
            assertEquals("Cannot Format String into Double", e.getMessage());
        }
    }

}
