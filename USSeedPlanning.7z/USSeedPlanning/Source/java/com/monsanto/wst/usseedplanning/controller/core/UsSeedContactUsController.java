/*
 UsSeedContactUsController was created on Aug 29, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.usseedplanning.controller.core;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.ServletFramework.UseCaseController;
import com.monsanto.wst.usseedplanning.view.factory.ViewFactory;
import com.monsanto.wst.view.View;

import java.io.IOException;

/**
 * Filename:    $RCSfile: UsSeedContactUsController.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: jdpoul $    	 On:	$Date: 2006-09-07 21:38:43 $
 *
 * @author ffbrac
 * @version $Revision: 1.2 $
 */
public class UsSeedContactUsController implements UseCaseController {
	private ViewFactory viewFactory;

	public UsSeedContactUsController(ViewFactory viewFactory) {
	    this.viewFactory = viewFactory;
	}

	public void run(UCCHelper helper) throws IOException {
		View view;
	    view = this.viewFactory.getContactUsView();
	    view.renderView(helper);
	}
}