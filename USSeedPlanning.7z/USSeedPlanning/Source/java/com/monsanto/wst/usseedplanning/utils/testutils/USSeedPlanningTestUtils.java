package com.monsanto.wst.usseedplanning.utils.testutils;

import com.monsanto.wst.commonutils.reflection.ObjectInspector;
import com.monsanto.wst.dbtemplate.transaction.TransactionTestUtils;
import com.monsanto.wst.dbtemplate.factory.AbstractTransactionManagerFactory;
import com.monsanto.wst.dbtemplate.transaction.TransactionManager;
import com.monsanto.wst.factory.AbstractGenericFactory;
import com.monsanto.wst.factory.GenericFactory;
import com.monsanto.wst.factory.BeanInitializationException;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.AbstractLogging.DebugLogEvent;

import java.io.FileNotFoundException;
import java.sql.Connection;

/**
 * Created by IntelliJ IDEA.
 * Date: Sep 6, 2006
 * Time: 7:09:07 AM
 * <p/>
 * This class represents utility methods for helping in the testing of objects within the US Seed Planning project.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class USSeedPlanningTestUtils extends TransactionTestUtils {
    /**
     * This constructor takes all dependencies.
     *
     * @param objectInspector ObjectInspector object for inspecting objects.
     */
    public USSeedPlanningTestUtils(ObjectInspector objectInspector) {
        super(objectInspector);
    }

    /**
     * This method sets up the application container for integration/acceptance tests that use the container.
     */
    public void setupContainer() throws ClassNotFoundException {
        AbstractGenericFactory.clear();
        AbstractGenericFactory.setImplementation("com.monsanto.wst.factory.DelegatingLocatorGenericFactory");
        AbstractGenericFactory.addCustomFactory("com.monsanto.wst.usseedplanning.container.test.mock.MockDaoFactory");
        AbstractGenericFactory.addCustomFactory("com.monsanto.wst.usseedplanning.container.ServiceFactory");
        AbstractGenericFactory.addCustomFactory("com.monsanto.wst.usseedplanning.container.ValidatorFactory");
        AbstractGenericFactory.addCustomFactory("com.monsanto.wst.usseedplanning.container.ControllerFactory");
        AbstractGenericFactory.addCustomFactory("com.monsanto.wst.usseedplanning.view.factory.ViewFactoryImpl");
    }

    public TransactionManager setupTransactionManager(Connection connection) throws WrappingException {
        GenericFactory container = AbstractGenericFactory.getInstance();
        TransactionManager txManager = super.setupTransactionManager(connection);    //To change body of overridden methods use File | Settings | File Templates.
        container.addBean("transactionManager", txManager, true);
        return txManager;
    }

    public void rollbackTransaction() {
        try {
            GenericFactory container = AbstractGenericFactory.getInstance();
            TransactionManager txManager = (TransactionManager) container.getBean("transactionManager");
            rollbackTransaction(txManager);
        } catch (BeanInitializationException e) {
            if (Logger.isEnabled(Logger.DEBUG_LOG)) {
                Logger.log(new DebugLogEvent("The transaction manager was never setup."));
            }
        } catch (IllegalArgumentException e) {
            if (Logger.isEnabled(Logger.DEBUG_LOG)) {
                Logger.log(new DebugLogEvent("The application container was never setup."));
            }
        }
    }

    /**
     * This method sets up a transaction manager used with dbtemplate.
     *
     * @throws FileNotFoundException - If unable to find the data source config file.
     */
    public void setupTransactionManager() throws FileNotFoundException {
        GenericFactory container = AbstractGenericFactory.getInstance();
        String config = (String) container.getBean("dataSourceConfigFile");
        AbstractTransactionManagerFactory txManagerFactory = AbstractTransactionManagerFactory.newInstance(config);
        TransactionManager txManager = txManagerFactory.getTransactionManager();
        container.addBean("transactionManager", txManager, true);
    }

    /**
     * This method tears down the container, clearing it and removing the system property.
     */
    public void tearDownContainer() {
        AbstractGenericFactory.clear();
    }
}
