package com.monsanto.wst.usseedplanning.container;

import com.monsanto.wst.factory.ApplicationContainerAware;
import com.monsanto.wst.factory.GenericFactory;
import com.monsanto.wst.usseedplanning.services.core.*;
import com.monsanto.wst.usseedplanning.services.core.xml.XMLLog4jLogReaderService;
import com.monsanto.wst.usseedplanning.services.core.jxlstemplate.JXLSExportSpreadsheetService;
import com.monsanto.wst.usseedplanning.services.core.filetemplate.FileTemplateImportSpreadsheetService;
import com.monsanto.wst.usseedplanning.services.maintenance.CommonUploadService;
import com.monsanto.wst.usseedplanning.services.maintenance.CommonUploadServiceImpl;
import com.monsanto.wst.usseedplanning.services.maintenance.supply.SupplyService;
import com.monsanto.wst.usseedplanning.services.maintenance.supply.SupplyServiceImpl;
import com.monsanto.wst.usseedplanning.services.maintenance.supply.UpdateSupplyServiceFactory;
import com.monsanto.wst.usseedplanning.services.maintenance.supply.UpdateSupplyServiceFactoryImpl;
import com.monsanto.wst.usseedplanning.services.maintenance.forecast.ForecastService;
import com.monsanto.wst.usseedplanning.services.maintenance.forecast.ForecastServiceImpl;
import com.monsanto.wst.usseedplanning.services.maintenance.seedEntity.*;
import com.monsanto.wst.usseedplanning.services.maintenance.seedEntity.dbServices.*;
import com.monsanto.wst.usseedplanning.services.reports.DashboardReportService;
import com.monsanto.wst.usseedplanning.services.reports.DashboardReportServiceImpl;
import com.monsanto.wst.usseedplanning.services.planning.*;
import com.monsanto.wst.usseedplanning.services.cache.ProductLookupService;
import com.monsanto.wst.usseedplanning.services.cache.ProductLookupServiceImpl;
import com.monsanto.wst.usseedplanning.services.cache.ProductCachingServiceImpl;
import com.monsanto.wst.usseedplanning.services.cache.ProductCachingService;
import com.monsanto.wst.usseedplanning.services.cache.lexiconclientservices.*;
import com.monsanto.wst.usseedplanning.services.cache.mock.MockProductLookupService;
import com.monsanto.wst.usseedplanning.services.batchupdate.*;
import com.monsanto.wst.usseedplanning.model.mail.FileMessageTemplateFactory;
import com.monsanto.wst.usseedplanning.reports.DashboardReport;
import com.monsanto.wst.usseedplanning.container.test.MockBatchServiceImpl;
import com.monsanto.wst.usseedplanning.dao.*;
import com.monsanto.wst.filetemplate.FileTemplate;
import com.monsanto.wst.filetemplate.ExternalConfigFileTemplate;
import com.monsanto.wst.commonutils.resources.ResourceUtils;
import com.monsanto.wst.commonutils.xml.XMLUtilities;
import com.monsanto.wst.emailtemplate.services.MonsantoEmailService;
import com.monsanto.wst.emailtemplate.facade.MessageTemplateFactory;
import com.monsanto.wst.reportingframework.core.AbstractReport;
import com.monsanto.wst.dbtemplate.DBTemplate;
import com.monsanto.POSClient.POSConnection;
import com.monsanto.POSClient.SecureXMLPOSConnection;
import com.monsanto.securityinterfaces.SystemSecurityProxy;
import com.monsanto.securityinterfaces.ClientSecurityProxy;
import com.monsanto.KerberosPOSSecurity.KerberosSPNEGOClient;
import com.monsanto.KerberosPOSSecurity.GSSManagerFactory;
import com.monsanto.KerberosPOSSecurity.OSBasedGSSManagerFactory;
import com.monsanto.KerberosPOSSecurity.KerberosStandaloneCredential;
import org.ietf.jgss.GSSException;

import java.io.FileNotFoundException;

/**
 * Created by IntelliJ IDEA.
 * Date: Feb 11, 2007
 * Time: 6:29:45 PM
 * <p/>
 * TODO: Enter description for class.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class ServiceFactory implements ApplicationContainerAware {
    private GenericFactory container;
    private XMLUtilities xmlUtils = new XMLUtilities(new ResourceUtils());

    /**
     * This method returns the current implementation of the import spreadsheet service.
     *
     * @return ImportSpreadsheetService - Object representing the spreadsheet service.
     */
    public ImportSpreadsheetService getImportSpreadsheetService() {
        return new FileTemplateImportSpreadsheetService(getFileTemplate());
    }

    /**
     * This method returns the current implementation of file template.
     *
     * @return FileTemplate - Object representing the file template.
     */
    public FileTemplate getFileTemplate() {
        return new ExternalConfigFileTemplate("filetemplate/fileTemplate.xml");
    }

    public LookupService getLookupService() {
        return new LookupServiceImpl((LookupDao) container.getBean("lookupDao"));
    }

    public CommonUploadService getCommonUploadService() {
        return new CommonUploadServiceImpl(getImportSpreadsheetService(),
                (CommonUploadDao) container.getBean("commonUploadDao"), (RevisionDao) container.getBean("revisionDao"));
    }

    public DashboardReportService getDashboardReportService() {
        return new DashboardReportServiceImpl((DashboardReportDao) container.getBean("dashboardReportDao"));
    }

    public FactorService getFactorService() {
        return new FactorServiceImpl((FactorDao) container.getBean("factorDao"));
    }

    /**
     * This method returns the current implementation of the Stage Service object
     *
     * @return StageService - object representing the Stage service
     */
    public StageService getStageService() {
        return new StageServiceImpl((StageDao) container.getBean("stageDao"));
    }

    /**
     * This method returns the current implementation of the Stage Factor ervice object
     *
     * @return StageService - object representing the Stage Factor service
     */
    public StageFactorService getStageFactorService() {
        return new StageFactorServiceImpl((StageFactorDao) container.getBean("stageFactorDao"),
                (RevisionDao) container.getBean("revisionDao"));
    }

    /**
     * This method returns the current implementation of the forecast service object.
     *
     * @return ForecastService - Object representing the forecast service.
     */
    public ForecastService getForecastService() throws GSSException {
        return new ForecastServiceImpl(getImportSpreadsheetService(), (DemandDao) container.getBean("demandDao"),
                (ChannelDao) container.getBean("channelDao"), (RevisionDao) container.getBean("revisionDao"),
                (YearDao) container.getBean("yearDao"));
    }

    public GenderService getGenderService() {
        return new GenderDbServiceImpl((GenderDao) container.getBean("genderDao"));
    }

    public YearService getYearService() {
        return new YearServiceDbImpl((YearDao) container.getBean("yearDao"));
    }

    public QaThresholdTypeService getQaThresholdTypeService() {
        return new QaThresholdTypeDbServiceImpl((QaThresholdTypeDao) container.getBean("qaThresholdTypeDao"));
    }

    public LoginService getLoginService() {
        return new LoginServiceImpl((LoginDAO) container.getBean("loginDao"));
    }

    public UserRoleService getUserRoleService() {
        return new UserRoleServiceImpl((UserRoleDao) container.getBean("userRoleDao"));
    }

    /**
     * This method returns the mock implementation of the product lookup service object.
     *
     * @return ProductLookupService - Object representing the product lookup service.
     */
    public ProductLookupService getMockProductLookupService() throws GSSException {
        return new MockProductLookupService();
    }

    /**
     * This method returns the current implementation of the product lookup service object.
     *
     * @return ProductLookupService - Object representing the product lookup service.
     */
    public ProductLookupService getProductLookupService() throws GSSException {
        return new ProductLookupServiceImpl(getProductService(), (CommonUploadDao) container.getBean("commonUploadDao"));
    }

    /**
     * This method returns the current implementation of the supply service.
     *
     * @return SupplyService - Object used to retrieve and modifying supply information.
     */
    public SupplyService getSupplyService() {
        return new SupplyServiceImpl((SupplyDao) container.getBean("supplyDao"),
                (YearDao) container.getBean("yearDao"), getUpdateSupplyServiceFactory());
    }

    private UpdateSupplyServiceFactory getUpdateSupplyServiceFactory() {
        return new UpdateSupplyServiceFactoryImpl(getImportSpreadsheetService(),
                (SupplyDao) container.getBean("supplyDao"), (SupplyTypeDao) container.getBean("supplyTypeDao"),
                (RevisionDao) container.getBean("revisionDao"), (ChannelDao) container.getBean("channelDao"),
                (UomConversionDao) container.getBean("uomConversionDao"), (YearDao) container.getBean("yearDao"));
    }

    public QaThresholdService getQaThresholdService() {
        return new QaThresholdDbServiceImpl((QaThresholdDao) container.getBean("qaThresholdDao"));
    }

    /**
     * This method returns the current implementation of the pos connection object.
     *
     * @return POSConnection - Object representing the pos connection.
     */
    public POSConnection getPOSConnection() {
        SystemSecurityProxy proxy = (SystemSecurityProxy) container.getBean("systemSecurityProxy");
        return new SecureXMLPOSConnection(getClientSecurityProxy(), proxy);
    }

    /**
     * This method returns the current implementation of the client security proxy.
     *
     * @return ClientSecurityProxy - Object representing the client security proxy.
     */
    public ClientSecurityProxy getClientSecurityProxy() {
        return new KerberosSPNEGOClient(getGSSManagerFactory());
    }

    /**
     * This method returns the current implementation of the gss manager factory object.
     *
     * @return GSSManagerFactory - Object representing the gss manager factory.
     */
    public GSSManagerFactory getGSSManagerFactory() {
        return new OSBasedGSSManagerFactory();
    }

    /**
     * This method returns the current implementation of the system security proxy object.
     *
     * @return SystemSecurityProxy - Object representing the system security proxy.
     * @throws GSSException - If unable to create proxy.
     */
    public SystemSecurityProxy getSystemSecurityProxy() throws GSSException {
        return new KerberosStandaloneCredential();
    }

    public QaThresholdComparisonStrategyService getQaThresholdComparisonStrategyService() {
        return new QaThresholdComparisonStrategyDbServiceImpl(
                (QaThresholdComparisonStrategyDao) container.getBean("qaThresholdComparisonStrategyDao"));
    }

    public YieldTargetService getYieldTargetService() {
        return new YieldTargetDbServiceImpl((YieldTargetDao) container.getBean("yieldTargetDao"),
                (RevisionDao) container.getBean("revisionDao"));
    }

    /**
     * This method returns the current implementation of the export spreadsheet service.
     *
     * @return ExportSpreadsheetService - Object representing the export spreadsheet service.
     * @throws java.io.FileNotFoundException - If unable to find the template.
     */
    public ExportSpreadsheetService getExportSpreadsheetService() throws FileNotFoundException {
        return new JXLSExportSpreadsheetService(new ResourceUtils(), getPlanTemplate());
    }

    /**
     * This method returns the plan template path.
     *
     * @return String - Repesenting the plan template path.
     */
    public String getPlanTemplate() {
        return "template/xls/planTemplate.xls";
    }

    /**
     * This method returns the current implementation of the plan service.
     *
     * @return PlanService - Object representing the plan service.
     * @throws FileNotFoundException - If unable to find the plan template.
     * @throws GSSException          - If unable to create a POS connection.
     */
    public PlanService getPlanService() throws FileNotFoundException, GSSException {
        return new PlanServiceImpl((PlanDao) container.getBean("planDao"),
                (RevisionDao) container.getBean("revisionDao"), getProductLookupService(),
                (YearDao) container.getBean("yearDao"),
                getExportSpreadsheetService(), (ProductDetailsDao) container.getBean("productDetailsDao"),
                getImportSpreadsheetService(),
                (DemandDao) container.getBean("demandDao"), getEmailService(), getLoginService(),
                (ChannelDao) container.getBean("channelDao"),
                (PlanTypeDao) container.getBean("planTypeDao"), new ProductCachingServiceImpl((ProductDetailsDao) container.getBean("productDetailsDao"), getProductLookupService(), (RevisionDao) container.getBean("revisionDao")));
    }

    public MonsantoEmailService getEmailService() {
        return new MonsantoEmailService(getEmailTemplateFactory());
    }

    public MessageTemplateFactory getEmailTemplateFactory() {
        return new FileMessageTemplateFactory();
    }

    public LogReaderService getLogReaderService() {
        return new XMLLog4jLogReaderService("log4j.xml", xmlUtils);
    }

    public ProductServiceResponseParser getLexiconServiceResponseParser() {
        return new LexiconServiceResponseStAXParserImpl();
    }

    public ProductServiceRequestGenerator getLexiconServiceRequestGenerator() {
        return new LexiconServiceRequestGeneratorDOMImpl();
    }

    public ProductService getProductService() throws GSSException {
        return new LexiconProductServiceImpl(getPOSConnection(), getLexiconServiceRequestGenerator(),
                getLexiconServiceResponseParser());
    }

    public LatestRevisionService getLatestRevisionService() {
        return new LatestRevisionServiceImpl((RevisionDao) container.getBean("revisionDao"));
    }

    public AbstractReport getDashboardReport() {
        return new DashboardReport((DBTemplate) container.getBean("dbTemplate"));
    }

    public BatchService getBatchService() throws GSSException, FileNotFoundException {
        return new BatchServiceImpl(null, getProductLookupService(), (BatchDao) container.getBean("batchDao"),
                (PlanDao) container.getBean("planDao"), getCacheUpdaterImpl(),
                getEmailService(), getNewProductsService());
    }

    public BatchService getMockBatchService() throws GSSException, FileNotFoundException {
        return new MockBatchServiceImpl(null, getPlanService(), getProductLookupService(),
                (BatchDao) container.getBean("batchDao"),
                (ProductDetailsDao) container.getBean("productDetailsDao"),
                (PlanDao) container.getBean("planDao"), getCacheUpdaterImpl());
    }

    public CacheUpdater getCacheUpdaterImpl() throws GSSException, FileNotFoundException {
        return new CacheUpdaterImpl((ProductDetailsDao) container.getBean("productDetailsDao"), getProductCachingService(),
                null, null);
    }

    public ProductCachingService getProductCachingService() throws GSSException {
        return new ProductCachingServiceImpl(
                (ProductDetailsDao) container.getBean("productDetailsDao"), getProductLookupService(),
                (RevisionDao) container.getBean("revisionDao"));
    }

    public NewProductService getNewProductsService() {
        return new NewProductServiceImpl((BatchDao) container.getBean("batchDao"));
    }

    public PlanService getPlanQueueService() {
        return new PlanQueueService();
    }

    public void setApplicationContainer(GenericFactory container) {
        this.container = container;
    }
}
