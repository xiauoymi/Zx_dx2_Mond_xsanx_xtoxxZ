/*
 UserRoleService was created on Aug 22, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.usseedplanning.services.core;

import java.util.List;

/**
 * Filename:    $RCSfile: UserRoleService.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ffbrac $    	 On:	$Date: 2006-08-22 21:50:42 $
 *
 * @author ffbrac
 * @version $Revision: 1.1 $
 */
public interface UserRoleService {
	public List getUserRoleList(String userId);
}