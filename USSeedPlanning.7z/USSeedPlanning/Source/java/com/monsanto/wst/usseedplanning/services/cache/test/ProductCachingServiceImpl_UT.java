package com.monsanto.wst.usseedplanning.services.cache.test;

import com.monsanto.wst.usseedplanning.utils.testutils.USSeedPlanningBaseTestCase;
import com.monsanto.wst.usseedplanning.services.cache.ProductCachingServiceImpl;
import com.monsanto.wst.usseedplanning.services.cache.ProductLookupService;
import com.monsanto.wst.usseedplanning.services.cache.mock.MockProductLookupService;
import com.monsanto.wst.usseedplanning.dao.ProductDetailsDao;
import com.monsanto.wst.usseedplanning.dao.RevisionDao;
import com.monsanto.wst.usseedplanning.dao.mock.MockRevisionDao;
import com.monsanto.wst.usseedplanning.dao.mock.MockProductDetailsDao;
import com.monsanto.wst.usseedplanning.model.cache.ProductCriteria;
import com.monsanto.wst.usseedplanning.model.maintenance.NameType;
import com.monsanto.wst.usseedplanning.model.core.LoginUser;

import java.util.List;
import java.util.ArrayList;

/**
 * Created by IntelliJ IDEA.
 * Date: Feb 23, 2007
 * Time: 2:25:24 PM
 * <p/>
 * TODO: Enter description for class.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class ProductCachingServiceImpl_UT extends USSeedPlanningBaseTestCase {
    public void testCreate() throws Exception {
        ProductCachingServiceImpl service = new ProductCachingServiceImpl((ProductDetailsDao) null,
                (ProductLookupService) null, (RevisionDao) null);
        assertNotNull(service);
    }

    public void testCacheSelectedProducts() throws Exception {
        MockProductLookupService productLookupService = new MockProductLookupService();
        MockRevisionDao revisionDao = new MockRevisionDao();
        MockProductDetailsDao productDetailsDao = new MockProductDetailsDao();
        ProductCachingServiceImpl service = new ProductCachingServiceImpl(productDetailsDao, productLookupService, revisionDao);
        List criteriaList = new ArrayList();
        criteriaList.add(new ProductCriteria("testName", new NameType(NameType.COMMERCIAL), "testName"));
        service.cacheSelectedProducts(criteriaList, new LoginUser("Tester"));
        assertEquals(3, productDetailsDao.getProductDetailList().size());
    }

    // TODO: Need to add in the rest of the tests from PlanServiceImpl_UT.
}
