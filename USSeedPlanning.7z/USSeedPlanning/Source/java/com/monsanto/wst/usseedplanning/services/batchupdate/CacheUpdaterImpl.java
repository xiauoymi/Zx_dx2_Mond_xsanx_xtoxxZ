package com.monsanto.wst.usseedplanning.services.batchupdate;

import com.monsanto.wst.usseedplanning.dao.ProductDetailsDao;
import com.monsanto.wst.usseedplanning.model.cache.ProductAlias;
import com.monsanto.wst.usseedplanning.model.cache.ProductDetails;
import com.monsanto.wst.usseedplanning.model.core.BatchSummary;
import com.monsanto.wst.usseedplanning.model.core.LoginUser;
import com.monsanto.wst.usseedplanning.services.cache.ProductCachingService;
import org.apache.commons.lang.StringUtils;

import java.util.Iterator;
import java.util.List;
/*
CacheUpdater was created on Nov 22, 2006 using Monsanto
resources and is the sole property of Monsanto.
Any duplication of the code and/or logic is a
direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, TCC, Monsanto
 */
public class CacheUpdaterImpl implements CacheUpdater {
    private ProductDetailsDao productDetailsDao;
    private ProductCachingService productCachingService;
    private LoginUser currentUser;
    private BatchSummary batchSummary;

    public void setBatchSummary(BatchSummary batchSummary) {
        this.batchSummary = batchSummary;
    }

    public LoginUser getCurrentUser() {
        return currentUser;
    }

    public void setCurrentUser(LoginUser currentUser) {
        this.currentUser = currentUser;
    }

    public void removeProduct(List listOfProducts) {
    }

    public CacheUpdaterImpl(ProductDetailsDao productDetailsDao, ProductCachingService productCachingService,
                            LoginUser currentUser, BatchSummary batchSummary) {
        this.productDetailsDao = productDetailsDao;
        this.productCachingService = productCachingService;
        this.currentUser = currentUser;
        this.batchSummary = batchSummary;
    }

    public void lookUpNewModifiedDeletedProducts(List listOfProductDetails) {
        //TODO Not sure why the list is passed around here delete it
        List listOfModifiedOrNewProductDetails = productDetailsDao.determineNewOrModifiedProducts(listOfProductDetails);
        List listOfDeletedProductDetails = productDetailsDao.determineDeletedProducts();
        batchSummary.setNumberOfAddedOrModifiedProducts(listOfModifiedOrNewProductDetails.size());
        batchSummary.setNumberOfDeletedProducts(listOfDeletedProductDetails.size());
        listOfModifiedOrNewProductDetails.addAll(listOfDeletedProductDetails);
        CacheUtil cacheUtil = new CacheUtil();
        List uniquePCMNProductDetailList = cacheUtil.removeDuplicatePreCommercialRecordsInProductDetailsList(listOfModifiedOrNewProductDetails);
        List listToBeInsertedIntoProductDetails = productDetailsDao.lookupProductDetailsFromTemp(uniquePCMNProductDetailList);
        negatePreviousProductsInCommercialForNewProductsInserted(listToBeInsertedIntoProductDetails);
        insert(listToBeInsertedIntoProductDetails);
    }

    public void insert(List listOfUpdatedProductDetails) {
        productCachingService.cacheProductDetailsList(currentUser,listOfUpdatedProductDetails);
    }

    public BatchSummary getBatchSummary() {
        return batchSummary;
    }

    public void negatePreviousProductsInCommercialForNewProductsInserted(List arrayList) {
        Iterator iterator = arrayList.iterator();
        while(iterator.hasNext()){
            ProductDetails productDetails = (ProductDetails) iterator.next();
            Iterator productDetailsIterator=productDetails.getProductAliasList().iterator();
            while(productDetailsIterator.hasNext()){
                String commercialName = ((ProductAlias)productDetailsIterator.next()).getCommercialName();
                if(StringUtils.isNotEmpty(commercialName)){
                    productDetailsDao.updateProductDetailsDao(commercialName);
                }
            }
        }
    }
}
