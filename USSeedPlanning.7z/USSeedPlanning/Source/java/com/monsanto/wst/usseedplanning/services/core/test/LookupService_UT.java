/*
 LookupService_UT was created on Oct 24, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.usseedplanning.services.core.test;

import com.monsanto.wst.commonutils.testutils.TestUtils;
import com.monsanto.wst.usseedplanning.constants.MainConstants;
import com.monsanto.wst.usseedplanning.dao.mock.MockLookupDao;
import com.monsanto.wst.usseedplanning.dao.mock.MockLookupDaoNoResults;
import com.monsanto.wst.usseedplanning.dao.LookupDao;
import com.monsanto.wst.usseedplanning.services.core.LookupService;
import com.monsanto.wst.usseedplanning.services.core.LookupServiceImpl;
import com.monsanto.wst.usseedplanning.model.planning.Plan;
import junit.framework.TestCase;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

/**
 * Filename:    $RCSfile: LookupService_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ffbrac $    	 On:	$Date: 2006-10-31 20:53:46 $
 *
 * @author ffbrac
 * @version $Revision: 1.3 $
 */
public class LookupService_UT extends TestCase {
	public void setUp() throws Exception {
	    TestUtils testUtils = new TestUtils();
	    testUtils.setupLogging(MainConstants.APPLICATION_NAME);
	    super.setUp();
	}
	public void testLastRevisionDate(){
		LookupDao lookupDao = new MockLookupDao();
		LookupService service = new LookupServiceImpl(lookupDao);
		Date date = service.lookupLastRevisionDate();
		SimpleDateFormat formater = new SimpleDateFormat("yyyy");
		assertEquals("1969", formater.format(date));
	}
	public void testLookupReleaseTrackingValue(){
		LookupDao lookupDao = new MockLookupDao();
		LookupService service = new LookupServiceImpl(lookupDao);
		String value = service.lookupReleaseTrackingValue();
		assertEquals("1.0", value);
	}
	public void testLookupPlanRevisionList(){
		LookupDao lookupDao = new MockLookupDao();
		LookupService service = new LookupServiceImpl(lookupDao);
		List list = service.lookupPlanRevisionList();
		assertNotNull(list);
	}
	public void testLastRevisionDateWithError(){
		LookupDao lookupDao = new MockLookupDaoNoResults();
		LookupService service = new LookupServiceImpl(lookupDao);
		Date date = service.lookupLastRevisionDate();
		assertNull(date);
	}
	public void testLookupPlanListByPlanTypeName(){
		LookupDao lookupDao = new MockLookupDao();
		LookupService service = new LookupServiceImpl(lookupDao);
		List planList = service.lookupPlanListByPlanTypeName("test");
		assertNotNull(planList);
	}
	public void testLookupPlanByPlanId(){
		LookupDao lookupDao = new MockLookupDao();
		LookupService service = new LookupServiceImpl(lookupDao);
		Plan plan = service.lookupPlanByPlanId(new Long("100"));
		assertNotNull(plan);
	}
	public void testLookupPlanDetailsByPlanId(){
		LookupDao lookupDao = new MockLookupDao();
		LookupService service = new LookupServiceImpl(lookupDao);
		List planList = service.lookupPlanDetailsByPlanId(new Long("100"));
		assertNotNull(planList);
	}
}