/*
 JXLSTemplateSpreadsheetService_UT was created on Sep 19, 2006 using Monsanto
 resources and is the sole property of Monsanto.  Any duplication of the
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.usseedplanning.services.core.jxlstemplate.test;

import com.monsanto.wst.commonutils.resources.ResourceUtils;
import com.monsanto.wst.usseedplanning.model.planning.Plan;
import com.monsanto.wst.usseedplanning.model.planning.PlanType;
import com.monsanto.wst.usseedplanning.model.planning.test.PlanUT;
import com.monsanto.wst.usseedplanning.services.core.jxlstemplate.JXLSExportSpreadsheetService;
import junit.framework.TestCase;

import java.io.File;
import java.io.FileOutputStream;

/**
 * Filename:    $RCSfile: JXLSExportSpreadsheetService_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: njminsh $    	 On:	$Date: 2007-02-16 16:54:12 $
 *
 * @author ffbrac
 * @version $Revision: 1.17 $
 */
public class JXLSExportSpreadsheetService_UT extends TestCase {
    private String outputPath = "";
    private String template = "template/xls/planTemplate.xls";
    private File testFoundationPlanFile;
    private File testHybridPlanFile;

    protected void setUp() throws Exception {
        super.setUp();
        File directory = new ResourceUtils().convertPathToFile(this.outputPath);
        this.testFoundationPlanFile = new File(directory.getAbsolutePath() + "/testFoundationPlan.xls");
        this.testFoundationPlanFile.delete();
        this.testFoundationPlanFile.createNewFile();

        this.testHybridPlanFile = new File(directory.getAbsolutePath() + "/testHybridPlan.xls");
        this.testHybridPlanFile.delete();
        this.testHybridPlanFile.createNewFile();
    }

    public void testCreate() throws Exception {
        JXLSExportSpreadsheetService jxlsExportSpreadsheetService =
                new JXLSExportSpreadsheetService(new ResourceUtils(), this.template);
        assertNotNull(jxlsExportSpreadsheetService);
    }

    public void testCreateFoundationXLSTransformation() throws Exception {
        JXLSExportSpreadsheetService jxlsExportSpreadsheetService =
                new JXLSExportSpreadsheetService(new ResourceUtils(), this.template);
        Plan plan = PlanUT.createPlan();
        byte[] bytes =
            jxlsExportSpreadsheetService.getPlanSpreadsheet(plan);
        assertNotNull(bytes);
        assertTrue(bytes.length > 0);

        // Create Plan for visual testing
        FileOutputStream fileOut = new FileOutputStream(this.testFoundationPlanFile);
        fileOut.write(bytes);
    }

    public void testCreateHybridXLSTransformation() throws Exception {
        JXLSExportSpreadsheetService jxlsExportSpreadsheetService =
                new JXLSExportSpreadsheetService(new ResourceUtils(), this.template);
        Plan plan = PlanUT.createPlan();
        changePlanToHybrid(plan);
        byte[] bytes =
            jxlsExportSpreadsheetService.getPlanSpreadsheet(plan);
        assertNotNull(bytes);
        assertTrue(bytes.length > 0);

        // Create Plan for visual testing
        FileOutputStream fileOut = new FileOutputStream(this.testHybridPlanFile);
        fileOut.write(bytes);
    }

    private void changePlanToHybrid(Plan plan) {
        plan.getPlanType().setName(PlanType.HYBRID_PLAN_TYPE_NAME);
    }
}