/*
 ErrorHandler was created on Mar 9, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.usseedplanning.services.cache;

import com.monsanto.wst.usseedplanning.services.cache.lexiconclientservices.LexiconProductServiceException;

import java.io.IOException;

/**
 * Filename:    $RCSfile: ErrorHandler.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: vrbethi $    	 On:	$Date: 2007-03-12 15:29:19 $
 *
 * @author vrbethi
 * @version $Revision: 1.2 $
 */
public interface ErrorHandler {
    void notifyError(LexiconProductServiceException e) throws IOException;

    void saveAndClose() throws IOException;
}