/*
 LatestRevisionSerivceImpl was created on Nov 3, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.usseedplanning.services.core;

import com.monsanto.wst.usseedplanning.dao.RevisionDao;
import com.monsanto.wst.usseedplanning.model.maintenance.Revision;
import com.monsanto.wst.usseedplanning.exception.NoResultsException;

/**
 * Filename:    $RCSfile: LatestRevisionServiceImpl.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: vrbethi $    	 On:	$Date: 2006-11-04 18:30:33 $
 *
 * @author vrbethi
 * @version $Revision: 1.1 $
 */
public class LatestRevisionServiceImpl implements LatestRevisionService{
    private RevisionDao revisionDao;

    public LatestRevisionServiceImpl(RevisionDao revisionDao) {
        this.revisionDao = revisionDao;
    }

    public Revision getLatestRevision() {
        return revisionDao.lookupLatest();
    }
}