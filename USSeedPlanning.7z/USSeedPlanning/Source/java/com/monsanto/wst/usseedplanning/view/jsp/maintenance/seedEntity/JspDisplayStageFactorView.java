/*
 JspDisplayStageFactorView was created on Sep 18, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.usseedplanning.view.jsp.maintenance.seedEntity;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.wst.usseedplanning.constants.MainConstants;
import com.monsanto.wst.view.View;
import com.monsanto.wst.view.ViewRenderingException;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import java.io.IOException;

/**
 * Filename:    $RCSfile: JspDisplayStageFactorView.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: njminsh $    	 On:	$Date: 2007-02-13 19:21:06 $
 *
 * @author sspati1
 * @version $Revision: 1.5 $
 */
public class JspDisplayStageFactorView implements View{

	private static final Log log = LogFactory.getLog(JspStageFactorsView.class);

    public void renderView(UCCHelper helper) throws ViewRenderingException {
        try {
            helper.forward(MainConstants.CREATE_STAGE_FACTOR_JSP);
        } catch (IOException e) {
            if (log.isErrorEnabled()) {
                log.error("Unable to render stage factor view.", e);
            }
            throw new ViewRenderingException("Unable to render stage factor view.");
        }
    }
}