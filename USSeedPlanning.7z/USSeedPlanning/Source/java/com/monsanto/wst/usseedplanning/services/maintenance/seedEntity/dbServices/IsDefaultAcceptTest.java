/*
 Copyright:  Copyright � 2006 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.usseedplanning.services.maintenance.seedEntity.dbServices;

import com.monsanto.wst.commonutils.collection.AcceptTest;
import com.monsanto.wst.usseedplanning.model.maintenance.Default;

/**
 * Filename:    $RCSfile: IsDefaultAcceptTest.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: jdpoul $
 * On:	$Date: 2006-10-11 21:24:32 $
 *
 * @author jdpoul
 * @version $Revision: 1.2 $
 */
public class IsDefaultAcceptTest implements AcceptTest {
  public boolean accept(Object o) {
    if (o instanceof Default) {
      Default defaultInstance = (Default) o;
      return !defaultInstance.isDefault();
    }
    return false;
  }
}