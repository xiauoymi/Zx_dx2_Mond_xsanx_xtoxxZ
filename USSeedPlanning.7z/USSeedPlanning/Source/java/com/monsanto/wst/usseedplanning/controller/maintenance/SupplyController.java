package com.monsanto.wst.usseedplanning.controller.maintenance;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.wst.servletframework.AbstractDispatchController;
import com.monsanto.wst.usseedplanning.constants.MainConstants;
import com.monsanto.wst.usseedplanning.constants.ControllerConstants;
import com.monsanto.wst.usseedplanning.model.core.LoginUser;
import com.monsanto.wst.usseedplanning.model.maintenance.supply.SupplyType;
import com.monsanto.wst.usseedplanning.services.maintenance.supply.SupplyService;
import com.monsanto.wst.usseedplanning.view.factory.ViewFactory;
import com.monsanto.wst.usseedplanning.utils.transaction.TransactionUtils;
import com.monsanto.wst.validator.HttpRequestErrors;
import com.monsanto.wst.validator.HttpRequestMessages;
import com.monsanto.wst.validator.HttpValidator;
import com.monsanto.wst.view.View;

import java.io.File;
import java.io.IOException;

/**
 * Created by IntelliJ IDEA.
 * Date: Aug 16, 2006
 * Time: 6:08:41 PM
 * <p/>
 * This class is a controller for the supply related pages.  It is used to delegate to the appropriate services and views
 * and to do validation.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class SupplyController extends AbstractDispatchController {
    private SupplyService supplyService;
    private ViewFactory viewFactory;
    private HttpValidator updateSupplyValidator;

    /**
     * This constructor takes all dependencies.
     *
     * @param supplyService SupplyService object for retrieving and modifying supply information.
     * @param viewFactory ViewFactory object for creating views.
     * @param updateSupplyValidator HttpValidator object for validating the request.
     */
    public SupplyController(SupplyService supplyService, ViewFactory viewFactory, HttpValidator updateSupplyValidator) {
        this.supplyService = supplyService;
        this.viewFactory = viewFactory;
        this.updateSupplyValidator = updateSupplyValidator;
    }

    /**
     * This method is the default action for this controller.
     *
     * @param helper UCCHelper object containing the request and response.
     * @throws IOException - If unable to access the request or response.
     */
    protected void notSpecified(UCCHelper helper) throws IOException {
        View view = this.viewFactory.getUpdateSupplyView();
        view.renderView(helper);
    }

    /**
     * This method is called for ZDCA upload
     *
     * @param helper UCCHelper object containing the request and response.
     * @throws IOException - If unable to access the request or response.
     */
    public void uploadZDCA(UCCHelper helper) throws IOException {
        View view = this.viewFactory.getUpdateZDCASupplyView();
        view.renderView(helper);
    }

    /**
     * This method updates the current supply information and renders the appropriate view.
     *
     * @param helper UCCHelper object containing the request and response.
     * @throws IOException - If unable to access the request or response.
     */
    public void updateSupply(UCCHelper helper) throws IOException {
        String supplyType = helper.getRequestParameterValue("supplyType");
        String planType = helper.getRequestParameterValue("planType");
        HttpRequestErrors errors = this.updateSupplyValidator.validate(helper);
        View view = null;
        if (errors.isEmpty()) {
            LoginUser owner = (LoginUser) helper.getSessionParameter(MainConstants.LOGINUSER);
            String comments = helper.getRequestParameterValue("comments");
            File supplyFile = new File((String) helper.getClientFiles().get(0));
            try {
                this.supplyService.updateSupply(supplyFile, owner, supplyType, new Long(planType), comments);
                HttpRequestMessages messages = new HttpRequestMessages();
                messages.addMessage("Supply Update Successful");
                helper.setRequestAttributeValue(ControllerConstants.MESSAGES_REQUEST_ATTRIBUTE, messages);
                view = this.viewFactory.getUSSeedHomeView();
            } catch (IllegalStateException e) {
                errors.addError(HttpRequestErrors.GLOBAL_ERROR, e.getMessage());
                if(supplyType.equals(SupplyType.ATP_SUPPLY_TYPE)){
                    helper.setRequestAttributeValue(ControllerConstants.ERRORS_REQUEST_ATTRIBUTE, errors);
                    view = this.viewFactory.getUpdateSupplyView();
                }
                else if(supplyType.equals(SupplyType.ZDCA_SUPPLY_TYPE)){
                    helper.setRequestAttributeValue(ControllerConstants.ERRORS_REQUEST_ATTRIBUTE, errors);
                    view = this.viewFactory.getUpdateZDCASupplyView();
                }
                new TransactionUtils(helper).flagForRollback();
            }
        } else {
            if(supplyType.equals(SupplyType.ATP_SUPPLY_TYPE)){
                helper.setRequestAttributeValue(ControllerConstants.ERRORS_REQUEST_ATTRIBUTE, errors);
                view = this.viewFactory.getUpdateSupplyView();
            }
            else if(supplyType.equals(SupplyType.ZDCA_SUPPLY_TYPE)){
                helper.setRequestAttributeValue(ControllerConstants.ERRORS_REQUEST_ATTRIBUTE, errors);
                view = this.viewFactory.getUpdateZDCASupplyView();
            }
        }
        view.renderView(helper);
    }
}
