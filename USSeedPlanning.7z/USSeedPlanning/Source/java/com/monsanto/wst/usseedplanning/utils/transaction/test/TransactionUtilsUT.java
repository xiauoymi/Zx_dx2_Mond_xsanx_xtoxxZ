package com.monsanto.wst.usseedplanning.utils.transaction.test;

import junit.framework.TestCase;
import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.wst.usseedplanning.utils.transaction.TransactionUtils;
import com.monsanto.wst.dbtemplate.transaction.TransactionManager;
import com.monsanto.wst.dbtemplate.transaction.test.mock.MockTransactionManager;
import com.monsanto.wst.servletframework.DITransactionalController;

/**
 * Created by IntelliJ IDEA.
 * Date: Sep 12, 2006
 * Time: 12:08:57 PM
 * <p/>
 * Unit test for the TransactionUtils object.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class TransactionUtilsUT extends TestCase {
    public void testCreate() throws Exception {
        TransactionUtils txUtils = new TransactionUtils((UCCHelper) null);
        assertNotNull(txUtils);
    }

    public void testGetTransactionManager() throws Exception {
        MockTransactionManager txManager = new MockTransactionManager();
        MockUCCHelper helper = new MockUCCHelper(null);
        helper.setContextAttribute(DITransactionalController.TRANSACTION_MANAGER_CTX_ATTRIBUTE, txManager);
        TransactionUtils txUtils = new TransactionUtils(helper);
        TransactionManager returnedTxManager = txUtils.getTransactionManager();
        assertNotNull(returnedTxManager);
        assertEquals(txManager, returnedTxManager);
    }

    public void testFlagForRollback() throws Exception {
        MockUCCHelper helper = new MockUCCHelper(null);
        TransactionUtils txUtils = new TransactionUtils(helper);
        txUtils.flagForRollback();
        assertEquals(Boolean.TRUE, helper.getRequestAttributeValue(DITransactionalController.ROLLBACK__FLAG));
    }
}
