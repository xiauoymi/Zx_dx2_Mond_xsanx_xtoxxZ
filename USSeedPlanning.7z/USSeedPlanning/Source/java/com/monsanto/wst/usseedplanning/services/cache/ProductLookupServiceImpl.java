/*
ProductLookupServiceImpl was created on Aug 17, 2006 using Monsanto
resources and is the sole property of Monsanto.  Any duplication of the
code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.usseedplanning.services.cache;

import com.monsanto.wst.usseedplanning.dao.CommonUploadDao;
import com.monsanto.wst.usseedplanning.exception.NoResultsException;
import com.monsanto.wst.usseedplanning.model.cache.ProductCriteria;
import com.monsanto.wst.usseedplanning.model.cache.ProductDetails;
import com.monsanto.wst.usseedplanning.model.maintenance.CommonData;
import com.monsanto.wst.usseedplanning.model.maintenance.NameType;
import com.monsanto.wst.usseedplanning.services.cache.lexiconclientservices.ProductService;
import com.monsanto.wst.usseedplanning.services.cache.lexiconclientservices.LexiconProductServiceException;
import org.apache.commons.lang.StringUtils;

import java.util.ArrayList;
import java.util.List;
import java.io.IOException;

/**
 * Filename:    $RCSfile: ProductLookupServiceImpl.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: vrbethi $    	 On:	$Date: 2007-03-12 15:29:19 $
 *
 * @author sspati1
 * @version $Revision: 1.7 $
 */
public class ProductLookupServiceImpl implements ProductLookupService {
    private ProductService productService;
    private CommonUploadDao commonUploadDao;
    private static final String UNRESOLVED_STATUS = "X";
    private List errorHandlerList = new ArrayList();

    public ProductLookupServiceImpl(ProductService productService, CommonUploadDao commonUploadDao) {
        this.productService = productService;
        this.commonUploadDao = commonUploadDao;
    }

    /**
     * This method returns the manufacturing name for a commercial or precommercial name
     *
     * @param productCriteriaList List representing product criteria.
     * @return manufacturing name
     */
    public List lookupProductDetailByCriteria(List productCriteriaList) throws Exception {
        List productDetailsList = new ArrayList();
        if (productCriteriaList != null) {
            performProductLookup(productCriteriaList, productDetailsList);
        }
        return productDetailsList;
    }

    public List lookupProductDetailByCriteria(ProductCriteria productCriteria) throws Exception {
        List criteriaList = new ArrayList();
        criteriaList.add(productCriteria);
        return lookupProductDetailByCriteria(criteriaList);
    }

    public void registerErrorHandler(ErrorHandler errorHandler) {
        errorHandlerList.add(errorHandler);
    }

    private void performProductLookup(List productCriteriaList, List productDetailsList) throws Exception {
        processAllCommercialProductNames(productCriteriaList);
        processAllPreCommercialProductNames(productCriteriaList, productDetailsList);
        processAllManufacturingProductNames(productCriteriaList, productDetailsList);
    }

    /**
     * TODO: Does not function as expected.  Need to create product detail objects for each of the versions in the product aliases.
     *
     * @throws Exception
     * @param productCriteriaList
     * @param productDetailsList
     */
    private void processAllManufacturingProductNames(List productCriteriaList, List productDetailsList) throws Exception {
        for (int i = 0; i < productCriteriaList.size(); i++) {
            ProductCriteria  productCriteria = (ProductCriteria) productCriteriaList.get(i);
            if(productCriteria != null && productCriteria.getNameType() != null &&
                    NameType.MANUFACTURING.equalsIgnoreCase(productCriteria.getNameType().getNameType())) {
                String manufacturingName = productCriteria.getProductName();
                List detailsList = callServiceForManufacturingName(manufacturingName);
                if (detailsList!=null && detailsList.size() > 0) {
                    boolean skipMFGNameFlag = hasEqualPreCommercialAndManufacturingNames(detailsList, manufacturingName);
                    boolean hasPrimary = hasPrimaryPCMName(detailsList);
                    for (int j = 0; j < detailsList.size(); j++) {
                        ProductDetails productDetails = (ProductDetails) detailsList.get(j);
                        productDetails.setProvidedName(productCriteria.getCommonName());
                        productDetails.setOrigin(productCriteria.getOrigin());
                        productDetails.setChannelId(productCriteria.getChannelId());
                        productDetails.setManufacturingName(manufacturingName);
                        productDetails.setSkipManufacturingName(new Boolean(skipMFGNameFlag));
                        productDetails.setPrimaryFlag(new Boolean(hasPrimary));
                        if (productDetails.getParentDetailsList().isEmpty()) {
                            createDefaultParents(productDetails);
                        }
                        if (!productDetailsList.contains(productDetails)) {
                            productDetailsList.add(productDetails);
                        }
                    }
                    addVersionIfNecessary(productCriteria, detailsList, productDetailsList);
                } else if (!productCriteria.getFoundProducts().isEmpty()) {
                    addVersionIfNecessary(productCriteria, productCriteria.getFoundProducts(), productDetailsList);
                    for (int j = 0; j < productCriteria.getFoundProducts().size(); j++) {
                        if (!productDetailsList.contains(productCriteria.getFoundProducts().get(j))) {
                            productDetailsList.add(productCriteria.getFoundProducts().get(j));
                        }
                    }
                } else {
                    createUnresolvedRecord(productCriteria, productDetailsList);
                }
            }
        }
    }



    private void addVersionIfNecessary(ProductCriteria criteria, List detailsList, List finalList) throws Exception {
        boolean foundMatch = false;
        for (int i = 0; i < detailsList.size(); i++) {
            ProductDetails productDetails = (ProductDetails) detailsList.get(i);
            if ((criteria.getTraitVersion() != null && criteria.getTraitVersion().equals(productDetails.getVersion()))
                    || (criteria.getTraitVersion() == null && productDetails.getVersion() == null)
                    || !"SUPPLY".equals(criteria.getOrigin())) {
                foundMatch = true;
            }
        }
        if (!foundMatch) {
            createUnresolvedRecord(criteria, finalList);
        }
    }

    private void createUnresolvedRecord(ProductCriteria productCriteria, List productDetailsList) throws Exception {
        ProductDetails productDetails = new ProductDetails();
        productDetails.setProvidedName(productCriteria.getCommonName());
        productDetails.setPreCommercialName(productCriteria.getCommonName());
        productDetails.setOrigin(productCriteria.getOrigin());
        productDetails.setChannelId(productCriteria.getChannelId());
        productDetails.setProductionStatus(UNRESOLVED_STATUS);
        productDetails.setVersion(productCriteria.getTraitVersion());
        createDefaultParents(productDetails);
        if (!productDetailsList.contains(productDetails)) {
            productDetailsList.add(productDetails);
        }
    }

    private void createDefaultParents(ProductDetails productDetails) throws Exception {
        if (productDetails.isParent()) {
            createDefaultParentParents(productDetails);
        } else {
            createDefaultHybridFemaleParent(productDetails);
            createDefaultHybridMaleParent(productDetails);
        }
    }

    private void createDefaultParentParents(ProductDetails productDetails) throws Exception {
        ProductDetails femaleDetails = new ProductDetails();
        femaleDetails.setPreCommercialName(productDetails.getPreCommercialName());
        femaleDetails.setManufacturingName(productDetails.getManufacturingName());
        femaleDetails.setVersion(productDetails.getVersion());
        femaleDetails.setOverrideFlag(ProductDetails.ACTUAL_OVERRIDE_FLAG);
        productDetails.setFemaleParent(femaleDetails);
        if (productDetails.isSterile()) {
            setMaleToHCLBase(productDetails);
        } else {
            ProductDetails maleDetails = new ProductDetails();
            maleDetails.setOverrideFlag(ProductDetails.ACTUAL_OVERRIDE_FLAG);
            productDetails.setMaleParent(maleDetails);
        }
    }

    private void setMaleToHCLBase(ProductDetails productDetails) throws Exception {
        productDetails.setProductType(ProductDetails.PRODUCT_TYPE_STERILE);
        CommonData criteria = new CommonData();
        criteria.setName(productDetails.getPreCommercialName());
        criteria.setTableName("BASE_NAME");
        try {
            CommonData commonData = commonUploadDao.lookupLatestCommonDataByName(criteria);
            ProductCriteria productCriteria =
                    new ProductCriteria((String) commonData.getUnits(), new NameType(NameType.COMMERCIAL),
                            (String) commonData.getUnits());
            List productDetailsList = lookupProductDetailByCriteria(productCriteria);
            ProductDetails maleDetails = (ProductDetails) productDetailsList.get(0);
            maleDetails.setOverrideFlag(ProductDetails.ACTUAL_OVERRIDE_FLAG);
            productDetails.setMaleParent(maleDetails);
        } catch (NoResultsException e) {
            createDefaultHybridMaleParent(productDetails);
        }
    }

    private void createDefaultHybridFemaleParent(ProductDetails productDetails) {
        ProductDetails parentDetails = new ProductDetails();
        parentDetails.setPreCommercialName(new StringBuffer("_").append(productDetails.getPreCommercialName()).append("_F").toString());
        parentDetails.setOverrideFlag(ProductDetails.GENERATED_OVERRIDE_FLAG);
        productDetails.setFemaleParent(parentDetails);
    }

    private void createDefaultHybridMaleParent(ProductDetails productDetails) {
        ProductDetails parentDetails = new ProductDetails();
        parentDetails.setPreCommercialName(new StringBuffer("_").append(productDetails.getPreCommercialName()).append("_M").toString());
        parentDetails.setOverrideFlag(ProductDetails.GENERATED_OVERRIDE_FLAG);
        productDetails.setMaleParent(parentDetails);
    }

    private boolean hasEqualPreCommercialAndManufacturingNames(List detailsList, String manufacturingName) {
        for (int i = 0; i < detailsList.size(); i++) {
            ProductDetails productDetails = (ProductDetails) detailsList.get(i);
            if (productDetails.getPreCommercialName().equals(manufacturingName)) {
                return true;
            }
        }
        return false;
    }

    private boolean hasPrimaryPCMName(List detailsList) {
        for (int i = 0; i < detailsList.size(); i++) {
            ProductDetails productDetails = (ProductDetails) detailsList.get(i);
            if (ProductDetails.FORMATTED_PRODUCTION_STATUS_PRIMARY.equals(productDetails.getProductionStatus())) {
                return true;
            }
        }
        return false;
    }

    private void processAllPreCommercialProductNames(List productCriteriaList, List productDetailsList) throws Exception {
        for (int i = 0; i < productCriteriaList.size(); i++) {
            ProductCriteria  productCriteria = (ProductCriteria) productCriteriaList.get(i);
            if(productCriteria != null && productCriteria.getNameType() != null &&
                    NameType.PRECOMMERCIAL.equalsIgnoreCase(productCriteria.getNameType().getNameType())) {
                String preCommercialName = productCriteria.getProductName();
                List detailsList = callServiceForPreCommercialName(preCommercialName);
                if (detailsList!= null && detailsList.size() > 0) {
                    for (int j = 0; j < detailsList.size(); j++) {
                        ProductDetails productDetails = (ProductDetails) detailsList.get(j);
                        productDetails.setProvidedName(productCriteria.getCommonName());
                        productDetails.setOrigin(productCriteria.getOrigin());
                        productDetails.setChannelId(productCriteria.getChannelId());
                        String manufacturingName = productDetails.getManufacturingName();
                        if (productDetails.getParentDetailsList().isEmpty()) {
                            createDefaultParents(productDetails);
                        }
                        if(StringUtils.isNotEmpty(manufacturingName)){
                            productCriteria.setProductName(manufacturingName);
                            productCriteria.setNameType(new NameType(NameType.MANUFACTURING));
                        } else if (Boolean.TRUE.equals(productDetails.getDeleted())) {
                            productCriteria.setNameType(new NameType(NameType.MANUFACTURING));
                        } else if (!productDetailsList.contains(productDetails)) {
                            productCriteria.addFoundProduct(productDetails);
                            productCriteria.setNameType(new NameType(NameType.MANUFACTURING));
                        }
                    }
                } else {
                    productCriteria.setNameType(new NameType(NameType.MANUFACTURING));
                }
            }
        }
    }

    private void processAllCommercialProductNames(List productCriteriaList) throws Exception {
        for (int i = 0; i < productCriteriaList.size(); i++) {
            ProductCriteria  productCriteria = (ProductCriteria) productCriteriaList.get(i);
            if(productCriteria != null && productCriteria.getNameType() != null
                    && NameType.COMMERCIAL.equalsIgnoreCase(productCriteria.getNameType().getNameType())) {
                String commercialName = productCriteria.getProductName();
                String preCommercialName=callCommercialProductService(commercialName);
                if (StringUtils.isNotEmpty(preCommercialName)) {
                    productCriteria.setProductName(preCommercialName);
                }
                productCriteria.setNameType(new NameType(NameType.PRECOMMERCIAL));
            }
        }
    }

    private String callCommercialProductService(String commercialName) throws Exception {
        String preCommercialName=""; 
        try {
            preCommercialName = productService.getPreCommercialNameFromCommercialName(commercialName);
        } catch (LexiconProductServiceException e) {
            handleException(e);
        }
        return preCommercialName;
    }

    private List callServiceForPreCommercialName(String preCommercialName) throws Exception {
        List detailList = null;
        try {
            detailList = productService.getProductDetailsListByPreCommercialName(preCommercialName);
        } catch (LexiconProductServiceException e) {
            handleException(e);
        }
        return detailList;
    }

    private List callServiceForManufacturingName(String manufacturingName) throws Exception {
        List detailList=null;
        try {
            detailList = productService.getProductDetailsListByManufacturingName(manufacturingName);
        } catch (LexiconProductServiceException e) {
            handleException(e);
        }
        return detailList;
    }

    private void handleException(LexiconProductServiceException e) throws LexiconProductServiceException, IOException {
        if(errorHandlerList.size()==0){
                throw new LexiconProductServiceException(e.getMessage(),e);
        }else{
            ErrorHandler errorHandler = (ErrorHandler) errorHandlerList.get(0);
            errorHandler.notifyError(e);
        }
    }
}