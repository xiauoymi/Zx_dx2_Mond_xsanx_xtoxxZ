/*
 LexiconProductServiceImpl_UT was created on Mar 9, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.usseedplanning.services.cache.lexiconclientservices.test;

import junit.framework.TestCase;
import com.monsanto.wst.usseedplanning.services.cache.lexiconclientservices.*;
import com.monsanto.POSClient.test.MockPOSConnection;
import com.monsanto.POSClient.POSResult;
import com.monsanto.POSClient.POSException;
import com.monsanto.POSClient.POSCommunicationException;
import org.w3c.dom.Document;

import java.util.List;
import java.io.InputStream;

/**
 * Filename:    $RCSfile: LexiconProductServiceImpl_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: vrbethi $    	 On:	$Date: 2007-03-09 16:18:19 $
 *
 * @author vrbethi
 * @version $Revision: 1.1 $
 */
public class LexiconProductServiceImpl_UT extends TestCase {

  public void testGetPreCommercialNameFromCommercialName_CallServiceThrowsLexiconProductServiceException() throws
      Exception {
    try {
      ProductServiceRequestGenerator generator = new MockProductServiceRequestGenerator();
      MockPOSConnection mockPOSConnection = new MockPOSConnection_ThrowsException("ram","ram");
      ProductServiceResponseParser productServiceResponseParser = new MockProductServiceResponseParser();
      ProductService lexiconProductService = new LexiconProductServiceImpl(mockPOSConnection,generator,productServiceResponseParser);
      lexiconProductService
          .getPreCommercialNameFromCommercialName("DKC50-50");
      fail("Lexicon Product Service Exception should have been thrown");
    } catch (LexiconProductServiceException e) {
      assertEquals("Exception encountered connecting to Lex_GetAggregateProduct for :DKC50-50",e.getMessage());
    }
  }

  public void testGetProductDetailsListByPreCommercialName_CallServiceThrowsLexiconProductServiceException() throws
      Exception {
    try {
      ProductServiceRequestGenerator generator = new MockProductServiceRequestGenerator();
      MockPOSConnection mockPOSConnection = new MockPOSConnection_ThrowsException("ram","ram");
      ProductServiceResponseParser productServiceResponseParser = new MockProductServiceResponseParser();
      ProductService lexiconProductService = new LexiconProductServiceImpl(mockPOSConnection,generator,productServiceResponseParser);
      lexiconProductService
          .getProductDetailsListByPreCommercialName("DKC50-50");
      fail("Lexicon Product Service Exception should have been thrown");
    } catch (LexiconProductServiceException e) {
      assertEquals("Exception encountered connecting to Lex_ProductParentsByPreComlName for :DKC50-50",e.getMessage());
    }
  }

  public void testProductDetailsListByManufacturingName_CallServiceThrowsLexiconProductServiceException() throws
      Exception {
    try {
      ProductServiceRequestGenerator generator = new MockProductServiceRequestGenerator();
      MockPOSConnection mockPOSConnection = new MockPOSConnection_ThrowsException("ram","ram");
      ProductServiceResponseParser productServiceResponseParser = new MockProductServiceResponseParser();
      ProductService lexiconProductService = new LexiconProductServiceImpl(mockPOSConnection,generator,productServiceResponseParser);
      lexiconProductService
          .getProductDetailsListByManufacturingName("DKC50-50");
      fail("Lexicon Product Service Exception should have been thrown");
    } catch (LexiconProductServiceException e) {
      assertEquals("Exception encountered connecting to Lex_ProductParentsByManfName for :DKC50-50",e.getMessage());
    }
  }

  class MockProductServiceRequestGenerator implements ProductServiceRequestGenerator{

    public Document getRequestDocumentForProductParentsByPrecommercialNameService(String preCommercialName) throws
    Exception {
      return null;
    }

    public Document getRequestDocumentForProductParentsByManufacturingNameService(String manufacturingName) throws
    Exception {
      return null;
    }

    public Document getRequestDocumentForGetAggregateProductService(String commercialName) throws Exception {
      return null;
    }
  }

  class MockProductServiceResponseParser implements ProductServiceResponseParser{

    public List getProductDetailsListFromProductParentsByPrecommercialNameServiceResponse(
        InputStream responseInputStream) throws Exception {
      return null;
    }

    public List getProductDetailsListFromProductParentsByManufacturingNameServiceResponse(
        InputStream responseInputStream) throws Exception {
      return null;
    }

    public String getPreCommercialNameFromGetAggregateProductServiceResponse(InputStream responseInputStream) throws
    Exception {
      return null;
    }
  }

  class MockPOSConnection_ThrowsException extends MockPOSConnection{

    public MockPOSConnection_ThrowsException(String userName, String password) {
      super(userName, password);
    }


    public POSResult callService(String posRequestName, Document document) throws POSException,
        POSCommunicationException {
      throw new POSCommunicationException("Communication exception");
    }
  }
}