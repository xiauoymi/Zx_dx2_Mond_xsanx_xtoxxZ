package com.monsanto.wst.usseedplanning.Servlet.test;

import com.monsanto.wst.commonutils.EnvironmentUtils;
import com.monsanto.wst.usseedplanning.Servlet.USSeedPlanningServlet;
import com.monsanto.wst.usseedplanning.Servlet.test.mock.MockHttpServletRequest;
import com.monsanto.wst.usseedplanning.Servlet.test.mock.MockHttpServletResponse;
import com.monsanto.wst.usseedplanning.utils.testutils.USSeedPlanningBaseTestCase;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import java.util.Enumeration;

/**
 * Created by IntelliJ IDEA.
 * Date: Aug 16, 2006
 * Time: 12:37:10 PM
 * <p/>
 * Unit test for the USSeedPlanningServlet object.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class USSeedPlanningServletUT extends USSeedPlanningBaseTestCase {
    protected void setUp() throws Exception {
        super.setUp();
        System.setProperty("catalina.base", new EnvironmentUtils().getVariable("CATALINA_HOME"));
        System.setProperty("current.domain", "");
        System.setProperty("current.port", "");
    }

    protected void tearDown() throws Exception {
        System.setProperty("catalina.base", "");
        System.setProperty("current.domain", "");
        System.setProperty("current.port", "");
        super.tearDown();    //To change body of overridden methods use File | Settings | File Templates.
    }

    public void testCreate() throws Exception {
        USSeedPlanningServlet servlet = new USSeedPlanningServlet();
        assertNotNull(servlet);
    }

    public void testDestroy() throws Exception {
        USSeedPlanningServlet servlet = new USSeedPlanningServlet();
        servlet.init(new MockServletConfig());
        servlet.destroy();
    }

    public void testDoGetSetsDomainInformation() throws Exception {
        USSeedPlanningServlet servlet = new USSeedPlanningServlet();
        servlet.init(new MockServletConfig());
        servlet.doGet(new MockHttpServletRequest(), new MockHttpServletResponse());
        assertEquals("monsanto.com", System.getProperty("current.domain"));
        assertEquals("80", System.getProperty("current.port"));
    }

    private class MockServletConfig implements ServletConfig {
        public String getServletName() {
            return null;  //To change body of implemented methods use File | Settings | File Templates.
        }

        public ServletContext getServletContext() {
            return null;  //To change body of implemented methods use File | Settings | File Templates.
        }

        public String getInitParameter(String sqlName) {
            return "com.monsanto.wst.usseedplanning.Servlet.test.mock.MockUseCaseController";
        }

        public Enumeration getInitParameterNames() {
            return null;  //To change body of implemented methods use File | Settings | File Templates.
        }
    }
}
