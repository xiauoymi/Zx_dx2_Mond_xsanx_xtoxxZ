package com.monsanto.wst.usseedplanning.services.core.test;

import com.monsanto.wst.commonutils.reflection.ObjectInspector;
import com.monsanto.wst.commonutils.resources.ResourceUtils;
import com.monsanto.wst.factory.AbstractGenericFactory;
import com.monsanto.wst.factory.GenericFactory;
import com.monsanto.wst.usseedplanning.model.maintenance.CommonData;
import com.monsanto.wst.usseedplanning.model.maintenance.DemandForecast;
import com.monsanto.wst.usseedplanning.model.maintenance.supply.Supply;
import com.monsanto.wst.usseedplanning.model.planning.PlanEntry;
import com.monsanto.wst.usseedplanning.services.core.ImportSpreadsheetService;
import com.monsanto.wst.usseedplanning.utils.testutils.USSeedPlanningTestUtils;
import com.monsanto.wst.usseedplanning.constants.DatabaseConstants;
import junit.framework.TestCase;

import java.io.File;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * Date: Aug 8, 2006
 * Time: 1:10:11 PM
 * <p/>
 * Integration/Acceptance test for the SpreadsheetService interface.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class ImportSpreadsheetServiceAT extends TestCase {
    protected void setUp() throws Exception {
        USSeedPlanningTestUtils testUtils = new USSeedPlanningTestUtils(new ObjectInspector());
        testUtils.setupContainer();
        super.setUp();
    }

    public void testGetCommonForecasts() throws Exception {
        GenericFactory container = AbstractGenericFactory.getInstance();
        ImportSpreadsheetService service = (ImportSpreadsheetService) container.getBean("importSpreadsheetService");
        File file = new ResourceUtils().convertPathToFile("com/monsanto/wst/usseedplanning/services/core/filetemplate/test/CommonForecastExample.xls");
        List demandForecastList = service.getCommonForecasts(file);
        assertEquals(48, demandForecastList.size());
        DemandForecast demand = (DemandForecast) demandForecastList.get(0);
        assertNotNull(demand.getCommonName());
        assertNotNull(demand.getYear());
        assertNotNull(demand.getDate());
        assertNotNull(demand.getChannel());
        assertNotNull(demand.getChannel().getName());
        assertNotNull(demand.getData());
        assertNotNull(demand.getData().getUnits());
        assertNotNull(demand.getData().getWinterUnits());
        assertNotNull(demand.getData().getNextYearUnits());
    }

    public void testGetDemandForecasts() throws Exception {
        GenericFactory container = AbstractGenericFactory.getInstance();
        ImportSpreadsheetService service = (ImportSpreadsheetService) container.getBean("importSpreadsheetService");
        File file = new ResourceUtils().convertPathToFile("com/monsanto/wst/usseedplanning/services/core/filetemplate/test/DemandForecastExample.xls");
        List demandForecastList = service.getDemandForecasts(file);
        assertEquals(290, demandForecastList.size());
        DemandForecast demand = (DemandForecast) demandForecastList.get(0);
        assertNotNull(demand.getCommonName());
        assertNotNull(demand.getData());
        assertNotNull(demand.getData().getUnits());
    }

    public void testGetATPSupply() throws Exception {
        GenericFactory container = AbstractGenericFactory.getInstance();
        ImportSpreadsheetService service = (ImportSpreadsheetService) container.getBean("importSpreadsheetService");
        File file = new ResourceUtils().convertPathToFile("com/monsanto/wst/usseedplanning/services/mock/yaptfnd.xls");
        List supplyList = service.getATPSupply(file);
        assertEquals(28, supplyList.size());
        Supply supply = (Supply) supplyList.get(0);
        assertNotNull(supply.getIdentifiers().getBatch());
        assertNotNull(supply.getIdentifiers().getCompanyCode());
        assertNotNull(supply.getIdentifiers().getDescription());
        assertNotNull(supply.getIdentifiers().getManufacturingName());
        assertEquals("A", supply.getIdentifiers().getTraitVersion());
        assertNotNull(supply.getIdentifiers().getPlant());
        assertNotNull(supply.getIdentifiers().getSLOC());
        assertNotNull(supply.getIdentifiers().getMaterial().getGroup());
        assertNotNull(supply.getIdentifiers().getMaterial().getNumber());
        assertNotNull(supply.getIdentifiers().getMaterial().getType());
        assertNotNull(supply.getTestResults().getGrade());
//        assertNotNull(supply.getTestResults().getKC());
//        assertNotNull(supply.getTestResults().getTreatment());
        assertNotNull(supply.getTestResults().getCertFlag());
//        assertNotNull(supply.getTestResults().getWarmGermMVK());
//        assertNotNull(supply.getTestResults().getColdTestCurrent());
//        assertNotNull(supply.getTestResults().getColdTestBOL());
//        assertNotNull(supply.getTestResults().getDefectCode());
//        assertNotNull(supply.getTestResults().getUsageDesc());
//        assertNotNull(supply.getTestResults().getStewartWilt());
//        assertNotNull(supply.getTestResults().getWheatStreak());
//        assertNotNull(supply.getTestResults().getCanadaNox());
//        assertNotNull(supply.getTestResults().getHybRRSusc());
//        assertNotNull(supply.getTestResults().getGrowout().getSelfs());
//        assertNotNull(supply.getTestResults().getGrowout().getTalls());
//        assertNotNull(supply.getTestResults().getGrowout().getPercentFertiles());
//        assertNotNull(supply.getTestResults().getGrowout().getOthers());
//        assertNotNull(supply.getTestResults().getGrowout().getTallsPlusOthers());
//        assertNotNull(supply.getTestResults().getIsozymes().getVariants());
//        assertNotNull(supply.getTestResults().getIsozymes().getTotalPurityTwo());
//        assertNotNull(supply.getTestResults().getIsozymes().getOthers());
//        assertNotNull(supply.getTestResults().getSnpVariants());
//        assertNotNull(supply.getTestResults().getSnpTotalPurity());
//        assertNotNull(supply.getTestResults().getNonWaxy());
//        assertNotNull(supply.getTestResults().getNonWhite());
//        assertNotNull(supply.getTestResults().getPercentOil());
//        assertNotNull(supply.getTestResults().getPCR().getTestNumberOfPools());
//        assertNotNull(supply.getTestResults().getPCR().getTestSeedsPerPool());
//        assertNotNull(supply.getTestResults().getPCR().getTestBT11Pat());
//        assertNotNull(supply.getTestResults().getPCR().getTestBAR());
//        assertNotNull(supply.getTestResults().getPCR().getTestGA21RR());
//        assertNotNull(supply.getTestResults().getPCR().getTest88017AP());
//        assertNotNull(supply.getTestResults().getPCR().getTestCry1Pat());
//        assertNotNull(supply.getTestResults().getPCR().getTestMON810AP());
//        assertNotNull(supply.getTestResults().getPCR().getTestBLKT25Pat());
//        assertNotNull(supply.getTestResults().getPCR().getTestNK603AP());
//        assertNotNull(supply.getTestResults().getPCR().getTestPAT());
//        assertNotNull(supply.getTestResults().getPCR().getTestMON863());
//        assertNotNull(supply.getTestResults().getPCR().getTestHerculexNumDetects());
//        assertNotNull(supply.getTestResults().getPCR().getTestLY038AP());
//        assertNotNull(supply.getTestResults().getPCR().getTestAPPassFail());
//        assertNotNull(supply.getTestResults().getPCR().getTestPercentUpperBound());
//        assertNotNull(supply.getTestResults().getPCR().getTestPercentTotalAP());
//        assertNotNull(supply.getTestResults().getPCR().getTestNK603Zygosity());
//        assertNotNull(supply.getTestResults().getPCR().getTestLY038Zygosity());
//        assertNotNull(supply.getTestResults().getPCR().getTest88017Zygosity());
//        assertNotNull(supply.getTestResults().getALSPositive());
//        assertNotNull(supply.getTestResults().getElisaMon810());
//        assertNotNull(supply.getTestResults().getElisaMon863());
//        assertNotNull(supply.getTestResults().getPonchoMediumRate());
//        assertNotNull(supply.getTestResults().getCombinedDDDIM());
//        assertNotNull(supply.getTestResults().getWarmGerm());
//        assertNotNull(supply.getData().getSeedCount());
//        assertNotNull(supply.getData().getBagWeight());
//        assertNotNull(supply.getData().getMvkPerBag());
//        assertNotNull(supply.getData().getShipped());
//        assertNotNull(supply.getData().getBag());
        assertNotNull(supply.getData().getMVK().getUnrestricted());
        assertNotNull(supply.getData().getMVK().getAtp());
        assertNotNull(supply.getData().getMVK().getAvailable());
        assertNotNull(supply.getData().getMVK().getBlocked());
        assertNotNull(supply.getData().getMVK().getCustomerDemand());
        assertNotNull(supply.getData().getMVK().getNextYearProcessOrders());
        assertNotNull(supply.getData().getMVK().getPlanned());
        assertNotNull(supply.getData().getMVK().getPlantDemand());
        assertNotNull(supply.getData().getMVK().getProcessOrders());
        assertNotNull(supply.getData().getMVK().getRestricted());
        assertNotNull(supply.getData().getMVK().getSalesOrder());
        assertNotNull(supply.getData().getMVK().getScheduledForDelivery());
        assertNotNull(supply.getData().getMVK().getStockTransfers());
        assertNotNull(supply.getData().getBags().getUnrestricted());
        assertNotNull(supply.getData().getBags().getAtp());
        assertNotNull(supply.getData().getBags().getBlocked());
        assertNotNull(supply.getData().getBags().getAvailable());
        assertNotNull(supply.getData().getBags().getCustomerDemand());
        assertNotNull(supply.getData().getBags().getNextYearProcessOrders());
        assertNotNull(supply.getData().getBags().getPlantDemand());
        assertNotNull(supply.getData().getBags().getProcessOrders());
        assertNotNull(supply.getData().getBags().getRestricted());
        assertNotNull(supply.getData().getBags().getSalesOrder());
        assertNotNull(supply.getData().getBags().getScheduledForDelivery());
        assertNotNull(supply.getData().getBags().getStockTransfers());
//        assertNotNull(supply.getData().getPartialBagPounds().getAtp());
//        assertNotNull(supply.getData().getPartialBagPounds().getAvailable());
//        assertNotNull(supply.getData().getPartialBagPounds().getBlocked());
//        assertNotNull(supply.getData().getPartialBagPounds().getCustomerDemand());
//        assertNotNull(supply.getData().getPartialBagPounds().getNextYearProcessOrders());
//        assertNotNull(supply.getData().getPartialBagPounds().getPlantDemand());
//        assertNotNull(supply.getData().getPartialBagPounds().getProcessOrders());
//        assertNotNull(supply.getData().getPartialBagPounds().getRestricted());
//        assertNotNull(supply.getData().getPartialBagPounds().getSalesOrder());
//        assertNotNull(supply.getData().getPartialBagPounds().getScheduledForDelivery());
//        assertNotNull(supply.getData().getPartialBagPounds().getStockTransfers());
//        assertNotNull(supply.getData().getPartialBagPounds().getUnrestricted());
//        assertNotNull(supply.getData().getBulk().getAvailable());
//        assertNotNull(supply.getData().getBulk().getBlocked());
//        assertNotNull(supply.getData().getBulk().getCustomerDemand());
//        assertNotNull(supply.getData().getBulk().getNextYearProcessOrders());
//        assertNotNull(supply.getData().getBulk().getPlanned());
//        assertNotNull(supply.getData().getBulk().getPlantDemand());
//        assertNotNull(supply.getData().getBulk().getProcessOrders());
//        assertNotNull(supply.getData().getBulk().getRestricted());
//        assertNotNull(supply.getData().getBulk().getSalesOrder());
//        assertNotNull(supply.getData().getBulk().getScheduledForDelivery());
//        assertNotNull(supply.getData().getBulk().getStockTransfers());
//        assertNotNull(supply.getData().getBulk().getUnrestricted());
    }


    public void testGetZDCASupply() throws Exception {
        GenericFactory container = AbstractGenericFactory.getInstance();
        ImportSpreadsheetService service = (ImportSpreadsheetService) container.getBean("importSpreadsheetService");
        File file = new ResourceUtils().convertPathToFile("com/monsanto/wst/usseedplanning/services/mock/ZDCAExampleSmall.xls");
        List supplyList = service.getZDCASupply(file);
        assertEquals(6, supplyList.size());
        Supply supply = (Supply) supplyList.get(0);
        assertNotNull(supply.getIdentifiers().getBatch());
        assertNotNull(supply.getIdentifiers().getDescription());
        assertNotNull(supply.getIdentifiers().getManufacturingName());
        assertNotNull(supply.getIdentifiers().getPlant());
        assertNotNull(supply.getIdentifiers().getSLOC());
        assertNotNull(supply.getData().getBags().getBlocked());
        assertNotNull(supply.getData().getBags().getUnrestricted());
        assertNotNull(supply.getData().getBags().getRestricted());
    }

    public void testCommonUploads() throws Exception {
        GenericFactory container = AbstractGenericFactory.getInstance();
        ImportSpreadsheetService service = (ImportSpreadsheetService) container.getBean("importSpreadsheetService");
        File file = new ResourceUtils().convertPathToFile("com/monsanto/wst/usseedplanning/services/mock/CommonUpload.xls");
        List commonUploadList = service.getCommonUpload("msis",file);
        assertEquals(1, commonUploadList.size());
        CommonData commonData = (CommonData) commonUploadList.get(0);
        assertNotNull(commonData.getYear());
        assertNotNull(commonData.getName());
        assertNotNull(commonData.getUnits());
        assertNotNull(commonData.getTableName());
    }
    public void testSavePlanUploadsForHybrid() throws Exception {
        GenericFactory container = AbstractGenericFactory.getInstance();
        ImportSpreadsheetService service = (ImportSpreadsheetService) container.getBean("importSpreadsheetService");
        File hybridFile = new ResourceUtils().convertPathToFile("com/monsanto/wst/usseedplanning/services/core/test/testPlan.xls");
        List savePlanList = service.getSavePlanSpreadSheet(hybridFile);
        assertNotNull(savePlanList);
        assertEquals(9, savePlanList.size());
        PlanEntry entry = (PlanEntry) savePlanList.get(savePlanList.size() - 1);
        assertEquals(new Long(104), entry.getId());
        assertEquals(new Long(794), entry.getPlanType().getId());
        assertEquals("test-a", entry.getCommonName());
        assertEquals("DK7777", entry.getProductDetails().getManufacturingName());
        assertEquals(DatabaseConstants.TRUE_INDICATOR, entry.getUserData().getReciprocal());
        assertEquals(new Double(86), entry.getUserData().getLicProdFactor1());
        assertEquals(new Long(70), entry.getUserData().getLicPlan());
        assertEquals(new Long(71), entry.getUserData().getLicSa());
        assertEquals(new Long(72), entry.getUserData().getLicHi());
        assertEquals(new Long(73), entry.getUserData().getLicOth1());
        assertEquals(new Long(74), entry.getUserData().getLicOth2());
        assertEquals(new Double(84), entry.getUserData().getUsProdFactor1());
        assertEquals(new Long(75), entry.getUserData().getUsPlan());
        assertEquals(new Long(76), entry.getUserData().getUsSa());
        assertEquals(new Long(77), entry.getUserData().getUsHi());
        assertEquals(new Long(78), entry.getUserData().getUsOth1());
        assertEquals(new Long(79), entry.getUserData().getUsOth2());
        assertEquals(new Double(80), entry.getUserData().getPipeline());
        assertEquals(new Double(1), entry.getUserData().getHybridProdFactor1Header());
        assertEquals(new Double(1), entry.getUserData().getParentProdFactor1Header());
        assertEquals(new Double(1), entry.getUserData().getHybridProdFactor2Header());
        assertEquals(new Double(1), entry.getUserData().getParentProdFactor2Header());
        assertEquals(new Double(1), entry.getUserData().getForcedQaLossHeader());
        assertEquals(new Double(0.0), entry.getUserData().getMonthlyInventoryAdjustmentAuditHeader());
        assertEquals(new Double(1), entry.getUserData().getStageFactorHeader());
        assertEquals(new Double(0), entry.getUserData().getSomForcedHeader());
        assertEquals(new Double(0.016), entry.getUserData().getReplantHeader());
        assertEquals(new Double(0.24), entry.getUserData().getPipelineFactorHeader());
        assertEquals(new Double(0), entry.getUserData().getYearPlusOneSomForcedHeader());
        assertEquals(new Double(745), entry.getCrossPlanData().getAvailableSeed());
        assertEquals(new Double(782.25), entry.getCrossPlanData().getPlannedFemaleSeed());
        assertEquals(new Double(419.0625), entry.getCrossPlanData().getPlannedMaleSeed());
        assertEquals(new Double(1738.9679999999998), entry.getCrossPlanData().getYearPlusOneFemaleSeed());
        assertEquals(new Double(93158.99999999999), entry.getCrossPlanData().getYearPlusOneMaleSeed());
        assertEquals(new Double(0.5), entry.getUserData().getMaleYieldTarget());

        assertEquals("DK7777", entry.getProductDetails().getFemaleParent().getPreCommercialName());
        assertEquals("1A", entry.getProductDetails().getFemaleParent().getVersion());
        assertEquals("HCL123", entry.getProductDetails().getFemaleParent().getManufacturingName());
        assertEquals("DK7777", entry.getProductDetails().getMaleParent().getPreCommercialName());
        assertEquals("1B", entry.getProductDetails().getMaleParent().getVersion());
        assertEquals("HCL345", entry.getProductDetails().getMaleParent().getManufacturingName());
    }
}
