/*
 USSeedPlanningLoggerFactoryUT was created on Aug 22, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.usseedplanning.Servlet.test;

import com.monsanto.AbstractLogging.LogRegistrationException;
import com.monsanto.wst.commonutils.testutils.TestUtils;
import com.monsanto.wst.usseedplanning.Servlet.USSeedPlanningLoggerFactory;
import com.monsanto.wst.usseedplanning.constants.MainConstants;
import junit.framework.TestCase;
import org.w3c.dom.Document;

import java.io.IOException;

/**
 * Filename:    $RCSfile: USSeedPlanningLoggerFactoryUT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: njminsh $    	 On:	$Date: 2006-09-08 15:10:12 $
 *
 * @author ffbrac
 * @version $Revision: 1.4 $
 */
public class USSeedPlanningLoggerFactoryUT extends TestCase {
	public void setUp()throws IOException, LogRegistrationException, Exception {
		TestUtils testUtils = new TestUtils();
		testUtils.setupLogging(MainConstants.APPLICATION_NAME);
		super.setUp();
	}
	public void testCreate(){
		USSeedPlanningLoggerFactory loggerFactory = new USSeedPlanningLoggerFactory();
		assertNotNull(loggerFactory);
	}
	public void testToXML(){
		USSeedPlanningLoggerFactory loggerFactory = new USSeedPlanningLoggerFactory();
		assertNotNull(loggerFactory);
		Document doc = loggerFactory.toXML();
		assertNotNull(doc);

	}
}