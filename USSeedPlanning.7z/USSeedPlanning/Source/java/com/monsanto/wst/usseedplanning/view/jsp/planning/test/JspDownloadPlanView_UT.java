package com.monsanto.wst.usseedplanning.view.jsp.planning.test;

import com.monsanto.wst.usseedplanning.utils.testutils.USSeedPlanningBaseTestCase;
import com.monsanto.wst.usseedplanning.view.jsp.planning.JspDownloadPlanView;
import com.monsanto.wst.usseedplanning.constants.ServletConstants;
import com.monsanto.wst.view.test.mock.MockUCCHelperThrowsIOException;
import com.monsanto.wst.view.ViewRenderingException;
import com.monsanto.ServletFramework.Test.MockUCCHelper;

/**
 * Created by IntelliJ IDEA.
 * Date: Feb 16, 2007
 * Time: 12:50:48 PM
 * <p/>
 * TODO: Enter description for class.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class JspDownloadPlanView_UT extends USSeedPlanningBaseTestCase {
    public void testCreate() throws Exception {
        JspDownloadPlanView view = new JspDownloadPlanView();
        assertNotNull(view);
    }

    public void testRenderView() throws Exception {
        MockUCCHelper helper = new MockUCCHelper(null);
        JspDownloadPlanView view = new JspDownloadPlanView();
        view.renderView(helper);
        assertTrue(helper.wasSentTo(ServletConstants.DOWNLOAD_PLAN_PAGE));
    }

    public void testRenderViewThrowsException() throws Exception {
        MockUCCHelperThrowsIOException helper = new MockUCCHelperThrowsIOException(null);
        JspDownloadPlanView view = new JspDownloadPlanView();
        try {
            view.renderView(helper);
            fail("This should throw an exception.");
        } catch (ViewRenderingException e) {
            // this should happen.
        }
    }
}
