/*
 Copyright:  Copyright � 2006 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.usseedplanning.services.maintenance.seedEntity.mock;

import com.monsanto.wst.usseedplanning.model.maintenance.QaThreshold;
import com.monsanto.wst.usseedplanning.services.maintenance.seedEntity.QaThresholdService;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

/**
 * Filename:    $RCSfile: MockQaThresholdService.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: jdpoul $    	 On:	$Date: 2006-09-11 18:39:57 $
 *
 * @author jdpoul
 * @version $Revision: 1.3 $
 */
public class MockQaThresholdService implements QaThresholdService {
  List thresholds = new ArrayList();

  public void saveEntity(QaThreshold qaThreshold, String comment) {
    thresholds.add(qaThreshold);
  }

  public Collection getQaThresholds() {
    return thresholds;
  }
}