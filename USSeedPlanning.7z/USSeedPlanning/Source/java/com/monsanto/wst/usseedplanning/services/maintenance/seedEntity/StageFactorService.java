/*
 StageFacotorService was created on Sep 18, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.usseedplanning.services.maintenance.seedEntity;

import com.monsanto.wst.usseedplanning.model.maintenance.StageFactor;

import java.util.List;

/**
 * Filename:    $RCSfile: StageFactorService.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: jdpoul $ On:	$Date:
 * 2006/10/24 17:21:23 $
 *
 * @author sspati1
 * @version $Revision: 1.4 $
 */
public interface StageFactorService {

  /**
   * This method returns a list of stage factors with the specified product name
   *
   * @return - Lit of stage factors
   */

  /**
   * This method returns a Stage Factor with specided revision Id
   *
   * @return - Stage Factor object
   */
  StageFactor lookupStageFactorsByRevisionId(Long revisionId);

  /**
   * this method inserts a new Stage Factor
   *
   * @param stageFactor
   */
  void saveStageFactor(StageFactor stageFactor, String comments);

  List getAllApplicableStageFactorsInOrderOfPrecedence(String productNameCriteria, Long yearCriteria,
                                                       Long stageCriteria, Long maxRevisionId);

  StageFactor getMostAppropriateStageFactor(String productNameCriteria, Long yearCriteria,
                                            Long stageCriteria, Long maxRevisionId);
}