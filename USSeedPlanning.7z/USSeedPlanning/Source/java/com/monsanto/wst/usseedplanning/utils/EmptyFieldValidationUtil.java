package com.monsanto.wst.usseedplanning.utils;

import com.monsanto.Util.StringUtils;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Aug 4, 2006
 * Time: 8:30:53 AM
 * To change this template use File | Settings | File Templates.
 */
public class EmptyFieldValidationUtil {

    public static List updateErrorListForRequiredField(String value, List errorList) {
        if (StringUtils.isNullOrEmpty(value)){
            if (errorList!=null && errorList.size() == 0){
                errorList.add("Please Fill in the Fields marked as required");
            }
        }
        return errorList;
    }
}
