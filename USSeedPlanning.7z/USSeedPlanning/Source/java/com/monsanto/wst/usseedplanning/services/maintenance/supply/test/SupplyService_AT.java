package com.monsanto.wst.usseedplanning.services.maintenance.supply.test;

import com.monsanto.wst.commonutils.resources.ResourceUtils;
import com.monsanto.wst.dbtemplate.DBTemplate;
import com.monsanto.wst.factory.AbstractGenericFactory;
import com.monsanto.wst.usseedplanning.model.core.LoginUser;
import com.monsanto.wst.usseedplanning.model.maintenance.supply.SupplyType;
import com.monsanto.wst.usseedplanning.model.maintenance.supply.Supply;
import com.monsanto.wst.usseedplanning.model.maintenance.Revision;
import com.monsanto.wst.usseedplanning.model.planning.PlanType;
import com.monsanto.wst.usseedplanning.services.maintenance.supply.SupplyService;
import com.monsanto.wst.usseedplanning.utils.testutils.USSeedPlanningBaseTransactionTestCase;

import java.io.File;
import java.util.List;

/**
 * Created by IntelliJ IDEA. Date: Feb 12, 2007 Time: 1:47:46 PM <p/> TODO: Enter description for class.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class SupplyService_AT extends USSeedPlanningBaseTransactionTestCase {
  protected String getConfigPath() {
    return "com/monsanto/wst/usseedplanning/services/maintenance/supply/test/dbunit/supplyDataSet.xml";
  }

  public void testUpdateSupplyOfTypeYATPFNDOnlyAddsSummaryAndBatchRows() throws Exception {
    SupplyService supplyService = (SupplyService) AbstractGenericFactory.getInstance().getBean("supplyService");
    File yatpfndFile = new ResourceUtils()
      .convertPathToFile("com/monsanto/wst/usseedplanning/services/maintenance/supply/test/test_YATPFND_1_23_07.xls");
    LoginUser currentUser = new LoginUser("DBUNIT");
    supplyService.updateSupply(yatpfndFile, currentUser, SupplyType.ATP_SUPPLY_TYPE, PlanType.PARENT_PLAN_TYPE_ID,
      "Test Upload of YATPFND");
    DBTemplate template = (DBTemplate) AbstractGenericFactory.getInstance().getBean("dbTemplate");
    Integer numRows = (Integer) template.executeSingleResultQuery("lookupNumberOfSupplyRows");
    assertEquals(new Integer(98), numRows);
    List list = supplyService.lookupSupplyRevisionsByCriteria(PlanType.PARENT_PLAN_TYPE_ID);
    assertNotNull(list);
    List supplyList = template
      .executeListResultQuery("lookupSupplyByRevisionForTesting", ((Revision) list.get(0)).getId());
    assertNotNull(supplyList);
    assertEquals(98, supplyList.size());
    for (int i = 0; i < supplyList.size(); i++) {
      Supply row = (Supply) supplyList.get(i);
      if (row.getIdentifiers().getManufacturingName().equalsIgnoreCase("01DHD10") &&
        row.getIdentifiers().getSLOC() == "*ATPWM01") {
        assertTrue(row.getData().getMVK().getAtp().doubleValue() == 5);
      }
      if (row.getIdentifiers().getManufacturingName().equalsIgnoreCase("6022CMS") &&
        row.getIdentifiers().getSLOC() == "WM01") {
        assertTrue(row.getData().getMVK().getAtp().doubleValue() == 10);
        assertTrue(row.getData().getMVK().getCustomerDelivery().doubleValue() == 0);
        assertTrue(row.getData().getMVK().getUnrestricted().doubleValue() == 0);
        assertTrue(row.getData().getMVK().getRestricted().doubleValue() == 0);
        assertTrue(row.getData().getMVK().getBlocked().doubleValue() == 0);
        assertTrue(row.getData().getMVK().getProcessOrders().doubleValue() == 0);
        assertTrue(row.getData().getMVK().getStockTransfers().doubleValue() == 0);

      }
    }
  }

  public void testUpdateSupplyOfTypeZDCAAddsAllRowsWhereDescriptionIsNotEmpty() throws Exception {
    SupplyService supplyService = (SupplyService) AbstractGenericFactory.getInstance().getBean("supplyService");
    File zdcaFile = new ResourceUtils()
      .convertPathToFile("com/monsanto/wst/usseedplanning/services/maintenance/supply/test/test_ZDCA_2_12_07.xls");
    LoginUser currentUser = new LoginUser("DBUNIT");
    supplyService.updateSupply(zdcaFile, currentUser, SupplyType.ZDCA_SUPPLY_TYPE, PlanType.HYBRID_PLAN_TYPE_ID,
      "Test Upload of ZDCA");
    DBTemplate template = (DBTemplate) AbstractGenericFactory.getInstance().getBean("dbTemplate");
    Integer numRows = (Integer) template.executeSingleResultQuery("lookupNumberOfSupplyRows");
    assertEquals(new Integer(99), numRows);
  }
}
