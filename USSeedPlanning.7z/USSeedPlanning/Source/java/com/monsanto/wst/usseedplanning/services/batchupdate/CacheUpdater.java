package com.monsanto.wst.usseedplanning.services.batchupdate;

import com.monsanto.wst.usseedplanning.model.core.BatchSummary;
import com.monsanto.wst.usseedplanning.model.core.LoginUser;

import java.util.List;
import java.util.ArrayList;
/*
CacheUpdater was created on Nov 22, 2006 using Monsanto
resources and is the sole property of Monsanto.
Any duplication of the code and/or logic is a
direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, TCC, Monsanto
 */
public interface CacheUpdater {
    void lookUpNewModifiedDeletedProducts(List listOfProductDetails);

    void insert(List listOfUpdatedProductDetails);

    BatchSummary getBatchSummary();

    void setBatchSummary(BatchSummary batchSummary);

    LoginUser getCurrentUser();

    void setCurrentUser(LoginUser currentUser);

    void removeProduct(List listOfProducts);

    void negatePreviousProductsInCommercialForNewProductsInserted(List arrayList);
}
