/*
 Copyright:  Copyright � 2006 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.usseedplanning.controller.validator.test;

import junit.framework.TestCase;
import com.monsanto.wst.usseedplanning.controller.validator.QaThresholdFormValidator;
import com.monsanto.wst.usseedplanning.constants.MainConstants;
import com.monsanto.wst.validator.HttpRequestErrors;
import com.monsanto.ServletFramework.Test.MockUCCHelper;

/**
 * Filename:    $RCSfile: QaThresholdFormValidator_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: jdpoul $    	 On:	$Date: 2006-09-20 19:57:05 $
 *
 * @author jdpoul
 * @version $Revision: 1.4 $
 */
public class QaThresholdFormValidator_UT extends TestCase {

    MockUCCHelper helper;
    QaThresholdFormValidator validator;
    HttpRequestErrors testErrors;

    public QaThresholdFormValidator_UT(String name) {
        super(name);
    }

    protected void setUp() throws Exception {
        super.setUp();
        this.helper = new MockUCCHelper(null);
        this.validator = new QaThresholdFormValidator();
        this.testErrors = new HttpRequestErrors();
    }

    public void testCreate(){
        QaThresholdFormValidator validator1 = new QaThresholdFormValidator();
        assertNotNull(validator1);
    }

    public void testCheckLongValueNoParamsRequiredField()throws Exception{
        HttpRequestErrors errors = validator.checkLongValue(testErrors, helper, "testKey", "test field", true);
        assertFalse(errors.isEmpty());
        assertEquals("Please select a value for the field " + "test field" + ".", testErrors.getError("testKey"));

    }


    public void testCheckLongValueNoParamsNotRequiredField()throws Exception{
        HttpRequestErrors errors = validator.checkLongValue(testErrors, helper, "testKey", "test field", false);
        assertTrue(errors.isEmpty());
    }

    public void testCheckLongValueNullArg1(){
        try {
            validator.checkLongValue(null, helper, "test", "test", true);
            fail("Null HttpRequestErrors instance did not throw IllegalArgumentException.");
        } catch (Exception e) {
            assertEquals("The HttpRequestErrors instance passed in was null.", e.getMessage());
        }
    }


    public void testCheckLongValueNullArg2(){
        try {
            validator.checkLongValue(testErrors, null, "test", "test", true);
            fail("Null HttpRequestErrors instance did not throw IllegalArgumentException.");
        } catch (Exception e) {
            assertEquals("The UCCHelper instance passed in was null.", e.getMessage());
        }
    }

    public void testCheckLongValueWCorrectParam()throws Exception{
        helper.setRequestParameterValue("testKey", new Long(1));
        validator.checkLongValue(testErrors, helper, "testKey", "test field", true);
        assertTrue(testErrors.isEmpty());
    }

    public void testCheckLongValueWrongValueType()throws Exception{
        helper.setRequestParameterValue("testKey", "test");
        String testFieldName = "test field";
        validator.checkLongValue(testErrors,  helper, "testKey", testFieldName, true);
        assertFalse(testErrors.isEmpty());
        assertEquals("Please select a value for the field " + testFieldName + ".", testErrors.getError("testKey"));
    }

    public void testCheckLongValueEmptyStringExpectedNoError()throws Exception{
        helper.setRequestParameterValue("testKey", "");
        String testFieldName = "test field";
        validator.checkLongValue(testErrors,  helper, "testKey", testFieldName, false);
        assertTrue(testErrors.isEmpty());
    }


    public void testCheckAllValuesGenderParamMissing()throws Exception{
        helper.setRequestParameterValue(MainConstants.QaThresholdConstants.COMPARISON_STRATEGY_ID_PARAM_NAME, new Long(1));
        helper.setRequestParameterValue(MainConstants.QaThresholdConstants.QA_THRESHOLD_TYPE_ID_PARAM_NAME, new Long(1));
        helper.setRequestParameterValue(MainConstants.QaThresholdConstants.ACTIVE_PARAM_NAME, "true");
        helper.setRequestParameterValue(MainConstants.QaThresholdConstants.VALUE_PARAM_NAME, "test");

        HttpRequestErrors errors = validator.validate(helper);
        assertTrue(errors.isEmpty());

    }

    public void testCheckAllValuesGenderParamNotNumber() throws Exception{
        helper.setRequestParameterValue(MainConstants.QaThresholdConstants.COMPARISON_STRATEGY_ID_PARAM_NAME, new Long(1));
        helper.setRequestParameterValue(MainConstants.QaThresholdConstants.QA_THRESHOLD_TYPE_ID_PARAM_NAME, new Long(1));
        helper.setRequestParameterValue(MainConstants.QaThresholdConstants.GENDER_ID_PARAM_NAME, "test");
        helper.setRequestParameterValue(MainConstants.QaThresholdConstants.YEAR_ID_PARAM_NAME, new Long(1));
        HttpRequestErrors errors = validator.validate(helper);
        assertFalse(errors.isEmpty());
        assertEquals("Please select a value for the field " + MainConstants.QaThresholdConstants.GENDER_ID_FIELD_NAME + ".", errors.getError(MainConstants.QaThresholdConstants.GENDER_ID_PARAM_NAME));
    }

    public void testCheckAllValuesSuccessful() throws Exception{
        helper.setRequestParameterValue(MainConstants.QaThresholdConstants.COMPARISON_STRATEGY_ID_PARAM_NAME, new Long(1));
        helper.setRequestParameterValue(MainConstants.QaThresholdConstants.QA_THRESHOLD_TYPE_ID_PARAM_NAME, new Long(1));
        helper.setRequestParameterValue(MainConstants.QaThresholdConstants.GENDER_ID_PARAM_NAME, new Long(1));
        helper.setRequestParameterValue(MainConstants.QaThresholdConstants.YEAR_ID_PARAM_NAME, new Long(1));
        helper.setRequestParameterValue(MainConstants.QaThresholdConstants.ACTIVE_PARAM_NAME, "true");
        helper.setRequestParameterValue(MainConstants.QaThresholdConstants.VALUE_PARAM_NAME, "test");
        HttpRequestErrors errors = validator.validate(helper);
        assertTrue(errors.isEmpty());

    }

    public void testCheckYearIdMissing() throws Exception {
        helper.setRequestParameterValue(MainConstants.QaThresholdConstants.COMPARISON_STRATEGY_ID_PARAM_NAME, new Long(1));
        helper.setRequestParameterValue(MainConstants.QaThresholdConstants.QA_THRESHOLD_TYPE_ID_PARAM_NAME, new Long(1));
        helper.setRequestParameterValue(MainConstants.QaThresholdConstants.GENDER_ID_PARAM_NAME, new Long(1));
        helper.setRequestParameterValue(MainConstants.QaThresholdConstants.ACTIVE_PARAM_NAME, "true");
        helper.setRequestParameterValue(MainConstants.QaThresholdConstants.VALUE_PARAM_NAME, "test");

        HttpRequestErrors errors = validator.validate(helper);
        assertTrue(errors.isEmpty());

    }

    public void testCheckActiveValueMissing() throws Exception
    {
        helper.setRequestParameterValue(MainConstants.QaThresholdConstants.COMPARISON_STRATEGY_ID_PARAM_NAME, new Long(1));
        helper.setRequestParameterValue(MainConstants.QaThresholdConstants.QA_THRESHOLD_TYPE_ID_PARAM_NAME, new Long(1));
        helper.setRequestParameterValue(MainConstants.QaThresholdConstants.GENDER_ID_PARAM_NAME, new Long(1));
        helper.setRequestParameterValue(MainConstants.QaThresholdConstants.YEAR_ID_PARAM_NAME, new Long(1));
        HttpRequestErrors errors = validator.validate(helper);
        assertTrue(!errors.isEmpty());
        assertEquals("The value for the field 'Active' was not specified, but is required.", errors.getError(MainConstants.QaThresholdConstants.ACTIVE_FIELD_NAME));

    }

    public void testCheckFactorValueMissing() throws Exception{
        helper.setRequestParameterValue(MainConstants.QaThresholdConstants.COMPARISON_STRATEGY_ID_PARAM_NAME, new Long(1));
        helper.setRequestParameterValue(MainConstants.QaThresholdConstants.QA_THRESHOLD_TYPE_ID_PARAM_NAME, new Long(1));
        helper.setRequestParameterValue(MainConstants.QaThresholdConstants.GENDER_ID_PARAM_NAME, new Long(1));
        helper.setRequestParameterValue(MainConstants.QaThresholdConstants.YEAR_ID_PARAM_NAME, new Long(1));
        helper.setRequestParameterValue(MainConstants.QaThresholdConstants.ACTIVE_PARAM_NAME, "true");
        HttpRequestErrors errors = validator.validate(helper);
        assertTrue(!errors.isEmpty());

    }

}