/*
 CommonUploadService was created on Oct 9, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.usseedplanning.services.maintenance;

import com.monsanto.wst.usseedplanning.model.core.LoginUser;
import com.monsanto.wst.usseedplanning.model.planning.ProductNameDetail;

import java.io.File;
import java.io.IOException;
import java.util.List;

/**
 * Filename:    $RCSfile: CommonUploadService.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: uukola $ On:	$Date:
 * 2007/02/23 20:31:03 $
 *
 * @author ffbrac
 * @version $Revision: 1.4 $
 */
public interface CommonUploadService {
  public void addCommonUpload(File spreadsheet, String columnName, LoginUser loginUser, String comments) throws
    IOException;

  public List lookupBaseNamesForPCMNameUpdate(String tableName);

  public List lookupPCMNamesForManufacturingNames(String tableName);


  public List lookupPCMNamesForCommercialNames(String tableName);

  public String lookupHighestRevisionPreCommercialName(String s);

  public ProductNameDetail getBaseNameDetail(ProductNameDetail productDetail);

  public void addNewPreCommercialNames(LoginUser loginUser, String table_name);

  public void addPreCommercialNamesForManufacturingNames(LoginUser loginUser, String tableName);

  public void addPreCommercialNamesForCommercialNames(LoginUser loginUser, String tableName);

  public void addPreCommercialNames(List pcmNameList, LoginUser loginUser, String tableName);
}

