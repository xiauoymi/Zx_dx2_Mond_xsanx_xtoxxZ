package com.monsanto.wst.usseedplanning.services.maintenance.seedEntity.dbServices;

import com.monsanto.wst.dbtemplate.dao.DBTemplateNoResultsException;
import com.monsanto.wst.usseedplanning.dao.QaThresholdDao;
import com.monsanto.wst.usseedplanning.model.maintenance.QaThreshold;
import com.monsanto.wst.usseedplanning.services.maintenance.seedEntity.QaThresholdService;
import com.monsanto.wst.usseedplanning.services.maintenance.seedEntity.ServiceException;

import java.util.Collection;
import java.util.LinkedList;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Aug 16, 2006
 * Time: 2:01:28 PM
 * To change this template use File | Settings | File Templates.
 */
public class QaThresholdDbServiceImpl implements QaThresholdService {

  private QaThresholdDao qaThresholdDao;

  public QaThresholdDbServiceImpl(QaThresholdDao qaThresholdDao) {
    this.qaThresholdDao = qaThresholdDao;
  }

  public void saveEntity(QaThreshold qaThreshold, String comment) throws ServiceException{
    try {
      qaThresholdDao.insert(qaThreshold, comment);
    } catch (DBTemplateNoResultsException e) {
      throw new ServiceException("Unable to add QA Threshold to the database.", e);
    }
  }

  public Collection getQaThresholds() {
    try {
      return qaThresholdDao.getQaThresholds();
    } catch (DBTemplateNoResultsException e) {
      //TODO Add Proper logging and exception handling
      System.out.println("Unable to retreive QA threshold instances from dbms due to: "+e.getMessage());
    }
    return new LinkedList();
  }
}
