package com.monsanto.wst.usseedplanning.utils.test;

import com.monsanto.wst.usseedplanning.utils.LoginUserUtil;
import junit.framework.TestCase;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Aug 3, 2006
 * Time: 12:53:16 PM
 * To change this template use File | Settings | File Templates.
 */
public class LoginUserUtil_UT extends TestCase {

    public void testLoginUserUtil() throws Exception {
        LoginUserUtil loginUserUtil = new LoginUserUtil();
        assertNotNull(loginUserUtil);
    }

    public void testGetNameInCorrectSequenceWithEmptyStringPassedIn() throws Exception {
        LoginUserUtil loginUserUtil = new LoginUserUtil();
        assertEquals("",loginUserUtil.getNameInCorrectSequence(""));
    }

    public void testGetNameInCorrectSequenceWithNullPassedIn() throws Exception {
        LoginUserUtil loginUserUtil = new LoginUserUtil();
        assertEquals("",loginUserUtil.getNameInCorrectSequence(null));
    }

    public void testGetNameInCorrectSequenceWithClassification() throws Exception {
        LoginUserUtil loginUserUtil = new LoginUserUtil();
        assertEquals("RIJO C GEORGE",loginUserUtil.getNameInCorrectSequence("GEORGE, RIJO C [AG/CONTRACTOR - 1000]"));
    }

    public void testGetNameInCorrectSequenceWithoutClassification() throws Exception {
        LoginUserUtil loginUserUtil = new LoginUserUtil();
        assertEquals("RIJO C GEORGE",loginUserUtil.getNameInCorrectSequence("GEORGE, RIJO C"));
    }

    public void testGetNameInCorrectSequenceWithoutClassificationAndInitials() throws Exception {
        LoginUserUtil loginUserUtil = new LoginUserUtil();
        assertEquals("RIJO GEORGE",loginUserUtil.getNameInCorrectSequence("GEORGE, RIJO"));
    }

    public void testGetNameInCorrectSequenceWithCorrectNameSequence() throws Exception {
        LoginUserUtil loginUserUtil = new LoginUserUtil();
        assertEquals("RIJO C GEORGE",loginUserUtil.getNameInCorrectSequence("RIJO C GEORGE"));
    }

}
