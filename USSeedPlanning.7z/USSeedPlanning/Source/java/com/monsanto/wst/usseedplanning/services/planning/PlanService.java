package com.monsanto.wst.usseedplanning.services.planning;

import com.monsanto.wst.usseedplanning.model.core.LoginUser;
import com.monsanto.wst.usseedplanning.model.planning.Plan;
import com.monsanto.wst.usseedplanning.model.planning.PlanCriteria;
import com.monsanto.wst.usseedplanning.model.planning.PlanSummary;

import java.util.List;
import java.io.File;
import java.io.IOException;

/**
 * Created by IntelliJ IDEA.
 * Date: Sep 15, 2006
 * Time: 2:34:17 PM
 * <p/>
 * This interface defines the contract for performing actions on a plan.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public interface PlanService {
  /**
   * This method generates a new plan.
   *
   * @param summary PlanSummary object representing plan summary information.
   * @param criteria PlanCriteria object representing criteria.
   * @param currentUser LoginUser object representing the current user.
   */
  void generatePlan(PlanSummary summary, PlanCriteria criteria, LoginUser currentUser) throws Exception;

  /**
   * This method returns the plan with the specified id.
   *
   * @param criteria
   * @return Plan - Object representing the plan.
   */
  Plan lookupPlanByCriteria(PlanCriteria criteria);

    /**
     * This method retrieves plan summary information based on the criteria specified.
     *
     * @param criteria PlanCriteria object representing criteria.
     * @return Plan - Object representing the plan summary information.
     */
    Plan lookupPlanSummaryByCriteria(PlanCriteria criteria);

    void savePlan(File planSpreadsheet, LoginUser loginUser, String comments) throws Exception;

    List lookupAllPlans();

  List lookupPlansByPlanType(Long planTypeId);

  void commitPlan(LoginUser loginUser, String comments, Long planRevisionId, Long planId) throws IOException;
}
