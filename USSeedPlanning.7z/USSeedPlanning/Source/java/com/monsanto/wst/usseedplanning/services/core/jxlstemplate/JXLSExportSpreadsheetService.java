/*
 JXLSTemplateSpreadsheetService was created on Sep 18, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.usseedplanning.services.core.jxlstemplate;

import com.monsanto.wst.commonutils.resources.ResourceUtils;
import com.monsanto.wst.usseedplanning.model.planning.Plan;
import com.monsanto.wst.usseedplanning.model.planning.PlanType;
import com.monsanto.wst.usseedplanning.services.core.ExportSpreadsheetService;
import net.sf.jxls.transformer.XLSTransformer;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.util.ShortList;
import org.apache.commons.lang.StringUtils;

import java.io.*;
import java.util.*;

/**
 * Filename:
 * $RCSfile: JXLSExportSpreadsheetService.java,v $ Label:
 * $Name:
 * $ Last Change: $Author: njminsh
 * $    	 On:
 * $Date: 2007-02-16 16:54:12 $
 *
 * @author ffbrac
 * @version $Revision: 1.17 $
 */
public class JXLSExportSpreadsheetService implements ExportSpreadsheetService {
  private File templateFile;
  private String filePath;
  private static final int MAX_SHEET_NAME_LENGTH = 31;

  public JXLSExportSpreadsheetService(ResourceUtils resourceUtils, String template) throws FileNotFoundException {
//    this.templateFile = resourceUtils.convertPathToFile(template);
    this.filePath = template;
  }

  public byte[] getPlanSpreadsheet(Plan plan) throws IOException {
    XLSTransformer transformer = new XLSTransformer();
    Map beans = new HashMap();
    InputStream inputStream = null;
    ResourceUtils resourceUtils = new ResourceUtils();
    try {
      inputStream = new FileInputStream(resourceUtils.convertPathToFile(filePath));
    } catch (FileNotFoundException e) {
      throw new IllegalArgumentException("Unable to find the schema at path: '" + resourceUtils.convertPathToFile(filePath)+ "'.");
    }

    if(PlanType.PARENT_PLAN_TYPE_NAME.equals(plan.getPlanType().getName())) {
      createFoudationXSLTransformation(transformer);
    } else {
      createHybridXSLTransformation(transformer);
    }

    beans.put("plan", plan);
    HSSFWorkbook workbook = transformer.transformXLS(inputStream, beans);
    workbook.setSheetName(0, StringUtils.left(plan.getPlanSummary().getName(), MAX_SHEET_NAME_LENGTH));
    ByteArrayOutputStream out = new ByteArrayOutputStream();
    workbook.write(out);
    return out.toByteArray();
  }

  private void createFoudationXSLTransformation(XLSTransformer transformer) {
    ArrayList colList = new ArrayList();
    colList.add(new Range(13, 13, 1));
    colList.add(new Range(15, 17, 1));
    colList.add(new Range(19, 19, 1));
    colList.add(new Range(33, 35, 1));
    colList.add(new Range(73, 81, 1));
    colList.add(new Range(84, 96, 1));
    colList.add(new Range(107, 109, 1));
    colList.add(new Range(113, 113, 1));
    colList.add(new Range(119, 137, 1));
    colList.add(new Range(147, 147, 1));
    colList.add(new Range(153, 153, 1));
    colList.add(new Range(165, 180, 1));
    colList.add(new Range(190, 190, 1));
    colList.add(new Range(196, 196, 1));
    colList.add(new Range(226, 229, 1));
    colList.add(new Range(242, 247, 1));
    transformer.setColumnsToHide(createColsToHideList(colList));
  }

  private void createHybridXSLTransformation(XLSTransformer transformer){
    // cols to hide
    ArrayList colList = new ArrayList();
    colList.add(new Range(3, 3, 1));
    colList.add(new Range(15, 17, 1));
    colList.add(new Range(19, 19, 1));
    colList.add(new Range(36, 64, 1));
    colList.add(new Range(101, 101, 1));
    colList.add(new Range(110, 111, 1));
    colList.add(new Range(122, 122, 1));
    colList.add(new Range(131, 131, 1));
    colList.add(new Range(138, 156, 1));
    colList.add(new Range(169, 169, 1));
    colList.add(new Range(181, 199, 1));
    colList.add(new Range(242, 247, 1));
    transformer.setColumnsToHide(createColsToHideList(colList));
  }

  private short[] createColsToHideList(ArrayList colList){
    ShortList columns = new ShortList();
    ListIterator listItr = colList.listIterator();
    Range range;
    while(listItr.hasNext()){
      range = (Range)listItr.next();
      for(int i = range.getStart()-1; i < range.getEnd(); i++){
        columns.add((short)i);
      }
    }
    return columns.toArray();
  }

  private class Range{
    int start;
    int end;
    int increment;

    public Range(int start, int end, int increment){
      this.start = start;
      this.end = end;
      this.increment = increment;
    }
    public int getIncrement(){
      return this.increment;
    }
    public int getStart(){
      return this.start;
    }
    public int getEnd(){
      return this.end;
    }
  }
}