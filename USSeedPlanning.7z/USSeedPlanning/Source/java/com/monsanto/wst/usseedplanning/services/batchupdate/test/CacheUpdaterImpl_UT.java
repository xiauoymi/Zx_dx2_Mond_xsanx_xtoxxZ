package com.monsanto.wst.usseedplanning.services.batchupdate.test;

import com.monsanto.wst.usseedplanning.dao.ProductDetailsDao;
import com.monsanto.wst.usseedplanning.dao.mock.MockPlanDao;
import com.monsanto.wst.usseedplanning.model.cache.ProductAlias;
import com.monsanto.wst.usseedplanning.model.cache.ProductDetails;
import com.monsanto.wst.usseedplanning.model.core.BatchSummary;
import com.monsanto.wst.usseedplanning.model.planning.PlanCriteria;
import com.monsanto.wst.usseedplanning.services.batchupdate.CacheUpdater;
import com.monsanto.wst.usseedplanning.services.batchupdate.CacheUpdaterImpl;
import com.monsanto.wst.usseedplanning.services.cache.ProductCachingService;
import com.monsanto.wst.usseedplanning.services.cache.mock.MockProductCachingService;
import junit.framework.TestCase;

import java.util.ArrayList;
import java.util.List;

/*
CacheUpdater_UT was created on Nov 22, 2006 using Monsanto
resources and is the sole property of Monsanto.
Any duplication of the code and/or logic is a
direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, TCC, Monsanto
 */

public class CacheUpdaterImpl_UT extends TestCase {
    public void testEmptyListDoesNothing() throws Exception {
        ProductDetailsDao changeDetector = new MockChangeDetectorAllChanged();
        MockCacheUpdaterForInsert updater = new MockCacheUpdaterForInsert(changeDetector, new MockProductCachingService(), new MockPlanDao(), new BatchSummary());
        updater.lookUpNewModifiedDeletedProducts(new ArrayList());
        assertEquals(0, updater.getNumInserts());
    }

    public void testExistingRecordDoesNotUpdate() throws Exception {
        ProductDetailsDao changeDetector = new MockChangeDetectorNoChanges();
        MockCacheUpdaterForInsert updater = new MockCacheUpdaterForInsert(changeDetector, new MockProductCachingService(), new MockPlanDao(), new BatchSummary());
        List list = new ArrayList(1);
        list.add(new ProductDetails("test", "test", "test", "1"));
        updater.lookUpNewModifiedDeletedProducts(list);
        assertEquals(0, updater.getNumInserts());
    }

    public void testOneNewItem() throws Exception {
        ProductDetailsDao changeDetector = new MockChangeDetectorAllChanged();
        MockCacheUpdaterForInsert updater = new MockCacheUpdaterForInsert(changeDetector, new MockProductCachingService(), new MockPlanDao(), new BatchSummary());
        List list = new ArrayList(1);
        ProductDetails product = new ProductDetails("test", "test", "test", "1");
        list.add(product);
        updater.lookUpNewModifiedDeletedProducts(list);
        assertEquals(1, updater.getNumInserts());
        assertEquals(product, updater.getInsert(0));
    }

    public void testOneNewItemOneOld() throws Exception {
        ProductDetailsDao changeDetector = new MockChangeDetectorAllChanged();
        MockCacheUpdaterForInsert updater = new MockCacheUpdaterForInsert(changeDetector, new MockProductCachingService(), new MockPlanDao(), new BatchSummary());
        List list = new ArrayList(1);
        ProductDetails product = new ProductDetails("test", "test", "test", "1");
        list.add(product);
        updater.lookUpNewModifiedDeletedProducts(list);
        assertEquals(1, updater.getNumInserts());
        assertEquals(product, updater.getInsert(0));
    }

    public void testOnePlustTwoNewItems() throws Exception {
        ProductDetailsDao changeDetector = new MockChangeDetectorAllChanged();
        MockCacheUpdaterForInsert updater = new MockCacheUpdaterForInsert(changeDetector, new MockProductCachingService(), new MockPlanDao(), new BatchSummary());
        List list1 = new ArrayList(2);
        List list2 = new ArrayList(1);
        ProductDetails product1 = new ProductDetails("test1", "test1", "test1", "1");
        ProductDetails product2 = new ProductDetails("test2", "test2", "test2", "2");
        ProductDetails product3 = new ProductDetails("test3", "test3", "test3", "3");
        list1.add(product1);
        list1.add(product2);
        list2.add(product3);
        updater.lookUpNewModifiedDeletedProducts(list1);
        updater.lookUpNewModifiedDeletedProducts(list2);
        assertEquals(3, updater.getNumInserts());
//    assertEquals(product1, updater.getInsert(0));
//    assertEquals(product2, updater.getInsert(1));
//    assertEquals(product3, updater.getInsert(2));
    }

    public void testNegatePreviousProductsInCommercialForNewProductsInserted() throws Exception {
        CacheUpdater cacheUpdater = new CacheUpdaterImpl
            (new com.monsanto.wst.usseedplanning.dao.mock.MockProductDetailsDao(),null,null,null);
        List productDetailsList = new ArrayList();
        ProductDetails productDetails = new ProductDetails();
        List productAliasList= new ArrayList();
        ProductAlias productAlias;
        productAlias = new ProductAlias();
        productAlias.setCommercialName("ABC");
        productAliasList.add(productAlias);
        productDetails.addProductAliases(productAliasList);
        productDetailsList.add(productDetails);
        cacheUpdater.negatePreviousProductsInCommercialForNewProductsInserted(productDetailsList);
    }

    public void testInsertItem() throws Exception {
        final String testValue = "test1";
        MockProductDetailsDao detailsDao = new MockProductDetailsDao();
        CacheUpdater updater = new CacheUpdaterImpl(detailsDao, new MockProductCachingService(), null, null);
        List insertList = new ArrayList(1);
        ProductDetails product = new ProductDetails(testValue, testValue, testValue, "1");
        insertList.add(product);
        updater.insert(insertList);
        assertTrue("No Exceptions during insert",true);
    }

    private class MockCacheUpdaterForInsert extends CacheUpdaterImpl {
        private final List inserted;

        public MockCacheUpdaterForInsert(ProductDetailsDao changeDetector, ProductCachingService productCachingService,
                                         MockPlanDao mockPlanDao, BatchSummary batchSummary) {
            super(changeDetector, productCachingService, null, batchSummary);
            inserted = new ArrayList();
        }

        public void insert(List listOfUpdatedProductDetails) {
            for (int i = 0; i < listOfUpdatedProductDetails.size(); i++) {
                ProductDetails productDetails = (ProductDetails) listOfUpdatedProductDetails.get(i);
                inserted.add(productDetails);
            }
        }

        public void negatePreviousProductsInCommercialForNewProductsInserted(List arrayList) {
        }

        public int getNumInserts() {
            return inserted.size();
        }

        public ProductDetails getInsert(int i) {
            return (ProductDetails) inserted.get(i);
        }
    }

    private class MockChangeDetectorNoChanges implements ProductDetailsDao {
        public List determineNewOrModifiedProducts(List products) {
            return new ArrayList(0);
        }

        public List lookupProductDetailsFromTemp(List tempPMNProductList) {
            return new ArrayList(0);
        }

        public List determineDeletedProducts() {
            return new ArrayList(0);
        }

        public void updateProductDetailsDao(String commercialName) {
        }

        public Long addProductDetails(ProductDetails details) {
            return null;
        }

        public void addProductDetails(List productDetailList) {
        }

        public List lookupPlanProductDetails(PlanCriteria criteria) {
            return new ArrayList(0);
        }
    }

    private class MockChangeDetectorAllChanged implements ProductDetailsDao {
        public List determineNewOrModifiedProducts(List products) {
            return new ArrayList(products);
        }

        public List lookupProductDetailsFromTemp(List tempPMNProductList) {
            return tempPMNProductList;
        }

        public List determineDeletedProducts() {
            return new ArrayList(0);
        }

        public void updateProductDetailsDao(String commercialName) {
        }

        public Long addProductDetails(ProductDetails details) {
            return null;
        }

        public void addProductDetails(List productDetailList) {
        }

        public List lookupPlanProductDetails(PlanCriteria criteria) {
            return new ArrayList(0);
        }
    }

    private class MockChangeDetectorOnlyFirstItemChanged implements ProductDetailsDao {
        public List determineNewOrModifiedProducts(List products) {
            List items = new ArrayList(1);
            items.add(products.get(0));
            return items;
        }

        public List lookupProductDetailsFromTemp(List tempPMNProductList) {
            return new ArrayList(0);
        }

        public List determineDeletedProducts() {
            return new ArrayList(0);
        }

        public void updateProductDetailsDao(String commercialName) {
        }

        public Long addProductDetails(ProductDetails details) {
            return null;
        }

        public void addProductDetails(List productDetailList) {
        }

        public List lookupPlanProductDetails(PlanCriteria criteria) {
            return new ArrayList(0);
        }
    }

    private class MockProductDetailsDao implements ProductDetailsDao {
        private final List added;

        public MockProductDetailsDao() {
            added = new ArrayList();
        }

        public void addProductDetails(List productDetailList) {
            added.addAll(productDetailList);
        }

        public List lookupPlanProductDetails(PlanCriteria criteria) {
            return new ArrayList(0);
        }

        public List getAdded() {
            return added;
        }

        public List determineNewOrModifiedProducts(List products) {
            return new ArrayList(0);
        }

        public List lookupProductDetailsFromTemp(List tempPMNProductList) {
            return new ArrayList(0);
        }

        public List determineDeletedProducts() {
            return new ArrayList(0);
        }

        public void updateProductDetailsDao(String commercialName) {
        }

        public Long addProductDetails(ProductDetails details) {
            return null;
        }
    }

}