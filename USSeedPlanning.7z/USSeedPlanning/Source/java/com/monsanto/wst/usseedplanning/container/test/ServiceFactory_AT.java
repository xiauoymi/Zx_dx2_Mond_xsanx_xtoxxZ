package com.monsanto.wst.usseedplanning.container.test;

import com.monsanto.POSClient.POSConnection;
import com.monsanto.POSClient.SecureXMLPOSConnection;
import com.monsanto.wst.commonutils.EnvironmentUtils;
import com.monsanto.wst.dbtemplate.dao.persistentstore.test.mock.MockPersistentStoreTransactionManager;
import com.monsanto.wst.factory.AbstractGenericFactory;
import com.monsanto.wst.factory.GenericFactory;
import com.monsanto.wst.usseedplanning.container.ServiceFactory;
import com.monsanto.wst.usseedplanning.services.batchupdate.BatchService;
import com.monsanto.wst.usseedplanning.services.batchupdate.BatchServiceImpl;
import com.monsanto.wst.usseedplanning.services.batchupdate.NewProductService;
import com.monsanto.wst.usseedplanning.services.batchupdate.NewProductServiceImpl;
import com.monsanto.wst.usseedplanning.services.cache.ProductLookupService;
import com.monsanto.wst.usseedplanning.services.cache.ProductLookupServiceImpl;
import com.monsanto.wst.usseedplanning.services.cache.lexiconclientservices.*;
import com.monsanto.wst.usseedplanning.services.cache.mock.MockProductLookupService;
import com.monsanto.wst.usseedplanning.services.core.*;
import com.monsanto.wst.usseedplanning.services.core.filetemplate.FileTemplateImportSpreadsheetService;
import com.monsanto.wst.usseedplanning.services.core.jxlstemplate.JXLSExportSpreadsheetService;
import com.monsanto.wst.usseedplanning.services.maintenance.CommonUploadService;
import com.monsanto.wst.usseedplanning.services.maintenance.CommonUploadServiceImpl;
import com.monsanto.wst.usseedplanning.services.maintenance.forecast.ForecastService;
import com.monsanto.wst.usseedplanning.services.maintenance.forecast.ForecastServiceImpl;
import com.monsanto.wst.usseedplanning.services.maintenance.seedEntity.*;
import com.monsanto.wst.usseedplanning.services.maintenance.seedEntity.dbServices.*;
import com.monsanto.wst.usseedplanning.services.planning.*;
import com.monsanto.wst.usseedplanning.services.reports.DashboardReportService;
import com.monsanto.wst.usseedplanning.services.reports.DashboardReportServiceImpl;
import com.monsanto.wst.usseedplanning.utils.testutils.TempBaseTestCase;

/**
 * Created by IntelliJ IDEA.
 * Date: Feb 11, 2007
 * Time: 6:29:04 PM
 * <p/>
 * TODO: Enter description for class.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class ServiceFactory_AT extends TempBaseTestCase {
    protected void setUp() throws Exception {
        super.setUp();
        String catalinaHome = new EnvironmentUtils().getVariable("CATALINA_HOME");
        System.setProperty("catalina.home", catalinaHome);
        GenericFactory container = AbstractGenericFactory.getInstance();
        container.addBean("transactionManager", new MockPersistentStoreTransactionManager(), true);
    }

    protected void tearDown() throws Exception {
        super.tearDown();
        System.setProperty("catalina.home", "");
    }

    public void testCreate() throws Exception {
        ServiceFactory factory = new ServiceFactory();
        assertNotNull(factory);
    }

    public void testGetImportSpreadsheetService() throws Exception {
        GenericFactory container = AbstractGenericFactory.getInstance();
        ImportSpreadsheetService service = (ImportSpreadsheetService) container.getBean("importSpreadsheetService");
        assertNotNull(service);
        assertEquals(FileTemplateImportSpreadsheetService.class, service.getClass());
    }

    public void testGetLoginService() throws Exception {
        GenericFactory container = AbstractGenericFactory.getInstance();
        LoginService service = (LoginService) container.getBean("loginService");
        assertNotNull(service);
        assertEquals(LoginServiceImpl.class, service.getClass());
    }

    public void testGetUserService() throws Exception {
        GenericFactory container = AbstractGenericFactory.getInstance();
        UserRoleService service = (UserRoleService) container.getBean("userRoleService");
        assertNotNull(service);
        assertEquals(UserRoleServiceImpl.class, service.getClass());
    }

    public void testGetQaThresholdTypeService() {
        GenericFactory container = AbstractGenericFactory.getInstance();
        QaThresholdTypeService service = (QaThresholdTypeService) container.getBean("qaThresholdTypeService");
        assertNotNull(service);
        assertEquals(QaThresholdTypeDbServiceImpl.class, service.getClass());

    }

    public void testGetYearService() {
        GenericFactory container = AbstractGenericFactory.getInstance();
        YearService service = (YearService) container.getBean("yearService");
        assertNotNull(service);
        assertEquals(YearServiceDbImpl.class, service.getClass());
    }

    public void testGetGenderService() {
        GenericFactory container = AbstractGenericFactory.getInstance();
        GenderService service = (GenderService) container.getBean("genderService");
        assertNotNull(service);
        assertEquals(GenderDbServiceImpl.class, service.getClass());
    }

    public void testGetLookupService() throws Exception {
        GenericFactory container = AbstractGenericFactory.getInstance();
        LookupService service = (LookupService) container.getBean("lookupService");
        assertNotNull(service);
        assertEquals(LookupServiceImpl.class, service.getClass());
    }

    public void testGetCommonUploadService() throws Exception {
        GenericFactory container = AbstractGenericFactory.getInstance();
        CommonUploadService service = (CommonUploadService) container.getBean("commonUploadService");
        assertNotNull(service);
        assertEquals(CommonUploadServiceImpl.class, service.getClass());
    }

    public void testGetDashboardReportService() throws Exception {
        GenericFactory container = AbstractGenericFactory.getInstance();
        DashboardReportService service = (DashboardReportServiceImpl) container.getBean("dashboardReportService");
        assertNotNull(service);
        assertEquals(DashboardReportServiceImpl.class, service.getClass());
    }

    public void testGetFactorService() throws Exception {
        GenericFactory container = AbstractGenericFactory.getInstance();
        FactorService service = (FactorService) container.getBean("factorService");
        assertNotNull(service);
        assertEquals(FactorServiceImpl.class, service.getClass());
    }

    public void testGetForecastService() throws Exception {
        GenericFactory container = AbstractGenericFactory.getInstance();
        ForecastService forecastService = (ForecastService) container.getBean("forecastService");
        assertNotNull(forecastService);
        assertEquals(ForecastServiceImpl.class, forecastService.getClass());
    }

    public void testGetPOSConnection() throws Exception {
        GenericFactory container = AbstractGenericFactory.getInstance();
        POSConnection connection = (POSConnection) container.getBean("POSConnection");
        assertNotNull(connection);
        assertEquals(SecureXMLPOSConnection.class, connection.getClass());
    }

    public void testGetQaThresholdComparisonStrategyService() throws Exception {
        GenericFactory container = AbstractGenericFactory.getInstance();
        QaThresholdComparisonStrategyService dao = (QaThresholdComparisonStrategyService) container.getBean("qaThresholdComparisonStrategyService");
        assertNotNull(dao);
        assertEquals(QaThresholdComparisonStrategyDbServiceImpl.class, dao.getClass());
    }

    public void testGetYieldTargetService() throws Exception {
        GenericFactory container = AbstractGenericFactory.getInstance();
        YieldTargetService dao = (YieldTargetService) container.getBean("yieldTargetService");
        assertNotNull(dao);
        assertEquals(YieldTargetDbServiceImpl.class, dao.getClass());
    }

    public void testGetExportSpreadsheetService() throws Exception {
        GenericFactory container = AbstractGenericFactory.getInstance();
        ExportSpreadsheetService service = (ExportSpreadsheetService) container.getBean("exportSpreadsheetService");
        assertNotNull(service);
        assertEquals(JXLSExportSpreadsheetService.class, service.getClass());
    }

    public void testGetPlanService() throws Exception {
        GenericFactory container = AbstractGenericFactory.getInstance();
        PlanService service = (PlanService) container.getBean("planService");
        assertNotNull(service);
        assertEquals(PlanServiceImpl.class, service.getClass());
    }

    public void testGetLexiconServiceResponseParser() throws Exception {
        GenericFactory container = AbstractGenericFactory.getInstance();
        ProductServiceResponseParser service = (ProductServiceResponseParser) container.getBean("lexiconServiceResponseParser");
        assertNotNull(service);
        assertEquals(LexiconServiceResponseStAXParserImpl.class, service.getClass());
    }

    public void testGetLexiconServiceRequestGenerator() throws Exception {
        GenericFactory container = AbstractGenericFactory.getInstance();
        ProductServiceRequestGenerator service = (ProductServiceRequestGenerator) container.getBean("lexiconServiceRequestGenerator");
        assertNotNull(service);
        assertEquals(LexiconServiceRequestGeneratorDOMImpl.class, service.getClass());
    }

    public void testGetProductLookupService() throws Exception {
        GenericFactory container = AbstractGenericFactory.getInstance();
        ProductLookupService service = (ProductLookupService) container.getBean("productLookupService");
        assertNotNull(service);
        assertEquals(ProductLookupServiceImpl.class, service.getClass());
    }

    public void testGetMockProductLookupService() throws Exception {
        GenericFactory container = AbstractGenericFactory.getInstance();
        ProductLookupService service = (ProductLookupService) container.getBean("mockProductLookupService");
        assertNotNull(service);
        assertEquals(MockProductLookupService.class, service.getClass());
    }

    public void testGetProductService() throws Exception {
        GenericFactory container = AbstractGenericFactory.getInstance();
        ProductService service = (ProductService) container.getBean("productService");
        assertNotNull(service);
        assertEquals(LexiconProductServiceImpl.class, service.getClass());
    }

    public void testGetLatestRevisionService() throws Exception {
        GenericFactory container = AbstractGenericFactory.getInstance();
        LatestRevisionService service = (LatestRevisionService) container.getBean("latestRevisionService");
        assertNotNull(service);
        assertEquals(LatestRevisionServiceImpl.class, service.getClass());
    }

    public void testGetBatchService() throws Exception {
        GenericFactory container = AbstractGenericFactory.getInstance();
        BatchService service = (BatchService) container.getBean("batchService");
        assertNotNull(service);
        assertEquals(BatchServiceImpl.class, service.getClass());
    }

    public void testGetMockBatchService() throws Exception {
        GenericFactory container = AbstractGenericFactory.getInstance();
        BatchService service = (BatchService) container.getBean("mockBatchService");
        assertNotNull(service);
        assertEquals(MockBatchServiceImpl.class, service.getClass());
    }

    public void testGetNewProductsService() throws Exception {
        GenericFactory container = AbstractGenericFactory.getInstance();
        NewProductService service = (NewProductServiceImpl) container.getBean("newProductsService");
        assertNotNull(service);
        assertEquals(NewProductServiceImpl.class, service.getClass());
    }

  public void testGetPlanQueueService() throws Exception {
      GenericFactory container = AbstractGenericFactory.getInstance();
      PlanService service = (PlanQueueService) container.getBean("planQueueService");
      assertNotNull(service);
      assertEquals(PlanQueueService.class, service.getClass());
  }
}
