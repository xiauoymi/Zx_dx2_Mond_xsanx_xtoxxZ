/*
 NewProductsService was created on Jan 17, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.usseedplanning.services.batchupdate;

import java.util.List;

/**
 * Filename:    $RCSfile: NewProductService.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: vrbethi $    	 On:	$Date: 2007-01-19 17:08:37 $
 *
 * @author vrbethi
 * @version $Revision: 1.1 $
 */
public interface NewProductService {
    void preserveEntries(List productDetailsList);
}