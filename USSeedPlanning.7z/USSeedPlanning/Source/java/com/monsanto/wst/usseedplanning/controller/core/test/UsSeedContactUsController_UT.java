/*
 UsSeedContactUsController_UT was created on Aug 29, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.usseedplanning.controller.core.test;

import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.wst.usseedplanning.controller.core.UsSeedContactUsController;
import com.monsanto.wst.usseedplanning.view.factory.ViewFactory;
import com.monsanto.wst.usseedplanning.view.factory.mock.MockViewFactory;
import com.monsanto.wst.view.test.mock.MockView;
import junit.framework.TestCase;

/**
 * Filename:    $RCSfile: UsSeedContactUsController_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ffbrac $    	 On:	$Date: 2006-08-29 15:18:27 $
 *
 * @author ffbrac
 * @version $Revision: 1.1 $
 */
public class UsSeedContactUsController_UT extends TestCase {
	private MockUCCHelper helper;

	protected void setUp() throws Exception {
	    helper = new MockUCCHelper(null);
	}

	public void testCreate() throws Exception {
	    UsSeedContactUsController controller = new UsSeedContactUsController((ViewFactory)null);
	    assertNotNull(controller);
	}

	public void testRenderViewTomainPage() throws Exception {
	    ViewFactory viewFactory = new MockViewFactory();
	    UsSeedContactUsController controller = new UsSeedContactUsController(viewFactory);
	    controller.run(helper);
	    MockView view = (MockView) viewFactory.getContactUsView();
	    assertTrue(view.wasViewRendered());
	}
}