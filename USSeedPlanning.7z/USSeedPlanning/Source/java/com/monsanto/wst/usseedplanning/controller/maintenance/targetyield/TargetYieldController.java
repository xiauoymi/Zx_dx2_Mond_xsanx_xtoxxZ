/*
 Copyright:  Copyright � 2006 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.usseedplanning.controller.maintenance.targetyield;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.Util.StringUtils;
import com.monsanto.wst.commonutils.DataTypeUtil;
import com.monsanto.wst.servletframework.AbstractDispatchController;
import com.monsanto.wst.usseedplanning.constants.MainConstants;
import com.monsanto.wst.usseedplanning.model.core.LoginUser;
import com.monsanto.wst.usseedplanning.model.maintenance.Gender;
import com.monsanto.wst.usseedplanning.model.maintenance.Revision;
import com.monsanto.wst.usseedplanning.model.maintenance.Year;
import com.monsanto.wst.usseedplanning.model.maintenance.YieldTargetFactor;
import com.monsanto.wst.usseedplanning.services.maintenance.seedEntity.GenderService;
import com.monsanto.wst.usseedplanning.services.maintenance.seedEntity.YearService;
import com.monsanto.wst.usseedplanning.services.maintenance.seedEntity.YieldTargetService;
import com.monsanto.wst.validator.HttpRequestErrors;
import com.monsanto.wst.validator.HttpRequestMessages;

import java.io.IOException;
import java.util.Date;
import java.util.GregorianCalendar;

/**
 * Filename:    $RCSfile: TargetYieldController.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ffbrac $
 * On:	$Date: 2006-10-27 18:26:20 $
 *
 * @author rdesai2
 * @version $Revision: 1.7 $
 */
public class TargetYieldController extends AbstractDispatchController {

  private YearService yearService;
  private YieldTargetService yieldTargetService;
  private GenderService genderService;
  private DataTypeUtil util = new DataTypeUtil();

  public TargetYieldController(YearService yearService, YieldTargetService yieldTargetService,
                               GenderService genderService) {
    this.yearService = yearService;
    this.yieldTargetService = yieldTargetService;
    this.genderService = genderService;
  }

  protected void notSpecified(UCCHelper helper) throws IOException {
  }

  public void saveYieldTargetFactor(UCCHelper helper) throws Exception {
    String modUser = helper.getAuthenticatedUserID();
    Date modDate = new GregorianCalendar().getTime();
    YieldTargetFactor factor = createYieldFactorObject(helper, modUser, modDate);
    repopulateYieldTargetObject(helper, factor);
    populateYearList(helper);
    populateGenderList(helper);
    HttpRequestErrors errors = validateRequiredFields(getEnteredYieldFactor(helper),
        getEnteredFinanceStandFactor(helper));
    if (!errors.isEmpty()) {
      addErrorMessages(errors, "errors", helper);
      forward(helper);
      return;
    }
    yieldTargetService.saveYieldTargetFactor(factor);
    addSuccessMessage(MainConstants.SUCCESS_MSG_YIELD_TARGET_FACTOR_SAVED, "messages", helper);
    disableNonEditableFields(helper);
    forwardSuccess(helper);
  }

  private void disableNonEditableFields(UCCHelper helper) {
    helper.setRequestAttributeValue(MainConstants.HELPER_TARGET_YIELD_EDIT_ACTION_FLAG, "true");
  }

  private void repopulateYieldTargetObject(UCCHelper helper, YieldTargetFactor factor) {
    helper.setRequestAttributeValue(MainConstants.HELPER_PARAM_YIELD_TARGET_FACTOR, factor);
  }

  private YieldTargetFactor createYieldFactorObject(UCCHelper helper, String modUser, Date modDate) throws Exception {
    String productName = helper
        .getRequestParameterValue(MainConstants.HELPER_PARAM_YIELD_TARGET_LIST_PAGE_PRODUCT_NAME);
    String targetYearId = helper.getRequestParameterValue(MainConstants.HELPER_PARAM_YIELD_TARGET_PG_YEAR_ID_STRING);
    String activeStatus = helper.getRequestParameterValue(MainConstants.HELPER_PARAM_YIELD_TARGET_PG_ACTIVE_STATUS);
    String genderId = helper.getRequestParameterValue(MainConstants.HELPER_PARAM_YIELD_TARGET_PG_GENDER_ID_STRING);
    String targetYieldFactor = getEnteredYieldFactor(helper);
    String financeStandFactor = getEnteredFinanceStandFactor(helper);
    String revisionComments = helper
        .getRequestParameterValue(MainConstants.HELPER_PARAM_YIELD_TARGET_PG_REVISION_COMMENT_FACTOR);
    Revision revision = new Revision("Adding Yield Target Factor", revisionComments, new LoginUser(modUser));
    Year targetYear = new Year(util.convertStringToLongIgnoreNumberFormatException(targetYearId), null, null, null,
        null);
    Gender gender = new Gender();
    gender.setId(util.convertStringToLongIgnoreNumberFormatException(genderId));

    return new YieldTargetFactor(revision, productName, targetYear, gender,
        util.convertYNStringIntoBoolean(activeStatus), getFactorAsObject(targetYieldFactor),
        getFactorAsObject(financeStandFactor), modUser, modDate);
  }

  private String getEnteredFinanceStandFactor(UCCHelper helper) throws IOException {
    return helper.getRequestParameterValue(MainConstants.HELPER_PARAM_YIELD_TARGET_PG_FINISHED_STAND_FACTOR);
  }

  private String getEnteredYieldFactor(UCCHelper helper) throws IOException {
    return helper.getRequestParameterValue(MainConstants.HELPER_PARAM_YIELD_TARGET_PG_TARGET_YIELD_FACTOR);
  }

  private Double getFactorAsObject(String targetYieldFactor) {
    try {
      return new Double(targetYieldFactor);
    } catch (Exception e) {
      return null;
    }
  }

  private void addErrorMessages(HttpRequestErrors errors, String errorMessageVariableName, UCCHelper helper) {
    helper.setRequestAttributeValue(errorMessageVariableName, errors);
  }

  private void forward(UCCHelper helper) throws IOException {
    helper.forward(MainConstants.FORWARD_ADD_EDIT_YIELD_TARGET_LIST_PAGE);
  }
  private void forwardSuccess(UCCHelper helper) throws IOException {
      helper.forward(MainConstants.FORWARD_YIELD_TARGET_LIST_PAGE);
  }

  private void populateYearList(UCCHelper helper) {
    helper.setRequestAttributeValue(MainConstants.HELPER_PARAM_YEAR_LOOKUP_LIST, yearService.getActiveYears());
  }

  private void populateGenderList(UCCHelper helper) {
    helper.setRequestAttributeValue(MainConstants.HELPER_PARAM_GENDER_LOOKUP_LIST, genderService.getActiveGenders());
  }


  private void addSuccessMessage(String message, String messageVariableName, UCCHelper helper) {
    HttpRequestMessages messages = new HttpRequestMessages();
    messages.addMessage(message);
    helper.setRequestAttributeValue(messageVariableName, messages);
  }

  private HttpRequestErrors validateRequiredFields(String targetYieldFactor, String financeStandFactor) {
    HttpRequestErrors errors = new HttpRequestErrors();
    if (StringUtils.isNullOrEmpty(targetYieldFactor)) {
      errors.addError(MainConstants.ERROR_KEY_TARGET_YIELD_FACTOR_EMPTY,
          MainConstants.ERROR_MSG_TARGET_YIELD_FACTOR_EMPTY);
    } else {
      try {
        new Double(targetYieldFactor);
      } catch (Exception e) {
        errors.addError(MainConstants.ERROR_KEY_TARGET_YIELD_FACTOR_NOT_NUMBER,
            MainConstants.ERROR_MSG_TARGET_YIELD_FACTOR_NOT_NUMBER);
      }
    }
    if (StringUtils.isNullOrEmpty(financeStandFactor)) {
      errors.addError(MainConstants.ERROR_KEY_FINANCE_STAND_FACTOR_EMPTY,
          MainConstants.ERROR_MSG_FINANCE_STAND_FACTOR_EMPTY);
    } else {
      try {
        new Double(financeStandFactor);
      } catch (Exception e) {
        errors.addError(MainConstants.ERROR_KEY_FINANCE_STAND_FACTOR_NOT_NUMBER,
            MainConstants.ERROR_MSG_FINANCE_STAND_FACTOR_NOT_NUMBER);
      }
    }
    return errors;
  }

}