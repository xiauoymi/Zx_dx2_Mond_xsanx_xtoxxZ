package com.monsanto.wst.usseedplanning.controller.validator;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.wst.validator.HttpRequestErrors;
import com.monsanto.wst.validator.HttpValidator;
import org.apache.commons.lang.StringUtils;

import java.io.IOException;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * Date: Aug 15, 2006
 * Time: 9:59:55 AM
 * <p/>
 * This class is used to validate common forecast requests.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class AddForecastValidator implements HttpValidator {
    public HttpRequestErrors validate(UCCHelper helper) throws IOException {
        HttpRequestErrors errors = new HttpRequestErrors();
        String comments = helper.getRequestParameterValue("comments");
        if (StringUtils.isEmpty(comments)) {
            errors.addError("comment", "The Comment field is required.");
        }
        List fileList = helper.getClientFiles();
        if (fileList.size() == 0) {
            errors.addError("forecastFile", "The File field is required.");
        }
        return errors;
    }
}
