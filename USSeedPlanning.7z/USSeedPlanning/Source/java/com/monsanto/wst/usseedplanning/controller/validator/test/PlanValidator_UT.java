/*
 PlanValidator_UT was created on Oct 19, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.usseedplanning.controller.validator.test;

import junit.framework.TestCase;
import com.monsanto.wst.usseedplanning.controller.validator.PlanValidator;
import com.monsanto.wst.validator.HttpRequestErrors;
import com.monsanto.ServletFramework.Test.MockUCCHelper;

/**
 * Created by IntelliJ IDEA.
 * Date: Aug 15, 2006
 * Time: 9:59:01 AM
 * <p/>
 * Unit test for the CommonForecastValidator object.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class PlanValidator_UT extends TestCase {
    public void testCreate() throws Exception {
        PlanValidator validator = new PlanValidator();
        assertNotNull(validator);
    }

    public void testValidatePass() throws Exception {
        PlanValidator validator = new PlanValidator();
        MockUCCHelper helper = createRequest();
        HttpRequestErrors errors = validator.validate(helper);
        assertTrue(errors.isEmpty());
    }

    //todo delete later .. dont think this is valid anymore
//    public void testValidateFail() throws Exception {
//        PlanValidator validator = new PlanValidator();
//        MockUCCHelper helper = new MockUCCHelper(null);
//        HttpRequestErrors errors = validator.validate(helper);
//        assertFalse(errors.isEmpty());
//        assertEquals("Plan Name should not be left empty.", errors.getError("plan name"));
//    }

    private MockUCCHelper createRequest() {
        MockUCCHelper helper = new MockUCCHelper(null);
        helper.setRequestParameterValue("plan_name", "Test Message");
        return helper;
    }
}