package com.monsanto.wst.usseedplanning.services.cache;

import com.monsanto.wst.usseedplanning.model.cache.ProductCriteria;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * Date: Aug 8, 2006
 * Time: 5:27:38 PM
 * <p/>
 * This interface defines the contract for looking up product information.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public interface ProductLookupService {
    //TODO Why is exception being thrown
    /**
     * This method returns a list of product detail based on the product name and type specified.
     *
     * @param productCriteriaList List representing product criteria.
     * @return List - Representing the product detail.
     */
    List lookupProductDetailByCriteria(List productCriteriaList) throws Exception;

    List lookupProductDetailByCriteria(ProductCriteria productCriteria) throws Exception;

    void registerErrorHandler(ErrorHandler errorHandler);
}