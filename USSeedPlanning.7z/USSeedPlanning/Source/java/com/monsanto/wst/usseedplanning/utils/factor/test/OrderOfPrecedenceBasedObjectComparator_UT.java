/*
 Copyright:  Copyright � 2006 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.usseedplanning.utils.factor.test;

import com.monsanto.wst.usseedplanning.model.maintenance.Gender;
import com.monsanto.wst.usseedplanning.model.maintenance.Year;
import com.monsanto.wst.usseedplanning.model.maintenance.YieldTargetFactor;
import com.monsanto.wst.usseedplanning.utils.factor.OrderOfPrecedenceBasedObjectComparator;
import junit.framework.TestCase;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/**
 * Filename:    $RCSfile: OrderOfPrecedenceBasedObjectComparator_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change:
 * $Author: kjjohn2 $    	 On:	$Date: 2006-12-01 20:25:04 $
 *
 * @author JDPOUL
 * @version $Revision: 1.2 $
 */
public class OrderOfPrecedenceBasedObjectComparator_UT extends TestCase {

  private static final String TARGET_YEAR_FIELD_NAME = "targetYear.id";
  private static final String GENDER_FIELD_NAME = "gender.id";
  private static final String PRODUCT_NAME_FIELD_NAME = "ProductName";


  private static final Map ORDER_OF_PRECEDENCE_MAP = new HashMap();
  private static final Set FIELDS_TO_COMPARE_SET = new HashSet();

  static {
    ORDER_OF_PRECEDENCE_MAP.put(PRODUCT_NAME_FIELD_NAME, new Integer(3));
    ORDER_OF_PRECEDENCE_MAP.put(TARGET_YEAR_FIELD_NAME, new Integer(2));

    FIELDS_TO_COMPARE_SET.add(TARGET_YEAR_FIELD_NAME);
    FIELDS_TO_COMPARE_SET.add(GENDER_FIELD_NAME);
    FIELDS_TO_COMPARE_SET.add(PRODUCT_NAME_FIELD_NAME);

  }

  public static OrderOfPrecedenceBasedObjectComparator COMPARATOR;

  protected void setUp() throws Exception {
    super.setUp();
    COMPARATOR = new OrderOfPrecedenceBasedObjectComparator();
  }


  public OrderOfPrecedenceBasedObjectComparator_UT(String name) {
    super(name);
  }

  public void testCompareObjectFirstObjectNull() {
    try {
      COMPARATOR.setObjectToCompareTo(new Object());
      COMPARATOR.compare(new Object(), null);
      fail("compare with null parameter did not throw IllegalArgumentException.");
    } catch (IllegalArgumentException e) {
      assertEquals(
          "Cannot process input to OrderOfPrecedenceObjectComparator.compare() method.  One or both inputs was null",
          e.getMessage());
    }

  }

  public void testCompareObjectSecondObjectNull() {
    try {
      COMPARATOR.setObjectToCompareTo(new Object());
      COMPARATOR.compare(null, new Object());
      fail("compare with null parameter did not throw IllegalArgumentException.");
    } catch (IllegalArgumentException e) {
      assertEquals(
          "Cannot process input to OrderOfPrecedenceObjectComparator.compare() method.  One or both inputs was null",
          e.getMessage());
    }
  }

  public void testCompareObjectsActualValueObjectNotSet() {
    try {
      COMPARATOR.setObjectToCompareTo(null);
      COMPARATOR.compare(new Object(), new Object());
      fail("compare with no actual values set on the comparator did not throw an IllegalArgumentException.");
    } catch (IllegalArgumentException e) {
      assertEquals("Dimensioned Object to compare to was set to be null.  This is not a valid value.", e.getMessage());
    }
  }

  public void testCompareObjects1FieldSameObjectNoMatch() {
    Object bean = new OneStringFieldBean("testValue");
    Object compareToBean = new OneStringFieldBean("noMatch");
    COMPARATOR.setObjectToCompareTo(compareToBean);
    int value = COMPARATOR.compare(bean, bean);
    assertEquals(0, value);
  }


  public void testCompareObjects1Field2DifferentObjectsWMatchOnOneField() {
    Object bean = new OneStringFieldBean("testValue");
    Object bean2 = new OneStringFieldBean("match");
    Object compareToBean = new OneStringFieldBean("match");

    COMPARATOR.setObjectToCompareTo(compareToBean);
    int value = COMPARATOR.compare(bean2, bean);
    assertTrue(value < 0);
    value = COMPARATOR.compare(bean, bean2);
    assertTrue(value > 0);
  }

  public void testCompareObjects1FieldSameFieldMatching() {
    Object bean = new OneStringFieldBean("testValue");
    Object compareToBean = new OneStringFieldBean("testValue");
    COMPARATOR.setObjectToCompareTo(compareToBean);
    int value = COMPARATOR.compare(bean, bean);
    assertEquals(0, value);
  }

  public void testCompareObjects1FieldValuesNullNoMatch() {
    Object bean = new OneStringFieldBean(null);
    Object compareToBean = new OneStringFieldBean("testValue");
    COMPARATOR.setObjectToCompareTo(compareToBean);
    int value = COMPARATOR.compare(bean, bean);
    assertEquals(0, value);
  }


  public void testCompareObjects1FieldActualValueObjectFieldNullNoMatch() {
    Object bean = new OneStringFieldBean("test");
    Object compareToBean = new OneStringFieldBean(null);
    COMPARATOR.setObjectToCompareTo(compareToBean);
    int value = COMPARATOR.compare(bean, bean);
    assertEquals(0, value);
  }

  public void testSetOrderOfPrecedence() {
    try {
      COMPARATOR.setDimensionComparisonOrderOfPrecedence(new HashMap());
    } catch (Exception e) {
      fail();
    }
  }

  public void testCompareObjects2Fields1ObjectMatching1Field() {
    Object bean = new TwoFieldOneStringOneBooleanBean("test", true);
    Object bean2 = new TwoFieldOneStringOneBooleanBean("test1", false);
    Object compareTo = new TwoFieldOneStringOneBooleanBean("test4", true);

    COMPARATOR.setObjectToCompareTo(compareTo);

    int value = COMPARATOR.compare(bean, bean2);
    assertEquals(0, value);

  }

  public void testCompareObjects2FieldWOrderOfPrecedenceObjectsEvenBecauseEachDoNotMatchOneFieldAndFieldValueNotNull() {
    Object bean = new TwoFieldOneStringOneBooleanBean("bean2", false);
    Object bean1 = new TwoFieldOneStringOneBooleanBean("bean1", true);
    Object compareToObject = new TwoFieldOneStringOneBooleanBean("bean1", false);
    Map precedence = new HashMap();
    precedence.put("StringProp", new Integer(3));
    precedence.put("BooleanProp", new Integer(2));
    COMPARATOR.setDimensionComparisonOrderOfPrecedence(precedence);
    COMPARATOR.setObjectToCompareTo(compareToObject);
    ;

    int value = COMPARATOR.compare(bean, bean1);
    assertEquals(0, value);
  }


  public void testCompareObjects2FieldWOrderOfPrecedenceOneObjectMoreAppropriateBecauseOneMatchesOneFieldAndItsOtherFieldIsNull() {
    Object bean = new TwoFieldOneStringOneBooleanBean(null, false);
    Object bean1 = new TwoFieldOneStringOneBooleanBean("bean1", true);
    Object compareToObject = new TwoFieldOneStringOneBooleanBean("bean1", false);
    Map precedence = new HashMap();
    precedence.put("StringProp", new Integer(3));
    precedence.put("BooleanProp", new Integer(2));
    COMPARATOR.setDimensionComparisonOrderOfPrecedence(precedence);
    COMPARATOR.setObjectToCompareTo(compareToObject);
    ;

    int value = COMPARATOR.compare(bean, bean1);
    assertEquals(-1, value);
    value = COMPARATOR.compare(bean1, bean);
    assertEquals(1, value);
  }


  public void testCompareObjects3FieldsWOrderOfPrecedenceObjectsEvenEachHaveFieldThatDoesntMatch() {
    Object bean = new ThreeFieldStringBooleanLong("test", true, new Long(1));
    Object bean2 = new ThreeFieldStringBooleanLong("test2", true, new Long(5));
    Object compareTo = new ThreeFieldStringBooleanLong("test", true, new Long(5));
    COMPARATOR.setObjectToCompareTo(compareTo);
    Map precedence = new HashMap();
    precedence.put("StringProp", new Integer(4));
    COMPARATOR.setDimensionComparisonOrderOfPrecedence(precedence);

    int value = COMPARATOR.compare(bean, bean2);
    assertEquals(0, value);
  }


  public void testCompareObjects3FieldsWOrderOfPrecedenceObjectsEvenBothHaveFieldsThatMatchOneMatchesHigherOrderOfPrecedence() {
    Object bean = new ThreeFieldStringBooleanLong("test", true, null);
    Object bean2 = new ThreeFieldStringBooleanLong(null, true, new Long(5));
    Object compareTo = new ThreeFieldStringBooleanLong("test", true, new Long(5));
    COMPARATOR.setObjectToCompareTo(compareTo);
    Map precedence = new HashMap();
    precedence.put("StringProp", new Integer(4));
    COMPARATOR.setDimensionComparisonOrderOfPrecedence(precedence);

    int value = COMPARATOR.compare(bean, bean2);
    assertEquals(-1, value);
    value = COMPARATOR.compare(bean2, bean);
    assertEquals(1, value);
  }

  public void testCompareObjects3FieldsWOrderOfPrecedenceFieldsAllNullVsFieldsThatDontMatch() {
    Object bean = new ThreeFieldStringBooleanLong("test", true, new Long(1));
    Object bean2 = new ThreeFieldStringBooleanLong(null, true, null);
    Object compareTo = new ThreeFieldStringBooleanLong("test", true, new Long(5));
    COMPARATOR.setObjectToCompareTo(compareTo);
    Map precedence = new HashMap();
    precedence.put("StringProp", new Integer(4));
    COMPARATOR.setDimensionComparisonOrderOfPrecedence(precedence);

    int value = COMPARATOR.compare(bean, bean2);
    assertEquals(1, value);
    value = COMPARATOR.compare(bean2, bean);
    assertEquals(-1, value);
  }


  public void testCompareObjects3FieldsNoOrderOfPrecedenceBothObjectsEqual2DifferentFieldssMatch() {
    Object bean = new ThreeFieldStringBooleanLong("test", true, null);
    Object bean2 = new ThreeFieldStringBooleanLong(null, true, new Long(5));
    Object compareTo = new ThreeFieldStringBooleanLong("test", true, new Long(5));
    COMPARATOR.setObjectToCompareTo(compareTo);

    int value = COMPARATOR.compare(bean, bean2);
    assertEquals(0, value);
  }


  public void testCompareObjectsWDifferentNumberOfFieldsNoOrderOfPrecedence() {
    Object bean = new ThreeFieldStringBooleanLong("test", true, new Long(5));
    Object bean2 = new TwoFieldOneStringOneBooleanBean("test2", true);
    Object compareTo = new ThreeFieldStringBooleanLong("test", true, new Long(5));
    COMPARATOR.setObjectToCompareTo(compareTo);

    int value = COMPARATOR.compare(bean, bean2);
    assertEquals(-1, value);
    value = COMPARATOR.compare(bean2, bean);
    assertEquals(1, value);

  }


  public void testCompareObjects3FieldsOnly1ToBeCompared() {
    Object bean = new ThreeFieldStringBooleanLong("test", false, new Long(1));
    Object bean2 = new ThreeFieldStringBooleanLong("test2", true, new Long(5));
    Object compareTo = new ThreeFieldStringBooleanLong("test", true, new Long(5));
    COMPARATOR.setObjectToCompareTo(compareTo);
    Set fieldsToCompare = new HashSet();
    fieldsToCompare.add("StringProp");
    COMPARATOR.setFieldNamesToCompare(fieldsToCompare);
    int value = COMPARATOR.compare(bean, bean2);
    assertEquals(-1, value);
    value = COMPARATOR.compare(bean2, bean);
    assertEquals(1, value);
  }


  public void testCompareObjects4FieldsW2OrderOfPrecedenceScoresOneObjectMoreAppropriate() {
    Object bean = new FourFieldStringBooleanLongString("bean1", false, null, null);
    Object bean1 = new FourFieldStringBooleanLongString("bean1", false, new Long(5), null);
    Object compareToObject = new FourFieldStringBooleanLongString("bean1", false, new Long(5), "noMatch");
    Map precedence = new HashMap();
    precedence.put("StringProp", new Integer(4));
    precedence.put("LongProp", new Integer(6));
    COMPARATOR.setDimensionComparisonOrderOfPrecedence(precedence);
    COMPARATOR.setObjectToCompareTo(compareToObject);
    ;

    int value = COMPARATOR.compare(bean1, bean);
    assertEquals(-1, value);
    value = COMPARATOR.compare(bean, bean1);
    assertEquals(1, value);

  }


  public void testCompareObjects4FieldsWOrderOfPrecedenceOneObjectMoreAppropriateWNulls() {
    Object bean = new FourFieldStringBooleanLongString(null, false, null, null);
    Object bean1 = new FourFieldStringBooleanLongString("bean2", true, new Long(5), "bean2String2");
    Object compareToObject = new FourFieldStringBooleanLongString("bean1", false, new Long(2), "noMatch");
    Map precedence = new HashMap();
    precedence.put("StringProp", new Integer(4));
    precedence.put("LongProp", new Integer(6));
    COMPARATOR.setDimensionComparisonOrderOfPrecedence(precedence);
    COMPARATOR.setObjectToCompareTo(compareToObject);
    ;

    int value = COMPARATOR.compare(bean, bean1);
    assertEquals(-1, value);
    value = COMPARATOR.compare(bean1, bean);
    assertEquals(1, value);
  }

  public void testCompareObjects4FieldsWOrderOfPrecedenceOneObjectMoreAppropriateCompareToWNullsLongObjectMatch() {
    Object bean = new FourFieldStringBooleanLongString(null, false, new Long(2), null);
    Object bean1 = new FourFieldStringBooleanLongString(null, false, null, null);
    Object compareToObject = new FourFieldStringBooleanLongString(null, false, new Long(2), null);
    Map precedence = new HashMap();
    precedence.put("StringProp", new Integer(4));
    precedence.put("LongProp", new Integer(6));
    COMPARATOR.setDimensionComparisonOrderOfPrecedence(precedence);
    COMPARATOR.setObjectToCompareTo(compareToObject);
    ;

    int value = COMPARATOR.compare(bean, bean1);
    assertEquals(-1, value);
    value = COMPARATOR.compare(bean1, bean);
    assertEquals(1, value);
  }


  public void testCompareYieldTargetW2OrderOfPrecedenceScoresOneObjectMoreAppropriate() {
    YieldTargetFactor factor1 = new YieldTargetFactor();
    factor1.setTargetYear(new Year(new Long(100), new Integer(2006), "testDesc", Boolean.TRUE, Boolean.FALSE));
    factor1.setGender(new Gender());
    YieldTargetFactor factor2 = new YieldTargetFactor();
    factor2.setTargetYear(new Year());
    factor2.setGender(new Gender());

    YieldTargetFactor compareToObject = new YieldTargetFactor();
    compareToObject.setTargetYear(new Year(new Long(101), new Integer(2006), "testDesc", Boolean.TRUE, Boolean.FALSE));
    compareToObject.setGender(new Gender());
    COMPARATOR.setDimensionComparisonOrderOfPrecedence(ORDER_OF_PRECEDENCE_MAP);
    COMPARATOR.setFieldNamesToCompare(FIELDS_TO_COMPARE_SET);
    COMPARATOR.setObjectToCompareTo(compareToObject);

    int value = COMPARATOR.compare(factor1, factor2);
    assertEquals(1, value);
    value = COMPARATOR.compare(factor2, factor1);
    assertEquals(-1, value);

  }

  public class OneStringFieldBean {
    protected String stringProp;

    public OneStringFieldBean(String stringProp) {
      this.stringProp = stringProp;
    }

    public String getStringProp() {
      return stringProp;
    }
  }

  public class TwoFieldOneStringOneBooleanBean extends OneStringFieldBean {
    protected boolean booleanProp;

    public TwoFieldOneStringOneBooleanBean(String stringProp, boolean booleanProp) {
      super(stringProp);
      this.booleanProp = booleanProp;
    }

    public boolean isBooleanProp() {
      return booleanProp;
    }
  }

  public class ThreeFieldStringBooleanLong extends TwoFieldOneStringOneBooleanBean {
    protected Long longProp;

    public ThreeFieldStringBooleanLong(String stringProp, boolean booleanProp, Long longProp) {
      super(stringProp, booleanProp);
      this.longProp = longProp;
    }

    public Long getLongProp() {
      return longProp;
    }
  }

  public class FourFieldStringBooleanLongString extends ThreeFieldStringBooleanLong {
    private String stringProp2;

    public FourFieldStringBooleanLongString(String stringProp, boolean booleanProp, Long longProp, String stringProp2) {
      super(stringProp, booleanProp, longProp);
      this.stringProp2 = stringProp2;
    }

    public String getStringProp2() {
      return stringProp2;
    }
  }
}