/*
BatchServiceUT was created on Dec 5, 2006 using Monsanto
resources and is the sole property of Monsanto.  Any duplication of the
code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.usseedplanning.services.batchupdate.test;

import com.monsanto.wst.emailtemplate.domain.EmailHeaderInfo;
import com.monsanto.wst.emailtemplate.services.EmailService;
import com.monsanto.wst.usseedplanning.dao.BatchDao;
import com.monsanto.wst.usseedplanning.dao.PlanDao;
import com.monsanto.wst.usseedplanning.dao.mock.MockPlanDao;
import com.monsanto.wst.usseedplanning.model.core.BatchSummary;
import com.monsanto.wst.usseedplanning.model.core.LoginUser;
import com.monsanto.wst.usseedplanning.model.cache.ProductCriteria;
import com.monsanto.wst.usseedplanning.services.batchupdate.BatchService;
import com.monsanto.wst.usseedplanning.services.batchupdate.BatchServiceImpl;
import com.monsanto.wst.usseedplanning.services.batchupdate.CacheUpdater;
import com.monsanto.wst.usseedplanning.services.batchupdate.NewProductService;
import com.monsanto.wst.usseedplanning.services.cache.ProductLookupService;
import com.monsanto.wst.usseedplanning.services.cache.ErrorHandler;
import com.monsanto.wst.usseedplanning.services.cache.mock.MockProductLookupService;
import com.monsanto.wst.usseedplanning.utils.testutils.USSeedPlanningBaseTestCase;

import java.util.ArrayList;
import java.util.List;

/**
 * Filename:    $RCSfile: BatchServiceUT.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: vrbethi $    	 On:	$Date: 2007-03-09 20:28:05 $
 *
 * @author vrbethi
 * @version $Revision: 1.18 $
 */
public class BatchServiceUT extends USSeedPlanningBaseTestCase{

    public void testCreateBatchService() throws Exception {
        BatchService batchService = new BatchServiceImpl((LoginUser)null, (ProductLookupService)null, (BatchDao)null, (PlanDao)null, null, (EmailService)null, null);
        assertNotNull(batchService);
    }

    public void testRunBatch() throws Exception {
        BatchService service = new BatchServiceImpl((LoginUser)null, new MockProductLookupService(), new MockBatchDao(), new MockPlanDao(), new MockCacheUpdate(), new MockEmailService(), new MockNewBatchServiceImpl());
        boolean batchRan = service.runBatch();
        BatchSummary batchSummary = service.getBatchSummary();
        assertTrue(batchRan);
        assertTrue(batchSummary.getNumberOfDeletedProducts()==0);
        assertTrue(batchSummary.getNumberOfAddedOrModifiedProducts()==0);
    }

    public void testRunBatchThrowsException() {
        try{
        BatchService service = new BatchServiceImpl((LoginUser)null, new MockProductLookUpServiceThrowsException(), new MockBatchDao(), new MockPlanDao(), new MockCacheUpdate(), (EmailService)null, null);
        boolean batchRan = service.runBatch();
        assertFalse(batchRan);
        fail("Exception should have been thrown");
        }catch(Exception e){

        }
    }

    public void testSetLoginUser() throws Exception {
        BatchService batchService = new BatchServiceImpl((LoginUser)null, (ProductLookupService)null, (BatchDao)null, (PlanDao)null, null, (EmailService)null, null);
        batchService.setLoginUser(new LoginUser("test"));
        assertNotNull(batchService);

    }

    class MockBatchDao implements BatchDao{

        public List lookUpSupplyDemandProducts() {
            return new ArrayList(0);
        }

        public List lookUpProductDetailsForProvidedName(String name) {
            return null;
        }
    }

    class MockCacheUpdate implements CacheUpdater{

        public void lookUpNewModifiedDeletedProducts(List listOfProductDetails) {
        }

        public void insert(List listOfUpdatedProductDetails) {
        }

        public BatchSummary getBatchSummary() {
            return null;
        }

        public void setBatchSummary(BatchSummary batchSummary) {
        }

        public LoginUser getCurrentUser() {
            return null;
        }

        public void setCurrentUser(LoginUser currentUser) {
        }

        public void removeProduct(List listOfProducts) {
        }

        public void negatePreviousProductsInCommercialForNewProductsInserted(List arrayList) {
        }
    }

    class MockProductLookUpServiceThrowsException implements ProductLookupService {

        public List lookupProductDetailByCriteria(List productCriteriaList) throws Exception {
            throw new Exception();
        }

        public List lookupProductDetailByCriteria(ProductCriteria productCriteria) throws Exception {
            return null;  //To change body of implemented methods use File | Settings | File Templates.
        }

      public void registerErrorHandler(ErrorHandler errorHandler) {
      }
    }

    class MockEmailService implements EmailService{

        public void sendEmail(String templateId, EmailHeaderInfo headerInfo, Object mapping) {
        }
    }

    class MockNewBatchServiceImpl implements NewProductService{

        public void preserveEntries(List productDetailsList) {
        }
    }
}