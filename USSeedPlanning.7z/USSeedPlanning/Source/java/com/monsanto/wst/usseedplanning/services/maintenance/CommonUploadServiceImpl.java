/*
 CommonUploadServiceImpl was created on Oct 9, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.usseedplanning.services.maintenance;

import com.monsanto.wst.dbtemplate.dao.DBTemplateNoResultsException;
import com.monsanto.wst.usseedplanning.constants.MainConstants;
import com.monsanto.wst.usseedplanning.dao.CommonUploadDao;
import com.monsanto.wst.usseedplanning.dao.RevisionDao;
import com.monsanto.wst.usseedplanning.model.core.LoginUser;
import com.monsanto.wst.usseedplanning.model.maintenance.CommonData;
import com.monsanto.wst.usseedplanning.model.maintenance.Revision;
import com.monsanto.wst.usseedplanning.model.planning.ProductNameDetail;
import com.monsanto.wst.usseedplanning.services.core.ImportSpreadsheetService;
import com.monsanto.wst.usseedplanning.utils.CommonUploadConstants;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import java.io.File;
import java.io.IOException;
import java.util.*;

/**
 * Filename:    $RCSfile: CommonUploadServiceImpl.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: uukola $
 * On:	$Date: 2007-02-28 19:49:52 $
 *
 * @author ffbrac
 * @version $Revision: 1.13 $
 */
public class CommonUploadServiceImpl implements CommonUploadService {
  private ImportSpreadsheetService importSpreadsheetService;
  private CommonUploadDao commonUploadDao;
  private RevisionDao revisionDao;
  private static final Log log = LogFactory.getLog(CommonUploadServiceImpl.class);

  public CommonUploadServiceImpl(ImportSpreadsheetService importSpreadsheetService, CommonUploadDao commonUploadDao,
                                 RevisionDao revisionDao) {
    this.importSpreadsheetService = importSpreadsheetService;
    this.commonUploadDao = commonUploadDao;
    this.revisionDao = revisionDao;

  }

  public void addCommonUpload(File spreadsheet, String columnName, LoginUser loginUser, String comments) throws
    IOException {
    List commonUploadList = this.importSpreadsheetService.getCommonUpload(columnName, spreadsheet);
    HashSet commonUploadSet = new HashSet();
    commonUploadSet.addAll(commonUploadList);
    List filteredCommonUploadList = new ArrayList();
    filteredCommonUploadList.addAll(commonUploadSet);
    Revision revision = new Revision(MainConstants.COMMON_UPLOADS_TAB, comments, loginUser);
    Long revision_id = this.revisionDao.insert(revision);
    for (int i = 0; i < filteredCommonUploadList.size(); i++) {
      CommonData commonData = (CommonData) filteredCommonUploadList.get(i);
      commonData.setRevisionId(revision_id);
      commonData.setDate(new Date());
      commonData.setLoginUser(loginUser);
    }
    commonUploadDao.addCommonUploads(filteredCommonUploadList);
    CommonUploadConstants uploadConstants = new CommonUploadConstants();
    addNewPreCommercialNames(loginUser, uploadConstants.getCommonUploadTableName(columnName));
  }

  public List lookupBaseNamesForPCMNameUpdate(String tableName) {
    return this.commonUploadDao.lookupBaseNamesForPCMNameUpdate(tableName);
  }

  public List lookupPCMNamesForManufacturingNames(String tableName) {
    return this.commonUploadDao.lookupPCMNamesForManufacturingNames(tableName);
  }


  public List lookupPCMNamesForCommercialNames(String tableName) {
    return this.commonUploadDao.lookupPCMNamesForCommercialNames(tableName);
  }

  public String lookupHighestRevisionPreCommercialName(String s) {
    return this.commonUploadDao.lookupHighestRevisionPreCommercialName(s);
  }

  public ProductNameDetail getBaseNameDetail(ProductNameDetail productDetail) {
    ProductNameDetail detail = null;
    try {
      detail = this.commonUploadDao.lookupBaseNameDetail(productDetail);
    }
    catch (DBTemplateNoResultsException e) {
      // No match found
    }
    return detail;
  }

  public void addNewPreCommercialNames(LoginUser loginUser, String tableName) {
    try {
      List pcmNames = lookupPCMNamesForCommercialNames(tableName);
      List listToAdd = new ArrayList();
      pcmNames.addAll(lookupPCMNamesForManufacturingNames(tableName));
      Iterator iterator = pcmNames.iterator();
      while (iterator.hasNext()) {
        ProductNameDetail detail = (ProductNameDetail) iterator.next();
        detail.setProductName(detail.getPreCommercialName());
        detail.setTableName(tableName);
        ProductNameDetail existingDetail = getBaseNameDetail(detail);
        if (existingDetail == null) {
          listToAdd.add(detail);
        }
      }
      if (listToAdd == null || listToAdd.size() <= 0) {
        // Nothing to add
        if (log.isWarnEnabled()) {
          log.warn("No new Pre-commercial Name updates were found for table " + tableName + ".");
        }
        return;
      }
      Revision revision = setRevision(loginUser);
      this.commonUploadDao.addPreCommercialNames(listToAdd, revision, tableName);
      if (log.isWarnEnabled()) {
        log.warn(listToAdd.size() + " Pre-commercial Name updates were made to " + tableName + ".");
      }
    }
    catch (Exception ex) {
      if (log.isWarnEnabled()) {
        log.warn("No new Pre-commercial Name updates were added for table " + tableName + ".", ex);
      }
    }
  }

  public void addPreCommercialNamesForManufacturingNames(LoginUser loginUser, String tableName) {
    List pcmNameList = this.commonUploadDao.lookupPCMNamesForManufacturingNames(tableName);
    addPreCommercialNames(pcmNameList, loginUser, tableName);
  }

  public void addPreCommercialNamesForCommercialNames(LoginUser loginUser, String tableName) {
    List pcmNameList = this.commonUploadDao.lookupPCMNamesForCommercialNames(tableName);
    addPreCommercialNames(pcmNameList, loginUser, tableName);
  }

  public void addPreCommercialNames(List pcmNameList, LoginUser loginUser, String tableName) {

    if (pcmNameList == null || pcmNameList.size() <= 0) {
      // Nothing to add
      // logged higher up
      return;
    }
    Revision revision = setRevision(loginUser);
    this.commonUploadDao.addPreCommercialNames(pcmNameList, revision, tableName);
  }


  private Revision setRevision(LoginUser loginUser) {
    Revision revision = new Revision("PCM NAME BATCH INSERT", "PCM BATCH", loginUser);
    Long revisionId = this.revisionDao.insert(revision);
    revision.setId(revisionId);
    return revision;
  }


  public void resolvePreCommercialNames(LoginUser loginUser) {
    try {
      CommonUploadConstants uploadConstants = new CommonUploadConstants();
      HashMap map = (HashMap) uploadConstants.getCommonUploadTables();
      Set set = map.keySet();
      Iterator iterator = set.iterator();
      while (iterator.hasNext()) {
        String tableKey = (String) iterator.next();
        addNewPreCommercialNames(loginUser, uploadConstants.getCommonUploadTableName(tableKey));
      }
    }
    catch (Exception e) {
      if (log.isWarnEnabled()) {
        log.warn(" No new Pre-commercial Names were added by common upload pre-commercial name updates batch" + ".", e);
      }
    }
  }


}