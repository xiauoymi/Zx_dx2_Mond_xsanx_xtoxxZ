package com.monsanto.wst.usseedplanning.utils.testutils;

import com.monsanto.wst.commonutils.reflection.ObjectInspector;
import com.monsanto.wst.usseedplanning.constants.MainConstants;
import junit.framework.TestCase;

/**
 * Created by IntelliJ IDEA.
 * Date: Feb 11, 2007
 * Time: 7:11:33 PM
 * <p/>
 * TODO: Enter description for class.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public abstract class TempBaseTestCase extends TestCase {
    private TempTestUtils testUtils;

    /**
     * Sets up the environment.
     *
     * @throws Exception - If unable to setup the environment.
     */
    protected void setUp() throws Exception {
        super.setUp();
        testUtils = new TempTestUtils(new ObjectInspector());
        testUtils.setupContainer();
        testUtils.setupLogging(MainConstants.APPLICATION_NAME);
    }

    /**
     * Tears down the environment.
     *
     * @throws Exception - If unable to tear down the environment.
     */
    protected void tearDown() throws Exception {
        testUtils.tearDownLogging();
        testUtils.tearDownContainer();
        super.tearDown();
    }

    /**
     * Returns the test utils object.
     *
     * @return TempTestUtils - Object containing test utility methods.
     */
    protected TempTestUtils getTestUtils() {
        return testUtils;
    }
}
