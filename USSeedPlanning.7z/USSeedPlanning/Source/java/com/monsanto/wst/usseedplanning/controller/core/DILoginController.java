package com.monsanto.wst.usseedplanning.controller.core;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.wst.emailtemplate.domain.EmailHeaderInfo;
import com.monsanto.wst.emailtemplate.services.EmailService;
import com.monsanto.wst.factory.GenericFactory;
import com.monsanto.wst.servletframework.DITransactionalController;
import com.monsanto.wst.usseedplanning.constants.MainConstants;
import com.monsanto.wst.usseedplanning.model.core.LoginUser;
import com.monsanto.wst.usseedplanning.model.core.Role;
import com.monsanto.wst.usseedplanning.services.core.LoginService;
import com.monsanto.wst.usseedplanning.utils.transaction.TransactionUtils;
import com.monsanto.wst.view.View;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.Enumeration;
import java.util.List;

/**
 * Created by IntelliJ IDEA. User: rgeorge Date: Aug 3, 2006 Time: 1:43:35 PM To change this template use File |
 * Settings | File Templates.
 */
public class DILoginController extends DITransactionalController {
    private static final Log log = LogFactory.getLog(DILoginController.class);

    public void run(UCCHelper helper) throws IOException {
        helper.setMaxImportFileSize(1024 * 1024 * 1024);
        GenericFactory container = getApplicationContext(helper);
        initializeTransactionManager(helper);
        cacheSecurityProxy(container, helper);
        LoginService loginService = (LoginService) container.getBean("loginService");
        LoginUser currentUser = (LoginUser) helper.getSessionParameter(MainConstants.LOGINUSER);
        if (currentUser != null || loginService.isAuthorized(helper.getAuthenticatedUserID())) {
            cacheCurrentUser(container, helper, currentUser);
            runTargetController(helper, container);
        } else {
            View unauthorizedView = (View) container.getBean("errorPage");
            unauthorizedView.renderView(helper);
        }
    }

    private void cacheCurrentUser(GenericFactory container, UCCHelper helper, LoginUser currentUser) {
        LoginService loginService = (LoginService) container.getBean("loginService");
        if (currentUser == null) {
            currentUser = loginService.lookupUserById(helper.getAuthenticatedUserID());
            helper.setSessionParameter(MainConstants.LOGINUSER, currentUser);
        }
    }

    private void initializeTransactionManager(UCCHelper helper) {
        getTransactionManager(helper);
    }

    private void cacheSecurityProxy(GenericFactory container, UCCHelper helper) {
        container.addBean("systemSecurityProxy", helper.getSystemSecurityProxy(), false);
    }

    private void runTargetController(UCCHelper helper, GenericFactory container) {
        try {
            super.run(helper);
        } catch (Throwable ex) {
            logError(container, helper, ex);
            handleError(helper, container);
        }
    }

    /**
     * This method converts the stack trace of the specified error into a string and returns it.
     *
     * @param t Throwable object representing the error.
     *
     * @return String - Representing the stack trace.
     */
    private String getStackTraceAsString(Throwable t) {
        StringWriter sw = new StringWriter();
        t.printStackTrace(new PrintWriter(sw));
        return sw.toString();
    }

    private void handleError(UCCHelper helper, GenericFactory container) {
        new TransactionUtils(helper).flagForRollback();
        View view = (View) container.getBean("allExceptionsView");
        view.renderView(helper);
    }

    /**
     * This method logs the error along with some additional information.
     *
     * @param container
     * @param helper UCCHelper object containing the request and the response.


     @param cause  Throwable object representing the exception that occurred.

     */
    private void logError(GenericFactory container, UCCHelper helper, Throwable cause) {
        StringBuffer sb = new StringBuffer("\nAn Unhandled exception was thrown.\n\n");
        sb.append("Environment = '").append(System.getProperty("lsi.function")).append("'\n");
        sb.append("Requested URL = '").append(helper.requestedURL()).append("'\n");
        LoginUser currentUser = (LoginUser) helper.getSessionParameter(MainConstants.LOGINUSER);
        sb.append("Username: '").append(currentUser.getFullName()).append("'\n");
        sb.append("User Id: '").append(helper.getAuthenticatedUserID()).append("'\n");
        sb.append("Parameters passed into the page:\n");
        appendRequestParameters(helper, sb);
        sb.append("\nStack Trace Info:\n");
        sb.append(getStackTraceAsString(cause));
        if (log.isErrorEnabled()) {
            log.error(sb.toString());
        }
        sendErrorNotificationEmail(container, sb.toString());
    }

    private void sendErrorNotificationEmail(GenericFactory container, String message) {
        LoginService loginService = (LoginService) container.getBean("loginService");
        EmailService emailService = (EmailService) container.getBean("emailService");
        List adminList = loginService.lookupUsersByRole(Role.ADMIN_ROLE);
        EmailHeaderInfo headerInfo = new EmailHeaderInfo(null, "usseedplanning@monsanto.com", "A user experience an unexpected error");
        for (int i = 0; i < adminList.size(); i++) {
            LoginUser admin = (LoginUser) adminList.get(i);
            headerInfo.addToEmailAddress(admin.getEmail());
        }
        emailService.sendEmail("unexpectedErrorEmail", headerInfo, message.toString());
    }

    /**
     * This method appends any request parameters to the message to be logged.
     *
     * @param helper UCCHelper object containing the request and the response.
     * @param sb     StringBuffer representing the message to be logged.
     */
    private void appendRequestParameters(UCCHelper helper, StringBuffer sb) {
        try {
            for (Enumeration params = helper.getParameterNames(); params.hasMoreElements();) {
                String paramName = (String) params.nextElement();
                String paramValue = helper.getRequestParameterValue(paramName);
                sb.append("  '").append(paramName).append("' = '").append(paramValue).append("'\n");
            }
        } catch (Throwable e) {
        }
    }

}
