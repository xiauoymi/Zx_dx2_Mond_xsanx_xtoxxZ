package com.monsanto.wst.usseedplanning.services.maintenance.supply;

import java.io.File;

/**
 * Created by IntelliJ IDEA.
 * Date: Aug 16, 2006
 * Time: 3:36:18 PM
 * <p/>
 * This interface defines the contract for retrieving supply files.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public interface SupplyFileLookupService {
    /**
     * This method returns the current ATP Supply file.
     *
     * @return File - Object representing the file.
     */
    File lookupATPSupplyFile();
}
