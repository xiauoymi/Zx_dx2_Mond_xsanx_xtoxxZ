/*
 MockStageService was created on Sep 18, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.usseedplanning.services.maintenance.seedEntity.mock;

import com.monsanto.wst.usseedplanning.services.maintenance.seedEntity.StageService;
import com.monsanto.wst.usseedplanning.model.maintenance.Stage;

import java.util.List;
import java.util.ArrayList;

/**
 * Filename:    $RCSfile: MockStageService.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: SSPATI1 $    	 On:	$Date: 2006-09-19 21:13:35 $
 *
 * @author sspati1
 * @version $Revision: 1.2 $
 */
public class MockStageService implements StageService {
  public List lookupAllStages() {
    Stage stage = null;
    List list = new ArrayList();
    stage = new Stage();
    stage.setStageId(new Long(123));
    stage.setDescription("test1");
    list.add(stage);
    stage = new Stage();
    stage.setStageId(new Long(123));
    stage.setDescription("test2");
    list.add(stage);
    return list;
  }

  public Stage lookupStageById(Long stageId) {
    Stage stage = new Stage();
    stage.setStageId(new Long(123));
    stage.setStage("test stage");
    return stage;
  }
}