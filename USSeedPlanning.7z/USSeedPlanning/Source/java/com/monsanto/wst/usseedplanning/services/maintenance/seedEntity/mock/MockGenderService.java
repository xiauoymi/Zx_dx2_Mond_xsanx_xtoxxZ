/*
 Copyright:  Copyright � 2006 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.usseedplanning.services.maintenance.seedEntity.mock;

import com.monsanto.wst.usseedplanning.services.maintenance.seedEntity.GenderService;
import com.monsanto.wst.usseedplanning.model.maintenance.Gender;

import java.util.List;
import java.util.ArrayList;

/**
 * Filename:    $RCSfile: MockGenderService.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: jdpoul $    	 On:	$Date: 2006-09-26 19:40:26 $
 *
 * @author jdpoul
 * @version $Revision: 1.2 $
 */
public class MockGenderService implements GenderService {
  private List genders = new ArrayList();
  public List getActiveGenders() {
    return genders;
  }

  public void insert(Gender gender){
    genders.add(gender);
  }
}