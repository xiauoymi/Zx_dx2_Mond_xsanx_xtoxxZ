package com.monsanto.wst.usseedplanning.services.maintenance.supply;

import com.monsanto.wst.usseedplanning.dao.*;
import com.monsanto.wst.usseedplanning.exception.NoResultsException;
import com.monsanto.wst.usseedplanning.model.core.LoginUser;
import com.monsanto.wst.usseedplanning.model.maintenance.Channel;
import com.monsanto.wst.usseedplanning.model.maintenance.ChannelCriteria;
import com.monsanto.wst.usseedplanning.model.maintenance.Revision;
import com.monsanto.wst.usseedplanning.model.maintenance.Year;
import com.monsanto.wst.usseedplanning.model.maintenance.supply.Supply;
import com.monsanto.wst.usseedplanning.model.maintenance.supply.SupplyType;
import com.monsanto.wst.usseedplanning.services.core.ImportSpreadsheetService;

import java.io.File;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;

/**
 * Created by IntelliJ IDEA. Date: Feb 12, 2007 Time: 3:34:32 PM <p/> TODO: Enter description for class.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class YATPFNDUpdateSupplyService extends AbstractUpdateSupplyService {
  private ImportSpreadsheetService importSpreadsheetService;
  private SupplyDao supplyDao;
  private ChannelDao channelDao;
  private YearDao yearDao;

  public YATPFNDUpdateSupplyService(ImportSpreadsheetService importSpreadsheetService, SupplyDao supplyDao,
                                    SupplyTypeDao supplyTypeDao, RevisionDao revisionDao, ChannelDao channelDao,
                                    YearDao yearDao) {
    super(supplyTypeDao, revisionDao, channelDao);
    this.importSpreadsheetService = importSpreadsheetService;
    this.supplyDao = supplyDao;
    this.channelDao = channelDao;
    this.yearDao = yearDao;
  }

  public void updateSupply(File file, String comments, LoginUser owner, Long planType) throws IOException {
    List supplyList = this.importSpreadsheetService.getATPSupply(file);
    //supplyList = removeBatchRows(supplyList);
    updateBatchRows(supplyList);
    Revision revision = createRevision(comments, owner, "Adding ATP Supply.");
    Channel defaultChannel = getChannel(planType, Channel.DEFAULT_CHANNEL);
    Year currentYear = this.yearDao.lookupCurrentYear();
    SupplyType supplyType = lookupSupplyType(SupplyType.ATP_SUPPLY_TYPE);
    setSupplyInfo(supplyList, currentYear, owner, revision, supplyType, defaultChannel, planType);
    this.supplyDao.addSupply(supplyList);
  }

  private void setSupplyInfo(List supplyList, Year currentYear, LoginUser owner, Revision revision,
                             SupplyType supplyType, Channel defaultChannel, Long planType) {
    for (int i = 0; i < supplyList.size(); i++) {
      Supply supply = (Supply) supplyList.get(i);
      supply.setYear(currentYear);
      supply.setOwner(owner);
      supply.setRevision(revision);
      supply.setSupplyType(supplyType);
      resolveChannel(supply, defaultChannel, planType);
    }
  }

  private void resolveChannel(Supply supply, Channel defaultChannel, Long planType) {
    try {
      ChannelCriteria criteria = new ChannelCriteria(supply.getIdentifiers().getSLOC(), planType);
      supply.getIdentifiers().setChannel(this.channelDao.lookupChannelByName(criteria));
    }
    catch (NoResultsException e) {
      supply.getIdentifiers().setChannel(defaultChannel);
    }
  }

//    private List removeBatchRows(List supplyList) {
//        List summarySupplyList = new ArrayList();
//        Iterator iterator = supplyList.iterator();
//        while(iterator.hasNext()){
//            Supply supply = (Supply) iterator.next();
//            if(supply.getIdentifiers().getSLOC().indexOf("*")==0){
//                summarySupplyList.add(supply);
//            }
//        }
//        return summarySupplyList;
//    }

  private void updateBatchRows(List supplyList) {
    Iterator iterator = supplyList.iterator();
    while (iterator.hasNext()) {
      Supply supply = (Supply) iterator.next();
      if (!(supply.getIdentifiers().getSLOC().indexOf("*") == 0)) {
        setAvailableToPromiseData(supply);
      }
    }
  }

  private void setAvailableToPromiseData(Supply supply) {
    if (supply.getData() == null || supply.getData().getMVK() == null
      || supply.getData().getMVK().getCustomerDelivery() == null) {
      return;
    }
    Double customerDelivery = supply.getData().getMVK().getCustomerDelivery();
    supply.getData().getMVK().setAtp(customerDelivery);
    removeRedundantData(supply);
  }

  private void removeRedundantData(Supply supply) {
    supply.getData().getMVK().setCustomerDelivery(new Double(0.0));
    supply.getData().getMVK().setUnrestricted(new Double(0.0));
    supply.getData().getMVK().setRestricted(new Double(0.0));
    supply.getData().getMVK().setBlocked(new Double(0.0));
    supply.getData().getMVK().setSalesOrder(new Double(0.0));
    supply.getData().getMVK().setStockTransfers(new Double(0.0));
  }
}
