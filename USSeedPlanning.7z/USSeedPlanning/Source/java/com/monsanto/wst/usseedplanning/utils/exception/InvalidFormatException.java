package com.monsanto.wst.usseedplanning.utils.exception;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Aug 4, 2006
 * Time: 9:21:47 AM
 * To change this template use File | Settings | File Templates.
 */
public class InvalidFormatException extends Exception {

    public InvalidFormatException(String errorMessage) {
        super(errorMessage);
    }
}
