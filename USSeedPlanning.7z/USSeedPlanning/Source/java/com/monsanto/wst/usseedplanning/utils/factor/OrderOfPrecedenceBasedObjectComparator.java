/*
 Copyright:  Copyright � 2006 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.usseedplanning.utils.factor;

import com.monsanto.wst.commonutils.reflection.ObjectInspector;

import java.util.*;

/**
 * Filename:    $RCSfile: OrderOfPrecedenceBasedObjectComparator.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: jdpoul $    	 On:	$Date: 2006-09-28 19:08:16 $
 *
 * @author JDPOUL
 * @version $Revision: 1.1 $
 */
public class OrderOfPrecedenceBasedObjectComparator implements Comparator {
  private Object compareToObject;
  private Map dimensionKeysToPrecedenceScore;
  private ObjectInspector inspector;
  private Set fieldNamesToCompare;

  public OrderOfPrecedenceBasedObjectComparator() {
    this.inspector = new ObjectInspector();
  }

  public int compare(Object o1, Object o2) {
    validateCompareInputs(o1, o2);

    Map compareToFieldsMap = null;
    Map object1FieldsMap = null;
    Map object2FieldsMap = null;

    try {
      compareToFieldsMap = inspector.getPropertyFieldtoValueMap(compareToObject, fieldNamesToCompare, true);
      object1FieldsMap = inspector.getPropertyFieldtoValueMap(o1, fieldNamesToCompare, true);
      object2FieldsMap = inspector.getPropertyFieldtoValueMap(o2, fieldNamesToCompare, true);
    } catch (Exception e) {
      throw new ClassCastException("The objects passed into the comparator were not comparable, or the compareTo object was not able to be compared to the two objects." + e.getMessage());
    }

    Set keys= compareToFieldsMap.keySet();


    int dimensionedObject1Score = 0;
    int dimensionedObject2Score = 0;

    boolean factor1Disqualified = false;
    boolean factor2Disqualified = false;

    for (Iterator keyIter = keys.iterator(); keyIter.hasNext();) {

      Object key = keyIter.next();

      Object actualValue = compareToFieldsMap.get(key);
      Object factor1DimValue = object1FieldsMap.get(key);
      Object factor2DimValue = object2FieldsMap.get(key);

      if(areDimValuesNotEqualAndFactorValueNotNull(actualValue, factor1DimValue)){
        factor1Disqualified = true;
      }

      if(areDimValuesNotEqualAndFactorValueNotNull(actualValue, factor2DimValue)){
        factor2Disqualified = true;
      }

      int dimensionValueComparisonResult = determineBestDimensionValueMatch(factor1DimValue, factor2DimValue, actualValue);
      if (dimensionValueComparisonResult < 0) {
        dimensionedObject1Score = incrementScoreForOrderOfPrecedence(key, dimensionedObject1Score);
      } else if (dimensionValueComparisonResult > 0) {
        dimensionedObject2Score = incrementScoreForOrderOfPrecedence(key, dimensionedObject2Score);
      }
    }
    return determineBestMatchDimensionedObject(dimensionedObject1Score, dimensionedObject2Score, factor1Disqualified, factor2Disqualified);

  }

  public void setFieldNamesToCompare(Set fieldNamesToCompare) {
    this.fieldNamesToCompare = fieldNamesToCompare;
  }

  public void setObjectToCompareTo(Object compareToObject) {
    this.compareToObject = compareToObject;
  }

  public void setDimensionComparisonOrderOfPrecedence(Map dimensionKeysToPrecedenceScore) {
    this.dimensionKeysToPrecedenceScore = dimensionKeysToPrecedenceScore;
  }

  private int determineBestMatchDimensionedObject(int dimensionedObject1Score, int dimensionedObject2Score, boolean factor1Disqualified, boolean factor2Disqualified) {
    if(factor1Disqualified && factor2Disqualified){
      return 0;
    }else if(factor1Disqualified){
      return 1;
    }else if(factor2Disqualified){
      return -1;
    }

    if (dimensionedObject1Score > dimensionedObject2Score) {
      return -1;
    } else if (dimensionedObject1Score < dimensionedObject2Score) {
      return 1;
    } else {
      return 0;
    }
  }


  private int incrementScoreForOrderOfPrecedence(Object key, int score) {
    score = score + getOrderOfPrecedenceScore(key);
    return score;
  }

  private void validateCompareInputs(Object o1, Object o2) {
    /*    validate input parameters.*/
    if (compareToObject == null) {
      throw new IllegalArgumentException("Dimensioned Object to compare to was set to be null.  This is not a valid value.");
    }

    if(o1 == null || o2 == null){
      throw new IllegalArgumentException("Cannot process input to OrderOfPrecedenceObjectComparator.compare() method.  One or both inputs was null");
    }
  }


  private int determineBestDimensionValueMatch(Object dimensionValue1, Object dimensionValue2, Object compareToValue) {
    if ((areDimValuesEqual(dimensionValue1, compareToValue) && areDimValuesEqual(dimensionValue2, compareToValue))) {
      return 0;
    } else if (areDimValuesEqual(dimensionValue1, compareToValue)) {
      return -1;
    } else if (areDimValuesEqual(dimensionValue2, compareToValue)) {
      return 1;
    } else{
      return 0;
    }
  }

  private boolean areDimValuesNotEqualAndFactorValueNotNull(Object value, Object factorValue){
    return !(areDimValuesEqual(factorValue, value)) && factorValue!=null;
  }

  private boolean areDimValuesEqual(Object dimValue1, Object dimValue2) {
    return dimValue1 == dimValue2 || (dimValue1 != null && dimValue1.equals(dimValue2));
  }

  private int getOrderOfPrecedenceScore(Object dimKey) {

    if (dimensionKeysToPrecedenceScore != null) {
      Object scoreObject = dimensionKeysToPrecedenceScore.get(dimKey);
      if (scoreObject != null) {
        return ((Integer) scoreObject).intValue();
      }
    }
    return 1;
  }


}