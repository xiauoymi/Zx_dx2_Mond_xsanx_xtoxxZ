package com.monsanto.wst.usseedplanning.services.maintenance.test;

import com.monsanto.wst.commonutils.resources.ResourceUtils;
import com.monsanto.wst.commonutils.xml.XMLParserException;
import com.monsanto.wst.commonutils.xml.XMLUtilities;
import com.monsanto.wst.commonutils.xml.XalanXPathUtils;
import com.monsanto.wst.usseedplanning.dao.mock.MockCommonUploadDao;
import com.monsanto.wst.usseedplanning.dao.mock.MockRevisionDao;
import com.monsanto.wst.usseedplanning.model.core.LoginUser;
import com.monsanto.wst.usseedplanning.model.planning.ProductNameDetail;
import com.monsanto.wst.usseedplanning.services.core.mock.MockImportSpreadsheetService;
import com.monsanto.wst.usseedplanning.services.maintenance.CommonUploadServiceImpl;
import com.monsanto.wst.usseedplanning.utils.testutils.USSeedPlanningBaseTestCase;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA. Date: Nov 28, 2006 Time: 10:23:03 AM <p/> Unit tests for Common Upload Services
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class CommonUploadServiceImpl_UT extends USSeedPlanningBaseTestCase {
  public void testAddCommonUploadAddsUniqueProductNames() throws Exception {
    MockImportSpreadsheetService importSpreadsheetService = new MockImportSpreadsheetService();
    MockCommonUploadDao commonUploadDao = new MockCommonUploadDao();
    MockRevisionDao revisionDao = new MockRevisionDao();
    CommonUploadServiceImpl commonUploadService = new CommonUploadServiceImpl(importSpreadsheetService, commonUploadDao,
      revisionDao);
    commonUploadService.addCommonUpload(null, null, null, null);
    assertEquals(1, commonUploadDao.getAddedCommonData().size());
  }

  public void testLookupBaseNameForPCMNameUpdate() throws Exception {
    MockImportSpreadsheetService importSpreadsheetService = new MockImportSpreadsheetService();
    MockCommonUploadDao commonUploadDao = new MockCommonUploadDao();
    MockRevisionDao revisionDao = new MockRevisionDao();
    CommonUploadServiceImpl commonUploadService = new CommonUploadServiceImpl(importSpreadsheetService, commonUploadDao,
      revisionDao);
    List baseNames = commonUploadService.lookupBaseNamesForPCMNameUpdate("BASE_NAME");
    assertNotNull(baseNames);
    assertTrue(baseNames.size() > 0);
  }

  public void testGetBaseNameDetail() throws Exception {
    MockImportSpreadsheetService importSpreadsheetService = new MockImportSpreadsheetService();
    MockCommonUploadDao commonUploadDao = new MockCommonUploadDao();
    MockRevisionDao revisionDao = new MockRevisionDao();
    CommonUploadServiceImpl commonUploadService = new CommonUploadServiceImpl(importSpreadsheetService, commonUploadDao,
      revisionDao);
    ProductNameDetail detailParam = new ProductNameDetail("test-a", "DKC-7777A", null, new Integer(3007), null);
    detailParam.setTableName("BASE_NAME");
    ProductNameDetail detail = commonUploadService.getBaseNameDetail(detailParam);
    assertTrue(commonUploadDao.wasLookupBaseNameDetailCalled());
  }


  public void testLookupPCMNamesForManufacturingNames() throws Exception {
    MockImportSpreadsheetService importSpreadsheetService = new MockImportSpreadsheetService();
    MockCommonUploadDao commonUploadDao = new MockCommonUploadDao();
    MockRevisionDao revisionDao = new MockRevisionDao();
    CommonUploadServiceImpl commonUploadService = new CommonUploadServiceImpl(importSpreadsheetService, commonUploadDao,
      revisionDao);
    List pcmNames = commonUploadService.lookupPCMNamesForManufacturingNames("BASE_NAME");
    assertNotNull(pcmNames);
    assertTrue(pcmNames.size() > 0);
  }

  public void testLookupPCMNamesForCommercialNames() throws Exception {
    MockImportSpreadsheetService importSpreadsheetService = new MockImportSpreadsheetService();
    MockCommonUploadDao commonUploadDao = new MockCommonUploadDao();
    MockRevisionDao revisionDao = new MockRevisionDao();
    CommonUploadServiceImpl commonUploadService = new CommonUploadServiceImpl(importSpreadsheetService, commonUploadDao,
      revisionDao);
    List pcmNames = commonUploadService.lookupPCMNamesForCommercialNames("BASE_NAME");
    assertNotNull(pcmNames);
    assertTrue(pcmNames.size() > 0);
  }


  public void testLookupHighestRevisionPreCommercialName() throws Exception {
    MockImportSpreadsheetService importSpreadsheetService = new MockImportSpreadsheetService();
    MockCommonUploadDao commonUploadDao = new MockCommonUploadDao();
    MockRevisionDao revisionDao = new MockRevisionDao();
    CommonUploadServiceImpl commonUploadService = new CommonUploadServiceImpl(importSpreadsheetService, commonUploadDao,
      revisionDao);
    String pcmName = commonUploadService.lookupHighestRevisionPreCommercialName("DK687");
    assertNotNull(pcmName);
    assertEquals("EXP569", pcmName);
  }

  public void testAddPreCommercialNamesForManufacturingNames() throws Exception {
    MockImportSpreadsheetService importSpreadsheetService = new MockImportSpreadsheetService();
    MockCommonUploadDao commonUploadDao = new MockCommonUploadDao();
    MockRevisionDao revisionDao = new MockRevisionDao();
    CommonUploadServiceImpl commonUploadService = new CommonUploadServiceImpl(importSpreadsheetService, commonUploadDao,
      revisionDao);
    commonUploadService.addPreCommercialNamesForManufacturingNames(new LoginUser("UUKOLA"), "BASE_NAME");
    assertTrue(commonUploadDao.wasPreCommercialNamesListAdded());
  }

  public void testAddPreCommercialNamesForCommercialNames() throws Exception {
    MockImportSpreadsheetService importSpreadsheetService = new MockImportSpreadsheetService();
    MockCommonUploadDao commonUploadDao = new MockCommonUploadDao();
    MockRevisionDao revisionDao = new MockRevisionDao();
    CommonUploadServiceImpl commonUploadService = new CommonUploadServiceImpl(importSpreadsheetService, commonUploadDao,
      revisionDao);
    commonUploadService.addPreCommercialNamesForCommercialNames(new LoginUser("UUKOLA"), "BASE_NAME");
    assertTrue(commonUploadDao.wasPreCommercialNamesListAdded());
  }

  public void testAddPreCommercialNames() throws Exception {
    MockImportSpreadsheetService importSpreadsheetService = new MockImportSpreadsheetService();
    MockCommonUploadDao commonUploadDao = new MockCommonUploadDao();
    MockRevisionDao revisionDao = new MockRevisionDao();
    CommonUploadServiceImpl commonUploadService = new CommonUploadServiceImpl(importSpreadsheetService, commonUploadDao,
      revisionDao);
    List nameList = new ArrayList();
    nameList.add(new ProductNameDetail("DK7777", "DKC-7777A", "test-a", new Integer(3007)));
    nameList.add(new ProductNameDetail("test-a", "DKC-7777A", "HCF1171", new Integer(3007)));
    nameList.add(new ProductNameDetail("test-a", "DKC-7777A", "PCF0010", new Integer(2007)));
    commonUploadService.addPreCommercialNames(nameList, new LoginUser("UUKOLA"), "BASE_NAME");
    assertTrue(commonUploadDao.wasPreCommercialNamesListAdded());
  }


  public void testAddNewPreCommercialNames() throws Exception {
    MockImportSpreadsheetService importSpreadsheetService = new MockImportSpreadsheetService();
    MockCommonUploadDao commonUploadDao = new MockCommonUploadDao();
    MockRevisionDao revisionDao = new MockRevisionDao();
    CommonUploadServiceImpl commonUploadService = new CommonUploadServiceImpl(importSpreadsheetService, commonUploadDao,
      revisionDao);
    commonUploadService.addNewPreCommercialNames(new LoginUser("UUKOLA"), "BASE_NAME");
    assertTrue(commonUploadDao.wasPreCommercialNamesListAdded());
  }


  public void testResolvePreCommercialNames() throws Exception {
    MockImportSpreadsheetService importSpreadsheetService = new MockImportSpreadsheetService();
    MockCommonUploadDao commonUploadDao = new MockCommonUploadDao();
    MockRevisionDao revisionDao = new MockRevisionDao();
    CommonUploadServiceImpl commonUploadService = new CommonUploadServiceImpl(importSpreadsheetService, commonUploadDao,
      revisionDao);
    commonUploadService.resolvePreCommercialNames(new LoginUser("UUKOLA"));
    assertTrue(commonUploadDao.wasPreCommercialNamesListAdded());
  }

  public void testGetCommonUploadTableNames() {
    ArrayList tableNameList = new ArrayList();
    String docPath = "com/monsanto/wst/usseedplanning/services/maintenance/test/fileTemplateTest.xml";
    XMLUtilities xmlUtilities = new XMLUtilities(new ResourceUtils());
    try {
      Document doc = xmlUtilities.createDocument(docPath);
      XalanXPathUtils utils = new XalanXPathUtils();
      NodeList nodeList = utils.selectNodeList(doc, "//property[@name='tableName']");
      for (int i = 0; i < nodeList.getLength(); i++) {
        Element element = (Element) nodeList.item(i);
        if ((element.getAttribute("name")).equalsIgnoreCase("tableName")) {
          tableNameList.add(element.getAttribute("value"));
        }
      }
    }
    catch (XMLParserException e) {
      e.printStackTrace();
      fail("Parser exception thrown");
    }
    assertTrue(tableNameList.size() == 20);
    System.out.println(tableNameList.toString());
  }
}
