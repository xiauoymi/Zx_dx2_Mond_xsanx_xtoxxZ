package com.monsanto.wst.usseedplanning.services.cache.mock;

import com.monsanto.wst.usseedplanning.model.cache.ProductCriteria;
import com.monsanto.wst.usseedplanning.model.cache.ProductDetails;
import com.monsanto.wst.usseedplanning.services.cache.ProductLookupService;
import com.monsanto.wst.usseedplanning.services.cache.ErrorHandler;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * Date: Aug 8, 2006
 * Time: 5:39:15 PM
 * <p/>
 * Mock implementation of the ProductLookupService interface.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class MockProductLookupService implements ProductLookupService {
    public List lookupProductDetailByCriteria(List productCriteriaList) {
        List productList = new ArrayList();
        for (int i = 0; i < productCriteriaList.size(); i++) {
            ProductCriteria criteria = (ProductCriteria) productCriteriaList.get(i);
            StringBuffer preCommercialName = new StringBuffer(criteria.getProductName());
            productList.add(new ProductDetails(criteria.getProductName(), criteria.getProductName(), preCommercialName.append("-0").toString(), "0"));
            productList.add(new ProductDetails(criteria.getProductName(), criteria.getProductName(), preCommercialName.append("-1").toString(), "1"));
            productList.add(new ProductDetails(criteria.getProductName(), criteria.getProductName(), preCommercialName.append("-2").toString(), "2"));
        }
        return productList;
    }

    public List lookupProductDetailByCriteria(ProductCriteria criteria) throws Exception {
        List productList = new ArrayList();
        StringBuffer preCommercialName = new StringBuffer(criteria.getProductName());
        productList.add(new ProductDetails(criteria.getProductName(), criteria.getProductName(), preCommercialName.append("-0").toString(), "0"));
        productList.add(new ProductDetails(criteria.getProductName(), criteria.getProductName(), preCommercialName.append("-1").toString(), "1"));
        productList.add(new ProductDetails(criteria.getProductName(), criteria.getProductName(), preCommercialName.append("-2").toString(), "2"));
        return productList;
    }

  public void registerErrorHandler(ErrorHandler errorHandler) {
  }
}
