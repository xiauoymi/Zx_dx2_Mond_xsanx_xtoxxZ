/*
 MockLatestRevisionSerivce was created on Nov 3, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.usseedplanning.services.core.mock;

import com.monsanto.wst.usseedplanning.model.maintenance.Revision;
import com.monsanto.wst.usseedplanning.services.core.LatestRevisionService;

import java.sql.Date;

/**
 * Filename:    $RCSfile: MockLatestRevisionService.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: vrbethi $    	 On:	$Date: 2006-11-04 18:30:34 $
 *
 * @author vrbethi
 * @version $Revision: 1.1 $
 */
public class MockLatestRevisionService implements LatestRevisionService {
    public Revision getLatestRevision(){
        return new Revision(new Long(1000),"temp",new Date(System.currentTimeMillis()),null,null,null);
    }
}