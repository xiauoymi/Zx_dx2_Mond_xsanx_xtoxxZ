/*
Copyright:  Copyright � 2006 Monsanto.  All rights reserved.
This software was produced using Monsanto resources and is the sole property of Monsanto.
Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.usseedplanning.services.cache.lexiconclientservices;

import com.monsanto.Util.StringUtils;
import com.monsanto.XMLUtil.ParserException;
import com.monsanto.wst.commonutils.resources.ResourceUtils;
import com.monsanto.wst.commonutils.xml.XMLParserException;
import com.monsanto.wst.commonutils.xml.XMLUtilities;
import com.monsanto.wst.usseedplanning.constants.MainConstants;
import org.apache.xpath.XPathAPI;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.xml.sax.SAXException;

import javax.xml.transform.TransformerException;
import java.io.IOException;

/**
 * Filename:    $RCSfile: LexiconServiceRequestGeneratorDOMImpl.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: njminsh $    	 On:	$Date: 2007-01-31 22:39:38 $
 *
 * @author rdesai2
 * @version $Revision: 1.1 $
 */
public class LexiconServiceRequestGeneratorDOMImpl implements ProductServiceRequestGenerator {

//  private static final String XPATH_GET_AGGREGATE_PRODUCT_SERVICE = "//*[local-name() = 'ProductName' and namespace-uri() = 'http://www.monsanto.com/lexicon/AggregateProduct']";
    public static final String XPATH_GET_AGGREGATE_PRODUCT_SERVICE = "Request/ProductName";
//  private static final String XPATH_GET_PRODUCT_PARENT_BY_PRE_COMPL_NAME = "//*[local-name() = 'PreCommercialName' and namespace-uri() = 'http://www.monsanto.com/lexicon/ProductParent']";
    public static final String XPATH_GET_PRODUCT_PARENT_BY_PRE_COMPL_NAME = "ProductParentRequest/PreCommercialName";
//  private static final String XPATH_GET_PRODUCT_PARENT_BY_MFG_NAME = "//*[local-name() = 'ManufacturingName' and namespace-uri() = 'http://www.monsanto.com/lexicon/ProductParent']";
    public static final String XPATH_GET_PRODUCT_PARENT_BY_MFG_NAME = "ProductParentRequest/ManufacturingName";

    public Document getRequestDocumentForProductParentsByPrecommercialNameService(String preCommercialName) throws Exception {
        if (!StringUtils.isNullOrEmpty(preCommercialName)) {
            return transformRequestXML(preCommercialName, XPATH_GET_PRODUCT_PARENT_BY_PRE_COMPL_NAME, MainConstants.REQUEST_TEMPLATE_XML_Lex_PRODUCT_PARENT_BY_PRE_COML_NAME);
        }
        throw new IllegalArgumentException();
    }

    public Document getRequestDocumentForProductParentsByManufacturingNameService(String manufacturingName) throws Exception {
        if (!StringUtils.isNullOrEmpty(manufacturingName)) {
            return transformRequestXML(manufacturingName, XPATH_GET_PRODUCT_PARENT_BY_MFG_NAME, MainConstants.REQUEST_TEMPLATE_XML_Lex_PRODUCT_PARENT_BY_MFG_NAME);
        }
        throw new IllegalArgumentException();
    }

    public Document getRequestDocumentForGetAggregateProductService(String commercialName) throws Exception {
        if (!StringUtils.isNullOrEmpty(commercialName)) {
            return transformRequestXML(commercialName, XPATH_GET_AGGREGATE_PRODUCT_SERVICE, MainConstants.REQUEST_TEMPLATE_XML_LEX_GET_AGGREGATE_PRODUCT);
        }
        throw new IllegalArgumentException();
    }

    /**
     * This method allows a small transformation of xml-document given an xml-template.
     * @param newValue
     * @param xpathString
     * @param requestTemplate
     * @return Transformed Document
     * @throws com.monsanto.XMLUtil.ParserException
     * @throws javax.xml.transform.TransformerException
     * @throws java.io.IOException
     * @throws org.xml.sax.SAXException
     */
    public Document transformRequestXML(String newValue, String xpathString, String requestTemplate) throws ParserException, TransformerException, IOException, SAXException, XMLParserException {
//    Document document = DOMUtil.newDocumentNS(new InputStreamReader(new FileInputStream(new ResourceUtils().convertPathToFile(requestTemplate))));
        XMLUtilities xmlUtilities = new XMLUtilities(new ResourceUtils());
        Document document =xmlUtilities.createDocument(getClass().getClassLoader().getResourceAsStream(requestTemplate));
        Node currentNode = XPathAPI.selectSingleNode(document, xpathString);
        Node newNode = document.createTextNode(newValue);
        currentNode.replaceChild(newNode, currentNode.getFirstChild());
        return document;
    }
}