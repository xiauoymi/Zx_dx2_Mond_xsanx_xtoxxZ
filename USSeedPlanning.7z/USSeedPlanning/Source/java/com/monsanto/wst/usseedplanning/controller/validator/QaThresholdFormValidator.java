/*
 Copyright:  Copyright � 2006 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.usseedplanning.controller.validator;

import com.monsanto.wst.validator.HttpValidator;
import com.monsanto.wst.validator.HttpRequestErrors;
import com.monsanto.wst.usseedplanning.constants.MainConstants;
import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.Util.StringUtils;

import java.io.IOException;

/**
 * Filename:    $RCSfile: QaThresholdFormValidator.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: jdpoul $    	 On:	$Date: 2006-09-20 19:57:05 $
 *
 * @author jdpoul
 * @version $Revision: 1.5 $
 */
public class QaThresholdFormValidator implements HttpValidator {

    public HttpRequestErrors validate(UCCHelper helper) throws IOException {
        HttpRequestErrors errors = new HttpRequestErrors();
        checkComparisonStrategyValue(errors, helper);
        checkQaThresholdTypeIdValue(errors, helper);
        checkGenderIdValue(errors, helper);
        checkYearIdValue(errors, helper);
        checkActiveValue(errors, helper);
        checkFactorValue(errors, helper);
        return errors;
    }

    public HttpRequestErrors checkLongValue(HttpRequestErrors errors, UCCHelper helper, String paramKey, String fieldName, boolean required) throws IOException{
        checkArgs(errors, helper);
        String value = helper.getRequestParameterValue(paramKey);

        if(value == null || StringUtils.isEmpty(value)){
            if(required){
                errors.addError(paramKey,"Please select a value for the field " + fieldName + ".");
                return errors;
            }
            return errors;
        }

        try {
            Long.valueOf(value);
        } catch (NumberFormatException e) {
            errors.addError(paramKey, "Please select a value for the field " + fieldName + ".");
        }
        return errors;
    }




    private void checkComparisonStrategyValue(HttpRequestErrors errors, UCCHelper helper) throws IOException{
        checkLongValue(errors, helper, MainConstants.QaThresholdConstants.COMPARISON_STRATEGY_ID_PARAM_NAME, MainConstants.QaThresholdConstants.COMPARISON_STRATEGY_ID_FIELD_NAME, true);
    }


    private void checkYearIdValue(HttpRequestErrors errors, UCCHelper helper) throws IOException{
        checkLongValue(errors, helper, MainConstants.QaThresholdConstants.YEAR_ID_PARAM_NAME, MainConstants.QaThresholdConstants.YEAR_ID_FIELD_NAME, false);
    }

    private void checkQaThresholdTypeIdValue(HttpRequestErrors errors, UCCHelper helper) throws IOException{
        checkLongValue(errors, helper, MainConstants.QaThresholdConstants.QA_THRESHOLD_TYPE_ID_PARAM_NAME, MainConstants.QaThresholdConstants.QA_THRESHOLD_TYPE_ID_FIELD_NAME, true);
    }

    private void checkGenderIdValue(HttpRequestErrors errors, UCCHelper helper)throws IOException{
        checkLongValue(errors, helper, MainConstants.QaThresholdConstants.GENDER_ID_PARAM_NAME, MainConstants.QaThresholdConstants.GENDER_ID_FIELD_NAME, false);
    }

    private void checkActiveValue(HttpRequestErrors errors, UCCHelper helper) throws IOException{
        checkExists(helper, errors, MainConstants.QaThresholdConstants.ACTIVE_FIELD_NAME, MainConstants.QaThresholdConstants.ACTIVE_PARAM_NAME);
    }


    private void checkFactorValue(HttpRequestErrors errors, UCCHelper helper)throws IOException{
        checkExists(helper, errors, MainConstants.QaThresholdConstants.VALUE_FIELD_NAME, MainConstants.QaThresholdConstants.VALUE_PARAM_NAME);
    }

    private void checkExists(UCCHelper helper, HttpRequestErrors errors, String fieldName, String paramName) throws IOException {
        String value = helper.getRequestParameterValue(paramName);
        if(value ==null || StringUtils.isEmpty(value)){
            errors.addError(fieldName, "The value for the field '" + fieldName + "' was not specified, but is required.");
        }
    }



    private void checkArgs(HttpRequestErrors errors, UCCHelper helper){
        if(errors == null){
            throw new IllegalArgumentException("The HttpRequestErrors instance passed in was null.");
        }

        if(helper == null){
            throw new IllegalArgumentException("The UCCHelper instance passed in was null.");
        }
    }

}