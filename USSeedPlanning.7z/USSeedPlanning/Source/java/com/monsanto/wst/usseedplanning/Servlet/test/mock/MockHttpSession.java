package com.monsanto.wst.usseedplanning.Servlet.test.mock;

import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpSessionContext;
import javax.servlet.ServletContext;
import java.util.Enumeration;

/**
 * Created by IntelliJ IDEA.
 * Date: Feb 16, 2007
 * Time: 11:01:38 AM
 * <p/>
 * TODO: Enter description for class.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class MockHttpSession implements HttpSession {
    public long getCreationTime() {
        return 0;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public String getId() {
        return "12345";
    }

    public long getLastAccessedTime() {
        return 0;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public ServletContext getServletContext() {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public void setMaxInactiveInterval(int i) {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    public int getMaxInactiveInterval() {
        return 0;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public HttpSessionContext getSessionContext() {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public Object getAttribute(String statementName) {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public Object getValue(String statementName) {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public Enumeration getAttributeNames() {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public String[] getValueNames() {
        return new String[0];  //To change body of implemented methods use File | Settings | File Templates.
    }

    public void setAttribute(String statementName, Object object) {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    public void putValue(String statementName, Object object) {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    public void removeAttribute(String statementName) {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    public void removeValue(String statementName) {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    public void invalidate() {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    public boolean isNew() {
        return false;  //To change body of implemented methods use File | Settings | File Templates.
    }
}
