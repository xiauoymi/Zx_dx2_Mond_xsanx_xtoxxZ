/*
 JspStageFactorViewUT was created on Sep 18, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.usseedplanning.view.jsp.maintenance.seedEntity.test;

import com.monsanto.AbstractLogging.Logger;
import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.wst.usseedplanning.view.jsp.maintenance.seedEntity.JspStageFactorsView;
import com.monsanto.wst.usseedplanning.constants.MainConstants;
import com.monsanto.wst.view.ViewRenderingException;
import com.monsanto.wst.view.test.mock.MockUCCHelperThrowsIOException;
import junit.framework.TestCase;

import java.util.List;
import java.util.ArrayList;

/**
 * Filename:    $RCSfile: JspStageFactorViewUT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: njminsh $    	 On:	$Date: 2007-02-13 19:21:06 $
 *
 * @author sspati1
 * @version $Revision: 1.2 $
 */
public class JspStageFactorViewUT extends TestCase{

  public void testCreate() throws Exception {
    JspStageFactorsView stageFactorsView = new JspStageFactorsView();
    assertNotNull(stageFactorsView);
  }

  public void testRenderView() throws Exception {
      MockUCCHelper helper = new MockUCCHelper(null);
      List stageFactorsList = new ArrayList();
      List yearList = new ArrayList();
      List stageList = new ArrayList();
      JspStageFactorsView view = new JspStageFactorsView();
      view.renderView(helper);
      assertTrue(helper.wasSentTo(MainConstants.LIST_STAGE_FACTORS_JSP));
    }

  public void testRenderViewThrowsException() throws Exception {
      MockUCCHelper helper = new MockUCCHelperThrowsIOException(null);
      JspStageFactorsView view = new JspStageFactorsView();
      Logger.disableLogger(Logger.ERROR_LOG);
      try {
          view.renderView(helper);
          fail("This should have thrown an exception.");
      } catch (ViewRenderingException e) {
          assertEquals("Unable to render stage factor view.", e.getMessage());
      }

      Logger.enableLogger(Logger.ERROR_LOG);
      try {
          view.renderView(helper);
          fail("This should have thrown an exception.");
      } catch (ViewRenderingException e) {
          assertEquals("Unable to render stage factor view.", e.getMessage());
      }
  }
}