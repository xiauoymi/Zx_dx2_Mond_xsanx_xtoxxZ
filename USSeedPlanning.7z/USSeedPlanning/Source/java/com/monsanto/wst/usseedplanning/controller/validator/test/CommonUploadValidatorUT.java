/*
 CommonUploadValidatorUT was created on Oct 10, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.usseedplanning.controller.validator.test;

import junit.framework.TestCase;
import com.monsanto.wst.usseedplanning.controller.validator.CommonUploadValidator;
import com.monsanto.wst.validator.HttpRequestErrors;
import com.monsanto.ServletFramework.Test.MockUCCHelper;

/**
 * Created by IntelliJ IDEA.
 * Date: Aug 15, 2006
 * Time: 9:59:01 AM
 * <p/>
 * Unit test for the CommonForecastValidator object.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class CommonUploadValidatorUT extends TestCase {
    public void testCreate() throws Exception {
        CommonUploadValidator validator = new CommonUploadValidator();
        assertNotNull(validator);
    }

    public void testValidatePass() throws Exception {
        CommonUploadValidator validator = new CommonUploadValidator();
        MockUCCHelper helper = createRequest();
        HttpRequestErrors errors = validator.validate(helper);
        assertTrue(errors.isEmpty());
    }

    public void testValidateFail() throws Exception {
        CommonUploadValidator validator = new CommonUploadValidator();
        MockUCCHelper helper = new MockUCCHelper(null);
        HttpRequestErrors errors = validator.validate(helper);
        assertFalse(errors.isEmpty());
        assertEquals("Comment should not be left empty.", errors.getError("comments"));
	    assertEquals("Please select a column.", errors.getError("columnName"));
        assertEquals("Please select file to upload.", errors.getError("commonFile"));
    }

    private MockUCCHelper createRequest() {
        MockUCCHelper helper = new MockUCCHelper(null);
        helper.setRequestParameterValue("comments", "Test Message");
        helper.setRequestParameterValue("columnName", "1");
	    helper.addClientFile("testfile");
        return helper;
    }
}