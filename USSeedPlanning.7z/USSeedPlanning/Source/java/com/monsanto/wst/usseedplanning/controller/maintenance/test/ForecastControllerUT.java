package com.monsanto.wst.usseedplanning.controller.maintenance.test;

import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.wst.servletframework.DITransactionalController;
import com.monsanto.wst.usseedplanning.constants.MainConstants;
import com.monsanto.wst.usseedplanning.constants.ControllerConstants;
import com.monsanto.wst.usseedplanning.controller.maintenance.ForecastController;
import com.monsanto.wst.usseedplanning.exception.ServiceUnavailableException;
import com.monsanto.wst.usseedplanning.model.core.LoginUser;
import com.monsanto.wst.usseedplanning.model.planning.PlanType;
import com.monsanto.wst.usseedplanning.services.maintenance.forecast.ForecastService;
import com.monsanto.wst.usseedplanning.services.maintenance.forecast.InvalidForecastException;
import com.monsanto.wst.usseedplanning.services.maintenance.forecast.mock.MockForecastService;
import com.monsanto.wst.usseedplanning.view.factory.ViewFactory;
import com.monsanto.wst.usseedplanning.view.factory.mock.MockViewFactory;
import com.monsanto.wst.validator.HttpRequestErrors;
import com.monsanto.wst.validator.HttpValidator;
import com.monsanto.wst.validator.HttpRequestMessages;
import com.monsanto.wst.validator.test.mock.MockHttpValidator;
import com.monsanto.wst.view.test.mock.MockView;
import junit.framework.TestCase;

import java.io.File;
import java.io.IOException;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * Date: Aug 7, 2006
 * Time: 2:00:22 PM
 * <p/>
 * Unit test for the ForecastController object.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class ForecastControllerUT extends TestCase {

  public void testCreate() throws Exception {
    ForecastController controller = new ForecastController((ViewFactory) null, (ForecastService) null, (HttpValidator) null);
    assertNotNull(controller);
  }

  public void testNotSpecified() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);
    ViewFactory factory = new MockViewFactory();
    ForecastController controller = new ForecastController(factory, (ForecastService) null, (HttpValidator) null);
    controller.run(helper);
    MockView view = (MockView) factory.getImportCommonForecastView();
    assertTrue(view.wasViewRendered());
  }

  public void testUploadDemand() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue("method","uploadDemand");
    ViewFactory factory = new MockViewFactory();
    ForecastController controller = new ForecastController(factory, (ForecastService) null, (HttpValidator) null);
    controller.run(helper);
    MockView view = (MockView) factory.getImportDemandForecastView();
    assertTrue(view.wasViewRendered());
  }

  public void testAddCommonForecastsSuccess() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.addClientFile("test.xls");
    helper.setRequestParameterValue("comments", "Test Comments");
    helper.setRequestParameterValue("planType", PlanType.PARENT_PLAN_TYPE_ID);
    helper.setRequestParameterValue("method", "addCommonForecasts");
    LoginUser user = new LoginUser("tester");
    helper.setSessionParameter(MainConstants.LOGINUSER, user);
    MockViewFactory factory = new MockViewFactory();
    MockForecastService service = new MockForecastService();
    ForecastController controller = new ForecastController(factory, service, new MockHttpValidator());
    controller.run(helper);
    assertTrue(service.wereForecastsAdded());
    assertEquals("test.xls", service.getSpreadsheet().getName());
    assertEquals("Test Comments", service.getComments());
    assertEquals(user, service.getCurrentUser());
    assertEquals(PlanType.PARENT_PLAN_TYPE_ID, service.getPlanType());
    assertEquals("Common Forecast Successfully Uploaded.", ((HttpRequestMessages) helper.getRequestAttributeValue(ControllerConstants.MESSAGES_REQUEST_ATTRIBUTE)).getMessages().get(0));
  }

  public void testAddCommonForecastsFailsValidation() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.addClientFile("test.xls");
    helper.setRequestParameterValue("comments", "Test Comments");
    helper.setRequestParameterValue("planType", PlanType.PARENT_PLAN_TYPE_NAME);
    helper.setRequestParameterValue("method", "addCommonForecasts");
    LoginUser user = new LoginUser("tester");
    helper.setSessionParameter(MainConstants.LOGINUSER, user);
    MockViewFactory factory = new MockViewFactory();
    MockForecastService service = new MockForecastService();
    HttpRequestErrors errors = new HttpRequestErrors();
    errors.addError("comment", "Test Error");
    ForecastController controller = new ForecastController(factory, service, new MockHttpValidator(errors));
    controller.run(helper);
    MockView view = (MockView) factory.getImportCommonForecastView();
    assertTrue(view.wasViewRendered());
    assertEquals("Test Error", ((HttpRequestErrors) helper.getRequestAttributeValue(ControllerConstants.ERRORS_REQUEST_ATTRIBUTE)).getError("comment"));
  }

  public void testAddCommonForecastInvalid() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.addClientFile("test.xls");
    helper.setRequestParameterValue("comments", "Test Comments");
    helper.setRequestParameterValue("planType", PlanType.PARENT_PLAN_TYPE_ID);
    helper.setRequestParameterValue("method", "addCommonForecasts");
    LoginUser user = new LoginUser("tester");
    helper.setSessionParameter(MainConstants.LOGINUSER, user);
    MockViewFactory factory = new MockViewFactory();
    MockForecastServiceThrowsException service = new MockForecastServiceThrowsException();
    ForecastController controller = new ForecastController(factory, service, new MockHttpValidator());
    controller.run(helper);
    MockView view = (MockView) factory.getImportCommonForecastView();
    assertTrue(view.wasViewRendered());
    assertEquals("Test Exception.", ((HttpRequestErrors) helper.getRequestAttributeValue(ControllerConstants.ERRORS_REQUEST_ATTRIBUTE)).getError(HttpRequestErrors.GLOBAL_ERROR));
    assertEquals(Boolean.TRUE, helper.getRequestAttributeValue(DITransactionalController.ROLLBACK__FLAG));
  }

  public void testAddDemandForecastsFailsValidation() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.addClientFile("test.xls");
    helper.setRequestParameterValue("comments", "Test Comments");
    helper.setRequestParameterValue("method", "addDemandForecasts");
    LoginUser user = new LoginUser("tester");
    helper.setSessionParameter(MainConstants.LOGINUSER, user);
    MockViewFactory factory = new MockViewFactory();
    MockForecastService service = new MockForecastService();
    HttpRequestErrors errors = new HttpRequestErrors();
    errors.addError("comment", "Test Error");
    ForecastController controller = new ForecastController(factory, service, new MockHttpValidator(errors));
    controller.run(helper);
    MockView view = (MockView) factory.getImportDemandForecastView();
    assertTrue(view.wasViewRendered());
    assertEquals("Test Error", ((HttpRequestErrors) helper.getRequestAttributeValue(ControllerConstants.ERRORS_REQUEST_ATTRIBUTE)).getError("comment"));
  }

  public void testAddDemandForecastsSuccess() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.addClientFile("test.xls");
    helper.setRequestParameterValue("comments", "Test Comments");
    helper.setRequestParameterValue("method", "addDemandForecasts");
    LoginUser user = new LoginUser("tester");
    helper.setSessionParameter(MainConstants.LOGINUSER, user);
    MockViewFactory factory = new MockViewFactory();
    MockForecastService service = new MockForecastService();
    ForecastController controller = new ForecastController(factory, service, new MockHttpValidator());
    controller.run(helper);
    assertTrue(service.wereForecastsAdded());
    assertEquals("test.xls", service.getSpreadsheet().getName());
    assertEquals("Test Comments", service.getComments());
    assertEquals(user, service.getCurrentUser());
    assertEquals("Demand Forecast Successfully Uploaded.", ((HttpRequestMessages) helper.getRequestAttributeValue(ControllerConstants.MESSAGES_REQUEST_ATTRIBUTE)).getMessages().get(0));
  }

  public void testAddDemandForecastsInvalid() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.addClientFile("test.xls");
    helper.setRequestParameterValue("comments", "Test Comments");
    helper.setRequestParameterValue("method", "addDemandForecasts");
    LoginUser user = new LoginUser("tester");
    helper.setSessionParameter(MainConstants.LOGINUSER, user);
    MockViewFactory factory = new MockViewFactory();
    MockForecastServiceThrowsException service = new MockForecastServiceThrowsException();
    ForecastController controller = new ForecastController(factory, service, new MockHttpValidator());
    controller.run(helper);
    MockView view = (MockView) factory.getImportDemandForecastView();
    assertTrue(view.wasViewRendered());
    assertEquals("Test Exception.", ((HttpRequestErrors) helper.getRequestAttributeValue(ControllerConstants.ERRORS_REQUEST_ATTRIBUTE)).getError(HttpRequestErrors.GLOBAL_ERROR));
    assertEquals(Boolean.TRUE, helper.getRequestAttributeValue(DITransactionalController.ROLLBACK__FLAG));
  }

  private class MockForecastServiceThrowsException implements ForecastService {
    public void addCommonForecasts(File spreadsheet, Long planType, LoginUser currentUser, String comments)
        throws IOException, ServiceUnavailableException, InvalidForecastException {
      throw new InvalidForecastException("Test Exception.");
    }

    public void addDemandForecasts(File spreadsheet, LoginUser currentUser, String comments)
        throws IOException, ServiceUnavailableException, InvalidForecastException {
      throw new InvalidForecastException("Test Exception.");
    }

    public List lookupDemandRevisionByChannel(Long planTypeId) {
      return null;  //To change body of implemented methods use File | Settings | File Templates.
    }
  }
}
