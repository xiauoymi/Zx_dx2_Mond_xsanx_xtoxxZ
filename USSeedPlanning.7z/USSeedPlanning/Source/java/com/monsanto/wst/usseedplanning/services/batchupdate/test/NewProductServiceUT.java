/*
BatchNewProductsServiceUT was created on Jan 17, 2007 using Monsanto
resources and is the sole property of Monsanto.  Any duplication of the
code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.usseedplanning.services.batchupdate.test;

import com.monsanto.wst.usseedplanning.dao.BatchDao;
import com.monsanto.wst.usseedplanning.dao.mock.MockBatchDao;
import com.monsanto.wst.usseedplanning.model.cache.ProductDetails;
import com.monsanto.wst.usseedplanning.services.batchupdate.NewProductServiceImpl;
import com.monsanto.wst.usseedplanning.services.batchupdate.NewProductService;
import junit.framework.TestCase;

import java.util.ArrayList;
import java.util.List;

/**
 * Filename:    $RCSfile: NewProductServiceUT.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: njminsh $    	 On:	$Date: 2007-03-06 17:23:59 $
 *
 * @author vrbethi
 * @version $Revision: 1.3 $
 */
public class NewProductServiceUT extends TestCase{


    public void testCreate() throws Exception {
        NewProductService newProductService = new NewProductServiceImpl((BatchDao)null);
        assertNotNull(newProductService);
    }

    public void testPreserveManualEntriesForMaleFemaleOverides() throws Exception {
        NewProductService newProductService = new NewProductServiceImpl(new MockBatchDao());
        List mockProductDetailsListFromLexicon= new ArrayList();
        ProductDetails productDetails;

        productDetails = new ProductDetails();
        productDetails.setPreCommercialName("LH160+LH85P");

        ProductDetails maleProductDetails = new ProductDetails();
        maleProductDetails.setPreCommercialName("_maleLH160+LH85P_");
        maleProductDetails.setManufacturingName("_maleLH160+LH85M_");
        maleProductDetails.setVersion("_MVersion_");
        maleProductDetails.setOverrideFlag(ProductDetails.GENERATED_OVERRIDE_FLAG);
        productDetails.setMaleParent(maleProductDetails);

        ProductDetails femaleProductDetails = new ProductDetails();
        femaleProductDetails.setPreCommercialName("_femaleLH160+LH85P_");
        femaleProductDetails.setManufacturingName("_femaleLH160+LH85M_");
        femaleProductDetails.setVersion("_FVersion_");
        femaleProductDetails.setOverrideFlag(ProductDetails.GENERATED_OVERRIDE_FLAG);
        productDetails.setFemaleParent(femaleProductDetails);

        mockProductDetailsListFromLexicon.add(productDetails);

        newProductService.preserveEntries(mockProductDetailsListFromLexicon);

        productDetails = (ProductDetails) mockProductDetailsListFromLexicon.get(0);
        ProductDetails maleParent = productDetails.getMaleParent();
        assertEquals("ManualMaleLH160+LH85P",maleParent.getPreCommercialName());
        assertEquals("ManualMaleLH160+LH85M",maleParent.getManufacturingName());
        assertEquals("n",maleParent.getVersion());

        ProductDetails femaleParent = productDetails.getFemaleParent();
        assertEquals("ManualFemaleLH160+LH85P",femaleParent.getPreCommercialName());
        assertEquals("ManualFemaleLH160+LH85M",femaleParent.getManufacturingName());
        assertEquals("n",femaleParent.getVersion());
    }

    public void testPreserveManualEntriesForMaleFemaleOverides_NoProductsInCache() throws Exception {
        NewProductService newProductService = new NewProductServiceImpl(new MockNoProductsBatchDao());
        List mockProductDetailsListFromLexicon= new ArrayList();
        ProductDetails productDetails;

        productDetails = new ProductDetails();
        productDetails.setPreCommercialName("LH160+LH85P");

        ProductDetails maleProductDetails = new ProductDetails();
        maleProductDetails.setPreCommercialName("_maleLH160+LH85P_");
        maleProductDetails.setManufacturingName("_maleLH160+LH85M_");
        maleProductDetails.setVersion("_MVersion_");
        maleProductDetails.setOverrideFlag(ProductDetails.GENERATED_OVERRIDE_FLAG);
        productDetails.setMaleParent(maleProductDetails);

        ProductDetails femaleProductDetails = new ProductDetails();
        femaleProductDetails.setPreCommercialName("_femaleLH160+LH85P_");
        femaleProductDetails.setManufacturingName("_femaleLH160+LH85M_");
        femaleProductDetails.setVersion("_FVersion_");
        femaleProductDetails.setOverrideFlag(ProductDetails.GENERATED_OVERRIDE_FLAG);
        productDetails.setFemaleParent(femaleProductDetails);

        mockProductDetailsListFromLexicon.add(productDetails);

        newProductService.preserveEntries(mockProductDetailsListFromLexicon);

        productDetails = (ProductDetails) mockProductDetailsListFromLexicon.get(0);
        ProductDetails maleParent = productDetails.getMaleParent();
        assertEquals("_maleLH160+LH85P_",maleParent.getPreCommercialName());
        assertEquals("_maleLH160+LH85M_",maleParent.getManufacturingName());
        assertEquals("V",maleParent.getVersion());

        ProductDetails femaleParent = productDetails.getFemaleParent();
        assertEquals("_femaleLH160+LH85P_",femaleParent.getPreCommercialName());
        assertEquals("_femaleLH160+LH85M_",femaleParent.getManufacturingName());
        assertEquals("V",femaleParent.getVersion());
    }

     public void testPreserveManualEntriesForOnlyFemaleOveridesActualMaleReturned() throws Exception {
        NewProductService newProductService = new NewProductServiceImpl(new MockBatchDao());
        List mockProductDetailsListFromLexicon= new ArrayList();
        ProductDetails productDetails;

        productDetails = new ProductDetails();
        productDetails.setPreCommercialName("LH160+LH85P");

        ProductDetails maleProductDetails = new ProductDetails();
        maleProductDetails.setPreCommercialName("_maleLH160+LH85P_");
        maleProductDetails.setManufacturingName("_maleLH160+LH85M_");
        maleProductDetails.setVersion("_MVersion_");
        maleProductDetails.setOverrideFlag(ProductDetails.ACTUAL_OVERRIDE_FLAG);
        productDetails.setMaleParent(maleProductDetails);

        ProductDetails femaleProductDetails = new ProductDetails();
        femaleProductDetails.setPreCommercialName("_femaleLH160+LH85P_");
        femaleProductDetails.setManufacturingName("_femaleLH160+LH85M_");
        femaleProductDetails.setVersion("_FVersion_");
        femaleProductDetails.setOverrideFlag(ProductDetails.GENERATED_OVERRIDE_FLAG);
        productDetails.setFemaleParent(femaleProductDetails);

        mockProductDetailsListFromLexicon.add(productDetails);

        newProductService.preserveEntries(mockProductDetailsListFromLexicon);

        productDetails = (ProductDetails) mockProductDetailsListFromLexicon.get(0);
        ProductDetails maleParent = productDetails.getMaleParent();
        assertEquals("_maleLH160+LH85P_",maleParent.getPreCommercialName());
        assertEquals("_maleLH160+LH85M_",maleParent.getManufacturingName());
        assertEquals("V",maleParent.getVersion());

        ProductDetails femaleParent = productDetails.getFemaleParent();
        assertEquals("ManualFemaleLH160+LH85P",femaleParent.getPreCommercialName());
        assertEquals("ManualFemaleLH160+LH85M",femaleParent.getManufacturingName());
        assertEquals("n",femaleParent.getVersion());
    }

    public void testPreserveManualEntriesForOnlyMaleOveridesActualFemaleReturned() throws Exception {
        NewProductService newProductService = new NewProductServiceImpl(new MockBatchDao());
        List mockProductDetailsListFromLexicon= new ArrayList();
        ProductDetails productDetails;

        productDetails = new ProductDetails();
        productDetails.setPreCommercialName("LH160+LH85P");

        ProductDetails maleProductDetails = new ProductDetails();
        maleProductDetails.setPreCommercialName("_maleLH160+LH85P_");
        maleProductDetails.setManufacturingName("_maleLH160+LH85M_");
        maleProductDetails.setVersion("_MVersion_");
        maleProductDetails.setOverrideFlag(ProductDetails.GENERATED_OVERRIDE_FLAG);
        productDetails.setMaleParent(maleProductDetails);

        ProductDetails femaleProductDetails = new ProductDetails();
        femaleProductDetails.setPreCommercialName("_femaleLH160+LH85P_");
        femaleProductDetails.setManufacturingName("_femaleLH160+LH85M_");
        femaleProductDetails.setVersion("_FVersion_");
        femaleProductDetails.setOverrideFlag(ProductDetails.ACTUAL_OVERRIDE_FLAG);
        productDetails.setFemaleParent(femaleProductDetails);

        mockProductDetailsListFromLexicon.add(productDetails);

        newProductService.preserveEntries(mockProductDetailsListFromLexicon);

        productDetails = (ProductDetails) mockProductDetailsListFromLexicon.get(0);
        ProductDetails maleParent = productDetails.getMaleParent();
        assertEquals("ManualMaleLH160+LH85P",maleParent.getPreCommercialName());
        assertEquals("ManualMaleLH160+LH85M",maleParent.getManufacturingName());
        assertEquals("n",maleParent.getVersion());

        ProductDetails femaleParent = productDetails.getFemaleParent();
        assertEquals("_femaleLH160+LH85P_",femaleParent.getPreCommercialName());
        assertEquals("_femaleLH160+LH85M_",femaleParent.getManufacturingName());
        assertEquals("V",femaleParent.getVersion());
    }

    public void testPreserveManualEntriesForBothMaleAndFemaleActive() throws Exception {
        NewProductService newProductService = new NewProductServiceImpl(new MockBatchDao());
        List mockProductDetailsListFromLexicon= new ArrayList();
        ProductDetails productDetails;

        productDetails = new ProductDetails();
        productDetails.setPreCommercialName("LH160+LH85P");

        ProductDetails maleProductDetails = new ProductDetails();
        maleProductDetails.setPreCommercialName("_maleLH160+LH85P_");
        maleProductDetails.setManufacturingName("_maleLH160+LH85M_");
        maleProductDetails.setVersion("_MVersion_");
        maleProductDetails.setOverrideFlag(ProductDetails.ACTUAL_OVERRIDE_FLAG);
        productDetails.setMaleParent(maleProductDetails);

        ProductDetails femaleProductDetails = new ProductDetails();
        femaleProductDetails.setPreCommercialName("_femaleLH160+LH85P_");
        femaleProductDetails.setManufacturingName("_femaleLH160+LH85M_");
        femaleProductDetails.setVersion("_FVersion_");
        femaleProductDetails.setOverrideFlag(ProductDetails.ACTUAL_OVERRIDE_FLAG);
        productDetails.setFemaleParent(femaleProductDetails);

        mockProductDetailsListFromLexicon.add(productDetails);

        newProductService.preserveEntries(mockProductDetailsListFromLexicon);

        productDetails = (ProductDetails) mockProductDetailsListFromLexicon.get(0);
        ProductDetails maleParent = productDetails.getMaleParent();
        assertEquals("_maleLH160+LH85P_",maleParent.getPreCommercialName());
        assertEquals("_maleLH160+LH85M_",maleParent.getManufacturingName());
        assertEquals("V",maleParent.getVersion());

        ProductDetails femaleParent = productDetails.getFemaleParent();
        assertEquals("_femaleLH160+LH85P_",femaleParent.getPreCommercialName());
        assertEquals("_femaleLH160+LH85M_",femaleParent.getManufacturingName());
        assertEquals("V",femaleParent.getVersion());
    }

    public void testPreserveManualEntriesForBothNoMaleOnlyFemalePresentFromLexicon() throws Exception {
        NewProductService newProductService = new NewProductServiceImpl(new MockBatchDao());
        List mockProductDetailsListFromLexicon= new ArrayList();
        ProductDetails productDetails;

        productDetails = new ProductDetails();
        productDetails.setPreCommercialName("LH160+LH85P");

        ProductDetails femaleProductDetails = new ProductDetails();
        femaleProductDetails.setPreCommercialName("_femaleLH160+LH85P_");
        femaleProductDetails.setManufacturingName("_femaleLH160+LH85M_");
        femaleProductDetails.setVersion("_FVersion_");
        femaleProductDetails.setOverrideFlag(ProductDetails.ACTUAL_OVERRIDE_FLAG);
        productDetails.setFemaleParent(femaleProductDetails);

        mockProductDetailsListFromLexicon.add(productDetails);

        newProductService.preserveEntries(mockProductDetailsListFromLexicon);

        productDetails = (ProductDetails) mockProductDetailsListFromLexicon.get(0);
        ProductDetails maleParent = productDetails.getMaleParent();
        assertEquals("ManualMaleLH160+LH85P",maleParent.getPreCommercialName());
        assertEquals("ManualMaleLH160+LH85M",maleParent.getManufacturingName());
        assertEquals("n",maleParent.getVersion());

        ProductDetails femaleParent = productDetails.getFemaleParent();
        assertEquals("_femaleLH160+LH85P_",femaleParent.getPreCommercialName());
        assertEquals("_femaleLH160+LH85M_",femaleParent.getManufacturingName());
        assertEquals("V",femaleParent.getVersion());
    }

    class MockNoProductsBatchDao implements BatchDao{

        public List lookUpSupplyDemandProducts() {
            return null;
        }

        public List lookUpProductDetailsForProvidedName(String name) {
            return new ArrayList();
        }
    }
}