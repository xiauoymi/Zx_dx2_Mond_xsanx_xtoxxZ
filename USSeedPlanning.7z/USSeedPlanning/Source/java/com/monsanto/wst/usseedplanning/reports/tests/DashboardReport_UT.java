/*
 DashboardReport_UT was created on Aug 31, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.usseedplanning.reports.tests;

import com.monsanto.wst.dbtemplate.test.mock.MockDBTemplate;
import com.monsanto.wst.reportingframework.core.AbstractReport;
import com.monsanto.wst.reportingframework.core.ReportParameters;
import com.monsanto.wst.usseedplanning.reports.DashboardReport;
import junit.framework.TestCase;
import org.w3c.dom.Document;

import java.util.ArrayList;
import java.util.List;

/**
 * Filename:    $RCSfile: DashboardReport_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ffbrac $    	 On:	$Date: 2006-10-26 20:28:57 $
 *
 * @author ffbrac
 * @version $Revision: 1.4 $
 */
public class DashboardReport_UT extends TestCase {
	public DashboardReport_UT(String name) {
		super(name);
	}

	public void testOutputReportXMLFromDashboardReport() throws Exception {
		AbstractReport abstractReport = new DashboardReport(new MockReportDBTemplate());
		ReportParameters reportParameters = new ReportParameters();
		reportParameters.add("planId", "0");
		Document document = abstractReport.buildReportXML(reportParameters, null);
		assertNotNull(document);
	}
	private class MockReportDBTemplate extends MockDBTemplate{
		public List executeListResultQuery(String sqlName) {
			return new ArrayList();
		}
	}
}