package com.monsanto.wst.usseedplanning.services.maintenance.supply;

/**
 * Created by IntelliJ IDEA.
 * Date: Feb 12, 2007
 * Time: 4:50:50 PM
 * <p/>
 * TODO: Enter description for class.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public interface UpdateSupplyServiceFactory {
    UpdateSupplyService getUpdateSupplyService(String supplyType);
}
