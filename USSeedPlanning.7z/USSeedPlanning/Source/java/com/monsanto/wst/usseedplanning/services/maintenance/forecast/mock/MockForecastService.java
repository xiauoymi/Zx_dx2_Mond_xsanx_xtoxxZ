package com.monsanto.wst.usseedplanning.services.maintenance.forecast.mock;

import com.monsanto.wst.usseedplanning.exception.ServiceUnavailableException;
import com.monsanto.wst.usseedplanning.model.core.LoginUser;
import com.monsanto.wst.usseedplanning.model.maintenance.Channel;
import com.monsanto.wst.usseedplanning.model.maintenance.Revision;
import com.monsanto.wst.usseedplanning.model.planning.ChannelizedDemandRevisions;
import com.monsanto.wst.usseedplanning.services.maintenance.forecast.ForecastService;

import java.io.File;
import java.io.IOException;
import java.util.*;

/**
 * Created by IntelliJ IDEA.
 * Date: Aug 11, 2006
 * Time: 2:27:11 PM
 * <p/>
 * Mock implemenation of the ForecastService interface.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class MockForecastService implements ForecastService {
  private File spreadsheet;
  private Long planType;
  private LoginUser currentUser;
  private String comments;
  private boolean wereAdded = false;

  public void addCommonForecasts(File spreadsheet, Long planType, LoginUser currentUser, String comments)
      throws IOException, ServiceUnavailableException {
    this.spreadsheet = spreadsheet;
    this.planType = planType;
    this.currentUser = currentUser;
    this.comments = comments;
    this.wereAdded = true;
  }

  public void addDemandForecasts(File spreadsheet, LoginUser currentUser, String comments)
      throws IOException,ServiceUnavailableException {
    this.spreadsheet = spreadsheet;
    this.currentUser = currentUser;
    this.comments = comments;
    this.wereAdded = true;
  }

  public List lookupDemandRevisionByChannel(Long planTypeId) {
    List revisionList = new ArrayList();
    revisionList.add(new Revision(new Long(100)));
    revisionList.add(new Revision(new Long(101)));
    List results = new ArrayList();
    results.add(new ChannelizedDemandRevisions(new Channel(new Long(100)), revisionList));
    return results;
  }

  public File getSpreadsheet() {
    return spreadsheet;
  }

  public Long getPlanType() {
    return planType;
  }

  public LoginUser getCurrentUser() {
    return currentUser;
  }

  public String getComments() {
    return comments;
  }

  public boolean wereForecastsAdded() {
    return wereAdded;
  }
}
