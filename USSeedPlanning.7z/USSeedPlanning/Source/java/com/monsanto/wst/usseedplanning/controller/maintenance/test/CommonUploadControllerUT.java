/*
 CommonUploadControllerUT was created on Oct 10, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.usseedplanning.controller.maintenance.test;

import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.wst.usseedplanning.controller.maintenance.CommonUploadController;
import com.monsanto.wst.usseedplanning.utils.testutils.USSeedPlanningBaseTestCase;
import com.monsanto.wst.usseedplanning.view.factory.ViewFactory;
import com.monsanto.wst.usseedplanning.view.factory.mock.MockViewFactory;
import com.monsanto.wst.usseedplanning.services.mock.MockCommonUploadServiceImpl;
import com.monsanto.wst.usseedplanning.model.core.LoginUser;
import com.monsanto.wst.validator.HttpRequestErrors;
import com.monsanto.wst.validator.HttpValidator;
import com.monsanto.wst.validator.test.mock.MockHttpValidator;
import com.monsanto.wst.view.test.mock.MockView;

import java.io.File;
import java.io.IOException;

/**
 * Created by IntelliJ IDEA.
 * Date: Sep 22, 2006
 * Time: 8:50:12 PM
 * <p/>
 * Unit test for the CommonUploadController object.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class CommonUploadControllerUT extends USSeedPlanningBaseTestCase {
    public void testCreate() throws Exception {
        CommonUploadController controller = new CommonUploadController((ViewFactory) null, (MockCommonUploadServiceImpl)null, (HttpValidator) null);
        assertNotNull(controller);
    }

    public void testUnspecified() throws Exception {
        MockViewFactory viewFactory = new MockViewFactory();
	    MockCommonUploadServiceImpl service = new MockCommonUploadServiceImpl();
        CommonUploadController controller = new CommonUploadController(viewFactory, service, (HttpValidator) null);
        MockUCCHelper helper = new MockUCCHelper(null);
        controller.run(helper);
        MockView view = (MockView) viewFactory.getCommonUploadView();
        assertTrue(view.wasViewRendered());
    }

	public void testAddCommonUploadPlan() throws Exception {
	    MockViewFactory viewFactory = new MockViewFactory();
		MockHttpValidator validator = new MockHttpValidator();
		MockCommonUploadServiceImpl service = new MockCommonUploadServiceImpl();
	    CommonUploadController controller = new CommonUploadController(viewFactory, service, validator);
	    MockUCCHelper helper = new MockUCCHelper(null);
		helper.addClientFile("com/monsanto/wst/usseedplanning/services/mock/CommonUpload.xls");
	    helper.setRequestParameterValue("method", "addCommonUpload");
	    controller.run(helper);
	    MockView view = (MockView) viewFactory.getMaintenanceView();
	    assertTrue(view.wasViewRendered());
	}

    //TODO What are we testing ???
	public void testCommonUploadWithErrors() throws Exception {
	    MockViewFactory viewFactory = new MockViewFactory();
		HttpRequestErrors error = new HttpRequestErrors();
		error.addError("test_field", "test validator");
		MockHttpValidator validator = new MockHttpValidator(error);
	    CommonUploadController controller = new CommonUploadController(viewFactory, new MockCommonUploadWithErrors(), validator);
	    MockUCCHelper helper = new MockUCCHelper(null);
	    helper.setRequestParameterValue("method", "addCommonUpload");
	    controller.run(helper);
	    MockView view = (MockView) viewFactory.getCommonUploadView();
	    assertTrue(view.wasViewRendered());
	}
	private class MockCommonUploadWithErrors extends MockCommonUploadServiceImpl {
		public void addCommonUpload(File spreadsheet, String columnName, LoginUser loginUser, String comments) throws
			IOException {
			throw new IOException();
		}
	}
}