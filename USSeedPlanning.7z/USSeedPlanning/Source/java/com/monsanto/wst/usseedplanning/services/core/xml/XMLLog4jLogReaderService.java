package com.monsanto.wst.usseedplanning.services.core.xml;

import com.monsanto.wst.usseedplanning.services.core.LogReaderException;
import com.monsanto.wst.usseedplanning.services.core.LogReaderService;
import com.monsanto.wst.commonutils.xml.XMLUtilities;
import com.monsanto.wst.commonutils.xml.XMLParserException;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import java.io.File;
import java.io.FilenameFilter;
import java.util.Arrays;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * Date: Apr 7, 2006
 * Time: 8:02:00 AM
 * <p/>
 * This class is an log4j.xml implementation of the LogReaderService.  It provides access to log configuration files in
 * order to retrieve log information.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class XMLLog4jLogReaderService implements LogReaderService {

    private static final Log log = LogFactory.getLog(XMLLog4jLogReaderService.class);
    private File baseLogFile;
    private FilenameFilter baseFilenameFilter;

    /**
     * This constructor takes the path to the log4j.xml file and an XML utility object.
     *
     * @param log4jPath String representing the path to the log4j.xml file.
     * @param xmlUtils XMLUtilities representing an xml utility object.
     */
    public XMLLog4jLogReaderService(String log4jPath, XMLUtilities xmlUtils) {
        try {
            parseLog4jXML(xmlUtils, log4jPath);
        } catch (XMLParserException e) {
            if (log.isErrorEnabled()) {
                log.error("Unable to parse the log4j xml file at location: " + log4jPath, e);
            }
            throw new LogReaderException("Unable to parse the log4j xml file at location: " + log4jPath);
        }
        if (this.baseLogFile == null) {
            throw new LogReaderException("Unable to find target log file defined in: " + log4jPath);
        }
        this.baseFilenameFilter = new BaseLogFileNameFilter(this.baseLogFile.getName());
    }

    /**
     * This method returns a list of log files based on configuration settings in the log4j.xml file.
     *
     * @return List (of Strings) representing the log file names.
     */
    public List getLogFileList() {
        File[] files = this.baseLogFile.getParentFile().listFiles(this.baseFilenameFilter);
        return Arrays.asList(files);
    }

    /**
     * This method returns the log file with the specified name.
     *
     * @param fileName String representing the name of the log file.
     * @return File - Object representing the log file.
     */
    public File getLogFile(String fileName) {
        File file = new File(this.baseLogFile.getParentFile(), fileName);
        if (file.exists()) {
            return file;
        }
        return null;
    }

    /**
     * This method parses the log4j.xml file and sets the base log file.
     *
     * @param xmlUtils XMLUtilities object representing xml utility methods.
     * @param log4jPath String representing the path to the log4j.xml file.
     * @throws XMLParserException - If unable to parse the log4j.xml file.
     */
    private void parseLog4jXML(XMLUtilities xmlUtils, String log4jPath) throws XMLParserException {
        Document log4jXML = xmlUtils.createDocument(log4jPath);
        NodeList appenderList = log4jXML.getElementsByTagName("appender");
        for (int i = 0; appenderList != null && i < appenderList.getLength(); i++) {
            Element appender = (Element) appenderList.item(i);
            File logFile = lookupLogFile(appender);
            if (logFile != null && logFile.exists()) {
                this.baseLogFile = logFile;
            }
        }
    }

    /**
     * This method checks the current appender element for the file parameter and returns a file object if found.
     *
     * @param appender Element object representing the current appender.
     * @return File - Object representing the current application log file.
     */
    private File lookupLogFile(Element appender) {
        NodeList paramList = appender.getElementsByTagName("param");
        for (int j = 0; paramList != null && j < paramList.getLength(); j++) {
            Element param = (Element) paramList.item(j);
            if (param != null && "File".equals(param.getAttribute("name"))) {
                String logFileLoc = param.getAttribute("value");
                if (StringUtils.isNotEmpty(logFileLoc)) {
                    if (isTomcat(logFileLoc)) {
                        logFileLoc = resolveTomcatLogLocation(logFileLoc);
                    }
                    return new File(logFileLoc);
                }
            }
        }

        return null;
    }

    /**
     * This method checks if the log file is specified using a tomcat specific system property.
     *
     * @param logFileLoc String representing the location of the log file.
     * @return boolean - Representing if there are tomcat spcecific system properties referenced.
     */
    private boolean isTomcat(String logFileLoc) {
        return logFileLoc.indexOf("${catalina.home}") != -1;
    }

    /**
     * This method resolves the absolute path to the log file if a tomcat specific system property is used.
     *
     * @param logFileLoc String representing the path to the log file.
     * @return String - Representing the updated path to the log file.
     */
    private String resolveTomcatLogLocation(String logFileLoc) {
        String catalinaHome = System.getProperty("catalina.home");
        if (catalinaHome == null) {
            throw new LogReaderException("There is not a catalina.home system property set, check your server configuration.");
        }
        catalinaHome = catalinaHome.replaceAll("\\\\", "/");
        return logFileLoc.replaceAll("(\\$\\{catalina.home\\})", catalinaHome);
    }

    /**
     * This inner class is used to filter out all files except for ones that contain a certain string in the name.
     */
    private class BaseLogFileNameFilter implements FilenameFilter {

        private String baseFileName;

        /**
         * This constructor takes a base file name which will be used to filter files.
         *
         * @param baseFileName String representing the base file name.
         */
        public BaseLogFileNameFilter(String baseFileName) {
            this.baseFileName = baseFileName;
        }

        /**
         * This method returns true if the current file contains the base file name in it's name.
         *
         * @param dir File representing the directory being scanned.
         * @param name String representing the current file name.
         * @return boolean - Representing whether the name contains the base file name.
         */
        public boolean accept(File dir, String name) {
            return name != null && name.indexOf(this.baseFileName) > -1;
        }

    }

}
