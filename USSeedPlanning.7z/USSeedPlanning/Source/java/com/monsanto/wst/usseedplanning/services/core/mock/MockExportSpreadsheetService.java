package com.monsanto.wst.usseedplanning.services.core.mock;

import com.monsanto.wst.usseedplanning.services.core.ExportSpreadsheetService;
import com.monsanto.wst.usseedplanning.model.planning.Plan;

import java.io.IOException;

/**
 * Created by IntelliJ IDEA.
 * Date: Sep 22, 2006
 * Time: 7:40:26 PM
 * <p/>
 * Mock object used for testing.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class MockExportSpreadsheetService implements ExportSpreadsheetService {
  private boolean wasRetrieved = false;

  public byte[] getPlanSpreadsheet(Plan plan) throws IOException {
    wasRetrieved = true;
    return new byte[0];
  }

  public boolean wasPlanRetrieved() {
    return this.wasRetrieved;
  }
}
