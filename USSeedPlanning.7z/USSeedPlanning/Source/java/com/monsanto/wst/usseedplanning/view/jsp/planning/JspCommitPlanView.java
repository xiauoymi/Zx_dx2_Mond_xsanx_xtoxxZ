/*
 JspCommitPlanView was created on Oct 12, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.usseedplanning.view.jsp.planning;

import com.monsanto.wst.view.View;
import com.monsanto.wst.view.ViewRenderingException;
import com.monsanto.wst.usseedplanning.constants.MainConstants;
import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.AbstractLogging.LoggableError;

import java.io.IOException;

/**
 * Filename:    $RCSfile: JspCommitPlanView.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ffbrac $    	 On:	$Date: 2006-10-12 16:24:10 $
 *
 * @author ffbrac
 * @version $Revision: 1.1 $
 */
public class JspCommitPlanView implements View {
	public void renderView(UCCHelper helper) throws ViewRenderingException {
	    try {
	        helper.forward(MainConstants.COMMIT_PLAN_PAGE);
	    } catch (IOException e) {
	        if (Logger.isEnabled(Logger.ERROR_LOG)) {
	            Logger.log(new LoggableError(e));
	        }
	        throw new ViewRenderingException("Unable to Render View");
	    }
	}
}