/*
 LookupServiceImpl was created on Oct 24, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.usseedplanning.services.core;

import com.monsanto.wst.usseedplanning.dao.LookupDao;
import com.monsanto.wst.usseedplanning.exception.NoResultsException;
import com.monsanto.wst.usseedplanning.model.planning.Plan;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import java.util.Date;
import java.util.List;

/**
 * Filename:    $RCSfile: LookupServiceImpl.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ffbrac $    	 On:	$Date: 2006-10-31 20:53:46 $
 *
 * @author ffbrac
 * @version $Revision: 1.3 $
 */
public class LookupServiceImpl implements LookupService{
	private LookupDao lookupDao;
	private static final Log log = LogFactory.getLog(LookupServiceImpl.class);

	public LookupServiceImpl(LookupDao lookupDao) {
		this.lookupDao = lookupDao;
	}

	public Date lookupLastRevisionDate(){
		try{
			return lookupDao.lookupLastRevisionDate();
		}catch(NoResultsException ex){
			if (log.isWarnEnabled()) {
			    log.warn("Unable to find the latest revision date...'" );
			}
			return null;
		}
	}

	public String lookupReleaseTrackingValue() {
		try{
			return lookupDao.lookupReleaseTrackingValue();
		}catch(NoResultsException ex){
			if (log.isWarnEnabled()) {
			    log.warn("Unable to find the release tracking value...'" );
			}
			return null;
		}
	}

	public List lookupPlanRevisionList() {
		return lookupDao.lookupPlanRevisionList();
	}

	public List lookupGeneratedPlanComponents(Long planId) {
		return lookupDao.lookupGeneratedPlanComponents(planId);
	}

	public List lookupPlanListByPlanTypeName(String planTypeName) {
		return lookupDao.lookupPlanListByPlanTypeName(planTypeName);
	}

	public Plan lookupPlanByPlanId(Long planId) {
		try{
			return lookupDao.lookupPlanByPlanId(planId);
		}catch(NoResultsException ex){
			if (log.isWarnEnabled()) {
			    log.warn("Unable to find the plan entry based on planId" );
			}
			return null;
		}
	}

	public List lookupPlanDetailsByPlanId(Long planId) {
		return lookupDao.lookupPlanDetailsByPlanId(planId);
	}
}