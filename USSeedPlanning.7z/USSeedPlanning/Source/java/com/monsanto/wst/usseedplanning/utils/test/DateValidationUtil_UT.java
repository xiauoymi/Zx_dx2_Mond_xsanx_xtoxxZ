package com.monsanto.wst.usseedplanning.utils.test;

import com.monsanto.wst.usseedplanning.constants.ErrorConstants;
import com.monsanto.wst.usseedplanning.utils.DateValidationUtil;
import junit.framework.TestCase;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Aug 4, 2006
 * Time: 8:35:27 AM
 * To change this template use File | Settings | File Templates.
 */
public class DateValidationUtil_UT extends TestCase {

    List errorList = new ArrayList();

    public void testCreate() throws Exception {
        DateValidationUtil util = new DateValidationUtil();
        assertNotNull(util);
    }

    public void testValidateEmptyDateString() throws Exception {
        DateValidationUtil.validDateEnteredAndGetErrorMessage("",errorList);
        assertEquals(0, errorList.size());
    }

    public void testValidateNullDateString() throws Exception {
        DateValidationUtil.validDateEnteredAndGetErrorMessage(null,errorList);
        assertEquals(0, errorList.size());
    }

    public void testValidateCorrectDateSequence() throws Exception {
        DateValidationUtil.validDateEnteredAndGetErrorMessage("10/10/2006",errorList);
        assertEquals(0, errorList.size());
    }

    public void testValidateWrongDateFormat() throws Exception {
        DateValidationUtil.validDateEnteredAndGetErrorMessage("10/2006",errorList);
        assertEquals(1, errorList.size());
        assertEquals(ErrorConstants.INVALID_DATE_FORMAT_ERROR_MESSAGE, errorList.get(0));
    }

    public void testValidateIncorrectMonth() throws Exception {
        DateValidationUtil.validDateEnteredAndGetErrorMessage("23/10/2006",errorList);
        assertEquals(1, errorList.size());
        assertEquals(ErrorConstants.INVALID_DATE_ERROR_MESSAGE, errorList.get(0));
    }

    public void testValidateIncorrectDay() throws Exception {
        DateValidationUtil.validDateEnteredAndGetErrorMessage("05/32/2006",errorList);
        assertEquals(1, errorList.size());
        assertEquals(ErrorConstants.INVALID_DATE_ERROR_MESSAGE, errorList.get(0));
    }

    public void testValidateIncorrectDayLessThan2Characers() throws Exception {
        DateValidationUtil.validDateEnteredAndGetErrorMessage("05/1/2006",errorList);
        assertEquals(1, errorList.size());
        assertEquals(ErrorConstants.INVALID_DATE_ERROR_MESSAGE, errorList.get(0));
    }

    public void testValidateIncorrectYear() throws Exception {
        DateValidationUtil.validDateEnteredAndGetErrorMessage("05/25/20121215",errorList);
        assertEquals(1, errorList.size());
        assertEquals(ErrorConstants.INVALID_DATE_ERROR_MESSAGE, errorList.get(0));
    }

    public void testCorrectDateSequence() throws Exception {
        DateValidationUtil.validDateSequencesEntered("05/25/2000","10/10/2001",errorList);
        assertEquals(0, errorList.size());
    }

    public void testInCorrectDateSequence() throws Exception {
        DateValidationUtil.validDateSequencesEntered("05/25/2001","10/10/1996",errorList);
        assertEquals(1, errorList.size());
        assertEquals(ErrorConstants.DATE_SEQUENCE_ERROR_MESSAGE, errorList.get(0));
    }

    public void testIncorrectDatesEnteredInComparingDateSequence() throws Exception {
        DateValidationUtil.validDateSequencesEntered("052","10/10/1996",errorList);
        assertEquals(1, errorList.size());
        assertEquals(ErrorConstants.INVALID_DATE_ERROR_MESSAGE, errorList.get(0));
    }

    public void testEmptyDatesForComparingDateSequence() throws Exception {
        DateValidationUtil.validDateSequencesEntered("","",errorList);
        assertEquals(0, errorList.size());
    }

    public void testNullDatesForComparingDateSequence() throws Exception {
        DateValidationUtil.validDateSequencesEntered(null,null,errorList);
        assertEquals(0, errorList.size());
    }

    public void testConvertDateToString() throws Exception {
        String convertedDate = DateValidationUtil.convertDateToString(DateValidationUtil.convertStringToDate("10/10/2006"));
        assertEquals("10/10/2006", convertedDate);
    }

    public void testConvertNullDateToString() throws Exception {
        String convertedDate = DateValidationUtil.convertDateToString(null);
        assertEquals("", convertedDate);
    }

    public void testConvertEmptyStringToDate() throws Exception {
        Date convertedDate = DateValidationUtil.convertStringToDate("");
        assertEquals(null, convertedDate);
    }

    public void testConvertNullStringToDate() throws Exception {
        Date convertedDate = DateValidationUtil.convertStringToDate(null);
        assertEquals(null, convertedDate);
    }

    public void testConvertCorrectStringToDate() throws Exception {
        Date convertedDate = DateValidationUtil.convertStringToDate("10/10/2006");
        assertEquals(DateValidationUtil.convertStringToDate("10/10/2006"), convertedDate);
    }

    public void testConvertInvalidDateStringToDate() throws Exception {
        Date convertedDate = DateValidationUtil.convertStringToDate("123ABC");
        assertNull(null, convertedDate);
    }
}
