/*
 PlanValidator was created on Sep 25, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.usseedplanning.controller.validator;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.wst.validator.HttpRequestErrors;
import com.monsanto.wst.validator.HttpValidator;
import org.apache.commons.lang.StringUtils;

import java.io.IOException;

/**
 * Created by IntelliJ IDEA.
 * Date: Aug 15, 2006
 * Time: 9:59:55 AM
 * <p/>
 * This class is used to validate common forecast requests.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class PlanValidator implements HttpValidator {
    public HttpRequestErrors validate(UCCHelper helper) throws IOException {
        HttpRequestErrors errors = new HttpRequestErrors();
//	    String plan_name = helper.getRequestParameterValue("plan_name");
//	    if (StringUtils.isEmpty(plan_name)) {
//	        errors.addError("plan name", "Plan Name should not be left empty.");
//	    }
/*
	    String description = helper.getRequestParameterValue("desciption");
	    if (StringUtils.isEmpty(description)) {
	        errors.addError("description", "Description should not be left empty.");
	    }
*/
        return errors;
    }
}