package com.monsanto.wst.usseedplanning.services.planning.mock;

import com.monsanto.wst.usseedplanning.model.core.LoginUser;
import com.monsanto.wst.usseedplanning.model.maintenance.Revision;
import com.monsanto.wst.usseedplanning.model.planning.DemandCriteria;
import com.monsanto.wst.usseedplanning.model.planning.Plan;
import com.monsanto.wst.usseedplanning.model.planning.PlanCriteria;
import com.monsanto.wst.usseedplanning.model.planning.PlanSummary;
import com.monsanto.wst.usseedplanning.services.planning.PlanService;

import java.util.ArrayList;
import java.util.List;
import java.io.File;
import java.io.IOException;

/**
 * Created by IntelliJ IDEA.
 * Date: Sep 22, 2006
 * Time: 8:11:16 PM
 * <p/>
 * Mock object used for testing.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class MockPlanService implements PlanService {
  private Plan plan = new Plan();
  private boolean cacheUpdated = false;
  private String savedComments;
  private Long planRevisionId;
  private Long planId;
  private LoginUser currentUser;

  public void generatePlan(PlanSummary summary, PlanCriteria criteria, LoginUser currentUser) {
  }

  public Plan lookupPlanByCriteria(PlanCriteria criteria) {
    plan.setPlanCriteria(new PlanCriteria());
    plan.getPlanCriteria().addDemandCriteria(new DemandCriteria(new Long(101), new Long(100)));
    plan.setSupplyRevision(new Revision(new Long(101)));
    return plan;
  }

    public Plan lookupPlanSummaryByCriteria(PlanCriteria criteria) {
      return lookupPlanByCriteria(criteria);
    }

    public void savePlan(File planSpreadsheet, LoginUser loginUser, String comments) throws IOException {
      this.savedComments = comments;
    }

  public List lookupAllPlans() {
    return null;
  }

  public List lookupPlansByPlanType(Long planTypeId) {
    return new ArrayList();
  }

  public void commitPlan(LoginUser loginUser, String comments, Long planRevisionId, Long planId) throws IOException {
    this.planId = planId;
    this.planRevisionId = planRevisionId;
    this.savedComments = comments;
    this.currentUser = loginUser;
  }

  public boolean isCacheUpToDate() {
    return this.cacheUpdated;
  }

  public String getSavedComments() {
    return savedComments;
  }

  public Long getPlanRevisionId() {
    return planRevisionId;
  }

  public Long getPlanId() {
    return planId;
  }

  public LoginUser getCurrentUser() {
    return currentUser;
  }
}
