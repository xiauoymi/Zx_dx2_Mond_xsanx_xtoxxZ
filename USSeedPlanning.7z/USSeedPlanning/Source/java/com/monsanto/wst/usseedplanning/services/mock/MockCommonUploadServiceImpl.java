/*
 MockCommonUploadServiceImpl was created on Oct 10, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.usseedplanning.services.mock;

import com.monsanto.wst.usseedplanning.services.maintenance.CommonUploadService;
import com.monsanto.wst.usseedplanning.model.core.LoginUser;
import com.monsanto.wst.usseedplanning.model.planning.ProductNameDetail;

import java.io.File;
import java.io.IOException;
import java.util.List;

/**
 * Filename:    $RCSfile: MockCommonUploadServiceImpl.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: uukola $
 * On:	$Date: 2007-02-23 23:09:18 $
 *
 * @author ffbrac
 * @version $Revision: 1.3 $
 */
public class MockCommonUploadServiceImpl implements CommonUploadService {
  public void addCommonUpload(File spreadsheet, String columnName, LoginUser loginUser, String comments) throws
    IOException {
    return;
  }

  public List lookupBaseNamesForPCMNameUpdate(String tableName) {
    return null;
  }

  public List lookupPCMNamesForManufacturingNames(String tableName) {
    return null;
  }

  public List lookupPCMNamesForCommercialNames(String tableName) {
    return null;
  }

  public String lookupHighestRevisionPreCommercialName(String s) {
    return null;
  }

  public ProductNameDetail getBaseNameDetail(ProductNameDetail productDetail) {
    return null;
  }

  public void addNewPreCommercialNames(LoginUser loginUser, String table_name) {
  }

  public void addPreCommercialNamesForManufacturingNames(LoginUser loginUser, String tableName) {

  }

  public void addPreCommercialNamesForCommercialNames(LoginUser loginUser, String tableName) {

  }

  public void addPreCommercialNames(List pcmNameList, LoginUser loginUser, String tableName) {

  }
}