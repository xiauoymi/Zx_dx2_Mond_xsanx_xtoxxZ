package com.monsanto.wst.usseedplanning.exception;

/**
 * Created by IntelliJ IDEA.
 * Date: Aug 8, 2006
 * Time: 5:32:13 PM
 * <p/>
 * This class is a custom exception for reporting that there were no results.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class NoResultsException extends Exception {
    /**
     * This constructor takes an error message.
     *
     * @param message String representing the error message.
     */
    public NoResultsException(String message) {
        super(message);
    }
}
