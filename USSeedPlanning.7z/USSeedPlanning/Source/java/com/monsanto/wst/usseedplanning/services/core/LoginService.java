/*
 LoginService was created on Aug 15, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.usseedplanning.services.core;

import com.monsanto.wst.usseedplanning.model.core.LoginUser;
import com.monsanto.wst.usseedplanning.model.core.Role;

import java.util.List;

/**
 * Filename:    $RCSfile: LoginService.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: njminsh $    	 On:	$Date: 2006-12-22 19:20:29 $
 *
 * @author ffbrac
 * @version $Revision: 1.3 $
 */
public interface LoginService {
  LoginUser lookupUserById(String userId);

  boolean isAuthorized(String userId);

  List lookupUsersByRole(Role role);
}