/*
 FactorServiceImpl was created on Oct 3, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.usseedplanning.services.planning;

import com.monsanto.wst.usseedplanning.dao.FactorDao;

import java.util.List;

/**
 * Filename:    $RCSfile: FactorServiceImpl.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ffbrac $    	 On:	$Date: 2006-10-03 18:05:11 $
 *
 * @author ffbrac
 * @version $Revision: 1.1 $
 */
public class FactorServiceImpl implements FactorService{
	private FactorDao factorDao;
	public FactorServiceImpl(FactorDao factorDao) {
		this.factorDao = factorDao;
	}

	public List getQAFactorList() {
		return factorDao.getQAFactorList();
	}

	public List getYieldFactorList() {
		return factorDao.getYieldFactorList();
	}
	public List getStageFactorList() {
		return this.factorDao.getStageFactorList();
	}
}