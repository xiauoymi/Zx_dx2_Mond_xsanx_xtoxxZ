/*
 UserRoleServiceImpl was created on Aug 22, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.usseedplanning.services.core;

import com.monsanto.wst.usseedplanning.dao.UserRoleDao;

import java.util.List;

/**
 * Filename:    $RCSfile: UserRoleServiceImpl.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ffbrac $    	 On:	$Date: 2006-08-22 21:50:42 $
 *
 * @author ffbrac
 * @version $Revision: 1.1 $
 */
public class UserRoleServiceImpl implements UserRoleService{
	private UserRoleDao userRoleDao;
	public UserRoleServiceImpl(UserRoleDao userRoleDao){
		this.userRoleDao = userRoleDao;
	}
	public List getUserRoleList(String userId){
		return userRoleDao.getUserRoleList(userId);
	}
}