package com.monsanto.wst.usseedplanning.services.maintenance.forecast;

/**
 * Created by IntelliJ IDEA.
 * Date: Sep 7, 2006
 * Time: 7:07:36 AM
 * <p/>
 * This class is a custom exception for reporting invalid forecasts.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class InvalidForecastException extends Exception {
    /**
     * This constructor takes a message.
     *
     * @param message String representing the error message.
     */
    public InvalidForecastException(String message) {
        super(message);
    }
}
