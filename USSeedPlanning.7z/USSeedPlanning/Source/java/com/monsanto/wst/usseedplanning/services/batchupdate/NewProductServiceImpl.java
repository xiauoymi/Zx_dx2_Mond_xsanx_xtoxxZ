/*
NewProductServiceImpl was created on Jan 17, 2007 using Monsanto
resources and is the sole property of Monsanto.  Any duplication of the
code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.usseedplanning.services.batchupdate;

import com.monsanto.wst.usseedplanning.dao.BatchDao;
import com.monsanto.wst.usseedplanning.model.cache.ProductDetails;

import java.util.Iterator;
import java.util.List;

/**
 * Filename:    $RCSfile: NewProductServiceImpl.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: njminsh $    	 On:	$Date: 2007-01-31 21:55:33 $
 *
 * @author vrbethi
 * @version $Revision: 1.5 $
 */
public class NewProductServiceImpl implements NewProductService{
    private BatchDao batchDao;

    public NewProductServiceImpl(BatchDao batchDao) {
        this.batchDao = batchDao;
    }

    /**
     * For each product from lexicon look up the cache entry for the provided name
     * from the cache entry check for manual over rides
     * if male manual over ride and lexicon return is fabricated then replace fabricated
     * entries with manual overides.
     * @param productDetailsList List that is got from lexicon Service
     */
    public void preserveEntries(List productDetailsList) {
        Iterator iterator = productDetailsList.iterator();
        while(iterator.hasNext()){
            ProductDetails lexiconProductDetails = (ProductDetails) iterator.next();
            String providedName = lexiconProductDetails.getProvidedName();
            System.out.println("providedName = " + providedName);
            List list = batchDao.lookUpProductDetailsForProvidedName(providedName);
            //TODO check if only one product is return or not
            if(list.size()>0){
                ProductDetails cacheProductDetails = (ProductDetails) list.get(0);
                prevserveMaleEntries(lexiconProductDetails, cacheProductDetails);
                prevserveFemalEntries(lexiconProductDetails, cacheProductDetails);
            }
        }
    }

    private void prevserveFemalEntries(ProductDetails lexiconProductDetails, ProductDetails cacheProductDetails) {
        if(isLexiconFemaleEntryGenerated(lexiconProductDetails) && isCacheFemaleEntryManual(cacheProductDetails)){
            lexiconProductDetails.replaceFemaleParents(cacheProductDetails);
        }
    }

    private void prevserveMaleEntries(ProductDetails lexiconProductDetails, ProductDetails cacheProductDetails) {
        if(isLexiconMaleEntryGenerated(lexiconProductDetails) &&
            isCacheMaleEntryManual(cacheProductDetails)){
            lexiconProductDetails.replaceMaleParentDetails(cacheProductDetails);
        }
    }

    private boolean isCacheFemaleEntryManual(ProductDetails cacheProductDetails) {
        return isParentManual(getFemaleParent(cacheProductDetails));
    }

    private boolean isLexiconFemaleEntryGenerated(ProductDetails lexiconProductDetails) {
        return isParentEntryGenerated(getFemaleParent(lexiconProductDetails));
    }

    private ProductDetails getFemaleParent(ProductDetails lexiconProductDetails) {
        return lexiconProductDetails.getFemaleParent();
    }

    private boolean isCacheMaleEntryManual(ProductDetails cacheProductDetails) {
        return isParentManual(getMaleParent(cacheProductDetails));
    }

    private boolean isLexiconMaleEntryGenerated(ProductDetails lexiconProductDetails) {
        return isParentEntryGenerated(getMaleParent(lexiconProductDetails));
    }

    private ProductDetails getMaleParent(ProductDetails cacheProductDetails) {
        return cacheProductDetails.getMaleParent();
    }

    private boolean isParentManual(ProductDetails parent) {
        return parent.getOverrideFlag().equalsIgnoreCase(ProductDetails.MANUAL_OVERRIDE_FLAG);
    }

    private boolean isParentEntryGenerated(ProductDetails parent) {
        boolean isParentOverideFlagSet;
        if(parent==null){
            isParentOverideFlagSet=true;
        }else{
            isParentOverideFlagSet = parent.getOverrideFlag().equalsIgnoreCase(ProductDetails.GENERATED_OVERRIDE_FLAG);
        }
        return isParentOverideFlagSet;
    }
}