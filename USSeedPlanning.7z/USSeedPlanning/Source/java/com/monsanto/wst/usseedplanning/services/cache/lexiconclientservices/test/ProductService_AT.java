/*
 ProductService_AT was created on Oct 1, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.usseedplanning.services.cache.lexiconclientservices.test;

import com.monsanto.wst.factory.AbstractGenericFactory;
import com.monsanto.wst.usseedplanning.services.cache.lexiconclientservices.LexiconProductServiceImpl;
import com.monsanto.wst.usseedplanning.services.cache.lexiconclientservices.ProductService;
import com.monsanto.wst.usseedplanning.utils.testutils.USSeedPlanningBaseTestCase;

/**
 * Filename:    $RCSfile: ProductService_AT.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: njminsh $    	 On:	$Date: 2007-01-31 22:39:38 $
 *
 * @author VRBETHI
 * @version $Revision: 1.1 $
 */
public class ProductService_AT extends USSeedPlanningBaseTestCase {
    private ProductService productService;
    private String originalLsi = System.getProperty("lsi.function");

    protected void setUp() throws Exception {
        super.setUp();
        System.setProperty("lsi.function", "test");
        productService  = (LexiconProductServiceImpl) AbstractGenericFactory.getInstance().getBean("productService");
    }

    protected void tearDown() throws Exception {
        System.setProperty("lsi.function", originalLsi);
        super.tearDown();
    }

    public void testGetPreCommercialNameFromCommercialName() throws Exception {
        String preCommercialName = productService.getPreCommercialNameFromCommercialName("DK440");
        assertEquals("EXP744", preCommercialName);
    }

    public void testGetProductDetailsListByPreCommercialName() throws Exception {
        //Todo...Write this test. (Since the correct schema is not available yet this test cannot be completed)
    }

    public void testGetProductDetailsListByManufacturingName() throws Exception {
        //Todo...Write this test. (Since the correct schema is not available yet this test cannot be completed)
    }
}