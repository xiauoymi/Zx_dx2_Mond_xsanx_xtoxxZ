/*
DashboardReport_UT was created on Aug 31, 2006 using Monsanto
resources and is the sole property of Monsanto.  Any duplication of the
code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.usseedplanning.reports.tests;

import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.wst.commonutils.xml.XPathUtils;
import com.monsanto.wst.commonutils.xml.XalanXPathUtils;
import com.monsanto.wst.factory.AbstractGenericFactory;
import com.monsanto.wst.factory.GenericFactory;
import com.monsanto.wst.reportingframework.core.AbstractReport;
import com.monsanto.wst.reportingframework.core.ReportParameters;
import com.monsanto.wst.usseedplanning.constants.MainConstants;
import com.monsanto.wst.usseedplanning.utils.testutils.USSeedPlanningBaseTransactionTestCase;
import com.monsanto.wst.dbtemplate.transaction.TransactionManager;
import org.w3c.dom.Document;

/**
 * Filename:    $RCSfile: DashboardReportCommonUploadsAT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: njminsh $    	 On:	$Date: 2007-02-15 22:46:26 $
 *
 * @author ffbrac
 * @version $Revision: 1.6 $
 */
public class DashboardReportCommonUploadsAT extends USSeedPlanningBaseTransactionTestCase {

    public void testDashboardReportOnlyDemandAndSupply() throws Exception {
        GenericFactory container = AbstractGenericFactory.getInstance();
        AbstractReport abstractReport = (AbstractReport) container.getBean("dashboardReport");
        XPathUtils xPathUtils = new XalanXPathUtils();
        ReportParameters reportParameters = new ReportParameters();
        reportParameters.add(MainConstants.FOUNDATION_PLANNING,"SET");
        reportParameters.add(MainConstants.HYBRID_PLANNING,"SET");
        Document document = abstractReport.buildReportXML(reportParameters, null);
        DOMUtil.outputXML(document);
        assertNotNull(document);
        assertEquals("01/01/2006",xPathUtils.evalToString(document,"/dashboard/data/row[position()=last()]/date"));
        assertEquals("DBUNIT",xPathUtils.evalToString(document,"/dashboard/data/row[position()=last()]/user"));
        assertEquals("CL - Actual Licensee Summer Production",xPathUtils.evalToString(document,"/dashboard/data/row[position()=last()]/value"));
//        //this is actually operation
        assertEquals("Common Uploads",xPathUtils.evalToString(document,"/dashboard/data/row[position()=last()]/description"));
        assertEquals("Adding Summer Production Common Upload",xPathUtils.evalToString(document,"/dashboard/data/row[position()=last()]/comment"));

        assertEquals("01/02/2006",xPathUtils.evalToString(document,"/dashboard/data/row[position()=last()-1]/date"));
        assertEquals("DBUNIT",xPathUtils.evalToString(document,"/dashboard/data/row[position()=last()-1]/user"));
        assertEquals("CM - Actual Licensee Winter Production",xPathUtils.evalToString(document,"/dashboard/data/row[position()=last()-1]/value"));
//        //this is actually operation
        assertEquals("Common Uploads",xPathUtils.evalToString(document,"/dashboard/data/row[position()=last()-1]/description"));
        assertEquals("Adding Winter Production Common Upload",xPathUtils.evalToString(document,"/dashboard/data/row[position()=last()-1]/comment"));
    }

    protected String getConfigPath() {
        return "com/monsanto/wst/usseedplanning/reports/tests/dbunit/commonuploads.xml";
    }

    protected void cleanDatabase(TransactionManager txManager) {
    }

}