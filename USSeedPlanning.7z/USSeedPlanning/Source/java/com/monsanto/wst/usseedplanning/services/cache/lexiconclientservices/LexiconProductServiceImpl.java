/*
 LexiconProductServiceImpl was created on Oct 1, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.usseedplanning.services.cache.lexiconclientservices;

import com.monsanto.POSClient.POSConnection;
import com.monsanto.POSClient.POSResult;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.w3c.dom.Document;

import java.util.List;

/**
 * Filename:    $RCSfile: LexiconProductServiceImpl.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: vrbethi $    	 On:	$Date: 2007-03-09 16:18:19 $
 *
 * @author VRBETHI
 * @version $Revision: 1.2 $
 */
public class LexiconProductServiceImpl implements ProductService {
  private static final Log log = LogFactory.getLog(LexiconProductServiceImpl.class);
  private static final String LEXICON_SERVICE_GET_AGGREGATE_PRODUCT = "Lex_GetAggregateProduct";
  private static final String LEXICON_SERVICE_GET_PRODUCT_PARENTS_BY_PRECOMMERCIAL_NAME = "Lex_ProductParentsByPreComlName";
  private static final String LEXICON_SERVICE_GET_PRODUCT_PARENTS_BY_MANUFACTURING_NAME = "Lex_ProductParentsByManfName";

  private POSConnection posConnection;
  private ProductServiceRequestGenerator requestGenerator;
  private ProductServiceResponseParser responseParser;

  public LexiconProductServiceImpl(POSConnection posConnection, ProductServiceRequestGenerator requestGenerator, ProductServiceResponseParser responseParser) {
    this.posConnection = posConnection;
    this.requestGenerator = requestGenerator;
    this.responseParser = responseParser;
  }

  public String getPreCommercialNameFromCommercialName(String commercialName) throws Exception {
    if (log.isDebugEnabled()) {
      log.debug("Connection to Lex_GetAggregateProduct service with commercial name: '" + commercialName + "'");
    }
    Document requestDocument = requestGenerator.getRequestDocumentForGetAggregateProductService(commercialName);
    POSResult posResult = null;
    posResult = callService(requestDocument, commercialName, LEXICON_SERVICE_GET_AGGREGATE_PRODUCT);
    return responseParser.getPreCommercialNameFromGetAggregateProductServiceResponse(posResult.getInputStream());
  }

  public List getProductDetailsListByPreCommercialName(String preCommercialName) throws Exception {
    if (log.isDebugEnabled()) {
      log.debug("Connection to Lex_ProductParentsByPreComlName service with precommercial name: '" + preCommercialName + "'");
    }
    Document requestDocument = requestGenerator.getRequestDocumentForProductParentsByPrecommercialNameService(preCommercialName);
    POSResult posResult = callService(requestDocument, preCommercialName, LEXICON_SERVICE_GET_PRODUCT_PARENTS_BY_PRECOMMERCIAL_NAME);
    return responseParser.getProductDetailsListFromProductParentsByPrecommercialNameServiceResponse(posResult.getInputStream());
  }

  public List getProductDetailsListByManufacturingName(String manufacturingName) throws Exception {
    if (log.isDebugEnabled()) {
      log.debug("Connection to Lex_ProductParentsByManfName service with manufacturing name: '" + manufacturingName + "'");
    }
    Document requestDocument = requestGenerator.getRequestDocumentForProductParentsByManufacturingNameService(manufacturingName);
    POSResult posResult = callService(requestDocument, manufacturingName, LEXICON_SERVICE_GET_PRODUCT_PARENTS_BY_MANUFACTURING_NAME);
    return responseParser.getProductDetailsListFromProductParentsByManufacturingNameServiceResponse(posResult.getInputStream());
  }

  private POSResult callService(Document requestDocument, String commercialName, String serviceName) throws LexiconProductServiceException {
    POSResult posResult;
    try {
      posResult = posConnection.callService(serviceName, requestDocument);
    } catch (Exception e) {
      throw new LexiconProductServiceException("Exception encountered connecting to "+serviceName+" for :"+commercialName,e);
    }
    return posResult;
  }
}