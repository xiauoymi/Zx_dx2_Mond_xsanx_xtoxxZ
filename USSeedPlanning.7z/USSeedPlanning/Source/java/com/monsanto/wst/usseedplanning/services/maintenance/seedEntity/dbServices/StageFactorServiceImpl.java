/*
 StageFactorServiceImpl was created on Sep 18, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.usseedplanning.services.maintenance.seedEntity.dbServices;

import com.monsanto.wst.commonutils.collection.CollectionUtil;
import com.monsanto.wst.usseedplanning.dao.RevisionDao;
import com.monsanto.wst.usseedplanning.dao.StageFactorDao;
import com.monsanto.wst.usseedplanning.exception.NoResultsException;
import com.monsanto.wst.usseedplanning.model.maintenance.Revision;
import com.monsanto.wst.usseedplanning.model.maintenance.Stage;
import com.monsanto.wst.usseedplanning.model.maintenance.StageFactor;
import com.monsanto.wst.usseedplanning.model.maintenance.Year;
import com.monsanto.wst.usseedplanning.services.maintenance.seedEntity.StageFactorService;
import com.monsanto.wst.usseedplanning.utils.factor.OrderOfPrecedenceBasedObjectComparator;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import java.util.*;

/**
 * Filename:    $RCSfile: StageFactorServiceImpl.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: jdpoul $
 * On:	$Date: 2006-10-25 17:49:40 $
 *
 * @author sspati1
 * @version $Revision: 1.5 $
 */
public class StageFactorServiceImpl implements StageFactorService {

  private static final String TARGET_YEAR_FIELD_NAME = "year.id";
  private static final String STAGE_FIELD_NAME = "stage.stageId";
  private static final String PRODUCT_NAME_FIELD_NAME = "productName";

  private static final Map ORDER_OF_PRECEDENCE_MAP = new HashMap();
  private static final Set FIELDS_TO_COMPARE_SET = new HashSet();

  static {
    ORDER_OF_PRECEDENCE_MAP.put(PRODUCT_NAME_FIELD_NAME, new Integer(3));
    ORDER_OF_PRECEDENCE_MAP.put(TARGET_YEAR_FIELD_NAME, new Integer(2));

    FIELDS_TO_COMPARE_SET.add(TARGET_YEAR_FIELD_NAME);
    FIELDS_TO_COMPARE_SET.add(STAGE_FIELD_NAME);
    FIELDS_TO_COMPARE_SET.add(PRODUCT_NAME_FIELD_NAME);

  }

  private static final Log log = LogFactory.getLog(StageFactorServiceImpl.class);
  private StageFactorDao stageFactorDao;
  private RevisionDao revisionDao;

  public StageFactorServiceImpl(StageFactorDao stageFactorDao, RevisionDao revisionDao) {
    this.stageFactorDao = stageFactorDao;
    this.revisionDao = revisionDao;
  }

  public List LookupAllStageFactors() {
    return this.stageFactorDao.lookupAll();
  }


  public StageFactor lookupStageFactorsByRevisionId(Long revisionId) {
    StageFactor stageFactor = null;
    try {
      stageFactor = this.stageFactorDao.lookupByRevisionId(revisionId);
      stageFactor.setRevision(this.revisionDao.lookupById(revisionId));
    } catch (NoResultsException e) {
      if (log.isWarnEnabled()) {
        log.warn("Unable to find a stage factor with revision id '" + revisionId);
      }
    }
    return stageFactor;
  }


  public void saveStageFactor(StageFactor stageFactor, String comments) {
    Revision revision = new Revision("Adding Stage Factor", comments, stageFactor.getLoginUser());
    this.revisionDao.insert(revision);
    stageFactor.setRevision(revision);
    this.stageFactorDao.insertStageFactor(stageFactor);
  }

  public List getAllApplicableStageFactorsInOrderOfPrecedence(String productNameCriteria, Long yearCriteria,
                                                              Long stageCriteria, Long maxRevisionId) {
    List unsortedStages = stageFactorDao.getAllApplicableStageFactors(maxRevisionId);
    if (unsortedStages.isEmpty()) {
      return unsortedStages;
    } else {
      List sortedFactors = sortFactorsByPrecedence(yearCriteria, stageCriteria, productNameCriteria,
          unsortedStages);
      return removeNotApplicableStageFactorsFromListSortedByPrecedence(sortedFactors);
    }
  }

  public StageFactor getMostAppropriateStageFactor(String productNameCriteria, Long yearCriteria,
                                                   Long stageCriteria, Long maxRevisionId) {
    List allApplicableStageFactors = getAllApplicableStageFactorsInOrderOfPrecedence(productNameCriteria,
        yearCriteria, stageCriteria, maxRevisionId);
    if (allApplicableStageFactors != null && allApplicableStageFactors.size() > 0) {
      return findFirstActiveTargetFactorInList(getAllApplicableStageFactorsInOrderOfPrecedence(
          productNameCriteria, yearCriteria, stageCriteria, maxRevisionId));
    } else {
      return null;
    }

  }

  public List removeNotApplicableStageFactorsFromListSortedByPrecedence(List sortedStages) {
    return CollectionUtil.truncateList(sortedStages, new IsDefaultAcceptTest());
  }

  private StageFactor findFirstActiveTargetFactorInList(List allApplicableStageFactorsInOrderOfPrecedence) {
    CollectionUtil.filter(allApplicableStageFactorsInOrderOfPrecedence, new IsActiveAcceptTest());
    if (allApplicableStageFactorsInOrderOfPrecedence != null &&
        allApplicableStageFactorsInOrderOfPrecedence.size() > 0) {
      return (StageFactor) allApplicableStageFactorsInOrderOfPrecedence.get(0);
    }
    return null;
  }


  private List sortFactorsByPrecedence(Long yearCriteria, Long stageCriteria, String productNameCriteria,
                                       List unsortedStages) {
    StageFactor compareTo = createShellStageFactorFromCriteria(yearCriteria, stageCriteria,
        productNameCriteria);

    return sortStagesByOrderOfPrecedence(compareTo, unsortedStages);
  }


  private List sortStagesByOrderOfPrecedence(StageFactor compareTo, List unsortedStages) {
    OrderOfPrecedenceBasedObjectComparator stageComparator = new OrderOfPrecedenceBasedObjectComparator();
    stageComparator.setFieldNamesToCompare(FIELDS_TO_COMPARE_SET);
    stageComparator.setDimensionComparisonOrderOfPrecedence(ORDER_OF_PRECEDENCE_MAP);


    stageComparator.setObjectToCompareTo(compareTo);

    Collections.sort(unsortedStages, stageComparator);
    return unsortedStages;
  }

  private StageFactor createShellStageFactorFromCriteria(Long yearCriteria, Long stageCriteria,
                                                         String productNameCriteria) {
    StageFactor compareTo = new StageFactor();
    compareTo.setProductName(productNameCriteria);
    Stage stage = new Stage();
    stage.setStageId(stageCriteria);
    Year year = new Year();
    year.setId(yearCriteria);
    compareTo.setStage(stage);
    compareTo.setYear(year);
    return compareTo;
  }

}