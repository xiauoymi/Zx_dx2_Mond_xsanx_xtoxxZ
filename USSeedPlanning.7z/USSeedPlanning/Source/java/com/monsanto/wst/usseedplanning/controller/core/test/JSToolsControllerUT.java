package com.monsanto.wst.usseedplanning.controller.core.test;

import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.wst.usseedplanning.controller.core.JSToolsController;
import com.monsanto.wst.usseedplanning.view.factory.ViewFactory;
import com.monsanto.wst.usseedplanning.view.factory.mock.MockViewFactory;
import com.monsanto.wst.view.test.mock.MockView;
import junit.framework.TestCase;

/**
 * Created by IntelliJ IDEA.
 * Date: Aug 17, 2006
 * Time: 2:38:18 PM
 * <p/>
 * Unit test for JSToolsController object.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class JSToolsControllerUT extends TestCase {
    public void testCreate() throws Exception {
        JSToolsController controller = new JSToolsController((ViewFactory) null);
        assertNotNull(controller);
    }

    public void testNotSpecified() throws Exception {
        MockViewFactory viewFactory = new MockViewFactory();
        JSToolsController controller = new JSToolsController(viewFactory);
        controller.run(new MockUCCHelper(null));
        assertTrue(((MockView) viewFactory.getJSConstantsView()).wasViewRendered());
    }
}
