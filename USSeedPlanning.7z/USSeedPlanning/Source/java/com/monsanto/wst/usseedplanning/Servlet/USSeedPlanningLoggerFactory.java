/*
 ExampleServletLoggerFactory was created on Jul 3, 2003 using Monsanto
 resources and is the sole property of Monsanto.  Any duplication of the
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.usseedplanning.Servlet;

import com.monsanto.AbstractLogging.LogDevice;
import com.monsanto.AbstractLogging.LogRegistrationException;
import com.monsanto.AbstractLogging.LoggableError;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.Log4JLogging.*;
import com.monsanto.XMLUtil.DOMUtil;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.apache.commons.lang.StringUtils;

import java.io.File;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;

/**
 * <p>Title: USSeedPlanningLoggerFactory</p>
 * <p>Description:
 * <p>Copyright: Copyright (c) 2005</p>
 * <p>Company: Monsanto</p>
 *
 * @author Java Framework Code  Generator 2.3
 * @version $Id: USSeedPlanningLoggerFactory.java,v 1.8 2007-01-29 22:55:03 njminsh Exp $
 */
public class USSeedPlanningLoggerFactory {
  private final String m_cstrAppName = "USSeedPlanning";
  private final String m_cstrTraceLogPath;
  private final String m_cstrRollingLogPath;
    private static final String LOGGER_PATTERN = "%d %-5r %-5p [%c{1}.%M]: %m%n";

    public USSeedPlanningLoggerFactory() {
        String cstrLogFolderName = "";
        if (StringUtils.isNotEmpty(System.getProperty("catalina.home"))) {
            cstrLogFolderName = System.getProperty("catalina.home") + File.separatorChar + "logs";
        } else {
            cstrLogFolderName = System.getProperty("catalina.base") + File.separatorChar + "logs";
        }
        System.out.println("log folder: '" + cstrLogFolderName + "'");

      m_cstrTraceLogPath = cstrLogFolderName + File.separatorChar + m_cstrAppName + "Trace.log";
      m_cstrRollingLogPath = cstrLogFolderName + File.separatorChar + m_cstrAppName + ".log";
    }

  public synchronized void setupLogging() throws IOException,
      LogRegistrationException {
    Logger.register(new Log4JTraceLog(m_cstrAppName, new Log4JFileLogDevice(m_cstrTraceLogPath)));

    LogDevice logDevice = new Log4JMidnightRollingFileLogDevice(LOGGER_PATTERN, m_cstrRollingLogPath);

    Logger.register(new Log4JDebugLog(m_cstrAppName, logDevice));
    Logger.register(new Log4JInfoLog(m_cstrAppName, logDevice));
    Logger.register(new Log4JWarningLog(m_cstrAppName, logDevice));
    Logger.register(new Log4JErrorLog(m_cstrAppName, logDevice));

// I can't define more than one log device, can somebody please shoot me?!
//    LogDevice consoleLogDevice = new Log4JConsoleLogDevice();
//    Logger.register(new Log4JDebugLog("detailed", consoleLogDevice));
//    Logger.register(new Log4JInfoLog("detailed", consoleLogDevice));
//    Logger.register(new Log4JWarningLog("detailed", consoleLogDevice));
//    Logger.register(new Log4JErrorLog("detailed", consoleLogDevice));
  }

  public Document toXML() {
    Logger.traceEntry();

    Document logDocument = DOMUtil.newDocument();
    Element rootElement = DOMUtil.addChildElement(logDocument, "LOGS");
    insertXML(rootElement);

    return (Document) Logger.traceExit(logDocument);
  }

  public void insertXML(Element parentElement) {
    Logger.traceEntry();

    try {
      addLogDeviceToXmlDocument(parentElement, "Rolling Log (Text)", m_cstrRollingLogPath);
      addLogDeviceToXmlDocument(parentElement, "Trace Log", m_cstrTraceLogPath);
    }
    catch (UnsupportedEncodingException uee) {
      Logger.log(new LoggableError(uee));
    }

    Logger.traceExit();
  }

  private void addLogDeviceToXmlDocument(Element parentElement, String deviceName, String filePath)
      throws UnsupportedEncodingException {
    Logger.traceEntry();

    if (filePath != null && (!filePath.trim().equals(""))) {
      Element deviceElement = DOMUtil.addChildElement(parentElement, "LOG_DEVICE");
      DOMUtil.addChildElement(deviceElement, "DEVICE_NAME", deviceName);
      DOMUtil.addChildElement(deviceElement, "LOCATION", URLEncoder.encode(filePath, "UTF-8"));
    } else {
      throw new IllegalArgumentException("filePath argument cannot be null, blank, or empty.");
    }

    Logger.traceExit();
  }
}
