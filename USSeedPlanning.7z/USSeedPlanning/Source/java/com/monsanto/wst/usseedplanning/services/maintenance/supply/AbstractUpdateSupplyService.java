package com.monsanto.wst.usseedplanning.services.maintenance.supply;

import com.monsanto.wst.usseedplanning.dao.ChannelDao;
import com.monsanto.wst.usseedplanning.dao.RevisionDao;
import com.monsanto.wst.usseedplanning.dao.SupplyTypeDao;
import com.monsanto.wst.usseedplanning.exception.NoResultsException;
import com.monsanto.wst.usseedplanning.model.core.LoginUser;
import com.monsanto.wst.usseedplanning.model.maintenance.Channel;
import com.monsanto.wst.usseedplanning.model.maintenance.ChannelCriteria;
import com.monsanto.wst.usseedplanning.model.maintenance.Revision;
import com.monsanto.wst.usseedplanning.model.maintenance.supply.SupplyType;

/**
 * Created by IntelliJ IDEA.
 * Date: Feb 12, 2007
 * Time: 3:22:17 PM
 * <p/>
 * TODO: Enter description for class.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public abstract class AbstractUpdateSupplyService implements UpdateSupplyService {
    private RevisionDao revisionDao;
    private ChannelDao channelDao;
    private SupplyTypeDao supplyTypeDao;

    public AbstractUpdateSupplyService(SupplyTypeDao supplyTypeDao, RevisionDao revisionDao, ChannelDao channelDao) {
        this.supplyTypeDao = supplyTypeDao;
        this.revisionDao = revisionDao;
        this.channelDao = channelDao;
    }

    protected Revision createRevision(String comments, LoginUser owner, String operation) {
        Revision revision = new Revision(operation, comments, owner);
        this.revisionDao.insert(revision);
        return revision;
    }

    protected Channel getChannel(Long planType, String channelName) {
        try {
            ChannelCriteria criteria = new ChannelCriteria(channelName, planType);
            return this.channelDao.lookupChannelByName(criteria);
        } catch (NoResultsException e) {
            throw new IllegalStateException("Unable to find channel: '" + channelName + "'.");
        }
    }

    /**
     * This method updates the supply type for the specified supply based on the name provided.
     *
     * @param supplyTypeName String representing the type of supply.
     */
    protected SupplyType lookupSupplyType(String supplyTypeName) {
        try {
            return this.supplyTypeDao.lookupByName(supplyTypeName);
        } catch (NoResultsException e) {
            throw new IllegalStateException("Unable to find a supply type with name '" + supplyTypeName + "'");
        }
    }

}
