package com.monsanto.wst.usseedplanning.services.cache.lexiconclientservices;

/**
 * Created by IntelliJ IDEA.
 * Date: Oct 17, 2006
 * Time: 7:34:17 AM
 * <p/>
 * This interface represents constants used by the Lexicon POS Service.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public interface LexiconServiceConstants {
  String XML_ELEMENT_PRODUCTS = "Products";
  String XML_ELEMENT_PRODUCT = "Product";
  String XML_ELEMENT_PRE_COMMERCIAL_NAME = "PreCommercialName";
  String XML_ELEMENT_RELATIONSHIP_ATTRS = "RelationshipAttributes";
  String XML_ELEMENT_MANUFACTUING_NAME = "ManufacturingName";
  String XML_ELEMENT_TRAIT_VERSION = "TraitVersion";
  String XML_ELEMENT_PRODUCTION_STATUS = "ProductionStatus";
  String XML_ELEMENT_PRODUCT_ALIASES = "ProductAliases";
  String XML_ELEMENT_PRODUCT_ALIAS = "ProductAlias";
  String XML_ELEMENT_COMMERCIAL_NAME = "CommercialName";
  String XML_ELEMENT_PRODUCT_RELATIONSHIP = "ProductRelationship";
  String XML_ELEMENT_CROP = "Crop";
  String XML_ELEMENT_BRAND = "Brand";
  String XML_ELEMENT_COUNTRY = "Country";
  String XML_ELEMENT_IS_DELETED = "IsDeleted";
  String XML_ELEMENT_STAGE = "Stage";
  String XML_ELEMENT_COMMERCIAL_MATURITY = "CommercialMaturity";
  String XML_ELEMENT_INBRED_HYBRID = "InbredHybrid";
  String XML_ELEMENT_HAS_FINISHED_GERMPLASM = "HasFinishedGermplasm";
  String XML_ELEMENT_PARENTS = "Parents";
  String XML_ELEMENT_PARENT = "Parent";
  String XML_ELEMENT_ROLE = "Role";
  String XML_ELEMENT_GERMPLASM = "Germplasms";
  String XML_ELEMENT_NAME_PUB_KEY = "NamePubkey";
  String XML_ELEMENT_PRODUCT_NAME = "ProductName";
  String XML_ELEMENT_PRODUCT_PUB_KEY = "ProductPubkey";
  String XML_ELEMENT_CROP_PUB_KEY = "CropPubkey";
  String XML_ELEMENT_CROP_NAME = "CropName";
  String XML_ELEMENT_BRAND_PUB_KEY = "BrandPubkey";
  String XML_ELEMENT_BRAND_NAME = "BrandName";
  String XML_ELEMENT_COUNTRY_PUB_KEY = "CountryPubkey";
  String XML_ELEMENT_COUNTRY_NAME = "CountryName";
  String XML_ELEMENT_PRE_COML_NAME = "PreComlName";
  String XML_ELEMENT_VARIETY_NAME = "VarietyName";
  String XML_ELEMENT_COMMERCIAL_TRAITS = "CommercialTraits";
  String XML_ELEMENT_STACK_ABBR = "StackAbbr";
  String XML_ELEMENT_TRANSGENIC_TRAITS = "TransgenicTraits";
  String XML_ELEMENT_IS_ACTIVE = "IsActive";
}
