package com.monsanto.wst.usseedplanning.controller.maintenance.seedEntity;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.wst.usseedplanning.constants.MainConstants;
import com.monsanto.wst.usseedplanning.constants.ControllerConstants;
import com.monsanto.wst.usseedplanning.model.maintenance.*;
import com.monsanto.wst.usseedplanning.model.core.LoginUser;
import com.monsanto.wst.usseedplanning.services.maintenance.seedEntity.*;
import com.monsanto.wst.usseedplanning.view.factory.ViewFactory;
import com.monsanto.wst.usseedplanning.controller.validator.QaThresholdFormValidator;
import com.monsanto.wst.usseedplanning.utils.transaction.TransactionUtils;
import com.monsanto.wst.view.View;
import com.monsanto.wst.validator.HttpRequestErrors;
import com.monsanto.wst.servletframework.AbstractDispatchController;
import com.monsanto.Util.StringUtils;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Aug 8, 2006
 * Time: 8:46:42 AM
 * To change this template use File | Settings | File Templates.
 */
public class QaThresholdFormController extends AbstractDispatchController {

    private ViewFactory viewFactory;
    private QaThresholdService qaThresholdService;
    private YearService yearService;
    private GenderService genderService;
    private QaThresholdTypeService typeService;
    private QaThresholdComparisonStrategyService comparisonStrategyService;

    private List successList = new ArrayList();
    private QaThresholdFormValidator validator = new QaThresholdFormValidator();

    public QaThresholdFormController(QaThresholdService qaThresholdService, ViewFactory viewFactory,
                                     YearService yearService, GenderService genderService,
                                     QaThresholdComparisonStrategyService comparisonStrategyService,
                                     QaThresholdTypeService typeService) {
        this.viewFactory = viewFactory;
        this.qaThresholdService = qaThresholdService;
        this.yearService = yearService;
        this.genderService = genderService;
        this.typeService = typeService;
        this.comparisonStrategyService = comparisonStrategyService;

    }

    protected void notSpecified(UCCHelper helper) throws IOException {
        displayQaThresholdFormView(helper);
    }

    public void displayQaThresholdFormView(UCCHelper helper) throws IOException {
        HttpRequestErrors errors = new HttpRequestErrors();
        View view = getQaThresholdView(helper, errors);
        view.renderView(helper);
    }

    public void formSubmittedSave(UCCHelper helper) throws IOException {
        HttpRequestErrors errors = validator.validate(helper);
        View view;
        if (errors.isEmpty()) {
            QaThreshold threshold = createQaThresholdFromUccHelper(helper);
            String comment = getCommentFromUccHelper(helper);
            try {
                qaThresholdService.saveEntity(threshold, comment);
            } catch (ServiceException e) {
                errors.addError(HttpRequestErrors.GLOBAL_ERROR, e.getMessage());
                view = getQaThresholdView(helper, errors);
                new TransactionUtils(helper).flagForRollback();
            }
            view = getQaThresholdView(helper, null);
        } else {
            QaThreshold threshold = createQaThresholdFromUccHelper(helper);
            setQaThresholdBeanIntoUccHelper(threshold, helper);
            view = getQaThresholdView(helper, errors);
        }
        view.renderView(helper);
    }

    public void formSubmittedUpdatePickLists(UCCHelper helper) throws IOException {
        QaThreshold threshold = createQaThresholdFromUccHelper(helper);
        String comment = getCommentFromUccHelper(helper);
        setCommentIntoUccHelper(comment, helper);
        setQaThresholdBeanIntoUccHelper(threshold, helper);
        View view = getQaThresholdView(helper, null);

        view.renderView(helper);
    }

    private View getQaThresholdView(UCCHelper helper, HttpRequestErrors errors) throws IOException {
        helper.setRequestAttributeValue(MainConstants.QaThresholdConstants.QA_THRESHOLD_COMPARISON_STRATEGY_PICK_LIST_ATTRIBUTE, getComparisonStrategies(helper));
        helper.setRequestAttributeValue(MainConstants.QaThresholdConstants.QA_THRESHOLD_TYPES_PICK_LIST_ATTRIBUTE, typeService.getActiveQaThresholdTypes());
        helper.setRequestAttributeValue(MainConstants.QaThresholdConstants.YEAR_PICK_LIST_ATTRIBUTE, yearService.getActiveYears());
        helper.setRequestAttributeValue(MainConstants.QaThresholdConstants.GENDERS_PICK_LIST_ATTRIBUTE, genderService.getActiveGenders());
        helper.setRequestAttributeValue(ControllerConstants.ERRORS_REQUEST_ATTRIBUTE, errors);
        return this.viewFactory.getQaThresholdFormView();
    }

    private void setQaThresholdBeanIntoUccHelper(QaThreshold threshold, UCCHelper helper) {
        helper.setRequestAttributeValue(MainConstants.QaThresholdConstants.QA_THRESHOLD_BEAN_PARAM_NAME, threshold);

    }


    private QaThreshold createQaThresholdFromUccHelper(UCCHelper helper) throws IOException {

        QaThreshold threshold = new QaThreshold();
        QaThresholdComparisonStrategy strategy = new QaThresholdComparisonStrategy();
        strategy.setId(getComparisonStrategyIdFromUccHelper(helper));
        Gender gender = new Gender();
        gender.setId(getGenderIdFromUccHelper(helper));
        Year year = new Year();
        year.setId(getYearIdFromUccHelper(helper));
        QaThresholdType type = new QaThresholdType();
        type.setId(getQaThresholdTypeIdFromUccHelper(helper));
        LoginUser user = (LoginUser) helper.getSessionParameter(MainConstants.LOGINUSER);
        threshold.setLoginUser(user);

        threshold.setGender(gender);
        threshold.setComparisonStrategy(strategy);
        threshold.setYear(year);
        threshold.setThresholdType(type);
        threshold.setActive(getActiveStateFromUccHelper(helper));
        threshold.setProductName(getProductNameFromUccHelper(helper));
        threshold.setValue(getValueFromUccHelper(helper));
        threshold.setLoginUser((LoginUser) helper.getSessionParameter(MainConstants.LOGINUSER));


        return threshold;

    }

    private String getValueFromUccHelper(UCCHelper helper) throws IOException {
        return helper.getRequestParameterValue(MainConstants.QaThresholdConstants.VALUE_PARAM_NAME);
    }

    private String getProductNameFromUccHelper(UCCHelper helper) throws IOException {
        return helper.getRequestParameterValue(MainConstants.QaThresholdConstants.PRODUCT_NAME_PARAM_NAME);
    }

    private Boolean getActiveStateFromUccHelper(UCCHelper helper) throws IOException {
        return Boolean.valueOf(helper.getRequestParameterValue(MainConstants.QaThresholdConstants.ACTIVE_PARAM_NAME));
    }

    private Long getGenderIdFromUccHelper(UCCHelper helper) throws IOException {
        return getLongValueFromUccHelper(helper, MainConstants.QaThresholdConstants.GENDER_ID_PARAM_NAME);
    }

    private Long getYearIdFromUccHelper(UCCHelper helper) throws IOException {
        return getLongValueFromUccHelper(helper, MainConstants.QaThresholdConstants.YEAR_ID_PARAM_NAME);
    }

    private Long getComparisonStrategyIdFromUccHelper(UCCHelper helper) throws IOException {
        return getLongValueFromUccHelper(helper, MainConstants.QaThresholdConstants.COMPARISON_STRATEGY_ID_PARAM_NAME);
    }

    private Long getQaThresholdTypeIdFromUccHelper(UCCHelper helper) throws IOException {
        return getLongValueFromUccHelper(helper, MainConstants.QaThresholdConstants.QA_THRESHOLD_TYPE_ID_PARAM_NAME);
    }

    private Long getLongValueFromUccHelper(UCCHelper helper, String paramName) throws IOException {
        try {
            return Long.valueOf(helper.getRequestParameterValue(paramName));
        } catch (NumberFormatException e) {
            return null;
        }
    }

    private String getCommentFromUccHelper(UCCHelper helper) throws IOException {
        return helper.getRequestParameterValue(MainConstants.REVISION_COMMENT);
    }

    private void setCommentIntoUccHelper(String comment, UCCHelper helper) {
        helper.setRequestAttributeValue(MainConstants.REVISION_COMMENT, comment);
    }

    private List getComparisonStrategies(UCCHelper helper) throws IOException {
        String currentQaThresholdTypeId = helper.getRequestParameterValue(MainConstants.QaThresholdConstants.QA_THRESHOLD_TYPE_ID_PARAM_NAME);

        if (currentQaThresholdTypeId != null && !StringUtils.isEmpty(currentQaThresholdTypeId)) {
            Long longCurrentQaThresholdTypeId = Long.valueOf(currentQaThresholdTypeId);
            return comparisonStrategyService.getActiveQaThresholdComparisonStrategiesForQaThresholdType(longCurrentQaThresholdTypeId);

        }
        return null;
    }
}
