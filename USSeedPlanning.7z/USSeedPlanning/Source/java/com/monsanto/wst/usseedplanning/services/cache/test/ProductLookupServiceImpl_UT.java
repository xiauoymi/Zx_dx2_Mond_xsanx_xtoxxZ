/*
ProductLookupServiceImpl_UT was created on Aug 17, 2006 using Monsanto
resources and is the sole property of Monsanto.  Any duplication of the
code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.usseedplanning.services.cache.test;

import com.monsanto.wst.usseedplanning.model.maintenance.NameType;
import com.monsanto.wst.usseedplanning.model.cache.ProductDetails;
import com.monsanto.wst.usseedplanning.model.cache.ProductCriteria;
import com.monsanto.wst.usseedplanning.model.cache.test.ProductCriteriaUT;
import com.monsanto.wst.usseedplanning.services.cache.lexiconclientservices.mock.MockLexiconProductService;
import com.monsanto.wst.usseedplanning.services.cache.lexiconclientservices.ProductService;
import com.monsanto.wst.usseedplanning.services.cache.lexiconclientservices.LexiconProductServiceException;
import com.monsanto.wst.usseedplanning.services.cache.ProductLookupService;
import com.monsanto.wst.usseedplanning.services.cache.ProductLookupServiceImpl;
import com.monsanto.wst.usseedplanning.services.cache.ErrorHandler;
import com.monsanto.wst.usseedplanning.dao.CommonUploadDao;
import com.monsanto.wst.usseedplanning.dao.mock.MockCommonUploadDao;
import junit.framework.TestCase;

import java.util.ArrayList;
import java.util.List;
import java.io.IOException;

/**
 * Filename:    $RCSfile: ProductLookupServiceImpl_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: vrbethi $    	 On:	$Date: 2007-03-12 15:29:19 $
 *
 * @author sspati1
 * @version $Revision: 1.7 $
 */
public class ProductLookupServiceImpl_UT extends TestCase {
    public void testCreate() throws Exception {
        ProductLookupService service = new ProductLookupServiceImpl(new MockLexiconProductService(), (CommonUploadDao) null);
        assertNotNull(service);
    }

    public void testLookupProductDetailsForProductionPlanType() throws Exception {
        MockCommonUploadDao commonUploadDao = new MockCommonUploadDao();
        ProductLookupService service = new ProductLookupServiceImpl(new MockLexiconProductService(), commonUploadDao);
        List productDetailsList = service.lookupProductDetailByCriteria(getProductCriteriaListForProductionPlanType());
        assertNotNull(productDetailsList);
        assertEquals(12, productDetailsList.size());
    }

    public void testLookupHybridProductDetailsSetsDefaultParentsWhenNoParentsDefinedAndManufacturingNameDefined() throws Exception {
        MockCommonUploadDao commonUploadDao = new MockCommonUploadDao();
        ProductLookupService service = new ProductLookupServiceImpl(new MockLexiconProductService(), commonUploadDao);
        List productDetailsList = service.lookupProductDetailByCriteria(getProductCriteriaListForProductionPlanType());
        ProductDetails productDetails = (ProductDetails) productDetailsList.get(11);
        assertEquals("_PC19_F", productDetails.getFemaleParent().getPreCommercialName());
        assertEquals(ProductDetails.GENERATED_OVERRIDE_FLAG, productDetails.getFemaleParent().getOverrideFlag());
        assertEquals("_PC19_M", productDetails.getMaleParent().getPreCommercialName());
        assertEquals(ProductDetails.GENERATED_OVERRIDE_FLAG, productDetails.getMaleParent().getOverrideFlag());
    }

    public void testLookupHybridProductDetailsWhenParentsAreDefinedAndManufacturingNameDefined() throws Exception {
        MockCommonUploadDao commonUploadDao = new MockCommonUploadDao();
        ProductLookupService service = new ProductLookupServiceImpl(new MockLexiconProductService(), commonUploadDao);
        List productDetailsList = service.lookupProductDetailByCriteria(getProductCriteriaListForProductionPlanType());
        ProductDetails productDetails = (ProductDetails) productDetailsList.get(1);
        assertEquals(2, productDetails.getParentDetailsList().size());
        assertEquals("PC5", productDetails.getFemaleParent().getPreCommercialName());
        assertEquals(ProductDetails.ACTUAL_OVERRIDE_FLAG, productDetails.getFemaleParent().getOverrideFlag());
        assertEquals("PC6", productDetails.getMaleParent().getPreCommercialName());
        assertEquals(ProductDetails.ACTUAL_OVERRIDE_FLAG, productDetails.getMaleParent().getOverrideFlag());
    }

    public void testLookupHybridProductDetailsSetsDefaultParentsWhenNoParentsDefinedAndManufacturingNameNotDefined() throws Exception {
        MockCommonUploadDao commonUploadDao = new MockCommonUploadDao();
        ProductLookupService service = new ProductLookupServiceImpl(new MockLexiconProductService(), commonUploadDao);
        List productDetailsList = service.lookupProductDetailByCriteria(getProductCriteriaListForProductionPlanType());
        ProductDetails productDetails = (ProductDetails) productDetailsList.get(10);
        assertEquals("_PC18_F", productDetails.getFemaleParent().getPreCommercialName());
        assertEquals(ProductDetails.GENERATED_OVERRIDE_FLAG, productDetails.getFemaleParent().getOverrideFlag());
        assertEquals("_PC18_M", productDetails.getMaleParent().getPreCommercialName());
        assertEquals(ProductDetails.GENERATED_OVERRIDE_FLAG, productDetails.getMaleParent().getOverrideFlag());
    }

    public void testLookupHybridProductDetailsWhenParentsAreDefinedAndManufacturingNameNotDefined() throws Exception {
        MockCommonUploadDao commonUploadDao = new MockCommonUploadDao();
        ProductLookupService service = new ProductLookupServiceImpl(new MockLexiconProductService(), commonUploadDao);
        List productDetailsList = service.lookupProductDetailByCriteria(getProductCriteriaListForProductionPlanType());
        ProductDetails productDetails = (ProductDetails) productDetailsList.get(3);
        assertEquals(2, productDetails.getParentDetailsList().size());
        assertEquals("PC11", productDetails.getFemaleParent().getPreCommercialName());
        assertEquals(ProductDetails.ACTUAL_OVERRIDE_FLAG, productDetails.getFemaleParent().getOverrideFlag());
        assertEquals("PC12", productDetails.getMaleParent().getPreCommercialName());
        assertEquals(ProductDetails.ACTUAL_OVERRIDE_FLAG, productDetails.getMaleParent().getOverrideFlag());
    }

    public void testLookupParentProductDetailsSetsPreCommercialNameToFemaleParent() throws Exception {
        MockCommonUploadDao commonUploadDao = new MockCommonUploadDao();
        ProductLookupService service = new ProductLookupServiceImpl(new MockLexiconProductService(), commonUploadDao);
        List productDetailsList = service.lookupProductDetailByCriteria(getProductCriteriaListForProductionPlanType());
        ProductDetails productDetails = (ProductDetails) productDetailsList.get(2);
        assertEquals("PC3", productDetails.getPreCommercialName());
        assertEquals("PC3", productDetails.getFemaleParent().getPreCommercialName());
        assertEquals("P3", productDetails.getFemaleParent().getManufacturingName());
        assertEquals("1A", productDetails.getFemaleParent().getVersion());
        assertEquals(ProductDetails.ACTUAL_OVERRIDE_FLAG, productDetails.getFemaleParent().getOverrideFlag());
        assertNull(productDetails.getMaleParent().getPreCommercialName());
        assertEquals(ProductDetails.ACTUAL_OVERRIDE_FLAG, productDetails.getMaleParent().getOverrideFlag());
    }

    public void testLookupProductDetailsForProductionPlanTypeWithNullData() throws Exception {
        MockCommonUploadDao commonUploadDao = new MockCommonUploadDao();
        ProductLookupService service = new ProductLookupServiceImpl(new MockLexiconProductService(), commonUploadDao);
        List productDetailsList = service.lookupProductDetailByCriteria(getProductCriteriaListWithNullData());
        assertNotNull(productDetailsList);
        assertEquals(8, productDetailsList.size());
    }

    public void testLookupProductDetailsForNullProductCriteria() throws Exception {
        MockCommonUploadDao commonUploadDao = new MockCommonUploadDao();
        ProductLookupService service = new ProductLookupServiceImpl(new MockLexiconProductService(), commonUploadDao);
        List productDetailsList = service.lookupProductDetailByCriteria((List) null);
        assertNotNull(productDetailsList);
        assertEquals(0, productDetailsList.size());
    }

    public void testLookupProductWithNoDetails() throws Exception {
        MockCommonUploadDao commonUploadDao = new MockCommonUploadDao();
        ProductLookupService service = new ProductLookupServiceImpl(new MockLexiconProductService(), commonUploadDao);
        List criteriaList = new ArrayList();
        ProductCriteria criteria = new ProductCriteria();
        criteria.setProductName("Unknown");
        criteria.setCommonName("Unknown");
        criteria.setOrigin("DEMAND");
        criteria.setChannelId(new Long(100));
        criteria.setNameType(new NameType(NameType.COMMERCIAL));
        criteriaList.add(criteria);
        List productDetailsList = service.lookupProductDetailByCriteria(criteriaList);
        assertNotNull(productDetailsList);
        assertEquals(1, productDetailsList.size());
        ProductDetails details = (ProductDetails) productDetailsList.get(0);
        assertEquals("Unknown", details.getProvidedName());
        assertEquals("Unknown", details.getPreCommercialName());
        assertEquals("DEMAND", details.getOrigin());
        assertEquals(new Long(100), details.getChannelId());
        assertEquals("X", details.getProductionStatus());
        assertNull(details.getManufacturingName());
        assertNull(details.getCommercialName());
        assertNull(details.getStage());
        assertNull(details.getRelativeMaturity());
        assertNull(details.getTrait());
        assertNull(details.getVersion());
        assertNull(details.getProductType());
        assertNotNull(details.getMaleParent());
        assertEquals("_Unknown_M", details.getMaleParent().getPreCommercialName());
        assertNotNull(details.getFemaleParent());
        assertEquals("_Unknown_F", details.getFemaleParent().getPreCommercialName());
    }

    public void testLookupProductWithEqualPCMAndMFGNames() throws Exception {
        MockCommonUploadDao commonUploadDao = new MockCommonUploadDao();
        ProductLookupService service = new ProductLookupServiceImpl(new MockLexiconProductService(), commonUploadDao);
        List criteriaList = new ArrayList();
        criteriaList.add(ProductCriteriaUT.createProductCriteria("P7", new NameType(NameType.MANUFACTURING)));
        List productDetailsList = service.lookupProductDetailByCriteria(criteriaList);
        assertEquals(1, productDetailsList.size());
        assertEquals(Boolean.TRUE, ((ProductDetails) productDetailsList.get(0)).getSkipManufacturingName());
    }

    public void testLookupProductWithPrimaryPCMName() throws Exception {
        MockCommonUploadDao commonUploadDao = new MockCommonUploadDao();
        ProductLookupService service = new ProductLookupServiceImpl(new MockLexiconProductService(), commonUploadDao);
        List criteriaList = new ArrayList();
        criteriaList.add(ProductCriteriaUT.createProductCriteria("P16", new NameType(NameType.MANUFACTURING)));
        List productDetailsList = service.lookupProductDetailByCriteria(criteriaList);
        assertEquals(3, productDetailsList.size());
        for (int i = 0; i < productDetailsList.size(); i++) {
            ProductDetails productDetails = (ProductDetails) productDetailsList.get(i);
            assertEquals(Boolean.TRUE, productDetails.getPrimaryFlag());
        }
    }

    public void testLookupProductWithoutPrimaryPCMName() throws Exception {
        MockCommonUploadDao commonUploadDao = new MockCommonUploadDao();
        ProductLookupService service = new ProductLookupServiceImpl(new MockLexiconProductService(), commonUploadDao);
        List criteriaList = new ArrayList();
        criteriaList.add(ProductCriteriaUT.createProductCriteria("P17", new NameType(NameType.MANUFACTURING)));
        List productDetailsList = service.lookupProductDetailByCriteria(criteriaList);
        assertEquals(3, productDetailsList.size());
        for (int i = 0; i < productDetailsList.size(); i++) {
            ProductDetails productDetails = (ProductDetails) productDetailsList.get(i);
            assertEquals(Boolean.FALSE, productDetails.getPrimaryFlag());
        }
    }

    public void testLookupSterileProductSetsMalePCMAsBaseName() throws Exception {
        MockCommonUploadDao commonUploadDao = new MockCommonUploadDao();
        ProductLookupService service = new ProductLookupServiceImpl(new MockLexiconProductService(), commonUploadDao);
        List criteriaList = new ArrayList();
        criteriaList.add(ProductCriteriaUT.createProductCriteria("P20CMS", new NameType(NameType.MANUFACTURING)));
        List productDetailsList = service.lookupProductDetailByCriteria(criteriaList);
        assertEquals(1, productDetailsList.size());
        ProductDetails productDetails = (ProductDetails) productDetailsList.get(0);
        assertEquals("PC20", productDetails.getMaleParent().getPreCommercialName());
        assertEquals("P20", productDetails.getMaleParent().getManufacturingName());
        assertEquals(ProductDetails.PRODUCT_TYPE_STERILE, productDetails.getProductType());
        assertEquals(ProductDetails.ACTUAL_OVERRIDE_FLAG, productDetails.getMaleParent().getOverrideFlag());
    }

    public void testLookupUnknownSterileProductGeneratesMale() throws Exception {
        MockCommonUploadDao commonUploadDao = new MockCommonUploadDao();
        ProductLookupService service = new ProductLookupServiceImpl(new MockLexiconProductService(), commonUploadDao);
        List criteriaList = new ArrayList();
        criteriaList.add(ProductCriteriaUT.createProductCriteria("P21CMS", new NameType(NameType.MANUFACTURING)));
        List productDetailsList = service.lookupProductDetailByCriteria(criteriaList);
        assertEquals(1, productDetailsList.size());
        ProductDetails productDetails = (ProductDetails) productDetailsList.get(0);
        assertEquals("_PC21CMS_M", productDetails.getMaleParent().getPreCommercialName());
        assertNull(productDetails.getMaleParent().getManufacturingName());
        assertEquals(ProductDetails.GENERATED_OVERRIDE_FLAG, productDetails.getMaleParent().getOverrideFlag());
        assertEquals(ProductDetails.PRODUCT_TYPE_STERILE, productDetails.getProductType());
    }

    public void testLookupProductWithoutMatchingVersion() throws Exception {
        MockCommonUploadDao commonUploadDao = new MockCommonUploadDao();
        ProductLookupServiceImpl service = new ProductLookupServiceImpl(new MockLexiconProductService(), commonUploadDao);
        List criteriaList = new ArrayList();
        ProductCriteria productCriteria = ProductCriteriaUT.createProductCriteria("P1", new NameType(NameType.MANUFACTURING));
        productCriteria.setOrigin("SUPPLY");
        productCriteria.setTraitVersion("A");
        criteriaList.add(productCriteria);
        List productDetailsList = service.lookupProductDetailByCriteria(criteriaList);
        assertEquals(2, productDetailsList.size());
        ProductDetails productDetails = (ProductDetails) productDetailsList.get(1);
        assertEquals(ProductDetails.PRODUCTION_STATUS_UNRESOLVED, productDetails.getProductionStatus());
        assertEquals("P1", productDetails.getPreCommercialName());
        assertEquals("A", productDetails.getVersion());
    }

    public void testLookupProductMatchingVersion() throws Exception {
        MockCommonUploadDao commonUploadDao = new MockCommonUploadDao();
        ProductLookupServiceImpl service = new ProductLookupServiceImpl(new MockLexiconProductService(), commonUploadDao);
        List criteriaList = new ArrayList();
        ProductCriteria productCriteria = ProductCriteriaUT.createProductCriteria("P3", new NameType(NameType.MANUFACTURING));
        productCriteria.setOrigin("SUPPLY");
        productCriteria.setTraitVersion("1A");
        criteriaList.add(productCriteria);
        List productDetailsList = service.lookupProductDetailByCriteria(criteriaList);
        assertEquals(1, productDetailsList.size());
        ProductDetails productDetails = (ProductDetails) productDetailsList.get(0);
        assertEquals("P3", productDetails.getManufacturingName());
        assertEquals("PC3", productDetails.getPreCommercialName());
        assertNull(productDetails.getProductionStatus());
        assertEquals("1A", productDetails.getVersion());
    }

    public void testLookupProductWithoutMatchingVersionButNotFromSupply() throws Exception {
        MockCommonUploadDao commonUploadDao = new MockCommonUploadDao();
        ProductLookupServiceImpl service = new ProductLookupServiceImpl(new MockLexiconProductService(), commonUploadDao);
        List criteriaList = new ArrayList();
        ProductCriteria productCriteria = ProductCriteriaUT.createProductCriteria("P3", new NameType(NameType.MANUFACTURING));
        productCriteria.setOrigin("DEMAND");
        criteriaList.add(productCriteria);
        List productDetailsList = service.lookupProductDetailByCriteria(criteriaList);
        assertEquals(1, productDetailsList.size());
        ProductDetails productDetails = (ProductDetails) productDetailsList.get(0);
        assertEquals("P3", productDetails.getManufacturingName());
        assertEquals("PC3", productDetails.getPreCommercialName());
        assertNull(productDetails.getProductionStatus());
        assertEquals("1A", productDetails.getVersion());
    }

    public void testLookupProductWhenBothVersionsAreNull() throws Exception {
        MockCommonUploadDao commonUploadDao = new MockCommonUploadDao();
        ProductLookupServiceImpl service = new ProductLookupServiceImpl(new MockLexiconProductService(), commonUploadDao);
        List criteriaList = new ArrayList();
        ProductCriteria productCriteria = ProductCriteriaUT.createProductCriteria("P1", new NameType(NameType.MANUFACTURING));
        productCriteria.setOrigin("SUPPLY");
        criteriaList.add(productCriteria);
        List productDetailsList = service.lookupProductDetailByCriteria(criteriaList);
        assertEquals(1, productDetailsList.size());
        ProductDetails productDetails = (ProductDetails) productDetailsList.get(0);
        assertNull(productDetails.getProductionStatus());
        assertEquals("PC1", productDetails.getPreCommercialName());
        assertEquals("P1", productDetails.getManufacturingName());
        assertNull(productDetails.getVersion());
    }

    public void testLookupProductNoMatchingVersionAndNoManufacturingName() throws Exception {
        MockCommonUploadDao commonUploadDao = new MockCommonUploadDao();
        ProductLookupServiceImpl service = new ProductLookupServiceImpl(new MockLexiconProductService(), commonUploadDao);
        List criteriaList = new ArrayList();
        ProductCriteria productCriteria = ProductCriteriaUT.createProductCriteria("PC15", new NameType(NameType.PRECOMMERCIAL));
        productCriteria.setOrigin("SUPPLY");
        productCriteria.setTraitVersion("A");
        criteriaList.add(productCriteria);
        List productDetailsList = service.lookupProductDetailByCriteria(criteriaList);
        assertEquals(2, productDetailsList.size());
        ProductDetails productDetails = (ProductDetails) productDetailsList.get(0);
        assertEquals(ProductDetails.PRODUCTION_STATUS_UNRESOLVED, productDetails.getProductionStatus());
        assertEquals("PC15", productDetails.getPreCommercialName());
        assertEquals("A", productDetails.getVersion());
    }

    public void testRegisterLexiconServiceErrorHandler_IfErrorEncounteredCheckIfErrorHandlerCalled_CommercialProduct() throws Exception {
        ProductService productService = new MockProductService_GetPreCommercialNameFromCommercialNameThrowsException();
        ProductLookupService productLookupService = new ProductLookupServiceImpl(productService,null);
        ErrorHandler errorHandler = new MockLexiconServiceErrorHandler();
        productLookupService.registerErrorHandler(errorHandler);
        List productCriteriaList = new ArrayList();
        NameType nameType = new NameType();
        nameType.setNameType(NameType.COMMERCIAL);
        ProductCriteria criteria = new ProductCriteria("TXP068-D", nameType, "TXP068-D");
        criteria.setOrigin("DEMAND");
        productCriteriaList.add(criteria);
        productLookupService.lookupProductDetailByCriteria(productCriteriaList);
        String error = ((MockLexiconServiceErrorHandler)errorHandler).getError();
        assertEquals("Exception thrown accessing Aggregate lexicon service",error);
    }

    public void testHandlerNotRegistered_ExceptionNeedsToBeRethrown_CommercialProduct() throws Exception {
        try {
            ProductService productService = new MockProductService_GetPreCommercialNameFromCommercialNameThrowsException();
            ProductLookupService productLookupService = new ProductLookupServiceImpl(productService,null);
            List productCriteriaList = new ArrayList();
            NameType nameType = new NameType();
            nameType.setNameType(NameType.COMMERCIAL);
            ProductCriteria criteria = new ProductCriteria("TXP068-D", nameType, "TXP068-D");
            criteria.setOrigin("DEMAND");
            productCriteriaList.add(criteria);
            productLookupService.lookupProductDetailByCriteria(productCriteriaList);
            fail("Exception should have been re thrown since there is no error handler");
        } catch (LexiconProductServiceException e) {

        }
    }

    public void testRegisterLexiconServiceErrorHandler_IfErrorEncounteredCheckIfErrorHandlerCalled_PreCommercailProduct() throws Exception {
        ProductService productService = new MockProductService_GetProductDetailsListByPreCommercialNameThrowsException();
        ProductLookupService productLookupService = new ProductLookupServiceImpl(productService,null);
        ErrorHandler errorHandler = new MockLexiconServiceErrorHandler();
        productLookupService.registerErrorHandler(errorHandler);
        List productCriteriaList = new ArrayList();
        NameType nameType = new NameType();
        nameType.setNameType(NameType.COMMERCIAL);
        ProductCriteria criteria = new ProductCriteria("TXP068-D", nameType, "TXP068-D");
        criteria.setOrigin("DEMAND");
        productCriteriaList.add(criteria);
        productLookupService.lookupProductDetailByCriteria(productCriteriaList);
        String error = ((MockLexiconServiceErrorHandler)errorHandler).getError();
        assertEquals("Exception thrown accessing PreCommercialName lexicon service",error);
    }

    public void testHandlerNotRegistered_ExceptionNeedsToBeRethrown_PreCommercailProduct() throws Exception {
        try {
            ProductService productService = new MockProductService_GetProductDetailsListByPreCommercialNameThrowsException();
            ProductLookupService productLookupService = new ProductLookupServiceImpl(productService,null);
            List productCriteriaList = new ArrayList();
            NameType nameType = new NameType();
            nameType.setNameType(NameType.COMMERCIAL);
            ProductCriteria criteria = new ProductCriteria("TXP068-D", nameType, "TXP068-D");
            criteria.setOrigin("DEMAND");
            productCriteriaList.add(criteria);
            productLookupService.lookupProductDetailByCriteria(productCriteriaList);
            fail("Exception should have been re thrown since there is no error handler");
        } catch (LexiconProductServiceException e) {

        }
    }

    public void testRegisterLexiconServiceErrorHandler_IfErrorEncounteredCheckIfErrorHandlerCalled_MFGProduct() throws Exception {
        ProductService productService = new MockProductService_GetProductDetailsListByMFGNameThrowsException();
        ProductLookupService productLookupService = new ProductLookupServiceImpl(productService,null);
        ErrorHandler errorHandler = new MockLexiconServiceErrorHandler();
        productLookupService.registerErrorHandler(errorHandler);
        List productCriteriaList = new ArrayList();
        NameType nameType = new NameType();
        nameType.setNameType(NameType.COMMERCIAL);
        ProductCriteria criteria = new ProductCriteria("TXP068-D", nameType, "TXP068-D");
        criteria.setOrigin("DEMAND");
        productCriteriaList.add(criteria);
        productLookupService.lookupProductDetailByCriteria(productCriteriaList);
        String error = ((MockLexiconServiceErrorHandler)errorHandler).getError();
        assertEquals("Exception thrown accessing MFG lexicon service",error);
    }

    public void testHandlerNotRegistered_ExceptionNeedsToBeRethrown_MFGProduct() throws Exception {
        try {
            ProductService productService = new MockProductService_GetProductDetailsListByMFGNameThrowsException();
            ProductLookupService productLookupService = new ProductLookupServiceImpl(productService,null);
            List productCriteriaList = new ArrayList();
            NameType nameType = new NameType();
            nameType.setNameType(NameType.COMMERCIAL);
            ProductCriteria criteria = new ProductCriteria("TXP068-D", nameType, "TXP068-D");
            criteria.setOrigin("DEMAND");
            productCriteriaList.add(criteria);
            productLookupService.lookupProductDetailByCriteria(productCriteriaList);
            fail("Exception should have been re thrown since there is no error handler");
        } catch (LexiconProductServiceException e) {

        }
    }

    private List getProductCriteriaListForProductionPlanType() {
        List productCriteriaList = new ArrayList();
        productCriteriaList.add(ProductCriteriaUT.createProductCriteria("P1", new NameType(NameType.MANUFACTURING)));
        productCriteriaList.add(ProductCriteriaUT.createProductCriteria("P2", new NameType(NameType.COMMERCIAL)));
        productCriteriaList.add(ProductCriteriaUT.createProductCriteria("P3", new NameType(NameType.PRECOMMERCIAL)));
        productCriteriaList.add(ProductCriteriaUT.createProductCriteria("P4", new NameType(NameType.PRECOMMERCIAL)));
        productCriteriaList.add(ProductCriteriaUT.createProductCriteria("P5", new NameType(NameType.COMMERCIAL)));
        productCriteriaList.add(ProductCriteriaUT.createProductCriteria("P6", new NameType(NameType.COMMERCIAL)));
        productCriteriaList.add(ProductCriteriaUT.createProductCriteria("P7", new NameType(NameType.MANUFACTURING)));
        productCriteriaList.add(ProductCriteriaUT.createProductCriteria("P8", new NameType(NameType.PRECOMMERCIAL)));
        productCriteriaList.add(ProductCriteriaUT.createProductCriteria("P8", new NameType(NameType.PRECOMMERCIAL)));
        productCriteriaList.add(ProductCriteriaUT.createProductCriteria("P9", new NameType(NameType.PRECOMMERCIAL)));
        productCriteriaList.add(ProductCriteriaUT.createProductCriteria("PC15", new NameType(NameType.PRECOMMERCIAL)));
        productCriteriaList.add(ProductCriteriaUT.createProductCriteria("PC18", new NameType(NameType.PRECOMMERCIAL)));
        productCriteriaList.add(ProductCriteriaUT.createProductCriteria("P19", new NameType(NameType.MANUFACTURING)));
        return productCriteriaList;
    }

    private List getProductCriteriaListWithNullData() {
        List productCriteriaList = new ArrayList();
        productCriteriaList.add(ProductCriteriaUT.createProductCriteria("P1", new NameType(NameType.MANUFACTURING)));
        productCriteriaList.add(ProductCriteriaUT.createProductCriteria("P2", new NameType(NameType.COMMERCIAL)));
        productCriteriaList.add(ProductCriteriaUT.createProductCriteria("P3", new NameType(NameType.PRECOMMERCIAL)));
        productCriteriaList.add(ProductCriteriaUT.createProductCriteria("P4", new NameType(NameType.PRECOMMERCIAL)));
        productCriteriaList.add(null);
        productCriteriaList.add(ProductCriteriaUT.createProductCriteria("P6", new NameType(NameType.COMMERCIAL)));
        productCriteriaList.add(ProductCriteriaUT.createProductCriteria("P7", new NameType(NameType.MANUFACTURING)));
        productCriteriaList.add(ProductCriteriaUT.createProductCriteria("P8", new NameType(NameType.PRECOMMERCIAL)));
        productCriteriaList.add(ProductCriteriaUT.createProductCriteria("P15", new NameType(NameType.MANUFACTURING)));
        return productCriteriaList;
    }

    class MockProductService_GetPreCommercialNameFromCommercialNameThrowsException implements ProductService{

        public String getPreCommercialNameFromCommercialName(String commercialName) throws Exception {
            throw new LexiconProductServiceException("Exception thrown accessing Aggregate lexicon service",new Exception());
        }

        public List getProductDetailsListByPreCommercialName(String preCommercialName) throws Exception {
            return new ArrayList();
        }

        public List getProductDetailsListByManufacturingName(String manufacturingName) throws Exception {
            return new ArrayList();
        }
    }

    class MockProductService_GetProductDetailsListByPreCommercialNameThrowsException implements ProductService{

        public String getPreCommercialNameFromCommercialName(String commercialName) throws Exception {
            return "";
        }

        public List getProductDetailsListByPreCommercialName(String preCommercialName) throws Exception {
            throw new LexiconProductServiceException("Exception thrown accessing PreCommercialName lexicon service",new Exception());
        }

        public List getProductDetailsListByManufacturingName(String manufacturingName) throws Exception {
            return new ArrayList();
        }
    }

    class MockProductService_GetProductDetailsListByMFGNameThrowsException implements ProductService{

        public String getPreCommercialNameFromCommercialName(String commercialName) throws Exception {
            return "";
        }

        public List getProductDetailsListByPreCommercialName(String preCommercialName) throws Exception {
            return new ArrayList();
        }

        public List getProductDetailsListByManufacturingName(String manufacturingName) throws Exception {
            throw new LexiconProductServiceException("Exception thrown accessing MFG lexicon service",new Exception());
        }
    }

    class MockLexiconServiceErrorHandler implements ErrorHandler{
        StringBuffer stringBuffer = new StringBuffer();
        public String getError() {
            return stringBuffer.toString();
        }

        public void notifyError(LexiconProductServiceException e) {
            stringBuffer.append(e.getMessage());
        }

        public void saveAndClose() throws IOException {
        }
    }
}