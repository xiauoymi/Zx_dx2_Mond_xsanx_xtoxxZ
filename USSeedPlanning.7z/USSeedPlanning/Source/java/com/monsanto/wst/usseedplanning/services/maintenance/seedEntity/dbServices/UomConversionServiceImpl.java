/*
 UomConversionServiceImpl was created on Sep 25, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.usseedplanning.services.maintenance.seedEntity.dbServices;

import com.monsanto.wst.usseedplanning.services.maintenance.seedEntity.UomConversionService;
import com.monsanto.wst.usseedplanning.dao.UomConversionDao;

import java.util.List;

/**
 * Filename:    $RCSfile: UomConversionServiceImpl.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: SSPATI1 $    	 On:	$Date: 2006-09-25 20:21:26 $
 *
 * @author sspati1
 * @version $Revision: 1.1 $
 */
public class UomConversionServiceImpl implements UomConversionService {

  private UomConversionDao uomConversionDao;

  public UomConversionServiceImpl(UomConversionDao uomConversionDao) {
    this.uomConversionDao = uomConversionDao;
  }

  public List getAllFactors() {
    return null;
  }
}