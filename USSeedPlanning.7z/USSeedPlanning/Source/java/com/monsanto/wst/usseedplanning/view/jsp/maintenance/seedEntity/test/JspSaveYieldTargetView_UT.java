package com.monsanto.wst.usseedplanning.view.jsp.maintenance.seedEntity.test;

import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.wst.usseedplanning.constants.MainConstants;
import com.monsanto.wst.usseedplanning.view.jsp.maintenance.seedEntity.JspSaveYieldTargetView;
import com.monsanto.wst.view.ViewRenderingException;
import com.monsanto.wst.view.test.mock.MockUCCHelperThrowsIOException;
import junit.framework.TestCase;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Aug 8, 2006
 * Time: 10:02:02 AM
 * To change this template use File | Settings | File Templates.
 */
public class JspSaveYieldTargetView_UT extends TestCase {

    MockUCCHelper helper = null;
    List errorList = new ArrayList();

    protected void setUp() throws Exception {
        helper = new MockUCCHelper(null);
    }

    public void testCreate() throws Exception {
        JspSaveYieldTargetView view = new JspSaveYieldTargetView();
        assertNotNull(view);
    }

    public void testRenderView() throws Exception {
        JspSaveYieldTargetView view = new JspSaveYieldTargetView();
        view.renderView(helper);
        assertTrue(helper.wasSentTo(MainConstants.CREATE_TARGET_YIELD_JSP));
    }

    public void testRenderViewThrowsException() throws Exception {
        MockUCCHelperThrowsIOException helperThrowsIOException = new MockUCCHelperThrowsIOException(null);
        JspSaveYieldTargetView view = new JspSaveYieldTargetView();
        try {
            view.renderView(helperThrowsIOException);
            fail("This should have thrown Exception");
        } catch (ViewRenderingException e) {
            assertEquals("Unable to Render View", e.getMessage());
        }
    }

    public void testRenderViewWithErrors() throws Exception {
        errorList.add("Error 1");
        errorList.add("Error 2");
        JspSaveYieldTargetView view = new JspSaveYieldTargetView(errorList, MainConstants.ERROR_LIST);
        view.renderView(helper);
        assertTrue(helper.wasSentTo(MainConstants.CREATE_TARGET_YIELD_JSP));
        assertEquals(2, ((List)helper.getRequestAttributeValue(MainConstants.ERROR_LIST)).size());
    }

    public void testRenderViewWithErrorsThrowsException() throws Exception {
        MockUCCHelperThrowsIOException helperThrowsIOException = new MockUCCHelperThrowsIOException(null);
        errorList.add("Error 1");
        errorList.add("Error 2");
        JspSaveYieldTargetView view = new JspSaveYieldTargetView(errorList, MainConstants.ERROR_LIST);
        try {
            view.renderView(helperThrowsIOException);
            fail("This should have thrown Exception");
        } catch (ViewRenderingException e) {
            assertEquals("Unable to Render View", e.getMessage());
        }
    }

    public void testRenderViewWithSuccess() throws Exception {
        errorList.add("Success 1");
        JspSaveYieldTargetView view = new JspSaveYieldTargetView(errorList, MainConstants.SUCCESS_LIST);
        view.renderView(helper);
        assertTrue(helper.wasSentTo(MainConstants.CREATE_TARGET_YIELD_JSP));
        assertEquals(1, ((List)helper.getRequestAttributeValue(MainConstants.SUCCESS_LIST)).size());
    }
}
