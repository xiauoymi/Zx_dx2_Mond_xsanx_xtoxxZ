package com.monsanto.wst.usseedplanning.utils.testutils.test;

import com.monsanto.AbstractLogging.Logger;
import com.monsanto.wst.commonutils.reflection.ObjectInspector;
import com.monsanto.wst.dbtemplate.plugins.dbunit.DBUnitConnectionInterceptor;
import com.monsanto.wst.dbtemplate.transaction.TransactionManager;
import com.monsanto.wst.dbtemplate.transaction.test.mock.MockTransactionManager;
import com.monsanto.wst.factory.AbstractGenericFactory;
import com.monsanto.wst.factory.DelegatingLocatorGenericFactory;
import com.monsanto.wst.factory.GenericFactoryInitializationException;
import com.monsanto.wst.usseedplanning.utils.testutils.USSeedPlanningTestUtils;
import junit.framework.TestCase;

import java.sql.Connection;

/**
 * Created by IntelliJ IDEA.
 * Date: Sep 6, 2006
 * Time: 7:05:07 AM
 * <p/>
 * Unit test for the USSeedPlanningTestUtils object.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class USSeedPlanningTestUtilsUT extends TestCase {
    public void testCreate() throws Exception {
        USSeedPlanningTestUtils testUtils = new USSeedPlanningTestUtils(new ObjectInspector());
        assertNotNull(testUtils);
    }

    public void testSetupContainer() throws Exception {
        USSeedPlanningTestUtils testUtils = new USSeedPlanningTestUtils(new ObjectInspector());
        testUtils.setupContainer();
        assertEquals(DelegatingLocatorGenericFactory.class, AbstractGenericFactory.getInstance().getClass());
    }

    public void testTearDownContainer() throws Exception {
        USSeedPlanningTestUtils testUtils = new USSeedPlanningTestUtils(new ObjectInspector());
        testUtils.setupContainer();
        testUtils.tearDownContainer();
        try {
            AbstractGenericFactory.getInstance().getClass();
            fail("This should have thrown an exception.");
        } catch (GenericFactoryInitializationException e) {
        }
    }

    public void testSetupTransactionManager() throws Exception {
        USSeedPlanningTestUtils testUtils = new USSeedPlanningTestUtils(new ObjectInspector());
        testUtils.setupContainer();
        testUtils.setupTransactionManager();
        assertNotNull(AbstractGenericFactory.getInstance().getBean("transactionManager"));
    }

    public void testSetupTransactionManagerThatTakesConnection() throws Exception {
        USSeedPlanningTestUtils testUtils = new USSeedPlanningTestUtils(new ObjectInspector());
        testUtils.setupContainer();
        TransactionManager txManager = testUtils.setupTransactionManager(new DBUnitConnectionInterceptor((Connection) null));
        assertNotNull(txManager);
        assertEquals(txManager, AbstractGenericFactory.getInstance().getBean("transactionManager"));
        assertNotNull(AbstractGenericFactory.getInstance().getBean("transactionManager"));
    }

    public void testRollbackTransaction() throws Exception {
        USSeedPlanningTestUtils testUtils = new USSeedPlanningTestUtils(new ObjectInspector());
        testUtils.setupContainer();
        testUtils.setupTransactionManager();
        MockTransactionManager txManager = new MockTransactionManager();
        AbstractGenericFactory.getInstance().addBean("transactionManager", txManager, true);
        testUtils.rollbackTransaction(txManager);
        assertTrue(txManager.isRolledBack());
    }

    public void testRollbackTransactionWhenNoTransaction() throws Exception {
        USSeedPlanningTestUtils testUtils = new USSeedPlanningTestUtils(new ObjectInspector());
        testUtils.setupContainer();
        testUtils.setupLogging("USSeedPlanning");
        Logger.enableLogger(Logger.DEBUG_LOG);
        testUtils.rollbackTransaction();

        Logger.disableLogger(Logger.DEBUG_LOG);
        testUtils.rollbackTransaction();
    }

    public void testRollbackTransactionWhenNoApplicationContainer() throws Exception {
        USSeedPlanningTestUtils testUtils = new USSeedPlanningTestUtils(new ObjectInspector());
        AbstractGenericFactory.clear();
        testUtils.setupLogging("USSeedPlanning");
        Logger.enableLogger(Logger.DEBUG_LOG);
        try {
            testUtils.rollbackTransaction();
            fail("This should have thrown an exception.");
        } catch (GenericFactoryInitializationException e) {
            e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
        }

        Logger.disableLogger(Logger.DEBUG_LOG);
        try {
            testUtils.rollbackTransaction();
            fail("This should have thrown an exception.");
        } catch (GenericFactoryInitializationException e) {
            e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
        }
    }
}
