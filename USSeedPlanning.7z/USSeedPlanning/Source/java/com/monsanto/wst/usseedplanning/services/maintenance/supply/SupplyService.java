package com.monsanto.wst.usseedplanning.services.maintenance.supply;

import com.monsanto.wst.usseedplanning.model.core.LoginUser;

import java.io.File;
import java.io.IOException;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * Date: Aug 16, 2006
 * Time: 5:31:15 PM
 * <p/>
 * This interface defines the contract for retrieving and modifying supply information.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public interface SupplyService {
  /**
   * This method updates supply information in the system based on the current supply.
   *
   * @param file File representing the supply data file.
   * @param owner LoginUser object representing the person requesting the update.
   * @param supplyType String representing the supply type
   * @param planType
   * @param comments String representing any comments.
   * @throws IOException - If unable to find a valid supply file.
   */
  void updateSupply(File file, LoginUser owner, String supplyType, Long planType, String comments) throws IOException;

  /**
   * This method returns a list of supply revisions based on the criteria specified.
   *
   * @param planTypeId
   * @return List - Representing the revisions.
   */
  List lookupSupplyRevisionsByCriteria(Long planTypeId);
}
