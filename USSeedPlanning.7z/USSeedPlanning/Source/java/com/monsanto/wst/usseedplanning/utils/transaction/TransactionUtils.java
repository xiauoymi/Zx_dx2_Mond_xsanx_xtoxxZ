package com.monsanto.wst.usseedplanning.utils.transaction;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.wst.dbtemplate.transaction.TransactionManager;
import com.monsanto.wst.servletframework.DITransactionalController;

/**
 * Created by IntelliJ IDEA.
 * Date: Sep 12, 2006
 * Time: 12:09:45 PM
 * <p/>
 * This class is used to perform actions on the current transaction.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class TransactionUtils {
    private UCCHelper helper;

    /**
     * This constructor takes a UCCHelper object.
     *
     * @param helper UCCHelper object containing the request and response.
     */
    public TransactionUtils(UCCHelper helper) {
        this.helper = helper;
    }

    /**
     * This method returns the current transaction manager.
     *
     * @return TransactionManager - Object representing the transaction manager.
     */
    public TransactionManager getTransactionManager() {
        return (TransactionManager) this.helper
                .getContextAttribute(DITransactionalController.TRANSACTION_MANAGER_CTX_ATTRIBUTE);
    }

    /**
     * This method flags the current transaction for rollback.  The rollback occurrs at the end of the request.
     */
    public void flagForRollback() {
        this.helper.setRequestAttributeValue(DITransactionalController.ROLLBACK__FLAG, Boolean.TRUE);
    }
}
