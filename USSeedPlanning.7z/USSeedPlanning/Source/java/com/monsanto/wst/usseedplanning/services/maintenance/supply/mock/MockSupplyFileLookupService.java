package com.monsanto.wst.usseedplanning.services.maintenance.supply.mock;

import com.monsanto.wst.commonutils.resources.ResourceUtils;
import com.monsanto.wst.usseedplanning.services.maintenance.supply.SupplyFileLookupService;

import java.io.File;
import java.io.FileNotFoundException;

/**
 * Created by IntelliJ IDEA.
 * Date: Aug 16, 2006
 * Time: 3:37:12 PM
 * <p/>
 * Mock implementation of the SupplyFileLookupService interface.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class MockSupplyFileLookupService implements SupplyFileLookupService {
    private File file;

    public MockSupplyFileLookupService() {
        try {
            this.file = new ResourceUtils().convertPathToFile("com/monsanto/wst/usseedplanning/services/mock/ATPExampleSmall.xls");
        } catch (FileNotFoundException e) {
            e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
        }
    }

    public File lookupATPSupplyFile() {
        return file;
    }
}
