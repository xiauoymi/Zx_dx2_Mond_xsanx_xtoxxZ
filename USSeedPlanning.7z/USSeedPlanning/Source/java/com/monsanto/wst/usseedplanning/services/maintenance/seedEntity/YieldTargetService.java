/*
 Copyright:  Copyright � 2006 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.usseedplanning.services.maintenance.seedEntity;

import com.monsanto.wst.usseedplanning.model.maintenance.YieldTargetFactor;

import java.util.List;

/**
 * Filename:    $RCSfile: YieldTargetService.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: jdpoul $    	 On:	$Date: 2006-09-29 19:14:22 $
 *
 * @author jdpoul
 * @version $Revision: 1.9 $
 */
public interface YieldTargetService {

  void saveYieldTargetFactor(YieldTargetFactor yieldTargetFactor);

  YieldTargetFactor getYieldTargetByRevisionId(String revisionId);

  List getAllApplicableYieldTargetFactorsInOrderOfPrecedence(String productNameCriteria, Long yearCriteria,
                                                             Long genderCriteria,
                                                             Long maxRevisionId);

  YieldTargetFactor getMostAppropriateYieldTargetFactor(String productNameCriteria, Long yearCriteria,
                                                        Long genderCriteria,
                                                        Long maxRevisionId);
}