package com.monsanto.wst.usseedplanning.Servlet;


import com.monsanto.AbstractLogging.LogRegistrationException;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.ServletFramework.GatewayServlet;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;


/**
 * <p>Title: USSeedPlanningServlet</p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Monsanto</p>
 *
 * @author Java Framework Code  Generator 2.3
 * @version $Id: USSeedPlanningServlet.java,v 1.11 2007-02-13 21:12:44 njminsh Exp $
 */
public class USSeedPlanningServlet extends GatewayServlet {
    private static final Log log = LogFactory.getLog(USSeedPlanningServlet.class);
    public static final String s_cstrResourceBundle = "com.monsanto.wst.usseedplanning.Servlet.USSeedPlanning";

    public USSeedPlanningServlet() {
        super(600);  // Set the session timeout values in seconds. (600)
    }

    public void init(ServletConfig servletConfig) throws ServletException {
        super.init(servletConfig);
        Logger.traceEntry();
        try {
            USSeedPlanningLoggerFactory loggerFactory = new USSeedPlanningLoggerFactory();
            loggerFactory.setupLogging();
        }
        catch (LogRegistrationException lre) {
            throw new ServletException(lre.toString());
        }
        catch (IOException ioe) {
            throw new ServletException(ioe.toString());
        }
        Logger.traceExit();
    }

    public void destroy() {
        Logger.traceEntry();
        super.destroy();
        Logger.traceExit();
    }

    /**
     * This static method will create an instance of the desired PersistentStore based on
     * data within a property file.
     *
     * @param request  - The HttpServlet Request from the servlet container
     * @param response - The HttpServletResponse to be sent back to the servlet container.
     * @throws java.io.IOException
     * @throws javax.servlet.ServletException
     */
    public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
        Logger.traceEntry();
        System.setProperty("current.domain", request.getServerName());
        System.setProperty("current.port", String.valueOf(request.getServerPort()));
        /*  Pass the doGet along.  */
        super.doGet(request, response);
        Logger.traceExit();
    }
}
