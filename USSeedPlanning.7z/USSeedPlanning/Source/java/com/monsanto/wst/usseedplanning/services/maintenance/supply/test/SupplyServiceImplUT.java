package com.monsanto.wst.usseedplanning.services.maintenance.supply.test;

import com.monsanto.wst.commonutils.resources.ResourceUtils;
import com.monsanto.wst.usseedplanning.dao.*;
import com.monsanto.wst.usseedplanning.dao.mock.*;
import com.monsanto.wst.usseedplanning.exception.NoResultsException;
import com.monsanto.wst.usseedplanning.model.core.LoginUser;
import com.monsanto.wst.usseedplanning.model.maintenance.Channel;
import com.monsanto.wst.usseedplanning.model.maintenance.ChannelCriteria;
import com.monsanto.wst.usseedplanning.model.maintenance.supply.Supply;
import com.monsanto.wst.usseedplanning.model.maintenance.supply.conversion.UomConversion;
import com.monsanto.wst.usseedplanning.model.maintenance.supply.data.SupplyBags;
import com.monsanto.wst.usseedplanning.model.maintenance.supply.data.SupplyData;
import com.monsanto.wst.usseedplanning.model.maintenance.supply.data.SupplyMVK;
import com.monsanto.wst.usseedplanning.model.maintenance.supply.identifier.SupplyIdentifiers;
import com.monsanto.wst.usseedplanning.model.planning.PlanType;
import com.monsanto.wst.usseedplanning.services.core.ImportSpreadsheetService;
import com.monsanto.wst.usseedplanning.services.core.mock.MockImportSpreadsheetService;
import com.monsanto.wst.usseedplanning.services.maintenance.supply.*;
import junit.framework.TestCase;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA. Date: Aug 16, 2006 Time: 4:57:13 PM <p/> Unit test for the SupplyServiceImpl object.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class SupplyServiceImplUT extends TestCase {
  public void testCreate() throws Exception {
    SupplyServiceImpl supplyService = new SupplyServiceImpl((SupplyDao) null,
      (YearDao) null, null);
    assertNotNull(supplyService);
  }

  public void testUpdateSupplyForSupplyTypeYATPFND() throws Exception {
    MockSupplyDao supplyDao = new MockSupplyDao();
    LoginUser owner = new LoginUser("tester");
    MockYearDao yearDao = new MockYearDao();
    MockRevisionDao revisionDao = new MockRevisionDao();
    UpdateSupplyServiceFactory updateSupplyServiceFactory =
      new MockUpdateSupplyServiceFactoryForSupplyTypeYATPFND(supplyDao, yearDao, revisionDao);
    SupplyServiceImpl supplyService = new SupplyServiceImpl(supplyDao,
      yearDao, updateSupplyServiceFactory);
    File file = new ResourceUtils()
      .convertPathToFile("com/monsanto/wst/usseedplanning/services/mock/ATPExampleSmall.xls");
    supplyService.updateSupply(file, owner, "ATP", null, "Updating Supply");
    List supplyList = supplyDao.getSupplyList();
    Supply supply = (Supply) supplyList.get(0);
    assertNotNull(supply);
    assertNotNull(supply.getSupplyType().getId());
    assertNotNull(supply.getRevision());
    assertEquals("Updating Supply", supply.getRevision().getComment());
    assertEquals("Adding ATP Supply.", supply.getRevision().getOperation());
    assertEquals(owner, supply.getOwner());
    assertTrue(revisionDao.wasRevisionAdded(supply.getRevision()));
    assertNotNull(supply.getIdentifiers().getChannel());
    assertEquals("*" + Channel.BRANDED_CHANNEL, supply.getIdentifiers().getChannel().getName());
    assertEquals(new Integer(2007), supply.getYear().getYear());
  }

//    public void testUpdateSupply_RemoveBatchRows_LeaveSummaryRowsForSupplyTypeYATPFND() throws Exception {
//        MockImportSpreadsheetServiceContainingBatchRows spreadsheetService = new MockImportSpreadsheetServiceContainingBatchRows();
//        MockSupplyDao supplyDao = new MockSupplyDao();
//        MockRevisionDao revisionDao = new MockRevisionDao();
//        LoginUser owner = new LoginUser("tester");
//        MockYearDao yearDao = new MockYearDao();
//        UpdateSupplyServiceFactory updateSupplyServiceFactory =
//                new MockUpdateSupplyServiceFactoryForSupplyTypeYATPFND(supplyDao, yearDao, revisionDao, spreadsheetService);
//        SupplyServiceImpl supplyService = new SupplyServiceImpl(supplyDao,
//                yearDao, updateSupplyServiceFactory);
//        supplyService.updateSupply(null, owner, "ATP", null, "Updating Supply");
//        List supplyList = supplyDao.getSupplyList();
//        Supply supply = (Supply) supplyList.get(0);
//        assertNotNull(supply);
//        assertNotNull(supply.getSupplyType().getId());
//        assertNotNull(supply.getRevision());
//        assertEquals("Updating Supply", supply.getRevision().getComment());
//        assertEquals("Adding ATP Supply.", supply.getRevision().getOperation());
//        assertEquals(owner, supply.getOwner());
//        assertTrue(revisionDao.wasRevisionAdded(supply.getRevision()));
//        assertNotNull(supply.getIdentifiers().getChannel());
//        assertEquals("*ATPWMAI", supply.getIdentifiers().getChannel().getName());
//        assertEquals(new Integer(2007), supply.getYear().getYear());
//        assertEquals(1, supplyDao.getSupplyInsertCount());
//    }

  public void testUpdateSupply_updateBatchRows_LeaveSummaryRowsForSupplyTypeYATPFND() throws Exception {
    MockImportSpreadsheetServiceContainingBatchRows spreadsheetService = new MockImportSpreadsheetServiceContainingBatchRows();
    MockSupplyDao supplyDao = new MockSupplyDao();
    MockRevisionDao revisionDao = new MockRevisionDao();
    LoginUser owner = new LoginUser("tester");
    MockYearDao yearDao = new MockYearDao();
    UpdateSupplyServiceFactory updateSupplyServiceFactory =
      new MockUpdateSupplyServiceFactoryForSupplyTypeYATPFND(supplyDao, yearDao, revisionDao, spreadsheetService);
    SupplyServiceImpl supplyService = new SupplyServiceImpl(supplyDao,
      yearDao, updateSupplyServiceFactory);
    supplyService.updateSupply(null, owner, "ATP", null, "Updating Supply");
    List supplyList = supplyDao.getSupplyList();
    Supply supply = (Supply) supplyList.get(1);
    assertNotNull(supply);
    assertNotNull(supply.getSupplyType().getId());
    assertNotNull(supply.getRevision());
    assertEquals("Updating Supply", supply.getRevision().getComment());
    assertEquals("Adding ATP Supply.", supply.getRevision().getOperation());
    assertEquals(owner, supply.getOwner());
    assertTrue(revisionDao.wasRevisionAdded(supply.getRevision()));
    assertNotNull(supply.getIdentifiers().getChannel());
    assertEquals("WMAI", supply.getIdentifiers().getChannel().getName());
    assertTrue(supply.getData().getMVK().getCustomerDelivery().doubleValue() == 0.0);
    assertTrue(supply.getData().getMVK().getBlocked().doubleValue() == 0.0);
    assertTrue(supply.getData().getMVK().getRestricted().doubleValue() == 0.0);
    assertTrue(supply.getData().getMVK().getUnrestricted().doubleValue() == 0.0);
    assertEquals(new Double(200), supply.getData().getMVK().getAtp());
    assertEquals(new Integer(2007), supply.getYear().getYear());
    assertEquals(2, supplyDao.getSupplyInsertCount());
  }

  public void testUpdateSupplyForSupplyTypeYATPFNDInvalidChannel() throws Exception {
    MockSupplyDao supplyDao = new MockSupplyDao();
    MockRevisionDao revisionDao = new MockRevisionDao();
    LoginUser owner = new LoginUser("tester");
    MockChannelDaoNoResults channelDao = new MockChannelDaoNoResults();
    MockYearDao yearDao = new MockYearDao();
    UpdateSupplyServiceFactory updateSupplyServiceFactory =
      new MockUpdateSupplyServiceFactoryForSupplyTypeYATPFND(supplyDao, yearDao, revisionDao, channelDao);
    SupplyServiceImpl supplyService = new SupplyServiceImpl(supplyDao,
      yearDao, updateSupplyServiceFactory);
    File file = new ResourceUtils()
      .convertPathToFile("com/monsanto/wst/usseedplanning/services/mock/ATPExampleSmall.xls");
    supplyService.updateSupply(file, owner, "ATP", null, "Updating Supply");
    List supplyList = supplyDao.getSupplyList();
    Supply supply = (Supply) supplyList.get(0);
    assertNotNull(supply);
    assertNotNull(supply.getSupplyType().getId());
    assertNotNull(supply.getRevision());
    assertEquals("Updating Supply", supply.getRevision().getComment());
    assertEquals("Adding ATP Supply.", supply.getRevision().getOperation());
    assertEquals(owner, supply.getOwner());
    assertTrue(revisionDao.wasRevisionAdded(supply.getRevision()));
    assertNotNull(supply.getIdentifiers().getChannel());
    assertEquals(Channel.DEFAULT_CHANNEL, supply.getIdentifiers().getChannel().getName());
  }

  public void testUpdateSupplyForSupplyTypeYATPFNDNoDefaultChannelInSystem() throws Exception {
    MockSupplyDao supplyDao = new MockSupplyDao();
    MockRevisionDao revisionDao = new MockRevisionDao();
    LoginUser owner = new LoginUser("tester");
    MockChannelDaoIllegalState channelDao = new MockChannelDaoIllegalState();
    MockYearDao yearDao = new MockYearDao();
    UpdateSupplyServiceFactory updateSupplyServiceFactory =
      new MockUpdateSupplyServiceFactoryForSupplyTypeYATPFND(supplyDao, yearDao, revisionDao, channelDao);
    SupplyServiceImpl supplyService = new SupplyServiceImpl(supplyDao,
      yearDao, updateSupplyServiceFactory);
    File file = new ResourceUtils()
      .convertPathToFile("com/monsanto/wst/usseedplanning/services/mock/ATPExampleSmall.xls");
    try {
      supplyService.updateSupply(file, owner, "ATP", null, "Updating Supply");
      fail("This should have thrown an exception.");
    }
    catch (IllegalStateException e) {
      assertEquals("Unable to find channel: '" + Channel.DEFAULT_CHANNEL + "'.", e.getMessage());
    }
  }

  public void testUpdateSupplyForSupplyTypeYATPFNDUnknownSupplyType() throws Exception {
    MockSupplyDao supplyDao = new MockSupplyDao();
    MockSupplyTypeDaoNoResults supplyTypeDao = new MockSupplyTypeDaoNoResults();
    MockRevisionDao revisionDao = new MockRevisionDao();
    LoginUser owner = new LoginUser("tester");
    MockYearDao yearDao = new MockYearDao();
    UpdateSupplyServiceFactory updateSupplyServiceFactory =
      new MockUpdateSupplyServiceFactoryForSupplyTypeYATPFND(supplyDao, yearDao, revisionDao, supplyTypeDao);
    SupplyServiceImpl supplyService = new SupplyServiceImpl(supplyDao,
      yearDao, updateSupplyServiceFactory);
    File file = new ResourceUtils()
      .convertPathToFile("com/monsanto/wst/usseedplanning/services/mock/ATPExampleSmall.xls");
    try {
      supplyService.updateSupply(file, owner, "ATP", null, "Updating Supply");
      fail("This should have thrown an exception.");
    }
    catch (IllegalStateException e) {
      assertEquals("Unable to find a supply type with name 'ATP'", e.getMessage());
    }
  }

  public void testUpdateSupplyForSupplyTypeZDCAUnknownUOMDescription() throws Exception {
    MockSupplyDao supplyDao = new MockSupplyDao();
    MockRevisionDao revisionDao = new MockRevisionDao();
    MockUomConversionDaoIllegalStage uomConversionDao = new MockUomConversionDaoIllegalStage();
    LoginUser owner = new LoginUser("tester");
    MockYearDao yearDao = new MockYearDao();
    UpdateSupplyServiceFactory updateSupplyServiceFactory =
      new MockUpdateSupplyServiceFactoryForSupplyTypeZDCA(supplyDao, yearDao, revisionDao, uomConversionDao);
    SupplyServiceImpl supplyService = new SupplyServiceImpl(supplyDao,
      yearDao, updateSupplyServiceFactory);
    File file = new ResourceUtils()
      .convertPathToFile("com/monsanto/wst/usseedplanning/services/mock/ZDCAExampleSmall.xls");
    try {
      supplyService.updateSupply(file, owner, "ZDCA", null, "Updating Supply");
      fail("This should have thrown an exception.");
    }
    catch (IllegalStateException e) {
      assertEquals("Unable to find a factor for description C DK DK440 P26 80M US in conversion table", e.getMessage());
    }
  }

  public void testUpdateSupplyForSupplyTypeZDCA() throws Exception {
    MockSupplyDao supplyDao = new MockSupplyDao();
    MockRevisionDao revisionDao = new MockRevisionDao();
    LoginUser owner = new LoginUser("tester");
    MockYearDao yearDao = new MockYearDao();
    UpdateSupplyServiceFactory updateSupplyServiceFactory =
      new MockUpdateSupplyServiceFactoryForSupplyTypeZDCA(supplyDao, yearDao, revisionDao);
    SupplyServiceImpl supplyService = new SupplyServiceImpl(supplyDao,
      yearDao, updateSupplyServiceFactory);
    File file = new ResourceUtils()
      .convertPathToFile("com/monsanto/wst/usseedplanning/services/mock/ZDCAExampleSmall.xls");
    supplyService.updateSupply(file, owner, "ZDCA", null, "Updating Supply");
    List supplyList = supplyDao.getSupplyList();
    Supply supply = (Supply) supplyList.get(0);
    assertNotNull(supply);
    assertNotNull(supply.getSupplyType().getId());
    assertNotNull(supply.getRevision());
    assertEquals("Updating Supply", supply.getRevision().getComment());
    assertEquals("Adding ZDCA Supply.", supply.getRevision().getOperation());
    assertEquals(owner, supply.getOwner());
    assertTrue(revisionDao.wasRevisionAdded(supply.getRevision()));
    assertNotNull(supply.getIdentifiers().getChannel());
    assertEquals(Channel.BRANDED_CHANNEL, supply.getIdentifiers().getChannel().getName());
    assertEquals(new Integer(2007), supply.getYear().getYear());
  }

  public void testLookupSupplyRevisionsByCriteria() throws Exception {
    MockSupplyDao supplyDao = new MockSupplyDao();
    MockYearDao yearDao = new MockYearDao();
    SupplyServiceImpl supplyService = new SupplyServiceImpl(supplyDao,
      yearDao, null);
    List revisionList = supplyService.lookupSupplyRevisionsByCriteria(PlanType.PARENT_PLAN_TYPE_ID);
    assertNotNull(revisionList);
    assertEquals(2, revisionList.size());
  }

  private class MockChannelDaoNoResults extends MockChannelDao {
    public Channel lookupChannelByName(ChannelCriteria criteria) throws NoResultsException {
      if (!Channel.DEFAULT_CHANNEL.equals(criteria.getChannelName())) {
        throw new NoResultsException("Test Exception.");
      }
      Channel channel = new Channel();
      channel.setId(new Long(12345));
      channel.setName(Channel.DEFAULT_CHANNEL);
      channel.setActive(Boolean.TRUE);
      channel.setDescription("Test default channel");
      return channel;
    }
  }

  private class MockChannelDaoIllegalState extends MockChannelDao {
    public Channel lookupChannelByName(ChannelCriteria criteria) throws NoResultsException {
      throw new NoResultsException("Test Exception.");
    }
  }

  private class MockUomConversionDaoIllegalStage extends MockUomConversionDao {
    public List getAllFactors() {
      List list = new ArrayList();
      UomConversion uomConversion = new UomConversion();
      uomConversion.setDescription("4M");
      uomConversion.setFactor(new Double(0.5));
      list.add(uomConversion);
      uomConversion = new UomConversion();
      uomConversion.setDescription("8M");
      uomConversion.setFactor(new Double(1));
      list.add(uomConversion);
      return list;
    }
  }

  class MockImportSpreadsheetServiceContainingBatchRows implements ImportSpreadsheetService {

    public List getCommonForecasts(File spreadsheet) throws IOException {
      return null;
    }

    public List getDemandForecasts(File spreadsheet) throws IOException {
      return null;
    }

    public List getATPSupply(File file) throws IOException {
      List supplyList = new ArrayList();
      supplyList.add(createSupply());
      supplyList.add(createAnotherSupply());
      return supplyList;
    }

    public List getZDCASupply(File file) throws IOException {
      return null;
    }

    public List getCommonUpload(String columnName, File file) throws IOException {
      return null;
    }

    public List getSavePlanSpreadSheet(File file) throws IOException {
      return null;
    }

    public List getImportHybridToDemand(File file) throws IOException {
      return null;
    }

    private Supply createSupply() {
      Supply supply = new Supply();
      supply.setIdentifiers(new SupplyIdentifiers());
      supply.getIdentifiers().setDescription("C DK DK440 P26 80M US");
      supply.getIdentifiers().setManufacturingName("DK440");
      supply.getIdentifiers().setSLOC("*ATPWMAI");
      supply.setData(new SupplyData());
      supply.getData().setBags(new SupplyBags());
      supply.getData().getBags().setUnrestricted(new Double(23));
      supply.getData().getBags().setRestricted(new Double(56));
      supply.getData().getBags().setBlocked(new Double(456));
      return supply;
    }

    private Supply createAnotherSupply() {
      Supply supply = new Supply();
      supply.setIdentifiers(new SupplyIdentifiers());
      supply.getIdentifiers().setDescription("C DK DK440 P26 80M US");
      supply.getIdentifiers().setManufacturingName("DK440");
      supply.getIdentifiers().setSLOC("WMAI");
      supply.setData(new SupplyData());
      supply.getData().setBags(new SupplyBags());
      supply.getData().getBags().setUnrestricted(new Double(23));
      supply.getData().getBags().setRestricted(new Double(56));
      supply.getData().getBags().setBlocked(new Double(456));
      supply.getData().setMVK(new SupplyMVK());
      supply.getData().getMVK().setCustomerDelivery(new Double(200));
      return supply;
    }
  }

  private class MockUpdateSupplyServiceFactoryForSupplyTypeZDCA implements UpdateSupplyServiceFactory {
    private SupplyDao supplyDao;
    private UomConversionDao uomConversionDao;
    private RevisionDao revisionDao;
    private YearDao yearDao;
    private ImportSpreadsheetService spreadsheetService;
    private SupplyTypeDao supplyTypeDao;
    private ChannelDao channelDao;

    public MockUpdateSupplyServiceFactoryForSupplyTypeZDCA(SupplyDao supplyDao, YearDao yearDao,
                                                           RevisionDao revisionDao, UomConversionDao uomConversionDao) {
      this.revisionDao = revisionDao;
      this.yearDao = yearDao;
      this.supplyDao = supplyDao;
      this.uomConversionDao = uomConversionDao;
      this.spreadsheetService = new MockImportSpreadsheetService();
      this.supplyTypeDao = new MockSupplyTypeDao();
      this.channelDao = new MockChannelDao();
    }

    public MockUpdateSupplyServiceFactoryForSupplyTypeZDCA(SupplyDao supplyDao, YearDao yearDao,
                                                           RevisionDao revisionDao) {
      this.revisionDao = revisionDao;
      this.yearDao = yearDao;
      this.supplyDao = supplyDao;
      this.uomConversionDao = new MockUomConversionDao();
      this.spreadsheetService = new MockImportSpreadsheetService();
      this.supplyTypeDao = new MockSupplyTypeDao();
      this.channelDao = new MockChannelDao();
    }

    public UpdateSupplyService getUpdateSupplyService(String supplyType) {
      return new ZDCAUpdateSupplyService(spreadsheetService, supplyDao, supplyTypeDao, revisionDao, channelDao,
        uomConversionDao, yearDao);
    }
  }

  private class MockUpdateSupplyServiceFactoryForSupplyTypeYATPFND implements UpdateSupplyServiceFactory {
    private SupplyDao supplyDao;
    private SupplyTypeDao supplyTypeDao;
    private RevisionDao revisionDao;
    private YearDao yearDao;
    private ChannelDao channelDao;
    private ImportSpreadsheetService spreadsheetService;

    public MockUpdateSupplyServiceFactoryForSupplyTypeYATPFND(SupplyDao supplyDao, YearDao yearDao,
                                                              RevisionDao revisionDao,
                                                              ImportSpreadsheetService spreadsheetService) {
      this.revisionDao = revisionDao;
      this.yearDao = yearDao;
      this.supplyDao = supplyDao;
      this.spreadsheetService = spreadsheetService;
      this.channelDao = new MockChannelDao();
      this.supplyTypeDao = new MockSupplyTypeDao();
    }

    public MockUpdateSupplyServiceFactoryForSupplyTypeYATPFND(SupplyDao supplyDao, YearDao yearDao,
                                                              RevisionDao revisionDao) {
      this.revisionDao = revisionDao;
      this.yearDao = yearDao;
      this.supplyDao = supplyDao;
      this.spreadsheetService = new MockImportSpreadsheetService();
      this.channelDao = new MockChannelDao();
      this.supplyTypeDao = new MockSupplyTypeDao();
    }

    public MockUpdateSupplyServiceFactoryForSupplyTypeYATPFND(SupplyDao supplyDao, YearDao yearDao,
                                                              RevisionDao revisionDao, ChannelDao channelDao) {
      this.channelDao = channelDao;
      this.revisionDao = revisionDao;
      this.yearDao = yearDao;
      this.supplyDao = supplyDao;
      this.spreadsheetService = new MockImportSpreadsheetService();
      this.supplyTypeDao = new MockSupplyTypeDao();
    }

    public MockUpdateSupplyServiceFactoryForSupplyTypeYATPFND(SupplyDao supplyDao, YearDao yearDao,
                                                              RevisionDao revisionDao, SupplyTypeDao supplyTypeDao) {
      this.revisionDao = revisionDao;
      this.yearDao = yearDao;
      this.supplyDao = supplyDao;
      this.supplyTypeDao = supplyTypeDao;
      this.spreadsheetService = new MockImportSpreadsheetService();
      this.channelDao = new MockChannelDao();
    }

    public UpdateSupplyService getUpdateSupplyService(String supplyType) {
      return new YATPFNDUpdateSupplyService(spreadsheetService, supplyDao, supplyTypeDao, revisionDao, channelDao,
        yearDao);
    }
  }
}
