/*
BatchServiceImpl was created on Dec 5, 2006 using Monsanto
resources and is the sole property of Monsanto.  Any duplication of the
code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.usseedplanning.services.batchupdate;

import com.monsanto.AbstractLogging.FatalEvent;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.wst.emailtemplate.domain.EmailHeaderInfo;
import com.monsanto.wst.emailtemplate.services.EmailService;
import com.monsanto.wst.usseedplanning.dao.BatchDao;
import com.monsanto.wst.usseedplanning.dao.PlanDao;
import com.monsanto.wst.usseedplanning.model.core.BatchSummary;
import com.monsanto.wst.usseedplanning.model.core.LoginUser;
import com.monsanto.wst.usseedplanning.services.cache.LexiconServiceErrorHandler;
import com.monsanto.wst.usseedplanning.services.cache.ProductLookupService;

import java.io.IOException;
import java.util.List;

/**
 * Filename:    $RCSfile: BatchServiceImpl.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: vrbethi $    	 On:	$Date: 2007-03-12 15:29:19 $
 *
 * @author vrbethi
 * @version $Revision: 1.18 $
 */
public class BatchServiceImpl implements BatchService {
    private BatchDao batchDao;
    private ProductLookupService service;
    private LoginUser loginUser;
    private PlanDao planDao;
    private CacheUpdater cacheUpdater;
    private EmailService eMailService;
    private NewProductService newProductService;
    private BatchSummary batchSummary;

    public BatchServiceImpl(LoginUser loginUser, ProductLookupService service, BatchDao batchDao, PlanDao planDao, CacheUpdater cacheUpdater, EmailService eMailService, NewProductService newProductService) {
        this.batchDao = batchDao;
        this.service = service;
        this.loginUser = loginUser;
        this.planDao = planDao;
        this.cacheUpdater = cacheUpdater;
        this.eMailService = eMailService;
        this.newProductService = newProductService;
        this.batchSummary = new BatchSummary();
    }

    public boolean runBatch() throws IOException {
        LexiconServiceErrorHandler handler = new LexiconServiceErrorHandler("c:/batchlexiconoutput.txt");
        boolean batchRan=true;
        try{
            List list = batchDao.lookUpSupplyDemandProducts();

//            list.clear();
//            NameType nameType = new NameType();
//            nameType.setNameType("Commercial");
//            ProductCriteria criteria = new ProductCriteria("TXP068-D", nameType, "TXP068-D");
//            criteria.setOrigin("DEMAND");
//            list.add(criteria);
//            criteria = new ProductCriteria("TXP068-D", nameType, "TXP068-D");
//            criteria.setOrigin("DEMAND");
//            list.add(criteria);
//            list.add(new ProductCriteria("87IDI2EZRAB",nameType,"87IDI2EZRAB"));
//            list.add(new ProductCriteria("DKC39-47",nameType,"ND6233EZN1"));
//            list.add(new ProductCriteria("ND3604",nameType,"ND3604"));
//            list.add(new ProductCriteria("DKC65-44",nameType,"DKC65-44"));
            //Lexicon look up Return a list of product details
            service.registerErrorHandler(handler);
            List productDetailList = service.lookupProductDetailByCriteria(list);
            this.newProductService.preserveEntries(productDetailList);
            alterListOfProductDetails(productDetailList);

            //Add to temp tables
            planDao.addTempProductDetailsAndCommercialProducts(productDetailList);
            cacheUpdater.setBatchSummary(this.batchSummary);
            cacheUpdater.setCurrentUser(this.loginUser);
            cacheUpdater.lookUpNewModifiedDeletedProducts(productDetailList);
            System.out.println(""+ batchSummary.toString());
        }catch(Exception e){
            System.out.println("e.getStackTrace() = " + e.getStackTrace());
            System.out.println("e.getMessage() = " + e.getMessage());
            Logger.log(new FatalEvent(e));
            batchRan=false;
        }
        sendNotification(batchRan);
        handler.saveAndClose();
        return batchRan;
    }

    private void sendNotification(boolean batchRan) {
        String message = "Batch Successful";
        if(!batchRan){
            message="Batch Failed";
        }
        EmailHeaderInfo headerInfo = new EmailHeaderInfo(System.getProperty("mail.recipient"), "VRBETHI@MONSANTO.COM", message+" "+System.getProperty("lsi.function"));
        headerInfo.setContentType("text/html");
        eMailService.sendEmail("batch",headerInfo,null);
    }

    public void setLoginUser(LoginUser loginUser) {
        this.loginUser = loginUser;
    }

    public BatchSummary getBatchSummary() {
        return batchSummary;
    }

    public void alterListOfProductDetails(List productList){
    }
}

