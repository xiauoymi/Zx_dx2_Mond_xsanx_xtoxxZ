package com.monsanto.wst.usseedplanning.view.jsp.maintenance.seedEntity.test;

import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.wst.usseedplanning.constants.MainConstants;
import com.monsanto.wst.usseedplanning.view.jsp.maintenance.seedEntity.JspDisplayAllObsFactorsView;
import com.monsanto.wst.view.ViewRenderingException;
import com.monsanto.wst.view.test.mock.MockUCCHelperThrowsIOException;
import junit.framework.TestCase;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Aug 14, 2006
 * Time: 9:35:36 AM
 * To change this template use File | Settings | File Templates.
 */
public class JspDisplayAllObsFactorsView_UT extends TestCase {
    private MockUCCHelper helper;

    protected void setUp() throws Exception {
        helper = new MockUCCHelper(null);
    }

    public void testCreate() throws Exception {
        JspDisplayAllObsFactorsView view = new JspDisplayAllObsFactorsView();
        assertNotNull(view);
    }

    public void testRenderView() throws Exception {
        JspDisplayAllObsFactorsView view = new JspDisplayAllObsFactorsView();
        view.renderView(helper);
        assertTrue(helper.wasSentTo(MainConstants.DISPLAY_OBS_FACTOR_JSP));
    }

    public void testRenderViewThrowsException() throws Exception {
        MockUCCHelperThrowsIOException helperThrowsIOException = new MockUCCHelperThrowsIOException(null);
        JspDisplayAllObsFactorsView view = new JspDisplayAllObsFactorsView();
        try {
            view.renderView(helperThrowsIOException);
            fail("This should have thrown Exception");
        } catch (ViewRenderingException e) {
            assertEquals("Unable to Render View", e.getMessage());
        }
    }
}
