package com.monsanto.wst.usseedplanning.Servlet.test.mock;

import com.monsanto.ServletFramework.UseCaseController;
import com.monsanto.ServletFramework.UCCHelper;

import java.io.IOException;

/**
 * Created by IntelliJ IDEA.
 * Date: Feb 16, 2007
 * Time: 11:05:43 AM
 * <p/>
 * TODO: Enter description for class.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class MockUseCaseController implements UseCaseController {
    public void run(UCCHelper helper) throws IOException {
        //To change body of implemented methods use File | Settings | File Templates.
    }
}
