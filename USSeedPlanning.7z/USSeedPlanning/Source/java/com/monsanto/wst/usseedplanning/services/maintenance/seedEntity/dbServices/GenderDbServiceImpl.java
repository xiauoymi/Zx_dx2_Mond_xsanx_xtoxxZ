package com.monsanto.wst.usseedplanning.services.maintenance.seedEntity.dbServices;

import com.monsanto.wst.usseedplanning.dao.GenderDao;
import com.monsanto.wst.usseedplanning.services.maintenance.seedEntity.GenderService;
import com.monsanto.wst.factory.AbstractGenericFactory;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Aug 17, 2006
 * Time: 9:12:06 AM
 * To change this template use File | Settings | File Templates.
 */
public class GenderDbServiceImpl implements GenderService {

  private GenderDao dao;

  public GenderDbServiceImpl(GenderDao dao){
    if(dao==null){
      throw new IllegalArgumentException("The GenderDao passed to the constructor of GenderServiceImpl was null.");
    }
    this.dao = dao;
  }

  public List getActiveGenders() {
    return dao.getActiveGenders();
  }
}
