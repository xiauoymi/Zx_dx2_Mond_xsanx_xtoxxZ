package com.monsanto.wst.usseedplanning.controller.core;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.wst.servletframework.AbstractDispatchController;
import com.monsanto.wst.view.View;
import com.monsanto.wst.usseedplanning.services.core.LogReaderService;
import com.monsanto.wst.usseedplanning.view.factory.ViewFactory;

import java.io.IOException;
import java.io.File;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * Date: Apr 7, 2006
 * Time: 12:55:50 PM
 * <p/>
 * This class is used to control admin requests.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class AdminController extends AbstractDispatchController {
    private ViewFactory viewFactory;
    private LogReaderService logReaderService;

    public AdminController(ViewFactory viewFactory, LogReaderService logReaderService) {
        this.viewFactory = viewFactory;
        this.logReaderService = logReaderService;
    }

    protected void notSpecified(UCCHelper helper) throws IOException {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    /**
     * This method retrieves a list of log files and renders them using the appropriate view.
     *
     * @param helper UCCHelper object containing the request and response.
     * @throws IOException - If unable to access the request or response.
     */
    public void lookupLogFileList(UCCHelper helper) throws IOException {
        List logFileList = logReaderService.getLogFileList();
        helper.setRequestAttributeValue("logFileList", logFileList);
        View view = viewFactory.getLogFileListView();
        view.renderView(helper);
    }

    /**
     * This method retrieves a log file based on the name specified in the request and renders a view of the contents.
     *
     * @param helper UCCHelper object containing the request and response.
     * @throws IOException - If unable to access the request or response.
     */
    public void lookupLogFile(UCCHelper helper) throws IOException {
        String fileName = helper.getRequestParameterValue("logFileName");
        File logFile = logReaderService.getLogFile(fileName);
        helper.setRequestAttributeValue("logFile", logFile);
        View view = viewFactory.getLogFileView();
        view.renderView(helper);
    }

}
