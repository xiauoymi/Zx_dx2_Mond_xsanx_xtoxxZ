/*
 BatchService was created on Dec 5, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.usseedplanning.services.batchupdate;

import com.monsanto.wst.usseedplanning.model.core.LoginUser;
import com.monsanto.wst.usseedplanning.model.core.BatchSummary;

import java.util.List;
import java.io.IOException;

/**
 * Filename:    $RCSfile: BatchService.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: vrbethi $    	 On:	$Date: 2007-03-12 15:29:19 $
 *
 * @author vrbethi
 * @version $Revision: 1.4 $
 */
public interface BatchService {
    boolean runBatch() throws IOException;

    void setLoginUser(LoginUser loginUser);

    BatchSummary getBatchSummary();

    void alterListOfProductDetails(List productList);
}