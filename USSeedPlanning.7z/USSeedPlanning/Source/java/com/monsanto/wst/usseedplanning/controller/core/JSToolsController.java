package com.monsanto.wst.usseedplanning.controller.core;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.wst.servletframework.AbstractDispatchController;
import com.monsanto.wst.usseedplanning.view.factory.ViewFactory;
import com.monsanto.wst.view.View;

import java.io.IOException;

/**
 * Created by IntelliJ IDEA.
 * Date: Aug 17, 2006
 * Time: 2:43:27 PM
 * <p/>
 * This class is a controller for generating JS Tools.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class JSToolsController extends AbstractDispatchController {
    private ViewFactory viewFactory;

    /**
     * This constructor takes all dependencies.
     *
     * @param viewFactory ViewFactory object for creating views.
     */
    public JSToolsController(ViewFactory viewFactory) {
        this.viewFactory = viewFactory;
    }

    /**
     * This method is the default action and renders the JS constants view.
     *
     * @param helper UCCHelper object containing the request and response.
     * @throws IOException - If unable to access the request or response.
     */
    protected void notSpecified(UCCHelper helper) throws IOException {
        View view = this.viewFactory.getJSConstantsView();
        view.renderView(helper);
    }
}
