package com.monsanto.wst.usseedplanning.view.jsp.planning;

import com.monsanto.wst.view.View;
import com.monsanto.wst.view.ViewRenderingException;
import com.monsanto.wst.usseedplanning.constants.ServletConstants;
import com.monsanto.ServletFramework.UCCHelper;

import java.io.IOException;

/**
 * Created by IntelliJ IDEA.
 * Date: Feb 16, 2007
 * Time: 12:51:37 PM
 * <p/>
 * TODO: Enter description for class.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class JspDownloadPlanView implements View {
    public void renderView(UCCHelper helper) throws ViewRenderingException {
        try {
            helper.forward(ServletConstants.DOWNLOAD_PLAN_PAGE);
        } catch (IOException e) {
            throw new ViewRenderingException("Unable to render page at path: '" +
                    ServletConstants.DOWNLOAD_PLAN_PAGE + "'", e);
        }
    }
}
