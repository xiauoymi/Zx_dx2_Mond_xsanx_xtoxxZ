/*
DashboardReport was created on Aug 31, 2006 using Monsanto
resources and is the sole property of Monsanto.  Any duplication of the
code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.usseedplanning.reports;

import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.wst.dbtemplate.DBTemplate;
import com.monsanto.wst.dbtemplate.DBTemplateImpl;
import com.monsanto.wst.emailtemplate.services.EmailService;
import com.monsanto.wst.reportingframework.core.AbstractReport;
import com.monsanto.wst.reportingframework.core.ReportParameters;
import com.monsanto.wst.reportingframework.core.ReportProperties;
import com.monsanto.wst.reportingframework.exceptions.ReportException;
import com.monsanto.wst.usseedplanning.dao.ChannelDao;
import com.monsanto.wst.usseedplanning.dao.DemandDao;
import com.monsanto.wst.usseedplanning.dao.PlanTypeDao;
import com.monsanto.wst.usseedplanning.dao.dbTemplate.*;
import com.monsanto.wst.usseedplanning.model.planning.Plan;
import com.monsanto.wst.usseedplanning.model.planning.PlanRevision;
import com.monsanto.wst.usseedplanning.model.reports.DashboardReportModel;
import com.monsanto.wst.usseedplanning.services.core.LoginService;
import com.monsanto.wst.usseedplanning.services.core.LookupService;
import com.monsanto.wst.usseedplanning.services.core.LookupServiceImpl;
import com.monsanto.wst.usseedplanning.services.planning.PlanService;
import com.monsanto.wst.usseedplanning.services.planning.PlanServiceImpl;
import com.monsanto.wst.usseedplanning.services.reports.DashboardReportService;
import com.monsanto.wst.usseedplanning.services.reports.DashboardReportServiceImpl;
import com.monsanto.wst.usseedplanning.services.cache.ProductCachingServiceImpl;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import java.util.List;

/**
 * Filename:    $RCSfile: DashboardReport.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: njminsh $    	 On:	$Date: 2007-02-23 20:22:02 $
 *
 * @author ffbrac
 * @version $Revision: 1.22 $
 */
public class DashboardReport extends AbstractReport {
    private DBTemplate dbtemplate;

    public DashboardReport() {
        String[] strings = new String[]{"database/dbTemplate.xml", "database/dbTemplate-planning.xml"};
        dbtemplate = new DBTemplateImpl("database/dbtemplate-config.xml", strings);
    }

    public DashboardReport(DBTemplate template) {
        dbtemplate = template;
    }

    public Document buildReportXML(ReportParameters reportParameters, ReportProperties reportProperties) throws
            ReportException {
        List dashboardReportList;
        Document document = DOMUtil.newDocument();

        String planId = (String) reportParameters.getReportParameter("planId");

        Element rootElement = document.createElement("dashboard");
        document.appendChild(rootElement);
        getPlanHeader(rootElement);


        if (planId != null && !planId.equals("0")) {
            dashboardReportList = getPlanReportList(new Long(planId));
        } else {
            dashboardReportList = getAllPlanReportlist();
        }
        getPlanReport(rootElement, dashboardReportList);
        addResponseParameter(rootElement, planId);
        return document;
    }

    private void getPlanReport(Element rootElement, List dashboardReportList) {

        Element dataElement = DOMUtil.addChildElement(rootElement, "data");
        Element rowElement;
        for (int i = 0; i < dashboardReportList.size(); i++) {
            DashboardReportModel dashboardModel = (DashboardReportModel) dashboardReportList.get(i);
            rowElement = DOMUtil.addChildElement(dataElement, "row");
            DOMUtil.addChildElement(rowElement, "date", dashboardModel.getDate());
            DOMUtil.addChildElement(rowElement, "time", dashboardModel.getTime());
            DOMUtil.addChildElement(rowElement, "user", dashboardModel.getUserId());
            DOMUtil.addChildElement(rowElement, "id", i + 1);
            DOMUtil.addChildElement(rowElement, "plan_type", dashboardModel.getPlanType());
            DOMUtil.addChildElement(rowElement, "value", dashboardModel.getValue());
            DOMUtil.addChildElement(rowElement, "description", dashboardModel.getDescription());
            DOMUtil.addChildElement(rowElement, "comment", dashboardModel.getComment());
        }
        return;
    }

    private List getAllPlanReportlist() {
        DashboardReportService dashboardReportService = new DashboardReportServiceImpl(new DBTemplateDashboardReportDao(this.dbtemplate));
        return dashboardReportService.getDashboardReport();

    }

    private void getPlanHeader(Element rootElement) {
        //TODO How do I remove this and use application container
        LookupService lookupService = new LookupServiceImpl(new DBTemplateLookupDao(this.dbtemplate));
        final DBTemplatePlanDao planDao = new DBTemplatePlanDao(dbtemplate);
        final DBTemplateProductDetailsDao productDetailsDao = new DBTemplateProductDetailsDao(dbtemplate);
        final DBTemplateRevisionDao revisionDao = new DBTemplateRevisionDao(dbtemplate);
        PlanService planService = new PlanServiceImpl(planDao,
                revisionDao,
                null,
                new DbTemplateYearDao(dbtemplate), null,
                productDetailsDao, null, (DemandDao) null, (EmailService) null, (LoginService) null,
                (ChannelDao) null, (PlanTypeDao) null, new ProductCachingServiceImpl(productDetailsDao, null, revisionDao));
        List planList = planService.lookupAllPlans();

        List planRevisionList = lookupService.lookupPlanRevisionList();

        Element planElement = DOMUtil.addChildElement(rootElement, "plan");
        Element rowElement;
        for (int i = 0; i < planRevisionList.size(); i++) {
            PlanRevision planRevision = (PlanRevision) planRevisionList.get(i);
            rowElement = DOMUtil.addChildElement(planElement, "row");
            DOMUtil.addChildElement(rowElement, "plan_id", planRevision.getPlanId().toString());
            DOMUtil.addChildElement(rowElement, "description", planRevision.getPlanDate() + " - " + planRevision.getPlanName());
        }
        if (planList != null) {
            for (int i = 0; i < planList.size(); i++) {
                Plan plan = (Plan) planList.get(i);
                rowElement = DOMUtil.addChildElement(planElement, "row");
                DOMUtil.addChildElement(rowElement, "plan_id", plan.getId().toString());
                String planComment = plan.getRevision().getComment();
                if (planComment == null) {
                    planComment = "";
                }
                //TODO Move this to the class .. We are doing this all the over the place May be a method in plan would help
                DOMUtil.addChildElement(rowElement, "description", plan.getPlanSummary().toString());
            }
        }
        return;
    }

    private List getPlanReportList(Long planId) {
        LookupService lookupService = new LookupServiceImpl(new DBTemplateLookupDao(this.dbtemplate));
        return lookupService.lookupGeneratedPlanComponents(planId);
    }

    public Document buildFilterXML(ReportParameters reportParameters, ReportProperties reportProperties) throws
            ReportException {
        return null;
    }

    private void addResponseParameter(Element rootElement, String parameter) {
        Element paramElement = DOMUtil.addChildElement(rootElement, "parameters");
        DOMUtil.addChildElement(paramElement, "planId", parameter);
    }

    public String returnExportFileNameKey() {
        return null;
    }
}