package com.monsanto.wst.usseedplanning.controller.core.test;

import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.wst.usseedplanning.constants.MainConstants;
import com.monsanto.wst.usseedplanning.controller.core.CancelActionController;
import com.monsanto.wst.usseedplanning.view.factory.ViewFactory;
import com.monsanto.wst.usseedplanning.view.factory.mock.MockViewFactory;
import com.monsanto.wst.view.test.mock.MockView;
import junit.framework.TestCase;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Aug 11, 2006
 * Time: 10:57:07 AM
 * To change this template use File | Settings | File Templates.
 */
public class CancelActionController_UT extends TestCase {

    MockUCCHelper helper = null;

    protected void setUp() throws Exception {
        helper = new MockUCCHelper(null);
    }

    public void testCreate() throws Exception {
        CancelActionController controller = new CancelActionController((ViewFactory)null);
        assertNotNull(controller);
    }

    public void testViewForTargetYieldCancel() throws Exception {
        helper.setRequestParameterValue(MainConstants.TYPE, MainConstants.YIELD_TARGET);
        ViewFactory viewFactory = new MockViewFactory();
        CancelActionController controller = new CancelActionController(viewFactory);
        controller.run(helper);
        MockView view = (MockView)viewFactory.getAllYieldTargetsView();
        assertTrue(view.wasViewRendered());
    }

    public void testViewForObsFactorCancel() throws Exception {
        helper.setRequestParameterValue(MainConstants.TYPE, MainConstants.OBS_FACTOR);
        ViewFactory viewFactory = new MockViewFactory();
        CancelActionController controller = new CancelActionController(viewFactory);
        controller.run(helper);
        MockView view = (MockView)viewFactory.getAllObsFactorsView();
        assertTrue(view.wasViewRendered());
    }
    
    public void testViewForQAThresholdCancel() throws Exception {
        helper.setRequestParameterValue(MainConstants.TYPE, MainConstants.QA_THRESHOLD);
        ViewFactory viewFactory = new MockViewFactory();
        CancelActionController controller = new CancelActionController(viewFactory);
        controller.run(helper);
        MockView view = (MockView)viewFactory.getAllQAThresholdView();
        assertTrue(view.wasViewRendered());
    }


}
