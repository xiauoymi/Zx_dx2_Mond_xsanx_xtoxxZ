package com.monsanto.wst.usseedplanning.services.maintenance.forecast;

import com.monsanto.wst.usseedplanning.exception.ServiceUnavailableException;
import com.monsanto.wst.usseedplanning.model.core.LoginUser;

import java.io.File;
import java.io.IOException;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * Date: Aug 8, 2006
 * Time: 2:30:45 PM
 * <p/>
 * This interface defineds the contract for retrieving and modifying forecast information.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public interface ForecastService {
  /**
   * This method adds a list of common forecasts containing in the specified spreadsheet to the system.
   *
   * @param spreadsheet File representing the spreadsheet with the data.
   * @param planType
   * @param currentUser LoginUser object representing the current user.
   * @param comments String representing revision comments.
   * @throws java.io.IOException - If unable to read the spreadsheet.
   */
  void addCommonForecasts(File spreadsheet, Long planType, LoginUser currentUser, String comments) throws
    IOException,
    ServiceUnavailableException, InvalidForecastException;

  void addDemandForecasts(File spreadsheet, LoginUser currentUser, String comments) throws
    IOException,
    ServiceUnavailableException, InvalidForecastException;

  /**
   * This method returns a map of channels to demand revisions.
   *
   * @param planTypeId
   * @return List - Representing the channels to demand revisions.
   */
  List lookupDemandRevisionByChannel(Long planTypeId);
}
