package com.monsanto.wst.usseedplanning.utils.testutils.test;

import com.monsanto.AbstractLogging.Logger;
import com.monsanto.wst.factory.AbstractGenericFactory;
import com.monsanto.wst.factory.DelegatingLocatorGenericFactory;
import com.monsanto.wst.factory.GenericFactoryInitializationException;
import com.monsanto.wst.usseedplanning.utils.testutils.USSeedPlanningBaseTestCase;

/**
 * Created by IntelliJ IDEA.
 * Date: Sep 12, 2006
 * Time: 3:50:45 PM
 * <p/>
 * Unit test for the USSeedPlanningBaseTestCase object.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class USSeedPlanningBaseTestCaseUT extends USSeedPlanningBaseTestCase {
  protected void tearDown() throws Exception {
    super.tearDown();
    assertFalse(Logger.isRegistered(Logger.DEBUG_LOG));
    try {
      AbstractGenericFactory.getInstance();
      fail("This should have thrown an exception.");
    } catch (GenericFactoryInitializationException e) {
      // Assert that the generic factory was reverted back.
    }
  }

  public void testSetUp() throws Exception {
    assertTrue(Logger.isEnabled(Logger.DEBUG_LOG));
    assertEquals(DelegatingLocatorGenericFactory.class, AbstractGenericFactory.getInstance().getClass());
    assertNotNull(getTestUtils());
  }
}
