/*
 EditStageFactorValidator was created on Sep 19, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.usseedplanning.controller.validator;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.wst.validator.HttpRequestErrors;
import com.monsanto.wst.validator.HttpValidator;
import org.apache.commons.lang.StringUtils;

import java.io.IOException;

/**
 * Filename:    $RCSfile: SaveStageFactorValidator.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: SSPATI1 $    	 On:	$Date: 2006-09-20 17:41:22 $
 *
 * @author sspati1
 * @version $Revision: 1.4 $
 */
public class SaveStageFactorValidator implements HttpValidator {

    /**
   * This method validates the appropriate fields from the request.
   *
   * @param helper UCCHelper object containing the request and response.
   * @return HttpRequestErrors - Object representing any errors.
   * @throws IOException - If unable to access request.
   */
  public HttpRequestErrors validate(UCCHelper helper) throws IOException {
      HttpRequestErrors errors = new HttpRequestErrors();
      String comments = helper.getRequestParameterValue("comments");
      String factor = helper.getRequestParameterValue("factor");
      if (StringUtils.isEmpty(comments)) {
          errors.addError("comments", "Comments for Stage Factor is required.");
      }
      if (StringUtils.isEmpty(factor)) {
          errors.addError("factor", "Stage Factor for Stage Factor is required.");
      }
      else if (StringUtils.isAlpha(factor)) {
          errors.addError("factorNumeric", "Stage Factor should be a numeric value.");
      }
      return errors;
  }
}