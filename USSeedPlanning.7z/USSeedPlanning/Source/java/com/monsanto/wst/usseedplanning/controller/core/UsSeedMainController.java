package com.monsanto.wst.usseedplanning.controller.core;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.ServletFramework.UseCaseController;
import com.monsanto.wst.usseedplanning.view.factory.ViewFactory;
import com.monsanto.wst.view.View;

import java.io.IOException;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Aug 15, 2006
 * Time: 3:23:28 PM
 * To change this template use File | Settings | File Templates.
 */
public class UsSeedMainController implements UseCaseController {

    private ViewFactory viewFactory;

    public UsSeedMainController(ViewFactory viewFactory) {
        this.viewFactory = viewFactory;
    }

    public void run(UCCHelper helper) throws IOException {
	    View view;
        view = this.viewFactory.getUSSeedHomeView();
        view.renderView(helper);
    }
}
