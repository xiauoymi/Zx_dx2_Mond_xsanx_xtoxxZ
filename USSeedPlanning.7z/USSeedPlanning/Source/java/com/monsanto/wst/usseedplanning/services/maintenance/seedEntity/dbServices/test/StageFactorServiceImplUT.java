/*
 StageFactorServiceImplUT was created on Sep 18, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.usseedplanning.services.maintenance.seedEntity.dbServices.test;

import com.monsanto.wst.usseedplanning.dao.RevisionDao;
import com.monsanto.wst.usseedplanning.dao.StageFactorDao;
import com.monsanto.wst.usseedplanning.dao.mock.MockRevisionDao;
import com.monsanto.wst.usseedplanning.dao.mock.MockStageFactorDao;
import com.monsanto.wst.usseedplanning.exception.NoResultsException;
import com.monsanto.wst.usseedplanning.model.maintenance.StageFactor;
import com.monsanto.wst.usseedplanning.services.maintenance.seedEntity.dbServices.StageFactorServiceImpl;
import junit.framework.TestCase;

import java.util.ArrayList;
import java.util.List;

/**
 * Filename:    $RCSfile: StageFactorServiceImplUT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: jdpoul $
 * On:	$Date: 2006-10-25 17:49:40 $
 *
 * @author sspati1
 * @version $Revision: 1.4 $
 */
public class StageFactorServiceImplUT extends TestCase {

  public void testCreate() throws Exception {
    StageFactorServiceImpl service = new StageFactorServiceImpl((StageFactorDao) null, (RevisionDao) null);
    assertNotNull(service);
  }

  public void testLookupAllStageFactors() throws Exception {
    MockStageFactorDao stageFactorDao = new MockStageFactorDao();
    StageFactorServiceImpl stageFactorService = new StageFactorServiceImpl(stageFactorDao, (RevisionDao) null);
    List list = stageFactorService.LookupAllStageFactors();
    assertEquals(2, list.size());
  }


  public void testLookupByRevisionId() throws Exception {
    MockStageFactorDao stageFactorDao = new MockStageFactorDao();
    MockRevisionDao revisionDao = new MockRevisionDao();
    StageFactorServiceImpl stageFactorService = new StageFactorServiceImpl(stageFactorDao, revisionDao);
    assertNotNull(stageFactorService.lookupStageFactorsByRevisionId(new Long(123)));
  }

  public void testAddStageFactor() throws Exception {
    MockStageFactorDao stageFactorDao = new MockStageFactorDao();
    MockRevisionDao revisionDao = new MockRevisionDao();
    StageFactorServiceImpl stageFactorService = new StageFactorServiceImpl(stageFactorDao, revisionDao);
    stageFactorService.saveStageFactor(new StageFactor(), "comments");
    assertTrue(stageFactorDao.isWasAdded());
  }

  public void testGetAllApplicableStageFactorsInOrderOfPrecedenceListValidateOrder() throws Exception {
    StageFactor factor1 = new StageFactor();
    MockListStageFactorDao dao = new MockListStageFactorDao();
    MockRevisionDao revisionDao = new MockRevisionDao();

    factor1.setProductName("test");
    StageFactor factor2 = new StageFactor();
    factor2.setProductName("test1");
    StageFactor factor3 = new StageFactor();
    factor3.setProductName(null);
    StageFactor factor4 = new StageFactor();
    factor4.setProductName("anotherFactor");


    dao.insertStageFactor(factor1);
    dao.insertStageFactor(factor2);
    dao.insertStageFactor(factor3);
    dao.insertStageFactor(factor4);
    StageFactorServiceImpl yieldTargetDbService = new StageFactorServiceImpl(dao, revisionDao);
    List factors = yieldTargetDbService
        .getAllApplicableStageFactorsInOrderOfPrecedence("test", null, null, new Long(1));
    StageFactor factor = (StageFactor) factors.get(0);
    assertEquals("test", factor.getProductName());
    assertEquals(2, factors.size());
  }

  public class MockListStageFactorDao implements StageFactorDao {
    private List factors = new ArrayList();

    public List lookupAll() {
      return null;
    }

    public StageFactor lookupByRevisionId(Long revisionId) throws NoResultsException {
      return null;
    }

    public void insertStageFactor(StageFactor stageFactor) {
      factors.add(stageFactor);
    }

    public List getAllApplicableStageFactors(Long maxRevisionId) {
      return factors;
    }
  }
}