package com.monsanto.wst.usseedplanning.view.jsp.maintenance.seedEntity.test;

import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.wst.usseedplanning.constants.MainConstants;
import com.monsanto.wst.usseedplanning.view.jsp.maintenance.seedEntity.JspSaveObsFactorView;
import com.monsanto.wst.view.ViewRenderingException;
import com.monsanto.wst.view.test.mock.MockUCCHelperThrowsIOException;
import junit.framework.TestCase;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Aug 14, 2006
 * Time: 9:30:00 AM
 * To change this template use File | Settings | File Templates.
 */
public class JspSaveObsFactorView_UT extends TestCase {

    private MockUCCHelper helper;
    private List errorList = new ArrayList();

    protected void setUp() throws Exception {
        helper = new MockUCCHelper(null);
    }

    public void testCreate() throws Exception {
        JspSaveObsFactorView view  = new JspSaveObsFactorView();
        assertNotNull(view);
    }

    public void testRenderView() throws Exception {
        JspSaveObsFactorView view  = new JspSaveObsFactorView();
        view.renderView(helper);
        assertTrue(helper.wasSentTo(MainConstants.CREATE_OBS_FACTOR_JSP));
    }

    public void testRenderViewThrowsException() throws Exception {
        MockUCCHelperThrowsIOException helperThrowsIOException = new MockUCCHelperThrowsIOException(null);
        JspSaveObsFactorView view  = new JspSaveObsFactorView();
        try {
            view.renderView(helperThrowsIOException);
            fail("This should have thrown Exception");
        } catch (ViewRenderingException e) {
            assertEquals("Unable to Render View", e.getMessage());
        }
    }

    public void testRenderViewWithErrors() throws Exception {
        errorList.add("Error 1");
        errorList.add("Error 2");
        JspSaveObsFactorView view = new JspSaveObsFactorView(errorList, MainConstants.ERROR_LIST);
        view.renderView(helper);
        assertTrue(helper.wasSentTo(MainConstants.CREATE_OBS_FACTOR_JSP));
        assertEquals(2, ((List)helper.getRequestAttributeValue(MainConstants.ERROR_LIST)).size());
    }

    public void testRenderViewWithEmptyTypeAndList() throws Exception {
        errorList.add("Error 2");
        JspSaveObsFactorView view = new JspSaveObsFactorView(errorList, "");
        view.renderView(helper);
        assertTrue(helper.wasSentTo(MainConstants.CREATE_OBS_FACTOR_JSP));
        assertNull(helper.getRequestAttributeValue(MainConstants.ERROR_LIST));
    }

    public void testRenderViewWithErrorsThrowsException() throws Exception {
        MockUCCHelperThrowsIOException helperThrowsIOException = new MockUCCHelperThrowsIOException(null);
        errorList.add("Error 1");
        errorList.add("Error 2");
        JspSaveObsFactorView view = new JspSaveObsFactorView(errorList, MainConstants.ERROR_LIST);
        try {
            view.renderView(helperThrowsIOException);
            fail("This should have thrown Exception");
        } catch (ViewRenderingException e) {
            assertEquals("Unable to Render View", e.getMessage());
        }
    }

}
