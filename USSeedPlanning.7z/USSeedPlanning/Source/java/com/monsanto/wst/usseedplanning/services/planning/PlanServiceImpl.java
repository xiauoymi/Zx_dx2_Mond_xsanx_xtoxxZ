package com.monsanto.wst.usseedplanning.services.planning;

import com.monsanto.wst.emailtemplate.domain.EmailHeaderInfo;
import com.monsanto.wst.emailtemplate.services.EmailService;
import com.monsanto.wst.usseedplanning.dao.*;
import com.monsanto.wst.usseedplanning.exception.NoResultsException;
import com.monsanto.wst.usseedplanning.model.cache.ProductCriteria;
import com.monsanto.wst.usseedplanning.model.cache.ProductDetails;
import com.monsanto.wst.usseedplanning.model.core.LoginUser;
import com.monsanto.wst.usseedplanning.model.core.Role;
import com.monsanto.wst.usseedplanning.model.maintenance.*;
import com.monsanto.wst.usseedplanning.model.planning.*;
import com.monsanto.wst.usseedplanning.services.cache.ProductCachingService;
import com.monsanto.wst.usseedplanning.services.cache.ProductLookupService;
import com.monsanto.wst.usseedplanning.services.core.ExportSpreadsheetService;
import com.monsanto.wst.usseedplanning.services.core.ImportSpreadsheetService;
import com.monsanto.wst.usseedplanning.services.core.LoginService;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA. Date: Sep 12, 2006 Time: 11:26:47 AM <p/> This class is a generic implementation of the
 * PlanService interface.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class PlanServiceImpl implements PlanService {
    private PlanDao planDao;
    private RevisionDao revisionDao;
    private ProductLookupService productLookupService;
    private YearDao yearDao;
    private ExportSpreadsheetService exportSpreadsheetService;
    private ProductDetailsDao productDetailsDao;
    private ImportSpreadsheetService importSpreadsheetService;
    private DemandDao demandDao;
    private EmailService emailService;
    private LoginService loginService;
    private ChannelDao channelDao;
    private PlanTypeDao planTypeDao;
    private static final String CREATE_PLAN_OPERATION = "Create Plan";
    private static final String RETURN_EMAIL_ADDRESS = "usseedplanning@monsanto.com";
    private ProductCachingService productCachingService;

    /**
     * This constructor takes all dependencies.
     *
     * @param planDao                  PlanDao object representing access to plan information.
     * @param revisionDao              RevisionDao object representing access to revision information.
     * @param productLookupService     ProductLookupService object representing access to additional product
     *                                 information.
     * @param yearDao                  YearDao object representing access to year information.
     * @param exportSpreadsheetService ExportSpreadsheetService object used to generate spreadsheets.
     * @param productDetailsDao
     * @param importSpreadsheetService
     * @param demandDao
     * @param emailService
     * @param loginService
     * @param channelDao
     * @param planTypeDao
     * @param productCachingService
     */
    public PlanServiceImpl(PlanDao planDao, RevisionDao revisionDao, ProductLookupService productLookupService,
                           YearDao yearDao, ExportSpreadsheetService exportSpreadsheetService,
                           ProductDetailsDao productDetailsDao, ImportSpreadsheetService importSpreadsheetService,
                           DemandDao demandDao, EmailService emailService, LoginService loginService,
                           ChannelDao channelDao, PlanTypeDao planTypeDao, ProductCachingService productCachingService) {
        this.planDao = planDao;
        this.revisionDao = revisionDao;
        this.productLookupService = productLookupService;
        this.yearDao = yearDao;
        this.exportSpreadsheetService = exportSpreadsheetService;
        this.productDetailsDao = productDetailsDao;
        this.importSpreadsheetService = importSpreadsheetService;
        this.demandDao = demandDao;
        this.emailService = emailService;
        this.loginService = loginService;
        this.channelDao = channelDao;
        this.planTypeDao = planTypeDao;
        this.productCachingService = productCachingService;
    }

    /**
     * This method generates a new plan.
     *
     * @param summary     PlanSummary object representing plan summary information.
     * @param criteria    PlanCriteria object representing criteria.
     * @param currentUser LoginUser object representing the current user.
     */
    public void generatePlan(PlanSummary summary, PlanCriteria criteria, LoginUser currentUser) throws Exception {
        Plan plan = createPlanObject(summary, currentUser, criteria);
        updateProductCache(criteria, currentUser);
        this.revisionDao.insert(plan.getRevision());
        this.planDao.addPlanNumber(plan);
        updateDemandCriteria(criteria, plan, currentUser);
        this.planDao.addDemandCrossReference(criteria);
        addPlanEntries(criteria, plan);
        this.planDao.addPlanDetails(plan.getEntries());
        this.planDao.updatePlanNumber(plan);
        PlanCriteria summaryCriteria = new PlanCriteria(plan.getId(), plan.getRevision().getId());
        Plan planWithSummaryInfo = this.planDao.lookupPlanSummaryByCriteria(summaryCriteria);
        plan.setPlanSummary(planWithSummaryInfo.getPlanSummary());
        sendNotificationEmail(plan);
    }

    /**
     * This method returns the plan with the specified id.
     *
     * @param criteria
     * @return Plan - Object representing the plan.
     */
    public Plan lookupPlanByCriteria(PlanCriteria criteria) {
        Plan plan = this.planDao.lookupPlanByCriteria(criteria);
        plan.setExportSpreadsheetService(this.exportSpreadsheetService);
        return plan;
    }

    /**
     * This method retrieves plan summary information based on the criteria specified.
     *
     * @param criteria PlanCriteria object representing criteria.
     * @return Plan - Object representing the plan summary information.
     */
    public Plan lookupPlanSummaryByCriteria(PlanCriteria criteria) {
        return planDao.lookupPlanSummaryByCriteria(criteria);
    }

    public void savePlan(File planSpreadsheet, LoginUser loginUser, String comments) throws Exception {
        List savePlanList = this.importSpreadsheetService.getSavePlanSpreadSheet(planSpreadsheet);
        Revision revision = new Revision("Save Plan", comments, loginUser);
        this.revisionDao.insert(revision);
        Long planId = null;
        List newEntries = new ArrayList();
        for (int i = 0; i < savePlanList.size(); i++) {
            PlanEntry entryToSave = (PlanEntry) savePlanList.get(i);
            PlanEntry planEntry = planDao.lookupPlanEntryById(entryToSave.getId());
            planId = planEntry.getPlanId();
            planEntry.setPlanRevision(revision);
            planEntry.setPlanOwner(loginUser);
            planEntry.setUserData(entryToSave.getUserData());
            planEntry.setCrossPlanData(entryToSave.getCrossPlanData());
            updateCache(entryToSave, planEntry, loginUser, comments);
            newEntries.add(planEntry);
        }
        planDao.addPlanDetails(newEntries);
        planDao.updatePlanSavedFlag(planId);
        if (planId != null) {
            Plan plan = new Plan();
            plan.setId(planId);
            plan.setRevision(revision);
            planDao.updateMinorVersion(plan);
        }
        planDao.updateTotalPlannedParentSeed(newEntries);
    }

    public void commitPlan(LoginUser loginUser, String comments, Long planRevisionId, Long planId) {
        PlanCriteria criteria = new PlanCriteria(planId, planRevisionId);
        List planDemandList = planDao.lookupPlanDemand(criteria);
        Plan plan = planDao.lookupPlanSummaryByCriteria(criteria);
        Revision revision = new Revision("Commit Plan", plan.getPlanSummary().toString(), loginUser);
        this.revisionDao.insert(revision);

        for (int i = 0; i < planDemandList.size(); i++) {
            DemandForecast demandForecast = (DemandForecast) planDemandList.get(i);
            demandForecast.setRevision(revision);
            demandForecast.setOwner(loginUser);
            demandForecast.setNameType(new NameType(NameType.DEFAULT_NAME_TYPE_ID));
            demandForecast.setChannel(lookupCrossPlanChannel(demandForecast.getPlanTypeId()));
            demandForecast.setPlanTypeId(PlanType.PARENT_PLAN_TYPE_ID);
        }
        demandDao.addDemand(planDemandList);
    }

    public List lookupAllPlans() {
        return this.planDao.lookupAllPlans();
    }

    public List lookupPlansByPlanType(Long planTypeId) {
        return planDao.lookupPlansByPlanType(planTypeId);
    }

    /**
     * This method updates the product cache with new product information.
     *
     * @param criteria    PlanCriteria object representing criteria.
     * @param currentUser
     */
    private void updateProductCache(PlanCriteria criteria, LoginUser currentUser) throws Exception {
        List productCriteria = this.planDao.lookupProductCriteria(criteria);
        List cachedProductDetailList = this.productDetailsDao.lookupPlanProductDetails(criteria);
        List productDetailList = productCachingService.cacheSelectedProducts(productCriteria, currentUser);
        this.planDao.addTempProductDetails(productDetailList);
        this.planDao.addTempProductDetails(cachedProductDetailList);
    }

    private Channel lookupCrossPlanChannel(Long planTypeId) {
        try {
            if (PlanType.HYBRID_PLAN_TYPE_ID.equals(planTypeId)) {
                return lookupChannelByNameAndPlanTypeId(Channel.BRANDED_CHANNEL, PlanType.PARENT_PLAN_TYPE_ID);
            } else {
                return lookupChannelByNameAndPlanTypeId(Channel.CP1_CHANNEL, PlanType.PARENT_PLAN_TYPE_ID);
            }
        }
        catch (NoResultsException e) {
            throw new RuntimeException(e);
        }
    }

    private Channel lookupChannelByNameAndPlanTypeId(String channelName, Long planTypeId) throws NoResultsException {
        ChannelCriteria criteria = new ChannelCriteria(channelName, planTypeId);
        return channelDao.lookupChannelByName(criteria);
    }

    private void updateCache(PlanEntry savedEntry, PlanEntry previousEntry, LoginUser currentUser,
                             String comments) throws Exception {
        updateManufacturingName(previousEntry, savedEntry);
        updateFemaleDetails(previousEntry, savedEntry);
        updateMaleDetails(previousEntry, savedEntry);
        if (previousEntry.getProductDetails().isOverridden()) {
            productCachingService.addNewCacheEntry(comments, currentUser, previousEntry.getProductDetails());
        }
    }

    private void updateManufacturingName(PlanEntry previousEntry, PlanEntry savedEntry) {
        previousEntry.getProductDetails().overrideMFGName(savedEntry.getProductDetails());
    }

    private void updateMaleDetails(PlanEntry previousEntry, PlanEntry savedEntry) throws Exception {
        ProductDetails previousMaleDetails = previousEntry.getProductDetails().getMaleParent();
        ProductDetails savedMaleDetails = savedEntry.getProductDetails().getMaleParent();
        previousMaleDetails.overrideParentDetails(savedMaleDetails);
        ProductDetails updatedMaleDetails = getUpdatedParentFromLexicon(previousMaleDetails);
        if (previousEntry.getProductDetails().isReciprocal()) {
            previousEntry.getProductDetails().setFemaleParent(updatedMaleDetails);
        } else {
            previousEntry.getProductDetails().setMaleParent(updatedMaleDetails);
        }
    }

    private void updateFemaleDetails(PlanEntry previousEntry, PlanEntry savedEntry) throws Exception {
        ProductDetails previousFemaleDetails = previousEntry.getProductDetails().getFemaleParent();
        ProductDetails savedFemaleDetails = savedEntry.getProductDetails().getFemaleParent();
        previousFemaleDetails.overrideParentDetails(savedFemaleDetails);
        ProductDetails updatedFemaleDetails = getUpdatedParentFromLexicon(previousFemaleDetails);
        if (previousEntry.getProductDetails().isReciprocal()) {
            previousEntry.getProductDetails().setMaleParent(updatedFemaleDetails);
        } else {
            previousEntry.getProductDetails().setFemaleParent(updatedFemaleDetails);
        }
    }

    private ProductDetails getUpdatedParentFromLexicon(ProductDetails previousParentDetails) throws Exception {
        if (ProductDetails.MANUAL_OVERRIDE_FLAG.equals(previousParentDetails.getOverrideFlag())) {
            ProductCriteria criteria = new ProductCriteria(previousParentDetails.getPreCommercialName(),
                    new NameType(NameType.DEFAULT_NAME_TYPE_ID), previousParentDetails.getPreCommercialName());
            List foundProducts = productLookupService.lookupProductDetailByCriteria(criteria);
            if (foundProducts.size() > 0
                    && !ProductDetails.PRODUCTION_STATUS_UNRESOLVED
                    .equals(((ProductDetails) foundProducts.get(0)).getProductionStatus())) {
                ProductDetails updatedParentDetails = (ProductDetails) foundProducts.get(0);
                updatedParentDetails.setOverrideFlag(ProductDetails.MANUAL_OVERRIDE_FLAG);
                updatedParentDetails.setOverridden(previousParentDetails.isOverridden());
                return updatedParentDetails;
            }
        }
        return previousParentDetails;
    }

    private void sendNotificationEmail(Plan plan) {
        EmailHeaderInfo headerInfo = new EmailHeaderInfo(plan.getOwner().getEmail(), RETURN_EMAIL_ADDRESS,
                "Your Plan is Ready");
        headerInfo.setContentType("text/html");
        List adminList = loginService.lookupUsersByRole(Role.ADMIN_ROLE);
        for (int i = 0; i < adminList.size(); i++) {
            LoginUser admin = (LoginUser) adminList.get(i);
            headerInfo.addBccEmailAddress(admin.getEmail());
        }
        emailService.sendEmail("successEmail", headerInfo, plan);
    }

    /**
     * This method adds the plan entries to the specified plan object.
     *
     * @param criteria PlanCriteria object representing criteria.
     * @param plan     Plan object representing the plan.
     */
    private void addPlanEntries(PlanCriteria criteria, Plan plan) {
        List entryList = this.planDao.lookupPlanEntriesByCriteria(criteria);
        for (int i = 0; i < entryList.size(); i++) {
            PlanEntry entry = (PlanEntry) entryList.get(i);
            entry.setPlanId(plan.getId());
            entry.setPlanRevision(plan.getRevision());
            entry.setPlanOwner(plan.getOwner());
        }
        plan.addEntries(entryList);
    }

    /**
     * This method creates a plan object and adds it to the system.
     *
     * @param summary     PlanSummary object representing plan summary information.
     * @param currentUser LoginUser object representing the current user.
     * @param criteria    PlanCriteria object representing criteria.
     * @return Plan - Object representing the plan.
     */
    private Plan createPlanObject(PlanSummary summary, LoginUser currentUser, PlanCriteria criteria) {
        Revision revision = createRevision(summary, currentUser);
        Year currentYear = this.yearDao.lookupCurrentYear();
        criteria.setYear(currentYear.getYear());
        PlanType planType = planTypeDao.lookupPlanTypeById(criteria.getPlanTypeId());
        Plan plan = new Plan(summary, currentUser, revision, currentYear, planType, this.exportSpreadsheetService);
        plan.setSupplyRevision(new Revision(criteria.getSupplyRevisionId()));
        criteria.setPlanType(planType);
        updateDemandCriteria(criteria, plan, currentUser);
        return plan;
    }

    /**
     * This method updates the demand criteria with information from the plan.
     *
     * @param criteria    PlanCriteria object representing plan criteria.
     * @param plan        Plan object representing the plan.
     * @param currentUser LoginUser object representing the current user.
     */
    private void updateDemandCriteria(PlanCriteria criteria, Plan plan, LoginUser currentUser) {
        for (int i = 0; i < criteria.getDemandCriteria().size(); i++) {
            DemandCriteria demandCriteria = (DemandCriteria) criteria.getDemandCriteria().get(i);
            demandCriteria.setPlanId(plan.getId());
            demandCriteria.setOwner(currentUser);
        }
    }

    /**
     * This method creates a new revision and adds it to the system.
     *
     * @param summary     PlanSummary object representing summary information.
     * @param currentUser LoginUser object represnting the current user.
     *
     * @return Revision - Object representing the revision.
     */
    private Revision createRevision(PlanSummary summary, LoginUser currentUser) {
        return new Revision(CREATE_PLAN_OPERATION, summary.getName(), currentUser);
    }

}
