/*
 MockBatchServiceImpl was created on Dec 21, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.usseedplanning.container.test;

import com.monsanto.wst.usseedplanning.dao.BatchDao;
import com.monsanto.wst.usseedplanning.dao.PlanDao;
import com.monsanto.wst.usseedplanning.dao.ProductDetailsDao;
import com.monsanto.wst.usseedplanning.model.core.LoginUser;
import com.monsanto.wst.usseedplanning.model.cache.ProductAlias;
import com.monsanto.wst.usseedplanning.model.cache.ProductDetails;
import com.monsanto.wst.usseedplanning.services.batchupdate.BatchServiceImpl;
import com.monsanto.wst.usseedplanning.services.batchupdate.CacheUpdater;
import com.monsanto.wst.usseedplanning.services.planning.PlanService;
import com.monsanto.wst.usseedplanning.services.cache.ProductLookupService;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * Filename:    $RCSfile: MockBatchServiceImpl.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: njminsh $    	 On:	$Date: 2007-01-31 22:10:15 $
 *
 * @author vrbethi
 * @version $Revision: 1.7 $
 */
public class MockBatchServiceImpl extends BatchServiceImpl{

    public MockBatchServiceImpl(LoginUser loginUser, PlanService planService, ProductLookupService productLookupService, BatchDao batchDao, ProductDetailsDao productDetailsDao, PlanDao planDao, CacheUpdater cacheUpdaterImpl) {
        super(loginUser, productLookupService,batchDao, planDao,cacheUpdaterImpl, null, null);
    }

    public void alterListOfProductDetails(List productList) {
       Iterator iterator = productList.iterator();
        while(iterator.hasNext()){
            ProductDetails productDetails = (ProductDetails) iterator.next();
            String preCommercialName = productDetails.getPreCommercialName();
            if(preCommercialName.equalsIgnoreCase("EXP568")){
                ProductAlias productAlias = new ProductAlias("DEKALB","USA","CM",new Double(1.0),"DK679001",new Boolean(false),new Boolean(false),"CONV");
                productDetails.getProductAliasList().clear();
                ArrayList productAliasList = new ArrayList();
                productAliasList.add(productAlias);
                productDetails.addProductAliases(productAliasList);
            }
        }
    }
}