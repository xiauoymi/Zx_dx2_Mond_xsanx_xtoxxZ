package com.monsanto.wst.usseedplanning.container.test.mock;

import com.monsanto.wst.usseedplanning.container.DaoFactory;

import java.util.List;
import java.util.Arrays;
import java.util.ArrayList;

/**
 * Created by IntelliJ IDEA.
 * Date: Feb 13, 2007
 * Time: 2:31:33 PM
 * <p/>
 * TODO: Enter description for class.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class MockDaoFactory extends DaoFactory {
    public String[] getDBTemplateMappings() {
        String[] productionMappings = super.getDBTemplateMappings();
        List productionMappingsList = Arrays.asList(productionMappings);
        List mappingList = new ArrayList();
        mappingList.addAll(productionMappingsList);
        mappingList.add("database/dbtemplate-test.xml");
        return (String[]) mappingList.toArray(new String[mappingList.size()]);
    }
}
