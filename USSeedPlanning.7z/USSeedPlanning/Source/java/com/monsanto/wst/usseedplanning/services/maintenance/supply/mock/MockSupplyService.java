package com.monsanto.wst.usseedplanning.services.maintenance.supply.mock;

import com.monsanto.wst.usseedplanning.model.core.LoginUser;
import com.monsanto.wst.usseedplanning.model.maintenance.Revision;
import com.monsanto.wst.usseedplanning.services.maintenance.supply.SupplyService;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.ArrayList;

/**
 * Created by IntelliJ IDEA.
 * Date: Aug 16, 2006
 * Time: 6:10:02 PM
 * <p/>
 * Mock implementation of the SupplyService interface.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class MockSupplyService implements SupplyService {
  private boolean wasUpdated = false;
  private File file;

  public void updateSupply(File file, LoginUser owner, String supplyType, Long planType, String comments) throws IOException {
    this.file = file;
    this.wasUpdated = true;
  }

  public List lookupSupplyRevisionsByCriteria(Long planTypeId) {
    List revisionList = new ArrayList();
    revisionList.add(new Revision(new Long(100)));
    revisionList.add(new Revision(new Long(101)));
    return revisionList;
  }

  public boolean wasSupplyUpdated() {
    return this.wasUpdated;
  }

  public File getFile() {
    return file;
  }
}
