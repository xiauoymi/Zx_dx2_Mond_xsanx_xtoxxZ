package com.monsanto.wst.usseedplanning.container;

import com.monsanto.ServletFramework.UseCaseController;
import com.monsanto.wst.factory.ApplicationContainerAware;
import com.monsanto.wst.factory.GenericFactory;
import com.monsanto.wst.usseedplanning.controller.maintenance.ForecastController;
import com.monsanto.wst.usseedplanning.controller.maintenance.UsSeedMaintenanceController;
import com.monsanto.wst.usseedplanning.controller.maintenance.CommonUploadController;
import com.monsanto.wst.usseedplanning.controller.maintenance.SupplyController;
import com.monsanto.wst.usseedplanning.controller.maintenance.targetyield.TargetYieldListController;
import com.monsanto.wst.usseedplanning.controller.maintenance.targetyield.TargetYieldController;
import com.monsanto.wst.usseedplanning.controller.maintenance.seedEntity.StageFactorController;
import com.monsanto.wst.usseedplanning.controller.maintenance.seedEntity.QaThresholdFormController;
import com.monsanto.wst.usseedplanning.controller.reports.UsSeedReportsController;
import com.monsanto.wst.usseedplanning.controller.core.*;
import com.monsanto.wst.usseedplanning.controller.planning.UsSeedPlanningController;
import com.monsanto.wst.usseedplanning.controller.planning.PlanController;
import com.monsanto.wst.usseedplanning.controller.validator.PlanValidator;
import com.monsanto.wst.usseedplanning.services.maintenance.forecast.ForecastService;
import com.monsanto.wst.usseedplanning.services.maintenance.CommonUploadService;
import com.monsanto.wst.usseedplanning.services.maintenance.supply.SupplyService;
import com.monsanto.wst.usseedplanning.services.maintenance.seedEntity.*;
import com.monsanto.wst.usseedplanning.services.planning.PlanService;
import com.monsanto.wst.usseedplanning.services.core.LogReaderService;
import com.monsanto.wst.usseedplanning.view.factory.ViewFactory;
import com.monsanto.wst.usseedplanning.view.factory.ViewFactoryImpl;
import com.monsanto.wst.validator.HttpValidator;
import com.monsanto.wst.reportingframework.controller.CreateReportController;
import com.monsanto.wst.reportingframework.controller.ExportController;
import com.monsanto.wst.reportingframework.controller.GenerateReportOptions;
import com.monsanto.wst.administerreferencedata.controller.DisplayDBLookupsController;
import com.monsanto.wst.administerreferencedata.controller.PreUpdateLookupController;
import com.monsanto.wst.administerreferencedata.controller.SaveLookupController;
import org.ietf.jgss.GSSException;

import java.io.FileNotFoundException;

/**
 * Created by IntelliJ IDEA.
 * Date: Feb 11, 2007
 * Time: 6:06:27 PM
 * <p/>
 * TODO: Enter description for class.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class ControllerFactory implements ApplicationContainerAware {
    private GenericFactory container;

    /**
     * This method returns the current forecast controller and is called through the public getBean methods.
     *
     * @return UseCaseController - Object representing the forecast controller.
     */
    public UseCaseController getForecastController() {
        return new ForecastController(getViewFactory(),
                (ForecastService) container.getBean("forecastService"),
                (HttpValidator) container.getBean("commonForecastValidator"));
    }

    public UseCaseController getUsSeedMaintenanceController() {
        return new UsSeedMaintenanceController(getViewFactory());
    }

    public UseCaseController getUsSeedReportsController() {
        return new UsSeedReportsController(getViewFactory());
    }

    public UseCaseController getUsSeedContactUsController() {
        return new UsSeedContactUsController(getViewFactory());
    }

    public UseCaseController getUsSeedPlanningController() {
        return new UsSeedPlanningController(getViewFactory());
    }

    public CommonUploadController getCommonUploadController() {
        return new CommonUploadController(getViewFactory(),
                (CommonUploadService) container.getBean("commonUploadService"),
                (HttpValidator) container.getBean("commonUploadValidator"));
    }

    /**
     * This method returns the current implementation of the STage FActor Controller object
     *
     * @return - StageFactorController - object representing the Stage Factor Controller
     */
    public StageFactorController getStageFactorController() {
        return new StageFactorController((StageFactorService) container.getBean("stageFactorService"),
                (YearService) container.getBean("yearService"),
                (StageService) container.getBean("stageService"),
                getViewFactory(),
                (HttpValidator) container.getBean("stageFactorValidator"));
    }

    public UseCaseController getCancelActionController() {
        return new CancelActionController(getViewFactory());
    }

    public UseCaseController getUsSeedMainController() {
        return new UsSeedMainController(getViewFactory());
    }

    /**
     * This method returns the current implementation of the supply controller.
     *
     * @return UseCaseController - Object representing the supply controller.
     */
    public UseCaseController getSupplyController() {
        return new SupplyController((SupplyService) container.getBean("supplyService"), getViewFactory(),
                (HttpValidator) container.getBean("updateSupplyValidator"));
    }

    public UseCaseController getSaveQaThresholdController() {
        return new QaThresholdFormController((QaThresholdService) container.getBean("qaThresholdService"),
                getViewFactory(), (YearService) container.getBean("yearService"),
                (GenderService) container.getBean("genderService"),
                (QaThresholdComparisonStrategyService) container.getBean("qaThresholdComparisonStrategyService"),
                (QaThresholdTypeService) container.getBean("qaThresholdTypeService"));

    }

    /**
     * This method returns the current implementation of the js tools controller.
     *
     * @return UseCaseController - Object representing the js tools controller.
     */
    public UseCaseController getJSToolsController() {
        return new JSToolsController(getViewFactory());
    }

    public UseCaseController getCreateReportController() {
        return new CreateReportController();
    }

    public UseCaseController getExportController() {
        return new ExportController();
    }

    public UseCaseController getGenerateReportOptions() {
        return new GenerateReportOptions();
    }

    public UseCaseController getDisplayLookupController() {
        return new DisplayDBLookupsController();
    }

    public UseCaseController getPreUpdateLookupController() {
        return new PreUpdateLookupController();
    }

    public UseCaseController getSaveLookupController() {
        return new SaveLookupController();
    }

    public UseCaseController getTargetYieldListController() {
        return new TargetYieldListController(getViewFactory(),
                (YearService) container.getBean("yearService"),
                (YieldTargetService) container.getBean("yieldTargetService"),
                (GenderService) container.getBean("genderService"));
    }

    public UseCaseController getTargetYieldController() {
        return new TargetYieldController((YearService) container.getBean("yearService"),
                (YieldTargetService) container.getBean("yieldTargetService"),
                (GenderService) container.getBean("genderService"));
    }

    /**
     * This method returns the plan controller.
     *
     * @return UseCaseController - Object representing the plan controller.
     *
     * @exception org.ietf.jgss.GSSException          - If unable to create POS connection.
     * @exception java.io.FileNotFoundException - If unable to find plan template.
     */
    public UseCaseController getPlanController() throws GSSException, FileNotFoundException {
        return new PlanController(getViewFactory(),
                (PlanService) container.getBean("planService"),
                (YearService) container.getBean("yearService"),
                (PlanValidator) container.getBean("planValidator"),
                (ForecastService) container.getBean("forecastService"),
                (SupplyService) container.getBean("supplyService"));
    }

    public UseCaseController getAdminController() {
        return new AdminController(getViewFactory(), (LogReaderService) container.getBean("logReaderService"));
    }

    public void setApplicationContainer(GenericFactory container) {
        this.container = container;
        initializeServletMappings();
    }

    private ViewFactory getViewFactory() {
        return new ViewFactoryImpl();
    }

    private void initializeServletMappings() {
        container.addBeanAlias("/servlet/forecast.htm", "forecastController");
        container.addBeanAlias("/servlet/saveEntity.htm", "saveEntityController");
        container.addBeanAlias("/servlet/listEntities.htm", "buildEntityController");
        container.addBeanAlias("/servlet/buildBaseEntity.htm", "buildBaseEntityController");
        container.addBeanAlias("/servlet/preDisplayEntity.htm", "preDisplayEntityController");
        container.addBeanAlias("/servlet/cancelAction.htm", "cancelActionController");
        container.addBeanAlias("/servlet/login.htm", "usSeedMainController");
        container.addBeanAlias("/servlet/maintenance.htm", "usSeedMaintenanceController");
        container.addBeanAlias("/servlet/reports.htm", "usSeedReportsController");
        container.addBeanAlias("/servlet/contact_us.htm", "usSeedContactUsController");
        container.addBeanAlias("/servlet/planning.htm", "usSeedPlanningController");
        container.addBeanAlias("/", "usSeedMainController");
        container.addBeanAlias("/servlet/supply.htm", "supplyController");
        container.addBeanAlias("/servlet/supplyZDCA.htm", "supplyController");
        container.addBeanAlias("/servlet/JSConstants.js", "JSToolsController");
        container.addBeanAlias("/servlet/create_report.htm", "createReportController");
        container.addBeanAlias("/servlet/generate_report.htm", "generateReportOptions");
        container.addBeanAlias("/servlet/export_report.htm", "exportController");
        container.addBeanAlias("/servlet/display_lookup.htm", "displayLookupController");
        container.addBeanAlias("/servlet/update_lookup.htm", "preUpdateLookupController");
        container.addBeanAlias("/servlet/save_lookup.htm", "saveLookupController");
        //container.addBeanAlias("/servlet/excel_report.htm", "excelReportController");
        container.addBeanAlias("/servlet/generatePlan.htm", "planController");

        container.addBeanAlias("/servlet/qaThresholdForm.htm", "saveQaThresholdController");
        container.addBeanAlias("/servlet/searchStageFactors.htm", "stageFactorController");
        container.addBeanAlias("/servlet/targetYieldList.htm", "targetYieldListController");
        container.addBeanAlias("/servlet/targetYield.htm", "targetYieldController");
        container.addBeanAlias("/servlet/admin.htm", "adminController");
        container.addBeanAlias("/servlet/commonUpload.htm", "commonUploadController");
        container.addBeanAlias("/servlet/commitPlan.htm", "commitPlanController");
        container.addBeanAlias("/servlet/savePlan.htm", "savePlanController");
    }
}
