/*
 Copyright:  Copyright � 2006 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.usseedplanning.services.maintenance.seedEntity.dbServices;

import com.monsanto.wst.usseedplanning.dao.YearDao;
import com.monsanto.wst.usseedplanning.exception.NoResultsException;
import com.monsanto.wst.usseedplanning.model.maintenance.Year;
import com.monsanto.wst.usseedplanning.services.maintenance.seedEntity.YearService;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import java.util.List;

/**
 * Filename:    $RCSfile: YearServiceDbImpl.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ffbrac $    	 On:	$Date: 2006-10-03 13:55:16 $
 *
 * @author jdpoul
 * @version $Revision: 1.4 $
 */
public class YearServiceDbImpl implements YearService {

  private static final Log log = LogFactory.getLog(YearServiceDbImpl.class);

  private YearDao dao;

  public YearServiceDbImpl(YearDao dao){
    if(dao == null){
      throw new  IllegalArgumentException("The YearServiceImpl constructor should throw an IllegalArgumentException when passed a null Dao.");
    }
    this.dao = dao;
  }

  public List getActiveYears() {
    return dao.getActiveYears();
  }

  public Year lookupYearById(Long yearId) {
    Year year = null;
    try {
      year =  this.dao.lookupYearById(yearId);
    } catch (NoResultsException e) {
        if (log.isWarnEnabled()) {
            log.warn("Unable to find a year with year id '" + yearId );
        }
    }
    return year;
  }

	public Year lookupCurrentYear() {
		return dao.lookupCurrentYear();
	}
}