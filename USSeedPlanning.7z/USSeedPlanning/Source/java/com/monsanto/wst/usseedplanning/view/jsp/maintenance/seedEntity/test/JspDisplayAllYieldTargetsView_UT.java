package com.monsanto.wst.usseedplanning.view.jsp.maintenance.seedEntity.test;

import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.wst.usseedplanning.constants.MainConstants;
import com.monsanto.wst.usseedplanning.view.jsp.maintenance.seedEntity.JspDisplayAllYieldTargetsView;
import com.monsanto.wst.view.ViewRenderingException;
import com.monsanto.wst.view.test.mock.MockUCCHelperThrowsIOException;
import junit.framework.TestCase;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Aug 9, 2006
 * Time: 8:57:50 AM
 * To change this template use File | Settings | File Templates.
 */
public class JspDisplayAllYieldTargetsView_UT extends TestCase {

    MockUCCHelper helper = null;

    protected void setUp() throws Exception {
        helper = new MockUCCHelper(null);
    }

    public void testCreate() throws Exception {
        JspDisplayAllYieldTargetsView view = new JspDisplayAllYieldTargetsView();
        assertNotNull(view);
    }

    public void testRenderView() throws Exception {
        JspDisplayAllYieldTargetsView view = new JspDisplayAllYieldTargetsView();
        view.renderView(helper);
        assertTrue(helper.wasSentTo(MainConstants.DISPLAY_TARGET_YIELD_JSP));
    }

    public void testRenderViewThrowsException() throws Exception {
        MockUCCHelperThrowsIOException helperThrowsIOException = new MockUCCHelperThrowsIOException(null);
        JspDisplayAllYieldTargetsView view = new JspDisplayAllYieldTargetsView();
        try {
            view.renderView(helperThrowsIOException);
            fail("This should have thrown Exception");
        } catch (ViewRenderingException e) {
            assertEquals("Unable to Render View", e.getMessage());
        }
    }
}
