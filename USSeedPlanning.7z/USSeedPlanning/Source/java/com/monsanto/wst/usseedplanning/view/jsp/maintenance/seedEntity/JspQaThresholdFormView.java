package com.monsanto.wst.usseedplanning.view.jsp.maintenance.seedEntity;

import com.monsanto.AbstractLogging.LoggableError;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.wst.usseedplanning.constants.MainConstants;
import com.monsanto.wst.view.View;
import com.monsanto.wst.view.ViewRenderingException;

import java.io.IOException;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Aug 16, 2006
 * Time: 1:31:38 PM
 * To change this template use File | Settings | File Templates.
 */
public class JspQaThresholdFormView implements View {
    public void renderView(UCCHelper helper) throws ViewRenderingException {
        try {
            helper.forward(MainConstants.CREATE_QA_THRESHOLD_JSP);
        } catch (IOException e) {
            logError(e);
            throw new ViewRenderingException("Unable to render view for QA Threshold form page.");
        }
    }

    private void logError(IOException e) {
        if (Logger.isEnabled(Logger.ERROR_LOG)) {
            Logger.log(new LoggableError(e));
        }
    }
}
