/*
 CommonUploadController was created on Oct 10, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.usseedplanning.controller.maintenance;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.wst.servletframework.AbstractDispatchController;
import com.monsanto.wst.usseedplanning.constants.MainConstants;
import com.monsanto.wst.usseedplanning.model.core.LoginUser;
import com.monsanto.wst.usseedplanning.model.planning.DemandCriteria;
import com.monsanto.wst.usseedplanning.model.planning.PlanCriteria;
import com.monsanto.wst.usseedplanning.services.maintenance.CommonUploadService;
import com.monsanto.wst.usseedplanning.utils.CommonUploadConstants;
import com.monsanto.wst.usseedplanning.utils.transaction.TransactionUtils;
import com.monsanto.wst.usseedplanning.view.factory.ViewFactory;
import com.monsanto.wst.validator.HttpRequestErrors;
import com.monsanto.wst.validator.HttpRequestMessages;
import com.monsanto.wst.validator.HttpValidator;
import com.monsanto.wst.view.View;

import java.io.File;
import java.io.IOException;

/**
 * Created by IntelliJ IDEA.
 * Date: Sep 22, 2006
 * Time: 8:51:14 PM
 * <p/>
 * This class is the controller for common uploads.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class CommonUploadController extends AbstractDispatchController {
  private ViewFactory viewFactory;
  private HttpValidator validator;
  private CommonUploadService commonUploadService;

  public CommonUploadController(ViewFactory viewFactory, CommonUploadService commonUploadService,
                                HttpValidator validator) {
    this.viewFactory = viewFactory;
    this.commonUploadService = commonUploadService;
    this.validator = validator;
  }

  protected void notSpecified(UCCHelper helper) throws IOException {
    View view;
    CommonUploadConstants commonUploadConstants=new CommonUploadConstants();
    helper.setRequestAttributeValue("commonUploadMap", commonUploadConstants.getcommonUploadConstants());
    view = this.viewFactory.getCommonUploadView();
    view.renderView(helper);
  }

  public void addCommonUpload(UCCHelper helper) throws Exception {
    HttpRequestErrors errors = this.validator.validate(helper);
    View view;
    if(errors.isEmpty()){
      File spreadsheet = new File((String) helper.getClientFiles().get(0));
      String comments = helper.getRequestParameterValue("comments");
      String columnName = helper.getRequestParameterValue("columnName");
      LoginUser currentUser = (LoginUser) helper.getSessionParameter(MainConstants.LOGINUSER);
      try {
        this.commonUploadService.addCommonUpload(spreadsheet, columnName, currentUser, comments);
        HttpRequestMessages messages = new HttpRequestMessages();
        messages.addMessage("Common Upload Successfully Added.");
        helper.setRequestAttributeValue("messages", messages);
        view = this.viewFactory.getMaintenanceView();
        view.renderView(helper);
      } catch (IOException e) {
        helper.setRequestAttributeValue("errors", errors);
        notSpecified(helper);
        new TransactionUtils(helper).flagForRollback();
      }
    }
    else{
      helper.setRequestAttributeValue("errors", errors);
      notSpecified(helper);
    }
  }

//  private void initHash(){
//    MainConstants.COMMON_UPLOAD_TYPES_MAP.clear();
//    MainConstants.COMMON_UPLOAD_TYPES_MAP.put("base_name", "Base Name");
//    MainConstants.COMMON_UPLOAD_TYPES_MAP.put("hcl_base", "HCL Base");
//    MainConstants.COMMON_UPLOAD_TYPES_MAP.put("oecd_name", "OECD Name / Country Synonym");
//
//    MainConstants.COMMON_UPLOAD_TYPES_MAP.put("pre_fiscal", "Pre-Fiscal Pitch");
//    MainConstants.COMMON_UPLOAD_TYPES_MAP.put("qa_loss", "QA % Loss");
//    MainConstants.COMMON_UPLOAD_TYPES_MAP.put("planned_marketing", "Planned Marketing Obsolescence");
//
//    MainConstants.COMMON_UPLOAD_TYPES_MAP.put("approved_quality", "Approved Actual Quality Discard");
//    MainConstants.COMMON_UPLOAD_TYPES_MAP.put("approved_mktg", "Approved Actual Mktg Discard");
//    MainConstants.COMMON_UPLOAD_TYPES_MAP.put("misc_monthly", "Act. Misc. Monthly");
//    MainConstants.COMMON_UPLOAD_TYPES_MAP.put("misc_offs", "Actual Misc. Write Offs");
//
//    MainConstants.COMMON_UPLOAD_TYPES_MAP.put("other_demand", "Other Demand");
//    MainConstants.COMMON_UPLOAD_TYPES_MAP.put("eb_carryover", "EB from Carryover");
//
//    MainConstants.COMMON_UPLOAD_TYPES_MAP.put("summer_prod", "Summer Production");
//    MainConstants.COMMON_UPLOAD_TYPES_MAP.put("winter_prod", "Winter Production");
//
//    MainConstants.COMMON_UPLOAD_TYPES_MAP.put("msis", "MSIS");
//
//    MainConstants.COMMON_UPLOAD_TYPES_MAP.put("yield_target", "Yield Yield");
//
///*
//		// To be added
//	    MainConstants.COMMON_UPLOAD_TYPES_MAP.put("qa_loss", "QA % Loss");
//	    MainConstants.COMMON_UPLOAD_TYPES_MAP.put("qa_loss", "QA % Loss");
//*/
//  }

  private void addDemandCriteria(UCCHelper helper, PlanCriteria planCriteria) throws IOException {
    String[] channelRevPairs = helper.getRequestParameterValues("channelRev");
    DemandCriteria demandCriteria;
    for (int i = 0; i < channelRevPairs.length; i++) {
      String[] pair = channelRevPairs[i].split("-");
      demandCriteria = new DemandCriteria(new Long(pair[1]), new Long(pair[0]));
      planCriteria.addDemandCriteria(demandCriteria);
    }
  }
}