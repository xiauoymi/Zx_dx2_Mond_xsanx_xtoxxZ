/*
 Copyright:  Copyright � 2006 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.usseedplanning.services.maintenance.seedEntity.dbServices.test;

import com.monsanto.wst.usseedplanning.model.maintenance.Default;
import com.monsanto.wst.usseedplanning.services.maintenance.seedEntity.dbServices.IsDefaultAcceptTest;
import junit.framework.TestCase;

/**
 * Filename:    $RCSfile: IsDefaultAcceptTest_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: jdpoul $
 * On:	$Date: 2006-10-11 21:24:32 $
 *
 * @author jdpoul
 * @version $Revision: 1.2 $
 */
public class IsDefaultAcceptTest_UT extends TestCase {
  private IsDefaultAcceptTest test;

  public IsDefaultAcceptTest_UT(String name) {
    super(name);
  }

  protected void setUp() throws Exception {
    super.setUp();
    this.test = new IsDefaultAcceptTest();
  }

  public void testCreate() throws Exception {
    IsDefaultAcceptTest test = new IsDefaultAcceptTest();
    assertNotNull(test);
  }

  public void testAcceptNullParam() throws Exception {
    assertFalse(test.accept(null));
  }


  public void testAcceptGenericObject() throws Exception {
    assertFalse(test.accept(new Object()));
  }

  public void testAcceptDefaultInstanceTrue() throws Exception {
    assertFalse(test.accept(new TestDefaultTrue()));
  }


  public void testAcceptDefaultInstanceFalse() throws Exception {
    assertTrue(test.accept(new TestDefaultFalse()));
  }

  public class TestDefaultFalse implements Default {
    public boolean isDefault() {
      return false;
    }
  }


  public class TestDefaultTrue implements Default {
    public boolean isDefault() {
      return true;
    }
  }
}