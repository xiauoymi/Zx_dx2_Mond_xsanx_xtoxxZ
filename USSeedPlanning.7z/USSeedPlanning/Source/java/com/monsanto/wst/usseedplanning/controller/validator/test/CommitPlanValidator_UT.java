/*
 CommitPlanValidator_UT was created on Oct 31, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.usseedplanning.controller.validator.test;

import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.wst.usseedplanning.controller.validator.CommitPlanValidator;
import com.monsanto.wst.validator.HttpRequestErrors;
import junit.framework.TestCase;

/**
 * Created by IntelliJ IDEA.
 * Date: Aug 15, 2006
 * Time: 9:59:01 AM
 * <p/>
 * Unit test for the CommonForecastValidator object.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class CommitPlanValidator_UT extends TestCase {
    public void testCreate() throws Exception {
        CommitPlanValidator validator = new CommitPlanValidator();
        assertNotNull(validator);
    }

    public void testValidatePass() throws Exception {
        CommitPlanValidator validator = new CommitPlanValidator();
        MockUCCHelper helper = createRequest();
        HttpRequestErrors errors = validator.validate(helper);
        assertTrue(errors.isEmpty());
    }

    public void testValidateFail() throws Exception {
        CommitPlanValidator validator = new CommitPlanValidator();
        MockUCCHelper helper = new MockUCCHelper(null);
        HttpRequestErrors errors = validator.validate(helper);
        assertFalse(errors.isEmpty());
        assertEquals("The Comment field is required.", errors.getError("comment"));
        assertEquals("There are no plans currently available.", errors.getError("planId"));
    }

    private MockUCCHelper createRequest() {
        MockUCCHelper helper = new MockUCCHelper(null);
        helper.setRequestParameterValue("comments", "Test Message");
        helper.setRequestParameterValue("planId", "1");
        helper.addClientFile("");
        return helper;
    }
}