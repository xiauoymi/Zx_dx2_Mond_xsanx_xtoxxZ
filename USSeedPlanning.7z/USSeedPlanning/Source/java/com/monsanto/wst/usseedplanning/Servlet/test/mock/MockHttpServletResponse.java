package com.monsanto.wst.usseedplanning.Servlet.test.mock;

import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Cookie;
import javax.servlet.ServletOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Locale;

/**
 * Created by IntelliJ IDEA.
 * Date: Feb 16, 2007
 * Time: 11:03:17 AM
 * <p/>
 * TODO: Enter description for class.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class MockHttpServletResponse implements HttpServletResponse {
    public void addCookie(Cookie cookie) {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    public boolean containsHeader(String statementName) {
        return false;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public String encodeURL(String statementName) {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public String encodeRedirectURL(String statementName) {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public String encodeUrl(String statementName) {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public String encodeRedirectUrl(String statementName) {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public void sendError(int i, String statementName) throws IOException {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    public void sendError(int i) throws IOException {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    public void sendRedirect(String statementName) throws IOException {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    public void setDateHeader(String statementName, long l) {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    public void addDateHeader(String statementName, long l) {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    public void setHeader(String statementName, String statementName1) {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    public void addHeader(String statementName, String statementName1) {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    public void setIntHeader(String statementName, int i) {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    public void addIntHeader(String statementName, int i) {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    public void setStatus(int i) {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    public void setStatus(int i, String statementName) {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    public String getCharacterEncoding() {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public String getContentType() {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public ServletOutputStream getOutputStream() throws IOException {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public PrintWriter getWriter() throws IOException {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public void setCharacterEncoding(String statementName) {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    public void setContentLength(int i) {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    public void setContentType(String statementName) {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    public void setBufferSize(int i) {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    public int getBufferSize() {
        return 0;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public void flushBuffer() throws IOException {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    public void resetBuffer() {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    public boolean isCommitted() {
        return false;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public void reset() {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    public void setLocale(Locale locale) {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    public Locale getLocale() {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }
}
