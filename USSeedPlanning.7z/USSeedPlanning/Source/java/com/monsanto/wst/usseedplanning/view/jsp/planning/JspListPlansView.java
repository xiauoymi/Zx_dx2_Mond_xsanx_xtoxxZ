package com.monsanto.wst.usseedplanning.view.jsp.planning;

import com.monsanto.wst.view.View;
import com.monsanto.wst.view.ViewRenderingException;
import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.AbstractLogging.LoggableError;

import java.io.IOException;

/**
 * Created by IntelliJ IDEA.
 * Date: Nov 5, 2006
 * Time: 6:39:32 PM
 * <p/>
 * This class represents the jsp implementation of the list plans view.  It's purpose is to display the current plans
 * in the system.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class JspListPlansView implements View {
  /**
   * This method renders the jsp view of the list plans page.
   *
   * @param helper UCCHelper object containing the request and response.
   * @throws ViewRenderingException - If unable tor render the view.
   */
  public void renderView(UCCHelper helper) throws ViewRenderingException {
    try {
      helper.forward("/WEB-INF/jsp/planning/listPlans.jspx");
    } catch (IOException e) {
      if (Logger.isEnabled(Logger.ERROR_LOG)) {
          Logger.log(new LoggableError(e));
      }
      throw new ViewRenderingException("Unable to Render View");
    }
  }
}
