package com.monsanto.wst.usseedplanning.controller.maintenance;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.wst.servletframework.AbstractDispatchController;
import com.monsanto.wst.usseedplanning.constants.MainConstants;
import com.monsanto.wst.usseedplanning.constants.ControllerConstants;
import com.monsanto.wst.usseedplanning.exception.ServiceUnavailableException;
import com.monsanto.wst.usseedplanning.model.core.LoginUser;
import com.monsanto.wst.usseedplanning.services.maintenance.forecast.ForecastService;
import com.monsanto.wst.usseedplanning.services.maintenance.forecast.InvalidForecastException;
import com.monsanto.wst.usseedplanning.utils.transaction.TransactionUtils;
import com.monsanto.wst.usseedplanning.view.factory.ViewFactory;
import com.monsanto.wst.validator.HttpRequestErrors;
import com.monsanto.wst.validator.HttpRequestMessages;
import com.monsanto.wst.validator.HttpValidator;
import com.monsanto.wst.view.View;

import java.io.File;
import java.io.IOException;

/**
 * Created by IntelliJ IDEA.
 * Date: Aug 7, 2006
 * Time: 2:06:14 PM
 * <p/>
 * This class is a consolidated controller for the forecast pages.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class ForecastController extends AbstractDispatchController {
    private ViewFactory viewFactory;
    private ForecastService forecastService;
    private HttpValidator validator;

    /**
     * This constructor takes all dependencies.
     *
     * @param viewFactory ViewFactory object representing access to view objects.
     * @param forecastService
     * @param validator
     */
    public ForecastController(ViewFactory viewFactory, ForecastService forecastService, HttpValidator validator) {
        this.viewFactory = viewFactory;
        this.forecastService = forecastService;
        this.validator = validator;
    }

    /**
     * This method is the default action for requests to the forecast controller.  It renders the import common
     * forecast view.
     *
     * @param helper UCCHelper object containing the request and response.
     * @throws IOException - If unable to access the request or response.
     */
    protected void notSpecified(UCCHelper helper) throws IOException {
        View view = this.viewFactory.getImportCommonForecastView();
        view.renderView(helper);
    }

    /**
     * This method renders the Domand forecast view for uploading.
     *
     * @param helper UCCHelper object containing the request and response.
     * @throws IOException - If unable to access the request or response.
     */
    public void uploadDemand(UCCHelper helper) throws IOException {
        View view = this.viewFactory.getImportDemandForecastView();
        view.renderView(helper);
    }

    /**
     * This method adds a demand forecast spreadsheet to the system.
     *
     * @param helper UCCHelper object containing the request and response.
     * @throws IOException - If unable to access the request or response.
     */
    public void addCommonForecasts(UCCHelper helper) throws IOException, ServiceUnavailableException {
        HttpRequestErrors errors = this.validator.validate(helper);
        View view = null;
        if (errors.isEmpty()) {
            File spreadsheet = new File((String) helper.getClientFiles().get(0));
            String comments = helper.getRequestParameterValue("comments");
            String planType = helper.getRequestParameterValue("planType");
            LoginUser currentUser = (LoginUser) helper.getSessionParameter(MainConstants.LOGINUSER);
            try {
                this.forecastService.addCommonForecasts(spreadsheet, new Long(planType), currentUser, comments);
                HttpRequestMessages messages = new HttpRequestMessages();
                messages.addMessage("Common Forecast Successfully Uploaded.");
                helper.setRequestAttributeValue(ControllerConstants.MESSAGES_REQUEST_ATTRIBUTE, messages);
                view = this.viewFactory.getUSSeedHomeView();
            } catch (InvalidForecastException e) {
                errors.addError(HttpRequestErrors.GLOBAL_ERROR, e.getMessage());
                helper.setRequestAttributeValue(ControllerConstants.ERRORS_REQUEST_ATTRIBUTE, errors);
                view = this.viewFactory.getImportCommonForecastView();
                new TransactionUtils(helper).flagForRollback();
            }
        } else {
            helper.setRequestAttributeValue(ControllerConstants.ERRORS_REQUEST_ATTRIBUTE, errors);
            view = this.viewFactory.getImportCommonForecastView();
        }
        view.renderView(helper);
    }

    /**
     * This method adds a demand forecast spreadsheet to the system.
     *
     * @param helper UCCHelper object containing the request and response.
     * @throws IOException - If unable to access the request or response.
     */
    public void addDemandForecasts(UCCHelper helper) throws IOException, ServiceUnavailableException {
        HttpRequestErrors errors = this.validator.validate(helper);
        View view = null;
        if (errors.isEmpty()) {
            File spreadsheet = new File((String) helper.getClientFiles().get(0));
            String comments = helper.getRequestParameterValue("comments");
            LoginUser currentUser = (LoginUser) helper.getSessionParameter(MainConstants.LOGINUSER);
            try {
                this.forecastService.addDemandForecasts(spreadsheet, currentUser, comments);
                HttpRequestMessages messages = new HttpRequestMessages();
                messages.addMessage("Demand Forecast Successfully Uploaded.");
                helper.setRequestAttributeValue(ControllerConstants.MESSAGES_REQUEST_ATTRIBUTE, messages);
                view = this.viewFactory.getUSSeedHomeView();
            } catch (InvalidForecastException e) {
                errors.addError(HttpRequestErrors.GLOBAL_ERROR, e.getMessage());
                helper.setRequestAttributeValue(ControllerConstants.ERRORS_REQUEST_ATTRIBUTE, errors);
                view = this.viewFactory.getImportDemandForecastView();
                new TransactionUtils(helper).flagForRollback();
            }
        } else {
            helper.setRequestAttributeValue(ControllerConstants.ERRORS_REQUEST_ATTRIBUTE, errors);
            view = this.viewFactory.getImportDemandForecastView();
        }
        view.renderView(helper);
    }
}
