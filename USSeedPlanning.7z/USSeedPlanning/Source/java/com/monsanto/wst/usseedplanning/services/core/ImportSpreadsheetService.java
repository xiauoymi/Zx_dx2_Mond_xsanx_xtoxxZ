package com.monsanto.wst.usseedplanning.services.core;

import java.io.File;
import java.io.IOException;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * Date: Aug 8, 2006
 * Time: 1:15:03 PM
 * <p/>
 * This interface defines the contract for importing spreadsheets.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public interface ImportSpreadsheetService {
    /**
     * This method retrieves a list of common forecasts based on the specified file.
     *
     * @param spreadsheet File object representing the file with the data.
     * @return List - Of configured objects representing the data.
     * @throws java.io.IOException - If unable to read the file.
     */
    List getCommonForecasts(File spreadsheet) throws IOException;

  /**
     * This method retrieves a list of demand forecasts based on the specified file.
     *
     * @param spreadsheet File object representing the file with the data.
     * @return List - Of configured objects representing the data.
     * @throws java.io.IOException - If unable to read the file.
     */
    List getDemandForecasts(File spreadsheet) throws IOException;

    /**
     * This method retrieves a list of current supply objects.
     *
     * @return List - Representing the supply objects.
     * @throws java.io.IOException - If unable to read the supply file.
     * @param file File representing the ATP supply data file.
     */
    List getATPSupply(File file) throws IOException;

    /**
     * This method retrieves a list of current supply objects.
     *
     * @return List - Representing the supply objects.
     * @throws java.io.IOException - If unable to read the supply file.
     * @param file File representing the ZDCA supply data file.
     */
    List getZDCASupply(File file) throws IOException;

    List getCommonUpload(String columnName, File file) throws IOException;

	List getSavePlanSpreadSheet(File file) throws IOException;

	List getImportHybridToDemand(File file) throws IOException;
}
