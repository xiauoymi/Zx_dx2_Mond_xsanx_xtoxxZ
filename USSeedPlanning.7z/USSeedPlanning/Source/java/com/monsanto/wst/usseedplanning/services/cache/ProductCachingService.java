package com.monsanto.wst.usseedplanning.services.cache;

import com.monsanto.wst.usseedplanning.model.cache.ProductDetails;
import com.monsanto.wst.usseedplanning.model.core.LoginUser;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * Date: Feb 23, 2007
 * Time: 1:14:03 PM
 * <p/>
 * TODO: Enter description for class.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public interface ProductCachingService {

    List cacheSelectedProducts(List productCriteria, LoginUser currentUser) throws Exception;

    /**
     * This method caches the new product details records to the system.
     *
     * @param currentUser               LoginUser Object representing the current user.
     * @param productDetailsToCacheList List representing the new product detail records.
     */
    void cacheProductDetailsList(LoginUser currentUser, List productDetailsToCacheList);

    void addNewCacheEntry(String comments, LoginUser currentUser, ProductDetails productDetails);
}
