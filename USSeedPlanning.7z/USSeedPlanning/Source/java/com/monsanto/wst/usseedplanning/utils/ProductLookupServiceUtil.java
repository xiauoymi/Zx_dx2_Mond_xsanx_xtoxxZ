/*
 ProductLookupServiceUtil was created on Oct 1, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.usseedplanning.utils;

import com.monsanto.wst.usseedplanning.services.planning.ProductTypeComparator;

import java.util.Collections;
import java.util.List;
import java.util.Comparator;

/**
 * Filename:    $RCSfile: ProductLookupServiceUtil.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: vrbethi $    	 On:	$Date: 2006-10-02 03:47:59 $
 *
 * @author VRBETHI
 * @version $Revision: 1.1 $
 */
public class ProductLookupServiceUtil {

  public List sortProductCriteriaList(List productCriteriaList) {
    Comparator productTypeComparator = new ProductTypeComparator();
    Collections.sort(productCriteriaList, productTypeComparator);
    return productCriteriaList;
  }
}