/*
 LexiconServiceResponseStAXParserImpl was created on Sep 26, 2006 using Monsanto
 resources and is the sole property of Monsanto.  Any duplication of the
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.usseedplanning.services.cache.lexiconclientservices;

import com.monsanto.Util.StringUtils;
import com.monsanto.wst.usseedplanning.model.planning.ParentDetails;
import com.monsanto.wst.usseedplanning.model.cache.ProductAlias;
import com.monsanto.wst.usseedplanning.model.cache.ProductDetails;

import javax.xml.stream.XMLStreamConstants;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

/**
 * Filename:    $RCSfile: LexiconServiceResponseStAXParserImpl.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: njminsh $    	 On:	$Date: 2007-03-07 22:54:46 $
 *
 * TODO: Add error handling.
 *
 * @author VRBETHI
 * @version $Revision: 1.2 $
 */
public class LexiconServiceResponseStAXParserImpl implements ProductServiceResponseParser {
  private StAXParserUtil parserUtil = new StAXParserUtil();

  public List getProductDetailsListFromProductParentsByPrecommercialNameServiceResponse(InputStream responseInputStream) throws Exception{
    return parsePreCommercialName(responseInputStream);
  }

  public List getProductDetailsListFromProductParentsByManufacturingNameServiceResponse(InputStream responseInputStream) throws Exception {
    return parseManufacturingName(responseInputStream);
  }

  public String getPreCommercialNameFromGetAggregateProductServiceResponse(InputStream responseInputStream) throws Exception {
    return parseCommercialName(responseInputStream);
  }

  private String parseCommercialName(InputStream responseInputStream) throws XMLStreamException {
    XMLStreamReader xmlFileCursor = StAXParserUtil.instantiateStAXParser(responseInputStream);
    int event;
    String preCommercialName = null;
    while ((event = xmlFileCursor.next()) != XMLStreamConstants.END_DOCUMENT) {
      if (event == XMLStreamConstants.START_ELEMENT) {
        preCommercialName = parseAggregateProductServiceResponse(xmlFileCursor);
      }
    }
    xmlFileCursor.close();
    return preCommercialName;
  }

  private List parsePreCommercialName(InputStream responseInputStream) throws XMLStreamException {
    XMLStreamReader xmlFileCursor = StAXParserUtil.instantiateStAXParser(responseInputStream);
    int event;
    List productDetailsList = new ArrayList();
    while ((event = xmlFileCursor.next()) != XMLStreamConstants.END_DOCUMENT) {
      if (event == XMLStreamConstants.START_ELEMENT) {
        ProductDetails productDetails = parseProductsDetail(xmlFileCursor);
        if (productDetails != null) {
          productDetailsList.add(productDetails);
        }
      }
    }
    xmlFileCursor.close();
    return productDetailsList;
  }

  private List parseManufacturingName(InputStream responseInputStream) throws XMLStreamException {
    XMLStreamReader xmlFileCursor = StAXParserUtil.instantiateStAXParser(responseInputStream);
    int event;
    List productDetailsList = new ArrayList();
    while ((event = xmlFileCursor.next()) != XMLStreamConstants.END_DOCUMENT) {
      if (event == XMLStreamConstants.START_ELEMENT) {
        productDetailsList.addAll(parseProductRelationship(xmlFileCursor));
      }
    }
    xmlFileCursor.close();
    return productDetailsList;
  }

  private List parseProductRelationship(XMLStreamReader xmlFileCursor) throws XMLStreamException {
    List productDetailsList = new ArrayList();
    if(xmlFileCursor.getLocalName().equalsIgnoreCase(LexiconServiceConstants.XML_ELEMENT_PRODUCT_RELATIONSHIP)){
      parserUtil.skipChildElement(LexiconServiceConstants.XML_ELEMENT_MANUFACTUING_NAME, xmlFileCursor);
      while (parserUtil.getNextElement(LexiconServiceConstants.XML_ELEMENT_PRODUCTS, xmlFileCursor)) {
        productDetailsList.add(parseProductsDetail(xmlFileCursor));
      }
      parserUtil.endCurrentComplexElement(LexiconServiceConstants.XML_ELEMENT_PRODUCT_RELATIONSHIP, xmlFileCursor);
    }
    return productDetailsList;
  }

  private ProductDetails parseProductsDetail(XMLStreamReader xmlFileCursor) throws XMLStreamException {
    if(xmlFileCursor.getLocalName().equalsIgnoreCase(LexiconServiceConstants.XML_ELEMENT_PRODUCTS)){
      ProductDetails productDetails = new ProductDetails();
      if (parserUtil.getNextChildElement(LexiconServiceConstants.XML_ELEMENT_PRODUCT, xmlFileCursor)) {
        parseProductDetail(productDetails, false, xmlFileCursor);
      }
      parserUtil.endCurrentComplexElement(LexiconServiceConstants.XML_ELEMENT_PRODUCTS, xmlFileCursor);
      return productDetails;
    }
    return null;
  }

  private String parseAggregateProductServiceResponse(XMLStreamReader xmlFileCursor) throws XMLStreamException {
    String preCommercialName = null;
    if(xmlFileCursor.getLocalName().equalsIgnoreCase(LexiconServiceConstants.XML_ELEMENT_PRODUCTS)) {
      if (parserUtil.getNextChildElement(LexiconServiceConstants.XML_ELEMENT_PRODUCT, xmlFileCursor)) {
        parserUtil.skipChildElement(LexiconServiceConstants.XML_ELEMENT_NAME_PUB_KEY, xmlFileCursor);
        parserUtil.skipElement(LexiconServiceConstants.XML_ELEMENT_PRODUCT_NAME, xmlFileCursor);
        parserUtil.skipElement(LexiconServiceConstants.XML_ELEMENT_PRODUCT_PUB_KEY, xmlFileCursor);
        parserUtil.skipElement(LexiconServiceConstants.XML_ELEMENT_CROP_PUB_KEY, xmlFileCursor);
        parserUtil.skipElement(LexiconServiceConstants.XML_ELEMENT_CROP_NAME, xmlFileCursor);
        parserUtil.skipElement(LexiconServiceConstants.XML_ELEMENT_BRAND_PUB_KEY, xmlFileCursor);
        parserUtil.skipElement(LexiconServiceConstants.XML_ELEMENT_BRAND_NAME, xmlFileCursor);
        parserUtil.skipElement(LexiconServiceConstants.XML_ELEMENT_COUNTRY_PUB_KEY, xmlFileCursor);
        parserUtil.skipElement(LexiconServiceConstants.XML_ELEMENT_COUNTRY_NAME, xmlFileCursor);
        if(parserUtil.getNextElement(LexiconServiceConstants.XML_ELEMENT_PRE_COML_NAME, xmlFileCursor)) {
          preCommercialName = parserUtil.getSimpleElementText(LexiconServiceConstants.XML_ELEMENT_PRE_COML_NAME, xmlFileCursor);
        }
        parserUtil.endCurrentComplexElement(LexiconServiceConstants.XML_ELEMENT_PRODUCT, xmlFileCursor);
      }
      parserUtil.endCurrentComplexElement(LexiconServiceConstants.XML_ELEMENT_PRODUCTS, xmlFileCursor);
    }
    return preCommercialName;
  }

  private void parseProductDetail(ProductDetails productDetails,  boolean isParentProductDetail, XMLStreamReader xmlFileCursor) throws XMLStreamException {
    if(parserUtil.getNextChildElement(LexiconServiceConstants.XML_ELEMENT_PRE_COMMERCIAL_NAME, xmlFileCursor)){
      productDetails.setPreCommercialName(parserUtil.getSimpleElementText(LexiconServiceConstants.XML_ELEMENT_PRE_COMMERCIAL_NAME, xmlFileCursor));
    }
    parserUtil.skipElement(LexiconServiceConstants.XML_ELEMENT_CROP, xmlFileCursor);
    if (parserUtil.getNextElement(LexiconServiceConstants.XML_ELEMENT_IS_DELETED, xmlFileCursor)) {
      productDetails.setDeleted(getBoolean(parserUtil.getSimpleElementText(LexiconServiceConstants.XML_ELEMENT_IS_DELETED, xmlFileCursor)));
    }
    parserUtil.skipElement(LexiconServiceConstants.XML_ELEMENT_VARIETY_NAME, xmlFileCursor);
    // TODO: Need to add test for this scenario.
    if(parserUtil.getNextElement(LexiconServiceConstants.XML_ELEMENT_RELATIONSHIP_ATTRS, xmlFileCursor)){
      parseRelationshipAttributes(xmlFileCursor, productDetails);
    }
    if (!isParentProductDetail) {
      if(parserUtil.getNextElement(LexiconServiceConstants.XML_ELEMENT_PRODUCT_ALIASES, xmlFileCursor)){
        parseProductAliases(productDetails.getProductAliasList(), xmlFileCursor);
      }
    }
    if(parserUtil.getNextElement(LexiconServiceConstants.XML_ELEMENT_INBRED_HYBRID, xmlFileCursor)) {
      productDetails.setProductType(parserUtil.getSimpleElementText(LexiconServiceConstants.XML_ELEMENT_INBRED_HYBRID, xmlFileCursor));
    }
    if (!isParentProductDetail) {
      parserUtil.skipElement(LexiconServiceConstants.XML_ELEMENT_HAS_FINISHED_GERMPLASM, xmlFileCursor);
    }
    if (!isParentProductDetail) {
      while (parserUtil.getNextElement(LexiconServiceConstants.XML_ELEMENT_PARENTS, xmlFileCursor)){
        parseParents(productDetails.getParentDetailsList(), xmlFileCursor);
      }
    }
    if(isParentProductDetail){
      parserUtil.skipElement(LexiconServiceConstants.XML_ELEMENT_GERMPLASM, xmlFileCursor);
    }
    parserUtil.endCurrentComplexElement(LexiconServiceConstants.XML_ELEMENT_PRODUCT, xmlFileCursor);
  }

  private void parseParents(List parentDetailsList, XMLStreamReader xmlFileCursor) throws XMLStreamException {
    if (parserUtil.getNextChildElement(LexiconServiceConstants.XML_ELEMENT_PARENT, xmlFileCursor)) {
      parseParent(parentDetailsList, xmlFileCursor);
    }
    while (parserUtil.getNextElement(LexiconServiceConstants.XML_ELEMENT_PARENT, xmlFileCursor)) {
      parseParent(parentDetailsList, xmlFileCursor);
    }
    parserUtil.endCurrentComplexElement(LexiconServiceConstants.XML_ELEMENT_PARENTS, xmlFileCursor);
  }

  private void parseParent(List parentDetailsList, XMLStreamReader xmlFileCursor) throws XMLStreamException {
    String role = null;
    ProductDetails parentProductDetails = new ProductDetails();
    if (parserUtil.getNextChildElement(LexiconServiceConstants.XML_ELEMENT_ROLE, xmlFileCursor)) {
      role = parserUtil.getSimpleElementText(LexiconServiceConstants.XML_ELEMENT_ROLE, xmlFileCursor);
    }
    if (parserUtil.getNextElement(LexiconServiceConstants.XML_ELEMENT_PRODUCT, xmlFileCursor)) {
      parseProductDetail(parentProductDetails, true, xmlFileCursor);
    }
    if(!StringUtils.isNullOrEmpty(role) && role.equalsIgnoreCase(ParentDetails.ROLE_FEMALE_PARENT)){
      parentDetailsList.add(new ParentDetails("FEMALE", parentProductDetails));
    }
    if(!StringUtils.isNullOrEmpty(role) && role.equalsIgnoreCase(ParentDetails.ROLE_MALE_PARENT)){
      parentDetailsList.add(new ParentDetails("MALE", parentProductDetails));
    }
    parserUtil.endCurrentComplexElement(LexiconServiceConstants.XML_ELEMENT_PARENT, xmlFileCursor);
  }

  private void parseProductAliases(List productAliasList, XMLStreamReader xmlFileCursor) throws XMLStreamException {
    if (parserUtil.getNextChildElement(LexiconServiceConstants.XML_ELEMENT_PRODUCT_ALIAS, xmlFileCursor)) {
      processProductAlias(productAliasList, xmlFileCursor);
    }
    while (parserUtil.getNextChildElement(LexiconServiceConstants.XML_ELEMENT_PRODUCT_ALIAS, xmlFileCursor)) {
      processProductAlias(productAliasList, xmlFileCursor);
    }
    parserUtil.endCurrentComplexElement(LexiconServiceConstants.XML_ELEMENT_PRODUCT_ALIASES, xmlFileCursor);
  }

  private void processProductAlias(List productAliasList, XMLStreamReader xmlFileCursor) throws XMLStreamException {
    String brand = null;
    String country = null;
    String stage = null;
    Double commercialMaturity = null;
    String commercialName = null;
    Boolean isDeleted = null;
    Boolean isActive = null;
    String traits = null;
    if (parserUtil.getNextChildElement(LexiconServiceConstants.XML_ELEMENT_COMMERCIAL_NAME, xmlFileCursor)) {
      commercialName = parserUtil.getSimpleElementText(LexiconServiceConstants.XML_ELEMENT_COMMERCIAL_NAME, xmlFileCursor);
    }
    if (parserUtil.getNextElement(LexiconServiceConstants.XML_ELEMENT_BRAND, xmlFileCursor)) {
      brand = parserUtil.getSimpleElementText(LexiconServiceConstants.XML_ELEMENT_BRAND, xmlFileCursor);
    }
    if (parserUtil.getNextElement(LexiconServiceConstants.XML_ELEMENT_COUNTRY, xmlFileCursor)) {
      country = parserUtil.getSimpleElementText(LexiconServiceConstants.XML_ELEMENT_COUNTRY, xmlFileCursor);
    }
    if (parserUtil.getNextElement(LexiconServiceConstants.XML_ELEMENT_COMMERCIAL_TRAITS, xmlFileCursor)) {
      traits = parseCommercialTraits(xmlFileCursor);
    }
    if (parserUtil.getNextElement(LexiconServiceConstants.XML_ELEMENT_COMMERCIAL_MATURITY, xmlFileCursor)) {
      commercialMaturity = getDouble(parserUtil.getSimpleElementText(LexiconServiceConstants.XML_ELEMENT_COMMERCIAL_MATURITY, xmlFileCursor));
    }
    if (parserUtil.getNextElement(LexiconServiceConstants.XML_ELEMENT_IS_ACTIVE, xmlFileCursor)) {
      isActive = getBoolean(parserUtil.getSimpleElementText(LexiconServiceConstants.XML_ELEMENT_IS_ACTIVE, xmlFileCursor));
    }
    if (parserUtil.getNextElement(LexiconServiceConstants.XML_ELEMENT_IS_DELETED, xmlFileCursor)) {
      isDeleted = getBoolean(parserUtil.getSimpleElementText(LexiconServiceConstants.XML_ELEMENT_IS_DELETED, xmlFileCursor));
    }
    if (parserUtil.getNextElement(LexiconServiceConstants.XML_ELEMENT_STAGE, xmlFileCursor)) {
      stage = parserUtil.getSimpleElementText(LexiconServiceConstants.XML_ELEMENT_STAGE, xmlFileCursor);
    }
    parserUtil.endCurrentComplexElement(LexiconServiceConstants.XML_ELEMENT_PRODUCT_ALIAS, xmlFileCursor);
    ProductAlias productAlias = new ProductAlias(brand, country, stage, commercialMaturity, commercialName, isDeleted,
        isActive, traits);
    productAliasList.add(productAlias);
  }

  private String parseCommercialTraits(XMLStreamReader xmlFileCursor) throws XMLStreamException {
    String traits = null;
    if (parserUtil.getNextChildElement(LexiconServiceConstants.XML_ELEMENT_STACK_ABBR, xmlFileCursor)) {
      traits = parserUtil.getSimpleElementText(LexiconServiceConstants.XML_ELEMENT_STACK_ABBR, xmlFileCursor);
    }
    parserUtil.endCurrentComplexElement(LexiconServiceConstants.XML_ELEMENT_COMMERCIAL_TRAITS, xmlFileCursor);
    return traits;
  }

  private void parseRelationshipAttributes(XMLStreamReader xmlFileCursor, ProductDetails productDetails) throws XMLStreamException {
    if(parserUtil.getNextChildElement(LexiconServiceConstants.XML_ELEMENT_MANUFACTUING_NAME, xmlFileCursor)){
      productDetails.setManufacturingName(parserUtil.getSimpleElementText(LexiconServiceConstants.XML_ELEMENT_MANUFACTUING_NAME, xmlFileCursor));
    }
    if(parserUtil.getNextElement(LexiconServiceConstants.XML_ELEMENT_TRAIT_VERSION, xmlFileCursor)){
      productDetails.setVersion(parserUtil.getSimpleElementText(LexiconServiceConstants.XML_ELEMENT_TRAIT_VERSION, xmlFileCursor));
    }
    if (parserUtil.getNextElement(LexiconServiceConstants.XML_ELEMENT_PRODUCTION_STATUS, xmlFileCursor)) {
      productDetails.setProductionStatus(parserUtil.getSimpleElementText(LexiconServiceConstants.XML_ELEMENT_PRODUCTION_STATUS, xmlFileCursor));
    }
    parserUtil.endCurrentComplexElement(LexiconServiceConstants.XML_ELEMENT_RELATIONSHIP_ATTRS, xmlFileCursor);
  }

  private Double getDouble(String doubleString) {
    try {
      return new Double(doubleString);
    } catch (Exception e) {
      return null;
    }
  }

  private Boolean getBoolean(String booleanString) {
    try {
      return Boolean.valueOf(booleanString);
    } catch (Exception e) {
      return null;
    }
  }
}