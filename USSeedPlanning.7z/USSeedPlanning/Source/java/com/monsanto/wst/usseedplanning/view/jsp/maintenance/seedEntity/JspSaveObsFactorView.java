package com.monsanto.wst.usseedplanning.view.jsp.maintenance.seedEntity;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.wst.usseedplanning.constants.MainConstants;
import com.monsanto.wst.view.View;
import com.monsanto.wst.view.ViewRenderingException;

import java.io.IOException;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Aug 14, 2006
 * Time: 9:30:43 AM
 * To change this template use File | Settings | File Templates.
 */
public class JspSaveObsFactorView implements View {

    private List typeList;
    private String type;

    public JspSaveObsFactorView() {
    }

    public JspSaveObsFactorView(List typeList, String type) {
        this.typeList = typeList;
        this.type = type;
    }

    public void renderView(UCCHelper helper) throws ViewRenderingException {
        if (type!=null && typeList.size()>0){
            setRespectiveListIntoRequest(helper);
        }
        try {
            helper.forward(MainConstants.CREATE_OBS_FACTOR_JSP);
        } catch (IOException e) {
            throw new ViewRenderingException("Unable to Render View");
        }
    }

    private void setRespectiveListIntoRequest(UCCHelper helper) {
        if (this.type.equalsIgnoreCase(MainConstants.ERROR_LIST)){
            helper.setRequestAttributeValue(MainConstants.ERROR_LIST, this.typeList);
        }
    }

}
