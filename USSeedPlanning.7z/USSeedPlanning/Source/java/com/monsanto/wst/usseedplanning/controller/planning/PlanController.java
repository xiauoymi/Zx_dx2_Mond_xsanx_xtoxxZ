package com.monsanto.wst.usseedplanning.controller.planning;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.wst.servletframework.AbstractDispatchController;
import com.monsanto.wst.usseedplanning.constants.MainConstants;
import com.monsanto.wst.usseedplanning.constants.ControllerConstants;
import com.monsanto.wst.usseedplanning.model.core.LoginUser;
import com.monsanto.wst.usseedplanning.model.maintenance.Revision;
import com.monsanto.wst.usseedplanning.model.planning.*;
import com.monsanto.wst.usseedplanning.services.maintenance.forecast.ForecastService;
import com.monsanto.wst.usseedplanning.services.maintenance.seedEntity.YearService;
import com.monsanto.wst.usseedplanning.services.maintenance.supply.SupplyService;
import com.monsanto.wst.usseedplanning.services.planning.PlanService;
import com.monsanto.wst.usseedplanning.utils.transaction.TransactionUtils;
import com.monsanto.wst.usseedplanning.view.factory.ViewFactory;
import com.monsanto.wst.validator.HttpRequestErrors;
import com.monsanto.wst.validator.HttpRequestMessages;
import com.monsanto.wst.validator.HttpValidator;
import com.monsanto.wst.view.View;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.AbstractLogging.LoggableError;
import org.apache.commons.lang.StringUtils;

import java.io.File;
import java.io.IOException;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * Date: Sep 22, 2006
 * Time: 8:51:14 PM
 * <p/>
 * This class is the controller for the plan pages.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class PlanController extends AbstractDispatchController {
    private ViewFactory viewFactory;
    private PlanService planService;
    private YearService yearService;
    private HttpValidator validator;
    private ForecastService forecastService;
    private SupplyService supplyService;

    public PlanController(ViewFactory viewFactory, PlanService planService, YearService yearService,
                          HttpValidator validator, ForecastService forecastService, SupplyService supplyService) {
        this.viewFactory = viewFactory;
        this.planService = planService;
        this.yearService = yearService;
        this.validator = validator;
        this.forecastService = forecastService;
        this.supplyService = supplyService;
    }

    /**
     * This is the default action method for this controller.  It displays the plan form view.
     *
     * TODO: Refactor me, please!
     *
     * @param helper UCCHelper object containing the request and response.
     * @throws IOException - If unable to access request or response.
     */
    protected void notSpecified(UCCHelper helper) throws IOException {
        // TODO: Need to add validation for plan_type.
        String plan_type = helper.getRequestParameterValue("plan_type");
        String plan_id = helper.getRequestParameterValue("plan_id");
        List planList = planService.lookupPlansByPlanType(new Long(plan_type));
        List channelWithRevisionsList = forecastService.lookupDemandRevisionByChannel(new Long(plan_type));
        List supplyRevisionList = supplyService.lookupSupplyRevisionsByCriteria(new Long(plan_type));
        if (StringUtils.isNotEmpty(plan_id)) {
            preSelectPlanCriteria(plan_id, channelWithRevisionsList, supplyRevisionList, helper);
        }
        helper.setRequestAttributeValue("planYear", yearService.lookupCurrentYear());
        helper.setRequestAttributeValue("planList", planList);
        helper.setRequestAttributeValue("channelWithRevisionsList", channelWithRevisionsList);
        helper.setRequestAttributeValue("supplyRevisionList", supplyRevisionList);

        View view = this.viewFactory.getGenerateExcelReportView();
        view.renderView(helper);
    }

    /**
     * This method generates a plan and writes it to the view.
     *
     * @param helper UCCHelper object containing the request and response.
     * @throws IOException - If unable to access the request or response.
     */
    public void generatePlan(UCCHelper helper) throws Exception {
        HttpRequestErrors errors = this.validator.validate(helper);
        View view;
        if (errors.isEmpty()) {
            LoginUser user = (LoginUser) helper.getSessionParameter(MainConstants.LOGINUSER);
            String planName = helper.getRequestParameterValue("plan_name");
            PlanSummary summary = new PlanSummary(planName);
            PlanCriteria planCriteria = createPlanCriteria(helper);
            this.planService.generatePlan(summary, planCriteria, user);
            view = this.viewFactory.getUSSeedHomeView();
            view.renderView(helper);
        } else {
            helper.setRequestAttributeValue("errors", errors);
            notSpecified(helper);
        }
    }

    /**
     * This method retrieves the plan with the id specified on the request.  It then renders the plan using the appropriate
     * view.
     *
     * @param helper UCCHelper object containing the request and response.
     * @throws IOException - If unable to access the request or response.
     */
    public void openPlan(UCCHelper helper) throws IOException {
        String planId = helper.getRequestParameterValue("planId");
        String revisionId = helper.getRequestParameterValue("revisionId");
        PlanCriteria criteria = new PlanCriteria(new Long(planId), new Long(revisionId));
        Plan plan = this.planService.lookupPlanByCriteria(criteria);
        helper.setRequestAttributeValue("plan", plan);
        View view = this.viewFactory.getPlanView();
        view.renderView(helper);
    }

    /**
     * This method generates a list of all current plans in the system.
     *
     * @param helper UCCHelper object containing the request and response.
     * @throws IOException - If unable to access the request or response.
     */
    public void listPlans(UCCHelper helper) throws IOException {
        String planType = helper.getRequestParameterValue("plan_type");
        List planList = planService.lookupPlansByPlanType(new Long(planType));
        helper.setRequestAttributeValue("planList", planList);
        View view = viewFactory.getListPlansView();
        view.renderView(helper);
    }

    public void uploadPlan(UCCHelper helper) throws IOException {
        View view = this.viewFactory.getSavePlanView();
        view.renderView(helper);
    }

    /**
     * This method generates a plan and writes it to the view.
     *
     * @param helper UCCHelper object containing the request and response.
     * @throws java.io.IOException - If unable to access the request or response.
     */
    public void savePlan(UCCHelper helper) throws Exception {
        HttpRequestErrors errors = this.validator.validate(helper);
        View view;
        if(errors.isEmpty()){
            File spreadsheet = new File((String) helper.getClientFiles().get(0));
            String comments = helper.getRequestParameterValue("comments");
            LoginUser currentUser = (LoginUser) helper.getSessionParameter(MainConstants.LOGINUSER);
            try {
                this.planService.savePlan(spreadsheet, currentUser, comments);
                HttpRequestMessages messages = new HttpRequestMessages();
                messages.addMessage("Plan Successfully Saved.");
                helper.setRequestAttributeValue("messages", messages);
                helper.setRequestAttributeValue(ControllerConstants.MESSAGES_REQUEST_ATTRIBUTE, messages);
                view = this.viewFactory.getUSSeedHomeView();
                view.renderView(helper);
            } catch (Exception e) {
                if (Logger.isEnabled(Logger.ERROR_LOG)) {
                    Logger.log(new LoggableError("Unable to save plan."));
                    Logger.log(new LoggableError(e));
                }
                errors.addError(HttpRequestErrors.GLOBAL_ERROR, e.getMessage());
                helper.setRequestAttributeValue("errors", errors);
                uploadPlan(helper);
                new TransactionUtils(helper).flagForRollback();
            }
        }
        else{
            helper.setRequestAttributeValue("errors", errors);
            uploadPlan(helper);
        }
    }

    public void listPlansForCommit(UCCHelper helper) throws IOException {
        View view;
        String planType = helper.getRequestParameterValue("plan_type");
        List planlist = planService.lookupPlansByPlanType(new Long(planType));

        helper.setRequestAttributeValue("planList",planlist);
        view = this.viewFactory.getCommitPlanView();
        view.renderView(helper);
    }

    /**
     * This method generates a plan and writes it to the view.
     *
     * @param helper UCCHelper object containing the request and response.
     * @throws java.io.IOException - If unable to access the request or response.
     */
    public void commitPlan(UCCHelper helper) throws Exception {
        HttpRequestErrors errors = this.validator.validate(helper);
        View view;
        if(errors.isEmpty()){
            String comments = helper.getRequestParameterValue("comments");
            String planId = helper.getRequestParameterValue("planId");
            String[] planIdParts = planId.split("-");
            LoginUser currentUser = (LoginUser) helper.getSessionParameter(MainConstants.LOGINUSER);
            planService.commitPlan(currentUser, comments, new Long(planIdParts[1]), new Long(planIdParts[0]));
            HttpRequestMessages messages = new HttpRequestMessages();
            messages.addMessage("Plan Successfully Committed.");
            helper.setRequestAttributeValue("messages", messages);
            helper.setRequestAttributeValue(ControllerConstants.MESSAGES_REQUEST_ATTRIBUTE, messages);
            view = this.viewFactory.getUSSeedHomeView();
            view.renderView(helper);
        } else {
            helper.setRequestAttributeValue("errors", errors);
            listPlansForCommit(helper);
            return;
        }
    }

    public void downloadPlan(UCCHelper helper) throws IOException {
        String[] planParts = helper.getRequestParameterValue("plan").split("-");
        helper.setRequestAttributeValue("planId", planParts[0]);
        helper.setRequestAttributeValue("revisionId", planParts[1]);
        View view = viewFactory.getDownloadPlanView();
        view.renderView(helper);
    }

    /**
     * This method flags the appropriate objects in order to pre-select the criteria on the page associated with the
     * selected plan.
     *
     * @param plan_id String representing the plan id and revision.
     * @param channelWithRevisionsList List representing the demand revisions by channel.
     * @param supplyRevisionList List representing the supply revisions.
     * @param helper UCCHelper object containing the request and response.
     */
    private void preSelectPlanCriteria(String plan_id, List channelWithRevisionsList, List supplyRevisionList, UCCHelper helper) {
        String[] parts = plan_id.split("-");
        Long planId = new Long(parts[0]);
        Long planRevisionId = new Long(parts[1]);
        Plan plan = planService.lookupPlanSummaryByCriteria(new PlanCriteria(planId, planRevisionId));
        preSelectDemandRevisionsByChannel(plan, channelWithRevisionsList);
        preSelectSupplyRevision(supplyRevisionList, plan);
        helper.setRequestAttributeValue("plan", plan);
        helper.setRequestAttributeValue("planSelected", Boolean.TRUE);
    }

    private void preSelectSupplyRevision(List supplyRevisionList, Plan plan) {
        for (int i = 0; i < supplyRevisionList.size(); i++) {
            Revision revision = (Revision) supplyRevisionList.get(i);
            if (revision.getId().equals(plan.getSupplyRevision().getId())) {
                revision.setSelected(true);
            }
        }
    }

    private void preSelectDemandRevisionsByChannel(Plan plan, List channelWithRevisionsList) {
        for (int i = 0; i < plan.getPlanCriteria().getDemandCriteria().size(); i++) {
            DemandCriteria criteria = (DemandCriteria) plan.getPlanCriteria().getDemandCriteria().get(i);
            findDemandRevisionsForCurrentChannel(channelWithRevisionsList, criteria);
        }
    }

    private void findDemandRevisionsForCurrentChannel(List channelWithRevisionsList, DemandCriteria criteria) {
        for (int k = 0; k < channelWithRevisionsList.size(); k++) {
            ChannelizedDemandRevisions channelWithRevisions = (ChannelizedDemandRevisions) channelWithRevisionsList.get(k);
            if (channelWithRevisions.getChannel().getId().equals(criteria.getChannelId())) {
                List revisionList = channelWithRevisions.getDemandRevisions();
                preSelectDemandRevisionForCurrentChannel(revisionList, criteria);
            }
        }
    }

    private void preSelectDemandRevisionForCurrentChannel(List revisionList, DemandCriteria criteria) {
        for (int j = 0; revisionList != null && j < revisionList.size(); j++) {
            Revision revision = (Revision) revisionList.get(j);
            if (revision.getId().equals(criteria.getRevisionId())) {
                revision.setSelected(true);
            }
        }
    }

    /**
     * This method creates a plan criteria object from user data.
     *
     * @param helper UCCHelper object containing the request and response.
     * @return PlanCriteria - Object representing plan criteria.
     * @throws IOException - If unable to access the request.
     */
    private PlanCriteria createPlanCriteria(UCCHelper helper) throws IOException {
        Long supplyRev = null;
        if (StringUtils.isNotEmpty(helper.getRequestParameterValue("supplyRev"))) {
            supplyRev = new Long(helper.getRequestParameterValue("supplyRev"));
        }
        String planType = helper.getRequestParameterValue("plan_type");
        String plan_id = helper.getRequestParameterValue("plan_id");
        Long planId = null;
        Long revisionId = null;
        if (StringUtils.isNotEmpty(plan_id)) {
            String[] parts = plan_id.split("-");
            planId = new Long(parts[0]);
            revisionId = new Long(parts[1]);
        }
        PlanCriteria planCriteria = new PlanCriteria(supplyRev, new Long(planType), planId, revisionId);
        addDemandCriteria(helper, planCriteria);
        return planCriteria;
    }

    /**
     * This method adds demand criteria based on user data.
     *
     * @param helper UCCHelper object containing the request and response.
     * @param planCriteria PlanCriteria object representing plan criteria.
     * @throws IOException - If unable to access the request.
     */
    private void addDemandCriteria(UCCHelper helper, PlanCriteria planCriteria) throws IOException {
        String[] channelRevPairs = helper.getRequestParameterValues("channelRev");
        DemandCriteria demandCriteria;
        for (int i = 0; i < channelRevPairs.length; i++) {
            String[] pair = channelRevPairs[i].split("-");
            if(pair.length == 2){
                demandCriteria = new DemandCriteria(new Long(pair[1]), new Long(pair[0]));
                planCriteria.addDemandCriteria(demandCriteria);
            }
        }
    }
}
