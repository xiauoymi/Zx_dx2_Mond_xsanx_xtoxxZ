package com.monsanto.wst.usseedplanning.controller.maintenance.test;

import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.wst.usseedplanning.controller.maintenance.SupplyController;
import com.monsanto.wst.usseedplanning.model.core.LoginUser;
import com.monsanto.wst.usseedplanning.services.maintenance.supply.SupplyService;
import com.monsanto.wst.usseedplanning.services.maintenance.supply.mock.MockSupplyService;
import com.monsanto.wst.usseedplanning.view.factory.ViewFactory;
import com.monsanto.wst.usseedplanning.view.factory.mock.MockViewFactory;
import com.monsanto.wst.usseedplanning.constants.ControllerConstants;
import com.monsanto.wst.validator.HttpRequestErrors;
import com.monsanto.wst.validator.HttpRequestMessages;
import com.monsanto.wst.validator.HttpValidator;
import com.monsanto.wst.validator.test.mock.MockHttpValidator;
import com.monsanto.wst.view.test.mock.MockView;
import junit.framework.TestCase;

import java.io.File;
import java.io.IOException;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * Date: Aug 16, 2006
 * Time: 6:07:48 PM
 * <p/>
 * Unit test for the SupplyController object.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class SupplyControllerUT extends TestCase {
    public void testCreate() throws Exception {
        SupplyController controller = new SupplyController((SupplyService) null, (ViewFactory) null, (HttpValidator) null);
        assertNotNull(controller);
    }

    public void testNotSpecified() throws Exception {
        MockSupplyService supplyService = new MockSupplyService();
        MockViewFactory viewFactory = new MockViewFactory();
        SupplyController controller = new SupplyController(supplyService, viewFactory, (HttpValidator) null);
        MockUCCHelper helper = new MockUCCHelper(null);
        controller.run(helper);
        assertTrue(((MockView) viewFactory.getUpdateSupplyView()).wasViewRendered());
    }

    public void testUploadZDCA() throws Exception {
        MockSupplyService supplyService = new MockSupplyService();
        MockViewFactory viewFactory = new MockViewFactory();
        SupplyController controller = new SupplyController(supplyService, viewFactory, (HttpValidator) null);
        MockUCCHelper helper = new MockUCCHelper(null);
        helper.setRequestParameterValue("method", "uploadZDCA");
        controller.run(helper);
        assertTrue(((MockView) viewFactory.getUpdateZDCASupplyView()).wasViewRendered());
    }

    public void testUpdateATPSupply() throws Exception {
        MockSupplyService supplyService = new MockSupplyService();
        MockViewFactoryWithErrors viewFactory = new MockViewFactoryWithErrors();
        SupplyController controller = new SupplyController(supplyService, viewFactory, new MockHttpValidator());
        MockUCCHelper helper = new MockUCCHelper(null);
        helper.setRequestParameterValue("method", "updateSupply");
        helper.setRequestParameterValue("supplyType", "ATP");
        helper.setRequestParameterValue("planType", "12345");
        helper.addClientFile("test.xls");
        controller.run(helper);
        assertTrue(supplyService.wasSupplyUpdated());
        assertTrue(((MockView) viewFactory.getUSSeedHomeView()).wasViewRendered());
        assertEquals("Supply Update Successful", ((HttpRequestMessages) helper.getRequestAttributeValue(ControllerConstants.MESSAGES_REQUEST_ATTRIBUTE)).getMessages().get(0));
        assertNotNull(supplyService.getFile());
    }

    public void testUpdateSupplyValidationErrors() throws Exception {
        MockSupplyServiceThrowsIOException supplyService = new MockSupplyServiceThrowsIOException();
        MockViewFactoryWithErrors viewFactory = new MockViewFactoryWithErrors();
        HttpRequestErrors errors = new HttpRequestErrors();
        errors.addError("test", "test error");
        SupplyController controller = new SupplyController(supplyService, viewFactory, new MockHttpValidator(errors));
        MockUCCHelper helper = new MockUCCHelper(null);
        helper.setRequestParameterValue("method", "updateSupply");
        helper.setRequestParameterValue("supplyType", "ATP");
        controller.run(helper);
        assertTrue(((MockView) viewFactory.getUpdateSupplyView()).wasViewRendered());
    }

    public void testUpdateZDCASupply() throws Exception {
        MockSupplyService supplyService = new MockSupplyService();
        MockViewFactoryWithErrors viewFactory = new MockViewFactoryWithErrors();
        SupplyController controller = new SupplyController(supplyService, viewFactory, new MockHttpValidator());
        MockUCCHelper helper = new MockUCCHelper(null);
        helper.setRequestParameterValue("method", "updateSupply");
        helper.setRequestParameterValue("supplyType", "ZDCA");
        helper.setRequestParameterValue("planType", "12345");
        helper.addClientFile("test.xls");
        controller.run(helper);
        assertTrue(supplyService.wasSupplyUpdated());
        assertTrue(((MockView) viewFactory.getUSSeedHomeView()).wasViewRendered());
        assertEquals("Supply Update Successful", ((HttpRequestMessages) helper.getRequestAttributeValue(ControllerConstants.MESSAGES_REQUEST_ATTRIBUTE)).getMessages().get(0));
        assertNotNull(supplyService.getFile());
    }

    public void testUpdateZDCASupplyValidationErrors() throws Exception {
        MockSupplyServiceThrowsIOException supplyService = new MockSupplyServiceThrowsIOException();
        MockViewFactoryWithErrors viewFactory = new MockViewFactoryWithErrors();
        HttpRequestErrors errors = new HttpRequestErrors();
        errors.addError("test", "test error");
        SupplyController controller = new SupplyController(supplyService, viewFactory, new MockHttpValidator(errors));
        MockUCCHelper helper = new MockUCCHelper(null);
        helper.setRequestParameterValue("method", "updateSupply");
        helper.setRequestParameterValue("supplyType", "ZDCA");
        controller.run(helper);
        assertTrue(((MockView) viewFactory.getUpdateZDCASupplyView()).wasViewRendered());
    }

    private class MockSupplyServiceThrowsIOException implements SupplyService {
        public void updateSupply(File file, LoginUser owner, String supplyType, Long planType, String comments) throws IOException {
            throw new IOException("Test Exception");
        }

        public List lookupSupplyRevisionsByCriteria(Long planTypeId) {
            return null;  //To change body of implemented methods use File | Settings | File Templates.
        }
    }

    private class MockViewFactoryWithErrors extends MockViewFactory {
        private HttpRequestErrors errors;
        private HttpRequestMessages messages;

        public HttpRequestErrors getErrors() {
            return this.errors;
        }

        public HttpRequestMessages getMessages() {
            return this.messages;
        }
    }
}
