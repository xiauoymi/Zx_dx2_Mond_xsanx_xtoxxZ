/*
 JspSavePlanView_UT was created on Oct 12, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.usseedplanning.view.jsp.planning.test;

import junit.framework.TestCase;
import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.wst.usseedplanning.view.jsp.planning.JspSavePlanView;
import com.monsanto.wst.usseedplanning.constants.MainConstants;
import com.monsanto.wst.commonutils.testutils.TestUtils;
import com.monsanto.wst.view.test.mock.MockUCCHelperThrowsIOException;
import com.monsanto.wst.view.ViewRenderingException;
import com.monsanto.AbstractLogging.Logger;

/**
 * Filename:    $RCSfile: JspSavePlanView_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ffbrac $    	 On:	$Date: 2006-10-12 21:03:42 $
 *
 * @author ffbrac
 * @version $Revision: 1.1 $
 */
public class JspSavePlanView_UT extends TestCase {
	MockUCCHelper helper = null;

	public void testCreate() throws Exception{
	    JspSavePlanView planningPage = new JspSavePlanView();
	    assertNotNull(planningPage);
	}

	protected void setUp() throws Exception {
	    new TestUtils().setupLogging(MainConstants.APPLICATION_NAME);
	    super.setUp();
	    helper = new MockUCCHelper(null);
	}

	public void testRenderView() throws Exception {
		JspSavePlanView planningPage = new JspSavePlanView();
	    planningPage.renderView(helper);
	    assertTrue(helper.wasSentTo(MainConstants.SAVE_PLAN_PAGE));
	}

	public void testRenderViewThrowsException() throws Exception {
	    MockUCCHelperThrowsIOException helperThrowsIOException = new MockUCCHelperThrowsIOException(null);
		JspSavePlanView planningPage = new JspSavePlanView();
		Logger.enableLogger(Logger.ERROR_LOG);
	    try {
	        planningPage.renderView(helperThrowsIOException);
	        fail("This should have thrown Exception");
	    } catch (ViewRenderingException e) {
	        assertEquals("Unable to Render View", e.getMessage());
	    }
		Logger.disableLogger(Logger.ERROR_LOG);
	    try {
	        planningPage.renderView(helperThrowsIOException);
	        fail("This should have thrown Exception");
	    } catch (ViewRenderingException e) {
	        assertEquals("Unable to Render View", e.getMessage());
	    }
	}
	public void testRenderViewThrowsExceptionFail() throws Exception {
	    MockUCCHelperThrowsIOException helperThrowsIOException = new MockUCCHelperThrowsIOException(null);
		JspSavePlanView planningPage = new JspSavePlanView();
	}
}