/*
Batch was created on Dec 6, 2006 using Monsanto
resources and is the sole property of Monsanto.  Any duplication of the
code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.usseedplanning.services.batchupdate;

import com.monsanto.wst.factory.AbstractGenericFactory;
import com.monsanto.wst.factory.GenericFactory;
import com.monsanto.wst.dbtemplate.transaction.TransactionManager;
import com.monsanto.wst.dbtemplate.factory.AbstractTransactionManagerFactory;
import com.monsanto.wst.commonutils.testutils.TestUtils;
import com.monsanto.wst.usseedplanning.model.core.LoginUser;
import com.monsanto.wst.usseedplanning.services.maintenance.CommonUploadService;
import com.monsanto.wst.usseedplanning.services.maintenance.CommonUploadServiceImpl;
import com.monsanto.AbstractLogging.LogRegistrationException;

import java.io.IOException;

/**
 * Filename:    $RCSfile: Batch.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: vrbethi $    	 On:	$Date:
 * 2007/02/13 22:16:06 $
 *
 * @author vrbethi
 * @version $Revision: 1.11 $
 */
public class Batch {

  //todo what would you do to test this.
  public static void main(String[] args) throws LogRegistrationException, IOException {
    TestUtils testUtils = new TestUtils();
    testUtils.setupLogging("USSeedPlanning");
    AbstractGenericFactory.setImplementation("com.monsanto.wst.factory.DelegatingLocatorGenericFactory");
    AbstractGenericFactory.addCustomFactory("com.monsanto.wst.usseedplanning.container.DaoFactory");
    AbstractGenericFactory.addCustomFactory("com.monsanto.wst.usseedplanning.container.ServiceFactory");
    AbstractGenericFactory.addCustomFactory("com.monsanto.wst.usseedplanning.container.ValidatorFactory");
    AbstractGenericFactory.addCustomFactory("com.monsanto.wst.usseedplanning.container.ControllerFactory");
    AbstractGenericFactory.addCustomFactory("com.monsanto.wst.usseedplanning.view.factory.ViewFactoryImpl");
    GenericFactory genericFactory = AbstractGenericFactory.getInstance();
    String config = (String) genericFactory.getBean("dataSourceConfigFile");
    AbstractTransactionManagerFactory txManagerFactory = AbstractTransactionManagerFactory.newInstance(config);
    TransactionManager txManager = txManagerFactory.getTransactionManager();
    genericFactory.addBean("transactionManager", txManager, true);
    BatchService batchService = (BatchService) AbstractGenericFactory.getInstance().getBean("batchService");
    CommonUploadService commonUploadService = (CommonUploadService) AbstractGenericFactory.getInstance()
      .getBean("commonUploadService");
    ((BatchServiceImpl) batchService).setLoginUser(new LoginUser("BATCH"));
    batchService.runBatch();
    ((CommonUploadServiceImpl) commonUploadService).resolvePreCommercialNames(new LoginUser("BATCH"));
    txManager.commitTransaction();
  }
}