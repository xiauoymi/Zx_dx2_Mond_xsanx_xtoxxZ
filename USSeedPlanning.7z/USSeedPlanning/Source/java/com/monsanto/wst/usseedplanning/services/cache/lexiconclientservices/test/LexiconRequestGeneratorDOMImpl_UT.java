/*
 Copyright:  Copyright � 2006 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.usseedplanning.services.cache.lexiconclientservices.test;

import org.custommonkey.xmlunit.XMLTestCase;
import org.custommonkey.xmlunit.SimpleXpathEngine;
import org.w3c.dom.Document;
import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.wst.commonutils.resources.ResourceUtils;
import com.monsanto.wst.usseedplanning.services.cache.lexiconclientservices.ProductServiceRequestGenerator;
import com.monsanto.wst.usseedplanning.services.cache.lexiconclientservices.LexiconServiceRequestGeneratorDOMImpl;
import com.monsanto.wst.usseedplanning.constants.MainConstants;

import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.io.IOException;

/**
 * Filename:    $RCSfile: LexiconRequestGeneratorDOMImpl_UT.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: njminsh $    	 On:	$Date: 2007-01-31 22:39:38 $
 *
 * @author rdesai2
 * @version $Revision: 1.1 $
 */
public class LexiconRequestGeneratorDOMImpl_UT extends XMLTestCase {

  private ProductServiceRequestGenerator requestGenerator;

  protected void setUp() throws IOException {
    requestGenerator = new LexiconServiceRequestGeneratorDOMImpl();
  }

  public void testGetRequestDocumentForGetAggregateProductLexiconService() throws Exception {
    Document requestDoc = DOMUtil.newDocumentNS(new InputStreamReader(new FileInputStream(new ResourceUtils().convertPathToFile(MainConstants.REQUEST_TEMPLATE_XML_LEX_GET_AGGREGATE_PRODUCT))));
    SimpleXpathEngine.registerNamespace("ns1", requestDoc.getDocumentElement().getNamespaceURI());
    assertXpathEvaluatesTo("sch*m22", "/ns1:Request/ns1:ProductName", requestDoc);
    Document transformedRequestDoc = requestGenerator.getRequestDocumentForGetAggregateProductService("testCommercialName");
    assertXpathEvaluatesTo("testCommercialName", LexiconServiceRequestGeneratorDOMImpl.XPATH_GET_AGGREGATE_PRODUCT_SERVICE, transformedRequestDoc);
  }

  public void testGetRequestDocumentForGetAggregateProductLexiconServiceForNullOrEmptyCommercialName_ThrowsIllegalArgumentException() throws Exception {
    try {
      requestGenerator.getRequestDocumentForGetAggregateProductService(null);
      fail("Exception not thrown");
    } catch (IllegalArgumentException e) {
      //expected path
    }
    try {
      requestGenerator.getRequestDocumentForGetAggregateProductService("");
      fail("Exception not thrown");
    } catch (IllegalArgumentException e) {
      //expected path
    }
  }

  public void testGetRequestDocumentForProductParentsByPrecommercialNameLexiconService() throws Exception {
    Document requestDoc = DOMUtil.newDocumentNS(new InputStreamReader(new FileInputStream(new ResourceUtils().convertPathToFile(MainConstants.REQUEST_TEMPLATE_XML_Lex_PRODUCT_PARENT_BY_PRE_COML_NAME))));
    SimpleXpathEngine.registerNamespace("ns1", requestDoc.getDocumentElement().getNamespaceURI());
    assertXpathEvaluatesTo("PCName", "/ns1:ProductParentRequest/ns1:PreCommercialName", requestDoc);
    Document transformedRequestDoc = requestGenerator.getRequestDocumentForProductParentsByPrecommercialNameService("testPreCommercialName");
    assertXpathEvaluatesTo("testPreCommercialName",LexiconServiceRequestGeneratorDOMImpl.XPATH_GET_PRODUCT_PARENT_BY_PRE_COMPL_NAME, transformedRequestDoc);
  }

  public void testGetRequestDocumentForProductParentsByPrecommercialNameLexiconServiceForNullOrEmptyPreComlName_ThrowsIllegalArgumentException() throws Exception {
    try {
      requestGenerator.getRequestDocumentForProductParentsByPrecommercialNameService(null);
      fail("Exception not thrown");
    } catch (IllegalArgumentException e) {
      //expected path
    }
    try {
      requestGenerator.getRequestDocumentForProductParentsByPrecommercialNameService("");
      fail("Exception not thrown");
    } catch (IllegalArgumentException e) {
      //expected path
    }
  }

  public void testGetRequestDocumentForProductParentsByManufacturingNameLexiconService() throws Exception {
    Document requestDoc = DOMUtil.newDocumentNS(new InputStreamReader(new FileInputStream(new ResourceUtils().convertPathToFile(MainConstants.REQUEST_TEMPLATE_XML_Lex_PRODUCT_PARENT_BY_MFG_NAME))));
    SimpleXpathEngine.registerNamespace("ns1", requestDoc.getDocumentElement().getNamespaceURI());
    assertXpathEvaluatesTo("ManfName", "/ns1:ProductParentRequest/ns1:ManufacturingName", requestDoc);
    Document transformedRequestDoc = requestGenerator.getRequestDocumentForProductParentsByManufacturingNameService("testMfgName");
    assertXpathEvaluatesTo("testMfgName",LexiconServiceRequestGeneratorDOMImpl.XPATH_GET_PRODUCT_PARENT_BY_MFG_NAME, transformedRequestDoc);
  }

  public void testGetRequestDocumentForProductParentsByManufacturingNameLexiconServiceForNullOrEmptyPreComlName_ThrowsIllegalArgumentException() throws Exception {
    try {
      requestGenerator.getRequestDocumentForProductParentsByManufacturingNameService(null);
      fail("Exception not thrown");
    } catch (IllegalArgumentException e) {
      //expected path
    }
    try {
      requestGenerator.getRequestDocumentForProductParentsByManufacturingNameService("");
      fail("Exception not thrown");
    } catch (IllegalArgumentException e) {
      //expected path
    }
  }
}