/*
 LexiconResponseParser_UT was created on Sep 25, 2006 using Monsanto
 resources and is the sole property of Monsanto.  Any duplication of the
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.usseedplanning.services.cache.lexiconclientservices.test;

import com.monsanto.wst.commonutils.resources.ResourceUtils;
import com.monsanto.wst.usseedplanning.model.cache.ProductDetails;
import com.monsanto.wst.usseedplanning.model.cache.ProductAlias;
import com.monsanto.wst.usseedplanning.model.planning.ParentDetails;
import com.monsanto.wst.usseedplanning.services.cache.lexiconclientservices.ProductServiceResponseParser;
import com.monsanto.wst.usseedplanning.services.cache.lexiconclientservices.LexiconServiceResponseStAXParserImpl;
import junit.framework.TestCase;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.File;
import java.util.List;

/**
 * Filename:    $RCSfile: LexiconResponseParser_UT.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: njminsh $    	 On:	$Date: 2007-01-31 22:39:38 $
 *
 * @author VRBETHI
 * @version $Revision: 1.1 $
 */
public class LexiconResponseParser_UT extends TestCase {

  private ProductServiceResponseParser parser;

  private static final String SIMPLE_INBRED_RESPONSE = "com/monsanto/wst/usseedplanning/services/cache/lexiconclientservices/test/SimpleInbredResonse.xml";
  private static final String INBRED_WITH_MISSING_OPTIONAL_DATA_RESPONSE = "com/monsanto/wst/usseedplanning/services/cache/lexiconclientservices/test/InbredWithMissingOptionalData.xml";
  private static final String SIMPLE_HYBRID_RESPONSE = "com/monsanto/wst/usseedplanning/services/cache/lexiconclientservices/test/SimpleHybridResponse.xml";
  private static final String HYBRID_TRAIT_RECIPROCAL_RESPONSE = "com/monsanto/wst/usseedplanning/services/cache/lexiconclientservices/test/HybridTraitReciprocal.xml";
  private static final String NO_RESULT_FROM_LEXICON_SERVICE = "com/monsanto/wst/usseedplanning/services/cache/lexiconclientservices/test/NoResultFromLexiconService.xml";
  private static final String MULTIPLE_PRODUCTS_PRE_COMM_SERVICE_RESP = "com/monsanto/wst/usseedplanning/services/cache/lexiconclientservices/test/MultipleProductsPreCommResp.xml";
  private static final String MULTIPLE_PRODUCTS_MANUFACTURING_NAME_SERVICE_RESP = "com/monsanto/wst/usseedplanning/services/cache/lexiconclientservices/test/MultipleProductsMfgResp.xml";
  private static final String AGGREGATE_PRODUCT_SERVICE_RESP = "com/monsanto/wst/usseedplanning/services/cache/lexiconclientservices/test/AggregateProductServiceResponse.xml";

  protected void setUp() throws IOException {
    parser = new LexiconServiceResponseStAXParserImpl();
  }

  public void testGetPreCommercialNameFromGetAggregateProductLexiconServiceResponse() throws Exception {
    ProductServiceResponseParser parser = new LexiconServiceResponseStAXParserImpl();
    String preCommercialName = parser.getPreCommercialNameFromGetAggregateProductServiceResponse(new FileInputStream(new ResourceUtils().convertPathToFile(AGGREGATE_PRODUCT_SERVICE_RESP)));
    assertNotNull(preCommercialName);
    assertEquals("EXP744", preCommercialName);
  }

  public void testNoResultCaseUsingPreCommercialNameServiceResponse() throws Exception {
    File file = new ResourceUtils().convertPathToFile(NO_RESULT_FROM_LEXICON_SERVICE);
    FileInputStream in = new FileInputStream(file);
    List productDetailsList = parser.getProductDetailsListFromProductParentsByPrecommercialNameServiceResponse(in);
    assertNotNull(productDetailsList);
    assertEquals(0, productDetailsList.size());
  }

  public void testNoResultCaseUsingManufacturingNameServiceResponse() throws Exception {
    List productDetailsList = parser.getProductDetailsListFromProductParentsByManufacturingNameServiceResponse(new FileInputStream(new ResourceUtils().convertPathToFile(NO_RESULT_FROM_LEXICON_SERVICE)));
    assertNotNull(productDetailsList);
    assertEquals(0, productDetailsList.size());
  }

  public void testParsingForInbredTypeUsingPreCommercialNameServiceResponse() throws Exception {
    File file = new ResourceUtils().convertPathToFile(SIMPLE_INBRED_RESPONSE);
    FileInputStream in = new FileInputStream(file);

    List productDetailsList = parser.getProductDetailsListFromProductParentsByPrecommercialNameServiceResponse(in);

    assertNotNull(productDetailsList);
    assertEquals(1, productDetailsList.size());
    validateProductDetails("EXP257", "LH244+LH295", null,
            "A", ProductDetails.PRODUCT_TYPE_PARENT,
            (ProductDetails)productDetailsList.get(0));

    ProductAlias expected = new ProductAlias("CORN STATES", "USA", "CM1", new Double("106.1"), "LH244+LH295",
        Boolean.FALSE, Boolean.FALSE, "CONV");
    ProductAlias actual = (ProductAlias) ((ProductDetails) productDetailsList.get(0)).getProductAliasList().get(0);
    validateProductAlias(expected, actual);

    expected = new ProductAlias("CORN STATES INTERNATIONAL", "HUN", "CM2", new Double("1206.2"), "DPA5464",
        Boolean.FALSE, Boolean.TRUE, "CONV");
    actual = (ProductAlias) ((ProductDetails) productDetailsList.get(0)).getProductAliasList().get(1);
    validateProductAlias(expected, actual);

    expected = new ProductAlias("CORN STATES", "CAN", "CM3", new Double("1036.30"), "LH244+LH295", Boolean.FALSE,
        Boolean.FALSE, "CONV");
    actual = (ProductAlias) ((ProductDetails) productDetailsList.get(0)).getProductAliasList().get(2);
    validateProductAlias(expected, actual);
  }

  public void testParsingForInbredTypeWithMissingOptionalDataUsingPreCommercialNameServiceResponse() throws Exception {
    File file = new ResourceUtils().convertPathToFile(INBRED_WITH_MISSING_OPTIONAL_DATA_RESPONSE);
    FileInputStream in = new FileInputStream(file);

    List productDetailsList = parser.getProductDetailsListFromProductParentsByPrecommercialNameServiceResponse(in);

    assertNotNull(productDetailsList);
    assertEquals(1, productDetailsList.size());
    ProductDetails productDetails = (ProductDetails) productDetailsList.get(0);
    assertNotNull(productDetails.getProductAliasList());
    assertEquals(2, productDetails.getProductAliasList().size());
    validateProductDetails("EXP257", null, null, null, null, (ProductDetails)productDetailsList.get(0));

    ProductAlias expected = new ProductAlias("CORN STATES", "USA", "CM1", new Double("106.1"), "LH244+LH295",
        Boolean.FALSE, Boolean.FALSE, "CONV");
    ProductAlias actual = (ProductAlias) ((ProductDetails) productDetailsList.get(0)).getProductAliasList().get(0);
    validateProductAlias(expected, actual);

    expected = new ProductAlias("CORN STATES INTERNATIONAL", "HUN", "CM2", new Double("1206.2"), "DPA5464",
        Boolean.FALSE, Boolean.TRUE, "CONV");
    actual = (ProductAlias) ((ProductDetails) productDetailsList.get(0)).getProductAliasList().get(1);
    validateProductAlias(expected, actual);
  }

  public void testParsingForHybridTypeUsingManufacturingNameServiceResponse() throws Exception {
    File file = new ResourceUtils().convertPathToFile(SIMPLE_HYBRID_RESPONSE);
    FileInputStream in = new FileInputStream(file);

    List productDetailsList = parser.getProductDetailsListFromProductParentsByManufacturingNameServiceResponse(in);

    assertNotNull(productDetailsList);
    assertEquals(1, productDetailsList.size());

    validateProductDetails("EXP257", "LH244+LH295", null,
            "P", ProductDetails.PRODUCT_TYPE_HYBRID,
            (ProductDetails)productDetailsList.get(0));

    ProductAlias expected =
        new ProductAlias("CORN STATES", "USA", "CM1", new Double("106"), "LH244+LH295", Boolean.FALSE, Boolean.FALSE, "CONV");
    ProductAlias actual = (ProductAlias) ((ProductDetails) productDetailsList.get(0)).getProductAliasList().get(0);
    validateProductAlias(expected, actual);

    expected =
        new ProductAlias("CORN STATES INTERNATIONAL", "HUN", "CM2", new Double("1206"), "DX5543", Boolean.FALSE, Boolean.TRUE, "CONV");
    actual = (ProductAlias) ((ProductDetails) productDetailsList.get(0)).getProductAliasList().get(1);
    validateProductAlias(expected, actual);

    expected =
        new ProductAlias("CORN STATES", "CAN", "CM3", new Double("1036"), "CD8876", Boolean.FALSE, Boolean.FALSE, "CONV");
    actual = (ProductAlias) ((ProductDetails) productDetailsList.get(0)).getProductAliasList().get(2);
    validateProductAlias(expected, actual);

    validateParentDetails("FEMALE", "LH244", "LH244",
            "A", ProductDetails.PRODUCT_TYPE_PARENT,
            (ParentDetails)((ProductDetails) productDetailsList.get(0)).getParentDetailsList().get(0));
    validateParentDetails("MALE", "LH295", "LH295",
            "A", ProductDetails.PRODUCT_TYPE_PARENT,
            (ParentDetails)((ProductDetails) productDetailsList.get(0)).getParentDetailsList().get(1));
  }

  public void testResponseContainingTraitReciprocalsReturnsAllFourParents() throws Exception {
    File file = new ResourceUtils().convertPathToFile(HYBRID_TRAIT_RECIPROCAL_RESPONSE);
    FileInputStream in = new FileInputStream(file);
    List productDetailsList = parser.getProductDetailsListFromProductParentsByManufacturingNameServiceResponse(in);
    assertNotNull(productDetailsList);
    assertEquals(1, productDetailsList.size());
    validateProductDetails("EXP257", "LH244+LH295", null,
            "P", ProductDetails.PRODUCT_TYPE_HYBRID,
            (ProductDetails)productDetailsList.get(0));

    ProductAlias expected =
        new ProductAlias("CORN STATES", "USA", "CM1", new Double("106"), "LH244+LH295", Boolean.FALSE, Boolean.FALSE, "CONV");
    ProductAlias actual = (ProductAlias) ((ProductDetails) productDetailsList.get(0)).getProductAliasList().get(0);
    validateProductAlias(expected, actual);

    expected =
        new ProductAlias("CORN STATES INTERNATIONAL", "HUN", "CM2", new Double("1206"), "DX5543", Boolean.FALSE, Boolean.TRUE, "CONV");
    actual = (ProductAlias) ((ProductDetails) productDetailsList.get(0)).getProductAliasList().get(1);
    validateProductAlias(expected, actual);

    expected =
        new ProductAlias("CORN STATES", "CAN", "CM3", new Double("1036"), "CD8876", Boolean.FALSE, Boolean.FALSE, "CONV");
    actual = (ProductAlias) ((ProductDetails) productDetailsList.get(0)).getProductAliasList().get(2);
    validateProductAlias(expected, actual);

    assertEquals(4, ((ProductDetails) productDetailsList.get(0)).getParentDetailsList().size());
    validateParentDetails("FEMALE", "LH295", "LH295",
            "A", ProductDetails.PRODUCT_TYPE_PARENT,
            (ParentDetails)((ProductDetails) productDetailsList.get(0)).getParentDetailsList().get(0));
    validateParentDetails("MALE", "LH244", "LH244",
            "A", ProductDetails.PRODUCT_TYPE_PARENT,
            (ParentDetails)((ProductDetails) productDetailsList.get(0)).getParentDetailsList().get(1));
    validateParentDetails("FEMALE", "LH244", "LH244",
            "A", ProductDetails.PRODUCT_TYPE_PARENT,
            (ParentDetails)((ProductDetails) productDetailsList.get(0)).getParentDetailsList().get(2));
    validateParentDetails("MALE", "LH295", "LH295",
            "A", ProductDetails.PRODUCT_TYPE_PARENT,
            (ParentDetails)((ProductDetails) productDetailsList.get(0)).getParentDetailsList().get(3));
  }

  public void testMultipleProductsUsingPrecommercialNameService() throws Exception {
    File file = new ResourceUtils().convertPathToFile(MULTIPLE_PRODUCTS_PRE_COMM_SERVICE_RESP);
    FileInputStream in = new FileInputStream(file);
    List productDetailsList = parser.getProductDetailsListFromProductParentsByPrecommercialNameServiceResponse(in);
    assertNotNull(productDetailsList);
    assertEquals(4, productDetailsList.size());
    validateProductDetails("PRECOMM1", "MFG-NAME1", null,
            "A", ProductDetails.PRODUCT_TYPE_PARENT,
            (ProductDetails)productDetailsList.get(0));
    validateProductDetails("EXP257", null, null,
            null, ProductDetails.PRODUCT_TYPE_HYBRID,
            (ProductDetails)productDetailsList.get(1));
    ProductAlias expected =
        new ProductAlias("CORN STATES", "USA", "CM1", new Double("106"), "LH244+LH295", Boolean.FALSE, Boolean.FALSE, "CONV");
    ProductAlias actual = (ProductAlias) ((ProductDetails) productDetailsList.get(1)).getProductAliasList().get(0);
    validateProductAlias(expected, actual);
    validateParentDetails("FEMALE", "LH244", "LH244",
            "A", ProductDetails.PRODUCT_TYPE_PARENT,
            (ParentDetails)((ProductDetails) productDetailsList.get(1)).getParentDetailsList().get(0));
    validateParentDetails("MALE", "LH295", "LH295",
            "A", ProductDetails.PRODUCT_TYPE_PARENT,
            (ParentDetails)((ProductDetails) productDetailsList.get(1)).getParentDetailsList().get(1));
    validateProductDetails("PRECOMM2", "MFG-NAME2", null,
            "P", ProductDetails.PRODUCT_TYPE_PARENT,
            (ProductDetails)productDetailsList.get(2));
    validateProductDetails("HBRD2", null, null,
            null, ProductDetails.PRODUCT_TYPE_HYBRID,
            (ProductDetails)productDetailsList.get(3));
    validateParentDetails("FEMALE", "FP2", "LH111",
            "A", ProductDetails.PRODUCT_TYPE_PARENT,
            (ParentDetails)((ProductDetails) productDetailsList.get(3)).getParentDetailsList().get(0));
    validateParentDetails("MALE", "MP2", "LH222",
            "A", ProductDetails.PRODUCT_TYPE_PARENT,
            (ParentDetails)((ProductDetails) productDetailsList.get(3)).getParentDetailsList().get(1));
  }

  public void testMultipleProductsUsingManufacturingNameService() throws Exception {
    File file = new ResourceUtils().convertPathToFile(MULTIPLE_PRODUCTS_MANUFACTURING_NAME_SERVICE_RESP);
    FileInputStream in = new FileInputStream(file);
    List productDetailsList = parser.getProductDetailsListFromProductParentsByManufacturingNameServiceResponse(in);
    assertNotNull(productDetailsList);
    assertEquals(4, productDetailsList.size());
    validateProductDetails("PRECOMM1", "MFG-NAME1", null,
            "A", ProductDetails.PRODUCT_TYPE_PARENT,
            (ProductDetails)productDetailsList.get(0));
    validateProductDetails("EXP257", "MFG-NAME1", null,
            "A", ProductDetails.PRODUCT_TYPE_HYBRID,
            (ProductDetails)productDetailsList.get(1));
    ProductAlias expected =
        new ProductAlias("CORN STATES", "USA", "CM1", new Double("106"), "LH244+LH295", Boolean.FALSE, Boolean.FALSE, "CONV");
    ProductAlias actual = (ProductAlias) ((ProductDetails) productDetailsList.get(1)).getProductAliasList().get(0);
    validateProductAlias(expected, actual);
    validateParentDetails("FEMALE", "LH244", "LH244",
            "A", ProductDetails.PRODUCT_TYPE_PARENT,
            (ParentDetails)((ProductDetails) productDetailsList.get(1)).getParentDetailsList().get(0));
    validateParentDetails("MALE", "LH295", "LH295",
            "A", ProductDetails.PRODUCT_TYPE_PARENT,
            (ParentDetails)((ProductDetails) productDetailsList.get(1)).getParentDetailsList().get(1));
    validateProductDetails("PRECOMM2", "MFG-NAME2", null,
            "P", ProductDetails.PRODUCT_TYPE_PARENT,
            (ProductDetails)productDetailsList.get(2));
    validateProductDetails("HBRD2", "MFG-NAME2", null,
           "P", ProductDetails.PRODUCT_TYPE_HYBRID,
            (ProductDetails)productDetailsList.get(3));
    validateParentDetails("FEMALE", "FP2", "LH111",
            "A", ProductDetails.PRODUCT_TYPE_PARENT,
            (ParentDetails)((ProductDetails) productDetailsList.get(3)).getParentDetailsList().get(0));
    validateParentDetails("MALE", "MP2", "LH222",
            "A", ProductDetails.PRODUCT_TYPE_PARENT,
            (ParentDetails)((ProductDetails) productDetailsList.get(3)).getParentDetailsList().get(1));
  }

  private void validateParentDetails(String role, String preCommercialName, String manufacturingName, String productionStatus, String inbredHybrid, ParentDetails parentDetails) {
    assertNotNull(parentDetails);
    assertEquals(role, parentDetails.getRole());
    validateProductDetails(preCommercialName, manufacturingName, null,
            productionStatus, inbredHybrid,
            parentDetails.getProductDetails());
  }

  private void validateProductDetails(String preCommercialName, String manufacturingName, String traitVersion, String productionStatus, String inbredHybrid, ProductDetails productDetails)  {
    assertEquals(preCommercialName, productDetails.getPreCommercialName());
    assertEquals(manufacturingName, productDetails.getManufacturingName());
    assertEquals(traitVersion, productDetails.getVersion());
    assertEquals(productionStatus, productDetails.getProductionStatus());
    assertEquals(inbredHybrid, productDetails.getProductType());
  }

  private void validateProductAlias(ProductAlias expected, ProductAlias actual) {
    assertNotNull(actual);
    assertEquals(expected.getBrand(), actual.getBrand());
    assertEquals(expected.getCountry(), actual.getCountry());
    assertEquals(expected.getStage(), actual.getStage());
    assertEquals(expected.getCommercialMaturity(), actual.getCommercialMaturity());
    assertEquals(expected.getCommercialName(), actual.getCommercialName());
    assertEquals(expected.getDeleted(), actual.getDeleted());
    assertEquals(expected.getActive(), actual.getActive());
    assertEquals(expected.getTraits(), actual.getTraits());
  }
}