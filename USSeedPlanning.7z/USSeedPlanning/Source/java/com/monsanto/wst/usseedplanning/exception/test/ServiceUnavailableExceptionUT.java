/*
 LexiconServiceExceptionUT was created on Aug 17, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.usseedplanning.exception.test;

import com.monsanto.wst.usseedplanning.exception.ServiceUnavailableException;
import junit.framework.TestCase;

/**
 * Filename:    $RCSfile: ServiceUnavailableExceptionUT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: SSPATI1 $    	 On:	$Date: 2006-08-17 18:46:44 $
 *
 * @author sspati1
 * @version $Revision: 1.1 $
 */
public class ServiceUnavailableExceptionUT extends TestCase {
    public void testCreate() throws Exception {
        ServiceUnavailableException exception = new ServiceUnavailableException("Test");
        assertNotNull(exception);
        assertEquals("Test", exception.getMessage());
    }
}