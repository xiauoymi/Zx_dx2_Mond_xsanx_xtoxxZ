/*
 UserRoleServiceUT was created on Aug 22, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.usseedplanning.services.core.test;

import com.monsanto.wst.commonutils.testutils.TestUtils;
import com.monsanto.wst.usseedplanning.dao.mock.MockUserRoleDao;
import com.monsanto.wst.usseedplanning.constants.MainConstants;
import junit.framework.TestCase;

import java.util.ArrayList;

/**
 * Filename:    $RCSfile: UserRoleServiceUT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: njminsh $    	 On:	$Date: 2006-09-08 15:10:12 $
 *
 * @author ffbrac
 * @version $Revision: 1.4 $
 */
public class UserRoleServiceUT extends TestCase {
	public void setUp() throws Exception {
	    TestUtils testUtils = new TestUtils();
	    testUtils.setupLogging(MainConstants.APPLICATION_NAME);
	    super.setUp();
	}
	public void testGetUserRoleList(){
		MockUserRoleDao mockUserRoleDao = new MockUserRoleDao();
		ArrayList list = (ArrayList) mockUserRoleDao.getUserRoleList("FFBRAC");
		assertNotNull(list);
		assertEquals("FFBRAC", mockUserRoleDao.getUserId());
	}
}