package com.monsanto.wst.usseedplanning.services.cache;

import com.monsanto.wst.usseedplanning.dao.ProductDetailsDao;
import com.monsanto.wst.usseedplanning.dao.RevisionDao;
import com.monsanto.wst.usseedplanning.model.cache.ProductDetails;
import com.monsanto.wst.usseedplanning.model.core.LoginUser;
import com.monsanto.wst.usseedplanning.model.maintenance.Revision;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * Date: Feb 23, 2007
 * Time: 1:09:56 PM
 * <p/>
 * TODO: Enter description for class.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class ProductCachingServiceImpl implements ProductCachingService {
    private ProductDetailsDao productDetailsDao;
    private ProductLookupService productLookupService;
    private RevisionDao revisionDao;

    public ProductCachingServiceImpl(ProductDetailsDao productDetailsDao,
                                     ProductLookupService productLookupService, RevisionDao revisionDao) {
        this.productDetailsDao = productDetailsDao;
        this.productLookupService = productLookupService;
        this.revisionDao = revisionDao;
    }

    public List cacheSelectedProducts(List productCriteria, LoginUser currentUser) throws Exception {
      List productDetailList = new ArrayList();
      productDetailList = this.productLookupService.lookupProductDetailByCriteria(productCriteria);
      cacheProductDetailsList(currentUser, productDetailList);
      return productDetailList;
    }

    /**
     * This method caches the new product details records to the system.
     *
     * @param currentUser               LoginUser Object representing the current user.
     * @param productDetailsToCacheList List representing the new product detail records.
     */
    public void cacheProductDetailsList(LoginUser currentUser, List productDetailsToCacheList) {
      Revision revision = new Revision("Caching product details", "Caching product details for unknown products.",
        currentUser);
      this.revisionDao.insert(revision);
      for (int i = 0; i < productDetailsToCacheList.size(); i++) {
        ProductDetails productDetails = (ProductDetails) productDetailsToCacheList.get(i);
        productDetails.setRevision(revision);
        productDetails.setOwner(currentUser);
      }
      this.productDetailsDao.addProductDetails(productDetailsToCacheList);
    }

    public void addNewCacheEntry(String comments, LoginUser currentUser, ProductDetails productDetails) {
       Revision revision = new Revision("Add Manual Cache Record", comments, currentUser);
       revisionDao.insert(revision);
       productDetails.setRevision(revision);
       productDetails.setOwner(currentUser);
       productDetailsDao.addProductDetails(productDetails);
    }
}
