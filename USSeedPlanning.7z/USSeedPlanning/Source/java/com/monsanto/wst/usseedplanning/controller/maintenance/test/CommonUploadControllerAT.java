/*
 ForecastControllerAT was created on Nov 3, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.usseedplanning.controller.maintenance.test;

import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.wst.commonutils.reflection.ObjectInspector;
import com.monsanto.wst.commonutils.resources.ResourceUtils;
import com.monsanto.wst.factory.AbstractGenericFactory;
import com.monsanto.wst.factory.GenericFactory;
import com.monsanto.wst.servletframework.AbstractDispatchController;
import com.monsanto.wst.usseedplanning.constants.MainConstants;
import com.monsanto.wst.usseedplanning.model.core.LoginUser;
import com.monsanto.wst.usseedplanning.utils.testutils.USSeedPlanningBaseTransactionTestCase;
import com.monsanto.wst.usseedplanning.utils.testutils.USSeedPlanningTestUtils;
import com.monsanto.wst.validator.HttpRequestMessages;
import com.monsanto.wst.dbtemplate.transaction.TransactionManager;

import java.io.File;

/**
 * Filename:    $RCSfile: CommonUploadControllerAT.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: njminsh $    	 On:	$Date: 2007-02-10 16:30:21 $
 *
 * @author vrbethi
 * @version $Revision: 1.7 $
 */
public class CommonUploadControllerAT extends USSeedPlanningBaseTransactionTestCase {

  protected void setUp() throws Exception {
    USSeedPlanningTestUtils testUtils = new USSeedPlanningTestUtils(new ObjectInspector());
    testUtils.setupContainer();
    super.setUp();
  }

  protected String getConfigPath() {
    return "com/monsanto/wst/usseedplanning/dao/test/dbUnit/commonUploadDataSet.xml";
  }

  protected void cleanDatabase(TransactionManager txManager) {
    //To change body of implemented methods use File | Settings | File Templates.
  }

  public void testCommonUploadQAPercentageLoss_ShouldReturnSuccess() throws Exception {
    GenericFactory container = AbstractGenericFactory.getInstance();
    AbstractDispatchController commonUploadController=(AbstractDispatchController) container.getBean("/servlet/commonUpload.htm");
    MockUCCHelper helper = new MockUCCHelper(null);
    File file = new ResourceUtils().convertPathToFile("com/monsanto/wst/usseedplanning/services/mock/QA.xls");
    helper.addClientFile(file.getAbsolutePath());
    helper.setRequestParameterValue("method", "addCommonUpload");
    helper.setRequestParameterValue("comments", "addCommonUpload");
    helper.setRequestParameterValue("columnName", "qa_loss");
    helper.setRequestParameterValue("commonFile", "qa_loss");
    helper.setSessionParameter(MainConstants.LOGINUSER, new LoginUser("DBUNIT"));
    commonUploadController.run(helper);
    HttpRequestMessages httpRequestMessages = (HttpRequestMessages) helper.getRequestAttributeValue("messages");
    String message = (String) httpRequestMessages.getMessages().get(0);
    assertEquals("Common Upload Successfully Added.",message);

  }

  public void testCommonUploadSummerProduction_ShouldReturnSuccess() throws Exception {
    GenericFactory container = AbstractGenericFactory.getInstance();
    AbstractDispatchController commonUploadController=(AbstractDispatchController) container.getBean("/servlet/commonUpload.htm");
    MockUCCHelper helper = new MockUCCHelper(null);
    File file = new ResourceUtils().convertPathToFile("com/monsanto/wst/usseedplanning/services/mock/QA.xls");
    helper.addClientFile(file.getAbsolutePath());
    helper.setRequestParameterValue("method", "addCommonUpload");
    helper.setRequestParameterValue("comments", "addCommonUpload");
    helper.setRequestParameterValue("columnName", "summer_prod_plan");
    helper.setRequestParameterValue("commonFile", "summer_prod_plan");
    helper.setSessionParameter(MainConstants.LOGINUSER, new LoginUser("DBUNIT"));
    commonUploadController.run(helper);
    HttpRequestMessages httpRequestMessages = (HttpRequestMessages) helper.getRequestAttributeValue("messages");
    String message = (String) httpRequestMessages.getMessages().get(0);
    assertEquals("Common Upload Successfully Added.",message);

  }

  public void testCommonUploadWinterProduction_ShouldReturnSuccess() throws Exception {
    GenericFactory container = AbstractGenericFactory.getInstance();
    AbstractDispatchController commonUploadController=(AbstractDispatchController) container.getBean("/servlet/commonUpload.htm");
    MockUCCHelper helper = new MockUCCHelper(null);
    File file = new ResourceUtils().convertPathToFile("com/monsanto/wst/usseedplanning/services/mock/QA.xls");
    helper.addClientFile(file.getAbsolutePath());
    helper.setRequestParameterValue("method", "addCommonUpload");
    helper.setRequestParameterValue("comments", "addCommonUpload");
    helper.setRequestParameterValue("columnName", "winter_prod_plan");
    helper.setRequestParameterValue("commonFile", "winter_prod_plan");
    helper.setSessionParameter(MainConstants.LOGINUSER, new LoginUser("DBUNIT"));
    commonUploadController.run(helper);
    HttpRequestMessages httpRequestMessages = (HttpRequestMessages) helper.getRequestAttributeValue("messages");
    String message = (String) httpRequestMessages.getMessages().get(0);
    assertEquals("Common Upload Successfully Added.",message);

  }

  public void testCommonUploadWinterProductionActUS_ShouldReturnSuccess() throws Exception {
    GenericFactory container = AbstractGenericFactory.getInstance();
    AbstractDispatchController commonUploadController=(AbstractDispatchController) container.getBean("/servlet/commonUpload.htm");
    MockUCCHelper helper = new MockUCCHelper(null);
    File file = new ResourceUtils().convertPathToFile("com/monsanto/wst/usseedplanning/services/mock/QA.xls");
    helper.addClientFile(file.getAbsolutePath());
    helper.setRequestParameterValue("method", "addCommonUpload");
    helper.setRequestParameterValue("comments", "addCommonUpload");
    helper.setRequestParameterValue("columnName", "winter_prod_act_us");
    helper.setRequestParameterValue("commonFile", "winter_prod_act_us");
    helper.setSessionParameter(MainConstants.LOGINUSER, new LoginUser("DBUNIT"));
    commonUploadController.run(helper);
    HttpRequestMessages httpRequestMessages = (HttpRequestMessages) helper.getRequestAttributeValue("messages");
    String message = (String) httpRequestMessages.getMessages().get(0);
    assertEquals("Common Upload Successfully Added.",message);

  }

  public void testCommonUploadSummerProductionActUS_ShouldReturnSuccess() throws Exception {
    GenericFactory container = AbstractGenericFactory.getInstance();
    AbstractDispatchController commonUploadController=(AbstractDispatchController) container.getBean("/servlet/commonUpload.htm");
    MockUCCHelper helper = new MockUCCHelper(null);
    File file = new ResourceUtils().convertPathToFile("com/monsanto/wst/usseedplanning/services/mock/QA.xls");
    helper.addClientFile(file.getAbsolutePath());
    helper.setRequestParameterValue("method", "addCommonUpload");
    helper.setRequestParameterValue("comments", "addCommonUpload");
    helper.setRequestParameterValue("columnName", "summer_prod_act_us");
    helper.setRequestParameterValue("commonFile", "summer_prod_act_us");
    helper.setSessionParameter(MainConstants.LOGINUSER, new LoginUser("DBUNIT"));
    commonUploadController.run(helper);
    HttpRequestMessages httpRequestMessages = (HttpRequestMessages) helper.getRequestAttributeValue("messages");
    String message = (String) httpRequestMessages.getMessages().get(0);
    assertEquals("Common Upload Successfully Added.",message);

  }

  public void testCommonUploadSummerProductionActLic_ShouldReturnSuccess() throws Exception {
    GenericFactory container = AbstractGenericFactory.getInstance();
    AbstractDispatchController commonUploadController=(AbstractDispatchController) container.getBean("/servlet/commonUpload.htm");
    MockUCCHelper helper = new MockUCCHelper(null);
    File file = new ResourceUtils().convertPathToFile("com/monsanto/wst/usseedplanning/services/mock/QA.xls");
    helper.addClientFile(file.getAbsolutePath());
    helper.setRequestParameterValue("method", "addCommonUpload");
    helper.setRequestParameterValue("comments", "addCommonUpload");
    helper.setRequestParameterValue("columnName", "summer_prod");
    helper.setRequestParameterValue("commonFile", "summer_prod");
    helper.setSessionParameter(MainConstants.LOGINUSER, new LoginUser("DBUNIT"));
    commonUploadController.run(helper);
    HttpRequestMessages httpRequestMessages = (HttpRequestMessages) helper.getRequestAttributeValue("messages");
    String message = (String) httpRequestMessages.getMessages().get(0);
    assertEquals("Common Upload Successfully Added.",message);

  }

  public void testCommonUploadWinterProductionActLic_ShouldReturnSuccess() throws Exception {
    GenericFactory container = AbstractGenericFactory.getInstance();
    AbstractDispatchController commonUploadController=(AbstractDispatchController) container.getBean("/servlet/commonUpload.htm");
    MockUCCHelper helper = new MockUCCHelper(null);
    File file = new ResourceUtils().convertPathToFile("com/monsanto/wst/usseedplanning/services/mock/QA.xls");
    helper.addClientFile(file.getAbsolutePath());
    helper.setRequestParameterValue("method", "addCommonUpload");
    helper.setRequestParameterValue("comments", "addCommonUpload");
    helper.setRequestParameterValue("columnName", "winter_prod");
    helper.setRequestParameterValue("commonFile", "winter_prod");
    helper.setSessionParameter(MainConstants.LOGINUSER, new LoginUser("DBUNIT"));
    commonUploadController.run(helper);
    HttpRequestMessages httpRequestMessages = (HttpRequestMessages) helper.getRequestAttributeValue("messages");
    String message = (String) httpRequestMessages.getMessages().get(0);
    assertEquals("Common Upload Successfully Added.",message);

  }

}