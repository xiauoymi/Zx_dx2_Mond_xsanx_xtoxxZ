/*
 Copyright:  Copyright � 2006 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.usseedplanning.controller.maintenance.targetyield.test;

import junit.framework.TestCase;
import com.monsanto.wst.usseedplanning.controller.maintenance.targetyield.TargetYieldController;
import com.monsanto.wst.usseedplanning.controller.maintenance.targetyield.mock.MockYearServiceForTargetYieldController;
import com.monsanto.wst.usseedplanning.controller.maintenance.targetyield.mock.MockTargetYieldService;
import com.monsanto.wst.usseedplanning.constants.MainConstants;
import com.monsanto.wst.usseedplanning.model.maintenance.YieldTargetFactor;
import com.monsanto.wst.usseedplanning.model.maintenance.Gender;
import com.monsanto.wst.usseedplanning.services.maintenance.seedEntity.mock.MockGenderService;
import com.monsanto.wst.validator.HttpRequestErrors;
import com.monsanto.wst.validator.HttpRequestMessages;
import com.monsanto.ServletFramework.Test.MockUCCHelper;

import java.io.IOException;
import java.util.List;

/**
 * Filename:    $RCSfile: TargetYieldController_UT.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: ffbrac $    	 On:	$Date: 2006-10-27 18:26:20 $
 *
 * @author rdesai2
 * @version $Revision: 1.4 $
 */
public class TargetYieldController_UT extends TestCase {

  private TargetYieldController controller;
  private MockUCCHelper mockHelper;
  private MockTargetYieldService mockYieldTargetService;
  private MockGenderService mockGenderService;

  protected void setUp() throws IOException {
    mockHelper = new MockUCCHelper(null);
    mockHelper.setRequestParameterValue("method", "saveYieldTargetFactor");
    mockYieldTargetService = new MockTargetYieldService();
    mockGenderService = new MockGenderService();
    controller = new TargetYieldController(new MockYearServiceForTargetYieldController(), mockYieldTargetService, mockGenderService);
  }

  public void testSaveTargetYieldFactorForwardsCorrectly() throws Exception {
    controller.run(mockHelper);
    assertTrue(mockHelper.wasSentTo(MainConstants.FORWARD_ADD_EDIT_YIELD_TARGET_LIST_PAGE));
  }

  public void testYearListPopulated() throws Exception {
    controller.run(mockHelper);
    validateYearListPopulated();
    assertTrue(mockHelper.wasSentTo(MainConstants.FORWARD_ADD_EDIT_YIELD_TARGET_LIST_PAGE));
  }

  public void testGenderListPopulated() throws Exception {
    Gender gender = new Gender();
    gender.setId(new Long(12));
    mockGenderService.insert(gender);
    controller.run(mockHelper);
    validateGenderListPopulated();
    assertTrue(mockHelper.wasSentTo(MainConstants.FORWARD_ADD_EDIT_YIELD_TARGET_LIST_PAGE));
  }

  public void testSaveTargetYieldFactorSavesDataToDatabase() throws Exception {
    mockHelper.setRequestParameterValue(MainConstants.HELPER_PARAM_YIELD_TARGET_PG_PRODUCT_NAME, "saveProductName");
    mockHelper.setRequestParameterValue(MainConstants.HELPER_PARAM_YIELD_TARGET_PG_YEAR_ID_STRING, "12");
    mockHelper.setRequestParameterValue(MainConstants.HELPER_PARAM_YIELD_TARGET_PG_ACTIVE_STATUS, "N");
    mockHelper.setRequestParameterValue(MainConstants.HELPER_PARAM_YIELD_TARGET_PG_TARGET_YIELD_FACTOR, "110.7");
    mockHelper.setRequestParameterValue(MainConstants.HELPER_PARAM_YIELD_TARGET_PG_FINISHED_STAND_FACTOR, "106.2");
    mockHelper.setRequestParameterValue(MainConstants.HELPER_PARAM_YIELD_TARGET_PG_REVISION_COMMENT_FACTOR, "No Comments");
    controller.run(mockHelper);
    validateYearListPopulated();
    YieldTargetFactor savedYieldTargetFactor = mockYieldTargetService.getSavedYieldTargetFactor();
    assertNotNull(savedYieldTargetFactor);
    assertEquals("saveProductName", savedYieldTargetFactor.getProductName());
    HttpRequestMessages messages = (HttpRequestMessages) mockHelper.getRequestAttributeValue("messages");
    assertNotNull(messages);
    assertEquals(1, messages.getMessages().size());
    assertEquals(MainConstants.SUCCESS_MSG_YIELD_TARGET_FACTOR_SAVED, messages.getMessages().get(0));
    assertEquals("true", mockHelper.getRequestAttributeValue(MainConstants.HELPER_TARGET_YIELD_EDIT_ACTION_FLAG));
    assertTrue(mockHelper.wasSentTo(MainConstants.FORWARD_YIELD_TARGET_LIST_PAGE));
  }

  public void testYieldTargetObjectRepopulatedToAddEditPage() throws Exception {
    mockHelper.setRequestParameterValue(MainConstants.HELPER_PARAM_YIELD_TARGET_PG_PRODUCT_NAME, "saveProductName");
    mockHelper.setRequestParameterValue(MainConstants.HELPER_PARAM_YIELD_TARGET_PG_YEAR_ID_STRING, "12");
    mockHelper.setRequestParameterValue(MainConstants.HELPER_PARAM_YIELD_TARGET_PG_ACTIVE_STATUS, "N");
    mockHelper.setRequestParameterValue(MainConstants.HELPER_PARAM_YIELD_TARGET_PG_TARGET_YIELD_FACTOR, "110.7");
    mockHelper.setRequestParameterValue(MainConstants.HELPER_PARAM_YIELD_TARGET_PG_FINISHED_STAND_FACTOR, "106.2");
    mockHelper.setRequestParameterValue(MainConstants.HELPER_PARAM_YIELD_TARGET_PG_REVISION_COMMENT_FACTOR, "No Comments");
    controller.run(mockHelper);
    YieldTargetFactor factor = (YieldTargetFactor) mockHelper.getRequestAttributeValue(MainConstants.HELPER_PARAM_YIELD_TARGET_FACTOR);
    assertNotNull(factor);
    assertEquals("No Comments", factor.getRevision().getComment());
    validateYearListPopulated();
    YieldTargetFactor savedYieldTargetFactor = mockYieldTargetService.getSavedYieldTargetFactor();
    assertNotNull(savedYieldTargetFactor);
    assertEquals("saveProductName", savedYieldTargetFactor.getProductName());
    HttpRequestMessages messages = (HttpRequestMessages) mockHelper.getRequestAttributeValue("messages");
    assertNotNull(messages);
    assertEquals(1, messages.getMessages().size());
    assertEquals(MainConstants.SUCCESS_MSG_YIELD_TARGET_FACTOR_SAVED, messages.getMessages().get(0));
    assertTrue(mockHelper.wasSentTo(MainConstants.FORWARD_YIELD_TARGET_LIST_PAGE));
  }

  public void testErrorMessagePopulatedIfRequiredFieldsHaveInvalidValues() throws Exception {
    mockHelper.setRequestParameterValue(MainConstants.HELPER_PARAM_YIELD_TARGET_PG_PRODUCT_NAME, "saveProductName");
    mockHelper.setRequestParameterValue(MainConstants.HELPER_PARAM_YIELD_TARGET_PG_YEAR_ID_STRING, "12");
    mockHelper.setRequestParameterValue(MainConstants.HELPER_PARAM_YIELD_TARGET_PG_ACTIVE_STATUS, "N");
    mockHelper.setRequestParameterValue(MainConstants.HELPER_PARAM_YIELD_TARGET_PG_TARGET_YIELD_FACTOR, "text");
    mockHelper.setRequestParameterValue(MainConstants.HELPER_PARAM_YIELD_TARGET_PG_FINISHED_STAND_FACTOR, "77someText88");
    mockHelper.setRequestParameterValue(MainConstants.HELPER_PARAM_YIELD_TARGET_PG_REVISION_COMMENT_FACTOR, "No Comments");
    controller.run(mockHelper);
    validateYearListPopulated();
    HttpRequestErrors httpRequestErrors = (HttpRequestErrors) mockHelper.getRequestAttributeValue("errors");
    assertNotNull(httpRequestErrors);
    assertEquals(2, httpRequestErrors.getErrors().size());
    assertEquals(MainConstants.ERROR_MSG_TARGET_YIELD_FACTOR_NOT_NUMBER, httpRequestErrors.getErrors().get(MainConstants.ERROR_KEY_TARGET_YIELD_FACTOR_NOT_NUMBER));
    assertEquals(MainConstants.ERROR_MSG_FINANCE_STAND_FACTOR_NOT_NUMBER, httpRequestErrors.getErrors().get(MainConstants.ERROR_KEY_FINANCE_STAND_FACTOR_NOT_NUMBER));
    assertTrue(mockHelper.wasSentTo(MainConstants.FORWARD_ADD_EDIT_YIELD_TARGET_LIST_PAGE));
  }

  public void testErrorMessagePopulatedIfRequiredFieldsAreNull() throws Exception {
    mockHelper.setRequestParameterValue(MainConstants.HELPER_PARAM_YIELD_TARGET_PG_PRODUCT_NAME, "saveProductName");
    mockHelper.setRequestParameterValue(MainConstants.HELPER_PARAM_YIELD_TARGET_PG_YEAR_ID_STRING, "12");
    mockHelper.setRequestParameterValue(MainConstants.HELPER_PARAM_YIELD_TARGET_PG_ACTIVE_STATUS, "N");
    mockHelper.setRequestParameterValue(MainConstants.HELPER_PARAM_YIELD_TARGET_PG_FINISHED_STAND_FACTOR, "");
    mockHelper.setRequestParameterValue(MainConstants.HELPER_PARAM_YIELD_TARGET_PG_REVISION_COMMENT_FACTOR, "No Comments");
    controller.run(mockHelper);
    validateYearListPopulated();
    HttpRequestErrors httpRequestErrors = (HttpRequestErrors) mockHelper.getRequestAttributeValue("errors");
    assertNotNull(httpRequestErrors);
    assertEquals(2, httpRequestErrors.getErrors().size());
    assertEquals(MainConstants.ERROR_MSG_TARGET_YIELD_FACTOR_EMPTY, httpRequestErrors.getErrors().get(MainConstants.ERROR_KEY_TARGET_YIELD_FACTOR_EMPTY));
    assertEquals(MainConstants.ERROR_MSG_FINANCE_STAND_FACTOR_EMPTY, httpRequestErrors.getErrors().get(MainConstants.ERROR_KEY_FINANCE_STAND_FACTOR_EMPTY));
    assertTrue(mockHelper.wasSentTo(MainConstants.FORWARD_ADD_EDIT_YIELD_TARGET_LIST_PAGE));
  }

  private void validateYearListPopulated() {
    List yearList = ((List) mockHelper.getRequestAttributeValue(MainConstants.HELPER_PARAM_YEAR_LOOKUP_LIST));
    assertNotNull(yearList);
    assertEquals(1, yearList.size());
    assertEquals("1997", yearList.get(0));
  }

  private void validateGenderListPopulated() {
    List genderList = ((List) mockHelper.getRequestAttributeValue(MainConstants.HELPER_PARAM_GENDER_LOOKUP_LIST));
    assertNotNull(genderList);
    assertEquals(1, genderList.size());
    assertEquals(new Long(12), ((Gender)genderList.get(0)).getId());
  }

}