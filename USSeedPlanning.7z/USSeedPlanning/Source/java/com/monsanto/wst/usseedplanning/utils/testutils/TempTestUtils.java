package com.monsanto.wst.usseedplanning.utils.testutils;

import com.monsanto.wst.commonutils.reflection.ObjectInspector;
import com.monsanto.wst.factory.AbstractGenericFactory;

/**
 * Created by IntelliJ IDEA.
 * Date: Feb 11, 2007
 * Time: 7:10:15 PM
 * <p/>
 * TODO: Enter description for class.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class TempTestUtils extends USSeedPlanningTestUtils {
    /**
     * This constructor takes all dependencies.
     *
     * @param objectInspector ObjectInspector object for inspecting objects.
     */
    public TempTestUtils(ObjectInspector objectInspector) {
        super(objectInspector);
    }

    /**
     * This method sets up the application container for integration/acceptance tests that use the container.
     */
    public void setupContainer() throws ClassNotFoundException {
        AbstractGenericFactory.clear();
        AbstractGenericFactory.setImplementation("com.monsanto.wst.factory.DelegatingLocatorGenericFactory");
        AbstractGenericFactory.addCustomFactory("com.monsanto.wst.usseedplanning.container.DaoFactory");
        AbstractGenericFactory.addCustomFactory("com.monsanto.wst.usseedplanning.container.ServiceFactory");
        AbstractGenericFactory.addCustomFactory("com.monsanto.wst.usseedplanning.container.ValidatorFactory");
        AbstractGenericFactory.addCustomFactory("com.monsanto.wst.usseedplanning.container.ControllerFactory");
    }
}
