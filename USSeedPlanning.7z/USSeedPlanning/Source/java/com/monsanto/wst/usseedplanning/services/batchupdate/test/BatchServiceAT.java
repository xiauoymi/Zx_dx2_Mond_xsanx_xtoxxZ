/*
BatchServiceAT was created on Dec 5, 2006 using Monsanto
resources and is the sole property of Monsanto.  Any duplication of the
code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.usseedplanning.services.batchupdate.test;

import com.monsanto.wst.usseedplanning.utils.testutils.USSeedPlanningBaseTransactionTestCase;
import com.monsanto.wst.dbtemplate.transaction.TransactionManager;

/**
 * Filename:    $RCSfile: BatchServiceAT.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: njminsh $    	 On:	$Date: 2007-02-10 16:30:22 $
 *
 * @author vrbethi
 * @version $Revision: 1.7 $
 */
public class BatchServiceAT extends USSeedPlanningBaseTransactionTestCase {

    //TODO Figure out a way how to test this
    public void testBatchService() throws Exception {
//        BatchService batchService = (BatchService) AbstractGenericFactory.getInstance().getBean("batchService");
//        TransactionManager transactionManager = (TransactionManager) AbstractGenericFactory.getInstance().getBean("transactionManager");
//        batchService.setLoginUser(new LoginUser("BATCH","BATCH"));
//        boolean isRun = batchService.runBatch();
//        BatchSummary batchSummary = batchService.getBatchSummary();
//        assertTrue(isRun);
//        assertEquals(3,batchSummary.getNumberOfAddedOrModifiedProducts());
//        assertEquals(0,batchSummary.getNumberOfDeletedProducts());
//
//        DBTemplate template = (DBTemplate) AbstractGenericFactory.getInstance().getBean("dbTemplate");
//        template.executeDelete("deleteAllTempCommercialProduct", null);
//        template.executeDelete("deleteAllTempProductDetails", null);
//
//        BatchService mockBatchService = (BatchService) AbstractGenericFactory.getInstance().getBean("mockBatchService");
//        mockBatchService.setLoginUser(new LoginUser("BATCH","BATCH"));
//        boolean mockIsRun = mockBatchService.runBatch();
//        BatchSummary mockBatchSummary = mockBatchService.getBatchSummary();
//        assertTrue(mockIsRun);
//        assertEquals(1,mockBatchSummary.getNumberOfAddedOrModifiedProducts());
//        assertEquals(3,mockBatchSummary.getNumberOfDeletedProducts());
        //TODO this test works But need to figure out a lexicon product for this test in dev
        assertTrue(true);
    }

    protected String getConfigPath() {
        return "com/monsanto/wst/usseedplanning/dao/test/dbUnit/batch.xml";
    }

    protected void cleanDatabase(TransactionManager txManager) {
//        DBTemplate template = (DBTemplate) AbstractGenericFactory.getInstance().getBean("dbTemplate");
//        template.executeDelete("deleteAllCommercialProduct", null);
//        template.executeDelete("deleteAllProductDetails", null);
//        template.executeDelete("deleteAllSupply", null);
//        template.executeDelete("deleteAllDemand", null);
    }
}