package com.monsanto.wst.usseedplanning.controller.core;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.ServletFramework.UseCaseController;
import com.monsanto.wst.usseedplanning.constants.MainConstants;
import com.monsanto.wst.usseedplanning.view.factory.ViewFactory;
import com.monsanto.wst.view.View;

import java.io.IOException;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Aug 11, 2006
 * Time: 10:54:41 AM
 * To change this template use File | Settings | File Templates.
 */
public class CancelActionController implements UseCaseController {

    private ViewFactory viewFactory;
    private View view = null;

    public CancelActionController(ViewFactory viewFactory) {
        this.viewFactory = viewFactory;
    }

    public void run(UCCHelper helper) throws IOException {
        if (helper.getRequestParameterValue(MainConstants.TYPE).equalsIgnoreCase(MainConstants.YIELD_TARGET)){
            view = viewFactory.getAllYieldTargetsView();
        }
        if (helper.getRequestParameterValue(MainConstants.TYPE).equalsIgnoreCase(MainConstants.OBS_FACTOR)){
            view = viewFactory.getAllObsFactorsView();
        }
        if (helper.getRequestParameterValue(MainConstants.TYPE).equalsIgnoreCase(MainConstants.QA_THRESHOLD)){
            view = viewFactory.getAllQAThresholdView();
        }
        view.renderView(helper);
    }
}
