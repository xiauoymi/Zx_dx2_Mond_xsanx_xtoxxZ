package com.monsanto.wst.usseedplanning.controller.core.test;

import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.wst.usseedplanning.controller.core.AdminController;
import com.monsanto.wst.usseedplanning.services.core.mock.MockLogReaderService;
import com.monsanto.wst.usseedplanning.utils.testutils.USSeedPlanningBaseTestCase;
import com.monsanto.wst.usseedplanning.view.factory.ViewFactory;
import com.monsanto.wst.usseedplanning.view.factory.mock.MockViewFactory;
import com.monsanto.wst.view.test.mock.MockView;

/**
 * Created by IntelliJ IDEA.
 * Date: Apr 7, 2006
 * Time: 12:54:56 PM
 * <p/>
 * This class is a junit test case for the AdminController object.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class AdminControllerUT extends USSeedPlanningBaseTestCase {
    public void testCreate() throws Exception {
        AdminController controller = new AdminController((ViewFactory) null, (MockLogReaderService) null);
        assertNotNull(controller);
    }

    public void testNotSpecifiedHasNoResponse() throws Exception {
        AdminController controller = new AdminController((ViewFactory) null, (MockLogReaderService) null);
        MockUCCHelper helper = new MockUCCHelper(null);
        controller.run(helper);
        assertNull(helper.getResponse());
    }

    public void testLookupLogFileList() throws Exception {
        MockViewFactory viewFactory = new MockViewFactory();
        MockLogReaderService logReaderService = new MockLogReaderService();
        AdminController controller = new AdminController(viewFactory, logReaderService);
        MockUCCHelper helper = new MockUCCHelper(null);
        helper.setRequestParameterValue("method", "lookupLogFileList");
        helper.setRequestParameterValue("view", "mock");
        controller.run(helper);
        MockView view = (MockView) viewFactory.getLogFileListView();
        assertTrue(view.wasViewRendered());
    }

    public void testLookupLogFile() throws Exception {
        MockViewFactory viewFactory = new MockViewFactory();
        MockLogReaderService logReaderService = new MockLogReaderService();
        AdminController controller = new AdminController(viewFactory, logReaderService);
        MockUCCHelper helper = new MockUCCHelper(null);
        helper.setRequestParameterValue("method", "lookupLogFile");
        helper.setRequestParameterValue("view", "mock");
        helper.setRequestParameterValue("logFileName", "test.log");
        controller.run(helper);
        MockView view = (MockView) viewFactory.getLogFileView();
        assertTrue(view.wasViewRendered());
        assertEquals("test.log", logReaderService.getFileName());
    }
}
