/*
 ProductTypeComparator was created on Oct 1, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.usseedplanning.services.planning;

import com.monsanto.wst.usseedplanning.model.cache.ProductCriteria;
import com.monsanto.wst.usseedplanning.model.maintenance.NameType;

import java.util.Comparator;

/**
 * Filename:    $RCSfile: ProductTypeComparator.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: njminsh $    	 On:	$Date: 2007-01-31 21:55:34 $
 *
 * @author VRBETHI
 * @version $Revision: 1.3 $
 */
public class ProductTypeComparator implements Comparator {

  private static final int OBJECT_1_MOVES_UP = -1;
  private static final int OBJECT_2_MOVES_UP = 1;
  private static final int BOTH_OBJECTS_ARE_EQUAL = 0;

  /**
   * This utility sorts the ProductCriteria List by grouping the Commercial-NameTypes first, then the PreCommercial-NameTypes
   * and then the Manufacturing-NameTypes.
   * @param o1
   * @param o2
   * @return int
   */
  public int compare(Object o1, Object o2) {
    if(o1 == null){
      return OBJECT_2_MOVES_UP;
    }
    if(o2 == null){
      return OBJECT_1_MOVES_UP;
    }
    if(o1 == null || o2 == null){
      return BOTH_OBJECTS_ARE_EQUAL;
    }
    ProductCriteria pc1 = null;
    try {
      pc1 = (ProductCriteria)o1;
    } catch (ClassCastException e) {
      return OBJECT_2_MOVES_UP;
    }
    ProductCriteria pc2 = null;
    try {
      pc2 = (ProductCriteria)o2;
    } catch (ClassCastException e) {
      return OBJECT_1_MOVES_UP;
    }
    NameType nameType1 = pc1.getNameType();
    NameType nameType2 = pc2.getNameType();
    if(nameType1 == null){
      return OBJECT_2_MOVES_UP;
    }
    if(nameType2 == null){
      return OBJECT_1_MOVES_UP;
    }
    if(nameType1 == null || nameType2 == null){
      return BOTH_OBJECTS_ARE_EQUAL;
    }
    String nameTypeString1 = nameType1.getNameType();
    String nameTypeString2 = nameType2.getNameType();
    if(nameTypeString1 == null){
      return OBJECT_2_MOVES_UP;
    }
    if(nameTypeString2 == null){
      return OBJECT_1_MOVES_UP;
    }
    if(nameTypeString1 == null || nameTypeString2 == null){
      return BOTH_OBJECTS_ARE_EQUAL;
    }
    if(nameTypeString1.equalsIgnoreCase(NameType.COMMERCIAL)){
      return OBJECT_1_MOVES_UP;
    }
    if(nameTypeString2.equalsIgnoreCase(NameType.COMMERCIAL)){
      return OBJECT_2_MOVES_UP;
    }
    if(nameTypeString1.equalsIgnoreCase(NameType.PRECOMMERCIAL)){
      return OBJECT_1_MOVES_UP;
    }
    if(nameTypeString2.equalsIgnoreCase(NameType.PRECOMMERCIAL)){
      return OBJECT_2_MOVES_UP;
    }
    return BOTH_OBJECTS_ARE_EQUAL;
  }
}