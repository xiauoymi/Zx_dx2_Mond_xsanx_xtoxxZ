/*
 StageServiceImpl was created on Sep 18, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.usseedplanning.services.maintenance.seedEntity.dbServices;

import com.monsanto.wst.usseedplanning.dao.StageDao;
import com.monsanto.wst.usseedplanning.services.maintenance.seedEntity.StageService;
import com.monsanto.wst.usseedplanning.model.maintenance.Stage;
import com.monsanto.wst.usseedplanning.exception.NoResultsException;
import com.monsanto.wst.dbtemplate.dao.DBTemplateNoResultsException;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.AbstractLogging.DebugLogEvent;

import java.util.List;

/**
 * Filename:    $RCSfile: StageServiceImpl.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: SSPATI1 $    	 On:	$Date: 2006-09-19 21:13:35 $
 *
 * @author sspati1
 * @version $Revision: 1.2 $
 */
public class StageServiceImpl implements StageService {
  private StageDao stageDao;

  public StageServiceImpl(StageDao stageDao) {
    this.stageDao = stageDao;
  }

  public List lookupAllStages() {
    return this.stageDao.lookupAllStages();
  }

  public Stage lookupStageById(Long stageId) {
    Stage stage = null;
    try {
      stage =  this.stageDao.lookupById(stageId);
    } catch (NoResultsException e) {
        if (Logger.isEnabled(Logger.DEBUG_LOG)) {
           Logger.log(new DebugLogEvent("Unable to find stage with id '" + stageId + "'."));
        }
     } catch (DBTemplateNoResultsException e) {
        if (Logger.isEnabled(Logger.DEBUG_LOG)) {
           Logger.log(new DebugLogEvent("Unable to find stage with id '" + stageId + "'."));
        }
   }
    return stage;
  }
}