/*
 StageFactorController was created on Sep 18, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.usseedplanning.controller.maintenance.seedEntity;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.wst.commonutils.DataTypeUtil;
import com.monsanto.wst.servletframework.AbstractDispatchController;
import com.monsanto.wst.usseedplanning.constants.MainConstants;
import com.monsanto.wst.usseedplanning.model.core.LoginUser;
import com.monsanto.wst.usseedplanning.model.maintenance.Revision;
import com.monsanto.wst.usseedplanning.model.maintenance.Stage;
import com.monsanto.wst.usseedplanning.model.maintenance.StageFactor;
import com.monsanto.wst.usseedplanning.model.maintenance.Year;
import com.monsanto.wst.usseedplanning.services.maintenance.seedEntity.StageFactorService;
import com.monsanto.wst.usseedplanning.services.maintenance.seedEntity.StageService;
import com.monsanto.wst.usseedplanning.services.maintenance.seedEntity.YearService;
import com.monsanto.wst.usseedplanning.view.factory.ViewFactory;
import com.monsanto.wst.validator.HttpRequestErrors;
import com.monsanto.wst.validator.HttpRequestMessages;
import com.monsanto.wst.validator.HttpValidator;
import com.monsanto.wst.view.View;
import org.apache.commons.lang.StringUtils;

import java.io.IOException;
import java.util.List;

/**
 * Filename:    $RCSfile: StageFactorController.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: njminsh $
 * On:	$Date: 2007-02-13 19:21:05 $
 *
 * @author sspati1
 * @version $Revision: 1.12 $
 */
public class StageFactorController extends AbstractDispatchController {

    private StageFactorService stageFactorService;
    private YearService yearService;
    private StageService stageService;
    private ViewFactory viewFactory;
    private HttpValidator saveStageFactorValidator;
    private DataTypeUtil dataTypeUtil = new DataTypeUtil();

    public StageFactorController(StageFactorService stageFactorService, YearService yearService,
                                 StageService stageService,
                                 ViewFactory viewFactory, HttpValidator saveStageFactorValidator) {
        this.stageFactorService = stageFactorService;
        this.yearService = yearService;
        this.stageService = stageService;
        this.viewFactory = viewFactory;
        this.saveStageFactorValidator = saveStageFactorValidator;
    }

    /**
     * This method is called when no method is specified.
     *
     * @param helper
     *
     * @exception IOException
     */
    protected void notSpecified(UCCHelper helper) throws IOException {
        listStageFactors(helper);
    }

    /**
     * This method returns a list of stage factors with specified search criteria in the request.
     *
     * @param helper
     *
     * @exception IOException
     */
    public void listStageFactors(UCCHelper helper) throws IOException {
        List stageFactorsList = getStageFactors(helper);
        List yearList = this.yearService.getActiveYears();
        List stageList = stageService.lookupAllStages();
        helper.setRequestAttributeValue("stageFactorsList", stageFactorsList);
        helper.setRequestAttributeValue("yearList", yearList);
        helper.setRequestAttributeValue("stageList", stageList);
        View view = this.viewFactory.getListStageFactorsView();
        view.renderView(helper);
    }

    /**
     * This method creates and saves stage factors
     *
     * @param helper
     *
     * @exception IOException
     */
    public void saveStageFactor(UCCHelper helper) throws IOException {
        String productName = helper.getRequestParameterValue("productName");
        String yearId = helper.getRequestParameterValue("yearId");
        String stageId = helper.getRequestParameterValue("stageId");
        Boolean status = dataTypeUtil.convertYNStringIntoBoolean(helper.getRequestParameterValue("status"));
        String factor = helper.getRequestParameterValue("factor");
        String comments = helper.getRequestParameterValue("comments");
        String revisionId = helper.getRequestParameterValue("revisionId");
        List yearList = this.yearService.getActiveYears();
        List stageList = this.stageService.lookupAllStages();
        StageFactor stageFactor = null;
        View view = null;
        HttpRequestErrors errors = this.saveStageFactorValidator.validate(helper);
        stageFactor = createStageFactor(productName, yearId, stageId, revisionId, status, helper);

        if (errors.isEmpty()) {
            stageFactor.setFactor(new Long(factor));
            this.stageFactorService.saveStageFactor(stageFactor, comments);
            stageFactor = null;
            HttpRequestMessages messages = new HttpRequestMessages();
            messages.addMessage("Stage Factor Successfully saved.");
            helper.setRequestAttributeValue("stageFactor", stageFactor);
            helper.setRequestAttributeValue("yearList", yearList);
            helper.setRequestAttributeValue("stageList",stageList);
            helper.setRequestAttributeValue("messages", messages);
            helper.setRequestAttributeValue("method", "listStageFactors");
            view = this.viewFactory.getListStageFactorsView();
            view.renderView(helper);
        } else {
            helper.setRequestAttributeValue("stageFactor", stageFactor);
            helper.setRequestAttributeValue("yearList", yearList);
            helper.setRequestAttributeValue("stageList", stageList);
            helper.setRequestAttributeValue("errors", errors);
            view = this.viewFactory.getDisplayStageFactorView();
            view.renderView(helper);
        }
    }

    private StageFactor createStageFactor(String productName, String yearId, String stageId, String revisionId,
                                          Boolean status, UCCHelper helper) {
        StageFactor stageFactor;
        stageFactor = new StageFactor();
        stageFactor.setProductName(productName);
        if (!StringUtils.isEmpty(yearId)) {
            setYear(yearId, stageFactor);
        }
        if (!StringUtils.isEmpty(stageId)) {
            setStage(stageId, stageFactor);
        }
        if (revisionId != null) {
            Revision revision = new Revision();
            revision.setId(new Long(revisionId));
            stageFactor.setRevision(revision);
        }
        stageFactor.setActiveStatus(status);
        stageFactor.setLoginUser((LoginUser) helper.getSessionParameter(MainConstants.LOGINUSER));
        return stageFactor;
    }

    /**
     * This method set a stage factor in request with specified revision Id
     *
     * @param helper
     *
     * @exception IOException
     */
    public void retrieveStageFactor(UCCHelper helper) throws IOException {
        StageFactor stageFactor = null;
        String revisionId = helper.getRequestParameterValue("revisionId");
        if (StringUtils.isNotEmpty(revisionId)) {
            stageFactor = this.stageFactorService.lookupStageFactorsByRevisionId(new Long(revisionId));
            stageFactor.setStage(this.stageService.lookupStageById(stageFactor.getStage().getStageId()));
        }
        List yearList = this.yearService.getActiveYears();
        List stageList = this.stageService.lookupAllStages();
        helper.setRequestAttributeValue("stageFactor", stageFactor);
        helper.setRequestAttributeValue("yearList", yearList);
        helper.setRequestAttributeValue("stageList", stageList);
        View view = this.viewFactory.getDisplayStageFactorView();
        view.renderView(helper);
    }

    private List getStageFactors(UCCHelper helper) throws IOException {
        String productName = getInitializedRequestParameter(helper.getRequestParameterValue("productName"));
        String yearId = getInitializedRequestParameter(helper.getRequestParameterValue("yearId"));
        String stageId = getInitializedRequestParameter(helper.getRequestParameterValue("stageIdField"));
        Long longYearId = dataTypeUtil.convertStringToLongIgnoreNumberFormatException(yearId);
        Long longStageId = dataTypeUtil.convertStringToLongIgnoreNumberFormatException(stageId);
        return stageFactorService
            .getAllApplicableStageFactorsInOrderOfPrecedence(productName, longYearId, longStageId, null);

    }

    private void setYear(String yearId, StageFactor stageFactor) {
        Year year = new Year();
        year.setId(new Long(yearId));
        stageFactor.setYear(year);
    }

    private void setStage(String stageId, StageFactor stageFactor) {
        Stage stage = new Stage();
        stage.setStageId(new Long(stageId));
        stageFactor.setStage(stage);
    }
    private String getInitializedRequestParameter(String paramName){
        if(paramName == null)	paramName = "";

        return paramName;
    }
}