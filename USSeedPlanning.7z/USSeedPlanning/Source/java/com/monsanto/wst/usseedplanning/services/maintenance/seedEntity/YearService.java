/*
 Copyright:  Copyright � 2006 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.usseedplanning.services.maintenance.seedEntity;

import com.monsanto.wst.usseedplanning.model.maintenance.Year;

import java.util.List;

/**
 * Filename:    $RCSfile: YearService.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ffbrac $    	 On:	$Date: 2006-10-03 13:55:16 $
 *
 * @author jdpoul
 * @version $Revision: 1.3 $
 */
public interface YearService {

	public List getActiveYears();

	/***
	 * This method returns a YEar with specified id
	 * @param yearId
	 * @return
	 */
	public Year lookupYearById(Long yearId);

	public Year lookupCurrentYear();


}