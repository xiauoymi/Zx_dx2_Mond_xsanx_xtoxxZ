/*
 StageServiceUt was created on Sep 18, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.usseedplanning.services.maintenance.seedEntity.dbServices.test;

import junit.framework.TestCase;
import com.monsanto.wst.usseedplanning.dao.StageDao;
import com.monsanto.wst.usseedplanning.dao.mock.MockStageDao;
import com.monsanto.wst.usseedplanning.services.maintenance.seedEntity.dbServices.StageServiceImpl;

/**
 * Filename:    $RCSfile: StageServiceImplUT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: SSPATI1 $    	 On:	$Date: 2006-09-19 21:13:35 $
 *
 * @author sspati1
 * @version $Revision: 1.2 $
 */
public class StageServiceImplUT extends TestCase{

  public void testCreate() throws Exception {
    StageServiceImpl stageService = new StageServiceImpl((StageDao) null);
    assertNotNull(stageService);
  }
  
  public void testLookupAllStages() throws Exception {
    MockStageDao dao = new MockStageDao();
    StageServiceImpl stageService = new StageServiceImpl(dao);
    assertEquals(2, dao.lookupAllStages().size());
  }

  public void testLookStageById() throws Exception {
    MockStageDao dao = new MockStageDao();
    StageServiceImpl stageService = new StageServiceImpl(dao);
    assertNotNull(dao.lookupById(new Long(123)));
  }

}