/*
 Copyright:  Copyright � 2006 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.usseedplanning.controller.maintenance.targetyield.mock;

import com.monsanto.Util.StringUtils;
import com.monsanto.wst.usseedplanning.model.maintenance.Year;
import com.monsanto.wst.usseedplanning.model.maintenance.YieldTargetFactor;
import com.monsanto.wst.usseedplanning.services.maintenance.seedEntity.YieldTargetService;

import java.util.ArrayList;
import java.util.List;

/**
 * Filename:    $RCSfile: MockTargetYieldService.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $
 * On:	$Date: 2006-12-01 20:25:04 $
 *
 * @author rdesai2
 * @version $Revision: 1.8 $
 */
public class MockTargetYieldService implements YieldTargetService {

  private YieldTargetFactor savedYieldTargetFactor = null;

  public void saveYieldTargetFactor(YieldTargetFactor yieldTargetFactor) {
    this.savedYieldTargetFactor = yieldTargetFactor;
  }

  public YieldTargetFactor getSavedYieldTargetFactor() {
    return savedYieldTargetFactor;
  }

  public YieldTargetFactor getYieldTargetByRevisionId(String revisionId) {
    if (!StringUtils.isNullOrEmpty(revisionId) && revisionId.equalsIgnoreCase("23")) {
      return new YieldTargetFactor("editProductName", null, null, new Double(12).floatValue());
    }
    return null;
  }

  public YieldTargetFactor getMostAppropriateYieldTargetFactor(String productNameCriteria, Long yearCriteria,
                                                               Long genderCriteria, Long maxRevisionId) {
    return null;
  }

  public List getAllApplicableYieldTargetFactorsInOrderOfPrecedence(String productNameCriteria, Long yearCriteria,
                                                                    Long genderCriteria, Long maxRevisionId) {
    ArrayList yieldTargetFactorList = new ArrayList();
    YieldTargetFactor factor = new YieldTargetFactor();
    factor.setProductName(productNameCriteria);
    Year targetYear = new Year();
    targetYear.setId(yearCriteria);
    factor.setTargetYear(targetYear);
    factor.setActiveStatus(Boolean.TRUE);
    yieldTargetFactorList.add(factor);
    return yieldTargetFactorList;
  }
}