/*
RevisionServiceUT was created on Nov 3, 2006 using Monsanto
resources and is the sole property of Monsanto.  Any duplication of the
code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.usseedplanning.services.core.test;

import junit.framework.TestCase;
import com.monsanto.wst.usseedplanning.services.core.LatestRevisionService;
import com.monsanto.wst.usseedplanning.services.core.LatestRevisionServiceImpl;
import com.monsanto.wst.usseedplanning.dao.RevisionDao;
import com.monsanto.wst.usseedplanning.dao.mock.MockRevisionDao;
import com.monsanto.wst.usseedplanning.model.maintenance.Revision;

/**
 * Filename:    $RCSfile: RevisionServiceUT.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: vrbethi $    	 On:	$Date: 2006-11-04 18:30:33 $
 *
 * @author vrbethi
 * @version $Revision: 1.2 $
 */
public class RevisionServiceUT  extends TestCase{

    public void testCreatePlanService() throws Exception {
        LatestRevisionService latestRevisionService = new LatestRevisionServiceImpl((RevisionDao)null);
        assertNotNull(latestRevisionService);
    }

    public void testGetLatestRevision() throws Exception {
        LatestRevisionService latestRevisionService = new LatestRevisionServiceImpl(new MockRevisionDao());
        Revision revision =latestRevisionService.getLatestRevision();
        assertNull(revision);

    }
}