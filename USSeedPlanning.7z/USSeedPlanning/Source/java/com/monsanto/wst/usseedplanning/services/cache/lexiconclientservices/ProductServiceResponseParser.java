/*
 ProductServiceResponseParser was created on Sep 26, 2006 using Monsanto
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.usseedplanning.services.cache.lexiconclientservices;

import java.io.InputStream;
import java.util.List;

/**
 * Filename:    $RCSfile: ProductServiceResponseParser.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: njminsh $    	 On:	$Date: 2007-01-31 22:39:38 $
 *
 * @author VRBETHI
 * @version $Revision: 1.1 $
 */
public interface ProductServiceResponseParser {

  List getProductDetailsListFromProductParentsByPrecommercialNameServiceResponse(InputStream responseInputStream) throws Exception;

  List getProductDetailsListFromProductParentsByManufacturingNameServiceResponse(InputStream responseInputStream) throws Exception;

  String getPreCommercialNameFromGetAggregateProductServiceResponse(InputStream responseInputStream) throws Exception;
}