/*
 Copyright:  Copyright � 2006 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.usseedplanning.controller.maintenance.targetyield;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.Util.StringUtils;
import com.monsanto.wst.commonutils.DataTypeUtil;
import com.monsanto.wst.servletframework.AbstractDispatchController;
import com.monsanto.wst.usseedplanning.constants.MainConstants;
import com.monsanto.wst.usseedplanning.model.maintenance.YieldTargetFactor;
import com.monsanto.wst.usseedplanning.services.maintenance.seedEntity.GenderService;
import com.monsanto.wst.usseedplanning.services.maintenance.seedEntity.YearService;
import com.monsanto.wst.usseedplanning.services.maintenance.seedEntity.YieldTargetService;
import com.monsanto.wst.usseedplanning.view.factory.ViewFactory;

import java.io.IOException;

/**
 * Filename:    $RCSfile: TargetYieldListController.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: njminsh $
 * On:	$Date: 2007-02-12 16:28:41 $
 *
 * @author rdesai2
 * @version $Revision: 1.21 $
 */
public class TargetYieldListController extends AbstractDispatchController {

  private ViewFactory viewFactory;
  private YearService yearService;
  private YieldTargetService yieldTargetService;
  private GenderService genderService;
  DataTypeUtil util = new DataTypeUtil();

  public TargetYieldListController(ViewFactory viewFactory, YearService yearService,
                                   YieldTargetService yieldTargetService, GenderService genderService) {
    this.viewFactory = viewFactory;
    this.yearService = yearService;
    this.yieldTargetService = yieldTargetService;
    this.genderService = genderService;
  }

  protected void notSpecified(UCCHelper helper) throws IOException {
      helper.setRequestAttributeValue(MainConstants.HELPER_PARAM_YEAR_LOOKUP_LIST, yearService.getActiveYears());
      helper.setRequestAttributeValue(MainConstants.HELPER_PARAM_GENDER_LOOKUP_LIST, genderService.getActiveGenders());
    this.viewFactory.getJspTargetYieldListPageView()
        .renderView(helper);
  }

  public void searchYieldTargetFactors(UCCHelper helper) throws Exception {
    String productName = getProductName(
        helper.getRequestParameterValue(MainConstants.HELPER_PARAM_YIELD_TARGET_LIST_PAGE_PRODUCT_NAME));
    Long targetYearId = util.convertStringToLongIgnoreNumberFormatException(
        helper.getRequestParameterValue(MainConstants.HELPER_PARAM_YIELD_TARGET_LIST_PAGE_TARGET_YEAR_ID_STR));
    Long genderId = util.convertStringToLongIgnoreNumberFormatException(
        helper.getRequestParameterValue(MainConstants.HELPER_PARAM_YIELD_TARGET_LIST_PAGE_GENDER_ID_STR));
      helper.setRequestAttributeValue(MainConstants.HELPER_PARAM_YEAR_LOOKUP_LIST, yearService.getActiveYears());
      helper.setRequestAttributeValue(MainConstants.HELPER_PARAM_GENDER_LOOKUP_LIST, genderService.getActiveGenders());
      helper.setRequestAttributeValue(MainConstants.HELPER_PARAM_YIELD_TARGET_FACTOR_LIST,
              yieldTargetService.getAllApplicableYieldTargetFactorsInOrderOfPrecedence(
                productName, targetYearId, genderId, null));
    this.viewFactory.getJspTargetYieldListPageView(
    ).renderView(helper);
  }

  public void addYieldTargetFactor(UCCHelper helper) throws IOException {
    helper.setRequestAttributeValue(MainConstants.HELPER_PARAM_YEAR_LOOKUP_LIST, yearService.getActiveYears());
    helper.setRequestAttributeValue(MainConstants.HELPER_PARAM_GENDER_LOOKUP_LIST, genderService.getActiveGenders());
    helper.forward(MainConstants.FORWARD_ADD_EDIT_YIELD_TARGET_LIST_PAGE);
  }

  public void editYieldTargetFactor(UCCHelper helper) throws IOException {
    YieldTargetFactor yieldTargetFactor = getQueryYieldTargetFactor(
        helper.getRequestParameterValue(MainConstants.HELPER_EDIT_TARGET_YIELD_PARAM_REVISION_ID));
    helper.setRequestAttributeValue(MainConstants.HELPER_PARAM_YIELD_TARGET_FACTOR, yieldTargetFactor);
    helper.setRequestAttributeValue(MainConstants.HELPER_PARAM_YEAR_LOOKUP_LIST, yearService.getActiveYears());
    helper.setRequestAttributeValue(MainConstants.HELPER_PARAM_GENDER_LOOKUP_LIST, genderService.getActiveGenders());
    helper.setRequestAttributeValue(MainConstants.HELPER_TARGET_YIELD_EDIT_ACTION_FLAG, "true");
    helper.forward(MainConstants.FORWARD_ADD_EDIT_YIELD_TARGET_LIST_PAGE);
  }

  private YieldTargetFactor getQueryYieldTargetFactor(String revisionId) {
    return yieldTargetService.getYieldTargetByRevisionId(revisionId);
  }

  private String getProductName(String productName) {
    if (!StringUtils.isNullOrEmpty(productName)) {
      return productName;
    }
    return null;
  }

}