package com.monsanto.wst.usseedplanning.controller.validator;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.wst.validator.HttpRequestErrors;
import com.monsanto.wst.validator.HttpValidator;
import org.apache.commons.lang.StringUtils;

import java.io.IOException;

/**
 * Created by IntelliJ IDEA.
 * Date: Aug 17, 2006
 * Time: 8:47:52 AM
 * <p/>
 * This class is used to validate requests to update supply.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class UpdateSupplyValidator implements HttpValidator {
    /**
     * This method validates the appropriate fields from the request.
     *
     * @param helper UCCHelper object containing the request and response.
     * @return HttpRequestErrors - Object representing any errors.
     * @throws IOException - If unable to access request.
     */
    public HttpRequestErrors validate(UCCHelper helper) throws IOException {
        HttpRequestErrors errors = new HttpRequestErrors();
        String comments = helper.getRequestParameterValue("comments");
        if (StringUtils.isEmpty(comments)) {
            errors.addError("comments", "The Comment field is required.");
        }
        if (helper.getClientFiles().size() != 1) {
            errors.addError("supplyFile", "The File field is required.");
        }
        return errors;
    }
}
