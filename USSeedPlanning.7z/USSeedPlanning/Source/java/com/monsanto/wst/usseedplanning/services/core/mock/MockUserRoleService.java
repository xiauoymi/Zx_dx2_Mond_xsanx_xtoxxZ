/*
 MockUserRoleService was created on Aug 22, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.usseedplanning.services.core.mock;

import com.monsanto.wst.usseedplanning.services.core.UserRoleService;

import java.util.ArrayList;
import java.util.List;

/**
 * Filename:    $RCSfile: MockUserRoleService.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ffbrac $    	 On:	$Date: 2006-08-22 22:27:49 $
 *
 * @author ffbrac
 * @version $Revision: 1.2 $
 */
public class MockUserRoleService implements UserRoleService {
	private String userId = null;
	private ArrayList list = null;
	public List getUserRoleList(String userId){
		if("FFBRAC".equals(this.userId)){
			list = new ArrayList();
			list.add("1");
			list.add("2");
			return (List) list;
		}
	    return (List) list;
	}
	public String getUserId(){
	    return this.userId;
	}
	public void setUserId(String userId){
	    this.userId = userId;
	}
	public void setUserRoleList(ArrayList list){
		this.list = list;
	}
}