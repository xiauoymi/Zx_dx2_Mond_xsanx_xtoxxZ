package com.monsanto.wst.usseedplanning.container.test;

import com.monsanto.wst.usseedplanning.container.ControllerFactory;
import com.monsanto.wst.usseedplanning.utils.testutils.TempBaseTestCase;
import com.monsanto.wst.usseedplanning.controller.maintenance.targetyield.TargetYieldController;
import com.monsanto.wst.usseedplanning.controller.maintenance.targetyield.TargetYieldListController;
import com.monsanto.wst.usseedplanning.controller.maintenance.SupplyController;
import com.monsanto.wst.usseedplanning.controller.maintenance.CommonUploadController;
import com.monsanto.wst.usseedplanning.controller.maintenance.UsSeedMaintenanceController;
import com.monsanto.wst.usseedplanning.controller.maintenance.ForecastController;
import com.monsanto.wst.usseedplanning.controller.maintenance.seedEntity.StageFactorController;
import com.monsanto.wst.usseedplanning.controller.planning.PlanController;
import com.monsanto.wst.usseedplanning.controller.planning.UsSeedPlanningController;
import com.monsanto.wst.usseedplanning.controller.core.JSToolsController;
import com.monsanto.wst.usseedplanning.controller.core.UsSeedContactUsController;
import com.monsanto.wst.usseedplanning.controller.core.UsSeedMainController;
import com.monsanto.wst.usseedplanning.controller.core.CancelActionController;
import com.monsanto.wst.usseedplanning.controller.reports.UsSeedReportsController;
import com.monsanto.wst.factory.AbstractGenericFactory;
import com.monsanto.wst.factory.GenericFactory;
import com.monsanto.wst.reportingframework.controller.CreateReportController;
import com.monsanto.wst.reportingframework.controller.ExportController;
import com.monsanto.wst.reportingframework.controller.GenerateReportOptions;
import com.monsanto.wst.administerreferencedata.controller.DisplayDBLookupsController;
import com.monsanto.wst.administerreferencedata.controller.PreUpdateLookupController;
import com.monsanto.wst.administerreferencedata.controller.SaveLookupController;
import com.monsanto.wst.commonutils.EnvironmentUtils;
import com.monsanto.wst.dbtemplate.dao.persistentstore.test.mock.MockPersistentStoreTransactionManager;
import com.monsanto.ServletFramework.UseCaseController;

/**
 * Created by IntelliJ IDEA.
 * Date: Feb 11, 2007
 * Time: 6:05:39 PM
 * <p/>
 * TODO: Enter description for class.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class ControllerFactory_AT extends TempBaseTestCase {
    protected void setUp() throws Exception {
        super.setUp();
        String catalinaHome = new EnvironmentUtils().getVariable("CATALINA_HOME");
        System.setProperty("catalina.home", catalinaHome);
        GenericFactory container = AbstractGenericFactory.getInstance();
        container.addBean("transactionManager", new MockPersistentStoreTransactionManager(), true);
    }

    protected void tearDown() throws Exception {
        super.tearDown();
        System.setProperty("catalina.home", "");
    }

    public void testCreate() throws Exception {
        ControllerFactory factory = new ControllerFactory();
        assertNotNull(factory);
    }

    public void testGetForecastController() throws Exception {
        GenericFactory container = AbstractGenericFactory.getInstance();
        UseCaseController controller = (UseCaseController) container.getBean("/servlet/forecast.htm");
        assertNotNull(controller);
        assertEquals(ForecastController.class, controller.getClass());
    }

    public void testGetStageFactorController() throws Exception {
        GenericFactory container = AbstractGenericFactory.getInstance();
        UseCaseController controller = (UseCaseController) container.getBean("/servlet/searchStageFactors.htm");
        assertNotNull(controller);
        assertEquals(StageFactorController.class, controller.getClass());
    }

    public void testCancelAction() throws Exception {
        GenericFactory container = AbstractGenericFactory.getInstance();
        UseCaseController controller = (UseCaseController) container.getBean("/servlet/cancelAction.htm");
        assertNotNull(controller);
        assertEquals(CancelActionController.class, controller.getClass());
    }

    public void testGetMainUSSeedPage() throws Exception {
        GenericFactory container = AbstractGenericFactory.getInstance();
        UseCaseController controller = (UseCaseController) container.getBean("/servlet/login.htm");
        assertNotNull(controller);
        assertEquals(UsSeedMainController.class, controller.getClass());
    }

    public void testGetContactUsUSSeedPage() throws Exception {
        GenericFactory container = AbstractGenericFactory.getInstance();
        UseCaseController controller = (UseCaseController) container.getBean("/servlet/contact_us.htm");
        assertNotNull(controller);
        assertEquals(UsSeedContactUsController.class, controller.getClass());
    }

    public void testGetMaintenanceUSSeedPage() throws Exception {
        GenericFactory container = AbstractGenericFactory.getInstance();
        UseCaseController controller = (UseCaseController) container.getBean("/servlet/maintenance.htm");
        assertNotNull(controller);
        assertEquals(UsSeedMaintenanceController.class, controller.getClass());
    }

    public void testGetReportsUSSeedPage() throws Exception {
        GenericFactory container = AbstractGenericFactory.getInstance();
        UseCaseController controller = (UseCaseController) container.getBean("/servlet/reports.htm");
        assertNotNull(controller);
        assertEquals(UsSeedReportsController.class, controller.getClass());
    }

    public void testGetCreateReportController() throws Exception {
        GenericFactory container = AbstractGenericFactory.getInstance();
        UseCaseController controller = (UseCaseController) container.getBean("/servlet/create_report.htm");
        assertNotNull(controller);
        assertEquals(CreateReportController.class, controller.getClass());
    }

    public void testGetExportController() throws Exception {
        GenericFactory container = AbstractGenericFactory.getInstance();
        UseCaseController controller = (UseCaseController) container.getBean("/servlet/export_report.htm");
        assertNotNull(controller);
        assertEquals(ExportController.class, controller.getClass());
    }

    public void testGetGenerateReportOptions() throws Exception {
        GenericFactory container = AbstractGenericFactory.getInstance();
        UseCaseController controller = (UseCaseController) container.getBean("/servlet/generate_report.htm");
        assertNotNull(controller);
        assertEquals(GenerateReportOptions.class, controller.getClass());
    }

    public void testGetDisplayLookupController() throws Exception {
        GenericFactory container = AbstractGenericFactory.getInstance();
        UseCaseController controller = (UseCaseController) container.getBean("/servlet/display_lookup.htm");
        assertNotNull(controller);
        assertEquals(DisplayDBLookupsController.class, controller.getClass());
    }

    public void testGetUpdateLookupController() throws Exception {
        GenericFactory container = AbstractGenericFactory.getInstance();
        UseCaseController controller = (UseCaseController) container.getBean("/servlet/update_lookup.htm");
        assertNotNull(controller);
        assertEquals(PreUpdateLookupController.class, controller.getClass());
    }

    public void testGetSaveLookupController() throws Exception {
        GenericFactory container = AbstractGenericFactory.getInstance();
        UseCaseController controller = (UseCaseController) container.getBean("/servlet/save_lookup.htm");
        assertNotNull(controller);
        assertEquals(SaveLookupController.class, controller.getClass());
    }

    public void testGetPlanningUSSeedPage() throws Exception {
        GenericFactory container = AbstractGenericFactory.getInstance();
        UseCaseController controller = (UseCaseController) container.getBean("/servlet/planning.htm");
        assertNotNull(controller);
        assertEquals(UsSeedPlanningController.class, controller.getClass());
    }

    public void testGetSupplyController() throws Exception {
        GenericFactory container = AbstractGenericFactory.getInstance();
        UseCaseController controller = (UseCaseController) container.getBean("/servlet/supply.htm");
        assertNotNull(controller);
        assertEquals(SupplyController.class, controller.getClass());
    }

    public void testGetJSToolsController() throws Exception {
        GenericFactory container = AbstractGenericFactory.getInstance();
        UseCaseController controller = (UseCaseController) container.getBean("/servlet/JSConstants.js");
        assertNotNull(controller);
        assertEquals(JSToolsController.class, controller.getClass());
    }

    public void testGetTargetYieldListController() throws Exception {
        GenericFactory container = AbstractGenericFactory.getInstance();
        UseCaseController controller = (UseCaseController) container.getBean("/servlet/targetYieldList.htm");
        assertNotNull(controller);
        assertEquals(TargetYieldListController.class, controller.getClass());
    }

    public void testGetTargetYieldController() throws Exception {
        GenericFactory container = AbstractGenericFactory.getInstance();
        UseCaseController controller = (UseCaseController) container.getBean("/servlet/targetYield.htm");
        assertNotNull(controller);
        assertEquals(TargetYieldController.class, controller.getClass());
    }

    public void testGetPlanController() throws Exception {
        GenericFactory container = AbstractGenericFactory.getInstance();
        UseCaseController controller = (UseCaseController) container.getBean("/servlet/generatePlan.htm");
        assertNotNull(controller);
        assertEquals(PlanController.class, controller.getClass());
    }

    public void testGetCommonUploadController() throws Exception {
        GenericFactory container = AbstractGenericFactory.getInstance();
        UseCaseController controller = (UseCaseController) container.getBean("/servlet/commonUpload.htm");
        assertNotNull(controller);
        assertEquals(CommonUploadController.class, controller.getClass());
    }

    public void testGetAdminController() throws Exception {
        GenericFactory container = AbstractGenericFactory.getInstance();
        UseCaseController controller = (UseCaseController) container.getBean("/servlet/admin.htm");
        assertNotNull(controller);
    }

    public void testGetSaveQaThresholdController() throws Exception {
        GenericFactory container = AbstractGenericFactory.getInstance();
        UseCaseController controller = (UseCaseController) container.getBean("/servlet/qaThresholdForm.htm");
        assertNotNull(controller);
    }
}
