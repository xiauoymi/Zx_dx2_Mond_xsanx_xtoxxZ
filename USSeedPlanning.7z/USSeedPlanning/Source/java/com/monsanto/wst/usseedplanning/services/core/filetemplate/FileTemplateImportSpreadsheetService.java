package com.monsanto.wst.usseedplanning.services.core.filetemplate;

import com.monsanto.wst.filetemplate.FileTemplate;
import com.monsanto.wst.usseedplanning.services.core.ImportSpreadsheetService;

import java.io.File;
import java.io.IOException;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * Date: Aug 8, 2006
 * Time: 12:11:38 PM
 * <p/>
 * This class is a filetemplate implementation of the ImportSpreadsheetService interface.  It is used to translate file
 * based data into usable objects.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class FileTemplateImportSpreadsheetService implements ImportSpreadsheetService {
    private FileTemplate fileTemplate;

    /**
     * This constructor takes all dependencies.
     *
     * @param fileTemplate FileTemplate object representing a translater object for converting file data into objects.
     */
    public FileTemplateImportSpreadsheetService(FileTemplate fileTemplate) {
        this.fileTemplate = fileTemplate;
    }

    /**
     * This method retrieves a list of common forecasts based on the specified file.
     *
     * @param spreadsheet File object representing the file with the data.
     * @return List - Of configured objects representing the data.
     * @throws IOException - If unable to read the file.
     */
    public List getCommonForecasts(File spreadsheet) throws IOException {
        return this.fileTemplate.importFile("commonForecast", spreadsheet);
    }
    /**
     * This method retrieves a list of demand forecasts based on the specified file.
     *
     * @param spreadsheet File object representing the file with the data.
     * @return List - Of configured objects representing the data.
     * @throws IOException - If unable to read the file.
     */
    public List getDemandForecasts(File spreadsheet) throws IOException {
        return this.fileTemplate.importFile("demandForecast", spreadsheet);
    }

    /**
     * This method retrieves a list of current supply objects.
     *
     * @return List - Representing the supply objects.
     * @throws IOException - If unable to read the supply file.
     * @param file File representing the ATP supply data file.
     */
    public List getATPSupply(File file) throws IOException {
        return this.fileTemplate.importFile("ATPSupply", file);
    }

      /**
     * This method retrieves a list of current supply objects.
     *
     * @return List - Representing the supply objects.
     * @throws IOException - If unable to read the supply file.
     * @param file File representing the ZDCA supply data file.
     */
    public List getZDCASupply(File file) throws IOException {
        return this.fileTemplate.importFile("ZDCASupply", file);
    }

	public List getCommonUpload(String columnName, File file) throws IOException {
	    return this.fileTemplate.importFile(columnName, file);
	}

	public List getSavePlanSpreadSheet(File file) throws IOException {
		return this.fileTemplate.importFile("save_plan", file);
	}

	public List getImportHybridToDemand(File file) throws IOException {
		return this.fileTemplate.importFile("hybrid_demand", file);
	}
}
