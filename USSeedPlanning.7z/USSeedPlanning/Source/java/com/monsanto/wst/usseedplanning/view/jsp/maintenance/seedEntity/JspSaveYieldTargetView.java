package com.monsanto.wst.usseedplanning.view.jsp.maintenance.seedEntity;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.wst.usseedplanning.constants.MainConstants;
import com.monsanto.wst.view.View;
import com.monsanto.wst.view.ViewRenderingException;

import java.io.IOException;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Aug 8, 2006
 * Time: 10:03:01 AM
 * To change this template use File | Settings | File Templates.
 */
public class JspSaveYieldTargetView implements View {

    private List typeList;
    private String type;

    public JspSaveYieldTargetView(List typeList, String type) {
        this.typeList = typeList;
        this.type = type;
    }

    public JspSaveYieldTargetView() {
    }

    public void renderView(UCCHelper helper) throws ViewRenderingException {
        if (type!=null && typeList.size()>0){
            setRespectiveListIntoRequest(helper);
        }
        try {
            helper.forward(MainConstants.CREATE_TARGET_YIELD_JSP);
        } catch (IOException e) {
            throw new ViewRenderingException("Unable to Render View");
        }
    }

    private void setRespectiveListIntoRequest(UCCHelper helper) {
        if (this.type.equalsIgnoreCase(MainConstants.ERROR_LIST)){
            helper.setRequestAttributeValue(MainConstants.ERROR_LIST, this.typeList);
        }
        if (this.type.equalsIgnoreCase(MainConstants.SUCCESS_LIST)){
            helper.setRequestAttributeValue(MainConstants.SUCCESS_LIST, this.typeList);
        }
    }

}
