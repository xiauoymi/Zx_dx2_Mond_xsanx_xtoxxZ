package com.monsanto.wst.usseedplanning.services.core;

/**
 * Created by IntelliJ IDEA.
 * Date: Apr 7, 2006
 * Time: 9:51:41 AM
 * <p/>
 * This object is a custom exception for notifying of log reader errors.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class LogReaderException extends RuntimeException {

    /**
     * This constructor takes an error message.
     *
     * @param message String representing the error message.
     */
    public LogReaderException(String message) {
        super(message);
    }

}
