/*
 StageService was created on Sep 18, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.usseedplanning.services.maintenance.seedEntity;

import com.monsanto.wst.usseedplanning.model.maintenance.Stage;

import java.util.List;

/**
 * Filename:    $RCSfile: StageService.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: SSPATI1 $    	 On:	$Date: 2006-09-19 21:13:35 $
 *
 * @author sspati1
 * @version $Revision: 1.2 $
 */
public interface StageService {

  /***
   * This method returns all the stages
   * @return - list of Stage objects
   */
  List lookupAllStages();

  /***
   * this method returns Stage with specified id
   * @param stageId
   * @return
   */
  Stage lookupStageById(Long stageId);
}