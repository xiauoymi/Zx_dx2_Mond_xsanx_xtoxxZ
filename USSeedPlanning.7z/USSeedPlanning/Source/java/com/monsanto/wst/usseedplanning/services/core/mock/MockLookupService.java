/*
 MockLookupService was created on Oct 24, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.usseedplanning.services.core.mock;

import com.monsanto.wst.usseedplanning.model.planning.Plan;
import com.monsanto.wst.usseedplanning.services.core.LookupService;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Filename:    $RCSfile: MockLookupService.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $
 * On:	$Date: 2006-12-01 20:25:04 $
 *
 * @author ffbrac
 * @version $Revision: 1.4 $
 */
public class MockLookupService implements LookupService {
  public Plan lookupPlanByPlanId(Long planId) {
    return new Plan();
  }

  public List lookupPlanDetailsByPlanId(Long planId) {
    return new ArrayList();
  }

  public Date lookupLastRevisionDate() {
    return new Date(0);
  }

  public String lookupReleaseTrackingValue() {
    return "";
  }

  public List lookupPlanRevisionList() {
    return new ArrayList();
  }

  public List lookupGeneratedPlanComponents(Long planId) {
    return new ArrayList();
  }

  public List lookupPlanListByPlanTypeName(String planTypeName) {
    return new ArrayList();
  }
}