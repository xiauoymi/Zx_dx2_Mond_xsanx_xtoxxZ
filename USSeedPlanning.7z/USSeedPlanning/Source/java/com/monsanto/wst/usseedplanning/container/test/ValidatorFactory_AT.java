package com.monsanto.wst.usseedplanning.container.test;

import com.monsanto.wst.usseedplanning.utils.testutils.TempBaseTestCase;
import com.monsanto.wst.usseedplanning.container.ValidatorFactory;
import com.monsanto.wst.usseedplanning.controller.validator.AddForecastValidator;
import com.monsanto.wst.usseedplanning.controller.validator.CommonUploadValidator;
import com.monsanto.wst.usseedplanning.controller.validator.PlanValidator;
import com.monsanto.wst.factory.GenericFactory;
import com.monsanto.wst.factory.AbstractGenericFactory;
import com.monsanto.wst.validator.HttpValidator;

/**
 * Created by IntelliJ IDEA.
 * Date: Feb 11, 2007
 * Time: 7:29:04 PM
 * <p/>
 * TODO: Enter description for class.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class ValidatorFactory_AT extends TempBaseTestCase {
    public void testCreate() throws Exception {
        ValidatorFactory factory = new ValidatorFactory();
        assertNotNull(factory);
    }

    public void testGetCommonForecastValidator() throws Exception {
        GenericFactory container = AbstractGenericFactory.getInstance();
        HttpValidator validator = (HttpValidator) container.getBean("commonForecastValidator");
        assertNotNull(validator);
        assertEquals(AddForecastValidator.class, validator.getClass());
    }

    public void testGetCommonUploadValidator() throws Exception {
        GenericFactory container = AbstractGenericFactory.getInstance();
        HttpValidator validator = (HttpValidator) container.getBean("commonUploadValidator");
        assertNotNull(validator);
        assertEquals(CommonUploadValidator.class, validator.getClass());
    }

    public void testGetPlanValidator() throws Exception {
        GenericFactory container = AbstractGenericFactory.getInstance();
        HttpValidator validator = (HttpValidator) container.getBean("planValidator");
        assertNotNull(validator);
        assertEquals(PlanValidator.class, validator.getClass());
    }

    public void testGetCommitPlanValidator() throws Exception {
        GenericFactory container = AbstractGenericFactory.getInstance();
        HttpValidator validator = (HttpValidator) container.getBean("commitPlanValidator");
        assertNotNull(validator);
    }

    public void testGetQaThresholdInputValidator() throws Exception {
        GenericFactory container = AbstractGenericFactory.getInstance();
        HttpValidator validator = (HttpValidator) container.getBean("qaThresholdInputValidator");
        assertNotNull(validator);
    }
}
