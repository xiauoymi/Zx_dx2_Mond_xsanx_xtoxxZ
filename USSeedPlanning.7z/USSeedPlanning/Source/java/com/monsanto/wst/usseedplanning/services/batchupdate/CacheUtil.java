/*
 CacheUtil was created on Dec 20, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.usseedplanning.services.batchupdate;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.HashSet;

/**
 * Filename:    $RCSfile: CacheUtil.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: vrbethi $    	 On:	$Date: 2006-12-21 22:15:59 $
 *
 * @author vrbethi
 * @version $Revision: 1.1 $
 */
public class CacheUtil {
    public List removeDuplicatePreCommercialRecordsInProductDetailsList(List arrayList) {
        Set hashSet = new HashSet(arrayList);
        return new ArrayList(hashSet);
    }
}