/*
 JspPlanningView_UT was created on Aug 17, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.usseedplanning.view.jsp.planning.test;

import com.monsanto.AbstractLogging.Logger;
import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.wst.commonutils.testutils.TestUtils;
import com.monsanto.wst.usseedplanning.constants.MainConstants;
import com.monsanto.wst.usseedplanning.view.jsp.planning.JspPlanningView;
import com.monsanto.wst.view.ViewRenderingException;
import com.monsanto.wst.view.test.mock.MockUCCHelperThrowsIOException;
import junit.framework.TestCase;

/**
 * Filename:    $RCSfile: JspPlanningView_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: njminsh $    	 On:	$Date: 2006-09-08 15:10:12 $
 *
 * @author ffbrac
 * @version $Revision: 1.6 $
 */
public class JspPlanningView_UT extends TestCase{
	MockUCCHelper helper = null;

	public void testCreate() throws Exception{
	    JspPlanningView planningPage = new JspPlanningView();
	    assertNotNull(planningPage);
	}

	protected void setUp() throws Exception {
	    new TestUtils().setupLogging(MainConstants.APPLICATION_NAME);
	    super.setUp();
	    helper = new MockUCCHelper(null);
	}

	public void testRenderView() throws Exception {
		JspPlanningView planningPage = new JspPlanningView();
	    planningPage.renderView(helper);
	    assertTrue(helper.wasSentTo(MainConstants.PLANNING_PAGE));
	}

	public void testRenderViewThrowsException() throws Exception {
	    MockUCCHelperThrowsIOException helperThrowsIOException = new MockUCCHelperThrowsIOException(null);
		JspPlanningView planningPage = new JspPlanningView();
		Logger.enableLogger(Logger.ERROR_LOG);
	    try {
	        planningPage.renderView(helperThrowsIOException);
	        fail("This should have thrown Exception");
	    } catch (ViewRenderingException e) {
	        assertEquals("Unable to Render View", e.getMessage());
	    }
		Logger.disableLogger(Logger.ERROR_LOG);
	    try {
	        planningPage.renderView(helperThrowsIOException);
	        fail("This should have thrown Exception");
	    } catch (ViewRenderingException e) {
	        assertEquals("Unable to Render View", e.getMessage());
	    }
	}
	public void testRenderViewThrowsExceptionFail() throws Exception {
	    MockUCCHelperThrowsIOException helperThrowsIOException = new MockUCCHelperThrowsIOException(null);
		JspPlanningView planningPage = new JspPlanningView();
	}
}