/*
 StageFactorControllerUT was created on Sep 18, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.usseedplanning.controller.maintenance.seedEntity.test;

import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.wst.usseedplanning.controller.maintenance.seedEntity.StageFactorController;
import com.monsanto.wst.usseedplanning.model.maintenance.Year;
import com.monsanto.wst.usseedplanning.services.maintenance.seedEntity.StageFactorService;
import com.monsanto.wst.usseedplanning.services.maintenance.seedEntity.StageService;
import com.monsanto.wst.usseedplanning.services.maintenance.seedEntity.YearService;
import com.monsanto.wst.usseedplanning.services.maintenance.seedEntity.mock.MockStageFactorService;
import com.monsanto.wst.usseedplanning.services.maintenance.seedEntity.mock.MockStageService;
import com.monsanto.wst.usseedplanning.view.factory.ViewFactory;
import com.monsanto.wst.usseedplanning.view.factory.mock.MockViewFactory;
import com.monsanto.wst.validator.HttpRequestErrors;
import com.monsanto.wst.validator.HttpRequestMessages;
import com.monsanto.wst.validator.HttpValidator;
import com.monsanto.wst.validator.test.mock.MockHttpValidator;
import com.monsanto.wst.view.test.mock.MockView;
import junit.framework.TestCase;

import java.util.ArrayList;
import java.util.List;

/**
 * Filename:    $RCSfile: StageFactorControllerUT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: njminsh $
 * On:	$Date: 2007-02-13 19:21:05 $
 *
 * @author sspati1
 * @version $Revision: 1.12 $
 */
public class StageFactorControllerUT extends TestCase {
    public void testCreate() throws Exception {
        StageFactorController controller = new StageFactorController((StageFactorService) null, (YearService) null,
                (StageService) null, (ViewFactory) null, (HttpValidator) null);
        assertNotNull(controller);
    }

    public void testNotSpecified() throws Exception {
        MockYearService yearService = new MockYearService();
        MockStageService stageService = new MockStageService();
        MockUCCHelper helper = new MockUCCHelper(null);
        ViewFactory factory = new MockViewFactory();
        StageFactorController controller = new StageFactorController(new MockStageFactorService(), yearService, stageService,
                factory, (HttpValidator) null);
        controller.run(helper);
        MockView view = (MockView) factory
                .getListStageFactorsView();
        assertNotNull(helper.getRequestAttributeValue("stageFactorsList"));
        assertNotNull(helper.getRequestAttributeValue("yearList"));
        assertEquals(2, ((List) helper.getRequestAttributeValue("stageList")).size());
        assertTrue(view.wasViewRendered());
    }


    public void testDisplayApplicableStageFactorsNoCriteria() throws Exception {
        MockUCCHelper helper = new MockUCCHelper(null);
        helper.setRequestParameterValue("method", "listStageFactors");
        ViewFactory factory = new MockViewFactory();
        MockYearService yearService = new MockYearService();
        MockStageService stageService = new MockStageService();
        MockStageFactorService service = new MockStageFactorService();
        StageFactorController controller = new StageFactorController(service, yearService, stageService, factory,
                (HttpValidator) null);
        controller.run(helper);
        MockView view = (MockView) factory.getListStageFactorsView();
        assertNotNull(helper.getRequestAttributeValue("stageFactorsList"));
        assertNotNull(helper.getRequestAttributeValue("yearList"));
        assertEquals(2, ((List) helper.getRequestAttributeValue("stageList")).size());
        assertTrue(view.wasViewRendered());
    }

    public void testRetrieveStageFactor() throws Exception {
        MockUCCHelper helper = new MockUCCHelper(null);
        helper.setRequestParameterValue("revisionId", "705");
        helper.setRequestParameterValue("method", "retrieveStageFactor");
        ViewFactory factory = new MockViewFactory();
        MockYearService yearService = new MockYearService();
        MockStageService stageService = new MockStageService();
        MockStageFactorService service = new MockStageFactorService();
        StageFactorController controller = new StageFactorController(service, yearService, stageService, factory,
                (HttpValidator) null);
        controller.run(helper);
        MockView view = (MockView) factory.getDisplayStageFactorView();
        assertNotNull(helper.getRequestAttributeValue("stageFactor"));
        assertNotNull(helper.getRequestAttributeValue("yearList"));
        assertEquals(2, ((List) helper.getRequestAttributeValue("stageList")).size());
        assertTrue(view.wasViewRendered());
    }

    public void testRetreiveStageFactorNoRevisionId() throws Exception {
        MockUCCHelper helper = new MockUCCHelper(null);
        helper.setRequestParameterValue("method", "retrieveStageFactor");
        ViewFactory factory = new MockViewFactory();
        MockYearService yearService = new MockYearService();
        MockStageService stageService = new MockStageService();
        MockStageFactorService service = new MockStageFactorService();
        StageFactorController controller = new StageFactorController(service, yearService, stageService, factory,
                (HttpValidator) null);
        controller.run(helper);
        MockView view = (MockView) factory.getDisplayStageFactorView();
        assertNull(helper.getRequestAttributeValue("stageFactor"));
        assertNotNull(helper.getRequestAttributeValue("yearList"));
        assertEquals(2, ((List) helper.getRequestAttributeValue("stageList")).size());
        assertTrue(view.wasViewRendered());
    }

    public void testSaveStageFactor() throws Exception {
        MockUCCHelper helper = new MockUCCHelper(null);
        helper.setRequestParameterValue("productName", "");
        helper.setRequestParameterValue("yearId", "");
        helper.setRequestParameterValue("stageId", "123");
        helper.setRequestParameterValue("factor", "123");
        helper.setRequestParameterValue("status", "Y");
        helper.setRequestParameterValue("comments", "test comments");
        helper.setRequestParameterValue("method", "saveStageFactor");
        MockViewFactory factory = new MockViewFactory();
        MockYearService yearService = new MockYearService();
        MockStageService stageService = new MockStageService();
        MockStageFactorService service = new MockStageFactorService();
        StageFactorController controller = new StageFactorController(service, yearService, stageService, factory,
                new MockHttpValidator());
        controller.run(helper);
        MockView view = (MockView) factory.getListStageFactorsView();
        assertEquals("Stage Factor Successfully saved.", ((HttpRequestMessages) helper.getRequestAttributeValue("messages")).getMessages().get(0));
        assertNull(helper.getRequestAttributeValue("stageFactor"));
        assertNotNull(helper.getRequestAttributeValue("yearList"));
        assertEquals(2, ((List) helper.getRequestAttributeValue("stageList")).size());
        assertEquals("listStageFactors", helper.getRequestAttributeValue("method"));
        assertTrue(service.isWasAdded());
        assertTrue(view.wasViewRendered());
    }

    public void testSaveStageFactorValidationErrors() throws Exception {
        MockViewFactory viewFactory = new MockViewFactory();
        HttpRequestErrors errors = new HttpRequestErrors();
        errors.addError("test", "test error");
        MockYearService yearService = new MockYearService();
        MockStageService stageService = new MockStageService();
        MockStageFactorService service = new MockStageFactorService();
        StageFactorController controller = new StageFactorController(service, yearService, stageService, viewFactory,
                new MockHttpValidator(errors));
        MockUCCHelper helper = new MockUCCHelper(null);
        helper.setRequestParameterValue("productName", "");
        helper.setRequestParameterValue("yearId", "12");
        helper.setRequestParameterValue("stageId", "123");
        helper.setRequestParameterValue("factor", "123");
        helper.setRequestParameterValue("status", "Y");
        helper.setRequestParameterValue("method", "saveStageFactor");
        controller.run(helper);
        MockView view = (MockView) viewFactory.getDisplayStageFactorView();
        assertEquals("test error", ((HttpRequestErrors) helper.getRequestAttributeValue("errors")).getError("test"));
        assertNotNull(helper.getRequestAttributeValue("stageFactor"));
        assertNotNull(helper.getRequestAttributeValue("yearList"));
        assertEquals(2, ((List) helper.getRequestAttributeValue("stageList")).size());
        assertFalse(service.isWasAdded());
        assertTrue(view.wasViewRendered());
    }

    private class MockYearService implements YearService {
        public List getActiveYears() {
            return new ArrayList();
        }

        public Year lookupYearById(Long yearId) {
            Year year = new Year();
            year.setId(new Long(123));
            year.setYear(new Integer(2006));
            return year;
        }

        public Year lookupCurrentYear() {
            return new Year(new Integer("2006"), "test", Boolean.TRUE);
        }
    }
}