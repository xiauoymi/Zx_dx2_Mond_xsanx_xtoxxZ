package com.monsanto.wst.usseedplanning.view.jsp.maintenance.seedEntity;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.wst.usseedplanning.constants.MainConstants;
import com.monsanto.wst.view.View;
import com.monsanto.wst.view.ViewRenderingException;

import java.io.IOException;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Aug 9, 2006
 * Time: 8:55:40 AM
 * To change this template use File | Settings | File Templates.
 */
public class JspDisplayAllYieldTargetsView implements View {

    public void renderView(UCCHelper helper) throws ViewRenderingException {
        try {
            helper.forward(MainConstants.DISPLAY_TARGET_YIELD_JSP);
        } catch (IOException e) {
            throw new ViewRenderingException("Unable to Render View");
        }
    }
}
