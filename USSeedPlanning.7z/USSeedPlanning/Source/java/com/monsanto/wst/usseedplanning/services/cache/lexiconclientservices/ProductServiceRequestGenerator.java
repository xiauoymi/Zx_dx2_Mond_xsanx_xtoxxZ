/*
 Copyright:  Copyright � 2006 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.usseedplanning.services.cache.lexiconclientservices;

import org.w3c.dom.Document;

/**
 * Filename:    $RCSfile: ProductServiceRequestGenerator.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: njminsh $    	 On:	$Date: 2007-01-31 22:39:38 $
 *
 * @author rdesai2
 * @version $Revision: 1.1 $
 */
public interface ProductServiceRequestGenerator {

  Document getRequestDocumentForProductParentsByPrecommercialNameService(String preCommercialName) throws Exception;

  Document getRequestDocumentForProductParentsByManufacturingNameService(String manufacturingName) throws Exception;

  Document getRequestDocumentForGetAggregateProductService(String commercialName) throws Exception;
}