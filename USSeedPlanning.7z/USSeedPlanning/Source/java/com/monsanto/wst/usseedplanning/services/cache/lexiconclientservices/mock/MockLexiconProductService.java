/*
MockLexiconProductService was created on Oct 1, 2006 using Monsanto
resources and is the sole property of Monsanto.  Any duplication of the
code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.usseedplanning.services.cache.lexiconclientservices.mock;

import com.monsanto.wst.usseedplanning.services.cache.lexiconclientservices.ProductService;
import com.monsanto.wst.usseedplanning.model.cache.ProductDetails;
import com.monsanto.wst.usseedplanning.model.planning.ParentDetails;

import java.util.List;
import java.util.ArrayList;

/**
 * Filename:    $RCSfile: MockLexiconProductService.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: njminsh $    	 On:	$Date: 2007-01-31 22:39:38 $
 *
 * @author VRBETHI
 * @version $Revision: 1.1 $
 */
public class MockLexiconProductService implements ProductService {

    public String getPreCommercialNameFromCommercialName(String commercialName) throws Exception {
        return commercialName;
    }

    public List getProductDetailsListByPreCommercialName(String preCommercialName) {
        List productDetailsList = new ArrayList();
        productDetailsList.addAll(getTestProductDetailsByPCMName(preCommercialName));
        return productDetailsList;
    }

    public List getProductDetailsListByManufacturingName(String manufacturingName) {
        List productDetailsList = new ArrayList();
        productDetailsList.addAll(getTestProductDetailsByManufacturingName(manufacturingName));
        return productDetailsList;
    }

    private List getTestProductDetailsByManufacturingName(String productName) {
        List detailsList = new ArrayList();
        if(productName.equalsIgnoreCase("P1")){
            detailsList.add(getProductDetails_P1());
        }
        if(productName.equalsIgnoreCase("P2")){
            detailsList.add(getProductDetails_P2());
        }
        if(productName.equalsIgnoreCase("P3")){
            detailsList.add(getProductDetails_P3());
        }
        if(productName.equalsIgnoreCase("P4")){
            detailsList.add(getProductDetails_P4());
        }
        if(productName.equalsIgnoreCase("P5")){
            detailsList.add(getProductDetails_P5());
        }
        if(productName.equalsIgnoreCase("P6")){
            detailsList.add(getProductDetails_P6());
        }
        if(productName.equalsIgnoreCase("P7")){
            detailsList.add(getProductDetails_P7());
        }
        if(productName.equalsIgnoreCase("P8")){
            detailsList.add(getProductDetails_P8());
        }
        if(productName.equalsIgnoreCase("P9")){
            detailsList.add(getProductDetails_P9());
        }
        if(productName.equalsIgnoreCase("P10")){
            detailsList.add(getProductDetails_P10());
        }
        if(productName.equalsIgnoreCase("P11")){
            detailsList.add(getProductDetails_P11());
        }
        if(productName.equalsIgnoreCase("P12")){
            detailsList.add(getProductDetails_P12());
        }
        if(productName.equalsIgnoreCase("P13")){
            detailsList.add(getProductDetails_P13());
        }
        if(productName.equalsIgnoreCase("P14")){
            detailsList.add(getProductDetails_P14());
        }
        if (productName.equalsIgnoreCase("P16")) {
            detailsList.addAll(getProductDetails_P16());
        }
        if (productName.equalsIgnoreCase("P17")) {
            detailsList.addAll(getProductDetails_P17());
        }
        if (productName.equalsIgnoreCase("P19")) {
            detailsList.add(getProductDetails_P19());
        }
        if (productName.equalsIgnoreCase("P20CMS")) {
            detailsList.add(getProductDetails_P20CMS());
        }
        if (productName.equalsIgnoreCase("P20")) {
            detailsList.add(getProductDetails_P20());
        }
        if (productName.equalsIgnoreCase("P21CMS")) {
            detailsList.add(getProductDetails_P21CMS());
        }
        return detailsList;
    }

    private List getTestProductDetailsByPCMName(String productName) {
        List detailsList = new ArrayList();
        if(productName.equalsIgnoreCase("P1")){
            detailsList.add(getProductDetails_P1());
        }
        if(productName.equalsIgnoreCase("P2")){
            detailsList.add(getProductDetails_P2());
        }
        if(productName.equalsIgnoreCase("P3")){
            detailsList.add(getProductDetails_P3());
        }
        if(productName.equalsIgnoreCase("P4")){
            detailsList.add(getProductDetails_P4());
        }
        if(productName.equalsIgnoreCase("P5")){
            detailsList.add(getProductDetails_P5());
        }
        if(productName.equalsIgnoreCase("P6")){
            detailsList.add(getProductDetails_P6());
        }
        if(productName.equalsIgnoreCase("P7")){
            detailsList.add(getProductDetails_P7());
        }
        if(productName.equalsIgnoreCase("P8")){
            detailsList.add(getProductDetails_P8());
        }
        if(productName.equalsIgnoreCase("P9")){
            detailsList.add(getProductDetails_P9());
        }
        if(productName.equalsIgnoreCase("P10")){
            detailsList.add(getProductDetails_P10());
        }
        if(productName.equalsIgnoreCase("P11")){
            detailsList.add(getProductDetails_P11());
        }
        if(productName.equalsIgnoreCase("P12")){
            detailsList.add(getProductDetails_P12());
        }
        if(productName.equalsIgnoreCase("P13")){
            detailsList.add(getProductDetails_P13());
        }
        if(productName.equalsIgnoreCase("P14")){
            detailsList.add(getProductDetails_P14());
        }
        if (productName.equalsIgnoreCase("P16")) {
            detailsList.addAll(getProductDetails_P16());
        }
        if (productName.equalsIgnoreCase("P17")) {
            detailsList.addAll(getProductDetails_P17());
        }
        if (productName.equalsIgnoreCase("PC15")) {
            detailsList.add(getProductDetails_P15());
        }
        if (productName.equalsIgnoreCase("PC18")) {
            detailsList.add(getProductDetails_P18());
        }
        return detailsList;
    }

    private List getProductDetails_P16() {
        List detailsList = new ArrayList();
        ProductDetails productDetails = new ProductDetails();
        productDetails.setManufacturingName("p16");
        productDetails.setPreCommercialName("PC16-A");
        productDetails.setProductType(ProductDetails.PRODUCT_TYPE_PARENT);
        productDetails.setProductionStatus(ProductDetails.PRODUCTION_STATUS_PRIMARY);
        detailsList.add(productDetails);
        productDetails = new ProductDetails();
        productDetails.setManufacturingName("p16");
        productDetails.setPreCommercialName("PC16-B");
        productDetails.setProductType(ProductDetails.PRODUCT_TYPE_PARENT);
        productDetails.setProductionStatus(ProductDetails.PRODUCTION_STATUS_ACTIVE);
        detailsList.add(productDetails);
        productDetails = new ProductDetails();
        productDetails.setManufacturingName("p16");
        productDetails.setPreCommercialName("PC16-C");
        productDetails.setProductType(ProductDetails.PRODUCT_TYPE_PARENT);
        productDetails.setProductionStatus(ProductDetails.PRODUCTION_STATUS_ACTIVE);
        detailsList.add(productDetails);
        return detailsList;
    }

    private List getProductDetails_P17() {
        List detailsList = new ArrayList();
        ProductDetails productDetails = new ProductDetails();
        productDetails.setManufacturingName("p17");
        productDetails.setPreCommercialName("PC17-A");
        productDetails.setProductType(ProductDetails.PRODUCT_TYPE_PARENT);
        productDetails.setProductionStatus(ProductDetails.PRODUCTION_STATUS_ACTIVE);
        detailsList.add(productDetails);
        productDetails = new ProductDetails();
        productDetails.setManufacturingName("p17");
        productDetails.setPreCommercialName("PC17-B");
        productDetails.setProductType(ProductDetails.PRODUCT_TYPE_PARENT);
        productDetails.setProductionStatus(ProductDetails.PRODUCTION_STATUS_ACTIVE);
        detailsList.add(productDetails);
        productDetails = new ProductDetails();
        productDetails.setManufacturingName("p17");
        productDetails.setPreCommercialName("PC17-C");
        productDetails.setProductType(ProductDetails.PRODUCT_TYPE_PARENT);
        productDetails.setProductionStatus(ProductDetails.PRODUCTION_STATUS_ACTIVE);
        detailsList.add(productDetails);
        return detailsList;
    }

    private ProductDetails getProductDetails_P10() {
        ProductDetails productDetails = new ProductDetails();
        productDetails.setManufacturingName("P10");
        productDetails.setPreCommercialName("PC10");
        productDetails.setProductType(ProductDetails.PRODUCT_TYPE_PARENT);
        return productDetails;
    }

    private ProductDetails getProductDetails_P9() {
        ProductDetails productDetails = new ProductDetails();
        productDetails.setManufacturingName("P9");
        productDetails.setPreCommercialName("PC9");
        productDetails.setDeleted(Boolean.TRUE);
        productDetails.setProductType(ProductDetails.PRODUCT_TYPE_PARENT);
        return productDetails;
    }

    private ProductDetails getProductDetails_P8() {
        ProductDetails productDetails = new ProductDetails();
        productDetails.setManufacturingName("P8");
        productDetails.setPreCommercialName("PC8");
        productDetails.setProductType(ProductDetails.PRODUCT_TYPE_PARENT);
        return productDetails;
    }

    private ProductDetails getProductDetails_P1() {
        ProductDetails productDetails = new ProductDetails();
        productDetails.setManufacturingName("P1");
        productDetails.setPreCommercialName("PC1");
        productDetails.setProductType(ProductDetails.PRODUCT_TYPE_PARENT);
        return productDetails;
    }

    private ProductDetails getProductDetails_P3() {
        ProductDetails productDetails = new ProductDetails();
        productDetails.setManufacturingName("P3");
        productDetails.setPreCommercialName("PC3");
        productDetails.setVersion("1A");
        productDetails.setProductType(ProductDetails.PRODUCT_TYPE_PARENT);
        return productDetails;
    }

    private ProductDetails getProductDetails_P5() {
        ProductDetails productDetails = new ProductDetails();
        productDetails.setManufacturingName("P5");
        productDetails.setPreCommercialName("PC5");
        productDetails.setProductType(ProductDetails.PRODUCT_TYPE_PARENT);
        return productDetails;
    }

    private ProductDetails getProductDetails_P12() {
        ProductDetails productDetails = new ProductDetails();
        productDetails.setManufacturingName("P12");
        productDetails.setPreCommercialName("PC12");
        productDetails.setProductType(ProductDetails.PRODUCT_TYPE_PARENT);
        return productDetails;
    }

    private ProductDetails getProductDetails_P13() {
        ProductDetails productDetails = new ProductDetails();
        productDetails.setManufacturingName("P13");
        productDetails.setPreCommercialName("PC13");
        productDetails.setProductType(ProductDetails.PRODUCT_TYPE_PARENT);
        return productDetails;
    }

    private ProductDetails getProductDetails_P14() {
        ProductDetails productDetails = new ProductDetails();
        productDetails.setManufacturingName("P14");
        productDetails.setPreCommercialName("PC14");
        productDetails.setProductType(ProductDetails.PRODUCT_TYPE_PARENT);
        return productDetails;
    }

    private ProductDetails getProductDetails_P7() {
        ProductDetails productDetails = new ProductDetails();
        productDetails.setManufacturingName("P7");
        productDetails.setPreCommercialName("P7");
        productDetails.setProductType(ProductDetails.PRODUCT_TYPE_HYBRID);
        productDetails.getParentDetailsList().add(0, new ParentDetails(ParentDetails.ROLE_FEMALE_PARENT, getProductDetails_P9()));
        productDetails.getParentDetailsList().add(1, new ParentDetails(ParentDetails.ROLE_MALE_PARENT, getProductDetails_P10()));
        return productDetails;
    }

    private ProductDetails getProductDetails_P6() {
        ProductDetails productDetails = new ProductDetails();
        productDetails.setManufacturingName("P6");
        productDetails.setPreCommercialName("PC6");
        productDetails.setProductType(ProductDetails.PRODUCT_TYPE_HYBRID);
        productDetails.getParentDetailsList().add(0, new ParentDetails(ParentDetails.ROLE_FEMALE_PARENT, getProductDetails_P7()));
        productDetails.getParentDetailsList().add(1, new ParentDetails(ParentDetails.ROLE_MALE_PARENT, getProductDetails_P8()));
        return productDetails;
    }

    private ProductDetails getProductDetails_P2() {
        ProductDetails productDetails = new ProductDetails();
        productDetails.setManufacturingName("P2");
        productDetails.setPreCommercialName("PC2");
        productDetails.setProductType(ProductDetails.PRODUCT_TYPE_HYBRID);
        productDetails.getParentDetailsList().add(0, new ParentDetails(ParentDetails.ROLE_FEMALE_PARENT, getProductDetails_P5()));
        productDetails.getParentDetailsList().add(1, new ParentDetails(ParentDetails.ROLE_MALE_PARENT, getProductDetails_P6()));
        return productDetails;
    }

    private ProductDetails getProductDetails_P11() {
        ProductDetails productDetails = new ProductDetails();
        productDetails.setManufacturingName("P11");
        productDetails.setPreCommercialName("PC11");
        productDetails.setProductType(ProductDetails.PRODUCT_TYPE_HYBRID);
        productDetails.getParentDetailsList().add(0, new ParentDetails(ParentDetails.ROLE_FEMALE_PARENT, getProductDetails_P13()));
        productDetails.getParentDetailsList().add(1, new ParentDetails(ParentDetails.ROLE_MALE_PARENT, getProductDetails_P14()));
        return productDetails;
    }

    private ProductDetails getProductDetails_P4() {
        ProductDetails productDetails = new ProductDetails();
        productDetails.setManufacturingName("P4");
        productDetails.setPreCommercialName("PC4");
        productDetails.setProductType(ProductDetails.PRODUCT_TYPE_HYBRID);
        productDetails.getParentDetailsList().add(0, new ParentDetails(ParentDetails.ROLE_FEMALE_PARENT, getProductDetails_P11()));
        productDetails.getParentDetailsList().add(1, new ParentDetails(ParentDetails.ROLE_MALE_PARENT, getProductDetails_P12()));
        return productDetails;
    }

    private ProductDetails getProductDetails_P19() {
        ProductDetails productDetails = new ProductDetails();
        productDetails.setManufacturingName("P19");
        productDetails.setPreCommercialName("PC19");
        productDetails.setProductType(ProductDetails.PRODUCT_TYPE_HYBRID);
        return productDetails;
    }

    private ProductDetails getProductDetails_P15() {
        ProductDetails productDetails = new ProductDetails();
        productDetails.setPreCommercialName("PC15");
        productDetails.setProductType(ProductDetails.PRODUCT_TYPE_HYBRID);
        productDetails.getParentDetailsList().add(0, new ParentDetails(ParentDetails.ROLE_FEMALE_PARENT, getProductDetails_P11()));
        productDetails.getParentDetailsList().add(1, new ParentDetails(ParentDetails.ROLE_MALE_PARENT, getProductDetails_P12()));
        return productDetails;
    }

    private ProductDetails getProductDetails_P18() {
        ProductDetails productDetails = new ProductDetails();
        productDetails.setPreCommercialName("PC18");
        productDetails.setProductType(ProductDetails.PRODUCT_TYPE_HYBRID);
        return productDetails;
    }

    private ProductDetails getProductDetails_P20CMS() {
        ProductDetails productDetails = new ProductDetails();
        productDetails.setManufacturingName("P20CMS");
        productDetails.setPreCommercialName("PC20CMS");
        productDetails.setProductType(ProductDetails.PRODUCT_TYPE_PARENT);
        return productDetails;
    }

    private ProductDetails getProductDetails_P20() {
        ProductDetails productDetails = new ProductDetails();
        productDetails.setManufacturingName("P20");
        productDetails.setPreCommercialName("PC20");
        productDetails.setProductType(ProductDetails.PRODUCT_TYPE_PARENT);
        return productDetails;
    }

    private ProductDetails getProductDetails_P21CMS() {
        ProductDetails productDetails = new ProductDetails();
        productDetails.setManufacturingName("P21CMS");
        productDetails.setPreCommercialName("PC21CMS");
        productDetails.setProductType(ProductDetails.PRODUCT_TYPE_PARENT);
        return productDetails;
    }
}