package com.monsanto.wst.usseedplanning.container;

import com.monsanto.wst.factory.ApplicationContainerAware;
import com.monsanto.wst.factory.GenericFactory;
import com.monsanto.wst.validator.HttpValidator;
import com.monsanto.wst.usseedplanning.controller.validator.*;

/**
 * Created by IntelliJ IDEA.
 * Date: Feb 11, 2007
 * Time: 7:29:43 PM
 * <p/>
 * TODO: Enter description for class.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class ValidatorFactory implements ApplicationContainerAware {
    /**
     * This method returns the current implementation of the stage factor validator.
     *
     * @return HttpValidator - Object representing the validator.
     */
    public HttpValidator getStageFactorValidator() {
        return new SaveStageFactorValidator();
    }

    /**
     * This method returns the current implementation of the common forecast validator.
     *
     * @return HttpValidator - Object representing the validator.
     */
    public HttpValidator getCommonForecastValidator() {
        return new AddForecastValidator();
    }

    public HttpValidator getCommitPlanValidator() {
        return new CommitPlanValidator();
    }

    public HttpValidator getPlanValidator() {
        return new PlanValidator();
    }

    public HttpValidator getCommonUploadValidator() {
        return new CommonUploadValidator();
    }

    public HttpValidator getQaThresholdInputValidator() {
        return new QaThresholdFormValidator();
    }

    /**
     * This method returns the current implementation of the update supply validator.
     *
     * @return HttpValidator - Object used to validate update supply requests.
     */
    public HttpValidator getUpdateSupplyValidator() {
        return new UpdateSupplyValidator();
    }

    public void setApplicationContainer(GenericFactory container) {
    }
}
