package com.monsanto.wst.usseedplanning.utils.testutils;

import com.monsanto.wst.commonutils.reflection.ObjectInspector;
import com.monsanto.wst.usseedplanning.constants.MainConstants;
import junit.framework.TestCase;

/**
 * Created by IntelliJ IDEA.
 * Date: Sep 12, 2006
 * Time: 3:51:16 PM
 * <p/>
 * This class is a base test case for the us seed planning project.  It sets up all the environment options a test would
 * need.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public abstract class USSeedPlanningBaseTestCase extends TestCase {
    private USSeedPlanningTestUtils testUtils;

    /**
     * Sets up the environment.
     *
     * @throws Exception - If unable to setup the environment.
     */
    protected void setUp() throws Exception {
        super.setUp();
        testUtils = new USSeedPlanningTestUtils(new ObjectInspector());
        testUtils.setupContainer();
        testUtils.setupLogging(MainConstants.APPLICATION_NAME);
    }

    /**
     * Tears down the environment.
     *
     * @throws Exception - If unable to tear down the environment.
     */
    protected void tearDown() throws Exception {
        testUtils.tearDownLogging();
        testUtils.tearDownContainer();
        super.tearDown();
    }

    /**
     * Returns the test utils object.
     *
     * @return USSeedPlanningTestUtils - Object containing test utility methods.
     */
    protected USSeedPlanningTestUtils getTestUtils() {
        return testUtils;
    }
}
