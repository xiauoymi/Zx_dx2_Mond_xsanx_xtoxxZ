package com.monsanto.wst.usseedplanning.services.maintenance.forecast;

import com.monsanto.wst.usseedplanning.dao.*;
import com.monsanto.wst.usseedplanning.exception.NoResultsException;
import com.monsanto.wst.usseedplanning.model.core.LoginUser;
import com.monsanto.wst.usseedplanning.model.maintenance.*;
import com.monsanto.wst.usseedplanning.model.planning.ChannelizedDemandRevisions;
import com.monsanto.wst.usseedplanning.model.planning.DemandRevisionCriteria;
import com.monsanto.wst.usseedplanning.model.planning.PlanType;
import com.monsanto.wst.usseedplanning.services.core.ImportSpreadsheetService;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * Date: Aug 8, 2006
 * Time: 12:07:59 PM
 * <p/>
 * This class is a generic implementation of the ForecastService.  It is used to retrieve and modify forecast
 * information.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class ForecastServiceImpl implements ForecastService {
    private ImportSpreadsheetService importSpreadsheetService;
    private DemandDao demandDao;
    private ChannelDao channelDao;
    private RevisionDao revisionDao;
    private YearDao yearDao;

    /**
     * This constructor takes all dependencies.
     *
     * @param importSpreadsheetService SpreadsheetService object for converting spreadsheets into objects.
     * @param demandDao DemandDao object for retrieving and modifying demand information.
     * @param channelDao ChannelDao object for retrieving and modifying channel information.
     * @param revisionDao
     * @param yearDao
     */
    public ForecastServiceImpl(ImportSpreadsheetService importSpreadsheetService, DemandDao demandDao,
                               ChannelDao channelDao, RevisionDao revisionDao, YearDao yearDao) {
        this.importSpreadsheetService = importSpreadsheetService;
        this.demandDao = demandDao;
        this.channelDao = channelDao;
        this.revisionDao = revisionDao;
        this.yearDao = yearDao;
    }

    /**
     * This method adds a list of common forecasts containing in the specified spreadsheet to the system.
     *
     * TODO: Change this to take the plan type id instead of name.
     *
     * @param spreadsheet File representing the spreadsheet with the data.
     * @param planTypeId
     * @param currentUser LoginUser object representing the current user.
     * @param comments String representing revision comments.
     * @throws IOException - If unable to read the spreadsheet.
     */
    public void addCommonForecasts(File spreadsheet, Long planTypeId, LoginUser currentUser, String comments)
            throws IOException, InvalidForecastException {
        List demandForecastList = this.importSpreadsheetService.getCommonForecasts(spreadsheet);
        Revision revision = new Revision("Adding Common Forecast", comments, currentUser);
        this.revisionDao.insert(revision);
        for (int i = 0; i < demandForecastList.size(); i++) {
            DemandForecast forecast = (DemandForecast) demandForecastList.get(i);
            forecast.setRevision(revision);
            forecast.setPlanTypeId(planTypeId);
            forecast.setOwner(currentUser);
            forecast.setChannel(lookupChannel(forecast.getChannel().getName(), planTypeId));
            forecast.setNameType(lookupNameType(forecast.getChannel()));
        }
        this.demandDao.addDemand(demandForecastList);
        insertNextYearDemand(demandForecastList);
    }

    /**
     * This method adds a list of common forecasts containing in the specified spreadsheet to the system.
     *
     * @param spreadsheet File representing the spreadsheet with the data.
     * @param currentUser LoginUser object representing the current user.
     * @param comments String representing revision comments.
     * @throws IOException - If unable to read the spreadsheet.
     */
    public void addDemandForecasts(File spreadsheet, LoginUser currentUser, String comments)
            throws IOException, InvalidForecastException {
        List demandForecastList = this.importSpreadsheetService.getDemandForecasts(spreadsheet);
        Revision revision = new Revision("Adding Demand Forecast", comments, currentUser);
        this.revisionDao.insert(revision);
        Channel channel = lookupChannel(Channel.BRANDED_CHANNEL, PlanType.HYBRID_PLAN_TYPE_ID);
        Year year = yearDao.lookupCurrentYear();
        NameType nameType = lookupNameType(channel);
        for (int i = 0; i < demandForecastList.size(); i++) {
            DemandForecast forecast = (DemandForecast) demandForecastList.get(i);
            forecast.setRevision(revision);
            forecast.setPlanTypeId(PlanType.HYBRID_PLAN_TYPE_ID);
            forecast.setOwner(currentUser);
            forecast.getData().setWinterUnits(new Long(0));
            forecast.setChannel(channel);
            forecast.setYear(year.getYear());
            forecast.setNameType(nameType);
        }
        this.demandDao.addDemand(demandForecastList);
    }

    /**
     * This method returns a map of channels to demand revisions.
     *
     * @param planTypeId
     * @return List - Representing the channels to demand revisions.
     */
    public List lookupDemandRevisionByChannel(Long planTypeId) {
        List channelList = this.channelDao.lookupAllByPlanType(planTypeId);
        Year year = this.yearDao.lookupCurrentYear();
        List results = new ArrayList();
        for (int i = 0; i < channelList.size(); i++) {
            Channel channel = (Channel) channelList.get(i);
            DemandRevisionCriteria criteria = new DemandRevisionCriteria(channel.getId(), year.getYear(), planTypeId);
            List revisionList = this.demandDao.lookupRevisionsByCriteria(criteria);
            results.add(new ChannelizedDemandRevisions(channel, revisionList));
        }
        return results;
    }

    /**
     * This method process the channel retrieving additional information based on what was provided.
     *
     @param channelName
      * @param planTypeId
     */
    private Channel lookupChannel(String channelName, Long planTypeId) throws InvalidForecastException {
        try {
            ChannelCriteria criteria = new ChannelCriteria(channelName, planTypeId);
            return this.channelDao.lookupChannelByName(criteria);
        } catch (NoResultsException e) {
            throw new InvalidForecastException("Unable to find channel: '" + channelName +
                    "' in the system.");
        }
    }

    /**
     * This method updates the product name if necessary.
     *
     * @param channel
     */
    private NameType lookupNameType(Channel channel) throws InvalidForecastException {
        try {
            return this.channelDao.lookupChannelNameType(channel.getId());
        } catch (NoResultsException e) {
            throw new InvalidForecastException("Unable to determine the appropriate product name type based on the " +
                    "channel: '" + channel.getName() + "' and the plan type specified.");
        }
    }

    /**
     * This method inserts demand for next year.
     *
     * @param demandForecastList
     */
    private void insertNextYearDemand(List demandForecastList) {
        for (int i = 0; i < demandForecastList.size(); i++) {
            DemandForecast demandForecast = (DemandForecast) demandForecastList.get(i);
            demandForecast.getData().setUnits(demandForecast.getData().getNextYearUnits());
            demandForecast.getData().setWinterUnits(new Long(0));
            demandForecast.setYear(new Integer(demandForecast.getYear().intValue() + 1));
        }
        this.demandDao.addDemand(demandForecastList);
    }

}
