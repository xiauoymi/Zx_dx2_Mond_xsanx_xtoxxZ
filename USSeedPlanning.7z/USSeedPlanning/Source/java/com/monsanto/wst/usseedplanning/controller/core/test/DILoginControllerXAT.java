package com.monsanto.wst.usseedplanning.controller.core.test;

import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.ServletFramework.UseCaseController;
import com.monsanto.securityinterfaces.SystemSecurityProxy;
import com.monsanto.securityinterfaces.Test.MockSystemSecurityProxy;
import com.monsanto.wst.commonutils.reflection.ObjectInspector;
import com.monsanto.wst.dbtemplate.transaction.TransactionManager;
import com.monsanto.wst.factory.AbstractGenericFactory;
import com.monsanto.wst.factory.AbstractLocatorGenericFactory;
import com.monsanto.wst.factory.BeanInitializationException;
import com.monsanto.wst.servletframework.DITransactionalController;
import com.monsanto.wst.usseedplanning.controller.core.DILoginController;
import com.monsanto.wst.usseedplanning.services.core.LoginService;
import com.monsanto.wst.usseedplanning.services.core.LookupService;
import com.monsanto.wst.usseedplanning.services.core.UserRoleService;
import com.monsanto.wst.usseedplanning.services.core.mock.MockLoginService;
import com.monsanto.wst.usseedplanning.services.core.mock.MockLookupService;
import com.monsanto.wst.usseedplanning.services.core.mock.MockUserRoleService;
import com.monsanto.wst.usseedplanning.utils.testutils.USSeedPlanningBaseTransactionTestCase;
import com.monsanto.wst.usseedplanning.view.factory.ViewFactory;
import com.monsanto.wst.usseedplanning.view.factory.mock.MockViewFactory;
import com.monsanto.wst.usseedplanning.constants.MainConstants;
import com.monsanto.wst.usseedplanning.model.core.LoginUser;

import java.io.IOException;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Aug 3, 2006
 * Time: 1:42:56 PM
 * To change this template use File | Settings | File Templates.
 */
public class DILoginControllerXAT extends USSeedPlanningBaseTransactionTestCase {
    LoginMockUCCHelper helper = null;

    protected void setUp() throws Exception {
        super.setUp();
        helper = new LoginMockUCCHelper("/");
        TransactionManager txManager = (TransactionManager) AbstractGenericFactory.getInstance().getBean("transactionManager");
        helper.setContextAttribute(DITransactionalController.TRANSACTION_MANAGER_CTX_ATTRIBUTE, txManager);
    }

    protected String getConfigPath() {
        return "com/monsanto/wst/usseedplanning/dao/test/dbUnit/commonUploadDataSet.xml";
    }

    protected void cleanDatabase(TransactionManager txManager) {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    public void testCreate() throws Exception {
        DILoginController controller = new DILoginController();
        assertNotNull(controller);
    }

    public void testLoginSuccess() throws Exception {
        DILoginController controller = new DILoginController();
        controller.run(helper);
        LoginUser currentUser = (LoginUser) helper.getSessionParameter(MainConstants.LOGINUSER);
        assertNotNull(currentUser);
    }

    private class LoginMockUCCHelper extends MockUCCHelper {
        private String contextPath;
        private int maxImportSize;

        public LoginMockUCCHelper(String cstrRequestedURL) {
            super(cstrRequestedURL);
        }

        public LoginMockUCCHelper(String cstrRequestedURL, String cstrServletName) {
            super(cstrRequestedURL, cstrServletName);
        }

        public LoginMockUCCHelper(String cstrRequestedURL, boolean systemSecurityEnabled, SystemSecurityProxy proxy) {
            super(cstrRequestedURL, systemSecurityEnabled, proxy);
        }

        public Date getLastLogon() {
            return new Date();
        }

        public LoginMockUCCHelper(String cstrRequestedURL, boolean boolApplyStylesheet) {
            super(cstrRequestedURL, boolApplyStylesheet);
        }

        public String getAuthenticatedUserID() {
            return "DBUNIT";
        }

        public String getAuthenticatedUserFullName() {
            return "GEORGE, RIJO C [AG/CONTRACTOR - 1000]";
        }

        public void setContextPath(String contextPath) {
            this.contextPath = contextPath;
        }

        public String getContextPath() {
            return this.contextPath;
        }

        public SystemSecurityProxy getSystemSecurityProxy() {
            return new MockSystemSecurityProxy();
        }

        public int setMaxImportFileSize(int iMaxSize) {
            this.maxImportSize = iMaxSize;
            return 0;
        }

        public int getMaxImportFileSize() {
            return this.maxImportSize;
        }
    }

    private static class MockController implements UseCaseController {
        private boolean wasCalled = false;

        public void run(UCCHelper helper) throws IOException {
            this.wasCalled = true;
        }

        public boolean wasRunCalled() {
            return this.wasCalled;
        }
    }

    public static class MockGenericFactory extends AbstractLocatorGenericFactory {
        private UseCaseController controller = new MockController();
        private String beanId;
        private MockLoginService loginService = new MockLoginService();
        private MockUserRoleService userRoleService = new MockUserRoleService();
        private MockLookupService lookupService = new MockLookupService();
        private MockViewFactory viewFactory = new MockViewFactory();
        private Map addedBeans = new HashMap();

        public MockGenericFactory() {
            super(new ObjectInspector());
        }

        public Object getBean(String beanId) throws BeanInitializationException {
            this.beanId = beanId;
            if ("/test".equals(beanId)) {
                return controller;
            } else if ("systemSecurityProxy".equals(beanId)) {
                return getSystemSecurityProxy();
            } else if (addedBeans.containsKey(beanId)) {
                return addedBeans.get(beanId);
            }
            return super.getBean(beanId);
        }

        public void addBean(String beanId, Object obj, boolean isSingleton) {
            this.addedBeans.put(beanId, obj);
        }

        public String getBeanId() {
            return this.beanId;
        }

        private LoginService getLoginService() {
            return this.loginService;
        }

        private UserRoleService getUserRoleService() {
            return this.userRoleService;
        }

        private LookupService getLookupService() {
            return this.lookupService;
        }

        private ViewFactory getViewFactory() {
            return this.viewFactory;
        }

        private String getDataSourceConfigFile() {
            return "database/dbtemplate-config.xml";
        }

        private SystemSecurityProxy getSystemSecurityProxy() {
            return (SystemSecurityProxy) this.addedBeans.get("systemSecurityProxy");
        }
    }
}
