package com.monsanto.wst.usseedplanning.controller.validator.test;

import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.wst.usseedplanning.controller.validator.AddForecastValidator;
import com.monsanto.wst.validator.HttpRequestErrors;
import junit.framework.TestCase;

/**
 * Created by IntelliJ IDEA.
 * Date: Aug 15, 2006
 * Time: 9:59:01 AM
 * <p/>
 * Unit test for the CommonForecastValidator object.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class AddForecastValidatorUT extends TestCase {
    public void testCreate() throws Exception {
        AddForecastValidator validator = new AddForecastValidator();
        assertNotNull(validator);
    }

    public void testValidatePass() throws Exception {
        AddForecastValidator validator = new AddForecastValidator();
        MockUCCHelper helper = createRequest();
        HttpRequestErrors errors = validator.validate(helper);
        assertTrue(errors.isEmpty());
    }

    public void testValidateFail() throws Exception {
        AddForecastValidator validator = new AddForecastValidator();
        MockUCCHelper helper = new MockUCCHelper(null);
        HttpRequestErrors errors = validator.validate(helper);
        assertFalse(errors.isEmpty());
        assertEquals("The Comment field is required.", errors.getError("comment"));
        assertEquals("The File field is required.", errors.getError("forecastFile"));
    }

    private MockUCCHelper createRequest() {
        MockUCCHelper helper = new MockUCCHelper(null);
        helper.setRequestParameterValue("comments", "Test Message");
        helper.addClientFile("");
        return helper;
    }
}
