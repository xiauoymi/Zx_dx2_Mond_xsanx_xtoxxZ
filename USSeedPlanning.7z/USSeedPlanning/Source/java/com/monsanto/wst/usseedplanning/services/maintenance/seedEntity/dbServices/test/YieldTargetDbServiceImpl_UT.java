package com.monsanto.wst.usseedplanning.services.maintenance.seedEntity.dbServices.test;

import com.monsanto.wst.usseedplanning.dao.mock.MockRevisionDao;
import com.monsanto.wst.usseedplanning.dao.mock.MockYieldTargetDAO;
import com.monsanto.wst.usseedplanning.model.maintenance.Gender;
import com.monsanto.wst.usseedplanning.model.maintenance.Revision;
import com.monsanto.wst.usseedplanning.model.maintenance.Year;
import com.monsanto.wst.usseedplanning.model.maintenance.YieldTargetFactor;
import com.monsanto.wst.usseedplanning.services.maintenance.seedEntity.dbServices.YieldTargetDbServiceImpl;
import junit.framework.TestCase;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA. User: rgeorge Date: Aug 8, 2006 Time: 11:09:35 AM To change this template use File |
 * Settings | File Templates.
 */
public class YieldTargetDbServiceImpl_UT extends TestCase {
  private MockYieldTargetDAO mockYieldTargetDAO;
  private MockRevisionDao mockRevisionDao;

  protected void setUp() throws IOException {
    mockYieldTargetDAO = new MockYieldTargetDAO();
    mockRevisionDao = new MockRevisionDao();
  }

  public void testCreate() throws Exception {
    YieldTargetDbServiceImpl service = new YieldTargetDbServiceImpl(mockYieldTargetDAO, mockRevisionDao);
    assertNotNull(service);
  }

  public void testGetAllApplicableYieldTargetFactorsInOrderOfPrecedenceListNotNull() throws Exception {
    YieldTargetDbServiceImpl yieldTargetDbService = new YieldTargetDbServiceImpl(mockYieldTargetDAO, mockRevisionDao);
    List yieldTargets = yieldTargetDbService
        .getAllApplicableYieldTargetFactorsInOrderOfPrecedence(null, null, null, new Long(1));
    assertNotNull(yieldTargets);
  }

  public void testGetAllApplicableYieldTargetFactorsInOrderOfPrecedenceListValidateOrder() throws Exception {
    YieldTargetFactor factor1 = new YieldTargetFactor();
    factor1.setProductName("test");
    YieldTargetFactor factor2 = new YieldTargetFactor();
    factor2.setProductName("test1");
    YieldTargetFactor factor3 = new YieldTargetFactor();
    factor3.setProductName(null);
    YieldTargetFactor factor4 = new YieldTargetFactor();
    factor4.setProductName("anotherFactor");


    mockYieldTargetDAO.insert(factor1);
    mockYieldTargetDAO.insert(factor2);
    mockYieldTargetDAO.insert(factor3);
    mockYieldTargetDAO.insert(factor4);
    YieldTargetDbServiceImpl yieldTargetDbService = new YieldTargetDbServiceImpl(mockYieldTargetDAO, mockRevisionDao);
    List yieldTargets = yieldTargetDbService
        .getAllApplicableYieldTargetFactorsInOrderOfPrecedence("test", null, null, new Long(1));
    YieldTargetFactor factor = (YieldTargetFactor) yieldTargets.get(0);
    assertEquals("test", factor.getProductName());
    assertEquals(2, yieldTargets.size());
  }

  public void testGetAllApplicableYieldTargetFactorsInOrderOfPrecedenceListValidateOrderDefaultOnlyApplicable() throws
      Exception {
    YieldTargetFactor factor1 = new YieldTargetFactor();
    factor1.setProductName("test");
    YieldTargetFactor factor2 = new YieldTargetFactor();
    factor2.setProductName("test1");
    YieldTargetFactor factor3 = new YieldTargetFactor();
    factor3.setProductName(null);
    YieldTargetFactor factor4 = new YieldTargetFactor();
    factor4.setProductName("anotherFactor");

    mockYieldTargetDAO.insert(factor1);
    mockYieldTargetDAO.insert(factor2);
    mockYieldTargetDAO.insert(factor3);
    mockYieldTargetDAO.insert(factor4);
    YieldTargetDbServiceImpl yieldTargetDbService = new YieldTargetDbServiceImpl(mockYieldTargetDAO, mockRevisionDao);
    List yieldTargets = yieldTargetDbService
        .getAllApplicableYieldTargetFactorsInOrderOfPrecedence("test7", null, null, new Long(1));
    YieldTargetFactor factor = (YieldTargetFactor) yieldTargets.get(0);
    assertEquals(null, factor.getProductName());
    assertEquals(1, yieldTargets.size());
  }


  public void testGetAllApplicableYieldTargetFactorsInOrderOfPrecedenceListValidateOrderMultipleFieldsConsidered() throws
      Exception {

    YieldTargetFactor factor1 = getYieldTargetFactor("test", getYear(100), null, Boolean.TRUE, 12, 15);
    YieldTargetFactor factor2 = getYieldTargetFactor("test", null, getGender(200), Boolean.TRUE, 12, 15);
    YieldTargetFactor factor3 = getYieldTargetFactor(null, null, null, Boolean.TRUE, 12, 15);
    YieldTargetFactor factor4 = getYieldTargetFactor("anotherFactor", null, null, Boolean.TRUE, 12, 15);

    mockYieldTargetDAO.insert(factor1);
    mockYieldTargetDAO.insert(factor2);
    mockYieldTargetDAO.insert(factor3);
    mockYieldTargetDAO.insert(factor4);
    YieldTargetDbServiceImpl yieldTargetDbService = new YieldTargetDbServiceImpl(mockYieldTargetDAO, mockRevisionDao);
    List yieldTargets = yieldTargetDbService
        .getAllApplicableYieldTargetFactorsInOrderOfPrecedence("test", new Long(100), new Long(200), new Long(1));
    YieldTargetFactor factor = (YieldTargetFactor) yieldTargets.get(0);
    assertEquals(3, yieldTargets.size());

    assertEquals("test", factor.getProductName());
    assertEquals(new Long(100), factor.getTargetYear().getId());

    factor = (YieldTargetFactor) yieldTargets.get(1);

    assertEquals("test", factor.getProductName());
    assertEquals(new Long(200), factor.getGender().getId());

    assertEquals(new Double(15), factor.getFinishedStandFactor());
  }

  public void testGetAllApplicableYieldTargetFactorsInOrderOfPrecedenceListValidateOrderMultipleFieldsConsideredMultipleDefaults() throws
      Exception {
    YieldTargetFactor factor1 = getYieldTargetFactor("test", getYear(100), getGender(200), Boolean.TRUE, 12, 15);
    YieldTargetFactor factor2 = getYieldTargetFactor("test", null, getGender(200), Boolean.TRUE, 12, 15);
    YieldTargetFactor factor3 = getYieldTargetFactor(null, null, null, Boolean.TRUE, 12, 15);
    YieldTargetFactor factor4 = getYieldTargetFactor(null, null, null, Boolean.TRUE, 12, 15);

    mockYieldTargetDAO.insert(factor1);
    mockYieldTargetDAO.insert(factor2);
    mockYieldTargetDAO.insert(factor3);
    mockYieldTargetDAO.insert(factor4);
    YieldTargetDbServiceImpl yieldTargetDbService = new YieldTargetDbServiceImpl(mockYieldTargetDAO, mockRevisionDao);
    List yieldTargets = yieldTargetDbService
        .getAllApplicableYieldTargetFactorsInOrderOfPrecedence("test", new Long(100), new Long(200), new Long(1));
    YieldTargetFactor factor = (YieldTargetFactor) yieldTargets.get(0);
    assertEquals(3, yieldTargets.size());

    assertEquals("test", factor.getProductName());
    assertEquals(new Long(100), factor.getTargetYear().getId());

    factor = (YieldTargetFactor) yieldTargets.get(1);

    assertEquals("test", factor.getProductName());
    assertEquals(new Long(200), factor.getGender().getId());

    assertEquals(new Double(15), factor.getFinishedStandFactor());
  }

  public void testGetAllApplicableYieldTargetFactorsInOrderOfPrecedenceListValidateOrderNoneMatchingButDefault() throws
      Exception {

    YieldTargetFactor factor1 = getYieldTargetFactor("test", getYear(100), getGender(200), Boolean.TRUE, 12, 15);
    YieldTargetFactor factor2 = getYieldTargetFactor("test", null, getGender(200), Boolean.TRUE, 12, 15);
    YieldTargetFactor factor3 = getYieldTargetFactor(null, null, null, Boolean.TRUE, 12, 15);
    YieldTargetFactor factor4 = getYieldTargetFactor(null, null, null, Boolean.TRUE, 12, 15);

    mockYieldTargetDAO.insert(factor1);
    mockYieldTargetDAO.insert(factor2);
    mockYieldTargetDAO.insert(factor3);
    mockYieldTargetDAO.insert(factor4);
    YieldTargetDbServiceImpl yieldTargetDbService = new YieldTargetDbServiceImpl(mockYieldTargetDAO, mockRevisionDao);
    List yieldTargets = yieldTargetDbService
        .getAllApplicableYieldTargetFactorsInOrderOfPrecedence("test", new Long(100), new Long(23), new Long(1));
    YieldTargetFactor factor = (YieldTargetFactor) yieldTargets.get(0);
    assertEquals(1, yieldTargets.size());

    assertEquals(null, factor.getProductName());
    assertEquals(null, factor.getTargetYear());


  }

  public void testGetAllApplicableYieldTargetFactorsInOrderOfPrecedenceListRealUseCase() throws Exception {
    Year year2005 = getYear(1);
    Year year2006 = getYear(2);
    Gender genderM = getGender(1);
    Gender genderY = getGender(2);
    YieldTargetFactor factor1 = getYieldTargetFactor(null, year2005, null, Boolean.TRUE, 4.5, 65);
    YieldTargetFactor factor2 = getYieldTargetFactor(null, year2005, null, Boolean.TRUE, 12, 15);
    YieldTargetFactor factor3 = getYieldTargetFactor(null, year2005, null, Boolean.TRUE, 32, 44);
    YieldTargetFactor factor4 = getYieldTargetFactor("Product1", year2005, null, Boolean.TRUE, 12, 15);
    YieldTargetFactor factor5 = getYieldTargetFactor("Product1", year2005, null, Boolean.FALSE, 12, 15);
    YieldTargetFactor factor6 = getYieldTargetFactor("Product2", year2006, null, Boolean.TRUE, 12, 15);
    YieldTargetFactor factor7 = getYieldTargetFactor(null, null, null, Boolean.TRUE, 12, 15);

    mockYieldTargetDAO.insert(factor1);
    mockYieldTargetDAO.insert(factor2);
    mockYieldTargetDAO.insert(factor3);
    mockYieldTargetDAO.insert(factor4);
    mockYieldTargetDAO.insert(factor5);
    mockYieldTargetDAO.insert(factor6);
    mockYieldTargetDAO.insert(factor7);

    YieldTargetDbServiceImpl yieldTargetDbService = new YieldTargetDbServiceImpl(mockYieldTargetDAO, mockRevisionDao);
    List yieldTargets = yieldTargetDbService
        .getAllApplicableYieldTargetFactorsInOrderOfPrecedence("Product2", year2005.getId(), null, new Long(1));
    YieldTargetFactor factor = (YieldTargetFactor) yieldTargets.get(0);
    assertEquals(4, yieldTargets.size());

    assertEquals(null, factor.getProductName());
    assertEquals(year2005, factor.getTargetYear());


  }


  public void testGetMostAppropriateYieldTargetFactor() throws Exception {
    YieldTargetFactor factor1 = new YieldTargetFactor();
    factor1.setProductName("test");
    factor1.setActiveStatus(Boolean.TRUE);
    YieldTargetFactor factor2 = new YieldTargetFactor();
    factor2.setProductName("test1");
    YieldTargetFactor factor3 = new YieldTargetFactor();
    factor3.setProductName(null);
    YieldTargetFactor factor4 = new YieldTargetFactor();
    factor4.setProductName("anotherFactor");


    mockYieldTargetDAO.insert(factor1);
    mockYieldTargetDAO.insert(factor2);
    mockYieldTargetDAO.insert(factor3);
    mockYieldTargetDAO.insert(factor4);
    YieldTargetDbServiceImpl yieldTargetDbService = new YieldTargetDbServiceImpl(mockYieldTargetDAO, mockRevisionDao);
    YieldTargetFactor factor = yieldTargetDbService
        .getMostAppropriateYieldTargetFactor("test", null, null, new Long(1));
    assertEquals("test", factor.getProductName());

  }

  public void testRemoveNotApplicableYieldTargetFactorsFromList() throws Exception {
    YieldTargetDbServiceImpl yieldTargetDbService = new YieldTargetDbServiceImpl(mockYieldTargetDAO, mockRevisionDao);

    YieldTargetFactor factor1 = getYieldTargetFactor("test", getYear(100), getGender(200), Boolean.TRUE, 12, 15);
    YieldTargetFactor factor2 = getYieldTargetFactor("test", null, getGender(200), Boolean.TRUE, 12, 15);
    YieldTargetFactor factor3 = getYieldTargetFactor(null, null, null, Boolean.TRUE, 12, 15);
    YieldTargetFactor factor4 = getYieldTargetFactor(null, null, null, Boolean.TRUE, 12, 15);
    List factors = new ArrayList();
    factors.add(factor1);
    factors.add(factor2);
    factors.add(factor3);
    factors.add(factor4);

    List yieldTargets = yieldTargetDbService.removeNotApplicableYieldTargetFactorsFromListSortedByPrecedence(factors);
    YieldTargetFactor factor = (YieldTargetFactor) yieldTargets.get(0);
    assertEquals(3, yieldTargets.size());

  }


  public void testRemoveNotApplicableYieldTargetFactorsFromListOnlyDefaultInList() throws Exception {
    YieldTargetDbServiceImpl yieldTargetDbService = new YieldTargetDbServiceImpl(mockYieldTargetDAO, mockRevisionDao);

    YieldTargetFactor factor1 = getYieldTargetFactor(null, null, null, Boolean.TRUE, 12, 15);
    List factors = new ArrayList();
    factors.add(factor1);

    List yieldTargets = yieldTargetDbService.removeNotApplicableYieldTargetFactorsFromListSortedByPrecedence(factors);
    YieldTargetFactor factor = (YieldTargetFactor) yieldTargets.get(0);
    assertEquals(1, yieldTargets.size());

  }


  public void testRemoveNotApplicableYieldTargetFactorsFromListGenderAndYearsWithNullIds() throws Exception {
    YieldTargetDbServiceImpl yieldTargetDbService = new YieldTargetDbServiceImpl(mockYieldTargetDAO, mockRevisionDao);

    Gender gender = new Gender();
    gender.setId(new Long(200));
    YieldTargetFactor factor1 = getYieldTargetFactor("test", new Year(new Long(100), new Integer(2006), "testDesc",
        Boolean.TRUE,
        Boolean.FALSE), gender, Boolean.TRUE, 12, 15);
    YieldTargetFactor factor2 = getYieldTargetFactor("test", new Year(), gender, Boolean.TRUE, 12, 15);
    YieldTargetFactor factor3 = getYieldTargetFactor(null, new Year(), null, Boolean.TRUE, 12, 15);
    YieldTargetFactor factor4 = getYieldTargetFactor(null, null, new Gender(), Boolean.TRUE, 12, 15);
    List factors = new ArrayList();
    factors.add(factor1);
    factors.add(factor2);
    factors.add(factor3);
    factors.add(factor4);

    assertEquals(3,
        yieldTargetDbService.removeNotApplicableYieldTargetFactorsFromListSortedByPrecedence(factors).size());
  }

  private YieldTargetFactor getYieldTargetFactor(String productName, Year year, Gender gender, Boolean activeStatus,
                                                 double yieldTargetFactor, double finishedStandFactor) throws
      ParseException {
    return new YieldTargetFactor(new Revision(null, "testComment", null, null, null, null),
        productName,
        year, gender,
        activeStatus, new Double(yieldTargetFactor), new Double(finishedStandFactor),
        "testLoginUser", new SimpleDateFormat("mm/dd/yyyy").parse("01/01/2006"));
  }

  private Year getYear(long id) {
    return new Year(new Long(id), new Integer(2006), "testDesc", Boolean.TRUE, Boolean.FALSE);
  }

  private Gender getGender(long id) {
    Gender gender = new Gender();
    gender.setId(new Long(id));
    return gender;
  }


}