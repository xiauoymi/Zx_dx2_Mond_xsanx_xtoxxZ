/*
 LexiconServiceErrorHandler_UT was created on Mar 9, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.usseedplanning.services.cache.test;

import junit.framework.TestCase;
import com.monsanto.wst.usseedplanning.services.cache.ErrorHandler;
import com.monsanto.wst.usseedplanning.services.cache.LexiconServiceErrorHandler;
import com.monsanto.wst.usseedplanning.services.cache.lexiconclientservices.LexiconProductServiceException;
import com.monsanto.Util.FileUtil;

import java.io.File;

/**
 * Filename:    $RCSfile: LexiconServiceErrorHandler_UT.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: vrbethi $    	 On:	$Date: 2007-03-12 15:29:19 $
 *
 * @author vrbethi
 * @version $Revision: 1.1 $
 */
public class LexiconServiceErrorHandler_UT extends TestCase {

    public void testNotifyError_WriteToErrorFile() throws Exception {
        String fileName = "c:/batchlexiconoutput.txt";
        ErrorHandler errorHandler = new LexiconServiceErrorHandler(fileName);
        errorHandler.notifyError(new LexiconProductServiceException("test message",new Exception()));
        errorHandler.saveAndClose();
        String outputString = FileUtil.readFileToString(new File(fileName));
        assertEquals("\ntest message",outputString);
    }
}