/*
 ProductService was created on Oct 1, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.usseedplanning.services.cache.lexiconclientservices;

import java.util.List;

/**
 * Filename:    $RCSfile: ProductService.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: njminsh $    	 On:	$Date: 2007-01-31 22:39:38 $
 *
 * @author VRBETHI
 * @version $Revision: 1.1 $
 */
public interface ProductService {

  String getPreCommercialNameFromCommercialName(String commercialName) throws Exception;

  List getProductDetailsListByPreCommercialName(String preCommercialName) throws Exception;

  List getProductDetailsListByManufacturingName(String manufacturingName) throws Exception;
}