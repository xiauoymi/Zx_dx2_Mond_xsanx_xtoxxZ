package com.monsanto.wst.usseedplanning.services.planning.test;

import com.monsanto.wst.emailtemplate.domain.EmailHeaderInfo;
import com.monsanto.wst.emailtemplate.services.EmailService;
import com.monsanto.wst.usseedplanning.dao.*;
import com.monsanto.wst.usseedplanning.dao.mock.*;
import com.monsanto.wst.usseedplanning.model.cache.ProductDetails;
import com.monsanto.wst.usseedplanning.model.core.LoginUser;
import com.monsanto.wst.usseedplanning.model.maintenance.Channel;
import com.monsanto.wst.usseedplanning.model.maintenance.DemandForecast;
import com.monsanto.wst.usseedplanning.model.maintenance.NameType;
import com.monsanto.wst.usseedplanning.model.planning.*;
import com.monsanto.wst.usseedplanning.services.cache.ProductCachingService;
import com.monsanto.wst.usseedplanning.services.cache.ProductCachingServiceImpl;
import com.monsanto.wst.usseedplanning.services.cache.ProductLookupService;
import com.monsanto.wst.usseedplanning.services.cache.mock.MockProductLookupService;
import com.monsanto.wst.usseedplanning.services.core.ExportSpreadsheetService;
import com.monsanto.wst.usseedplanning.services.core.ImportSpreadsheetService;
import com.monsanto.wst.usseedplanning.services.core.LoginService;
import com.monsanto.wst.usseedplanning.services.core.mock.MockExportSpreadsheetService;
import com.monsanto.wst.usseedplanning.services.core.mock.MockImportSpreadsheetService;
import com.monsanto.wst.usseedplanning.services.core.mock.MockLoginService;
import com.monsanto.wst.usseedplanning.services.planning.PlanServiceImpl;
import junit.framework.TestCase;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA. Date: Sep 12, 2006 Time: 11:26:08 AM <p/> Unit test for the plan service object.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class PlanServiceImplUT extends TestCase {
  public void testCreate() throws Exception {
    PlanServiceImpl planService = new PlanServiceImpl((PlanDao) null, (RevisionDao) null,
      (ProductLookupService) null, (YearDao) null, (ExportSpreadsheetService) null,
      (ProductDetailsDao) null, (ImportSpreadsheetService) null, (DemandDao) null, (EmailService) null,
      (LoginService) null, (ChannelDao) null, (PlanTypeDao) null, (ProductCachingService) null);
    assertNotNull(planService);
  }

  public void testGeneratePlan() throws Exception {
    MockRevisionDao revisionDao = new MockRevisionDao();
    MockPlanDao planDao = new MockPlanDao();
    MockProductLookupService productLookupService = new MockProductLookupService();
    MockYearDao yearDao = new MockYearDao();
    MockExportSpreadsheetService exportSpreadsheetService = new MockExportSpreadsheetService();
    MockProductDetailsDao productDetailsDao = new MockProductDetailsDao();
    MockImportSpreadsheetService importSpreadsheetService = new MockImportSpreadsheetService();
    MockEmailService emailService = new MockEmailService();
    MockLoginService loginService = new MockLoginService();
    PlanServiceImpl planService = new PlanServiceImpl(planDao, revisionDao, productLookupService, yearDao,
      exportSpreadsheetService, productDetailsDao, importSpreadsheetService, (DemandDao) null,
      emailService, loginService, (ChannelDao) null, new MockPlanTypeDao(),
      new ProductCachingServiceImpl(productDetailsDao, productLookupService, revisionDao));
    PlanSummary summary = new PlanSummary("Test Plan");
    PlanCriteria planCriteria = new PlanCriteria(new Long(12345), PlanType.HYBRID_PLAN_TYPE_ID, null, null);
    LoginUser currentUser = new LoginUser("Tester");
    currentUser.setEmail("tester@monsanto.com");
    DemandCriteria demandCriteria = new DemandCriteria(new Long(12345), new Long(67890));
    planCriteria.addDemandCriteria(demandCriteria);
    planCriteria.addDemandCriteria(new DemandCriteria(new Long(54321), new Long(98765)));
    planService.generatePlan(summary, planCriteria, currentUser);
    assertNotNull(planDao.getPlan());
    assertNotNull(planDao.getPlan().getPlanType().getId());
    assertNotNull(planDao.getPlan().getPlanType().getName());
    assertEquals(new Integer(0), planDao.getPlan().getPlanSummary().getMinorVersion());
    assertEquals(yearDao.lookupCurrentYear().getYear(), planDao.getPlan().getYear().getYear());
    assertNotNull(planDao.getPlan().getRevision());
    assertTrue(revisionDao.wasRevisionAdded(planDao.getPlan().getRevision()));
    assertNotNull(planDao.getPlan().getSupplyRevision());
    assertEquals("Test Plan", planDao.getPlan().getPlanSummary().getName());
    assertEquals(new Integer(1), planDao.getPlan().getPlanSummary().getMajorVersion());
    assertEquals(new Integer(0), planDao.getPlan().getPlanSummary().getMinorVersion());
    assertEquals(planDao.getLastModifiedDate(), planDao.getPlan().getPlanSummary().getLastModifiedDate());
    assertNotNull(planDao.getPlan().getEntries());
    assertEquals(10, planDao.getPlan().getEntries().size());
    assertEquals(10, planDao.getPlanEntries().size());
    PlanEntry entry = (PlanEntry) planDao.getPlan().getEntries().get(0);
    checkFirstPlanEntry(entry, planCriteria, planDao, demandCriteria, currentUser, yearDao, productDetailsDao);
    checkEmailSent(emailService);
  }

  public void testLookupPlanById() throws Exception {
    MockRevisionDao revisionDao = new MockRevisionDao();
    MockPlanDao planDao = new MockPlanDao();
    MockProductLookupService productLookupService = new MockProductLookupService();
    MockYearDao yearDao = new MockYearDao();
    MockExportSpreadsheetService exportSpreadsheetService = new MockExportSpreadsheetService();
    MockProductDetailsDao productDetailsDao = new MockProductDetailsDao();
    MockImportSpreadsheetService importSpreadsheetService = new MockImportSpreadsheetService();
    MockEmailService emailService = new MockEmailService();
    MockLoginService loginService = new MockLoginService();
    PlanServiceImpl planService = new PlanServiceImpl(planDao, revisionDao, productLookupService, yearDao,
      exportSpreadsheetService, productDetailsDao, importSpreadsheetService, (DemandDao) null,
      emailService, loginService, (ChannelDao) null, new MockPlanTypeDao(),
      new ProductCachingServiceImpl(productDetailsDao, productLookupService, revisionDao));
    Plan plan = planService.lookupPlanByCriteria(null);
    assertEquals(plan, planDao.lookupPlanByCriteria(null));
  }

  public void testLookupPlansByPlanTypeId() throws Exception {
    MockRevisionDao revisionDao = new MockRevisionDao();
    MockPlanDao planDao = new MockPlanDao();
    MockProductLookupService productLookupService = new MockProductLookupService();
    MockYearDao yearDao = new MockYearDao();
    MockExportSpreadsheetService exportSpreadsheetService = new MockExportSpreadsheetService();
    MockProductDetailsDao productDetailsDao = new MockProductDetailsDao();
    MockImportSpreadsheetService importSpreadsheetService = new MockImportSpreadsheetService();
    MockEmailService emailService = new MockEmailService();
    MockLoginService loginService = new MockLoginService();
    PlanServiceImpl planService = new PlanServiceImpl(planDao, revisionDao, productLookupService, yearDao,
      exportSpreadsheetService, productDetailsDao, importSpreadsheetService, (DemandDao) null,
      emailService, loginService, (ChannelDao) null, new MockPlanTypeDao(),
      new ProductCachingServiceImpl(productDetailsDao, productLookupService, revisionDao));
    List planList = planService.lookupPlansByPlanType(PlanType.PARENT_PLAN_TYPE_ID);
    assertNotNull(planList);
    assertEquals(1, planList.size());
  }

  public void testLookupPlanSummaryById() throws Exception {
    MockRevisionDao revisionDao = new MockRevisionDao();
    MockPlanDao planDao = new MockPlanDao();
    MockProductLookupService productLookupService = new MockProductLookupService();
    MockYearDao yearDao = new MockYearDao();
    MockExportSpreadsheetService exportSpreadsheetService = new MockExportSpreadsheetService();
    MockProductDetailsDao productDetailsDao = new MockProductDetailsDao();
    MockImportSpreadsheetService importSpreadsheetService = new MockImportSpreadsheetService();
    MockEmailService emailService = new MockEmailService();
    MockLoginService loginService = new MockLoginService();
    PlanServiceImpl planService = new PlanServiceImpl(planDao, revisionDao, productLookupService, yearDao,
      exportSpreadsheetService, productDetailsDao, importSpreadsheetService, (DemandDao) null,
      emailService, loginService, (ChannelDao) null, new MockPlanTypeDao(),
      new ProductCachingServiceImpl(productDetailsDao, productLookupService, revisionDao));
    assertNotNull(planService.lookupPlanSummaryByCriteria(new PlanCriteria(new Long(100), null)));
  }

  public void testSavePlan() throws Exception {
    MockRevisionDao revisionDao = new MockRevisionDao();
    MockPlanDao planDao = new MockPlanDao();
    MockProductLookupService productLookupService = new MockProductLookupService();
    MockYearDao yearDao = new MockYearDao();
    MockExportSpreadsheetService exportSpreadsheetService = new MockExportSpreadsheetService();
    MockProductDetailsDao productDetailsDao = new MockProductDetailsDao();
    MockImportSpreadsheetService importSpreadsheetService = new MockImportSpreadsheetService();
    MockEmailService emailService = new MockEmailService();
    MockLoginService loginService = new MockLoginService();
    PlanServiceImpl planService = new PlanServiceImpl(planDao, revisionDao, productLookupService, yearDao,
      exportSpreadsheetService, productDetailsDao, importSpreadsheetService, (DemandDao) null,
      emailService, loginService, (ChannelDao) null, new MockPlanTypeDao(),
      new ProductCachingServiceImpl(productDetailsDao, productLookupService, revisionDao));
    LoginUser currentUser = new LoginUser("NJMINSH");
    planService.savePlan(new File(""), currentUser, "test");
    assertEquals(1, planDao.getPlanEntries().size());
    PlanEntry entry = (PlanEntry) planDao.getPlanEntries().get(0);
    assertTrue(revisionDao.wasRevisionAdded(entry.getPlanRevision()));
    assertTrue(planDao.isSavedFlagUpdated());
    assertTrue(planDao.wasMinorVersionUpdated());
    assertEquals(importSpreadsheetService.getUserData(), entry.getUserData());
    assertEquals("NB001-0", entry.getProductDetails().getFemaleParent().getPreCommercialName());
    assertEquals("NB001", entry.getProductDetails().getFemaleParent().getManufacturingName());
    assertEquals("0", entry.getProductDetails().getFemaleParent().getVersion());
    assertEquals(ProductDetails.MANUAL_OVERRIDE_FLAG, entry.getProductDetails().getFemaleParent().getOverrideFlag());
    assertEquals("NB002-0", entry.getProductDetails().getMaleParent().getPreCommercialName());
    assertEquals("NB002", entry.getProductDetails().getMaleParent().getManufacturingName());
    assertEquals("0", entry.getProductDetails().getMaleParent().getVersion());
    assertEquals(ProductDetails.MANUAL_OVERRIDE_FLAG, entry.getProductDetails().getMaleParent().getOverrideFlag());
    assertEquals("Save Plan", entry.getPlanRevision().getOperation());
    assertEquals("test", entry.getPlanRevision().getComment());
    assertEquals(currentUser, entry.getPlanRevision().getOwner());
    assertTrue(planDao.wasTotalParentSeedUpdated());
    checkCacheWasUpdated(productDetailsDao, currentUser, revisionDao);
    assertEquals(new Double(2000), entry.getParentLimit().getFemaleLimit());
    assertEquals(new Double(1000), entry.getParentLimit().getMaleLimit());
  }

  public void testSavePlanWithNoRows() throws Exception {
    MockRevisionDao revisionDao = new MockRevisionDao();
    MockPlanDaoThrowsExceptionForNullPlanIdAndRevision planDao = new MockPlanDaoThrowsExceptionForNullPlanIdAndRevision();
    MockProductLookupService productLookupService = new MockProductLookupService();
    MockYearDao yearDao = new MockYearDao();
    MockExportSpreadsheetService exportSpreadsheetService = new MockExportSpreadsheetService();
    MockProductDetailsDao productDetailsDao = new MockProductDetailsDao();
    MockImportSpreadsheetServiceNoResults importSpreadsheetService = new MockImportSpreadsheetServiceNoResults();
    MockEmailService emailService = new MockEmailService();
    MockLoginService loginService = new MockLoginService();
    PlanServiceImpl planService = new PlanServiceImpl(planDao, revisionDao, productLookupService, yearDao,
      exportSpreadsheetService, productDetailsDao, importSpreadsheetService, (DemandDao) null,
      emailService, loginService, (ChannelDao) null, new MockPlanTypeDao(),
      new ProductCachingServiceImpl(productDetailsDao, productLookupService, revisionDao));
    LoginUser currentUser = new LoginUser("NJMINSH");
    planService.savePlan(new File(""), currentUser, "test");
    assertEquals(0, planDao.getPlanEntries().size());
    assertTrue(planDao.wasTotalParentSeedUpdated());
  }

  public void testLookupAllPlans() throws Exception {
    MockRevisionDao revisionDao = new MockRevisionDao();
    MockPlanDao planDao = new MockPlanDao();
    MockProductLookupService productLookupService = new MockProductLookupService();
    MockYearDao yearDao = new MockYearDao();
    MockExportSpreadsheetService exportSpreadsheetService = new MockExportSpreadsheetService();
    MockProductDetailsDao productDetailsDao = new MockProductDetailsDao();
    MockImportSpreadsheetService importSpreadsheetService = new MockImportSpreadsheetService();
    MockEmailService emailService = new MockEmailService();
    MockLoginService loginService = new MockLoginService();
    PlanServiceImpl planService = new PlanServiceImpl(planDao, revisionDao, productLookupService, yearDao,
      exportSpreadsheetService, productDetailsDao, importSpreadsheetService, (DemandDao) null,
      emailService, loginService, (ChannelDao) null, new MockPlanTypeDao(),
      new ProductCachingServiceImpl(productDetailsDao, productLookupService, revisionDao));
    List plans = planService.lookupAllPlans();
    assertNotNull(plans);
    assertEquals(1, plans.size());
  }

  public void testCommitPlanForHybrid() throws Exception {
    MockPlanDao planDao = new MockPlanDao(PlanType.HYBRID_PLAN_TYPE_ID);
    MockRevisionDao revisionDao = new MockRevisionDao();
    MockDemandDao demandDao = new MockDemandDao();
    final MockProductDetailsDao productDetailsDao = new MockProductDetailsDao();
    final MockProductLookupService productLookupService = new MockProductLookupService();
    PlanServiceImpl planService = new PlanServiceImpl(planDao, revisionDao,
      productLookupService, new MockYearDao(),
      new MockExportSpreadsheetService(), productDetailsDao, new MockImportSpreadsheetService(),
      demandDao, new MockEmailService(), new MockLoginService(), new MockChannelDao(), new MockPlanTypeDao(),
      new ProductCachingServiceImpl(productDetailsDao, productLookupService, revisionDao));
    LoginUser loginUser = new LoginUser("NJMINSH");
    planService.commitPlan(loginUser, "test", new Long(100), new Long(100));
    checkCommittedDemand(demandDao, loginUser, revisionDao, Channel.BRANDED_CHANNEL);
  }

  public void testCommitPlanForParent() throws Exception {
    MockPlanDao planDao = new MockPlanDao(PlanType.PARENT_PLAN_TYPE_ID);
    MockRevisionDao revisionDao = new MockRevisionDao();
    MockDemandDao demandDao = new MockDemandDao();
    final MockProductDetailsDao productDetailsDao = new MockProductDetailsDao();
    final MockProductLookupService productLookupService = new MockProductLookupService();
    PlanServiceImpl planService = new PlanServiceImpl(planDao, revisionDao,
      productLookupService, new MockYearDao(),
      new MockExportSpreadsheetService(), productDetailsDao,
      new MockImportSpreadsheetService(), demandDao,
      new MockEmailService(), new MockLoginService(), new MockChannelDao(), new MockPlanTypeDao(),
      new ProductCachingServiceImpl(productDetailsDao, productLookupService, revisionDao));
    LoginUser loginUser = new LoginUser("NJMINSH");
    planService.commitPlan(loginUser, "test", new Long(100), new Long(100));
    checkCommittedDemand(demandDao, loginUser, revisionDao, Channel.CP1_CHANNEL);
  }

  public void testCommitPlanWhenChannelUndefinedThrowsRunetimeException() throws Exception {
    MockChannelDaoNoResults channelDao = new MockChannelDaoNoResults();
    final MockPlanDao planDao = new MockPlanDao();
    final MockProductDetailsDao productDetailsDao = new MockProductDetailsDao();
    final MockProductLookupService productLookupService = new MockProductLookupService();
    final MockRevisionDao revisionDao = new MockRevisionDao();
    PlanServiceImpl planService = new PlanServiceImpl(planDao, revisionDao,
      productLookupService, new MockYearDao(),
      new MockExportSpreadsheetService(), productDetailsDao, new MockImportSpreadsheetService(),
      new MockDemandDao(), new MockEmailService(), new MockLoginService(), channelDao, new MockPlanTypeDao(),
      new ProductCachingServiceImpl(productDetailsDao, productLookupService, revisionDao));
    LoginUser loginUser = new LoginUser("NJMINSH");
    try {
      planService.commitPlan(loginUser, "test", new Long(100), new Long(100));
      fail("This should have thrown an exception.");
    }
    catch (RuntimeException e) {
      // everything ok.
    }
  }

  private void checkCommittedDemand(MockDemandDao demandDao, LoginUser loginUser, MockRevisionDao revisionDao,
                                    String channelName) {
    List demandList = demandDao.getAllAddedDemandForecasts();
    DemandForecast demand = (DemandForecast) demandList.get(0);
    assertNotNull(demand);
    assertNotNull(demand.getRevision());
    assertEquals(loginUser, demand.getOwner());
    assertTrue(revisionDao.wasRevisionAdded(demand.getRevision()));
    assertEquals(loginUser, demand.getRevision().getOwner());
    assertEquals("1.0 Test Plan (01/01/2007 12:00:00 AM)", demand.getRevision().getComment());
    assertEquals(NameType.DEFAULT_NAME_TYPE_ID, demand.getNameType().getId());
    assertEquals(channelName, demand.getChannel().getName());
  }

  private void checkCacheWasUpdated(MockProductDetailsDao productDetailsDao, LoginUser currentUser,
                                    MockRevisionDao revisionDao) {
    List productDetailsList = productDetailsDao.getProductDetailList();
    assertNotNull(productDetailsList);
    assertEquals(1, productDetailsList.size());
    ProductDetails productDetails = (ProductDetails) productDetailsList.get(0);
    assertEquals("newMFGName", productDetails.getManufacturingName());
    assertEquals("NB001-0", productDetails.getFemaleParent().getPreCommercialName());
    assertEquals("NB001", productDetails.getFemaleParent().getManufacturingName());
    assertEquals("0", productDetails.getFemaleParent().getVersion());
    assertEquals(ProductDetails.MANUAL_OVERRIDE_FLAG, productDetails.getFemaleParent().getOverrideFlag());
    assertEquals("NB002-0", productDetails.getMaleParent().getPreCommercialName());
    assertEquals("NB002", productDetails.getMaleParent().getManufacturingName());
    assertEquals("0", productDetails.getMaleParent().getVersion());
    assertEquals(ProductDetails.MANUAL_OVERRIDE_FLAG, productDetails.getMaleParent().getOverrideFlag());
    assertEquals("Add Manual Cache Record", productDetails.getRevision().getOperation());
    assertEquals("test", productDetails.getRevision().getComment());
    assertEquals(currentUser, productDetails.getRevision().getOwner());
    assertEquals(currentUser, productDetails.getOwner());
    assertTrue(revisionDao.wasRevisionAdded(productDetails.getRevision()));
  }

  private void checkEmailSent(MockEmailService emailService) {
    assertTrue(emailService.isEmailSent());
    assertTrue(emailService.getHeaderInfo().getToEmailAddresses().contains("tester@monsanto.com"));
    assertTrue(emailService.getHeaderInfo().getBccEmailAddresses().contains("junit@monsanto.com"));
  }

  private void checkFirstPlanEntry(PlanEntry entry, PlanCriteria planCriteria, MockPlanDao planDao,
                                   DemandCriteria demandCriteria, LoginUser currentUser, MockYearDao yearDao,
                                   MockProductDetailsDao productDetailsDao) {
    assertNotNull(entry.getPlanRevision());
    assertNotNull(entry.getPlanOwner());
    assertEquals(planCriteria, planDao.getCriteria());
    assertNotNull(planCriteria.getPlanType());
    assertEquals(planDao.getPlan().getId(), demandCriteria.getPlanId());
    assertEquals(currentUser, demandCriteria.getOwner());
    assertEquals(yearDao.lookupCurrentYear().getYear(), planCriteria.getYear());
    assertNotNull(planDao.getPlan());
    assertEquals(3, productDetailsDao.getProductDetailList().size());
    assertNotNull(((ProductDetails) productDetailsDao.getProductDetailList().get(0)).getRevision());
  }

  private class MockEmailService implements EmailService {
    private boolean wasSent = false;
    private EmailHeaderInfo headerInfo;

    public void sendEmail(String templateId, EmailHeaderInfo headerInfo, Object mapping) {
      this.headerInfo = headerInfo;
      this.wasSent = true;
    }

    public boolean isEmailSent() {
      return this.wasSent;
    }

    public EmailHeaderInfo getHeaderInfo() {
      return headerInfo;
    }


  }

  private class MockImportSpreadsheetServiceNoResults implements ImportSpreadsheetService {
    public List getCommonForecasts(File spreadsheet) throws IOException {
      return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public List getDemandForecasts(File spreadsheet) throws IOException {
      return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public List getATPSupply(File file) throws IOException {
      return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public List getZDCASupply(File file) throws IOException {
      return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public List getCommonUpload(String columnName, File file) throws IOException {
      return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public List getSavePlanSpreadSheet(File file) throws IOException {
      return new ArrayList();
    }

    public List getImportHybridToDemand(File file) throws IOException {
      return null;  //To change body of implemented methods use File | Settings | File Templates.
    }
  }

  private class MockPlanDaoThrowsExceptionForNullPlanIdAndRevision extends MockPlanDao {
    public void updateMinorVersion(Plan plan) {
      if (plan.getId() == null) {
        throw new RuntimeException("The plan id and revision must not be null.");
      }
    }
  }
}
