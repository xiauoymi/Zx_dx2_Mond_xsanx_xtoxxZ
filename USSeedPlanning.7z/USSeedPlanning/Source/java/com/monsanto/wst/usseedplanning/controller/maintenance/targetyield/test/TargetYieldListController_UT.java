/*
 Copyright:  Copyright � 2006 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.usseedplanning.controller.maintenance.targetyield.test;

import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.wst.usseedplanning.constants.MainConstants;
import com.monsanto.wst.usseedplanning.controller.maintenance.targetyield.TargetYieldListController;
import com.monsanto.wst.usseedplanning.controller.maintenance.targetyield.mock.MockTargetYieldService;
import com.monsanto.wst.usseedplanning.controller.maintenance.targetyield.mock.MockYearServiceForTargetYieldController;
import com.monsanto.wst.usseedplanning.model.maintenance.YieldTargetFactor;
import com.monsanto.wst.usseedplanning.services.maintenance.seedEntity.mock.MockGenderService;
import com.monsanto.wst.usseedplanning.view.factory.mock.MockViewFactory;
import com.monsanto.wst.view.test.mock.MockView;
import junit.framework.TestCase;

import java.io.IOException;
import java.util.List;

/**
 * Filename:    $RCSfile: TargetYieldListController_UT.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: njminsh $    	 On:	$Date: 2007-02-12 16:28:41 $
 *
 * @author rdesai2
 * @version $Revision: 1.19 $
 */
public class TargetYieldListController_UT extends TestCase {

    private MockViewFactory mockFactory;
    private TargetYieldListController controller;
    private MockUCCHelper mockHelper;

    protected void setUp() throws IOException {
        mockFactory = new MockViewFactory();
        mockHelper = new MockUCCHelper(null);
        controller = new TargetYieldListController(mockFactory, new MockYearServiceForTargetYieldController(), new MockTargetYieldService(), new MockGenderService());
    }

    public void testImplementationWhenMethodNameIsNotSpecified() throws Exception {
        controller.run(mockHelper);
        MockView mockView = (MockView) mockFactory.getJspTargetYieldListPageView();
        assertEquals("1997", ((List) mockHelper.getRequestAttributeValue(MainConstants.HELPER_PARAM_YEAR_LOOKUP_LIST)).get(0));
        assertTrue(mockView.wasViewRendered());
    }

    public void testSearchYieldTargetFactors() throws Exception {
        mockHelper.setRequestParameterValue("method", "searchYieldTargetFactors");
        mockHelper.setRequestParameterValue(MainConstants.HELPER_PARAM_YIELD_TARGET_LIST_PAGE_PRODUCT_NAME, "testProductName");
        mockHelper.setRequestParameterValue(MainConstants.HELPER_PARAM_YIELD_TARGET_LIST_PAGE_TARGET_YEAR_ID_STR, "23");
        controller.run(mockHelper);
        MockView mockView = (MockView) mockFactory.getJspTargetYieldListPageView();
        assertEquals("1997", ((List) mockHelper.getRequestAttributeValue(MainConstants.HELPER_PARAM_YEAR_LOOKUP_LIST)).get(0));
        YieldTargetFactor yieldTargetFactor = (YieldTargetFactor) ((List) mockHelper.getRequestAttributeValue(MainConstants.HELPER_PARAM_YIELD_TARGET_FACTOR_LIST)).get(0);
        assertEquals("testProductName", yieldTargetFactor.getProductName());
        assertEquals(Boolean.TRUE, yieldTargetFactor.getActiveStatus());
        assertEquals(new Long(23), yieldTargetFactor.getTargetYear().getId());
        assertTrue(mockView.wasViewRendered());
    }

    public void testSearchYieldTargetFactorsWithNullProductNameAndTargetYearId() throws Exception {
        mockHelper.setRequestParameterValue("method", "searchYieldTargetFactors");
        controller.run(mockHelper);
        MockView mockView = (MockView) mockFactory.getJspTargetYieldListPageView();
        assertEquals("1997", ((List) mockHelper.getRequestAttributeValue(MainConstants.HELPER_PARAM_YEAR_LOOKUP_LIST)).get(0));
        YieldTargetFactor yieldTargetFactor = (YieldTargetFactor) ((List) mockHelper.getRequestAttributeValue(MainConstants.HELPER_PARAM_YIELD_TARGET_FACTOR_LIST)).get(0);
        assertEquals(null, yieldTargetFactor.getProductName());
        assertEquals(Boolean.TRUE, yieldTargetFactor.getActiveStatus());
        assertEquals(null, yieldTargetFactor.getTargetYear().getId());
        assertTrue(mockView.wasViewRendered());
    }

    public void testAddYieldTargetFactor() throws Exception {
        mockHelper.setRequestParameterValue("method", "addYieldTargetFactor");
        controller.run(mockHelper);
        List yearList = ((List) mockHelper.getRequestAttributeValue(MainConstants.HELPER_PARAM_YEAR_LOOKUP_LIST));
        assertEquals(1, yearList.size());
        assertEquals("1997", yearList.get(0));
        assertTrue(mockHelper.wasSentTo(MainConstants.FORWARD_ADD_EDIT_YIELD_TARGET_LIST_PAGE));
    }

    public void testEditYieldTargetFactor() throws Exception {
        mockHelper.setRequestParameterValue(MainConstants.HELPER_EDIT_TARGET_YIELD_PARAM_REVISION_ID, "23");
        mockHelper.setRequestParameterValue("method", "editYieldTargetFactor");
        controller.run(mockHelper);
        List yearList = ((List) mockHelper.getRequestAttributeValue(MainConstants.HELPER_PARAM_YEAR_LOOKUP_LIST));
        YieldTargetFactor yieldTargetFactor = (YieldTargetFactor) mockHelper.getRequestAttributeValue(MainConstants.HELPER_PARAM_YIELD_TARGET_FACTOR);
        assertEquals(1, yearList.size());
        assertEquals("1997", yearList.get(0));
        assertNotNull(yieldTargetFactor);
        assertEquals("editProductName", yieldTargetFactor.getProductName());
        assertEquals("true", mockHelper.getRequestAttributeValue(MainConstants.HELPER_TARGET_YIELD_EDIT_ACTION_FLAG));
        assertTrue(mockHelper.wasSentTo(MainConstants.FORWARD_ADD_EDIT_YIELD_TARGET_LIST_PAGE));
    }
}