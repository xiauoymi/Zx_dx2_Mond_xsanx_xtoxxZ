/*
 CacheUtilUT was created on Dec 20, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.usseedplanning.services.batchupdate.test;

import junit.framework.TestCase;

import java.util.ArrayList;
import java.util.List;

import com.monsanto.wst.usseedplanning.services.batchupdate.CacheUtil;
import com.monsanto.wst.usseedplanning.model.cache.ProductDetails;

/**
 * Filename:    $RCSfile: CacheUtilUT.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: njminsh $    	 On:	$Date: 2007-01-31 21:55:33 $
 *
 * @author vrbethi
 * @version $Revision: 1.2 $
 */
public class CacheUtilUT extends TestCase{

    public void testRemoveDuplicatePreCommercialRecordsInProductDetailsList() throws Exception {
        CacheUtil cacheUtil = new CacheUtil();
        ArrayList productDetailsList = new ArrayList();
        ProductDetails productDetails;

        productDetails = new ProductDetails();
        productDetails.setPreCommercialName("PCMN1");
        productDetails.setPrimaryFlag(new Boolean(true));
        productDetails.setManufacturingName("MFGN1");
        productDetailsList.add(productDetails);

        productDetails = new ProductDetails();
        productDetails.setPreCommercialName("PCMN2");
        productDetails.setPrimaryFlag(new Boolean(true));
        productDetails.setManufacturingName("MFGN2");
        productDetailsList.add(productDetails);

        productDetails = new ProductDetails();
        productDetails.setPreCommercialName("PCMN2");
        productDetails.setPrimaryFlag(new Boolean(true));
        productDetails.setManufacturingName("MFGN3");
        productDetailsList.add(productDetails);

        List uniquePreCommercialList = cacheUtil.removeDuplicatePreCommercialRecordsInProductDetailsList(productDetailsList);
        assertTrue(uniquePreCommercialList.size()==2);
    }
}