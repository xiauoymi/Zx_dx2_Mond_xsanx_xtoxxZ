/*
CommonUploadConstantsUT was created on Nov 14, 2006 using Monsanto
resources and is the sole property of Monsanto.  Any duplication of the
code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.usseedplanning.utils.test;

import com.monsanto.wst.usseedplanning.utils.CommonUploadConstants;
import org.custommonkey.xmlunit.XMLTestCase;

/**
 * Filename:    $RCSfile: CommonUploadConstantsUT.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: njminsh $    	 On:	$Date: 2007-02-15 22:46:26 $
 *
 * @author vrbethi
 * @version $Revision: 1.2 $
 */
public class CommonUploadConstantsUT extends XMLTestCase {
    public CommonUploadConstantsUT(String name) {
        super(name);
    }

    public void testCreateCommonUploadConstant() throws Exception {
        CommonUploadConstants commonUploadConstants = new CommonUploadConstants();
        assertEquals("F - Base Name",commonUploadConstants.getCommonUploadConstantValue("base_name"));
    }

    public void testGetUploadConstants() throws Exception {
        CommonUploadConstants commonUploadConstants = new CommonUploadConstants();
        assertTrue(commonUploadConstants.getcommonUploadConstants().size() > 10);
    }
}