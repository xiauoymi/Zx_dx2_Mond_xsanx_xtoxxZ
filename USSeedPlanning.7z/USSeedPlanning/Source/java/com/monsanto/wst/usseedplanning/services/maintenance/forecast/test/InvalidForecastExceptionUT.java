package com.monsanto.wst.usseedplanning.services.maintenance.forecast.test;

import com.monsanto.wst.usseedplanning.services.maintenance.forecast.InvalidForecastException;
import junit.framework.TestCase;

/**
 * Created by IntelliJ IDEA.
 * Date: Sep 7, 2006
 * Time: 7:06:02 AM
 * <p/>
 * Unit test for the InvalidForecastException object.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class InvalidForecastExceptionUT extends TestCase {
    public void testCreate() throws Exception {
        InvalidForecastException exception = new InvalidForecastException("Test Message");
        assertNotNull(exception);
        assertEquals("Test Message", exception.getMessage());
    }
}
