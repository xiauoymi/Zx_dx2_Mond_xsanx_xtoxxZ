/*
DashboardReport_UT was created on Aug 31, 2006 using Monsanto
resources and is the sole property of Monsanto.  Any duplication of the
code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.usseedplanning.reports.tests;

import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.wst.commonutils.xml.XPathUtils;
import com.monsanto.wst.commonutils.xml.XalanXPathUtils;
import com.monsanto.wst.factory.AbstractGenericFactory;
import com.monsanto.wst.factory.GenericFactory;
import com.monsanto.wst.reportingframework.core.AbstractReport;
import com.monsanto.wst.reportingframework.core.ReportParameters;
import com.monsanto.wst.usseedplanning.constants.MainConstants;
import com.monsanto.wst.usseedplanning.utils.testutils.USSeedPlanningBaseTransactionTestCase;
import com.monsanto.wst.usseedplanning.model.planning.PlanType;
import com.monsanto.wst.dbtemplate.transaction.TransactionManager;
import org.w3c.dom.Document;

/**
 * Filename:    $RCSfile: DashboardReportPlanAT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: njminsh $    	 On:	$Date: 2007-02-16 16:54:12 $
 *
 * @author ffbrac
 * @version $Revision: 1.13 $
 */
public class DashboardReportPlanAT extends USSeedPlanningBaseTransactionTestCase {

    public void testDashboardReportPlan() throws Exception {
        GenericFactory container = AbstractGenericFactory.getInstance();
        AbstractReport abstractReport = (AbstractReport) container.getBean("dashboardReport");
        XPathUtils xPathUtils = new XalanXPathUtils();
        ReportParameters reportParameters = new ReportParameters();
        reportParameters.add(MainConstants.FOUNDATION_PLANNING,"SET");
        reportParameters.add(MainConstants.HYBRID_PLANNING,"SET");
        Document document = abstractReport.buildReportXML(reportParameters, null);
        DOMUtil.outputXML(document);
        assertNotNull(document);
        assertEquals("01/01/2006",xPathUtils.evalToString(document,"/dashboard/data/row[position()=last()]/date"));
        assertEquals("DBUNIT",xPathUtils.evalToString(document,"/dashboard/data/row[position()=last()]/user"));
        assertEquals(PlanType.HYBRID_PLAN_TYPE_NAME,xPathUtils.evalToString(document,"/dashboard/data/row[position()=last()]/plan_type"));
        assertEquals("BR",xPathUtils.evalToString(document,"/dashboard/data/row[position()=last()]/value"));
        //this is actually operation
        assertEquals("Adding Demand Forecast",xPathUtils.evalToString(document,"/dashboard/data/row[position()=last()]/description"));
        assertEquals("Insert Demand",xPathUtils.evalToString(document,"/dashboard/data/row[position()=last()]/comment"));

        assertEquals("10/12/2006",xPathUtils.evalToString(document,"/dashboard/data/row[position()=last()-1]/date"));
        assertEquals("DBUNIT",xPathUtils.evalToString(document,"/dashboard/data/row[position()=last()-1]/user"));
        assertEquals(PlanType.HYBRID_PLAN_TYPE_NAME,xPathUtils.evalToString(document,"/dashboard/data/row[position()=last()-1]/plan_type"));
        assertEquals("ZDCA",xPathUtils.evalToString(document,"/dashboard/data/row[position()=last()-1]/value"));
//        //this is actually operation
        assertEquals("Import Supply",xPathUtils.evalToString(document,"/dashboard/data/row[position()=last()-1]/description"));
        assertEquals("Insert Supply",xPathUtils.evalToString(document,"/dashboard/data/row[position()=last()-1]/comment"));

        assertEquals("10/13/2006",xPathUtils.evalToString(document,"/dashboard/data/row[position()=last()-2]/date"));
        assertEquals("DBUNIT",xPathUtils.evalToString(document,"/dashboard/data/row[position()=last()-2]/user"));
        assertEquals("",xPathUtils.evalToString(document,"/dashboard/data/row[position()=last()-2]/plan_type"));
        assertEquals("F - Base Name",xPathUtils.evalToString(document,"/dashboard/data/row[position()=last()-2]/value"));
//        //this is actually operation
        assertEquals(MainConstants.COMMON_UPLOADS_TAB,xPathUtils.evalToString(document,"/dashboard/data/row[position()=last()-2]/description"));
        assertEquals("Base Name Common Uploads",xPathUtils.evalToString(document,"/dashboard/data/row[position()=last()-2]/comment"));
    }

//    public void testPlanDropDown() throws Exception {
//        GenericFactory container = AbstractGenericFactory.getInstance();
//        AbstractReport abstractReport = (AbstractReport) container.getBean("dashboardReport");
//        XPathUtils xPathUtils = new XalanXPathUtils();
//        ReportParameters reportParameters = new ReportParameters();
//        reportParameters.add(MainConstants.FOUNDATION_PLANNING,"SET");
//        reportParameters.add(MainConstants.HYBRID_PLANNING,"SET");
//        Document document = abstractReport.buildReportXML(reportParameters, null);
//        DOMUtil.outputXML(document);
//        assertNotNull(document);
//        assertEquals("100",xPathUtils.evalToString(document,"/dashboard/plan/row[position()=last()]/plan_id"));
//        assertEquals("10/22/06 12:00:00 AM 1.0 Caching product details for unknown products", xPathUtils.evalToString(document,"/dashboard/plan/row[position()=last()]/description"));
//    }

    public void testOnSelectOfAPlanValuesInTheReport() throws Exception {
        GenericFactory container = AbstractGenericFactory.getInstance();
        AbstractReport abstractReport = (AbstractReport) container.getBean("dashboardReport");
        XPathUtils xPathUtils = new XalanXPathUtils();
        ReportParameters reportParameters = new ReportParameters();
        reportParameters.add("planId","100");
        Document document = abstractReport.buildReportXML(reportParameters, null);
        DOMUtil.outputXML(document);
        assertNotNull(document);

        assertEquals("01/01/2006",xPathUtils.evalToString(document,"/dashboard/data/row[position()=last()]/date"));
         assertEquals("DBUNIT",xPathUtils.evalToString(document,"/dashboard/data/row[position()=last()]/user"));
         assertEquals(PlanType.HYBRID_PLAN_TYPE_NAME,xPathUtils.evalToString(document,"/dashboard/data/row[position()=last()]/plan_type"));
         assertEquals("BR",xPathUtils.evalToString(document,"/dashboard/data/row[position()=last()]/value"));
         //this is actually operation
         assertEquals("Adding Demand Forecast",xPathUtils.evalToString(document,"/dashboard/data/row[position()=last()]/description"));
         assertEquals("Insert Demand",xPathUtils.evalToString(document,"/dashboard/data/row[position()=last()]/comment"));

        assertEquals("10/12/2006",xPathUtils.evalToString(document,"/dashboard/data/row[position()=last()-1]/date"));
        assertEquals("DBUNIT",xPathUtils.evalToString(document,"/dashboard/data/row[position()=last()-1]/user"));
        assertEquals(PlanType.HYBRID_PLAN_TYPE_NAME,xPathUtils.evalToString(document,"/dashboard/data/row[position()=last()-1]/plan_type"));
        assertEquals("ZDCA",xPathUtils.evalToString(document,"/dashboard/data/row[position()=last()-1]/value"));
//        //this is actually operation
        assertEquals("Import Supply",xPathUtils.evalToString(document,"/dashboard/data/row[position()=last()-1]/description"));
        assertEquals("Insert Supply",xPathUtils.evalToString(document,"/dashboard/data/row[position()=last()-1]/comment"));


        assertEquals("10/13/2006",xPathUtils.evalToString(document,"/dashboard/data/row[position()=last()-2]/date"));
        assertEquals("DBUNIT",xPathUtils.evalToString(document,"/dashboard/data/row[position()=last()-2]/user"));
        assertEquals("",xPathUtils.evalToString(document,"/dashboard/data/row[position()=last()-2]/plan_type"));
        assertEquals("F - Base Name",xPathUtils.evalToString(document,"/dashboard/data/row[position()=last()-2]/value"));
        //this is actually operation
        assertEquals(MainConstants.COMMON_UPLOADS_TAB,xPathUtils.evalToString(document,"/dashboard/data/row[position()=last()-2]/description"));
        assertEquals("Base Name Common Uploads",xPathUtils.evalToString(document,"/dashboard/data/row[position()=last()-2]/comment"));

    }


    protected String getConfigPath() {
        return "com/monsanto/wst/usseedplanning/reports/tests/dbunit/dashboardplan.xml";
    }

    protected void cleanDatabase(TransactionManager txManager) {
    }

}