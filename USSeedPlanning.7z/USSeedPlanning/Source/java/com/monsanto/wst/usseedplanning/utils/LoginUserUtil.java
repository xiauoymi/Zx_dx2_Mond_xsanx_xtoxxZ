package com.monsanto.wst.usseedplanning.utils;

import java.util.StringTokenizer;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Aug 3, 2006
 * Time: 12:53:50 PM
 * To change this template use File | Settings | File Templates.
 */
public class LoginUserUtil {

    public String getNameInCorrectSequence(String kerberosAuthenticatedUserFullName) {
        if (kerberosAuthenticatedUserFullName!=null){
            String nameOnly = removeEmployeeClassification(kerberosAuthenticatedUserFullName);
            return getFirstNameFollowedByLastName(nameOnly);
        }
        return "";
    }

    private String removeEmployeeClassification(String employeeNameWithClassification) {
        int sqBckPosition = employeeNameWithClassification.indexOf("[");
        if (sqBckPosition == -1){
            return employeeNameWithClassification;
        }
        else
        {
            return employeeNameWithClassification.substring(0,sqBckPosition-1);
        }
    }

    private String getFirstNameFollowedByLastName(String employeeName) {
        String firstName = null;
        String lastName = null;
        String fullName = null;
        StringTokenizer st = new StringTokenizer(employeeName,",");
        int tokens = st.countTokens();
        if (tokens>1){
            for (int i=0;i<2;i++){
                lastName = getLastName(i, st, lastName);
                firstName = getFirstName(i, st, firstName);
            }
            fullName = firstName + " " + lastName;
        }
        else {
            fullName = employeeName;
        }
        return fullName;
    }

    private String getFirstName(int i, StringTokenizer st, String firstname) {
        if (i == 1){
            firstname = st.nextToken();
            firstname = firstname.substring(1,firstname.length());
        }
        return firstname;
    }

    private String getLastName(int i, StringTokenizer st, String lastname) {
        if (i==0){
            lastname = st.nextToken();
        }
        return lastname;
    }
}
