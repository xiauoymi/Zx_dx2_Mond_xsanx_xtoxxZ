package com.monsanto.wst.usseedplanning.services.maintenance.supply;

import com.monsanto.wst.usseedplanning.model.core.LoginUser;

import java.io.File;
import java.io.IOException;

/**
 * Created by IntelliJ IDEA.
 * Date: Feb 12, 2007
 * Time: 5:41:05 PM
 * <p/>
 * TODO: Enter description for class.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public interface UpdateSupplyService {
    /**
     * This method updates supply information in the system based on the current supply.
     *
     * TODO: Use supply type id instead of string.
     *
     * @param file     File representing the supply data file.
     * @param owner    LoginUser object representing the person requesting the update.
     * @param planType
     * @param comments String representing any comments.
     * @throws java.io.IOException - If unable to find a valid supply file.
     */
    void updateSupply(File file, String comments, LoginUser owner, Long planType)
            throws IOException;
}
