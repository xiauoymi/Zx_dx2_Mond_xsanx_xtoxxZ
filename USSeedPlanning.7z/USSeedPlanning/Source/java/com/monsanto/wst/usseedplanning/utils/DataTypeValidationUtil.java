package com.monsanto.wst.usseedplanning.utils;

import com.monsanto.wst.usseedplanning.utils.exception.InvalidFormatException;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Aug 4, 2006
 * Time: 9:19:56 AM
 * To change this template use File | Settings | File Templates.
 */
public class DataTypeValidationUtil {

    public static double getdoubleValue(String number) throws InvalidFormatException {
        double d = 0.0;
        try {
            d = Double.parseDouble(number);
        } catch (Exception e) {
            throw new InvalidFormatException("Cannot Format String into Double");
        }
        return d;
    }

    public static Double getDoubleValue(String number) throws InvalidFormatException {
        Double dvalue = new Double(0.0);
        if (number != null && !number.equalsIgnoreCase("")){
            try {
                dvalue = Double.valueOf(number);
            } catch (Exception e) {
                throw new InvalidFormatException("Cannot Format String into Double");
            }
        }
        return dvalue;
    }

}
