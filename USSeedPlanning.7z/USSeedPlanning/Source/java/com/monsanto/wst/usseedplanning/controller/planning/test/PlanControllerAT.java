/*
PlanControllerAT was created on Nov 2, 2006 using Monsanto
resources and is the sole property of Monsanto.  Any duplication of the
code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.usseedplanning.controller.planning.test;

import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.wst.dbtemplate.DBTemplate;
import com.monsanto.wst.factory.AbstractGenericFactory;
import com.monsanto.wst.factory.GenericFactory;
import com.monsanto.wst.servletframework.AbstractDispatchController;
import com.monsanto.wst.usseedplanning.dao.YearDao;
import com.monsanto.wst.usseedplanning.model.maintenance.YearCriteria;
import com.monsanto.wst.usseedplanning.model.planning.ChannelizedDemandRevisions;
import com.monsanto.wst.usseedplanning.model.planning.Plan;
import com.monsanto.wst.usseedplanning.utils.testutils.USSeedPlanningBaseTransactionTestCase;
import com.monsanto.wst.usseedplanning.constants.DatabaseConstants;

import java.util.List;

/**
 * Filename:    $RCSfile: PlanControllerAT.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: njminsh $    	 On:	$Date: 2007-02-14 22:23:12 $
 *
 * @author vrbethi
 * @version $Revision: 1.10 $
 */
public class PlanControllerAT extends USSeedPlanningBaseTransactionTestCase {
    protected String getConfigPath() {
        return "com/monsanto/wst/usseedplanning/controller/planning/test/dbunit/plan.xml";
    }

    public void testDisplayGeneratPlanScreen_CheckForValuesInDropDown() throws Exception {
        YearDao dao = (YearDao) AbstractGenericFactory.getInstance().getBean("yearDao");
        updateCurrentYear(dao, new YearCriteria(new Long("10001"), DatabaseConstants.FALSE_INDICATOR));
        GenericFactory container = AbstractGenericFactory.getInstance();
        AbstractDispatchController planController = (AbstractDispatchController) container.getBean("/servlet/generatePlan.htm");
        MockUCCHelper helper = new MockUCCHelper(null);
        helper.setRequestParameterValue("plan_type", "795");
        planController.run(helper);
        List channelWithRevisionsList = (List) helper.getRequestAttributeValue("channelWithRevisionsList");
        List planList = (List) helper.getRequestAttributeValue("planList");
        ChannelizedDemandRevisions channelEntry = (ChannelizedDemandRevisions) channelWithRevisionsList.get(1);
        Plan plan = (Plan) planList.get(planList.size()-1);
        assertEquals("BR", channelEntry.getChannel().getName());
        assertEquals("01/01/2006 12:00:00 AM", plan.getRevision().getFormattedDate());
        assertEquals("this is for testing", plan.getRevision().getComment());
    }

    public void testOnChangeOnGeneratePlanScreen() throws Exception {
        YearDao dao = (YearDao) AbstractGenericFactory.getInstance().getBean("yearDao");
        updateCurrentYear(dao, new YearCriteria(new Long("10001"), DatabaseConstants.FALSE_INDICATOR));
        GenericFactory container = AbstractGenericFactory.getInstance();
        AbstractDispatchController planController = (AbstractDispatchController) container.getBean("/servlet/generatePlan.htm");
        MockUCCHelper helper = new MockUCCHelper(null);
        helper.setRequestParameterValue("plan_type", "795");
        helper.setRequestParameterValue("fromPlan", "true");
        helper.setRequestParameterValue("plan_id", "101-101");
        helper.setRequestParameterValue("plan_revision", "100");
        planController.run(helper);
        List channelWithRevisionsList = (List) helper.getRequestAttributeValue("channelWithRevisionsList");
        List planList = (List) helper.getRequestAttributeValue("planList");
        ChannelizedDemandRevisions channelEntry = (ChannelizedDemandRevisions) channelWithRevisionsList.get(1);
        Plan plan = (Plan) planList.get(planList.size()-1);
        assertEquals("BR",channelEntry.getChannel().getName());
        assertEquals("01/01/2006 12:00:00 AM",plan.getRevision().getFormattedDate());
        assertEquals("this is for testing",plan.getRevision().getComment());
    }


    private void updateCurrentYear(YearDao dao, YearCriteria yearCriteria) {
        DBTemplate template = (DBTemplate) AbstractGenericFactory.getInstance().getBean("dbTemplate");
        template.executeUpdate("updateCurrentYear", yearCriteria);
    }
}