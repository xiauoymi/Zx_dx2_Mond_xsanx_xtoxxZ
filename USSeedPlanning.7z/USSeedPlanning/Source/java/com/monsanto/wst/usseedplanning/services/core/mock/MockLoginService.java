/*
 MockLoginService was created on Aug 16, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.usseedplanning.services.core.mock;

import com.monsanto.wst.usseedplanning.services.core.LoginService;
import com.monsanto.wst.usseedplanning.model.core.LoginUser;
import com.monsanto.wst.usseedplanning.model.core.Role;

import java.util.List;
import java.util.ArrayList;

/**
 * Filename:    $RCSfile: MockLoginService.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: njminsh $    	 On:	$Date: 2007-02-13 18:08:48 $
 *
 * @author ffbrac
 * @version $Revision: 1.6 $
 */
public class MockLoginService implements LoginService {
    private boolean isAuthorized = true;
    private boolean authorized = false;
    private boolean userRetrieved = false;

    public void setIsAuthorized(boolean isAuthorized) {
        this.isAuthorized = isAuthorized;
    }

    public LoginUser lookupUserById(String userId) {
        userRetrieved = true;
        LoginUser user = new LoginUser("JUNIT");
        user.setEmail("junit@monsanto.com");
        user.setFirstName("Junit");
        user.setLastName("Tester");
        return user;
    }

    public boolean isAuthorized(String userId) {
        authorized = true;
        return this.isAuthorized;
    }

    public List lookupUsersByRole(Role role) {
        List userList = new ArrayList();
        LoginUser user = new LoginUser("JUNIT");
        user.setEmail("junit@monsanto.com");
        user.setFirstName("Junit");
        user.setLastName("Tester");
        userList.add(user);
        return userList;
    }

    public boolean wasAuthorized() {
        return authorized;
    }

    public boolean wasUserRetrieved() {
        return userRetrieved;
    }
}