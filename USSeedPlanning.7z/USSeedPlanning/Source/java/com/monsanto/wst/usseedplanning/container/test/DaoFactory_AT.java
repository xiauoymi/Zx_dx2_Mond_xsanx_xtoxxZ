package com.monsanto.wst.usseedplanning.container.test;

import com.monsanto.wst.commonutils.EnvironmentUtils;
import com.monsanto.wst.dbtemplate.dao.persistentstore.test.mock.MockPersistentStoreTransactionManager;
import com.monsanto.wst.factory.AbstractGenericFactory;
import com.monsanto.wst.factory.GenericFactory;
import com.monsanto.wst.usseedplanning.container.DaoFactory;
import com.monsanto.wst.usseedplanning.dao.*;
import com.monsanto.wst.usseedplanning.dao.dbTemplate.*;
import com.monsanto.wst.usseedplanning.utils.testutils.TempBaseTestCase;

/**
 * Created by IntelliJ IDEA.
 * Date: Feb 11, 2007
 * Time: 6:14:08 PM
 * <p/>
 * TODO: Enter description for class.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class DaoFactory_AT extends TempBaseTestCase {
    protected void setUp() throws Exception {
        super.setUp();
        String catalinaHome = new EnvironmentUtils().getVariable("CATALINA_HOME");
        System.setProperty("catalina.home", catalinaHome);
        GenericFactory container = AbstractGenericFactory.getInstance();
        container.addBean("transactionManager", new MockPersistentStoreTransactionManager(), true);
    }

    protected void tearDown() throws Exception {
        super.tearDown();
        System.setProperty("catalina.home", "");
    }

    public void testCreate() throws Exception {
        DaoFactory factory = new DaoFactory();
        assertNotNull(factory);
    }

    public void testGetLoginDao() throws Exception {
        GenericFactory container = AbstractGenericFactory.getInstance();
        LoginDAO template = (LoginDAO) container.getBean("loginDao");
        assertNotNull(template);
        assertEquals(DBTemplateLoginDao.class, template.getClass());
    }

    public void testGetLookupDao() throws Exception {
        GenericFactory container = AbstractGenericFactory.getInstance();
        LookupDao template = (LookupDao) container.getBean("lookupDao");
        assertNotNull(template);
        assertEquals(DBTemplateLookupDao.class, template.getClass());
    }

    public void testCommonUploadDao() throws Exception {
        GenericFactory container = AbstractGenericFactory.getInstance();
        CommonUploadDao template = (CommonUploadDao) container.getBean("commonUploadDao");
        assertNotNull(template);
        assertEquals(DBTemplateCommonUploadDao.class, template.getClass());
    }

    public void testGetDashboardReportDao() throws Exception {
        GenericFactory container = AbstractGenericFactory.getInstance();
        DashboardReportDao template = (DashboardReportDao) container.getBean("dashboardReportDao");
        assertNotNull(template);
        assertEquals(DBTemplateDashboardReportDao.class, template.getClass());
    }

    public void testGetFactorDao() throws Exception {
        GenericFactory container = AbstractGenericFactory.getInstance();
        FactorDao template = (FactorDao) container.getBean("factorDao");
        assertNotNull(template);
        assertEquals(DBTemplateFactorDao.class, template.getClass());
    }

    public void testGetPlanRevisionDao() throws Exception {
        GenericFactory container = AbstractGenericFactory.getInstance();
        PlanRevisionDao template = (PlanRevisionDao) container.getBean("getPlanRevisionDao");
        assertNotNull(template);
        assertEquals(DBTemplatePlanRevisionDao.class, template.getClass());
    }

    public void testGetUserRoleDao() throws Exception {
        GenericFactory container = AbstractGenericFactory.getInstance();
        UserRoleDao template = (UserRoleDao) container.getBean("userRoleDao");
        assertNotNull(template);
        assertEquals(DBTemplateUserRoleDao.class, template.getClass());
    }

    public void testGetChannelDao() throws Exception {
        GenericFactory container = AbstractGenericFactory.getInstance();
        ChannelDao dao = (ChannelDao) container.getBean("channelDao");
        assertNotNull(dao);
        assertEquals(DBTemplateChannelDao.class, dao.getClass());
    }

    public void testUomConversionDao() throws Exception {
        GenericFactory container = AbstractGenericFactory.getInstance();
        UomConversionDao dao = (UomConversionDao) container.getBean("uomConversionDao");
        assertNotNull(dao);
        assertEquals(DBTemplateUomConversionDao.class, dao.getClass());
    }

    public void testGetRevisionDao() throws Exception {
        GenericFactory container = AbstractGenericFactory.getInstance();
        RevisionDao dao = (RevisionDao) container.getBean("revisionDao");
        assertNotNull(dao);
        assertEquals(DBTemplateRevisionDao.class, dao.getClass());
    }

    public void testGetStageFactorDao() throws Exception {
        GenericFactory container = AbstractGenericFactory.getInstance();
        StageFactorDao dao = (StageFactorDao) container.getBean("stageFactorDao");
        assertNotNull(dao);
        assertEquals(DBTemplateStageFactorDao.class, dao.getClass());
    }

    public void testGetStageDao() throws Exception {
        GenericFactory container = AbstractGenericFactory.getInstance();
        StageDao dao = (StageDao) container.getBean("stageDao");
        assertNotNull(dao);
        assertEquals(DBTemplateStageDao.class, dao.getClass());
    }

    public void testGetSupplyDao() throws Exception {
        GenericFactory container = AbstractGenericFactory.getInstance();
        SupplyDao supplyDao = (SupplyDao) container.getBean("supplyDao");
        assertNotNull(supplyDao);
        assertEquals(DBTemplateSupplyDao.class, supplyDao.getClass());
    }

    public void testGetSupplyTypeDao() throws Exception {
        GenericFactory container = AbstractGenericFactory.getInstance();
        SupplyTypeDao supplyTypeDao = (SupplyTypeDao) container.getBean("supplyTypeDao");
        assertNotNull(supplyTypeDao);
        assertEquals(DBTemplateSupplyTypeDao.class, supplyTypeDao.getClass());
    }

    public void testGetPlanDao() throws Exception {
        GenericFactory container = AbstractGenericFactory.getInstance();
        PlanDao planDao = (PlanDao) container.getBean("planDao");
        assertNotNull(planDao);
        assertEquals(DBTemplatePlanDao.class, planDao.getClass());
    }

    public void testGetQaThresholdComparisonStrategyDao() throws Exception {
        GenericFactory container = AbstractGenericFactory.getInstance();
        QaThresholdComparisonStrategyDao dao = (QaThresholdComparisonStrategyDao) container.getBean("qaThresholdComparisonStrategyDao");
        assertNotNull(dao);
        assertEquals(DbTemplateQaThresholdComparisonStrategyDao.class, dao.getClass());
    }

    public void testGetProductDetailsDao() throws Exception {
        GenericFactory container = AbstractGenericFactory.getInstance();
        ProductDetailsDao dao = (ProductDetailsDao) container.getBean("productDetailsDao");
        assertNotNull(dao);
    }

    public void testGetBatchDao() throws Exception {
        GenericFactory container = AbstractGenericFactory.getInstance();
        BatchDao dao = (BatchDao) container.getBean("batchDao");
        assertNotNull(dao);
        assertEquals(DBTemplateBatchDao.class, dao.getClass());
    }

    public void testGetDataSourceConfigFile() throws Exception {
        GenericFactory container = AbstractGenericFactory.getInstance();
        String path = (String) container.getBean("dataSourceConfigFile");
        assertEquals("database/dbtemplate-config.xml", path);
    }

    public void testGetPlanTypeDao() throws Exception {
        GenericFactory container = AbstractGenericFactory.getInstance();
        PlanTypeDao dao = (PlanTypeDao) container.getBean("planTypeDao");
        assertNotNull(dao);
    }
}
