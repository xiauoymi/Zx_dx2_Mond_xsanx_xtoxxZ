/*
 LoginServiceImplUT was created on Aug 16, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.usseedplanning.services.core.test;

import com.monsanto.wst.usseedplanning.dao.mock.MockLoginDao;
import com.monsanto.wst.usseedplanning.model.core.LoginUser;
import com.monsanto.wst.usseedplanning.model.core.Role;
import com.monsanto.wst.usseedplanning.services.core.LoginServiceImpl;
import com.monsanto.wst.usseedplanning.utils.testutils.USSeedPlanningBaseTestCase;

import java.util.List;

/**
 * Filename:    $RCSfile: LoginServiceImplUT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: njminsh $    	 On:	$Date: 2006-12-22 19:20:29 $
 *
 * @author ffbrac
 * @version $Revision: 1.6 $
 */
public class LoginServiceImplUT extends USSeedPlanningBaseTestCase {
  public void testIsAuthorized() throws Exception {
    MockLoginDao loginDao = new MockLoginDao();
    LoginServiceImpl loginService = new LoginServiceImpl(loginDao);
    assertTrue(loginService.isAuthorized("test"));
  }

  public void testLookupUserById() throws Exception {
    MockLoginDao loginDao = new MockLoginDao();
    LoginServiceImpl loginService = new LoginServiceImpl(loginDao);
    LoginUser user = loginService.lookupUserById("test");
    assertNotNull(user);
  }

  public void testLookupUsersByRole() throws Exception {
    MockLoginDao loginDao = new MockLoginDao();
    LoginServiceImpl loginService = new LoginServiceImpl(loginDao);
    List userList = loginService.lookupUsersByRole(Role.ADMIN_ROLE);
    assertNotNull(userList);
  }
}