/*
 MockFactorService was created on Oct 3, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.usseedplanning.services.planning.mock;

import com.monsanto.wst.usseedplanning.services.planning.FactorService;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * Date: Sep 22, 2006
 * Time: 8:53:23 PM
 * <p/>
 * Mock object used for testing.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class MockFactorService implements FactorService {
	public List getStageFactorList() {
		return new ArrayList();
	}

	public List getQAFactorList() {
		return new ArrayList();
	}

	public List getYieldFactorList() {
		return new ArrayList();
	}
}