/*
 Copyright:  Copyright � 2006 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.usseedplanning.services.maintenance.seedEntity.dbServices;

import com.monsanto.wst.usseedplanning.dao.QaThresholdTypeDao;
import com.monsanto.wst.usseedplanning.services.maintenance.seedEntity.QaThresholdTypeService;

import java.util.List;

/**
 * Filename:    $RCSfile: QaThresholdTypeDbServiceImpl.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: jdpoul $    	 On:	$Date: 2006-09-15 19:23:12 $
 *
 * @author JDPOUL
 * @version $Revision: 1.1 $
 */
public class QaThresholdTypeDbServiceImpl implements QaThresholdTypeService {

  private QaThresholdTypeDao dao;

  public QaThresholdTypeDbServiceImpl(QaThresholdTypeDao dao) {
    if(dao == null){
      throw new IllegalArgumentException("The QaThresholdTypeDao passed to QaThresholdServiceImpl was null.");
    }
    this.dao = dao;
  }

  public List getActiveQaThresholdTypes() {
    return dao.getActiveQaThresholdTypes();
  }
}