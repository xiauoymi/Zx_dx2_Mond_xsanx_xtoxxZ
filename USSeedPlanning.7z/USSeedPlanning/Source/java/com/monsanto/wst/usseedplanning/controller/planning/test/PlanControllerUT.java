package com.monsanto.wst.usseedplanning.controller.planning.test;

import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.wst.usseedplanning.constants.MainConstants;
import com.monsanto.wst.usseedplanning.controller.planning.PlanController;
import com.monsanto.wst.usseedplanning.model.core.LoginUser;
import com.monsanto.wst.usseedplanning.model.maintenance.Revision;
import com.monsanto.wst.usseedplanning.model.planning.ChannelizedDemandRevisions;
import com.monsanto.wst.usseedplanning.model.planning.PlanType;
import com.monsanto.wst.usseedplanning.services.maintenance.forecast.ForecastService;
import com.monsanto.wst.usseedplanning.services.maintenance.forecast.mock.MockForecastService;
import com.monsanto.wst.usseedplanning.services.maintenance.seedEntity.YearService;
import com.monsanto.wst.usseedplanning.services.maintenance.seedEntity.mock.MockYearService;
import com.monsanto.wst.usseedplanning.services.maintenance.supply.SupplyService;
import com.monsanto.wst.usseedplanning.services.maintenance.supply.mock.MockSupplyService;
import com.monsanto.wst.usseedplanning.services.planning.PlanService;
import com.monsanto.wst.usseedplanning.services.planning.mock.MockPlanService;
import com.monsanto.wst.usseedplanning.utils.testutils.USSeedPlanningBaseTestCase;
import com.monsanto.wst.usseedplanning.view.factory.ViewFactory;
import com.monsanto.wst.usseedplanning.view.factory.mock.MockViewFactory;
import com.monsanto.wst.validator.HttpRequestErrors;
import com.monsanto.wst.validator.HttpValidator;
import com.monsanto.wst.validator.test.mock.MockHttpValidator;
import com.monsanto.wst.view.test.mock.MockView;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * Date: Sep 22, 2006
 * Time: 8:50:12 PM
 * <p/>
 * Unit test for the PlanController object.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class PlanControllerUT extends USSeedPlanningBaseTestCase {
    public void testCreate() throws Exception {
        PlanController controller = new PlanController((ViewFactory) null, (PlanService) null,
                (YearService) null, (HttpValidator) null, (ForecastService) null, (SupplyService) null);
        assertNotNull(controller);
    }

    public void testUnspecified() throws Exception {
        MockViewFactory viewFactory = new MockViewFactory();
        MockPlanService planService = new MockPlanService();
        MockForecastService forecastService = new MockForecastService();
        MockSupplyService supplyService = new MockSupplyService();
        PlanController controller = new PlanController(viewFactory, planService,
                new MockYearService(), (HttpValidator) null, forecastService, supplyService);
        MockUCCHelper helper = new MockUCCHelper(null);
        helper.setRequestParameterValue("plan_type", "794");
        controller.run(helper);
        MockView view = (MockView) viewFactory.getGenerateExcelReportView();
        assertTrue(view.wasViewRendered());
        assertNotNull(helper.getRequestAttributeValue("channelWithRevisionsList"));
        assertNotNull(helper.getRequestAttributeValue("supplyRevisionList"));
    }

    public void testUnspecifiedWithPlanId() throws Exception {
        MockViewFactory viewFactory = new MockViewFactory();
        MockPlanService planService = new MockPlanService();
        MockForecastService forecastService = new MockForecastService();
        MockSupplyService supplyService = new MockSupplyService();
        PlanController controller = new PlanController(viewFactory, planService,
                new MockYearService(), (HttpValidator) null, forecastService, supplyService);
        MockUCCHelper helper = new MockUCCHelper(null);
        helper.setRequestParameterValue("plan_type", "795");
        helper.setRequestParameterValue("plan_id", "100-100");
        controller.run(helper);
        MockView view = (MockView) viewFactory.getGenerateExcelReportView();
        assertTrue(view.wasViewRendered());
        assertNotNull(helper.getRequestAttributeValue("channelWithRevisionsList"));
        List channelWithRevisionsList = (List) helper.getRequestAttributeValue("channelWithRevisionsList");
        ChannelizedDemandRevisions channelWithRevision = (ChannelizedDemandRevisions) channelWithRevisionsList.get(0);
        Revision revision = (Revision) channelWithRevision.getDemandRevisions().get(1);
        assertTrue(revision.isSelected());
        assertNotNull(helper.getRequestAttributeValue("supplyRevisionList"));
        List supplyRevisionList = (List) helper.getRequestAttributeValue("supplyRevisionList");
        assertTrue(((Revision) supplyRevisionList.get(1)).isSelected());
    }

    public void testGeneratePlan() throws Exception {
        MockViewFactory viewFactory = new MockViewFactory();
        MockPlanService planService = new MockPlanService();
        MockHttpValidator validator = new MockHttpValidator();
        MockSupplyService supplyService = new MockSupplyService();
        PlanController controller = new PlanController(viewFactory, planService, new MockYearService(), validator, null,
                supplyService);
        MockUCCHelper helper = new MockUCCHelper(null);
        helper.setRequestParameterValue("method", "generatePlan");
        helper.setRequestParameterValue("channelRev", "123-12345");
        helper.setRequestParameterValue("supplyRev", "12345");
        helper.setRequestParameterValue("plan_name", "test");
        helper.setRequestParameterValue("plan_type", "12345");
        controller.run(helper);
        MockView view = (MockView) viewFactory.getUSSeedHomeView();
        assertTrue(view.wasViewRendered());
    }

    public void testGeneratePlanWithErrors() throws Exception {
        MockViewFactory viewFactory = new MockViewFactory();
        MockPlanService planService = new MockPlanService();
        HttpRequestErrors error = new HttpRequestErrors();
        MockForecastService forecastService = new MockForecastService();
        error.addError("test_field", "test validator");
        MockHttpValidator validator = new MockHttpValidator(error);
        MockSupplyService supplyService = new MockSupplyService();
        PlanController controller = new PlanController(viewFactory, planService, new MockYearService(), validator,
                forecastService, supplyService);
        MockUCCHelper helper = new MockUCCHelper(null);
        helper.setRequestParameterValue("method", "generatePlan");
        helper.setRequestParameterValue("channelRev", "123-12345");
        helper.setRequestParameterValue("supplyRev", "12345");
        helper.setRequestParameterValue("plan_name", "test");
        helper.setRequestParameterValue("plan_type", "12345");
        controller.run(helper);
        assertNull(helper.getRequestAttributeValue("plan"));
        assertNotNull(helper.getRequestAttributeValue("channelWithRevisionsList"));
        assertNotNull(helper.getRequestAttributeValue("supplyRevisionList"));
    }

    public void testOpenPlan() throws Exception {
        MockViewFactory viewFactory = new MockViewFactory();
        MockPlanService planService = new MockPlanService();
        MockHttpValidator validator = new MockHttpValidator();
        MockSupplyService supplyService = new MockSupplyService();
        PlanController controller = new PlanController(viewFactory, planService, new MockYearService(), validator, null,
                supplyService);
        MockUCCHelper helper = new MockUCCHelper(null);
        helper.setRequestParameterValue("method", "openPlan");
        helper.setRequestParameterValue("planId", "12345");
        helper.setRequestParameterValue("revisionId", "12345");
        controller.run(helper);
        assertEquals(planService.lookupPlanByCriteria(null), helper.getRequestAttributeValue("plan"));
        MockView view = (MockView) viewFactory.getPlanView();
        assertTrue(view.wasViewRendered());
    }

    public void testListPlans() throws Exception {
        MockViewFactory viewFactory = new MockViewFactory();
        MockPlanService planService = new MockPlanService();
        MockHttpValidator validator = new MockHttpValidator();
        MockSupplyService supplyService = new MockSupplyService();
        PlanController controller = new PlanController(viewFactory, planService, new MockYearService(), validator, null,
                supplyService);
        MockUCCHelper helper = new MockUCCHelper(null);
        helper.setRequestParameterValue("method", "listPlans");
        helper.setRequestParameterValue("plan_type", PlanType.PARENT_PLAN_TYPE_ID);
        controller.run(helper);
        assertNotNull(helper.getRequestAttributeValue("planList"));
        MockView view = (MockView) viewFactory.getListPlansView();
        assertTrue(view.wasViewRendered());
    }

    public void testUploadPlan() throws Exception {
        MockViewFactory viewFactory = new MockViewFactory();
        MockPlanService planService = new MockPlanService();
        MockHttpValidator validator = new MockHttpValidator();
        MockSupplyService supplyService = new MockSupplyService();
        PlanController controller = new PlanController(viewFactory, planService, new MockYearService(), validator, null,
                supplyService);
        MockUCCHelper helper = new MockUCCHelper(null);
        helper.setRequestParameterValue("method", "uploadPlan");
        helper.setRequestParameterValue("plan_type", PlanType.PARENT_PLAN_TYPE_ID);
        controller.run(helper);
        MockView view = (MockView) viewFactory.getSavePlanView();
        assertTrue(view.wasViewRendered());
    }

    public void testSavePlan() throws Exception {
        MockViewFactory viewFactory = new MockViewFactory();
        MockPlanService planService = new MockPlanService();
        MockHttpValidator validator = new MockHttpValidator();
        MockSupplyService supplyService = new MockSupplyService();
        PlanController controller = new PlanController(viewFactory, planService, new MockYearService(), validator, null,
                supplyService);
        MockUCCHelper helper = new MockUCCHelper(null);
        helper.addClientFile("com/monsanto/wst/usseedplanning/services/mock/HybridPlan.xls");
        helper.setRequestParameterValue("method", "savePlan");
        helper.setRequestParameterValue("comments", "test");
        controller.run(helper);
        MockView view = (MockView) viewFactory.getUSSeedHomeView();
        assertTrue(view.wasViewRendered());
        assertEquals("test", planService.getSavedComments());
    }

    public void testSavePlanWithErrors() throws Exception {
        MockViewFactory viewFactory = new MockViewFactory();
        HttpRequestErrors error = new HttpRequestErrors();
        error.addError("test_field", "test validator");
        MockHttpValidator validator = new MockHttpValidator(error);
        MockPlanService planService = new MockPlanService();
        MockSupplyService supplyService = new MockSupplyService();
        PlanController controller = new PlanController(viewFactory, planService, new MockYearService(), validator, null,
                supplyService);
        MockUCCHelper helper = new MockUCCHelper(null);
        helper.setRequestParameterValue("method", "savePlan");
        controller.run(helper);
    }

    public void testListPlansForCommit() throws Exception {
        MockViewFactory viewFactory = new MockViewFactory();
        MockPlanService planService = new MockPlanService();
        MockHttpValidator validator = new MockHttpValidator();
        MockSupplyService supplyService = new MockSupplyService();
        PlanController controller = new PlanController(viewFactory, planService, new MockYearService(), validator, null,
                supplyService);
        MockUCCHelper helper = new MockUCCHelper(null);
        helper.setRequestParameterValue("method", "listPlansForCommit");
        helper.setRequestParameterValue("plan_type", "795");
        controller.run(helper);
        MockView view = (MockView) viewFactory.getCommitPlanView();
        assertTrue(view.wasViewRendered());
    }

    public void testCommitPlan() throws Exception {
        MockViewFactory viewFactory = new MockViewFactory();
        MockPlanService planService = new MockPlanService();
        MockHttpValidator validator = new MockHttpValidator();
        MockSupplyService supplyService = new MockSupplyService();
        PlanController controller = new PlanController(viewFactory, planService, new MockYearService(), validator, null,
                supplyService);
        MockUCCHelper helper = new MockUCCHelper(null);
        helper.setRequestParameterValue("method", "commitPlan");
        helper.setRequestParameterValue("comments", "test");
        helper.setRequestParameterValue("planId", "100-101");
        LoginUser currentUser = new LoginUser("NJMINSH");
        helper.setSessionParameter(MainConstants.LOGINUSER, currentUser);
        controller.run(helper);
        MockView view = (MockView) viewFactory.getUSSeedHomeView();
        assertTrue(view.wasViewRendered());
        assertEquals("test", planService.getSavedComments());
        assertEquals(new Long(100), planService.getPlanId());
        assertEquals(new Long(101), planService.getPlanRevisionId());
        assertEquals(currentUser, planService.getCurrentUser());
    }

    public void testCommitPlanWithErrors() throws Exception {
        MockViewFactory viewFactory = new MockViewFactory();
        MockPlanService planService = new MockPlanService();
        HttpRequestErrors errors = new HttpRequestErrors();
        errors.addError("test_field", "test validator");
        MockHttpValidator validator = new MockHttpValidator(errors);
        MockSupplyService supplyService = new MockSupplyService();
        PlanController controller = new PlanController(viewFactory, planService, new MockYearService(), validator, null,
                supplyService);
        MockUCCHelper helper = new MockUCCHelper(null);
        helper.setRequestParameterValue("method", "commitPlan");
        helper.setRequestParameterValue("comments", "test");
        helper.setRequestParameterValue("planId", "100-101");
        helper.setRequestParameterValue("plan_type", "795");
        controller.run(helper);
        MockView view = (MockView) viewFactory.getCommitPlanView();
        assertTrue(view.wasViewRendered());
        assertEquals(errors, helper.getRequestAttributeValue("errors"));
    }

    public void testDownloadPlan() throws Exception {
        MockViewFactory viewFactory = new MockViewFactory();
        MockPlanService planService = new MockPlanService();
        MockHttpValidator validator = new MockHttpValidator();
        MockSupplyService supplyService = new MockSupplyService();
        PlanController controller = new PlanController(viewFactory, planService, new MockYearService(), validator, null,
                supplyService);
        MockUCCHelper helper = new MockUCCHelper(null);
        helper.setRequestParameterValue("method", "downloadPlan");
        helper.setRequestParameterValue("plan", "12345-67890");
        controller.run(helper);
        MockView view = (MockView) viewFactory.getDownloadPlanView();
        assertTrue(view.wasViewRendered());
        assertEquals("12345", helper.getRequestAttributeValue("planId"));
        assertEquals("67890", helper.getRequestAttributeValue("revisionId"));
    }
}
