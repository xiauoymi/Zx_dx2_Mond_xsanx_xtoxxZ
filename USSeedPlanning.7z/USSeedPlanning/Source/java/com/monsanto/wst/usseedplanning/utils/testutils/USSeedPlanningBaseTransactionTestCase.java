/*
 Copyright:  Copyright � 2006 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.usseedplanning.utils.testutils;

import com.monsanto.wst.commonutils.reflection.ObjectInspector;
import com.monsanto.wst.commonutils.resources.ResourceUtils;
import com.monsanto.wst.dbtemplate.plugins.dbunit.DbUnitBaseTransactionTestCase;
import com.monsanto.wst.dbtemplate.plugins.dbunit.DBUnitConnectionInterceptor;
import com.monsanto.wst.dbtemplate.DBTemplate;
import com.monsanto.wst.dbtemplate.transaction.TransactionManager;
import com.monsanto.wst.usseedplanning.constants.MainConstants;
import com.monsanto.wst.factory.AbstractGenericFactory;
import org.dbunit.dataset.IDataSet;
import org.dbunit.dataset.xml.FlatXmlDataSet;
import org.dbunit.operation.DatabaseOperation;
import org.dbunit.database.IDatabaseConnection;
import org.dbunit.ext.oracle.OracleConnection;
import org.xml.sax.InputSource;

import java.io.File;

/**
 * This class is a base TestCase for setting up the environment when doing integration testing against a database.  It
 * utilizes dbunit to setup and tear down data for the test.
 *
 * @author jdpoul
 * @version $Revision: 1.9 $
 */
public abstract class USSeedPlanningBaseTransactionTestCase extends DbUnitBaseTransactionTestCase {

  /**
   * This constructor creates a new jdbc connection that will be used by both dbtemplate and dbunit and caches it for
   * the duration of the test.
   */
  public USSeedPlanningBaseTransactionTestCase() {
    super(new USSeedPlanningTestUtils(new ObjectInspector()), "oracle.jdbc.driver.OracleDriver",
      "jdbc:oracle:thin:@dev01.monsanto.com:1521:comgend", "usseedplanning", "usseedplanning_01");
//        super(new USSeedPlanningTestUtils(new ObjectInspector()), "oracle.jdbc.driver.OracleDriver",
//                "jdbc:oracle:thin:@M3013538.na.ds.monsanto.com:1521:XE", "usseedplanning", "usseedplanning_01");
  }

  protected void setUp() throws Exception {
    USSeedPlanningTestUtils testUtils = (USSeedPlanningTestUtils) getTestUtils();
    testUtils.setupLogging(MainConstants.APPLICATION_NAME);
    testUtils.setupContainer();
    super.setUp();
  }

  /**
   * Tears down the environment.
   *
   * @exception Exception - If unable to tear down the environment.
   */
  protected void tearDown() throws Exception {
    USSeedPlanningTestUtils testUtils = (USSeedPlanningTestUtils) getTestUtils();
    super.tearDown();
    testUtils.tearDownContainer();
    testUtils.tearDownLogging();
  }

  /**
   * This method returns the setup operation used by dbunit, ie. insert setup data.
   *
   * @return DatabaseOperation - Object representing the setup operation.
   *
   * @exception Exception - If unable to setup data.
   */
  protected DatabaseOperation getSetUpOperation()
    throws Exception {
    return DatabaseOperation.INSERT;
  }

  /**
   * This method returns the tear down operation used by dbunit, ie. delete inserted records.
   *
   * @return DatabaseOperation - Object representing the tear down operation.
   *
   * @exception Exception - If unable to setup data.
   */
  protected DatabaseOperation getTearDownOperation()
    throws Exception {
    return DatabaseOperation.NONE;
  }

  /**
   * This method is the abstract method used to determine the location of the dbunit configuration file.
   *
   * @return String - Representing the path to the config file.
   */
  protected abstract String getConfigPath();

  /**
   * This method returns the data set that should be processed by dbunit.
   *
   * @return IDataSet - Object representing the data set.
   *
   * @exception Exception - If unable to retrieve the data set.
   */
  protected IDataSet getDataSet() throws Exception {
    File file = new ResourceUtils().convertPathToFile(getConfigPath());
    InputSource in = new InputSource(file.getAbsolutePath());
    return new FlatXmlDataSet(in);
  }

  protected void cleanDatabase(TransactionManager txManager) {
    DBTemplate template = (DBTemplate) AbstractGenericFactory.getInstance().getBean("dbTemplate");
    template.executeDelete("deleteAllPlanDetails", null);
    template.executeDelete("deleteAllDemandCrossReference", null);
    template.executeDelete("deleteAllPlanNumbers", null);
    template.executeDelete("deleteAllCommercialProduct", null);
    template.executeDelete("deleteAllProductDetails", null);
    template.executeDelete("deleteAllSupply", null);
    template.executeDelete("deleteAllStageFactors", null);
    template.executeDelete("deleteAllQAThresholds", null);
    template.executeDelete("deleteAllYieldTargets", null);
    template.executeDelete("deleteAllYears", null);
    template.executeDelete("deleteAllBaseNames", null);
    template.executeDelete("deleteAdmins", null);
  }

  protected String getDatabaseSchema() {
    return "USSeedPlanning";
  }
}