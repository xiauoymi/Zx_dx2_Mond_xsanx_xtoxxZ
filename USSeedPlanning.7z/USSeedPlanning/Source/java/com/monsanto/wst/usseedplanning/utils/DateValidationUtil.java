package com.monsanto.wst.usseedplanning.utils;

import com.monsanto.wst.usseedplanning.constants.ErrorConstants;
import com.monsanto.wst.usseedplanning.constants.MainConstants;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.StringTokenizer;

/**
 * Created by IntelliJ IDEA. User: rgeorge Date: Aug 4, 2006 Time: 8:32:26 AM To change this template use File |
 * Settings | File Templates.
 */
public class DateValidationUtil {

  private static DateFormat df = new SimpleDateFormat(MainConstants.DATE_FORMAT);

  public static List validDateEnteredAndGetErrorMessage(String date, List errorlist) {
    if (date != null && !date.equals("")) {
      checkFormatForDate(df, date, errorlist);
      if (errorlist.size() == 0) {
        tokenizeDateToValidate(date, errorlist);
      }
    }
    return errorlist;
  }

  private static void tokenizeDateToValidate(String date, List errorlist) {
    StringTokenizer st = new StringTokenizer(date, "/");
    for (int i = 0; i < 3; i++) {
      if (i == 0) {
        st.nextToken();
      }
      if (i == 1) {
        st.nextToken();
      }
      tokenizeYear(i, st, errorlist);
    }
  }

  private static void tokenizeYear(int i, StringTokenizer st, List errorlist) {
    if (i == 2) {
      String year = st.nextToken();
      if (year.length() > 4) {
        errorlist.add(ErrorConstants.INVALID_DATE_ERROR_MESSAGE);
      }
    }
  }

  private static void checkFormatForDate(DateFormat df, String date, List errorlist) {
    try {
      java.sql.Date check_date = new java.sql.Date(df.parse(date).getTime());
      String c_date = (df.format((check_date)));
      if ((!c_date.equals(date))) {
        errorlist.add(ErrorConstants.INVALID_DATE_ERROR_MESSAGE);
      }
    } catch (ParseException e) {
      errorlist.add(ErrorConstants.INVALID_DATE_FORMAT_ERROR_MESSAGE);
    }
  }

  public static void validDateSequencesEntered(String startDate, String endDate, List errorList) {
    Date sDate = null;
    Date eDate = null;
    if (startDate != null && !startDate.equals("") && endDate != null && !endDate.equals("")) {
      try {
        sDate = convertStringToRespDate(startDate);
        eDate = convertStringToRespDate(endDate);
        if (eDate.before(sDate)) {
          errorList.add(ErrorConstants.DATE_SEQUENCE_ERROR_MESSAGE);
        }
      } catch (ParseException e) {
        errorList.add(ErrorConstants.INVALID_DATE_ERROR_MESSAGE);
      }
    }
  }

  private static Date convertStringToRespDate(String startDateString) throws ParseException {
    return df.parse(startDateString);
  }

  public static Date convertStringToDate(String startDateString) {
    if (startDateString == null || startDateString.equals("")) {
      return null;
    } else {
      try {
        return df.parse(startDateString);
      } catch (ParseException e) {
        return null;
      }
    }
  }

  public static String convertDateToString(Date inputDate) {
    return getDateFormat(inputDate);
  }

  private static String getDateFormat(Date date) {
    try {
      return df.format(date);
    }
    catch (Exception e) {
      return "";
    }
  }
}
