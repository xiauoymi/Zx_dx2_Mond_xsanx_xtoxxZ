package com.monsanto.wst.usseedplanning.controller.validator.test;

import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.wst.usseedplanning.controller.validator.UpdateSupplyValidator;
import com.monsanto.wst.validator.HttpRequestErrors;
import junit.framework.TestCase;

/**
 * Created by IntelliJ IDEA.
 * Date: Aug 17, 2006
 * Time: 8:47:11 AM
 * <p/>
 * Unit test for the AddSupplyValidator object.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class UpdateSupplyValidatorUT extends TestCase {
    public void testCreate() throws Exception {
        UpdateSupplyValidator validator = new UpdateSupplyValidator();
        assertNotNull(validator);
    }

    public void testValidatePass() throws Exception {
        UpdateSupplyValidator validator = new UpdateSupplyValidator();
        HttpRequestErrors errors = validator.validate(createRequest());
        assertTrue(errors.isEmpty());
    }

    public void testValidateFail() throws Exception {
        UpdateSupplyValidator validator = new UpdateSupplyValidator();
        MockUCCHelper helper = new MockUCCHelper(null);
        HttpRequestErrors errors = validator.validate(helper);
        assertFalse(errors.isEmpty());
        assertEquals("The Comment field is required.", errors.getError("comments"));
        assertEquals("The File field is required.", errors.getError("supplyFile"));
    }

    private MockUCCHelper createRequest() {
        MockUCCHelper helper = new MockUCCHelper(null);
        helper.setRequestParameterValue("comments", "Test Comments");
        helper.addClientFile("");
        return helper;
    }
}
