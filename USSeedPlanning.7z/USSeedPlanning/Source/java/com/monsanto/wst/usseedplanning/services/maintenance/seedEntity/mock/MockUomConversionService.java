/*
 MockUomConversionService was created on Sep 25, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.usseedplanning.services.maintenance.seedEntity.mock;

import com.monsanto.wst.usseedplanning.model.maintenance.supply.conversion.UomConversion;
import com.monsanto.wst.usseedplanning.services.maintenance.seedEntity.UomConversionService;

import java.util.ArrayList;
import java.util.List;

/**
 * Filename:    $RCSfile: MockUomConversionService.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $
 * On:	$Date: 2006-12-01 20:25:04 $
 *
 * @author sspati1
 * @version $Revision: 1.2 $
 */
public class MockUomConversionService implements UomConversionService {
  public List getAllFactors() {
    List list = new ArrayList();
    UomConversion uomConversion = new UomConversion();
    uomConversion.setDescription("40M");
    uomConversion.setFactor(new Double(0.5));
    list.add(uomConversion);
    uomConversion = new UomConversion();
    uomConversion.setDescription("80M");
    uomConversion.setFactor(new Double(1));
    list.add(uomConversion);
    return list;
  }
}