package com.monsanto.wst.usseedplanning.services.core.filetemplate.test;

import com.monsanto.wst.commonutils.resources.ResourceUtils;
import com.monsanto.wst.filetemplate.FileTemplate;
import com.monsanto.wst.filetemplate.mock.MockFileTemplate;
import com.monsanto.wst.usseedplanning.services.core.filetemplate.FileTemplateImportSpreadsheetService;
import junit.framework.TestCase;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * Date: Aug 8, 2006
 * Time: 12:10:51 PM
 * <p/>
 * Unit test for the FileTemplateImportSpreadsheetService object.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class FileTemplateImportSpreadsheetServiceUT extends TestCase {
    public void testCreate() throws Exception {
        FileTemplateImportSpreadsheetService service = new FileTemplateImportSpreadsheetService((FileTemplate) null);
        assertNotNull(service);
    }

    public void testGetCommonForecasts() throws Exception {
        MockFileTemplate fileTemplate = new MockForecastFileTemplate();
        FileTemplateImportSpreadsheetService service = new FileTemplateImportSpreadsheetService(fileTemplate);
        File file = new File("");
        List demandForecastList = service.getCommonForecasts(file);
        assertEquals("commonForecast", fileTemplate.getFileId());
        assertEquals(file, fileTemplate.getFile());
        assertNotNull(demandForecastList);
    }

    public void testGetDemandForecasts() throws Exception {
        MockFileTemplate fileTemplate = new MockForecastFileTemplate();
        FileTemplateImportSpreadsheetService service = new FileTemplateImportSpreadsheetService(fileTemplate);
        File file = new File("");
        List demandForecastList = service.getDemandForecasts(file);
        assertEquals("demandForecast", fileTemplate.getFileId());
        assertEquals(file, fileTemplate.getFile());
        assertNotNull(demandForecastList);
    }

	public void testGetATPSupply() throws Exception {
	    MockFileTemplate fileTemplate = new MockForecastFileTemplate();
	    FileTemplateImportSpreadsheetService service = new FileTemplateImportSpreadsheetService(fileTemplate);
	    File file = new ResourceUtils().convertPathToFile("com/monsanto/wst/usseedplanning/services/mock/ATPExampleSmall.xls");
	    List supplyList = service.getATPSupply(file);
	    assertEquals("ATPSupply", fileTemplate.getFileId());
	    assertEquals(file, fileTemplate.getFile());
	    assertNotNull(supplyList);
	}
	public void testGetCommitPlan() throws Exception {
	    MockFileTemplate fileTemplate = new MockForecastFileTemplate();
	    FileTemplateImportSpreadsheetService service = new FileTemplateImportSpreadsheetService(fileTemplate);
	    File file = new ResourceUtils().convertPathToFile("com/monsanto/wst/usseedplanning/services/mock/HybridPlan.xls");
	    List planList = service.getSavePlanSpreadSheet(file);
	    assertEquals("save_plan", fileTemplate.getFileId());
	    assertEquals(file, fileTemplate.getFile());
	    assertNotNull(planList);
	}
	public void testGetImportHybridToDemandPlan() throws Exception {
	    MockFileTemplate fileTemplate = new MockForecastFileTemplate();
	    FileTemplateImportSpreadsheetService service = new FileTemplateImportSpreadsheetService(fileTemplate);
	    File file = new ResourceUtils().convertPathToFile("com/monsanto/wst/usseedplanning/services/mock/HybridPlan.xls");
	    List planList = service.getImportHybridToDemand(file);
	    assertEquals("hybrid_demand", fileTemplate.getFileId());
	    assertEquals(file, fileTemplate.getFile());
	    assertNotNull(planList);
	}

    private class MockForecastFileTemplate extends MockFileTemplate {
        public List importFile(String fileId, File file) throws IOException {
            super.importFile(fileId, file);
            return new ArrayList();
        }
    }
}
