package com.monsanto.wst.usseedplanning.services.maintenance.supply.test;

import com.monsanto.wst.usseedplanning.dao.*;
import com.monsanto.wst.usseedplanning.services.core.ImportSpreadsheetService;
import com.monsanto.wst.usseedplanning.services.maintenance.supply.UpdateSupplyServiceFactoryImpl;
import com.monsanto.wst.usseedplanning.services.maintenance.supply.UpdateSupplyService;
import com.monsanto.wst.usseedplanning.services.maintenance.supply.YATPFNDUpdateSupplyService;
import com.monsanto.wst.usseedplanning.services.maintenance.supply.ZDCAUpdateSupplyService;
import com.monsanto.wst.usseedplanning.utils.testutils.USSeedPlanningBaseTestCase;
import com.monsanto.wst.usseedplanning.model.maintenance.supply.SupplyType;

/**
 * Created by IntelliJ IDEA.
 * Date: Feb 13, 2007
 * Time: 8:54:52 AM
 * <p/>
 * TODO: Enter description for class.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class UpdateSupplyServiceFactoryImpl_UT extends USSeedPlanningBaseTestCase {
    public void testCreate() throws Exception {
        UpdateSupplyServiceFactoryImpl factory = new UpdateSupplyServiceFactoryImpl((ImportSpreadsheetService) null,
                (SupplyDao) null, (SupplyTypeDao) null, (RevisionDao) null, (ChannelDao) null, (UomConversionDao) null,
                (YearDao) null);
        assertNotNull(factory);
    }

    public void testGetUpdateSupplyServiceForYATPFNDSupplyType() throws Exception {
        UpdateSupplyServiceFactoryImpl factory = new UpdateSupplyServiceFactoryImpl((ImportSpreadsheetService) null,
                (SupplyDao) null, (SupplyTypeDao) null, (RevisionDao) null, (ChannelDao) null, (UomConversionDao) null,
                (YearDao) null);
        UpdateSupplyService service = factory.getUpdateSupplyService(SupplyType.ATP_SUPPLY_TYPE);
        assertNotNull(service);
        assertEquals(YATPFNDUpdateSupplyService.class, service.getClass());
    }

    public void testGetUpdateSupplyServiceForZDCASupplyType() throws Exception {
        UpdateSupplyServiceFactoryImpl factory = new UpdateSupplyServiceFactoryImpl((ImportSpreadsheetService) null,
                (SupplyDao) null, (SupplyTypeDao) null, (RevisionDao) null, (ChannelDao) null, (UomConversionDao) null,
                (YearDao) null);
        UpdateSupplyService service = factory.getUpdateSupplyService(SupplyType.ZDCA_SUPPLY_TYPE);
        assertNotNull(service);
        assertEquals(ZDCAUpdateSupplyService.class, service.getClass());
    }
}
