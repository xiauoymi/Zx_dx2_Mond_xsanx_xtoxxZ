package com.monsanto.wst.usseedplanning.services.maintenance.supply;

import com.monsanto.wst.usseedplanning.services.core.ImportSpreadsheetService;
import com.monsanto.wst.usseedplanning.dao.*;
import com.monsanto.wst.usseedplanning.model.maintenance.supply.SupplyType;

/**
 * Created by IntelliJ IDEA.
 * Date: Feb 12, 2007
 * Time: 4:44:09 PM
 * <p/>
 * TODO: Enter description for class.
 * TODO: I refactored the test for this class away, need to readd it.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class UpdateSupplyServiceFactoryImpl implements UpdateSupplyServiceFactory {
    private ImportSpreadsheetService importSpreadsheetService;
    private SupplyDao supplyDao;
    private SupplyTypeDao supplyTypeDao;
    private RevisionDao revisionDao;
    private ChannelDao channelDao;
    private UomConversionDao uomConversionDao;
    private YearDao yearDao;

    public UpdateSupplyServiceFactoryImpl(ImportSpreadsheetService importSpreadsheetService, SupplyDao supplyDao,
                                          SupplyTypeDao supplyTypeDao, RevisionDao revisionDao, ChannelDao channelDao,
                                          UomConversionDao uomConversionDao, YearDao yearDao) {
        this.importSpreadsheetService = importSpreadsheetService;
        this.supplyDao = supplyDao;
        this.supplyTypeDao = supplyTypeDao;
        this.revisionDao = revisionDao;
        this.channelDao = channelDao;
        this.uomConversionDao = uomConversionDao;
        this.yearDao = yearDao;
    }

    public UpdateSupplyService getUpdateSupplyService(String supplyType) {
        if (SupplyType.ATP_SUPPLY_TYPE.equals(supplyType)) {
            return new YATPFNDUpdateSupplyService(importSpreadsheetService, supplyDao, supplyTypeDao, revisionDao,
                    channelDao, yearDao);
        } else {
            return new ZDCAUpdateSupplyService(importSpreadsheetService, supplyDao, supplyTypeDao, revisionDao,
                    channelDao, uomConversionDao, yearDao);
        }
    }
}
