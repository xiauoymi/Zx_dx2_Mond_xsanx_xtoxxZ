/*
 DashboardReportServiceImpl was created on Oct 12, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.usseedplanning.services.reports;

import com.monsanto.wst.usseedplanning.dao.DashboardReportDao;

import java.util.List;

/**
 * Filename:    $RCSfile: DashboardReportServiceImpl.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ffbrac $    	 On:	$Date: 2006-10-12 23:08:27 $
 *
 * @author ffbrac
 * @version $Revision: 1.1 $
 */
public class DashboardReportServiceImpl implements DashboardReportService{
	private DashboardReportDao reportDao;

	public DashboardReportServiceImpl(DashboardReportDao reportDao) {
		this.reportDao = reportDao;
	}

	public List getDashboardReport() {
		return reportDao.getDashboardReport();
	}
}