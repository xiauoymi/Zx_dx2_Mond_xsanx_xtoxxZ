package com.monsanto.wst.usseedplanning.services.core.mock;

import com.monsanto.wst.usseedplanning.model.maintenance.DemandData;
import com.monsanto.wst.usseedplanning.model.maintenance.DemandForecast;
import com.monsanto.wst.usseedplanning.model.maintenance.Channel;
import com.monsanto.wst.usseedplanning.model.maintenance.CommonData;
import com.monsanto.wst.usseedplanning.model.maintenance.supply.Supply;
import com.monsanto.wst.usseedplanning.model.maintenance.supply.data.SupplyBags;
import com.monsanto.wst.usseedplanning.model.maintenance.supply.data.SupplyData;
import com.monsanto.wst.usseedplanning.model.maintenance.supply.identifier.SupplyIdentifiers;
import com.monsanto.wst.usseedplanning.model.planning.Plan;
import com.monsanto.wst.usseedplanning.model.planning.PlanEntry;
import com.monsanto.wst.usseedplanning.model.planning.UserEnterData;
import com.monsanto.wst.usseedplanning.model.cache.ProductDetails;
import com.monsanto.wst.usseedplanning.services.core.ImportSpreadsheetService;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * Date: Aug 8, 2006
 * Time: 2:18:28 PM
 * <p/>
 * Mock implementation of the ImportSpreadsheetService interface.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class MockImportSpreadsheetService implements ImportSpreadsheetService {
    private File spreadsheet;
    private UserEnterData userData = new UserEnterData();

    public List getDemandForecasts(File spreadsheet) throws IOException {
        this.spreadsheet = spreadsheet;
        List demandForecastList = new ArrayList();
        demandForecastList.add(createDemandForecast());
        demandForecastList.add(createDemandForecast());
        demandForecastList.add(createDemandForecast());
        return demandForecastList;
    }

    public List getATPSupply(File file) throws IOException {
        List supplyList = new ArrayList();
        supplyList.add(createSupply());
        supplyList.add(createSupply());
        return supplyList;
    }

    public List getZDCASupply(File file) throws IOException {
        List supplyList = new ArrayList();
        supplyList.add(createSupply());
        supplyList.add(createSupply());
        return supplyList;
    }

    public List getCommonUpload(String columnName,File file) throws IOException {
        ArrayList commonDataList = new ArrayList();
        CommonData commonData = new CommonData();
        commonData.setName("test");
        commonDataList.add(commonData);
        commonDataList.add(commonData);
        commonDataList.add(commonData);
        return commonDataList;
    }

    public List getSavePlanSpreadSheet(File file) throws IOException {
        this.spreadsheet = file;
        List planEntryList = new ArrayList();
        PlanEntry entry = new PlanEntry();
        entry.setUserData(userData);
        ProductDetails productDetails = new ProductDetails();
        productDetails.setManufacturingName("newMFGName");
        ProductDetails femaleDetails = new ProductDetails();
        femaleDetails.setPreCommercialName("NB001");
        femaleDetails.setManufacturingName("HCL123");
        femaleDetails.setVersion("1A");
        productDetails.setFemaleParent(femaleDetails);
        ProductDetails maleDetails = new ProductDetails();
        maleDetails.setPreCommercialName("NB002");
        maleDetails.setManufacturingName("HCL345");
        maleDetails.setVersion("1B");
        productDetails.setMaleParent(maleDetails);
        entry.setProductDetails(productDetails);
        planEntryList.add(entry);
        return planEntryList;
    }

    public UserEnterData getUserData() {
        return userData;
    }

    public List getImportHybridToDemand(File file) throws IOException {
        this.spreadsheet = file;
        return new ArrayList();
    }


    public byte[] getPlanSpreadsheet(Plan plan, String inputSchema) {
        return null;
    }

    private DemandForecast createDemandForecast() {
        DemandForecast demandForecast = new DemandForecast();
        demandForecast.setYear(new Integer(2006));
        demandForecast.setChannelName("BRANDED");
        demandForecast.setCommonName("HC1151");
        demandForecast.setData(new DemandData());
        demandForecast.getData().setUnits(new Long(12345));
        return demandForecast;
    }

    public List getCommonForecasts(File spreadsheet) throws IOException {
        this.spreadsheet = spreadsheet;
        List demandForecastList = new ArrayList();
        demandForecastList.add(createCommonForecast());
        demandForecastList.add(createCommonForecast());
        demandForecastList.add(createCommonForecast());
        return demandForecastList;
    }

    private DemandForecast createCommonForecast() {
        DemandForecast demandForecast = new DemandForecast();
        demandForecast.setYear(new Integer(2006));
        demandForecast.setChannelName("ASI");
        demandForecast.setCommonName("HC1151");
        demandForecast.setData(new DemandData());
        demandForecast.getData().setUnits(new Long(12345));
        demandForecast.getData().setWinterUnits(new Long(54321));
        demandForecast.getData().setNextYearUnits(new Long(67890));
        return demandForecast;
    }

    private Supply createSupply() {
        Supply supply = new Supply();
        supply.setIdentifiers(new SupplyIdentifiers());
        supply.getIdentifiers().setDescription("C DK DK440 P26 80M US");
        supply.getIdentifiers().setManufacturingName("DK440");
        supply.getIdentifiers().setSLOC("*" + Channel.BRANDED_CHANNEL);
        supply.setData(new SupplyData());
        supply.getData().setBags(new SupplyBags());
        supply.getData().getBags().setUnrestricted(new Double(23));
        supply.getData().getBags().setRestricted(new Double(56));
        supply.getData().getBags().setBlocked(new Double(456));
        return supply;
    }

    public File getSpreadsheet() {
        return spreadsheet;
    }
}
