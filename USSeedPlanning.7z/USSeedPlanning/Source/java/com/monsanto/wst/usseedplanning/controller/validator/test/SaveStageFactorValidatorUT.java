/*
 EditStageFactorValidatorUT was created on Sep 19, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.usseedplanning.controller.validator.test;

import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.wst.usseedplanning.controller.validator.SaveStageFactorValidator;
import com.monsanto.wst.validator.HttpRequestErrors;
import junit.framework.TestCase;

/**
 * Filename:    $RCSfile: SaveStageFactorValidatorUT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: SSPATI1 $    	 On:	$Date: 2006-09-20 17:41:29 $
 *
 * @author sspati1
 * @version $Revision: 1.3 $
 */
public class SaveStageFactorValidatorUT extends TestCase{

  public void testCreate() throws Exception {
    SaveStageFactorValidator validator = new SaveStageFactorValidator();
    assertNotNull(validator);
  }

    public void testValidatePass() throws Exception {
        SaveStageFactorValidator validator = new SaveStageFactorValidator();
        HttpRequestErrors errors = validator.validate(createRequest());
        assertTrue(errors.isEmpty());
    }

    public void testValidateFail() throws Exception {
        SaveStageFactorValidator validator = new SaveStageFactorValidator();
        MockUCCHelper helper = new MockUCCHelper(null);
        HttpRequestErrors errors = validator.validate(helper);
        assertFalse(errors.isEmpty());
        assertEquals("Comments for Stage Factor is required.", errors.getError("comments"));
        assertEquals("Stage Factor for Stage Factor is required.", errors.getError("factor"));
    }

    public void testValidateFactorFail() throws Exception {
        SaveStageFactorValidator validator = new SaveStageFactorValidator();
        MockUCCHelper helper = new MockUCCHelper(null);
        helper.setRequestParameterValue("comments", "Test Comments");
        helper.setRequestParameterValue("factor", "factor");
        HttpRequestErrors errors = validator.validate(helper);
        assertFalse(errors.isEmpty());
        assertEquals("Stage Factor should be a numeric value.", errors.getError("factorNumeric"));
    }

    private MockUCCHelper createRequest() {
        MockUCCHelper helper = new MockUCCHelper(null);
        helper.setRequestParameterValue("comments", "Test Comments");
        helper.setRequestParameterValue("factor", "23");
        return helper;
    }
}