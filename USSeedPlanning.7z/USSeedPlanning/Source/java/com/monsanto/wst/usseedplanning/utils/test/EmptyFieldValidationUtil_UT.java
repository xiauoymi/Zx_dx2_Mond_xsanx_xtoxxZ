package com.monsanto.wst.usseedplanning.utils.test;

import com.monsanto.wst.usseedplanning.utils.EmptyFieldValidationUtil;
import junit.framework.TestCase;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Aug 4, 2006
 * Time: 8:31:44 AM
 * To change this template use File | Settings | File Templates.
 */
public class EmptyFieldValidationUtil_UT extends TestCase {

    public void testCreate() throws Exception {
        EmptyFieldValidationUtil util = new EmptyFieldValidationUtil();
        assertNotNull(util);
    }

    public void testCheckErrorListForNullListAndNonEmptyValuePassedIn() throws Exception {
        List errors = EmptyFieldValidationUtil.updateErrorListForRequiredField("value",null);
        assertNull(errors);
    }

    public void testCheckErrorListForEmptyListAndNonEmptyValuePassedIn() throws Exception {
        List errors = EmptyFieldValidationUtil.updateErrorListForRequiredField("value",new ArrayList());
        assertEquals(0, errors.size());
        assertNotNull(errors);
    }

    public void testCheckErrorListForNonEmptyListAndNonEmptyValuePassedIn() throws Exception {
        List errorList = new ArrayList();
        errorList.add("Error 1");
        errorList = EmptyFieldValidationUtil.updateErrorListForRequiredField("",errorList);
        assertEquals(1, errorList.size());
        assertEquals("Error 1",errorList.get(0));
    }

    public void testCheckErrorListNotEmptyForEmptyField() throws Exception {
        List errorList = new ArrayList();
        List errors = EmptyFieldValidationUtil.updateErrorListForRequiredField("",errorList);
        assertEquals(1, errors.size());
        assertEquals("Please Fill in the Fields marked as required",errors.get(0));
    }

    public void testCheckEmptyErrorListForNonEmptyField() throws Exception {
        List errorList = new ArrayList();
        List errors = EmptyFieldValidationUtil.updateErrorListForRequiredField("value",errorList);
        assertEquals(0, errors.size());
    }
}
