/*
 UomConversionServiceUT was created on Sep 25, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.usseedplanning.services.maintenance.seedEntity.dbServices.test;

import com.monsanto.wst.usseedplanning.services.maintenance.seedEntity.dbServices.UomConversionServiceImpl;
import com.monsanto.wst.usseedplanning.services.maintenance.seedEntity.mock.MockUomConversionService;
import com.monsanto.wst.usseedplanning.dao.UomConversionDao;
import junit.framework.TestCase;

/**
 * Filename:    $RCSfile: UomConversionServiceUT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: SSPATI1 $    	 On:	$Date: 2006-09-25 20:21:26 $
 *
 * @author sspati1
 * @version $Revision: 1.1 $
 */
public class UomConversionServiceUT extends TestCase{

  public void testCreate() throws Exception {
    UomConversionServiceImpl uomConversion = new UomConversionServiceImpl((UomConversionDao) null);
    assertNotNull(uomConversion);
  }

  public void testGetAllFactors() throws Exception {
    MockUomConversionService service = new MockUomConversionService();
    assertEquals(2,service.getAllFactors().size());
  }
}