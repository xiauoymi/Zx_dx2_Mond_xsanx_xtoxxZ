package com.monsanto.wst.usseedplanning.exception.test;

import com.monsanto.wst.usseedplanning.exception.NoResultsException;
import junit.framework.TestCase;

/**
 * Created by IntelliJ IDEA.
 * Date: Aug 8, 2006
 * Time: 5:31:22 PM
 * <p/>
 * Unit test for the NoResultsException object.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class NoResultsExceptionUT extends TestCase {
    public void testCreate() throws Exception {
        NoResultsException exception = new NoResultsException("Test");
        assertNotNull(exception);
        assertEquals("Test", exception.getMessage());
    }
}
