/*
 JspCommonUploadView_UT was created on Oct 10, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.usseedplanning.view.jsp.maintenance.test;

import com.monsanto.AbstractLogging.Logger;
import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.wst.commonutils.testutils.TestUtils;
import com.monsanto.wst.usseedplanning.constants.MainConstants;
import com.monsanto.wst.usseedplanning.view.jsp.maintenance.JspCommonUploadView;
import com.monsanto.wst.view.ViewRenderingException;
import com.monsanto.wst.view.test.mock.MockUCCHelperThrowsIOException;
import junit.framework.TestCase;

/**
 * Filename:    $RCSfile: JspCommonUploadView_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ffbrac $    	 On:	$Date: 2006-10-10 14:04:00 $
 *
 * @author ffbrac
 * @version $Revision: 1.1 $
 */
public class JspCommonUploadView_UT extends TestCase {
	MockUCCHelper helper = null;

	public void testCreate() throws Exception{
	    JspCommonUploadView commonUploadPage = new JspCommonUploadView();
	    assertNotNull(commonUploadPage);
	}

	protected void setUp() throws Exception {
	    new TestUtils().setupLogging(MainConstants.APPLICATION_NAME);
	    super.setUp();
	    helper = new MockUCCHelper(null);
	}

	public void testRenderView() throws Exception {
		JspCommonUploadView commonUploadPage = new JspCommonUploadView();
	    commonUploadPage.renderView(helper);
	    assertTrue(helper.wasSentTo(MainConstants.COMMON_UPLOAD_PAGE));
	}

	public void testRenderViewThrowsException() throws Exception {
	    MockUCCHelperThrowsIOException helperThrowsIOException = new MockUCCHelperThrowsIOException(null);
		JspCommonUploadView commonUploadPage = new JspCommonUploadView();
		Logger.enableLogger(Logger.ERROR_LOG);
	    try {
	        commonUploadPage.renderView(helperThrowsIOException);
	        fail("This should have thrown Exception");
	    } catch (ViewRenderingException e) {
	        assertEquals("Unable to Render View", e.getMessage());
	    }
		Logger.disableLogger(Logger.ERROR_LOG);
	    try {
	        commonUploadPage.renderView(helperThrowsIOException);
	        fail("This should have thrown Exception");
	    } catch (ViewRenderingException e) {
	        assertEquals("Unable to Render View", e.getMessage());
	    }
	}
}