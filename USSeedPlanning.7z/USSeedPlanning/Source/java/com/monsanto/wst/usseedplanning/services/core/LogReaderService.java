package com.monsanto.wst.usseedplanning.services.core;

import java.util.List;
import java.io.File;

/**
 * Created by IntelliJ IDEA.
 * Date: Apr 7, 2006
 * Time: 9:42:37 AM
 * <p/>
 * This interface defines the public interface for all log reader services.  It is used to retrieve log information from
 * the server.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public interface LogReaderService {

    /**
     * This method returns a list of log file names.
     *
     * @return List (of Strings) representing the log file names.
     */
    public List getLogFileList();

    /**
     * This method returns the log file with the specified name.
     *
     * @param fileName String represnting the name of the log file.
     * @return File - Object representing the log file.
     */
    public File getLogFile(String fileName);
    
}
