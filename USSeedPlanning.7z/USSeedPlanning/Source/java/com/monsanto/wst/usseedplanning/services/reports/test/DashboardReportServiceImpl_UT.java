/*
 DashboardReportServiceImpl_UT was created on Oct 12, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.usseedplanning.services.reports.test;

import com.monsanto.wst.commonutils.testutils.TestUtils;
import com.monsanto.wst.usseedplanning.constants.MainConstants;
import com.monsanto.wst.usseedplanning.dao.mock.MockDashboardReportDao;
import com.monsanto.wst.usseedplanning.services.reports.DashboardReportService;
import com.monsanto.wst.usseedplanning.services.reports.DashboardReportServiceImpl;
import junit.framework.TestCase;

import java.util.List;

/**
 * Filename:    $RCSfile: DashboardReportServiceImpl_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ffbrac $    	 On:	$Date: 2006-10-12 23:08:27 $
 *
 * @author ffbrac
 * @version $Revision: 1.1 $
 */
public class DashboardReportServiceImpl_UT extends TestCase {
	protected void setUp() throws Exception {
	  TestUtils testUtils = new TestUtils();
	  testUtils.setupLogging(MainConstants.APPLICATION_NAME);
	  super.setUp();
	}
	public void testCreate() throws Exception {
		DashboardReportService service = new DashboardReportServiceImpl((MockDashboardReportDao)null);
		assertNotNull(service);
	}
	public void testGetDashboardReport() throws Exception {
		DashboardReportService service = new DashboardReportServiceImpl(new MockDashboardReportDao());
		List reportList = service.getDashboardReport();
		assertEquals(2, reportList.size());
	}

}