package com.monsanto.wms.persistence.model;

import org.codehaus.jackson.annotate.JsonAutoDetect;
import org.codehaus.jackson.annotate.JsonProperty;
import org.hibernate.annotations.Type;

import javax.persistence.*;

import static javax.persistence.GenerationType.SEQUENCE;

/**
 * Created by IntelliJ IDEA.
 * User: MANIET
 * Date: 6/3/13
 * Time: 12:58 PM
 * To change this template use File | Settings | File Templates.
 */
@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE, getterVisibility = JsonAutoDetect.Visibility.NONE)
@Entity
@Table(name="WMS_AREAS")
public class Area extends BaseAuditEntity {

    private Long id;
    private String description;
    private Boolean active;

    private String activeDescription;

    public Area() {
    }

    public Area(Long id) {
        setId(id);
    }



    @SequenceGenerator(name="generator", sequenceName="WMS_AREAS_SEQ")@Id
    @GeneratedValue(strategy=SEQUENCE, generator="generator")
	@JsonProperty
    @Column(name="ID_AREA", nullable=false, precision=22, scale=0)
    public Long getId() {
        return this.id;
    }

    public void setId(Long id) {
        this.id = id;
    }
	@JsonProperty
    @Column(name="AREA_DESC", length=100)
    public String getDescription() {
        return this.description;
    }

    public void setDescription(String description) {
        this.description = description!=null ? description.toUpperCase() : description;
    }

     @JsonProperty
    @Column(name="ACTIVE")
    @Type(type = "yes_no")
    public Boolean getActive() {
        return active;
    }

    public void setActive(Boolean active) {
        if(active!=null && active) activeDescription = "Active";
        else activeDescription = "Not Active";

        this.active = active;
    }

    @Transient
    @JsonProperty
    public String getActiveDescription() {
        return activeDescription;
    }

    public void setActiveDescription(String activeDescription) {
        this.activeDescription = activeDescription;
    }

}
