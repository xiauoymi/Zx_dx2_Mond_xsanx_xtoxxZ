package com.monsanto.wms.persistence.model;

import org.codehaus.jackson.annotate.JsonAutoDetect;
import org.codehaus.jackson.annotate.JsonProperty;

import javax.persistence.*;

import java.util.Comparator;

import static javax.persistence.GenerationType.SEQUENCE;

/**
 * Created by IntelliJ IDEA.
 * User: MANIET
 * Date: 6/3/13
 * Time: 12:58 PM
 * To change this template use File | Settings | File Templates.
 */
@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE, getterVisibility = JsonAutoDetect.Visibility.NONE)
@Entity
@Table(name="WMS_STREW_RECOM_STG_DTL")
public class StrewRecommendationDetail extends BaseAuditEntity implements Comparator<StrewRecommendationDetail> {

    private Long id;
    private StrewRecommendation strewRecommendation;
    private CropStage cropStage;
    private Double cropStageValue;

    public StrewRecommendationDetail() {
    }

    public StrewRecommendationDetail(Long id) {
        setId(id);
    }

    public StrewRecommendationDetail(Long id, StrewRecommendation strewRecommendation, Long cropStageId, Double cropStageValue) {
        this.id = id;
        this.strewRecommendation = strewRecommendation;
        this.cropStage = new CropStage(cropStageId);
        this.cropStageValue = cropStageValue;
    }

     public StrewRecommendationDetail(StrewRecommendation strewRecommendation,CropStage cropStage, Double cropStageValue) {
        this.strewRecommendation = strewRecommendation;
        this.cropStage = cropStage;
        this.cropStageValue = cropStageValue;
    }

    public StrewRecommendationDetail(Long id, StrewRecommendation strewRecommendation, CropStage cropStage, Double cropStageValue) {
        this.id = id;
        this.strewRecommendation = strewRecommendation;
        this.cropStage = cropStage;
        this.cropStageValue = cropStageValue;
    }

    @SequenceGenerator(name="generator", sequenceName="WMS_STREW_RECOM_STG_DTL_SEQ")@Id
    @GeneratedValue(strategy=SEQUENCE, generator="generator")
	@JsonProperty
    @Column(name="ID_STREW_RECOM_STG_DTL", nullable=false, precision=22, scale=0)
    public Long getId() {
        return this.id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    @JsonProperty
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "ID_STREW_RECOMMENDATION")
    public StrewRecommendation getStrewRecommendation() {
        return strewRecommendation;
    }

    public void setStrewRecommendation(StrewRecommendation strewRecommendation) {
        this.strewRecommendation = strewRecommendation;
    }

    @JsonProperty
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "ID_CROP_STAGE")
    public CropStage getCropStage() {
        return cropStage;
    }

    public void setCropStage(CropStage cropStage) {
        this.cropStage = cropStage;
    }

    @JsonProperty
    @Column(name="CROP_STAGE_VALUE")
    public Double getCropStageValue() {
        return cropStageValue;
    }

    public void setCropStageValue(Double cropStageValue) {
        this.cropStageValue = cropStageValue;
    }

    @Transient
    @Override
    public int compare(StrewRecommendationDetail o1, StrewRecommendationDetail o2) {
        return o1.getCropStageValue().intValue() - o2.getCropStageValue().intValue();
    }
}
