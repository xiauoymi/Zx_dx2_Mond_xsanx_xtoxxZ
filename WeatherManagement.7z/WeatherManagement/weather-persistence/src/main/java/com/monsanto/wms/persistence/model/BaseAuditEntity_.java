package com.monsanto.wms.persistence.model;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;
import java.util.Date;

@Generated(value = "org.hibernate.jpamodelgen.JPAMetaModelEntityProcessor")
@StaticMetamodel(BaseAuditEntity.class)
public abstract class BaseAuditEntity_ {

	public static volatile SingularAttribute<BaseAuditEntity, String> rowUserId;
	public static volatile SingularAttribute<BaseAuditEntity, String> rowTaskId;
	public static volatile SingularAttribute<BaseAuditEntity, Date> rowModifyDate;
	public static volatile SingularAttribute<BaseAuditEntity, Date> rowEntryDate;

}

