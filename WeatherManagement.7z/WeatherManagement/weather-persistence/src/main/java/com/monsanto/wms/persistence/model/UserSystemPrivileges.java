package com.monsanto.wms.persistence.model;

import org.codehaus.jackson.annotate.JsonAutoDetect;
import org.codehaus.jackson.annotate.JsonProperty;

import javax.management.relation.Role;
import javax.persistence.*;

import static javax.persistence.GenerationType.SEQUENCE;

/**
 * Created by IntelliJ IDEA.
 * User: MANIET
 * Date: 6/3/13
 * Time: 12:58 PM
 * To change this template use File | Settings | File Templates.
 */
@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE, getterVisibility = JsonAutoDetect.Visibility.NONE)
@Entity
@Table(name="WMS_USER_SYSTEM_PRIVILEGES")
public class UserSystemPrivileges extends BaseAuditEntity {

    private Long id;
    private User user;
    private Roles role;


    public UserSystemPrivileges() {
    }

    public UserSystemPrivileges(Long id) {
        setId(id);
    }

    public UserSystemPrivileges(Long id,String userId,Long roleId,Long areaId) {
        this.id = id;
        setRole(new Roles(roleId,areaId));
        setUser(new User(userId));

    }



    @SequenceGenerator(name="generator", sequenceName="WMS_USER_SYSTEM_PRIVILEGES_SEQ")@Id
    @GeneratedValue(strategy=SEQUENCE, generator="generator")
	@JsonProperty
    @Column(name="ID_USER_SYSTEM_PRIVILEGES", nullable=false, precision=22, scale=0)
    public Long getId() {
        return this.id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    @JsonProperty
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "ID_USER")
    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    @JsonProperty
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "ID_ROLE")
    public Roles getRole() {
        return role;
    }

    public void setRole(Roles role) {
        this.role = role;
    }
}
