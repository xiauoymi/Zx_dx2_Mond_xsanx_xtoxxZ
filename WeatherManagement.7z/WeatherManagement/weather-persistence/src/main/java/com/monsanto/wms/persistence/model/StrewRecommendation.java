package com.monsanto.wms.persistence.model;

import org.codehaus.jackson.annotate.JsonAutoDetect;
import org.codehaus.jackson.annotate.JsonProperty;

import javax.persistence.*;

import java.util.*;

import static javax.persistence.GenerationType.SEQUENCE;

/**
 * Created by IntelliJ IDEA.
 * User: MANIET
 * Date: 6/3/13
 * Time: 12:58 PM
 * To change this template use File | Settings | File Templates.
 */
@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE, getterVisibility = JsonAutoDetect.Visibility.NONE)
@Entity
@Table(name="WMS_STREW_RECOMMENDATION")
public class StrewRecommendation extends BaseAuditEntity {

    private Long id;
    private ProductionZone productionZone;
    private ProductionCycles productionCycles;
    private Hybrid hybrid;
    private String sourceCode;

    private Set<StrewRecommendationDetail> detail;
    private  List<StrewRecommendationDetail> detailForJson;

    public StrewRecommendation() {
    }


    public StrewRecommendation(Long id) {
        setId(id);
    }

    public StrewRecommendation(Long id, ProductionZone productionZone, ProductionCycles productionCycles, Hybrid hybrid) {
        this.id = id;
        this.productionZone = productionZone;
        this.productionCycles = productionCycles;
        this.hybrid = hybrid;
    }

    public StrewRecommendation(Long id, Long productionZoneId, Long productionCycles, Long hybridId,String sourceCode) {
        this.id = id;
        this.productionZone = new ProductionZone(productionZoneId);
        this.productionCycles = new ProductionCycles(productionCycles);
        this.hybrid = new Hybrid(hybridId);
        this.sourceCode = sourceCode;
    }


    @SequenceGenerator(name="generator", sequenceName="WMS_STREW_RECOMMENDATION_SEQ")@Id
    @GeneratedValue(strategy=SEQUENCE, generator="generator")
	@JsonProperty
    @Column(name="ID_STREW_RECOMMENDATION", nullable=false, precision=22, scale=0)
    public Long getId() {
        return this.id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    @JsonProperty
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "ID_PRODUCTION_ZONE")
    public ProductionZone getProductionZone() {
        return productionZone;
    }

    public void setProductionZone(ProductionZone productionZone) {
        this.productionZone = productionZone;
    }


    @JsonProperty
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "ID_PROD_CYCLES")
    public ProductionCycles getProductionCycles() {
        return productionCycles;
    }

    public void setProductionCycles(ProductionCycles productionCycles) {
        this.productionCycles = productionCycles;
    }

    @JsonProperty
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "ID_HIBRID")
    public Hybrid getHybrid() {
        return hybrid;
    }

    public void setHybrid(Hybrid hybrid) {
        this.hybrid = hybrid;
    }

    @JsonProperty
    @Column(name = "SOURCE_CODE")
    public String getSourceCode() {
        return sourceCode;
    }

    public void setSourceCode(String sourceCode) {
        this.sourceCode = sourceCode;
    }




    @OneToMany(fetch = FetchType.EAGER, mappedBy="strewRecommendation")
    public Set<StrewRecommendationDetail> getDetail() {
        return detail;
    }

    public void setDetail(Set<StrewRecommendationDetail> detail) {
        this.detail = detail;
    }


    @Transient
    @JsonProperty
    public List<StrewRecommendationDetail> getDetailForJson() {
        List<StrewRecommendationDetail> ls = new ArrayList<StrewRecommendationDetail>();

        if(this.detail!=null && !this.detail.isEmpty()){
             ls = new ArrayList<StrewRecommendationDetail>();
             List<StrewRecommendationDetail> lsSet = new ArrayList<StrewRecommendationDetail>(detail);

            for(StrewRecommendationDetail currentItem : lsSet){
                ProductionZone productionZone = new ProductionZone(currentItem.getStrewRecommendation().getProductionZone());
                ProductionCycles productionCycle = new ProductionCycles(currentItem.getStrewRecommendation().getProductionCycles());


                StrewRecommendation strewRecommendation = new StrewRecommendation(currentItem.getStrewRecommendation().getId(),
                                                                                  productionZone,
                                                                                  productionCycle,
                                                                                  currentItem.getStrewRecommendation().getHybrid());

                StrewRecommendationDetail strewRecommendationDetail = new StrewRecommendationDetail(currentItem.getId(),
                                                                                                    strewRecommendation,
                                                                                                    new CropStage(currentItem.getCropStage().getId(),
                                                                                                                  currentItem.getCropStage().getDescription()),
                                                                                                    currentItem.getCropStageValue());

                strewRecommendationDetail.getCropStage().setCrop(new Crop(currentItem.getCropStage().getCrop().getId()));
                strewRecommendationDetail.getCropStage().getCrop().setType(new CropType(currentItem.getCropStage().getCrop().getType().getId()));

                ls.add(strewRecommendationDetail);
            }


        }

        Collections.sort(ls,new StrewRecommendationDetail());

        return ls;
    }

    public void setDetailForJson( List<StrewRecommendationDetail> detailForJson) {
        this.detailForJson = detailForJson;
    }
}
