package com.monsanto.wms.persistence.model;

import org.codehaus.jackson.annotate.JsonAutoDetect;
import org.codehaus.jackson.annotate.JsonProperty;

import javax.persistence.*;
import java.util.Date;

/**
 * Created by GFRAN1 on 9/2/2014.
 */
@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE, getterVisibility = JsonAutoDetect.Visibility.NONE)
@Entity
@Table(name="WMS_DATA_LOADER_LOG")


@SqlResultSetMappings({
        @SqlResultSetMapping(name = "errorMessage", columns = {
                @ColumnResult(name = "error_message")}
        )

})

@NamedNativeQueries({

        @NamedNativeQuery( name = "reloadData"
                , query = "{ ? = call WMS.WMS_DATA_LOADER_PKG.FULL_REFRESH_METHOD(?,?,?,?,?)}"
                ,resultSetMapping = "errorMessage"
                , hints = {
                @QueryHint(name = "org.hibernate.callable", value = "true")
                ,@QueryHint(name = "org.hibernate.readOnly", value = "true")
        }
        )
})
public class DataLoaderLog  extends BaseAuditEntity {

    private Long id;
    private MeteorologicalStation metStationId;
    private Date startDate;
    private Date endDate;
    private Long recordCount;
    private Long insertedCount;
    private Long updatedCount;
    private Long errorCount;

    public DataLoaderLog(Long id, MeteorologicalStation metStationId, Date startDate, Date endDate, Long recordCount, Long insertedCount, Long updatedCount, Long errorCount) {
        this.id = id;
        this.metStationId = metStationId;
        this.startDate = startDate;
        this.endDate = endDate;
        this.recordCount = recordCount;
        this.insertedCount = insertedCount;
        this.updatedCount = updatedCount;
        this.errorCount = errorCount;

    }

    public DataLoaderLog() {
    }



    @JsonProperty
    @Id
    @Column(name = "WMS_DATA_LOADER_LOG_ID")
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    @JsonProperty
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "METEORO_STATION_ID")
    public MeteorologicalStation getMetStationId() {
        return metStationId;
    }

    public void setMetStationId(MeteorologicalStation metStationId) {
        this.metStationId = metStationId;
    }


    @JsonProperty
    @Column(name = "START_DATE")
    public Date getStartDate() {
        return startDate;
    }

    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    @JsonProperty
    @Column(name = "END_DATE")
    public Date getEndDate() {
        return endDate;
    }

    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }

    @JsonProperty
    @Column(name = "RECORD_COUNT")
    public Long getRecordCount() {
        return recordCount;
    }

    public void setRecordCount(Long recordCount) {
        this.recordCount = recordCount;
    }

    @JsonProperty
    @Column(name = "INSERTED_COUNT")
    public Long getInsertedCount() {
        return insertedCount;
    }

    public void setInsertedCount(Long insertedCount) {
        this.insertedCount = insertedCount;
    }

    @JsonProperty
    @Column(name = "UPDATED_COUNT")
    public Long getUpdatedCount() {
        return updatedCount;
    }

    public void setUpdatedCount(Long updatedCount) {
        this.updatedCount = updatedCount;
    }

    @JsonProperty
    @Column(name = "ERROR_COUNT")
    public Long getErrorCount() {
        return errorCount;
    }

    public void setErrorCount(Long errorCount) {
        this.errorCount = errorCount;
    }


}