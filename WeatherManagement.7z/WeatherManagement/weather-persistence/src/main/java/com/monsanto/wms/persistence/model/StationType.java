package com.monsanto.wms.persistence.model;

import org.codehaus.jackson.annotate.JsonAutoDetect;
import org.codehaus.jackson.annotate.JsonProperty;

import javax.persistence.*;

import static javax.persistence.GenerationType.SEQUENCE;

/**
 * Created by IntelliJ IDEA.
 * User: MANIET
 * Date: 6/3/13
 * Time: 12:58 PM
 * To change this template use File | Settings | File Templates.
 */
@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE, getterVisibility = JsonAutoDetect.Visibility.NONE)
@Entity
@Table(name="WMS_METEORO_STATION_TYPE")
public class StationType extends BaseAuditEntity {

    private Long id;
    private String description;


    public StationType() {
    }

    public StationType(Long id) {
        setId(id);
    }

    public StationType(String description) {
        this.description = description;
    }

    public StationType(Long id, String description, Boolean active) {
        this.id = id;
        setDescription(description);
    }



    @SequenceGenerator(name="generator", sequenceName="WMS_METEORO_STATION_TYPE_SEQ")@Id
    @GeneratedValue(strategy=SEQUENCE, generator="generator")
	@JsonProperty
    @Column(name="METEORO_STATION_TYPE_ID", nullable=false, precision=22, scale=0)
    public Long getId() {
        return this.id;
    }

    public void setId(Long id) {
        this.id = id;
    }
	@JsonProperty
    @Column(name="DESCRIPTION", length=100)
    public String getDescription() {
        return this.description;
    }

    public void setDescription(String description) {
        this.description = description!=null ? description.toUpperCase() : description;
    }

}
