package com.monsanto.wms.persistence.model;

import org.codehaus.jackson.annotate.JsonAutoDetect;
import org.codehaus.jackson.annotate.JsonProperty;

import javax.persistence.*;

import static javax.persistence.GenerationType.SEQUENCE;

/**
 * Created by IntelliJ IDEA.
 * User: MANIET
 * Date: 6/3/13
 * Time: 12:58 PM
 * To change this template use File | Settings | File Templates.
 */
@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE, getterVisibility = JsonAutoDetect.Visibility.NONE)
@Entity
@Table(name="WMS_HISTORIC_MST_DATA")

@SqlResultSetMappings({
    @SqlResultSetMapping(name = "generalCalculationByGDUMapping", columns = {
                         @ColumnResult(name = "TEMP_MAX"),
                         @ColumnResult(name = "TEMP_MIN"),
                         @ColumnResult(name = "CURR_DAY"),
                         @ColumnResult(name = "CURR_MONTH"),
                         @ColumnResult(name = "GDU"),
                         @ColumnResult(name = "ERROR_DESC")}
                        ),

     @SqlResultSetMapping(name = "generalCalculationByDayMapping", columns = {
                         @ColumnResult(name = "TEMP_MAX"),
                         @ColumnResult(name = "TEMP_MIN"),
                         @ColumnResult(name = "CURR_DAY"),
                         @ColumnResult(name = "CURR_MONTH"),
                         @ColumnResult(name = "GDU"),
                         @ColumnResult(name = "ERROR_DESC")
                         }),

    @SqlResultSetMapping(name = "weeklyCalculationMapping", columns = {
                         @ColumnResult(name = "ID_WEEK"),
                         @ColumnResult(name = "TEMP_MAX"),
                         @ColumnResult(name = "TEMP_MIN"),
                         @ColumnResult(name = "N_WEEK"),
                         @ColumnResult(name = "N_MONTH"),
                         @ColumnResult(name = "ERROR_DESC")}),

    @SqlResultSetMapping(name = "underZeroCalculationMapping", columns = {
                         @ColumnResult(name = "TEMP_MIN"),
                         @ColumnResult(name = "TEMP_DATE"),
                         @ColumnResult(name = "ERROR_DESC")}),

     @SqlResultSetMapping(name = "periodToGDUMapping", columns = {
                         @ColumnResult(name = "N_GDU"),
                         @ColumnResult(name = "ERROR_DESC")}),

     @SqlResultSetMapping(name = "realReportMapping", columns = {
                         @ColumnResult(name = "CURR_YEAR"),
                         @ColumnResult(name = "CURR_MONTH"),
                         @ColumnResult(name = "CURR_DAY"),
                         @ColumnResult(name = "TEMP_MAX"),
                         @ColumnResult(name = "TEMP_MIN"),
                         @ColumnResult(name = "GDU_DAY"),
                         @ColumnResult(name = "GDU_ACUM"),
                         @ColumnResult(name = "VALUE_STS"),
                         @ColumnResult(name = "ERROR_DESC")}),

     @SqlResultSetMapping(name = "generalReportMapping", columns = {
                     @ColumnResult(name = "N_DATE"),
                     @ColumnResult(name = "TEMP_MIN"),
                     @ColumnResult(name = "TEMP_MAX"),
                     @ColumnResult(name = "GDU"),
                     @ColumnResult(name = "GDU_ACUM"),
                     @ColumnResult(name = "HUMIDITYMIN"),
                     @ColumnResult(name = "HUMIDITYMAX"),
                     @ColumnResult(name = "RAINDAYMAX"),
                     @ColumnResult(name = "WINDMIN"),
                     @ColumnResult(name = "WINDMAX"),
                     @ColumnResult(name = "RADIATION"),
                     @ColumnResult(name = "PROM_TMIN"),
                     @ColumnResult(name = "PROM_TMAX"),
                     @ColumnResult(name = "WIND_7_7"),
                     @ColumnResult(name = "ETRANSPIRATION"),
                     @ColumnResult(name = "LONGITUD"),
                     @ColumnResult(name = "LATITUD")}),

        @SqlResultSetMapping(name = "dataGapsMapping", columns = {
                @ColumnResult(name = "ERROR_MESSAGE")
        }),
        @SqlResultSetMapping(name = "dataProfileMapping", columns = {
                @ColumnResult(name = "METEORO_MEASURE_CNT"),
                @ColumnResult(name = "EXTRAPOLATED_MEASURE_CNT")
        })


})

@NamedNativeQueries({

        @NamedNativeQuery( name = "getGeneralCalculationByGDU"
                                       , query = "{ ? = call WMS.WMS_FUNCTIONS_PKG.WMS_CALC_GDU_FN(?,?,?,?,?,?,?,?,?)}"     //startPeriod(YYYY),endPeriod(YYYY),day(int),month(int),idMetStation(long),searchValue(Double),tempMin(Double),tempMax(Double),crop name
                                       , resultSetMapping = "generalCalculationByGDUMapping"
                                       , hints = {
                                                    @QueryHint(name = "org.hibernate.callable", value = "true")
                                                   ,@QueryHint(name = "org.hibernate.readOnly", value = "true")
                                       }
                         ),
        @NamedNativeQuery( name = "getGeneralCalculationByDay"
                                       , query = "{ ? = call WMS.WMS_FUNCTIONS_PKG.WMS_CALC_DAYS_FN(?,?,?,?,?,?,?,?,?)}"     //startPeriod(YYYY),endPeriod(YYYY),day(int),month(int),idMetStation(long),searchValue(Integer),crop name
                                       , resultSetMapping = "generalCalculationByDayMapping"
                                       , hints = {
                                                    @QueryHint(name = "org.hibernate.callable", value = "true")
                                                   ,@QueryHint(name = "org.hibernate.readOnly", value = "true")
                                       }
                         ),
        @NamedNativeQuery( name = "getWeeklyCalculationByGDU"
                                       , query = "{ ? = call WMS.WMS_FUNCTIONS_PKG.WMS_CALC_WEEKS_GDU_FN(?,?,?,?,?,?,?,?)}"      //start Period(YYYY),end period(YYYY),start point (MM),idMetStation(long),desired GDUs,tempMin(Double),tempMax(Double),crop name
                                       , resultSetMapping = "weeklyCalculationMapping"
                                       , hints = {
                                                    @QueryHint(name = "org.hibernate.callable", value = "true")
                                                   ,@QueryHint(name = "org.hibernate.readOnly", value = "true")
                                       }
                         ),
        @NamedNativeQuery( name = "getWeeklyCalculationByDay"
                                       , query = "{ ? = call WMS.WMS_FUNCTIONS_PKG.WMS_CALC_WEEKS_DAY_FN(?,?,?,?,?,?)}"            //start Period(YYYY),end period(YYYY),start point (MM),idMetStation(long),searchValue (Integer),cropName
                                       , resultSetMapping = "weeklyCalculationMapping"
                                       , hints = {
                                                    @QueryHint(name = "org.hibernate.callable", value = "true")
                                                   ,@QueryHint(name = "org.hibernate.readOnly", value = "true")
                                       }
                         ),
        @NamedNativeQuery( name = "getUnderZeroCalculation"
                                       , query = "{ ? = call WMS.WMS_FUNCTIONS_PKG.WMS_TEMP_UNDER_ZERO(?,?,?)}"            //year,Month,idMetStation,
                                       , resultSetMapping = "underZeroCalculationMapping"
                                       , hints = {
                                                    @QueryHint(name = "org.hibernate.callable", value = "true")
                                                   ,@QueryHint(name = "org.hibernate.readOnly", value = "true")
                                       }
                         ),
        @NamedNativeQuery( name = "getPeriodToGDU"
                                       , query = "{ ? = call WMS.WMS_FUNCTIONS_PKG.WMS_SUMGDU_FN(?,?,?,?,?,?,?,?,?,?)}"            //start Period(YYYY),end period(YYYY),month init (MM),month end(MM),dayIni(DD),dayEnd(DD),idMetStation(long),tempMin(D),tempMax(D),cropName
                                       , resultSetMapping = "periodToGDUMapping"
                                       , hints = {
                                                    @QueryHint(name = "org.hibernate.callable", value = "true")
                                                   ,@QueryHint(name = "org.hibernate.readOnly", value = "true")
                                       }
                         ),

        @NamedNativeQuery( name = "getRealReport"
                                       , query = "{ ? = call WMS.WMS_FUNCTIONS_PKG.WMS_ACUM_GDU_FN(?,?,?,?,?,?,?,?,?)}"            //start Period(YYYY),end period(YYYY),month init (MM),month end(MM),idMetStation(long),tempMin(D),tempMax(D),CropStage-Value Chain,cropName
                                       , resultSetMapping = "realReportMapping"
                                       , hints = {
                                                    @QueryHint(name = "org.hibernate.callable", value = "true")
                                                   ,@QueryHint(name = "org.hibernate.readOnly", value = "true")
                                       }
                         ),
         @NamedNativeQuery( name = "getGeneralReport"
                                       , query = "{ ? = call WMS.WMS_FUNCTIONS_PKG.WMS_RPT_TEMP_FN (?,?,?,?,?,?,?,?,?,?,?,?)}"            //Ini Year(YYYY),ini day(DD),ini month(MM),End Year(YYYY),End day(DD),End month(MM),MetStationId,Temp MIN CROP,Temp MAX CROP,CROP NAME,UNDER TEMP C,ABOVE TEMP C
                                       , resultSetMapping = "generalReportMapping"
                                       , hints = {
                                                    @QueryHint(name = "org.hibernate.callable", value = "true")
                                                   ,@QueryHint(name = "org.hibernate.readOnly", value = "true")
                                       }
                         ),
        @NamedNativeQuery( name = "fillDataGaps"
                , query = "{ ? = call WMS.WMS_FUNCTIONS_PKG.WMS_FILL_DATA_GAPS_FN (?,?,?,?)}"
                , resultSetMapping = "dataGapsMapping"
                , hints = {
                @QueryHint(name = "org.hibernate.callable", value = "true")
                ,@QueryHint(name = "org.hibernate.readOnly", value = "true")
        }

        ),
        @NamedNativeQuery( name = "getExtrapolatedDataProfile"
                , query = "{ ? = call WMS.WMS_FUNCTIONS_PKG.WMS_DATA_PROFILE_FN (?,?,?)}"
                , resultSetMapping = "dataProfileMapping"
                , hints = {
                @QueryHint(name = "org.hibernate.callable", value = "true")
                ,@QueryHint(name = "org.hibernate.readOnly", value = "true")
        }

        )


})
public class MeteorologicalStationHistoric extends BaseAuditEntity {

    private Long id;
    private MeteorologicalStation meteorologicalStation;
    private Integer dayOfTheMonth;
    private Integer month;
    private Integer year;
    private String timeRegistry;

    private Double tempMin;
    private String tempMinTime;

    private Double tempMax;
    private String tempMaxTime;

    private Double pressureMax;
    private String pressureMaxTime;

    private Double pressureMin;
    private String pressureMinTime;

    private Double rain;
    private Double radiation;
    private String radiationTime;

    private Double wind;
    private String windTime;

    private Double dewPointMax;
    private String dewPointMaxTime;
    private Double dewPointMin;
    private String dewPointMinTime;

    private Double eTranspirationDay;
    private Double eTranspirationMonth;
    private Double eTranspirationYear;

    private Double heatIndexDayMax;
    private String heatIndexDayMaxTime;

    private Double rainDayMax;
    private Double rainStorm;

    private Double relativeHumidityDayMax;
    private String relativeHumidityDayMaxTime;

    private Double relativeHumidityDayMin;
    private String relativeHumidityDayMinTime;

    private String sunrise;
    private String sunset;

    private Double uvIndex;

    private String longitude;
    private String latitude;


    public MeteorologicalStationHistoric() {
    }

    public MeteorologicalStationHistoric(MeteorologicalStation meteorologicalStation) {
        this.meteorologicalStation = meteorologicalStation;
    }

    public MeteorologicalStationHistoric(Long id) {
        setId(id);
    }

    public MeteorologicalStationHistoric(MeteorologicalStation meteorologicalStation, Integer dayOfTheMonth, Integer month, Integer year, String timeRegistry,
                                         Double tempMin, String tempMinTime, Double tempMax, String tempMaxTime, Double pressureMax, String pressureMaxTime,
                                         Double pressureMin, String pressureMinTime, Double rain, Double radiation, String radiationTime, Double wind, String windTime,
                                         Double dewPointMax, String dewPointMaxTime, Double dewPointMin, String dewPointMinTime, Double eTranspirationDay,
                                         Double eTranspirationMonth, Double eTranspirationYear, Double heatIndexDayMax, String heatIndexDayMaxTime,
                                         Double rainDayMax, Double rainStorm, Double relativeHumidityDayMax, String relativeHumidityDayMaxTime,
                                         Double relativeHumidityDayMin, String relativeHumidityDayMinTime, String sunrise, String sunset, Double uvIndex,
                                         String longitude, String latitude) {
        this.meteorologicalStation = meteorologicalStation;
        this.dayOfTheMonth = dayOfTheMonth;
        this.month = month;
        this.year = year;
        this.timeRegistry = timeRegistry;
        this.tempMin = tempMin;
        this.tempMinTime = tempMinTime;
        this.tempMax = tempMax;
        this.tempMaxTime = tempMaxTime;
        this.pressureMax = pressureMax;
        this.pressureMaxTime = pressureMaxTime;
        this.pressureMin = pressureMin;
        this.pressureMinTime = pressureMinTime;
        this.rain = rain;
        this.radiation = radiation;
        this.radiationTime = radiationTime;
        this.wind = wind;
        this.windTime = windTime;
        this.dewPointMax = dewPointMax;
        this.dewPointMaxTime = dewPointMaxTime;
        this.dewPointMin = dewPointMin;
        this.dewPointMinTime = dewPointMinTime;
        this.eTranspirationDay = eTranspirationDay;
        this.eTranspirationMonth = eTranspirationMonth;
        this.eTranspirationYear = eTranspirationYear;
        this.heatIndexDayMax = heatIndexDayMax;
        this.heatIndexDayMaxTime = heatIndexDayMaxTime;
        this.rainDayMax = rainDayMax;
        this.rainStorm = rainStorm;
        this.relativeHumidityDayMax = relativeHumidityDayMax;
        this.relativeHumidityDayMaxTime = relativeHumidityDayMaxTime;
        this.relativeHumidityDayMin = relativeHumidityDayMin;
        this.relativeHumidityDayMinTime = relativeHumidityDayMinTime;
        this.sunrise = sunrise;
        this.sunset = sunset;
        this.uvIndex = uvIndex;
        this.longitude = longitude;
        this.latitude = latitude;
    }

    public MeteorologicalStationHistoric( Long meteorologicalStationId, Double tempMin, Double tempMax, Integer dayOfTheMonth, Integer month, Integer year, String timeRegistry) {
        this.meteorologicalStation = new MeteorologicalStation(meteorologicalStationId);
        this.tempMin = tempMin;
        this.tempMax = tempMax;
        this.dayOfTheMonth = dayOfTheMonth;
        this.month = month;
        this.year = year;
        this.timeRegistry = timeRegistry;
    }

    @SequenceGenerator(name="generator", sequenceName="WMS_HISTORIC_MST_DATA_SEQ")@Id
    @GeneratedValue(strategy=SEQUENCE, generator="generator")
	@JsonProperty
    @Column(name="ID_HISTORIC_MST_DATA", nullable=false, precision=22, scale=0)
    public Long getId() {
        return this.id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    @JsonProperty
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "ID_METEORO_STATIONS")
    public MeteorologicalStation getMeteorologicalStation() {
        return meteorologicalStation;
    }

    public void setMeteorologicalStation(MeteorologicalStation meteorologicalStation) {
        this.meteorologicalStation = meteorologicalStation;
    }

    @JsonProperty
    @Column(name="TEMP_MIN")
    public Double getTempMin() {
        return tempMin;
    }

    public void setTempMin(Double tempMin) {
        this.tempMin = tempMin;
    }

    @JsonProperty
    @Column(name="TEMP_MAX")
    public Double getTempMax() {
        return tempMax;
    }

    public void setTempMax(Double tempMax) {
        this.tempMax = tempMax;
    }

    @JsonProperty
    @Column(name="N_DAY")
    public Integer getDayOfTheMonth() {
        return dayOfTheMonth;
    }

    public void setDayOfTheMonth(Integer dayOfTheMonth) {
        this.dayOfTheMonth = dayOfTheMonth;
    }

    @JsonProperty
    @Column(name="N_MONTH")
    public Integer getMonth() {
        return month;
    }

    public void setMonth(Integer month) {
        this.month = month;
    }

    @JsonProperty
    @Column(name="N_YEAR")
    public Integer getYear() {
        return year;
    }

    public void setYear(Integer year) {
        this.year = year;
    }

    @JsonProperty
    @Column(name="TIME_REGISTRY")
    public String getTimeRegistry() {
        return timeRegistry;
    }

    public void setTimeRegistry(String timeRegistry) {
        this.timeRegistry = timeRegistry;
    }


    @JsonProperty
    @Column(name="RADIATION")
    public Double getRadiation() {
        return radiation;
    }

    public void setRadiation(Double radiation) {
        this.radiation = radiation;
    }


    @JsonProperty
    @Column(name="TEMPMINTIME")
    public String getTempMinTime() {
        return tempMinTime;
    }

    public void setTempMinTime(String tempMinTime) {
        this.tempMinTime = tempMinTime;
    }

    @JsonProperty
    @Column(name="TEMPMAXTIME")
    public String getTempMaxTime() {
        return tempMaxTime;
    }

    public void setTempMaxTime(String tempMaxTime) {
        this.tempMaxTime = tempMaxTime;
    }

    @JsonProperty
    @Column(name="PRESSUREMAX")
    public Double getPressureMax() {
        return pressureMax;
    }

    public void setPressureMax(Double pressureMax) {
        this.pressureMax = pressureMax;
    }

    @JsonProperty
    @Column(name="PRESSUREMAXTIME")
    public String getPressureMaxTime() {
        return pressureMaxTime;
    }

    public void setPressureMaxTime(String pressureMaxTime) {
        this.pressureMaxTime = pressureMaxTime;
    }

    @JsonProperty
    @Column(name="PRESSUREMIN")
    public Double getPressureMin() {
        return pressureMin;
    }

    public void setPressureMin(Double pressureMin) {
        this.pressureMin = pressureMin;
    }

    @JsonProperty
    @Column(name="PRESSUREMINTIME")
    public String getPressureMinTime() {
        return pressureMinTime;
    }

    public void setPressureMinTime(String pressureMinTime) {
        this.pressureMinTime = pressureMinTime;
    }

    @JsonProperty
    @Column(name="RAIN")
    public Double getRain() {
        return rain;
    }

    public void setRain(Double rain) {
        this.rain = rain;
    }

    @JsonProperty
    @Column(name="RADIATIONTIME")
    public String getRadiationTime() {
        return radiationTime;
    }

    public void setRadiationTime(String radiationTime) {
        this.radiationTime = radiationTime;
    }

    @JsonProperty
    @Column(name="WIND")
    public Double getWind() {
        return wind;
    }

    public void setWind(Double wind) {
        this.wind = wind;
    }

    @JsonProperty
    @Column(name="WINDTIME")
    public String getWindTime() {
        return windTime;
    }

    public void setWindTime(String windTime) {
        this.windTime = windTime;
    }

    @JsonProperty
    @Column(name="DEWPOINTMAX")
    public Double getDewPointMax() {
        return dewPointMax;
    }

    public void setDewPointMax(Double dewPointMax) {
        this.dewPointMax = dewPointMax;
    }

    @JsonProperty
    @Column(name="DEWPOINTMAXTIME")
    public String getDewPointMaxTime() {
        return dewPointMaxTime;
    }

    public void setDewPointMaxTime(String dewPointMaxTime) {
        this.dewPointMaxTime = dewPointMaxTime;
    }

    @JsonProperty
    @Column(name="DEWPOINTMIN")
    public Double getDewPointMin() {
        return dewPointMin;
    }

    public void setDewPointMin(Double dewPointMin) {
        this.dewPointMin = dewPointMin;
    }

    @JsonProperty
    @Column(name="DEWPOINTMINTIME")
    public String getDewPointMinTime() {
        return dewPointMinTime;
    }

    public void setDewPointMinTime(String dewPointMinTime) {
        this.dewPointMinTime = dewPointMinTime;
    }

    @JsonProperty
    @Column(name="ETRANSPIRATIONDAY")
    public Double geteTranspirationDay() {
        return eTranspirationDay;
    }

    public void seteTranspirationDay(Double eTranspirationDay) {
        this.eTranspirationDay = eTranspirationDay;
    }

    @JsonProperty
    @Column(name="ETRANSPIRATIONMONTH")
    public Double geteTranspirationMonth() {
        return eTranspirationMonth;
    }

    public void seteTranspirationMonth(Double eTranspirationMonth) {
        this.eTranspirationMonth = eTranspirationMonth;
    }

    @JsonProperty
    @Column(name="ETRANSPIRATIONYEAR")
    public Double geteTranspirationYear() {
        return eTranspirationYear;
    }

    public void seteTranspirationYear(Double eTranspirationYear) {
        this.eTranspirationYear = eTranspirationYear;
    }

    @JsonProperty
    @Column(name="HEATINDEXDAYMAX")
    public Double getHeatIndexDayMax() {
        return heatIndexDayMax;
    }

    public void setHeatIndexDayMax(Double heatIndexDayMax) {
        this.heatIndexDayMax = heatIndexDayMax;
    }

    @JsonProperty
    @Column(name="HEATINDEXDAYMAXTIME")
    public String getHeatIndexDayMaxTime() {
        return heatIndexDayMaxTime;
    }

    public void setHeatIndexDayMaxTime(String heatIndexDayMaxTime) {
        this.heatIndexDayMaxTime = heatIndexDayMaxTime;
    }

    @JsonProperty
    @Column(name="RAINDAYMAX")
    public Double getRainDayMax() {
        return rainDayMax;
    }

    public void setRainDayMax(Double rainDayMax) {
        this.rainDayMax = rainDayMax;
    }

    @JsonProperty
    @Column(name="RAINSTORM")
    public Double getRainStorm() {
        return rainStorm;
    }

    public void setRainStorm(Double rainStorm) {
        this.rainStorm = rainStorm;
    }

    @JsonProperty
    @Column(name="RELATIVEHUMIDITYDAYMAX")
    public Double getRelativeHumidityDayMax() {
        return relativeHumidityDayMax;
    }

    public void setRelativeHumidityDayMax(Double relativeHumidityDayMax) {
        this.relativeHumidityDayMax = relativeHumidityDayMax;
    }

    @JsonProperty
    @Column(name="RELATIVEHUMIDITYDAYMAXTIME")
    public String getRelativeHumidityDayMaxTime() {
        return relativeHumidityDayMaxTime;
    }

    public void setRelativeHumidityDayMaxTime(String relativeHumidityDayMaxTime) {
        this.relativeHumidityDayMaxTime = relativeHumidityDayMaxTime;
    }

    @JsonProperty
    @Column(name="RELATIVEHUMIDITYDAYMIN")
    public Double getRelativeHumidityDayMin() {
        return relativeHumidityDayMin;
    }

    public void setRelativeHumidityDayMin(Double relativeHumidityDayMin) {
        this.relativeHumidityDayMin = relativeHumidityDayMin;
    }

    @JsonProperty
    @Column(name="RELATIVEHUMIDITYDAYMINTIME")
    public String getRelativeHumidityDayMinTime() {
        return relativeHumidityDayMinTime;
    }

    public void setRelativeHumidityDayMinTime(String relativeHumidityDayMinTime) {
        this.relativeHumidityDayMinTime = relativeHumidityDayMinTime;
    }

    @JsonProperty
    @Column(name="SUNRISE")
    public String getSunrise() {
        return sunrise;
    }

    public void setSunrise(String sunrise) {
        this.sunrise = sunrise;
    }

    @JsonProperty
    @Column(name="SUNSET")
    public String getSunset() {
        return sunset;
    }

    public void setSunset(String sunset) {
        this.sunset = sunset;
    }

    @JsonProperty
    @Column(name="UVINDEXMAX")
    public Double getUvIndex() {
        return uvIndex;
    }

    public void setUvIndex(Double uvIndex) {
        this.uvIndex = uvIndex;
    }


    @JsonProperty
    @Column(name="LONGITUDE")
    public String getLongitude() {
        return longitude;
    }

    public void setLongitude(String longitude) {
        this.longitude = longitude;
    }

     @JsonProperty
    @Column(name="LATITUDE")
    public String getLatitude() {
        return latitude;
    }

    public void setLatitude(String latitude) {
        this.latitude = latitude;
    }
}
