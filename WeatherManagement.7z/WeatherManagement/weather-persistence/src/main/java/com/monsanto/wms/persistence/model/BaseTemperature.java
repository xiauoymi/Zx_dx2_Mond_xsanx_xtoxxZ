package com.monsanto.wms.persistence.model;

import org.codehaus.jackson.annotate.JsonAutoDetect;
import org.codehaus.jackson.annotate.JsonProperty;
import org.hibernate.annotations.Type;

import javax.persistence.*;

import static javax.persistence.GenerationType.SEQUENCE;

/**
 * Created by IntelliJ IDEA.
 * User: MANIET
 * Date: 6/3/13
 * Time: 12:58 PM
 * To change this template use File | Settings | File Templates.
 */
@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE, getterVisibility = JsonAutoDetect.Visibility.NONE)
@Entity
@Table(name="WMS_BASE_TEMPERATURE")
public class BaseTemperature extends BaseAuditEntity {

    private Long id;
    private Crop crop;
    private String tempmin;
    private String tempmax;
    private Boolean active;

    private String activeDescription;


    public BaseTemperature() {
    }

    public BaseTemperature(Long id) {
        setId(id);
    }

    public BaseTemperature(Long id, Long cropId, String tempmin, String tempmax, Boolean active) {
        this.id = id;
        this.crop = new Crop(cropId);
        this.tempmin = tempmin;
        this.tempmax = tempmax;
        this.active = active;
    }

    @SequenceGenerator(name="generator", sequenceName="WMS_BASE_TEMPERATURE_SEQ")@Id
    @GeneratedValue(strategy=SEQUENCE, generator="generator")
	@JsonProperty
    @Column(name="ID_BASE_TEMP", nullable=false, precision=22, scale=0)
    public Long getId() {
        return this.id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    @JsonProperty
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "ID_CROP")
    public Crop getCrop() {
        return crop;
    }

    public void setCrop(Crop crop) {
        this.crop = crop;
    }

    @JsonProperty
    @Column(name="TEMP_MIN")
    public String getTempmin() {
        return tempmin;
    }

    public void setTempmin(String tempmin) {
        this.tempmin = tempmin;
    }

    @JsonProperty
    @Column(name="TEMP_MAX")
    public String getTempmax() {
        return tempmax;
    }

    public void setTempmax(String tempmax) {
        this.tempmax = tempmax;
    }

    @JsonProperty
    @Column(name="ACTIVE")
    @Type(type = "yes_no")
    public Boolean getActive() {
        return active;
    }

    public void setActive(Boolean active) {
        if(active!=null && active) activeDescription = "Active";
        else activeDescription = "Not Active";

        this.active = active;
    }

    @Transient
    @JsonProperty
    public String getActiveDescription() {
        return activeDescription;
    }

    public void setActiveDescription(String activeDescription) {
        this.activeDescription = activeDescription;
    }
}
