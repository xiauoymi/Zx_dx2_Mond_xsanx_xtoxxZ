package com.monsanto.wms.persistence.model;

import org.codehaus.jackson.annotate.JsonAutoDetect;
import org.codehaus.jackson.annotate.JsonProperty;
import org.hibernate.annotations.Type;

import javax.persistence.*;

import static javax.persistence.GenerationType.SEQUENCE;

/**
 * Created by IntelliJ IDEA.
 * User: MANIET
 * Date: 6/3/13
 * Time: 12:58 PM
 * To change this template use File | Settings | File Templates.
 */
@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE, getterVisibility = JsonAutoDetect.Visibility.NONE)
@Entity
@Table(name="WMS_SCHEDULE_ERROR_LOG")
public class ScheduleErrorLog extends BaseAuditEntity {

    private Long id;
    private String error;
    private MeteorologicalStation station;

    public ScheduleErrorLog(String error, MeteorologicalStation station) {
        this.error = error;
        this.station = station;
    }

    @SequenceGenerator(name="generator", sequenceName="WMS_SCHEDULE_ERROR_LOG_SEQ")@Id
    @GeneratedValue(strategy=SEQUENCE, generator="generator")
	@JsonProperty
    @Column(name="ID_SCHEDULE_ERROR_LOG", nullable=false, precision=22, scale=0)
    public Long getId() {
        return this.id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    @Column(name="ERROR_DESC")
    public String getError() {
        return error;
    }

    public void setError(String error) {
        this.error = error;
    }

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "ID_METEORO_STATIONS")
    public MeteorologicalStation getStation() {
        return station;
    }

    public void setStation(MeteorologicalStation station) {
        this.station = station;
    }
}
