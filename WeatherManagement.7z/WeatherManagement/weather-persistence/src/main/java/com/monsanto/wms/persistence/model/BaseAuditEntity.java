package com.monsanto.wms.persistence.model;

import org.codehaus.jackson.annotate.JsonProperty;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

/**
 * Created by IntelliJ IDEA.
 * User: MANIET
 * Date: 16/08/12
 * Time: 08:38 AM
 * To change this template use File | Settings | File Templates.
 */
@MappedSuperclass
public abstract class BaseAuditEntity implements Serializable {

    private Date rowEntryDate;
    private Date rowModifyDate;
    private String rowUserId;
    private String rowTaskId;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "ROW_ENTRY_DATE", nullable = false, length = 7, updatable = false)
    public Date getRowEntryDate() {
        return this.rowEntryDate;
    }

    public void setRowEntryDate(Date rowEntryDate) {
        this.rowEntryDate = rowEntryDate;
    }

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "ROW_MODIFY_DATE", nullable = false, length = 7)
    public Date getRowModifyDate() {
        return this.rowModifyDate;
    }

    public void setRowModifyDate(Date rowModifyDate) {
        this.rowModifyDate = rowModifyDate;
    }

    @JsonProperty
    @Column(name = "ROW_USER_ID", nullable = false, length = 15)
    public String getRowUserId() {
        return this.rowUserId;
    }

    public void setRowUserId(String rowUserId) {
        this.rowUserId = rowUserId;
    }

    @Column(name = "ROW_TASK_ID", nullable = false, length = 15)
    public String getRowTaskId() {
        return rowTaskId;
    }

    public void setRowTaskId(String rowTaskId) {
        this.rowTaskId = rowTaskId;
    }

    @PrePersist
    public void beforeInsert() {
        Date date = new Date();

        rowEntryDate = date;
        rowModifyDate = date;
        //rowUserId = "HARD CODE";
    }

    @PreUpdate
    public void beforeUpdate() {
        rowModifyDate = new Date();
        //rowUserId = "HARD CODE";
    }

}
