package com.monsanto.wms.persistence.model;

import org.codehaus.jackson.annotate.JsonAutoDetect;
import org.codehaus.jackson.annotate.JsonProperty;
import org.hibernate.annotations.Type;

import javax.persistence.*;

import static javax.persistence.GenerationType.SEQUENCE;

/**
 * Created by IntelliJ IDEA.
 * User: MANIET
 * Date: 6/3/13
 * Time: 12:58 PM
 * To change this template use File | Settings | File Templates.
 */
@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE, getterVisibility = JsonAutoDetect.Visibility.NONE)
@Entity
@Table(name="WMS_CROP_STAGES")
public class CropStage extends BaseAuditEntity {

    private Long id;
    private String description;
    private Boolean active;
    private Boolean defaultValue;
    private Crop crop;

    private String activeDescription;
    private String defaultValueDescription;


    public CropStage() {
    }

    public CropStage(Long id) {
        setId(id);
    }

    public CropStage(Long id, String description) {
        this.id = id;
        this.description = description;
    }

    public CropStage(String description) {
        this.description = description;
        this.active = true;
    }

    public CropStage(Long id, String description, Long cropId, Boolean active,Boolean defaultValue) {
        this.id = id;
        setDescription(description);
        setCrop(new Crop(cropId));
        this.active = active != null ? active : false;
        this.defaultValue = defaultValue != null ? defaultValue : false;
     }



    @SequenceGenerator(name="generator", sequenceName="WMS_CROP_STAGES_SEQ")@Id
    @GeneratedValue(strategy=SEQUENCE, generator="generator")
	@JsonProperty
    @Column(name="ID_CROP_STAGE", nullable=false, precision=22, scale=0)
    public Long getId() {
        return this.id;
    }

    public void setId(Long id) {
        this.id = id;
    }
	@JsonProperty
    @Column(name="CROP_STAGE_DESC", length=100)
    public String getDescription() {
        return this.description;
    }

    public void setDescription(String description) {
        this.description = description!=null ? description.toUpperCase() : description;
    }

    @JsonProperty
    @Column(name="ACTIVE")
    @Type(type = "yes_no")
    public Boolean getActive() {
        return active;
    }

    public void setActive(Boolean active) {
        if(active!=null && active) activeDescription = "Active";
        else activeDescription = "Not Active";

        this.active = active;
    }

    @JsonProperty
    @Column(name="DEFAULT_STAGE")
    @Type(type = "yes_no")
    public Boolean getDefaultValue() {
        if(defaultValue==null) defaultValue = false;
        return defaultValue;
    }

    public void setDefaultValue(Boolean defaultValue) {
         if(defaultValue!=null && defaultValue) defaultValueDescription = "Yes";
        else defaultValueDescription = "No";
        this.defaultValue = defaultValue;
    }

    @JsonProperty
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "ID_CROP")
    public Crop getCrop() {
        return crop;
    }

    public void setCrop(Crop crop) {
        this.crop = crop;
    }

    @Transient
    @JsonProperty
    public String getActiveDescription() {
        return activeDescription;
    }

    public void setActiveDescription(String activeDescription) {
        this.activeDescription = activeDescription;
    }

     @Transient
    @JsonProperty
    public String getDefaultValueDescription() {
        return defaultValueDescription;
    }

    public void setDefaultValueDescription(String defaultValueDescription) {
        this.defaultValueDescription = defaultValueDescription;
    }
}
