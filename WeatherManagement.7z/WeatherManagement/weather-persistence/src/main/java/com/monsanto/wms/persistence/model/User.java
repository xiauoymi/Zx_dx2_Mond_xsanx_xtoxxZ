package com.monsanto.wms.persistence.model;

import org.codehaus.jackson.annotate.JsonAutoDetect;
import org.codehaus.jackson.annotate.JsonProperty;
import org.hibernate.annotations.Type;

import javax.persistence.*;

import static javax.persistence.GenerationType.SEQUENCE;

/**
 * Created by IntelliJ IDEA.
 * User: MANIET
 * Date: 6/3/13
 * Time: 12:58 PM
 * To change this template use File | Settings | File Templates.
 */
@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE, getterVisibility = JsonAutoDetect.Visibility.NONE)
@Entity
@Table(name="WMS_USER")
public class User extends BaseAuditEntity {

    private String id;
    private String name;
    private String email;
    private Boolean active;
    private Boolean sendNotification;


    private String activeDescription;
    private String sendNotificationDescription;


    public User() {
    }

    public User(String id) {
        this.id = id;
    }

    public User(String id, String name, String email, Boolean active,Boolean sendNotification) {
        this.id = id;
        this.name = name;
        this.email = email;
        this.active = active;
        this.sendNotification = sendNotification;
    }

    @Id
	@JsonProperty
    @Column(name="ID_USER", nullable=false, precision=22, scale=0)
    public String getId() {
        return this.id;
    }

    public void setId(String id) {
        this.id = id;
    }

	@JsonProperty
    @Column(name="USER_NAME", length=100)
    public String getName() {
        return this.name;
    }

    public void setName(String name) {
        this.name = name!=null ? name.toUpperCase() : name;
    }

    @JsonProperty
    @Column(name="EMAIL", length=100)
    public String getEmail() {
        return this.email;
    }

    public void setEmail(String email) {
        this.email = email!=null ? email.toUpperCase() : email;
    }

    @JsonProperty
    @Column(name="ACTIVE")
    @Type(type = "yes_no")
    public Boolean getActive() {
        return active;
    }

    public void setActive(Boolean active) {
        if(active!=null && active) activeDescription = "Active";
        else activeDescription = "Not Active";

        this.active = active;
    }

    @JsonProperty
    @Column(name="SEND_NOTIFICATIONS")
    @Type(type = "yes_no")
    public Boolean getSendNotification() {
        return sendNotification;
    }

    public void setSendNotification(Boolean sendNotification) {
         if(sendNotification!=null && sendNotification) sendNotificationDescription = "Yes";
        else sendNotificationDescription = "No";

        this.sendNotification = sendNotification;
    }

    @Transient
    @JsonProperty
    public String getActiveDescription() {
        return activeDescription;
    }

    public void setActiveDescription(String activeDescription) {
        this.activeDescription = activeDescription;
    }

    @Transient
    @JsonProperty
    public String getSendNotificationDescription() {
        return sendNotificationDescription;
    }

    public void setSendNotificationDescription(String sendNotificationDescription) {
        this.sendNotificationDescription = sendNotificationDescription;
    }
}
