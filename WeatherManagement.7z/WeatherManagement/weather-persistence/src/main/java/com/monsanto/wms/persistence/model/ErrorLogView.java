package com.monsanto.wms.persistence.model;

import org.codehaus.jackson.annotate.JsonAutoDetect;
import org.codehaus.jackson.annotate.JsonProperty;

import javax.persistence.*;
import java.util.Date;

/**
 * Created by GFRAN1 on 9/17/2014.
 */
@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE, getterVisibility = JsonAutoDetect.Visibility.NONE)
@Entity
@Table(name="WMS_DATA_LOADER_LOG_VW")
public class ErrorLogView  {

    private Long id;
    private String dateTime;
    private String temperature;
    private String temperatureMin;
    private String dateTimeTempMin;
    private String tempMax;
    private String dateTimeTempMax;
    private String humidity;
    private String humidityMin;
    private String dateTimeHumidityMin;
    private String humidityMax;
    private String dateTimeHumidityMax;
    private String solarRadiation;
    private String rainFall;
    private String windDirection;
    private String windGust;
    private String windSpeed;
    private String dewPoint;
    private String dewPointMin;
    private String dateTimePointMin;
    private String dewPointMax;
    private String dateTimeDewPointMax;
    private String heatIndex;
    private String heatIndexMin;
    private String dateTimeHeatIndexMin;
    private String heatIndexMax;
    private String dateTimeHeatIndexMax;
    private String rainFallMax;
    private String dateTimeRainFallMax;
    private String status;
    private String errorMessage;
    private Long wmsDataLoaderId;
    private MeteorologicalStation metStationId;
    private Date startDate;
    private Date endDate;
    private Long recordCount;
    private Long insertedCount;
    private Long updatedCount;
    private Long errorCount;


    public ErrorLogView(String dateTime, String temperature, String temperatureMin, String dateTimeTempMin, String tempMax, String dateTimeTempMax, String humidity, String humidityMin, String dateTimeHumidityMin, String humidityMax, String dateTimeHumidityMax, String solarRadiation, String rainFall, String windDirection, String windGust, String windSpeed, String dewPoint, String dewPointMin, String dateTimePointMin, String dewPointMax, String dateTimeDewPointMax, String heatIndex, String heatIndexMin, String dateTimeHeatIndexMin, String heatIndexMax, String dateTimeHeatIndexMax, String rainFallMax, String dateTimeRainFallMax, String status, String errorMessage, Long wmsDataLoaderId, MeteorologicalStation metStationId, Date startDate, Date endDate, Long recordCount, Long insertedCount, Long updatedCount, Long errorCount) {
        this.dateTime = dateTime;
        this.temperature = temperature;
        this.temperatureMin = temperatureMin;
        this.dateTimeTempMin = dateTimeTempMin;
        this.tempMax = tempMax;
        this.dateTimeTempMax = dateTimeTempMax;
        this.humidity = humidity;
        this.humidityMin = humidityMin;
        this.dateTimeHumidityMin = dateTimeHumidityMin;
        this.humidityMax = humidityMax;
        this.dateTimeHumidityMax = dateTimeHumidityMax;
        this.solarRadiation = solarRadiation;
        this.rainFall = rainFall;
        this.windDirection = windDirection;
        this.windGust = windGust;
        this.windSpeed = windSpeed;
        this.dewPoint = dewPoint;
        this.dewPointMin = dewPointMin;
        this.dateTimePointMin = dateTimePointMin;
        this.dewPointMax = dewPointMax;
        this.dateTimeDewPointMax = dateTimeDewPointMax;
        this.heatIndex = heatIndex;
        this.heatIndexMin = heatIndexMin;
        this.dateTimeHeatIndexMin = dateTimeHeatIndexMin;
        this.heatIndexMax = heatIndexMax;
        this.dateTimeHeatIndexMax = dateTimeHeatIndexMax;
        this.rainFallMax = rainFallMax;
        this.dateTimeRainFallMax = dateTimeRainFallMax;
        this.status = status;
        this.errorMessage = errorMessage;
        this.wmsDataLoaderId = wmsDataLoaderId;
        this.metStationId = metStationId;
        this.startDate = startDate;
        this.endDate = endDate;
        this.recordCount = recordCount;
        this.insertedCount = insertedCount;
        this.updatedCount = updatedCount;
        this.errorCount = errorCount;
    }

    public ErrorLogView() {
    }

    @JsonProperty
    @Id
    @Column(name="WMS_DATA_LOADER_STAGING_ID", nullable=false)
    public Long getId() {
        return this.id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    @JsonProperty
    @Column(name="DATETIME",nullable = true)
    public String getDateTime() {
        return dateTime;
    }

    public void setDateTime(String dateTime) {
        this.dateTime = dateTime;
    }

    @JsonProperty
    @Column(name="TEMP",nullable = true)
    public String getTemperature() {
        return temperature;
    }

    public void setTemperature(String temperature) {
        this.temperature = temperature;
    }

    @JsonProperty
    @Column(name="TEMPMIN" ,nullable = true)
    public String getTemperatureMin() {
        return temperatureMin;
    }

    public void setTemperatureMin(String temperatureMin) {
        this.temperatureMin = temperatureMin;
    }

    @JsonProperty
    @Column(name="DATETIMETEMPMIN",nullable = true)
    public String getDateTimeTempMin() {
        return dateTimeTempMin;
    }

    public void setDateTimeTempMin(String dateTimeTempMin) {
        this.dateTimeTempMin = dateTimeTempMin;
    }

    @JsonProperty
    @Column(name="TEMPMAX",nullable = true)
    public String getTempMax() {
        return tempMax;
    }

    public void setTempMax(String tempMax) {
        this.tempMax = tempMax;
    }

    @JsonProperty
    @Column(name="DATETIMETEMPMAX",nullable = true)
    public String getDateTimeTempMax() {
        return dateTimeTempMax;
    }

    public void setDateTimeTempMax(String dateTimeTempMax) {
        this.dateTimeTempMax = dateTimeTempMax;
    }

    @JsonProperty
    @Column(name="HUMIDITY",nullable = true)
    public String getHumidity() {
        return humidity;
    }

    public void setHumidity(String humidity) {
        this.humidity = humidity;
    }

    @JsonProperty
    @Column(name="HUMIDITYMIN",nullable = true)
    public String getHumidityMin() {
        return humidityMin;
    }

    public void setHumidityMin(String humidityMin) {
        this.humidityMin = humidityMin;
    }

    @JsonProperty
    @Column(name="DATETIMEHUMIDTYMIN",nullable = true)
    public String getDateTimeHumidityMin() {
        return dateTimeHumidityMin;
    }

    public void setDateTimeHumidityMin(String dateTimeHumidityMin) {
        this.dateTimeHumidityMin = dateTimeHumidityMin;
    }

    @JsonProperty
    @Column(name="HUMIDITYMAX",nullable = true)
    public String getHumidityMax() {
        return humidityMax;
    }

    public void setHumidityMax(String humidityMax) {
        this.humidityMax = humidityMax;
    }

    @JsonProperty
    @Column(name="DATETIMEHUMIDITYMAX",nullable = true)
    public String getDateTimeHumidityMax() {
        return dateTimeHumidityMax;
    }

    public void setDateTimeHumidityMax(String dateTimeHumidityMax) {
        this.dateTimeHumidityMax = dateTimeHumidityMax;
    }

    @JsonProperty
    @Column(name="SOLARRADIATION",nullable = true)
    public String getSolarRadiation() {
        return solarRadiation;
    }

    public void setSolarRadiation(String solarRadiation) {
        this.solarRadiation = solarRadiation;
    }

    @JsonProperty
    @Column(name="RAINFALL",nullable = true)
    public String getRainFall() {
        return rainFall;
    }

    public void setRainFall(String rainFall) {
        this.rainFall = rainFall;
    }

    @JsonProperty
    @Column(name="WINDDIRECTION",nullable = true)
    public String getWindDirection() {
        return windDirection;
    }

    public void setWindDirection(String windDirection) {
        this.windDirection = windDirection;
    }

    @JsonProperty
    @Column(name="WINDGUST",nullable = true)
    public String getWindGust() {
        return windGust;
    }

    public void setWindGust(String windGust) {
        this.windGust = windGust;
    }

    @JsonProperty
    @Column(name="WINDSPEED",nullable = true)
    public String getWindSpeed() {
        return windSpeed;
    }

    public void setWindSpeed(String windSpeed) {
        this.windSpeed = windSpeed;
    }

    @JsonProperty
    @Column(name="DEWPOINT",nullable = true)
    public String getDewPoint() {
        return dewPoint;
    }

    public void setDewPoint(String dewPoint) {
        this.dewPoint = dewPoint;
    }

    @JsonProperty
    @Column(name="DEWPOINTMIN",nullable = true)
    public String getDewPointMin() {
        return dewPointMin;
    }

    public void setDewPointMin(String dewPointMin) {
        this.dewPointMin = dewPointMin;
    }

    @JsonProperty
    @Column(name="DATETIMEDEWPOINTMIN",nullable = true)
    public String getDateTimePointMin() {
        return dateTimePointMin;
    }

    public void setDateTimePointMin(String dateTimePointMin) {
        this.dateTimePointMin = dateTimePointMin;
    }

    @JsonProperty
    @Column(name="DEWPOINTMAX",nullable = true)
    public String getDewPointMax() {
        return dewPointMax;
    }

    public void setDewPointMax(String dewPointMax) {
        this.dewPointMax = dewPointMax;
    }

    @JsonProperty
    @Column(name="DATETIMEDEWPOINTMAX",nullable = true)
    public String getDateTimeDewPointMax() {
        return dateTimeDewPointMax;
    }

    public void setDateTimeDewPointMax(String dateTimeDewPointMax) {
        this.dateTimeDewPointMax = dateTimeDewPointMax;
    }

    @JsonProperty
    @Column(name="HEATINDEX",nullable = true)
    public String getHeatIndex() {
        return heatIndex;
    }

    public void setHeatIndex(String heatIndex) {
        this.heatIndex = heatIndex;
    }

    @JsonProperty
    @Column(name="HEATINDEXMIN",nullable = true)
    public String getHeatIndexMin() {
        return heatIndexMin;
    }

    public void setHeatIndexMin(String heatIndexMin) {
        this.heatIndexMin = heatIndexMin;
    }

    @JsonProperty
    @Column(name="DATETIMEHEATINDEXMIN",nullable = true)
    public String getDateTimeHeatIndexMin() {
        return dateTimeHeatIndexMin;
    }

    public void setDateTimeHeatIndexMin(String dateTimeHeatIndexMin) {
        this.dateTimeHeatIndexMin = dateTimeHeatIndexMin;
    }

    @JsonProperty
    @Column(name="HEATINDEXMAX",nullable = true)
    public String getHeatIndexMax() {
        return heatIndexMax;
    }

    public void setHeatIndexMax(String heatIndexMax) {
        this.heatIndexMax = heatIndexMax;
    }

    @JsonProperty
    @Column(name="DATETIMEHEATINDEXMAX",nullable = true)
    public String getDateTimeHeatIndexMax() {
        return dateTimeHeatIndexMax;
    }

    public void setDateTimeHeatIndexMax(String dateTimeHeatIndexMax) {
        this.dateTimeHeatIndexMax = dateTimeHeatIndexMax;
    }

    @JsonProperty
    @Column(name="RAINFALLMAX",nullable = true)
    public String getRainFallMax() {
        return rainFallMax;
    }

    public void setRainFallMax(String rainFallMax) {
        this.rainFallMax = rainFallMax;
    }

    @JsonProperty
    @Column(name="DATETIMERAINFALLMAX",nullable = true)
    public String getDateTimeRainFallMax() {
        return dateTimeRainFallMax;
    }

    public void setDateTimeRainFallMax(String dateTimeRainFallMax) {
        this.dateTimeRainFallMax = dateTimeRainFallMax;
    }

    @JsonProperty
    @Column(name="STATUS",nullable = true)
    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    @JsonProperty
    @Column(name="ERROR_MESSAGE",nullable = true)
    public String getErrorMessage() {
        return errorMessage;
    }

    public void setErrorMessage(String error_message) {
        this.errorMessage = error_message;
    }

    @JsonProperty
    @Column(name="WMS_DATA_LOADER_LOG_ID", nullable=true)
    public Long getWmsDataLoaderId() {
        return wmsDataLoaderId;
    }

    public void setWmsDataLoaderId(Long wmsDataLoaderId) {
        this.wmsDataLoaderId = wmsDataLoaderId;
    }


    @JsonProperty
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "METEORO_STATION_ID")
    public MeteorologicalStation getMetStationId() {
        return metStationId;
    }

    public void setMetStationId(MeteorologicalStation metStationId) {
        this.metStationId = metStationId;
    }


    @JsonProperty
    @Column(name = "START_DATE")
    public Date getStartDate() {
        return startDate;
    }

    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    @JsonProperty
    @Column(name = "END_DATE")
    public Date getEndDate() {
        return endDate;
    }

    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }

    @JsonProperty
    @Column(name = "RECORD_COUNT")
    public Long getRecordCount() {
        return recordCount;
    }

    public void setRecordCount(Long recordCount) {
        this.recordCount = recordCount;
    }

    @JsonProperty
    @Column(name = "INSERTED_COUNT")
    public Long getInsertedCount() {
        return insertedCount;
    }

    public void setInsertedCount(Long insertedCount) {
        this.insertedCount = insertedCount;
    }

    @JsonProperty
    @Column(name = "UPDATED_COUNT")
    public Long getUpdatedCount() {
        return updatedCount;
    }

    public void setUpdatedCount(Long updatedCount) {
        this.updatedCount = updatedCount;
    }

    @JsonProperty
    @Column(name = "ERROR_COUNT")
    public Long getErrorCount() {
        return errorCount;
    }

    public void setErrorCount(Long errorCount) {
        this.errorCount = errorCount;
    }



}
