package com.monsanto.wms.persistence.model;

import org.codehaus.jackson.annotate.JsonAutoDetect;
import org.codehaus.jackson.annotate.JsonProperty;
import org.hibernate.annotations.Type;

import javax.persistence.*;

import static javax.persistence.GenerationType.SEQUENCE;

/**
 * Created by IntelliJ IDEA.
 * User: MANIET
 * Date: 6/3/13
 * Time: 12:58 PM
 * To change this template use File | Settings | File Templates.
 */
@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.NONE, getterVisibility = JsonAutoDetect.Visibility.NONE)
@Entity
@Table(name="WMS_METEORO_STATIONS")
public class MeteorologicalStation extends BaseAuditEntity {

    public static final Long DAVIS = 1L;
    public static final Long SPECTRUM = 2L;

    private Long id;
    private String description;
    private String longitude;
    private String latitude;
    private Boolean active;
    private String userName;
    private String pwd;
    private MeteorologicalStationOwner owner;
    private StationType stationType;
    private String serialNumber;
    private User responsible;

    private String activeDescription;


    public MeteorologicalStation() {
    }

    public MeteorologicalStation(MeteorologicalStation ms) {
        this.id = ms.getId();
        this.description=ms.getDescription();
        this.longitude=ms.getLongitude();
        this.latitude=ms.getLatitude();
        this.active = ms.getActive();
        this.userName=ms.getUserName();
        this.pwd=ms.getPwd();


    }

    public MeteorologicalStation(Long id) {
        setId(id);
    }

    public MeteorologicalStation(String description) {
        this.description = description;
        this.active = true;
    }

    public MeteorologicalStation(Long id, String description, String longitude, String latitude, Boolean active) {
        this.id = id;
        this.description = description;
        this.longitude = longitude;
        this.latitude = latitude;
        this.active = active;
    }

    public MeteorologicalStation(Long id, String description, String longitude, String latitude, Boolean active, Long ownerId,String userName,String pwd, Long stationType,String serialNumber,String responsible) {
        this.id = id;
        this.longitude = longitude;
        this.latitude = latitude;
        setDescription(description);
        this.active = active != null ? active : false;
        this.owner = new MeteorologicalStationOwner(ownerId);
        this.userName  = userName;
        this.pwd  = pwd;
        setStationType(new StationType(stationType));
        this.serialNumber = serialNumber;
        this.responsible = new User(responsible);
    }

    @SequenceGenerator(name="generator", sequenceName="WMS_METEORO_STATION_OWNER_SEQ")@Id
    @GeneratedValue(strategy=SEQUENCE, generator="generator")
	@JsonProperty
    @Column(name="ID_METEORO_STATIONS", nullable=false, precision=22, scale=0)
    public Long getId() {
        return this.id;
    }

    public void setId(Long id) {
        this.id = id;
    }
	@JsonProperty
    @Column(name="DESCRIPTION", length=100)
    public String getDescription() {
        return this.description;
    }

    public void setDescription(String description) {
        this.description = description!=null ? description.toUpperCase() : description;
    }

    @JsonProperty
    @Column(name="LONGITUD", length=100)
    public String getLongitude() {
        return longitude;
    }

    public void setLongitude(String longitude) {
        this.longitude = longitude;
    }

    @JsonProperty
    @Column(name="LATITITUD", length=100)
    public String getLatitude() {
        return latitude;
    }

    public void setLatitude(String latitude) {
        this.latitude = latitude;
    }

    @JsonProperty
    @Column(name="ACTIVE")
    @Type(type = "yes_no")
    public Boolean getActive() {
        return active;
    }

    public void setActive(Boolean active) {
        if(active!=null && active) activeDescription = "Active";
        else activeDescription = "Not Active";

        this.active = active;
    }

    @JsonProperty
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "ID_METEORO_STATION_OWNER")
       public MeteorologicalStationOwner getOwner() {
        return owner;
    }

    public void setOwner(MeteorologicalStationOwner owner) {
        this.owner = owner;
    }

    @JsonProperty
    @Column(name="STATION_USER")
    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    @JsonProperty
    @Column(name="STATION_PWD")
    public String getPwd() {
        return pwd;
    }

    public void setPwd(String pwd) {
        this.pwd = pwd;
    }


    @JsonProperty
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "METEORO_STATION_TYPE_ID")
    public StationType getStationType() {
        return stationType;
    }

    public void setStationType(StationType stationType) {
        this.stationType = stationType;
    }

    @Transient
    @JsonProperty
    public String getActiveDescription() {
        return activeDescription;
    }

    public void setActiveDescription(String activeDescription) {
        this.activeDescription = activeDescription;
    }

    @JsonProperty
    @Column(name="SERIAL_NUMBER")
    public String getSerialNumber() {
        return serialNumber;
    }

    public void setSerialNumber(String serialNumber) {
        this.serialNumber = serialNumber;
    }

    @JsonProperty
    @OneToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "RESPONSIBLE_ID")
    public User getResponsible() {
        return responsible;
    }

    public void setResponsible(User responsibleId) {
        this.responsible = responsibleId;
    }
}
