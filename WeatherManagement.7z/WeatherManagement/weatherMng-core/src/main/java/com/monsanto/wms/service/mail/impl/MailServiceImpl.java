package com.monsanto.wms.service.mail.impl;


import com.monsanto.wms.exceptions.WMSException;
import com.monsanto.wms.service.mail.MailService;
import com.monsanto.wms.support.mail.AbstractMailSender;
import freemarker.template.Configuration;
import freemarker.template.TemplateException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Component;

import javax.mail.MessagingException;
import java.io.IOException;
import java.util.*;

/**
 * Created by IntelliJ IDEA.
 * User: FJSIBA
 * Date: 13/11/12
 * Time: 09:09 AM
 * To change this template use File | Settings | File Templates.
 */
@Component(value = "mailService")
public class MailServiceImpl extends AbstractMailSender implements MailService {
    private String from;
    private String topHeader;

    @Autowired
    public MailServiceImpl(JavaMailSender mailSender, Configuration freeMarkerConfiguration) {
        super(mailSender, freeMarkerConfiguration);
    }

    @Override
    public String getFrom() {
        return this.from;
    }


    @Value("${${lsi.function}.notification.mail.from}")
    public void setFrom(String from) {
        this.from = from;
    }

    public String getTopHeader() {
        return topHeader;
    }

    @Value("${mail.default.image.mailHeader}")
    public void setTopHeader(String topHeader) {
        this.topHeader = topHeader;
    }

    @Override
    public void sendMailMessage(String subject,String to,String msg, String template) throws WMSException {

        SimpleMailMessage simpleMailMessage = new SimpleMailMessage();
        simpleMailMessage.setTo(to);
        simpleMailMessage.setFrom(getFrom());
        simpleMailMessage.setSubject(subject);
        Map<String, Object> model = new HashMap<String, Object>();
        model.put("currentDate",new Date().toString());
        model.put("title",subject);
        model.put("messageText",msg);


        try {
            sendSimpleMessage(simpleMailMessage, template, model);
        } catch (MessagingException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (TemplateException e) {
            e.printStackTrace();
        }

    }

}
