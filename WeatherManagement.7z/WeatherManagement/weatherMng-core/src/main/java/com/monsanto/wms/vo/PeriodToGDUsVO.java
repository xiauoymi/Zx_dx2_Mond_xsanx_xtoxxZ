package com.monsanto.wms.vo;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: MANIET
 * Date: 6/21/13
 * Time: 12:28 PM
 * To change this template use File | Settings | File Templates.
 */

public class PeriodToGDUsVO {

    private final Integer INDEX_GDUS = 0;
    private final Integer INDEX_ERROR = 1;


    private Double gdus;
    private String error;

    private List<PeriodToGDUsVO> items;

    public PeriodToGDUsVO() {
    }

    public PeriodToGDUsVO(List objects) {
        items = new ArrayList<PeriodToGDUsVO>();

        for(Object currentObject : objects){
          Object[] currentItem = (Object[])currentObject;
          items.add(new PeriodToGDUsVO(Double.parseDouble(String.valueOf(currentItem[INDEX_GDUS])),
                  currentItem[INDEX_ERROR]!=null ? (String.valueOf(currentItem[INDEX_ERROR])) : ""));
        }
    }

    public PeriodToGDUsVO(Double gdus, String error) {
        this.gdus = gdus;
        this.error = error;
    }

    public Double getGdus() {
        return gdus;
    }

    public void setGdus(Double gdus) {
        this.gdus = gdus;
    }

    public String getError() {
        return error;
    }

    public void setError(String error) {
        this.error = error;
    }

    public List<PeriodToGDUsVO> getItems() {
        return items;
    }

    public void setItems(List<PeriodToGDUsVO> items) {
        this.items = items;
    }
}
