package com.monsanto.wms.util;

import org.codehaus.jackson.JsonGenerator;
import org.codehaus.jackson.JsonProcessingException;
import org.codehaus.jackson.map.JsonSerializer;
import org.codehaus.jackson.map.SerializerProvider;

import java.io.IOException;

/**
 * Monsanto
 * Author: Luis Miguel Arteaga Rios (lmarte@monsanto.com)
 * Date: 6/12/12
 * Time: 03:56 PM
 */
public class AreaTypeSerializer extends JsonSerializer<AreaType> {

    @Override
    public void serialize(AreaType areaType, JsonGenerator jsonGenerator, SerializerProvider serializerProvider) throws IOException, JsonProcessingException {
        jsonGenerator.writeStartObject();
        for( AreaType area : AreaType.values() ){
            jsonGenerator.writeFieldName( area.name() );
            jsonGenerator.writeNumber( area.getId() );
        }
        jsonGenerator.writeEndObject();
    }
}
