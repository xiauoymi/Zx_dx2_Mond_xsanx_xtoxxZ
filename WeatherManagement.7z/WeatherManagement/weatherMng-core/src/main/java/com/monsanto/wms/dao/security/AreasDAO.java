package com.monsanto.wms.dao.security;

import com.monsanto.wms.persistence.model.Area;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: MANIET
 * Date: 6/3/13
 * Time: 3:52 PM
 * To change this template use File | Settings | File Templates.
 */
@Repository
public interface AreasDAO extends JpaRepository<Area, Long> {
     Collection<Area> findByActiveTrueOrderByDescriptionAsc();

}
