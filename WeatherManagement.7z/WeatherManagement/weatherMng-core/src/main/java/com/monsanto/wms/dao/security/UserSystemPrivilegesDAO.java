package com.monsanto.wms.dao.security;

import com.monsanto.wms.persistence.model.UserSystemPrivileges;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: MANIET
 * Date: 6/3/13
 * Time: 3:52 PM
 * To change this template use File | Settings | File Templates.
 */
@Repository
public interface UserSystemPrivilegesDAO extends JpaRepository<UserSystemPrivileges, Long> {

     Page findByUserIdLikeAndUserActive(String userId,Boolean active, Pageable pageable);
     Page findByUserIdLikeAndRoleAreaIdAndUserActive(String userId,Long areaId,Boolean active, Pageable pageable);
     Page findByUserIdLikeAndRoleIdAndUserActive(String userId,Long roleId,Boolean active, Pageable pageable);
     Page findByUserIdLikeAndRoleAreaIdAndRoleIdAndUserActive(String userId,Long areaId,Long roleId,Boolean active, Pageable pageable);

     List<UserSystemPrivileges> findByUserIdAndRoleAreaId(String userId,Long areaId);
     List<UserSystemPrivileges> findByUserId(String userId);
    List<UserSystemPrivileges> findByRoleAreaIdAndUserSendNotificationTrue(Long areaId);


}
