package com.monsanto.wms.util;

import org.codehaus.jackson.JsonGenerator;
import org.codehaus.jackson.JsonProcessingException;
import org.codehaus.jackson.map.JsonSerializer;
import org.codehaus.jackson.map.SerializerProvider;

import java.io.IOException;

/**
 * Monsanto
 * Author: Luis Miguel Arteaga Rios (lmarte@monsanto.com)
 * Date: 6/12/12
 * Time: 03:56 PM
 */
public class RoleTypeSerializer extends JsonSerializer<RoleType> {

    @Override
    public void serialize(RoleType roleType, JsonGenerator jsonGenerator, SerializerProvider serializerProvider) throws IOException, JsonProcessingException {
        jsonGenerator.writeStartObject();
        for( RoleType role : RoleType.values() ){
            jsonGenerator.writeFieldName( role.name() );
            jsonGenerator.writeNumber( role.getId() );
        }
        jsonGenerator.writeEndObject();
    }
}
