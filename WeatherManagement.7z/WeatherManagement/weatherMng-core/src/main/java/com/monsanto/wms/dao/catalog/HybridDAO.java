package com.monsanto.wms.dao.catalog;

import com.monsanto.wms.persistence.model.Hybrid;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: MANIET
 * Date: 6/3/13
 * Time: 3:52 PM
 * To change this template use File | Settings | File Templates.
 */
@Repository
public interface HybridDAO extends JpaRepository<Hybrid, Long> {
    Page findByDescriptionLikeAndActive(String description, Boolean active, Pageable pageable);

    Page findByDescriptionLikeAndCropIdAndCropTypeIdAndActive(String description, Long cropId, Long cropTypeId,Boolean active, Pageable pageable);
    Page findByDescriptionLikeAndCropTypeIdAndActive(String description, Long cropTypeId,Boolean active, Pageable pageable);

    Collection<Hybrid> findByActiveTrueOrderByDescriptionAsc();
    Collection<Hybrid> findByCropTypeIdAndCropIdAndDescriptionLikeAndActiveTrueOrderByDescriptionAsc(Long cropTypeId,Long cropId,String match);
}
