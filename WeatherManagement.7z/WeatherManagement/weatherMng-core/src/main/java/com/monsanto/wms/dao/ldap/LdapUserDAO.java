package com.monsanto.wms.dao.ldap;

import com.monsanto.wms.vo.LdapUserVO;

import java.util.Collection;

/**
 * Monsanto
 * Author: MANIET
 * Date: 29/11/12
 * Time: 04:23 PM
 */
public interface LdapUserDAO {
    Collection<LdapUserVO> findByIdLike(String userId);
    Boolean authenticated(String userId, String password);
}
