package com.monsanto.wms.vo;

import com.monsanto.wms.util.WMSServiceUtil;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: MANIET
 * Date: 6/21/13
 * Time: 12:28 PM
 * To change this template use File | Settings | File Templates.
 */
public class GeneralCalculationByDayVO {

    private final Integer INDEX_TEMP_MIN = 1;
    private final Integer INDEX_TEMP_MAX = 0;
    private final Integer INDEX_NU_DAY = 2;
    private final Integer INDEX_MONTH_DESC = 3;
    private final Integer INDEX_GDU_DESC = 4;
    private final Integer INDEX_ERROR = 5;

    private Double tempMinF;
    private Double tempMaxF;
    private Double tempMinC;
    private Double tempMaxC;
    private Integer day;
    private String month;
    private String error;
    private Double realGDU;

    private List<GeneralCalculationByDayVO> items;

    public GeneralCalculationByDayVO() {
    }

    public GeneralCalculationByDayVO(List objects) {
        items = new ArrayList<GeneralCalculationByDayVO>();

        for(Object currentObject : objects){
          Object[] currentItem = (Object[])currentObject;
          items.add(new GeneralCalculationByDayVO(Double.parseDouble(String.valueOf(currentItem[INDEX_TEMP_MIN])),
                  Double.parseDouble(String.valueOf(currentItem[INDEX_TEMP_MAX])),
                  Integer.parseInt(String.valueOf(currentItem[INDEX_NU_DAY])),
                  String.valueOf(currentItem[INDEX_MONTH_DESC]),
                  Double.parseDouble(String.valueOf(currentItem [INDEX_GDU_DESC])),
                  currentItem[INDEX_ERROR]!=null ? (String.valueOf(currentItem[INDEX_ERROR])) : ""));
        }
    }

    public GeneralCalculationByDayVO(Double tempMin, Double tempMax, Integer day, String month,Double realGDU, String error) {
        this.tempMinC = tempMin;
        this.tempMaxC = tempMax;
        this.day = day;
        this.month = month;
        this.realGDU = realGDU;
        this.error = error;
    }

    public Double getTempMinF() {
         if(tempMinC!=null){
            this.tempMinF = WMSServiceUtil.celsiusToFahrenheit(this.tempMinC);
        }
        return tempMinF;
    }

    public void setTempMinF(Double tempMinF) {
        this.tempMinF = tempMinF;
    }

    public Double getTempMaxF() {
         if(tempMaxC!=null){
            this.tempMaxF = WMSServiceUtil.celsiusToFahrenheit(this.tempMaxC);
        }
        return tempMaxF;
    }

    public void setTempMaxF(Double tempMaxF) {
        this.tempMaxF = tempMaxF;
    }

    public Double getTempMinC(){
        return tempMinC;
    }

    public void setTempMinC(Double tempMinC) {
        this.tempMinC = tempMinC;
    }

    public Double getTempMaxC() {
        return tempMaxC;
    }

    public void setTempMaxC(Double tempMaxC) {
        this.tempMaxC = tempMaxC;
    }

    public Integer getDay() {
        return day;
    }

    public void setDay(Integer day) {
        this.day = day;
    }

    public String getMonth() {
        return month;
    }

    public void setMonth(String month) {
        this.month = month;
    }


    public Double getRealGDU() {
        return realGDU;
    }

    public void setRealGDU(Double realGDU) {
        this.realGDU = realGDU;
    }

    public List<GeneralCalculationByDayVO> getItems() {
        return items;
    }

    public void setItems(List<GeneralCalculationByDayVO> items) {
        this.items = items;
    }

    public String getError() {
        return error;
    }

    public void setError(String error) {
        this.error = error;
    }
}
