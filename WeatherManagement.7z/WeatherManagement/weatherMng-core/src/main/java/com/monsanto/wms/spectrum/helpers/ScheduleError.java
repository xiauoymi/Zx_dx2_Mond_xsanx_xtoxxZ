package com.monsanto.wms.spectrum.helpers;

/**
 * Created with IntelliJ IDEA.
 * User: MANIET
 * Date: 10/15/13
 * Time: 8:18 AM
 * To change this template use File | Settings | File Templates.
 */
public class ScheduleError {

    private final String section;
    private final String message;

    public ScheduleError(String section, String message) {
        this.section = section;
        this.message = message;
    }

    public String getSection() {
        return section;
    }

    public String getMessage() {
        return message;
    }
}
