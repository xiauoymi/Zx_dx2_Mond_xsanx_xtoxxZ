package com.monsanto.wms.service.catalog.impl;

import com.monsanto.wms.dao.catalog.HybridDAO;
import com.monsanto.wms.persistence.model.Hybrid;
import com.monsanto.wms.service.catalog.HybridService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: MANIET
 * Date: 6/3/13
 * Time: 3:51 PM
 * To change this template use File | Settings | File Templates.
 */
@Service
public final class HybridServiceImpl implements HybridService {

    private HybridDAO hybridDAO;

    @Autowired
    public HybridServiceImpl(HybridDAO hybridDAO) {
        this.hybridDAO = hybridDAO;
    }

    @Override
    public Page<Hybrid> search(String description, Long cropTypeId, Long cropId, Boolean active,  Pageable pageable) {
        String descriptionParam = "%"+ ( description!=null ? description.toUpperCase() : description )+"%";

        if(cropTypeId!=null && cropId !=null && cropTypeId>0 && cropId>0){
           return hybridDAO.findByDescriptionLikeAndCropIdAndCropTypeIdAndActive(descriptionParam,cropId,cropTypeId,active,pageable);
        }else if(cropTypeId!=null && cropId !=null && cropTypeId>0 && cropId<0){
            return hybridDAO.findByDescriptionLikeAndCropTypeIdAndActive(descriptionParam,cropTypeId,active,pageable);
        }else{
            return hybridDAO.findByDescriptionLikeAndActive(descriptionParam,active,pageable);
        }
    }

     @Override
    public Hybrid findById(Long hybridId) {
        return hybridDAO.findOne(hybridId);
    }

    @Override
    public void delete(Long id) {
        hybridDAO.delete(id);
    }

    @Override
    public Collection<Hybrid> loadCollection() {
        return hybridDAO.findByActiveTrueOrderByDescriptionAsc();
    }

    @Override
    public Hybrid save(Hybrid hybrid) {
        return hybridDAO.saveAndFlush(hybrid);
    }

    @Override
    public Collection<Hybrid> findDynamicList(String match,Long cropTypeId,Long cropId) {
        String matchParam = "%"+(match!=null ? match.toUpperCase() : match)+"%";
        return hybridDAO.findByCropTypeIdAndCropIdAndDescriptionLikeAndActiveTrueOrderByDescriptionAsc(cropTypeId,cropId,matchParam);
    }
}
