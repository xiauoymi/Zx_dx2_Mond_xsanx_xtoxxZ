package com.monsanto.wms.service.production.impl;

import com.monsanto.wms.dao.oracle.OracleFxDAO;
import com.monsanto.wms.exceptions.WMSException;
import com.monsanto.wms.service.production.PRGeneralReportService;
import com.monsanto.wms.vo.ReportPRGeneralReportVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: MANIET
 * Date: 6/3/13
 * Time: 3:51 PM
 * To change this template use File | Settings | File Templates.
 */
@Service
public final class PRGeneralReportServiceImpl implements PRGeneralReportService {

    private OracleFxDAO<Object> oracleFxDAO;

    @Autowired
    public PRGeneralReportServiceImpl(OracleFxDAO<Object> oracleFxDAO) {

        this.oracleFxDAO = oracleFxDAO;
    }


    @Transactional
    @Override
    public List<ReportPRGeneralReportVO> getReport(Integer initYear,Integer initMonth,Integer initDay,
                                                   Integer endYear,Integer endMonth,Integer endDay,
                                                   Long meteorologicalStationId, Double tempMin, Double tempMax,
                                                   String cropName,Double tempUnder,Double tempAbove,Pageable pageable) {

        List<ReportPRGeneralReportVO> ls = new ArrayList<ReportPRGeneralReportVO>();
        if (validateRealReportInputs(initYear,initDay,initMonth,
                                     endYear,endDay,endMonth,
                                     meteorologicalStationId, tempMin, tempMax,
                                     cropName,tempUnder,tempAbove)) {
            ReportPRGeneralReportVO rs = new ReportPRGeneralReportVO(oracleFxDAO.executeFunction("getGeneralReport", initYear,initDay,initMonth,
                                                                                                                     endYear,endDay,endMonth,
                                                                                                                     meteorologicalStationId, tempMin, tempMax,
                                                                                                                     cropName,tempUnder,tempAbove));

            ls = rs.getItems();
        }

        return ls;
    }

    private Boolean validateRealReportInputs(Integer initYear,Integer initMonth,Integer initDay,
                                                   Integer endYear,Integer endMonth,Integer endDay,
                                                   Long meteorologicalStationId, Double tempMin, Double tempMax,
                                                   String cropName,Double tempUnder,Double tempAbove){
        if(initYear==null || initYear<0L){ return false;}
        else if(initMonth==null || initMonth<0L){ return false;}
        else if(initDay==null || initDay<0L){ return false;  }
        else if(endYear==null || endYear<0L){ return false; }
        else if(endMonth==null || endMonth<0L){ return false; }
        else if(endDay==null || endDay<0L){ return false;   }
        else if(meteorologicalStationId==null || meteorologicalStationId<0L){ return false;}
        else if(tempMin==null){ return false;}
        else if(tempMax==null){ return false;  }
        else if(cropName==null){ return false;  }
        else if(tempUnder==null){ return false; }
        else if(tempAbove==null){ return false;  }

        return true;

    }
}
