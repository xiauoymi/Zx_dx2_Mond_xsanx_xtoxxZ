package com.monsanto.wms.exceptions.davisSchedule;

import com.monsanto.wms.exceptions.WMSException;

/**
 * Created by IntelliJ IDEA.
 * User: MANIET
 * Date: 29/11/12
 * To change this template use File | Settings | File Templates.
 */
public class DavisSpectrumScheduleException extends WMSException {

    public static final int DAVIS = 1;
    public static final int SPECTRUM = 2;
    private String url;

    public DavisSpectrumScheduleException(String message,int stationType) {
        super(message);

        if(stationType == DAVIS){
            url = "http://www.weatherlink.com/";
        }else{
            url = "http://www.weatherlink.com/";
        }
    }

    public String getCustomizedMessage(){
        if(super.getMessage()==null || (super.getMessage().contains("null") && super.getMessage().contains(" Tried all"))){
            return "The "+url+" is not available, if you continue reciving this error call your administrator."
                    + " The most common reason is : Web Maintenance";
        }else if(super.getMessage().contains("403")) {
             return "The "+url+" is not available, call your administrator immediately."
                    + " The most common reason is : Firewall blocking";

        }else if(super.getMessage().contains("Content is not allowed in prolog")) {
             return "The URL reading is invalid review your user name and password if the problem persist call your administrator immediately";

        }

        return super.getMessage();
    }

}
