package com.monsanto.wms.service.catalog;

import com.monsanto.wms.persistence.model.MeteorologicalStationOwner;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: MANIET
 * Date: 6/3/13
 * Time: 3:51 PM
 * To change this template use File | Settings | File Templates.
 */
public interface MeteorologicStationOwnerService {

    Page<MeteorologicalStationOwner> search(String description, String shortDescription,Long areaId,Boolean active, Pageable pageable);
    MeteorologicalStationOwner save(MeteorologicalStationOwner meteorologicalStationOwner);
    MeteorologicalStationOwner findById(Long id);
    void delete(Long id);
    Collection<MeteorologicalStationOwner> loadCollection();
}
