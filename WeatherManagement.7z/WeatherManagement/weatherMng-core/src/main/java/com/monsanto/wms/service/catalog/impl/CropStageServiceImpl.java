package com.monsanto.wms.service.catalog.impl;

import com.monsanto.wms.dao.catalog.CropStageDAO;
import com.monsanto.wms.exceptions.CatalogException;
import com.monsanto.wms.persistence.model.CropStage;
import com.monsanto.wms.service.catalog.CropStageService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: MANIET
 * Date: 6/3/13
 * Time: 3:51 PM
 * To change this template use File | Settings | File Templates.
 */
@Service
public final class CropStageServiceImpl implements CropStageService {

    private CropStageDAO cropStageDAO;

    @Autowired
    public CropStageServiceImpl(CropStageDAO cropStageDAO) {
        this.cropStageDAO = cropStageDAO;
    }

    @Override
    public Page<CropStage> search(String description, Long cropTypeId, Long cropId, Boolean active,  Pageable pageable) {
        String descriptionParam = "%"+(description!=null ? description.toUpperCase() : description)+"%";

        if(cropTypeId!=null && cropId !=null && cropTypeId>0 && cropId>0){
           return cropStageDAO.findByDescriptionLikeAndCropIdAndCropTypeIdAndActive(descriptionParam,cropId,cropTypeId,active,pageable);
        }else if(cropTypeId!=null && cropId !=null && cropTypeId>0 && cropId<0){
            return cropStageDAO.findByDescriptionLikeAndCropTypeIdAndActive(descriptionParam,cropTypeId,active,pageable);
        }else{
            return cropStageDAO.findByDescriptionLikeAndActive(descriptionParam,active,pageable);
        }
    }

     @Override
    public CropStage findById(Long cropStageId) {
        return cropStageDAO.findOne(cropStageId);
    }

    @Override
    public void delete(Long id,Boolean defaultValue) {

        if(!defaultValue){
            cropStageDAO.delete(id);
        }else{
            throw new CatalogException("This Registry is a default value, can not be deleted");
        }

    }

    @Override
    public Collection<CropStage> loadCollection() {
        return cropStageDAO.findByActiveTrueOrderByDescriptionAsc();
    }

     @Override
    public Collection<CropStage> loadCollectionDefault() {
        return cropStageDAO.findByActiveTrueAndDefaultValueTrueOrderByDescriptionAsc();
    }

    @Override
    public CropStage save(CropStage cropStage) {
        if(!cropStage.getDefaultValue()){
            return cropStageDAO.saveAndFlush(cropStage);
        }else{
            throw new CatalogException("This Registry is a default value, can not be updated");
        }

    }

    @Override
    public Collection<CropStage> loadCollectionNotDefault() {
        return cropStageDAO.findByActiveTrueAndDefaultValueFalseOrderByDescriptionAsc();
    }

    @Override
    public Collection<CropStage> loadCollectionNotDefaultByCropId(Long cropId) {
        return cropStageDAO.findByActiveTrueAndDefaultValueFalseAndCropIdOrderByDescriptionAsc(cropId);
    }
}
