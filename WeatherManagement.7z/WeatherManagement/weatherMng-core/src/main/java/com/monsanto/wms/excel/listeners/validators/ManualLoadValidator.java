package com.monsanto.wms.excel.listeners.validators;

import com.monsanto.wms.exceptions.WMSException;

import java.text.DecimalFormat;
import java.util.List;
import java.util.regex.Pattern;

/**
 * Created by IntelliJ IDEA.
 * User: MANIET
 * Date: 7/24/13
 * Time: 10:34 AM
 * To change this template use File | Settings | File Templates.
 */
public abstract class ManualLoadValidator {

    public static Boolean validateIsInteger(Object obj,Integer row, Integer column, List<String> errors){

        try{
            Object objParam = new DecimalFormat("#").format(obj);
            Integer.parseInt(objParam.toString());
        }catch(Exception e){
            errors.add("Invalid Data [Number required (No decimals)] Row: "+row + " Column: "+ column);
            return false;
        }
        return true;
    }

     public static Boolean validateIsLong(Object obj,Integer row, Integer column, List<String> errors){

        try{
            Object objParam = new DecimalFormat("#").format(obj);
            Long.valueOf(objParam.toString());
        }catch(Exception e){
            errors.add("Invalid Data [Number required (No decimals)] Row: "+row + " Column: "+ column);
            return false;
        }
        return true;
    }

    public static Boolean validateIsDouble(Object obj,Integer row, Integer column, List<String> errors){

        try{
            Object objParam = new DecimalFormat("#.##").format(obj);
            Double.valueOf(objParam.toString());
        }catch (Exception e){
            errors.add("Invalid Data [Number required (decimals optionals)] Row: "+row + " Column: "+ column);
            return false;
        }
        return true;
    }

    public static Boolean validateIsTime(Object obj, Integer row, Integer column, List<String> errors) {

        String s = obj.toString();

        if (s.length() != 8) {
            errors.add("Invalid Data [Time Format must be 00:00:00] Row: "+row + " Column: "+ column);
            return false;
        }

        if (!Pattern.compile("\\d\\d:\\d\\d:\\d\\d").matcher(s).find()) {
            errors.add("Invalid Data [Time Format must be 00:00:00] Row: "+row + " Column: "+ column);
            return false;
        }

        return true;
    }
}
