package com.monsanto.wms.dao.production;

import com.monsanto.wms.persistence.model.StrewRecommendation;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

/**
 * Created by IntelliJ IDEA.
 * User: MANIET
 * Date: 6/3/13
 * Time: 3:52 PM
 * To change this template use File | Settings | File Templates.
 */
@Repository
public interface StrewRecommendationDAO extends JpaRepository<StrewRecommendation, Long> {

     Page findByProductionZoneIdAndProductionCyclesIdAndHybridIdAndSourceCode(Long productionZoneId,Long productionCycleId,Long hybridId,String sourceCode,Pageable pageable);
     Page findByProductionZoneIdAndProductionCyclesIdAndSourceCode(Long productionZoneId,Long productionCycleId,String sourceCode,Pageable pageable);
     Page findByProductionZoneIdAndSourceCode(Long productionZoneId,String sourceCode,Pageable pageable);

     Page findByProductionCyclesIdAndHybridIdAndSourceCode(Long productionCycleId,Long hybridId,String sourceCode,Pageable pageable);
     Page findByProductionCyclesIdAndSourceCode(Long productionCycleId,String sourceCode,Pageable pageable);

     Page findByHybridIdAndSourceCode(Long hybrid, String sourceCode, Pageable pageable);

     Page findBySourceCode(String sourceCode, Pageable pageable);



}
