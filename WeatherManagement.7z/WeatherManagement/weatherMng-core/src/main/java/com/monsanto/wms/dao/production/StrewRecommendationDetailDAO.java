package com.monsanto.wms.dao.production;

import com.monsanto.wms.persistence.model.StrewRecommendationDetail;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: MANIET
 * Date: 6/3/13
 * Time: 3:52 PM
 * To change this template use File | Settings | File Templates.
 */
@Repository
public interface StrewRecommendationDetailDAO extends JpaRepository<StrewRecommendationDetail, Long> {

   List<StrewRecommendationDetail> findByStrewRecommendationId(Long strewRecommendationId);

}
