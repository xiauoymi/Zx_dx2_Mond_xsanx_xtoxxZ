package com.monsanto.wms.vo;

import com.monsanto.wms.util.WMSServiceUtil;
import org.codehaus.jackson.annotate.JsonProperty;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: MANIET
 * Date: 6/21/13
 * Time: 12:28 PM
 * To change this template use File | Settings | File Templates.
 */
public class RealReportStrewRecommendationVO {

    private final Integer INDEX_YEAR = 0;
    private final Integer INDEX_MONTH = 1;
    private final Integer INDEX_DAY = 2;
    private final Integer INDEX_TEMP_MIN = 3;
    private final Integer INDEX_TEMP_MAX = 4;
    private final Integer INDEX_DAILY_GDU = 5;
    private final Integer INDEX_ACUM_GDU = 6;
    private final Integer INDEX_CROPSTAGE_NAME = 7;
    private final Integer INDEX_ERROR = 8;


    private Integer year;
    private Integer month;
    private Integer day;
    private Double tempMaxF;
    private Double tempMinF;
    private Double tempMaxC;
    private Double tempMinC;
    private Double dailyGdu;
    private Double acumGdu;
    private String cropStageName;
    private String error;


    private List<RealReportStrewRecommendationVO> items;

    public RealReportStrewRecommendationVO() {
    }

    public RealReportStrewRecommendationVO(List objects) {
        items = new ArrayList<RealReportStrewRecommendationVO>();

        for (Object currentObject : objects) {
            Object[] currentItem = (Object[]) currentObject;
                items.add(new RealReportStrewRecommendationVO(
                    Integer.parseInt(String.valueOf(currentItem[INDEX_YEAR])),
                    Integer.parseInt(String.valueOf(currentItem[INDEX_MONTH])),
                    Integer.parseInt(String.valueOf(currentItem[INDEX_DAY])),
                    Double.parseDouble(String.valueOf(currentItem[INDEX_TEMP_MIN])),
                    Double.parseDouble(String.valueOf(currentItem[INDEX_TEMP_MAX])),
                    Double.parseDouble(String.valueOf(currentItem[INDEX_DAILY_GDU])),
                    Double.parseDouble(String.valueOf(currentItem[INDEX_ACUM_GDU])),
                    String.valueOf(currentItem[INDEX_CROPSTAGE_NAME]),
                    currentItem[INDEX_ERROR] != null ? (String.valueOf(currentItem[INDEX_ERROR])) : ""));
        }
    }

    public RealReportStrewRecommendationVO(Integer year,Integer month, Integer day, Double tempMax, Double tempMin, Double dailyGdu, Double acumGdu, String cropStageName, String error) {
        this.year = year;
        this.month = month;
        this.day = day;
        this.tempMaxC = tempMax;
        this.tempMinC = tempMin;
        this.dailyGdu = dailyGdu;
        this.acumGdu = acumGdu;
        this.cropStageName = cropStageName;
        this.error = error;
    }

    @JsonProperty
    public Integer getMonth() {
        return month;
    }

    public void setMonth(Integer month) {
        this.month = month;
    }

    @JsonProperty
    public Integer getDay() {
        return day;
    }

    public void setDay(Integer day) {
        this.day = day;
    }

    public Double getTempMinF() {
        if (tempMinC != null) {
            this.tempMinF = WMSServiceUtil.celsiusToFahrenheit(this.tempMinC);
        }
        return tempMinF;
    }

    public void setTempMinF(Double tempMinF) {
        this.tempMinF = tempMinF;
    }

    public Double getTempMaxF() {
        if(tempMaxC!=null){
            this.tempMaxF = WMSServiceUtil.celsiusToFahrenheit(this.tempMaxC);
        }
        return tempMaxF;
    }

    public void setTempMaxF(Double tempMaxF) {
        this.tempMaxF = tempMaxF;
    }

    public Double getTempMinC(){
        return tempMinC;
    }

    public void setTempMinC(Double tempMinC) {
        this.tempMinC = tempMinC;
    }

    public Double getTempMaxC() {
        return tempMaxC;
    }

    public void setTempMaxC(Double tempMaxC) {
        this.tempMaxC = tempMaxC;
    }

    @JsonProperty
    public Double getDailyGdu() {
        return dailyGdu;
    }

    public void setDailyGdu(Double dailyGdu) {
        this.dailyGdu = dailyGdu;
    }

    @JsonProperty
    public Double getAcumGdu() {
        return acumGdu;
    }

    public void setAcumGdu(Double acumGdu) {
        this.acumGdu = acumGdu;
    }

    @JsonProperty
    public String getCropStageName() {
        return cropStageName;
    }

    public void setCropStageName(String cropStageName) {
        this.cropStageName = cropStageName;
    }

    @JsonProperty
    public String getError() {
        return error;
    }

    public void setError(String error) {
        this.error = error;
    }

    @JsonProperty
    public List<RealReportStrewRecommendationVO> getItems() {
        return items;
    }

    public void setItems(List<RealReportStrewRecommendationVO> items) {
        this.items = items;
    }

     @JsonProperty
    public Integer getYear() {
        return year;
    }

    public void setYear(Integer year) {
        this.year = year;
    }
}
