package com.monsanto.wms.service.security;

import com.monsanto.wms.persistence.model.Area;
import com.monsanto.wms.persistence.model.Roles;
import com.monsanto.wms.persistence.model.User;
import com.monsanto.wms.persistence.model.UserSystemPrivileges;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.Collection;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: MANIET
 * Date: 6/3/13
 * Time: 3:51 PM
 * To change this template use File | Settings | File Templates.
 */
public interface UserSystemPrivilegesService {

    Page<UserSystemPrivileges> search(String userId, Long areaId, Long rolId,Boolean active, Pageable pageable);
    UserSystemPrivileges save(UserSystemPrivileges userSystemPrivileges);
    UserSystemPrivileges findById(Long id);
    void delete(Long id);
    Collection<Area> loadCollectionAreas();
    Collection<Roles> loadCollectionRoles(Long areaId);
    Collection<User> loadCollectionUser(String userId);

    List<UserSystemPrivileges> findByUserId(String userId);

    public List<UserSystemPrivileges> getMailDistributionListByArea(Long areaId);
}
