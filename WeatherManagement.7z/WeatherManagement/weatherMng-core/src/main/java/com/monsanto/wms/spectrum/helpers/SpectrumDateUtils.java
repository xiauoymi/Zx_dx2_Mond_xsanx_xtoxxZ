package com.monsanto.wms.spectrum.helpers;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

/**
 * Created with IntelliJ IDEA.
 * User: MANIET
 * Date: 10/22/13
 * Time: 2:02 PM
 * To change this template use File | Settings | File Templates.
 */
public class SpectrumDateUtils {

    public static final int MONTH_OFFSET = 1;
    public static final int DAY = 2;
    public static final int MONTH = 1;
    public static final int YEAR = 0;

    public static Date getDayBeforeOfCurrentDate() throws ParseException {
        Calendar c = Calendar.getInstance();
        c.add(Calendar.DAY_OF_MONTH,-1);
        String currentDate = c.get(Calendar.YEAR) + "-" + (c.get(Calendar.MONTH)+ MONTH_OFFSET) + "-" + c.get(Calendar.DAY_OF_MONTH);
        return spectrumFormatDate(currentDate);
    }

    public static Date spectrumFormatDate(String strDate) throws ParseException {
        return new SimpleDateFormat("yyyy-MM-dd").parse(strDate);
    }

    public static String getDayBeforeOfCurrentDateAsString() throws ParseException {
        Date d = getDayBeforeOfCurrentDate();
        return new SimpleDateFormat("yyyy-MM-dd").format(d);
    }

    public static Date formatCurrentFileDate(String currentFileDate) throws ParseException,ArrayIndexOutOfBoundsException {
        String[] a = currentFileDate.split(" ");
        String[] b = a[0].replaceAll("-","/").split("/");

        if(b[DAY].length()<2){b[DAY]="0"+b[DAY];}
        if(b[MONTH].length()<2){b[MONTH]="0"+b[MONTH];}

        return SpectrumDateUtils.spectrumFormatDate(b[YEAR]+"-"+b[MONTH]+"-"+b[DAY]);
    }

    public static Integer getDayOfRegistryTime(String registryTime){
        if(registryTime.length()>=10)
           return Integer.parseInt(registryTime.substring(8,10));
        else{
            Calendar currentDateTime = Calendar.getInstance();
            return currentDateTime.get(Calendar.DAY_OF_MONTH);
        }
    }
    public static Integer getMonthOfRegistryTime(String registryTime){
        if(registryTime.length()>=10)
            return Integer.parseInt(registryTime.substring(5,7));
        else{
            Calendar currentDateTime = Calendar.getInstance();
            return currentDateTime.get(Calendar.MONTH) + 1;
        }
    }
    public static Integer getYearOfRegistryTime(String registryTime){
        if(registryTime.length()>=10)
            return Integer.parseInt(registryTime.substring(0,4));
        else{
            Calendar currentDateTime = Calendar.getInstance();
            return currentDateTime.get(Calendar.YEAR);
        }
    }

}
