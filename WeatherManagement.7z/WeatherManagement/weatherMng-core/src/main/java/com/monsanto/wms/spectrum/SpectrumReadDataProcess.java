package com.monsanto.wms.spectrum;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.io.InputStreamReader;
import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: MANIET
 * Date: 10/12/13
 * Time: 8:04 AM
 * To change this template use File | Settings | File Templates.
 */

 public class SpectrumReadDataProcess {
    private static final Logger log = LoggerFactory.getLogger(SpectrumReadDataProcess.class);

    public List<String[]> startReading(SpectrumRemoteFileReader remoteFileReader, Boolean onDemand) throws IOException {
       InputStreamReader inputStreamReader = remoteFileReader.getInputStreamReader(onDemand);
      //InputStream inputStream = new ClassPathResource("spectrumTestFile.csv").getInputStream();
       //InputStreamReader inputStreamReader = new InputStreamReader(inputStream);

       List<String[]> rawSpectrumStationList = SpectrumBufferReader.toList(inputStreamReader, 1, ";");
           if(!rawSpectrumStationList.isEmpty() && !onDemand){
               remoteFileReader.validateExistenceDataFromPreviousDay(rawSpectrumStationList);
           }
           return rawSpectrumStationList;
    }
}