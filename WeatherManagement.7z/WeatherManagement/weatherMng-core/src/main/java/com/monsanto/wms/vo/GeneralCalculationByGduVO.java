package com.monsanto.wms.vo;

import com.monsanto.wms.util.WMSServiceUtil;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: MANIET
 * Date: 6/21/13
 * Time: 12:28 PM
 * To change this template use File | Settings | File Templates.
 */
public class GeneralCalculationByGduVO {

    private final Integer INDEX_TEMP_MAX = 0;
    private final Integer INDEX_TEMP_MIN = 1;
    private final Integer INDEX_NU_DAY = 2;
    private final Integer INDEX_MONTH = 3;
    private final Integer INDEX_REAL_GDU = 4;
    private final Integer INDEX_ERROR = 5;

    private Double tempMinF;
    private Double tempMaxF;
    private Double tempMinC;
    private Double tempMaxC;

    private Integer day;
    private Integer month;
    private Double realGDU;
    private List<GeneralCalculationByGduVO> items;

    private String error;

    public GeneralCalculationByGduVO() {
        this.tempMaxF = 0.0;
        this.tempMinF = 0.0;
        this.day = 0;
        this.month = 0;
        this.realGDU = 0.0;
        items = new ArrayList<GeneralCalculationByGduVO>();
        error ="";
    }

    public GeneralCalculationByGduVO(List objects) {
        items = new ArrayList<GeneralCalculationByGduVO>();

        for(Object currentObject : objects){
          Object[] currentItem = (Object[])currentObject;
          items.add(new GeneralCalculationByGduVO(Double.parseDouble(String.valueOf(currentItem[INDEX_TEMP_MAX])),
                  Double.parseDouble(String.valueOf(currentItem[INDEX_TEMP_MIN])),
                  Integer.parseInt(String.valueOf(currentItem[INDEX_NU_DAY])),
                  Integer.parseInt(String.valueOf(currentItem[INDEX_MONTH])),
                  Double.parseDouble(String.valueOf(currentItem[INDEX_REAL_GDU])),
                  currentItem[INDEX_ERROR]!=null ? (String.valueOf(currentItem[INDEX_ERROR])) : ""));
        }

    }

    public GeneralCalculationByGduVO(Double tempMax, Double tempMin, Integer day, Integer month, Double realGDU,String error) {
        this.tempMinC = tempMin;
        this.tempMaxC = tempMax;
        this.day = day;
        this.month = month;
        this.realGDU = realGDU;
        this.error = error;
    }

    public Double getTempMinF() {
         if(tempMinC!=null){
            this.tempMinF = WMSServiceUtil.celsiusToFahrenheit(this.tempMinC);
        }
        return tempMinF;
    }

    public void setTempMinF(Double tempMinF) {
        this.tempMinF = tempMinF;
    }

    public Double getTempMaxF() {
         if(tempMaxC!=null){
            this.tempMaxF = WMSServiceUtil.celsiusToFahrenheit(this.tempMaxC);
        }
        return tempMaxF;
    }

    public void setTempMaxF(Double tempMaxF) {
        this.tempMaxF = tempMaxF;
    }

    public Double getTempMinC(){
        return tempMinC;
    }

    public void setTempMinC(Double tempMinC) {
        this.tempMinC = tempMinC;
    }

    public Double getTempMaxC() {
        return tempMaxC;
    }

    public void setTempMaxC(Double tempMaxC) {
        this.tempMaxC = tempMaxC;
    }

    public Integer getDay() {
        return day;
    }

    public void setDay(Integer day) {
        this.day = day;
    }

    public Integer getMonth() {
        return month;
    }

    public void setMonth(Integer month) {
        this.month = month;
    }

    public Double getRealGDU() {
        return realGDU;
    }

    public void setRealGDU(Double realGDU) {
        this.realGDU = realGDU;
    }

    public List<GeneralCalculationByGduVO> getItems() {
        return items;
    }

    public void setItems(List<GeneralCalculationByGduVO> items) {
        this.items = items;
    }

    public String getError() {
        if(error==null) error = "";
        return error;
    }

    public void setError(String error) {
        this.error = error;
    }
}
