package com.monsanto.wms.service.production;

import java.text.ParseException;
import java.util.Date;
import java.util.List;

/**
 * Created by GFRAN1 on 10/29/2014.
 */
public interface SpectrumMeteorologicalStationManualLoadService  {
    Long importDataToStaging(Long metStationId, List<String[]> dataLoaderStagingStringList, Date startDate, Date endDate) throws ParseException;
}
