package com.monsanto.wms.service.security.impl;

import com.monsanto.wms.dao.security.AreasDAO;
import com.monsanto.wms.dao.security.RolesDAO;
import com.monsanto.wms.dao.security.UserDAO;
import com.monsanto.wms.dao.security.UserSystemPrivilegesDAO;
import com.monsanto.wms.exceptions.SystemSecurityException;
import com.monsanto.wms.persistence.model.Area;
import com.monsanto.wms.persistence.model.Roles;
import com.monsanto.wms.persistence.model.User;
import com.monsanto.wms.persistence.model.UserSystemPrivileges;
import com.monsanto.wms.service.security.UserSystemPrivilegesService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collection;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: MANIET
 * Date: 6/3/13
 * Time: 3:51 PM
 * To change this template use File | Settings | File Templates.
 */
@Service(value = "userSystemPrivilegesService")
public class UserSystemPrivilegesServiceImpl implements UserSystemPrivilegesService {

    private UserSystemPrivilegesDAO userSystemPrivilegesDAO;
    private RolesDAO rolesDAO;
    private AreasDAO areasDAO;
    private UserDAO userDAO;

    @Autowired
    public UserSystemPrivilegesServiceImpl(UserSystemPrivilegesDAO userSystemPrivilegesDAO, RolesDAO rolesDAO,AreasDAO areasDAO,UserDAO userDAO) {
        this.userSystemPrivilegesDAO = userSystemPrivilegesDAO;
        this.rolesDAO = rolesDAO;
        this.areasDAO = areasDAO;
        this.userDAO = userDAO;

    }

    @Override
    public Page<UserSystemPrivileges> search(String userId, Long areaId, Long roleId,Boolean active, Pageable pageable){
        String userIdParam = "%"+(userId!=null ? userId.toUpperCase() : userId)+"%";

        if(areaId.intValue()>0 && roleId.intValue()<0){
            return userSystemPrivilegesDAO.findByUserIdLikeAndRoleAreaIdAndUserActive(userIdParam, areaId, active, pageable);
        }else if(areaId.intValue()<0 && roleId.intValue()>0){
            return userSystemPrivilegesDAO.findByUserIdLikeAndRoleIdAndUserActive(userIdParam, roleId, active, pageable);
        }else if(areaId.intValue()>0 && roleId.intValue()>0){
            return  userSystemPrivilegesDAO.findByUserIdLikeAndRoleAreaIdAndRoleIdAndUserActive(userIdParam, areaId, roleId, active, pageable);
        }else{
            return userSystemPrivilegesDAO.findByUserIdLikeAndUserActive(userIdParam, active, pageable);
        }
    }

     @Override
    public UserSystemPrivileges findById(Long id) {
        return userSystemPrivilegesDAO.findOne(id);
    }

    @Override
    public void delete(Long id) {
        userSystemPrivilegesDAO.delete(id);
    }


    @Transactional
    @Override
    public UserSystemPrivileges save(UserSystemPrivileges userSystemPrivileges) {
        List<UserSystemPrivileges> ls = userSystemPrivilegesDAO.findByUserIdAndRoleAreaId(userSystemPrivileges.getUser().getId(),
                                                                                          userSystemPrivileges.getRole().getArea().getId());

        if(!ls.isEmpty() && userSystemPrivileges.getId()==null){
            throw new SystemSecurityException("The user id can only have one privilege per area");
        }

        return userSystemPrivilegesDAO.saveAndFlush(userSystemPrivileges);
    }

    @Override
    public Collection<Area> loadCollectionAreas() {
        return areasDAO.findByActiveTrueOrderByDescriptionAsc();
    }

    @Override
    public Collection<Roles> loadCollectionRoles(Long areaId) {
        return rolesDAO.findByAreaIdAndActiveTrueOrderByDescriptionAsc(areaId);
    }

    @Override
    public Collection<User> loadCollectionUser(String userId) {
        String userIdParam = "%"+(userId!=null ? userId.toUpperCase() : userId)+"%";
        return userDAO.findByActiveTrueAndIdLikeOrderByNameAsc(userIdParam);
    }

    @Override
    public List<UserSystemPrivileges> findByUserId(String userId) {
        return userSystemPrivilegesDAO.findByUserId(userId);
    }


    @Override
    public List<UserSystemPrivileges> getMailDistributionListByArea(Long areaId) {
        return userSystemPrivilegesDAO.findByRoleAreaIdAndUserSendNotificationTrue(areaId);
    }
}
