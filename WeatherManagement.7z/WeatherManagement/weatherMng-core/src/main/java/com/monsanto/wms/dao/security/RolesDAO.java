package com.monsanto.wms.dao.security;

import com.monsanto.wms.persistence.model.Roles;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: MANIET
 * Date: 6/3/13
 * Time: 3:52 PM
 * To change this template use File | Settings | File Templates.
 */
@Repository
public interface RolesDAO extends JpaRepository<Roles, Long> {
     Collection<Roles> findByAreaIdAndActiveTrueOrderByDescriptionAsc(Long areaId);

}
