package com.monsanto.wms.service.catalog.impl;

import com.monsanto.wms.dao.catalog.BaseTemperatureDAO;
import com.monsanto.wms.persistence.model.BaseTemperature;
import com.monsanto.wms.service.catalog.BaseTemperatureService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.ArrayList;

/**
 * Created by IntelliJ IDEA.
 * User: MANIET
 * Date: 6/3/13
 * Time: 3:51 PM
 * To change this template use File | Settings | File Templates.
 */
@Service
public final class BaseTemperatureServiceImpl implements BaseTemperatureService {

    private BaseTemperatureDAO baseTemperatureDAO;

    @Autowired
    public BaseTemperatureServiceImpl(BaseTemperatureDAO baseTemperatureDAO) {
        this.baseTemperatureDAO = baseTemperatureDAO;
    }

    @Override
    public Page<BaseTemperature> search(Long cropId, Long cropTypeId, String tempMin,String tempMax, Boolean active, Pageable pageable) {

        if(cropTypeId!=null && cropId!=null){
             if(cropTypeId>0 && cropId>0){
                return baseTemperatureDAO.findByCropTypeIdAndCropIdAndTempminLikeAndTempmaxLikeAndActive(cropTypeId, cropId, "%" + tempMin + "%", "%" + tempMax + "%", active, pageable);
             }else if(cropTypeId>0 && cropId<0){
                return baseTemperatureDAO.findByCropTypeIdAndTempminLikeAndTempmaxLikeAndActive(cropTypeId,"%"+tempMin+"%","%"+tempMax+"%",active,pageable);
            }else if(cropTypeId<0 && cropId>0){
                return baseTemperatureDAO.findByCropIdAndTempminLikeAndTempmaxLikeAndActive(cropId, "%" + tempMin + "%", "%" + tempMax + "%", active, pageable);
            }else{
                 return baseTemperatureDAO.findByActive(active,pageable);
             }
        }

        return new PageImpl<BaseTemperature>(new ArrayList<BaseTemperature>());
    }

     @Override
    public BaseTemperature findById(Long id) {
        return baseTemperatureDAO.findOne(id);
    }

    @Override
    public void delete(Long id) {
        baseTemperatureDAO.delete(id);
    }

    @Override
    public BaseTemperature save(BaseTemperature baseTemperature) {
        return baseTemperatureDAO.saveAndFlush(baseTemperature);
    }
}