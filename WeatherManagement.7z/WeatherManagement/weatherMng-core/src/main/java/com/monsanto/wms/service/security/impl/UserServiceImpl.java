package com.monsanto.wms.service.security.impl;

import com.monsanto.wms.dao.ldap.LdapUserDAO;
import com.monsanto.wms.dao.security.*;
import com.monsanto.wms.persistence.model.User;
import com.monsanto.wms.service.security.UserService;
import com.monsanto.wms.vo.LdapUserVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: MANIET
 * Date: 6/3/13
 * Time: 3:51 PM
 * To change this template use File | Settings | File Templates.
 */
@Service
public class UserServiceImpl implements  UserService{

    private UserDAO userDAO;
    private LdapUserDAO ldapUserDAO;

    @Autowired
    public UserServiceImpl(UserDAO userDAO,LdapUserDAO ldapUserDAO) {
        this.userDAO = userDAO;
        this.ldapUserDAO = ldapUserDAO;
    }

    @Override
    public Page<User> search(String userId, String name, String email,Boolean active,Pageable pageable){
        String userIdParam = "%" + (userId!=null ? userId.toUpperCase() : userId)+"%";
        String nameParam = "%" + (name!=null ? name.toUpperCase() : name)+"%";
        String emailParam = "%" + (email!=null ? email.toUpperCase() : email)+"%";
        return userDAO.findByIdLikeAndNameLikeAndEmailLikeAndActive(userIdParam, nameParam, emailParam, active,pageable);
    }

    @Override
    public Boolean authenticated(String userId, String password) {
        return ldapUserDAO.authenticated(userId,password);
    }

    @Override
    public User findById(String id) {
        return userDAO.findOne(id);
    }

    @Override
    public void delete(String id) {
        userDAO.delete(id);
    }

    @Override
    public Collection<LdapUserVO> findLdapUserByIdLike(String userId) {
        return ldapUserDAO.findByIdLike(userId);
    }

    @Transactional
    @Override
    public User save(User user) {

        return userDAO.saveAndFlush(user);
    }

}
