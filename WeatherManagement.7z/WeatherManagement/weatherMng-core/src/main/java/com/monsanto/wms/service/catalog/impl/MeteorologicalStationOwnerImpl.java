package com.monsanto.wms.service.catalog.impl;

import com.monsanto.wms.dao.catalog.MeteorologicStationOwnerDAO;
import com.monsanto.wms.persistence.model.MeteorologicalStationOwner;
import com.monsanto.wms.service.catalog.MeteorologicStationOwnerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: MANIET
 * Date: 6/3/13
 * Time: 3:51 PM
 * To change this template use File | Settings | File Templates.
 */
@Service
public final class MeteorologicalStationOwnerImpl implements MeteorologicStationOwnerService {

    private MeteorologicStationOwnerDAO meteorologicStationOwnerDAO;

    @Autowired
    public MeteorologicalStationOwnerImpl(MeteorologicStationOwnerDAO meteorologicStationOwnerDAO) {
        this.meteorologicStationOwnerDAO = meteorologicStationOwnerDAO;
    }

    @Override
    public Page<MeteorologicalStationOwner> search(String description, String shortDescription, Long areaId,Boolean active,Pageable pageable) {
        String descriptionParam = "%"+(description!=null ? description.toUpperCase() : description)+"%";
        String shortDescriptionParam = "%"+ (shortDescription!=null ? shortDescription.toUpperCase() : shortDescription)+ "%";

        if(areaId<0)
            return meteorologicStationOwnerDAO.findByDescriptionLikeAndShortDescriptionLikeAndActive(descriptionParam,shortDescriptionParam,active,pageable);
        else
            return meteorologicStationOwnerDAO.findByAreaIdAndDescriptionLikeAndShortDescriptionLikeAndActive(areaId,descriptionParam,shortDescriptionParam,active,pageable);
    }

     @Override
    public MeteorologicalStationOwner findById(Long id) {
        return meteorologicStationOwnerDAO.findOne(id);
    }

    @Override
    public void delete(Long id) {
        meteorologicStationOwnerDAO.delete(id);
    }

    @Override
    public Collection<MeteorologicalStationOwner> loadCollection() {
        return meteorologicStationOwnerDAO.findByActiveTrueOrderByDescriptionAsc();
    }

    @Override
    public MeteorologicalStationOwner save(MeteorologicalStationOwner meteorologicalStationOwner) {
        return meteorologicStationOwnerDAO.saveAndFlush(meteorologicalStationOwner);
    }



}
