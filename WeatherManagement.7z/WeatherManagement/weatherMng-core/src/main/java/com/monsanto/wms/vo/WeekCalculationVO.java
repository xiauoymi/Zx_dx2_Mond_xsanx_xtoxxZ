package com.monsanto.wms.vo;

import com.monsanto.wms.util.WMSServiceUtil;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: MANIET
 * Date: 6/21/13
 * Time: 12:28 PM
 * To change this template use File | Settings | File Templates.
 */
public class WeekCalculationVO {

    private final Integer INDEX_CURRENT_WEEK = 0;
    private final Integer INDEX_TEMP_MAX = 1;
    private final Integer INDEX_TEMP_MIN = 2;
    private final Integer INDEX_WEEK_NUM = 3;
    private final Integer INDEX_MONTH_NUM = 4;
    private final Integer INDEX_ERROR = 5;

    private Integer currentWeek;
    private Double tempMaxF;
    private Double tempMinF;
    private Double tempMaxC;
    private Double tempMinC;
    private Integer nuWeek;
    private Integer nuMonth;
    private String error;

    private List<WeekCalculationVO> items;

    public WeekCalculationVO() {
        this.currentWeek = 0;
        this.tempMaxF = 0.0;
        this.tempMinF = 0.0;
        this.nuWeek = 0;
        this.nuMonth = 0;
        this.error ="";
    }

    public WeekCalculationVO(List objects) {
        items = new ArrayList<WeekCalculationVO>();

        for(Object currentObject : objects){
          Object[] currentItem = (Object[])currentObject;
          items.add(new WeekCalculationVO(
                  Integer.parseInt(String.valueOf(currentItem[INDEX_CURRENT_WEEK])),
                  Double.parseDouble(String.valueOf(currentItem[INDEX_TEMP_MAX])),
                  Double.parseDouble(String.valueOf(currentItem[INDEX_TEMP_MIN])),
                  Integer.parseInt(String.valueOf(currentItem[INDEX_WEEK_NUM])),
                  Integer.parseInt(String.valueOf(currentItem[INDEX_MONTH_NUM])),
                  currentItem[INDEX_ERROR]!=null ? (String.valueOf(currentItem[INDEX_ERROR])) : ""));
        }
    }

    public WeekCalculationVO(Integer currentWeek, Double tempMax,Double tempMin, Integer nuWeek,Integer nuMonth,String error) {
        this.currentWeek = currentWeek;
        this.tempMaxC = tempMax;
        this.tempMinC = tempMin;
        this.nuWeek = nuWeek;
        this.nuMonth = nuMonth;
        this.error = error;
    }

    public Integer getCurrentWeek() {
        return currentWeek;
    }

    public void setCurrentWeek(Integer currentWeek) {
        this.currentWeek = currentWeek;
    }

   public Double getTempMinF() {
        if(tempMinC!=null){
            this.tempMinF = WMSServiceUtil.celsiusToFahrenheit(this.tempMinC);
        }
        return tempMinF;
    }

    public void setTempMinF(Double tempMinF) {
        this.tempMinF = tempMinF;
    }

    public Double getTempMaxF() {
        if (tempMaxC != null) {
            this.tempMaxF = WMSServiceUtil.celsiusToFahrenheit(this.tempMaxC);
        }
        return tempMaxF;
    }

    public void setTempMaxF(Double tempMaxF) {
        this.tempMaxF = tempMaxF;
    }

    public Double getTempMinC(){
        return tempMinC;
    }

    public void setTempMinC(Double tempMinC) {
        this.tempMinC = tempMinC;
    }

    public Double getTempMaxC() {
        return tempMaxC;
    }

    public void setTempMaxC(Double tempMaxC) {
        this.tempMaxC = tempMaxC;
    }

    public Integer getNuMonth() {
        return nuMonth;
    }

    public void setNuMonth(Integer nuMonth) {
        this.nuMonth = nuMonth;
    }

    public String getError() {
        return error;
    }

    public void setError(String error) {
        this.error = error;
    }

    public Integer getNuWeek() {
        return nuWeek;
    }

    public void setNuWeek(Integer nuWeek) {
        this.nuWeek = nuWeek;
    }

    public List<WeekCalculationVO> getItems() {
        return items;
    }

    public void setItems(List<WeekCalculationVO> items) {
        this.items = items;
    }
}
