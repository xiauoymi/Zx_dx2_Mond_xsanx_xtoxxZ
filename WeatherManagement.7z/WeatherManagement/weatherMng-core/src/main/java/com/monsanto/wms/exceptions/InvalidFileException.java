package com.monsanto.wms.exceptions;

/**
 * Created by IntelliJ IDEA.
 * User: MANIET
 * Date: 1/3/13
 * Time: 3:02 PM
 * To change this template use File | Settings | File Templates.
 */
public class InvalidFileException extends WMSException {

    public InvalidFileException(String s) {
        super(s);
    }
}
