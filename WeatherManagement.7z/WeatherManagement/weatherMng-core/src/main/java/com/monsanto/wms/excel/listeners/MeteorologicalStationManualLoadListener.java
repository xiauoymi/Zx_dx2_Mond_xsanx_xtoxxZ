package com.monsanto.wms.excel.listeners;

import com.monsanto.wms.dao.sheduleTasks.MeteorologicalStationHistoricInfoDAO;
import com.monsanto.wms.excel.listeners.validators.ManualLoadValidator;
import com.monsanto.wms.excel.listeners.xlsRows.MeteorologicalStationManualLoadRow;
import com.monsanto.wms.excel.manager.HSSFCoreListener;
import com.monsanto.wms.excel.manager.base.WMSReadingXLSCore;
import com.monsanto.wms.excel.manager.invokers.InvokerResult;
import com.monsanto.wms.exceptions.excel.ExcelLoadErrorException;
import com.monsanto.wms.exceptions.excel.InvalidDataException;
import com.monsanto.wms.exceptions.excel.InvalidLayoutException;
import com.monsanto.wms.persistence.model.MeteorologicalStationHistoric;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;

import javax.swing.tree.RowMapper;
import java.text.DecimalFormat;
import java.util.*;


/**
 * Created by IntelliJ IDEA.
 * User: MANIET
 * Date: 1/2/13
 * Time: 10:48 AM
 * To change this template use File | Settings | File Templates.
 */
public class MeteorologicalStationManualLoadListener extends WMSReadingXLSCore {

    private static final Logger log = LoggerFactory.getLogger(MeteorologicalStationManualLoadListener.class);

    private final Integer INDEX_MET_STATION_ID = 0;
    private final Integer INDEX_DAY = 1;
    private final Integer INDEX_MONTH = 2;
    private final Integer INDEX_YEAR = 3;
    private final Integer INDEX_TEMP_MIN = 4;
    private final Integer INDEX_TEMP_MAX = 5;
    private final Integer INDEX_REGISTRY_TIME = 6;

    private MessageSource messageSource;

    private MeteorologicalStationHistoricInfoDAO meteorologicalStationHistoricInfoDAO;

    private List<String> errors;

    @Autowired
    public MeteorologicalStationManualLoadListener(MessageSource messageSource, MeteorologicalStationHistoricInfoDAO meteorologicalStationHistoricInfoDAO) {

        this.messageSource = messageSource;
        this.invokerResult = new InvokerResult();
        this.meteorologicalStationHistoricInfoDAO = meteorologicalStationHistoricInfoDAO;
        this.errors = new ArrayList<String>();
        this.COLUMNS = 7;

    }

    @Override
    protected void processColumns(int rowNumber, List<Object> row) {


        MeteorologicalStationManualLoadRow manualLoadRow = new MeteorologicalStationManualLoadRow();

        setMeteorologicalStation(row, rowNumber, manualLoadRow);
        setTempMin(row, rowNumber, manualLoadRow);
        setTempMax(row, rowNumber, manualLoadRow);
        setDay(row, rowNumber, manualLoadRow);
        setMonth(row, rowNumber, manualLoadRow);
        setYear(row, rowNumber, manualLoadRow);
        setRegistryTime(row, rowNumber, manualLoadRow);


        saveData(manualLoadRow);


        invokerResult.increment();

    }


    private void setMeteorologicalStation(List<Object> row, Integer rowNumber, MeteorologicalStationManualLoadRow manualLoadRow) {

        Object obj =row.get(INDEX_MET_STATION_ID);

        if (ManualLoadValidator.validateIsLong(obj, rowNumber, (INDEX_MET_STATION_ID + 1), errors)) {
            obj = new DecimalFormat("#").format(obj);
            manualLoadRow.setMeteorologicalStationId(Long.valueOf(obj.toString()));
        }
    }

    private void setTempMin(List<Object> row, Integer rowNumber, MeteorologicalStationManualLoadRow manualLoadRow) {
        Object obj = row.get(INDEX_TEMP_MIN);

        if (ManualLoadValidator.validateIsDouble(obj, rowNumber, (INDEX_TEMP_MIN + 1), errors)) {
            obj = new DecimalFormat("#.##").format(obj);
            manualLoadRow.setTempMin(Double.valueOf(obj.toString()));
        }
    }

    private void setTempMax(List<Object> row, Integer rowNumber, MeteorologicalStationManualLoadRow manualLoadRow) {
        Object obj = row.get(INDEX_TEMP_MAX);

        if (ManualLoadValidator.validateIsDouble(obj, rowNumber, (INDEX_TEMP_MAX + 1), errors)) {
            obj = new DecimalFormat("#.##").format(obj);
            manualLoadRow.setTempMax(Double.valueOf(obj.toString()));
        }
    }

    private void setDay(List<Object> row, Integer rowNumber, MeteorologicalStationManualLoadRow manualLoadRow) {
        Object obj = row.get(INDEX_DAY);

        if (ManualLoadValidator.validateIsInteger(obj, rowNumber, (INDEX_DAY + 1), errors)) {
            obj = new DecimalFormat("#").format(obj);
            manualLoadRow.setDay(Integer.valueOf(obj.toString()));
        }
    }

    private void setMonth(List<Object> row, Integer rowNumber, MeteorologicalStationManualLoadRow manualLoadRow) {
        Object obj = row.get(INDEX_MONTH);

        if (ManualLoadValidator.validateIsInteger(obj, rowNumber, (INDEX_MONTH + 1), errors)) {
            obj = new DecimalFormat("#").format(obj);
            manualLoadRow.setMonth(Integer.valueOf(obj.toString()));
        }
    }

    private void setYear(List<Object> row, Integer rowNumber, MeteorologicalStationManualLoadRow manualLoadRow) {
        Object obj = row.get(INDEX_YEAR);

        if (ManualLoadValidator.validateIsInteger(obj, rowNumber, (INDEX_YEAR + 1), errors)) {
            obj = new DecimalFormat("#").format(obj);
            manualLoadRow.setYear(Integer.valueOf(obj.toString()));
        }
    }

    private void setRegistryTime(List<Object> row, Integer rowNumber, MeteorologicalStationManualLoadRow manualLoadRow) {
        Object obj = row.get(INDEX_REGISTRY_TIME);

        if (ManualLoadValidator.validateIsTime(obj, rowNumber, (INDEX_REGISTRY_TIME + 1), errors)) {
            manualLoadRow.setRegistryTime(obj.toString());
        }
    }

    private void saveData(MeteorologicalStationManualLoadRow manualLoadRow) {

        if (errors.isEmpty()) {

            MeteorologicalStationHistoric model = new MeteorologicalStationHistoric(
                    manualLoadRow.getMeteorologicalStationId(),
                    manualLoadRow.getTempMin(),
                    manualLoadRow.getTempMax(),
                    manualLoadRow.getDay(),
                    manualLoadRow.getMonth(),
                    manualLoadRow.getYear(),
                    manualLoadRow.getRegistryTime()
            );


            meteorologicalStationHistoricInfoDAO.saveAndFlush(model);

        }else{
            throw new InvalidDataException(errors);
        }
    }

}
