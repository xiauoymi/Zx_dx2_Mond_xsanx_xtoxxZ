package com.monsanto.wms.dao.security;

import com.monsanto.wms.persistence.model.User;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: MANIET
 * Date: 6/3/13
 * Time: 3:52 PM
 * To change this template use File | Settings | File Templates.
 */
@Repository
public interface UserDAO extends JpaRepository<User, String> {
     Collection<User> findByActiveTrueAndIdLikeOrderByNameAsc(String userId);
     Page<User> findByIdLikeAndNameLikeAndEmailLikeAndActive(String userId, String name,String email,Boolean active,Pageable pageable);

}
