package com.monsanto.wms.service.sheduleTasks.impl;

import com.monsanto.wms.dao.sheduleTasks.ScheduleErrorDAO;
import com.monsanto.wms.persistence.model.ScheduleErrorLog;
import com.monsanto.wms.service.sheduleTasks.ScheduleErrorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * Created with IntelliJ IDEA.
 * User: MANIET
 * Date: 10/16/13
 * Time: 8:29 AM
 * To change this template use File | Settings | File Templates.
 */
@Service(value = "scheduleErrorService")
public class ScheduleErrorServiceImpl implements ScheduleErrorService {

    private ScheduleErrorDAO dao;

    @Autowired
    public ScheduleErrorServiceImpl(ScheduleErrorDAO dao) {
        this.dao = dao;
    }

    @Override
    public ScheduleErrorLog saveErrorLog(ScheduleErrorLog errorLog) {
        return dao.save(errorLog);
    }
}
