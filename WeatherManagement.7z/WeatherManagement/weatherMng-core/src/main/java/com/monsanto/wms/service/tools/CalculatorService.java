package com.monsanto.wms.service.tools;

import com.monsanto.wms.persistence.model.BaseTemperature;
import com.monsanto.wms.persistence.model.MeteorologicalStationHistoric;
import com.monsanto.wms.vo.*;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.Date;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: MANIET
 * Date: 6/3/13
 * Time: 3:51 PM
 * To change this template use File | Settings | File Templates.
 */
public interface CalculatorService {

    GeneralCalculationByGduVO getGeneralCalculationByGDU(Integer startYear,Integer endYear,Integer day,Integer month,Long meteorologicalStationId,Double value,Double tempMin,Double tempMax,String cropName);
    GeneralCalculationByDayVO getGeneralCalculationByDay(Integer startYear,Integer endYear,Integer day,Integer month,Long meteorologicalStationId,Integer value,Double tempMin, Double tempMax,String cropName);
    List<WeekCalculationVO> getWeeklyCalculationByGDU(Integer startYear,Integer endYear,Integer month,Long meteorologicalStationId,Double value,Double tempMin,Double tempMax,String cropName);
    List<WeekCalculationVO> getWeeklyCalculationByDay(Integer startYear,Integer endYear,Integer month,Long meteorologicalStationId, Integer value,String cropName);
    List<UnderZeroCalculationVO> getUnderZeroCalculation(Integer year,Integer month,Long meteorologicalStationId);
    PeriodToGDUsVO getPeriodToGDU(Integer startYear,Integer endYear,Integer startMonth,Integer startDay, Integer endMonth, Integer endDay,Long meteorologicalStationId,Double tempMin,Double tempMax,String cropName);


}
