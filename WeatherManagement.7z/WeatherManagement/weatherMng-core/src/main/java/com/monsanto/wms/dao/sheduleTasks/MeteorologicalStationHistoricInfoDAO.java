package com.monsanto.wms.dao.sheduleTasks;

import com.monsanto.wms.persistence.model.MeteorologicalStationHistoric;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: MANIET
 * Date: 6/3/13
 * Time: 3:52 PM
 * To change this template use File | Settings | File Templates.
 */
@Repository
public interface MeteorologicalStationHistoricInfoDAO extends JpaRepository<MeteorologicalStationHistoric, Long> {

    List<MeteorologicalStationHistoric> findByMeteorologicalStationIdAndDayOfTheMonthAndMonthAndYear(Long metStationId,Integer day, Integer month,Integer year);
    Page<MeteorologicalStationHistoric> findByMeteorologicalStationIdAndDayOfTheMonthAndMonthAndYear(Long metStationId,Integer day, Integer month,Integer year,Pageable pageable);
    Page<MeteorologicalStationHistoric> findByMeteorologicalStationIdAndYear(Long metStationId,Integer year,Pageable pageable);
    Page<MeteorologicalStationHistoric> findByMeteorologicalStationIdAndMonthAndYear(Long metStationId, Integer month,Integer year,Pageable pageable);
    Page  findByMeteorologicalStationIdAndDayOfTheMonthBetweenAndMonthBetweenAndYear(Long metStationId,Integer startDay, Integer endDay, Integer startMonth,Integer endMonth,Integer year,Pageable pageable);


}
