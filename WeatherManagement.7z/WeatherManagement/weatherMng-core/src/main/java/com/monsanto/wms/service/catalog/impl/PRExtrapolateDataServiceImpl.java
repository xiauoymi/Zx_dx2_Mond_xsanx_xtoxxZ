package com.monsanto.wms.service.catalog.impl;

import com.monsanto.wms.dao.oracle.OracleFxDAO;
import com.monsanto.wms.service.catalog.PRExtrapolateDataService;
import com.monsanto.wms.vo.ExtrapolatedDataHistoricVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;


/**
 * Created with IntelliJ IDEA.
 * User: GFRAN1
 * Date: 7/21/14
 * Time: 12:38 PM
 * To change this template use File | Settings | File Templates.
 */
@Service
public class PRExtrapolateDataServiceImpl implements PRExtrapolateDataService{

    public static final String FILL_DATA_GAPS = "fillDataGaps";
    private OracleFxDAO<Object> oracleFxDAO;


    @Autowired
    public PRExtrapolateDataServiceImpl(OracleFxDAO<Object> oracleFxDAO) {

        this.oracleFxDAO = oracleFxDAO;
    }

    @Override

    public String fillEmptyDays(Long meteorologicalStationId, Date startDate, Date endDate, Integer daysToFill) {
        List rs= oracleFxDAO.executeFunction(FILL_DATA_GAPS,meteorologicalStationId,startDate,endDate,daysToFill);
        return rs.get(0) !=null?rs.get(0).toString():"";
    }


    public String getExtrapolatedDataProfile(Long meteorologicalStationId, Date startDate, Date endDate) {
        ExtrapolatedDataHistoricVO rs= new ExtrapolatedDataHistoricVO(oracleFxDAO.executeFunction("getExtrapolatedDataProfile",meteorologicalStationId,startDate,endDate));
        ExtrapolatedDataHistoricVO extrapolatedDataHistoricVO =rs.getItems().get(0) ;

        if (extrapolatedDataHistoricVO.getExtrapolatedMeasureCount().equals("0") && extrapolatedDataHistoricVO.getMeteorologicalMeasureCount().equals("0")){
            return "";
        }
        return getMessage(extrapolatedDataHistoricVO);

    }

    private String getMessage(ExtrapolatedDataHistoricVO extrapolatedDataHistoricVO) {
        return "Are you sure to fill Gaps? For this period there are Natural Data: "+extrapolatedDataHistoricVO.getMeteorologicalMeasureCount()+ "Extrapolated Data:"+extrapolatedDataHistoricVO.getExtrapolatedMeasureCount();
    }
}
