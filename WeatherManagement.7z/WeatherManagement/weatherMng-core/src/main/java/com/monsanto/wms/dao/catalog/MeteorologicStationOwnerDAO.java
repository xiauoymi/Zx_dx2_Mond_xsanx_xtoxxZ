package com.monsanto.wms.dao.catalog;

import com.monsanto.wms.persistence.model.MeteorologicalStationOwner;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: MANIET
 * Date: 6/3/13
 * Time: 3:52 PM
 * To change this template use File | Settings | File Templates.
 */
@Repository
public interface MeteorologicStationOwnerDAO extends JpaRepository<MeteorologicalStationOwner, Long> {
     Page findByDescriptionLikeAndShortDescriptionLikeAndActive(String description, String shortDescription,Boolean active, Pageable pageable);
     Page findByAreaIdAndDescriptionLikeAndShortDescriptionLikeAndActive(Long areaId,String description, String shortDescription,Boolean active, Pageable pageable);
     Collection<MeteorologicalStationOwner> findByActiveTrueOrderByDescriptionAsc();
}
