package com.monsanto.wms.service.production.impl;

import com.monsanto.wms.dao.oracle.OracleFxDAO;
import com.monsanto.wms.dao.production.StrewRecommendationDAO;
import com.monsanto.wms.dao.production.StrewRecommendationDetailDAO;
import com.monsanto.wms.exceptions.WMSException;
import com.monsanto.wms.persistence.model.StrewRecommendation;
import com.monsanto.wms.persistence.model.StrewRecommendationDetail;
import com.monsanto.wms.service.production.StrewRecommendationService;
import com.monsanto.wms.vo.RealReportStrewRecommendationVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: MANIET
 * Date: 6/3/13
 * Time: 3:51 PM
 * To change this template use File | Settings | File Templates.
 */
@Service
public final class StrewRecommendationServiceImpl implements StrewRecommendationService {

    private StrewRecommendationDAO strewRecommendationDAO;
    private StrewRecommendationDetailDAO strewRecommendationDetailDAO;
    private OracleFxDAO<Object> oracleFxDAO;

    @Autowired
    public StrewRecommendationServiceImpl(StrewRecommendationDAO strewRecommendationDAO,StrewRecommendationDetailDAO strewRecommendationDetailDAO,OracleFxDAO<Object> oracleFxDAO) {
        this.strewRecommendationDAO = strewRecommendationDAO;
        this.strewRecommendationDetailDAO = strewRecommendationDetailDAO;
        this.oracleFxDAO = oracleFxDAO;
    }

    @Override
    public Page<StrewRecommendation> search(Long productionZoneId, Long productionCycleId, Long hybridId, String sourceCode, Pageable pageable) {

        Page<StrewRecommendation> page = new PageImpl<StrewRecommendation>(new ArrayList<StrewRecommendation>());
        if(validateInputs(productionZoneId,productionCycleId,hybridId)){
             if(productionZoneId>0L && productionCycleId>0L && hybridId>0L){
                page = strewRecommendationDAO.findByProductionZoneIdAndProductionCyclesIdAndHybridIdAndSourceCode(productionZoneId,productionCycleId,hybridId,sourceCode,pageable);
            }else if(productionZoneId>0L && productionCycleId>0L){
                page = strewRecommendationDAO.findByProductionZoneIdAndProductionCyclesIdAndSourceCode(productionZoneId,productionCycleId,sourceCode,pageable);
            }else if(productionZoneId>0L){
                page = strewRecommendationDAO.findByProductionZoneIdAndSourceCode(productionZoneId,sourceCode,pageable);
            }else if(productionCycleId>0L && hybridId>0L){
                 page = strewRecommendationDAO.findByProductionCyclesIdAndHybridIdAndSourceCode(productionCycleId,hybridId,sourceCode,pageable);
            }else if(productionCycleId>0L){
               page = strewRecommendationDAO.findByProductionCyclesIdAndSourceCode(productionCycleId,sourceCode,pageable);
            }else if(hybridId>0L){
                page = strewRecommendationDAO.findByHybridIdAndSourceCode(hybridId,sourceCode,pageable);
            }else{
                page = strewRecommendationDAO.findBySourceCode(sourceCode,pageable);
            }
        }
        return  page;
    }

    private Boolean validateInputs(Long productionZoneId,Long productionCycleId, Long hybridId){
        if(productionZoneId== null){ return false;  }
        else if(productionCycleId== null){ return false;}
        else if(hybridId== null){ return false; }

        return true;


    }

    @Transactional
    @Override
    public StrewRecommendation save(StrewRecommendation strewRecommendation) {
        return strewRecommendationDAO.saveAndFlush(strewRecommendation);
    }

    @Override
    public void saveDetail(List<StrewRecommendationDetail> detail) {
        cleanDetail(detail);
        executeSaveDetail(detail);
    }

    @Transactional
    private void executeSaveDetail(List<StrewRecommendationDetail> detail){
        for(StrewRecommendationDetail currentItem : detail){
           strewRecommendationDetailDAO.save(currentItem);
        }
    }

    @Transactional
    private void cleanDetail(List<StrewRecommendationDetail> detail){
         if(!detail.isEmpty()){
            this.deleteDetail(detail.get(0).getStrewRecommendation().getId());
        }
    }

    @Transactional
    @Override
    public StrewRecommendation findById(Long id) {
        return strewRecommendationDAO.findOne(id);
    }

    @Transactional
    @Override
    public void delete(Long id) {
        this.deleteDetail(id);
        strewRecommendationDAO.delete(id);
    }

    @Transactional
    @Override
    public void deleteDetail(Long strewRecommendationId) {
        List<StrewRecommendationDetail> lsDetails = strewRecommendationDetailDAO.findByStrewRecommendationId(strewRecommendationId);

        for(StrewRecommendationDetail currentItem : lsDetails){
            strewRecommendationDetailDAO.delete(new StrewRecommendationDetail(currentItem.getId()));
        }
    }

    @Transactional
    @Override
    public List<RealReportStrewRecommendationVO> getRealReport(Integer startYear, Integer endYear, Integer day, Integer month, Long meteorologicalStationId, Double tempMin, Double tempMax, String cropStagesGDUs,String cropName) {

        List<RealReportStrewRecommendationVO> ls = new ArrayList<RealReportStrewRecommendationVO>();
        if (validateRealReportInputs(startYear, endYear, day, month, meteorologicalStationId, tempMin, tempMax, cropStagesGDUs)) {
            RealReportStrewRecommendationVO rs = new RealReportStrewRecommendationVO(oracleFxDAO.executeFunction("getRealReport", startYear, endYear, day, month, meteorologicalStationId, tempMin, tempMax, cropStagesGDUs,cropName));
            if (rs.getItems().get(0).getError().length() > 0) {
                throw new WMSException(rs.getItems().get(0).getError());
            }

            ls = rs.getItems();
        }

        return ls;
    }

    private Boolean validateRealReportInputs(Integer startYear, Integer endYear, Integer day, Integer month, Long meteorologicalStationId,Double tempMin, Double tempMax,String cropStagesGDUs){
        if(startYear==null || startYear<0L){ return false; }
        else if(endYear==null || endYear<0L){ return false;  }
        else if(day==null || day<0L){ return false; }
        else if(month==null || month<0L){ return false;   }
        else if(meteorologicalStationId==null || meteorologicalStationId<0L) {return false; }
        else if(tempMin==null){ return false;}
        else if(tempMax==null){ return false; }
        else if(cropStagesGDUs==null || cropStagesGDUs.equals("")){ return false; }

        return true;

    }
}
