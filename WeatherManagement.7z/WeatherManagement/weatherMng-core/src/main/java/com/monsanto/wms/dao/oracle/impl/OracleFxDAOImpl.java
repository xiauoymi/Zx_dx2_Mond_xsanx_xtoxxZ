package com.monsanto.wms.dao.oracle.impl;

import com.monsanto.wms.dao.oracle.OracleFxDAO;
import com.monsanto.wms.exceptions.oracle.EntityManagerException;
import com.monsanto.wms.exceptions.oracle.NamedQueryException;
import com.monsanto.wms.exceptions.oracle.ParameterException;
import org.springframework.stereotype.Component;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.PersistenceUnit;
import javax.persistence.Query;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: MANIET
 * Date: 6/19/13
 * Time: 10:24 AM
 * To change this template use File | Settings | File Templates.
 */
@Component
public class OracleFxDAOImpl<T> implements OracleFxDAO {

    @PersistenceUnit(unitName = "WMS_PU")
    private EntityManagerFactory entityManagerFactory;



    @Override
    public List executeFunction(String namedQuery, Object... parameters) {

        EntityManager entityManager = entityManagerFactory.createEntityManager();

       validateData(entityManager, namedQuery, parameters);

       Query query = createQuery(entityManager, namedQuery, parameters);

       List<T> ls = execute(query);

       closeConnection(entityManager);

       return ls;
    }

    private synchronized List<T> execute(Query query){
       return (ArrayList<T>) query.getResultList();
    }


    private void validateData(EntityManager entityManager,String namedQuery,Object... parameters){

        validateEntityManager(entityManager);
        validateNamedQuery(namedQuery);
        validateParameters(parameters);

    }

    private void validateParameters(Object... params){
        if(params==null){
            throw new ParameterException("The parameters are in invalid [Null]");
        }
    }

    private void validateNamedQuery(String namedQuery){
        if(namedQuery==null || namedQuery.length()<=0){
            throw new NamedQueryException("The function (named query) is invalid [Null or Length 0]");
        }
    }

    private void validateEntityManager(EntityManager entityManager){
        if(entityManager==null){
            throw new EntityManagerException("The connection is invalid [EntityManager closed or null]");
        }
    }

    private void closeConnection(EntityManager entityManager) {
        if (entityManager.isOpen()) {
            entityManager.clear();
            entityManager.close();
        }
    }

    private Query createQuery(EntityManager entityManager, String namedQuery, Object... parameters) {
        Query query = entityManager.createNamedQuery(namedQuery);
        int index = 1;
        for (Object currentItem : parameters) {
            query.setParameter(index++, currentItem);
        }

        return query;
    }

    public Object createQuerySingleResult(String namedQuery) {
        EntityManager entityManager = entityManagerFactory.createEntityManager();

        Query query = entityManager.createNativeQuery(namedQuery);
       Object object=  query.getSingleResult() ;
        return object;
    }
}
