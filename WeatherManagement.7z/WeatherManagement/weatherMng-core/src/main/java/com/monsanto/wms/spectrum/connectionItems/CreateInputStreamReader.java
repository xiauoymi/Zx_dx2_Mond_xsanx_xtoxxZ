package com.monsanto.wms.spectrum.connectionItems;

import java.io.IOException;
import java.io.InputStreamReader;

/**
 * Created by IntelliJ IDEA.
 * User: MANIET
 * Date: 7/31/13
 * Time: 8:43 AM
 * To change this template use File | Settings | File Templates.
 */
public  class CreateInputStreamReader {

    private InputStreamReader inputStreamReader;
    private CreateURLConnection createURLConnection;
    private Boolean isValidStreamReader;
    private String error;

    public CreateInputStreamReader(CreateURLConnection createURLConnection){
        setCreateURLConnection(createURLConnection);
        setValidStreamReader(false);
        initInputStreamReader();
    }

    private void initInputStreamReader() {

        if (getCreateURLConnection().getValidURLConnection()) {
            try {
                setInputStreamReader(new InputStreamReader(getCreateURLConnection().getUrlConnection().getInputStream()));
                setValidStreamReader(true);
            } catch (IOException e) {
                e.printStackTrace();
                this.error = e.getMessage();
                setInputStreamReader(null);
            }
        }else{
            this.error = "Invalid URL connection";
        }

    }

    public InputStreamReader getInputStreamReader() {
        initInputStreamReader();
        return inputStreamReader;
    }

    public void setInputStreamReader(InputStreamReader inputStreamReader) {
        this.inputStreamReader = inputStreamReader;
    }

    public CreateURLConnection getCreateURLConnection() {
        return createURLConnection;
    }

    public void setCreateURLConnection(CreateURLConnection createURLConnection) {
        this.createURLConnection = createURLConnection;
    }

    public Boolean getValidStreamReader() {
        return isValidStreamReader;
    }

    public void setValidStreamReader(Boolean validStreamReader) {
        isValidStreamReader = validStreamReader;
    }

    public String getError() {
        return error;
    }

}
