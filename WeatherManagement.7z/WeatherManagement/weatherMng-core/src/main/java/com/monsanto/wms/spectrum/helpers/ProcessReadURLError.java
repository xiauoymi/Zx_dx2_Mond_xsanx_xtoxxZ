package com.monsanto.wms.spectrum.helpers;

import com.monsanto.wms.exceptions.davisSchedule.DavisSpectrumScheduleException;
import com.monsanto.wms.persistence.model.MeteorologicalStation;
import com.monsanto.wms.persistence.model.UserSystemPrivileges;
import com.monsanto.wms.service.mail.MailService;
import com.monsanto.wms.service.security.UserSystemPrivilegesService;

import java.util.Date;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: MANIET
 * Date: 9/10/13
 * Time: 7:37 AM
 * To change this template use File | Settings | File Templates.
 */
public class ProcessReadURLError {

    private MailService mailService;
    private UserSystemPrivilegesService userSystemPrivilegesService;

    private String errorMessage;
    private String subjectForMail;
    private String mailTemplate;
    private String urlStr;

    private MeteorologicalStation meteorologicalStation;

    public ProcessReadURLError(MailService mailService, UserSystemPrivilegesService userSystemPrivilegesService, MeteorologicalStation meteorologicalStation, String urlStr) {
        this.mailService = mailService;
        this.userSystemPrivilegesService = userSystemPrivilegesService;
        this.mailTemplate = "generalMailTemplate.ftl";
        this.urlStr = urlStr;
        this.meteorologicalStation = meteorologicalStation;

        this.subjectForMail = "URGENT: Meteorological Station Failing ["+ meteorologicalStation.getOwner().getDescription()+ " - "+meteorologicalStation.getDescription()+"]";

        initErrorMessage();
    }

    public void sendErrorToDistributionList(Exception e, int stationType) {
        String eStr = "";

        if(e!=null && e.getCause()!=null){eStr = e.getCause().getMessage();}
        else if(e!=null &&  e.getMessage()!=null){eStr = e.getMessage();}

        errorMessage += new DavisSpectrumScheduleException(eStr,stationType).getCustomizedMessage();
        List<UserSystemPrivileges> lsUser = userSystemPrivilegesService.getMailDistributionListByArea(meteorologicalStation.getOwner().getArea().getId());

        if(!validateResponsibleInNotificaficationActiveList(lsUser) && meteorologicalStation.getResponsible()!= null){
            UserSystemPrivileges userSystemPrivileges = new UserSystemPrivileges();
            userSystemPrivileges.setUser(meteorologicalStation.getResponsible());
            lsUser.add(userSystemPrivileges);
        }
        for (UserSystemPrivileges currentUser : lsUser) {
            sendMail(currentUser);
        }
    }


    private Boolean validateResponsibleInNotificaficationActiveList(List<UserSystemPrivileges> lsUser){

        for (UserSystemPrivileges currentUser : lsUser) {
            if (currentUser.getUser()!=null && meteorologicalStation.getResponsible()!=null) {
                return currentUser.getUser().getId().equals(meteorologicalStation.getResponsible().getId());
            }
        }
        return false;
    }

    public void sendErrorToDistributionList(String message, int stationType) {
        errorMessage += message;
        List<UserSystemPrivileges> lsUser = userSystemPrivilegesService.getMailDistributionListByArea(meteorologicalStation.getOwner().getArea().getId());
        if(!validateResponsibleInNotificaficationActiveList(lsUser)){
            UserSystemPrivileges userSystemPrivileges = new UserSystemPrivileges();
            userSystemPrivileges.setUser(meteorologicalStation.getResponsible());
            lsUser.add(userSystemPrivileges);
        }
        for (UserSystemPrivileges currentUser : lsUser) {
            sendMail(currentUser);
        }
    }

    private void sendMail(UserSystemPrivileges currentUser) {
        if (currentUser.getUser().getEmail() != null && !currentUser.getUser().getEmail().trim().equals("")) {
            mailService.sendMailMessage(subjectForMail, currentUser.getUser().getEmail(), errorMessage, mailTemplate);
        }
    }

/*
    private void sendMail(User currentUser) {
        if (currentUser.getEmail() != null && !currentUser.getEmail().trim().equals("")) {
           mailService.sendMailMessage(subjectForMail, currentUser.getEmail(), errorMessage, mailTemplate);
        }
    }*/

    private void initErrorMessage() {
        this.errorMessage = "Details:<br>"
                + " <b>- Date: </b>" + new Date().toString() + "<br>"
                + " <b>- Type: </b>"+meteorologicalStation.getStationType().getDescription()+" <br>"
                + " <b>- Meteorological Station Name: </b>" + meteorologicalStation.getDescription() + "<br>"
                + " <b>- Meteorological Station Owner: </b>" + meteorologicalStation.getOwner().getDescription() + "<br>"
                + " <b>- Meteorological User: </b>" + meteorologicalStation.getUserName() + "<br>"
                + " <b>- Meteorological URL: </b>" + urlStr + "<br>"
                + " <b>- Error Description: </b>";

    }

}
