package com.monsanto.wms.service.catalog;

import com.monsanto.wms.persistence.model.DataLoaderStaging;
import com.monsanto.wms.persistence.model.ErrorLogView;
import com.monsanto.wms.persistence.model.MeteorologicalStationHistoric;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.io.IOException;
import java.sql.SQLException;
import java.util.Date;
import java.util.List;

/**
 * Created by GFRAN1 on 9/2/2014.
 */
public interface ReloadDataService {

    public List<MeteorologicalStationHistoric> getMeteorologicalHistoricData(Long metStationId,Integer day, Integer month,Integer year);

    public Long reloadMeteorologicalData(Long metStationId, Date date) throws IOException, SQLException;
    public Page<ErrorLogView> getErrorsDataLoader(Long batchId, Pageable page);
    public Long executeReloadProcess(Date startDate, Date endDate, Long currentStationId, List<DataLoaderStaging> stagingList);
    public void saveStagingData(List<DataLoaderStaging> dataLoaderStagingList, Long batchId);

}
