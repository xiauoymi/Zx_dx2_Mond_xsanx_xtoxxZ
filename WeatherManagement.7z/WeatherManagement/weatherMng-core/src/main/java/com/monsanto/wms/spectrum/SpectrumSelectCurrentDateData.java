package com.monsanto.wms.spectrum;

import com.monsanto.wms.persistence.model.DataLoaderStaging;
import com.monsanto.wms.persistence.model.MeteorologicalStation;
import com.monsanto.wms.persistence.model.MeteorologicalStationHistoric;
import com.monsanto.wms.spectrum.helpers.SpectrumDateUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: MANIET
 * Date: 10/11/13
 * Time: 9:27 AM
 * To change this template use File | Settings | File Templates.
 */
public class SpectrumSelectCurrentDateData extends SpectrumMeteorologicalStationLayout {


    private final List<String[]> bufferedMeteorologicalStationData;
    private final MeteorologicalStation station;
    private List<SpectrumValidatedMeteorologicalStationHistory> stationHistoricList;

    private static final Logger log = LoggerFactory.getLogger(SpectrumSelectCurrentDateData.class);

    public SpectrumSelectCurrentDateData(List<String[]> bufferedMeteorologicalStationData, MeteorologicalStation station) {
        this.bufferedMeteorologicalStationData = bufferedMeteorologicalStationData;
        this.station = station;
        this.stationHistoricList = new ArrayList<SpectrumValidatedMeteorologicalStationHistory>();
    }

    public List<SpectrumValidatedMeteorologicalStationHistory> getData() {
        return createMeteorologicalStationHistoryList(bufferedMeteorologicalStationData, station);
    }

    private List<SpectrumValidatedMeteorologicalStationHistory> createMeteorologicalStationHistoryList(List<String[]> bufferedMeteorologicalStationData, MeteorologicalStation station) {
        for (String[] currentBufferRegistry : bufferedMeteorologicalStationData) {
            SpectrumValidatedMeteorologicalStationHistory validatedMeteorologicalStationHistory = new SpectrumValidatedMeteorologicalStationHistory();
            transformBufferRegistryToValidatedMetStationHistory(station, currentBufferRegistry, validatedMeteorologicalStationHistory);

            if (validatedMeteorologicalStationHistory.getValidator().isCurrentDate()) {
                stationHistoricList.add(validatedMeteorologicalStationHistory);
            }

        }
        return stationHistoricList;
    }

    private void transformBufferRegistryToValidatedMetStationHistory(MeteorologicalStation station, String[] currentBufferRegistry, SpectrumValidatedMeteorologicalStationHistory validatedMeteorologicalStationHistory) {

        if (validateBufferSizeAndCurrentDate(validatedMeteorologicalStationHistory, currentBufferRegistry)) {
            MeteorologicalStationHistoric meteorologicalStationHistoric = new MeteorologicalStationHistoric(station,
                    SpectrumDateUtils.getDayOfRegistryTime(currentBufferRegistry[SPECTRUM_DATE_TIME]),
                    SpectrumDateUtils.getMonthOfRegistryTime(currentBufferRegistry[SPECTRUM_DATE_TIME]),
                    SpectrumDateUtils.getYearOfRegistryTime(currentBufferRegistry[SPECTRUM_DATE_TIME]),
                    validatedMeteorologicalStationHistory.getValidator().validateRegistryTime(currentBufferRegistry[SPECTRUM_DATE_TIME]),
                    validatedMeteorologicalStationHistory.getValidator().validateNumericData(currentBufferRegistry[SPECTRUM_TEMP_MIN], "TEM_MIN"),
                    currentBufferRegistry[SPECTRUM_DATE_TIME_TEMP_MIN],
                    validatedMeteorologicalStationHistory.getValidator().validateNumericData(currentBufferRegistry[SPECTRUM_TEMP_MAX], "TEMP_MAX"),
                    currentBufferRegistry[SPECTRUM_DATE_TIME_TEMP_MAX],
                    null,
                    null,
                    null,
                    null,
                    validatedMeteorologicalStationHistory.getValidator().validateNumericData(currentBufferRegistry[SPECTRUM_RAINFALL], "RAIN_FALL"),
                    validatedMeteorologicalStationHistory.getValidator().validateNumericData(currentBufferRegistry[SPECTRUM_SOLAR_RADIATION], "SOLAR_RADIATION"),
                    null,
                    validatedMeteorologicalStationHistory.getValidator().validateNumericData(currentBufferRegistry[SPECTRUM_WIND_SPEED], "WIND_SPEED"),
                    null,
                    validatedMeteorologicalStationHistory.getValidator().validateNumericData(currentBufferRegistry[SPECTRUM_DEWPOINT_MAX], "SPECTRUM_DEWPOINT_MAX"),
                    validatedMeteorologicalStationHistory.getValidator().validateRegistryTime(currentBufferRegistry[SPECTRUM_DATE_TIME_DEWPOINT_MAX]),
                    validatedMeteorologicalStationHistory.getValidator().validateNumericData(currentBufferRegistry[SPECTRUM_DEWPOINT_MIN], "SPECTRUM_DEWPOINT_MIN"),
                    validatedMeteorologicalStationHistory.getValidator().validateRegistryTime(currentBufferRegistry[SPECTRUM_DATE_TIME_DEWPOINT_MIN]),
                    null,
                    null,
                    null,
                    validatedMeteorologicalStationHistory.getValidator().validateNumericData(currentBufferRegistry[SPECTRUM_HEAT_INDEX_MAX], "HEAT_INDEX_MAX"),
                    validatedMeteorologicalStationHistory.getValidator().validateRegistryTime(currentBufferRegistry[SPECTRUM_DATE_TIME_HEAT_INDEX_MAX]),
                    null,
                    null,
                    validatedMeteorologicalStationHistory.getValidator().validateNumericData(currentBufferRegistry[SPECTRUM_HUMIDITY_MAX], "HUMIDITY_MAX"),
                    validatedMeteorologicalStationHistory.getValidator().validateRegistryTime(currentBufferRegistry[SPECTRUM_DATE_TIME_HUMIDITY_MAX]),
                    validatedMeteorologicalStationHistory.getValidator().validateNumericData(currentBufferRegistry[SPECTRUM_HUMIDITY_MIN], "HUMIDITY_MIN"),
                    validatedMeteorologicalStationHistory.getValidator().validateRegistryTime(currentBufferRegistry[SPECTRUM_DATE_TIME_HUMIDTY_MIN]),
                    null,
                    null,
                    null,
                    null,
                    null);

            validatedMeteorologicalStationHistory.setStationHistoric(meteorologicalStationHistoric);

        } else {
            validatedMeteorologicalStationHistory.setStationHistoric(new MeteorologicalStationHistoric(station));
        }

    }
    private boolean validateBufferSizeAndCurrentDate(SpectrumValidatedMeteorologicalStationHistory validatedMeteorologicalStationHistory, String[] currentBufferRegistry) {
        return validatedMeteorologicalStationHistory.getValidator().validateCurrentRegistryWithCurrentDate(currentBufferRegistry[SPECTRUM_DATE_TIME]) && validatedMeteorologicalStationHistory.getValidator().validateBufferRegistrySize(currentBufferRegistry);
    }

    public List<DataLoaderStaging> getDataLoaderStagingList(MeteorologicalStation station, List<String[]> bufferedMeteorologicalStationData){
        List<DataLoaderStaging> dataLoaderStagingList = new ArrayList<DataLoaderStaging>();
        for (String[] currentBufferRegistry : bufferedMeteorologicalStationData) {
            DataLoaderStaging dataLoaderStaging = transformBufferRegistryToDataLoaderStaging(station,currentBufferRegistry);
            dataLoaderStagingList.add(dataLoaderStaging);
        }
        return dataLoaderStagingList;

    }

    private DataLoaderStaging transformBufferRegistryToDataLoaderStaging(MeteorologicalStation station, String[] currentBufferRegistry) {

        DataLoaderStaging dataLoaderStaging = new DataLoaderStaging();
        dataLoaderStaging.setDateTime(validateIndex(currentBufferRegistry,SpectrumLayoutAbstract.DATE_TIME));
        dataLoaderStaging.setTemperature(validateIndex(currentBufferRegistry,SpectrumLayoutAbstract.TEMPERATURE));
        dataLoaderStaging.setTemperatureMin(validateIndex(currentBufferRegistry,SpectrumLayoutAbstract.TEMP_MIN));
        dataLoaderStaging.setDateTimeTempMin(validateIndex(currentBufferRegistry,SpectrumLayoutAbstract.DATE_TIME_TEMP_MIN));
        dataLoaderStaging.setTempMax(validateIndex(currentBufferRegistry,SpectrumLayoutAbstract.TEMP_MAX));
        dataLoaderStaging.setDateTimeTempMax(validateIndex(currentBufferRegistry,SpectrumLayoutAbstract.DATE_TIME_TEMP_MAX));
        dataLoaderStaging.setHumidity(validateIndex(currentBufferRegistry,SpectrumLayoutAbstract.HUMIDITY));
        dataLoaderStaging.setHumidityMin(validateIndex(currentBufferRegistry,SpectrumLayoutAbstract.HUMIDITY_MIN));
        dataLoaderStaging.setDateTimeHumidityMin(validateIndex(currentBufferRegistry,SpectrumLayoutAbstract.DATE_TIME_HUMIDTY_MIN));
        dataLoaderStaging.setHumidityMax(validateIndex(currentBufferRegistry,SpectrumLayoutAbstract.HUMIDITY_MAX));
        dataLoaderStaging.setDateTimeHumidityMax(validateIndex(currentBufferRegistry,SpectrumLayoutAbstract.DATE_TIME_HUMIDITY_MAX));
        dataLoaderStaging.setSolarRadiation(validateIndex(currentBufferRegistry,SpectrumLayoutAbstract.SOLAR_RADIATION));
        dataLoaderStaging.setRainFall(validateIndex(currentBufferRegistry,SpectrumLayoutAbstract.RAINFALL));
        dataLoaderStaging.setWindDirection(validateIndex(currentBufferRegistry,SpectrumLayoutAbstract.WIND_DIRECTION));
        dataLoaderStaging.setWindGust(validateIndex(currentBufferRegistry,SpectrumLayoutAbstract.WIND_GUST));
        dataLoaderStaging.setWindSpeed(validateIndex(currentBufferRegistry,SpectrumLayoutAbstract.WIND_SPEED));
        dataLoaderStaging.setDewPoint(validateIndex(currentBufferRegistry,SpectrumLayoutAbstract.DEW_POINT));
        dataLoaderStaging.setDewPointMin(validateIndex(currentBufferRegistry,SpectrumLayoutAbstract.DEWPOINT_MIN));
        dataLoaderStaging.setDateTimePointMin(validateIndex(currentBufferRegistry,SpectrumLayoutAbstract.DATE_TIME_DEWPOINT_MIN));
        dataLoaderStaging.setDewPointMax(validateIndex(currentBufferRegistry,SpectrumLayoutAbstract.DEWPOINT_MAX));
        dataLoaderStaging.setDateTimeDewPointMax(validateIndex(currentBufferRegistry,SpectrumLayoutAbstract.DATE_TIME_DEWPOINT_MAX));
        dataLoaderStaging.setHeatIndex(validateIndex(currentBufferRegistry,SpectrumLayoutAbstract.HEAT_INDEX));
        dataLoaderStaging.setHeatIndexMin(validateIndex(currentBufferRegistry,SpectrumLayoutAbstract.HEAT_INDEX_MIN));
        dataLoaderStaging.setDateTimeHeatIndexMin(validateIndex(currentBufferRegistry,SpectrumLayoutAbstract.DATE_TIME_HEAT_INDEX_MIN));
        dataLoaderStaging.setHeatIndexMax(validateIndex(currentBufferRegistry,SpectrumLayoutAbstract.HEAT_INDEX_MAX));
        dataLoaderStaging.setDateTimeHeatIndexMax(validateIndex(currentBufferRegistry,SpectrumLayoutAbstract.DATE_TIME_HEAT_INDEX_MAX));
        dataLoaderStaging.setRainFallMax(validateIndex(currentBufferRegistry,SpectrumLayoutAbstract.RAIN_FALL_MAX));
        dataLoaderStaging.setDateTimeRainFallMax(validateIndex(currentBufferRegistry,SpectrumLayoutAbstract.DATE_TIME_RAIN_FALL_MAX));

        return  dataLoaderStaging;
    }

    private String validateIndex(String[] currentBufferRegistry,int index) {
        return currentBufferRegistry.length > index ? currentBufferRegistry[index]:"";
    }
}
