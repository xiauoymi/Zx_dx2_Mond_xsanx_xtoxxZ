package com.monsanto.wms.spectrum;

import com.monsanto.wms.spectrum.helpers.ScheduleError;
import com.monsanto.wms.spectrum.helpers.SpectrumDateUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: MANIET
 * Date: 10/11/13
 * Time: 12:40 PM
 * To change this template use File | Settings | File Templates.
 */
public class SpectrumDataValidator {

    private  final int DATE_EXPECTED_LENGTH = 10;
    private  final int EXPECTED_REGISTRY_SIZE = 29;

    private  boolean incorrectRegistryFounded;
    private  boolean isCurrentDate;

    private  List<ScheduleError> errorList;

    private static final Logger log = LoggerFactory.getLogger(SpectrumDataValidator.class);

    public SpectrumDataValidator() {
        this.errorList = new ArrayList<ScheduleError>();
        this.incorrectRegistryFounded = false;
        this.isCurrentDate = false;
    }

    public boolean isAnIncorrectRegistryFounded() {
        return incorrectRegistryFounded;
    }

    public String validateRegistryTime(String currentData) {
        if(currentData.length() < DATE_EXPECTED_LENGTH){
            incorrectRegistryFounded = true;
            addError("Registry Time","Invalid length:"+currentData.length()+" Expected:"+DATE_EXPECTED_LENGTH);
        }
        return currentData;
    }

    public Double validateNumericData(String currentData,String section) {
        try{
            return Double.parseDouble(currentData);
        }catch (NumberFormatException e){
            incorrectRegistryFounded = true;
            addError(section,"Invalid numeric data:"+currentData);
            return null;
        }
    }


    public Boolean validateCurrentRegistryWithCurrentDate(String currentFileDate) {
        try {
            Date fileDate = SpectrumDateUtils.formatCurrentFileDate(currentFileDate);
            Date currentDate = SpectrumDateUtils.getDayBeforeOfCurrentDate();

            this.isCurrentDate = compareFileDateAndCurrentDate(fileDate,currentDate);
            return isCurrentDate;

        } catch (ParseException e) {
            e.printStackTrace();
            addError("Registry Date","Invalid Format:"+currentFileDate.length()+" Expected:MM/dd/yyyy");
        } catch (ArrayIndexOutOfBoundsException e) {
            addError("Registry Date","Invalid length:"+currentFileDate.length()+" Expected:10");
            e.printStackTrace();
        }
        this.incorrectRegistryFounded = true;
        return false;
    }

    public boolean validateBufferRegistrySize(String[] currentBufferRegistry) {
        if(currentBufferRegistry.length == EXPECTED_REGISTRY_SIZE){
            return true;
        }else{
            incorrectRegistryFounded = true;
            addError("Buffer Registry Size","Invalid Buffer Registry size:"+currentBufferRegistry.length+"  Expected:"+EXPECTED_REGISTRY_SIZE);
            return false;
        }
    }

    private boolean compareFileDateAndCurrentDate(Date fileDate, Date currentDate) {
        if(currentDate.compareTo(fileDate) == 0 ){
            return true;
        }
        this.incorrectRegistryFounded = true;
        return false;
    }

    public List<ScheduleError> getErrorList() {
        return errorList;
    }

    public void addError(String section,String message){
        this.incorrectRegistryFounded = true;
        this.errorList.add(new ScheduleError(section,message));
    }

    public boolean isCurrentDate() {
        return isCurrentDate;
    }

    @Override
    public String toString(){
        String errorString ="";
        for(ScheduleError currentError : errorList){
            errorString+=currentError.getSection() +" - " + currentError.getMessage() + " / ";
        }

        return errorString;
    }



}
