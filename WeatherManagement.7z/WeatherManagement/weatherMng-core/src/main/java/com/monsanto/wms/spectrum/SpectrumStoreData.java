package com.monsanto.wms.spectrum;

import com.monsanto.wms.exceptions.schedule.DatabaseDuplicatedItem;
import com.monsanto.wms.persistence.model.ScheduleErrorLog;
import com.monsanto.wms.service.catalog.MeteorologicalStationService;
import com.monsanto.wms.service.sheduleTasks.ScheduleErrorService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: MANIET
 * Date: 10/13/13
 * Time: 7:58 PM
 * To change this template use File | Settings | File Templates.
 */
public class SpectrumStoreData {

    private final MeteorologicalStationService meteorologicalStationService;
    private final ScheduleErrorService scheduleErrorService;
    private final List<SpectrumValidatedMeteorologicalStationHistory> meteorologicalStationHistoric;
    private static final Logger log = LoggerFactory.getLogger(SpectrumStoreData.class);

    public SpectrumStoreData(MeteorologicalStationService meteorologicalStationService, ScheduleErrorService scheduleErrorService, List<SpectrumValidatedMeteorologicalStationHistory> meteorologicalStationHistoric) {
        this.meteorologicalStationService = meteorologicalStationService;
        this.scheduleErrorService = scheduleErrorService;
        this.meteorologicalStationHistoric = meteorologicalStationHistoric;
    }



    public void save() {
        for (SpectrumValidatedMeteorologicalStationHistory currentItem : meteorologicalStationHistoric) {
            if (!currentItem.getValidator().isAnIncorrectRegistryFounded()) {
                if(!validateDatabaseInsertion(currentItem)){
                    break;
                }
            } else {
                validateErrorInsertion(currentItem);
            }
        }
    }

    private void validateErrorInsertion(SpectrumValidatedMeteorologicalStationHistory currentItem) {
        try{
            scheduleErrorService.saveErrorLog(new ScheduleErrorLog(currentItem.getValidator().toString(), currentItem.getStationHistoric().getMeteorologicalStation()));
        }catch(Exception e){
            e.printStackTrace();
        }
    }

    private Boolean validateDatabaseInsertion(SpectrumValidatedMeteorologicalStationHistory currentItem) {
        try{
            meteorologicalStationService.save(currentItem.getStationHistoric());
        }catch(DatabaseDuplicatedItem e){
             e.printStackTrace();
            return false;
        }catch(Exception e){
            e.printStackTrace();
            return false;
        }
        return true;
    }

}
