package com.monsanto.wms.service.catalog;

import com.monsanto.wms.persistence.model.MeteorologicalStation;
import com.monsanto.wms.persistence.model.MeteorologicalStationHistoric;
import com.monsanto.wms.persistence.model.StationType;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: MANIET
 * Date: 6/3/13
 * Time: 3:51 PM
 * To change this template use File | Settings | File Templates.
 */
public interface MeteorologicalStationService {

    Page<MeteorologicalStation> search(Long stationTypeId,String description, Boolean active, Long ownerId, Pageable pageable);

    MeteorologicalStation save(MeteorologicalStation meteorologicalStation);
    MeteorologicalStation findById(Long cropTypeId);
    void delete(Long id);
    Collection<MeteorologicalStation> loadCollection();
    Collection<MeteorologicalStation> loadCollectionByMetStationType();
    Collection<MeteorologicalStation> loadCollectionByOwner(Long owner);

    Collection<MeteorologicalStation> findByTypeStationsWithUsrPwd(Long stationType);
    Collection<MeteorologicalStation> findByTypeStationsWithUsrSerialNumber(Long stationType);

    MeteorologicalStationHistoric save(MeteorologicalStationHistoric meteorologicalStationHistoric);
    Collection<StationType> loadStationTypesCollection();
    Page<MeteorologicalStationHistoric> search(Integer day, Integer month, Integer year, Long meteorologicalStationId, Pageable pageable);


}
