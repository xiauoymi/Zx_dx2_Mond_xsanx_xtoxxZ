package com.monsanto.wms.service.catalog.impl;

import com.monsanto.wms.dao.catalog.ProductionCyclesDAO;
import com.monsanto.wms.persistence.model.ProductionCycles;
import com.monsanto.wms.service.catalog.ProductionCycleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: MANIET
 * Date: 6/3/13
 * Time: 3:51 PM
 * To change this template use File | Settings | File Templates.
 */
@Service
public final class ProductionCycleServiceImpl implements ProductionCycleService {

    private ProductionCyclesDAO productionCyclesDAO;

    @Autowired
    public ProductionCycleServiceImpl(ProductionCyclesDAO productionCyclesDAO) {
        this.productionCyclesDAO = productionCyclesDAO;
    }

    @Override
    public Page<ProductionCycles> search(String description, Boolean active,Pageable pageable) {
        String descriptionParam = "%"+(description!=null ? description.toUpperCase() : description)+"%";
        return productionCyclesDAO.findByDescriptionLikeAndActive(descriptionParam,active,pageable);
    }

     @Override
    public ProductionCycles findById(Long id) {
        return productionCyclesDAO.findOne(id);
    }

    @Override
    public void delete(Long id) {
        productionCyclesDAO.delete(id);
    }

    @Override
    public ProductionCycles save(ProductionCycles productionCycles) {
        return productionCyclesDAO.saveAndFlush(productionCycles);
    }

       @Override
    public Collection<ProductionCycles> loadCollection() {
        return productionCyclesDAO.findByActiveTrueOrderByDescriptionAsc();
    }



}
