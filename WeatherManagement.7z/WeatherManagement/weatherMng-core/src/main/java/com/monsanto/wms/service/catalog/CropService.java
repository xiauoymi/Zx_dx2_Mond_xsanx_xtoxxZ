package com.monsanto.wms.service.catalog;

import com.monsanto.wms.persistence.model.Crop;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.Collection;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: MANIET
 * Date: 6/3/13
 * Time: 3:51 PM
 * To change this template use File | Settings | File Templates.
 */
public interface CropService {

    Page<Crop> search(String description, Boolean active,Long cropType,Pageable pageable);
    Crop save(Crop crop);
    Crop findById(Long cropId);
    void delete(Long id);
    Collection<Crop> loadCollection();
    Collection<Crop> loadCollectionByParent(Long cropTypeId);
}
