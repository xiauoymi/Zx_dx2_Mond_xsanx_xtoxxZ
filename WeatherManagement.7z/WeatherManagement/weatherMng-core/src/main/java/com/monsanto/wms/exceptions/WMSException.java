package com.monsanto.wms.exceptions;

/**
 * Created by IntelliJ IDEA.
 * User: RBERN
 * Date: 17/10/12
 * Time: 04:50 PM
 * To change this template use File | Settings | File Templates.
 */
public class WMSException extends RuntimeException {



    public WMSException(String message) {
        super(message);
    }

}
