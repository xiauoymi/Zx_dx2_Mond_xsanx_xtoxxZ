package com.monsanto.wms.spectrum;

import com.monsanto.wms.service.catalog.MeteorologicalStationService;
import com.monsanto.wms.service.mail.MailService;
import com.monsanto.wms.service.security.UserSystemPrivilegesService;
import com.monsanto.wms.service.sheduleTasks.ScheduleErrorService;

import java.util.Date;
import java.util.Timer;
import java.util.TimerTask;

/**
 * Created by IntelliJ IDEA.
 * User: MANIET
 * Date: 8/1/13
 * Time: 10:44 AM
 * To change this template use File | Settings | File Templates.
 */
public class SpectrumScheduleTask {

    private Timer timer;
    // private final static int WAIT_NUMBER_OF_MINUTES_FOR_NEXT_EXECUTION=1300;      //24 horas
    private final static int VALUE_OF_A_MINUTE_IN_MILLISECONDS =  1000 * 60;
    private final static int WAIT_NUMBER_OF_MINUTES_FOR_NEXT_EXECUTION = 1440;
    private final static int TIME_MILLISECONDS =  VALUE_OF_A_MINUTE_IN_MILLISECONDS * WAIT_NUMBER_OF_MINUTES_FOR_NEXT_EXECUTION;

    private MeteorologicalStationService meteorologicalStationService;
    private MailService mailService;
    private UserSystemPrivilegesService userSystemPrivilegesService;
    private ScheduleErrorService errorService;

    private Boolean isSpectrumScheduleTaskRunning;

    public SpectrumScheduleTask(MeteorologicalStationService meteorologicalStationService, MailService mailService, UserSystemPrivilegesService userSystemPrivilegesService,ScheduleErrorService errorService) {
        this.meteorologicalStationService = meteorologicalStationService;
        this.mailService = mailService;
        this.userSystemPrivilegesService = userSystemPrivilegesService;
        this.errorService = errorService;

        isSpectrumScheduleTaskRunning = false;
    }

    public void start() {
        timer = new Timer("SPECTRUM_TIMER_TASK_OBJECT");
        timer.scheduleAtFixedRate(createSpectrumTimer(), new Date(), TIME_MILLISECONDS);
        isSpectrumScheduleTaskRunning = true;
    }

    public TimerTask createSpectrumTimer() {
        return new SpectrumTimerControl(meteorologicalStationService, mailService, userSystemPrivilegesService,errorService);
    }

    public void cancelScheduleTask() {
        timer.cancel();
        isSpectrumScheduleTaskRunning = false;
    }

    public Boolean isSpectrumScheduleTaskRunning() {
        return isSpectrumScheduleTaskRunning;
    }
}
