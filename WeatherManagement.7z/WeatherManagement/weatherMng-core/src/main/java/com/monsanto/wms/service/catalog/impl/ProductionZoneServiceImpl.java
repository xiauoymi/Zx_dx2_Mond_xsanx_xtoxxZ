package com.monsanto.wms.service.catalog.impl;

import com.monsanto.wms.dao.catalog.ProductionZoneDAO;
import com.monsanto.wms.persistence.model.ProductionZone;
import com.monsanto.wms.service.catalog.ProductionZoneService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: MANIET
 * Date: 6/3/13
 * Time: 3:51 PM
 * To change this template use File | Settings | File Templates.
 */
@Service
public final class ProductionZoneServiceImpl implements ProductionZoneService {

    private ProductionZoneDAO productionZoneDAO;

    @Autowired
    public ProductionZoneServiceImpl(ProductionZoneDAO productionZoneDAO) {
        this.productionZoneDAO = productionZoneDAO;
    }

    @Override
    public Page<ProductionZone> search(String description, Boolean active,Pageable pageable) {
        String descriptionParam = "%"+(description!=null ? description.toUpperCase() : description)+"%";
        return productionZoneDAO.findByDescriptionLikeAndActive(descriptionParam,active,pageable);
    }

     @Override
    public ProductionZone findById(Long id) {
        return productionZoneDAO.findOne(id);
    }

    @Override
    public void delete(Long id) {
        productionZoneDAO.delete(id);
    }

    @Override
    public ProductionZone save(ProductionZone productionZone) {
        return productionZoneDAO.saveAndFlush(productionZone);
    }

      @Override
    public Collection<ProductionZone> loadCollection() {
        return productionZoneDAO.findByActiveTrueOrderByDescriptionAsc();
    }



}
