package com.monsanto.wms.dao.catalog;

import com.monsanto.wms.persistence.model.DataLoaderLog;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * Created by GFRAN1 on 9/11/2014.
 */
public interface DataLoaderLogDAO extends JpaRepository<DataLoaderLog, Long> {


}
