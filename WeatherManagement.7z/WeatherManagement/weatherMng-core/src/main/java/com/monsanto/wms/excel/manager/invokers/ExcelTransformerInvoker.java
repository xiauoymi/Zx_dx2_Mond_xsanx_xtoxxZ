package com.monsanto.wms.excel.manager.invokers;

import com.monsanto.wms.excel.manager.ExcelListener;

import java.io.InputStream;

/**
 * Created by IntelliJ IDEA.
 * User: ACISS
 * Date: 3/10/12
 * Time: 01:37 PM
 * To change this template use File | Settings | File Templates.
 */
public interface ExcelTransformerInvoker {
    InvokerResult invoke(InputStream file, ExcelListener listener);
}
