package com.monsanto.wms.excel.manager;

import com.monsanto.wms.excel.manager.invokers.InvokerResult;
import org.apache.poi.hssf.eventusermodel.HSSFListener;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: MANIET
 * Date: 5/28/13
 * Time: 3:23 PM
 * To change this template use File | Settings | File Templates.
 */
public interface ExcelListener extends HSSFListener {

    void processRow(int rowNumber, List<Object> row, String sheetName);
    int getMaxColumns();
    InvokerResult getInvokerResult();


}
