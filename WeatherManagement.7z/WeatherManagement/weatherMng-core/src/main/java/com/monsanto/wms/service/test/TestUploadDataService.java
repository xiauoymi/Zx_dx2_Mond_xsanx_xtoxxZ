package com.monsanto.wms.service.test;

/**
 * Created by IntelliJ IDEA.
 * User: MANIET
 * Date: 5/29/13
 * Time: 12:31 PM
 * To change this template use File | Settings | File Templates.
 */
public interface TestUploadDataService {
    //FileLoadResultVO importData(InputStream inputStream);
}
