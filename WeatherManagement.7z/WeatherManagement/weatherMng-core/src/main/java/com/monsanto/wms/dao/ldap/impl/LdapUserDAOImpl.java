package com.monsanto.wms.dao.ldap.impl;

import com.monsanto.wms.dao.ldap.LdapUserDAO;
import com.monsanto.wms.vo.LdapUserVO;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Required;
import org.springframework.ldap.core.AttributesMapper;
import org.springframework.ldap.core.AttributesMapperCallbackHandler;
import org.springframework.ldap.core.CollectingNameClassPairCallbackHandler;
import org.springframework.ldap.core.LdapTemplate;

import javax.naming.directory.SearchControls;
import java.text.MessageFormat;
import java.util.Collection;

/**
 * Monsanto
 * Author: Luis Miguel Arteaga Rios (lmarte@monsanto.com)
 * Date: 29/11/12
 * Time: 04:32 PM
 */
public class LdapUserDAOImpl implements LdapUserDAO {

    private static final Logger logger = Logger.getLogger( LdapUserDAOImpl.class );

    private static final int COUNT_LIMIT = 5;

    private static final int TIME_LIMIT = 500;

    public final SearchControls searchControls = new SearchControls();

    private LdapTemplate ldapTemplate;

    private String searchBase;

    private String queryById;

    @Autowired
    public LdapUserDAOImpl(LdapTemplate ldapTemplate){
        this.ldapTemplate = ldapTemplate;

        searchControls.setCountLimit(COUNT_LIMIT);
        searchControls.setSearchScope(SearchControls.SUBTREE_SCOPE);
        searchControls.setTimeLimit(TIME_LIMIT);
        searchControls.setReturningAttributes( LdapUserAttributesMapper.RETURNING_ATTRIBUTES );
    }

    public Boolean authenticated(String userId, String password) {
        return this.ldapTemplate.authenticate("", "(&(objectclass=person)(!(objectclass=computer))(cn=" + userId +"))",password);
    }

    public Collection<LdapUserVO> findByIdLike( String userId ) {

        final AttributesMapper mapper = new LdapUserAttributesMapper();
        final CollectingNameClassPairCallbackHandler handler = new AttributesMapperCallbackHandler( mapper );
        final String           filter  = buildFilterLikeId( userId );

        try {

            ldapTemplate.search( searchBase, filter, searchControls, handler );
        }
        catch ( Exception e) {
            e.printStackTrace();
        }

        return handler.getList();
    }

    private String buildFilterLikeId( String userId ){
        return MessageFormat.format( queryById, userId );
    }

    @Required
    public void setSearchBase( String searchBase ){
        this.searchBase = searchBase;
    }

    @Required
    public void setQueryById(String queryById) {
        this.queryById = queryById;
    }

}
