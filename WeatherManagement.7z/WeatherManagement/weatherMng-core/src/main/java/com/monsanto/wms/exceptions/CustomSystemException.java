package com.monsanto.wms.exceptions;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: MANIET
 * Date: 6/5/13
 * Time: 2:46 PM
 * To change this template use File | Settings | File Templates.
 */
public class CustomSystemException {

    public static String[] getCustomException(String... messages){

        String[] customizedMsg = new String[messages.length];

        for(int i=0;i<messages.length;i++){
            if(messages[i].contains("NOREPREG")){
                customizedMsg[i] ="This registry is already saved in the database";
            }else if(messages[i].contains("constraint [null]")){
                customizedMsg[i] = "Some of the values are invalid, review the data and try again";
            }else if(messages[i].contains("Unknown reason")){
                customizedMsg[i] = "The operation is invalid, verify the relationship with other modules";
            }else if(messages[i].contains("save the transient instance before flushing")){
                customizedMsg[i] = "There is an invalid relationship, try again if the problem persist call your system administrator";
            }else{
                customizedMsg[i] = messages[i];
            }
        }

        return customizedMsg;

    }

}
