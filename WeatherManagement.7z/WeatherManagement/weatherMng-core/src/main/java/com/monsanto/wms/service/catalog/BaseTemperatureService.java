package com.monsanto.wms.service.catalog;

import com.monsanto.wms.persistence.model.BaseTemperature;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

/**
 * Created by IntelliJ IDEA.
 * User: MANIET
 * Date: 6/3/13
 * Time: 3:51 PM
 * To change this template use File | Settings | File Templates.
 */
public interface BaseTemperatureService {

    Page<BaseTemperature> search(Long cropId, Long cropTypeId,String tempMin,String tempMax, Boolean active, Pageable pageable);
    BaseTemperature save(BaseTemperature baseTemperature);
    BaseTemperature findById(Long id);
    void delete(Long id);
}
