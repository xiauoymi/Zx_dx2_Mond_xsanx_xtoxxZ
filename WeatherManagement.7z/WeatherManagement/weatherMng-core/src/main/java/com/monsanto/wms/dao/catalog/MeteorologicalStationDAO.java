package com.monsanto.wms.dao.catalog;

import com.monsanto.wms.persistence.model.MeteorologicalStation;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: MANIET
 * Date: 6/3/13
 * Time: 3:52 PM
 * To change this template use File | Settings | File Templates.
 */
@Repository
public interface MeteorologicalStationDAO extends JpaRepository<MeteorologicalStation, Long> {
     Page findByStationTypeIdAndDescriptionLikeAndActiveAndOwnerId(Long stationType,String description, Boolean active, Long ownerId, Pageable pageable);
     Page findByStationTypeIdAndDescriptionLikeAndActive(Long stationType,String description, Boolean active, Pageable pageable);
     Collection<MeteorologicalStation> findByActiveTrueOrderByDescriptionAsc();
     Collection<MeteorologicalStation> findByActiveTrueAndOwnerIdOrderByDescriptionAsc(Long ownerId);

     Collection<MeteorologicalStation> findByActiveTrueAndStationTypeIdAndUserNameNotNullAndPwdNotNull(Long stationType);
     Collection<MeteorologicalStation> findByActiveTrueAndStationTypeIdAndUserNameNotNullAndSerialNumberNotNull(Long stationType);
    Collection<MeteorologicalStation>  findByActiveTrueAndStationTypeIdOrderByDescriptionAsc(Long stationType);
}
