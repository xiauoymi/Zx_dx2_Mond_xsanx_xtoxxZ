package com.monsanto.wms.exceptions.excel;

import com.monsanto.wms.exceptions.BaseExcelException;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: ACISS
 * Date: 6/10/12
 * Time: 10:23 PM
 * To change this template use File | Settings | File Templates.
 */
public class InvalidLayoutException extends BaseExcelException {

     public InvalidLayoutException(String msg){
         super(msg);
     }

    public List<String> getErrorAsList(){
        List<String> ls = new ArrayList<String>();
        ls.add(this.getMessage());
        return ls;
    }

}
