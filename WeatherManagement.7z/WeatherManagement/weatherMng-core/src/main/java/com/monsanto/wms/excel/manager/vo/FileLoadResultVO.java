package com.monsanto.wms.excel.manager.vo;

/**
 * Created by IntelliJ IDEA.
 * User: MANIET
 * Date: 12/11/12
 * Time: 12:40 PM
 * To change this template use File | Settings | File Templates.
 */
public class FileLoadResultVO {

    private long insertedRows;
    private long deletedRows;
    private long updatedRows;

    public FileLoadResultVO(){
        this.deletedRows = 0;
        this.insertedRows = 0;
        this.updatedRows = 0;
    }

    public long getInsertedRows() {
        return insertedRows;
    }

    public void setInsertedRows(long insertedRows) {
        this.insertedRows = insertedRows;
    }

    public long getDeletedRows() {
        return deletedRows;
    }

    public void setDeletedRows(long deletedRows) {
        this.deletedRows = deletedRows;
    }

    public long getUpdatedRows() {
        return updatedRows;
    }

    public void setUpdatedRows(long updatedRows) {
        this.updatedRows = updatedRows;
    }
}
