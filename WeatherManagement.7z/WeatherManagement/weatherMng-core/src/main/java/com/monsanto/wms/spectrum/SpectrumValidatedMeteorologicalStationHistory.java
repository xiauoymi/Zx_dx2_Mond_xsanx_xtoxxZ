package com.monsanto.wms.spectrum;

import com.monsanto.wms.persistence.model.MeteorologicalStationHistoric;

/**
 * Created with IntelliJ IDEA.
 * User: MANIET
 * Date: 10/14/13
 * Time: 4:16 PM
 * To change this template use File | Settings | File Templates.
 */
public class SpectrumValidatedMeteorologicalStationHistory {
    MeteorologicalStationHistoric stationHistoric;
    SpectrumDataValidator validator;

    public SpectrumValidatedMeteorologicalStationHistory() {
        this.validator = new SpectrumDataValidator();
    }

    public MeteorologicalStationHistoric getStationHistoric() {
        return stationHistoric;
    }

    public SpectrumDataValidator getValidator() {
        return validator;
    }

    public void setStationHistoric(MeteorologicalStationHistoric stationHistoric) {
        this.stationHistoric = stationHistoric;
    }
}
