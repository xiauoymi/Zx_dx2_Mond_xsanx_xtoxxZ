package com.monsanto.wms.spectrum;

/**
 * Created with IntelliJ IDEA.
 * User: MANIET
 * Date: 10/11/13
 * Time: 12:51 PM
 * To change this template use File | Settings | File Templates.
 */
public class SpectrumMeteorologicalStationLayout {

    public static final int SPECTRUM_DATE_TIME = 1;
    public static final int SPECTRUM_TEMP_MIN = 3;
    public static final int SPECTRUM_DATE_TIME_TEMP_MIN = 4;
    public static final int SPECTRUM_TEMP_MAX = 5;
    public static final int SPECTRUM_DATE_TIME_TEMP_MAX = 6;

    public static final int SPECTRUM_HUMIDITY_MIN = 8;
    public static final int SPECTRUM_DATE_TIME_HUMIDTY_MIN = 9;
    public static final int SPECTRUM_HUMIDITY_MAX = 10;
    public static final int SPECTRUM_DATE_TIME_HUMIDITY_MAX = 11;
    public static final int SPECTRUM_SOLAR_RADIATION = 12;
    public static final int SPECTRUM_RAINFALL = 13;

    public static final int SPECTRUM_WIND_SPEED = 16;
    public static final int SPECTRUM_DEWPOINT_MIN = 18;
    public static final int SPECTRUM_DATE_TIME_DEWPOINT_MIN = 19;
    public static final int SPECTRUM_DEWPOINT_MAX = 20;
    public static final int SPECTRUM_DATE_TIME_DEWPOINT_MAX = 21;

    public static final int SPECTRUM_HEAT_INDEX_MAX = 25;
    public static final int SPECTRUM_DATE_TIME_HEAT_INDEX_MAX = 26;


}
