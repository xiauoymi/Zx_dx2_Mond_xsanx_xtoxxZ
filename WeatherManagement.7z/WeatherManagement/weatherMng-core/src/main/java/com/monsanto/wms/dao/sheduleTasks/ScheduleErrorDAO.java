package com.monsanto.wms.dao.sheduleTasks;

import com.monsanto.wms.persistence.model.ScheduleErrorLog;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

/**
 * Created with IntelliJ IDEA.
 * User: MANIET
 * Date: 10/16/13
 * Time: 8:30 AM
 * To change this template use File | Settings | File Templates.
 */
@Repository
public interface ScheduleErrorDAO extends JpaRepository<ScheduleErrorLog, Long> {
}
