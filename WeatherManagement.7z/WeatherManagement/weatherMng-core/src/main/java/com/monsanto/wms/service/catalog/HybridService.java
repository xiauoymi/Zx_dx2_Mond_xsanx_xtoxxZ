package com.monsanto.wms.service.catalog;

import com.monsanto.wms.persistence.model.Hybrid;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: MANIET
 * Date: 6/3/13
 * Time: 3:51 PM
 * To change this template use File | Settings | File Templates.
 */
public interface HybridService {

    Page<Hybrid> search(String description,  Long cropTypeId, Long cropId,Boolean active, Pageable pageable);
    Hybrid save(Hybrid cropType);
    Hybrid findById(Long hybrid);
    void delete(Long id);
    Collection<Hybrid> loadCollection();
    Collection<Hybrid> findDynamicList(String match,Long cropTypeId,Long cropId);


}
