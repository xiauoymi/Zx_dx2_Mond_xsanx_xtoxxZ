package com.monsanto.wms.spectrum;

import com.monsanto.wms.persistence.model.MeteorologicalStation;
import com.monsanto.wms.service.catalog.MeteorologicalStationService;
import com.monsanto.wms.service.mail.MailService;
import com.monsanto.wms.service.security.UserSystemPrivilegesService;
import com.monsanto.wms.service.sheduleTasks.ScheduleErrorService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Collection;
import java.util.Date;
import java.util.TimerTask;

/**
 * Created by IntelliJ IDEA.
 * User: MANIET
 * Date: 7/9/13
 * Time: 8:54 AM
 * To change this template use File | Settings | File Templates.
 */
public class SpectrumTimerControl extends TimerTask {


    private MeteorologicalStationService meteorologicalStationService;
    private MailService mailService;
    private UserSystemPrivilegesService userSystemPrivilegesService;
    private ScheduleErrorService errorService;

    private static final Logger log = LoggerFactory.getLogger(SpectrumTimerControl.class);

    public SpectrumTimerControl(MeteorologicalStationService meteorologicalStationService, MailService mailService, UserSystemPrivilegesService userSystemPrivilegesService,ScheduleErrorService  errorService) {
        this.meteorologicalStationService = meteorologicalStationService;
        this.mailService = mailService;
        this.userSystemPrivilegesService = userSystemPrivilegesService;
        this.errorService = errorService;
    }

    @Override
    public void run() {
        log.info("Spectrum Time Control start reading on:"+new Date());
        Collection<MeteorologicalStation> spectrumStations = getSpectrumStations();
        SpectrumRemoteFileProcess spectrumRemoteFileProcess = new SpectrumRemoteFileProcess(meteorologicalStationService,mailService,userSystemPrivilegesService,errorService);
        for(MeteorologicalStation currentStation : spectrumStations){
            spectrumRemoteFileProcess.storeHistoricRetrievedInformation(currentStation);
        }
    }

    private Collection<MeteorologicalStation> getSpectrumStations() {
        return meteorologicalStationService.findByTypeStationsWithUsrSerialNumber(MeteorologicalStation.SPECTRUM);
    }


}
