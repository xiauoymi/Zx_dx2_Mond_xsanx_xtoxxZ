package com.monsanto.wms.excel.manager;

import com.monsanto.wms.excel.manager.invokers.InvokerResult;
import com.monsanto.wms.exceptions.excel.InvalidLayoutException;
import org.apache.poi.hssf.eventusermodel.HSSFListener;
import org.apache.poi.hssf.record.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.*;

public abstract class HSSFCoreListener implements HSSFListener, ExcelListener {

    private SSTRecord sstrec;
    private List<Object> row;
    private List<String> sheetNames;
    private short currentSheetIndex;
    private int actualRow = -1;
    private boolean lastRowFlag = false;



    private Map<String,Object> extraData = new HashMap<String,Object>();
    private static final Logger log = LoggerFactory.getLogger(HSSFCoreListener.class);

    public void processRecord(Record record) {

        switch (record.getSid()) {

            case BOFRecord.sid: // start of workbook, worksheet etc. records
                handleBOFRecord((BOFRecord) record);
                break;

            case EOFRecord.sid: // end of workbook, worksheet etc. records
                handleEOF();
                break;

            case BoundSheetRecord.sid:
                BoundSheetRecord sr = (BoundSheetRecord) record;
                sheetNames.add(sr.getSheetname());
                break;

            case NumberRecord.sid:
                NumberRecord numrec = (NumberRecord) record;
                log.info("{} {} {}", new Object[]{numrec.getRow(), numrec.getColumn(), numrec.getValue()});
                addValue(numrec.getValue(), numrec.getRow(), numrec.getColumn());
                break;

            case FormulaRecord.sid: // Cell value from a formula
                FormulaRecord formula = (FormulaRecord) record;
                addValue(formula.getValue(), formula.getRow(), formula.getColumn());
                break;

            // SSTRecords store a array of unique strings used in Excel.
            case SSTRecord.sid:
                sstrec = (SSTRecord) record;
                break;

            case LabelSSTRecord.sid:
                LabelSSTRecord lrec = (LabelSSTRecord) record;
                log.info("{} {} {}", new Object[]{lrec.getRow(), lrec.getColumn(), sstrec.getString(lrec.getSSTIndex())});
                addValue(sstrec.getString(lrec.getSSTIndex()), lrec.getRow(), lrec.getColumn());
                break;

        }
    }

    private void handleEOF() {
        //Lo ideal hubiera sido capturar el EOF del workbook para ejecutar el processRow
        if (currentSheetIndex >= 0 && !lastRowFlag) {
            processRow(actualRow, row, sheetNames.get(currentSheetIndex));
            lastRowFlag = true;
        }
    }

    private void handleBOFRecord(BOFRecord bof) {
        switch (bof.getType()) {
            case BOFRecord.TYPE_WORKBOOK:
                lastRowFlag = false;
                actualRow = -1;
                currentSheetIndex = -1;
                sheetNames = new ArrayList<String>();
                break;
            case BOFRecord.TYPE_WORKSHEET:
                currentSheetIndex++;
                break;
        }
    }

    private void addValue(Object value, int rowValue, int column) {
        log.debug("row: {} column: {}", rowValue, column);
        if (rowValue != actualRow) {
            if (actualRow != -1) {
                processRow(actualRow, row, sheetNames.get(currentSheetIndex));
                row = Arrays.asList(new Object[getMaxColumns()]);
            }
            actualRow = rowValue;
        }
        if (row == null || column == 0) {
            row = Arrays.asList(new Object[getMaxColumns()]);
        }
        if (column >= getMaxColumns()) {
            throw new InvalidLayoutException("The number of columns in the spreadsheet is bigger than "+getMaxColumns());
        }
        row.set(column, value);
        log.debug("rowList: {}", row);
    }

    public abstract void processRow(int rowNumber, List<Object> row,
                                    String sheetName);


    public abstract int getMaxColumns();
    public abstract InvokerResult getInvokerResult();

}
