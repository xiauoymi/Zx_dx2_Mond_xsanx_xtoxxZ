package com.monsanto.wms.spectrum.connectionItems;

import java.net.MalformedURLException;
import java.net.URL;

/**
 * Created by IntelliJ IDEA.
 * User: MANIET
 * Date: 7/31/13
 * Time: 8:35 AM
 * To change this template use File | Settings | File Templates.
 */
public class CreateURL {

    private String urlStr;
    private URL url;
    private Boolean isValidURL;

    public CreateURL(String urlStr){
        setUrlStr(urlStr);
        setValidURL(false);
        initURL();
    }

     private void initURL() {
        try {
            setUrl(new URL(getUrlStr()));
            setValidURL(true);
        } catch (MalformedURLException e) {
            e.printStackTrace();
            setUrl(null);
        }
    }

    public String getUrlStr() {
        return urlStr;
    }

    public void setUrlStr(String urlStr) {
        this.urlStr = urlStr;
    }

    public URL getUrl() {
        return url;
    }

    public void setUrl(URL url) {
        this.url = url;
    }

    public Boolean getValidURL() {
        return isValidURL;
    }

    public void setValidURL(Boolean validURL) {
        isValidURL = validURL;
    }
}
