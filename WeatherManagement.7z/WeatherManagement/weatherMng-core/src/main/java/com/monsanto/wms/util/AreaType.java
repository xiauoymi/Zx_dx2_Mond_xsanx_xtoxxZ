package com.monsanto.wms.util;

import org.codehaus.jackson.map.annotate.JsonSerialize;

import java.text.MessageFormat;

/**
 * Monsanto
 * Author: Luis Miguel Arteaga Rios (lmarte@monsanto.com)
 * Date: 6/12/12
 * Time: 03:26 PM
 */
@JsonSerialize(using = AreaTypeSerializer.class)
public enum AreaType {
    AREA_ADMINISTRATIVE_TASKS        (1L),
    AREA_PRODUCTION_RESEARCH         (2L),
    AREA_TD                          (3L),
    AREA_FIELD_PRODUCTION            (4L);

    private final Long id;

    private AreaType(Long id){
        this.id = id;
    }

    public Long getId(){
        return id;
    }

    private static final String ERROR_MESSAGE = "No area is defined with id: {0}";

    public static AreaType lookup( Long id ){

        for( AreaType area : AreaType.values() ){
            if( area.id.equals( id ) ){
                return area;
            }
        }
        throw new IllegalArgumentException( MessageFormat.format( ERROR_MESSAGE , id ) );
    }
}
