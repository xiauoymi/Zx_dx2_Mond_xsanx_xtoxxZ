package com.monsanto.wms.exceptions.excel;

import com.monsanto.wms.exceptions.BaseExcelException;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: ACISS
 * Date: 2/10/12
 * Time: 11:05 PM
 * To change this template use File | Settings | File Templates.
 */
public class ExcelLoadErrorException extends BaseExcelException {

    public ExcelLoadErrorException(String message) {
        super(message);
    }

    public List<String> getErrorAsList() {
        List<String> ls = new ArrayList<String>();
        ls.add(this.getMessage());
        return ls;
    }

}
