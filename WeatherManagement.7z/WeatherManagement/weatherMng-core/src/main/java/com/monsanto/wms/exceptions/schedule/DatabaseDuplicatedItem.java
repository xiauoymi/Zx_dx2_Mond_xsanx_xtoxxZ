package com.monsanto.wms.exceptions.schedule;

import com.monsanto.wms.exceptions.WMSException;

/**
 * Created with IntelliJ IDEA.
 * User: MANIET
 * Date: 10/23/13
 * Time: 10:05 AM
 * To change this template use File | Settings | File Templates.
 */
public class DatabaseDuplicatedItem extends WMSException {

    public DatabaseDuplicatedItem(String message) {
        super(message);
    }
}
