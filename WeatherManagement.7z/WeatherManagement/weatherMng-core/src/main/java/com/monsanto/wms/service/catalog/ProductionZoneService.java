package com.monsanto.wms.service.catalog;

import com.monsanto.wms.persistence.model.ProductionZone;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: MANIET
 * Date: 6/3/13
 * Time: 3:51 PM
 * To change this template use File | Settings | File Templates.
 */
public interface ProductionZoneService {

    Page<ProductionZone> search(String description, Boolean active, Pageable pageable);
    ProductionZone save(ProductionZone productionZone);
    ProductionZone findById(Long id);
    void delete(Long id);
    Collection<ProductionZone> loadCollection();
}
