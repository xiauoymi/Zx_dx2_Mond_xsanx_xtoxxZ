package com.monsanto.wms.service.catalog.impl;

import com.monsanto.wms.dao.sheduleTasks.MeteorologicalStationHistoricInfoDAO;
import com.monsanto.wms.persistence.model.MeteorologicalStationHistoric;
import com.monsanto.wms.service.catalog.MeteorologicalStationHistoricService;
import com.monsanto.wms.util.WMSServiceUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.text.ParseException;
import java.util.Date;

/**
 * Created by GFRAN1 on 10/31/2014.
 */
@Service(value = "meteorologicalStationHistoricService")
public class MeteorologicalStationHistoricServiceImpl implements MeteorologicalStationHistoricService {

    private MeteorologicalStationHistoricInfoDAO meteorologicalStationHistoricInfoDAO;

    @Autowired
    public MeteorologicalStationHistoricServiceImpl(MeteorologicalStationHistoricInfoDAO meteorologicalStationHistoricInfoDAO) {
        this.meteorologicalStationHistoricInfoDAO = meteorologicalStationHistoricInfoDAO;
    }

    @Override
    public Page<MeteorologicalStationHistoric> search(Long metStationId, Date startDate,Date endDate, Pageable pageable) throws ParseException {
            return meteorologicalStationHistoricInfoDAO.findByMeteorologicalStationIdAndDayOfTheMonthBetweenAndMonthBetweenAndYear(metStationId, WMSServiceUtil.getDay(startDate),WMSServiceUtil.getDay(endDate),
                                                            WMSServiceUtil.getMonth(startDate), WMSServiceUtil.getMonth(endDate),WMSServiceUtil.getYear(startDate),pageable);
    }
}
