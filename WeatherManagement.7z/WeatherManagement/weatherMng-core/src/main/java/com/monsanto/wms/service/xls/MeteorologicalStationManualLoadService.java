package com.monsanto.wms.service.xls;

import com.monsanto.wms.excel.manager.vo.FileLoadResultVO;

import java.io.InputStream;

/**
 * Created by IntelliJ IDEA.
 * User: MANIET
 * Date: 5/29/13
 * Time: 12:31 PM
 * To change this template use File | Settings | File Templates.
 */
public interface MeteorologicalStationManualLoadService {
    FileLoadResultVO importData(InputStream inputStream, Long metStationId, Integer day, Integer month, Integer year);
}
