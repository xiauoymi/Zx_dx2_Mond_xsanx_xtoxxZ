package com.monsanto.wms.exceptions.excel;

import com.monsanto.wms.exceptions.BaseExcelException;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: ACISS
 * Date: 6/10/12
 * Time: 10:23 PM
 * To change this template use File | Settings | File Templates.
 */
public class InvalidDataException extends BaseExcelException {

    List<String> errorsAsList = new ArrayList<String>();

     public InvalidDataException(List<String> errors){
         super("");
         this.errorsAsList = errors;
     }

    public List<String> getErrorsAsList() {
        return errorsAsList;
    }

    public void setErrorsAsList(List<String> errorsAsList) {
        this.errorsAsList = errorsAsList;
    }
}
