package com.monsanto.wms.spectrum.connectionItems;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URLConnection;

/**
 * Created by IntelliJ IDEA.
 * User: MANIET
 * Date: 7/31/13
 * Time: 8:36 AM
 * To change this template use File | Settings | File Templates.
 */
public final class CreateURLConnection {

    private CreateURL createURL;
    private URLConnection urlConnection;
    private Boolean isValidURLConnection;

    public CreateURLConnection(CreateURL createURL) {
        setCreateURL(createURL);
        setValidURLConnection(false);
        initURLConnection();
    }

    private void initURLConnection() {
        try {
            if(getCreateURL().getValidURL()){
                setUrlConnection(getCreateURL().getUrl().openConnection());
                disablePageRedirection();
                setValidURLConnection(true);
            }
        } catch (IOException e) {
            e.printStackTrace();
            setUrlConnection(null);
        }

    }

    private void disablePageRedirection() {
        HttpURLConnection conn = (HttpURLConnection) urlConnection;
        conn.setInstanceFollowRedirects(false);
    }

    public URLConnection getUrlConnection() {
        initURLConnection();
        return urlConnection;
    }

    public void setUrlConnection(URLConnection urlConnection) {
        this.urlConnection = urlConnection;
    }

    public CreateURL getCreateURL() {
        return createURL;
    }

    public void setCreateURL(CreateURL createURL) {
        this.createURL = createURL;
    }

    public Boolean getValidURLConnection() {
        return isValidURLConnection;
    }

    public void setValidURLConnection(Boolean validURLConnection) {
        isValidURLConnection = validURLConnection;
    }
}
