package com.monsanto.wms.vo;

/**
 * Created by IntelliJ IDEA.
 * User: MANIET
 * Date: 8/8/13
 * Time: 4:30 PM
 * To change this template use File | Settings | File Templates.
 */
public class LoginUserVO {

    private String userName;
    private String password;
    private Boolean isIE;

    public LoginUserVO(String webData) {
        if (webData.contains("-$#$@$-")) {
            createLoginUserByOtherBrowsers(webData);
            isIE = false;
        }else{
            createLoginUserByIERequest(webData);
            isIE = true;
        }
    }

    private void createLoginUserByOtherBrowsers(String webData) {
        setUserName(webData.substring(0, webData.indexOf("-$#$@$")));
        setPassword(webData.substring(webData.indexOf("-$#$@$-") + 7, webData.length()));
    }

    private void createLoginUserByIERequest(String webData) {
        setUserName(webData);
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        if(userName!=null)  this.userName = userName.toUpperCase();
        else this.userName = userName;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public Boolean isIE() {
        return isIE;
    }

}
