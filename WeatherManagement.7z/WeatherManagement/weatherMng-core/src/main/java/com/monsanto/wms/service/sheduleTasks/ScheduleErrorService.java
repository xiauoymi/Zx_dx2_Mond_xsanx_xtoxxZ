package com.monsanto.wms.service.sheduleTasks;

import com.monsanto.wms.persistence.model.ScheduleErrorLog;

/**
 * Created with IntelliJ IDEA.
 * User: MANIET
 * Date: 10/16/13
 * Time: 8:28 AM
 * To change this template use File | Settings | File Templates.
 */
public interface ScheduleErrorService {

    ScheduleErrorLog saveErrorLog(ScheduleErrorLog errorLog);
}
