package com.monsanto.wms.spectrum;

/**
 * Created by GFRAN1 on 9/9/2014.
 */
public abstract class SpectrumLayoutAbstract {

    public static final int METEOROLOGICAL_STATION_ID=0;
     public static final int DATE_TIME =1;
    public static final int TEMPERATURE = 2;
    public static final int TEMP_MIN=3;
    public static final int DATE_TIME_TEMP_MIN=4;
    public static final int TEMP_MAX=5;
    public static final int DATE_TIME_TEMP_MAX=6;
    public static final int HUMIDITY=7;
    public static final int HUMIDITY_MIN=8;
    public static final int DATE_TIME_HUMIDTY_MIN=9;
    public static final int HUMIDITY_MAX=10;
    public static final int DATE_TIME_HUMIDITY_MAX =11;
    public static final int SOLAR_RADIATION=12;
    public static final int RAINFALL=13;
    public static final int WIND_DIRECTION=14;
    public static final int WIND_GUST=15;
    public static final int WIND_SPEED =16;
    public static final int DEW_POINT=17;
    public static final int DEWPOINT_MIN =18;
    public static final int DATE_TIME_DEWPOINT_MIN=19;
    public static final int DEWPOINT_MAX=20;
    public static final int DATE_TIME_DEWPOINT_MAX=21;
    public static final int HEAT_INDEX=22;
    public static final int HEAT_INDEX_MIN=23;
    public static final int DATE_TIME_HEAT_INDEX_MIN=24;
    public static final int HEAT_INDEX_MAX=25;
    public static final int DATE_TIME_HEAT_INDEX_MAX=26;
    public static final int RAIN_FALL_MAX=27;
    public static final int DATE_TIME_RAIN_FALL_MAX=28;


}
