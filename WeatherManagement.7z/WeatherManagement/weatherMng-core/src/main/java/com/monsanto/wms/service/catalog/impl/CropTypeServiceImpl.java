package com.monsanto.wms.service.catalog.impl;

import com.monsanto.wms.dao.catalog.CropTypeDAO;
import com.monsanto.wms.dao.oracle.OracleFxDAO;
import com.monsanto.wms.persistence.model.CropType;
import com.monsanto.wms.service.catalog.CropTypeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: MANIET
 * Date: 6/3/13
 * Time: 3:51 PM
 * To change this template use File | Settings | File Templates.
 */
@Service
public final class CropTypeServiceImpl implements CropTypeService {

    private CropTypeDAO cropTypeDAO;

    @Autowired
    public CropTypeServiceImpl(CropTypeDAO cropTypeDAO) {
        this.cropTypeDAO = cropTypeDAO;
    }

    @Override
    public Page<CropType> search(String description, Boolean active,  Pageable pageable) {
        String descriptionParam = "%"+(description!=null ? description.toUpperCase() : description)+"%";
        return cropTypeDAO.findByDescriptionLikeAndActive(descriptionParam,active,pageable);
    }

     @Override
    public CropType findById(Long cropTypeId) {
        return cropTypeDAO.findOne(cropTypeId);
    }

    @Override
    public void delete(Long id) {
        cropTypeDAO.delete(id);
    }

    @Override
    public Collection<CropType> loadCollection() {
        return cropTypeDAO.findByActiveTrueOrderByDescriptionAsc();
    }

    @Override
    public CropType save(CropType cropType) {
        return cropTypeDAO.saveAndFlush(cropType);
    }

}
