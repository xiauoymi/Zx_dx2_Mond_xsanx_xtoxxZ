package com.monsanto.wms.service.catalog.impl;

import com.monsanto.wms.dao.catalog.MeteorologicalStationDAO;
import com.monsanto.wms.dao.catalog.StationTypeDAO;
import com.monsanto.wms.dao.sheduleTasks.MeteorologicalStationHistoricInfoDAO;
import com.monsanto.wms.persistence.model.MeteorologicalStation;
import com.monsanto.wms.persistence.model.MeteorologicalStationHistoric;
import com.monsanto.wms.persistence.model.StationType;
import com.monsanto.wms.persistence.model.User;
import com.monsanto.wms.service.catalog.MeteorologicalStationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: MANIET
 * Date: 6/3/13
 * Time: 3:51 PM
 * To change this template use File | Settings | File Templates.
 */
@Service(value = "meteorologicalStationService")
public class MeteorologicalStationServiceImpl implements MeteorologicalStationService {

    private MeteorologicalStationDAO meteorologicalStationDAO;
    private MeteorologicalStationHistoricInfoDAO meteorologicalStationHistoricInfoDAO;
    private StationTypeDAO stationTypeDAO;

    @Autowired
    public MeteorologicalStationServiceImpl(MeteorologicalStationDAO meteorologicalStationDAO,MeteorologicalStationHistoricInfoDAO meteorologicalStationHistoricInfoDAO,StationTypeDAO stationTypeDAO) {
        this.meteorologicalStationDAO = meteorologicalStationDAO;
        this.meteorologicalStationHistoricInfoDAO = meteorologicalStationHistoricInfoDAO;
        this.stationTypeDAO  = stationTypeDAO;
    }

    @Override
    public Page<MeteorologicalStation> search(Long stationTypeId,String description, Boolean active, Long ownerId, Pageable pageable) {
        String descriptionParam = "%"+(description!=null ? description.toUpperCase() : description)+"%";
        if(ownerId!=null && ownerId.intValue()>0){
            return assignResponsible(meteorologicalStationDAO.findByStationTypeIdAndDescriptionLikeAndActiveAndOwnerId(stationTypeId,descriptionParam,active,ownerId,pageable));
        }else{
            return assignResponsible(meteorologicalStationDAO.findByStationTypeIdAndDescriptionLikeAndActive(stationTypeId,descriptionParam,active,pageable));
        }
    }

    private Page<MeteorologicalStation> assignResponsible(Page<MeteorologicalStation> meteorologicalStations) {
        if(meteorologicalStations != null){
            for(MeteorologicalStation meteorologicalStation:meteorologicalStations){
                if(meteorologicalStation.getResponsible() == null){
                    meteorologicalStation.setResponsible(new User());
                    meteorologicalStation.getResponsible().setId("");
                }
             }
        }
        return meteorologicalStations;
    }

    @Override
    public MeteorologicalStation findById(Long meteorologicalStationId) {
        MeteorologicalStation meteorologicalStation = meteorologicalStationDAO.findOne(meteorologicalStationId);
        if(meteorologicalStation.getResponsible() == null){
            meteorologicalStation.setResponsible(new User());
            meteorologicalStation.getResponsible().setId("");
        }
        return meteorologicalStation;
    }

    @Override
    public void delete(Long id) {
        meteorologicalStationDAO.delete(id);
    }

    @Override
    public Collection<MeteorologicalStation> loadCollection() {
        return meteorologicalStationDAO.findByActiveTrueOrderByDescriptionAsc();
    }

    @Override
    public Collection<MeteorologicalStation> loadCollectionByMetStationType() {
        return meteorologicalStationDAO.findByActiveTrueAndStationTypeIdOrderByDescriptionAsc(MeteorologicalStation.SPECTRUM);
    }

    @Override
    public Collection<MeteorologicalStation> loadCollectionByOwner(Long owner) {
        return meteorologicalStationDAO.findByActiveTrueAndOwnerIdOrderByDescriptionAsc(owner);
    }

    @Override
    public MeteorologicalStation save(MeteorologicalStation meteorologicalStation) {
        if(meteorologicalStation.getResponsible().getId().equals("")){
            meteorologicalStation.setResponsible(null);
        }
        return meteorologicalStationDAO.saveAndFlush(meteorologicalStation);
    }

    @Override
    public Collection<MeteorologicalStation> findByTypeStationsWithUsrPwd(Long stationType) {
        return meteorologicalStationDAO.findByActiveTrueAndStationTypeIdAndUserNameNotNullAndPwdNotNull(stationType);
    }

    @Override
    public MeteorologicalStationHistoric save(MeteorologicalStationHistoric meteorologicalStationHistoric) {
        return meteorologicalStationHistoricInfoDAO.saveAndFlush(meteorologicalStationHistoric);
    }

    @Override
    public Collection<StationType> loadStationTypesCollection() {
        return stationTypeDAO.findAll();
    }

    @Override
    public Page<MeteorologicalStationHistoric> search(Integer day, Integer month, Integer year, Long meteorologicalStationId, Pageable pageable) {
        if(validateParameters(year,meteorologicalStationId)){
            if(month>0 && day<0){
                return meteorologicalStationHistoricInfoDAO.findByMeteorologicalStationIdAndMonthAndYear(meteorologicalStationId,month,year,pageable);
            }else if(month>0 && day > 0){
                return meteorologicalStationHistoricInfoDAO.findByMeteorologicalStationIdAndDayOfTheMonthAndMonthAndYear(meteorologicalStationId,day,month,year,pageable);
            }else{
                return meteorologicalStationHistoricInfoDAO.findByMeteorologicalStationIdAndYear(meteorologicalStationId,year,pageable);
            }
        }
        return new PageImpl<MeteorologicalStationHistoric>(new ArrayList<MeteorologicalStationHistoric>());
    }

    @Override
    public Collection<MeteorologicalStation> findByTypeStationsWithUsrSerialNumber(Long stationType) {
        return meteorologicalStationDAO.findByActiveTrueAndStationTypeIdAndUserNameNotNullAndSerialNumberNotNull(stationType);
    }

    private Boolean validateParameters(Integer year, Long meteorologicalStationId){
        if(year==null || meteorologicalStationId == null){
            return false;
        }

        return true;

    }
}
