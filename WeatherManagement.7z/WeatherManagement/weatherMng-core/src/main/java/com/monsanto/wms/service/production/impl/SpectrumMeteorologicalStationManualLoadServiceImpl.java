package com.monsanto.wms.service.production.impl;

import com.monsanto.wms.persistence.model.DataLoaderStaging;
import com.monsanto.wms.service.catalog.ReloadDataService;
import com.monsanto.wms.service.production.SpectrumMeteorologicalStationManualLoadService;
import com.monsanto.wms.spectrum.SpectrumManualLoadLayoutAbstract;
import com.monsanto.wms.util.WMSServiceUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.text.ParseException;
import java.util.Date;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

/**
 * Created by GFRAN1 on 10/29/2014.
 */
@Service(value = "spectrumMeteorologicalStationManualLoadService")
public class SpectrumMeteorologicalStationManualLoadServiceImpl implements SpectrumMeteorologicalStationManualLoadService {


    private ReloadDataService reloadDataService;

    @Autowired
    public SpectrumMeteorologicalStationManualLoadServiceImpl(ReloadDataService reloadDataService) {
        this.reloadDataService = reloadDataService;
    }

    @Override
    public Long importDataToStaging(Long metStationId, List<String[]> dataLoaderStagingStringList, Date startDate, Date endDate) throws ParseException {
        List<DataLoaderStaging> dataLoaderStagingList = getDataLoaderStagingList(dataLoaderStagingStringList);
        List<DataLoaderStaging> finalDataLoaderStagingList = fillTempAndDewPoint(dataLoaderStagingList);

        return reloadDataService.executeReloadProcess(startDate, endDate, metStationId, finalDataLoaderStagingList);

    }


    private List<DataLoaderStaging> fillTempAndDewPoint(List<DataLoaderStaging> dataLoaderStagingList){

        //delete rows when temp = null or dew Point = null
        List<DataLoaderStaging> filteredList = getFilteredList(dataLoaderStagingList);
            for (Integer i=0; i< filteredList.size() ;i++) {

                DataLoaderStaging previousDataLoaderStaging = i > 0 ? filteredList.get(i - 1) : filteredList.get(i);
                DataLoaderStaging currentDataLoaderStaging = filteredList.get(i);

                if (validateTempAndDewPoint(currentDataLoaderStaging)) {
                    //Calculating temperature Max and Min taking temperature from Spectrum station
                    currentDataLoaderStaging.setTemperatureMin(calculateMinTempAndDewPoint(Double.valueOf(validateData(previousDataLoaderStaging.getTemperatureMin())), Double.valueOf(validateData(currentDataLoaderStaging.getTemperature())), previousDataLoaderStaging.getDateTime(), currentDataLoaderStaging.getDateTime()));
                    currentDataLoaderStaging.setTempMax(calculateMaxTempAndDewPoint(Double.valueOf(validateData(previousDataLoaderStaging.getTempMax())), Double.valueOf(validateData(currentDataLoaderStaging.getTemperature())), previousDataLoaderStaging.getDateTime(), currentDataLoaderStaging.getDateTime()));
                    //Calculating DewPoint Max and Min taking temperature from Spectrum station
                    currentDataLoaderStaging.setDewPointMin(calculateMinTempAndDewPoint(Double.valueOf(validateData(previousDataLoaderStaging.getDewPointMin())), Double.valueOf(validateData(currentDataLoaderStaging.getDewPoint())), previousDataLoaderStaging.getDateTime(), currentDataLoaderStaging.getDateTime()));
                    currentDataLoaderStaging.setDewPointMax(calculateMaxTempAndDewPoint(Double.valueOf(validateData(previousDataLoaderStaging.getDewPointMax())), Double.valueOf(validateData(currentDataLoaderStaging.getDewPoint())), previousDataLoaderStaging.getDateTime(), currentDataLoaderStaging.getDateTime()));

                    filteredList.set(i, currentDataLoaderStaging);

                }
            }

         return filteredList;
    }

    private List<DataLoaderStaging> getFilteredList(List<DataLoaderStaging> dataLoaderStagingList){
        Iterator<DataLoaderStaging> dataLoaderStagingIterator = dataLoaderStagingList.iterator();
        while (dataLoaderStagingIterator.hasNext()){
            if(!validateTempAndDewPoint(dataLoaderStagingIterator.next())){
                    dataLoaderStagingIterator.remove();
            }
        }
        return dataLoaderStagingList;
    }

    private boolean validateTempAndDewPoint(DataLoaderStaging currentDataLoaderStaging) {
        return currentDataLoaderStaging.getTemperature() != null  && currentDataLoaderStaging.getDewPoint() != null
                && !currentDataLoaderStaging.getTemperature().equals("") && !currentDataLoaderStaging.getDewPoint().equals("");
    }


    private  List<DataLoaderStaging> getDataLoaderStagingList(List<String[]> bufferedMeteorologicalStationData){
        List<DataLoaderStaging> dataLoaderStagingList = new LinkedList<DataLoaderStaging>();

        for (String[] currentBufferRegistry : bufferedMeteorologicalStationData) {
            DataLoaderStaging dataLoaderStaging = transformBufferRegistryToDataLoaderStaging(currentBufferRegistry);
            dataLoaderStagingList.add(dataLoaderStaging);
        }
        return dataLoaderStagingList;

    }

    private String validateData(String data) {
        return data!= null ? data : WMSServiceUtil.ZERO;
    }

    private DataLoaderStaging transformBufferRegistryToDataLoaderStaging(String[] currentBufferRegistry) {

        DataLoaderStaging dataLoaderStaging = new DataLoaderStaging();
        dataLoaderStaging.setDateTime(validateIndex(currentBufferRegistry, SpectrumManualLoadLayoutAbstract.DATE_TIME));
        dataLoaderStaging.setSolarRadiation(validateIndex(currentBufferRegistry,SpectrumManualLoadLayoutAbstract.SOLAR_RADIATION));
        dataLoaderStaging.setHumidity(validateIndex(currentBufferRegistry,SpectrumManualLoadLayoutAbstract.HUMIDITY));
        dataLoaderStaging.setTemperature(validateIndex(currentBufferRegistry,SpectrumManualLoadLayoutAbstract.TEMPERATURE));
        dataLoaderStaging.setRainFall(validateIndex(currentBufferRegistry,SpectrumManualLoadLayoutAbstract.RAINFALL));
        dataLoaderStaging.setWindDirection(validateIndex(currentBufferRegistry,SpectrumManualLoadLayoutAbstract.WIND_DIRECTION));
        dataLoaderStaging.setWindGust(validateIndex(currentBufferRegistry,SpectrumManualLoadLayoutAbstract.WIND_GUST));
        dataLoaderStaging.setWindSpeed(validateIndex(currentBufferRegistry,SpectrumManualLoadLayoutAbstract.WIND_SPEED));
        dataLoaderStaging.setDewPoint(validateIndex(currentBufferRegistry,SpectrumManualLoadLayoutAbstract.DEW_POINT));
        return  dataLoaderStaging;
    }

    private String validateIndex(String[] currentBufferRegistry,int index) {
        return currentBufferRegistry.length > index ? currentBufferRegistry[index]:"";
    }


    private String calculateMaxTempAndDewPoint(Double previousData, Double currentData, String previousDay, String currentDay) {
        if ( currentData.intValue() < previousData.intValue() && validateSameDay(previousDay,currentDay)) {
            return previousData.toString();

        } else {
            return currentData.toString();
        }
    }


    private String calculateMinTempAndDewPoint(Double previousData, Double currentData, String previousDay, String currentDay) {
        if ( previousData.intValue() < currentData.intValue() && previousData.intValue()>0 && validateSameDay(previousDay,currentDay)) {
            return previousData.toString();
        } else {
            return currentData.toString();
        }
    }

    private Boolean validateSameDay(String previousDay, String currentDay){
        String previousDayFormat = WMSServiceUtil.getFormattedDate(previousDay, "yyyy-MM-dd", "dd/MM/yyyy");
        String currentDayFormat = WMSServiceUtil.getFormattedDate(currentDay, "yyyy-MM-dd", "dd/MM/yyyy");
       return currentDayFormat.equals(previousDayFormat)? true:false;
    }
}
