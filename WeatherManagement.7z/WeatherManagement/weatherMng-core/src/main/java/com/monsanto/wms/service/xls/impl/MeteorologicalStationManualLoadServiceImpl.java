package com.monsanto.wms.service.xls.impl;

import com.monsanto.wms.dao.sheduleTasks.MeteorologicalStationHistoricInfoDAO;
import com.monsanto.wms.excel.manager.ExcelListener;
import com.monsanto.wms.excel.manager.ExcelListenerManager;
import com.monsanto.wms.excel.manager.invokers.ExcelTransformerInvoker;
import com.monsanto.wms.excel.manager.invokers.InvokerResult;
import com.monsanto.wms.excel.manager.vo.FileLoadResultVO;
import com.monsanto.wms.exceptions.excel.ExcelLoadErrorException;
import com.monsanto.wms.persistence.model.MeteorologicalStationHistoric;
import com.monsanto.wms.service.xls.MeteorologicalStationManualLoadService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.InputStream;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: MANIET
 * Date: 5/29/13
 * Time: 12:31 PM
 * To change this template use File | Settings | File Templates.
 */
@Service
public final class MeteorologicalStationManualLoadServiceImpl implements MeteorologicalStationManualLoadService {

     private ExcelListenerManager excelListenerManager;
     private ExcelTransformerInvoker excelTransformerInvoker;

    private MeteorologicalStationHistoricInfoDAO meteorologicalStationHistoricInfoDAO;


    @Autowired
    public MeteorologicalStationManualLoadServiceImpl(ExcelListenerManager excelListenerManager, ExcelTransformerInvoker excelTransformerInvoker,MeteorologicalStationHistoricInfoDAO meteorologicalStationHistoricInfoDAO) {
        this.excelListenerManager = excelListenerManager;
        this.excelTransformerInvoker = excelTransformerInvoker;
        this.meteorologicalStationHistoricInfoDAO = meteorologicalStationHistoricInfoDAO;
    }

    @Override
    public FileLoadResultVO importData(InputStream inputStream, Long metStationId,Integer day, Integer month, Integer year) {

        deleteCurrentData(metStationId,day,month,year);

        FileLoadResultVO fileLoadResultVO = new FileLoadResultVO();
        ExcelListener listener = excelListenerManager.createMetStationManualLoad();


        excelTransformerInvoker.invoke(inputStream, listener);
        InvokerResult result = listener.getInvokerResult();

        fileLoadResultVO.setInsertedRows(result.getInsertedRows());
        fileLoadResultVO.setUpdatedRows(0L);

        if(fileLoadResultVO.getInsertedRows()<=0){
          throw new ExcelLoadErrorException("There was no registries inserted, review your file and confirm it has registries available");
        }

        return fileLoadResultVO;
    }

    private void deleteCurrentData(Long metStationId, Integer day, Integer month, Integer year){
        List<MeteorologicalStationHistoric> ls = meteorologicalStationHistoricInfoDAO.findByMeteorologicalStationIdAndDayOfTheMonthAndMonthAndYear(metStationId, day, month, year);
        for(MeteorologicalStationHistoric currentItem: ls){
            meteorologicalStationHistoricInfoDAO.delete(currentItem);
        }
    }
}
