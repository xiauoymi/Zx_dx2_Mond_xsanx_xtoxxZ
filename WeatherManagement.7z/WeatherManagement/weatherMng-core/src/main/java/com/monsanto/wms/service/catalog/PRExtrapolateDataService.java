package com.monsanto.wms.service.catalog;

import java.util.Date;

/**
 * Created with IntelliJ IDEA.
 * User: GFRAN1
 * Date: 7/21/14
 * Time: 12:15 PM
 * To change this template use File | Settings | File Templates.
 */
public interface PRExtrapolateDataService {

    String fillEmptyDays(Long meteorologicalStationId,Date startDate, Date endDate,Integer daysToFill) ;
    String getExtrapolatedDataProfile(Long meteorologicalStationId, Date startDate, Date endDate) ;
}
