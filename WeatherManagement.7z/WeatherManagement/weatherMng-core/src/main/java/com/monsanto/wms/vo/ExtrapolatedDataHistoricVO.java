package com.monsanto.wms.vo;

import org.omg.CORBA.PUBLIC_MEMBER;

import java.util.ArrayList;
import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: GFRAN1
 * Date: 7/31/14
 * Time: 5:41 PM
 * To change this template use File | Settings | File Templates.
 */
public class ExtrapolatedDataHistoricVO {

    private final Integer INDEX_MET_MEASURE_COUNT = 0;
    private final Integer INDEX_EXT_MEASURE_COUNT = 1;

    private String meteorologicalMeasureCount;
    private String extrapolatedMeasureCount;
    private List<ExtrapolatedDataHistoricVO> items;

    public ExtrapolatedDataHistoricVO(List objects){
        items = new ArrayList<ExtrapolatedDataHistoricVO>();

        for(Object currentObject : objects){
            Object[] currentItem = (Object[])currentObject;
            items.add(new ExtrapolatedDataHistoricVO(String.valueOf(currentItem[INDEX_MET_MEASURE_COUNT]),
                    String.valueOf(currentItem[INDEX_EXT_MEASURE_COUNT])));

        }
    }

    public ExtrapolatedDataHistoricVO(String meteorologicalMeasureCount,String extrapolatedMeasureCount){
        this.meteorologicalMeasureCount = meteorologicalMeasureCount;
        this.extrapolatedMeasureCount= extrapolatedMeasureCount;
    }

    public String getMeteorologicalMeasureCount() {
        return meteorologicalMeasureCount;
    }

    public void setMeteorologicalMeasureCount(String meteorologicalMeasureCount) {
        this.meteorologicalMeasureCount = meteorologicalMeasureCount;
    }

    public String getExtrapolatedMeasureCount() {
        return extrapolatedMeasureCount;
    }

    public void setExtrapolatedMeasureCount(String extrapolatedMeasureCount) {
        this.extrapolatedMeasureCount = extrapolatedMeasureCount;
    }

    public List<ExtrapolatedDataHistoricVO> getItems() {
        return items;
    }

    public void setItems(List<ExtrapolatedDataHistoricVO> items) {
        this.items = items;
    }
}
