package com.monsanto.wms.util;

import org.codehaus.jackson.map.annotate.JsonSerialize;

import java.text.MessageFormat;

/**
 * Monsanto
 * Author: Luis Miguel Arteaga Rios (lmarte@monsanto.com)
 * Date: 6/12/12
 * Time: 03:26 PM
 */
@JsonSerialize(using = RoleTypeSerializer.class)
public enum RoleType {
    ROLE_SUPER_ADMIN                                    (1L),
    ROLE_ADMIN_AREA_ADMINISTRATIVE_TASKS                (2L),
    ROLE_CAPTURE_AREA_ADMINISTRATIVE_TASKS              (3L),
    ROLE_REPORT_AREA_ADMINISTRATIVE_TASKS               (4L),//
    ROLE_READONLY_AREA_ADMINISTRATIVE_TASKS             (5L),
    ROLE_ADMIN_AREA_PRODUCTION_RESEARCH                 (6L),
    ROLE_CAPTURE_AREA_PRODUCTION_RESEARCH               (7L),
    ROLE_REPORT_AREA_PRODUCTION_RESEARCH                (8L), //
    ROLE_READONLY_AREA_PRODUCTION_RESEARCH              (9L),
    ROLE_ADMIN_AREA_TD                                  (10L),
    ROLE_CAPTURE_AREA_TD                                (11L),
    ROLE_REPORT_AREA_TD                                 (12L), //
    ROLE_READONLY_AREA_TD                               (13L),
    ROLE_ADMIN_AREA_FIELD_PRODUCTION                    (14L),
    ROLE_CAPTURE_AREA_FIELD_PRODUCTION                  (15L),
    ROLE_REPORT_ADMIN_AREA_FIELD_PRODUCTION             (16L), //
    ROLE_READONLY_ADMIN_AREA_FIELD_PRODUCTION           (17L);

    private final Long id;

    private RoleType(Long id){
        this.id = id;
    }

    public Long getId(){
        return id;
    }

    private static final String ERROR_MESSAGE = "No role is defined with id: {0}";

    public static RoleType lookup( Long id ){

        for( RoleType role : RoleType.values() ){
            if( role.id.equals( id ) ){
                return role;
            }
        }
        throw new IllegalArgumentException( MessageFormat.format( ERROR_MESSAGE , id ) );
    }
}
