package com.monsanto.wms.excel.manager.invokers;

/**
 * Created by IntelliJ IDEA.
 * User: CCARD2
 * Date: 12/11/12
 * Time: 12:25 PM
 * To change this template use File | Settings | File Templates.
 */
public class InvokerResult {

    private long  insertedRows = 0;

    public long getInsertedRows() {
        return insertedRows;
    }

    public void setInsertedRows(long insertedRows) {
        this.insertedRows = insertedRows;
    }

    public void increment() {
        insertedRows += 1;
    }
}
