package com.monsanto.wms.excel.listeners.xlsRows;

import org.hibernate.validator.constraints.NotBlank;

import javax.validation.constraints.NotNull;
import java.util.Date;

/**
 * Created by IntelliJ IDEA.
 * User: MANIET
 * Date: 5/28/13
 * Time: 4:06 PM
 * To change this template use File | Settings | File Templates.
 */
public class TestXlsRow {
    @NotBlank
    @NotNull
    private String string1;

    @NotBlank
    private String formula;

    private Double number;

    private Date date;

    public String getString1() {
        return string1;
    }

    public void setString1(String string1) {
        this.string1 = string1;
    }

    public String getFormula() {
        return formula;
    }

    public void setFormula(String formula) {
        this.formula = formula;
    }

    public Double getNumber() {
        return number;
    }

    public void setNumber(Double number) {
        this.number = number;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }
}
