package com.monsanto.wms.excel.manager.base;

import com.monsanto.wms.excel.manager.HSSFCoreListener;
import com.monsanto.wms.excel.manager.invokers.InvokerResult;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: MANIET
 * Date: 7/29/13
 * Time: 9:51 AM
 * To change this template use File | Settings | File Templates.
 */
public abstract class WMSReadingXLSCore extends HSSFCoreListener {

    protected InvokerResult invokerResult;
    protected int COLUMNS;

    protected abstract void processColumns(int rowNumber, List<Object> row);

    @Override
    public int getMaxColumns() {
        return COLUMNS;
    }

    @Override
    public InvokerResult getInvokerResult() {
        return invokerResult;
    }

    @Override
    public void processRow(int rowNumber, List<Object> row, String sheetName) {
        if (rowNumber >= 1 && row != null) {
            processColumns(rowNumber, row);
        }
    }
}
