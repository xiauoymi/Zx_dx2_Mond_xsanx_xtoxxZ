package com.monsanto.wms.service.catalog;

import com.monsanto.wms.persistence.model.CropStage;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: MANIET
 * Date: 6/3/13
 * Time: 3:51 PM
 * To change this template use File | Settings | File Templates.
 */
public interface CropStageService {

    Page<CropStage> search(String description, Long cropTypeId, Long cropId,Boolean active, Pageable pageable);
    CropStage save(CropStage cropStage);
    CropStage findById(Long cropStageId);
    void delete(Long id,Boolean defaultValue);
    Collection<CropStage> loadCollection();
    Collection<CropStage> loadCollectionNotDefault();
    Collection<CropStage> loadCollectionDefault();
    Collection<CropStage> loadCollectionNotDefaultByCropId(Long cropId);

}

