package com.monsanto.wms.spectrum;

import com.monsanto.wms.persistence.model.DataLoaderStaging;
import com.monsanto.wms.persistence.model.MeteorologicalStation;
import com.monsanto.wms.service.catalog.MeteorologicalStationService;
import com.monsanto.wms.service.mail.MailService;
import com.monsanto.wms.service.security.UserSystemPrivilegesService;
import com.monsanto.wms.service.sheduleTasks.ScheduleErrorService;
import com.monsanto.wms.spectrum.connectionItems.CreateURL;
import com.monsanto.wms.util.WMSServiceUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Created by GFRAN1 on 9/4/2014.
 */
public class SpectrumRemoteFileProcess {

    private static final Logger log = LoggerFactory.getLogger(SpectrumTimerControl.class);
    private final String  SPECTRUM_URL = "http://meteoviewapi.specweather.com/Monsanto.aspx";
    private CreateURL urlController;
    private MeteorologicalStationService meteorologicalStationService;
    private MailService mailService;
    private UserSystemPrivilegesService userSystemPrivilegesService;
    private ScheduleErrorService errorService;

    public SpectrumRemoteFileProcess(MeteorologicalStationService meteorologicalStationService, MailService mailService, UserSystemPrivilegesService userSystemPrivilegesService,ScheduleErrorService  errorService) {
        this.meteorologicalStationService = meteorologicalStationService;
        this.mailService = mailService;
        this.userSystemPrivilegesService = userSystemPrivilegesService;
        this.errorService = errorService;
    }


    public  String getUrlWithSecurityParameters(MeteorologicalStation meteorologicalStation){
        String paramURL = SPECTRUM_URL + "?user="+meteorologicalStation.getUserName() + "&station=" + meteorologicalStation.getSerialNumber() + "&method=getConditionsCSV";
        log.info("Spectrum Time Control consulting URL:"+paramURL);
        return paramURL;
    }

    public SpectrumRemoteFileReader createRemoteFileReader(MeteorologicalStation currentStation) {
        urlController = new CreateURL(getUrlWithSecurityParameters(currentStation));
        return new SpectrumRemoteFileReader(urlController.getUrl(),currentStation,mailService,userSystemPrivilegesService);
    }

    public List<String[]> getSpectrumMeteorologicalReadInformation(MeteorologicalStation currentStation) throws IOException {
        SpectrumReadDataProcess readDataProcess = new SpectrumReadDataProcess();
        List<String[]> rawSpectrumStationList = readDataProcess.startReading(createRemoteFileReader(currentStation), false);
        return rawSpectrumStationList;
    }

    public void storeHistoricRetrievedInformation(MeteorologicalStation currentStation) {

        try {
            List<String[]> rawSpectrumStationList = getSpectrumMeteorologicalReadInformation(currentStation);
            SpectrumSelectCurrentDateData selectCurrentDateData = new SpectrumSelectCurrentDateData(rawSpectrumStationList, currentStation);
            List<SpectrumValidatedMeteorologicalStationHistory> historicList = selectCurrentDateData.getData();
            SpectrumStoreData storeData = new SpectrumStoreData(meteorologicalStationService, errorService, historicList);
            storeData.save();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public List<DataLoaderStaging> getFilteredHistoricList(MeteorologicalStation currentStation,Date date) throws IOException {

        List<DataLoaderStaging> dataLoaderStagingFilteredList = new ArrayList<DataLoaderStaging>();
        try {
            List<String[]> rawSpectrumStationList = getSpectrumMeteorologicalReadInformation(currentStation);
            SpectrumSelectCurrentDateData selectCurrentDateData = new SpectrumSelectCurrentDateData(rawSpectrumStationList, currentStation);
            List<DataLoaderStaging> dataLoaderStagingList = selectCurrentDateData.getDataLoaderStagingList(currentStation, rawSpectrumStationList);

            for (DataLoaderStaging dataLoaderStaging : dataLoaderStagingList) {
                if(dataLoaderStaging.getDateTime()!=null && date!=null){
                    String dateFormat = WMSServiceUtil.getFormattedDate(dataLoaderStaging.getDateTime(), "yyyy-MM-dd", "dd/MM/yyyy");
                    String pickedDateFormat=WMSServiceUtil.getFormattedDate(date.toString(), WMSServiceUtil.PATTERN, "dd/MM/yyyy");
                    if (dateFormat.equalsIgnoreCase(pickedDateFormat)) {
                        dataLoaderStagingFilteredList.add(dataLoaderStaging);
                    }
                }

            }
        }
        catch(IOException e){
            e.printStackTrace();
        }
        return dataLoaderStagingFilteredList;
    }


}
