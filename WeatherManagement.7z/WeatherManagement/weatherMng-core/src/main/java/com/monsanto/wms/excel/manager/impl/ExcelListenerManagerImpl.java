package com.monsanto.wms.excel.manager.impl;

import com.monsanto.wms.excel.manager.ExcelListener;
import com.monsanto.wms.excel.manager.ExcelListenerManager;

/**
 * Created by IntelliJ IDEA.
 * User: MANIET
 * Date: 5/28/13
 * Time: 3:21 PM
 * To change this template use File | Settings | File Templates.
 */
public abstract class ExcelListenerManagerImpl implements ExcelListenerManager{

}
