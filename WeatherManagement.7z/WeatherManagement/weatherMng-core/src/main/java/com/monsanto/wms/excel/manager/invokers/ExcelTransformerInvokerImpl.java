package com.monsanto.wms.excel.manager.invokers;

import com.monsanto.wms.excel.manager.ExcelListener;
import com.monsanto.wms.exceptions.excel.ExcelLoadErrorException;
import org.apache.poi.hssf.eventusermodel.HSSFEventFactory;
import org.apache.poi.hssf.eventusermodel.HSSFRequest;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;

import java.io.IOException;
import java.io.InputStream;


public final class ExcelTransformerInvokerImpl implements ExcelTransformerInvoker {


    @Override
    public InvokerResult invoke(InputStream file, ExcelListener listener) {

        POIFSFileSystem poifs = null;
        try {
            poifs = new POIFSFileSystem(file);
            InputStream din = poifs.createDocumentInputStream("Workbook");
            HSSFRequest req = new HSSFRequest();
            req.addListenerForAllRecords(listener);
            HSSFEventFactory factory = new HSSFEventFactory();
            factory.processEvents(req, din);
            din.close();
        } catch (IOException e) {
            throw new ExcelLoadErrorException(e.getMessage());
        }
        return listener.getInvokerResult();
    }


}
