package com.monsanto.wms.excel.listeners.xlsRows;

/**
 * Created by IntelliJ IDEA.
 * User: MANIET
 * Date: 7/23/13
 * Time: 11:00 AM
 * To change this template use File | Settings | File Templates.
 */
public class MeteorologicalStationManualLoadRow {


    private Long meteorologicalStationId;
    private Double tempMin;
    private Double tempMax;
    private Integer day;
    private Integer month;
    private Integer year;
    private String registryTime;

    public Long getMeteorologicalStationId() {
        return meteorologicalStationId;
    }

    public void setMeteorologicalStationId(Long meteorologicalStationId) {
        this.meteorologicalStationId = meteorologicalStationId;
    }

    public Double getTempMin() {
        return tempMin;
    }

    public void setTempMin(Double tempMin) {
        this.tempMin = tempMin;
    }

    public Double getTempMax() {
        return tempMax;
    }

    public void setTempMax(Double tempMax) {
        this.tempMax = tempMax;
    }

    public Integer getDay() {
        return day;
    }

    public void setDay(Integer day) {
        this.day = day;
    }

    public Integer getMonth() {
        return month;
    }

    public void setMonth(Integer month) {
        this.month = month;
    }

    public Integer getYear() {
        return year;
    }

    public void setYear(Integer year) {
        this.year = year;
    }

    public String getRegistryTime() {
        return registryTime;
    }

    public void setRegistryTime(String registryTime) {
        this.registryTime = registryTime;
    }
}
