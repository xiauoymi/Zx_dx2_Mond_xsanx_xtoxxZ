package com.monsanto.wms.dao.catalog;

import com.monsanto.wms.persistence.model.ErrorLogView;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * Created by GFRAN1 on 9/17/2014.
 */
public interface ErrorLogViewDAO extends JpaRepository<ErrorLogView,Long>{
    Page findByWmsDataLoaderIdAndStatus(Long id,String status, Pageable pageable);
}
