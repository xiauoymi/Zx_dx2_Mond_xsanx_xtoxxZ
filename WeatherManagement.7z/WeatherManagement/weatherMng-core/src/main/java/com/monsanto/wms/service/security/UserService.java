package com.monsanto.wms.service.security;


import com.monsanto.wms.persistence.model.User;
import com.monsanto.wms.vo.LdapUserVO;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: MANIET
 * Date: 6/3/13
 * Time: 3:51 PM
 * To change this template use File | Settings | File Templates.
 */
public interface UserService {

    Page<User> search(String userId, String name, String email,Boolean active, Pageable pageable);
    User save(User user);
    User findById(String id);
    void delete(String id);

    Collection<LdapUserVO> findLdapUserByIdLike( String userId );
    Boolean authenticated(String userId, String password);

}
