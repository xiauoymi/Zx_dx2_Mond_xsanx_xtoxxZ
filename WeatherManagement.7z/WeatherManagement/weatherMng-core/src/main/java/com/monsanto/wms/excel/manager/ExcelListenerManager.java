package com.monsanto.wms.excel.manager;

/**
 * Created by IntelliJ IDEA.
 * User: MANIET
 * Date: 5/28/13
 * Time: 3:20 PM
 * To change this template use File | Settings | File Templates.
 */
public interface ExcelListenerManager {
    public abstract ExcelListener createTestXLSReading();
    public abstract ExcelListener createMetStationManualLoad();
}
