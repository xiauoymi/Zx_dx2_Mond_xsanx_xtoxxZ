package com.monsanto.wms.service.catalog.impl;

import com.monsanto.wms.dao.catalog.CropDAO;
import com.monsanto.wms.persistence.model.Crop;
import com.monsanto.wms.service.catalog.CropService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: MANIET
 * Date: 6/3/13
 * Time: 3:51 PM
 * To change this template use File | Settings | File Templates.
 */
@Service
public final class CropServiceImpl implements CropService {

    private CropDAO cropDAO;

    @Autowired
    public CropServiceImpl(CropDAO cropDAO) {
        this.cropDAO = cropDAO;
    }

    @Override
    public Page<Crop> search(String description, Boolean active,Long cropType, Pageable pageable) {
        String descriptionParam = "%"+(description!=null ? description.toUpperCase() : description)+"%";

        if(cropType!=null && cropType.intValue()>0){
            return cropDAO.findByDescriptionLikeAndActiveAndTypeId(descriptionParam,active,cropType,pageable);
        }else{
            return cropDAO.findByDescriptionLikeAndActive(descriptionParam,active,pageable);
        }

    }

     @Override
    public Crop findById(Long cropId) {
        return cropDAO.findOne(cropId);
    }

    @Override
    public void delete(Long id) {
        cropDAO.delete(id);
    }

    @Override
    public Collection<Crop> loadCollection() {
        return cropDAO.findByActiveTrueOrderByDescriptionAsc();
    }

     @Override
    public Collection<Crop> loadCollectionByParent(Long cropTypeId) {
        return cropDAO.findByTypeIdAndActiveTrueOrderByDescriptionAsc(cropTypeId);
    }

    @Override
    public Crop save(Crop crop) {
        return cropDAO.saveAndFlush(crop);
    }



}
