package com.monsanto.wms.dao.oracle;

import org.springframework.stereotype.Component;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: MANIET
 * Date: 6/19/13
 * Time: 10:23 AM
 * To change this template use File | Settings | File Templates.
 */
@Component
public interface OracleFxDAO <T> {

    public List<T> executeFunction(String namedQuery,Object... parameters);
    public Object createQuerySingleResult(String namedQuery);

}
