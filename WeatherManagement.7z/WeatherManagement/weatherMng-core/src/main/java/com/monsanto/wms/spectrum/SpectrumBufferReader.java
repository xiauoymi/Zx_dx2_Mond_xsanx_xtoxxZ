package com.monsanto.wms.spectrum;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: MANIET
 * Date: 10/10/13
 * Time: 8:44 AM
 * To change this template use File | Settings | File Templates.
 */
public class SpectrumBufferReader {


    public static List<String[]> toList(InputStreamReader inputStreamReader, Integer numberHeaders, String delimiter) throws IOException {

        List<String[]> list = new ArrayList<String[]>();

        if (inputStreamReader != null) {

            final BufferedReader bufferedReader = new BufferedReader(inputStreamReader);

            for(Integer headers=0; headers<numberHeaders;headers++){
                skipBufferHeaders(bufferedReader);
            }


            readAndProcessBufferReader(bufferedReader, list,delimiter);

        }

        return list;
    }

    private static void readAndProcessBufferReader(BufferedReader bufferedReader, List<String[]> list, String delimiter) throws IOException {
        String currentBufferLine;
        while ((currentBufferLine = bufferedReader.readLine()) != null) {
            addArrayToList(list, convertBufferLineToArray(currentBufferLine,delimiter));
        }
    }

    private static void addArrayToList(List<String[]> list, String[] s) {
        list.add(s);
    }

    private static void skipBufferHeaders(BufferedReader bufferedReader) throws IOException {
        bufferedReader.readLine();
    }

    private static String[] convertBufferLineToArray(String currentLine, String delimiter) {
        String trimLine = currentLine.trim();
        return trimLine.split(delimiter);
    }

}
