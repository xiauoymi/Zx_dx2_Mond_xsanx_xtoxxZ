package com.monsanto.wms.exceptions.schedule.spectrum;

import com.monsanto.wms.exceptions.WMSException;

/**
 * Created with IntelliJ IDEA.
 * User: MANIET
 * Date: 10/14/13
 * Time: 11:54 AM
 * To change this template use File | Settings | File Templates.
 */
public class SpectrumListenerInitializationException extends WMSException {

    public SpectrumListenerInitializationException(String message) {
        super(message);
    }
}
