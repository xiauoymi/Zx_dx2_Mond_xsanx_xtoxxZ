package com.monsanto.wms.spectrum;


import com.monsanto.wms.persistence.model.MeteorologicalStation;
import com.monsanto.wms.service.mail.MailService;
import com.monsanto.wms.service.security.UserSystemPrivilegesService;
import com.monsanto.wms.util.WMSServiceUtil;
import com.monsanto.wms.spectrum.helpers.ProcessReadURLError;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.*;

/**
 * Created with IntelliJ IDEA.
 * User: MANIET
 * Date: 10/11/13
 * Time: 1:55 PM
 * To change this template use File | Settings | File Templates.
 */
public class SpectrumRemoteFileReader {

    private static final Logger log = LoggerFactory.getLogger(SpectrumReadDataProcess.class);
    private URL url;
    private MeteorologicalStation currentStation;
    private final MailService mailService;
    private final UserSystemPrivilegesService userSystemPrivilegesService;

    public SpectrumRemoteFileReader(URL url, MeteorologicalStation currentStation, MailService mailService, UserSystemPrivilegesService userSystemPrivilegesService) {
        this.url = url;
        this.currentStation = currentStation;
        this.mailService = mailService;
        this.userSystemPrivilegesService = userSystemPrivilegesService;
    }

    public InputStreamReader getInputStreamReader(Boolean onDemand) {
        try {
            InputStreamReader inputStreamReader = openInputStreamConnection();
            return inputStreamReader;
        } catch (IOException e) {
            if(!onDemand){
                processErrorFound(e);
            }
            e.printStackTrace();
            return null;
        }

    }

    public InputStreamReader openInputStreamConnection() throws IOException {
        return new InputStreamReader(url.openConnection().getInputStream());
    }

    public void processErrorFound(IOException e) {
        log.info("Station failing: "+ currentStation.getDescription());
        ProcessReadURLError processReadURLError = new ProcessReadURLError(mailService, userSystemPrivilegesService, currentStation, url.toString());
        processReadURLError.sendErrorToDistributionList(e, MeteorologicalStation.SPECTRUM.intValue());
    }


    public void processErrorFound(String message){
        log.info("Station failing: "+ currentStation.getDescription());
        ProcessReadURLError processReadURLError = new ProcessReadURLError(mailService, userSystemPrivilegesService, currentStation, url.toString());
        processReadURLError.sendErrorToDistributionList(message, MeteorologicalStation.SPECTRUM.intValue());
    }

    public void validateExistenceDataFromPreviousDay(List<String[]> rawSpectrumStationList)
    {
        List<String> dayRawSpectrumStationList = new ArrayList<String>();
        for(String[] rawSpectrumStationArray:rawSpectrumStationList){
            String dateFormat = WMSServiceUtil.getFormattedDate(rawSpectrumStationArray[1].toString(), "yyyy-MM-dd", "dd/MM/yyyy");
                if(dateFormat.equalsIgnoreCase(WMSServiceUtil.subtractDay(new Date())))
                {
                    dayRawSpectrumStationList.add(dateFormat);
                }
        }
        if(dayRawSpectrumStationList.isEmpty()){
             processErrorFound("No existen datos registrados para el dia anterior.");
        }
    }
}
