package com.monsanto.wms.dao.catalog;

import com.monsanto.wms.persistence.model.BaseTemperature;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

/**
 * Created by IntelliJ IDEA.
 * User: MANIET
 * Date: 6/3/13
 * Time: 3:52 PM
 * To change this template use File | Settings | File Templates.
 */
@Repository
public interface BaseTemperatureDAO extends JpaRepository<BaseTemperature, Long> {

    Page findByCropTypeIdAndCropIdAndTempminLikeAndTempmaxLikeAndActive(Long cropTypeId,Long cropId,String temMin, String tempMax,Boolean active, Pageable pageable);
    Page findByCropTypeIdAndTempminLikeAndTempmaxLikeAndActive(Long cropTypeId,String temMin, String tempMax,Boolean active, Pageable pageable);
    Page findByCropIdAndTempminLikeAndTempmaxLikeAndActive(Long cropTypeId,String temMin, String tempMax,Boolean active, Pageable pageable);

    Page findByActive(Boolean active, Pageable pageable);


}
