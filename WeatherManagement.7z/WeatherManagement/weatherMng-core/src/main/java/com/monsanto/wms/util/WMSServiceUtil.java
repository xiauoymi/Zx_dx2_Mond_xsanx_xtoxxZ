package com.monsanto.wms.util;

import com.monsanto.wms.persistence.model.User;
import org.apache.commons.lang.time.DateFormatUtils;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;


/**
 * Created by IntelliJ IDEA.
 * User: CCARD2
 * Date: 6/10/12
 * Time: 09:07 AM
 * To change this template use File | Settings | File Templates.
 */
public abstract class WMSServiceUtil {

    public final static String PATTERN = "EEE MMM dd HH:mm:ss z yyyy";
    public final static String ZERO="0.0";

    public static User getCurrentUser() {

        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

        if (authentication != null) {

            return (User) authentication.getDetails();
        }

        return null;
    }

    public static Double fahrenheitToCelsius(Double fahrenheit) {

        Double C = null;

        if (fahrenheit != null) {
            C = (((fahrenheit - 32) * 5D) / 9D);
            C = (double) Math.round(C * 100) / 100;
            C = manualFloatPrecision(C);
        }
        return C;
    }

    public static Double celsiusToFahrenheit(Double celsius) {
        Double F = null;

        if (celsius != null) {
            F = (((celsius * 9D) / 5D) + 32);
            F = (double) Math.round(F * 100) / 100;
            F = manualFloatPrecision(F);
        }

        return F;
    }

    private static Double manualFloatPrecision(Double D) {

        if (D.toString().length() > 5) {
            String DS = D.toString();
            DS = DS.substring(0, 5);
            return Double.parseDouble(DS);
        }

        return D;
    }

    public static String subtractDay(Date date) {

        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        cal.add(Calendar.DAY_OF_MONTH, -1);
        return DateFormatUtils.format(cal.getTime(), "dd/MM/yyyy");

    }

    public static Integer getMonth(Date date) throws ParseException {

        String formattedDate = getFormattedDate(date.toString(), PATTERN, "MM/dd/yyyy");
        Calendar cal = parseDate(formattedDate);
        return cal.get(Calendar.MONTH)+1;
    }

    public static Integer getDay(Date date) throws ParseException {
        String formattedDate = getFormattedDate(date.toString(), PATTERN, "MM/dd/yyyy");
        Calendar cal = parseDate(formattedDate);
        return cal.get(Calendar.DAY_OF_MONTH );
    }

    public static Integer getYear(Date date) throws ParseException {
        String formattedDate = getFormattedDate(date.toString(), PATTERN, "MM/dd/yyyy");
        Calendar cal = parseDate(formattedDate);
        return cal.get(Calendar.YEAR);
    }
    public static String getFormattedDate(String date, String pattern, String format){
        String dateFormat = "";
        try {
            SimpleDateFormat textFormat = new SimpleDateFormat(pattern);
          if(date!=null){
              Date dateParsed = textFormat.parse(date);
              Calendar cal = Calendar.getInstance();
              cal.setTime(dateParsed);
              dateFormat = DateFormatUtils.format(cal.getTime(), format);

          }

        } catch (ParseException e) {
            e.printStackTrace();
        }
        return dateFormat;
    }

    public static Calendar parseDate(String formattedDate) throws ParseException{
        DateFormat date2 = DateFormat.getDateInstance(DateFormat.SHORT);
        date2.parse(formattedDate);
        Calendar cal = Calendar.getInstance();
        cal.setTime(date2.getCalendar().getTime());
        return cal;
    }

    public static Date getDate(String date) throws ParseException {
        String dateFormatted =getFormattedDate(date, "yyyy-MM-dd", "dd/MM/yyyy");
        Calendar dateParsed = parseDate(dateFormatted);
        return dateParsed.getTime();
    }


}
