package com.monsanto.wms.excel.builder;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;

public class CellBuilderVO {

    private Double value;
    private String strValue;
    private HSSFRow row;

    public CellBuilderVO() {
        strValue = "";
    }

    public CellBuilderVO withValue(Double value) {
        this.value = value;
        return this;
    }

    public CellBuilderVO withStrValue(String strValue) {
        this.strValue = strValue;
        this.value = null;
        return this;
    }

    public CellBuilderVO withRow(HSSFRow row) {
        this.row = row;
        return this;
    }

    public HSSFCell buildStr(int index) {
        HSSFCell cell = row.createCell(index);
        cell.setCellValue(strValue);
        return cell;
    }

    public HSSFCell build(int index) {
        HSSFCell cell = row.createCell(index);
        cell.setCellValue(value);
        return cell;
    }
}
