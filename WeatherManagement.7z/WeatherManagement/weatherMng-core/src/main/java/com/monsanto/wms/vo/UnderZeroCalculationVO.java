package com.monsanto.wms.vo;

import com.monsanto.wms.util.WMSServiceUtil;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: MANIET
 * Date: 6/21/13
 * Time: 12:28 PM
 * To change this template use File | Settings | File Templates.
 */
public class UnderZeroCalculationVO {

    private final Integer INDEX_TEMP_MIN = 0;
    private final Integer INDEX_MONTH_DESC = 1;
    private final Integer INDEX_ERROR = 2;

    private Double tempMinF;
    private Double tempMinC;
    private String dateDesc;
    private String error;

    private List<UnderZeroCalculationVO> items;

    public UnderZeroCalculationVO(List objects) {
        items = new ArrayList<UnderZeroCalculationVO>();

        for(Object currentObject : objects){
          Object[] currentItem = (Object[])currentObject;
          items.add(new UnderZeroCalculationVO(Double.parseDouble(String.valueOf(currentItem[INDEX_TEMP_MIN])),
                  String.valueOf(currentItem[INDEX_MONTH_DESC]),
                  currentItem[INDEX_ERROR]!=null ? (String.valueOf(currentItem[INDEX_ERROR])) : ""));
        }
    }

    public UnderZeroCalculationVO(Double tempMin, String dateDesc,String error) {
        this.tempMinC = tempMin;
        this.dateDesc = dateDesc;
        this.error = error;
    }

    public Double getTempMinF() {
        if(tempMinC!=null){
               this.tempMinF = WMSServiceUtil.celsiusToFahrenheit(this.tempMinC);
           }
        return tempMinF;
    }

    public void setTempMinF(Double tempMinF) {
        this.tempMinF = tempMinF;
    }

    public Double getTempMinC(){
         return tempMinC;
    }

       public void setTempMinC(Double tempMinC) {
           this.tempMinC = tempMinC;
       }


    public String getDateDesc() {
        return dateDesc;
    }

    public void setDateDesc(String dateDesc) {
        this.dateDesc = dateDesc;
    }

    public String getError() {
        return error;
    }

    public void setError(String error) {
        this.error = error;
    }

    public List<UnderZeroCalculationVO> getItems() {
        return items;
    }

    public void setItems(List<UnderZeroCalculationVO> items) {
        this.items = items;
    }
}
