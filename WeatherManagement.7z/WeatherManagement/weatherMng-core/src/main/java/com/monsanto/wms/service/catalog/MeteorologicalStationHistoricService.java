package com.monsanto.wms.service.catalog;

import com.monsanto.wms.persistence.model.MeteorologicalStationHistoric;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.text.ParseException;
import java.util.Date;

/**
 * Created by GFRAN1 on 10/31/2014.
 */
public interface MeteorologicalStationHistoricService {
    Page<MeteorologicalStationHistoric> search(Long metStationId, Date startDate,Date endDate,Pageable pageable) throws ParseException;
}
