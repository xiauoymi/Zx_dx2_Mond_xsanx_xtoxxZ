package com.monsanto.wms.service.tools.impl;

import com.monsanto.wms.dao.oracle.OracleFxDAO;
import com.monsanto.wms.dao.tools.CalculatorDAO;
import com.monsanto.wms.exceptions.CalculatorException;
import com.monsanto.wms.persistence.model.MeteorologicalStationHistoric;
import com.monsanto.wms.service.tools.CalculatorService;
import com.monsanto.wms.vo.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: MANIET
 * Date: 6/3/13
 * Time: 3:51 PM
 * To change this template use File | Settings | File Templates.
 */
@Service
public final class CalculatorServiceImpl implements CalculatorService {

    private CalculatorDAO calculatorDAO;
    private OracleFxDAO<Object> oracleFxDAO;

    @Autowired
    public CalculatorServiceImpl(CalculatorDAO calculatorDAO,OracleFxDAO<Object> oracleFxDAO) {
        this.calculatorDAO = calculatorDAO;
        this.oracleFxDAO = oracleFxDAO;
    }


    @Override
    public GeneralCalculationByGduVO getGeneralCalculationByGDU(Integer startYear,Integer endYear,Integer day,
                                                                Integer month,Long meteorologicalStationId,
                                                                Double value,Double tempMin,Double tempMax,String cropName) {

        GeneralCalculationByGduVO rs = new GeneralCalculationByGduVO(oracleFxDAO.executeFunction("getGeneralCalculationByGDU",startYear,
                                                                                                  endYear,day,month,meteorologicalStationId,
                                                                                                  value,tempMin,tempMax,cropName));

        if(rs.getItems().get(0).getError().length()>0){
            throw new CalculatorException(rs.getItems().get(0).getError());
        }

        return rs.getItems().get(0);

    }

    @Override
    public GeneralCalculationByDayVO getGeneralCalculationByDay(Integer startYear,Integer endYear,Integer day,Integer month,Long meteorologicalStationId,Integer value,Double tempMin, Double tempMax,String cropName) {

             GeneralCalculationByDayVO rs = new GeneralCalculationByDayVO(oracleFxDAO.executeFunction("getGeneralCalculationByDay",startYear,endYear,day,month,meteorologicalStationId,value,tempMin,tempMax,cropName));

        if(rs.getItems().get(0).getError().length()>0){
            throw new CalculatorException(rs.getItems().get(0).getError());
        }

        return rs.getItems().get(0);
    }

    @Override
    public PeriodToGDUsVO getPeriodToGDU(Integer startYear,Integer endYear,Integer startMonth, Integer startDay, Integer endMonth, Integer endDay,Long meteorologicalStationId,Double tempMin,Double tempMax,String cropName) {
         PeriodToGDUsVO rs = new PeriodToGDUsVO(oracleFxDAO.executeFunction("getPeriodToGDU",startYear,endYear,startMonth,endMonth,startDay,endDay,meteorologicalStationId,tempMin,tempMax,cropName));

        if(rs.getItems().get(0).getError().length()>0){
            throw new CalculatorException(rs.getItems().get(0).getError());
        }

        return rs.getItems().get(0);
    }

    @Override
    public List<WeekCalculationVO> getWeeklyCalculationByGDU(Integer startYear, Integer endYear, Integer month, Long meteorologicalStationId, Double value,Double tempMin,Double tempMax,String cropName) {
             WeekCalculationVO rs = new WeekCalculationVO(oracleFxDAO.executeFunction("getWeeklyCalculationByGDU",startYear,endYear,month,meteorologicalStationId,value,tempMin,tempMax,cropName));

        if(rs.getItems().get(0).getError().length()>0){
            throw new CalculatorException(rs.getItems().get(0).getError());
        }

        return rs.getItems();
    }

    @Override
    public List<WeekCalculationVO> getWeeklyCalculationByDay(Integer startYear, Integer endYear, Integer month, Long meteorologicalStationId,Integer value,String cropName) {
             WeekCalculationVO rs = new WeekCalculationVO(oracleFxDAO.executeFunction("getWeeklyCalculationByDay",startYear,endYear,month,meteorologicalStationId,value,cropName));


        String errorFound = checkForError(rs.getItems());
        if(errorFound.length()>0){
            throw new CalculatorException(errorFound);
        }

        return rs.getItems();
    }

    private String checkForError(List<WeekCalculationVO> ls){
      for(WeekCalculationVO currentItem : ls){
           if(currentItem.getError().length()>0){
               return currentItem.getError();

           }
      }
       return "";
    }

    @Override
    public List<UnderZeroCalculationVO> getUnderZeroCalculation(Integer year, Integer month,Long meteorologicalStationId ) {

        UnderZeroCalculationVO rs = new UnderZeroCalculationVO(oracleFxDAO.executeFunction("getUnderZeroCalculation",year,month,meteorologicalStationId));

        if(rs.getItems().get(0).getError().length()>0){
            throw new CalculatorException(rs.getItems().get(0).getError());
        }

        return rs.getItems();
    }

}