package com.monsanto.wms.service.mail;

import com.monsanto.wms.exceptions.WMSException;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: FJSIBA
 * Date: 13/11/12
 * Time: 09:11 AM
 * To change this template use File | Settings | File Templates.
 */
public interface MailService {
    void sendMailMessage(String subject,String to,String msg, String template) throws WMSException;
}
