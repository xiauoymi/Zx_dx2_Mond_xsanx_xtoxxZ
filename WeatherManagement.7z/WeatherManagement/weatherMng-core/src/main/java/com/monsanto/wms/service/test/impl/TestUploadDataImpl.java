package com.monsanto.wms.service.test.impl;

import com.monsanto.wms.service.test.TestUploadDataService;
import org.springframework.stereotype.Service;

/**
 * Created by IntelliJ IDEA.
 * User: MANIET
 * Date: 5/29/13
 * Time: 12:31 PM
 * To change this template use File | Settings | File Templates.
 */
@Service
public class TestUploadDataImpl implements TestUploadDataService {
/*
     private ExcelListenerManager excelListenerManager;
     private ExcelTransformerInvoker excelTransformerInvoker;

    @Autowired
    public TestUploadDataImpl(ExcelListenerManager excelListenerManager,ExcelTransformerInvoker excelTransformerInvoker) {
        this.excelListenerManager = excelListenerManager;
        this.excelTransformerInvoker = excelTransformerInvoker;
    }

    @Override
    public FileLoadResultVO importData(InputStream inputStream) {
        FileLoadResultVO fileLoadResultVO = new FileLoadResultVO();
        ExcelListener listener = excelListenerManager.createTestXLSReading();


        excelTransformerInvoker.invoke(inputStream, listener);
        InvokerResult result = listener.getInvokerResult();

        fileLoadResultVO.setInsertedRows(result.getInsertedRows());
        fileLoadResultVO.setUpdatedRows(0L);


        return fileLoadResultVO;
    }
    */
}
