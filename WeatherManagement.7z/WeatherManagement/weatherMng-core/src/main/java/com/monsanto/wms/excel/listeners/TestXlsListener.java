package com.monsanto.wms.excel.listeners;

import com.monsanto.wms.excel.listeners.xlsRows.TestXlsRow;
import com.monsanto.wms.excel.manager.base.WMSReadingXLSCore;
import com.monsanto.wms.excel.manager.invokers.InvokerResult;
import com.monsanto.wms.exceptions.excel.ExcelLoadErrorException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;

import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Set;



/**
 * Created by IntelliJ IDEA.
 * User: MANIET
 * Date: 1/2/13
 * Time: 10:48 AM
 * To change this template use File | Settings | File Templates.
 */
public class TestXlsListener extends WMSReadingXLSCore {

    private static final Logger log = LoggerFactory.getLogger(TestXlsListener.class);

    private MessageSource messageSource;

    public TestXlsListener() {
        this.COLUMNS = 4;
    }

    @Autowired
    public TestXlsListener(MessageSource messageSource){

        this.messageSource = messageSource;
        this.invokerResult = new InvokerResult();
        this.COLUMNS = 4;

    }

    @Override
    protected void processColumns(int rowNumber, List<Object> row) {

        int index = 0;
        TestXlsRow testXlsRow = new TestXlsRow();
        Object string1 = row.get(index++);
        testXlsRow.setString1(string1!=null ? String.valueOf(string1):null);
        testXlsRow.setNumber(Double.parseDouble(String.valueOf(row.get(index++))));
        testXlsRow.setDate(new Date(String.valueOf(row.get(index++))));
        testXlsRow.setFormula(String.valueOf(row.get(index++)));

        invokerResult.increment();

    }



}
