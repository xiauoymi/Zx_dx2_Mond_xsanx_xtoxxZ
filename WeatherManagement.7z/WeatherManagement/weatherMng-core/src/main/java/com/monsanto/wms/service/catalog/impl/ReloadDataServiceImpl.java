package com.monsanto.wms.service.catalog.impl;

import com.monsanto.wms.dao.catalog.DataLoaderStagingDAO;
import com.monsanto.wms.dao.catalog.ErrorLogViewDAO;
import com.monsanto.wms.dao.oracle.OracleFxDAO;
import com.monsanto.wms.dao.sheduleTasks.MeteorologicalStationHistoricInfoDAO;
import com.monsanto.wms.persistence.model.DataLoaderStaging;
import com.monsanto.wms.persistence.model.ErrorLogView;
import com.monsanto.wms.persistence.model.MeteorologicalStation;
import com.monsanto.wms.persistence.model.MeteorologicalStationHistoric;
import com.monsanto.wms.service.catalog.MeteorologicalStationService;
import com.monsanto.wms.service.catalog.ReloadDataService;
import com.monsanto.wms.service.mail.MailService;
import com.monsanto.wms.service.security.UserSystemPrivilegesService;
import com.monsanto.wms.service.sheduleTasks.ScheduleErrorService;
import com.monsanto.wms.spectrum.SpectrumRemoteFileProcess;
import com.monsanto.wms.util.WMSServiceUtil;
import org.hibernate.exception.SQLGrammarException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.util.Date;
import java.util.List;


/**
 * Created with IntelliJ IDEA.
 * User: GFRAN1
 * Date: 7/21/14
 * Time: 12:38 PM
 * To change this template use File | Settings | File Templates.
 */
@Service
public class ReloadDataServiceImpl implements ReloadDataService{

    public static final String GET_BATCH_ID = "getBatchId";
    public static final String ERROR = "ERROR";
    private OracleFxDAO<Object> oracleFxDAO;
    private MeteorologicalStationHistoricInfoDAO meteorologicalStationHistoricInfoDAO;
    private DataLoaderStagingDAO dataLoaderStagingDAO;
    private ErrorLogViewDAO errorLogViewDAO;
    private MeteorologicalStationService meteorologicalStationService;
    private MailService mailService;
    private UserSystemPrivilegesService userSystemPrivilegesService;
    private ScheduleErrorService errorService;


    @Autowired
    public ReloadDataServiceImpl(OracleFxDAO<Object> oracleFxDAO,MeteorologicalStationHistoricInfoDAO meteorologicalStationHistoricInfoDAO,DataLoaderStagingDAO dataLoaderStagingDAO,ErrorLogViewDAO errorLogViewDAO,MeteorologicalStationService meteorologicalStationService,MailService mailService,UserSystemPrivilegesService userSystemPrivilegesService,ScheduleErrorService errorService) {

        this.oracleFxDAO = oracleFxDAO;
        this.meteorologicalStationHistoricInfoDAO = meteorologicalStationHistoricInfoDAO;
        this.dataLoaderStagingDAO = dataLoaderStagingDAO;
        this.errorLogViewDAO = errorLogViewDAO;
        this.meteorologicalStationService = meteorologicalStationService;
        this.mailService = mailService;
        this.userSystemPrivilegesService = userSystemPrivilegesService;
        this.errorService = errorService;


    }

    @Override
    public List<MeteorologicalStationHistoric> getMeteorologicalHistoricData(Long metStationId, Integer day,Integer month, Integer year) {
        return meteorologicalStationHistoricInfoDAO.findByMeteorologicalStationIdAndDayOfTheMonthAndMonthAndYear(metStationId,day,month,year);
    }

    @Override
    public Long reloadMeteorologicalData(Long metStationId, Date date) throws IOException ,SQLGrammarException{
            MeteorologicalStation currentStation = meteorologicalStationService.findById(metStationId);
            SpectrumRemoteFileProcess spectrumRemoteFileProcess = new SpectrumRemoteFileProcess(meteorologicalStationService,mailService,userSystemPrivilegesService,errorService);
            List<DataLoaderStaging> stagingList = spectrumRemoteFileProcess.getFilteredHistoricList(currentStation,date);
        return executeReloadProcess(date, date, currentStation.getId(), stagingList);
    }

    @Override
    public Long executeReloadProcess(Date startDate, Date endDate, Long currentStationId, List<DataLoaderStaging> stagingList) {
        Long batchId = getBatchId();
         saveStagingData(stagingList,batchId);
        List rs=  oracleFxDAO.executeFunction("reloadData", currentStationId,startDate,endDate, WMSServiceUtil.getCurrentUser().getId(),batchId);
        return rs.get(0).toString().equals("0") ?0L:batchId ;
    }


    @Override
    public Page<ErrorLogView> getErrorsDataLoader(Long batchId, Pageable page) {
        Page<ErrorLogView> errorLogViews = errorLogViewDAO.findByWmsDataLoaderIdAndStatus(batchId, ERROR,page);
        return errorLogViews;
    }


    @Override
    public void saveStagingData(List<DataLoaderStaging> dataLoaderStagingList, Long batchId) {
        for (DataLoaderStaging dataLoaderStaging : dataLoaderStagingList) {
                dataLoaderStaging.setWmsDataLoaderId(batchId);
            dataLoaderStagingDAO.saveAndFlush(dataLoaderStaging);
        }

    }

    private Long getBatchId(){
        List rs= oracleFxDAO.executeFunction(GET_BATCH_ID);
        return rs.get(0) !=null?  Long.parseLong(rs.get(0).toString()):0L;
    }

}