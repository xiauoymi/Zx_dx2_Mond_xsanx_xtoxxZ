package com.monsanto.wms.exceptions;

/**
 * Created by IntelliJ IDEA.
 * User: RBERN
 * Date: 29/11/12
 * To change this template use File | Settings | File Templates.
 */
public class CatalogException extends WMSException {

    public CatalogException(String message) {
        super(message);
    }

    
}
