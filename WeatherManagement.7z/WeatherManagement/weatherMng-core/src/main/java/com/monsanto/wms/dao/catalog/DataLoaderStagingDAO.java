package com.monsanto.wms.dao.catalog;

import com.monsanto.wms.persistence.model.DataLoaderStaging;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

/**
 * Created by GFRAN1 on 9/3/2014.
 */

@Repository
public interface DataLoaderStagingDAO extends JpaRepository<DataLoaderStaging, String> {

}
