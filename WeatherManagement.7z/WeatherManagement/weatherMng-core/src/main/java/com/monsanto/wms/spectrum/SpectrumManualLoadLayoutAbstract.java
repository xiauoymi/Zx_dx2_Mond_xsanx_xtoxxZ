package com.monsanto.wms.spectrum;

/**
 * Created by GFRAN1 on 9/9/2014.
 */
public abstract class SpectrumManualLoadLayoutAbstract {

    public static final int DATE_TIME =0;
    public static final int SOLAR_RADIATION=1;
    public static final int HUMIDITY=2;
    public static final int TEMPERATURE = 3;
    public static final int RAINFALL=4;
    public static final int WIND_DIRECTION=5;
    public static final int WIND_GUST=6;
    public static final int WIND_SPEED =7;
    public static final int DEW_POINT=8;

}
