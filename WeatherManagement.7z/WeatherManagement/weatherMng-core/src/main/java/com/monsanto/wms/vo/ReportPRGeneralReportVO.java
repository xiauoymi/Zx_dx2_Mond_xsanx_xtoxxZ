package com.monsanto.wms.vo;

import com.monsanto.wms.util.WMSServiceUtil;
import org.aspectj.weaver.patterns.ThisOrTargetAnnotationPointcut;
import org.hibernate.mapping.Index;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/**
 * Created by IntelliJ IDEA.
 * User: MANIET
 * Date: 6/21/13
 * Time: 12:28 PM
 * To change this template use File | Settings | File Templates.
 */
public class ReportPRGeneralReportVO {

    private final Integer INDEX_DATE = 0;
    private final Integer INDEX_TEMP_MIN = 1;
    private final Integer INDEX_TEMP_MAX = 2;
    private final Integer INDEX_GDUS = 3;
    private final Integer INDEX_GDU_ACUM = 4;
    private final Integer INDEX_DAMP_MIN = 5;
    private final Integer INDEX_DAMP_MAX = 6;
    private final Integer INDEX_PRECIPITATION = 7;
    private final Integer INDEX_WIND_MIN = 8;
    private final Integer INDEX_WIND_MAX = 9;
    private final Integer INDEX_RADIATION = 10;
    private final Integer INDEX_PERIODS_UNDER = 11;
    private final Integer INDEX_PERIODS_ABOVE = 12;
    private final Integer INDEX_WIND_7_7= 13;
    private final Integer INDEX_EVO_TRANSPIRATION = 14;
    private final Integer INDEX_LONGITUDE = 15;
    private final Integer INDEX_LATITUDE = 16;

    private String dateStr;
    private Double tempMinF;
    private Double tempMaxF;
    private Double tempMinC;
    private Double tempMaxC;
    private Double gdus;
    private Double gduAcum;
    private Double dampMin;
    private Double dampMax;
    private Double periodsUnder;
    private Double periodsAbove;
    private Double precipitation;
    private Double evoTranspiration;
    private Double windSpeedMax;
    private Double windSpeedMin;
    private Double windAVGBetween7And17Hrs;
    private Double radiation;
    private String longitude;
    private String latitude;


    private String error;

    private List<ReportPRGeneralReportVO> items;

    public ReportPRGeneralReportVO() {
    }

    public ReportPRGeneralReportVO(List objects) {
        items = new ArrayList<ReportPRGeneralReportVO>();

        for(Object currentObject : objects){
          Object[] currentItem = (Object[])currentObject;
          items.add(new ReportPRGeneralReportVO(String.valueOf(currentItem[INDEX_DATE]),
                  Double.parseDouble(String.valueOf(currentItem[INDEX_TEMP_MIN])),
                  Double.parseDouble(String.valueOf(currentItem[INDEX_TEMP_MAX])),
                  Double.parseDouble(String.valueOf(currentItem[INDEX_GDUS])),
                  Double.parseDouble(String.valueOf(currentItem[INDEX_GDU_ACUM])),
                  Double.parseDouble(String.valueOf(currentItem[INDEX_DAMP_MIN])),
                  Double.parseDouble(String.valueOf(currentItem[INDEX_DAMP_MAX])),
                  Double.parseDouble(String.valueOf(currentItem[INDEX_PERIODS_UNDER])),
                  Double.parseDouble(String.valueOf(currentItem[INDEX_PERIODS_ABOVE])),
                  Double.parseDouble(String.valueOf(currentItem[INDEX_PRECIPITATION])),
                  Double.parseDouble(String.valueOf(currentItem[INDEX_EVO_TRANSPIRATION])),
                  Double.parseDouble(String.valueOf(currentItem[INDEX_WIND_MIN])),
                  Double.parseDouble(String.valueOf(currentItem[INDEX_WIND_MAX])),
                  Double.parseDouble(String.valueOf(currentItem[INDEX_WIND_7_7])),
                  Double.parseDouble(String.valueOf(currentItem[INDEX_RADIATION])),
                  String.valueOf(currentItem[INDEX_LONGITUDE]),
                  String.valueOf(currentItem[INDEX_LATITUDE])));
        }
    }

    public ReportPRGeneralReportVO(String dateStr, Double tempMinC, Double tempMaxC,
                                   Double gdus, Double gduAcum,Double dampMin, Double dampMax, Double periodsUnder,
                                   Double periodsAbove, Double precipitation, Double evoTranspiration,
                                   Double windSpeedMin, Double windSpeedMax,
                                   Double windAVGBetween7And17Hrs, Double radiation,String longitude,String latitude) {
        this.dateStr = dateStr;
        this.tempMinC = tempMinC;
        this.tempMaxC = tempMaxC;
        this.gdus = gdus;
        this.gduAcum = gduAcum;
        this.dampMin = dampMin;
        this.dampMax = dampMax;
        this.periodsUnder = periodsUnder;
        this.periodsAbove = periodsAbove;
        this.precipitation = precipitation;
        this.evoTranspiration = evoTranspiration;
        this.windSpeedMax = windSpeedMax;
        this.windSpeedMin = windSpeedMin;
        this.windAVGBetween7And17Hrs = windAVGBetween7And17Hrs;
        this.radiation = radiation;
        this.longitude = longitude;
        this.latitude =latitude;

    }

    public String getDateStr() {
        try {
            Date d = new SimpleDateFormat("yyyy-MM-dd").parse(dateStr.substring(0,10));
            dateStr = new SimpleDateFormat("dd-MM-yyyy").format(d);

        } catch (ParseException e) {
            e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
        }
        return dateStr;
    }

    public void setDateStr(String dateStr) {
        this.dateStr = dateStr;
    }

   public Double getTempMinF() {
         if(tempMinC!=null){
            this.tempMinF = WMSServiceUtil.celsiusToFahrenheit(this.tempMinC);
        }
        return tempMinF;
    }

    public void setTempMinF(Double tempMinF) {
        this.tempMinF = tempMinF;
    }

    public Double getTempMaxF() {
         if(tempMaxC!=null){
            this.tempMaxF = WMSServiceUtil.celsiusToFahrenheit(this.tempMaxC);
        }
        return tempMaxF;
    }

    public void setTempMaxF(Double tempMaxF) {
        this.tempMaxF = tempMaxF;
    }

    public Double getTempMinC(){
        return tempMinC;
    }

    public void setTempMinC(Double tempMinC) {
        this.tempMinC = tempMinC;
    }

    public Double getTempMaxC() {
        return tempMaxC;
    }

    public void setTempMaxC(Double tempMaxC) {
        this.tempMaxC = tempMaxC;
    }

    public Double getGdus() {
        return gdus;
    }

    public void setGdus(Double gdus) {
        this.gdus = gdus;
    }

    public Double getGduAcum() {
        return gduAcum;
    }

    public void setGduAcum(Double gduAcum) {
        this.gduAcum = gduAcum;
    }

    public Double getDampMin() {
        return dampMin;
    }

    public void setDampMin(Double dampMin) {
        this.dampMin = dampMin;
    }

    public Double getDampMax() {
        return dampMax;
    }

    public void setDampMax(Double dampMax) {
        this.dampMax = dampMax;
    }

    public Double getPrecipitation() {
        return precipitation;
    }

    public void setPrecipitation(Double precipitation) {
        this.precipitation = precipitation;
    }

    public Double getEvoTranspiration() {
        return evoTranspiration;
    }

    public void setEvoTranspiration(Double evoTranspiration) {
        this.evoTranspiration = evoTranspiration;
    }

    public List<ReportPRGeneralReportVO> getItems() {
        return items;
    }

    public Double getPeriodsUnder() {
        return periodsUnder;
    }

    public void setPeriodsUnder(Double periodsUnder) {
        this.periodsUnder = periodsUnder;
    }

    public Double getPeriodsAbove() {
        return periodsAbove;
    }

    public void setPeriodsAbove(Double periodsAbove) {
        this.periodsAbove = periodsAbove;
    }

    public Double getWindSpeedMax() {
        return windSpeedMax;
    }

    public void setWindSpeedMax(Double windSpeedMax) {
        this.windSpeedMax = windSpeedMax;
    }

    public Double getWindSpeedMin() {
        return windSpeedMin;
    }

    public void setWindSpeedMin(Double windSpeedMin) {
        this.windSpeedMin = windSpeedMin;
    }

    public Double getWindAVGBetween7And17Hrs() {
        return windAVGBetween7And17Hrs;
    }

    public void setWindAVGBetween7And17Hrs(Double windAVGBetween7And17Hrs) {
        this.windAVGBetween7And17Hrs = windAVGBetween7And17Hrs;
    }

    public Double getRadiation() {
        return radiation;
    }

    public void setRadiation(Double radiation) {
        this.radiation = radiation;
    }

    public String getLongitude() {
        return longitude;
    }

    public void setLongitude(String longitude) {
        this.longitude = longitude;
    }

    public String getLatitude() {
        return latitude;
    }

    public void setLatitude(String latitude) {
        this.latitude = latitude;
    }

    public void setItems(List<ReportPRGeneralReportVO> items) {
        this.items = items;
    }

    public String getError() {
        return error;
    }

    public void setError(String error) {
        this.error = error;
    }


}
