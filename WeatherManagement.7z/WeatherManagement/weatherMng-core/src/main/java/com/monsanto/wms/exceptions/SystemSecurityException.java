package com.monsanto.wms.exceptions;

/**
 * Created by IntelliJ IDEA.
 * User: RBERN
 * Date: 29/11/12
 * To change this template use File | Settings | File Templates.
 */
public class SystemSecurityException extends WMSException {

    public SystemSecurityException(String message) {
        super(message);
    }

}
