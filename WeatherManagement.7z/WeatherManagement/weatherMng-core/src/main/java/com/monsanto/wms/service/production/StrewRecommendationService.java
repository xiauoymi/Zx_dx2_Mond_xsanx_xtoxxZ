package com.monsanto.wms.service.production;

import com.monsanto.wms.persistence.model.StrewRecommendation;
import com.monsanto.wms.persistence.model.StrewRecommendationDetail;
import com.monsanto.wms.vo.RealReportStrewRecommendationVO;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: MANIET
 * Date: 6/3/13
 * Time: 3:51 PM
 * To change this template use File | Settings | File Templates.
 */
public interface StrewRecommendationService {

    Page<StrewRecommendation> search(Long productionZoneId, Long productionCycleId,Long hybridId, String sourceCode, Pageable pageable);
    StrewRecommendation save(StrewRecommendation strewRecommendation);
    void saveDetail(List<StrewRecommendationDetail> detail);
    StrewRecommendation findById(Long id);
    void deleteDetail(Long strewRecommendationId);
    void delete(Long strewRecommendationId);
    List<RealReportStrewRecommendationVO> getRealReport(Integer startYear, Integer endYear, Integer day, Integer month, Long meteorologicalStationId,Double tempMin, Double tempMax,String cropStagesGDUs,String cropName);
}
