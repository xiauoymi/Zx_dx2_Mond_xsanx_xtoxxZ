package com.monsanto.wms.dao.ldap.impl;

import com.monsanto.wms.vo.LdapUserVO;
import org.springframework.ldap.core.AttributesMapper;

import javax.naming.NamingException;
import javax.naming.directory.Attribute;
import javax.naming.directory.Attributes;

/**
 * Monsanto
 * Author: Luis Miguel Arteaga Rios (lmarte@monsanto.com)
 * Date: 29/11/12
 * Time: 05:13 PM
 */
public class LdapUserAttributesMapper implements AttributesMapper {

    public static final String ATTRIBUTE_CN           = "cn";
    public static final String ATTRIBUTE_DISPLAY_NAME = "displayName";
    public static final String ATTRIBUTE_EMAIL        = "mail";
    public static final String[] RETURNING_ATTRIBUTES = { ATTRIBUTE_CN, ATTRIBUTE_DISPLAY_NAME, ATTRIBUTE_EMAIL };

    public Object mapFromAttributes( Attributes attributes ) throws NamingException {

        LdapUserVO user = new LdapUserVO();

        user.setId(     getAttributeAsString(attributes.get(ATTRIBUTE_CN)) );
        user.setName(   getAttributeAsString(attributes.get(ATTRIBUTE_DISPLAY_NAME)) );
        user.setEmail(  getAttributeAsString(attributes.get(ATTRIBUTE_EMAIL)) );

        return user;
    }

    private String getAttributeAsString( Attribute attribute ) throws NamingException{

        if( attribute != null && attribute.get() != null ){

            return attribute.get().toString();
        }

        return null;
    }
}