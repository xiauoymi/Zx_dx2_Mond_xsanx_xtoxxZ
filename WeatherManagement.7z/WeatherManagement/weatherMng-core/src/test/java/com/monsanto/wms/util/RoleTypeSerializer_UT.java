package com.monsanto.wms.util;

import org.codehaus.jackson.JsonGenerator;
import org.codehaus.jackson.map.SerializerProvider;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.io.IOException;

/**
 * Monsanto
 * Author: MANIET
 * Date: 6/12/12
 * Time: 04:20 PM
 */
@RunWith(MockitoJUnitRunner.class)
public class RoleTypeSerializer_UT {

    RoleTypeSerializer serializer;

    @Mock
    JsonGenerator generator;

    @Mock
    SerializerProvider provider;

    @Test
    public void serialize() throws IOException {

        serializer = new RoleTypeSerializer();

        serializer.serialize( RoleType.ROLE_SUPER_ADMIN, generator, provider );
    }
}
