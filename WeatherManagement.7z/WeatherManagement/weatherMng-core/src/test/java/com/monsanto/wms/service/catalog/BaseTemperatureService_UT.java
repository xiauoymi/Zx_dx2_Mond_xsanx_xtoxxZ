package com.monsanto.wms.service.catalog;

import com.monsanto.wms.dao.catalog.BaseTemperatureDAO;
import com.monsanto.wms.persistence.model.BaseTemperature;
import com.monsanto.wms.service.catalog.impl.BaseTemperatureServiceImpl;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import static junit.framework.Assert.assertNotNull;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyBoolean;
import static org.mockito.Matchers.anyLong;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.*;

/**
 * Created by IntelliJ IDEA.
 * User: MANIET
 * Date: 6/6/13
 * Time: 3:41 PM
 * To change this template use File | Settings | File Templates.
 */
@RunWith(MockitoJUnitRunner.class)
public class BaseTemperatureService_UT {

    @Mock
    private BaseTemperatureDAO dao;

    private BaseTemperatureService service;

    @Before
    public void setUp() {
        service = new BaseTemperatureServiceImpl(dao);
    }

    @Test
    public void searchCropAndType(){
        Page page = mock(Page.class);
        Pageable pageable = mock(Pageable.class);

        when(dao.findByCropTypeIdAndCropIdAndTempminLikeAndTempmaxLikeAndActive(anyLong(),anyLong(),anyString(), anyString(),anyBoolean(),any(Pageable.class))).thenReturn(page);

        assertNotNull(service.search(1L, 1L, "", "", false, pageable));

        verify(dao).findByCropTypeIdAndCropIdAndTempminLikeAndTempmaxLikeAndActive(1L,1L,"%%", "%%", false, pageable);
    }

    @Test
    public void searchByType(){
        Page page = mock(Page.class);
        Pageable pageable = mock(Pageable.class);

        when(dao.findByCropTypeIdAndTempminLikeAndTempmaxLikeAndActive(anyLong(),anyString(), anyString(),anyBoolean(),any(Pageable.class))).thenReturn(page);

        assertNotNull(service.search(-1L, 1L, "", "", false, pageable));

        verify(dao).findByCropTypeIdAndTempminLikeAndTempmaxLikeAndActive(1L,"%%", "%%", false, pageable);
    }

    @Test
    public void searchByCrop(){
        Page page = mock(Page.class);
        Pageable pageable = mock(Pageable.class);

        when(dao.findByCropIdAndTempminLikeAndTempmaxLikeAndActive(anyLong(),anyString(), anyString(),anyBoolean(),any(Pageable.class))).thenReturn(page);

        assertNotNull(service.search(1L, -1L, "", "", false, pageable));

        verify(dao).findByCropIdAndTempminLikeAndTempmaxLikeAndActive(1L,"%%", "%%", false, pageable);
    }

    @Test
    public void searchByCropNull(){
        Pageable pageable = mock(Pageable.class);
        assertNotNull(service.search(null, 1L, "", "", false, pageable));
    }

    @Test
    public void searchByCropTypeNull(){
        Pageable pageable = mock(Pageable.class);
        assertNotNull(service.search(1L, null, "", "", false, pageable));
    }

     @Test
    public void searchByAllValuesNull(){
        Pageable pageable = mock(Pageable.class);
        assertNotNull(service.search(null, null, "", "", false, pageable));
    }

      @Test
    public void searchByAllValuesUnderZero(){
        Pageable pageable = mock(Pageable.class);
        Page page = mock(Page.class);
        when(dao.findByActive(anyBoolean(),any(Pageable.class))).thenReturn(page);
        assertNotNull(service.search(-1L, -1L, "", "", false, pageable));
    }

    @Test
    public void findById(){

        when(dao.findOne(anyLong())).thenReturn(new BaseTemperature());

        assertNotNull(service.findById(anyLong()));

        verify(dao).findOne(anyLong());
    }

    @Test
    public void delete(){
        service.delete(anyLong());
        verify(dao).delete(anyLong());
    }

    @Test
    public void save(){

        when(dao.saveAndFlush(any(BaseTemperature.class))).thenReturn(new BaseTemperature());

        assertNotNull(service.save(any(BaseTemperature.class)));

        verify(dao).saveAndFlush(any(BaseTemperature.class));
    }

}
