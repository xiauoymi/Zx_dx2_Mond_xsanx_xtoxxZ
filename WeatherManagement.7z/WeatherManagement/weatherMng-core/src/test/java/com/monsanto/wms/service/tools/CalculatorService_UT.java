package com.monsanto.wms.service.tools;

import com.monsanto.wms.dao.oracle.OracleFxDAO;
import com.monsanto.wms.dao.tools.CalculatorDAO;
import com.monsanto.wms.exceptions.CalculatorException;

import com.monsanto.wms.service.tools.impl.CalculatorServiceImpl;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.List;

import static junit.framework.Assert.assertNotNull;

import static org.mockito.Mockito.*;

/**
 * Created by IntelliJ IDEA.
 * User: MANIET
 * Date: 6/6/13
 * Time: 3:41 PM
 * To change this template use File | Settings | File Templates.
 */
@RunWith(MockitoJUnitRunner.class)
public class CalculatorService_UT {

    @Mock
    private CalculatorDAO dao;

    @Mock
    private OracleFxDAO<Object> oracleFxDAO;

    private CalculatorService service;

    @Before
    public void setUp() {
        service = new CalculatorServiceImpl(dao,oracleFxDAO);
    }

    @Test
    public void getGeneralCalculationByGDUWithData(){
        List<Object> ls = new ArrayList<Object>();
        Object[] obj = {1D,1D,1,1,1D,""};
        ls.add(obj);
        when(oracleFxDAO.executeFunction("getGeneralCalculationByGDU",1,1,1,1,1L,1D,1D,1D,"CropName")).thenReturn(ls);

        assertNotNull(service.getGeneralCalculationByGDU(1, 1, 1, 1, 1L, 1D,1D,1D,"CropName"));

        verify(oracleFxDAO).executeFunction("getGeneralCalculationByGDU", 1, 1, 1, 1, 1L,1D,1D,1D,"CropName");
    }

    @Test (expected = CalculatorException.class)
    public void getGeneralCalculationByGDUWithError(){
        List<Object> ls = new ArrayList<Object>();
        Object[] obj = {1D,1D,1,1,1D,"ORA-10001"};
        ls.add(obj);
        when(oracleFxDAO.executeFunction("getGeneralCalculationByGDU",1,1,1,1,1L,1D,1D,1D,"CropName")).thenReturn(ls);

        assertNotNull(service.getGeneralCalculationByGDU(1,1,1,1,1L,1D,1D,1D,"CropName"));

        verify(oracleFxDAO).executeFunction("getGeneralCalculationByGDU",1,1,1,1,1L,1D,1D,1D,"CropName");
    }

    @Test
      public void getGeneralCalculationByDayWithData(){
          List<Object> ls = new ArrayList<Object>();
          Object[] obj = {1D,1D,1,1,1D,""};
          ls.add(obj);
          when(oracleFxDAO.executeFunction("getGeneralCalculationByDay",1,1,1,1,1L,1,1D,1D,"CropName")).thenReturn(ls);

          assertNotNull(service.getGeneralCalculationByDay(1, 1, 1, 1, 1L, 1,1D,1D,"CropName"));

          verify(oracleFxDAO).executeFunction("getGeneralCalculationByDay", 1, 1, 1, 1, 1L, 1,1D,1D,"CropName");
      }

     @Test (expected = CalculatorException.class)
      public void getGeneralCalculationByDayWithError(){
          List<Object> ls = new ArrayList<Object>();
          Object[] obj = {1D,1D,1,1,1D,1D,"ORA-10001"};
          ls.add(obj);
          when(oracleFxDAO.executeFunction("getGeneralCalculationByDay",1,1,1,1,1L,1,1D,1D,"CropName")).thenReturn(ls);

          assertNotNull(service.getGeneralCalculationByDay(1, 1, 1, 1, 1L, 1,1D,1D,"CropName"));

          verify(oracleFxDAO).executeFunction("getGeneralCalculationByDay", 1, 1, 1, 1, 1L, 1,1D,1D,"CropName");
      }

    @Test
      public void getUnderZeroCalculationWithData(){
          List<Object> ls = new ArrayList<Object>();
          Object[] obj = {1D,"",""};
          ls.add(obj);
          when(oracleFxDAO.executeFunction("getUnderZeroCalculation",2013,1,1L)).thenReturn(ls);

          assertNotNull(service.getUnderZeroCalculation(2013,1,1L));

          verify(oracleFxDAO).executeFunction("getUnderZeroCalculation", 2013,1,1L);
      }

    @Test(expected = CalculatorException.class)
    public void getUnderZeroCalculationWithError() {
        List<Object> ls = new ArrayList<Object>();
          Object[] obj = {1D,"01/01/2010","ORA-10001"};
          ls.add(obj);
          when(oracleFxDAO.executeFunction("getUnderZeroCalculation",2013,1,1L)).thenReturn(ls);

          assertNotNull(service.getUnderZeroCalculation(2013,1,1L));

          verify(oracleFxDAO).executeFunction("getUnderZeroCalculation", 2013,1,1L);
    }

    @Test
    public void getWeeklyCalculationByGDUWithData(){
        List<Object> ls = new ArrayList<Object>();
        Object[] obj = {1,1D,1D,1,1,""};
        ls.add(obj);
        when(oracleFxDAO.executeFunction("getWeeklyCalculationByGDU",1,1,1,1L,1D,1D,1D,"CropName")).thenReturn(ls);

        assertNotNull(service.getWeeklyCalculationByGDU(1, 1,  1, 1L, 1D,1D,1D,"CropName"));

        verify(oracleFxDAO).executeFunction("getWeeklyCalculationByGDU", 1, 1, 1, 1L, 1D,1D,1D,"CropName");
    }

    @Test (expected = CalculatorException.class)
    public void getWeeklyCalculationByGDUWithError(){
        List<Object> ls = new ArrayList<Object>();
        Object[] obj = {1,1D,1D,1,1,"ORA-10001"};
        ls.add(obj);
        when(oracleFxDAO.executeFunction("getWeeklyCalculationByGDU",1,1,1,1L,1D,1D,1D,"CropName")).thenReturn(ls);

        assertNotNull(service.getWeeklyCalculationByGDU(1,1,1,1L,1D,1D,1D,"CropName"));

        verify(oracleFxDAO).executeFunction("getWeeklyCalculationByGDU",1,1,1,1L,1D,1D,1D,"CropName");
    }

     @Test
    public void getWeeklyCalculationByDayWithData(){
        List<Object> ls = new ArrayList<Object>();
        Object[] obj = {1,1D,1D,1,1,""};
        ls.add(obj);
        when(oracleFxDAO.executeFunction("getWeeklyCalculationByDay",1,1,1,1L,1,"CropName")).thenReturn(ls);

        assertNotNull(service.getWeeklyCalculationByDay(1, 1,  1, 1L, 1,"CropName"));

        verify(oracleFxDAO).executeFunction("getWeeklyCalculationByDay", 1, 1, 1, 1L, 1,"CropName");
    }

    @Test (expected = CalculatorException.class)
    public void getWeeklyCalculationByDayWithError(){
        List<Object> ls = new ArrayList<Object>();
        Object[] obj = {1,1D,1D,1,1,"ORA-10001"};
        ls.add(obj);
        when(oracleFxDAO.executeFunction("getWeeklyCalculationByDay",1,1,1,1L,1,"CropName")).thenReturn(ls);

        assertNotNull(service.getWeeklyCalculationByDay(1, 1,  1, 1L, 1,"CropName"));

        verify(oracleFxDAO).executeFunction("getWeeklyCalculationByDay", 1, 1, 1, 1L, 1,"CropName");
    }

    @Test
    public void getPeriodToGDUWithData(){
        List<Object> ls = new ArrayList<Object>();
        Object[] obj = {1,""};
        ls.add(obj);
        when(oracleFxDAO.executeFunction("getPeriodToGDU",1,1,1,1,1,1,1L,1D,1D,"CropName")).thenReturn(ls);

        assertNotNull(service.getPeriodToGDU(1,1,1,1,1,1,1L,1D,1D,"CropName"));

        verify(oracleFxDAO).executeFunction("getPeriodToGDU",1,1,1,1,1,1,1L,1D,1D,"CropName");
    }

    @Test (expected = CalculatorException.class)
    public void getPeriodToGDUWithError(){
        List<Object> ls = new ArrayList<Object>();
        Object[] obj = {1,"ORA-10002"};
        ls.add(obj);
        when(oracleFxDAO.executeFunction("getPeriodToGDU",1,1,1,1,1,1,1L,1D,1D,"CropName")).thenReturn(ls);

        assertNotNull(service.getPeriodToGDU(1,1,1,1,1,1,1L,1D,1D,"CropName"));

        verify(oracleFxDAO).executeFunction("getPeriodToGDU",1,1,1,1,1,1,1L,1D,1D,"CropName");
    }


}
