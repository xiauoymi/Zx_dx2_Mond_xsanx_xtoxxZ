package com.monsanto.wms.spectrum;

import com.monsanto.wms.persistence.model.MeteorologicalStation;
import com.monsanto.wms.spectrum.helpers.SpectrumDateUtils;
import org.apache.commons.lang.time.DateFormatUtils;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.mock;

/**
 * Created with IntelliJ IDEA.
 * User: MANIET
 * Date: 10/11/13
 * Time: 9:28 AM
 * To change this template use File | Settings | File Templates.
 */
@RunWith(MockitoJUnitRunner.class)
public class SpectrumSelectCurrentDateData_UT {


    @Test
    public void selectCurrentDateDataWhenThisExist() throws ParseException {

        MeteorologicalStation station = new MeteorologicalStation(1L);
        SpectrumSelectCurrentDateData spectrumCurrentDateData = new SpectrumSelectCurrentDateData(createCorrectBufferedMeteorologicalStationDataWithCurrentDate(),station);

        List<SpectrumValidatedMeteorologicalStationHistory> ls = spectrumCurrentDateData.getData();
        int listSize = ls.size();

        assertEquals(1, listSize);
        assertFalse(ls.get(0).getValidator().isAnIncorrectRegistryFounded());

    }


    @Test
    public void selectCurrentDateDataWhenThisIsUnavailable(){

        MeteorologicalStation station = new MeteorologicalStation(1L);
        SpectrumSelectCurrentDateData spectrumCurrentDateData = new SpectrumSelectCurrentDateData(createCorrectBufferedMeteorologicalStationDataWithNoCurrentDate(),station);

        List<SpectrumValidatedMeteorologicalStationHistory> ls = spectrumCurrentDateData.getData();
        int listSize = ls.size();

        assertEquals(0, listSize);


    }

    @Test
    public void failOfReadingWhenDataIsIncomplete() throws ParseException {

        MeteorologicalStation station = new MeteorologicalStation(1L);
        SpectrumSelectCurrentDateData spectrumCurrentDateData = new SpectrumSelectCurrentDateData(createIncompleteBufferedMeteorologicalStationData(),station);

        List<SpectrumValidatedMeteorologicalStationHistory> ls = spectrumCurrentDateData.getData();
        int listSize = ls.size();

        assertEquals(1, listSize);
        assertEquals(ls.get(0).getValidator().getErrorList().get(0).getMessage(),"Invalid Buffer Registry size:13  Expected:29");
        assertTrue(ls.get(0).getValidator().isAnIncorrectRegistryFounded());



    }

    @Test
    public void failOfReadingWhenRegistryTimeHasAnInvalidFormat(){

        MeteorologicalStation station = new MeteorologicalStation(1L);
        SpectrumSelectCurrentDateData spectrumCurrentDateData = new SpectrumSelectCurrentDateData(createCorrectBufferedMeteorologicalStationDataWithInvalidRegistryTimeFormat(),station);

        List<SpectrumValidatedMeteorologicalStationHistory> ls = spectrumCurrentDateData.getData();
        int listSize = ls.size();

        assertEquals(0, listSize);

    }

    @Test
    public void failOfReadingWhenRegistryNumericDataIsInvalid() throws ParseException {

        MeteorologicalStation station = new MeteorologicalStation(1L);
        SpectrumSelectCurrentDateData spectrumCurrentDateData = new SpectrumSelectCurrentDateData(createCorrectBufferedMeteorologicalStationDataWithCurrentDateAndInvalidNumericData(),station);

        List<SpectrumValidatedMeteorologicalStationHistory> ls = spectrumCurrentDateData.getData();
        int listSize = ls.size();

        assertEquals(1, listSize);
        assertEquals(ls.get(0).getValidator().getErrorList().get(0).getMessage(),"Invalid numeric data:");
        assertTrue(ls.get(0).getValidator().isAnIncorrectRegistryFounded());



    }
  /*
    @Test
    public void readingFromRealSampleFile() throws IOException {
        InputStream inputStream = new ClassPathResource(".csv").getInputStream();
        InputStreamReader inputStreamReader = new InputStreamReader(inputStream);

        SpectrumSelectCurrentDateData spectrumCurrentDateData = new SpectrumSelectCurrentDateData(SpectrumBufferReader.toList(inputStreamReader),new MeteorologicalStation(1L));
        List<SpectrumValidatedMeteorologicalStationHistory> ls = spectrumCurrentDateData.getData();

        MeteorologicalStationService meteorologicalStationService = mock(MeteorologicalStationService.class);
        ScheduleErrorService scheduleErrorService = mock(ScheduleErrorService.class);

        SpectrumStoreData spectrumStoreData = new SpectrumStoreData(meteorologicalStationService,scheduleErrorService,ls);
        spectrumStoreData.save();
    }
     */
    private List<String[]> createCorrectBufferedMeteorologicalStationDataWithCurrentDate() throws ParseException {
        int index=0;
        List<String[]> ls = new ArrayList<String[]>();

        String[] stringFormBufferWithOutErrors = new String[29];

        String currentDate = SpectrumDateUtils.getDayBeforeOfCurrentDateAsString();


        stringFormBufferWithOutErrors[index++] = "290005206";
        stringFormBufferWithOutErrors[index++] = currentDate;
        stringFormBufferWithOutErrors[index++] = "26.8";
        stringFormBufferWithOutErrors[index++] = "13.5";
        stringFormBufferWithOutErrors[index++] = "10/1/2013  07:45";

        stringFormBufferWithOutErrors[index++] = "31.4";
        stringFormBufferWithOutErrors[index++] = "10/1/2013  13:30";
        stringFormBufferWithOutErrors[index++] = "28.2";
        stringFormBufferWithOutErrors[index++] = "19";
        stringFormBufferWithOutErrors[index++] = "10/1/2013  11:15";

        stringFormBufferWithOutErrors[index++] = "68.6";
        stringFormBufferWithOutErrors[index++] = "10/1/2013  08:00";
        stringFormBufferWithOutErrors[index++] = "31";
        stringFormBufferWithOutErrors[index++] = "0";
        stringFormBufferWithOutErrors[index++] = "135";

        stringFormBufferWithOutErrors[index++] = "1";
        stringFormBufferWithOutErrors[index++] = "1";
        stringFormBufferWithOutErrors[index++] = "6.85";
        stringFormBufferWithOutErrors[index++] = "2.78";
        stringFormBufferWithOutErrors[index++] = "10/1/2013  11:15";

        stringFormBufferWithOutErrors[index++] = "9.3";
        stringFormBufferWithOutErrors[index++] = "10/1/2013  09:15";
        stringFormBufferWithOutErrors[index++] = "26.23";
        stringFormBufferWithOutErrors[index++] = "12.68";
        stringFormBufferWithOutErrors[index++] = "10/1/2013  07:45";

        stringFormBufferWithOutErrors[index++] = "0";
        stringFormBufferWithOutErrors[index++] = "10/1/2013  13:30";
        stringFormBufferWithOutErrors[index++] = "0";
        stringFormBufferWithOutErrors[index++] = "10/1/2013  17:15";

        ls.add(stringFormBufferWithOutErrors);

        return ls;
    }

    private List<String[]> createCorrectBufferedMeteorologicalStationDataWithNoCurrentDate(){
        int index=0;
        List<String[]> ls = new ArrayList<String[]>();

        String[] stringFormBufferWithOutErrors = new String[29];

        stringFormBufferWithOutErrors[index++] = "290005206";
        stringFormBufferWithOutErrors[index++] = "10/1/2013 07:45";
        stringFormBufferWithOutErrors[index++] = "26.8";
        stringFormBufferWithOutErrors[index++] = "13.5";
        stringFormBufferWithOutErrors[index++] = "10/1/2013 07:45";

        stringFormBufferWithOutErrors[index++] = "31.4";
        stringFormBufferWithOutErrors[index++] = "10/1/2013 13:30";
        stringFormBufferWithOutErrors[index++] = "28.2";
        stringFormBufferWithOutErrors[index++] = "19";
        stringFormBufferWithOutErrors[index++] = "10/1/2013 11:15";

        stringFormBufferWithOutErrors[index++] = "68.6";
        stringFormBufferWithOutErrors[index++] = "10/1/2013 08:00";
        stringFormBufferWithOutErrors[index++] = "31";
        stringFormBufferWithOutErrors[index++] = "0";
        stringFormBufferWithOutErrors[index++] = "135";

        stringFormBufferWithOutErrors[index++] = "1";
        stringFormBufferWithOutErrors[index++] = "1";
        stringFormBufferWithOutErrors[index++] = "6.85";
        stringFormBufferWithOutErrors[index++] = "2.78";
        stringFormBufferWithOutErrors[index++] = "10/1/2013 11:15";

        stringFormBufferWithOutErrors[index++] = "9.3";
        stringFormBufferWithOutErrors[index++] = "10/1/2013 09:15";
        stringFormBufferWithOutErrors[index++] = "26.23";
        stringFormBufferWithOutErrors[index++] = "12.68";
        stringFormBufferWithOutErrors[index++] = "10/1/2013 07:45";

        stringFormBufferWithOutErrors[index++] = "0";
        stringFormBufferWithOutErrors[index++] = "10/1/2013 13:30";
        stringFormBufferWithOutErrors[index++] = "0";
        stringFormBufferWithOutErrors[index++] = "10/1/2013 17:15";

        ls.add(stringFormBufferWithOutErrors);

        return ls;
    }

    private List<String[]> createIncompleteBufferedMeteorologicalStationData() throws ParseException {
        int index=0;
        List<String[]> ls = new ArrayList<String[]>();

        String[] stringFormatWithIncompleteBuffer= new String[13];
        String currentDate = SpectrumDateUtils.getDayBeforeOfCurrentDateAsString();
        stringFormatWithIncompleteBuffer[index++] = "290005206";
        stringFormatWithIncompleteBuffer[index++] = currentDate;
        stringFormatWithIncompleteBuffer[index++] = "26.8";
        stringFormatWithIncompleteBuffer[index++] = "13.5";
        stringFormatWithIncompleteBuffer[index++] = "10/1/2013 07:45";

        stringFormatWithIncompleteBuffer[index++] = "9.3";
        stringFormatWithIncompleteBuffer[index++] = "10/1/2013 09:15";
        stringFormatWithIncompleteBuffer[index++] = "26.23";
        stringFormatWithIncompleteBuffer[index++] = "12.68";
        stringFormatWithIncompleteBuffer[index++] = "10/1/2013 07:45";

        stringFormatWithIncompleteBuffer[index++] = "10/1/2013 13:30";
        stringFormatWithIncompleteBuffer[index++] = "0";
        stringFormatWithIncompleteBuffer[index++] = "10/1/2013 17:15";

        ls.add(stringFormatWithIncompleteBuffer);

        return ls;
    }

    private List<String[]> createCorrectBufferedMeteorologicalStationDataWithInvalidRegistryTimeFormat(){
        int index=0;
        List<String[]> ls = new ArrayList<String[]>();

        String[] stringFormatBufferMeteorologicalStationDataWithAnInvalidTimeFormat = new String[29];

        String currentDate = DateFormatUtils.format(new Date(), "dd-MM");

        stringFormatBufferMeteorologicalStationDataWithAnInvalidTimeFormat[index++] = "290005206";
        stringFormatBufferMeteorologicalStationDataWithAnInvalidTimeFormat[index++] = currentDate;
        stringFormatBufferMeteorologicalStationDataWithAnInvalidTimeFormat[index++] = "26.8";
        stringFormatBufferMeteorologicalStationDataWithAnInvalidTimeFormat[index++] = "13.5";
        stringFormatBufferMeteorologicalStationDataWithAnInvalidTimeFormat[index++] = "10/1/2013  07:45";

        stringFormatBufferMeteorologicalStationDataWithAnInvalidTimeFormat[index++] = "31.4";
        stringFormatBufferMeteorologicalStationDataWithAnInvalidTimeFormat[index++] = "10/1/2013  13:30";
        stringFormatBufferMeteorologicalStationDataWithAnInvalidTimeFormat[index++] = "28.2";
        stringFormatBufferMeteorologicalStationDataWithAnInvalidTimeFormat[index++] = "19";
        stringFormatBufferMeteorologicalStationDataWithAnInvalidTimeFormat[index++] = "10/1/2013  11:15";

        stringFormatBufferMeteorologicalStationDataWithAnInvalidTimeFormat[index++] = "68.6";
        stringFormatBufferMeteorologicalStationDataWithAnInvalidTimeFormat[index++] = "10/1/2013  08:00";
        stringFormatBufferMeteorologicalStationDataWithAnInvalidTimeFormat[index++] = "31";
        stringFormatBufferMeteorologicalStationDataWithAnInvalidTimeFormat[index++] = "0";
        stringFormatBufferMeteorologicalStationDataWithAnInvalidTimeFormat[index++] = "135";

        stringFormatBufferMeteorologicalStationDataWithAnInvalidTimeFormat[index++] = "1";
        stringFormatBufferMeteorologicalStationDataWithAnInvalidTimeFormat[index++] = "1";
        stringFormatBufferMeteorologicalStationDataWithAnInvalidTimeFormat[index++] = "6.85";
        stringFormatBufferMeteorologicalStationDataWithAnInvalidTimeFormat[index++] = "2.78";
        stringFormatBufferMeteorologicalStationDataWithAnInvalidTimeFormat[index++] = "10/1/2013  11:15";

        stringFormatBufferMeteorologicalStationDataWithAnInvalidTimeFormat[index++] = "9.3";
        stringFormatBufferMeteorologicalStationDataWithAnInvalidTimeFormat[index++] = "10/1/2013  09:15";
        stringFormatBufferMeteorologicalStationDataWithAnInvalidTimeFormat[index++] = "26.23";
        stringFormatBufferMeteorologicalStationDataWithAnInvalidTimeFormat[index++] = "12.68";
        stringFormatBufferMeteorologicalStationDataWithAnInvalidTimeFormat[index++] = "10/1/2013  07:45";

        stringFormatBufferMeteorologicalStationDataWithAnInvalidTimeFormat[index++] = "0";
        stringFormatBufferMeteorologicalStationDataWithAnInvalidTimeFormat[index++] = "10/1/2013  13:30";
        stringFormatBufferMeteorologicalStationDataWithAnInvalidTimeFormat[index++] = "0";
        stringFormatBufferMeteorologicalStationDataWithAnInvalidTimeFormat[index++] = "10/1/2013  17:15";

        ls.add(stringFormatBufferMeteorologicalStationDataWithAnInvalidTimeFormat);

        return ls;
    }

    private List<String[]> createCorrectBufferedMeteorologicalStationDataWithCurrentDateAndInvalidNumericData() throws ParseException {
        int index=0;
        List<String[]> ls = new ArrayList<String[]>();

        String[] stringFormBufferWithOutErrors = new String[29];

        String currentDate = SpectrumDateUtils.getDayBeforeOfCurrentDateAsString();

        stringFormBufferWithOutErrors[index++] = "290005206";
        stringFormBufferWithOutErrors[index++] = currentDate;
        stringFormBufferWithOutErrors[index++] = "";
        stringFormBufferWithOutErrors[index++] = "";
        stringFormBufferWithOutErrors[index++] = "10/1/2013  07:45";

        stringFormBufferWithOutErrors[index++] = "31.4";
        stringFormBufferWithOutErrors[index++] = "10/1/2013  13:30";
        stringFormBufferWithOutErrors[index++] = "28.2";
        stringFormBufferWithOutErrors[index++] = "19";
        stringFormBufferWithOutErrors[index++] = "10/1/2013  11:15";

        stringFormBufferWithOutErrors[index++] = "68.6";
        stringFormBufferWithOutErrors[index++] = "10/1/2013  08:00";
        stringFormBufferWithOutErrors[index++] = "31";
        stringFormBufferWithOutErrors[index++] = "0";
        stringFormBufferWithOutErrors[index++] = "135";

        stringFormBufferWithOutErrors[index++] = "1";
        stringFormBufferWithOutErrors[index++] = "1";
        stringFormBufferWithOutErrors[index++] = "6.85";
        stringFormBufferWithOutErrors[index++] = "2.78";
        stringFormBufferWithOutErrors[index++] = "10/1/2013  11:15";

        stringFormBufferWithOutErrors[index++] = "9.3";
        stringFormBufferWithOutErrors[index++] = "10/1/2013  09:15";
        stringFormBufferWithOutErrors[index++] = "26.23";
        stringFormBufferWithOutErrors[index++] = "12.68";
        stringFormBufferWithOutErrors[index++] = "10/1/2013  07:45";

        stringFormBufferWithOutErrors[index++] = "10/1/2013  13:30";
        stringFormBufferWithOutErrors[index++] = "0";
        stringFormBufferWithOutErrors[index++] = "10/1/2013  17:15";

        ls.add(stringFormBufferWithOutErrors);

        return ls;
    }
}
