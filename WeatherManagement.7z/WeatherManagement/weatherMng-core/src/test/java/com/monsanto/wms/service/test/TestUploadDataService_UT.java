package com.monsanto.wms.service.test;

import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;

/**
 * Created by IntelliJ IDEA.
 * User: MANIET
 * Date: 5/29/13
 * Time: 1:28 PM
 * To change this template use File | Settings | File Templates.
 */
@RunWith(MockitoJUnitRunner.class)
public class TestUploadDataService_UT {
/*
    @Mock
    private ExcelListenerManager excelListenerManager;

    @Mock
    private ExcelTransformerInvoker excelTransformerInvoker;

    private TestUploadDataService service;

    private static FileInputStream file;

    @BeforeClass
    public static void loadKeys() throws Exception {
        String fileLocationOK = Thread.currentThread().getContextClassLoader().getResource("testInputDataFileOK.xls").getFile();
        file = new FileInputStream(fileLocationOK);
    }

    @Before
    public void setUp(){
        service = new TestUploadDataImpl(excelListenerManager,excelTransformerInvoker);
    }

    @Test
    public void importDataSuccess() throws Throwable{

        InvokerResult result = new InvokerResult();
        result.setInsertedRows( 1L );
        ExcelListener listener = mock(TestXlsListener.class);

        when( excelListenerManager.createTestXLSReading()).thenReturn(listener);
        when( listener.getInvokerResult() ).thenReturn( result );

        service.importData(file);

        verify( excelListenerManager ).createTestXLSReading();
        verify( excelTransformerInvoker ).invoke( any( InputStream.class ), any( ExcelListener.class ) );
    }

    @Test
    public void importDataWithOutRecords() throws Throwable{

        InvokerResult result = new InvokerResult();
        result.setInsertedRows( 0L );
        ExcelListener listener = mock(TestXlsListener.class);

        when( excelListenerManager.createTestXLSReading() ).thenReturn( listener );
        when( listener.getInvokerResult() ).thenReturn( result );

        service.importData(file);

       verify( excelListenerManager ).createTestXLSReading();
       verify( excelTransformerInvoker ).invoke( any( InputStream.class ), any( ExcelListener.class ) );

    }
*/
}
