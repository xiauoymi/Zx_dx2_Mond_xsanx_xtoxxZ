package com.monsanto.wms.excel.manager;


import com.monsanto.wms.excel.listeners.TestXlsListener;
import com.monsanto.wms.excel.manager.invokers.ExcelTransformerInvoker;
import com.monsanto.wms.excel.manager.invokers.ExcelTransformerInvokerImpl;
import com.monsanto.wms.exceptions.excel.ExcelLoadErrorException;
import org.apache.poi.hssf.record.Record;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import static org.mockito.Mockito.*;

/**
 * Created by IntelliJ IDEA.
 * User: ACISS
 * Date: 3/10/12
 * Time: 02:45 PM
 */

@RunWith(MockitoJUnitRunner.class)
public class ExcelTransformerInvoker_UT {

    private ExcelTransformerInvoker service;

    private static FileInputStream file;

    private static File invalidFile;


    @BeforeClass
    public static void loadKeys() throws Exception {
        String fileLocation = Thread.currentThread().getContextClassLoader().getResource("testInputDataFile.xls").getFile();
        file = new FileInputStream(fileLocation);
    }

    @Test
    public void testExcelLoading() {
        service = new ExcelTransformerInvokerImpl();
        service.invoke(file, createListener());
    }

    private HSSFCoreListener createListener() {
        HSSFCoreListener l = spy(new TestXlsListener());
        doNothing().when(l).processRow(anyInt(), anyListOf(Object.class), anyString());
        doCallRealMethod().when(l).processRecord(Matchers.<Record>any());
        return l;
    }

    @Test(expected=ExcelLoadErrorException.class)
    public void testInvokerMustThrowException() {
        HSSFCoreListener l = spy(new TestXlsListener());
        doThrow(IOException.class).when(l).processRow(anyInt(), anyListOf(Object.class), anyString());
        service = new ExcelTransformerInvokerImpl();
        service.invoke(file, l);
    }
}
