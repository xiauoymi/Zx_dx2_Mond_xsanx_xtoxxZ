package com.monsanto.wms.util;

import com.monsanto.wms.persistence.model.User;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;

import static org.junit.Assert.*;
import static org.mockito.Mockito.mock;

/**
 * Created by IntelliJ IDEA.
 * User: MANIET
 * Date: 6/14/13
 * Time: 9:05 AM
 * To change this template use File | Settings | File Templates.
 */
@RunWith(MockitoJUnitRunner.class)
public class WMSServiceUtil_UT {

    @Test
       public void getCurrentUser() {

        User user = mock(User.class);

        Authentication authentication = new UsernamePasswordAuthenticationToken("TEST", "DUMMY");
         ((UsernamePasswordAuthenticationToken) authentication).setDetails(user);

        SecurityContextHolder.getContext().setAuthentication(authentication);

        User result = WMSServiceUtil.getCurrentUser();

         assertNotNull(result);

       }
    @Test
       public void getCurrentUserNull() {
           User user = mock(User.class);
           Authentication authentication = new UsernamePasswordAuthenticationToken("TEST", "DUMMY");
           ((UsernamePasswordAuthenticationToken) authentication).setDetails(user);
           SecurityContextHolder.getContext().setAuthentication(null);

           User result = WMSServiceUtil.getCurrentUser();

           assertNull(result);

       }

    @Test
    public void fahrenheitToCelsius(){
        Double celsius = WMSServiceUtil.fahrenheitToCelsius(68D);
        assertEquals(celsius,new Double("20"));
    }


    @Test
    public void celsiusToFahrenheit(){
        Double celsius = WMSServiceUtil.celsiusToFahrenheit(20D);
        assertEquals(celsius,new Double("68"));
    }

    @Test
         public void getFormattedDateTest(){
        String dateFormatted= WMSServiceUtil.getFormattedDate("2013-09-15 00:00","yyyy-MM-dd", "dd/MM/yyyy");
        assertEquals(dateFormatted,"15/09/2013");
    }

}
