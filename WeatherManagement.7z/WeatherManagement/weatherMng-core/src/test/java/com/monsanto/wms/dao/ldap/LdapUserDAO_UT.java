package com.monsanto.wms.dao.ldap;


import com.monsanto.wms.dao.ldap.impl.LdapUserDAOImpl;
import com.monsanto.wms.vo.LdapUserVO;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.ldap.LimitExceededException;
import org.springframework.ldap.core.LdapTemplate;
import org.springframework.ldap.core.NameClassPairCallbackHandler;

import javax.naming.directory.SearchControls;
import java.util.Collection;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.*;

/**
 * Monsanto
 * Author: Luis Miguel Arteaga Rios (lmarte@monsanto.com)
 * Date: 29/11/12
 * Time: 05:38 PM
 */
@RunWith(MockitoJUnitRunner.class)
public class LdapUserDAO_UT {

    @Mock
    LdapTemplate ldapTemplate;

    LdapUserDAO ldapUserDAO;

    @Before
    public void setUp(){
        ldapUserDAO = new LdapUserDAOImpl( ldapTemplate );
        ((LdapUserDAOImpl)ldapUserDAO).setQueryById( "find{0}" );
        ((LdapUserDAOImpl)ldapUserDAO).setSearchBase( "" );
    }

    @Test
    public void findByIdLike(){

        Throwable test = new LimitExceededException( mock( javax.naming.LimitExceededException.class) );

        doThrow( test ).when(ldapTemplate).search(anyString(), anyString(), any(SearchControls.class), any(NameClassPairCallbackHandler.class));

        Collection<LdapUserVO> users = ldapUserDAO.findByIdLike("LMARTE");

        assertNotNull( users );

        verify( ldapTemplate ).search(  anyString(), anyString(), any( SearchControls.class ), any( NameClassPairCallbackHandler.class ) );
    }

    @Test
    public void authenticated(){

        when(ldapTemplate.authenticate("", "(&(objectclass=person)(!(objectclass=computer))(cn=USER_ID))","PASSWORD")).thenReturn(true);
        assertTrue(ldapUserDAO.authenticated("USER_ID","PASSWORD"));

        verify( ldapTemplate).authenticate("", "(&(objectclass=person)(!(objectclass=computer))(cn=USER_ID))","PASSWORD");
    }

}
