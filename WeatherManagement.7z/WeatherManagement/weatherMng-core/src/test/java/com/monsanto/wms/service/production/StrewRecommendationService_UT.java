package com.monsanto.wms.service.production;

import com.monsanto.wms.dao.catalog.BaseTemperatureDAO;
import com.monsanto.wms.dao.oracle.OracleFxDAO;
import com.monsanto.wms.dao.production.StrewRecommendationDAO;
import com.monsanto.wms.dao.production.StrewRecommendationDetailDAO;
import com.monsanto.wms.exceptions.WMSException;
import com.monsanto.wms.persistence.model.BaseTemperature;
import com.monsanto.wms.persistence.model.StrewRecommendation;
import com.monsanto.wms.persistence.model.StrewRecommendationDetail;
import com.monsanto.wms.service.catalog.BaseTemperatureService;
import com.monsanto.wms.service.catalog.impl.BaseTemperatureServiceImpl;
import com.monsanto.wms.service.production.impl.StrewRecommendationServiceImpl;
import com.monsanto.wms.vo.RealReportStrewRecommendationVO;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.ArrayList;
import java.util.List;

import static junit.framework.Assert.assertNotNull;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyBoolean;
import static org.mockito.Matchers.anyLong;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.*;

/**
 * Created by IntelliJ IDEA.
 * User: MANIET
 * Date: 6/6/13
 * Time: 3:41 PM
 * To change this template use File | Settings | File Templates.
 */
@RunWith(MockitoJUnitRunner.class)
public class StrewRecommendationService_UT {


    @Mock
    private StrewRecommendationDAO strewRecommendationDAO;
    @Mock
    private StrewRecommendationDetailDAO strewRecommendationDetailDAO;
    @Mock
    private OracleFxDAO<Object> oracleFxDAO;

    private StrewRecommendationService service;

    @Before
    public void setUp() {
        service = new StrewRecommendationServiceImpl(strewRecommendationDAO,strewRecommendationDetailDAO,oracleFxDAO);
    }

    @Test
    public void searchWithAllFields(){
        Page page = mock(Page.class);
        Pageable pageable = mock(Pageable.class);

        when(strewRecommendationDAO.findByProductionZoneIdAndProductionCyclesIdAndHybridIdAndSourceCode(1L,1L,1L,"",pageable)).thenReturn(page);

        assertNotNull(service.search(1L,1L,1L,"",pageable));

        verify(strewRecommendationDAO).findByProductionZoneIdAndProductionCyclesIdAndHybridIdAndSourceCode(1L,1L, 1L, "",pageable);
    }

     @Test
    public void searchWitNonOfTheFields(){
        Page page = mock(Page.class);
        Pageable pageable = mock(Pageable.class);

        when(strewRecommendationDAO.findBySourceCode("",pageable)).thenReturn(page);

        assertNotNull(service.search(-1L,-1L,-1L,"",pageable));

        verify(strewRecommendationDAO).findBySourceCode("",pageable);
    }

    @Test
    public void searchWithProductionZoneAndProductionCycle(){
        Page page = mock(Page.class);
        Pageable pageable = mock(Pageable.class);

        when(strewRecommendationDAO.findByProductionZoneIdAndProductionCyclesIdAndSourceCode(1L,1L,"",pageable)).thenReturn(page);

        assertNotNull(service.search(1L,1L,-1L,"",pageable));

        verify(strewRecommendationDAO).findByProductionZoneIdAndProductionCyclesIdAndSourceCode(1L, 1L, "",pageable);
    }

     @Test
    public void searchWithProductionZone(){
        Page page = mock(Page.class);
        Pageable pageable = mock(Pageable.class);

        when(strewRecommendationDAO.findByProductionZoneIdAndSourceCode(1L,"",pageable)).thenReturn(page);

        assertNotNull(service.search(1L,-1L,-1L,"",pageable));

        verify(strewRecommendationDAO).findByProductionZoneIdAndSourceCode(1L,"", pageable);
    }



    @Test
    public void searchWithProductionCycleAndHybrid(){
        Page page = mock(Page.class);
        Pageable pageable = mock(Pageable.class);

        when(strewRecommendationDAO.findByProductionCyclesIdAndHybridIdAndSourceCode(1L, 1L, "", pageable)).thenReturn(page);

        assertNotNull(service.search(-1L,1L,1L,"",pageable));

        verify(strewRecommendationDAO).findByProductionCyclesIdAndHybridIdAndSourceCode(1L, 1L, "",pageable);
    }

    @Test
    public void searchWithProductionCycle(){
        Page page = mock(Page.class);
        Pageable pageable = mock(Pageable.class);

        when(strewRecommendationDAO.findByProductionCyclesIdAndSourceCode(1L,"",pageable)).thenReturn(page);

        assertNotNull(service.search(-1L,1L,-1L,"",pageable));

        verify(strewRecommendationDAO).findByProductionCyclesIdAndSourceCode(1L, "",pageable);
    }



    @Test
    public void searchWithHybrid(){
        Page page = mock(Page.class);
        Pageable pageable = mock(Pageable.class);

        when(strewRecommendationDAO.findByHybridIdAndSourceCode(1L, "", pageable)).thenReturn(page);

        assertNotNull(service.search(-1L,-1L,1L,"",pageable));

        verify(strewRecommendationDAO).findByHybridIdAndSourceCode(1L, "",pageable);
    }

    @Test
    public void searchWithProductionZoneIdNull(){
        Pageable pageable = mock(Pageable.class);
        assertNotNull(service.search(null,1L,1L,"",pageable));
    }

    @Test
    public void searchWithProductionCycleIdNull(){
        Pageable pageable = mock(Pageable.class);
        assertNotNull(service.search(1L,null,1L,"",pageable));
    }

    @Test
    public void searchWithHybridIdNull(){
        Pageable pageable = mock(Pageable.class);
        assertNotNull(service.search(1L,1L,null,"",pageable));
    }

    @Test
    public void findById(){

        when(strewRecommendationDAO.findOne(anyLong())).thenReturn(new StrewRecommendation());

        assertNotNull(service.findById(anyLong()));

        verify(strewRecommendationDAO).findOne(anyLong());
    }

    @Test
    public void delete(){
        List<StrewRecommendationDetail> lsDetails = new ArrayList<StrewRecommendationDetail>();
        lsDetails.add(new StrewRecommendationDetail(1L));
        when(strewRecommendationDetailDAO.findByStrewRecommendationId(anyLong())).thenReturn(lsDetails);
        service.delete(anyLong());
        verify(strewRecommendationDAO).delete(anyLong());
    }

    @Test
    public void save(){

        when(strewRecommendationDAO.saveAndFlush(any(StrewRecommendation.class))).thenReturn(new StrewRecommendation());
        assertNotNull(service.save(any(StrewRecommendation.class)));
        verify(strewRecommendationDAO).saveAndFlush(any(StrewRecommendation.class));
    }

    @Test
    public void saveDetail(){
        List<StrewRecommendationDetail> lsDetails = new ArrayList<StrewRecommendationDetail>();
        StrewRecommendationDetail strewRecommendationDetail = new StrewRecommendationDetail(1L);
        strewRecommendationDetail.setStrewRecommendation(new StrewRecommendation(1L));
        lsDetails.add(strewRecommendationDetail);

        when(strewRecommendationDAO.saveAndFlush(any(StrewRecommendation.class))).thenReturn(new StrewRecommendation());
        when(strewRecommendationDetailDAO.findByStrewRecommendationId(anyLong())).thenReturn(lsDetails);
        service.saveDetail(lsDetails);

        verify(strewRecommendationDetailDAO).save(any(StrewRecommendationDetail.class));
        verify(strewRecommendationDetailDAO).findByStrewRecommendationId(anyLong());
        verify(strewRecommendationDetailDAO).delete(any(StrewRecommendationDetail.class));

    }

    @Test
    public void saveEmptyDetail(){
        List<StrewRecommendationDetail> lsDetails = new ArrayList<StrewRecommendationDetail>();

        when(strewRecommendationDAO.saveAndFlush(any(StrewRecommendation.class))).thenReturn(new StrewRecommendation());
        when(strewRecommendationDetailDAO.findByStrewRecommendationId(anyLong())).thenReturn(lsDetails);
        service.saveDetail(lsDetails);

    }

    @Test
    public void getRealReportSuccess(){
        List<Object> ls = new ArrayList<Object>();
        Object[] obj = {1,1,1,1D,1D,1D,1D,"",""};
        ls.add(obj);
        when(oracleFxDAO.executeFunction("getRealReport", 1, 1, 1, 1, 1L, 1D, 1D, "[190-11]","CropName")).thenReturn(ls);
        assertNotNull(service.getRealReport(1, 1, 1, 1, 1L, 1D, 1D, "[190-11]","CropName"));
        verify(oracleFxDAO).executeFunction("getRealReport",1, 1, 1, 1, 1L, 1D, 1D, "[190-11]","CropName");

    }

     @Test(expected = WMSException.class)
    public void getRealReportError(){
        List<Object> ls = new ArrayList<Object>();
        Object[] obj = {1,1,1,1D,1D,1D,1D,"","ORACLE-10100"};
        ls.add(obj);
        when(oracleFxDAO.executeFunction("getRealReport", 1, 1, 1, 1, 1L, 1D, 1D, "[190-11]","CropName")).thenReturn(ls);
        assertNotNull(service.getRealReport(1, 1, 1, 1, 1L, 1D, 1D, "[190-11]","CropName"));
        verify(oracleFxDAO).executeFunction("getRealReport",1, 1, 1, 1, 1L, 1D, 1D, "[190-11]","CropName");

    }

   @Test
    public void getRealReportYearNull(){
        List<Object> ls = new ArrayList<Object>();
        Object[] obj = {1,1,1D,1D,1D,1D,"",""};
        ls.add(obj);
        assertNotNull(service.getRealReport(null, 1, 1, 1, 1L, 1D, 1D, "[190-11]","CropName"));

    }

     @Test
    public void getRealReportYearUnderZero(){
        List<Object> ls = new ArrayList<Object>();
        Object[] obj = {1,1,1D,1D,1D,1D,"",""};
        ls.add(obj);
        assertNotNull(service.getRealReport(-1, 1, 1, 1, 1L, 1D, 1D, "[190-11]","CropName"));

    }

    @Test
    public void getRealReportYearEndNull(){
        List<Object> ls = new ArrayList<Object>();
        Object[] obj = {1,1,1D,1D,1D,1D,"",""};
        ls.add(obj);
        assertNotNull(service.getRealReport(1, null, 1, 1, 1L, 1D, 1D, "[190-11]","CropName"));

    }

     @Test
    public void getRealReportYeaEndrUnderZero(){
        List<Object> ls = new ArrayList<Object>();
        Object[] obj = {1,1,1D,1D,1D,1D,"",""};
        ls.add(obj);
        assertNotNull(service.getRealReport(1, -1, 1, 1, 1L, 1D, 1D, "[190-11]","CropName"));

    }

    @Test
    public void getRealReportDayNull(){
        List<Object> ls = new ArrayList<Object>();
        Object[] obj = {1,1,1D,1D,1D,1D,"",""};
        ls.add(obj);
        assertNotNull(service.getRealReport(1, 1, null, 1, 1L, 1D, 1D, "[190-11]","CropName"));

    }

     @Test
    public void getRealReportDayUnderZero(){
        List<Object> ls = new ArrayList<Object>();
        Object[] obj = {1,1,1D,1D,1D,1D,"",""};
        ls.add(obj);
        assertNotNull(service.getRealReport(1, 1, -1, 1, 1L, 1D, 1D, "[190-11]","CropName"));

    }

    @Test
    public void getRealReportMonthNull(){
        List<Object> ls = new ArrayList<Object>();
        Object[] obj = {1,1,1D,1D,1D,1D,"",""};
        ls.add(obj);
        assertNotNull(service.getRealReport(1, 1, 1, null, 1L, 1D, 1D, "[190-11]","CropName"));

    }

     @Test
    public void getRealReportMonthUnderZero(){
        List<Object> ls = new ArrayList<Object>();
        Object[] obj = {1,1,1D,1D,1D,1D,"",""};
        ls.add(obj);
        assertNotNull(service.getRealReport(1, 1, 1, -1, 1L, 1D, 1D, "[190-11]","CropName"));

    }

      @Test
    public void getRealReportMetStationNull(){
        List<Object> ls = new ArrayList<Object>();
        Object[] obj = {1,1,1D,1D,1D,1D,"",""};
        ls.add(obj);
        assertNotNull(service.getRealReport(1, 1, 1, 1, null, 1D, 1D, "[190-11]","CropName"));

    }

     @Test
    public void getRealReportMetStationUnderZero(){
        List<Object> ls = new ArrayList<Object>();
        Object[] obj = {1,1,1D,1D,1D,1D,"",""};
        ls.add(obj);
        assertNotNull(service.getRealReport(1, 1, 1, 1, -1L, 1D, 1D, "[190-11]","CropName"));

    }

     @Test
    public void getRealReportTemMinNull(){
        List<Object> ls = new ArrayList<Object>();
        Object[] obj = {1,1,1D,1D,1D,1D,"",""};
        ls.add(obj);
        assertNotNull(service.getRealReport(1, 1, 1, 1, 1L, null, 1D, "[190-11]","CropName"));

    }

     @Test
    public void getRealReportTemMaxNull(){
        List<Object> ls = new ArrayList<Object>();
        Object[] obj = {1,1,1D,1D,1D,1D,"",""};
        ls.add(obj);
        assertNotNull(service.getRealReport(1, 1, 1, 1, 1L, 1D, null, "[190-11]","CropName"));

    }

    @Test
    public void getRealReportTemCropStagesGDUNull(){
        List<Object> ls = new ArrayList<Object>();
        Object[] obj = {1,1,1D,1D,1D,1D,"",""};
        ls.add(obj);
        assertNotNull(service.getRealReport(1, 1, 1, 1, 1L, 1D, 1D, null,"CropName"));

    }

    @Test
    public void getRealReportTemCropStagesGDUEmpty(){
        List<Object> ls = new ArrayList<Object>();
        Object[] obj = {1,1,1D,1D,1D,1D,"",""};
        ls.add(obj);
        assertNotNull(service.getRealReport(1, 1, 1, 1, 1L, 1D, 1D, "","CropName"));

    }


}
