package com.monsanto.wms.service.catalog;

import com.monsanto.wms.dao.catalog.CropDAO;
import com.monsanto.wms.persistence.model.Crop;
import com.monsanto.wms.service.catalog.impl.CropServiceImpl;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.Collections;

import static junit.framework.Assert.assertNotNull;
import static org.mockito.Matchers.*;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/**
 * Created by IntelliJ IDEA.
 * User: MANIET
 * Date: 6/6/13
 * Time: 3:41 PM
 * To change this template use File | Settings | File Templates.
 */
@RunWith(MockitoJUnitRunner.class)
public class CropService_UT {

    @Mock
    private CropDAO dao;

    private CropService service;

    @Before
    public void setUp() {
        service = new CropServiceImpl(dao);
    }

    @Test
    public void search(){
        Page page = mock(Page.class);
        Pageable pageable = mock(Pageable.class);

        when(dao.findByDescriptionLikeAndActiveAndTypeId(anyString(),anyBoolean(),anyLong(),any(Pageable.class))).thenReturn(page);

        assertNotNull(service.search("", false, 1L,pageable));

        verify(dao).findByDescriptionLikeAndActiveAndTypeId("%%",false,1L,pageable);
    }

    @Test
    public void searchDescriptionNull(){
        Page page = mock(Page.class);
        Pageable pageable = mock(Pageable.class);

        when(dao.findByDescriptionLikeAndActive(anyString(),anyBoolean(),any(Pageable.class))).thenReturn(page);

        assertNotNull(service.search(null, false, null, pageable));

        verify(dao).findByDescriptionLikeAndActive("%null%",false,pageable);
    }

    @Test
    public void searchCropTypeUnderZero(){
        Page page = mock(Page.class);
        Pageable pageable = mock(Pageable.class);

        when(dao.findByDescriptionLikeAndActive(anyString(),anyBoolean(),any(Pageable.class))).thenReturn(page);

        assertNotNull(service.search(null, false, -1L, pageable));

        verify(dao).findByDescriptionLikeAndActive("%null%",false,pageable);
    }

    @Test
    public void findById(){

        when(dao.findOne(anyLong())).thenReturn(new Crop());

        assertNotNull(service.findById(anyLong()));

        verify(dao).findOne(anyLong());
    }

    @Test
    public void delete(){
        service.delete(anyLong());
        verify(dao).delete(anyLong());
    }

    @Test
    public void save(){

        when(dao.saveAndFlush(any(Crop.class))).thenReturn(new Crop());

        assertNotNull(service.save(any(Crop.class)));

        verify(dao).saveAndFlush(any(Crop.class));
    }

     @Test
    public void loadCollection(){

        when(dao.findByActiveTrueOrderByDescriptionAsc()).thenReturn(Collections.EMPTY_LIST);

        assertNotNull(service.loadCollection());

        verify(dao).findByActiveTrueOrderByDescriptionAsc();
    }

       @Test
    public void loadCollectionByParent(){

        when(dao.findByTypeIdAndActiveTrueOrderByDescriptionAsc(anyLong())).thenReturn(Collections.EMPTY_LIST);

        assertNotNull(service.loadCollectionByParent(anyLong()));

        verify(dao).findByTypeIdAndActiveTrueOrderByDescriptionAsc(anyLong());
    }


}
