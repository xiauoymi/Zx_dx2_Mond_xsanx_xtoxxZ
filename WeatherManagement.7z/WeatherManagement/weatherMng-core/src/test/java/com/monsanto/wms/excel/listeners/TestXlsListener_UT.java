package com.monsanto.wms.excel.listeners;

import com.monsanto.wms.excel.builder.CellBuilderVO;
import com.monsanto.wms.excel.manager.ExcelListener;
import com.monsanto.wms.excel.manager.invokers.ExcelTransformerInvoker;
import com.monsanto.wms.excel.manager.invokers.ExcelTransformerInvokerImpl;
import com.monsanto.wms.exceptions.WMSException;
import com.monsanto.wms.exceptions.excel.ExcelLoadErrorException;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.context.MessageSource;
import org.springframework.validation.Errors;

import java.io.*;

import static junit.framework.Assert.fail;
import static org.mockito.Mockito.*;

/**
 * Created by IntelliJ IDEA.
 * User: MANIET
 * Date: 1/4/13
 * Time: 12:41 PM
 * To change this template use File | Settings | File Templates.
 */
@RunWith(MockitoJUnitRunner.class)
public class TestXlsListener_UT {

    private ExcelTransformerInvoker excelTransformerInvoker;


    @Mock
    private MessageSource messageSource;


    private ExcelListener listener;

    private static FileInputStream fileFullTest;

    private static FileInputStream fileErrors;

    private static FileInputStream fileOutNumColsError;



     @BeforeClass
       public static void loadKeys() throws Exception {

         String fileLocationOK = Thread.currentThread().getContextClassLoader().getResource("testInputDataFileOK.xls").getFile();
         String fileLocationError = Thread.currentThread().getContextClassLoader().getResource("testInputDataFileErrors.xls").getFile();
         String fileLocationOutNumCol = Thread.currentThread().getContextClassLoader().getResource("testInputDataFileOutNumberCols.xls").getFile();

         fileFullTest = new FileInputStream(fileLocationOK);
         fileErrors = new FileInputStream(fileLocationError);
         fileOutNumColsError = new FileInputStream(fileLocationOutNumCol);

      }

      @Before
      public void setUp() {
          excelTransformerInvoker = new ExcelTransformerInvokerImpl();
          listener = new TestXlsListener(messageSource);


      }

      @Test
      public void testProcessColumnsSuccess() throws IOException{
         excelTransformerInvoker.invoke(fileFullTest, listener);
      }


      @Test
      public void validateRowWithValidateException()  throws IOException{
          try{
            excelTransformerInvoker.invoke(fileErrors, listener);
          }catch (WMSException e){
             e.printStackTrace();
          }

      }

      @Test
      public void validateRowWithOutNumColsException()  throws IOException{
          try{
            excelTransformerInvoker.invoke(fileOutNumColsError, listener);
          }catch (WMSException e){
             e.printStackTrace();
          }

      }

}
