package com.monsanto.wms.service.sheduleTasks;

import com.monsanto.wms.dao.sheduleTasks.ScheduleErrorDAO;
import com.monsanto.wms.persistence.model.MeteorologicalStation;
import com.monsanto.wms.persistence.model.ScheduleErrorLog;
import com.monsanto.wms.service.sheduleTasks.impl.ScheduleErrorServiceImpl;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;

import static junit.framework.Assert.assertEquals;
import static org.mockito.Mockito.*;

/**
 * Created with IntelliJ IDEA.
 * User: MANIET
 * Date: 10/16/13
 * Time: 8:14 AM
 * To change this template use File | Settings | File Templates.
 */
@RunWith(MockitoJUnitRunner.class)
public class ScheduleErrorService_UT {

    @Test
    public void saveScheduleErrorsFoundWhenBatchProcessOfSpectrum(){
        ScheduleErrorDAO dao = mock(ScheduleErrorDAO.class);
        ScheduleErrorService service = new ScheduleErrorServiceImpl(dao);
        String error ="SECTION - ERROR / ";

        ScheduleErrorLog errorLog =  new ScheduleErrorLog(error, new MeteorologicalStation());
        when(dao.save(errorLog)).thenReturn(errorLog);

        service.saveErrorLog(errorLog);

        verify(dao).save(errorLog);
        assertEquals(error,errorLog.getError());

    }

}
