package com.monsanto.wms.spectrum;

import com.monsanto.wms.persistence.model.MeteorologicalStation;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.core.io.ClassPathResource;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/**
 * Created with IntelliJ IDEA.
 * User: MANIET
 * Date: 10/12/13
 * Time: 8:04 AM
 * To change this template use File | Settings | File Templates.
 */
@RunWith(MockitoJUnitRunner.class)
public class SpectrumReadDataProcess_UT {

    private InputStreamReader inputStreamReader;

    @Before
    public void setup() throws IOException {
        InputStream inputStream = new ClassPathResource("spectrumTestFile.csv").getInputStream();
        inputStreamReader = new InputStreamReader(inputStream);
    }

    @Test
    public void startRemoteReadingProcessForSpectrumStations() throws IOException {
        SpectrumReadDataProcess readDataProcess = new SpectrumReadDataProcess();
        SpectrumRemoteFileReader remoteFileReader = mock(SpectrumRemoteFileReader.class);
        MeteorologicalStation station = mock(MeteorologicalStation.class);

        when(remoteFileReader.getInputStreamReader(false)).thenReturn(inputStreamReader);
        readDataProcess.startReading(remoteFileReader,false);


        verify(remoteFileReader).getInputStreamReader(false);

    }

}
