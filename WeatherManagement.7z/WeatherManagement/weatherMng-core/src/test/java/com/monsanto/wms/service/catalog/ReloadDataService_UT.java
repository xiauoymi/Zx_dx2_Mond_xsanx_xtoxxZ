package com.monsanto.wms.service.catalog;

import com.monsanto.wms.dao.catalog.DataLoaderStagingDAO;
import com.monsanto.wms.dao.catalog.ErrorLogViewDAO;
import com.monsanto.wms.dao.oracle.OracleFxDAO;
import com.monsanto.wms.dao.sheduleTasks.MeteorologicalStationHistoricInfoDAO;
import com.monsanto.wms.service.catalog.impl.ReloadDataServiceImpl;
import com.monsanto.wms.service.mail.MailService;
import com.monsanto.wms.service.security.UserSystemPrivilegesService;
import com.monsanto.wms.service.sheduleTasks.ScheduleErrorService;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.core.io.ClassPathResource;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

import static org.mockito.Mockito.verify;

/**
 * Created by GFRAN1 on 9/17/2014.
 */
@RunWith(MockitoJUnitRunner.class)
public class ReloadDataService_UT {

    @Mock
    OracleFxDAO<Object> oracleFxDAO;
    @Mock
    DataLoaderStagingDAO dataLoaderStagingDAO;
    @Mock
    ErrorLogViewDAO errorLogViewDAO;
    @Mock
    MeteorologicalStationService meteorologicalStationService;
    @Mock
    MailService mailService;
    @Mock
    UserSystemPrivilegesService userSystemPrivilegesService;
    @Mock
    ScheduleErrorService errorService;
    @Mock
    MeteorologicalStationHistoricInfoDAO meteorologicalStationHistoricInfoDAO;

    private InputStreamReader inputStreamReader;

    ReloadDataService  reloadDataService;


    @Before
    public void setUp(){
        reloadDataService = new ReloadDataServiceImpl(oracleFxDAO,meteorologicalStationHistoricInfoDAO,dataLoaderStagingDAO,errorLogViewDAO,meteorologicalStationService,mailService,userSystemPrivilegesService,errorService);
        InputStream inputStream = null;
        try {
            inputStream = new ClassPathResource("spectrumTestFile.csv").getInputStream();
        } catch (IOException e) {
            e.printStackTrace();
        }
        inputStreamReader = new InputStreamReader(inputStream);

    }

    @Test
    public void getMeteorologicalHistoricDataTest(){
        reloadDataService.getMeteorologicalHistoricData(1L, 2, 3, 2014);
        verify(meteorologicalStationHistoricInfoDAO).findByMeteorologicalStationIdAndDayOfTheMonthAndMonthAndYear(1L,2,3,2014);

    }

  /*  @Test
    public void reloadMeteorologicalDataWithoutError() throws IOException, SQLException {
        MeteorologicalStation meteorologicalStation = new MeteorologicalStation();
        meteorologicalStation.setId(1L);
        MeteorologicalStationOwner owner = new MeteorologicalStationOwner();
        owner.setId(1L);
        owner.setDescription("TEST1");
        meteorologicalStation.setOwner(owner);
        meteorologicalStation.setDescription("GUASAVE");
        meteorologicalStation.setUserName("GFRAN1");
        StationType stationType = new StationType();
        stationType.setId(1L);
        stationType.setDescription("station1");
        meteorologicalStation.setStationType(stationType);
        SpectrumRemoteFileReader remoteFileReader = mock(SpectrumRemoteFileReader.class);


       when(meteorologicalStationService.findById(1L)).thenReturn(meteorologicalStation);
        when(remoteFileReader.getInputStreamReader(false)).thenReturn(inputStreamReader);
        reloadDataService.reloadMeteorologicalData(1L,new Date());
        verify(dataLoaderStagingDAO).save(new DataLoaderStaging());
        verify(oracleFxDAO).executeFunction("reloadData}",1L,new Date(),new Date(),1);

    }*/


}
