package com.monsanto.wms.spectrum;

import com.monsanto.wms.persistence.model.MeteorologicalStation;
import com.monsanto.wms.persistence.model.MeteorologicalStationOwner;
import com.monsanto.wms.persistence.model.StationType;
import com.monsanto.wms.persistence.model.User;
import com.monsanto.wms.service.catalog.MeteorologicalStationService;
import com.monsanto.wms.service.mail.MailService;
import com.monsanto.wms.service.security.UserSystemPrivilegesService;
import com.monsanto.wms.service.sheduleTasks.ScheduleErrorService;
import com.monsanto.wms.spectrum.helpers.ProcessReadURLError;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import static org.mockito.Mockito.*;

/**
 * Created with IntelliJ IDEA.
 * User: MANIET
 * Date: 10/14/13
 * Time: 7:58 AM
 * To change this template use File | Settings | File Templates.
 */
@RunWith(MockitoJUnitRunner.class)
public class SpectrumTimerControl_UT {

    private MeteorologicalStationService meteorologicalStationService;
    private MailService mailService;
    private UserSystemPrivilegesService userSystemPrivilegesService;
    private SpectrumTimerControl timerControl;
    private SpectrumRemoteFileProcess fileProcess;
    private ScheduleErrorService scheduleErrorService;
    private ProcessReadURLError processReadURLError;
    private String urlStr;
    private MeteorologicalStation meteorologicalStation;

    @Before
    public void initAllMocks(){
        meteorologicalStation = new MeteorologicalStation();
        MeteorologicalStationOwner owner = new MeteorologicalStationOwner();
        owner.setDescription("");
        meteorologicalStation.setOwner(owner);
        meteorologicalStation.setDescription("");
        meteorologicalStation.setUserName("");
        StationType stationType = new StationType();
        stationType.setDescription("");
        meteorologicalStation.setStationType(stationType);
        User user = new User();
        user.setId("");
        meteorologicalStation.setResponsible(user);
        urlStr = "";
        meteorologicalStationService = mock(MeteorologicalStationService.class);
        mailService = mock(MailService.class);
        userSystemPrivilegesService = mock(UserSystemPrivilegesService.class);
        scheduleErrorService = mock(ScheduleErrorService.class);
        fileProcess = new SpectrumRemoteFileProcess(meteorologicalStationService,mailService,userSystemPrivilegesService,scheduleErrorService);
        timerControl = new SpectrumTimerControl(meteorologicalStationService, mailService, userSystemPrivilegesService,scheduleErrorService);
        processReadURLError = new ProcessReadURLError(mailService,userSystemPrivilegesService,meteorologicalStation,urlStr);

    }

    @Test
    public void runCallsMeteorologicalStationService() throws IOException {
        timerControl.run();
        verify(meteorologicalStationService).findByTypeStationsWithUsrSerialNumber(MeteorologicalStation.SPECTRUM);
    }

    @Ignore
    @Test
    public void runTimeControlWithAllServicesAndAnElementInTheHistoricDataList() throws IOException {

        SpectrumRemoteFileProcess spyRemoteFileProcess = spy(fileProcess);
        SpectrumTimerControl spyTimeControl = spy(timerControl);
        List<MeteorologicalStation> meteorologicalStationList = createMeteorologicalStationList();
        List<String[]> historicList = createMeteorologicalStationHistoricList();

        when(meteorologicalStationService.findByTypeStationsWithUsrSerialNumber(MeteorologicalStation.SPECTRUM)).thenReturn(meteorologicalStationList);
        doReturn(historicList).when(spyRemoteFileProcess).getSpectrumMeteorologicalReadInformation(meteorologicalStation);
        spyTimeControl.run();
    }

    private List<String[]> createMeteorologicalStationHistoricList() {
        List<String[]> historicList = new ArrayList<String[]>();
        historicList.add(new String[0]);
        return historicList;
    }

    private List<MeteorologicalStation> createMeteorologicalStationList() {
        List<MeteorologicalStation> meteorologicalStationList = new ArrayList<MeteorologicalStation>();
        meteorologicalStationList.add(meteorologicalStation);
        return meteorologicalStationList;
    }


}
