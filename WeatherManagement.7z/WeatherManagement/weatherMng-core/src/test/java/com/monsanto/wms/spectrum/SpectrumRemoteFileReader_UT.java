package com.monsanto.wms.spectrum;

import com.monsanto.wms.persistence.model.*;
import com.monsanto.wms.service.mail.MailService;
import com.monsanto.wms.service.security.UserSystemPrivilegesService;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.core.io.ClassPathResource;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.mockito.Mockito.*;

/**
 * Created with IntelliJ IDEA.
 * User: MANIET
 * Date: 10/11/13
 * Time: 1:56 PM
 * To change this template use File | Settings | File Templates.
 */
@RunWith(MockitoJUnitRunner.class)
public class SpectrumRemoteFileReader_UT {

    private MeteorologicalStation station;
    private MailService mailService;
    private UserSystemPrivilegesService userSystemPrivilegesService;

    @Before
    public void setup(){

        station = new MeteorologicalStation("SYSTEM TEST CYCLE");
        station.setUserName("TEST USER NAME");
        station.setStationType(new StationType("SPECTRUM"));
        station.setOwner(new MeteorologicalStationOwner("SYSTEM TEST CYCLE"));
        station.getOwner().setArea(new Area(1L));
        station.setResponsible(new User("GFRAN1"));
        station.getResponsible().setName("Gabriela");
        station.getResponsible().setEmail("gabriela.franco@monsanto.com");
        mailService = mock(MailService.class);
        userSystemPrivilegesService = mock(UserSystemPrivilegesService.class);
    }
    @Test
    public void retrieveInputStreamReaderFromURL() throws IOException {
        //because problems with proxy we use the spy in order to make this test pass.
        URL url = new URL("http://meteoviewapi.specweather.com/Monsanto.aspx?user=4ADFFC4D-B46B-4EEB-87E3-F232C8B9DDCF&station=290005206&method=getConditionsCSV"); //server

        SpectrumRemoteFileReader fileReader = new SpectrumRemoteFileReader(url, station,mailService,userSystemPrivilegesService);
        SpectrumRemoteFileReader fileReaderSpy = spy(fileReader);
        InputStreamReader inputStreamReader = mock(InputStreamReader.class);
        doReturn(inputStreamReader).when(fileReaderSpy).openInputStreamConnection();

        assertNotNull(fileReaderSpy.getInputStreamReader(false));
    }

    @Test
    public void errorWhenRetrieveInputStreamReaderFromURL() throws IOException {
        List<UserSystemPrivileges> listOfUsers = new ArrayList<UserSystemPrivileges>();
        UserSystemPrivileges userSystemPrivileges = new UserSystemPrivileges();
        userSystemPrivileges.setUser(new User());
        userSystemPrivileges.getUser().setId("GFRAN1");
        userSystemPrivileges.getUser().setEmail("gabriela.franco@monsanto.com");
        listOfUsers.add(userSystemPrivileges);

        URL url = new URL("http://fakeUrlDesignedForFailure.com");

        when(userSystemPrivilegesService.getMailDistributionListByArea(1L)).thenReturn(listOfUsers);

        SpectrumRemoteFileReader fileReader = new SpectrumRemoteFileReader(url, station,mailService,userSystemPrivilegesService);

        assertNull(fileReader.getInputStreamReader(false));

    }

    @Test
    public void errorWhenNoDataFoundFromDayBeforeSpectrumStation() throws IOException {
        List<UserSystemPrivileges> listOfUsers = new ArrayList<UserSystemPrivileges>();
        UserSystemPrivileges userSystemPrivileges = new UserSystemPrivileges();
        userSystemPrivileges.setUser(new User());
        userSystemPrivileges.getUser().setId("GFRAN1");
        userSystemPrivileges.getUser().setEmail("gabriela.franco@monsanto.com");
        listOfUsers.add(userSystemPrivileges);

        List<String[]> dayRowInformationList = new ArrayList<String[]>();

        URL url = new URL("http://meteoviewapi.specweather.com/Monsanto.aspx?user=4ADFFC4D-B46B-4EEB-87E3-F232C8B9DDCF&station=290005206&method=getConditionsCSV");
        SpectrumRemoteFileReader fileReader = new SpectrumRemoteFileReader(url, station,mailService,userSystemPrivilegesService);
        SpectrumRemoteFileReader fileReaderSpy = spy(fileReader);
        InputStreamReader inputStreamReader = mock(InputStreamReader.class);
        doReturn(inputStreamReader).when(fileReaderSpy).openInputStreamConnection();

        when(userSystemPrivilegesService.getMailDistributionListByArea(1L)).thenReturn(listOfUsers);
        fileReader.validateExistenceDataFromPreviousDay(dayRowInformationList);

    }


    @Test
    public void retrieveInputStreamReaderFromURLWhenFoundDataFromDayBefore() throws IOException {
        URL url = new URL("http://meteoviewapi.specweather.com/Monsanto.aspx?user=4ADFFC4D-B46B-4EEB-87E3-F232C8B9DDCF&station=290005206&method=getConditionsCSV"); //server

        SpectrumRemoteFileReader fileReader = new SpectrumRemoteFileReader(url, station,mailService,userSystemPrivilegesService);
        SpectrumRemoteFileReader fileReaderSpy = spy(fileReader);
        InputStreamReader inputStreamReader = mock(InputStreamReader.class);
        doReturn(inputStreamReader).when(fileReaderSpy).openInputStreamConnection();
        assertNotNull(fileReaderSpy.getInputStreamReader(false));

        InputStream inputStream = new ClassPathResource("spectrumTestFile.csv").getInputStream();
        inputStreamReader = new InputStreamReader(inputStream);
        List<String[]> dayRowInformationList = SpectrumBufferReader.toList(inputStreamReader, 1, ";");
        fileReader.validateExistenceDataFromPreviousDay(dayRowInformationList);

    }
}
