package com.monsanto.wms.service.security;

import com.monsanto.wms.dao.ldap.LdapUserDAO;
import com.monsanto.wms.dao.security.*;
import com.monsanto.wms.persistence.model.User;
import com.monsanto.wms.service.security.impl.UserServiceImpl;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.Collections;

import static junit.framework.Assert.assertNotNull;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyBoolean;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.*;

/**
 * Created by IntelliJ IDEA.
 * User: MANIET
 * Date: 6/6/13
 * Time: 3:41 PM
 * To change this template use File | Settings | File Templates.
 */
@RunWith(MockitoJUnitRunner.class)
public class UserService_UT {

    @Mock private LdapUserDAO ldapUserDAO;
    @Mock private UserDAO userDAO;

    private UserService service;

    @Before
    public void setUp() {
        service = new UserServiceImpl(userDAO,ldapUserDAO);
    }

    @Test
    public void searchDefault(){
        Page page = mock(Page.class);
        Pageable pageable = mock(Pageable.class);

        when(userDAO.findByIdLikeAndNameLikeAndEmailLikeAndActive(anyString(), anyString(),anyString(),anyBoolean(), any(Pageable.class))).thenReturn(page);

        assertNotNull(service.search("","","", false,pageable));

        verify(userDAO).findByIdLikeAndNameLikeAndEmailLikeAndActive("%%", "%%","%%", false,pageable);
    }

    @Test
    public void searchNullParameters(){
        Page page = mock(Page.class);
        Pageable pageable = mock(Pageable.class);

        when(userDAO.findByIdLikeAndNameLikeAndEmailLikeAndActive(anyString(), anyString(),anyString(),anyBoolean(), any(Pageable.class))).thenReturn(page);

        assertNotNull(service.search(null,null,null, false,pageable));

        verify(userDAO).findByIdLikeAndNameLikeAndEmailLikeAndActive("%null%", "%null%","%null%", false,pageable);
    }


    @Test
    public void findById(){

        when(userDAO.findOne(anyString())).thenReturn(new User());

        assertNotNull(service.findById(anyString()));

        verify(userDAO).findOne(anyString());
    }

    @Test
    public void delete(){
        service.delete(anyString());
        verify(userDAO).delete(anyString());
    }

     @Test
    public void authenticated(){
         when(ldapUserDAO.authenticated(anyString(),anyString())).thenReturn(true);
         service.authenticated(anyString(),anyString());
         verify(ldapUserDAO).authenticated(anyString(),anyString());
    }

    @Test
    public void saveDefault(){

        User user = new User("USER_ID","USER_NAME","USER_MAIL",true,true);

        when(userDAO.saveAndFlush(any(User.class))).thenReturn(new User());

        assertNotNull(service.save(user));

        verify(userDAO).saveAndFlush(any(User.class));
    }

      @Test
    public void findLdapUserByIdLike(){

        when(ldapUserDAO.findByIdLike(anyString())).thenReturn(Collections.EMPTY_LIST);

        assertNotNull(service.findLdapUserByIdLike("ID_USER"));

        verify(ldapUserDAO).findByIdLike("ID_USER");
    }

}
