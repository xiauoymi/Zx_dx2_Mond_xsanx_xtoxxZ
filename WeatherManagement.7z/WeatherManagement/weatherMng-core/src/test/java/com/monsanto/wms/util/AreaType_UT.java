package com.monsanto.wms.util;

import org.junit.Test;

import static junit.framework.Assert.*;

/**
 * Monsanto
 * Author: MANIET
 * Date: 6/12/12
 * Time: 04:15 PM
 */
public class AreaType_UT {

    @Test
    public void successLookup(){

        AreaType area = AreaType.lookup( 1L );

        assertNotNull(area);

        assertTrue( AreaType.AREA_ADMINISTRATIVE_TASKS == area );
    }

    @Test
    public void failedLookup(){

        try {
            AreaType area = AreaType.lookup( 10L );
        } catch (IllegalArgumentException e) {

            assertEquals( "No area is defined with id: 10", e.getMessage() );
        }
    }
}
