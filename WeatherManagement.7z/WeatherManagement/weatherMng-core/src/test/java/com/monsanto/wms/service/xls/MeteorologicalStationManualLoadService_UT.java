package com.monsanto.wms.service.xls;

import com.monsanto.wms.dao.sheduleTasks.MeteorologicalStationHistoricInfoDAO;
import com.monsanto.wms.excel.listeners.MeteorologicalStationManualLoadListener;
import com.monsanto.wms.excel.manager.ExcelListener;
import com.monsanto.wms.excel.manager.ExcelListenerManager;
import com.monsanto.wms.excel.manager.invokers.ExcelTransformerInvoker;
import com.monsanto.wms.excel.manager.invokers.InvokerResult;
import com.monsanto.wms.exceptions.excel.ExcelLoadErrorException;
import com.monsanto.wms.persistence.model.MeteorologicalStationHistoric;
import com.monsanto.wms.service.xls.impl.MeteorologicalStationManualLoadServiceImpl;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.io.FileInputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import static junit.framework.Assert.assertNotNull;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyInt;
import static org.mockito.Matchers.anyLong;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/**
 * Created by IntelliJ IDEA.
 * User: MANIET
 * Date: 6/6/13
 * Time: 3:41 PM
 * To change this template use File | Settings | File Templates.
 */
@RunWith(MockitoJUnitRunner.class)
public class MeteorologicalStationManualLoadService_UT {

    @Mock
    private ExcelListenerManager excelListenerManager;

    @Mock
    private ExcelTransformerInvoker excelTransformerInvoker;

    @Mock
    private MeteorologicalStationHistoricInfoDAO meteorologicalStationHistoricInfoDAO;

    private MeteorologicalStationManualLoadService service;

    private static FileInputStream file;

    @BeforeClass
    public static void loadKeys() throws Exception {
        String fileLocationOK = Thread.currentThread().getContextClassLoader().getResource("testInputDataFileOK.xls").getFile();
        file = new FileInputStream(fileLocationOK);
    }

    @Before
    public void setUp() {
        service = new MeteorologicalStationManualLoadServiceImpl(excelListenerManager, excelTransformerInvoker, meteorologicalStationHistoricInfoDAO);
    }

    @Test
    public void importDataSuccess() throws Throwable {

        InvokerResult result = new InvokerResult();
        result.setInsertedRows(1L);
        ExcelListener listener = mock(MeteorologicalStationManualLoadListener.class);

        List<MeteorologicalStationHistoric> ls = new ArrayList<MeteorologicalStationHistoric>();
        ls.add(new MeteorologicalStationHistoric(1L));
        when(meteorologicalStationHistoricInfoDAO.findByMeteorologicalStationIdAndDayOfTheMonthAndMonthAndYear(anyLong(), anyInt(), anyInt(), anyInt())).thenReturn(ls);
        when(excelListenerManager.createMetStationManualLoad()).thenReturn(listener);
        when(listener.getInvokerResult()).thenReturn(result);

        service.importData(file, 1L, 1, 1, 1);

        verify(excelListenerManager).createMetStationManualLoad();
        verify(excelTransformerInvoker).invoke(any(InputStream.class), any(ExcelListener.class));
    }

    @Test(expected = ExcelLoadErrorException.class)
    public void importDataWithOutRecords() throws Throwable {

        InvokerResult result = new InvokerResult();
        result.setInsertedRows(0L);
        ExcelListener listener = mock(MeteorologicalStationManualLoadListener.class);

        when(excelListenerManager.createMetStationManualLoad()).thenReturn(listener);
        when(listener.getInvokerResult()).thenReturn(result);

        service.importData(file, 1L, 1, 1, 1);

        verify(excelListenerManager).createMetStationManualLoad();
        verify(excelTransformerInvoker).invoke(any(InputStream.class), any(ExcelListener.class));

    }


}
