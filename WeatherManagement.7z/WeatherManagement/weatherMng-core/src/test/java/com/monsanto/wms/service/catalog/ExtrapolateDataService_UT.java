package com.monsanto.wms.service.catalog;

import com.monsanto.wms.dao.oracle.OracleFxDAO;
import com.monsanto.wms.service.catalog.impl.PRExtrapolateDataServiceImpl;
import com.monsanto.wms.vo.ExtrapolatedDataHistoricVO;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import static org.mockito.Mockito.when;

/**
 * Created by GFRAN1 on 10/9/2014.
 */

@RunWith(MockitoJUnitRunner.class)
public class ExtrapolateDataService_UT {

    @Mock
    private OracleFxDAO<Object> oracleFxDAO;

    private PRExtrapolateDataService prExtrapolateDataService;

    @Before
    public void setUp(){
        prExtrapolateDataService = new PRExtrapolateDataServiceImpl(oracleFxDAO);
    }

    @Test
    public void fillEmptyDays_Success(){
        Date date = new Date();
        List<Object> rs = new ArrayList<Object>();
        rs.add(new String("test1"));
        when(oracleFxDAO.executeFunction("fillDataGaps",1L,date,date,2)).thenReturn(rs);
        prExtrapolateDataService.fillEmptyDays(1L,date,date,2);
    }

    @Test
     public void getExtrapolatedDataProfile_GetMessage(){
        Date date = new Date();
        List<Object> rs = new ArrayList<Object>();
        rs.add(new Object[ ]{"0","2"});
        ExtrapolatedDataHistoricVO extrapolatedDataHistoricVO = new ExtrapolatedDataHistoricVO(rs);
        extrapolatedDataHistoricVO.setExtrapolatedMeasureCount("2");
        extrapolatedDataHistoricVO.setMeteorologicalMeasureCount("0");
        String message = "Are you sure to fill Gaps? For this period there are Natural Data: "+extrapolatedDataHistoricVO.getMeteorologicalMeasureCount()+ "Extrapolated Data:"+extrapolatedDataHistoricVO.getExtrapolatedMeasureCount();
        when(oracleFxDAO.executeFunction("getExtrapolatedDataProfile", 1L, date, date)).thenReturn(rs);
        String messageService= prExtrapolateDataService.getExtrapolatedDataProfile(1L, date, date);
        Assert.assertEquals(message,messageService);



    }

    @Test
    public void getExtrapolatedDataProfile_GetEmptyMessage(){
        Date date = new Date();
        List<Object> rs = new ArrayList<Object>();
        rs.add(new Object[ ]{"0","0"});
        ExtrapolatedDataHistoricVO extrapolatedDataHistoricVO = new ExtrapolatedDataHistoricVO(rs);
        extrapolatedDataHistoricVO.setExtrapolatedMeasureCount("0");
        extrapolatedDataHistoricVO.setMeteorologicalMeasureCount("0");
        when(oracleFxDAO.executeFunction("getExtrapolatedDataProfile", 1L, date, date)).thenReturn(rs);
       String message = prExtrapolateDataService.getExtrapolatedDataProfile(1L, date, date);
        Assert.assertEquals(message,"");


    }


}
