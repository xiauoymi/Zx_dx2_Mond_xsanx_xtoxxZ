package com.monsanto.wms.excel.listeners;

import com.monsanto.wms.dao.sheduleTasks.MeteorologicalStationHistoricInfoDAO;
import com.monsanto.wms.excel.manager.ExcelListener;
import com.monsanto.wms.excel.manager.invokers.ExcelTransformerInvoker;
import com.monsanto.wms.excel.manager.invokers.ExcelTransformerInvokerImpl;
import com.monsanto.wms.exceptions.excel.InvalidDataException;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.context.MessageSource;

import java.io.FileInputStream;
import java.io.IOException;

/**
 * Created by IntelliJ IDEA.
 * User: MANIET
 * Date: 1/4/13
 * Time: 12:41 PM
 * To change this template use File | Settings | File Templates.
 */
@RunWith(MockitoJUnitRunner.class)
public class MeteorologicalStationManualLoad_UT {

    private ExcelTransformerInvoker excelTransformerInvoker;


    @Mock
    private MessageSource messageSource;

    @Mock
    private MeteorologicalStationHistoricInfoDAO meteorologicalStationHistoricInfoDAO;

    private ExcelListener listener;

    private static FileInputStream fileFullTest;

    private static FileInputStream fileErrors;


    @BeforeClass
    public static void loadKeys() throws Exception {

        String fileLocationOK = Thread.currentThread().getContextClassLoader().getResource("LayoutManualLoadMetStationInfo.xls").getFile();
        String fileLocationErrorsCols = Thread.currentThread().getContextClassLoader().getResource("LayoutManualLoadMetStationInfoDataCols.xls").getFile();
        fileFullTest = new FileInputStream(fileLocationOK);
        fileErrors = new FileInputStream(fileLocationErrorsCols);

    }

    @Before
    public void setUp() {
        excelTransformerInvoker = new ExcelTransformerInvokerImpl();
        listener = new MeteorologicalStationManualLoadListener(messageSource, meteorologicalStationHistoricInfoDAO);


    }

    @Test
    public void testProcessColumnsSuccess() throws IOException {
        excelTransformerInvoker.invoke(fileFullTest, listener);
    }

    @Test(expected = InvalidDataException.class)
    public void testProcessDataErrorColumns() throws IOException {
        excelTransformerInvoker.invoke(fileErrors, listener);
    }

}
