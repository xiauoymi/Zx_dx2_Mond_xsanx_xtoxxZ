package com.monsanto.wms.dao.ldap;


import com.monsanto.wms.dao.ldap.impl.LdapUserAttributesMapper;
import com.monsanto.wms.vo.LdapUserVO;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import javax.naming.NamingException;
import javax.naming.directory.Attribute;
import javax.naming.directory.Attributes;

import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.*;

/**
 * Monsanto
 * Author: Luis Miguel Arteaga Rios (lmarte@monsanto.com)
 * Date: 29/11/12
 * Time: 05:19 PM
 */
@RunWith(MockitoJUnitRunner.class)
public class LdapUserAttributesMapper_UT {

    LdapUserAttributesMapper mapper;

    @Mock
    Attributes attributes;

    @Mock
    Attribute cnAttribute;

    @Mock
    Attribute displayNameAttribute;

    @Before
    public void setUp(){

        mapper = new LdapUserAttributesMapper();
    }

    @Test
    public void testMapFromAttributes() throws NamingException{

        when( attributes.get( LdapUserAttributesMapper.ATTRIBUTE_CN ) ).thenReturn( cnAttribute );
        when( attributes.get( LdapUserAttributesMapper.ATTRIBUTE_DISPLAY_NAME ) ).thenReturn( displayNameAttribute );
        when( attributes.get( LdapUserAttributesMapper.ATTRIBUTE_EMAIL ) ).thenReturn( null );

        when( cnAttribute.get() ).thenReturn( "LMARTE" );
        when( displayNameAttribute.get() ).thenReturn( null );

        LdapUserVO user = (LdapUserVO) mapper.mapFromAttributes( attributes );

        assertNotNull( user );

        verify( attributes, times( 3 ) ).get( anyString() );
        verify( cnAttribute, times( 2 ) ).get();
        verify( displayNameAttribute ).get();

    }
}
