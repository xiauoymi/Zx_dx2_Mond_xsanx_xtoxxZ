package com.monsanto.wms.spectrum;

import com.monsanto.wms.exceptions.schedule.DatabaseDuplicatedItem;
import com.monsanto.wms.persistence.model.MeteorologicalStation;
import com.monsanto.wms.persistence.model.MeteorologicalStationHistoric;
import com.monsanto.wms.persistence.model.ScheduleErrorLog;
import com.monsanto.wms.service.catalog.MeteorologicalStationService;
import com.monsanto.wms.service.sheduleTasks.ScheduleErrorService;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.List;

import static org.mockito.Matchers.any;
import static org.mockito.Mockito.*;

/**
 * Created with IntelliJ IDEA.
 * User: MANIET
 * Date: 10/13/13
 * Time: 7:52 PM
 * To change this template use File | Settings | File Templates.
 */
@RunWith(MockitoJUnitRunner.class)
public class SpectrumStoreData_UT {

    MeteorologicalStationService meteorologicalStationService;
    ScheduleErrorService errorService;

    @Before
    public void setUp(){
        meteorologicalStationService = mock(MeteorologicalStationService.class);
        errorService = mock(ScheduleErrorService.class);
    }

    @Test
    public void storeHistoricDataForSpectrumStations(){

        List<SpectrumValidatedMeteorologicalStationHistory> historicList = new ArrayList<SpectrumValidatedMeteorologicalStationHistory>();
        SpectrumValidatedMeteorologicalStationHistory validatedMeteorologicalStationHistory = new SpectrumValidatedMeteorologicalStationHistory();
        historicList.add(validatedMeteorologicalStationHistory);
        SpectrumStoreData spectrumStoreData = new SpectrumStoreData(meteorologicalStationService,errorService,historicList);

        spectrumStoreData.save();

        verify(meteorologicalStationService).save(validatedMeteorologicalStationHistory.getStationHistoric());

    }

    @Test
    public void saveDuplicatedRegistryOnDatabase(){
        List<SpectrumValidatedMeteorologicalStationHistory> historicList = new ArrayList<SpectrumValidatedMeteorologicalStationHistory>();
        SpectrumValidatedMeteorologicalStationHistory validatedMeteorologicalStationHistory = new SpectrumValidatedMeteorologicalStationHistory();
        historicList.add(validatedMeteorologicalStationHistory);
        SpectrumStoreData spectrumStoreData = new SpectrumStoreData(meteorologicalStationService,errorService,historicList);

        when(meteorologicalStationService.save(any(MeteorologicalStationHistoric.class))).thenThrow(new DatabaseDuplicatedItem("Duplicated Item"));

        spectrumStoreData.save();

        verify(meteorologicalStationService).save(validatedMeteorologicalStationHistory.getStationHistoric());
        verifyNoMoreInteractions(meteorologicalStationService);
    }

    @Test
    public void storeFoundErrorsHistoricDataForSpectrumStations(){

        List<SpectrumValidatedMeteorologicalStationHistory> historicList = new ArrayList<SpectrumValidatedMeteorologicalStationHistory>();
        SpectrumValidatedMeteorologicalStationHistory validatedMeteorologicalStationHistory = new SpectrumValidatedMeteorologicalStationHistory();
        validatedMeteorologicalStationHistory.getValidator().addError("SECTION","ERROR");
        validatedMeteorologicalStationHistory.setStationHistoric(new MeteorologicalStationHistoric(1L));
        validatedMeteorologicalStationHistory.getStationHistoric().setMeteorologicalStation(new MeteorologicalStation(1L));
        historicList.add(validatedMeteorologicalStationHistory);

        SpectrumStoreData spectrumStoreData = new SpectrumStoreData(meteorologicalStationService,errorService,historicList);
        spectrumStoreData.save();

        verify(errorService).saveErrorLog(any(ScheduleErrorLog.class));

    }
}
