package com.monsanto.wms.service.catalog;

import com.monsanto.wms.dao.catalog.HybridDAO;
import com.monsanto.wms.persistence.model.Hybrid;
import com.monsanto.wms.service.catalog.impl.HybridServiceImpl;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.Collections;

import static junit.framework.Assert.assertNotNull;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyBoolean;
import static org.mockito.Matchers.anyLong;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.*;

/**
 * Created by IntelliJ IDEA.
 * User: MANIET
 * Date: 6/6/13
 * Time: 3:41 PM
 * To change this template use File | Settings | File Templates.
 */
@RunWith(MockitoJUnitRunner.class)
public class HybridService_UT {

    @Mock
    private HybridDAO dao;

    private HybridService service;

    @Before
    public void setUp() {
        service = new HybridServiceImpl(dao);
    }

    @Test
    public void searchDefault(){
        Page page = mock(Page.class);
        Pageable pageable = mock(Pageable.class);

        when(dao.findByDescriptionLikeAndActive(anyString(),anyBoolean(),any(Pageable.class))).thenReturn(page);

        assertNotNull(service.search("",-1L,-1L, false, pageable));

        verify(dao).findByDescriptionLikeAndActive("%%",false,pageable);
    }

    @Test
    public void searchDescriptionNull(){
        Page page = mock(Page.class);
        Pageable pageable = mock(Pageable.class);

        when(dao.findByDescriptionLikeAndActive(anyString(),anyBoolean(),any(Pageable.class))).thenReturn(page);

        assertNotNull(service.search(null, -1L,-1L,false, pageable));

        verify(dao).findByDescriptionLikeAndActive("%null%",false,pageable);
    }

    @Test
    public void searchByCropTypeAndCrop(){
        Page page = mock(Page.class);
        Pageable pageable = mock(Pageable.class);

        when(dao.findByDescriptionLikeAndCropIdAndCropTypeIdAndActive(anyString(),anyLong(),anyLong(),anyBoolean(),any(Pageable.class))).thenReturn(page);

        assertNotNull(service.search("",1L,1L, false, pageable));

        verify(dao).findByDescriptionLikeAndCropIdAndCropTypeIdAndActive("%%",1L,1L,false,pageable);
    }

     @Test
    public void searchByCropType(){
        Page page = mock(Page.class);
        Pageable pageable = mock(Pageable.class);

        when(dao.findByDescriptionLikeAndCropTypeIdAndActive(anyString(),anyLong(),anyBoolean(),any(Pageable.class))).thenReturn(page);

        assertNotNull(service.search("",1L,-1L, false, pageable));

        verify(dao).findByDescriptionLikeAndCropTypeIdAndActive("%%",1L,false,pageable);
    }

    @Test
    public void searchByCropTypeNull(){
        Page page = mock(Page.class);
        Pageable pageable = mock(Pageable.class);

        when(dao.findByDescriptionLikeAndActive(anyString(),anyBoolean(),any(Pageable.class))).thenReturn(page);

        assertNotNull(service.search("",null,-1L, false, pageable));

        verify(dao).findByDescriptionLikeAndActive("%%",false,pageable);
    }


     @Test
    public void searchByCropNull(){
        Page page = mock(Page.class);
        Pageable pageable = mock(Pageable.class);

        when(dao.findByDescriptionLikeAndActive(anyString(),anyBoolean(),any(Pageable.class))).thenReturn(page);

        assertNotNull(service.search("",1L,null, false, pageable));

        verify(dao).findByDescriptionLikeAndActive("%%",false,pageable);
    }

     @Test
    public void searchByCropAndCropTypeNull(){
        Page page = mock(Page.class);
        Pageable pageable = mock(Pageable.class);

        when(dao.findByDescriptionLikeAndActive(anyString(),anyBoolean(),any(Pageable.class))).thenReturn(page);

        assertNotNull(service.search("",null,null, false, pageable));

        verify(dao).findByDescriptionLikeAndActive("%%",false,pageable);
    }

    @Test
    public void findById(){

        when(dao.findOne(anyLong())).thenReturn(new Hybrid());

        assertNotNull(service.findById(anyLong()));

        verify(dao).findOne(anyLong());
    }

    @Test
    public void delete(){
        service.delete(anyLong());
        verify(dao).delete(anyLong());
    }

    @Test
    public void save(){

        when(dao.saveAndFlush(any(Hybrid.class))).thenReturn(new Hybrid());

        assertNotNull(service.save(any(Hybrid.class)));

        verify(dao).saveAndFlush(any(Hybrid.class));
    }

     @Test
    public void loadCollection(){

        when(dao.findByActiveTrueOrderByDescriptionAsc()).thenReturn(Collections.EMPTY_LIST);

        assertNotNull(service.loadCollection());

        verify(dao).findByActiveTrueOrderByDescriptionAsc();
    }

     @Test
    public void findDynamicList(){

        when(dao.findByCropTypeIdAndCropIdAndDescriptionLikeAndActiveTrueOrderByDescriptionAsc(anyLong(),anyLong(),anyString())).thenReturn(Collections.EMPTY_LIST);

        assertNotNull(service.findDynamicList("",1L,1L));

        verify(dao).findByCropTypeIdAndCropIdAndDescriptionLikeAndActiveTrueOrderByDescriptionAsc(1L,1L,"%%");
    }


}
