package com.monsanto.wms.spectrum;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.core.io.ClassPathResource;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

/**
 * Created with IntelliJ IDEA.
 * User: MANIET
 * Date: 10/10/13
 * Time: 8:31 AM
 * To change this template use File | Settings | File Templates.
 */
@RunWith(MockitoJUnitRunner.class)
public class SpectrumBufferReader_UT {

    private final int EMPTY_LIST = 0;
    private final int CSV_TEST_FILE_SIZE = 2084;
    private InputStreamReader inputStreamReader;


    @Before
    public void setup() throws IOException {
        InputStream inputStream = new ClassPathResource("spectrumTestFile.csv").getInputStream();
        inputStreamReader = new InputStreamReader(inputStream);

    }

    @Test
    public void createListOfArraysFromGivenInputStreamReader() throws IOException {
        assertEquals(CSV_TEST_FILE_SIZE, SpectrumBufferReader.toList(inputStreamReader, 1, ";").size());
    }

    @Test
    public void createFailureWhenInputStreamReaderIsNull() throws IOException {
        assertTrue(SpectrumBufferReader.toList(null, 1, ";").size() == EMPTY_LIST);

    }

}
