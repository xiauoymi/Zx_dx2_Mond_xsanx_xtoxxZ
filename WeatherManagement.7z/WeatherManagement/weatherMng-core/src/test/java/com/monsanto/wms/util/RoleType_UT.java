package com.monsanto.wms.util;

import org.junit.Test;

import static junit.framework.Assert.*;

/**
 * Monsanto
 * Author: MANIET
 * Date: 6/12/12
 * Time: 04:15 PM
 */
public class RoleType_UT {

    @Test
    public void successLookup(){

        RoleType role = RoleType.lookup( 1L );

        assertNotNull(role);

        assertTrue( RoleType.ROLE_SUPER_ADMIN == role );
    }

    @Test
    public void failedLookup(){

        try {
            RoleType role = RoleType.lookup( 10L );
        } catch (IllegalArgumentException e) {

            assertEquals( "No role is defined with id: 10", e.getMessage() );
        }
    }
}
