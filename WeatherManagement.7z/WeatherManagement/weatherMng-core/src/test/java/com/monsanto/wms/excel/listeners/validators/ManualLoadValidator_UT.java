package com.monsanto.wms.excel.listeners.validators;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.ArrayList;

import static junit.framework.Assert.assertFalse;
import static junit.framework.Assert.assertTrue;

/**
 * Created by IntelliJ IDEA.
 * User: MANIET
 * Date: 7/25/13
 * Time: 9:47 AM
 * To change this template use File | Settings | File Templates.
 */
@RunWith(MockitoJUnitRunner.class)
public class ManualLoadValidator_UT {

    @Test
    public void validateIsInteger() {
         assertTrue(ManualLoadValidator.validateIsInteger(new Integer(1), 1, 1, new ArrayList<String>()));
    }

    @Test
    public void validateIsIntegerNumberFormatException() {
         assertFalse(ManualLoadValidator.validateIsInteger(new String("A"), 1, 1, new ArrayList<String>()));
    }

     @Test
    public void validateIsLong() {
         assertTrue(ManualLoadValidator.validateIsLong(new Long(1), 1, 1, new ArrayList<String>()));
    }

    @Test
    public void validateIsLongNumberFormatException() {
         assertFalse(ManualLoadValidator.validateIsLong(new String("A"), 1, 1, new ArrayList<String>()));
    }

    @Test
    public void validateIsDouble() {
         assertTrue(ManualLoadValidator.validateIsDouble(new Double(1), 1, 1, new ArrayList<String>()));
    }

    @Test
    public void validateIsDoubleNumberFormatException() {
         assertFalse(ManualLoadValidator.validateIsDouble(new String("A"), 1, 1, new ArrayList<String>()));
    }

     @Test
    public void validateIsTimeLessThan8Characters() {
         assertFalse(ManualLoadValidator.validateIsTime(new String("AAA"), 1, 1, new ArrayList<String>()));
    }

    @Test
    public void validateIsTimeIncorrectFormat() {
         assertFalse(ManualLoadValidator.validateIsTime(new String("AA:AA:AA"), 1, 1, new ArrayList<String>()));
    }

     @Test
    public void validateIsTimeCorrectFormat() {
         assertTrue(ManualLoadValidator.validateIsTime(new String("00:00:00"), 1, 1, new ArrayList<String>()));
    }
}
