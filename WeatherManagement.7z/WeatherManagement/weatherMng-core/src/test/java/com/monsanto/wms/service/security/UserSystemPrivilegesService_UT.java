package com.monsanto.wms.service.security;

import com.monsanto.wms.dao.security.*;
import com.monsanto.wms.exceptions.SystemSecurityException;
import com.monsanto.wms.persistence.model.UserSystemPrivileges;
import com.monsanto.wms.service.security.impl.UserSystemPrivilegesServiceImpl;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import static junit.framework.Assert.assertNotNull;
import static junit.framework.Assert.fail;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyBoolean;
import static org.mockito.Matchers.anyLong;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.*;

/**
 * Created by IntelliJ IDEA.
 * User: MANIET
 * Date: 6/6/13
 * Time: 3:41 PM
 * To change this template use File | Settings | File Templates.
 */
@RunWith(MockitoJUnitRunner.class)
public class UserSystemPrivilegesService_UT {

    @Mock private UserSystemPrivilegesDAO userSystemPrivilegesDAO;
    @Mock private RolesDAO rolesDAO;
    @Mock private AreasDAO areasDAO;
    @Mock private UserDAO userDAO;

    private UserSystemPrivilegesService service;

    @Before
    public void setUp() {
        service = new UserSystemPrivilegesServiceImpl(userSystemPrivilegesDAO,rolesDAO,areasDAO,userDAO);
    }

    @Test
    public void searchDefault(){
        Page page = mock(Page.class);
        Pageable pageable = mock(Pageable.class);

        when(userSystemPrivilegesDAO.findByUserIdLikeAndUserActive(anyString(), anyBoolean(), any(Pageable.class))).thenReturn(page);

        assertNotNull(service.search("",-1L,-1L, false,pageable));

        verify(userSystemPrivilegesDAO).findByUserIdLikeAndUserActive("%%", false, pageable);
    }

    @Test
    public void searchUserIdNull(){
        Page page = mock(Page.class);
        Pageable pageable = mock(Pageable.class);

        when(userSystemPrivilegesDAO.findByUserIdLikeAndUserActive(anyString(),anyBoolean(),any(Pageable.class))).thenReturn(page);

        assertNotNull(service.search(null,-1L,-1L, false,pageable));

        verify(userSystemPrivilegesDAO).findByUserIdLikeAndUserActive("%null%",false,pageable);
    }


    @Test
    public void searchByArea(){
        Page page = mock(Page.class);
        Pageable pageable = mock(Pageable.class);

        when(userSystemPrivilegesDAO.findByUserIdLikeAndRoleAreaIdAndUserActive(anyString(), anyLong(), anyBoolean(), any(Pageable.class))).thenReturn(page);

        assertNotNull(service.search("",1L,-1L, false,pageable));

        verify(userSystemPrivilegesDAO).findByUserIdLikeAndRoleAreaIdAndUserActive("%%", 1L, false, pageable);
    }

    @Test
    public void searchByRole(){
        Page page = mock(Page.class);
        Pageable pageable = mock(Pageable.class);

        when(userSystemPrivilegesDAO.findByUserIdLikeAndRoleIdAndUserActive(anyString(), anyLong(), anyBoolean(), any(Pageable.class))).thenReturn(page);

        assertNotNull(service.search("",-1L,1L, false,pageable));

        verify(userSystemPrivilegesDAO).findByUserIdLikeAndRoleIdAndUserActive("%%", 1L, false, pageable);
    }

    @Test
    public void searchByAreaAndRole(){
        Page page = mock(Page.class);
        Pageable pageable = mock(Pageable.class);

        when(userSystemPrivilegesDAO.findByUserIdLikeAndRoleAreaIdAndRoleIdAndUserActive(anyString(), anyLong(), anyLong(), anyBoolean(), any(Pageable.class))).thenReturn(page);

        assertNotNull(service.search("",1L,1L, false,pageable));

        verify(userSystemPrivilegesDAO).findByUserIdLikeAndRoleAreaIdAndRoleIdAndUserActive("%%", 1L, 1L, false, pageable);
    }

    @Test
    public void findById(){

        when(userSystemPrivilegesDAO.findOne(anyLong())).thenReturn(new UserSystemPrivileges());

        assertNotNull(service.findById(anyLong()));

        verify(userSystemPrivilegesDAO).findOne(anyLong());
    }

    @Test
    public void findByUserId(){

        when(userSystemPrivilegesDAO.findByUserId(anyString())).thenReturn(Collections.EMPTY_LIST);

        assertNotNull(service.findByUserId(anyString()));

        verify(userSystemPrivilegesDAO).findByUserId(anyString());
    }

    @Test
    public void delete(){
        service.delete(anyLong());
        verify(userSystemPrivilegesDAO).delete(anyLong());
    }

    @Test
    public void saveDefault(){

        UserSystemPrivileges userSystemPrivileges = new UserSystemPrivileges(null,"USER_ID",1L,1L);

        when(userSystemPrivilegesDAO.findByUserIdAndRoleAreaId(anyString(),anyLong())).thenReturn(Collections.EMPTY_LIST);
        when(userSystemPrivilegesDAO.saveAndFlush(any(UserSystemPrivileges.class))).thenReturn(new UserSystemPrivileges());

        assertNotNull(service.save(userSystemPrivileges));

        verify(userSystemPrivilegesDAO).findByUserIdAndRoleAreaId(anyString(),anyLong());
        verify(userSystemPrivilegesDAO).saveAndFlush(any(UserSystemPrivileges.class));
    }



    @Test(expected = SystemSecurityException.class)
    public void saveSystemAccessMoreThanOneArea(){

        UserSystemPrivileges userSystemPrivileges = new UserSystemPrivileges(null,"USER_ID",1L,1L);

        List<UserSystemPrivileges> ls = new ArrayList<UserSystemPrivileges>();
        ls.add(new UserSystemPrivileges());

        when(userSystemPrivilegesDAO.findByUserIdAndRoleAreaId(anyString(),anyLong())).thenReturn(ls);


        service.save(userSystemPrivileges);

        verify(userSystemPrivilegesDAO).findByUserIdAndRoleAreaId(anyString(),anyLong());

        fail("SystemSecurityException expected");

    }

     @Test
    public void loadCollectionAreas(){

        when(areasDAO.findByActiveTrueOrderByDescriptionAsc()).thenReturn(Collections.EMPTY_LIST);

        assertNotNull(service.loadCollectionAreas());

        verify(areasDAO).findByActiveTrueOrderByDescriptionAsc();
    }

    @Test
    public void loadCollectionRoles(){

        when(rolesDAO.findByAreaIdAndActiveTrueOrderByDescriptionAsc(anyLong())).thenReturn(Collections.EMPTY_LIST);

        assertNotNull(service.loadCollectionRoles(anyLong()));

        verify(rolesDAO).findByAreaIdAndActiveTrueOrderByDescriptionAsc(anyLong());
    }

    @Test
    public void loadCollectionUser(){

        when(userDAO.findByActiveTrueAndIdLikeOrderByNameAsc(anyString())).thenReturn(Collections.EMPTY_LIST);

        assertNotNull(service.loadCollectionUser(""));

        verify(userDAO).findByActiveTrueAndIdLikeOrderByNameAsc("%%");
    }

     @Test
    public void loadCollectionUserIdNull(){

        when(userDAO.findByActiveTrueAndIdLikeOrderByNameAsc(anyString())).thenReturn(Collections.EMPTY_LIST);

        assertNotNull(service.loadCollectionUser(null));

        verify(userDAO).findByActiveTrueAndIdLikeOrderByNameAsc("%null%");
    }

      @Test
    public void getMailDistributionListByArea(){

        when(userSystemPrivilegesDAO.findByUserId(anyString())).thenReturn(Collections.EMPTY_LIST);

        assertNotNull(service.getMailDistributionListByArea(1L));
    }


}
