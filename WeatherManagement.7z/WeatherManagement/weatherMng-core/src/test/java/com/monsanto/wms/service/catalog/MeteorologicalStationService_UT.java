package com.monsanto.wms.service.catalog;

import com.monsanto.wms.dao.catalog.MeteorologicalStationDAO;
import com.monsanto.wms.dao.catalog.StationTypeDAO;
import com.monsanto.wms.dao.sheduleTasks.MeteorologicalStationHistoricInfoDAO;
import com.monsanto.wms.persistence.model.MeteorologicalStation;
import com.monsanto.wms.persistence.model.MeteorologicalStationHistoric;
import com.monsanto.wms.persistence.model.User;
import com.monsanto.wms.service.catalog.impl.MeteorologicalStationServiceImpl;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import static junit.framework.Assert.assertNotNull;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyLong;
import static org.mockito.Mockito.*;

/**
 * Created by IntelliJ IDEA.
 * User: MANIET
 * Date: 6/6/13
 * Time: 3:41 PM
 * To change this template use File | Settings | File Templates.
 */
@RunWith(MockitoJUnitRunner.class)
public class MeteorologicalStationService_UT {

    @Mock
    private MeteorologicalStationDAO meteorologicalStationDAO;

     @Mock
    private StationTypeDAO stationTypeDAO;

    @Mock
    private MeteorologicalStationHistoricInfoDAO meteorologicalStationHistoricInfoDAO;

    private MeteorologicalStationService service;

    @Mock
    MeteorologicalStation meteorologicalStation;

    @Mock
    User responsible;


    List<MeteorologicalStation> meteorologicalStations = new ArrayList<MeteorologicalStation>();



    @Before
    public void setUp() {
        service = new MeteorologicalStationServiceImpl(meteorologicalStationDAO,meteorologicalStationHistoricInfoDAO,stationTypeDAO);
    }

    @Test
    public void search_calls_findByStationTypeIdAndDescriptionLikeAndActiveAndOwnerId_when_OwnerId_NOT_NULL(){

        Pageable pageable = mock(Pageable.class);
        service.search(1L,"",false,1L,pageable);
        verify(meteorologicalStationDAO).findByStationTypeIdAndDescriptionLikeAndActiveAndOwnerId(1L,"%%", false, 1L, pageable);
    }

    @Test
    public void search_calls_findByStationTypeIdAndDescriptionLikeAndActiveAndOwnerId_when_OwnerId_NULL(){

        Pageable pageable = mock(Pageable.class);
        service.search(1L,"",false,null,pageable);
        verify(meteorologicalStationDAO).findByStationTypeIdAndDescriptionLikeAndActive(1L,"%%", false,pageable);
    }


    @Test
    public void findById(){

        when(meteorologicalStationDAO.findOne(anyLong())).thenReturn(new MeteorologicalStation());

        assertNotNull(service.findById(anyLong()));

        verify(meteorologicalStationDAO).findOne(anyLong());
    }

    @Test
    public void delete(){
        service.delete(anyLong());
        verify(meteorologicalStationDAO).delete(anyLong());
    }

    @Test
    public void save_callsDao(){
        when(responsible.getId()).thenReturn("");
        when(meteorologicalStation.getResponsible()).thenReturn(responsible);
        service.save(meteorologicalStation);
        verify(meteorologicalStationDAO).saveAndFlush(meteorologicalStation);
    }

     @Test
    public void loadCollection(){

        when(meteorologicalStationDAO.findByActiveTrueOrderByDescriptionAsc()).thenReturn(Collections.EMPTY_LIST);

        assertNotNull(service.loadCollection());

        verify(meteorologicalStationDAO).findByActiveTrueOrderByDescriptionAsc();
    }

     @Test
    public void loadStationCollection(){

        when(stationTypeDAO.findAll()).thenReturn(Collections.EMPTY_LIST);

        assertNotNull(service.loadStationTypesCollection());

        verify(stationTypeDAO).findAll();
    }

      @Test
    public void loadCollectionByOwner(){

        when(meteorologicalStationDAO.findByActiveTrueAndOwnerIdOrderByDescriptionAsc(anyLong())).thenReturn(Collections.EMPTY_LIST);

        assertNotNull(service.loadCollectionByOwner(anyLong()));

        verify(meteorologicalStationDAO).findByActiveTrueAndOwnerIdOrderByDescriptionAsc(anyLong());
    }

     @Test
    public void saveHistoricData(){

        when(meteorologicalStationHistoricInfoDAO.saveAndFlush(any(MeteorologicalStationHistoric.class))).thenReturn(new MeteorologicalStationHistoric());

        assertNotNull(service.save(any(MeteorologicalStationHistoric.class)));

        verify(meteorologicalStationHistoricInfoDAO).saveAndFlush(any(MeteorologicalStationHistoric.class));
    }

    @Test
     public void findByTypeStationsWithUsrPwd(){

         when(meteorologicalStationDAO.findByActiveTrueAndStationTypeIdAndUserNameNotNullAndPwdNotNull(anyLong())).thenReturn(Collections.EMPTY_LIST);

         assertNotNull(service.findByTypeStationsWithUsrPwd(anyLong()));

         verify(meteorologicalStationDAO).findByActiveTrueAndStationTypeIdAndUserNameNotNullAndPwdNotNull(anyLong());
     }

    @Test
    public void searchMetStationHistoric(){
        Page page = mock(Page.class);
        Pageable pageable = mock(Pageable.class);

        when(meteorologicalStationHistoricInfoDAO.findByMeteorologicalStationIdAndDayOfTheMonthAndMonthAndYear(anyLong(),anyInt(),anyInt(),anyInt(),any(Pageable.class))).thenReturn(page);

        assertNotNull(service.search(1,1,1,1L, pageable));

        verify(meteorologicalStationHistoricInfoDAO).findByMeteorologicalStationIdAndDayOfTheMonthAndMonthAndYear(1L,1,1,1, pageable);
    }

    @Test
    public void searchMetStationHistoricMetStationNull(){
        Page page = mock(Page.class);
        Pageable pageable = mock(Pageable.class);

        when(meteorologicalStationHistoricInfoDAO.findByMeteorologicalStationIdAndDayOfTheMonthAndMonthAndYear(anyLong(),anyInt(),anyInt(),anyInt(),any(Pageable.class))).thenReturn(page);

        assertNotNull(service.search(1,1,1,null, pageable));

    }

     @Test
    public void searchMetStationHistoricDayNull(){
        Page page = mock(Page.class);
        Pageable pageable = mock(Pageable.class);

        when(meteorologicalStationHistoricInfoDAO.findByMeteorologicalStationIdAndDayOfTheMonthAndMonthAndYear(anyLong(),anyInt(),anyInt(),anyInt(),any(Pageable.class))).thenReturn(page);

        assertNotNull(service.search(null,1,1,null, pageable));

    }

     @Test
    public void searchMetStationHistoricMonthNull(){
        Page page = mock(Page.class);
        Pageable pageable = mock(Pageable.class);

        when(meteorologicalStationHistoricInfoDAO.findByMeteorologicalStationIdAndDayOfTheMonthAndMonthAndYear(anyLong(),anyInt(),anyInt(),anyInt(),any(Pageable.class))).thenReturn(page);

        assertNotNull(service.search(null,null,1,null, pageable));

    }

     @Test
    public void searchMetStationHistoricYearNull(){
         Page page = mock(Page.class);
        Pageable pageable = mock(Pageable.class);

        when(meteorologicalStationHistoricInfoDAO.findByMeteorologicalStationIdAndDayOfTheMonthAndMonthAndYear(anyLong(),anyInt(),anyInt(),anyInt(),any(Pageable.class))).thenReturn(page);

       assertNotNull(service.search(-1,null,null,null, pageable));

    }

      @Test
    public void searchMetStationHistoricDayUnderZero(){
          Page page = mock(Page.class);
          Pageable pageable = mock(Pageable.class);
          MeteorologicalStation meteorologicalStation = new MeteorologicalStation();
        //  User responsible = new User();
          //responsible.setId("");

         // meteorologicalStation.setResponsible(responsible);


        when(meteorologicalStationHistoricInfoDAO.findByMeteorologicalStationIdAndMonthAndYear(anyLong(), anyInt(), anyInt(), any(Pageable.class))).thenReturn(page);

        assertNotNull(service.search(-1,1,1,1L, pageable));

        verify(meteorologicalStationHistoricInfoDAO).findByMeteorologicalStationIdAndMonthAndYear(1L,1,1, pageable);
    }

     @Test
    public void searchMetStationHistoricDayMonthUnderZero(){
        Page page = mock(Page.class);
        Pageable pageable = mock(Pageable.class);

        when(meteorologicalStationHistoricInfoDAO.findByMeteorologicalStationIdAndYear(anyLong(),anyInt(),any(Pageable.class))).thenReturn(page);

        assertNotNull(service.search(-1,-1,1,1L, pageable));

        verify(meteorologicalStationHistoricInfoDAO).findByMeteorologicalStationIdAndYear(1L,1, pageable);
    }



}
