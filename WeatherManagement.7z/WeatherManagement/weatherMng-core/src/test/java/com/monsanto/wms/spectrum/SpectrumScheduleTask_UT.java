package com.monsanto.wms.spectrum;

import com.monsanto.wms.service.catalog.MeteorologicalStationService;
import com.monsanto.wms.service.mail.MailService;
import com.monsanto.wms.service.security.UserSystemPrivilegesService;
import com.monsanto.wms.service.sheduleTasks.ScheduleErrorService;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;

import static junit.framework.Assert.assertEquals;
import static junit.framework.Assert.assertTrue;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;

/**
 * Created with IntelliJ IDEA.
 * User: MANIET
 * Date: 10/14/13
 * Time: 10:43 AM
 * To change this template use File | Settings | File Templates.
 */
@RunWith(MockitoJUnitRunner.class)
public class SpectrumScheduleTask_UT {

    private MeteorologicalStationService meteorologicalStationService;
    private MailService mailService;
    private UserSystemPrivilegesService userSystemPrivilegesService;
    private SpectrumScheduleTask scheduleTask;
    private ScheduleErrorService scheduleErrorService;

    @Before
    public void initAllMocks() {
        meteorologicalStationService = mock(MeteorologicalStationService.class);
        mailService = mock(MailService.class);
        userSystemPrivilegesService = mock(UserSystemPrivilegesService.class);
        scheduleErrorService = mock(ScheduleErrorService.class);
        scheduleTask = new SpectrumScheduleTask(meteorologicalStationService, mailService, userSystemPrivilegesService,scheduleErrorService);

    }

    @Test
    public void verifyCreationOfSpectrumScheduleTaskTaskWithSpectrumTimeControl() {
        scheduleTask.start();
        assertTrue(scheduleTask.createSpectrumTimer() instanceof SpectrumTimerControl);
    }
}
