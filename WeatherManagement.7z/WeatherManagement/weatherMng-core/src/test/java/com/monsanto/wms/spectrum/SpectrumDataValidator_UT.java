package com.monsanto.wms.spectrum;

import com.monsanto.wms.spectrum.helpers.ScheduleError;
import com.monsanto.wms.spectrum.helpers.SpectrumDateUtils;
import org.apache.commons.lang.time.DateFormatUtils;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;

import java.text.ParseException;
import java.util.Date;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

/**
 * Created with IntelliJ IDEA.
 * User: MANIET
 * Date: 10/11/13
 * Time: 1:05 PM
 * To change this template use File | Settings | File Templates.
 */

@RunWith(MockitoJUnitRunner.class)
public class SpectrumDataValidator_UT{
    private final int LIST_FIRST_ELEMENT = 0;
    private SpectrumDataValidator validator;

    @Before
    public void setup(){
        validator = new SpectrumDataValidator();
    }

    @Test
    public void whenARegistryHasInvalidNumericData(){
        validator.validateNumericData("SOME_FIELD","INVALID");
        assertTrue(validator.isAnIncorrectRegistryFounded());
    }

    @Test
    public void whenARegistryHasAValidDateTimeFormat(){
        validator.validateRegistryTime("2013-10-08 17:15");
        assertFalse(validator.isAnIncorrectRegistryFounded());

    }

    @Test
    public void whenARegistryHasAnInvalidDateTimeFormat(){
        String sDate = "2013-10";
        validator.validateRegistryTime(sDate);
        ScheduleError scheduleError = validator.getErrorList().get(0);

        assertTrue(validator.isAnIncorrectRegistryFounded());
        assertEquals("Invalid length:"+sDate.length()+" Expected:"+10,scheduleError.getMessage());

    }

    @Test
    public void validateRegistryWithANotCurrentDate(){
        assertFalse(validator.validateCurrentRegistryWithCurrentDate("2013-10-08 17:15"));

    }

    @Test
    public void validateRegistryWithCurrentDate() throws ParseException {
        String strDate = SpectrumDateUtils.getDayBeforeOfCurrentDateAsString();
        assertTrue(validator.validateCurrentRegistryWithCurrentDate(strDate));

    }
    @Test
    public void validateRegistryWithIncompleteCurrentDate(){
        String currentDate = DateFormatUtils.format(new Date(), "dd-MM");
        assertFalse(validator.validateCurrentRegistryWithCurrentDate(currentDate));
        assertEquals("Invalid length:"+currentDate.length()+" Expected:10",validator.getErrorList().get(0).getMessage());

    }

    @Test
    public void validateRegistryWithInvalidDate(){
        String currentDate = "AA/BB/CCCC";
        assertFalse(validator.validateCurrentRegistryWithCurrentDate(currentDate));
        assertEquals("Invalid Format:"+currentDate.length()+" Expected:MM/dd/yyyy",validator.getErrorList().get(0).getMessage());

    }

    @Test
    public void addAnErrorToErrorList(){
        validator.addError("MY_SECTION","MY_MESSAGE");
        assertTrue(validator.isAnIncorrectRegistryFounded());
        assertEquals("MY_SECTION",validator.getErrorList().get(LIST_FIRST_ELEMENT).getSection());
        assertEquals("MY_MESSAGE",validator.getErrorList().get(LIST_FIRST_ELEMENT).getMessage());
    }

    @Test
    public void verifyCorrectSizeOfBufferRegistry(){
        assertTrue(validator.validateBufferRegistrySize(new String[29]));
        assertFalse(validator.isAnIncorrectRegistryFounded());
    }

    @Test
    public void verifyIncorrectSizeOfBufferRegistry(){
        assertFalse(validator.validateBufferRegistrySize(new String[12]));
        assertTrue(validator.isAnIncorrectRegistryFounded());
    }

    @Test
    public void transformListOfErrorsToAString(){
        validator.addError("SECTION 1","ERROR 1");
        validator.addError("SECTION 2","ERROR 2");

        assertEquals("SECTION 1 - ERROR 1 / SECTION 2 - ERROR 2 / ",validator.toString());
    }



}
