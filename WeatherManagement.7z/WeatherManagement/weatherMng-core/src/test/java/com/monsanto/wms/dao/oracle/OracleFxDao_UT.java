package com.monsanto.wms.dao.oracle;

import com.monsanto.wms.dao.oracle.impl.OracleFxDAOImpl;
import com.monsanto.wms.exceptions.oracle.EntityManagerException;
import com.monsanto.wms.exceptions.oracle.NamedQueryException;
import com.monsanto.wms.exceptions.oracle.ParameterException;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.data.domain.Pageable;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Query;
import java.util.ArrayList;

import static junit.framework.Assert.assertNotNull;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.*;

/**
 * Created by IntelliJ IDEA.
 * User: MANIET
 * Date: 6/6/13
 * Time: 3:41 PM
 * To change this template use File | Settings | File Templates.
 */
@RunWith(MockitoJUnitRunner.class)
public class OracleFxDao_UT {

    @Mock
    EntityManagerFactory entityManagerFactory;

    @Mock
    EntityManager entityManager;

    @Mock
    Query query;

    @InjectMocks
    OracleFxDAO<Object> dao = new OracleFxDAOImpl();


    @Test
    public void executeFunctionWithOutErrors(){
        when(entityManagerFactory.createEntityManager()).thenReturn(entityManager);
        when(entityManager.createNamedQuery(anyString())).thenReturn(query);
        when(query.getResultList()).thenReturn(new ArrayList());
        assertNotNull(dao.executeFunction("MY_ORACLE_FX", "Param1"));
    }



    @Test (expected = EntityManagerException.class)
    public void executeFunctionWithEntityManagerException(){
        when(entityManagerFactory.createEntityManager()).thenReturn(null);
        dao.executeFunction("MY_ORACLE_FX", "Param1");
    }

    @Test (expected = NamedQueryException.class)
    public void executeFunctionWithNamedQueryExceptionEmpty(){
        when(entityManagerFactory.createEntityManager()).thenReturn(entityManager);
        dao.executeFunction("","Param1");
    }

    @Test (expected = ParameterException.class)
    public void executeFunctionWithParameterException(){
        when(entityManagerFactory.createEntityManager()).thenReturn(entityManager);
        dao.executeFunction("MY_ORACLE_FX",null);
    }



}
