package com.monsanto.wms.service.production;

import com.monsanto.wms.dao.oracle.OracleFxDAO;
import com.monsanto.wms.service.production.impl.PRGeneralReportServiceImpl;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.data.domain.Pageable;

import java.util.ArrayList;
import java.util.List;

import static junit.framework.Assert.assertNotNull;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/**
 * Created by IntelliJ IDEA.
 * User: MANIET
 * Date: 8/1/13
 * Time: 4:15 PM
 * To change this template use File | Settings | File Templates.
 */
@RunWith(MockitoJUnitRunner.class)
public class PRGeneralReportService_UT {

    @Mock
    OracleFxDAO<Object> oracleFxDAO;

    PRGeneralReportService service;

     @Before
    public void setUp(){
        service = new PRGeneralReportServiceImpl(oracleFxDAO);
    }

    @Test
    public void getReportWithOutError(){
        Object[] obj = new Object[]{"2013/01/08",1D,1D,1D,1D,1D,1D,1D,1D,1D,1D,1D,1D,1D,1D,1D,"10.52.12","2"};
        List<Object> ls = new ArrayList<Object>();
        ls.add(obj);

        when(oracleFxDAO.executeFunction("getGeneralReport", 2013,1,1,2013,1,1,1L,1D,1D,"CROP",1D,1D)).thenReturn(ls);
        service.getReport(2013,1,1,2013,1,1,1L,1D,1D,"CROP",1D,1D,mock(Pageable.class));

        verify(oracleFxDAO).executeFunction("getGeneralReport", 2013,1,1,2013,1,1,1L,1D,1D,"CROP",1D,1D);
    }

    @Test
    public void getReportWithErrorValuesNull(){
        assertNotNull(service.getReport(null,1,1,2013,1,1,1L,1D,1D,"CROP",1D,1D, mock(Pageable.class)));
        assertNotNull(service.getReport(2013,null,1,2013,1,1,1L,1D,1D,"CROP",1D,1D, mock(Pageable.class)));
        assertNotNull(service.getReport(2013,1,null,2013,1,1,1L,1D,1D,"CROP",1D,1D, mock(Pageable.class)));
        assertNotNull(service.getReport(2013,1,1,null,1,1,1L,1D,1D,"CROP",1D,1D, mock(Pageable.class)));
        assertNotNull(service.getReport(2013,1,1,2013,null,1,1L,1D,1D,"CROP",1D,1D, mock(Pageable.class)));
        assertNotNull(service.getReport(2013,1,1,2013,1,null,1L,1D,1D,"CROP",1D,1D, mock(Pageable.class)));
        assertNotNull(service.getReport(2013,1,1,2013,1,1,null,1D,1D,"CROP",1D,1D, mock(Pageable.class)));
        assertNotNull(service.getReport(2013,1,1,2013,1,1,1L,null,1D,"CROP",1D,1D, mock(Pageable.class)));
        assertNotNull(service.getReport(2013,1,1,2013,1,1,1L,1D,null,"CROP",1D,1D, mock(Pageable.class)));
        assertNotNull(service.getReport(2013,1,1,2013,1,1,1L,1D,1D,null,1D,1D, mock(Pageable.class)));
        assertNotNull(service.getReport(2013,1,1,2013,1,1,1L,1D,1D,"CROP",null,1D, mock(Pageable.class)));
        assertNotNull(service.getReport(2013,1,1,2013,1,1,1L,1D,1D,"CROP",1D,null, mock(Pageable.class)));
    }

        @Test
    public void getReportWithErrorValuesUnderZero(){
        assertNotNull(service.getReport(-1,1,1,2013,1,1,1L,1D,1D,"CROP",1D,1D, mock(Pageable.class)));
        assertNotNull(service.getReport(2013,-1,1,2013,1,1,1L,1D,1D,"CROP",1D,1D, mock(Pageable.class)));
        assertNotNull(service.getReport(2013,1,-1,2013,1,1,1L,1D,1D,"CROP",1D,1D, mock(Pageable.class)));
        assertNotNull(service.getReport(2013,1,1,-1,1,1,1L,1D,1D,"CROP",1D,1D, mock(Pageable.class)));
        assertNotNull(service.getReport(2013,1,1,2013,-1,1,1L,1D,1D,"CROP",1D,1D, mock(Pageable.class)));
        assertNotNull(service.getReport(2013,1,1,2013,1,-1,1L,1D,1D,"CROP",1D,1D, mock(Pageable.class)));
        assertNotNull(service.getReport(2013,1,1,2013,1,1,-1L,1D,1D,"CROP",1D,1D, mock(Pageable.class)));
        assertNotNull(service.getReport(2013,1,1,2013,1,1,1L,-1D,1D,"CROP",1D,1D, mock(Pageable.class)));
        assertNotNull(service.getReport(2013,1,1,2013,1,1,1L,1D,-1D,"CROP",1D,1D, mock(Pageable.class)));
    }
}
