package com.monsanto.wms.service.production;

import com.monsanto.wms.persistence.model.DataLoaderStaging;
import com.monsanto.wms.service.catalog.ReloadDataService;
import com.monsanto.wms.service.production.impl.SpectrumMeteorologicalStationManualLoadServiceImpl;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import static org.mockito.Mockito.when;

/**
 * Created by GFRAN1 on 10/30/2014.
 */
@RunWith(MockitoJUnitRunner.class)
public class SpectrumMeteorologicalStationManualLoadService_UT {

    @Mock
    ReloadDataService reloadDataService;

    @Mock
    List<DataLoaderStaging> dataLoaderStagingList;

   SpectrumMeteorologicalStationManualLoadService spectrumMeteorologicalStationManualLoadService;

    List<String[]> list=new ArrayList<String[]>();
    String[] strings;

    Date date =new Date();

    @Before
    public void setUp(){
        spectrumMeteorologicalStationManualLoadService = new SpectrumMeteorologicalStationManualLoadServiceImpl(reloadDataService);

        strings = new String[]{"2014-09-01 00:00","0.0","53.9","23.1","0.0","15","0","0","13.3"};
        list.add(strings);
        strings = new String[]{"2014-09-01 00:00","0.0","57.6","26.1","0.0","16","0","0","14.3"};
        list.add(strings);
        strings = new String[]{"2014-09-01 00:00","0.0","57.6",null,"0.0","17","0","0","10.3"};
        list.add(strings);
        strings = new String[]{"2014-09-02 00:00","0.0","57.6","42.1","0.0","18","0","0","8.3"};
        list.add(strings);
        strings = new String[]{"2014-09-02 00:00","0.0","53.9","25.1","0.0","15","0","0","13.3"};
        list.add(strings);
        strings = new String[]{"2014-09-03 00:00","0.0","57.6",null,"0.0","16","0","0","14.3"};
        list.add(strings);
        strings = new String[]{"2014-09-03 00:00","0.0","57.6","21.1","0.0","17","0","0","10.3"};
        list.add(strings);
        strings = new String[]{"2014-09-04 00:00","0.0","57.6","48.1","0.0","18","0","0","8.3"};
        list.add(strings);

    }

    @Test
    public void importDataToStaging_success() throws ParseException {
        when(reloadDataService.executeReloadProcess(date, date, 1L, dataLoaderStagingList)).thenReturn(1L);
        spectrumMeteorologicalStationManualLoadService.importDataToStaging(1L,list, new Date(), new Date());
    }



}
