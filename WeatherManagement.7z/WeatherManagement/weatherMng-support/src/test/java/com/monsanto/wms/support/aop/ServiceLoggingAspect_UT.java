package com.monsanto.wms.support.aop;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.Signature;
import org.junit.Before;
import org.junit.Test;

import java.util.Arrays;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

/**
 * Created by IntelliJ IDEA.
 * User: FJSIBA
 * Date: 16/08/12
 * Time: 10:55 AM
 * To change this template use File | Settings | File Templates.
 */
public class ServiceLoggingAspect_UT {
    JoinPoint joinPoint;
    Signature signature;

    @Before
    public void setUp(){
        joinPoint = mock(JoinPoint.class);
        signature = mock(Signature.class);
        when(signature.getName()).thenReturn("testMethod");
        when(joinPoint.getTarget()).thenReturn(this);
        when(joinPoint.getSignature()).thenReturn(signature);
    }

    @Test
    public void testLoggingMethodWithArguments(){
        when(joinPoint.getArgs()).thenReturn(Arrays.asList(new Object(), new String(), null).toArray());
        ServiceLoggingAspect aspect = new ServiceLoggingAspect();

        aspect.logBefore(joinPoint);
        aspect.logAfter(joinPoint);
    }

    @Test
    public void testLoggingMethodWithoutArguments(){
        when(joinPoint.getArgs()).thenReturn(new Object[0]);
        ServiceLoggingAspect aspect = new ServiceLoggingAspect();

        aspect.logBefore(joinPoint);
        aspect.logAfter(joinPoint);
    }


    @Test
    public void testLoggingMethodAfterThrowingException(){
        when(joinPoint.getArgs()).thenReturn(new Object[0]);
        ServiceLoggingAspect aspect = new ServiceLoggingAspect();

        aspect.logAfterErrorThrown(joinPoint, new Exception());
    }

}
