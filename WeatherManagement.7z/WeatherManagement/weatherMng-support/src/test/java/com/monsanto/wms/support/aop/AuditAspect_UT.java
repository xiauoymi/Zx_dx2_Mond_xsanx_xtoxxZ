package com.monsanto.wms.support.aop;

import com.monsanto.wms.persistence.model.BaseAuditEntity;
import com.monsanto.wms.support.security.DefaultTaskIdLocatorFactory;
import com.monsanto.wms.support.security.DefaultUserIdLocatorFactory;
import com.monsanto.wms.support.security.TaskIdLocatorFactory;
import com.monsanto.wms.support.security.UserIdLocatorFactory;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.Signature;
import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.Collection;

import static junit.framework.Assert.assertNotNull;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

/**
 * Created by IntelliJ IDEA.
 * User: FJSIBA
 * Date: 16/08/12
 * Time: 11:56 AM
 * To change this template use File | Settings | File Templates.
 */
public class AuditAspect_UT {
    private JoinPoint joinPoint;
        private Signature signature;
        private TestModel testModel;
        private AuditAspect aspect;
        private TaskIdLocatorFactory taskIdLocatorFactory;
        private UserIdLocatorFactory userIdLocatorFactory;

        @Before
        public void setUp(){
            joinPoint = mock(JoinPoint.class);
            signature = mock(Signature.class);

            taskIdLocatorFactory = new DefaultTaskIdLocatorFactory();
            userIdLocatorFactory = new DefaultUserIdLocatorFactory();

            testModel = new TestModel();
            aspect = new AuditAspect(userIdLocatorFactory, taskIdLocatorFactory);
        }

        @Test
        public void testSetAuditDataBeforeInsert(){
            when(joinPoint.getTarget()).thenReturn(new Object());
            when(joinPoint.getArgs()).thenReturn(new Object[]{testModel});
            when(joinPoint.getSignature()).thenReturn(signature);
            when(signature.getName()).thenReturn("amethod");

            aspect.setAuditPropertiesBeforeInsert(joinPoint, testModel);

            assertNotNull(testModel.getRowUserId());
        }

        @Test
        public void testSetAuditDataBeforeInsertNoAuditableObjects(){
            Collection<BaseAuditEntity> models = new ArrayList<BaseAuditEntity>();
            models.add(new TestModel());

            when(joinPoint.getTarget()).thenReturn(new Object());
            when(joinPoint.getArgs()).thenReturn(new Object[]{new Object()});
            when(joinPoint.getSignature()).thenReturn(signature);
            when(signature.getName()).thenReturn("amethod");

            aspect.setAuditPropertiesBeforeInsert(joinPoint, models);

        }

        static class TestModel extends BaseAuditEntity{
        }


}
