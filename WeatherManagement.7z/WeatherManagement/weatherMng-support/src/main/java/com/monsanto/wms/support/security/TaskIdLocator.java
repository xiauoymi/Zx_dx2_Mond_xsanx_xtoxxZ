package com.monsanto.wms.support.security;

/**
 * Created by IntelliJ IDEA.
 * User: FJSIBA
 * Date: 27/08/12
 * Time: 11:50 AM
 * To change this template use File | Settings | File Templates.
 */
public interface TaskIdLocator {
    String getTaskId();
}
