package com.monsanto.wms.support.security;

/**
 * Created by IntelliJ IDEA.
 * User: FJSIBA
 * Date: 3/09/12
 * Time: 12:11 PM
 * To change this template use File | Settings | File Templates.
 */
public class DefaultTaskIdLocatorFactory implements TaskIdLocatorFactory{

    public TaskIdLocator getTaskIdLocator() {
        return new DefaultTaskIdLocator();
    }
}
