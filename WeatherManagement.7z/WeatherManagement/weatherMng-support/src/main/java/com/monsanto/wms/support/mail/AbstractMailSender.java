package com.monsanto.wms.support.mail;

import freemarker.template.Configuration;
import freemarker.template.TemplateException;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.ui.freemarker.FreeMarkerTemplateUtils;
import org.springframework.util.StringUtils;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.URLDataSource;
import javax.mail.BodyPart;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import java.io.IOException;
import java.util.Map;

/**
 * Created by IntelliJ IDEA.
 * User: MANIET
 * Date: 31/07/13
 * Time: 02:42 PM
 */
public abstract class AbstractMailSender{

    private JavaMailSender mailSender;
    private Configuration freeMarkerConfiguration;

    protected AbstractMailSender(JavaMailSender mailSender, Configuration freeMarkerConfiguration) {
        this.mailSender = mailSender;
        this.freeMarkerConfiguration = freeMarkerConfiguration;
    }

    public JavaMailSender getMailSender() {
        return mailSender;
    }

    public Configuration getFreeMarkerConfiguration() {
        return freeMarkerConfiguration;
    }

    public abstract String getFrom();

    public abstract String getTopHeader() ;


    public void sendSimpleMessage(SimpleMailMessage simpleMailMessage, String template, Map<String, Object> model) throws MessagingException, IOException, TemplateException {
        MimeMessage message = getMailSender().createMimeMessage();
        if(StringUtils.hasText(simpleMailMessage.getFrom())){
            message.setFrom(new InternetAddress(simpleMailMessage.getFrom()));
        }
        else{
            message.setFrom(new InternetAddress(getFrom()));
        }
        StringBuffer to = new StringBuffer();
        for (String toN : simpleMailMessage.getTo()){
            to.append(toN).append(",");
        }
        final String text  = FreeMarkerTemplateUtils.processTemplateIntoString(getFreeMarkerConfiguration().getTemplate(
                template), model);
        message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(to.toString()));
        message.setSubject(simpleMailMessage.getSubject());
        message.setContent(text, "text/html");

        Multipart multipart = new MimeMultipart();
        BodyPart bodyPart = new MimeBodyPart();
        bodyPart.setContent(text, "text/html");


        DataSource topHeader = new URLDataSource(Thread.currentThread().getContextClassLoader().getResource(getTopHeader()));

        MimeBodyPart imgPart = new MimeBodyPart();
        imgPart.setDataHandler(new DataHandler(topHeader));
        imgPart.setHeader("Content-ID", "mailHeader");

        multipart.addBodyPart(imgPart);
        multipart.addBodyPart(bodyPart);

        message.setContent(multipart);
        getMailSender().send(message);
    }

}
