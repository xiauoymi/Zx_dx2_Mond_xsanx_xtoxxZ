package com.monsanto.wms.support.security;

/**
 * Created by IntelliJ IDEA.
 * User: FJSIBA
 * Date: 21/08/12
 * Time: 02:22 PM
 * To change this template use File | Settings | File Templates.
 */
public interface UserIdLocator {
    String getUserId();
}
