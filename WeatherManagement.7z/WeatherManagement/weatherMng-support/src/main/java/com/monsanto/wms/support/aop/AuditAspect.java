package com.monsanto.wms.support.aop;

//import com.monsanto.scpif.persistence.model.BaseAuditEntity;
import com.monsanto.wms.persistence.model.BaseAuditEntity;
import com.monsanto.wms.support.security.TaskIdLocatorFactory;
import com.monsanto.wms.support.security.UserIdLocatorFactory;
import org.apache.log4j.Logger;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: MANIET
 * Date: 16/08/12
 * Time: 09:08 AM
 * To change this template use File | Settings | File Templates.
 */
@Component
@Aspect
public class AuditAspect {
    private Logger logger = Logger.getLogger(AuditAspect.class);

    private UserIdLocatorFactory userIdLocator;

    private TaskIdLocatorFactory taskIdLocator;

    @Autowired
    public AuditAspect(UserIdLocatorFactory userIdLocator, TaskIdLocatorFactory taskIdLocator) {
        logger.info("*********** Creating Audit Aspect with : " + userIdLocator + ":" + taskIdLocator);
        this.userIdLocator = userIdLocator;
        this.taskIdLocator = taskIdLocator;
    }

    @Before("execution(* com.monsanto.wms.dao..*+.save*(..)) && args(entity)")
    public void setAuditPropertiesBeforeInsert(JoinPoint joinPoint, BaseAuditEntity entity) {
        logger.info("*********** Executing advice for : " + joinPoint.getTarget().getClass() + "." + joinPoint.getSignature().getName());
        entity.setRowUserId(userIdLocator.getUserIdLocator().getUserId());
        entity.setRowTaskId(taskIdLocator.getTaskIdLocator().getTaskId());
    }

    @Before("execution(* com.monsanto.wms.dao..*+.save*(..)) && args(iterator)")
    public void setAuditPropertiesBeforeInsert(JoinPoint joinPoint, Collection<BaseAuditEntity> iterator) {
        logger.info("*********** Executing advice for : " + joinPoint.getTarget().getClass() + "." + joinPoint.getSignature().getName());
        for (BaseAuditEntity entity : iterator) {
            entity.setRowUserId(userIdLocator.getUserIdLocator().getUserId());
            entity.setRowTaskId(taskIdLocator.getTaskIdLocator().getTaskId());
        }
    }

}
