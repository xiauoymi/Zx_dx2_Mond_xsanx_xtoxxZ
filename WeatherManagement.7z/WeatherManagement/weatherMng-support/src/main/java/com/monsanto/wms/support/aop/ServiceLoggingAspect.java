package com.monsanto.wms.support.aop;

import org.apache.log4j.Logger;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.stereotype.Component;

/**
 * @author FJSIBA
 *         Date: 15/08/12
 *         Time: 04:44 PM
 *         To change this template use File | Settings | File Templates.
 */
@Component
@Aspect
public class ServiceLoggingAspect extends AbstractLoggingAspect{
    @Before("execution(* com.monsanto.wms.service.*.*.*.*(..))")
    public void logBefore(JoinPoint joinPoint) {
        createLogger(joinPoint).info(createLoggingMessage(joinPoint, "**** Entering the method ****  "));
    }

    @After("execution(* com.monsanto.wms.service.*.*.*.*(..))")
    public void logAfter(JoinPoint joinPoint){
        createLogger(joinPoint).info(createLoggingMessage(joinPoint, "**** Leaving the method ****  "));
    }

    @AfterThrowing(pointcut = "execution(* com.monsanto.wms.service.*.*.*.*(..))", throwing = "anyException")
    public void logAfterErrorThrown(JoinPoint joinPoint, Exception anyException){
        createLogger(joinPoint).error(createLoggingMessage(joinPoint, "**** Exception was thrown ****  "), anyException);
    }

    private Logger createLogger(JoinPoint joinPoint) {
        return Logger.getLogger(joinPoint.getTarget().getClass());
    }
}
