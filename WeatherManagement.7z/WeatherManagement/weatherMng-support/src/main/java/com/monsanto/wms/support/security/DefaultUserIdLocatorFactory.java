package com.monsanto.wms.support.security;

/**
 * Created by IntelliJ IDEA.
 * User: FJSIBA
 * Date: 3/09/12
 * Time: 12:12 PM
 * To change this template use File | Settings | File Templates.
 */
public class DefaultUserIdLocatorFactory implements UserIdLocatorFactory{
    public UserIdLocator getUserIdLocator() {
        return new DefaultUserIdLocator();
    }
}
