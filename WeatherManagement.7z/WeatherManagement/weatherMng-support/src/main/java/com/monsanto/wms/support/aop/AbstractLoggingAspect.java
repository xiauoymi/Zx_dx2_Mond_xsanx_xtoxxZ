package com.monsanto.wms.support.aop;

import org.aspectj.lang.JoinPoint;

/**
 * Created by IntelliJ IDEA.
 * User: FJSIBA
 * Date: 16/08/12
 * Time: 09:01 AM
 * To change this template use File | Settings | File Templates.
 */
public abstract class AbstractLoggingAspect {
    protected String createLoggingMessage(JoinPoint joinPoint, String initPattern){
        StringBuilder builder = new StringBuilder(initPattern);
        builder.append(createBasicInformationLoggingMessage(joinPoint));
        return builder.toString();
    }
    private String createBasicInformationLoggingMessage(JoinPoint joinPoint){
        StringBuilder builder = new StringBuilder();
        builder.append(joinPoint.getTarget().getClass().getCanonicalName());
        builder.append(".");
        builder.append(joinPoint.getSignature().getName());
        builder.append(createParamLoggingMessage(joinPoint));
        return builder.toString();
    }

    private String createParamLoggingMessage(JoinPoint joinPoint) {
        StringBuilder builder = new StringBuilder();
        if (joinPoint.getArgs() != null && joinPoint.getArgs().length > 0) {
            builder.append("(");
            int i = 0;
            for (Object obj : joinPoint.getArgs()) {
                builder.append(obj != null ? obj.getClass().getName():"null");
                if((i + 1) < joinPoint.getArgs().length){
                    builder.append(",");
                }
                i++;
            }
            builder.append(")");
        } else {
            builder.append("()");
        }
        return builder.toString();
    }

    public abstract void logBefore(JoinPoint joinPoint);
    public abstract void logAfter(JoinPoint joinPoint);
}
