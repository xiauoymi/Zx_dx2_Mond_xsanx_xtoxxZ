package com.monsanto.wms.support.security;

/**
 * Created by IntelliJ IDEA.
 * User: FJSIBA
 * Date: 28/08/12
 * Time: 04:27 PM
 * To change this template use File | Settings | File Templates.
 */
public interface TaskIdLocatorFactory {
    TaskIdLocator getTaskIdLocator();
}
