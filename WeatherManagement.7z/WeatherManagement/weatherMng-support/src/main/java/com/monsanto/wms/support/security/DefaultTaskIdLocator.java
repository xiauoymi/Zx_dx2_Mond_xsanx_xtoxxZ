package com.monsanto.wms.support.security;

/**
 * Created by IntelliJ IDEA.
 * User: FJSIBA
 * Date: 27/08/12
 * Time: 12:13 PM
 * To change this template use File | Settings | File Templates.
 */
public class DefaultTaskIdLocator implements TaskIdLocator{

    public String getTaskId() {
        return "N/A";
    }
}
