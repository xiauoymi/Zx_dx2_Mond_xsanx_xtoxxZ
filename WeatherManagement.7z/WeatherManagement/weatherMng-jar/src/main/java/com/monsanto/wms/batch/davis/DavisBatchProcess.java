package com.monsanto.wms.batch.davis;

import com.monsanto.wms.persistence.model.MeteorologicalStation;
import com.monsanto.wms.service.catalog.MeteorologicalStationService;
import com.monsanto.wms.service.mail.MailService;
import com.monsanto.wms.service.security.UserSystemPrivilegesService;
import com.monsanto.wms.web.scheduleTasks.davis.DavisProcessRemoteData;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Collection;
import java.util.Date;

/**
 * Created by GFRAN1 on 12/4/2014.
 */

public class DavisBatchProcess {

    private MeteorologicalStationService meteorologicalStationService;
    private MailService mailService;
    private UserSystemPrivilegesService userSystemPrivilegesService;
    private static final Logger log = LoggerFactory.getLogger(DavisBatchProcess.class);

    public DavisBatchProcess(MeteorologicalStationService meteorologicalStationService, MailService mailService, UserSystemPrivilegesService userSystemPrivilegesService) {
        this.meteorologicalStationService = meteorologicalStationService;
        this.mailService = mailService;
        this.userSystemPrivilegesService = userSystemPrivilegesService;
    }

    public void executeDavisProcessRemoteData() {
        log.info("DAVIS XML reading started on:"+new Date());
        Collection<MeteorologicalStation> davisStations = getDavisStations();
        DavisProcessRemoteData davisProcessRemoteData = null;
        if(davisStations!=null){
            davisProcessRemoteData = new DavisProcessRemoteData(meteorologicalStationService,mailService,userSystemPrivilegesService,davisStations);
            davisProcessRemoteData.start();
        }
        System.out.println("RUNNING DAVISTimer..."+ new Date());
    }

    private Collection<MeteorologicalStation> getDavisStations() {
        try {
            return meteorologicalStationService.findByTypeStationsWithUsrPwd(MeteorologicalStation.DAVIS);
        } catch (Exception e) {
            e.printStackTrace();
            log.error("DAVIS Station could not be retrieved");
            return null;
        }
    }
}
