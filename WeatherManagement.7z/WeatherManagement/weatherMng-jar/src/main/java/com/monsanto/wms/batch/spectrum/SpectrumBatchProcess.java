package com.monsanto.wms.batch.spectrum;

import com.monsanto.wms.persistence.model.MeteorologicalStation;
import com.monsanto.wms.service.catalog.MeteorologicalStationService;
import com.monsanto.wms.service.mail.MailService;
import com.monsanto.wms.service.security.UserSystemPrivilegesService;
import com.monsanto.wms.service.sheduleTasks.ScheduleErrorService;
import com.monsanto.wms.spectrum.SpectrumRemoteFileProcess;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Collection;
import java.util.Date;

/**
 * Created by GFRAN1 on 12/23/2014.
 */
public class SpectrumBatchProcess {

    private MeteorologicalStationService meteorologicalStationService;
    private MailService mailService;
    private UserSystemPrivilegesService userSystemPrivilegesService;
    private ScheduleErrorService errorService;
    private static final Logger log = LoggerFactory.getLogger(SpectrumBatchProcess.class);

    public SpectrumBatchProcess(MeteorologicalStationService meteorologicalStationService, MailService mailService, UserSystemPrivilegesService userSystemPrivilegesService, ScheduleErrorService errorService) {
        this.meteorologicalStationService = meteorologicalStationService;
        this.mailService = mailService;
        this.userSystemPrivilegesService = userSystemPrivilegesService;
        this.errorService = errorService;
    }


    public void executeSpectrumProcessRemoteData() {
        log.info("Spectrum Time Control start reading on:" + new Date());
        Collection<MeteorologicalStation> spectrumStations = getSpectrumStations();
        SpectrumRemoteFileProcess spectrumRemoteFileProcess = new SpectrumRemoteFileProcess(meteorologicalStationService, mailService, userSystemPrivilegesService, errorService);
        for (MeteorologicalStation currentStation : spectrumStations) {
            spectrumRemoteFileProcess.storeHistoricRetrievedInformation(currentStation);
        }
    }

        private Collection<MeteorologicalStation> getSpectrumStations() {
            return meteorologicalStationService.findByTypeStationsWithUsrSerialNumber(MeteorologicalStation.SPECTRUM);
        }
}
