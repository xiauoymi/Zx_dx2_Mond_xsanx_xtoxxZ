package com.monsanto.wms.batch.davis;

import com.monsanto.wms.batch.ProcessMain;
import com.monsanto.wms.service.catalog.MeteorologicalStationService;
import com.monsanto.wms.service.mail.MailService;
import com.monsanto.wms.service.security.UserSystemPrivilegesService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;

/**
 * Created by GFRAN1 on 12/3/2014.
 */
public class DavisBatchMain extends ProcessMain{
    private final Logger log = LoggerFactory.getLogger(this.getClass());
    private DavisBatchProcess davisBatchProcess;

    public DavisBatchMain(ApplicationContext applicationContext) {
        super(applicationContext);
    }

    public DavisBatchMain() {

    }


    protected  void processData(){
        final MeteorologicalStationService meteorologicalStationService= getMeteorologicalStationService();
        final MailService mailService = getMailService();
        final UserSystemPrivilegesService userSystemPrivileges = getUserSystemPrivileges();

        DavisBatchProcess davisBatchProcess=  new DavisBatchProcess(meteorologicalStationService,mailService,userSystemPrivileges);
        davisBatchProcess.executeDavisProcessRemoteData();

    }

    protected MeteorologicalStationService getMeteorologicalStationService(){
        return this.getService("meteorologicalStationService",MeteorologicalStationService.class);
    }

    protected MailService getMailService(){
        return this.getService("mailService",MailService.class);
    }

    protected UserSystemPrivilegesService getUserSystemPrivileges(){
        return this.getService("userSystemPrivilegesService",UserSystemPrivilegesService.class);
    }
    public static void main(String[] args){
        new DavisBatchMain().processData();

    }
}
