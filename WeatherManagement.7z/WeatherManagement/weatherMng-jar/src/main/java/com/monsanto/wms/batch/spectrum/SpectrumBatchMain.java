package com.monsanto.wms.batch.spectrum;

import com.monsanto.wms.batch.ProcessMain;
import com.monsanto.wms.service.catalog.MeteorologicalStationService;
import com.monsanto.wms.service.mail.MailService;
import com.monsanto.wms.service.security.UserSystemPrivilegesService;
import com.monsanto.wms.service.sheduleTasks.ScheduleErrorService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;

/**
 * Created by GFRAN1 on 12/23/2014.
 */
public class SpectrumBatchMain extends ProcessMain{
    private final Logger log = LoggerFactory.getLogger(this.getClass());
    SpectrumBatchProcess spectrumBatchProcess;

    public SpectrumBatchMain(ApplicationContext applicationContext) {
        super(applicationContext);
    }

    public SpectrumBatchMain(){

    }

    protected  void processData(){
        final MeteorologicalStationService meteorologicalStationService= getMeteorologicalStationService();
        final MailService mailService = getMailService();
        final UserSystemPrivilegesService userSystemPrivileges = getUserSystemPrivileges();
        final ScheduleErrorService errorService = getScheduleErrorService();
        SpectrumBatchProcess spectrumBatchProcess= new SpectrumBatchProcess(meteorologicalStationService,mailService,userSystemPrivileges,errorService);
        spectrumBatchProcess.executeSpectrumProcessRemoteData();
    }

    private ScheduleErrorService getScheduleErrorService() {
        return this.getService(ScheduleErrorService.class);
    }

    protected MeteorologicalStationService getMeteorologicalStationService(){
        return this.getService(MeteorologicalStationService.class);
    }

    protected MailService getMailService(){
        return this.getService(MailService.class);
    }

    protected UserSystemPrivilegesService getUserSystemPrivileges(){
        return this.getService(UserSystemPrivilegesService.class);
    }

    public static void main(String[] args){
        new SpectrumBatchMain().processData();

    }
}
