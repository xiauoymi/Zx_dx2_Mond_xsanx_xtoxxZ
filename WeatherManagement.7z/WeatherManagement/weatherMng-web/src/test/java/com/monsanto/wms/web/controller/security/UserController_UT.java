package com.monsanto.wms.web.controller.security;

import com.monsanto.wms.persistence.model.User;
import com.monsanto.wms.service.security.UserService;
import com.monsanto.wms.web.controller.commons.BaseController;
import com.monsanto.wms.web.form.security.UserForm;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.context.MessageSource;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;

import java.util.Collections;
import java.util.Locale;

import static junit.framework.Assert.assertEquals;
import static junit.framework.Assert.assertNotNull;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

/**
 * Created by IntelliJ IDEA.
 * User: MANIET
 * Date: 6/6/13
 * Time: 12:50 PM
 * To change this template use File | Settings | File Templates.
 */
@RunWith(MockitoJUnitRunner.class)
public class UserController_UT {

    @Mock
    private UserService service;

    @Mock
    private MessageSource messageSource;

    private UserController controller;

    @Before
    public void setUp() {
       controller = new UserController(service, messageSource);
    }

    @Test
    public void testInitView(){
         assertEquals("security/userBase", controller.initView().getViewName());
    }

    @Test
    public void saveOrUpdate(){
        when(messageSource.getMessage("common.action.save.success",new Object[0],Locale.getDefault())).thenReturn("The record was saved successfully");
        ResponseEntity<BaseController.GenericResponse> response =  controller.saveOrUpdate(createForm());
        assertEquals("The record was saved successfully",response.getBody().getMessages()[0]);
    }

    @Test
    public void search(){
        Pageable pageable = mock(Pageable.class);
        Page page = mock(Page.class);
        when(service.search("USER_ID","USER_NAME","USER_EMAIL",true,pageable)).thenReturn(page);

        assertNotNull(controller.search(createForm(), pageable));
    }


    @Test
    public void findById(){

        when(service.findById(anyString())).thenReturn(new User());

        assertNotNull(controller.findById(anyString()));
    }

    @Test
    public void delete(){
        when(messageSource.getMessage("common.action.delete.success",new Object[0],Locale.getDefault())).thenReturn("Record was successfully deleted");
        ResponseEntity<BaseController.GenericResponse> response =  controller.delete("USER_ID");
        assertEquals("Record was successfully deleted",response.getBody().getMessages()[0]);
    }

     @Test
    public void findLdapUser(){

        when(service.findLdapUserByIdLike(anyString())).thenReturn(Collections.EMPTY_LIST);

        assertNotNull(controller.findLdapUser(anyString()));
    }

    private UserForm createForm(){
        UserForm form = new UserForm();
        form.setActiveStatus(true);
        form.setEmail("USER_EMAIL");
        form.setName("USER_NAME");
        form.setUserId("USER_ID");
        form.setSendNotification(true);

        return form;
    }


}
