package com.monsanto.wms.web.support;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.HashMap;
import java.util.Map;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.*;

/**
 * Created by IntelliJ IDEA.
 * User: CROME
 * Date: 10/18/12
 * Time: 5:39 PM
 */
@RunWith(MockitoJUnitRunner.class)
public class MessagesServlet_UT {

    private static final String KEY = "Key";
    private static final String VALUE = "Value";
    private static final String EXPECTED_FINAL = String.format("scpi[\"messages\"][\"%s\"]=\"%s\"; if (jQuery.i18n) {jQuery.i18n.setDictionary(scpi[\"messages\"]);}", KEY, VALUE);

    private StringWriter sw;
    private PrintWriter pw;

    @Mock
    private HttpServletResponse response;

    @Mock
    private HttpServletRequest request;

    private MessagesServlet messagesServlet;

    @Before
    public void setup() throws IOException {
        messagesServlet = spy(new MessagesServlet());
        Map<String, String> m = new HashMap<String, String>(0);
        m.put(KEY, VALUE);
        when(messagesServlet.loadMessages()).thenReturn(m);

        sw = new StringWriter();
        pw = new PrintWriter(sw);
        when(response.getWriter()).thenReturn(pw);
    }

    @Test
    public void testThatLoadMessagesCalledOnce() throws ServletException, IOException {
        messagesServlet.service(request, response);
        assertEquals(EXPECTED_FINAL, sw.toString());

        // Reset objects and mock after first call
        sw = new StringWriter();
        pw = new PrintWriter(sw);
        when(response.getWriter()).thenReturn(pw);
        messagesServlet.service(request, response);
        assertEquals(EXPECTED_FINAL, sw.toString());
        verify(messagesServlet, times(1)).loadMessages();
    }
}
