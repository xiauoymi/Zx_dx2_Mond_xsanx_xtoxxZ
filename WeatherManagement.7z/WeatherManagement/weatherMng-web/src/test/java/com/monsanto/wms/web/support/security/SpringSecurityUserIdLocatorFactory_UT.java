package com.monsanto.wms.web.support.security;

import com.monsanto.wms.support.security.UserIdLocator;
import com.monsanto.wms.support.security.UserIdLocatorFactory;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

/**
 * Monsanto
 * Author: Luis Miguel Arteaga Rios (lmarte@monsanto.com)
 * Date: 4/12/12
 * Time: 01:18 PM
 */
public class SpringSecurityUserIdLocatorFactory_UT {

    UserIdLocatorFactory factory;

    @Before
    public void setUp(){

        factory = new SpringSecurityUserIdLocatorFactory();
    }

    @Test
    public void getUserIdLocator(){

        UserIdLocator locator = factory.getUserIdLocator();

        assertNotNull( locator );

        assertTrue( locator instanceof SpringSecurityUserIdLocator );
    }

}
