package com.monsanto.wms.web.support;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.context.MessageSource;

import java.util.Locale;

import static org.mockito.Mockito.*;

/**
 * Created by IntelliJ IDEA.
 * User: ACISS
 * Date: 5/10/12
 * Time: 08:45 PM
 */
@RunWith(MockitoJUnitRunner.class)
@SuppressWarnings("unchecked")
public class CustomerObjectMapper_UT {

    private CustomObjectMapper objectMapper;

     @Mock
    private MessageSource messageSource;

    @Before
    public void setUp() {
        objectMapper = new CustomObjectMapper();
    }

    @Test
    public void testPaginationObjectWithoutSort() throws Exception {
       when(messageSource.getMessage(anyString(), any(Object[].class), any(Locale.class))).thenReturn("MM/dd/yyyy");
       objectMapper.setMessageSource(messageSource);
       objectMapper.afterPropertiesSet();
    }

}
