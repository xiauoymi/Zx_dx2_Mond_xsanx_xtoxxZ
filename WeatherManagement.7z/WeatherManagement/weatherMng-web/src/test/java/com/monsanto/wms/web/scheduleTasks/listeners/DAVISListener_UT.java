package com.monsanto.wms.web.scheduleTasks.listeners;

import com.monsanto.wms.exceptions.schedule.spectrum.SpectrumListenerInitializationException;
import com.monsanto.wms.service.catalog.MeteorologicalStationService;
import com.monsanto.wms.service.mail.MailService;
import com.monsanto.wms.service.security.UserSystemPrivilegesService;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;

import static org.mockito.Mockito.*;

/**
 * Created by IntelliJ IDEA.
 * User: MANIET
 * Date: 7/11/13
 * Time: 10:45 AM
 * To change this template use File | Settings | File Templates.
 */
@RunWith(MockitoJUnitRunner.class)
public class DAVISListener_UT {

    DAVISListener davisListener;
    private ServletContextEvent servletContextEvent;
    private ServletContext servletContext;
    private WebApplicationContext webApplicationContext;
    private MailService mailService;
    private UserSystemPrivilegesService userSystemPrivilegesService;
    private MeteorologicalStationService meteorologicalStationService;

    @Before
    public void setUp() {
        davisListener = new DAVISListener();
        servletContextEvent = mock(ServletContextEvent.class);
        servletContext = mock(ServletContext.class);
        webApplicationContext = mock(WebApplicationContext.class);
        mailService = mock(MailService.class);
        userSystemPrivilegesService = mock(UserSystemPrivilegesService.class);
        meteorologicalStationService = mock(MeteorologicalStationService.class);
    }

    @Test
    public void contextInitialized() {

        when(servletContextEvent.getServletContext()).thenReturn(servletContext);
        when(WebApplicationContextUtils.getWebApplicationContext(servletContext)).thenReturn(webApplicationContext);
        when(webApplicationContext.getBean("meteorologicalStationService")).thenReturn(meteorologicalStationService);
        when(webApplicationContext.getBean("mailService")).thenReturn(mailService);
        when(webApplicationContext.getBean("userSystemPrivilegesService")).thenReturn(userSystemPrivilegesService);

        davisListener.contextInitialized(servletContextEvent);

        verify(webApplicationContext).getBean("meteorologicalStationService");
        verify(webApplicationContext).getBean("mailService");
    }

    @Test
    public void contextDestroyed() {

        when(servletContextEvent.getServletContext()).thenReturn(servletContext);
        when(WebApplicationContextUtils.getWebApplicationContext(servletContext)).thenReturn(webApplicationContext);
        when(webApplicationContext.getBean("meteorologicalStationService")).thenReturn(meteorologicalStationService);
        when(webApplicationContext.getBean("mailService")).thenReturn(mailService);
        when(webApplicationContext.getBean("userSystemPrivilegesService")).thenReturn(userSystemPrivilegesService);

        davisListener.contextInitialized(servletContextEvent);
        davisListener.contextDestroyed(servletContextEvent);

        verify(webApplicationContext).getBean("meteorologicalStationService");
        verify(webApplicationContext).getBean("mailService");
    }

    @Test(expected = SpectrumListenerInitializationException.class)
    public void contextInitializedExceptionOnMeteorologicalService() {

        when(servletContextEvent.getServletContext()).thenReturn(servletContext);
        when(WebApplicationContextUtils.getWebApplicationContext(servletContext)).thenReturn(webApplicationContext);
        when(webApplicationContext.getBean("meteorologicalStationService")).thenThrow(new SpectrumListenerInitializationException("ERROR"));

        davisListener.contextInitialized(servletContextEvent);

        verify(webApplicationContext).getBean("meteorologicalStationService");

    }

    @Test(expected = SpectrumListenerInitializationException.class)
    public void contextInitializedExceptionOnMailService() {

        when(servletContextEvent.getServletContext()).thenReturn(servletContext);
        when(WebApplicationContextUtils.getWebApplicationContext(servletContext)).thenReturn(webApplicationContext);
        when(webApplicationContext.getBean("meteorologicalStationService")).thenReturn(meteorologicalStationService);
        when(webApplicationContext.getBean("mailService")).thenThrow(new SpectrumListenerInitializationException("ERROR"));

        davisListener.contextInitialized(servletContextEvent);

        verify(webApplicationContext).getBean("meteorologicalStationService");

    }

    @Test(expected = SpectrumListenerInitializationException.class)
    public void contextInitializedExceptionOnUserSystemPrivileges() {

        when(servletContextEvent.getServletContext()).thenReturn(servletContext);
        when(WebApplicationContextUtils.getWebApplicationContext(servletContext)).thenReturn(webApplicationContext);
        when(webApplicationContext.getBean("meteorologicalStationService")).thenReturn(meteorologicalStationService);
        when(webApplicationContext.getBean("mailService")).thenReturn(mailService);
        when(webApplicationContext.getBean("userSystemPrivilegesService")).thenThrow(new SpectrumListenerInitializationException("ERROR"));

        davisListener.contextInitialized(servletContextEvent);

        verify(webApplicationContext).getBean("meteorologicalStationService");
        verify(webApplicationContext).getBean("mailService");

    }


}
