package com.monsanto.wms.web.controller.production;

import com.monsanto.wms.excel.manager.vo.FileLoadResultVO;
import com.monsanto.wms.exceptions.excel.ExcelLoadErrorException;
import com.monsanto.wms.exceptions.excel.InvalidDataException;
import com.monsanto.wms.exceptions.excel.InvalidLayoutException;
import com.monsanto.wms.persistence.model.CropStage;
import com.monsanto.wms.persistence.model.MeteorologicalStationHistoric;
import com.monsanto.wms.persistence.model.StrewRecommendation;
import com.monsanto.wms.service.catalog.CropStageService;
import com.monsanto.wms.service.catalog.MeteorologicalStationService;
import com.monsanto.wms.service.production.StrewRecommendationService;
import com.monsanto.wms.service.xls.MeteorologicalStationManualLoadService;
import com.monsanto.wms.web.controller.commons.BaseController;
import com.monsanto.wms.web.form.production.MetStationManualLoadForm;
import com.monsanto.wms.web.form.production.StrewRecommendationForm;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.context.MessageSource;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.*;

import static junit.framework.Assert.assertEquals;
import static junit.framework.Assert.assertNotNull;
import static junit.framework.Assert.assertNull;
import static org.mockito.Matchers.*;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

/**
 * Created by IntelliJ IDEA.
 * User: MANIET
 * Date: 6/6/13
 * Time: 12:50 PM
 * To change this template use File | Settings | File Templates.
 */
@RunWith(MockitoJUnitRunner.class)
public class MetStationManualLoadController_UT {

    @Mock
    private MeteorologicalStationManualLoadService meteorologicalStationManualLoadService;

    @Mock
    private MeteorologicalStationService meteorologicalStationService;

    @Mock
    private MessageSource messageSource;

    @Mock
    private MultipartFile multipartFile;

    private MetStationManualLoadController controller;
    private  HSSFWorkbook originalFile;
    @Before
    public void setUp() {
       controller = new MetStationManualLoadController(meteorologicalStationManualLoadService, meteorologicalStationService,messageSource);
       originalFile =  new HSSFWorkbook();
    }

    @Test
    public void testInitViewFirstTime(){
         HttpServletRequest request = mock(HttpServletRequest.class);
         when(request.getParameter("msg")).thenReturn("");
         when(request.getParameter("success")).thenReturn(null);
         assertEquals("production/metStationManualLoadBase", controller.initView(request).getViewName());
    }

    @Test
    public void testInitViewWithResult(){
          HttpServletRequest request = mock(HttpServletRequest.class);
         when(request.getParameter("msg")).thenReturn("");
         when(request.getParameter("success")).thenReturn("true");
         assertEquals("production/metStationManualLoadBase", controller.initView(request).getViewName());
    }

    @Test
    public void importData() throws IOException {
        FileLoadResultVO fileLoadResultVO = new FileLoadResultVO();
        fileLoadResultVO.setInsertedRows(1);
        when(multipartFile.getInputStream()).thenReturn(getWebFile());
        when(meteorologicalStationManualLoadService.importData(any(InputStream.class), anyLong(), anyInt(), anyInt(), anyInt())).thenReturn(fileLoadResultVO);
        assertNotNull(controller.importData(createForm(1,1)));
    }

     @Test
    public void importDataInvalidLayoutException() throws IOException {
        FileLoadResultVO fileLoadResultVO = new FileLoadResultVO();
        fileLoadResultVO.setInsertedRows(1);
        when(multipartFile.getInputStream()).thenReturn(getWebFile());
        when(meteorologicalStationManualLoadService.importData(any(InputStream.class), anyLong(), anyInt(), anyInt(), anyInt())).thenThrow(new InvalidLayoutException("ERROR"));
        assertNotNull(controller.importData(createForm(1,1)));
    }

     @Test
    public void importDataExcelLoadErrorException() throws IOException {
        FileLoadResultVO fileLoadResultVO = new FileLoadResultVO();
        fileLoadResultVO.setInsertedRows(1);
         when(multipartFile.getInputStream()).thenReturn(getWebFile());
        when(meteorologicalStationManualLoadService.importData(any(InputStream.class), anyLong(), anyInt(), anyInt(), anyInt())).thenThrow(new ExcelLoadErrorException("ERROR"));
        assertNotNull(controller.importData(createForm(1,1)));
    }

     @Test
    public void importDataInvalidDataInvalidDataException() throws IOException {
        FileLoadResultVO fileLoadResultVO = new FileLoadResultVO();
        fileLoadResultVO.setInsertedRows(1);
        when(multipartFile.getInputStream()).thenReturn(getWebFile());
        when(meteorologicalStationManualLoadService.importData(any(InputStream.class), anyLong(), anyInt(), anyInt(), anyInt())).thenThrow(new InvalidDataException(new ArrayList<String>()));
        assertNotNull(controller.importData(createForm(1,1)));
    }


    @Test
    public void searchByMeteorologicalStationAndYear() {
        Pageable pageable = mock(Pageable.class);
        when(meteorologicalStationService.search(-1,-1,1,1L,pageable)).thenReturn(new PageImpl<MeteorologicalStationHistoric>(new ArrayList<MeteorologicalStationHistoric>()));
        assertNotNull(controller.search(createForm(-1,-1),pageable));
    }

      @Test
    public void searchByMonthAndDay() {
        Pageable pageable = mock(Pageable.class);
        when(meteorologicalStationService.search(1,1,1,1L,pageable)).thenReturn(new PageImpl<MeteorologicalStationHistoric>(new ArrayList<MeteorologicalStationHistoric>()));
        assertNotNull(controller.search(createForm(1,1),pageable));
    }

     @Test
    public void searchByMonth() {
        Pageable pageable = mock(Pageable.class);
        when(meteorologicalStationService.search(-1,1,1,1L,pageable)).thenReturn(new PageImpl<MeteorologicalStationHistoric>(new ArrayList<MeteorologicalStationHistoric>()));
        assertNotNull(controller.search(createForm(-1,1),pageable));
    }


    @Test
    public void exportWithOutAnyResponseData() {
        when(meteorologicalStationService.search(1,1,1,1L,null)).thenReturn(new PageImpl<MeteorologicalStationHistoric>(new ArrayList<MeteorologicalStationHistoric>()));
        assertNull(controller.export(1L,1,1,1,"C"));
    }

    @Test
    public void exportWithResponseData() {
        List<MeteorologicalStationHistoric> ls = new ArrayList<MeteorologicalStationHistoric>();
        ls.add(new MeteorologicalStationHistoric());
        when(meteorologicalStationService.search(1, 1, 1, 1L, null)).thenReturn(new PageImpl<MeteorologicalStationHistoric>(ls));
        assertNotNull(controller.export(1L,1,1,1,"C"));
    }

     @Test
    public void exportWithResponseDataNull() {
        when(meteorologicalStationService.search(1, 1, 1, 1L, null)).thenReturn(null);
        assertNull(controller.export(1L,1,1,1,"C"));
    }



    private MetStationManualLoadForm createForm(Integer day,Integer month) {
        MetStationManualLoadForm form = new MetStationManualLoadForm();
        form.setDay(day);
        form.setMonth(month);
        form.setYear(1);
        form.setMetStationId(1L);
        form.setMetStationOwnerId(1L);
        form.setTemperatureIn("C");

        List<MultipartFile> ls = new ArrayList<MultipartFile>();
        ls.add(multipartFile);
        form.setFiles(ls);

        return form;
    }

    private ByteArrayInputStream getWebFile() throws IOException {
        HSSFSheet sheet = originalFile.createSheet("webFile");
        crateHeaders(sheet);
        insertContent(sheet);
        return getByteArrayInputStream();
    }

    private void crateHeaders(HSSFSheet sheet){
        HSSFRow header = sheet.createRow(0);
        int i = 0;
        header.createCell(i++).setCellValue("Tm");
        header.createCell(i++).setCellValue("TM");
        header.createCell(i++).setCellValue("Registry Time");

    }

    private void insertContent(HSSFSheet sheet){
        int i =0;
        int rowNum = 1;

        HSSFRow originalFileRow = sheet.createRow(rowNum++);;

        originalFileRow.createCell(i++).setCellValue(12.2);
        originalFileRow.createCell(i++).setCellValue(32.5);
        originalFileRow.createCell(i++).setCellValue("10:55");
    }

    private ByteArrayInputStream getByteArrayInputStream() throws IOException {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        originalFile.write(out);
        return new ByteArrayInputStream(out.toByteArray());
    }

}
