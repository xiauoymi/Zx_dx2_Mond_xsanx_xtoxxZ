package com.monsanto.wms.web.support.security;

import org.junit.Assert;
import org.junit.Test;

/**
 * Created by IntelliJ IDEA.
 * User: FJSIBA
 * Date: 21/08/12
 * Time: 03:31 PM
 * To change this template use File | Settings | File Templates.
 */
public class WAMUserLocatorIdFactory_UT {
    @Test
    public void testGetDefaultUserIdLocatorFromFactory(){
        WAMUserLocatorIdFactory lsiUserLocatorIdFactory = new WAMUserLocatorIdFactory();
        Assert.assertEquals("Test-User", lsiUserLocatorIdFactory.getUserIdLocator().getUserId());
    }

    @Test
    public void testGetDefaultUserIdLocatorFromFactoryNullLSI(){
        WAMUserLocatorIdFactory lsiUserLocatorIdFactory = new WAMUserLocatorIdFactory(null);
        Assert.assertEquals("Test-User", lsiUserLocatorIdFactory.getUserIdLocator().getUserId());
    }

    @Test(expected = SecurityException.class)
    public void testGetWAMUserIdLocatorFromFactory() throws SecurityException{
        new WAMUserLocatorIdFactory("dev").getUserIdLocator();
    }
}
