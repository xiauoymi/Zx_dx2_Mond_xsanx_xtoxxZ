package com.monsanto.wms.web.controller.catalog;


import com.monsanto.wms.service.catalog.PRExtrapolateDataService;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.context.MessageSource;

import javax.servlet.http.HttpServletRequest;

import static junit.framework.Assert.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

/**
 * Created by IntelliJ IDEA.
 * User: MANIET
 * Date: 6/6/13
 * Time: 12:50 PM
 * To change this template use File | Settings | File Templates.
 */
@RunWith(MockitoJUnitRunner.class)
public class PRExtrapolateDataController_UT {

    @Mock
    private PRExtrapolateDataService prExtrapolateDataService;

    @Mock
    private MessageSource messageSource;

    private PRExtrapolateDataController controller;

    @Before
    public void setUp() {
       controller = new PRExtrapolateDataController(prExtrapolateDataService, messageSource);
    }

    @Test
    public void testInitViewFirstTime(){
         HttpServletRequest request = mock(HttpServletRequest.class);
         when(request.getParameter("msg")).thenReturn("");
         when(request.getParameter("success")).thenReturn(null);
         assertEquals("/catalog/prExtrapolateData", controller.initView(request).getViewName());
    }

    @Test
    public void testInitViewWithResult(){
          HttpServletRequest request = mock(HttpServletRequest.class);
         when(request.getParameter("msg")).thenReturn("");
         when(request.getParameter("success")).thenReturn("true");
         assertEquals("/catalog/prExtrapolateData", controller.initView(request).getViewName());
    }

}
