package com.monsanto.wms.web.scheduleTasks.commonItems;

import com.monsanto.wms.spectrum.connectionItems.CreateURL;
import com.monsanto.wms.spectrum.connectionItems.CreateURLConnection;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.io.IOException;

import static junit.framework.Assert.assertNull;
import static org.mockito.Mockito.when;

/**
 * Created with IntelliJ IDEA.
 * User: MANIET
 * Date: 9/26/13
 * Time: 10:18 AM
 * To change this template use File | Settings | File Templates.
 */
@RunWith(MockitoJUnitRunner.class)
public class CreateURLConnection_UT {

    @Mock
    CreateURL createURL;

    CreateURLConnection createURLConnection;


    @Test
    public void initURLConnectionIOException() {

        when(createURL.getValidURL()).thenReturn(true);
        when(createURL.getUrl()).thenThrow(IOException.class);

        createURLConnection = new CreateURLConnection(createURL);
        assertNull(createURLConnection.getUrlConnection());

    }
}
