package com.monsanto.wms.web.controller.catalog;

import com.monsanto.wms.persistence.model.MeteorologicalStation;
import com.monsanto.wms.service.catalog.MeteorologicalStationService;
import com.monsanto.wms.web.controller.commons.BaseController;
import com.monsanto.wms.web.form.catalog.MeteorologicalStationForm;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.context.MessageSource;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.web.servlet.ModelAndView;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import static junit.framework.Assert.assertEquals;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyLong;
import static org.mockito.Mockito.*;

/**
 * Created by IntelliJ IDEA.
 * User: MANIET
 * Date: 6/6/13
 * Time: 12:50 PM
 * To change this template use File | Settings | File Templates.
 */
@RunWith(MockitoJUnitRunner.class)
public class  MeteorologicalStationController_UT {

    @Mock
    private  MeteorologicalStationService service;

    @Mock
    private MessageSource messageSource;

    private  MeteorologicalStationController controller;

    @Before
    public void setUp() {
        controller = new  MeteorologicalStationController(service, messageSource);
    }

    @Test
    public void controllerRedirectToCatalogHomePage() {
        ModelAndView modelAndView = controller.initView();
        Map<String, Object> objectMap =  modelAndView.getModelMap();
        Object form = objectMap.get( MeteorologicalStationController.DATA_FORM);

        assertEquals(1,objectMap.size());
        assertTrue(form instanceof  MeteorologicalStationForm);
        assertEquals(controller.METEORO_BASE, modelAndView.getViewName());

    }

    @Test
    public void saveRegistryWithOutErrors() {
        when(messageSource.getMessage("common.action.save.success", new Object[0], Locale.getDefault())).thenReturn("The record was saved successfully");

        ResponseEntity<BaseController.GenericResponse> response = controller.saveOrUpdate(createForm());
        assertTrue(response.getBody().isSuccess());
        assertEquals("The record was saved successfully", response.getBody().getMessages()[0]);
        verify(service).save(any( MeteorologicalStation.class));
        verifyNoMoreInteractions(service);
    }

    @Test
    public void searchMeteorologicalStationItemsWithResult() {

         MeteorologicalStation baseTemperature = new  MeteorologicalStation(1L);
        List< MeteorologicalStation> resultFromMetStationService = new ArrayList< MeteorologicalStation>();
        resultFromMetStationService.add(baseTemperature);
        Page< MeteorologicalStation> page = new PageImpl(resultFromMetStationService);

        Pageable pageable = mock(Pageable.class);
        when(service.search(1L, "MY_SATATION", true, 1L,pageable)).thenReturn(page);
        page = controller.search(createForm(), pageable);

        assertTrue(page.getContent().size() >= 1);
        assertTrue(page.getContent().get(0) instanceof  MeteorologicalStation);
        verify(service).search(1L, "MY_SATATION", true, 1L,pageable);
        verifyNoMoreInteractions(service);
    }

    @Test
    public void searchMeteorologicalStationWithOutResult() {

        List< MeteorologicalStation> resultFromMetStationService = new ArrayList< MeteorologicalStation>();
        Page< MeteorologicalStation> page = new PageImpl(resultFromMetStationService);

        Pageable pageable = mock(Pageable.class);
        when(service.search(1L, "MY_SATATION", true, 1L,pageable)).thenReturn(page);
        page = controller.search(createForm(), pageable);

        assertTrue(page.getContent().size() == 0);
        verify(service).search(1L, "MY_SATATION", true, 1L,pageable);
        verifyNoMoreInteractions(service);
    }


    @Test
    public void findMeteorologicalStationUsingValidId() {
         MeteorologicalStation baseTemperature = new  MeteorologicalStation(1L);

        when(service.findById(anyLong())).thenReturn(baseTemperature);

         MeteorologicalStation baseTemperatureResultOfFindingById = controller.findById(1L);

        verify(service).findById(1L);
        assertEquals(baseTemperature.getId(), baseTemperatureResultOfFindingById.getId());
        verifyNoMoreInteractions(service);
    }

    @Test
    public void findMeteorologicalStationUsingInvalidId() {

        when(service.findById(anyLong())).thenReturn(null);

         MeteorologicalStation baseTemperatureResultOfFindingById = controller.findById(-10L);

        verify(service).findById(-10L);
        assertNull(baseTemperatureResultOfFindingById);
        verifyNoMoreInteractions(service);
    }

    @Test
    public void successfullyDeletionOfAnItem() {
        when(messageSource.getMessage("common.action.delete.success", new Object[0], Locale.getDefault())).thenReturn("Record was successfully deleted");

        ResponseEntity<BaseController.GenericResponse> response = controller.delete(1L);

        assertTrue(response.getBody().isSuccess());
        assertEquals("Record was successfully deleted", response.getBody().getMessages()[0]);
        verify(service).delete(1L);
        verifyNoMoreInteractions(service);

    }

    private MeteorologicalStationForm createForm(){
        MeteorologicalStationForm form = new MeteorologicalStationForm();
        form.setActiveStatus(true);
        form.setMeteorologicalStationDescription("MY_SATATION");
        form.setMeteorologicalStationId(1L);
        form.setMeteorologicalStationLatitude("1");
        form.setMeteorologicalStationLongitude("2");
        form.setOwnerId(1L);
        form.setStationTypeId(1L);
        form.setStationSerialNumber("SERIAL");


        return form;
    }

}
