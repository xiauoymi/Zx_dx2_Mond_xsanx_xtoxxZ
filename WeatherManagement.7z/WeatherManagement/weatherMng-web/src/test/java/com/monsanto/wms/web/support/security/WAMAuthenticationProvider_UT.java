package com.monsanto.wms.web.support.security;

import com.monsanto.wms.persistence.model.*;
import com.monsanto.wms.service.security.UserService;
import com.monsanto.wms.service.security.UserSystemPrivilegesService;
import com.monsanto.wms.util.RoleType;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.*;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.*;

/**
 * Monsanto
 * Author:MANIET
 * Date: 10/08/13
 * Time: 11:49 AM
 */
@RunWith(MockitoJUnitRunner.class)
public class WAMAuthenticationProvider_UT {

    @Mock
    Authentication authentication;

    @Mock
    UserSystemPrivilegesService userSystemPrivilegesService;

    @Mock
    UserService userService;

    AuthenticationProvider authenticationProvider;

    @Before
    public void setUp(){

        authenticationProvider = new WAMAuthenticationProvider( userSystemPrivilegesService,userService );
    }

    @Test
    public void supports(){

        assertTrue( authenticationProvider.supports( Object.class ) );
    }

    @Test
    public void successfulAuthenticationIE(){

        List<UserSystemPrivileges> list = new ArrayList<UserSystemPrivileges>();
        UserSystemPrivileges item1 = new UserSystemPrivileges(null,"USER_ID",1L,1L);
        list.add(item1);

        when( authentication.getName() ).thenReturn( "USER_ID" );
        when( userSystemPrivilegesService.findByUserId(anyString()) ).thenReturn(list);

        Authentication result = authenticationProvider.authenticate( authentication );

        assertNotNull( result );
        assertTrue(    result instanceof UsernamePasswordAuthenticationToken );
        assertNotNull( result.getAuthorities() );

        verify( authentication ).getName();

    }

    @Test
    public void successfulAuthenticationOtherBrowserAccessGranted(){

        List<UserSystemPrivileges> list = new ArrayList<UserSystemPrivileges>();
        UserSystemPrivileges item1 = new UserSystemPrivileges(null,"USER_ID-$#$@$-PASSWORD",1L,1L);
        list.add(item1);

        when( authentication.getName() ).thenReturn( "USER_ID-$#$@$-PASSWORD" );
        when(userService.authenticated(anyString(),anyString())).thenReturn(true);
        when( userSystemPrivilegesService.findByUserId(anyString()) ).thenReturn(list);

        Authentication result = authenticationProvider.authenticate( authentication );

        assertNotNull( result );
        assertTrue(    result instanceof UsernamePasswordAuthenticationToken );
        assertNotNull( result.getAuthorities() );

        verify( authentication ).getName();

    }

     @Test(expected = UsernameNotFoundException.class)
    public void successfulAuthenticationOtherBrowserAccessDenied(){

        List<UserSystemPrivileges> list = new ArrayList<UserSystemPrivileges>();
        UserSystemPrivileges item1 = new UserSystemPrivileges(null,"USER_ID-$#$@$-PASSWORD",1L,1L);
        list.add(item1);

        when( authentication.getName() ).thenReturn( "USER_ID-$#$@$-PASSWORD" );
        when(userService.authenticated(anyString(),anyString())).thenReturn(false);

        Authentication result = authenticationProvider.authenticate( authentication );
    }

    @Test
    public void unsuccessfulAuthentication(){

        final String userName = "AWAWA";

        when( authentication.getName() ).thenReturn( userName );
        when( userSystemPrivilegesService.findByUserId(anyString())).thenReturn(null);

        try {

            authenticationProvider.authenticate( authentication );

        } catch (UsernameNotFoundException e) {

            assertEquals( "User 'AWAWA' not found", e.getMessage() );
        }

        verify( authentication ).getName();
    }

}
