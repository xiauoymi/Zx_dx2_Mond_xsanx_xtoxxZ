package com.monsanto.wms.web.views;

import com.monsanto.wms.persistence.model.MeteorologicalStation;
import com.monsanto.wms.persistence.model.MeteorologicalStationHistoric;
import com.monsanto.wms.web.view.ManualLoadExcelView;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by IntelliJ IDEA.
 * User: MANIET
 * Date: 8/1/13
 * Time: 4:15 PM
 * To change this template use File | Settings | File Templates.
 */
@RunWith(MockitoJUnitRunner.class)
public class ManualLoadExcelView_UT {

    @Mock
    HttpServletRequest request;

    @Mock
    HttpServletResponse response;

    ManualLoadExcelView view;

     @Before
    public void setUp(){
        view = new ManualLoadExcelView();
    }

    @Test
    public void buildExcelDocumentC() throws Exception {
        Map<String,Object> data = new HashMap<String,Object>();
        Map<String,Object> container = new HashMap<String,Object>();

        data.put("dataList",createList());
        data.put("tempType","C");

        container.put("excelData",data);

        view.buildExcelDocument( container, new HSSFWorkbook(), request, response );
    }

      @Test
    public void buildExcelDocumentF() throws Exception {
        Map<String,Object> data = new HashMap<String,Object>();
        Map<String,Object> container = new HashMap<String,Object>();

        data.put("dataList",createList());
        data.put("tempType","F");

        container.put("excelData",data);

        view.buildExcelDocument( container, new HSSFWorkbook(), request, response );
    }

    private List<MeteorologicalStationHistoric> createList(){

        List<MeteorologicalStationHistoric> ls = new ArrayList<MeteorologicalStationHistoric>();
        ls.add(createMeteorologicalStationHistoric());
        ls.add(createMeteorologicalStationHistoric());

        return ls;

    }

    private MeteorologicalStationHistoric createMeteorologicalStationHistoric() {
        MeteorologicalStationHistoric obj = new MeteorologicalStationHistoric();
        obj.setId(1L);
        obj.setMeteorologicalStation(new MeteorologicalStation("Description"));
        obj.setTempMax(1D);
        obj.setTempMin(1D);
        obj.setTimeRegistry("00:00:00");

        return obj;
    }
}
