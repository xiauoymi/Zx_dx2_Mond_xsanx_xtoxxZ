package com.monsanto.wms.web.scheduleTasks.listeners;

import com.monsanto.wms.exceptions.schedule.spectrum.SpectrumListenerInitializationException;
import com.monsanto.wms.service.catalog.MeteorologicalStationService;
import com.monsanto.wms.service.mail.MailService;
import com.monsanto.wms.service.security.UserSystemPrivilegesService;
import com.monsanto.wms.service.sheduleTasks.ScheduleErrorService;
import com.monsanto.wms.web.scheduleTasks.listeners.SpectrumListener;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

/**
 * Created by IntelliJ IDEA.
 * User: MANIET
 * Date: 7/11/13
 * Time: 10:45 AM
 * To change this template use File | Settings | File Templates.
 */
@RunWith(MockitoJUnitRunner.class)
public class SpectrumListener_UT {

    private SpectrumListener spectrumListener;
    private ServletContextEvent servletContextEvent;
    private ServletContext servletContext;
    private WebApplicationContext webApplicationContext;
    private MeteorologicalStationService meteorologicalStationService;
    private MailService mailService;
    private UserSystemPrivilegesService userSystemPrivilegesService;
    private ScheduleErrorService scheduleErrorService;

    @Before
    public void setUp() {
        spectrumListener = new SpectrumListener();

        servletContextEvent = mock(ServletContextEvent.class);
        servletContext = mock(ServletContext.class);
        webApplicationContext = mock(WebApplicationContext.class);
        meteorologicalStationService = mock(MeteorologicalStationService.class);
        mailService = mock(MailService.class);
        userSystemPrivilegesService = mock(UserSystemPrivilegesService.class);
        scheduleErrorService = mock (ScheduleErrorService.class);

    }

    private void initWhenStubsWithOutErrors() {
        when(servletContextEvent.getServletContext()).thenReturn(servletContext);
        when(WebApplicationContextUtils.getWebApplicationContext(servletContext)).thenReturn(webApplicationContext);
        when(webApplicationContext.getBean("meteorologicalStationService")).thenReturn(meteorologicalStationService);
        when(webApplicationContext.getBean("mailService")).thenReturn(mailService);
        when(webApplicationContext.getBean("userSystemPrivilegesService")).thenReturn(userSystemPrivilegesService);
        when(webApplicationContext.getBean("scheduleErrorService")).thenReturn(scheduleErrorService);
    }

    @Test
    public void contextInitializedWithAllServices() {
        initWhenStubsWithOutErrors();
        spectrumListener.contextInitialized(servletContextEvent);

        verify(webApplicationContext).getBean("meteorologicalStationService");
        verify(webApplicationContext).getBean("mailService");
        verify(webApplicationContext).getBean("userSystemPrivilegesService");
        verify(webApplicationContext).getBean("scheduleErrorService");

        assertTrue(spectrumListener.getSpectrumScheduleTask().isSpectrumScheduleTaskRunning());

    }

    @Test
    public void contextDestroyed() {
        initWhenStubsWithOutErrors();

        spectrumListener.contextInitialized(servletContextEvent);
        spectrumListener.contextDestroyed(servletContextEvent);

        assertFalse(spectrumListener.getSpectrumScheduleTask().isSpectrumScheduleTaskRunning());

    }

    @Test
    public void contextInitializedExceptionOnMeteorologicalService() {

        when(servletContextEvent.getServletContext()).thenReturn(servletContext);
        when(WebApplicationContextUtils.getWebApplicationContext(servletContext)).thenReturn(webApplicationContext);

        when(webApplicationContext.getBean("meteorologicalStationService")).thenReturn(null);


        try{
            spectrumListener.contextInitialized(servletContextEvent);
        }catch (SpectrumListenerInitializationException e){
            assertEquals("Spectrum meteorologicalStationService initialization failed",e.getMessage());
        }


    }

    @Test
    public void contextInitializedExceptionOnMailService() {

        when(servletContextEvent.getServletContext()).thenReturn(servletContext);
        when(WebApplicationContextUtils.getWebApplicationContext(servletContext)).thenReturn(webApplicationContext);

        when(webApplicationContext.getBean("meteorologicalStationService")).thenReturn(meteorologicalStationService);
        when(webApplicationContext.getBean("mailService")).thenReturn(null);

        try{
            spectrumListener.contextInitialized(servletContextEvent);
        }catch (SpectrumListenerInitializationException e){
            assertEquals("Spectrum mailService initialization failed",e.getMessage());
        }

    }

    @Test
    public void contextInitializedExceptionOnUserSystemPrivilegesService() {

        when(servletContextEvent.getServletContext()).thenReturn(servletContext);
        when(WebApplicationContextUtils.getWebApplicationContext(servletContext)).thenReturn(webApplicationContext);

        when(webApplicationContext.getBean("meteorologicalStationService")).thenReturn(meteorologicalStationService);
        when(webApplicationContext.getBean("mailService")).thenReturn(mailService);
        when(webApplicationContext.getBean("userSystemPrivilegesService")).thenReturn(null);

        try{
            spectrumListener.contextInitialized(servletContextEvent);
        }catch (SpectrumListenerInitializationException e){
            assertEquals("Spectrum userSystemPrivilegesService initialization failed",e.getMessage());
        }


    }

    @Test
    public void contextInitializedExceptionOnScheduleErrorService() {

        when(servletContextEvent.getServletContext()).thenReturn(servletContext);
        when(WebApplicationContextUtils.getWebApplicationContext(servletContext)).thenReturn(webApplicationContext);

        when(webApplicationContext.getBean("meteorologicalStationService")).thenReturn(meteorologicalStationService);
        when(webApplicationContext.getBean("mailService")).thenReturn(mailService);
        when(webApplicationContext.getBean("userSystemPrivilegesService")).thenReturn(userSystemPrivilegesService);
        when(webApplicationContext.getBean("scheduleErrorService")).thenReturn(null);

        try{
            spectrumListener.contextInitialized(servletContextEvent);
        }catch (SpectrumListenerInitializationException e){
            assertEquals("Spectrum scheduleErrorService initialization failed",e.getMessage());
        }


    }


}
