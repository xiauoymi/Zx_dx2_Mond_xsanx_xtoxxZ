package com.monsanto.wms.web.views;

import com.monsanto.wms.persistence.model.MeteorologicalStation;
import com.monsanto.wms.persistence.model.MeteorologicalStationHistoric;
import com.monsanto.wms.vo.ReportPRGeneralReportVO;
import com.monsanto.wms.web.view.ManualLoadExcelView;
import com.monsanto.wms.web.view.PRGeneralReportExcelView;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by IntelliJ IDEA.
 * User: MANIET
 * Date: 8/1/13
 * Time: 4:15 PM
 * To change this template use File | Settings | File Templates.
 */
@RunWith(MockitoJUnitRunner.class)
public class PRGeneralReportExcelView_UT {

    @Mock
    HttpServletRequest request;

    @Mock
    HttpServletResponse response;

    PRGeneralReportExcelView view;

     @Before
    public void setUp(){
        view = new PRGeneralReportExcelView();
    }

    @Test
    public void buildExcelDocumentC() throws Exception {
        Map<String,Object> data = new HashMap<String,Object>();
        Map<String,Object> container = new HashMap<String,Object>();

        data.put("dataList",createList());
        data.put("temperatureIn","C");
        data.put("tempUnder",10D);
        data.put("tempAbove",30D);
        data.put("metStation","MET_STATION");

        container.put("excelData",data);

        view.buildExcelDocument( container, new HSSFWorkbook(), request, response );
    }

      @Test
    public void buildExcelDocumentF() throws Exception {
        Map<String,Object> data = new HashMap<String,Object>();
        Map<String,Object> container = new HashMap<String,Object>();

        data.put("dataList",createList());
        data.put("temperatureIn","F");
        data.put("tempUnder",10D);
        data.put("tempAbove",30D);
        data.put("metStation","MET_STATION");

        container.put("excelData",data);

        view.buildExcelDocument( container, new HSSFWorkbook(), request, response );
    }

    private List<ReportPRGeneralReportVO> createList(){

        List<ReportPRGeneralReportVO> ls = new ArrayList<ReportPRGeneralReportVO>();
        ls.add(createReportPRGeneralReportVO());
        ls.add(createReportPRGeneralReportVO());

        return ls;

    }

    private ReportPRGeneralReportVO createReportPRGeneralReportVO() {
        ReportPRGeneralReportVO obj = new ReportPRGeneralReportVO();
        obj.setPrecipitation(1D);
        obj.setDampMax(10D);
        obj.setDampMin(10D);
        obj.setDateStr("10/10/2013");
        obj.setEvoTranspiration(10D);
        obj.setGduAcum(10D);
        obj.setGdus(10D);
        obj.setPeriodsAbove(10D);
        obj.setPeriodsUnder(10D);
        obj.setRadiation(10D);
        obj.setTempMaxC(10D);
        obj.setTempMaxF(10D);
        obj.setTempMinC(10D);
        obj.setTempMinF(10D);
        obj.setWindAVGBetween7And17Hrs(10D);
        obj.setWindSpeedMax(10D);
        obj.setWindSpeedMin(10D);

        return obj;
    }
}
