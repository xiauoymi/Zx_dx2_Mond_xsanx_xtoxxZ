package com.monsanto.wms.web.scheduleTasks.davis;

import com.monsanto.wms.exceptions.WMSException;
import com.monsanto.wms.persistence.model.*;
import com.monsanto.wms.service.catalog.MeteorologicalStationService;
import com.monsanto.wms.service.mail.MailService;
import com.monsanto.wms.service.security.UserSystemPrivilegesService;
import com.monsanto.wms.web.scheduleTasks.davis.xmlObjects.DavisItemsDetail;
import com.monsanto.wms.web.scheduleTasks.davis.xmlObjects.DavisXMLReader;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.List;

import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyLong;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

/**
 * Created by IntelliJ IDEA.
 * User: MANIET
 * Date: 7/11/13
 * Time: 8:01 AM
 * To change this template use File | Settings | File Templates.
 */
@RunWith(MockitoJUnitRunner.class)
public class DAVISTimer_UT {

    @Mock
    private MeteorologicalStationService meteorologicalStationService;
     @Mock
    private MailService mailService;

    @Mock
    private UserSystemPrivilegesService userSystemPrivilegesService;

    private DAVISTimer davisTimer;

    private final Long DAVIS_STATION =1L;

    @Before
    public void setUp() {
         davisTimer = new DAVISTimer(meteorologicalStationService,mailService,userSystemPrivilegesService);
     }

    @Test
    public void runDefault(){
        ReadAndStoreDavisXMLFromURL readAndStoreDavisXMLFromURL = mock(ReadAndStoreDavisXMLFromURL.class);
        DavisXMLReader davisXMLReader = createDavisXMLReader();
        List<MeteorologicalStation> ls = new ArrayList<MeteorologicalStation>();
        ls.add(createStation());
        when(meteorologicalStationService.findByTypeStationsWithUsrPwd(DAVIS_STATION)).thenReturn(ls);
        when(readAndStoreDavisXMLFromURL.startDavisXMLReading()).thenReturn(davisXMLReader);
        when(meteorologicalStationService.save(any(MeteorologicalStationHistoric.class))) .thenReturn(any(MeteorologicalStationHistoric.class));
        davisTimer.run();
    }

     @Test
    public void runWithExceptionRetrievingStations(){
        when(meteorologicalStationService.findByTypeStationsWithUsrPwd(DAVIS_STATION)).thenThrow(new WMSException("ERROR"));
        davisTimer.run();
    }

    @Test
    public void runWithExceptionStoringData(){
        ReadAndStoreDavisXMLFromURL readAndStoreDavisXMLFromURL = mock(ReadAndStoreDavisXMLFromURL.class);
        DavisXMLReader davisXMLReader = createDavisXMLReader();
        List<MeteorologicalStation> ls = new ArrayList<MeteorologicalStation>();
        ls.add(createStation());
        when(meteorologicalStationService.findByTypeStationsWithUsrPwd(DAVIS_STATION)).thenReturn(ls);
        when(readAndStoreDavisXMLFromURL.startDavisXMLReading()).thenReturn(davisXMLReader);
        when(meteorologicalStationService.save(any(MeteorologicalStationHistoric.class))) .thenThrow(new WMSException("ERROR"));
        davisTimer.run();
    }

    @Test
    public void runWithOutMetStations(){
        when(meteorologicalStationService.findByTypeStationsWithUsrPwd(DAVIS_STATION)).thenReturn(null);
        davisTimer.run();
    }

    @Test
    public void runInvalidUsrPwd(){
        ReadAndStoreDavisXMLFromURL readAndStoreDavisXMLFromURL = mock(ReadAndStoreDavisXMLFromURL.class);
        DavisXMLReader davisXMLReader = createDavisXMLReader();
        List<MeteorologicalStation> ls = new ArrayList<MeteorologicalStation>();
        MeteorologicalStation meteorologicalStation = createStation();
        meteorologicalStation.setPwd("NONE");
        ls.add(meteorologicalStation);
        when(meteorologicalStationService.findByTypeStationsWithUsrPwd(DAVIS_STATION)).thenReturn(ls);
        when(readAndStoreDavisXMLFromURL.startDavisXMLReading()).thenReturn(davisXMLReader);
        when(userSystemPrivilegesService.getMailDistributionListByArea(anyLong())).thenReturn(createListOfUserSystemPrivileges());

        davisTimer.run();
    }

    private List<UserSystemPrivileges> createListOfUserSystemPrivileges(){
        UserSystemPrivileges userSystemPrivileges = new UserSystemPrivileges(1L,"USER_ID",1L,1L);
        userSystemPrivileges.getUser().setEmail("MAIL@MAIL:COM");

        List<UserSystemPrivileges> ls = new ArrayList<UserSystemPrivileges>();
        ls.add(userSystemPrivileges);

        return ls;

    }

    private MeteorologicalStation createStation(){

        MeteorologicalStation meteorologicalStation = new MeteorologicalStation();
        meteorologicalStation.setId(1L);
        meteorologicalStation.setUserName("kosmos");    //USER AND PWD VALID
        meteorologicalStation.setPwd("kosmos2008");
        meteorologicalStation.setDescription("MI_STATION_DESC");
        meteorologicalStation.setLatitude("1");
        meteorologicalStation.setLongitude("2");
        meteorologicalStation.setOwner(new MeteorologicalStationOwner("OWNER_DESC"));
        meteorologicalStation.getOwner().setId(1L);
        meteorologicalStation.getOwner().setArea(new Area(1L));
        meteorologicalStation.setStationType(new StationType("TYPE"));

        return meteorologicalStation;
    }

    private DavisXMLReader createDavisXMLReader(){
        DavisXMLReader davisXMLReader = new DavisXMLReader();
        davisXMLReader.setDavisStationDetails(new DavisItemsDetail());

        davisXMLReader.getDavisStationDetails().setMaxTempF(1D);
        davisXMLReader.getDavisStationDetails().setMaxTempTime("00:00");
        davisXMLReader.getDavisStationDetails().setMinTempF(1D);
        davisXMLReader.getDavisStationDetails().setMinTempTime("00:00");
        davisXMLReader.getDavisStationDetails().setMaxPressure(1D);
        davisXMLReader.getDavisStationDetails().setMaxPressureTime("00:00");
        davisXMLReader.getDavisStationDetails().setMinPressure(1D);
        davisXMLReader.getDavisStationDetails().setMinPressureTime("00:00");
        davisXMLReader.getDavisStationDetails().setRain(1D);
        davisXMLReader.getDavisStationDetails().setRadiation(1D);
        davisXMLReader.getDavisStationDetails().setRadiationTime("00:00");
        davisXMLReader.getDavisStationDetails().setWind(1D);
        davisXMLReader.getDavisStationDetails().setWindTime("00:00");
        return davisXMLReader;
    }
}
