package com.monsanto.wms.web.controller.tools;

import com.monsanto.wms.service.tools.CalculatorService;
import com.monsanto.wms.vo.GeneralCalculationByDayVO;
import com.monsanto.wms.vo.GeneralCalculationByGduVO;
import com.monsanto.wms.vo.PeriodToGDUsVO;
import com.monsanto.wms.vo.WeekCalculationVO;
import com.monsanto.wms.web.form.tools.CalculatorForm;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.context.MessageSource;

import java.util.ArrayList;
import java.util.Collections;

import static junit.framework.Assert.assertEquals;
import static junit.framework.Assert.assertNotNull;
import static org.mockito.Matchers.*;
import static org.mockito.Mockito.when;

/**
 * Created by IntelliJ IDEA.
 * User: MANIET
 * Date: 6/6/13
 * Time: 12:50 PM
 * To change this template use File | Settings | File Templates.
 */
@RunWith(MockitoJUnitRunner.class)
public class CalculatorController_UT {

    @Mock
    private CalculatorService service;

    @Mock
    private MessageSource messageSource;

    private CalculatorController controller;

    @Before
    public void setUp() {
       controller = new CalculatorController(service, messageSource);
    }

    @Test
    public void testInitView(){
         assertEquals("tools/calculatorBase", controller.initView().getViewName());
    }

    @Test
    public void generalCalculationByGDU(){

        when(service.getGeneralCalculationByGDU(anyInt(),anyInt(),anyInt(),anyInt(),anyLong(),anyDouble(),anyDouble(),anyDouble(),anyString())).thenReturn(new GeneralCalculationByGduVO());
        assertNotNull(controller.generalCalculationBy(createForm("GDU")));
    }

    @Test
    public void generalCalculationByDay(){
        when(service.getGeneralCalculationByDay(anyInt(), anyInt(), anyInt(), anyInt(), anyLong(),  anyInt(),anyDouble(),anyDouble(),anyString())).thenReturn(new GeneralCalculationByDayVO());
        assertNotNull(controller.generalCalculationBy(createForm("DAYS")));
    }

    @Test
    public void getTemperaturesUnderZeroFirstLoad(){
        when(service.getUnderZeroCalculation(anyInt(), anyInt(), anyLong())).thenReturn(Collections.EMPTY_LIST);
        assertNotNull(controller.getTemperaturesUnderZero(createForm("DAYS")));
    }

    @Test
    public void getTemperaturesUnderZeroSecondLoad(){
        CalculatorForm form = createForm("DAYS");
        form.setFirstLoad("NO");
        when(service.getUnderZeroCalculation(anyInt(), anyInt(), anyLong())).thenReturn(Collections.EMPTY_LIST);
        assertNotNull(controller.getTemperaturesUnderZero(form));
    }

    @Test
    public void weeklyCalculationByGDU(){

        when(service.getWeeklyCalculationByGDU(anyInt(), anyInt(), anyInt(), anyLong(), anyDouble(),anyDouble(),anyDouble(),anyString())).thenReturn(new ArrayList<WeekCalculationVO>());
        assertNotNull(controller.weeklyCalculationBy(createForm("GDU")));
    }

    @Test
    public void weeklyCalculationByDay(){

        when(service.getWeeklyCalculationByDay(anyInt(), anyInt(), anyInt(), anyLong(), anyInt(),anyString())).thenReturn(new ArrayList<WeekCalculationVO>());
        assertNotNull(controller.weeklyCalculationBy(createForm("Day")));
    }

    @Test
    public void periodToGDU(){

        when(service.getPeriodToGDU(anyInt(), anyInt(), anyInt(), anyInt(), anyInt(), anyInt(), anyLong(), anyDouble(), anyDouble(),anyString())).thenReturn(new PeriodToGDUsVO());
        assertNotNull(controller.periodToGDU(createForm("Day")));
    }

    private CalculatorForm createForm(){
       return createForm("GDU");
    }

    private CalculatorForm createForm(String type){
        CalculatorForm form = new CalculatorForm();

        form.setStartDate(2012);
        form.setEndDate(2014);
        form.setMeteorologicalStationId(1L);

        form.setDayOfTheMonthA(1);
        form.setCalculationTypeA(type);
        form.setCurrentValueA(10D);
        form.setMonthSectionA(1);

        form.setCalculationTypeB(type);
        form.setCurrentValueB(10D);
        form.setMonthSectionB(1);

        form.setMonthSectionC(1);
        form.setMonthSectionC(1);
        form.setFirstLoad("YES");

        form.setTempMax(10D);
        form.setTempMin(5D);

        form.setDayDStart(1);
        form.setDayDEnd(1);

        form.setMonthSectionEndD(1);
        form.setMonthSectionStartD(1);

        return form;
    }


}
