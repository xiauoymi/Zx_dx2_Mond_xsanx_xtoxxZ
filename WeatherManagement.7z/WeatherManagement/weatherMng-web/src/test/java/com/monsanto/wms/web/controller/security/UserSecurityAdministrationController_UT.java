package com.monsanto.wms.web.controller.security;

import com.monsanto.wms.persistence.model.ProductionZone;
import com.monsanto.wms.persistence.model.UserSystemPrivileges;
import com.monsanto.wms.service.catalog.ProductionZoneService;
import com.monsanto.wms.service.security.UserSystemPrivilegesService;
import com.monsanto.wms.web.controller.catalog.ProductionZoneController;
import com.monsanto.wms.web.controller.commons.BaseController;
import com.monsanto.wms.web.form.catalog.ProductionZoneForm;
import com.monsanto.wms.web.form.security.UserAdministrationForm;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.context.MessageSource;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;

import java.util.Collections;
import java.util.Locale;

import static junit.framework.Assert.assertEquals;
import static junit.framework.Assert.assertNotNull;
import static org.mockito.Matchers.anyLong;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

/**
 * Created by IntelliJ IDEA.
 * User: MANIET
 * Date: 6/6/13
 * Time: 12:50 PM
 * To change this template use File | Settings | File Templates.
 */
@RunWith(MockitoJUnitRunner.class)
public class UserSecurityAdministrationController_UT {

    @Mock
    private UserSystemPrivilegesService service;

    @Mock
    private MessageSource messageSource;

    private UserSecurityAdministrationController controller;

    @Before
    public void setUp() {
       controller = new UserSecurityAdministrationController(service, messageSource);
    }

    @Test
    public void testInitView(){
         assertEquals("security/userSecurityAdm", controller.initView().getViewName());
    }

    @Test
    public void saveOrUpdate(){
        when(messageSource.getMessage("common.action.save.success",new Object[0],Locale.getDefault())).thenReturn("The record was saved successfully");
        ResponseEntity<BaseController.GenericResponse> response =  controller.saveOrUpdate(createForm());
        assertEquals("The record was saved successfully",response.getBody().getMessages()[0]);
    }

    @Test
    public void search(){
        Pageable pageable = mock(Pageable.class);
        Page page = mock(Page.class);
        when(service.search("USER_ID",1L,1L,true,pageable)).thenReturn(page);

        assertNotNull(controller.search(createForm(),pageable));
    }


    @Test
    public void findById(){

        when(service.findById(anyLong())).thenReturn(new UserSystemPrivileges());

        assertNotNull(controller.findById(anyLong()));
    }

    @Test
    public void delete(){
        when(messageSource.getMessage("common.action.delete.success",new Object[0],Locale.getDefault())).thenReturn("Record was successfully deleted");
        ResponseEntity<BaseController.GenericResponse> response =  controller.delete(1L);
        assertEquals("Record was successfully deleted",response.getBody().getMessages()[0]);
    }


    @Test
    public void loadCollectionAreas(){

        when(service.loadCollectionAreas()).thenReturn(Collections.EMPTY_LIST);

        assertNotNull(controller.loadCollectionAreas());
    }

    @Test
    public void loadCollectionRoles(){

        when(service.loadCollectionRoles(anyLong())).thenReturn(Collections.EMPTY_LIST);

        assertNotNull(controller.loadCollectionRoles(anyLong()));
    }

    @Test
    public void loadCollectionUser(){

        when(service.loadCollectionUser(anyString())).thenReturn(Collections.EMPTY_LIST);

        assertNotNull(controller.loadCollectionUser(anyString()));
    }

    private UserAdministrationForm createForm(){
        UserAdministrationForm form = new UserAdministrationForm();
        form.setActiveStatus(true);
        form.setAreaId(1L);
        form.setRoleId(1L);
        form.setUserId("USER_ID");
        form.setUserPrivilegesId(1L);

        return form;
    }


}
