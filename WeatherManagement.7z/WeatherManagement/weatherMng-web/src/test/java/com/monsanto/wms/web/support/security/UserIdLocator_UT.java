package com.monsanto.wms.web.support.security;

import com.monsanto.wms.support.security.DefaultUserIdLocator;
import com.monsanto.wms.support.security.UserIdLocator;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;

import javax.security.auth.Subject;
import java.security.Principal;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

/**
 * Created by IntelliJ IDEA.
 * User: FJSIBA
 * Date: 21/08/12
 * Time: 01:18 PM
 * To change this template use File | Settings | File Templates.
 */
@RunWith(MockitoJUnitRunner.class)
public class UserIdLocator_UT {

    private Subject subject;
    private UserIdLocator userIdLocator;

    @Before
    public void setUp() {
        Principal principal = mock(Principal.class);
        when(principal.getName()).thenReturn("TEST");

        Collection<Principal> principals = Arrays.asList(principal);
        Collection<Object> pubCredentials = Collections.emptyList();
        Collection<Object> privCredentials = Collections.emptyList();
        subject = new Subject(true, new HashSet<Principal>(principals), new HashSet<Object>(pubCredentials), new HashSet<Object>(privCredentials));

    }

    @Test
    public void testWAMUserIdLocator() {
        userIdLocator = new WAMUserIdLocator(subject);
        Assert.assertNotNull(userIdLocator.getUserId());
    }

    @Test
    public void testWAMUserIdLocatorNoPrincipals() {
        subject = new Subject();
        userIdLocator = new WAMUserIdLocator(subject);
        Assert.assertNull(userIdLocator.getUserId());
    }

    @Test
    public void testDefaultUserIdLocator() {
        userIdLocator = new DefaultUserIdLocator();
        Assert.assertNotNull(userIdLocator.getUserId());
    }
}
