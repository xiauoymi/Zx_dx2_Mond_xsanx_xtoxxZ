package com.monsanto.wms.web.controller.catalog;

import com.monsanto.wms.persistence.model.CropStage;
import com.monsanto.wms.service.catalog.CropStageService;
import com.monsanto.wms.web.controller.commons.BaseController;
import com.monsanto.wms.web.form.catalog.CropStageForm;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.context.MessageSource;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.web.servlet.ModelAndView;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import static junit.framework.Assert.assertEquals;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyLong;
import static org.mockito.Mockito.*;

/**
 * Created by IntelliJ IDEA.
 * User: MANIET
 * Date: 6/6/13
 * Time: 12:50 PM
 * To change this template use File | Settings | File Templates.
 */
@RunWith(MockitoJUnitRunner.class)
public class CropStageController_UT {

    @Mock
    private CropStageService service;

    @Mock
    private MessageSource messageSource;

    private CropStageController controller;

    @Before
    public void setUp() {
        controller = new CropStageController(service, messageSource);
    }

    @Test
    public void controllerRedirectToCatalogHomePage() {
        ModelAndView modelAndView = controller.initView();
        Map<String, Object> objectMap = modelAndView.getModelMap();
        Object form = objectMap.get(CropStageController.DATA_FORM);

        assertEquals(1, objectMap.size());
        assertTrue(form instanceof CropStageForm);
        assertEquals(controller.CROP_STAGE_BASE, modelAndView.getViewName());

    }

    @Test
    public void saveRegistryWithOutErrors() {
        when(messageSource.getMessage("common.action.save.success", new Object[0], Locale.getDefault())).thenReturn("The record was saved successfully");

        ResponseEntity<BaseController.GenericResponse> response = controller.saveOrUpdate(createForm());
        assertTrue(response.getBody().isSuccess());
        assertEquals("The record was saved successfully", response.getBody().getMessages()[0]);
        verify(service).save(any(CropStage.class));
        verifyNoMoreInteractions(service);
    }

    @Test
    public void searchCropStageItemsWithResult() {

        CropStage cropStage = new CropStage(1L);
        List<CropStage> resultFromCropStageService = new ArrayList<CropStage>();
        resultFromCropStageService.add(cropStage);
        Page<CropStage> page = new PageImpl(resultFromCropStageService);

        Pageable pageable = mock(Pageable.class);
        when(service.search("MY_CROP_STAGE", 1L, 1L, true, pageable)).thenReturn(page);
        page = controller.search(createForm(), pageable);

        assertTrue(page.getContent().size() >= 1);
        assertTrue(page.getContent().get(0) instanceof CropStage);
        verify(service).search("MY_CROP_STAGE", 1L, 1L, true, pageable);
        verifyNoMoreInteractions(service);
    }

    @Test
    public void searchCropStageWithOutResult() {

        List<CropStage> resultFromCropStageService = new ArrayList<CropStage>();
        Page<CropStage> page = new PageImpl(resultFromCropStageService);

        Pageable pageable = mock(Pageable.class);
        when(service.search("MY_CROP_STAGE", 1L, 1L, true, pageable)).thenReturn(page);
        page = controller.search(createForm(), pageable);

        assertTrue(page.getContent().size() == 0);
        verify(service).search("MY_CROP_STAGE", 1L, 1L, true, pageable);
        verifyNoMoreInteractions(service);
    }


    @Test
    public void findCropStageUsingValidId() {
        CropStage cropStage = new CropStage(1L);

        when(service.findById(anyLong())).thenReturn(cropStage);

        CropStage cropStageResultOfFindingById = controller.findById(1L);

        verify(service).findById(1L);
        assertEquals(cropStage.getId(), cropStageResultOfFindingById.getId());
        verifyNoMoreInteractions(service);
    }

    @Test
    public void findCropStageUsingInvalidId() {

        when(service.findById(anyLong())).thenReturn(null);

        CropStage cropResultOfFindingById = controller.findById(-10L);

        verify(service).findById(-10L);
        assertNull(cropResultOfFindingById);
        verifyNoMoreInteractions(service);
    }

    @Test
    public void successfullyDeletionOfAnItem() {
        when(messageSource.getMessage("common.action.delete.success", new Object[0], Locale.getDefault())).thenReturn("Record was successfully deleted");

        ResponseEntity<BaseController.GenericResponse> response = controller.delete(1L, false);

        assertTrue(response.getBody().isSuccess());
        assertEquals("Record was successfully deleted", response.getBody().getMessages()[0]);
        verify(service).delete(1L, false);
        verifyNoMoreInteractions(service);

    }

    private CropStageForm createForm() {
        CropStageForm form = new CropStageForm();
        form.setActiveStatus(true);
        form.setCropStageDescription("MY_CROP_STAGE");
        form.setCropStageId(1L);
        form.setCropId(1L);
        form.setCropTypeId(1L);

        return form;
    }


}
