package com.monsanto.wms.web.scheduleTasks.davis;

import com.monsanto.wms.persistence.model.Area;
import com.monsanto.wms.persistence.model.MeteorologicalStation;
import com.monsanto.wms.service.mail.MailService;
import com.monsanto.wms.service.security.UserSystemPrivilegesService;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import static junit.framework.Assert.assertNull;

/**
 * Created with IntelliJ IDEA.
 * User: MANIET
 * Date: 9/26/13
 * Time: 9:47 AM
 * To change this template use File | Settings | File Templates.
 */
@RunWith(MockitoJUnitRunner.class)
public class ReadAndStoreDavisXMLFromURL_UT {


    MeteorologicalStation meteorologicalStation;
    @Mock
    MailService mailService;
    @Mock
    UserSystemPrivilegesService userSystemPrivilegesService;

    ReadAndStoreDavisXMLFromURL readAndStoreDavisXMLFromURL;
    @Before
    public void setUp() {
        meteorologicalStation = new MeteorologicalStation(1L,"DESC","","",true,1L,"USR","PWD",2L,"SERIAL","GFRAN1");
        meteorologicalStation.getOwner().setArea(new Area(1L));
    }

    @Test
    public void testIOExceptionWhenReading(){
        readAndStoreDavisXMLFromURL = new ReadAndStoreDavisXMLFromURL("http://someURl.com",meteorologicalStation,mailService,userSystemPrivilegesService);
        assertNull(readAndStoreDavisXMLFromURL.startDavisXMLReading());
    }

    @Test
    public void testMalFormedURL(){
        readAndStoreDavisXMLFromURL = new ReadAndStoreDavisXMLFromURL("htt23p://someURl.com",meteorologicalStation,mailService,userSystemPrivilegesService);
        assertNull(readAndStoreDavisXMLFromURL.startDavisXMLReading());
    }
}
