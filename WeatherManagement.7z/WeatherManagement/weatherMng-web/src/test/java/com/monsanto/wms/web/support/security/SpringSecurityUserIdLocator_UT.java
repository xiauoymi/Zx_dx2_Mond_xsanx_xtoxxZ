package com.monsanto.wms.web.support.security;

import com.monsanto.wms.persistence.model.User;
import com.monsanto.wms.support.security.UserIdLocator;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;

import static junit.framework.Assert.assertEquals;

/**
 * Monsanto
 * Author: Luis Miguel Arteaga Rios (lmarte@monsanto.com)
 * Date: 4/12/12
 * Time: 12:57 PM
 */
@RunWith(MockitoJUnitRunner.class)
public class SpringSecurityUserIdLocator_UT {

    UserIdLocator locator;

    @Before
    public void setUp(){

        locator = new SpringSecurityUserIdLocator();
    }

    @Test
    public void getUserId(){

          final String userId = "MANIET";

        User user = new User();
        user.setId( userId );

        Authentication authentication = new UsernamePasswordAuthenticationToken( userId, "DUMMY" );
        ((UsernamePasswordAuthenticationToken) authentication ).setDetails( user );
        SecurityContextHolder.getContext().setAuthentication( authentication );

        assertEquals(userId, locator.getUserId());
    }


    @Test
       public void getUserIdNull(){

           User user = null;

           Authentication authentication = new UsernamePasswordAuthenticationToken( null, "DUMMY" );
           ((UsernamePasswordAuthenticationToken) authentication ).setDetails( user );
           SecurityContextHolder.getContext().setAuthentication( authentication );

           assertEquals("N/A", locator.getUserId());
       }

}
