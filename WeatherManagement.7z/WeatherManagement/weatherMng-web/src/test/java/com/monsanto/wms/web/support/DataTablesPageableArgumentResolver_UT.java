package com.monsanto.wms.web.support;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.core.MethodParameter;
import org.springframework.data.domain.Pageable;
import org.springframework.web.bind.support.WebArgumentResolver;
import org.springframework.web.context.request.NativeWebRequest;

import static junit.framework.Assert.*;
import static org.mockito.Mockito.*;

/**
 * Created by IntelliJ IDEA.
 * User: ACISS
 * Date: 5/10/12
 * Time: 08:45 PM
 */
@RunWith(MockitoJUnitRunner.class)
@SuppressWarnings("unchecked")
public class DataTablesPageableArgumentResolver_UT {

    private WebArgumentResolver service;

    @Before
    public void setUp() {
        service = new DataTablesPageableArgumentResolver();
    }

    @Test
    public void testPaginationObjectWithoutSort() throws Exception {
        MethodParameter mp = mock(MethodParameter.class);
        NativeWebRequest nr = mock(NativeWebRequest.class);
        Class c = Pageable.class;
        when(mp.getParameterType()).thenReturn(c);
        when(nr.getParameter("iDisplayStart")).thenReturn("0");
        when(nr.getParameter("iDisplayLength")).thenReturn("25");
        when(nr.getParameter("iColumns")).thenReturn("3");
        when(nr.getParameter("iSortCol_0")).thenReturn("0");
        when(nr.getParameter("sSortDir_0")).thenReturn("asc");
        when(nr.getParameter("mDataProp_0")).thenReturn("entityField");
        when(nr.getParameter("iSortCol_1")).thenReturn("1");
        when(nr.getParameter("sSortDir_2")).thenReturn("asc");
        when(nr.getParameter("mDataProp_3")).thenReturn("entityField3");
        Object page = service.resolveArgument(mp, nr);
        assertTrue(page instanceof Pageable);
        Pageable p = (Pageable) page;
        assertEquals(0, p.getPageNumber());
        assertEquals(25, p.getPageSize());
        assertEquals("entityField", p.getSort().getOrderFor("entityField").getProperty());
        assertEquals("ASC", p.getSort().getOrderFor("entityField").getDirection().name());
        verify(nr).getParameter("iDisplayStart");
        verify(nr).getParameter("iDisplayLength");
        verify(nr).getParameter("iColumns");
        verify(nr).getParameter("iSortCol_0");
        verify(nr).getParameter("sSortDir_0");
        verify(nr).getParameter("mDataProp_0");
        verify(nr).getParameter("iSortCol_1");
        verify(nr).getParameter("sSortDir_2");
    }

    @Test
    public void testPaginationObjectWithSort() throws Exception {
        MethodParameter mp = mock(MethodParameter.class);
        NativeWebRequest nr = mock(NativeWebRequest.class);
        Class c = Pageable.class;
        when(mp.getParameterType()).thenReturn(c);
        when(nr.getParameter("iDisplayStart")).thenReturn("25");
        when(nr.getParameter("iDisplayLength")).thenReturn("25");
        when(nr.getParameter("iColumns")).thenReturn("0");
        Object page = service.resolveArgument(mp, nr);
        assertTrue(page instanceof Pageable);
        assertEquals(1, ((Pageable) page).getPageNumber());
        assertEquals(25, ((Pageable) page).getPageSize());
        assertNull(((Pageable) page).getSort());
        verify(nr).getParameter("iDisplayStart");
        verify(nr).getParameter("iDisplayLength");
        verify(nr).getParameter("iColumns");
    }

    @Test
    public void testDefaultPaginationObject() throws Exception {
        MethodParameter mp = mock(MethodParameter.class);
        NativeWebRequest nr = mock(NativeWebRequest.class);
        Class c = Pageable.class;
        when(mp.getParameterType()).thenReturn(c);
        Object page = service.resolveArgument(mp, nr);
        assertTrue(page instanceof Pageable);
        assertEquals(0, ((Pageable) page).getPageNumber());
        assertEquals(10, ((Pageable) page).getPageSize());
        assertNull(((Pageable) page).getSort());
        verify(nr).getParameter("iDisplayLength");
        verify(nr).getParameter("iColumns");
    }

    @Test
    public void testDefaultPaginationByInvalid() throws Exception {
        MethodParameter mp = mock(MethodParameter.class);
        NativeWebRequest nr = mock(NativeWebRequest.class);
        Class c = Pageable.class;
        when(mp.getParameterType()).thenReturn(c);
        when(nr.getParameter("iDisplayStart")).thenReturn("aa");
        when(nr.getParameter("iDisplayLength")).thenReturn("aa");
        when(nr.getParameter("iColumns")).thenReturn("aa");
        Object page = service.resolveArgument(mp, nr);
        assertTrue(page instanceof Pageable);
        assertEquals(0, ((Pageable) page).getPageNumber());
        assertEquals(10, ((Pageable) page).getPageSize());
        assertNull(((Pageable) page).getSort());
        verify(nr).getParameter("iDisplayLength");
        verify(nr).getParameter("iColumns");
    }

    @Test
    public void testNotPageableObject() throws Exception {
        MethodParameter mp = mock(MethodParameter.class);
        NativeWebRequest nr = mock(NativeWebRequest.class);
        Class c = String.class;
        when(mp.getParameterType()).thenReturn(c);
        assertEquals(WebArgumentResolver.UNRESOLVED, service.resolveArgument(mp, nr));
    }

}
