package com.monsanto.wms.web.scheduleTasks.helper;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;
import com.monsanto.wms.spectrum.helpers.SpectrumDateUtils;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

/**
 * Created with IntelliJ IDEA.
 * User: MANIET
 * Date: 12/2/13
 * Time: 3:22 PM
 * To change this template use File | Settings | File Templates.
 */
@RunWith(MockitoJUnitRunner.class)
public class SpectrumDateUtils_UT {

    @Test
    public void getCurrentDateMinusOneDay() throws ParseException {
        Calendar c = Calendar.getInstance();
        c.add(Calendar.DAY_OF_MONTH,-1);
        String currentDate = c.get(Calendar.YEAR) + "-" + (c.get(Calendar.MONTH)+ SpectrumDateUtils.MONTH_OFFSET) + "-" + c.get(Calendar.DAY_OF_MONTH);

        assertEquals(SpectrumDateUtils.spectrumFormatDate(currentDate),SpectrumDateUtils.getDayBeforeOfCurrentDate());
    }

    @Test
    public void specifySpectrumFormatDate() throws ParseException {
        assertEquals(new SimpleDateFormat("yyyy-MM-dd").parse("2013-12-01"),SpectrumDateUtils.spectrumFormatDate("2013-12-01"));
    }

    @Test
    public void getCurrentDateMinusOneDayAsString() throws ParseException {
        assertTrue(SpectrumDateUtils.getDayBeforeOfCurrentDateAsString() instanceof  String);
    }

    @Test
    public void formatCurrentFileDate() throws ParseException {
        String fileDate = "2013-10-11" ;
        Date transformedDate = SpectrumDateUtils.formatCurrentFileDate(fileDate);
        String formatedDate = new SimpleDateFormat("yyyy-MM-dd").format(transformedDate);
        assertEquals(fileDate,formatedDate);
    }

    @Test
    public void getDayOfRegistryTimeWhenDateIsComplete(){
        assertEquals(new Integer(1),SpectrumDateUtils.getDayOfRegistryTime("2013-30-01"));
    }

    @Test
    public void getDayOfRegistryTimeWhenDateIsIncomplete(){
        Calendar currentDateTime = Calendar.getInstance();
        assertEquals(new Integer(currentDateTime.get(Calendar.DAY_OF_MONTH)),SpectrumDateUtils.getDayOfRegistryTime("2013"));
    }

    @Test
    public void getMonthOfRegistryTimeWhenDateIsComplete(){
        assertEquals(new Integer(30),SpectrumDateUtils.getMonthOfRegistryTime("2013-30-01"));
    }

    @Test
    public void getMonthOfRegistryTimeWhenDateIsIncomplete(){
        Calendar currentDateTime = Calendar.getInstance();
        assertEquals(new Integer(currentDateTime.get(Calendar.MONTH)+1),SpectrumDateUtils.getMonthOfRegistryTime("2013"));
    }

    @Test
    public void getYearOfRegistryTimeWhenDateIsComplete(){
        assertEquals(new Integer(2013),SpectrumDateUtils.getYearOfRegistryTime("2013-30-01"));
    }

    @Test
    public void getYearOfRegistryTimeWhenDateIsIncomplete(){
        Calendar currentDateTime = Calendar.getInstance();
        assertEquals(new Integer(currentDateTime.get(Calendar.YEAR)),SpectrumDateUtils.getYearOfRegistryTime("2013"));
    }
}
