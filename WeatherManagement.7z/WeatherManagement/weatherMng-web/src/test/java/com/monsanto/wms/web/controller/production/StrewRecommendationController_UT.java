package com.monsanto.wms.web.controller.production;

import com.monsanto.wms.exceptions.WMSException;
import com.monsanto.wms.persistence.model.CropStage;
import com.monsanto.wms.persistence.model.StrewRecommendation;
import com.monsanto.wms.service.catalog.CropStageService;
import com.monsanto.wms.service.production.StrewRecommendationService;
import com.monsanto.wms.vo.RealReportStrewRecommendationVO;
import com.monsanto.wms.web.controller.commons.BaseController;
import com.monsanto.wms.web.form.production.StrewRecommendationForm;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.context.MessageSource;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;

import javax.servlet.http.HttpServletRequest;
import java.util.*;

import static junit.framework.Assert.assertEquals;
import static junit.framework.Assert.assertNotNull;
import static junit.framework.Assert.assertNull;
import static org.mockito.Matchers.*;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

/**
 * Created by IntelliJ IDEA.
 * User: MANIET
 * Date: 6/6/13
 * Time: 12:50 PM
 * To change this template use File | Settings | File Templates.
 */
@RunWith(MockitoJUnitRunner.class)
public class StrewRecommendationController_UT {

    @Mock
    private StrewRecommendationService strewRecommendationService;

    @Mock
     private CropStageService cropStageService;

    @Mock
    private MessageSource messageSource;

    private StrewRecommendationController controller;

    @Before
    public void setUp() {
       controller = new StrewRecommendationController(strewRecommendationService, cropStageService,messageSource);
    }

    @Test
       public void testInit(){
            assertEquals("production/strewRecommendationBase", controller.initView().getViewName());
       }


    @Test
    public void testInitWithCropViewTD(){
         when(cropStageService.loadCollectionNotDefaultByCropId(anyLong())).thenReturn(Collections.EMPTY_LIST);
         assertEquals("production/strewRecommendationBase", controller.initWithCrop(createForm("00015874369")).getViewName());
    }

    @Test
    public void testInitWithCropViewFieldProduction(){
        when(cropStageService.loadCollectionNotDefaultByCropId(anyLong())).thenReturn(Collections.EMPTY_LIST);
        assertEquals("production/strewRecommendationBase", controller.initWithCrop(createForm("225487445")).getViewName());
    }

    @Test
    public void testInitWithCropViewProductionResearch(){
        when(cropStageService.loadCollectionNotDefaultByCropId(anyLong())).thenReturn(Collections.EMPTY_LIST);
        assertEquals("production/strewRecommendationBase", controller.initWithCrop(createForm("8645132132")).getViewName());
    }


    @Test
    public void testInitWithCropViewNullType() {
        assertEquals("production/denied", controller.initWithCrop(createForm(null)).getViewName());
    }


    @Test
    public void getRealReport(){
        when(strewRecommendationService.getRealReport(anyInt(),anyInt(),anyInt(),anyInt(),anyLong(),anyDouble(),anyDouble(),anyString(),anyString())).thenReturn(Collections.EMPTY_LIST);
        assertNotNull(controller.getRealReport(createForm()));
    }

    @Test
    public void saveOrUpdate(){
        StrewRecommendation strewRecommendation = new StrewRecommendation(1L);

        HttpServletRequest request = mock(HttpServletRequest.class);
        request.setAttribute("cropStageDetail-1",1);

        Collection<CropStage> cropStageVariables = new ArrayList<CropStage>();
        cropStageVariables.add(new CropStage(1L,"STAGE",1L,true,true));

        controller.setCropStageVariables(cropStageVariables);

        when(strewRecommendationService.save(any(StrewRecommendation.class))).thenReturn(strewRecommendation);
        when(messageSource.getMessage("common.action.save.success", new Object[0], Locale.getDefault())).thenReturn("The record was saved successfully");
        ResponseEntity<BaseController.GenericResponse> response =  controller.saveOrUpdate(createForm(),request);
        assertEquals("The record was saved successfully",response.getBody().getMessages()[0]);
    }

    @Test
    public void search(){
        Pageable pageable = mock(Pageable.class);
        Page page = mock(Page.class);
        when(strewRecommendationService.search(1L,1L,1L,"",pageable)).thenReturn(page);

        assertNotNull(controller.search(createForm(), pageable));
    }


    @Test
    public void findById(){

        when(strewRecommendationService.findById(anyLong())).thenReturn(new StrewRecommendation());
        assertNotNull(controller.findById(anyLong()));
    }

    @Test
    public void delete(){
        when(messageSource.getMessage("common.action.delete.success",new Object[0],Locale.getDefault())).thenReturn("Record was successfully deleted");
        ResponseEntity<BaseController.GenericResponse> response =  controller.delete(1L);
        assertEquals("Record was successfully deleted",response.getBody().getMessages()[0]);
    }

     @Test
    public void exportWithOutAnyResponseData() {
        controller.setRealReportInformation(new ArrayList<RealReportStrewRecommendationVO>());
        assertNull(controller.export(1, "MyStation","C"));
    }

    @Test
    public void exportWithResponseData() {
        List<RealReportStrewRecommendationVO> ls = new ArrayList<RealReportStrewRecommendationVO>();
        ls.add(new RealReportStrewRecommendationVO());
        controller.setRealReportInformation(ls);
        assertNotNull(controller.export(1, "MyStation","C"));
    }

     @Test
    public void exportWithResponseDataNull() {
         controller.setRealReportInformation(null);
        assertNull(controller.export(1, "MyStation","C"));
    }

     private  StrewRecommendationForm createForm(){
         return createForm("");

     }
    private StrewRecommendationForm createForm(String sourceCode){
        StrewRecommendationForm form = new StrewRecommendationForm();
        form.setCropStage(1L);
        form.setCropStageValue(1D);
        form.setCropStageVariables(new ArrayList<CropStage>());
        form.setHybridId(1L);
        form.setProductionCyclesId(1L);
        form.setProductionZoneId(1L);
        form.setStrewRecommendationId(1L);

        form.setRealReportCrop(1L);
        form.setRealReportCropStageData("");
        form.setRealReportCropType(1L);
        form.setRealReportMetStationId(1L);
        form.setRealReportMetStationOwnerId(1L);
        form.setRealReportStartDay(1);
        form.setRealReportStartMonth(1);
        form.setRealReportYear(2013);
        form.setRealReportTempMax(1D);
        form.setRealReportTempMin(1D);

        form.setSourceCode(sourceCode);
        form.setTemperatureIn("C");

        return form;
    }


}
