package com.monsanto.wms.web.scheduleTasks.commonItems;

import com.monsanto.wms.spectrum.connectionItems.CreateInputStreamReader;
import com.monsanto.wms.spectrum.connectionItems.CreateURL;
import com.monsanto.wms.spectrum.connectionItems.CreateURLConnection;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URLConnection;

import static junit.framework.Assert.assertEquals;
import static junit.framework.Assert.assertNotNull;
import static junit.framework.Assert.assertNull;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@RunWith(PowerMockRunner.class)
@PrepareForTest({CreateURLConnection.class})
public class CreateInputStreamReader_UT {

    private CreateInputStreamReader createInputStreamReader;

    @Mock
    private CreateURLConnection createURLConnection;

    @Mock
    private URLConnection urlConnection;

    @Mock
    private InputStream inputStream;

    @Test
    public void getInputStreamReader_throwsError(){
        when(createURLConnection.getValidURLConnection()).thenReturn(false);
        createInputStreamReader = new CreateInputStreamReader(createURLConnection);

        createInputStreamReader.getInputStreamReader();
        assertNotNull(createInputStreamReader.getError());
        assertEquals("Invalid URL connection", createInputStreamReader.getError());
    }

    @Test
    public void getInputStreamReader_returnsValidStream() throws Exception{
        when(createURLConnection.getValidURLConnection()).thenReturn(true);
        when(createURLConnection.getUrlConnection()).thenReturn(urlConnection);
        when(urlConnection.getInputStream()).thenReturn(inputStream);
        createInputStreamReader = new CreateInputStreamReader(createURLConnection);

        createInputStreamReader.getInputStreamReader();

        assertNull(createInputStreamReader.getError());
        verify(createURLConnection.getUrlConnection());
    }
}
