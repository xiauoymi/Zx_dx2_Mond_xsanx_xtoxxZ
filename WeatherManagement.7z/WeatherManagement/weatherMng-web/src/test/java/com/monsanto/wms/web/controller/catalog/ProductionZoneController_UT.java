package com.monsanto.wms.web.controller.catalog;

import com.monsanto.wms.persistence.model.ProductionZone;
import com.monsanto.wms.service.catalog.ProductionZoneService;
import com.monsanto.wms.web.controller.commons.BaseController;
import com.monsanto.wms.web.form.catalog.ProductionZoneForm;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.context.MessageSource;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.web.servlet.ModelAndView;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import static junit.framework.Assert.assertEquals;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyLong;
import static org.mockito.Mockito.*;

/**
 * Created by IntelliJ IDEA.
 * User: MANIET
 * Date: 6/6/13
 * Time: 12:50 PM
 * To change this template use File | Settings | File Templates.
 */
@RunWith(MockitoJUnitRunner.class)
public class ProductionZoneController_UT {

    @Mock
    private ProductionZoneService service;

    @Mock
    private MessageSource messageSource;

    private ProductionZoneController controller;

    @Before
    public void setUp() {
        controller = new ProductionZoneController(service, messageSource);
    }

    @Test
    public void controllerRedirectToCatalogHomePage() {
        ModelAndView modelAndView = controller.initView();
        Map<String, Object> objectMap =  modelAndView.getModelMap();
        Object form = objectMap.get(ProductionZoneController.DATA_FORM);

        assertEquals(1,objectMap.size());
        assertTrue(form instanceof ProductionZoneForm);
        assertEquals(controller.PRODUCTION_ZONE_BASE, modelAndView.getViewName());

    }

    @Test
    public void saveRegistryWithOutErrors() {
        when(messageSource.getMessage("common.action.save.success", new Object[0], Locale.getDefault())).thenReturn("The record was saved successfully");

        ResponseEntity<BaseController.GenericResponse> response = controller.saveOrUpdate(createForm());
        assertTrue(response.getBody().isSuccess());
        assertEquals("The record was saved successfully", response.getBody().getMessages()[0]);
        verify(service).save(any(ProductionZone.class));
        verifyNoMoreInteractions(service);
    }

    @Test
    public void searchProductionZoneItemsWithResult() {

        ProductionZone productionZone = new ProductionZone(1L);
        List<ProductionZone> resultFromProductionZoneService = new ArrayList<ProductionZone>();
        resultFromProductionZoneService.add(productionZone);
        Page<ProductionZone> page = new PageImpl(resultFromProductionZoneService);

        Pageable pageable = mock(Pageable.class);
        when(service.search("MY_PROD_ZONE", true, pageable)).thenReturn(page);
        page = controller.search(createForm(), pageable);

        assertTrue(page.getContent().size() >= 1);
        assertTrue(page.getContent().get(0) instanceof ProductionZone);
        verify(service).search("MY_PROD_ZONE", true, pageable);
        verifyNoMoreInteractions(service);
    }

    @Test
    public void searchProductionZoneWithOutResult() {

        List<ProductionZone> resultFromProductionZoneService = new ArrayList<ProductionZone>();
        Page<ProductionZone> page = new PageImpl(resultFromProductionZoneService);

        Pageable pageable = mock(Pageable.class);
        when(service.search("MY_PROD_ZONE", true, pageable)).thenReturn(page);
        page = controller.search(createForm(), pageable);

        assertTrue(page.getContent().size() == 0);
        verify(service).search("MY_PROD_ZONE", true, pageable);
        verifyNoMoreInteractions(service);
    }


    @Test
    public void findProductionZoneUsingValidId() {
        ProductionZone productionZone = new ProductionZone(1L);

        when(service.findById(anyLong())).thenReturn(productionZone);

        ProductionZone productionZoneResultOfFindingById = controller.findById(1L);

        verify(service).findById(1L);
        assertEquals(productionZone.getId(), productionZoneResultOfFindingById.getId());
        verifyNoMoreInteractions(service);
    }

    @Test
    public void findProductionZoneUsingInvalidId() {

        when(service.findById(anyLong())).thenReturn(null);

        ProductionZone productionZoneResultOfFindingById = controller.findById(-10L);

        verify(service).findById(-10L);
        assertNull(productionZoneResultOfFindingById);
        verifyNoMoreInteractions(service);
    }

    @Test
    public void successfullyDeletionOfAnItem() {
        when(messageSource.getMessage("common.action.delete.success", new Object[0], Locale.getDefault())).thenReturn("Record was successfully deleted");

        ResponseEntity<BaseController.GenericResponse> response = controller.delete(1L);

        assertTrue(response.getBody().isSuccess());
        assertEquals("Record was successfully deleted", response.getBody().getMessages()[0]);
        verify(service).delete(1L);
        verifyNoMoreInteractions(service);

    }

    private ProductionZoneForm createForm(){
        ProductionZoneForm form = new ProductionZoneForm();
        form.setActiveStatus(true);
        form.setProductionZoneDescription("MY_PROD_ZONE");
        form.setProductionZoneId(1L);

        return form;
    }


}
