package com.monsanto.wms.web.controller.catalog;

import com.monsanto.wms.persistence.model.MeteorologicalStationOwner;
import com.monsanto.wms.service.catalog.MeteorologicStationOwnerService;
import com.monsanto.wms.web.controller.commons.BaseController;
import com.monsanto.wms.web.form.catalog.MeteorologicalStationOwnerForm;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.context.MessageSource;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.web.servlet.ModelAndView;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import static junit.framework.Assert.assertEquals;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyLong;
import static org.mockito.Mockito.*;

/**
 * Created by IntelliJ IDEA.
 * User: MANIET
 * Date: 6/6/13
 * Time: 12:50 PM
 * To change this template use File | Settings | File Templates.
 */
@RunWith(MockitoJUnitRunner.class)
public class MeteorologicalStationOwnerController_UT {

    @Mock
    private MeteorologicStationOwnerService service;

    @Mock
    private MessageSource messageSource;

    private MeteorologicalStationOwnerController controller;

    @Before
    public void setUp() {
        controller = new MeteorologicalStationOwnerController(service, messageSource);
    }

    @Test
    public void controllerRedirectToCatalogHomePage() {
        ModelAndView modelAndView = controller.initView();
        Map<String, Object> objectMap =  modelAndView.getModelMap();
        Object form = objectMap.get(MeteorologicalStationOwnerController.DATA_FORM);

        assertEquals(1,objectMap.size());
        assertTrue(form instanceof MeteorologicalStationOwnerForm);
        assertEquals(controller.METEOROLOGICAL_STATION_OWNER_BASE, modelAndView.getViewName());

    }

    @Test
    public void saveRegistryWithOutErrors() {
        when(messageSource.getMessage("common.action.save.success", new Object[0], Locale.getDefault())).thenReturn("The record was saved successfully");

        ResponseEntity<BaseController.GenericResponse> response = controller.saveOrUpdate(createForm());
        assertTrue(response.getBody().isSuccess());
        assertEquals("The record was saved successfully", response.getBody().getMessages()[0]);
        verify(service).save(any(MeteorologicalStationOwner.class));
        verifyNoMoreInteractions(service);
    }

    @Test
    public void searchMeteorologicalStationOwnerItemsWithResult() {

        MeteorologicalStationOwner baseTemperature = new MeteorologicalStationOwner(1L);
        List<MeteorologicalStationOwner> resultFromMetStationOwnerService = new ArrayList<MeteorologicalStationOwner>();
        resultFromMetStationOwnerService.add(baseTemperature);
        Page<MeteorologicalStationOwner> page = new PageImpl(resultFromMetStationOwnerService);

        Pageable pageable = mock(Pageable.class);
        when(service.search("MY_MET_STATION","MY_MET_STATION_SHORT", 1L, true, pageable)).thenReturn(page);
        page = controller.search(createForm(), pageable);

        assertTrue(page.getContent().size() >= 1);
        assertTrue(page.getContent().get(0) instanceof MeteorologicalStationOwner);
        verify(service).search("MY_MET_STATION","MY_MET_STATION_SHORT", 1L, true, pageable);
        verifyNoMoreInteractions(service);
    }

    @Test
    public void searchMeteorologicalStationOwnerWithOutResult() {

        List<MeteorologicalStationOwner> resultFromMetStationOwnerService = new ArrayList<MeteorologicalStationOwner>();
        Page<MeteorologicalStationOwner> page = new PageImpl(resultFromMetStationOwnerService);

        Pageable pageable = mock(Pageable.class);
        when(service.search("MY_MET_STATION","MY_MET_STATION_SHORT", 1L, true, pageable)).thenReturn(page);
        page = controller.search(createForm(), pageable);

        assertTrue(page.getContent().size() == 0);
        verify(service).search("MY_MET_STATION","MY_MET_STATION_SHORT", 1L, true, pageable);
        verifyNoMoreInteractions(service);
    }


    @Test
    public void findMeteorologicalStationOwnerUsingValidId() {
        MeteorologicalStationOwner baseTemperature = new MeteorologicalStationOwner(1L);

        when(service.findById(anyLong())).thenReturn(baseTemperature);

        MeteorologicalStationOwner baseTemperatureResultOfFindingById = controller.findById(1L);

        verify(service).findById(1L);
        assertEquals(baseTemperature.getId(), baseTemperatureResultOfFindingById.getId());
        verifyNoMoreInteractions(service);
    }

    @Test
    public void findMeteorologicalStationOwnerUsingInvalidId() {

        when(service.findById(anyLong())).thenReturn(null);

        MeteorologicalStationOwner baseTemperatureResultOfFindingById = controller.findById(-10L);

        verify(service).findById(-10L);
        assertNull(baseTemperatureResultOfFindingById);
        verifyNoMoreInteractions(service);
    }

    @Test
    public void successfullyDeletionOfAnItem() {
        when(messageSource.getMessage("common.action.delete.success", new Object[0], Locale.getDefault())).thenReturn("Record was successfully deleted");

        ResponseEntity<BaseController.GenericResponse> response = controller.delete(1L);

        assertTrue(response.getBody().isSuccess());
        assertEquals("Record was successfully deleted", response.getBody().getMessages()[0]);
        verify(service).delete(1L);
        verifyNoMoreInteractions(service);

    }

    private MeteorologicalStationOwnerForm createForm(){
        MeteorologicalStationOwnerForm form = new MeteorologicalStationOwnerForm();
        form.setActiveStatus(true);
        form.setMeteorologicalStationOwnerDescription("MY_MET_STATION");
        form.setMeteorologicalStationOwnerShortDescription("MY_MET_STATION_SHORT");
        form.setMeteorologicalStationOwnerId(1L);
        form.setAreaId(1L);

        return form;
    }


}
