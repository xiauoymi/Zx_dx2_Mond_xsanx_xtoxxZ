package com.monsanto.wms.web.controller.production;


import com.monsanto.wms.service.production.PRGeneralReportService;
import com.monsanto.wms.vo.ReportPRGeneralReportVO;
import com.monsanto.wms.web.form.production.PRGeneralReportForm;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.context.MessageSource;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;

import javax.servlet.http.HttpServletRequest;

import java.util.ArrayList;
import java.util.List;

import static junit.framework.Assert.*;
import static org.mockito.Matchers.*;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

/**
 * Created by IntelliJ IDEA.
 * User: MANIET
 * Date: 6/6/13
 * Time: 12:50 PM
 * To change this template use File | Settings | File Templates.
 */
@RunWith(MockitoJUnitRunner.class)
public class PRGeneralReportController_UT {

    @Mock
    private PRGeneralReportService prGeneralReportService;

    @Mock
    private MessageSource messageSource;

    private PRGeneralReportController controller;

    @Before
    public void setUp() {
       controller = new PRGeneralReportController(prGeneralReportService, messageSource);
    }

    @Test
    public void testInitViewFirstTime(){
         HttpServletRequest request = mock(HttpServletRequest.class);
         when(request.getParameter("msg")).thenReturn("");
         when(request.getParameter("success")).thenReturn(null);
         assertEquals("production/reports/prGeneralReportBase", controller.initView(request).getViewName());
    }

    @Test
    public void testInitViewWithResult(){
          HttpServletRequest request = mock(HttpServletRequest.class);
         when(request.getParameter("msg")).thenReturn("");
         when(request.getParameter("success")).thenReturn("true");
         assertEquals("production/reports/prGeneralReportBase", controller.initView(request).getViewName());
    }


    @Test
    public void search() {
        Pageable pageable = mock(Pageable.class);
        assertNotNull(controller.search(createForm(),pageable));
    }


    @Test
    public void exportWithOutAnyResponseData() {
        when(prGeneralReportService.getReport(1,1,1,1,1,1,1L,1D,1D,"",1D,1D,null)).thenReturn(new ArrayList<ReportPRGeneralReportVO>());
        assertNull(controller.export(1, 1,1, 1, 1, 1, "", 1L, 1D, 1D, "",1D,1D,"C"));
    }

    @Test
    public void exportWithResponseData() {
        List<ReportPRGeneralReportVO> ls = new ArrayList<ReportPRGeneralReportVO>();
        ls.add(new ReportPRGeneralReportVO());
        when(prGeneralReportService.getReport(1,1,1,1,1,1,1L,1D,1D,"",1D,1D,null)).thenReturn(ls);

       assertNotNull(controller.export(1, 1,1, 1, 1, 1, "", 1L, 1D, 1D, "",1D,1D,"C"));
    }

       @Test
    public void exportWithResponseDataNull() {
       when(prGeneralReportService.getReport(1,1,1,1,1,1,1L,1D,1D,"",1D,1D,null)).thenReturn(null);
       assertNull(controller.export(1, 1,1, 1, 1, 1, "", 1L, 1D, 1D, "",1D,1D,"C"));
    }


    private PRGeneralReportForm createForm(){
        PRGeneralReportForm form = new PRGeneralReportForm();
        form.setCropId(1L);
        form.setCropType(1L);
        form.setMeteorologicalStationDesc("");
        form.setMeteorologicalStationId(1L);
        form.setMetStationOwnerId(1L);
        form.setTempMax(1D);
        form.setTempMin(1D);
   //     form.setYear(2013);



        return form;
    }


}
