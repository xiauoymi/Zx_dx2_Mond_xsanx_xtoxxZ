package com.monsanto.wms.web.controller.catalog;

import com.monsanto.wms.persistence.model.ProductionCycles;
import com.monsanto.wms.service.catalog.ProductionCycleService;
import com.monsanto.wms.web.controller.commons.BaseController;
import com.monsanto.wms.web.form.catalog.ProductionCycleForm;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.context.MessageSource;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.web.servlet.ModelAndView;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import static junit.framework.Assert.assertEquals;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyLong;
import static org.mockito.Mockito.*;

/**
 * Created by IntelliJ IDEA.
 * User: MANIET
 * Date: 6/6/13
 * Time: 12:50 PM
 * To change this template use File | Settings | File Templates.
 */
@RunWith(MockitoJUnitRunner.class)
public class ProductionCycleController_UT {

    @Mock
    private ProductionCycleService service;

    @Mock
    private MessageSource messageSource;

    private ProductionCycleController controller;

    @Before
    public void setUp() {
        controller = new ProductionCycleController(service, messageSource);
    }

    @Test
    public void controllerRedirectToCatalogHomePage() {
        ModelAndView modelAndView = controller.initView();
        Map<String, Object> objectMap = modelAndView.getModelMap();
        Object form = objectMap.get(ProductionCycleController.DATA_FORM);

        assertEquals(1, objectMap.size());
        assertTrue(form instanceof ProductionCycleForm);
        assertEquals(controller.PRODUCTION_CYCLE_BASE, modelAndView.getViewName());

    }

    @Test
    public void saveRegistryWithOutErrors() {
        when(messageSource.getMessage("common.action.save.success", new Object[0], Locale.getDefault())).thenReturn("The record was saved successfully");

        ResponseEntity<BaseController.GenericResponse> response = controller.saveOrUpdate(createForm());
        assertTrue(response.getBody().isSuccess());
        assertEquals("The record was saved successfully", response.getBody().getMessages()[0]);
        verify(service).save(any(ProductionCycles.class));
        verifyNoMoreInteractions(service);
    }

    @Test
    public void searchProductionCycleItemsWithResult() {

        ProductionCycles productionCycle = new ProductionCycles(1L);
        List<ProductionCycles> resultFromProdCycleService = new ArrayList<ProductionCycles>();
        resultFromProdCycleService.add(productionCycle);
        Page<ProductionCycles> page = new PageImpl(resultFromProdCycleService);

        Pageable pageable = mock(Pageable.class);
        when(service.search("MY_PROD_CYCLE", true, pageable)).thenReturn(page);
        page = controller.search(createForm(), pageable);

        assertTrue(page.getContent().size() >= 1);
        assertTrue(page.getContent().get(0) instanceof ProductionCycles);
        verify(service).search("MY_PROD_CYCLE", true, pageable);
        verifyNoMoreInteractions(service);
    }

    @Test
    public void searchProductionCycleWithOutResult() {

        List<ProductionCycles> resultFromProdCycleService = new ArrayList<ProductionCycles>();
        Page<ProductionCycles> page = new PageImpl(resultFromProdCycleService);

        Pageable pageable = mock(Pageable.class);
        when(service.search("MY_PROD_CYCLE", true, pageable)).thenReturn(page);
        page = controller.search(createForm(), pageable);

        assertTrue(page.getContent().size() == 0);
        verify(service).search("MY_PROD_CYCLE", true, pageable);
        verifyNoMoreInteractions(service);
    }


    @Test
    public void findProductionCycleUsingValidId() {
        ProductionCycles productionCycle = new ProductionCycles(1L);

        when(service.findById(anyLong())).thenReturn(productionCycle);

        ProductionCycles productionCycleResultOfFindingById = controller.findById(1L);

        verify(service).findById(1L);
        assertEquals(productionCycle.getId(), productionCycleResultOfFindingById.getId());
        verifyNoMoreInteractions(service);
    }

    @Test
    public void findProductionCycleUsingInvalidId() {

        when(service.findById(anyLong())).thenReturn(null);

        ProductionCycles productionCycleResultOfFindingById = controller.findById(-10L);

        verify(service).findById(-10L);
        assertNull(productionCycleResultOfFindingById);
        verifyNoMoreInteractions(service);
    }

    @Test
    public void successfullyDeletionOfAnItem() {
        when(messageSource.getMessage("common.action.delete.success", new Object[0], Locale.getDefault())).thenReturn("Record was successfully deleted");

        ResponseEntity<BaseController.GenericResponse> response = controller.delete(1L);

        assertTrue(response.getBody().isSuccess());
        assertEquals("Record was successfully deleted", response.getBody().getMessages()[0]);
        verify(service).delete(1L);
        verifyNoMoreInteractions(service);

    }


    private ProductionCycleForm createForm() {
        ProductionCycleForm form = new ProductionCycleForm();
        form.setActiveStatus(true);
        form.setProductionCycleDescription("MY_PROD_CYCLE");
        form.setProductionCycleId(1L);

        return form;
    }


}
