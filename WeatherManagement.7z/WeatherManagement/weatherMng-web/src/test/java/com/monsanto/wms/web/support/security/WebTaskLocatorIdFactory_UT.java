package com.monsanto.wms.web.support.security;

import com.monsanto.wms.support.security.TaskIdLocator;
import com.monsanto.wms.web.support.WebTaskIdLocator;
import com.monsanto.wms.web.support.WebTaskIdLocatorFactory;
import junit.framework.Assert;
import org.junit.Before;
import org.junit.Test;

import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.when;

/**
 * Created by IntelliJ IDEA.
 * User: FJSIBA
 * Date: 27/08/12
 * Time: 12:24 PM
 * To change this template use File | Settings | File Templates.
 */
public class WebTaskLocatorIdFactory_UT {
    private WebTaskIdLocatorFactory webTaskIdLocatorFactory;

    @Before
    public void setUp(){
        webTaskIdLocatorFactory = new WebTaskIdLocatorFactory();
    }

    @Test
    public void testGetTaskIdLocatorObjectFromServletRequest(){
        TaskIdLocator taskIdLocator = webTaskIdLocatorFactory.getTaskIdLocator();
        Assert.assertNotNull(taskIdLocator);
        Assert.assertNotNull(taskIdLocator.getTaskId());
    }

    @Test
    public void testGetWebTaskIdLocator(){
        WebTaskIdLocatorFactory spy = spy(webTaskIdLocatorFactory);
        when(spy.getTaskIdLocator()).thenReturn(new WebTaskIdLocator("test/uri"));

        TaskIdLocator taskIdLocator = spy.getTaskIdLocator();

        Assert.assertNotNull(taskIdLocator);
        Assert.assertNotNull(taskIdLocator.getTaskId());

    }
}
