package com.monsanto.wms.web.scheduleTasks.helper;

import com.monsanto.wms.exceptions.davisSchedule.DavisSpectrumScheduleException;
import com.monsanto.wms.persistence.model.Area;
import com.monsanto.wms.persistence.model.MeteorologicalStation;
import com.monsanto.wms.persistence.model.UserSystemPrivileges;
import com.monsanto.wms.service.mail.MailService;
import com.monsanto.wms.service.security.UserSystemPrivilegesService;
import com.monsanto.wms.spectrum.helpers.ProcessReadURLError;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.List;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

/**
 * Created by IntelliJ IDEA.
 * User: MANIET
 * Date: 9/17/13
 * Time: 8:23 AM
 * To change this template use File | Settings | File Templates.
 */
@RunWith(MockitoJUnitRunner.class)
public class ProcessReadURLError_UT {

    @Mock
    MailService mailService;
    @Mock
    UserSystemPrivilegesService userSystemPrivilegesService;

    ProcessReadURLError processReadURLError;
    MeteorologicalStation meteorologicalStation;

    @Before
    public void setUp() {
        meteorologicalStation = new MeteorologicalStation(1L, "DESC", "", "", true, 1L, "USR", "PWD", 2L,"SERIAL","GFRAN1");
        meteorologicalStation.getOwner().setArea(new Area(1L));
        processReadURLError = new ProcessReadURLError(mailService, userSystemPrivilegesService, meteorologicalStation, "URL");
    }

    @Test
    public void sendErrorToDistributionListExceptionOnGetMessage() {
        Exception e = mock(Exception.class);
        when(e.getCause()).thenReturn(null);
        when(e.getMessage()).thenReturn("ERROR");
        processReadURLError.sendErrorToDistributionList(e, DavisSpectrumScheduleException.DAVIS);
    }

    @Test
    public void sendErrorToDistributionListSendingEmail() {
        Exception e = mock(Exception.class);
        when(e.getCause()).thenReturn(null);
        when(e.getMessage()).thenReturn("ERROR");
        when(userSystemPrivilegesService.getMailDistributionListByArea(1L)).thenReturn(getUserPrivilegeList("mail@mail.com"));
        processReadURLError.sendErrorToDistributionList(e,DavisSpectrumScheduleException.SPECTRUM);
    }

    @Test
    public void sendErrorToDistributionListNullEmail() {
        Exception e = mock(Exception.class);
        when(e.getCause()).thenReturn(null);
        when(e.getMessage()).thenReturn("ERROR");
        when(userSystemPrivilegesService.getMailDistributionListByArea(1L)).thenReturn(getUserPrivilegeList(null));
        processReadURLError.sendErrorToDistributionList(e,DavisSpectrumScheduleException.DAVIS);
    }

    @Test
    public void sendErrorToDistributionListBlankEmail() {
        Exception e = mock(Exception.class);
        when(e.getCause()).thenReturn(null);
        when(e.getMessage()).thenReturn("ERROR");
        when(userSystemPrivilegesService.getMailDistributionListByArea(1L)).thenReturn(getUserPrivilegeList(""));
        processReadURLError.sendErrorToDistributionList(e,DavisSpectrumScheduleException.DAVIS);
    }


    @Test
    public void sendErrorToDistributionListExceptionNull() {
        Exception e = mock(Exception.class);
        when(e).thenReturn(null);
        processReadURLError.sendErrorToDistributionList(e,DavisSpectrumScheduleException.DAVIS);
    }

    @Test
    public void sendErrorToDistributionListExceptionAllNull() {
        Exception e = mock(Exception.class);
        when(e.getCause()).thenReturn(null);
        when(e.getMessage()).thenReturn(null);
        processReadURLError.sendErrorToDistributionList(e,DavisSpectrumScheduleException.DAVIS);
    }


    private List<UserSystemPrivileges> getUserPrivilegeList(String email) {
        List<UserSystemPrivileges> lsUser = new ArrayList<UserSystemPrivileges>();
        UserSystemPrivileges userSystemPrivileges = new UserSystemPrivileges(1L, "USER", 1L, 1L);
        userSystemPrivileges.getUser().setEmail(email);
        lsUser.add(userSystemPrivileges);
        return lsUser;

    }


}
