package com.monsanto.wms.web.views;

import com.monsanto.wms.vo.RealReportStrewRecommendationVO;
import com.monsanto.wms.web.view.SowRecommendationDateGduExcelView;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by IntelliJ IDEA.
 * User: MANIET
 * Date: 8/1/13
 * Time: 4:15 PM
 * To change this template use File | Settings | File Templates.
 */
@RunWith(MockitoJUnitRunner.class)
public class SowRecommendationDateGduExcelView_UT {

    @Mock
    HttpServletRequest request;

    @Mock
    HttpServletResponse response;

    SowRecommendationDateGduExcelView view;

     @Before
    public void setUp(){
        view = new SowRecommendationDateGduExcelView();
    }

    @Test
    public void buildExcelDocumentC() throws Exception {
        Map<String,Object> container = new HashMap<String,Object>();
        Map<String, Object> data = new HashMap<String, Object>();
        data.put("dataList",createList());
        data.put("selectedYear",2013);
        data.put("metStation","myMetStation");
        data.put("tempType","C");
        container.put("excelData",data);
        view.buildExcelDocument( container, new HSSFWorkbook(), request, response );
    }

    @Test
    public void buildExcelDocumentF() throws Exception {
        Map<String,Object> container = new HashMap<String,Object>();
        Map<String, Object> data = new HashMap<String, Object>();
        data.put("dataList",createList());
        data.put("selectedYear",2013);
        data.put("metStation","myMetStation");
        data.put("tempType","F");
        container.put("excelData",data);
        view.buildExcelDocument( container, new HSSFWorkbook(), request, response );
    }

    private List<RealReportStrewRecommendationVO> createList(){

        List<RealReportStrewRecommendationVO> ls = new ArrayList<RealReportStrewRecommendationVO>();
        ls.add(createRealReportStrewRecommendationVO("MyStage"));
        ls.add(createRealReportStrewRecommendationVO("null"));
        ls.add(createRealReportStrewRecommendationVO(""));

        return ls;

    }

    private RealReportStrewRecommendationVO createRealReportStrewRecommendationVO(String stage) {
        RealReportStrewRecommendationVO obj = new RealReportStrewRecommendationVO();
        obj.setAcumGdu(1D);
        obj.setCropStageName(stage);
        obj.setDailyGdu(1D);
        obj.setDay(1);
        obj.setMonth(1);
        obj.setTempMaxC(1D);
        obj.setTempMinC(1D);
        return obj;
    }
}
