    var VALIDATION_TYPE_REQUIRED = 0;
    var VALIDATION_TYPE_NUM = 1;
    var VALIDATION_TYPE_ALFA = 2;
    var VALIDATION_TYPE_ALFANUM = 3;
    var VALIDATION_TYPE_DECIMAL = 4;
    var VALIDATION_TYPE_MAX_LENGTH = 5;
    var VALIDATION_TYPE_EMAIL = 6;
    var VALIDATION_TYPE_MINOR_THAN = 7;
    var VALIDATION_TYPE_ALFANUM_SPECIAL_CHARS = 8;
    var VALIDATION_TYPE_MIN_VALUE = 9;

    var validationMessages = new Array();
        validationMessages[VALIDATION_TYPE_REQUIRED] = "Required";
        validationMessages[VALIDATION_TYPE_NUM] = "Numeric";
        validationMessages[VALIDATION_TYPE_ALFA] = "Alphabetic";
        validationMessages[VALIDATION_TYPE_ALFANUM] = "Alphanumeric";
        validationMessages[VALIDATION_TYPE_DECIMAL] = "Numeric/Decimal";
        validationMessages[VALIDATION_TYPE_MAX_LENGTH] = " The max Length is:";
        validationMessages[VALIDATION_TYPE_EMAIL] = "The E mail is invalid:";
        validationMessages[VALIDATION_TYPE_MINOR_THAN] = "Can not be bigger than the value on: ";
        validationMessages[VALIDATION_TYPE_ALFANUM_SPECIAL_CHARS] = "Alphanumeric and special chars";
        validationMessages[VALIDATION_TYPE_MIN_VALUE] = "The min value for this field is:";




    function executeFormValidation(id,validations){

        var allFields = id.split("@");

        var field = document.getElementById(id)	;
        var label = document.getElementById(id+"Label")	;

        for(var i=0;i<validations.length;i++){

            switch(validations[i]){
                case VALIDATION_TYPE_REQUIRED:
                if(field!=null && field.value==="" || (field.type=="select-one" && field.value==-1)){
                    label.innerHTML = validationMessages[VALIDATION_TYPE_REQUIRED];
                    field.className = "fieldError";
                    field.setAttribute('title','This Field can not be empty');
                    return true;
                }

                break;

                case VALIDATION_TYPE_NUM:
                    if(field!=null && field.value!=""){
                        if(!allnumeric(field)){
                            label.innerHTML = validationMessages[VALIDATION_TYPE_NUM];
                            field.className = "fieldError";
                            field.setAttribute('title','This Field is numeric');
                            return true;

                         }
                    }

                break;

                case VALIDATION_TYPE_ALFA:
                    if(field!=null && field.value!=""){
                        if(!allalfas(field)){
                            label.innerHTML = validationMessages[VALIDATION_TYPE_ALFA];
                            field.className = "fieldError";
                            field.setAttribute('title','This Field is alfabetic');
                            return true;

                         }
                    }

                break;

                case VALIDATION_TYPE_ALFANUM:
                    if(field!=null && field.value!=""){
                        if(!allAlfaNumeric(field)){
                            label.innerHTML = validationMessages[VALIDATION_TYPE_ALFANUM];
                            field.className = "fieldError";
                            field.setAttribute('title','This Field is alfaNumeric');
                            return true;

                         }
                    }

                break;

                case VALIDATION_TYPE_DECIMAL:
                    if(field!=null && field.value!=""){
                        if(!numberFloat(field)){
                            label.innerHTML = validationMessages[VALIDATION_TYPE_DECIMAL];
                            field.className = "fieldError";
                            field.setAttribute('title','This Field is numeric');
                            return true;

                         }
                    }

                break;

                case VALIDATION_TYPE_MAX_LENGTH:
                    if(field!=null && field.value!=""){
                        if(field.value.length > field.maxLength ){
                            label.innerHTML = validationMessages[VALIDATION_TYPE_MAX_LENGTH]+field.maxLength;
                            field.className = "fieldError";
                            field.setAttribute('title','Incorrect Length');
                            return true;
                        }
                    }

                break;

                case VALIDATION_TYPE_EMAIL:
                    if(field!=null && field.value!=""){
                        if(!validateEMail(field.value)){
                            label.innerHTML = validationMessages[VALIDATION_TYPE_EMAIL];
                            field.className = "fieldError";
                            field.setAttribute('title','The E mail is invalid');
                            return true;

                         }
                    }

                break;


                case VALIDATION_TYPE_MINOR_THAN:

                    var A = document.getElementById(allFields[0]);
                    var B = document.getElementById(allFields[1]);
                    var message = allFields[2];

                    label = document.getElementById(allFields[0]+"Label");

                    if(A!=null && A.value!="" && B!=null && B.value!=""){
                        if(!validateFiledAMinorFieldB(A.value,B.value)){
                            if(message==null){
                                label.innerHTML = validationMessages[VALIDATION_TYPE_MINOR_THAN]+B.name;
                            }else{
                                label.innerHTML = message;
                            }

                            A.className = "fieldError";
                            A.setAttribute('title','Invalid Number');
                            return true;

                         }else{
                            if(A.type=="select-one" && B.type=="select-one"){
                                if(A.value==-1 || B.value ==-1){
                                    label.innerHTML = "Can not compare " + A.name +" with "+B.name+" using their default value";
                                    A.className = "fieldError";
                                    A.setAttribute('title','Invalid Number');
                                    return true;
                                }
                            }else{
                                label.innerHTML='';
                                A.setAttribute('title','');
                                A.className = "fieldNormal";
                            }
                        }
                    }

                break;

                case VALIDATION_TYPE_ALFANUM_SPECIAL_CHARS:
                    if(field!=null && field.value!=""){
                        if(!allAlNumericSpecialChars(field.value)){
                            label.innerHTML = validationMessages[VALIDATION_TYPE_ALFANUM_SPECIAL_CHARS];
                            field.className = "fieldError";
                            field.setAttribute('title','Invalid Text');
                            return true;

                         }
                    }

                break;

                case VALIDATION_TYPE_MIN_VALUE:

                    var A = document.getElementById(allFields[0]);
                    var B = Number(allFields[1]);

                    label = document.getElementById(allFields[0]+"Label");

                    if(A!=null && A.value!="" && B!=null && B.value!=""){
                        if(!validateMinValue(A.value,B)){
                            label.innerHTML = validationMessages[VALIDATION_TYPE_MIN_VALUE]+B;
                            A.className = "fieldError";
                            A.setAttribute('title','Invalid Number');
                            return true;

                         }
                    }
                break;

            }

        }

        if(label!=null && field!=null && (allFields==null || allFields.length==1)){
            label.innerHTML='';
            field.setAttribute('title','');
            field.className = "fieldNormal";
        }


        return false;
    }

    function validateMinValue(fieldValue,valueMin){
        if(Number(fieldValue)<Number(valueMin)){
            return false;
        }

        return true;
    }

    function validateFiledAMinorFieldB(A,B){

        if(Number(A)>Number(B)){
           return false;
        }

        return true;

    }

      function cleanErrors(allFields){
        var field;
        var label;

        for(var i=0;i<allFields.length;i++){
           field = document.getElementById(allFields[i]);
           label = document.getElementById(allFields[i]+"Label")	;

            try{
                label.innerHTML='';
                field.setAttribute('title','');
                field.className = "fieldNormal";
            }catch(error){}


        }
      }

      function validateForm(currentError,idToValidate,validateRules){
        var result = executeFormValidation(idToValidate,validateRules);
        if(currentError===true){return currentError}

        return result;
      }

      function numberFloat(inputtxt) {
         // var numbers = /^[-{0,1}][0-9]?(\.{0,1}[0-9]{1,2})+$/;
          var numbers = /^-{0,1}(\d*\.)?\d+$/;

          if(inputtxt.value.match(numbers)){
             return true;
          } else {
             return false;
          }
       }

      function allnumeric(inputtxt) {
          var numbers = /^[0-9]+$/;

          if(inputtxt.value.match(numbers)){
             return true;
          } else {
             return false;
          }
       }

        function allAlfaNumeric(inputtxt) {
          var mask = /^[0-9A-Za-z\s-]+$/;

          if(inputtxt.value.match(mask)){
             return true;
          } else {
             return false;
          }
       }
      function allAlNumericSpecialChars(inputtxt) {
          var mask = /^[0-9A-Za-z,\]\[\(\)\/\s-]+$/;

          if(inputtxt.match(mask)){
             return true;
          } else {
             return false;
          }
       }

       function allalfas(inputtxt) {
          var mask = /^[A-Za-z \361\321\s-]+$/;



          if(inputtxt.value.match(mask)){
             return true;
          } else {
             return false;
          }
       }

       function validateEMail(inputtxt){
           var mask = /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.(?: |com|org|net|biz|info|mobi|cat|es|ar)$/i;

          if(inputtxt.match(mask)){
             return true;
          } else {
             return false;
          }
       }

      function cleanSpecificField(id){
          document.getElementById(id+'Label').innerHTML = "";
          document.getElementById(id).className = "fieldNormal";
          document.getElementById(id).setAttribute('title', '');
      }

      function setErrorSpecificField(id,msg){
          document.getElementById(id+'Label').innerHTML = msg;
          document.getElementById(id).className = "fieldError";
          document.getElementById(id).setAttribute('title', msg);
      }


