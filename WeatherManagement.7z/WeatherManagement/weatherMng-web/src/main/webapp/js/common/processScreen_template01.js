
/**
  Author: Marco Antonio Nieto Plett
  Date: 21/05/2013
  Version: 1.0.0
  
  Description:
  
  The objective of this file is to help in the display of the
  processing screen when an action is happening.
  
  The invocation for this alerts will be calling the function
  showProcessScreen:
      - true when you want to show the process screen
	  - false when you want to hide the process screen
  
										 
	Releated Files:
	
	- processBlockScreen_template01.css : Contains all the styes used in this component
	- processScreen_template01.js: Contain all the instructions used in this component.
	
	NOTE:  is recomendable to implement at the end of it showHideProcessScreen(false) 
	       in order to hide the alert after the process is finished.
*/



function showHideProcessScreen(status){
	var blockScreen = document.getElementById("monsantoElement_blockScreen"); 
	var processBox = document.getElementById("monsantoElement_processBox"); 
	
	if(status){
		processBox.style.display = "block";
		blockScreen.style.display = "block";
	}else{
		processBox.style.display = "none";
		blockScreen.style.display = "none";
	}
}



function testCallback(){
	alert("You Just Called the Callback Function");	
}