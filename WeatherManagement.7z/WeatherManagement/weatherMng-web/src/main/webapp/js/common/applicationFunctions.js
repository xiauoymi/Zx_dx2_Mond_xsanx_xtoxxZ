var applicationLib = (function ($, s) {

    var LIB = {
        /**
         * Regular expression that accepts a number with a comma as a group separator (optionally)
         */
        "validatedInteger" :     function (number) {
            number = $.trim(number);
            if (!/(^[-]?\d*(,\d*)*$)|(^\d+$)/.test(number)) {
                return false;
            } else {
                return number.replace(/,/g, '');
            }
        },
        "validatedPositiveInteger" :     function (number) {
            number = $.trim(number);
            if (!/(^\d*(,\d*)*$)|(^\d+$)/.test(number)) {
                return false;
            } else {
                return number.replace(/,/g, '');
            }
        },
        "validatedYear" :     function (number) {
            number = $.trim(number);
            if (!/^\d{4}$/.test(number)) {
                return false;
            } else {
                return number;
            }
        },
        "validatedBigDecimal":     function (number) {
            number = $.trim(number);
            if (!/^[-]?\d*(,\d*)*([.]\d+)?$/.test(number)) {
                return false;
            } else {
                return number.replace(/,/g, '');
            }
        },
        "isNumber" : function(str) {
            return str.toString().indexOf('e') == -1 ? !isNaN(str.toString().replace(/[,.]/g, '')) : false;
        },
        "validatedNumberLength" : function(str, length) {
            return str.toString().replace(/[,.]/g, '').length <= length;
        },
        "parseAnyNumber":function(value) {
            return $.parseNumber(value, {format: '-#,##0', locale:'us'}, true);
        },
        //util forms

        "createSearchParams": function (params) {
            var aoData = [];
            $.each(params, function(entryIndex, entry) {

                if ($(entry.container).is('input:text')) {
                    aoData.push({"name": entry.id, "value": $(entry.container).val()});
                }
                else if ($(entry.container).is('input:hidden')) {
                    aoData.push({"name": entry.id, "value": $(entry.container).val()});
                }
                else if ($('input[name=' + entry.property + ']').is('input:checkbox')) {
                    aoData.push({"name": entry.id, "value": $('input[name=' + entry.property + ']').is(':checked')});
                }
                else if ($(entry.container).is('select')) {
                    aoData.push({"name": entry.id, "value": $(entry.container).val()});
                }

            });
            return aoData;
        },"initComboByUrl": function(options) {
            var source = $(options.sourceScript).html();
            var template = Handlebars.compile(source);
            var templateParams = {comboBoxId:options.comboBoxId, comboBoxName:options.comboBoxName};
            $.ajax({"url": options.url,
                "data": options.params,
                "async": options.async,
                "dataType":'json',
                success:function(result, status, xhr) {
                    $.each(result, function(entryIndex, entry) {
                        entry["id"] = entry[options.mappings["id"]];
                        entry["description"] = entry[options.mappings["description"]];
                        entry["selectedItem"] = options.mappings["selectedItem"];
                    });
                    templateParams["options"] = result;
                    $(options.container).html(template(templateParams));
                    if (options.callback) {
                        options.callback.call();
                    }
                },
                error:function(xhr, status, error) {
                    showAlert([error], MONSANTO_STATIC_VARIABLE_ERROR);
                }
            });
        },

        "clearForm":function (params) {
            $.each(params, function(entryIndex, entry) {
                if ($(entry.container).is('input:text')) {
                    $(entry.container).val('');//add variable
                }
                else if ($(entry.container).is('input:hidden')) {
                    $(entry.container).val('');
                }
                else if ($(entry.container).is('input:checkbox')) {
                    $(entry.container).prop("checked", false);
                }
                else if ($(entry.container).is('select')) {
                    $(entry.container).val('-1').change();
                }

            });
        },
        "hideShowElement":function(div, show) {
            if (!show) {
                $('#' + div).hide();
            } else {
                $('#' + div).show();
            }


        },
        "formatNumber":function(number) {
            return $.formatNumber(new Number(number).toString(), {format: '-#,##0', locale:'us'}, true);
        },

        "formatDecimal":function(number) {
            return $.formatNumber(new Number(number).toString(), {format: '-#,##0.00', locale:'us'}, true);
        },

        "parseFloat":function(value) {
            if (value != null && typeof value != undefined && $.trim(value).length > 0) {
                value = parseFloat(value);
                if (!isNaN(value)) {
                    return value;
                }
            }
            return 0;
        },
        "parseNumber":function(value) {
            return isNaN(value) ? $.parseNumber(value, {format: '-#,##0', locale:'us'}, true) : value.toString();
        }
        //
    };
    return LIB;

})(jQuery, application);

function hideAllAlertsAndProcessScreen() {
    hideShowAlertBox(false);
    showHideProcessScreen(false);
}

function addComboItem(comboId, text, value) {
    var opt = document.createElement("option");
    document.getElementById(comboId).options.add(opt);
    opt.text = text;
    opt.value = value;
}

function cleanCombo(comboId) {
    var sel = document.getElementById(comboId);
    for (i = (sel.length - 1); i >= 0; i--) {
        aBorrar = sel.options[i];
        aBorrar.parentNode.removeChild(aBorrar);
    }
}

var MONTH_VALUE_JANUARY = 1;
var MONTH_VALUE_FEBRUARY = 2;
var MONTH_VALUE_MARCH = 3;
var MONTH_VALUE_APRIL = 4;
var MONTH_VALUE_MAY = 5;
var MONTH_VALUE_JUNE = 6;
var MONTH_VALUE_JULY = 7;
var MONTH_VALUE_AUGUST = 8;
var MONTH_VALUE_SEPTEMBER = 9;
var MONTH_VALUE_OCTOBER = 10;
var MONTH_VALUE_NOVEMBER = 11;
var MONTH_VALUE_DECEMBER = 12;


var MONTHS = new Array();
MONTHS[0] = "January";
MONTHS[1] = "February";
MONTHS[2] = "March";
MONTHS[3] = "April";
MONTHS[4] = "May";
MONTHS[5] = "June";
MONTHS[6] = "July";
MONTHS[7] = "August";
MONTHS[8] = "September";
MONTHS[9] = "October";
MONTHS[10] = "November";
MONTHS[11] = "December";

var MONTH_JANUARY_DAYS = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31];
//var MONTH_FEBRUARY_DAYS = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28];
var MONTH_MARCH_DAYS = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31];
var MONTH_APRIL_DAYS = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30];
var MONTH_MAY_DAYS = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31];
var MONTH_JUNE_DAYS = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30];
var MONTH_JULY_DAYS = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31];
var MONTH_AUGUST_DAYS = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31];
var MONTH_SEPTEMBER_DAYS = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30];
var MONTH_OCTOBER_DAYS = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31];
var MONTH_NOVEMBER_DAYS = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30];
var MONTH_DECEMBER_DAYS = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31];

function getMonthDescription(monthValue) {
    monthValue = monthValue - 1;
    return MONTHS[monthValue];

}

function fahrenheitToCelsius(F) {
    var C = (((F - 32) * 5) / 9);
    return Math.round(C * 100) / 100;
}

function celsiusToFahrenheit(C) {
    var F = (((C * 9) / 5) + 32);
    return Math.round(F * 100) / 100;
}

function replaceAllElements(str, tokenToFind, replacement) {

    var re = new RegExp(tokenToFind, 'g');

    str = str.replace(re, replacement);

    return str;
}

function loadDaysOfTheMonth(month, id,leapYear) {

    cleanCombo(id);

    switch (Number(month)) {
        case MONTH_VALUE_JANUARY:
            fillDaysOfTheMonth(MONTH_JANUARY_DAYS, id);
            break;
        case MONTH_VALUE_FEBRUARY:
            var temp = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28];
            if(leapYear){
                temp.push(29);
            }
            fillDaysOfTheMonth(temp, id);
            break;
        case MONTH_VALUE_MARCH:
            fillDaysOfTheMonth(MONTH_MARCH_DAYS, id);
            break;
        case MONTH_VALUE_APRIL:
            fillDaysOfTheMonth(MONTH_APRIL_DAYS, id);
            break;
        case MONTH_VALUE_MAY:
            fillDaysOfTheMonth(MONTH_MAY_DAYS, id);
            break;
        case MONTH_VALUE_JUNE:
            fillDaysOfTheMonth(MONTH_JUNE_DAYS, id);
            break;
        case MONTH_VALUE_JULY:
            fillDaysOfTheMonth(MONTH_JULY_DAYS, id);
            break;
        case MONTH_VALUE_AUGUST:
            fillDaysOfTheMonth(MONTH_AUGUST_DAYS, id);
            break;
        case MONTH_VALUE_SEPTEMBER:
            fillDaysOfTheMonth(MONTH_SEPTEMBER_DAYS, id);
            break;
        case MONTH_VALUE_OCTOBER:
            fillDaysOfTheMonth(MONTH_OCTOBER_DAYS, id);
            break;
        case MONTH_VALUE_NOVEMBER:
            fillDaysOfTheMonth(MONTH_NOVEMBER_DAYS, id);
            break;
        case MONTH_VALUE_DECEMBER:
            fillDaysOfTheMonth(MONTH_DECEMBER_DAYS, id);
            break;
        default:
            addComboItem(id, "-- Select an Option --", -1);

    }

}

function fillDaysOfTheMonth(days, id) {

    addComboItem(id, "-- Select an Option --", -1);

    for (var i = 0; i < days.length; i++) {
        addComboItem(id, days[i], days[i]);
    }

}

function isLeapYear(yearA, yearB) {

    for (var i = yearA; i <= yearB; i++) {
        if ((i % 4 == 0) && ((i % 100 != 0) || (i % 400 == 0))){
            return true;
        }
    }

    return false;

}