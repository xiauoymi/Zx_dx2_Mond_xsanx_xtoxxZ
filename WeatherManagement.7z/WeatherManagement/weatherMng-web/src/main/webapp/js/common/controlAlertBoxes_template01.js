
/**
  Author: Marco Antonio Nieto Plett
  Date: 20/05/2013
  Version: 1.0.0
  
  Description:
  
  The objective of this file is to help in the display of the
  following alerts: Notification, Warning, Error and Succeeded 
  operation.
  
  The invocation for this alerts will be calling the function
  showAlert with the following parameters:
     - message: Most be an array of strings ['A','B',...]
	 - type: Most be one of the following variables:
	    MONSANTO_STATIC_VARIABLE_SUCCESS
		MONSANTO_STATIC_VARIABLE_ERROR
		MONSANTO_STATIC_VARIABLE_WARNING
		MONSANTO_STATIC_VARIABLE_NOTIFICATION
	- callback : this paramenter is used by warning and notification alert types
	             because they need a user action, in order to make it
				 function you need to pass customized function in the 3rd
				 argument and is recomendable to implement at the end
				 of it hideShowAlertBox(false) in order to hide the alert after
				 clicking confirm. NOTE: With the other alerts do not include this
				                         parameter.
										 
	Releated Files:
	
	- akertCSS.css : Contains all the styes used in this component
	- controlAlertBoxes__template01.js: Contain all the instructions used in this component.
	     
*/

var MONSANTO_STATIC_VARIABLE_SUCCESS = 1;
var MONSANTO_STATIC_VARIABLE_ERROR = 2;
var MONSANTO_STATIC_VARIABLE_WARNING = 3;
var MONSANTO_STATIC_VARIABLE_NOTIFICATION = 4;

var MONSANTO_STATIC_BTNS_CONFIRM = 1;
var MONSANTO_STATIC_BTNS_WARNING = 2;
var MONSANTO_STATIC_BTNS_NOTIFICATION = 3;

var MONSANTO_STATIC_OPERATION_COMPLETED = "Operation Completed";
var MONSANTO_STATIC_OPERATION_ERROR = "Operation Failed";
var MONSANTO_STATIC_OPERATION_WARNING = "User Confirmation Required";
var MONSANTO_STATIC_OPERATION_NOTIFICATION = "Notification";

function showAlert(message,type,callback){
	
	var alertType = document.getElementById("alert_type");
	var alertMessage = document.getElementById("alert_message");
	var alertFooter = document.getElementById("alert_footer");
	var alertActionBtn = document.getElementById("alert_action_btn");
	
	switch(type){
		case MONSANTO_STATIC_VARIABLE_SUCCESS:
		
			alertType.className = "alert_header_success";
			alertFooter.className = "alertSucceededFooter";
			alertType.innerHTML = MONSANTO_STATIC_OPERATION_COMPLETED;
			alertMessage.innerHTML = getHTMLMessage(message);
			alertActionBtn.innerHTML = getActionBtns(MONSANTO_STATIC_BTNS_CONFIRM);


            if(setOnClickCallBack(document.getElementById("okButton"),callback)){
				hideShowAlertBox(true);
			}else{
				hideShowAlertBox(false);
			}

			break;
		case MONSANTO_STATIC_VARIABLE_ERROR:
			alertType.className = "alert_header_error";
			alertFooter.className = "alertErrorFooter";
			alertType.innerHTML = MONSANTO_STATIC_OPERATION_ERROR;
			alertMessage.innerHTML = getHTMLMessage(message);
			alertActionBtn.innerHTML = getActionBtns(MONSANTO_STATIC_BTNS_CONFIRM);
			
			hideShowAlertBox(true);
			break;
		case MONSANTO_STATIC_VARIABLE_WARNING:
			alertType.className = "alert_header_warning";
			alertFooter.className = "alertWarningFooter";
			alertType.innerHTML = MONSANTO_STATIC_OPERATION_WARNING;
			alertMessage.innerHTML = getHTMLMessage(message);
			alertActionBtn.innerHTML = getActionBtns(MONSANTO_STATIC_BTNS_WARNING);
			
			if(setOnClickCallBack(document.getElementById("confirmAlert"),callback)){
				hideShowAlertBox(true);
			}else{
				hideShowAlertBox(false);
			}
			
			break;
			
		case MONSANTO_STATIC_VARIABLE_NOTIFICATION:
			alertType.className = "alert_header_notification";
			alertFooter.className = "alertNotificationFooter";
			alertType.innerHTML = MONSANTO_STATIC_OPERATION_NOTIFICATION;
			alertMessage.innerHTML = getHTMLMessage(message);
			alertActionBtn.innerHTML = getActionBtns(MONSANTO_STATIC_BTNS_WARNING);

			setOnClickCallBackOptional(document.getElementById("confirmAlert"),callback);
			hideShowAlertBox(true);

			break;	
			
			
	}
	
}

function setOnClickCallBack(btn,callback){
	if(callback!=null){
		btn.onclick = callback;
		return true;
	}else{
		alert("This type of alert requieres a callback function");
		return false;
	}
	
}

function setOnClickCallBackOptional(btn,callback){
	if(callback!=null){
		btn.onclick = callback;
		return true;
	}
}

function getActionBtns(option){
	
	var btnHTML="";
	
	switch(option){
		
		case MONSANTO_STATIC_BTNS_CONFIRM:
			btnHTML = "<input type='button' id='okButton' value='Ok' class='' onclick='hideShowAlertBox(false)'/>";
			break;
			
		case MONSANTO_STATIC_BTNS_WARNING:
		
			btnHTML = "<input type='button' id='confirmAlert' value='Confirm' class=''/>";
			btnHTML += "<input type='button' value='Cancel' class='' onclick='hideShowAlertBox(false)'/>";
			break;
			
		case MONSANTO_STATIC_BTNS_NOTIFICATION:
		
			btnHTML = "<input type='button' id='confirmAlert' value='Confirm' class=''/>";
			btnHTML += "<input type='button' value='Cancel' class='' onclick='hideShowAlertBox(false)'/>";
			break;
			
		
	}	
	
	return btnHTML;
}

function hideShowAlertBox(status){
	var blockScreen = document.getElementById("monsantoElement_blockScreen"); 
	var alertBox = document.getElementById("monsantoElement_alertBox"); 
	
	if(status){
		alertBox.style.display = "block";
		blockScreen.style.display = "block";
	}else{
		alertBox.style.display = "none";
		blockScreen.style.display = "none";
	}
	
	
		
}

function getHTMLMessage(message){
	
	var HTMLMessage = "<ul>";
	
	
	for(var i=0; i< message.length;i++){
		HTMLMessage +=  "<li>" + message[i] + "</li>";
	}
	
	HTMLMessage+="</ul>";
	
	return HTMLMessage;
	
}

function testCallback(){
	alert("You Just Called the Callback Function");	
}