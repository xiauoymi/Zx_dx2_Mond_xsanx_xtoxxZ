(function ($,s) {

    var MAIN_DATA_TABLE = "dataTable_manualLoad";
    var CLEAN_FLAG = false;
      var searchParameters=[
        { id: 'metStationId', container: '#metStationId', property: 'metStationId', searchValue: '' },
        { id: 'day', container: '#day', property: 'day', searchValue: '' },
        { id: 'month', container: '#month', property: 'month', searchValue: '' },
        { id: 'year', container: '#year', property: 'year', searchValue: '' }
      ];

    function loadPage(){

      initData();
      initDataTable();

       initBtnSearch();

      initBtnClean();
      initBtnImportData();
      initBtnExport();
      initComboStationOwner();
      initCombosYears();
      initCombosMonths();
      initChangeMonth();

      loadComboMeteorologicalStation("-1");

    }

     function resetMonthsAndDays() {
        $("#day").val("-1");
        $("#month").val("-1");

        cleanCombo("day");
        addComboItem("day","-- Select an Option --",-1);


    }

    function initCombosYears(){
        cleanCombo('year');
        addComboItem("year","-- Select an Option --",-1);

        for(var i=2006;i<=new Date().getFullYear();i++){
            addComboItem("year",i,i);
        }

        $(document).on("change", '#year', function() {
            resetMonthsAndDays();
        });

    }

    function initCombosMonths(){
        cleanCombo('month');
        addComboItem("month","-- Select an Option --",-1);
        for(var i=0;i<MONTHS.length;i++){
            addComboItem("month",MONTHS[i],(i+1));
        }
    }

    function initChangeMonth(){
          $(document).on("change",'#month', function() {
              var leapYear = isLeapYear($("#year").val(),$("#year").val());
              loadDaysOfTheMonth($('#month').val(),'day',leapYear);
          });

    }


    function initComboStationOwner(){
         var options = {
             'url':s.baseUrl + '/catalog/meteoroStationOwnerBase/loadCollection.do' , 'params':{},
             'sourceScript':'#comboBoxTemplate', 'container':'#containerMeteorologicalStationOwner',
             'comboBoxId':'metStationOwnerId', 'comboBoxName':'metStationOwnerId',
             'mappings':{'id':'id','description':'description','selectedItem':'-1'}, 'async':false
         }

         $(document).on("change",'#metStationOwnerId', function() {
            loadComboMeteorologicalStation($('#metStationOwnerId').val());
        });

         applicationLib.initComboByUrl(options);
    }

    function loadComboMeteorologicalStation(selectedItem){
        var ownerId = ($('#metStationOwnerId').val()!=null && $('#metStationOwnerId').val()!=undefined )? $('#metStationOwnerId').val() : "-1";
         var options = {
             'url':s.baseUrl + '/catalog/meteoroStationBase/loadCollectionByOwner.do' , 'params':{'ownerId':ownerId},
             'sourceScript':'#comboBoxTemplate', 'container':'#containerMeteorologicalStation',
             'comboBoxId':'metStationId', 'comboBoxName':'metStationId',
             'mappings':{'id':'id','description':'description','selectedItem':selectedItem}, 'async':false
         }
         applicationLib.initComboByUrl(options);
    }

    function initData(){
      $('#deleteBtn').attr('disabled',true);

    }

    function initBtnClean(){

         $(document).on("click",'#cleanBtn', function() {
             CLEAN_FLAG = true;
             cleanFrom();
         });
    }


    function initBtnExport(){

         $(document).on("click",'#exportBtn', function() {

             if (!validateGeneralFields()) {
                 showAlert(['You are about to export these data to excel, do you want to proceed?'],MONSANTO_STATIC_VARIABLE_NOTIFICATION,callBackExportXLS)

             }

         });
    }

    function callBackExportXLS() {

        hideShowAlertBox(false);

        var filters = "metStationId=" + $('#metStationId').val() + "&";
        filters = filters + "day=" + $('#day').val() + "&";
        filters = filters + "month=" + $('#month').val() + "&";
        filters = filters + "tempType=" + $('#temperatureIn').val() + "&";
        filters = filters + "year=" + $('#year').val();

        window.location = s.baseUrl + "/production/metStationManualLoadBase/export.do?"+filters;

    }

    function initBtnSearch(){

         $(document).on("click",'#searchBtn', function() {
             cleanErrors(FIELDS_TO_CLEAN);
             if(!validateGeneralFields()){
                 drawTable();
             }
         });
    }

    function validateGeneralFields(){
         var errFound = false;
                errFound = validateForm(errFound, 'metStationId', VALIDATE_COMBO_MET_STATIONS);
                errFound = validateForm(errFound, 'metStationOwnerId', VALIDATE_COMBO_MET_STATIONS_OWNER);
                errFound = validateForm(errFound, 'year', VALIDATE_COMBO_YEAR);

        return  errFound;

    }

    function validateFieldsForImport(){
          var errFound = false;
                errFound = validateGeneralFields();
                errFound = validateForm(errFound, 'day', VALIDATE_COMBO_DAY);
                errFound = validateForm(errFound, 'month', VALIDATE_COMBO_MONTH);
        return errFound;

    }

    function initBtnImportData(){

         $(document).on("click",'#importBtn', function() {
             var errFound = validateFieldsForImport();
                errFound =  validateForm(errFound, 'file0', VALIDATE_FILE_0);
               var ext = $('#file0').val().substring($('#file0').val().length,$('#file0').val().length-3);

                 if(!errFound && ext.toUpperCase()!="XLS"){
                     setErrorSpecificField("file0","The file must have the extension xls");
                     errFound = true;
                 }
             if(!errFound){
                showAlert(['All the data from the selected day/month/year will be replaced, do you want to proceed?'],MONSANTO_STATIC_VARIABLE_WARNING,importCallback)
             }
         });
    }

    function drawTable(){

        $('#'+MAIN_DATA_TABLE).dataTable().fnDraw();

    }

    function importCallback(){
         hideShowAlertBox(false);
         showHideProcessScreen(true);

        $('#dataForm').submit();

    }



    function initDataTable(){

       var tableInfo= $('#'+MAIN_DATA_TABLE).dataTable( {
             "bJQueryUI": true,
            "bProcessing": true,
            "bServerSide": true,
            "bLengthChange": 10,
            "sAjaxSource" : s.baseUrl+"/production/metStationManualLoadBase/search.do",
            "sScrollX": "100%",
            "aaSorting": [[ 0, "asc" ]],
            "sPaginationType": "full_numbers",
            "aoColumns": [
                  { "mDataProp": "id","sWidth": "10%"},
                  { "mDataProp": "meteorologicalStation.description","sWidth": "40%"},
                  { "mDataProp":  function ( source, type, val ) {
                   if($("#temperatureIn").val()=="F"){
                        return celsiusToFahrenheit(source.tempMax);
                   }else{
                        return source.tempMax;
                   }
                },"bSortable": false,"sWidth": "15%" },
                 { "mDataProp":  function ( source, type, val ) {
                   if($("#temperatureIn").val()=="F"){
                        return celsiusToFahrenheit(source.tempMin);
                   }else{
                        return source.tempMin;
                   }
                },"bSortable": false,"sWidth": "15%" },
                  { "mDataProp": "timeRegistry","sWidth": "20%"}
            ],
            "bPaginate": true,
            "bFilter": true,
            "sPaginationType": "full_numbers",

            "fnServerData": function ( sSource, aoData, fnCallback ) {
                $.merge(aoData,applicationLib.createSearchParams(searchParameters));
                hideAllAlertsAndProcessScreen();
                showHideProcessScreen(true);
                $.ajax( {"url":sSource,
                         "dataType":'json',
                         "data":aoData,
                    "success":function (response) {
                        if(!response.success&&response.success===false){
                            var json={};
                            json.aaData= {};
                            json.iTotalDisplayRecords=0;
                            json.iTotalRecords=response.totalElements;
                            fnCallback(json);
                            hideAllAlertsAndProcessScreen();

                            showAlert(response.messages,MONSANTO_STATIC_VARIABLE_ERROR);
                        }else{
                            hideAllAlertsAndProcessScreen();

                            var json={};
                            json.aaData= response.content;
                            json.iTotalDisplayRecords=response.totalElements;
                            json.iTotalRecords=response.totalElements;
                            fnCallback(json);

                            if(!CLEAN_FLAG){
                                showOperationResult();
                            }

                             CLEAN_FLAG = false;
                        }

                    },
                    "error":function(xhr, status, error) {
                        hideAllAlertsAndProcessScreen();
                        showAlert(["Application Error, Try Again:"+error],MONSANTO_STATIC_VARIABLE_ERROR);
                    }
                });
            }
        });

    }

    function showOperationResult() {
        if (QueryString.success == "true") {
            showAlert([QueryString.msg], MONSANTO_STATIC_VARIABLE_SUCCESS, hideAllAlertsAndProcessScreen);
        } else if (QueryString.success == "false") {
            var msg = QueryString.msg;
            msg = msg.substring(1, msg.length - 1);

            var msgArray = msg.split(",");

            showAlert(msgArray, MONSANTO_STATIC_VARIABLE_ERROR);
        }
    }

    function cleanFrom(){
        $('#metStationOwnerId').val('-1');
        $('#month').val('-1');
        $('#year').val('-1');

        cleanCombo('metStationId')
        addComboItem("metStationId", "-- Select an Option --","-1");

        cleanCombo('day');
        addComboItem("day", "-- Select an Option --","-1");

        $('#metStationOwnerId').val('-1');
        $('#hybridId').val('-1');

        var file = $('#file0');
        file.replaceWith( file = file.clone( true ) );

        drawTable();

        cleanErrors(FIELDS_TO_CLEAN);

     }



     $(document).ready(function() {
         loadPage();
     });
})(jQuery,application);