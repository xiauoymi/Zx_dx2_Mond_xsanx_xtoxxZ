/**
 * Created with IntelliJ IDEA.
 * User: GFRAN1
 * Date: 7/22/14
 * Time: 10:33 AM
 * To change this template use File | Settings | File Templates.
 */
(function ($,s) {

    var MAIN_DATA_TABLE = "dataTable_errorLog";

    var searchParameters=[
        { id: 'batchId', container: '#batchId', property: 'batchId', searchValue: '' }
    ];
    function loadPage(){
        loadComboMeteorologicalStation();
        initProcessBtn();
        pickDate();
        initParameters();


    }

    function loadComboMeteorologicalStation(){

        var options = {
            'url':s.baseUrl + '/catalog/meteoroStationBase/loadCollectionByType.do' ,  'params':{},
            'sourceScript':'#comboBoxTemplate', 'container':'#containerMeteorologicalStation',
            'comboBoxId':'meteorologicalStationId', 'comboBoxName':'meteorologicalStationId',
            'mappings':{'id':'id','description':'description','selectedItem':'-1'}, 'async':false
        }
        applicationLib.initComboByUrl(options);
    }

    function initParameters(){
        $('#dataTable_errorLog').hide();
        if( $('#startDate').val() == ''){
            $('#processBtn').attr('disabled',true);
        }
    }

    function initProcessBtn(){
        $(document).on("click",'#processBtn', function() {
            var errFound = false;
            errFound = validateForm(errFound,'meteorologicalStationId',VALIDATE_REQUIRED);
            if(!errFound){
            getHistoricData();}
        });
    }

    function getHistoricData(){

        $.ajax( {"url": s.baseUrl+"/catalog/metStationReloadData/validateHistoricData.do",
            type: 'POST',
            data: $('#dataForm').serialize(),

            "success":function(response,data) {

                    if(response.messages!='') {
                        hideShowAlertBox(false);
                        showAlert(response.messages,MONSANTO_STATIC_VARIABLE_WARNING,callbackProcess);
                    }
                    else {
                        showHideProcessScreen(true);
                        callbackProcess();
                    }

            },
            "error":function(xhr, status, error) {

                showAlert([error],MONSANTO_STATIC_VARIABLE_ERROR);
            }
        }) ;

    }

    function cleanForm(){
        hideShowAlertBox(false);
        $("#startDate").val('');
        $("#meteorologicalStationId").val('');
    }

       function callbackProcess(){
           showHideProcessScreen(true);

           $.ajax( {"url": s.baseUrl+"/catalog/metStationReloadData/fillData.do",
               type: 'POST',
               data: $('#dataForm').serialize(),
               "success":function(response,data) {

               if(!response.success&&response.success===false){
                   showHideProcessScreen(false);
                       $("#batchId").val(response.messages);
                       showAlert(["Some records has errors,Look table below"],MONSANTO_STATIC_VARIABLE_ERROR);
                       showErrorTable();

                   }
                   else{
                   showHideProcessScreen(false);
                   if(response.messages !='0') {
                       showAlert(["Application Error"],MONSANTO_STATIC_VARIABLE_ERROR);
                   }else{
                       showAlert(["Data Merged Success"],MONSANTO_STATIC_VARIABLE_SUCCESS,cleanForm);
                   }
                 }
               },
               "error":function(xhr, status, error) {

                   showAlert([error],MONSANTO_STATIC_VARIABLE_ERROR);
               }
           }) ;
           cleanData();
       }

    function pickDate(){
        $("#startDate").datepicker({
            firstDay: 1,
            onClose: function() {
                if( $('#startDate').val() != ''){
                    $('#processBtn').attr('disabled',false);
                }
            }
        });
    }

    function initDataTable(){
        var tableInfo= $('#'+MAIN_DATA_TABLE).dataTable( {
            "bJQueryUI": true,
            "bProcessing": true,
            "bServerSide": true,
            "bLengthChange": 10,
            "sAjaxSource" : s.baseUrl+"/catalog/metStationReloadData/getDataLoaderLog.do",
            "sScrollX": "100%",
            "bPaginate": true,
            "bFilter": true,
            "aaSorting": [[ 1, "asc" ]],
            "sPaginationType": "full_numbers",
            "aoColumns": [
                { "mDataProp": "status","sWidth": "15%"},
                { "mDataProp": "dateTime","sWidth": "15%"},
                { "mDataProp": "recordCount","sWidth": "15%"},
                { "mDataProp": "insertedCount","sWidth": "15%"},
                { "mDataProp": "updatedCount","sWidth": "15%"},
                { "mDataProp": "errorCount","sWidth": "15%"},
                { "mDataProp": "errorMessage","sWidth": "10%"}
            ],

            "fnServerData": function ( sSource, aoData, fnCallback ) {
                $.merge(aoData,applicationLib.createSearchParams(searchParameters));
                hideAllAlertsAndProcessScreen();
                showHideProcessScreen(true);
                $.ajax( {"url":sSource,
                    "dataType":'json',
                    "data":aoData,
                    "success":function (response) {
                        if(!response.success&&response.success===false){
                            var json={};
                            json.aaData= {};
                            json.iTotalDisplayRecords=0;
                            json.iTotalRecords=response.totalElements;
                            fnCallback(json);
                            hideAllAlertsAndProcessScreen();
                            showAlert(response.messages,MONSANTO_STATIC_VARIABLE_ERROR);
                        }else{
                            hideAllAlertsAndProcessScreen();
                            var json={};
                            json.aaData= response.content;
                            json.iTotalDisplayRecords=response.totalElements;
                            json.iTotalRecords=response.totalElements;
                            fnCallback(json);
                        }

                    },
                    "error":function(xhr, status, error) {
                        hideAllAlertsAndProcessScreen();
                        showAlert(["Application Error, Try Again"],MONSANTO_STATIC_VARIABLE_ERROR);
                    }

                })
            }
    });
    }

    function showErrorTable() {
        $('#dataTable_errorLog').show();
        initDataTable();
        $('#'+MAIN_DATA_TABLE).dataTable().fnDraw();
    }


    function cleanData(){
        $("#meteorologicalStationId").val(-1);
        $("#startDate").val('');
    }

    $(document).ready(function() {
        loadPage();
    });
})(jQuery,application);
