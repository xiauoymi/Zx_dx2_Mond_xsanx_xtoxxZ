$(document).ready(function() {

    try {
        $("#processScreen_actionMsg").html('Login Validation...');
        $("#processScreen_descMsg").html('Locating User');

        showHideProcessScreen(true);

        var WinNetwork = new ActiveXObject("WScript.Network");
        $("#processScreen_descMsg").html('User Located: ' + WinNetwork.UserName);
        $('#j_username').val(WinNetwork.UserName);

        $('#submitBtn').click();
    } catch(error) {
        showHideProcessScreen(false);
        if (QueryString.error != "true" && QueryString.reDir != "true") {
            showAlert(["Automatic login failed:The user can not be identified -> try manual login"], MONSANTO_STATIC_VARIABLE_ERROR);
        }

        var loginDIV = document.getElementById("myLoginDiv");
        loginDIV.style.display = "block";
        $(document).on("click", '#loginBtn', function() {
            $("#processScreen_actionMsg").html('Login Validation...');
            $("#processScreen_descMsg").html('Verifying User Credentials');
            showHideProcessScreen(true);
            $('#j_username').val($('#user').val() + "-$#$@$-" + $('#pwd').val());
            $('#submitBtn').click();
        });
    }


});

