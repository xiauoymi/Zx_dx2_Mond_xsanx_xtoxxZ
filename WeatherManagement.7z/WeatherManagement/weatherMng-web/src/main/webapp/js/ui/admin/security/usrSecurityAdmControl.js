(function ($,s) {

    var MAIN_DATA_TABLE = "dataTable_adminRoles";

      var searchParameters=[
        { id: 'userId', container: '#userId', property: 'userId', searchValue: '' },
        { id: 'activeStatus', container: '#activeStatus', property: 'activeStatus', searchValue: '' },
        { id: 'areaId', container: '#areaId', property: 'areaId', searchValue: '' },
        { id: 'roleId', container: '#roleId', property: 'roleId', searchValue: '' },
        { id: 'userPrivilegesId', container: '#userPrivilegesId', property: 'userPrivilegesId', searchValue: '' }

      ];

    function loadPage(){
      initData();
      initDataTable();
      initBtnSaveOrUpdate();
      initBtnSearch();
      initBtnDelete();
      initBtnClean();
      initComboAreas();
      loadComboRoles("-1");
      initUserNameSearch();

    }

    function initComboAreas(){
         var options = {
             'url':s.baseUrl + '/security/userSecurityAdm/loadCollectionAreas.do' , 'params':{},
             'sourceScript':'#comboBoxTemplate', 'container':'#containerArea',
             'comboBoxId':'areaId', 'comboBoxName':'areaId',
             'mappings':{'id':'id','description':'description','selectedItem':'-1'}, 'async':false
         }
         applicationLib.initComboByUrl(options);

          $(document).on("change",'#areaId', function() {
            loadComboRoles("-1");
        });

    }

    function loadComboRoles(selectedItem){
        var areaId = ($('#areaId').val()!=null && $('#areaId').val()!=undefined )? $('#areaId').val() : "-1";
         var options = {
             'url':s.baseUrl + '/security/userSecurityAdm/loadCollectionRoles.do' , 'params':{'areaId':areaId},
             'sourceScript':'#comboBoxTemplate', 'container':'#containerRole',
             'comboBoxId':'roleId', 'comboBoxName':'roleId',
             'mappings':{'id':'id','description':'role','selectedItem':selectedItem}, 'async':false
         }
         applicationLib.initComboByUrl(options);
    }

    function initData(){
      $('input[name=activeStatus]').attr('checked',true);
      $('#deleteBtn').attr('disabled',true);
    }

     function initBtnClean(){

         $(document).on("click",'#cleanBtn', function() {
             cleanFrom();
         });
    }

    function initBtnSaveOrUpdate(){

         $(document).on("click",'#saveBtn', function() {
             var errFound = false;
                 errFound = validateForm(errFound,'userId',VALIDATE_USER_ID);
                 errFound = validateForm(errFound,'areaId',VALIDATE_AREA_ID_COMBO);
                 errFound = validateForm(errFound,'roleId',VALIDATE_ROLE_ID_COMBO);

             if(!errFound){
                showAlert(['The Registry is about to be saved, do you want to proceed?'],MONSANTO_STATIC_VARIABLE_NOTIFICATION,saveCallback)
             }
         });
    }

    function initBtnSearch(){

         $(document).on("click",'#searchBtn', function() {
             cleanErrors(FIELDS_TO_CLEAN);
             drawTable();
         });
    }

    function initBtnDelete(){

         $(document).on("click",'#deleteBtn', function() {
             showAlert(['The Registry is about to be deleted, do you want to proceed?'],MONSANTO_STATIC_VARIABLE_WARNING,deleteCallback)
         });

    }



     function drawTable(){
        $('#userPrivilegesId').val('');
        $('#saveBtn').val('Save');
        $('#deleteBtn').attr('disabled',true);

        $('#'+MAIN_DATA_TABLE).dataTable().fnDraw();


    }


    function saveCallback(){
         hideShowAlertBox(false);
         showHideProcessScreen(true);
         var optionsForm = {
                  dataType:  'json',
                  "success":function(response, statusText, xhr) {
                    if (response.success) {
                        showHideProcessScreen(false);
                        showAlert(response.messages,MONSANTO_STATIC_VARIABLE_SUCCESS,drawTable);

                    }else{
                        hideAllAlertsAndProcessScreen();
                        showAlert(response.messages,MONSANTO_STATIC_VARIABLE_ERROR);

                    }
                  },
                  "error":function(xhr, status, error) {
                      hideAllAlertsAndProcessScreen();
                      showAlert([error],MONSANTO_STATIC_VARIABLE_ERROR);
                  }
              };

              $('#dataForm').ajaxForm(optionsForm);
              $('#dataForm').submit();

    }

    function deleteCallback(){
         hideShowAlertBox(false);
         showHideProcessScreen(true);

         $.ajax( {"url": s.baseUrl+"/security/userSecurityAdm/delete.do",
            "dataType":'json',
            "data":{ id:$('#userPrivilegesId').val()},
            "success":function(response,status ,xhr) {
                 if(!response.success&&response.success===false){
                      hideAllAlertsAndProcessScreen();
                      showAlert(response.messages,MONSANTO_STATIC_VARIABLE_ERROR);
                 }else{
                    cleanFrom();
                    showHideProcessScreen(false);
                    showAlert(response.messages,MONSANTO_STATIC_VARIABLE_SUCCESS,drawTable);
                 }
            },
            "error":function(xhr, status, error) {
                hideAllAlertsAndProcessScreen();
                showAlert([error],MONSANTO_STATIC_VARIABLE_ERROR);
            }
        });

    }

    function initDataTable(){

       var tableInfo= $('#'+MAIN_DATA_TABLE).dataTable( {
             "bJQueryUI": true,
            "bProcessing": true,
            "bServerSide": true,
            "bLengthChange": 10,
            "sAjaxSource" : s.baseUrl+"/security/userSecurityAdm/search.do",
            "sScrollX": "100%",
            "bPaginate": true,
            "bFilter": true,
            "aaSorting": [[ 1, "asc" ]],
            "sPaginationType": "full_numbers",
            "aoColumns": [
                { "mDataProp": "user.id","sWidth": "10%"},
                { "mDataProp": "role.area.description","sWidth": "45%"},
                { "mDataProp": "role.description","sWidth": "45%"}
            ],

            "fnServerData": function ( sSource, aoData, fnCallback ) {
                $.merge(aoData,applicationLib.createSearchParams(searchParameters));
                hideAllAlertsAndProcessScreen();
                showHideProcessScreen(true);
                $.ajax( {"url":sSource,
                         "dataType":'json',
                         "data":aoData,
                    "success":function (response) {
                        if(!response.success&&response.success===false){
                            var json={};
                            json.aaData= {};
                            json.iTotalDisplayRecords=0;
                            json.iTotalRecords=response.totalElements;
                            fnCallback(json);
                            hideAllAlertsAndProcessScreen();
                            showAlert(response.messages,MONSANTO_STATIC_VARIABLE_ERROR);
                        }else{
                            hideAllAlertsAndProcessScreen();
                            var json={};
                            json.aaData= response.content;
                            json.iTotalDisplayRecords=response.totalElements;
                            json.iTotalRecords=response.totalElements;
                            fnCallback(json);
                        }

                    },
                    "error":function(xhr, status, error) {
                        hideAllAlertsAndProcessScreen();
                        showAlert(["Application Error, Try Again"],MONSANTO_STATIC_VARIABLE_ERROR);
                    }
                });
            },"fnRowCallback": function(nRow, aData, iDisplayIndex) {
            $(nRow).click(function() {
                showHideProcessScreen(true);
                cleanFrom();
                $.ajax( {"url": s.baseUrl+"/security/userSecurityAdm/findById.do",
                    "dataType":'json',
                    "data":{ id:aData.id},
                    "success":function(entity,status ,xhr) {

                        $('#userPrivilegesId').val(entity.id);
                        $('#userId').val(entity.user.id);
                        $('#email').val(entity.user.email);

                        if(entity.user.active){
                           $('input[name=activeStatus]').attr('checked',true);
                        } else{
                           $('input[name=activeStatus]').attr('checked',false);
                        }

                        $('#areaId').val(entity.role.area.id);

                        loadComboRoles(entity.role.id)


                        $('#saveBtn').val('Modify');
                        $('#deleteBtn').attr('disabled',false);

                        showHideProcessScreen(false);
                    },
                    "error":function(xhr, status, error) {
                        hideAllAlertsAndProcessScreen();
                        showAlert([error],MONSANTO_STATIC_VARIABLE_ERROR);
                    }
                });

            });
        }
        });

    }

    var userObj;
    var userLabels;

    var queryTimer;
	var QUERY_DELAY=1000;

     function initUserNameSearch(){


          $( "#userId"         ).typeahead({
            source:  function ( query, process) {

                userObj ={};
                userLabels = [];

				clearTimeout(  queryTimer );
				queryTimer = setTimeout( function(){ findUserNameMatchesTypeHead( query,process ); }, QUERY_DELAY );
            },
            updater: function( label ){

                return fillUserNameAndIdField(  userObj[label] );
            },
			matcher: function(){ return true; }
        });
     }

     function findUserNameMatchesTypeHead( query, process ){
        $.ajax({
            url      : s.baseUrl+"/security/userSecurityAdm/loadCollectionUser.do",
            dataType : "json",
            data     : { id: query },
            success  : function( data ) {
                if( data.length == 0 ){
                    userLabels.push( "---No Data found---" );
                    $('#userId').val('');
                }
                $.each( data, function ( i, obj ) {

                    var label = obj.id +" [ "+ obj.name +" ] " ;

                    userObj[label] = obj;
                    userLabels.push( label )

                });
                process( userLabels );

            },
            error    : function( xhr, status, error ) {showAlert([error],MONSANTO_STATIC_VARIABLE_ERROR); }
        });
     }

     function fillUserNameAndIdField( userObj ){
        if( userObj != null ){

            $( "#userId" ).val( userObj.id );

            return  userObj.id;
        }
     }


     function cleanFrom(){
        $('#userPrivilegesId').val('');
        $('#userId').val('');
        $('#areaId').val('-1');
        $('#roleId').val('-1');
        $('#email').val('');
        $('#saveBtn').val('Save');
        $('input[name=activeStatus]').attr('checked',true);
        cleanErrors(FIELDS_TO_CLEAN);
     }

     $(document).ready(function() {
         loadPage();
     });
})(jQuery,application);