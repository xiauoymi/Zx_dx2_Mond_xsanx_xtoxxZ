(function ($,s) {

    var MAIN_DATA_TABLE = "dataTable_baseTemperature";

      var searchParameters=[
        { id: 'baseTemperatureId', container: '#baseTemperatureId', property: 'baseTemperatureId', searchValue: '' },
        { id: 'cropTypeId', container: '#cropTypeId', property: 'cropTypeId', searchValue: '' },
        { id: 'cropId', container: '#cropId', property: 'cropId', searchValue: '' },
        { id: 'tempMin', container: '#tempMin', property: 'tempMin', searchValue: '' },
        { id: 'tempMax', container: '#tempMax', property: 'tempMax', searchValue: '' },
        { id: 'activeStatus', container: '#activeStatus', property: 'activeStatus', searchValue: '' }
      ];

    function loadPage(){
      initData();
      initDataTable();
      initBtnSaveOrUpdate();
      initBtnSearch();
      initBtnDelete();
      initBtnClean();
      initComboCropTypes();
    }

    function initData(){
      $('input[name=activeStatus]').attr('checked',true);
      $('#deleteBtn').attr('disabled',true);
    }


     function initComboCropTypes(){
         var options = {
             'url':s.baseUrl + '/catalog/cropTypeBase/loadCollection.do' , 'params':{},
             'sourceScript':'#comboBoxTemplate', 'container':'#containerCropType',
             'comboBoxId':'cropTypeId', 'comboBoxName':'cropTypeId',
             'mappings':{'id':'id','description':'description','selectedItem':'-1'}, 'async':false
         }
         applicationLib.initComboByUrl(options);

         loadComboCrop($('#cropTypeId').val(),'-1');

          $(document).on("change",'#cropTypeId', function() {
              loadComboCrop($('#cropTypeId').val(),'-1');
          });
    }

     function loadComboCrop(cropTypeId,cropId){
         var options = {
             'url':s.baseUrl + '/catalog/cropBase/loadCollectionByParent.do' , 'params':{'cropTypeId':cropTypeId},
             'sourceScript':'#comboBoxTemplate', 'container':'#containerCropId',
             'comboBoxId':'cropId', 'comboBoxName':'cropId',
             'mappings':{'id':'id','description':'description','selectedItem':cropId}, 'async':false
         }
         applicationLib.initComboByUrl(options);
    }


     function initBtnClean(){

         $(document).on("click",'#cleanBtn', function() {
             cleanFrom();

         });
    }

    function initBtnSaveOrUpdate(){

         $(document).on("click",'#saveBtn', function() {
             var errFound = false;
                 errFound = validateForm(errFound,'cropTypeId',VALIDATE_CROP_TYPE_ID_COMBO);
                 errFound = validateForm(errFound,'cropId',VALIDATE_CROP_ID_COMBO);
                 errFound = validateForm(errFound,'tempMin',VALIDATE_TEMP_MIN);
                 errFound = validateForm(errFound,'tempMax',VALIDATE_TEMP_MAX);
                 errFound = validateForm(errFound,'tempMin@tempMax',VALIDATE_TEMP_MIN_VS_MAX);

             if(!errFound){
                showAlert(['The Registry is about to be saved, do you want to proceed?'],MONSANTO_STATIC_VARIABLE_NOTIFICATION,saveCallback)
             }
         });
    }

    function initBtnSearch(){

         $(document).on("click",'#searchBtn', function() {
             cleanErrors(FIELDS_TO_CLEAN);
             drawTable();
         });
    }

    function initBtnDelete(){

         $(document).on("click",'#deleteBtn', function() {
             showAlert(['The Registry is about to be deleted, do you want to proceed?'],MONSANTO_STATIC_VARIABLE_WARNING,deleteCallback)
         });

    }



     function drawTable(){
        $('#baseTemperatureId').val('');
        $('#saveBtn').val('Save');
        $('#deleteBtn').attr('disabled',true);

        $('#'+MAIN_DATA_TABLE).dataTable().fnDraw();
    }


    function saveCallback(){
         hideShowAlertBox(false);
         showHideProcessScreen(true);
         var optionsForm = {
                  dataType:  'json',
                  "success":function(response, statusText, xhr) {
                    if (response.success) {
                        showHideProcessScreen(false);
                        showAlert(response.messages,MONSANTO_STATIC_VARIABLE_SUCCESS,drawTable);

                    }else{
                        hideAllAlertsAndProcessScreen();
                        showAlert(response.messages,MONSANTO_STATIC_VARIABLE_ERROR);

                    }
                  },
                  "error":function(xhr, status, error) {
                      hideAllAlertsAndProcessScreen();
                      showAlert([error],MONSANTO_STATIC_VARIABLE_ERROR);
                  }
              };

              $('#dataForm').ajaxForm(optionsForm);
              $('#dataForm').submit();

    }

    function deleteCallback(){
         hideShowAlertBox(false);
         showHideProcessScreen(true);

         $.ajax( {"url": s.baseUrl+"/catalog/temperatureBase/delete.do",
            "dataType":'json',
            "data":{ id:$('#baseTemperatureId').val()},
            "success":function(response,status ,xhr) {

                if(!response.success&&response.success===false){
                      hideAllAlertsAndProcessScreen();
                      showAlert(response.messages,MONSANTO_STATIC_VARIABLE_ERROR);
                 }else{
                    cleanFrom();
                    showHideProcessScreen(false);
                    showAlert(response.messages,MONSANTO_STATIC_VARIABLE_SUCCESS,drawTable);
                }
            },
            "error":function(xhr, status, error) {
                hideAllAlertsAndProcessScreen();
                showAlert([error],MONSANTO_STATIC_VARIABLE_ERROR);
            }
        });

    }

    function initDataTable(){

       var tableInfo= $('#'+MAIN_DATA_TABLE).dataTable( {
             "bJQueryUI": true,
            "bProcessing": true,
            "bServerSide": true,
            "bLengthChange": 10,
            "sAjaxSource" : s.baseUrl+"/catalog/temperatureBase/search.do",
            "sScrollX": "100%",
            "bPaginate": true,
            "bFilter": true,
            "aaSorting": [[ 1, "asc" ]],
            "sPaginationType": "full_numbers",
            "aoColumns": [
                { "mDataProp": "id","sWidth": "10%"},
                { "mDataProp": "crop.type.description","sWidth": "20%"},
                { "mDataProp": "crop.description","sWidth": "20%"},
                { "mDataProp": "tempmin","sWidth": "15%"},
                { "mDataProp": "tempmax","sWidth": "15%"},
                { "mDataProp": "activeDescription","sWidth": "20%","bSortable": false}
            ],

            "fnServerData": function ( sSource, aoData, fnCallback ) {
                $.merge(aoData,applicationLib.createSearchParams(searchParameters));
                hideAllAlertsAndProcessScreen();
                showHideProcessScreen(true);
                $.ajax( {"url":sSource,
                         "dataType":'json',
                         "data":aoData,
                    "success":function (response) {
                        if(!response.success&&response.success===false){
                            var json={};
                            json.aaData= {};
                            json.iTotalDisplayRecords=0;
                            json.iTotalRecords=response.totalElements;
                            fnCallback(json);
                            hideAllAlertsAndProcessScreen();
                            showAlert(response.messages,MONSANTO_STATIC_VARIABLE_ERROR);
                        }else{
                            hideAllAlertsAndProcessScreen();
                            var json={};
                            json.aaData= response.content;
                            json.iTotalDisplayRecords=response.totalElements;
                            json.iTotalRecords=response.totalElements;
                            fnCallback(json);
                        }

                    },
                    "error":function(xhr, status, error) {
                        hideAllAlertsAndProcessScreen();
                        showAlert(["Application Error, Try Again"],MONSANTO_STATIC_VARIABLE_ERROR);
                    }
                });
            },"fnRowCallback": function(nRow, aData, iDisplayIndex) {
            $(nRow).click(function() {
                showHideProcessScreen(true);
                cleanFrom();
                $.ajax( {"url": s.baseUrl+"/catalog/temperatureBase/findById.do",
                    "dataType":'json',
                    "data":{ id:aData.id},
                    "success":function(entity,status ,xhr) {

                        $('#baseTemperatureId').val(entity.id);
                        $('#tempMin').val(entity.tempmin);
                        $('#tempMax').val(entity.tempmax);
                        $('#cropTypeId').val(entity.crop.type.id);

                        loadComboCrop(entity.crop.type.id,entity.crop.id);

                        if(entity.active){
                           $('input[name=activeStatus]').attr('checked',true);
                        } else{
                           $('input[name=activeStatus]').attr('checked',false);
                        }

                        $('#saveBtn').val('Modify');
                        $('#deleteBtn').attr('disabled',false);

                        showHideProcessScreen(false);
                    },
                    "error":function(xhr, status, error) {
                        hideAllAlertsAndProcessScreen();
                        showAlert([error],MONSANTO_STATIC_VARIABLE_ERROR);
                    }
                });

            });
        }
        });

    }

     function cleanFrom(){
        $('#baseTemperatureId').val('');
        $('#tempMin').val('');
        $('#tempMax').val('');
        $('#cropId').val('-1');
        $('#cropTypeId').val('-1');
        $('#saveBtn').val('Save');
        $('input[name=activeStatus]').attr('checked',true);
        $('#deleteBtn').attr('disabled',true);
        cleanErrors(FIELDS_TO_CLEAN);
        loadComboCrop("-1","-1");
     }

     $(document).ready(function() {
         loadPage();
     });
})(jQuery,application);