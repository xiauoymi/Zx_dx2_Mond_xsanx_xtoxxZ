/**
 * Created with IntelliJ IDEA.
 * User: GFRAN1
 * Date: 7/22/14
 * Time: 10:33 AM
 * To change this template use File | Settings | File Templates.
 */
(function ($,s) {

    function loadPage(){
        loadComboMeteorologicalStation();
        initProcessBtn();
        initParameters();
        pickDate();
    }

    function loadComboMeteorologicalStation(){

        var options = {
            'url':s.baseUrl + '/catalog/meteoroStationBase/loadCollection.do' ,  'params':{},
            'sourceScript':'#comboBoxTemplate', 'container':'#containerMeteorologicalStation',
            'comboBoxId':'meteorologicalStationId', 'comboBoxName':'meteorologicalStationId',
            'mappings':{'id':'id','description':'description','selectedItem':'-1'}, 'async':false
        }
        applicationLib.initComboByUrl(options);
    }

    function initParameters(){
        $('#dataTable_errorLog').hide();
        if( $('#startDate').val() == '' || $('#endDate').val() == '' ){
            $('#processBtn').attr('disabled',true);
        }
    }

    function initProcessBtn(){
        $(document).on("click",'#processBtn', function() {
            var errFound = false;
            errFound = validateForm(errFound,'meteorologicalStationId',VALIDATE_REQUIRED);
            if(!errFound) {
                getExtrapolatedDataProfile();
            }
        });
    }

    function getExtrapolatedDataProfile(){

        $.ajax( {"url": s.baseUrl+"/catalog/prExtrapolateData/getExtrapolatedDataProfile.do",
            type: 'POST',
            data: $('#dataForm').serialize(),

            "success":function(response,data) {

                if(!response.success&&response.success===false){

                    showAlert(response.messages,MONSANTO_STATIC_VARIABLE_WARNING,callbackProcess());
                }else{
                    if(response.messages!='') {
                        hideShowAlertBox(false);
                        callbackProcess();
                    }
                }
            },
            "error":function(xhr, status, error) {

                showAlert([error],MONSANTO_STATIC_VARIABLE_ERROR);
            }
        }) ;

    }

    function cleanForm(){
        hideShowAlertBox(false);
        $("#startDate").val('');
        $("#endDate").val('');
        $("#days").val('');
        $("#meteorologicalStationId").val('');
    }

       function callbackProcess(){

           $.ajax( {"url": s.baseUrl+"/catalog/prExtrapolateData/extrapolateData.do",
               type: 'POST',
               data: $('#dataForm').serialize(),
               "success":function(response,data) {

                   if (!response.success&&response.success===false) {
                       showAlert(response.messages,MONSANTO_STATIC_VARIABLE_ERROR);

                   }
                   else{
                       showAlert(response.messages,MONSANTO_STATIC_VARIABLE_SUCCESS,cleanForm);
                   }
               },
               "error":function(xhr, status, error) {

                   showAlert([error],MONSANTO_STATIC_VARIABLE_ERROR);
               }
           }) ;
       }

    function pickDate(){
        $("#startDate").datepicker({
            firstDay: 1,
            onClose: function() {
                if( $('#startDate').val() != '' && $('#endDate').val() != ''){
                    $('#processBtn').attr('disabled',false);
                }
            }
        });
        $("#endDate").datepicker({
            firstDay: 1,
            onClose: function() {
                if( $('#startDate').val() != '' && $('#endDate').val() != ''){
                    $('#processBtn').attr('disabled',false);
                }
            }
        });
    }


    $(document).ready(function() {
        loadPage();
    });
})(jQuery,application);
