(function ($,s) {

    var MAIN_DATA_TABLE = "dataTable_meteoroStation";

      var searchParameters=[
        { id: 'stationTypeId', container: '#stationTypeId', property: 'stationTypeId', searchValue: '' },
        { id: 'meteorologicalStationId', container: '#meteorologicalStationId', property: 'meteorologicalStationId', searchValue: '' },
        { id: 'meteorologicalStationDescription', container: '#meteorologicalStationDescription', property: 'meteorologicalStationDescription', searchValue: '' },
        { id: 'meteorologicalStationLongitude', container: '#meteorologicalStationLongitude', property: 'meteorologicalStationLongitude', searchValue: '' },
        { id: 'meteorologicalStationLatitude', container: '#meteorologicalStationLatitude', property: 'meteorologicalStationLatitude', searchValue: '' },
        { id: 'activeStatus', container: '#activeStatus', property: 'activeStatus', searchValue: '' },
        { id: 'stationSerialNumber', container: '#stationSerialNumber', property: 'stationSerialNumber', searchValue: '' },
        { id: 'ownerId', container: '#ownerId', property: 'ownerId', searchValue: '' },
        { id: 'responsible', container: '#responsible', property: 'responsible', searchValue: '' }
      ];

    function loadPage(){
      initData();
      initDataTable();
      initBtnSaveOrUpdate();
      initBtnSearch();
      initBtnDelete();
      initBtnClean();

      initComboStationOwner();
      initComboStationTypes();
      initLdapUserNameSearch();
    }

    function initData(){
      $('input[name=activeStatus]').attr('checked',true);
      $('#deleteBtn').attr('disabled',true);
    }

     function initComboStationTypes(){
         var options = {
             'url':s.baseUrl + '/catalog/meteoroStationBase/loadStationTypeCollection.do' , 'params':{},
             'sourceScript':'#comboBoxTemplate', 'container':'#containerStationType',
             'comboBoxId':'stationTypeId', 'comboBoxName':'stationTypeId',
             'mappings':{'id':'id','description':'description','selectedItem':'-1'}, 'async':false
         }
         applicationLib.initComboByUrl(options);
    }


    function initComboStationOwner(){
         var options = {
             'url':s.baseUrl + '/catalog/meteoroStationOwnerBase/loadCollection.do' , 'params':{},
             'sourceScript':'#comboBoxTemplate', 'container':'#containerStationOwner',
             'comboBoxId':'ownerId', 'comboBoxName':'ownerId',
             'mappings':{'id':'id','description':'description','selectedItem':'-1'}, 'async':false
         }
         applicationLib.initComboByUrl(options);
    }



     function initBtnClean(){

         $(document).on("click",'#cleanBtn', function() {
             cleanFrom();
         });
    }

    function initBtnSaveOrUpdate(){

         $(document).on("click",'#saveBtn', function() {
             var errFound = false;
             cleanErrors(FIELDS_TO_CLEAN);

             errFound = validateForm(errFound,'stationTypeId',VALIDATE_COMBO_STATION_TYPE);
             errFound = validateForm(errFound,'meteorologicalStationDescription',VALIDATE_METEOROLOGICAL_DESCRIPTION);
             errFound = validateForm(errFound,'ownerId',VALIDATE_OWNER_ID_COMBO);
             errFound = validateForm(errFound,'meteorologicalStationUser',VALIDATE_METEOROLOGICAL_USER);
             errFound = validateForm(errFound,'meteorologicalStationLongitude',VALIDATE_METEOROLOGICAL_LONGITUDE);
             errFound = validateForm(errFound,'meteorologicalStationLatitude',VALIDATE_METEOROLOGICAL_LATITUDE);

             if($("#stationTypeId").val()==1){
                 errFound = validateForm(errFound,'meteorologicalStationPwd',VALIDATE_METEOROLOGICAL_PWD);
             }else if($("#stationTypeId").val()==2){
                 errFound = validateForm(errFound,'stationSerialNumber',VALIDATE_METEOROLOGICAL_SERIAL);

             }

             if(!errFound){
                 document.getElementById("googleMapDiv").style.display ="none";
                showAlert(['The Registry is about to be saved, do you want to proceed?'],MONSANTO_STATIC_VARIABLE_NOTIFICATION,saveCallback)
             }
         });
    }

    function initBtnSearch(){

         $(document).on("click",'#searchBtn', function() {
             document.getElementById("googleMapDiv").style.display ="none";
             cleanErrors(FIELDS_TO_CLEAN);
             drawTable();
         });
    }

    function initBtnDelete(){

         $(document).on("click",'#deleteBtn', function() {
             document.getElementById("googleMapDiv").style.display ="none";
             showAlert(['The Registry is about to be deleted, do you want to proceed?'],MONSANTO_STATIC_VARIABLE_WARNING,deleteCallback)
         });

    }



     function drawTable(){
        $('#meteorologicalStationId').val('');
        $('#saveBtn').val('Save');
        $('#deleteBtn').attr('disabled',true);

        $('#'+MAIN_DATA_TABLE).dataTable().fnDraw();
    }


    function saveCallback(){


         hideShowAlertBox(false);
         showHideProcessScreen(true);
         var optionsForm = {
                  dataType:  'json',
                  "success":function(response, statusText, xhr) {
                    if (response.success) {
                        showHideProcessScreen(false);
                        showAlert(response.messages,MONSANTO_STATIC_VARIABLE_SUCCESS,drawTable);

                    }else{
                        hideAllAlertsAndProcessScreen();
                        showAlert(response.messages,MONSANTO_STATIC_VARIABLE_ERROR);

                    }
                  },
                  "error":function(xhr, status, error) {
                      hideAllAlertsAndProcessScreen();
                      showAlert([error],MONSANTO_STATIC_VARIABLE_ERROR);
                  }
              };

              $('#dataForm').ajaxForm(optionsForm);
              $('#dataForm').submit();

    }

    function deleteCallback(){
         hideShowAlertBox(false);
         showHideProcessScreen(true);

         $.ajax( {"url": s.baseUrl+"/catalog/meteoroStationBase/delete.do",
            "dataType":'json',
            "data":{ id:$('#meteorologicalStationId').val()},
            "success":function(response,status ,xhr) {
                if(!response.success&&response.success===false){
                      hideAllAlertsAndProcessScreen();
                      showAlert(response.messages,MONSANTO_STATIC_VARIABLE_ERROR);
                 }else{
                    cleanFrom();
                    showHideProcessScreen(false);
                    showAlert(response.messages,MONSANTO_STATIC_VARIABLE_SUCCESS,drawTable);
                }

            },
            "error":function(xhr, status, error) {
                hideAllAlertsAndProcessScreen();
                showAlert([error],MONSANTO_STATIC_VARIABLE_ERROR);
            }
        });

    }

    function initDataTable(){

       var tableInfo= $('#'+MAIN_DATA_TABLE).dataTable( {
             "bJQueryUI": true,
            "bProcessing": true,
            "bServerSide": true,
            "bLengthChange": 10,
            "sAjaxSource" : s.baseUrl+"/catalog/meteoroStationBase/search.do",
            "sScrollX": "100%",
            "bPaginate": true,
            "bFilter": true,
            "aaSorting": [[ 1, "asc" ]],
            "sPaginationType": "full_numbers",
            "aoColumns": [
                { "mDataProp": "id","sWidth": "15%"},
                { "mDataProp": "description","sWidth": "15%"},
                { "mDataProp": "owner.description","sWidth": "10%"},
                { "mDataProp": "responsible.id","sWidth": "10%"},
                { "mDataProp": "stationType.description","sWidth": "10%"},
                { "mDataProp": "serialNumber","sWidth": "10%"},
                { "mDataProp": "longitude","sWidth": "10%"},
                { "mDataProp": "latitude","sWidth": "10%"},
                { "mDataProp": "activeDescription","sWidth": "10%","bSortable":false}
            ],

            "fnServerData": function ( sSource, aoData, fnCallback ) {
                $.merge(aoData,applicationLib.createSearchParams(searchParameters));
                hideAllAlertsAndProcessScreen();
                showHideProcessScreen(true);
                $.ajax( {"url":sSource,
                         "dataType":'json',
                         "data":aoData,
                    "success":function (response) {
                        if(!response.success&&response.success===false){
                            var json={};
                            json.aaData= {};
                            json.iTotalDisplayRecords=0;
                            json.iTotalRecords=response.totalElements;
                            fnCallback(json);
                            hideAllAlertsAndProcessScreen();
                            showAlert(response.messages,MONSANTO_STATIC_VARIABLE_ERROR);
                        }else{
                            hideAllAlertsAndProcessScreen();
                            var json={};
                            json.aaData= response.content;
                            json.iTotalDisplayRecords=response.totalElements;
                            json.iTotalRecords=response.totalElements;
                            fnCallback(json);
                        }

                    },
                    "error":function(xhr, status, error) {
                        hideAllAlertsAndProcessScreen();
                        showAlert(["Application Error, Try Again"],MONSANTO_STATIC_VARIABLE_ERROR);
                    }
                });
            },"fnRowCallback": function(nRow, aData, iDisplayIndex) {
            $(nRow).click(function() {
                showHideProcessScreen(true);
                cleanFrom();
                $.ajax( {"url": s.baseUrl+"/catalog/meteoroStationBase/findById.do",
                    "dataType":'json',
                    "data":{ id:aData.id},
                    "success":function(entity,status ,xhr) {

                        $('#meteorologicalStationId').val(entity.id);
                        $('#meteorologicalStationDescription').val(entity.description);
                        $('#ownerId').val(entity.owner.id);
                        $('#responsible').val(entity.responsible.id);
                        $('#meteorologicalStationLongitude').val(entity.longitude);
                        $('#meteorologicalStationLatitude').val(entity.latitude);
                        $('#meteorologicalStationUser').val(entity.userName);
                        $('#meteorologicalStationPwd').val(entity.pwd);
                        $('#stationTypeId').val(entity.stationType.id);
                        $('#stationSerialNumber').val(entity.serialNumber);




                        if(entity.active){
                           $('input[name=activeStatus]').attr('checked',true);
                        } else{
                           $('input[name=activeStatus]').attr('checked',false);
                        }

                        $('#saveBtn').val('Modify');
                        $('#deleteBtn').attr('disabled',false);

                        showHideProcessScreen(false);
                        loadMap();
                        $("#googleMapDiv").show();
                    },
                    "error":function(xhr, status, error) {
                        hideAllAlertsAndProcessScreen();
                        showAlert([error],MONSANTO_STATIC_VARIABLE_ERROR);
                    }
                });

            });
        }
        });

    }

    var userObj;
    var userLabels;

    var queryTimer;
    var QUERY_DELAY=1000;

    function initLdapUserNameSearch(){


        $( "#responsible"         ).typeahead({
            source:  function ( query, process) {

                userObj ={};
                userLabels = [];

                clearTimeout(  queryTimer );
                queryTimer = setTimeout( function(){ findLdapUserNameMatchesTypeHead( query,process ); }, QUERY_DELAY );
            },
            updater: function( label ){

                return fillDataOnForm(  userObj[label] );
            },
            matcher: function(){ return true; }
        });
    }

    function fillDataOnForm( userObj ){
        if( userObj != null ){

            $( "#responsible" ).val( userObj.id );

            return  userObj.id;
        }
    }

    function findLdapUserNameMatchesTypeHead( query, process ){
        $.ajax({
            url      : s.baseUrl+"/security/userBase/findLdapUser.do",
            dataType : "json",
            data     : { userId: query },
            success  : function( data ) {
                if( data.length == 0 ){
                    userLabels.push( "---No Data found---" );
                    $('#responsible').val('');
                }
                $.each( data, function ( i, obj ) {

                    var label = obj.id +" [ "+ obj.name +" ] " ;

                    userObj[label] = obj;
                    userLabels.push( label )

                });
                process( userLabels );

            },
            error    : function( xhr, status, error ) { showAlert([error],MONSANTO_STATIC_VARIABLE_ERROR); }
        });
    }

     function cleanFrom(){
        $('#meteorologicalStationId').val('');
        $('#stationTypeId').val('-1');
        $('#ownerId').val('-1');
         $('#responsible').val('');
        $('#meteorologicalStationDescription').val('');
        $('#meteorologicalStationLongitude').val('');
        $('#meteorologicalStationLatitude').val('');
        $('#meteorologicalStationUser').val('');
        $('#meteorologicalStationPwd').val('');
        $('#saveBtn').val('Save');
        $('input[name=activeStatus]').attr('checked',true);
         $('#deleteBtn').attr('disabled',true);
         cleanErrors(FIELDS_TO_CLEAN);
     }

     $(document).ready(function() {
         loadPage();
     });
})(jQuery,application);