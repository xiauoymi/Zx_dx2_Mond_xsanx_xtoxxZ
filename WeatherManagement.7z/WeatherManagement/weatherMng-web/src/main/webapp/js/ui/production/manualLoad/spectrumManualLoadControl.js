/**
 * Created by GFRAN1 on 10/28/2014.
 */
(function ($,s) {

    var ERROR_DATA_TABLE = "dataTable_errorLog";
    var searchParameters=[
        { id: 'batchId', container: '#batchId', property: 'batchId', searchValue: '' }
    ];
    var startDate;
    var endDate;

    var searchHistoricParameters=[
        { id: 'meteorologicalStationId', container: '#meteorologicalStationId', property: 'meteorologicalStationId', searchValue: '' },
        { id: 'startDate', container: '#startDate', property: 'startDate', searchValue: '' },
        { id: 'endDate', container: '#endDate', property: 'endDate', searchValue: '' }
    ]

    function loadPage(){
        initBtnClean();
        loadComboMeteorologicalStation();
        initImportBtn();
        initErrorsDataTable();
        initParameters();
        pickDate();
    }

    function pickDate(){

        $("#startDate").datepicker({
            firstDay: 1,
             onClose: function(dateText, inst) {
                if( $('#startDate').val() != '' && $('#endDate').val() != ''){
                    $('#importBtn').attr('disabled',false);
                }
                 var date = new Date(dateText);
                 startDate = date.getMonth();

            }
        });
        $("#endDate").datepicker({
            firstDay: 1,
            onClose: function(dateText, inst) {
                if( $('#startDate').val() != '' && $('#endDate').val() != ''){
                    $('#importBtn').attr('disabled',false);
                }
                var date = new Date(dateText);
                endDate = date.getMonth();
            }
        });
    }

    function initParameters(){
        $('#dataTable_errorLog').hide();
        if( $('#startDate').val() == '' || $('#endDate').val() == '' ){
            $('#importBtn').attr('disabled',true);
        }
    }

    function loadComboMeteorologicalStation(){

        var options = {
            'url':s.baseUrl + '/catalog/meteoroStationBase/loadCollectionByType.do' ,  'params':{},
            'sourceScript':'#comboBoxTemplate', 'container':'#containerMeteorologicalStation',
            'comboBoxId':'meteorologicalStationId', 'comboBoxName':'meteorologicalStationId',
            'mappings':{'id':'id','description':'description','selectedItem':'-1'}, 'async':false
        }
        applicationLib.initComboByUrl(options);
    }


    function initBtnClean(){

        $(document).on("click",'#cleanBtn', function() {
            cleanForm();
        });
    }


    function initImportBtn() {
        $(document).on("click", '#importBtn', function () {
            var errFound = false;
            errFound = validateForm(errFound, 'meteorologicalStationId', VALIDATE_REQUIRED);
            if (!errFound && $('#file0').val().length <= 0) {
                setErrorSpecificField("file0", "Please select a file");
                errFound = true;
            }
            if(startDate != endDate){
                showAlert(["Date range must be the same month"], MONSANTO_STATIC_VARIABLE_ERROR);
                errFound = true;
            }
            if (!errFound) {
                 cleanSpecificField("file0");
                importData();
            }
        });
    }


    function importData() {
        showHideProcessScreen(true);

        var options={
            "success": function (response, data) {

                if (!response.success && response.success === false) {
                    showHideProcessScreen(false);
                    $("#batchId").val(response.messages);
                    //showAlert(["Some records has errors,Look table below"], MONSANTO_STATIC_VARIABLE_ERROR);
                    showErrorTable();

                }
                else {
                    showHideProcessScreen(false);
                    if (response.messages != '0') {
                        showAlert(["Application Error"], MONSANTO_STATIC_VARIABLE_ERROR);
                    } else {
                        showAlert(["Data Merged Success"], MONSANTO_STATIC_VARIABLE_SUCCESS, endProcess);
                    }
                }
            },
            "error": function (xhr, status, error) {
                showHideProcessScreen(false);
                showAlert([error], MONSANTO_STATIC_VARIABLE_ERROR);
            }     }

        $('#dataForm').ajaxForm(options);
        $('#dataForm').submit();


    }
   function showErrorTable() {
        $('#dataTable_errorLog').show();
        $('#'+ERROR_DATA_TABLE).dataTable().fnDraw();
       cleanForm();
    }

    function endProcess(){
        hideShowAlertBox(false);
        $('#dataTable_errorLog').hide();
        cleanForm();
    }

    function initErrorsDataTable(){
        var tableInfo= $('#'+ERROR_DATA_TABLE).dataTable( {
            "bJQueryUI": true,
            "bProcessing": true,
            "bServerSide": true,
            "bLengthChange": 10,
            "sAjaxSource" : s.baseUrl+"/catalog/metStationReloadData/getDataLoaderLog.do",
            "sScrollX": "100%",
            "bPaginate": true,
            "bFilter": true,
            "aaSorting": [[ 1, "asc" ]],
            "sPaginationType": "full_numbers",
            "aoColumns": [
                { "mDataProp": "status","sWidth": "15%"},
                { "mDataProp": "dateTime","sWidth": "15%"},
                { "mDataProp": "recordCount","sWidth": "15%"},
                { "mDataProp": "insertedCount","sWidth": "15%"},
                { "mDataProp": "updatedCount","sWidth": "15%"},
                { "mDataProp": "errorCount","sWidth": "15%"},
                { "mDataProp": "errorMessage","sWidth": "10%"}
            ],

            "fnServerData": function ( sSource, aoData, fnCallback ) {
                $.merge(aoData,applicationLib.createSearchParams(searchParameters));
                hideAllAlertsAndProcessScreen();
                showHideProcessScreen(true);
                $.ajax( {"url":sSource,
                    "dataType":'json',
                    "data":aoData,
                    "success":function (response) {
                        if(!response.success&&response.success===false){
                            var json={};
                            json.aaData= {};
                            json.iTotalDisplayRecords=0;
                            json.iTotalRecords=response.totalElements;
                            fnCallback(json);
                            hideAllAlertsAndProcessScreen();
                            showAlert(response.messages,MONSANTO_STATIC_VARIABLE_ERROR);
                        }else{
                            hideAllAlertsAndProcessScreen();
                            var json={};
                            json.aaData= response.content;
                            json.iTotalDisplayRecords=response.totalElements;
                            json.iTotalRecords=response.totalElements;
                            fnCallback(json);
                        }

                    },
                    "error":function(xhr, status, error) {
                        hideAllAlertsAndProcessScreen();
                        showAlert(["Application Error, Try Again"],MONSANTO_STATIC_VARIABLE_ERROR);
                    }

                })
            }
        });
    }



    function cleanForm(){
        cleanSpecificField("file0");
        $('#meteorologicalStationId').val('-1');
        var file = $('#file0');
        file.replaceWith( file = file.clone( true ) );
        $("#startDate").val('');
        $("#endDate").val('');
    }

    $(document).ready(function() {
        loadPage();
    });
})(jQuery,application);