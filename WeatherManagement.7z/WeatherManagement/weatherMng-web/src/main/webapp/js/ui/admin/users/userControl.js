(function ($,s) {

    var MAIN_DATA_TABLE = "dataTable_users";

      var searchParameters=[
        { id: 'userId', container: '#userId', property: 'userId', searchValue: '' },
        { id: 'activeStatus', container: '#activeStatus', property: 'activeStatus', searchValue: '' },
        { id: 'sendNotification', container: '#sendNotification', property: 'sendNotification', searchValue: '' },
        { id: 'name', container: '#name', property: 'name', searchValue: '' },
        { id: 'email', container: '#email', property: 'email', searchValue: '' }

      ];

    function loadPage(){
      initData();
      initDataTable();
      initBtnSaveOrUpdate();
      initBtnSearch();
      initBtnDelete();
      initBtnClean();
      initLdapUserNameSearch();

    }


    function initData(){
      $('input[name=activeStatus]').attr('checked',true);
      $('#deleteBtn').attr('disabled',true);
    }

     function initBtnClean(){

         $(document).on("click",'#cleanBtn', function() {
             cleanFrom();
         });
    }

    function initBtnSaveOrUpdate(){

         $(document).on("click",'#saveBtn', function() {
             var errFound = false;
                 errFound = validateForm(errFound,'userId',VALIDATE_USER_ID);
                 errFound = validateForm(errFound,'name',VALIDATE_USER_NAME);
                 errFound = validateForm(errFound,'email',VALIDATE_USER_EMAIL);

             if(!errFound){
                showAlert(['The Registry is about to be saved, do you want to proceed?'],MONSANTO_STATIC_VARIABLE_NOTIFICATION,saveCallback)
             }
         });
    }

    function initBtnSearch(){

         $(document).on("click",'#searchBtn', function() {
             $('#userId').attr('readonly',false);
             cleanErrors(FIELDS_TO_CLEAN);
             drawTable();
         });
    }

    function initBtnDelete(){

         $(document).on("click",'#deleteBtn', function() {
             showAlert(['The Registry is about to be deleted, do you want to proceed?'],MONSANTO_STATIC_VARIABLE_WARNING,deleteCallback)
         });

    }



     function drawTable(){
        $('#saveBtn').val('Save');
        $('#deleteBtn').attr('disabled',true);

        $('#'+MAIN_DATA_TABLE).dataTable().fnDraw();
    }


    function saveCallback(){
         hideShowAlertBox(false);
         showHideProcessScreen(true);
         var optionsForm = {
                  dataType:  'json',
                  "success":function(response, statusText, xhr) {
                    if (response.success) {
                        showHideProcessScreen(false);
                        showAlert(response.messages,MONSANTO_STATIC_VARIABLE_SUCCESS,drawTable);

                    }else{
                        hideAllAlertsAndProcessScreen();
                        showAlert(response.messages,MONSANTO_STATIC_VARIABLE_ERROR);

                    }
                  },
                  "error":function(xhr, status, error) {
                      hideAllAlertsAndProcessScreen();
                      showAlert([error],MONSANTO_STATIC_VARIABLE_ERROR);
                  }
              };

              $('#dataForm').ajaxForm(optionsForm);
              $('#dataForm').submit();


    }

    function deleteCallback(){
         hideShowAlertBox(false);
         showHideProcessScreen(true);

         $.ajax( {"url": s.baseUrl+"/security/userBase/delete.do",
            "dataType":'json',
            "data":{ id:$('#userId').val()},
            "success":function(response,status ,xhr) {
                 if(!response.success&&response.success===false){
                      hideAllAlertsAndProcessScreen();
                      showAlert(response.messages,MONSANTO_STATIC_VARIABLE_ERROR);
                 }else{
                    cleanFrom();
                    showHideProcessScreen(false);
                    showAlert(response.messages,MONSANTO_STATIC_VARIABLE_SUCCESS,drawTable);
                 }
            },
            "error":function(xhr, status, error) {
                hideAllAlertsAndProcessScreen();
                showAlert([error],MONSANTO_STATIC_VARIABLE_ERROR);
            }
        });

    }

    function initDataTable(){

       var tableInfo= $('#'+MAIN_DATA_TABLE).dataTable( {
             "bJQueryUI": true,
            "bProcessing": true,
            "bServerSide": true,
            "bLengthChange": 10,
            "sAjaxSource" : s.baseUrl+"/security/userBase/search.do",
            "sScrollX": "100%",
            "bPaginate": true,
            "bFilter": true,
            "aaSorting": [[ 1, "asc" ]],
            "sPaginationType": "full_numbers",
            "aoColumns": [
                { "mDataProp": "id","sWidth": "20%"},
                { "mDataProp": "name","sWidth": "30%"},
                { "mDataProp": "email","sWidth": "30%"},
                { "mDataProp": "activeDescription","sWidth": "10%","bSortable":false},
                { "mDataProp": "sendNotificationDescription","sWidth": "10%","bSortable":false}
            ],

            "fnServerData": function ( sSource, aoData, fnCallback ) {
                $.merge(aoData,applicationLib.createSearchParams(searchParameters));
                hideAllAlertsAndProcessScreen();
                showHideProcessScreen(true);
                $.ajax( {"url":sSource,
                         "dataType":'json',
                         "data":aoData,
                    "success":function (response) {
                        if(!response.success&&response.success===false){
                            var json={};
                            json.aaData= {};
                            json.iTotalDisplayRecords=0;
                            json.iTotalRecords=response.totalElements;
                            fnCallback(json);
                            hideAllAlertsAndProcessScreen();
                            showAlert(response.messages,MONSANTO_STATIC_VARIABLE_ERROR);
                        }else{
                            hideAllAlertsAndProcessScreen();
                            var json={};
                            json.aaData= response.content;
                            json.iTotalDisplayRecords=response.totalElements;
                            json.iTotalRecords=response.totalElements;
                            fnCallback(json);
                        }

                    },
                    "error":function(xhr, status, error) {
                        hideAllAlertsAndProcessScreen();
                        showAlert(["Application Error, Try Again"],MONSANTO_STATIC_VARIABLE_ERROR);
                    }
                });
            },"fnRowCallback": function(nRow, aData, iDisplayIndex) {
            $(nRow).click(function() {
                showHideProcessScreen(true);
                cleanFrom();
                $.ajax( {"url": s.baseUrl+"/security/userBase/findById.do",
                    "dataType":'json',
                    "data":{ id:aData.id},
                    "success":function(entity,status ,xhr) {

                        $('#userId').val(entity.id);
                        $('#name').val(entity.name);
                        $('#email').val(entity.email);

                        if(entity.active){
                           $('input[name=activeStatus]').attr('checked',true);
                        } else{
                           $('input[name=activeStatus]').attr('checked',false);
                        }

                          if(entity.sendNotification){
                           $('#sendNotification').val("true");
                        } else{
                           $('#sendNotification').val("false");
                        }

                        $('#saveBtn').val('Modify');
                        $('#deleteBtn').attr('disabled',false);
                        $('#userId').attr('readonly',true);

                        showHideProcessScreen(false);
                    },
                    "error":function(xhr, status, error) {
                        hideAllAlertsAndProcessScreen();
                        showAlert([error],MONSANTO_STATIC_VARIABLE_ERROR);
                    }
                });

            });
        }
        });

    }

    var userObj;
    var userLabels;

    var queryTimer;
	var QUERY_DELAY=1000;

     function initLdapUserNameSearch(){


          $( "#userId"         ).typeahead({
            source:  function ( query, process) {

                userObj ={};
                userLabels = [];

				clearTimeout(  queryTimer );
				queryTimer = setTimeout( function(){ findLdapUserNameMatchesTypeHead( query,process ); }, QUERY_DELAY );
            },
            updater: function( label ){

                return fillDataOnForm(  userObj[label] );
            },
			matcher: function(){ return true; }
        });
     }

     function findLdapUserNameMatchesTypeHead( query, process ){
        $.ajax({
            url      : s.baseUrl+"/security/userBase/findLdapUser.do",
            dataType : "json",
            data     : { userId: query },
            success  : function( data ) {
                if( data.length == 0 ){
                    userLabels.push( "---No Data found---" );
                    $('#userId').val('');
                }
                $.each( data, function ( i, obj ) {

                    var label = obj.id +" [ "+ obj.name +" ] " ;

                    userObj[label] = obj;
                    userLabels.push( label )

                });
                process( userLabels );

            },
            error    : function( xhr, status, error ) { showAlert([error],MONSANTO_STATIC_VARIABLE_ERROR); }
        });
     }

     function fillDataOnForm( userObj ){
        if( userObj != null ){

            $( "#userId" ).val( userObj.id );
            $( "#name" ).val( userObj.name );
            $( "#email" ).val( userObj.email );

            return  userObj.id;
        }
     }


     function cleanFrom(){
        $('#userId').val('');
        $('#name').val('');
        $('#email').val('');
        $('#saveBtn').val('Save');
        $('#userId').attr('readonly',false);
        $('input[name=activeStatus]').attr('checked',true);
        $('#sendNotification').val('false');

        cleanErrors(FIELDS_TO_CLEAN);
     }

     $(document).ready(function() {
         loadPage();
     });
})(jQuery,application);