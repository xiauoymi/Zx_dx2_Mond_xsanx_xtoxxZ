(function ($,s) {

    var MAIN_DATA_TABLE = "dataTable_tempUnderZero";

      var searchParameters=[
        { id: 'meteorologicalStationId', container: '#meteorologicalStationId', property: 'meteorologicalStationId', searchValue: '' },
        { id: 'startDate', container: '#startDate', property: 'startDate', searchValue: '' },
        { id: 'endDate', container: '#endDate', property: 'endDate', searchValue: '' },
        { id: 'dayOfTheMonthA', container: '#dayOfTheMonthA', property: 'dayOfTheMonthA', searchValue: '' },
        { id: 'monthSectionA', container: '#monthSectionA', property: 'monthSectionA', searchValue: '' },
        { id: 'calculationTypeA', container: '#calculationTypeA', property: 'calculationTypeA', searchValue: '' },
        { id: 'currentValueA', container: '#currentValueA', property: 'currentValueA', searchValue: '' },
        { id: 'monthSectionB', container: '#monthSectionB', property: 'monthSectionB', searchValue: '' },
       // { id: 'calculationTypeB', container: '#calculationTypeB', property: 'calculationTypeB', searchValue: '' },
        { id: 'currentValueB', container: '#currentValueB', property: 'currentValueB', searchValue: '' },
        { id: 'yearC', container: '#yearC', property: 'yearC', searchValue: '' },
        { id: 'monthSectionC', container: '#monthSectionC', property: 'monthSectionC', searchValue: '' },
        { id: 'dayDStart', container: '#dayDStart', property: 'dayDStart', searchValue: '' },
        { id: 'monthSectionStartD', container: '#monthSectionStartD', property: 'monthSectionStartD', searchValue: '' },
        { id: 'dayDEnd', container: '#dayDEnd', property: 'dayDEnd', searchValue: '' },
        { id: 'monthSectionEndD', container: '#monthSectionEndD', property: 'monthSectionEndD', searchValue: '' },
        { id: 'tempMin', container: '#tempMin', property: 'tempMin', searchValue: '' },
        { id: 'tempMax', container: '#tempMax', property: 'tempMax', searchValue: '' },
        { id: 'firstLoad', container: '#firstLoad', property: 'firstLoad', searchValue: '' },
        { id: 'cropName', container: '#cropName', property: 'cropName', searchValue: '' }

      ];

    function loadPage(){

      showHideCalculatorComponent('container3');
      initBtnProcessA();
      initBtnProcessB();
      initBtnProcessC();
      initBtnProcessD();

      initBtnClean();
      initComboCropTypes();
      initComboCrop();

      initCombosOfYears();
      initCombosMonths();
      initCalculationTypes();
      initChangeMonthA();

      initChangeMonthStartD();
      initChangeMonthEndD();

      initComboStationOwner();
      loadComboMeteorologicalStation('-1');

      $("#firstLoad").val('YES');
      initDataTable();
      showHideCalculatorComponent('container3');

    }

    function initComboStationOwner(){
         var options = {
             'url':s.baseUrl + '/catalog/meteoroStationOwnerBase/loadCollection.do' , 'params':{},
             'sourceScript':'#comboBoxTemplate', 'container':'#containerStationOwner',
             'comboBoxId':'ownerId', 'comboBoxName':'ownerId',
             'mappings':{'id':'id','description':'description','selectedItem':'-1'}, 'async':false
         }

         $(document).on("change",'#ownerId', function() {
            loadComboMeteorologicalStation($('#ownerId').val());
        });

         applicationLib.initComboByUrl(options);
    }

    function initBtnProcessA(){
         $(document).on("click",'#btnProcessA', function() {
             callbackGeneralCalc();
         });
    }

    function initBtnProcessB(){
         $(document).on("click",'#btnProcessB', function() {
             callbackWeeklyCalc();
         });
    }

    function initBtnProcessC(){
         $(document).on("click",'#btnProcessC', function() {
             callbackUnderZeroCalc();
         });
    }

    function initBtnProcessD(){
         $(document).on("click",'#btnProcessD', function() {
             callbackPeriodToGDUs();
         });
    }


    function initChangeMonthA(){
          $(document).on("change",'#monthSectionA', function() {
              var leapYear = isLeapYear($("#startDate").val(),$("#endDate").val());
              loadDaysOfTheMonth($('#monthSectionA').val(),'dayOfTheMonthA',leapYear);
          });

    }

     function initChangeMonthStartD(){
          $(document).on("change",'#monthSectionStartD', function() {
              var leapYear = isLeapYear($("#startDate").val(),$("#endDate").val());
              loadDaysOfTheMonth($('#monthSectionStartD').val(),'dayDStart',leapYear);
          });

    }

    function initChangeMonthEndD(){
          $(document).on("change",'#monthSectionEndD', function() {
              var leapYear = isLeapYear($("#startDate").val(),$("#endDate").val());
              loadDaysOfTheMonth($('#monthSectionEndD').val(),'dayDEnd',leapYear);
          });

    }


    function initCalculationTypes(){
        addComboItem("calculationTypeA","-- Select an Option --",-1);
        addComboItem("calculationTypeA","GDU","GDU");
        addComboItem("calculationTypeA","Days","Days");

        //addComboItem("calculationTypeB","Select an Option",-1);
        //addComboItem("calculationTypeB","GDU","GDU");
        //addComboItem("calculationTypeB","Days","Days");


    }

    function initCombosMonths(){

        addComboItem("monthSectionA","-- Select an Option --",-1);
        addComboItem("monthSectionB","-- Select an Option --",-1);
        addComboItem("monthSectionC","-- Select an Option --",-1);
        addComboItem("monthSectionStartD","-- Select an Option --",-1);
        addComboItem("monthSectionEndD","-- Select an Option --",-1);

        for(var i=0;i<MONTHS.length;i++){
            addComboItem("monthSectionA",MONTHS[i],(i+1));
            addComboItem("monthSectionB",MONTHS[i],(i+1));
            addComboItem("monthSectionC",MONTHS[i],(i+1));
            addComboItem("monthSectionStartD",MONTHS[i],(i+1));
            addComboItem("monthSectionEndD",MONTHS[i],(i+1));
        }
    }

    function initCombosOfYears() {
        addComboItem("startDate", "-- Select an Option --", -1);
        addComboItem("endDate", "-- Select an Option --", -1);
        addComboItem("yearC", "-- Select an Option --", -1);

        for (var i = 2006; i <= new Date().getFullYear(); i++) {
            addComboItem("startDate", i, i);
            addComboItem("endDate", i, i);
            addComboItem("yearC", i, i);
        }

        $(document).on("change", '#startDate', function() {
            resetMonthsAndDays();
        });

        $(document).on("change", '#endDate', function() {
            resetMonthsAndDays();
        });

    }

    function resetMonthsAndDays() {
        $("#monthSectionA").val("-1");
        $("#monthSectionStartD").val("-1");
        $("#monthSectionEndD").val("-1");

        cleanCombo("dayOfTheMonthA");
        cleanCombo("dayDEnd");
        cleanCombo("dayDStart");

         addComboItem("dayOfTheMonthA","-- Select an Option --",-1);
         addComboItem("dayDEnd","-- Select an Option --",-1);
         addComboItem("dayDStart","-- Select an Option --",-1);
    }

    function initComboCropTypes() {
        var options = {
            'url':s.baseUrl + '/catalog/cropTypeBase/loadCollection.do' , 'params':{},
            'sourceScript':'#comboBoxTemplate', 'container':'#containerCropType',
            'comboBoxId':'cropTypeId', 'comboBoxName':'cropTypeId',
            'mappings':{'id':'id','description':'description','selectedItem':'-1'}, 'async':false
         }
         applicationLib.initComboByUrl(options);

          $(document).on("change",'#cropTypeId', function() {
              $('#tempMin').val('');
              $('#tempMax').val('');
              $('#cropName').val('');
              cleanSpecificField("cropId");
              loadComboCrop($('#cropTypeId').val(),'-1');
          });
    }

     function loadComboCrop(cropTypeId,cropId){
         var options = {
             'url':s.baseUrl + '/catalog/cropBase/loadCollectionByParent.do' , 'params':{'cropTypeId':cropTypeId},
             'sourceScript':'#comboBoxTemplate', 'container':'#containerCropId',
             'comboBoxId':'cropId', 'comboBoxName':'cropId',
             'mappings':{'id':'id','description':'description','selectedItem':cropId}, 'async':false
         }
         applicationLib.initComboByUrl(options);

          $(document).on("change",'#cropId', function() {
              loadBaseTemperatures($('#cropTypeId').val(),$('#cropId').val());
              $("#cropName").val($("#cropId option:selected").text());

          });
    }

     function initComboCrop(){
         var options = {
             'url':s.baseUrl + '/catalog/cropBase/loadCollectionByParent.do' , 'params':{'cropTypeId':'-1'},
             'sourceScript':'#comboBoxTemplate', 'container':'#containerCropId',
             'comboBoxId':'cropId', 'comboBoxName':'cropId',
             'mappings':{'id':'id','description':'description','selectedItem':'-1'}, 'async':false
         }
         applicationLib.initComboByUrl(options);

    }



    function loadBaseTemperatures(cropTypeId,cropId){
        var cropType = cropTypeId < 0 ? null : cropTypeId;
        var crop = cropId < 0 ? null : cropId;

        $.ajax( {"url": s.baseUrl+"/catalog/temperatureBase/search.do",
            "dataType":'json',
            "data":{'cropTypeId':cropType,'cropId':crop,'tempMin':'','tempMax':'','activeStatus':true},
            "success":function(response,status ,xhr) {

                if(!response.success&&response.success===false){
                      hideAllAlertsAndProcessScreen();
                      showAlert(response.messages,MONSANTO_STATIC_VARIABLE_ERROR);
                      cleanFrom();
                 }else{

                    if(response.content.length>0){
                        $("#tempMax").val(response.content[0].tempmax);
                        $("#tempMin").val(response.content[0].tempmin);
                    }else{
                        $("#tempMax").val('');
                        $("#tempMin").val('');
                    }


                }
            },
            "error":function(xhr, status, error) {
                hideAllAlertsAndProcessScreen();
                showAlert([error],MONSANTO_STATIC_VARIABLE_ERROR);
                cleanFrom();
            }
        });

    }



    function loadComboMeteorologicalStation(selectedItem){
        var ownerId = ($('#ownerId').val()!=null && $('#ownerId').val()!=undefined )? $('#ownerId').val() : "-1";
         var options = {
             'url':s.baseUrl + '/catalog/meteoroStationBase/loadCollectionByOwner.do' ,
             'params':{'ownerId':ownerId},
             'sourceScript':'#comboBoxTemplate', 'container':'#containerMetStation',
             'comboBoxId':'meteorologicalStationId', 'comboBoxName':'meteorologicalStationId',
             'mappings':{'id':'id','description':'description','selectedItem':selectedItem}, 'async':false
         }
         applicationLib.initComboByUrl(options);
    }

    function validateGeneralData(){
       var  errFound = validateForm(errFound,'meteorologicalStationId',VALIDATE_COMBO_METEOROLOGICAL_STATION);
                 errFound = validateForm(errFound,'startDate',VALIDATE_COMBO_START_DATE);
                 errFound = validateForm(errFound,'endDate',VALIDATE_COMBO_END_DATE);
                 errFound = validateForm(errFound,'cropTypeId',VALIDATE_COMBO_CROP_TYPE);
                 errFound = validateForm(errFound,'cropId',VALIDATE_COMBO_CROP);
                 errFound = validateForm(errFound,'startDate@endDate',VALIDATE_ANUALINI_VS_ANUALEND);
        return errFound;

    }

    function validateGeneralCalc() {
        var errFound = false;
        errFound = validateGeneralData();
        errFound = validateForm(errFound, 'dayOfTheMonthA', VALIDATE_COMBO_DAY_OF_THE_MONTH_A);
        errFound = validateForm(errFound, 'monthSectionA', VALIDATE_COMBO_MONTH_A);
        errFound = validateForm(errFound, 'calculationTypeA', VALIDATE_COMBO_CALC_TYPE_A);
        errFound = validateForm(errFound, 'currentValueA', VALIDATE_VALUE_A);

        errFound = checkForAssignedTemperature(errFound);

        return errFound;
    }

    function checkForAssignedTemperature(errFound){
        if (!errFound && ($('#tempMax').val() == "" || $('#tempMax').val() == null) && ($('#tempMin').val() == "" || $('#tempMin').val() == null)) {
            setErrorSpecificField("cropId","Temp Min or Max are invalid for this crop, review them in the Base Temp Catalog");
            errFound = true;
        } else {
            if(!errFound){
                cleanSpecificField("cropId");
            }

        }

        return errFound;
    }

    function validateUnderZeroCalc(){
        var errFound = false;
        errFound = validateForm(errFound,'meteorologicalStationId',VALIDATE_COMBO_METEOROLOGICAL_STATION);
        errFound = validateForm(errFound,'yearC',VALIDATE_COMBO_YEAR_C);
        errFound = validateForm(errFound,'monthSectionC',VALIDATE_COMBO_CALC_MONTH_C);

        return errFound;

    }

    function validateWeeklyCalc(){
           var errFound = false;
        errFound = validateGeneralData();
        errFound = validateForm(errFound,'monthSectionB',VALIDATE_COMBO_MONTH_B);
      //  errFound = validateForm(errFound,'calculationTypeB',VALIDATE_COMBO_CALC_TYPE_B);
       // errFound = validateForm(errFound,'currentValueB',VALIDATE_VALUE_B);

        errFound = checkForAssignedTemperature(errFound);

        return errFound;

    }

    function callbackGeneralCalc(){
         hideShowAlertBox(false);

        if(validateGeneralCalc()){return;}

         showHideProcessScreen(true);

           var aoData=[];
         $.merge(aoData,applicationLib.createSearchParams(searchParameters));

         $.ajax( {"url": s.baseUrl+"/tools/calculatorBase/generalCalculationBy.do",
            "dataType":'json',
            "data":aoData,
            "success":function(response,status ,xhr) {

                if(!response.success&&response.success===false){
                      hideAllAlertsAndProcessScreen();
                      showAlert(response.messages,MONSANTO_STATIC_VARIABLE_ERROR);
                      cleanDataFromTableA();
                 }else{

                    showHideProcessScreen(false);

                    if($("#temperatureIn").val()=="C"){
                        $("#resultTempMinALabel").html(response.tempMinC);
                        $("#resultTempMaxALabel").html(response.tempMaxC);
                    }else{
                        $("#resultTempMinALabel").html(response.tempMinF);
                        $("#resultTempMaxALabel").html(response.tempMaxF);

                    }

                    $("#resultMonthDescALabel").html(getMonthDescription(response.month));
                    $("#resultDayALabel").html(response.day);
                    $("#resultGDULabel").html(response.realGDU);

                }
            },
            "error":function(xhr, status, error) {
                hideAllAlertsAndProcessScreen();
                showAlert([error],MONSANTO_STATIC_VARIABLE_ERROR);
                cleanDataFromTableA();
            }
        });
    }

    function validatePeriodToGDUs(){
           var errFound = false;
        errFound = validateGeneralData();
        errFound = validateForm(errFound,'monthSectionStartD',VALIDATE_COMBO_CALC_MONTH_D_START);
        errFound = validateForm(errFound,'dayDStart',VALIDATE_COMBO_CALC_DAY_D_START);
        errFound = validateForm(errFound,'monthSectionEndD',VALIDATE_COMBO_CALC_MONTH_D_END);
        errFound = validateForm(errFound,'dayDEnd',VALIDATE_COMBO_CALC_DAY_D_END);


        errFound = checkForAssignedTemperature(errFound);

        return errFound;

    }

    function callbackPeriodToGDUs(){
        hideShowAlertBox(false);

        if(validatePeriodToGDUs()){return;}

         showHideProcessScreen(true);

           var aoData=[];
         $.merge(aoData,applicationLib.createSearchParams(searchParameters));

         $.ajax( {"url": s.baseUrl+"/tools/calculatorBase/periodToGDU.do",
            "dataType":'json',
            "data":aoData,
            "success":function(response,status ,xhr) {

                if(!response.success&&response.success===false){
                      hideAllAlertsAndProcessScreen();
                      showAlert(response.messages,MONSANTO_STATIC_VARIABLE_ERROR);
                      cleanDataFromTableB();
                 }else{

                    showHideProcessScreen(false);
                     $('#resultTimeToGDUs').html(response.gdus);



                }
            },
            "error":function(xhr, status, error) {
                hideAllAlertsAndProcessScreen();
                showAlert([error],MONSANTO_STATIC_VARIABLE_ERROR);
                cleanDataFromTableB();
            }
        });

    }

    function callbackWeeklyCalc(){
         hideShowAlertBox(false);

        if(validateWeeklyCalc()){return;}

         showHideProcessScreen(true);

           var aoData=[];
         $.merge(aoData,applicationLib.createSearchParams(searchParameters));

         $.ajax( {"url": s.baseUrl+"/tools/calculatorBase/weeklyCalculationBy.do",
            "dataType":'json',
            "data":aoData,
            "success":function(response,status ,xhr) {

                if(!response.success&&response.success===false){
                      hideAllAlertsAndProcessScreen();
                      showAlert(response.messages,MONSANTO_STATIC_VARIABLE_ERROR);
                      cleanDataFromTableB();
                 }else{

                    showHideProcessScreen(false);

                    cleanDataFromTableB();

                    for(var i=0;i<response.length;i++){

                        var tempMinId = "#resultWeek"+response[i].currentWeek+"TempMinLabel";
                        var tempMaxId = "#resultWeek"+response[i].currentWeek+"TempMaxLabel";
                        var numWeekId = "#resultWeek"+response[i].currentWeek+"NumWeekLabel";
                        var numMonthId = "#resultWeek"+response[i].currentWeek+"MonthLabel";



                        if ($("#temperatureIn").val() == "C") {
                            $(tempMinId).html(response[i].tempMinC);
                            $(tempMaxId).html(response[i].tempMaxC);
                        } else {
                            $(tempMinId).html(response[i].tempMinF);
                            $(tempMaxId).html(response[i].tempMaxF);
                        }


                        $(numWeekId).html(response[i].nuWeek);
                        $(numMonthId).html(getMonthDescription(response[i].nuMonth));


                    }

                }
            },
            "error":function(xhr, status, error) {
                hideAllAlertsAndProcessScreen();
                showAlert([error],MONSANTO_STATIC_VARIABLE_ERROR);
                cleanDataFromTableB();
            }
        });
    }

    function callbackUnderZeroCalc(){
        hideShowAlertBox(false);

        if(validateUnderZeroCalc()){return;}

        cleanErrors(FIELDS_TO_CLEAN);
        drawTable();

    }

    function cleanDataFromTableA(){
        $('#resultTempMinALabel').html('');
        $('#resultTempMaxALabel').html('');
        $('#resultMonthDescALabel').html('');
        $('#resultDayALabel').html('');
    }

    function cleanDataFromTableB(){
        $('#resultWeek1MonthLabel').html('');
        $('#resultWeek2MonthLabel').html('');
        $('#resultWeek3MonthLabel').html('');
        $('#resultWeek4MonthLabel').html('');

        $('#resultWeek1NumWeekLabel').html('');
        $('#resultWeek2NumWeekLabel').html('');
        $('#resultWeek3NumWeekLabel').html('');
        $('#resultWeek4NumWeekLabel').html('');

        $('#resultWeek1TempMaxLabel').html('');
        $('#resultWeek2TempMaxLabel').html('');
        $('#resultWeek3TempMaxLabel').html('');
        $('#resultWeek4TempMaxLabel').html('');

        $('#resultWeek1TempMinLabel').html('');
        $('#resultWeek2TempMinLabel').html('');
        $('#resultWeek3TempMinLabel').html('');
        $('#resultWeek4TempMinLabel').html('');
    }


    function initBtnClean(){

         $(document).on("click",'#cleanBtn', function() {
             cleanFrom();
         });
    }


     function drawTable(){
        $('#'+MAIN_DATA_TABLE).dataTable().fnDraw();
    }


    function initDataTable(){

       var tableInfo= $('#'+MAIN_DATA_TABLE).dataTable( {
             "bJQueryUI": true,
            "bProcessing": true,
            "bServerSide": true,
            "bLengthChange": 10,
            "sAjaxSource" : s.baseUrl+"/tools/calculatorBase/getTemperaturesUnderZero.do",
            "sScrollX": "100%",
            "bPaginate": false,
            "bFilter": true,
            "aaSorting": [[ 1, "asc" ]],
            "sScrollY": "200px",
            "bPaginate": false,
            "aoColumns": [
                { "mDataProp": "dateDesc","sWidth": "50%","bSortable": false},
                 { "mDataProp":  function ( source, type, val ) {
                   if($("#temperatureIn").val()=="C"){
                        return source.tempMinC;
                   }else{
                        return source.tempMinF;
                   }
                },"bSortable": false,"sWidth": "50%" }
            ],

            "fnServerData": function ( sSource, aoData, fnCallback ) {
                $.merge(aoData,applicationLib.createSearchParams(searchParameters));
                hideAllAlertsAndProcessScreen();
                showHideProcessScreen(true);
                $.ajax( {"url":sSource,
                         "dataType":'json',
                         "data":aoData,
                    "success":function (response) {
                        $("#firstLoad").val('NO');
                        if(!response.success&&response.success===false){
                            var json={};
                            json.aaData= {};
                            json.iTotalDisplayRecords=0;
                            json.iTotalRecords=response.totalElements;
                            fnCallback(json);
                            hideAllAlertsAndProcessScreen();
                            showAlert(response.messages,MONSANTO_STATIC_VARIABLE_ERROR);
                        }else{
                            hideAllAlertsAndProcessScreen();
                            var json={};
                            json.aaData= response.content;
                            json.iTotalDisplayRecords=response.totalElements;
                            json.iTotalRecords=response.totalElements;
                            fnCallback(json);
                        }

                    },
                    "error":function(xhr, status, error) {
                        hideAllAlertsAndProcessScreen();
                        showAlert(["Application Error, Try Again"],MONSANTO_STATIC_VARIABLE_ERROR);
                    }
                });
            }
        });

    }

     function cleanFrom(){

        $('#ownerId').val('-1');
        $('#meteorologicalStationId').val('-1');
        $('#startDate').val('-1');
        $('#endDate').val('-1');

        $('#dayOfTheMonthA').val('-1');
        $('#monthSectionA').val('-1');
        $('#calculationTypeA').val('-1');
        $('#currentValueA').val('');

        $('#monthSectionB').val('-1');
       // $('#calculationTypeB').val('-1');
     //   $('#currentValueB').val('');

        $('#yearC').val('-1');
        $('#monthSectionC').val('-1');

         $("#tempMin").val('');
         $("#tempMax").val('');
         $("#cropName").val('');

         $("#dayDStart").val('-1');
         $("#monthSectionStartD").val('-1');
         $("#dayDEnd").val('-1');
         $("#monthSectionEndD").val('-1');

         $("#cropTypeId").val('-1');

         $("#resultTimeToGDUs").val('');

         loadComboCrop('-1','-1');
         loadComboMeteorologicalStation("-1");

        cleanDataFromTableA();
        cleanDataFromTableB();

        cleanErrors(FIELDS_TO_CLEAN);

        $("#firstLoad").val('YES');
        drawTable();
     }

     $(document).ready(function() {
         loadPage();
     });
})(jQuery,application);

function showHideCalculatorComponent(id) {

    var container = document.getElementById(id);
    var status = document.getElementById(id + "DIV").innerHTML;

    if (status == '+') {
        container.style.display = "block";
        container.style.display = "block";
        document.getElementById(id + "DIV").innerHTML = "-";
    } else {
        container.style.display = "none";
        container.style.display = "none";
        document.getElementById(id + "DIV").innerHTML = "+";
    }
}
