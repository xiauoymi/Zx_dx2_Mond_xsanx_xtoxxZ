(function ($,s) {

    var MAIN_DATA_TABLE = "dataTable_productionCycle";

      var searchParameters=[
        { id: 'productionCycleDescription', container: '#productionCycleDescription', property: 'productionCycleDescription', searchValue: '' },
        { id: 'productionCycleId', container: '#productionCycleId', property: 'productionCycleId', searchValue: '' },
        { id: 'activeStatus', container: '#activeStatus', property: 'activeStatus', searchValue: '' }
      ];

    function loadPage(){
      initData();
      initDataTable();
      initBtnSaveOrUpdate();
      initBtnSearch();
      initBtnDelete();
      initBtnClean();
    }

    function initData(){
      $('input[name=activeStatus]').attr('checked',true);
      $('#deleteBtn').attr('disabled',true);
    }



     function initBtnClean(){

         $(document).on("click",'#cleanBtn', function() {
             cleanFrom();
         });
    }

    function initBtnSaveOrUpdate(){

         $(document).on("click",'#saveBtn', function() {
             var errFound = false;
                 errFound = validateForm(errFound,'productionCycleDescription',VALIDATE_PRODUCTION_CYCLE_DESCRIPTION);

             if(!errFound){
                showAlert(['The Registry is about to be saved, do you want to proceed?'],MONSANTO_STATIC_VARIABLE_NOTIFICATION,saveCallback)
             }
         });
    }

    function initBtnSearch(){

         $(document).on("click",'#searchBtn', function() {
             cleanErrors(FIELDS_TO_CLEAN);
             drawTable();
         });
    }

    function initBtnDelete(){

         $(document).on("click",'#deleteBtn', function() {
             showAlert(['The Registry is about to be deleted, do you want to proceed?'],MONSANTO_STATIC_VARIABLE_WARNING,deleteCallback)
         });

    }



     function drawTable(){
        $('#productionCycleId').val('');
        $('#saveBtn').val('Save');
        $('#deleteBtn').attr('disabled',true);

        $('#'+MAIN_DATA_TABLE).dataTable().fnDraw();
    }


    function saveCallback(){
         hideShowAlertBox(false);
         showHideProcessScreen(true);
         var optionsForm = {
                  dataType:  'json',
                  "success":function(response, statusText, xhr) {
                    if (response.success) {
                        showHideProcessScreen(false);
                        showAlert(response.messages,MONSANTO_STATIC_VARIABLE_SUCCESS,drawTable);

                    }else{
                        hideAllAlertsAndProcessScreen();
                        showAlert(response.messages,MONSANTO_STATIC_VARIABLE_ERROR);

                    }
                  },
                  "error":function(xhr, status, error) {
                      hideAllAlertsAndProcessScreen();
                      showAlert([error],MONSANTO_STATIC_VARIABLE_ERROR);
                  }
              };

              $('#dataForm').ajaxForm(optionsForm);
              $('#dataForm').submit();

    }

    function deleteCallback(){
         hideShowAlertBox(false);
         showHideProcessScreen(true);

         $.ajax( {"url": s.baseUrl+"/catalog/productionCycleBase/delete.do",
            "dataType":'json',
            "data":{ id:$('#productionCycleId').val()},
            "success":function(response,status ,xhr) {
                if(!response.success&&response.success===false){
                      hideAllAlertsAndProcessScreen();
                      showAlert(response.messages,MONSANTO_STATIC_VARIABLE_ERROR);
                 }else{
                    cleanFrom();
                    showHideProcessScreen(false);
                    showAlert(response.messages,MONSANTO_STATIC_VARIABLE_SUCCESS,drawTable);
                }
            },
            "error":function(xhr, status, error) {
                hideAllAlertsAndProcessScreen();
                showAlert([error],MONSANTO_STATIC_VARIABLE_ERROR);
            }
        });

    }

    function initDataTable(){

       var tableInfo= $('#'+MAIN_DATA_TABLE).dataTable( {
             "bJQueryUI": true,
            "bProcessing": true,
            "bServerSide": true,
            "bLengthChange": 10,
            "sAjaxSource" : s.baseUrl+"/catalog/productionCycleBase/search.do",
            "sScrollX": "100%",
            "bPaginate": true,
            "bFilter": true,
            "aaSorting": [[ 1, "asc" ]],
            "sPaginationType": "full_numbers",
            "aoColumns": [
                { "mDataProp": "id","sWidth": "10%"},
                { "mDataProp": "description","sWidth": "70%"},
                { "mDataProp": "activeDescription","sWidth": "20%","bSortable": false}
            ],

            "fnServerData": function ( sSource, aoData, fnCallback ) {
                $.merge(aoData,applicationLib.createSearchParams(searchParameters));
                hideAllAlertsAndProcessScreen();
                showHideProcessScreen(true);
                $.ajax( {"url":sSource,
                         "dataType":'json',
                         "data":aoData,
                    "success":function (response) {
                        if(!response.success&&response.success===false){
                            var json={};
                            json.aaData= {};
                            json.iTotalDisplayRecords=0;
                            json.iTotalRecords=response.totalElements;
                            fnCallback(json);
                            hideAllAlertsAndProcessScreen();
                            showAlert(response.messages,MONSANTO_STATIC_VARIABLE_ERROR);
                        }else{
                            hideAllAlertsAndProcessScreen();
                            var json={};
                            json.aaData= response.content;
                            json.iTotalDisplayRecords=response.totalElements;
                            json.iTotalRecords=response.totalElements;
                            fnCallback(json);
                        }

                    },
                    "error":function(xhr, status, error) {
                        hideAllAlertsAndProcessScreen();
                        showAlert(["Application Error, Try Again"],MONSANTO_STATIC_VARIABLE_ERROR);
                    }
                });
            },"fnRowCallback": function(nRow, aData, iDisplayIndex) {
            $(nRow).click(function() {
                showHideProcessScreen(true);
                cleanFrom();
                $.ajax( {"url": s.baseUrl+"/catalog/productionCycleBase/findById.do",
                    "dataType":'json',
                    "data":{ id:aData.id},
                    "success":function(entity,status ,xhr) {

                        $('#productionCycleId').val(entity.id);
                        $('#productionCycleDescription').val(entity.description);

                        if(entity.active){
                           $('input[name=activeStatus]').attr('checked',true);
                        } else{
                           $('input[name=activeStatus]').attr('checked',false);
                        }

                        $('#saveBtn').val('Modify');
                        $('#deleteBtn').attr('disabled',false);

                        showHideProcessScreen(false);
                    },
                    "error":function(xhr, status, error) {
                        hideAllAlertsAndProcessScreen();
                        showAlert([error],MONSANTO_STATIC_VARIABLE_ERROR);
                    }
                });

            });
        }
        });

    }

     function cleanFrom(){
        $('#productionCycleId').val('');
        $('#productionCycleDescription').val('');
        $('#saveBtn').val('Save');
        $('input[name=activeStatus]').attr('checked',true);
         $('#deleteBtn').attr('disabled',true);

        cleanErrors(FIELDS_TO_CLEAN);
     }

     $(document).ready(function() {
         loadPage();
     });
})(jQuery,application);