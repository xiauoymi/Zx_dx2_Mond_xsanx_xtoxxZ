(function ($,s) {

    var MAIN_DATA_TABLE = "dataTable_strewRecommendation";
    var REAL_REPORT_DATA_TABLE = "dataTable_realReport";
    var initRealReportTable = true;

    var cropStageGDUInfo;

      var searchParameters=[
        { id: 'productionZoneId', container: '#productionZoneId', property: 'productionZoneId', searchValue: '' },
        { id: 'productionCyclesId', container: '#productionCyclesId', property: 'productionCyclesId', searchValue: '' },
        { id: 'hybridId', container: '#hybridId', property: 'hybridId', searchValue: '' },
        { id: 'realReportYear', container: '#realReportYear', property: 'realReportYear', searchValue: '' },
        { id: 'realReportStartDay', container: '#realReportStartDay', property: 'realReportStartDay', searchValue: '' },
        { id: 'realReportStartMonth', container: '#realReportStartMonth', property: 'realReportStartMonth', searchValue: '' },
        { id: 'realReportMetStationOwnerId', container: '#realReportMetStationOwnerId', property: 'realReportMetStationOwnerId', searchValue: '' },
        { id: 'realReportMetStationId', container: '#realReportMetStationId', property: 'realReportMetStationId', searchValue: '' },
        { id: 'realReportCropType', container: '#realReportCropType', property: 'realReportCropType', searchValue: '' },
        { id: 'realReportCrop', container: '#realReportCrop', property: 'realReportCrop', searchValue: '' },
        { id: 'realReportTempMin', container: '#realReportTempMin', property: 'realReportTempMin', searchValue: '' },
        { id: 'realReportTempMax', container: '#realReportTempMax', property: 'realReportTempMax', searchValue: '' },
        { id: 'realReportCropStageData', container: '#realReportCropStageData', property: 'realReportCropStageData', searchValue: '' },
        { id: 'cropName', container: '#cropName', property: 'cropName', searchValue: '' },
        { id: 'sourceCode', container: '#sourceCode', property: 'sourceCode', searchValue: '' }
      ];

    function loadPage(){

      initTabs();
      initData();
      initDataTable();
      initBtnSaveOrUpdate();
      initBtnSearch();
      initBtnDelete();
      initBtnClean();
      initBtnExport();

      initComboProductionZone();
      initComboProductionCycle();
      initHybridSearch();


      initCombosRealReportYears();
      initCombosMonths();
      initChangeMonth();
      initComboStationOwner();
      loadComboMeteorologicalStation("-1");

      initComboCropTypes(QueryString.realReportCropType!=null && QueryString.realReportCropType!="" ? QueryString.realReportCropType : "-1");

      loadComboCrop(QueryString.realReportCropType!=null && QueryString.realReportCropType!="" ? QueryString.realReportCropType : "-1",
                    QueryString.realReportCrop!=null && QueryString.realReportCrop!="" ? QueryString.realReportCrop : "-1");


      initShowDataChartBtn();
      initBtnCleanDataChart();

    }

    function initTabs(){
      $( "#tabs" ).tabs();
      $('#tabs').removeClass('ui-widget ui-widget-content ui-corner-all');

    }

    function initBtnExport(){

         $(document).on("click",'#exportBtn', function() {

             if (!validateFieldsForChartData()) {
                 showAlert(['You are about to export these data to excel, do you want to proceed?'],MONSANTO_STATIC_VARIABLE_NOTIFICATION,callBackExportXLS)

             }

         });
    }

    function callBackExportXLS() {

        hideShowAlertBox(false);

        var filters = "year="+$('#realReportYear').val()+"&";
            filters=filters+"tempType="+$('#temperatureIn').val()+"&";
            filters=filters+"metStation="+$("#realReportMetStationId option:selected").text();

        window.location = s.baseUrl + "/production/strewRecommendationBase/export.do?"+filters;

    }

    function initComboProductionZone(){
         var options = {
             'url':s.baseUrl + '/catalog/productionZoneBase/loadCollection.do' , 'params':{},
             'sourceScript':'#comboBoxTemplate', 'container':'#containerProductionZone',
             'comboBoxId':'productionZoneId', 'comboBoxName':'productionZoneId',
             'mappings':{'id':'id','description':'description','selectedItem':'-1'}, 'async':false
         }
         applicationLib.initComboByUrl(options);
    }

    function initComboProductionCycle(){
         var options = {
             'url':s.baseUrl + '/catalog/productionCycleBase/loadCollection.do' , 'params':{},
             'sourceScript':'#comboBoxTemplate', 'container':'#containerProductionCycle',
             'comboBoxId':'productionCyclesId', 'comboBoxName':'productionCyclesId',
             'mappings':{'id':'id','description':'description','selectedItem':'-1'}, 'async':false
         }
         applicationLib.initComboByUrl(options);
    }

    //

    function initCombosRealReportYears(){
        cleanCombo('realReportYear');
        addComboItem("realReportYear","-- Select an Option --",-1);

        for(var i=2006;i<=new Date().getFullYear();i++){
            addComboItem("realReportYear",i,i);
        }

          $(document).on("change",'#realReportYear', function() {
              resetMonthsAndDays();
          });
    }

    function initCombosMonths(){
        cleanCombo('realReportStartMonth');
        addComboItem("realReportStartMonth","-- Select an Option --",-1);

        for(var i=0;i<MONTHS.length;i++){
            addComboItem("realReportStartMonth",MONTHS[i],(i+1));
        }
    }

    function initChangeMonth(){
          $(document).on("change",'#realReportStartMonth', function() {
              var leapYear = isLeapYear($("#realReportYear").val(),$("#realReportYear").val());
              loadDaysOfTheMonth($('#realReportStartMonth').val(),'realReportStartDay',leapYear);
          });

    }

    function resetMonthsAndDays() {
           $("#realReportStartDay").val("-1");
           $("#realReportStartMonth").val("-1");

           cleanCombo("realReportStartDay");
           addComboItem("realReportStartDay","-- Select an Option --",-1);


       }



    function initComboStationOwner(){
         var options = {
             'url':s.baseUrl + '/catalog/meteoroStationOwnerBase/loadCollection.do' , 'params':{},
             'sourceScript':'#comboBoxTemplate', 'container':'#containerStationOwner',
             'comboBoxId':'realReportMetStationOwnerId', 'comboBoxName':'realReportMetStationOwnerId',
             'mappings':{'id':'id','description':'description','selectedItem':'-1'}, 'async':false
         }

         $(document).on("change",'#realReportMetStationOwnerId', function() {
            loadComboMeteorologicalStation($('#ownerId').val());
        });

         applicationLib.initComboByUrl(options);
    }

    function loadComboMeteorologicalStation(selectedItem){
        var ownerId = ($('#realReportMetStationOwnerId').val()!=null && $('#realReportMetStationOwnerId').val()!=undefined )? $('#realReportMetStationOwnerId').val() : "-1";
         var options = {
             'url':s.baseUrl + '/catalog/meteoroStationBase/loadCollectionByOwner.do' , 'params':{'ownerId':ownerId},
             'sourceScript':'#comboBoxTemplate', 'container':'#containerMetStation',
             'comboBoxId':'realReportMetStationId', 'comboBoxName':'realReportMetStationId',
             'mappings':{'id':'id','description':'description','selectedItem':selectedItem}, 'async':false
         }

        $(document).on("change",'#realReportMetStationId', function() {
            $('#showDataChartBtn').attr('disabled',false);
        });


         applicationLib.initComboByUrl(options);
    }


    function initComboCropTypes(idCropType){
         var options = {
             'url':s.baseUrl + '/catalog/cropTypeBase/loadCollection.do' , 'params':{},
             'sourceScript':'#comboBoxTemplate', 'container':'#containerCropType',
             'comboBoxId':'realReportCropType', 'comboBoxName':'realReportCropType',
             'mappings':{'id':'id','description':'description','selectedItem':idCropType}, 'async':false
         }
         applicationLib.initComboByUrl(options);

          $(document).on("change",'#realReportCropType', function() {
              $('#realReportTempMin').val('');
              $('#realReportTempMax').val('');
              cleanSpecificField("realReportCrop");
              $('#showDataChartBtn').attr('disabled',true);
              $('#exportBtn').attr('disabled',true);

              loadComboCrop($('#realReportCropType').val(),'-1');
          });
    }

     function loadComboCrop(cropTypeId,cropId){
         var options = {
             'url':s.baseUrl + '/catalog/cropBase/loadCollectionByParent.do' , 'params':{'cropTypeId':cropTypeId},
             'sourceScript':'#comboBoxTemplate', 'container':'#containerCrop',
             'comboBoxId':'realReportCrop', 'comboBoxName':'realReportCrop',
             'mappings':{'id':'id','description':'description','selectedItem':cropId}, 'async':false
         }
         applicationLib.initComboByUrl(options);

          $(document).on("change",'#realReportCrop', function() {
              $('#showDataChartBtn').attr('disabled',true);
              $('#exportBtn').attr('disabled',true);
              showHideProcessScreen(true);
              loadBaseTemperatures($('#realReportCropType').val(),$('#realReportCrop').val());
              $("#cropName").val($("#realReportCrop option:selected").text());
          });
    }

    function getFilters(){
        var filters = "type="+$("#sourceCode").val()+"&";
                  filters = filters + "realReportCropType="+$("#realReportCropType").val()+"&";
                  filters = filters + "realReportTempMax="+$("#realReportTempMax").val()+"&";
                  filters = filters + "realReportTempMin="+$("#realReportTempMin").val()+"&";
                  filters = filters + "realReportCrop="+$("#realReportCrop").val();
        return  filters;
    }

     function loadBaseTemperatures(cropTypeId,cropId){
        var cropType = cropTypeId < 0 ? null : cropTypeId;
        var crop = cropId < 0 ? null : cropId;

        $.ajax( {"url": s.baseUrl+"/catalog/temperatureBase/search.do",
            "dataType":'json',
            "data":{'cropTypeId':cropType,'cropId':crop,'tempMin':'','tempMax':'','activeStatus':true},
            "success":function(response,status ,xhr) {

                if(!response.success&&response.success===false){
                      hideAllAlertsAndProcessScreen();
                      showAlert(response.messages,MONSANTO_STATIC_VARIABLE_ERROR);
                      cleanFrom();
                 }else{

                    if(response.content.length>0){
                        $("#realReportTempMax").val(response.content[0].tempmax);
                        $("#realReportTempMin").val(response.content[0].tempmin);

                        cleanSpecificField('realReportCrop');

                        $("#dataForm").attr("action", "initWithCrop.do?"+getFilters());
                        $("#dataForm").submit();
                    }else{
                        $("#realReportTempMax").val('');
                        $("#realReportTempMin").val('');
                        $("#cropStagesDesc").html('');
                        setErrorSpecificField('realReportCrop','The temp min and max are invalid');
                        disableAllActionBtns();
                        showHideProcessScreen(false);
                    }


                }
            },
            "error":function(xhr, status, error) {
                hideAllAlertsAndProcessScreen();
                showAlert([error],MONSANTO_STATIC_VARIABLE_ERROR);
                cleanFrom();
            }
        });

    }
    //



    function initData(){

      $('#hybridId').val('-1');
      $('#deleteBtn').attr('disabled',true);
      $('#showDataChartBtn').attr('disabled',true);
      $('#exportBtn').attr('disabled',true);
      $('#sourceCode').val(QueryString.type);

      $("#realReportTempMax").val(QueryString.realReportTempMax!=null && QueryString.realReportTempMax!="" ? QueryString.realReportTempMax : "-1");
      $("#realReportTempMin").val(QueryString.realReportTempMin!=null && QueryString.realReportTempMin!="" ? QueryString.realReportTempMin : "-1");

      if($("#cropStageLoadError").html()=="No Crop Stages were found"){
           disableAllActionBtns();

      }


    }

    function disableAllActionBtns(){
         $('#deleteBtn').attr('disabled',true);
         $('#searchBtn').attr('disabled',true);
         $('#saveBtn').attr('disabled',true);

    }

    function initBtnCleanDataChart(){
        $(document).on("click",'#cleanDataChartBtn', function() {
             cleanChartForm();
         });

    }

    function initBtnClean(){

         $(document).on("click",'#cleanBtn', function() {
             showHideProcessScreen(true);
             window.location = s.baseUrl+"/production/strewRecommendationBase/init.do?type=8645132132";
         });
    }

    function validateFieldsForChartData(){
        var errFound = false;
                 errFound = validateForm(errFound,'realReportYear',VALIDATE_COMBO_REAL_REPORT_YEAR);
                 errFound = validateForm(errFound,'realReportStartDay',VALIDATE_COMBO_REAL_START_DAY);
                 errFound = validateForm(errFound,'realReportStartMonth',VALIDATE_COMBO_REAL_START_MONTH);
                 errFound = validateForm(errFound,'realReportMetStationOwnerId',VALIDATE_COMBO_REAL_MET_ST_OWNER);
                 errFound = validateForm(errFound,'realReportMetStationId',VALIDATE_COMBO_REAL_MET_ST);
                 errFound = validateForm(errFound,'realReportCropType',VALIDATE_COMBO_REAL_CROP_TYPE);
                 errFound = validateForm(errFound,'realReportCrop',VALIDATE_COMBO_REAL_CROP);

        return errFound;

    }

     function initShowDataChartBtn(){

         $(document).on("click",'#showDataChartBtn', function() {
             var errFound = validateFieldsForChartData();

             if(!errFound){
                showAlert(['The data is about to be loaded, do you want to proceed?'],MONSANTO_STATIC_VARIABLE_NOTIFICATION,drawTableRealReport)
             }
         });
    }
    function initRealReportDataTable(){
        $("#chart2").html('');
        $('#tabs').tabs( "option", "active", 1 );

       var tableInfo2= $('#'+REAL_REPORT_DATA_TABLE).dataTable( {
             "bJQueryUI": true,
            "bProcessing": true,
            "bServerSide": true,
            "bLengthChange": 10,
            "sAjaxSource" : s.baseUrl+"/production/strewRecommendationBase/getRealReport.do",
            "sScrollX": "100%",
            "sScrollY": "200px",
            "bPaginate": false,
            "aaSorting": [[ 0, "asc" ]],
            "aoColumns": [
                 { "mDataProp":  function ( source, type, val ) {
                     var currentDate = "" + source.day<9?("0"+source.day)+"/":source.day + "/";
                     currentDate+= source.month<9?("0"+source.month+"/"):source.month+"/";
                     currentDate+="" +  source.year;

                    return  currentDate;
                },"bSortable": false,"sWidth": "30%" },
                { "mDataProp":  function ( source, type, val ) {
                   if($("#temperatureIn").val()=="C"){
                        return source.tempMinC;
                   }else{
                        return source.tempMinF;
                   }
                },"bSortable": false,"sWidth": "30%" },
                { "mDataProp":  function ( source, type, val ) {
                    if($("#temperatureIn").val()=="C"){
                        return source.tempMaxC;
                    }else{
                        return source.tempMaxF;
                    }
                },"bSortable": false,"sWidth": "30%" },
                  { "mDataProp": "dailyGdu","sWidth": "20%","bSortable":false},
                  { "mDataProp": "acumGdu","sWidth": "20%","bSortable":false}
            ],
           "bAutoWidth": false,
            "fnServerData": function ( sSource, aoData, fnCallback ) {
                $.merge(aoData,applicationLib.createSearchParams(searchParameters));
                hideAllAlertsAndProcessScreen();
                showHideProcessScreen(true);
                $.ajax( {"url":sSource,
                         "dataType":'json',
                         "data":aoData,
                    "success":function (response) {
                        if(!response.success&&response.success===false){
                            var json={};
                            json.aaData= {};
                            json.iTotalDisplayRecords=0;
                            json.iTotalRecords=0;
                            fnCallback(json);
                            hideAllAlertsAndProcessScreen();
                            $('#exportBtn').attr('disabled',true);
                            showAlert(response.messages,MONSANTO_STATIC_VARIABLE_ERROR);
                        }else{
                            hideAllAlertsAndProcessScreen();
                            $("#chart2").html('');
                            $('#tabs').tabs( "option", "active", 1 );
                            var json={};
                            json.aaData= response;
                            json.iTotalDisplayRecords=response.length;
                            json.iTotalRecords=response.length;
                            createCropStageTimeGDUChart(response);
                            if(response.length>0){
                                $('#exportBtn').attr('disabled',false);
                            }else{
                                $('#exportBtn').attr('disabled',true);
                            }

                            fnCallback(json);
                        }

                    },
                    "error":function(xhr, status, error) {
                        hideAllAlertsAndProcessScreen();
                        showAlert(["Application Error, Try Again:"+error],MONSANTO_STATIC_VARIABLE_ERROR);
                    }
                });
            }
        });

    }

    function drawTableRealReport(){
        $("#chart2").html('');
        $('#tabs').tabs( "option", "active", 1 );

        if(initRealReportTable){
            initRealReportDataTable();
            initRealReportTable = false;
        }else{
            $('#'+REAL_REPORT_DATA_TABLE).dataTable().fnDraw();
        }

    }

    function initBtnSaveOrUpdate(){

         $(document).on("click",'#saveBtn', function() {
             var errFound = false;
                 errFound = validateForm(errFound,'productionZoneId',VALIDATE_COMBO_PRODUCTION_ZONE);
                 errFound = validateForm(errFound,'productionCyclesId',VALIDATE_COMBO_PRODUCTION_CYCLES);
                 errFound = validateForm(errFound,'hybridDescription',VALIDATE_HYBRID_DESC);
                 errFound = validateForm(errFound,'realReportCropType',VALIDATE_COMBO_REAL_CROP_TYPE);
                 errFound = validateForm(errFound,'realReportCrop',VALIDATE_COMBO_REAL_CROP);

             if(!errFound){
                 errFound = validateForm(errFound,'hybridId@1',VALIDATE_HYBRID_MIN_VAL);
             }

             errFound = validateDynamicFields(errFound);

             if(!errFound){
                showAlert(['The Registry is about to be saved, do you want to proceed?'],MONSANTO_STATIC_VARIABLE_NOTIFICATION,saveCallback)
             }
         });
    }

    function initBtnSearch(){

         $(document).on("click",'#searchBtn', function() {
             cleanErrors(FIELDS_TO_CLEAN);
             var errFound =  validateForm(errFound,'realReportCrop',VALIDATE_COMBO_REAL_CROP);
             if(!errFound){
                 drawTable();
             }
         });
    }

    function initBtnDelete(){

         $(document).on("click",'#deleteBtn', function() {
             showAlert(['The Registry is about to be deleted, do you want to proceed?'],MONSANTO_STATIC_VARIABLE_WARNING,deleteCallback)
         });

    }

    function drawTable(){
        $('#strewRecommendationId').val('');
        $('#saveBtn').val('Save');
        $('#deleteBtn').attr('disabled',true);

        $('#'+MAIN_DATA_TABLE).dataTable().fnDraw();

    }

    function saveCallback(){
         hideShowAlertBox(false);
         showHideProcessScreen(true);
         var optionsForm = {
                  dataType:  'json',
                  "success":function(response, statusText, xhr) {
                    if (response.success) {
                        showHideProcessScreen(false);
                        showAlert(response.messages,MONSANTO_STATIC_VARIABLE_SUCCESS,drawTable);

                    }else{
                        hideAllAlertsAndProcessScreen();
                        showAlert(response.messages,MONSANTO_STATIC_VARIABLE_ERROR);

                    }
                  },
                  "error":function(xhr, status, error) {
                      hideAllAlertsAndProcessScreen();
                      showAlert([error],MONSANTO_STATIC_VARIABLE_ERROR);
                  }
              };

              $('#dataForm').ajaxForm(optionsForm);
              $('#dataForm').submit();

    }

    function deleteCallback(){
         hideShowAlertBox(false);
         showHideProcessScreen(true);

         $.ajax( {"url": s.baseUrl+"/production/strewRecommendationBase/delete.do",
            "dataType":'json',
            "data":{ id:$('#strewRecommendationId').val()},
            "success":function(response,status ,xhr) {
                 if(!response.success&&response.success===false){
                      hideAllAlertsAndProcessScreen();
                      showAlert(response.messages,MONSANTO_STATIC_VARIABLE_ERROR);
                 }else{
                    cleanFrom();
                    showHideProcessScreen(false);
                    showAlert(response.messages,MONSANTO_STATIC_VARIABLE_SUCCESS,drawTable);
                 }
            },
            "error":function(xhr, status, error) {
                hideAllAlertsAndProcessScreen();
                showAlert([error],MONSANTO_STATIC_VARIABLE_ERROR);
            }
        });

    }

    function initDataTable(){

       var tableInfo= $('#'+MAIN_DATA_TABLE).dataTable( {
             "bJQueryUI": true,
            "bProcessing": true,
            "bServerSide": true,
            "bLengthChange": 10,
            "sAjaxSource" : s.baseUrl+"/production/strewRecommendationBase/search.do",
            "sScrollX": "100%",
            "bPaginate": true,
            "aaSorting": [[ 0, "asc" ]],
            "aoColumns": [
                  { "mDataProp": "id","sWidth": "10%"},
                  { "mDataProp": "productionZone.description","sWidth": "16%"},
                  { "mDataProp": "productionCycles.description","sWidth": "17%"},
                  { "mDataProp": "hybrid.description","sWidth": "17%"},
                  { "mDataProp":  function ( source, type, val ) {
                     var table ="<table width='100%' border='0' cellspacing='0' cellpadding='0'><tr><td ><table width='100%' border='1' cellspacing='5' cellpadding='5'><tr>";
                     var tableContent ="<table width='100%' border='1' cellspacing='0' cellpadding='0'>";

                      tableContent += "<tr>";
                      for(var i=0;i<source.detailForJson.length;i++){
                          tableContent += "<td bgcolor='#CCCCCC'>"+source.detailForJson[i].cropStage.description +"</td>";

                      }
                      tableContent += "</tr><tr>";

                      for(var i=0;i<source.detailForJson.length;i++){
                          tableContent += "<td bgcolor='#FFFFFF'>"+ source.detailForJson[i].cropStageValue+"</td>";
                      }
                      tableContent += "</tr></table>";
                      table += tableContent+ "</tr></table></td></tr></table>";

                    return  table;
                },"bSortable": false,"sWidth": "40%" }
            ],
            "bPaginate": true,
            "bFilter": true,
            "sPaginationType": "full_numbers",
            "bAutoWidth": false,
            "fnServerData": function ( sSource, aoData, fnCallback ) {
                $.merge(aoData,applicationLib.createSearchParams(searchParameters));
                hideAllAlertsAndProcessScreen();
                showHideProcessScreen(true);
                $.ajax( {"url":sSource,
                         "dataType":'json',
                         "data":aoData,
                    "success":function (response) {
                        if(!response.success&&response.success===false){
                            var json={};
                            json.aaData= {};
                            json.iTotalDisplayRecords=0;
                            json.iTotalRecords=response.totalElements;
                            fnCallback(json);
                            hideAllAlertsAndProcessScreen();
                            showAlert(response.messages,MONSANTO_STATIC_VARIABLE_ERROR);
                        }else{
                            hideAllAlertsAndProcessScreen();
                            var json={};
                            json.aaData= response.content;
                            json.iTotalDisplayRecords=response.totalElements;
                            json.iTotalRecords=response.totalElements;
                            fnCallback(json);

                        }

                    },
                    "error":function(xhr, status, error) {
                        hideAllAlertsAndProcessScreen();
                        showAlert(["Application Error, Try Again:"+error],MONSANTO_STATIC_VARIABLE_ERROR);
                    }
                });
            },"fnRowCallback": function(nRow, aData, iDisplayIndex) {
            $(nRow).click(function() {
                showHideProcessScreen(true);
                cleanFrom();
                $.ajax( {"url": s.baseUrl+"/production/strewRecommendationBase/findById.do",
                    "dataType":'json',
                    "data":{ id:aData.id},
                    "success":function(entity,status ,xhr) {


                        $('#strewRecommendationId').val(entity.id);
                        $('#productionZoneId').val(entity.productionZone.id);
                        $('#productionCyclesId').val(entity.productionCycles.id);
                        $('#hybridDescription').val(entity.hybrid.description);
                        $('#hybridId').val(entity.hybrid.id);
                        $('#realReportCropType').val(entity.detailForJson[0].cropStage.crop.type.id);
                        loadComboCrop(entity.detailForJson[0].cropStage.crop.type.id,entity.detailForJson[0].cropStage.crop.id)


                         cropStageGDUInfo = new Array();
                         var currentStage = new Array();

                        var realCropData = "";
                        $('#realReportCropStageData').val('');

                         for(var i=0;i<entity.detailForJson.length;i++){
                             $("#cropStageDetail-"+entity.detailForJson[i].cropStage.id).val(entity.detailForJson[i].cropStageValue);

                             currentStage = new Array();
                             currentStage.push(entity.detailForJson[i].cropStage.description);
                             currentStage.push(entity.detailForJson[i].cropStageValue);

                             cropStageGDUInfo.push(currentStage);

                             realCropData+="\""+entity.detailForJson[i].cropStage.id+"-"+entity.detailForJson[i].cropStageValue+"\",";
                         }
                         realCropData = realCropData.substring(0,realCropData.length-1);

                        $('#realReportCropStageData').val(realCropData);
                        $('#saveBtn').val('Modify');
                        $('#deleteBtn').attr('disabled',false);



                        applicationLib.hideShowElement('tabs',true);
                        createCropStageGDUChart();
                        showHideProcessScreen(false);
                    },
                    "error":function(xhr, status, error) {
                        hideAllAlertsAndProcessScreen();
                        showAlert([error],MONSANTO_STATIC_VARIABLE_ERROR);
                    }
                });

            });
        }
        });

    }

    function cleanFrom(){
        $('#productionZoneId').val('-1');
        $('#productionCyclesId').val('-1');
        $('#hybridId').val('-1');

        drawTable();
        cleanChartForm();

        cleanDynamicFields();
        $('#saveBtn').val('Save');
        cleanErrors(FIELDS_TO_CLEAN);
        cleanErrors(FIELDS_TO_CLEAN_B);

        applicationLib.hideShowElement('tabs',false);
     }

    function cleanChartForm(){
        $('#realReportYear').val('-1');
        $('#realReportStartDay').val('-1');
        $('#realReportStartMonth').val('-1');
        $('#realReportMetStationOwnerId').val('-1');
        $('#realReportMetStationId').val('-1');


        cleanCombo('realReportStartDay');
        addComboItem('realReportStartDay','-- Select an Option --','-1');

        cleanCombo('realReportMetStationId');
        addComboItem('realReportMetStationId','-- Select an Option --','-1');

        cleanErrors(FIELDS_TO_CLEAN_B);

        $('#showDataChartBtn').attr('disabled',true);

        if(!initRealReportTable){
            drawTableRealReport();
        }


    }

    function cleanDynamicFields() {
        var elements = document.getElementsByTagName("input");
        for (var ii = 0; ii < elements.length; ii++) {
            if (elements[ii].type == "text") {
                elements[ii].value = "";
            }
        }
    }

     function validateDynamicFields(errFound) {
        var elements = document.getElementsByTagName("input");

        for (var ii = 0; ii < elements.length; ii++) {
            if (elements[ii].type == "text" && elements[ii].name != 'hybridDescription') {
                try{
                    errFound = validateForm(errFound,elements[ii].name,VALIDATE_DYNAMIC_FIELDS);
                }catch(error){}

            }
        }

         return errFound;
    }


    var hybridObj;
    var hybridLabels;

    var queryTimer;
	var QUERY_DELAY=1000;

     function initHybridSearch(){


          $( "#hybridDescription"         ).typeahead({
            source:  function ( query, process) {

                hybridObj ={};
                hybridLabels = [];

				clearTimeout(  queryTimer );
				queryTimer = setTimeout( function(){ findHybridMatchesTypeHead( query,process ); }, QUERY_DELAY );
            },
            updater: function( label ){

                return fillHybridAndIdField(  hybridObj[label] );
            },
			matcher: function(){ return true; }
        });
     }

     function findHybridMatchesTypeHead( query, process ){
         var cropTypeId = $("#realReportCropType").val();
         var cropId = $("#realReportCrop").val();
        $.ajax({
            url      : s.baseUrl+"/catalog/hybridBase/findDynamicList.do",
            dataType : "json",
            data     : { match: query, "cropTypeId":cropTypeId,"cropId":cropId},
            success  : function( data ) {
                if( data.length == 0 ){
                    hybridLabels.push( "---No Data found---" );
                    $('#hybridId').val('-1');
                }
                $.each( data, function ( i, obj ) {

                    var label = obj.description;

                    hybridObj[label] = obj;
                    hybridLabels.push( label )

                });
                process( hybridLabels );

            },
            error    : function( xhr, status, error ) {alert(error) }
        });
     }

     function fillHybridAndIdField( hybridObj ){
        if( hybridObj != null ){

            $( "#hybridDescription" ).val( hybridObj.description );
            $( "#hybridId" ).val( hybridObj.id );

            return  hybridObj.description;
        }
     }

    function createCropStageTimeGDUChart(content){
        $("#chart2").html('');
        $('#tabs').tabs( "option", "active", 1 );
        var cropStageTimeGDUInfo = new Array();
        var currentStageDate = null;

        if(content.length>0){
            for(var i=0;i<content.length;i++){
            currentStageDate = new Array();

            if(content[i].cropStageName!=null && content[i].cropStageName!='null' && content[i].cropStageName.length>0){
                var currentDate = content[i].day+"/"+ content[i].month +"/"+content[i].year;
                var currentCropStage = " [ "+content[i].cropStageName+" ] ";

                currentStageDate.push(currentDate+currentCropStage);
                currentStageDate.push(content[i].acumGdu);

                cropStageTimeGDUInfo.push(currentStageDate)

            }

        }

         $.jqplot.config.enablePlugins = true;
            var plot2 = $.jqplot('chart2', [cropStageTimeGDUInfo], {
              title: 'Station'+ $("#realReportMetStationId option:selected").text()+' - Date [Crop Stage]',
              axes: {
                xaxis: {
                  renderer: $.jqplot.CategoryAxisRenderer,
                  label: "Date / Crop Stage",
                  labelRenderer: $.jqplot.CanvasAxisLabelRenderer,
                  tickRenderer: $.jqplot.CanvasAxisTickRenderer,
                  tickOptions: {
                      // labelPosition: 'middle',
                      angle: 15
                  }

                },
                yaxis: {
                  label: 'Data',
                  labelRenderer: $.jqplot.CanvasAxisLabelRenderer
                }
              },
                highlighter: {
                            sizeAdjust: 10,
                            tooltipLocation: 'n',
                            tooltipAxes: 'y',
                            tooltipFormatString: '<b><i><span style="color:blue;">GDUs:</span></i></b> %.2f',
                            useAxesFormatters: false
                },     cursor: {         show: true     },
                series: [
                    {label: 'Date VS Crop Stage'}
                ],legend: {show: true,placement: 'outside'}
            });

        }


    }

    function createCropStageGDUChart(){
        $("#chart1").html('');
        $('#tabs').tabs( "option", "active", 0 );
         $.jqplot.config.enablePlugins = true;
            var plot2 = $.jqplot('chart1', [cropStageGDUInfo], {
              title: 'Crop Stage VS GDUs',
              axes: {
                xaxis: {
                  renderer: $.jqplot.CategoryAxisRenderer,
                  label: 'Crop Stage',
                  labelRenderer: $.jqplot.CanvasAxisLabelRenderer,
                  tickRenderer: $.jqplot.CanvasAxisTickRenderer,
                  tickOptions: {
                      // labelPosition: 'middle',
                      angle: 15
                  }

                },
                yaxis: {
                  label: 'GDU',
                  labelRenderer: $.jqplot.CanvasAxisLabelRenderer
                }
              },
                highlighter: {
                            sizeAdjust: 10,
                            tooltipLocation: 'n',
                            tooltipAxes: 'y',
                            tooltipFormatString: '<b><i><span style="color:blue;">GDUs:</span></i></b> %.2f',
                            useAxesFormatters: false
                },     cursor: {         show: true     },
                series: [
                    {label: 'Data'},
                    {label: 'Wind Speed.Max'}
                ],legend: {show: true,placement: 'outside'}
            });

    }


     $(document).ready(function() {
         loadPage();
         applicationLib.hideShowElement('tabs',false);
     });
})(jQuery,application);