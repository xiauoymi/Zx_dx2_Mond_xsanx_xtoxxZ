(function ($,s) {

    var MAIN_DATA_TABLE = "dataTable_generalReport";

      var searchParameters=[
          { id: 'yearIni', container: '#yearIni', property: 'yearIni', searchValue: '' },
          { id: 'yearEnd', container: '#yearEnd', property: 'yearEnd', searchValue: '' },
          { id: 'monthIni', container: '#monthIni', property: 'monthIni', searchValue: '' },
          { id: 'monthEnd', container: '#monthEnd', property: 'monthEnd', searchValue: '' },
          { id: 'dayIni', container: '#dayIni', property: 'dayIni', searchValue: '' },
          { id: 'dayEnd', container: '#dayEnd', property: 'dayEnd', searchValue: '' },
          { id: 'meteorologicalStationId', container: '#meteorologicalStationId', property: 'meteorologicalStationId', searchValue: '' },
          { id: 'meteorologicalStationDesc', container: '#meteorologicalStationDesc', property: 'meteorologicalStationDesc', searchValue: '' },
          { id: 'tempMax', container: '#tempMax', property: 'tempMax', searchValue: '' },
          { id: 'tempMin', container: '#tempMin', property: 'tempMin', searchValue: '' },
          { id: 'cropType', container: '#cropType', property: 'cropType', searchValue: '' },
          { id: 'cropId', container: '#cropId', property: 'cropId', searchValue: '' },
          { id: 'cropName', container: '#cropName', property: 'cropName', searchValue: '' },
          { id: 'tempAbove', container: '#tempAbove', property: 'tempAbove', searchValue: '' },
          { id: 'tempUnder', container: '#tempUnder', property: 'tempUnder', searchValue: '' }
      ];

    function loadPage(){

     initDataTable();

      initBtnSearch();

      initBtnClean();
      initBtnExport();
      initComboStationOwner();

      initComboCropTypes();
      loadComboMeteorologicalStation("-1");
      loadComboCrop('-1','-1');

      initCombosMonths();
      initCombosYears();
      initChangeMonthIni();
      initChangeMonthEnd();
      initMeteorologicalStationChange();


      onChangeTemperatureIn();
      onChangeTempUnderOrAbove();

      $("#exportBtn").attr("disabled",true);
      $("#searchBtn").attr("disabled",true);

    }

    function onChangeTemperatureIn() {
        $(document).on("change", '#temperatureIn', function() {
            if($("#temperatureIn").val()=="C"){
                $("#tempMaxLabelTable").html("(&ordm;C)");
                $("#tempMinLabelTable").html("(&ordm;C)");
                $("#tempUnderLabelTable").html("(&ordm;C)");
                $("#tempAboveLabelTable").html("(&ordm;C)");
            }else{
                $("#tempMaxLabelTable").html("(F)");
                $("#tempMinLabelTable").html("(F)");
                $("#tempUnderLabelTable").html("(F)");
                $("#tempAboveLabelTable").html("(F)");
            }

            onChangeUpdateTempUnderOrAbove("tempUnder","tempMin","tempUnderLabelTable");
            onChangeUpdateTempUnderOrAbove("tempAbove","tempMax","tempAboveLabelTable");

        });
    }

    function onChangeTempUnderOrAbove() {
        $(document).on("change", '#tempUnder', function() {
            onChangeUpdateTempUnderOrAbove("tempUnder","tempMin","tempUnderLabelTable");
       });
         $(document).on("change", '#tempAbove', function() {
            onChangeUpdateTempUnderOrAbove("tempAbove","tempMax","tempAboveLabelTable");

       });
    }

    function onChangeUpdateTempUnderOrAbove(id,temMinMaxId,tableLabel) {

        if (!isNaN(Number($("#"+id).val())) && $("#"+id).val() != "") {
            if ($("#temperatureIn").val() == "C") {
                $("#"+tableLabel).html("   " + $("#"+id).val() + "(&ordm;C)");
                return "   " + $("#"+id).val() + "(&ordm;C)";
            } else {
                $("#"+tableLabel).html("   " + celsiusToFahrenheit($("#"+id).val()) + "(F)");
                return "   " + celsiusToFahrenheit($("#"+id).val()) + "(F)";
            }
        } else {
            if ($("#temperatureIn").val() == "C") {
                $("#"+tableLabel).html("   " + $("#"+temMinMaxId).val() + "(&ordm;C)");
                return "   " + $("#"+temMinMaxId).val() + "(&ordm;C)";
            } else {
                $("#"+tableLabel).html("   " + celsiusToFahrenheit($("#"+temMinMaxId).val()) + "(F)");
                return "   " + celsiusToFahrenheit($("#"+temMinMaxId).val()) + "(F)";
            }
        }

    }


    function initComboCropTypes(){
         var options = {
             'url':s.baseUrl + '/catalog/cropTypeBase/loadCollection.do' , 'params':{},
             'sourceScript':'#comboBoxTemplate', 'container':'#containerCropType',
             'comboBoxId':'cropType', 'comboBoxName':'cropType',
             'mappings':{'id':'id','description':'description','selectedItem':'-1'}, 'async':false
         }
         applicationLib.initComboByUrl(options);

          $(document).on("change",'#cropType', function() {
              $('#tempMin').val('');
              $('#tempMax').val('');
              cleanSpecificField("cropId");
              loadComboCrop($('#cropType').val(),'-1');
          });
    }

     function loadComboCrop(cropTypeId,cropId){
         var options = {
             'url':s.baseUrl + '/catalog/cropBase/loadCollectionByParent.do' , 'params':{'cropTypeId':cropTypeId},
             'sourceScript':'#comboBoxTemplate', 'container':'#containerCropId',
             'comboBoxId':'cropId', 'comboBoxName':'cropId',
             'mappings':{'id':'id','description':'description','selectedItem':cropId}, 'async':false
         }
         applicationLib.initComboByUrl(options);

          $(document).on("change",'#cropId', function() {

              $("#exportBtn").attr("disabled",true);
              $("#searchBtn").attr("disabled",true);

              loadBaseTemperatures($('#cropType').val(),$('#cropId').val());
              $("#cropName").val($("#cropId option:selected").text());

          });
    }

    function initMeteorologicalStationChange(){
         $(document).on("change",'#meteorologicalStationId', function() {
              $("#meteorologicalStationDesc").val($("#meteorologicalStationId option:selected").text());
          });
    }

    function loadBaseTemperatures(cropTypeId,cropId){
        var cropType = cropTypeId < 0 ? null : cropTypeId;
        var crop = cropId < 0 ? null : cropId;

        $.ajax( {"url": s.baseUrl+"/catalog/temperatureBase/search.do",
            "dataType":'json',
            "data":{'cropTypeId':cropType,'cropId':crop,'tempMin':'','tempMax':'','activeStatus':true},
            "success":function(response,status ,xhr) {

                if(!response.success&&response.success===false){
                      hideAllAlertsAndProcessScreen();
                      showAlert(response.messages,MONSANTO_STATIC_VARIABLE_ERROR);
                      cleanFrom();
                 }else{

                    if(response.content.length>0){
                        $("#tempMax").val(response.content[0].tempmax);
                        $("#tempMin").val(response.content[0].tempmin);


                       if($("#temperatureIn").val()=="C"){
                         $("#tempUnderLabelTable").html("   "+response.content[0].tempmin+"(&ordm;C)");
                         $("#tempAboveLabelTable").html("   "+response.content[0].tempmax+"(&ordm;C)");
                       }else{
                           $("#tempUnderLabelTable").html("   "+celsiusToFahrenheit(response.content[0].tempmin)+" (F)");
                           $("#tempAboveLabelTable").html("   "+celsiusToFahrenheit(response.content[0].tempmax)+" (F)");
                       }
                        $("#exportBtn").attr("disabled",false);
                        $("#searchBtn").attr("disabled",false);

                    }else{
                        $("#tempMax").val('');
                        $("#tempMin").val('');
                        $("#exportBtn").attr("disabled",true);
                        $("#searchBtn").attr("disabled",true);
                    }


                }
            },
            "error":function(xhr, status, error) {
                hideAllAlertsAndProcessScreen();
                showAlert([error],MONSANTO_STATIC_VARIABLE_ERROR);
                cleanFrom();
            }
        });

    }


    function initComboStationOwner(){
         var options = {
             'url':s.baseUrl + '/catalog/meteoroStationOwnerBase/loadCollection.do' , 'params':{},
             'sourceScript':'#comboBoxTemplate', 'container':'#containerMeteorologicalStationOwner',
             'comboBoxId':'metStationOwnerId', 'comboBoxName':'metStationOwnerId',
             'mappings':{'id':'id','description':'description','selectedItem':'-1'}, 'async':false
         }

         $(document).on("change",'#metStationOwnerId', function() {
            loadComboMeteorologicalStation($('#metStationOwnerId').val());
        });

         applicationLib.initComboByUrl(options);
    }

    function loadComboMeteorologicalStation(selectedItem){
        var ownerId = ($('#metStationOwnerId').val()!=null && $('#metStationOwnerId').val()!=undefined )? $('#metStationOwnerId').val() : "-1";
         var options = {
             'url':s.baseUrl + '/catalog/meteoroStationBase/loadCollectionByOwner.do' , 'params':{'ownerId':ownerId},
             'sourceScript':'#comboBoxTemplate', 'container':'#containerMeteorologicalStation',
             'comboBoxId':'meteorologicalStationId', 'comboBoxName':'meteorologicalStationId',
             'mappings':{'id':'id','description':'description','selectedItem':selectedItem}, 'async':false
         }
         applicationLib.initComboByUrl(options);
    }


    function initBtnClean(){

         $(document).on("click",'#cleanBtn', function() {
             cleanFrom();
         });
    }


    function initBtnExport(){

         $(document).on("click",'#exportBtn', function() {

             if (!validateFields()) {
                 showAlert(['You are about to export these data to excel, do you want to proceed?'],MONSANTO_STATIC_VARIABLE_NOTIFICATION,callBackExportXLS)

             }

         });
    }

    function callBackExportXLS() {
        hideShowAlertBox(false);

        var filters = "initYear=" + $('#yearIni').val() + "&";
            filters = filters + "initMonth=" + $("#monthIni").val()+ "&";
            filters = filters + "initDay=" + $("#dayIni").val()+ "&";
            filters = filters + "endYear=" + $("#yearEnd").val()+ "&";
            filters = filters + "endMonth=" + $("#monthEnd").val()+ "&";
            filters = filters + "endDay=" + $("#dayEnd").val()+ "&";
            filters = filters + "meteorologicalStationDesc=" + $("#meteorologicalStationId option:selected").text()+ "&";
            filters = filters + "meteorologicalStationId=" + $("#meteorologicalStationId").val()+ "&";
            filters = filters + "tempMin=" + $("#tempMin").val()+ "&";
            filters = filters + "tempMax=" + $("#tempMax").val()+ "&";
            filters = filters + "cropName=" + $("#cropId option:selected").text()+ "&";

        if($("#tempUnder").val()!=null && $("#tempUnder").val()!=""){
            filters = filters + "tempUnder=" + $("#tempUnder").val()+ "&";
        }else{
            filters = filters + "tempUnder=" + $("#tempMin").val()+ "&";
        }

        if($("#tempAbove").val()!=null && $("#tempAbove").val()!=""){
            filters = filters + "tempAbove=" + $("#tempAbove").val()+ "&";
        }else{
            filters = filters + "tempAbove=" + $("#tempMax").val()+ "&";
        }

        filters = filters + "temperatureIn=" + $("#temperatureIn").val();



        window.location = s.baseUrl + "/production/reports/prGeneralReportBase/export.do?" + filters;


    }

    function initBtnSearch(){

         $(document).on("click",'#searchBtn', function() {

             cleanErrors(FIELDS_TO_CLEAN);
             if(!validateFields()){
                 drawTable();
             }
         });
    }

    function validateFields() {
        var errFound = false;
        errFound = validateForm(errFound, 'yearIni', VALIDATE_COMBO);
        errFound = validateForm(errFound, 'monthIni', VALIDATE_COMBO);
        errFound = validateForm(errFound, 'dayIni', VALIDATE_COMBO);
        errFound = validateForm(errFound, 'yearEnd', VALIDATE_COMBO);
        errFound = validateForm(errFound, 'monthEnd', VALIDATE_COMBO);
        errFound = validateForm(errFound, 'dayEnd', VALIDATE_COMBO);
        errFound = validateForm(errFound, 'metStationOwnerId', VALIDATE_COMBO);
        errFound = validateForm(errFound, 'meteorologicalStationId', VALIDATE_COMBO);
        errFound = validateForm(errFound, 'cropType', VALIDATE_COMBO);
        errFound = validateForm(errFound, 'cropId', VALIDATE_COMBO);
        errFound = validateForm(errFound, 'tempAbove', VALIDATE_INPUT_TEXT_TEMP_UNDER_ABOVE);
        errFound = validateForm(errFound, 'tempUnder', VALIDATE_INPUT_TEXT_TEMP_UNDER_ABOVE);
        errFound = validateForm(errFound,'yearIni@yearEnd',VALIDATE_COMBO_DATA);
        errFound = validateForm(errFound,'meteorologicalStationLongitude',VALIDATE_METEOROLOGICAL_LONGITUDE);
        errFound = validateForm(errFound,'meteorologicalStationLatitude',VALIDATE_METEOROLOGICAL_LATITUDE);



        if(document.getElementById("yearIni").value == document.getElementById("yearEnd").value){
            errFound = validateForm(errFound,'monthIni@monthEnd',VALIDATE_COMBO_DATA);
        }

         if(document.getElementById("yearIni").value == document.getElementById("yearEnd").value
             && document.getElementById("monthIni").value == document.getElementById("monthEnd").value){
            errFound = validateForm(errFound,'dayIni@dayEnd',VALIDATE_COMBO_DATA);
        }

        if (!errFound && ($('#tempMax').val() == "" || $('#tempMax').val() == null) && ($('#tempMin').val() == "" || $('#tempMin').val() == null)) {
            setErrorSpecificField("cropId", "Temp Min or Max are invalid for this crop, review them in the Base Temp Catalog");
            errFound = true;
        } else {
            if (!errFound) {
                document.getElementById("googleMapDiv").style.display ="none";
                cleanSpecificField("cropId");
            }

        }


        return errFound;

    }

    function drawTable(){

        $('#'+MAIN_DATA_TABLE).dataTable().fnDraw();

    }



    function initDataTable(){

       var tableInfo= $('#'+MAIN_DATA_TABLE).dataTable( {
             "bJQueryUI": true,
            "bProcessing": true,
            "bServerSide": true,
            "bLengthChange": 10,
            "sAjaxSource" : s.baseUrl+"/production/reports/prGeneralReportBase/search.do",
            "sScrollX": "100%",
            "aaSorting": [[ 0, "asc" ]],
            "sScrollY": "200px",
            "sScrollX": "100%",
             "bPaginate": false,
            "aoColumns": [
                  { "mDataProp": "dateStr","sWidth": "7.14%","sClass":"center"},
                  { "mDataProp":  function ( source, type, val ) {
                       if($("#temperatureIn").val()=="C"){
                            return source.tempMinC;
                       }else{
                            return source.tempMinF;
                       }
                  },"bSortable": false,"sWidth": "7.14%" },
                  { "mDataProp":  function ( source, type, val ) {
                       if($("#temperatureIn").val()=="C"){
                            return source.tempMaxC;
                       }else{
                            return source.tempMaxF;
                       }
                  },"bSortable": false,"sWidth": "6.66%" },
                  { "mDataProp": "gdus","sWidth": "6.66%","sClass":"center","bSortable": false},
                  { "mDataProp": "gduAcum","sWidth": "6.66%","sClass":"center","bSortable": false},
                  { "mDataProp": "dampMin","sWidth": "6.66%","sClass":"center","bSortable": false},
                  { "mDataProp": "dampMax","sWidth": "6.66%","sClass":"center","bSortable": false},
                  { "mDataProp": "periodsUnder","sWidth": "6.66%","sClass":"center","bSortable": false},
                  { "mDataProp": "periodsAbove","sWidth": "6.66%","sClass":"center","bSortable": false},
                  { "mDataProp": "precipitation","sWidth": "6.66%","sClass":"center","bSortable": false},
                  { "mDataProp": "evoTranspiration","sWidth": "6.66%","sClass":"center","bSortable": false},
                  { "mDataProp": "windSpeedMin","sWidth": "6.66%","sClass":"center","bSortable": false},
                  { "mDataProp": "windSpeedMax","sWidth": "6.66%","sClass":"center","bSortable": false},
                  { "mDataProp": "windAVGBetween7And17Hrs","sWidth": "6.66%","sClass":"center","bSortable": false},
                  { "mDataProp": "radiation","sWidth": "6.66%","sClass":"center","bSortable": false}
            ],

            "fnServerData": function ( sSource, aoData, fnCallback ) {
                $.merge(aoData,applicationLib.createSearchParams(searchParameters));
                hideAllAlertsAndProcessScreen();
                showHideProcessScreen(true);
                $.ajax( {"url":sSource,
                         "dataType":'json',
                         "data":aoData,
                    "success":function (response) {
                        if(!response.success&&response.success===false){
                            var json={};
                            json.aaData= {};
                            json.iTotalDisplayRecords=0;
                            json.iTotalRecords=response.totalElements;
                            fnCallback(json);
                            hideAllAlertsAndProcessScreen();

                            showAlert(response.messages,MONSANTO_STATIC_VARIABLE_ERROR);

                        }else{
                            hideAllAlertsAndProcessScreen();

                            try{

                               fillDataForMap(response.content);
                               fillDataForTempChart(response.content);
                               createTempMinMaxChart();
                               createDampMinMaxChart();
                               createWindSpeedMinMaxChart();
                            }catch(error){


                            }


                            var json={};
                            json.aaData= response.content;
                            json.iTotalDisplayRecords=response.totalElements;
                            json.iTotalRecords=response.totalElements;
                            fnCallback(json);

                        }

                    },
                    "error":function(xhr, status, error) {
                        hideAllAlertsAndProcessScreen();

                        showAlert(["Application Error, Try Again:"+error],MONSANTO_STATIC_VARIABLE_ERROR);
                    }
                });
            }
        });

    }

    var arrayTempMin = new Array();
    var arrayTempMax = new Array();

    var arrayDampMin = new Array();
    var arrayDampMax = new Array();

    var arrayWindSpeedMin = new Array();
    var arrayWindSpeedMax = new Array();
    var arrayGDUAcum = new Array();

    var arrayPeriodUnder = new Array();
    var arrayPeriodAbove = new Array();

    function fillDataForMap(content)  {
        $("#longitude").val(content[0].longitude);
        $("#latitude").val(content[0].latitude);

        $('#googleMapDiv').show();
        if( $("#longitude").val() != 'null' &&  $("#latitude").val() != 'null'){
            loadMap();

        }else{
            document.getElementById("googleMapDiv").style.display ="none";
            showAlert(['Map not available,Latitude and Longitude are zero'],MONSANTO_STATIC_VARIABLE_ERROR);
        }

    }


    function fillDataForTempChart(content) {
        arrayTempMin = new Array();
        arrayTempMax = new Array();
        arrayDampMin = new Array();
        arrayDampMax = new Array();
        arrayWindSpeedMin = new Array();
        arrayWindSpeedMax = new Array();
        arrayGDUAcum = new Array();
        arrayPeriodUnder = new Array();
        arrayPeriodAbove = new Array();

        for (var i = 0; i < content.length; i++) {
            if($("#temperatureIn").val()=="C"){
                arrayTempMin.push(addChartItem(content[i].dateStr,content[i].tempMinC));
                arrayTempMax.push(addChartItem(content[i].dateStr,content[i].tempMaxC));
            }else{
                arrayTempMin.push(addChartItem(content[i].dateStr,content[i].tempMinF));
                arrayTempMax.push(addChartItem(content[i].dateStr,content[i].tempMaxF));
            }
            arrayGDUAcum.push(addChartItem(content[i].dateStr,content[i].gdus))
            arrayDampMin.push(addChartItem(content[i].dateStr,content[i].dampMin));
            arrayDampMax.push(addChartItem(content[i].dateStr,content[i].dampMax));
            arrayWindSpeedMin.push(addChartItem(content[i].dateStr,content[i].windSpeedMax));
            arrayWindSpeedMax.push(addChartItem(content[i].dateStr,content[i].windSpeedMin));

            arrayPeriodUnder.push(addChartItem(content[i].dateStr,content[i].periodsUnder));
            arrayPeriodAbove.push(addChartItem(content[i].dateStr,content[i].periodsAbove));
        }


    }

    function addChartItem(date, value) {
        var arrayCurrentItem = new Array();
        var dateArr = date.split("-");

        arrayCurrentItem.push(dateArr[2]+"-"+dateArr[1]+"-"+dateArr[0]);
        arrayCurrentItem.push(value);

        return arrayCurrentItem;

    }


    function cleanFrom(){
        $('#metStationOwnerId').val('-1');
        $('#year').val('-1');

        $("#exportBtn").attr("disabled",true);
        $("#searchBtn").attr("disabled",true);

        cleanCombo('meteorologicalStationId')
        addComboItem("meteorologicalStationId", "-- Select an Option --","-1");

        $('#tempMin').val('');
        $('#tempMax').val('');

        $('#cropType').val('-1');
        cleanCombo('cropId')
        addComboItem("cropId", "-- Select an Option --","-1");

        drawTable();

        cleanErrors(FIELDS_TO_CLEAN);

     }

    function initCombosMonths(){

        addComboItem("monthIni","-- Select an Option --",-1);
        addComboItem("monthEnd","-- Select an Option --",-1);

        for(var i=0;i<MONTHS.length;i++){
            addComboItem("monthIni",MONTHS[i],(i+1));
            addComboItem("monthEnd",MONTHS[i],(i+1));
        }
    }

    function initChangeMonthIni() {
        $(document).on("change", '#monthIni', function() {
            var leapYear = isLeapYear($("#yearIni").val(),$("#yearIni").val());
            loadDaysOfTheMonth($('#monthIni').val(), 'dayIni',leapYear);
        });

    }

    function initChangeMonthEnd() {
        $(document).on("change", '#monthEnd', function() {
            var leapYear = isLeapYear($("#yearEnd").val(),$("#yearEnd").val());
            loadDaysOfTheMonth($('#monthEnd').val(), 'dayEnd',leapYear);
        });

    }

     function resetMonthsAndDays(idDay,idMonth) {
        $("#"+idDay).val("-1");
        $("#"+idMonth).val("-1");

        cleanCombo(idDay);
        addComboItem(idDay,"-- Select an Option --",-1);


    }

    function initCombosYears(){

        cleanCombo('yearIni');
        cleanCombo('yearEnd');

        addComboItem("yearIni","-- Select an Option --",-1);
        addComboItem("yearEnd","-- Select an Option --",-1);

        for(var i=2006;i<=new Date().getFullYear();i++){
            addComboItem("yearIni",i,i);
            addComboItem("yearEnd",i,i);
        }

        $(document).on("change", '#yearIni', function() {
            resetMonthsAndDays("dayIni","monthIni");
        });

        $(document).on("change", '#yearEnd', function() {
           resetMonthsAndDays("dayEnd","monthEnd");
        });
    }


    function getSampleForChart(selectedArray) {

        if (selectedArray.length > 30) {
            var temporalArray = new Array();

            var fullLength = selectedArray.length;
            var incrementValueBy = Math.floor((Math.floor(fullLength / 3)/10));

            var firstPosition = 0;
            var thirdOfTheArray = Math.floor(fullLength / 3);
            var firstThird = Math.floor(thirdOfTheArray);
            var secondThird = Math.floor(thirdOfTheArray*2);
            var lastThird = Math.floor(thirdOfTheArray*3)-1;


            temporalArray.push(selectedArray[firstPosition]);
            temporalArray.push(selectedArray[firstThird - (incrementValueBy*8)]);
            temporalArray.push(selectedArray[firstThird - (incrementValueBy*7)]);
            temporalArray.push(selectedArray[firstThird - (incrementValueBy*6)]);
            temporalArray.push(selectedArray[firstThird - (incrementValueBy*5)]);
            temporalArray.push(selectedArray[firstThird - (incrementValueBy*4)]);
            temporalArray.push(selectedArray[firstThird - (incrementValueBy*3)]);
            temporalArray.push(selectedArray[firstThird - (incrementValueBy*2)]);
            temporalArray.push(selectedArray[firstThird - incrementValueBy]);
            temporalArray.push(selectedArray[firstThird]);

            temporalArray.push(selectedArray[secondThird - (incrementValueBy*9)]);
            temporalArray.push(selectedArray[secondThird - (incrementValueBy*8)]);
            temporalArray.push(selectedArray[secondThird - (incrementValueBy*7)]);
            temporalArray.push(selectedArray[secondThird - (incrementValueBy*6)]);
            temporalArray.push(selectedArray[secondThird - (incrementValueBy*5)]);
            temporalArray.push(selectedArray[secondThird - (incrementValueBy*4)]);
            temporalArray.push(selectedArray[secondThird - (incrementValueBy*3)]);
            temporalArray.push(selectedArray[secondThird - (incrementValueBy*2)]);
            temporalArray.push(selectedArray[secondThird - incrementValueBy]);
            temporalArray.push(selectedArray[secondThird]);

            temporalArray.push(selectedArray[lastThird - (incrementValueBy*9)]);
            temporalArray.push(selectedArray[lastThird - (incrementValueBy*8)]);
            temporalArray.push(selectedArray[lastThird - (incrementValueBy*7)]);
            temporalArray.push(selectedArray[lastThird - (incrementValueBy*6)]);
            temporalArray.push(selectedArray[lastThird - (incrementValueBy*5)]);
            temporalArray.push(selectedArray[lastThird - (incrementValueBy*4)]);
            temporalArray.push(selectedArray[lastThird - (incrementValueBy*3)]);
            temporalArray.push(selectedArray[lastThird - (incrementValueBy*2)]);
            temporalArray.push(selectedArray[lastThird - incrementValueBy]);
            temporalArray.push(selectedArray[lastThird]);


            return temporalArray;

        } else {

            return  selectedArray;
        }

    }

    function createTempMinMaxChart(){
        $("#tempMinVSTempMax").html('');

        $.jqplot.config.enablePlugins = true;
            var plot2 = $.jqplot('tempMinVSTempMax', [getSampleForChart(arrayTempMin),
                                                      getSampleForChart(arrayTempMax),
                                                      getSampleForChart(arrayGDUAcum),
                                                      getSampleForChart(arrayPeriodUnder),
                                                      getSampleForChart(arrayPeriodAbove)], {
              title: 'Temperatures and GDUs',
              axes: {
                xaxis: {
                  renderer: $.jqplot.DateAxisRenderer,
                  label: 'Date',
                  labelRenderer: $.jqplot.CanvasAxisLabelRenderer,
                  tickRenderer: $.jqplot.CanvasAxisTickRenderer,
                  tickOptions: {
                      angle: 15 ,
                      tickInterval: '1 day'

                  }

                },
                yaxis: {
                  label: 'C',
                  labelRenderer: $.jqplot.CanvasAxisLabelRenderer
                }
              },
                highlighter: {
                            sizeAdjust: 10,
                            tooltipLocation: 'n',
                            tooltipAxes: 'y',
                            tooltipFormatString: '<b><i><span style="color:blue;">Temp:</span></i></b> %.2f',
                            useAxesFormatters: false
                },     cursor: {         show: true     },
                seriesColors: [ "#0066CC", "#FF9900", "#996633", "#006600", "#CC66FF"],
                series: [
                    {label: 'Tem.Min'},
                    {label: 'Temp.Max'},
                    {label: 'Daily GDUs'},
                    {label: 'Periods Under'+onChangeUpdateTempUnderOrAbove("tempUnder","tempMin","tempUnderLabelTable")},
                    {label: 'Periods Above'+onChangeUpdateTempUnderOrAbove("tempAbove","tempMax","tempAboveLabelTable")}
                ],legend: {show: true,placement: 'outside'}
            });

    }


    function createDampMinMaxChart(){
        $("#dampMinVSTempMax").html('');

         $.jqplot.config.enablePlugins = true;
            var plot2 = $.jqplot('dampMinVSTempMax', [getSampleForChart(arrayDampMin),getSampleForChart(arrayDampMax)], {
              title: 'Damp Min VS Max',
              axes: {
                xaxis: {
                  renderer: $.jqplot.DateAxisRenderer,
                  label: 'Date',
                  labelRenderer: $.jqplot.CanvasAxisLabelRenderer,
                  tickRenderer: $.jqplot.CanvasAxisTickRenderer,
                  tickOptions: {
                      angle: 15,
                      tickInterval: '1 day'
                  }

                },
                yaxis: {
                  label: '%',
                  labelRenderer: $.jqplot.CanvasAxisLabelRenderer
                }
              },
                highlighter: {
                            sizeAdjust: 10,
                            tooltipLocation: 'n',
                            tooltipAxes: 'y',
                            tooltipFormatString: '<b><i><span style="color:blue;">%:</span></i></b> %.2f',
                            useAxesFormatters: false
                },     cursor: {         show: true     },
                 series: [
                    {label: 'Damp.Min'},
                    {label: 'Damp.Max'}
                ],legend: {show: true,placement: 'outside'}
            });

    }

    function createWindSpeedMinMaxChart(){
        $("#windSpeedVSTempMax").html('');

         $.jqplot.config.enablePlugins = true;
            var plot2 = $.jqplot('windSpeedVSTempMax', [getSampleForChart(arrayWindSpeedMax),getSampleForChart(arrayWindSpeedMin)], {
              title: 'Wind Speed Min VS Max',
              axes: {
                xaxis: {
                  renderer: $.jqplot.DateAxisRenderer,
                  label: 'Date',
                  labelRenderer: $.jqplot.CanvasAxisLabelRenderer,
                  tickRenderer: $.jqplot.CanvasAxisTickRenderer,
                  tickOptions: {
                      angle: 15,
                      tickInterval: '1 day'
                  }

                },
                yaxis: {
                  label: 'Mph',
                  labelRenderer: $.jqplot.CanvasAxisLabelRenderer
                }
              },
                highlighter: {
                            sizeAdjust: 10,
                            tooltipLocation: 'n',
                            tooltipAxes: 'y',
                            tooltipFormatString: '<b><i><span style="color:blue;">Mph:</span></i></b> %.2f',
                            useAxesFormatters: false
                },     cursor: {         show: true     },
                 series: [
                    {label: 'Wind Speed.Min'},
                    {label: 'Wind Speed.Max'}
                ],legend: {show: true,placement: 'outside'}
            });

    }
     $(document).ready(function() {
         loadPage();
     });
})(jQuery,application);