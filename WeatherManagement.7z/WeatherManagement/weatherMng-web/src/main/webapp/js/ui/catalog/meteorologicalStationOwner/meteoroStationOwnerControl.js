(function ($,s) {

    var MAIN_DATA_TABLE = "dataTable_meteorologicalOwner";

      var searchParameters=[
        { id: 'meteorologicalStationOwnerDescription', container: '#meteorologicalStationOwnerDescription', property: 'meteorologicalStationOwnerDescription', searchValue: '' },
        { id: 'meteorologicalStationOwnerId', container: '#meteorologicalStationOwnerId', property: 'meteorologicalStationOwnerId', searchValue: '' },
        { id: 'meteorologicalStationOwnerShortDescription', container: '#meteorologicalStationOwnerShortDescription', property: 'meteorologicalStationOwnerShortDescription', searchValue: '' },
        { id: 'areaId', container: '#areaId', property: 'areaId', searchValue: '' },
        { id: 'activeStatus', container: '#activeStatus', property: 'activeStatus', searchValue: '' }
      ];

    function loadPage(){
      initData();
      initComboAreas();
      initDataTable();
      initBtnSaveOrUpdate();
      initBtnSearch();
      initBtnDelete();
      initBtnClean();
    }

    function initData(){
      $('input[name=activeStatus]').attr('checked',true);
      $('#deleteBtn').attr('disabled',true);
    }

     function initComboAreas(){
         var options = {
             'url':s.baseUrl + '/security/userSecurityAdm/loadCollectionAreas.do' , 'params':{},
             'sourceScript':'#comboBoxTemplate', 'container':'#containerArea',
             'comboBoxId':'areaId', 'comboBoxName':'areaId',
             'mappings':{'id':'id','description':'description','selectedItem':'-1'}, 'async':false
         }
         applicationLib.initComboByUrl(options);

    }


     function initBtnClean(){

         $(document).on("click",'#cleanBtn', function() {
             cleanFrom();
         });
    }

    function initBtnSaveOrUpdate(){

         $(document).on("click",'#saveBtn', function() {
             var errFound = false;
             errFound = validateForm(errFound,'meteorologicalStationOwnerDescription',VALIDATE_METEORO_STATION_OWNER_DESCRIPTION);
             errFound = validateForm(errFound,'meteorologicalStationOwnerShortDescription',VALIDATE_METEORO_STATION_OWNER_SHORT_DESCRIPTION);
             errFound = validateForm(errFound,'areaId',VALIDATE_METEORO_STATION_OWNER_AREA_ID);

             if(!errFound){
                showAlert(['The Registry is about to be saved, do you want to proceed?'],MONSANTO_STATIC_VARIABLE_NOTIFICATION,saveCallback)
             }
         });
    }

    function initBtnSearch(){

         $(document).on("click",'#searchBtn', function() {
             cleanErrors(FIELDS_TO_CLEAN);
             drawTable();
         });
    }

    function initBtnDelete(){

         $(document).on("click",'#deleteBtn', function() {
             showAlert(['The Registry is about to be deleted, do you want to proceed?'],MONSANTO_STATIC_VARIABLE_WARNING,deleteCallback)
         });

    }



     function drawTable(){
        $('#meteorologicalStationOwnerId').val('');
        $('#saveBtn').val('Save');
        $('#deleteBtn').attr('disabled',true);

        $('#'+MAIN_DATA_TABLE).dataTable().fnDraw();
    }


    function saveCallback(){
         hideShowAlertBox(false);
         showHideProcessScreen(true);
         var optionsForm = {
                  dataType:  'json',
                  "success":function(response, statusText, xhr) {
                    if (response.success) {
                        showHideProcessScreen(false);
                        showAlert(response.messages,MONSANTO_STATIC_VARIABLE_SUCCESS,drawTable);

                    }else{
                        hideAllAlertsAndProcessScreen();
                        showAlert(response.messages,MONSANTO_STATIC_VARIABLE_ERROR);

                    }
                  },
                  "error":function(xhr, status, error) {
                      hideAllAlertsAndProcessScreen();
                      showAlert([error],MONSANTO_STATIC_VARIABLE_ERROR);
                  }
              };

              $('#dataForm').ajaxForm(optionsForm);
              $('#dataForm').submit();

    }

    function deleteCallback(){
         hideShowAlertBox(false);
         showHideProcessScreen(true);

         $.ajax( {"url": s.baseUrl+"/catalog/meteoroStationOwnerBase/delete.do",
            "dataType":'json',
            "data":{ id:$('#meteorologicalStationOwnerId').val()},
            "success":function(response,status ,xhr) {
                 if(!response.success&&response.success===false){
                      hideAllAlertsAndProcessScreen();
                      showAlert(response.messages,MONSANTO_STATIC_VARIABLE_ERROR);
                 }else{
                     cleanFrom();
                    showHideProcessScreen(false);
                    showAlert(response.messages,MONSANTO_STATIC_VARIABLE_SUCCESS,drawTable);
                 }
            },
            "error":function(xhr, status, error) {
                hideAllAlertsAndProcessScreen();
                showAlert([error],MONSANTO_STATIC_VARIABLE_ERROR);
            }
        });

    }

    function initDataTable(){

       var tableInfo= $('#'+MAIN_DATA_TABLE).dataTable( {
             "bJQueryUI": true,
            "bProcessing": true,
            "bServerSide": true,
            "bLengthChange": 10,
            "sAjaxSource" : s.baseUrl+"/catalog/meteoroStationOwnerBase/search.do",
            "sScrollX": "100%",
            "bPaginate": true,
            "bFilter": true,
            "aaSorting": [[ 1, "asc" ]],
            "sPaginationType": "full_numbers",
            "aoColumns": [
                { "mDataProp": "id","sWidth": "10%"},
                { "mDataProp": "description","sWidth": "23%"},
                { "mDataProp": "shortDescription","sWidth": "22%"},
                { "mDataProp": "area.description","sWidth": "25%"},
                { "mDataProp": "activeDescription","sWidth": "20%","bSortable": false}
            ],

            "fnServerData": function ( sSource, aoData, fnCallback ) {
                $.merge(aoData,applicationLib.createSearchParams(searchParameters));
                hideAllAlertsAndProcessScreen();
                showHideProcessScreen(true);
                $.ajax( {"url":sSource,
                         "dataType":'json',
                         "data":aoData,
                    "success":function (response) {
                        if(!response.success&&response.success===false){
                            var json={};
                            json.aaData= {};
                            json.iTotalDisplayRecords=0;
                            json.iTotalRecords=response.totalElements;
                            fnCallback(json);
                            hideAllAlertsAndProcessScreen();
                            showAlert(response.messages,MONSANTO_STATIC_VARIABLE_ERROR);
                        }else{
                            hideAllAlertsAndProcessScreen();
                            var json={};
                            json.aaData= response.content;
                            json.iTotalDisplayRecords=response.totalElements;
                            json.iTotalRecords=response.totalElements;
                            fnCallback(json);
                        }

                    },
                    "error":function(xhr, status, error) {
                        hideAllAlertsAndProcessScreen();
                        showAlert(["Application Error, Try Again"],MONSANTO_STATIC_VARIABLE_ERROR);
                    }
                });
            },"fnRowCallback": function(nRow, aData, iDisplayIndex) {
            $(nRow).click(function() {
                showHideProcessScreen(true);
                cleanFrom();
                $.ajax( {"url": s.baseUrl+"/catalog/meteoroStationOwnerBase/findById.do",
                    "dataType":'json',
                    "data":{ id:aData.id},
                    "success":function(entity,status ,xhr) {

                        $('#meteorologicalStationOwnerId').val(entity.id);
                        $('#meteorologicalStationOwnerDescription').val(entity.description);
                        $('#meteorologicalStationOwnerShortDescription').val(entity.shortDescription);

                        if(entity.active){
                           $('input[name=activeStatus]').attr('checked',true);
                        } else{
                           $('input[name=activeStatus]').attr('checked',false);
                        }

                        $("#areaId").val(entity.area.id);

                        $('#saveBtn').val('Modify');
                        $('#deleteBtn').attr('disabled',false);

                        showHideProcessScreen(false);
                    },
                    "error":function(xhr, status, error) {
                        hideAllAlertsAndProcessScreen();
                        showAlert([error],MONSANTO_STATIC_VARIABLE_ERROR);
                    }
                });

            });
        }
        });

    }

     function cleanFrom(){
        $('#meteorologicalStationOwnerId').val('');
        $('#meteorologicalStationOwnerDescription').val('');
        $('#meteorologicalStationOwnerShortDescription').val('');
        $("#areaId").val("-1");
        $('#saveBtn').val('Save');
        $('input[name=activeStatus]').attr('checked',true);
        $('#deleteBtn').attr('disabled',true);

        cleanErrors(FIELDS_TO_CLEAN);
     }

     $(document).ready(function() {
         loadPage();
     });
})(jQuery,application);