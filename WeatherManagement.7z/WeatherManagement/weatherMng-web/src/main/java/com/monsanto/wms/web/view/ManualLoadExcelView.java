package com.monsanto.wms.web.view;

import com.monsanto.wms.persistence.model.MeteorologicalStationHistoric;
import com.monsanto.wms.util.WMSServiceUtil;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.springframework.web.servlet.view.document.AbstractExcelView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * Created by IntelliJ IDEA.
 * User: MANIET
 * Date: 12/11/12
 * Time: 10:53 AM
 * To change this template use File | Settings | File Templates.
 */
public class ManualLoadExcelView extends AbstractExcelView {

    @Override
    public void buildExcelDocument(Map<String, Object> model,
                                      HSSFWorkbook workbook,
                                      HttpServletRequest httpServletRequest,
                                      HttpServletResponse httpServletResponse) throws Exception {


        HSSFSheet sheet = workbook.createSheet("WMS Report Tm TM");
        createHeader(sheet);
        Map<String, Object> data  =(Map<String, Object>) model.get("excelData");

        populateConceptRow(sheet,(List<MeteorologicalStationHistoric>)data.get("dataList"),(String)data.get("tempType"));

        httpServletResponse.setHeader("Content-Disposition", "attachment; filename=\"ReportTmTM.xls\"");
    }

    private void populateConceptRow(HSSFSheet sheet, List<MeteorologicalStationHistoric> resultData,String tempType){

        int i =0;
        int rowNum = 1;

        HSSFRow row = null;

        for(MeteorologicalStationHistoric currentItem : resultData ){
            row = sheet.createRow(rowNum++);
            row.createCell(i++).setCellValue(currentItem.getId());
            row.createCell(i++).setCellValue(currentItem.getMeteorologicalStation().getDescription());
            if(tempType.equalsIgnoreCase("C")){
                row.createCell(i++).setCellValue(currentItem.getTempMax());
                row.createCell(i++).setCellValue(currentItem.getTempMin());
            }else{
                row.createCell(i++).setCellValue(WMSServiceUtil.celsiusToFahrenheit(currentItem.getTempMax()));
                row.createCell(i++).setCellValue(WMSServiceUtil.celsiusToFahrenheit(currentItem.getTempMin()));
            }

            row.createCell(i++).setCellValue(currentItem.getTimeRegistry());

            i=0;
        }




    }
    private HSSFRow createHeader(HSSFSheet sheet) {

         HSSFRow header = sheet.createRow(0);
        int i = 0;
		header.createCell(i++).setCellValue("ID");
		header.createCell(i++).setCellValue("Meteorological Station");
		header.createCell(i++).setCellValue("Temp Min °C");
		header.createCell(i++).setCellValue("Temp Max °C");
		header.createCell(i++).setCellValue("Registry time");

        return header;
    }
}
