package com.monsanto.wms.web.controller.security;

import com.monsanto.wms.persistence.model.Area;
import com.monsanto.wms.persistence.model.Roles;
import com.monsanto.wms.persistence.model.User;
import com.monsanto.wms.persistence.model.UserSystemPrivileges;
import com.monsanto.wms.service.security.UserSystemPrivilegesService;
import com.monsanto.wms.web.controller.commons.BaseController;
import com.monsanto.wms.web.form.security.UserAdministrationForm;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.MessageSource;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by IntelliJ IDEA.
 * User: MANIET
 * Date: 6/3/13
 * Time: 3:58 PM
 * To change this template use File | Settings | File Templates.
 */
@Controller
@RequestMapping("/security/userSecurityAdm")
public final class UserSecurityAdministrationController extends BaseController {

    private static final String USER_SECURITY_ADM_BASE = "security/userSecurityAdm";

    private UserSystemPrivilegesService userSystemPrivilegesService;

    @Autowired
    public UserSecurityAdministrationController(UserSystemPrivilegesService userSystemPrivilegesService, @Qualifier("messageSource") MessageSource messageSource) {
        super();
        this.userSystemPrivilegesService = userSystemPrivilegesService;
        setMessageSource(messageSource);
    }

    @RequestMapping("/init")
    public ModelAndView initView() {
        Map<String, Object> model = new HashMap<String, Object>();

        model.put(DATA_FORM, new UserAdministrationForm());
        return new ModelAndView(USER_SECURITY_ADM_BASE, model);
    }

    @RequestMapping("/saveOrUpdate")
    @ResponseBody
    public ResponseEntity<GenericResponse> saveOrUpdate(@ModelAttribute UserAdministrationForm form) {

        userSystemPrivilegesService.save(new UserSystemPrivileges(form.getUserPrivilegesId(), form.getUserId(), form.getRoleId(), form.getAreaId()));

        return new ResponseEntity<GenericResponse>(new GenericResponse(true, getMessage(SAVE_OPERATION_SUCCEEDED)), HttpStatus.OK);
    }

    @RequestMapping("/search")
    @ResponseBody
    public Page<UserSystemPrivileges> search(@ModelAttribute UserAdministrationForm form, Pageable pageable) {
        return userSystemPrivilegesService.search(form.getUserId(), form.getAreaId(), form.getRoleId(), form.getActiveStatus(), pageable);
    }

    @RequestMapping(value = "/findById")
    @ResponseBody
    public UserSystemPrivileges findById(@RequestParam Long id) {
        return userSystemPrivilegesService.findById(id);
    }


    @RequestMapping(value = "/delete")
    @ResponseBody
    public ResponseEntity<GenericResponse> delete(@RequestParam Long id) {

        userSystemPrivilegesService.delete(id);

        return new ResponseEntity<GenericResponse>(new GenericResponse(true, getMessage(DELETE_OPERATION_SUCCEEDED)), HttpStatus.OK);
    }

    @RequestMapping(value = "/loadCollectionAreas")
    @ResponseBody
    public Collection<Area> loadCollectionAreas() {
        return userSystemPrivilegesService.loadCollectionAreas();
    }

    @RequestMapping(value = "/loadCollectionRoles")
    @ResponseBody
    public Collection<Roles> loadCollectionRoles(@RequestParam Long areaId) {
        return userSystemPrivilegesService.loadCollectionRoles(areaId);
    }

    @RequestMapping(value = "/loadCollectionUser")
    @ResponseBody
    public Collection<User> loadCollectionUser(@RequestParam String id) {
        return userSystemPrivilegesService.loadCollectionUser(id);
    }

}
