package com.monsanto.wms.web.controller.catalog;


import com.monsanto.wms.persistence.model.MeteorologicalStationHistoric;
import com.monsanto.wms.service.catalog.MeteorologicalStationHistoricService;
import com.monsanto.wms.web.controller.commons.BaseController;
import com.monsanto.wms.web.form.catalog.MeteorologicalStationForm;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.MessageSource;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import java.text.ParseException;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by IntelliJ IDEA.
 * User: MANIET
 * Date: 6/3/13
 * Time: 3:58 PM
 * To change this template use File | Settings | File Templates.
 */
@Controller
@RequestMapping("/catalog/meteoroStationHistory")
public final class MeteorologicalStationHistoricController extends BaseController {

    public static final String METEORO_HISTORY = "catalog/meteoroStationHistory";

    private MeteorologicalStationHistoricService meteorologicalStationHistoricService;

    @Autowired
    public MeteorologicalStationHistoricController(MeteorologicalStationHistoricService meteorologicalStationHistoricService, @Qualifier("messageSource") MessageSource messageSource) {
        super();
        this.meteorologicalStationHistoricService = meteorologicalStationHistoricService;
        setMessageSource(messageSource);
    }

    @RequestMapping("/init")
    public ModelAndView initView() {
        Map<String, Object> model = new HashMap<String, Object>();

        model.put(DATA_FORM, new MeteorologicalStationForm());
        return new ModelAndView(METEORO_HISTORY, model);
    }

    @RequestMapping("/search")
    @ResponseBody
    public Page<MeteorologicalStationHistoric> search(@RequestParam Long meteorologicalStationId, @RequestParam Date startDate,@RequestParam Date endDate, Pageable pageable) throws ParseException {
        return meteorologicalStationHistoricService.search(meteorologicalStationId,startDate, endDate,pageable);
    }


}
