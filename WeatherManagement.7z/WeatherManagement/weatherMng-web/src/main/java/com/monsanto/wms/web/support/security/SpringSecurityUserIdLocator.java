package com.monsanto.wms.web.support.security;

import com.monsanto.wms.persistence.model.User;
import com.monsanto.wms.support.security.UserIdLocator;
import com.monsanto.wms.util.WMSServiceUtil;

/**
 * Monsanto
 * Author: MANIET
 * Date: 14/05/13
 * Time: 10:45 AM
 */
public class SpringSecurityUserIdLocator implements UserIdLocator {

    public String getUserId() {
        User user = (User) WMSServiceUtil.getCurrentUser();
        if(user!=null){
            return user.getId();
        }else{
            return "N/A";
        }

    }
}
