package com.monsanto.wms.web.form.tools;

import java.util.Date;

/**
 * Created by IntelliJ IDEA.
 * User: MANIET
 * Date: 6/24/13
 * Time: 10:39 AM
 * To change this template use File | Settings | File Templates.
 */
public class CalculatorForm {

    //General Variables
    private Long meteorologicalStationId;
    private Long cropTypeId;
    private Long cropId;
    private Integer startDate;
    private Integer endDate;
    private Double tempMin;
    private Double tempMax;
    private Long ownerId;
    private String temperatureIn;
    private String cropName;

    //First Section
    private Integer dayOfTheMonthA;
    private Integer monthSectionA;
    private String calculationTypeA;
    private Double currentValueA;


     //Second Section
    private Integer monthSectionB;
    private String calculationTypeB;
    private Double currentValueB;

    //Third Section
    private Integer yearC;
    private Integer monthSectionC;

    private String firstLoad;

    //fourth Section

    private Integer dayDStart;
    private Integer monthSectionStartD;
    private Integer dayDEnd;
    private Integer monthSectionEndD;

    public Long getMeteorologicalStationId() {
        return meteorologicalStationId;
    }

    public void setMeteorologicalStationId(Long meteorologicalStationId) {
        this.meteorologicalStationId = meteorologicalStationId;
    }

    public Integer getStartDate() {
        return startDate;
    }

    public void setStartDate(Integer startDate) {
        this.startDate = startDate;
    }

    public Integer getEndDate() {
        return endDate;
    }

    public void setEndDate(Integer endDate) {
        this.endDate = endDate;
    }

    public Integer getDayOfTheMonthA() {
        return dayOfTheMonthA;
    }

    public void setDayOfTheMonthA(Integer dayOfTheMonthA) {
        this.dayOfTheMonthA = dayOfTheMonthA;
    }

    public Integer getMonthSectionA() {
        return monthSectionA;
    }

    public void setMonthSectionA(Integer monthSectionA) {
        this.monthSectionA = monthSectionA;
    }

    public String getCalculationTypeA() {
        return calculationTypeA;
    }

    public void setCalculationTypeA(String calculationTypeA) {
        this.calculationTypeA = calculationTypeA;
    }

    public Double getCurrentValueA() {
        return currentValueA;
    }

    public void setCurrentValueA(Double currentValueA) {
        this.currentValueA = currentValueA;
    }

    public Integer getMonthSectionB() {
        return monthSectionB;
    }

    public void setMonthSectionB(Integer monthSectionB) {
        this.monthSectionB = monthSectionB;
    }

    public String getCalculationTypeB() {
        return calculationTypeB;
    }

    public void setCalculationTypeB(String calculationTypeB) {
        this.calculationTypeB = calculationTypeB;
    }

    public Double getCurrentValueB() {
        return currentValueB;
    }

    public void setCurrentValueB(Double currentValueB) {
        this.currentValueB = currentValueB;
    }

    public Integer getYearC() {
        return yearC;
    }

    public void setYearC(Integer yearC) {
        this.yearC = yearC;
    }

    public Integer getMonthSectionC() {
        return monthSectionC;
    }

    public void setMonthSectionC(Integer monthSectionC) {
        this.monthSectionC = monthSectionC;
    }

    public String getFirstLoad() {
        return firstLoad;
    }

    public void setFirstLoad(String firstLoad) {
        this.firstLoad = firstLoad;
    }

    public Boolean isFisrtLoad(){
        if(getFirstLoad().equalsIgnoreCase("YES")) return true;
        else return false;
    }

    public Long getCropTypeId() {
        return cropTypeId;
    }

    public void setCropTypeId(Long cropTypeId) {
        this.cropTypeId = cropTypeId;
    }

    public Long getCropId() {
        return cropId;
    }

    public void setCropId(Long cropId) {
        this.cropId = cropId;
    }

    public Double getTempMin() {
        return tempMin;
    }

    public void setTempMin(Double tempMin) {
        this.tempMin = tempMin;
    }

    public Double getTempMax() {
        return tempMax;
    }

    public void setTempMax(Double tempMax) {
        this.tempMax = tempMax;
    }

    public Integer getDayDStart() {
        return dayDStart;
    }

    public void setDayDStart(Integer dayDStart) {
        this.dayDStart = dayDStart;
    }

    public Integer getMonthSectionStartD() {
        return monthSectionStartD;
    }

    public void setMonthSectionStartD(Integer monthSectionStartD) {
        this.monthSectionStartD = monthSectionStartD;
    }

    public Integer getDayDEnd() {
        return dayDEnd;
    }

    public void setDayDEnd(Integer dayDEnd) {
        this.dayDEnd = dayDEnd;
    }

    public Integer getMonthSectionEndD() {
        return monthSectionEndD;
    }

    public void setMonthSectionEndD(Integer monthSectionEndD) {
        this.monthSectionEndD = monthSectionEndD;
    }

    public Long getOwnerId() {
        return ownerId;
    }

    public void setOwnerId(Long ownerId) {
        this.ownerId = ownerId;
    }

    public String getTemperatureIn() {
        return temperatureIn;
    }

    public void setTemperatureIn(String temperatureIn) {
        this.temperatureIn = temperatureIn;
    }

    public String getCropName() {
        return cropName;
    }

    public void setCropName(String cropName) {
        this.cropName = cropName;
    }
}
