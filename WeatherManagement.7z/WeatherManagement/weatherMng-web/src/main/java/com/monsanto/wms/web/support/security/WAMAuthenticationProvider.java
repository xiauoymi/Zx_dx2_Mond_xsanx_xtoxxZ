package com.monsanto.wms.web.support.security;


import com.monsanto.wms.persistence.model.UserSystemPrivileges;
import com.monsanto.wms.service.security.UserService;
import com.monsanto.wms.service.security.UserSystemPrivilegesService;
import com.monsanto.wms.util.AreaType;
import com.monsanto.wms.util.RoleType;
import com.monsanto.wms.vo.LoginUserVO;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

import java.text.MessageFormat;
import java.util.*;

/**
 * Monsanto
 * Author: MANIET
 * Date: 08/08/2103
 * Time: 12:27 PM
 */
public class WAMAuthenticationProvider implements AuthenticationProvider {

    private static final Logger logger = Logger.getLogger(WAMAuthenticationProvider.class);
    private static final String DEFAULT_CREDENTIALS = "¡¡¡SECRET!!!";
    private static final String USERNAME_NOT_FOUND_MESSAGE = "User ''{0}'' not found";
    private UserSystemPrivilegesService userSystemPrivilegesService;
    private UserService userService;


    @Autowired
    public WAMAuthenticationProvider(UserSystemPrivilegesService userSystemPrivilegesService, UserService userService) {
        this.userSystemPrivilegesService = userSystemPrivilegesService;
        this.userService = userService;
    }

    public Authentication authenticate(Authentication authentication) throws AuthenticationException {

        String webData = authentication.getName();
        LoginUserVO loginUser = getUserAndPassword(webData);

        return verifySystemAccess(loginUser);

    }

    private Authentication verifySystemAccess(LoginUserVO loginUser) {
        List<UserSystemPrivileges> userData = userSystemPrivilegesService.findByUserId(loginUser.getUserName());

        UserSystemPrivileges userSystemPrivileges = getUserSystemPrivileges(userData);

        if (userSystemPrivileges != null) {

            UsernamePasswordAuthenticationToken userAuthenticatedToken =
                    new UsernamePasswordAuthenticationToken(loginUser.getUserName(),
                            DEFAULT_CREDENTIALS,
                            setupPrivileges(userData));

            userAuthenticatedToken.setDetails(userSystemPrivileges.getUser());

            return userAuthenticatedToken;
        }

        throw new UsernameNotFoundException(MessageFormat.format(USERNAME_NOT_FOUND_MESSAGE, loginUser.getUserName()));
    }

    private UserSystemPrivileges getUserSystemPrivileges(List<UserSystemPrivileges> userData) {

        UserSystemPrivileges userSystemPrivileges = null;

        if (userData != null && !userData.isEmpty()) {
            userSystemPrivileges = userData.get(0);
        }

        return userSystemPrivileges;
    }

    private LoginUserVO getUserAndPassword(String webData){
        LoginUserVO  loginUser = new LoginUserVO(webData);

        if (!loginUser.isIE()) {
            return verifyAccessWithLDAP(loginUser);
        } else {
            return loginUser;
        }
    }

    private LoginUserVO verifyAccessWithLDAP(LoginUserVO  loginUser){
        Boolean accessGranted = userService.authenticated(loginUser.getUserName(), loginUser.getPassword());
        if(accessGranted) return loginUser;
        else throw new UsernameNotFoundException(MessageFormat.format(USERNAME_NOT_FOUND_MESSAGE, loginUser.getUserName()));
    }


    private List<GrantedAuthority> setupPrivileges(List<UserSystemPrivileges> privileges) {

        List<GrantedAuthority> authorities = new ArrayList<GrantedAuthority>();

        for (UserSystemPrivileges currentItem : privileges) {
            RoleType role = RoleType.lookup(currentItem.getRole().getId());
            AreaType area = AreaType.lookup(currentItem.getRole().getArea().getId());
            GrantedAuthority authorityRole = new SimpleGrantedAuthority(role.name());
            GrantedAuthority authorityArea = new SimpleGrantedAuthority(area.name());
            authorities.add(authorityRole);
            authorities.add(authorityArea);
        }

        return authorities;
    }

    public boolean supports(Class<?> aClass) {
        return true;
    }
}
