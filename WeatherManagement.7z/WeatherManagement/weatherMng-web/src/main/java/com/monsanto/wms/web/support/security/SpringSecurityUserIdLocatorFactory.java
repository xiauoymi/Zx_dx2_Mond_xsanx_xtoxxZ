package com.monsanto.wms.web.support.security;

import com.monsanto.wms.support.security.UserIdLocator;
import com.monsanto.wms.support.security.UserIdLocatorFactory;
import org.springframework.stereotype.Component;

/**
 * Monsanto
 * Author: Luis Miguel Arteaga Rios (lmarte@monsanto.com)
 * Date: 4/12/12
 * Time: 12:55 PM
 */
@Component
public class SpringSecurityUserIdLocatorFactory implements UserIdLocatorFactory{

    public UserIdLocator getUserIdLocator() {
        return new SpringSecurityUserIdLocator();
    }
}
