package com.monsanto.wms.web.view;

import com.monsanto.wms.vo.RealReportStrewRecommendationVO;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.springframework.web.servlet.view.document.AbstractExcelView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.List;
import java.util.Map;

/**
 * Created by IntelliJ IDEA.
 * User: MANIET
 * Date: 12/11/12
 * Time: 10:53 AM
 * To change this template use File | Settings | File Templates.
 */
public class SowRecommendationDateGduExcelView extends AbstractExcelView {

    @Override
    public void buildExcelDocument(Map<String, Object> model,
                                      HSSFWorkbook workbook,
                                      HttpServletRequest httpServletRequest,
                                      HttpServletResponse httpServletResponse) throws Exception {


        HSSFSheet sheet = workbook.createSheet("WMS Sow Recommendation Report");
        createHeader(sheet);
        Map<String, Object> data  =(Map<String, Object>) model.get("excelData");

        populateConceptRow(sheet,(List<RealReportStrewRecommendationVO>)data.get("dataList"),(Integer)data.get("selectedYear"),(String)data.get("tempType"));

        httpServletResponse.setHeader("Content-Disposition", "attachment; filename=\"sowRecommendationReport_"+(String)data.get("metStation")+".xls\"");
    }

    private void populateConceptRow(HSSFSheet sheet, List<RealReportStrewRecommendationVO> resultData, Integer year,String tempType){

        int i =0;
        int rowNum = 1;

        HSSFRow row = null;

        for(RealReportStrewRecommendationVO currentItem : resultData ){
            row = sheet.createRow(rowNum++);
            row.createCell(i++).setCellValue(currentItem.getDay()+"/"+currentItem.getMonth()+"/"+year);

            if(tempType.equalsIgnoreCase("C")){
                row.createCell(i++).setCellValue(currentItem.getTempMinC());
                row.createCell(i++).setCellValue(currentItem.getTempMaxC());
            }else{
                row.createCell(i++).setCellValue(currentItem.getTempMinF());
                row.createCell(i++).setCellValue(currentItem.getTempMaxF());
            }

            row.createCell(i++).setCellValue(currentItem.getDailyGdu());
            row.createCell(i++).setCellValue(currentItem.getAcumGdu());
            row.createCell(i++).setCellValue((!currentItem.getCropStageName().equalsIgnoreCase("null") && currentItem.getCropStageName().length()>0) ? currentItem.getCropStageName():"");

            i=0;
        }




    }
    private HSSFRow createHeader(HSSFSheet sheet) {

         HSSFRow header = sheet.createRow(0);
        int i = 0;
		header.createCell(i++).setCellValue("Date");
		header.createCell(i++).setCellValue("Temp Min °C");
		header.createCell(i++).setCellValue("Temp Max °C");
		header.createCell(i++).setCellValue("Daily GDUs");
        header.createCell(i++).setCellValue("Acum. GDUs");
        header.createCell(i++).setCellValue("Crop Stage");

        return header;
    }
}
