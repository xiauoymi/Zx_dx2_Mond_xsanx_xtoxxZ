package com.monsanto.wms.web.support.security;

import com.monsanto.wms.support.security.DefaultUserIdLocator;
import com.monsanto.wms.support.security.UserIdLocator;
import com.monsanto.wms.support.security.UserIdLocatorFactory;
import org.springframework.beans.factory.annotation.Value;
import weblogic.security.Security;

/**
 * Created by IntelliJ IDEA.
 * User: FJSIBA
 * Date: 21/08/12
 * Time: 02:25 PM
 * To change this template use File | Settings | File Templates.
 */

//@Component
public class WAMUserLocatorIdFactory implements UserIdLocatorFactory{
    private String lsiFunction = "default";

    public WAMUserLocatorIdFactory(){}

    public WAMUserLocatorIdFactory(@Value("${lsi.function}") String lsiFunction){
        if(lsiFunction != null){
            this.lsiFunction = lsiFunction;
        }
    }

    public UserIdLocator getUserIdLocator(){
        return "default".equals(lsiFunction) || "win".equals(lsiFunction) ? new DefaultUserIdLocator():new WAMUserIdLocator(Security.getCurrentSubject());

    }
}
