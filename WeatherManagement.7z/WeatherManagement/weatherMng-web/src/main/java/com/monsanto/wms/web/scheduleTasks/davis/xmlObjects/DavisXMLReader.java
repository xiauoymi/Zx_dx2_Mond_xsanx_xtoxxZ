package com.monsanto.wms.web.scheduleTasks.davis.xmlObjects;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "current_observation")
public class DavisXMLReader {

    private DavisItemsDetail davisStationDetails;
    private String latitude;
    private String longitude;

    public String getLatitude() {
        return latitude;
    }

    @XmlElement(name = "latitude")
    public void setLatitude(String latitude) {
        this.latitude = latitude;
    }

    public String getLongitude() {
        return longitude;
    }

    @XmlElement(name = "longitude")
    public void setLongitude(String longitude) {
        this.longitude = longitude;
    }

    public DavisItemsDetail getDavisStationDetails() {
        return davisStationDetails;
    }

    @XmlElement(name = "davis_current_observation")
    public void setDavisStationDetails(DavisItemsDetail davisStationDetails) {
        this.davisStationDetails = davisStationDetails;
    }
}