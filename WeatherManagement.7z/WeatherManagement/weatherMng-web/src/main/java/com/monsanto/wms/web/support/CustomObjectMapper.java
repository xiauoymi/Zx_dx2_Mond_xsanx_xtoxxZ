package com.monsanto.wms.web.support;


import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.map.SerializationConfig;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.text.SimpleDateFormat;
import java.util.Locale;


/**
 * Created by IntelliJ IDEA.
 * User: ACISS
 * Date: 12/10/12
 * Time: 07:48 PM
 * To change this template use File | Settings | File Templates.
 */
@Component
public class CustomObjectMapper extends ObjectMapper {


    private MessageSource messageSource;

    public CustomObjectMapper() {
        super.configure(SerializationConfig.Feature.WRITE_DATES_AS_TIMESTAMPS, false);
        super.configure(SerializationConfig.Feature.FAIL_ON_EMPTY_BEANS, false);
    }

    @PostConstruct
    public void afterPropertiesSet() throws Exception {
        SerializationConfig serialConfig = getSerializationConfig()
                .withDateFormat(new SimpleDateFormat(
                        messageSource.getMessage("common.default.dateFormat", null,
                                Locale.getDefault()))
                );
        this.setSerializationConfig(serialConfig);
    }

    @Autowired
    public void setMessageSource(@Qualifier("messageSource") MessageSource messageSource) {
        this.messageSource = messageSource;
    }
}