package com.monsanto.wms.web.scheduleTasks.listeners;

import com.monsanto.wms.service.catalog.MeteorologicalStationService;
import com.monsanto.wms.service.mail.MailService;
import com.monsanto.wms.service.security.UserSystemPrivilegesService;
import com.monsanto.wms.web.scheduleTasks.spectrum.InitStationRequiredServices;
import com.monsanto.wms.web.scheduleTasks.davis.InitDavisScheduleTask;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import java.util.Date;

/**
 * Created by IntelliJ IDEA.
 * User: MANIET
 * Date: 7/9/13
 * Time: 10:49 AM
 * To change this template use File | Settings | File Templates.
 */
@Component
public class DAVISListener implements ServletContextListener {

    private InitDavisScheduleTask initDavisScheduleTask;
    private static final Logger log = LoggerFactory.getLogger(DAVISListener.class);

    @Override
    public void contextInitialized(ServletContextEvent servletContextEvent) {

        final MeteorologicalStationService meteorologicalStationService = InitStationRequiredServices.getStationService(servletContextEvent);
        final MailService mailService = InitStationRequiredServices.getMailService(servletContextEvent);
        final UserSystemPrivilegesService userSystemPrivilegesService = InitStationRequiredServices.getUserSystemPrivilegesService(servletContextEvent);

        initDavisScheduleTask = new InitDavisScheduleTask(meteorologicalStationService,mailService,userSystemPrivilegesService);
        initDavisScheduleTask.start();

    }

    @Override
    public void contextDestroyed(ServletContextEvent servletContextEvent) {
        log.info("DAVIS Station batch reader stopped  on the " + new Date() + " restart the server to run this process again");
        System.out.println("DAVIS batch process destroyed");
        if (initDavisScheduleTask.getTimer() != null) {
            initDavisScheduleTask.getTimer().cancel();
        }

        log.info("DAVIS batch process destroyed");
    }

}
