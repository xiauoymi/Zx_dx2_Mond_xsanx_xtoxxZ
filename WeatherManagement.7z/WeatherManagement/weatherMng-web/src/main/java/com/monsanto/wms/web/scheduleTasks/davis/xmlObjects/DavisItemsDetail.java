package com.monsanto.wms.web.scheduleTasks.davis.xmlObjects;

import javax.xml.bind.annotation.XmlElement;

/**
 * Created by IntelliJ IDEA.
 * User: MANIET
 * Date: 6/20/13
 * Time: 3:45 PM
 * To change this template use File | Settings | File Templates.
 */
public class DavisItemsDetail {

    private Double maxTempF;
    private String maxTempTime;

    private Double minTempF;
    private String minTempTime;

    private Double maxPressure;
    private String maxPressureTime;
    private Double minPressure;
    private String minPressureTime;

    private Double rain;
    private Double radiation;
    private String radiationTime;

    private Double wind;
    private String windTime;

    private Double dewPointMax;
    private String dewPointMaxTime;
    private Double dewPointMin;
    private String dewPointMinTime;

    private Double eTranspirationDay;
    private Double eTranspirationMonth;
    private Double eTranspirationYear;

    private Double heatIndexDayMax;
    private String heatIndexDayMaxTime;

    private Double rainDayMax;
    private Double rainStorm;

    private Double relativeHumidityDayMax;
    private String relativeHumidityDayMaxTime;

    private Double relativeHumidityDayMin;
    private String relativeHumidityDayMinTime;

    private String sunrise;
    private String sunset;

    private Double uvIndex;


    public Double getMaxTempF() {
        return maxTempF;
    }

    @XmlElement(name = "temp_day_high_f")
    public void setMaxTempF(Double maxTempF) {
        this.maxTempF = maxTempF;
    }

    public String getMaxTempTime() {
        return maxTempTime;
    }

    @XmlElement(name = "temp_day_high_time")
    public void setMaxTempTime(String maxTempTime) {
        this.maxTempTime = maxTempTime;
    }

    public Double getMinTempF() {
        return minTempF;
    }

    @XmlElement(name = "temp_day_low_f")
    public void setMinTempF(Double minTempF) {
        this.minTempF = minTempF;
    }

    public String getMinTempTime() {
        return minTempTime;
    }

    @XmlElement(name = "temp_day_low_time")
    public void setMinTempTime(String minTempTime) {
        this.minTempTime = minTempTime;
    }

    public Double getMaxPressure() {
        return maxPressure;
    }

    @XmlElement(name = "pressure_day_high_in")
    public void setMaxPressure(Double maxPressure) {
        this.maxPressure = maxPressure;
    }

    public String getMaxPressureTime() {
        return maxPressureTime;
    }
    @XmlElement(name = "pressure_day_high_time")
    public void setMaxPressureTime(String maxPressureTime) {
        this.maxPressureTime = maxPressureTime;
    }

    public Double getMinPressure() {
        return minPressure;
    }

    @XmlElement(name = "pressure_day_low_in")
    public void setMinPressure(Double minPressure) {
        this.minPressure = minPressure;
    }

    public String getMinPressureTime() {
        return minPressureTime;
    }

    @XmlElement(name = "pressure_day_low_time")
    public void setMinPressureTime(String minPressureTime) {
        this.minPressureTime = minPressureTime;
    }

    public Double getRain() {
        return rain;
    }

    @XmlElement(name = "rain_rate_hour_high_in_per_hr")
    public void setRain(Double rain) {
        this.rain = rain;
    }

    public Double getRadiation() {
        return radiation;
    }

    @XmlElement(name = "solar_radiation_day_high")
    public void setRadiation(Double radiation) {
        this.radiation = radiation;
    }

    public String getRadiationTime() {
        return radiationTime;
    }

    @XmlElement(name = "solar_radiation_day_high_time")
    public void setRadiationTime(String radiationTime) {
        this.radiationTime = radiationTime;
    }

    public Double getWind() {
        return wind;
    }

    @XmlElement(name = "wind_day_high_mph")
    public void setWind(Double wind) {
        this.wind = wind;
    }

    public String getWindTime() {
        return windTime;
    }

    @XmlElement(name = "wind_day_high_time")
    public void setWindTime(String windTime) {
        this.windTime = windTime;
    }





    public Double getDewPointMax() {
        return dewPointMax;
    }

    @XmlElement(name = "dewpoint_day_high_f")
    public void setDewPointMax(Double dewPointMax) {
        this.dewPointMax = dewPointMax;
    }

    public String getDewPointMaxTime() {
        return dewPointMaxTime;
    }

    @XmlElement(name = "dewpoint_day_high_time")
    public void setDewPointMaxTime(String dewPointMaxTime) {
        this.dewPointMaxTime = dewPointMaxTime;
    }

    public Double getDewPointMin() {
        return dewPointMin;
    }

    @XmlElement(name = "dewpoint_day_low_f")
    public void setDewPointMin(Double dewPointMin) {
        this.dewPointMin = dewPointMin;
    }

    public String getDewPointMinTime() {
        return dewPointMinTime;
    }

    @XmlElement(name = "dewpoint_day_low_time")
    public void setDewPointMinTime(String dewPointMinTime) {
        this.dewPointMinTime = dewPointMinTime;
    }

    public Double geteTranspirationDay() {
        return eTranspirationDay;
    }

    @XmlElement(name = "et_day")
    public void seteTranspirationDay(Double eTranspirationDay) {
        this.eTranspirationDay = eTranspirationDay;
    }

    public Double geteTranspirationMonth() {
        return eTranspirationMonth;
    }

    @XmlElement(name = "et_month")
    public void seteTranspirationMonth(Double eTranspirationMonth) {
        this.eTranspirationMonth = eTranspirationMonth;
    }

    public Double geteTranspirationYear() {
        return eTranspirationYear;
    }

    @XmlElement(name = "et_year")
    public void seteTranspirationYear(Double eTranspirationYear) {
        this.eTranspirationYear = eTranspirationYear;
    }

    public Double getHeatIndexDayMax() {
        return heatIndexDayMax;
    }

    @XmlElement(name = "heat_index_day_high_f")
    public void setHeatIndexDayMax(Double heatIndexDayMax) {
        this.heatIndexDayMax = heatIndexDayMax;
    }

    public String getHeatIndexDayMaxTime() {
        return heatIndexDayMaxTime;
    }

    @XmlElement(name = "heat_index_day_high_time")
    public void setHeatIndexDayMaxTime(String heatIndexDayMaxTime) {
        this.heatIndexDayMaxTime = heatIndexDayMaxTime;
    }

    public Double getRainDayMax() {
        return rainDayMax;
    }

    @XmlElement(name = "rain_day_in")
    public void setRainDayMax(Double rainDayMax) {
        this.rainDayMax = rainDayMax;
    }

    public Double getRainStorm() {
        return rainStorm;
    }

    @XmlElement(name = "rain_storm_in")
    public void setRainStorm(Double rainStorm) {
        this.rainStorm = rainStorm;
    }

    public Double getRelativeHumidityDayMax() {
        return relativeHumidityDayMax;
    }

    @XmlElement(name = "relative_humidity_day_high")
    public void setRelativeHumidityDayMax(Double relativeHumidityDayMax) {
        this.relativeHumidityDayMax = relativeHumidityDayMax;
    }

    public String getRelativeHumidityDayMaxTime() {
        return relativeHumidityDayMaxTime;
    }

    @XmlElement(name = "relative_humidity_day_high_time")
    public void setRelativeHumidityDayMaxTime(String relativeHumidityDayMaxTime) {
        this.relativeHumidityDayMaxTime = relativeHumidityDayMaxTime;
    }

    public Double getRelativeHumidityDayMin() {
        return relativeHumidityDayMin;
    }

    @XmlElement(name = "relative_humidity_day_low")
    public void setRelativeHumidityDayMin(Double relativeHumidityDayMin) {
        this.relativeHumidityDayMin = relativeHumidityDayMin;
    }

    public String getRelativeHumidityDayMinTime() {
        return relativeHumidityDayMinTime;
    }

    @XmlElement(name = "relative_humidity_day_low_time")
    public void setRelativeHumidityDayMinTime(String relativeHumidityDayMinTime) {
        this.relativeHumidityDayMinTime = relativeHumidityDayMinTime;
    }

    public String getSunrise() {
        return sunrise;
    }

    @XmlElement(name = "sunrise")
    public void setSunrise(String sunrise) {
        this.sunrise = sunrise;
    }

    public String getSunset() {
        return sunset;
    }

    @XmlElement(name = "sunset")
    public void setSunset(String sunset) {
        this.sunset = sunset;
    }

    public Double getUvIndex() {
        return uvIndex;
    }

    @XmlElement(name = "uv_index")
    public void setUvIndex(Double uvIndex) {
        this.uvIndex = uvIndex;
    }

}
