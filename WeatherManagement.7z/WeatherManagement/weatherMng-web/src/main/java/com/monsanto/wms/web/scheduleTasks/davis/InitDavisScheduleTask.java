package com.monsanto.wms.web.scheduleTasks.davis;

import com.monsanto.wms.service.catalog.MeteorologicalStationService;
import com.monsanto.wms.service.mail.MailService;
import com.monsanto.wms.service.security.UserService;
import com.monsanto.wms.service.security.UserSystemPrivilegesService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Date;
import java.util.Timer;
import java.util.TimerTask;

/**
 * Created by IntelliJ IDEA.
 * User: MANIET
 * Date: 8/1/13
 * Time: 10:44 AM
 * To change this template use File | Settings | File Templates.
 */
public class InitDavisScheduleTask {

    private Timer timer;
    private final static int MINUTES=30;
    private final static int TIME_MILLISECONDS = 1000 * 60 * MINUTES;
    private static final Logger log = LoggerFactory.getLogger(InitDavisScheduleTask.class);

    private MeteorologicalStationService meteorologicalStationService;
    private MailService mailService;
    private UserSystemPrivilegesService userSystemPrivilegesService;

    public InitDavisScheduleTask(MeteorologicalStationService meteorologicalStationService, MailService mailService,UserSystemPrivilegesService userSystemPrivilegesService) {
        this.meteorologicalStationService = meteorologicalStationService;
        this.mailService = mailService;
        this.userSystemPrivilegesService = userSystemPrivilegesService;
    }

    public void start() {

        if (meteorologicalStationService != null) {
            timer = new Timer();
            TimerTask davisTimer = new DAVISTimer(meteorologicalStationService, mailService,userSystemPrivilegesService);
            timer.scheduleAtFixedRate(davisTimer, new Date(), TIME_MILLISECONDS);
            log.info("DAVIS Station batch reader started on the " + new Date() + " and will be executed every:" + MINUTES + " Minutes");
        } else {
            log.error("DAVIS Meteorological Station Reading/Storing did not start because meteorologicalStationService is NULL");
        }
    }

    public Timer getTimer() {
        return timer;
    }
}
