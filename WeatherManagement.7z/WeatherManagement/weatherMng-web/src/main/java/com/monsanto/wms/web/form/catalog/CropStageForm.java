package com.monsanto.wms.web.form.catalog;

/**
 * Created by IntelliJ IDEA.
 * User: MANIET
 * Date: 6/3/13
 * Time: 4:00 PM
 * To change this template use File | Settings | File Templates.
 */
public class CropStageForm {


    private String cropStageDescription;

    private Boolean activeStatus;

    private Long cropStageId;

    private Boolean cropStageDefaultValue;

    private Long cropId;

    private Long cropTypeId;

    public String getCropStageDescription() {
        return cropStageDescription;
    }

    public void setCropStageDescription(String cropStageDescription) {
        this.cropStageDescription = cropStageDescription;
    }

    public Boolean getActiveStatus() {
        return activeStatus;
    }

    public void setActiveStatus(Boolean activeStatus) {
        this.activeStatus = activeStatus;
    }

    public Long getCropStageId() {
        return cropStageId;
    }

    public void setCropStageId(Long cropStageId) {
        this.cropStageId = cropStageId;
    }

    public Boolean getCropStageDefaultValue() {
        return cropStageDefaultValue;
    }

    public void setCropStageDefaultValue(Boolean cropStageDefaultValue) {
        this.cropStageDefaultValue = cropStageDefaultValue;
    }

    public Long getCropId() {
        return cropId;
    }

    public void setCropId(Long cropId) {
        this.cropId = cropId;
    }

    public Long getCropTypeId() {
        return cropTypeId;
    }

    public void setCropTypeId(Long cropTypeId) {
        this.cropTypeId = cropTypeId;
    }
}
