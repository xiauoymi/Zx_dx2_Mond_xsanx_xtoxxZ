package com.monsanto.wms.web.form.production;

import org.springframework.web.multipart.MultipartFile;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Created by GFRAN1 on 10/30/2014.
 */
public class SpectrumManualLoadForm {

    private Long meteorologicalStationId;
    private String temperatureIn;
    private Date startDate;
    private Date endDate;
    private Long batchId;
    private List<MultipartFile> files;

    public SpectrumManualLoadForm() {
        files = new ArrayList<MultipartFile>();
    }

    public Long getBatchId() {
        return batchId;
    }

    public void setBatchId(Long batchId) {
        this.batchId = batchId;
    }

    public Date getStartDate() {
        return startDate;
    }

    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    public Date getEndDate() {
        return endDate;
    }

    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }

    public Long getMeteorologicalStationId() {
        return meteorologicalStationId;
    }

    public void setMeteorologicalStationId(Long meteorologicalStationId) {
        this.meteorologicalStationId = meteorologicalStationId;
    }

    public String getTemperatureIn() {
        return temperatureIn;
    }

    public void setTemperatureIn(String temperatureIn) {
        this.temperatureIn = temperatureIn;
    }

    public List<MultipartFile> getFiles() {
        return files;
    }

    public void setFiles(List<MultipartFile> files) {
        this.files = files;
    }
}
