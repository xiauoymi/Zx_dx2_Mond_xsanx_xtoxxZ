package com.monsanto.wms.web.form.security;

/**
 * Created by IntelliJ IDEA.
 * User: MANIET
 * Date: 6/12/13
 * Time: 10:35 AM
 * To change this template use File | Settings | File Templates.
 */
public class UserAdministrationForm {

    private Long userPrivilegesId;
    private String userId;
    private Boolean activeStatus;
    private Long areaId;
    private Long roleId;

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        if(userId!=null){ this.userId = userId.toUpperCase();}
        else {this.userId = userId;}
    }

    public Boolean getActiveStatus() {
        return activeStatus;
    }

    public void setActiveStatus(Boolean activeStatus) {
        this.activeStatus = activeStatus;
    }

    public Long getAreaId() {
        return areaId!=null ? areaId : -1L;
    }

    public void setAreaId(Long areaId) {
        this.areaId = areaId;
    }

    public Long getRoleId() {
        return roleId!=null ? roleId : -1L;
    }

    public void setRoleId(Long roleId) {
        this.roleId = roleId;
    }

    public Long getUserPrivilegesId() {
        return userPrivilegesId;
    }

    public void setUserPrivilegesId(Long userPrivilegesId) {
        this.userPrivilegesId = userPrivilegesId;
    }
}
