package com.monsanto.wms.web.form.catalog;

/**
 * Created by IntelliJ IDEA.
 * User: MANIET
 * Date: 6/3/13
 * Time: 4:00 PM
 * To change this template use File | Settings | File Templates.
 */
public class ProductionZoneForm {


    private Long productionZoneId;

    private String productionZoneDescription;

    private Boolean activeStatus;


    public Long getProductionZoneId() {
        return productionZoneId;
    }

    public void setProductionZoneId(Long productionZoneId) {
        this.productionZoneId = productionZoneId;
    }

    public String getProductionZoneDescription() {
        return productionZoneDescription;
    }

    public void setProductionZoneDescription(String productionZoneDescription) {
        this.productionZoneDescription = productionZoneDescription;
    }

    public Boolean getActiveStatus() {
        return activeStatus;
    }

    public void setActiveStatus(Boolean activeStatus) {
        this.activeStatus = activeStatus;
    }

}
