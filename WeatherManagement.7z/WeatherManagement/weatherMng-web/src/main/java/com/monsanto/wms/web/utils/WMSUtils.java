package com.monsanto.wms.web.utils;

import com.monsanto.wms.spectrum.SpectrumBufferReader;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.List;

/**
 * Created by GFRAN1 on 10/29/2014.
 */
public abstract class WMSUtils {


    public static List<String[]> convertInputStreamToList(MultipartFile multipartFile,String delimiter) throws IOException {
        InputStream inputStream= multipartFile.getInputStream();
        InputStreamReader inputStreamReader = new InputStreamReader(inputStream);
       return SpectrumBufferReader.toList(inputStreamReader, 3, "\t");
    }

}
