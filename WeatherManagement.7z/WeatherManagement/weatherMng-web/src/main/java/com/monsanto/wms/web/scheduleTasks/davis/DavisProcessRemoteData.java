package com.monsanto.wms.web.scheduleTasks.davis;

import com.monsanto.wms.persistence.model.MeteorologicalStation;
import com.monsanto.wms.service.catalog.MeteorologicalStationService;
import com.monsanto.wms.service.mail.MailService;
import com.monsanto.wms.service.security.UserService;
import com.monsanto.wms.service.security.UserSystemPrivilegesService;
import com.monsanto.wms.web.scheduleTasks.davis.xmlObjects.DavisXMLReader;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: MANIET
 * Date: 8/1/13
 * Time: 10:48 AM
 * To change this template use File | Settings | File Templates.
 */
public class DavisProcessRemoteData {

    private MeteorologicalStationService meteorologicalStationService;
    private MailService mailService;
    private UserSystemPrivilegesService userSystemPrivilegesService;
    private Collection<MeteorologicalStation> davisStations;
    private static final String DAVIS_URL = "http://www.weatherlink.com/xml.php";

    public DavisProcessRemoteData(MeteorologicalStationService meteorologicalStationService,MailService mailService, UserSystemPrivilegesService userSystemPrivilegesService,Collection<MeteorologicalStation> davisStations) {
        this.davisStations = davisStations;
        this.meteorologicalStationService = meteorologicalStationService;
        this.mailService = mailService;
        this.userSystemPrivilegesService = userSystemPrivilegesService;
    }

    public void start() {

        ReadAndStoreDavisXMLFromURL readAndStoreDavisXMLFromURL = null;
        DavisStoreData davisStoreData = null;
        for (MeteorologicalStation currentItem : davisStations) {
            readAndStoreDavisXMLFromURL = new ReadAndStoreDavisXMLFromURL(DAVIS_URL,currentItem,mailService,userSystemPrivilegesService);
            DavisXMLReader davisData = readAndStoreDavisXMLFromURL.startDavisXMLReading();
            if(davisData!=null){
                davisStoreData = new DavisStoreData(meteorologicalStationService,davisData,currentItem);
                davisStoreData.start();
            }
        }
    }
}
