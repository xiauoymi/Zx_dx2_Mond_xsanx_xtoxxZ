package com.monsanto.wms.web.support;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.ResourceBundle;

/**
 * Created by IntelliJ IDEA.
 * User: CROME
 * Date: 10/17/12
 * Time: 3:02 PM
 */
public class MessagesServlet extends HttpServlet {

    private static Map<String, String> messages;

    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        if (messages == null) {
            messages = loadMessages();
        }

        StringBuilder sb = new StringBuilder();
        String line = "scpi[\"messages\"][\"%s\"]=\"%s\"; ";
        for (Map.Entry<String, String> e: messages.entrySet()) {
            sb.append(String.format(line, e.getKey(), e.getValue()));
        }
        sb.append("if (jQuery.i18n) {jQuery.i18n.setDictionary(scpi[\"messages\"]);}");
        resp.setContentType("application/javascript");
        resp.getWriter().print(sb.toString());
    }

    protected Map<String, String> loadMessages() {
        Map<String, String> m = new HashMap<String, String>(0);
        ResourceBundle rb = ResourceBundle.getBundle("messages");
        for(String e: rb.keySet()) {
            m.put(e, rb.getString(e));
        }
        return m;
    }
}
