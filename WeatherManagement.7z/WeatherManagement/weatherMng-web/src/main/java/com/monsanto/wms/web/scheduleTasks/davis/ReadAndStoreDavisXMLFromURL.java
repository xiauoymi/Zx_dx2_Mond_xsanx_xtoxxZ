package com.monsanto.wms.web.scheduleTasks.davis;

import com.monsanto.wms.exceptions.davisSchedule.DavisSpectrumScheduleException;
import com.monsanto.wms.persistence.model.MeteorologicalStation;
import com.monsanto.wms.service.mail.MailService;
import com.monsanto.wms.service.security.UserSystemPrivilegesService;
import com.monsanto.wms.spectrum.connectionItems.CreateURL;
import com.monsanto.wms.web.scheduleTasks.davis.xmlObjects.DavisXMLReader;
import com.monsanto.wms.spectrum.helpers.ProcessReadURLError;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;
import java.io.IOException;


/**
 * Created by IntelliJ IDEA.
 * User: MANIET
 * Date: 6/20/13
 * Time: 12:09 PM
 * To change this template use File | Settings | File Templates.
 */
public class ReadAndStoreDavisXMLFromURL {

    private CreateURL createURL;
    private ProcessReadURLError processReadURLError;

    private static final Logger log = LoggerFactory.getLogger(ReadAndStoreDavisXMLFromURL.class);

    public ReadAndStoreDavisXMLFromURL(String urlStr,MeteorologicalStation meteorologicalStation, MailService mailService,UserSystemPrivilegesService userSystemPrivilegesService) {
        this.createURL = new CreateURL(urlStr+"?user="+meteorologicalStation.getUserName()+"&pass="+meteorologicalStation.getPwd());
        this.processReadURLError = new ProcessReadURLError(mailService,userSystemPrivilegesService,meteorologicalStation,urlStr);
    }


    public DavisXMLReader startDavisXMLReading() {

        DavisXMLReader davisXMLReader = getInfo();

        return davisXMLReader;
    }

    private DavisXMLReader getInfo() {

        if (createURL.getValidURL()) {
            try {
                JAXBContext jaxbContext = null;

                log.debug("Starting XML reading for DAVIS stations for " + this.createURL.getUrl());

                jaxbContext = JAXBContext.newInstance(DavisXMLReader.class);
                Unmarshaller unmarshaller = jaxbContext.createUnmarshaller();
                DavisXMLReader davisXMLReader = (DavisXMLReader) unmarshaller.unmarshal(createURL.getUrl().openStream());

                log.debug("Reading complete for DAVIS in the url:" + this.createURL.getUrl());

                return davisXMLReader;

            } catch (JAXBException e) {

                e.printStackTrace();
                log.error("Error while reading the XML for DAVIS stations in the url:" + this.createURL.getUrl());
                log.error(e.getMessage());
                processReadURLError.sendErrorToDistributionList(e, DavisSpectrumScheduleException.DAVIS);

            } catch (IOException e) {
                e.printStackTrace();
                log.error("Error while reading the XML for DAVIS stations in the url:" + this.createURL.getUrl());
                log.error(e.getMessage());
                processReadURLError.sendErrorToDistributionList(e,DavisSpectrumScheduleException.DAVIS);
            }

        }
        return null;
    }

}
