package com.monsanto.wms.web.controller.production;


import com.monsanto.wms.excel.manager.vo.FileLoadResultVO;
import com.monsanto.wms.exceptions.excel.ExcelLoadErrorException;
import com.monsanto.wms.exceptions.excel.InvalidDataException;
import com.monsanto.wms.exceptions.excel.InvalidLayoutException;
import com.monsanto.wms.persistence.model.MeteorologicalStationHistoric;
import com.monsanto.wms.service.catalog.MeteorologicalStationService;
import com.monsanto.wms.service.xls.MeteorologicalStationManualLoadService;
import com.monsanto.wms.web.controller.commons.BaseController;
import com.monsanto.wms.web.form.production.MetStationManualLoadForm;
import com.monsanto.wms.web.utils.HSSFManualLoadFile;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.MessageSource;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by IntelliJ IDEA.
 * User: MANIET
 * Date: 6/3/13
 * Time: 3:58 PM
 * To change this template use File | Settings | File Templates.
 */
@Controller
@RequestMapping("/production/metStationManualLoadBase")
public final class MetStationManualLoadController extends BaseController {

    private static final String MANUAL_LOAD_BASE = "production/metStationManualLoadBase";
    private static final String REDIRECT_INIT_VIEW = "redirect:/production/metStationManualLoadBase/init.do";

    private MeteorologicalStationManualLoadService meteorologicalStationManualLoadService;
    private MeteorologicalStationService meteorologicalStationService;

    @Autowired
    public MetStationManualLoadController(MeteorologicalStationManualLoadService meteorologicalStationManualLoadService, MeteorologicalStationService meteorologicalStationService, @Qualifier("messageSource") MessageSource messageSource) {
        super();
        this.meteorologicalStationManualLoadService = meteorologicalStationManualLoadService;
        this.meteorologicalStationService = meteorologicalStationService;
        setMessageSource(messageSource);
    }

    @RequestMapping("/init")
    public ModelAndView initView(HttpServletRequest request) {

        String sMsg = request.getParameter("msg");
        Boolean success = validateResultRequestParameter(request);

        Map<String, Object> model = new HashMap<String, Object>();
        MetStationManualLoadForm form = new MetStationManualLoadForm();

        model.put(DATA_FORM, form);
        model.put("success", success);
        model.put("msg", sMsg);

        return new ModelAndView(MANUAL_LOAD_BASE, model);
    }

    @RequestMapping("/importData")
    public String importData(@ModelAttribute("dataForm") MetStationManualLoadForm form) {
        try {
            HSSFManualLoadFile hssfManualLoadFile = new HSSFManualLoadFile(form.getFiles().get(0).getInputStream(), form.getMetStationId(), form.getDay(), form.getMonth(), form.getYear());
            FileLoadResultVO fileLoadResultVO = meteorologicalStationManualLoadService.importData(hssfManualLoadFile.getManualLoadFile(), form.getMetStationId(), form.getDay(), form.getMonth(), form.getYear());

            return REDIRECT_INIT_VIEW + "?success=true&msg=The file was uploaded and saved successfully, " + fileLoadResultVO.getInsertedRows() + " registries were inserted";
        } catch (InvalidLayoutException e) {
            return REDIRECT_INIT_VIEW + "?success=false&msg=" + e.getErrorAsList();
        } catch (ExcelLoadErrorException e) {
            return REDIRECT_INIT_VIEW + "?success=false&msg=" + e.getErrorAsList();
        } catch (InvalidDataException e) {
            return REDIRECT_INIT_VIEW + "?success=false&msg=" + e.getErrorsAsList();
        } catch (IOException e) {
            return REDIRECT_INIT_VIEW + "?success=false&msg=" + e.getMessage();
        }
    }


    @RequestMapping(value = "/export")
    @ResponseBody
    public ModelAndView export(@RequestParam Long metStationId,
                               @RequestParam Integer day,
                               @RequestParam Integer month,
                               @RequestParam Integer year,
                               @RequestParam String tempType) {
        Page<MeteorologicalStationHistoric> result = meteorologicalStationService.search(day, month, year, metStationId, null);
        if (result != null && !result.getContent().isEmpty()) {
            Map<String, Object> model = new HashMap<String, Object>();
            model.put("dataList", result.getContent());
            model.put("tempType", tempType);

            return new ModelAndView("manualLoadExcelView", "excelData", model);
        }

        return null;

    }


    @RequestMapping("/search")
    @ResponseBody
    public Page<MeteorologicalStationHistoric> search(@ModelAttribute("dataForm") MetStationManualLoadForm form, Pageable pageable) {
        return meteorologicalStationService.search(form.getDay(), form.getMonth(), form.getYear(), form.getMetStationId(), pageable);
    }


}
