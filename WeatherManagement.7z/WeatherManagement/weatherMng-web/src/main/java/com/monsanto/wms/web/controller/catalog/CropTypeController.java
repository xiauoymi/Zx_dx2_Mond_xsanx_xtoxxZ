package com.monsanto.wms.web.controller.catalog;

import com.monsanto.wms.persistence.model.CropType;
import com.monsanto.wms.service.catalog.CropTypeService;
import com.monsanto.wms.web.controller.commons.BaseController;
import com.monsanto.wms.web.form.catalog.CropTypeForm;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.MessageSource;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by IntelliJ IDEA.
 * User: MANIET
 * Date: 6/3/13
 * Time: 3:58 PM
 * To change this template use File | Settings | File Templates.
 */
@Controller
@RequestMapping("/catalog/cropTypeBase")
public final class CropTypeController extends BaseController {

    public static final String CROP_TYPE_BASE = "catalog/cropTypeBase";

    private CropTypeService cropTypeService;

    @Autowired
    public CropTypeController(CropTypeService cropTypeService, @Qualifier("messageSource") MessageSource messageSource) {
        super();
        this.cropTypeService = cropTypeService;
        setMessageSource(messageSource);
    }

    @RequestMapping("/init")
    public ModelAndView initView() {
        Map<String, Object> model = new HashMap<String, Object>();

        model.put(DATA_FORM, new CropTypeForm());
        return new ModelAndView(CROP_TYPE_BASE, model);
    }

    @RequestMapping("/saveOrUpdate")
    @ResponseBody
    public ResponseEntity<GenericResponse> saveOrUpdate(@ModelAttribute CropTypeForm form) {

        cropTypeService.save(new CropType(form.getCropTypeId(), form.getCropTypeDescription(), form.getActiveStatus()));

        return new ResponseEntity<GenericResponse>(new GenericResponse(true, getMessage(SAVE_OPERATION_SUCCEEDED)), HttpStatus.OK);
    }

    @RequestMapping("/search")
    @ResponseBody
    public Page<CropType> search(@ModelAttribute CropTypeForm form, Pageable pageable) {
        return cropTypeService.search(form.getCropTypeDescription(), form.getActiveStatus(), pageable);
    }

    @RequestMapping(value = "/findById")
    @ResponseBody
    public CropType findById(@RequestParam Long id) {
        return cropTypeService.findById(id);
    }


    @RequestMapping(value = "/delete")
    @ResponseBody
    public ResponseEntity<GenericResponse> delete(@RequestParam Long id) {

        cropTypeService.delete(id);

        return new ResponseEntity<GenericResponse>(new GenericResponse(true, getMessage(DELETE_OPERATION_SUCCEEDED)), HttpStatus.OK);
    }

    @RequestMapping(value = "/loadCollection")
    @ResponseBody
    public Collection<CropType> loadCollection() {

        return cropTypeService.loadCollection();

    }

}
