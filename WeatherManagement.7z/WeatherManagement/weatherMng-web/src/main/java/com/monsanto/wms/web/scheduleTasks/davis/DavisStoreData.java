package com.monsanto.wms.web.scheduleTasks.davis;

import com.monsanto.wms.persistence.model.MeteorologicalStation;
import com.monsanto.wms.persistence.model.MeteorologicalStationHistoric;
import com.monsanto.wms.service.catalog.MeteorologicalStationService;
import com.monsanto.wms.util.WMSServiceUtil;
import com.monsanto.wms.web.scheduleTasks.davis.xmlObjects.DavisXMLReader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Calendar;
import java.util.Date;

/**
 * Created by IntelliJ IDEA.
 * User: MANIET
 * Date: 8/1/13
 * Time: 10:50 AM
 * To change this template use File | Settings | File Templates.
 */
public class DavisStoreData {

    private static final Logger log = LoggerFactory.getLogger(DavisStoreData.class);

    private MeteorologicalStationService meteorologicalStationService;
    private DavisXMLReader davisData;
    private MeteorologicalStation meteorologicalStation;

    public DavisStoreData(MeteorologicalStationService meteorologicalStationService, DavisXMLReader davisData, MeteorologicalStation meteorologicalStation) {
        this.meteorologicalStationService = meteorologicalStationService;
        this.davisData = davisData;
        this.meteorologicalStation = meteorologicalStation;
    }

    public void start(){
        Calendar currentDateAndTime = Calendar.getInstance();
        try{
            MeteorologicalStationHistoric meteorologicalStationHistoric = createMeteorologicalHistObj(davisData, meteorologicalStation, currentDateAndTime);
            meteorologicalStationService.save(meteorologicalStationHistoric);
        }catch (Exception e){
            e.printStackTrace();
            log.error("DAVIS Station data can not be saved: "+meteorologicalStation.getDescription()+" Date:"+new Date());
        }

    }

    private MeteorologicalStationHistoric createMeteorologicalHistObj(DavisXMLReader davisData,MeteorologicalStation meteorologicalStation, Calendar currentDateAndTime){

        String timeRegistry = maskTwoNumbers(currentDateAndTime.get(Calendar.HOUR_OF_DAY))+":"
                                                    + maskTwoNumbers(currentDateAndTime.get(Calendar.MINUTE))+":"
                                                    + maskTwoNumbers(currentDateAndTime.get(Calendar.SECOND));

        MeteorologicalStationHistoric meteorologicalStationHistoric = new MeteorologicalStationHistoric(
                                        meteorologicalStation,
                                        currentDateAndTime.get(Calendar.DAY_OF_MONTH),
                                        currentDateAndTime.get(Calendar.MONTH)+1,
                                        currentDateAndTime.get(Calendar.YEAR),
                                        timeRegistry,
                                        WMSServiceUtil.fahrenheitToCelsius(davisData.getDavisStationDetails().getMinTempF()),
                                        davisData.getDavisStationDetails().getMinTempTime(),
                                        WMSServiceUtil.fahrenheitToCelsius(davisData.getDavisStationDetails().getMaxTempF()),
                                        davisData.getDavisStationDetails().getMaxTempTime(),
                                        davisData.getDavisStationDetails().getMaxPressure(),
                                        davisData.getDavisStationDetails().getMaxPressureTime(),
                                        davisData.getDavisStationDetails().getMinPressure(),
                                        davisData.getDavisStationDetails().getMinPressureTime(),
                                        davisData.getDavisStationDetails().getRain(),
                                        davisData.getDavisStationDetails().getRadiation(),
                                        davisData.getDavisStationDetails().getRadiationTime(),
                                        davisData.getDavisStationDetails().getWind(),
                                        davisData.getDavisStationDetails().getWindTime(),
                                        davisData.getDavisStationDetails().getDewPointMax(),
                                        davisData.getDavisStationDetails().getDewPointMaxTime(),
                                        davisData.getDavisStationDetails().getDewPointMin(),
                                        davisData.getDavisStationDetails().getDewPointMinTime(),
                                        davisData.getDavisStationDetails().geteTranspirationDay(),
                                        davisData.getDavisStationDetails().geteTranspirationMonth(),
                                        davisData.getDavisStationDetails().geteTranspirationYear(),
                                        davisData.getDavisStationDetails().getHeatIndexDayMax(),
                                        davisData.getDavisStationDetails().getHeatIndexDayMaxTime(),
                                        davisData.getDavisStationDetails().getRainDayMax(),
                                        davisData.getDavisStationDetails().getRainStorm(),
                                        davisData.getDavisStationDetails().getRelativeHumidityDayMax(),
                                        davisData.getDavisStationDetails().getRelativeHumidityDayMaxTime(),
                                        davisData.getDavisStationDetails().getRelativeHumidityDayMin(),
                                        davisData.getDavisStationDetails().getRelativeHumidityDayMinTime(),
                                        davisData.getDavisStationDetails().getSunrise(),
                                        davisData.getDavisStationDetails().getSunset(),
                                        davisData.getDavisStationDetails().getUvIndex(),
                                        davisData.getLongitude(),
                                        davisData.getLatitude()
                                    );

        return meteorologicalStationHistoric;

    }

    private String maskTwoNumbers(Integer number){

        if(number<10) return "0"+number;
        else return ""+number;

    }
}
