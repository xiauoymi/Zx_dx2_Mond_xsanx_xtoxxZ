package com.monsanto.wms.web.scheduleTasks.davis;

import com.monsanto.wms.persistence.model.MeteorologicalStation;
import com.monsanto.wms.service.catalog.MeteorologicalStationService;
import com.monsanto.wms.service.mail.MailService;
import com.monsanto.wms.service.security.UserSystemPrivilegesService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Collection;
import java.util.Date;
import java.util.TimerTask;

/**
 * Created by IntelliJ IDEA.
 * User: MANIET
 * Date: 7/9/13
 * Time: 8:54 AM
 * To change this template use File | Settings | File Templates.
 */
public class DAVISTimer extends TimerTask {


    private MeteorologicalStationService meteorologicalStationService;
    private MailService mailService;
    private UserSystemPrivilegesService userSystemPrivilegesService;
    private static final Logger log = LoggerFactory.getLogger(DAVISTimer.class);


    public DAVISTimer(MeteorologicalStationService meteorologicalStationService,MailService mailService,UserSystemPrivilegesService userSystemPrivilegesService) {
        this.meteorologicalStationService = meteorologicalStationService;
        this.mailService = mailService;
        this.userSystemPrivilegesService = userSystemPrivilegesService;
    }

    @Override
    public void run() {
        log.info("DAVIS XML reading started on:"+new Date());
        Collection<MeteorologicalStation> davisStations = getDavisStations();
        DavisProcessRemoteData davisProcessRemoteData = null;
        if(davisStations!=null){
            davisProcessRemoteData = new DavisProcessRemoteData(meteorologicalStationService,mailService,userSystemPrivilegesService,davisStations);
            davisProcessRemoteData.start();
        }
        System.out.println("RUNNING DAVISTimer..."+ new Date());
    }

    private Collection<MeteorologicalStation> getDavisStations() {
        try {
            return meteorologicalStationService.findByTypeStationsWithUsrPwd(MeteorologicalStation.DAVIS);
        } catch (Exception e) {
            e.printStackTrace();
            log.error("DAVIS Station could not be retrieved");
            return null;
        }
    }

}
