package com.monsanto.wms.web.scheduleTasks.spectrum;

import com.monsanto.wms.exceptions.schedule.spectrum.SpectrumListenerInitializationException;
import com.monsanto.wms.service.catalog.MeteorologicalStationService;
import com.monsanto.wms.service.mail.MailService;
import com.monsanto.wms.service.security.UserSystemPrivilegesService;
import com.monsanto.wms.service.sheduleTasks.ScheduleErrorService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import javax.servlet.ServletContextEvent;

/**
 * Created by IntelliJ IDEA.
 * User: MANIET
 * Date: 8/1/13
 * Time: 10:41 AM
 * To change this template use File | Settings | File Templates.
 */
public class InitStationRequiredServices {

    private static final Logger log = LoggerFactory.getLogger(InitStationRequiredServices.class);

    public static MeteorologicalStationService getStationService(ServletContextEvent servletContextEvent) {

        final WebApplicationContext springContext = WebApplicationContextUtils.getWebApplicationContext(servletContextEvent.getServletContext());
        final MeteorologicalStationService meteorologicalStationService = (MeteorologicalStationService) springContext.getBean("meteorologicalStationService");

        verifyCorrectServiceInitialization(meteorologicalStationService, "meteorologicalStationService");

        return meteorologicalStationService;

    }

    public static MailService getMailService(ServletContextEvent servletContextEvent) {

        final WebApplicationContext springContext = WebApplicationContextUtils.getWebApplicationContext(servletContextEvent.getServletContext());
        final MailService mailService = (MailService) springContext.getBean("mailService");

        verifyCorrectServiceInitialization(mailService, "mailService");

        return mailService;

    }

    public static UserSystemPrivilegesService getUserSystemPrivilegesService(ServletContextEvent servletContextEvent) {

        final WebApplicationContext springContext = WebApplicationContextUtils.getWebApplicationContext(servletContextEvent.getServletContext());
        final UserSystemPrivilegesService userSystemPrivilegesService = (UserSystemPrivilegesService) springContext.getBean("userSystemPrivilegesService");

        verifyCorrectServiceInitialization(userSystemPrivilegesService, "userSystemPrivilegesService");

        return userSystemPrivilegesService;

    }

    public static ScheduleErrorService getScheduleErrorService(ServletContextEvent servletContextEvent) {
        final WebApplicationContext springContext = WebApplicationContextUtils.getWebApplicationContext(servletContextEvent.getServletContext());
        final ScheduleErrorService scheduleErrorService = (ScheduleErrorService) springContext.getBean("scheduleErrorService");

        verifyCorrectServiceInitialization(scheduleErrorService, "scheduleErrorService");

        return scheduleErrorService;

    }

    private static void verifyCorrectServiceInitialization(Object service, String serviceName) {
        if (service == null) {
            throw new SpectrumListenerInitializationException("Spectrum " + serviceName + " initialization failed");
        }
    }


}
