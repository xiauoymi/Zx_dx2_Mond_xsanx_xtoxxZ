package com.monsanto.wms.web.scheduleTasks.listeners;

import com.monsanto.wms.exceptions.schedule.spectrum.SpectrumListenerInitializationException;
import com.monsanto.wms.service.catalog.MeteorologicalStationService;
import com.monsanto.wms.service.mail.MailService;
import com.monsanto.wms.service.security.UserSystemPrivilegesService;
import com.monsanto.wms.service.sheduleTasks.ScheduleErrorService;
import com.monsanto.wms.web.scheduleTasks.spectrum.InitStationRequiredServices;
import com.monsanto.wms.spectrum.SpectrumScheduleTask;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import java.util.Date;

/**
 * Created by IntelliJ IDEA.
 * User: MANIET
 * Date: 7/9/13
 * Time: 10:49 AM
 * To change this template use File | Settings | File Templates.
 */
@Component
public class SpectrumListener implements ServletContextListener {

    private SpectrumScheduleTask spectrumScheduleTask;
    private static final Logger log = LoggerFactory.getLogger(SpectrumListener.class);

    @Override
    public void contextInitialized(ServletContextEvent servletContextEvent) {

        final MeteorologicalStationService meteorologicalStationService = InitStationRequiredServices.getStationService(servletContextEvent);
        final MailService mailService = InitStationRequiredServices.getMailService(servletContextEvent);
        final UserSystemPrivilegesService userSystemPrivilegesService = InitStationRequiredServices.getUserSystemPrivilegesService(servletContextEvent);
        final ScheduleErrorService errorService = InitStationRequiredServices.getScheduleErrorService(servletContextEvent);

        if(validateInitializationOfServices(meteorologicalStationService,mailService,userSystemPrivilegesService)){
            spectrumScheduleTask = new SpectrumScheduleTask(meteorologicalStationService,mailService,userSystemPrivilegesService,errorService);
            spectrumScheduleTask.start();
        }

    }

    private Boolean validateInitializationOfServices(MeteorologicalStationService meteorologicalStationService, MailService mailService, UserSystemPrivilegesService userSystemPrivilegesService){
        if(meteorologicalStationService !=null && mailService!=null && userSystemPrivilegesService!=null){
            return true;
        }else{
            throw new SpectrumListenerInitializationException("Spectrum Listener Fail on the services initialization");
        }
    }

    @Override
    public void contextDestroyed(ServletContextEvent servletContextEvent) {
        log.info("SPECTRUM Station batch reader stopped  on the " + new Date() + " restart the server to run this process again");
        spectrumScheduleTask.cancelScheduleTask();
        log.info("SPECTRUM batch process destroyed");
    }

    public SpectrumScheduleTask getSpectrumScheduleTask() {
        return spectrumScheduleTask;
    }
}
