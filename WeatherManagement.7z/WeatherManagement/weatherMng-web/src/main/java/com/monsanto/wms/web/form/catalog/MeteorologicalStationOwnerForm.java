package com.monsanto.wms.web.form.catalog;

/**
 * Created by IntelliJ IDEA.
 * User: MANIET
 * Date: 6/3/13
 * Time: 4:00 PM
 * To change this template use File | Settings | File Templates.
 */
public class MeteorologicalStationOwnerForm {

    private Long meteorologicalStationOwnerId;

    private String meteorologicalStationOwnerDescription;

    private String meteorologicalStationOwnerShortDescription;

    private Boolean activeStatus;

    private Long areaId;


    public Long getMeteorologicalStationOwnerId() {
        return meteorologicalStationOwnerId;
    }

    public void setMeteorologicalStationOwnerId(Long meteorologicalStationOwnerId) {
        this.meteorologicalStationOwnerId = meteorologicalStationOwnerId;
    }

    public String getMeteorologicalStationOwnerDescription() {
        return meteorologicalStationOwnerDescription;
    }

    public void setMeteorologicalStationOwnerDescription(String meteorologicalStationOwnerDescription) {
        this.meteorologicalStationOwnerDescription = meteorologicalStationOwnerDescription;
    }

    public Boolean getActiveStatus() {
        return activeStatus;
    }

    public void setActiveStatus(Boolean activeStatus) {
        this.activeStatus = activeStatus;
    }

    public String getMeteorologicalStationOwnerShortDescription() {
        return meteorologicalStationOwnerShortDescription;
    }

    public void setMeteorologicalStationOwnerShortDescription(String meteorologicalStationOwnerShortDescription) {
        this.meteorologicalStationOwnerShortDescription = meteorologicalStationOwnerShortDescription;
    }

    public Long getAreaId() {
        return areaId;
    }

    public void setAreaId(Long areaId) {
        this.areaId = areaId;
    }
}
