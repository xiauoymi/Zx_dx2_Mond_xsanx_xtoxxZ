package com.monsanto.wms.web.form.catalog;

/**
 * Created by IntelliJ IDEA.
 * User: MANIET
 * Date: 6/3/13
 * Time: 4:00 PM
 * To change this template use File | Settings | File Templates.
 */
public class HybridForm {


    private String hybridDescription;

    private Boolean activeStatus;

    private Long hybridId;

    private Long cropId;

    private Long cropTypeId;


    public String getHybridDescription() {
        return hybridDescription;
    }

    public void setHybridDescription(String hybridDescription) {
        this.hybridDescription = hybridDescription;
    }

    public Boolean getActiveStatus() {
        return activeStatus;
    }

    public void setActiveStatus(Boolean activeStatus) {
        this.activeStatus = activeStatus;
    }

    public Long getHybridId() {
        return hybridId;
    }

    public void setHybridId(Long hybridId) {
        this.hybridId = hybridId;
    }

    public Long getCropId() {
        return cropId;
    }

    public void setCropId(Long cropId) {
        this.cropId = cropId;
    }

    public Long getCropTypeId() {
        return cropTypeId;
    }

    public void setCropTypeId(Long cropTypeId) {
        this.cropTypeId = cropTypeId;
    }
}
