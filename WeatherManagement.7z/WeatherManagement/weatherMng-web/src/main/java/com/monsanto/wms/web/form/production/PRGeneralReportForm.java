package com.monsanto.wms.web.form.production;

/**
 * Created by IntelliJ IDEA.
 * User: MANIET
 * Date: 8/5/13
 * Time: 10:30 AM
 * To change this template use File | Settings | File Templates.
 */
public class PRGeneralReportForm {
    private Integer yearIni;
    private Integer yearEnd;
    private Integer monthIni;
    private Integer monthEnd;
    private Integer dayIni;
    private Integer dayEnd;
    private Long metStationOwnerId;
    private Long meteorologicalStationId;
    private String meteorologicalStationDesc;
    private Double tempMin;
    private Double tempMax;
    private Long cropType;
    private Long cropId;
    private String cropName;
    private Double tempAbove;
    private Double tempUnder;
    private String temperatureIn;
    private String longitude;
    private String latitude;

    public Integer getYearIni() {
        return yearIni;
    }

    public void setYearIni(Integer yearIni) {
        this.yearIni = yearIni;
    }

    public Integer getYearEnd() {
        return yearEnd;
    }

    public void setYearEnd(Integer yearEnd) {
        this.yearEnd = yearEnd;
    }

    public Integer getMonthIni() {
        return monthIni;
    }

    public void setMonthIni(Integer monthIni) {
        this.monthIni = monthIni;
    }

    public Integer getMonthEnd() {
        return monthEnd;
    }

    public void setMonthEnd(Integer monthEnd) {
        this.monthEnd = monthEnd;
    }

    public Integer getDayIni() {
        return dayIni;
    }

    public void setDayIni(Integer dayIni) {
        this.dayIni = dayIni;
    }

    public Integer getDayEnd() {
        return dayEnd;
    }

    public void setDayEnd(Integer dayEnd) {
        this.dayEnd = dayEnd;
    }

    public Long getMetStationOwnerId() {
        return metStationOwnerId;
    }

    public void setMetStationOwnerId(Long metStationOwnerId) {
        this.metStationOwnerId = metStationOwnerId;
    }

    public Long getMeteorologicalStationId() {
        return meteorologicalStationId;
    }

    public void setMeteorologicalStationId(Long meteorologicalStationId) {
        this.meteorologicalStationId = meteorologicalStationId;
    }

    public String getMeteorologicalStationDesc() {
        return meteorologicalStationDesc;
    }

    public void setMeteorologicalStationDesc(String meteorologicalStationDesc) {
        this.meteorologicalStationDesc = meteorologicalStationDesc;
    }

    public Double getTempMin() {
        return tempMin;
    }

    public void setTempMin(Double tempMin) {
        this.tempMin = tempMin;
    }

    public Double getTempMax() {
        return tempMax;
    }

    public void setTempMax(Double tempMax) {
        this.tempMax = tempMax;
    }

    public Long getCropType() {
        return cropType;
    }

    public void setCropType(Long cropType) {
        this.cropType = cropType;
    }

    public Long getCropId() {
        return cropId;
    }

    public void setCropId(Long cropId) {
        this.cropId = cropId;
    }

    public String getCropName() {
        return cropName;
    }

    public void setCropName(String cropName) {
        this.cropName = cropName;
    }

    public Double getTempAbove() {
        if(tempAbove!=null){
            return tempAbove;
        }else{
            return tempMax;
        }
    }

    public void setTempAbove(Double tempAbove) {
        this.tempAbove = tempAbove;
    }

    public Double getTempUnder() {
        if(tempUnder!=null){
            return tempUnder;
        }else{
            return tempMin;
        }

    }

    public void setTempUnder(Double tempUnder) {
        this.tempUnder = tempUnder;
    }

    public String getTemperatureIn() {
        return temperatureIn;
    }

    public void setTemperatureIn(String temperatureIn) {
        this.temperatureIn = temperatureIn;
    }

    public String getLongitude() {
        return longitude;
    }

    public void setLongitude(String longitude) {
        this.longitude = longitude;
    }

    public String getLatitude() {
        return latitude;
    }

    public void setLatitude(String latitude) {
        this.latitude = latitude;
    }
}
