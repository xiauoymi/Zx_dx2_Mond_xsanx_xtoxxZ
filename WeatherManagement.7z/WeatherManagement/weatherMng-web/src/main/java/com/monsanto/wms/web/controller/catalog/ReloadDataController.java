package com.monsanto.wms.web.controller.catalog;

import com.monsanto.wms.persistence.model.ErrorLogView;
import com.monsanto.wms.persistence.model.MeteorologicalStationHistoric;
import com.monsanto.wms.service.catalog.ReloadDataService;
import com.monsanto.wms.util.WMSServiceUtil;
import com.monsanto.wms.web.controller.commons.BaseController;
import com.monsanto.wms.web.form.catalog.ReloadDataForm;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.MessageSource;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by IntelliJ IDEA.
 * User: MANIET
 * Date: 6/3/13
 * Time: 3:58 PM
 * To change this template use File | Settings | File Templates.
 */
@Controller
@RequestMapping("/catalog/metStationReloadData")
public final class ReloadDataController extends BaseController {

    public static final String  EXISTING_DATA = "Data already exist, Do you want to proceed?";
    private static final String RELOAD_DATA_BASE = "/catalog/metStationReloadData";

    private ReloadDataService reloadDataService;


    @Autowired
    public ReloadDataController(ReloadDataService reloadDataService, @Qualifier("messageSource") MessageSource messageSource) {
        super();
        this.reloadDataService = reloadDataService ;
        setMessageSource(messageSource);

    }



    @RequestMapping("/init")
    public ModelAndView initView(HttpServletRequest request) {

        String sMsg = request.getParameter("msg");
        Boolean success = validateResultRequestParameter(request);

        Map<String, Object> model = new HashMap<String, Object>();
        ReloadDataForm form = new ReloadDataForm();

        model.put(DATA_FORM, form);
        model.put("success", success);
        model.put("msg", sMsg);

        return new ModelAndView(RELOAD_DATA_BASE, model);
    }

    @RequestMapping(value="/fillData", produces = "application/json")
    @ResponseBody
    public GenericResponse fillData(@ModelAttribute ReloadDataForm form) throws IOException, SQLException {
        Long batchId =reloadDataService.reloadMeteorologicalData(form.getMeteorologicalStationId(),form.getStartDate());
        String [] messages = new String[] {""+batchId};
        GenericResponse gr;
        if(batchId > 0){
            gr=new GenericResponse(false,messages);
        }
        else{
            gr= new GenericResponse(true,messages);
        }
        return gr;
    }

    @RequestMapping(value="/getDataLoaderLog", produces = "application/json")
    @ResponseBody
    public Page<ErrorLogView> getDataLoaderLog(@RequestParam Long batchId,Pageable pageable) throws IOException {
        return reloadDataService.getErrorsDataLoader(batchId, pageable);
    }

    @RequestMapping("/validateHistoricData")
    @ResponseBody
    public GenericResponse getHistoricData(@ModelAttribute ReloadDataForm form) throws ParseException {
        String [] messages = new String[]{""};
        List<MeteorologicalStationHistoric> meteorologicalStationHistoricList = reloadDataService.getMeteorologicalHistoricData(form.getMeteorologicalStationId(), WMSServiceUtil.getDay(form.getStartDate()),                                                                               WMSServiceUtil.getMonth(form.getStartDate()),WMSServiceUtil.getYear(form.getStartDate()));
       if(!meteorologicalStationHistoricList.isEmpty()){
           messages =  new String[] {EXISTING_DATA};
       }
        return new GenericResponse(true,messages);
    }

}

