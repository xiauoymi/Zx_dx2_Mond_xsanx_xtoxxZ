package com.monsanto.wms.web.form.catalog;

import java.util.Date;

/**
 * Created with IntelliJ IDEA.
 * User: GFRAN1
 * Date: 7/21/14
 * Time: 2:58 PM
 * To change this template use File | Settings | File Templates.
 */
public class PRExtrapolateDataForm {

    private Long meteorologicalStationId;
    private Date startDate;
    private Date endDate;
    private Integer days;


    public Long getMeteorologicalStationId() {
        return meteorologicalStationId;
    }

    public void setMeteorologicalStationId(Long meteorologicalStationId) {
        this.meteorologicalStationId = meteorologicalStationId;
    }

    public Date getStartDate() {
        return startDate;
    }

    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    public Date getEndDate() {
        return endDate;
    }

    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }

    public Integer getDays() {
        return days;
    }

    public void setDays(Integer days) {
        this.days = days;
    }
}
