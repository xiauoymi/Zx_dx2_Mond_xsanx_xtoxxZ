package com.monsanto.wms.web.form.catalog;

/**
 * Created by IntelliJ IDEA.
 * User: MANIET
 * Date: 6/3/13
 * Time: 4:00 PM
 * To change this template use File | Settings | File Templates.
 */
public class MeteorologicalStationForm {


    private Long meteorologicalStationId;
    private String meteorologicalStationDescription;
    private String meteorologicalStationLongitude;
    private String meteorologicalStationLatitude;
    private Boolean activeStatus;
    private Long ownerId;
    private String meteorologicalStationUser;
    private String meteorologicalStationPwd;
    private Long stationTypeId;
    private String stationSerialNumber;
    private String responsible;


    public Long getMeteorologicalStationId() {
        return meteorologicalStationId;
    }

    public void setMeteorologicalStationId(Long meteorologicalStationId) {
        this.meteorologicalStationId = meteorologicalStationId;
    }

    public String getMeteorologicalStationDescription() {
        return meteorologicalStationDescription;
    }

    public void setMeteorologicalStationDescription(String meteorologicalStationDescription) {
        this.meteorologicalStationDescription = meteorologicalStationDescription;
    }

    public String getMeteorologicalStationLongitude() {
        return meteorologicalStationLongitude;
    }

    public void setMeteorologicalStationLongitude(String meteorologicalStationLongitude) {
        this.meteorologicalStationLongitude = meteorologicalStationLongitude;
    }

    public String getMeteorologicalStationLatitude() {
        return meteorologicalStationLatitude;
    }

    public void setMeteorologicalStationLatitude(String meteorologicalStationLatitude) {
        this.meteorologicalStationLatitude = meteorologicalStationLatitude;
    }

    public Boolean getActiveStatus() {
        return activeStatus;
    }

    public void setActiveStatus(Boolean activeStatus) {
        this.activeStatus = activeStatus;
    }

    public Long getOwnerId() {
        return ownerId;
    }

    public void setOwnerId(Long ownerId) {
        this.ownerId = ownerId;
    }

    public String getMeteorologicalStationUser() {
        return meteorologicalStationUser;
    }

    public void setMeteorologicalStationUser(String meteorologicalStationUser) {
        this.meteorologicalStationUser = meteorologicalStationUser;
    }

    public String getMeteorologicalStationPwd() {
        return meteorologicalStationPwd;
    }

    public void setMeteorologicalStationPwd(String meteorologicalStationPwd) {
        this.meteorologicalStationPwd = meteorologicalStationPwd;
    }

    public Long getStationTypeId() {
        return stationTypeId;
    }

    public void setStationTypeId(Long stationTypeId) {
        this.stationTypeId = stationTypeId;
    }

    public String getStationSerialNumber() {
        return stationSerialNumber;
    }

    public void setStationSerialNumber(String stationSerialNumber) {
        this.stationSerialNumber = stationSerialNumber;
    }

    public String getResponsible() {
        return responsible;
    }

    public void setResponsible(String responsible) {
        this.responsible = responsible;
    }
}
