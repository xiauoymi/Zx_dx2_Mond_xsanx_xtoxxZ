package com.monsanto.wms.web.controller.catalog;


import com.monsanto.wms.persistence.model.MeteorologicalStation;
import com.monsanto.wms.persistence.model.StationType;
import com.monsanto.wms.service.catalog.MeteorologicalStationService;
import com.monsanto.wms.web.controller.commons.BaseController;
import com.monsanto.wms.web.form.catalog.MeteorologicalStationForm;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.MessageSource;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by IntelliJ IDEA.
 * User: MANIET
 * Date: 6/3/13
 * Time: 3:58 PM
 * To change this template use File | Settings | File Templates.
 */
@Controller
@RequestMapping("/catalog/meteoroStationBase")
public final class MeteorologicalStationController extends BaseController {

    public static final String METEORO_BASE = "catalog/meteoroStationBase";

    private MeteorologicalStationService meteorologicalStationService;

    @Autowired
    public MeteorologicalStationController(MeteorologicalStationService meteorologicalStationService, @Qualifier("messageSource") MessageSource messageSource) {
        super();
        this.meteorologicalStationService = meteorologicalStationService;
        setMessageSource(messageSource);
    }

    @RequestMapping("/init")
    public ModelAndView initView() {
        Map<String, Object> model = new HashMap<String, Object>();

        model.put(DATA_FORM, new MeteorologicalStationForm());
        return new ModelAndView(METEORO_BASE, model);
    }

    @RequestMapping("/saveOrUpdate")
    @ResponseBody
    public ResponseEntity<GenericResponse> saveOrUpdate(@ModelAttribute MeteorologicalStationForm form) {

        meteorologicalStationService.save(new MeteorologicalStation(form.getMeteorologicalStationId(),
                form.getMeteorologicalStationDescription(),
                form.getMeteorologicalStationLongitude(),
                form.getMeteorologicalStationLatitude(),
                form.getActiveStatus(),
                form.getOwnerId(),
                form.getMeteorologicalStationUser(),
                form.getMeteorologicalStationPwd(),
                form.getStationTypeId(),
                form.getStationSerialNumber(),
                form.getResponsible()));

        return new ResponseEntity<GenericResponse>(new GenericResponse(true, getMessage(SAVE_OPERATION_SUCCEEDED)), HttpStatus.OK);
    }

    @RequestMapping("/search")
    @ResponseBody
    public Page<MeteorologicalStation> search(@ModelAttribute MeteorologicalStationForm form, Pageable pageable) {
        return meteorologicalStationService.search(form.getStationTypeId(),form.getMeteorologicalStationDescription(), form.getActiveStatus(), form.getOwnerId(), pageable);
    }

    @RequestMapping(value = "/findById")
    @ResponseBody
    public MeteorologicalStation findById(@RequestParam Long id) {
        return meteorologicalStationService.findById(id);
    }


    @RequestMapping(value = "/delete")
    @ResponseBody
    public ResponseEntity<GenericResponse> delete(@RequestParam Long id) {

        meteorologicalStationService.delete(id);

        return new ResponseEntity<GenericResponse>(new GenericResponse(true, getMessage(DELETE_OPERATION_SUCCEEDED)), HttpStatus.OK);
    }

    @RequestMapping(value = "/loadCollection")
    @ResponseBody
    public Collection<MeteorologicalStation> loadCollection() {
        return meteorologicalStationService.loadCollection();
    }

    @RequestMapping(value = "/loadCollectionByType")
    @ResponseBody
    public Collection<MeteorologicalStation> loadCollectionByStationType() {
        return meteorologicalStationService.loadCollectionByMetStationType();
    }



    @RequestMapping(value = "/loadCollectionByOwner")
    @ResponseBody
    public Collection<MeteorologicalStation> loadCollectionByOwner(@RequestParam Long ownerId) {
        return meteorologicalStationService.loadCollectionByOwner(ownerId);
    }

    @RequestMapping(value = "/loadStationTypeCollection")
    @ResponseBody
    public Collection<StationType> loadStationTypeCollection() {
        return meteorologicalStationService.loadStationTypesCollection();
    }

}
