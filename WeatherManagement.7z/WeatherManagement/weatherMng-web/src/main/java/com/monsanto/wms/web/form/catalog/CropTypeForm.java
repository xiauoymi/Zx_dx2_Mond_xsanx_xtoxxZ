package com.monsanto.wms.web.form.catalog;

/**
 * Created by IntelliJ IDEA.
 * User: MANIET
 * Date: 6/3/13
 * Time: 4:00 PM
 * To change this template use File | Settings | File Templates.
 */
public class CropTypeForm {


    private String cropTypeDescription;

    private Boolean activeStatus;

    private Long cropTypeId;


    public String getCropTypeDescription() {
        return cropTypeDescription;
    }

    public void setCropTypeDescription(String cropTypeDescription) {
        this.cropTypeDescription = cropTypeDescription;
    }

    public Boolean getActiveStatus() {
        return activeStatus;
    }

    public void setActiveStatus(Boolean activeStatus) {
        this.activeStatus = activeStatus;
    }

    public Long getCropTypeId() {
        return cropTypeId;
    }

    public void setCropTypeId(Long cropTypeId) {
        this.cropTypeId = cropTypeId;
    }
}
