package com.monsanto.wms.web.view;

import com.monsanto.wms.vo.ReportPRGeneralReportVO;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.springframework.web.servlet.view.document.AbstractExcelView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.List;
import java.util.Map;

/**
 * Created by IntelliJ IDEA.
 * User: MANIET
 * Date: 12/11/12
 * Time: 10:53 AM
 * To change this template use File | Settings | File Templates.
 */
public class PRGeneralReportExcelView extends AbstractExcelView {

    @Override
    public void buildExcelDocument(Map<String, Object> model,
                                      HSSFWorkbook workbook,
                                      HttpServletRequest httpServletRequest,
                                      HttpServletResponse httpServletResponse) throws Exception {


       HSSFSheet sheet = workbook.createSheet("WMS Sow Recommendation Report");
       Map<String, Object> data  =(Map<String, Object>) model.get("excelData");

       createHeader(sheet,(String)data.get("temperatureIn"),
                          (Double)data.get("tempUnder"),
                          (Double)data.get("tempAbove"));


        populateConceptRow(sheet,(List<ReportPRGeneralReportVO>)data.get("dataList"),(String)data.get("temperatureIn"));

        httpServletResponse.setHeader("Content-Disposition", "attachment; filename=\"PRGeneralReport"+(String)data.get("metStation")+".xls\"");
    }

    private void populateConceptRow(HSSFSheet sheet, List<ReportPRGeneralReportVO> resultData,String temperatureIn){

        int i =0;
        int rowNum = 1;

        HSSFRow row = null;

        for(ReportPRGeneralReportVO currentItem : resultData ){
            row = sheet.createRow(rowNum++);
            row.createCell(i++).setCellValue(currentItem.getDateStr());
            if(temperatureIn.equalsIgnoreCase("C")){
                row.createCell(i++).setCellValue(currentItem.getTempMinC());
                row.createCell(i++).setCellValue(currentItem.getTempMaxC());
            }else{
                row.createCell(i++).setCellValue(currentItem.getTempMinF());
                row.createCell(i++).setCellValue(currentItem.getTempMaxF());
            }

            row.createCell(i++).setCellValue(currentItem.getGdus());
            row.createCell(i++).setCellValue(currentItem.getGduAcum());
            row.createCell(i++).setCellValue(currentItem.getDampMin());
            row.createCell(i++).setCellValue(currentItem.getDampMax());
            row.createCell(i++).setCellValue(currentItem.getPeriodsUnder());
            row.createCell(i++).setCellValue(currentItem.getPeriodsAbove());
            row.createCell(i++).setCellValue(currentItem.getPrecipitation());
            row.createCell(i++).setCellValue(currentItem.getEvoTranspiration());
            row.createCell(i++).setCellValue(currentItem.getWindSpeedMin());
            row.createCell(i++).setCellValue(currentItem.getWindSpeedMax());
            row.createCell(i++).setCellValue(currentItem.getWindAVGBetween7And17Hrs());
            row.createCell(i++).setCellValue(currentItem.getRadiation());

            i=0;
        }




    }

    private HSSFRow createHeader(HSSFSheet sheet,String temperatureIn,Double tempUnder,Double tempAbove) {

         HSSFRow header = sheet.createRow(0);
        int i = 0;
		header.createCell(i++).setCellValue("Date");
		header.createCell(i++).setCellValue("Temp Min "+temperatureIn);
		header.createCell(i++).setCellValue("Temp Max "+temperatureIn);
		header.createCell(i++).setCellValue("GDU");
        header.createCell(i++).setCellValue("GDU Acum");
        header.createCell(i++).setCellValue("Damp Min");
        header.createCell(i++).setCellValue("Damp Max");
        header.createCell(i++).setCellValue("Periods Under "+tempUnder+" "+temperatureIn);
        header.createCell(i++).setCellValue("Periods Above"+tempAbove+" "+temperatureIn);
        header.createCell(i++).setCellValue("Precipitation");
        header.createCell(i++).setCellValue("E.transpiration");
        header.createCell(i++).setCellValue("Wind Speed Min");
        header.createCell(i++).setCellValue("Wind Speed Max");
        header.createCell(i++).setCellValue("Wind Seepd 7am to 7pm");
        header.createCell(i++).setCellValue("Radiation");
        return header;
    }
}
