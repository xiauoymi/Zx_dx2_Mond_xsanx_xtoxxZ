package com.monsanto.wms.web.controller.catalog;


import com.monsanto.wms.persistence.model.Hybrid;
import com.monsanto.wms.service.catalog.HybridService;
import com.monsanto.wms.web.controller.commons.BaseController;
import com.monsanto.wms.web.form.catalog.HybridForm;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.MessageSource;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by IntelliJ IDEA.
 * User: MANIET
 * Date: 6/3/13
 * Time: 3:58 PM
 * To change this template use File | Settings | File Templates.
 */
@Controller
@RequestMapping("/catalog/hybridBase")
public final class HybridController extends BaseController {

    public static final String HYBRID_BASE = "catalog/hybridBase";

    private HybridService hybridService;

    @Autowired
    public HybridController(HybridService hybridService, @Qualifier("messageSource") MessageSource messageSource) {
        super();
        this.hybridService = hybridService;
        setMessageSource(messageSource);
    }

    @RequestMapping("/init")
    public ModelAndView initView() {
        Map<String, Object> model = new HashMap<String, Object>();

        model.put(DATA_FORM, new HybridForm());
        return new ModelAndView(HYBRID_BASE, model);
    }

    @RequestMapping("/saveOrUpdate")
    @ResponseBody
    public ResponseEntity<GenericResponse> saveOrUpdate(@ModelAttribute HybridForm form) {

        hybridService.save(new Hybrid(form.getHybridId(), form.getHybridDescription(), form.getCropId(), form.getActiveStatus()));

        return new ResponseEntity<GenericResponse>(new GenericResponse(true, getMessage(SAVE_OPERATION_SUCCEEDED)), HttpStatus.OK);
    }

    @RequestMapping("/search")
    @ResponseBody
    public Page<Hybrid> search(@ModelAttribute HybridForm form, Pageable pageable) {
        return hybridService.search(form.getHybridDescription(), form.getCropTypeId(), form.getCropId(), form.getActiveStatus(), pageable);
    }

    @RequestMapping(value = "/findById")
    @ResponseBody
    public Hybrid findById(@RequestParam Long id) {
        return hybridService.findById(id);
    }


    @RequestMapping(value = "/delete")
    @ResponseBody
    public ResponseEntity<GenericResponse> delete(@RequestParam Long id) {

        hybridService.delete(id);

        return new ResponseEntity<GenericResponse>(new GenericResponse(true, getMessage(DELETE_OPERATION_SUCCEEDED)), HttpStatus.OK);
    }

    @RequestMapping(value = "/loadCollection")
    @ResponseBody
    public Collection<Hybrid> loadCollection() {

        return hybridService.loadCollection();

    }

    @RequestMapping(value = "/findDynamicList")
    @ResponseBody
    public Collection<Hybrid> findDynamicList(String match, Long cropTypeId, Long cropId) {

        return hybridService.findDynamicList(match, cropTypeId, cropId);

    }

}
