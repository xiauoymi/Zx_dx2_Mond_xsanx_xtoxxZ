package com.monsanto.wms.web.support;

import com.monsanto.wms.support.security.DefaultTaskIdLocator;
import com.monsanto.wms.support.security.TaskIdLocator;
import com.monsanto.wms.support.security.TaskIdLocatorFactory;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

/**
 * Created by IntelliJ IDEA.
 * User: FJSIBA
 * Date: 27/08/12
 * Time: 12:30 PM
 * To change this template use File | Settings | File Templates.
 */
@Component
public class WebTaskIdLocatorFactory implements TaskIdLocatorFactory{

    @Override
    public TaskIdLocator getTaskIdLocator() {

        TaskIdLocator taskIdLocator = null;
        try{

            taskIdLocator = new WebTaskIdLocator(((ServletRequestAttributes)RequestContextHolder.currentRequestAttributes()).getRequest().getRequestURI());

        }catch (IllegalStateException e){
            taskIdLocator = new DefaultTaskIdLocator();
        }

        return taskIdLocator;
    }
}
