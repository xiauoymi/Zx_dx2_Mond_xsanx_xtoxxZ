package com.monsanto.wms.web.controller.production;

import com.monsanto.wms.service.production.SpectrumMeteorologicalStationManualLoadService;
import com.monsanto.wms.web.controller.commons.BaseController;
import com.monsanto.wms.web.form.production.SpectrumManualLoadForm;
import com.monsanto.wms.web.utils.WMSUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.text.ParseException;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by GFRAN1 on 10/29/2014.
 */
@Controller
@RequestMapping("/production/metStationSpectrumManualLoad")
public class SpectrumMetStationManualLoadController extends BaseController{

    private static final String SPECTRUM_MANUAL_LOAD = "production/metStationSpectrumManualLoad";

    private SpectrumMeteorologicalStationManualLoadService spectrumMeteorologicalStationManualLoadService;

    @Autowired
    public SpectrumMetStationManualLoadController(SpectrumMeteorologicalStationManualLoadService spectrumMeteorologicalStationManualLoadService,@Qualifier("messageSource") MessageSource messageSource) {
        super();
        this.spectrumMeteorologicalStationManualLoadService = spectrumMeteorologicalStationManualLoadService;
        setMessageSource(messageSource);
    }

    @RequestMapping("/init")
    public ModelAndView initView(HttpServletRequest request) {

        String sMsg = request.getParameter("msg");
        Map<String, Object> model = new HashMap<String, Object>();
        SpectrumManualLoadForm form = new SpectrumManualLoadForm();
        model.put(DATA_FORM, form);
        model.put("success", true);
        model.put("msg", sMsg);
        return new ModelAndView(SPECTRUM_MANUAL_LOAD, model);
    }


    @RequestMapping("/loadSpectrumData" )
    @ResponseBody
    public GenericResponse importDataToStaging(@ModelAttribute ("dataForm") SpectrumManualLoadForm form) throws IOException, ParseException {
        Long batchId= spectrumMeteorologicalStationManualLoadService.importDataToStaging(form.getMeteorologicalStationId(), WMSUtils.convertInputStreamToList(form.getFiles().get(0),"\t"), form.getStartDate(), form.getEndDate());
        String [] messages = new String[] {""+batchId};
        GenericResponse gr;
        if(batchId > 0){
            gr=new GenericResponse(false,messages);
        }
        else{
            gr= new GenericResponse(true,messages);
        }
        return gr;
    }
}
