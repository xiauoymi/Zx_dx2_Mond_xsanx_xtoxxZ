package com.monsanto.wms.web.support.security;

import com.monsanto.wms.support.security.UserIdLocator;

import javax.security.auth.Subject;
import java.security.Principal;
import java.util.Set;

/**
 * Created by IntelliJ IDEA.
 * User: FJSIBA
 * Date: 21/08/12
 * Time: 01:05 PM
 * To change this template use File | Settings | File Templates.
 */
public class WAMUserIdLocator implements UserIdLocator {
    private Subject subject;

    public WAMUserIdLocator(Subject subject) {
        this.subject = subject;
    }

    public String getUserId() {
        return getUserId(subject.getPrincipals());
    }

    private String getUserId(Set<Principal> principals) {
        String userId = null;

        if (!principals.isEmpty()) {
            userId = principals.iterator().next().getName();
        }
        if (userId != null) {
            userId = userId.toUpperCase();
        }
        return userId;
    }
}
