package com.monsanto.wms.web.controller.catalog;

import com.monsanto.wms.persistence.model.CropStage;
import com.monsanto.wms.service.catalog.CropStageService;
import com.monsanto.wms.web.controller.commons.BaseController;
import com.monsanto.wms.web.form.catalog.CropStageForm;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.MessageSource;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by IntelliJ IDEA.
 * User: MANIET
 * Date: 6/3/13
 * Time: 3:58 PM
 * To change this template use File | Settings | File Templates.
 */
@Controller
@RequestMapping("/catalog/cropStageBase")
public final class CropStageController extends BaseController {

    public static final String CROP_STAGE_BASE = "catalog/cropStageBase";

    private CropStageService cropStageService;

    @Autowired
    public CropStageController(CropStageService cropSageService, @Qualifier("messageSource") MessageSource messageSource) {
        super();
        this.cropStageService = cropSageService;
        setMessageSource(messageSource);
    }

    @RequestMapping("/init")
    public ModelAndView initView() {
        Map<String, Object> model = new HashMap<String, Object>();

        model.put(DATA_FORM, new CropStageForm());
        return new ModelAndView(CROP_STAGE_BASE, model);
    }

    @RequestMapping("/saveOrUpdate")
    @ResponseBody
    public ResponseEntity<GenericResponse> saveOrUpdate(@ModelAttribute CropStageForm form) {

        cropStageService.save(new CropStage(form.getCropStageId(), form.getCropStageDescription(), form.getCropId(), form.getActiveStatus(), form.getCropStageDefaultValue()));

        return new ResponseEntity<GenericResponse>(new GenericResponse(true, getMessage(SAVE_OPERATION_SUCCEEDED)), HttpStatus.OK);
    }

    @RequestMapping("/search")
    @ResponseBody
    public Page<CropStage> search(@ModelAttribute CropStageForm form, Pageable pageable) {
        return cropStageService.search(form.getCropStageDescription(), form.getCropTypeId(), form.getCropId(), form.getActiveStatus(), pageable);
    }

    @RequestMapping(value = "/findById")
    @ResponseBody
    public CropStage findById(@RequestParam Long id) {
        return cropStageService.findById(id);
    }


    @RequestMapping(value = "/delete")
    @ResponseBody
    public ResponseEntity<GenericResponse> delete(@RequestParam Long id, @RequestParam Boolean defaultValue) {

        cropStageService.delete(id, defaultValue);

        return new ResponseEntity<GenericResponse>(new GenericResponse(true, getMessage(DELETE_OPERATION_SUCCEEDED)), HttpStatus.OK);
    }

    @RequestMapping(value = "/loadCollection")
    @ResponseBody
    public Collection<CropStage> loadCollection() {

        return cropStageService.loadCollection();

    }

    @RequestMapping(value = "/loadCollectionDefault")
    @ResponseBody
    public Collection<CropStage> loadCollectionDefault() {

        return cropStageService.loadCollectionDefault();

    }

}
