package com.monsanto.wms.web.controller.production;

import com.monsanto.wms.service.production.PRGeneralReportService;
import com.monsanto.wms.vo.ReportPRGeneralReportVO;
import com.monsanto.wms.web.controller.commons.BaseController;
import com.monsanto.wms.web.form.production.PRGeneralReportForm;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.MessageSource;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by IntelliJ IDEA.
 * User: MANIET
 * Date: 6/3/13
 * Time: 3:58 PM
 * To change this template use File | Settings | File Templates.
 */
@Controller
@RequestMapping("/production/reports/prGeneralReportBase")
public final class PRGeneralReportController extends BaseController {

    private static final String REPORT_BASE = "production/reports/prGeneralReportBase";

    private PRGeneralReportService prGeneralReportService;


    @Autowired
    public PRGeneralReportController(PRGeneralReportService prGeneralReportService, @Qualifier("messageSource") MessageSource messageSource) {
        super();
        this.prGeneralReportService = prGeneralReportService;
        setMessageSource(messageSource);

    }


    @RequestMapping("/init")
    public ModelAndView initView(HttpServletRequest request) {

        String sMsg = request.getParameter("msg");
        Boolean success = validateResultRequestParameter(request);

        Map<String, Object> model = new HashMap<String, Object>();
        PRGeneralReportForm form = new PRGeneralReportForm();

        model.put(DATA_FORM, form);
        model.put("success", success);
        model.put("msg", sMsg);

        return new ModelAndView(REPORT_BASE, model);
    }

    @RequestMapping(value = "/export")
    @ResponseBody
    public ModelAndView export(@RequestParam Integer initYear, @RequestParam Integer initMonth, @RequestParam Integer initDay,
                               @RequestParam Integer endYear, @RequestParam Integer endMonth, @RequestParam Integer endDay,
                               @RequestParam String meteorologicalStationDesc, @RequestParam Long meteorologicalStationId,
                               @RequestParam Double tempMin, @RequestParam Double tempMax, @RequestParam String cropName,
                               @RequestParam Double tempUnder, @RequestParam Double tempAbove, @RequestParam String temperatureIn) {

        List<ReportPRGeneralReportVO> ls = prGeneralReportService.getReport(initYear, initMonth, initDay, endYear, endMonth, endDay, meteorologicalStationId, tempMin, tempMax, cropName, tempUnder, tempAbove, null);

        if (ls != null && !ls.isEmpty()) {
            Map<String, Object> model = new HashMap<String, Object>();
            model.put("dataList", ls);
            model.put("metStation", meteorologicalStationDesc);
            model.put("tempAbove", tempAbove);
            model.put("tempUnder", tempUnder);
            model.put("temperatureIn", temperatureIn);
            return new ModelAndView("prGeneralReportExcelView", "excelData", model);
        }

        return null;

    }

    @RequestMapping("/search")
    @ResponseBody
    public Page<ReportPRGeneralReportVO> search(@ModelAttribute PRGeneralReportForm form, Pageable pageable) {
        List<ReportPRGeneralReportVO> ls = prGeneralReportService.getReport(form.getYearIni(), form.getMonthIni(), form.getDayIni(), form.getYearEnd(), form.getMonthEnd(), form.getDayEnd(), form.getMeteorologicalStationId(), form.getTempMin(), form.getTempMax(), form.getCropName(), form.getTempUnder(), form.getTempAbove(), pageable);
        Page<ReportPRGeneralReportVO> page = new PageImpl(ls);
        return page;
    }


}
