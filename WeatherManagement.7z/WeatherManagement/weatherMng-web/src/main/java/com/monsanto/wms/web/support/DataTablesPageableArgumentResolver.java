package com.monsanto.wms.web.support;

import org.springframework.core.MethodParameter;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.support.WebArgumentResolver;
import org.springframework.web.context.request.NativeWebRequest;

import java.util.ArrayList;
import java.util.List;

import static org.springframework.data.domain.Sort.Order;

/**
 * Created by IntelliJ IDEA.
 * User: ACISS
 * Date: 30/09/12
 * Time: 02:30 PM
 */
public class DataTablesPageableArgumentResolver implements WebArgumentResolver {

    @Override
    public Object resolveArgument(MethodParameter methodParameter, NativeWebRequest request) {
        if (methodParameter.getParameterType().equals(Pageable.class)) {

            String iDisplayStart = request.getParameter("iDisplayStart");
            String iDisplayLength = request.getParameter("iDisplayLength");

            Integer page = 0;
            Integer size = 10;

            if (StringUtils.hasText(iDisplayLength) && iDisplayLength.matches("[\\d]*")) {
                size = Integer.valueOf(iDisplayLength);
            }
            if (StringUtils.hasText(iDisplayStart) && iDisplayStart.matches("[\\d]*")) {
                page = Integer.valueOf(iDisplayStart) / size;
            }
            return new PageRequest(page, size, createSort(request));
        }
        return UNRESOLVED;
    }

    private Sort createSort(NativeWebRequest request) {
        String iColumns = request.getParameter("iColumns");
        Sort sort = null;
        if (StringUtils.hasText(iColumns) && iColumns.matches("[\\d]*")) {
            int noColumns = Integer.valueOf(iColumns);

            List<Order> orders = new ArrayList<Order>(noColumns);
            for (int i = 0; i < noColumns; i++) {
                String iSortCol = request.getParameter(String.format("iSortCol_%d", i));
                String sSortDir = request.getParameter(String.format("sSortDir_%d", i));
                if (StringUtils.hasText(iSortCol) && StringUtils.hasText(sSortDir)) {
                    String mDataProp = request.getParameter(String.format("mDataProp_%d", Integer.valueOf(iSortCol)));
                    Order o = new Order(Sort.Direction.fromString(sSortDir.toUpperCase()), mDataProp);
                    orders.add(o);
                }
            }
            if (orders.size() > 0) {
                sort = new Sort(orders);
            }

        }
        return sort;
    }
}
