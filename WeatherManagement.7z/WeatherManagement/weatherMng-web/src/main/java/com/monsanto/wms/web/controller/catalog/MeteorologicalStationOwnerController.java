package com.monsanto.wms.web.controller.catalog;

import com.monsanto.wms.persistence.model.MeteorologicalStationOwner;
import com.monsanto.wms.service.catalog.MeteorologicStationOwnerService;
import com.monsanto.wms.web.controller.commons.BaseController;
import com.monsanto.wms.web.form.catalog.MeteorologicalStationOwnerForm;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.MessageSource;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by IntelliJ IDEA.
 * User: MANIET
 * Date: 6/3/13
 * Time: 3:58 PM
 * To change this template use File | Settings | File Templates.
 */
@Controller
@RequestMapping("/catalog/meteoroStationOwnerBase")
public final class MeteorologicalStationOwnerController extends BaseController {

    public static final String METEOROLOGICAL_STATION_OWNER_BASE = "catalog/meteoroStationOwnerBase";

    private MeteorologicStationOwnerService meteorologicStationOwnerService;

    @Autowired
    public MeteorologicalStationOwnerController(MeteorologicStationOwnerService meteorologicStationOwnerService, @Qualifier("messageSource") MessageSource messageSource) {
        super();
        this.meteorologicStationOwnerService = meteorologicStationOwnerService;
        setMessageSource(messageSource);
    }

    @RequestMapping("/init")
    public ModelAndView initView() {
        Map<String, Object> model = new HashMap<String, Object>();

        model.put(DATA_FORM, new MeteorologicalStationOwnerForm());
        return new ModelAndView(METEOROLOGICAL_STATION_OWNER_BASE, model);
    }

    @RequestMapping("/saveOrUpdate")
    @ResponseBody
    public ResponseEntity<GenericResponse> saveOrUpdate(@ModelAttribute MeteorologicalStationOwnerForm form) {

        meteorologicStationOwnerService.save(new MeteorologicalStationOwner(
                form.getMeteorologicalStationOwnerId(), form.getMeteorologicalStationOwnerDescription(), form.getMeteorologicalStationOwnerShortDescription(), form.getAreaId(), form.getActiveStatus()));

        return new ResponseEntity<GenericResponse>(new GenericResponse(true, getMessage(SAVE_OPERATION_SUCCEEDED)), HttpStatus.OK);
    }

    @RequestMapping("/search")
    @ResponseBody
    public Page<MeteorologicalStationOwner>
    search(@ModelAttribute MeteorologicalStationOwnerForm form, Pageable pageable) {
        return meteorologicStationOwnerService.search(form.getMeteorologicalStationOwnerDescription(), form.getMeteorologicalStationOwnerShortDescription(), form.getAreaId(), form.getActiveStatus(), pageable);
    }

    @RequestMapping(value = "/findById")
    @ResponseBody
    public MeteorologicalStationOwner findById(@RequestParam Long id) {
        return meteorologicStationOwnerService.findById(id);
    }


    @RequestMapping(value = "/delete")
    @ResponseBody
    public ResponseEntity<GenericResponse> delete(@RequestParam Long id) {

        meteorologicStationOwnerService.delete(id);

        return new ResponseEntity<GenericResponse>(new GenericResponse(true, getMessage(DELETE_OPERATION_SUCCEEDED)), HttpStatus.OK);
    }

    @RequestMapping(value = "/loadCollection")
    @ResponseBody
    public Collection<MeteorologicalStationOwner> loadCollection() {

        return meteorologicStationOwnerService.loadCollection();

    }

}
