package com.monsanto.wms.web.form.catalog;

/**
 * Created by IntelliJ IDEA.
 * User: MANIET
 * Date: 6/3/13
 * Time: 4:00 PM
 * To change this template use File | Settings | File Templates.
 */
public class BaseTemperatureForm {


    private Long baseTemperatureId;

    private Long cropId;

    private Long cropTypeId;

    private String tempMin;

    private String tempMax;

    private Boolean activeStatus;

    public Long getBaseTemperatureId() {
        return baseTemperatureId;
    }

    public void setBaseTemperatureId(Long baseTemperatureId) {
        this.baseTemperatureId = baseTemperatureId;
    }

    public Long getCropId() {
        return cropId;
    }

    public void setCropId(Long cropId) {
        this.cropId = cropId;
    }

    public String getTempMin() {
        return tempMin;
    }

    public void setTempMin(String tempMin) {
        this.tempMin = tempMin;
    }

    public String getTempMax() {
        return tempMax;
    }

    public void setTempMax(String tempMax) {
        this.tempMax = tempMax;
    }

    public Boolean getActiveStatus() {
        return activeStatus;
    }

    public void setActiveStatus(Boolean activeStatus) {
        this.activeStatus = activeStatus;
    }

    public Long getCropTypeId() {
        return cropTypeId;
    }

    public void setCropTypeId(Long cropTypeId) {
        this.cropTypeId = cropTypeId;
    }
}
