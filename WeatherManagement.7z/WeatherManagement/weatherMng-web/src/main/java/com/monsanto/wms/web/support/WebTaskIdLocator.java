package com.monsanto.wms.web.support;

import com.monsanto.wms.support.security.TaskIdLocator;

/**
 * Created by IntelliJ IDEA.
 * User: FJSIBA
 * Date: 27/08/12
 * Time: 12:41 PM
 * To change this template use File | Settings | File Templates.
 */
public class WebTaskIdLocator implements TaskIdLocator {
    private String taskId;
    public WebTaskIdLocator(String taskId) {
        this.taskId = taskId;
    }

    public String getTaskId() {
        return taskId;
    }
}
