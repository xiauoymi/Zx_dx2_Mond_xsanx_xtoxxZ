package com.monsanto.wms.web.controller.commons;

import com.monsanto.wms.exceptions.CustomSystemException;
import org.springframework.context.MessageSource;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import java.util.*;

/**
 * Created by IntelliJ IDEA.
 * User: MANIET
 * Date: 5/17/13
 * Time: 8:03 AM
 * To change this template use File | Settings | File Templates.
 */
public abstract class BaseController {

    public static final String DATA_FORM = "dataForm";
    protected static final String SAVE_OPERATION_SUCCEEDED = "common.action.save.success";
    protected static final String DELETE_OPERATION_SUCCEEDED = "common.action.delete.success";

    protected MessageSource messageSource;

    public static final class GenericResponse {
    
        private String[] messages;
        private boolean success;
        
        public GenericResponse(boolean success, String... messages) {
            this.success = success;
            this.messages = CustomSystemException.getCustomException(messages);
        }
        
        public String[] getMessages() {
            return messages;
        }
        
        public boolean isSuccess() {
            return success;
        }
    
    }

    protected void setMessageSource(MessageSource messageSource) {
        this.messageSource = messageSource;
    }

    protected MessageSource getMessageSource() {
        return messageSource;
    }

    protected String getMessage( String code, Object ...args ){

      return getMessageSource().getMessage(code, args, Locale.getDefault());
    }


    protected Boolean validateResultRequestParameter(HttpServletRequest request){
        String sResult = request.getParameter("success");
        Boolean success;

        if(sResult!=null){
            success = Boolean.valueOf(sResult);
        }else{
            success = null;
        }

        return success;
    }


    @ExceptionHandler(Exception.class)
    @ResponseBody
    protected GenericResponse handleException(Exception ex) {

           return new GenericResponse(false, ex.getMessage());

    }


}
