package com.monsanto.wms.web.utils;

import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;

/**
 * Created with IntelliJ IDEA.
 * User: MANIET
 * Date: 10/2/13
 * Time: 3:09 PM
 * To change this template use File | Settings | File Templates.
 */
public final class HSSFManualLoadFile {

    private  HSSFWorkbook originalFile;
    private  HSSFWorkbook manualLoadFile;
    private Long meteorologicalStationId;
    private  Integer day;
    private  Integer month;
    private  Integer year;

    public HSSFManualLoadFile(InputStream file,Long meteorologicalStationId,Integer day, Integer month,Integer year) throws IOException {
        this.originalFile = new HSSFWorkbook(file);
        this.manualLoadFile = new HSSFWorkbook();
        this.meteorologicalStationId =meteorologicalStationId;
        this.day = day;
        this.month = month;
        this.year = year;
    }

    public ByteArrayInputStream getManualLoadFile() throws IOException {
        HSSFSheet sheet = manualLoadFile.createSheet("systemAutoFile");
        crateHeaders(sheet);
        insertContent(sheet);
        return getByteArrayInputStream();
    }


    private void crateHeaders(HSSFSheet sheet){
        HSSFRow header = sheet.createRow(0);
        int i = 0;
        header.createCell(i++).setCellValue("day");
        header.createCell(i++).setCellValue("month");
        header.createCell(i++).setCellValue("year");
        header.createCell(i++).setCellValue("TM");
        header.createCell(i++).setCellValue("tm");
        header.createCell(i++).setCellValue("timeRegistry");

    }

    private void insertContent(HSSFSheet sheet){
        int i =0;
        int rowNum = 1;

        HSSFRow manualLoadFileRow = null;
        HSSFRow originalFileRow = null;

        for(int j=1;j<=originalFile.getSheetAt(0).getLastRowNum();j++){
            originalFileRow = originalFile.getSheetAt(0).getRow(rowNum);
            manualLoadFileRow = sheet.createRow(rowNum++);

            manualLoadFileRow.createCell(i++).setCellValue(meteorologicalStationId);
            manualLoadFileRow.createCell(i++).setCellValue(day);
            manualLoadFileRow.createCell(i++).setCellValue(month);
            manualLoadFileRow.createCell(i++).setCellValue(year);

            manualLoadFileRow.createCell(i++).setCellValue(originalFileRow.getCell(0).getNumericCellValue());
            manualLoadFileRow.createCell(i++).setCellValue(originalFileRow.getCell(1).getNumericCellValue());
            manualLoadFileRow.createCell(i++).setCellValue(originalFileRow.getCell(2).getStringCellValue());

            i=0;
        }

    }

    private ByteArrayInputStream getByteArrayInputStream() throws IOException {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        manualLoadFile.write(out);
        return new ByteArrayInputStream(out.toByteArray());
    }

}
