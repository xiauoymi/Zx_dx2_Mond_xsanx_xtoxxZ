package com.monsanto.wms.web.controller.catalog;

import com.monsanto.wms.service.catalog.PRExtrapolateDataService;
import com.monsanto.wms.util.WMSServiceUtil;
import com.monsanto.wms.web.controller.commons.BaseController;
import com.monsanto.wms.web.form.catalog.PRExtrapolateDataForm;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by IntelliJ IDEA.
 * User: MANIET
 * Date: 6/3/13
 * Time: 3:58 PM
 * To change this template use File | Settings | File Templates.
 */
@Controller
@RequestMapping("/catalog/prExtrapolateData")
public final class PRExtrapolateDataController extends BaseController {

    private static final String EXTRAPOLATE_DATA = "/catalog/prExtrapolateData";

    private PRExtrapolateDataService prExtrapolateDataService;


    @Autowired
    public PRExtrapolateDataController(PRExtrapolateDataService prExtrapolateDataService, @Qualifier("messageSource") MessageSource messageSource) {
        super();
        this.prExtrapolateDataService = prExtrapolateDataService;
        setMessageSource(messageSource);

    }



    @RequestMapping("/init")
    public ModelAndView initView(HttpServletRequest request) {

        String sMsg = request.getParameter("msg");
        Boolean success = validateResultRequestParameter(request);

        Map<String, Object> model = new HashMap<String, Object>();
        PRExtrapolateDataForm form = new PRExtrapolateDataForm();

        model.put(DATA_FORM, form);
        model.put("success", success);
        model.put("msg", sMsg);

        return new ModelAndView(EXTRAPOLATE_DATA, model);
    }

    @RequestMapping(value="/extrapolateData", produces = "application/json")
    @ResponseBody

    public GenericResponse fillData(@ModelAttribute PRExtrapolateDataForm form) {
        String [] messages ;
        String response = prExtrapolateDataService.fillEmptyDays(form.getMeteorologicalStationId(),form.getStartDate(),form.getEndDate(),form.getDays());
        String startDateFormatted= WMSServiceUtil.getFormattedDate(form.getStartDate().toString(), WMSServiceUtil.PATTERN, "dd/MM/yyyy");
        String endDateFormatted = WMSServiceUtil.getFormattedDate(form.getEndDate().toString(), WMSServiceUtil.PATTERN, "dd/MM/yyyy");
        GenericResponse gr;
        if(response.isEmpty()){
            messages =  new String[] {"Data gap filled from:"+startDateFormatted+ " to "+endDateFormatted};
            gr=new GenericResponse(true,messages);
        }
        else{
            messages =  new String[] {response};
            gr= new GenericResponse(false,messages);
        }
        return gr;
    }

    @RequestMapping("/getExtrapolatedDataProfile")
    @ResponseBody
    public GenericResponse getExtrapolatedDataProfile(@ModelAttribute PRExtrapolateDataForm form){
        String response =prExtrapolateDataService.getExtrapolatedDataProfile(form.getMeteorologicalStationId(),form.getStartDate(),form.getEndDate());
      return new GenericResponse(true,response);
    }

}

