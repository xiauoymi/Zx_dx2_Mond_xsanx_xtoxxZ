package com.monsanto.wms.web.form.catalog;

/**
 * Created by IntelliJ IDEA.
 * User: MANIET
 * Date: 6/3/13
 * Time: 4:00 PM
 * To change this template use File | Settings | File Templates.
 */
public class ProductionCycleForm {


    private Long productionCycleId;

    private String productionCycleDescription;

    private Boolean activeStatus;


    public Long getProductionCycleId() {
        return productionCycleId;
    }

    public void setProductionCycleId(Long productionCycleId) {
        this.productionCycleId = productionCycleId;
    }

    public String getProductionCycleDescription() {
        return productionCycleDescription;
    }

    public void setProductionCycleDescription(String productionCycleDescription) {
        this.productionCycleDescription = productionCycleDescription;
    }

    public Boolean getActiveStatus() {
        return activeStatus;
    }

    public void setActiveStatus(Boolean activeStatus) {
        this.activeStatus = activeStatus;
    }

}
