package com.monsanto.wms.web.form.catalog;

import java.util.Date;

/**
 * Created with IntelliJ IDEA.
 * User: GFRAN1
 * Date: 7/21/14
 * Time: 2:58 PM
 * To change this template use File | Settings | File Templates.
 */
public class ReloadDataForm {

    private Long meteorologicalStationId;
    private Date startDate;
    private Long batchId;


    public Long getMeteorologicalStationId() {
        return meteorologicalStationId;
    }

    public void setMeteorologicalStationId(Long meteorologicalStationId) {
        this.meteorologicalStationId = meteorologicalStationId;
    }

    public Date getStartDate() {
        return startDate;
    }

    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    public Long getBatchId() {
        return batchId;
    }

    public void setBatchId(Long batchId) {
        this.batchId = batchId;
    }
}



