package com.monsanto.wms.web.controller.catalog;

import com.monsanto.wms.persistence.model.BaseTemperature;
import com.monsanto.wms.service.catalog.BaseTemperatureService;
import com.monsanto.wms.web.controller.commons.BaseController;
import com.monsanto.wms.web.form.catalog.BaseTemperatureForm;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.MessageSource;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by IntelliJ IDEA.
 * User: MANIET
 * Date: 6/3/13
 * Time: 3:58 PM
 * To change this template use File | Settings | File Templates.
 */
@Controller
@RequestMapping("/catalog/temperatureBase")
public final class BaseTemperatureController extends BaseController {

    public static final String PRODUCTION_TEMPERATURE_BASE = "catalog/temperatureBase";

    private BaseTemperatureService baseTemperatureService;

    @Autowired
    public BaseTemperatureController(BaseTemperatureService baseTemperatureService, @Qualifier("messageSource") MessageSource messageSource) {
        super();
        this.baseTemperatureService = baseTemperatureService;
        setMessageSource(messageSource);
    }

    @RequestMapping(value="/init",method = RequestMethod.GET)
    public ModelAndView initView() {
        Map<String, Object> model = new HashMap<String, Object>();
        model.put(DATA_FORM, new BaseTemperatureForm());
        return new ModelAndView(PRODUCTION_TEMPERATURE_BASE, model);
    }

    @RequestMapping("/saveOrUpdate")
    @ResponseBody
    public ResponseEntity<GenericResponse> saveOrUpdate(@ModelAttribute BaseTemperatureForm form) {

        baseTemperatureService.save(new BaseTemperature(form.getBaseTemperatureId(), form.getCropId(), form.getTempMin(),
                form.getTempMax(), form.getActiveStatus()));

        return new ResponseEntity<GenericResponse>(new GenericResponse(true, getMessage(SAVE_OPERATION_SUCCEEDED)), HttpStatus.OK);
    }

    @RequestMapping("/search")
    @ResponseBody
    public Page<BaseTemperature> search(@ModelAttribute BaseTemperatureForm form, Pageable pageable) {
        return baseTemperatureService.search(form.getCropId(), form.getCropTypeId(), form.getTempMin(), form.getTempMax(), form.getActiveStatus(), pageable);
    }

    @RequestMapping(value = "/findById")
    @ResponseBody
    public BaseTemperature findById(@RequestParam Long id) {
        return baseTemperatureService.findById(id);
    }


    @RequestMapping(value = "/delete")
    @ResponseBody
    public ResponseEntity<GenericResponse> delete(@RequestParam Long id) {

        baseTemperatureService.delete(id);

        return new ResponseEntity<GenericResponse>(new GenericResponse(true, getMessage(DELETE_OPERATION_SUCCEEDED)), HttpStatus.OK);
    }

}
