package com.monsanto.wms.web.controller.production;

import com.monsanto.wms.exceptions.WMSException;
import com.monsanto.wms.persistence.model.CropStage;
import com.monsanto.wms.persistence.model.StrewRecommendation;
import com.monsanto.wms.persistence.model.StrewRecommendationDetail;
import com.monsanto.wms.service.catalog.CropStageService;
import com.monsanto.wms.service.production.StrewRecommendationService;
import com.monsanto.wms.vo.RealReportStrewRecommendationVO;
import com.monsanto.wms.web.controller.commons.BaseController;
import com.monsanto.wms.web.form.production.StrewRecommendationForm;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.MessageSource;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import java.util.*;

/**
 * Created by IntelliJ IDEA.
 * User: MANIET
 * Date: 6/3/13
 * Time: 3:58 PM
 * To change this template use File | Settings | File Templates.
 */
@Controller
@RequestMapping("/production/strewRecommendationBase")
public final class StrewRecommendationController extends BaseController {


    private static final String STREW_RECOMMENDATION_BASE = "production/strewRecommendationBase";
    private static final String DENIED_PAGE = "production/denied";

    private StrewRecommendationService strewRecommendationService;
    private CropStageService cropStageService;
    private Collection<CropStage> cropStageVariables;
    private List<RealReportStrewRecommendationVO> realReportInformation;

    private final String TD = "00015874369";
    private final String PROD_RESEARCH = "8645132132";
    private final String FIELD_PROD = "225487445";

    private static final Logger log = LoggerFactory.getLogger(StrewRecommendationController.class);

    @Autowired
    public StrewRecommendationController(StrewRecommendationService strewRecommendationService, CropStageService cropStageService, @Qualifier("messageSource") MessageSource messageSource) {
        super();
        this.strewRecommendationService = strewRecommendationService;
        this.cropStageService = cropStageService;
        setMessageSource(messageSource);
        setCropStageVariables(new ArrayList<CropStage>());
        this.realReportInformation = new ArrayList<RealReportStrewRecommendationVO>();
    }

    @RequestMapping("/init")
    public ModelAndView initView() {

        Map<String, Object> model = new HashMap<String, Object>();

        StrewRecommendationForm form = new StrewRecommendationForm();

        model.put("dataFormB", new StrewRecommendationForm());
        model.put(DATA_FORM, form);
        return new ModelAndView(STREW_RECOMMENDATION_BASE, model);
    }

    @RequestMapping("/initWithCrop")
    public ModelAndView initWithCrop(@ModelAttribute StrewRecommendationForm form) {

        Map<String, Object> model = new HashMap<String, Object>();

        try {
            loadCropStages(form.getSourceCode(), form.getRealReportCrop());
        } catch (WMSException e) {
            return new ModelAndView(DENIED_PAGE, model);
        }

        form.setCropStageVariables(cropStageVariables);
        form.setFirstLoad("NO");
        model.put("dataFormB", new StrewRecommendationForm());

        model.put(DATA_FORM, form);
        return new ModelAndView(STREW_RECOMMENDATION_BASE, model);
    }

    @RequestMapping("/saveOrUpdate")
    @ResponseBody
    public ResponseEntity<GenericResponse> saveOrUpdate(@ModelAttribute StrewRecommendationForm form, HttpServletRequest request) {

        StrewRecommendation strewRecommendation = strewRecommendationService.save(
                new StrewRecommendation(form.getStrewRecommendationId(),
                        form.getProductionZoneId(),
                        form.getProductionCyclesId(),
                        form.getHybridId(),
                        form.getSourceCode()));

        strewRecommendationService.saveDetail(generateDetail(request, strewRecommendation));

        return new ResponseEntity<GenericResponse>(new GenericResponse(true, getMessage(SAVE_OPERATION_SUCCEEDED)), HttpStatus.OK);
    }


    @RequestMapping("/search")
    @ResponseBody
    public Page<StrewRecommendation> search(@ModelAttribute StrewRecommendationForm form, Pageable pageable) {
        return strewRecommendationService.search(form.getProductionZoneId(), form.getProductionCyclesId(), form.getHybridId(), form.getSourceCode(), pageable);
    }

    @RequestMapping(value = "/findById")
    @ResponseBody
    public StrewRecommendation findById(@RequestParam Long id) {
        return strewRecommendationService.findById(id);
    }

    @RequestMapping(value = "/delete")
    @ResponseBody
    public ResponseEntity<GenericResponse> delete(@RequestParam Long id) {
        strewRecommendationService.delete(id);
        return new ResponseEntity<GenericResponse>(new GenericResponse(true, getMessage(DELETE_OPERATION_SUCCEEDED)), HttpStatus.OK);
    }

    @RequestMapping(value = "/getRealReport")
    @ResponseBody
    public List<RealReportStrewRecommendationVO> getRealReport(@ModelAttribute StrewRecommendationForm form) {
        setRealReportInformation(strewRecommendationService.getRealReport(form.getRealReportYear(), form.getRealReportYear(), form.getRealReportStartDay(), form.getRealReportStartMonth(), form.getRealReportMetStationId(), form.getRealReportTempMin(), form.getRealReportTempMax(), form.getRealReportCropStageData(), form.getCropName()));
        return getRealReportInformation();
    }

    @RequestMapping(value = "/export")
    @ResponseBody
    public ModelAndView export(@RequestParam Integer year, @RequestParam String metStation, @RequestParam String tempType) {

        if (getRealReportInformation() != null && !getRealReportInformation().isEmpty()) {
            Map<String, Object> model = new HashMap<String, Object>();
            model.put("dataList", getRealReportInformation());
            model.put("selectedYear", year);
            model.put("metStation", metStation);
            model.put("tempType", tempType);
            return new ModelAndView("sowRecommendationDateGduExcelView", "excelData", model);
        }

        return null;

    }

    private List<StrewRecommendationDetail> generateDetail(HttpServletRequest request, StrewRecommendation strewRecommendation) {

        List<StrewRecommendationDetail> ls = new ArrayList<StrewRecommendationDetail>();

        for (CropStage currentStage : getCropStageVariables()) {
            Double valueDb = validateData(request.getParameter("cropStageDetail-" + currentStage.getId()));
            ls.add(new StrewRecommendationDetail(strewRecommendation, currentStage, valueDb));
        }
        return ls;
    }

    private Double validateData(String valueStr) {
        try {
            return Double.parseDouble(valueStr);
        } catch (Exception e) {
            return 0.0;
        }
    }

    private void loadCropStages(String callType, Long cropId) {
        if (callType != null && callType.equalsIgnoreCase(TD)) {
            setCropStageVariables(cropStageService.loadCollectionNotDefault());
        } else if (callType != null && callType.equalsIgnoreCase(FIELD_PROD) || (callType != null && callType.equalsIgnoreCase(PROD_RESEARCH))) {
            setCropStageVariables(cropStageService.loadCollectionNotDefaultByCropId(cropId));
        } else {
            throw new WMSException("Illegal Entry, consult your administrator:Error [Data Type Invalid]");
        }
    }

    public Collection<CropStage> getCropStageVariables() {
        return cropStageVariables;
    }

    public void setCropStageVariables(Collection<CropStage> cropStageVariables) {
        this.cropStageVariables = cropStageVariables;
    }

    public List<RealReportStrewRecommendationVO> getRealReportInformation() {
        return realReportInformation;
    }

    public void setRealReportInformation(List<RealReportStrewRecommendationVO> realReportInformation) {
        this.realReportInformation = realReportInformation;
    }
}
