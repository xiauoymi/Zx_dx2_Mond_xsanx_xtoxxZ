package com.monsanto.wms.web.form.production;

import com.monsanto.wms.persistence.model.CropStage;

import java.util.Collection;
import java.util.List;


/**
 * Created by IntelliJ IDEA.
 * User: MANIET
 * Date: 7/1/13
 * Time: 3:53 PM
 * To change this template use File | Settings | File Templates.
 */
public class StrewRecommendationForm {

    private Long cropStage;
    private Double cropStageValue;
    private Long strewRecommendationId;

    private Long productionZoneId;
    private Long productionCyclesId;
    private Long hybridId;
    private String hybridDescription;

    private Integer realReportYear;
    private Integer realReportStartDay;
    private Integer realReportStartMonth;
    private Long realReportMetStationOwnerId;
    private Long realReportMetStationId;
    private Long realReportCropType;
    private Long realReportCrop;
    private Double realReportTempMin;
    private Double realReportTempMax;
    private String realReportCropStageData;

    private String sourceCode;
    private String temperatureIn;
    private String cropName;


    private Collection<CropStage> cropStageVariables;
    private String firstLoad;

    public Long getCropStage() {
        return cropStage;
    }

    public void setCropStage(Long cropStage) {
        this.cropStage = cropStage;
    }

    public Double getCropStageValue() {
        return cropStageValue;
    }

    public void setCropStageValue(Double cropStageValue) {
        this.cropStageValue = cropStageValue;
    }

    public Long getStrewRecommendationId() {
        return strewRecommendationId;
    }

    public void setStrewRecommendationId(Long strewRecommendationId) {
        this.strewRecommendationId = strewRecommendationId;
    }

    public Long getProductionZoneId() {
        return productionZoneId;
    }

    public void setProductionZoneId(Long productionZoneId) {
        this.productionZoneId = productionZoneId;
    }

    public Long getProductionCyclesId() {
        return productionCyclesId;
    }

    public void setProductionCyclesId(Long productionCyclesId) {
        this.productionCyclesId = productionCyclesId;
    }

    public Long getHybridId() {
        return hybridId;
    }

    public void setHybridId(Long hybridId) {
        this.hybridId = hybridId;
    }

    public Collection<CropStage> getCropStageVariables() {
        return cropStageVariables;
    }

    public void setCropStageVariables(Collection<CropStage> cropStageVariables) {
        this.cropStageVariables = cropStageVariables;
    }

    public String getHybridDescription() {
        return hybridDescription;
    }

    public void setHybridDescription(String hybridDescription) {
        this.hybridDescription = hybridDescription;
    }

    public Integer getRealReportYear() {
        return realReportYear;
    }

    public void setRealReportYear(Integer realReportYear) {
        this.realReportYear = realReportYear;
    }

    public Integer getRealReportStartDay() {
        return realReportStartDay;
    }

    public void setRealReportStartDay(Integer realReportStartDay) {
        this.realReportStartDay = realReportStartDay;
    }

    public Integer getRealReportStartMonth() {
        return realReportStartMonth;
    }

    public void setRealReportStartMonth(Integer realReportStartMonth) {
        this.realReportStartMonth = realReportStartMonth;
    }

    public Long getRealReportMetStationId() {
        return realReportMetStationId;
    }

    public void setRealReportMetStationId(Long realReportMetStationId) {
        this.realReportMetStationId = realReportMetStationId;
    }

    public Double getRealReportTempMin() {
        return realReportTempMin;
    }

    public void setRealReportTempMin(Double realReportTempMin) {
        this.realReportTempMin = realReportTempMin;
    }

    public Double getRealReportTempMax() {
        return realReportTempMax;
    }

    public void setRealReportTempMax(Double realReportTempMax) {
        this.realReportTempMax = realReportTempMax;
    }

    public String getRealReportCropStageData() {
        return realReportCropStageData;
    }

    public void setRealReportCropStageData(String realReportCropStageData) {
        this.realReportCropStageData = realReportCropStageData;
    }

    public Long getRealReportMetStationOwnerId() {
        return realReportMetStationOwnerId;
    }

    public void setRealReportMetStationOwnerId(Long realReportMetStationOwnerId) {
        this.realReportMetStationOwnerId = realReportMetStationOwnerId;
    }

    public Long getRealReportCropType() {
        return realReportCropType;
    }

    public void setRealReportCropType(Long realReportCropType) {
        this.realReportCropType = realReportCropType;
    }

    public Long getRealReportCrop() {
        return realReportCrop;
    }

    public void setRealReportCrop(Long realReportCrop) {
        this.realReportCrop = realReportCrop;
    }

    public String getSourceCode() {
        return sourceCode;
    }

    public void setSourceCode(String sourceCode) {
        this.sourceCode = sourceCode;
    }

    public String getTemperatureIn() {
        return temperatureIn;
    }

    public void setTemperatureIn(String temperatureIn) {
        this.temperatureIn = temperatureIn;
    }

    public String getCropName() {
        return cropName;
    }

    public void setCropName(String cropName) {
        this.cropName = cropName;
    }

    public String getFirstLoad() {
        return firstLoad;
    }

    public void setFirstLoad(String firstLoad) {
        this.firstLoad = firstLoad;
    }
}
