package com.monsanto.wms.web.form.security;

/**
 * Created by IntelliJ IDEA.
 * User: MANIET
 * Date: 6/17/13
 * Time: 9:43 AM
 * To change this template use File | Settings | File Templates.
 */
public class UserForm {

    private String userId;
    private String name;
    private String email;
    private Boolean sendNotification;
    private Boolean activeStatus;


    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public Boolean getActiveStatus() {
        return activeStatus;
    }

    public void setActiveStatus(Boolean activeStatus) {
        this.activeStatus = activeStatus;
    }

    public Boolean getSendNotification() {
        return sendNotification;
    }

    public void setSendNotification(Boolean sendNotification) {
        this.sendNotification = sendNotification;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
