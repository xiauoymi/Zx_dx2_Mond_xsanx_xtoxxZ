package com.monsanto.wms.web.controller.tools;

import com.monsanto.wms.service.tools.CalculatorService;
import com.monsanto.wms.vo.UnderZeroCalculationVO;
import com.monsanto.wms.web.controller.commons.BaseController;
import com.monsanto.wms.web.form.tools.CalculatorForm;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.MessageSource;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by IntelliJ IDEA.
 * User: MANIET
 * Date: 6/3/13
 * Time: 3:58 PM
 * To change this template use File | Settings | File Templates.
 */
@Controller
@RequestMapping("/tools/calculatorBase")
public final class CalculatorController extends BaseController {

    private static final String CALCULATOR_BASE = "tools/calculatorBase";

    private CalculatorService calculatorService;

    @Autowired
    public CalculatorController(CalculatorService calculatorService, @Qualifier("messageSource") MessageSource messageSource) {
        super();
        this.calculatorService = calculatorService;
        setMessageSource(messageSource);
    }

    @RequestMapping("/init")
    public ModelAndView initView() {
        Map<String, Object> model = new HashMap<String, Object>();

        model.put("dataFormA", new CalculatorForm());
        model.put("dataFormB", new CalculatorForm());
        model.put("dataFormC", new CalculatorForm());
        model.put("dataFormD", new CalculatorForm());
        model.put("dataFormE", new CalculatorForm());

        return new ModelAndView(CALCULATOR_BASE, model);
    }

    @RequestMapping("/generalCalculationBy")
    @ResponseBody
    public Object generalCalculationBy(@ModelAttribute CalculatorForm form) {
        if (form.getCalculationTypeA().equalsIgnoreCase("GDU")) {
            return calculatorService.getGeneralCalculationByGDU(form.getStartDate(), form.getEndDate(),
                    form.getDayOfTheMonthA(), form.getMonthSectionA(),
                    form.getMeteorologicalStationId(), form.getCurrentValueA(),
                    form.getTempMin(), form.getTempMax(), form.getCropName());
        } else {
            return calculatorService.getGeneralCalculationByDay(form.getStartDate(), form.getEndDate(),
                    form.getDayOfTheMonthA(), form.getMonthSectionA(),
                    form.getMeteorologicalStationId(), form.getCurrentValueA().intValue(), form.getTempMin(),form.getTempMax(),form.getCropName());
        }
    }

    @RequestMapping("/weeklyCalculationBy")
    @ResponseBody
    public Object weeklyCalculationBy(@ModelAttribute CalculatorForm form) {
       // if (form.getCalculationTypeB().equalsIgnoreCase("GDU")) {
            return calculatorService.getWeeklyCalculationByGDU(form.getStartDate(), form.getEndDate(),
                    form.getMonthSectionB(), form.getMeteorologicalStationId(),
                    form.getCurrentValueB(), form.getTempMin(), form.getTempMax(), form.getCropName());
       // } else {
           // return calculatorService.getWeeklyCalculationByDay(form.getStartDate(), form.getEndDate(), form.getMonthSectionB(), form.getMeteorologicalStationId(), form.getCurrentValueB().intValue(), form.getCropName());
       // }
    }

    @RequestMapping("/getTemperaturesUnderZero")
    @ResponseBody
    public Page<UnderZeroCalculationVO> getTemperaturesUnderZero(@ModelAttribute CalculatorForm form) {

        if (form.isFisrtLoad()) {
            return new PageImpl(new ArrayList<UnderZeroCalculationVO>());
        } else {
            List<UnderZeroCalculationVO> ls = calculatorService.getUnderZeroCalculation(form.getYearC(), form.getMonthSectionC(), form.getMeteorologicalStationId());
            Page<UnderZeroCalculationVO> page = new PageImpl(ls);
            return page;
        }
    }

    @RequestMapping("/periodToGDU")
    @ResponseBody
    public Object periodToGDU(@ModelAttribute CalculatorForm form) {
        return calculatorService.getPeriodToGDU(form.getStartDate(), form.getEndDate(),
                form.getMonthSectionStartD(), form.getDayDStart(),
                form.getMonthSectionEndD(), form.getDayDEnd(),
                form.getMeteorologicalStationId(),
                form.getTempMin(), form.getTempMax(), form.getCropName());
    }


}
