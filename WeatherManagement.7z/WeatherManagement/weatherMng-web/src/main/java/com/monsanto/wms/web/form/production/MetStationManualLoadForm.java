package com.monsanto.wms.web.form.production;

import org.springframework.web.multipart.MultipartFile;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: MANIET
 * Date: 7/23/13
 * Time: 11:35 AM
 * To change this template use File | Settings | File Templates.
 */
public class MetStationManualLoadForm {
    private List<MultipartFile> files;
    private Long metStationId;
    private Long metStationOwnerId;
    private Integer day;
    private Integer month;
    private Integer year;
    private String temperatureIn;

    public MetStationManualLoadForm(){
        files = new ArrayList<MultipartFile>();
    }

    public List<MultipartFile> getFiles() {
        return files;
    }

    public void setFiles(List<MultipartFile> files) {
        this.files = files;
    }

    public Long getMetStationId() {
        return metStationId;
    }

    public void setMetStationId(Long metStationId) {
        this.metStationId = metStationId;
    }

    public Integer getDay() {
        return day;
    }

    public void setDay(Integer day) {
        this.day = day;
    }

    public Integer getMonth() {
        return month;
    }

    public void setMonth(Integer month) {
        this.month = month;
    }

    public Integer getYear() {
        return year;
    }

    public void setYear(Integer year) {
        this.year = year;
    }

    public Long getMetStationOwnerId() {
        return metStationOwnerId;
    }

    public void setMetStationOwnerId(Long metStationOwnerId) {
        this.metStationOwnerId = metStationOwnerId;
    }

    public String getTemperatureIn() {
        return temperatureIn;
    }

    public void setTemperatureIn(String temperatureIn) {
        this.temperatureIn = temperatureIn;
    }
}
