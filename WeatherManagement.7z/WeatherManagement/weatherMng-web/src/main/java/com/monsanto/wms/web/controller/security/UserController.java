package com.monsanto.wms.web.controller.security;

import com.monsanto.wms.persistence.model.User;
import com.monsanto.wms.service.security.UserService;
import com.monsanto.wms.vo.LdapUserVO;
import com.monsanto.wms.web.controller.commons.BaseController;
import com.monsanto.wms.web.form.security.UserForm;
import org.hibernate.validator.constraints.NotBlank;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.MessageSource;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import javax.validation.Valid;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by IntelliJ IDEA.
 * User: MANIET
 * Date: 6/3/13
 * Time: 3:58 PM
 * To change this template use File | Settings | File Templates.
 */
@Controller
@RequestMapping("/security/userBase")
public final class UserController extends BaseController {

    private static final String USER_BASE = "security/userBase";

    private UserService userService;

    @Autowired
    public UserController(UserService userService, @Qualifier("messageSource") MessageSource messageSource) {
        super();
        this.userService = userService;
        setMessageSource(messageSource);
    }

    @RequestMapping("/init")
    public ModelAndView initView() {
        Map<String, Object> model = new HashMap<String, Object>();

        model.put(DATA_FORM, new UserForm());
        return new ModelAndView(USER_BASE, model);
    }

    @RequestMapping("/saveOrUpdate")
    @ResponseBody
    public ResponseEntity<GenericResponse> saveOrUpdate(@ModelAttribute UserForm form) {

        userService.save(new User(form.getUserId(), form.getName(), form.getEmail(), form.getActiveStatus(), form.getSendNotification()));

        return new ResponseEntity<GenericResponse>(new GenericResponse(true, getMessage(SAVE_OPERATION_SUCCEEDED)), HttpStatus.OK);
    }

    @RequestMapping("/search")
    @ResponseBody
    public Page<User> search(@ModelAttribute UserForm form, Pageable pageable) {
        return userService.search(form.getUserId(), form.getName(), form.getEmail(), form.getActiveStatus(), pageable);
    }

    @RequestMapping(value = "/findById")
    @ResponseBody
    public User findById(@RequestParam String id) {
        return userService.findById(id);
    }


    @RequestMapping(value = "/delete")
    @ResponseBody
    public ResponseEntity<GenericResponse> delete(@RequestParam String id) {

        userService.delete(id);

        return new ResponseEntity<GenericResponse>(new GenericResponse(true, getMessage(DELETE_OPERATION_SUCCEEDED)), HttpStatus.OK);
    }

    @RequestMapping("/findLdapUser")
    @ResponseBody
    public Collection<LdapUserVO> findLdapUser(@RequestParam @Valid @NotBlank String userId) {

        return userService.findLdapUserByIdLike(userId);
    }


}
