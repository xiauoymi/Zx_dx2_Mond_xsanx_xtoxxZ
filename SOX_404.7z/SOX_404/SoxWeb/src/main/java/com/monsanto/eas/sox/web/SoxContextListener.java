package com.monsanto.eas.sox.web;

import org.apache.log4j.Logger;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

public class SoxContextListener implements ServletContextListener
{
    private static final Logger LOG = Logger.getLogger(SoxContextListener.class);

    @Override
    public void contextInitialized(ServletContextEvent servletContextEvent) {
        String banner = "\r\n" +
            "\r\n   _____  ______   __    _____ _             _           _ " +
            "\r\n  / ____|/ __ \\ \\ / /   / ____| |           | |         | |" +
            "\r\n | (___ | |  | \\ V /   | (___ | |_ __ _ _ __| |_ ___  __| |" +
            "\r\n  \\___ \\| |  | |> <     \\___ \\| __/ _` | '__| __/ _ \\/ _` |" +
            "\r\n  ____) | |__| / . \\    ____) | || (_| | |  | ||  __/ (_| |" +
            "\r\n |_____/ \\____/_/ \\_\\  |_____/ \\__\\__,_|_|   \\__\\___|\\__,_|" +
            "\r\n"
        ;
        System.out.println(banner);
        LOG.info(banner);
    }

    @Override
    public void contextDestroyed(ServletContextEvent servletContextEvent) {
        String banner = "\r\n" +
            "\r\n   _____  ______   __   _____ _                             _ " +
            "\r\n  / ____|/ __ \\ \\ / /  / ____| |                           | |" +
            "\r\n | (___ | |  | \\ V /  | (___ | |_ ___  _ __  _ __   ___  __| |" +
            "\r\n  \\___ \\| |  | |> <    \\___ \\| __/ _ \\| '_ \\| '_ \\ / _ \\/ _` |" +
            "\r\n  ____) | |__| / . \\   ____) | || (_) | |_) | |_) |  __/ (_| |" +
            "\r\n |_____/ \\____/_/ \\_\\ |_____/ \\__\\___/| .__/| .__/ \\___|\\__,_|" +
            "\r\n                                      | |   | |               " +
            "\r\n                                      |_|   |_|               " +
            "\r\n"
        ;
        System.out.println(banner);
        LOG.info(banner);
    }
}
