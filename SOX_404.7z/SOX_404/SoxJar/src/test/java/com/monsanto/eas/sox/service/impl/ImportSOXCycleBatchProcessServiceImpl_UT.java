package com.monsanto.eas.sox.service.impl;

import com.monsanto.eas.sox.dao.ControlEntityDao;
import com.monsanto.eas.sox.model.SoxControlEntity;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collection;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"classpath:test-sox-context.xml"})
@TransactionConfiguration(transactionManager = "transactionManager", defaultRollback = true)
@Transactional
public class ImportSOXCycleBatchProcessServiceImpl_UT {

    @Autowired
    private ControlEntityDao controlEntityDao;

    @Test
    public void testGetMissingCyclesFromPreviousPeriod(){
        String previousPeriodId = "FY14-Q2";
        String currentOrNewPeriod = "FY14-Q3";

        Collection<SoxControlEntity> cyclesFromPreviousPeriodList = controlEntityDao.lookupCyclesByPeriod(previousPeriodId);
        Collection<SoxControlEntity> cyclesFromCurrentPeriodList = controlEntityDao.lookupCyclesByPeriod(currentOrNewPeriod);

        assertNotNull(cyclesFromPreviousPeriodList);
        assertFalse(cyclesFromPreviousPeriodList.isEmpty());

        assertNotNull(cyclesFromCurrentPeriodList);
        assertFalse(cyclesFromCurrentPeriodList.isEmpty());
    }
}
