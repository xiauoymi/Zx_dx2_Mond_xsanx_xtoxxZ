package com.monsanto.eas.sox.dao;

import com.monsanto.eas.sox.model.SoxConfig;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;

import static junit.framework.Assert.assertNotNull;
import static junit.framework.Assert.assertTrue;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"/test-sox-context.xml"})
@TransactionConfiguration(transactionManager = "transactionManager", defaultRollback = true)
@Transactional
public class SoxConfigDao_UT {
    @Autowired
    private ConfigDao configDao = null;

    @Test
    public void lookupConfigsByNameReturnsValidData() throws Exception {
        List<SoxConfig> settings= null;
        settings = configDao.lookupConfigsByName("email.%");
        assertNotNull(settings);
        assertTrue(settings.size() != 0);
    }

    @Test
    public void savedObjectEqualsOriginalObject() throws Exception {
        SoxConfig config = new SoxConfig("some.parameter", "some value");
        configDao.merge(config);
        assertNotNull(config);
        assertNotNull(config.getParameterName());
        SoxConfig otherConfig = configDao.lookupConfigByName(config.getParameterName());
        assertNotNull(otherConfig);
        assertTrue(config.getParameterName().equals(otherConfig.getParameterName()));
    }

    @Test
    public void savedObjectInAListEqualsOriginalObject() throws Exception {
        List<SoxConfig> configList = new ArrayList<SoxConfig>();
        SoxConfig config = new SoxConfig("another.parameter", "some value");
        configList.add(config);
        configDao.saveConfigList(configList);
        assertNotNull(config);
        assertNotNull(config.getParameterName());
        SoxConfig otherConfig = configDao.lookupConfigByName(config.getParameterName());
        assertNotNull(otherConfig);
        assertTrue(config.getParameterName().equals(otherConfig.getParameterName()));
    }

    @Test
    public void nullReferenceDoesntBreakSave() throws Exception {
        configDao.saveConfigList(null);
        assertTrue(true);
    }

}
