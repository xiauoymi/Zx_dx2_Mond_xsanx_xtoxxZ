package com.monsanto.eas.sox.service.impl;

import com.monsanto.eas.sox.model.SOXPeriodWithCycleTemplateDataVO;
import com.monsanto.eas.sox.model.SoxControlEntity;
import com.monsanto.eas.sox.service.ImportSOXPeriodWithCyclesFromTemplateData2DBService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertNotNull;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"classpath:test-sox-context.xml"})
@TransactionConfiguration(transactionManager = "transactionManager", defaultRollback = true)
@Transactional
public class ImportSOXPeriodWithCyclesFromTemplateData2DBServiceImpl_UT {

    @Autowired
    private ImportSOXPeriodWithCyclesFromTemplateData2DBService importService;

    private List<SOXPeriodWithCycleTemplateDataVO> getSOXPeriodWithCycleTemplateDataList () {
        List<SOXPeriodWithCycleTemplateDataVO> soxPeriodWithCycleTemplateDataVOList = new ArrayList<SOXPeriodWithCycleTemplateDataVO>();

        SOXPeriodWithCycleTemplateDataVO soxPeriodWithCycleTemplateDataVO = new SOXPeriodWithCycleTemplateDataVO();
        soxPeriodWithCycleTemplateDataVO.setTemplateCycleDescription("Fixed Assets/Intangibles");
        soxPeriodWithCycleTemplateDataVO.setActivitiesOwner("FJADAN");
        soxPeriodWithCycleTemplateDataVO.setDeleteThisControl(false);
        soxPeriodWithCycleTemplateDataVO.setModifiedThisControl(true);
        soxPeriodWithCycleTemplateDataVO.setAddedThisControl(true);
        soxPeriodWithCycleTemplateDataVO.setOriginalEntity(false);
        soxPeriodWithCycleTemplateDataVO.setControlId("FA.04.05");
        soxPeriodWithCycleTemplateDataVO.setControlIdKey("FA.04.05");
        soxPeriodWithCycleTemplateDataVO.setCountry("US,Bangalore");
        soxPeriodWithCycleTemplateDataVO.setCycle("Fixed Assets/Intangibles");
        soxPeriodWithCycleTemplateDataVO.setSubcycle("Disposing of Fixed Assets");
        soxPeriodWithCycleTemplateDataVO.setSubcycleOwner("");
        soxPeriodWithCycleTemplateDataVO.setExistenceOfOccurrenceAssertion(false);
        soxPeriodWithCycleTemplateDataVO.setCompletenessAssertion(false);
        soxPeriodWithCycleTemplateDataVO.setValuationAndAllocationAssertion(false);
        soxPeriodWithCycleTemplateDataVO.setRightAndObligationAssertion(false);
        soxPeriodWithCycleTemplateDataVO.setPresentationAndDisclosureAssertion(false);
        soxPeriodWithCycleTemplateDataVO.setRisk("Assets held for sale are not valued appropriately.");
        soxPeriodWithCycleTemplateDataVO.setControl("Documentation for the valuation of assets to be held for sale is obtained by the business prior to moving the asset from active to held for sale.");
        soxPeriodWithCycleTemplateDataVO.setControlOwner("");
        soxPeriodWithCycleTemplateDataVO.setControlType("Manual");
        soxPeriodWithCycleTemplateDataVO.setFrequency("As Needed");
        soxPeriodWithCycleTemplateDataVO.setSystem("N/A");
        soxPeriodWithCycleTemplateDataVO.setPrevent("Detect");
        soxPeriodWithCycleTemplateDataVO.setFraud("No");
        soxPeriodWithCycleTemplateDataVO.setKey("No");

        soxPeriodWithCycleTemplateDataVOList.add(soxPeriodWithCycleTemplateDataVO);

        return soxPeriodWithCycleTemplateDataVOList;
    }

    @Test
    public void testImportLastSOXCyclesIntoACurrentPeriod() throws Exception {

        List<SOXPeriodWithCycleTemplateDataVO> soxPeriodWithCycleTemplateDataVOList = getSOXPeriodWithCycleTemplateDataList();
        String currentOrNewPeriod = "FY14-Q2";
        String cycleId = "FA";

        SoxControlEntity soxControlEntity = importService.importLastSOXCyclesIntoACurrentPeriod(soxPeriodWithCycleTemplateDataVOList, currentOrNewPeriod, "TEST", cycleId);

        assertNotNull(soxControlEntity);
    }

}
