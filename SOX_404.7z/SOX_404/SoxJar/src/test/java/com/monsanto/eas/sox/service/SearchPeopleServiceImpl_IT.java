package com.monsanto.eas.sox.service;

import com.monsanto.PeoplePicker.PersonInfo;
import com.monsanto.eas.sox.exception.InvalidUserException;
import com.monsanto.eas.sox.service.impl.SearchPeopleServiceImpl;
import com.monsanto.eas.sox.util.TestUtils;
import org.junit.BeforeClass;
import org.junit.Test;

import static org.junit.Assert.assertNotNull;

public class SearchPeopleServiceImpl_IT {

    @BeforeClass
    public static void configureSearchPeopleService() {
        TestUtils.setSearchPeopleServiceSystemProperties();
    }

    @Test
    public void testFindPersonByUserId() throws InvalidUserException {
        SearchPeopleServiceImpl searchPeopleService = new SearchPeopleServiceImpl();

        PersonInfo personInfo = searchPeopleService.findPersonByUserId("FJADAN");

        assertNotNull(personInfo);
    }
}
