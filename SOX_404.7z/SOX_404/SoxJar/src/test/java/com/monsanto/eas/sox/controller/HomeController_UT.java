/*
 Copyright:  Copyright � 2011 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.eas.sox.controller;

import com.monsanto.eas.sox.util.SoxConstants;
import org.junit.Test;
import org.springframework.web.servlet.ModelAndView;

import java.util.HashMap;

import static org.springframework.test.web.ModelAndViewAssert.assertModelAttributeValues;
import static org.springframework.test.web.ModelAndViewAssert.assertViewName;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author sspati1
 * @version $Revision$
 */
public class HomeController_UT {

    @Test
    public void testGoToHome_GoesToHome() throws Exception {
        HomeController controller = new HomeController();

        ModelAndView modelAndView = controller.goToHome();

        assertViewName(modelAndView, SoxConstants.HOME_VIEW);
        assertModelAttributeValues(modelAndView, new HashMap<String, Object>());
    }
}