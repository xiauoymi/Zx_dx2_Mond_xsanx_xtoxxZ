package com.monsanto.eas.sox.service;

import com.monsanto.eas.sox.util.DateToStringHelper;
import org.junit.Test;

import java.text.ParseException;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

public class DateToStringHelper_UT {

  private DateToStringHelper helper = new DateToStringHelper();
  private Calendar calendar = new GregorianCalendar(2013,2,4);

  @Test
  public void stringToDate() throws ParseException {
    String dateStr = "03/4/2013";
    Date date = helper.stringToDate(dateStr);
    System.out.println(String.format("%1$s -> %2$s", dateStr, date));
    assert(date != null);
  }

  @Test
  public void dateToString() {
    String dateStr = helper.dateToString(calendar.getTime());
    System.out.println(String.format("%1$s -> %2$s", dateStr, calendar.getTime()));
    assert(dateStr != null);
  }

}
