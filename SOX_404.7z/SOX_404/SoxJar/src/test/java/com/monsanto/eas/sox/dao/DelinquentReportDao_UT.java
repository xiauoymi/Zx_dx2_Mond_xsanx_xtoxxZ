package com.monsanto.eas.sox.dao;

import com.monsanto.eas.sox.model.DelinquentReportVO;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.util.Collection;

import static junit.framework.Assert.assertNotNull;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"/test-sox-context.xml"})
public class DelinquentReportDao_UT
{
    @Autowired
    private DelinquentReportDao delinquentReportDao = null;

    @Autowired
    private PeriodDao periodDao;

    @Test
    public void lookupCertificationsStarted() throws Exception {
        Collection<DelinquentReportVO> delinquentOwners = null;
        String periodId;
        periodId = periodDao.lookupCurrentPeriod().getPeriodId();
        delinquentOwners = delinquentReportDao.lookupDelinquentOwnersByPeriod(periodId);
        assertNotNull(delinquentOwners);
    }

}
