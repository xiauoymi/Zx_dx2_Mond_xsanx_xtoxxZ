package com.monsanto.eas.sox.service;

import com.monsanto.eas.sox.service.impl.FlexHtmlAdapter;
import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class FlexHtmlAdapter_UT
{
    private FlexHtmlAdapter flexHtmlAdapter = new FlexHtmlAdapter();

    private String[][] unneededTags = {
        {"<a a1=\"aa\">", "</a>", null},
        {"<b b1=\"bb\">", "</b>", "<BR/>"}
    };

    @Test
    public void testSimpleTags() {
        String flexHtml = "<a a1=\"aa\"><b b1=\"bb\"></b></a>";

        final String resultText = flexHtmlAdapter.removeFlexUnneededTags(flexHtml, unneededTags);

        assertEquals("<BR/>", resultText);
    }

    @Test
    public void testOneLevelNestedTags() {
        String flexHtml = "<a a1=\"aa\"><a a2=\"aa\"><b b1=\"bb\"></b></a></a>";

        final String resultText = flexHtmlAdapter.removeFlexUnneededTags(flexHtml, unneededTags);

        assertEquals("<a a2=\"aa\"><BR/></a>", resultText);
    }

    @Test
    public void testTwoLevelNestedTagsSameTag() {
        String flexHtml = "<a a1=\"aa\"><a a2=\"aa\"><a a1=\"aa\"></a><b b1=\"bb\"></b></a></a>";

        final String resultText = flexHtmlAdapter.removeFlexUnneededTags(flexHtml, unneededTags);

        assertEquals("<a a2=\"aa\"><BR/></a>", resultText);
    }

    @Test
    public void testTwoLevelNestedTagsDifferentTag() {
        String flexHtml = "<a a1=\"aa\"><a a2=\"aa\"><a a3=\"aa\"></a><b b1=\"bb\"></b></a></a>";

        final String resultText = flexHtmlAdapter.removeFlexUnneededTags(flexHtml, unneededTags);

        assertEquals("<a a2=\"aa\"><a a3=\"aa\"></a><BR/></a>", resultText);
    }

    @Test
    public void testBTwoLevelNestedTagsDifferentTag() {
        String flexHtml = "<b b1=\"bb\"><b b2=\"bb\"><b b3=\"bb\"></b><a a1=\"aa\"></a></b></b>";

        final String resultText = flexHtmlAdapter.removeFlexUnneededTags(flexHtml, unneededTags);

        assertEquals("<b b2=\"bb\"><b b3=\"bb\"></b><BR/></b>", resultText);
    }

    @Test
    public void testHTML() throws Exception {
        String[][] unneededTags2 = {
            {"<BR/><BR/>", null, "<BR/>"},
            {"<BR><BR>", null, "<BR>"},
            {"<FONT FACE=\"DroidSansSox\" SIZE=\"12\" COLOR=\"#000000\" LETTERSPACING=\"0\" KERNING=\"1\">", "</FONT>", "<BR/>"},
            {"<CENTER ALIGN=\"left\">", "</CENTER>", "<BR/>"},
            {"<P ALIGN=\"left\">", "</P>", "<BR/>"}
        };

        String flexHtml = new StringBuilder()
            .append("<BR/><BR/>")
            .append("<BR><BR>")
            .append("<FONT FACE=\"DroidSansSox\" SIZE=\"12\" COLOR=\"#000000\" LETTERSPACING=\"0\" KERNING=\"1\"></FONT>")
            .append("<CENTER ALIGN=\"left\"></CENTER>")
            .append("<P ALIGN=\"left\"></P>")
            .toString()
        ;

        final String resultText = flexHtmlAdapter.removeFlexUnneededTags(flexHtml, unneededTags2);

        assertEquals("<BR/><BR><BR/><BR/><BR/>", resultText);
    }

}
