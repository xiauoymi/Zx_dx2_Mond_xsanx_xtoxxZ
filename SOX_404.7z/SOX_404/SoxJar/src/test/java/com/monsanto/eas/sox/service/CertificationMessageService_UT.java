package com.monsanto.eas.sox.service;

import com.monsanto.eas.sox.service.impl.CertificationMessagesServiceImpl;
import org.junit.Test;

import java.util.HashMap;
import java.util.Map;

import static junit.framework.Assert.assertEquals;

public class CertificationMessageService_UT
{
    CertificationMessagesServiceImpl messageService = new CertificationMessagesServiceImpl();

    private Map<String, String> getDictionary() {
        Map<String, String> dictionary = new HashMap<String, String>();

        dictionary.put("email.entity.owner", "SMENDOZ");
        dictionary.put("email.entityList", "<tr><td colspan=\"3\">entityList</td></tr>");
        dictionary.put("email.currentPeriod", "FY13_Q1");
        dictionary.put("email.introductory.cycle.message", "Cycle's Introductory Message");

        return dictionary;
    }

    @Test
    public void replaceConstants() throws Exception {
        StringBuffer template = new StringBuffer()
            .append("User ID: {#email.entity.owner}, ")
            .append("Entity List: {#email.entityList}, ")
            .append("Current Period: {#email.currentPeriod}, ")
            .append("Cycle Message: {#email.introductory.cycle.message}")
        ;

        String message = messageService.replaceConstants(template, "cycle", getDictionary());

        assertEquals(
            "User ID: SMENDOZ, Entity List: <tr><td colspan=\"3\">entityList</td></tr>, Current Period: FY13_Q1, Cycle Message: Cycle's Introductory Message",
            message
        );
    }
}
