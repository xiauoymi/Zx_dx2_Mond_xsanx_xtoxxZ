package com.monsanto.eas.sox.dao;

import com.monsanto.eas.sox.model.SoxPeriod;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static junit.framework.Assert.assertNotNull;
import static junit.framework.Assert.assertTrue;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"/test-sox-context.xml"})
public class SoxPeriodDao_UT {
    @Autowired
    private PeriodDao periodDao = null;

    @Test
    public void lookupConfigByName() throws Exception {
        SoxPeriod period = null;
        List<SoxPeriod> periodList = null;
        Map<String, Object> parameters = new HashMap<String, Object>();
        parameters.put("periodId", "FY13-Q1");
        periodList = (List<SoxPeriod>)periodDao.findListByQueryName("lookupPeriodById", parameters);
        if (periodList != null && periodList.size() !=0){
            period = periodList.get(0);
        }
        System.out.println("lookupGapsByPeriod v1.03");
        if (period != null)
        {
            System.out.println(period);
        }
        assertNotNull(period);
    }

    @Test
    public void executeUpdate() throws Exception {
        Map<String, Object> parameters = new HashMap<String, Object>();
        parameters.put("periodId", "FY13-Q1");
        int count = periodDao.executeUpdate("UPDATE Sox_Period SET current_Period=decode(period_id, :periodId, 1, null)", parameters);
        assertTrue(count > 0);
    }

    @Test
    public void getNewPeriodAvailability() throws Exception {
        Boolean isNewPeriodAvailable;
        isNewPeriodAvailable = periodDao.getNewPeriodAvailability();
        System.out.println("isNewPeriodAvailable =" + isNewPeriodAvailable);
        assertNotNull(isNewPeriodAvailable);
    }
}
