package com.monsanto.eas.sox.model;

import org.junit.Test;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;


public class SoxOwner_UT {
    @Test
    public void shouldNotBeNoneWhenCreated() {
        SoxOwner owner = new SoxOwner();

        assertThat(owner.isNone(), is(false));
    }

    @Test
    public void shouldNotBeNoneWhenUserIdIsNotNullAndNotNone() {
        SoxOwner owner = new SoxOwner();
        owner.setUserId("HAHAH");

        assertThat(owner.isNone(), is(false));
    }

    @Test
    public void shouldBeNoneWhenUserIdIsNone() {
        SoxOwner owner = new SoxOwner();
        owner.setUserId("NONE");

        assertThat(owner.isNone(), is(true));
    }
}
