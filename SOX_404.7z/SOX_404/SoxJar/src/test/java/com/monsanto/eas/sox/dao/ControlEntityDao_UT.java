package com.monsanto.eas.sox.dao;

import com.google.common.collect.Maps;
import com.monsanto.eas.sox.model.PeriodMaintenanceVO;
import com.monsanto.eas.sox.model.RelatedActivityVO;
import com.monsanto.eas.sox.model.SoxPeriod;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.util.Collection;
import java.util.HashMap;

import static java.lang.String.format;
import static junit.framework.Assert.assertFalse;
import static junit.framework.Assert.assertNotNull;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"/test-sox-context.xml"})
public class ControlEntityDao_UT
{
    @Autowired
    private ControlEntityDao controlEntityDao;

    @Autowired
    private PeriodDao periodDao;

    @Test
    public void isPeriodOpenReturnsFalseForClosedPeriod() throws Exception {
        final String periodId = "FY14-Q3";
        boolean isPeriodOpen = controlEntityDao.isPeriodOpen(getPeriod(periodId));

        assertFalse(format("Period '%s' should be closed.", periodId), isPeriodOpen);
    }

    @Test
    public void getPeriodHistoricalData() throws Exception {
        final String periodId = "FY13-Q2";
        PeriodMaintenanceVO periodsHistoricalData = controlEntityDao.getPeriodHistoricalData(getPeriod(periodId));

        assertNotNull(format("Historical data must exist for period '%s'.", periodId), periodsHistoricalData);
    }

    @Test
    public void testGetActivitiesDifferentFromSelectedCycle() {
        final String periodId = "FY13-Q4";
        Collection<RelatedActivityVO> relatedActivityVOCollection = controlEntityDao.getActivitiesDifferentFromSelectedCycle(periodId);

        assertFalse(
            format("At least one related activity must exist for period '%s'.", periodId),
            relatedActivityVOCollection == null || relatedActivityVOCollection.isEmpty()
        );
    }

    private SoxPeriod getPeriod(String periodId) {
        final HashMap<String, Object> params = Maps.newHashMapWithExpectedSize(1);
        params.put("periodId", periodId);
        return periodDao.findListByQueryName("lookupPeriodById", params).get(0);
    }
}
