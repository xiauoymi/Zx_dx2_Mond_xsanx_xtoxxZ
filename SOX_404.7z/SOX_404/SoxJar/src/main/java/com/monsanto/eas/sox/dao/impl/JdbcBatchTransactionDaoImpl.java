package com.monsanto.eas.sox.dao.impl;

import com.monsanto.eas.sox.dao.JdbcBatchTransactionDao;
import com.monsanto.eas.sox.model.BatchTransactionVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import javax.sql.DataSource;

@Repository
public class JdbcBatchTransactionDaoImpl extends GenericDaoImpl<BatchTransactionVO> implements JdbcBatchTransactionDao {
    private static final long serialVersionUID = 1L;

    private JdbcTemplate jdbcTemplate;

    @Autowired
    public void setDataSource(DataSource dataSource) {
        this.jdbcTemplate = new JdbcTemplate(dataSource);
    }

    @Override
    public void save(BatchTransactionVO batchTransactionVO) {
//        jdbcTemplate.update("call sarbox_et.delete_sox_control_entity(?)",cycleId);
        jdbcTemplate.update("call sarbox_et.Maintenance.maintenance_ownership_rel(?,?,?)",
                batchTransactionVO.getTransactionLog(),
                batchTransactionVO.getDeleteOwner(),
                batchTransactionVO.getDeleteResponse());

    }
}
