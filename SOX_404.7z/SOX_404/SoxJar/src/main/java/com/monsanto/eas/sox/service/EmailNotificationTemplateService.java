package com.monsanto.eas.sox.service;

import com.monsanto.eas.sox.model.EmailNotificationTemplateVO;
import org.springframework.flex.remoting.RemotingInclude;
import org.springframework.transaction.annotation.Transactional;

public interface EmailNotificationTemplateService {
  @RemotingInclude
//  String save(EmailNotificationTemplateVO emailNotificationTemplateVO);
  String save(String notificationType, String subject, String body);

  @RemotingInclude
  @Transactional
  EmailNotificationTemplateVO getEmailNotificationTemplate(String notificationType);
}
