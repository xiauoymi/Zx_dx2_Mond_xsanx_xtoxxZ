package com.monsanto.eas.sox.jaxb.dao.impl;

import com.monsanto.eas.sox.jaxb.ActivityValidationAdp;
import com.monsanto.eas.sox.jaxb.UploadResult;
import com.monsanto.eas.sox.jaxb.dao.UploadResultXmlDao;
import com.monsanto.eas.sox.model.SoxControlEntity;
import org.springframework.stereotype.Repository;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Marshaller;
import java.io.ByteArrayOutputStream;

@Repository
public class UploadResultXmlDaoImpl implements UploadResultXmlDao {
    private final ActivityValidationAdp activityValidationAdp = new ActivityValidationAdp();

    @Override
    public String generateXml(UploadResult uploadResult) throws Exception {
        ByteArrayOutputStream output = new ByteArrayOutputStream();
        JAXBContext context = JAXBContext.newInstance(UploadResult.class);
        Marshaller marshaller = context.createMarshaller();
        marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);

        marshaller.marshal(uploadResult, output);

        return output.toString();
    }

    @Override
    public UploadResult getUploadResultFromCycle(SoxControlEntity cycle) {
        UploadResult uploadResult = new UploadResult();

        if (cycle != null) {
            uploadResult.setPeriodDescription("");

            if (cycle.getSoxPeriod() != null && cycle.getSoxPeriod().getPeriodDescription() != null) {
                uploadResult.setPeriodDescription(cycle.getSoxPeriod().getPeriodDescription());
            }

            uploadResult.setActivity(activityValidationAdp.getActivityValidationsFromSoxControlEntity(cycle));
        }

        return uploadResult;
    }
}
