package com.monsanto.eas.sox.service.impl;

import com.monsanto.eas.sox.service.EmailService;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Service;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.mail.*;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import java.util.Date;
import java.util.List;
import java.util.Properties;

/**
 * Created by IntelliJ IDEA.
 * User: SMENDOZ
 * Date: Nov 25, 2011
 * Time: 10:27:22 AM
 */
@Service
public class EmailServiceImpl implements EmailService {

    private static Logger logger = Logger.getLogger(EmailService.class);

    public boolean sendEmail(String toAddress, String fromAddress, String subject,
                             StringBuffer messageBody, List attachments) {
        fromAddress = fromAddress.trim();
        Session mailSession = Session.getDefaultInstance(getSystemProperties(), null);
        mailSession.setDebug(false);
        Message msg = new MimeMessage(mailSession);
        try {
            logger.info("sending "+subject+" to "+toAddress);
            msg.setFrom(new InternetAddress(fromAddress));
            msg.setRecipients(Message.RecipientType.TO, InternetAddress.parse(toAddress, false));
            msg.setSubject(subject);
            msg.setSentDate(new Date());
            if (!hasAttachments(attachments)) {
                msg.setContent(messageBody.toString(),"text/html");
            } else {
                addAttachments(messageBody, attachments, msg);
            }
            Transport.send(msg);
            return true;
        } catch (Exception e) {
            logger.error("error sending "+subject+" to "+toAddress, e);
            throw new RuntimeException("Error occured while sending the email: " + e.getMessage(), e);
        }
    }

    private boolean hasAttachments(List attachments) {
        return attachments != null && !attachments.isEmpty();
    }

    private void addAttachments(StringBuffer messageBody, List attachments, Message msg) throws MessagingException {
        Multipart multipart = new MimeMultipart();
        String fileName = (String) attachments.get(0);
        DataSource fileDataSource = new FileDataSource(fileName);
        BodyPart bodyPart = new MimeBodyPart();
        bodyPart.setDataHandler(new DataHandler(fileDataSource));
        bodyPart.setFileName(fileDataSource.getName());
        bodyPart.setDisposition(Part.ATTACHMENT);
        multipart.addBodyPart(bodyPart);
        bodyPart = new MimeBodyPart();
        bodyPart.setContent(messageBody.toString(),"text/html");
        multipart.addBodyPart(bodyPart);
        msg.setContent(multipart);
    }

    private Properties getSystemProperties() {
        Properties props = System.getProperties();
        props.put("mail.host", "mail.monsanto.com");
        props.put("mail.transport.protocol", "smtp");
        return props;
    }
}