package com.monsanto.eas.sox.exception;

public class TemplateException extends Exception {
	public TemplateException(){
		super();
	}

    public TemplateException(String message){
		super("TemplateException: " + message);
	}

	public TemplateException(Exception e){
		super(e);
	}
}
