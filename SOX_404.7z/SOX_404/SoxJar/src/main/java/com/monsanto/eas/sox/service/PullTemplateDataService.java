package com.monsanto.eas.sox.service;

import com.monsanto.eas.sox.model.SOXPeriodWithCycleTemplateDataVO;

import java.util.List;

public interface PullTemplateDataService {

   List<SOXPeriodWithCycleTemplateDataVO> getTemplateData(String periodId, String countryId, String cycleId);
}
