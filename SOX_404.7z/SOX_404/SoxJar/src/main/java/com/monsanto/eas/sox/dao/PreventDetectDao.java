package com.monsanto.eas.sox.dao;

import com.monsanto.eas.sox.model.PreventDetect;

public interface PreventDetectDao extends GenericDao<PreventDetect>{
    PreventDetect lookupPreventDetectByDescription(String description);
}
