package com.monsanto.eas.sox.util;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class DateToStringHelper {
  DateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");

  public String dateToString(Date date) {
    return date == null ? "" : String.format("%1$tm/%1$te/%1$tY", date);
  }

  public Date stringToDate(String dateStr) throws ParseException {
    return dateStr == null || dateStr.trim().length() == 0 ? null : (Date) formatter.parse(dateStr);
  }
}