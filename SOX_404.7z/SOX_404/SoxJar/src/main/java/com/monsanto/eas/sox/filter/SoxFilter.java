package com.monsanto.eas.sox.filter;

import com.monsanto.KerberosServletSecurity.KerberosSecurity;
import com.monsanto.Util.StringUtils;
import com.monsanto.eas.sox.util.SoxConstants;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.config.AutowireCapableBeanFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@Component
public class SoxFilter implements Filter {

    private FilterConfig config;

    private KerberosSecurity security;

    static Logger logger = Logger.getLogger(SoxFilter.class.getName());

    public SoxFilter(){
    }

    public void destroy() {
    }

    public void init(FilterConfig config) throws ServletException {
        this.config = config;
        ServletContext servletContext = config.getServletContext();
        WebApplicationContext webApplicationContext = WebApplicationContextUtils.getWebApplicationContext(servletContext);
        if (webApplicationContext != null) {
            AutowireCapableBeanFactory autowireCapableBeanFactory = webApplicationContext.getAutowireCapableBeanFactory();
            autowireCapableBeanFactory.autowireBean(this);
        }

    }

    public void doFilter(ServletRequest req, ServletResponse resp, FilterChain chain) throws ServletException, IOException {
        HttpServletRequest httpServletRequest = (HttpServletRequest) req;
        HttpServletResponse httpServletResponse = (HttpServletResponse) resp;
        String userId = null;

        security = getKerberosSecurity();
        security.init(httpServletRequest);
        userId = security.getUserID();
        logger.info("USER ID is: '" + userId+"'");
        if (StringUtils.isNullOrEmpty(userId)) {
            logger.info("Error 403 sent due to null or empty userId");
            httpServletResponse.sendError(403);
        } else {
            userId = userId.trim().toUpperCase();
            httpServletRequest.getSession(true).setAttribute(SoxConstants.WAM_USER_ID, userId);
        }

        chain.doFilter(req, resp);
    } // end of doFilter method


    private KerberosSecurity getKerberosSecurity() {
        if (security == null) {
            return new KerberosSecurity();
        } else {
            return security;
        }
    }

    public void setSecurity(KerberosSecurity security) {
        this.security = security;
    }

} // end of class
