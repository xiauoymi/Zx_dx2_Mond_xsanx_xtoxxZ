package com.monsanto.eas.sox.model;

import org.hibernate.annotations.Cascade;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.Collection;

@Entity
@Table(schema = "SARBOX_ET", name = "FRAUD")
@NamedQueries({
        @NamedQuery(name = "lookupFraudByDescription", query = "FROM Fraud f WHERE f.description=:description")
})
public class Fraud {
    @javax.persistence.Column(name = "FRAUD_ID", nullable = false, insertable = true, updatable = true, length = 22, precision = 0)
    @Id
    private int fraudId;

    @javax.persistence.Column(name = "DESCRIPTION", nullable = true, insertable = true, updatable = true, length = 250, precision = 0)
    @Basic
    private String description;

    @OneToMany(mappedBy = "fraud", fetch = FetchType.LAZY)
    @Cascade({org.hibernate.annotations.CascadeType.ALL})
    private Collection<SoxCtrlActivityEntity> soxCtrlActivityEntities= new ArrayList<SoxCtrlActivityEntity>();;

    public int getFraudId() {
        return fraudId;
    }

    public void setFraudId(int fraudId) {
        this.fraudId = fraudId;
    }


    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Collection<SoxCtrlActivityEntity> getSoxCtrlActivityEntities() {
        return soxCtrlActivityEntities;
    }

    public void setSoxCtrlActivityEntities(Collection<SoxCtrlActivityEntity> soxCtrlActivityEntities) {
        this.soxCtrlActivityEntities = soxCtrlActivityEntities;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Fraud fraud = (Fraud) o;

        if (fraudId != fraud.fraudId) return false;
        if (description != null ? !description.equals(fraud.description) : fraud.description != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = fraudId;
        result = 31 * result + (description != null ? description.hashCode() : 0);
        return result;
    }

    public void addSoxCtrlActivityEntity(SoxCtrlActivityEntity soxCtrlActivityEntity) {
        if (soxCtrlActivityEntity != null) {
            soxCtrlActivityEntity.setFraud(this);
            soxCtrlActivityEntities.add(soxCtrlActivityEntity);
        }
    }
}
