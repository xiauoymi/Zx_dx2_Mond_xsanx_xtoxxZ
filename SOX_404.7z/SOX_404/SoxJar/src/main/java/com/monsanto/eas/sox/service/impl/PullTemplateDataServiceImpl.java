package com.monsanto.eas.sox.service.impl;

import com.monsanto.eas.sox.model.*;
import com.monsanto.eas.sox.service.ControlEntityRelationShipService;
import com.monsanto.eas.sox.service.ControlEntityService;
import com.monsanto.eas.sox.service.PullTemplateDataService;
import com.monsanto.eas.sox.util.SoxConstants;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.flex.remoting.RemotingDestination;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

@Service
@RemotingDestination(value = "pullTemplateDataService")
public class PullTemplateDataServiceImpl implements PullTemplateDataService {

    @Autowired
    private ControlEntityService controlEntityService;

    @Autowired
    private ControlEntityRelationShipService controlEntityRelationShipService;

    private final Logger logger = Logger.getLogger(PullTemplateDataServiceImpl.class);


    public String getBaseCycleId(String cycleId) {
        String[] entityId = cycleId.split("\\.");
        String baseCycleId = "";

        baseCycleId = entityId[1];

        return baseCycleId;
    }

    @Override
    public List<SOXPeriodWithCycleTemplateDataVO> getTemplateData(String periodId, String countryId, String cycleId) {
        List<SOXPeriodWithCycleTemplateDataVO> soxPeriodWithCycleTemplateDataVOList = new ArrayList<SOXPeriodWithCycleTemplateDataVO>();
        try {
            String baseCycleId = getBaseCycleId(cycleId);

            Collection<SoxControlEntity> activities = controlEntityService.getActivities(periodId, countryId, cycleId);
            populateTemplate(activities, soxPeriodWithCycleTemplateDataVOList, baseCycleId);

            Collection<SoxControlEntityRelationship> relatedActivities = controlEntityRelationShipService.getRelatedActivitiesByCycle(cycleId);
            addRelatedActivities(relatedActivities, soxPeriodWithCycleTemplateDataVOList, baseCycleId);

        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return soxPeriodWithCycleTemplateDataVOList;
    }


    private void populateTemplate(Collection<SoxControlEntity> activities, List<SOXPeriodWithCycleTemplateDataVO> soxPeriodWithCycleTemplateDataVOList, String baseCycleId) {
        try {

            SoxControlEntity templateCycle = null;

            if (activities != null && activities.size() > 0) {
                templateCycle = activities.iterator().next().getParentControlEntity().getParentControlEntity();
            }

            String cycleDescription = null;
            String activitiesOwner = "";

            if (templateCycle != null) {
                cycleDescription = templateCycle.getDescription();

                if (templateCycle.getSoxControlEntityOwners() != null) {
                    activitiesOwner = controlEntityService.getActivityOwners(templateCycle);
                } else {
                    Collection<SoxControlEntityOwner> controlEntityOwnerCollection = controlEntityService.getControlEntityOwnerByControlEntityId(templateCycle.getControlEntityId());
                    activitiesOwner = controlEntityService.getActivityOwners(controlEntityOwnerCollection);
                }
            }

            for (SoxControlEntity activity : activities) {

                SOXPeriodWithCycleTemplateDataVO soxPeriodWithCycleTemplateDataVO = new SOXPeriodWithCycleTemplateDataVO();

                soxPeriodWithCycleTemplateDataVO.setTemplateCycleDescription(cycleDescription);
                soxPeriodWithCycleTemplateDataVO.setActivitiesOwner(activitiesOwner);

                SoxControlEntity subCycle = activity.getParentControlEntity();
                SoxControlEntity cycle = subCycle.getParentControlEntity();

                Iterator<SoxCtrlActivityEntity> it2 = activity.getSoxCtrlActivityEntities().iterator();
                SoxCtrlActivityEntity ctrlActivityEntity = null;
                while (it2.hasNext()) {
                    ctrlActivityEntity = it2.next();
                }

                Iterator<SoxCtrlActivityAssertion> it3 = ctrlActivityEntity.getSoxCtrlActivityAssertions().iterator();
                while (it3.hasNext()) {
                    SoxCtrlActivityAssertion ctrlActivityAssertion = it3.next();
                    if (ctrlActivityAssertion.getAssertion().getDescription().equals(SoxConstants.ASSERTION_EXISTENCE_OR_OCCURRENCE)) {
                        soxPeriodWithCycleTemplateDataVO.setExistenceOfOccurrenceAssertion(true);
                    } else if (ctrlActivityAssertion.getAssertion().getDescription().equals(SoxConstants.ASSERTION_COMPLETENESS)) {
                        soxPeriodWithCycleTemplateDataVO.setCompletenessAssertion(true);
                    } else if (ctrlActivityAssertion.getAssertion().getDescription().equals(SoxConstants.ASSERTION_VALUATION_AND_ALLOCATION)) {
                        soxPeriodWithCycleTemplateDataVO.setValuationAndAllocationAssertion(true);
                    } else if (ctrlActivityAssertion.getAssertion().getDescription().equals(SoxConstants.ASSERTION_RIGHT_AND_OBLIGATION)) {
                        soxPeriodWithCycleTemplateDataVO.setRightAndObligationAssertion(true);
                    } else if (ctrlActivityAssertion.getAssertion().getDescription().equals(SoxConstants.ASSERTION_PRESENTATION_AND_DISCLOSURE)) {
                        soxPeriodWithCycleTemplateDataVO.setPresentationAndDisclosureAssertion(true);
                    }
                }

                //Activity ID
                String controlId = activity.getControlEntityId();
                controlId = controlId.substring(controlId.indexOf('.') + 1);

                soxPeriodWithCycleTemplateDataVO.setBaseCycleId(baseCycleId);

                soxPeriodWithCycleTemplateDataVO.setControlId(controlId);
                soxPeriodWithCycleTemplateDataVO.setCountry(controlEntityService.getCountries(activity));
                soxPeriodWithCycleTemplateDataVO.setCycle(cycle.getDescription());
                soxPeriodWithCycleTemplateDataVO.setSubcycle(subCycle.getDescription());
                soxPeriodWithCycleTemplateDataVO.setSubcycleOwner(controlEntityService.getActivityOwners(subCycle));

                soxPeriodWithCycleTemplateDataVO.setRisk(ctrlActivityEntity.getRisk());
                soxPeriodWithCycleTemplateDataVO.setControl(activity.getDescription());
                soxPeriodWithCycleTemplateDataVO.setControlOwner(controlEntityService.getActivityOwners(activity));
                soxPeriodWithCycleTemplateDataVO.setControlType(ctrlActivityEntity.getTypeOfControl() != null ? ctrlActivityEntity.getTypeOfControl().getDescription() : "");
                soxPeriodWithCycleTemplateDataVO.setFrequency(ctrlActivityEntity.getFrequency() != null ? ctrlActivityEntity.getFrequency().getDescription() : "");
                soxPeriodWithCycleTemplateDataVO.setSystem(controlEntityService.getSoxSystems(ctrlActivityEntity));
                soxPeriodWithCycleTemplateDataVO.setPrevent(ctrlActivityEntity.getPreventDetect() != null ? ctrlActivityEntity.getPreventDetect().getDescription() : "");
                soxPeriodWithCycleTemplateDataVO.setFraud(ctrlActivityEntity.getFraud() != null ? ctrlActivityEntity.getFraud().getDescription() : "No");
                soxPeriodWithCycleTemplateDataVO.setKey(ctrlActivityEntity.getKey() != null ? ctrlActivityEntity.getKey().getDescription() : "No");

                soxPeriodWithCycleTemplateDataVOList.add(soxPeriodWithCycleTemplateDataVO);
            }
        } catch (Exception ex) {
            logger.error("Error exporting the template", ex);
        }
    }


    private void addRelatedActivities(Collection<SoxControlEntityRelationship> relatedActivities, List<SOXPeriodWithCycleTemplateDataVO> soxPeriodWithCycleTemplateDataVOList, String baseCycleId) {

        SOXPeriodWithCycleTemplateDataVO soxPeriodWithCycleTemplateDataVO = null;

        for (SoxControlEntityRelationship activity : relatedActivities) {

            String relatedControlId = activity.getRelatedControlActivityId();
            relatedControlId = relatedControlId.substring(relatedControlId.indexOf('.') + 1);

            soxPeriodWithCycleTemplateDataVO = new SOXPeriodWithCycleTemplateDataVO();

            soxPeriodWithCycleTemplateDataVO.setBaseCycleId(baseCycleId);

            soxPeriodWithCycleTemplateDataVO.setControlId(relatedControlId);
            soxPeriodWithCycleTemplateDataVO.setRisk(activity.getRisk());
            soxPeriodWithCycleTemplateDataVO.setControl(activity.getEntity().getDescription());

            soxPeriodWithCycleTemplateDataVO.setRelationshipId(activity.getId());

            soxPeriodWithCycleTemplateDataVOList.add(soxPeriodWithCycleTemplateDataVO);
        }
    }

}
