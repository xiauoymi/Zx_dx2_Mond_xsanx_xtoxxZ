package com.monsanto.eas.sox.dao.impl;

import com.monsanto.eas.sox.dao.BusinessTypeDao;
import com.monsanto.eas.sox.model.SoxBusinessType;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.util.Collection;

@Repository
public class BusinessTypeDaoImpl extends GenericDaoImpl<SoxBusinessType> implements BusinessTypeDao{
    private static final long serialVersionUID = 1L;

    @PersistenceContext
    private EntityManager entityManager;

    public Collection<SoxBusinessType> lookupAllBusinessType() {
        return entityManager.createNamedQuery("lookupAllBusinessType").getResultList();
    }
}
