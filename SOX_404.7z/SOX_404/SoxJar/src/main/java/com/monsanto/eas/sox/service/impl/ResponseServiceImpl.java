package com.monsanto.eas.sox.service.impl;

import com.monsanto.eas.sox.dao.ControlEntityDao;
import com.monsanto.eas.sox.dao.PeriodDao;
import com.monsanto.eas.sox.dao.ResponseDao;
import com.monsanto.eas.sox.model.*;
import com.monsanto.eas.sox.service.ResponseService;
import com.monsanto.eas.sox.service.ResponseTypeService;
import com.monsanto.eas.sox.service.SignificantChangeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.flex.remoting.RemotingDestination;
import org.springframework.flex.remoting.RemotingInclude;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;

@Service
@RemotingDestination(value = "responseService")
public class ResponseServiceImpl implements ResponseService {
   @Autowired
   private ResponseDao responseDao;

   @Autowired
   private ControlEntityDao controlEntityDao;

   @Autowired
   private ResponseTypeService responseTypeService;

   @Autowired
   private SignificantChangeService significantChangeService;

   @Autowired
   private PeriodDao periodDao;

   @RemotingInclude
   @Transactional
   public void saveOrUpdate(Collection<SoxResponse> responses) {
      Collection<SoxResponse> finalResponses = save(responses);

      updateControlEntity(finalResponses);

      SoxPeriod currentPeriod = periodDao.lookupCurrentPeriod();
      if (!controlEntityDao.isPeriodOpen(currentPeriod)) {
         currentPeriod.setClosedPeriod("1");
         periodDao.merge(currentPeriod);
      }
   }

   private void updateControlEntity(Collection<SoxResponse> responses) {

      boolean complete = true;
      SoxControlEntity ce = null;

      for (SoxResponse r : responses) {
         ce = r.getSoxControlEntityOwner().getSoxControlEntity();
         Collection<SoxControlEntityOwner> ceo = ce.getSoxControlEntityOwners();
         for (SoxControlEntityOwner currentControlEntityOwner : ceo) {
            Collection<SoxResponse> r1 = currentControlEntityOwner.getSoxResponses();
            for (SoxResponse t : r1) {

               ResponseType type = t.getResponseType();
               if (type == null)
                  complete = false;
            }
         }
      }

      if (complete && ce != null) {
         ce.setCompletedDate(new Date());
         controlEntityDao.merge(ce);
      } else if (ce != null) {
         ce.setCompletedDate(null);
         controlEntityDao.merge(ce);
      }
   }

   private Collection<SoxResponse> save(Collection<SoxResponse> responses) {
      boolean complete = true;

      Collection<SoxResponse> finalResponses = new ArrayList();

      if (responses != null && responses.size() == 2) {
         complete = true;
      }

      for (SoxResponse currentResponse : responses) {
         ResponseType responseType = responseTypeService.getResponseTypeByDescription(currentResponse.getResponseDescription());
         currentResponse.setResponseType(responseType);

         if (responseType == null)
            complete = false;

         responseDao.merge(currentResponse);
         currentResponse = responseDao.getReference(SoxResponse.class, currentResponse.getResponseId());

         finalResponses.add(currentResponse);
      }

      for (SoxResponse r : responses) {
         if (r.getSoxQuestion() != null) {
            r.getSoxQuestion().setSoxResponses(null);
         }
         if (r.getResponseType() != null) {
            r.getResponseType().setSoxResponses(null);
         }
         r.setSoxControlEntityOwner(null);
      }

      return finalResponses;
   }

   /**
    * Save responses and significant changes in a single transaction.
    *
    * @param entityId
    * @param userId
    * @param responses
    * @param significantChanges
    */
   @RemotingInclude
   @Transactional
   public void saveOrUpdate(String entityId, String userId, Collection<SoxResponse> responses, Collection<SoxSignificantChange> significantChanges) {
      saveOrUpdate(responses);
      significantChangeService.saveOrUpdate(entityId, userId, significantChanges);
   }

   @Override
   public void deleteSoxResponseWithoutReferences() {
      responseDao.deleteSoxResponseWithoutReferences();
   }

   @RemotingInclude
   public Collection<SoxResponse> getResponseByEntityAndOwner(String entityId, String userId) {

      Collection<SoxResponse> responses = responseDao.lookupResponseForEntityAndOwner(entityId, userId);
      String responseAsString = null;
      ResponseType responseType = null;
      for (SoxResponse currentResponse : responses) {
         currentResponse.getSoxQuestion().setSoxResponses(null);
         currentResponse.setSoxControlEntityOwner(null);
         responseType = currentResponse.getResponseType();
         if (responseType != null) {
            responseType.setSoxResponses(null);
            responseAsString = responseType.getDescription();
            if (responseAsString != null && !responseAsString.equalsIgnoreCase("")) {
               currentResponse.setResponseDescription(responseAsString);
            }
         }
      }

      return responses;
   }
}
