package com.monsanto.eas.sox.model;

public class GapReportVO {
    private String controlEntityId;
    private String userId;
    private String description;
    private String firstName;
    private String lastName;
    private String Region;


    public GapReportVO()
    {
        super();
    }

    public GapReportVO(String controlEntityId, String userId, String description) {
        super();
        this.controlEntityId = controlEntityId;
        this.userId = userId;
        this.description = description == null ? "" : description;
    }

    public String getControlEntityId() {
        return controlEntityId;
    }

    public void setControlEntityId(String controlEntityId) {
        this.controlEntityId = controlEntityId;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getRegion() {
        return Region;
    }

    public void setRegion(String region) {
        Region = region;
    }

    @Override
    public String toString() {
        return "GapReportVO{" +
                "controlEntityId='" + controlEntityId + '\'' +
                ", userId='" + userId + '\'' +
                ", description='" + description + '\'' +
                '}';
    }
}
