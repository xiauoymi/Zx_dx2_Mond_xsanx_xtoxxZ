package com.monsanto.eas.sox.dao;

import com.monsanto.eas.sox.model.SoxConfig;

import java.util.List;

public interface ConfigDao extends GenericDao<SoxConfig>{
  SoxConfig lookupConfigByName(String parameterName);
  void saveConfigList(List<SoxConfig> configList);
  List<SoxConfig> lookupConfigsByName(String parameterMask);
}
