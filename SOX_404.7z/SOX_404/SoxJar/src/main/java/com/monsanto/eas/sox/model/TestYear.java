package com.monsanto.eas.sox.model;

import java.io.Serializable;

public class TestYear implements Serializable{

  private String modUser;


  public String getModUser() {
    return modUser;
  }

  public void setModUser(String modUser) {
    this.modUser = modUser;
  }
}
