package com.monsanto.eas.sox.service.impl;

import com.monsanto.eas.sox.service.DateCalculationService;
import net.objectlab.kit.datecalc.common.DateCalculator;
import net.objectlab.kit.datecalc.common.HolidayHandlerType;
import net.objectlab.kit.datecalc.joda.LocalDateKitCalculatorsFactory;
import org.joda.time.LocalDate;
import org.springframework.stereotype.Service;

import java.util.Date;

/**
 * Created by IntelliJ IDEA.
 * User: JEESCO
 * Date: 15/02/2012
 * Time: 10:49:15 AM
 */
@Service
public class DateCalculationServiceImpl implements DateCalculationService {

    public Date calculateBusinessDate() {
        DateCalculator<LocalDate> dc = LocalDateKitCalculatorsFactory.getDefaultInstance().getDateCalculator("holidays", HolidayHandlerType.BACKWARD);        
        return dc.moveByBusinessDays(configureOffset()).getCurrentBusinessDate().toDate();
    }

    private int configureOffset() {
        return -1 * DAYS_FOR_SENDING_REMINDER;
    }
}
