package com.monsanto.eas.sox.service;

import com.monsanto.eas.sox.model.SoxQuestion;

import java.util.Collection;

public interface QuestionService {
    Collection<SoxQuestion> getQuestionsForEntity(String entityType);
    Collection<SoxQuestion> getAllQuestions();
}
