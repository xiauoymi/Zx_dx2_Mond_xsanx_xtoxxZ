package com.monsanto.eas.sox.service;

import com.monsanto.eas.sox.model.SOXPeriodWithCycleTemplateDataVO;
import com.monsanto.eas.sox.model.SoxControlEntity;

import java.util.List;

public interface ImportSOXPeriodWithCyclesFromTemplateData2DBService {

   SoxControlEntity importLastSOXCyclesIntoACurrentPeriod(List<SOXPeriodWithCycleTemplateDataVO> soxPeriodWithCycleTemplateDataVOList, String currentOrNewPeriod, String cycleDescription, String currentCycleId) throws Exception;

   SoxControlEntity updateSoxControlEntityActivity(SoxControlEntity soxControlEntity, SOXPeriodWithCycleTemplateDataVO soxPeriodWithCycleTemplateDataVO, String currentOrNewPeriod) throws Exception;

   SoxControlEntity updateCycleActivitiesOwner(SoxControlEntity cycle, String activitiesOwner, String entityType) throws Exception;
}
