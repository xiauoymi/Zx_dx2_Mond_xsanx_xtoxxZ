package com.monsanto.eas.sox.service;

import com.monsanto.eas.sox.model.DependentOverdueEntityVO;
import com.monsanto.eas.sox.model.EmailNotificationTemplateVO;

import java.util.Collection;

public interface CertificationMessagesService {
    void sendStartCertificationMessages(EmailNotificationTemplateVO emailNotificationTemplateVO) throws Exception;

    void sendReminderMessages(EmailNotificationTemplateVO emailNotificationTemplateVO) throws Exception;

    void sendEntityOwnersOverdueCertificationMessages(EmailNotificationTemplateVO emailNotificationTemplateVO) throws Exception;

    void sendEntityChildsOverdueCertificationMessages(EmailNotificationTemplateVO emailNotificationTemplateVO) throws Exception;

    void sendUncertifyNotice(EmailNotificationTemplateVO emailNotificationTemplateVO,Collection<DependentOverdueEntityVO> owners) throws Exception;
}
