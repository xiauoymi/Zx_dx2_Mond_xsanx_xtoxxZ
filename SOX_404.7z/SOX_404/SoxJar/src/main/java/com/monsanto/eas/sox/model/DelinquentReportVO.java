package com.monsanto.eas.sox.model;

import java.util.Date;

public class DelinquentReportVO {

    private String controlEntityId;
    private String userId;
    private String firstName;
    private String lastName;
    private String region;
    private Date endDate;
    private Date completedDate;
    private String controlEntityDescription;

    public DelinquentReportVO() { }

    public DelinquentReportVO(String controlEntityId, String userId, Date endDate, Date completedDate, String controlEntityDescription) {
        this.controlEntityId = controlEntityId;
        this.userId = userId;
        this.endDate = endDate;
        this.completedDate = completedDate;
        this.controlEntityDescription = controlEntityDescription;
    }

    public Date getEndDate() {
        return endDate;
    }

    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }

    public Date getCompletedDate() {
        return completedDate;
    }

    public void setCompletedDate(Date completedDate) {
        this.completedDate = completedDate;
    }

    public String getControlEntityDescription() {
        return controlEntityDescription;
    }

    public void setControlEntityDescription(String controlEntityDescription) {
        this.controlEntityDescription = controlEntityDescription;
    }

    public String getControlEntityId() {
        return controlEntityId;
    }

    public void setControlEntityId(String controlEntityId) {
        this.controlEntityId = controlEntityId;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getRegion() {
        return region;
    }

    public void setRegion(String region) {
        this.region = region;
    }
}
