package com.monsanto.eas.sox.service;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: SMENDOZ
 * Date: Nov 25, 2011
 * Time: 10:27:22 AM
 */
public interface EmailService {

     public boolean sendEmail(String toAddress, String fromAddress, String subject,
                           StringBuffer messageBody, List attachments);
}
