package com.monsanto.eas.sox.dao.impl;

import com.monsanto.eas.sox.dao.ControlEntityOwnerDao;
import com.monsanto.eas.sox.model.SoxControlEntityOwner;
import com.monsanto.eas.sox.model.SoxEntityOwnershipVO;
import com.monsanto.eas.sox.util.ControlEntityType;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Repository
public class ControlEntityOwnerDaoImpl extends GenericDaoImpl<SoxControlEntityOwner> implements ControlEntityOwnerDao {

    private static final long serialVersionUID = 1L;
    private static final String ENTITY_ID = "entityId";

    @PersistenceContext
    private EntityManager entityManager;

   @Override
   @Transactional
   public void deleteSoxControlEntityOwnerWithoutReferences() {
      entityManager.createNativeQuery("DELETE FROM SOX_CONTROL_ENTITY_OWNER c WHERE c.CONTROL_ENTITY_ID is null").executeUpdate();
   }

   public SoxControlEntityOwner lookupControlEntityOwnerByEntityAndOwner(String entityId, String userId) {
        SoxControlEntityOwner soxControlEntityOwner = null;
        List<SoxControlEntityOwner> soxControlEntityOwnerList = entityManager.createNamedQuery("lookupControlEntityOwnerByEntityAndOwner")
                .setParameter(ENTITY_ID, entityId)
                .setParameter("userId", userId).getResultList();
        if (soxControlEntityOwnerList != null && soxControlEntityOwnerList.size() > 0) {
            soxControlEntityOwner = soxControlEntityOwnerList.get(0);
        }
        return soxControlEntityOwner;
    }

   @Override
   public Collection<SoxControlEntityOwner> lookupControlEntityOwnerByControlEntityId(String entityId) {
        List<SoxControlEntityOwner> soxControlEntityOwnerList = entityManager.createNamedQuery("lookupControlEntityOwnerByControlEntityId")
                .setParameter(ENTITY_ID, entityId).getResultList();
        return soxControlEntityOwnerList;
   }

   @Override
    @SuppressWarnings("unchecked")
    public Collection<String> lookupEditableCycles() {
        Set<String> cycleSet = new HashSet<String>();
        cycleSet.addAll(entityManager.createNamedQuery("lookupEditableCycles").getResultList());
        cycleSet.addAll(entityManager.createNamedQuery("lookupEditableCyclesComplement").getResultList());

        return cycleSet;
    }

    public Collection<SoxControlEntityOwner> lookupControlEntityOwnerByPeriod(String periodId) {
        return entityManager.createNamedQuery("lookupOwnerStatusByPeriod").setParameter("periodId", periodId).getResultList();
    }

    private Collection<SoxEntityOwnershipVO> postProcessEntityPermissions(String queryName, ControlEntityType entityType, String userId) {
        Collection<SoxEntityOwnershipVO> entities;

        entities = entityManager.createNamedQuery(queryName).setParameter("userId", userId).getResultList();
        for (SoxEntityOwnershipVO entity : entities) {
            entity.setEntityType(entityType);
        }

        return entities;
    }

    public Collection<SoxEntityOwnershipVO> lookupCyclePermissionsForAnOwner(String userId) {
        return postProcessEntityPermissions("lookupCyclePermissionsForAnOwner", ControlEntityType.CYCLE, userId);
    }

    public Collection<SoxEntityOwnershipVO> lookupSubCyclePermissionsForAnOwner(String userId) {
        return postProcessEntityPermissions("lookupSubCyclePermissionsForAnOwner", ControlEntityType.SUB_CYCLE, userId);
    }

    public Collection<SoxEntityOwnershipVO> lookupActivitiesPermissionsForAnOwner(String userId) {
        return postProcessEntityPermissions("lookupActivitiesPermissionsForAnOwner", ControlEntityType.ACTIVITY, userId);
    }

    public Collection<SoxEntityOwnershipVO> lookupAllCycles() {
        return entityManager.createNamedQuery("lookupAllCyclesOwnership").getResultList();
    }

    public Collection<SoxEntityOwnershipVO> lookupAllSubcycles() {
        return entityManager.createNamedQuery("lookupAllSubcycles").getResultList();
    }

    public Collection<SoxEntityOwnershipVO> lookupSubCyclesForACycle(String cycle) {
        return entityManager.createNamedQuery("lookupSubCyclesForACycle").setParameter("cycle", cycle).getResultList();
    }

    public Collection<SoxEntityOwnershipVO> lookupActivitiesForACycleSubCycle(String cycle, String subCycle) {
        return entityManager.createNamedQuery("lookupActivitiesForACycleSubCycle").setParameter("cycle", cycle).setParameter("subCycle", subCycle).getResultList();
    }
}
