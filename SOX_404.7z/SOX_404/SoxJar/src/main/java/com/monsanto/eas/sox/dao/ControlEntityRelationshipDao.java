package com.monsanto.eas.sox.dao;

import com.monsanto.eas.sox.model.SoxControlEntityRelationship;

import java.util.Collection;


public interface ControlEntityRelationshipDao extends GenericDao<SoxControlEntityRelationship> {

    Collection<SoxControlEntityRelationship> lookupRelatedActivities(String cycleId);

    void deleteSoxControlEntityRelationship(int relationshipId);
}
