package com.monsanto.eas.sox.service.impl;

import com.monsanto.eas.sox.dao.ConfigDao;
import com.monsanto.eas.sox.model.SoxConfig;
import com.monsanto.eas.sox.service.ConfigService;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.flex.remoting.RemotingDestination;
import org.springframework.flex.remoting.RemotingInclude;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
@RemotingDestination(value="configService")
public class ConfigServiceImpl implements ConfigService {

    private Logger logger = Logger.getLogger(getClass().getName());

    @Autowired
    private ConfigDao configDao;

    @Override
    @RemotingInclude
    @Transactional
    public void save(SoxConfig config) {
        configDao.save(config);
    }

    @Override
    @RemotingInclude
    public void merge(SoxConfig config) {
        configDao.merge(config);
    }

    @Override
    @RemotingInclude
    public SoxConfig lookupConfigByName(String parameterName) {
        return configDao.lookupConfigByName(parameterName);
    }

    @Override
    @RemotingInclude
    public List<SoxConfig> lookupConfigsByName(String parameterMask) {
      List<SoxConfig> configList = null;
      try
      {
          if (parameterMask.indexOf("%") == -1){
            parameterMask += "%";
          }
          configList = configDao.lookupConfigsByName(parameterMask);
      } catch (Exception e) {
          logger.error(e.getMessage());
          configList = new ArrayList<SoxConfig>();
      }
      return configList;
    }

    @Override
    public Map<String, String> getDictionary(String parameterMask) {
      Map<String, String> dictionary = new HashMap();
      try
      {
          if (parameterMask.indexOf("%") == -1){
            parameterMask += "%";
          }
          List<SoxConfig> properties = configDao.lookupConfigsByName(parameterMask);
          if (properties != null){
              for (SoxConfig property : properties){
                dictionary.put(property.getParameterName(), property.getParameterValue());
              }
          }
      } catch (Exception e){
          dictionary = new HashMap();
          logger.error(e.getMessage());
      }
      return dictionary;
    }
}
