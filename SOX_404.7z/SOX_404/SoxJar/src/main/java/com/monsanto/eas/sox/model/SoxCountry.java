package com.monsanto.eas.sox.model;

import org.hibernate.annotations.Cascade;

import javax.persistence.*;
import java.util.HashSet;
import java.util.Set;

@Entity
@Table(name = "SOX_COUNTRY", schema = "SARBOX_ET")
public class SoxCountry {

    @javax.persistence.Column(name = "COUNTRY_ID", nullable = false, insertable = true, updatable = true, length = 22, precision = 0)
    @Id
    private int countryId;

    @javax.persistence.Column(name = "COUNTRY_DESCRIPTION", nullable = true, insertable = true, updatable = true, length = 500, precision = 0)
    @Basic
    private String countryDescription;

    @OneToMany(mappedBy = "soxCountry", fetch = FetchType.LAZY)
    @Cascade({org.hibernate.annotations.CascadeType.ALL})
    private Set<SoxControlEntityOwner> soxControlEntityOwners = new HashSet<SoxControlEntityOwner>();

    @ManyToMany(mappedBy = "countries", cascade = {CascadeType.PERSIST, CascadeType.MERGE}, fetch = FetchType.LAZY)
    private Set<SoxControlEntity> activities = new HashSet<SoxControlEntity>();

    public SoxCountry() {

    }

    public SoxCountry(int countryId, String countryDescription) {
        this.countryId = countryId;
        this.countryDescription = countryDescription;

    }
    public int getCountryId() {
        return countryId;
    }

    public void setCountryId(int countryId) {
        this.countryId = countryId;
    }

    public String getCountryDescription() {
        return countryDescription;
    }

    public void setCountryDescription(String countryDescription) {
        this.countryDescription = countryDescription;
    }

    public Set<SoxControlEntityOwner> getSoxControlEntityOwners() {
        return soxControlEntityOwners;
    }

    public void setSoxControlEntityOwners(Set<SoxControlEntityOwner> soxControlEntityOwners) {
        this.soxControlEntityOwners = soxControlEntityOwners;
    }

    public void addSoxControlEntityOwner(SoxControlEntityOwner controlEntityOwner) {
        if (controlEntityOwner != null) {
            controlEntityOwner.setSoxCountry(this);
            soxControlEntityOwners.add(controlEntityOwner);
        }
    }

    public Set<SoxControlEntity> getActivities() {
        return activities;
    }

    public void setActivities(Set<SoxControlEntity> activities) {
        this.activities = activities;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        SoxCountry that = (SoxCountry) o;

        if (countryId != that.countryId) return false;
        if (countryDescription != null ? !countryDescription.equals(that.countryDescription) : that.countryDescription != null)
            return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = countryId;
        result = 31 * result + (countryDescription != null ? countryDescription.hashCode() : 0);
        return result;
    }
}
