package com.monsanto.eas.sox.dao.impl;

import com.monsanto.eas.sox.dao.ControlEntityDao;
import com.monsanto.eas.sox.model.*;

import java.util.*;

public class SampleControlEntityDaoImpl extends GenericDaoImpl<SoxControlEntity> implements ControlEntityDao {
    @Override
    public PeriodMaintenanceVO getPeriodHistoricalData(SoxPeriod period) {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    @Override
    public boolean isPeriodOpen(SoxPeriod period) {
        return false;  //To change body of implemented methods use File | Settings | File Templates.
    }

    private static final long serialVersionUID = 1L;

    private String owner;
    private Collection<SoxControlEntityOwner> sampleOwners;
    private Collection<SoxControlEntity> sampleEntities;

    public SampleControlEntityDaoImpl() {
        this(null);
    }

    public SampleControlEntityDaoImpl(String owner) {
        this.owner = owner;
        SoxControlEntityOwner controlEntityOwner;
        sampleEntities = new ArrayList<SoxControlEntity>();
        sampleOwners = new ArrayList<SoxControlEntityOwner>();
        Calendar calendar = new GregorianCalendar();
        // CYCLE
        controlEntityOwner = getSampleOwner(1);
        SoxControlEntity cycle = new SoxControlEntity();
        cycle.setControlEntityId("sample.cycle");
        cycle.setStartDate(calendar.getTime());
        calendar.add(Calendar.DAY_OF_MONTH, 3);
        cycle.setEndDate(calendar.getTime());
        cycle.addSoxControlEntityOwner(controlEntityOwner);
        controlEntityOwner.setSoxControlEntity(cycle);
        sampleOwners.add(controlEntityOwner);

        // SUB-CYCLE
        controlEntityOwner = getSampleOwner(2);
        SoxControlEntity subCycle = new SoxControlEntity();
        subCycle.setControlEntityId("sample.cycle.subcycle");
        subCycle.setStartDate(calendar.getTime());
        calendar.add(Calendar.DAY_OF_MONTH, 3);
        subCycle.setEndDate(calendar.getTime());
        subCycle.setParentControlEntity(cycle);
        subCycle.addSoxControlEntityOwner(controlEntityOwner);
        controlEntityOwner.setSoxControlEntity(subCycle);
        sampleOwners.add(controlEntityOwner);

        // CONTROL
        controlEntityOwner = getSampleOwner(3);
        SoxControlEntity control = new SoxControlEntity();
        control.setControlEntityId("sample.cycle.subcycle.control");
        control.setStartDate(calendar.getTime());
        calendar.add(Calendar.DAY_OF_MONTH, 3);
        control.setEndDate(calendar.getTime());
        control.setParentControlEntity(subCycle);
        control.addSoxControlEntityOwner(controlEntityOwner);
        controlEntityOwner.setSoxControlEntity(control);
        sampleOwners.add(controlEntityOwner);

        subCycle.addChildEntity(control);
        cycle.addChildEntity(subCycle);
    }

    private Collection<SoxControlEntity> getSampleEntities() {
        return sampleEntities;
    }

    private SoxControlEntityOwner getSampleOwner(int id) {
        SoxOwner soxOwner = new SoxOwner();
        soxOwner.setOwnerId(id);
        soxOwner.setUserId(owner);

        SoxControlEntityOwner controlEntityOwner = new SoxControlEntityOwner();
        controlEntityOwner.setControlEntityOwnerId(id);
        controlEntityOwner.setSoxOwner(soxOwner);

        return controlEntityOwner;
    }

    private Collection<SoxControlEntityOwner> getSampleOwners() {
        return sampleOwners;
    }

    private Collection<DependentOverdueEntityVO> getSampleOverdueDependents() {
        Collection<DependentOverdueEntityVO> sampleDependents = new ArrayList<DependentOverdueEntityVO>();

        return sampleDependents;
    }

    @Override
    public SoxControlEntity lookupSoxControlEntityByControlId(String controlId) {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    @Override
    public Collection<SoxControlEntity> lookupAllCycles() {
        return getSampleEntities();
    }

    private Date getCurrentDate() {
        Calendar calendar = new GregorianCalendar();
        calendar.set(Calendar.HOUR_OF_DAY, 0);
        calendar.set(Calendar.MINUTE, 0);
        calendar.set(Calendar.SECOND, 0);
        calendar.set(Calendar.MILLISECOND, 0);

        return calendar.getTime();
    }

    @Override
    @SuppressWarnings("unchecked")
    public Collection<SoxControlEntityOwner> lookupCertificationsStarted(SoxPeriod period) {
        return getSampleOwners();
    }

    @Override
    @SuppressWarnings("unchecked")
    public Collection<SoxControlEntityOwner> lookupEntityOwnersCertificationsOverdue(SoxPeriod period) {
        return getSampleOwners();
    }

    @Override
    @SuppressWarnings("unchecked")
    public Collection<SoxControlEntityOwner> lookupEntityChildsCertificationsOverdue(SoxPeriod period) {
        return getSampleOwners();
    }

    @Override
    @SuppressWarnings("unchecked")
    public Collection<SoxControlEntity> lookupEntitiesNotCertifiedForUser(String userId) {
        return getSampleEntities();
    }

    @Override
    public Collection<DependentOverdueEntityVO> lookupChildsForAnEntity(String controlEntityId) {

        return getSampleOverdueDependents();
    }

    @SuppressWarnings("unchecked")
    public Collection<DependentOverdueEntityVO> lookupCertifiedOwnersForAnEntity(String controlEntityId, Date currentDate) {

        return getSampleOverdueDependents();
    }

    @Override
    public Collection<DependentOverdueEntityVO> lookupCertifiedOwnersForAnEntityWithoutDateRestriction(String controlEntityId) {
        return getSampleOverdueDependents();
    }

    @Override
    public Collection<RelatedActivityVO> getActivitiesDifferentFromSelectedCycle(String controlEntityId) {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    @SuppressWarnings("unchecked")
    public List<DependentOverdueEntityVO> lookupDelinquentOwnersForAnEntity(String controlEntityId, Date currentDate) {

        return (List<DependentOverdueEntityVO>) getSampleOverdueDependents();
    }

    @SuppressWarnings("unchecked")
    public Collection<DependentOverdueEntityVO> lookupPendingChildsForAnEntity(String controlEntityId, Date currentDate) {

        return getSampleOverdueDependents();
    }

    @Override
    @SuppressWarnings("unchecked")
    public Collection<SoxControlEntity> lookupCyclesOwnedByUser(String userId) {
        return getSampleEntities();
    }

    @Override
    @SuppressWarnings("unchecked")
    public Collection<SoxControlEntity> lookupSubCyclesOwnedByUser(String userId) {
        return getSampleEntities();
    }

    @Override
    @SuppressWarnings("unchecked")
    public Collection<SoxControlEntity> lookupActivitiesOwnedByUser(String userId) {
        return getSampleEntities();
    }

    @Override
    @SuppressWarnings("unchecked")
    public Collection<SoxControlEntity> lookupSubCyclesByUserAndCycle(String userId, String cycleId) {
        return getSampleEntities();
    }

    @Override
    @SuppressWarnings("unchecked")
    public Collection<SoxControlEntity> lookupActivitiesByUserAndCycle(String userId, String cycleId) {
        return getSampleEntities();
    }

    @Override
    public Collection<SoxControlEntity> lookupActivitiesByCycle(String periodId, String cycleId) {
        return getSampleEntities();
    }

    @Override
    @SuppressWarnings("unchecked")
    public Collection<SoxControlEntity> lookupActivitiesByCountry(String periodId, String countryId) {
        return getSampleEntities();
    }

    @Override
    @SuppressWarnings("unchecked")
    public Collection<SoxControlEntity> lookupActivitiesByCountryAndCycle(String periodId, String countryId, String cycleId) {
        return getSampleEntities();
    }

    @Override
    @SuppressWarnings("unchecked")
    public Collection<SoxControlEntity> lookupActivitiesByUserAndSubCycle(String userId, String subCycleId) {
        return getSampleEntities();
    }

    @Override
    @SuppressWarnings("unchecked")
    public Collection<SoxControlEntity> getIncompleteChildren(String parentEntityId) {
        return getSampleEntities();
    }

    @Override
    @SuppressWarnings("unchecked")
    public Collection<SoxControlEntity> lookupCyclesByPeriod(String periodId) {
        return getSampleEntities();
    }

    @Override
    @SuppressWarnings("unchecked")
    public Collection<SoxControlEntityOwner> lookupCertificationsToSendReminder(Date referenceDate, SoxPeriod period) {
        return getSampleOwners();
    }

    /*
    @Override
    @SuppressWarnings("unchecked")
    public Collection<SoxControlEntityOwner> lookupAllCertifications() {
      return getSampleOwners();
    }
    */

    public String getOwner() {
        return owner;
    }

    public void setOwner(String owner) {
        this.owner = owner;
    }
}
