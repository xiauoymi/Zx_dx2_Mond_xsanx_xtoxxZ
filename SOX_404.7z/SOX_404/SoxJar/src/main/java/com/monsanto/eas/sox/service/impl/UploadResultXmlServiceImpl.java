package com.monsanto.eas.sox.service.impl;

import com.monsanto.eas.sox.jaxb.UploadResult;
import com.monsanto.eas.sox.jaxb.dao.UploadResultXmlDao;
import com.monsanto.eas.sox.model.SoxControlEntity;
import com.monsanto.eas.sox.service.UploadResultXmlService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.flex.remoting.RemotingDestination;
import org.springframework.flex.remoting.RemotingInclude;
import org.springframework.stereotype.Service;

@Service
@RemotingDestination(value="uploadResultXmlService")
public class UploadResultXmlServiceImpl implements UploadResultXmlService {
    @Autowired
    private UploadResultXmlDao xmlDao;

    @RemotingInclude
    public String serialize(SoxControlEntity cycle, String state, String serverResponse) throws Exception
    {
        UploadResult uploadResult;

        uploadResult = xmlDao.getUploadResultFromCycle(cycle);
        uploadResult.setState(state);
        uploadResult.setServerResponse(serverResponse);

        return xmlDao.generateXml(uploadResult);
    }
}
