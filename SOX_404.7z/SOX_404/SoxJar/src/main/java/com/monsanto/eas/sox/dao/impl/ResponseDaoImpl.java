package com.monsanto.eas.sox.dao.impl;

import com.monsanto.eas.sox.dao.ResponseDao;
import com.monsanto.eas.sox.model.SoxGap;
import com.monsanto.eas.sox.model.SoxResponse;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.util.Collection;
import java.util.HashSet;
import java.util.Set;

/**
 * Created by SMENDOZ
 * User:
 * Date: 16/11/11
 * Time: 08:46 AM
 * To change this template use File | Settings | File Templates.
 */
@Repository
public class ResponseDaoImpl extends GenericDaoImpl<SoxResponse> implements ResponseDao {
   private static final long serialVersionUID = 1L;

   @PersistenceContext
   private EntityManager entityManager;

   static Logger logger = Logger.getLogger(ResponseDaoImpl.class.getName());


   @Override
   public Collection<SoxResponse> lookupResponseForEntityAndOwner(String entityId, String userId) {

      return entityManager.createNamedQuery("lookupResponseForEntityAndOwner")
              .setParameter("entityId", entityId)
              .setParameter("userId", userId)
              .getResultList();
   }

   @Override
   public SoxResponse lookupResponse() {
      return (SoxResponse) entityManager.createNamedQuery("lookupResponse").getSingleResult();
   }

   @Override
   @Transactional
   public void deleteSoxResponseWithoutReferences() {
      entityManager.createNativeQuery("DELETE FROM SOX_RESPONSE sr WHERE sr.CONTROL_ENTITY_OWNER_ID IN (SELECT CONTROL_ENTITY_OWNER_ID FROM SOX_CONTROL_ENTITY_OWNER c WHERE c.CONTROL_ENTITY_ID is null) ")
              .executeUpdate();
   }

   @Transactional
   public SoxResponse merge(SoxResponse response) {

      Set<SoxGap> gaps = response.getSoxGaps();
      SoxResponse result = null;

      SoxResponse tmpResponse = entityManager.getReference(SoxResponse.class, response.getResponseId());
      tmpResponse.setResponseType(response.getResponseType());
      Set<SoxGap> previousGaps = tmpResponse.getSoxGaps();

      for (SoxGap g : gaps) {
         g.setSoxResponse(tmpResponse);
      }

      previousGaps.addAll(gaps);

      Set<SoxGap> finalGaps = new HashSet<SoxGap>();

      for (SoxGap currentGap : previousGaps) {
         if (!contains(gaps, currentGap)) {
            currentGap = entityManager.getReference(SoxGap.class, currentGap.getGapId());
            currentGap.setSoxResponse(null);
            entityManager.remove(currentGap);

         } else {
            logger.debug("Previous gap found");
            finalGaps.add(currentGap);
         }

      }
      tmpResponse.setSoxGaps(finalGaps);
      result = entityManager.merge(tmpResponse);
      entityManager.flush();

      return result;
   }

   private boolean contains(Set<SoxGap> gaps, SoxGap gap) {
      boolean result = false;
      for (SoxGap currentGap : gaps) {
         if (currentGap.getGapId() == gap.getGapId())
            result = true;
      }
      return result;
   }
} // end of class
