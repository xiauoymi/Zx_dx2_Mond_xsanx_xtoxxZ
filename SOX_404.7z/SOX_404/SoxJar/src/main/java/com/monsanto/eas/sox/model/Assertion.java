package com.monsanto.eas.sox.model;

import javax.persistence.Basic;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(schema = "SARBOX_ET", name = "ASSERTION")
public class Assertion {
    @Id
    @javax.persistence.Column(name = "ASSERTION_ID", nullable = false, insertable = true, updatable = true, length = 22, precision = 0)
    private int assertionId;

    @javax.persistence.Column(name = "DESCRIPTION", nullable = true, insertable = true, updatable = true, length = 250, precision = 0)
    @Basic
    private String description;

/*
    @OneToMany(mappedBy = "assertion", fetch = FetchType.EAGER)
    @Cascade({org.hibernate.annotations.CascadeType.ALL})
    private Collection<SoxCtrlActivityAssertion> soxCtrlActivityAssertions = new ArrayList<SoxCtrlActivityAssertion>();
*/
    public int getAssertionId() {
        return assertionId;
    }

    public void setAssertionId(int assertionId) {
        this.assertionId = assertionId;
    }


    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

/*
    public Collection<SoxCtrlActivityAssertion> getSoxCtrlActivityAssertions() {
        return soxCtrlActivityAssertions;
    }

    public void setSoxCtrlActivityAssertions(Collection<SoxCtrlActivityAssertion> soxCtrlActivityAssertions) {
        this.soxCtrlActivityAssertions = soxCtrlActivityAssertions;
    }

    public void addSoxCtrlActivityAssertion(SoxCtrlActivityAssertion soxCtrlActivityAssertion){
        if (soxCtrlActivityAssertion != null) {
            soxCtrlActivityAssertion.setAssertion(this);
            soxCtrlActivityAssertions.add(soxCtrlActivityAssertion);
        }
    }
 */
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Assertion assertion = (Assertion) o;

        if (assertionId != assertion.assertionId) return false;
        if (description != null ? !description.equals(assertion.description) : assertion.description != null)
            return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = assertionId;
        result = 31 * result + (description != null ? description.hashCode() : 0);
        return result;
    }

}
