package com.monsanto.eas.sox.service;

import com.monsanto.PeoplePicker.PersonInfo;
import com.monsanto.eas.sox.exception.InvalidUserException;

import java.util.Collection;
import java.util.Set;

public interface SearchPeopleService {
    Collection<PersonInfo> getPeople(String lastName, String firstName, String phone, String mailStop, String userId, String site, String mailZone);

    PersonInfo[] findPersonsByUserId(String userId);

    PersonInfo findPersonByUserId(String userId) throws InvalidUserException;

    Set<String> getInvalidUserIdsForPeriod(String periodId);

    boolean isValid (PersonInfo personInfo);
}
