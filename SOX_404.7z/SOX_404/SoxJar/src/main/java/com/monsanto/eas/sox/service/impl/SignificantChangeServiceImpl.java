package com.monsanto.eas.sox.service.impl;

import com.monsanto.eas.sox.dao.ControlEntityOwnerDao;
import com.monsanto.eas.sox.dao.SignificantChangeDao;
import com.monsanto.eas.sox.model.SoxControlEntityOwner;
import com.monsanto.eas.sox.model.SoxSignificantChange;
import com.monsanto.eas.sox.service.SignificantChangeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.flex.remoting.RemotingDestination;
import org.springframework.flex.remoting.RemotingInclude;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collection;

@Service
@RemotingDestination(value="significantChangeService")
public class SignificantChangeServiceImpl implements SignificantChangeService{

    @Autowired
    private SignificantChangeDao significantChangeDao;

    @Autowired
    private ControlEntityOwnerDao controlEntityOwnerDao;


   @Override
   public void deleteSignificantChangeWithoutReferences() {
      significantChangeDao.deleteSignificantChangeWithoutReferences();
   }

   @RemotingInclude
    public Collection<SoxSignificantChange> getSignificantChangeByEntityAndOwner(String controlEntityId, String userId) {
        return prepareForFlex(significantChangeDao.lookupSignificantChangeByEntityAndOwner(controlEntityId, userId));
    }

    Collection<SoxSignificantChange> prepareForFlex(Collection<SoxSignificantChange> significantChanges){
      if (significantChanges != null) {
        for (SoxSignificantChange significantChange : significantChanges){
            if (significantChange.getSoxBusinessType() != null){
                significantChange.getSoxBusinessType().setSoxSignificantChanges(null);
            }
            if (significantChange.getSoxControlEntityOwner() != null){
                significantChange.getSoxControlEntityOwner().setSoxControlEntity(null);
                significantChange.getSoxControlEntityOwner().setSoxOwner(null);
                significantChange.getSoxControlEntityOwner().setSoxSignificantChanges(null);
                significantChange.getSoxControlEntityOwner().setSoxCountry(null);
                significantChange.getSoxControlEntityOwner().setSoxResponses(null);
            }
        }
      }

      return significantChanges;
    }

    @RemotingInclude
    @Transactional
    public Collection<SoxSignificantChange> saveOrUpdate(String entityId, String userId, Collection<SoxSignificantChange> significantChanges) {

        SoxControlEntityOwner soxControlEntityOwner = controlEntityOwnerDao.lookupControlEntityOwnerByEntityAndOwner(entityId, userId);

        if(soxControlEntityOwner != null) {

            if(significantChanges != null && significantChanges.size() == 0){
//                soxControlEntityOwner.setSoxSignificantChanges(null);
                Collection<SoxSignificantChange> significantChangesCollection = getSignificantChangeByEntityAndOwner(entityId, userId);
                for(SoxSignificantChange currentSignificantChange : significantChangesCollection) {
                    currentSignificantChange = significantChangeDao.getReference(SoxSignificantChange.class, currentSignificantChange.getSignificantChangeId());
                    currentSignificantChange.setSoxControlEntityOwner(null);
                    soxControlEntityOwner.setSoxSignificantChanges(null);
                    significantChangeDao.delete(currentSignificantChange);
                }

            } else {
                for (SoxSignificantChange currentSignificantChange : significantChanges) {
                    currentSignificantChange.setSoxControlEntityOwner(soxControlEntityOwner);
                    significantChangeDao.merge(currentSignificantChange);
                }
            }

        }


        return significantChanges;
    }
}
