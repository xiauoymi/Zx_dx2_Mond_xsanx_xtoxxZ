package com.monsanto.eas.sox.dao.impl;

import com.monsanto.eas.sox.dao.CountryDao;
import com.monsanto.eas.sox.model.SoxCountry;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.util.Collection;
import java.util.List;

@Repository
public class CountryDaoImpl extends GenericDaoImpl<SoxCountry> implements CountryDao{
    private static final long serialVersionUID = 1L;

    @PersistenceContext
    private EntityManager entityManager;


    @Override
    public SoxCountry lookupCountryByDescription(String description) {
        SoxCountry country = null;
        List<SoxCountry> countryList = entityManager.createNamedQuery("lookupCountryByDescription")
                .setParameter("description", description)
                .getResultList();

        if (countryList != null && countryList.size() > 0) {
            country = countryList.get(0);
        }
        return country;
    }

    @Override
    public Collection<SoxCountry> lookupAllCountries() {
        return entityManager.createNamedQuery("lookupAllCountries").getResultList();
    }
}


