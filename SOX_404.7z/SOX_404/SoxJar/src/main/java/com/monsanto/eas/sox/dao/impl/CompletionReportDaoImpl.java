package com.monsanto.eas.sox.dao.impl;

import com.monsanto.eas.sox.dao.CompletionReportDao;
import com.monsanto.eas.sox.model.CompletionReportVO;
import org.springframework.stereotype.Repository;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: JEESCO
 * Date: 1/02/2012
 * Time: 04:40:14 PM
 */
@Repository
public class CompletionReportDaoImpl extends GenericDaoImpl<CompletionReportVO> implements CompletionReportDao {
    @Override
    @SuppressWarnings("unchecked")
    public Collection<CompletionReportVO> retrieveEntitiesByCycle(String cycleId) {
        return entityManager.createNamedQuery("lookupAllEntitiesByCycleId")
                .setParameter("cycleId", cycleId)
                .getResultList();
    }

    @Override
    @SuppressWarnings("unchecked")
    public Collection<CompletionReportVO> retrieveEntitiesByPeriodAndCountry(String periodId, Integer countryId) {
        return entityManager.createNamedQuery("lookupAllEntitiesByPeriodAndCountry")
                .setParameter("periodId", periodId)
                .setParameter("countryId", countryId)
                .getResultList();
    }

    @Override
    @SuppressWarnings("unchecked")
    public Collection<CompletionReportVO> retrieveEntitiesByCycleAndCountry(String cycleId, Integer countryId) {
        return entityManager.createNamedQuery("lookupAllEntitiesByCycleAndCountry")
                .setParameter("cycleId", cycleId)
                .setParameter("countryId", countryId)
                .getResultList();
    }
}
