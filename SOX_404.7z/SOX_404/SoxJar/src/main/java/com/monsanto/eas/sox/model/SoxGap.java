package com.monsanto.eas.sox.model;

import javax.persistence.*;
import java.io.Serializable;

@Table(name = "SOX_GAP", schema = "SARBOX_ET")
@Entity
public class SoxGap implements Serializable{
    @Id
    @SequenceGenerator(name = "soxGapSeq", sequenceName = "SARBOX_ET.SOX_GAP_SEQ")
    @GeneratedValue(generator = "soxGapSeq", strategy = GenerationType.SEQUENCE)
    @javax.persistence.Column(name = "GAP_ID", nullable = false, insertable = true, updatable = true, length = 22, precision = 0)
    private int gapId;

    @javax.persistence.Column(name = "DESCRIPTION", nullable = true, insertable = true, updatable = true, length = 4000, precision = 0)
    @Basic
    private String description;

    @ManyToOne  (cascade = CascadeType.ALL)
    @javax.persistence.JoinColumn(name = "RESPONSE_ID", referencedColumnName = "RESPONSE_ID")
    private SoxResponse soxResponse;

    public int getGapId() {
        return gapId;
    }

    public void setGapId(int gapId) {
        this.gapId = gapId;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }



    public SoxResponse getSoxResponse() {
        return soxResponse;
    }

    public void setSoxResponse(SoxResponse soxResponse) {
        this.soxResponse = soxResponse;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        SoxGap soxGap = (SoxGap) o;

        if (gapId != soxGap.gapId) return false;
//        if (responseId != soxGap.responseId) return false;
        if (description != null ? !description.equals(soxGap.description) : soxGap.description != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = gapId;
        result = 31 * result + (description != null ? description.hashCode() : 0);
//        result = 31 * result + responseId;
        return result;
    }
}
