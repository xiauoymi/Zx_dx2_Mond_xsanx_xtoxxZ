package com.monsanto.eas.sox.util;

public enum PeriodSettingsProperties {

  PREFIX("period.maintenance%"),
  CONTROL_DELINQUENT_DATE("period.maintenance.activity.delinquent.date"),
  CONTROL_NOTIFICATION_DATE("period.maintenance.activity.notification.date"),
  CONTROL_REMINDER_DATE("period.maintenance.activity.reminder.date"),
  SUB_CYCLE_DELINQUENT_DATE("period.maintenance.sub_cycle.delinquent.date"),
  SUB_CYCLE_NOTIFICATION_DATE("period.maintenance.sub_cycle.notification.date"),
  SUB_CYCLE_REMINDER_DATE("period.maintenance.subcycle.reminder.date"),
  CYCLE_DELINQUENT_DATE("period.maintenance.cycle.delinquent.date"),
  CYCLE_NOTIFICATION_DATE("period.maintenance.cycle.notification.date"),
  CYCLE_REMINDER_DATE("period.maintenance.cycle.reminder.date")
  ;
  private String code;

  PeriodSettingsProperties(String code){
    this.code = code;
  }

  public String getCode() {
    return code;
  }

  public void setCode(String code) {
    this.code = code;
  }
}
