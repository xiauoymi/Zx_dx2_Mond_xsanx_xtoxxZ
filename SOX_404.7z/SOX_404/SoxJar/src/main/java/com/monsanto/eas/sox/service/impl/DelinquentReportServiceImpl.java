package com.monsanto.eas.sox.service.impl;

import com.monsanto.PeoplePicker.PersonInfo;
import com.monsanto.eas.sox.dao.DelinquentReportDao;
import com.monsanto.eas.sox.exception.InvalidUserException;
import com.monsanto.eas.sox.model.DelinquentReportVO;
import com.monsanto.eas.sox.service.DelinquentReportService;
import com.monsanto.eas.sox.service.SearchPeopleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.flex.remoting.RemotingDestination;
import org.springframework.flex.remoting.RemotingInclude;
import org.springframework.stereotype.Service;

import java.util.Collection;

@Service
@RemotingDestination(value = "delinquentReportService")
public class DelinquentReportServiceImpl implements DelinquentReportService {

    private DelinquentReportDao delinquentReportDao;
    private SearchPeopleService searchPeopleService;

    @Autowired
    public DelinquentReportServiceImpl(DelinquentReportDao delinquentReportDao, SearchPeopleService searchPeopleService) {
        this.delinquentReportDao = delinquentReportDao;
        this.searchPeopleService = searchPeopleService;
    }

    @RemotingInclude
    public Collection<DelinquentReportVO> getDelinquentReport(String periodId) throws InvalidUserException {
        Collection<DelinquentReportVO> result = delinquentReportDao.lookupDelinquentOwnersByPeriod(periodId);

        fillFirstAndLastName(result);

        return result;
    }

    private void fillFirstAndLastName(Collection<DelinquentReportVO> delinquentReportVOCollection) throws InvalidUserException {
        for (DelinquentReportVO delinquentReportVO : delinquentReportVOCollection) {
            PersonInfo personInfo = searchPeopleService.findPersonByUserId(delinquentReportVO.getUserId());

            delinquentReportVO.setFirstName(personInfo.getFirstName());
            delinquentReportVO.setLastName(personInfo.getLastName());
            delinquentReportVO.setRegion(personInfo.getMailStop());
        }
    }
}
