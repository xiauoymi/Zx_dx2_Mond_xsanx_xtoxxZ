package com.monsanto.eas.sox.dao;

import com.monsanto.eas.sox.model.SoxAdminLog;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: JEESCO
 * Date: 8/02/12
 * Time: 10:43 AM
 */
public interface AdminLogDao extends GenericDao<SoxAdminLog> {
    Collection<SoxAdminLog> lookupLogEntries();

    Collection<SoxAdminLog> lookupLogEntriesByPeriod(String periodId);
}
