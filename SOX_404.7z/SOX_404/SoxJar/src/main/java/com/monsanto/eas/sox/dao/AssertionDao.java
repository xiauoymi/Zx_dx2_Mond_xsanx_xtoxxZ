package com.monsanto.eas.sox.dao;

import com.monsanto.eas.sox.model.Assertion;

public interface AssertionDao extends GenericDao<Assertion>{
    Assertion lookupAssertionByDescription(String description);
}
