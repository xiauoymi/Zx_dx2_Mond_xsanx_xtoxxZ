package com.monsanto.eas.sox.dao;

import com.monsanto.eas.sox.model.SoxCountry;

import java.util.Collection;

public interface CountryDao extends GenericDao<SoxCountry>{
    SoxCountry lookupCountryByDescription(String description);

    Collection<SoxCountry> lookupAllCountries();
}
