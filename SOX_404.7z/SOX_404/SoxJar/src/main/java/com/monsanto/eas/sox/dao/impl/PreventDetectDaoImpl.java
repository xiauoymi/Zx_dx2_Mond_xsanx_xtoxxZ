package com.monsanto.eas.sox.dao.impl;

import com.monsanto.eas.sox.dao.PreventDetectDao;
import com.monsanto.eas.sox.model.PreventDetect;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.util.List;

@Repository
public class PreventDetectDaoImpl extends GenericDaoImpl<PreventDetect> implements PreventDetectDao{
    private static final long serialVersionUID = 1L;

    @PersistenceContext
    private EntityManager entityManager;

    @Override
    public PreventDetect lookupPreventDetectByDescription(String description) {
        PreventDetect preventDetect = null;

        List<PreventDetect> preventDetectList = entityManager.createNamedQuery("lookupPreventDetectByDescription").setParameter("description", description).getResultList();
        if (preventDetectList != null && preventDetectList.size() > 0) {
            preventDetect = preventDetectList.get(0);
        }
        return preventDetect;
    }
}
