package com.monsanto.eas.sox.jaxb.dao;

import com.monsanto.eas.sox.jaxb.UploadResult;
import com.monsanto.eas.sox.model.SoxControlEntity;

public interface UploadResultXmlDao {
    String generateXml(UploadResult uploadResult) throws Exception;

    UploadResult getUploadResultFromCycle(SoxControlEntity cycle);
}
