package com.monsanto.eas.sox.model;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.Collection;

@Table(name = "RESPONSE_TYPE", schema = "SARBOX_ET")
@Entity
@NamedQueries({
        @NamedQuery(name = "lookupResponseTypeByDescription", query = "FROM ResponseType rt WHERE rt.description=:description")
})
public class ResponseType {
    @javax.persistence.Column(name = "RESPONSE_TYPE_ID", nullable = false, insertable = true, updatable = true, length = 22, precision = 0)
    @Id
    private int responseTypeId;

    @javax.persistence.Column(name = "DESCRIPTION", nullable = true, insertable = true, updatable = true, length = 250, precision = 0)
    @Basic
    private String description;

    @OneToMany(mappedBy = "responseType")
    private Collection<SoxResponse> soxResponses = new ArrayList<SoxResponse>();

    public int getResponseTypeId() {
        return responseTypeId;
    }

    public void setResponseTypeId(int responseTypeId) {
        this.responseTypeId = responseTypeId;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Collection<SoxResponse> getSoxResponses() {
        return soxResponses;
    }

    public void setSoxResponses(Collection<SoxResponse> soxResponses) {
        this.soxResponses = soxResponses;
    }

    public void addSoxResponse(SoxResponse soxResponse) {
        if (soxResponse != null) {
            soxResponse.setResponseType(this);
            soxResponses.add(soxResponse);
        }
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        ResponseType that = (ResponseType) o;

        if (responseTypeId != that.responseTypeId) return false;
        if (description != null ? !description.equals(that.description) : that.description != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = responseTypeId;
        result = 31 * result + (description != null ? description.hashCode() : 0);
        return result;
    }
}
