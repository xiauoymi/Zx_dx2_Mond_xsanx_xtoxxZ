package com.monsanto.eas.sox.service;

import com.monsanto.eas.sox.exception.InvalidUserException;
import com.monsanto.eas.sox.model.SoxAdminLog;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: JEESCO
 * Date: 8/02/12
 * Time: 10:55 AM
 */
public interface AdminLogService {
    Collection<SoxAdminLog> lookupLogEntries();
    Collection<SoxAdminLog> lookupLogEntries(String periodId) throws InvalidUserException;
}
