package com.monsanto.eas.sox.service;

import com.monsanto.eas.sox.exception.InvalidUserException;
import com.monsanto.eas.sox.model.GapReportVO;
import com.monsanto.eas.sox.model.SoxGap;
import com.monsanto.eas.sox.model.SoxGapVO;

import java.util.Collection;

public interface GapService {

    void deleteGap(SoxGap soxGap);
    Collection<SoxGapVO> getGapsByEntityAndOwner(String entityId, String userId);
    Collection<GapReportVO> getGapsByPeriod(String periodId) throws InvalidUserException;
}
