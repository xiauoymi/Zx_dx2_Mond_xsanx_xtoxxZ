package com.monsanto.eas.sox.jaxb;

import javax.xml.bind.annotation.*;
import java.util.ArrayList;
import java.util.List;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "activity")
@XmlRootElement(name = "Activities")
public class ActivityValidationList {
    @XmlElement(name = "activity")
    protected List<ActivityValidation> activities;

    public List<ActivityValidation> getActivities() {
        if (activities == null)
        {
            activities = new ArrayList<ActivityValidation>();
        }
        return activities;
    }

    public void setActivities(List<ActivityValidation> activities) {
        this.activities = activities;
    }
}
