package com.monsanto.eas.sox.model;

public class SoxGapVO {
    private String control;
    private String owner;
    private String description;

    public SoxGapVO() {
    }

    public SoxGapVO(SoxGap currentGap) {
        setDescription(currentGap.getDescription());

        try {
            setControl(currentGap.getSoxResponse().getSoxControlEntityOwner().getSoxControlEntity().getControlEntityId());
        }
        catch (NullPointerException npe) {
        }

        try {
            setOwner(currentGap.getSoxResponse().getSoxControlEntityOwner().getSoxOwner().getUserId());
        }
        catch (NullPointerException npe) {
        }
    }

    public String getControl() {
        return control;
    }

    public void setControl(String control) {
        this.control = control;
    }

    public String getOwner() {
        return owner;
    }

    public void setOwner(String owner) {
        this.owner = owner;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}
