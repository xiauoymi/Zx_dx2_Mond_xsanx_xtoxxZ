package com.monsanto.eas.sox.service.impl;

import com.google.common.base.Joiner;
import com.monsanto.PeoplePicker.PersonInfo;
import com.monsanto.eas.sox.dao.*;
import com.monsanto.eas.sox.exception.InvalidUserException;
import com.monsanto.eas.sox.model.*;
import com.monsanto.eas.sox.service.ControlEntityRelationShipService;
import com.monsanto.eas.sox.service.ControlEntityService;
import com.monsanto.eas.sox.service.SearchPeopleService;
import com.monsanto.eas.sox.util.ControlEntityProgress;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.flex.remoting.RemotingDestination;
import org.springframework.flex.remoting.RemotingInclude;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
@RemotingDestination(value = "controlEntityService")
public class ControlEntityServiceImpl implements ControlEntityService {

    private final static String CYCLE_TYPE = "C";
    private final static String SUB_CYCLE_TYPE = "SC";
    private final static String ACTIVITY_TYPE = "ACT";

    @Autowired
    private ControlEntityDao controlEntityDao;

    @Autowired
    private ControlEntityOwnerDao controlEntityOwnerDao;

    @Autowired
    private JdbcControlEntityDao jdbcControlEntityDao;

    @Autowired
    private GapDao gapDao;

    @Autowired
    private ResponseDao responseDao;

    @Autowired
    private SearchPeopleService searchPeopleService;

    @Autowired
    private ControlEntityRelationShipService controlEntityRelationshipService;

    private Joiner joiner = Joiner.on(',').skipNulls();

    @RemotingInclude
    public String deleteSoxControlEntity(String cycleId) {
        String results = cycleId;

        try {
            jdbcControlEntityDao.deleteSoxControlEntity(cycleId);
        } catch (Exception e) {
            results = cycleId + "|" + e.getMessage();
        }

        return results;
    }

    @Override
    public String deleteCtrlEntityDependencies(String cycleId) {
        String results = cycleId;

        try {
            jdbcControlEntityDao.deleteCtrlEntityDependencies(cycleId);
        } catch (Exception e) {
            results = cycleId + "|" + e.getMessage();
        }

        return results;
    }

    @Override
    public SoxControlEntity lookupSoxControlEntityByControlId(String controlId) {
        return controlEntityDao.lookupSoxControlEntityByControlId(controlId);
    }

    @RemotingInclude
    public SoxControlEntity saveOrUpdate(SoxControlEntity soxControlEntity, List<SoxControlEntityRelationship> controlEntityRelationships) {
//        controlEntityDao.save(soxControlEntity);
        if(soxControlEntity.getControlEntityId() != null && !soxControlEntity.getControlEntityId().equals("")){
            controlEntityDao.merge(soxControlEntity);
        }

        for (SoxControlEntityRelationship ctrlRel : controlEntityRelationships) {
            controlEntityRelationshipService.saveOrUpdate(ctrlRel);
        }
        return soxControlEntity;
    }

    @Override
    public SoxControlEntity saveOrUpdate(SoxControlEntity soxControlEntity) {
        controlEntityDao.merge(soxControlEntity);
        return soxControlEntity;
    }

    @RemotingInclude
    public Collection<SoxControlEntity> getAllCycles() {
        Collection<SoxControlEntity> soxControlEntities = controlEntityDao.lookupAllCycles();
        Iterator<SoxControlEntity> iterator = soxControlEntities.iterator();
        while (iterator.hasNext()) {
            SoxControlEntity soxControlEntity = iterator.next();
            setChildEntitiesToNull(soxControlEntity);

        }
        return soxControlEntities;
    }

    private void setChildEntitiesToNull(SoxControlEntity soxControlEntity) {
        soxControlEntity.setChildControlEntities(null);
        soxControlEntity.setParentControlEntity(null);
        soxControlEntity.setSoxCtrlActivityEntities(null);
        soxControlEntity.setSoxControlEntityOwners(null);
        soxControlEntity.setCountries(null);
    }

    @RemotingInclude
    public Collection<DependentOverdueEntityVO> getChildsForAnEntity(String controlEntityId) throws InvalidUserException {
        Collection<DependentOverdueEntityVO> result = controlEntityDao.lookupChildsForAnEntity(controlEntityId);

        for (DependentOverdueEntityVO dependentOverdueEntityVO : result) {
            PersonInfo personInfo = searchPeopleService.findPersonByUserId(dependentOverdueEntityVO.getUserId());

            dependentOverdueEntityVO.setFirstName(personInfo.getFirstName());
            dependentOverdueEntityVO.setLastName(personInfo.getLastName());
        }

        return result;
    }

    @RemotingInclude
    public Collection<SoxControlEntity> getCyclesByOwner(String userId) {
        Collection<SoxControlEntity> result = null;

        Map<String, SoxControlEntity> allCycles = new TreeMap<String, SoxControlEntity>();

        // get the cycles that belong to the owner
        Collection<SoxControlEntity> cycles = controlEntityDao.lookupCyclesOwnedByUser(userId);
        for (SoxControlEntity t : cycles) {
            t.setEntityTypeDelinquentLink(ControlEntityServiceImpl.CYCLE_TYPE);
            t.setEnabled(true);
            allCycles.put(t.getControlEntityId(), t);
//            setChildEntitiesToNull(t);
        }

        // get the subcycles that belong to the owner
        Collection<SoxControlEntity> subCycles = controlEntityDao.lookupSubCyclesOwnedByUser(userId);
        for (SoxControlEntity t : subCycles) {
            SoxControlEntity parent = t.getParentControlEntity();

            if (parent != null && parent.getControlEntityId() != null) {

                if (!allCycles.containsKey(parent.getControlEntityId())) {
                    parent.setEnabled(false);
                    parent.setEntityTypeDelinquentLink(ControlEntityServiceImpl.CYCLE_TYPE);
//                    setChildEntitiesToNull(parent);
                    allCycles.put(parent.getControlEntityId(), parent);
                }
            }
        }

        // get the activities that belong to the owner
        Collection<SoxControlEntity> activities = controlEntityDao.lookupActivitiesOwnedByUser(userId);
        for (SoxControlEntity t : activities) {
            SoxControlEntity parent = t.getParentControlEntity();
            if (parent != null && parent.getParentControlEntity() != null) {
                SoxControlEntity grandParent = parent.getParentControlEntity();

                if (!allCycles.containsKey(grandParent.getControlEntityId())) {
                    grandParent.setEnabled(false);
                    grandParent.setEntityTypeDelinquentLink(ControlEntityServiceImpl.CYCLE_TYPE);
                    allCycles.put(grandParent.getControlEntityId(), grandParent);
                }
            }
        }

        result = allCycles.values();

        for (SoxControlEntity currentCycle : result) {
            setControlEntityProgress(currentCycle, userId);
            setEnableLink(currentCycle, ControlEntityServiceImpl.CYCLE_TYPE);
            setControlEntityGapStatus(currentCycle, userId);
            setChildEntitiesToNull(currentCycle);
        }
        return result;
    } // end of getCyclesByOwner method


    @RemotingInclude
    public Collection<SoxControlEntity> getEntitiesNotCertifiedForUser(String userId) {
        return controlEntityDao.lookupEntitiesNotCertifiedForUser(userId);
    }

    @Override
    public Collection<SoxControlEntityOwner> getControlEntityOwnerByControlEntityId(String entityId) {
        return controlEntityOwnerDao.lookupControlEntityOwnerByControlEntityId(entityId);
    }

    @Override
    public String getActivityOwners(SoxControlEntity activity) {
        Set<String> owners = new HashSet<String>();

        for (SoxControlEntityOwner soxControlEntityOwner : activity.getSoxControlEntityOwners()) {
            if (!soxControlEntityOwner.getSoxOwner().isNone())
                owners.add(soxControlEntityOwner.getSoxOwner().getUserId());
        }

        return joiner.join(owners);
    }

    public String getActivityOwners(Collection<SoxControlEntityOwner> controlEntityOwnerCollection) {
        Set<String> owners = new HashSet<String>();

        for (SoxControlEntityOwner soxControlEntityOwner : controlEntityOwnerCollection) {
            if (!soxControlEntityOwner.getSoxOwner().isNone())
                owners.add(soxControlEntityOwner.getSoxOwner().getUserId());
        }

        return joiner.join(owners);
    }

    @Override
    public String getCountries(SoxControlEntity activity) {
        Set<String> countries = new HashSet<String>();

        for (SoxCountry soxCountry : activity.getCountries()) {
            countries.add(soxCountry.getCountryDescription());
        }

        return joiner.join(countries);
    }

    @Override
    public String getSoxSystems(SoxCtrlActivityEntity ctrlActivityEntity) {
        if (ctrlActivityEntity.getSoxSystems().isEmpty()) {
            return "N/A";
        }
        return ctrlActivityEntity.getSoxSystemsAsString(",");
    }

    @Override
    public Collection<DependentOverdueEntityVO> lookupCertifiedOwnersForAnEntityWithoutDateRestriction(String controlEntityId) {
        return controlEntityDao.lookupCertifiedOwnersForAnEntityWithoutDateRestriction(controlEntityId);
    }

    public void setEnableLink(SoxControlEntity entity, String entityType) {
        boolean enable = true;
        if (entity.isEnabled()) {
            Collection<SoxControlEntity> incompleteSubCycles = controlEntityDao.getIncompleteChildren(entity.getControlEntityId());
            if (incompleteSubCycles.size() > 0) {
                if (entityType.equals(ControlEntityServiceImpl.CYCLE_TYPE)) {
                    for (SoxControlEntity subcycle : incompleteSubCycles) {
                        for (SoxControlEntityOwner owner : subcycle.getSoxControlEntityOwners()) {
                            enable = enable && owner.getSoxOwner().getUserId().equalsIgnoreCase("NONE");
                        }
                    }
                } else {
                    enable = false;
                }
            }

            if (enable) {
                for (SoxControlEntity currentSubCycle : entity.getChildControlEntities()) {
                    Collection<SoxControlEntity> incompleteActivities = controlEntityDao.getIncompleteChildren(currentSubCycle.getControlEntityId());
                    if (incompleteActivities.size() > 0) {
                        enable = false;
                        break;
                    }
                }
            }

            entity.setEnabled(enable);
        }
    }

    @RemotingInclude
    public Collection<SoxControlEntity> getSubCyclesByOwnerAndCycle(String userId, String cycleId) {
        Collection<SoxControlEntity> result = null;
        Map<String, SoxControlEntity> allSubCycles = new TreeMap<String, SoxControlEntity>();

        // get the subcycles that belong to the owner
        Collection<SoxControlEntity> subCycles = controlEntityDao.lookupSubCyclesByUserAndCycle(userId, cycleId);
        for (SoxControlEntity t : subCycles) {
            t.setEntityTypeDelinquentLink(ControlEntityServiceImpl.SUB_CYCLE_TYPE);
            t.setEnabled(true);
            allSubCycles.put(t.getControlEntityId(), t);
        }

        // get the activities that belong to the owner
        Collection<SoxControlEntity> activities = controlEntityDao.lookupActivitiesByUserAndCycle(userId, cycleId);
        for (SoxControlEntity t : activities) {
            SoxControlEntity parent = t.getParentControlEntity();
            if (parent != null && parent.getControlEntityId() != null) {
                if (!allSubCycles.containsKey(parent.getControlEntityId())) {
                    parent.setEnabled(false);
                    parent.setEntityTypeDelinquentLink(ControlEntityServiceImpl.SUB_CYCLE_TYPE);
                    allSubCycles.put(parent.getControlEntityId(), parent);
                }
            }
        }

        result = allSubCycles.values();

        for (SoxControlEntity currentSubCycle : result) {
            setControlEntityProgress(currentSubCycle, userId);
            setEnableLink(currentSubCycle, ControlEntityServiceImpl.SUB_CYCLE_TYPE);
            setControlEntityGapStatus(currentSubCycle, userId);
            setChildEntitiesToNull(currentSubCycle);
        }
        return result;
    }

    @RemotingInclude
    public Collection<SoxControlEntity> getActivitiesByOwnerAndSubCycle(String userId, String subCycleId) {
        Collection<SoxControlEntity> activities = controlEntityDao.lookupActivitiesByUserAndSubCycle(userId, subCycleId);

        for (SoxControlEntity currentActivity : activities) {
            currentActivity.setEnabled(true);
            currentActivity.setEntityTypeDelinquentLink(ControlEntityServiceImpl.ACTIVITY_TYPE);
            setControlEntityProgress(currentActivity, userId);
            setEnableLink(currentActivity, ControlEntityServiceImpl.ACTIVITY_TYPE);
            setControlEntityGapStatus(currentActivity, userId);
            setChildEntitiesToNull(currentActivity);
        }

        return activities;
    }

    @Override
    public Collection<SoxControlEntity> getActivities(String periodId, String countryId, String cycleId) {
        Collection<SoxControlEntity> activities = null;

        if (!countryId.equals("") && !cycleId.equals("")) {
            activities = getActivitiesByCountryAndCycle(periodId, countryId, cycleId);
        } else if (!countryId.equals("")) {
            activities = getActivitiesByCountry(periodId, countryId);
        } else if (!cycleId.equals("")) {
            activities = getActivitiesByCycle(periodId, cycleId);
        }

        return activities;
    }

    @RemotingInclude
    public Collection<SoxControlEntity> getCyclesByPeriod(String periodId) {
        Collection<SoxControlEntity> collection = controlEntityDao.lookupCyclesByPeriod(periodId);
        Iterator<SoxControlEntity> iterator = collection.iterator();
        while (iterator.hasNext()) {
            SoxControlEntity tmpControlEntity = iterator.next();
            setChildEntitiesToNull(tmpControlEntity);
        }
        return collection;
    }

    /*
    public Collection<SoxControlEntity> getMissingCyclesForBeingCopiedFromPreviousPeriod(String currentPeriodId) {
        Collection<SoxControlEntity> collection = controlEntityDao.getMissingCyclesForBeingCopiedFromPreviousPeriod(currentPeriodId);
        Iterator<SoxControlEntity> iterator = collection.iterator();
        while (iterator.hasNext()) {
            SoxControlEntity tmpControlEntity = iterator.next();
            setChildEntitiesToNull(tmpControlEntity);
        }
        return collection;
    }
    */


    @RemotingInclude
    public Collection<SoxControlEntity> getActivitiesByCycle(String periodId, String cycleId) {
        Collection<SoxControlEntity> activities = controlEntityDao.lookupActivitiesByCycle(periodId, cycleId);
        return activities;
    }

    @RemotingInclude
    public Collection<SoxControlEntity> getActivitiesByCountry(String periodId, String countryId) {
        Collection<SoxControlEntity> activities = controlEntityDao.lookupActivitiesByCountry(periodId, countryId);
        return activities;
    }

    @RemotingInclude
    public Collection<SoxControlEntity> getActivitiesByCountryAndCycle(String periodId, String countryId, String cycleId) {
        Collection<SoxControlEntity> activities = controlEntityDao.lookupActivitiesByCountryAndCycle(periodId, countryId, cycleId);
        return activities;
    }

    @Override
    @RemotingInclude
    public Collection<RelatedActivityVO> getActivitiesDifferentFromSelectedCycle(String controlEntityId) {
        Collection<RelatedActivityVO> activities = controlEntityDao.getActivitiesDifferentFromSelectedCycle(controlEntityId);
        return activities;
    }

    private void setControlEntityGapStatus(SoxControlEntity entity, String userId) {
        Collection<SoxGap> result = new ArrayList<SoxGap>();
        String entityId = entity.getControlEntityId();

        SoxControlEntityOwner controlEntityOwner = controlEntityOwnerDao.lookupControlEntityOwnerByEntityAndOwner(entityId, userId);

        if (controlEntityOwner != null) {
            SoxControlEntity controlEntity = controlEntityOwner.getSoxControlEntity();

            if (controlEntity != null) {
                if (controlEntity.getParentControlEntity() == null) {
                    // cycle
                    for (SoxControlEntity subCycle : controlEntity.getChildControlEntities()) {
                        for (SoxControlEntity activity : subCycle.getChildControlEntities()) {
                            result.addAll(gapDao.lookupGapsByEntity(activity.getControlEntityId()));
                        }
                        result.addAll(gapDao.lookupGapsByEntity(subCycle.getControlEntityId()));
                    }
                    result.addAll(gapDao.lookupGapsByEntityAndOwner(controlEntity.getControlEntityId(), userId));
                } else if (controlEntity.getParentControlEntity() != null && controlEntity.getParentControlEntity().getParentControlEntity() == null) {
                    // subCycle
                    for (SoxControlEntity activity : controlEntity.getChildControlEntities()) {
                        result.addAll(gapDao.lookupGapsByEntity(activity.getControlEntityId()));
                    }
                    result.addAll(gapDao.lookupGapsByEntityAndOwner(controlEntity.getControlEntityId(), userId));
                } else if (controlEntity.getParentControlEntity() != null && controlEntity.getParentControlEntity().getParentControlEntity() != null
                        && controlEntity.getParentControlEntity().getParentControlEntity().getParentControlEntity() == null) {
                    // activity
                    result.addAll(gapDao.lookupGapsByEntityAndOwner(entityId, userId));
                }
            }
        }

        if (result.size() > 0) {
            entity.setGaps(true);

        }


//        for (SoxControlEntity currentEntity : entity.getChildControlEntities()) {
//            for (SoxControlEntity currentSubEntity : currentEntity.getChildControlEntities()) {
//                calculateControlEntityGapStatus(currentSubEntity, userId);
//            }
//            calculateControlEntityGapStatus(currentEntity, userId);
//        }
//        calculateControlEntityGapStatus(entity, userId);
    }

    /*
    private void calculateControlEntityGapStatus(SoxControlEntity entity, String userId) {
        if (entity.getChildControlEntities().size() > 0) {
            if (childrenHaveGaps(entity.getChildControlEntities())) {
                entity.setGaps(true);
            } else {
                for (SoxControlEntityOwner currentSoxControlEntityOwner : entity.getSoxControlEntityOwners()) {
                    if (currentSoxControlEntityOwner.getSoxOwner() != null && currentSoxControlEntityOwner.getSoxOwner().getUserId().equalsIgnoreCase(userId)) {
                        for (SoxResponse currentSoxResponse : currentSoxControlEntityOwner.getSoxResponses()) {
                            if (currentSoxResponse.getSoxGaps() != null && currentSoxResponse.getSoxGaps().size() > 0) {
                                entity.setGaps(true);
                                break;
                            }
                        }
                    }
                }
            }
        } else {
            for (SoxControlEntityOwner currentSoxControlEntityOwner : entity.getSoxControlEntityOwners()) {
                if (currentSoxControlEntityOwner.getSoxOwner() != null && currentSoxControlEntityOwner.getSoxOwner().getUserId().equalsIgnoreCase(userId)) {
                    for (SoxResponse currentSoxResponse : currentSoxControlEntityOwner.getSoxResponses()) {
                        if (currentSoxResponse.getSoxGaps() != null && currentSoxResponse.getSoxGaps().size() > 0) {
                            entity.setGaps(true);
                            break;
                        }
                    }
                }
            }
        }
    }


    private boolean childrenHaveGaps(Collection<SoxControlEntity> entities) {
        boolean hasGaps = false;
        for (SoxControlEntity currentEntity : entities) {
            if (currentEntity.isGaps())
                hasGaps = true;
        }
        return hasGaps;
    }
    */

    private void setControlEntityProgress(SoxControlEntity entity, String userId) {
        Date today = new Date();

        Date dueDate = entity.getEndDate();

        if (dueDate == null) {
            entity.setControlEntityProgress(ControlEntityProgress.ENTITY_NOT_OPENED);
            entity.setEnabled(false);
            return;
        } else {
            // get controlEntityOwner
            SoxControlEntityOwner ceo = controlEntityOwnerDao.lookupControlEntityOwnerByEntityAndOwner(entity.getControlEntityId(), userId);
            if (ceo != null) {
                Collection<SoxResponse> responses = ceo.getSoxResponses();
                boolean completed = true;
                for (SoxResponse currentResponse : responses) {
                    if (currentResponse.getResponseType() == null)
                        completed = false;
                }
                if (completed) {
                    entity.setControlEntityProgress(ControlEntityProgress.COMPLETE);
                } else {
                    long diff = daysBetweenDates(dueDate, today);

                    if (diff > 5) {
                        entity.setControlEntityProgress(ControlEntityProgress.IN_PROGRESS_MORE_THAN_FIVE_DAYS_REMAINING);
                    } else if (diff > 2 && diff <= 5) {
                        entity.setControlEntityProgress(ControlEntityProgress.IN_PROGRESS_FIVE_DAYS_REMAINING);
                    } else if (diff <= 2) {
                        entity.setControlEntityProgress(ControlEntityProgress.IN_PROGRESS_TWO_DAYS_REMAINING);
                    }
                }
            } else {
                entity.setControlEntityProgress(ControlEntityProgress.ENTITY_NOT_OPENED);
            }


        }
    }

    private long daysBetweenDates(Date dueDate, Date today) {
        long diff = dueDate.getTime() - today.getTime();
        return (diff / (1000 * 60 * 60 * 24));
    }

    public void uncertifyEntity(String controlEntityId, String parentId) {
        Date currentDate = getCurrentDate();
        Collection<DependentOverdueEntityVO> otherChilds = controlEntityDao.lookupCertifiedOwnersForAnEntity(parentId, currentDate);
        for (DependentOverdueEntityVO dep : otherChilds) {
            SoxControlEntityOwner sown = controlEntityOwnerDao.lookupControlEntityOwnerByEntityAndOwner(dep.getControlEntityId(), dep.getUserId());

            for (SoxResponse currResp : sown.getSoxResponses()) {
                currResp.setResponseType(null);
                responseDao.save(currResp);
            }
        }
    }

    public void uncertifyEntity(Collection<DependentOverdueEntityVO> otherChilds) {
        for (DependentOverdueEntityVO dep : otherChilds) {
            SoxControlEntityOwner sown = controlEntityOwnerDao.lookupControlEntityOwnerByEntityAndOwner(dep.getControlEntityId(), dep.getUserId());

            for (SoxResponse currResp : sown.getSoxResponses()) {
                currResp.setResponseType(null);
                responseDao.save(currResp);
            }
        }
    }

    private Date getCurrentDate() {
        Calendar calendar = new GregorianCalendar();
        calendar.set(Calendar.HOUR_OF_DAY, 0);
        calendar.set(Calendar.MINUTE, 0);
        calendar.set(Calendar.SECOND, 0);
        calendar.set(Calendar.MILLISECOND, 0);

        return calendar.getTime();
    }

} // end of class
