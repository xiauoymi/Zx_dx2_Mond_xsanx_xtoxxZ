package com.monsanto.eas.sox.service;

import com.monsanto.eas.sox.model.ResponseType;

public interface ResponseTypeService {
    ResponseType getResponseTypeByDescription(String description);
}
