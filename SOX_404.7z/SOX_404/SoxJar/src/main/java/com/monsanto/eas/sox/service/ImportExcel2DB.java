package com.monsanto.eas.sox.service;


import com.google.common.base.Splitter;
import com.google.common.collect.Lists;
import com.monsanto.PeoplePicker.PersonInfo;
import com.monsanto.eas.sox.exception.InvalidUserException;
import com.monsanto.eas.sox.exception.TemplateException;
import com.monsanto.eas.sox.model.*;
import com.monsanto.eas.sox.util.DateToStringHelper;
import com.monsanto.eas.sox.util.PeriodSettingsProperties;
import com.monsanto.eas.sox.util.SoxConstants;
import org.apache.log4j.Logger;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.flex.remoting.RemotingDestination;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.io.InputStream;
import java.util.*;

@Service
@RemotingDestination(value = "importExcel2DB")
public class ImportExcel2DB {
    private static Logger logger = Logger.getLogger(ImportExcel2DB.class.getName());

    private static final int TOTAL_COLS = 20;

    @Autowired
    private OwnerService ownerService;
    @Autowired

    private PeriodService periodService;

    @Autowired
    private AssertionService assertionService;

    @Autowired
    private TypeOfControlService typeOfControlService;

    @Autowired
    private FrequencyService frequencyService;

    @Autowired
    private SoxSystemService soxSystemService;

    @Autowired
    private PreventDetectService preventDetectService;

    @Autowired
    private FraudService fraudService;

    @Autowired
    private KeyService keyService;

    @Autowired
    private CountryService countryService;

    @Autowired
    private ConfigService configService;

    @Autowired
    private ControlEntityService controlEntityService;

    @Autowired
    private ControlEntityRelationShipService controlEntityRelationShipService;

    @Autowired
    private QuestionService questionService;

    @Autowired
    private SearchPeopleService searchPeopleService;

    private final DateToStringHelper dateToStringHelper = new DateToStringHelper();

    private Splitter splitter = Splitter.on(',').omitEmptyStrings().trimResults();

    public SoxControlEntity importFile(String fileName, InputStream inputStream) throws Exception {
        Map<String, String> dictionary = configService.getDictionary(PeriodSettingsProperties.PREFIX.getCode());
        // Validate the file extension
        Workbook wb = makeWorkbook(fileName, inputStream);

        logger.debug("importFile started for file: " + fileName);

        // get the first sheet
        Sheet sheet = wb.getSheetAt(0);

        int totalRows = sheet.getLastRowNum();

        SoxControlEntity cycle = new SoxControlEntity();
        cycle.setStartDate(dateToStringHelper.stringToDate(dictionary.get(PeriodSettingsProperties.CYCLE_NOTIFICATION_DATE.getCode())));
        cycle.setReminderDate(dateToStringHelper.stringToDate(dictionary.get(PeriodSettingsProperties.CYCLE_REMINDER_DATE.getCode())));
        cycle.setEndDate(dateToStringHelper.stringToDate(dictionary.get(PeriodSettingsProperties.CYCLE_DELINQUENT_DATE.getCode())));
        SoxControlEntity subCycle = null;
        SoxControlEntity activity = null;
        SoxCtrlActivityEntity controlActivityEntity = null;

        List<SoxControlEntityRelationship> controlEntityRelationships = new ArrayList<SoxControlEntityRelationship>();
        // get the current period
        SoxPeriod period = periodService.getCurrentPeriod();

        String cycleId = null;
        String subCycleId = null;
        String activityId = null;
        String currentCycleId = null;

        boolean skipRow = false;
        boolean relatedRow = false;

        for (int rowNum = 0; rowNum < totalRows + 1; rowNum++) {
            Set<SoxCountry> countries = new HashSet<SoxCountry>();

            Row row = sheet.getRow(rowNum);

            controlActivityEntity = new SoxCtrlActivityEntity();

            if (row != null) {
                for (int colNum = 0; colNum < TOTAL_COLS; colNum++) {
                    Cell cell = row.getCell(colNum);
                    //logger.debug("[" + rowNum + "]" + "[" + colNum + "] = " + (cell != null ? cell.toString() : "BLANK"));

                    // A3 - cycle description
                    if (rowNum == 2 && colNum == 0) {
                        cycle.setDescription(cell.toString());
                        // add the period to the cycle
                        cycle.setSoxPeriod(period);
                    }
                    // A4 - cycle owner
                    if (rowNum == 3 && colNum == 0) {
                        setEntityOwners(cycle, cell, SoxConstants.ENTITY_TYPE_CYCLE);
                    }

                    if (rowNum >= 8) {

                        skipRow = false;
                        relatedRow = false;
                        // A10 - control id
                        if (colNum == ExcelTemplateDescriptor.COL_CONTROL_ID) {
                            ControlId controlId = ControlIdBuilder.build(period, cell.toString());

                            if (controlId.equals(ControlId.NULL_CONTROL_ID)) {
                                skipRow = true;
                            } else {
                                cycleId = controlId.getCycleId();
                                subCycleId = controlId.getSubCycleId();
                                activityId = controlId.getActivityId();
                            }
                        }

                        if (currentCycleId == null) {
                            currentCycleId = cycleId;
                            skipRow = false;
                        } else if (!currentCycleId.equals(cycleId)) {
                            skipRow = true;
                            if(cycleId != null) {
                                relatedRow = true;
                            }
                        }

                        if (!skipRow) {
                            cycle.setControlEntityId(cycleId);

                            // B10 - Countries
                            if (colNum == ExcelTemplateDescriptor.COL_COUNTRY) {
                                countries.addAll(parseCountries(cell));
                            }

                            // D10 - subCycle description
                            if (colNum == ExcelTemplateDescriptor.COL_SUBCYCLE) {
                                // get the subcycle from the cycle or create one
                                subCycle = getChildEntity(cycle, subCycleId);

                                if (subCycle == null) {
                                    subCycle = new SoxControlEntity();
                                    subCycle.setDescription(cell.toString());
                                    subCycle.setControlEntityId(subCycleId);
                                    subCycle.setSoxPeriod(period);
                                    subCycle.setStartDate(dateToStringHelper.stringToDate(dictionary.get(PeriodSettingsProperties.SUB_CYCLE_NOTIFICATION_DATE.getCode())));
                                    subCycle.setReminderDate(dateToStringHelper.stringToDate(dictionary.get(PeriodSettingsProperties.SUB_CYCLE_REMINDER_DATE.getCode())));
                                    subCycle.setEndDate(dateToStringHelper.stringToDate(dictionary.get(PeriodSettingsProperties.SUB_CYCLE_DELINQUENT_DATE.getCode())));
                                    cycle.addChildEntity(subCycle);
                                }
                            }

                            // E10 - subCycle owners
                            if (colNum == ExcelTemplateDescriptor.COL_SUBCYCLE_OWNER) {
                                setEntityOwners(subCycle, cell, SoxConstants.ENTITY_TYPE_SUBCYCLE);
                            }

                            // F10 - Assertions
                            if (colNum >= ExcelTemplateDescriptor.COL_OCURRENCE && colNum <= ExcelTemplateDescriptor.COL_PRESENTATION) {
                                setAssertion(controlActivityEntity, cell);
                            }

                            // K10 - Risk
                            if (colNum == ExcelTemplateDescriptor.COL_RISK) {
                                if (!isEmptyCell(cell)) {
                                    controlActivityEntity.setRisk(cell.toString());
                                }
                            }

                            // L10 - activity description
                            if (colNum == ExcelTemplateDescriptor.COL_CONTROL) {
                                // get the activity from the subcycle or create one
                                activity = getChildEntity(subCycle, activityId);

                                if (activity == null) {
                                    activity = new SoxControlEntity();
                                    activity.setDescription(cell.toString());
                                    activity.setControlEntityId(activityId);
                                    activity.addSoxCtrlActivityEntity(controlActivityEntity);
                                    activity.setSoxPeriod(period);
                                    activity.addCountries(countries);
                                    activity.setStartDate(dateToStringHelper.stringToDate(dictionary.get(PeriodSettingsProperties.CONTROL_NOTIFICATION_DATE.getCode())));
                                    activity.setReminderDate(dateToStringHelper.stringToDate(dictionary.get(PeriodSettingsProperties.CONTROL_REMINDER_DATE.getCode())));
                                    activity.setEndDate(dateToStringHelper.stringToDate(dictionary.get(PeriodSettingsProperties.CONTROL_DELINQUENT_DATE.getCode())));

                                    subCycle.addChildEntity(activity);
                                }
                            }

                            // M10 - activity owners
                            if (colNum == ExcelTemplateDescriptor.COL_CONTROL_OWNER) {
                                setEntityOwners(activity, cell, SoxConstants.ENTITY_TYPE_ACTIVITY);
                            }

                            // O10 - Type of control
                            if (colNum == ExcelTemplateDescriptor.COL_CONTROL_TYPE) {
                                if (!isEmptyCell(cell)) {
                                    TypeOfControl typeOfControl = typeOfControlService.getTypeOfControlByDescription(cell.toString());
                                    if(typeOfControl == null) {
                                       throw new TemplateException("Template error, the type of control is not correct on activity "+activityId);
                                    } else {
                                        controlActivityEntity.setTypeOfControl(typeOfControl);
                                    }
                                }
                            }

                            // P10 - Frequency
                            if (colNum == ExcelTemplateDescriptor.COL_FREQUENCY) {
                                if (!isEmptyCell(cell)) {
                                    Frequency frequency = frequencyService.getFrequencyByDescription(cell.toString());
                                    if(frequency == null) {
                                       throw new TemplateException("Template error, the frequency is not correct on activity "+activityId);
                                    } else {
                                        controlActivityEntity.setFrequency(frequency);
                                    }
                                }
                            }

                            // Q10 - System
                            if (colNum == ExcelTemplateDescriptor.COL_SYSTEM) {
                                if (!isEmptyCell(cell)) {
                                    Set<SoxSystem> systems = parseSystems(cell);
                                    if(systems!= null) {
                                        controlActivityEntity.addSoxSystems(systems);
                                    }
                                }
                            }

                            // R10 - Prevent Detect
                            if (colNum == ExcelTemplateDescriptor.COL_PREVENT) {
                                if (!isEmptyCell(cell)) {
                                    PreventDetect preventDetect = preventDetectService.getPreventDetectByDescription(cell.toString());
                                    if(preventDetect!= null) {
                                        controlActivityEntity.setPreventDetect(preventDetect);
                                    } else {
                                        throw new TemplateException("Template error, the Prevent/detect is not correct on activity "+activityId);
                                    }
                                }
                            }

                            // S10 - Fraud
                            if (colNum == ExcelTemplateDescriptor.COL_FRAUD) {
                                if (!isEmptyCell(cell)) {
                                    Fraud fraud = fraudService.getFraudByDescription(cell.toString());
                                    if(fraud == null) {
                                       throw new TemplateException("Template error, the fraud is not correct on activity "+activityId);
                                    } else {
                                        controlActivityEntity.setFraud(fraud);
                                    }
                                }
                            }

                            // T10 - Key
                            if (colNum == ExcelTemplateDescriptor.COL_KEY) {
                                if (!isEmptyCell(cell)) {
                                    Key key = keyService.getKeyByDescription(cell.toString());
                                    if(key == null) {
                                       throw new TemplateException("Template error, the key is not correct on activity "+activityId);
                                    } else {
                                        controlActivityEntity.setKey(key);
                                    }
                                }
                            }
                        } else if(relatedRow){
                            /* Related activities row; add to the new table */
                            SoxControlEntityRelationship soxControlEntityRelationship = new SoxControlEntityRelationship();
                            soxControlEntityRelationship.setControlEntityId(currentCycleId);
                            soxControlEntityRelationship.setRelatedControlActivityId(activityId);
                            soxControlEntityRelationship.setRisk(row.getCell(ExcelTemplateDescriptor.COL_RISK).getStringCellValue());
                            controlEntityRelationships.add(soxControlEntityRelationship);
                            break;
                        } else {
                            break;
                        }

                    }
                }
            }
            if (skipRow && !relatedRow) {
                relatedRow = false;
                break;
            }

        } // end of for - rows

        logger.debug("CYCLE: " + cycle);

        return controlEntityService.saveOrUpdate(cycle, controlEntityRelationships);

    }

    private Workbook makeWorkbook(String fileName, InputStream inputStream) throws IOException {
        if (fileName.endsWith(".xls")) {
            return new HSSFWorkbook(inputStream);
        } else if (fileName.endsWith(".xlsx")) {
            return new XSSFWorkbook(inputStream);
        }

        return null;
    }

    private void setAssertion(SoxCtrlActivityEntity activityEntity, Cell cell) {
        if (cell != null && cell.toString() != null && !cell.toString().equals("")) {
            Assertion assertion = null;

            switch (cell.getColumnIndex()) {
                case ExcelTemplateDescriptor.COL_OCURRENCE:
                    assertion = assertionService.getAssertionByDescription(SoxConstants.ASSERTION_EXISTENCE_OR_OCCURRENCE);
                    break;
                case ExcelTemplateDescriptor.COL_COMPLETNESS:
                    assertion = assertionService.getAssertionByDescription(SoxConstants.ASSERTION_COMPLETENESS);
                    break;
                case ExcelTemplateDescriptor.COL_VALUATION:
                    assertion = assertionService.getAssertionByDescription(SoxConstants.ASSERTION_VALUATION_AND_ALLOCATION);
                    break;
                case ExcelTemplateDescriptor.COL_RIGHT:
                    assertion = assertionService.getAssertionByDescription(SoxConstants.ASSERTION_RIGHT_AND_OBLIGATION);
                    break;
                case ExcelTemplateDescriptor.COL_PRESENTATION:
                    assertion = assertionService.getAssertionByDescription(SoxConstants.ASSERTION_PRESENTATION_AND_DISCLOSURE);
                    break;
            }

            if (assertion != null) {
                SoxCtrlActivityAssertion soxCtrlActivityAssertion = new SoxCtrlActivityAssertion();
                soxCtrlActivityAssertion.setAssertion(assertion);
                activityEntity.addSoxCtrlActivityAssertions(soxCtrlActivityAssertion);
            }
        }
    }

    private void setEntityOwners(SoxControlEntity entity, Cell cell, String entityType) throws Exception {
        logger.debug("setEntityOwners: " + cell.toString());

        Collection<String> entityOwners = getCommaSeparatedListAsCollection(cell.toString());

        logger.debug("entityOwners: " + entityOwners.size());

        if (entityOwners.isEmpty()) {
            entityOwners.add(SoxConstants.NONE);
        }

        for (String entityOwnerString : entityOwners) {
            PersonInfo personInfo = null;

            if (entityOwnerString.equalsIgnoreCase(SoxConstants.NONE)) {
                personInfo = new PersonInfo();
                personInfo.setUserId(entityOwnerString.toUpperCase());
            } else {
                // Get the user info from people picker
                logger.debug("getPersonInfo: " + entityOwnerString);
                personInfo = getPersonInfo(entityOwnerString.toUpperCase());
            }

            //logger.debug("personInfo: " + (personInfo != null ? personInfo.getUserId() : personInfo));

            SoxOwner owner = ownerService.lookupOwnerByUserId(personInfo.getUserId());

            // if owner is missing then generate new one
            if (owner == null) {
                owner = new SoxOwner();
                owner.setUserId(entityOwnerString.toUpperCase());
                ownerService.save(owner);
            }

            SoxControlEntityOwner controlEntityOwner = new SoxControlEntityOwner();

            logger.debug("loading questions for entityType: " + entityType);

            Collection<SoxQuestion> allQuestions = questionService.getAllQuestions();

            //logger.debug("allQuestions size: " + (allQuestions != null ? allQuestions.size() : allQuestions));

            Collection<SoxQuestion> questions = new ArrayList<SoxQuestion>();

            for (SoxQuestion currentQuestion : allQuestions) {
                logger.debug("currentQuestion.getLevelType(): '" + currentQuestion.getLevelType() + "'");
                logger.debug("entityType: '" + entityType + "'");

                if (currentQuestion.getLevelType().trim().equalsIgnoreCase(entityType)) {
                    questions.add(currentQuestion);

                    logger.debug("adding question: " + currentQuestion.getLevelType());
                }
            }

            logger.debug("questions size: " + (questions.size()));

            SoxResponse response = null;

            for (SoxQuestion question : questions) {
                response = new SoxResponse();
                controlEntityOwner.getSoxResponses();
                controlEntityOwner.addSoxResponse(response);
                response.setSoxQuestion(question);

                logger.debug("question added: " + question.getDescription());
            }

            controlEntityOwner.setSoxOwner(owner);
            entity.addSoxControlEntityOwner(controlEntityOwner);
        }
    }

    private PersonInfo getPersonInfo(String userId) throws Exception {
        PersonInfo personInfo = searchPeopleService.findPersonByUserId(userId);

        if (personInfo.getUserId() == null) {
            throw new InvalidUserException(userId);
        }

        return personInfo;
    }

    private Collection<String> getCommaSeparatedListAsCollection(String list) {
        if (list != null && list.trim().length() > 0) {
            return Lists.newArrayList(splitter.split(list));
        }

        return new ArrayList<String>();
    }

    private SoxControlEntity getChildEntity(SoxControlEntity entity, String childControlEntityId) {
        if (entity != null) {
            Collection<SoxControlEntity> children = entity.getChildControlEntities();

            for (SoxControlEntity currentChild : children) {
                if (currentChild.getControlEntityId() != null && currentChild.getControlEntityId().equals(childControlEntityId)) {
                    return currentChild;
                }
            }
        }

        return null;
    }

    private Set<SoxCountry> parseCountries(Cell cell) throws TemplateException{
        Set<SoxCountry> countries = new HashSet<SoxCountry>();

        Iterable<String> countryNames = splitter.split(cell.toString());

        for (String countryName : countryNames) {
            SoxCountry country = countryService.getCountryByDescription(countryName);

            if (country != null) {
                countries.add(country);
            } else {
                throw new TemplateException("Template error, the countries are not correct: " + cell.toString());
            }
        }

        return countries;
    }

    private boolean isEmptyCell(Cell cell) {
        return cell == null || cell.toString() == null || cell.toString().isEmpty();
    }

    private Set<SoxSystem> parseSystems(Cell cell) throws TemplateException {
        Set<SoxSystem> soxSystems = new HashSet<SoxSystem>();

        Iterable<String> systems = splitter.split(cell.toString());

        for (String system : systems) {
            SoxSystem soxSystem = soxSystemService.getSoxSystemByDescription(system);

            if (soxSystem != null) {
                soxSystems.add(soxSystem);
            } else {
                throw new TemplateException("Template error, the systems are not correct: " + cell.toString());
            }
        }

        return soxSystems;
    }

    private static class ControlId {
        public static final ControlId NULL_CONTROL_ID = new ControlId(null, null, null);

        private String cycleId;
        private String subCycleId;
        private String activityId;

        private ControlId(String cycleId, String subCycleId, String activityId) {
            this.cycleId = cycleId;
            this.subCycleId = subCycleId;
            this.activityId = activityId;
        }

        public String getCycleId() {
            return cycleId;
        }

        public String getSubCycleId() {
            return subCycleId;
        }

        public String getActivityId() {
            return activityId;
        }
    }

    private static class ControlIdBuilder {
        private static ControlId build(SoxPeriod period, String id) {
            String periodId = period != null ? period.getPeriodId() : "";

            String[] entityId = id.split("\\.");

            if (entityId.length == 3) {
                String cycleId = periodId + "." + entityId[0];
                String subCycleId = cycleId + "." + entityId[1];
                String activityId = subCycleId + "." + entityId[2];

                return new ControlId(cycleId, subCycleId, activityId);
            }

            return ControlId.NULL_CONTROL_ID;
        }
    }
}
