package com.monsanto.eas.sox.service;

import com.monsanto.eas.sox.exception.TemplateException;
import com.monsanto.eas.sox.model.SoxSystem;

import java.util.Collection;
import java.util.Set;

public interface SoxSystemService {
    SoxSystem getSoxSystemByDescription(String description);

    Collection<SoxSystem> lookupAllSoxSystems();

    Set<SoxSystem> parseSystems(String systemList) throws TemplateException;
}
