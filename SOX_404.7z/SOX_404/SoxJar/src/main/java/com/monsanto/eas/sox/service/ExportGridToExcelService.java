package com.monsanto.eas.sox.service;

import java.util.Collection;

public interface ExportGridToExcelService {
    byte[] getExcelFileForReportName(String reportName, Collection<Object> gridRows);
}
