package com.monsanto.eas.sox.service;

import com.monsanto.eas.sox.exception.TemplateException;
import com.monsanto.eas.sox.model.SoxCountry;

import java.util.Collection;
import java.util.Set;

public interface CountryService {
    SoxCountry getCountryByDescription(String description);

    Collection<SoxCountry> getAllCountries();

    Set<SoxCountry> parseCountries(String countryList) throws TemplateException;
}
