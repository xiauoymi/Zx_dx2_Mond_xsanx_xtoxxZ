package com.monsanto.eas.sox.service;

import com.monsanto.eas.sox.model.Fraud;

public interface FraudService {
    Fraud getFraudByDescription(String description);
}
