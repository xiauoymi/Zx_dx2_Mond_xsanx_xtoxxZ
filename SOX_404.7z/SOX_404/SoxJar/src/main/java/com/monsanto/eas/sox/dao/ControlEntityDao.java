package com.monsanto.eas.sox.dao;

import com.monsanto.eas.sox.model.*;

import java.util.Collection;
import java.util.Date;

public interface ControlEntityDao extends GenericDao<SoxControlEntity> {

    SoxControlEntity lookupSoxControlEntityByControlId(String controlId);

    Collection<SoxControlEntity> lookupAllCycles();

    Collection<SoxControlEntityOwner> lookupCertificationsStarted(SoxPeriod currentPeriod);

    Collection<SoxControlEntityOwner> lookupEntityOwnersCertificationsOverdue(SoxPeriod currentPeriod);

    Collection<SoxControlEntityOwner> lookupEntityChildsCertificationsOverdue(SoxPeriod currentPeriod);

    Collection<SoxControlEntityOwner> lookupCertificationsToSendReminder(Date formattedDate, SoxPeriod currentPeriod);


    Collection<SoxControlEntity> lookupEntitiesNotCertifiedForUser(String userId);

    Collection<DependentOverdueEntityVO> lookupChildsForAnEntity(String controlEntityId);

    Collection<SoxControlEntity> lookupCyclesOwnedByUser(String userId);

    Collection<SoxControlEntity> lookupSubCyclesOwnedByUser(String userId);

    Collection<SoxControlEntity> lookupSubCyclesByUserAndCycle(String userId, String cycleId);

    Collection<SoxControlEntity> lookupActivitiesOwnedByUser(String userId);

    Collection<SoxControlEntity> lookupActivitiesByUserAndCycle(String userId, String cycleId);

    Collection<SoxControlEntity> lookupActivitiesByCycle(String periodId, String cycleId);

    Collection<SoxControlEntity> lookupActivitiesByCountry(String periodId, String countryId);

    Collection<SoxControlEntity> lookupActivitiesByCountryAndCycle(String periodId, String countryId, String cycleId);

    Collection<SoxControlEntity> lookupActivitiesByUserAndSubCycle(String userId, String subCycleId);

    Collection<SoxControlEntity> getIncompleteChildren(String entityId);

    Collection<SoxControlEntity> lookupCyclesByPeriod(String periodId);

    PeriodMaintenanceVO getPeriodHistoricalData(SoxPeriod period);

    boolean isPeriodOpen(SoxPeriod period);

    Collection<DependentOverdueEntityVO> lookupCertifiedOwnersForAnEntity(String controlEntityId, Date currentDate);

    Collection<DependentOverdueEntityVO> lookupCertifiedOwnersForAnEntityWithoutDateRestriction(String controlEntityId);

    Collection<RelatedActivityVO> getActivitiesDifferentFromSelectedCycle(String controlEntityId);
}
