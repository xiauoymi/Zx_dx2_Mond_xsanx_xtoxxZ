package com.monsanto.eas.sox.service.impl;

import com.monsanto.eas.sox.dao.ControlEntityRelationshipDao;
import com.monsanto.eas.sox.model.SoxControlEntityRelationship;
import com.monsanto.eas.sox.service.ControlEntityRelationShipService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.flex.remoting.RemotingDestination;
import org.springframework.flex.remoting.RemotingInclude;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collection;

@Service
@RemotingDestination(value = "controlEntityRelationshipService")
public class ControlEntityRelationshipServiceImpl implements ControlEntityRelationShipService {

    @Autowired
    private ControlEntityRelationshipDao controlEntityRelationshipDao;

    @Override
    @Transactional
    public void deleteSoxControlEntityRelationship(int relationshipId) {
        controlEntityRelationshipDao.deleteSoxControlEntityRelationship(relationshipId);
    }

    @RemotingInclude
    public SoxControlEntityRelationship saveOrUpdate(SoxControlEntityRelationship soxControlEntityRelationship) {
        controlEntityRelationshipDao.merge(soxControlEntityRelationship);
        return soxControlEntityRelationship;
    }

    @Override
    public Collection<SoxControlEntityRelationship> getRelatedActivitiesByCycle(String cycleId) {
        Collection<SoxControlEntityRelationship> relatedActivities = controlEntityRelationshipDao.lookupRelatedActivities(cycleId);
        return relatedActivities;
    }
}
