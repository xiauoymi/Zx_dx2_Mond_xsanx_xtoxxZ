package com.monsanto.eas.sox.service;

import com.monsanto.eas.sox.exception.TemplateException;
import com.monsanto.eas.sox.model.SOXPeriodWithCycleTemplateDataVO;
import com.monsanto.eas.sox.model.SoxOwnerCycleTemplateVO;

import java.util.List;

public interface ImportSOXCycleBatchProcessService {

    List<String> copyPreviousCyclesIntoCurrentPeriod(String currentOrNewPeriod) throws TemplateException;

    List<String> modifySOXControlEntitiesFromTemplate(List<SOXPeriodWithCycleTemplateDataVO> soxControlEntitiesFromTemplateVOList,
                                                      String currentOrNewPeriod, String cycleId, SoxOwnerCycleTemplateVO cycleActivitiesOwner, String userId);
}
