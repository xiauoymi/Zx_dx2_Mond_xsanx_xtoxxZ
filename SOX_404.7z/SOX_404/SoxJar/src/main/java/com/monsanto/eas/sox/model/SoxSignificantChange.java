package com.monsanto.eas.sox.model;

import org.hibernate.annotations.Cascade;

import javax.persistence.*;

@Table(name = "SOX_SIGNIFICANT_CHANGE", schema = "SARBOX_ET")
@Entity
@NamedQueries({
        @NamedQuery(name = "lookupSignificantChangeByEntityAndOwner",
                query = "SELECT sc " +
                        " FROM SoxSignificantChange sc " +
                        " JOIN sc.soxControlEntityOwner eo JOIN eo.soxControlEntity ce JOIN eo.soxOwner o " +
                        " WHERE ce.controlEntityId=:entityId and o.userId=:userId")
})
public class SoxSignificantChange {
    @Id
    @SequenceGenerator(name = "soxSignificantChangeSeq", sequenceName = "SARBOX_ET.SOX_SIGNIFICANT_CHANGE_SEQ")
    @GeneratedValue(generator = "soxSignificantChangeSeq", strategy = GenerationType.SEQUENCE)
    @javax.persistence.Column(name = "SIGNIFICANT_CHANGE_ID", nullable = false, insertable = true, updatable = true, length = 22, precision = 0)
    private int significantChangeId;

    @ManyToOne
    @Cascade({org.hibernate.annotations.CascadeType.SAVE_UPDATE, org.hibernate.annotations.CascadeType.PERSIST, org.hibernate.annotations.CascadeType.MERGE})
    @JoinColumn(name = "BUSINESS_TYPE_ID", referencedColumnName = "BUSINESS_TYPE_ID")
    private SoxBusinessType soxBusinessType;

    @javax.persistence.Column(name = "COST", nullable = true, insertable = true, updatable = true, length = 100, precision = 0)
    @Basic
    private String cost;

    @javax.persistence.Column(name = "KEY_CONTACT", nullable = true, insertable = true, updatable = true, length = 100, precision = 0)
    @Basic
    private String keyContact;

    @javax.persistence.Column(name = "SUB_CYCLE_IMPACTED", nullable = true, insertable = true, updatable = true, length = 200, precision = 0)
    @Basic
    private String subCycleImpacted;

    @javax.persistence.Column(name = "DESCRIPTION", nullable = true, insertable = true, updatable = true, length = 2000, precision = 0)
    @Basic
    private String description;

    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "CONTROL_ENTITY_OWNER_ID", referencedColumnName = "CONTROL_ENTITY_OWNER_ID")
    private SoxControlEntityOwner soxControlEntityOwner;

    public SoxControlEntityOwner getSoxControlEntityOwner() {
        return soxControlEntityOwner;
    }

    public void setSoxControlEntityOwner(SoxControlEntityOwner soxControlEntityOwner) {
        this.soxControlEntityOwner = soxControlEntityOwner;
    }

    public int getSignificantChangeId() {
        return significantChangeId;
    }

    public void setSignificantChangeId(int significantChangeId) {
        this.significantChangeId = significantChangeId;
    }

    public SoxBusinessType getSoxBusinessType() {
        return soxBusinessType;
    }

    public void setSoxBusinessType(SoxBusinessType soxBusinessType) {
        this.soxBusinessType = soxBusinessType;
    }

    public String getCost() {
        return cost;
    }

    public void setCost(String cost) {
        this.cost = cost;
    }

    public String getKeyContact() {
        return keyContact;
    }

    public void setKeyContact(String keyContact) {
        this.keyContact = keyContact;
    }

    public String getSubCycleImpacted() {
        return subCycleImpacted;
    }

    public void setSubCycleImpacted(String subCycleImpacted) {
        this.subCycleImpacted = subCycleImpacted;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        SoxSignificantChange that = (SoxSignificantChange) o;

        if (significantChangeId != that.significantChangeId) return false;
        if (cost != null ? !cost.equals(that.cost) : that.cost != null) return false;
        if (description != null ? !description.equals(that.description) : that.description != null) return false;
        if (keyContact != null ? !keyContact.equals(that.keyContact) : that.keyContact != null) return false;
        if (subCycleImpacted != null ? !subCycleImpacted.equals(that.subCycleImpacted) : that.subCycleImpacted != null) return false;
        if (soxBusinessType != null ? !soxBusinessType.equals(that.soxBusinessType) : that.soxBusinessType != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = significantChangeId;
//        result = 31 * result + businessTypeId;
        result = 31 * result + (cost != null ? cost.hashCode() : 0);
        result = 31 * result + (keyContact != null ? keyContact.hashCode() : 0);
        result = 31 * result + (subCycleImpacted != null ? subCycleImpacted.hashCode() : 0);
        result = 31 * result + (description != null ? description.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        return "SoxSignificantChange{" +
                "significantChangeId=" + significantChangeId +
//                ", soxBusinessType=" + soxBusinessType +
//                ", cost='" + cost + '\'' +
//                ", keyContact='" + keyContact + '\'' +
//                ", subCycleImpacted='" + subCycleImpacted + '\'' +
                ", description='" + description + '\'' +
//                ", soxControlEntityOwner=" + soxControlEntityOwner +
                '}';
    }
}
