package com.monsanto.eas.sox.dao;

import com.monsanto.eas.sox.model.SoxResponse;

import java.util.Collection;

public interface ResponseDao extends GenericDao<SoxResponse> {

   void deleteSoxResponseWithoutReferences();

   SoxResponse lookupResponse();

   Collection<SoxResponse> lookupResponseForEntityAndOwner(String entityId, String userId);
}
