package com.monsanto.eas.sox.context;

import com.monsanto.Util.databasepasswordencryption.EncryptionUtils;
import org.springframework.beans.factory.config.AutowireCapableBeanFactory;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

import java.util.ResourceBundle;

/**
 * Bootstraps Spring-managed beans into an application. How to use:
 * <ul>
 * <li>Create XML configuration files. The configuration must include the
 * {@code <context:annotation-config/>} element to enable annotation-based
 * configuration, or the {@code <context:component-scan base-package="..."/>}
 * element to also detect bean definitions from annotated classes.
 * <li>Create a "main" class that will receive references to Spring-managed
 * beans. Add the {@code @Autowired} annotation to any properties you want to be
 * injected with beans from the application context.
 * <li>In your application {@code main} method, create an
 * {@link ApplicationContextLoader} instance, and call the {@link #load} method
 * with the "main" object and the configuration file locations as parameters.
 * </ul>
 */
public class ApplicationContextLoader {
 
    private static final String ENV_D_PARAM = "env";
    private static final String LSI_FUNCTION = "lsi.function";
    private static final String JDBC_PROPERTIES = "jdbc";

    private static final String JDBC_CONNECTION_URL = ".jdbc.url";
    private static final String JDBC_USER_NAME = ".jdbc.username";

    protected ConfigurableApplicationContext applicationContext;
 
    public ApplicationContextLoader() {
        super();
    }
 
    public ConfigurableApplicationContext getApplicationContext() {
        return applicationContext;
    }
 
    /**
     * Loads application context. Override this method to change how the
     * application context is loaded.
     * 
     * @param configLocations
     *            configuration file locations
     */
    protected void loadApplicationContext(String... configLocations) {
        applicationContext = new ClassPathXmlApplicationContext(
                configLocations);
        applicationContext.registerShutdownHook();
    }
 
    /**
     * Injects dependencies into the object. Override this method if you need
     * full control over how dependencies are injected.
     * 
     * @param main
     *            object to inject dependencies into
     */
    protected void injectDependencies(Object main) {
        getApplicationContext().getBeanFactory().autowireBeanProperties(
                main, AutowireCapableBeanFactory.AUTOWIRE_NO, false);
    }
 
    /**
     * Loads application context, then injects dependencies into the object.
     * 
     * @param main
     *            object to inject dependencies into
     * @param configLocations
     *            configuration file locations
     */
    public void load(Object main, String... configLocations) throws Exception{
        loadApplicationContext(configLocations);
        updateDataSource();
        injectDependencies(main);
    }

    private void updateDataSource() throws Exception
    {
        String databaseUrl = getJdbcProperties(JDBC_CONNECTION_URL);
        String username = getJdbcProperties(JDBC_USER_NAME);

        DriverManagerDataSource dataSource = (DriverManagerDataSource) applicationContext.getBean("dataSource");
        System.out.println("url = " + databaseUrl);
        System.out.println("username = " + username);
        dataSource.setUrl(databaseUrl);
        dataSource.setUsername(username);
        dataSource.setPassword(
            EncryptionUtils.GetDecryptedStringFromExternalStorage("MONCRYPTJV", "sox", "soxDBPassword.txt", "soxDBKey.txt"));
    }

    private static String getJdbcProperties(String parameter) throws Exception {
      String env = getEnvironment();
      ResourceBundle bundle = ResourceBundle.getBundle(JDBC_PROPERTIES);
      return bundle.getString(env + parameter);
    }

    public static String getEnvironment() {
      String env = System.getProperty(ENV_D_PARAM);
      if (env == null) {
        env = System.getProperty(LSI_FUNCTION);
      }
      System.out.println("Environment is: " + env);
      return env;
    }
}