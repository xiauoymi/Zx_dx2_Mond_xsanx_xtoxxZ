package com.monsanto.eas.sox.service.impl;

import com.monsanto.eas.sox.dao.TypeOfControlDao;
import com.monsanto.eas.sox.model.TypeOfControl;
import com.monsanto.eas.sox.service.TypeOfControlService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.flex.remoting.RemotingDestination;
import org.springframework.flex.remoting.RemotingInclude;
import org.springframework.stereotype.Service;

@Service
@RemotingDestination(value="typeOfControlService")
public class TypeOfControlServiceImpl implements TypeOfControlService {

    @Autowired
    private TypeOfControlDao typeOfControlDao;

    @RemotingInclude
    public TypeOfControl getTypeOfControlByDescription(String description) {
        TypeOfControl typeOfControl = typeOfControlDao.lookupTypeOfControlByDescription(description);
        return typeOfControl;
    }
}
