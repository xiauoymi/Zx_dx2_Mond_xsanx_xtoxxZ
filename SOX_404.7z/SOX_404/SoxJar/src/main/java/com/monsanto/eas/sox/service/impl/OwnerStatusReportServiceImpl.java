package com.monsanto.eas.sox.service.impl;

import com.monsanto.PeoplePicker.PersonInfo;
import com.monsanto.eas.sox.dao.ControlEntityOwnerDao;
import com.monsanto.eas.sox.exception.InvalidUserException;
import com.monsanto.eas.sox.model.OwnerStatusReportVO;
import com.monsanto.eas.sox.model.SoxControlEntityOwner;
import com.monsanto.eas.sox.model.SoxResponse;
import com.monsanto.eas.sox.service.OwnerStatusReportService;
import com.monsanto.eas.sox.service.SearchPeopleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.flex.remoting.RemotingDestination;
import org.springframework.flex.remoting.RemotingInclude;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Collection;

@Service
@RemotingDestination(value = "ownerStatusReportService")
public class OwnerStatusReportServiceImpl implements OwnerStatusReportService {

    private static final boolean USER_ACTIVE_AND_VALID = true;

    @Autowired
    private SearchPeopleService searchPeopleService;

    @Autowired
    ControlEntityOwnerDao controlEntityOwnerDao;

    @RemotingInclude
    public Collection<OwnerStatusReportVO> getOwnerStatusReport(String periodId) throws InvalidUserException {
        Collection<OwnerStatusReportVO> result = new ArrayList<OwnerStatusReportVO>();
        Collection<SoxControlEntityOwner> ceo = controlEntityOwnerDao.lookupControlEntityOwnerByPeriod(periodId);

        OwnerStatusReportVO ownerStatusReportVO;

        for (SoxControlEntityOwner currentCeo : ceo) {
            String status = "complete";
            for (SoxResponse currentResponse : currentCeo.getSoxResponses()) {
                if (currentResponse.getResponseType() == null) {
                    status = "incomplete";
                }
            }

            ownerStatusReportVO = new OwnerStatusReportVO(
                    currentCeo.getSoxControlEntity().getControlEntityId(),
                    currentCeo.getSoxOwner().getUserId(),
                    status,
                    currentCeo.getSoxControlEntity().getDescription(),
                    USER_ACTIVE_AND_VALID);

            if (!currentCeo.getSoxOwner().isNone()) {
                fillFirstAndLastName(ownerStatusReportVO);
            } else {
                ownerStatusReportVO.setUserId("");
                ownerStatusReportVO.setActiveAndValidUser(false);
            }

            result.add(ownerStatusReportVO);
        }
        //fillFirstAndLastName(result);
        return result;
    }

    /*
    private void fillFirstAndLastName(Collection<OwnerStatusReportVO> ownerStatusReportVOCollection) throws InvalidUserException {
        for (OwnerStatusReportVO ownerStatusReportVO : ownerStatusReportVOCollection) {
            PersonInfo personInfo = searchPeopleService.findPersonByUserId(ownerStatusReportVO.getUserId());

            ownerStatusReportVO.setFirstName(personInfo.getFirstName());
            ownerStatusReportVO.setLastName(personInfo.getLastName());
            ownerStatusReportVO.setRegion(personInfo.getMailStop());
        }
    }
    */

    private void fillFirstAndLastName(OwnerStatusReportVO ownerStatusReportVO) {
        try {
            PersonInfo personInfo = searchPeopleService.findPersonByUserId(ownerStatusReportVO.getUserId());

            ownerStatusReportVO.setFirstName(personInfo.getFirstName());
            ownerStatusReportVO.setLastName(personInfo.getLastName());
            ownerStatusReportVO.setRegion(personInfo.getMailStop());
        }
        catch (InvalidUserException iue) {
            ownerStatusReportVO.setActiveAndValidUser(false);
        }
    }

}
