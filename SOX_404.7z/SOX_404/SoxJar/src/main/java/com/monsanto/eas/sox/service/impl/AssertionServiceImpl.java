package com.monsanto.eas.sox.service.impl;

import com.monsanto.eas.sox.dao.AssertionDao;
import com.monsanto.eas.sox.model.Assertion;
import com.monsanto.eas.sox.service.AssertionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.flex.remoting.RemotingDestination;
import org.springframework.stereotype.Service;

@Service
@RemotingDestination(value="assertionService")
public class AssertionServiceImpl implements AssertionService{

    @Autowired
    private AssertionDao assertionDao;

    //@Autowired
    //private SoxCtrlActivityAssertionDao soxCtrlActivityAssertionDao;

    @Override
    public Assertion getAssertionByDescription(String description) {
        Assertion assertion = assertionDao.lookupAssertionByDescription(description);
        return assertion;
    }

}
