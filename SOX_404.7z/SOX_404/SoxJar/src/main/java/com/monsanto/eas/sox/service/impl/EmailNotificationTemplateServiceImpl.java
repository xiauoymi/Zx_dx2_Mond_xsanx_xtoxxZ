package com.monsanto.eas.sox.service.impl;

import com.monsanto.eas.sox.dao.ConfigDao;
import com.monsanto.eas.sox.model.EmailNotificationTemplateVO;
import com.monsanto.eas.sox.model.SoxConfig;
import com.monsanto.eas.sox.service.EmailNotificationTemplateService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.flex.remoting.RemotingDestination;
import org.springframework.flex.remoting.RemotingInclude;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;

@Service
@RemotingDestination(value="emailNotificationTemplateService")
public class EmailNotificationTemplateServiceImpl implements EmailNotificationTemplateService {

    @Autowired
    private ConfigDao configDao;
    private final static String EMAIL_TEMPLATE = ".emailTemplate";
    private final static String EMAIL_SUBJECT = ".subject";

    @Override
    @RemotingInclude
    public String save(String notificationType, String subject, String body) {
        List<SoxConfig> soxConfigList = new ArrayList<SoxConfig>();
        SoxConfig soxConfig = new SoxConfig(
                notificationType + EMAIL_TEMPLATE,
                body
        );
        soxConfigList.add(soxConfig);
        soxConfig = new SoxConfig(
              notificationType + EMAIL_SUBJECT,
              subject
      );
        soxConfigList.add(soxConfig);
        configDao.saveConfigList(soxConfigList);

        return "java";
    }
  /*
    @Override
    @RemotingInclude
    public String save(EmailNotificationTemplateVO emailNotificationTemplateVO) {
        List<SoxConfig> soxConfigList = new ArrayList<SoxConfig>();
        SoxConfig soxConfig = new SoxConfig(
                emailNotificationTemplateVO.getNotificationType() + EMAIL_TEMPLATE,
                emailNotificationTemplateVO.getBody()
        );
        soxConfigList.add(soxConfig);
        soxConfig = new SoxConfig(
              emailNotificationTemplateVO.getNotificationType() + EMAIL_SUBJECT,
              emailNotificationTemplateVO.getSubject()
      );
        soxConfigList.add(soxConfig);
        configDao.saveConfigList(soxConfigList);

        return "java";
    }
    */
    @Override
    @RemotingInclude
    @Transactional
    public EmailNotificationTemplateVO getEmailNotificationTemplate(String notificationType) {
        EmailNotificationTemplateVO emailNotificationTemplateVO = null;
        List<SoxConfig> soxConfigList = configDao.lookupConfigsByName(notificationType + "%");
        if (soxConfigList != null && !soxConfigList.isEmpty()){
            emailNotificationTemplateVO = new EmailNotificationTemplateVO();
            for (SoxConfig config : soxConfigList){
                if (config.getParameterName().indexOf(EMAIL_SUBJECT) != -1){
                    emailNotificationTemplateVO.setSubject(config.getParameterValue());
                }
                else if (config.getParameterName().indexOf(EMAIL_TEMPLATE) != -1){
                    emailNotificationTemplateVO.setBody(config.getParameterValue());
                }
            }
        }

        return emailNotificationTemplateVO;
    }
}
