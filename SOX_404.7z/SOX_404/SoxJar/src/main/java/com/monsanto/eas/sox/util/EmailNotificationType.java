package com.monsanto.eas.sox.util;

public enum EmailNotificationType {
    CERTIFICATION_START("certificationStart"), REMINDER("reminder"), ENTITIES_OVERDUE("entitiesOverdue"), CHILD_ENTITIES_OVERDUE("childEntitiesOverdue"), UNCERTIFY("uncertifiedNotice");
    private String code;
    EmailNotificationType(String code){
        this.code = code;
    }

    public String getCode() {
      return code;
    }

    public static EmailNotificationType getEmailNotificationType(String value){
        EmailNotificationType notificationType = null;

        if (value.equalsIgnoreCase(EmailNotificationType.CERTIFICATION_START.getCode())){
            notificationType = CERTIFICATION_START;
        }
        else if (value.equalsIgnoreCase(EmailNotificationType.REMINDER.getCode())){
            notificationType = REMINDER;
        }
        else if (value.equalsIgnoreCase(EmailNotificationType.ENTITIES_OVERDUE.getCode())){
            notificationType = ENTITIES_OVERDUE;
        }
        else if (value.equalsIgnoreCase(EmailNotificationType.CHILD_ENTITIES_OVERDUE.getCode())){
            notificationType = ENTITIES_OVERDUE;
        }
        else if(value.equalsIgnoreCase(EmailNotificationType.UNCERTIFY.getCode())){
                    notificationType = UNCERTIFY;
                }
        return notificationType;
    }
}
