package com.monsanto.eas.sox.service;

import com.monsanto.eas.sox.model.DependentOverdueEntityVO;
import com.monsanto.eas.sox.model.SOXPeriodWithCycleTemplateDataVO;
import com.monsanto.eas.sox.model.SoxEntityTrackLogVO;

import java.util.Collection;
import java.util.List;
import java.util.Map;

public interface SOXEntityTrackLogService {

    void trackUpdateEntityOwners(String controlEntityId, String originalOwner, String newOwner, String userId );

    void trackUpdateEntity(Map<String, SoxEntityTrackLogVO> soxModifiedEntityTrackLogVOMap, String userId);

    void trackDeleteEntity(List<SOXPeriodWithCycleTemplateDataVO> soxPeriodWithCycleTemplateDataVOList, String userId);

    void trackAddEntity(List<SOXPeriodWithCycleTemplateDataVO> soxPeriodWithCycleTemplateDataVOList, String userId);

    void sendUncertifyNotice(Collection<DependentOverdueEntityVO> otherChilds, String controlEntityId, String parentId);
}
