package com.monsanto.eas.sox.dao.impl;

import com.monsanto.eas.sox.dao.DelinquentReportDao;
import com.monsanto.eas.sox.model.DelinquentReportVO;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.util.Collection;

@Repository
public class DelinquentReportDaoImpl extends GenericDaoImpl<DelinquentReportVO> implements DelinquentReportDao {

     private static final long serialVersionUID = 1L;

    @PersistenceContext
    private EntityManager entityManager;

    @Override
    public Collection<DelinquentReportVO> lookupDelinquentOwnersByPeriod(String periodId) {
        return entityManager.createNamedQuery("lookupDelinquentOwnersByPeriod").setParameter("periodId", periodId).getResultList();
    }
}
