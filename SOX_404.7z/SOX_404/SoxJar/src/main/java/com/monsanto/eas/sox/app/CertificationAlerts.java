package com.monsanto.eas.sox.app;

import com.monsanto.eas.sox.context.ApplicationContextLoader;
import com.monsanto.eas.sox.model.EmailNotificationTemplateVO;
import com.monsanto.eas.sox.service.CertificationMessagesService;
import com.monsanto.eas.sox.service.SampleEmailNotificationService;
import com.monsanto.eas.sox.util.EmailNotificationType;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component // Main is a Spring-managed bean too, since it have @Autowired property
public class CertificationAlerts {
    @Autowired
    private CertificationMessagesService certificationMessagesService;

    private final Logger logger = Logger.getLogger(CertificationAlerts.class);

    @Autowired
    private SampleEmailNotificationService sampleEmailNotificationService;

    public void processAlerts() throws Exception
    {
        logger.debug("Starting Notifications job");
        try {
            certificationMessagesService.sendStartCertificationMessages(getNotificationTemplateVO(EmailNotificationType.CERTIFICATION_START));
            certificationMessagesService.sendReminderMessages(getNotificationTemplateVO(EmailNotificationType.REMINDER));
            certificationMessagesService.sendEntityOwnersOverdueCertificationMessages(getNotificationTemplateVO(EmailNotificationType.ENTITIES_OVERDUE));
        } catch (Exception e) {
            logger.error(e);
        } finally {
            logger.debug("Ending Notifications job");
        }
    }

    private EmailNotificationTemplateVO getNotificationTemplateVO(EmailNotificationType notificationType){
        return sampleEmailNotificationService.getEmailNotificationTemplate(notificationType.getCode());
    }

    public static void main(String[] args) throws Exception
    {
        ApplicationContextLoader loader = new ApplicationContextLoader();

        CertificationAlerts alerts = new CertificationAlerts();
        loader.load(alerts, new String[] {"alertsContext-dao-jpa.xml","alertsContext-service.xml"});

        alerts.processAlerts();
    }
}
