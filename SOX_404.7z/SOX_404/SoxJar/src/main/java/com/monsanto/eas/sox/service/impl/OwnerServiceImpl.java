package com.monsanto.eas.sox.service.impl;

import com.monsanto.eas.sox.dao.OwnerDao;
import com.monsanto.eas.sox.model.SoxOwner;
import com.monsanto.eas.sox.service.OwnerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.flex.remoting.RemotingDestination;
import org.springframework.flex.remoting.RemotingInclude;
import org.springframework.stereotype.Service;

@Service
@RemotingDestination(value = "ownerService")
public class OwnerServiceImpl implements OwnerService
{
    private OwnerDao ownerDao;

    @Autowired
    public void setOwnerDao(OwnerDao ownerDao) {
        this.ownerDao = ownerDao;
    }

    @RemotingInclude
    public SoxOwner lookupOwnerByUserId(String userId){
        SoxOwner soxOwner = ownerDao.lookupSoxOwnerByUserId(userId);
        return soxOwner;
    }

    @RemotingInclude
    public SoxOwner save(SoxOwner owner) {
        ownerDao.save(owner);
        return owner;
    }

}