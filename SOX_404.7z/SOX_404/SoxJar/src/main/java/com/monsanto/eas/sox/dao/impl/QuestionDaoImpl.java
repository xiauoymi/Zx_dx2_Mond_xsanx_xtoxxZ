package com.monsanto.eas.sox.dao.impl;

import com.monsanto.eas.sox.dao.QuestionDao;
import com.monsanto.eas.sox.model.SoxQuestion;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.util.Collection;

@Repository
public class QuestionDaoImpl extends GenericDaoImpl<SoxQuestion> implements QuestionDao{
    private static final long serialVersionUID = 1L;

    @PersistenceContext
    private EntityManager entityManager;

    public Collection<SoxQuestion> lookupQuestionsForEntity(String entityType) {
        return  entityManager.createNamedQuery("lookupQuestionsForEntity").setParameter("entityType", entityType).getResultList();
    }

    public Collection<SoxQuestion> lookupAllQuestions() {
        return  entityManager.createNamedQuery("lookupAllQuestions").getResultList();
    }
}
