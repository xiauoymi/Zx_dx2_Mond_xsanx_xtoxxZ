package com.monsanto.eas.sox.model;

/**
 * Created by IntelliJ IDEA.
 * User: JEESCO
 * Date: 2/02/2012
 * Time: 09:27:07 AM
 */
public class CompletionReportDataVO {
    private String id;
    private Double completedPercentage;
    private Double nonCompletedPercentage;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Double getCompletedPercentage() {
        return completedPercentage;
    }

    public void setCompletedPercentage(Double completedPercentage) {
        this.completedPercentage = completedPercentage;
    }

    public Double getNonCompletedPercentage() {
        return nonCompletedPercentage;
    }

    public void setNonCompletedPercentage(Double nonCompletedPercentage) {
        this.nonCompletedPercentage = nonCompletedPercentage;
    }
}
