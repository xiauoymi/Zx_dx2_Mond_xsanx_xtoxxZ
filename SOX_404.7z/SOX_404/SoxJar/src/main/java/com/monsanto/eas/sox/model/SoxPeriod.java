package com.monsanto.eas.sox.model;

import javax.persistence.Basic;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;

@Entity
@Table(name = "SOX_PERIOD", schema = "SARBOX_ET")
public class SoxPeriod implements Serializable{

  private static final long serialVersionUID = 1L;

    @javax.persistence.Column(name = "PERIOD_ID", nullable = false, insertable = true, updatable = true, length = 22, precision = 0)
    @Id
    private String periodId;

    @javax.persistence.Column(name = "PERIOD_DESCRIPTION", nullable = true, insertable = true, updatable = true, length = 200, precision = 0)
    @Basic
    private String periodDescription;

    @javax.persistence.Column(name = "CYCLE_ONLY", nullable = true, insertable = true, updatable = true, length = 10, precision = 0)
    @Basic
    private String cycleOnly;

    @javax.persistence.Column(name = "CURRENT_PERIOD", nullable = true, insertable = true, updatable = true, length = 1, precision = 0)
    @Basic
    private String currentPeriod;

    @javax.persistence.Column(name = "CLOSED_PERIOD", nullable = true, insertable = true, updatable = true, length = 1, precision = 0)
    @Basic
    private String closedPeriod;

    @javax.persistence.Column(name = "NEWS", nullable = true, insertable = true, updatable = true, length = 1, precision = 0)
    @Basic
    private String news;

    public String getPeriodId() {
        return periodId;
    }

    public void setPeriodId(String periodId) {
        this.periodId = periodId;
    }

    public String getPeriodDescription() {
        return periodDescription;
    }

    public void setPeriodDescription(String periodDescription) {
        this.periodDescription = periodDescription;
    }

    public String getCycleOnly() {
        return cycleOnly;
    }

    public void setCycleOnly(String cycleOnly) {
        this.cycleOnly = cycleOnly;
    }

    public String getCurrentPeriod() {
        return currentPeriod;
    }

    public void setCurrentPeriod(String currentPeriod) {
        this.currentPeriod = currentPeriod;
    }

    public String getClosedPeriod() {
      return closedPeriod;
    }

    public void setClosedPeriod(String closedPeriod) {
      this.closedPeriod = closedPeriod;
    }

    public String getNews() {
      return news;
    }

    public void setNews(String news) {
      this.news = news;
    }

  @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        SoxPeriod soxPeriod = (SoxPeriod) o;

        if (periodId != soxPeriod.periodId) return false;
        if (currentPeriod != null ? !currentPeriod.equals(soxPeriod.currentPeriod) : soxPeriod.currentPeriod != null)
            return false;
        if (cycleOnly != null ? !cycleOnly.equals(soxPeriod.cycleOnly) : soxPeriod.cycleOnly != null) return false;
        if (periodDescription != null ? !periodDescription.equals(soxPeriod.periodDescription) : soxPeriod.periodDescription != null)
            return false;
        if (news != null ? !news.equals(soxPeriod.news) : soxPeriod.news != null)
            return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = (periodId != null ? periodId.hashCode() : 0);;
        result = 31 * result + (periodDescription != null ? periodDescription.hashCode() : 0);
        result = 31 * result + (cycleOnly != null ? cycleOnly.hashCode() : 0);
        result = 31 * result + (currentPeriod != null ? currentPeriod.hashCode() : 0);
        result = 31 * result + (closedPeriod != null ? closedPeriod.hashCode() : 0);
        result = 31 * result + (news != null ? news.hashCode() : 0);
        return result;
    }

  @Override
  public String toString() {
    return "SoxPeriod{" +
            "periodId='" + periodId + '\'' +
            ", periodDescription='" + periodDescription + '\'' +
            ", cycleOnly='" + cycleOnly + '\'' +
            ", currentPeriod='" + currentPeriod + '\'' +
            ", closedPeriod='" + closedPeriod + '\'' +
            ", news='" + news + '\'' +
            '}';
  }
}