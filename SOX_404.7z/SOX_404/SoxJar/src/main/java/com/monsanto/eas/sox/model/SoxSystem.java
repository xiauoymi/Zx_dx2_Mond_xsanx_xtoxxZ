package com.monsanto.eas.sox.model;

import javax.persistence.*;

@Entity
@Table(schema = "SARBOX_ET", name = "SYSTEM")
@NamedQueries({
        @NamedQuery(name = "lookupSystemByDescription", query = "FROM SoxSystem s WHERE s.description like :description"),
        @NamedQuery(name = "lookupAllSoxSystems", query = "FROM SoxSystem s ORDER BY s.description")
})


public class SoxSystem {
    @javax.persistence.Column(name = "SYSTEM_ID", nullable = false, insertable = true, updatable = true, length = 22, precision = 0)
    @Id
    private int systemId;

    @javax.persistence.Column(name = "DESCRIPTION", nullable = true, insertable = true, updatable = true, length = 250, precision = 0)
    @Basic
    private String description;

    public int getSystemId() {
        return systemId;
    }

    public void setSystemId(int systemId) {
        this.systemId = systemId;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        SoxSystem soxSystem = (SoxSystem) o;

        if (systemId != soxSystem.systemId) return false;
        if (description != null ? !description.equals(soxSystem.description) : soxSystem.description != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = systemId;
        result = 31 * result + (description != null ? description.hashCode() : 0);
        return result;
    }

}
