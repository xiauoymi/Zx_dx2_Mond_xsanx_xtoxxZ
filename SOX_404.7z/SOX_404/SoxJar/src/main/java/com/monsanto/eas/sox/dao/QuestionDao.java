package com.monsanto.eas.sox.dao;

import com.monsanto.eas.sox.model.SoxQuestion;

import java.util.Collection;

public interface QuestionDao extends GenericDao<SoxQuestion>{
    Collection<SoxQuestion> lookupQuestionsForEntity(String entityType);
    Collection<SoxQuestion> lookupAllQuestions();
}
