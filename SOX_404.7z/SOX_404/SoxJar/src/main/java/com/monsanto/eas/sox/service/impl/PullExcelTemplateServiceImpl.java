package com.monsanto.eas.sox.service.impl;

import com.monsanto.eas.sox.model.ExportExcelTemplateVO;
import com.monsanto.eas.sox.model.SoxControlEntity;
import com.monsanto.eas.sox.service.ControlEntityService;
import com.monsanto.eas.sox.service.ExportExcelTemplate;
import com.monsanto.eas.sox.service.ExportTeamMateExcelTemplate;
import com.monsanto.eas.sox.service.PullExcelTemplateService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.flex.remoting.RemotingDestination;
import org.springframework.stereotype.Service;

import java.util.Collection;

@Service
@RemotingDestination(value = "pullExcelTemplateService")
public class PullExcelTemplateServiceImpl implements PullExcelTemplateService {

   @Autowired
   ExportExcelTemplate exportExcelTemplate;

   @Autowired
   ExportTeamMateExcelTemplate exportTeamMateExcelTemplate;

   @Autowired
   private ControlEntityService controlEntityService;


   @Override
   public ExportExcelTemplateVO getExcelTemplate(String periodId, String countryId, String cycleId) {
      ExportExcelTemplateVO exportExcelTemplateVO = null;
      try {
         Collection<SoxControlEntity> activities = controlEntityService.getActivities(periodId, countryId, cycleId);
         exportExcelTemplateVO = exportExcelTemplate.exportTemplate(periodId, countryId, cycleId, activities);
      } catch (Exception ex) {
         exportExcelTemplateVO = new ExportExcelTemplateVO();
         exportExcelTemplateVO.setRetrievalSuccessful(false);
         exportExcelTemplateVO.setRetrievalStatusDescription(ex.getMessage());

         ex.printStackTrace();
      }
      return exportExcelTemplateVO;
   }

   @Override
   public ExportExcelTemplateVO getTeamMateExcelTemplate(String periodId, String countryId, String cycleId) {
      ExportExcelTemplateVO exportExcelTemplateVO = new ExportExcelTemplateVO();
      exportExcelTemplateVO.setRetrievalSuccessful(false);

      try {
         Collection<SoxControlEntity> activities = controlEntityService.getActivities(periodId, countryId, cycleId);

         if (activities != null && activities.size() > 0) {
            exportExcelTemplateVO = exportTeamMateExcelTemplate.exportTemplate(periodId, countryId, cycleId, activities);
         }

      } catch (Exception ex) {
         exportExcelTemplateVO.setRetrievalStatusDescription(ex.getMessage());

         ex.printStackTrace();
      }
      return exportExcelTemplateVO;
   }
}
