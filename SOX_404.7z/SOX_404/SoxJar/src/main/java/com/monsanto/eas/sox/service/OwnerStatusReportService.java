package com.monsanto.eas.sox.service;

import com.monsanto.eas.sox.exception.InvalidUserException;
import com.monsanto.eas.sox.model.OwnerStatusReportVO;

import java.util.Collection;

public interface OwnerStatusReportService {
    Collection<OwnerStatusReportVO> getOwnerStatusReport(String periodId) throws InvalidUserException;
}
