package com.monsanto.eas.sox.jaxb;

import com.google.common.base.Joiner;
import com.monsanto.eas.sox.model.*;
import com.monsanto.eas.sox.util.SoxConstants;

import java.util.*;

public class ActivityValidationAdp {
    public final static String DELIMITER = "\n";

    private Joiner joiner = Joiner.on(", ").skipNulls();

    public List<ActivityValidation> getActivityValidationsFromSoxControlEntity(SoxControlEntity cycle) {
        List<ActivityValidation> activityValidationList = new ArrayList<ActivityValidation>();

        if (cycle != null && cycle.getChildControlEntities() != null) {
            for (SoxControlEntity subCycle : cycle.getChildControlEntities()) {

                String subCycleEntityOwnerMap = parseSubCycleOwners(subCycle.getSoxControlEntityOwners());

                for (SoxControlEntity activity : subCycle.getChildControlEntities()) {
                    ActivityValidation validation = new ActivityValidation();

                    validation.setControlId(activity.getControlEntityId());
                    validation.setCycle(cycle.getDescription());

                    validation.setCountry(parseCountries(activity));

                    validation.setSubcycle(subCycle.getDescription());
                    validation.setSubcycleOwner(subCycleEntityOwnerMap);

                    validation.setControl(activity.getDescription());
                    validation.setControlOwner(parseOwners(activity));

                    updateAssertionsOnActivityValidation(activity, validation);
                    updateControlAttributes(activity, validation);

                    activityValidationList.add(validation);
                }
            }
        }

        return activityValidationList;
    }

    private String parseSubCycleOwners(Set<SoxControlEntityOwner> soxControlEntityOwners) {
        List<String> owners = new ArrayList<String>();

        if (soxControlEntityOwners != null) {
            for (SoxControlEntityOwner soxControlEntityOwner : soxControlEntityOwners) {
                if (soxControlEntityOwner.getSoxOwner() != null) {
                    owners.add(soxControlEntityOwner.getSoxOwner().getUserId());
                }
            }
        }

        return joiner.join(owners);
    }

    private void updateAssertionsOnActivityValidation(SoxControlEntity soxControlEntity, ActivityValidation validation) {

        validation.setExistence("");
        validation.setCompleteness("");
        validation.setValuation("");
        validation.setRight("");
        validation.setPresentation("");

        if (soxControlEntity.getSoxCtrlActivityEntities() != null) {
            for (SoxCtrlActivityEntity activity : soxControlEntity.getSoxCtrlActivityEntities()) {
                if (activity.getSoxCtrlActivityAssertions() != null) {
                    for (SoxCtrlActivityAssertion assertion : activity.getSoxCtrlActivityAssertions()) {
                        if (assertion.getAssertion() != null && assertion.getAssertion().getDescription() != null) {
                            if (assertion.getAssertion().getDescription().equals(SoxConstants.ASSERTION_EXISTENCE_OR_OCCURRENCE)) {
                                validation.setExistence("X");
                            } else if (assertion.getAssertion().getDescription().equals(SoxConstants.ASSERTION_COMPLETENESS)) {
                                validation.setCompleteness("X");
                            } else if (assertion.getAssertion().getDescription().equals(SoxConstants.ASSERTION_VALUATION_AND_ALLOCATION)) {
                                validation.setValuation("X");
                            } else if (assertion.getAssertion().getDescription().equals(SoxConstants.ASSERTION_RIGHT_AND_OBLIGATION)) {
                                validation.setRight("X");
                            } else if (assertion.getAssertion().getDescription().equals(SoxConstants.ASSERTION_PRESENTATION_AND_DISCLOSURE)) {
                                validation.setPresentation("X");
                            }
                        }
                    }
                }
            }
        }
    }

    private void updateControlAttributes(SoxControlEntity soxControlEntity, ActivityValidation validation) {

        validation.setControlType("");
        validation.setFrequency("");
        validation.setSystem("");
        validation.setPrevent("");
        validation.setFraud("");
        validation.setKey("");

        if (soxControlEntity.getSoxCtrlActivityEntities() != null) {
            for (SoxCtrlActivityEntity activity : soxControlEntity.getSoxCtrlActivityEntities()) {
                if (activity.getTypeOfControl() != null && activity.getTypeOfControl().getDescription() != null) {
                    validation.setControlType(activity.getTypeOfControl().getDescription());
                }
                if (activity.getFrequency() != null && activity.getFrequency().getDescription() != null) {
                    validation.setFrequency(activity.getFrequency().getDescription());
                }
                if (activity.getSoxSystems() != null && !activity.getSoxSystems().isEmpty()) {
                    validation.setSystem(activity.getSoxSystemsAsString(DELIMITER));
                }
                if (activity.getPreventDetect() != null && activity.getPreventDetect().getDescription() != null) {
                    validation.setPrevent(activity.getPreventDetect().getDescription());
                }
                if (activity.getFraud() != null && activity.getFraud().getDescription() != null) {
                    validation.setFraud(activity.getFraud().getDescription());
                }
                if (activity.getKey() != null && activity.getKey().getDescription() != null) {
                    validation.setKey(activity.getKey().getDescription());
                }
            }

        }
    }

    private String parseCountries(SoxControlEntity activity) {
        Set<String> countries = new HashSet<String>();

        for (SoxCountry soxCountry : activity.getCountries()) {
            countries.add(soxCountry.getCountryDescription());
        }

        return joiner.join(countries);
    }

    private String parseOwners(SoxControlEntity activity) {
        Set<String> owners = new TreeSet<String>();

        for (SoxControlEntityOwner soxControlEntityOwner : activity.getSoxControlEntityOwners()) {
            SoxOwner soxOwner = soxControlEntityOwner.getSoxOwner();

            if (soxOwner != null) {
                owners.add(soxOwner.getUserId());
            }
        }

        return joiner.join(owners);
    }

}