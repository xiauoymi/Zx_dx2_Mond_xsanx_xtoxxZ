package com.monsanto.eas.sox.model;

import org.hibernate.annotations.Cascade;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.Collection;

@Table(name = "TYPE_OF_CONTROL", schema = "SARBOX_ET")
@Entity
@NamedQueries({
        @NamedQuery(name = "lookupTypeOfControlByDescription", query = "FROM TypeOfControl t WHERE t.description=:description")
})
public class TypeOfControl {
    @javax.persistence.Column(name = "TYPE_OF_CONTROL_ID", nullable = false, insertable = true, updatable = true, length = 22, precision = 0)
    @Id
    private int typeOfControlId;

    @javax.persistence.Column(name = "DESCRIPTION", nullable = true, insertable = true, updatable = true, length = 250, precision = 0)
    @Basic
    private String description;

    @OneToMany(mappedBy = "typeOfControl", fetch = FetchType.LAZY)
    @Cascade({org.hibernate.annotations.CascadeType.ALL})
    private Collection<SoxCtrlActivityEntity> soxCtrlActivityEntities= new ArrayList<SoxCtrlActivityEntity>();

    public int getTypeOfControlId() {
        return typeOfControlId;
    }

    public void setTypeOfControlId(int typeOfControlId) {
        this.typeOfControlId = typeOfControlId;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Collection<SoxCtrlActivityEntity> getSoxCtrlActivityEntities() {
        return soxCtrlActivityEntities;
    }

    public void setSoxCtrlActivityEntities(Collection<SoxCtrlActivityEntity> soxCtrlActivityEntities) {
        this.soxCtrlActivityEntities = soxCtrlActivityEntities;
    }

    public void addSoxCtrlActivityEntity(SoxCtrlActivityEntity soxCtrlActivityEntity){
        if(soxCtrlActivityEntity != null) {
            soxCtrlActivityEntity.setTypeOfControl(this);
            soxCtrlActivityEntities.add(soxCtrlActivityEntity);
        }
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        TypeOfControl that = (TypeOfControl) o;

        if (typeOfControlId != that.typeOfControlId) return false;
        if (description != null ? !description.equals(that.description) : that.description != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = typeOfControlId;
        result = 31 * result + (description != null ? description.hashCode() : 0);
        return result;
    }
}
