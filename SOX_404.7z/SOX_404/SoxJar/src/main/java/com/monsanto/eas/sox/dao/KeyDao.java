package com.monsanto.eas.sox.dao;

import com.monsanto.eas.sox.model.Key;

public interface KeyDao extends GenericDao<Key>{
    Key lookupKeyByDescription(String description);
}
