package com.monsanto.eas.sox.service;

import com.monsanto.eas.sox.model.SoxControlEntityOwner;
import com.monsanto.eas.sox.model.SoxEntityOwnershipVO;

import java.util.Collection;

public interface ControlEntityOwnerService {

    void deleteSoxControlEntityOwnerWithoutReferences();

    SoxControlEntityOwner saveOrUpdate(SoxControlEntityOwner soxControlEntityOwner);

    Collection<SoxEntityOwnershipVO> getCycleOwnership(String userId);
    Collection<SoxEntityOwnershipVO> getSubCycleOwnership(String userId);
    Collection<SoxEntityOwnershipVO> getActivityOwnership(String userId);
    Collection<String> getEditableCycles();
    Collection<SoxEntityOwnershipVO> getAllCycles();
    Collection<SoxEntityOwnershipVO> getAllSubcycles();
    Collection<SoxEntityOwnershipVO> getSubCyclesForACycle(String cycle);
    Collection<SoxEntityOwnershipVO> getActivitiesForACycleSubCycle(String cycle, String subCycle);
}
