package com.monsanto.eas.sox.service.impl;

import com.monsanto.eas.sox.dao.AdminLogDao;
import com.monsanto.eas.sox.dao.ControlEntityDao;
import com.monsanto.eas.sox.dao.PeriodDao;
import com.monsanto.eas.sox.model.DependentOverdueEntityVO;
import com.monsanto.eas.sox.model.SOXPeriodWithCycleTemplateDataVO;
import com.monsanto.eas.sox.model.SoxAdminLog;
import com.monsanto.eas.sox.model.SoxEntityTrackLogVO;
import com.monsanto.eas.sox.service.CertificationMessagesService;
import com.monsanto.eas.sox.service.ControlEntityService;
import com.monsanto.eas.sox.service.SOXEntityTrackLogService;
import com.monsanto.eas.sox.service.SampleEmailNotificationService;
import com.monsanto.eas.sox.util.EmailNotificationType;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class SOXEntityTrackLogServiceImpl implements SOXEntityTrackLogService {

    public final static String DELETE_TRANSACTION = "DELETE";
    public final static String UPDATE_TRANSACTION = "UPDATE";
    public final static String ADD_TRANSACTION = "ADD";

    @Autowired
    AdminLogDao adminLogDao;

    @Autowired
    ControlEntityDao controlEntityDao;

    @Autowired
    PeriodDao periodDao;

    @Autowired
    private CertificationMessagesService certificationMessagesService;

    @Autowired
    private SampleEmailNotificationService sampleEmailNotificationService;

    @Autowired
    ControlEntityService controlEntityService;

    Logger logger = Logger.getLogger(getClass().getName());

    @Override
    public void trackUpdateEntityOwners(String controlEntityId, String originalOwner, String newOwner, String userId) {
        saveAdminLogs(createSpecificAdminLogForOwnerProperty(newOwner, originalOwner, "Activities Owner", originalOwner, newOwner, controlEntityId, userId));
    }

    @Override
    public void trackUpdateEntity(Map<String, SoxEntityTrackLogVO> soxModifiedEntityTrackLogVOMap, String userId) {

        logger.info("trying update");
        //Iterate over collection
        for (SoxEntityTrackLogVO soxEntityTrackLogVO : soxModifiedEntityTrackLogVOMap.values()) {

            for (SoxAdminLog currAdminLog : getModified(soxEntityTrackLogVO, userId)) {
                if (currAdminLog != null) {
                    logger.info(currAdminLog.getModification());
                    saveAdminLogs(currAdminLog);
                }
            }
        }
    }


    @Override
    public void trackDeleteEntity(List<SOXPeriodWithCycleTemplateDataVO> soxPeriodWithCycleTemplateDataVOList, String userId) {
        String currPeriod = periodDao.lookupCurrentPeriod().getPeriodId();
        logger.info("trying delete");
        //Iterate over collection
        for (SOXPeriodWithCycleTemplateDataVO currVo : soxPeriodWithCycleTemplateDataVOList) {
            if (currVo.isDeleteThisControl()) {
                String[] cycesubControl = currVo.getControlId().split("\\.");
                String parentControlId = cycesubControl.length > 2 ? (cycesubControl[0] + "." + cycesubControl[1]) : cycesubControl[0];
                sendUncertifyNotice(currPeriod + "." + currVo.getControlId(), currPeriod + "." + parentControlId);
                saveAdminLogs(createSoxAdminLog(DELETE_TRANSACTION, currVo.getControlId(), currVo.getControlOwner(), currVo.getControlOwner(), userId, ""));
            }
        }
    }

    @Override
    public void trackAddEntity(List<SOXPeriodWithCycleTemplateDataVO> soxPeriodWithCycleTemplateDataVOList, String userId) {
        logger.info("trying add");
        //Iterate over collection
        for (SOXPeriodWithCycleTemplateDataVO currVo : soxPeriodWithCycleTemplateDataVOList) {
            if (currVo.isAddedThisControl()) {
                saveAdminLogs(createSoxAdminLog(ADD_TRANSACTION, currVo.getControlId(), currVo.getControlOwner(), currVo.getControlOwner(), userId, ""));
            }

        }
    }

    private void saveAdminLogs(SoxAdminLog soxAdminLog) {
        try {
            if (soxAdminLog.getOwner() != null && !soxAdminLog.getOwner().equals("")) {
                //String[] ownersArray = soxAdminLog.getOwner().split(",");
                //soxAdminLog.setOwner(ownersArray[0]);
                adminLogDao.save(soxAdminLog);
            }
        } catch (Exception e) {
            throw new RuntimeException("There was a problem saving the logs for this transaction", e);
        }
    }


    private List<SoxAdminLog> getModified(SoxEntityTrackLogVO soxEntityTrackLogVO, String userId) {
        List<SoxAdminLog> soxAdminLogs = new ArrayList<SoxAdminLog>();

        SOXPeriodWithCycleTemplateDataVO controlNewVo = soxEntityTrackLogVO.getNewSOXTemplateVO();
        SOXPeriodWithCycleTemplateDataVO controlOldVo = soxEntityTrackLogVO.getOriginalSOXTemplateVO();

        soxAdminLogs.add(createSpecificAdminLogForOwnerProperty(controlNewVo.getActivitiesOwner(), controlOldVo.getActivitiesOwner(), "Activities Owner",
                controlOldVo.getActivitiesOwner(), controlNewVo.getActivitiesOwner(), controlOldVo.getBaseCycleId(), userId));

        String subCycleId = controlOldVo.getControlId().substring(0, controlOldVo.getControlId().lastIndexOf('.'));

        soxAdminLogs.add(createSpecificAdminLogForOwnerProperty(controlNewVo.getSubcycleOwner(), controlOldVo.getSubcycleOwner(), "Sub Cycle Owner",
                controlOldVo.getSubcycleOwner(), controlNewVo.getSubcycleOwner(), subCycleId, userId));

        soxAdminLogs.add(createSpecificAdminLogForOwnerProperty(controlNewVo.getControlOwner(), controlOldVo.getControlOwner(), "Control Owner",
                controlOldVo.getControlOwner(), controlNewVo.getControlOwner(), controlOldVo.getControlId(), userId));

        //soxAdminLogs.add(createSpecificAdminLogForProperty(controlNewVo.getActivitiesOwner(), controlOldVo.getActivitiesOwner(), "Activities Owner", controlNewVo, userId));

        soxAdminLogs.add(createSpecificAdminLogForProperty(controlNewVo.getCountry(),        controlOldVo.getCountry(),        "Country", controlNewVo, userId));
        soxAdminLogs.add(createSpecificAdminLogForProperty(controlNewVo.getCycle(),          controlOldVo.getCycle(),          "Cycle", controlNewVo, userId));
        soxAdminLogs.add(createSpecificAdminLogForProperty(controlNewVo.getSubcycle(),       controlOldVo.getSubcycle(),       "Sub Cycle", controlNewVo, userId));
        //soxAdminLogs.add(createSpecificAdminLogForProperty(controlNewVo.getSubcycleOwner(),  controlOldVo.getSubcycleOwner(),  "Sub Cycle Owner", controlNewVo, userId));

        soxAdminLogs.add(createSpecificAdminLogForProperty(controlNewVo.isExistenceOfOccurrenceAssertion(),     controlOldVo.isExistenceOfOccurrenceAssertion(),     "Existence Of Occurrence Assertion", controlNewVo, userId));
        soxAdminLogs.add(createSpecificAdminLogForProperty(controlNewVo.isCompletenessAssertion(),              controlOldVo.isCompletenessAssertion(),              "Completeness Assertion", controlNewVo, userId));
        soxAdminLogs.add(createSpecificAdminLogForProperty(controlNewVo.isValuationAndAllocationAssertion(),    controlOldVo.isValuationAndAllocationAssertion(),    "Valuation And Allocation Assertion", controlNewVo, userId));
        soxAdminLogs.add(createSpecificAdminLogForProperty(controlNewVo.isRightAndObligationAssertion(),        controlOldVo.isRightAndObligationAssertion(),        "Right And Obligation Assertion", controlNewVo, userId));
        soxAdminLogs.add(createSpecificAdminLogForProperty(controlNewVo.isPresentationAndDisclosureAssertion(), controlOldVo.isPresentationAndDisclosureAssertion(), "Presentation And Disclosure Assertion", controlNewVo, userId));

        soxAdminLogs.add(createSpecificAdminLogForProperty(controlNewVo.getRisk(),         controlOldVo.getRisk(),         "Risk",      controlNewVo, userId));
        soxAdminLogs.add(createSpecificAdminLogForProperty(controlNewVo.getControl(),      controlOldVo.getControl(),      "Control",   controlNewVo, userId));
        //soxAdminLogs.add(createSpecificAdminLogForProperty(controlNewVo.getControlOwner(), controlOldVo.getControlOwner(), "Control Owner", controlNewVo, userId));
        soxAdminLogs.add(createSpecificAdminLogForProperty(controlNewVo.getControlType(),  controlOldVo.getControlType(),  "Type of Control",   controlNewVo, userId));
        soxAdminLogs.add(createSpecificAdminLogForProperty(controlNewVo.getFrequency(),    controlOldVo.getFrequency(),    "Frequency",         controlNewVo, userId));
        soxAdminLogs.add(createSpecificAdminLogForProperty(controlNewVo.getSystem(),       controlOldVo.getSystem(),       "System",            controlNewVo, userId));
        soxAdminLogs.add(createSpecificAdminLogForProperty(controlNewVo.getPrevent(),      controlOldVo.getPrevent(),      "Prevent / Detect",  controlNewVo, userId));
        soxAdminLogs.add(createSpecificAdminLogForProperty(controlNewVo.getFraud(),        controlOldVo.getFraud(),        "Fraud",             controlNewVo, userId));
        soxAdminLogs.add(createSpecificAdminLogForProperty(controlNewVo.getKey(),          controlOldVo.getKey(),          "Key",               controlNewVo, userId));

        return soxAdminLogs;
    }

    private SoxAdminLog createSpecificAdminLogForOwnerProperty(String newValue, String oldValue, String columnName, String originalOwner, String newOwner, String controlId, String userId) {
        if(newValue == null && oldValue == null){
            return null;
        }
        if (newValue == null && oldValue != null) {
            return createSoxAdminLog(DELETE_TRANSACTION, controlId, newOwner, newOwner, userId, columnName + "\n");
        }
        if (!newValue.equalsIgnoreCase(oldValue)) {
            if (newValue.equalsIgnoreCase("")) {
                return createSoxAdminLog(DELETE_TRANSACTION, controlId, newOwner, newOwner, userId, columnName + "\n");
            } else if (oldValue == null || oldValue.equalsIgnoreCase("")) {
                return createSoxAdminLog(ADD_TRANSACTION, controlId, newOwner, newOwner, userId, columnName + "\nNEW:\n" + newValue);
            } else {
                return createSoxAdminLog(UPDATE_TRANSACTION, controlId, originalOwner, newOwner, userId, columnName + "\nOLD:\n " + oldValue + "\nNEW:\n" + newValue);
            }
        }
        return null;
    }


    private SoxAdminLog createSpecificAdminLogForProperty(String newValue, String oldValue, String columnName, SOXPeriodWithCycleTemplateDataVO controlNewVo, String userId) {
        String newControlOwner = controlNewVo.getControlOwner();
        String controlEntityId = controlNewVo.getControlId();

        return createSpecificAdminLogForOwnerProperty( newValue, oldValue, columnName, newControlOwner, newControlOwner, controlEntityId, userId);
    }

    private SoxAdminLog createSpecificAdminLogForProperty(boolean newValue, boolean oldValue, String columnName, SOXPeriodWithCycleTemplateDataVO controlNewVo, String userId) {
        String newControlOwner = controlNewVo.getControlOwner();
        String controlEntityId = controlNewVo.getControlId();

        if (newValue != oldValue) {
            return createSoxAdminLog(UPDATE_TRANSACTION, controlEntityId, newControlOwner, newControlOwner, userId, columnName + "\nOLD:\n " + (oldValue ? "Yes" : "No") + "\nNEW:\n" + (newValue ? "Yes" : "No"));
        }

        return null;
    }

    private SoxAdminLog createSoxAdminLog(String transaction, String controlEntityId, String originalOwner, String newOwner, String modUser, String modification) {
        String currPeriod = periodDao.lookupCurrentPeriod().getPeriodId();

        SoxAdminLog adminLog = new SoxAdminLog();
        adminLog.setTransaction(transaction);
        adminLog.setControlEntityId(currPeriod + "." + controlEntityId);

        adminLog.setOwner(originalOwner);
        adminLog.setNewOwner(newOwner);

        adminLog.setModDate(new Date());
        adminLog.setModUser(modUser);
        adminLog.setModification(controlEntityId + "\n" + modification);
        return adminLog;
    }

    private void sendUncertifyNotice(String controlEntityId, String parentId) {
        Date currentDate = getCurrentDate();
        Collection<DependentOverdueEntityVO> otherChilds = controlEntityDao.lookupCertifiedOwnersForAnEntityWithoutDateRestriction(parentId);
        try {
            ArrayList<DependentOverdueEntityVO> onlyOnesToUncertify = new ArrayList<DependentOverdueEntityVO>();
            for (DependentOverdueEntityVO dependentOverdueEntityVO : otherChilds) {
                if (dependentOverdueEntityVO.getControlEntityId().equalsIgnoreCase(controlEntityId)) {
                    onlyOnesToUncertify.add(dependentOverdueEntityVO);
                }
            }
            certificationMessagesService.sendUncertifyNotice(sampleEmailNotificationService.getEmailNotificationTemplate(EmailNotificationType.UNCERTIFY.getCode()), onlyOnesToUncertify);

        } catch (Exception e) {
            logger.info("", e);
            throw new RuntimeException("There was an error sending the un-certifying notice", e);
        }
    }


    public void sendUncertifyNotice(Collection<DependentOverdueEntityVO> otherChilds, String controlEntityId, String parentId) {
        try {
            ArrayList<DependentOverdueEntityVO> onlyOnesToUncertify = new ArrayList<DependentOverdueEntityVO>();
            for (DependentOverdueEntityVO dependentOverdueEntityVO : otherChilds) {
                if (dependentOverdueEntityVO.getControlEntityId().equalsIgnoreCase(controlEntityId)) {
                    onlyOnesToUncertify.add(dependentOverdueEntityVO);
                }
            }
            certificationMessagesService.sendUncertifyNotice(sampleEmailNotificationService.getEmailNotificationTemplate(EmailNotificationType.UNCERTIFY.getCode()), onlyOnesToUncertify);

        } catch (Exception e) {
            logger.info("", e);
            throw new RuntimeException("There was an error sending the un-certifying notice", e);
        }
    }

    private Date getCurrentDate() {
        Calendar calendar = new GregorianCalendar();
        calendar.set(Calendar.HOUR_OF_DAY, 0);
        calendar.set(Calendar.MINUTE, 0);
        calendar.set(Calendar.SECOND, 0);
        calendar.set(Calendar.MILLISECOND, 0);

        return calendar.getTime();
    }

}
