package com.monsanto.eas.sox.dao;

import com.monsanto.eas.sox.model.SoxCtrlActivityAssertion;

public interface SoxCtrlActivityAssertionDao extends GenericDao<SoxCtrlActivityAssertion> {
}
