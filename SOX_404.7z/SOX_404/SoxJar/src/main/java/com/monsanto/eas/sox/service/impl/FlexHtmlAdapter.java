package com.monsanto.eas.sox.service.impl;

public class FlexHtmlAdapter {
    private String getDebugMessage(StringBuffer buffer, int pos, String tag){
          int endPos;
          StringBuffer line = new StringBuffer("EOF");

          pos = pos + tag.length();
          endPos= pos + 20;
          if (endPos > buffer.length()){
             endPos = buffer.length();
          }
          if (pos < buffer.length() && endPos < buffer.length()){
            line = new StringBuffer(buffer.substring(pos, endPos));
          }
          for (int i=0; i < line.length(); i++){
            if (line.charAt(i) < 32){
              line.replace(i,i+1," ");
            }
          }

          return line.toString();
    }

    public String removeFlexUnneededTags(String flexHtml, String[][] unneededTags) {
        StringBuffer buffer = new StringBuffer(flexHtml);
        int START_TAG = 0;
        int END_TAG = 1;
        int REPLACEMENT_TAG = 2;
        int pos;
        int endPos;
        String currentTag;
        for (String[] unneededTag : unneededTags) {
          pos = unneededTag[START_TAG].indexOf(" ");
          if (pos == -1) {
            pos = unneededTag[START_TAG].length();
          }
          currentTag = unneededTag[START_TAG].toUpperCase().substring(0, pos);
          while ((pos = buffer.toString().toUpperCase().indexOf(unneededTag[START_TAG].toUpperCase())) != -1) {
            buffer = buffer.delete(pos, pos + unneededTag[START_TAG].length());
            endPos = pos;
            if (unneededTag[END_TAG] != null){
              endPos = buffer.toString().toUpperCase().indexOf(unneededTag[END_TAG].toUpperCase(), pos);
              pos = pos-1 < 0 ? 0 : pos -1;
              while ((pos = buffer.toString().toUpperCase().indexOf(currentTag, pos + 1)) != -1 && pos < endPos) {
                endPos = buffer.toString().toUpperCase().indexOf(unneededTag[END_TAG].toUpperCase(), endPos+1);
                pos = endPos + unneededTag[END_TAG].length();
              }
              buffer.delete(endPos, endPos + unneededTag[END_TAG].length());
            }
            if (unneededTag[REPLACEMENT_TAG] != null) {
              if (endPos >= buffer.length()) {
                buffer.append(unneededTag[REPLACEMENT_TAG]);
              } else {
                buffer.insert(endPos, unneededTag[REPLACEMENT_TAG]);
              }
            }
          }
        }

        return buffer.toString();
    }
}