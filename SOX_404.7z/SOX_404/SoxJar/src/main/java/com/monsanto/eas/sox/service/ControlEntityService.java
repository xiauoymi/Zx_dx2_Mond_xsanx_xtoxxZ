package com.monsanto.eas.sox.service;

import com.monsanto.eas.sox.exception.InvalidUserException;
import com.monsanto.eas.sox.model.*;

import java.util.Collection;
import java.util.List;

public interface ControlEntityService {
    String deleteSoxControlEntity(String cycleId);

    String deleteCtrlEntityDependencies(String cycleId);

    SoxControlEntity lookupSoxControlEntityByControlId(String controlId);

    SoxControlEntity saveOrUpdate(SoxControlEntity soxControlEntity, List<SoxControlEntityRelationship> controlEntityRelationships);

    SoxControlEntity saveOrUpdate(SoxControlEntity soxControlEntity);

    Collection<SoxControlEntity> getAllCycles();

    Collection<DependentOverdueEntityVO> getChildsForAnEntity(String controlEntityId) throws InvalidUserException;

    Collection<SoxControlEntity> getCyclesByOwner(String userId);

    Collection<SoxControlEntity> getSubCyclesByOwnerAndCycle(String userId, String cycleId);

    Collection<SoxControlEntity> getActivitiesByOwnerAndSubCycle(String userId, String subCycleId);

    Collection<SoxControlEntity> getActivities(String periodId, String countryId, String cycleId);

    Collection<SoxControlEntity> getActivitiesByCycle(String periodId, String cycleId);

    Collection<SoxControlEntity> getActivitiesByCountry(String periodId, String countryId);

    Collection<SoxControlEntity> getActivitiesByCountryAndCycle(String periodId, String countryId, String cycleId);

    Collection<RelatedActivityVO> getActivitiesDifferentFromSelectedCycle(String controlEntityId);

    Collection<SoxControlEntity> getCyclesByPeriod(String periodId);

    Collection<SoxControlEntity> getEntitiesNotCertifiedForUser(String userId);

    Collection<SoxControlEntityOwner> getControlEntityOwnerByControlEntityId(String entityId);

    String getActivityOwners(Collection<SoxControlEntityOwner> controlEntityOwnerCollection);

    String getActivityOwners(SoxControlEntity activity);

    String getCountries(SoxControlEntity activity);

    String getSoxSystems(SoxCtrlActivityEntity ctrlActivityEntity);

    Collection<DependentOverdueEntityVO> lookupCertifiedOwnersForAnEntityWithoutDateRestriction(String controlEntityId);

    void uncertifyEntity(String controlEntityId, String parentId);

    void uncertifyEntity(Collection<DependentOverdueEntityVO> otherChilds);
}
