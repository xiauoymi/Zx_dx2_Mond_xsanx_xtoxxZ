package com.monsanto.eas.sox.dao;

import com.monsanto.eas.sox.model.Frequency;

import java.util.Collection;

public interface FrequencyDao extends GenericDao<Frequency>{
    Frequency lookupFrequencyByDescription(String description);
    Collection<Frequency> lookupAllFrequencies();
}
