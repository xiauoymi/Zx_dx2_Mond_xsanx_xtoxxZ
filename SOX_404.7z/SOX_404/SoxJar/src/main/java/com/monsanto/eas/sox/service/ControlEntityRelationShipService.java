package com.monsanto.eas.sox.service;

import com.monsanto.eas.sox.model.SoxControlEntityRelationship;

import java.util.Collection;

public interface ControlEntityRelationShipService {

    void deleteSoxControlEntityRelationship(int relationshipId);

    SoxControlEntityRelationship saveOrUpdate(SoxControlEntityRelationship soxControlEntityRelationship);

    Collection<SoxControlEntityRelationship> getRelatedActivitiesByCycle(String cycleId);

}
