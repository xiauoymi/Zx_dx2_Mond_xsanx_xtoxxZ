package com.monsanto.eas.sox.service;

import com.monsanto.eas.sox.model.SoxBusinessType;

import java.util.Collection;

public interface BusinessTypeService {

    Collection<SoxBusinessType> getAllBusinessType();
}
