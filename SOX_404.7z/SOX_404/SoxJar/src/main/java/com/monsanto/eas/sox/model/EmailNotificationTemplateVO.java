package com.monsanto.eas.sox.model;

public class EmailNotificationTemplateVO {
    private String recipient;
    private String notificationType;
    private String subject;
    private String body;
    private String tlfTemplate;

    private String errorMsg;

    public EmailNotificationTemplateVO() {
      super();
    }

    public EmailNotificationTemplateVO(String errorMsg) {
      super();
      this.errorMsg = errorMsg;
    }

    public String getRecipient() {
      return recipient;
    }

    public void setRecipient(String recipient) {
      this.recipient = recipient;
    }

    public String getNotificationType() {
        return notificationType;
    }

    public void setNotificationType(String notificationType) {
      this.notificationType = notificationType;
    }

    public String getSubject() {
      return subject;
    }

    public void setSubject(String subject) {
      this.subject = subject;
    }

    public String getBody() {
      return body;
    }

    public void setBody(String body) {
      this.body = body;
    }

    public String getTlfTemplate() {
      return tlfTemplate;
    }

    public void setTlfTemplate(String tlfTemplate) {
      this.tlfTemplate = tlfTemplate;
    }

    public String getErrorMsg() {
      return errorMsg;
    }

    public void setErrorMsg(String errorMsg) {
      this.errorMsg = errorMsg;
    }

  @Override
    public String toString() {
      return "EmailNotificationTemplateVO{" +
              "recipient='" + recipient + '\'' +
              ", notificationType='" + notificationType + '\'' +
              ", subject='" + subject + '\'' +
              '}';
    }
}
