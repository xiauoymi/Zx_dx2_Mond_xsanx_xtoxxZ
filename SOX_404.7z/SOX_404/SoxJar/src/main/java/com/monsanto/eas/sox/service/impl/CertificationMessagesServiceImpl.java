package com.monsanto.eas.sox.service.impl;

import com.monsanto.eas.sox.context.ApplicationContextLoader;
import com.monsanto.eas.sox.dao.ControlEntityDao;
import com.monsanto.eas.sox.dao.PeriodDao;
import com.monsanto.eas.sox.model.*;
import com.monsanto.eas.sox.service.CertificationMessagesService;
import com.monsanto.eas.sox.service.ConfigService;
import com.monsanto.eas.sox.service.DateCalculationService;
import com.monsanto.eas.sox.service.EmailService;
import com.monsanto.eas.sox.util.ControlEntityType;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.net.URL;
import java.util.*;

@Service
public class CertificationMessagesServiceImpl implements CertificationMessagesService {
    public final static String DUE_DATE = "_dueDate";
    public final static String CONSTANT_START = "{#";
    public final static String CONSTANT_END = "}";
    public final static String CONSTANT_ENTITY_TYPE = "{#email.entity.type}";
    public final static String CONSTANT_NOTIFICATION_TYPE = "email.notification.type";
    public final static String CONSTANT_OWNER = "email.entity.owner";
    public final static String CONSTANT_PERIOD = "email.currentPeriod";
    public final static String CURRENT_ROW = "email.entityList";
    public final static String UNCERTIFY_ACTIVITY = "activity";
    private static final String NO_OWNERS_FOUND_MSG = " no owners found ";
    private Map<String, String> dictionary;
    private SoxPeriod currentPeriod = null;

    @Autowired
    DateCalculationService dateCalcService;

    @Autowired
    EmailService emailService;

    @Autowired
    ControlEntityDao controlEntityDao;

    @Autowired
    ConfigService configService;

    @Autowired
    PeriodDao periodDao;

    Logger logger = Logger.getLogger(getClass().getName());

    public CertificationMessagesServiceImpl() {
        super();
    }

    public CertificationMessagesServiceImpl(DateCalculationService dateCalcService, EmailService emailService, ControlEntityDao controlEntityDao, ConfigService configService, PeriodDao periodDao) {
        super();
        this.dateCalcService = dateCalcService;
        this.emailService = emailService;
        this.controlEntityDao = controlEntityDao;
        this.configService = configService;
        this.periodDao = periodDao;
    }

    private boolean isPeriodOpen() {
        boolean enabled = true;

        if (getCurrentPeriod() != null && getCurrentPeriod().getClosedPeriod() != null && getCurrentPeriod().getClosedPeriod().equals("1")){
            enabled = false;
        }

        return enabled;
    }

  @Override
    public void sendStartCertificationMessages(EmailNotificationTemplateVO emailNotificationTemplateVO) throws Exception {
    try {
        if (isPeriodOpen()){
            logger.debug("sendStartCertificationMessages started");
            SoxPeriod currentPeriod1 = getCurrentPeriod();
            Collection<SoxControlEntityOwner> owners = controlEntityDao.lookupCertificationsStarted(currentPeriod1);
            String subject = emailNotificationTemplateVO.getSubject();
            String body = emailNotificationTemplateVO.getBody();
            sendCertificationMessages(owners, subject, body, false);
        }
    } catch (Exception e) {
        logger.error(e);
    } finally {
        logger.debug("sendStartCertificationMessages ended");
    }
  }

    @Override
    public void sendReminderMessages(EmailNotificationTemplateVO emailNotificationTemplateVO) throws Exception {
      try {
          if (isPeriodOpen()){
              logger.debug("sendReminderMessages started ");
              sendCertificationMessages(controlEntityDao.lookupCertificationsToSendReminder(dateCalcService.calculateBusinessDate(),
                      getCurrentPeriod()), emailNotificationTemplateVO.getSubject(), emailNotificationTemplateVO.getBody(), false);
          }
      } catch (Exception e) {
          logger.error(e);
      } finally {
          logger.debug("sendReminderMessages ended");
      }
    }

    @Override
    public void sendEntityOwnersOverdueCertificationMessages(EmailNotificationTemplateVO emailNotificationTemplateVO) throws Exception{
      try {
          if (isPeriodOpen()){
              logger.debug("sendEntityOwnersOverdueCertificationMessages started ");
              Collection<SoxControlEntityOwner> owners = controlEntityDao.lookupEntityOwnersCertificationsOverdue(
                      getCurrentPeriod());
              String emailNotificationTemplateVOSubject = emailNotificationTemplateVO.getSubject();
              String body = emailNotificationTemplateVO.getBody();
              sendCertificationMessages(owners, emailNotificationTemplateVOSubject, body, false);
          }
      } catch (Exception e) {
          logger.error(e);
      } finally {
        logger.debug("sendEntityOwnersOverdueCertificationMessages ended");
      }
    }

    @Override
    public void sendEntityChildsOverdueCertificationMessages(EmailNotificationTemplateVO emailNotificationTemplateVO) throws Exception{
        if (isPeriodOpen()){
          sendCertificationMessages(controlEntityDao.lookupEntityChildsCertificationsOverdue(
                  getCurrentPeriod()), emailNotificationTemplateVO.getSubject(), emailNotificationTemplateVO.getBody(), true);
        }
    }

    @Override
        public void sendUncertifyNotice(EmailNotificationTemplateVO emailNotificationTemplateVO,Collection<DependentOverdueEntityVO> owners) throws Exception {
          logger.debug("uncertify notice started ");

            String email;

            if (owners != null && owners.size() != 0) {
                logger.debug(" owners found " + owners.size());
            }
            else {
                logger.debug(NO_OWNERS_FOUND_MSG);
            }


            for (DependentOverdueEntityVO owner : owners)
            {
                StringBuffer template = new StringBuffer(emailNotificationTemplateVO.getBody());
                //iterate over, get control, get user id
                String controlId = owner.getControlEntityId();
                String userId = owner.getUserId();
                addToDictionary(UNCERTIFY_ACTIVITY, controlId);
                email = replaceConstants(template, UNCERTIFY_ACTIVITY, getDictionary());
                //email=email+userId;

                  try {

                     String environment = ApplicationContextLoader.getEnvironment();

                     if(!environment.equals("prod")){
                        emailService.sendEmail("aoroz@monsanto.com,fjadan@monsanto.com,JJSPUR@monsanto.com", "controls.internal@monsanto.com", emailNotificationTemplateVO.getSubject() + " TEST environment", new StringBuffer(email), null);
                     }
                     else {
                        emailService.sendEmail( userId + "@monsanto.com", "controls.internal@monsanto.com", emailNotificationTemplateVO.getSubject(), new StringBuffer(email), null);
                     }

                  } catch (Exception e) {
                    logger.error(e);
                  }

            }
            logger.debug(" uncertify notice finished ");
        }

    private Map<String, String> getDictionary(){
        if (dictionary == null) {
            dictionary = configService.getDictionary("email.");
        }

        return dictionary;
    }

    private void addToDictionary(String parameter, String value){
         if (value != null){
            getDictionary().put(parameter, value);
         }
    }

    private SoxPeriod getCurrentPeriod(){
      if (currentPeriod == null) {
        currentPeriod = periodDao.lookupCurrentPeriod();
      }
      return currentPeriod;
    }

    private String generateRow(ControlEntityType entityType, String entityValueList, String entityDueDateList)
    {
        String row = "";

        row += "<table border=\"1\"><tr><td>&nbsp;</td><td><b>ID</b></td><td><b>Due Date</b></td></tr>";
        if (entityValueList != null && entityValueList.trim().length() != 0)
        {
            row += String.format("<tr><td><b>%1$s</b></td><td>%2$s</td><td>%3$s</td></tr>",
                    getDictionary().get("email." + entityType.name().toLowerCase() + ".table.type.label"),
                    entityValueList,
                    entityDueDateList
            );
        }
        row += "</table>";

        return row;
    }

    public void sendCertificationMessages(Collection<SoxControlEntityOwner> owners, String subject, String emailTemplate, boolean checkParentOwners) throws Exception {
        Map<String, Map<String, String>> ownerEntities = getMessagesByOwner(owners, checkParentOwners);

      logger.debug(" sendCertificationMessages started ");

        String email;

        if (owners != null && owners.size() != 0) {
            logger.debug(" owners found " + owners.size());
        }
        else {
            logger.debug(NO_OWNERS_FOUND_MSG);
        }

        dictionary = null;
        if (getCurrentPeriod() == null) {
            addToDictionary(CONSTANT_PERIOD, "");
        }
        else {
            addToDictionary(CONSTANT_PERIOD, getCurrentPeriod().getPeriodDescription());
        }

        for (String owner : ownerEntities.keySet())
        {
            StringBuffer template = new StringBuffer(emailTemplate);
            Map<String, String> currentOwnerMessages = ownerEntities.get(owner);
            addToDictionary(CONSTANT_OWNER, owner);

            for (ControlEntityType entityType : ControlEntityType.values())
            {
              try {
                if (currentOwnerMessages.get(entityType.name()) != null)
                {
                    addToDictionary(CURRENT_ROW,
                            generateRow(
                                            entityType,
                                            currentOwnerMessages.get(entityType.name()),
                                            currentOwnerMessages.get(entityType.name() + CertificationMessagesServiceImpl.DUE_DATE)
                                        )
                    );
                    email = replaceConstants(template, entityType.name().toLowerCase(), getDictionary());

                    if (owner != null && !owner.equalsIgnoreCase("NONE"))
                    {
                        String realSubject = replaceConstants(new StringBuffer(subject), entityType.name().toLowerCase(), getDictionary());

        // For testing
                    //emailService.sendEmail("VRBETHI@monsanto.com", "controls.internal@monsanto.com", realSubject, new StringBuffer(email), null);
//                    emailService.sendEmail("JJSPUR@monsanto.com", "controls.internal@monsanto.com", realSubject, new StringBuffer(email), null);
//                    emailService.sendEmail("SMENDOZ@monsanto.com", "controls.internal@monsanto.com", realSubject, new StringBuffer(email), null);
                    emailService.sendEmail(owner+"@monsanto.com", "controls.internal@monsanto.com", realSubject, new StringBuffer(email), null);
        // For testing
                    }
                }
              } catch (Exception e) {
                logger.error(e);
              }
            }
        }
    }

    private Map<String, Map<String, String>> getMessagesByOwner(Collection<SoxControlEntityOwner> owners, boolean checkParentOwners) {
        Map<String, Map<String, String>> ownerEntities = new HashMap<String, Map<String, String>>();
        Map<String, String> currentOwnerMessages = new HashMap<String, String>();
        Set<SoxControlEntityOwner> currentEntityOwners;

        try {
            for (SoxControlEntityOwner owner : owners)
            {
                ControlEntityType    entityType = ControlEntityType.getEntityType(owner.getSoxControlEntity());
                String dueDate = String.format("%1$tm/%1$te/%1$tY",owner.getSoxControlEntity().getEndDate());

                if (checkParentOwners)
                {
                     currentEntityOwners = owner.getSoxControlEntity().getParentControlEntity().getSoxControlEntityOwners();
                }
                else
                {
                    currentEntityOwners = new HashSet<SoxControlEntityOwner>();
                    currentEntityOwners.add(owner);
                }

                for (SoxControlEntityOwner currentEntityOwner : currentEntityOwners)
                {
                    currentOwnerMessages = ownerEntities.get(currentEntityOwner.getSoxOwner().getUserId());
                    if (currentOwnerMessages != null)
                    {
                       String currentEntityMessages = currentOwnerMessages.get(entityType.name());
                       String currentEntityDueDate = currentOwnerMessages.get(entityType.name()+DUE_DATE);
                       if (currentEntityMessages == null)
                       {
                           currentEntityMessages = owner.getSoxControlEntity().getControlEntityId();
                           currentEntityDueDate = dueDate;
                       }
                       else if (currentEntityMessages.indexOf(owner.getSoxControlEntity().getControlEntityId()) == -1)
                       {
                           currentEntityMessages += ",<br/>" + owner.getSoxControlEntity().getControlEntityId();
                           currentEntityDueDate += ",<br/>" + dueDate;
                       }
                       currentOwnerMessages.put(entityType.name(), currentEntityMessages);
                       currentOwnerMessages.put(entityType.name()+DUE_DATE, currentEntityDueDate);
                    }
                    else
                    {
                       currentOwnerMessages = new HashMap<String, String>();
                       currentOwnerMessages.put(entityType.name(), owner.getSoxControlEntity().getControlEntityId());
                       currentOwnerMessages.put(entityType.name()+DUE_DATE, dueDate);
                       ownerEntities.put(currentEntityOwner.getSoxOwner().getUserId(), currentOwnerMessages);
                    }
                }
            }
        } catch(RuntimeException rte) {
            logger.error(rte.getMessage(), rte);
        }
        return ownerEntities;
    }

    private List<String> getAttachments() throws Exception
    {
        ClassLoader loader = CertificationMessagesServiceImpl.class.getClassLoader();
        URL url;
        url = loader.getResource("Walkthrough.pptx");
        List<String> attachments = new ArrayList<String>();
//        attachments.add(url.getFile());
        attachments.add(System.getProperty("MONCRYPTJV") + "/sox/Walkthrough.pptx");

        return attachments;
    }

    private String getConfigProperty(String parameter)  {
        SoxConfig config = configService.lookupConfigByName(parameter);
        return config == null ? "" : config.getParameterValue();
    }

    public String replaceConstants(StringBuffer template, String entityType, Map<String, String> dictionary) {
        int pos;
        int end;
        String constantName;
        String constantValue;
        while ((pos = template.indexOf(CONSTANT_ENTITY_TYPE)) != -1) {
            template = template.replace(pos, pos + CONSTANT_ENTITY_TYPE.length(), entityType.toLowerCase());
        }
        while ((pos = template.indexOf(CONSTANT_START)) != -1) {
            end = template.indexOf(CONSTANT_END, pos);
            if (pos != -1 && end != -1 && end > pos){
                constantName = template.substring(pos + CONSTANT_START.length(), end);
                constantValue = dictionary.get(constantName) == null ? "" : dictionary.get(constantName);
                template = template.replace(pos, end +CONSTANT_END.length(), constantValue);
            }
        }

        return template.toString();
    }

    public void setControlEntityDao(ControlEntityDao controlEntityDao) {
        this.controlEntityDao = controlEntityDao;
    }
}
