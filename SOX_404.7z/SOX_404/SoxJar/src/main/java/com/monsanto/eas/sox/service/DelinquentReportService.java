package com.monsanto.eas.sox.service;

import com.monsanto.eas.sox.exception.InvalidUserException;
import com.monsanto.eas.sox.model.DelinquentReportVO;

import java.util.Collection;

public interface DelinquentReportService {
    Collection<DelinquentReportVO> getDelinquentReport(String periodId) throws InvalidUserException;
}
