package com.monsanto.eas.sox.service;

import com.monsanto.eas.sox.model.Frequency;

import java.util.Collection;

public interface FrequencyService {
    Frequency getFrequencyByDescription(String description);

    Collection<Frequency> lookupAllFrequencies();
}
