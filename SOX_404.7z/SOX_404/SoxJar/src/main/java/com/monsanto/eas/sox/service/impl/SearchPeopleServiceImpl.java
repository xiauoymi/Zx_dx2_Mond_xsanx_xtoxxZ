package com.monsanto.eas.sox.service.impl;

import com.google.common.base.Joiner;
import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import com.monsanto.PeoplePicker.IPeopleService;
import com.monsanto.PeoplePicker.PeopleService;
import com.monsanto.PeoplePicker.PersonInfo;
import com.monsanto.eas.sox.model.PeopleSearchCriteriaVO;
import com.monsanto.eas.sox.service.SearchPeopleService;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.flex.remoting.RemotingDestination;
import org.springframework.flex.remoting.RemotingInclude;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import javax.sql.DataSource;
import java.util.*;

import static com.google.common.base.Strings.isNullOrEmpty;
import static java.lang.String.format;

@Service
@RemotingDestination(value = "searchPeopleService")
public class SearchPeopleServiceImpl implements SearchPeopleService
{
    private static final Logger LOG = Logger.getLogger(SearchPeopleServiceImpl.class);

    private static final String[] REQUIRED_SYSTEM_PROPERTIES = new String[] {
        "xmlservice.peoplepicker.server",
        "xmlservice.peoplepicker.vdir",
        "xmlservice.peoplepicker.endpoint"
    };

    private static final String PERIOD_OWNER_USER_IDS_SQL = getPeriodOwnerUserIdsSql();
    public static final PersonInfo NULL_PERSON = new PersonInfo();

    private final Logger logger = Logger.getLogger(SearchPeopleServiceImpl.class);
    private final IPeopleService peopleService = new PeopleService();

    private DataSource dataSource;

    @Autowired
    public void setDataSource(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    public SearchPeopleServiceImpl() {
        validateServiceConfiguration();
    }

    private void validateServiceConfiguration() {
        List<String> missingSystemProperties = Lists.newArrayListWithCapacity(REQUIRED_SYSTEM_PROPERTIES.length);
        for (String property : REQUIRED_SYSTEM_PROPERTIES) {
            if (isNullOrEmpty(System.getProperty(property))) {
                missingSystemProperties.add(property);
            }
        }
        if (!missingSystemProperties.isEmpty()) {
            RuntimeException configurationError = new IllegalStateException(String.format(
                "Invalid SearchPeopleService configuration. Required system properties not found: %s", missingSystemProperties)
            );
            LOG.error(configurationError.getMessage(), configurationError);
            throw configurationError;
        }
    }

    private static String getPeriodOwnerUserIdsSql() {
        return new StringBuilder()
            .append(" SELECT ")
            .append("     DISTINCT ")
            .append("     owner.user_id ")
            .append(" FROM ")
            .append("     sox_owner owner, ")
            .append("     sox_control_entity_owner entityOwner, ")
            .append("     sox_control_entity entity ")
            .append(" WHERE ")
            .append("     entity.period_id = ? ")
            .append("     AND entityOwner.control_entity_id = entity.control_entity_id ")
            .append("     AND entityOwner.owner_id = owner.owner_id ")
            .append(" ORDER BY ")
            .append("     owner.user_id ")
            .toString()
        ;
    }

    @Override
    @RemotingInclude
    public Collection<PersonInfo> getPeople(String lastName, String firstName, String phone, String mailStop, String userId, String site, String mailZone) {
        try {
            PersonInfo[] searchResults = peopleService.GetPeople(
                    normalize(lastName),
                    normalize(firstName),
                    normalize(phone),
                    normalize(mailStop),
                    normalize(userId),
                    normalize(site),
                    normalize(mailZone));

            if (searchResults != null && searchResults.length > 0) {
                return Arrays.asList(searchResults);
            }
        } catch (Exception e) {
            logger.error("Error getting results from PeoplePicker", e);
        }

        return Collections.emptyList();
    }

    private String normalize(String value) {
        return value == null ? "" : value;
    }

    public Collection<PersonInfo> getPeople(PeopleSearchCriteriaVO searchCriteria) {
        return getPeople(
                searchCriteria.getLastName(),
                searchCriteria.getFirstName(),
                searchCriteria.getPhone(),
                searchCriteria.getMailStop(),
                searchCriteria.getUserId(),
                searchCriteria.getSite(),
                searchCriteria.getMailZone());
    }

    @Override
    public PersonInfo findPersonByUserId(String userId) {
        PersonInfo personInfo = null;
        try {
            /*
            personInfo = findPersonByUserId(userId);
            return personInfo;
            */
            PersonInfo[] matches = findPersonsByUserId(userId);
            return findExactMatch(userId, matches);

        } catch (Exception e) {
            personInfo = new PersonInfo();
            personInfo.setUserId(userId);
            personInfo.setFirstName("");
            personInfo.setLastName("");
        }
        return personInfo;
    }

    private PersonInfo findExactMatch(String userId, PersonInfo[] persons) {
        for (PersonInfo person : persons) {
            if (userId.equalsIgnoreCase(person.getUserId())) {
                return person;
            }
        }

        return NULL_PERSON;
    }

    @Override
    public PersonInfo[] findPersonsByUserId(String userId) {
        try {
            return peopleService.GetPeople("", "", "", "", userId, "", "");
        } catch (Exception e) {
            return new PersonInfo[0];
        }
    }

    @Override
    public boolean isValid (PersonInfo personInfo) {
        return
            personInfo != null
            && personInfo.getFirstName() != null
            && personInfo.getLastName() != null
            && !personInfo.getFirstName().equals("")
            && !personInfo.getLastName().equals("")
        ;
    }

    @Override
    public Set<String> getInvalidUserIdsForPeriod(String periodId) {
        LOG.info(format("Getting invalid user IDs for period '%s'...", periodId));
        Set<String> invalidUserIds = Sets.newHashSet();
        final List<String> periodUserIds = new JdbcTemplate(dataSource).queryForList(PERIOD_OWNER_USER_IDS_SQL, String.class, periodId);
        for (String userId : periodUserIds) {
            if (!isValid(findPersonByUserId(userId))) {
                invalidUserIds.add(userId);
            }
        }
        LOG.info(format("%s invalid users were found for period '%s': [ %s ]", invalidUserIds.size(), periodId, Joiner.on(", ").join(invalidUserIds)));
        return invalidUserIds;
    }
}
