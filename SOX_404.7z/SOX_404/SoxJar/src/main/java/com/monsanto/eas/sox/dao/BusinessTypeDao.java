package com.monsanto.eas.sox.dao;

import com.monsanto.eas.sox.model.SoxBusinessType;

import java.util.Collection;

public interface BusinessTypeDao extends GenericDao<SoxBusinessType>{
    Collection<SoxBusinessType> lookupAllBusinessType();
}
