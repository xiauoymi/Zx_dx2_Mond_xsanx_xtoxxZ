package com.monsanto.eas.sox.dao.impl;

import com.monsanto.eas.sox.dao.OwnerDao;
import com.monsanto.eas.sox.model.SoxOwner;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.util.List;

@Repository
public class OwnerDaoImpl extends GenericDaoImpl<SoxOwner> implements OwnerDao {

    private static final long serialVersionUID = 1L;

    @PersistenceContext
    private EntityManager entityManager;

    public SoxOwner lookupSoxOwnerByUserId(String userId){
        SoxOwner owner = null;

        List<SoxOwner> owners = entityManager.createNamedQuery("lookupSoxOwnerByUserId").setParameter("userId", userId).getResultList();
        if(owners != null && owners.size() > 0) {
            owner = owners.get(0);
        }
        return owner;
    }

}
