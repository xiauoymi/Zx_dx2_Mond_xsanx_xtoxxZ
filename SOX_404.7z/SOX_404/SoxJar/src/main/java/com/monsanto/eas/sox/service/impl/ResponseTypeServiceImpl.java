package com.monsanto.eas.sox.service.impl;

import com.monsanto.eas.sox.dao.ResponseTypeDao;
import com.monsanto.eas.sox.model.ResponseType;
import com.monsanto.eas.sox.service.ResponseTypeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.flex.remoting.RemotingDestination;
import org.springframework.flex.remoting.RemotingInclude;
import org.springframework.stereotype.Service;

@Service
@RemotingDestination(value = "responseTypeService")
public class ResponseTypeServiceImpl implements ResponseTypeService{
    @Autowired
    private ResponseTypeDao responseTypeDao;

    @RemotingInclude
    public ResponseType getResponseTypeByDescription(String description) {
        ResponseType responseType = responseTypeDao.lookupResponseTypeByDescription(description);
        return responseType;
    }
}
