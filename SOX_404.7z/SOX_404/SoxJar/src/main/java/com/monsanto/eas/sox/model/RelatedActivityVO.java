package com.monsanto.eas.sox.model;

public class RelatedActivityVO {

    private String controlEntityId;
    private String description;


    public RelatedActivityVO(){}

    public RelatedActivityVO(String controlEntityId, String description){
        this.controlEntityId = controlEntityId;
        this.description = description;
    }

    public String getControlEntityId() {
        return controlEntityId;
    }

    public void setControlEntityId(String controlEntityId) {
        this.controlEntityId = controlEntityId;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}
