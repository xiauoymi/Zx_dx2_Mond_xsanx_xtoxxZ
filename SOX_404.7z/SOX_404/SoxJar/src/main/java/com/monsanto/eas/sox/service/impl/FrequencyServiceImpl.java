package com.monsanto.eas.sox.service.impl;

import com.monsanto.eas.sox.dao.FrequencyDao;
import com.monsanto.eas.sox.model.Frequency;
import com.monsanto.eas.sox.service.FrequencyService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.flex.remoting.RemotingDestination;
import org.springframework.flex.remoting.RemotingInclude;
import org.springframework.stereotype.Service;

import java.util.Collection;

@Service
@RemotingDestination(value="frequencyService")
public class FrequencyServiceImpl implements FrequencyService{

    @Autowired
    private FrequencyDao frequencyDao;

    @RemotingInclude
    public Frequency getFrequencyByDescription(String description) {
        Frequency frequency = frequencyDao.lookupFrequencyByDescription(description) ;
        return frequency;
    }

   @RemotingInclude
   public Collection<Frequency> lookupAllFrequencies() {
      return frequencyDao.lookupAllFrequencies();
   }
}
