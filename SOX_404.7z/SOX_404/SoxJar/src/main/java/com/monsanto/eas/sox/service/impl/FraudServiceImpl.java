package com.monsanto.eas.sox.service.impl;

import com.monsanto.eas.sox.dao.FraudDao;
import com.monsanto.eas.sox.model.Fraud;
import com.monsanto.eas.sox.service.FraudService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.flex.remoting.RemotingDestination;
import org.springframework.flex.remoting.RemotingInclude;
import org.springframework.stereotype.Service;

@Service
@RemotingDestination(value="fraudService")
public class FraudServiceImpl implements FraudService{

    @Autowired
    private FraudDao fraudDao;

    @RemotingInclude
    public Fraud getFraudByDescription(String description) {
        Fraud fraud = fraudDao.lookupFraudByDescription(description);
        return fraud;
    }
}
