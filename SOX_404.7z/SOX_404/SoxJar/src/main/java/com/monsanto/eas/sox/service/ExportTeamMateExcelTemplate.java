package com.monsanto.eas.sox.service;

import com.monsanto.eas.sox.model.ExportExcelTemplateVO;
import com.monsanto.eas.sox.model.SoxControlEntity;
import com.monsanto.eas.sox.model.SoxCtrlActivityAssertion;
import com.monsanto.eas.sox.model.SoxCtrlActivityEntity;
import org.apache.log4j.Logger;
import org.apache.poi.xssf.usermodel.*;
import org.springframework.stereotype.Service;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.Collection;
import java.util.Iterator;
import java.util.Map;

@Service
public class ExportTeamMateExcelTemplate extends ExportExcelTemplate {

   private final Logger logger = Logger.getLogger(ExportTeamMateExcelTemplate.class);

   public ExportExcelTemplateVO exportTemplate(String periodId, String countryId, String cycleId, Collection<SoxControlEntity> activities) {

      SoxControlEntity cycle = null;
      if (activities != null && activities.size() > 0) {
         cycle = activities.iterator().next().getParentControlEntity().getParentControlEntity();
      }

      /*
      Collection<SoxControlEntityRelationship> relatedActivities = null;
      relatedActivities = controlEntityRelationShipService.getRelatedActivitiesByCycle(cycle.getControlEntityId());
      */

      XSSFWorkbook template = new XSSFWorkbook();

      Map<String, XSSFCellStyle> styles = createStyles(template);
      XSSFSheet sheet = template.createSheet("Procedures");

      sheet.setFitToPage(true);
      sheet.getPrintSetup().setFitWidth((short) 1);
      sheet.getPrintSetup().setFitHeight((short) 0);
      sheet.getPrintSetup().setLandscape(true);

      createHeader(sheet, styles, cycle);
      createContent(1, sheet, styles, activities);
      //createSupportContent(ROW_FIRST_DATA + activities.size(), sheet, styles, relatedActivities);

      byte[] fileBytes = null;
      try {
         ByteArrayOutputStream baos = new ByteArrayOutputStream();
         template.write(baos);
         fileBytes = baos.toByteArray();
      } catch (IOException ioException) {
         System.out.println("Error writing file to output");
      }

      ExportExcelTemplateVO exportExcelTemplateVO = new ExportExcelTemplateVO();

      exportExcelTemplateVO.setRetrievalStatusDescription("successful");
      exportExcelTemplateVO.setRetrievalSuccessful(true);
      exportExcelTemplateVO.setExcelTemplateByteArray(fileBytes);

      return exportExcelTemplateVO;
   }


   private void createHeader(XSSFSheet sheet, Map<String, XSSFCellStyle> styles, SoxControlEntity cycle) {
      String[] titles = {
              "FOLDER",
              "FOLDER1",
              "FOLDER2",
              "WORKPROGRAMFOLDER",
              "TITLE",
              "TYPE",
              "CATEGORY",
              "VISIT",
              "FREQUENCY",
              "LOCATION",
              "USERCATEGORY1",
              "USERCATEGORY2",
              "PLANNINGTEXT1",
              "PLANNINGTEXT2",
              "PLANNINGTEXT3",
              "PLANNINGTEXT4",
              "PLANNINGTEXT5",
              "EXECUTIONTEXT1",
              "EXECUTIONTEXT2",
              "EXECUTIONTEXT3",
              "EXECUTIONTEXT4"
      };

      XSSFCell cell = null;
      XSSFRow titleRow = sheet.createRow(0);

      for (int i = 0; i < titles.length; i++) {

         cell = titleRow.createCell(i);
         cell.setCellStyle(styles.get("subTitleStyle"));

         if (i == ExcelTemplateDescriptor.TEAM_MATE_COL_WORKPROGRAMFOLDER) {
            sheet.setColumnWidth(i, LARGE_2_COL_LENGTH);
         } else if ((i >= ExcelTemplateDescriptor.TEAM_MATE_COL_PLANNINGTEXT1 && i <= ExcelTemplateDescriptor.TEAM_MATE_COL_PLANNINGTEXT3)
                 || i == ExcelTemplateDescriptor.TEAM_MATE_COL_PLANNINGTEXT5) {
            sheet.setColumnWidth(i, LARGE_1_COL_LENGTH);
         } else {
            sheet.setColumnWidth(i, MED_3_COL_LENGTH);
         }

         cell.setCellValue(titles[i]);
      }

   }

   protected void createContent(int firstIndex, XSSFSheet sheet, Map<String, XSSFCellStyle> styles, Collection<SoxControlEntity> activities) {
      int i = 0;

      StringBuffer assertions = null;

      try {
         for (SoxControlEntity activity : activities) {
            XSSFRow row = sheet.createRow(firstIndex + i++);

            SoxControlEntity subCycle = activity.getParentControlEntity();
            SoxControlEntity cycle = subCycle.getParentControlEntity();

            Iterator<SoxCtrlActivityEntity> it2 = activity.getSoxCtrlActivityEntities().iterator();
            SoxCtrlActivityEntity ctrlActivityEntity = null;
            while (it2.hasNext()) {
               ctrlActivityEntity = it2.next();
            }

            for (int cellCol = 0; cellCol <= 20; cellCol++) {
               XSSFCell cell = row.createCell(cellCol);
               cell.setCellStyle(styles.get("border"));
            }

            String assertionDescription = null;
            assertions = new StringBuffer();

            Iterator<SoxCtrlActivityAssertion> it3 = ctrlActivityEntity.getSoxCtrlActivityAssertions().iterator();
            while (it3.hasNext()) {
               SoxCtrlActivityAssertion ctrlActivityAssertion = it3.next();
               assertionDescription = ctrlActivityAssertion.getAssertion().getDescription();

               if(assertionDescription != null && !assertionDescription.equals("")){
                  assertions.append( assertionDescription );

                  if(it3.hasNext()){
                     assertions.append( ", " );
                  }
               }
            }


            String controlId = activity.getControlEntityId();
            controlId = controlId.substring(controlId.indexOf('.') + 1);

            String keyDescription = ctrlActivityEntity.getKey() != null ? ctrlActivityEntity.getKey().getDescription() : "No";

            StringBuffer controlSubcycleOwnerDesc = new StringBuffer();
            controlSubcycleOwnerDesc.append("Control Owner: ").append(getActivityOwners(activity)).append("\n")
                    .append("Subcycle Owner: ").append(getActivityOwners(subCycle));

            row.getCell(ExcelTemplateDescriptor.TEAM_MATE_COL_FOLDER).setCellValue(cycle.getDescription());
            row.getCell(ExcelTemplateDescriptor.TEAM_MATE_COL_WORKPROGRAMFOLDER).setCellValue(controlId.substring(0, controlId.lastIndexOf('.')).concat(" - ").concat(subCycle.getDescription()));
            row.getCell(ExcelTemplateDescriptor.TEAM_MATE_COL_TITLE).setCellValue(controlId);
            row.getCell(ExcelTemplateDescriptor.TEAM_MATE_COL_TYPE).setCellValue(keyDescription.equals("Yes") ? "Fieldwork" : "Scoped Out");
            row.getCell(ExcelTemplateDescriptor.TEAM_MATE_COL_CATEGORY).setCellValue(ctrlActivityEntity.getTypeOfControl() != null ? ctrlActivityEntity.getTypeOfControl().getDescription() : "");

            row.getCell(ExcelTemplateDescriptor.TEAM_MATE_COL_FREQUENCY).setCellValue(ctrlActivityEntity.getFrequency() != null ? ctrlActivityEntity.getFrequency().getDescription() : "");
            row.getCell(ExcelTemplateDescriptor.TEAM_MATE_COL_LOCATION).setCellValue(getCountries(activity));
            row.getCell(ExcelTemplateDescriptor.TEAM_MATE_COL_USERCATEGORY1).setCellValue(keyDescription.equals("Yes") ? "1" : "2");

            row.getCell(ExcelTemplateDescriptor.TEAM_MATE_COL_PLANNINGTEXT1).setCellValue(activity.getDescription());
            row.getCell(ExcelTemplateDescriptor.TEAM_MATE_COL_PLANNINGTEXT2).setCellValue(subCycle.getDescription());
            row.getCell(ExcelTemplateDescriptor.TEAM_MATE_COL_PLANNINGTEXT3).setCellValue(ctrlActivityEntity.getRisk());
            row.getCell(ExcelTemplateDescriptor.TEAM_MATE_COL_PLANNINGTEXT4).setCellValue(controlSubcycleOwnerDesc.toString());
            row.getCell(ExcelTemplateDescriptor.TEAM_MATE_COL_PLANNINGTEXT5).setCellValue(assertions.toString());
         }
      } catch (Exception ex) {
         logger.error("Error exporting the template", ex);
      }
   }

}
