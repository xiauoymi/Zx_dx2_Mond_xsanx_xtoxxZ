package com.monsanto.eas.sox.dao.impl;

import com.monsanto.eas.sox.dao.ControlEntityDao;
import com.monsanto.eas.sox.model.*;
import com.monsanto.eas.sox.util.DependentOverdueEntityVOComparator;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.util.*;

@Repository
public class ControlEntityDaoImpl extends GenericDaoImpl<SoxControlEntity> implements ControlEntityDao {
    private static final long serialVersionUID = 1L;

    @PersistenceContext
    private EntityManager entityManager;

    @Override
    public SoxControlEntity lookupSoxControlEntityByControlId(String controlId) {
        return (SoxControlEntity) entityManager.createNamedQuery("lookupCycleById").setParameter("cycleId", controlId).getSingleResult();
    }

    @Override
    public Collection<SoxControlEntity> lookupAllCycles() {
        return entityManager.createNamedQuery("lookupAllCycles").getResultList();
    }

    private Date getCurrentDate() {
        Calendar calendar = new GregorianCalendar();
        calendar.set(Calendar.HOUR_OF_DAY, 0);
        calendar.set(Calendar.MINUTE, 0);
        calendar.set(Calendar.SECOND, 0);
        calendar.set(Calendar.MILLISECOND, 0);

        return calendar.getTime();
    }

    @Override
    @SuppressWarnings("unchecked")
    public Collection<SoxControlEntityOwner> lookupCertificationsStarted(SoxPeriod period) {
        return entityManager.createNamedQuery("lookupCertificationsStarted").setParameter("currentDate", getCurrentDate()).setParameter("currentPeriod", period.getPeriodId()).getResultList();
    }

    @Override
    @SuppressWarnings("unchecked")
    public Collection<SoxControlEntityOwner> lookupEntityOwnersCertificationsOverdue(SoxPeriod period) {
        return entityManager.createNamedQuery("lookupEntityOwnersCertificationsOverdue").setParameter("currentDate", getCurrentDate()).setParameter("currentPeriod", period.getPeriodId()).getResultList();
    }

    @Override
    @SuppressWarnings("unchecked")
    public boolean isPeriodOpen(SoxPeriod period) {
        boolean periodOpen = true;
        Collection<SoxControlEntityOwner> delinquentOwners = entityManager.createNamedQuery("isPeriodOpen")
                .setParameter("currentPeriod", period.getPeriodId())
                .setMaxResults(1)
                .getResultList();

        if (delinquentOwners != null && delinquentOwners.isEmpty()) {
            periodOpen = false;
        }

        return periodOpen;
    }

    @Override
    @SuppressWarnings("unchecked")
    public Collection<SoxControlEntityOwner> lookupEntityChildsCertificationsOverdue(SoxPeriod period) {
        return entityManager.createNamedQuery("lookupEntityChildsCertificationsOverdue").setParameter("currentDate", getCurrentDate()).setParameter("currentPeriod", period.getPeriodId()).getResultList();
    }

    @Override
    @SuppressWarnings("unchecked")
    public Collection<SoxControlEntity> lookupEntitiesNotCertifiedForUser(String userId) {
        return entityManager.createNamedQuery("lookupEntitiesNotCertifiedForUser").setParameter("userId", userId).setParameter("currentPeriod", "1").getResultList();
    }

    @Override
    public Collection<DependentOverdueEntityVO> lookupChildsForAnEntity(String controlEntityId) {
        Date currentDate = getCurrentDate();

        List<DependentOverdueEntityVO> childs = lookupDelinquentOwnersForAnEntity(controlEntityId, currentDate);
        for (DependentOverdueEntityVO child : childs) {
            child.setStatus("OVERDUE");
        }
        Collection<DependentOverdueEntityVO> otherChilds = lookupCertifiedOwnersForAnEntity(controlEntityId, currentDate);
        for (DependentOverdueEntityVO child : otherChilds) {
            child.setStatus("CERTIFIED");
        }
        childs.addAll(otherChilds);

        otherChilds = lookupPendingChildsForAnEntity(controlEntityId, currentDate);
        for (DependentOverdueEntityVO child : otherChilds) {
            if (child.getStartDate().after(currentDate)) {
                child.setStatus("SCHEDULED");
            } else {
                child.setStatus("PENDING");
            }
        }
        childs.addAll(otherChilds);
        Collections.sort(childs, new DependentOverdueEntityVOComparator());
        return childs;
    }

    @SuppressWarnings("unchecked")
    public Collection<DependentOverdueEntityVO> lookupCertifiedOwnersForAnEntity(String controlEntityId, Date currentDate) {
        return entityManager.createNamedQuery("lookupCertifiedOwnersForAnEntity")
                .setParameter("currentDate", currentDate)
                .setParameter("controlEntityId", controlEntityId)
                .getResultList();
    }

    @Override
    public Collection<DependentOverdueEntityVO> lookupCertifiedOwnersForAnEntityWithoutDateRestriction(String controlEntityId) {
        return entityManager.createNamedQuery("lookupCertifiedOwnersForAnEntityWithoutDateRestriction")
                .setParameter("controlEntityId", controlEntityId)
                .getResultList();
    }

    @Override
    public Collection<RelatedActivityVO> getActivitiesDifferentFromSelectedCycle(String controlEntityId) {
        return entityManager.createNamedQuery("lookupActivitiesDifferentFromSelectedCycle")
                .setParameter("controlEntityId", controlEntityId)
                .getResultList();
    }

    @SuppressWarnings("unchecked")
    public List<DependentOverdueEntityVO> lookupDelinquentOwnersForAnEntity(String controlEntityId, Date currentDate) {
        return entityManager.createNamedQuery("lookupDelinquentOwnersForAnEntity")
                .setParameter("currentDate", currentDate)
                .setParameter("controlEntityId", controlEntityId)
                .getResultList();
    }

    @SuppressWarnings("unchecked")
    public Collection<DependentOverdueEntityVO> lookupPendingChildsForAnEntity(String controlEntityId, Date currentDate) {
        return entityManager.createNamedQuery("lookupPendingChildsForAnEntity")
                .setParameter("currentDate", currentDate)
                .setParameter("controlEntityId", controlEntityId)
                .getResultList();
    }

    @Override
    @SuppressWarnings("unchecked")
    public Collection<SoxControlEntity> lookupCyclesOwnedByUser(String userId) {
        return entityManager.createNamedQuery("lookupCyclesByUser").setParameter("userId", userId).getResultList();
    }

    @Override
    @SuppressWarnings("unchecked")
    public Collection<SoxControlEntity> lookupSubCyclesOwnedByUser(String userId) {
        return entityManager.createNamedQuery("lookupSubCyclesByUser").setParameter("userId", userId).getResultList();
    }

    @Override
    @SuppressWarnings("unchecked")
    public Collection<SoxControlEntity> lookupActivitiesOwnedByUser(String userId) {
        return entityManager.createNamedQuery("lookupActivitiesByUser").setParameter("userId", userId).getResultList();
    }

    @Override
    @SuppressWarnings("unchecked")
    public Collection<SoxControlEntity> lookupSubCyclesByUserAndCycle(String userId, String cycleId) {
        return entityManager.createNamedQuery("lookupSubCyclesByUserAndCycle").setParameter("userId", userId).setParameter("cycleId", cycleId).getResultList();
    }

    @Override
    @SuppressWarnings("unchecked")
    public Collection<SoxControlEntity> lookupActivitiesByUserAndCycle(String userId, String cycleId) {
        return entityManager.createNamedQuery("lookupActivitiesByUserAndCycle").setParameter("userId", userId).setParameter("cycleId", cycleId).getResultList();
    }

    @Override
    public Collection<SoxControlEntity> lookupActivitiesByCycle(String periodId, String cycleId) {
        return entityManager.createNamedQuery("lookupActivitiesByCycle").setParameter("periodId", periodId).setParameter("cycleId", cycleId).getResultList();
    }

    @Override
    @SuppressWarnings("unchecked")
    public Collection<SoxControlEntity> lookupActivitiesByCountry(String periodId, String countryId) {
        return entityManager.createNamedQuery("lookupActivitiesByCountry").setParameter("periodId", periodId).setParameter("countryId", countryId).getResultList();
    }

    @Override
    @SuppressWarnings("unchecked")
    public Collection<SoxControlEntity> lookupActivitiesByCountryAndCycle(String periodId, String countryId, String cycleId) {
        return entityManager.createNamedQuery("lookupActivitiesByCountryAndCycle").setParameter("periodId", periodId).setParameter("countryId", countryId).setParameter("cycleId", cycleId).getResultList();
    }

    @Override
    @SuppressWarnings("unchecked")
    public Collection<SoxControlEntity> lookupActivitiesByUserAndSubCycle(String userId, String subCycleId) {
        return entityManager.createNamedQuery("lookupActivitiesByUserAndSubCycle").setParameter("userId", userId).setParameter("subCycleId", subCycleId).getResultList();
    }

    @Override
    @SuppressWarnings("unchecked")
    public Collection<SoxControlEntity> getIncompleteChildren(String parentEntityId) {
        return entityManager.createNamedQuery("lookupIncompleteChildren").setParameter("parentEntityId", parentEntityId).getResultList();
    }

    @Override
    @SuppressWarnings("unchecked")
    public Collection<SoxControlEntity> lookupCyclesByPeriod(String periodId) {
        return entityManager.createNamedQuery("lookupCyclesByPeriod").setParameter("periodId", periodId).getResultList();
    }

    @Override
    @SuppressWarnings("unchecked")
    public Collection<SoxControlEntityOwner> lookupCertificationsToSendReminder(Date referenceDate, SoxPeriod period) {
        return entityManager.createNamedQuery("lookupCertificationsReminder").setParameter("currentPeriod", period.getPeriodId()).getResultList();
    }


    @Override
    @SuppressWarnings("unchecked")
    public PeriodMaintenanceVO getPeriodHistoricalData(SoxPeriod period) {
        StringBuffer sql = new StringBuffer()
                .append("            select period_id as periodId, entity_type, max(start_date)as startDate, max(reminder_date)as reminderDate, max(end_date) as endDate")
                .append("            from")
                .append("            (")
                .append("                select 'cycle' as entity_type, period_id, start_date, reminder_date, end_date")
                .append("                from sox_control_entity")
                .append("                where period_id = :periodId")
                .append("                and parent_control_entity_id is null")
                .append("                union all")
                .append("                select 'sub_cycle' as entity_type, period_id, start_date, reminder_date, end_date")
                .append("                from sox_control_entity sce")
                .append("                where period_id = :periodId")
                .append("                and parent_control_entity_id is not null")
                .append("                and exists")
                .append("                (")
                .append("                    select 1")
                .append("                    from sox_control_entity sce_parent")
                .append("                    where sce_parent.period_id = :periodId")
                .append("                    and sce_parent.control_entity_id = sce.parent_control_entity_id")
                .append("                    and sce_parent.parent_control_entity_id is null")
                .append("                )")
                .append("                union all")
                .append("                select 'activity' as entity_type, period_id, start_date, reminder_date, end_date")
                .append("                from sox_control_entity sce")
                .append("                where period_id = :periodId")
                .append("                and parent_control_entity_id is not null")
                .append("                and exists")
                .append("                (")
                .append("                    select 1")
                .append("                    from sox_control_entity sce_parent")
                .append("                    where sce_parent.period_id = :periodId")
                .append("                    and sce_parent.control_entity_id = sce.parent_control_entity_id")
                .append("                    and sce_parent.parent_control_entity_id is not null")
                .append("                )")
                .append("            )")
                .append("            group by period_id, entity_type");

        return PeriodHistoricalDataConverterDAOImpl.
                getPeriodHistoricalDataFromList(entityManager.createNativeQuery(sql.toString()).setParameter("periodId", period.getPeriodId()).getResultList(),
                        period);
    }
}
