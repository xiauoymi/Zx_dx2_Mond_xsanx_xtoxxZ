package com.monsanto.eas.sox.service;

import com.monsanto.eas.sox.model.PeriodMaintenanceVO;
import com.monsanto.eas.sox.model.SoxPeriod;
import org.springframework.flex.remoting.RemotingInclude;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.text.ParseException;

public interface PeriodSettingsService {
  @RemotingInclude
  @Transactional(propagation= Propagation.REQUIRED)
  void save(PeriodMaintenanceVO periodMaintenanceVO);

  @RemotingInclude
  PeriodMaintenanceVO get(String periodName) throws ParseException;

  @RemotingInclude
  Boolean getNewPeriodAvailability();
  
  @RemotingInclude
  SoxPeriod getNewPeriodData();
}
