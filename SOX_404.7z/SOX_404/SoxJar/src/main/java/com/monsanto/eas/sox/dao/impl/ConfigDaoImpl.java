package com.monsanto.eas.sox.dao.impl;

import com.monsanto.eas.sox.dao.ConfigDao;
import com.monsanto.eas.sox.model.SoxConfig;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.util.List;

@Repository
public class ConfigDaoImpl extends GenericDaoImpl<SoxConfig> implements ConfigDao {

    @PersistenceContext
    private EntityManager entityManager;

    @Override
    public SoxConfig lookupConfigByName(String parameterName) {

        SoxConfig config = null;
        List<SoxConfig> configList = entityManager.createNamedQuery("lookupConfigByName").setParameter("parameterName",parameterName).getResultList();
        if(configList != null && configList.size() > 0){
            config = configList.get(0);
        }
        return config;
    }

    @Override
    public List<SoxConfig> lookupConfigsByName(String parameterMask) {
        return entityManager.createNamedQuery("lookupConfigByName").setParameter("parameterName",parameterMask).getResultList();
    }

    @Override
    public void saveConfigList(List<SoxConfig> configList){
        if (configList != null){
            for (SoxConfig config : configList){
                this.merge(config);
            }
        }
    }
}
