package com.monsanto.eas.sox.dao.impl;

import com.monsanto.eas.sox.dao.ControlEntityRelationshipDao;
import com.monsanto.eas.sox.model.SoxControlEntity;
import com.monsanto.eas.sox.model.SoxControlEntityRelationship;
import org.springframework.stereotype.Repository;

import java.util.Collection;
import java.util.List;

@Repository
public class ControlEntityRelationshipDaoImpl extends GenericDaoImpl<SoxControlEntityRelationship> implements ControlEntityRelationshipDao {

    @Override
    public Collection<SoxControlEntityRelationship> lookupRelatedActivities(String cycleId) {
        List<SoxControlEntityRelationship> relatedActivities = entityManager.createNamedQuery("lookupRelatedActivitiesByCycle")
                .setParameter("cycleId", cycleId).getResultList();

        for (SoxControlEntityRelationship rel : relatedActivities) {
            Collection<SoxControlEntity> entityCollection = entityManager.createNamedQuery("lookupCycleById").setParameter("cycleId", rel.getRelatedControlActivityId()).getResultList();
            SoxControlEntity entity = entityCollection.iterator().next();
            rel.setEntity(entity);
        }
        return relatedActivities;
    }

    @Override
    public void deleteSoxControlEntityRelationship(int relationshipId) {
        entityManager.createNativeQuery("DELETE FROM sarbox_et.sox_control_activity_rel WHERE relationship_id = ?")
                .setParameter(1, relationshipId)
                .executeUpdate();
    }
}
