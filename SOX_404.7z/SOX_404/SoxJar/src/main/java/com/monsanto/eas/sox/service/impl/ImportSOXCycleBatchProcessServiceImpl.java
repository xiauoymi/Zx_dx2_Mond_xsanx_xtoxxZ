package com.monsanto.eas.sox.service.impl;

import com.google.common.base.Throwables;
import com.monsanto.eas.sox.exception.TemplateException;
import com.monsanto.eas.sox.model.*;
import com.monsanto.eas.sox.service.*;
import com.monsanto.eas.sox.util.SoxConstants;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.flex.remoting.RemotingDestination;
import org.springframework.flex.remoting.RemotingInclude;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
@RemotingDestination(value = "importSOXCycleBatchProcessService")
public class ImportSOXCycleBatchProcessServiceImpl implements ImportSOXCycleBatchProcessService {

    private static Logger logger = Logger.getLogger(ImportSOXCycleBatchProcessServiceImpl.class.getName());

    @Autowired
    private PeriodService periodService;

    @Autowired
    private ControlEntityService controlEntityService;

    @Autowired
    private ControlEntityRelationShipService relationShipService;

    @Autowired
    private ControlEntityOwnerService controlEntityOwnerService;

    @Autowired
    private SignificantChangeService significantChangeService;

    @Autowired
    private ResponseService responseService;

    @Autowired
    private ImportSOXPeriodWithCyclesFromTemplateData2DBService importSOXPeriodWithCyclesFromTemplateData2DBService;

    @Autowired
    private SOXEntityTrackLogService soxEntityTrackLogService;

    @Autowired
    private RollForwardServiceStoredProcedureImpl rollForwardServiceStoredProcedureImpl;

    @Override
    @RemotingInclude
    public List<String> copyPreviousCyclesIntoCurrentPeriod(String currentOrNewPeriod) throws TemplateException {
        try {
            return rollForwardServiceStoredProcedureImpl.copyPreviousCyclesIntoCurrentPeriod(currentOrNewPeriod);
        }
        catch (Exception e) {
            final Throwable cause = Throwables.getRootCause(e);
            logger.error(cause.getMessage(), cause);
            throw new TemplateException(cause.getMessage());
        }
    }

    @Override
    @RemotingInclude
    public List<String> modifySOXControlEntitiesFromTemplate(List<SOXPeriodWithCycleTemplateDataVO> soxControlEntitiesFromTemplateVOList,
                                                             String currentOrNewPeriod, String cycleId, SoxOwnerCycleTemplateVO cycleActivitiesOwner, String userId) {
        List<String> cyclesCopied = new ArrayList<String>();

        List<SOXPeriodWithCycleTemplateDataVO> soxControlDeletedEntitiesVOList = new ArrayList<SOXPeriodWithCycleTemplateDataVO>();
        List<SOXPeriodWithCycleTemplateDataVO> soxControlNewEntitiesVOList = new ArrayList<SOXPeriodWithCycleTemplateDataVO>();

        Map<String, SoxEntityTrackLogVO> soxModifiedEntityTrackLogVOMap = new HashMap<String, SoxEntityTrackLogVO>();

        for (SOXPeriodWithCycleTemplateDataVO soxPeriodWithCycleTemplateDataVO : soxControlEntitiesFromTemplateVOList) {

            if (soxPeriodWithCycleTemplateDataVO.isDeleteThisControl()) {
                soxControlDeletedEntitiesVOList.add(soxPeriodWithCycleTemplateDataVO);
            }

            if (soxPeriodWithCycleTemplateDataVO.isModifiedThisControl()) {

                createOrUpdateSoxEntityTrackLogVOEntry(soxModifiedEntityTrackLogVOMap, soxPeriodWithCycleTemplateDataVO);
            }

            if (soxPeriodWithCycleTemplateDataVO.isAddedThisControl()) {
                soxControlNewEntitiesVOList.add(soxPeriodWithCycleTemplateDataVO);
            }
        }

        deleteSOXControlEntities(soxControlDeletedEntitiesVOList, userId);
        saveSOXControlEntities(soxControlNewEntitiesVOList, currentOrNewPeriod, cycleId, userId);
        updateSOXControlEntities(soxModifiedEntityTrackLogVOMap, currentOrNewPeriod, userId);

        updateCycleActivitiesOwner(cycleId, cycleActivitiesOwner, userId);

        return cyclesCopied;
    }

    private void createOrUpdateSoxEntityTrackLogVOEntry(Map<String, SoxEntityTrackLogVO> soxModifiedEntityTrackLogVOMap, SOXPeriodWithCycleTemplateDataVO soxPeriodWithCycleTemplateDataVO) {
        SoxEntityTrackLogVO soxModifiedEntityTrackLogVO = null;

        if (soxModifiedEntityTrackLogVOMap.containsKey(soxPeriodWithCycleTemplateDataVO.getControlId())) {
            soxModifiedEntityTrackLogVO = soxModifiedEntityTrackLogVOMap.get(soxPeriodWithCycleTemplateDataVO.getControlId());

        } else {
            soxModifiedEntityTrackLogVO = new SoxEntityTrackLogVO();
            soxModifiedEntityTrackLogVO.setControlEntityId(soxPeriodWithCycleTemplateDataVO.getControlId());
            soxModifiedEntityTrackLogVOMap.put(soxPeriodWithCycleTemplateDataVO.getControlId(), soxModifiedEntityTrackLogVO);
        }

        if (soxPeriodWithCycleTemplateDataVO.isOriginalEntity()) {
            soxModifiedEntityTrackLogVO.setOriginalSOXTemplateVO(soxPeriodWithCycleTemplateDataVO);

        } else {
            soxModifiedEntityTrackLogVO.setNewSOXTemplateVO(soxPeriodWithCycleTemplateDataVO);
        }
    }


    private List<SOXPeriodWithCycleTemplateDataVO> deleteSOXControlEntities(List<SOXPeriodWithCycleTemplateDataVO> soxControlEntities, String userId) {
        if (soxControlEntities.size() > 0) {

            SoxPeriod currentPeriod = periodService.getCurrentPeriod();
            String currentPeriodPrefix = currentPeriod.getPeriodId();

            for (SOXPeriodWithCycleTemplateDataVO soxPeriodWithCycleTemplateDataVO : soxControlEntities) {
                if (soxPeriodWithCycleTemplateDataVO.getRelationshipId() != 0) {
                    relationShipService.deleteSoxControlEntityRelationship(soxPeriodWithCycleTemplateDataVO.getRelationshipId());
                } else {
                    controlEntityService.deleteSoxControlEntity(currentPeriodPrefix + "." + soxPeriodWithCycleTemplateDataVO.getControlId());
                    logger.info("Entity deleted " + currentPeriodPrefix + "." + soxPeriodWithCycleTemplateDataVO.getControlId());
                }
            }

            soxEntityTrackLogService.trackDeleteEntity(soxControlEntities, userId);
        }

        return soxControlEntities;
    }


    private List<SOXPeriodWithCycleTemplateDataVO> saveSOXControlEntities(List<SOXPeriodWithCycleTemplateDataVO> newSOXControlEntities,
                                                                          String currentOrNewPeriod, String cycleId, String userId) {
        try {
            //---Insert only the new ones
            if (newSOXControlEntities.size() > 0) {
                String cycleDescription = newSOXControlEntities.get(0).getTemplateCycleDescription();
                importSOXPeriodWithCyclesFromTemplateData2DBService.importLastSOXCyclesIntoACurrentPeriod(newSOXControlEntities, currentOrNewPeriod, cycleDescription, cycleId);
                soxEntityTrackLogService.trackAddEntity(newSOXControlEntities, userId);
            }

        } catch (Exception e) {
            logger.info("", e);
            throw new RuntimeException(e);
        }
        return newSOXControlEntities;
    }


    private List<SOXPeriodWithCycleTemplateDataVO> updateSOXControlEntities(Map<String, SoxEntityTrackLogVO> soxModifiedEntityTrackLogVOMap,
                                                                            String currentOrNewPeriod, String userId) {
        try {

            if (soxModifiedEntityTrackLogVOMap.size() > 0) {

                Collection<DependentOverdueEntityVO> otherChild = null;
                String[] cycleSubControl = null;
                SoxControlEntity soxControlEntity = null;
                SOXPeriodWithCycleTemplateDataVO soxPeriodWithCycleTemplateDataVO = null;

                for (SoxEntityTrackLogVO soxEntityTrackLogVO : soxModifiedEntityTrackLogVOMap.values()) {

                    soxPeriodWithCycleTemplateDataVO = soxEntityTrackLogVO.getNewSOXTemplateVO();

                    //update related activity
                    if (soxPeriodWithCycleTemplateDataVO.getRelationshipId() != 0) {
                        updateRelatedControlEntity(soxPeriodWithCycleTemplateDataVO, currentOrNewPeriod);

                    } else {
                        //---Get the owners of the control before deleting
                        cycleSubControl = soxPeriodWithCycleTemplateDataVO.getControlId().split("\\.");
                        String parentControlId = cycleSubControl.length > 2 ? (cycleSubControl[0] + "." + cycleSubControl[1]) : cycleSubControl[0];
                        String cycleId = cycleSubControl[0];
                        soxControlEntity = controlEntityService.lookupSoxControlEntityByControlId(currentOrNewPeriod + "." + cycleId);

                        otherChild = controlEntityService.lookupCertifiedOwnersForAnEntityWithoutDateRestriction(currentOrNewPeriod + "." + parentControlId);

                        importSOXPeriodWithCyclesFromTemplateData2DBService.updateSoxControlEntityActivity(soxControlEntity, soxPeriodWithCycleTemplateDataVO, currentOrNewPeriod);

                        //---Uncertify users - send notification
                        soxEntityTrackLogService.sendUncertifyNotice(otherChild, currentOrNewPeriod + "." + soxPeriodWithCycleTemplateDataVO.getControlId(), currentOrNewPeriod + "." + parentControlId);
                        controlEntityService.uncertifyEntity(otherChild);
                    }
                }

                soxEntityTrackLogService.trackUpdateEntity(soxModifiedEntityTrackLogVOMap, userId);
            }


        } catch (Exception e) {
            logger.info("", e);
            throw new RuntimeException(e);
        }
        return null;
    }

    private void updateRelatedControlEntity(SOXPeriodWithCycleTemplateDataVO soxPeriodWithCycleTemplateDataVO, String currentOrNewPeriod) {
        SoxControlEntityRelationship soxControlEntityRelationship = new SoxControlEntityRelationship();
        soxControlEntityRelationship.setId(soxPeriodWithCycleTemplateDataVO.getRelationshipId());
        soxControlEntityRelationship.setControlEntityId(currentOrNewPeriod + "." + soxPeriodWithCycleTemplateDataVO.getBaseCycleId());
        soxControlEntityRelationship.setRelatedControlActivityId(currentOrNewPeriod + "." + soxPeriodWithCycleTemplateDataVO.getControlId());
        soxControlEntityRelationship.setRisk(soxPeriodWithCycleTemplateDataVO.getRisk());

        relationShipService.saveOrUpdate(soxControlEntityRelationship);
    }

    private void updateCycleActivitiesOwner(String cycleId, SoxOwnerCycleTemplateVO cycleActivitiesOwner, String userId) {
        SoxControlEntity soxControlEntity = null;
        try {
            if (cycleActivitiesOwner != null && cycleActivitiesOwner.hasActivitiesOwnerChanged()) {
                soxControlEntity = controlEntityService.lookupSoxControlEntityByControlId(cycleId);
                importSOXPeriodWithCyclesFromTemplateData2DBService.updateCycleActivitiesOwner(soxControlEntity, cycleActivitiesOwner.getNewActivitiesOwner(), SoxConstants.ENTITY_TYPE_CYCLE);

                deleteEntitiesWithoutParentReferences();

                soxEntityTrackLogService.trackUpdateEntityOwners(cycleId, cycleActivitiesOwner.getOriginalActivitiesOwner(), cycleActivitiesOwner.getNewActivitiesOwner(), userId);
            }
        } catch (Exception e) {
            logger.error("", e);
            throw new RuntimeException(e);
        }
    }


    private void deleteEntitiesWithoutParentReferences() {
        try {

            //TODO: migrate to a newer version of jpa to make use of the orphanRemoval property
            significantChangeService.deleteSignificantChangeWithoutReferences();
            responseService.deleteSoxResponseWithoutReferences();
            controlEntityOwnerService.deleteSoxControlEntityOwnerWithoutReferences();

        } catch (Exception e) {
            logger.error("", e);
            throw new RuntimeException(e);
        }
    }

}
