package com.monsanto.eas.sox.service.impl;

import com.google.common.base.Splitter;
import com.monsanto.eas.sox.dao.SoxSystemDao;
import com.monsanto.eas.sox.exception.TemplateException;
import com.monsanto.eas.sox.model.SoxSystem;
import com.monsanto.eas.sox.service.SoxSystemService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.flex.remoting.RemotingDestination;
import org.springframework.flex.remoting.RemotingInclude;
import org.springframework.stereotype.Service;

import java.util.Collection;
import java.util.HashSet;
import java.util.Set;

@Service
@RemotingDestination(value = "systemService")
public class SoxSystemServiceImpl implements SoxSystemService {

    @Autowired
    private SoxSystemDao systemDao;

    private Splitter splitter = Splitter.on(',').omitEmptyStrings().trimResults();

    @RemotingInclude
    public SoxSystem getSoxSystemByDescription(String description) {
        SoxSystem system = systemDao.lookupSoxSystemByDescription(description);
        return system;
    }

    @RemotingInclude
    public Collection<SoxSystem> lookupAllSoxSystems() {
        Collection<SoxSystem> soxSystemCollection = systemDao.lookupAllSoxSystems();
        return soxSystemCollection;
    }

    @Override
    public Set<SoxSystem> parseSystems(String systemList) throws TemplateException {
        Set<SoxSystem> soxSystems = new HashSet<SoxSystem>();

        Iterable<String> systems = splitter.split(systemList);

        for (String system : systems) {

            SoxSystem soxSystem = null;

            if (system.equals("N/A")) {
                continue;
            } else {
                soxSystem = getSoxSystemByDescription(system);
            }

            if (soxSystem != null) {
                soxSystems.add(soxSystem);
            } else {
                throw new TemplateException("Template error, the system was not found: " + soxSystem);
            }
        }

        return soxSystems;
    }
}
