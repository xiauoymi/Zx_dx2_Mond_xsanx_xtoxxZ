package com.monsanto.eas.sox.service.impl;

import com.monsanto.eas.sox.dao.ControlEntityOwnerDao;
import com.monsanto.eas.sox.model.SoxControlEntityOwner;
import com.monsanto.eas.sox.model.SoxEntityOwnershipVO;
import com.monsanto.eas.sox.service.ControlEntityOwnerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.flex.remoting.RemotingDestination;
import org.springframework.flex.remoting.RemotingInclude;
import org.springframework.stereotype.Service;

import java.util.Collection;

@Service
@RemotingDestination(value = "controlEntityOwnerService")
public class ControlEntityOwnerServiceImpl implements ControlEntityOwnerService {

    @Autowired
    private ControlEntityOwnerDao controlEntityOwnerDao;

    @Override
    public SoxControlEntityOwner saveOrUpdate(SoxControlEntityOwner soxControlEntityOwner) {
        controlEntityOwnerDao.merge(soxControlEntityOwner);
        return soxControlEntityOwner;
    }

    @Override
    public void deleteSoxControlEntityOwnerWithoutReferences() {
        controlEntityOwnerDao.deleteSoxControlEntityOwnerWithoutReferences();
    }

    @RemotingInclude
    public Collection<SoxEntityOwnershipVO> getCycleOwnership(String userId) {
        return controlEntityOwnerDao.lookupCyclePermissionsForAnOwner(userId);
    }

    @RemotingInclude
    public Collection<SoxEntityOwnershipVO> getSubCycleOwnership(String userId) {
        return controlEntityOwnerDao.lookupSubCyclePermissionsForAnOwner(userId);
    }

    @RemotingInclude
    public Collection<SoxEntityOwnershipVO> getActivityOwnership(String userId) {
        return controlEntityOwnerDao.lookupActivitiesPermissionsForAnOwner(userId);
    }

    @RemotingInclude
    public Collection<String> getEditableCycles() {
        return controlEntityOwnerDao.lookupEditableCycles();
    }

    @RemotingInclude
    public Collection<SoxEntityOwnershipVO> getAllCycles() {
        return controlEntityOwnerDao.lookupAllCycles();
    }

    @RemotingInclude
    public Collection<SoxEntityOwnershipVO> getAllSubcycles() {
        return controlEntityOwnerDao.lookupAllSubcycles();
    }

    @RemotingInclude
    public Collection<SoxEntityOwnershipVO> getSubCyclesForACycle(String cycle) {
        return controlEntityOwnerDao.lookupSubCyclesForACycle(cycle);
    }

    @RemotingInclude
    public Collection<SoxEntityOwnershipVO> getActivitiesForACycleSubCycle(String cycle, String subCycle) {
        return controlEntityOwnerDao.lookupActivitiesForACycleSubCycle(cycle, subCycle);
    }
}
