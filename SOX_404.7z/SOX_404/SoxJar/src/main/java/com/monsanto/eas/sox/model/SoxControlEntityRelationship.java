package com.monsanto.eas.sox.model;

import javax.persistence.*;

@Entity
@Table(name = "SOX_CONTROL_ACTIVITY_REL", schema = "SARBOX_ET")
public class SoxControlEntityRelationship {

    @Id
    @SequenceGenerator(name = "soxRelSeq", sequenceName = "SARBOX_ET.SOX_REL_SEQ")
    @GeneratedValue(generator = "soxRelSeq", strategy = GenerationType.SEQUENCE)
    @javax.persistence.Column(name = "RELATIONSHIP_ID", nullable = false, insertable = true, updatable = true, length = 22, precision = 0)
    private int id;

    @javax.persistence.Column(name = "CONTROL_ENTITY_ID", nullable = false, insertable = true, updatable = true, length = 200, precision = 0)
    @Basic
    private String controlEntityId;

    @javax.persistence.Column(name = "RELATED_CONTROL_ACTIVITY_ID", nullable = false, insertable = true, updatable = true, length = 200, precision = 0)
    @Basic
    private String relatedControlActivityId;

    @javax.persistence.Column(name = "CONTROL_RISK", insertable = true, updatable = true, length = 200, precision = 0)
    @Basic
    private String risk;

    @Transient
    private SoxControlEntity entity;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getControlEntityId() {
        return controlEntityId;
    }

    public void setControlEntityId(String controlEntityId) {
        this.controlEntityId = controlEntityId;
    }

    public String getRelatedControlActivityId() {
        return relatedControlActivityId;
    }

    public void setRelatedControlActivityId(String relatedControlActivityId) {
        this.relatedControlActivityId = relatedControlActivityId;
    }

    public String getRisk() {
        return risk;
    }

    public void setRisk(String risk) {
        this.risk = risk;
    }

    public SoxControlEntity getEntity() {
        return entity;
    }

    public void setEntity(SoxControlEntity entity) {
        this.entity = entity;
    }

    @Override
    public int hashCode() {
        int result = id;
        result = 31 * result + id;
        return result;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        SoxControlEntityRelationship soxRel = (SoxControlEntityRelationship) o;

        if (id != soxRel.id) return false;
        return true;
    }

}
