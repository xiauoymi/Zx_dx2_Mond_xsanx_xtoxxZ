package com.monsanto.eas.sox.dao.impl;

import com.monsanto.eas.sox.dao.AdminLogDao;
import com.monsanto.eas.sox.model.SoxAdminLog;
import org.springframework.stereotype.Repository;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: JEESCO
 * Date: 8/02/12
 * Time: 10:44 AM
 */
@Repository
public class AdminLogDaoImpl extends GenericDaoImpl<SoxAdminLog> implements AdminLogDao {
    public Collection<SoxAdminLog> lookupLogEntries() {
        return entityManager.createNamedQuery("lookupLogEntries").getResultList();
    }

    public Collection<SoxAdminLog> lookupLogEntriesByPeriod(String periodId){
        return entityManager.createNamedQuery("lookupLogEntriesByPeriod").setParameter("periodId", periodId+"%").getResultList();

    }
}
