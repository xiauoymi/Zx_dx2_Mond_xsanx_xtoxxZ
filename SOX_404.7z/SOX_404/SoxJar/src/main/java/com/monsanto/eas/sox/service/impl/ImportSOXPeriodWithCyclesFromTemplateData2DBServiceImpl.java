package com.monsanto.eas.sox.service.impl;

import com.google.common.base.Joiner;
import com.google.common.base.Splitter;
import com.google.common.collect.Lists;
import com.monsanto.PeoplePicker.PersonInfo;
import com.monsanto.eas.sox.exception.InvalidUserException;
import com.monsanto.eas.sox.exception.TemplateException;
import com.monsanto.eas.sox.model.*;
import com.monsanto.eas.sox.service.*;
import com.monsanto.eas.sox.util.DateToStringHelper;
import com.monsanto.eas.sox.util.PeriodSettingsProperties;
import com.monsanto.eas.sox.util.SoxConstants;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.flex.remoting.RemotingDestination;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.text.ParseException;
import java.util.*;

@Service
@RemotingDestination(value = "importSOXPeriodWithCycleTemplateData2DB")
public class ImportSOXPeriodWithCyclesFromTemplateData2DBServiceImpl implements ImportSOXPeriodWithCyclesFromTemplateData2DBService {

    private static Logger logger = Logger.getLogger(ImportSOXPeriodWithCyclesFromTemplateData2DBServiceImpl.class.getName());

    @Autowired
    private OwnerService ownerService;

    @Autowired
    private PeriodService periodService;

    @Autowired
    private AssertionService assertionService;

    @Autowired
    private TypeOfControlService typeOfControlService;

    @Autowired
    private FrequencyService frequencyService;

    @Autowired
    private SoxSystemService soxSystemService;

    @Autowired
    private PreventDetectService preventDetectService;

    @Autowired
    private FraudService fraudService;

    @Autowired
    private KeyService keyService;

    @Autowired
    private CountryService countryService;

    @Autowired
    private ConfigService configService;

    @Autowired
    private ControlEntityService controlEntityService;

    @Autowired
    private QuestionService questionService;

    @Autowired
    private SearchPeopleService searchPeopleService;

    private final DateToStringHelper dateToStringHelper = new DateToStringHelper();

    private Splitter splitter = Splitter.on(',').omitEmptyStrings().trimResults();
    private Joiner joiner = Joiner.on(',').skipNulls();


    @Transactional
    public SoxControlEntity importLastSOXCyclesIntoACurrentPeriod(List<SOXPeriodWithCycleTemplateDataVO> soxPeriodWithCycleTemplateDataVOList,
                                                                  String currentOrNewPeriod, String cycleDescription, String currentCycleId) throws TemplateException, ParseException, InvalidUserException {

        List<SoxControlEntityRelationship> controlEntityRelationships = new ArrayList<SoxControlEntityRelationship>();

        SoxControlEntity subCycle = null;
        SoxControlEntity activity = null;
        SoxCtrlActivityEntity controlActivityEntity = null;

        String cycleId = null;
        String subCycleId = null;
        String activityId = null;

        boolean skipRow = false;
        boolean relatedRow = false;

        Map<String, String> dictionary = configService.getDictionary(PeriodSettingsProperties.PREFIX.getCode());

        // get the current period
        SoxPeriod period = periodService.getPeriodById(currentOrNewPeriod);

        SoxControlEntity cycle = new SoxControlEntity();
        cycle.setStartDate(dateToStringHelper.stringToDate(dictionary.get(PeriodSettingsProperties.CYCLE_NOTIFICATION_DATE.getCode())));
        cycle.setReminderDate(dateToStringHelper.stringToDate(dictionary.get(PeriodSettingsProperties.CYCLE_REMINDER_DATE.getCode())));
        cycle.setEndDate(dateToStringHelper.stringToDate(dictionary.get(PeriodSettingsProperties.CYCLE_DELINQUENT_DATE.getCode())));
        cycle.setSoxPeriod(period);

        cycle.setDescription(cycleDescription);
        logger.info("cycleDesc: " + cycleDescription);

        for (SOXPeriodWithCycleTemplateDataVO soxPeriodWithCycleTemplateDataVO : soxPeriodWithCycleTemplateDataVOList) {

            setEntityOwners(cycle, soxPeriodWithCycleTemplateDataVO.getActivitiesOwner(), SoxConstants.ENTITY_TYPE_CYCLE);

            ControlId controlId = ControlIdBuilder.build(period, soxPeriodWithCycleTemplateDataVO.getControlId());

            skipRow = false;
            relatedRow = false;

            if (controlId.equals(ControlId.NULL_CONTROL_ID)) {
                skipRow = true;
            } else {
                cycleId = controlId.getCycleId();
                subCycleId = controlId.getSubCycleId();
                activityId = controlId.getActivityId();
            }

            if (currentCycleId == null) {
                currentCycleId = cycleId;
                skipRow = false;
            } else if (!currentCycleId.equals(cycleId)) {
                skipRow = true;
                if (cycleId != null) {
                    relatedRow = true;
                }
            }

            if (!skipRow) {
                cycle.setControlEntityId(cycleId);

                // D10 - subCycle description
                subCycle = attachSubCycleToACycle(cycle, subCycleId, soxPeriodWithCycleTemplateDataVO.getSubcycle(), period, dictionary);

                // E10 - subCycle owners
                setEntityOwners(subCycle, soxPeriodWithCycleTemplateDataVO.getSubcycleOwner(), SoxConstants.ENTITY_TYPE_SUBCYCLE);

                controlActivityEntity = new SoxCtrlActivityEntity();

                // F10 - Assertions
                setAssertions(controlActivityEntity, soxPeriodWithCycleTemplateDataVO);

                //TODO: test whether risk is set to null no matter
                // K10 - Risk
                //if (soxPeriodWithCycleTemplateDataVO.getRisk() != null && !soxPeriodWithCycleTemplateDataVO.getRisk().equals("")) {
                controlActivityEntity.setRisk(soxPeriodWithCycleTemplateDataVO.getRisk());
                //}

                // L10 - activity description
                activity = attachActivityToASubCycle(subCycle, activityId, soxPeriodWithCycleTemplateDataVO, controlActivityEntity, period, dictionary);

                // M10 - activity owners
                setEntityOwners(activity, soxPeriodWithCycleTemplateDataVO.getControlOwner(), SoxConstants.ENTITY_TYPE_ACTIVITY);

                setControlsForAControlActivity(controlActivityEntity, soxPeriodWithCycleTemplateDataVO, activityId);


            } else if (relatedRow) {
                /* Related activities row; add to the new table */
                SoxControlEntityRelationship soxControlEntityRelationship = new SoxControlEntityRelationship();
                soxControlEntityRelationship.setControlEntityId(currentCycleId);
                soxControlEntityRelationship.setRelatedControlActivityId(activityId);
                soxControlEntityRelationship.setRisk(soxPeriodWithCycleTemplateDataVO.getRisk());
                controlEntityRelationships.add(soxControlEntityRelationship);
                //break;
            } else {
                break;
            }

            if (skipRow && !relatedRow) {
                relatedRow = false;
                break;
            }

        } // end of for - rows

        logger.debug("CYCLE: " + cycle);

        return controlEntityService.saveOrUpdate(cycle, controlEntityRelationships);
    }


    @Transactional
    public SoxControlEntity updateSoxControlEntityActivity(SoxControlEntity cycle, SOXPeriodWithCycleTemplateDataVO soxPeriodWithCycleTemplateDataVO, String currentOrNewPeriod) throws Exception {

        logger.info("Update SoxControlEntity started");

        SoxControlEntity subCycle = null;
        SoxControlEntity activity = null;

        String subCycleId = null;
        String activityId = null;

        // get the current period
        SoxPeriod period = periodService.getPeriodById(currentOrNewPeriod);

        Set<SoxCountry> countries = new HashSet<SoxCountry>();

        cycle.setDescription(soxPeriodWithCycleTemplateDataVO.getCycle());

        //--Cycle Owners
        List<Integer> activitiesOwnerToDeleteList = new ArrayList<Integer>();
        String activitiesOwnerFinalList = filterEntityOwnerToAdd(cycle, soxPeriodWithCycleTemplateDataVO.getActivitiesOwner(), activitiesOwnerToDeleteList);

        Iterator<SoxControlEntityOwner> cycleEntityOwnerIterator = cycle.getSoxControlEntityOwners().iterator();
        SoxControlEntityOwner cycleSoxControlEntityOwner = null;
        while (cycleEntityOwnerIterator.hasNext()) {
            cycleSoxControlEntityOwner = cycleEntityOwnerIterator.next();

            if (activitiesOwnerToDeleteList.contains(Integer.valueOf(cycleSoxControlEntityOwner.getControlEntityOwnerId()))) {
                cycleSoxControlEntityOwner.setSoxControlEntity(null);
                //cycle.getSoxControlEntityOwners().remove(cycleSoxControlEntityOwner);
                cycleEntityOwnerIterator.remove();
            }
        }
        if (!activitiesOwnerFinalList.equals("")) {
            setEntityOwners(cycle, activitiesOwnerFinalList, SoxConstants.ENTITY_TYPE_CYCLE);
        }

        // A10 - control id
        ControlId controlId = ControlIdBuilder.build(period, soxPeriodWithCycleTemplateDataVO.getControlId());

        subCycleId = controlId.getSubCycleId();
        activityId = controlId.getActivityId();

        // D10 - subCycle description
        subCycle = cycle.getChildEntity(subCycleId);
        subCycle.setDescription(soxPeriodWithCycleTemplateDataVO.getSubcycle());

        //--SubCycle Owners
        List<Integer> subCycleOwnerToDeleteList = new ArrayList<Integer>();
        String subCycleOwnerFinalList = filterEntityOwnerToAdd(subCycle, soxPeriodWithCycleTemplateDataVO.getSubcycleOwner(), subCycleOwnerToDeleteList);

        Iterator<SoxControlEntityOwner> subCycleEntityOwnerIterator = subCycle.getSoxControlEntityOwners().iterator();
        SoxControlEntityOwner subCycleSoxControlEntityOwner = null;
        while (subCycleEntityOwnerIterator.hasNext()) {
            subCycleSoxControlEntityOwner = subCycleEntityOwnerIterator.next();

            if (subCycleOwnerToDeleteList.contains(Integer.valueOf(subCycleSoxControlEntityOwner.getControlEntityOwnerId()))) {
                subCycleSoxControlEntityOwner.setSoxControlEntity(null);
                //subCycle.getSoxControlEntityOwners().remove(subCycleSoxControlEntityOwner);
                subCycleEntityOwnerIterator.remove();
            }
        }
        if (!subCycleOwnerFinalList.equals("")) {
            setEntityOwners(subCycle, subCycleOwnerFinalList, SoxConstants.ENTITY_TYPE_SUBCYCLE);
        }


        // L10 - activity description
        activity = subCycle.getChildEntity(activityId);
        if (activity == null) {
            throw new TemplateException("Template error, the control: " + soxPeriodWithCycleTemplateDataVO.getControlId() + " doesn't exist, first try to add it before updating");
        }
        Collection<SoxCtrlActivityEntity> controlActivityEntityTemp = activity.getSoxCtrlActivityEntities();

        controlEntityService.deleteCtrlEntityDependencies(activity.getControlEntityId());

        SoxCtrlActivityEntity soxCtrlActivityEntity = null;
        if (controlActivityEntityTemp != null && controlActivityEntityTemp.size() > 0) {
            soxCtrlActivityEntity = controlActivityEntityTemp.iterator().next();
        }

        // F10 - Assertions
        setAssertions(soxCtrlActivityEntity, soxPeriodWithCycleTemplateDataVO);


        // K10 - Risk
        if (soxPeriodWithCycleTemplateDataVO.getRisk() != null && !soxPeriodWithCycleTemplateDataVO.getRisk().equals("")) {
            soxCtrlActivityEntity.setRisk(soxPeriodWithCycleTemplateDataVO.getRisk());
        }

        // B10 - Countries
        countries.addAll(countryService.parseCountries(soxPeriodWithCycleTemplateDataVO.getCountry()));
        activity.setCountries(countries);

        activity.setDescription(soxPeriodWithCycleTemplateDataVO.getControl());

        // M10 - activity owners
        List<Integer> activityOwnerToDeleteList = new ArrayList<Integer>();
        String activityOwnerFinalList = filterEntityOwnerToAdd(activity, soxPeriodWithCycleTemplateDataVO.getControlOwner(), activityOwnerToDeleteList);

        Iterator<SoxControlEntityOwner> activityEntityOwnerIterator = activity.getSoxControlEntityOwners().iterator();
        SoxControlEntityOwner activityCycleSoxControlEntityOwner = null;
        while (activityEntityOwnerIterator.hasNext()) {
            activityCycleSoxControlEntityOwner = activityEntityOwnerIterator.next();

            if (activityOwnerToDeleteList.contains(Integer.valueOf(activityCycleSoxControlEntityOwner.getControlEntityOwnerId()))) {
                activityCycleSoxControlEntityOwner.setSoxControlEntity(null);
                //activity.getSoxControlEntityOwners().remove(activityCycleSoxControlEntityOwner);
                activityEntityOwnerIterator.remove();
            }
        }

        if (!activityOwnerFinalList.equals("")) {
            setEntityOwners(activity, activityOwnerFinalList, SoxConstants.ENTITY_TYPE_ACTIVITY);
        }

        // O10 - Type of control
        // P10 - Frequency
        // Q10 - System
        // R10 - Prevent Detect
        // S10 - Fraud
        // T10 - Key
        setControlsForAControlActivity(soxCtrlActivityEntity, soxPeriodWithCycleTemplateDataVO, activityId);

        //set the new values for the controlActivityEntity
        activity.addSoxCtrlActivityEntity(soxCtrlActivityEntity);

        return controlEntityService.saveOrUpdate(cycle);
    }


    public SoxControlEntity attachSubCycleToACycle(SoxControlEntity cycle, String subCycleId, String subCycleDesc,
                                                   SoxPeriod period, Map<String, String> periodSettingDictionary) throws ParseException {

        SoxControlEntity subCycle = cycle.getChildEntity(subCycleId);

        if (subCycle == null) {
            subCycle = new SoxControlEntity();
            subCycle.setDescription(subCycleDesc);
            subCycle.setControlEntityId(subCycleId);
            subCycle.setSoxPeriod(period);
            subCycle.setStartDate(dateToStringHelper.stringToDate(periodSettingDictionary.get(PeriodSettingsProperties.SUB_CYCLE_NOTIFICATION_DATE.getCode())));
            subCycle.setReminderDate(dateToStringHelper.stringToDate(periodSettingDictionary.get(PeriodSettingsProperties.SUB_CYCLE_REMINDER_DATE.getCode())));
            subCycle.setEndDate(dateToStringHelper.stringToDate(periodSettingDictionary.get(PeriodSettingsProperties.SUB_CYCLE_DELINQUENT_DATE.getCode())));
            cycle.addChildEntity(subCycle);
        }

        return subCycle;
    }

    public SoxControlEntity attachActivityToASubCycle(SoxControlEntity subCycle, String activityId, SOXPeriodWithCycleTemplateDataVO soxPeriodWithCycleTemplateDataVO,
                                                      SoxCtrlActivityEntity controlActivityEntity, SoxPeriod period, Map<String, String> periodSettingDictionary) throws ParseException, TemplateException {

        Set<SoxCountry> countries = new HashSet<SoxCountry>();
        countries.addAll(countryService.parseCountries(soxPeriodWithCycleTemplateDataVO.getCountry()));

        SoxControlEntity activity = subCycle.getChildEntity(activityId);

        if (activity == null) {
            activity = new SoxControlEntity();
            activity.setDescription(soxPeriodWithCycleTemplateDataVO.getControl());
            activity.setControlEntityId(activityId);
            activity.addSoxCtrlActivityEntity(controlActivityEntity);
            activity.setSoxPeriod(period);
            activity.addCountries(countries);
            activity.setStartDate(dateToStringHelper.stringToDate(periodSettingDictionary.get(PeriodSettingsProperties.CONTROL_NOTIFICATION_DATE.getCode())));
            activity.setReminderDate(dateToStringHelper.stringToDate(periodSettingDictionary.get(PeriodSettingsProperties.CONTROL_REMINDER_DATE.getCode())));
            activity.setEndDate(dateToStringHelper.stringToDate(periodSettingDictionary.get(PeriodSettingsProperties.CONTROL_DELINQUENT_DATE.getCode())));

            subCycle.addChildEntity(activity);
        }

        return activity;
    }

    public void setControlsForAControlActivity(SoxCtrlActivityEntity controlActivityEntity, SOXPeriodWithCycleTemplateDataVO soxPeriodWithCycleTemplateDataVO, String activityId) throws TemplateException {
        // O10 - Type of control
        setTypeOfControlForAControlActivity(controlActivityEntity, soxPeriodWithCycleTemplateDataVO.getControlType(), activityId);

        // P10 - Frequency
        setFrequencyForAControlActivity(controlActivityEntity, soxPeriodWithCycleTemplateDataVO.getFrequency(), activityId);

        // Q10 - System
        setSystemForAControlActivity(controlActivityEntity, soxPeriodWithCycleTemplateDataVO.getSystem());

        // R10 - Prevent Detect
        setPreventDetectControlForAControlActivity(controlActivityEntity, soxPeriodWithCycleTemplateDataVO.getPrevent(), activityId);

        // S10 - Fraud
        setFraudForAControlActivity(controlActivityEntity, soxPeriodWithCycleTemplateDataVO.getFraud(), activityId);

        // T10 - Key
        setKeyForAControlActivity(controlActivityEntity, soxPeriodWithCycleTemplateDataVO.getKey(), activityId);
    }

    public void setTypeOfControlForAControlActivity(SoxCtrlActivityEntity controlActivityEntity, String controlType, String activityId) throws TemplateException {
        if (controlType != null && !controlType.equals("")) {
            TypeOfControl typeOfControl = typeOfControlService.getTypeOfControlByDescription(controlType);
            if (typeOfControl == null) {
                throw new TemplateException("Template error, the type of control is not correct on activity " + activityId);
            } else {
                controlActivityEntity.setTypeOfControl(typeOfControl);
            }
        }
    }

    public void setFrequencyForAControlActivity(SoxCtrlActivityEntity controlActivityEntity, String frequencyDesc, String activityId) throws TemplateException {
        if (frequencyDesc != null && !frequencyDesc.equals("")) {
            Frequency frequency = frequencyService.getFrequencyByDescription(frequencyDesc);
            if (frequency == null) {
                throw new TemplateException("Template error, the frequency is not correct on activity " + activityId);
            } else {
                controlActivityEntity.setFrequency(frequency);
            }
        }
    }

    public void setSystemForAControlActivity(SoxCtrlActivityEntity controlActivityEntity, String systemDesc) throws TemplateException {
        if (systemDesc != null && !systemDesc.equals("")) {
            Set<SoxSystem> systems = soxSystemService.parseSystems(systemDesc);
            if (systems != null) {
                controlActivityEntity.setSoxSystems(systems);
            }
        }
    }

    public void setPreventDetectControlForAControlActivity(SoxCtrlActivityEntity controlActivityEntity, String preventDetectDesc, String activityId) throws TemplateException {
        if (preventDetectDesc != null && !preventDetectDesc.equals("")) {
            PreventDetect preventDetect = preventDetectService.getPreventDetectByDescription(preventDetectDesc);
            if (preventDetect != null) {
                controlActivityEntity.setPreventDetect(preventDetect);
            } else {
                throw new TemplateException("Template error, the Prevent/detect is not correct on activity " + activityId);
            }
        }
    }

    public void setFraudForAControlActivity(SoxCtrlActivityEntity controlActivityEntity, String fraudDesc, String activityId) throws TemplateException {
        if (fraudDesc != null && !fraudDesc.equals("")) {
            Fraud fraud = fraudService.getFraudByDescription(fraudDesc);
            if (fraud == null) {
                throw new TemplateException("Template error, the fraud is not correct on activity " + activityId);
            } else {
                controlActivityEntity.setFraud(fraud);
            }
        }
    }

    public void setKeyForAControlActivity(SoxCtrlActivityEntity controlActivityEntity, String keyDesc, String activityId) throws TemplateException {
        if (keyDesc != null && !keyDesc.equals("")) {
            Key key = keyService.getKeyByDescription(keyDesc);
            if (key == null) {
                throw new TemplateException("Template error, the key is not correct on activity " + activityId);
            } else {
                controlActivityEntity.setKey(key);
            }
        }
    }

    public SoxControlEntity updateCycleActivitiesOwner(SoxControlEntity cycle, String activitiesOwner, String entityType) throws Exception {
        logger.info("updateCycleActivitiesOwner ");

        List<Integer> activitiesOwnerToDeleteList = new ArrayList<Integer>();
        String activitiesOwnerFinalList = filterEntityOwnerToAdd(cycle, activitiesOwner, activitiesOwnerToDeleteList);

        Iterator<SoxControlEntityOwner> cycleEntityOwnerIterator = cycle.getSoxControlEntityOwners().iterator();
        SoxControlEntityOwner cycleSoxControlEntityOwner = null;

        while (cycleEntityOwnerIterator.hasNext()) {
            cycleSoxControlEntityOwner = cycleEntityOwnerIterator.next();

            if (activitiesOwnerToDeleteList.contains(Integer.valueOf(cycleSoxControlEntityOwner.getControlEntityOwnerId()))) {

                cycleSoxControlEntityOwner.setSoxControlEntity(null);

                cycleEntityOwnerIterator.remove();
                cycle.getSoxControlEntityOwners().remove(cycleSoxControlEntityOwner);
            }
        }
        if (!activitiesOwnerFinalList.equals("")) {
            setEntityOwners(cycle, activitiesOwnerFinalList, entityType);
        }

        return controlEntityService.saveOrUpdate(cycle);
    }


    public void setAssertions(SoxCtrlActivityEntity activityEntity, SOXPeriodWithCycleTemplateDataVO soxPeriodWithCycleTemplateDataVO) {

        if (soxPeriodWithCycleTemplateDataVO.isExistenceOfOccurrenceAssertion()) {
            Assertion assertion = null;
            assertion = assertionService.getAssertionByDescription(SoxConstants.ASSERTION_EXISTENCE_OR_OCCURRENCE);
            setAssertion(activityEntity, assertion);
        }
        if (soxPeriodWithCycleTemplateDataVO.isCompletenessAssertion()) {
            Assertion assertion = null;
            assertion = assertionService.getAssertionByDescription(SoxConstants.ASSERTION_COMPLETENESS);
            setAssertion(activityEntity, assertion);
        }
        if (soxPeriodWithCycleTemplateDataVO.isValuationAndAllocationAssertion()) {
            Assertion assertion = null;
            assertion = assertionService.getAssertionByDescription(SoxConstants.ASSERTION_VALUATION_AND_ALLOCATION);
            setAssertion(activityEntity, assertion);
        }
        if (soxPeriodWithCycleTemplateDataVO.isRightAndObligationAssertion()) {
            Assertion assertion = null;
            assertion = assertionService.getAssertionByDescription(SoxConstants.ASSERTION_RIGHT_AND_OBLIGATION);
            setAssertion(activityEntity, assertion);
        }
        if (soxPeriodWithCycleTemplateDataVO.isPresentationAndDisclosureAssertion()) {
            Assertion assertion = null;
            assertion = assertionService.getAssertionByDescription(SoxConstants.ASSERTION_PRESENTATION_AND_DISCLOSURE);
            setAssertion(activityEntity, assertion);
        }
    }


    public void setAssertion(SoxCtrlActivityEntity activityEntity, Assertion assertion) {
        if (assertion != null) {
            SoxCtrlActivityAssertion soxCtrlActivityAssertion = new SoxCtrlActivityAssertion();
            soxCtrlActivityAssertion.setAssertion(assertion);
            activityEntity.addSoxCtrlActivityAssertions(soxCtrlActivityAssertion);
        }
    }


    public void setEntityOwners(SoxControlEntity entity, String entityOwners, String entityType) throws InvalidUserException {
        Collection<String> entityOwnersCollection = getCommaSeparatedListAsCollection(entityOwners);

        if (entityOwnersCollection.isEmpty()) {
            return;
            //entityOwnersCollection.add(SoxConstants.NONE);
        }

        for (String entityOwnerString : entityOwnersCollection) {
            PersonInfo personInfo = null;

            if (entityOwnerString.equalsIgnoreCase(SoxConstants.NONE)) {
                //TODO: is it the same if we skip this?
                continue;
                /*
                personInfo = new PersonInfo();
                personInfo.setUserId(entityOwnerString.toUpperCase());
                */
            } else {
                // Get the user info from people picker
                logger.debug("getPersonInfo: " + entityOwnerString);
                personInfo = searchPeopleService.findPersonByUserId(entityOwnerString.toUpperCase());
            }

            if (searchPeopleService.isValid(personInfo)) {

                SoxOwner owner = ownerService.lookupOwnerByUserId(personInfo.getUserId());

                // if owner is missing then generate new one
                if (owner == null) {
                    owner = new SoxOwner();
                    owner.setUserId(entityOwnerString.toUpperCase());
                    ownerService.save(owner);
                }

                SoxControlEntityOwner controlEntityOwner = new SoxControlEntityOwner();

                logger.debug("loading questions for entityType: " + entityType);

                setQuestionsForOwnerBasedOnEntityType(controlEntityOwner, entityType);

                controlEntityOwner.setSoxOwner(owner);
                entity.addSoxControlEntityOwner(controlEntityOwner);
            } else {
                logger.info("InvalidUserId: " + personInfo.getUserId() );
            }
        }
    }

    public void setQuestionsForOwnerBasedOnEntityType(SoxControlEntityOwner controlEntityOwner, String entityType) {
        Collection<SoxQuestion> allQuestions = questionService.getAllQuestions();

        Collection<SoxQuestion> questions = new ArrayList<SoxQuestion>();

        for (SoxQuestion currentQuestion : allQuestions) {
            logger.debug("currentQuestion.getLevelType(): '" + currentQuestion.getLevelType() + "'");
            logger.debug("entityType: '" + entityType + "'");

            if (currentQuestion.getLevelType().trim().equalsIgnoreCase(entityType)) {
                questions.add(currentQuestion);

                logger.debug("adding question: " + currentQuestion.getLevelType());
            }
        }

        logger.debug("questions size: " + (questions.size()));

        SoxResponse response = null;

        for (SoxQuestion question : questions) {
            response = new SoxResponse();
            response.setSoxQuestion(question);
            controlEntityOwner.addSoxResponse(response);
            logger.debug("question added: " + question.getDescription());
        }
    }


    public String filterEntityOwnerToAdd(SoxControlEntity entity, String entityOwners, List<Integer> deletedEntityOwners) throws Exception {
        logger.debug("setEntityOwners: " + entityOwners);

        Collection<String> entityOwnersCollection = getCommaSeparatedListAsCollection(entityOwners);
        String userOwnerId = null;
        int ctrlEntityOwnerId = 0;

        if (entity.getSoxControlEntityOwners() != null && entity.getSoxControlEntityOwners().size() == 0) {
            return entityOwners;
        }
        for (SoxControlEntityOwner soxControlEntityOwner : entity.getSoxControlEntityOwners()) {
            userOwnerId = soxControlEntityOwner.getSoxOwner().getUserId();
            ctrlEntityOwnerId = soxControlEntityOwner.getControlEntityOwnerId();

            if (entityOwnersCollection.contains(userOwnerId)) {
                entityOwnersCollection.remove(userOwnerId);
            } else {
                deletedEntityOwners.add(ctrlEntityOwnerId);
            }
        }

        return joiner.join(entityOwnersCollection);
    }


    public Collection<String> getCommaSeparatedListAsCollection(String list) {
        if (list != null && list.trim().length() > 0) {
            return Lists.newArrayList(splitter.split(list));
        }

        return new ArrayList<String>();
    }


    private static class ControlId {
        public static final ControlId NULL_CONTROL_ID = new ControlId(null, null, null);

        private String cycleId;
        private String subCycleId;
        private String activityId;

        private ControlId(String cycleId, String subCycleId, String activityId) {
            this.cycleId = cycleId;
            this.subCycleId = subCycleId;
            this.activityId = activityId;
        }

        public String getCycleId() {
            return cycleId;
        }

        public String getSubCycleId() {
            return subCycleId;
        }

        public String getActivityId() {
            return activityId;
        }
    }

    private static class ControlIdBuilder {
        private static ControlId build(SoxPeriod period, String id) {
            String periodId = period != null ? period.getPeriodId() : "";

            String[] entityId = id.split("\\.");

            if (entityId.length == 3) {
                String cycleId = periodId + "." + entityId[0];
                String subCycleId = cycleId + "." + entityId[1];
                String activityId = subCycleId + "." + entityId[2];

                return new ControlId(cycleId, subCycleId, activityId);
            }

            return ControlId.NULL_CONTROL_ID;
        }
    }

    public void setSearchPeopleService(SearchPeopleService searchPeopleService) {
        this.searchPeopleService = searchPeopleService;
    }
}
