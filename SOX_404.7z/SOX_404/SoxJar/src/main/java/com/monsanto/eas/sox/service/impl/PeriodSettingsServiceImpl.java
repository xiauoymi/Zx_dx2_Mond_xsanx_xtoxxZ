package com.monsanto.eas.sox.service.impl;

import com.monsanto.eas.sox.dao.ConfigDao;
import com.monsanto.eas.sox.dao.ControlEntityDao;
import com.monsanto.eas.sox.dao.PeriodDao;
import com.monsanto.eas.sox.model.PeriodMaintenanceVO;
import com.monsanto.eas.sox.model.SoxConfig;
import com.monsanto.eas.sox.model.SoxPeriod;
import com.monsanto.eas.sox.service.PeriodSettingsService;
import com.monsanto.eas.sox.util.DateToStringHelper;
import com.monsanto.eas.sox.util.PeriodSettingsProperties;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.flex.remoting.RemotingDestination;
import org.springframework.flex.remoting.RemotingInclude;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.text.ParseException;
import java.util.*;

@Service
@RemotingDestination(value = "periodSettingsService")
public class PeriodSettingsServiceImpl implements PeriodSettingsService {

    @Autowired
    PeriodDao periodDao;

    @Autowired
    private ConfigDao configDao;

    @Autowired
    private ControlEntityDao controlEntityDao;

    private final DateToStringHelper dateToStringHelper = new DateToStringHelper();

    private SoxPeriod getSoxPeriodFromPeriodMaintenanceVO(PeriodMaintenanceVO periodMaintenanceVO) {
        SoxPeriod soxPeriod = new SoxPeriod();
        soxPeriod.setPeriodId(periodMaintenanceVO.getName());
        soxPeriod.setPeriodDescription(periodMaintenanceVO.getDescription());
        soxPeriod.setCurrentPeriod(periodMaintenanceVO.getCurrentPeriod());
        soxPeriod.setClosedPeriod(periodMaintenanceVO.getStatus());
        soxPeriod.setCycleOnly(periodMaintenanceVO.getCycleOnly());
        soxPeriod.setNews(periodMaintenanceVO.getNews());

        return soxPeriod;
    }

    private List<SoxConfig> getSettingsFromPeriodMaintenanceVO(PeriodMaintenanceVO periodMaintenanceVO) {
        List<SoxConfig> settings = new ArrayList<SoxConfig>();
        settings.add(new SoxConfig(PeriodSettingsProperties.CONTROL_NOTIFICATION_DATE.getCode(),
                dateToStringHelper.dateToString(periodMaintenanceVO.getControlNotification())));
        settings.add(new SoxConfig(PeriodSettingsProperties.CONTROL_REMINDER_DATE.getCode(),
                dateToStringHelper.dateToString(periodMaintenanceVO.getControlReminder())));
        settings.add(new SoxConfig(PeriodSettingsProperties.CONTROL_DELINQUENT_DATE.getCode(),
                dateToStringHelper.dateToString(periodMaintenanceVO.getControlDelinquent())));

        settings.add(new SoxConfig(PeriodSettingsProperties.SUB_CYCLE_NOTIFICATION_DATE.getCode(),
                dateToStringHelper.dateToString(periodMaintenanceVO.getSubcycleNotification())));
        settings.add(new SoxConfig(PeriodSettingsProperties.SUB_CYCLE_REMINDER_DATE.getCode(),
                dateToStringHelper.dateToString(periodMaintenanceVO.getSubcycleReminder())));
        settings.add(new SoxConfig(PeriodSettingsProperties.SUB_CYCLE_DELINQUENT_DATE.getCode(),
                dateToStringHelper.dateToString(periodMaintenanceVO.getSubcycleDelinquent())));

        settings.add(new SoxConfig(PeriodSettingsProperties.CYCLE_NOTIFICATION_DATE.getCode(),
                dateToStringHelper.dateToString(periodMaintenanceVO.getCycleNotification())));
        settings.add(new SoxConfig(PeriodSettingsProperties.CYCLE_REMINDER_DATE.getCode(),
                dateToStringHelper.dateToString(periodMaintenanceVO.getCycleReminder())));
        settings.add(new SoxConfig(PeriodSettingsProperties.CYCLE_DELINQUENT_DATE.getCode(),
                dateToStringHelper.dateToString(periodMaintenanceVO.getCycleDelinquent())));

        return settings;
    }

    private PeriodMaintenanceVO getPeriodMaintenanceVOFromSettings(List<SoxConfig> settings, SoxPeriod period) throws ParseException {
        PeriodMaintenanceVO periodMaintenanceVO = new PeriodMaintenanceVO();
        Map<String, String> dictionary;


        if (period != null) {
            periodMaintenanceVO.setName(period.getPeriodId());
            periodMaintenanceVO.setDescription(period.getPeriodDescription());
            periodMaintenanceVO.setCurrentPeriod(period.getCurrentPeriod());
            periodMaintenanceVO.setStatus(period.getClosedPeriod());
            periodMaintenanceVO.setCycleOnly(period.getCycleOnly());
            periodMaintenanceVO.setNews(period.getNews());
        }

        if (settings != null && settings.size() != 0 && period != null && !period.getPeriodDescription().equalsIgnoreCase("NEW")) {
            dictionary = new HashMap<String, String>();
            for (SoxConfig config : settings) {
                dictionary.put(config.getParameterName(), config.getParameterValue());
            }

            periodMaintenanceVO.setControlNotification(dateToStringHelper.stringToDate(dictionary.get(PeriodSettingsProperties.CONTROL_NOTIFICATION_DATE.getCode())));
            periodMaintenanceVO.setControlReminder(dateToStringHelper.stringToDate(dictionary.get(PeriodSettingsProperties.CONTROL_REMINDER_DATE.getCode())));
            periodMaintenanceVO.setControlDelinquent(dateToStringHelper.stringToDate(dictionary.get(PeriodSettingsProperties.CONTROL_DELINQUENT_DATE.getCode())));

            periodMaintenanceVO.setSubcycleNotification(dateToStringHelper.stringToDate(dictionary.get(PeriodSettingsProperties.SUB_CYCLE_NOTIFICATION_DATE.getCode())));
            periodMaintenanceVO.setSubcycleReminder(dateToStringHelper.stringToDate(dictionary.get(PeriodSettingsProperties.SUB_CYCLE_REMINDER_DATE.getCode())));
            periodMaintenanceVO.setSubcycleDelinquent(dateToStringHelper.stringToDate(dictionary.get(PeriodSettingsProperties.SUB_CYCLE_DELINQUENT_DATE.getCode())));

            periodMaintenanceVO.setCycleNotification(dateToStringHelper.stringToDate(dictionary.get(PeriodSettingsProperties.CYCLE_NOTIFICATION_DATE.getCode())));
            periodMaintenanceVO.setCycleReminder(dateToStringHelper.stringToDate(dictionary.get(PeriodSettingsProperties.CYCLE_REMINDER_DATE.getCode())));
            periodMaintenanceVO.setCycleDelinquent(dateToStringHelper.stringToDate(dictionary.get(PeriodSettingsProperties.CYCLE_DELINQUENT_DATE.getCode())));
        }

        return periodMaintenanceVO;
    }

    @Override
    @RemotingInclude
    @Transactional
    public void save(PeriodMaintenanceVO periodMaintenanceVO) {
        if (periodMaintenanceVO.getCurrentPeriod().equals("1")) {
            Map<String, Object> parameters = new HashMap<String, Object>();
            parameters.put("periodId", periodMaintenanceVO.getName());
            periodDao.executeUpdate("UPDATE Sox_Period SET current_Period=decode(period_id, :periodId, 1, null)", parameters);
        }
        periodDao.merge(getSoxPeriodFromPeriodMaintenanceVO(periodMaintenanceVO));
        configDao.saveConfigList(getSettingsFromPeriodMaintenanceVO(periodMaintenanceVO));
    }

    @Override
    @RemotingInclude
    public PeriodMaintenanceVO get(String periodName) throws ParseException {
        PeriodMaintenanceVO periodMaintenanceVO = null;
        Map<String, Object> parameters = new HashMap<String, Object>();
        parameters.put("periodId", periodName);
        List<SoxPeriod> periods = (List<SoxPeriod>) periodDao.findListByQueryName("lookupPeriodById", parameters);
        SoxPeriod period = periods == null || periods.size() == 0 ? null : periods.get(0);
        if (period != null) {
            periodMaintenanceVO = controlEntityDao.getPeriodHistoricalData(period);
            if (periodMaintenanceVO.getControlNotification() == null) {
                periodMaintenanceVO = getPeriodMaintenanceVOFromSettings(configDao.lookupConfigsByName(PeriodSettingsProperties.PREFIX.getCode()), period);
            }
            periodMaintenanceVO.setCompleted(!controlEntityDao.isPeriodOpen(period));
        } else {
            period = getNewPeriodData();
            periodMaintenanceVO = getPeriodMaintenanceVOFromSettings(configDao.lookupConfigsByName(PeriodSettingsProperties.PREFIX.getCode()), period);
        }

        return periodMaintenanceVO;
    }

    @Override
    @RemotingInclude
    public Boolean getNewPeriodAvailability() {
        return periodDao.getNewPeriodAvailability();
    }

    @Override
    @RemotingInclude
    public SoxPeriod getNewPeriodData() {
        SoxPeriod newPeriod = null;
        final String YEAR_MARKER = "FY";
        final String QUARTER_MARKER = "Q";
        if (getNewPeriodAvailability()) {
            newPeriod = periodDao.getMaximumPeriod();
            Calendar calendar = new GregorianCalendar();
            int currentYear = calendar.get(Calendar.YEAR) % 100;
            int currentQuarter = 1;
            int pos = newPeriod.getPeriodId().indexOf(QUARTER_MARKER);
            if (pos != -1 && pos < newPeriod.getPeriodId().length()) {
                currentQuarter = Integer.parseInt(newPeriod.getPeriodId().substring(pos + 1));
                pos = newPeriod.getPeriodId().indexOf(YEAR_MARKER);
                if (pos != -1 && pos + YEAR_MARKER.length() + 2 < newPeriod.getPeriodId().length()) {
                    currentYear = Integer.parseInt(newPeriod.getPeriodId().substring(pos + YEAR_MARKER.length(), pos + YEAR_MARKER.length() + 2));
                }
                if (currentQuarter != 4) {
                    currentQuarter++;
                } else {
                    currentQuarter = 1;
                    currentYear++;
                }
            }
            newPeriod.setPeriodId(YEAR_MARKER + currentYear + "-" + QUARTER_MARKER + currentQuarter);
            newPeriod.setPeriodDescription("NEW");
            newPeriod.setCurrentPeriod("");
            newPeriod.setClosedPeriod("");
            newPeriod.setNews("You're certifying for " + newPeriod.getPeriodId());
        }

        return newPeriod;
    }
}
