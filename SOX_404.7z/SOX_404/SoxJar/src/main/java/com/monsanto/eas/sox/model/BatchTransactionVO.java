package com.monsanto.eas.sox.model;

public class BatchTransactionVO {
    private String transactionLog;
    private String deleteOwner;
    private String deleteResponse;

    public BatchTransactionVO(String transactionLog, String deleteOwner, String deleteResponse) {
        this.transactionLog = transactionLog;
        this.deleteOwner = deleteOwner;
        this.deleteResponse = deleteResponse;
    }

    public String getTransactionLog() {
        return transactionLog;
    }

    public void setTransactionLog(String transactionLog) {
        this.transactionLog = transactionLog;
    }

    public String getDeleteOwner() {
        return deleteOwner;
    }

    public void setDeleteOwner(String deleteOwner) {
        this.deleteOwner = deleteOwner;
    }

    public String getDeleteResponse() {
        return deleteResponse;
    }

    public void setDeleteResponse(String deleteResponse) {
        this.deleteResponse = deleteResponse;
    }

    @Override
    public String toString() {
        return "BatchTransactionVO{" +
                "transactionLog='" + transactionLog + '\'' +
                ", deleteOwner='" + deleteOwner + '\'' +
                ", deleteResponse='" + deleteResponse + '\'' +
                '}';
    }
}
