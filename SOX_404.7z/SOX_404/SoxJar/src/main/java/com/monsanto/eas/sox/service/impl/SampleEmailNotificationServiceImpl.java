package com.monsanto.eas.sox.service.impl;

import com.monsanto.eas.sox.dao.ConfigDao;
import com.monsanto.eas.sox.dao.ControlEntityDao;
import com.monsanto.eas.sox.dao.PeriodDao;
import com.monsanto.eas.sox.dao.impl.SampleControlEntityDaoImpl;
import com.monsanto.eas.sox.model.EmailNotificationTemplateVO;
import com.monsanto.eas.sox.model.SoxConfig;
import com.monsanto.eas.sox.service.*;
import com.monsanto.eas.sox.util.EmailNotificationType;
import com.monsanto.eas.sox.util.NotificationConfigProperties;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.flex.remoting.RemotingDestination;
import org.springframework.flex.remoting.RemotingInclude;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;

@Service
@RemotingDestination(value="sampleEmailNotificationService")
public class SampleEmailNotificationServiceImpl implements SampleEmailNotificationService {

    private Logger logger = Logger.getLogger(getClass().getName());

    @Autowired
    DateCalculationService dateCalcService;

    @Autowired
    EmailService emailService;

    @Autowired
    ConfigService configService;

    @Autowired
    PeriodDao periodDao;

    @Autowired
    private ConfigDao configDao;

    private final static String STATUS_OK = "";

    private CertificationMessagesService messagesService;
    private ControlEntityDao controlEntityDao;
    private String[][] unneededTags = {
          {"<FONT FACE=\"DroidSansSox\" SIZE=\"12\" COLOR=\"#000000\" LETTERSPACING=\"0\" KERNING=\"1\">", "</FONT>", "<XX/>"},
          {"<CENTER ALIGN=\"left\">", "</CENTER>", "<XX/>"},
          {"<P ALIGN=\"left\">", "</P>", "<XX/>"},
          {"<XX/><XX/>", null, "<XX/>"},
          {"<XX/>", null, "<BR/>"},
  };

    @Override
    @RemotingInclude
    public String sendEmail(EmailNotificationTemplateVO emailNotificationTemplateVO) {
      String status = STATUS_OK;
      try {
          FlexHtmlAdapter flexHtmlAdapter = new FlexHtmlAdapter();
          this.controlEntityDao = new SampleControlEntityDaoImpl(emailNotificationTemplateVO.getRecipient());
          this.messagesService = new CertificationMessagesServiceImpl(
                  dateCalcService,
                  emailService,
                  this.controlEntityDao,
                  configService,
                  periodDao) ;
           emailNotificationTemplateVO.setBody(flexHtmlAdapter.removeFlexUnneededTags(emailNotificationTemplateVO.getBody(), unneededTags));

            if (EmailNotificationType.getEmailNotificationType(emailNotificationTemplateVO.getNotificationType()) == EmailNotificationType.CERTIFICATION_START){
                messagesService.sendStartCertificationMessages(emailNotificationTemplateVO);
            }
            else if (EmailNotificationType.getEmailNotificationType(emailNotificationTemplateVO.getNotificationType()) == EmailNotificationType.REMINDER){
                messagesService.sendReminderMessages(emailNotificationTemplateVO);
            }
            else if (EmailNotificationType.getEmailNotificationType(emailNotificationTemplateVO.getNotificationType()) == EmailNotificationType.ENTITIES_OVERDUE){
                messagesService.sendEntityOwnersOverdueCertificationMessages(emailNotificationTemplateVO);
            }
            else if (EmailNotificationType.getEmailNotificationType(emailNotificationTemplateVO.getNotificationType()) == EmailNotificationType.CHILD_ENTITIES_OVERDUE){
                messagesService.sendEntityChildsOverdueCertificationMessages(emailNotificationTemplateVO);
            }
        }
        catch (Exception e) {
          logger.error(e);
          status = e.toString();
        }
        return status;
    }

    @Override
    @RemotingInclude
    @Transactional(propagation= Propagation.REQUIRED)
    public String save(EmailNotificationTemplateVO emailNotificationTemplateVO) {
        String status = STATUS_OK;
        try
        {
            FlexHtmlAdapter flexHtmlAdapter = new FlexHtmlAdapter();
            List<SoxConfig> soxConfigList = new ArrayList<SoxConfig>();
            // HTML Template
            SoxConfig soxConfig = new SoxConfig(
                    NotificationConfigProperties.EMAIL_CONFIG_PREFIX.getCode() + EmailNotificationType.getEmailNotificationType(emailNotificationTemplateVO.getNotificationType()).getCode()
                            + NotificationConfigProperties.EMAIL_TEMPLATE.getCode(),
                    flexHtmlAdapter.removeFlexUnneededTags(emailNotificationTemplateVO.getBody(), unneededTags)
            );
            soxConfigList.add(soxConfig);

            // TLF Template (Flex Template)
            soxConfig = new SoxConfig(
                    NotificationConfigProperties.EMAIL_CONFIG_PREFIX.getCode() + EmailNotificationType.getEmailNotificationType(emailNotificationTemplateVO.getNotificationType()).getCode()
                            + NotificationConfigProperties.TLF_TEMPLATE.getCode(),
                    emailNotificationTemplateVO.getTlfTemplate()
            );
            soxConfigList.add(soxConfig);

            // Subject
            soxConfig = new SoxConfig(
                  NotificationConfigProperties.EMAIL_CONFIG_PREFIX.getCode() + EmailNotificationType.getEmailNotificationType(emailNotificationTemplateVO.getNotificationType()).getCode() +
                          NotificationConfigProperties.EMAIL_SUBJECT.getCode(),
                  emailNotificationTemplateVO.getSubject()
            );
            soxConfigList.add(soxConfig);
            configDao.saveConfigList(soxConfigList);
        }
        catch (Exception e) {
          logger.error(e);
          status = e.toString();
        }

        return "OK";
    }

    @Override
    @RemotingInclude
    public EmailNotificationTemplateVO getEmailNotificationTemplate(String notificationType) {
      EmailNotificationTemplateVO emailNotificationTemplateVO = null;
      try
      {
            EmailNotificationType emailNotificationType = EmailNotificationType.getEmailNotificationType(notificationType);
            List<SoxConfig> soxConfigList = null;
            if (emailNotificationType != null) {
               soxConfigList = configDao.lookupConfigsByName(NotificationConfigProperties.EMAIL_CONFIG_PREFIX.getCode() + emailNotificationType.getCode() + "%");
            }
            if (soxConfigList != null && !soxConfigList.isEmpty()){
                emailNotificationTemplateVO = new EmailNotificationTemplateVO();
                for (SoxConfig config : soxConfigList){
                    if (config.getParameterName().indexOf(NotificationConfigProperties.EMAIL_SUBJECT.getCode()) != -1){
                        emailNotificationTemplateVO.setSubject(config.getParameterValue());
                    }
                    else if (config.getParameterName().indexOf(NotificationConfigProperties.EMAIL_TEMPLATE.getCode()) != -1){
                        emailNotificationTemplateVO.setBody(config.getParameterValue());
                    }
                    else if (config.getParameterName().indexOf(NotificationConfigProperties.TLF_TEMPLATE.getCode()) != -1){
                        emailNotificationTemplateVO.setTlfTemplate(config.getParameterValue());
                    }
                }
            }
      } catch (Exception e){
          logger.error(e);
          emailNotificationTemplateVO = new EmailNotificationTemplateVO(e.toString());
      }
        return emailNotificationTemplateVO;
    }
}
