package com.monsanto.eas.sox.service.impl;

import com.monsanto.eas.sox.exception.TemplateException;

import java.util.List;

public interface RollForwardService
{
    List<String> copyPreviousCyclesIntoCurrentPeriod(String currentOrNewPeriod) throws TemplateException;
}
