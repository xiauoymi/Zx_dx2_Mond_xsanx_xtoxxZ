package com.monsanto.eas.sox.model;

import com.monsanto.eas.sox.util.ControlEntityType;

public class SoxEntityOwnershipVO {
    private String controlEntityId;
    private String description;
    private String userId;
    private boolean editable = false;
    private ControlEntityType entityType;

    public SoxEntityOwnershipVO()
    {
        super();
    }

    public SoxEntityOwnershipVO (String controlEntityId,String description)
    {
        super();
        this.controlEntityId = controlEntityId;
        this.description = description;
    }

    public SoxEntityOwnershipVO (String controlEntityId,String description, String userId)
    {
        super();
        this.controlEntityId = controlEntityId;
        this.description = description;
        this.userId = userId;
    }

    public String getControlEntityId() {
        return controlEntityId;
    }

    public void setControlEntityId(String controlEntityId) {
        this.controlEntityId = controlEntityId;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public ControlEntityType getEntityType() {
        return entityType;
    }

    public void setEntityType(ControlEntityType entityType) {
        this.entityType = entityType;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public boolean isEditable() {
        return editable;
    }

    public void setEditable(boolean editable) {
        this.editable = editable;
    }

    @Override
    public String toString() {
        return "SoxEntityOwnershipVO{" +
                "controlEntityId='" + controlEntityId + '\'' +
                ", description='" + description + '\'' +
                ", userId='" + userId + '\'' +
                ", entityType=" + entityType +
                ", editable=" + editable +
                '}';
    }
}
