/*
 Copyright:  Copyright � 2011 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.eas.sox.dao;

import java.io.Serializable;
import java.util.Collection;
import java.util.List;
import java.util.Map;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author sspati1
 * @version $Revision$
 */
public interface GenericDao<E> extends Serializable {
    /**
     * This method creates the entity on the database.
     *
     * @param entity the entity
     */
    public void save(E entity);

    /**
     * This method updates the database.
     *
     * @param entity the entity
     */
    public E merge(E entity);

    /**
     * This method deletes <code>E</code> from the database.
     *
     * @param entity the entity
     */
    public void delete(E entity);

    /**
     * Refresh.
     *
     * @param entity the entity
     */
    public void refresh(E entity);

    public E getReference(java.lang.Class<E> tClass, java.lang.Object o);

    /**
     * This method checks if <code>E</code> exists in persistence context, if <code>E</code> this method returns true
     * otherwise false.<br>
     *
     * @param entity the entity
     * @return true, if successful
     */
    public boolean contains(E entity);

    /**
     * Find using a named query.
     *
     * @param queryName the name of the query
     * @param params    the query parameters
     * @return the list of entities
     */
    public Collection<E> findByQuery(final String queryName, Object... params);

    /**
     * Find by query name.
     *
     * @param queryName the query name
     * @param params    the params
     * @return the list< e>
     */
    public Collection<E> findByQueryName(final String queryName, Object... params);

    /**
     * Find by primary key
     *
     * @param clazz      - Class
     * @param primaryKey - primary key of table
     * @return the E
     */
    public E findByPrimaryKey(Class clazz, Integer primaryKey);

    public abstract E findByQueryName(String queryName, Map<String, Object> parameters);

    public abstract List<E> findListByQueryName(String queryName, Map<String, Object> parameters);

    public abstract int executeUpdate(String queryName, Map<String, Object> parameters);
}
