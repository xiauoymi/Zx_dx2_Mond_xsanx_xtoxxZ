package com.monsanto.eas.sox.service.impl;

import com.google.common.base.Splitter;
import com.monsanto.eas.sox.dao.CountryDao;
import com.monsanto.eas.sox.exception.TemplateException;
import com.monsanto.eas.sox.model.SoxCountry;
import com.monsanto.eas.sox.service.CountryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.flex.remoting.RemotingDestination;
import org.springframework.flex.remoting.RemotingInclude;
import org.springframework.stereotype.Service;

import java.util.Collection;
import java.util.HashSet;
import java.util.Set;

@Service
@RemotingDestination(value="countryService")
public class CountryServiceImpl implements CountryService{

    @Autowired
    private CountryDao countryDao;

    private Splitter splitter = Splitter.on(',').omitEmptyStrings().trimResults();

    @RemotingInclude
    public SoxCountry getCountryByDescription(String description) {
        SoxCountry country = countryDao.lookupCountryByDescription(description);
        return country;
    }

    @RemotingInclude
    public Collection<SoxCountry> getAllCountries() {
        Collection<SoxCountry> soxCountries = countryDao.lookupAllCountries();
        return soxCountries;
    }

    @Override
    public Set<SoxCountry> parseCountries(String countryList) throws TemplateException {
        Set<SoxCountry> countries = new HashSet<SoxCountry>();

        Iterable<String> countryNames = splitter.split(countryList);

        for (String countryName : countryNames) {
            SoxCountry country = getCountryByDescription(countryName);

            if (country != null) {
                countries.add(country);
            } else {
                throw new TemplateException("Template error, the countries are not correct: " + countryList);
            }
        }

        return countries;
    }

}
