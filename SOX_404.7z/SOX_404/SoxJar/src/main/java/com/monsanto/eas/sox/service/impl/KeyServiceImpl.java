package com.monsanto.eas.sox.service.impl;

import com.monsanto.eas.sox.dao.KeyDao;
import com.monsanto.eas.sox.model.Key;
import com.monsanto.eas.sox.service.KeyService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.flex.remoting.RemotingDestination;
import org.springframework.flex.remoting.RemotingInclude;
import org.springframework.stereotype.Service;

@Service
@RemotingDestination(value="keyService")
public class KeyServiceImpl implements KeyService {

    @Autowired
    private KeyDao keyDao;

    @RemotingInclude
    public Key getKeyByDescription(String description) {
        Key key = keyDao.lookupKeyByDescription(description);
        return key;
    }
}
