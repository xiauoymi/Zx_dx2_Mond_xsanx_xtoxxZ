/*
 Copyright:  Copyright � 2011 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.eas.sox.controller;

import com.monsanto.eas.sox.util.SoxConstants;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import java.util.HashMap;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author sspati1
 * @version $Revision$
 */
@Controller
@RequestMapping(value = "/home")
public class HomeController {

  @RequestMapping(method = RequestMethod.GET)
  public final ModelAndView goToHome() {
    return new ModelAndView(SoxConstants.HOME_VIEW, new HashMap<String, String>());
  }
}