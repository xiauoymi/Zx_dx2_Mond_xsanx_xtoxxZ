package com.monsanto.eas.sox.model;

public class ExportExcelTemplateVO {

   private byte[] excelTemplateByteArray;
   private boolean retrievalSuccessful;
   private String retrievalStatusDescription;

   public ExportExcelTemplateVO() {
      super();
   }

   public ExportExcelTemplateVO(byte[] excelTemplateByteArray, boolean retrievalSuccessful, String retrievalStatusDescription) {
      this.excelTemplateByteArray = excelTemplateByteArray;
      this.retrievalSuccessful = retrievalSuccessful;
      this.retrievalStatusDescription = retrievalStatusDescription;
   }

   public byte[] getExcelTemplateByteArray() {
      return excelTemplateByteArray;
   }

   public void setExcelTemplateByteArray(byte[] excelTemplateByteArray) {
      this.excelTemplateByteArray = excelTemplateByteArray;
   }

   public String getRetrievalStatusDescription() {
      return retrievalStatusDescription;
   }

   public void setRetrievalStatusDescription(String retrievalStatusDescription) {
      this.retrievalStatusDescription = retrievalStatusDescription;
   }

   public boolean isRetrievalSuccessful() {
      return retrievalSuccessful;
   }

   public void setRetrievalSuccessful(boolean retrievalSuccessful) {
      this.retrievalSuccessful = retrievalSuccessful;
   }

}
