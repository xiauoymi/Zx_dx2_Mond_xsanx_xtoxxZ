package com.monsanto.eas.sox.model;

import javax.persistence.*;
import java.io.Serializable;

@Entity
@Table(name = "SOX_CONFIG", schema = "SARBOX_ET")
public class SoxConfig implements Serializable{

    @javax.persistence.Column(name = "PARAM_NAME", nullable = false, insertable = true, updatable = true, length = 50, precision = 0)
    @Id
    //@Column(name = "PARAM_NAME", nullable = true, insertable = true, updatable = true, length = 50, precision = 0)
    //@Basic
    private String parameterName;

    @Column(name = "PARAM_VALUE", nullable = true, insertable = true, updatable = true, length = 2000, precision = 0)
    @Basic
    private String parameterValue;

    public SoxConfig() {
        super();
    }

  public SoxConfig(String parameterName, String parameterValue) {
    this.parameterName = parameterName;
    this.parameterValue = parameterValue;
  }

    public String getParameterName() {
      return parameterName;
    }

    public void setParameterName(String parameterName) {
      this.parameterName = parameterName;
    }

    public String getParameterValue() {
      return parameterValue;
    }

    public void setParameterValue(String parameterValue) {
      this.parameterValue = parameterValue;
    }

    @Override
    public String toString() {
      return "SoxConfig{" +
              ", parameterName='" + parameterName + '\'' +
              ", parameterValue='" + parameterValue + '\'' +
              '}';
    }
} // end of class