package com.monsanto.eas.sox.model;

public class SOXPeriodWithCycleTemplateDataVO {

    private String templateCycleDescription;
    private String activitiesOwner;

    private boolean deleteThisControl;
    private boolean modifiedThisControl;
    private boolean addedThisControl;
    private boolean originalEntity;

    private String controlId;
    private String controlIdKey;
    private String country;
    private String cycle;
    private String subcycle;
    private String subcycleOwner;

    private boolean existenceOfOccurrenceAssertion;
    private boolean completenessAssertion;
    private boolean valuationAndAllocationAssertion;
    private boolean rightAndObligationAssertion;
    private boolean presentationAndDisclosureAssertion;

    private String risk;
    private String control;
    private String controlOwner;
    private String controlType;
    private String frequency;
    private String system;
    private String prevent;
    private String fraud;
    private String key;

    //In case the entityControl is a related activity
    private String baseCycleId;
    private int relationshipId;

    public SOXPeriodWithCycleTemplateDataVO() {
    }

    public String getActivitiesOwner() {
        return activitiesOwner;
    }

    public void setActivitiesOwner(String activitiesOwner) {
        this.activitiesOwner = activitiesOwner;
    }

    public boolean isAddedThisControl() {
        return addedThisControl;
    }

    public void setAddedThisControl(boolean addedThisControl) {
        this.addedThisControl = addedThisControl;
    }

    public boolean isCompletenessAssertion() {
        return completenessAssertion;
    }

    public void setCompletenessAssertion(boolean completenessAssertion) {
        this.completenessAssertion = completenessAssertion;
    }

    public String getControl() {
        return control;
    }

    public void setControl(String control) {
        this.control = control;
    }

    public String getBaseCycleId() {
        return baseCycleId;
    }

    public void setBaseCycleId(String baseCycleId) {
        this.baseCycleId = baseCycleId;
    }

    public String getControlId() {
        return controlId;
    }

    public void setControlId(String controlId) {
        this.controlId = controlId;
    }

    public String getControlIdKey() {
        return controlIdKey;
    }

    public void setControlIdKey(String controlIdKey) {
        this.controlIdKey = controlIdKey;
    }

    public String getControlOwner() {
        return controlOwner;
    }

    public void setControlOwner(String controlOwner) {
        this.controlOwner = controlOwner;
    }

    public String getControlType() {
        return controlType;
    }

    public void setControlType(String controlType) {
        this.controlType = controlType;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getCycle() {
        return cycle;
    }

    public void setCycle(String cycle) {
        this.cycle = cycle;
    }

    public boolean isDeleteThisControl() {
        return deleteThisControl;
    }

    public void setDeleteThisControl(boolean deleteThisControl) {
        this.deleteThisControl = deleteThisControl;
    }

    public boolean isExistenceOfOccurrenceAssertion() {
        return existenceOfOccurrenceAssertion;
    }

    public void setExistenceOfOccurrenceAssertion(boolean existenceOfOccurrenceAssertion) {
        this.existenceOfOccurrenceAssertion = existenceOfOccurrenceAssertion;
    }

    public String getFraud() {
        return fraud;
    }

    public void setFraud(String fraud) {
        this.fraud = fraud;
    }

    public String getFrequency() {
        return frequency;
    }

    public void setFrequency(String frequency) {
        this.frequency = frequency;
    }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public boolean isModifiedThisControl() {
        return modifiedThisControl;
    }

    public void setModifiedThisControl(boolean modifiedThisControl) {
        this.modifiedThisControl = modifiedThisControl;
    }

    public boolean isOriginalEntity() {
        return originalEntity;
    }

    public void setOriginalEntity(boolean originalEntity) {
        this.originalEntity = originalEntity;
    }

    public boolean isPresentationAndDisclosureAssertion() {
        return presentationAndDisclosureAssertion;
    }

    public void setPresentationAndDisclosureAssertion(boolean presentationAndDisclosureAssertion) {
        this.presentationAndDisclosureAssertion = presentationAndDisclosureAssertion;
    }

    public String getPrevent() {
        return prevent;
    }

    public void setPrevent(String prevent) {
        this.prevent = prevent;
    }

    public boolean isRightAndObligationAssertion() {
        return rightAndObligationAssertion;
    }

    public void setRightAndObligationAssertion(boolean rightAndObligationAssertion) {
        this.rightAndObligationAssertion = rightAndObligationAssertion;
    }

    public String getRisk() {
        return risk;
    }

    public void setRisk(String risk) {
        this.risk = risk;
    }

    public String getSubcycle() {
        return subcycle;
    }

    public void setSubcycle(String subcycle) {
        this.subcycle = subcycle;
    }

    public String getSubcycleOwner() {
        return subcycleOwner;
    }

    public void setSubcycleOwner(String subcycleOwner) {
        this.subcycleOwner = subcycleOwner;
    }

    public String getSystem() {
        return system;
    }

    public void setSystem(String system) {
        this.system = system;
    }

    public String getTemplateCycleDescription() {
        return templateCycleDescription;
    }

    public void setTemplateCycleDescription(String templateCycleDescription) {
        this.templateCycleDescription = templateCycleDescription;
    }

    public boolean isValuationAndAllocationAssertion() {
        return valuationAndAllocationAssertion;
    }

    public void setValuationAndAllocationAssertion(boolean valuationAndAllocationAssertion) {
        this.valuationAndAllocationAssertion = valuationAndAllocationAssertion;
    }

    public int getRelationshipId() {
        return relationshipId;
    }

    public void setRelationshipId(int relationshipId) {
        this.relationshipId = relationshipId;
    }
}
