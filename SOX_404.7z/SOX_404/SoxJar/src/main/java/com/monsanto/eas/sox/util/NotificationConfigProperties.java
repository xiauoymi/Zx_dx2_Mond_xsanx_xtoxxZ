package com.monsanto.eas.sox.util;

public enum NotificationConfigProperties {
  EMAIL_TEMPLATE(".emailTemplate"),EMAIL_SUBJECT(".subject"),EMAIL_CONFIG_PREFIX ("email."), TLF_TEMPLATE(".tlfTemplate");
  private String code;

  NotificationConfigProperties(String code) {
    this.code = code;
  }

  public String getCode() {
    return code;
  }

  public void setCode(String code) {
    this.code = code;
  }
}
