package com.monsanto.eas.sox.model;

import org.hibernate.annotations.Cascade;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.Collection;

@Entity
@Table(schema = "SARBOX_ET", name = "FREQUENCY")
@NamedQueries({
        @NamedQuery(name = "lookupFrequencyByDescription", query = "FROM Frequency f WHERE f.description=:description"),
        @NamedQuery(name = "lookupAllFrequencies", query = "FROM Frequency f ORDER BY f.description")
})
public class Frequency {
    @javax.persistence.Column(name = "FREQUENCY_ID", nullable = false, insertable = true, updatable = true, length = 22, precision = 0)
    @Id
    private int frequencyId;

    @javax.persistence.Column(name = "DESCRIPTION", nullable = true, insertable = true, updatable = true, length = 250, precision = 0)
    @Basic
    private String description;

    @OneToMany(mappedBy = "frequency",fetch = FetchType.LAZY)
    @Cascade({org.hibernate.annotations.CascadeType.ALL})
    private Collection<SoxCtrlActivityEntity> soxCtrlActivityEntities= new ArrayList<SoxCtrlActivityEntity>();


    public int getFrequencyId() {
        return frequencyId;
    }

    public void setFrequencyId(int frequencyId) {
        this.frequencyId = frequencyId;
    }


    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }


    public Collection<SoxCtrlActivityEntity> getSoxCtrlActivityEntities() {
        return soxCtrlActivityEntities;
    }

    public void setSoxCtrlActivityEntities(Collection<SoxCtrlActivityEntity> soxCtrlActivityEntities) {
        this.soxCtrlActivityEntities = soxCtrlActivityEntities;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Frequency frequency = (Frequency) o;

        if (frequencyId != frequency.frequencyId) return false;
        if (description != null ? !description.equals(frequency.description) : frequency.description != null)
            return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = frequencyId;
        result = 31 * result + (description != null ? description.hashCode() : 0);
        return result;
    }

    public void addSoxCtrlActivityEntity(SoxCtrlActivityEntity soxCtrlActivityEntity){
        if(soxCtrlActivityEntity != null) {
            soxCtrlActivityEntity.setFrequency(this);
            soxCtrlActivityEntities.add(soxCtrlActivityEntity);
        }
    }
}
