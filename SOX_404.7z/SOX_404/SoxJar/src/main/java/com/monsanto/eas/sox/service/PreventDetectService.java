package com.monsanto.eas.sox.service;

import com.monsanto.eas.sox.model.PreventDetect;

public interface PreventDetectService {
    PreventDetect getPreventDetectByDescription(String description);
}
