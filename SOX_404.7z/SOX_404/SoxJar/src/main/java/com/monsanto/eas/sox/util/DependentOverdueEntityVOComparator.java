package com.monsanto.eas.sox.util;

import com.monsanto.eas.sox.model.DependentOverdueEntityVO;

import java.util.Comparator;

public class DependentOverdueEntityVOComparator implements Comparator<DependentOverdueEntityVO>{

    public enum FEATURES {PARENT_ENTITIES_AT_TOP, PARENT_ENTITIES_MIXED};
    private FEATURES sortFeatures;

    public DependentOverdueEntityVOComparator()
    {
        super();
        sortFeatures = FEATURES.PARENT_ENTITIES_MIXED;
    }

    public DependentOverdueEntityVOComparator(FEATURES sortFeatures)
    {
        super();
        this.sortFeatures = sortFeatures;
    }

    private String getEntityType(DependentOverdueEntityVO vo)
    {
        String entityType = "1";

        if (vo.getActivityId() != null && vo.getActivityId().trim().length() != 0)
        {
            entityType = "3";
        }
        else if (vo.getSubcycleId() != null && vo.getSubcycleId().trim().length() != 0)
        {
            entityType = "2";
        }

        return entityType;
    }

    private String getKey(DependentOverdueEntityVO vo)
    {
        StringBuffer key = new StringBuffer();
        if (vo != null)
        {
            if (sortFeatures == FEATURES.PARENT_ENTITIES_AT_TOP)
            {
                key.append(getEntityType(vo));
            }
            key.append(vo.getCycleId() == null ? "" : vo.getCycleId() + ".")
               .append(vo.getSubcycleId() == null ? "" : vo.getSubcycleId() + ".")
               .append(vo.getActivityId() == null ? "" : vo.getActivityId())
               .toString();
        }

        return key.toString();
    }

    @Override
    public int compare(DependentOverdueEntityVO source, DependentOverdueEntityVO target) {
        String sourceKey = getKey(source);
        String targetKey = getKey(target);
        int maxLength = sourceKey.length() > targetKey.length() ? sourceKey.length() : targetKey.length();
        if (maxLength != 0)
        {
            sourceKey = String.format("%1$-" + maxLength+ "s", sourceKey);
            targetKey = String.format("%1$-" + maxLength+ "s", targetKey);
        }

        if (source.getUserId() != null)
        {
            sourceKey += source.getUserId();
        }

        if (target.getUserId() != null)
        {
            targetKey += target.getUserId();
        }

        return sourceKey.compareTo(targetKey);
    }
}
