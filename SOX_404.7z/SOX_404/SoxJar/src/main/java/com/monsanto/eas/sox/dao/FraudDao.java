package com.monsanto.eas.sox.dao;

import com.monsanto.eas.sox.model.Fraud;

public interface FraudDao extends GenericDao<Fraud>{
    Fraud lookupFraudByDescription(String description);
}
