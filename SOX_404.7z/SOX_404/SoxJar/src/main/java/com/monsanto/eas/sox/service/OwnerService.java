/*
 Copyright:  Copyright � 2011 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.eas.sox.service;

import com.monsanto.eas.sox.model.SoxOwner;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author sspati1
 * @version $Revision$
 */
public interface OwnerService {
   //Collection<SoxOwner> lookupOwners();

   SoxOwner lookupOwnerByUserId(String userId);

   SoxOwner save(SoxOwner owner);
}