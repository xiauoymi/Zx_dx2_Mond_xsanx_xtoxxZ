package com.monsanto.eas.sox.jaxb;

import javax.xml.bind.annotation.*;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "activity")
@XmlRootElement(name = "Activity")
public class ActivityValidation {
    @XmlElement()
    public String controlId;
    @XmlElement()
    public String country;
    @XmlElement()
    public String cycle;
    @XmlElement()
    public String subcycle;
    @XmlElement()
    public String subcycleOwner;
    @XmlElement()
    public String existence;
    @XmlElement()
    public String completeness;
    @XmlElement()
    public String valuation;
    @XmlElement()
    public String right;
    @XmlElement()
    public String presentation;
    @XmlElement()
    public String risk;
    @XmlElement()
    public String control;
    @XmlElement()
    public String controlOwner;
    @XmlElement()
    public String controlOwnerLocation;
    @XmlElement()
    public String controlType;
    @XmlElement()
    public String frequency;
    @XmlElement()
    public String system;
    @XmlElement()
    public String prevent;
    @XmlElement()
    public String fraud;
    @XmlElement()
    public String key;

    public String getControlId() {
        return controlId;
    }

    public void setControlId(String controlId) {
        this.controlId = controlId;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getCycle() {
        return cycle;
    }

    public void setCycle(String cycle) {
        this.cycle = cycle;
    }

    public String getSubcycle() {
        return subcycle;
    }

    public void setSubcycle(String subcycle) {
        this.subcycle = subcycle;
    }

    public String getSubcycleOwner() {
        return subcycleOwner;
    }

    public void setSubcycleOwner(String subcycleOwner) {
        this.subcycleOwner = subcycleOwner;
    }

    public String getExistence() {
        return existence;
    }

    public void setExistence(String existence) {
        this.existence = existence;
    }

    public String getCompleteness() {
        return completeness;
    }

    public void setCompleteness(String completeness) {
        this.completeness = completeness;
    }

    public String getValuation() {
        return valuation;
    }

    public void setValuation(String valuation) {
        this.valuation = valuation;
    }

    public String getRight() {
        return right;
    }

    public void setRight(String right) {
        this.right = right;
    }

    public String getPresentation() {
        return presentation;
    }

    public void setPresentation(String presentation) {
        this.presentation = presentation;
    }

    public String getRisk() {
        return risk;
    }

    public void setRisk(String risk) {
        this.risk = risk;
    }

    public String getControl() {
        return control;
    }

    public void setControl(String control) {
        this.control = control;
    }

    public String getControlOwner() {
        return controlOwner;
    }

    public void setControlOwner(String controlOwner) {
        this.controlOwner = controlOwner;
    }

    public String getControlOwnerLocation() {
        return controlOwnerLocation;
    }

    public void setControlOwnerLocation(String controlOwnerLocation) {
        this.controlOwnerLocation = controlOwnerLocation;
    }

    public String getControlType() {
        return controlType;
    }

    public void setControlType(String controlType) {
        this.controlType = controlType;
    }

    public String getFrequency() {
        return frequency;
    }

    public void setFrequency(String frequency) {
        this.frequency = frequency;
    }

    public String getSystem() {
        return system;
    }

    public void setSystem(String system) {
        this.system = system;
    }

    public String getPrevent() {
        return prevent;
    }

    public void setPrevent(String prevent) {
        this.prevent = prevent;
    }

    public String getFraud() {
        return fraud;
    }

    public void setFraud(String fraud) {
        this.fraud = fraud;
    }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    @Override
    public String toString() {
        return "ActivityValidation{" +
                "controlId='" + controlId + '\'' +
                ", country='" + country + '\'' +
                ", cycle='" + cycle + '\'' +
                ", subcycle='" + subcycle + '\'' +
                ", subcycleOwner='" + subcycleOwner + '\'' +
                ", existence='" + existence + '\'' +
                ", completeness='" + completeness + '\'' +
                ", valuation='" + valuation + '\'' +
                ", right='" + right + '\'' +
                ", presentation='" + presentation + '\'' +
                ", risk='" + risk + '\'' +
                ", control='" + control + '\'' +
                ", controlOwner='" + controlOwner + '\'' +
                ", controlOwnerLocation='" + controlOwnerLocation + '\'' +
                ", controlType='" + controlType + '\'' +
                ", frequency='" + frequency + '\'' +
                ", system='" + system + '\'' +
                ", prevent='" + prevent + '\'' +
                ", fraud='" + fraud + '\'' +
                ", key='" + key + '\'' +
                '}';
    }
}
