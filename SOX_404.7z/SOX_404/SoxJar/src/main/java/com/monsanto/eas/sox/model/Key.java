package com.monsanto.eas.sox.model;

import org.hibernate.annotations.Cascade;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.Collection;

@Entity
@Table(schema = "SARBOX_ET", name = "KEY")
@NamedQueries({
        @NamedQuery(name = "lookupKeyByDescription", query = "FROM Key k WHERE k.description=:description")
})
public class Key {
    @javax.persistence.Column(name = "KEY_ID", nullable = false, insertable = true, updatable = true, length = 22, precision = 0)
    @Id
    private int keyId;

    @javax.persistence.Column(name = "DESCRIPTION", nullable = true, insertable = true, updatable = true, length = 250, precision = 0)
    @Basic
    private String description;

    @OneToMany(mappedBy = "key", fetch = FetchType.LAZY)
    @Cascade({org.hibernate.annotations.CascadeType.ALL})
    private Collection<SoxCtrlActivityEntity> soxCtrlActivityEntities= new ArrayList<SoxCtrlActivityEntity>();

    public int getKeyId() {
        return keyId;
    }

    public void setKeyId(int keyId) {
        this.keyId = keyId;
    }


    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Collection<SoxCtrlActivityEntity> getSoxCtrlActivityEntities() {
        return soxCtrlActivityEntities;
    }

    public void setSoxCtrlActivityEntities(Collection<SoxCtrlActivityEntity> soxCtrlActivityEntities) {
        this.soxCtrlActivityEntities = soxCtrlActivityEntities;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Key key = (Key) o;

        if (keyId != key.keyId) return false;
        if (description != null ? !description.equals(key.description) : key.description != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = keyId;
        result = 31 * result + (description != null ? description.hashCode() : 0);
        return result;
    }

    public void addSoxCtrlActivityEntity(SoxCtrlActivityEntity soxCtrlActivityEntity) {
        if (soxCtrlActivityEntity != null) {
            soxCtrlActivityEntity.setKey(this);
            soxCtrlActivityEntities.add(soxCtrlActivityEntity);
        }
    }
}
