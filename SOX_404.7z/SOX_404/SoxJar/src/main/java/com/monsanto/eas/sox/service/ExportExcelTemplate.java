package com.monsanto.eas.sox.service;

import com.google.common.base.Joiner;
import com.monsanto.eas.sox.model.*;
import com.monsanto.eas.sox.util.SoxConstants;
import org.apache.log4j.Logger;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.*;

@Service
public class ExportExcelTemplate {

   @Autowired
   private ControlEntityRelationShipService controlEntityRelationShipService;

   private Joiner joiner = Joiner.on(',').skipNulls();

   private final Logger logger = Logger.getLogger(ExportExcelTemplate.class);

   static final int ROW_HEADER_MONSANTO = 0;
   static final int ROW_HEADER_RISK_MATRIX = 1;
   static final int ROW_HEADER_CYCLE_DESC = 2;
   static final int ROW_HEADER_CYCLE_OWNER = 3;
   static final int ROW_TITLE = 6;
   static final int ROW_SUBTITLE = 7;
   static final int ROW_FIRST_DATA = 8;

   // 47 pixels
   static final int SMALL_COL_LENGTH = 256 * 7;
   // 84 pixels
   static final int MED_1_COL_LENGTH = 256 * 12;
   // 100 pixels
   static final int MED_2_COL_LENGTH = 256 * 14;
   // 125 pixels
   static final int MED_3_COL_LENGTH = 256 * 18;
   // 211 pixels
   static final int LARGE_1_COL_LENGTH = 256 * 30;
   // 299 pixels
   static final int LARGE_2_COL_LENGTH = 256 * 42;


   public ExportExcelTemplateVO exportTemplate(String periodId, String countryId, String cycleId, Collection<SoxControlEntity> activities) {

      SoxControlEntity cycle = null;
      if (activities != null && activities.size() > 0) {
         cycle = activities.iterator().next().getParentControlEntity().getParentControlEntity();
      }

      XSSFWorkbook template = new XSSFWorkbook();

      Map<String, XSSFCellStyle> styles = createStyles(template);
      XSSFSheet sheet = template.createSheet();

      sheet.setFitToPage(true);
      sheet.getPrintSetup().setFitWidth((short) 1);
      sheet.getPrintSetup().setFitHeight((short) 0);
      sheet.getPrintSetup().setLandscape(true);

      createHeader(sheet, styles, cycle);
      createContent(ROW_FIRST_DATA, sheet, styles, activities);

      Collection<SoxControlEntityRelationship> relatedActivities = null;
      relatedActivities = controlEntityRelationShipService.getRelatedActivitiesByCycle(cycle.getControlEntityId());

      createSupportContent(ROW_FIRST_DATA + activities.size(), sheet, styles, relatedActivities);

      byte[] fileBytes = null;
      try {
         ByteArrayOutputStream baos = new ByteArrayOutputStream();
         template.write(baos);
         fileBytes = baos.toByteArray();
      } catch (IOException ioException) {
         System.out.println("Error writing file to output");
      }

      ExportExcelTemplateVO exportExcelTemplateVO = new ExportExcelTemplateVO();

      exportExcelTemplateVO.setRetrievalStatusDescription("successful");
      exportExcelTemplateVO.setRetrievalSuccessful(true);
      exportExcelTemplateVO.setExcelTemplateByteArray(fileBytes);

      return exportExcelTemplateVO;
   }


   private void createHeader(XSSFSheet sheet, Map<String, XSSFCellStyle> styles, SoxControlEntity cycle) {
      String[] titles = {
              "Control Identification",
              "Assertions",
              "Control Attributes"
      };
      String[] subtitles = {
              "Control ID",
              "Country",
              "Cycle",
              "Subcycle",
              "Subcycle Owner",
              "Existence or Occurrence",
              "Completeness",
              "Valuation & Allocation",
              "Right & Obligation",
              "Presentation & Disclosure",
              "Risk",
              "Control",
              "Control Owner",
              "Type of Control (Application, IT Dependent, Manual)",
              "Frequency",
              "System",
              "Prevent / Detect",
              "Fraud (Yes/No)",
              "Key (Yes/No)"};

      XSSFCell cell = sheet.createRow(ROW_HEADER_MONSANTO).createCell(0);
      cell.setCellValue("Monsanto");

      cell = sheet.createRow(ROW_HEADER_RISK_MATRIX).createCell(0);
      cell.setCellValue("Risk and Control Matrix");
      if (cycle != null) {
         cell = sheet.createRow(ROW_HEADER_CYCLE_DESC).createCell(0);
         cell.setCellValue(cycle.getDescription());
         cell = sheet.createRow(ROW_HEADER_CYCLE_OWNER).createCell(0);
         cell.setCellValue(getActivityOwners(cycle));
      }

      XSSFRow titleRow = sheet.createRow(ROW_TITLE);
      XSSFRow subTitleRow = sheet.createRow(ROW_SUBTITLE);


      for (int i = 0; i < subtitles.length; i++) {
         (titleRow.createCell(i)).setCellStyle(styles.get("titleStyle"));
         cell = subTitleRow.createCell(i);
         if (i >= ExcelTemplateDescriptor.COL_OCURRENCE && i <= ExcelTemplateDescriptor.COL_PRESENTATION) {
            cell.setCellStyle(styles.get("subTitleVerStyle"));
            sheet.setColumnWidth(i, SMALL_COL_LENGTH);
         } else {
            cell.setCellStyle(styles.get("subTitleStyle"));
            if (i == ExcelTemplateDescriptor.COL_RISK) {
               sheet.setColumnWidth(i, LARGE_1_COL_LENGTH);
            } else if (i == ExcelTemplateDescriptor.COL_CONTROL) {
               sheet.setColumnWidth(i, LARGE_2_COL_LENGTH);
            } else if (i == ExcelTemplateDescriptor.COL_CYCLE || i == ExcelTemplateDescriptor.COL_COUNTRY || i == ExcelTemplateDescriptor.COL_KEY) {
               sheet.setColumnWidth(i, MED_1_COL_LENGTH);
            } else if (i == ExcelTemplateDescriptor.COL_CONTROL_TYPE || i == ExcelTemplateDescriptor.COL_FREQUENCY || i == ExcelTemplateDescriptor.COL_SYSTEM
                    || i == ExcelTemplateDescriptor.COL_FRAUD || i == ExcelTemplateDescriptor.COL_PREVENT) {
               sheet.setColumnWidth(i, MED_3_COL_LENGTH);
            } else {
               sheet.setColumnWidth(i, MED_2_COL_LENGTH);
            }

         }
         cell.setCellValue(subtitles[i]);
      }

      (titleRow.getCell(ExcelTemplateDescriptor.COL_CONTROL_ID)).setCellValue(titles[0]);
      (titleRow.getCell(ExcelTemplateDescriptor.COL_OCURRENCE)).setCellValue(titles[1]);
      (titleRow.getCell(ExcelTemplateDescriptor.COL_RISK)).setCellValue(titles[2]);

      sheet.addMergedRegion(new CellRangeAddress(ROW_TITLE, ROW_TITLE, ExcelTemplateDescriptor.COL_CONTROL_ID, ExcelTemplateDescriptor.COL_SUBCYCLE_OWNER));
      sheet.addMergedRegion(new CellRangeAddress(ROW_TITLE, ROW_TITLE, ExcelTemplateDescriptor.COL_OCURRENCE, ExcelTemplateDescriptor.COL_PRESENTATION));
      sheet.addMergedRegion(new CellRangeAddress(ROW_TITLE, ROW_TITLE, ExcelTemplateDescriptor.COL_RISK, ExcelTemplateDescriptor.COL_KEY));

   }

   private void createContent(int firstindex, XSSFSheet sheet, Map<String, XSSFCellStyle> styles, Collection<SoxControlEntity> activities) {
      int i = 0;
      try {
         for (SoxControlEntity activity : activities) {
            XSSFRow row = sheet.createRow(firstindex + i++);

            SoxControlEntity subCycle = activity.getParentControlEntity();
            SoxControlEntity cycle = subCycle.getParentControlEntity();

            Iterator<SoxCtrlActivityEntity> it2 = activity.getSoxCtrlActivityEntities().iterator();
            SoxCtrlActivityEntity ctrlActivityEntity = null;
            while (it2.hasNext()) {
               ctrlActivityEntity = it2.next();
            }

            for (int cellCol = 0; cellCol <= 18; cellCol++) {
               XSSFCell cell = row.createCell(cellCol);
               cell.setCellStyle(styles.get("border"));
            }

            Iterator<SoxCtrlActivityAssertion> it3 = ctrlActivityEntity.getSoxCtrlActivityAssertions().iterator();
            while (it3.hasNext()) {
               SoxCtrlActivityAssertion ctrlActivityAssertion = it3.next();
               if (ctrlActivityAssertion.getAssertion().getDescription().equals(SoxConstants.ASSERTION_EXISTENCE_OR_OCCURRENCE)) {
                  row.getCell(ExcelTemplateDescriptor.COL_OCURRENCE).setCellValue("X");
               } else if (ctrlActivityAssertion.getAssertion().getDescription().equals(SoxConstants.ASSERTION_COMPLETENESS)) {
                  row.getCell(ExcelTemplateDescriptor.COL_COMPLETNESS).setCellValue("X");
               } else if (ctrlActivityAssertion.getAssertion().getDescription().equals(SoxConstants.ASSERTION_VALUATION_AND_ALLOCATION)) {
                  row.getCell(ExcelTemplateDescriptor.COL_VALUATION).setCellValue("X");
               } else if (ctrlActivityAssertion.getAssertion().getDescription().equals(SoxConstants.ASSERTION_RIGHT_AND_OBLIGATION)) {
                  row.getCell(ExcelTemplateDescriptor.COL_RIGHT).setCellValue("X");
               } else if (ctrlActivityAssertion.getAssertion().getDescription().equals(SoxConstants.ASSERTION_PRESENTATION_AND_DISCLOSURE)) {
                  row.getCell(ExcelTemplateDescriptor.COL_PRESENTATION).setCellValue("X");
               }
            }

            //Activity ID
            String controlId = activity.getControlEntityId();
            controlId = controlId.substring(controlId.indexOf('.') + 1);
            row.getCell(ExcelTemplateDescriptor.COL_CONTROL_ID).setCellValue(controlId);

            row.getCell(ExcelTemplateDescriptor.COL_COUNTRY).setCellValue(getCountries(activity));
            row.getCell(ExcelTemplateDescriptor.COL_CYCLE).setCellValue(cycle.getDescription());
            row.getCell(ExcelTemplateDescriptor.COL_SUBCYCLE).setCellValue(subCycle.getDescription());
            row.getCell(ExcelTemplateDescriptor.COL_SUBCYCLE_OWNER).setCellValue(getActivityOwners(subCycle));
            row.getCell(ExcelTemplateDescriptor.COL_RISK).setCellValue(ctrlActivityEntity.getRisk());
            row.getCell(ExcelTemplateDescriptor.COL_CONTROL).setCellValue(activity.getDescription());
            row.getCell(ExcelTemplateDescriptor.COL_CONTROL_OWNER).setCellValue(getActivityOwners(activity));
            row.getCell(ExcelTemplateDescriptor.COL_CONTROL_TYPE).setCellValue(ctrlActivityEntity.getTypeOfControl() != null ? ctrlActivityEntity.getTypeOfControl().getDescription() : "");
            row.getCell(ExcelTemplateDescriptor.COL_FREQUENCY).setCellValue(ctrlActivityEntity.getFrequency() != null ? ctrlActivityEntity.getFrequency().getDescription() : "");
            row.getCell(ExcelTemplateDescriptor.COL_SYSTEM).setCellValue(getSoxSystems(ctrlActivityEntity));
            row.getCell(ExcelTemplateDescriptor.COL_PREVENT).setCellValue(ctrlActivityEntity.getPreventDetect() != null ? ctrlActivityEntity.getPreventDetect().getDescription() : "");
            row.getCell(ExcelTemplateDescriptor.COL_FRAUD).setCellValue(ctrlActivityEntity.getFraud() != null ? ctrlActivityEntity.getFraud().getDescription() : "No");
            row.getCell(ExcelTemplateDescriptor.COL_KEY).setCellValue(ctrlActivityEntity.getKey() != null ? ctrlActivityEntity.getKey().getDescription() : "No");
         }
      } catch (Exception ex) {
         logger.error("Error exporting the template", ex);
      }
   }

   protected void createSupportContent(int firstindex, XSSFSheet sheet, Map<String, XSSFCellStyle> styles, Collection<SoxControlEntityRelationship> activities) {
      int i = 0;
      try {
         for (SoxControlEntityRelationship activity : activities) {
            XSSFRow row = sheet.createRow(firstindex + i++);

            for (int cellCol = 0; cellCol <= 18; cellCol++) {
               XSSFCell cell = row.createCell(cellCol);
               cell.setCellStyle(styles.get("solidBorder"));
            }

            String relatedControlId = activity.getRelatedControlActivityId();
            relatedControlId = relatedControlId.substring(relatedControlId.indexOf('.') + 1);
            row.getCell(ExcelTemplateDescriptor.COL_CONTROL_ID).setCellValue(relatedControlId);
            row.getCell(ExcelTemplateDescriptor.COL_RISK).setCellValue(activity.getRisk());
            row.getCell(ExcelTemplateDescriptor.COL_CONTROL).setCellValue(activity.getEntity().getDescription());
         }
      } catch (Exception ex) {
         logger.error("Error exporting the template", ex);
      }
   }


   protected String getActivityOwners(SoxControlEntity activity) {
      Set<String> owners = new HashSet<String>();

      for (SoxControlEntityOwner soxControlEntityOwner : activity.getSoxControlEntityOwners()) {
         if (!soxControlEntityOwner.getSoxOwner().isNone())
            owners.add(soxControlEntityOwner.getSoxOwner().getUserId());
      }

      return joiner.join(owners);
   }

   protected String getCountries(SoxControlEntity activity) {
      Set<String> countries = new HashSet<String>();

      for (SoxCountry soxCountry : activity.getCountries()) {
         countries.add(soxCountry.getCountryDescription());
      }

      return joiner.join(countries);
   }

   private String getSoxSystems(SoxCtrlActivityEntity ctrlActivityEntity) {
      if (ctrlActivityEntity.getSoxSystems().isEmpty()) {
         return "N/A";
      }
      return ctrlActivityEntity.getSoxSystemsAsString(",");
   }

   /**
    * create a library of cell styles
    */
   protected static Map<String, XSSFCellStyle> createStyles(XSSFWorkbook wb) {
      Map<String, XSSFCellStyle> styles = new HashMap<String, XSSFCellStyle>();

      XSSFCellStyle style;

      XSSFFont headerFont = wb.createFont();
      headerFont.setBoldweight(XSSFFont.BOLDWEIGHT_BOLD);

      style = createBorderedStyle(wb);
      style.setAlignment(CellStyle.ALIGN_CENTER);
      style.setFillForegroundColor(IndexedColors.LIGHT_CORNFLOWER_BLUE.getIndex());
      style.setFillPattern(CellStyle.SOLID_FOREGROUND);
      style.setFont(headerFont);
      styles.put("header", style);

      style = createStrongBorderedStyle(wb);
      style.setAlignment(CellStyle.ALIGN_CENTER);
      style.setFillPattern(CellStyle.SOLID_FOREGROUND);
      style.setFillForegroundColor(IndexedColors.GREY_50_PERCENT.getIndex());
      style.setFont(headerFont);
      style.setWrapText(true);
      styles.put("titleStyle", style);

      style = createBorderedStyle(wb);
      style.setAlignment(CellStyle.ALIGN_CENTER);
      style.setFillPattern(CellStyle.SOLID_FOREGROUND);
      style.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.getIndex());
      style.setFont(headerFont);
      style.setWrapText(true);
      styles.put("subTitleStyle", style);

      style = createBorderedStyle(wb);
      style.setAlignment(CellStyle.ALIGN_CENTER);
      style.setFillPattern(CellStyle.SOLID_FOREGROUND);
      style.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.getIndex());
      style.setFont(headerFont);
      style.setWrapText(true);
      style.setRotation((short) 90);
      styles.put("subTitleVerStyle", style);

      style = createBorderedStyle(wb);
      style.setWrapText(true);
      styles.put("border", style);

      style = createBorderedStyle(wb);
      style.setWrapText(true);
      style.setFillPattern(CellStyle.SOLID_FOREGROUND);
      style.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.getIndex());
      styles.put("solidBorder", style);


      return styles;
   }

   private static XSSFCellStyle createBorderedStyle(XSSFWorkbook wb) {
      XSSFCellStyle style = wb.createCellStyle();
      style.setBorderRight(CellStyle.BORDER_THIN);
      style.setRightBorderColor(IndexedColors.BLACK.getIndex());
      style.setBorderBottom(CellStyle.BORDER_THIN);
      style.setBottomBorderColor(IndexedColors.BLACK.getIndex());
      style.setBorderLeft(CellStyle.BORDER_THIN);
      style.setLeftBorderColor(IndexedColors.BLACK.getIndex());
      style.setBorderTop(CellStyle.BORDER_THIN);
      style.setTopBorderColor(IndexedColors.BLACK.getIndex());
      return style;
   }

   private static XSSFCellStyle createStrongBorderedStyle(XSSFWorkbook wb) {
      XSSFCellStyle style = wb.createCellStyle();
      style.setBorderRight(CellStyle.BORDER_MEDIUM);
      style.setRightBorderColor(IndexedColors.BLACK.getIndex());
      style.setBorderBottom(CellStyle.BORDER_MEDIUM);
      style.setBottomBorderColor(IndexedColors.BLACK.getIndex());
      style.setBorderLeft(CellStyle.BORDER_MEDIUM);
      style.setLeftBorderColor(IndexedColors.BLACK.getIndex());
      style.setBorderTop(CellStyle.BORDER_MEDIUM);
      style.setTopBorderColor(IndexedColors.BLACK.getIndex());
      return style;
   }

}

