package com.monsanto.eas.sox.util;

import com.monsanto.eas.sox.model.SoxControlEntity;

public enum ControlEntityType {
     CYCLE, SUB_CYCLE, ACTIVITY;

    public static ControlEntityType getEntityType(SoxControlEntity entity)
    {
        ControlEntityType entityType = ControlEntityType.CYCLE;

        if (entity.getParentControlEntity() != null)
        {
            if (entity.getParentControlEntity().getParentControlEntity() != null)
            {
                entityType = ControlEntityType.ACTIVITY;
            }
            else
            {
                entityType = ControlEntityType.SUB_CYCLE;
            }
        }

        return entityType;
    }


}
