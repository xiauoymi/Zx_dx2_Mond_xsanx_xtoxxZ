package com.monsanto.eas.sox.model;

import javax.persistence.*;

@Table(name = "SOX_CTRL_ACTIVITY_ASSERTIONS", schema = "SARBOX_ET")
@Entity
public class SoxCtrlActivityAssertion {

    @Id
    @SequenceGenerator(name = "soxCtrlActAssertionSeq", sequenceName = "SARBOX_ET.SOX_CTRL_ACT_ASSERTION_SEQ")
    @GeneratedValue(generator = "soxCtrlActAssertionSeq", strategy = GenerationType.SEQUENCE)
    @javax.persistence.Column(name = "CTRL_ACTIVITY_ASSERTIONS_ID", nullable = false, insertable = true, updatable = true, length = 22, precision = 0)
    private int ctrlActivityAssertionsId;

    @ManyToOne(cascade = CascadeType.ALL)
    @javax.persistence.JoinColumn(name = "ASSERTION_ID")
    private Assertion assertion;

    @ManyToOne
    @javax.persistence.JoinColumn(name = "CONTROL_ACTIVITY_ID")
    private SoxCtrlActivityEntity soxCtrlActivityEntity;

    public int getCtrlActivityAssertionsId() {
        return ctrlActivityAssertionsId;
    }

    public void setCtrlActivityAssertionsId(int ctrlActivityAssertionsId) {
        this.ctrlActivityAssertionsId = ctrlActivityAssertionsId;
    }


    public Assertion getAssertion() {
        return assertion;
    }

    public void setAssertion(Assertion assertion) {
        this.assertion = assertion;
    }

    public SoxCtrlActivityEntity getSoxCtrlActivityEntity() {
        return soxCtrlActivityEntity;
    }

    public void setSoxCtrlActivityEntity(SoxCtrlActivityEntity soxCtrlActivityEntity) {
        this.soxCtrlActivityEntity = soxCtrlActivityEntity;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        SoxCtrlActivityAssertion that = (SoxCtrlActivityAssertion) o;

//        if (assertionId != that.assertionId) return false;
//        if (controlActivityId != that.controlActivityId) return false;
        if (ctrlActivityAssertionsId != that.ctrlActivityAssertionsId) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = ctrlActivityAssertionsId;
//        result = 31 * result + controlActivityId;
//        result = 31 * result + assertionId;
        return result;
    }
}
