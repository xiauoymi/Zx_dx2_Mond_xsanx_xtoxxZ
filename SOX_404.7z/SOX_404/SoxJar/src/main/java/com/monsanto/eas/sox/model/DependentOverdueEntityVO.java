package com.monsanto.eas.sox.model;

import java.util.Date;

public class DependentOverdueEntityVO {

    private String controlEntityId;
    private String userId;
    private Date startDate;
    private Date endDate;
    private String cycleId = "";
    private String subcycleId = "";
    private String activityId = "";
    private String status;
    private String entityType;
    private String dueDate = "";
    private int controlEntityOwnerId;
    private String firstName;
    private String lastName;

    public DependentOverdueEntityVO() {
        super();
    }

    public DependentOverdueEntityVO(String controlEntityId, String userId, Date startDate, Date endDate, int controlEntityOwnerId, String parentId, String grandParentId) {
        super();
        this.controlEntityId = controlEntityId;
        this.userId = userId;
        this.startDate = startDate;
        this.endDate = endDate;
        this.controlEntityOwnerId = controlEntityOwnerId;

        if (parentId == null) {
            entityType = "C";
            cycleId = controlEntityId;
        } else if (parentId != null && grandParentId != null) {
            entityType = "ACT";
            activityId = controlEntityId;
            subcycleId = parentId;
            cycleId = grandParentId;
        } else {
            entityType = "SC";
            subcycleId = controlEntityId;
            cycleId = parentId;
        }
        if (endDate != null) {
            dueDate = String.format("%1$tm/%1$te/%1$tY", endDate);
        }
    }

    public int getControlEntityOwnerId() {
        return controlEntityOwnerId;
    }

    public void setControlEntityOwnerId(int controlEntityOwnerId) {
        this.controlEntityOwnerId = controlEntityOwnerId;
    }

    public String getControlEntityId() {
        return controlEntityId;
    }

    public void setControlEntityId(String controlEntityId) {
        this.controlEntityId = controlEntityId;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public Date getStartDate() {
        return startDate;
    }

    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    public Date getEndDate() {
        return endDate;
    }

    public void setEndDate(Date endDate) {
        this.endDate = endDate;
        if (endDate != null) {
            dueDate = String.format("%1$tm/%1$te/$1$tY", endDate);
        }
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getCycleId() {
        return cycleId;
    }

    public void setCycleId(String cycleId) {
        this.cycleId = cycleId;
    }

    public String getSubcycleId() {
        return subcycleId;
    }

    public void setSubcycleId(String subcycleId) {
        this.subcycleId = subcycleId;
    }

    public String getActivityId() {
        return activityId;
    }

    public void setActivityId(String activityId) {
        this.activityId = activityId;
    }

    public String getDueDate() {
        return dueDate;
    }

    public void setDueDate(String dueDate) {
        this.dueDate = dueDate;
    }

    public String getEntityType() {
        return entityType;
    }

    public void setEntityType(String entityType) {
        this.entityType = entityType;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    @Override
    public String toString() {
        return "DependentOverdueEntityVO{" +
                "controlEntityId='" + controlEntityId + '\'' +
                ", userId='" + userId + '\'' +
                ", startDate=" + startDate +
                ", endDate=" + endDate +
                ", cycleId='" + cycleId + '\'' +
                ", subcycleId='" + subcycleId + '\'' +
                ", activityId='" + activityId + '\'' +
                ", status='" + status + '\'' +
                ", entityType='" + entityType + '\'' +
                ", controlEntityOwnerId=" + controlEntityOwnerId +
                '}';
    }
}
