package com.monsanto.eas.sox.model;

import org.hibernate.annotations.Cascade;

import javax.persistence.*;
import java.util.Collection;
import java.util.HashSet;
import java.util.Set;

@Table(name = "SOX_CONTROL_ENTITY_OWNER", schema = "SARBOX_ET")
@Entity
public class SoxControlEntityOwner {
    @Id
    @SequenceGenerator(name = "soxControlEntityOwnerSeq", sequenceName = "SARBOX_ET.SOX_CTRL_ENTITY_OWNER_SEQ")
    @GeneratedValue(generator = "soxControlEntityOwnerSeq", strategy = GenerationType.SEQUENCE)
    @javax.persistence.Column(name = "CONTROL_ENTITY_OWNER_ID", nullable = false, insertable = true, updatable = true, length = 22, precision = 0)
    private int controlEntityOwnerId;

//    @javax.persistence.Column(name = "CONTROL_ENTITY_ID", nullable = true, insertable = false, updatable = false, length = 22, precision = 0)
//    @Basic
//    private int controlEntityId;
    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "CONTROL_ENTITY_ID")
    private SoxControlEntity soxControlEntity;

//    @javax.persistence.Column(name = "OWNER_ID", nullable = true, insertable = false, updatable = false, length = 22, precision = 0)
//    @Basic
//    private int ownerId;
    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "OWNER_ID")
    private SoxOwner soxOwner;

//    @javax.persistence.Column(name = "COUNTRY_ID", nullable = true, insertable = false, updatable = false, length = 22, precision = 0)
//    @Basic
//    private int countryId;
    @ManyToOne
    @JoinColumn(name = "COUNTRY_ID")
    private SoxCountry soxCountry;

    @OneToMany(mappedBy = "soxControlEntityOwner", fetch = FetchType.LAZY)
    @Cascade({org.hibernate.annotations.CascadeType.ALL})
    private Set<SoxResponse> soxResponses= new HashSet<SoxResponse>();

    @OneToMany(mappedBy = "soxControlEntityOwner", fetch = FetchType.LAZY)
    @Cascade({org.hibernate.annotations.CascadeType.ALL})
    private Set<SoxSignificantChange> soxSignificantChanges= new HashSet<SoxSignificantChange>();

    public Set<SoxSignificantChange> getSoxSignificantChanges() {
        return soxSignificantChanges;
    }

    public void setSoxSignificantChanges(Set<SoxSignificantChange> soxSignificantChanges) {
        this.soxSignificantChanges = soxSignificantChanges;
    }

    public int getControlEntityOwnerId() {
        return controlEntityOwnerId;
    }

    public void setControlEntityOwnerId(int controlEntityOwnerId) {
        this.controlEntityOwnerId = controlEntityOwnerId;
    }

    public SoxControlEntity getSoxControlEntity() {
        return soxControlEntity;
    }

    public void setSoxControlEntity(SoxControlEntity soxControlEntity) {
        this.soxControlEntity = soxControlEntity;
    }

    public SoxOwner getSoxOwner() {
        return soxOwner;
    }

    public void setSoxOwner(SoxOwner soxOwner) {
        this.soxOwner = soxOwner;
    }

    public SoxCountry getSoxCountry() {
        return soxCountry;
    }

    public void setSoxCountry(SoxCountry soxCountry) {
        this.soxCountry = soxCountry;
    }

    public Collection<SoxResponse> getSoxResponses() {
        return soxResponses;
    }

    public void setSoxResponses(Set<SoxResponse> soxResponses) {
        this.soxResponses = soxResponses;
    }

    public void addSoxResponse(SoxResponse soxResponse){
        if(soxResponse != null) {
            soxResponse.setSoxControlEntityOwner(this);
            soxResponses.add(soxResponse);
        }
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        SoxControlEntityOwner that = (SoxControlEntityOwner) o;

//        if (controlEntityId != that.controlEntityId) return false;
        if (controlEntityOwnerId != that.controlEntityOwnerId) return false;

        if(soxCountry != null && that.soxCountry != null) {
            return soxCountry.equals(that.soxCountry);
        }

        if (soxOwner != null && that.soxOwner !=null) {
           return soxOwner.equals(that.soxOwner);
        }
        if(soxControlEntity != null && that.soxControlEntity !=null) {
            return soxControlEntity.equals(that.soxControlEntity);
        }

        return true;
    }

    @Override
    public int hashCode() {
        int result = controlEntityOwnerId;
        result = result + (soxOwner != null ? soxOwner.hashCode() : 0);
//        result = 31 * result + controlEntityId;
//        result = 31 * result + ownerId;
//        result = 31 * result + countryId;
        return result;
    }

    @Override
    public String toString() {
        return "SoxControlEntityOwner{" +
                "controlEntityOwnerId=" + controlEntityOwnerId +
//                ", soxControlEntity=" + soxControlEntity +
//                ", soxOwner=" + soxOwner +
//                ", soxCountry=" + soxCountry +
//                ", soxResponsesByControlEntityOwnerId=" + soxResponsesByControlEntityOwnerId +
                '}';
    }
} // end of class
