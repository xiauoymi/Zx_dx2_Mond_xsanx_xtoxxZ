package com.monsanto.eas.sox.dao;

import com.monsanto.eas.sox.model.DelinquentReportVO;

import java.util.Collection;

public interface DelinquentReportDao extends GenericDao<DelinquentReportVO>{
    Collection<DelinquentReportVO> lookupDelinquentOwnersByPeriod(String periodId);
}
