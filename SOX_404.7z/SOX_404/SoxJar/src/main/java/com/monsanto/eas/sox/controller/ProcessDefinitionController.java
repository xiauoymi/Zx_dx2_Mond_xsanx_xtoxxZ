package com.monsanto.eas.sox.controller;


import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public abstract class ProcessDefinitionController  {

    protected abstract void executeProcessDefinition(HttpServletRequest request, HttpServletResponse response)throws Exception;

    @RequestMapping(method = RequestMethod.POST)
    protected ModelAndView onSubmit(HttpServletRequest request,HttpServletResponse response) throws Exception {
            executeProcessDefinition(request,response);
		return null;
	}
} // end of class
