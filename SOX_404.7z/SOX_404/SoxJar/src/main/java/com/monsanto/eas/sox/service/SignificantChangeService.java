package com.monsanto.eas.sox.service;

import com.monsanto.eas.sox.model.SoxSignificantChange;

import java.util.Collection;

public interface SignificantChangeService {

   void deleteSignificantChangeWithoutReferences();

   Collection<SoxSignificantChange> getSignificantChangeByEntityAndOwner(String controlEntityId, String userId);

   Collection<SoxSignificantChange> saveOrUpdate(String controlEntityId, String userId, Collection<SoxSignificantChange> significantChanges);

}
