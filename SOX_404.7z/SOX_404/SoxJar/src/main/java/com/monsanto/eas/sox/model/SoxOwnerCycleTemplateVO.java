package com.monsanto.eas.sox.model;

import com.google.common.base.Splitter;
import com.google.common.collect.Lists;

import java.util.ArrayList;
import java.util.Collection;

/**
 * Created by FJADAN on 3/14/14.
 */
public class SoxOwnerCycleTemplateVO {

    private String controlEntityId;
    private String originalActivitiesOwner;
    private String newActivitiesOwner;

    private Splitter splitter = Splitter.on(',').omitEmptyStrings().trimResults();

    public SoxOwnerCycleTemplateVO() {
    }

    public Collection<String> getCommaSeparatedListAsCollection(String list) {
        if (list != null && list.trim().length() > 0) {
            return Lists.newArrayList(splitter.split(list));
        }

        return new ArrayList<String>();
    }

    public boolean hasActivitiesOwnerChanged() {
        Collection<String> originalOwnersId = getCommaSeparatedListAsCollection(originalActivitiesOwner);
        Collection<String> newOwnersId = getCommaSeparatedListAsCollection(newActivitiesOwner);

        if (originalOwnersId.size() == newOwnersId.size()) {
            for (String owner : originalOwnersId) {
                if (!newOwnersId.contains(owner)) {
                    return true;
                }
            }
        } else {
            return true;
        }

        return false;
    }

    public String getOriginalActivitiesOwner() {
        return originalActivitiesOwner;
    }

    public void setOriginalActivitiesOwner(String originalActivitiesOwner) {
        this.originalActivitiesOwner = originalActivitiesOwner;
    }

    public String getNewActivitiesOwner() {
        return newActivitiesOwner;
    }

    public void setNewActivitiesOwner(String newActivitiesOwner) {
        this.newActivitiesOwner = newActivitiesOwner;
    }

    public String getControlEntityId() {
        return controlEntityId;
    }

    public void setControlEntityId(String controlEntityId) {
        this.controlEntityId = controlEntityId;
    }
}
