package com.monsanto.eas.sox.dao.impl;

import com.monsanto.eas.sox.dao.FrequencyDao;
import com.monsanto.eas.sox.model.Frequency;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.util.Collection;
import java.util.List;

@Repository
public class FrequencyDaoImpl extends GenericDaoImpl<Frequency> implements FrequencyDao {
   private static final long serialVersionUID = 1L;

   @PersistenceContext
   private EntityManager entityManager;

   @Override
   public Frequency lookupFrequencyByDescription(String description) {
      Frequency frequency = null;

      List<Frequency> frequencyList = entityManager.createNamedQuery("lookupFrequencyByDescription").setParameter("description", description).getResultList();
      if (frequencyList != null && frequencyList.size() > 0) {
         frequency = frequencyList.get(0);
      } else {
         frequency = null;
      }
      return frequency;
   }

   @Override
   public Collection<Frequency> lookupAllFrequencies() {
      List<Frequency> frequencyList = entityManager.createNamedQuery("lookupAllFrequencies").getResultList();
      if (frequencyList != null && frequencyList.size() > 0) {
         for (Frequency frequency : frequencyList) {
            frequency.setSoxCtrlActivityEntities(null);
         }
      }
      return frequencyList;
   }
}
