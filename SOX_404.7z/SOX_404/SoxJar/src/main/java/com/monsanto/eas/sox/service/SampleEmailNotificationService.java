package com.monsanto.eas.sox.service;

import com.monsanto.eas.sox.model.EmailNotificationTemplateVO;

public interface SampleEmailNotificationService {
    String sendEmail(EmailNotificationTemplateVO emailNotificationTemplateVO);
    String save(EmailNotificationTemplateVO emailNotificationTemplateVO);
    EmailNotificationTemplateVO getEmailNotificationTemplate(String notificationType);
}
