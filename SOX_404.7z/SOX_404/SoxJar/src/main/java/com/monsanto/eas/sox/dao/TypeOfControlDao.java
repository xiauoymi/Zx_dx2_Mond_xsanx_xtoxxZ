package com.monsanto.eas.sox.dao;

import com.monsanto.eas.sox.model.TypeOfControl;

public interface TypeOfControlDao extends GenericDao<TypeOfControl>{
    TypeOfControl lookupTypeOfControlByDescription(String description);
}
