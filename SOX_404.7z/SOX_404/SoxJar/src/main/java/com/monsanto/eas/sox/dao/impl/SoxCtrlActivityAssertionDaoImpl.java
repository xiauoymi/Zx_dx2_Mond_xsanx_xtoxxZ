package com.monsanto.eas.sox.dao.impl;

import com.monsanto.eas.sox.dao.SoxCtrlActivityAssertionDao;
import com.monsanto.eas.sox.model.SoxCtrlActivityAssertion;
import org.springframework.stereotype.Repository;

@Repository
public class SoxCtrlActivityAssertionDaoImpl extends GenericDaoImpl<SoxCtrlActivityAssertion> implements SoxCtrlActivityAssertionDao {

}
