package com.monsanto.eas.sox.service.impl;

import com.monsanto.eas.sox.dao.JdbcBatchTransactionDao;
import com.monsanto.eas.sox.model.BatchTransactionVO;
import com.monsanto.eas.sox.service.BatchTransactionService;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.flex.remoting.RemotingDestination;
import org.springframework.jdbc.UncategorizedSQLException;
import org.springframework.stereotype.Service;

@Service
@RemotingDestination(value = "batchTransactionService")
public class BatchTransactionServiceImpl implements BatchTransactionService {

    private final Logger logger = Logger.getLogger(BatchTransactionServiceImpl.class);

    @Autowired
    private JdbcBatchTransactionDao jdbcBatchTransactionDao;

    @Override
    public String save(String transactionLog, String deleteOwner, String deleteResponse) {
        //transactionLog = transactionLog.replace(']', '�');
        BatchTransactionVO batchTransactionVO = new BatchTransactionVO(transactionLog, deleteOwner, deleteResponse);
        return save(batchTransactionVO);
    }

    @Override
    public String save(BatchTransactionVO batchTransactionVO) {
        String response = "";

        try {
            jdbcBatchTransactionDao.save(batchTransactionVO);
        }
        catch (UncategorizedSQLException e) {
            if (e.getRootCause() != null && e.getRootCause().getMessage() != null) {
                response = e.getRootCause().getMessage().substring("ORA-20000: ".length());
                if (response.contains("\n")) {
                    response = response.substring(0, response.indexOf("\n"));
                }
            }
        }
        catch (Exception e) {
            response = e.getMessage();

            logger.error("Error saving the transaction", e);
        }

        return response;
    }
}
