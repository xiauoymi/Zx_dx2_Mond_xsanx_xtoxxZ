package com.monsanto.eas.sox.service;

import com.monsanto.eas.sox.model.DelinquentReportVO;
import com.monsanto.eas.sox.model.GapReportVO;
import com.monsanto.eas.sox.model.OwnerStatusReportVO;
import flex.messaging.io.amf.ASObject;
import org.apache.log4j.Logger;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.VerticalAlignment;
import org.apache.poi.xssf.usermodel.*;
import org.springframework.stereotype.Service;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.*;

@Service
public class ExportToExcelReportService {
    private final Logger logger = Logger.getLogger(ExportToExcelReportService.class);
    private static final int ROW_HEADERS_REPORT = 1;
    private static final int FIRST_ROW_DATA = 2;
    private static final String HEADER = "header";
    private static final String NEW_OWNER = "newOwner";
    private static final String OWNER = "owner";
    private static final String TRANSACTION = "transaction";
    private static final String MOD_DATE = "modDate";
    private static final String CONTROL_ENTITY_ID = "controlEntityId";
    private static final String MOD_USER = "modUser";
    private static final String MODIFICATION = "modification";
    private static final String DEFAULT_STYLE = "border";
    private static final String DELINQUENT = "Delinquent";
    private static final String LEVEL_HEADER = "Level";
    private static final String CONTROL_HEADER = "Control";
    private static final String OWNER_HEADER = "Owner";
    private static final String FIRST_NAME_HEADER = "First Name";
    private static final String LAST_NAME_HEADER = "Last Name";
    private static final String REGION_HEADER = "Region";
    private static final String DUE_DATE_HEADER = "Due Date";
    private static final String DESCRIPTION_HEADER = "Description";
    private static final String TRANSACTION_HEADER = "Transaction";
    private static final String ORIGINAL_OWNER_HEADER = "Original Owner";
    private static final String NEW_OWNER_HEADER = "New Owner";
    private static final String MODIFIED_BY_HEADER = "Modified by";
    private static final String MODIFIED_DATE_HEADER = "Modified Date";
    private static final String MODIFIED_DATA_HEADER = "Modified Data";
    private static final String[] HEADERS_DELINQUENT_REPORT = {LEVEL_HEADER, CONTROL_HEADER, OWNER_HEADER, FIRST_NAME_HEADER, LAST_NAME_HEADER, REGION_HEADER, DUE_DATE_HEADER, DESCRIPTION_HEADER};
    private static final String[] HEADERS_GAP_REPORT = {CONTROL_HEADER, OWNER_HEADER, FIRST_NAME_HEADER, LAST_NAME_HEADER, REGION_HEADER, DESCRIPTION_HEADER};
    private static final String[] HEADERS_OWNER_STATUS_REPORT = {CONTROL_HEADER, OWNER_HEADER, FIRST_NAME_HEADER, LAST_NAME_HEADER, REGION_HEADER, "Status", DESCRIPTION_HEADER};
    private static final String[] HEADERS_OWNER_CHANGE_REPORT = {TRANSACTION_HEADER, CONTROL_HEADER, ORIGINAL_OWNER_HEADER, NEW_OWNER_HEADER, MODIFIED_BY_HEADER, MODIFIED_DATE_HEADER};
    private static final String[] HEADERS_TEMPLATE_CHANGE_REPORT = {TRANSACTION_HEADER, CONTROL_HEADER, ORIGINAL_OWNER_HEADER, NEW_OWNER_HEADER, MODIFIED_BY_HEADER, MODIFIED_DATE_HEADER, MODIFIED_DATA_HEADER};
    private static final int[] DELINQUENT_COL_WIDTH = {3000, 5000, 5000, 5000, 7000, 12000, 5000, 30000};
    private static final int[] GAP_COL_WIDTH = {5000, 5000, 5000, 7000, 12000, 25000};
    private static final int[] OWNER_STATUS_COL_WIDTH = {5000, 5000, 5000, 7000, 12000, 5000, 35000};
    private static final int[] OWNER_CHANGE_COL_WIDTH = {5000, 5000, 7000, 7000, 7000, 8000};
    private static final int[] TEMPLATE_CHANGE_COL_WIDTH = {5000, 5000, 5000, 5000, 7000, 7000, 7000, 8000};

    private interface ReportHeaderCreator {
        void createHeader(XSSFSheet sheet, Map<String, XSSFCellStyle> styles);
    }

    private static final ReportHeaderCreator DELINQUENT_HEADER_CREATOR = new ReportHeaderCreator() {
        @Override
        public void createHeader(XSSFSheet sheet, Map<String, XSSFCellStyle> styles) {
            for(int j=0;j<HEADERS_DELINQUENT_REPORT.length;j++) {
                sheet.setColumnWidth(j, DELINQUENT_COL_WIDTH[j]);
                sheet.getRow(ROW_HEADERS_REPORT).createCell(j).setCellStyle(styles.get(HEADER));
                sheet.getRow(ROW_HEADERS_REPORT).getCell(j).setCellValue(HEADERS_DELINQUENT_REPORT[j]);
            }
        }
    };

    private static final ReportHeaderCreator GAP_HEADER_CREATOR = new ReportHeaderCreator() {
        @Override
        public void createHeader(XSSFSheet sheet, Map<String, XSSFCellStyle> styles) {
            for(int j=0;j<HEADERS_GAP_REPORT.length;j++) {
                sheet.setColumnWidth(j, GAP_COL_WIDTH[j]);
                sheet.getRow(ROW_HEADERS_REPORT).createCell(j).setCellStyle(styles.get(HEADER));
                sheet.getRow(ROW_HEADERS_REPORT).getCell(j).setCellValue(HEADERS_GAP_REPORT[j]);
            }
        }
    };

    private static final ReportHeaderCreator OWNER_STATUS_HEADER_CREATOR = new ReportHeaderCreator() {
        @Override
        public void createHeader(XSSFSheet sheet, Map<String, XSSFCellStyle> styles) {
            for(int j=0;j< HEADERS_OWNER_STATUS_REPORT.length;j++) {
                sheet.setColumnWidth(j, OWNER_STATUS_COL_WIDTH[j]);
                sheet.getRow(ROW_HEADERS_REPORT).createCell(j).setCellStyle(styles.get(HEADER));
                sheet.getRow(ROW_HEADERS_REPORT).getCell(j).setCellValue(HEADERS_OWNER_STATUS_REPORT[j]);
            }
        }
    };

    private static final ReportHeaderCreator OWNER_CHANGE_HEADER_CREATOR = new ReportHeaderCreator() {
        @Override
        public void createHeader(XSSFSheet sheet, Map<String, XSSFCellStyle> styles) {
            for(int j=0;j< HEADERS_OWNER_CHANGE_REPORT.length;j++) {
                sheet.setColumnWidth(j, OWNER_CHANGE_COL_WIDTH[j]);
                sheet.getRow(ROW_HEADERS_REPORT).createCell(j).setCellStyle(styles.get(HEADER));
                sheet.getRow(ROW_HEADERS_REPORT).getCell(j).setCellValue(HEADERS_OWNER_CHANGE_REPORT[j]);
            }
        }
    };

    private static final ReportHeaderCreator TEMPLATE_CHANGE_HEADER_CREATOR = new ReportHeaderCreator() {
        @Override
        public void createHeader(XSSFSheet sheet, Map<String, XSSFCellStyle> styles) {
            for(int j=0;j< HEADERS_TEMPLATE_CHANGE_REPORT.length;j++) {
                sheet.setColumnWidth(j, TEMPLATE_CHANGE_COL_WIDTH[j]);
                sheet.getRow(ROW_HEADERS_REPORT).createCell(j).setCellStyle(styles.get(HEADER));
                sheet.getRow(ROW_HEADERS_REPORT).getCell(j).setCellValue(HEADERS_TEMPLATE_CHANGE_REPORT[j]);
            }
        }
    };

    private static final Map<String, ReportHeaderCreator> HEADER_CREATORS = new HashMap<String, ReportHeaderCreator>(){{
        put(DELINQUENT,       DELINQUENT_HEADER_CREATOR);
        put("Gap",            GAP_HEADER_CREATOR);
        put("OwnerStatus",    OWNER_STATUS_HEADER_CREATOR);
        put("OwnerChange",    OWNER_CHANGE_HEADER_CREATOR);
        put("TemplateChange", TEMPLATE_CHANGE_HEADER_CREATOR);
    }};

    public byte[] getExcelFile(String reportName, Collection<Object> collection) {
        XSSFWorkbook report = new XSSFWorkbook();
        Map<String, XSSFCellStyle> styles = createStyles(report);
        XSSFSheet sheet = report.createSheet();

        sheet.setFitToPage(true);
        sheet.getPrintSetup().setFitWidth((short)1);
        sheet.getPrintSetup().setFitHeight((short)0);
        sheet.getPrintSetup().setLandscape(true);

        createContent(reportName, FIRST_ROW_DATA, sheet, styles, collection);

        byte[] fileBytes = null;
        try {
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            report.write(baos);
            fileBytes = baos.toByteArray();
        } catch(IOException e) {
            logger.error("Error writing the File", e);
        }

        return fileBytes;
    }

    /**
     * create a library of cell styles
     */
    private static Map<String, XSSFCellStyle> createStyles(XSSFWorkbook wb){
        Map<String, XSSFCellStyle> styles = new HashMap<String, XSSFCellStyle>();

        XSSFCellStyle style;
        XSSFFont headerFont = wb.createFont();
        headerFont.setBoldweight(XSSFFont.BOLDWEIGHT_BOLD);

        style = createBorderedStyle(wb);
        style.setAlignment(CellStyle.ALIGN_CENTER);
        style.setFillForegroundColor(IndexedColors.LIGHT_CORNFLOWER_BLUE.getIndex());
        style.setFillPattern(CellStyle.SOLID_FOREGROUND);
        style.setFont(headerFont);
        styles.put(HEADER, style);

        style = createBorderedStyle(wb);
        style.setWrapText(true);
        style.setAlignment(CellStyle.ALIGN_CENTER);
        style.setVerticalAlignment(CellStyle.VERTICAL_CENTER);
        styles.put(DEFAULT_STYLE, style);

        styles.put("date", createDateStyle(wb));

        return styles;
    }

    private static XSSFCellStyle createDateStyle(XSSFWorkbook report) {
        final XSSFCellStyle dateStyle = createBorderedStyle(report);
        dateStyle.setDataFormat(report.getCreationHelper().createDataFormat().getFormat("mmm d, yyyy, h:mm AM/PM"));
        dateStyle.setAlignment(HorizontalAlignment.CENTER);
        dateStyle.setVerticalAlignment(VerticalAlignment.CENTER);
        return dateStyle;
    }

    private static XSSFCellStyle createBorderedStyle(XSSFWorkbook wb){
        XSSFCellStyle style = wb.createCellStyle();
        style.setBorderRight(CellStyle.BORDER_THIN);
        style.setRightBorderColor(IndexedColors.BLACK.getIndex());
        style.setBorderBottom(CellStyle.BORDER_THIN);
        style.setBottomBorderColor(IndexedColors.BLACK.getIndex());
        style.setBorderLeft(CellStyle.BORDER_THIN);
        style.setLeftBorderColor(IndexedColors.BLACK.getIndex());
        style.setBorderTop(CellStyle.BORDER_THIN);
        style.setTopBorderColor(IndexedColors.BLACK.getIndex());
        return style;
    }

    private void setDateValue(XSSFRow row, int cellNumber, ASObject asObject, String fieldName, Map<String, XSSFCellStyle> styles) {
        if (asObject != null) {
            Object value = asObject.get(fieldName);
            if (value instanceof Date) {
                XSSFCell cell = row.getCell(cellNumber);
                if (cell == null) {
                    cell = row.createCell(cellNumber);
                }
                cell.setCellStyle(styles.get("date"));
                cell.setCellValue((Date) value);
            }
        }
    }

    private void createHeader(String reportType, XSSFSheet sheet, Map<String, XSSFCellStyle> styles) {
        XSSFRow row = sheet.createRow(ROW_HEADERS_REPORT);
        HEADER_CREATORS.get(reportType).createHeader(sheet, styles);
    }

    private void createContent(String reportName, int firstIndex, XSSFSheet sheet, Map<String, XSSFCellStyle> styles, Collection<Object> gridObjects) {
        int i = 0;
        try {
            if(gridObjects != null && gridObjects.size()>0) {
                Iterator<Object> iterator = gridObjects.iterator();
                while(iterator.hasNext()) {
                    XSSFRow row = sheet.createRow((firstIndex + i++));
                    row.setHeightInPoints(75);
                    Object tmpGridObj = iterator.next();
                    processReport(reportName, tmpGridObj, row, styles, sheet);
                }
            }
        } catch (Exception ex) {
            logger.error("Error exporting the template", ex);
        }
    }

    private void processReport(String reportName, Object gridObject, XSSFRow row, Map<String, XSSFCellStyle> styles, XSSFSheet sheet) {
        if(gridObject instanceof DelinquentReportVO) {
            processDelinquentReport((DelinquentReportVO) gridObject, row, styles, sheet);
        } else if(gridObject instanceof GapReportVO) {
            processGapReport((GapReportVO) gridObject, row, styles, sheet);
        } else if(gridObject instanceof OwnerStatusReportVO) {
            processOwnerStatusReport((OwnerStatusReportVO)gridObject, row, styles, sheet);
        } else {
            if (reportName == null) {
                processOwnerChangeReport((ASObject)gridObject, row, styles, sheet);
            }
            else {
                processTemplateChangeReport((ASObject)gridObject, row, styles, sheet);
            }
        }

    }

    private void processTemplateChangeReport(ASObject soxAdminLog, XSSFRow row, Map<String, XSSFCellStyle> styles, XSSFSheet sheet) {
        if(soxAdminLog!=null) {
            createHeader("TemplateChange", sheet, styles);
            for(int j=0;j<HEADERS_TEMPLATE_CHANGE_REPORT.length;j++) {
                row.createCell(j).setCellStyle(styles.get(DEFAULT_STYLE));
            }
            int cellNum = 0;
            row.getCell(cellNum++).setCellValue((String)soxAdminLog.get(TRANSACTION));
            row.getCell(cellNum++).setCellValue((String)soxAdminLog.get(CONTROL_ENTITY_ID));
            row.getCell(cellNum++).setCellValue((String)soxAdminLog.get(OWNER));
            row.getCell(cellNum++).setCellValue((String)soxAdminLog.get(NEW_OWNER));
            row.getCell(cellNum++).setCellValue((String)soxAdminLog.get(MOD_USER));
            setDateValue(row, cellNum++, soxAdminLog, MOD_DATE, styles);
            row.getCell(cellNum++).setCellValue((String)soxAdminLog.get(MODIFICATION));
        }
    }

    private void processDelinquentReport(DelinquentReportVO delinquentVO, XSSFRow row, Map<String, XSSFCellStyle> styles, XSSFSheet sheet) {
        if(delinquentVO!=null) {
            createHeader(DELINQUENT, sheet, styles);
            for(int j=0;j<HEADERS_DELINQUENT_REPORT.length;j++) {
                row.createCell(j).setCellStyle(styles.get(DEFAULT_STYLE));
            }
            int cellNum = 0;
            row.getCell(cellNum++).setCellValue(determineEntityType(delinquentVO.getControlEntityId()));
            row.getCell(cellNum++).setCellValue(delinquentVO.getControlEntityId());
            row.getCell(cellNum++).setCellValue(delinquentVO.getUserId());
            row.getCell(cellNum++).setCellValue(delinquentVO.getFirstName());
            row.getCell(cellNum++).setCellValue(delinquentVO.getLastName());
            row.getCell(cellNum++).setCellValue(delinquentVO.getRegion());
            row.getCell(cellNum++).setCellValue(formatDate(delinquentVO.getEndDate()));
            row.getCell(cellNum++).setCellValue(delinquentVO.getControlEntityDescription());
        }
    }

    private String formatDate(Date date2Format) {
        String formattedDate = "";
        if(date2Format!=null) {
            SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");
            formattedDate=formatter.format(date2Format);
        }
        return formattedDate;
    }

    private String determineEntityType(String controlEntityId) {
        String result = "";
        if(controlEntityId!=null && controlEntityId.trim().length()>0) {
            String[] idElements = controlEntityId.split("\\.");
            if(idElements.length==4) {
                result = "Activity";
            }
            if(idElements.length==3) {
                result = "Sub-cycle";
            }
            if(idElements.length==2) {
                result = "Cycle";
            }
        }
        return result;
    }

    private void processGapReport(GapReportVO gapVO, XSSFRow row, Map<String, XSSFCellStyle> styles, XSSFSheet sheet) {
        if(gapVO!=null) {
            createHeader("Gap", sheet, styles);
            for(int j=0;j<HEADERS_GAP_REPORT.length;j++) {
                row.createCell(j).setCellStyle(styles.get(DEFAULT_STYLE));
            }
            int cellNum = 0;
            row.getCell(cellNum++).setCellValue(gapVO.getControlEntityId());
            row.getCell(cellNum++).setCellValue(gapVO.getUserId());
            row.getCell(cellNum++).setCellValue(gapVO.getFirstName());
            row.getCell(cellNum++).setCellValue(gapVO.getLastName());
            row.getCell(cellNum++).setCellValue(gapVO.getRegion());
            row.getCell(cellNum++).setCellValue(gapVO.getDescription());
        }
    }

    private void processOwnerStatusReport(OwnerStatusReportVO ownerStatusVO, XSSFRow row, Map<String, XSSFCellStyle> styles, XSSFSheet sheet) {
        if(ownerStatusVO!=null) {
            createHeader("OwnerStatus", sheet, styles);
            for(int j=0;j< HEADERS_OWNER_STATUS_REPORT.length;j++) {
                row.createCell(j).setCellStyle(styles.get(DEFAULT_STYLE));
            }
            int cellNum = 0;
            row.getCell(cellNum++).setCellValue(ownerStatusVO.getControlEntityId());
            row.getCell(cellNum++).setCellValue(ownerStatusVO.getUserId());
            row.getCell(cellNum++).setCellValue(ownerStatusVO.getFirstName());
            row.getCell(cellNum++).setCellValue(ownerStatusVO.getLastName());
            row.getCell(cellNum++).setCellValue(ownerStatusVO.getRegion());
            row.getCell(cellNum++).setCellValue(ownerStatusVO.getStatus());
            row.getCell(cellNum++).setCellValue(ownerStatusVO.getControlEntityDescription());
        }
    }

    private void processOwnerChangeReport(ASObject soxAdminLog, XSSFRow row, Map<String, XSSFCellStyle> styles, XSSFSheet sheet) {
        if(soxAdminLog!=null) {
            createHeader("OwnerChange", sheet, styles);
            for(int j=0;j< HEADERS_OWNER_CHANGE_REPORT.length;j++) {
                row.createCell(j).setCellStyle(styles.get(DEFAULT_STYLE));
            }
            int cellNum = 0;
            row.getCell(cellNum++).setCellValue((String)soxAdminLog.get(TRANSACTION));
            row.getCell(cellNum++).setCellValue((String)soxAdminLog.get(CONTROL_ENTITY_ID));
            row.getCell(cellNum++).setCellValue((String)soxAdminLog.get(OWNER));
            row.getCell(cellNum++).setCellValue((String)soxAdminLog.get(NEW_OWNER));
            row.getCell(cellNum++).setCellValue((String)soxAdminLog.get(MOD_USER));
            setDateValue(row, cellNum++, soxAdminLog, MOD_DATE, styles);
        }
    }

}

