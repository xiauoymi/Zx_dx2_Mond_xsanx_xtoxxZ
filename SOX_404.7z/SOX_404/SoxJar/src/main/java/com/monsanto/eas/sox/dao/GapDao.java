package com.monsanto.eas.sox.dao;

import com.monsanto.eas.sox.model.GapReportVO;
import com.monsanto.eas.sox.model.SoxGap;

import java.util.Collection;

public interface GapDao extends GenericDao<SoxGap> {
    Collection<SoxGap> lookupGapsByEntityAndOwner(String entityId, String userId);
    Collection<SoxGap> lookupGapsByEntity(String entityId);
    Collection<GapReportVO> lookupGapsByPeriod(String periodId);
}
