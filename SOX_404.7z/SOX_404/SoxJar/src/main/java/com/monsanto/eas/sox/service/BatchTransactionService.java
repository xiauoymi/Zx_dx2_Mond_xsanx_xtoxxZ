package com.monsanto.eas.sox.service;

import com.monsanto.eas.sox.model.BatchTransactionVO;

public interface BatchTransactionService {
    String save(String transactionLog, String deleteOwner, String deleteResponse);
    String save(BatchTransactionVO batchTransactionVO);
}
