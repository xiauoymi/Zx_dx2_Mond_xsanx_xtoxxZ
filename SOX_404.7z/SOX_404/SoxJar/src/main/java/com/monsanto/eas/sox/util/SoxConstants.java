/*
 Copyright:  Copyright � 2011 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.eas.sox.util;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author sspati1
 * @version $Revision$
 */
public class SoxConstants {
    public static final String HOME_VIEW = "home";
    public static final String WAM_USER_ID = "WAM_USER_ID";

    public static final String ASSERTION_EXISTENCE_OR_OCCURRENCE = "Existence or Occurrence";
    public static final String ASSERTION_COMPLETENESS = "Completeness";
    public static final String ASSERTION_VALUATION_AND_ALLOCATION = "Valuation and Allocation";
    public static final String ASSERTION_RIGHT_AND_OBLIGATION = "Right and Obligation";
    public static final String ASSERTION_PRESENTATION_AND_DISCLOSURE = "Presentation and Disclosure";

    public static final String ENTITY_TYPE_CYCLE = "C";
    public static final String ENTITY_TYPE_SUBCYCLE= "SC";
    public static final String ENTITY_TYPE_ACTIVITY = "ACT";

    public static final String NONE = "NONE";

}