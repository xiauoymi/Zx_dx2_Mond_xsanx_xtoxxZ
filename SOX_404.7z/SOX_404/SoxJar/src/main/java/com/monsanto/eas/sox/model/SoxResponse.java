package com.monsanto.eas.sox.model;

import org.hibernate.annotations.Cascade;

import javax.persistence.*;
import java.util.HashSet;
import java.util.Set;

@Entity
@Table(name = "SOX_RESPONSE", schema = "SARBOX_ET")
public class SoxResponse {

    @Id
    @SequenceGenerator(name = "soxResponseSeq", sequenceName = "SARBOX_ET.SOX_RESPONSE_SEQ")
    @GeneratedValue(generator = "soxResponseSeq", strategy = GenerationType.SEQUENCE)
    @javax.persistence.Column(name = "RESPONSE_ID", nullable = false, insertable = true, updatable = true, length = 22, precision = 0)
    private Integer responseId;

    @OneToMany(mappedBy = "soxResponse", fetch = FetchType.LAZY)
    @Cascade({org.hibernate.annotations.CascadeType.ALL})
    private Set<SoxGap> soxGaps = new HashSet<SoxGap>();

    @ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @JoinColumn(name = "RESPONSE_TYPE_ID", referencedColumnName = "RESPONSE_TYPE_ID")
    private ResponseType responseType;

    @ManyToOne (fetch = FetchType.LAZY)
    @JoinColumn(name = "CONTROL_ENTITY_OWNER_ID", referencedColumnName = "CONTROL_ENTITY_OWNER_ID")
    private SoxControlEntityOwner soxControlEntityOwner;

    @ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
    @JoinColumn(name = "QUESTION_ID", referencedColumnName = "QUESTION_ID")
    private SoxQuestion soxQuestion;

    @Transient
    private String responseDescription;

    public String getResponseDescription() {
        return responseDescription;
    }

    public void setResponseDescription(String responseDescription) {
        this.responseDescription = responseDescription;
    }

    public Integer getResponseId() {
        return responseId;
    }

    public void setResponseId(Integer responseId) {
        this.responseId = responseId;
    }

    public Set<SoxGap> getSoxGaps() {
        return soxGaps;
    }

    public void setSoxGaps(Set<SoxGap> soxGaps) {
        this.soxGaps = soxGaps;
    }

    public void addSoxGap(SoxGap soxGap) {
        if (soxGap != null) {
            soxGap.setSoxResponse(this);
            soxGaps.add(soxGap);
        }
    }

    public ResponseType getResponseType() {
        return responseType;
    }

    public void setResponseType(ResponseType responseType) {
        this.responseType = responseType;
    }

    public SoxControlEntityOwner getSoxControlEntityOwner() {
        return soxControlEntityOwner;
    }

    public void setSoxControlEntityOwner(SoxControlEntityOwner soxControlEntityOwner) {
        this.soxControlEntityOwner = soxControlEntityOwner;
    }

    public SoxQuestion getSoxQuestion() {
        return soxQuestion;
    }

    public void setSoxQuestion(SoxQuestion soxQuestion) {
        this.soxQuestion = soxQuestion;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        SoxResponse that = (SoxResponse) o;

        if (soxQuestion != null ? !soxQuestion.equals(that.soxQuestion) : that.soxQuestion != null)
            return false;
        if (soxControlEntityOwner != null ? !soxControlEntityOwner.equals(that.soxControlEntityOwner) : that.soxControlEntityOwner != null)
            return false;
        if (responseType != null ? !responseType.equals(that.responseType) : that.responseType != null)
            return false;

//        if (controlEntityOwnerId != that.controlEntityOwnerId) return false;
//        if (questionId != that.questionId) return false;
        if (responseId != that.responseId) return false;
//        if (responseTypeId != that.responseTypeId) return false;

        return true;
    }

    @Override
    public int hashCode() {

//        int result = (responseId != null ? responseId.hashCode() : 0);
        int result = (soxQuestion != null ? soxQuestion.hashCode() : 0);
        result = result + (soxControlEntityOwner != null ? soxControlEntityOwner.hashCode() : 0);
//        result = 31 * result + controlEntityOwnerId;
//        result = 31 * result + questionId;
//        result = 31 * result + responseTypeId;
        return result;
    }
}
