package com.monsanto.eas.sox.model;

import org.hibernate.annotations.Cascade;

import javax.persistence.*;
import java.util.HashSet;
import java.util.Set;

@Table(name = "SOX_BUSINESS_TYPE", schema = "SARBOX_ET")
@Entity
@NamedQueries({
        @NamedQuery(name = "lookupAllBusinessType",
                query = "FROM SoxBusinessType bt ORDER BY bt.businessTypeId")
})
public class SoxBusinessType {
    @Id
    @javax.persistence.Column(name = "BUSINESS_TYPE_ID", nullable = false, insertable = true, updatable = true, length = 22, precision = 0)
    private int businessTypeId;

    @javax.persistence.Column(name = "DESCRIPTION", nullable = true, insertable = true, updatable = true, length = 100, precision = 0)
    @Basic
    private String description;

    @OneToMany(mappedBy = "soxBusinessType", fetch = FetchType.LAZY)
    @Cascade({org.hibernate.annotations.CascadeType.SAVE_UPDATE, org.hibernate.annotations.CascadeType.PERSIST})
    private Set<SoxSignificantChange> soxSignificantChanges= new HashSet<SoxSignificantChange>();

    public Set<SoxSignificantChange> getSoxSignificantChanges() {
        return soxSignificantChanges;
    }

    public void setSoxSignificantChanges(Set<SoxSignificantChange> soxSignificantChanges) {
        this.soxSignificantChanges = soxSignificantChanges;
    }

    public void addSoxSignificantChange(SoxSignificantChange soxSignificantChange){
        if(soxSignificantChange != null) {
            soxSignificantChange.setSoxBusinessType(this);
            soxSignificantChanges.add(soxSignificantChange);
        }
    }

    public int getBusinessTypeId() {
        return businessTypeId;
    }

    public void setBusinessTypeId(int businessTypeId) {
        this.businessTypeId = businessTypeId;
    }


    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        SoxBusinessType that = (SoxBusinessType) o;

        if (businessTypeId != that.businessTypeId) return false;
        if (description != null ? !description.equals(that.description) : that.description != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = businessTypeId;
        result = 31 * result + (description != null ? description.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        return "SoxBusinessType{" +
                "businessTypeId=" + businessTypeId +
                ", description='" + description + '\'' +
//                ", soxSignificantChanges=" + soxSignificantChanges +
                '}';
    }
}
