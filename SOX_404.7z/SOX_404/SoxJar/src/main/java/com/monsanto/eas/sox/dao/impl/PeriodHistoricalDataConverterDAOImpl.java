package com.monsanto.eas.sox.dao.impl;

import com.monsanto.eas.sox.model.PeriodMaintenanceVO;
import com.monsanto.eas.sox.model.SoxPeriod;
import com.monsanto.eas.sox.util.ControlEntityType;

import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

public class PeriodHistoricalDataConverterDAOImpl {
    private static Date getDateFromObject(Object object){
        Date date = null;

        if (object != null) {
            if (object instanceof Timestamp){
                date = new Date(((Timestamp) object).getTime());
            } else if (object instanceof java.sql.Date){
                date = new Date(((java.sql.Date) object).getTime());
            }
        }

        return date;
    }

    public static PeriodMaintenanceVO getPeriodHistoricalDataFromList(List<Object[]> objects, SoxPeriod period){
        PeriodMaintenanceVO periodMaintenanceVO = null;
        periodMaintenanceVO = new PeriodMaintenanceVO();

        if (period != null){
            periodMaintenanceVO.setName(period.getPeriodId());
            periodMaintenanceVO.setDescription(period.getPeriodDescription());
            periodMaintenanceVO.setCurrentPeriod(period.getCurrentPeriod());
            periodMaintenanceVO.setStatus(period.getClosedPeriod());
            periodMaintenanceVO.setNews(period.getNews());
        }

        if (objects != null){
          for (Object[] properties: objects){
             if (properties[1].toString().equalsIgnoreCase(ControlEntityType.CYCLE.toString())){
               periodMaintenanceVO.setCycleNotification(getDateFromObject(properties[2]));
               periodMaintenanceVO.setCycleReminder(getDateFromObject( properties[3]));
               periodMaintenanceVO.setCycleDelinquent(getDateFromObject( properties[4]));
             }
             else if (properties[1].toString().equalsIgnoreCase(ControlEntityType.SUB_CYCLE.toString())){
               periodMaintenanceVO.setSubcycleNotification(getDateFromObject( properties[2]));
               periodMaintenanceVO.setSubcycleReminder(getDateFromObject( properties[3]));
               periodMaintenanceVO.setSubcycleDelinquent(getDateFromObject( properties[4]));
             }
             else if (properties[1].toString().equalsIgnoreCase(ControlEntityType.ACTIVITY.toString())){
               periodMaintenanceVO.setControlNotification(getDateFromObject( properties[2]));
               periodMaintenanceVO.setControlReminder(getDateFromObject( properties[3]));
               periodMaintenanceVO.setControlDelinquent(getDateFromObject( properties[4]));
             }
          }
        }

        return periodMaintenanceVO;
    }
}
