package com.monsanto.eas.sox.service.impl;

import com.google.common.base.Joiner;
import com.monsanto.eas.sox.exception.TemplateException;
import com.monsanto.eas.sox.service.SearchPeopleService;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.ConnectionCallback;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import javax.sql.DataSource;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Collection;
import java.util.List;

@Component
public class RollForwardServiceStoredProcedureImpl implements RollForwardService
{
    private static final Logger LOG = Logger.getLogger(RollForwardServiceStoredProcedureImpl.class);

    private static final String SELECT = " SELECT ";
    private static final String PREVIOUS_PERIOD_SQL = new StringBuilder()
        .append(SELECT)
        .append("     period_id ")
        .append(" FROM ( ")
        .append("     SELECT period_id ")
        .append("     FROM (SELECT period_id FROM sox_period ORDER BY period_id DESC) ")
        .append("     WHERE rownum <= 2 ")
        .append("     ORDER BY rownum DESC ")
        .append(" ) ")
        .append(" WHERE ")
        .append("     rownum = 1 ")
        .toString()
        .trim()
    ;

    private static final String LATEST_CYCLES_SQL = new StringBuilder()
        .append(SELECT)
        .append("     control_entity_id ")
        .append(" FROM ")
        .append("     sox_control_entity ")
        .append(" WHERE ")
        .append("     period_id = (SELECT max(period_id) FROM sox_period) ")
        .append("     AND INSTRC(control_entity_id, '.', 1, 2) = 0 ")
        .append(" ORDER BY ")
        .append("     control_entity_id ")
        .toString()
        .trim()
    ;

    private final JdbcTemplate jdbcTemplate;
    private SearchPeopleService searchPeopleService;

    @Autowired
    public RollForwardServiceStoredProcedureImpl(DataSource dataSource) {
        jdbcTemplate = new JdbcTemplate(dataSource);
    }

    @Autowired
    public void setSearchPeopleService(SearchPeopleService searchPeopleService) {
        this.searchPeopleService = searchPeopleService;
    }

    @Override
    public List<String> copyPreviousCyclesIntoCurrentPeriod(String currentOrNewPeriod) throws TemplateException {
        return copyPreviousCyclesIntoCurrentPeriod(
            currentOrNewPeriod,
            searchPeopleService.getInvalidUserIdsForPeriod(getPreviousPeriodId())
        );
    }

    private String getPreviousPeriodId() {
        return jdbcTemplate.queryForObject(PREVIOUS_PERIOD_SQL, String.class);
    }

    private List<String> copyPreviousCyclesIntoCurrentPeriod (final String currentOrNewPeriod, final Collection<String> invalidUserIds) {
        LOG.info("Executing Roll-Forward Stored Procedure...");
        jdbcTemplate.execute(new ConnectionCallback<Boolean>()
        {
            @Override
            public Boolean doInConnection(Connection connection) throws SQLException, DataAccessException {
                final CallableStatement stmt = connection.prepareCall("{call QUARTERLY_ROLLFORWARD.MAIN(?, ?)}");
                stmt.setString(1, currentOrNewPeriod);
                stmt.setString(2, Joiner.on(",").skipNulls().join(invalidUserIds));
                return stmt.execute();
            }
        });
        LOG.info("Done.");
        return jdbcTemplate.queryForList(LATEST_CYCLES_SQL, String.class);
    }
}
