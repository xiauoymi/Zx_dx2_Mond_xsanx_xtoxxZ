package com.monsanto.eas.sox.dao.impl;

import com.monsanto.eas.sox.dao.ResponseTypeDao;
import com.monsanto.eas.sox.model.ResponseType;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.util.List;

@Repository
public class ResponseTypeDaoImpl extends GenericDaoImpl<ResponseType> implements ResponseTypeDao {
    private static final long serialVersionUID = 1L;

    @PersistenceContext
    private EntityManager entityManager;

    @Override
    public ResponseType lookupResponseTypeByDescription(String description) {
        ResponseType responseType = null;
        List<ResponseType> responseTypeList= entityManager.createNamedQuery("lookupResponseTypeByDescription").setParameter("description", description).getResultList();
        if(responseTypeList != null && responseTypeList.size() > 0) {
            responseType = responseTypeList.get(0);
        }
        return responseType;
    }
}
