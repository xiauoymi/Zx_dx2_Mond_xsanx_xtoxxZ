package com.monsanto.eas.sox.dao;

import com.monsanto.eas.sox.model.SoxSignificantChange;

import java.util.Collection;

public interface SignificantChangeDao extends GenericDao<SoxSignificantChange> {

   void deleteSignificantChangeWithoutReferences();

   Collection<SoxSignificantChange> lookupSignificantChangeByEntityAndOwner(String entityId, String userId);
}
