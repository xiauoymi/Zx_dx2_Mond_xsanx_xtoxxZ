package com.monsanto.eas.sox.dao;

import com.monsanto.eas.sox.model.BatchTransactionVO;

public interface JdbcBatchTransactionDao {
    void save(BatchTransactionVO batchTransactionVO);
}
