package com.monsanto.eas.sox.service;

import com.monsanto.eas.sox.model.SoxControlEntity;
import org.springframework.flex.remoting.RemotingInclude;

public interface UploadResultXmlService {
    @RemotingInclude
    String serialize(SoxControlEntity cycle, String state, String serverResponse) throws Exception;
}
