package com.monsanto.eas.sox.model;

import javax.persistence.*;
import java.util.Date;

/**
 * Created by IntelliJ IDEA.
 * User: JEESCO
 * Date: 8/02/12
 * Time: 09:24 AM
 */
@Entity
@Table(name="SOX_ADMIN_LOG", schema="SARBOX_ET")
public class SoxAdminLog {
    @javax.persistence.Column(name = "SOX_ADMIN_LOG_ID", nullable = false, insertable = true, updatable = true, length = 22, precision = 0)    
    @Id
    @SequenceGenerator(name = "soxAdminLogSeq", sequenceName = "SARBOX_ET.SOX_ADMIN_LOG_SEQ")
    @GeneratedValue(generator = "soxAdminLogSeq", strategy = GenerationType.SEQUENCE)
    private int adminLogId;

    @javax.persistence.Column(name = "TRANSACTION", nullable = false, insertable = true, updatable = true, length = 10, precision = 0)
    @Basic
    private String transaction;

    @javax.persistence.Column(name = "CONTROL_ENTITY_ID", nullable = false, insertable = true, updatable = true, length = 200, precision = 0)
    @Basic
    private String controlEntityId;

    @javax.persistence.Column(name = "OWNER", nullable = false, insertable = true, updatable = true, length = 20, precision = 0)
    @Basic
    private String owner;

    @javax.persistence.Column(name = "NEW_OWNER", nullable = true, insertable = true, updatable = true, length = 20, precision = 0)
    @Basic
    private String newOwner;

    @javax.persistence.Column(name = "MOD_DATE", nullable = true, insertable = true, updatable = true, length = 7, precision = 0)
    @Basic
    private Date modDate;

    @javax.persistence.Column(name = "MOD_USER", nullable = false, insertable = true, updatable = true, length = 20, precision = 0)
    @Basic
    private String modUser;

    @Transient
    private String currentOwnerFirstName;

    @Transient
    private String currentOwnerLastName;

    @Transient
    private String newOwnerFirstName;

    @Transient
    private String newOwnerLastName;

    @javax.persistence.Column(name = "MODIFICATION", nullable = true, insertable = true, updatable = true)
    @Lob
    @Basic
    private String modification;


    public int getAdminLogId() {
        return adminLogId;
    }

    public void setAdminLogId(int adminLogId) {
        this.adminLogId = adminLogId;
    }

    public String getTransaction() {
        return transaction;
    }

    public void setTransaction(String transaction) {
        this.transaction = transaction;
    }

    public String getControlEntityId() {
        return controlEntityId;
    }

    public void setControlEntityId(String controlEntityId) {
        this.controlEntityId = controlEntityId;
    }

    public String getOwner() {
        return owner;
    }

    public void setOwner(String owner) {
        this.owner = owner;
    }

    public String getNewOwner() {
        return newOwner;
    }

    public void setNewOwner(String newOwner) {
        this.newOwner = newOwner;
    }

    public Date getModDate() {
        return modDate;
    }

    public void setModDate(Date modDate) {
        this.modDate = modDate;
    }

    public String getModUser() {
        return modUser;
    }

    public void setModUser(String modUser) {
        this.modUser = modUser;
    }

    public String getCurrentOwnerFirstName() {
        return currentOwnerFirstName;
    }

    public void setCurrentOwnerFirstName(String currentOwnerFirstName) {
        this.currentOwnerFirstName = currentOwnerFirstName;
    }

    public String getCurrentOwnerLastName() {
        return currentOwnerLastName;
    }

    public void setCurrentOwnerLastName(String currentOwnerLastName) {
        this.currentOwnerLastName = currentOwnerLastName;
    }

    public String getNewOwnerFirstName() {
        return newOwnerFirstName;
    }

    public void setNewOwnerFirstName(String newOwnerFirstName) {
        this.newOwnerFirstName = newOwnerFirstName;
    }

    public String getNewOwnerLastName() {
        return newOwnerLastName;
    }

    public void setNewOwnerLastName(String newOwnerLastName) {
        this.newOwnerLastName = newOwnerLastName;
    }

    public String getModification() {
        return modification;
    }

    public void setModification(String modification) {
        this.modification = modification;
    }
}
