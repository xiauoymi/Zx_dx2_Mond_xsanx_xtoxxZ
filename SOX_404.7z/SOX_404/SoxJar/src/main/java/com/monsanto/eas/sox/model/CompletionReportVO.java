package com.monsanto.eas.sox.model;

/**
 * Created by IntelliJ IDEA.
 * User: JEESCO
 * Date: 2/02/2012
 * Time: 07:35:42 AM
 */
public class CompletionReportVO {
    private String controlEntityId;
    private Integer ownerId;
    private Integer questionId;
    private Integer responseId;
    private Integer responseTypeId;

    public CompletionReportVO() {
    }

    public CompletionReportVO(String controlEntityId, Integer ownerId, Integer questionId, Integer responseId, Integer responseTypeId) {
        this.controlEntityId = controlEntityId;
        this.ownerId = ownerId;
        this.questionId = questionId;
        this.responseId = responseId;
        this.responseTypeId = responseTypeId;
    }

    public String getControlEntityId() {
        return controlEntityId;
    }

    public void setControlEntityId(String controlEntityId) {
        this.controlEntityId = controlEntityId;
    }

    public Integer getOwnerId() {
        return ownerId;
    }

    public void setOwnerId(Integer ownerId) {
        this.ownerId = ownerId;
    }

    public Integer getQuestionId() {
        return questionId;
    }

    public void setQuestionId(Integer questionId) {
        this.questionId = questionId;
    }

    public Integer getResponseId() {
        return responseId;
    }

    public void setResponseId(Integer responseId) {
        this.responseId = responseId;
    }

    public Integer getResponseTypeId() {
        return responseTypeId;
    }

    public void setResponseTypeId(Integer responseTypeId) {
        this.responseTypeId = responseTypeId;
    }
}
