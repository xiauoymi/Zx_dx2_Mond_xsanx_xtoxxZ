package com.monsanto.eas.sox.service;

import com.monsanto.eas.sox.model.ExportExcelTemplateVO;

public interface PullExcelTemplateService {

   ExportExcelTemplateVO getExcelTemplate(String periodId, String countryId, String cycleId);

   ExportExcelTemplateVO getTeamMateExcelTemplate(String periodId, String countryId, String cycleId);
}
