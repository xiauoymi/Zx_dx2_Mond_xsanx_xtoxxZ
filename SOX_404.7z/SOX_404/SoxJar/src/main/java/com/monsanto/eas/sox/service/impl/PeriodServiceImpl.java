package com.monsanto.eas.sox.service.impl;

import com.monsanto.eas.sox.dao.PeriodDao;
import com.monsanto.eas.sox.dao.ResponseDao;
import com.monsanto.eas.sox.model.SoxPeriod;
import com.monsanto.eas.sox.model.SoxResponse;
import com.monsanto.eas.sox.model.TestSoxPeriod;
import com.monsanto.eas.sox.model.TestYear;
import com.monsanto.eas.sox.service.PeriodService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.flex.remoting.RemotingDestination;
import org.springframework.flex.remoting.RemotingInclude;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
@RemotingDestination(value = "periodService")
public class PeriodServiceImpl implements PeriodService {

   @Autowired
   private PeriodDao periodDao;

   @Autowired
   private ResponseDao responseDao;

   @RemotingInclude
   public SoxPeriod getCurrentPeriod() {
      SoxPeriod period = periodDao.lookupCurrentPeriod();
      return period;
   }

   @Override
   public SoxPeriod getPreviousPeriod() {
      Collection<SoxPeriod> soxPeriodCollection = getAllPeriods();
      SoxPeriod previousPeriod = null;
      int soxPeriodsIndex = 0;

      for (SoxPeriod soxPeriod : soxPeriodCollection) {
         if (soxPeriodsIndex == 1) {
            previousPeriod = soxPeriod;
            break;
         }
         soxPeriodsIndex++;
      }

      return previousPeriod;
   }

   @Override
   public SoxPeriod getPeriodById(String periodId) {
      Map<String, Object> parameters = new HashMap<String, Object>();
      parameters.put("periodId", periodId);
      List<SoxPeriod> periods = (List<SoxPeriod>) periodDao.findListByQueryName("lookupPeriodById", parameters);
      SoxPeriod period = periods == null || periods.size() == 0 ? null : periods.get(0);
      return period;
   }

   @RemotingInclude
   public TestSoxPeriod getTestCurrentPeriod() {
      SoxPeriod period = periodDao.lookupCurrentPeriod();
      TestSoxPeriod testSoxPeriod = new TestSoxPeriod();
      testSoxPeriod.setCurrentPeriod(period.getCurrentPeriod());
      testSoxPeriod.setCycleOnly(period.getCycleOnly());
      testSoxPeriod.setPeriodDescription(period.getPeriodDescription());
      testSoxPeriod.setPeriodId(period.getPeriodId());
      return testSoxPeriod;
   }

   @RemotingInclude
   public Collection<SoxPeriod> getAllPeriods() {
      Collection<SoxPeriod> soxPeriods = periodDao.lookupAllPeriods();
      Collection<SoxPeriod> testSoxPeriods = new ArrayList<SoxPeriod>();

      Iterator<SoxPeriod> soxPeriodIterator = soxPeriods.iterator();

      while (soxPeriodIterator.hasNext()) {
         SoxPeriod period = soxPeriodIterator.next();
         SoxPeriod soxPeriod = new SoxPeriod();
         soxPeriod.setCurrentPeriod(period.getCurrentPeriod());
         soxPeriod.setCycleOnly(period.getCycleOnly());
         soxPeriod.setPeriodDescription(period.getPeriodDescription());
         soxPeriod.setPeriodId(period.getPeriodId());
         testSoxPeriods.add(soxPeriod);
      }
      return testSoxPeriods;
   }

   @RemotingInclude
   public TestYear getTestYear() {
      TestYear testYear = new TestYear();
      testYear.setModUser("vrbethi");
      return testYear;
   }

   @RemotingInclude
   public SoxResponse getTestResponse() {
      SoxResponse soxResponse = responseDao.lookupResponse();
      return soxResponse;
   }

}
