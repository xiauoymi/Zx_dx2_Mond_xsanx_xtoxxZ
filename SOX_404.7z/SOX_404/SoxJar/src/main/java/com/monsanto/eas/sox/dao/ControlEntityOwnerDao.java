package com.monsanto.eas.sox.dao;

import com.monsanto.eas.sox.model.SoxControlEntityOwner;
import com.monsanto.eas.sox.model.SoxEntityOwnershipVO;

import java.util.Collection;

public interface ControlEntityOwnerDao extends GenericDao<SoxControlEntityOwner> {

    void deleteSoxControlEntityOwnerWithoutReferences();

    SoxControlEntityOwner lookupControlEntityOwnerByEntityAndOwner(String entityId, String userId);

    Collection<SoxControlEntityOwner> lookupControlEntityOwnerByControlEntityId(String entityId);

    Collection<SoxControlEntityOwner> lookupControlEntityOwnerByPeriod(String periodId);

    /*
    Collection<SoxControlEntityOwner> lookupCertificationsStarted(SoxPeriod currentPeriod);
    Collection<SoxControlEntityOwner> lookupEntityOwnersCertificationsOverdue(SoxPeriod currentPeriod);
    Collection<SoxControlEntityOwner> lookupEntityChildsCertificationsOverdue(SoxPeriod currentPeriod);
    Collection<SoxControlEntityOwner> lookupCertificationsToSendReminder(Date formattedDate, SoxPeriod currentPeriod);
    Collection<SoxControlEntityOwner> lookupAllCertifications();
    */

    Collection<SoxEntityOwnershipVO> lookupCyclePermissionsForAnOwner(String userId);

    Collection<SoxEntityOwnershipVO> lookupSubCyclePermissionsForAnOwner(String userId);

    Collection<SoxEntityOwnershipVO> lookupActivitiesPermissionsForAnOwner(String userId);

    Collection<SoxEntityOwnershipVO> lookupAllCycles();

    Collection<SoxEntityOwnershipVO> lookupAllSubcycles();

    Collection<SoxEntityOwnershipVO> lookupSubCyclesForACycle(String cycle);

    Collection<SoxEntityOwnershipVO> lookupActivitiesForACycleSubCycle(String cycle, String subCycle);

    Collection<String> lookupEditableCycles();
}
