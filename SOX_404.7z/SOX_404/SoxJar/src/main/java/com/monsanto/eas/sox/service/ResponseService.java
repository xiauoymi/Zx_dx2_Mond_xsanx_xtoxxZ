package com.monsanto.eas.sox.service;

import com.monsanto.eas.sox.model.SoxResponse;
import com.monsanto.eas.sox.model.SoxSignificantChange;

import java.util.Collection;

public interface ResponseService {

    void saveOrUpdate(Collection<SoxResponse> responses);

    void deleteSoxResponseWithoutReferences();

    void saveOrUpdate(String entityId, String userId, Collection<SoxResponse> responses, Collection<SoxSignificantChange> significantChanges);

    Collection<SoxResponse> getResponseByEntityAndOwner(String entityId, String userId);
}
