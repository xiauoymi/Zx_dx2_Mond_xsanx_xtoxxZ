package com.monsanto.eas.sox.dao;

import com.monsanto.eas.sox.model.SoxSystem;

import java.util.Collection;

public interface SoxSystemDao extends GenericDao<SoxSystem>{
    SoxSystem lookupSoxSystemByDescription(String description);
    Collection<SoxSystem> lookupAllSoxSystems();
}
