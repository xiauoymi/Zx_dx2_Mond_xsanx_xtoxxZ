package com.monsanto.eas.sox.service;

import com.monsanto.eas.sox.model.Assertion;

public interface AssertionService {
    Assertion getAssertionByDescription(String description);
}
