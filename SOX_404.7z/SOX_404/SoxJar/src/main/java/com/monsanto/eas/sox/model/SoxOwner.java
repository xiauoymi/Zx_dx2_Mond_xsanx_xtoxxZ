package com.monsanto.eas.sox.model;

import com.monsanto.eas.sox.util.SoxConstants;
import org.hibernate.annotations.Cascade;

import javax.persistence.*;
import java.util.HashSet;
import java.util.Set;

@Table(name = "SOX_OWNER", schema = "SARBOX_ET")
@Entity
@NamedQueries({
        @NamedQuery(name = "lookupAll", query = "FROM SoxOwner s ORDER BY s.userId"),
        @NamedQuery(name = "lookupSoxOwnerByUserId", query = "FROM SoxOwner s WHERE s.userId=:userId")
})
public class SoxOwner {

    @Id
    @SequenceGenerator(name = "soxOwnerSeq", sequenceName = "SARBOX_ET.SOX_OWNER_SEQ")
    @GeneratedValue(generator = "soxOwnerSeq", strategy = GenerationType.SEQUENCE)
    @javax.persistence.Column(name = "OWNER_ID")
    private int ownerId;

    @javax.persistence.Column(name = "USER_ID", nullable = false, insertable = true, updatable = true, length = 22, precision = 0)
    @Basic
    private String userId;

    @OneToMany(mappedBy = "soxOwner", fetch = FetchType.LAZY)
    @Cascade({org.hibernate.annotations.CascadeType.ALL})
    private Set<SoxControlEntityOwner> soxControlEntityOwners = new HashSet<SoxControlEntityOwner>();


    public int getOwnerId() {
        return ownerId;
    }

    public void setOwnerId(int ownerId) {
        this.ownerId = ownerId;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public Set<SoxControlEntityOwner> getSoxControlEntityOwners() {
        return soxControlEntityOwners;
    }

    public void setSoxControlEntityOwners(Set<SoxControlEntityOwner> soxControlEntityOwners) {
        this.soxControlEntityOwners = soxControlEntityOwners;
    }

    public void addSoxControlEntityOwner(SoxControlEntityOwner controlEntityOwner) {
        if (controlEntityOwner != null) {
            controlEntityOwner.setSoxOwner(this);
            soxControlEntityOwners.add(controlEntityOwner);
        }
    }

    public boolean isNone() {
        return SoxConstants.NONE.equalsIgnoreCase(userId);
    }

    @Override
    public boolean equals(Object o) {
//        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        SoxOwner that = (SoxOwner) o;

        if (userId != null ? !userId.equals(that.userId) : that.userId != null)
            return false;

//        if (ownerId != soxOwner.ownerId) return false;
//        if (userId != soxOwner.userId) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = ownerId;
//        result = 31 * result + (userId != null ? userId.hashCode() : 0);
        result = result + (userId != null ? userId.hashCode() : 0);

        return result;
    }

    @Override
    public String toString() {
        return "SoxOwner{" +
                "ownerId=" + ownerId +
                ", userId='" + userId + '\'' +
//                ", soxControlEntityOwners=" + soxControlEntityOwners +
                '}';
    }
} // end of class

