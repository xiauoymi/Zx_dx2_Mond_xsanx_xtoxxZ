package com.monsanto.eas.sox.service;

public final class ExcelTemplateDescriptor {
   public static final int COL_CONTROL_ID = 0;
   public static final int COL_COUNTRY = 1;
   public static final int COL_CYCLE = 2;
   public static final int COL_SUBCYCLE = 3;
   public static final int COL_SUBCYCLE_OWNER = 4;
   public static final int COL_OCURRENCE = 5;
   public static final int COL_COMPLETNESS = 6;
   public static final int COL_VALUATION = 7;
   public static final int COL_RIGHT = 8;
   public static final int COL_PRESENTATION = 9;
   public static final int COL_RISK = 10;
   public static final int COL_CONTROL = 11;
   public static final int COL_CONTROL_OWNER = 12;
   public static final int COL_CONTROL_TYPE = 13;
   public static final int COL_FREQUENCY = 14;
   public static final int COL_SYSTEM = 15;
   public static final int COL_PREVENT = 16;
   public static final int COL_FRAUD = 17;
   public static final int COL_KEY = 18;

   public static final int TEAM_MATE_COL_FOLDER = 0;
   public static final int TEAM_MATE_COL_FOLDER1 = 1;
   public static final int TEAM_MATE_COL_FOLDER2 = 2;
   public static final int TEAM_MATE_COL_WORKPROGRAMFOLDER = 3;
   public static final int TEAM_MATE_COL_TITLE = 4;
   public static final int TEAM_MATE_COL_TYPE = 5;
   public static final int TEAM_MATE_COL_CATEGORY = 6;
   public static final int TEAM_MATE_COL_VISIT = 7;
   public static final int TEAM_MATE_COL_FREQUENCY = 8;
   public static final int TEAM_MATE_COL_LOCATION = 9;
   public static final int TEAM_MATE_COL_USERCATEGORY1 = 10;
   public static final int TEAM_MATE_COL_USERCATEGORY2 = 11;
   public static final int TEAM_MATE_COL_PLANNINGTEXT1 = 12;
   public static final int TEAM_MATE_COL_PLANNINGTEXT2 = 13;
   public static final int TEAM_MATE_COL_PLANNINGTEXT3 = 14;
   public static final int TEAM_MATE_COL_PLANNINGTEXT4 = 15;
   public static final int TEAM_MATE_COL_PLANNINGTEXT5 = 16;
   public static final int TEAM_MATE_COL_EXECUTIONTEXT1 = 17;
   public static final int TEAM_MATE_COL_EXECUTIONTEXT2 = 18;
   public static final int TEAM_MATE_COL_EXECUTIONTEXT3 = 19;
   public static final int TEAM_MATE_COL_EXECUTIONTEXT4 = 20;
}