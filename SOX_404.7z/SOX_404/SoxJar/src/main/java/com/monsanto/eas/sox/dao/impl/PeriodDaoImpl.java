package com.monsanto.eas.sox.dao.impl;

import com.monsanto.eas.sox.dao.PeriodDao;
import com.monsanto.eas.sox.model.SoxPeriod;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.util.Collection;
import java.util.List;

@Repository
public class PeriodDaoImpl extends GenericDaoImpl<SoxPeriod> implements PeriodDao{
    private static final long serialVersionUID = 1L;

    @PersistenceContext
    private EntityManager entityManager;

    @Override
    public SoxPeriod lookupCurrentPeriod() {
        SoxPeriod period = null;

        List<SoxPeriod> periods = entityManager.createNamedQuery("lookupCurrentPeriod").setParameter("currentPeriod","1").getResultList();
        if(periods != null && periods.size() > 0){
            period = periods.get(0);
        }
        return period;
    }

    @Override
    public Collection<SoxPeriod> lookupAllPeriods() {

        return entityManager.createNamedQuery("lookupAllPeriods").getResultList();
    }

    @Override
    public Boolean getNewPeriodAvailability() {

        List<SoxPeriod> periods = entityManager.createNamedQuery("getNewPeriodAvailability").getResultList();

        return periods != null && periods.size() == 0;
    }

    @Override
    public SoxPeriod getMaximumPeriod() {
        SoxPeriod period = null;

        List<SoxPeriod> periods = entityManager.createNamedQuery("getMaximumPeriod").getResultList();
        if(periods != null && periods.size() > 0){
            period = periods.get(0);
        }
        return period;
    }
} // end of class
