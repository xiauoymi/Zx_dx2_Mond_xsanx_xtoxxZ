package com.monsanto.eas.sox.model;

import java.util.Date;

public class PeriodMaintenanceVO {
    private String name;
    private String description;
    private String cycleOnly;
    private String currentPeriod;
    private String status;
    private String news;
    private boolean completed = false;
    private Date controlNotification;
    private Date controlReminder;
    private Date controlDelinquent;
    private Date subcycleNotification;
    private Date subcycleReminder;
    private Date subcycleDelinquent;
    private Date cycleNotification;
    private Date cycleReminder;
    private Date cycleDelinquent;

    public PeriodMaintenanceVO() {
       super();
    }

    public PeriodMaintenanceVO(String name, String description, String cycleOnly, String currentPeriod, String status, String news, Date controlNotification, Date controlReminder, Date controlDelinquent, Date subcycleNotification, Date subcycleReminder, Date subcycleDelinquent, Date cycleNotification, Date cycleReminder, Date cycleDelinquent) {
        super();
        this.name = name;
        this.description = description;
        this.cycleOnly = cycleOnly;
        this.currentPeriod = currentPeriod;
        this.status = status;
        this.news = news;
        this.controlNotification = controlNotification;
        this.controlReminder = controlReminder;
        this.controlDelinquent = controlDelinquent;
        this.subcycleNotification = subcycleNotification;
        this.subcycleReminder = subcycleReminder;
        this.subcycleDelinquent = subcycleDelinquent;
        this.cycleNotification = cycleNotification;
        this.cycleReminder = cycleReminder;
        this.cycleDelinquent = cycleDelinquent;
    }

  public String getName() {
      return name;
    }

    public void setName(String name) {
      this.name = name;
    }

    public String getDescription() {
      return description;
    }

    public void setDescription(String description) {
      this.description = description;
    }

    public String getCycleOnly() {
      return cycleOnly;
    }

    public void setCycleOnly(String cycleOnly) {
      this.cycleOnly = cycleOnly;
    }

    public String getCurrentPeriod() {
      return currentPeriod;
    }

    public void setCurrentPeriod(String currentPeriod) {
      this.currentPeriod = currentPeriod;
    }

    public String getStatus() {
      return status;
    }

    public void setStatus(String status) {
      this.status = status;
    }

    public String getNews() {
      return news;
    }

    public void setNews(String news) {
      this.news = news;
    }

    public Date getControlNotification() {
      return controlNotification;
    }

    public void setControlNotification(Date controlNotification) {
      this.controlNotification = controlNotification;
    }

    public Date getControlReminder() {
      return controlReminder;
    }

    public void setControlReminder(Date controlReminder) {
      this.controlReminder = controlReminder;
    }

    public Date getControlDelinquent() {
      return controlDelinquent;
    }

    public void setControlDelinquent(Date controlDelinquent) {
      this.controlDelinquent = controlDelinquent;
    }

    public Date getSubcycleNotification() {
      return subcycleNotification;
    }

    public void setSubcycleNotification(Date subcycleNotification) {
      this.subcycleNotification = subcycleNotification;
    }

    public Date getSubcycleReminder() {
      return subcycleReminder;
    }

    public void setSubcycleReminder(Date subcycleReminder) {
      this.subcycleReminder = subcycleReminder;
    }

    public Date getSubcycleDelinquent() {
      return subcycleDelinquent;
    }

    public void setSubcycleDelinquent(Date subcycleDelinquent) {
      this.subcycleDelinquent = subcycleDelinquent;
    }

    public Date getCycleNotification() {
      return cycleNotification;
    }

    public void setCycleNotification(Date cycleNotification) {
      this.cycleNotification = cycleNotification;
    }

    public Date getCycleReminder() {
      return cycleReminder;
    }

    public void setCycleReminder(Date cycleReminder) {
      this.cycleReminder = cycleReminder;
    }

    public Date getCycleDelinquent() {
      return cycleDelinquent;
    }

    public void setCycleDelinquent(Date cycleDelinquent) {
      this.cycleDelinquent = cycleDelinquent;
    }

    public boolean isCompleted() {
      return completed;
    }

    public void setCompleted(boolean completed) {
      this.completed = completed;
    }

    @Override
    public String toString() {
      return "PeriodMaintenanceVO{" +
              "name='" + name + '\'' +
              ", description='" + description + '\'' +
              ", cycleOnly='" + cycleOnly + '\'' +
              ", currentPeriod='" + currentPeriod + '\'' +
              ", status='" + status + '\'' +
              ", news='" + news + '\'' +
              ", controlNotification=" + controlNotification +
              ", controlReminder=" + controlReminder +
              ", controlDelinquent=" + controlDelinquent +
              ", subcycleNotification=" + subcycleNotification +
              ", subcycleReminder=" + subcycleReminder +
              ", subcycleDelinquent=" + subcycleDelinquent +
              ", cycleNotification=" + cycleNotification +
              ", cycleReminder=" + cycleReminder +
              ", cycleDelinquent=" + cycleDelinquent +
              ", completed=" + completed +
              '}';
    }
}
