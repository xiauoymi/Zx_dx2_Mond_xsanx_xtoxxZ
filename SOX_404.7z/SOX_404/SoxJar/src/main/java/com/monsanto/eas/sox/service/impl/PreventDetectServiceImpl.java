package com.monsanto.eas.sox.service.impl;

import com.monsanto.eas.sox.dao.PreventDetectDao;
import com.monsanto.eas.sox.model.PreventDetect;
import com.monsanto.eas.sox.service.PreventDetectService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.flex.remoting.RemotingDestination;
import org.springframework.flex.remoting.RemotingInclude;
import org.springframework.stereotype.Service;

@Service
@RemotingDestination(value = "preventDetectService")
public class PreventDetectServiceImpl implements PreventDetectService {

    @Autowired
    private PreventDetectDao preventDetectDao;

    @RemotingInclude
    public PreventDetect getPreventDetectByDescription(String description) {
        PreventDetect preventDetect = preventDetectDao.lookupPreventDetectByDescription(description);
        return preventDetect;
    }
}
