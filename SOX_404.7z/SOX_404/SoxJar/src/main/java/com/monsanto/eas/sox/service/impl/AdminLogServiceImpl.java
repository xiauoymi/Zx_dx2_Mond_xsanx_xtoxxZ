package com.monsanto.eas.sox.service.impl;

import com.monsanto.PeoplePicker.PersonInfo;
import com.monsanto.eas.sox.dao.AdminLogDao;
import com.monsanto.eas.sox.exception.InvalidUserException;
import com.monsanto.eas.sox.model.SoxAdminLog;
import com.monsanto.eas.sox.service.AdminLogService;
import com.monsanto.eas.sox.service.SearchPeopleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.flex.remoting.RemotingDestination;
import org.springframework.flex.remoting.RemotingInclude;
import org.springframework.stereotype.Service;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: JEESCO
 * Date: 8/02/12
 * Time: 10:57 AM
 */
@Service
@RemotingDestination(value = "adminLogService")
public class AdminLogServiceImpl implements AdminLogService {
    @Autowired
    private AdminLogDao adminLogDao;

    @Autowired
    private SearchPeopleService searchPeopleService;


    @RemotingInclude
    public Collection<SoxAdminLog> lookupLogEntries() {
        return adminLogDao.lookupLogEntries();
    }

    @RemotingInclude
    public Collection<SoxAdminLog> lookupLogEntries(String periodId) throws InvalidUserException {
        Collection<SoxAdminLog> soxAdminLogs = adminLogDao.lookupLogEntriesByPeriod(periodId);
        for (SoxAdminLog soxAdminLog : soxAdminLogs) {
            PersonInfo personInfo = null;
            if (soxAdminLog.getOwner() != null) {
                //personInfo = searchPeopleService.findPersonByUserId(soxAdminLog.getOwner());
                personInfo = getPersonInfoHandleInactiveUsers(soxAdminLog.getOwner());
                soxAdminLog.setCurrentOwnerFirstName(personInfo.getFirstName());
                soxAdminLog.setCurrentOwnerLastName(personInfo.getLastName());
            }
            if (soxAdminLog.getNewOwner() != null) {
                //personInfo = searchPeopleService.findPersonByUserId(soxAdminLog.getNewOwner());
                personInfo = getPersonInfoHandleInactiveUsers(soxAdminLog.getNewOwner());
                soxAdminLog.setNewOwnerFirstName(personInfo.getFirstName());
                soxAdminLog.setNewOwnerLastName(personInfo.getLastName());
            }

        }
        return soxAdminLogs;
    }

    private PersonInfo getPersonInfoHandleInactiveUsers(String owner) {
        PersonInfo personInfo = null;
        try {
            personInfo = searchPeopleService.findPersonByUserId(owner);
        }
        catch (InvalidUserException iue) {
            personInfo = new PersonInfo();
            personInfo.setUserId(owner);
            personInfo.setFirstName("");
            personInfo.setLastName("");
        }
        return personInfo;
    }

}

