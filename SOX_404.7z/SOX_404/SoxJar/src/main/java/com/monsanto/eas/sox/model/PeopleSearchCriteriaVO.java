package com.monsanto.eas.sox.model;

public class PeopleSearchCriteriaVO {
    private String lastName; 
    private String firstName; 
    private String phone; 
    private String mailStop; 
    private String userId; 
    private String site; 
    private String mailZone;

    public PeopleSearchCriteriaVO(String lastName, String firstName, String phone, String mailStop, String userId, String site, String mailZone) {
        this.lastName = lastName;
        this.firstName = firstName;
        this.phone = phone;
        this.mailStop = mailStop;
        this.userId = userId;
        this.site = site;
        this.mailZone = mailZone;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getMailStop() {
        return mailStop;
    }

    public void setMailStop(String mailStop) {
        this.mailStop = mailStop;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getSite() {
        return site;
    }

    public void setSite(String site) {
        this.site = site;
    }

    public String getMailZone() {
        return mailZone;
    }

    public void setMailZone(String mailZone) {
        this.mailZone = mailZone;
    }

    @Override
    public String toString() {
        return "PeopleSearchCriteriaVO{" +
                "lastName='" + lastName + '\'' +
                ", firstName='" + firstName + '\'' +
                ", phone='" + phone + '\'' +
                ", mailStop='" + mailStop + '\'' +
                ", userId='" + userId + '\'' +
                ", site='" + site + '\'' +
                ", mailZone='" + mailZone + '\'' +
                '}';
    }
}
