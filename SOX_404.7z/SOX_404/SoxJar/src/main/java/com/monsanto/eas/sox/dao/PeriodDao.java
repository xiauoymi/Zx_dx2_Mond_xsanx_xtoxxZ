package com.monsanto.eas.sox.dao;

import com.monsanto.eas.sox.model.SoxPeriod;

import java.util.Collection;

public interface PeriodDao extends GenericDao<SoxPeriod>{
    SoxPeriod lookupCurrentPeriod();
    Collection<SoxPeriod> lookupAllPeriods();
    Boolean getNewPeriodAvailability();
    SoxPeriod getMaximumPeriod();
}
