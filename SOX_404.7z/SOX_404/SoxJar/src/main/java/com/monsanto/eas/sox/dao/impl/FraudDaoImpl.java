package com.monsanto.eas.sox.dao.impl;

import com.monsanto.eas.sox.dao.FraudDao;
import com.monsanto.eas.sox.model.Fraud;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.util.List;

@Repository
public class FraudDaoImpl extends GenericDaoImpl<Fraud> implements FraudDao{
    private static final long serialVersionUID = 1L;

    @PersistenceContext
    private EntityManager entityManager;


    @Override
    public Fraud lookupFraudByDescription(String description) {
        Fraud fraud = null;

        List<Fraud> fraudList = entityManager.createNamedQuery("lookupFraudByDescription").setParameter("description", description).getResultList();
        if (fraudList != null && fraudList.size() > 0) {
            fraud = fraudList.get(0);
        }
        return fraud;
    }
}
