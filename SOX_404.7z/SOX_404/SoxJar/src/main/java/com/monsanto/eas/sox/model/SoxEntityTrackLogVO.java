package com.monsanto.eas.sox.model;

/**
 * Created by FJADAN on 3/13/14.
 */
public class SoxEntityTrackLogVO {

    String controlEntityId;
    SOXPeriodWithCycleTemplateDataVO originalSOXTemplateVO;
    SOXPeriodWithCycleTemplateDataVO newSOXTemplateVO;

    public SoxEntityTrackLogVO(){}

    public String getControlEntityId() {
        return controlEntityId;
    }

    public void setControlEntityId(String controlEntityId) {
        this.controlEntityId = controlEntityId;
    }

    public SOXPeriodWithCycleTemplateDataVO getOriginalSOXTemplateVO() {
        return originalSOXTemplateVO;
    }

    public void setOriginalSOXTemplateVO(SOXPeriodWithCycleTemplateDataVO originalSOXTemplateVO) {
        this.originalSOXTemplateVO = originalSOXTemplateVO;
    }

    public SOXPeriodWithCycleTemplateDataVO getNewSOXTemplateVO() {
        return newSOXTemplateVO;
    }

    public void setNewSOXTemplateVO(SOXPeriodWithCycleTemplateDataVO newSOXTemplateVO) {
        this.newSOXTemplateVO = newSOXTemplateVO;
    }
}
