package com.monsanto.eas.sox.controller;

import com.google.common.io.Closeables;
import com.monsanto.eas.sox.exception.TemplateException;
import com.monsanto.eas.sox.model.SoxControlEntity;
import com.monsanto.eas.sox.service.ImportExcel2DB;
import com.monsanto.eas.sox.service.UploadResultXmlService;
import org.apache.commons.fileupload.FileItem;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.PrintWriter;
import java.util.List;

@Controller
@RequestMapping(value = "/upload/excel")
public class UploadProcessDefinitionController extends ProcessDefinitionController {
    private static final String CONTENT_TYPE = "text/xml;charset=utf-8";

    private static Logger logger = Logger.getLogger(UploadProcessDefinitionController.class.getName());

    private ImportExcel2DB importExcel2DB;
    private UploadResultXmlService uploadResultXmlService;

    @Autowired
    public UploadProcessDefinitionController(ImportExcel2DB importExcel2DB, UploadResultXmlService uploadResultXmlService) {
        this.importExcel2DB = importExcel2DB;
        this.uploadResultXmlService = uploadResultXmlService;
    }

    @Override
    @SuppressWarnings("unchecked")
    protected void executeProcessDefinition(HttpServletRequest request, HttpServletResponse response) {

        PrintWriter out = null;

        try {
            String xml = null;

            response.setContentType(CONTENT_TYPE);

            out = response.getWriter();

            List items = (List) request.getSession(true).getAttribute("items");

            for (Object item : items) {
                FileItem fileItem = (FileItem) item;

                if (!fileItem.isFormField()) {

                    String fieldName = fileItem.getFieldName();
                    String fileName = fileItem.getName();

                    if (logger.isDebugEnabled()) {
                        logger.debug("Field Name:" + fieldName + ",File Name:" + fileName);
                        logger.debug("Content Type:" + fileItem.getContentType() + ",Is In Memory:" + fileItem.isInMemory() + ",Size:" + fileItem.getSize());
                    }

                    SoxControlEntity controlEntity = null;
                    try
                    {
                        controlEntity = importExcel2DB.importFile(fileName, fileItem.getInputStream());
                        xml = uploadResultXmlService.serialize(controlEntity, "success", "The file was successfully processed: " + fileName);
                    }
                    catch (Exception ex)
                    {
                        xml = uploadResultXmlService.serialize(null, "error", ex.getMessage());
                        //throw ex;
                    }

                    Closeables.closeQuietly(fileItem.getInputStream());
                }
            }

            out.print(xml);
        }
        catch (Exception e) {
            if(e instanceof TemplateException) {
                response.setStatus(HttpServletResponse.SC_NOT_IMPLEMENTED);
                logger.error(e.getMessage(), e);
            } else {
                response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
                logger.error("Error while importing the file", e);
            }
        }
        finally {
            Closeables.closeQuietly(out);
        }
    }
}
