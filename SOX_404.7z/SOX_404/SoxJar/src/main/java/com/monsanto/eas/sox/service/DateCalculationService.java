package com.monsanto.eas.sox.service;

import java.util.Date;

/**
 * Created by IntelliJ IDEA.
 * User: JEESCO
 * Date: 15/02/2012
 * Time: 10:43:54 AM
 */
public interface DateCalculationService {
    static final int DAYS_FOR_SENDING_REMINDER = 3;
    
    Date calculateBusinessDate();
}
