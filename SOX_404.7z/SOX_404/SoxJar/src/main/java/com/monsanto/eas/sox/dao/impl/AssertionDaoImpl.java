package com.monsanto.eas.sox.dao.impl;

import com.monsanto.eas.sox.dao.AssertionDao;
import com.monsanto.eas.sox.model.Assertion;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.util.List;

@Repository
public class AssertionDaoImpl extends GenericDaoImpl<Assertion> implements AssertionDao{
    private static final long serialVersionUID = 1L;

    @PersistenceContext
    private EntityManager entityManager;

    @Override
    public Assertion lookupAssertionByDescription(String description){
        Assertion assertion = null;
        List<Assertion> assertions = entityManager.createNamedQuery("lookupAssertionByDescription").setParameter("description","%"+description+"%").getResultList();
        if(assertions != null && assertions.size() > 0){
            assertion = assertions.get(0);
        }
        return assertion;
    }

}
