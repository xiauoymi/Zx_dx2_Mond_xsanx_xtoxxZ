package com.monsanto.eas.sox.service;

import com.monsanto.eas.sox.model.SoxConfig;
import org.springframework.flex.remoting.RemotingInclude;

import java.util.List;
import java.util.Map;

public interface ConfigService {
  @RemotingInclude
  void save(SoxConfig config);

  @RemotingInclude
  void merge(SoxConfig config);

  @RemotingInclude
  SoxConfig lookupConfigByName(String parameterName);

  @RemotingInclude
  List<SoxConfig> lookupConfigsByName(String parameterMask);

  @RemotingInclude
  Map<String, String> getDictionary(String parameterMask);
}
