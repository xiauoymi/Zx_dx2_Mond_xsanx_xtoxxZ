package com.monsanto.eas.sox.dao.impl;

import com.monsanto.eas.sox.dao.TypeOfControlDao;
import com.monsanto.eas.sox.model.TypeOfControl;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.util.List;

@Repository
public class TypeOfControlDaoImpl extends GenericDaoImpl<TypeOfControl> implements TypeOfControlDao {
    private static final long serialVersionUID = 1L;

    @PersistenceContext
    private EntityManager entityManager;

    @Override
    public TypeOfControl lookupTypeOfControlByDescription(String description) {
        TypeOfControl typeOfControl = null;

        List<TypeOfControl> types = entityManager.createNamedQuery("lookupTypeOfControlByDescription").setParameter("description", description).getResultList();
        if(types != null && types.size() > 0) {
            typeOfControl = types.get(0);
        }
        return typeOfControl;
    }
}
