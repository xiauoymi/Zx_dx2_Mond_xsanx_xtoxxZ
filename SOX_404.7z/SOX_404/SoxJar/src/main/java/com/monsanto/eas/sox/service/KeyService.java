package com.monsanto.eas.sox.service;

import com.monsanto.eas.sox.model.Key;

public interface KeyService {
    Key getKeyByDescription(String description);
}
