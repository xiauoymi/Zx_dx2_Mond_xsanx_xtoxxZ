package com.monsanto.eas.sox.service;

import com.monsanto.eas.sox.model.SoxPeriod;
import com.monsanto.eas.sox.model.SoxResponse;
import com.monsanto.eas.sox.model.TestSoxPeriod;
import com.monsanto.eas.sox.model.TestYear;

import java.util.Collection;

public interface PeriodService {
    SoxPeriod getCurrentPeriod();
    SoxPeriod getPreviousPeriod();
    SoxPeriod getPeriodById(String periodId);
    TestSoxPeriod getTestCurrentPeriod();
    public Collection<SoxPeriod> getAllPeriods();
    public TestYear getTestYear();
    public SoxResponse getTestResponse();
}
