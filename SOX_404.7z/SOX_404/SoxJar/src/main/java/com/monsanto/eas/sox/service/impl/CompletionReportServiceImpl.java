package com.monsanto.eas.sox.service.impl;

import com.monsanto.eas.sox.dao.CompletionReportDao;
import com.monsanto.eas.sox.model.CompletionReportDataVO;
import com.monsanto.eas.sox.model.CompletionReportVO;
import com.monsanto.eas.sox.service.CompletionReportService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.flex.remoting.RemotingDestination;
import org.springframework.flex.remoting.RemotingInclude;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;

/**
 * Created by IntelliJ IDEA.
 * User: JEESCO
 * Date: 1/02/2012
 * Time: 05:07:26 PM
 */
@Service
@RemotingDestination(value = "completionReportService")
public class CompletionReportServiceImpl implements CompletionReportService {
    @Autowired
    private CompletionReportDao completionReportDao;

    @RemotingInclude
    public Collection<CompletionReportDataVO> getReportByCycle(String cycleId) {
        Collection<CompletionReportVO> entities = completionReportDao.retrieveEntitiesByCycle(cycleId);

        return buildReport(entities);
    }

    @RemotingInclude
    public Collection<CompletionReportDataVO> getReportByPeriodAndCountry(String periodId, Integer countryId) {
        Collection<CompletionReportVO> entities = completionReportDao.retrieveEntitiesByPeriodAndCountry(periodId, countryId);

        return buildReport(entities);
    }

    @RemotingInclude
    public Collection<CompletionReportDataVO> getReportByCycleAndCountry(String cycleId, Integer countryId) {
        Collection<CompletionReportVO> entities = completionReportDao.retrieveEntitiesByCycleAndCountry(cycleId, countryId);

        return buildReport(entities);
    }

    private Collection<CompletionReportDataVO> buildReport(Collection<CompletionReportVO> entities) {
        Collection<CompletionReportDataVO> result = new ArrayList<CompletionReportDataVO>();

        Double completedPercentage = 0.0d;

        if (entities.size() > 0) {
            completedPercentage = calculatePercentage(getTotalCount(entities), getNonCompletedTotalCount(entities));
        }

        result.add(configureReportData(true, completedPercentage));
        result.add(configureReportData(false, formatNumber(100 - completedPercentage)));

        return result;
    }

    private int getTotalCount(Collection<CompletionReportVO> result) {
        int totalCount = 0;

        if (result != null) {
            totalCount = result.size();
        }

        return totalCount;
    }

    private int getNonCompletedTotalCount(Collection<CompletionReportVO> result) {
        int nonCompletedEntities = 0;
        if (result != null) {
            Iterator<CompletionReportVO> iterator = result.iterator();
            while (iterator.hasNext()) {
                CompletionReportVO tmpVO = iterator.next();
                if (tmpVO.getResponseTypeId() == null) {
                    nonCompletedEntities++;
                }
            }
        }
        return nonCompletedEntities;
    }

    private Double calculatePercentage(int total, int nonCertifiedTotal) {
        double result = ((total - nonCertifiedTotal) / (double) total) * 100;
        return formatNumber(result);
    }

    private Double formatNumber(double nonFormatted) {
        BigDecimal bigDecimal = new BigDecimal(nonFormatted);
        bigDecimal = bigDecimal.setScale(DECIMAL_POSITIONS, RoundingMode.HALF_EVEN);
        return bigDecimal.doubleValue();
    }

    private CompletionReportDataVO configureReportData(boolean isCompletedPercentage, Double percentage) {
        CompletionReportDataVO reportData = new CompletionReportDataVO();
        if (isCompletedPercentage) {
            reportData.setId(COMPLETED_CHART_LEGEND);
        } else {
            reportData.setId(NON_COMPLETED_CHART_LEGEND);
        }

        reportData.setCompletedPercentage(percentage);
        return reportData;
    }
}
