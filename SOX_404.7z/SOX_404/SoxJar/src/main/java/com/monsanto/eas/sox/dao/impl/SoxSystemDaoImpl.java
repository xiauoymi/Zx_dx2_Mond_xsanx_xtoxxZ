package com.monsanto.eas.sox.dao.impl;

import com.monsanto.eas.sox.dao.SoxSystemDao;
import com.monsanto.eas.sox.model.SoxSystem;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.util.Collection;
import java.util.List;

@Repository
public class SoxSystemDaoImpl extends GenericDaoImpl<SoxSystem> implements SoxSystemDao {
   private static final long serialVersionUID = 1L;

   @PersistenceContext
   private EntityManager entityManager;

   @Override
   public SoxSystem lookupSoxSystemByDescription(String description) {
      SoxSystem system = null;

      List<SoxSystem> systems = entityManager.createNamedQuery("lookupSystemByDescription").setParameter("description", description).getResultList();
      if (systems != null && systems.size() > 0) {
         system = systems.get(0);
      }
      return system;
   }

   @Override
   public Collection<SoxSystem> lookupAllSoxSystems() {
      List<SoxSystem> systems = entityManager.createNamedQuery("lookupAllSoxSystems").getResultList();

      return systems;
   }
}
