package com.monsanto.eas.sox.dao.impl;

import com.monsanto.eas.sox.dao.KeyDao;
import com.monsanto.eas.sox.model.Key;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.util.List;

@Repository
public class KeyDaoImpl extends GenericDaoImpl<Key> implements KeyDao{
    private static final long serialVersionUID = 1L;

    @PersistenceContext
    private EntityManager entityManager;

    public Key lookupKeyByDescription(String description) {
        Key key = null;
        List<Key> keyList = entityManager.createNamedQuery("lookupKeyByDescription").setParameter("description",description).getResultList();
        if(keyList != null && keyList.size() > 0) {
            key = keyList.get(0);
        }
        return key;
    }
}
