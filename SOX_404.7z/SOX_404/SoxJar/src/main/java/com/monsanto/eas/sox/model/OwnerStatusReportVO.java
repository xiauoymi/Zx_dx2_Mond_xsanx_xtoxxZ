package com.monsanto.eas.sox.model;

public class OwnerStatusReportVO {
    private String controlEntityId;
    private String userId;
    private String firstName;
    private String lastName;
    private String region;
    private String status;
    private String controlEntityDescription;
    private boolean activeAndValidUser;

    public OwnerStatusReportVO() { }

    public OwnerStatusReportVO(String controlEntityId, String userId, String status, String controlEntityDescription, boolean activeAndValidUser) {
        this.controlEntityId = controlEntityId;
        this.userId = userId;
        this.status = status;
        this.controlEntityDescription = controlEntityDescription;
        this.activeAndValidUser = activeAndValidUser;
    }

    public String getControlEntityId() {
        return controlEntityId;
    }

    public void setControlEntityId(String controlEntityId) {
        this.controlEntityId = controlEntityId;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getControlEntityDescription() {
        return controlEntityDescription;
    }

    public void setControlEntityDescription(String controlEntityDescription) {
        this.controlEntityDescription = controlEntityDescription;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getRegion() {
        return region;
    }

    public void setRegion(String region) {
        this.region = region;
    }

    public boolean isActiveAndValidUser() {
        return activeAndValidUser;
    }

    public void setActiveAndValidUser(boolean activeAndValidUser) {
        this.activeAndValidUser = activeAndValidUser;
    }
}
