package com.monsanto.eas.sox.model;

import java.io.Serializable;

public class TestSoxPeriod implements Serializable{

    private String periodId;

    private String periodDescription;

    private String cycleOnly;

    private String currentPeriod;
//
//    public String getPeriodId() {
//        return periodId;
//    }
//
//    public void setPeriodId(String periodId) {
//        this.periodId = periodId;
//    }
//
//    public String getPeriodDescription() {
//        return periodDescription;
//    }
//
//    public void setPeriodDescription(String periodDescription) {
//        this.periodDescription = periodDescription;
//    }
//
//    public String getCycleOnly() {
//        return cycleOnly;
//    }
//
//    public void setCycleOnly(String cycleOnly) {
//        this.cycleOnly = cycleOnly;
//    }
//
//    public String getCurrentPeriod() {
//        return currentPeriod;
//    }
//
//    public void setCurrentPeriod(String currentPeriod) {
//        this.currentPeriod = currentPeriod;
//    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        TestSoxPeriod soxPeriod = (TestSoxPeriod) o;

        if (periodId != soxPeriod.periodId) return false;
        if (currentPeriod != null ? !currentPeriod.equals(soxPeriod.currentPeriod) : soxPeriod.currentPeriod != null)
            return false;
        if (cycleOnly != null ? !cycleOnly.equals(soxPeriod.cycleOnly) : soxPeriod.cycleOnly != null) return false;
        if (periodDescription != null ? !periodDescription.equals(soxPeriod.periodDescription) : soxPeriod.periodDescription != null)
            return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = (periodId != null ? periodId.hashCode() : 0);;
        result = 31 * result + (periodDescription != null ? periodDescription.hashCode() : 0);
        result = 31 * result + (cycleOnly != null ? cycleOnly.hashCode() : 0);
        result = 31 * result + (currentPeriod != null ? currentPeriod.hashCode() : 0);
        return result;
    }

//    @Override
//    public String toString() {
//        return "SoxPeriod{" +
//                "periodId='" + periodId + '\'' +
//                ", periodDescription='" + periodDescription + '\'' +
//                ", cycleOnly='" + cycleOnly + '\'' +
//                ", currentPeriod='" + currentPeriod + '\'' +
//                '}';
//    }

  public String getPeriodId() {
    return periodId;
  }

  public void setPeriodId(String periodId) {
    this.periodId = periodId;
  }

  public String getPeriodDescription() {
    return periodDescription;
  }

  public void setPeriodDescription(String periodDescription) {
    this.periodDescription = periodDescription;
  }

  public String getCycleOnly() {
    return cycleOnly;
  }

  public void setCycleOnly(String cycleOnly) {
    this.cycleOnly = cycleOnly;
  }

  public String getCurrentPeriod() {
    return currentPeriod;
  }

  public void setCurrentPeriod(String currentPeriod) {
    this.currentPeriod = currentPeriod;
  }
} // end of class