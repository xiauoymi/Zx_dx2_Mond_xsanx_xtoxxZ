package com.monsanto.eas.sox.dao;

import com.monsanto.eas.sox.model.SoxControlEntity;

public interface JdbcControlEntityDao extends GenericDao<SoxControlEntity> {
    void deleteSoxControlEntity(String cycleId);
    void deleteCtrlEntityDependencies(String cycleId);
}
