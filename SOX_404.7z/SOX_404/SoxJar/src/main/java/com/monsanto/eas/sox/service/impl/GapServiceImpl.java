package com.monsanto.eas.sox.service.impl;

import com.monsanto.PeoplePicker.PersonInfo;
import com.monsanto.eas.sox.dao.ControlEntityOwnerDao;
import com.monsanto.eas.sox.dao.GapDao;
import com.monsanto.eas.sox.exception.InvalidUserException;
import com.monsanto.eas.sox.model.*;
import com.monsanto.eas.sox.service.GapService;
import com.monsanto.eas.sox.service.SearchPeopleService;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.flex.remoting.RemotingDestination;
import org.springframework.flex.remoting.RemotingInclude;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.Collection;

@Service
@RemotingDestination(value="gapService")
public class GapServiceImpl implements GapService{

    @Autowired
    private GapDao gapDao;

    @Autowired
    private SearchPeopleService searchPeopleService;

    static Logger logger = Logger.getLogger(GapServiceImpl.class.getName());

    @Autowired
    private ControlEntityOwnerDao controlEntityOwnerDao;

    @RemotingInclude
    public void deleteGap(SoxGap soxGap) {
        gapDao.delete(soxGap);
    }

    @RemotingInclude
    @Transactional
    public Collection<SoxGapVO> getGapsByEntityAndOwner(String entityId, String userId) {
        Collection<SoxGap> result = new ArrayList<SoxGap>();

        Collection<SoxGapVO> gaps= new ArrayList<SoxGapVO>();

        SoxControlEntityOwner controlEntityOwner = controlEntityOwnerDao.lookupControlEntityOwnerByEntityAndOwner(entityId, userId);

        if (controlEntityOwner != null) {
            SoxControlEntity controlEntity = controlEntityOwner.getSoxControlEntity();

            if (controlEntity != null) {
                if (controlEntity.getParentControlEntity() == null) {
                    // cycle
                    for (SoxControlEntity subCycle : controlEntity.getChildControlEntities()) {
                        for (SoxControlEntity activity : subCycle.getChildControlEntities()) {
                            result.addAll(gapDao.lookupGapsByEntity(activity.getControlEntityId()));
                        }
                        result.addAll(gapDao.lookupGapsByEntity(subCycle.getControlEntityId()));
                    }
                    result.addAll(gapDao.lookupGapsByEntityAndOwner(controlEntity.getControlEntityId(), userId));
                } else if (controlEntity.getParentControlEntity() != null && controlEntity.getParentControlEntity().getParentControlEntity() == null) {
                    // subCycle
                    for (SoxControlEntity activity : controlEntity.getChildControlEntities()) {
                        result.addAll(gapDao.lookupGapsByEntity(activity.getControlEntityId()));
                    }
                    result.addAll(gapDao.lookupGapsByEntityAndOwner(controlEntity.getControlEntityId(), userId));
                } else if (controlEntity.getParentControlEntity() != null && controlEntity.getParentControlEntity().getParentControlEntity() != null
                        && controlEntity.getParentControlEntity().getParentControlEntity().getParentControlEntity() == null) {
                    // activity
                    result.addAll(gapDao.lookupGapsByEntityAndOwner(entityId, userId));
                }
            }
        }

        for(SoxGap currentGap : result) {
            if(currentGap.getSoxResponse() != null
                    && currentGap.getSoxResponse().getSoxControlEntityOwner() != null){

                SoxResponse sr = currentGap.getSoxResponse();
                sr.getSoxQuestion().setSoxResponses(null);
                SoxControlEntityOwner ceo = sr.getSoxControlEntityOwner();
                ceo.setSoxSignificantChanges(null);
                ceo.setSoxCountry(null);
                ceo.getSoxControlEntity().setSoxCtrlActivityEntities(null);
                ceo.getSoxControlEntity().setSoxControlEntityOwners(null);

                gaps.add(new SoxGapVO(currentGap));


            }
            logger.debug("currentGap: " + currentGap.getDescription());
        }

        return gaps;
    }

    @RemotingInclude
    public Collection<GapReportVO> getGapsByPeriod(String periodId) throws InvalidUserException  {
        Collection<GapReportVO> result = gapDao.lookupGapsByPeriod(periodId);

        fillFirstAndLastName(result);

        return result;
    }

    private void fillFirstAndLastName(Collection<GapReportVO> gapReportVOCollection) throws InvalidUserException {
        for (GapReportVO gapReportVO : gapReportVOCollection) {
            PersonInfo personInfo = searchPeopleService.findPersonByUserId(gapReportVO.getUserId());

            gapReportVO.setFirstName(personInfo.getFirstName());
            gapReportVO.setLastName(personInfo.getLastName());
            gapReportVO.setRegion(personInfo.getMailStop());

        }
    }

}
