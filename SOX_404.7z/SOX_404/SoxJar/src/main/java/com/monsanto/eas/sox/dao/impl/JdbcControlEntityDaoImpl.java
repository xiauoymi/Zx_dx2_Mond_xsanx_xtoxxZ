package com.monsanto.eas.sox.dao.impl;

import com.monsanto.eas.sox.dao.JdbcControlEntityDao;
import com.monsanto.eas.sox.model.SoxControlEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import javax.sql.DataSource;

@Repository
public class JdbcControlEntityDaoImpl extends GenericDaoImpl<SoxControlEntity> implements JdbcControlEntityDao {
    private static final long serialVersionUID = 1L;

    private JdbcTemplate jdbcTemplate;

    @Autowired
    public void setDataSource(DataSource dataSource) {
        this.jdbcTemplate = new JdbcTemplate(dataSource);
    }

    @Override
    public void deleteSoxControlEntity(String cycleId) {
        jdbcTemplate.update("call sarbox_et.delete_sox_control_entity(?)",cycleId);
    }

   @Override
   public void deleteCtrlEntityDependencies(String cycleId) {
      jdbcTemplate.update("call sarbox_et.DELETE_CTRL_ENTITY_REFERENCES(?)",cycleId);
   }

}
