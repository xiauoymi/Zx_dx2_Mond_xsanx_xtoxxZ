package com.monsanto.eas.sox.dao;

import com.monsanto.eas.sox.model.CompletionReportVO;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: JEESCO
 * Date: 1/02/2012
 * Time: 01:03:03 PM
 */
public interface CompletionReportDao extends GenericDao<CompletionReportVO> {
    Collection<CompletionReportVO> retrieveEntitiesByCycle(String cycleId);
    Collection<CompletionReportVO> retrieveEntitiesByPeriodAndCountry(String periodId, Integer countryId);
    Collection<CompletionReportVO> retrieveEntitiesByCycleAndCountry(String cycleId, Integer countryId);
}
