package com.monsanto.eas.sox.service;

import com.monsanto.eas.sox.model.CompletionReportDataVO;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: JEESCO
 * Date: 1/02/2012
 * Time: 05:05:47 PM
 */
public interface CompletionReportService {
    static final int DECIMAL_POSITIONS = 3;
    static final String COMPLETED_CHART_LEGEND = "Completed";
    static final String NON_COMPLETED_CHART_LEGEND = "Non completed";
    Collection<CompletionReportDataVO> getReportByCycle(String cycleId);
    Collection<CompletionReportDataVO> getReportByPeriodAndCountry(String periodId, Integer countryId);
    Collection<CompletionReportDataVO> getReportByCycleAndCountry(String cycleId, Integer countryId);

}
