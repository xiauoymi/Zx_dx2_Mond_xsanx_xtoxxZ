package com.monsanto.eas.sox.service.impl;

import com.monsanto.eas.sox.dao.QuestionDao;
import com.monsanto.eas.sox.model.SoxQuestion;
import com.monsanto.eas.sox.service.QuestionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.flex.remoting.RemotingDestination;
import org.springframework.flex.remoting.RemotingInclude;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Collection;

@Service
@RemotingDestination(value="questionService")
public class QuestionServiceImpl implements QuestionService {

    @Autowired
    private QuestionDao questionDao;

    @RemotingInclude
    public Collection<SoxQuestion> getQuestionsForEntity(String entityType) {
        Collection<SoxQuestion> questions = questionDao.lookupAllQuestions();
        Collection<SoxQuestion> result = new ArrayList<SoxQuestion>();
        for(SoxQuestion currentQuestion : questions) {
            if(currentQuestion.getLevelType().equalsIgnoreCase(entityType)) {
                result.add(currentQuestion);
            }
        }
        return result;
    }

    @RemotingInclude
    public Collection<SoxQuestion> getAllQuestions() {
        Collection<SoxQuestion> questions = questionDao.lookupAllQuestions();
        return questions;
    }
}
