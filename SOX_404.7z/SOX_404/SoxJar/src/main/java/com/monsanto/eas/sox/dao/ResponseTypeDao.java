package com.monsanto.eas.sox.dao;

import com.monsanto.eas.sox.model.ResponseType;

public interface ResponseTypeDao extends GenericDao<ResponseType>{
    ResponseType lookupResponseTypeByDescription(String description);
}
