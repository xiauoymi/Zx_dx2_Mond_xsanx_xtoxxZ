package com.monsanto.eas.sox.util;

public final class TestUtils
{
    private TestUtils() {}

    public static boolean setSearchPeopleServiceSystemProperties() {
        System.setProperty("xmlservice.peoplepicker.server", "w3t.ent.monsanto.com");
        System.setProperty("xmlservice.peoplepicker.vdir", "/ccca/pps");
        System.setProperty("xmlservice.peoplepicker.endpoint", "PeoplePicker.rem");
        return true;
    }
}
