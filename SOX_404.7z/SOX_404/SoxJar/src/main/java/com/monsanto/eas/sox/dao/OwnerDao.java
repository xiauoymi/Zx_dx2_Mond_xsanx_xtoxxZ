package com.monsanto.eas.sox.dao;

import com.monsanto.eas.sox.model.SoxOwner;

public interface OwnerDao extends GenericDao<SoxOwner> {

    SoxOwner lookupSoxOwnerByUserId(String userId);
}
