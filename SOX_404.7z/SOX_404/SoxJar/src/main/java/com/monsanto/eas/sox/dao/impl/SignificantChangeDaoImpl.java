package com.monsanto.eas.sox.dao.impl;

import com.monsanto.eas.sox.dao.SignificantChangeDao;
import com.monsanto.eas.sox.model.SoxSignificantChange;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;
import java.util.Collection;

@Repository
public class SignificantChangeDaoImpl extends GenericDaoImpl<SoxSignificantChange> implements SignificantChangeDao {

    private static final long serialVersionUID = 1L;

    @PersistenceContext
    private EntityManager entityManager;

    private JdbcTemplate jdbcTemplate;

    @Autowired
    public void setDataSource(DataSource dataSource) {
        this.jdbcTemplate = new JdbcTemplate(dataSource);
    }

    @Override
    @Transactional
    public void deleteSignificantChangeWithoutReferences() {
        jdbcTemplate.update("DELETE FROM SOX_SIGNIFICANT_CHANGE ssc " +
                "WHERE ssc.CONTROL_ENTITY_OWNER_ID IN (SELECT CONTROL_ENTITY_OWNER_ID FROM SOX_CONTROL_ENTITY_OWNER c WHERE c.CONTROL_ENTITY_ID is null) ");

    }

    public Collection<SoxSignificantChange> lookupSignificantChangeByEntityAndOwner(String entityId, String userId) {
        return entityManager.createNamedQuery("lookupSignificantChangeByEntityAndOwner").setParameter("entityId", entityId).setParameter("userId", userId).getResultList();
    }
}
