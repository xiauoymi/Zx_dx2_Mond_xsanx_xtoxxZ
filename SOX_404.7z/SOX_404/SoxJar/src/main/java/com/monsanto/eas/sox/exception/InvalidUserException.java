package com.monsanto.eas.sox.exception;

public class InvalidUserException extends Exception {
	public InvalidUserException(){
		super();
	}

    public InvalidUserException(String userName){
		super("InvalidUserException: " + userName);
	}

	public InvalidUserException(Exception e){
		super(e);
	}
}
