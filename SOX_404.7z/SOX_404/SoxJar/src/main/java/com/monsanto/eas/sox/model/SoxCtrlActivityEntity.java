package com.monsanto.eas.sox.model;

import com.google.common.base.Joiner;
import org.hibernate.annotations.Cascade;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.Set;

@Table(name = "SOX_CTRL_ACTIVITY_ENTITY", schema = "SARBOX_ET")
@Entity
public class SoxCtrlActivityEntity {

    @Id
    @SequenceGenerator(name = "soxCtrlActivityEntitySeq", sequenceName = "SARBOX_ET.SOX_CTRL_ACTIVITY_ENTITY_SEQ")
    @GeneratedValue(generator = "soxCtrlActivityEntitySeq", strategy = GenerationType.SEQUENCE)
    @javax.persistence.Column(name = "CONTROL_ACTIVITY_ID", nullable = false, insertable = true, updatable = true, length = 22, precision = 0)
    private int controlActivityId;

    @OneToMany(mappedBy = "soxCtrlActivityEntity", fetch = FetchType.EAGER)
    @Cascade({org.hibernate.annotations.CascadeType.ALL})
    private Collection<SoxCtrlActivityAssertion> soxCtrlActivityAssertions = new ArrayList<SoxCtrlActivityAssertion>();

    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "FRAUD_ID", referencedColumnName = "FRAUD_ID")
    private Fraud fraud;

    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "FREQUENCY_ID", referencedColumnName = "FREQUENCY_ID")
    private Frequency frequency;

    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "KEY_ID", referencedColumnName = "KEY_ID")
    private Key key;

    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "PREVENT_DETECT_ID", referencedColumnName = "PREVENT_DETECT_ID")
    private PreventDetect preventDetect;

    @ManyToOne
    @JoinColumn(name = "CONTROL_ENTITY_ID", referencedColumnName = "CONTROL_ENTITY_ID")
    private SoxControlEntity soxControlEntity;

    @ManyToMany(cascade = {CascadeType.MERGE, CascadeType.PERSIST})
    @JoinTable(name = "SOX_CTRL_ACT_ENTITY_SYSTEM", joinColumns = @JoinColumn(name = "CONTROL_ACTIVITY_ID"),
            inverseJoinColumns = @JoinColumn(name = "SYSTEM_ID"))
    private Set<SoxSystem> soxSystems = new HashSet<SoxSystem>();

    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "TYPE_OF_CONTROL_ID", referencedColumnName = "TYPE_OF_CONTROL_ID")
    private TypeOfControl typeOfControl;

    @javax.persistence.Column(name = "RISK", nullable = false, insertable = true, updatable = true, length = 22, precision = 0)
    @Basic
    private String risk;

    public int getControlActivityId() {
        return controlActivityId;
    }

    public void setControlActivityId(int controlActivityId) {
        this.controlActivityId = controlActivityId;
    }

    public Collection<SoxCtrlActivityAssertion> getSoxCtrlActivityAssertions() {
        return soxCtrlActivityAssertions;
    }

    public void setSoxCtrlActivityAssertions(Collection<SoxCtrlActivityAssertion> soxCtrlActivityAssertions) {
        this.soxCtrlActivityAssertions = soxCtrlActivityAssertions;
    }

    public void addSoxCtrlActivityAssertions(SoxCtrlActivityAssertion soxCtrlActivityAssertion) {
        if (soxCtrlActivityAssertion != null) {
            soxCtrlActivityAssertion.setSoxCtrlActivityEntity(this);
            soxCtrlActivityAssertions.add(soxCtrlActivityAssertion);
        }
    }

    public Fraud getFraud() {
        return fraud;
    }

    public void setFraud(Fraud fraud) {
        this.fraud = fraud;
    }

    public Frequency getFrequency() {
        return frequency;
    }

    public void setFrequency(Frequency frequency) {
        this.frequency = frequency;
    }

    public Key getKey() {
        return key;
    }

    public void setKey(Key key) {
        this.key = key;
    }

    public PreventDetect getPreventDetect() {
        return preventDetect;
    }

    public void setPreventDetect(PreventDetect preventDetect) {
        this.preventDetect = preventDetect;
    }

    public SoxControlEntity getSoxControlEntity() {
        return soxControlEntity;
    }

    public void setSoxControlEntity(SoxControlEntity soxControlEntity) {
        this.soxControlEntity = soxControlEntity;
    }

    public TypeOfControl getTypeOfControl() {
        return typeOfControl;
    }

    public void setTypeOfControl(TypeOfControl typeOfControl) {
        this.typeOfControl = typeOfControl;
    }

    public String getRisk() {
        return risk;
    }

    public void setRisk(String risk) {
        this.risk = risk;
    }

    public Set<SoxSystem> getSoxSystems() {
        return soxSystems;
    }

    public void setSoxSystems(Set<SoxSystem> soxSystems) {
        this.soxSystems = soxSystems;
    }

    public void addSoxSystems(Set<SoxSystem> systems) {
        getSoxSystems().addAll(systems);
    }

    public String getSoxSystemsAsString(String separator) {
        Set<String> systems = new HashSet<String>();

        Joiner joiner = Joiner.on(separator).skipNulls();

        for (SoxSystem soxSystem : getSoxSystems()) {
            systems.add(soxSystem.getDescription());
        }

        return joiner.join(systems);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        SoxCtrlActivityEntity that = (SoxCtrlActivityEntity) o;

        if (controlActivityId != that.controlActivityId) return false;
//        if (controlEntityId != that.controlEntityId) return false;
//        if (frequencyId != that.frequencyId) return false;
//        if (fraudId != that.fraudId) return false;
//        if (keyId != that.keyId) return false;
//        if (preventDetectId != that.preventDetectId) return false;
//        if (systemId != that.systemId) return false;
//        if (typeOfControlId != that.typeOfControlId) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = controlActivityId;
//        result = 31 * result + controlEntityId;
//        result = 31 * result + keyId;
//        result = 31 * result + fraudId;
//        result = 31 * result + preventDetectId;
//        result = 31 * result + frequencyId;
//        result = 31 * result + systemId;
//        result = 31 * result + typeOfControlId;
        return result;
    }
}
