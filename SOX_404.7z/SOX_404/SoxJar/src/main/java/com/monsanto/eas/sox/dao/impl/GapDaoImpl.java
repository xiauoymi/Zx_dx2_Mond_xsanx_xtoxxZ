package com.monsanto.eas.sox.dao.impl;

import com.monsanto.eas.sox.dao.GapDao;
import com.monsanto.eas.sox.model.GapReportVO;
import com.monsanto.eas.sox.model.SoxGap;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.util.Collection;

@Repository
public class GapDaoImpl extends GenericDaoImpl<SoxGap> implements GapDao {

    private static final long serialVersionUID = 1L;

    @PersistenceContext
    private EntityManager entityManager;

    public Collection<SoxGap> lookupGapsByEntityAndOwner(String entityId, String userId) {
        return entityManager.createNamedQuery("lookupGapsByEntityAndOwner").setParameter("entityId", entityId).setParameter("userId", userId).getResultList();
    }


    public Collection<SoxGap> lookupGapsByEntity(String entityId) {
        return entityManager.createNamedQuery("lookupGapsByEntity").setParameter("entityId", entityId).getResultList();
    }

    public Collection<GapReportVO> lookupGapsByPeriod(String periodId) {
        return entityManager.createNamedQuery("lookupGapsByPeriod").setParameter("periodId", periodId).getResultList();
    }
}
