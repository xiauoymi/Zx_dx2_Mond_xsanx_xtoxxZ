package com.monsanto.eas.sox.model;

import org.hibernate.annotations.Cascade;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.Collection;

@Table(name = "PREVENT_DETECT", schema = "SARBOX_ET")
@Entity
@NamedQueries({
        @NamedQuery(name = "lookupPreventDetectByDescription", query = "FROM PreventDetect pd WHERE pd.description=:description")
})
public class PreventDetect {

    @javax.persistence.Column(name = "PREVENT_DETECT_ID", nullable = false, insertable = true, updatable = true, length = 22, precision = 0)
    @Id
    private int preventDetectId;

    @javax.persistence.Column(name = "DESCRIPTION", nullable = true, insertable = true, updatable = true, length = 250, precision = 0)
    @Basic
    private String description;

    @OneToMany(mappedBy = "preventDetect", fetch = FetchType.LAZY)
    @Cascade({org.hibernate.annotations.CascadeType.ALL})
    private Collection<SoxCtrlActivityEntity> soxCtrlActivityEntities= new ArrayList<SoxCtrlActivityEntity>();

    public int getPreventDetectId() {
        return preventDetectId;
    }


    public void setPreventDetectId(int preventDetectId) {
        this.preventDetectId = preventDetectId;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Collection<SoxCtrlActivityEntity> getSoxCtrlActivityEntities() {
        return soxCtrlActivityEntities;
    }

    public void setSoxCtrlActivityEntities(Collection<SoxCtrlActivityEntity> soxCtrlActivityEntities) {
        this.soxCtrlActivityEntities = soxCtrlActivityEntities;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        PreventDetect that = (PreventDetect) o;

        if (preventDetectId != that.preventDetectId) return false;
        if (description != null ? !description.equals(that.description) : that.description != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = preventDetectId;
        result = 31 * result + (description != null ? description.hashCode() : 0);
        return result;
    }

    public void addSoxCtrlActivityEntity(SoxCtrlActivityEntity soxCtrlActivityEntity) {
        if (soxCtrlActivityEntity != null) {
            soxCtrlActivityEntity.setPreventDetect(this);
            soxCtrlActivityEntities.add(soxCtrlActivityEntity);
        }
    }
}
