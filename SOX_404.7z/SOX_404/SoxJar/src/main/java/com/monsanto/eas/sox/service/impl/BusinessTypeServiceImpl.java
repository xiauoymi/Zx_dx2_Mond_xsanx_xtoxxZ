package com.monsanto.eas.sox.service.impl;

import com.monsanto.eas.sox.dao.BusinessTypeDao;
import com.monsanto.eas.sox.model.SoxBusinessType;
import com.monsanto.eas.sox.service.BusinessTypeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.flex.remoting.RemotingDestination;
import org.springframework.flex.remoting.RemotingInclude;
import org.springframework.stereotype.Service;

import java.util.Collection;

@Service
@RemotingDestination(value="businessTypeService")
public class BusinessTypeServiceImpl implements BusinessTypeService{

    @Autowired
    private BusinessTypeDao businessTypeDao;


    @RemotingInclude
    public Collection<SoxBusinessType> getAllBusinessType() {
        return businessTypeDao.lookupAllBusinessType();
    }
}
