package com.monsanto.eas.sox.model;

import com.monsanto.eas.sox.util.ControlEntityProgress;
import org.hibernate.annotations.Cascade;

import javax.persistence.*;
import java.util.*;

@Entity
@Table(name = "SOX_CONTROL_ENTITY", schema = "SARBOX_ET")
public class SoxControlEntity {
    @javax.persistence.Column(name = "CONTROL_ENTITY_ID", nullable = false, insertable = true, updatable = true, length = 22, precision = 0)
    @Id
    private String controlEntityId;

    @ManyToOne(cascade = CascadeType.ALL, targetEntity = SoxControlEntity.class, fetch = FetchType.LAZY)
    @JoinColumn(name = "PARENT_CONTROL_ENTITY_ID", nullable = true)
    private SoxControlEntity parentControlEntity;

    @OneToMany(mappedBy = "parentControlEntity", targetEntity = SoxControlEntity.class, cascade = CascadeType.MERGE, fetch = FetchType.LAZY)
    @OrderBy("controlEntityId")
    //@Cascade({org.hibernate.annotations.CascadeType.SAVE_UPDATE})
    private Collection<SoxControlEntity> childControlEntities = new ArrayList<SoxControlEntity>();

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "PERIOD_ID", nullable = true)
    private SoxPeriod soxPeriod;

    @javax.persistence.Column(name = "DESCRIPTION", nullable = true, insertable = true, updatable = true, length = 10, precision = 0)
    @Basic
    private String description;

    @javax.persistence.Column(name = "START_DATE", nullable = true, insertable = true, updatable = true, length = 7, precision = 0)
    @Basic
    private Date startDate;

    @javax.persistence.Column(name = "END_DATE", nullable = true, insertable = true, updatable = true, length = 7, precision = 0)
    @Basic
    private Date endDate;

    @javax.persistence.Column(name = "REMINDER_DATE", nullable = true, insertable = true, updatable = true, length = 7, precision = 0)
    @Basic
    private Date reminderDate;

    @javax.persistence.Column(name = "COMPLETED_DATE", nullable = true, insertable = true, updatable = true, length = 7, precision = 0)
    @Basic
    private Date completedDate;

    @OneToMany(mappedBy = "soxControlEntity", fetch = FetchType.EAGER)
    @org.hibernate.annotations.Cascade({org.hibernate.annotations.CascadeType.ALL})
    private Set<SoxControlEntityOwner> soxControlEntityOwners = new HashSet<SoxControlEntityOwner>();

    @OneToMany(mappedBy = "soxControlEntity", fetch = FetchType.LAZY)
    @Cascade({org.hibernate.annotations.CascadeType.ALL})
    private Collection<SoxCtrlActivityEntity> soxCtrlActivityEntities = new ArrayList<SoxCtrlActivityEntity>();

    @ManyToMany(cascade = {CascadeType.PERSIST, CascadeType.MERGE})
    @JoinTable(name = "sox_control_entity_country", joinColumns = @JoinColumn(name = "CONTROL_ENTITY_ID"),
            inverseJoinColumns = @JoinColumn(name = "COUNTRY_ID"))
    private Set<SoxCountry> countries = new HashSet<SoxCountry>();

    @Transient
    private boolean enabled = false;

    @Transient
    private ControlEntityProgress controlEntityProgress = ControlEntityProgress.IN_PROGRESS_TWO_DAYS_REMAINING;

    @Transient
    private String entityTypeDelinquentLink;

    @Transient
    private boolean gaps = false;

    public String getEntityTypeDelinquentLink() {
        return entityTypeDelinquentLink;
    }

    public void setEntityTypeDelinquentLink(String entityTypeDelinquentLink) {
        this.entityTypeDelinquentLink = entityTypeDelinquentLink;
    }

    public boolean isGaps() {
        return gaps;
    }

    public void setGaps(boolean gaps) {
        this.gaps = gaps;
    }

    public ControlEntityProgress getControlEntityProgress() {
        return controlEntityProgress;
    }

    public void setControlEntityProgress(ControlEntityProgress controlEntityProgress) {
        this.controlEntityProgress = controlEntityProgress;
    }

    public boolean isEnabled() {
        return enabled;
    }

    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }

    public String getControlEntityId() {
        return controlEntityId;
    }

    public void setControlEntityId(String controlEntityId) {
        this.controlEntityId = controlEntityId;
    }

    public SoxControlEntity getParentControlEntity() {
        return parentControlEntity;
    }

    public void setParentControlEntity(SoxControlEntity parentControlEntity) {
        this.parentControlEntity = parentControlEntity;
    }

    public Collection<SoxControlEntity> getChildControlEntities() {
        return childControlEntities;
    }

    public void setChildControlEntities(Collection<SoxControlEntity> childControlEntities) {
        this.childControlEntities = childControlEntities;
    }

    public void addChildEntity(SoxControlEntity child) {
        if (child != null) {
            childControlEntities.add(child);
            child.setParentControlEntity(this);
        }
    }

    public SoxPeriod getSoxPeriod() {
        return soxPeriod;
    }

    public void setSoxPeriod(SoxPeriod soxPeriod) {
        this.soxPeriod = soxPeriod;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Date getStartDate() {
        return startDate;
    }

    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    public Date getEndDate() {
        return endDate;
    }

    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }

    public Date getReminderDate() {
        return reminderDate;
    }

    public void setReminderDate(Date reminderDate) {
        this.reminderDate = reminderDate;
    }

    public Date getCompletedDate() {
        return completedDate;
    }

    public void setCompletedDate(Date completedDate) {
        this.completedDate = completedDate;
    }

    public Set<SoxControlEntityOwner> getSoxControlEntityOwners() {
        return soxControlEntityOwners;
    }

    public void setSoxControlEntityOwners(Set<SoxControlEntityOwner> controlEntityOwners) {
        this.soxControlEntityOwners = controlEntityOwners;
    }

    public void addSoxControlEntityOwner(SoxControlEntityOwner controlEntityOwner) {
        if (controlEntityOwner != null) {
            controlEntityOwner.setSoxControlEntity(this);
            soxControlEntityOwners.add(controlEntityOwner);
        }
    }

    public Collection<SoxCtrlActivityEntity> getSoxCtrlActivityEntities() {
        return soxCtrlActivityEntities;
    }

    public void setSoxCtrlActivityEntities(Collection<SoxCtrlActivityEntity> soxCtrlActivityEntities) {
        this.soxCtrlActivityEntities = soxCtrlActivityEntities;
    }

    public void addSoxCtrlActivityEntity(SoxCtrlActivityEntity soxCtrlActivityEntity) {
        if (soxCtrlActivityEntity != null) {
            soxCtrlActivityEntity.setSoxControlEntity(this);
            soxCtrlActivityEntities.add(soxCtrlActivityEntity);
        }
    }

    public SoxControlEntity getChildEntity(String childControlEntityId) {

        Collection<SoxControlEntity> children = getChildControlEntities();

        for (SoxControlEntity currentChild : children) {
            if (currentChild.getControlEntityId() != null && currentChild.getControlEntityId().equals(childControlEntityId)) {
                return currentChild;
            }
        }

        return null;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        SoxControlEntity that = (SoxControlEntity) o;

        if (controlEntityId != that.controlEntityId) return false;
//        if (parentControlEntityId != that.parentControlEntityId) return false;
//        if (periodId != that.periodId) return false;
        if (completedDate != null ? !completedDate.equals(that.completedDate) : that.completedDate != null)
            return false;
        if (description != null ? !description.equals(that.description) : that.description != null) return false;
        if (endDate != null ? !endDate.equals(that.endDate) : that.endDate != null) return false;
        if (startDate != null ? !startDate.equals(that.startDate) : that.startDate != null) return false;
        if (reminderDate != null ? !reminderDate.equals(that.reminderDate) : that.reminderDate != null) return false;

        return true;
    }

    public Set<SoxCountry> getCountries() {
        return countries;
    }

    public void setCountries(Set<SoxCountry> countries) {
        this.countries = countries;
    }

    public void addCountries(Set<SoxCountry> countries) {
        getCountries().addAll(countries);
    }

    @Override
    public int hashCode() {
        int result = (controlEntityId != null ? controlEntityId.hashCode() : 0);
//        result = 31 * result + parentControlEntityId;
//        result = 31 * result + (periodId != null ? periodId.hashCode() : 0);;
        result = 31 * result + (description != null ? description.hashCode() : 0);
        result = 31 * result + (startDate != null ? startDate.hashCode() : 0);
        result = 31 * result + (endDate != null ? endDate.hashCode() : 0);
        result = 31 * result + (reminderDate != null ? reminderDate.hashCode() : 0);
        result = 31 * result + (completedDate != null ? completedDate.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        return "SoxControlEntity{" +
                "controlEntityId='" + controlEntityId + '\'' +
//                ", parentControlEntity=" + parentControlEntity +
                ", childControlEntities=" + (childControlEntities == null ? null : "" + childControlEntities.size()) +
                ", childControlEntities=" + (getSoxCtrlActivityEntities() == null ? null : "" + getSoxCtrlActivityEntities().size()) +
//                ", soxPeriod=" + soxPeriod +
//                ", description='" + description + '\'' +
//                ", startDate=" + startDate +
//                ", endDate=" + endDate +
//                ", completedDate=" + completedDate +
                ", soxControlEntityOwners=" + (soxControlEntityOwners == null ? null : "" + soxControlEntityOwners.size()) +
//                ", soxCtrlActivityEntitiesByControlEntityId=" + soxCtrlActivityEntitiesByControlEntityId +
                '}';
    }
} // end of class
