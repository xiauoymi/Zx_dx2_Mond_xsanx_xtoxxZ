package com.monsanto.eas.sox.service.impl;

import com.monsanto.eas.sox.service.ExportGridToExcelService;
import com.monsanto.eas.sox.service.ExportToExcelReportService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.flex.remoting.RemotingDestination;
import org.springframework.flex.remoting.RemotingInclude;
import org.springframework.stereotype.Service;

import java.util.Collection;

@Service
@RemotingDestination(value="exportGridToExcelService")
public class ExportGridToExcelServiceImpl implements ExportGridToExcelService {
    private static org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger(ExportGridToExcelServiceImpl.class);

    @Autowired
    ExportToExcelReportService exportService;

    @Override
    @RemotingInclude
    public byte[] getExcelFileForReportName(String reportName, Collection<Object> gridRows) {
        byte[] fileByteArray = null;
        try {
            fileByteArray = exportService.getExcelFile(reportName, gridRows);
        }
        catch(Exception e) {
            logger.error("Error writing the excel file", e);
        }
        return fileByteArray;
    }
}
