package com.monsanto.eas.sox.jaxb;

import javax.xml.bind.annotation.*;
import java.util.List;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "")
@XmlRootElement(name = "UploadResult")
public class UploadResult {
    @XmlElement()
    private String serverResponse;
    @XmlElement()
    private String periodDescription;
    @XmlElement()
    private String state;
    @XmlElement()
    List<ActivityValidation> activity;

    public String getServerResponse() {
        return serverResponse;
    }

    public void setServerResponse(String serverResponse) {
        this.serverResponse = serverResponse;
    }

    public String getPeriodDescription() {
        return periodDescription;
    }

    public void setPeriodDescription(String periodDescription) {
        this.periodDescription = periodDescription;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public List<ActivityValidation> getActivity() {
        return activity;
    }

    public void setActivity(List<ActivityValidation> activity) {
        this.activity = activity;
    }
}

