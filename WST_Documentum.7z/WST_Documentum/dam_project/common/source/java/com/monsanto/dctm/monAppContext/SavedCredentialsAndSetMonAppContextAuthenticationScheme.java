package com.monsanto.dctm.monAppContext;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.documentum.fc.common.DfException;
import com.documentum.web.formext.config.Context;
import com.documentum.web.formext.config.IPreferenceStore;
import com.documentum.web.formext.config.PreferenceService;
import com.documentum.web.formext.session.SavedCredentialsAuthenticationScheme;

public class SavedCredentialsAndSetMonAppContextAuthenticationScheme extends
		SavedCredentialsAuthenticationScheme {

	public String authenticate(HttpServletRequest request, HttpServletResponse response, String docbase) throws DfException 
	{
		
		String strDocbase = super.authenticate(request, response, docbase);
		
		if (strDocbase != null)
		{
			MonAppContextService monAppContextService = new MonAppContextService(strDocbase);
			monAppContextService.setMonAppContext();
		}
		
		return strDocbase;
	}

}
