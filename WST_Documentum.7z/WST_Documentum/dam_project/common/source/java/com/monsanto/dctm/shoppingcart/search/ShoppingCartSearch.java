/*
 * ShoppingCartSearch.java
 *
 * Created on November 18, 2005, 2:17 PM
 *
 * To change this template, choose Tools | Options and locate the template under
 * the Source Creation and Management node. Right-click the template and choose
 * Open. You can then make changes to the template in the Source Editor.
 */

package com.monsanto.dctm.shoppingcart.search;

import com.documentum.web.common.ArgumentList;
import com.documentum.web.form.Control;
import com.documentum.web.form.Form;
import com.documentum.web.formext.config.Context;
import com.documentum.web.formext.config.IPreferenceStore;
import com.documentum.web.formext.config.PreferenceService;
import com.documentum.web.formext.control.action.ActionButton;
import com.documentum.web.formext.control.action.ActionControl;

/**
 * @author tsvedan
 */
public class ShoppingCartSearch extends com.documentum.dam.search.SearchEx {

    public void onInit(ArgumentList argumentList) {
        IPreferenceStore preferenceStore = PreferenceService.getPreferenceStore();
        preferenceStore.writeBoolean("application.display.thumbnails", Boolean.valueOf(true));
        super.onInit(argumentList);
    }

    public void onControlInitialized(Form form, Control control) {

        if (control instanceof ActionControl) {
            if ((control instanceof ActionButton) && control.getName().equals("addtoclipboard"))
                return;
            super.onControlInitialized(form, control);
        }
    }

    public void onClickRevise(Control control, ArgumentList args) {

        Context navContext = new Context(getContext());
        ArgumentList navArgs = new ArgumentList(getInitArgs());
        setComponentNavigationParams(navContext, navArgs);
        navArgs.remove("queryType");
        navArgs.remove("query");
        navArgs.replace("queryId", getSearchInfo().getQueryId());
        navArgs.replace("component", "advsearch");
        setComponentJump("advsearchcontainer", navArgs, navContext);

    }

    private void setComponentNavigationParams(Context jumpContext, ArgumentList jumpArgs) {
        String strObjectType = getSearchInfo().getQueryBuilder().getObjectType();
        jumpArgs.replace("type", strObjectType);
        jumpContext.set("type", strObjectType);
        jumpArgs.remove("r_object_id");
        jumpContext.remove("r_object_id");
        String strObjectId = getSearchInfo().getObjectId();
        if (strObjectId != null && strObjectId.length() > 0) {
            jumpArgs.replace("r_object_id", strObjectId);
            jumpContext.set("r_object_id", strObjectId);
        }
    }

}
