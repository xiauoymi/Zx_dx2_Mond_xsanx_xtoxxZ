/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.support;

import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.IDfSysObject;
import com.documentum.fc.common.DfException;
import com.documentum.web.formext.component.Component;
import com.monsanto.dctm.component.ComponentSessionManager;
import com.monsanto.dctm.component.IComponentSessionManager;

/**
 * Filename:    $RCSfile: SupportConfig.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: lakench $    	 On:	$Date:
 * 2007/08/24 21:23:23 $
 *
 * @author lakench
 * @version $Revision: 1.1 $
 */
public class SupportConfig {
  private static final String SUPPORT_INFO_OBJECT_TYPE = "mon_support_info";
  private IComponentSessionManager sessionManager;

  public SupportConfig(Component component) {
    sessionManager = new ComponentSessionManager("supportConfigObject", component.getDfSession().getSessionManager());
  }

  public IDfSysObject getSupportConfigObject(IDfSession dfSession) throws DfException {
    return (IDfSysObject) dfSession.getObjectByQualification(SUPPORT_INFO_OBJECT_TYPE);
  }

  public IDfSysObject getSupportConfigSysObject() throws DfException {
    return getSupportConfigObject(sessionManager.getSessionForComponent());
  }

  public String getOutageNotice() throws DfException {
    return getSupportInfoValue("outage_notice");
  }

  public String getUserMessage() throws DfException {
    return getSupportInfoValue("user_message");
  }

  public String getOutageNoticeUrl() throws DfException {
    return getSupportInfoValue("outage_notice_url");
  }

  public String getUserMessageUrl() throws DfException {
    return getSupportInfoValue("user_message_url");
  }

  private String getSupportInfoValue(String attribute) throws DfException {
    IDfSession session = null;
    String value = null;
    try {
      session = sessionManager.getSessionForComponent();
      IDfSysObject supportObject = getSupportConfigObject(session);
      value = supportObject.getString(attribute);
    } finally {
      if (session != null) {
        sessionManager.release(session);
      }
    }
    return value;
  }

}