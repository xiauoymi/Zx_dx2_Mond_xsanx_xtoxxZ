/*
 * ExportClipboard.java
 *
 * Created on December 5, 2005, 10:18 AM
 *
 * To change this template, choose Tools | Options and locate the template under
 * the Source Creation and Management node. Right-click the template and choose
 * Open. You can then make changes to the template in the Source Editor.
 */

package com.monsanto.dctm.shoppingcart.clipboard;

import com.documentum.fc.client.DfQuery;
import com.documentum.fc.client.IDfCollection;
import com.documentum.fc.client.IDfQuery;
import com.documentum.fc.common.DfException;
import com.documentum.web.common.ArgumentList;
import com.documentum.web.form.Control;
import com.documentum.web.formext.action.ActionService;
import com.documentum.web.formext.action.CallbackDoneListener;
import com.documentum.web.formext.clipboard.IClipboard;
import com.documentum.web.formext.component.ComboContainer;
import com.documentum.web.formext.component.Component;

import java.util.Map;

/**
 * @author tsvedan
 */
public class ExportClipboard extends ComboContainer {

    /**
     * Creates a new instance of ExportClipboard
     */
    public ExportClipboard() {
        objIds = null;
        renditions = null;
        selections = null;
    }

    public void onInit(ArgumentList args) {
        super.onInit(args);
        String [] compArgs = args.getValues("componentArgs");
        objIds = new String [compArgs.length];
        renditions = new String [compArgs.length];
        selections = new String [compArgs.length];
        for (int i = 0; i < compArgs.length; i++) {
            ArgumentList temp = ArgumentList.decode(compArgs[i]);
            objIds[i] = temp.get("objectId");
            selections[i] = "-1";
        }
    }

    public void onOk(Control control, ArgumentList args) {
        String contentType = null;
        contentType = args.get("contentType");
        try {
            for (; index < objIds.length; index++) {
                if (isFormatValid(objIds[index], contentType))
                    renditions[index] = contentType;
                else {
                    super.setCurrentComponent(index);
                    ArgumentList arglist = new ArgumentList();
                    arglist.add("contentType", contentType);
                    setClientEvent("showInvalidFormatPrompt", arglist);
                    return;
                }
            }
        } catch (DfException dfe) {
        }
        ArgumentList list = new ArgumentList();
        list.add("objectId", objIds[0]);
        list.add("contentType", renditions[0]);
        ActionService.execute("export", list, getContext(), this, new CallbackDoneListener(this, "onComplete"));
        for (int i = 0; i < objIds.length; i++) {
            if (i > 0) {
                list.replace("objectId", objIds[i]);
                list.replace("contentType", renditions[i]);
                ActionService.execute("export", list, getContext(), this, null);
            }
        }
        index = getCurrentComponent();
    }

    public void onComplete(String strAction, boolean bSuccess, Map map) {
        if (bSuccess) {
            IClipboard clipboard = getClipboard();
            clipboard.removeAll();
            setComponentReturn();
        }
    }

    public boolean onPrevPage() {
        index--;
        boolean result = super.onPrevPage();
        Component component = getContainedComponent();
        ArgumentList arglist = new ArgumentList();
        arglist.add("selection", selections[index]);
        setClientEvent("showSelectedCheckbox", arglist);
        return result;
    }

    public void onClickNext(Control ctrl, ArgumentList args) {
        renditions[index] = args.get("contentType");
        selections[index] = args.get("selectIndex");
        index++;
        ArgumentList arglist = new ArgumentList();
        arglist.add("selection", selections[index]);
        setClientEvent("showSelectedCheckbox", arglist);
        onNext(ctrl, args);
    }

    protected boolean isFormatValid(String objId, String format) throws DfException {
        boolean valid = false;
        StringBuffer strQuery = new StringBuffer();
        int i = 1;
        strQuery.append("select full_format from dmr_content where any parent_id='").append(
                objId).append("'");
        IDfCollection coll = null;

        IDfQuery query = new DfQuery();
        query.setDQL(strQuery.toString());
        try {
            coll = query.execute(getDfSession(), IDfQuery.DF_READ_QUERY);
            if (coll != null) {
                while (coll.next()) {
                    if (coll.getString("full_format").equals(format)) {
                        valid = true;
                        selections[index] = Integer.toString(i);
                        break;
                    }
                    i++;
                }
                coll.close();
            }
        } catch (DfException dfe) {
            System.out.println("Error occured during format validation!!!");
            System.out.println(dfe.getMessage());
        }
        return valid;
    }

    private String [] objIds;
    private String [] renditions;
    private String [] selections;
    private int index = 0;

}
