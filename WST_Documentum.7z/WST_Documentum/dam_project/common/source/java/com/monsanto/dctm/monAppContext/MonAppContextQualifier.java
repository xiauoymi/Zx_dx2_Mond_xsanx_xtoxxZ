/*
 * Created on Sep 3, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.dctm.monAppContext;

import com.documentum.web.formext.config.IQualifier;
import com.documentum.web.formext.config.QualifierContext;

/**
 * @author LAKENCH
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class MonAppContextQualifier implements IQualifier 
{

	/* (non-Javadoc)
	 * @see com.documentum.web.formext.config.IQualifier#getContextNames()
	 */
	public String[] getContextNames() 
	{
		return (new String[] {"mon_app_context"});
	}

	/* (non-Javadoc)
	 * @see com.documentum.web.formext.config.IQualifier#getScopeName()
	 */
	public String getScopeName() 
	{
		return "mon_app_context";
	}

	/* (non-Javadoc)
	 * @see com.documentum.web.formext.config.IQualifier#getScopeValue(com.documentum.web.formext.config.QualifierContext)
	 */
	public String getScopeValue(QualifierContext context) 
	{
		return context.get("mon_app_context");
	}

	/* (non-Javadoc)
	 * @see com.documentum.web.formext.config.IQualifier#getParentScopeValue(java.lang.String)
	 */
	public String getParentScopeValue(String arg0) 
	{
		return null;
	}

	/* (non-Javadoc)
	 * @see com.documentum.web.formext.config.IQualifier#getAliasScopeValues(java.lang.String)
	 */
	public String[] getAliasScopeValues(String arg0) 
	{
		return null;
	}
}
