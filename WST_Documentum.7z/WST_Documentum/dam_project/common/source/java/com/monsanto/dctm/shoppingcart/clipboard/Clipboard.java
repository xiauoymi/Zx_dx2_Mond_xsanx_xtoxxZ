/*
 * Clipboard.java
 *
 * Created on November 18, 2005, 8:22 PM
 *
 * To change this template, choose Tools | Options and locate the template under
 * the Source Creation and Management node. Right-click the template and choose
 * Open. You can then make changes to the template in the Source Editor.
 */

package com.monsanto.dctm.shoppingcart.clipboard;

import com.documentum.web.common.ArgumentList;
import com.documentum.web.form.control.Button;
import com.documentum.web.formext.action.ActionService;
import com.documentum.web.formext.clipboard.IClipboard;

/**
 * @author tsvedan
 */
public class Clipboard extends com.documentum.dam.environment.clipboard.Clipboard {

    /**
     * Creates a new instance of Clipboard
     */
    public Clipboard() {
    }

    public void onClickEmpty(Button button, ArgumentList args) {
        IClipboard clipboard = getClipboard();
        if (clipboard.hasItems())
            clipboard.removeAll();
        setComponentReturn();
    }

    public void onClickExport(Button button, ArgumentList args) {
        IClipboard clipboard = getClipboard();
        if (!clipboard.hasItems()) {
            ArgumentList list = new ArgumentList();
            setClientEvent("showClipboardEmptyPrompt", list);
//            setComponentReturn();
        } else {
            String items[] = clipboard.getItemIds();
            args.add("objectId", items[0]);
            for (int i = 0; i < items.length; i++) {
                if (i > 0)
                    args.replace("objectId", items[i]);
                ActionService.execute("exportclipboard", args, getContext(), this, null);
            }
        }
    }

}
