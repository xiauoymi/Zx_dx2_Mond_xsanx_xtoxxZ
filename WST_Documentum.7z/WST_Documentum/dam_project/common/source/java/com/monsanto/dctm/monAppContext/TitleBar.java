/*
 * Created on Sep 3, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.dctm.monAppContext;

import com.documentum.web.common.ArgumentList;
import com.documentum.web.form.control.databound.ArrayResultSet;
import com.documentum.web.form.control.databound.DataDropDownList;

/**
 * @author LAKENCH
 *         <p/>
 *         TODO To change the template for this generated type comment go to
 *         Window - Preferences - Java - Code Style - Code Templates
 */
public class TitleBar extends com.documentum.webtop.webcomponent.titlebar.TitleBar {

    public void onInit(ArgumentList args) {
        super.onInit(args);

        DataDropDownList dropDownList = ((DataDropDownList) getControl("mon_app_context", DataDropDownList.class));
        monAppContextService = new MonAppContextService();
        ArrayResultSet arrMonAppContexts = new ArrayResultSet(monAppContextService.getSupportedMonAppContexts(),
                                                              "mon_app_context");
        dropDownList.getDataProvider().setScrollableResultSet(arrMonAppContexts);
        ((DataDropDownList) getControl("mon_app_context", DataDropDownList.class))
                .setValue(monAppContextService.getMonAppContext());
    }

    public void onSelectMonAppContext(DataDropDownList monAppContext, ArgumentList arg) {
        monAppContextService.setMonAppContext(monAppContext.getValue());
        setClientEvent("refreshViewWindow", null);
    }

    private MonAppContextService monAppContextService;
}
