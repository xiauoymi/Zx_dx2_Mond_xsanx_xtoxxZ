package com.monsanto.dctm.monAppContext;

import java.util.ArrayList;
import java.util.Iterator;

import com.documentum.web.formext.config.ConfigService;
import com.documentum.web.formext.config.Context;
import com.documentum.web.formext.config.IConfigElement;
import com.documentum.web.formext.config.IConfigLookup;
import com.documentum.web.formext.config.PreferenceService;
import com.documentum.web.formext.session.SessionManagerHttpBinding;

public class MonAppContextService 
{
	private Context context;
	private String docbase;
	private String[] supportedMonAppContexts;
	
	public MonAppContextService() {
		super();
		setContext(Context.getSessionContext());
		setDocbase(SessionManagerHttpBinding.getCurrentDocbase());
	}

	public MonAppContextService(String docbase) {
		super();
		setContext(Context.getSessionContext());
		setDocbase(docbase);
	}
		
	public String getMonAppContext()
	{
		return ConfigService.getConfigLookup().lookupString("application.mon_app_context." + docbase, context);
    }
	
	public String getMonAppContextInternalName()
	{	
		IConfigLookup lookup = ConfigService.getConfigLookup();
		if (context != null)
		{
			IConfigElement configMonAppContexts = lookup.lookupElement("application.mon_app_contexts", context);

			if (configMonAppContexts != null)
			{
				Iterator iterMonAppContexts = configMonAppContexts.getChildElements("context");
				while (iterMonAppContexts.hasNext())
				{
					IConfigElement configMonAppContext = (IConfigElement) iterMonAppContexts.next();
					String monAppContext = configMonAppContext.getChildValue("name");
					if (monAppContext != null && monAppContext.length() > 0 && monAppContext.equals(getMonAppContext()))
					{
						return configMonAppContext.getChildValue("internal_name");
					}
				}
			}
		}
		return null;
	}
	
	public boolean isUseViewForCommentingEnabled()
	{
		IConfigLookup lookup = ConfigService.getConfigLookup();
		if (context != null)
		{
			IConfigElement configMonAppContexts = lookup.lookupElement("application.mon_app_contexts", context);

			if (configMonAppContexts != null)
			{
				Iterator iterMonAppContexts = configMonAppContexts.getChildElements("context");
				while (iterMonAppContexts.hasNext())
				{
					IConfigElement configMonAppContext = (IConfigElement) iterMonAppContexts.next();
					String monAppContext = configMonAppContext.getChildValue("name");
					if (monAppContext != null && monAppContext.length() > 0 && monAppContext.equals(getMonAppContext()))
					{
						Boolean useViewForCommentingEnabled = configMonAppContext.getChildValueAsBoolean("use_view_for_commenting_enabled");
						if (useViewForCommentingEnabled != null)
							return useViewForCommentingEnabled.booleanValue();
						else
							return true;
					}
				}
			}
		}
		return false;
	}
	
	public void setMonAppContext()
	{
		setMonAppContext(getMonAppContext());
	}
	
	public void setMonAppContext(String monAppContext)
	{
		setMonAppContext(monAppContext, true);
	}
	
	public void setMonAppContext(String monAppContext, boolean storePreference)
	{
		if (context != null)
			context.set("mon_app_context", monAppContext);
		if (storePreference)
			PreferenceService.getPreferenceStore().writeString("application.mon_app_context." + docbase, monAppContext);
	}

	public void setDocbase(String docbase) 
	{
		this.docbase = docbase;
		refreshSupportedMonAppContexts();
	}
	
	public String[] getSupportedMonAppContexts()
	{
		return supportedMonAppContexts;
	}
	
	protected void refreshSupportedMonAppContexts()
	{
		ArrayList arrMonAppContexts = new ArrayList(10);
		IConfigLookup lookup = ConfigService.getConfigLookup();
		
		if (context != null)
		{
			IConfigElement configMonAppContexts = lookup.lookupElement("application.mon_app_contexts", context);
			String monAppContext = null;
			arrMonAppContexts.add(monAppContext);  //Add blank element
			if (configMonAppContexts != null)
			{
				Iterator iterMonAppContexts = configMonAppContexts.getChildElements("context");
				while (iterMonAppContexts.hasNext())
				{
					IConfigElement configMonAppContext = (IConfigElement) iterMonAppContexts.next();
					boolean noDocbaseDefined = true;
					boolean docbaseMatches = false;
					IConfigElement configElementDocbases = configMonAppContext.getChildElement("docbases");
					if (configElementDocbases != null)
					{
						Iterator iteratorDocbases = configElementDocbases.getChildElements("docbase");
						while (iteratorDocbases.hasNext())
						{
							noDocbaseDefined = false;
							IConfigElement configDocbase = (IConfigElement) iteratorDocbases.next();
							if (configDocbase.getValue().equals(docbase))
							{
								docbaseMatches = true;
								break;
							}
						}
					}
					if (noDocbaseDefined || docbaseMatches)
					{
						String strMonAppContext = configMonAppContext.getChildElement("name").getValue();
						monAppContext = strMonAppContext;
						arrMonAppContexts.add(monAppContext);
					}
				}
			}
		}
		else
		{
			arrMonAppContexts.add(getMonAppContext());
		}
		supportedMonAppContexts = new String[arrMonAppContexts.size()];
		arrMonAppContexts.toArray(supportedMonAppContexts);
	}

	private void setContext(Context context) {
		this.context = context;
		refreshSupportedMonAppContexts();
	}

	public String getDocbase() {
		return docbase;
	}
}
