package com.monsanto.dctm.importcontent;

import com.documentum.web.common.ArgumentList;
import com.documentum.web.form.Control;
import com.documentum.web.form.control.databound.DataDropDownList;
import com.documentum.web.form.control.databound.ScrollableResultSet;
import com.documentum.web.form.control.databound.TableResultSet;
import com.documentum.web.formext.control.docbase.DocbaseObject;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.StringTokenizer;

public class ImportContent extends
        com.documentum.dam.library.contenttransfer.importcontent.ImportContent {

    public void onSyncType(Control control, ArgumentList arg) {
        boolean bFound;
        String strInitialValue;
        label0:
        {
            bFound = false;
            String strValue = arg.get("newType");
            strInitialValue = arg.get("initType");
            DocbaseObject docbaseObj = getDocbaseObjectControl(false);
            ScrollableResultSet typesResultset = createTypesResultSet();
            if (typesResultset == null || typesResultset.getResultsCount() <= 0)
                break label0;
            typesResultset.setCursor(-1);
            int nTypeNameColumn = typesResultset.findColumn("type_name") + 1;
            String strType;
            do {
                if (!typesResultset.next())
                    break label0;
                strType = (String) typesResultset.getObject(nTypeNameColumn);
            } while (!strType.equals(strValue));
            bFound = true;
            if (docbaseObj != null)
                docbaseObj.setType(strValue);
        }
        if (!bFound) {
            DataDropDownList list = getTypeListControl(false);
            if (list == null)
                list = getTypeListControl(true);
            list.setValue(strInitialValue);
        }
    }

    protected ScrollableResultSet createTypesResultSet() {

        if (isDirectory()) {
            return super.createTypesResultSet();
        } else {
            List includeTypesList = parseIncludeTypes();
            ScrollableResultSet resultSet = null;
            Iterator includeTypes = includeTypesList.iterator();
            while (includeTypes.hasNext()) {
                String includeType = (String) includeTypes.next();
                setBaseDocbaseType(includeType);
                resultSet = combineTwoTypeListResultSets(resultSet, super.createTypesResultSet());
            }

            resultSet.sort("description", 0, 1);
            return resultSet;
        }
    }

    private ScrollableResultSet combineTwoTypeListResultSets(ScrollableResultSet resultSet1, ScrollableResultSet resultSet2) {

        TableResultSet resultSet = new TableResultSet(new String[]{
                "type_name", "description", "label_text"
        });

        int numOfColumns = 3;
        copyScrollableResultSetToTableResultSet(resultSet1, resultSet, numOfColumns);
        copyScrollableResultSetToTableResultSet(resultSet2, resultSet, numOfColumns);
        return resultSet;
    }

    private void copyScrollableResultSetToTableResultSet(ScrollableResultSet source, TableResultSet target, int numOfColumns) {
        if (source != null) {
            int numOfRows = source.getResultsCount();
            for (int i = 0; i < numOfRows; i++) {
                source.next();
                String[] row = new String[3];
                for (int j = 0; j < numOfColumns; j++) {
                    row[j] = (String) source.getObject(j + 1);
                }
                target.add(row);
            }
        }
    }

    private List parseIncludeTypes() {
        ArrayList baseTypes = new ArrayList();
        String defaultType = lookupString("document-docbase-base-type");
        String typeName;
        for (StringTokenizer stringTokenizer = new StringTokenizer(defaultType, ", \t\n\r", false); stringTokenizer.hasMoreTokens(); baseTypes.add(typeName))
            typeName = stringTokenizer.nextToken();

        return baseTypes;
    }

}
