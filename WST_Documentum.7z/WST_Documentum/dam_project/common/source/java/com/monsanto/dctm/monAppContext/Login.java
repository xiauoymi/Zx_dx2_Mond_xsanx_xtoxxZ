/*
 * Created on Sep 2, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.dctm.monAppContext;

import com.documentum.web.common.ArgumentList;
import com.documentum.web.form.control.DropDownList;
import com.documentum.web.form.control.databound.ArrayResultSet;
import com.documentum.web.form.control.databound.DataDropDownList;

/**
 * @author LAKENCH
 *         <p/>
 *         TODO To change the template for this generated type comment go to
 *         Window - Preferences - Java - Code Style - Code Templates
 */
public class Login extends com.documentum.dam.formext.session.Login {

    public void onInit(ArgumentList args) {
        super.onInit(args);
        String m_strCurrentlySelectedDocbase = ((DataDropDownList) getControl("docbase", DataDropDownList.class)).getValue();
        DataDropDownList dropDownList = ((DataDropDownList) getControl(CONTROL_MON_APP_CONTEXT, DataDropDownList.class));
        monAppContextService = new MonAppContextService(m_strCurrentlySelectedDocbase);
        ArrayResultSet arrMonAppContexts = new ArrayResultSet(monAppContextService.getSupportedMonAppContexts(), "mon_app_context");
        dropDownList.getDataProvider().setScrollableResultSet(arrMonAppContexts);
        ((DataDropDownList) getControl(CONTROL_MON_APP_CONTEXT, DataDropDownList.class)).setValue(monAppContextService.getMonAppContext());
    }

    public void onSelectDocbaseFromDropDown(DropDownList docbase, ArgumentList arg) {
        super.onSelectDocbaseFromDropDown(docbase, arg);
        monAppContextService.setDocbase(docbase.getValue());
        DataDropDownList dropDownList = (DataDropDownList) getControl(CONTROL_MON_APP_CONTEXT, DataDropDownList.class);
        dropDownList.getDataProvider().setScrollableResultSet(new ArrayResultSet(monAppContextService.getSupportedMonAppContexts(), "mon_app_context"));
        ((DataDropDownList) getControl(CONTROL_MON_APP_CONTEXT, DataDropDownList.class)).setValue(monAppContextService.getMonAppContext());
    }

    protected void handleSuccess() {
        String strMonAppContext = ((DataDropDownList) getControl(CONTROL_MON_APP_CONTEXT, DataDropDownList.class)).getValue();
        monAppContextService.setMonAppContext(strMonAppContext);

        super.handleSuccess();
    }

    public static final String CONTROL_MON_APP_CONTEXT = "mon_app_context";
    private MonAppContextService monAppContextService;
}
