/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.autoLogin;

import com.documentum.fc.client.IDfDocbaseMap;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfLogger;
import com.documentum.fc.common.DfLoginInfo;
import com.documentum.fc.common.IDfLoginInfo;
import com.documentum.web.formext.session.SessionManagerHttpBinding;

import java.io.IOException;
import java.util.*;

/**
 * Filename:    $RCSfile: ComponentCredentials.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: lakench $
 * On:	$Date: 2007-08-31 13:59:13 $
 *
 * @author lakench
 * @version $Revision: 1.1 $
 */
public class ComponentCredentials {
  private static String RES_BUNDLE_NAME = "AutoLoginAuthentication.properties";

  private List credentials = null;

  public ComponentCredentials(String componentId) throws DfException, IOException {
    this(componentId,
        new PropertyResourceBundle(AutoLoginAuthenticationScheme.class.getResourceAsStream(RES_BUNDLE_NAME)),
        SessionManagerHttpBinding.getDocbrokerClient().getDocbaseMap());
  }

  public ComponentCredentials(String componentId, ResourceBundle resBundle, IDfDocbaseMap docbaseMap) throws
      DfException {
    credentials = getCredentialsForComponent(componentId, resBundle, docbaseMap);
  }

  public String getDocbase() {
    if (credentials != null)
      return (String) credentials.get(0);
    else
      return null;
  }

  public String getUser() {
    if (credentials != null)
      return (String) credentials.get(1);
    else
      return null;
  }

  public String getPassword() {
    if (credentials != null)
      return (String) credentials.get(2);
    else
      return null;
  }

  public String getDomain() {
    if (credentials != null)
      return (String) credentials.get(3);
    else
      return null;
  }

  public IDfLoginInfo getLoginInfo() {
    IDfLoginInfo loginInfo = null;
    if (getDocbase() != null) {
      loginInfo = new DfLoginInfo();
      loginInfo.setUser(getUser());
      loginInfo.setPassword(getPassword());
      loginInfo.setDomain(getDomain());
    }
    return loginInfo;
  }

  private List getCredentialsForComponent(String componentId, ResourceBundle resBundle, IDfDocbaseMap docbaseMap) throws
      DfException {
    List creds = null;
    if (resBundle != null) {
      Enumeration components = resBundle.getKeys();

      while (components.hasMoreElements()) {
        String componentNameKey = (String) components.nextElement();
        String componentName = componentNameKey.split("\\$")[0];
        DfLogger.debug("AutoLoginAuthenticationScheme", "Got component: " + componentName, null, null);
        if (componentName.equals(componentId)) {
          String value = resBundle.getString(componentNameKey);

          creds = parseCredentials(value);
          if (creds.size() == 0) break;
          if (docbaseAvailable((String) creds.get(0), docbaseMap)) break;
          else creds = null;
        }
      }
    }
    return creds;
  }

  private boolean docbaseAvailable(String docbase, IDfDocbaseMap docbaseMap) throws DfException {
    int docbaseCount = docbaseMap.getDocbaseCount();
    for (int i = 0; i < docbaseCount; i++) {
      if (docbaseMap.getDocbaseName(i).equals(docbase)) return true;
    }
    return false;
  }

  private static List parseCredentials(String creds) {
    ArrayList lstCreds = new ArrayList(4);
    StringTokenizer tokCreds = new StringTokenizer(creds, ",");
    while (lstCreds.size() != 4) {
      String cred = null;
      if (tokCreds.hasMoreTokens()) cred = tokCreds.nextToken();
      lstCreds.add(cred);
    }
    return lstCreds;
  }
}