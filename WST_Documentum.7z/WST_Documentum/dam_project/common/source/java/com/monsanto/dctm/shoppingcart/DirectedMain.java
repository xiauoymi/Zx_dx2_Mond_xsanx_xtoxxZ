/*
 Copyright:  Copyright � 2006 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.shoppingcart;

import com.documentum.web.common.ArgumentList;
import com.documentum.webtop.app.AppSessionContext;

/**
 * Filename:    $RCSfile: DirectedMain.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: lakench $    	 On:	$Date: 2006-10-05 21:04:49 $
 *
 * @author lakench
 * @version $Revision: 1.4 $
 */
public class DirectedMain extends com.monsanto.dctm.directed.DirectedMain {
    public void onInit(ArgumentList args) {
        args.replace("entryPage", "classic");
        super.onInit(args);
    }
}