var ROW_HIGHLIGHT_COLOUR_IE = "#b6c7e6";
var ROW_HIGHLIGHT_COLOUR_NS = "rgb(182, 199, 230)";
var ROW_HIGHLIGHT_COLOUR_NS_OLD = "rgb(182,199,230)";
var DYNAMIC_GENERIC = 0;
var DYNAMIC_SINGLESELECT = 1;
var DYNAMIC_MULTISELECT = 2;
var DYNAMIC_GENERICNOSELECT = 3;
var isNav = (navigator.appName == "Netscape");
var isMac = (navigator.platform.toLowerCase().indexOf("mac")!=-1)
var isMacIE = isMac&&!isNav;
function isGeneric(dynamic)
{
return ( (dynamic == DYNAMIC_GENERIC) || (dynamic == DYNAMIC_GENERICNOSELECT) );
}
function init(name, value)
{
if (typeof(eval(name)) == "undefined")
{
eval(name + "=" + value);
}
}
init("getTopLevelWnd().g_actionControls", "[]");
init("getTopLevelWnd().pmLookup", "[]");
function ActionControl(strControlId,strActionId,source,bShowIfDisabled,bShowIfInvalid,eDynamic,bIsMenu)
{
this.m_strControlId = strControlId;
this.m_strActionId = strActionId;
this.m_bShowIfDisabled = bShowIfDisabled;
this.m_bShowIfInvalid = bShowIfInvalid;
this.m_eDynamic = eDynamic;
this.m_source = source;
this.m_actionState = -1;
this.m_bIsMenu = bIsMenu;
}
function showControlEnabled(control)
{
if ( control.m_bIsMenu == false )
{
if (isDispatchableWindow(control.m_source))
{
setControlVisibility(control, true, false);
}
}
else
{
var menuItem = getTopLevelWnd().pmLookup[control.m_strControlId];
menuItem.isEnabled = true;
menuItem.isVisible = true;
}
}
function showControlDisabled(control)
{
if ( control.m_bIsMenu == false )
{
if ( isDispatchableWindow(control.m_source) )
{
setControlVisibility(control, false, true);
}
}
else
{
var menuItem = getTopLevelWnd().pmLookup[control.m_strControlId];
menuItem.isEnabled = false;
menuItem.isVisible = true;
}
}
function hideControl(control)
{
if ( control.m_bIsMenu == false )
{
if ( isDispatchableWindow(control.m_source) )
{
setControlVisibility(control, false, false);
}
}
else
{
var menuItem = getTopLevelWnd().pmLookup[control.m_strControlId];
menuItem.isVisible = false;
}
}
function setControlVisibility(control, showEnabled, showDisabled)
{
var span1 = control.m_source.document.getElementById(control.m_strControlId + "_1");
var span2 = control.m_source.document.getElementById(control.m_strControlId + "_2");
if (span1 != null && span2 != null)
{
if (showEnabled == true)
{
span1.style.display = 'block';
}
else
{
span1.style.display = 'none';
}
if (showDisabled == true)
{
span2.style.display = 'block';
}
else
{
span2.style.display = 'none';
}
}
}
function updateControl(control, actionState)
{
if (control.m_actionState != actionState)
{
control.m_actionState = actionState;
if (actionState == 1)
{
showControlEnabled(control);
}
else if (actionState == 0)
{
if (control.m_bShowIfDisabled)
{
showControlDisabled(control);
}
else
{
hideControl(control);
}
}
else if (actionState == 2)
{
if (control.m_bShowIfInvalid)
{
showControlDisabled(control);
}
else
{
hideControl(control);
}
}
}
}
function registerActionControl(strControlId,strActionId,source,bShowIfDisabled,bShowIfInvalid,eDynamic,bIsMenu)
{
var actionControl = new ActionControl(strControlId,strActionId,source,bShowIfDisabled,bShowIfInvalid,eDynamic,bIsMenu);
getTopLevelWnd().g_actionControls[ getTopLevelWnd().g_actionControls.length ] = actionControl;
}
function unregisterActionControls()
{
if(isMacIE && typeof getTopLevelWnd().g_actionControls =="undefined")
{
//don't bother to reset it
}
else
{
getTopLevelWnd().g_actionControls = [];
}
}
function getMultiselectSelection()
{
var strSelection = "";
while (true)
{
var id = "actionmultiselectcheckbox_" + strSelection.length;
var checkbox = window.document.getElementById(id);
if (checkbox == null)
{
break;
}
if (checkbox.checked)
{
strSelection = strSelection + "1";
}
else
{
strSelection = strSelection + "0";
}
}
return strSelection;
}
function updateCheckboxRowHighlightColour(checkbox)
{
var row = checkbox.parentNode;
while (row != null && row.tagName != "TR")
{
row = row.parentNode;
}
if (row != null)
{
if (checkbox.checked)
{
var rowHighlightColor = ROW_HIGHLIGHT_COLOUR_IE;
if (g_isIE == false)
{
rowHighlightColor = ROW_HIGHLIGHT_COLOUR_NS;
}
if ((row.style.backgroundColor != rowHighlightColor) && (row.style.backgroundColor != ROW_HIGHLIGHT_COLOUR_NS_OLD))
{
row.oldColour = row.style.backgroundColor;
row.style.backgroundColor = rowHighlightColor;
}
}
else
{
if (typeof(row.oldColour) != "undefined" && row.style.backgroundColor != row.oldColour)
{
row.style.backgroundColor = row.oldColour;
}
}
}
}
function onActionMultiselectCheckboxClick(checkbox)
{
if (checkbox.checked == true)
{
for (var index = 0; true; index++)
{
var id = "actionmultiselectcheckbox_" + index;
var cb = window.document.getElementById(id);
if (cb == null)
{
break;
}
if (cb.id == checkbox.id)
{
continue;
}
if (cb.checked == true)
{
cb.checked = false;
onActionMultiselectCheckboxClick(cb);
}
}
}
updateCheckboxRowHighlightColour(checkbox);
updateDynamicControls();
}
function onActionMultiselectCheckAllClick()
{
var selectAll = window.document.getElementById("actionmultiselectcheckall");
selectAll.checked = false;
alert("This operation is not allowed!");
}
function _updateDynamicControls()
{
var selection = [];
var nSelected = 0;
while (true)
{
var id = "actionmultiselectcheckbox_" + selection.length;
var checkbox = window.document.getElementById(id);
if (checkbox == null)
{
break;
}
if (checkbox.checked)
{
nSelected++;
}
selection[selection.length] = checkbox.checked;
updateCheckboxRowHighlightColour(checkbox);
}
var selectAll = window.document.getElementById("actionmultiselectcheckall");
if (selectAll != null)
{
selectAll.checked = (selection.length == nSelected);
}
for ( var iControl = 0; iControl < getTopLevelWnd().g_actionControls.length; iControl++ )
{
var control = getTopLevelWnd().g_actionControls[ iControl ];
var controlState = null;
if (isGeneric(control.m_eDynamic) == true)
{
controlState = getGenericActionState(control.m_strActionId);
}
else
{
controlState = getMultiselectActionState(control.m_strActionId, selection);
}
if ((nSelected > 0) && (controlState == 1) && (control.m_eDynamic == DYNAMIC_GENERICNOSELECT))
{
controlState = 0;
}
if ((nSelected > 1) && (controlState == 1) && (control.m_eDynamic == DYNAMIC_SINGLESELECT))
{
controlState = 0;
}
updateControl(control, controlState);
}
}
function getGenericActionState(strActionId)
{
for ( var iAction = 0; iAction < genericActionIdTbl.length; iAction++ )
{
if ( strActionId == genericActionIdTbl[ iAction ] )
{
return genericActionExecuteTbl[ iAction ];
}
}
return 0;
}
function getMultiselectActionState(strActionId, selection)
{
var iexecutable = 0;
for ( var iAction = 0; iAction < multiselectActionIdTbl.length; iAction++ )
{
if ( strActionId == multiselectActionIdTbl[ iAction ] )
{
var allItemsAreInvalid = true;
var itemIsInvalid = false;
for (var iItem = 0; iItem < multiselectActionExecuteTbl[ iAction ].length; iItem++ )
{
if (selection[ iItem ])
{
if (multiselectActionExecuteTbl[ iAction ][ iItem ] == 2)
{
itemIsInvalid = true;
}
}
if (multiselectActionExecuteTbl[ iAction ][ iItem ] != 2)
{
allItemsAreInvalid = false;
}
}
if (itemIsInvalid == true)
{
if (allItemsAreInvalid == true)
{
return 2;
}
else
{
return 0;   // treat the invalid item as "disabled"
}
}
if (allItemsAreInvalid)
return 2;
for (var iItem = 0; iItem < multiselectActionExecuteTbl[ iAction ].length; iItem++ )
{
if (selection[ iItem ])
{
if (multiselectActionExecuteTbl[ iAction ][ iItem ] == 1)
{
iexecutable = 1;
}
else
{
return 0;
}
}
}
break;
}
}
return iexecutable;
}
function fireDynamicActionEvent(strControlId)
{
var multiselectWnd = findMultiselectWindow();
if (multiselectWnd != null)
{
var actionControl = null;
for ( var iControl = 0; iControl < getTopLevelWnd().g_actionControls.length; iControl++ )
{
var control = getTopLevelWnd().g_actionControls[ iControl ];
if ( control.m_strControlId == strControlId )
{
actionControl = control;
break;
}
}
var strActionId = actionControl.m_strActionId;
var strFunction = null;
if (isGeneric(actionControl.m_eDynamic) == true)
{
strFunction = "postGenericActionEvent";
}
else
{
strFunction = "postMultiselectActionEvent";
}
multiselectWnd.eval(strFunction + "('" + strActionId + "')");
}
}
function findMultiselectFrame(containerFrame)
{
var framePath = null;
for (var iChildFrame = 0; iChildFrame < containerFrame.frames.length; iChildFrame++)
{
if (( containerFrame.frames[iChildFrame].postMultiselectActionEvent != null ) &&
( typeof containerFrame.frames[iChildFrame].postMultiselectActionEvent != "undefined" ))
{
framePath = "frames[" + iChildFrame + "]";
break;
}
}
if (framePath == null)
{
for (var iChildFrame = 0; iChildFrame < containerFrame.frames.length; iChildFrame++)
{
var childFramePath = findMultiselectFrame(containerFrame.frames[iChildFrame]);
if (childFramePath != null)
{
framePath = "frames[" + iChildFrame + "]." + childFramePath;
break;
}
}
}
return framePath;
}
function findMultiselectWindow()
{
var wndFound = null;
var multiselectFrame = findMultiselectFrame(getTopLevelWnd());
if (multiselectFrame != null)
{
wndFound = getTopLevelWnd().eval(multiselectFrame);
}
else if (multiselectFrame == null && typeof(window.postMultiselectActionEvent) != "undefined" && window.postMultiselectActionEvent != null)
{
wndFound = window;
}
return wndFound;
}
function setOnActionMultiselectWindowUnloadHandler()
{
if (typeof(s_fWindowUnloadHandlerSet) == 'undefined')
{
s_fWindowUnloadHandlerSet = true;
s_fnWindowUnload = window.onunload;
window.onunload = onActionMultiselectWindowUnload;
}
}
function onActionMultiselectWindowUnload()
{
if(!isMacIE)
{
for ( var iControl = 0; iControl < getTopLevelWnd().g_actionControls.length; iControl++ )
{
var control = getTopLevelWnd().g_actionControls[ iControl ];
updateControl(control, 2);
}
if (typeof(s_fnWindowUnload) != "undefined" && s_fnWindowUnload != null)
{
eval(s_fnWindowUnload + "();");
}
}
}
