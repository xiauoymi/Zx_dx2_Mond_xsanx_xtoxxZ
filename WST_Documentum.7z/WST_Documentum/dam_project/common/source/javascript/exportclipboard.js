function onNext() {
	var sel = getMultiselectSelection(); // this is from dynamicAction.js
	var numBoxes = sel.length-1;
	var increment = false;
	var selection = "";
	if (getIsValid(sel)){
		var page = getPageIndex();
		if(document.getElementById("cbrenditions_" + page + "_contentType_" + numBoxes)){
			// alert("Number of checkboxes = " + numBoxes + " of " + sel.length);
			var index = sel.indexOf("1");
		} else{
			var index = sel.indexOf("1") - 1;
			if (index < 1){
				index=0;
			}
			increment = true;
		}
		// window.confirm(index+1);
		// it is body_objectId_ because it is included in the body of the container
		// and objectId is the name of the dmf:hidden field in the component page
		selection = document.getElementById("cbrenditions_" + page + "_contentType_" + index).value;
		if (increment){
			index = index+1;
		}
		// alert("Your selection is:  " + selection );
		postServerEvent(null, null, null, "onClickNext", "contentType", selection, "selectIndex", index);
	}
}
function onOk() {
	var sel = getMultiselectSelection(); // this is from dynamicAction.js
	var numBoxes = sel.length-1;
	var increment = false;
	var selection = "";
	if (getIsValid(sel)){
		var page = getPageIndex();
		if(document.getElementById("cbrenditions_" + page + "_contentType_" + numBoxes)){
			// alert("Number of checkboxes = " + numBoxes + " of " + sel.length);
			var index = sel.indexOf("1");
		} else{
			var index = sel.indexOf("1") - 1;
			if (index < 1){
				index=0;
			}
			increment = true;
		}
		// window.confirm(index+1);
		// it is body_objectId_ because it is included in the body of the container
		// and objectId is the name of the dmf:hidden field in the component page
		// selection = document.getElementById("body_objectId_" + index);
		selection = document.getElementById("cbrenditions_" + page + "_contentType_" + index).value;
		if (increment){
			index = index+1;
		}
		// alert("Your selection is:  " + selection );
		postServerEvent(null, null, null, "onOk", "contentType", selection, "selectIndex", index);
	}
}
function getIsValid(select){
	var makeSelection = "Please select a rendition to export!";
	var selectOnly = "Please select ONLY ONE rendition to export!"; 
	var cnt = 0;
	for (var ind = 0; ind < select.length; ind++) {
		if (select.charAt(ind) == 1){
			cnt++;
		}
	}
	if (cnt == 0){
		alert(makeSelection);
		return false;
	}
	else if (cnt > 1){
		alert(selectOnly);
		return false;
	}
	else {
		return true;
	}
}
function getPageIndex(){
	var pageIndex = 0;
	while (true){
		if (document.getElementById("cbrenditions_" + pageIndex + "_contentType_0")){
			return pageIndex;
		}
		pageIndex++;
	}
}