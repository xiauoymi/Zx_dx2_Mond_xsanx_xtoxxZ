/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.ag_pesticide_labels.test;

import com.documentum.fc.client.MockSession;
import com.documentum.fc.client.IDfPersistentObject;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfId;
import com.monsanto.dctm.ag_pesticide_labels.MonAgPesticideLabels;
import com.monsanto.dctm.attachlifecycle.test.AttachLifecycleTestUtils;
import com.monsanto.dctm.test.MockPersistentObject;
import junit.framework.TestCase;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

/**
 * Filename:    $RCSfile: MonAgPesticideLabels_UT.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: ussing $    	 On:	$Date: 2009-03-09 20:31:07 $
 *
 * @author lakench
 * @version $Revision: 1.2 $
 */
public class MonAgPesticideLabels_UT extends TestCase {
    public void testCreate() throws Exception {
        MonAgPesticideLabels object = new MonAgPesticideLabels();

        assertNotNull(object);
    }

    public void testAttachLifecycleBlank() throws Exception {
        MockMonAgPesticideLabels mock = createMockPesticideLabelsObject();
        mock.setString("pesticide_label_status", null);
mock.save();
        mock.applyLifecycle(mock, null, null, null);
        assertEquals("lifecycleID:Ag_Pesticide_labels_LC", mock.getPolicyId().getId());
        assertEquals("", mock.lifecycleScope);
        assertEquals("Blank", mock.getCurrentStateName());
    }


    public void testAttachLifecycleInProgress() throws Exception {
        MockMonAgPesticideLabels mock = createMockPesticideLabelsObject();
        mock.setString("pesticide_label_status", "In-Progress");

        mock.applyLifecycle(mock, null, null, null);

        assertEquals("lifecycleID:Ag_Pesticide_labels_LC", mock.getPolicyId().getId());
        assertEquals("", mock.lifecycleScope);
        assertEquals("In-Progress", mock.getCurrentStateName());
    }

    public void testAttachLifecycleSubmitted() throws Exception {
        MockMonAgPesticideLabels mock = createMockPesticideLabelsObject();
        mock.setString("pesticide_label_status", "Submitted");

        mock.applyLifecycle(mock, null, null, null);

        assertEquals("lifecycleID:Ag_Pesticide_labels_LC", mock.getPolicyId().getId());
        assertEquals("", mock.lifecycleScope);
        assertEquals("Submitted", mock.getCurrentStateName());
    }

    public void testAttachLifecycleApproved() throws Exception {
        MockMonAgPesticideLabels mock = createMockPesticideLabelsObject();
        mock.setString("pesticide_label_status", "Approved");

        mock.applyLifecycle(mock, null, null, null);

        assertEquals("lifecycleID:Ag_Pesticide_labels_LC", mock.getPolicyId().getId());
        assertEquals("", mock.lifecycleScope);
        assertEquals("Approved/Approved Correct", mock.getCurrentStateName());
    }

    public void testAttachLifecycleApprovedCorrect() throws Exception {
        MockMonAgPesticideLabels mock = createMockPesticideLabelsObject();
        mock.setString("pesticide_label_status", "Approved Correct");

        mock.applyLifecycle(mock, null, null, null);

        assertEquals("lifecycleID:Ag_Pesticide_labels_LC", mock.getPolicyId().getId());
        assertEquals("", mock.lifecycleScope);
        assertEquals("Approved/Approved Correct", mock.getCurrentStateName());
    }

    public void testAttachLifecycleApprovedCorrected() throws Exception {
        MockMonAgPesticideLabels mock = createMockPesticideLabelsObject();
        mock.setString("pesticide_label_status", "Approved Corrected");

        mock.applyLifecycle(mock, null, null, null);

        assertEquals("lifecycleID:Ag_Pesticide_labels_LC", mock.getPolicyId().getId());
        assertEquals("", mock.lifecycleScope);
        assertEquals("Approved/Approved Correct", mock.getCurrentStateName());
    }

    public void testAttachLifecycleDraftEFP() throws Exception {
        MockMonAgPesticideLabels mock = createMockPesticideLabelsObject();
        mock.setString("pesticide_label_status", "Draft EFP");

        mock.applyLifecycle(mock, null, null, null);

        assertEquals("lifecycleID:Ag_Pesticide_labels_LC", mock.getPolicyId().getId());
        assertEquals("", mock.lifecycleScope);
        assertEquals("Draft EFP", mock.getCurrentStateName());
    }

    public void testAttachLifecycleEditedForPrint() throws Exception {
        MockMonAgPesticideLabels mock = createMockPesticideLabelsObject();
        mock.setString("pesticide_label_status", "Edited for Print");

        mock.applyLifecycle(mock, null, null, null);

        assertEquals("lifecycleID:Ag_Pesticide_labels_LC", mock.getPolicyId().getId());
        assertEquals("", mock.lifecycleScope);
        assertEquals("Edited for Print", mock.getCurrentStateName());
    }

    public void testAttachLifecycleDraftPrinted() throws Exception {
        MockMonAgPesticideLabels mock = createMockPesticideLabelsObject();
        mock.setString("pesticide_label_status", "Draft Printed");

        mock.applyLifecycle(mock, null, null, null);

        assertEquals("lifecycleID:Ag_Pesticide_labels_LC", mock.getPolicyId().getId());
        assertEquals("", mock.lifecycleScope);
        assertEquals("Draft Printed", mock.getCurrentStateName());
    }

    public void testAttachLifecyclePrinted() throws Exception {
        MockMonAgPesticideLabels mock = createMockPesticideLabelsObject();
        mock.setString("pesticide_label_status", "Printed");

        mock.applyLifecycle(mock, null, null, null);

        assertEquals("lifecycleID:Ag_Pesticide_labels_LC", mock.getPolicyId().getId());
        assertEquals("", mock.lifecycleScope);
        assertEquals("Printed", mock.getCurrentStateName());
    }

    public void testSynchToStatusValue() throws Exception {
        MockMonAgPesticideLabels mock = createMockPesticideLabelsObject();
        mock.setString("pesticide_label_status", null);
        mock.applyLifecycle(mock, null, null, null);
        mock.setString("pesticide_label_status", "In-Progress");

        mock.getAttachLifecycleService()
                .syncLifecycleStateWithStateName(mock, mock.getString("pesticide_label_status"));

        assertEquals("lifecycleID:Ag_Pesticide_labels_LC", mock.getPolicyId().getId());
        assertEquals("", mock.lifecycleScope);
        assertEquals("In-Progress", mock.getCurrentStateName());

        mock.setString("pesticide_label_status", "Blank");

        mock.getAttachLifecycleService()
                .syncLifecycleStateWithStateName(mock, mock.getString("pesticide_label_status"));

        assertEquals("lifecycleID:Ag_Pesticide_labels_LC", mock.getPolicyId().getId());
        assertEquals("", mock.lifecycleScope);
        assertEquals("Blank", mock.getCurrentStateName());
    }

    public void testSyncToFarStatusValue() throws Exception {
        MockMonAgPesticideLabels mock = createMockPesticideLabelsObject();
        mock.setString("pesticide_label_status", null);
        mock.applyLifecycle(mock, null, null, null);
        mock.setString("pesticide_label_status", "Draft Printed");

        mock.getAttachLifecycleService()
                .syncLifecycleStateWithStateName(mock, mock.getString("pesticide_label_status"));

        assertEquals("lifecycleID:Ag_Pesticide_labels_LC", mock.getPolicyId().getId());
        assertEquals("", mock.lifecycleScope);
        assertEquals("Draft Printed", mock.getCurrentStateName());

        mock.setString("pesticide_label_status", "In-Progress");

        mock.getAttachLifecycleService()
                .syncLifecycleStateWithStateName(mock, mock.getString("pesticide_label_status"));

        assertEquals("lifecycleID:Ag_Pesticide_labels_LC", mock.getPolicyId().getId());
        assertEquals("", mock.lifecycleScope);
        assertEquals("In-Progress", mock.getCurrentStateName());

    }

    public void testSynchToBadStatusValue() throws Exception {
        MockMonAgPesticideLabels mock = createMockPesticideLabelsObject();
        mock.setString("pesticide_label_status", null);
        mock.applyLifecycle(mock, null, null, null);
        mock.setString("pesticide_label_status", "A Status Value that is not valid");

        mock.getAttachLifecycleService()
                .syncLifecycleStateWithStateName(mock, mock.getString("pesticide_label_status"));

        assertEquals("lifecycleID:Ag_Pesticide_labels_LC", mock.getPolicyId().getId());
        assertEquals("", mock.lifecycleScope);
        assertEquals("Blank", mock.getCurrentStateName());
    }

    public void testSyncToSameStatus() throws Exception {
        MockMonAgPesticideLabels mock = createMockPesticideLabelsObject();
        mock.setString("pesticide_label_status", null);
        mock.applyLifecycle(mock, null, null, null);
        mock.setString("pesticide_label_status", "In-Progress");

        mock.getAttachLifecycleService()
                .syncLifecycleStateWithStateName(mock, mock.getString("pesticide_label_status"));

        assertEquals("lifecycleID:Ag_Pesticide_labels_LC", mock.getPolicyId().getId());
        assertEquals("", mock.lifecycleScope);
        assertEquals("In-Progress", mock.getCurrentStateName());

        mock.getAttachLifecycleService()
                .syncLifecycleStateWithStateName(mock, mock.getString("pesticide_label_status"));

        assertEquals("lifecycleID:Ag_Pesticide_labels_LC", mock.getPolicyId().getId());
        assertEquals("", mock.lifecycleScope);
        assertEquals("In-Progress", mock.getCurrentStateName());
    }

    private MockMonAgPesticideLabels createMockPesticideLabelsObject() throws DfException {
      Map stateNameLookup = new HashMap();
        stateNameLookup.put("Approved", "Approved/Approved Correct");
        stateNameLookup.put("Approved Correct", "Approved/Approved Correct");
        stateNameLookup.put("Approved Corrected", "Approved/Approved Correct");
        MockMonAgPesticideLabels mock = new MockMonAgPesticideLabels(stateNameLookup);
      mock.setId("policy_id", new DfId("0000000000000000"));
        MockSession mockSession = AttachLifecycleTestUtils.createMockSessionWithMockPesticideLabelsLifecycle();
      MockPersistentObject mockLifecycleObject = new MockPersistentObject();
        mockLifecycleObject.setString("object_name", "Ag_Pesticide_labels_LC");
        ArrayList stateNames = new ArrayList();
        stateNames.add("Blank");
        stateNames.add("In-Progress");
        stateNames.add("Submitted");
        stateNames.add("Approved/Approved Correct");
        stateNames.add("Draft EFP");
        stateNames.add("Edited for Print");
        stateNames.add("Draft Printed");
        stateNames.add("Printed");
        mockLifecycleObject.setRepeatingStrings("state_name", stateNames);
        mockLifecycleObject.setString("r_object_id", "lifecycleID:Ag_Pesticide_labels_LC");
        mockSession.addObject((IDfPersistentObject) mockLifecycleObject, "lifecycleID:Ag_Pesticide_labels_LC");
        mockSession.addObject((IDfPersistentObject) mockLifecycleObject, "dm_policy where object_name='Ag_Pesticide_labels_LC'");
        mock.setSession(mockSession);
        return mock;
    }


}