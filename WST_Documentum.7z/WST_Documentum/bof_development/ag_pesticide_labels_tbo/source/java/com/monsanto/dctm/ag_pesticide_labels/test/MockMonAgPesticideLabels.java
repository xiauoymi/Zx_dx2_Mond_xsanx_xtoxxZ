/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.ag_pesticide_labels.test;

import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.IDfSysObject;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.IDfId;
import com.monsanto.dctm.ag_pesticide_labels.MonAgPesticideLabels;
import com.monsanto.dctm.attachlifecycle.IMonAttachLifecycleService;
import com.monsanto.dctm.mon_docs.test.MockMonMonDocs;

import java.util.Map;

/**
 * Filename:    $RCSfile: MockMonAgPesticideLabels.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ussing $
 * On:	$Date: 2009-03-09 20:31:18 $
 *
 * @author lakench
 * @version $Revision: 1.3 $
 */
public class MockMonAgPesticideLabels extends MonAgPesticideLabels {
  private MockMonMonDocs mock;
  public String lifecycleScope;
  private Map stateNameLookup;

  public void save() throws DfException {
    mock.save();
  }

  public MockMonAgPesticideLabels(Map stateNameLookup) {
    this(new MockMonMonDocs(), stateNameLookup);
  }

  public MockMonAgPesticideLabels(MockMonMonDocs mockMonMonDocs, Map stateNameLookup) {
    mock = mockMonMonDocs;
    this.stateNameLookup = stateNameLookup;
  }

  /**
   * @noinspection RefusedBequest
   */
  public IMonAttachLifecycleService getAttachLifecycleService() throws DfException {
    return mock.getAttachLifecycleService();
  }

  public void applyLifecycle(IDfSysObject sourceObject, String lifecycleName, String stateName, String scope) throws
      DfException {
  mock.applyLifecycle(this, null, getStateNameFromStatus(getString("pesticide_label_status")), null);
  }

  public String getTypeName() throws DfException {
    return "ag_pesticide_labels";
  }

  /**
   * @noinspection RefusedBequest
   */
  public String getString(String attrName) throws DfException {
    return mock.getString(attrName);
  }

  /**
   * @noinspection RefusedBequest
   */
  public void setString(String attrName, String value) throws DfException {
    mock.setString(attrName, value);
  }

  /**
   * @noinspection RefusedBequest
   */
  public void attachPolicy(IDfId iDfId, String stateName, String scope) throws DfException {
    mock.attachPolicy(iDfId, stateName, scope);
    lifecycleScope = scope;
  }

  /**
   * @noinspection RefusedBequest
   */
  public void promote(String state, boolean override, boolean fTestOnly) throws DfException {
    super.promote(state, override, fTestOnly);
  }

  /**
   * @noinspection RefusedBequest
   */
  public void demote(String attrName, boolean b) throws DfException {
    super.demote(attrName, b);
  }

  /**
   * @noinspection RefusedBequest
   */
  public IDfId getPolicyId() throws DfException {
    return mock.getPolicyId();
  }

  protected String getCurrentDocbase() throws DfException {
    return "test_docbase";
  }

  /**
   * @noinspection RefusedBequest
   */
  public void setSession(IDfSession session) {
    mock.setSession(session);
  }

  /**
   * @noinspection RefusedBequest
   */
  public IDfSession getSession() {
    return mock.getSession();
  }

  /**
   * @noinspection RefusedBequest
   */
  public String getNextStateName() throws DfException {
    return super.getNextStateName();
  }

  /**
   * @noinspection RefusedBequest
   */
  public String getCurrentStateName() throws DfException {
    return super.getCurrentStateName();
  }

  /**
   * @noinspection RefusedBequest
   */
  public String getPreviousStateName() throws DfException {
    return super.getPreviousStateName();
  }


  public String getStateNameFromStatus(String status) {
    String attrStatusValue = status;
    if (stateNameLookup.containsKey(attrStatusValue)) {
      attrStatusValue = (String) stateNameLookup.get(attrStatusValue);
    }
    return attrStatusValue;
  }
}