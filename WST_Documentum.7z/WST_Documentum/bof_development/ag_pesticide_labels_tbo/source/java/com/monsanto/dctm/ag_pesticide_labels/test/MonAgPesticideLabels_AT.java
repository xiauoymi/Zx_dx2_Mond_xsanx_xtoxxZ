/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.ag_pesticide_labels.test;

import com.documentum.fc.client.IDfPersistentObject;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.IDfSessionManager;
import com.documentum.fc.client.IDfSysObject;
import com.monsanto.dctm.ag_pesticide_labels.IMonAgPesticideLabels;
import com.monsanto.dctm.utils.DFCSessionUtils;
import junit.framework.TestCase;

/**
 * Filename:    $RCSfile: MonAgPesticideLabels_AT.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: ussing $    	 On:	$Date: 2009-03-09 20:31:18 $
 *
 * @author lakench
 * @version $Revision: 1.2 $
 */
public class MonAgPesticideLabels_AT extends TestCase {
  private static final String testuserid = "lakench";
  private static final String testpw = "G1ng3r";
  private static final String testdocbase = "mtctst01";

  public void testCreateMonAgPesticideLabelsDocument() throws Exception {
        IDfSessionManager sessionManager = DFCSessionUtils.createSessionManager(testdocbase, testuserid, testpw);
        IDfSession session = null;
        try {
            sessionManager.beginTransaction();
            session = sessionManager.getSession(testdocbase);
            IDfPersistentObject object = session.newObject("ag_pesticide_labels");
            assertNotNull(object);
            assertTrue(object instanceof IMonAgPesticideLabels);
        } finally {
            if (session != null) {
                sessionManager.release(session);
            }
            sessionManager.abortTransaction();
        }
    }

    public void testLifecycleIsAttachedThroughSave() throws Exception {
        IDfSessionManager sessionManager = DFCSessionUtils.createSessionManager(testdocbase, testuserid, testpw);
        IDfSession session = null;
        IMonAgPesticideLabels object = null;
        try {
            // Note: lifecycle manipulation apparently cannot occur within a transaction
            //  so we have to destroy our object at the end rather than begin and abort a transaction
            session = sessionManager.getSession(testdocbase);
            object = (IMonAgPesticideLabels) session.newObject("ag_pesticide_labels");
            ((IDfSysObject)object).save();
            assertNotNull(object);
            assertEquals("Ag_Pesticide_labels_LC", ((IDfSysObject)object).getPolicyName());
            assertEquals("Blank", ((IDfSysObject)object).getCurrentStateName());
        } finally {
            if (object != null) {
               ((IDfSysObject)object).destroy();
            }
            if (session != null) {
                sessionManager.release(session);
            }
        }
    }

    public void testLifecycleIsAttachedThroughSaveLock() throws Exception {
        IDfSessionManager sessionManager = DFCSessionUtils.createSessionManager(testdocbase,testuserid,testpw);
        IDfSession session = null;
        IDfSysObject object = null;
        try {
            // Note: lifecycle manipulation apparently cannot occur within a transaction
            //  so we have to destroy our object at the end rather than begin and abort a transaction
            session = sessionManager.getSession(testdocbase);
            object = (IDfSysObject) session.newObject("ag_pesticide_labels");
            object.saveLock();
            assertNotNull(object);
            assertEquals("Ag_Pesticide_labels_LC", object.getPolicyName());
            assertEquals("Blank", object.getCurrentStateName());
        } finally {
            if (object != null) {
                object.destroy();
            }
            if (session != null) {
                sessionManager.release(session);
            }
        }
    }

    public void testLifecycleIsAttachedThroughCheckin() throws Exception {
        IDfSessionManager sessionManager = DFCSessionUtils.createSessionManager(testdocbase, testuserid, testpw);
        IDfSession session = null;
        IDfSysObject object = null;
        IDfSysObject newObject = null;
        try {
            // Note: lifecycle manipulation apparently cannot occur within a transaction
            //  so we have to destroy our object at the end rather than begin and abort a transaction
            session = sessionManager.getSession(testdocbase);
            object = (IDfSysObject) session.newObject("ag_pesticide_labels");
            object.save();

            object.checkout();

            newObject = (IDfSysObject) session.getObject(object.checkin(false, ""));
            assertNotNull(object);
            assertEquals("Ag_Pesticide_labels_LC", newObject.getPolicyName());
            assertEquals("Blank", newObject.getCurrentStateName());
        } finally {
            if (object != null) {
                object.destroy();
            }

            if (newObject != null) {
                newObject.destroy();
            }
            if (session != null) {
                sessionManager.release(session);
            }
        }
    }

    public void testLifecycleIsAttachedToLateStateThroughSave() throws Exception {
        IDfSessionManager sessionManager = DFCSessionUtils.createSessionManager(testdocbase, testuserid, testpw);
        IDfSession session = null;
        IDfSysObject object = null;
        try {
            // Note: lifecycle manipulation apparently cannot occur within a transaction
            //  so we have to destroy our object at the end rather than begin and abort a transaction
            session = sessionManager.getSession(testdocbase);
            object = (IDfSysObject) session.newObject("ag_pesticide_labels");
            object.setString("pesticide_label_status", "Approved Corrected");
            object.save();
            assertNotNull(object);
            assertEquals("Ag_Pesticide_labels_LC", object.getPolicyName());
            assertEquals("Approved/Approved Correct", object.getCurrentStateName());
        } finally {
            if (object != null) {
                object.destroy();
            }
            if (session != null) {
                sessionManager.release(session);
            }
        }
    }

    public void testLifecycleIsPromotedOnStatusChangeThroughSave() throws Exception {
        IDfSessionManager sessionManager = DFCSessionUtils.createSessionManager(testdocbase, testuserid, testpw);
        IDfSession session = null;
        IDfSysObject object = null;
        try {
            // Note: lifecycle manipulation apparently cannot occur within a transaction
            //  so we have to destroy our object at the end rather than begin and abort a transaction
            session = sessionManager.getSession(testdocbase);
            object = (IDfSysObject) session.newObject("ag_pesticide_labels");
            object.save();
            assertNotNull(object);
            assertEquals("Ag_Pesticide_labels_LC", object.getPolicyName());
            assertEquals("Blank", object.getCurrentStateName());
            object.setString("pesticide_label_status", "In-Progress");
            object.save();
            assertEquals("In-Progress", object.getCurrentStateName());
        } finally {
            if (object != null) {
                object.destroy();
            }
            if (session != null) {
                sessionManager.release(session);
            }
        }
    }

    public void testLifecycleIsPromotedOnStatusChangeThroughSaveLock() throws Exception {
        IDfSessionManager sessionManager = DFCSessionUtils.createSessionManager(testdocbase, testuserid, testpw);
        IDfSession session = null;
        IDfSysObject object = null;
        try {
            // Note: lifecycle manipulation apparently cannot occur within a transaction
            //  so we have to destroy our object at the end rather than begin and abort a transaction
            session = sessionManager.getSession(testdocbase);
            object = (IDfSysObject) session.newObject("ag_pesticide_labels");
            object.saveLock();
            assertNotNull(object);
            assertEquals("Ag_Pesticide_labels_LC", object.getPolicyName());
            assertEquals("Blank", object.getCurrentStateName());
            object.setString("pesticide_label_status", "In-Progress");
            object.save();
            assertEquals("In-Progress", object.getCurrentStateName());
        } finally {
            if (object != null) {
                object.destroy();
            }
            if (session != null) {
                sessionManager.release(session);
            }
        }
    }

    public void testLifecycleIsPromotedOnStatusChangeThroughCheckin() throws Exception {
        IDfSessionManager sessionManager = DFCSessionUtils.createSessionManager(testdocbase, testuserid, testpw);
        IDfSession session = null;
        IDfSysObject object = null;
        IDfSysObject newObject = null;
        try {
            // Note: lifecycle manipulation apparently cannot occur within a transaction
            //  so we have to destroy our object at the end rather than begin and abort a transaction
            session = sessionManager.getSession(testdocbase);
            object = (IDfSysObject) session.newObject("ag_pesticide_labels");
            object.save();
            assertNotNull(object);
            assertEquals("Ag_Pesticide_labels_LC", object.getPolicyName());
            assertEquals("Blank", object.getCurrentStateName());
            object.checkout();
            object.setString("pesticide_label_status", "In-Progress");

            newObject = (IDfSysObject) session.getObject(object.checkin(false, ""));

            assertEquals("In-Progress", newObject.getCurrentStateName());
        } finally {
            if (object != null) {
                object.destroy();
            }
            if (session != null) {
                sessionManager.release(session);
            }
        }
    }

    public void testLifecycleIsDemotedOnStatusChangeThroughSave() throws Exception {
        IDfSessionManager sessionManager = DFCSessionUtils.createSessionManager(testdocbase, testuserid, testpw);
        IDfSession session = null;
        IDfSysObject object = null;
        try {
            // Note: lifecycle manipulation apparently cannot occur within a transaction
            //  so we have to destroy our object at the end rather than begin and abort a transaction
            session = sessionManager.getSession(testdocbase);
            object = (IDfSysObject) session.newObject("ag_pesticide_labels");
            object.setString("pesticide_label_status", "Approved Corrected");
            object.save();
            assertNotNull(object);
            assertEquals("Ag_Pesticide_labels_LC", object.getPolicyName());
            assertEquals("Approved/Approved Correct", object.getCurrentStateName());
            object.setString("pesticide_label_status", "In-Progress");
            object.save();
            assertEquals("In-Progress", object.getCurrentStateName());
        } finally {
            if (object != null) {
                object.destroy();
            }
            if (session != null) {
                sessionManager.release(session);
            }
        }
    }
}