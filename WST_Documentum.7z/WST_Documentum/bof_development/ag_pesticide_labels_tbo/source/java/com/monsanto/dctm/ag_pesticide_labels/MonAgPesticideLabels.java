package com.monsanto.dctm.ag_pesticide_labels;

import com.documentum.fc.client.IDfSysObject;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.IDfDynamicInheritance;
import com.documentum.fc.common.IDfId;
import com.monsanto.dctm.mon_docs.MonMonDocs;

import java.util.HashMap;

public class MonAgPesticideLabels extends MonMonDocs implements
    IMonAgPesticideLabels, IDfDynamicInheritance {

  private HashMap stateNameLookup;

  public MonAgPesticideLabels() {
    stateNameLookup = new HashMap();
    stateNameLookup.put("Approved", "Approved/Approved Correct");
    stateNameLookup.put("Approved Correct", "Approved/Approved Correct");
    stateNameLookup.put("Approved Corrected", "Approved/Approved Correct");
  }

  public String getVendorString() {
    return "Copyright(c) Monsanto Corp., 2005";
  }

  public String getVersion() {
    return "1.0";
  }

  public boolean isCompatible(String str) {
    return str.equals("1.0");
  }

  public boolean supportsFeature(String str) {
    String strFeatures = "";
    return strFeatures.indexOf(str) != -1;
  }

  protected void doSave(boolean b, String string, Object[] objects) throws DfException {
    System.out.println("MonAgPesticideLabels.doSave");
    super.doSave(b, string, objects);
  }

  protected IDfId doCheckin(boolean b, String attrName, String attrName1, String attrName2, String attrName3,
                            String attrName4, Object[] objects) throws
      DfException {
    IDfId newObjectId = super.doCheckin(b, attrName, attrName1, attrName2, attrName3, attrName4, objects);
    getSession().getObject(newObjectId).save();
    return newObjectId;
  }

  public String getStateNameFromStatus(String status) {
    String attrStatusValue = status;
    if (stateNameLookup.containsKey(attrStatusValue)) {
      attrStatusValue = (String) stateNameLookup.get(attrStatusValue);
    }
    return attrStatusValue;
  }

  public void applyLifecycle(IDfSysObject sourceObject, String lifecycleName, String stateName, String scope) throws
      DfException {
    System.out.println("MonAgPesticideLabels.applyLifecycle");
    super.applyLifecycle(sourceObject, lifecycleName, stateName, scope);
    getAttachLifecycleService()
        .syncLifecycleStateWithStateName(this, getStateNameFromStatus(getString("pesticide_label_status")));
  }
}
