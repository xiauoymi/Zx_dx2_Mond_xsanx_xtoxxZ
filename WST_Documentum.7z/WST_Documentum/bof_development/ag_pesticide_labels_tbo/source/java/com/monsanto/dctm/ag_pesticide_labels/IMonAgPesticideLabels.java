package com.monsanto.dctm.ag_pesticide_labels;

import com.documentum.fc.client.IDfBusinessObject;

public interface IMonAgPesticideLabels extends IDfBusinessObject {
//    public void syncLifecycleStateWithStateName(String statusAttributeName) throws DfException;

  String getStateNameFromStatus(String status);
}
