/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.southafrica.iso;

import com.documentum.com.DfClientX;
import com.documentum.com.IDfClientX;
import com.documentum.fc.client.*;
import com.documentum.fc.common.*;

/**
 * Filename:    $RCSfile: MonSouthAfricaISODoc.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: tsvedan $
 * On:	$Date: 2007-02-08 18:08:15 $
 *
 * @author tsvedan
 * @version $Revision: 1.5 $
 */
public class MonSouthAfricaISODoc extends DfSysObject
    implements IMonSouthAfricaISODoc, IDfDynamicInheritance {

  public IDfId checkinEx(
      boolean arg0,
      String arg1,
      String arg2,
      String arg3,
      String arg4,
      String arg5)
      throws DfException {
    DfLogger.debug(this, "@@@@@@@@@ CHECKINEX @@@@@@@@@", null, null);
    if (this.getPreviousApprovedVersion())
      arg1 = arg1.replaceAll("CURRENT", moveSymbolicVersionLabel());
    else
      arg1 = "," + moveSymbolicVersionLabel() + arg1;
    IDfId newId = super.checkinEx(arg0, arg1, arg2, arg3, arg4, arg5);
    IDfSession sess = null;
    IDfSysObject newObj = null;

    sess = getSession();
    newObj = (IDfSysObject) sess.getObject(newId);
    DfLogger.debug(this, "***Your name is :: " + sess.getLoginUserName(), null, null);
    if (isApprovedVersion(this) || (!isAlreadyInWorkflow(newObj) && isDraftVersion(newObj))) {
      setProcessId(WORKFLOW_NAME);
      setPerformers(newObj);
      startWorkflow(newId);
    }
    return newId;
  } //checkinEx


  public void doSave(boolean saveLock, String versionLabel, Object[] extendedArgs)
      throws DfException {
    DfLogger.debug(this, "@@@@@@@@@ doSave @@@@@@@@@", null, null);
    DfLogger.debug(this, "***Your name is :: " + getSession().getLoginUserName(), null, null);

    super.doSave(saveLock, versionLabel, extendedArgs);
    if (this.getPolicyId().isNull())
      applyLifecycle(LIFECYCLE_NAME, null, null);

    if (!isAlreadyInWorkflow(this) && isDraftVersion(this)) {
      setProcessId(WORKFLOW_NAME);
      setPerformers(this);
      startWorkflow(this.getId("r_object_id"));
    }
  } //doSave

  public void save() throws DfException {
    DfLogger.debug(this, "@@@@@@@@@ SAVE @@@@@@@@@", null, null);
    if (!isApprovedVersion(this) && this.getPreviousApprovedVersion())
      this.unmark("CURRENT");
    super.save();
    if (APPROVED_STATE_LABEL.equals(getCurrentStateName()))
      queue("dm_autorender_win31", "rendition", 0, false, null, "rendition_req_ps_pdf");
  } //save

  protected void setProcessId(String processName) throws DfException {

    IDfSession session = null;
    try {
      session = getSession();
      IDfCollection Workflows = session.getRunnableProcesses("");
      IDfId processID = null;
      while (Workflows.next()) {
        IDfTypedObject Next = Workflows.getTypedObject();
        if (Next.getString("object_name").equals(processName)) {
          processID = Next.getId("r_object_id");
          m_processId = processID;
          DfLogger.debug(this, "Workflow name: " + Next.getString("object_name"), null, null);
          DfLogger.debug(this, "Set the process id: " + processID.toString(), null, null);
          break;
        }
      }
      Workflows.close();
    } catch (DfException dfe) {
      throw dfe;
    }
  } //setProcessId

  protected void startWorkflow(IDfId documentId) throws DfException {
    IDfSession session = null;
    try {
      session = getSession();

      IDfId processId = getProcessId();
      if (processId == null) {
        DfLogger.warn(this, "No valid processes to start", null, null);
        return;
      }
      IDfWorkflowBuilder wfBuilder =
          session.newWorkflowBuilder(processId);
      wfBuilder.initWorkflow();
      wfBuilder.runWorkflow();
      IDfWorkflow workflow = wfBuilder.getWorkflow();

      setWFPerformers(workflow);

      String activityName = null;
      String packageName = null;
      String portName = null;

      if (getActivityId() == null) //choose first start activity by default
      {
        IDfList activityIds = wfBuilder.getStartActivityIds();
        setActivityId((IDfId) activityIds.get(0));
      }

      IDfActivity activity =
          (IDfActivity) session.getObject(getActivityId());
      activityName = activity.getString("object_name");

      if (getPortName() == null) //choose first input port by default
      {
        for (int cntrPort = 0; cntrPort < activity.getPortCount(); cntrPort++) {
          if (activity.getPortType(cntrPort).equals("INPUT")) {
            portName = activity.getPortName(cntrPort);
            packageName = activity.getPackageName(cntrPort);
            break;
          }
        }
      } else {
        portName = getPortName();
        for (int i = 0; i < activity.getPortCount(); i++) {
          if (activity.getPortName(i).equals(portName)) {
            packageName = activity.getPackageName(i);
            break;
          }
        }
      }

      String strObjectType = getTypeName();
      DfList list = new DfList();
      list.append(documentId);
      workflow.addPackage(
          activityName,
          portName,
          packageName,
          strObjectType,
          "",
          false,
          list);
      DfLogger.debug(this, "Started workflow with id: " + workflow.getObjectId().getId(), null, null);
      DfLogger.debug(this, "Workflow name: " + workflow.getObjectName(), null, null);
      DfLogger.debug(this, "The workflow supervisor is: " + workflow.getSupervisorName(), null, null);
      DfLogger.debug(this, "Added package with doc id: " + documentId, null, null);
    } catch (DfException dfe) {
      DfLogger.error(this, dfe.getMessage(), null, null);
      dfe.printStackTrace();
      throw dfe;
    }
  } //startWorkflow

  private void setWFPerformers(IDfWorkflow workflow) throws DfException {

    IDfList list = new DfList();
    list.append(reviewer);
    workflow.setPerformers("Review", list);

    list = new DfList();
    list.append(approver);
    workflow.setPerformers("Approve", list);

  }

  protected void setPerformers(IDfSysObject sysObj) throws DfException {

    String name = sysObj.getString("object_name");
    String process = sysObj.getString("process");

    DfLogger.debug(this, "Name: " + name, null, null);
    DfLogger.debug(this, "Process: " + process, null, null);

    StringBuffer query = new StringBuffer("select coded_value from dm_dbo.code_lookup ");
    query.append("where code_type='south_africa_iso_process' and decoded_value='");
    query.append(process).append("'");

    String procCode = execQuery(query.toString());

    reviewer = "south_africa_iso_" + procCode + "_reviewer";
    approver = "south_africa_iso_" + procCode + "_approver";

    validate();
  }

  protected void validate() throws DfException {

    IDfSession session = getSession();
    IDfGroup rev = null;
    IDfGroup app = null;

    try {
      rev = session.getGroup(reviewer);
      app = session.getGroup(approver);
      if (rev == null || rev.getUsersNamesCount() < 1) {
        String msg = "Group specified by " + reviewer + " does not exist or is empty!";
        throw new DfException(msg);
      }
      if (app == null || app.getUsersNamesCount() < 1) {
        String msg = "Group specified by " + approver + " does not exist or is empty!";
        throw new DfException(msg);
      }
    } catch (DfException e) {
      reviewer = "south_africa_iso_gen_reviewer";
      approver = "south_africa_iso_gen_approver";
      DfLogger.warn(this, e.getMessage(), null, null);
    } finally {
      DfLogger.info(this, "Reviewer group = " + reviewer, null, null);
      DfLogger.info(this, "Approver group = " + approver, null, null);
    }
  } //validate

  protected void applyLifecycle(String lifecycleName, String state, String scope)
      throws DfException {

    IDfSession session = null;
    try {
      session = getSession();
      StringBuffer bufQual = new StringBuffer(64);
      bufQual.append("dm_policy where object_name='").append(
          lifecycleName).append(
          "'");
      IDfId policyId = session.getIdByQualification(bufQual.toString());
      DfLogger.debug(this, "Got policy with id: " + policyId.getId(), null, null);
      if ((policyId == null) || (policyId.isNull())) {
        String msg = "Unable to locate the lifecycle to be applied";
        DfLogger.warn(this, msg, null, null);
        throw new IllegalArgumentException(msg);
      }
      IDfSysObject policyObj = (IDfSysObject) session.getObject(policyId);
      if (state == null || state.equals(""))
        state = policyObj.getRepeatingString("state_name", 0);

      this.attachPolicy(policyId, state, scope);
      DfLogger.debug(this, "!!!! Successfully attached policy...", null, null);
    } catch (DfException dfe) {
      DfLogger.error(this, "Error attaching the policy :: " + lifecycleName, null, null);
    }
  } //applyLifecycle

  protected boolean isAlreadyInWorkflow(IDfSysObject sysObj) throws DfException {

    IDfSysObject version = null;
    IDfId versionId = null;
    IDfCollection coll = null;
    IDfCollection wcoll = null;
    boolean inWorkflow = false;

    wcoll = sysObj.getWorkflows("", "");
    if (wcoll != null && wcoll.next()) {
      DfLogger.debug(this, "This object already participates in workflow with ID:: " + wcoll.getString("r_workflow_id"),
          null, null);
      inWorkflow = true;
    } else if ((coll = sysObj.getVersions("r_modify_date, r_object_id")) != null) {
      while (coll.next()) {
        versionId = coll.getId("r_object_id");
        version = (IDfSysObject) getSession().getObject(versionId);
        if (APPROVED_STATE_LABEL.equals(version.getCurrentStateName()))
          continue;
        wcoll = version.getWorkflows("", "");
        if (wcoll != null && wcoll.next()) {
          DfLogger.debug(this,
              "This object already participates in workflow with ID:: " + wcoll.getString("r_workflow_id"), null, null);
          inWorkflow = true;
          break;
        }
      }
    }
    if (wcoll != null)
      wcoll.close();
    if (coll != null)
      coll.close();

    return inWorkflow;
  } //isAlreadyInWorkflow

  protected boolean getPreviousApprovedVersion() throws DfException {

    IDfSysObject version = null;
    IDfId versionId = null;
    IDfCollection coll = null;
    boolean found = false;
    DfLogger.debug(this, "!!!! In getPreviousApprovedVersion....", null, null);
    if (this.getVStamp() == 0) return false;
    try {
      coll = this.getVersions("r_version_label, r_modify_date, r_object_id");
    } catch (DfException dfe) {
      DfLogger.error(this, dfe.getMessage(), null, null);
      dfe.printStackTrace();
    }
    if (coll != null) {
      while (coll.next()) {
        versionId = coll.getId("r_object_id");
        version = (IDfSysObject) getSession().getObject(versionId);
        if (isApprovedVersion(version)) {
          found = true;
          break;
        }
      }
      coll.close();
    }
    DfLogger.debug(this, ">>>> CHECKED FOR APPROVED VERSIONS .." + found, null, null);
    return found;
  } //getPreviousApprovedVersion


  protected String moveSymbolicVersionLabel() throws DfException {
    String label = null;
    for (int i = 1; i < this.getVersionLabelCount(); i++) {
      label = this.getVersionLabel(i);
      if (label.equals("Review")) {
        return label;
      }
    }
    return DRAFT_STATE_LABEL;
  } //moveSymbolicVersionLabel


  protected boolean isApprovedVersion(IDfSysObject sysObj) throws DfException {
    boolean isApproved = false;
    if (sysObj.getCurrentStateName() == null)
      return true;
    if (sysObj.getCurrentStateName().equals(APPROVED_STATE_LABEL)) {
      isApproved = true;
    }
    return isApproved;
  } //isApprovedVersion

  protected boolean isDraftVersion(IDfSysObject sysObj) throws DfException {
    String label = null;
    boolean isDraft = false;
    for (int i = 1; i < sysObj.getVersionLabelCount(); i++) {
      label = sysObj.getVersionLabel(i);
      if (label.equals(DRAFT_STATE_LABEL))
        isDraft = true;
    }
    return isDraft;
  } //isDraftVersion


  protected String execQuery(String queryString)
      throws DfException {
    IDfCollection coll = null; //Collection for the result
    IDfClientX clientx = new DfClientX();
    IDfQuery q = clientx.getQuery(); //Create query object
    String result = null;
    q.setDQL(queryString); //Give it the query
    coll = q.execute(getSession(), IDfQuery.DF_READ_QUERY);
    if (coll.next()) {
      result = coll.getString("coded_value");
      DfLogger.debug(this, "Query executed... Result is " + result, null, null);
    }
    if (coll != null)
      coll.close();
    return result;
  } //execQuery


  public void setActivityId(IDfId activityId) {
    m_activityId = activityId;
  }


  public void setPackageName(String packageName) {
    m_strPackageName = packageName;
  }


  public void setPortName(String strPort) {
    m_strPortName = strPort;
  }


  public IDfId getActivityId() {
    return m_activityId;
  }


  public String getPackageName() {
    return m_strPackageName;
  }

  public String getPortName() {
    return m_strPortName;
  }


  public IDfId getProcessId() {
    return m_processId;
  }

  public boolean supportsFeature(String arg0) {
    return false;
  } //supportsFeature


  public boolean isCompatible(String arg0) {
    if (arg0.equals(getVersion())) {
      return true;
    }
    return false;
  } //isCompatible


  public String getVersion() {
    return "1.0";
  } //getVersion


  public String getVendorString() {
    return "Copyright (c) 2007 Monsanto Corp.";
  } //getVendorString


  private String reviewer = null;
  private String approver = null;
  private IDfId m_activityId = null;
  private IDfId m_processId = null;
  private String m_strPackageName = null;
  private String m_strPortName = null;

  private static final String LIFECYCLE_NAME = "South Africa ISO DLC";
  private static final String WORKFLOW_NAME = "South Africa ISO Approval Workflow";
  private static final String DRAFT_STATE_LABEL = "Draft";
  private static final String APPROVED_STATE_LABEL = "Effective";


}