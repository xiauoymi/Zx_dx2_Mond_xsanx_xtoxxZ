/*
 * Created on Nov 3, 2003
 * Documentum Developer Program 2003
 */
package com.documentum.devprog.common.boconfig;

import com.documentum.fc.common.DfLogger;

/**
 * @author Aashish Patil (aashish.patil@documentum.com)
 *
 * 
 */
public class BOConfigFactory
{
   /**
    * Singleton instance of the registry. 
    */
   private static Cache s_reg = null;
   
   /**
    * Constructs a new instance of IBOConfig by locating the input stream
    * from the file boconfig.xml within the jar of the BO classes. 
    * 
    * @param boClass
    * @return Instance of IBOConfig or <code>null</code> if unable to locate
    *         the config file.
    */
   public static IBOConfig newBOConfig(Object bobj) throws BOConfigException
   {      
      try
      {
         if(s_reg== null)
         {
            s_reg = new Cache();
         }
         
         IBOConfig boConfig = new BOConfigService(bobj,s_reg);
         return boConfig;
      }
      catch(NullPointerException npe)
      {
         DfLogger.error(BOConfigFactory.class.getName(),"Null pointer exception from within BOConfig",null,npe);
         throw new BOConfigException("Unable to configure the BO. Null pointer exception generated. Check logs for stack trace");
      }            
   }
   
   public static IBOConfig newBOConfigForClass(Class cl) throws BOConfigException
   {
      try
            {
               if(s_reg== null)
               {
                  s_reg = new Cache();
               }
         
               IBOConfig boConfig = new BOConfigService(cl,s_reg);
               return boConfig;
            }
            catch(NullPointerException npe)
            {
               DfLogger.error(BOConfigFactory.class.getName(),"Null pointer exception from within BOConfig",null,npe);
               throw new BOConfigException("Unable to configure the BO. Null pointer exception generated. Check logs for stack trace");
            } 
      
      
   }
   
   
   

}
