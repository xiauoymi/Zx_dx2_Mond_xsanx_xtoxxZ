/*
 * Created on Oct 9, 2003
 * Documentum Developer Program 2003
 */
package com.documentum.devprog.common.boconfig;

import org.w3c.dom.*;
import javax.xml.parsers.*;

import org.apache.xpath.*;
import org.apache.xpath.objects.*;

import java.io.*;

/**
 * @author Aashish Patil (aashish.patil@documentum.com)
 *
 * 
 */
public class TestXPath
{

   public static void main(String[] args)
   {

      try
      {

         File fl = new File("C:\\devprog\\sample.xml");
         DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
         DocumentBuilder builder = factory.newDocumentBuilder();
         Document document = builder.parse(fl);

         XObject xObj =
            XPathAPI.eval(
               document,
         "//*/template[contains(text(),'Mem')]");
               //"/boconfig/CompoundTemplate/document[@name]/template[contains(text(),'Mem')]");
         String objClass = xObj.getTypeString();
         System.out.println(objClass);
         NodeList nodeList = xObj.nodelist();
         for (int j = 0; j < nodeList.getLength(); j++)
         {
            Node node = nodeList.item(j);
            System.out.println(node.getNodeName() + "=" + node.getNodeValue());
            NamedNodeMap nodeMap = node.getAttributes();

            for (int k = 0; k < nodeMap.getLength(); k++)
            {
               Node attrNode = nodeMap.item(k);
               System.out.println(
                  "---"
                     + attrNode.getNodeName()
                     + "="
                     + attrNode.getNodeValue());

            }
         }
      }
      catch (Exception ex)
      {
         ex.printStackTrace();
      }
   }
}
