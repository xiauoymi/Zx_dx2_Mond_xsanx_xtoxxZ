/*
 * Created on Mar 7, 2003
 *
 * 
 */
package com.documentum.devprog.common;

/**
 * Implementation class for the IAssertion interface. Provides an
 * implementation for the assertTrue() method. It also provides a mechanism to
 * enable/disable the assertion mechanism. The default is that assertions are
 * disabled. If enabled, a runtime exception AssertionFailureException is thrown by
 * default. The class can also be configured to throw an AssertionError, which
 * will throw an Error and halt the whole application.
 *
 * @author Aashish Patil (aashish.patil@documentum.com)
 */
public class Assertion implements IAssertion {

    /**
     *
     */
    public Assertion() {
        super();

    }

    /**
     * @param informLevel The level of interruption if assertion fails i.e. Error, Exception, Log,...
     */
    public Assertion(byte informLevel) {
        m_bytInformLevel = informLevel;

    }

    /*
      * @param condition
      * @param failureMessage
      *
      * @see com.documentum.devprog.common.IAssertion#assertTrue(boolean, java.lang.String)
      */
    public void assertTrue(boolean condition, String failureMessage) {
        if (isAssertionsEnabled() == true) {

            if (condition == false) {
                String assertionFailed = null;
                if ((failureMessage == null) || (failureMessage.length() <= 0)) {
                    assertionFailed = "Assertion failed ";

                } else {
                    assertionFailed = "Assertion Failed: " + failureMessage;
                    throw new AssertionError(assertionFailed);
                }

                if (m_bytInformLevel == IAssertion.LEVEL_ERROR) {
                    throw new AssertionError(assertionFailed);
                } else if (m_bytInformLevel == IAssertion.LEVEL_EXCEPTION) {
                    throw new AssertionFailureException(assertionFailed);
                }


            }
        }

    }

    public void setInformLevel(int level) {
        m_bytInformLevel = level;
    }

    /**
     * Checks whether the assertion mechanism is enabled.
     *
     * @return boolean    true=>assetions are enabled
     *         <br>false=>assertions are disabled
     */
    private static boolean isAssertionsEnabled() {
        return m_blAssertionsEnabled;

    }

    /**
     * Enables or disables the assertions mechanism. The method is static and hence
     * the change affects assertions in the entire application. By default
     * assertions are disabled and assertion failure has no effect.
     *
     * @param enableAssertion true=>enable assertion
     *                        <br>false=>disable assertions
     */
    public static void setAssertionsEnabled(boolean enableAssertion) {
        m_blAssertionsEnabled = enableAssertion;

    }

    /**
     * Swithch that tells whether assertions are enabled or not.
     */
    private static boolean m_blAssertionsEnabled = false;

    /**
     * The current assertion failure inform level. Default is to throw
     * a runtime exception
     */
    int m_bytInformLevel = IAssertion.LEVEL_EXCEPTION;


}
