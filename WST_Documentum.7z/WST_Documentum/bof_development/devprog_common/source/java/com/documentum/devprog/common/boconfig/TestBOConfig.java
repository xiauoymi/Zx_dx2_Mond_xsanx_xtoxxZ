/*
 * Created on Nov 5, 2003
 * Documentum Developer Program 2003
 */
package com.documentum.devprog.common.boconfig;

/**
 * @author Aashish Patil (aashish.patil@documentum.com)
 *
 * 
 */
public class TestBOConfig
{

   static void setConfigObject(IBOConfig boConfig)
   {
      String[] values = boConfig.getValues("/TocEntryAttributes/attribute");
      for (int i = 0; i < values.length; i++)
      {
         System.out.println(values[i]);
      }
   }
   
   static void testSamples(IBOConfig boConfig)
   {
      String defRend = boConfig.getValue("/defaultRendition");
      System.out.println("\ndefault rendition: " + defRend);
      
      String[] names = boConfig.getXMLAttributeValues("/namingRules/rule","name");
      System.out.println("\nPrinting the values of rule names");
      for(int i=0;i<names.length;i++)
      {
         System.out.println(names[i]);
      }
      
      String[] implClass = boConfig.getValues("/namingRules/rule");
      System.out.println("\nPrinting naming rule implementation classes");
      for(int j=0;j<implClass.length;j++)
      {
         System.out.println(implClass[j]);
      }
      
      String numIncrImpl = boConfig.getValue("/namingRules/rule[@name='simpleNumberIncrement']");
      System.out.println("Impl class for numIncr: " + numIncrImpl);
      
      String[] attrs = boConfig.getValues("/TocEntryAttributes/attribute");
      System.out.println("\nPrinting all attributes");
      for(int k=0;k<attrs.length;k++)
      {
         System.out.println(attrs[k]);
      }
      
   }

   public static void main(String[] args)
   {
      try
      {
         //Create an instance of the class whose config info needs to 
         //be read in.
         TestBOConfig tester = new TestBOConfig();
         //Create a new config object from the factory. This is 
         //to separate interface from implementation.
         IBOConfig boConf = BOConfigFactory.newBOConfig(tester);

         //Call the method and pass the config object to it.
         //setConfigObject(boConf);
         testSamples(boConf);
         
         Thread.sleep(120000);

      }
      catch (BOConfigException bce)
      {
         bce.printStackTrace();
      }
      catch(Exception ex)
      {
         ex.printStackTrace();
      }
   }
}
