/*
 * Created on Mar 7, 2003
 *
 * 
 */
package com.documentum.devprog.common;

/**
 * @author Aashish Patil (aashish.patil@documentum.com)
 *
 * 
 */
public class AssertionFailureException extends RuntimeException
{

	/**
	 * 
	 */
	public AssertionFailureException()
	{
		super();

	}
    
    

	/**
	 * @param arg0
	 */
	public AssertionFailureException(String arg0)
	{
		super(arg0);

	}

}
