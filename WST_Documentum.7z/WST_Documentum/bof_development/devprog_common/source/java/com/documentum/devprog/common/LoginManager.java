/*
 * Created on Mar 24, 2003
 *
 * Documentum Developer Program 2003
 */
package com.documentum.devprog.common;

import com.documentum.fc.client.DfClient;
import com.documentum.fc.client.IDfClient;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.IDfSessionManager;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfLoginInfo;
import com.documentum.fc.common.IDfLoginInfo;


/**
 * Single identity login manager. Does not support mulitple identities.
 * This is a convenience class to be used in the test scripts that Developer
 * Program distributes.
 *
 * @author Aashish Patil (aashish.patil@documentum.com)
 */
public class LoginManager {

    /**
     *
     */
    public LoginManager(String username, String password, String docbase) {

        m_strUsername = username;
        m_strPassword = password;
        m_strDocbase = docbase;

        init();
    }

    protected void init() {
        try {

            m_localClient = DfClient.getLocalClient();


            Assertion assertion = new Assertion();
            Assertion.setAssertionsEnabled(true);
            assertion.setInformLevel(Assertion.LEVEL_ERROR);
            assertion.assertTrue(getUsername() != null && getPassword() != null && getDocbase() != null,
                                 "Username or password or docbaseName is null");

            IDfLoginInfo loginInfo = new DfLoginInfo();
            loginInfo.setUser(getUsername());
            loginInfo.setPassword(getPassword());

            m_sessMgr = m_localClient.newSessionManager();
            m_sessMgr.setIdentity(getDocbase(), loginInfo);


        }
        catch (DfException dfe) {
            dfe.printStackTrace();
        }

    }

    public void setUsername(String username) {
        m_strUsername = username;
    }

    public String getUsername() {
        return m_strUsername;
    }

    public void setPassword(String password) {
        m_strPassword = password;

    }

    public String getPassword() {
        return m_strPassword;
    }

    /**
     * @param docbase
     */
    public void setDocbase(String docbase) {
        m_strDocbase = docbase;
    }

    /**
     * @return String
     */
    public String getDocbase() {
        return m_strDocbase;
    }


    public IDfSession getSession() {
        try {
            m_session = m_sessMgr.getSession(getDocbase());
            return m_session;
        }
        catch (DfException dfe) {
            dfe.printStackTrace();
        }
        return null;
    }

    public void releaseSession() {
        if (m_session != null) {
            m_sessMgr.release(m_session);
        }
    }

    public IDfSessionManager getSessionManager() {
        return m_sessMgr;
    }

    public IDfClient getLocalClient() {
        return m_localClient;
    }

    private String m_strUsername = null;
    private String m_strPassword = null;
    private String m_strDocbase = null;

    private IDfSessionManager m_sessMgr = null;

    private IDfSession m_session = null;

    private IDfClient m_localClient = null;
}
