/*
 * Created on Mar 7, 2003
 *
 * 
 */
package com.documentum.devprog.common;

/**
 * Interface for assertion mechanism. This is meant for a non-asserion
 * architecture of JDK 1.3.xxx and before. It is compatible with Java 1.4 too.
 * However, Java 1.4 includes a built in assertion mechanism.
 *
 * @author Aashish Patil (aashish.patil@documentum.com)
 */
public interface IAssertion {
    /**
     * Checks whether the condition is true or false. If false, the assertion has
     * failed and the method throws a runtime AssertionError.
     *
     * @param condition      The condition that is checked to be true.
     *                       <br> If true method returns. If false, asertion has failed
     * @param failureMessage Detailed message that describing the failure of the condition that needs
     *                       to be asserted . It is application
     *                       and context sensitive and should be set by the developer. If
     *                       <code>null</code>, a default message is output.
     */
    public void assertTrue(boolean condition, String failureMessage);

    /**
     * If assertion fails, halt the whole app
     */
    public static final int LEVEL_ERROR = 0x01;

    /**
     * If assertion fails, throw a runtime exception
     */
    public static final int LEVEL_EXCEPTION = 0x02;

    /**
     * Log an assertion failure.
     */
    //TODO Implement logging an assertion sometime in the future.
    public static final int LEVEL_LOG = 0x40;


}
