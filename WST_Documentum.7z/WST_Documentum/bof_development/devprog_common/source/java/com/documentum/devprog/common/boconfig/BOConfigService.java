/*
 * Created on Oct 9, 2003
 * Documentum Developer Program 2003
 * 
 */
package com.documentum.devprog.common.boconfig;

import java.util.*;
import java.io.*;

import javax.xml.parsers.*;

import org.w3c.dom.*;
import org.xml.sax.*;

import org.apache.xpath.domapi.*;
import org.w3c.dom.xpath.*;

import com.documentum.fc.common.DfLogger;

/**
 * An implementation of the IBOConfig interface.
 * 
 * @author Aashish Patil (aashish.patil@documentum.com)
 *
 * 
 */
class BOConfigService implements IBOConfig
{
   /**
    * The BO whose config info is being accessed.
    */
   private Object m_bobj = null;

   /**
    * The name of the BO.
    */
   private String m_strBoName = null;

   /**
    * The cache that is used to store the config info
    */
   private Cache m_reg = null;

   /**
    * The XML Doc from which config values are read in. 
    */
   private Document m_confDoc = null;

   /**
    * The evaluator used to evaluate the xpath expressions.
    */
   private XPathEvaluator m_xpathEval = null;

   /**
    * The namespace resolver used for evaluating xpath expressions.
    */
   private XPathNSResolver m_nsResolver = null;

   /**
    * This represents the context node corresponding to the \&lt;boconfig\&gt;
    * element. All xpath expressions are evaluated relative to this. 
    */
   private Element m_contextNode = null;

   /**
    * The boconfig element \<boconfig\> 
    */
   private String ELEM_BOCONFIG = "/boconfig";

   /* (non-Javadoc)
    * @see com.documentum.devprog.common.config.IBOConfig#getValue(java.lang.String)
    */
   public String getValue(String expression)
   {
      String[] values = getValues(expression);
      if (values.length > 0)
      {
         return values[0];
      }
      return null;
   }

   /**
    * Returns the text children of the nodes found as a result of
    * executing the xpath expression. If no results are found an 
    * empty array (length=0) is returned.
    * 
    * @see com.documentum.devprog.common.config.IBOConfig#getValues(java.lang.String)
    */
   public String[] getValues(String expression)
   {
      expression = makeValidExpression(expression);

      //System.out.println("evaluating " + expression);
      XPathResult results =
         (XPathResult) m_xpathEval.evaluate(
            expression,
            m_contextNode,
            m_nsResolver,
            XPathResult.UNORDERED_NODE_ITERATOR_TYPE,
            null);
      //System.out.println("got results " + results);
      ArrayList resultList = new ArrayList(5);
      Node res;
      while ((res = results.iterateNext()) != null)
      {
         //System.out.println("Iterating thru results");
         NodeList childs = res.getChildNodes();
         StringBuffer bufText = new StringBuffer(32);
         for (int i = 0; i < childs.getLength(); i++)
         {
            Node childNode = childs.item(i);
            if (childNode.getNodeType() == Node.TEXT_NODE)
            {
               bufText.append(childNode.getNodeValue());
            }
            else
            {
               break;
            }

         } //for(allChildsForEachNode)
         resultList.add(bufText.toString().trim());
      } //while(allResultNodes)
      String[] strArr = new String[resultList.size()];
      resultList.toArray(strArr);
      return strArr;
   }

   /* (non-Javadoc)
    * @see com.documentum.devprog.common.config.IBOConfig#getXMLAttributeValue(java.lang.String, java.lang.String)
    */
   public String getXMLAttributeValue(String expression, String attrName)
   {
      String[] values = getXMLAttributeValues(expression, attrName);
      if (values.length > 0)
      {
         return values[0];
      }
      return null;
   }

   /**
    * Returns the values of the attribute specified in the list
    * of XML Nodes obtained by evaluating the specified XPath expression.
    * The values returned are unordered.  
    * 
    * @see com.documentum.devprog.common.config.IBOConfig#getXMLAttributeValues(java.lang.String, java.lang.String)
    */
   public String[] getXMLAttributeValues(String expression, String attrName)
   {

      expression = makeValidExpression(expression);

      XPathResult results =
         (XPathResult) m_xpathEval.evaluate(
            expression,
            m_contextNode,
            m_nsResolver,
            XPathResult.UNORDERED_NODE_ITERATOR_TYPE,
            null);

      ArrayList lstResults = new ArrayList(5);
      Node curResult = null;
      while ((curResult = results.iterateNext()) != null)
      {
         if (curResult.getNodeType() == Node.ELEMENT_NODE)
         {
            Element elemResult = (Element) curResult;
            String attrValue = elemResult.getAttribute(attrName);
            if ((attrValue != null) && (attrValue.length() > 0))
            {
               lstResults.add(attrValue);
            }
         }
      }

      String[] arrResults = new String[lstResults.size()];
      lstResults.toArray(arrResults);
      return arrResults;
   }

   /**
    * Attempt to read the config info from the cache. If not in cache
    * read the from file boconfig.xml that should be present in the jar
    * of the BO. The information is then cached for future use in the cache.
    * 
    * @param obj
    * @param reg
    */
   BOConfigService(Object obj, Cache cache) throws BOConfigException
   {
      if (obj == null)
      {
         throw new IllegalArgumentException("BO instance is null. That is needed to obtain config information");
      }
      m_strBoName = obj.getClass().getName();
      m_bobj = obj;
      m_confDoc = cache.getConfigDoc(m_strBoName);
      if (m_confDoc == null)
      {
         readConfig(null);
         if (m_confDoc == null)
         {
            throw new BOConfigException(
               "Unable to locate the configuration file in cache or the default location in the jar for "
                  + m_strBoName);
         }
         cache.putConfigDoc(m_strBoName, m_confDoc);
      }
      setupXPathParams();
   }

   /**
    * The configuration information is read from the config source and
    * also cached for future use.
    * 
    * @param strBoName The BO name for which this conf is used.
    * @param reg The cache 
    * @param confSrc The input source from which to read the config info
    */
   BOConfigService(String strBoName, Cache reg, InputStream confSrc)
      throws BOConfigException
   {
      m_strBoName = strBoName;
      if (reg.contains(m_strBoName))
      {
         m_confDoc = reg.getConfigDoc(m_strBoName);
      }
      else
      {
         readConfig(confSrc);
         reg.putConfigDoc(m_strBoName, m_confDoc);
      }
      setupXPathParams();
   }

   /**
    * Reads the config information from boconfig.xml located at 
    * the same location as the class file for a specified class.
    * 
    * @param boClass The class from whose location the boconfig.xml file is read
    * @param cache The cache instance into which the parsed file is saved.
    * @throws BOConfigException
    */
   BOConfigService(Class boClass, Cache cache) throws BOConfigException
   {
      m_strBoName = getClass().getName();

      m_confDoc = cache.getConfigDoc(m_strBoName);
      if (m_confDoc == null)
      {
         readConfig(boClass.getResourceAsStream("boconfig.xml"));
         if (m_confDoc == null)
         {
            throw new BOConfigException(
               "Unable to locate the configuration file in cache or the default location in the jar for "
                  + m_strBoName);
         }
         cache.putConfigDoc(m_strBoName, m_confDoc);
      }
      setupXPathParams();
   }

   /**
    * The configuration information is read from the boconfig.xml file that
    * should be a part of the BO jar. The boconfig.xml is looked for in the
    * same directory as the class file. The information is not cached.
    *  
    * @param bobj
    */
   BOConfigService(Object bobj) throws BOConfigException
   {
      m_bobj = bobj;
      m_strBoName = m_bobj.getClass().getName();
      readConfig(null);
      if (m_confDoc == null)
      {
         throw new BOConfigException(
            "Unable to read config information from default location in jar for "
               + m_strBoName);
      }
      setupXPathParams();
   }

   /**
    * Reads the configuration information from the specified config source.
    * No caching is done. 
    *  
    * @return
    */
   BOConfigService(InputStream confSrc) throws BOConfigException
   {
      readConfig(confSrc);
      if (m_confDoc == null)
      {
         throw new BOConfigException("Unable to read config information from specified source");
      }
      setupXPathParams();
   }

   /**
    * Reads and parses the XML Config file. If <code>confSrc</code> is null,
    * then attempt is  made to read from the default location in the jar from
    * a file named boconfig.xml
    * 
    * @param confSrc
    */
   private void readConfig(InputStream confSrc)
   {
      if (confSrc == null)
      {
         confSrc = m_bobj.getClass().getResourceAsStream("boconfig.xml");
      }

      try
      {
         DocumentBuilder bldr =
            DocumentBuilderFactory.newInstance().newDocumentBuilder();
         m_confDoc = bldr.parse(confSrc);

      }
      catch (IOException ioe)
      {
         DfLogger.error(
            this,
            "IO Error while reading config info for " + m_bobj,
            null,
            ioe);
      }
      catch (ParserConfigurationException pce)
      {
         DfLogger.error(
            this,
            "XML Parse error while reading config info for " + m_strBoName,
            null,
            pce);

      }
      catch (SAXException se)
      {
         DfLogger.error(
            this,
            "SAX Parser Error while reading config info for " + m_strBoName,
            null,
            se);
      }

   }

   /**
    * Sets up the evaluator, nsresolver and context node from the config
    * file Document
    *
    */
   private void setupXPathParams()
   {
      m_xpathEval = new XPathEvaluatorImpl(m_confDoc);

      Element boconfigElem = m_confDoc.getDocumentElement();
      m_contextNode = boconfigElem;
//      System.out.println(
//         "setting context node to: " + m_contextNode.getNodeName());

      XPathNSResolver nsResolver = m_xpathEval.createNSResolver(m_confDoc);
      m_nsResolver = nsResolver;
   }

   /* (non-Javadoc)
    * @see com.documentum.devprog.common.boconfig.IBOConfig#getValuesAsXMLNodes(java.lang.String)
    */
   public Node[] getValuesAsXMLNodes(String expression)
   {
      expression = makeValidExpression(expression);

      XPathResult results =
         (XPathResult) m_xpathEval.evaluate(
            expression,
            m_contextNode,
            m_nsResolver,
            XPathResult.UNORDERED_NODE_ITERATOR_TYPE,
            null);
      ArrayList lstResults = new ArrayList(5);

      Node curResult = null;
      while ((curResult = results.iterateNext()) != null)
      {
         lstResults.add(curResult);
      }
      Node arrNode[] = new Node[lstResults.size()];
      lstResults.toArray(arrNode);
      return arrNode;

   }

   /**
    * makes a valid expression of form
    * <br> /boconfig/someElement OR
    * <br> someElement/restOfPath
    * 
    * <p>Following are not valid
    * <br>boconfig/restOfPath
    * <br>/someElement/restOfPath
    * 
    * @param expression
    * @return valid expression.
    */
   private String makeValidExpression(String expression)
   {

      StringBuffer buf =
         new StringBuffer(ELEM_BOCONFIG.length() + expression.length() + 1);

      if (!expression.startsWith("/boconfig"))
      {
         if (expression.startsWith("boconfig"))
         {
            buf.append("/").append(expression);
         }
         else if (expression.startsWith("/"))
         {
            buf.append(ELEM_BOCONFIG).append(expression);
         }
         expression = buf.toString();
      }

      return expression;
   }

} //class BOConfigService
