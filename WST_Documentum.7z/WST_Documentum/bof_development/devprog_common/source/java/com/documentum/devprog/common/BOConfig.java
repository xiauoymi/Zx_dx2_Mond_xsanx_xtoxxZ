/*
 * Created on Mar 14, 2003
 *
 * 
 */
package com.documentum.devprog.common;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.LinkedList;

/**
 * Provides access methods to access the values contained in the XML config file.
 * <pre>
 * <br>
 * <br><boconfig>
 * <br> <attributes scopedBy='someScope'>
 * <br>    <attribute>
 * <br>        <name>nameOfAttr</name>
 * <br>        <type>typeOfAttr</type>
 * <br>        <!-- one or more values -->
 * <br>        <value>value</value>*
 * <br>     </attribute>
 * <br> </attributes>
 * <br></boconfig>
 * </pre>
 * <br> The file should be in the same package as the implementation class and should be on the class path of the JVM.
 * It can be present in the same jar file as the BO classes.
 *
 * <br> The business logic can vary from one BO to another. Hence, it is difficult to generalise xml configuration
 * files. The above file is an attempt to generalise configuration. All the tags are mere placeholders and their
 * interpretation depends <br>entirely on the Business Object that uses the tags and their values. The aim is to provide
 * a common Java class that can interpret the xml file. The Java class can then be reused across varied Business Objects
 * without having to write new XML parsing routines everytime a BO needs some configuration.
 *
 *
 * <br> The <![CDATA[ <type> ]]> tag does not necessarily represent a document object type. Its value is open for
 * interpretation by the BO that uses it.
 *
 * TODO Work on in-memory caching. Currently, it does not work.
 *
 * @author Aashish Patil (aashish.patil@documentum.com)
 * @version 2.0 Added  support for the scopedBy attribute in the <attributes> element
 */
public class BOConfig {

  /**
   * Global Hashtable containing configs of all BOs. Each entry points to a Hashtable of a BO.
   */
  private static Hashtable m_htblAllConfigs = null;

  /**
   * References to the instance of the Hashtable containing the config information
   * of the BO specified by m_strImplClassName.

   private Hashtable m_htblCurrentConfig = null;
   */

  /**
   * Hashtable containing attributes per scope value.
   */
  private Hashtable m_htblCurrentConfigByScope = null;

  /**
   * Implementation class name of the BO that initialised the BOConfig instance.
   */
  private Class m_clsImplClass = null;

  /**
   * Enable/Disable in-memory caching for the specific BO that initialised this instance of the BOConfig.
   */
  private boolean m_blEnableInMemoryCaching = true;

  /**
   * Enable/Disable in-memory caching of all the BO configs.
   */
  private static boolean m_blGlobalEnableInMemoryCaching = true;

  /**
   * Name of the XML Config file
   */
  private final String m_strConfigFilename = "boconfig.xml";

  /**
   * Default scope name. This is used if the 'scopeBy' attribute is omitted from the attributes tag.
   */
  private String m_strDefaultScopedByVal = Long.toString(System.currentTimeMillis());

  /**
   * default scope used by other classes to refer to the default scope value.
   */
  public static String DEFAULT_SCOPE = "";
  /**
   * 'scopedBy' attribute string
   */
  private String m_strScopedBy = "scopedBy";

  /**
   * Constructor
   *
   * @param boImplClass           The implementation class of the BO. It is used to locate the xml config file. The file
   *                              is expeceed to reside within the same package as the BO Implementation class.
   * @param enableInMemoryCaching Enables/disable memory caching for current BO config data. TODO Current implementation
   *                              ignores this parameter. Need to support this.
   */
  public BOConfig(Object boImplClass, boolean enableInMemoryCaching) {
    m_clsImplClass = boImplClass.getClass();
    m_blEnableInMemoryCaching = enableInMemoryCaching;

    if (m_htblAllConfigs == null) {
      if (m_blGlobalEnableInMemoryCaching) {
        m_htblAllConfigs = new Hashtable(5); //5 is a random number

      }
      readConfigFile();
    } else //htbl already exists implies that global caching is already enabled
    {
      //check whether the current BOs htbl already exists
      String strImplClassName = m_clsImplClass.getName();
      if (m_htblAllConfigs.contains(strImplClassName)) {
        System.out.println("Found old config");
      } else {
        readConfigFile();
      }

    }

  }


  /**
   * Reads the XML Config file. The structure of the file is assumed to be as <br> <br><boconfig> <br> <attributes
   * scopedBy='someScope'> <br>    <attribute> <br>        <name>nameOfAttr</name> <br>        <type>typeOfAttr</type>
   * <br> <br>        <value>value</value>* <br>     </attribute>* <br> </attributes>* <br></boconfig>
   *
   * <br> The file should be in the same package as the implementation class and should be on the class path of the JVM.
   * Thus, it can be present in the same jar file as the BO classes.
   */
  private void readConfigFile() {

    InputStream insConfigFile = m_clsImplClass.getResourceAsStream(m_strConfigFilename);

    try {
      DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
      DocumentBuilder docBldr = docFactory.newDocumentBuilder();
      Document document = docBldr.parse(insConfigFile);
      Element docElement = document.getDocumentElement();

      NodeList attrsList = docElement.getElementsByTagName("attributes");
      if (attrsList == null) {
        return;
      }
      int numScopedByElems = attrsList.getLength();
      m_htblCurrentConfigByScope = new Hashtable(numScopedByElems);

      for (int cntrAttrsByScope = 0;
           cntrAttrsByScope < attrsList.getLength();
           cntrAttrsByScope++) {

        Element attrsElement = (Element) attrsList.item(cntrAttrsByScope);

        String strScopedByVal = attrsElement.getAttribute(m_strScopedBy);
        if (UtilityMethods.isStringEmpty(strScopedByVal)) {
          strScopedByVal = m_strDefaultScopedByVal;
        }
        NodeList attrAll = attrsElement.getElementsByTagName("attribute");

        if (attrAll == null) {
          return;
        }
        int numAttr = attrAll.getLength();
        Hashtable htblCurrentConfig = new Hashtable(numAttr);

        //iterate through each attribute defined
        for (int cntrAttrs = 0; cntrAttrs < numAttr; cntrAttrs++) {
          Element attrCurrent = (Element) attrAll.item(cntrAttrs);

          NodeList lstName = attrCurrent.getElementsByTagName("name");
          Element elemName = (Element) lstName.item(0);
          Node nameChild = elemName.getFirstChild();
          String strName = nameChild.getNodeValue().trim();

          NodeList lstType = attrCurrent.getElementsByTagName("type");
          String strType = null;
          if ((lstType != null) && (lstType.getLength() > 0)) {
            Element elemType = (Element) lstType.item(0);
            Node typeChild = elemType.getFirstChild();
            strType = typeChild.getNodeValue().trim();
          }

          NodeList lstValues = attrCurrent.getElementsByTagName("value");
          String strArrayValues[] = null;
          if ((lstValues != null) && (lstValues.getLength() > 0)) {
            int numValues = lstValues.getLength();
            strArrayValues = new String[numValues];
            for (int cntrValues = 0; cntrValues < numValues; cntrValues++) {
              Element elemValue = (Element) lstValues.item(cntrValues);
              Node valueChild = elemValue.getFirstChild();
              strArrayValues[cntrValues] = new String();
              strArrayValues[cntrValues] = valueChild.getNodeValue().trim();

            } //for(cntrValues)
          }
          AttributeEntry entry = new AttributeEntry();
          entry.setAttrName(strName);
          //System.out.println("Attr Name: " + strName);
          entry.setAttrType(strType);
          //System.out.println("Attr Type: " + strType);
          entry.setAttrValues(strArrayValues);
          //System.out.println("AttrValues: " + strArrayValues);

          htblCurrentConfig.put(strName, entry);

        } //for(cntrAttrs)
        m_htblCurrentConfigByScope.put(strScopedByVal, htblCurrentConfig);

      } //for(cntrAttrsScope

      m_htblAllConfigs.put(m_clsImplClass.getName(), m_htblCurrentConfigByScope);

      /** Does not work. Need to revise
       if (m_blEnableInMemoryCaching == true)
       {
       if (m_blGlobalEnableInMemoryCaching == true)
       {
       m_htblAllConfigs.put(m_clsImplClass.getName(), htbl);
       }
       }*/

    } //try
    catch (ParserConfigurationException pce) {

    }
    catch (SAXException se) {

    }
    catch (IOException ioe) {

    }

  } //readConfigFile

  /**
   * Checks if attribute with name <code>attrName</code> exists in the config. Default scope is used to check for
   * existence of attribute. The <attribute> tags within <attributes> tag that does not have a scopedBy attribute are
   * tags that come under the default scope.
   *
   * @param attrName Name of the attribute
   *
   * @return boolean  true=>Attribute exists <br>false=>attribute does not exist.
   */
  public boolean hasAttribute(String attrName) {
    return hasAttribute(m_strDefaultScopedByVal, attrName);
  }

  /**
   * Checks for the existence of an attribute within a scope.
   *
   * @param scopeName The scope within which the existence of an attribute is searched for. If empty, the default scope
   *                  is used.
   * @param attrName  The name of the attribute that is being searched for.
   *
   * @return boolean  true => If attribute found. <br>false => Attribute not found OR scopeName is null
   */
  public boolean hasAttribute(String scopeName, String attrName) {
    if (scopeName == null) {
      return false;
    }

    if (m_htblCurrentConfigByScope != null) {
      if ((scopeName.equals(""))) {
        scopeName = m_strDefaultScopedByVal;
      }

      Hashtable htbl = (Hashtable) m_htblCurrentConfigByScope.get(scopeName);

      return (htbl.containsKey(attrName));

    }
    return false; //hashtable is null no chance of attr being there.
  } //hasAttr(scope,...)

  /**
   * Gets all the values of the attribute. Scope specified by <code> scopeName </code> is used to search for the
   * attribute.
   *
   * @param attrName  Name of the attribute whose values are requested.
   * @param scopeName Name of the scope within which to search for this attribute If empty, the default scope is used
   *
   * @return String[] Values of the attribute. There is a one-one correspondence between the order of the
   *         <value>...</value> tags in the XML file and the elements of the array. Thus, the first tags' value will be
   *         at the zeroeth index and so on. A null is returned in case of failure or if the scopeName is null
   */
  public String[] getAttributeValue(String scopeName, String attrName) {
    if (scopeName == null) {
      return null;
    }

    if (m_htblCurrentConfigByScope != null) {
      if ((scopeName.equals(""))) {
        scopeName = m_strDefaultScopedByVal;
      }

      Hashtable htbl = (Hashtable) m_htblCurrentConfigByScope.get(scopeName);

      if (htbl == null) {
        return null;
      }
      if (htbl.containsKey(attrName)) {

        AttributeEntry attrEntry = (AttributeEntry) htbl.get(attrName);

        String allValues[] = attrEntry.getAttrValues();

        return (String[]) allValues;
      }
    }
    return null;

  }

  /**
   * Gets all the values of the attribute.Default scope is used to search for attribute values. The <attribute> tags
   * within <attributes> tag that does not have a scopedBy attribute are tags that come under the default scope.
   *
   * @param attrName Name of the attribute whose values are requested.
   *
   * @return String[] Values of the attribute. There is a one-one correspondence between the order of the
   *         <value>...</value> tags in the XML file and the elements of the array. Thus, the first tags' value will be
   *         at the zeroeth index and so on.
   */
  public String[] getAttributeValue(String attrName) {
    return getAttributeValue(m_strDefaultScopedByVal, attrName);
  } //getAttributeValue

  /**
   * Returns the value of the <type>..</type> tags for the attribute specified by the <code>attrName</code>.
   *
   * @param scopeName The scope under which is attribute is searched for. If empty, the default scope is searched
   * @param attrName  The name of the attribute
   *
   * @return String  The value of the <type>...</type> tags of the attribute. In case of an abnormal circumstances a null
   *         is returned. A null is also returned if scopeName parameter is null
   */
  public String getType(String scopeName, String attrName) {
    if (scopeName == null) {
      return null;
    }

    if (m_htblCurrentConfigByScope != null) {
      if ((scopeName.equals(""))) {
        scopeName = m_strDefaultScopedByVal;
      }
      Hashtable htbl = (Hashtable) m_htblCurrentConfigByScope.get(scopeName);
      if (htbl == null) {
        return null;
      }
      if (htbl.containsKey(attrName)) {

        AttributeEntry entry = (AttributeEntry) htbl.get(attrName);
        String type = entry.getAttrType();
        return type;
      }
    }
    return null;

  } //getType

  /**
   * Returns the value of the <type>..</type> tags for the attribute specified by the <code>attrName</code>. It uses
   * default scope to retrieve attributes. The <attribute> tags within <attributes> tag that does not have a scopedBy
   * attribute are tags that come under the default scope.
   *
   * @param attrName The name of the attribute
   *
   * @return String  The value of the <type>...</type> tags of the attribute. In case of an abnormal circumstances a null
   *         is returned.
   */
  public String getType(String attrName) {
    return getType(m_strDefaultScopedByVal, attrName);

  } //getType

  /**
   * Returns a list of the attribute names
   *
   * @return LinkedList   names of all attributes i.e. values of all <name>...</name> tags of all
   *         <attribute>...</attribute> tags <br>A <code>null</code> is returned if config does not exist or if there is
   *         a failure or if the <code>scopeName<code> param is null
   */
  public LinkedList getAllAttributeNames(String scopeName) {
    if (scopeName == null) {
      return null;
    }

    if (m_htblCurrentConfigByScope != null) {
      if ((scopeName.equals(""))) {
        scopeName = m_strDefaultScopedByVal;
      }

      Hashtable htbl = (Hashtable) m_htblCurrentConfigByScope.get(scopeName);
      LinkedList list = new LinkedList();

      Enumeration currentconfigkeys = htbl.keys();
      while (currentconfigkeys.hasMoreElements()) {
        list.add(currentconfigkeys.nextElement());
      }
      return list;
    }
    return null;
  }

  /**
   * Returns a list of the attribute names
   *
   * @return LinkedList   names of all attributes i.e. values of all <name>...</name> tags of all
   *         <attribute>...</attribute> tags <br>A <code>null</code> is returned in case of failure or if config does not
   *         exist
   */
  public LinkedList getAllAttributeNames() {
    return getAllAttributeNames(m_strDefaultScopedByVal);
  }

  /**
   * Returns the number of attributes defined in the config.
   *
   * @return int  number of attributes. <br> -1 is returned in case of failure.
   */
  public int getAttributeCount(String scopeName) {
    if (scopeName == null) {
      return -1;
    }

    if (m_htblCurrentConfigByScope != null) {
      if (scopeName.equals("")) {
        scopeName = m_strDefaultScopedByVal;
      }

      Hashtable htbl = (Hashtable) m_htblCurrentConfigByScope.get(scopeName);
      if (htbl == null) {
        return -1;
      }
      return htbl.size();
    }
    return -1;
  }

  /**
   * Returns the number of attributes defined in the config.
   *
   * @return int  number of attributes. <br> -1 is returned in case of failure.
   */
  public int getAttributeCount() {
    return getAttributeCount(m_strDefaultScopedByVal);
  }

  /**
   * Returns a list of all the scope except for the default scope value.
   *
   * @return LinkedList   All scope names except for default scope name. A <code>null</code> is returned in case of
   *         failure
   */
  public LinkedList getAllScopes() {
    if (m_htblCurrentConfigByScope != null) {
      LinkedList lstScopes = new LinkedList();
      Enumeration enumScopes = m_htblCurrentConfigByScope.keys();
      while (enumScopes.hasMoreElements()) {
        String strScope = (String) enumScopes.nextElement();
        if (!strScope.equals(m_strDefaultScopedByVal)) {
          lstScopes.add(strScope);
        }

      }
      return lstScopes;
    }
    return null;
  }//getAllScopes


  /////////////////////////////////////////////////////////////////////////
  // Inner class definition begins
  /**
   * Inner class representing a complete attribute entry. This class maps to the <attribute>...</attribute> tag and its
   * contents.
   *
   * @author Aashish Patil (aashish.patil@documentum.com)
   */
  class AttributeEntry {
    /**
     * The attribute type entry in the XML file
     */
    private String m_attrType = null;

    /**
     * The values of the attribute. An attribute can have one or more values
     */
    private String m_attrValueArray[] = null;

    /**
     * The name of the attribute
     */
    private String m_attrName = null;

    //setter and getter for member variables

    /**
     * sets the attribute name
     *
     * @param name name of the attribute i.e. value between the <name>...</name> tags.
     */
    void setAttrName(String name) {
      m_attrName = name;
    }

    /**
     * Gets the name of the attribute
     *
     * @return String   name of the attribute i.e. value between the <name>...</name> tag
     */
    String getAttrName() {
      return m_attrName;
    }

    /**
     * sets the type of the attribute i.e value between <type>...</type> tags
     *
     * @param type type of the attribute
     */
    void setAttrType(String type) {
      m_attrType = type;
    }

    /**
     * gets the type of the attribute
     *
     * @return String   type of the attribute i.e. value between the <type>...</type> tags
     */
    String getAttrType() {
      return m_attrType;
    }

    /**
     * Sets the values of the attribute i.e. the values between the multiple <value>...</value> tags.
     *
     * @param values values of the attribute There is a one-one correspondence between the order of the tags and the
     *               elements of the array
     */
    void setAttrValues(String values[]) {
      m_attrValueArray = values;
    }

    /**
     * Gets the values of the attribute
     *
     * @return String[] Values of the attribute. There is a one-one correspondence between the order of the
     *         <value>...</value> tags in the XML file and the elements of the array. Thus, the first tags value will be
     *         at the zeroeth position and so on.
     */
    String[] getAttrValues() {
      return m_attrValueArray;
		}

	}
	///////// Inner class definition ends
	/////////////////////////////////////////////////////////////////////////////

}
