/*
 * Created on Nov 3, 2003
 * Documentum Developer Program 2003
 */
package com.documentum.devprog.common.boconfig;

import org.w3c.dom.Node;

/**
 * @author Aashish Patil (aashish.patil@documentum.com)
 *
 * 
 */
public interface IBOConfig
{
   /**
    * Gets the text values obtained by evaluating the specified expression.
    * The expression points to nodes whose children are text nodes.
    * <br>
    * For expressions of form '/template/document'
    * @param expression
    * @return
    */
   String[] getValues(String expression);
   
   /**
    * Get the text child value of the first node returned by executing the 
    * expression specified. 
    */
   String getValue(String expression);
   
   
   /**
    * Gets values of the attribute specified in the expression.
    * <br>
    *  
    * @param expression This creates the node list to search for attributes
    * @param attrName The name of the attribute whose values are needed.
    * @return 
    */
   String[] getXMLAttributeValues(String expression,String attrName);
   
   /**
    * Gets the first value for the attribute. The attribute is searched for
    * in the nodelist obtained by running the expression specified.
    * 
    * @param expression Expression used to obtain nodelist.
    * @param attrName The attribute name of the whose value is searched
    *                 <br> in the first node of the nodelist.
    * @return The first attr value if an attribute match is found in the results.
    * 
    */
   String getXMLAttributeValue(String expression,String attrName);
   
   /**
    * Gets the DOM representation of the results of the xpath expression.
    * The caller of this method has the responsibility of interpreting the
    * results.
    *  
    * @param expression
    * @return Unordered Array of org.w3c.dom.Node objects
    */
   Node[] getValuesAsXMLNodes(String expression);
   
}
