/*
 * Created on Nov 3, 2003
 * Documentum Developer Program 2003
 */
package com.documentum.devprog.common.boconfig;

import java.util.*;
import org.w3c.dom.*;
import org.w3c.dom.xpath.XPathEvaluator;

import com.documentum.fc.common.DfLogger;

/**
 * 
 * 
 * @author Aashish Patil (aashish.patil@documentum.com)
 */
class Cache
{
   /**
    * Maintains a mapping from 
    * <br>
    * class name => objects of type Cache.CacheEntry
    *  
    * 
    */
   private HashMap m_confReg = null;

   /**
    * The time in milliseconds for which an entry is cached.
    */
   private long m_entryLifetime = 120000;

   /**
    * The frequency period in milliseconds after which the cleaner should
    * run to clean the cache.
    */
   private long m_cleanerRunPeriod = 3000;

   /**
    * Package protected constructor
    *
    */
   Cache()
   {
      if (m_confReg == null)
      {
         m_confReg = new HashMap(10);
      }

      initCacheCleaner();
   }

   /**
    * Sets the properties of the cache cleaner. 
    *
    */
   private void initCacheCleaner()
   {
      try
      {
         StringBuffer bufBundleName = new StringBuffer(32);
         bufBundleName.append(this.getClass().getPackage().getName()).append(
            ".").append(
            "boconfig");
         PropertyResourceBundle bundle =
            (PropertyResourceBundle) PropertyResourceBundle.getBundle(
               bufBundleName.toString());

         m_entryLifetime =
            Integer.parseInt(bundle.getString("cache.entry.lifetime"));
         m_cleanerRunPeriod =
            Integer.parseInt(bundle.getString("cache.cleaner.frequency"));

      }
      catch (Exception ex)
      {
         //Log error and resort to default values. 
         //Overkill to halt or disturb execution.
         DfLogger.error(
            this,
            "Unable to read config properties values. Resorting to defaults.",
            null,
            ex);
      }

      CacheCleaner cleaner = new CacheCleaner(this);
      Timer tmrCleaner = new Timer(true); //set timer to be daemon
      tmrCleaner.schedule(cleaner, 500, m_cleanerRunPeriod);

   } //initCacheCleaner

   /**
    * Puts the  parsed xml config document for a BO into the registry. 
    * 
    * @param boName The name of the BO whose config info is being cached.
    *               <br>It is better to use the fully qualified interface name
    *               <br>of the BO.
    * @param xmlDoc The corresponding XML config doc 
    */
   synchronized void putConfigDoc(String boName, Document xmlDoc)
   {
      //System.out.println("trying ot add to cache");
      CacheEntry entry = new CacheEntry();
      entry.xmlDoc = xmlDoc;
      entry.timestamp = System.currentTimeMillis();
      m_confReg.put(boName, entry);
   }

   /**
    * Gets the XML config doc for the bo name specified. 
    * @param boName
    * @return
    */
   Document getConfigDoc(String boName)
   {
      CacheEntry entry = (CacheEntry) m_confReg.get(boName);
      if (entry == null)
      {
         return null;
      }
      Document doc = entry.xmlDoc;
      entry.timestamp = System.currentTimeMillis();
      return doc;
   }

   /**
    * Removes the cached config information for the specified BO. 
    * @param boName
    */
   synchronized void remove(String boName)
   {
      //System.out.println("Trying to remove from cache");
      m_confReg.remove(boName);
   }

   /**
    * Checks if the config information for the BO is already cached. 
    * @param boName The name of the BO.
    * @return true=>Info is there / false=>Info not there.
    */
   boolean contains(String boName)
   {
      return m_confReg.containsKey(boName);
   }

   /**
    * Returns the number of BO Config files cached.
    * @return
    */
   int size()
   {
      return m_confReg.size();
   }

      
   synchronized void cleanCache()
   {

      Set keySet = m_confReg.keySet();
      Iterator keyIter = keySet.iterator();
      while (keyIter.hasNext())
      {
         String boName = (String) keyIter.next();
         CacheEntry entry = (CacheEntry) m_confReg.get(boName);
         long curTime = System.currentTimeMillis();
         if ((curTime - entry.timestamp) > m_entryLifetime)
         {
            //entry has not been accessed for quite some time.
            //System.out.println("About to remove " + boName);
                           
            //m_confReg.remove(boName); Don't use this
            //since the current method is already synchronized on cache
            //object. If the hashtable is accessed directly bypassing 
            //the sync methods there can be a sync conflict. This results
            //in java.util.ConcurrentModificationException. 
            //Instead use iterator to remove element.
            keyIter.remove();
         }
      } //while(...)

   }

   class CacheEntry
   {
      /**
       * The XML Document
       */
      Document xmlDoc = null;

      /**
       * Time of last access of this entry.
       */
      long timestamp = 0;
   }

   /**
    * This task runs periodically and cleans up the cache of old
    * and unused entries.
    *
    */
   class CacheCleaner extends java.util.TimerTask
   {
      Cache m_parent = null;

      CacheCleaner(Cache parent)
      {
         m_parent = parent;
      }
      /* (non-Javadoc)
      * @see java.lang.Runnable#run()
      */
      public void run()
      {
         m_parent.cleanCache();
      }
   }

} //class Cache
