/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.documentum.fc.client;

import com.documentum.fc.client.acs.IDfAcsTransferPreferences;
import com.documentum.fc.client.impl.acs.IDfAcsTransferPreferencesImmutable;
import com.documentum.fc.common.*;
import com.monsanto.dctm.test.MockDfACL;
import com.monsanto.dctm.test.MockDfUser;
import com.monsanto.dctm.test.MockPersistentObject;
import com.monsanto.dctm.test.MockDfCollection;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.Map;
import java.util.List;

/**
 * Filename:    $RCSfile: MockSession.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ussing $    	 On:	$Date:
 * 2007/04/20 04:34:42 $
 *
 * @author lakench
 * @version $Revision: 1.7 $
 */
public class MockSession implements IDfSession, IDfSessionInternal {
  private String docbaseOwnerName = null;
  private IDfPersistentObject object = null;
  private int collectionCursor;
  private Map objects = new HashMap();
  private String collectionQualification;
  private IDfSessionManager sessionManager = null;
  private String loginUserName;
  private IDfLoginInfo loginInfo;
  private String docbaseName;
  private Map groups = new HashMap();
  private Map users = new HashMap();
  public boolean wasReleaseCalled = false;
  private List results;


  public MockSession(String docbaseOwnerName) {
    this.docbaseOwnerName = docbaseOwnerName;
  }

  public MockSession(IDfSessionManager sessionManager) {
    this.sessionManager = sessionManager;
  }

  public void addObject(IDfPersistentObject object) {
    addObject(object, "all");
  }

  public void addObject(IDfPersistentObject object, String qualification) {
    objects.put(qualification, object);
    try {
      object.setSessionManager(sessionManager);
      if (object instanceof MockPersistentObject) {
        ((MockPersistentObject) object).setSession(this);
      }
    } catch (DfException e) {
      e.printStackTrace();
    }
  }

  public IDfClient getClient() {
    return null;
  }

  public boolean isConnected() {
    return false;
  }

  public void disconnect() throws DfException {
  }

  public String getSessionId() throws DfException {
    return null;
  }

  public String getDMCLSessionId() throws DfException {
    return "s0";
  }

  public IDfLoginInfo getLoginInfo() throws DfException {
    return loginInfo;
  }

  public void setLoginInfo(IDfLoginInfo loginInfo) {
    this.loginInfo = loginInfo;
  }

  public boolean isShared() throws DfException {
    return false;
  }

  public boolean isRemote() throws DfException {
    return false;
  }

  public boolean isAdopted() throws DfException {
    return false;
  }

  public String getDocbaseScope() throws DfException {
    return null;
  }

  public String setDocbaseScope(String string) throws DfException {
    return null;
  }

  public String setDocbaseScopeById(IDfId iDfId) throws DfException {
    return null;
  }

  public boolean lock(int i) {
    return false;
  }

  public boolean unlock() {
    return false;
  }

  public void abortTrans() throws DfException {
  }

  public void beginTrans() throws DfException {
  }

  public void commitTrans() throws DfException {
  }

  public IDfPersistentObject getObject(IDfId iDfId) throws DfException {
    return getObjectByQualification(iDfId.getId());
  }

  public IDfPersistentObject getObjectWithType(IDfId iDfId, String string, String string1) throws DfException {
    return object;
  }

  public IDfPersistentObject getObjectWithCaching(IDfId iDfId, String string, String string1, String string2, boolean b,
                                                  boolean b1) throws
      DfException {
    return object;
  }

  public IDfPersistentObject getObjectWithInterface(IDfId iDfId, String string) throws DfException,
      DfServiceNotFoundException,
      DfDborNotFoundException {
    return object;
  }

  public IDfPersistentObject getObjectByQualificationWithInterface(String qualification, String string1) throws
      DfException,
      DfServiceNotFoundException {
    return getObjectByQualification(qualification);
  }

  public IDfId getIdByQualification(String qualification) throws DfException {
    try {
      return getObjectByQualification(qualification).getObjectId();
    } catch (DfException e) {
      e.printStackTrace();
      return null;
    }
  }

  public IDfPersistentObject getObjectByQualification(String qualification) throws DfException {
    if (objects.containsKey(qualification))
      return (IDfPersistentObject) objects.get(qualification);
    else
      throw new DfException("no object associated with qualification \"" + qualification + "\"");
  }

  public IDfTypedObject getTypeDescription(String string, String string1, IDfId iDfId, String string2) throws
      DfException {
    return null;
  }

  public IDfPersistentObject newObject(String object_type) throws DfException {
    if (object_type.equals("dm_user")) {
      MockDfUser mockDfUser = new MockDfUser();
      mockDfUser.setSession(this);
      return mockDfUser;
    }
    return (IDfPersistentObject) new MockPersistentObject();
  }

  public IDfPersistentObject newObjectWithType(String string, String string1) throws DfException {
    return (IDfPersistentObject) new MockPersistentObject();
  }


  public String getDocbaseId() throws DfException {
    return null;
  }

  public String getDocbaseName() throws DfException {
    return docbaseName;
  }

  public void setDocbaseName(String docbaseName) {
    this.docbaseName = docbaseName;
  }

  public String getDocbaseOwnerName() throws DfException {
    return docbaseOwnerName;
  }


  public String getDBMSName() throws DfException {
    return null;
  }

  public String getSecurityMode() throws DfException {
    return null;
  }

  public boolean isACLDocbase() throws DfException {
    return false;
  }

  public String getServerVersion() throws DfException {
    return null;
  }

  public int getDefaultACL() throws DfException {
    return 0;
  }

  public IDfACL getACL(String docbaseOwnerName, String aclName) throws DfException {
    return new MockDfACL(docbaseOwnerName, aclName);
  }

  public IDfFolder getFolderByPath(String string) throws DfException {
    return null;
  }

  public IDfFormat getFormat(String string) throws DfException {
    return null;
  }

  public IDfGroup getGroup(String groupName) throws DfException {
    if (groups.containsKey(groupName)) {
      return (IDfGroup) groups.get(groupName);
    }
    return null;
  }

  public void addGroup(IDfGroup group) throws DfException {
    groups.put(group.getGroupName(), group);
  }

  public IDfPersistentObject getObjectByPath(String string) throws DfException {
    return object;
  }

  public IDfType getType(String string) throws DfException {
    return null;
  }

  public IDfUser getUser(String user) throws DfException {
    if (users.containsKey(user)) {
      return (IDfUser) users.get(user);
    }
    return null;
  }

  public void addUser(IDfUser user) throws DfException {
    users.put(user.getUserName(), user);
  }

  public IDfUser getUserByOSName(String string, String string1) throws DfException {
    return null;
  }

  public void flush(String string, String string1) throws DfException {
  }

  public void flushCache(boolean b) throws DfException {
  }

  public IDfTypedObject getClientConfig() throws DfException {
    return null;
  }

  public IDfTypedObject getDocbrokerMap() throws DfException {
    return null;
  }

  public IDfTypedObject getServerMap(String string) throws DfException {
    return null;
  }

  public String getLoginUserName() throws DfException {
    return loginUserName;
  }

  public String getLoginTicket() throws DfException {
    return null;
  }

  public IDfTypedObject getSessionConfig() throws DfException {
    return null;
  }

  public void purgeLocalFiles() throws DfException {
  }

  public void setBatchHint(int i) throws DfException {
  }

  public void shutdown(boolean b, boolean b1) throws DfException {
  }

  public void traceDMCL(int i, String string) throws DfException {
  }

  public IDfCollection apply(String string, String string1, IDfList iDfList, IDfList iDfList1, IDfList iDfList2) throws
      DfException {
    return null;
  }

  public IDfId archive(String string, String string1, int i, boolean b, IDfTime iDfTime) throws DfException {
    return null;
  }

  public void changePassword(String string, String string1) throws DfException {
  }

  public void dequeue(IDfId iDfId) throws DfException {
  }

  public String describe(String string, String string1) throws DfException {
    return null;
  }

  public IDfTypedObject getDocbaseConfig() throws DfException {
    return null;
  }

  public IDfTypedObject getServerConfig() throws DfException {
    return null;
  }

  public IDfCollection getEvents() throws DfException {
    return null;
  }

  public String getMessage(int i) throws DfException {
    return null;
  }

  public boolean hasEvents() throws DfException {
    return false;
  }

  public IDfCollection getLastCollection() throws DfException {
    return null;
  }

  public void reInit(String string) throws DfException {
  }

  public void reStart(String string, boolean b) throws DfException {
  }

  public IDfId restore(String string, String string1, String string2, int i, boolean b, IDfTime iDfTime) throws
      DfException {
    return null;
  }

  public String apiGet(String string, String string1) throws DfException {
    return null;
  }

  public boolean apiSet(String string, String string1, String string2) throws DfException {
    return false;
  }

  public boolean apiExec(String string, String string1) throws DfException {
    return false;
  }

  public ByteArrayInputStream apiGetBytes(String string, String string1, String string2, String string3, int i) throws
      DfException {
    return null;
  }

  public boolean apiSetBytes(String string, String string1, ByteArrayOutputStream byteArrayOutputStream) throws
      DfException {
    return false;
  }

  public IDfCollection getTasks(String string, int i, String string1, String string2) throws DfException {
    return null;
  }

  public IDfId sendToDistributionList(IDfList iDfList, IDfList iDfList1, String string, IDfList iDfList2, int i,
                                      boolean b) throws
      DfException {
    return null;
  }

  public IDfCollection getRunnableProcesses(String string) throws DfException {
      IDfCollection collection = new MockDfCollection(true, results);
      return collection;
  }

  public IDfWorkflowBuilder newWorkflowBuilder(IDfId iDfId) throws DfException {
    return null;
  }

  public IDfVersionTreeLabels getVersionTreeLabels(IDfId iDfId) throws DfException {
    return null;
  }

  public IDfRelationType getRelationType(String string) throws DfException {
    return null;
  }

  public String resolveAlias(IDfId iDfId, String string) throws DfException {
    return null;
  }

  public IDfList apiDesc(String string) throws DfException {
    return null;
  }

  public IDfTypedObject getConnectionConfig() throws DfException {
    return null;
  }

  public String getAliasSet() throws DfException {
    return null;
  }

  public void setAliasSet(String string) throws DfException {
  }

  public IDfId sendToDistributionListEx(IDfList iDfList, IDfList iDfList1, String string, IDfList iDfList2, int i,
                                        int i1) throws
      DfException {
    return null;
  }

  public IDfId sendToDistributionListEx2(IDfList iDfList, IDfList iDfList1, IDfList iDfList2, String s,
                                         IDfList iDfList3, int i, int i1) throws DfException {
    return null;
  }

  public IDfCollection getTasksEx(String string, int i, IDfList iDfList, IDfList iDfList1) throws DfException {
    return null;
  }

  public IDfAuditTrailManager getAuditTrailManager() throws DfException {
    return null;
  }

  public String getLoginTicketForUser(String string) throws DfException {
    return null;
  }

  public String getLoginTicketEx(String string, String string1, int i, boolean b, String string2) throws DfException {
    return null;
  }

  public boolean resetTicketKey() throws DfException {
    return false;
  }

  public String exportTicketKey(String string) throws DfException {
    return null;
  }

  public boolean importTicketKey(String string, String string1) throws DfException {
    return false;
  }

  public IDfSessionManager getSessionManager() {
    return sessionManager;
  }

  public boolean isTransactionActive() throws DfException {
    return false;
  }

  public void authenticate(IDfLoginInfo iDfLoginInfo) throws DfException {
  }

  public void addDynamicGroup(String string) throws DfException {
  }

  public void removeDynamicGroup(String string) throws DfException {
  }

  public int getDynamicGroupCount() throws DfException {
    return 0;
  }

  public String getDynamicGroup(int i) throws DfException {
    return null;
  }

  public boolean resetPassword(String string) throws DfException {
    return false;
  }

  public String getApplicationToken(String string, String string1, int i, String string2, boolean b) throws
      DfException {
    return null;
  }

  public IDfLocalModuleRegistry getModuleRegistry() throws DfException {
    return null;
  }

  public IDfEnumeration getObjectPaths(IDfId iDfId) throws DfException {
    return null;
  }

  public void assume(IDfLoginInfo iDfLoginInfo) throws DfException {
  }

  public IDfAcsTransferPreferences getAcsTransferPreferences() {
    return null;
  }

  public void setAcsTransferPreferences(IDfAcsTransferPreferences iDfAcsTransferPreferences) {
  }

  public void beginTrans(boolean b) throws DfException {
  }

  public void commitTrans(boolean b) throws DfException {
  }

  public void disconnect(boolean b) throws DfException {
  }

  public SimpleDateFormat getDateFormat() throws DfException {
    return null;
  }

  public IDfPersistentObject getObjectByQualificationWithType(String string, String string1, String string2) throws
      DfException {
    return null;
  }

  public boolean registerClass(String string, String string1) throws DfException {
    return false;
  }

  public String convertTimeToString(IDfTime iDfTime) throws DfException {
    return null;
  }

  public String getKey() {
    return null;
  }

  public void unadopt() throws DfException {
  }

  public DfDocbase getDocbase() throws DfException {
    return null;
  }

  public void setSharedObjectCache(DfPersistentObjectsCache dfPersistentObjectsCache) {
  }

  public IDfTypedObject makeTypedObject(String string) throws DfException {
    return null;
  }

  public DfExprFileManager getExprFileManager() {
    return null;
  }

  public IDfSysObject newNote(String string) throws DfException {
    return null;
  }

  public DfAttrValidator getAttrValidator(IDfPersistentObject object, String string) throws DfException {
    return null;
  }

  public DfObjValidator getObjValidator(IDfPersistentObject object) throws DfException {
    return null;
  }

  public DfObjValidator getObjValidator(IDfType iDfType, IDfId iDfId, String string) throws DfException {
    return null;
  }

  public DfValidationManager getValidationManager() {
    return null;
  }

  public String getWidgetType(int i, IDfPersistentObject object, String string) throws DfException {
    return null;
  }

  public String getWidgetType(int i, IDfType iDfType, String string, IDfId iDfId, String string1) throws DfException {
    return null;
  }

  public DfAttrValidator getAttrValidator(IDfType iDfType, String string, IDfId iDfId, String string1) throws
      DfException {
    return null;
  }

  public void abortTrans(boolean b) throws DfException {
  }

  public DfCommandBuffer buildCommandRoot(String method) {
    DfCommandBuffer command = new DfCommandBuffer(method);
    command.appendArgument("s0");
    return command;
  }

  public void cacheObject(IDfPersistentObject object) throws DfException {
  }

  public void setManager(IDfSessionManager iDfSessionManager) {
  }

  public boolean apiExec(String string) throws DfException {
//        System.out.println("apiExec string = " + string);
    if (string.startsWith("next") && string.endsWith("q0")) {
      if (collectionCursor > 0) {
        collectionCursor = 0;
        return false;
      } else {
        collectionCursor++;
        return true;
      }
    } else {

      return true;
    }
  }

  public String apiGet(String string) throws DfException {
//        System.out.println("apiGet string = " + string);
    if (string.startsWith("query_cmd")) {
      collectionQualification = string;
      collectionCursor = 0;
      return "q0";
    } else if (string.startsWith("get,s0,q0,")) {
      return getObjectByQualification(collectionQualification).getString(string.substring("get,s0,q0,".length()));
    }
    return null;
  }

  public ByteArrayInputStream apiGetBytes(String string, String string1, String string2, int i) throws DfException {
    return null;
  }

  public boolean apiSet(String string, String string1) throws DfException {
    return false;
  }

  public IDfPersistentObject makePersistentObject(IDfId iDfId, String string, String string1) throws DfException {
    return null;
  }

  public DfServiceThreadHelper getThreadHelper() {
    return null;
  }

  public void setThreadHelper(DfServiceThreadHelper dfServiceThreadHelper) {
  }

  public void resetState() throws DfException {
  }

  public void modifyStorageChangeObject(IDfSession session) throws DfException {
  }

  public boolean isManaged() {
    return false;
  }

  public Class getRegisteredClass(String string) {
    return null;
  }

  public void updateCache(IDfPersistentObject object) throws DfException {
  }

  public String getSuperType(String string) throws DfException {
    return null;
  }

  public void disconnectWithoutException() {
  }

  public void autoRelease(Object object, boolean b) {
  }

  public IDfFolder getFolderBySpecification(String string) throws DfException {
    return null;
  }

  public IDfAcsTransferPreferencesImmutable getEffectiveAcsTransferPreferences() {
    return null;
  }

  public void setLoginUserName(String loginUserName) {
    this.loginUserName = loginUserName;
  }
  public List setResults(List results){
    this.results = results;
    return results;
  }
}