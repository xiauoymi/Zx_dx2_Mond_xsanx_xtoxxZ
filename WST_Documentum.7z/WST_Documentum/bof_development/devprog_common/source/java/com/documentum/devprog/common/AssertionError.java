/*
 * Created on Mar 7, 2003
 *
 */
 
package com.documentum.devprog.common;

/**
 * 
 * Represents a runtime assertion failed error. This is meant for a non-asserion
 * architecture of JDK 1.3.xxx and before. Java 1.4 includes a built in assertion
 * mechanism. However, this class is still valid for Java 1.4 and above.
 * 
 * @author Aashish Patil (aashish.patil@documentum.com)
 *
 * 
 */
public class AssertionError extends Error
{

	/**
	 * 
	 */
	public AssertionError()
	{
		super();
		
		
		
	}

	/**
	 * @param arg0
	 */
	public AssertionError(String arg0)
	{
		super(arg0);
		
		
		
	}
	
	

	

}
