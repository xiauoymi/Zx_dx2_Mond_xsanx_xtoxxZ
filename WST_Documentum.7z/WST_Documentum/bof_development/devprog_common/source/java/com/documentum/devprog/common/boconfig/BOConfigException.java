/*
 * Created on Nov 3, 2003
 * Documentum Developer Program 2003
 */
package com.documentum.devprog.common.boconfig;

/**
 * @author Aashish Patil (aashish.patil@documentum.com)
 *
 * 
 */
public class BOConfigException extends Exception
{
   

   /**
    * 
    */
   public BOConfigException()
   {
      super();
      // TODO Auto-generated constructor stub
   }

   /**
    * @param message
    */
   public BOConfigException(String message)
   {
      super(message);
      // TODO Auto-generated constructor stub
   }

   /**
    * @param cause
    */
   public BOConfigException(Throwable cause)
   {
      super(cause);
      // TODO Auto-generated constructor stub
   }

   /**
    * @param message
    * @param cause
    */
   public BOConfigException(String message, Throwable cause)
   {
      super(message, cause);
      // TODO Auto-generated constructor stub
   }

}
