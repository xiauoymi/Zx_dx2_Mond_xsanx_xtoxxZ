/*
 Copyright:  Copyright � 2008 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.test;

import com.documentum.fc.client.*;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.IDfId;
import com.documentum.fc.common.IDfList;

import java.util.ArrayList;
import java.util.List;

/**
 * Filename:    $RCSfile: MockAliasSet.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ussing $    	 On:	$Date: 2009-03-09 20:35:07 $
 *
 * @author rrkaur
 * @version $Revision: 1.3 $
 */
public class MockAliasSet extends MockPersistentObject implements IDfAliasSet {
  List alias= new ArrayList();

  public String getOwnerName() throws DfException {
    return null;
  }


  public void setOwnerName(String string) throws DfException {
  }

  public String getObjectName() throws DfException {
    return null;
  }

  public void setObjectName(String string) throws DfException {
  }

  public String getObjectDescription() throws DfException {
    return null;
  }

  public void setObjectDescription(String string) throws DfException {
  }

  public int getAliasCount() throws DfException {
    return 0;
  }

  public String getAliasName(int i) throws DfException {
    return null;
  }

  public void setAliasName(int i, String string) throws DfException {
  }

  public String getAliasValue(int i) throws DfException {
    return alias.get(i).toString();
  }

  public void setAliasValue(int i, String string) throws DfException {
    alias.add(i,string);
  }

  public int getAliasCategory(int i) throws DfException {
    return 0;
  }

  public void setAliasCategory(int i, int i1) throws DfException {
  }

  public int getAliasUserCategory(int i) throws DfException {
    return 0;
  }

  public void setAliasUserCategory(int i, int i1) throws DfException {
  }

  public String getAliasDescription(int i) throws DfException {
    return null;
  }

  public void setAliasDescription(int i, String string) throws DfException {
  }

  public int appendAlias(String string, String string1, int i, int i1, String string2) throws DfException {
    return 0;
  }

  public void removeAlias(String string) throws DfException {
  }

  public int findAliasIndex(String string) throws DfException {

    return alias.size()-1;
  }

  public void removeAllAliases() throws DfException {
  }

  public boolean isReplica() throws DfException {
    return false;
  }

  public int getVStamp() throws DfException {
    return 0;
  }

  public void destroy() throws DfException {
  }

  public IDfType getType() throws DfException {
    return null;
  }

  public boolean isDirty() throws DfException {
    return false;
  }

  public boolean isNew() throws DfException {
    return false;
  }

  public void revert() throws DfException {
  }

  public void save() throws DfException {
  }

  public boolean apiSet(String s, String s1, String s2) throws DfException {
    return false;
  }

  public boolean apiExec(String s, String s1) throws DfException {
    return false;
  }

  public boolean fetch(String s) throws DfException {
    return false;
  }

  public boolean fetchWithCaching(String s, boolean b, boolean b1) throws DfException {
    return false;
  }

  public IDfRelation addChildRelative(String s, IDfId iDfId, String s1, boolean b, String s2) throws DfException {
    return null;
  }

  public IDfRelation addParentRelative(String s, IDfId iDfId, String s1, boolean b, String s2) throws DfException {
    return null;
  }

  public void removeChildRelative(String s, IDfId iDfId, String s1) throws DfException {
  }

  public void removeParentRelative(String s, IDfId iDfId, String s1) throws DfException {
  }

  public IDfCollection getChildRelatives(String s) throws DfException {
    return null;
  }

  public IDfCollection getParentRelatives(String s) throws DfException {
    return null;
  }

  public boolean isDeleted() throws DfException {
    return false;
  }

  public void signoff(String s, String s1, String s2) throws DfException {
  }

  public void validateAllRules(int i) throws DfException {
  }

  public void validateObjRules(int i) throws DfException {
  }

  public void validateAttrRules(String s, int i) throws DfException {
  }

  public void validateAttrRulesWithValue(String s, String s1, int i) throws DfException {
  }

  public void validateAttrRulesWithValues(String s, IDfList iDfList, int i) throws DfException {
  }

  public void validateObjRulesWithValues(IDfList iDfList, IDfList iDfList1, int i) throws DfException {
  }

  public IDfList getAttrAsstDependencies(String s) throws DfException {
    return null;
  }

  public IDfList getAttrAssistance(String s) throws DfException {
    return null;
  }

  public IDfList getAttrAssistanceWithValues(String s, IDfList iDfList, IDfList iDfList1) throws DfException {
    return null;
  }

  public String getWidgetType(int i, String s) throws DfException {
    return null;
  }

  public IDfValidator getValidator() throws DfException {
    return null;
  }
}