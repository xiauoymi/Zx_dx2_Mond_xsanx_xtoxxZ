/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.utils.pathgeneration.test;

import com.monsanto.dctm.test.MockPersistentObject;
import com.monsanto.dctm.utils.pathgeneration.DefaultPathGenerator;
import com.monsanto.dctm.utils.pathgeneration.PathGenerator;
import junit.framework.TestCase;

import java.util.ArrayList;
import java.util.List;

/**
 * Filename:    $RCSfile: DefaultPathGenerator_UT.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: lakench $    	 On:	$Date: 2007-03-28 21:18:41 $
 *
 * @author lakench
 * @version $Revision: 1.2 $
 */
public class DefaultPathGenerator_UT extends TestCase {

    public void testGeneratePathsNullsToConstructor() throws Exception {
        PathGenerator pathGenerator = new DefaultPathGenerator(null, null);
        List pathList = pathGenerator.generatePaths(new MockPersistentObject());

        assertNotNull(pathList);
        assertTrue(pathList.isEmpty());
    }

    public void testGeneratePathsWithListOfAttrNamesToConstructorAndNullPrefix() throws Exception {
        List listOfAttrNames = new ArrayList();
        listOfAttrNames.add("test1");
        listOfAttrNames.add("test2");
        PathGenerator pathGenerator = new DefaultPathGenerator(null, listOfAttrNames);

        MockPersistentObject object = new MockPersistentObject();
        object.setRepeatingString("test1", 0, "test1value1");
        object.setRepeatingString("test1", 0, "test1value2");
        object.setRepeatingString("test2", 0, "test2value1");
        object.setRepeatingString("test2", 0, "test2value2");

        List pathList = pathGenerator.generatePaths(object);

        assertNotNull(pathList);
        assertFalse(pathList.isEmpty());
        assertEquals(4, pathList.size());
        assertTrue(pathList.contains("test1value1/" + "test2value1"));
        assertTrue(pathList.contains("test1value1/" + "test2value2"));
        assertTrue(pathList.contains("test1value2/" + "test2value1"));
        assertTrue(pathList.contains("test1value2/" + "test2value2"));
    }

    public void testGeneratePathsWithListOfOneAttrNameToConstructor() throws Exception {
        List listOfAttrNames = new ArrayList();
        listOfAttrNames.add("test1");
        PathGenerator pathGenerator = new DefaultPathGenerator(null, listOfAttrNames);

        MockPersistentObject object = new MockPersistentObject();
        object.setRepeatingString("test1", 0, "test1value1");
        object.setRepeatingString("test1", 0, "test1value2");

        List pathList = pathGenerator.generatePaths(object);

        assertNotNull(pathList);
        assertFalse(pathList.isEmpty());
        assertEquals(2, pathList.size());
        assertTrue(pathList.contains("test1value1"));
        assertTrue(pathList.contains("test1value2"));
    }

    public void testGeneratePathsWithBasePath() throws Exception {
        List listOfAttrNames = new ArrayList();
        listOfAttrNames.add("test1");
        listOfAttrNames.add("test2");
        listOfAttrNames.add("test3");
        listOfAttrNames.add("test4");
        PathGenerator pathGenerator = new DefaultPathGenerator("prefix", listOfAttrNames);

        MockPersistentObject object = new MockPersistentObject();
        object.setString("test1", "test1value1");
        object.setRepeatingString("test2", 0, "test2value1");
        object.setRepeatingString("test2", 1, "test2value2");
        object.setRepeatingString("test3", 0, "test3value1");
        object.setRepeatingString("test3", 1, "test3value2");
        object.setString("test4", "test4value1");

        List pathList = pathGenerator.generatePaths(object);

        assertNotNull(pathList);
        assertFalse(pathList.isEmpty());
        assertEquals(4, pathList.size());
        assertTrue(pathList.contains("prefix/" + "test1value1/" + "test2value1/" + "test3value1/" + "test4value1"));
        assertTrue(pathList.contains("prefix/" + "test1value1/" + "test2value1/" + "test3value2/" + "test4value1"));
        assertTrue(pathList.contains("prefix/" + "test1value1/" + "test2value2/" + "test3value1/" + "test4value1"));
        assertTrue(pathList.contains("prefix/" + "test1value1/" + "test2value2/" + "test3value2/" + "test4value1"));
    }
}